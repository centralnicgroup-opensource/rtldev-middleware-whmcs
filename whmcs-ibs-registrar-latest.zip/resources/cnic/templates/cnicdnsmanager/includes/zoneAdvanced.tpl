<div class="cnic-dns-controls">
    <div class="row cnic-controls-row">
        <div class="col-12 col-lg">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" id="dnsRecordSearch" class="form-control" placeholder="{$lang.searchDnsRecordsPlaceholder}" />
            </div>
        </div>
        <div class="col-12 col-lg-auto mt-2 mt-lg-0">
            <div class="cnic-button-group">
                {if $soa.isSupported}
                    <button type="button" id="soaToggle" class="btn btn-default" data-toggle="collapse" data-target="#soaPanel" aria-expanded="{if isset($smarty.post["soa-save"])}true{else}false{/if}" aria-controls="soaPanel">
                        <i class="fa fa-cog"></i> {$lang.soaBtn}
                    </button>
                {/if}
                <button type="button" id="importExportToggle" class="btn btn-default" aria-expanded="false" aria-controls="importExportPanel">
                    <i class="fa fa-exchange"></i> {$lang.importAndExportBtn}
                </button>
                <button type="button" id="headerAddRecordButton" class="btn btn-primary" aria-expanded="false" aria-controls="addNewRecordContainer">
                    <i class="fa fa-plus"></i> {$lang.addRecordBtn}
                </button>
            </div>
        </div>
    </div>
    
    <!-- Combined Import/Export Panel -->
    <div id="importExportPanel" class="cnic-zone-drawer" style="display:none;">
        <div class="row">
            <div class="col-md-6 mb-3 mb-md-0">
                <h4 class="cnic-drawer-title"><i class="fa fa-upload"></i> {$lang.importDnsRecordsTitle}</h4>
                <p class="cnic-drawer-intro">{$lang.importDnsRecordsDesc}</p>
                <div id="zoneDropArea" class="cnic-zone-drop-area-compact">
                    <input type="file" id="zoneFileInput" accept="text/plain,.txt,.zone" style="display:none;" />
                    <i class="fa fa-cloud-upload cnic-drop-icon"></i>
                    <span class="cnic-drop-text">{$lang.selectFileOrDragText}</span>
                    <button type="button" id="zoneFileBrowse" class="btn btn-default">
                        <i class="fa fa-folder-open"></i> {$lang.browseFilesBtn}
                    </button>
                </div>
                <div class="cnic-drawer-warning">
                    <i class="fa fa-exclamation-triangle"></i> <strong>{$lang.importWarningLabel}</strong> {$lang.importWarningText}
                </div>
                <div id="zoneImportResults" class="cnic-zone-import-results"></div>
                <div class="cnic-apply-button-wrapper">
                    <button type="button" id="applyImportedRecordsButton" class="btn btn-success btn-block cnic-apply-button">
                        <i class="fa fa-check"></i> {$lang.applyImportedRecordsBtn}
                    </button>
                </div>
            </div>
            <div class="col-md-6">
                <h4 class="cnic-drawer-title"><i class="fa fa-download"></i> {$lang.exportDnsRecordsTitle}</h4>
                <p class="cnic-drawer-intro">{$lang.exportDnsRecordsDesc}</p>
                <button type="button" id="exportZoneButton" class="btn btn-default">
                    <i class="fa fa-download"></i> {$lang.exportZoneFileBtn}
                </button>
            </div>
        </div>
    </div>

    {if $soa.isSupported}
        {include file="$templateDir/includes/soa.tpl"}
    {/if}
</div>
