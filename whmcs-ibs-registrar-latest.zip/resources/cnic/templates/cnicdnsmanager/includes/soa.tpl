{* SOA settings of the DNS zone — collapsed unless just submitted *}
<div id="soaPanel" class="collapse{if isset($smarty.post["soa-save"])} show{/if}">
    <div class="cnic-zone-drawer">
        <div class="d-flex flex-wrap justify-content-between align-items-baseline mb-2">
            <p class="cnic-drawer-intro mb-0 mr-3">{$lang.soaDesc}</p>
            <small class="cnic-drawer-intro mb-0">
                {$lang.soaLabelSOAMNAME}: <span class="text-monospace text-body">{$soa.values.SOAMNAME|escape:'html'}</span>
                <i class="fa fa-lock" tabindex="0" data-toggle="tooltip" title="{$lang.soaHelpSOAMNAME|escape:'html'}"></i>
            </small>
        </div>

        {if !empty($soa.error)}
            {include file="$templateDir/includes/alert.tpl" type="error" msg=$soa.error|escape:'html'}
        {elseif !empty($soa.fieldErrors)}
            {include file="$templateDir/includes/alert.tpl" type="error" msg=$lang.soaInvalid}
        {elseif $soa.success}
            {include file="$templateDir/includes/alert.tpl" type="success" msg=$lang.soaSaved}
        {/if}

        <form method="post" class="form mb-0" role="form" id="soaForm">
            <div class="form-row">
                {foreach $soa.ranges as $key => $range}
                    {assign var="labelKey" value="soaLabel`$key`"}
                    {assign var="helpKey" value="soaHelp`$key`"}
                    <div class="col-6 col-md-3 form-group mb-2">
                        <label for="soa{$key}">
                            {$lang.$labelKey}
                            <i class="fa fa-question-circle text-muted" tabindex="0" data-toggle="tooltip" title="{$lang.$helpKey|escape:'html'} ({$range[0]} - {$range[1]} {$lang.soaSeconds})"></i>
                        </label>
                        <div class="input-group">
                            <input type="text" inputmode="numeric" pattern="[0-9]*" id="soa{$key}" name="{$key}" class="form-control soa-seconds{if isset($soa.fieldErrors.$key)} is-invalid{/if}" value="{$soa.values.$key|escape:'html'}" />
                            <div class="input-group-append"><span class="input-group-text">s</span></div>
                        </div>
                        {if isset($soa.fieldErrors.$key)}
                            <div class="invalid-feedback d-block">{$lang.soaAllowed} {$range[0]} - {$range[1]} s</div>
                        {else}
                            <small class="form-text text-muted mt-1 soa-human"></small>
                        {/if}
                    </div>
                {/foreach}
            </div>
            <div class="form-row align-items-end">
                <div class="col-md-7 form-group mb-2">
                    <label for="soaSOARNAME">
                        {$lang.soaLabelSOARNAME}
                        <i class="fa fa-question-circle text-muted" tabindex="0" data-toggle="tooltip" title="{$lang.soaHelpSOARNAME|escape:'html'}"></i>
                    </label>
                    <input type="text" id="soaSOARNAME" name="SOARNAME" class="form-control{if isset($soa.fieldErrors.SOARNAME)} is-invalid{/if}" value="{$soa.values.SOARNAME|escape:'html'}" />
                </div>
                <div class="col-md-5 form-group mb-2 cnic-drawer-actions">
                    <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#soaPanel">{lang key='cancel'}</button>
                    <button type="submit" name="soa-save" class="btn btn-primary">
                        <i class="fa fa-check"></i> {$lang.soaSaveBtn}
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(function() {
    $('#soaPanel [data-toggle="tooltip"]').tooltip();

    // only one of the zone panels (SOA, import/export, add record) is open at a time
    $('#soaPanel').on('show.bs.collapse', function() {
        $('#importExportToggle[aria-expanded="true"], #headerAddRecordButton[aria-expanded="true"]').trigger('click');
    });
    $('#importExportToggle, #headerAddRecordButton').on('click', function() {
        $('#soaPanel.show').collapse('hide');
    });

    // show the seconds in a readable unit below each SOA timing field
    var units = [[86400, 'd'], [3600, 'h'], [60, 'min']];
    function readable(value) {
        var seconds = parseInt(value, 10);
        if (!/^\d+$/.test($.trim(value)) || seconds < 60) {
            return '';
        }
        for (var i = 0; i < units.length; i++) {
            if (seconds >= units[i][0]) {
                var amount = Math.round(seconds / units[i][0] * 10) / 10;
                return (amount * units[i][0] === seconds ? '= ' : '≈ ') + amount + ' ' + units[i][1];
            }
        }
        return '';
    }
    $('#soaForm .soa-seconds').on('input', function() {
        $(this).closest('.form-group').find('.soa-human').text(readable($(this).val()));
    }).trigger('input');
});
</script>
