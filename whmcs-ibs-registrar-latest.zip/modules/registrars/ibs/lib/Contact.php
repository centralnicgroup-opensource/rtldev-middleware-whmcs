<?php

namespace WHMCS\Module\Registrar\Ibs;

class Contact
{
    /**
     * Map WHMCS contact data to API contact data
     *
     * @param array<string,mixed> $params WHMCS contact data
     * @return array<string,mixed> API contact data
     */
    public static function mapWHMCStoAPI($params)
    {
        $whmcsContactFields = [
            "firstname",
            "lastname",
            "companyname",
            "address1",
            "address2",
            "city",
            "state",
            "postcode",
            "country",
            "email"
        ];
        // map whmcs <-> api fields for contact data where they differ
        $apiContactFields = [
            "companyname"   => "organization",
            "country"       => "countrycode",
            "postcode"      => "postalcode",
            "address1"      => "street",
            "address2"      => "street2",
        ];

        $registrant = [];
        $admin = [];

        foreach ($whmcsContactFields as $field) {
            $apifield = $apiContactFields[$field] ?? $field;
            $registrant[$apifield] = $params[$field];
            $admin[$apifield] = $params["admin" . $field];
        }

        $registrant["phonenumber"] = PhoneNumber::reformat($params["fullphonenumber"] ?? $params["phonenumber"], $params["country"]);
        $admin["phonenumber"] = PhoneNumber::reformat($params["adminfullphonenumber"] ?? $params["adminphonenumber"], $params["admincountry"]);

        $contactTypes = ["registrant", "technical", "admin", "billing"];
        $result = [];

        foreach ($contactTypes as $type) {
            foreach ($registrant as $key => $value) {
                $result["{$type}_{$key}"] = $value;
            }
            foreach ($admin as $key => $value) {
                $result["{$type}_{$key}"] = $value;
            }
        }
        foreach ($contactTypes as $type) {
            if (empty(trim($result["{$type}_organization"]))) {
                unset($result["{$type}_organization"]);
            }
        }
        return $result;
    }
}
