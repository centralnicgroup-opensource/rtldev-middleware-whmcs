<?php

namespace WHMCS\Module\Registrar\Ibs;

use Illuminate\Database\Capsule\Manager as DB;

class AdditionalFields
{
    /**
     * @var array<string,mixed>|null
     */
    private static $additionalFieldMap = null;

    /**
     * @param string $tld
     * @param array<int|string,mixed> $fields
     * @return array<string,mixed>
     */
    public static function mapToIbsFields($tld, $fields)
    {
        $fieldConfiguration = self::getTldConfiguration($tld);
        if (empty($fieldConfiguration)) {
            return [];
        }

        $lookup = [];
        $orderedFields = [];
        foreach ($fields as $key => $value) {
            if (is_int($key)) {
                $orderedFields[] = $value;
                continue;
            }

            if (ctype_digit($key)) {
                $orderedFields[] = $value;
                continue;
            }

            $normalizedKey = self::normalizeAdditionalFieldKey($key);
            if ($normalizedKey === "" || array_key_exists($normalizedKey, $lookup)) {
                continue;
            }

            $lookup[$normalizedKey] = $value;
        }

        $mappedFields = [];
        $inputIndex = 0;
        foreach ($fieldConfiguration as $field) {
            if (empty($field["name"])) {
                continue;
            }

            $value = null;
            $found = false;

            $names = [$field["name"], $field["ibsName"]];

            foreach ($names as $name) {
                $normalizedName = self::normalizeAdditionalFieldKey($name);
                if (!array_key_exists($normalizedName, $lookup)) {
                    continue;
                }

                $value = $lookup[$normalizedName];
                $found = true;
                break;
            }

            if (!$found && array_key_exists($inputIndex, $orderedFields)) {
                $value = $orderedFields[$inputIndex];
                $found = true;
            }

            $inputIndex++;

            if (!$found) {
                continue;
            }

            if (isset($field["valueMapLookup"]) && is_array($field["valueMapLookup"]) && is_scalar($value)) {
                $normalizedValue = self::normalizeAdditionalFieldKey($value);
                if (array_key_exists($normalizedValue, $field["valueMapLookup"])) {
                    $value = $field["valueMapLookup"][$normalizedValue];
                }
            }

            $mappedFields[$field["ibsName"]] = $value;
        }

        return $mappedFields;
    }

    /**
     * @param string $tld
     * @param array<int,array<string,mixed>> $fallbackFields
     * @param array<string,mixed> $values
     * @return array<int,array<string,mixed>>
     */
    public static function getDisplayFields($tld, $fallbackFields = [], $values = [])
    {
        $fieldConfiguration = self::getTldConfiguration($tld);
        if (empty($fieldConfiguration)) {
            foreach ($fallbackFields as &$fallbackField) {
                if (empty($fallbackField["DisplayName"]) && !empty($fallbackField["Name"])) {
                    $fallbackField["DisplayName"] = $fallbackField["Name"];
                }
            }
            unset($fallbackField);
            return $fallbackFields;
        }

        $fallbackLookup = [];
        $configurationByIbsName = [];
        foreach ($fallbackFields as $fallbackField) {
            if (empty($fallbackField["Name"])) {
                continue;
            }

            $fallbackLookup[self::normalizeAdditionalFieldKey($fallbackField["Name"])] = $fallbackField;
        }

        foreach ($fieldConfiguration as $field) {
            if (empty($field["ibsName"])) {
                continue;
            }

            $configurationByIbsName[self::normalizeAdditionalFieldKey($field["ibsName"])] = $field;
        }

        $displayFields = [];
        foreach ($fieldConfiguration as $field) {
            if (empty($field["name"])) {
                continue;
            }

            $normalizedName = self::normalizeAdditionalFieldKey($field["name"]);
            $displayField = $fallbackLookup[$normalizedName] ?? [
                "Name" => $field["name"],
                "DisplayName" => $field["name"],
                "Type" => (!empty($field["valueMap"]) && is_array($field["valueMap"])) ? "dropdown" : "text",
                "Options" => (!empty($field["valueMap"]) && is_array($field["valueMap"])) ? implode(",", array_keys($field["valueMap"])) : "",
                "contactType" => ["registrant"],
            ];

            if (empty($displayField["DisplayName"]) && !empty($displayField["Name"])) {
                $displayField["DisplayName"] = $displayField["Name"];
            }

            if (!empty($field["requiredWhen"])) {
                $dependentConfiguration = $configurationByIbsName[self::normalizeAdditionalFieldKey($field["requiredWhen"]["field"] ?? "")] ?? null;
                $currentValue = empty($dependentConfiguration["name"])
                    ? null
                    : ($values[self::normalizeAdditionalFieldKey($dependentConfiguration["name"])] ?? null);

                if (!is_scalar($currentValue)) {
                    $displayField["Required"] = false;
                } else {
                    $mappedCurrentValue = $currentValue;
                    if (!empty($dependentConfiguration["valueMapLookup"]) && is_array($dependentConfiguration["valueMapLookup"])) {
                        $normalizedCurrentValue = self::normalizeAdditionalFieldKey($currentValue);
                        if (array_key_exists($normalizedCurrentValue, $dependentConfiguration["valueMapLookup"])) {
                            $mappedCurrentValue = $dependentConfiguration["valueMapLookup"][$normalizedCurrentValue];
                        }
                    }

                    $displayField["Required"] = in_array(
                        self::normalizeAdditionalFieldKey($mappedCurrentValue),
                        $field["requiredWhen"]["values"] ?? [],
                        true
                    );
                }
            } elseif (is_array($displayField["Required"] ?? null)) {
                $isRequired = false;
                foreach ($displayField["Required"] as $dependencyFieldName => $dependencyValues) {
                    $currentValue = $values[self::normalizeAdditionalFieldKey($dependencyFieldName)] ?? null;
                    if (!is_scalar($currentValue) || !is_array($dependencyValues)) {
                        continue;
                    }

                    if (in_array((string) $currentValue, $dependencyValues, true)) {
                        $isRequired = true;
                        break;
                    }
                }

                $displayField["Required"] = $isRequired;
            }

            $displayFields[] = $displayField;
        }

        return $displayFields;
    }

    /**
     * @param string $tld
     * @param array<string,mixed> $fields
     * @return array<string,mixed>
     */
    public static function mapFromIbsFields($tld, $fields)
    {
        $fieldConfiguration = self::getTldConfiguration($tld);
        if (empty($fieldConfiguration)) {
            return [];
        }

        $lookup = [];
        foreach ($fields as $key => $value) {
            $lookup[self::normalizeAdditionalFieldKey($key)] = $value;
        }

        $mappedFields = [];
        foreach ($fieldConfiguration as $field) {
            if (empty($field["name"]) || empty($field["ibsName"])) {
                continue;
            }

            $possibleKeys = [$field["ibsName"]];
            if (!empty($field["copyTo"])) {
                $possibleKeys[] = $field["copyTo"];
            }

            $matchedKey = null;
            foreach ($possibleKeys as $possibleKey) {
                $normalizedKey = self::normalizeAdditionalFieldKey($possibleKey);
                if (array_key_exists($normalizedKey, $lookup)) {
                    $matchedKey = $normalizedKey;
                    break;
                }

                $shortKey = preg_replace('/^[^_]+_/', '', $possibleKey);
                if (!is_string($shortKey) || $shortKey === $possibleKey) {
                    continue;
                }

                $normalizedShortKey = self::normalizeAdditionalFieldKey($shortKey);
                if (array_key_exists($normalizedShortKey, $lookup)) {
                    $matchedKey = $normalizedShortKey;
                    break;
                }
            }

            if ($matchedKey === null || !is_scalar($lookup[$matchedKey])) {
                continue;
            }

            $value = $lookup[$matchedKey];
            if (!empty($field["valueMap"]) && is_array($field["valueMap"])) {
                $normalizedValue = self::normalizeAdditionalFieldKey($value);
                foreach ($field["valueMap"] as $inputValue => $mappedValue) {
                    if (self::normalizeAdditionalFieldKey($mappedValue) === $normalizedValue) {
                        $value = $inputValue;
                        break;
                    }
                }
            }

            $mappedFields[$field["name"]] = $value;
        }

        return $mappedFields;
    }

    /**
     * @param string $tld
    * @param array<int|string,mixed> $fields
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     */
    public static function buildTldPayload($tld, $fields, $context = [])
    {
        $fieldConfiguration = self::getTldConfiguration($tld);
        $mappedFields = self::mapToIbsFields($tld, $fields);

        foreach ($fieldConfiguration as $field) {
            if (
                empty($field["ibsName"])
                || !array_key_exists("default", $field)
                || (isset($mappedFields[$field["ibsName"]]) && $mappedFields[$field["ibsName"]] !== "")
            ) {
                continue;
            }

            $mappedFields[$field["ibsName"]] = $field["default"];
        }

        foreach ($fieldConfiguration as $field) {
            if (empty($field["ibsName"])) {
                continue;
            }

            if (!empty($field["requiredWhen"]) && !self::matchesFieldCondition($mappedFields, $field["requiredWhen"])) {
                unset($mappedFields[$field["ibsName"]]);
                if (!empty($field["copyTo"])) {
                    unset($mappedFields[$field["copyTo"]]);
                }
                continue;
            }

            if (!empty($field["copyTo"]) && !empty($mappedFields[$field["ibsName"]])) {
                $mappedFields[$field["copyTo"]] = $mappedFields[$field["ibsName"]];
            }

            if (!self::matchesFieldCondition($mappedFields, $field["when"] ?? null)) {
                continue;
            }

            if (!empty($field["context"])) {
                if (!empty($context[$field["context"]])) {
                    $mappedFields[$field["ibsName"]] = $context[$field["context"]];
                }
                continue;
            }

            if (array_key_exists("value", $field)) {
                $mappedFields[$field["ibsName"]] = $field["value"];
            }
        }

        return $mappedFields;
    }

    /**
     * @param string $tld
     * @return array<int,array<string,mixed>>
     */
    private static function getTldConfiguration($tld)
    {
        if (!is_array(self::$additionalFieldMap)) {
            $raw = file_get_contents(__DIR__ . "/additionalfields_map.json");
            if ($raw === false) {
                throw new \RuntimeException("Unable to load additional field mappings.");
            }

            $config = json_decode($raw, true);
            if (!is_array($config)) {
                throw new \RuntimeException("Invalid additional field mapping configuration.");
            }

            $normalizedConfiguration = [];
            foreach ($config as $defaultTld => $groupConfiguration) {
                if (empty($groupConfiguration["fields"]) || !is_array($groupConfiguration["fields"])) {
                    continue;
                }

                $fields = [];
                foreach ($groupConfiguration["fields"] as $fieldConfiguration) {
                    if (
                        !is_array($fieldConfiguration)
                        || empty($fieldConfiguration["ibsName"])
                    ) {
                        continue;
                    }

                    if (!empty($fieldConfiguration["valueMap"]) && is_array($fieldConfiguration["valueMap"])) {
                        $normalizedValueMap = [];
                        foreach ($fieldConfiguration["valueMap"] as $inputValue => $mappedValue) {
                            $normalizedValueMap[self::normalizeAdditionalFieldKey($inputValue)] = $mappedValue;
                        }
                        $fieldConfiguration["valueMapLookup"] = $normalizedValueMap;
                    }

                    foreach (["when", "requiredWhen"] as $conditionKey) {
                        if (empty($fieldConfiguration[$conditionKey]["values"]) || !is_array($fieldConfiguration[$conditionKey]["values"])) {
                            continue;
                        }

                        $normalizedValues = [];
                        foreach ($fieldConfiguration[$conditionKey]["values"] as $value) {
                            $normalizedValues[] = self::normalizeAdditionalFieldKey($value);
                        }

                        $fieldConfiguration[$conditionKey]["values"] = $normalizedValues;
                    }

                    $fields[] = $fieldConfiguration;
                }

                if (empty($fields)) {
                    continue;
                }

                $tlds = [$defaultTld];
                if (!empty($groupConfiguration["tlds"]) && is_array($groupConfiguration["tlds"])) {
                    $tlds = array_merge($tlds, $groupConfiguration["tlds"]);
                }

                foreach ($tlds as $configuredTld) {
                    $normalizedConfiguration[ltrim(self::normalizeAdditionalFieldKey($configuredTld), ".")] = $fields;
                }
            }

            self::$additionalFieldMap = $normalizedConfiguration;
        }

        $tld = ltrim(self::normalizeAdditionalFieldKey($tld), ".");
        return self::$additionalFieldMap[$tld] ?? [];
    }

    /**
     * @param mixed $value
     * @return string
     */
    private static function normalizeAdditionalFieldKey($value)
    {
        return strtolower(trim((string) $value));
    }

    /**
     * @param array<string,mixed> $fields
     * @param mixed $condition
     * @return bool
     */
    private static function matchesFieldCondition($fields, $condition)
    {
        if (
            !is_array($condition)
            || empty($condition["field"])
            || empty($condition["values"])
            || !is_array($condition["values"])
        ) {
            return true;
        }

        $fieldValue = $fields[$condition["field"]] ?? null;
        return is_scalar($fieldValue)
            && in_array(self::normalizeAdditionalFieldKey($fieldValue), $condition["values"], true);
    }

    /**
     * Validate contact data for AFNIC TLDs
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @param string $countryCode country code
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateContactDataAFNIC($domain, $fields, $countryCode, $clientDetails)
    {
        $errors = [];
        if (!Country::isEuropeanUnionCountry($countryCode)) {
            $errors[] = "Registrant must be from European union (" . $domain . "). Provided $countryCode";
        }
        return array_merge($errors, self::validateAFNIC($domain, $fields, $clientDetails));
    }

    /**
     * Validate additional fields for AFNIC TLDs
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateAFNIC($domain, $fields, $clientDetails)
    {
        $errors = [];
        switch ($fields["holdertype"]) {
            case "individual":
                if (
                    empty($fields["birthdate"])
                    || !preg_match("/^(\d{4})-(\d{2})-(\d{2})$/", $fields["birthdate"], $m)
                    || !checkdate((int)$m[2], (int)$m[3], (int)$m[1]) // m, d, y
                ) {
                    $errors[] = "Valid Date Of Birth is required (" . $domain . ")";
                }
                if (empty($fields["birthcountry"])) {
                    $errors[] = "Birth Country is required (" . $domain . ")";
                }
                if ($fields["birthcountry"] === "FR" && (empty($fields["birthcity"]) || empty($fields["birthpostalcode"]))) {
                    $errors[] = "Birth City plus its Postal Code are required (" . $domain . ")";
                }
                break;
            case "trademark":
                if (empty($fields["trademark"])) {
                    $errors[] = "Trademark is required (" . $domain . ")";
                }
                break;
            case "association":
                if (empty($fields["waldec"]) && empty($fields["dateofassociation"])) {
                    $errors[] = "Waldec or Date of Association is required (" . $domain . ")";
                }
                if (!empty($fields["dateofassociation"]) && empty($fields["dateofpublication"])) {
                    $errors[] = "Date of Publication is required (" . $domain . ")";
                }
                break;
            case "other":
                if (empty($fields["otherlegalstatus"])) {
                    $errors[] = "Other legal status is required (" . $domain . ")";
                }
                break;
        }
        return $errors;
    }

    /**
     * Validate additional fields for .ASIA TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateASIA($domain, $fields, $clientDetails)
    {
        $errors = [];
        if ($fields["legalentity"] == "other") {
            if (!$fields["otherlegalentity"]) {
                $errors[] = "Other Legal Entity Type is required (" . $domain . ")";
            }
        }
        if ($fields["identificationform"] == "other") {
            if (!$fields["otheridentificationform"]) {
                $errors[] = "Other identification form is required (" . $domain . ")";
            }
        }
        return $errors;
    }

    /**
     * Validate contact data for .IT TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param string $countryCode country code
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateContactDateIT($domain, $fields, $countryCode, $clientDetails)
    {
        $nationality = $fields["nationality"];
        if (strlen($nationality) > 2) {
            $nationality = Country::getCountryCodeByName($nationality);
        }
        if ($fields["legalentity"] === "1. Italian and foreign natural persons") {
            if (!Country::isEuropeanUnionCountry($nationality) && !Country::isEuropeanUnionCountry($countryCode)) {
                return [ "Registrant Nationality or Country has to be from European union (" . $domain . ")" ];
            }
        }
        if ($fields["legalentity"] == "7. foreigners who match 2 - 6") {
            if (!Country::isEuropeanUnionCountry($nationality) || $nationality !== $countryCode) {
                return [ "Registrant Nationality and Country have to be same and have to be from European union (" . $domain . ")" ];
            }
        }
        if ($countryCode !== "IT" && $countryCode !== "ITALY") {
            return [ "Registrant Country must be Italy (" . $domain . ")" ];
        }
        return [];
    }

    /**
     * Validate additional fields for .IT TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateIT($domain, $fields, $clientDetails)
    {
        $errors = [];
        if ($fields["legalentity"] == "7. foreigners who match 2 - 6") {
            if (!Country::isEuropeanUnionCountry($fields["nationality"])) {
                $errors[] = "Nationality must be from European Countries (" . $domain . ")";
            }
        } elseif (isset($fields["legalentity"]) && $fields["legalentity"] !== "1. Italian and foreign natural persons") {
            if ($fields["nationality"] !== "IT" && $fields["nationality"] !== "ITALY") {
                $errors[] = "Nationality must be Italy (" . $domain . ")";
            }
        }
        if (isset($fields["legalentity"]) && $fields["legalentity"] !== "1. Italian and foreign natural persons" && $fields["whois"] == "on") {
            $errors[] = "Whois information can be hidden for Italian and foreign natural persons entity type only (" . $domain . ")";
        }
        return $errors;
    }

    /**
     * Validate contact data for .DE TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param string $countryCode country code
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateContactDataDE($domain, $fields, $countryCode, $clientDetails)
    {
        // Admin from Germany!
        $errors = [];
        $adminCountryCode = Country::getAdminCountryCode($countryCode);
        if ($countryCode !== "DE" && $adminCountryCode !== "DE") {
            $errors[] = "Registrant or Admin must be from Germany (" . $domain . ")";
        }
        return array_merge($errors, self::validateDE($domain, $fields, $clientDetails));
    }

    /**
     * Validate additional fields for .DE TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateDE($domain, $fields, $clientDetails)
    {
        $errors = [];
        if (
            // TODO: context of contact?!?
            (empty($clientDetails["companyname"]) && $fields["role"] === "ORG")
            || (!empty($clientDetails["companyname"]) && $fields["role"] === "PERSON")
        ) {
            $errors[] = empty($clientDetails["companyname"])
                ? "<b>" . $domain . "</b>: Your account doesn't have a valid Company Name. Please select 'Person' as the contact role type in your cart or update your account details."
                : "<b>" . $domain . "</b>: Your account is marked as a company account. Please select 'Organization' as the contact role type in your cart or update your account details.";
        }
        return $errors;
    }

    /**
     * Validate contact data for .UK TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param string $countryCode country code
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateContactDataUK($domain, $fields, $countryCode, $clientDetails)
    {
        $errors = [];
        $adminCountryCode = Country::getAdminCountryCode($countryCode);
        if (!(bool)preg_match("/^(GG|IM|JE|GB)$/i", $adminCountryCode)) {
            $errors[] = "Invalid Country for admininistrative Contact (" . $domain . ")";
        }
        return array_merge($errors, self::validateUK($domain, $fields, $clientDetails));
    }

    /**
     * Validate additional fields for .UK TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateUK($domain, $fields, $clientDetails)
    {
        list(, $tld) = explode(".", $domain, 2);
        $fieldConfiguration = self::getTldConfiguration($tld);
        $fields = self::buildTldPayload($tld, $fields);
        $errors = [];

        foreach ($fieldConfiguration as $field) {
            if (
                empty($field["ibsName"])
                || empty($field["requiredMessage"])
                || !self::matchesFieldCondition($fields, $field["requiredWhen"] ?? null)
            ) {
                continue;
            }

            if (empty($fields[$field["ibsName"]] ?? null)) {
                $errors[] = $field["requiredMessage"] . " (" . $domain . ")";
            }
        }

        return $errors;
    }

    /**
     * Validate additional fields for .FI TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateFI($domain, $fields, $clientDetails)
    {
        $errors = [];
        $contactType = self::getAdditionalFieldValue($fields, ["contacttype", "registrant_contacttype"]);
        $birthDate = self::getAdditionalFieldValue($fields, ["birthdate", "registrant_birthdate"]);
        $personalId = self::getAdditionalFieldValue($fields, ["personalid", "registrant_personalid"]);
        $companyNumber = self::getAdditionalFieldValue($fields, ["companynumber", "registrant_companynumber"]);

        if ($contactType === "") {
            return ["Legal Entity Type is required (" . $domain . ")"];
        }

        if (!preg_match('/^[0-7]$/', $contactType)) {
            return ["Legal Entity Type is invalid (" . $domain . ")"];
        }

        if (
            $birthDate !== ""
            && (
                !preg_match("/^(
                    \\d{4})-(\\d{2})-(\\d{2})$/x", $birthDate, $m)
                || !checkdate((int)$m[2], (int)$m[3], (int)$m[1])
            )
        ) {
            $errors[] = "Birth Date must use YYYY-MM-DD (" . $domain . ")";
        }

        if ($contactType === "0") {
            if ($birthDate === "" && $personalId === "") {
                $errors[] = "Birth Date or Personal Identification Number is required for private persons (" . $domain . ")";
            }
        } elseif ($companyNumber === "") {
            $errors[] = "Company Registration Number is required for non-private registrants (" . $domain . ")";
        }

        return $errors;
    }

    /**
     * Validate contact data for .FI TLD
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param string $countryCode country code
     * @param array<string,mixed> $clientDetails client details
     * @return array<string>
     */
    public static function validateContactDataFI($domain, $fields, $countryCode, $clientDetails)
    {
        $errors = [];
        $contactType = self::getAdditionalFieldValue($fields, ["contacttype", "registrant_contacttype"]);
        $birthDate = self::getAdditionalFieldValue($fields, ["birthdate", "registrant_birthdate"]);
        $personalId = self::getAdditionalFieldValue($fields, ["personalid", "registrant_personalid"]);

        if ($contactType !== "0") {
            return $errors;
        }

        if (strtoupper(trim($countryCode)) === "FI") {
            if ($personalId === "") {
                $errors[] = "Personal Identification Number is required for Finnish private persons (" . $domain . ")";
            }
            return $errors;
        }

        if ($birthDate === "") {
            $errors[] = "Birth Date is required for non-Finnish private persons (" . $domain . ")";
        }

        return $errors;
    }

    /**
     * @param array<string,mixed> $fields
     * @param array<int,string> $keys
     * @return string
     */
    private static function getAdditionalFieldValue($fields, $keys)
    {
        foreach ($keys as $key) {
            if (!array_key_exists($key, $fields) || !is_scalar($fields[$key])) {
                continue;
            }

            return trim((string) $fields[$key]);
        }

        return "";
    }

    /**
     * Validate additional fields on shopping cart
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @return array<string>
     */
    public static function validate($domain, $fields)
    {
        list($sld, $tld) = explode(".", $domain, 2);

        $fn = "validate" . ((bool)preg_match("/\.(fr|re|pm|yt|wf|tf)$/i", "." . $tld) ? "AFNIC" : strtoupper($tld));
        if (is_callable([self::class, $fn])) {
            $data = localAPI("GetClientsDetails", [
                "clientid" => \WHMCS\Session::get("uid")
            ]);
            return self::$fn($domain, $fields, $data);
        }
        return [];
    }

    /**
     * Validate contact data
     *
     * @param string $domain domain name
     * @param array<string,mixed> $fields additional fields
     * @param string $countryCode country code
     * @return array<string>
     */
    public static function validateContactData($domain, $fields, $countryCode)
    {
        list($sld, $tld) = explode(".", $domain, 2);

        $fn = "validateContactData" . ((bool)preg_match("/\.(eu|fr|re|pm|yt|wf|tf)$/i", "." . $tld) ? "AFNIC" : strtoupper($tld));
        if (is_callable([self::class, $fn])) {
            $data = localAPI("GetClientsDetails", [
                "clientid" => \WHMCS\Session::get("uid")
            ]);
            return self::$fn($domain, $fields, $countryCode, $data);
        }
        return [];
    }

    /**
     * Validate contact data details
     *
     * @param string $countryCode country code
     * @param string $phoneNumber phone number
     * @return array{countryCode:string,phoneNumber:string}|array{error:string}
     */
    public static function validateContactDataDetails($countryCode, $phoneNumber)
    {
        $c1 = empty($countryCode);
        $c2 = empty($phoneNumber);
        if ($c1 && $c2) {
            return [ "error" => "Country Code and Phone Number are required" ];
        }
        if ($c1) {
            return [ "error" => "Country Code is required" ];
        }
        if ($c2) {
            return [ "error" => "Phone Number is required" ];
        }
        $formattedPhoneNumber = PhoneNumber::reformat($phoneNumber, $countryCode);
        $isValidPhone = PhoneNumber::validate($formattedPhoneNumber);
        if (!$isValidPhone) {
            return [ "error" => "Invalid phone Number " . $phoneNumber ];
        }
        return [
            "countryCode" => $countryCode,
            "phoneNumber" => $formattedPhoneNumber
        ];
    }

    /**
     * Fetch and validate contact data
     *
     * @param array<string,mixed> $params WHMCS params
     * @return array{countryCode:string,phoneNumber:string}|array{error:string}
     */
    public static function fetchAndValidateContactData($params)
    {
        if ($params["custtype"] === "new") {
            return self::validateContactDataDetails($params["country"], $params["phonenumber"]);
        }
        if (strtolower($params["contact"]) === "addingnew") {
            return self::validateContactDataDetails($params["domaincontactcountry"], $params["domaincontactphonenumber"]);
        }
        if ($params["contact"]) {
            $contact = DB::table("tblcontacts")
                        ->select("country", "phonenumber")
                        ->where("id", $params["contact"])
                        ->first();
            if (is_null($contact)) {
                return [ "error" => "Unable to load contact: " . $params["contact"] ];
            }
            /** @var array{country:string,phonenumber:string} $data */
            $data = get_object_vars($contact);
            return self::validateContactDataDetails($data["country"], $data["phonenumber"]);
        }

        // load client details
        $data = localAPI("GetClientsDetails", [
            "clientid" => \WHMCS\Session::get("uid")
        ]);
        return self::validateContactDataDetails($data["country"], $data["phonenumber"]);
    }
}
