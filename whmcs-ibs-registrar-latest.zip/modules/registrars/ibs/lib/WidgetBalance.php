<?php

namespace WHMCS\Module\Registrar\Ibs;

class WidgetBalance
{
    /** @var array<string,mixed> */
    private $data = [];
    /** @var string */
    private $widgetid = null;
    /** @var string */
    private $registrarid = null;
    /** @var array<string,mixed> */
    private $currency = [];
    /** @var float */
    private $lowBalanceThreshold = 0; // threshold for low balance
    /**
     * Constructor
     *
     * @param string $widgetid the widget id
     * @param string $registrarid the registrar id
     * @param array<string,mixed> $params common module parameters
     */
    public function __construct($widgetid, $registrarid, $params)
    {
        $this->widgetid = $widgetid;
        $this->registrarid = $registrarid;

        /**
         * @codeCoverageIgnore
         */
        // init status
        if (isset($_SESSION[$this->widgetid]["data"])) { // data cache exists
            $this->data = $_SESSION[$this->widgetid]["data"];
        } else {
            // fetch data from registrar
            $fn = $this->registrarid . "_getAccountDetails";
            if (!function_exists($fn)) {
                return;
            }
            $accountsStatus = $fn($params);
            if ($accountsStatus["status"] === "SUCCESS") {
                // Collect all balances and currencies
                $balances = [];
                $defaultCurrencyCode = "USD";
                $defaultTotal = 0;
                $exchangeRates = \WHMCS\Utility\CurrencyExchange::fetchCurrentRates();
                if (isset($accountsStatus["balance"])) {
                    foreach ($accountsStatus["balance"] as $idx => $row) {
                        $balances[] = [
                            "currency" => $row["currency"],
                            "amount" => $row["amount"],
                        ];
                        $defaultTotal += $row["amount"] * $exchangeRates->getUsdExchangeRate($row["currency"]);
                    }
                }
                // Store all balances in $this->data
                $this->data["balances"] = $balances;
                // Optionally, set the first balance as default for backward compatibility
                if ($balances && count($balances) > 1) {
                    $this->data["amount"] = $defaultTotal;
                    $this->data["currency"] = $defaultCurrencyCode;
                } else {
                    $this->data["amount"] = $balances[0]["amount"] ?? 0;
                    $this->data["currency"] = $balances[0]["currency"] ?? "USD";
                }
                $this->data["lastUpdated"] = date("Y-m-d H:i:s");
                $_SESSION[$this->widgetid]["data"] = $this->data;
            }
        }

        // init currency
        $currencies = localAPI("GetCurrencies", []);
        $currenciesAsAssocList = [];
        if ($currencies["result"] === "success") {
            foreach ($currencies["currencies"]["currency"] as $idx => $d) {
                $currenciesAsAssocList[$d["code"]] = $d;
            }
        }
        $this->currency  = $currenciesAsAssocList;
    }

    /**
     * get balance data
     * @return array<string,mixed>
     */
    public function getData(): array
    {
        $amount = floatval($this->data["amount"]);
        $currency = $this->data["currency"];
        $currencyid = $this->currency[$currency]["id"] ?? null;
        return [
            "amount" => $amount,
            "currency" => $currency,
            "currencyID" => $currencyid,
            "lastUpdated" => $this->data["lastUpdated"] ?? null,
            "balances" => $this->data["balances"] ?? [],
        ];
    }

    /**
     * get formatted balance data
     * @return array<string,mixed>
     */
    public function getDataFormatted(): ?array
    {
        $data = $this->getData();
        if (is_null($data["currencyID"])) {
            $formattedAmount = number_format($data["amount"], 2, ".", ",") . " " . $data["currency"];
        } else {
            $formattedAmount = formatCurrency($data["amount"], $data["currencyID"]);
        }
        return [
            "amount" => $formattedAmount,
            "rawAmount" => $data["amount"],
            "balances" => $data["balances"],
            "lastUpdated" => $data["lastUpdated"],
        ];
    }

    /**
     * generate balance as HTML
     * @return string
     */
    public function toHTML(): string
    {
        $data = $this->getDataFormatted();
        if (is_null($data)) {
            return <<<HTML
<div class="ibs-widget-notice ibs-widget-notice--danger">Loading Account Data failed.</div>
HTML;
        }

        $balanceState = (floatval($data["rawAmount"]) < $this->lowBalanceThreshold) ? " ibs-widget-amount--negative" : "";
        $html = <<<HTML
<div class="ibs-widget-balance">
    <div class="ibs-widget-label">Account balance</div>
    <div class="ibs-widget-amount{$balanceState}">{$data["amount"]}</div>
HTML;

        // Enhanced multi-currency display if multiple balances exist
        if (!empty($data["balances"]) && count($data["balances"]) > 1) {
            $html .= "<div class=\"ibs-widget-chips\">";
            foreach ($data["balances"] as $index => $bal) {
                $currency = htmlspecialchars($bal["currency"]);
                $amount = number_format(floatval($bal["amount"]), 2, ".", ",");
                $chipState = floatval($bal["amount"]) < $this->lowBalanceThreshold ? " ibs-widget-chip--negative" : "";
                $html .= "<span class=\"ibs-widget-chip{$chipState}\">{$currency} {$amount}</span>";
            }
            $html .= "</div>";
        }

        $html .= <<<HTML
    <div class="ibs-widget-account">Updated {$this->data["lastUpdated"]}</div>
</div>
HTML;
        return $html;
    }
}
