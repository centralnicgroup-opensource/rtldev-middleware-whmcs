## [5.8.1](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.8.0...ibs-moniker-5.8.1) (2026-10-16)

### Bug Fixes

* **Internet.bs Registrar Module:** load the DNS Manager pages in the client area again ([c4d40b5](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/c4d40b5f8039f1472414449b430d425e44f174e2))

  The DNS Manager and Web Forwarding pages in the client area stopped with the error "Undefined constant CNIC_VERSION" on installs that use the Internet.bs or Moniker registrar. Both pages load again.

# [5.8.0](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.7.0...ibs-moniker-5.8.0) (2026-10-15)

### Upgrade Notes

* **CNIC DNS Manager Addon:** DNS records are saved one at a time when clients save or
delete a record; the "Save Changes" and "Cancel Changes" buttons are gone.

Refs: RSRMID-3129, RSRMID-3130, RSRMID-3131


### Features

* **CNIC DNS Manager Addon:** redesign the client area with per-record editing ([a0501cd](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/a0501cddb0ccd9f62cd2e8f4d0382d9bc715488b))

  The DNS Manager and Web Forwarding pages have a new, cleaner design that
  also works well on phones.

  DNS records are listed as plain rows with their type, value and a readable
  TTL. Clients can search, filter by record type, sort by column and page
  through large zones. Adding and editing a record use one form: it shows
  labels and examples for the selected record type, a summary of what the
  record does ("www.example.com points to 192.0.2.10") and a choice of TTL,
  and it can be saved once the input is valid. Deleting asks for confirmation.

  Each change is saved straight away: a confirmation appears, the saved
  record is highlighted briefly, and nothing changes if saving fails.

  Zone settings (SOA), import and export open from the toolbar. On phones,
  records are tappable cards, forms open as bottom sheets and Add record stays
  at the bottom of the screen. The pages can be used with the keyboard alone.

  Web forwardings are listed in a table with Edit and Delete. The form offers
  the forwarding type as three options, shows the domain next to the source
  host name and summarises the forwarding before it is saved. Forwardings no
  longer show the domain twice in their name.

  All texts are available in English, German, Italian and Arabic.

# [5.7.0](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.6.0...ibs-moniker-5.7.0) (2026-10-15)

### Features

* **CNIC DNS Manager Addon:** let clients edit the SOA of existing DNS zones ([b444d5c](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/b444d5cc7edca349ed23ba48b84dc3e3b6fae679))

  Existing zones could only have their SOA changed per zone in the
  CentralNic Reseller control panel, which WHMCS resellers and their
  customers don't have access to.

  The DNS Manager now has an SOA Settings panel for zones on cnic and its
  wrapper registrars. It shows the current SOA, lets clients change RName,
  Refresh, Retry, Expire and Minimum TTL within the ranges the control panel
  validates (ModifyDNSZone::SOA_RANGES), and sends only the changed fields
  through ModifyDNSZone. The MName stays read-only and the serial is left to
  the DNS platform. Each change is written to the activity log. The new
  addon setting "Allow clients to edit SOA" (default on) turns the panel off.

  The SOA, import/export and add record panels now share one compact layout:
  the toolbar buttons show which panel is open and only one panel is open at
  a time, import and export take a third of the previous height, and the type
  select matches the height of the text inputs, in the panels and table rows.

  Refs: RSRMID-3128

# [5.6.0](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.13...ibs-moniker-5.6.0) (2026-10-15)

### Features

* **CNIC DNS Manager Addon:** add SOA Refresh, Retry, Expire and MinTTL settings for new DNS zones ([f3f73ad](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/f3f73adfdaae8bdf8b70d730a8e400bb0f0769f8))

  The DNS Manager addon only allowed customizing SOA RNAME and MNAME for new
  DNS zones, and the CentralNic Reseller control panel only offers SOA
  overrides per zone, so resellers had no way to set SOA timing defaults.

  New optional addon settings SOA Refresh, Retry, Expire and MinTTL are passed
  to AddDNSZone when set within the ranges the control panel validates;
  empty or out-of-range values fall back to the API defaults. Existing zones
  are not touched. A lower MinTTL shortens how long resolvers cache negative
  answers, e.g. for the DNSSEC keys after signing a zone.

  Refs: RSRMID-3127

## [5.5.13](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.12...ibs-moniker-5.5.13) (2026-10-14)

### Upgrade Notes

* **CNIC DNS Manager Addon:** If the "KeyDNS Nameservers" setting of a CNIC registrar module contains an invalid entry, WHMCS will refuse to save that module's settings until the entry is corrected or the field is emptied to use the default nameservers.


### Bug Fixes

* **CNIC DNS Manager Addon:** send clients to their domain list when a domain cannot be managed ([25554db](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/25554db9a852b589512e01118fa732592558e6b5))

  When the DNS Manager is opened for a domain that cannot be managed there, for example a domain of another client account, a domain without DNS management or one not managed through a CentralNic registrar module, the client is now taken to their domain list. Previously they landed on the client area home page, and every such request added a 'requested template file ".tpl" which could not be found' entry to the WHMCS Activity Log. The redirect works with every Friendly URLs setting and for WHMCS installations in a subfolder.

  The DNS Manager no longer shows unreadable nameservers in its "This zone is not active" notice, and no longer reports a zone as inactive because of them. The "KeyDNS Nameservers" setting of the CNIC registrar module and of its additional account modules (cnic1, cnic2, ...) now ignores entries that are not valid nameserver hostnames, and uses the default nameservers ns1.dnsres.net, ns2.dnsres.net and ns3.dnsres.net when no valid entry is left. Saving the registrar settings with an invalid entry, for example nameservers separated by semicolons or spaces instead of commas, is now refused with a message naming the entry, so that it can be corrected.

## [5.5.12](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.11...ibs-moniker-5.5.12) (2026-10-13)

### Bug Fixes

* **CNIC DNS Manager Addon:** only let clients manage DNS of their own domains ([a083507](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/a08350757821f24a66d0651e70212e8cfc49cc00))

  The DNS Manager now checks that a domain belongs to the logged-in client before it shows or changes the domain's DNS records, web forwarding or zone file. Opening the DNS Manager for a domain of another client account, for example through an old link or after switching between client accounts, now returns to the client area instead of failing with "The domain name input is empty". We recommend installing this update.

  Web forwarding now also works for domains assigned to an additional CentralNic Reseller account (wrapper registrar modules such as cnic1 and cnic2). Until now the Web Forwarding page returned to the client area for these domains.

## [5.5.11](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.10...ibs-moniker-5.5.11) (2026-10-09)

### Bug Fixes

* **Internet.bs Registrar Module:** keep NS records when saving DNS in the client area ([1cd068f](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/1cd068fdd452427610dd2a9622378a7fc69c6cbc))

  Adding, editing or deleting a DNS record on the standard WHMCS DNS management page could remove the domain's NS records (for example topdns nameserver records). The page has no NS option in its record-type list, so existing NS records were sent back as the wrong type and removed on save.

  Record types the standard WHMCS page cannot display (NS, CAA, SRV, SSHFP, TLSA and others) are now left out of that page and are never changed when a client saves. They stay in place at the registrar.

  If you use the CNIC DNS Manager addon, nothing changes: all record types, including NS, stay visible and editable there.

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))
