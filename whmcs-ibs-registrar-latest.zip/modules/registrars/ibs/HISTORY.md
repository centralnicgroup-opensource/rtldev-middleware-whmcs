## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))
