<?php

use Illuminate\Database\Capsule\Manager as DB;

function br2nl($string)
{
    return preg_replace('/\<br(\s*)?\/?\>/i', "\n", $string);
}

$cronreport = "Internet.bs Domain Sync Report<br>
---------------------------------------------------<br>
";

$path = $_SERVER["SCRIPT_FILENAME"];
$dir = dirname($path);
if (is_link($dir)) {
    // DEV ENVIRONMENT
    $path = dirname($dir, 3) . DIRECTORY_SEPARATOR . "init.php";
} else {
    $path = __DIR__ . "/../../../init.php";
}

if (!file_exists($path)) {
    $cronreport .= "Error: WHMCS' init.php not found. ($path)<br>";
    echo br2nl($cronreport);
    return;
}

require $path;
require ROOTDIR . "/includes/functions.php";
require ROOTDIR . "/includes/registrarfunctions.php";

# Check if there are domains with status Active or Pending Transfer
$results = DB::table("tbldomains")
    ->where("registrar", "ibs")
    ->whereIn("status", ["Pending Transfer", "Active"])
    ->get();
# WHMCS 7 vs 8 (Laravel Query Builder upgraded - Object vs. Array)
if (is_object($results)) {
    $results = json_decode(json_encode($results), true);
}
if (empty($results)) {
    $cronreport .= "INFO: No Domains identified requiring a Synchronization.<br>";
    logActivity("Internet.bs Domain Sync Run");
    sendAdminNotification("system", "WHMCS Internet.bs Domain Syncronisation Report", $cronreport);
    echo br2nl($cronreport);
    return;
}

# Load the IBS Registrar Module
$module = new WHMCS\Module\Registrar();
if (!$module->load("ibs")) {
    $cronreport .= "ERROR: Unable to load the Internet.bs Registrar Module.<br>";
    logActivity("Internet.bs Domain Sync Run");
    sendAdminNotification("system", "WHMCS Internet.bs Domain Syncronisation Report", $cronreport);
    echo br2nl($cronreport);
    return;
}

# Check if the Module has been activated
if (!$module->isActivated()) {
    $cronreport .= "ERROR: The Internet.bs Registrar Module is not activated.<br>";
    logActivity("Internet.bs Domain Sync Run");
    sendAdminNotification("system", "WHMCS Internet.bs Domain Syncronisation Report", $cronreport);
    echo br2nl($cronreport);
    return;
}

# Prepare API Request
$params = $module->getSettings();

# load the entire account's domain list at IBS
$result = ibs_call($params, "domain/list", [
    "ResponseFormat" => "TEXT",
    "ReturnFields" => "status,expiration,paiduntil"
]);
if ($result["status"] === "FAILURE") {
    $cronreport .= "ERROR: " . $result["message"] . "<br>";
    logActivity("Internet.bs Domain Sync Run");
    sendAdminNotification("system", "WHMCS Internet.bs Domain Syncronisation Report", $cronreport);
    echo br2nl($cronreport);
    return;
}

$result["domaincount"] = (int)$result["domaincount"];
if ($result["domaincount"] === 0) {
    $cronreport .= "ERROR: No domains in the Registrar System but in WHMCS:<br>";
    foreach ($results as $row) {
        $cronreport .= "- " . $row["domain"] . "<br/>";
    }
    logActivity("Internet.bs Domain Sync Run");
    sendAdminNotification("system", "WHMCS Internet.bs Domain Syncronisation Report", $cronreport);
    echo br2nl($cronreport);
    return;
}

# flag: is sync of nextduedate configured
$SyncNextDueDate = trim(strtolower($params["SyncNextDueDate"])) === "on";
$ndddays = (int) WHMCS\Config\Setting::getValue("DomainSyncNextDueDateDays");
$nddseconds = $ndddays * 86400; // days to seconds
$cronreport .= "Sync of Next Due Date: " . ($SyncNextDueDate ? "ON" : "OFF") . "<br>";
$cronreport .= "Number of Days in Advance of Expiry: " . $ndddays . "<br><br>";

$d = toList($result);

# Process Domains with Status matching ACTIVE, PENDING TRANSFER
foreach ($results as $data) {
    $domainname = trim(strtolower($data["domain"]));

    if (!isset($d[$domainname])) {
        $cronreport .= "ERROR: " . $domainname . " -  Domain does not appear in the account at Internet.bs.<br>";
        continue;
    }

    $domaindata = $d[$domainname];

    # sync domain status
    if ($domaindata["status"] === "ok") {
        DB::table("tbldomains")
            ->where("id", $data["id"])
            ->update(["status" => "Active"]);

        if ($data["status"] === "Pending Transfer") {
            logActivity($domainname . " set to active by internet.bs sync script");
            $rs = localAPI("SendEmail", [
                "messagename" => "Domain Transfer Completed",
                "id" => $data["id"],
            ]);
            if ($rs["result"] === "success") {
                $cronreport .= $domainname . " - Transfer confirmation email sent<br>";
            }
        }
    }

    # verify availability of expirydate
    if (is_null($domaindata["expiry"])) { // this is either paiduntil or expiration
        $cronreport .= $domainname . " - No data returned from API.<br>";
        continue;
    }

    $expirydate = date("Y-m-d", $domaindata["expiry"]);
    if ($expirydate === false) {
        $cronreport .= $domainname . " - Unable to convert expiry date to date string.<br>";
        continue;
    }

    # sync expirydate and nextduedate
    $upddata = [
        "expirydate" => $expirydate
    ];
    if ($SyncNextDueDate) {
        $upddata["nextduedate"] = date("Y-m-d", $domaindata["expiry"] - $nddseconds);
    }
    try {
        $dbres = DB::table("tbldomains")
            ->where("id", $data["id"])
            ->update($upddata);
    } catch (Exception $e) {
        $cronreport .= "ERROR: SQL Update failed for " . $domainname . "(" . $e->getMessage() . ")<br>";
        continue;
    }
    if ($dbres === 0) {
        $cronreport .= "In Sync: " . $domainname . ", no changes applied.<br>";
        continue;
    }
    $cronreport .= "Updated " . $domainname . " expiry to " . fromMySQLDate($upddata["expirydate"]) . " (api's " . $domaindata["expirykey"] . ")<br>";
    if ($SyncNextDueDate) {
        $cronreport .= "Updated " . $domainname . " nextduedate to " . fromMySQLDate($upddata["nextduedate"]) . "<br>";
    }
}

echo br2nl($cronreport);
logActivity("Internet.bs Domain Sync Run");
sendAdminNotification("system", "WHMCS Internet.bs Domain Syncronisation Report", $cronreport);

/**
 * gets expiration date from domain list command
 * @param string $data - parsed API Result of Domain/list
 * @return array - associative array having as key the domain name and as value the expiration date
 */
function toList($result)
{
    # Exemplary Response:
    # 'transactid' => '....'
    # 'status' => 'SUCCESS'
    # 'domaincount' => '2'
    # 'domain_0_name' => 'mydomain1.com'
    # 'domain_0_expiration' => '2024/04/24'
    # 'domain_0_status' => 'ok'
    # 'domain_1_name' => 'mydomain2.com'
    # 'domain_1_expiration' => '2024/04/24'
    # 'domain_1_status' => 'ok'
    $tmp = [];

    for ($i = 0; $i < $result["domaincount"]; $i++) {
        $ddat = [
            "expiry" => null,
            "status" => strtolower($result["domain_" . $i . "_status"])
        ];
        foreach (["paiduntil", "expiry"] as $key) {
            $property = "domain_" . $i . "_" . $key;
            if (isset($result[$property])) {
                list($y, $m, $d) = explode("/", $result[$property]);
                if (is_numeric($y) && is_numeric($m) && is_numeric($d)) {
                    $ddat["expiry"] = mktime(0, 0, 0, $m, $d, $y);
                    $ddat["expirykey"] = $key;
                    break;
                }
            }
        }
        $tmp[strtolower($result["domain_" . $i . "_name"])] = $ddat;
        if (isset($result["domain_" . $i . "_punycode"])) {
            $tmp[strtolower($result["domain_" . $i . "_punycode"])] = $ddat;
        }
    }
    return $tmp;
}
