{* Account Balance Widget *}

{if $widgetStatus eq -1}
    <div class="ibs-widget">
        <div class="ibs-widget-notice ibs-widget-notice--danger">
            Please install or upgrade to the latest {$widgetTitle} Registrar Module.
            <span data-toggle="tooltip"
                  title="The {$widgetTitleWithCompany} Registrar Module is regularly maintained, download and documentation available at github."
                  class="glyphicon glyphicon-question-sign"></span>
        </div>
        <a href="{$repoLink}">
            <img src="{$logo}?ts={$currentVersion}" class="ibs-widget-logo" alt="" />
        </a>
    </div>
{else}
    <div class="ibs-widget">
        {if $widgetStatus eq 0}
            <div class="ibs-widget-notice">{$widgetDisableMessage}</div>
        {elseif $widgetStatus eq 1}
            <div class="ibs-widget-head">
                <img src="{$logo}?ts={$currentVersion}" class="ibs-widget-logo" alt="" />
            </div>
            {$balanceHTML}
            <div class="ibs-widget-foot">
                <span class="ibs-widget-version">v{$currentVersion}</span>
            </div>
        {/if}
    </div>
    <script type="text/javascript">
        const {$moduleName} = new BalanceWidget(
            `{$widgetId}`,
            `{$widgetTTL}`,
            `{$widgetExpires}`,
            `{$widgetStatus}`,
            `{$widgetStatusIcon}`,
            `#{$widgetId}BalanceExpires`
        );
        {$moduleName}.mainWidget();
        {if $widgetStatus eq 1 && $refreshRequest eq ""}
            {$moduleName}.ibsStartCounter();
        {/if}
    </script>
{/if}
