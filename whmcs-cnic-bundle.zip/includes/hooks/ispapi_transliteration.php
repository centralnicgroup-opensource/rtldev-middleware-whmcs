<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPufKGvOpzBVPofhMjSBjFtTBBogDkYRnAxEuXUfrWEE1QctbXaBe+sxOx+9+9Jk7DJqcH8Jd
82CTvTgde2ob887CGZwfediD4fb9V99oOhF16b6czlgFrBPJQxdCRDpJqSsz3MDngr+Xp3l0x2sD
6g/BCS/ny5FuYgKzQcrPSlsxt6ivwifpWFJ1tFB0LGS20/FSASu78qtUKQAEspTH8AAquoPLQtXx
UOLpmPj96HI+v5kkHWDEwGjoYnx2dyPMJ5PYDDmkVTjnBd+zj67wAkOr/C9kAPbJ/eDKdZ/mkHyC
AkSr/zqg2YdfcdmzwgrZICaEGt25BttWsEs3/Kt/Qq5NTWYbx9eOSHCn30fTx3dWh/x8Yd6Qnoix
546SiHKrU5JdzSFf9AOtneELt5W1DR6XU277zquMSWCOJ9VZgh4M2AJmnez7v2T6YSsJ9nPeXCLU
4Nl8qPrl0xW5agLoTMwErXgDND1wtR/+14aJRzYcDr9Z2Ur/w3ctLGY5LDWfGttN80z0p7clOq/M
W4jgC1TDgeUwTbvwGfDQEAuviPEebg+T4Vhr/LU2XNQjLb5rIqIeWU52IRTKgC+4AKHNEyNMljGa
3kO8Gqc94U222c+yREVR7EoE7GxClHmr8Io9gMXGBp57zpToHhGW7el+vIqTfqvENXVRfaV2Im8j
NHKxXYGWpsZQKLqWn9qph9/Rr5P4uAap73y8RqKAQ0Nzg5A4BYSKGy04Jr85N8AHFJYtlBADL6kh
rnNv6/6thrix2QbcqwFYYcO987Ud7ZgKrZdCV2duVZEO3n/elh3RU4PNO0xtdr8mJjZLYLcKIeKs
Bffv0DHWQSts5TBd50X3ahB2LBVZL9KdNJ3zFs5Pcnqwzn3m27CHZrDfJDpgL65Dx4inOTM9T61w
97idCNPK0nkfywRdcV4cixJzlJ0EIPRDiZz7OlYaekC5YY5DBWP3BLsIHCpWDlUw5tp1txtvXnaD
hLl/kTi54p1/LRN58YncVdAyfy0DvDeVqJXqgJ8d4MztRQmXE1fUC2NgPMuMMsmBhHiNiBhdwiIJ
fHQYPNhn8mcfqKMjCOP5oi748xeh3HoIie2acfRdNR7CMpDDpiC/v9ppGWQ6HIRx+su0Tc7Vicr0
XcDkmVFl5W1IfWfcBHJ1zI1gRhHaQwKujVZVgfhEV+RZu7+pPX2A7GuB7B68tytPRGXh4TGtSH1p
9KpyRagPCZaYhglevY7ALwNAh2qLCMfId9PVj5m7g2WCxPIafFVHVuTeEsbmrNF92jlsbZ06AnCN
ImuOg5KEFL+tT0IgX1Tj//l1FVIiRCTkeQ+ixYJ7e0fonUnCrbO6VoTKuxUvRbDl38bVNqKx7w71
6xr3negJp1AaNcQF2wF8Rg8uKXztEKkGNrgsCP+g511ZvMndirkTlQ4KjjIWNC3UgEdbhBI1kct4
xRC4l+Ewj/oAmcNc1CZIFa+RSqG1CAMUCWanYkdETAXRjim18kttsa9FId78kIOWLwxi4MT40FmZ
8aA8v/jeallCMQuZ5EY8H0B8bn0FR9R0oP2wiqfnXkri07b9c/FVNF3fyqOJyiMKyfk5dNZSVcVo
G8iZeZ8oBXBpwxXLq2ViOqmeasxe1oAEU5VYmU7Tnz5wULVzNeV6H47hb6036u1nc4mVBA9IIMx4
+1Obk7MIAOqLdfdJMMjLg1OB2mlJ+HvS8DPn87sMSHhp2Lpl8oy+4fdfVuMQzV3uBi7pBsycjKWb
SXTg/6/VCtYB52SKIPymu5yVm2yhCSTu7d/rjCjAEz6/ldBUWWA1GMdu3IqddBAlYKYEQHEx5Mr/
CxIiU7r+96PHNJ2azrnUcPpYZF091bFq0l81SiQNLHPyppMBz3joKRcd3gtdAKgUzgcaxxupwhPq
DJwdz3+BjonDcw9qk3MSifSgLTbmM6zUAUJqyj6yarCb27V8L+JNVZF65HbFfEAiTszbpBDo0bwO
To0OEd6TtBeLIGTIeJcaxGkDfHVAuPbsR0LM1S4wis5nPRvIAvQHq3vhNkT2iGS/5JcUCVjcQOHj
iS6jdX/b7p7RMy0DQoIEM/xdTQCsRa1JNGHH5eQpLLBQLWQsXPvx+sDFMELQHABKdUALNMSf3sSK
1boID6BnDXsLL+ttt5A+yilPVUXwdBkxqEp6qmkZWg+MQRX+hm+7hm2RncL6TwPeSWk7t3fpFXxc
G5916ANgdwYGqtLQUriO/2+/5sjCH9UIZvzl5auJAlXiP00Y6DduDnxtxJUVpnU6QdeOzxFtpAy+
3Ac+JI08vR0PinlTNS9YubAXCWjNcQU7t8F0OOZUiY7Wf13JfQFgujPvGvrg/ICwaXTwqdciCFsO
ISE+VkiEEli4FK6NQke7NDbJbUwwDFwU8cCc/t1t4eAFwZFctDiDQhIXDym5DbkrqJ8J2SQIDWr5
+pgTBU6Tvp6leeSLI2PdDHE1dNe893hiZjTzmqbXJD6jNAD+6ODo6hcNDzYvlvELzqo9mSwtQDgF
Mir4HE3WGUp5p/nEr1owOO5IJfFK1K/Gm3IGcvh/HtlOG3qricGll6ob94BpDAb3X+bv8aqc1Vlt
6y67HyuAYEZUQtMiMYl3KhrbZ1pmp3rJgisvM7p/5nUDfBziHi4E3BAWjJ7c9Oa8sgIuge/U/laV
5zt43lAmsZLqguV5a5Mz5OL9pKvgtfpytXrGCURcmvp6ZZUyNh3f8UmOX9YXyqtpemDuQgI6Xm//
gR0Xs2SQ8MV8QusRU6/rFxQnqfVu4DZ56qRoscJhAjArpio7EX57wK9yTxZoB69eRNbgPJv328JV
ysCTy78CmPE0DkU+WQahmrteTT7Pd+1whg6BDxZpQVBJxpIxHenONcQjZ8HJgjBaUtmL47eIy87A
AcHkSIX4saUUxF/RLvyYz6nsgxP2vazmH+grnIzveiPuS1Ar5z1z1OdL7i62e0Q8Y2T6Qw9pIgdL
PnvVN3q6+cJT7RK68cbeYKaDcgnYNQ5mPCAcPaAtYDphLPAvQp2F1GAkYv4atjXTwF/E9n2yjwms
1CNHLG8adl/f8OZwVZkqXJbF6gb7/eGKvmejFTZ8ZGQkvHPNIULDGodynR5hD1CkmDFjKPZGP0o1
yILWLUX0B80v60cfAM+afPXr4RvScfN+GWrgDx8GSXB746qHUNzWooovnbnHGzkwkvZtKngfkblN
N0JyfGzVGvkJHxtcBHyFn/qXG1r2a5FC3PcoxZgHNxWkChnD492VZoc1qSC1wX6h8Ql4bf7UDpEW
pHkILftc0GtKoiH+qQ4FZ2hIDBrdy+N66odaxZCNgI8baENCJ0BWOG3PAz1450rQDeX4EZqDr8st
ShJ5AoyPX8KenvU92cKwFeIcHLnbX0==