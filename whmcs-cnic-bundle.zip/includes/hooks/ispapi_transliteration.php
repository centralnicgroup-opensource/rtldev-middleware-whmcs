<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvTSITyO3B8GvPBS/F8qoCx7I1tlS7BL38wuncjl3nunkxUTGoa2tvNP+cITD4eiwemlaCbm
7w7sg4hf0ijw0fXnCtIC/S8c0zvJO857gAYjkrd5cgtjspGc7biXbVrV40wKQMD2ub2e7IaVhO1t
bsSZ2AKT2DETFRtB3ffYcmPmnKgPdEuEUmKYsrbuteqcFTjoK02Iuww7YaEeTQ++BE7BxBnsl6On
1Cw4OVsLXUl88DfUTT3sOOeH91Ewz4ll0asKHN4kOM5PifqpQfusWHk/dZ1czv21RHhDfi86eazN
kMW+UZYbrKNfbFIgo5XG4mp/Td7XVYA+Ho0EVQnEn1xf7XiRtZk/BZJSckkebjip3DHD4OaRcrTr
uUlKuQ5LA+Oo5DzaMeOz8OigcBcMVPXdP86YNt8jLvTcyQFCA3kzmooYBmAWCzX+autmRtbl10Qa
cf5wWDoHZrzUflFMdjS2X3tbA2N2yBmkU1EqAiOSAZvBN2NI+EWbrujV77WM0D0ueE5trPIDM90w
+BEN+8QlTUdHSMhmIMhLNxe38MJLx1ZZP4NpGlA5TVk2z9EfGoe3N8ieLB1vTl1v6zZXhCXd194D
rsVt5FPEv+sOzrwbSaYEvAJkK9PRXfngKreXauHRvp8jr1WQ+4Yc/XN5UIjGFOBqEoERdJyTE9Bt
lcSVrdsOgGyFZ3ZYkqeZfmJWBHCz6Z8aZ+KH0suANv6h5T2WUmlNOjKiiaWmd9rIYiAHiwMD6D3v
GAMCJWbP34HdmnhEHvV15GKbcw3dfQzRrlcB61eNb1jeVayC56/fEpNQ2rJ+sOfZE/aeTEPxVk1S
VE3SXZeuKFirpYV9gY3FPgRDs3rDMiu5yIfgYjOlEN6G/E/1abyqzd6/c+AzswI5Pl2s6KmJT46J
fxYXlU+IGjDiwKCv6SfCVQ05JN2gona/KiF/nRD1L3NwHoQaJlcVz4HbmI4szBzQ11xL27oeMVAw
10MF6D9lCBBOeyhfJIrdS8y549mNwgtAf6OwrioHRZQazA3AlJE+Auu6v7FsCF8SRagGKI1CRzF3
EImN39Jc1yxtJ/DUUgLDhvYgYI82HHg5H4dFjb60MRRE8tzlQxSQBFeOH+ptsUdZN1Hxsu3/uCNX
MzmSw6DmlXCj0zbtifW8pMijXNn/pzas77XUBX/1JWtQHT/rT/6m25CMvWhkLf3266+aI6uqAmYE
LFR+AnlResG01YVJAkEbpgtY1zWQCz3pfik3owR2NLD4aZR9P1Wi4i1KkaQw/6sNY77DmS2fcMhe
XyWEL9ZR15nV+KtGQ6Yc5Vs6aRp76YXD1rh/gd5HJp1N9z+KAFmczuvs901D2g4u/vltEjPRkBuH
QNR0FH3l7iFN1d5Jj6VUYBBELk11zk/CUwYRlb6d+aFNemCzUUnafvmCUbg34YRXV7GgIzpXAi9n
RpBM2RUJgtOZkRebVePY6qPYg29N0IBbgJ7j7WBXzggwAGi98x0tFikk1z7get1YuN7Y6HQRtLak
vNUDEMAJrCqueUNAOys4MhAAiWeZ5YxuWUi7Rt/mdzpW7Tbibyi5X4/6H0Xidr4LJoCiEwoI8og4
ZAyPlftVmDewHrknqGtYLF6DgkbPTX0MqRLTA4Az6X38mAg5l7hZQDHwqCjqh8yT/ohh93iAVi9z
8/SslFZrCbN1zZs0QcUZpfdnqrj1vlLn0NMRyytRM7g5rudZbnSpHWPEEt6SBKlt6JM6bKPJOKkk
hRuSO0LYv0jzWXTpgxUrS88bLneffOYhHu+6EhQRNmWgob2OiTHzUlS4dGcuvDJc6T7Zz0KYAFzx
4YYgdwJscs6xNqoUXdekVp+5Y8ajaiXeAdLEbcsTYlqjqIMc3w09p7syrhafzQzvELA0GSvMg3O3
FOHDZacC7wkdsOdjnwEiMesUwtYivY/Khbe9xyif5O9rmCJNClFN36Or7uVMmh3AlvlFyulolfp4
9rTPHQavU8c/BY+kJOVPh2v9fnPq974lW2QmiayUqzSM3+hhhsB5MALZDlekxYZfsF3Eeblq5V+H
rUTR6NNoo6EkBazHUA/FPBCN31c9IJvwagw9yRd1YGytBHFe3NUbHZCVfDAODLvyuzxJ7qUpBKPK
Wv0LUQqbjRiQwIjwM+/+HJ/85KnVL4TwBDw1LSYFrak4fgWkphI5c1KNPTVIZZrhh94686+u9eOh
Cth03T8t8igvlaar1U9KUPl8aUr0+b5z7PPIdKgltWchAhtfdeMmYkq9pld6Db0w77GnVAPK8KcX
7APrTO8rkfsB7sVbYnX0jCZmbFy3nzdIggqqmphoyQm57WINr89prjgAmR81B6kVTzG2TzYJThsx
u2Q8g387kOutEFV8cVY/9ZKgRfJG2O1l7x80eewcND+Un97Lzdy//6I8EpZxjkRuwHysMweIDK0V
NoDYM1JPJ9nFcqzgLFmXW7ukay402nmIYJMtOPWFehRBmelM9x9Z+LFCFharELyInOBwPbAqlrpU
6ybaTIwOhKHD8lYBwG1W1WcRpChHvOPQ8ATq1aJbSwYoWMPfPjpPgu2ALnbgOBghm/+U+pDVN13H
mRr+nSjRmfyeCWjWkUnz3zQc3u0J1bmuttfwxypBdbotLpd1/hLTJhj+cnUvPZ7TZrY9ZFufqrUb
NxguPSU0r930IifisoOtmDxNB0I5llyLvhENGKMoEtpPCqA7j3RYUfEMDraOQ10eWBmNib0arTvc
BtwXMRHVliWS686V2NsAtwHZMfQ1661T+cQ9YjIlU4s4NvXJsrMF1F5VSo+BeVNrYfStFUoQm1gs
SvzNGNB5Y5hSGhQn+QmT6Mo0vuDpiPLst9qkaDzW/2v2NTX8c1GiNnhF8AIsoaHpP6St/alZCpjQ
NrQfghZGrF1KeOg+vBDsD+gaVuelKC2ho4Q1OhwKLXAwifflLvYiTgWu90AVv52+xB+UOpyi96cb
qzkt8ojxFqQAsjPixbFCaMBUsQtBiVtICACR2BfcXqC3SrAwjzZOfd+Vxmymy9NUysFDmA2/WTmp
667ejGjF0Il5Gjhd43UJbhH2q4UHNYwdQTpkdosXmbmhy6lrOK79LIaohauBn8HjQHxf7k9PsM0e
QieFkXbgGg1zUf4j17Do8eSKAnPiZgtCSrPVWHw0HSbTfx4PJnjo+mSgevsX585YNmbW+sVKhedD
Bl+V7MHKNsUi+pWSxpTdPCUnYCCGphBtbxihed1doMsxCvozD/Zp6RhVS41jg5wIqWJ2fDHl/zZd
1eGhmZKb30QPrtiqgMKgTreVFt3MRmxjV+1edUIxflb9XFmkCrSrDi5DmQyLYCViC3/vHaHHKBGN
emsLLYyIaDoyNtxzGmWQCboJWvL8h4F6A/CzJ7mK/AemVGQi