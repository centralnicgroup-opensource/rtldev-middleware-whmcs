<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpaixHs/lzLIHk9uFWmfs9VY6Rfqnhzd0EgoAc1tDra3Unzypd3rvegI3LpE76juY4o9nMKc
SxSzC6czoH6HhVI3BosHj4ia7n1qeffdhrLPzj1TfzK6Gb3d/TaVHMuwvDvUqzbgPQDBmrZSKDby
1iXCI+oNz+pE+qN7EaiXnELNNQ0nsPuccbB/eS03olepmHp1UKQnKA0BhAEHrufVQ4MonbSH7VDa
ZH4XdawpCntxISnj++NRZnqTXGPBPVUGsgLAdpbbxBQcJa0XCx05ZWaqc+3RQ6fO+H1JIYHf+EVH
np+eG6GPhKDDcaXaf2WTxR9fOOc/LFg9br+/CMtZ88av9xbKj+BSla9aab+u/KnwbVCLA5tIMvgF
xtYZ7yvCVB4kTCkMmNL6ushkZWeFrZYHOXKjzjK0kDXuAvvFUXbQLbpE8b/kPhPuWCSe7WPXlCIr
ur3N/pjnRe+Cr/qn7dyfOQa6wzPpOmpX+OZ3Ia9wgAslPOo+4K3O1K49dBbSgKqxKp/7oMP4IPvT
RDlL/TEHtX9scXAB7yQ9CawhIY+4daYMYzcL4RxmVK4qTrwVVusATM4uKuFbK+0RG1IWSSXJc2aV
wZwoaS5qZ0ebAYZMq80c8tvTsB21GpgcXj3XJflWSjIJkXXxqubyrODPmcz7ZtqCHLHvuFUc0tmC
NapHoIxIBhKWZiLfY7jRt111PhHk7omnHnUOiLhFN5462n1QMFLvafEMVr2mCjhNy+wc/6Q20PjC
EXJMDPmpc6bmnaVNg84YoCJomToVd9gxmPL0MyY8G72J7O9oOWy1kZDgx1phscN0L2oJFRRAonEO
yj09TjUcEU/e6pVTMUPytg4ChxtcpkxqiGXIjdFZqmBoiVdbIPzgwYKmMCYpXBs4FnEyBSZiqtBr
54tkDSL+CwKDcQvHErx1Si60XzkIRXQjJ9yh7sVRTXGtA0BjKm7d/NFmR2mNwrkzJwsgWSqDJHEH
M5JQ7dnaEQy88DovvWgSBW4RQFaf/oRep1IUnZfQyEt6ZnAS8VT8O9cNxpFZmnWw6J1P8Xyp+sO4
r1VXlesXTdUkHJREvS9nmgfU2lRKfB+G/3Onc/V/b7NphXgsnB/rM/OW1vmo/F42V6EiVG2+uSmd
8sg2cre0TXqOi/PJR9me/CQmBlm1fBLNC8o5JMfN7OZi77SbQO84xTYbAkjz1eYbJpLy1zUZzbrE
Hrubukc26OKaH6C1ednazqB2Ts8q/9PdLxzBQZkPnhaoD9marXCaL2I5mSdm5D3vdMmK7NF9UW6H
VTuUZRa6q1xTknvTXeFWeY322gaoAlg1urPURrwn2VVXZ0Rb0pzSVxY8M0C5TjbyDNyn/o6VCgJ7
C8eQpgk7kL/1iRUp6xcmru9UNkkLTVwdgAR46uX1Za2mUwOOqVxkVi+MHd1O1elgQL4OiCErRg/K
Wc3v3eA0Lp+degr8BK2ZNuToIN9a7MxGYHkcE76q54M0c+Ui30eZeGqOGlekg8qjtHDVXrL3WQoe
k+9GseNzELJ6k+TNacR94I1qixwO75q6GDcTpJX9RIIi48JGT9MAzgu+8d/HmntX5rskCgX0YQwW
h3+x1AjyO9F4EQcpFMofjmvx+Km9pGWPUMtL3MikmAuYYfiwa2Q7u1oy9sl6y1qT6x9Ch6jYMOcf
SGTxqMG3S0/DkjSEmjJdbIS/JV2GKm//BbnRgy6Wh8Ii9TolfGNqb7rAEed9mbeIX0MrIMTau7fP
V1AQqKWHPtBwo61hiHVeN/4ze0pAEZfEckxNfBHZZuSwfa68Bsx7y//o0VpRmTa+qs4SaQ6vNFah
EJAOdsmeiPGgbjhAmXp+z2iGoUltYyaLWihZzdTNBejClWk5EAGr4807B5sugB9OLhGWZsjGUk/A
pMMirV/ehnMJ+m8/6NCpcWYt5/TEZG4K0wEiT9cAug9ieDuWg12muAIXHPJMHUAuuS+LgGDmqjYM
xkW7pnAdv1PMGSr1spFqQyXTo+reGeKleJhdyEL9Q6RYxyVT9IvlHEN08j4fb/+0ILoU6K1gwjHa
mxxf6lTBf4ooKmp2yUnlMhax6OfB/9eRsh9W8Qgjtb8T2Hy1r1nMTOEX7O0sboZJasqYuOF1RGKu
d0qMcOXQcMcj0Px28JZGzXYbxik6uL0+IEIgOqYvLLc3pQ1bMfuv321bSL1S3ULa7ggvkCnYPDQy
8OLFBbdoq1fzMH/9wBqJAL/nDyzr4QcANwzzk5JuxO/NETz5VToNxPWPTeXglK19ix5Y1BPU/PUI
hg7iGrnnAe6DXHfmDhKTGZNsue00gPF4x6uZU0k/o2rdKGGWittc26IoufOcgffSDWv1ctfeSHnl
gpwce0/NnfOT1HMUG1Gg8M703MKrh+Ym7f8bzem1hFSN/yS5eV2VFb4qDbEa7MCebX/JfZencXUQ
pcFB/i83f7WjZ0NC3fcqrFJEf12a8Q4D651dGvOQ7k/J0JK3JDgci1rSU9rH1LJpX+7hRU2mYePF
TlihcFG1RuviNdw0QOTMS8fKVGVlUkx0qDbyAHHnUUIG1ivsrFl9u9NYljIx2U5EaBhRcY+GNr/v
f36gDGfi5AyaQB3bCBlmkn3jn0+l0sBNQbrDveYbJv/aOU4gVoelJGYPRHZZYnHUZYeb7P9mTX+q
OKj6AJeHZqd5X8NcHnGdr54Pjzlh0Q3epj+eQ16T+FTKlORxBUT5x3ggCF2iFHXJykFtyHrJTyNX
A9/1FZlmQvzcO3UG0fo1xwko/juhXQMdaCJAdxl3yUglaPAbo/ESGhZp14rIZZYkBB1Eug7vxaH0
96KWzX8EMX2ysbqXKVhMwA9aetezYRYbYRqiVr7L3B5LYugJgK7KKURBOlFPEZSlG3c8gaSmvqjs
rjNa3n3sdnhUoaIK80CBoBzufzZe5AhKTnnThOKqNjrXzBroUpHwDpgk6Zk1oTFowU19pZ2sxWLi
hFgI7EouHwyNnoR3v/Qph7AzXDxGIZlbv6F7iihAwyQxyEbVNsds28THLzduH5UzhEF478Vzg+pI
BWQU8o7mz4elPJAOvgPmVMgicwnb3dHmSfL2C4JV8vq+kW6WFj8toxbeOfyJ6GR/wF/gvaPMrSNJ
JcXdxKBkoqK0B0T4uWZK1l60wsZ5rl6IcVJsk8lMDQc1THF29O5WLhOqbtkpZMb+nBB+ZwnPHOFt
TMT+5GYTxBUEqFjDe3JYJYDHxA3y5NuRvNJpr9Y6EZN8HTZOtPP11Z6k3wOjIWfbRw7vMsDHaT6k
icbCpLuViSkmc5BE1P1KMrZ9MFx1qf6C5iYXFWQcqLX5B/aRW4O4SDxpPoy8GpG6FVkGwh1eDpbJ
6156HQtTScDJ/rFVg3yVnTnZ2R6my7wklW==