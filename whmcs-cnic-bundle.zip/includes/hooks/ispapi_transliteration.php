<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtOPRaCgor9rCzVxOFzTa87EMAaQMc+VrSuDBPnFyfPlDINCdlTV+D8Ryhf7Cj8c9Yu8BKZu
WyHROjDf+ssujp+E2HSjs5oBsVrRHhZBVY+R2UV67He4W+GsI+kXeu8AQdoEMforN2Ae/DdaA+5L
h6kQNxnydzG2vFW0IRYgdvZkC02upBAPhtC3r9xx9DulBQYakv6xnOUsAfz4VhjAXbVHPR4nY+U4
aFZouDVaL0Lqc85I/MdujUvilPF7gl0nOLXgFzl4DJgg0hYnXGO+Hr+xtZBlgnPmVw2+f+E79xNY
UjkM3CWC+YYJPLbA23YTvmhFqfjb3I7JUBzidyFXqRut6UxZ8iqqKiDZZshtVrusQ+uPG1zpTnaX
rfM5rHZYXASCHAdGrTdU5UQF6DlaOd/CrDDi3MS5OkqpsXO55EJ7SRGHBmi9nH1LvIwFXOlBEz/E
GFEYYGS1Faw3YPoL8J99DHqDnRT7Qi7arUb/7+LW/fitS4WsaLZr/rLP87fCektvBncezZed+/eE
JM7hsqglo1eV3BG3Qb7FWJYZJe/RQ1UNAYUEHbSzvhqc/RCzf3LaZyw1c4tNbvLdbmOg79Hw6SxO
zM5ZrmPaI3lROc8+TqFhGr0IWCQl3d84eDSShxYC5me4426qyXPAlBbMfRuBA9CldVdWxK3zuhy5
1ZS23Zkdq6C1P7ZjSmPxAYB9kx2lkyjv/lfiZUc4I9jFkMntmHScqoMgztxFXjWVFHOIxSBmt+oM
p6MqSVg41yco5LsZ0lFKCiTXn9PmqXF5cWmcWQMuMtUhtCkt0VT+uzdneEEckdjA3YbjMmvfGh/v
g1M0UPRZfPVFUs8mRV8N0dJgEhUesJd9vscYO/2bNlfi1VyNcfdGx0zxFf4kBt33y0ACDYCI2h66
0JCorREu5Hd1ZCSOJ6n8Rzq38eZIp8xayfhPKMJldthQEXxOK7gdlaHVc3Hjp8TMdt99CD7BudBb
zuu4nnWpX/dtQI8f3lzpU1rK2ZFJ2dCcWCgOA69J1MHSwI6rclHGYs3VcKH0u8rYmJs8j7yiIPtQ
YMWmVLN3p90kTajiqSZA+N+AFi3Vi08K+hNu5PLnqXhCxmBrKCMR8Wm0TaP3hjvABU3PB1G/R2wU
OufWiEjHO9JWKvV6XW3IuNxTafX5W6SfFxnl+axT45JNSCTq4sIytngllLnhIK9FEgrjNS9DDPRR
U5gZVmMPrlSlwUqMy8VnrOdCRlkuZPKi6wmk2fw4Oy3Nv6KZC79XlwSo6gkIdYInaP/GFRmKg19K
s9iVDMGxhj43YIXxRXkwqWnumUVGLAY+ToTQchF3TMaoywvYAvg/dNLv/xsgbKcpMLUBiH+QTo//
1+4M0JsBsHZpuUIqNLV8Np6sCGkX7maIYXDa4sSfR5toB3FDavGuYUzzwLtXdl9RKyPo+Xul5a0l
3IgztxIjLQ7dsXDu6g0P/e2sKOOL4FrYeMhdZgHGOkFpzNOU0RKvqlty5dvkee6RiCVL63eJkTLD
hOl5J6EavYy0LTIriZOZXw81S43O+D7o66f8OdUcgLsNq+ZmGe7QvJMkMTjWtBYxwYfqce4ssaBu
yR6lncGYoGC/ur4D4eYWDMUxlzb6YQ4B2n7+qVmTlvHTnjXk9+uE9VTqFS2rQIjZq6b2ol1mgVpt
/t+XqAXXhqVrXylQZ7//HkmdUvDZsT6GRi33G5Dkp2eSY6YSBLxTXauYLOnTrCur41Mbes2jGZB3
2iSNnoH3sF1Osn//pGx4jLOF+D2vQPs45OnE/bvjkgrHzDWBDy7PMjfSaMArIXBK7MJLg1ri0qD9
/+wSaDPdJE5kb5jVNPCw7JAwyVyGyGhzDLHKjdk5Hh7qskJVex/BpOHQGAx3XT7nss9454dumoH8
+4eKMs9/LumnZysfKuOSwR1lsUKGRgGoMsAfqxKXkhNTvlIfuVO/NtIrxPsHvKLLtHtWn9mY8Ces
POqTpc0dQr9OSIX20kGbtaE/4drrqakki9iFzM0cP2hTJT8uACSoAANtA8ke+a2Lh892ArYKXwsW
pTmz/zWB7H8AbIVYk0DNU+GvRwy9R0J//bELQ47SGxwvV/oEuA6ZRn1+wmqbbiASr/MGx266Tap3
Ht95H5uu/wz1uQ7Du2sfIJLiuSKphyrCiPgz8S84JDf1lAQKp0xRE1LpTSJZgtnND17zm59xkgFb
VtVbgvpHjG3x9WwtYD08S+REDJBOiDrmVLfx1a4mMKHhKb8Q/Is/NFsEIXSUyNo6N+rrlgMGCX30
VZChWLObMHXeyXOjKa6jz5Uq/8kyblV18S8n2129nNZooBknz96wwTmHzK2GUAWEmHZ7I7QJYlmx
zY+zMUcOdbGsramaWKIFAcyKxhS/v1Jg6bu9sTfanuOE7H3cJ3zF8qTMv+2ANiB8OA/0xs3AV/dS
bXDKZ/UnoLn+BERHy+KAIgzubrrDiFQU0uSCb5X20WxyNUvNuzcTNAZODPdeIc/zACYx6s5oB4pZ
EkdKsr7HIgeXQoPbnS+V5STarVKPOiidksYGScMxW3A1/EUvjmjyiyYmLMTlQvYgXYT5YWvyaXhd
kDVYHztF4CAH2iMA4etdR9OVuJIP9gb80qTMtkxomefGCUigbsR1zUhScA2CBBklnJC+hWGtTFEr
kGrwPovjxUy4gEWrqd0xHwY2adyrUESJZGSO0RYKOMiGUMn75z4IGhzzr8z4HLNRdmN/Pfn2jAe9
gxlRJRDC1yBFXKBhBxaVp5bm5/eIvtbjJfQG7a2MPWmrLN0+PIEzWM2FhVSzxcZwAGKnBdS1Gw3p
6pudEdrv3RdVNHzv5ioJGPNUZwtqyJ1q/OQ9ok8H68XlAS/QGrG6XrTg/qQdfXMRFqdiaXr5LuFU
9yJr2Urlo8qQDMSVtFd4vUltkxGq3+vPdsw+g7H4AYvP13Jor1w8hlLDeRUZnQ1Rzr2L/1F71tXb
MFuqJ3fnEDzgkuXsjvZprelPNGS8oSf4Zz2K5Yjla0eXSWE9Dpj9+ps4BcQ/va25bwJY9aamz2y0
FtB5iasM9rORA2+YiBfS5zLDDY5RC46PyhAmxJFipSqmDJAW96phAJaYlQlhoNTi9VyIaV7ZW+Ac
pPZoRrGBc7GZvVmbwO99vI+M6wIwxEavV0H4BfIc4v2/CPHEPFu86sAPVF+uDyqLQxnjuLLqdUMf
X4z/78sEabZ083aYEjB3BwAvtYaS5o9CURJ+BeojXEz0Hm2zuaj4Hx4ZkeWd4Q56ulyHqsjqf/l4
oR4OUEVdqzKkl/wExGOEouzivKqiZTY/25WNcSJ+J+iWGUhtx95RYjFmgrLNVkUjaJ3ZIkRYik2w
Ok7iwIRw6w+3q7epaJ+iNeJO/W==