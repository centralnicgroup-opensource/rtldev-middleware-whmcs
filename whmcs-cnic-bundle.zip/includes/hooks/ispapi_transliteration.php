<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyuGxf7DiDAcYDvxifO50U5YO8CQ27qkR9cureH0n9gDb/6KEllmdBdgz5dtqBtUu09ckw0O
Ra7ECAokoJRkUBwMxeNv0ePf2Taw90u67gyacDDk6d+fCC2OEhZsGu4EB6a709CuEoPmsbbI2ntD
Io9q7J6AH5OGFjK9n+1+Gp9mDcsApvtGl0FrJQZ5HNm0M59nVjXdwuh72bzaDgo51to6S4Z32uEM
ApeABjcVhUySsY+kemUJ0tiDBELhNnczq3qx38PGOQjJKu8SAFAUjXXANTTXdWCjvaYCJDJ79zXs
4MSo/ofaeuzwLvSVL4XGTLlpbeKUelUXR4VXTteTP1QgoNKfCU2BuWvnT85kTjybIq7dwrf2kzAr
jHsuRHxbOOUzrqL27NHkMKrc14ujQEw2IP8g7Lw1YoOHe0jBviPwhERnXc6TH6Qq3LhiUhJiS86/
IM+NZyS9EBWAdAQM87pSHgoA6hZZv1AxYFg30+4pPcl3vQYltD2erIwrkK9FtWL+hgUQOOLGwKEH
Y4nSR+wPmY13iGmLEmCuCWVQzQfIQSpcdG2E9bQWuCoAgd/89gxsXsafy7rdcF5Go6RomCXPItmo
nae58LeLX/biQkoiYDAAAtHEqNsLJ9uDBOijnsVRCZe3+kDXcj8Y+yaF+ku+LQS2MmOrsr2tqPYO
vZYho9UNDENjqiqO6+wENf04JxTFWOiWqyxn9A13SJNQoxBR4G9itz/Oa1mgVhJxXeFAhwJi65XN
tl7hSm8v9zEsCgo0oVJC19kcrlC8OnlOCkmXBqf07FImS4XJ1uJMrDLXhsuFwiLuI17Sq+RCDpRt
jyGf6dd83bye8hDpJeUVS2n4K1kxllLxaNc6JTkhWAuLevqnjJlmdJ8DqB5kXF7OxCuuE9P9+E27
du/dTk43Saq3QdR0ycLyH65Er/pmXzmXCtEzAh0BIaK6Cgt0g7Ig+Df2mPlJGSZJH1neP6ilK48J
OY1ioFUPQLLGZjJkOL7mLIDA/pZOYCZlo5+y8vEyhc0+iQdyWg6F4mDWWgXrDRZW5+yi9XLKJcLg
wsHGUNABlJztxv/z+yl4dQvx31EvMrjYWLl7XMpsV59pBwpKYRK/UlGPpHomsQd+TobOtHKPnujN
wRhPjui8nDnTPjT0LElg1dWBOu9+4HKABUqmRtehQaJqHnDOc/P9FkXCHt4gzCSwtd+QLTKFQz1Y
Hkc8H+r8qyxEZk6we7Ey99Sn0kWXYGFzeN7I++gYwzd7sPW7HpWb9/V2ERatzsozdrOiBWBLkthz
nCrm/MFBu5bmDfqJnd04M2tiVI9TQxRli1jIu3ykckjsGbR2thyTey1W/ui1YB9JN2hEdn4K+yR8
r2gUn8X7diR6UKeP3o+JbbcmewEGW/n4/TebXH8T0Zkh0w2KLghSjeFjNu+m5akcnKtx8Xh+/2TY
ADcGId4z/JQ/lx4h2WQ1BVT1WEwUBoHlDUO1AMfAkOGCzS1G5Z/W0Wtr13E7uHzbJS1YXEY69/Rb
emmNgUWlZ/ipvqflvuD5M8CAQ+czSGxASgQ3gXEv4EmMNxIlghqT1/cmGVX0WuQmcrwMbXZpVGZG
bBPZCDi42N5+XFpYLTunPmMlLrRs8Zz5KSVWkoj4ua1Xx2DD/Nr+HiwXult8iWI+nO956F0hzTP9
WQ/uaCI0/3u1+O0eILB/xx5mrtrdzNoqwEP5cD2GYnUwCj+4gMmd58eb742o+xoRNPer0wqiB4bs
6zpCvfd/vV9QnkhzWcNUOQDRMBKrONOdEKX/EQ4GYAYkl3BwSPj/Ha7+UXxIxoy1EHs26rDu/lTU
seZfyj8zpylyoYWoBqihjjjC7GSJd0V69YnGRA6tk1ApQrCJORZAy6IHLfvOrK3gIBopCrktfET6
KHFJ3sxuZEyHepAXGCRWPdvcn8C9DwtrjdDch/d8JlQg5dqDHN9VWc0TcRSMa7DjLxMZjMpxxoPt
0RWmLCIhTvZLjLcbJbmVWJlFJDt1k4YymvV23pibkooXE4PthxrZgGDlJCtHmU+uJuytHO3Qxmxe
+s8mzBNlOcNO1cZ2QynzbKjk12SzeYraYbk8GgG1bDTXMukIfAJ1SGXdh9OBEpfK0WgfY/4hieWe
O/dvi2bkNfdNdvAR3lmzPITxN9dRp6Lm+uf34fKfMQ1dtfAENSmIMZigdG1bHUHpx7eVtcKG/IjO
BnAgM4nJFfPS9oAxUlKvNn+1B27lSqqHUrM46/yDM2ifyQfvXVW+RPKciAEgv8oFDuzSw3Vm+AX3
PGAFiSa1I8tkoIR9w53zhPHyAYyOZ5jXCUTSz0y6VGo2OyvL4PF/coaFe2yfiM9H2bb2NAHdSpzC
HgYz8+zRTKlNOd/0KmFZmxyBEwrFh/uu19O2Hk2vwAPSZ0sjyc6WFrG5B3B7RYHQz0eaqvdKNutB
MB/dkoXcO2AWi8MSfyLHs7IBND7VYpj6muVyjWdMLgbxzr2rae4JFjWoekCEj+7TVP/SGC/4tP7R
+Jr3IgXGYl01d9ErawXatQJDRnTPdVqM1RWRBLxLkHloEuWQq70jH0J+Fda6YOGtt1P1a+XquK0F
TOYeh7lO9btPTZaXWO0XUQpzkfAQ1g6hHEj+xiucGRaEgnEQqselJ+WdePbtxg2pZiokWdZtQaXy
UU5/wIT5r3rVEIjFB2eTr6QsplxizcjOyu6IUidfy098mqE2owT3GrGAUe5ek2hB+ozAnLizivCi
T0MfyN8wjOuQhUaBNKTwEna0TmE/VEWjCGxraK/19DA9tgcjIvpXQDChMo0W4/llrtJ+JE/TGMhC
7v42GS93p/Z6x46FWMUq9s8sESNpNAjsB/t5aUMpwOWqyZQ8xlYaKLWpkSfK5cQdhnmdjZqn7Skp
VEUilTclWYFiPtpVZcizXlwaa+Cq3DnqHkGZA2O8TnyxSa3QNoaRCYaf4qcOCl6keZaaloagtTfi
otXrBx4DTE9oX6F57xap8XMVyBTAymrTPsGW7A1PEJ0TpQvpzsyZyjHRZYJ9uZZX8u4dPfCY2brQ
Zwuzxs6gHTGWyNPW2cZUNdrZfqRNLZBYPzL5rwCBPqifkjt7Y786gQOQF+1SvDVr2GJS2azsNc8U
porjUwbffvYb91JUpXZCmpTPYkH7qLj/HmH3B8478EQZfcSWI4FjHQ5tG48hdS0MtB5YqDs3RJwQ
QhrgcRLyJov5yzqRIdQmGAGfmud37Ac22on6tGYcFIrftKXfe3kcZn/7sUuOm06e9ZN9T5yTnvnA
x+a4NbdT2GXeQvV4qY4mOclGGKkb4PrF28RpOZ49eT55G1dK4Fgta/5/utv2Ja91e4F9uC6UaICk
u7/i2bPF6U4ICAIrxc/eG0==