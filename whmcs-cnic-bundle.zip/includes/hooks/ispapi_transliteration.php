<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+qR4mtLoUSYeDM6BgPhjAvg7VPY3k4UjTOg8iS7sdcXAFEFJ+aCPFkJBKRhmaVyUZSR0naH
83z+8E0l7z9BrgZZBIQnW8rhipBAMD2s0KxNimY39EwP6fEyLugoOj2HTYsE8dJ3hkP1xTmQ8i9L
KBrgRtA4AL454syY1e7CvmTQPx2lNXjfc4pcOvUEuP8WHt9W5fr3LAhQxPxO9bbEYmtF9x2lpEm6
a7nrcIkAVtfPDSjmc5aLnjDxUK5xyHPNiHMcYky2x7U8xd4B1xuoCNY/8vswOn+6K2FLfzEkssa9
WTFcEFyARaAm+Z0ZkQ9yUM99wdL9fJTH772WefqBVkU302I7r/r9e4MRZ+Q7oHsQ4iGXjhjaA9NC
LMXNe1LhNcEf6yRHbI05YPE9oEeMkF7/v0LWmegmuhuTgG1XRfnyAQNee4IY3YArSR7ZB01cf011
94FmTc52c+vdZJVIxPaPZrDpN7czKqJ8l5OoQ5RK/HG8DgNMJjyzrezHoeVl/IWCTDol6Y9IzTwE
eENMHdNzKNtvYCA6FdcJPF1vyeNmB3+TxFiY/BxvD3ZtjiqFoSscBCjajjnpLLVTc0fgH3AtuVh8
ZBoyL0XLX2oxsLl2LpLFycUMVsbKrviKtpLtnE2AG5TRcfnGX6y8t1r0LeH3G013H/I/fGMlqb5R
2+QzMkUVjOAJetWhcsneFKVgkzq46OJ5j55bSXtLHU8edk/im0jFDe5QqWQ5oNJ6enyfh5WaMyGg
9OgZISRwVbV9K4xd9juf/MN0ljoSJjUP1P+keAEPgy5XzJc+ZTDn79b1dm6nXVIt0b3+rY//lxe6
KNs3okrHg+7wJKjoFoBeZLsRn9F4A4q/gZFBGnAuU2NvM4NfjERHFiH0AwB85e18+MCm8AWczN4v
JBDs8X+FgeVBOj39wUfoWMv2D/C6nSpXTOSttT8a9xDqOe1xGFyYkr1CDuXpAHKk9Ce59xULRCIY
Et8amipWBT0SagLs/+B6ptCORK5PjEmmnXiZ6XNVrFnf4wYBUCGqZRXXjcXSJgopkv8gCFP8qmb2
AGJReYiOOlDakmOnloxHcRxxhtgcKyLjeeSZEG/L/nVse6ldgN7Zn1rjY+46cYrahFtxcfl4gzJr
Guwq+zSpKFu72xg4ipPF75pEYZscxx6++Q3R+6gduMR+y67o6ttn1lbUSulzaGTVVdmwBE2jnO4M
p0A5Fctvs/oIn/+CKy38xg0tcyxk6xIPbeqkmv/gEBHKkrrri8lWU8Js1QCYxtH7z2b8IPMua+VF
uDdep73Up428FquAgZjfDXDFyzhga//daXYIFtdQjFlcT54nGmymXKV/lEkCh1c+h5tHEcG9CJbn
G7emFqQgkKcpsU/rwdfemuaptUPG9FxHZLAV0CzBOcnJIyPB2a9KoxQg2uEFWz18iSK4dEfAxRA+
hLxjK3L7zUH4ani/O5O0qTDmSYLLJsoPE2ddatQRcv/fPs51blV1GJWvYpV9folLtHlOvfeTpfcZ
0LhbGPEWwz/LIcUXk5cJeN0wOOWw2mN2YGZlg9EUHvBhlWxTfCMk8apJH+e0CDG9P6BvDfpmjhY0
k+s8BpjMkyfrQrFYgS32U/d0ARqxbhLjUUu9MKWgjE5tczVKY2T7Ft81Q8BzbK9SwU7lqFndpO7M
B7PJTio3QoNhkbT3UF+w11wb0n7NaY6REV8gqOJUXFZvWtJLQUZjSWI76eXuf6EGyPCBRchdj64T
rqo+GiOGJEE7UWKp2AwXHmbawMAOqU5nfm2YKj5/0kUWYQbgspw4rhVURveHWCqUhVcl7R9v2lLW
ByLjDzVaMzDrxSbGXyatqCBHk876TerW+F5U5pMA3pqKfHCNWvly6+QOjXF0rNzUopk0wTghtPUF
6W/dkrVMw8jhQcSeQTuTGKNCAt32LT7uK01Ux76OSVU25PMzz0rX4CaZmZ09jALhVz0IRJjFxqiF
4YvSkHuTpMJN0JElnPMdsM6JSkaLycuEV/38mpEIIU4w1z0Adds56l5z/vqo0y9YBTT0TPcUye/g
Y+eTyFscdPrcosHlWZAw7DIDVYfdpGimN2mPESkDEMIHEBPxDxA8LmwFYghy3tafAnvzGQN64F+d
TyjHu2lVgnB13mV4PEGfcyuTI0QyrhW2TcAGrnLeQzXRKzundDlansJow5o6n1R2GXcRuvcS0JJa
4LNNxfLKc40Ibn7+/4yVX4+jnZ6R5iLT75XuGz1NL0b+fCs0/tbN4HjCRTKVSHmBmUvGpjLh+9N/
m09J/ZHvXsBlhqwNcKT2qIQeprarPf9QnpdS+qsJgxMIvthhd7/51BRAUuKkGAjBHiUcQa4Vg/aN
CaSIxlbrPtnnpTqLJqXWBIx6Wx63O22jUIfkS6TL1VWgPpwBZwQdzYyzKLntCNxlFl9PGDHf9mkG
eLtpixxlyZOAt7kaEahjfugQ4wtNcQRoSolEAigWd/qFgFoS0/Phfkb99UlWYs9Dp75E80MkYA4Y
dksf5JiHJLISN8FZ08ww0wgAOHt0bId4k5bIhZcXPmxEHggpZZqzfTphhXYqyQO8xhqqGku9HnzP
4vtmWoPbr0gv+XggA78uezheH6tPZw3VX3T4W0KjR0dMRUGMzqgSCE2Q1vhlrKKOYMxx0UsFVebm
DNTHhbPb9LdNnAlebgQ8Uo0lRdGGSVkm3+yqBkKVrwMCED6Gbiua7JuJHPylCaDjR23S9KBjDagr
lwXfZ4C/yGJtSN1/WalT1xPa+SmVvjfzbZI7G668OVE8FkR4/zqtp7yN60QuJc+piR3P7qy31foK
aeetkog8f6dHDL18A1IoqeLoPYLOlM775bu4lZPuTh6raautuPzUX6IDfCC/B8W7xF2akOy1DXbF
dxQcDXFqNa/YUGiul5G7rBhXo0Y//ED+KGVZflYSrbLbjeidOFrtAq0fp3f0xdK+zh5XGSENklh8
GPi+kMtgn8WR60WlgW2zuaHaOTENJXBNvGqGBTmnETLHTagIB3gChAdTnMUam+pC5NogCMKO4Tje
r6+BzdPx7017prSVV6fswxn0BfLmr3yaOmZcwRcUuqNcDxfoMZCGZShqvxGpYemjWiBP603YjizK
i6AoSKYrIxvP+94tv9R14GrFZipJ5dQUmIoaIJUEObSMa2VlxZ5YYvrI39hLfVrhWEeY8PwwAQYR
j669klhRoPjX2ngjyE2a+Ce40RbmhXg8mpNcLBzYccQpgQUK5r6scWS4eOlpG8G//6ffds0w0M3Q
Bpu7+jdGinIB8RreRF5UTNvCBqmDP9CVTvZbKSyjcNEis/gKw+icLXDoipuOOdTzn4To2ZdzCzae
jhq1JL1eln25yPu=