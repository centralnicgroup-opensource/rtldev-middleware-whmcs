<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuEsE1BdAe4b/dYjCUhrO4+WLxLqwAJNyD1r9qMjJm6ldycd3MCqqch0qXVqqAFGCZeMOJ3v
kOkCg2EqK880QdN8IE4c346X8nfcLD7Z6lGsZBTSHCOIhsJW2jTnHHZMw9xTWZ1CP5Nfv1dSguOJ
isN07dlS87cHaAQUqkjCWJq1ZyUY5JYDdqXdfvyHtmXA/psqcEllMUCOnbXSjYu+vVwe1aG9aYw5
zsYFhYNecxFaorhg69EkUR1Eg5XXzpCjdhKZ8iytrYTFH2WdZHMqjmIbhYUPOcauYK/cqNFOrelQ
Tp6QforexQxlNrXyXkA8vlvj5mC4reGINQnbODuYWTC1qWdXfFx+7BPYwRFYWng4zoiP7x0bKbnk
UboSjQ/M8F7kbyTnyL4G4C/ILDzbORamhg3MKviJT+C0c4EagoydHjHYDWA+vekSbY70vu2DpXXZ
bomODIzbkxr2sThQYarUxrWeKVuQMYSWTkR+pizmHS4qeqYRw2IMJ5Y0klJrrKtbBNx6utSTn7sx
9sQdJUpzFI0dPqRPs6Hqn1ClvwhKKs5g2PocmoFUg8/jfr9veqeB5Iclc1rsC4dP5kngfqru2rGO
UqseLWZJHFBzMvrVz0QVlIKB8MhXEXLSIrSv4yiOkL1qmPPU4vOR5m4RTWLfxUsA2fOdKPqrxDjr
lR7NbWz6PZGF1KYNJlfLo3rTiA/qELglh5ST1lMUiUZrnych8QthdUXbFVhZw/dgrLLJ0gYXlMVR
6JhTBrzI2slKMMz77fxLqdAF0cs1AJu+P4Q/u/16HXqr9abshUsrZieqOBhAuJgeW8MBIv6N2TKK
3k9OQPvJ8/TmDXzPtZD8huEoa0r++LDVCzdwDw61L/xMlT3Kes+naUmwMpuxFjj0LuyL0K1ypQkE
jFySh4iZ69R1DwKXpLLikmTHuUNMcM5VMELhBEGmrdy+Y/rWQaxGFrpfY6HyAVHw2HEfsVz2vC8B
RxyULT82bkvwp93mn22QH1/eCZeN/+ljo66/D7sJVxPwfxPF6vh3EEsTQ9OZQ0eRdcKXUv3yx1yv
Cnj91KyYJeqEPZSEZid/WZ+F3KZ4dyMyh8OsixiiAtqvQsYNNmnfkPHgL7Ljzjcvb0P7z098S8zb
vvN6X8iaI1zMRW0gg9EpmYNO7+gOMhBPDB7asPhLyqOdb/A7jrRh0vkiMUIjpFaxU3eI+N2zaLU2
r8Mv4Iaf/GewMP286I/6AUq2PSRAKAJzKk8IvN3/v1S7I9FYEXYwbt3Ik145K7na22qorPN5f1Uo
TYzHc+2s3xDYINmkCyVLyXl81+bILcNxj/g5pg1maw+SYfAMuTnvUwmpCtf988MhvIyKPq5iETfc
NVxfFkgOuNyQWJ17kGIFGqDIUlfWz08GWeNpZ4Levrt/d+zVj8WpKfE8XQc+a2uvtgjmD9q+Joi5
4+BEs5e+DKiiIvTbs9gdjoSntZYfXEaBamR3BjthKLObvNo5uhr0pT+9tODCQPTmo88PfIf/YxS5
mGigH0FfyPOT5NIrZT2lyxs5J8U2wtQRIcbv4ng3JB7gPoIqm62CIwUcbfZW5+fuLMi2akcrNtd9
fpZ79uuJ3pjXvJ87ktjmQv3CA4YSXR/GcCcrjl8Z87/2nKGzudYVLtYLiZiDlC07+3axGmNBSuVP
WWPwH9IqZCl7Do1O3PjQiKYZDFaY4EklVxD7NF/31Ee2wxIF5y+tyrzTy3GMEuUM/EyG5hIsyqtW
/AM4EcEOqsFxhD5yT5aMV4a/IxgozW5dR/ZvZiise74PzJWI1CIYf1kGBb1UC8tpSEylj2Q3tvW2
ovlDfC8D1D4ctTv0+AwlR4NzQP7UZHa6EDOknfjxr08nyBLGNKKzm421IdD2PObPvwe2ADl4IrEO
iQu7+Aac9DcnBB4i94We85QJDbKPCLc36/jFLV+ftxJVEdc3oIeZH5X13jUO6V2YJUWJZAswZJXO
fPqIpKgge2v0BHqS1hZnM1lE8JZpwq2GRUTIjuVLlr1vp9BJiH0QSW2IkZ0x/bm5eJSH+KR0agX/
RBfNhG4DK16tlmJbrSitIqBLgjtm//jiRMc5CEesi1Msx56zUwqT9j8Bhl57GDUQv/p97cIudJI2
59GVFqZqGRx29dLNq8mchNi7WCeKu4bN2+yGYGBG0rdyocd4vXfY/IdH1rmTNWXtyobL3Py+M985
PQ2CTpcef6qfTRDpGSJ7izOFsohaRbcrcxKZLizRqA9n4+jl+CYA6xiXD+uUHfWfpONPGGaM0B8B
ExXPbrhRj2LDWBfR/SSA34V1hYGTmz8SW5otJ/oYYPH5N4GRwmRtEsOC6werQBDnIV1a3un3WxRs
tmTA0Kl0Xk9xNKLQ/3f2JEzZhqWg2oOqLcJN8ikr2sexm1XtkIfGFLApFoVNwCVGOAzOW35bmL+y
EeZLfSAFqSIt1NObwltawp6K6yZf8l025MfEGCpTcKH77x9X0K+1fJsrZPvqoToJV4cYcEwMQeT0
a5CeAA3hJX2qLErFeSaOrsGq2EJFqyiu9IDcm8DhS9mKsvJfhreGo40BItSK1rdmem9LasgmjRtQ
QfMfkyRQPOLQU9+2AQ0zcbeDm03JCGb0Wk6o/jNRN+fgeqy+7iDIo3cp0xdVVuyhKL254OvlFjI+
cgUEVbMLOzeqUxixmJWkH63nxfEavz29+ratWSmwx55kOtTBVIQd2q8+zBJGrIA/6lUctftdTGpj
/dzSZaoWXum7srKn/sK7lLweT385d/9fKZrR8ivmmDnzNXa//a5zYTlwsjCwQDUw9NI1WPg8prHE
BQOC8zo5jD8KLV95N9g2CaU/qqzcFj1FUOvrlwXxIn/UR+ZgOPge6X4QHbYt+jHut0UYM651uw5V
94So2gIcAmvzI1jsC3kItaunFxIfLxZGKOE27ndwdMTfGYntNDVVOD25B+lGC+XMRfCQsz+kt8hx
NVtTQ9xAkVA1rbodTFUAVf0CU51+tzJxGuGmaJE4gPXrLM+ORsWqj8DXCmPoI+92869ctbOFn2u8
cN3+BBXN0lK2zbAOjw0TLPibAAQH5mPIxHuERzt1vUlxQpxPsQU9PtnY6rlOdoZwMj3XNRHIVdtF
c2F/+Skh1kH0Uf2hcF7RIXaZeYRU40G/UcMRWhU/m9kgc5KsESuJuShJ3RYKYzSxwoJ8KjvVqs69
8ga/g6UCUVc2pt8W4pgs/kxTqATCoBu8k9ESsYyJI6k5hDy772uEczqnWuvGydnSzezjJbw6vrCa
Zp6u+bBiG+jjc6BaNhZrrPzH0yAoFZBbZhlyUlOPX5h2owmWpNXNLWtxVWpMPHDpa1hxQLwRyiX2
pfVWo6al26b7VvnyhI0nUckLYM573bdKuEwti67kKNLHeS9rVCi=