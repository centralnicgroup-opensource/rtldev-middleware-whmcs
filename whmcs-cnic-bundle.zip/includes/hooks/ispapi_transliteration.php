<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPobFOt6S75X7MO7sKg1ID17PH3Ms6APULAcuyXuXOpdNMYNEGRI6guPyAQty/eUp4W8MKEJh
9Q9t+rrvXZYC7plKmO4lrnMBpaBx96jOiG110Jb3qyFQH+S88Zhj6h1Uvlkbhl+1t9/KK9dNE0qP
VvFmJgkUj3wr5pwBLtN/Y76XMrmUKy+RiuKIo2UIC38PQ0+E16c0jzcHi89nt2HWKbhSs5Ftn3sH
ySoLR5MdQ8ThIfu4k/7O7T9ahiscuzuskgBIVx3TJcoLmpISkowBr9pBQInfQJ+VE/Qagg289ai1
8QS2lC3fUNCvTsqKOgWCV79DgOifzej6QonsXr6ImZFBHjpMvU4Xm4J8AQncYlziUqeG2XHloypN
ohM2ZaGoAFXRnVOJO+Y69i2O6qcegV2DSw+QaIiw24RSXHum28A0D8E86ZeZSts2Bhm+g9m7Lg4c
cnnkefcoZInJ25eXNy2AGOMTVRc1jV9ZG/RBUH12zxhwILgf8rPYfOo52B6EomnxNS+0ugstpawU
2Gxx+vAAPmLMq4EP+axvGCm6v1oOWXiNGh8durRWLp3EHIMh3brEyaqC29n4uc0MJzY6xEJr2j7O
p4wDs522BGKe3QmiOLi7ynmJ0k2RfFe5EiF34PVCg+m6l3J/t41KlCsLtKiTLB8CZBRnQSChhuzt
inn1yqbi3MMfKIzulcu/aoExEsE0rcNnII7eA+KR+bui8PIT6ooWQjkQhEcTRF6wFI/RzumbRSCN
crV+iPj7l8M4FK4HLbmSneNSGWyof9MuGa/cTNe1NqT1IK+UP/0ogdWdtv0fpusaQ38N7fx90QtY
olxgcMI1T1FEg+kN0B4NwK4lWxVRfK4lcZQHMedqcWKNNGxp5wagPRpvvKkPSWo0Uob+Ah4+RICg
TMdvScrV48xqevpQSoKrYFX8UU+PzvphH2ObejLPLcclzFCw7hTeMzij4KfpBdm6R2Wzbhn0q5hp
Gj8590f3UYCT2915ZzS8gHK0dPvG3mUvxi+dQ+/iNIHYSNR1zhjhg6vFevhAIpiJvRqHIdwytG36
5F+9fykJPOB9SDLfjLZOgDSDAWoJ+ce9obNCgTfTjGkWfEfPx4tS8Oh6hJBBqqRafau1RuxWMpDM
pKS/lAoCQ3X1PLeauIVF6Q2MK6a+LNaCHJ0gGFfeDaH4CPilE8o4m4dJwZKgCTS+zosRk6Tg9s7q
JEv18IMrFu4Gbmh6/cmgYkLklRDyrT4AKrszwCk9edCP8NOuW0prVgjGZHydaJy1hH+c+c7IEAra
VDUWuAOa5wRYVDmkDiNje0pxuVo40U+UNa0dIQp8QWPZF+1lruDywzyE+J3MG7GB/KZf4Ft2tAfv
rmsKi6xpQLevV6SJ223453ezAj/lWz7YlCmOg+E1s24RK5olKiXEiFgb0cVqn4onPiHBoJQL+R6s
qYBz7+N0eQyr3sPAjLlSgRnFLQ5gjBiuBclYzPCl4vuJLdCkktiE2xyRsCdfz0shZT+IO1qXu0b5
60pod/yObEzt/YFnUFWuVnkrFlmkVZYhugKK2epi60jbOMEM3XEqOH91Sutw5Y2T6i0YbvMXoZb9
iB3Gek8kR1eu8wzxwuq/kexGMFWi2JL6DZ5akZK2hzPe9TFaJyQuKE7FuTHevrOJNsoe119p1IpN
6S00qVWRz+Tt2nkZRqlBfwmU4jclEkjsZ0msE+DkMQV+b6W5onp6RK08GqRBQhTnOnddE7IBLdCk
3EwQY8iGQWc5pzuIZRaMhwYL1JqAk/b29y4VcyA7mr/qmHH2qHJff5gDHKp0kSUujQ7094pdSjoC
6FxndZtongFs7Vkcz70fOL8JZ0BK4AOWhuBZ+3qq7cGXObjA0U6hshoF0zw/UmHeb3gEBpwwDikB
h4friBjDrLI8RpskMNjfw1SttzdbIlXKW320n8xSeKuKJ8eQ4sTp2iLc9GEr1WJdrcZYcqkbRDTY
UV81LLIhKGuXwgWAf54xNs9tsE5PLQE+EcBYbjqJcZbe4/N28U5sGNpAXb3/If7QjyeKQ95f5JaI
mthldqLknoHvhfb9x4Lu0SMOtOccMCpN9K6pZVQg4i9LSZPWlAW3O13P28AdyorJux+jEgw5e+po
Yt4w/HW4z2p55BoO/znJ8v4Uq1F2VPiptHun80hUAlk0o0Qwl4Az4MZQCncO86KFKKf3QxcW2w9S
yTwowx0EoIq0o5AYuuUup38oyDdHDII+BENooX98FqHoOsmQjlln9h1xOnutK7hqosR1lk+6p6MN
pjNO98NI90LuqTkRIhdXvhHEbMcpchMhCMchFrTHDVry/sS4qEieXYVU5mbQVmyffwWRLMcRYRQO
u1qSbfLCzgAMqOAgck9KZ2dkykwG36dN0H6uuEJ2UtgM1XnqzQqA0p9vKGaSlCqSrh+C1sM/nEhL
B65cUhCcHMLn/F7Dgoa3SE+T22eojuK6OU+G1opazQ49EsHV4P7rMstsWh3bPMCWThtYntkCkT+u
u1+qpuDkxtJF5B6II/hIYmahuX7DlNaaEd8uavwstUdM8r63NchKkTqE96yYau9G/xuHkTQrpGg5
6dZTj/X+S1OLm/BZcinWQ3sMsnaG6w0GJsWWwl9AIaS+m93KZ5CxPWPBOHsdcFfEsaYLAZ64uC5a
iw9IxfK6VvFJSAH0+Yf12Nn1GiGE6mq3czmji8ATu6gECGScqOufYTi5UuwXd5nl50kzSRP0Sb36
ONNxE3TWT/+SMk8ZOmwHI/IFvvDt2VvDDed6sEyjitjImBkcfjHKs2M4ud53X07gPyYkFbwDiKqq
wE/GVTDpFNJJBL1ZH++8gdtZ8PncgZRQceRvmGWWQwy8x734VU3fOtcf89Kg7jqAG8nUhaQ1Bn6w
yOnvsrVRUAnAkoHfolBDZUmAQgnNeyX7x1Nh6+kppBMnD+rJ6NT7xUaRG/1U7qHEnjBeTDRZ7/4a
4AL/1Jdvt+c+1kYKvHp67/6PRXcYzDh9OQydQzzFItt8V6M5VsDgWfNlWaekZElPHRHy24cpqrDL
68kXtYUxLHnR6saK/FjiZSoHREF9rjjXkPKgbvk1OateJwabIY8rfBM+/9uVtaXnQrODXJbPrROu
dEmorB4QU7ISEmOKRBbea3AQ+NGfhF6863lK9xbxxTwM71U/j8QXpaiMfY+xASdUrVYfLuM4XS40
JKsDlDTJnsEZ983S5zZEye6Tx02DhmDV56c1aHL10PeaEFW2ZwstSygGVAdADiaSEIW3jA2QNhz7
MF9j/6ltdk7sOzhchFpmN5Fji9YTW8CAGJD+1VC45IsC3VbIg8pkl5s/AylBZ889j/tgOz5yFcuM
bFvkD7E7mET5IVvzeZX65RRADZb9mpQMubOZFOAxYm9nkXXssce=