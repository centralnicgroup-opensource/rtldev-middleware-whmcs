<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+6/fk3ABHlNat4pmmHj4FNIuHzurdPyGuUuUAWcqdO4lSSgknXpXPct9NHAvx8C6Sst9nTb
5C6gI8/QuFnKljd7Sxu0wlO639/15sMlPLD+zSqrM21Mk0rgOFTYXV7UA2+azCJnMUdUHXh2jqpE
i4Q/gBQ4zT4fwerQt+xXAxkp1ER5sHLqxhuu9pqlrG+KfpOKdascRxXDHCrYer6IiAz5k0oR2L7F
YCf9+XV0GGuz6orAlMAsITPw+sx46Fle7ogBKFHTFJwo43LofB0Qo/2MmrLimZXNbB32Uc9+9qFD
wKTCAF7+cKnqdMTN4hUcsHIfCJLvda9tr4iW1XIA40uXDnVY7RgwVvmF7m+CB6KlT4sNwx5nxqjp
4YDNs7fcnU3XFtRuqOuUrJYltDvr3o3opr4u5qbWkl4J/+VoFgE5CmC1t8CxJwIqYoDK9QwJWkz3
m/Sim2HdKyoxPHEcGsiVYGjsq1tHyxNvaSX1DcHE9CbHGShb74ii3KgL0P4Xn5L8JhOE8DHcp7oN
hixtaupm8llqfZr8jyo0dv0vpBo6BYPFfQmPH2qbktSBtYfCDSEqCmULexp/NSdBApGvXMXSj9CB
NW/Zzu6RkglbHZAPpbyMOZWu0hQnGyFgPs/KpnUkga6+I5FO9DqTQbJ/eL3OPhFILad6dtz+VoRJ
brkM7ZDPElUqZZAe+1II338WAHHlNmMEETOZzJW2cxLw547tD8HH/Lb2nhbAn9DmLSQV+ukd5HmB
zHfG38KSWCucov/rtytP4T+u8XifwQlNjplKti3FLtqwnUAkMqu88oMZynih5JyCP/Crcq9nkjhP
pyNiKApocv4j+cHvXOVHqbBChLtkIImmw6Jc9G0MnrDX5v1YkpyxwlggWCsL2LVkN4qeP3Pili+G
ZT78//s8YbdLWUUoCOMsyE284drLdX0S9mFnyTy/OnTRWsG77YXgmsgo2OsgkEDhtgimpbLdcZbd
qg0zia0DGDzS7AKm8ly17y3dFYxJD04K4N2kGNfG3sRH9Icg/SZokXQ0OvSQkPLUCx7GIyje3nL3
DyPwmrA9XSMDP8RoghV5VW/dANJx09n6KqxSG8cDI3vG+VGeaEwwQdiKIDAr0BN3H0hiNHtOeqcL
1QIMC/DhCQDdjZTFCjJ3CWlPnc1uJRzaQoDPzDreh40uJ7i6TOSPCNhTtPK37E2+va4Sbi0pwXXr
Z30lc8TuArlK9KrXdTCw0hIr8jgyTbYbicuI6G0qyRPV4y6ZDiCjvRA+y2SRV2NhGOY+wHDkJHhA
627oZ4xosS01kaEri8ca09Qwj7qeCoNQ/E6EEqqjTjm7+JzRr6iDKyHHVcsjp04o+iVYGBwgVjk1
EoohRyNVNUNm6LrE8qUPm/T++hz85ks+/bh4Ch9gG4iflj6TvUBHazixtyWmH12mfq5++r6ZPgCE
LUw6mlsvkZO89i0wVPGHCbIO8rxZUU9rtW9Nk78uK4D+HKwAJQ0hH5VBUL/eABK9vJ/tTJWX7f7P
2N7BoIZxiOBwoLl0ywZK5B43gJkck48USXQklrJFLmC8uT849raUubT8UFiEXbiFMf5VKcAbUisz
aOoJ9WkqtbN5CkUKrb2FoDLSOPlMuH0EjrKR1a/ur35rL+wVU6gy7C9Ghl4KwE9klK9nWuSgZmjq
zOc35Wx30XQu5893E0AkXk7qfou29dcEA0XA3ZQsXr/f8Y9cf9GJ3CfXx783M7BTqh31IGl/IzEB
1wh8I00Ylr6uUXEhNXLg5KjJG9eu2flnW26X+8OOh5T09Yb12/DgfEBJvVE8CtXgiSlmAhskoIjm
LFc80tveR+A0hpwdZWybof9FlfaSsdw0fIbL5ce8ICt0QgDDNRueSw/MINLndTKWefq2gDk5rlAD
fzJDZzpT5DDCxMz/qOQwXpsrpWppXicjg1Uc+kPWwBEkIibtypLt6vY6T1nDR48ro3kZcdsyYk05
DU9/RHlpiYS46101huTeb6LOARINxZF9ujWZjb5U5BuviSKIF/Kc/N+0rcbe7LLs76cCCWPB77CQ
0omxJwEe17ezuMYA1fhWKmzmZXcoJl1A0krzwHyD06Q9g6WwLbsxFyzzaQFlOCVvyor5elc2TYTz
3ZO5HGG+W6G7ikDTsKNYBRSYjoG/6M80YxPXyTwix9hZmeslCrI21i6I1AxowbSFbyoWvUEGOD/R
JlepaxEdcM+SmwyHLQja7GdVWAnUjMOWWFx2vHBahMmA93QwtqfeQT6r+W7QySDm2k4ZYNrwZnb2
CwUBiVfxBLRb0LQcEnF5VcRzctDiXAYpD24RgRuN0N/pKekpmBOa2m8JwOjelNPpG6ELQe88H2Ve
FGTMWMVcnpzpIbYsqoIvYEIxT5fSkWk9ZLHkIHTaT+PMcmpMeWWQ/vUs3Y21nHGfZyfVbSyru5ID
NZuH3bh4eNlwx8pZqD22HHlmYmbPA7lUbxMOR1LbHTAyw4hDIjTGwP0LQS/A3bPtkGipEayrg4eY
Mvpin90wLeAd/qaxUs6qnP+ac3EasSJF1e8maX6ngttsbqgnik25GCTsfjclqz0UK3EP1EoXJi7E
5M/RoNP21xnbNmv/ak1fJBNQvtl51skt6sj/46wKUhGKfFaJ+KTKjlnNpoArGc3cfMXPn3cVddfW
aQdiNHmz6QzjSsGr1b/5kPG8Ss6rLLJAxslIGyD8pSZH1Cmnw1RnJAG4ixGKUG3gR00fyMyAqSMc
qtA53NuFnO+RTKuP45Cd/513+snXZdE0/1ZVx3yYx+0iia8ZT8v+DkMiqBMRYTHeXyKjMAbPpf8P
Ff4pAV0FMkawHBZgJt3HcTAafgyNugxvflJLrgY7JqxZkCU4sKatCzBCCWbJn8j4C1TrDcRYV5rY
cavsK4sJwARZpi7E4qREioLNAaVD6Zdun4LSr2EX1Iw+H1HZ4EjlYbJDGhX3zL+19/LLq0JP7Ts1
5gO1LCnMjUHFboLkksQWGiQDmW/3Yb94ZKlpxwEDTfQFVrBZCshgZV2BTuSggcrvSjXtm/iIWDng
QBo30luwKpTf3yiZl9xHWsn1Lqn6wRrJZOYzrpggrwM2sI3KQseJdRNQ1DV7+dMT3uOSNHpdPFTs
k59tg7/Hd3e67YV+RE23rxuu5oILPRCWoiH2d9CFGsWYfiFkqjkJf57XOj4eQFwvSTYxyYyHWPx9
etSU4yXhsvDCnMnPW52mYJbnq+zQZx3VHOFFkRyK5nCuRQCiFXLub3bzXbz93/FJHmnStoSsbwus
QboMS/6GAtbUcScBXGh6IjPXK1Wn2LkFcwoW0OFGf5EtoI7ovRZOZ99qpqmEnTwpT2LzhnKFyJOb
bbobsYreNlQKWDaWZ8tTA1sF8RuQHZkEe4dmS2MdYQc8Q8mR