<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtkPvt7/r4lSHZbNSb9ua9L4muP5fcUY2EuE2yMu4he19cGRP54xdAB7FR9TYfTYjPJuxfqx
qT67YxWP1aooLLNOI0Eo/tn2xGjt38h1dGYe7FWZ5orJJrSw5FmSzAQ8+EGikep+4uI/Qqy9CYRu
BKNiM9rTJVIYsk3f21KnvDEWl9OPLv8Zrj7cfnk9flF3Qwvnl7+sG1EUB96B3gY7TRtKmqHZAgOt
vmkx5zvuLHDdVVBc9GPGboFNNrxtqKR5pKpDwQqtSMaNgVaeYGs+i8eP79IKecXtEwUDVJMXgolP
KF9vvoB/n+0GUnJOYEGVRrPQL/Kf+wQ/vN9mweVFkaoH3YTJZTsymBG7woVN6c3HGiUm2awGMo+S
8lHv2iF+BRc4iMPzf1ztyUpCY7vkgB8Gi6H2+HUAwQ9J3EeWi30plxBqa87JYzSzhZHUO5v1/gAM
c/miQ1Qj7af9z0FZdbUCqKi+0J8Gc6+3BmIiS2qKVOzCTvrRyLTrXDFrki6J75e9/QLF2CuzKGph
4KhyKg1mHaiW7fcxOtEBO1kM80Xcf2QElWaFqY8+2AhPmUgElXDtRofyolhyEwlpkJ7w8GDg/GdB
0qV3NNPTnpNSLlbWn9D8aOmwpXE0yklGn1yu4wgGg0DW7N3oUHhmJyOAX1qJ+ealT7gNZhPefn3E
/iXlofzy78vn3aTh1moittgzDjSkjtO5MpaiXzGxqb4AQlepNu7fTzI7oQrNuDSubnofgwvCO04q
h22O+Ht5RrnEKpglVwyFMMUi6snlRfR0ta3q9m8/IB/9dJfrZdkh1Qk7ZDcS3tQc56wMcXzzvVbG
xx1IE2P03hWRijd8FMFcqE1BXsO2fTQ3WsqsxFa7YXtYvqP1Mq20Xto8vR3o2B42ikZmrRtXkH5D
iqJDFvSBUAN6O/3AMokeeW4al1zhKDvG/oJ+5ufKKrZ4Y16jbr3We4kvuiyiXPet+eO4MnnpnQOR
CJI7eQeiM9SK/xLRC/Z6kQO63VNW5ADEUvDne971ZjJuGxCNNTgiAyx/Bk4P1p4Qzj5X3XvQzTCr
7ZIu0t6yrbrYy+0Oz1v/Z/poLx8MOpW6gQq5A2lxt/s9eaWpPRglUV+VU73jj2UhTr04clvM4eMa
2Aw3kFrSITMN9cL97jmUS/OMFOB6GKXK4ktoH55HONidY4j8wR99fUSC66GMYJDsNCqrVw0stH6B
lAkkMmwmCTfGe17YtKx0i8xC9mF/HA5W6u3xV/F2Dybb+4VOrZwVozl4Rkf7RkH+zB/MWdC8ueVr
ZSP2eWEz6XbnL+ghuVbaY7UyVwOnvia7mWVoYB2bpebcUy8AR367e+/KJt4gGBc3m2OqNYeiV3VG
mjpdLGnxb+50kY5iXQGhQ5OCsO2AttsVVL70DquASwRCIvRzvNGM4kdsPV24Mv65j2MRQlB/8Wno
3OpITnyuUmYP46jskEBptL0HHqSY3BVryibQLWAceNIGpVG+85bwSq1dus/iP7ps1RILQLz5z4ze
0sqJaGeeHAP34+0mTd/hvc6N+4q/1lwGoHgO2PyayOhhktoppS4aRFjmpaDYZJ3HBdbOH97f3P0L
gddQBfT92o5QvuS0xbxBXQ+ZY90xChcOTA+G1R4UeTsrfIQXBS69cqCpW4NNBhNPoVoA3/zvjC1D
hOQ6qVt0yvSlBZksbE82ViSqQsDsYOVa3VbpASuutqgGcvFCtQYBnFdf3c302zic9hdqvEbNhx9B
sPp1MDJAzjCP4JBtCdCJwVJscwHMy9TlafjEctn1BhLPNzCODTUzJ/5l+HMOutXeOUG9QPB7J5KO
GFjsdpgR3xPNtEsOTLsncYJ5ofc/jvfFqNXmsln5AHBH99i0e+5fVSC1L1qBIge0G2/km+LlJbhf
q+Lfg47w89v0Vph7rRLl/lLLyuJMug0ClVvQrS6CUWoilmfBG+l/iatyOQFjdZThDuPzahERJx3G
UqlovZM2+19c0uvp59NvrpEteEzHRrqKTCz5hUulJpVgeT32t0PCCtSbbKyp1eTp2qxbQCoe6AYu
UEENamr6ynXYqe4PCkWAUsftBpjmY0qt3MaZs/b2jQ1ef7dM/YdsVV7hEoFS5SzdyZhrSUJ3+W7b
SCLOQQYv1OWcJSOWcLh6it9rV74VTfsrqNJdd0Z2FxGJkmbtwxb1dj0CKPmx8tIJJMF6GuBdRtKL
krjXlVdqsKIEDfWvc3IfOF9KZFTYKh70+ikQ6G6ASro1TCtV1/q3VINRXl9/wlsTnkpJYeRfYPtr
PA53LBkej1teDLMyR67AM7u0CnS4KhhAvNvzzx7nNMR63byOQ3gR2GdZfee+hNZpb+aREAbmTpa4
zOn/wj7dWOMxz+63FPWhU2IOpK3R8GR/afQoHFio+rDvmuHek2jL20bjSolX+21RBZ9T3URfRO42
t4ibQepFVOoqsPwGXz7DQsD9rLrxQjQrhQKwZ1kMVJ1e6rn6Hu8B0EfKriDJQg2j6ZkHz4pkdZsl
CwhxsNMalCVk7TPrS8PgynAFeJLhNN03/omawTe1Rzq5lHFx7TawenWzQR3ZPFna6T0rtcyvNTLC
PnArkj9T0wDwRaLVefejR5Sbq2RxHFXtL5meR/MjoaqYv6raiBhw1NI8pnpzl6QZ9v23jjdkC9/m
YEFHFxlkJw49buDT6BDanlc4faxGAHL960X0BCp8tlmZt2LXrEm1H9DlBzo14oenIVl86bpYisOi
aNqZx8pN9bY4Qr+xahMAkX3X4wd+1BhbyN2I0ZtTTOf/0BU205vJMIk/L79esdlxbMV2PlAVw0Es
m625sw6KBOPgH3himuVsfpXtaKli9EtRACSot/IIXvfDBYFLcvwFPnI0EUObmMDSn+qiXybQiNN4
0+r5d31hNDTyp0tJmuvE3tvJYdoAFnZseS5FSGQX6cNCibKHjHkowlmh77txPCrp/7A+IZ8PeGRu
zlCbTkxIvnNa65JTtdVZfJ1Rs53wj88YjPtPVWa4ivV8jXLhUUdMZD4rq9ZN5CHVkWr3dsL8H1L5
ZOMIvywNZSlhoF1g7L5UKJxGVFOLmSgsESDAPU83rB3jUsVMHC9o48DtVuC/RItgBIH6O93w/V3c
bs9bbATWoHXD9tMsW6ipvbjePetuhPn5Ijoc5XZfhV5zR0ydL7txSHfkwy0w73zGlNMdBavY3d3d
LrdEnre6Oyzjb1FNBIcRKaf4ikytk1ZQQT3abItA/p7sGxhc/RZF6lnpTfVb/CDNCKiKWsZb2Gep
qKBje/CK2XOu0E8Bu8dTP+KL2H/PAFyA/ZqguB0hz+oQitsqCMZMOzg5ZFCsTBjo+D2O0mVw990K
ZliZPPm2V+VXwXfDp41+lOw9o1K=