<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+hiDLRFV8wPbYAWTNsgzMpaQututM90uxUuzgFh8VXdBg+T3RPPs85uzq09LOJB2IQ0KaeZ
mUB9aFAVTAJLljgsqTw/SqhhrKV0kjfWuqJZ4U2SKhFqpOebHTxi9xmc1jivWefmllphxlwI85uX
ZSPUAtxVIWzmqPCuvVsBPvWRhW/qRVziFSR3eMcYvikBJ8PW3NkJEMxE1n6QpFihse0SAkv+aTtZ
8Ad0oJFymsB+Zae7iYDGkNEoGhyGU7mj/TwU1RvSKut9IebCxzBCMPaEOUfp9ov+I0UoSE5cFDbN
KoWj4S2FOa3bkxJu1UKnB4A8aOGPZOj3DfPk2M+zfMKcaM5+BP1Uzj3sacs5jWDrAa5ig8MXGxPU
BG8IslUWe0HEo0rGE8O4iO0AcjrQ48F5ARPD4NSYEDAdRgO7qrJ1VWMBXzLdo/x9Bv9yMy9FD1G9
ofM8Lc9HTduBMX3NptM5Xl6x8rOg7JcuY752uAfUZSX+dbtalo7F3PpnDOHugPp3QP7Ty/WOdRSY
0FNTn7puUn2iyxjfPmHHM8klFqVxYq9n5Jzt1Q4SzKfMdOmhnQxOG7yL9qYMz9ChkmKxWTc7q0JZ
yJVO+7uurvDzLBQobG8UK9mgUttjwpFDQQ1pGK/HSMYWdi1dO343eMXlaNejvietchCzr+X5ilu5
aVez8ycD62geVEvCj2nYeoRdxSfCfNvizYBR5/KIiAsPL0bDv+nT3w4kYRKFEgqie7qL5liSLzZi
hu6JvjeDq1xhh0is5WR8LHiLCGeRXYcbaUzrkf5gcRTFH55gTx5YZFIJPENI+xNZkKjnoUtBh0LU
TdI3LOTVJKNNNhDxvbgaPmkKbdu7vvChdoO6x6kWc/o58AjO2eZvd6iJDgsV557w/kj1Hxval9nN
vUA+EOBr+W/5/CQN5A2k84C0j7J1s+gKVWORsLTRkLJKlpgQYJONZzlxK9aCwni+ZN9h5FwljxuC
QFhb1+KXJa4YfiOi7HLX5+xpG3vjEViDbtst+jnnlPS9l50Amt8mXQb5NtT3PEXXdyOpjANhUWba
QBENHoKgwUxuGZR6WPesm+xbHhvnA4KTZmYzmEPJetq4NTEiEXqibT/3DRLo51IjSy7BQvBWAb9F
vS3euPH2tIIpW06dZ3vwadlsppXe6acbQqSxM/9/qBBV8Ul8CrKsTA3OzWjlm5WN0XKFNiI1lTgS
tylVSgNDYbQKRbko8x+/aklS6MeLw03DxFCx3Dv5iWpbOpvS6FSjCVkhTTqQOBpjaMz6O+pYDtoT
bAwcnTeHk1qaSg17YGEizcriVLsKYAkCTowLbqXR42Y5GPNLQcmlwdNmcYzNubzU/mc57hVb8abY
dOMUmp+Z0n6jt3jXx/w5Ufw22KmlCHzgf/7Dq0u1FfeFoHK0uzdHikPkp+Ml7LvddJ5e7tcHhsem
NE7/RSG7UrfcIn1aECgOJTSBVqZ1fyedT0Nij9G98TSzRy86QD6ciay16qbQ2TgETKBFXiY03lGH
yLhogcqp6JkPRCKPa8zPYkkr0zLZkzDJNyykugJD7nMrLqCIsCm7Z61bRv9naAuKicPHDmrdt4Mc
HBngg3UuBtDeeHhfJNSZIv1dX/w+7IJr5HZcUnp9/lEMGPlKBwXHnHEl9eZr1g+DgM0W0tuH6IeS
G+5lm5JE4yIt1kXtvx+HnTbnbaZfHKyrvNBa4pAvEeIL0vDsoVbompuERH5WXv/d/lyesKbTsc0J
7H8XIVIhjRr/XynLhgZaJCY/0gFSj7wHZZ++biyCiTv8pSePEnVuXTsklBwVeuw4NI9WCCwJAEsS
Ylqu4vftEClvKVH3ZzlMC1Jd6CtiyjMxDBY6XX1mE+s5Ix7ln4L2/nQHET6kUNRAdpWulyZgbPgT
DWuAT51JoTxqNtVnmOOLidnWRCZ7N+NrZKdL7YKAMPdAfpPQNVDPILEXRjF0AHFkjc5HhOxX7Jxx
B2Z1yu1nt4CWoxpVAtXh8ix6WQh/VJMihjw8V1aLQ6mKTtVap6fGOdqHiTTjBD6MQSdQ5shhT9XX
Q1sdDyT0yguOqRRKSPpaP5z9xftpW9vVNh7gNKe6yWBqFzOTHULsiisAIxT7BVnZBVQjajEWi07y
Z5jLRBz7mRB6WmMx7+DqQmkInQaS1nuCRS/EzwmoA+PgsJ0wJkbjM6P0rviGbpv1TQo5zruMGYzP
SdNyYg3agBMF+iwrnqlgeAysFnI4x50dJYm7UYlWSAl+LRSeWUczFO5O80Ga8OAvQAvixgsYC0O4
FacGaemdsCV1N9KFlpVXvI33oIAYgbnCDwJAjhmx5KxQMPWz9kk6JOE1/jjUH4nl8idNAe5JQnxN
TE2YAump0r5sRI9igTLvN12Av/rd2WGdKp71B8at/v93yWyP30j2HqorGiQifb2Y2X8X7BQG7Yth
P9lYB9BN6h+swuMNOs5x/p8SW+RmzIStZS4JyHcd/Di7lbzy/nNxHntTZImfv+Idkkvg9pdNAbik
n3GMRuqzRfPsLInk5Xsl100oZwd4k1nJVXvqiTO5SuO7V5iWmw8+xmDeLpfttJJsqT34VhjNusdI
jcqDjXiZUvLX5CFjzdY/HPdqBB8qMrv7EUrGfbGzCrKt1vRK4PwjNEb3PGdKWlNEK7JsuyJPFevF
JfI1LqHtoLdimyhHq+c2b0HHf1SMlXp1CTRz+R68xkwgsg7405SQdXV2i5XpCLq0u1TcoqK2fZjs
103/Q/F5C8ocU/8HJZlEhzHfm/5myUc2oezEaGk2I/3wyLETowdsAOia4QLoQ451XHD+yakin+HM
VPhb3YtNlduKlhnx8XSfvdXCfk3B5EsTNGTUq1DK7i9JTP/SDeW/XYxATV7VJRD5v2KbVhjC9RNT
62NHkCGSmPYeBtCzfB35N1iwt3QMGDPYaRS45b0shdp6kowRZW8a7ey1hQhZizsVGnRiLtBfL1Sp
TewniiHbyHrcHuV+YEr2/+CRS8AuLfpem+6U/dI/uHN82hgY60NSQTPAe16lIjCN/IYu6yynDoQV
jj8oK+L74B4n7nccr3gCPuCqt0y6lqxsIuL+/dvA6qt+AP8X0sH/NQ6twF4ncKf8/9YCiv2oM0Ja
YsXAxC1eAAKj77/LipF/vfLsZ+Xrj/O1zZJ9Cxa/HftkkFt0vqr+yopOOYU5ktoNm3ieRviCBeZl
vz4P5qO4DOQaRZ39de50SDkyP1cSlzFjGT/y4786Fc4h0+BbmUlR4hXAMg9G7Us2AeQIIF0VIK1V
4WyTXyQ2nyJeoPOewrtAUb9x6t+zNEnu0ovlOxx0oQNGgmXPedqUdX7QNehaPSpymCZfaVTjGQwW
jb705nujg+22n2IEFvkW46HxJENNkvjtUsm=