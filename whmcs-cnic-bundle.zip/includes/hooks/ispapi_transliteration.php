<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtiBtLiZsIMSEiL8UCTQWsvX3vEebpb7TTQKT027OnOSEHut8sllO3SA2SI/GxRARqftfwjy
f5u1dSgPZogJNvwwRDNxESeDHYZilJ6hwCe5c5pRwx2iW15HKJEpkLmhZ4Lt7ghdDYUQgRD0jtPQ
WlNAouBYdT+eEjWONt4Hf5FDKYVFiOq6Otcq2fpq0AExBX90VZu2Sa2QoQHKJZXeClnhBL1LTknf
k5y234Es4xeZzrQvKNOXD/khW8+F8Pa0sGH0MR7/R3uQsGryYXfCcmOogysXO7jSuTdk63f00HhE
GJ6eHymB3ej+wBnW79o9rli30sC6UE2UpGQc1ky4P60UxeRz8OjGEyN8vHlvkoeBDmrKmmpe/jzo
WT3QqNSleDF6M22tm7sPojn+4niba4VuqN8zsLgw3d/AWg7XDQb5eo+ivmDAMfwDeecEmJr/SI92
oWzpvtdidfbsrDBcaC6uJz/dmHPv7xsJWooO1HlwvcHy/bqSE4/bO7MqFqg0E0AwStzwMzRWSKoB
s4H34HPR88CePPFxKKvm9tEzXITwxOvmAbX8e+GNU7aKnGQ2ljU78qiodCNNYo5DtlvJ/6co3f69
71Zr9+uXncwSf+FkS+/coYDGzJHLY22HjWIitP+m+KcUJtarUbPmQ0r0INcBMBCXwYOSuFWGwM9N
tsUjpnZx338BNT2x5/EEt3OMYsqrlMWRPxAU6iSwqMa5PUkxOIvf5qQ48m/Uau/FJaAmfXJYzW4V
PixxYgakEwimaFeza2WRH3lknk4HGEIHC9vS9guJ9t/ooad246/IiI57ww5UbRHCX0GWsMXi9oR/
OnQstAYx5TMkvFZPUyKxn3/0TTIW6vlpovVY4VFA4Rkg1YAr8zJdCoZYFVGjsy9y5FzXZ6+8ckQy
ih4klKFzn/yWNx/tXxRS59ljjS8lnsfES9x6uNGNeMkDcEkWxL6PKzz6tdfrDKXOY4yo/UE5v/qK
7I7q8Hy40oyDBI3/ksD8hMFpcBCTl0q+4lJcG2NIOCan+VmPUtVVAqlW1vNOU97lL+/DdBQrSt2/
UavLOGnxjQhU1z/ZJuhoajX6AIZwsLyVIsHaT5pKQ+n1ZF+npIg6TVk6kAn2GUbCeIqn4j51DSJd
+1ouXgHFu4ZvbGf/81MkXFTEX3d9S+8BaFE5bR2nBMX3EIFIf2N7KVziH8afegfRAo0dLnnvs15g
Vl7wQTWooFYCu+TXWFcQcoS1iW9atHM0MT9k5Nlh+8HshSF4eDRBO+KU+9Qy6Stmh6w5rOGDQE2W
QLmp3mKocu29NU+pHsTJH494Fb103lVh3GaGKc9q9B/mndsTwPyAYbnuzRYKTARdRMSePElHd3HM
qI40OBUdcProSw1hEIZovzEc+ZyWI7wvj7EYFXSbjILgkijpw9o3zR4VT/aDHaAAL56Dkp4zlk7E
axgG/4zBWGxHYLZPIFijqXMrL77YmN57vIRh2hmAlFGKUM5QAg5ZBiJOApLtupFhXDjOnFHiGeHz
U53AKDQ5ybsW8HvyodjAfx++YK9HqMckbp2SON3wT9UzuQAxT5xBKZ9afIURwGt6e04se9ozlB7e
450QjdUDEmnlIhm5RWnuw/6IOpFGS1SDj0/3A/wf8s/g2NhJo7IIxK00Jtn5VGRTszHkD+02obSd
gPUgc0uA2B2L8eAXszvu1u4QM6lf2WcDRKIbn/5Pigj56OJIjLnSZ9UXClE+L11lVDPh9Kwl+fA/
c9Q3pZEayg1Eaeu4VcOU/GpMARp67ssaQ+sOGD4h86zbubsuI7SXk/I7MDBQFzv+RHEquu9DKOHh
uagYz8fN4R7Nh2fXbkp6GgAYfFtjwuJxfAVIkNZG8CA7b3jzjG1rAgfPUoUlMneqpjt5kkFN6Zzm
kCB2pYHFf+l+RYpZQE1DC2A/BEtuuKJ9VL9YY1hq+Z50zhqZBU1EaBize5NQetVYT0To0qIfFswF
pPb/RPzRUHWc+Omv+nm2nb59p6D8SvjBc6BgZT2z1UNa6109aOCr8C2Zrs2EpAiq8VfY766miLH0
wi+NKJO4E297id145X2ZWsSJ5uRcQmTLpPGHVDrSXAG5yGvJNm9T+yNvCFq9YCoeQ7s3fjiKWHz0
95RiR4gPUwIn/0b18O4jW5Z+mE9RVKsZ0OCMFUfAMeBLkPnduLI33iKGrVnTtNO9Supd1t4rQtQs
A4F9K2yYp26dri31mLY/1oMtXWClNGMInByTOCej+OjadxZNISkWqEKZwXx2QbVyukn8WiDfWY/z
/aVfb+zbqBx6hVmwTNa71BSC1r9bwUtFmscaBSURLyKVEEnvDubVtimaQgRnHnTadk05WzNz9p5Q
NaeVgW77UVlsS0vy1zR9nczgt1GKhdG38fF+bCKh++q0ct4DUd97PK/PzKswcXFgsBzCz08pfLXc
+UWcOKzR0KZYQi3yQ/brHFqluIxb+8sNYxttVCTDtzvw5kB9TMupV0Hrl5WSgPPU5kjJz7jmknEQ
MqXA3/zz+PscYdStSf5YytmLeo40OVklexEgGdFI0JXd9UYjLNdTsu3rnqUfsB1EHg3WaICD5Q+Z
peZZwx6i9eoyy5HiJlIE72niMFJsHaht9FdqaDPz6cWNjq8UpOSfNSF0ZWK0DblrPZBSHujgN5L0
TrMMsRcPFuCfxcXx4kOLJ6U2DlAfYOc+O9dIEP+8MP3SOXKcOtsvD2FSKYTC8twGWDo1uzIuRJXt
7MkONpIdA9Z7+tgtaDeJWtYe3Xssuc/sOtbwk4H+HQJzdolGKXa3082CzvGMGkPuRSVkBmXuKerk
OJlyRQLU/EWCIVXyJBU/BhWRvOFXSEtSmCSAZbtXUH4RPQGR/qPvpt7KGt7G4epwJepxOwJIcFh1
U1ZWCu7T6OeUY7vvULrmNkHgElTWspdfyZSvJbRfqeN7n4TVCsT8Tij6YASoDbK30w1o3vjQNHHB
BNY5yJdv3edzPR15isvJVEqIPBm4AwTilhfvsphpS8YT00rbkXQdQVRaCiqBEhAWZUh6C36VdFyn
NZxSJ5J/eFDFKsJgQO5v/22QRskp3Ef8NJUiN/owANmcr7r5vq2eolIzSzAbh8SZAKdU64013oiF
zRSUqlqmhF7fw8wBSf1vXL0ZZqFYcoCjJ3QmqBhWIEUpwbddRFO4CeBNozNg7w4I4cgFKPLq3AFZ
44F10eU845UTGzhWYAqRbnHDZ/MRT8MzXcBkvC/+HC24G/oy2iFLpZtVAVwKACkDyoUczhOJO3yB
WBnh8V+rOG2REjk0QNss2kf0B77AqaIZj2wxXQty0CUWEURnXgJw3JysDMgE5UKBvXSWQVVeSPed
Syr9SiDUNIfSbhStVxUf3Dm9gp67CDm=