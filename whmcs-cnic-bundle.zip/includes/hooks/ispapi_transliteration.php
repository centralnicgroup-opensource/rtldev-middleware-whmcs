<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwXWAeyBuAwWqgw/h5MS92R5ieD2Yxa0OBQuukqEbUsrW9yms6QFqhREe236A41dWGR9HZ+K
EywcnMYoBCjY5g8Ai/bWRfUFHqFnWAP4rWaFSm5Ojw10br/Pi6AePGXjsaokTd4WX2gFkpXkXNU+
/s4Qihw1Kykz22dAoEjjaoiXunCQOrgVqk5FRcDyB8YeAsJF3XG36XwB1mp3e96+57ss6UWw+aZQ
69JsUBfRYpTfjV2Y/p7w1gowLwrsFHhDl0rNxZxcDrKHnBWZAa8J2NHJAvLa1mxmTKNc85mknZmj
vyPp/wb5v5TefDhA8bqvjfJ+baOLxR+vsWm1/5Hfi5cqhmPEL+vpzxnCg8qau9oKErU2QExfuNBe
bFphjZRyXHHafU4aG7zOIe27GwUqoe1bIyv7gzBKsx0/5flj+ebbyYthXoipg2gbiLzu96grIFSh
qI0oW5rPcLEMWZwGDBR3fGPNYp2qzY3lAjJDL4Sg4mqqT+4kocIzO+duw7sC8BG0kuLSRgR23OPL
m410Nqek/Kcb0hk+w43wCw5kLZ9agHBnICW8GTQ6VcyAvuh7pIaib3QgWxrRdQ49wYSo7x2lkAUf
vRSX4IudnJ6as0JZIVW7eEdtlPBuCTZDBzMfJE4ZKrt/6Yc7lbtKDzB6CYvQECz+YypKabvt6ahw
LelSbOg5baYL1cVCMlLN6SthWAAO1yZ7PUc3ZaZcPQgSDCvNwbckYSh/PxvnxIzM03K5gtO0cwr4
pzudjrjr+AZLf7toy2ExU8xITY3lfbhrYiYB2dBoPIOjWIQ8R+mRF+E79z+IHK223vsLnvUvyPSc
9ncvvo2owjWc/l6JfPRk71u7ayZC/nDB/qvkVCh5bSDBF/NrSIjixprb6xc7EWCu7Ukusv1S9dFn
1bRDfbv4WMJ6ldkAVLp/TYThBzpbozxibFh/FiY++f+A+9E2Ex+FKMWBialRy+Vr9/+Wnn8aRzt0
Gy9XHSr29MEPRjAvsLanrewiDdK6f0wlGNhiE/fn4oqYMeBvOnqKX9ShqvbgXUXWNxceeRm+0ghA
cGuD+4L8FXRlFrfKU62xtLe2bTaYNi9A/8sHO927UHejnaH0456ieQ0K9GdILQVttHgutqOrZeeT
P0bfYKijOMXPPg2RZ8DQHeYb2Kuqku5MqO27qFM33hROkOnlF/HMVmHdjvqRx2G1P5S/uzlr2T2z
MKPUOmbx0/FoHdLDbhuWaPqRdSLxo8n+EQ1vUB4uM1ccABBlUGe1XJ8KCHjjg+rm2O3q0daYt38W
45M2GEgYxMXejdJ4FUl+zJlahDgZfgPMnjHb8rf5JV/RLlucEmqgfWZVX/CZdAEVPJNRgbAtnkTD
C7vU0LCQr0sQDbEXI2g5m587EwHxWwTvcUXJfAvcVHhhUm4uMczWJ070Z8H0Wo2BizEDn7EHE1k0
97SEJANLreq9gbwGfgZScIjnXP9FDT2yFkp0BYRJ5b6c7pJlzKAbwG2RUF63i+pOesI+9upAHMMJ
nJVnbdy7zrFLZc/A/F205d+Apl4kVVii+Qtnkl3uc39bkNPZzuxKJ7LullEx4RoWxcIIqkA3q50p
GlSL/QSdWAOu9o6qjySZ5LGlGM4JfLBQgpV5qySRvc1Xf6FWJYw0567SwDjXPV9Jm9Xs1XOLNjjH
ygq/WXNXjpe5Wxi2+9iU5dfNE2yjKDSELEgCyzG+RwRB4in3qBbCYGXCT5fslxS0LZx6cqidFKBh
Jvfk7kYp0RAtbPWbVJ9stDwP2JLhBVDc/u3BoIoWnlxIOTRlnPbFjvVUQvXxsXLsgo1IG+aHvk+v
R7h9n1hbA9sN5PprHPk0gO1xw0AMKaYOpyIm0kAAh08xUo+jfFXTeIMrpRFTxFnQIFyb37yLKE/p
tjqmi9smows4VizOXU4uG1CZPCe2cSssFbSWX/HIRXrEN0QsOuX5onry96ZjKo0CfORju0tFspT3
E0vvxbBbme0+W6o4cVg53/NuUmZolas7j26C68rWFjpWByaL3kvFd4o7CzKetz9sM6R3z145Ktbl
EKFacOh1fnUQHNrMd8qG17oTbfi/B3b+KZD5QWEyKVaHqMrwu9bW5huYZhviraMrT7naNpbQTadC
knoBn9EFK8SV9Zvr6yVYGsRJWVxOlsBVXTC91adcYKPILeaNOgIlT2ncZlTji78oVDV80hWt9LP6
1yxa/fiFYKNPorL7Vc4Zwzq9obABoNvnQ54m+c+n4ldhhBZgXRqit/eevGyVJn+J541zkA6sqJdR
NmIHgDN6cHuTV7VDWsVewCQZL3SlwnUTGX3V2tGXLk9p4W0kxAWPXhvA2iX3JXaHWFIlirY9vr+3
6GmFC+SvhQZB/HRdIRf16s4uh0BNbsJeqi/QUMsolox/6M2U+wRWZglqXc7GsFoBa2Csl+Edy/Rj
LMbxV5ql6ue13UvOhtNHy9ljnFc+mMNQts9Jmz3gTh+FOLKUonuatR83Z5p8vYH+K9ax+nh2LgK1
Ahq13DNvEIwhPAxL7OIY7Oep+cc6fl6yGS7tbKmDnVUYNlhy/L46YCZw1Te+MA4tEwPSZmgnd4V3
h8+fHGzpuGC3HmVkcmCGGqSKdhNJSrMp8QK3ZrjPK2nGia/UyrbzwrhtsRcS8lF/jnKgd2Q3eBed
a86Fm8tWUpuZIv++HQedqEHRlNlJwvflhTvtSokOo/N5+P6jWYqTPftk0q/9CWLm+oYTr9Y1tfwa
NVrPH72pl1l7SDWJy57j3AzH9TqdS0VBPw/7X0a2Lc+3X5felae3SNvVIxG8i4spg4d4NFCiSwJt
lh60h+Gvz1WNA1GbEYhQRzgZhxs9ti7NrPyXOti7c54U7Drj4G86SzYCT8oiHD4PIO/UzGED1IoI
sEpMXCrzEqnUeICxshlsmZI86Gsqh7AhSc6Dr9CvIyt/wgYQC29a7ycDzV/PqyVU55J9J/6t9u1k
nMfV6MeMa3CCdVrjKdPtyrO1eAQBiD68lb7nMhNYmzLz50zkVDiEfspPwCxAh50z9zl/jeUmpEJr
TlecWl5dcN4H9O/Sqa4e/0uO9mE5hXw909wEaSODXm9VOb5CRWjsqnCQ4gz6TYmr//fLbcrAPtIg
oVOoWnxGQjqXt+VYENOjFbMJR2x/r/Ubl4ZnKdR3hSPtvLClqcXRVOXf+OFVcvGUxWtaEdifPuGj
o8oFc3F07FCvcPqEspCqGXv82oF8McF0XjBbQ9ZodAo2h2iBZ8xeYNp6xaORUDrdmTbkDtsIIzK0
9Wcjpb/Vox45wFoUWPk6PfqXXoPti1pAanM76L5YWHqqjEIM+CmifIkhjQ5kkxZj4OKLnizA9yCx
fDeOXL0IA2bWupTBlBQAjHrIKhe4hQkhZugNAG==