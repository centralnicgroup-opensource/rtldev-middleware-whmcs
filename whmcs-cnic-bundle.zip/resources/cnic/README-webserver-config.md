# Web Server Configuration for resources/cnic/

This directory contains vendor libraries and internal resources that should not be indexed by search engines or directly accessible via HTTP.

## Supported Web Servers

WHMCS officially supports **Linux-based environments only**:
- ✅ **Apache** (Primary support)
- ✅ **LiteSpeed** (Apache-compatible)
- ⚠️ **Nginx** (Limited support - requires manual configuration)

**Windows/IIS is NOT supported by WHMCS.**

---

## Quick Reference

| Web Server | Config File | Works Automatically? | Manual Setup Required? |
|-----------|-------------|---------------------|----------------------|
| **Apache** | `.htaccess` | ✅ Yes | No |
| **LiteSpeed** | `.htaccess` | ✅ Yes | No |
| **Nginx** | `nginx.conf.example` | ❌ No | Yes - Add to server block |

---

## Configuration by Web Server

### Apache / LiteSpeed
✅ **Automatic** - Uses `.htaccess` file (already configured)

No additional configuration needed. The `.htaccess` file handles:
- Search engine blocking via X-Robots-Tag headers
- Directory listing prevention
- Access blocking for vendor/ and lib/ directories
- File type restrictions

---

### Nginx

Nginx does **NOT** read `.htaccess` files. You must add configuration to your Nginx server block.

⚠️ **Note:** WHMCS provides limited assistance for Nginx configurations. See [WHMCS Nginx documentation](https://docs.whmcs.com/Restrict_NGINX_Directory_Access) for more details.

**Option 1: Include the example file**
```nginx
server {
    # ... your existing config ...
    
    include /path/to/whmcs/resources/cnic/nginx.conf.example;
}
```

**Option 2: Add rules directly**
```nginx
location ^~ /resources/cnic/ {
    add_header X-Robots-Tag "noindex, nofollow, noarchive, nosnippet" always;
    
    location ~ ^/resources/cnic/(vendor|lib)/ {
        deny all;
        return 403;
    }
    
    location ~ \.(md|json|lock|dist|sh|yml|yaml|log|xml)$ {
        deny all;
        return 403;
    }
    
    autoindex off;
}
```

After adding, test and reload:
```bash
nginx -t
systemctl reload nginx
```

---

## What Gets Blocked?

### ❌ Blocked (403 Forbidden):
- `resources/cnic/vendor/*` - Composer dependencies
- `resources/cnic/lib/*` - Internal PHP libraries  
- `*.md, *.json, *.lock, *.sh, *.yml, *.log, *.xml` - Sensitive files

### ✅ Accessible (Required for functionality):
- `resources/cnic/assets/*` - CSS, JS, images
- `resources/cnic/templates/*` - Frontend templates
- `resources/cnic/lang/*` - Translation files (needed by JavaScript)
- `resources/cnic/logo.png` - Logo file

### 🔒 Not Indexed by Search Engines:
- **All files** in `resources/cnic/` (via X-Robots-Tag header)

---

## Testing

### Test if blocking works:
```bash
# Should return 403 Forbidden
curl -I https://yourdomain.com/resources/cnic/vendor/
curl -I https://yourdomain.com/resources/cnic/lib/

# Should return 200 OK
curl -I https://yourdomain.com/resources/cnic/assets/css/style.css
curl -I https://yourdomain.com/resources/cnic/lang/overrides/cnic-domain-search-addon-english.json
```

### Test X-Robots-Tag header:
```bash
curl -I https://yourdomain.com/resources/cnic/logo.png | grep -i "X-Robots-Tag"
# Should output: X-Robots-Tag: noindex, nofollow, noarchive, nosnippet
```

---

## Troubleshooting

### Nginx: "403 Forbidden" on assets/templates
- Check that your location blocks are ordered correctly (more specific first)
- Ensure the `^~` modifier is used for the main location block
- Verify Nginx error logs: `tail -f /var/log/nginx/error.log`

### Headers not appearing
- Verify the headers module is enabled:
  - Apache: `sudo a2enmod headers && sudo systemctl restart apache2`
  - Nginx: Headers module is built-in (check config syntax)
- Test with: `curl -I https://yourdomain.com/resources/cnic/logo.png | grep X-Robots-Tag`

### Nginx configuration conflicts
- If you have existing location blocks for `/resources/`, they may conflict
- More specific location blocks take precedence
- Consider placing the CNIC rules in a separate file and including it

---

## Security Notes

This configuration provides **defense in depth**:

1. **X-Robots-Tag** prevents search engine indexing (polite request)
2. **Directory blocking** prevents HTTP access to sensitive code
3. **File extension filtering** blocks configuration/metadata files
4. **No directory listing** prevents file enumeration

Even if crawlers ignore X-Robots-Tag, they still can't access blocked directories.
