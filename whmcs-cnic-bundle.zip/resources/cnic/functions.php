<?php

define("CNIC_VERSION", "16.6.0");

if (!function_exists('cnic_getLogoHTML')) {
    /**
     * Returns logo with permalink
     *
     * @return string
     */
    function cnic_getLogoHTML()
    {
        $imgpath = implode(DIRECTORY_SEPARATOR, [
            ROOTDIR, "resources", "cnic", "logo.png"
        ]);
        $imgdata = file_get_contents($imgpath);
        $imgsrc = "";
        if ($imgdata) {
            $imgsrc = "data:image/png;base64," . base64_encode($imgdata);
        }
        return <<<HTML
            <a href="https://centralnic-reseller.com/" target="_blank">
                <img style="max-width:100px" src="$imgsrc" alt="CentralNic Reseller" title="CentralNic Reseller" />
            </a>
HTML;
    }
}

if (!function_exists('cnic_getTemplateDir')) {
    /**
     * Get Templates Path
     *
     * @param string $templateDir templates directory path
     * @param string $module registrar module/addon name
     * @param string $additional if the templates are in any sub directories for e.g admin/client
     * @return string
     */
    function cnic_getTemplateDir($templateDir, $module = "cnic", $additional = null)
    {
        if (is_null($templateDir)) {
            // workaround for $ca->setTemplate()
            return implode(DIRECTORY_SEPARATOR, ["", "resources", "cnic", "templates", $module, $additional, ""]);
        }
        // get web root path
        $wrpath = \DI::make("asset")->getWebRoot();
        $path = new \WHMCS\View\Asset($wrpath);
        $assets = ["resources", "cnic"];
        $assets = implode(DIRECTORY_SEPARATOR, $assets);
        $defaulttplfolder = array_pop($templateDir);
        $newtplfolder = explode(DIRECTORY_SEPARATOR, $defaulttplfolder);
        array_splice($newtplfolder, count($newtplfolder) - 2, 0, ltrim($assets, '/'));
        $newtplfolder[count($newtplfolder) - 1] = $module;

        if (!empty($additional) && !is_array($additional)) {
            $newtplfolder[] = $additional;
        }

        return implode(DIRECTORY_SEPARATOR, $newtplfolder);
    }
}

if (!function_exists('cnic_getAssetPath')) {
    /**
     * Get Assets Path
     *
     * @param string $assetType specify what assets are required e.g css/js/img/logo, or root to get a web root path
     * @param string $module registrar module/addon name
     * @param string $additional if the templates are in any sub directories for e.g admin/client
     * @return string
     */
    function cnic_getAssetPath($assetType = null, $module = "cnic", $additional = null)
    {
        $wrpath = \DI::make("asset")->getWebRoot();
        $assetPath = new \WHMCS\View\Asset($wrpath);

        $assets = [$assetPath->getWebRoot(), "resources", "cnic"];

        if (!empty($assetType)) {
            if ($assetType === "css") {
                $assets[] = "assets";
                $assets[] = "css";
                $assets[] = $module;
            } elseif ($assetType === "js") {
                $assets[] = "assets";
                $assets[] = "js";
                $assets[] = $module;
            } elseif ($assetType === "img") {
                $assets[] = "assets";
                $assets[] = "img";
                $assets[] = $module;
            } elseif ($assetType === "logo") {
                // /^(?:a|b|c)$/ regex -> compliant code /psr
                if (preg_match("/^(?:ispapi|keysystems|cnic|cnr|hexonet)$/i", $module)) {
                    $assets = [$assetPath->getWebRoot(), "modules", "registrars", strtolower($module), "logo.png"];
                }
            } elseif ($assetType === "root") {
                return $assetPath->getWebRoot();
            }

            if (!empty($additional)) {
                $assets[] = $additional;
            }
        }
        return implode('/', $assets);
    }
}

if (!function_exists('cnic_getVersionCheck')) {
    /**
     * Checks if there is a newer version available
     *
     * @param boolean $requestVersion if true then it will return a version number
     * @return mixed[int, array]
     */
    function cnic_getVersionCheck($requestVersion = false)
    {
        $data = file_get_contents('https://raw.githubusercontent.com/centralnicgroup-opensource/rtldev-middleware-whmcs/main/release.json');
        if (!$data) {
            return -1;
        }
        $json = json_decode($data);
        if (version_compare(CNIC_VERSION, $json->version, '<')) {
            // if latest version is requested then return in an array
            if ($requestVersion) {
                return ['version' => $json->version];
            }
            return 1;
        }
        return 0;
    }
}

if (!function_exists('cnic_precheckAddons')) {
    /**
     * Automatically precheck addons on cart page if registrar module is activated
     * To toggle the auto-enabling mechanism by configuration on demand
     * A reseller might want to pre-check id protection, but not email forwarding
     * @param array $vars Hook data is available with custom data e.g registrar information
     * @return string
     */
    function cnic_precheckAddons($vars)
    {
        if (!$vars['inShoppingCart'] || $vars['action'] !== "confdomains") {
            return "";
        }

        $registrar = new WHMCS\Module\Registrar();
        if (!$registrar->load($vars['registrar'])) {
            // unable to load the registrar module
            return "";
        }

        // registrar module settings or whmcs settings
        $settings = $registrar->getSettings();

        // activate checkboxes via jquery
        $precheckDNSManagement = ($settings['AutoEnableDNSManagement'] === "on" ? 1 : 0);
        $precheckIDProtection = ($settings['AutoEnableIDProtection'] === "on" ? 1 : 0);
        $precheckEmailForwarding = ($settings['AutoEnableEmailForwarding'] === "on" ? 1 : 0);

        return <<<HTML
        <script type="text/javascript">
            $(document).ready(function() {
                if($precheckIDProtection === 1) {
                    let eL = $("input[name^=\"idprotection\"][type=\"checkbox\"]");
                    if (eL.prop('checked') === false) {
                        eL.click();
                    };
                }
                if($precheckDNSManagement === 1) {
                    eL = $("input[name^=\"dnsmanagement\"][type=\"checkbox\"]");
                    if (eL.prop('checked') === false) {
                        eL.click();
                    };
                }
                if($precheckEmailForwarding === 1) {
                    eL = $("input[name^=\"emailforwarding\"][type=\"checkbox\"]");
                    if (eL.prop('checked') === false) {
                        eL.click();
                    };
                }
            })
        </script>
HTML;
    }
}

if (!function_exists('cnic_getStatisticsData')) {
    /**
     * Get statistics data of active addons and registrars
     *
     * @param boolean $modulesOnly if it is true then additional stats data is not returned such as whmcs version, updated_date, php version and os name
     * @param string $separator if separator is not null then the data will returned with the requested separtor e.g if separator is "/" then data will look like CNIC/16.0.3 etc
     * @return array
     */
    function cnic_getStatisticsData($modulesOnly = false, $separator = null)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $stats = $_SESSION['CNIC_STATS'] ?? [];
        if (empty($stats)) {
            if (isset($_SESSION['CNIC_STATS'])) {
                unset($_SESSION['CNIC_STATS']);
            }
            $db = "\Illuminate\Database\Capsule\Manager";
            // get system driver mariadb/mysql etc
            $dbEngineName = strtolower(\DI::make("db")->getSqlVersionComment());
            // get system driver version 5/8 etc
            $sqlVersion = strtolower(\DI::make("db")->getSqlVersion());
            $dbEngineVersion = preg_replace("/[^\\d\\.]*/", "", $sqlVersion);
            $isMariaDb = strpos($dbEngineName . $sqlVersion, "mariadb") !== false;
            $dbEngineName = $isMariaDb ? "MariaDB" : "MySQL";

            // check if Cnic registrar is active
            $getCnicRegistrarStatus = $db::table('tblregistrars')
                ->where('registrar', '=', 'cnic')
                ->exists();
            // check if Ispapi registrar is active
            $getIspapiRegistrarStatus = $db::table('tblregistrars')
                ->where('registrar', '=', 'ispapi')
                ->exists();
            // Fetch Active Addons
            $activeAddons = $db::table('tblconfiguration')
                ->where('setting', '=', 'ActiveAddonModules')
                ->value('value');
            $activeAddons = explode(',', $activeAddons);
            // add active registrar to an array
            if ($getCnicRegistrarStatus !== false) {
                $activeRegistrarAddons['registrars']['cnic'] = CNIC_VERSION;
            }
            if ($getIspapiRegistrarStatus !== false) {
                $activeRegistrarAddons['registrars']['ispapi'] = CNIC_VERSION;
            }
            // add active addons to an array
            foreach ($activeAddons as $addon) {
                $activeRegistrarAddons['addons'][strtolower($addon)] = CNIC_VERSION;
            }
            $stats['basics'] = [
                "whmcs" => \App::getVersion()->getCanonical(),
                "updated_date" => (new \DateTime("now", new \DateTimeZone("UTC")))->format("Y-m-d H:i:s"), // this is UTC!
                "phpversion" => implode(".", [PHP_MAJOR_VERSION, PHP_MINOR_VERSION, PHP_RELEASE_VERSION]),
                "db" => $dbEngineName . "v" . $dbEngineVersion,
                "os" => php_uname("s")
            ];
            // merge registrar and addons data with current stats
            $stats = array_merge($stats, $activeRegistrarAddons ?? []);
            $_SESSION['CNIC_STATS'] = $stats;
        }
        // if only module stats are requested add db as well
        $moduleStats = array_merge($stats['registrars'] ?? [], $stats['addons'] ?? []);
        $moduleStats['db'] = $stats['basics']['db'] ?? [];

        // if all stats information is requested including php/whmcs/db/os info as well
        $allStats = array_merge($stats['registrars'] ?? [], $stats['addons'] ?? [], $stats['basics'] ?? []);

        if ($separator !== null) {
            // if modules are only requested then skip other stats
            if ($modulesOnly) {
                $stats = $moduleStats;
            } else {
                $stats = $allStats;
            }

            $formattedStats = [];
            foreach ($stats as $key => $value) {
                $formattedStats[] = $key . $separator . $value;
            }
            return $formattedStats;
        }

        return $allStats;
    }
}
