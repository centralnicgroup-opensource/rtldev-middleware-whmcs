<?php

define("CNIC_VERSION", "16.0.0");

if (!function_exists('cnic_getLogoHTML')) {
    function cnic_getLogoHTML()
    {
        $imgpath = implode(DIRECTORY_SEPARATOR, [
            ROOTDIR, "resources", "cnic", "logo.png"
        ]);
        $imgdata = file_get_contents($imgpath);
        $imgsrc = "";
        if ($imgdata) {
            $imgsrc = "data:image/png;base64," . base64_encode($imgdata);
        }
        return <<<HTML
            <a href="https://centralnic-reseller.com/" target="_blank">
                <img style="max-width:100px" src="$imgsrc" alt="CentralNic Reseller" title="CentralNic Reseller" />
            </a>
HTML;
    }
}

if (!function_exists('cnic_getTemplateDir')) {
    /**
     * Get Templates Path
     * @param string $asset
     * @return string
     */
    function cnic_getTemplateDir($templateDir, $module = "cnic", $additional = null)
    {
        if (is_null($templateDir)) {
            // workaround for $ca->setTemplate()
            return implode(DIRECTORY_SEPARATOR, ["", "resources", "cnic", "templates", $module, $additional, ""]);
        }
        // get web root path
        $wrpath = \DI::make("asset")->getWebRoot();
        $path = new \WHMCS\View\Asset($wrpath);
        $assets = [$path->getWebRoot(), "resources", "cnic"];
        $assets = implode(DIRECTORY_SEPARATOR, $assets);
        $defaulttplfolder = array_pop($templateDir);
        $newtplfolder = explode(DIRECTORY_SEPARATOR, $defaulttplfolder);
        array_splice($newtplfolder, count($newtplfolder) - 2, 0, ltrim($assets, '/'));
        $newtplfolder[count($newtplfolder) - 1] = $module;

        if (!empty($additional) && !is_array($additional)) {
            $newtplfolder[] = $additional;
        }

        $newtplfolder = implode(DIRECTORY_SEPARATOR, $newtplfolder);

        return $newtplfolder;
    }
}

if (!function_exists('cnic_getAssetPath')) {
    /**
     * Get Assets Path
     * @param string $asset
     * @return string
     */
    function cnic_getAssetPath($assetType = null, $module = "cnic", $additional = null)
    {
        $wrpath = \DI::make("asset")->getWebRoot();
        $assetPath = new \WHMCS\View\Asset($wrpath);

        $assets = [$assetPath->getWebRoot(), "resources", "cnic"];

        if (!empty($assetType)) {
            if ($assetType === "css") {
                $assets[] = "assets";
                $assets[] = "css";
                $assets[] = $module;
            } elseif ($assetType === "js") {
                $assets[] = "assets";
                $assets[] = "js";
                $assets[] = $module;
            } elseif ($assetType === "img") {
                $assets[] = "assets";
                $assets[] = "img";
                $assets[] = $module;
            } elseif ($assetType === "logo") {
                // /^(?:a|b|c)$/ regex -> compliant code /psr
                if (preg_match("/^(?:ispapi|keysystems|cnic|cnr|hexonet)$/i", $module)) {
                    $assets = [$assetPath->getWebRoot(), "modules", "registrars", strtolower($module), "logo.png"];
                }
            } elseif ($assetType === "root") {
                return $assetPath->getWebRoot();
            }

            if (!empty($additional)) {
                $assets[] = $additional;
            }
        }
        return implode(DIRECTORY_SEPARATOR, $assets);
    }
}

if (!function_exists('cnic_getVersionCheck')) {
    /**
     * Checks if there is a newer version available
     *
     * @return mixed[int, array]
     */
    function cnic_getVersionCheck($requestVersion = false)
    {
        $data = file_get_contents('https://raw.githubusercontent.com/centralnicgroup-opensource/rtldev-middleware-whmcs/main/release.json');
        if (!$data) {
            return -1;
        }
        $json = json_decode($data);
        if (version_compare(CNIC_VERSION, $json->version, '<')) {
            // if latest version is requested then return in an array
            if ($requestVersion) {
                return ['version' => $json->version];
            }
            return 1;
        }
        return 0;
    }
}
