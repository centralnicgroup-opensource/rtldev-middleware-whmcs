<?php

define("CNIC_VERSION", "22.3.6");

use \Illuminate\Database\Capsule\Manager as DB;

if (!function_exists('cnic_getLogoHTML')) {
    /**
     * Returns logo with permalink
     *
     * @return string
     */
    function cnic_getLogoHTML()
    {
        $imgpath = implode(DIRECTORY_SEPARATOR, [
            ROOTDIR, "resources", "cnic", "logo.png"
        ]);
        $imgdata = file_get_contents($imgpath);
        $imgsrc = "";
        if ($imgdata) {
            $imgsrc = "data:image/png;base64," . base64_encode($imgdata);
        }
        return <<<HTML
            <a href="https://centralnicreseller.com/" target="_blank">
                <img rel="prefetch" style="max-width:100px" src="$imgsrc" alt="CentralNic Reseller" title="CentralNic Reseller" />
            </a>
HTML;
    }
}

if (!function_exists('cnic_getTemplateDir')) {
    /**
     * Get Templates Path
     *
     * @param string|array $templateDir templates directory path
     * @param string $module registrar module/addon name
     * @param string|array $additional if the templates are in any sub directories for e.g admin/client
     * @return string
     */
    function cnic_getTemplateDir($templateDir, $module = "cnic", $additional = null)
    {
        if (!$templateDir) {
            // workaround for $ca->setTemplate()
            return implode(DIRECTORY_SEPARATOR, ["", "resources", "cnic", "templates", $module, $additional, ""]);
        }

        if ($templateDir === "bower_components") {
            return implode(DIRECTORY_SEPARATOR, ["", "resources", "cnic", "bower_components"]);
        }

        // get web root path
        $assets = ["resources", "cnic"];
        $assets = implode(DIRECTORY_SEPARATOR, $assets);
        $defaulttplfolder = array_pop($templateDir);
        $newtplfolder = explode(DIRECTORY_SEPARATOR, $defaulttplfolder);
        array_splice($newtplfolder, count($newtplfolder) - 2, 0, ltrim($assets, '/'));
        $newtplfolder[count($newtplfolder) - 1] = $module;

        if (!empty($additional) && !is_array($additional)) {
            $newtplfolder[] = $additional;
        }

        return implode(DIRECTORY_SEPARATOR, $newtplfolder);
    }
}

if (!function_exists('cnic_getAssetPath')) {
    /**
     * Get Assets Path
     *
     * @param string $assetType specify what assets are required e.g css/js/img/logo, or root to get a web root path
     * @param string $module registrar module/addon name
     * @param string $additional if the templates are in any sub directories for e.g admin/client
     * @return string
     */
    function cnic_getAssetPath($assetType = null, $module = "cnic", $additional = null)
    {
        $wrpath = \DI::make("asset")->getWebRoot();
        $assetPath = new \WHMCS\View\Asset($wrpath);

        $assets = [$assetPath->getWebRoot(), "resources", "cnic"];

        if (!empty($assetType)) {
            if ($assetType === "css") {
                $assets[] = "assets";
                $assets[] = "css";
                $assets[] = $module;
            } elseif ($assetType === "js" || $assetType === "javascript") {
                $assets[] = "assets";
                $assets[] = "js";
                $assets[] = $module;
            } elseif ($assetType === "img" || $assetType === "image") {
                $assets[] = "assets";
                $assets[] = "img";
                $assets[] = $module;
            } elseif ($assetType === "csv") {
                $assets[] = "assets";
                $assets[] = "csv";
                $assets[] = $module;
            } elseif ($assetType === "logo") {
                // /^(?:a|b|c)$/ regex -> compliant code /psr
                if (preg_match("/^(?:ispapi|keysystems|cnic|cnr|hexonet)$/i", $module)) {
                    $assets = [$assetPath->getWebRoot(), "modules", "registrars", strtolower($module), "logo.png"];
                }
            } elseif ($assetType === "root") {
                return $assetPath->getWebRoot();
            }

            if (!empty($additional)) {
                $assets[] = $additional;
            }
        }
        return implode('/', $assets);
    }
}

if (!function_exists('cnic_getVersionCheck')) {
    /**
     * Checks if there is a newer version available
     *
     * @param boolean $requestVersion if true then it will return a version number
     * @return mixed[int, array]
     */
    function cnic_getVersionCheck($requestVersion = false)
    {
        $data = file_get_contents('https://raw.githubusercontent.com/centralnicgroup-opensource/rtldev-middleware-whmcs/main/release.json');
        if (!$data) {
            return -1;
        }
        $json = json_decode($data);
        if (version_compare(CNIC_VERSION, $json->version, '<')) {
            // if latest version is requested then return in an array
            if ($requestVersion) {
                return ['version' => $json->version];
            }
            return 1;
        }
        return 0;
    }
}

if (!function_exists('cnic_precheckAddons')) {
    /**
     * Automatically precheck addons on cart page if registrar module is activated
     * To toggle the auto-enabling mechanism by configuration on demand
     * A reseller might want to pre-check id protection, but not email forwarding
     * @param array $vars Hook data plus custom data e.g registrar information
     * @return string
     */
    function cnic_precheckAddons($vars)
    {
        static $run = false;

        if (!$vars['inShoppingCart'] || $vars['action'] !== "confdomains" || !isset($vars["registrar"]) || $run) {
            return "";
        }

        $registrar = new WHMCS\Module\Registrar();
        if (!$registrar->load($vars['registrar'])) {
            // unable to load the registrar module
            return "";
        }

        // registrar module settings or whmcs settings
        $settings = $registrar->getSettings();

        // cart domains
        $domains = $_SESSION["cart"]["domains"];

        $addonsToCart = [];
        foreach ($domains as $idx => $domain) {
            list($sld, $tld) = explode(".", $domain["domain"], 2);
            $addonsToCart[".{$tld}"][$sld] = [
                "idprotection[{$idx}]" => !array_key_exists("idprotection", $domain) ? ($settings['AutoEnableIDProtection'] === "on" ? 1 : 0) : ($domain["idprotection"] === "on" ? 1 : 0),
                "dnsmanagement[{$idx}]" => !array_key_exists("dnsmanagement", $domain) ? ($settings['AutoEnableDNSManagement'] === "on" ? 1 : 0) : ($domain["dnsmanagement"] === "on" ? 1 : 0),
                "emailforwarding[{$idx}]" => !array_key_exists("emailforwarding", $domain) ? ($settings['AutoEnableEmailForwarding'] === "on" ? 1 : 0) : ($domain["emailforwarding"] === "on" ? 1 : 0),
            ];
        }

        $tldsInCart = array_keys($addonsToCart);

        $tldsFound = DB::table("tbldomainpricing")
            ->select("extension")
            ->whereIn("extension", $tldsInCart)
            ->whereIn("autoreg", ["ispapi", "cnic"])
            ->pluck("extension");
        $tldsFound = cnic_objectToArray($tldsFound);

        $tldsNotSupported = array_diff($tldsInCart, $tldsFound);
        foreach ($tldsNotSupported as $tld) {
            unset($addonsToCart[$tld]);
        }

        $run = true;

        $addonsToCart = json_encode($addonsToCart);
        return <<<HTML
        <script type="text/javascript">
            $(document).ready(function() {
                let addonsToCart = $addonsToCart;
                for (let tld in addonsToCart) {
                    if (!addonsToCart.hasOwnProperty(tld)) continue;
                    let domains = addonsToCart[tld];
                    for (let domain in domains) {
                        if (!domains.hasOwnProperty(domain)) continue;
                        let addons = domains[domain];
                        for (let addon in addons) {
                            if (!addons.hasOwnProperty(addon)) continue;
                            let value = addons[addon];
                            if (value === 1) {
                                let eL = $("input[name='" + addon + "'][type='checkbox']");
                                if (!eL.prop('checked')) {
                                    eL.click();
                                }
                            }
                        }
                    }
                }
            })
        </script>
HTML;
    }
}

if (!function_exists('cnic_getStatisticsData')) {
    /**
     * Get statistics data of active addons and registrars
     *
     * @param boolean $modulesOnly if it is true then additional stats data is not returned such as whmcs version, updated_date, php version and os name
     * @param string $separator if separator is not null then the data will returned with the requested separtor e.g if separator is "/" then data will look like CNIC/16.0.3 etc
     * @return array
     */
    function cnic_getStatisticsData($modulesOnly = false, $separator = null)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $stats = $_SESSION['CNIC_STATS'] ?? [];
        if (empty($stats)) {
            if (isset($_SESSION['CNIC_STATS'])) {
                unset($_SESSION['CNIC_STATS']);
            }
            // get system driver mariadb/mysql etc
            $dbEngineName = strtolower(\DI::make("db")->getSqlVersionComment());
            // get system driver version 5/8 etc
            $sqlVersion = strtolower(\DI::make("db")->getSqlVersion());
            $dbEngineVersion = preg_replace("/[^\\d\\.]*/", "", $sqlVersion);
            $isMariaDb = strpos($dbEngineName . $sqlVersion, "mariadb") !== false;
            $dbEngineName = $isMariaDb ? "MariaDB" : "MySQL";

            // check if Cnic registrar is active
            $getCnicRegistrarStatus = DB::table('tblregistrars')
                ->where('registrar', '=', 'cnic')
                ->exists();
            // check if Ispapi registrar is active
            $getIspapiRegistrarStatus = DB::table('tblregistrars')
                ->where('registrar', '=', 'ispapi')
                ->exists();
            // Fetch Active Addons
            $activeAddons = DB::table('tblconfiguration')
                ->where('setting', '=', 'ActiveAddonModules')
                ->value('value');
            $activeAddons = explode(',', $activeAddons);
            $activeAddons = preg_grep("/^(cnic|ispapi)/i", $activeAddons);
            // add active registrar to an array
            if ($getCnicRegistrarStatus !== false) {
                $activeRegistrarAddons['registrars']['cnic'] = CNIC_VERSION;
            }
            if ($getIspapiRegistrarStatus !== false) {
                $activeRegistrarAddons['registrars']['ispapi'] = CNIC_VERSION;
            }
            // add active addons to an array
            foreach ($activeAddons as $addon) {
                $activeRegistrarAddons['addons'][strtolower($addon)] = CNIC_VERSION;
            }
            $stats['basics'] = [
                "whmcs" => \App::getVersion()->getCanonical(),
                "updated_date" => (new \DateTime("now", new \DateTimeZone("UTC")))->format("Y-m-d H:i:s"), // this is UTC!
                "phpversion" => implode(".", [PHP_MAJOR_VERSION, PHP_MINOR_VERSION, PHP_RELEASE_VERSION]),
                "db" => $dbEngineName . "v" . $dbEngineVersion,
                "os" => php_uname("s")
            ];
            // merge registrar and addons data with current stats
            $stats = array_merge($stats, $activeRegistrarAddons ?? []);
            $_SESSION['CNIC_STATS'] = $stats;
        }
        // if only module stats are requested add db as well
        $moduleStats = array_merge($stats['registrars'] ?? [], $stats['addons'] ?? []);
        $moduleStats['db'] = $stats['basics']['db'] ?? [];

        // if all stats information is requested including php/whmcs/db/os info as well
        $allStats = array_merge($stats['registrars'] ?? [], $stats['addons'] ?? [], $stats['basics'] ?? []);

        if ($separator !== null) {
            // if modules are only requested then skip other stats
            if ($modulesOnly) {
                $stats = $moduleStats;
            } else {
                $stats = $allStats;
            }

            $formattedStats = [];
            foreach ($stats as $key => $value) {
                $formattedStats[] = $key . $separator . $value;
            }
            return $formattedStats;
        }

        return $allStats;
    }
}

if (!function_exists('cnic_precheckTransfersCheckout')) {
    /**
     * Precheck Transfers on Shopping Cart Checkout
     *
     * @param string $registrarid id of the registrar module e.g. cnic, ispapi
     * @return array<string>
     */
    function cnic_precheckTransfersCheckout($registrarid)
    {
        $fn = $registrarid . "_precheckTransfer";
        $registrar = new WHMCS\Module\Registrar();
        if (
            !$registrar->load($registrarid)
            || !is_callable(($fn))
        ) {
            return [];
        }

        // merge registrar settings and domain data
        $params = $registrar->getSettings();

        // load registrar module settings and check if transfer precheck are activated
        $cartprecheck = ($params["TRANSFERCARTPRECHECK"] === "on");
        if (!$cartprecheck) {
            return [];
        }

        $errors = [];

        // precheck all transfers
        foreach ($_SESSION["cart"]["domains"] as $d) {
            // check if type is transfer
            if ($d["type"] !== "transfer") {
                continue;
            }

            // check if the registrar configured for that tld matches
            $tld = preg_replace("/^[^.]+\./", "", $d["domain"]);
            $count = DB::table("tbldomainpricing")
                ->select("autoreg")
                ->where("extension", "." . $tld)
                ->where("autoreg", $registrarid)
                ->count();
            if (!$count) {
                continue;
            }

            $params["domain"] = $d["domain"];
            $params["eppcode"] = html_entity_decode($d["eppcode"]); // WHMCS ... :-/

            $r = $fn($params);
            if (isset($r["error"])) {
                $errors[] = $d["domain"] . ": " . $r["error"];
            }
        }
        return $errors;
    }
}

if (!function_exists("hideDataFromLog")) {
    function hideDataFromLog($command, $postData)
    {
        // extract variables from the query string if it is a string
        if (is_string($postData)) {
            parse_str(urldecode($postData), $postData);
        }

        // define the keys to be replaced
        $replaceKeys = ["AUTH", "s_pw", "PASSWORD"];

        // combine the command and the parsed string arrays
        $mergeArrayData = array_merge($postData ?? [], $command);

        // flip the arrayKeys to make the values as keys
        $flippedKeys = array_flip($replaceKeys);

        // filter the array by the replace keys and return the values
        return array_values(array_intersect_key($mergeArrayData, $flippedKeys));
    }
}

if (!function_exists("getAdminFolder")) {
    /**
     * get the admin folder path
     *
     * @return string
     */
    function getAdminFolder()
    {
        // get whmcs application instance
        $whmcs = \App::self();
        // access application config
        $whmcsAppConfig = $whmcs->getApplicationConfig();
        // return admin path (it is either a custom folder name or the default one)
        return $whmcsAppConfig["customadminpath"];
    }
}


if (!function_exists("cnic_track")) {
    /**
     * Logging system activities with user id
     *
     * @param array $params
     * @return void
     */
    function cnic_track(array $params)
    {
        $customMessage = $params["custom"] ?? "";
        $reason = $params["reason"] ?? "";
        $statusKey = $params["success"] ? "success" : "fail";
        $item = $params["item"] ?? "";
        $userId = \WHMCS\Session::get("uid");

        $action = cnic_backtraceFn();
        $registrar = $action['registrar'] ?? $params["registrar"] ?? "";

        if (!empty($customMessage)) {
            logActivity("[{$registrar}] {$customMessage}", $userId);
            return;
        }

        if (strtolower($action["fnName"]) === "savedns") {
            if (!isset($_SESSION["SaveDNS"])) {
                $_SESSION["SaveDNS"] = [];
            } else {
                unset($_SESSION["SaveDNS"][$item]);
            }
            if ($statusKey === "fail") {
                $_SESSION["SaveDNS"][$item] = $reason;
            }
        }

        $messages = json_decode(file_get_contents(__DIR__ . "/json/logMessages.json"), true) ?? [];
        $messages["default"] = [
            "success" => "Updated the data successfully.",
            "fail" => "Failed to process the data.",
        ];

        $message = $messages[$action["fnName"]][$statusKey] ?? $messages["default"][$statusKey];
        $message = !empty($item) ? $item . ": " . $message : $message;
        $message = !empty($reason) ? $message . " ({$reason})" : $message;
        $message = "[{$registrar}] {$message}";

        if (preg_match("/confirm the premium pricing/i", $message)) {
            cnic_addToDoItem([
                "item" => $item,
                "domainid" => $params["domainid"],
                "issue" => "premium_price_missing",
                "type" => preg_match("/renew domain/i", $message) ? "renew" : (preg_match("/transfer domain/i", $message) ? "transfer" : "register")
            ]);
        }

        logActivity($message, $userId);
    }
}

if (!function_exists("cnic_backtraceFn")) {
    /**
     * Finding last called function and returining function name and registrar module name
     *
     * @return array
     */
    function cnic_backtraceFn()
    {
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS | DEBUG_BACKTRACE_PROVIDE_OBJECT);
        $result = array();
        foreach ($trace as $t) {
            if (isset($t["function"]) && preg_match("/^(ispapi|cnic)_(.+)$/i", $t["function"], $m) && $m[2] !== "call" && $m[0] !== "cnic_track" && $m[0] !== "cnic_backtraceFn") {
                $result["fnName"] = strtolower($m[2]);
                $result["registrar"] = strtolower($m[1]);
                break;
            }
        }
        if (empty($result)) {
            $result["fnName"] = strtolower($trace[0]["function"]);
        }
        return $result;
    }
}

if (!function_exists("cnic_objectToArray")) {
    /**
     * Object to Array cast (e.g. db query results)
     * @param mixed $data input data which is casted to array in case it is of type object
     * @return array
     */
    function cnic_objectToArray($data)
    {
        if (is_object($data)) {
            $data = json_decode(json_encode($data), true); // object to array
        }
        return $data;
    }
}

if (!function_exists("cnic_isAddonActive")) {

    function cnic_isAddonActive($name)
    {
        // Fetch Active Addons
        $activeAddons = DB::table('tblconfiguration')
            ->where('setting', '=', 'ActiveAddonModules')
            ->value('value');
        $activeAddons = explode(',', $activeAddons);
        $activeAddons = preg_grep("/^(cnic|ispapi)/i", $activeAddons);

        // add active addons to an array
        foreach ($activeAddons as $addon) {
            if (strtolower($addon) === strtolower($name)) {
                return true;
            }
        }
        return false;
    }
}


if (!function_exists("cnic_validateAdditionalFields")) {
    /**
     * Validate DATE additional field(s) on domain cart configuration page
     * @param mixed $params cart data which includes domains with additional fields and their data
     * @return array
     */
    function cnic_validateAdditionalFields($params)
    {
        $domains = $_SESSION["cart"]["domains"];
        if (is_null($domains)) {
            return [];
        }

        $additionalFieldsFn = $params["registrar"] . "_AdditionalDomainFields";
        $registrar = new \WHMCS\Module\Registrar();
        if (
            !$registrar->load($params["registrar"])
            || !is_callable($additionalFieldsFn)
        ) {
            return [];
        }

        $registrarSettings = $registrar->getSettings();
        if ($registrarSettings["AdditionalFieldsValidation"] !== "on") {
            return [];
        }

        $errors = [];
        foreach ($domains as $i => $domainData) {
            $domainName = $domainData["domain"];
            $filledFields = $params["domainfield"][$i]; // Use $i as the index
            list($sld, $tld) = explode(".", $domainName, 2);

            $autoRegistrationRegistrar = \WHMCS\Domains\Extension::where("extension", "." . $tld)->value("autoreg");
            if ($autoRegistrationRegistrar !== $params["registrar"]) {
                continue;
            }

            $data = array_merge($registrarSettings, ["tld" => $tld, "type" => $domainData["type"]]);
            $fields = $additionalFieldsFn($data);

            foreach ($fields["fields"] as $field) {
                $fieldName = $field["Ispapi-Name"] ?? $field["Name"]; // HX vs CNR
                $fieldValue = $filledFields[$field["Name"]];
                if (
                    !empty($fieldValue)
                    && preg_match("/-(BIRTH)?DATE(-|$)/", $fieldName)
                    && !(preg_match("/^(\d{4})-(\d{2})-(\d{2})$/", $fieldValue, $m)
                        // https://www.php.net/manual/de/function.checkdate.php
                        // fn params: int month, int day, int year
                        // our format: YYYY-MM-DD, $m[0] is the original string
                        && checkdate((int)$m[2], (int)$m[3], (int)$m[1])
                    )
                ) {
                    $errors[] = "{$field["DisplayName"]} contains an invalid date '{$fieldValue}' ({$domainName})";
                }
            }
        }

        return $errors;
    }

    if (!function_exists("cnic_addToDoItem")) {
        /**
         * Add todo-list item in whmcs todolist table and add to domains monitoring table if premium price missing case
         *
         * @param array $params
         * @return void
         */
        function cnic_addToDoItem(array $params)
        {
            $title = "";
            $description = "";
            if ($params["issue"] === "premium_price_missing") {
                $type = $params["type"];
                $domainId = $params["domainid"];
                switch ($type) {
                    case "renew":
                        $title = "{$params["item"]}: Premium pricing missing, Manual action required";
                        $description = "The domain has either been upgraded to premium by the TLD provider or its premium pricing has been adjusted. To reflect this change, you'll need to manually update the premium pricing data in WHMCS.";
                        $issue = $type . "_premium_price_missing";
                        break;
                    case "transfer":
                        $title = "{$params["item"]}: Premium pricing missing, Manual action required";
                        $description = "The domain has either been upgraded to premium by the TLD provider or its premium pricing has been adjusted. To reflect this change, you'll need to manually update the premium pricing data in WHMCS.";
                        $issue = $type . "_premium_price_missing";
                        break;
                }
            }

            if ($title && $description) {
                $todoId = DB::table('tbltodolist')->where('title', $title)->value('id');
                $todoData = [
                    "title" => $title,
                    "date" => date("Y-m-d"),
                    "description" => $description,
                    "status" => "Pending",
                    "duedate" => date("Y-m-d")
                ];
                if (!$todoId) {
                    $todoId = DB::table("tbltodolist")->insertGetId($todoData);
                } else {
                    DB::table("tbltodolist")->where('id', $todoId)->update($todoData);
                }
            }

            if ($params["issue"] === "premium_price_missing") {
                cnic_addDomainMonitoringItem(["domainId" => $domainId, "issue" => $issue, "todoId" => $todoId]);
            }
        }
    }

    if (!function_exists("cnic_addDomainMonitoringItem")) {
        /**
         * Create domain monitoring table if not exist and add data for domains with pricing issues
         *
         * @param array $params
         * @return void
         */
        function cnic_addDomainMonitoringItem(array $params)
        {
            // Create table and import default categories
            if (!DB::schema()->hasTable('cnic_domainmonitoring')) {
                DB::schema()->create('cnic_domainmonitoring', function ($table) {
                    $table->increments('id');
                    $table->integer('domainId')->unsigned();
                    $table->integer('todoId')->unsigned();
                    $table->string('type', 64);
                    $table->charset = 'utf8mb3';
                    $table->collation = 'utf8mb3_unicode_ci';
        
                    // Define the foreign key constraint
                    $table->foreign('domainId')->references('id')->on('tbldomains')->onDelete('cascade');
                    $table->foreign('todoId')->references('id')->on('tbltodolist')->onDelete('cascade');
        
                    // Add a unique constraint
                    $table->unique(['domainId', 'todoId', 'type']);
                });
            }

            if (isset($params["domainId"]) && isset($params["todoId"])) {
                DB::table("cnic_domainmonitoring")->updateOrInsert(
                    [
                        "domainId" => $params["domainId"],
                        "type" => $params["issue"]
                    ],
                    [
                        "todoId" => $params["todoId"]
                    ]
                );
            }
        }
    }
}

if (!function_exists("cnic_aftermarketDomains")) {
    /**
     * Store and retrieve domains from session
     *
     * @param string $domain
     * @param boolean $set
     * @return boolean|void
     */
    function cnic_aftermarketDomains($domain, $addToSession = false)
    {
        if (empty($domain)) {
            return false;
        }

        $aftermarketDomains = (array) \WHMCS\Session::get("cnicAftermarketDomains");
        // check if it's a domain name or domain id
        $isDomainName = is_numeric($domain);

        // Check if addToSession is false
        if (!$addToSession) {
            if (!$isDomainName && in_array($domain, $aftermarketDomains)) {
                return true;
            } elseif ($isDomainName && \WHMCS\Domain\Extra::where("domain_id", $domain)->where("name", "cnicAftermarketDomain")->count() > 0) {
                return true;
            }

            return false;
        }

        // Add domain to session and remove duplicates and empty strings
       \WHMCS\Session::set(
            "cnicAftermarketDomains",
            array_values(array_filter(array_unique([...$aftermarketDomains, $domain]), "strlen"))
        );
    }
}

if (!function_exists("cnic_aftermarketCheckout")) {
    /**
     * Add aftermarket domains to domains table extra
     *
     * @param array $params
     * @return void
     */
    function cnic_aftermarketCheckout(array $params)
    {
        static $processed = NULL;
        if ($processed) {
            return;
        }
        foreach ($params["DomainIDs"] as $domain) {
            $domain = \WHMCS\Domain\Domain::find($domain);
            if (!isValidTldRegistrar($params["registrar"], $domain->getTldAttribute())) {
                continue;
            }
            // check if the domain is not in session or does not has custom prices in tbldomains_extra
            if (!cnic_aftermarketDomains($domain->domain)) {
                continue;
            }
            $extraDetails = \WHMCS\Domain\Extra::firstOrNew([
                "domain_id" => $domain->id,
                "name" => "cnicAftermarketDomain"
            ]);
            $extraDetails->value = 1;
            $extraDetails->save();
        }
        $processed = true;
    }
}

if (!function_exists("cnic_aftermarketDomainRegistration")) {
    /**
     * Change status of aftermarket domain after successful domain purchase
     *
     * @param array $params
     * @return void
     */
    function cnic_aftermarketDomainRegistration(array $params)
    {
        if (!isValidTldRegistrar($params["registrar"], $params["tld"]) && !cnic_aftermarketDomains($params["domainid"])) {
            return;
        }
        $domain = \WHMCS\Domain\Domain::find($params["domainid"]);
        $domain->status = "Pending Transfer";
        $domain->save();
    }
}

function isValidTldRegistrar($registrar, $tld)
{
    // add dot in the tld if not exist as whmcs stores tlds with dot in tbldomainpricing
    $tld = (strpos($tld, '.') === 0) ? $tld : '.' . $tld;
    return DB::table("tbldomainpricing")->where("autoreg", $registrar)->where("extension", $tld)->count() > 0;
}
