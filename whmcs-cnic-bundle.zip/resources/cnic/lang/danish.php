<?php

// #########################################################################
// #########################################################################
// # Add translations for CNR registrar module additional domain fields    #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ------------------ .DK Checkout Page ---------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrdkcheckoutheading"] = ".dk domænenavne vilkår og betingelser";
$_LANG["cnrdkcheckoutintro"] = "For at registrere et .dk-domænenavn skal du indgå en aftale om brugsret med Punktum dk A/S. Punktum dk er administrator for alle .dk-domænenavne.";
$_LANG["cnrdkcheckoutdomains"] = "Domænenavne:";
$_LANG["cnrdkcheckoutregistrant"] = "Registrant:";
$_LANG["cnrdkcheckoutregistrantaddress"] = "se ovenfor";
$_LANG["cnrdkcheckoutadmin"] = "Domæneadministrator:";
$_LANG["cnrdkcheckoutadminaddress"] = "Punktum dk A/S<br/>Ørestads Boulevard 108, 11. etage<br/>2300 København S";
$_LANG["cnrdkcheckouttac"] = implode("<br/><br/>", [
    "Jeg accepterer hermed at indgå en aftale om brugsret til det angivne .dk-domænenavn på de vilkår, der gælder herfor. Dette indebærer bl.a., at jeg til enhver tid skal sikre, at mine kontaktoplysninger som registrant er korrekte. Jeg gennemfører Punktum dk A/S' identitetskontrol, når der anmodes herom.",
    "Min brugsret til det angivne .dk-domænenavn kan overdrages, suspenderes, slettes og blokeres på de betingelser, der fremgår af Punktum dk A/S' vilkår.",
    "Jeg accepterer, at jeg efter den danske forbrugeraftalelov, § 18, stk. 2, nr. 13 giver afkald på retten til at fortryde indgåelse af aftale om brugsret til det angivne .dk-domænenavn.",
    "Jeg er indforstået med, at Punktum dk A/S som domæneadministrator anvender personoplysninger om mig i overensstemmelse med sin persondatapolitik.",
    "Jeg er indforstået med, at betaling for den første registreringsperiode af det angivne .dk-domænenavn sker til denne udbyder, og at betaling for efterfølgende registreringsperioder afhænger af mit valg af håndteringsordning, jf. punkt 2.1 i Punktum dk A/S' vilkår."
]);
$_LANG["cnrdkcheckouttacurl"] = "https://www.punktum.dk/artikler/vilkaar-for-brugsret-til-et-dkdomaenenavn";
$_LANG["cnrdkcheckouttacurltext"] = "Vilkår og betingelser for brugsretten til et .dk-domænenavn";
$_LANG["cnrdkcheckoutpolicyurl"] = "https://www.punktum.dk/artikler/persondatapolitik";
$_LANG["cnrdkcheckoutpolicyurltext"] = "Persondatapolitik";
$_LANG["cnrdkcheckoutabouturl"] = "https://www.punktum.dk/om-os";
$_LANG["cnrdkcheckoutabouturltext"] = "Om Punktum dk A/S";
$_LANG["cnrdkcheckouttacagree"] = "Ja, jeg accepterer brugeraftalen med Punktum dk A/S.";

// ----------------------------------------------------------------------
// ------------------ Common CNR Translations ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrchoose"] = "Vælg venligst";
$_LANG["cnroptional"] = "valgfri";
$_LANG["cnr1"] = "Ja";
$_LANG["cnr0"] = "Nej";
$_LANG["cnrconsentforpublishing"] = "Registrant, samtykke til offentliggørelse";
// .abogado, .aero, .attorney, .bank, .broker, .dentist, .forex, .insurance, .lotto, .law, .lawyer, .markets, .trading
$_LANG["cnrxallocationtoken"] = "Registryets allokeringstoken";
$_LANG["cnrxallocationtokendescr"] = "Kun påkrævet for Premium-domæner. Udstedt af registryudbyderen. Lad os vide, hvis du har brug for hjælp med det.";
// .app, .page, .dev, .new, .day, .channel, .boo, .foo, .zip, .mov, .nexus, .dad, .phd, .prof, .esq, .rsvp, .meme, .ing, .new
$_LANG["cnrxacceptsslrequirement"] = "SSL-krav";
$_LANG["cnrxacceptsslrequirementdescr"] = "Jeg bekræfter, at jeg forstår og accepterer kravene til HTTPS / et SSL-certifikat. Dette TLD er et mere sikkert domæne, hvilket betyder, at HTTPS er påkrævet for alle websteder. Du kan købe dit domænenavn nu, men for at det skal fungere korrekt i browsere, skal du konfigurere HTTPS baseret på et SSL-certifikat.";
$_LANG["cnrxacceptsslrequirement0"] = $_LANG["cnr0"];
$_LANG["cnrxacceptsslrequirement1"] = $_LANG["cnr1"];
// .attorney, .dentist, .lawyer
$_LANG["cnrxunitedtldregulatorydata"] = "Information om tilsynsorgan";
$_LANG["cnrxunitedtldregulatorydatadescr"] = "Udvidelse, der indeholder information om den godkendende myndighed/kontrolmyndighed/tilsynsorgan";
// .barcelona, .cat, .madrid, .scot, .sport, .swiss
$_LANG["cnrxintendeduse"] = "Tilsigtet brug";
$_LANG["cnrxintendedusedescr"] = implode("<br/>", [
    "Erklæring om tilsigtet brug af domænenavnet. Inkluder venligst en eksplicit reference til ansøgerens påståede ret til navnet (hvis ikke virksomhedsnavnet for ansøgeren).",
    "For eksempel, hvis domænenavnet matcher et varemærke, skal TM-nummeret angives (maks. 256 tegn)."
]);
// .mk
$_LANG["cnrxcompanyvatid"] = "Registrant, virksomhedens moms-id";
$_LANG["cnrxcompanyvatiddescr"] = "";
// .nu, .se
$_LANG["cnrxrequestauthcode"] = "Anmod om ny EPP-kode";
$_LANG["cnrxrequestauthcode0"] = $_LANG["cnr0"];
$_LANG["cnrxrequestauthcode1"] = $_LANG["cnr1"];
$_LANG["cnrxrequestauthcodedescr"] = "Hvis du vil overføre domænet til en anden registrar, har du brug for autorisationskoden. Vi sender den til domæneejere

ns e-mailadresse.";

// ----------------------------------------------------------------------
// ------------------ DOMAIN DETAILS (and sub pages) --------------------
// ----------------------------------------------------------------------
$_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] = (
    "<small>Vi har fundet nogle problemer med dine domænekontaktoplysninger, der kræver din opmærksomhed. For at løse dette:<br/><br/><ol>" .
    "<li>Skift til klientområdet (yderligere felter vises også der, hvis det er relevant)</li>" .
    "<li>Gå til dette domænes <b>Kontaktinformation</b> side</li>" .
    "<li>Foretag de nødvendige rettelser</li>" .
    "<li>Gennemfør verifikationsprocessen umiddelbart efter, hvis det er relevant</li></ol></small>"
 );
$_LANG["cnrdomaincontactvalidationerrorsummary"] = (
    "<small>Vi har fundet nogle problemer med dine domænekontaktoplysninger, der kræver din opmærksomhed. For at løse dette:<br/><br/><ol>" .
    "<li>Gå til siden <b><a href=\"clientarea.php?action=domaincontacts&domainid=:domainid\">Kontaktinformation</a></b> og gennemgå dine detaljer</li>" .
    "<li>Foretag de nødvendige rettelser</li>" .
    "<li>Gennemfør verifikationsprocessen umiddelbart efter, hvis det er relevant</li></ol></small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspensionadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Venligst afslut disse trin inden <b>:suspensiondate</b> for at forhindre, at dit domæne bliver suspenderet.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspension"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Venligst afslut disse trin inden <b>:suspensiondate</b> for at forhindre, at dit domæne bliver suspenderet.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspendedadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Dit domæne er blevet suspenderet. Venligst afslut disse trin for at ophæve suspensionen af dit domæne.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspended"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Dit domæne er blevet suspenderet. Venligst afslut disse trin for at ophæve suspensionen af dit domæne.</small>"
);

// ----------------------------------------------------------------------
// ------------------ .AERO Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaeroensauthid"] = "Registrant, ENS Authority ID";
$_LANG["cnrxaeroensauthiddescr"] = "ENS Authority ID / Key";
$_LANG["cnrxaeroensauthkey"] = "Registrant, ENS Authority Key";
$_LANG["cnrxaeroensauthkeydescr"] = "ENS Authority ID / Key";

// ----------------------------------------------------------------------
// ------------------ .AU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaudomainrelation"] = "Registrant, Relation to Domain Name";
$_LANG["cnrxaudomainrelation1"] = "Registrant Name matches or is a close and substantial connection to the requested Domain Name";
$_LANG["cnrxaudomainrelation2"] = "Registrant Name matches or is an acronym, abbreviation or other variation of the registered Domain Name";
$_LANG["cnrxaudomainrelationdescr"] = "Confirm that at least one of these is true";
$_LANG["cnrxaudomainrelationtype"] = "Registrant, Type (Legal Entity and ABN/ACN holders only)";
$_LANG["cnrxaudomainrelationtypecompany"] = "Company";
$_LANG["cnrxaudomainrelationtyperegisteredbusiness"] = "Registered Business";
$_LANG["cnrxaudomainrelationtypesoletrader"] = "Sole Trader";
$_LANG["cnrxaudomainrelationtypepartnership"] = "Partnership";
$_LANG["cnrxaudomainrelationtypetrademarkowner"] = "Trademark Owner";
$_LANG["cnrxaudomainrelationtypependingtmowner"] = "Pending Trademark Owner";
$_LANG["cnrxaudomainrelationtypecitizenresident"] = "Citizen/Resident";
$_LANG["cnrxaudomainrelationtypeincorporatedassociation"] = "Incorporated Association";
$_LANG["cnrxaudomainrelationtypeclub"] = "Club";
$_LANG["cnrxaudomainrelationtypenonprofitorganisation"] = "Non-profit organisation";
$_LANG["cnrxaudomainrelationtypecharity"] = "Charity";
$_LANG["cnrxaudomainrelationtypetradeunion"] = "Trade Union";
$_LANG["cnrxaudomainrelationtypeindustrybody"] = "Industry Body";
$_LANG["cnrxaudomainrelationtypecommercialstatutorybody"] = "Commercial Statutory Body";
$_LANG["cnrxaudomainrelationtypepoliticalparty"] = "Political Party";
$_LANG["cnrxaudomainrelationtypeother"] = "Other";
$_LANG["cnrxaudomainrelationtypereligiouschurchgroup"] = "Religious/Church Group";
$_LANG["cnrxaudomainrelationtypehighereducationinstitution"] = "Higher Education Institution";
$_LANG["cnrxaudomainrelationtyperesearchorganisation"] = "Research Organisation";
$_LANG["cnrxaudomainrelationtypegovernmentschool"] = "Government School";
$_LANG["cnrxaudomainrelationtypechildcarecentre"] = "Child Care Centre";
$_LANG["cnrxaudomainrelationtypepreschool"] = "Pre-school";
$_LANG["cnrxaudomainrelationtypenationalbody"] = "National Body";
$_LANG["cnrxaudomainrelationtypetrainingorganisation"] = "Training Organisation";
$_LANG["cnrxaudomainrelationtypenongovernmentschool"] = "Non-government School";
$_LANG["cnrxaudomainrelationtypeunincorporatedassociation"] = "Unincorporated Association/Club";
$_LANG["cnrxaudomainrelationtypeindustryorganisation"] = "Industry Organisation";
$_LANG["cnrxaudomainrelationtyperegistrablebody"] = "Registrable Body";
$_LANG["cnrxaudomainrelationtypeindigenouscorporation"] = "Indigenous Corporation (CATSI Act)";
$_LANG["cnrxaudomainrelationtyperegisteredorganisation"] = "Registered Organisation";
$_LANG["cnrxaudomainrelationtypetrust"] = "Trust";
$_LANG["cnrxaudomainrelationtypeeducationalinstitution"] = "Educational Institution";
$_LANG["cnrxaudomainrelationtypecommonwealthentity"] = "Commonwealth Entity";
$_LANG["cnrxaudomainrelationtypestatutorybody"] = "Non-Commercial Statutory Body";
$_LANG["cnrxaudomainrelationtypetradingcooperative"] = "Trading Co-operative";
$_LANG["cnrxaudomainrelationtypecompanylimitedbyguarantee"] = "Company Limited by Guarantee";
$_LANG["cnrxaudomainrelationtypenondistributingcooperative"] = "Non-distributing Co-operative";
$_LANG["cnrxaudomainrelationtypenontradingcooperative"] = "Non-trading Co-operative";
$_LANG["cnrxaudomainrelationtypecharitabletrust"] = "Charitable Trust";
$_LANG["cnrxaudomainrelationtypepublicprivateancillaryfund"] = "Public/Private Ancillary Fund";
$_LANG["cnrxaudomainrelationtypepeakstateterritorybody"] = "Peak State/Territory Body";
$_LANG["cnrxaudomainrelationtypenotforprofitcommunitygroup"] = "Not-for-profit Community Group";
$_LANG["cnrxaudomainrelationtypeeducationandcareserviceschildcare"] = "Education and Care Services (Child Care)";
$_LANG["cnrxaudomainrelationtypegovernmentbody"] = "Government Body";
$_LANG["cnrxaudomainrelationtypeproviderofnonaccreditedtraining"] = "Provider of Non-accredited Training";
$_LANG["cnrxaudomainrelationtypedescr"] = "Entity Type (non-Person entity types only)";
$_LANG["cnrxauownerorganization"] = "Registrant, Organisation Name<br/>(e.g. Company, Association, etc.)";
$_LANG["cnrxauownerorganizationdescr"] = "Company, Association, Registered Business, Partnership or Trust name or Other (As it appears on your company certificate. Sole Traders should enter their name as it appears on their Sole Trader registration.)";
$_LANG["cnrxauidwarranty"] = "Eligibility Warranty";
$_LANG["cnrxauidwarranty0"] = "I certify that the I am eligible for the domain name and/or information provided in this application is true, complete and correct. If any information is later found to be inaccurate, it may result in cancellation of the domain name.";
$_LANG["cnrxauidwarranty1"] = "I certify that the entity I represent is eligible for the domain name and/or information provided in this application is true, complete and correct. If any information is later found to be inaccurate, it may result in cancellation of the domain name.";
$_LANG["cnrxauidwarrantydescr"] = "This has to be checked in order to be allowed to proceed. Select the appropriate Warranty Phrase";
$_LANG["cnrxaueligibilityname"] = "Registrant, Eligibility Name";
$_LANG["cnrxaueligibilitynamedescr"] = "Entity Name or Person Name (Must be the exact match of the name on your ABN, ACN, TM, or other State/Territory identifiers)";
$_LANG["cnrxaudomainidnumber"] = "Registrant, Eligibility ID Number";
$_LANG["cnrxaudomainidnumberdescr"] = "ABN/ACN/TM number for entity/organisation (If ABN/ACN, provide with no spaces. If Trademark, include the country code e.g.: AU0001 for Australian trademarks, NZ0002 for New Zealand trademarks, 1234567 for WIPO IR trademark)";
$_LANG["cnrxaudomainidtype"] = "Registrant, Eligibility ID Type";
$_LANG["cnrxaudomainidtypetm"] = "Trademark Number";
$_LANG["cnrxaudomainidtypeabn"] = "Australian Company Number (ACN)";
$_LANG["cnrxaudomainidtypeacn"] = "Australian Business Number (ABN)";
$_LANG["cnrxaudomainidtypeother"] = "Other - used for incorporated companies, business, registered business, trusts, partnerships, and sole traders)";
$_LANG["cnrxaudomainidtypeact"] = "Australian Capital Territory";
$_LANG["cnrxaudomainidtypensw"] = "New South Wales";
$_LANG["cnrxaudomainidtypent"] = "Northern Territory";
$_LANG["cnrxaudomainidtypeqld"] = "Queensland";
$_LANG["cnrxaudomainidtypesa"] = "South Australia";
$_LANG["cnrxaudomainidtypetas"] = "Tasmania";
$_LANG["cnrxaudomainidtypevic"] = "Victoria";
$_LANG["cnrxaudomainidtypewa"] = "Western Australia";
$_LANG["cnrxaudomainidtypeprivate"] = "Used by Individuals";
$_LANG["cnrxaudomainidtypedescr"] = "Eligibility ID Type";
$_LANG["cnrxaueligibilityidnumber"] = "Registrant, Eligibility ID Number";
$_LANG["cnrxaueligibilityidnumberdescr"] = "ABN/ACN/TM number for entity/organisation (If ABN/ACN, provide with no spaces. If Trademark, include the country code e.g.: AU0001 for Australian trademarks, NZ0002 for New Zealand trademarks, 1234567 for WIPO IR trademark)";
$_LANG["cnrxaueligibilityidtype"] = "Registrant, Eligibility ID Type";
$_LANG["cnrxaueligibilityidtypedescr"] = "Eligibility ID Type";

// ----------------------------------------------------------------------
// ------------------ .CA Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcalegaltype"] = "Registrant, Legal Type";
$_LANG["cnrxcalegaltypeabo"] = "Aboriginal Peoples";
$_LANG["cnrxcalegaltypeass"] = "Unincorporated Association";
$_LANG["cnrxcalegaltypecco"] = "Corporation";
$_LANG["cnrxcalegaltypecct"] = "Canadian Citizen";
$_LANG["cnrxcalegaltypeedu"] = "Educational Institution";
$_LANG["cnrxcalegaltypegov"] = "Government Entity";
$_LANG["cnrxcalegaltypehop"] = "Hospital";
$_LANG["cnrxcalegaltypeinb"] = "Indian Band";
$_LANG["cnrxcalegaltypelam"] = "Library, Archive or Museum";
$_LANG["cnrxcalegaltypelgr"] = "Legal Representative";
$_LANG["cnrxcalegaltypemaj"] = "The Queen";
$_LANG["cnrxcalegaltypeomk"] = "Official Mark";
$_LANG["cnrxcalegaltypeplt"] = "Political Party";
$_LANG["cnrxcalegaltypeprt"] = "Partnership";
$_LANG["cnrxcalegaltyperes"] = "Permanent Resident";
$_LANG["cnrxcalegaltypetdm"] = "Trademark";
$_LANG["cnrxcalegaltypetrd"] = "Trade Union";
$_LANG["cnrxcalegaltypetrs"] = "Trust";
$_LANG["cnrxcalegaltypedescr"] = "";
$_LANG["cnrxcatrademark"] = "Registrant, Trademark";
$_LANG["cnrxcatrademark0"] = "The registrant does not hold a trademark relevant to this domain name";
$_LANG["cnrxcatrademark1"] = "The registrant holds a registered trademark relevant to this domain name";
$_LANG["cnrxcatrademarkdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COM.BR / .NET.BR Fields --------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxbrregisternumber"] = "Registrant, CPF or CNPJ Number";
$_LANG["cnrxbrregisternumberdescr"] = "Format: 000.000.000-00 (CPF, for individuals) or 00.000.000/0000-00 (CNPJ, for entities)";

// ----------------------------------------------------------------------
// ------------------ .CN Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcnownertype"] = "Registrant, Type";
$_LANG["cnrxcnownertypei"] = "Individual";
$_LANG["cnrxcnownertypee"] = "Entity";
$_LANG["cnrxcnownertypedescr"] = "";
$_LANG["cnrxcnowneridtype"] = "Registrant, ID Card Type";
$_LANG["cnrxcnowneridtypesfz"] = "身份证 (Chinese ID card)";
$_LANG["cnrxcnowneridtypehz"] = "户口 (Household registration)";
$_LANG["cnrxcnowneridtypegajmtx"] = "港澳居民来往内地通行证 (Mainland travel permit for Hong Kong and Macao residents)";
$_LANG["cnrxcnowneridtypetwjmtx"] = "台湾居民来往大陆通行证 (Mainland travel permit for Taiwan residents)";
$_LANG["cnrxcnowneridtypewjlsfz"] = "外国人永久居留身份证 (Foreigner's permanent residence identity card)";
$_LANG["cnrxcnowneridtypegajzz"] = "港澳居住证 (Hong Kong and Macao residence permit)";
$_LANG["cnrxcnowneridtypetwjzz"] = "台湾居住证 (Taiwan residence permit)";
$_LANG["cnrxcnowneridtypejgz"] = "军官证 (Officer's certificate)";
$_LANG["cnrxcnowneridtypeqt"] = "其他 (Other)";
$_LANG["cnrxcnowneridtypeorg"] = "组织机构代码证 (Organization code certificate)";
$_LANG["cnrxcnowneridtypeyyzz"] = "工商营业执照 (Business license)";
$_LANG["cnrxcnowneridtypetydm"] = "统一社会信用代码证书 (Unified social credit code certificate)";
$_LANG["cnrxcnowneridtypebddm"] = "部队代码 (Military code)";
$_LANG["cnrxcnowneridtypejddwfw"] = "军队单位对外有偿服务许可证 (Military unit paid service license)";
$_LANG["cnrxcnowneridtypesydwfr"] = "事业单位法人证书 (Public institution legal person certificate)";
$_LANG["cnrxcnowneridtypewgczjg"] = "外国常驻记者机构批准登记证 (Foreign correspondent institution registration certificate)";
$_LANG["cnrxcnowneridtypeshttfr"] = "社会团体法人登记证书 (Social organization legal person certificate)";
$_LANG["cnrxcnowneridtypezjcs"] = "宗教活动场所登记证 (Religious activity site registration certificate)";
$_LANG["cnrxcnowneridtypembfqy"] = "民办非企业单位登记证书 (Private non-enterprise unit certificate)";
$_LANG["cnrxcnowneridtypejjhfr"] = "基金会法人登记证书 (Foundation legal person certificate)";
$_LANG["cnrxcnowneridtypelszy"] = "律师执业证 (Lawyer's practice certificate)";
$_LANG["cnrxcnowneridtypewgzhwh"] = "外国在华文化中心登记证 (Foreign cultural center in China registration certificate)";
$_LANG["cnrxcnowneridtypewlczzg"] = "外国政府旅游部门常驻代表机构批准登记证 (Foreign government tourism office registration certificate)";
$_LANG["cnrxcnowneridtypesfjd"] = "司法鉴定许可证 (Forensic identification license)";
$_LANG["cnrxcnowneridtypejwjg"] = "境外机构证件 (Overseas organization certificate)";
$_LANG["cnrxcnowneridtypeshfwjg"] = "社会服务机构登记证书 (Social service organization registration certificate)";
$_LANG["cnrxcnowneridtypembxxbx"] = "民办学校办学许可证 (Private school license)";
$_LANG["cnrxcnowneridtypeyljgzy"] = "医疗机构执业许可证 (Medical institution practice license)";
$_LANG["cnrxcnowneridtypegzjgzy"] = "公证机构执业证 (Notary office practice certificate)";
$_LANG["cnrxcnowneridtypebjwsxx"] = "外国企业常驻代表机构登记证 (Foreign enterprise representative office registration certificate)";
$_LANG["cnrxcnowneridtypeqttyzm"] = "其他证明 (Other certificate)";
$_LANG["cnrxcnowneridtypedescr"] = "";
$_LANG["cnrxcnowneridnumber"] = "Registrant, ID Card Number";
$_LANG["cnrxcnowneridnumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COOP Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcoopeligibility"] = "Cooperative Eligibility";
$_LANG["cnrxcoopeligibilitydescr"] = "Cooperatives are eligible to register .coop domains.";
$_LANG["cnrxcoopeligibility0"] = "I am not eligible";
$_LANG["cnrxcoopeligibility1"] = "I am eligible as a cooperative";

// ----------------------------------------------------------------------
// ------------------ .DE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdensentry0"] = "Domaininhaber, Aktion bei Providerwechsel - Zone aktualisieren?";
$_LANG["cnrxdensentry0descr"] = "Zone löschen und automatisch neue Zone anhand übermittelter Daten erzeugen.";
$_LANG["cnrxdensentry1"] = "Domaininhaber, Aktion bei Providerwechsel - Zone löschen?";
$_LANG["cnrxdensentry1descr"] = "Zone löschen.";
$_LANG["cnrxdensentry2"] = "Domaininhaber, Aktion bei Providerwechsel - Zone beibehalten?";
$_LANG["cnrxdensentry2descr"] = "Zone beibehalten.";
$_LANG["cnrxdensentry3"] = "Domaininhaber, Rolleninhaber ändern?";
$_LANG["cnrxdensentry3descr"] = "Administrative Verwaltung (Admin-C) und Technische Verwaltung (Tech-C) auf übermittelte Handles ändern.";
$_LANG["cnrxdensentry4"] = "Domaininhaber, Rolleninhaber beibehalten?";
$_LANG["cnrxdensentry4descr"] = "Administrative Verwaltung (Admin-C) und Technische Verwaltung (Tech-C) beibehalten.";
$_LANG["cnrxdegeneralrequest"] = "Generel meddelelse til DENIC";
$_LANG["cnrxdegeneralrequestdescr"] = "Her kan du angive andre meddelelser til DENIC.";
$_LANG["cnrxdeabusecontact"] = "Misbrug kontaktoplysninger";
//$_LANG["cnrxdeabusecontactdescr "] = "";

// ----------------------------------------------------------------------
// ------------------ .DK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdkusertype"] = "Registrant, brugertype";
$_LANG["cnrxdkusertypeperson"] = "Person";
$_LANG["cnrxdkusertypecompany"] = "Virksomhed";
$_LANG["cnrxdkusertypeassociation"] = "Forening";
$_LANG["cnrxdkusertypepuborg"] = "Offentlig organisation";
$_LANG["cnrxdkusertypedescr"] = "";
$_LANG["cnrxdkuseridnumber"] = "Registrant, CVR/SE/P-nummer eller fødselsdato";
$_LANG["cnrxdkuseridnumberdescr"] = "Angiv CVR-nr. for virksomheder, SE-nr. for forening eller offentlig organisation, P-nummer for produktionsenhed eller fødselsdato (YYYY-MM-DD) for privatpersoner.";

// ----------------------------------------------------------------------
// ------------------ .ES Fields ----------------------------------------
// ----------------------------------------------------------------------
$types = [
    1 => "Enkeltperson",
    39 => "Økonomisk Interessegruppe",
    47 => "Forening",
    59 => "Idrætsforening",
    68 => "Faglig Forening",
    124 => "Sparekasse",
    150 => "Fælleseje",
    152 => "Ejerforening",
    164 => "Orden eller Religiøs Institution",
    181 => "Konsulat",
    197 => "Offentligretlig Forening",
    203 => "Ambassade",
    229 => "Lokal Myndighed",
    269 => "Idræts Forbund",
    286 => "Fond",
    365 => "Gensidigt Forsikringsselskab",
    434 => "Regional Regeringsmyndighed",
    436 => "Central Regeringsmyndighed",
    439 => "Politisk Parti",
    476 => "Fagforening",
    510 => "Landbrugspartnerskab",
    524 => "Aktieselskab",
    525 => "Sportsforening",
    554 => "Civilsamfund",
    560 => "Interessentskab",
    562 => "Kommanditselskab",
    566 => "Andelsselskab",
    608 => "Medarbejderejet Virksomhed",
    612 => "Anpartsselskab",
    713 => "Spansk Kontor",
    717 => "Midlertidig Virksomhedsalliance",
    744 => "Medarbejderejet Anpartsselskab",
    745 => "Regional Offentlig Enhed",
    746 => "National Offentlig Enhed",
    747 => "Lokal Offentlig Enhed",
    877 => "Andet",
    878 => "Oprindelsesbetegnelse Tilsynsråd",
    879 => "Enhed til Forvaltning af Naturområder"
];
$idtypes = [
    0 => "Andet (for kontakter uden for Spanien)",
    1 => "DNI/NIF (for spanske kontakter)",
    2 => "Forældet, brug næste mulighed i stedet.",
    3 => "NIE (for spanske kontakter)",
    4 => "Momsnummer - kun gyldigt for ikke-spanske juridiske enheder"
];
$idtypesdescr = implode("<br/>", [
    "DNI = &quot;Documento Nacional de Identidad&quot;",
    "NIF = &quot;Número de Identificación Fiscal&quot;",
    "NIE = &quot;Número de Identificación de Extranjero&quot;. Det er ækvivalenten til et spansk NIF, men udstedt af spanske myndigheder til udlændinge, der planlægger at blive i Spanien i mere end 3 måneder."
]);
$idnodescr = "Identifikationsnummeret for denne kontakt. For spanske kontakter er dette DNI/NIF/NIE-nummeret - ellers ID-kort- eller pasnummeret.";

$_LANG["cnrxesownertipoidentificacion"] = "Registrant, Identificeringstype";
$_LANG["cnrxesadmintipoidentificacion"] = "Administrator, Identificeringstype";
$_LANG["cnrxestechtipoidentificacion"] = "Teknisk, Identificeringstype";
$_LANG["cnrxesbillingtipoidentificacion"] = "Fakturering, Identificeringstype";

foreach ($idtypes as $key => $value) {
    $_LANG["cnrxesownertipoidentificacion$key"] = $value;
    $_LANG["cnrxesadmintipoidentificacion$key"] = $value;
    $_LANG["cnrxestechtipoidentificacion$key"] = $value;
    $_LANG["cnrxesbillingtipoidentificacion$key"] = $value;
}

$_LANG["cnrxesownertipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesadmintipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxestechtipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesbillingtipoidentificaciondescr"] = $idtypesdescr;

$_LANG["cnrxesowneridentificacion"] = "Registrant, Identifikationsnummer";
$_LANG["cnrxesadminidentificacion"] = "Administrator, Identifikationsnummer";
$_LANG["cnrxestechidentificacion"] = "Teknisk, Identifikationsnummer";
$_LANG["cnrxesbillingidentificacion"] = "Fakturering, Identifikationsnummer";

$_LANG["cnrxesowneridentificaciondescr"] = $idnodescr;
$_LANG["cnrxesadminidentificaciondescr"] = $idnodescr;
$_LANG["cnrxestechidentificaciondescr"] = $idnodescr;
$_LANG["cnrxesbillingidentificaciondescr"] = $idnodescr;

$_LANG["cnrxesownerlegalform"] = "Registrant, Juridisk Form";
$_LANG["cnrxesadminlegalform"] = "Administrator, Juridisk Form";
$_LANG["cnrxestechlegalform"] = "Teknisk, Juridisk Form";
$_LANG["cnrxesbillinglegalform"] = "Fakturering, Juridisk Form";

foreach ($types as $key => $value) {
    $_LANG["cnrxesownerlegalform$key"] = $value;
    $_LANG["cnrxesadminlegalform$key"] = $value;
    $_LANG["cnrxestechlegalform$key"] = $value;
    $_LANG["cnrxesbillinglegalform$key"] = $value;
}

$_LANG["cnrxesownerlegalformdescr"] = "";
$_LANG["cnrxesadminlegalformdescr"] = "";
$_LANG["cnrxestechlegalformdescr"] = "";
$_LANG["cnrxesbillinglegalformdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .EU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxeuregistrantlang"] = "Registrant, Language";
$_LANG["cnrxeuregistrantcitizenship"] = "Registrant, Country of Citizenship";
$_LANG["cnrxeuregistrantlangdescr"] = "Any of the official EU languages";
$_LANG["cnrxeuregistrantcitizenshipdescr"] = "Two letter country code of an EU member state";

// ----------------------------------------------------------------------
// ------------------ .FI Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxficompanyregid"] = "Registrant, Company Registration ID";
$_LANG["cnrxficompanyregiddescr"] = "Company, Organisation or Association. Contact should be an Organisation. Format: 1234567-8";
$_LANG["cnrxfipersonalid"] = "Registrant, Finnish Personal Identity Code";
$_LANG["cnrxfipersonaliddescr"] = "Contact should be an Individual. Valid Finnish personal identity code (format: DDMMYYCZZZQ)";
$_LANG["cnrxfibirthdate"] = "Registrant, Date of Birth (DD.MM.YYYY)";
$_LANG["cnrxfibirthdatedescr"] = "Not Resident in Finland";
$_LANG["cnrxficontacttype"] = "Registrant, Type of Contact";
$_LANG["cnrxficontacttype0"] = "Private person";
$_LANG["cnrxficontacttype1"] = "Company";
$_LANG["cnrxficontacttype2"] = "Corporation";
$_LANG["cnrxficontacttype3"] = "Institution";
$_LANG["cnrxficontacttype4"] = "Political party";
$_LANG["cnrxficontacttype5"] = "Municipality";
$_LANG["cnrxficontacttype6"] = "Government";
$_LANG["cnrxficontacttype7"] = "Public community";
$_LANG["cnrxficontacttypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .GAY Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxgayacceptrequirements"] = "Registrant, .gay Domain Agreement";
$_LANG["cnrxgayacceptrequirements0"] = "I disagree";
$_LANG["cnrxgayacceptrequirements1"] = "I agree to the requirements set forth in the .gay Domain Name Registration Agreement.";
$_LANG["cnrxgayacceptrequirementsdescr"] = "To register a .gay domain, I must agree that my website will not contain disparaging content including, but not limited to: speech or content discriminating against or denigrating any person or group of persons on the basis of race, color, religion, ethnicity, national origin, citizenship, gender, gender identity, sexual orientation, or disability; speech or content that constitutes bullying or harassment of others; or incite others to violence.";

// ----------------------------------------------------------------------
// ------------------ .HK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxhkownerdocumenttype"] = "Registrant, Document Type";
$_LANG["cnrxhkownerdocumenttypehkid"] = "Hong Kong Identity Number (Only applicable for Hong Kong permanent residents)";
$_LANG["cnrxhkownerdocumenttypeothid"] = "Identity Number (For applicants holding identity card or equivalent document that has not been issued by the Hong Kong SAR Government)";
$_LANG["cnrxhkownerdocumenttypepassno"] = "Passport Number";
$_LANG["cnrxhkownerdocumenttypebirthcert"] = "Birth Certificate";
$_LANG["cnrxhkownerdocumenttypeothidv"] = "Others (Individual)";
$_LANG["cnrxhkownerdocumenttypebr"] = "Hong Kong Business Registration Certificate Number";
$_LANG["cnrxhkownerdocumenttypeci"] = "Hong Kong Certificate of Incorporation Number";
$_LANG["cnrxhkownerdocumenttypecrs"] = "Certificate of Registration of a School under the Hong Kong Education Ordinance";
$_LANG["cnrxhkownerdocumenttypehksarg"] = "Registration Number Assigned to a company by the Hong Kong SAR Government for tax purposes";
$_LANG["cnrxhkownerdocumenttypehkordinance"] = "Registration Number Assigned by a body incorporated by an Ordinance of Hong Kong";
$_LANG["cnrxhkownerdocumenttypeothorg"] = "Others (Organisation)";
$_LANG["cnrxhkownerdocumenttypedescr"] = "The type of document which will be used by the registrant to prove their identity";
$_LANG["cnrxhkownerdocumentnumber"] = "Registrant, Document Number";
$_LANG["cnrxhkownerdocumentnumberdescr"] = "The number of the document by which the registrant will prove their identity";
$_LANG["cnrxhkownerdocumentorigincountry"] = "Registrant, Document Origin Country";
$_LANG["cnrxhkownerdocumentorigincountrydescr"] = "The country code from which the identification document was issued";
$_LANG["cnrxhkownerotherdocumenttype"] = "Registrant, Specify Other Document Type";
$_LANG["cnrxhkownerotherdocumenttypedescr"] = "The type of document (for document types OTHIDV and OTHORG)";
$_LANG["cnrxhkdomaincategory"] = "Registrant, Domain Category";
$_LANG["cnrxhkdomaincategoryi"] = "Individual";
$_LANG["cnrxhkdomaincategoryo"] = "Organisation";
$_LANG["cnrxhkdomaincategorydescr"] = "Whether an individual or organization is registering the domain";
$_LANG["cnrxhkownerageover18"] = "Registrant, Aged Over 18";
$_LANG["cnrxhkownerageover18no"] = "Under 18";
$_LANG["cnrxhkownerageover18yes"] = "Over 18";
$_LANG["cnrxhkownerageover18descr"] = "Whether the registrant is over the age of 18. Required to be at least 18";

// ----------------------------------------------------------------------
// ------------------ .IE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxiecontacttype"] = "Registrant, Contact Type";
$_LANG["cnrxiecontacttypecom"] = "Commercial";
$_LANG["cnrxiecontacttypecha"] = "Charity";
$_LANG["cnrxiecontacttypeoth"] = "Other (Personal, Club, Band, Sole-Trader, etc.)";
$_LANG["cnrxiecontacttypedescr"] = "";
$_LANG["cnrxielanguage"] = "Registrant, Language";
$_LANG["cnrxielanguageen"] = "English";
$_LANG["cnrxielanguagefr"] = "French / Français";
$_LANG["cnrxielanguagedescr"] = "Preferred language (e.g., for forms, emails, etc.)";
$_LANG["cnrxiecronumber"] = "Registrant, CRO Number";
$_LANG["cnrxiecronumberdescr"] = "CRO (Companies Registration Office) Number / Business Number (Required for companies)";
$_LANG["cnrxiesupportingnumber"] = "Registrant, Supporting Number";
$_LANG["cnrxiesupportingnumberdescr"] = "Trademark Number, CHY Number (Charity), etc. (Required for charities, see documentation)";

// ----------------------------------------------------------------------
// ------------------ .IT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxitconsentforpublishing"] = "Consent for Publishing of Personal Data in Public WHOIS";
$_LANG["cnrxitconsentforpublishing0"] = $_LANG["cnr0"];
$_LANG["cnrxitconsentforpublishing1"] = $_LANG["cnr1"];
$_LANG["cnrxitconsentforpublishingdescr"] = "";
$_LANG["cnrxitentitytype"] = "Registrant, Entity Type";
$_LANG["cnrxitentitytype1"] = "Italian and foreign natural persons";
$_LANG["cnrxitentitytype2"] = "Companies/one-man companies";
$_LANG["cnrxitentitytype3"] = "Freelance workers/professionals";
$_LANG["cnrxitentitytype4"] = "Non-profit organizations";
$_LANG["cnrxitentitytype5"] = "Public organizations";
$_LANG["cnrxitentitytype6"] = "Other entities";
$_LANG["cnrxitentitytype7"] = "Foreigners with no other indication";
$_LANG["cnrxitentitytypedescr"] = "";
$_LANG["cnrxitpin"] = "Registrant, Tax ID / Personal Identification Number";
$_LANG["cnrxitpindescr"] = "For entity type 1, 3: Italian and foreign natural persons: Tax ID for Italians; Passport number for foreigners<br/>For entity type 2-6: Valid VAT number";
$_LANG["cnrxitnationality"] = "Registrant, Nationality";
$_LANG["cnrxitnationalitydescr"] = "Two letter country code (required for natural persons, EU companies & freelancers in EU countries)";
$_LANG["cnrxitsect3liability"] = "I declare that I am aware of and accept liability in accordance with the Italian laws in force (Articles 1, 2, 3 of the Italian Law)";
$_LANG["cnrxitsect3liabilitydescr"] = "";
$_LANG["cnrxitsect3liability0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect3liability1"] = $_LANG["cnr1"];
$_LANG["cnrxitsect5personaldataforregistration"] = "I declare that I have read and understood the information set out in Articles 5, 6 and 7 of the Registration Rules and I authorize the processing of my personal data for the purposes indicated";
$_LANG["cnrxitsect5personaldataforregistrationdescr"] = "";
$_LANG["cnrxitsect5personaldataforregistration0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect5personaldataforregistration1"] = $_LANG["cnr1"];
$_LANG["cnrxitsect6personaldatafordiffusion"] = "I consent to my personal data being disclosed and disseminated";
$_LANG["cnrxitsect6personaldatafordiffusiondescr"] = "";
$_LANG["cnrxitsect6personaldatafordiffusion0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect6personaldatafordiffusion1"] = $_LANG["cnr1"];
$_LANG["cnrxitsect7explicitacceptance"] = "I explicitly accept the points a), b), c) as laid down in Section 7 of the Registration Rules, and I am aware of the consequences of not complying with the legal requirements";
$_LANG["cnrxitsect7explicitacceptancedescr"] = "";
$_LANG["cnrxitsect7explicitacceptance0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect7explicitacceptance1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .LV Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxlvownerregnr"] = "Registrant, Registration number";
$_LANG["cnrxlvownerregnrdescr"] = "(required for legal entities)";
$_LANG["cnrxlvadminregnr"] = "Administrative Contact, Registration number";
$_LANG["cnrxlvadminregnrdescr"] = "(required for legal entities)";
$_LANG["cnrxlvvatnr"] = "VAT number";
$_LANG["cnrxlvvatnrdescr"] = "(optional; for legal entities only)";

// ----------------------------------------------------------------------
// ------------------ .LT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxltcompanynumber"] = "Registrant, Company Number";
$_LANG["cnrxltcompanynumberdescr"] = "(required for legal entities/organisations)";

// ----------------------------------------------------------------------
// ------------------ .MY Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxmybusinessnumber"] = "Registrant, Business Registration Number";
$_LANG["cnrxmybusinessnumberdescr"] = "(required for organisations)";
$_LANG["cnrxmyorganizationtype"] = "Registrant, Organisation Type";
$_LANG["cnrxmyorganizationtypedescr"] = "Select Applicable";
$_LANG["cnrxmyperidentity"] = "Registrant, Identity Card Number (NRIC, Passport or Police/Army ID)";
$_LANG["cnrxmyperidentitydescr"] = "(required for individuals)";
$_LANG["cnrxmyperdateofbirth"] = "Registrant, Date of Birth";
$_LANG["cnrxmyperdateofbirthdescr"] = "Format: DD/MM/YYYY (required for individuals)";
$_LANG["cnrxmyrace"] = "Registrant, Race";
$_LANG["cnrxmyracemalay"] = "Malay";
$_LANG["cnrxmyracechinese"] = "Chinese";
$_LANG["cnrxmyraceindian"] = "Indian";
$_LANG["cnrxmyraceothers"] = "Others";
$_LANG["cnrxmyracedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .NO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnoorganizationnumber"] = "Registrant, Organisasjonsnummer";
$_LANG["cnrxnoorganizationnumberdescr"] = "(påkrevd for organisasjoner)";
$_LANG["cnrxnopersonidentifier"] = "Registrant, Fødselsnummer eller D-nummer";
$_LANG["cnrxnopersonidentifierdescr"] = "(påkrevd for privatpersoner)";

// ----------------------------------------------------------------------
// ------------------ .NU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnuiisidno"] = "Registrant, ID Number";
$_LANG["cnrxnuiisidnodescr"] = "Personal ID Number (for individuals) or Organisation Number (for organisations).";
$_LANG["cnrxnuiisvatno"] = "Registrant, VAT Number";
$_LANG["cnrxnuiisvatnodescr"] = "VAT Number (for organisations).";

// ----------------------------------------------------------------------
// ------------------ .NYC Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnycextcontact"] = "Contact Name";
$_LANG["cnrxnycextcontactadmin"] = "Administrative Contact";
$_LANG["cnrxnycextcontacttech"] = "Technical Contact";
$_LANG["cnrxnycextcontactbilling"] = "Billing Contact";
$_LANG["cnrxnycextcontactowner"] = "Registrant";
$_LANG["cnrxnycextcontactdescr"] = "Nexus Requirements for NYC (Select applicable)";

// ----------------------------------------------------------------------
// ------------------ .PARIS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxafniccode"] = $_LANG["cnrxallocationtoken"];
$_LANG["cnrxafniccodedescr"] = $_LANG["cnrxallocationtokendescr"];

// ----------------------------------------------------------------------
// ------------------ .FR, .PM, .RE, .TF, .WF, .YT Fields, Boilerplate --
// ----------------------------------------------------------------------
// Organizations (Companies, Associations, etc.)
$_LANG["cnrxfrannounce"] = "Organisation/Company, Announcement No.<br/>(Journal Officiel)";
$_LANG["cnrxfrannouncedescr"] = implode(" ", [
    "Organisation/Company only (associations/companies). Leave blank for individuals.<br/>",
    "Journal Officiel announcement number (digits only).",
    "If you use Journal Officiel details as your identifier, please provide all related JO fields:",
    "Date of Publication, Announcement No., Page No. and Date of Association."
]);
$_LANG["cnrxfrdatepublicationjo"] = "Organisation/Company, Date of Publication<br/>(Journal Officiel)";
$_LANG["cnrxfrdatepublicationjodescr"] = "Organisation/Company only (associations/companies). Leave blank for individuals. Journal Officiel Date of Publication (YYYY-MM-DD).";
$_LANG["cnrxfrnumerodepageannouncejo"] = "Organisation/Company, Page No.<br/>(Journal Officiel)";
$_LANG["cnrxfrnumerodepageannouncejodescr"] = "Organisation/Company only (associations/companies). Leave blank for individuals. Journal Officiel Page Number (digits only).";
$_LANG["cnrxfrwaldec"] = "Organisation/Company, Waldec Number";
$_LANG["cnrxfrwaldecdescr"] = "Organisation/Company only (associations). Leave blank for individuals. Issued by prefecture. Format: Association Waldec Identifier (9 digits) issued by French prefecture or sub-prefecture or 'aucun' (if not applicable).";
$_LANG["cnrxfrdateassociation"] = "Organisation/Company, Creation Date";
$_LANG["cnrxfrdateassociationdescr"] = "Organisation/Company only (associations/companies). Leave blank for individuals. Date of creation/registration of the organisation (YYYY-MM-DD).";
$_LANG["cnrxfrduns"] = "Organisation/Company, DUNS Number";
$_LANG["cnrxfrdunsdescr"] = "Organisation/Company only (associations/companies). Leave blank for individuals. Dun & Bradstreet DUNS number (if applicable, 9 digits only).";
$_LANG["cnrxfrlocal"] = "Organisation/Company, Other Local ID";
$_LANG["cnrxfrlocaldescr"] = "Organisation/Company only (associations/companies). Leave blank for individuals. Other local identifier where applicable.";
$_LANG["cnrxfrnoprezonecheck0"] = "Do NOT skip the DNS check before registration";
$_LANG["cnrxfrnoprezonecheck1"] = "Skip the DNS check before registration";
$_LANG["cnrxfrsirenorsiret"] = "Organisation/Company, SIREN or SIRET Number";
$_LANG["cnrxfrsirenorsiretdescr"] = "Organisation/Company only (companies). Leave blank for individuals and associations. SIREN number (9 digits) or SIRET number (14 digits, SIREN + 5 digits).";
$_LANG["cnrxfrtrademark"] = "Organisation/Company, Trademark Number";
$_LANG["cnrxfrtrademarkdescr"] = "Organisation/Company only. Leave blank for individuals. Trademark Number/Holder (if applicable).";
$_LANG["cnrxfrvatid"] = "Organisation/Company, VAT Number";
$_LANG["cnrxfrvatiddescr"] = "Organisation/Company only. Leave blank for individuals. Intra-community VAT identifier (starting with country code like FR for France, DE for Germany, etc., 2 letters + numbers).";
// Individuals
$_LANG["cnrxfrbirthpc"] = "Individual, Birth Postal Code";
$_LANG["cnrxfrbirthpcdescr"] = "Individuals only. Format: 5-digit postal code of birth location or 99999 (for foreign countries).";
$_LANG["cnrxfrbirthcity"] = "Individual, Birth City";
$_LANG["cnrxfrbirthcitydescr"] = "Individuals only. City of Birth (max 255 characters).";
$_LANG["cnrxfrbirthdate"] = "Individual, Birth Date";
$_LANG["cnrxfrbirthdatedescr"] = "Individuals only. Date of birth (YYYY-MM-DD).";
$_LANG["cnrxfrbirthplace"] = "Individual, Birth Place";
$_LANG["cnrxfrbirthplacedescr"] = "Individuals only. Leave blank for organisations. Format: Department number of birth location (French department code, 2 or 3 alphanumeric characters) or 99 for births outside France.";
$_LANG["cnrxfrrestrictpub"] = "Registrant, Restrict Publication";
$_LANG["cnrxfrrestrictpub0"] = "Allow Personal Data Publication (Note that European privacy laws may still apply)";
$_LANG["cnrxfrrestrictpub1"] = "Do Not Publish Personal Data in Public WHOIS";
$_LANG["cnrxfrrestrictpubdescr"] = "Individuals only. Whether personal information should be restricted from public WHOIS (Note that the registry may override this option based on GDPR, local laws or policies). Leave default (unchecked / unrestricted) for organisations.";
$_LANG["cnrxfrnoprezonecheck"] = "Skip Pre-Registration DNS Check";
$_LANG["cnrxfrnoprezonecheckdescr"] = "By default, AFNIC requires that valid nameservers and a DNS zone are configured before a .fr domain can be registered. If you want to bypass this check and register the domain name even without a working zone, select 'Skip the DNS check before registration'. The domain will still be registered even if the DNS zone is not yet configured. You can set up the DNS zone later.";

// ----------------------------------------------------------------------
// ------------------ .PT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxpttechidentification"] = "Technical Contact, ROID or Personal Identification";
$_LANG["cnrxpttechidentificationdescr"] = "For companies: Certificate of Registry Identification (ROID). For private persons: Personal identification number / VAT number.";
$_LANG["cnrxptowneridentification"] = "Registrant, ROID or Personal Identification";
$_LANG["cnrxptowneridentificationdescr"] = "For companies: Certificate of Registry Identification (ROID). For private persons: Personal identification number / VAT number.";
$_LANG["cnrxpttechmobile"] = "Technical Contact, Mobile Phone Number";
$_LANG["cnrxpttechmobiledescr"] = "Format: +[country code][area code][telephone number]";
$_LANG["cnrxptownermobile"] = "Registrant, Mobile Phone Number";
$_LANG["cnrxptownermobiledescr"] = "Format: +[country code][area code][telephone number]";

// ----------------------------------------------------------------------
// ------------------ .RO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrocompanynumber"] = "Registrant, Company Number";
$_LANG["cnrxrocompanynumberdescr"] = "(påkrævet kun for virksomheder)";
$_LANG["cnrxroidcardorpassportnumber"] = "Registrant, ID-kort eller pasnummer";
$_LANG["cnrxroidcardorpassportnumberdescr"] = "(påkrævet kun for privatpersoner)";
$_LANG["cnrxrovatnumber"] = "Registrant, momsnummer";
$_LANG["cnrxrovatnumberdescr"] = "(påkrævet kun for virksomheder)";

// ----------------------------------------------------------------------
// ------------------ .RU Fields, Boilerplate ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrubirthdate"] = "Registrant, Date of Birth";
$_LANG["cnrxrubirthdatedescr"] = "The Date of Birth of the Registrant (DD.MM.YYYY)<br/>(required for Individuals only)";
$_LANG["cnrxrufirstname"] = "Registrant, First Name";
$_LANG["cnrxrufirstnamedescr"] = "The First Name of the Registrant in Russian. To be filled with Russian and Latin letters, no dots.<br/>(required for Individuals only)";
$_LANG["cnrxrumiddlename"] = "Registrant, Middle Name";
$_LANG["cnrxrumiddlenamedescr"] = "The Middle Name/Patronymic Name of the Registrant in Russian. To be filled with Russian and Latin letters, no dots.<br/>(required for Individuals only)";
$_LANG["cnrxrulastname"] = "Registrant, Last Name";
$_LANG["cnrxrulastnamedescr"] = "The Last Name of the Registrant in Russian. To be filled with Russian and Latin letters, no dots.<br/>(required for Individuals only)";
$_LANG["cnrxruorganization"] = "Registrant, Organisation Name";
$_LANG["cnrxruorganizationdescr"] = "Registered organisation name, in Russian (required for legal entities only).";
$_LANG["cnrxrucode"] = "Registrant, TIN (Taxpayer ID)";
$_LANG["cnrxrucodedescr"] = "Taxpayer Identification Number (TIN) in Russian Federation<br/>(required for legal entities)";
$_LANG["cnrxrukpp"] = "Registrant, KPP (Territory-linked TIN)";
$_LANG["cnrxrukppdescr"] = "Territory-linked Taxpayer Number (KPP) in Russian Federation<br/>(optional for legal entities, if assigned)";
$_LANG["cnrxrupassportdata"] = "Registrant, Passport Data";
$_LANG["cnrxrupassportdatadescr"] = "Series and Number, Issue Date, Issuing Authority<br/>(required for Individuals only). Example: '1234 567890 issued on 01.01.2001 by Moscow Police Department' – format not strictly enforced, supply relevant details about your identity document in one line.";

// ----------------------------------------------------------------------
// ------------------ .SE (Sweden), .NU Fields --------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnicseidnumber"] = "Registrant, ID Number";
$_LANG["cnrxnicseidnumberdescr"] = "Personal ID Number (personnummer/samordningsnummer, YYMMDDXXXX for Swedish citizens/residents) or Organisation Number (organisationsnummer, 10 digits for companies/organisations).";
$_LANG["cnrxnicsevatid"] = "Registrant, VAT Number";
$_LANG["cnrxnicsevatiddescr"] = "VAT Number (for EU organisations outside of Sweden, if no Swedish org.nr available).";
$_LANG["cnrxsediscloseemail"] = "Disclose Email Address in Public WHOIS";
$_LANG["cnrxsediscloseemaildescr"] = "By default your email address is NOT displayed publicly. Check this box to make your email address publicly visible in WHOIS.";
$_LANG["cnrxsedisclosefax"] = "Disclose Fax Number in Public WHOIS";
$_LANG["cnrxsedisclosefaxdescr"] = "By default your fax number is NOT displayed publicly. Check this box to make your fax number publicly visible in WHOIS.";
$_LANG["cnrxsedisclosevoice"] = "Disclose Phone Number in Public WHOIS";
$_LANG["cnrxsedisclosevoicedescr"] = "By default your phone number is NOT displayed publicly. Check this box to make your phone number publicly visible in WHOIS.";

// ----------------------------------------------------------------------
// ------------------ .SG Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxsgrcbid"] = "Registrant, Company Registration Number (RCB ID)";
$_LANG["cnrxsgrcbiddescr"] = "Singapore Company Registration Number (For Organisations / Corporate Bodies)";
$_LANG["cnrxsgadminsingpassid"] = "Administrative Contact, Singapore ID (SingPass ID)";
$_LANG["cnrxsgadminsingpassiddescr"] = "Singapore ID (NRIC/FIN for individuals, or UEN for organisations)";

// ----------------------------------------------------------------------
// ------------------ .SK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxskcontactlegalform"] = "Registrant, Legal Form";
$_LANG["cnrxskcontactlegalformdescr"] = "Are you a Private Person or a Legal Entity?";
$_LANG["cnrxskcontactlegalformcorp"] = "Legal Entity / Organisation";
$_LANG["cnrxskcontactlegalformpers"] = "Private Person";
$_LANG["cnrxskcontactidentnumber"] = "Registrant, Identity Number";
$_LANG["cnrxskcontactidentnumberdescr"] = "Identity Number: RC number (for organisations) or birth number/other identity number (for individuals).";

// ----------------------------------------------------------------------
// ------------------ .SWISS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxswissuid"] = "Registrant, Swiss UID / Enterprise ID";
$_LANG["cnrxswissuiddescr"] = "Swiss Enterprise ID (CHE number). Format: CHE-123.456.789 (required for enterprises). Individuals: Leave empty.";
$_LANG["cnrxswissownertype"] = "Registrant, Type";
$_LANG["cnrxswissownertypep"] = "Individual / Private Person";
$_LANG["cnrxswissownertypeo"] = "Organisation / Company";
$_LANG["cnrxswissownertypedescr"] = "Are you registering as an individual or as an organisation?";

// ----------------------------------------------------------------------
// ------------------ .TRAVEL Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxtravelindustry"] = "Registrant, Part of Travel Industry";
$_LANG["cnrxtravelindustryn"] = $_LANG["cnr0"];
$_LANG["cnrxtravelindustryy"] = $_LANG["cnr1"];
$_LANG["cnrxtravelindustrydescr"] = "Are you part of the travel industry and eligible for a .travel domain?";

// ----------------------------------------------------------------------
// ------------------ .UK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxukownercorporatetype"] = "Registrant, Corporate Type";
$_LANG["cnrxukownercorporatetypedescr"] = "Select the type of organisation / entity (leave as 'Other' for private individuals)";
$_LANG["cnrxukownercorporatetypeother"] = "Other / Private Individual";
$_LANG["cnrxukownercorporatetypefother"] = "Other Foreign";
$_LANG["cnrxukownercorporatetypeind"] = "UK Individual";
$_LANG["cnrxukownercorporatetypefind"] = "Non-UK Individual";
$_LANG["cnrxukownercorporatetypefcorp"] = "Non-UK Corporation";
$_LANG["cnrxukownercorporatetypeltd"] = "UK Limited Company";
$_LANG["cnrxukownercorporatetypeplc"] = "UK Public Limited Company";
$_LANG["cnrxukownercorporatetypellp"] = "UK Limited Liability Partnership";
$_LANG["cnrxukownercorporatetypeip"] = "UK Industrial/Provident Registered Company";
$_LANG["cnrxukownercorporatetypecrc"] = "UK Corporation by Royal Charter";
$_LANG["cnrxukownercorporatetypegov"] = "UK Government Body";
$_LANG["cnrxukownercorporatetypeptnr"] = "UK Partnership";
$_LANG["cnrxukownercorporatetyperchar"] = "UK Registered Charity";
$_LANG["cnrxukownercorporatetypesch"] = "UK School";
$_LANG["cnrxukownercorporatetypestat"] = "UK Statutory Body";
$_LANG["cnrxukownercorporatetypestra"] = "UK Sole Trader";
$_LANG["cnrxukownercorporatenumber"] = "Registrant, Company Registration Number";
$_LANG["cnrxukownercorporatenumberdescr"] = "Company Registration Number (if applicable, for organisations only)";

// ----------------------------------------------------------------------
// ------------------ .US Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxusnexusapppurpose"] = "Registrant, Purpose";
$_LANG["cnrxusnexusapppurposep1"] = "Business use for profit";
$_LANG["cnrxusnexusapppurposep2"] = "Non-profit business, club, association, religious organization, etc.";
$_LANG["cnrxusnexusapppurposep3"] = "Personal use";
$_LANG["cnrxusnexusapppurposep4"] = "Educational purposes";
$_LANG["cnrxusnexusapppurposep5"] = "Government purposes";
$_LANG["cnrxusnexusapppurposedescr"] = "Purpose for which the domain name will be used";
$_LANG["cnrxusnexuscategory"] = "Registrant, Nexus Category";
$_LANG["cnrxusnexuscategoryc11"] = "US Citizen or Permanent Resident";
$_LANG["cnrxusnexuscategoryc12"] = "Permanent Resident of the US or any US territory";
$_LANG["cnrxusnexuscategoryc21"] = "US Entity or Organization";
$_LANG["cnrxusnexuscategoryc31"] = "Foreign Entity with a bona fide presence in the US";
$_LANG["cnrxusnexuscategoryc32"] = "Foreign Entity with an office or property in the US";
$_LANG["cnrxusnexuscategorydescr"] = "Select a nexus category that describes your eligibility";
$_LANG["cnrxusnexusvalidator"] = "Registrant, Nexus Validator";
$_LANG["cnrxusnexusvalidatordescr"] = "Information to support your nexus category (optional, but may be required for dispute resolution, max. 255 characters)";

// ----------------------------------------------------------------------
// ------------------ .XXX Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxxxxcommunityid"] = "Registrant, Sponsored Community ID";
$_LANG["cnrxxxxcommunityiddescr"] = "ID of company or association related to the adult entertainment industry (if applicable, optional).";
$_LANG["cnrxxxxdefensive"] = "Defensive Registration";
$_LANG["cnrxxxxdefensive0"] = "No - This domain will actively provide adult content";
$_LANG["cnrxxxxdefensive1"] = "Yes - This is a defensive registration (does not provide adult content)";
$_LANG["cnrxxxxdefensivedescr"] = implode(" ", [
    "A defensive registration is defined as a domain name registration that is unique and does not resolve, redirects traffic to a",
    "primary registration or hosts no unique content. Such registrations are made to protect a brand or identity against abuse,",
    "such as cybersquatting. It is defined as a registration that is not unique, does not resolve,",
    "redirects traffic to a primary registration or hosts no unique content.<br/>",
    "Note: if not selected, the domain will be considered a defensive registration."
]);

// #########################################################################
// #########################################################################
// # Add reusable translations for ALL PROVIDERS                           #
// #########################################################################
// #########################################################################

/// ----------------------------------------------------------------------
// ---------------- EMAIL VERIFICATION ----------------------------------
// ----------------------------------------------------------------------
// $_LANG["cnicemailverification"] = "E-mail-verifikation";
// $_LANG["emailverificationtitle"] = "Bekræft din e-mail";
// $_LANG["emailverificationinfo"] = "Verifikation kræves for følgende kontaktinformation";
// $_LANG["emailverificationconsequences"] = "Hvis du ikke bekræfter din e-mail, kan dit domæne blive suspenderet.";
// $_LANG["emailverificationresendemailinfo"] = "Hvis du ikke har modtaget e-mailen, skal du klikke på knappen nedenfor for at gensende verifikations-e-mailen.";
// $_LANG["verified"] = "Verificeret";
// $_LANG["emailverificationpending"] = "Afventer";

// ----------------------------------------------------------------------
// ----------------------- DNSSEC MANAGEMENT ----------------------------
// ----------------------------------------------------------------------
$_LANG["cnicdnssecmanagement"] = "DNSSEC-administration";

// Statusmeddelelser
$_LANG["dnssecautomaticupdatesuccessmsg"] = "DNSSEC er blevet <span style=\"color:green;font-weight:bold;\">aktiveret</span> for dit domæne.<br> DNSSEC-posterne blev importeret fra din DNS-zone og opdateret hos din domæneregistrator.<br><br><span style=\"color:#007bff;\">For din sikkerhed hjælper DNSSEC med at beskytte dit domæne mod visse typer angreb ved at validere DNS-svar.</span>";
$_LANG["dnssecautoenable"] = "Aktiver DNSSEC og auto-importér DNSSEC-poster fra DNS-zone";
$_LANG["dnssecsyncrecords"] = "Synkroniser DNSSEC-poster fra DNS-zone";

// Posthåndtering
$_LANG["dnssecaddnewdskey"] = "Tilføj ny DS-nøgle";
$_LANG["dnssecaddnewkeyrecord"] = "Tilføj ny nøglepost";

// Modal dialog
$_LANG["dnssecconfirmdisable"] = "Er du sikker på, at du vil deaktivere DNSSEC for dette domæne? Denne handling kan påvirke domæneopløsning.";
$_LANG["dnssecmodaltitle"] = "Deaktiver DNSSEC";
$_LANG["dnssecmodalcancel"] = "Annuller";
$_LANG["dnssecmodaldisable"] = "Deaktiver DNSSEC";
