<?php

// #########################################################################
// #########################################################################
// # Add translations for CNR registrar module additional domain fields    #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ------------------ .DK Checkout Page ---------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrdkcheckoutheading"] = "Términos y Condiciones Generales para nombres de dominio .dk";
$_LANG["cnrdkcheckoutintro"] = "Para registrar un nombre de dominio .dk, debe celebrar un contrato con Punktum.dk A/S. Punktum dk es el administrador de todos los nombres de dominio .dk.";
$_LANG["cnrdkcheckoutdomains"] = "Nombres de dominio:";
$_LANG["cnrdkcheckoutregistrant"] = "Titular:";
$_LANG["cnrdkcheckoutregistrantaddress"] = "Ver arriba";
$_LANG["cnrdkcheckoutadmin"] = "Administrador del dominio:";
$_LANG["cnrdkcheckoutadminaddress"] = "Punktum dk A/S<br/>Ørestads Boulevard 108, 11. Stock<br/>DK-2300 Copenhague S";
$_LANG["cnrdkcheckouttac"] = implode("<br/><br/>", [
    "Por la presente acepto celebrar un contrato sobre el derecho de uso del nombre de dominio .dk especificado de acuerdo con los términos y condiciones aplicables. Esto significa, entre otras cosas, que garantizo que mis datos de contacto como titular estarán siempre actualizados. Realizaré la verificación de identidad de Punktum dk A/S si así se solicita.",
    "Mi derecho de uso del nombre de dominio .dk especificado puede ser transferido, suspendido, eliminado o bloqueado de acuerdo con los términos y condiciones de uso de Punktum dk A/S.",
    "De acuerdo con la sección 18 (2) (13) de la Ley de Contratos de Consumo danesa, renuncio al derecho de desistir del contrato sobre el derecho de uso del nombre de dominio .dk especificado.",
    "Doy mi consentimiento para que Punktum dk A/S, como administrador del dominio, utilice mis datos personales de acuerdo con su política de privacidad.",
    "Acepto pagar a este proveedor la tarifa por el primer período de registro del nombre de dominio .dk especificado y que el pago de los períodos de registro posteriores dependerá de mi elección de régimen de administración, según la sección 2.1 de los Términos y Condiciones Generales de Punktum dk A/S."
]);
$_LANG["cnrdkcheckouttacurl"] = "https://www.punktum.dk/en/articles/terms-and-conditions-for-the-right-of-use-to-a-dk-domain-name";
$_LANG["cnrdkcheckouttacurltext"] = "Términos y Condiciones Generales para el derecho de uso de un nombre de dominio .dk";
$_LANG["cnrdkcheckoutpolicyurl"] = "https://www.punktum.dk/en/articles/privacy-policy";
$_LANG["cnrdkcheckoutpolicyurltext"] = "Política de privacidad";
$_LANG["cnrdkcheckoutabouturl"] = "https://www.punktum.dk/en/about-us";
$_LANG["cnrdkcheckoutabouturltext"] = "Sobre Punktum dk A/S";
$_LANG["cnrdkcheckouttacagree"] = "Sí, acepto el acuerdo de usuario con Punktum dk A/S.";

// ----------------------------------------------------------------------
// ------------------ Common CNR Translations ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrchoose"] = "Por favor seleccione";
$_LANG["cnroptional"] = "opcional";
$_LANG["cnr1"] = "Sí";
$_LANG["cnr0"] = "No";
$_LANG["cnrconsentforpublishing"] = "Titular, consentimiento para publicación";
// .abogado, .aero, .attorney, .bank, .broker, .dentist, .forex, .insurance, .lotto, .law, .lawyer, .markets, .trading
$_LANG["cnrxallocationtoken"] = "Token de pedido del Registro";
$_LANG["cnrxallocationtokendescr"] = "Solo requerido para dominios premium. Emitido por el proveedor de la TLD. Contáctenos si necesita ayuda.";
// .app, .page, .dev, .new, .day, .channel, .boo, .foo, .zip, .mov, .nexus, .dad, .phd, .prof, .esq, .rsvp, .meme, .ing, .new
$_LANG["cnrxacceptsslrequirement"] = "Requisitos SSL";
$_LANG["cnrxacceptsslrequirementdescr"] = "Confirmo que entiendo y acepto los requisitos para HTTPS / un certificado SSL. Esta TLD es un dominio más seguro, lo que significa que HTTPS es obligatorio para todos los sitios web. Puede comprar su dominio ahora, pero para que funcione correctamente en los navegadores, debe configurar HTTPS basado en un certificado SSL.";
$_LANG["cnrxacceptsslrequirement0"] = $_LANG["cnr0"];
$_LANG["cnrxacceptsslrequirement1"] = $_LANG["cnr1"];
// .attorney, .dentist, .lawyer
$_LANG["cnrxunitedtldregulatorydata"] = "Información de la autoridad reguladora";
$_LANG["cnrxunitedtldregulatorydatadescr"] = "Información sobre la autoridad aprobadora/controladora/reguladora";
// .barcelona, .cat, .madrid, .scot, .sport, .swiss
$_LANG["cnrxintendeduse"] = "Uso previsto";
$_LANG["cnrxintendedusedescr"] = implode("<br/>", [
    "Declaración del uso previsto del nombre de dominio. Si corresponde, indique una referencia explícita al derecho reclamado por el solicitante sobre el nombre (si no es el nombre de la empresa del solicitante).",
    "Por ejemplo, si el nombre de dominio corresponde a una marca, debe indicarse el número de registro de la marca (máx. 256 caracteres)."
]);
// .mk
$_LANG["cnrxcompanyvatid"] = "Titular, NIF/CIF";
// $_LANG["cnrxcompanyvatiddescr"] = "";
// .nu, .se
$_LANG["cnrxrequestauthcode"] = "Solicitar nuevo código EPP";
$_LANG["cnrxrequestauthcode0"] = $_LANG["cnr0"];
$_LANG["cnrxrequestauthcode1"] = $_LANG["cnr1"];
$_LANG["cnrxrequestauthcodedescr"] = "Si desea transferir el dominio a otro registrador, necesita el código de autorización. Lo enviaremos al correo electrónico del titular del dominio.";

// NOTE: The following translations are labeled as boilerplate and should
// be used as a template for other languages. English texts are returned
// by default from the CNR Backend System. If you want to override these
// default texts, please consider a language override file in WHMCS using
// the below translation keys.
// We added some translations to override the API defaults which sometimes
// suck.

// ----------------------------------------------------------------------
// ------------------ DOMAIN DETAILS (and sub pages) --------------------
// ----------------------------------------------------------------------
$_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] = (
    "<small>Hemos encontrado algunos problemas con la información de contacto de su dominio que requieren su atención. Para resolverlo:<br/><br/><ol>" .
    "<li>Cambie al área de cliente (los campos adicionales también se enumeran allí, si corresponde)</li>" .
    "<li>Vaya a la página de <b>Información de Contacto</b> de este dominio</li>" .
    "<li>Realice las correcciones necesarias</li>" .
    "<li>Complete el proceso de verificación inmediatamente después si corresponde</li></ol></small>"
 );
$_LANG["cnrdomaincontactvalidationerrorsummary"] = (
    "<small>Hemos encontrado algunos problemas con la información de contacto de su dominio que requieren su atención. Para resolverlo:<br/><br/><ol>" .
    "<li>Vaya a la página de <b><a href=\"clientarea.php?action=domaincontacts&domainid=:domainid\">Información de Contacto</a></b> y revise sus datos</li>" .
    "<li>Realice las correcciones necesarias</li>" .
    "<li>Complete el proceso de verificación inmediatamente después si corresponde</li></ol></small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspensionadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Por favor, complete estos pasos antes del <b>:suspensiondate</b> para evitar que su dominio sea suspendido.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspension"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Por favor, complete estos pasos antes del <b>:suspensiondate</b> para evitar que su dominio sea suspendido.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspendedadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Su dominio ha sido suspendido. Por favor, complete estos pasos para reactivar su dominio.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspended"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Su dominio ha sido suspendido. Por favor, complete estos pasos para reactivar su dominio.</small>"
);

// ----------------------------------------------------------------------
// ------------------ .AERO Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaeroensauthid"] = "ID de miembro";
$_LANG["cnrxaeroensauthiddescr"] = "El ID de miembro .AERO es necesario para registrar un dominio en la industria aeronáutica. Puede solicitarlo <a style=\"text-decoration:underline\" href=\"https://information.aero/node/add/request-aero-id\" target=\"_blank\">aquí</a>.";
$_LANG["cnrxaeroensauthkey"] = "Contraseña de miembro";
$_LANG["cnrxaeroensauthkeydescr"] = "La contraseña/código de autenticación proporcionado junto con el ID de miembro .AERO en el sitio web mencionado arriba.";

// ----------------------------------------------------------------------
// ------------------ .AU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaudomainrelation"] = "Relación";
$_LANG["cnrxaudomainrelation1"] = "El dominio de segundo nivel es una coincidencia exacta, acrónimo o abreviatura del nombre de la empresa, nombre comercial, nombre de la organización o marca.";
$_LANG["cnrxaudomainrelation2"] = "El dominio de segundo nivel está estrechamente relacionado y es esencial para la organización o las actividades realizadas por la organización.";
$_LANG["cnrxaudomainrelationdescr"] = "Esto indica la relación entre el tipo de elegibilidad (por ejemplo, nombre comercial) y el nombre de dominio.";
$_LANG["cnrxaudomainrelationtype"] = "Tipo de relación";
$_LANG["cnrxaudomainrelationtypecompany"] = "Empresa";
$_LANG["cnrxaudomainrelationtyperegisteredbusiness"] = "Negocio registrado";
$_LANG["cnrxaudomainrelationtypesoletrader"] = "Autónomo";
$_LANG["cnrxaudomainrelationtypepartnership"] = "Sociedad";
$_LANG["cnrxaudomainrelationtypetrademarkowner"] = "Titular de marca";
$_LANG["cnrxaudomainrelationtypependingtmowner"] = "Solicitud de marca";
$_LANG["cnrxaudomainrelationtypecitizenresident"] = "Ciudadano / Residente"; // .id.au only
$_LANG["cnrxaudomainrelationtypeincorporatedassociation"] = "Asociación incorporada";
$_LANG["cnrxaudomainrelationtypeclub"] = "Club";
$_LANG["cnrxaudomainrelationtypenonprofitorganisation"] = "Organización sin fines de lucro";
$_LANG["cnrxaudomainrelationtypecharity"] = "Organización benéfica";
$_LANG["cnrxaudomainrelationtypetradeunion"] = "Sindicato";
$_LANG["cnrxaudomainrelationtypeindustrybody"] = "Organismo sectorial";
$_LANG["cnrxaudomainrelationtypecommercialstatutorybody"] = "Entidad estatutaria comercial";
$_LANG["cnrxaudomainrelationtypepoliticalparty"] = "Partido político";
$_LANG["cnrxaudomainrelationtypeother"] = "Otro";
$_LANG["cnrxaudomainrelationtypereligiouschurchgroup"] = "Grupo religioso / iglesia";
$_LANG["cnrxaudomainrelationtypehighereducationinstitution"] = "Institución de educación superior";
$_LANG["cnrxaudomainrelationtyperesearchorganisation"] = "Organización de investigación";
$_LANG["cnrxaudomainrelationtypegovernmentschool"] = "Escuela pública";
$_LANG["cnrxaudomainrelationtypechildcarecentre"] = "Centro de cuidado infantil";
$_LANG["cnrxaudomainrelationtypepreschool"] = "Preescolar";
$_LANG["cnrxaudomainrelationtypenationalbody"] = "Organismo nacional";
$_LANG["cnrxaudomainrelationtypetrainingorganisation"] = "Organización de formación";
$_LANG["cnrxaudomainrelationtypenongovernmentschool"] = "Escuela privada";
$_LANG["cnrxaudomainrelationtypeunincorporatedassociation"] = "Asociación no incorporada";
$_LANG["cnrxaudomainrelationtypeindustryorganisation"] = "Organización sectorial";
$_LANG["cnrxaudomainrelationtyperegistrablebody"] = "Entidad registrable";
$_LANG["cnrxaudomainrelationtypeindigenouscorporation"] = "Corporación indígena";
$_LANG["cnrxaudomainrelationtyperegisteredorganisation"] = "Organización registrada";
$_LANG["cnrxaudomainrelationtypetrust"] = "Fideicomiso";
$_LANG["cnrxaudomainrelationtypeeducationalinstitution"] = "Institución educativa";
$_LANG["cnrxaudomainrelationtypecommonwealthentity"] = "Entidad de la Commonwealth";
$_LANG["cnrxaudomainrelationtypestatutorybody"] = "Entidad estatutaria";
$_LANG["cnrxaudomainrelationtypetradingcooperative"] = "Cooperativa comercial";
$_LANG["cnrxaudomainrelationtypecompanylimitedbyguarantee"] = "Sociedad limitada por garantía";
$_LANG["cnrxaudomainrelationtypenondistributingcooperative"] = "Cooperativa no distributiva";
$_LANG["cnrxaudomainrelationtypenontradingcooperative"] = "Cooperativa no comercial";
$_LANG["cnrxaudomainrelationtypecharitabletrust"] = "Fideicomiso benéfico";
$_LANG["cnrxaudomainrelationtypepublicprivateancillaryfund"] = "Fondo auxiliar público/privado";
$_LANG["cnrxaudomainrelationtypepeakstateterritorybody"] = "Órgano principal estatal/territorial";
$_LANG["cnrxaudomainrelationtypenotforprofitcommunitygroup"] = "Grupo comunitario sin fines de lucro";
$_LANG["cnrxaudomainrelationtypeeducationandcareserviceschildcare"] = "Servicios educativos y de cuidado (guardería)";
$_LANG["cnrxaudomainrelationtypegovernmentbody"] = "Organismo gubernamental";
$_LANG["cnrxaudomainrelationtypeproviderofnonaccreditedtraining"] = "Proveedor de formación no acreditada";
$_LANG["cnrxaudomainrelationtypedescr"] = "Indique qué habilita al titular a registrar el nombre de dominio";
$_LANG["cnrxauownerorganization"] = "Titular, organización";
$_LANG["cnrxauownerorganizationdescr"] = "Nombre de la organización (titular)";
$_LANG["cnrxauidwarranty"] = "Titular,<br>es ciudadano o residente AU";
$_LANG["cnrxauidwarranty0"] = $_LANG["cnr0"];
$_LANG["cnrxauidwarranty1"] = $_LANG["cnr1"];
$_LANG["cnrxauidwarrantydescr"] = "El titular de un dominio .id.au debe garantizar que es residente o ciudadano australiano";
$_LANG["cnrxaueligibilityname"] = "Nombre de elegibilidad";
$_LANG["cnrxaueligibilitynamedescr"] = "Nombre del tipo de elegibilidad (por ejemplo, nombre comercial)";
$_LANG["cnrxaudomainidnumber"] = "Titular, número de identificación";
$_LANG["cnrxaudomainidnumberdescr"] = "";
$_LANG["cnrxaudomainidtype"] = "Titular, tipo de identificación";
// $_LANG["cnrxaudomainidtypetm"] = "TM";
// $_LANG["cnrxaudomainidtypeabn"] = "ABN";
// $_LANG["cnrxaudomainidtypeacn"] = "ACN";
// $_LANG["cnrxaudomainidtypeother"] = "Other";
// $_LANG["cnrxaudomainidtypeact"] = "ACT";
// $_LANG["cnrxaudomainidtypensw"] = "NSW";
// $_LANG["cnrxaudomainidtypent"] = "NT";
// $_LANG["cnrxaudomainidtypeqld"] = "QLD";
// $_LANG["cnrxaudomainidtypesa"] = "SA";
// $_LANG["cnrxaudomainidtypetas"] = "TAS";
// $_LANG["cnrxaudomainidtypevic"] = "VIC";
// $_LANG["cnrxaudomainidtypewa"] = "WA";
// $_LANG["cnrxaudomainidtypeprivate"] = "Private";
$_LANG["cnrxaudomainidtypedescr"] = "";
$_LANG["cnrxaueligibilityidnumber"] = "Elegibilidad, número de identificación";
$_LANG["cnrxaueligibilityidnumberdescr"] = "";
$_LANG["cnrxaueligibilityidtype"] = "Elegibilidad, tipo de identificación";
$_LANG["cnrxaueligibilityidtypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .CA Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcalegaltype"] = "Titular, tipo legal";
$_LANG["cnrxcalegaltypeabo"] = "Aborigen canadiense";
$_LANG["cnrxcalegaltypeass"] = "Asociación canadiense no incorporada";
$_LANG["cnrxcalegaltypecco"] = "Corporación (Canadá o provincia/territorio canadiense)";
$_LANG["cnrxcalegaltypecct"] = "Ciudadano canadiense";
$_LANG["cnrxcalegaltypeedu"] = "Institución educativa canadiense";
$_LANG["cnrxcalegaltypegov"] = "Gobierno o agencia gubernamental en Canadá";
$_LANG["cnrxcalegaltypehop"] = "Hospital canadiense";
$_LANG["cnrxcalegaltypeinb"] = "Tribu india reconocida por la Ley de Indios de Canadá";
$_LANG["cnrxcalegaltypelam"] = "Biblioteca, archivo o museo canadiense";
$_LANG["cnrxcalegaltypelgr"] = "Representante legal de un ciudadano canadiense o residente permanente";
$_LANG["cnrxcalegaltypemaj"] = "Su Majestad la Reina";
$_LANG["cnrxcalegaltypeomk"] = "Marca oficial registrada en Canadá";
$_LANG["cnrxcalegaltypeplt"] = "Partido político canadiense";
$_LANG["cnrxcalegaltypeprt"] = "Sociedad registrada en Canadá";
$_LANG["cnrxcalegaltyperes"] = "Residente permanente de Canadá";
$_LANG["cnrxcalegaltypetdm"] = "Marca registrada en Canadá (por titular no canadiense)";
$_LANG["cnrxcalegaltypetrd"] = "Sindicato canadiense";
$_LANG["cnrxcalegaltypetrs"] = "Fideicomiso constituido en Canadá";
// $_LANG["cnrxcalegaltypedescr"] = "";
$_LANG["cnrxcatrademark"] = "Es una marca registrada";
$_LANG["cnrxcatrademark0"] = $_LANG["cnr0"];
$_LANG["cnrxcatrademark1"] = $_LANG["cnr1"];
$_LANG["cnrxcatrademarkdescr"] = "Indica si el dominio es una marca registrada o no.";

// ----------------------------------------------------------------------
// ------------------ .COM.BR Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxbrregisternumber"] = "Titular, número de identificación brasileño";
$_LANG["cnrxbrregisternumberdescr"] = "El número de registro de empresa brasileña (CNPJ) o el número de registro individual brasileño (CPF).";

// ----------------------------------------------------------------------
// ------------------ .CN Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcnownertype"] = "Titular, tipo";
$_LANG["cnrxcnownertypei"] = "Persona física";
$_LANG["cnrxcnownertypee"] = "Empresa";
$_LANG["cnrxcnownertypedescr"] = "";
$_LANG["cnrxcnowneridtype"] = "Titular, tipo de ID";
$_LANG["cnrxcnowneridtypesfz"] = "SFZ (DNI) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypehz"] = "HZ (Pasaporte) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypegajmtx"] = "GAJMTX (Permiso de entrada/salida para Hong Kong y Macao) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypetwjmtx"] = "TWJMTX (Pasaporte para residentes de Taiwán para entrada/salida) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypewjlsfz"] = "WJLSFZ (Permiso de residencia permanente extranjero) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypegajzz"] = "GAJZZ (Permiso de residencia para residentes de Hong Kong y Macao) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypetwjzz"] = "TWJZZ (Permiso de residencia para residentes de Taiwán) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypejgz"] = "JGZ (Carnet de oficial) - Tipo de titular es persona física";
$_LANG["cnrxcnowneridtypeqt"] = "QT (Otro) - Tipo de titular es persona física o empresa";
$_LANG["cnrxcnowneridtypeorg"] = "ORG (Certificado de código organizacional) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypeyyzz"] = "YYZZ (Licencia comercial) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypetydm"] = "TYDM (Certificado de código de crédito social unificado) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypebddm"] = "BDDM (Código militar) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypejddwfw"] = "JDDWFW (Licencia de servicio externo militar) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypesydwfr"] = "SYDWFR (Certificado de persona jurídica de institución pública) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypewgczjg"] = "WGCZJG (Formulario de registro para representaciones de empresas extranjeras) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypeshttfr"] = "SHTTFR (Certificado de registro de organización social) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypezjcs"] = "ZJCS (Certificado de registro de lugar de actividad religiosa) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypembfqy"] = "MBFQY (Certificado de registro de entidad privada no empresarial) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypejjhfr"] = "JJHFR (Certificado de registro de fundación) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypelszy"] = "LSZY (Licencia de bufete de abogados) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypewgzhwh"] = "WGZHWH (Certificado de registro de centro cultural extranjero en China) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypewlczzg"] = "WLCZJG (Certificado de registro para representaciones de departamentos turísticos extranjeros) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypesfjd"] = "SFJD (Certificado de formación jurídica) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypejwjg"] = "JWJG (Certificado de empresa extranjera) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypeshfwjg"] = "SHFWJG (Certificado de registro de agencia de servicios sociales) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypembxxbx"] = "MBXXBX (Permiso de escuela privada) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypeyljgzy"] = "YLJGZY (Licencia de institución médica) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypegzjgzy"] = "GZJGZY (Licencia de notaría) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypebjwsxx"] = "BJWSXX (Permiso de escuela para hijos de diplomáticos extranjeros en Beijing/China) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypeqttyzm"] = "QTTYDM (Otro-certificado de código de crédito social unificado) - Tipo de titular es empresa";
$_LANG["cnrxcnowneridtypedescr"] = "Tipo de identificación del documento";
$_LANG["cnrxcnowneridnumber"] = "Titular, número de ID";
$_LANG["cnrxcnowneridnumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COOP Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcoopeligibility"] = "Requisitos de elegibilidad";
$_LANG["cnrxcoopeligibilitydescr"] = "Acepto que mi organización cumple al menos uno de los requisitos de elegibilidad .COOP. Lea <a style=\"text-decoration:underline\" href=\"https://identity.coop/coop-policies-and-agreements/\" target=\"_blank\">aquí</a>.";
$_LANG["cnrxcoopeligibility0"] = $_LANG["cnr0"];
$_LANG["cnrxcoopeligibility1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .DE Fields ----------------------------------------
// ----------------------------------------------------------------------
//$_LANG["cnrxdensentry0"] = "";
$_LANG["cnrxdensentry0descr"] = implode(" ", [
    "Permite el uso de nsentrys en lugar de servidores de nombres para dominios .de;",
    "Las entradas NS permiten la configuración de subdominios con servidores de nombres alternativos.",
    "<a target=\"_blank\" href=\"https://www.denic.de/en/domains/de-domains/registration/nameserver-and-nsentry-data/\" style=\"text-decoration:underline\">Información detallada</a>."
]);
//$_LANG["cnrxdensentry1"] = "";
$_LANG["cnrxdensentry1descr"] = "ver arriba";
//$_LANG["cnrxdensentry2"] = "";
$_LANG["cnrxdensentry2descr"] = "ver arriba";
//$_LANG["cnrxdensentry3"] = "";
$_LANG["cnrxdensentry3descr"] = "ver arriba";
//$_LANG["cnrxdensentry4"] = "";
$_LANG["cnrxdensentry4descr"] = "ver arriba";
//$_LANG["cnrxdegeneralrequest"] = "";
//$_LANG["cnrxdegeneralrequestdescr"] = "";
//$_LANG["cnrxdeabusecontact"] = "";
//$_LANG["cnrxdeabusecontactdescr "] = "";

// ----------------------------------------------------------------------
// ------------------ .DK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdkusertype"] = "Titular, tipo";
$_LANG["cnrxdkusertypeperson"] = "Persona";
$_LANG["cnrxdkusertypecompany"] = "Empresa";
$_LANG["cnrxdkusertypeassociation"] = "Asociación";
$_LANG["cnrxdkusertypepuborg"] = "Organización pública";
// $_LANG["cnrxdkusertypedescr"] = "";
$_LANG["cnrxdkuseridnumber"] = "Titular, número de ID";
$_LANG["cnrxdkuseridnumberdescr"] = implode("", [
    "Número de identificación del contacto titular. Puede ser <i>EAN, CVR o P Número</i>. ",
    "El <i>número CVR</i> se utiliza para identificar la organización, y el <i>número EAN</i> garantiza ",
    "que los documentos relacionados con la facturación electrónica se envíen a la cuenta correcta. ",
    "El <i>número P</i> es una designación de sucursal asignada por el Registro Central de Empresas danés para ",
    "vincular ubicaciones físicas con una organización."
]);

// ----------------------------------------------------------------------
// ------------------ .ES Fields ----------------------------------------
// ----------------------------------------------------------------------
$types = [
    1 => "Persona física",
    39 => "Asociación de intereses económicos",
    47 => "Asociación",
    59 => "Club deportivo",
    68 => "Asociación profesional",
    124 => "Caja de ahorros",
    150 => "Bienes comunales",
    152 => "Comunidad de propietarios",
    164 => "Orden o institución religiosa",
    181 => "Consulado",
    197 => "Corporación de derecho público",
    203 => "Embajada",
    229 => "Administración local",
    269 => "Federación deportiva",
    286 => "Fundación",
    365 => "Mutua de seguros",
    434 => "Autoridad gubernamental regional",
    436 => "Autoridad gubernamental central",
    439 => "Partido político",
    476 => "Sociedad mercantil",
    510 => "Sociedad agraria",
    524 => "Sociedad anónima",
    525 => "Club deportivo",
    554 => "Sociedad civil",
    560 => "Sociedad colectiva",
    562 => "Sociedad colectiva y comanditaria",
    566 => "Cooperativa",
    608 => "Empresa gestionada por empleados",
    612 => "Sociedad limitada",
    713 => "Oficina española",
    717 => "Cooperación empresarial temporal",
    744 => "Sociedad anónima gestionada por empleados",
    745 => "Entidad pública regional",
    746 => "Entidad pública nacional",
    747 => "Entidad pública local",
    877 => "Otros",
    878 => "Consejo regulador de denominación de origen",
    879 => "Entidad gestora de espacios naturales"
];
$idtypes = [
    0 => "Otro (para contactos fuera de España)",
    1 => "DNI/NIF (para contactos españoles)",
    2 => "Obsoleto, use la siguiente opción.",
    3 => "NIE (para contactos españoles)",
    4 => "IVA (número de identificación fiscal): solo válido para entidades legales no españolas"
];
$idtypesdescr = implode("<br/>", [
    "DNI = &quot;Documento Nacional de Identidad&quot;",
    "NIF = &quot;Número de Identificación Fiscal&quot;",
    "NIE = &quot;Número de Identificación de Extranjero&quot;. Es el equivalente a un NIF español, pero lo expiden las autoridades españolas a extranjeros que permanecen más de 3 meses en España."
]);
$idnodescr = "El número de identificación de este contacto. Para contactos españoles es el número DNI/NIF/NIE; de lo contrario, el número de documento o pasaporte.";

$_LANG["cnrxesownertipoidentificacion"] = "Titular, tipo de identificación";
$_LANG["cnrxesadmintipoidentificacion"] = "Admin, tipo de identificación";
$_LANG["cnrxestechtipoidentificacion"] = "Técnico, tipo de identificación";
$_LANG["cnrxesbillingtipoidentificacion"] = "Facturación, tipo de identificación";

foreach ($idtypes as $key => $value) {
    $_LANG["cnrxesownertipoidentificacion$key"] = $value;
    $_LANG["cnrxesadmintipoidentificacion$key"] = $value;
    $_LANG["cnrxestechtipoidentificacion$key"] = $value;
    $_LANG["cnrxesbillingtipoidentificacion$key"] = $value;
}

$_LANG["cnrxesownertipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesadmintipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxestechtipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesbillingtipoidentificaciondescr"] = $idtypesdescr;

$_LANG["cnrxesowneridentificacion"] = "Titular, número de identificación";
$_LANG["cnrxesadminidentificacion"] = "Admin, número de identificación";
$_LANG["cnrxestechidentificacion"] = "Técnico, número de identificación";
$_LANG["cnrxesbillingidentificacion"] = "Facturación, número de identificación";

$_LANG["cnrxesowneridentificaciondescr"] = $idnodescr;
$_LANG["cnrxesadminidentificaciondescr"] = $idnodescr;
$_LANG["cnrxestechidentificaciondescr"] = $idnodescr;
$_LANG["cnrxesbillingidentificaciondescr"] = $idnodescr;

$_LANG["cnrxesownerlegalform"] = "Titular, forma jurídica";
$_LANG["cnrxesadminlegalform"] = "Admin, forma jurídica";
$_LANG["cnrxestechlegalform"] = "Técnico, forma jurídica";
$_LANG["cnrxesbillinglegalform"] = "Facturación, forma jurídica";

foreach ($types as $key => $value) {
    $_LANG["cnrxesownerlegalform$key"] = $value;
    $_LANG["cnrxesadminlegalform$key"] = $value;
    $_LANG["cnrxestechlegalform$key"] = $value;
    $_LANG["cnrxesbillinglegalform$key"] = $value;
}

$_LANG["cnrxesownerlegalformdescr"] = "";
$_LANG["cnrxesadminlegalformdescr"] = "";
$_LANG["cnrxestechlegalformdescr"] = "";
$_LANG["cnrxesbillinglegalformdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .EU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxeuregistrantlang"] = "Titular, idioma";
$_LANG["cnrxeuregistrantcitizenship"] = "Titular, nacionalidad";
$_LANG["cnrxeuregistrantlangdescr"] = "Idioma para la comunicación con el operador de la TLD (por defecto = inglés)";
$_LANG["cnrxeuregistrantcitizenshipdescr"] = "Las personas físicas con ciudadanía europea que no residan en la UE pueden registrar dominios .eu con esta configuración.";

// ----------------------------------------------------------------------
// ------------------ .FI Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxficompanyregid"] = "Titular, ID de empresa o número de registro";
$_LANG["cnrxficompanyregiddescr"] = "Entidad comercial local (registrada en el registro mercantil finlandés o una corporación dentro de la República de Finlandia)<br/>(requerido para entidades no finlandesas)";
$_LANG["cnrxfipersonalid"] = "Titular, número de identificación personal";
$_LANG["cnrxfipersonaliddescr"] = "Número de identificación personal finlandés<br/>(requerido para personas físicas no finlandesas)";
$_LANG["cnrxfibirthdate"] = "Titular, fecha de nacimiento";
$_LANG["cnrxfibirthdatedescr"] = "Fecha de nacimiento (AAAA-MM-DD)<br/>(requerido para personas físicas no finlandesas)";
$_LANG["cnrxficontacttype"] = "Titular, tipo de contacto";
$_LANG["cnrxficontacttype0"] = "Persona física";
$_LANG["cnrxficontacttype1"] = "Empresa";
$_LANG["cnrxficontacttype2"] = "Corporación";
$_LANG["cnrxficontacttype3"] = "Institución";
$_LANG["cnrxficontacttype4"] = "Partido político";
$_LANG["cnrxficontacttype5"] = "Municipio";
$_LANG["cnrxficontacttype6"] = "Gobierno";
$_LANG["cnrxficontacttype7"] = "Comunidad pública";
$_LANG["cnrxficontacttypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .GAY Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxgayacceptrequirements"] = "Aceptar requisitos";
$_LANG["cnrxgayacceptrequirements0"] = $_LANG["cnr0"];
$_LANG["cnrxgayacceptrequirements1"] = $_LANG["cnr1"];
$_LANG["cnrxgayacceptrequirementsdescr"] = "Confirmo que el dominio NO se utilizará para incitar a la violencia, acoso, intimidación o discurso de odio y que NO será utilizado por grupos reconocidos de odio. DotGay dona el 20% de cada dominio registrado a sus socios, GLAAD y CenterLink.";

// ----------------------------------------------------------------------
// ------------------ .HK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxhkownerdocumenttype"] = "Titular, tipo de documento";
$_LANG["cnrxhkownerdocumenttypehkid"] = "Persona física: número de identificación de Hong Kong";
$_LANG["cnrxhkownerdocumenttypeothid"] = "Persona física: número de identificación de otro país";
$_LANG["cnrxhkownerdocumenttypepassno"] = "Persona física: número de pasaporte";
$_LANG["cnrxhkownerdocumenttypebirthcert"] = "Persona física: certificado de nacimiento";
$_LANG["cnrxhkownerdocumenttypeothidv"] = "Persona física: otro documento";
$_LANG["cnrxhkownerdocumenttypebr"] = "Organización: registro mercantil";
$_LANG["cnrxhkownerdocumenttypeci"] = "Organización: certificado de constitución";
$_LANG["cnrxhkownerdocumenttypecrs"] = "Organización: certificado de registro escolar";
$_LANG["cnrxhkownerdocumenttypehksarg"] = "Organización: departamento gubernamental de Hong Kong";
$_LANG["cnrxhkownerdocumenttypehkordinance"] = "Organización: ordenanza de Hong Kong";
$_LANG["cnrxhkownerdocumenttypeothorg"] = "Organización: otro documento";
$_LANG["cnrxhkownerdocumenttypedescr"] = "";
$_LANG["cnrxhkownerdocumentnumber"] = "Titular, número de documento";
$_LANG["cnrxhkownerdocumentnumberdescr"] = "";
$_LANG["cnrxhkownerdocumentorigincountry"] = "Titular, país de emisión del documento";
$_LANG["cnrxhkownerdocumentorigincountrydescr"] = "El país donde se emitió este documento (por favor, indique el código ISO de 2 letras, por ejemplo, ES o US).";
$_LANG["cnrxhkownerotherdocumenttype"] = "Titular, otro tipo de documento";
$_LANG["cnrxhkownerotherdocumenttypedescr"] = "Requerido si el tipo de documento seleccionado anteriormente es '" . $_LANG["cnrxhkownerdocumenttypeothidv"] . "' o '" . $_LANG["cnrxhkownerdocumenttypeothorg"] . "'.";
$_LANG["cnrxhkdomaincategory"] = "Categoría de dominio";
$_LANG["cnrxhkdomaincategoryi"] = "Persona física";
$_LANG["cnrxhkdomaincategoryo"] = "Organización";
$_LANG["cnrxhkdomaincategorydescr"] = "Tipo legal de todos los contactos del dominio";
$_LANG["cnrxhkownerageover18"] = "Titular, mayor de 18 años";
$_LANG["cnrxhkownerageover18no"] = $_LANG["cnr0"];
$_LANG["cnrxhkownerageover18yes"] = $_LANG["cnr1"];
$_LANG["cnrxhkownerageover18descr"] = "Confirmo que el titular tiene al menos 18 años (solo requerido para personas físicas).";

// ----------------------------------------------------------------------
// ------------------ .IE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxiecontacttype"] = "Titular, tipo de contacto";
$_LANG["cnrxiecontacttypecom"] = "Empresa";
$_LANG["cnrxiecontacttypecha"] = "Fundación";
$_LANG["cnrxiecontacttypeoth"] = "Otro";
$_LANG["cnrxiecontacttypedescr"] = "";
$_LANG["cnrxielanguage"] = "Titular, idioma";
$_LANG["cnrxielanguageen"] = "Inglés";
$_LANG["cnrxielanguagefr"] = "Francés";
$_LANG["cnrxielanguagedescr"] = "Idioma para la comunicación con el operador de la TLD (por defecto = inglés)";
$_LANG["cnrxiecronumber"] = "Titular, número CRO";
$_LANG["cnrxiecronumberdescr"] = "Número de registro mercantil (CRO)";
$_LANG["cnrxiesupportingnumber"] = "Titular, número de soporte";
$_LANG["cnrxiesupportingnumberdescr"] = "Número de soporte/fundación";

// ----------------------------------------------------------------------
// ------------------ .IT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxitconsentforpublishing"] = $_LANG["cnrconsentforpublishing"];
$_LANG["cnrxitconsentforpublishing0"] = $_LANG["cnr0"];
$_LANG["cnrxitconsentforpublishing1"] = $_LANG["cnr1"];
$_LANG["cnrxitconsentforpublishingdescr"] = "Permitir la publicación de los datos de contacto personales. Solo se puede rechazar si el tipo de entidad abajo es 1.";
$_LANG["cnrxitentitytype"] = "Titular, tipo de entidad";
$_LANG["cnrxitentitytype1"] = "[1] Personas físicas italianas y extranjeras";
$_LANG["cnrxitentitytype2"] = "[2] Empresas/empresarios individuales";
$_LANG["cnrxitentitytype3"] = "[3] Profesionales/liberales";
$_LANG["cnrxitentitytype4"] = "[4] Organizaciones sin ánimo de lucro";
$_LANG["cnrxitentitytype5"] = "[5] Organizaciones públicas";
$_LANG["cnrxitentitytype6"] = "[6] Otros sujetos";
$_LANG["cnrxitentitytype7"] = "[7] Extranjeros equivalentes a 2-6";
$_LANG["cnrxitentitytypedescr"] = "Tipo de entidad para identificar al titular.";
$_LANG["cnrxitpin"] = "Titular, código fiscal";
//$_LANG["cnrxitpindescr"] = "";
$_LANG["cnrxitnationality"] = "Titular, nacionalidad";
$_LANG["cnrxitnationalitydescr"] = "La nacionalidad del titular, indicada por el código ISO de 2 letras.";
//$_LANG["cnrxitsect3liability"] = "";
$_LANG["cnrxitsect3liabilitydescr"] = "";
$_LANG["cnrxitsect3liability0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect3liability1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect5personaldataforregistration"] = "";
$_LANG["cnrxitsect5personaldataforregistrationdescr"] = "";
$_LANG["cnrxitsect5personaldataforregistration0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect5personaldataforregistration1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect6personaldatafordiffusion"] = "";
$_LANG["cnrxitsect6personaldatafordiffusiondescr"] = "";
$_LANG["cnrxitsect6personaldatafordiffusion0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect6personaldatafordiffusion1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect7explicitacceptance"] = "";
$_LANG["cnrxitsect7explicitacceptancedescr"] = "";
$_LANG["cnrxitsect7explicitacceptance0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect7explicitacceptance1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .LV Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxlvownerregnr"] = "Titular, número de registro";
$_LANG["cnrxlvownerregnrdescr"] = "Número de registro letón utilizado para el contacto titular (por ejemplo, número de registro de empresa)";
$_LANG["cnrxlvadminregnr"] = "Admin, número de registro";
$_LANG["cnrxlvadminregnrdescr"] = "Número de registro letón utilizado para el contacto administrativo (por ejemplo, número de registro de empresa)";
$_LANG["cnrxlvvatnr"] = "Titular, NIF";
$_LANG["cnrxlvvatnrdescr"] = "El NIF del contacto titular (solo para empresas).";

// ----------------------------------------------------------------------
// ------------------ .LT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxltcompanynumber"] = "Titular, número de empresa";
$_LANG["cnrxltcompanynumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .MY Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxmybusinessnumber"] = "Titular, número de empresa";
$_LANG["cnrxmybusinessnumberdescr"] = "Número de registro de empresa del titular (solo para empresas)";
$_LANG["cnrxmyorganizationtype"] = "Titular, tipo de organización";
$_LANG["cnrxmyorganizationtypedescr"] = "Tipo de empresa del titular (solo para empresas)";
$_LANG["cnrxmyperidentity"] = "Titular, número de identificación personal";
$_LANG["cnrxmyperidentitydescr"] = "Número de identificación personal del titular (solo para personas físicas)";
$_LANG["cnrxmyperdateofbirth"] = "Titular, fecha de nacimiento";
$_LANG["cnrxmyperdateofbirthdescr"] = "Fecha de nacimiento del titular (AAAA-MM-DD, solo para personas físicas)";
$_LANG["cnrxmyrace"] = "Titular, etnia";
$_LANG["cnrxmyracemalay"] = "Malayo";
$_LANG["cnrxmyracechinese"] = "Chino";
$_LANG["cnrxmyraceindian"] = "Indio";
$_LANG["cnrxmyraceothers"] = "Otro";
$_LANG["cnrxmyracedescr"] = "(solo para personas físicas)";

// ----------------------------------------------------------------------
// ------------------ .NO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnoorganizationnumber"] = "Titular, número de organización";
$_LANG["cnrxnoorganizationnumberdescr"] = "Número de registro noruego emitido por el Registro Central de Entidades Jurídicas.";
$_LANG["cnrxnopersonidentifier"] = "ID personal Norid";
$_LANG["cnrxnopersonidentifierdescr"] = "ID personal requerida para registrar un dominio .PRIV.NO privado. De lo contrario, dejar en blanco.";

// ----------------------------------------------------------------------
// ------------------ .NU Fields ----------------------------------------
// ----------------------------------------------------------------------
// see further .nu fields at the top of the file
$_LANG["cnrxnuiisidno"] = "Titular, número de identificación";
$_LANG["cnrxnuiisidnodescr"] = "Número de identificación personal, número de identificación de empresa o designación de registro en un registro estatal. Para contactos en Suecia se requiere un número de identificación sueco válido (ejemplo: 123456-1234).";
$_LANG["cnrxnuiisvatno"] = "Titular, NIF";
$_LANG["cnrxnuiisvatnodescr"] = "El NIF del titular (solo para empresas)";

// ----------------------------------------------------------------------
// ------------------ .NYC Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnycextcontact"] = "Contacto externo NY";
$_LANG["cnrxnycextcontactadmin"] = "Contacto administrativo";
$_LANG["cnrxnycextcontacttech"] = "Contacto técnico";
$_LANG["cnrxnycextcontactbilling"] = "Contacto de facturación";
$_LANG["cnrxnycextcontactowner"] = "Titular";
$_LANG["cnrxnycextcontactdescr"] = "El contacto proporcionado debe tener una dirección física válida en la ciudad de Nueva York.";

// ----------------------------------------------------------------------
// ------------------ .PARIS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxafniccode"] = $_LANG["cnrxallocationtoken"];
$_LANG["cnrxafniccodedescr"] = $_LANG["cnrxallocationtokendescr"];

// ----------------------------------------------------------------------
// ------------------ .FR, .PM, .RE, .TF, .WF, .YT Fields ---------------
// ----------------------------------------------------------------------
// Organizations (Companies, Associations, etc.)
$_LANG["cnrxfrannounce"] = "Organización/Empresa, n.º de anuncio<br/>(Journal Officiel)";
$_LANG["cnrxfrannouncedescr"] = implode(" ", [
    "Solo para organizaciones/empresas (asociaciones/empresas). Deje en blanco para personas físicas.<br/>",
    "Número de anuncio en el Journal Officiel (solo dígitos).",
    "Si utiliza los datos del Journal Officiel como identificador, rellene todos los campos JO relacionados:",
    "Fecha de publicación, n.º de anuncio, n.º de página y fecha de la asociación."
]);
$_LANG["cnrxfrdatepublicationjo"] = "Organización/Empresa, fecha de publicación<br/>(Journal Officiel)";
$_LANG["cnrxfrdatepublicationjodescr"] = implode(" ", [
    "Solo para organizaciones/empresas (asociaciones/empresas). Deje en blanco para personas físicas.<br/>",
    "Fecha de publicación en el Journal Officiel.",
    "Formato de fecha AAAA-MM-DD.",
    "Si utiliza los datos del Journal Officiel como identificador, rellene todos los campos JO relacionados:",
    "Fecha de publicación, n.º de anuncio, n.º de página y fecha de la asociación."
]);
$_LANG["cnrxfrnumerodepageannouncejo"] = "Organización/Empresa, n.º de página<br/>(Journal Officiel)";
$_LANG["cnrxfrnumerodepageannouncejodescr"] = implode(" ", [
    "Solo para organizaciones/empresas (asociaciones/empresas). Deje en blanco para personas físicas.<br/>",
    "Número de página en el Journal Officiel (solo dígitos).",
    "Si utiliza los datos del Journal Officiel como identificador, rellene todos los campos JO relacionados:",
    "Fecha de publicación, n.º de anuncio, n.º de página y fecha de la asociación."
]);
$_LANG["cnrxfrwaldec"] = "Organización/Empresa, ID Waldec (Asociaciones)";
$_LANG["cnrxfrwaldecdescr"] = implode(" ", [
    "Solo para asociaciones. Deje en blanco para personas físicas.<br/>",
    "Identificador Waldec asociado a una asociación (solo dígitos).",
    "Si se proporciona, es suficiente para identificar la asociación.",
    "Consejo: normalmente basta con UN identificador; si indica Waldec, puede dejar en blanco otros identificadores de organización (SIREN/SIRET, NIF/IVA, DUNS, marca, ID local, campos Journal Officiel)."
]);
$_LANG["cnrxfrdateassociation"] = "Organización/Empresa, fecha de la asociación";
$_LANG["cnrxfrdateassociationdescr"] = implode(" ", [
    "Solo para organizaciones/empresas (asociaciones/empresas). Deje en blanco para personas físicas.<br/>",
    "Formato de fecha AAAA-MM-DD.",
    "Requerido si proporciona datos del Journal Officiel (n.º de anuncio, n.º de página, fecha de publicación)."
]);
$_LANG["cnrxfrduns"] = "Organización/Empresa, número DUNS";
$_LANG["cnrxfrdunsdescr"] = implode(" ", [
    "Solo para organizaciones/empresas. Deje en blanco para personas físicas.<br/>",
    "El número DUNS es un identificador único de nueve dígitos para empresas. Abreviatura de Data Universal",
    "Numbering System; se refiere a un nuevo identificador que puede enviarse para una verificación de elegibilidad",
    "a nivel europeo.",
    "Consejo: normalmente basta con UN identificador (p. ej., SIREN/SIRET, NIF/IVA, DUNS, marca, ID local, Waldec o campos Journal Officiel)."
]);
$_LANG["cnrxfrlocal"] = "Organización/Empresa, ID local";
$_LANG["cnrxfrlocaldescr"] = implode(" ", [
    "Solo para organizaciones/empresas. Deje en blanco para personas físicas.<br/>",
    "Un identificador local específico de un país del Espacio Económico Europeo (por ejemplo, número de certificado comercial).",
    "Consejo: normalmente basta con UN identificador (p. ej., SIREN/SIRET, NIF/IVA, DUNS, marca, ID local, Waldec o campos Journal Officiel)."
]);
$_LANG["cnrxfrnoprezonecheck0"] = $_LANG["cnr0"];
$_LANG["cnrxfrnoprezonecheck1"] = $_LANG["cnr1"];
$_LANG["cnrxfrsirenorsiret"] = "Organización/Empresa, número SIREN/SIRET";
$_LANG["cnrxfrsirenorsiretdescr"] = implode(" ", [
    "Solo para organizaciones/empresas. Deje en blanco para personas físicas.<br/>",
    "Indíquelo si registra como organización/empresa en Francia con un SIREN/SIRET válido.",
    "Consejo: normalmente basta con UN identificador; si indica SIREN/SIRET, puede dejar en blanco NIF/IVA, DUNS, marca, ID local, Waldec y campos Journal Officiel.",
    "El código SIREN es el número único de empresa en Francia. Lo emite el",
    "Institut national de la statistique et des études économiques (INSEE) y tiene 9 dígitos.",
    "Los primeros 9 dígitos son el número SIREN y los siguientes 5 dígitos son el número NIC",
    "(Numéro Interne de Classement). El número SIRET se emite una vez que registra su",
    "empresa en la Cámara de Comercio (RCS) para comercio, la Cámara de Artesanía para artesanía y",
    "trabajo manual o en la URSSAF para servicios intelectuales.",
    "Los números SIRET constan de 14 dígitos. El número SIRET proporciona información sobre la ubicación de la empresa en Francia",
    "(para empresas establecidas). El nombre de la empresa proporcionado en el contacto titular debe",
    "coincidir exactamente con el de la base de datos SIREN/SIRET ( https://www.infogreffe.fr/ )."
]);
$_LANG["cnrxfrtrademark"] = "Organización/Empresa, número de marca";
$_LANG["cnrxfrtrademarkdescr"] = implode(" ", [
    "Solo para organizaciones/empresas. Deje en blanco para personas físicas.<br/>",
    "Número de marca (si el registro se basa en derechos de marca).",
    "Consejo: normalmente basta con UN identificador; si indica un número de marca, puede dejar en blanco SIREN/SIRET, NIF/IVA, DUNS, ID local, Waldec y campos Journal Officiel."
]);
$_LANG["cnrxfrvatid"] = "Organización/Empresa, NIF/IVA";
$_LANG["cnrxfrvatiddescr"] = implode(" ", [
    "Solo para organizaciones/empresas. Deje en blanco para personas físicas.<br/>",
    "NIF/IVA (si está disponible).",
    "Consejo: normalmente basta con UN identificador; si indica NIF/IVA, puede dejar en blanco SIREN/SIRET, DUNS, marca, ID local, Waldec y campos Journal Officiel."
]);

// Individual
$_LANG["cnrxfrbirthpc"] = "Titular, código postal (lugar de nacimiento)";
$_LANG["cnrxfrbirthpcdescr"] = implode(" ", [
    "Solo para personas físicas. Deje en blanco para organizaciones/empresas.<br/>",
    "Solo requerido para personas nacidas en Francia o territorios franceses de ultramar (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Indique el código postal del lugar de nacimiento (o al menos el código del departamento)."
]);
$_LANG["cnrxfrbirthcity"] = "Titular, ciudad de nacimiento";
$_LANG["cnrxfrbirthcitydescr"] = implode(" ", [
    "Solo para personas físicas. Deje en blanco para organizaciones/empresas.<br/>",
    "Solo requerido para personas nacidas en Francia o territorios franceses de ultramar (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Indique el nombre de la ciudad."
]);
$_LANG["cnrxfrbirthdate"] = "Titular, fecha de nacimiento";
$_LANG["cnrxfrbirthdatedescr"] = "Solo para personas físicas. Fecha de nacimiento en formato AAAA-MM-DD. Deje en blanco para organizaciones/empresas.";
$_LANG["cnrxfrbirthplace"] = "Titular, país de nacimiento";
$_LANG["cnrxfrbirthplacedescr"] = "Solo para personas físicas. Código de país del lugar de nacimiento (p. ej., FR, DE). Deje en blanco para organizaciones/empresas.";
$_LANG["cnrxfrrestrictpub"] = "Titular, restringir publicación (WHOIS)";
$_LANG["cnrxfrrestrictpub0"] = $_LANG["cnr0"];
$_LANG["cnrxfrrestrictpub1"] = $_LANG["cnr1"];
$_LANG["cnrxfrrestrictpubdescr"] = "Solo para personas físicas. Elija 'Sí' para restringir la publicación y ocultar los datos personales en WHOIS.";
$_LANG["cnrxfrnoprezonecheck"] = "Omitir prechequeo DNS";
$_LANG["cnrxfrnoprezonecheckdescr"] = "Determina si el sistema debe realizar una prevalidación DNS antes de enviar la orden al registro.";

// ----------------------------------------------------------------------
// ------------------ .PT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxpttechidentification"] = "Contacto técnico, NIF";
$_LANG["cnrxpttechidentificationdescr"] = "El número de identificación fiscal del contacto técnico";
$_LANG["cnrxptowneridentification"] = "Titular, NIF";
$_LANG["cnrxptowneridentificationdescr"] = "El número de identificación fiscal del titular";
$_LANG["cnrxpttechmobile"] = "Contacto técnico, móvil";
$_LANG["cnrxpttechmobiledescr"] = "El número de móvil del contacto técnico";
$_LANG["cnrxptownermobile"] = "Titular, móvil";
$_LANG["cnrxptownermobiledescr"] = "El número de móvil del titular";

// ----------------------------------------------------------------------
// ------------------ .RO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrocompanynumber"] = "Titular, número de empresa";
$_LANG["cnrxrocompanynumberdescr"] = "(solo requerido para empresas)";
$_LANG["cnrxroidcardorpassportnumber"] = "Titular, número de DNI o pasaporte";
$_LANG["cnrxroidcardorpassportnumberdescr"] = "(solo requerido para personas físicas)";
$_LANG["cnrxrovatnumber"] = "Titular, NIF";
$_LANG["cnrxrovatnumberdescr"] = "(solo requerido para empresas)";

// ----------------------------------------------------------------------
// ------------------ .RU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrubirthdate"] = "Titular, fecha de nacimiento";
$_LANG["cnrxrubirthdatedescr"] = "La fecha de nacimiento del titular (DD.MM.AAAA)<br/>(solo requerido para personas físicas)";
$_LANG["cnrxrufirstname"] = "Titular, nombre";
$_LANG["cnrxrufirstnamedescr"] = "El nombre del titular en ruso. Debe completarse con letras rusas y latinas, sin puntos.<br/>(solo requerido para personas físicas)";
$_LANG["cnrxrumiddlename"] = "Titular, segundo nombre";
$_LANG["cnrxrumiddlenamedescr"] = "El segundo nombre del titular en ruso. Debe completarse con letras rusas y latinas, sin puntos.<br/>(solo requerido para personas físicas)";
$_LANG["cnrxrulastname"] = "Titular, apellido";
$_LANG["cnrxrulastnamedescr"] = "El apellido del titular en ruso. Debe completarse con letras rusas y latinas, sin puntos.<br/>(solo requerido para personas físicas)";
$_LANG["cnrxruorganization"] = "Titular, nombre de la organización";
$_LANG["cnrxruorganizationdescr"] = "El nombre de la organización del titular en ruso. Este campo puede contener letras rusas y latinas, números, signos de puntuación y espacios.<br/>(solo requerido para organizaciones registradas en la Federación Rusa)";
$_LANG["cnrxrucode"] = "Titular, número fiscal";
$_LANG["cnrxrucodedescr"] = "El número fiscal (TIN) del titular. Este campo debe contener un número de diez dígitos (el último dígito es un dígito de control).<br/>(solo requerido para organizaciones registradas en la Federación Rusa)";
$_LANG["cnrxrukpp"] = "Titular, código base";
$_LANG["cnrxrukppdescr"] = "El código base (KPP) del titular. Este campo debe contener un número de nueve dígitos.<br/>(solo requerido para organizaciones registradas en la Federación Rusa)";
$_LANG["cnrxrupassportdata"] = "Titular, datos del pasaporte";
$_LANG["cnrxrupassportdatadescr"] = "Los datos del pasaporte del titular. Este campo se completa en ruso y puede contener letras rusas y latinas, números, signos de puntuación y espacios. Formato: número de documento, emitido por, fecha de emisión<br/>(solo requerido para personas físicas)";

// ----------------------------------------------------------------------
// ------------------ .SE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnicseidnumber"] = "Titular, número de identificación";
$_LANG["cnrxnicseidnumberdescr"] = "Número personal u organizacional.";
$_LANG["cnrxnicsevatid"] = "Titular, NIF";
$_LANG["cnrxnicsevatiddescr"] = "";
$_LANG["cnrxsediscloseemail"] = "Titular, mostrar correo electrónico";
$_LANG["cnrxsediscloseemaildescr"] = "Permitir la publicación del correo electrónico del titular en el WHOIS público.";
$_LANG["cnrxsedisclosefax"] = "Titular, mostrar fax";
$_LANG["cnrxsedisclosefaxdescr"] = "Permitir la publicación del número de fax del titular en el WHOIS público.";
$_LANG["cnrxsedisclosevoice"] = "Titular, mostrar teléfono";
$_LANG["cnrxsedisclosevoicedescr"] = "Permitir la publicación del número de teléfono del titular en el WHOIS público.";
foreach (["email", "fax", "voice"] as $field) {
    $_LANG["cnrxsedisclose$field" . "0"] = $_LANG["cnr0"];
    $_LANG["cnrxsedisclose$field" . "1"] = $_LANG["cnr1"];
}

// ----------------------------------------------------------------------
// ------------------ .SG Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxsgrcbid"] = "Titular, ID RCB";
$_LANG["cnrxsgrcbiddescr"] = "El número único de empresa (UEN) o el número de registro de empresa (RCB) del titular. Para <u>empresas</u> con sede en Singapur, debe proporcionarse el número de registro de empresa correspondiente O la tarjeta de identidad de contacto para presencia local en Singapur (Formato: S1234567D).";
$_LANG["cnrxsgadminsingpassid"] = "Admin, ID SingPass";
$_LANG["cnrxsgadminsingpassiddescr"] = "La tarjeta de identidad de contacto (ID SingPass) del contacto administrativo<br/>(solo para <u>personas físicas</u> de Singapur, formato: S1234567D)";

// ----------------------------------------------------------------------
// ------------------ .SK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxskcontactlegalform"] = "Titular, forma jurídica";
$_LANG["cnrxskcontactlegalformdescr"] = "";
// $_LANG["cnrxskcontactlegalformcorp"] = "";
// $_LANG["cnrxskcontactlegalformpers"] = "";
$_LANG["cnrxskcontactidentnumber"] = "Titular, número de registro mercantil";
$_LANG["cnrxskcontactidentnumberdescr"] = "Campo obligatorio para empresas/organizaciones";

// ----------------------------------------------------------------------
// ------------------ .SWISS Fields -------------------------------------
// ----------------------------------------------------------------------
// see other .swiss fields at top of the file
$_LANG["cnrxswissuid"] = "Titular, UID o UPI";
$_LANG["cnrxswissuiddescr"] = implode("", [
    "El ...<ul>",
    "<li>UID (Número de Identificación Empresarial, formato: \"CHE-ddd.ddd.ddd\") para organizaciones o</li>",
    "<li>UPI (Número de Identificación Personal Universal, formato: \"756.dddd.dddd.dd\") para personas físicas</li>",
    "</ul>... del titular (d = dígito).<br/>",
    "Nota: El nombre de la persona y la UPI NO se publican en Whois/RDAP, a diferencia del nombre de la organización y la UID, que sí son visibles."
]);
$_LANG["cnrxswissownertype"] = "Titular, tipo";
$_LANG["cnrxswissownertypep"] = "Persona física";
$_LANG["cnrxswissownertypeo"] = "Organización / Persona jurídica";
$_LANG["cnrxswissownertypedescr"] = "El tipo de identidad del titular.";

// ----------------------------------------------------------------------
// ------------------ .TRAVEL Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxtravelindustry"] = "Industria de viajes";
$_LANG["cnrxtravelindustryn"] = $_LANG["cnr0"];
$_LANG["cnrxtravelindustryy"] = $_LANG["cnr1"];
$_LANG["cnrxtravelindustrydescr"] = "Confirmo que el titular es miembro de la industria de viajes y posee un número de membresía válido.";

// ----------------------------------------------------------------------
// ------------------ .UK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxukownercorporatetype"] = "Titular, tipo de empresa";
$_LANG["cnrxukownercorporatetypedescr"] = "";
$_LANG["cnrxukownercorporatetypeother"] = "Otro";
$_LANG["cnrxukownercorporatetypefother"] = "Otro (No-UK)";
$_LANG["cnrxukownercorporatetypeind"] = "Persona física";
$_LANG["cnrxukownercorporatetypefind"] = "Persona física (No-UK)";
$_LANG["cnrxukownercorporatetypefcorp"] = "Empresa (No-UK)";
// $_LANG["cnrxukownercorporatetypeltd"] = "LTD";
// $_LANG["cnrxukownercorporatetypeplc"] = "PLC";
// $_LANG["cnrxukownercorporatetypellp"] = "LLP";
// $_LANG["cnrxukownercorporatetypeip"] = "IP";
$_LANG["cnrxukownercorporatetypecrc"] = "Empresa con carta real";
$_LANG["cnrxukownercorporatetypegov"] = "Agencia gubernamental";
$_LANG["cnrxukownercorporatetypeptnr"] = "Sociedad británica";
$_LANG["cnrxukownercorporatetyperchar"] = "Organización benéfica registrada";
$_LANG["cnrxukownercorporatetypesch"] = "Escuela";
$_LANG["cnrxukownercorporatetypestat"] = "Corporación pública";
$_LANG["cnrxukownercorporatetypestra"] = "Empresario individual";
$_LANG["cnrxukownercorporatenumber"] = "Titular, número de registro mercantil";
$_LANG["cnrxukownercorporatenumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .US Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxusnexusapppurpose"] = "Nexus US, propósito de uso";
$_LANG["cnrxusnexusapppurposep1"] = "Uso comercial con fines de lucro";
$_LANG["cnrxusnexusapppurposep2"] = "Organización sin fines de lucro, asociación, organización religiosa, etc.";
$_LANG["cnrxusnexusapppurposep3"] = "Uso personal";
$_LANG["cnrxusnexusapppurposep4"] = "Fines educativos";
$_LANG["cnrxusnexusapppurposep5"] = "Fines gubernamentales";
$_LANG["cnrxusnexusapppurposedescr"] = "";
$_LANG["cnrxusnexuscategory"] = "Nexus US, categoría";
$_LANG["cnrxusnexuscategoryc11"] = "[C11] Ciudadano estadounidense";
$_LANG["cnrxusnexuscategoryc12"] = "[C12] Residente permanente de EE.UU.";
$_LANG["cnrxusnexuscategoryc21"] = "[C21] Organización estadounidense";
$_LANG["cnrxusnexuscategoryc31"] = "[C31] Entidad extranjera con actividades en EE.UU.";
$_LANG["cnrxusnexuscategoryc32"] = "[C32] Entidad extranjera con oficina en EE.UU.";
$_LANG["cnrxusnexuscategorydescr"] = "Categorización de la entidad que realiza la solicitud.<br/>Nota: También se incluyen los territorios y posesiones de EE.UU.";
$_LANG["cnrxusnexusvalidator"] = "Nexus US, país";
$_LANG["cnrxusnexusvalidatordescr"] = "Indique el código de país de dos letras del titular (si la categoría Nexus es C31 o C32)";

// ----------------------------------------------------------------------
// ------------------ .XXX Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxxxxcommunityid"] = "ID de miembro de la comunidad";
$_LANG["cnrxxxxcommunityiddescr"] = "ID de miembro de la comunidad patrocinada .XXX";
$_LANG["cnrxxxxdefensive"] = "Registro defensivo<br/>(Dominio no resolvente)";
$_LANG["cnrxxxxdefensive0"] = $_LANG["cnr0"];
$_LANG["cnrxxxxdefensive1"] = $_LANG["cnr1"];
$_LANG["cnrxxxxdefensivedescr"] = implode("", [
    "Confirmo que el dominio es un registro defensivo. ",
    "El registro defensivo se refiere al registro de nombres de dominio, ",
    "a menudo en varias TLD y en diferentes formatos gramaticales, ",
    "con el propósito principal de proteger la propiedad intelectual o marcas contra abusos, ",
    "como el ciberocupación. Se define como un registro que no es único, no resuelve, ",
    "redirige el tráfico a un registro principal o no contiene contenido único.<br/>",
    "Nota: Si no se selecciona, el dominio se considerará como registro defensivo."
]);

// #########################################################################
// #########################################################################
// # Add reusable translations for ALL PROVIDERS                           #
// #########################################################################
// #########################################################################

/// ----------------------------------------------------------------------
// ---------------- EMAIL VERIFICATION ----------------------------------
// ----------------------------------------------------------------------
// $_LANG["cnicemailverification"] = "Verificación de correo electrónico";
// $_LANG["emailverificationtitle"] = "Verifique su correo electrónico";
// $_LANG["emailverificationinfo"] = "Se requiere verificación para la siguiente información de contacto";
// $_LANG["emailverificationconsequences"] = "No verificar su correo electrónico puede resultar en la suspensión de su dominio.";
// $_LANG["emailverificationresendemailinfo"] = "Si no ha recibido el correo electrónico, haga clic en el botón de abajo para reenviar el correo de verificación.";
// $_LANG["verified"] = "Verificado";
// $_LANG["emailverificationpending"] = "Pendiente";

// ----------------------------------------------------------------------
// ----------------------- DNSSEC MANAGEMENT ----------------------------
// ----------------------------------------------------------------------
$_LANG["cnicdnssecmanagement"] = "Gestión de DNSSEC";

// Status Messages
$_LANG["dnssecautomaticupdatesuccessmsg"] = "DNSSEC ha sido <span style=\"color:green;font-weight:bold;\">activado</span> para su dominio.<br> Los registros DNSSEC fueron importados desde su zona DNS y actualizados en su registrador de dominio.<br><br><span style=\"color:#007bff;\">Por su seguridad, DNSSEC ayuda a proteger su dominio de ciertos tipos de ataques validando las respuestas DNS.</span>";
$_LANG["dnssecautoenable"] = "Activar DNSSEC e importar automáticamente registros desde la zona DNS";
$_LANG["dnssecsyncrecords"] = "Sincronizar registros DNSSEC desde la zona DNS";

// Record Management
$_LANG["dnssecaddnewdskey"] = "Agregar Nueva Clave DS";
$_LANG["dnssecaddnewkeyrecord"] = "Agregar Nuevo Registro de Clave";

// Modal Dialog
$_LANG["dnssecconfirmdisable"] = "¿Está seguro de que desea desactivar DNSSEC para este dominio? Esta acción puede afectar la resolución del dominio.";
$_LANG["dnssecmodaltitle"] = "Desactivar DNSSEC";
$_LANG["dnssecmodalcancel"] = "Cancelar";
$_LANG["dnssecmodaldisable"] = "Desactivar DNSSEC";
