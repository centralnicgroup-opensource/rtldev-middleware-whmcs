<?php

// #########################################################################
// #########################################################################
// # Add translations for CNR registrar module additional domain fields    #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ------------------ .DK Checkout Page ---------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrdkcheckoutheading"] = "Allgemeine Geschäftsbedingungen für .dk Domainnamen";
$_LANG["cnrdkcheckoutintro"] = "Um einen .dk Domainnamen zu registrieren, müssen Sie einen Vertrag mit Punktum.dk A/S abschließen. Punktum dk ist der Administrator für alle .dk Domainnamen.";
$_LANG["cnrdkcheckoutdomains"] = "Domainnamen:";
$_LANG["cnrdkcheckoutregistrant"] = "Inhaber:";
$_LANG["cnrdkcheckoutregistrantaddress"] = "Siehe oben";
$_LANG["cnrdkcheckoutadmin"] = "Domain-Administrator:";
$_LANG["cnrdkcheckoutadminaddress"] = "Punktum dk A/S<br/>Ørestads Boulevard 108, 11. Stock<br/>DK-2300 Kopenhagen S";
$_LANG["cnrdkcheckouttac"] = implode("<br/><br/>", [
    "Ich erkläre mich hiermit einverstanden, einen Vertrag über das Recht zur Nutzung des angegebenen .dk Domainnamens gemäß den geltenden Bedingungen abzuschließen. Unter anderem bedeutet dies, dass ich sicherstelle, dass meine Kontaktdaten als Inhaber jederzeit korrekt sind. Ich werde die Identitätsprüfung von Punktum dk A/S durchführen, wenn ich dazu aufgefordert werde.",
    "Mein Recht zur Nutzung des angegebenen .dk Domainnamens kann gemäß den Bedingungen in den Nutzungsbedingungen von Punktum dk A/S übertragen, ausgesetzt, gelöscht oder gesperrt werden.",
    "Gemäß Abschnitt 18 (2) (13) des dänischen Verbrauchervertragsgesetzes verzichte ich auf das Recht, vom Vertrag über das Nutzungsrecht des angegebenen .dk Domainnamens zurückzutreten.",
    "Ich gebe meine Zustimmung, dass Punktum dk A/S, als Domain-Administrator, meine persönlichen Daten gemäß seiner Datenschutzrichtlinie verwendet.",
    "Ich stimme zu, dass ich diesem Anbieter die Gebühr für den ersten Registrierungszeitraum des angegebenen .dk Domainnamens bezahle und dass die Zahlung für nachfolgende Registrierungszeiträume von meiner Wahl der Verwaltungsregelung abhängt, gemäß Abschnitt 2.1 der Allgemeinen Geschäftsbedingungen von Punktum dk A/S."
]);
$_LANG["cnrdkcheckouttacurl"] = "https://www.punktum.dk/en/articles/terms-and-conditions-for-the-right-of-use-to-a-dk-domain-name";
$_LANG["cnrdkcheckouttacurltext"] = "Allgemeine Geschäftsbedingungen für das Nutzungsrecht eines .dk Domainnamens";
$_LANG["cnrdkcheckoutpolicyurl"] = "https://www.punktum.dk/en/articles/privacy-policy";
$_LANG["cnrdkcheckoutpolicyurltext"] = "Datenschutzrichtlinie";
$_LANG["cnrdkcheckoutabouturl"] = "https://www.punktum.dk/en/about-us";
$_LANG["cnrdkcheckoutabouturltext"] = "Über Punktum dk A/S";
$_LANG["cnrdkcheckouttacagree"] = "Ja, ich akzeptiere die Benutzervereinbarung mit Punktum dk A/S.";

// ----------------------------------------------------------------------
// ------------------ Common CNR Translations ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrchoose"] = "Bitte wählen";
$_LANG["cnroptional"] = "optional";
$_LANG["cnr1"] = "Ja";
$_LANG["cnr0"] = "Nein";
$_LANG["cnrconsentforpublishing"] = "Registrant, Zustimmung zur Veröffentlichung";
// .abogado, .aero, .attorney, .bank, .broker, .dentist, .forex, .insurance, .lotto, .law, .lawyer, .markets, .trading
$_LANG["cnrxallocationtoken"] = "Bestellschlüssel der Registrierungsstelle";
$_LANG["cnrxallocationtokendescr"] = "Nur erforderlich für Premium-Domains. Ausgestellt durch den TLD-Provider. Lassen Sie uns wissen, wenn Sie Hilfe benötigen.";
// .app, .page, .dev, .new, .day, .channel, .boo, .foo, .zip, .mov, .nexus, .dad, .phd, .prof, .esq, .rsvp, .meme, .ing, .new
$_LANG["cnrxacceptsslrequirement"] = "SSL Anforderungen";
$_LANG["cnrxacceptsslrequirementdescr"] = "Ich bestätige, dass ich die Anforderungen für HTTPS / ein SSL-Zertifikat verstehe und akzeptiere. Diese TLD ist eine sicherere Domain, was bedeutet, dass HTTPS für alle Websites erforderlich ist. Sie können Ihren Domainnamen jetzt kaufen, aber damit er in Browsern ordnungsgemäß funktioniert, müssen Sie HTTPS basierend auf einem SSL-Zertifikat konfigurieren.";
$_LANG["cnrxacceptsslrequirement0"] = $_LANG["cnr0"];
$_LANG["cnrxacceptsslrequirement1"] = $_LANG["cnr1"];
// .attorney, .dentist, .lawyer
$_LANG["cnrxunitedtldregulatorydata"] = "Regulierungsbehörde Informationen";
$_LANG["cnrxunitedtldregulatorydatadescr"] = "Informationen über die genehmigende Behörde/kontrollierende Behörde/Regulierungsbehörde";
// .barcelona, .cat, .madrid, .scot, .sport, .swiss
$_LANG["cnrxintendeduse"] = "Beabsichtigte Nutzung";
$_LANG["cnrxintendedusedescr"] = implode("<br/>", [
    "Erklärung zur beabsichtigten Nutzung des Domainnamens. Falls zutreffend, bitte einen expliziten Verweis auf das beanspruchte Recht des Antragstellers auf den Namen angeben (falls nicht der Firmenname des Antragstellers).",
    "Zum Beispiel, wenn der Domainname einer Marke entspricht, muss die Markenregistrierungsnummer angegeben werden (max. 256 Zeichen)."
]);
// .mk
$_LANG["cnrxcompanyvatid"] = "Registrant, USt-IdNr.";
// $_LANG["cnrxcompanyvatiddescr"] = "";
// .nu, .se
$_LANG["cnrxrequestauthcode"] = "Neuen EPP-Code anfordern";
$_LANG["cnrxrequestauthcode0"] = $_LANG["cnr0"];
$_LANG["cnrxrequestauthcode1"] = $_LANG["cnr1"];
$_LANG["cnrxrequestauthcodedescr"] = "Wenn Sie die Domain zu einem anderen Registrar transferieren möchten, benötigen Sie den Auth-Code. Wir senden ihn an die E-Mail-Adresse des Domaininhabers.";

// NOTE: The following translations are labeled as boilerplate and should
// be used as a template for other languages. English texts are returned
// by default from the CNR Backend System. If you want to override these
// default texts, please consider a language override file in WHMCS using
// the below translation keys.
// We added some translations to override the API defaults which sometimes
// suck.

// ----------------------------------------------------------------------
// ------------------ DOMAIN DETAILS (and sub pages) --------------------
// ----------------------------------------------------------------------
$_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] = (
    "<small>Wir haben einige Probleme mit Ihren Domain-Kontaktinformationen festgestellt, die Ihre Aufmerksamkeit erfordern. Um dies zu beheben:<br/><br/><ol>" .
    "<li>Wechseln Sie zum Kundenbereich (zusätzliche Felder werden dort ebenfalls aufgelistet, falls zutreffend)</li>" .
    "<li>Gehen Sie zur Seite <b>Kontaktinformationen</b> dieser Domain</li>" .
    "<li>Nehmen Sie die erforderlichen Korrekturen vor</li>" .
    "<li>Schließen Sie den Verifizierungsprozess unmittelbar danach ab, falls zutreffend</li></ol></small>"
 );
$_LANG["cnrdomaincontactvalidationerrorsummary"] = (
    "<small>Wir haben einige Probleme mit Ihren Domain-Kontaktinformationen festgestellt, die Ihre Aufmerksamkeit erfordern. Um dies zu beheben:<br/><br/><ol>" .
    "<li>Gehen Sie zur Seite <b><a href=\"clientarea.php?action=domaincontacts&domainid=:domainid\">Kontaktinformationen</a></b> und überprüfen Sie Ihre Angaben</li>" .
    "<li>Nehmen Sie die erforderlichen Korrekturen vor</li>" .
    "<li>Schließen Sie den Verifizierungsprozess unmittelbar danach ab, falls zutreffend</li></ol></small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspensionadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Bitte schließen Sie diese Schritte bis zum <b>:suspensiondate</b> ab, um eine Sperrung Ihrer Domain zu verhindern.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspension"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Bitte schließen Sie diese Schritte bis zum <b>:suspensiondate</b> ab, um eine Sperrung Ihrer Domain zu verhindern.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspendedadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Ihre Domain wurde gesperrt. Bitte schließen Sie diese Schritte ab, um die Sperrung Ihrer Domain aufzuheben.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspended"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Ihre Domain wurde gesperrt. Bitte schließen Sie diese Schritte ab, um die Sperrung Ihrer Domain aufzuheben.</small>"
);

// ----------------------------------------------------------------------
// ------------------ .AERO Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaeroensauthid"] = "Mitglieds-ID";
$_LANG["cnrxaeroensauthiddescr"] = "Die .AERO Mitglieds-ID wird benötigt, um eine Domain in der Luftfahrt zu registrieren. Sie können sie <a style=\"text-decoration:underline\" href=\"https://information.aero/node/add/request-aero-id\" target=\"_blank\">hier</a> beantragen.";
$_LANG["cnrxaeroensauthkey"] = "Mitglieds-Passwort";
$_LANG["cnrxaeroensauthkeydescr"] = "Das jeweilige Passwort/Authcode, das von der oben genannten Website gleichzeitig mit der .AERO Mitglieds-ID bereitgestellt wird.";

// ----------------------------------------------------------------------
// ------------------ .AU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaudomainrelation"] = "Beziehung";
$_LANG["cnrxaudomainrelation1"] = "Die Second-Level-Domain ist eine exakte Übereinstimmung, ein Akronym oder eine Abkürzung des Unternehmens- oder Handelsnamens, des Organisations- oder Vereinsnamens oder der Marke.";
$_LANG["cnrxaudomainrelation2"] = "Die Second-Level-Domain steht in enger und wesentlicher Verbindung zur Organisation oder den von der Organisation durchgeführten Aktivitäten.";
$_LANG["cnrxaudomainrelationdescr"] = "Dies gibt die Beziehung zwischen dem Berechtigungstyp (z.B. Geschäftsname) und dem Domainnamen an.";
$_LANG["cnrxaudomainrelationtype"] = "Beziehungstyp";
$_LANG["cnrxaudomainrelationtypecompany"] = "Unternehmen";
$_LANG["cnrxaudomainrelationtyperegisteredbusiness"] = "Eingetragenes Unternehmen";
$_LANG["cnrxaudomainrelationtypesoletrader"] = "Einzelunternehmer";
$_LANG["cnrxaudomainrelationtypepartnership"] = "Partnerschaft";
$_LANG["cnrxaudomainrelationtypetrademarkowner"] = "Markeninhaber";
$_LANG["cnrxaudomainrelationtypependingtmowner"] = "Markenanmeldung";
$_LANG["cnrxaudomainrelationtypecitizenresident"] = "Bürger / Einwohner"; // .id.au only
$_LANG["cnrxaudomainrelationtypeincorporatedassociation"] = "Eingetragener Verein";
$_LANG["cnrxaudomainrelationtypeclub"] = "Club";
$_LANG["cnrxaudomainrelationtypenonprofitorganisation"] = "Gemeinnützige Organisation";
$_LANG["cnrxaudomainrelationtypecharity"] = "Wohltätigkeitsorganisation";
$_LANG["cnrxaudomainrelationtypetradeunion"] = "Gewerkschaft";
$_LANG["cnrxaudomainrelationtypeindustrybody"] = "Branchenverband";
$_LANG["cnrxaudomainrelationtypecommercialstatutorybody"] = "Kommerzielle Körperschaft des öffentlichen Rechts";
$_LANG["cnrxaudomainrelationtypepoliticalparty"] = "Politische Partei";
$_LANG["cnrxaudomainrelationtypeother"] = "Andere";
$_LANG["cnrxaudomainrelationtypereligiouschurchgroup"] = "Religiöse / Kirchliche Gruppe";
$_LANG["cnrxaudomainrelationtypehighereducationinstitution"] = "Hochschule";
$_LANG["cnrxaudomainrelationtyperesearchorganisation"] = "Forschungseinrichtung";
$_LANG["cnrxaudomainrelationtypegovernmentschool"] = "Staatliche Schule";
$_LANG["cnrxaudomainrelationtypechildcarecentre"] = "Kindertagesstätte";
$_LANG["cnrxaudomainrelationtypepreschool"] = "Vorschule";
$_LANG["cnrxaudomainrelationtypenationalbody"] = "Nationale Organisation";
$_LANG["cnrxaudomainrelationtypetrainingorganisation"] = "Bildungseinrichtung";
$_LANG["cnrxaudomainrelationtypenongovernmentschool"] = "Nicht-staatliche Schule";
$_LANG["cnrxaudomainrelationtypeunincorporatedassociation"] = "Nicht eingetragener Verein";
$_LANG["cnrxaudomainrelationtypeindustryorganisation"] = "Branchenorganisation";
$_LANG["cnrxaudomainrelationtyperegistrablebody"] = "Registrierbare Körperschaft";
$_LANG["cnrxaudomainrelationtypeindigenouscorporation"] = "Indigene Körperschaft";
$_LANG["cnrxaudomainrelationtyperegisteredorganisation"] = "Eingetragene Organisation";
$_LANG["cnrxaudomainrelationtypetrust"] = "Treuhand";
$_LANG["cnrxaudomainrelationtypeeducationalinstitution"] = "Bildungseinrichtung";
$_LANG["cnrxaudomainrelationtypecommonwealthentity"] = "Commonwealth-Entität";
$_LANG["cnrxaudomainrelationtypestatutorybody"] = "Körperschaft des öffentlichen Rechts";
$_LANG["cnrxaudomainrelationtypetradingcooperative"] = "Handelsgenossenschaft";
$_LANG["cnrxaudomainrelationtypecompanylimitedbyguarantee"] = "Gesellschaft mit beschränkter Haftung";
$_LANG["cnrxaudomainrelationtypenondistributingcooperative"] = "Nicht-verteilende Genossenschaft";
$_LANG["cnrxaudomainrelationtypenontradingcooperative"] = "Nicht-handelsgenossenschaft";
$_LANG["cnrxaudomainrelationtypecharitabletrust"] = "Wohltätigkeitstreuhand";
$_LANG["cnrxaudomainrelationtypepublicprivateancillaryfund"] = "Öffentlicher / Privater Hilfsfonds";
$_LANG["cnrxaudomainrelationtypepeakstateterritorybody"] = "Spitzenverband des Staates / Territoriums";
$_LANG["cnrxaudomainrelationtypenotforprofitcommunitygroup"] = "Gemeinnützige Gemeinschaftsgruppe";
$_LANG["cnrxaudomainrelationtypeeducationandcareserviceschildcare"] = "Bildungs- und Betreuungsdienste (Kinderbetreuung)";
$_LANG["cnrxaudomainrelationtypegovernmentbody"] = "Regierungsbehörde";
$_LANG["cnrxaudomainrelationtypeproviderofnonaccreditedtraining"] = "Anbieter von nicht akkreditierten Schulungen";
$_LANG["cnrxaudomainrelationtypedescr"] = "Geben Sie an, was den Registranten berechtigt, den Domainnamen zu registrieren";
$_LANG["cnrxauownerorganization"] = "Registrant, Organisation";
$_LANG["cnrxauownerorganizationdescr"] = "Der Name der Organisation (Registrant)";
$_LANG["cnrxauidwarranty"] = "Registrant,<br>ist AU-Bürger oder Einwohner";
$_LANG["cnrxauidwarranty0"] = $_LANG["cnr0"];
$_LANG["cnrxauidwarranty1"] = $_LANG["cnr1"];
$_LANG["cnrxauidwarrantydescr"] = "Der Registrant einer .id.au-Domain muss garantieren, dass er ein australischer Einwohner oder Bürger ist";
$_LANG["cnrxaueligibilityname"] = "Berechtigungsname";
$_LANG["cnrxaueligibilitynamedescr"] = "Der Name des Berechtigungstyps (z.B. Geschäftsname)";
$_LANG["cnrxaudomainidnumber"] = "Registrant, Identifikationsnummer";
$_LANG["cnrxaudomainidnumberdescr"] = "";
$_LANG["cnrxaudomainidtype"] = "Registrant, Identifikationstyp";
// $_LANG["cnrxaudomainidtypetm"] = "TM";
// $_LANG["cnrxaudomainidtypeabn"] = "ABN";
// $_LANG["cnrxaudomainidtypeacn"] = "ACN";
// $_LANG["cnrxaudomainidtypeother"] = "Other";
// $_LANG["cnrxaudomainidtypeact"] = "ACT";
// $_LANG["cnrxaudomainidtypensw"] = "NSW";
// $_LANG["cnrxaudomainidtypent"] = "NT";
// $_LANG["cnrxaudomainidtypeqld"] = "QLD";
// $_LANG["cnrxaudomainidtypesa"] = "SA";
// $_LANG["cnrxaudomainidtypetas"] = "TAS";
// $_LANG["cnrxaudomainidtypevic"] = "VIC";
// $_LANG["cnrxaudomainidtypewa"] = "WA";
// $_LANG["cnrxaudomainidtypeprivate"] = "Private";
$_LANG["cnrxaudomainidtypedescr"] = "";
$_LANG["cnrxaueligibilityidnumber"] = "Berechtigung, Identifikationsnummer";
$_LANG["cnrxaueligibilityidnumberdescr"] = "";
$_LANG["cnrxaueligibilityidtype"] = "Berechtigung, Identifikationstyp";
$_LANG["cnrxaueligibilityidtypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .CA Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcalegaltype"] = "Registrant, Rechtstyp";
$_LANG["cnrxcalegaltypeabo"] = "Ureinwohner Kanadas";
$_LANG["cnrxcalegaltypeass"] = "Kanadische nicht eingetragene Vereinigung";
$_LANG["cnrxcalegaltypecco"] = "Körperschaft (Kanada oder kanadische Provinz oder Territorium)";
$_LANG["cnrxcalegaltypecct"] = "Kanadischer Staatsbürger";
$_LANG["cnrxcalegaltypeedu"] = "Kanadische Bildungseinrichtung";
$_LANG["cnrxcalegaltypegov"] = "Regierung oder Regierungsbehörde in Kanada";
$_LANG["cnrxcalegaltypehop"] = "Kanadisches Krankenhaus";
$_LANG["cnrxcalegaltypeinb"] = "Indianischer Stamm anerkannt durch den Indian Act von Kanada";
$_LANG["cnrxcalegaltypelam"] = "Kanadische Bibliothek, Archiv oder Museum";
$_LANG["cnrxcalegaltypelgr"] = "Rechtlicher Vertreter eines kanadischen Staatsbürgers oder ständigen Bewohners";
$_LANG["cnrxcalegaltypemaj"] = "Ihre Majestät die Königin";
$_LANG["cnrxcalegaltypeomk"] = "Offizielles Markenzeichen in Kanada registriert";
$_LANG["cnrxcalegaltypeplt"] = "Kanadische politische Partei";
$_LANG["cnrxcalegaltypeprt"] = "In Kanada eingetragene Partnerschaft";
$_LANG["cnrxcalegaltyperes"] = "Ständiger Bewohner Kanadas";
$_LANG["cnrxcalegaltypetdm"] = "In Kanada registrierte Marke (durch einen nicht-kanadischen Inhaber)";
$_LANG["cnrxcalegaltypetrd"] = "Kanadische Gewerkschaft";
$_LANG["cnrxcalegaltypetrs"] = "In Kanada gegründetes Treuhandvermögen";
// $_LANG["cnrxcalegaltypedescr"] = "";
$_LANG["cnrxcatrademark"] = "Ist eine eingetragene Marke";
$_LANG["cnrxcatrademark0"] = $_LANG["cnr0"];
$_LANG["cnrxcatrademark1"] = $_LANG["cnr1"];
$_LANG["cnrxcatrademarkdescr"] = "Gibt an, ob die Domain eine eingetragene Marke ist oder nicht.";

// ----------------------------------------------------------------------
// ------------------ .COM.BR Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxbrregisternumber"] = "Registrant, Brasil. Identifikationsnummer";
$_LANG["cnrxbrregisternumberdescr"] = "Die brasilianische Unternehmensregisternummer (CNPJ) oder die brasilianische individuelle Registernummer (CPF).";

// ----------------------------------------------------------------------
// ------------------ .CN Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcnownertype"] = "Registrant, Typ";
$_LANG["cnrxcnownertypei"] = "Privatperson";
$_LANG["cnrxcnownertypee"] = "Unternehmen";
$_LANG["cnrxcnownertypedescr"] = "";
$_LANG["cnrxcnowneridtype"] = "Registrant, ID Typ";
$_LANG["cnrxcnowneridtypesfz"] = "SFZ (Personalausweis) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypehz"] = "HZ (Reisepass) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypegajmtx"] = "GAJMTX (Ausreise-Einreise-Erlaubnis für Reisen nach Hongkong und Macao) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypetwjmtx"] = "TWJMTX (Reisepässe für Taiwan-Bewohner zur Ein- und Ausreise) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypewjlsfz"] = "WJLSFZ (Ausländischer Daueraufenthaltsausweis) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypegajzz"] = "GAJZZ (Aufenthaltserlaubnis für Hongkong und Macao Bewohner) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypetwjzz"] = "TWJZZ (Aufenthaltserlaubnis für Taiwan Bewohner) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypejgz"] = "JGZ (Offiziersausweis) - Registrant Typ ist Privatperson";
$_LANG["cnrxcnowneridtypeqt"] = "QT (Andere) - Registrant Typ ist Privatperson oder Unternehmen";
$_LANG["cnrxcnowneridtypeorg"] = "ORG (Organisationscode-Zertifikat) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypeyyzz"] = "YYZZ (Gewerbeerlaubnis) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypetydm"] = "TYDM (Zertifikat für einheitlichen Sozialkreditcode) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypebddm"] = "BDDM (Militärischer Code-Bezeichnung) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypejddwfw"] = "JDDWFW (Militärisch bezahlte externe Dienstleistungslizenz) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypesydwfr"] = "SYDWFR (Zertifikat einer juristischen Person einer öffentlichen Einrichtung) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypewgczjg"] = "WGCZJG (Registrierungsformular für ansässige Vertretungen ausländischer Unternehmen) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypeshttfr"] = "SHTTFR (Registrierungszertifikat einer sozialen Organisation) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypezjcs"] = "ZJCS (Registrierungszertifikat einer religiösen Aktivitätsstätte) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypembfqy"] = "MBFQY (Registrierungszertifikat einer privaten Nichtunternehmenseinheit) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypejjhfr"] = "JJHFR (Registrierungszertifikat einer Stiftung) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypelszy"] = "LSZY (Lizenz einer Anwaltskanzlei) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypewgzhwh"] = "WGZHWH (Registrierungszertifikat eines ausländischen Kulturzentrums in China) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypewlczzg"] = "WLCZJG (Registrierungszertifikat für ansässige Vertretungen der Tourismusabteilungen einer ausländischen Regierung) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypesfjd"] = "SFJD (Zertifikat einer juristischen Ausbildung) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypejwjg"] = "JWJG (Zertifikat eines Unternehmens im Ausland) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypeshfwjg"] = "SHFWJG (Registrierungszertifikat einer Sozialdienstagentur) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypembxxbx"] = "MBXXBX (Erlaubnis einer Privatschule) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypeyljgzy"] = "YLJGZY (Lizenz einer medizinischen Einrichtung) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypegzjgzy"] = "GZJGZY (Lizenz eines notariellen Unternehmens) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypebjwsxx"] = "BJWSXX (Erlaubnis der Schule für Kinder ausländischer Botschaftsmitarbeiter in Beijing/China) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypeqttyzm"] = "QTTYDM (Andere-Zertifikat für einheitlichen Sozialkreditcode) - Registrant Typ ist Unternehmen";
$_LANG["cnrxcnowneridtypedescr"] = "Identifikationstyp des Ausweises";
$_LANG["cnrxcnowneridnumber"] = "Registrant, ID Nummer";
$_LANG["cnrxcnowneridnumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COOP Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcoopeligibility"] = "Berechtigungsvoraussetzungen";
$_LANG["cnrxcoopeligibilitydescr"] = "Akzeptieren Sie, dass meine Organisation mindestens eine der .COOP-Berechtigungsvoraussetzungen erfüllt. Lesen Sie <a style=\"text-decoration:underline\" href=\"https://identity.coop/coop-policies-and-agreements/\" target=\"_blank\">hier</a>.";
$_LANG["cnrxcoopeligibility0"] = $_LANG["cnr0"];
$_LANG["cnrxcoopeligibility1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .DE Fields ----------------------------------------
// ----------------------------------------------------------------------
//$_LANG["cnrxdensentry0"] = "";
$_LANG["cnrxdensentry0descr"] = implode(" ", [
    "Ermöglicht die Verwendung von nsentrys anstelle von Nameservern für .de-Domains;",
    "NS-Einträge ermöglichen die Konfiguration von Subdomains mit alternativen Nameservern.",
    "<a target=\"_blank\" href=\"https://www.denic.de/en/domains/de-domains/registration/nameserver-and-nsentry-data/\" style=\"text-decoration:underline\">Detaillierte Informationen</a>."
]);
//$_LANG["cnrxdensentry1"] = "";
$_LANG["cnrxdensentry1descr"] = "siehe oben";
//$_LANG["cnrxdensentry2"] = "";
$_LANG["cnrxdensentry2descr"] = "siehe oben";
//$_LANG["cnrxdensentry3"] = "";
$_LANG["cnrxdensentry3descr"] = "siehe oben";
//$_LANG["cnrxdensentry4"] = "";
$_LANG["cnrxdensentry4descr"] = "siehe oben";
//$_LANG["cnrxdegeneralrequest"] = "";
//$_LANG["cnrxdegeneralrequestdescr"] = "";
//$_LANG["cnrxdeabusecontact"] = "";
//$_LANG["cnrxdeabusecontactdescr "] = "";

// ----------------------------------------------------------------------
// ------------------ .DK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdkusertype"] = "Registrant, Typ";
$_LANG["cnrxdkusertypeperson"] = "Person";
$_LANG["cnrxdkusertypecompany"] = "Unternehmen";
$_LANG["cnrxdkusertypeassociation"] = "Verein";
$_LANG["cnrxdkusertypepuborg"] = "Öffentliche Organisation";
// $_LANG["cnrxdkusertypedescr"] = "";
$_LANG["cnrxdkuseridnumber"] = "Registrant, ID Nummer";
$_LANG["cnrxdkuseridnumberdescr"] = implode("", [
    "Identifikationsnummer des Registrantenkontakts. Dies kann <i>EAN, CVR oder P Nummer</i> sein. ",
    "Die <i>CVR Nummer</i> wird zur Identifizierung der Organisation verwendet, und die <i>EAN Nummer</i> stellt sicher, ",
    "dass Dokumente im Zusammenhang mit der elektronischen Rechnungsstellung an das richtige Konto gesendet werden. ",
    "Die <i>P Nummer</i> ist eine Filialkennzeichnung, die vom dänischen Zentralen Unternehmensregister zugewiesen wird, um ",
    "physische Standorte mit einer Organisation zu verknüpfen."
]);

// ----------------------------------------------------------------------
// ------------------ .ES Fields ----------------------------------------
// ----------------------------------------------------------------------
$types = [
    1 => "Privatperson",
    39 => "Wirtschaftliche Interessenvereinigung",
    47 => "Verband",
    59 => "Sportverein",
    68 => "Berufsverband",
    124 => "Sparkasse",
    150 => "Gemeinschaftsgut",
    152 => "Eigentümergemeinschaft",
    164 => "Orden oder religiöse Einrichtung",
    181 => "Konsulat",
    197 => "Verband des öffentlichen Rechts",
    203 => "Botschaft",
    229 => "Kommunalverwaltung",
    269 => "Sportbund",
    286 => "Stiftung",
    365 => "Gegenseitigkeitsversicherungsgesellschaft",
    434 => "Landesregierungsbehörde",
    436 => "Zentrale Regierungsbehörde",
    439 => "Politische Partei",
    476 => "Gewerkschaft",
    510 => "Landwirtschaftliche Partnerschaft",
    524 => "Aktiengesellschaft",
    525 => "Sportverein",
    554 => "Zivilgesellschaft",
    560 => "Allgemeine Partnerschaft",
    562 => "Allgemeine und beschränkte Partnerschaft",
    566 => "Genossenschaft",
    608 => "Mitarbeitergeführtes Unternehmen",
    612 => "Gesellschaft mit beschränkter Haftung",
    713 => "Spanisches Amt",
    717 => "Vorübergehende Unternehmenskooperation",
    744 => "Mitarbeitergeführte Aktiengesellschaft",
    745 => "Regionale öffentliche Einrichtung",
    746 => "Nationale öffentliche Einrichtung",
    747 => "Lokale öffentliche Einrichtung",
    877 => "Sonstige",
    878 => "Aufsichtsrat der Ursprungsbezeichnung",
    879 => "Einheit zur Verwaltung natürlicher Gebiete"
];
$idtypes = [
    0 => "Andere (für Kontakte außerhalb Spaniens)",
    1 => "DNI/NIF (für spanische Kontakte)",
    2 => "Veraltet, bitte nächste Option verwenden.",
    3 => "NIE (für spanische Kontakte)",
    4 => "USt-IdNr. (Steuernummer) - nur gültig für nicht-spanische juristische Personen"
];
$idtypesdescr = implode("<br/>", [
    "DNI = &quot;Documento Nacional de Identidad&quot;",
    "NIF = &quot;Número de Identificación Fiscal&quot;",
    "NIE = &quot;Número de Identificación de Extranjero&quot;. Es ist das Äquivalent einer spanischen NIF, wird aber von spanischen Behörden an Ausländer ausgestellt, die länger als 3 Monate in Spanien bleiben."
]);
$idnodescr = "Die Identifikationsnummer dieses Kontakts. Für spanische Kontakte ist dies die DNI/NIF/NIE-Nummer - andernfalls die Ausweis- oder Passnummer.";

$_LANG["cnrxesownertipoidentificacion"] = "Inhaber, Identifikationstyp";
$_LANG["cnrxesadmintipoidentificacion"] = "Admin, Identifikationstyp";
$_LANG["cnrxestechtipoidentificacion"] = "Tech, Identifikationstyp";
$_LANG["cnrxesbillingtipoidentificacion"] = "Abrechnung, Identifikationstyp";

foreach ($idtypes as $key => $value) {
    $_LANG["cnrxesownertipoidentificacion$key"] = $value;
    $_LANG["cnrxesadmintipoidentificacion$key"] = $value;
    $_LANG["cnrxestechtipoidentificacion$key"] = $value;
    $_LANG["cnrxesbillingtipoidentificacion$key"] = $value;
}

$_LANG["cnrxesownertipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesadmintipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxestechtipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesbillingtipoidentificaciondescr"] = $idtypesdescr;

$_LANG["cnrxesowneridentificacion"] = "Inhaber, Identifikationsnummer";
$_LANG["cnrxesadminidentificacion"] = "Admin, Identifikationsnummer";
$_LANG["cnrxestechidentificacion"] = "Tech, Identifikationsnummer";
$_LANG["cnrxesbillingidentificacion"] = "Abrechnung, Identifikationsnummer";

$_LANG["cnrxesowneridentificaciondescr"] = $idnodescr;
$_LANG["cnrxesadminidentificaciondescr"] = $idnodescr;
$_LANG["cnrxestechidentificaciondescr"] = $idnodescr;
$_LANG["cnrxesbillingidentificaciondescr"] = $idnodescr;

$_LANG["cnrxesownerlegalform"] = "Inhaber, Rechtsform";
$_LANG["cnrxesadminlegalform"] = "Admin, Rechtsform";
$_LANG["cnrxestechlegalform"] = "Tech, Rechtsform";
$_LANG["cnrxesbillinglegalform"] = "Billing, Rechtsform";

foreach ($types as $key => $value) {
    $_LANG["cnrxesownerlegalform$key"] = $value;
    $_LANG["cnrxesadminlegalform$key"] = $value;
    $_LANG["cnrxestechlegalform$key"] = $value;
    $_LANG["cnrxesbillinglegalform$key"] = $value;
}

$_LANG["cnrxesownerlegalformdescr"] = "";
$_LANG["cnrxesadminlegalformdescr"] = "";
$_LANG["cnrxestechlegalformdescr"] = "";
$_LANG["cnrxesbillinglegalformdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .EU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxeuregistrantlang"] = "Registrant, Sprache";
$_LANG["cnrxeuregistrantcitizenship"] = "Registrant, Staatsbürgerschaft";
$_LANG["cnrxeuregistrantlangdescr"] = "Sprache für die Kommunikation mit dem TLD-Anbieter (Standard = Englisch)";
$_LANG["cnrxeuregistrantcitizenshipdescr"] = "Privatpersonen mit europäischer Staatsbürgerschaft, die nicht in der EU leben, können .eu-Domains mit dieser Einstellung registrieren.";

// ----------------------------------------------------------------------
// ------------------ .FI Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxficompanyregid"] = "Registrant, Unternehmens-ID oder Registrierungsnummer";
$_LANG["cnrxficompanyregiddescr"] = "Lokale Geschäftseinheit (registriert im finnischen Handelsregister oder eine Körperschaft innerhalb der finnischen Republik)<br/>(erforderlich für nicht-finnische Einheiten)";
$_LANG["cnrxfipersonalid"] = "Registrant, persönliche Identifikationsnummer";
$_LANG["cnrxfipersonaliddescr"] = "Finnische persönliche Identifikationsnummer<br/>(erforderlich für nicht-finnische Privatpersonen)";
$_LANG["cnrxfibirthdate"] = "Registrant, Geburtsdatum";
$_LANG["cnrxfibirthdatedescr"] = "Geburtsdatum (YYYY-MM-DD)<br/>(erforderlich für nicht-finnische Privatpersonen)";
$_LANG["cnrxficontacttype"] = "Registrant, Kontakttyp";
$_LANG["cnrxficontacttype0"] = "Privatperson";
$_LANG["cnrxficontacttype1"] = "Unternehmen";
$_LANG["cnrxficontacttype2"] = "Körperschaft";
$_LANG["cnrxficontacttype3"] = "Institution";
$_LANG["cnrxficontacttype4"] = "Politische Partei";
$_LANG["cnrxficontacttype5"] = "Gemeinde";
$_LANG["cnrxficontacttype6"] = "Regierung";
$_LANG["cnrxficontacttype7"] = "Öffentliche Gemeinschaft";
$_LANG["cnrxficontacttypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .GAY Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxgayacceptrequirements"] = "Anforderungen akzeptieren";
$_LANG["cnrxgayacceptrequirements0"] = $_LANG["cnr0"];
$_LANG["cnrxgayacceptrequirements1"] = $_LANG["cnr1"];
$_LANG["cnrxgayacceptrequirementsdescr"] = "Ich bestätige, dass die Domain NICHT zur Anstiftung zu Gewalt, Mobbing, Belästigung oder Hassrede verwendet wird und NICHT von anerkannten Hassgruppen genutzt wird. DotGay spendet 20% jeder neu registrierten Domain an ihre Partner, GLAAD und CenterLink.";

// ----------------------------------------------------------------------
// ------------------ .HK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxhkownerdocumenttype"] = "Registrant, Dokumenttyp";
$_LANG["cnrxhkownerdocumenttypehkid"] = "Privatperson: HK Ausweisnummer";
$_LANG["cnrxhkownerdocumenttypeothid"] = "Privatperson: Ausweisnummer eines anderen Landes";
$_LANG["cnrxhkownerdocumenttypepassno"] = "Privatperson: Reisepassnummer";
$_LANG["cnrxhkownerdocumenttypebirthcert"] = "Privatperson: Geburtsurkunde";
$_LANG["cnrxhkownerdocumenttypeothidv"] = "Privatperson: Sonstiges Dokument";
$_LANG["cnrxhkownerdocumenttypebr"] = "Organisation: Gewerbeanmeldung";
$_LANG["cnrxhkownerdocumenttypeci"] = "Organisation: Gründungsurkunde";
$_LANG["cnrxhkownerdocumenttypecrs"] = "Organisation: Schulregistrierungszertifikat";
$_LANG["cnrxhkownerdocumenttypehksarg"] = "Organisation: HK Regierungsabteilung";
$_LANG["cnrxhkownerdocumenttypehkordinance"] = "Organisation: HK Verordnung";
$_LANG["cnrxhkownerdocumenttypeothorg"] = "Organisation: Sonstiges Dokument";
$_LANG["cnrxhkownerdocumenttypedescr"] = "";
$_LANG["cnrxhkownerdocumentnumber"] = "Registrant, Dokumentnummer";
$_LANG["cnrxhkownerdocumentnumberdescr"] = "";
$_LANG["cnrxhkownerdocumentorigincountry"] = "Registrant, Ausstellungsland des Dokuments";
$_LANG["cnrxhkownerdocumentorigincountrydescr"] = "Das Land, in dem dieses Dokument ausgestellt wurde (bitte den 2-stelligen ISO-Ländercode angeben, z.B. DE oder US).";
$_LANG["cnrxhkownerotherdocumenttype"] = "Registrant, anderer Dokumenttyp";
$_LANG["cnrxhkownerotherdocumenttypedescr"] = "Erforderlich, wenn der zuvor ausgewählte Dokumenttyp entweder '" . $_LANG["cnrxhkownerdocumenttypeothidv"] . "' oder '" . $_LANG["cnrxhkownerdocumenttypeothorg"] . "' ist.";
$_LANG["cnrxhkdomaincategory"] = "Domainkategorie";
$_LANG["cnrxhkdomaincategoryi"] = "Privatperson";
$_LANG["cnrxhkdomaincategoryo"] = "Organisation";
$_LANG["cnrxhkdomaincategorydescr"] = "Rechtstyp aller Domainkontakte";
$_LANG["cnrxhkownerageover18"] = "Registrant, Alter über 18";
$_LANG["cnrxhkownerageover18no"] = $_LANG["cnr0"];
$_LANG["cnrxhkownerageover18yes"] = $_LANG["cnr1"];
$_LANG["cnrxhkownerageover18descr"] = "Ich bestätige, dass der Registrant mindestens 18 Jahre alt ist (nur für Privatpersonen erforderlich).";

// ----------------------------------------------------------------------
// ------------------ .IE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxiecontacttype"] = "Registrant, Kontakttyp";
$_LANG["cnrxiecontacttypecom"] = "Unternehmen";
$_LANG["cnrxiecontacttypecha"] = "Stiftung";
$_LANG["cnrxiecontacttypeoth"] = "Andere";
$_LANG["cnrxiecontacttypedescr"] = "";
$_LANG["cnrxielanguage"] = "Registrant, Sprache";
$_LANG["cnrxielanguageen"] = "Englisch";
$_LANG["cnrxielanguagefr"] = "Französisch";
$_LANG["cnrxielanguagedescr"] = "Sprache für die Kommunikation mit dem TLD-Anbieter (Standard = Englisch)";
$_LANG["cnrxiecronumber"] = "Registrant, CRO-Nummer";
$_LANG["cnrxiecronumberdescr"] = "Die Unternehmensregisternummer (CRO-Nummer)";
$_LANG["cnrxiesupportingnumber"] = "Registrant, Stiftungsnummer";
$_LANG["cnrxiesupportingnumberdescr"] = "Stiftungs- / Unterstützungsnummer";

// ----------------------------------------------------------------------
// ------------------ .IT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxitconsentforpublishing"] = $_LANG["cnrconsentforpublishing"];
$_LANG["cnrxitconsentforpublishing0"] = $_LANG["cnr0"];
$_LANG["cnrxitconsentforpublishing1"] = $_LANG["cnr1"];
$_LANG["cnrxitconsentforpublishingdescr"] = "Erlauben Sie die Veröffentlichung der persönlichen Kontaktdaten. Ablehnung nur möglich, wenn der Entitätstyp unten 1 ist.";
$_LANG["cnrxitentitytype"] = "Registrant, Entitätstyp";
$_LANG["cnrxitentitytype1"] = "[1] Italienische und ausländische natürliche Personen";
$_LANG["cnrxitentitytype2"] = "[2] Unternehmen/Einzelunternehmen";
$_LANG["cnrxitentitytype3"] = "[3] Freiberufler/Professionals";
$_LANG["cnrxitentitytype4"] = "[4] gemeinnützige Organisationen";
$_LANG["cnrxitentitytype5"] = "[5] öffentliche Organisationen";
$_LANG["cnrxitentitytype6"] = "[6] andere Subjekte";
$_LANG["cnrxitentitytype7"] = "[7] Ausländer, die 2-6 entsprechen";
$_LANG["cnrxitentitytypedescr"] = "Entitätstyp zur Identifizierung des Registranten.";
$_LANG["cnrxitpin"] = "Registrant, Steuernummer";
//$_LANG["cnrxitpindescr"] = "";
$_LANG["cnrxitnationality"] = "Registrant, Nationalität";
$_LANG["cnrxitnationalitydescr"] = "Die Nationalität des Registranten, angegeben durch den 2-stelligen ISO-Ländercode.";
//$_LANG["cnrxitsect3liability"] = "";
$_LANG["cnrxitsect3liabilitydescr"] = "";
$_LANG["cnrxitsect3liability0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect3liability1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect5personaldataforregistration"] = "";
$_LANG["cnrxitsect5personaldataforregistrationdescr"] = "";
$_LANG["cnrxitsect5personaldataforregistration0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect5personaldataforregistration1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect6personaldatafordiffusion"] = "";
$_LANG["cnrxitsect6personaldatafordiffusiondescr"] = "";
$_LANG["cnrxitsect6personaldatafordiffusion0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect6personaldatafordiffusion1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect7explicitacceptance"] = "";
$_LANG["cnrxitsect7explicitacceptancedescr"] = "";
$_LANG["cnrxitsect7explicitacceptance0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect7explicitacceptance1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .LV Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxlvownerregnr"] = "Registrant, Registrierungsnummer";
$_LANG["cnrxlvownerregnrdescr"] = "Die Registrierungsnummer des lettischen Bürgers, die für den Registrantenkontakt verwendet wird (z.B. Firmenregistrierungsnummer)";
$_LANG["cnrxlvadminregnr"] = "Admin, Registrierungsnummer";
$_LANG["cnrxlvadminregnrdescr"] = "Die Registrierungsnummer des lettischen Bürgers, die für den administrativen Kontakt verwendet wird (z.B. Firmenregistrierungsnummer)";
$_LANG["cnrxlvvatnr"] = "Registrant, USt-IdNr.";
$_LANG["cnrxlvvatnrdescr"] = "Die USt-IdNr. des Registrantenkontakts (nur für Unternehmen).";

// ----------------------------------------------------------------------
// ------------------ .LT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxltcompanynumber"] = "Registrant, Unternehmensnummer";
$_LANG["cnrxltcompanynumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .MY Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxmybusinessnumber"] = "Registrant, Unternehmensnummer";
$_LANG["cnrxmybusinessnumberdescr"] = "Die Unternehmensregisternummer des Registranten (nur für Unternehmen)";
$_LANG["cnrxmyorganizationtype"] = "Registrant, Organisationstyp";
$_LANG["cnrxmyorganizationtypedescr"] = "Der Unternehmenstyp des Registranten (nur für Unternehmen)";
$_LANG["cnrxmyperidentity"] = "Registrant, persönliche Identifikationsnummer";
$_LANG["cnrxmyperidentitydescr"] = "Die persönliche Identifikationsnummer des Registranten (nur für Privatpersonen)";
$_LANG["cnrxmyperdateofbirth"] = "Registrant, Geburtsdatum";
$_LANG["cnrxmyperdateofbirthdescr"] = "Das Geburtsdatum des Registranten (YYYY-MM-DD, nur für Privatpersonen)";
$_LANG["cnrxmyrace"] = "Registrant, ethnische Zugehörigkeit";
$_LANG["cnrxmyracemalay"] = "Malayisch";
$_LANG["cnrxmyracechinese"] = "Chinesisch";
$_LANG["cnrxmyraceindian"] = "Indisch";
$_LANG["cnrxmyraceothers"] = "Andere";
$_LANG["cnrxmyracedescr"] = "(nur für Privatpersonen)";

// ----------------------------------------------------------------------
// ------------------ .NO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnoorganizationnumber"] = "Registrant, Organisationsnummer";
$_LANG["cnrxnoorganizationnumberdescr"] = "Die norwegische Registrierungsnummer, die vom Zentralen Koordinierungsregister für juristische Personen ausgestellt wird.";
$_LANG["cnrxnopersonidentifier"] = "Norid Personen-ID";
$_LANG["cnrxnopersonidentifierdescr"] = "Erforderliche persönliche ID zur Registrierung einer privaten .PRIV.NO-Domain. Andernfalls leer lassen.";

// ----------------------------------------------------------------------
// ------------------ .NU Fields ----------------------------------------
// ----------------------------------------------------------------------
// see further .nu fields at the top of the file
$_LANG["cnrxnuiisidno"] = "Registrant, ID Nummer";
$_LANG["cnrxnuiisidnodescr"] = "Personalausweisnummer, Unternehmensidentifikationsnummer oder Registrierungsbezeichnung in einem staatlichen Register. Für Kontakte in Schweden ist eine gültige schwedische ID-Nummer erforderlich (z.B.: 123456-1234).";
$_LANG["cnrxnuiisvatno"] = "Registrant, USt-IdNr.";
$_LANG["cnrxnuiisvatnodescr"] = "Die USt-IdNr. des Registranten (nur für Unternehmen)";

// ----------------------------------------------------------------------
// ------------------ .NYC Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnycextcontact"] = "NY Externer Kontakt";
$_LANG["cnrxnycextcontactadmin"] = "Administrativer Kontakt";
$_LANG["cnrxnycextcontacttech"] = "Technischer Kontakt";
$_LANG["cnrxnycextcontactbilling"] = "Abrechnungskontakt";
$_LANG["cnrxnycextcontactowner"] = "Registrant";
$_LANG["cnrxnycextcontactdescr"] = "Der angegebene Kontakt muss eine gültige physische Adresse in der Stadt New York haben.";

// ----------------------------------------------------------------------
// ------------------ .PARIS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxafniccode"] = $_LANG["cnrxallocationtoken"];
$_LANG["cnrxafniccodedescr"] = $_LANG["cnrxallocationtokendescr"];

// ----------------------------------------------------------------------
// ------------------ .FR, .PM, .RE, .TF, .WF, .YT Fields ---------------
// ----------------------------------------------------------------------
// Organizations (Companies, Associations, etc.)
$_LANG["cnrxfrannounce"] = "Organisation/Unternehmen, Ankündigungsnr.<br/>(Journal Officiel)";
$_LANG["cnrxfrannouncedescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen (Vereine/Unternehmen). Für natürliche Personen leer lassen.<br/>",
    "Ankündigungsnummer im Journal Officiel (nur Ziffern).",
    "Wenn Sie Journal-Officiel-Angaben als Identifikator verwenden, geben Sie bitte alle zugehörigen JO-Felder an:",
    "Veröffentlichungsdatum, Ankündigungsnr., Seitennr. und Datum der Vereinigung."
]);
$_LANG["cnrxfrdatepublicationjo"] = "Organisation/Unternehmen, Veröffentlichungsdatum<br/>(Journal Officiel)";
$_LANG["cnrxfrdatepublicationjodescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen (Vereine/Unternehmen). Für natürliche Personen leer lassen.<br/>",
    "Veröffentlichungsdatum im Journal Officiel.",
    "Datumsformat YYYY-MM-DD.",
    "Wenn Sie Journal-Officiel-Angaben als Identifikator verwenden, geben Sie bitte alle zugehörigen JO-Felder an:",
    "Veröffentlichungsdatum, Ankündigungsnr., Seitennr. und Datum der Vereinigung."
]);
$_LANG["cnrxfrnumerodepageannouncejo"] = "Organisation/Unternehmen, Seitennr.<br/>(Journal Officiel)";
$_LANG["cnrxfrnumerodepageannouncejodescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen (Vereine/Unternehmen). Für natürliche Personen leer lassen.<br/>",
    "Seitennummer im Journal Officiel (nur Ziffern).",
    "Wenn Sie Journal-Officiel-Angaben als Identifikator verwenden, geben Sie bitte alle zugehörigen JO-Felder an:",
    "Veröffentlichungsdatum, Ankündigungsnr., Seitennr. und Datum der Vereinigung."
]);
$_LANG["cnrxfrwaldec"] = "Organisation/Unternehmen, Waldec-ID (Vereine)";
$_LANG["cnrxfrwaldecdescr"] = implode(" ", [
    "Nur für Vereine. Für natürliche Personen leer lassen.<br/>",
    "Waldec-Kennung, die mit einem Verein verknüpft ist (nur Ziffern).",
    "Wenn angegeben, reicht dies aus, um den Verein zu identifizieren.",
    "Hinweis: In der Regel reicht EIN Identifikator; wenn Sie Waldec angeben, können Sie andere Organisations-Identifikatoren leer lassen (SIREN/SIRET, USt-IdNr., DUNS, Marke, lokale ID, Journal-Officiel-Felder)."
]);
$_LANG["cnrxfrdateassociation"] = "Organisation/Unternehmen, Datum der Vereinigung";
$_LANG["cnrxfrdateassociationdescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen (Vereine/Unternehmen). Für natürliche Personen leer lassen.<br/>",
    "Datumsformat YYYY-MM-DD.",
    "Erforderlich, wenn Sie Journal-Officiel-Angaben angeben (Ankündigungsnr., Seitennr., Veröffentlichungsdatum)."
]);
$_LANG["cnrxfrduns"] = "Organisation/Unternehmen, DUNS-Nummer";
$_LANG["cnrxfrdunsdescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen. Für natürliche Personen leer lassen.<br/>",
    "Die DUNS-Nummer ist eine eindeutige neunstellige Kennung für Unternehmen. Kurz für Data Universal",
    "Numbering System; bezieht sich auf eine neue Kennung, die für eine Berechtigungsüberprüfung",
    "auf europäischer Ebene gesendet werden kann.",
    "Hinweis: In der Regel reicht EIN Identifikator (z.B. SIREN/SIRET, USt-IdNr., DUNS, Marke, lokale ID, Waldec oder Journal-Officiel-Felder)."
]);
$_LANG["cnrxfrlocal"] = "Organisation/Unternehmen, lokale ID";
$_LANG["cnrxfrlocaldescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen. Für natürliche Personen leer lassen.<br/>",
    "Eine lokale Kennung, die spezifisch für ein Land des Europäischen Wirtschaftsraums ist (z.B. Geschäftszertifikatsnummer).",
    "Hinweis: In der Regel reicht EIN Identifikator (z.B. SIREN/SIRET, USt-IdNr., DUNS, Marke, lokale ID, Waldec oder Journal-Officiel-Felder)."
]);
$_LANG["cnrxfrnoprezonecheck0"] = $_LANG["cnr0"];
$_LANG["cnrxfrnoprezonecheck1"] = $_LANG["cnr1"];
$_LANG["cnrxfrsirenorsiret"] = "Organisation/Unternehmen, SIREN/SIRET-Nummer";
$_LANG["cnrxfrsirenorsiretdescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen. Für natürliche Personen leer lassen.<br/>",
    "Geben Sie dies an, wenn Sie als Organisation/Unternehmen in Frankreich mit gültiger SIREN/SIRET registrieren.",
    "Hinweis: In der Regel reicht EIN Identifikator; wenn Sie SIREN/SIRET angeben, können Sie USt-IdNr., DUNS, Marke, lokale ID, Waldec und Journal-Officiel-Felder leer lassen.",
    "Der SIREN-Code ist die eindeutige Unternehmenskennnummer in Frankreich. Er wird vom",
    "Institut national de la statistique et des études économiques (INSEE) ausgegeben und hat 9 Ziffern.",
    "Die ersten 9 Ziffern sind die SIREN-Nummer und die folgenden 5 Ziffern sind die NIC-Nummer",
    "(Numéro Interne de Classement). Die SIRET-Nummer wird ausgegeben, sobald Sie Ihr",
    "Unternehmen bei der Handelskammer (RCS) für Handel, der Handwerkskammer für Handwerk und",
    "manuelle Arbeit oder bei der URSSAF für intellektuelle Dienstleistungen registriert haben.",
    "SIRET-Nummern bestehen aus 14 Ziffern. Die SIRET-Nummer liefert Informationen über den Standort des Unternehmens in Frankreich",
    "(für etablierte Unternehmen). Der im Registrantenkontakt angegebene Firmenname muss",
    "genau mit dem im SIREN/SIRET-Datenbank ( https://www.infogreffe.fr/ ) übereinstimmen."
]);
$_LANG["cnrxfrtrademark"] = "Organisation/Unternehmen, Marken-Nr.";
$_LANG["cnrxfrtrademarkdescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen. Für natürliche Personen leer lassen.<br/>",
    "Markennummer (wenn die Registrierung auf Markenrechten basiert).",
    "Hinweis: In der Regel reicht EIN Identifikator; wenn Sie eine Markennummer angeben, können Sie SIREN/SIRET, USt-IdNr., DUNS, lokale ID, Waldec und Journal-Officiel-Felder leer lassen."
]);
$_LANG["cnrxfrvatid"] = "Organisation/Unternehmen, USt-IdNr.";
$_LANG["cnrxfrvatiddescr"] = implode(" ", [
    "Nur für Organisationen/Unternehmen. Für natürliche Personen leer lassen.<br/>",
    "USt-IdNr. (falls verfügbar).",
    "Hinweis: In der Regel reicht EIN Identifikator; wenn Sie die USt-IdNr. angeben, können Sie SIREN/SIRET, DUNS, Marke, lokale ID, Waldec und Journal-Officiel-Felder leer lassen."
]);

// Individual
$_LANG["cnrxfrbirthpc"] = "Registrant, Postleitzahl (Geburtsort)";
$_LANG["cnrxfrbirthpcdescr"] = implode(" ", [
    "Nur für natürliche Personen. Für Organisationen/Unternehmen leer lassen.<br/>",
    "Nur erforderlich für Personen, die in Frankreich oder französischen Überseegebieten geboren sind (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Bitte geben Sie die Postleitzahl des Geburtsortes an (oder zumindest den Departementcode)."
]);
$_LANG["cnrxfrbirthcity"] = "Registrant, Geburtsstadt";
$_LANG["cnrxfrbirthcitydescr"] = implode(" ", [
    "Nur für natürliche Personen. Für Organisationen/Unternehmen leer lassen.<br/>",
    "Nur erforderlich für Personen, die in Frankreich oder französischen Überseegebieten geboren sind (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Bitte geben Sie den Namen der Stadt an."
]);
$_LANG["cnrxfrbirthdate"] = "Registrant, Geburtsdatum";
$_LANG["cnrxfrbirthdatedescr"] = "Nur für natürliche Personen. Geburtsdatum im Format YYYY-MM-DD. Für Organisationen/Unternehmen leer lassen.";
$_LANG["cnrxfrbirthplace"] = "Registrant, Geburtsland";
$_LANG["cnrxfrbirthplacedescr"] = "Nur für natürliche Personen. Ländercode des Geburtsortes (z.B. FR, DE). Für Organisationen/Unternehmen leer lassen.";
$_LANG["cnrxfrrestrictpub"] = "Registrant, Veröffentlichung einschränken (WHOIS)";
$_LANG["cnrxfrrestrictpub0"] = $_LANG["cnr0"];
$_LANG["cnrxfrrestrictpub1"] = $_LANG["cnr1"];
$_LANG["cnrxfrrestrictpubdescr"] = "Nur für natürliche Personen. Wählen Sie 'Ja', um die Veröffentlichung einzuschränken und persönliche Daten im WHOIS zu verbergen.";
$_LANG["cnrxfrnoprezonecheck"] = "DNS-Vorprüfung unterdrücken";
$_LANG["cnrxfrnoprezonecheckdescr"] = "Bestimmt, ob das System eine DNS-Vorprüfung durchführen soll, bevor der Befehl an die Registrierungsstelle gesendet wird.";

// ----------------------------------------------------------------------
// ------------------ .PT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxpttechidentification"] = "Technischer Kontakt, USt-IdNr.";
$_LANG["cnrxpttechidentificationdescr"] = "Die Steueridentifikationsnummer des technischen Kontakts";
$_LANG["cnrxptowneridentification"] = "Registrant, USt-IdNr.";
$_LANG["cnrxptowneridentificationdescr"] = "Die Steueridentifikationsnummer des Registranten";
$_LANG["cnrxpttechmobile"] = "Technischer Kontakt, Mobiltelefon";
$_LANG["cnrxpttechmobiledescr"] = "Die Mobiltelefonnummer des technischen Kontakts";
$_LANG["cnrxptownermobile"] = "Registrant, Mobiltelefon";
$_LANG["cnrxptownermobiledescr"] = "Die Mobiltelefonnummer des Registranten";

// ----------------------------------------------------------------------
// ------------------ .RO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrocompanynumber"] = "Registrant, Unternehmensnummer";
$_LANG["cnrxrocompanynumberdescr"] = "(nur für Unternehmen erforderlich)";
$_LANG["cnrxroidcardorpassportnumber"] = "Registrant, Personalausweis- oder Reisepassnummer";
$_LANG["cnrxroidcardorpassportnumberdescr"] = "(nur für Privatpersonen erforderlich)";
$_LANG["cnrxrovatnumber"] = "Registrant, USt-IdNr.";
$_LANG["cnrxrovatnumberdescr"] = "(nur für Unternehmen erforderlich)";

// ----------------------------------------------------------------------
// ------------------ .RU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrubirthdate"] = "Registrant, Geburtsdatum";
$_LANG["cnrxrubirthdatedescr"] = "Das Geburtsdatum des Registranten (TT.MM.JJJJ)<br/>(nur für Privatpersonen erforderlich)";
$_LANG["cnrxrufirstname"] = "Registrant, Vorname";
$_LANG["cnrxrufirstnamedescr"] = "Der Vorname des Registranten auf Russisch. Muss mit russischen und lateinischen Buchstaben ausgefüllt werden, keine Punkte.<br/>(nur für Privatpersonen erforderlich)";
$_LANG["cnrxrumiddlename"] = "Registrant, Zweiter Vorname";
$_LANG["cnrxrumiddlenamedescr"] = "Der zweite Vorname des Registranten auf Russisch. Muss mit russischen und lateinischen Buchstaben ausgefüllt werden, keine Punkte.<br/>(nur für Privatpersonen erforderlich)";
$_LANG["cnrxrulastname"] = "Registrant, Nachname";
$_LANG["cnrxrulastnamedescr"] = "Der Nachname des Registranten auf Russisch. Muss mit russischen und lateinischen Buchstaben ausgefüllt werden, keine Punkte.<br/>(nur für Privatpersonen erforderlich)";
$_LANG["cnrxruorganization"] = "Registrant, Organisationsname";
$_LANG["cnrxruorganizationdescr"] = "Der Name der Organisation des Registranten auf Russisch. Dieses Feld kann russische und lateinische Buchstaben, Zahlen, Satzzeichen und Leerzeichen enthalten.<br/>(nur für Organisationen, die in der Russischen Föderation eingetragen sind, erforderlich)";
$_LANG["cnrxrucode"] = "Registrant, Steuernummer";
$_LANG["cnrxrucodedescr"] = "Die Steuernummer (TIN) des Registranten. Dieses Feld muss eine zehnstellige Zahl enthalten (die letzte Ziffer ist eine Prüfziffer).<br/>(nur für Organisationen, die in der Russischen Föderation eingetragen sind, erforderlich)";
$_LANG["cnrxrukpp"] = "Registrant, Grundcode";
$_LANG["cnrxrukppdescr"] = "Der Grundcode (KPP) des Registranten. Dieses Feld muss eine neunstellige Zahl enthalten.<br/>(nur für Organisationen, die in der Russischen Föderation eingetragen sind, erforderlich)";
$_LANG["cnrxrupassportdata"] = "Registrant, Passdaten";
$_LANG["cnrxrupassportdatadescr"] = "Die Passdaten des Registranten. Dieses Feld wird auf Russisch ausgefüllt und kann russische und lateinische Buchstaben, Zahlen, Satzzeichen und Leerzeichen enthalten. Format: Dokumentnummer, Ausgestellt von, Ausstellungsdatum<br/>(nur für Privatpersonen erforderlich)";

// ----------------------------------------------------------------------
// ------------------ .SE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnicseidnumber"] = "Registrant, ID Nummer";
$_LANG["cnrxnicseidnumberdescr"] = "Persönliche oder organisatorische Nummer.";
$_LANG["cnrxnicsevatid"] = "Registrant, USt-IdNr.";
$_LANG["cnrxnicsevatiddescr"] = "";
$_LANG["cnrxsediscloseemail"] = "Registrant, E-Mail-Adresse offenlegen";
$_LANG["cnrxsediscloseemaildescr"] = "Erlauben Sie die Offenlegung der E-Mail-Adresse des Registranten in der öffentlichen WHOIS-Datenbank.";
$_LANG["cnrxsedisclosefax"] = "Registrant, Faxnummer offenlegen";
$_LANG["cnrxsedisclosefaxdescr"] = "Erlauben Sie die Offenlegung der Faxnummer des Registranten in der öffentlichen WHOIS-Datenbank.";
$_LANG["cnrxsedisclosevoice"] = "Registrant, Telefonnummer offenlegen";
$_LANG["cnrxsedisclosevoicedescr"] = "Erlauben Sie die Offenlegung der Telefonnummer des Registranten in der öffentlichen WHOIS-Datenbank.";
foreach (["email", "fax", "voice"] as $field) {
    $_LANG["cnrxsedisclose$field" . "0"] = $_LANG["cnr0"];
    $_LANG["cnrxsedisclose$field" . "1"] = $_LANG["cnr1"];
}

// ----------------------------------------------------------------------
// ------------------ .SG Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxsgrcbid"] = "Registrant, RCB ID";
$_LANG["cnrxsgrcbiddescr"] = "Die eindeutige Unternehmensnummer (UEN) oder die Registrierungsnummer des Unternehmens (RCB) des Registranten. Für <u>Unternehmen</u> mit Sitz in Singapur muss die entsprechende Unternehmensregistrierungsnummer angegeben werden ODER die Kontaktidentitätskarte für eine lokale Präsenz in Singapur (Format: S1234567D).";
$_LANG["cnrxsgadminsingpassid"] = "Admin, SingPass ID";
$_LANG["cnrxsgadminsingpassiddescr"] = "Die Kontaktidentitätskarte (SingPass ID) des administrativen Kontakts<br/>(nur für singapurische <u>Privatpersonen</u>, Format: S1234567D)";

// ----------------------------------------------------------------------
// ------------------ .SK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxskcontactlegalform"] = "Registrant, Rechtsform";
$_LANG["cnrxskcontactlegalformdescr"] = "";
// $_LANG["cnrxskcontactlegalformcorp"] = "";
// $_LANG["cnrxskcontactlegalformpers"] = "";
$_LANG["cnrxskcontactidentnumber"] = "Registrant, Handelsregisternummer";
$_LANG["cnrxskcontactidentnumberdescr"] = "Pflichtfeld für Unternehmen/Organisationen";

// ----------------------------------------------------------------------
// ------------------ .SWISS Fields -------------------------------------
// ----------------------------------------------------------------------
// see other .swiss fields at top of the file
$_LANG["cnrxswissuid"] = "Registrant, UID oder UPI";
$_LANG["cnrxswissuiddescr"] = implode("", [
    "Die ...<ul>",
    "<li>UID (Unternehmens-Identifikationsnummer, Format: \"CHE-ddd.ddd.ddd\") für Organisationen oder</li>",
    "<li>UPI (Universelle Personen-Identifikationsnummer, Format: \"756.dddd.dddd.dd\") für natürliche Personen</li>",
    "</ul>... des Registranten (d = Ziffer).<br/>",
    "Bitte beachten: Der Name der Person und die UPI werden NICHT im Whois/RDAP veröffentlicht, im Gegensatz zum Namen der Organisation und der UID, die sichtbar sind."
]);
$_LANG["cnrxswissownertype"] = "Registrant, Typ";
$_LANG["cnrxswissownertypep"] = "Natürliche Person";
$_LANG["cnrxswissownertypeo"] = "Organisation / Juristische Person";
$_LANG["cnrxswissownertypedescr"] = "Der Identitätstyp des Registranten.";

// ----------------------------------------------------------------------
// ------------------ .TRAVEL Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxtravelindustry"] = "Reisebranche";
$_LANG["cnrxtravelindustryn"] = $_LANG["cnr0"];
$_LANG["cnrxtravelindustryy"] = $_LANG["cnr1"];
$_LANG["cnrxtravelindustrydescr"] = "Ich bestätige, dass der Registrant Mitglied der Reisebranche ist und eine gültige Mitgliedsnummer besitzt.";

// ----------------------------------------------------------------------
// ------------------ .UK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxukownercorporatetype"] = "Registrant, Unternehmensart";
$_LANG["cnrxukownercorporatetypedescr"] = "";
$_LANG["cnrxukownercorporatetypeother"] = "Andere";
$_LANG["cnrxukownercorporatetypefother"] = "Andere (Nicht-UK)";
$_LANG["cnrxukownercorporatetypeind"] = "Einzelperson";
$_LANG["cnrxukownercorporatetypefind"] = "Einzelperson (Nicht-UK)";
$_LANG["cnrxukownercorporatetypefcorp"] = "Unternehmen (Nicht-UK)";
// $_LANG["cnrxukownercorporatetypeltd"] = "LTD";
// $_LANG["cnrxukownercorporatetypeplc"] = "PLC";
// $_LANG["cnrxukownercorporatetypellp"] = "LLP";
// $_LANG["cnrxukownercorporatetypeip"] = "IP";
$_LANG["cnrxukownercorporatetypecrc"] = "Unternehmen mit königlicher Satzung";
$_LANG["cnrxukownercorporatetypegov"] = "Regierungsbehörde";
$_LANG["cnrxukownercorporatetypeptnr"] = "Britische Partnerschaft";
$_LANG["cnrxukownercorporatetyperchar"] = "Eingetragene Wohltätigkeitsorganisation";
$_LANG["cnrxukownercorporatetypesch"] = "Schule";
$_LANG["cnrxukownercorporatetypestat"] = "Körperschaft des öffentlichen Rechts";
$_LANG["cnrxukownercorporatetypestra"] = "Einzelunternehmer";
$_LANG["cnrxukownercorporatenumber"] = "Registrant, Handelsregisternummer";
$_LANG["cnrxukownercorporatenumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .US Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxusnexusapppurpose"] = "US Nexus, Verwendungszweck";
$_LANG["cnrxusnexusapppurposep1"] = "Geschäftliche Nutzung für Gewinnzwecke";
$_LANG["cnrxusnexusapppurposep2"] = "Gemeinnützige Organisation, Verein, religiöse Organisation, etc.";
$_LANG["cnrxusnexusapppurposep3"] = "Persönliche Nutzung";
$_LANG["cnrxusnexusapppurposep4"] = "Bildungszwecke";
$_LANG["cnrxusnexusapppurposep5"] = "Regierungszwecke";
$_LANG["cnrxusnexusapppurposedescr"] = "";
$_LANG["cnrxusnexuscategory"] = "US Nexus, Kategorie";
$_LANG["cnrxusnexuscategoryc11"] = "[C11] US-Bürger";
$_LANG["cnrxusnexuscategoryc12"] = "[C12] US-Daueraufenthaltsberechtigter";
$_LANG["cnrxusnexuscategoryc21"] = "[C21] US-Organisation";
$_LANG["cnrxusnexuscategoryc31"] = "[C31] Ausländische Entität mit US-Aktivitäten";
$_LANG["cnrxusnexuscategoryc32"] = "[C32] Ausländische Entität mit US-Büro";
$_LANG["cnrxusnexuscategorydescr"] = "Kategorisierung der Entität, die den Antrag stellt.<br/>Hinweis: Besitzungen und Territorien der USA sind ebenfalls eingeschlossen.";
$_LANG["cnrxusnexusvalidator"] = "US Nexus, Land";
$_LANG["cnrxusnexusvalidatordescr"] = "Geben Sie den zweibuchstabigen Ländercode des Registranten an (wenn die Nexus-Kategorie entweder C31 oder C32 ist)";

// ----------------------------------------------------------------------
// ------------------ .XXX Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxxxxcommunityid"] = "Community-Mitglieds-ID";
$_LANG["cnrxxxxcommunityiddescr"] = ".XXX Gesponserte Community-Mitglieds-ID";
$_LANG["cnrxxxxdefensive"] = "Defensive Registrierung<br/>(Nicht-auflösende Domain)";
$_LANG["cnrxxxxdefensive0"] = $_LANG["cnr0"];
$_LANG["cnrxxxxdefensive1"] = $_LANG["cnr1"];
$_LANG["cnrxxxxdefensivedescr"] = implode("", [
    "Ich bestätige, dass die Domain eine defensive Registrierung ist. ",
    "Defensive Registrierung bezieht sich auf die Registrierung von Domainnamen, ",
    "oft über mehrere TLDs hinweg und in verschiedenen grammatikalischen Formaten, ",
    "mit dem primären Zweck, geistiges Eigentum oder Marken vor Missbrauch zu schützen, ",
    "wie z.B. Cybersquatting. Es wird definiert als eine Registrierung, die nicht einzigartig ist, nicht auflöst, ",
    "den Verkehr zurück zu einer Kernregistrierung umleitet oder keinen einzigartigen Inhalt enthält.<br/>",
    "Hinweis: Wenn nicht ausgewählt, wird die Domain als defensive Registrierung betrachtet."
]);

// #########################################################################
// #########################################################################
// # Add reusable translations for ALL PROVIDERS                           #
// #########################################################################
// #########################################################################

/// ----------------------------------------------------------------------
// ---------------- EMAIL VERIFICATION ----------------------------------
// ----------------------------------------------------------------------
// $_LANG["cnicemailverification"] = "E-Mail-Verifizierung";
// $_LANG["emailverificationtitle"] = "Verifizieren Sie Ihre E-Mail";
// $_LANG["emailverificationinfo"] = "Für die folgenden Kontaktinformationen ist eine Verifizierung erforderlich";
// $_LANG["emailverificationconsequences"] = "Wenn Sie Ihre E-Mail nicht verifizieren, kann dies zur Aussetzung Ihrer Domain führen.";
// $_LANG["emailverificationresendemailinfo"] = "Wenn Sie die E-Mail nicht erhalten haben, klicken Sie bitte auf die Schaltfläche unten, um die Verifizierungs-E-Mail erneut zu senden.";
// $_LANG["verified"] = "Verifiziert";
// $_LANG["emailverificationpending"] = "Ausstehend";

// ----------------------------------------------------------------------
// ----------------------- DNSSEC MANAGEMENT ----------------------------
// ----------------------------------------------------------------------
$_LANG["cnicdnssecmanagement"] = "DNSSEC Verwaltung";

// Statusmeldungen
$_LANG["dnssecautomaticupdatesuccessmsg"] = "DNSSEC wurde für Ihre Domain <span style=\"color:green;font-weight:bold;\">aktiviert</span>.<br> Die DNSSEC-Datensätze wurden aus Ihrer DNS-Zone importiert und bei Ihrem Domain-Registrar aktualisiert.<br><br><span style=\"color:#007bff;\">Zu Ihrer Sicherheit hilft DNSSEC, Ihre Domain vor bestimmten Arten von Angriffen zu schützen, indem DNS-Antworten validiert werden.</span>";
$_LANG["dnssecautoenable"] = "DNSSEC aktivieren und DNSSEC-Einträge automatisch aus der DNS-Zone importieren";
$_LANG["dnssecsyncrecords"] = "DNSSEC-Einträge aus der DNS-Zone synchronisieren";

// Verwaltung von Einträgen
$_LANG["dnssecaddnewdskey"] = "Neue DS-Schlüssel hinzufügen";
$_LANG["dnssecaddnewkeyrecord"] = "Neuen Schlüssel-Eintrag hinzufügen";

// Modal-Dialog
$_LANG["dnssecconfirmdisable"] = "Sind Sie sicher, dass Sie DNSSEC für diese Domain deaktivieren möchten? Diese Aktion kann die Domainauflösung beeinflussen.";
$_LANG["dnssecmodaltitle"] = "DNSSEC deaktivieren";
$_LANG["dnssecmodalcancel"] = "Abbrechen";
$_LANG["dnssecmodaldisable"] = "DNSSEC deaktivieren";
