<?php

// #########################################################################
// #########################################################################
// # Add translations for CNR registrar module additional domain fields    #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ------------------ .DK Checkout Page ---------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrdkcheckoutheading"] = "Algemene voorwaarden voor .dk domeinnamen";
$_LANG["cnrdkcheckoutintro"] = "Om een .dk domeinnaam te registreren, dient u een overeenkomst aan te gaan met Punktum.dk A/S. Punktum dk is de registry voor alle .dk domeinnamen.";
$_LANG["cnrdkcheckoutdomains"] = "Domeinnamen:";
$_LANG["cnrdkcheckoutregistrant"] = "Domeinhouder:";
$_LANG["cnrdkcheckoutregistrantaddress"] = "Zie hierboven";
$_LANG["cnrdkcheckoutadmin"] = "Domeinbeheerder:";
$_LANG["cnrdkcheckoutadminaddress"] = "Punktum dk A/S<br/>Ørestads Boulevard 108, 11e verdieping<br/>DK-2300 Kopenhagen S";
$_LANG["cnrdkcheckouttac"] = implode("<br/><br/>", [
    "Ik ga ermee akkoord een overeenkomst aan te gaan voor het recht op gebruik van de opgegeven .dk domeinnaam volgens de geldende voorwaarden. Dit betekent onder andere dat ik ervoor zorg dat mijn contactgegevens als houder altijd correct zijn. Ik zal de identiteitscontrole van Punktum dk A/S uitvoeren indien daarom wordt gevraagd.",
    "Mijn recht op gebruik van de opgegeven .dk domeinnaam kan worden overgedragen, opgeschort, verwijderd of geblokkeerd volgens de voorwaarden in de gebruiksvoorwaarden van Punktum dk A/S.",
    "Conform sectie 18 (2) (13) van de Deense consumentenovereenkomstenwet doe ik afstand van het recht om de overeenkomst betreffende het gebruiksrecht van de opgegeven .dk domeinnaam te herroepen.",
    "Ik geef toestemming dat Punktum dk A/S, als domeinbeheerder, mijn persoonsgegevens verwerkt volgens het privacybeleid.",
    "Ik ga ermee akkoord dat ik aan deze provider de vergoeding voor de eerste registratieperiode van de opgegeven .dk domeinnaam betaal en dat de betaling voor volgende registratieperiodes afhankelijk is van mijn keuze voor het beheerregime, conform sectie 2.1 van de algemene voorwaarden van Punktum dk A/S."
]);
$_LANG["cnrdkcheckouttacurl"] = "https://www.punktum.dk/en/articles/terms-and-conditions-for-the-right-of-use-to-a-dk-domain-name";
$_LANG["cnrdkcheckouttacurltext"] = "Algemene voorwaarden voor het gebruiksrecht van een .dk domeinnaam";
$_LANG["cnrdkcheckoutpolicyurl"] = "https://www.punktum.dk/en/articles/privacy-policy";
$_LANG["cnrdkcheckoutpolicyurltext"] = "Privacybeleid";
$_LANG["cnrdkcheckoutabouturl"] = "https://www.punktum.dk/en/about-us";
$_LANG["cnrdkcheckoutabouturltext"] = "Over Punktum dk A/S";
$_LANG["cnrdkcheckouttacagree"] = "Ja, ik accepteer de gebruikersovereenkomst met Punktum dk A/S.";

// ----------------------------------------------------------------------
// ------------------ Common CNR Translations ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrchoose"] = "Selecteer alstublieft";
$_LANG["cnroptional"] = "optioneel";
$_LANG["cnr1"] = "Ja";
$_LANG["cnr0"] = "Nee";
$_LANG["cnrconsentforpublishing"] = "Domeinhouder, toestemming voor publicatie";
// .abogado, .aero, .attorney, .bank, .broker, .dentist, .forex, .insurance, .lotto, .law, .lawyer, .markets, .trading
$_LANG["cnrxallocationtoken"] = "Registry bestelsleutel";
$_LANG["cnrxallocationtokendescr"] = "Alleen vereist voor premium domeinen. Uitgegeven door de TLD-provider. Neem contact op indien u hulp nodig heeft.";
// .app, .page, .dev, .new, .day, .channel, .boo, .foo, .zip, .mov, .nexus, .dad, .phd, .prof, .esq, .rsvp, .meme, .ing, .new
$_LANG["cnrxacceptsslrequirement"] = "SSL vereisten";
$_LANG["cnrxacceptsslrequirementdescr"] = "Ik bevestig dat ik de vereisten voor HTTPS / een SSL-certificaat begrijp en accepteer. Deze TLD is een beveiligde domeinextensie, wat betekent dat HTTPS verplicht is voor alle websites. U kunt uw domeinnaam nu registreren, maar om deze correct te laten functioneren in browsers, moet u HTTPS configureren op basis van een SSL-certificaat.";
$_LANG["cnrxacceptsslrequirement0"] = $_LANG["cnr0"];
$_LANG["cnrxacceptsslrequirement1"] = $_LANG["cnr1"];
// .attorney, .dentist, .lawyer
$_LANG["cnrxunitedtldregulatorydata"] = "Regulerende instantie informatie";
$_LANG["cnrxunitedtldregulatorydatadescr"] = "Informatie over de goedkeurende instantie/toezichthouder/regulerende autoriteit";
// .barcelona, .cat, .madrid, .scot, .sport, .swiss
$_LANG["cnrxintendeduse"] = "Beoogd gebruik";
$_LANG["cnrxintendedusedescr"] = implode("<br/>", [
    "Toelichting op het beoogde gebruik van de domeinnaam. Indien van toepassing, graag een expliciete verwijzing naar het geclaimde recht van de aanvrager op de naam (indien niet de bedrijfsnaam van de aanvrager).",
    "Bijvoorbeeld, als de domeinnaam overeenkomt met een merknaam, dient het merkregistratienummer te worden opgegeven (max. 256 tekens)."
]);
// .mk
$_LANG["cnrxcompanyvatid"] = "Domeinhouder, btw-nummer";
// $_LANG["cnrxcompanyvatiddescr"] = "";
// .nu, .se
$_LANG["cnrxrequestauthcode"] = "Nieuwe EPP-code aanvragen";
$_LANG["cnrxrequestauthcode0"] = $_LANG["cnr0"];
$_LANG["cnrxrequestauthcode1"] = $_LANG["cnr1"];
$_LANG["cnrxrequestauthcodedescr"] = "Indien u de domein wilt verhuizen naar een andere registrar, heeft u de Auth-code nodig. Deze wordt verstuurd naar het e-mailadres van de domeinhouder.";

// NOTE: The following translations are labeled as boilerplate and should
// be used as a template for other languages. English texts are returned
// by default from the CNR Backend System. If you want to override these
// default texts, please consider a language override file in WHMCS using
// the below translation keys.
// We added some translations to override the API defaults which sometimes
// suck.

// ----------------------------------------------------------------------
// ------------------ DOMAIN DETAILS (and sub pages) --------------------
// ----------------------------------------------------------------------
$_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] = (
    "<small>We hebben enkele problemen gevonden met uw domeincontactinformatie die uw aandacht vereisen. Om dit op te lossen:<br/><br/><ol>" .
    "<li>Schakel over naar het klantportaal (aanvullende velden worden daar ook weergegeven, indien van toepassing)</li>" .
    "<li>Ga naar de <b>Contactinformatie</b>-pagina van dit domein</li>" .
    "<li>Breng de benodigde correcties aan</li>" .
    "<li>Voltooi direct daarna het verificatieproces indien van toepassing</li></ol></small>"
 );
$_LANG["cnrdomaincontactvalidationerrorsummary"] = (
    "<small>We hebben enkele problemen gevonden met uw domeincontactinformatie die uw aandacht vereisen. Om dit op te lossen:<br/><br/><ol>" .
    "<li>Ga naar de <b><a href=\"clientarea.php?action=domaincontacts&domainid=:domainid\">Contactinformatie</a></b>-pagina en controleer uw gegevens</li>" .
    "<li>Breng de benodigde correcties aan</li>" .
    "<li>Voltooi direct daarna het verificatieproces indien van toepassing</li></ol></small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspensionadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Voltooi deze stappen vóór <b>:suspensiondate</b> om te voorkomen dat uw domein wordt opgeschort.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspension"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Voltooi deze stappen vóór <b>:suspensiondate</b> om te voorkomen dat uw domein wordt opgeschort.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspendedadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Uw domein is opgeschort. Voltooi deze stappen om de opschorting van uw domein op te heffen.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspended"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Uw domein is opgeschort. Voltooi deze stappen om de opschorting van uw domein op te heffen.</small>"
);

// ----------------------------------------------------------------------
// ------------------ .AERO Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaeroensauthid"] = "AERO Lidmaatschaps-ID";
$_LANG["cnrxaeroensauthiddescr"] = "De .AERO lidmaatschaps-ID is vereist om een domeinnaam in de luchtvaartsector te registreren. U kunt deze <a style=\"text-decoration:underline\" href=\"https://information.aero/node/add/request-aero-id\" target=\"_blank\">hier</a> aanvragen.";
$_LANG["cnrxaeroensauthkey"] = "Lidmaatschapswachtwoord";
$_LANG["cnrxaeroensauthkeydescr"] = "Het bijbehorende wachtwoord/authcode dat samen met de .AERO lidmaatschaps-ID via bovenstaande website wordt verstrekt.";

// ----------------------------------------------------------------------
// ------------------ .AU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaudomainrelation"] = "Relatie";
$_LANG["cnrxaudomainrelation1"] = "De second-level domeinnaam is een exacte overeenkomst, acroniem of afkorting van de bedrijfs- of handelsnaam, organisatienaam, verenigingsnaam of merknaam.";
$_LANG["cnrxaudomainrelation2"] = "De second-level domeinnaam heeft een nauwe en substantiële band met de organisatie of de activiteiten die door de organisatie worden uitgevoerd.";
$_LANG["cnrxaudomainrelationdescr"] = "Dit geeft de relatie aan tussen het type recht (bijv. handelsnaam) en de domeinnaam.";
$_LANG["cnrxaudomainrelationtype"] = "Relatietype";
$_LANG["cnrxaudomainrelationtypecompany"] = "Bedrijf";
$_LANG["cnrxaudomainrelationtyperegisteredbusiness"] = "Geregistreerd bedrijf";
$_LANG["cnrxaudomainrelationtypesoletrader"] = "Eenmanszaak";
$_LANG["cnrxaudomainrelationtypepartnership"] = "Vennootschap onder firma";
$_LANG["cnrxaudomainrelationtypetrademarkowner"] = "Merkhouder";
$_LANG["cnrxaudomainrelationtypependingtmowner"] = "Merkregistratie in aanvraag";
$_LANG["cnrxaudomainrelationtypecitizenresident"] = "Burger / Inwoner"; // .id.au only
$_LANG["cnrxaudomainrelationtypeincorporatedassociation"] = "Ingeschreven vereniging";
$_LANG["cnrxaudomainrelationtypeclub"] = "Club";
$_LANG["cnrxaudomainrelationtypenonprofitorganisation"] = "Non-profitorganisatie";
$_LANG["cnrxaudomainrelationtypecharity"] = "Goede doelen organisatie";
$_LANG["cnrxaudomainrelationtypetradeunion"] = "Vakbond";
$_LANG["cnrxaudomainrelationtypeindustrybody"] = "Brancheorganisatie";
$_LANG["cnrxaudomainrelationtypecommercialstatutorybody"] = "Commerciële publiekrechtelijke instelling";
$_LANG["cnrxaudomainrelationtypepoliticalparty"] = "Politieke partij";
$_LANG["cnrxaudomainrelationtypeother"] = "Overig";
$_LANG["cnrxaudomainrelationtypereligiouschurchgroup"] = "Religieuze / Kerkelijke groep";
$_LANG["cnrxaudomainrelationtypehighereducationinstitution"] = "Hoger onderwijsinstelling";
$_LANG["cnrxaudomainrelationtyperesearchorganisation"] = "Onderzoeksinstelling";
$_LANG["cnrxaudomainrelationtypegovernmentschool"] = "Openbare school";
$_LANG["cnrxaudomainrelationtypechildcarecentre"] = "Kinderopvangcentrum";
$_LANG["cnrxaudomainrelationtypepreschool"] = "Peuterspeelzaal";
$_LANG["cnrxaudomainrelationtypenationalbody"] = "Nationale organisatie";
$_LANG["cnrxaudomainrelationtypetrainingorganisation"] = "Opleidingsinstituut";
$_LANG["cnrxaudomainrelationtypenongovernmentschool"] = "Particuliere school";
$_LANG["cnrxaudomainrelationtypeunincorporatedassociation"] = "Niet-ingeschreven vereniging";
$_LANG["cnrxaudomainrelationtypeindustryorganisation"] = "Brancheorganisatie";
$_LANG["cnrxaudomainrelationtyperegistrablebody"] = "Registratieplichtige entiteit";
$_LANG["cnrxaudomainrelationtypeindigenouscorporation"] = "Inheemse corporatie";
$_LANG["cnrxaudomainrelationtyperegisteredorganisation"] = "Geregistreerde organisatie";
$_LANG["cnrxaudomainrelationtypetrust"] = "Trust";
$_LANG["cnrxaudomainrelationtypeeducationalinstitution"] = "Onderwijsinstelling";
$_LANG["cnrxaudomainrelationtypecommonwealthentity"] = "Commonwealth-entiteit";
$_LANG["cnrxaudomainrelationtypestatutorybody"] = "Publiekrechtelijke instelling";
$_LANG["cnrxaudomainrelationtypetradingcooperative"] = "Handelscoöperatie";
$_LANG["cnrxaudomainrelationtypecompanylimitedbyguarantee"] = "Vennootschap met beperkte aansprakelijkheid";
$_LANG["cnrxaudomainrelationtypenondistributingcooperative"] = "Niet-uitkerende coöperatie";
$_LANG["cnrxaudomainrelationtypenontradingcooperative"] = "Niet-handelscoöperatie";
$_LANG["cnrxaudomainrelationtypecharitabletrust"] = "Goede doelen trust";
$_LANG["cnrxaudomainrelationtypepublicprivateancillaryfund"] = "Publiek / Privaat ondersteuningsfonds";
$_LANG["cnrxaudomainrelationtypepeakstateterritorybody"] = "Koepelorganisatie staat/territorium";
$_LANG["cnrxaudomainrelationtypenotforprofitcommunitygroup"] = "Non-profit gemeenschapsgroep";
$_LANG["cnrxaudomainrelationtypeeducationandcareserviceschildcare"] = "Onderwijs- en zorgdiensten (kinderopvang)";
$_LANG["cnrxaudomainrelationtypegovernmentbody"] = "Overheidsinstantie";
$_LANG["cnrxaudomainrelationtypeproviderofnonaccreditedtraining"] = "Aanbieder van niet-geaccrediteerde trainingen";
$_LANG["cnrxaudomainrelationtypedescr"] = "Geef aan wat de registrant het recht geeft om de domeinnaam te registreren";
$_LANG["cnrxauownerorganization"] = "Domeinhouder, organisatie";
$_LANG["cnrxauownerorganizationdescr"] = "De naam van de organisatie (domeinhouder)";
$_LANG["cnrxauidwarranty"] = "Domeinhouder,<br>is AU-burger of inwoner";
$_LANG["cnrxauidwarranty0"] = $_LANG["cnr0"];
$_LANG["cnrxauidwarranty1"] = $_LANG["cnr1"];
$_LANG["cnrxauidwarrantydescr"] = "De houder van een .id.au-domein moet garanderen dat hij/zij een Australisch inwoner of burger is";
$_LANG["cnrxaueligibilityname"] = "Naam van recht";
$_LANG["cnrxaueligibilitynamedescr"] = "De naam van het rechtstype (bijv. handelsnaam)";
$_LANG["cnrxaudomainidnumber"] = "Domeinhouder, identificatienummer";
$_LANG["cnrxaudomainidnumberdescr"] = "";
$_LANG["cnrxaudomainidtype"] = "Domeinhouder, identificatietype";
// $_LANG["cnrxaudomainidtypetm"] = "TM";
// $_LANG["cnrxaudomainidtypeabn"] = "ABN";
// $_LANG["cnrxaudomainidtypeacn"] = "ACN";
// $_LANG["cnrxaudomainidtypeother"] = "Other";
// $_LANG["cnrxaudomainidtypeact"] = "ACT";
// $_LANG["cnrxaudomainidtypensw"] = "NSW";
// $_LANG["cnrxaudomainidtypent"] = "NT";
// $_LANG["cnrxaudomainidtypeqld"] = "QLD";
// $_LANG["cnrxaudomainidtypesa"] = "SA";
// $_LANG["cnrxaudomainidtypetas"] = "TAS";
// $_LANG["cnrxaudomainidtypevic"] = "VIC";
// $_LANG["cnrxaudomainidtypewa"] = "WA";
// $_LANG["cnrxaudomainidtypeprivate"] = "Private";
$_LANG["cnrxaudomainidtypedescr"] = "";
$_LANG["cnrxaueligibilityidnumber"] = "Recht, identificatienummer";
$_LANG["cnrxaueligibilityidnumberdescr"] = "";
$_LANG["cnrxaueligibilityidtype"] = "Recht, identificatietype";
$_LANG["cnrxaueligibilityidtypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .CA Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcalegaltype"] = "Domeinhouder, rechtsvorm";
$_LANG["cnrxcalegaltypeabo"] = "Inheemse inwoner van Canada";
$_LANG["cnrxcalegaltypeass"] = "Niet-geregistreerde Canadese vereniging";
$_LANG["cnrxcalegaltypecco"] = "Vennootschap (Canada of Canadese provincie/territorium)";
$_LANG["cnrxcalegaltypecct"] = "Canadese staatsburger";
$_LANG["cnrxcalegaltypeedu"] = "Canadese onderwijsinstelling";
$_LANG["cnrxcalegaltypegov"] = "Overheid of overheidsinstantie in Canada";
$_LANG["cnrxcalegaltypehop"] = "Canadees ziekenhuis";
$_LANG["cnrxcalegaltypeinb"] = "Door de Indian Act erkende inheemse groep";
$_LANG["cnrxcalegaltypelam"] = "Canadese bibliotheek, archief of museum";
$_LANG["cnrxcalegaltypelgr"] = "Wettelijk vertegenwoordiger van een Canadese staatsburger of permanente inwoner";
$_LANG["cnrxcalegaltypemaj"] = "Hare Majesteit de Koningin";
$_LANG["cnrxcalegaltypeomk"] = "Officieel handelsmerk geregistreerd in Canada";
$_LANG["cnrxcalegaltypeplt"] = "Canadese politieke partij";
$_LANG["cnrxcalegaltypeprt"] = "In Canada geregistreerd partnerschap";
$_LANG["cnrxcalegaltyperes"] = "Permanente inwoner van Canada";
$_LANG["cnrxcalegaltypetdm"] = "In Canada geregistreerd merk (door niet-Canadese houder)";
$_LANG["cnrxcalegaltypetrd"] = "Canadese handelsvereniging";
$_LANG["cnrxcalegaltypetrs"] = "In Canada opgericht trustfonds";
// $_LANG["cnrxcalegaltypedescr"] = "";
$_LANG["cnrxcatrademark"] = "Is een geregistreerd merk";
$_LANG["cnrxcatrademark0"] = $_LANG["cnr0"];
$_LANG["cnrxcatrademark1"] = $_LANG["cnr1"];
$_LANG["cnrxcatrademarkdescr"] = "Geeft aan of het domein een geregistreerd merk is of niet.";

// ----------------------------------------------------------------------
// ------------------ .COM.BR Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxbrregisternumber"] = "Domeinhouder, Braziliaans registratienummer";
$_LANG["cnrxbrregisternumberdescr"] = "Het Braziliaanse ondernemingsregistratienummer (CNPJ) of het Braziliaanse persoonlijke registratienummer (CPF).";

// ----------------------------------------------------------------------
// ------------------ .CN Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcnownertype"] = "Domeinhouder, type";
$_LANG["cnrxcnownertypei"] = "Particulier";
$_LANG["cnrxcnownertypee"] = "Bedrijf";
$_LANG["cnrxcnownertypedescr"] = "";
$_LANG["cnrxcnowneridtype"] = "Domeinhouder, ID-type";
$_LANG["cnrxcnowneridtypesfz"] = "SFZ (Identiteitskaart) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypehz"] = "HZ (Paspoort) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypegajmtx"] = "GAJMTX (Toestemming voor uitreis/terugkeer Hongkong en Macau) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypetwjmtx"] = "TWJMTX (Reisdocument voor inwoners van Taiwan voor in- en uitreizen) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypewjlsfz"] = "WJLSFZ (Buitenlandse verblijfsvergunning) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypegajzz"] = "GAJZZ (Verblijfsvergunning voor inwoners van Hongkong/Macau) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypetwjzz"] = "TWJZZ (Verblijfsvergunning voor inwoners van Taiwan) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypejgz"] = "JGZ (Militair identiteitsbewijs) - Domeinhouder type is particulier";
$_LANG["cnrxcnowneridtypeqt"] = "QT (Overig) - Domeinhouder type is particulier of bedrijf";
$_LANG["cnrxcnowneridtypeorg"] = "ORG (Organisatiecode-certificaat) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypeyyzz"] = "YYZZ (Zakelijke licentie) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypetydm"] = "TYDM (USCC-certificaat) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypebddm"] = "BDDM (Militaire code) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypejddwfw"] = "JDDWFW (Militair betaalde externe dienstverleningslicentie) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypesydwfr"] = "SYDWFR (Certificaat rechtspersoon publieke instelling) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypewgczjg"] = "WGCZJG (Registratieformulier buitenlandse vestiging) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypeshttfr"] = "SHTTFR (Registratiecertificaat sociale organisatie) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypezjcs"] = "ZJCS (Registratiecertificaat religieuze locatie) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypembfqy"] = "MBFQY (Registratiecertificaat private non-profit organisatie) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypejjhfr"] = "JJHFR (Registratiecertificaat stichting) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypelszy"] = "LSZY (Vergunning advocatenkantoor) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypewgzhwh"] = "WGZHWH (Registratiecertificaat buitenlands cultureel centrum in China) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypewlczzg"] = "WLCZJG (Registratiecertificaat buitenlandse toerismevertegenwoordiging) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypesfjd"] = "SFJD (Certificaat juridische entiteit) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypejwjg"] = "JWJG (Certificaat buitenlandse onderneming) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypeshfwjg"] = "SHFWJG (Registratiecertificaat sociale dienstverlener) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypembxxbx"] = "MBXXBX (Vergunning particuliere school) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypeyljgzy"] = "YLJGZY (Vergunning medische instelling) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypegzjgzy"] = "GZJGZY (Vergunning notariskantoor) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypebjwsxx"] = "BJWSXX (Vergunning school voor kinderen van buitenlandse diplomaten in Beijing/China) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypeqttyzm"] = "QTTYDM (Overig-certificaat USCC) - Domeinhouder type is bedrijf";
$_LANG["cnrxcnowneridtypedescr"] = "Type identificatiedocument";
$_LANG["cnrxcnowneridnumber"] = "Domeinhouder, ID-nummer";
$_LANG["cnrxcnowneridnumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COOP Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcoopeligibility"] = "Vereisten voor geschiktheid";
$_LANG["cnrxcoopeligibilitydescr"] = "Ik verklaar dat mijn organisatie aan minimaal één van de .COOP-geschiktheidscriteria voldoet. Zie <a style=\"text-decoration:underline\" href=\"https://identity.coop/coop-policies-and-agreements/\" target=\"_blank\">hier</a>.";
$_LANG["cnrxcoopeligibility0"] = $_LANG["cnr0"];
$_LANG["cnrxcoopeligibility1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .DE Fields ----------------------------------------
// ----------------------------------------------------------------------
 //$_LANG["cnrxdensentry0"] = "";
$_LANG["cnrxdensentry0descr"] = implode(" ", [
    "Maakt het gebruik van nsentry's in plaats van nameservers voor .de-domeinen mogelijk;",
    "NS-entry's stellen u in staat subdomeinen te configureren met alternatieve nameservers.",
    "<a target=\"_blank\" href=\"https://www.denic.de/en/domains/de-domains/registration/nameserver-and-nsentry-data/\" style=\"text-decoration:underline\">Gedetailleerde informatie</a>."
]);
//$_LANG["cnrxdensentry1"] = "";
$_LANG["cnrxdensentry1descr"] = "zie hierboven";
//$_LANG["cnrxdensentry2"] = "";
$_LANG["cnrxdensentry2descr"] = "zie hierboven";
//$_LANG["cnrxdensentry3"] = "";
$_LANG["cnrxdensentry3descr"] = "zie hierboven";
//$_LANG["cnrxdensentry4"] = "";
$_LANG["cnrxdensentry4descr"] = "zie hierboven";
//$_LANG["cnrxdegeneralrequest"] = "";
//$_LANG["cnrxdegeneralrequestdescr"] = "";
//$_LANG["cnrxdeabusecontact"] = "";
//$_LANG["cnrxdeabusecontactdescr "] = "";

// ----------------------------------------------------------------------
// ------------------ .DK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdkusertype"] = "Domeinhouder, type";
$_LANG["cnrxdkusertypeperson"] = "Persoon";
$_LANG["cnrxdkusertypecompany"] = "Bedrijf";
$_LANG["cnrxdkusertypeassociation"] = "Vereniging";
$_LANG["cnrxdkusertypepuborg"] = "Publieke organisatie";
// $_LANG["cnrxdkusertypedescr"] = "";
$_LANG["cnrxdkuseridnumber"] = "Domeinhouder, ID-nummer";
$_LANG["cnrxdkuseridnumberdescr"] = implode("", [
    "Identificatienummer van de domeinhouder. Dit kan een <i>EAN, CVR of P-nummer</i> zijn. ",
    "Het <i>CVR-nummer</i> wordt gebruikt voor de identificatie van de organisatie, en het <i>EAN-nummer</i> zorgt ervoor ",
    "dat documenten met betrekking tot elektronische facturatie naar het juiste account worden gestuurd. ",
    "Het <i>P-nummer</i> is een vestigingsnummer dat door het Deense Centrale Bedrijfsregister wordt toegekend om ",
    "fysieke locaties aan een organisatie te koppelen."
]);

// ----------------------------------------------------------------------
// ------------------ .ES Fields ----------------------------------------
// ----------------------------------------------------------------------
$types = [
    1 => "Particulier",
    39 => "Economische belangengroep",
    47 => "Vereniging",
    59 => "Sportvereniging",
    68 => "Beroepsvereniging",
    124 => "Spaarbank",
    150 => "Gemeenschappelijk goed",
    152 => "Vereniging van eigenaren",
    164 => "Orde of religieuze instelling",
    181 => "Consulaat",
    197 => "Publiekrechtelijke vereniging",
    203 => "Ambassade",
    229 => "Gemeentebestuur",
    269 => "Sportfederatie",
    286 => "Stichting",
    365 => "Wederzijdse verzekeringsmaatschappij",
    434 => "Regionale overheidsinstantie",
    436 => "Centrale overheidsinstantie",
    439 => "Politieke partij",
    476 => "Vakbond",
    510 => "Landbouwpartnerschap",
    524 => "Naamloze vennootschap",
    525 => "Sportclub",
    554 => "Burgerlijke maatschappij",
    560 => "Vennootschap onder firma",
    562 => "Vennootschap onder firma en commanditaire vennootschap",
    566 => "Coöperatie",
    608 => "Werknemersbedrijf",
    612 => "Besloten vennootschap",
    713 => "Spaans agentschap",
    717 => "Tijdelijke bedrijfscombinatie",
    744 => "Werknemersnaamloze vennootschap",
    745 => "Regionale publieke entiteit",
    746 => "Nationale publieke entiteit",
    747 => "Lokale publieke entiteit",
    877 => "Overig",
    878 => "Raad van oorsprongsbenaming",
    879 => "Entiteit voor beheer van natuurgebieden"
];
$idtypes = [
    0 => "Overig (voor contacten buiten Spanje)",
    1 => "DNI/NIF (voor Spaanse contacten)",
    2 => "Verouderd, gebruik de volgende optie.",
    3 => "NIE (voor Spaanse contacten)",
    4 => "BTW (belastingnummer) - alleen geldig voor niet-Spaanse juridische entiteiten"
];
$idtypesdescr = implode("<br/>", [
    "DNI = &quot;Documento Nacional de Identidad&quot;",
    "NIF = &quot;Número de Identificación Fiscal&quot;",
    "NIE = &quot;Número de Identificación de Extranjero&quot;. Dit is het equivalent van een Spaanse NIF, maar wordt uitgegeven door Spaanse autoriteiten aan buitenlanders die langer dan 3 maanden in Spanje verblijven."
]);
$idnodescr = "Het identificatienummer van dit contact. Voor Spaanse contacten is dit het DNI/NIF/NIE-nummer – anders het ID- of paspoortnummer.";

$_LANG["cnrxesownertipoidentificacion"] = "Domeinhouder, identificatietype";
$_LANG["cnrxesadmintipoidentificacion"] = "Admin, identificatietype";
$_LANG["cnrxestechtipoidentificacion"] = "Technisch contact, identificatietype";
$_LANG["cnrxesbillingtipoidentificacion"] = "Facturatie, identificatietype";

foreach ($idtypes as $key => $value) {
    $_LANG["cnrxesownertipoidentificacion$key"] = $value;
    $_LANG["cnrxesadmintipoidentificacion$key"] = $value;
    $_LANG["cnrxestechtipoidentificacion$key"] = $value;
    $_LANG["cnrxesbillingtipoidentificacion$key"] = $value;
}

$_LANG["cnrxesownertipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesadmintipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxestechtipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesbillingtipoidentificaciondescr"] = $idtypesdescr;

$_LANG["cnrxesowneridentificacion"] = "Domeinhouder, identificatienummer";
$_LANG["cnrxesadminidentificacion"] = "Admin, identificatienummer";
$_LANG["cnrxestechidentificacion"] = "Technisch contact, identificatienummer";
$_LANG["cnrxesbillingidentificacion"] = "Facturatie, identificatienummer";

$_LANG["cnrxesowneridentificaciondescr"] = $idnodescr;
$_LANG["cnrxesadminidentificaciondescr"] = $idnodescr;
$_LANG["cnrxestechidentificaciondescr"] = $idnodescr;
$_LANG["cnrxesbillingidentificaciondescr"] = $idnodescr;

$_LANG["cnrxesownerlegalform"] = "Domeinhouder, rechtsvorm";
$_LANG["cnrxesadminlegalform"] = "Admin, rechtsvorm";
$_LANG["cnrxestechlegalform"] = "Technisch contact, rechtsvorm";
$_LANG["cnrxesbillinglegalform"] = "Facturatie, rechtsvorm";

foreach ($types as $key => $value) {
    $_LANG["cnrxesownerlegalform$key"] = $value;
    $_LANG["cnrxesadminlegalform$key"] = $value;
    $_LANG["cnrxestechlegalform$key"] = $value;
    $_LANG["cnrxesbillinglegalform$key"] = $value;
}

$_LANG["cnrxesownerlegalformdescr"] = "";
$_LANG["cnrxesadminlegalformdescr"] = "";
$_LANG["cnrxestechlegalformdescr"] = "";
$_LANG["cnrxesbillinglegalformdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .EU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxeuregistrantlang"] = "Domeinhouder, taal";
$_LANG["cnrxeuregistrantcitizenship"] = "Domeinhouder, nationaliteit";
$_LANG["cnrxeuregistrantlangdescr"] = "Taal voor communicatie met de TLD-provider (standaard = Engels)";
$_LANG["cnrxeuregistrantcitizenshipdescr"] = "Particuliere registranten met een Europese nationaliteit die buiten de EU wonen, kunnen .eu-domeinen registreren met deze instelling.";

// ----------------------------------------------------------------------
// ------------------ .FI Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxficompanyregid"] = "Domeinhouder, bedrijfs-ID of registratienummer";
$_LANG["cnrxficompanyregiddescr"] = "Lokale bedrijfsentiteit (geregistreerd in het Finse handelsregister of een rechtspersoon binnen de Finse Republiek)<br/>(vereist voor niet-Finse entiteiten)";
$_LANG["cnrxfipersonalid"] = "Domeinhouder, persoonlijk identificatienummer";
$_LANG["cnrxfipersonaliddescr"] = "Fins persoonlijk identificatienummer<br/>(vereist voor niet-Finse particulieren)";
$_LANG["cnrxfibirthdate"] = "Domeinhouder, geboortedatum";
$_LANG["cnrxfibirthdatedescr"] = "Geboortedatum (JJJJ-MM-DD)<br/>(vereist voor niet-Finse particulieren)";
$_LANG["cnrxficontacttype"] = "Domeinhouder, contacttype";
$_LANG["cnrxficontacttype0"] = "Particulier";
$_LANG["cnrxficontacttype1"] = "Bedrijf";
$_LANG["cnrxficontacttype2"] = "Rechtspersoon";
$_LANG["cnrxficontacttype3"] = "Instelling";
$_LANG["cnrxficontacttype4"] = "Politieke partij";
$_LANG["cnrxficontacttype5"] = "Gemeente";
$_LANG["cnrxficontacttype6"] = "Overheid";
$_LANG["cnrxficontacttype7"] = "Publieke gemeenschap";
$_LANG["cnrxficontacttypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .GAY Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxgayacceptrequirements"] = "Vereisten accepteren";
$_LANG["cnrxgayacceptrequirements0"] = $_LANG["cnr0"];
$_LANG["cnrxgayacceptrequirements1"] = $_LANG["cnr1"];
$_LANG["cnrxgayacceptrequirementsdescr"] = "Ik bevestig dat de domeinnaam NIET wordt gebruikt voor het aanzetten tot geweld, pesten, intimidatie of haatzaaien en NIET wordt gebruikt door erkende haatgroepen. DotGay doneert 20% van elke nieuw geregistreerde domeinnaam aan haar partners, GLAAD en CenterLink.";

// ----------------------------------------------------------------------
// ------------------ .HK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxhkownerdocumenttype"] = "Domeinhouder, documenttype";
$_LANG["cnrxhkownerdocumenttypehkid"] = "Particulier: HK identiteitskaartnummer";
$_LANG["cnrxhkownerdocumenttypeothid"] = "Particulier: Identiteitsnummer van ander land";
$_LANG["cnrxhkownerdocumenttypepassno"] = "Particulier: Paspoortnummer";
$_LANG["cnrxhkownerdocumenttypebirthcert"] = "Particulier: Geboorteakte";
$_LANG["cnrxhkownerdocumenttypeothidv"] = "Particulier: Overig document";
$_LANG["cnrxhkownerdocumenttypebr"] = "Organisatie: Handelsregistratie";
$_LANG["cnrxhkownerdocumenttypeci"] = "Organisatie: Oprichtingsakte";
$_LANG["cnrxhkownerdocumenttypecrs"] = "Organisatie: Schoolregistratiecertificaat";
$_LANG["cnrxhkownerdocumenttypehksarg"] = "Organisatie: HK overheidsafdeling";
$_LANG["cnrxhkownerdocumenttypehkordinance"] = "Organisatie: HK verordening";
$_LANG["cnrxhkownerdocumenttypeothorg"] = "Organisatie: Overig document";
$_LANG["cnrxhkownerdocumenttypedescr"] = "";
$_LANG["cnrxhkownerdocumentnumber"] = "Domeinhouder, documentnummer";
$_LANG["cnrxhkownerdocumentnumberdescr"] = "";
$_LANG["cnrxhkownerdocumentorigincountry"] = "Domeinhouder, land van afgifte document";
$_LANG["cnrxhkownerdocumentorigincountrydescr"] = "Het land waar dit document is afgegeven (gebruik de 2-letterige ISO-landcode, bijv. NL of BE).";
$_LANG["cnrxhkownerotherdocumenttype"] = "Domeinhouder, ander documenttype";
$_LANG["cnrxhkownerotherdocumenttypedescr"] = "Vereist indien het eerder gekozen documenttype '" . $_LANG["cnrxhkownerdocumenttypeothidv"] . "' of '" . $_LANG["cnrxhkownerdocumenttypeothorg"] . "' is.";
$_LANG["cnrxhkdomaincategory"] = "Domeincategorie";
$_LANG["cnrxhkdomaincategoryi"] = "Particulier";
$_LANG["cnrxhkdomaincategoryo"] = "Organisatie";
$_LANG["cnrxhkdomaincategorydescr"] = "Juridisch type van alle domeincontacten";
$_LANG["cnrxhkownerageover18"] = "Domeinhouder, ouder dan 18 jaar";
$_LANG["cnrxhkownerageover18no"] = $_LANG["cnr0"];
$_LANG["cnrxhkownerageover18yes"] = $_LANG["cnr1"];
$_LANG["cnrxhkownerageover18descr"] = "Ik bevestig dat de domeinhouder minimaal 18 jaar oud is (alleen vereist voor particulieren).";

// ----------------------------------------------------------------------
// ------------------ .IE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxiecontacttype"] = "Domeinhouder, contacttype";
$_LANG["cnrxiecontacttypecom"] = "Bedrijf";
$_LANG["cnrxiecontacttypecha"] = "Goede doel / Stichting";
$_LANG["cnrxiecontacttypeoth"] = "Overig";
$_LANG["cnrxiecontacttypedescr"] = "";
$_LANG["cnrxielanguage"] = "Domeinhouder, taal";
$_LANG["cnrxielanguageen"] = "Engels";
$_LANG["cnrxielanguagefr"] = "Frans";
$_LANG["cnrxielanguagedescr"] = "Taal voor communicatie met de TLD-provider (standaard = Engels)";
$_LANG["cnrxiecronumber"] = "Domeinhouder, CRO-nummer";
$_LANG["cnrxiecronumberdescr"] = "Bedrijfsregistratienummer (CRO-nummer)";
$_LANG["cnrxiesupportingnumber"] = "Domeinhouder, ondersteuningsnummer";
$_LANG["cnrxiesupportingnumberdescr"] = "Stichtings- / ondersteuningsnummer";

// ----------------------------------------------------------------------
// ------------------ .IT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxitconsentforpublishing"] = $_LANG["cnrconsentforpublishing"];
$_LANG["cnrxitconsentforpublishing0"] = $_LANG["cnr0"];
$_LANG["cnrxitconsentforpublishing1"] = $_LANG["cnr1"];
$_LANG["cnrxitconsentforpublishingdescr"] = "Toestemming voor publicatie van persoonlijke contactgegevens. Weigering is alleen mogelijk indien het entiteitstype hieronder 1 is.";
$_LANG["cnrxitentitytype"] = "Domeinhouder, entiteitstype";
$_LANG["cnrxitentitytype1"] = "[1] Italiaanse en buitenlandse natuurlijke personen";
$_LANG["cnrxitentitytype2"] = "[2] Bedrijven/eenmanszaken";
$_LANG["cnrxitentitytype3"] = "[3] Zelfstandigen/professionals";
$_LANG["cnrxitentitytype4"] = "[4] Non-profitorganisaties";
$_LANG["cnrxitentitytype5"] = "[5] Publieke organisaties";
$_LANG["cnrxitentitytype6"] = "[6] Overige entiteiten";
$_LANG["cnrxitentitytype7"] = "[7] Buitenlandse entiteiten die overeenkomen met 2-6";
$_LANG["cnrxitentitytypedescr"] = "Entiteitstype ter identificatie van de domeinhouder.";
$_LANG["cnrxitpin"] = "Domeinhouder, fiscaal nummer";
//$_LANG["cnrxitpindescr"] = "";
$_LANG["cnrxitnationality"] = "Domeinhouder, nationaliteit";
$_LANG["cnrxitnationalitydescr"] = "Nationaliteit van de domeinhouder, aangeduid met de 2-letterige ISO-landcode.";
//$_LANG["cnrxitsect3liability"] = "";
$_LANG["cnrxitsect3liabilitydescr"] = "";
$_LANG["cnrxitsect3liability0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect3liability1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect5personaldataforregistration"] = "";
$_LANG["cnrxitsect5personaldataforregistrationdescr"] = "";
$_LANG["cnrxitsect5personaldataforregistration0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect5personaldataforregistration1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect6personaldatafordiffusion"] = "";
$_LANG["cnrxitsect6personaldatafordiffusiondescr"] = "";
$_LANG["cnrxitsect6personaldatafordiffusion0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect6personaldatafordiffusion1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect7explicitacceptance"] = "";
$_LANG["cnrxitsect7explicitacceptancedescr"] = "";
$_LANG["cnrxitsect7explicitacceptance0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect7explicitacceptance1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .LV Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxlvownerregnr"] = "Domeinhouder, registratienummer";
$_LANG["cnrxlvownerregnrdescr"] = "Het registratienummer van de Letse entiteit dat wordt gebruikt voor de domeinhouder (bijv. bedrijfsregistratienummer)";
$_LANG["cnrxlvadminregnr"] = "Admin, registratienummer";
$_LANG["cnrxlvadminregnrdescr"] = "Het registratienummer van de Letse entiteit dat wordt gebruikt voor de administratieve contactpersoon (bijv. bedrijfsregistratienummer)";
$_LANG["cnrxlvvatnr"] = "Domeinhouder, btw-nummer";
$_LANG["cnrxlvvatnrdescr"] = "Het btw-nummer van de domeinhouder (alleen voor bedrijven).";

// ----------------------------------------------------------------------
// ------------------ .LT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxltcompanynumber"] = "Domeinhouder, ondernemingsnummer";
$_LANG["cnrxltcompanynumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .MY Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxmybusinessnumber"] = "Domeinhouder, ondernemingsnummer";
$_LANG["cnrxmybusinessnumberdescr"] = "Het bedrijfsregistratienummer van de domeinhouder (alleen voor bedrijven)";
$_LANG["cnrxmyorganizationtype"] = "Domeinhouder, organisatietype";
$_LANG["cnrxmyorganizationtypedescr"] = "Het type organisatie van de domeinhouder (alleen voor bedrijven)";
$_LANG["cnrxmyperidentity"] = "Domeinhouder, persoonlijk identificatienummer";
$_LANG["cnrxmyperidentitydescr"] = "Het persoonlijke identificatienummer van de domeinhouder (alleen voor particulieren)";
$_LANG["cnrxmyperdateofbirth"] = "Domeinhouder, geboortedatum";
$_LANG["cnrxmyperdateofbirthdescr"] = "De geboortedatum van de domeinhouder (JJJJ-MM-DD, alleen voor particulieren)";
$_LANG["cnrxmyrace"] = "Domeinhouder, etniciteit";
$_LANG["cnrxmyracemalay"] = "Maleis";
$_LANG["cnrxmyracechinese"] = "Chinees";
$_LANG["cnrxmyraceindian"] = "Indiaas";
$_LANG["cnrxmyraceothers"] = "Overig";
$_LANG["cnrxmyracedescr"] = "(alleen voor particulieren)";

// ----------------------------------------------------------------------
// ------------------ .NO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnoorganizationnumber"] = "Domeinhouder, organisatienummer";
$_LANG["cnrxnoorganizationnumberdescr"] = "Het Noorse registratienummer uitgegeven door het Centraal Coördinatieregister voor rechtspersonen.";
$_LANG["cnrxnopersonidentifier"] = "Norid persoons-ID";
$_LANG["cnrxnopersonidentifierdescr"] = "Vereist persoons-ID voor registratie van een particuliere .PRIV.NO-domein. Anders leeg laten.";

// ----------------------------------------------------------------------
// ------------------ .NU Fields ----------------------------------------
// ----------------------------------------------------------------------
// see further .nu fields at the top of the file
$_LANG["cnrxnuiisidno"] = "Domeinhouder, ID-nummer";
$_LANG["cnrxnuiisidnodescr"] = "Persoonlijk identificatienummer, ondernemingsnummer of registratieaanduiding in een nationaal register. Voor contacten in Zweden is een geldige Zweedse ID vereist (bijv.: 123456-1234).";
$_LANG["cnrxnuiisvatno"] = "Domeinhouder, btw-nummer";
$_LANG["cnrxnuiisvatnodescr"] = "Het btw-nummer van de domeinhouder (alleen voor bedrijven)";

// ----------------------------------------------------------------------
// ------------------ .NYC Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnycextcontact"] = "NY externe contactpersoon";
$_LANG["cnrxnycextcontactadmin"] = "Administratief contact";
$_LANG["cnrxnycextcontacttech"] = "Technisch contact";
$_LANG["cnrxnycextcontactbilling"] = "Facturatiecontact";
$_LANG["cnrxnycextcontactowner"] = "Domeinhouder";
$_LANG["cnrxnycextcontactdescr"] = "Het opgegeven contact moet een geldig fysiek adres in New York City hebben.";

// ----------------------------------------------------------------------
// ------------------ .PARIS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxafniccode"] = $_LANG["cnrxallocationtoken"];
$_LANG["cnrxafniccodedescr"] = $_LANG["cnrxallocationtokendescr"];

// ----------------------------------------------------------------------
// ------------------ .FR, .PM, .RE, .TF, .WF, .YT Fields ---------------
// ----------------------------------------------------------------------
// Organizations (Companies, Associations, etc.)
$_LANG["cnrxfrannouncedescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven (verenigingen/bedrijven). Laat leeg voor natuurlijke personen.<br/>",
    "Aankondigingsnummer in het Journal Officiel (alleen cijfers).",
    "Als u Journal Officiel-gegevens gebruikt als identificatie, vul dan alle bijbehorende JO-velden in:",
    "Publicatiedatum, aankondigingsnr., paginanr. en oprichtingsdatum."
]);
$_LANG["cnrxfrdatepublicationjo"] = "Organisatie/bedrijf, publicatiedatum<br/>(Journal Officiel)";
$_LANG["cnrxfrdatepublicationjodescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven (verenigingen/bedrijven). Laat leeg voor natuurlijke personen.<br/>",
    "Publicatiedatum in het Journal Officiel.",
    "Datumformaat JJJJ-MM-DD.",
    "Als u Journal Officiel-gegevens gebruikt als identificatie, vul dan alle bijbehorende JO-velden in:",
    "Publicatiedatum, aankondigingsnr., paginanr. en oprichtingsdatum."
]);
$_LANG["cnrxfrnumerodepageannouncejo"] = "Organisatie/bedrijf, paginanr.<br/>(Journal Officiel)";
$_LANG["cnrxfrnumerodepageannouncejodescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven (verenigingen/bedrijven). Laat leeg voor natuurlijke personen.<br/>",
    "Paginanummer in het Journal Officiel (alleen cijfers).",
    "Als u Journal Officiel-gegevens gebruikt als identificatie, vul dan alle bijbehorende JO-velden in:",
    "Publicatiedatum, aankondigingsnr., paginanr. en oprichtingsdatum."
]);
$_LANG["cnrxfrwaldec"] = "Organisatie/bedrijf, Waldec-ID (verenigingen)";
$_LANG["cnrxfrwaldecdescr"] = implode(" ", [
    "Alleen voor verenigingen. Laat leeg voor natuurlijke personen.<br/>",
    "Waldec-identificatie gekoppeld aan een vereniging (alleen cijfers).",
    "Indien opgegeven is dit voldoende om de vereniging te identificeren.",
    "Tip: meestal is één identificatie voldoende; als u Waldec invult, laat dan andere organisatie-identificaties leeg (SIREN/SIRET, btw-nummer, DUNS, merkregistratie, lokale ID, Journal Officiel-velden)."
]);
$_LANG["cnrxfrdateassociation"] = "Organisatie/bedrijf, oprichtingsdatum";
$_LANG["cnrxfrdateassociationdescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven (verenigingen/bedrijven). Laat leeg voor natuurlijke personen.<br/>",
    "Datumformaat JJJJ-MM-DD.",
    "Vereist wanneer u Journal Officiel-gegevens invult (aankondigingsnr., paginanr., publicatiedatum)."
]);
$_LANG["cnrxfrduns"] = "Organisatie/bedrijf, DUNS-nummer";
$_LANG["cnrxfrdunsdescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven. Laat leeg voor natuurlijke personen.<br/>",
    "Het DUNS-nummer is een unieke negen-cijferige identificatie voor organisaties. Afkorting van Data Universal",
    "Numbering System; verwijst naar een nieuwe identificatie die kan worden gebruikt voor validatie",
    "op Europees niveau.",
    "Tip: meestal is één identificatie voldoende (bijv. SIREN/SIRET, btw-nummer, DUNS, merkregistratie, lokale ID, Waldec of Journal Officiel-velden)."
]);
$_LANG["cnrxfrlocal"] = "Organisatie/bedrijf, lokale ID";
$_LANG["cnrxfrlocaldescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven. Laat leeg voor natuurlijke personen.<br/>",
    "Een lokale identificatie die specifiek is voor een land binnen de Europese Economische Ruimte (bijv. ondernemingscertificaatnummer).",
    "Tip: meestal is één identificatie voldoende (bijv. SIREN/SIRET, btw-nummer, DUNS, merkregistratie, lokale ID, Waldec of Journal Officiel-velden)."
]);
$_LANG["cnrxfrnoprezonecheck0"] = $_LANG["cnr0"];
$_LANG["cnrxfrnoprezonecheck1"] = $_LANG["cnr1"];
$_LANG["cnrxfrsirenorsiret"] = "Organisatie/bedrijf, SIREN/SIRET-nummer";
$_LANG["cnrxfrsirenorsiretdescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven. Laat leeg voor natuurlijke personen.<br/>",
    "Vul dit in als u registreert als organisatie/bedrijf in Frankrijk met een geldig SIREN/SIRET.",
    "Tip: meestal is één identificatie voldoende; als u SIREN/SIRET invult, kunt u btw-nummer, DUNS, merkregistratie, lokale ID, Waldec en Journal Officiel-velden leeg laten.",
    "De SIREN-code is het unieke bedrijfsnummer in Frankrijk. Deze wordt uitgegeven door het",
    "Institut national de la statistique et des études économiques (INSEE) en bestaat uit 9 cijfers.",
    "De eerste 9 cijfers zijn het SIREN-nummer en de volgende 5 cijfers zijn het NIC-nummer",
    "(Numéro Interne de Classement). Het SIRET-nummer wordt uitgegeven zodra u uw",
    "bedrijf registreert bij de Kamer van Koophandel (RCS) voor handel, de Kamer van Ambachten voor ambachtelijk werk,",
    "of bij de URSSAF voor intellectuele diensten.",
    "SIRET-nummers bestaan uit 14 cijfers. Het SIRET-nummer geeft informatie over de vestigingslocatie van het bedrijf in Frankrijk",
    "(voor gevestigde ondernemingen). De bedrijfsnaam opgegeven bij de registrant moet",
    "exact overeenkomen met die in de SIREN/SIRET-database ( https://www.infogreffe.fr/ )."
]);
$_LANG["cnrxfrtrademark"] = "Organisatie/bedrijf, merkregistratienummer";
$_LANG["cnrxfrtrademarkdescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven. Laat leeg voor natuurlijke personen.<br/>",
    "Merkregistratienummer (als u registreert op basis van merkrechten).",
    "Tip: meestal is één identificatie voldoende; als u een merkregistratienummer invult, kunt u SIREN/SIRET, btw-nummer, DUNS, lokale ID, Waldec en Journal Officiel-velden leeg laten."
]);
$_LANG["cnrxfrvatid"] = "Organisatie/bedrijf, btw-nummer";
$_LANG["cnrxfrvatiddescr"] = implode(" ", [
    "Alleen voor organisaties/bedrijven. Laat leeg voor natuurlijke personen.<br/>",
    "Btw-nummer (indien beschikbaar).",
    "Tip: meestal is één identificatie voldoende; als u btw-nummer invult, kunt u SIREN/SIRET, DUNS, merkregistratie, lokale ID, Waldec en Journal Officiel-velden leeg laten."
]);

// Individual
$_LANG["cnrxfrbirthpc"] = "Domeinhouder, postcode (geboorteplaats)";
$_LANG["cnrxfrbirthpcdescr"] = implode(" ", [
    "Alleen voor natuurlijke personen (particulieren). Laat leeg voor organisaties/bedrijven.<br/>",
    "Alleen vereist voor personen geboren in Frankrijk of Franse overzeese gebieden (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Vul de postcode van de geboorteplaats in (of ten minste de departementcode)."
]);
$_LANG["cnrxfrbirthcity"] = "Domeinhouder, geboortestad";
$_LANG["cnrxfrbirthcitydescr"] = implode(" ", [
    "Alleen voor natuurlijke personen (particulieren). Laat leeg voor organisaties/bedrijven.<br/>",
    "Alleen vereist voor personen geboren in Frankrijk of Franse overzeese gebieden (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Vul de naam van de stad in."
]);
$_LANG["cnrxfrbirthdate"] = "Domeinhouder, geboortedatum";
$_LANG["cnrxfrbirthdatedescr"] = "Alleen voor natuurlijke personen (particulieren).<br/>Geboortedatum in het formaat JJJJ-MM-DD. Laat leeg voor organisaties/bedrijven.";
$_LANG["cnrxfrbirthplace"] = "Domeinhouder, geboorteland";
$_LANG["cnrxfrbirthplacedescr"] = "Alleen voor natuurlijke personen (particulieren).<br/>Landcode van geboorteplaats (bijv. FR, DE). Laat leeg voor organisaties/bedrijven.";
$_LANG["cnrxfrrestrictpub"] = "Domeinhouder, publicatie beperken (WHOIS)";
$_LANG["cnrxfrrestrictpub0"] = $_LANG["cnr0"];
$_LANG["cnrxfrrestrictpub1"] = $_LANG["cnr1"];
$_LANG["cnrxfrrestrictpubdescr"] = "Alleen voor natuurlijke personen (particulieren). Kies 'Ja' om publicatie te beperken en persoonsgegevens in WHOIS te verbergen.";
$_LANG["cnrxfrnoprezonecheck"] = "DNS pre-check overslaan";
$_LANG["cnrxfrnoprezonecheckdescr"] = "Bepaalt of het systeem een DNS pre-check uitvoert voordat het verzoek naar de registry wordt gestuurd.";
//
// ----------------------------------------------------------------------
// ------------------ .PT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxpttechidentification"] = "Technisch contact, btw-nummer";
$_LANG["cnrxpttechidentificationdescr"] = "Het btw-nummer van het technisch contact";
$_LANG["cnrxptowneridentification"] = "Domeinhouder, btw-nummer";
$_LANG["cnrxptowneridentificationdescr"] = "Het btw-nummer van de domeinhouder";
$_LANG["cnrxpttechmobile"] = "Technisch contact, mobiel nummer";
$_LANG["cnrxpttechmobiledescr"] = "Het mobiele telefoonnummer van het technisch contact";
$_LANG["cnrxptownermobile"] = "Domeinhouder, mobiel nummer";
$_LANG["cnrxptownermobiledescr"] = "Het mobiele telefoonnummer van de domeinhouder";

// ----------------------------------------------------------------------
// ------------------ .RO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrocompanynumber"] = "Domeinhouder, ondernemingsnummer";
$_LANG["cnrxrocompanynumberdescr"] = "(alleen vereist voor bedrijven)";
$_LANG["cnrxroidcardorpassportnumber"] = "Domeinhouder, ID-kaart- of paspoortnummer";
$_LANG["cnrxroidcardorpassportnumberdescr"] = "(alleen vereist voor particulieren)";
$_LANG["cnrxrovatnumber"] = "Domeinhouder, btw-nummer";
$_LANG["cnrxrovatnumberdescr"] = "(alleen vereist voor bedrijven)";

// ----------------------------------------------------------------------
// ------------------ .RU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrubirthdate"] = "Domeinhouder, geboortedatum";
$_LANG["cnrxrubirthdatedescr"] = "De geboortedatum van de domeinhouder (DD.MM.JJJJ)<br/>(alleen vereist voor particulieren)";
$_LANG["cnrxrufirstname"] = "Domeinhouder, voornaam";
$_LANG["cnrxrufirstnamedescr"] = "De voornaam van de domeinhouder in het Russisch. Moet ingevuld worden met Russische en Latijnse letters, geen punten.<br/>(alleen vereist voor particulieren)";
$_LANG["cnrxrumiddlename"] = "Domeinhouder, tweede voornaam";
$_LANG["cnrxrumiddlenamedescr"] = "De tweede voornaam van de domeinhouder in het Russisch. Moet ingevuld worden met Russische en Latijnse letters, geen punten.<br/>(alleen vereist voor particulieren)";
$_LANG["cnrxrulastname"] = "Domeinhouder, achternaam";
$_LANG["cnrxrulastnamedescr"] = "De achternaam van de domeinhouder in het Russisch. Moet ingevuld worden met Russische en Latijnse letters, geen punten.<br/>(alleen vereist voor particulieren)";
$_LANG["cnrxruorganization"] = "Domeinhouder, organisatienaam";
$_LANG["cnrxruorganizationdescr"] = "De organisatienaam van de domeinhouder in het Russisch. Dit veld mag Russische en Latijnse letters, cijfers, leestekens en spaties bevatten.<br/>(alleen vereist voor organisaties geregistreerd in de Russische Federatie)";
$_LANG["cnrxrucode"] = "Domeinhouder, fiscaal nummer";
$_LANG["cnrxrucodedescr"] = "Het fiscaal nummer (TIN) van de domeinhouder. Dit veld moet een getal van tien cijfers bevatten (laatste cijfer is een controlegetal).<br/>(alleen vereist voor organisaties geregistreerd in de Russische Federatie)";
$_LANG["cnrxrukpp"] = "Domeinhouder, redencode";
$_LANG["cnrxrukppdescr"] = "De redencode (KPP) van de domeinhouder. Dit veld moet een getal van negen cijfers bevatten.<br/>(alleen vereist voor organisaties geregistreerd in de Russische Federatie)";
$_LANG["cnrxrupassportdata"] = "Domeinhouder, paspoortgegevens";
$_LANG["cnrxrupassportdatadescr"] = "De paspoortgegevens van de domeinhouder. Dit veld wordt in het Russisch ingevuld en mag Russische en Latijnse letters, cijfers, leestekens en spaties bevatten. Formaat: documentnummer, uitgegeven door, uitgiftedatum<br/>(alleen vereist voor particulieren)";

// ----------------------------------------------------------------------
// ------------------ .SE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnicseidnumber"] = "Domeinhouder, ID-nummer";
$_LANG["cnrxnicseidnumberdescr"] = "Persoonlijk of organisatie-identificatienummer.";
$_LANG["cnrxnicsevatid"] = "Domeinhouder, btw-nummer";
$_LANG["cnrxnicsevatiddescr"] = "";
$_LANG["cnrxsediscloseemail"] = "Domeinhouder, e-mailadres openbaar maken";
$_LANG["cnrxsediscloseemaildescr"] = "Sta toe dat het e-mailadres van de domeinhouder wordt weergegeven in de publieke WHOIS-database.";
$_LANG["cnrxsedisclosefax"] = "Domeinhouder, faxnummer openbaar maken";
$_LANG["cnrxsedisclosefaxdescr"] = "Sta toe dat het faxnummer van de domeinhouder wordt weergegeven in de publieke WHOIS-database.";
$_LANG["cnrxsedisclosevoice"] = "Domeinhouder, telefoonnummer openbaar maken";
$_LANG["cnrxsedisclosevoicedescr"] = "Sta toe dat het telefoonnummer van de domeinhouder wordt weergegeven in de publieke WHOIS-database.";
foreach (["email", "fax", "voice"] as $field) {
    $_LANG["cnrxsedisclose$field" . "0"] = $_LANG["cnr0"];
    $_LANG["cnrxsedisclose$field" . "1"] = $_LANG["cnr1"];
}

// ----------------------------------------------------------------------
// ------------------ .SG Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxsgrcbid"] = "Domeinhouder, RCB-ID";
$_LANG["cnrxsgrcbiddescr"] = "Het unieke ondernemingsnummer (UEN) of het registratienummer van de onderneming (RCB) van de domeinhouder. Voor <u>bedrijven</u> gevestigd in Singapore dient het juiste bedrijfsregistratienummer te worden opgegeven OF de contact-ID-kaart voor een lokale aanwezigheid in Singapore (formaat: S1234567D).";
$_LANG["cnrxsgadminsingpassid"] = "Admin, SingPass-ID";
$_LANG["cnrxsgadminsingpassiddescr"] = "De contact-ID-kaart (SingPass-ID) van de administratieve contactpersoon<br/>(alleen voor Singaporese <u>particulieren</u>, formaat: S1234567D)";

// ----------------------------------------------------------------------
// ------------------ .SK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxskcontactlegalform"] = "Domeinhouder, rechtsvorm";
$_LANG["cnrxskcontactlegalformdescr"] = "";
// $_LANG["cnrxskcontactlegalformcorp"] = "";
// $_LANG["cnrxskcontactlegalformpers"] = "";
$_LANG["cnrxskcontactidentnumber"] = "Domeinhouder, handelsregisternummer";
$_LANG["cnrxskcontactidentnumberdescr"] = "Verplicht veld voor bedrijven/organisaties";

// ----------------------------------------------------------------------
// ------------------ .SWISS Fields -------------------------------------
// ----------------------------------------------------------------------
// see other .swiss fields at top of the file
$_LANG["cnrxswissuid"] = "Domeinhouder, UID of UPI";
$_LANG["cnrxswissuiddescr"] = implode("", [
    "De ...<ul>",
    "<li>UID (ondernemingsidentificatienummer, formaat: \"CHE-ddd.ddd.ddd\") voor organisaties of</li>",
    "<li>UPI (universeel persoonsidentificatienummer, formaat: \"756.dddd.dddd.dd\") voor natuurlijke personen</li>",
    "</ul>... van de domeinhouder (d = cijfer).<br/>",
    "Let op: De naam van de persoon en de UPI worden NIET gepubliceerd in Whois/RDAP, in tegenstelling tot de organisatienaam en de UID, die wel zichtbaar zijn."
]);
$_LANG["cnrxswissownertype"] = "Domeinhouder, type";
$_LANG["cnrxswissownertypep"] = "Natuurlijke persoon";
$_LANG["cnrxswissownertypeo"] = "Organisatie / rechtspersoon";
$_LANG["cnrxswissownertypedescr"] = "Het identiteitstype van de domeinhouder.";

// ----------------------------------------------------------------------
// ------------------ .TRAVEL Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxtravelindustry"] = "Reissector";
$_LANG["cnrxtravelindustryn"] = $_LANG["cnr0"];
$_LANG["cnrxtravelindustryy"] = $_LANG["cnr1"];
$_LANG["cnrxtravelindustrydescr"] = "Ik bevestig dat de domeinhouder actief is in de reissector en een geldig lidmaatschapsnummer bezit.";

// ----------------------------------------------------------------------
// ------------------ .UK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxukownercorporatetype"] = "Domeinhouder, bedrijfstype";
$_LANG["cnrxukownercorporatetypedescr"] = "";
$_LANG["cnrxukownercorporatetypeother"] = "Overig";
$_LANG["cnrxukownercorporatetypefother"] = "Overig (niet-UK)";
$_LANG["cnrxukownercorporatetypeind"] = "Particulier";
$_LANG["cnrxukownercorporatetypefind"] = "Particulier (niet-UK)";
$_LANG["cnrxukownercorporatetypefcorp"] = "Bedrijf (niet-UK)";
// $_LANG["cnrxukownercorporatetypeltd"] = "LTD";
// $_LANG["cnrxukownercorporatetypeplc"] = "PLC";
// $_LANG["cnrxukownercorporatetypellp"] = "LLP";
// $_LANG["cnrxukownercorporatetypeip"] = "IP";
$_LANG["cnrxukownercorporatetypecrc"] = "Bedrijf met koninklijk statuut";
$_LANG["cnrxukownercorporatetypegov"] = "Overheidsinstantie";
$_LANG["cnrxukownercorporatetypeptnr"] = "Brits partnerschap";
$_LANG["cnrxukownercorporatetyperchar"] = "Geregistreerde liefdadigheidsinstelling";
$_LANG["cnrxukownercorporatetypesch"] = "School";
$_LANG["cnrxukownercorporatietypestat"] = "Publiekrechtelijke entiteit";
$_LANG["cnrxukownercorporatetypestra"] = "Eenmanszaak";
$_LANG["cnrxukownercorporatenumber"] = "Domeinhouder, bedrijfsregistratienummer";
$_LANG["cnrxukownercorporatenumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .US Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxusnexusapppurpose"] = "US Nexus, beoogd gebruik";
$_LANG["cnrxusnexusapppurposep1"] = "Zakelijk gebruik met winstoogmerk";
$_LANG["cnrxusnexusapppurposep2"] = "Non-profitorganisatie, vereniging, religieuze organisatie, enz.";
$_LANG["cnrxusnexusapppurposep3"] = "Persoonlijk gebruik";
$_LANG["cnrxusnexusapppurposep4"] = "Educatieve doeleinden";
$_LANG["cnrxusnexusapppurposep5"] = "Overheidsdoeleinden";
$_LANG["cnrxusnexusapppurposedescr"] = "";
$_LANG["cnrxusnexuscategory"] = "US Nexus, categorie";
$_LANG["cnrxusnexuscategoryc11"] = "[C11] Amerikaans staatsburger";
$_LANG["cnrxusnexuscategoryc12"] = "[C12] Permanent ingezetene van de VS";
$_LANG["cnrxusnexuscategoryc21"] = "[C21] Amerikaanse organisatie";
$_LANG["cnrxusnexuscategoryc31"] = "[C31] Buitenlandse entiteit met activiteiten in de VS";
$_LANG["cnrxusnexuscategoryc32"] = "[C32] Buitenlandse entiteit met kantoor in de VS";
$_LANG["cnrxusnexuscategorydescr"] = "Classificatie van de entiteit die de aanvraag indient.<br/>Let op: Amerikaanse bezittingen en territoria zijn ook inbegrepen.";
$_LANG["cnrxusnexusvalidator"] = "US Nexus, land";
$_LANG["cnrxusnexusvalidatordescr"] = "Vul de ISO 2-letterige landcode van de registrant in (alleen vereist indien Nexus-categorie C31 of C32 is)";

// ----------------------------------------------------------------------
// ------------------ .XXX Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxxxxcommunityid"] = "Community-lidmaatschaps-ID";
$_LANG["cnrxxxxcommunityiddescr"] = ".XXX gesponsorde community-lidmaatschaps-ID";
$_LANG["cnrxxxxdefensive"] = "Defensieve registratie<br/>(Niet-resolverende domein)";
$_LANG["cnrxxxxdefensive0"] = $_LANG["cnr0"];
$_LANG["cnrxxxxdefensive1"] = $_LANG["cnr1"];
$_LANG["cnrxxxxdefensivedescr"] = implode("", [
    "Ik bevestig dat dit domein een defensieve registratie betreft. ",
    "Defensieve registratie verwijst naar het registreren van domeinnamen, ",
    "vaak over meerdere TLD's en in verschillende grammaticale vormen, ",
    "met als primair doel het beschermen van intellectueel eigendom of merken tegen misbruik, ",
    "zoals cybersquatting. Het wordt gedefinieerd als een registratie die niet uniek is, niet resolveert, ",
    "verkeer terugstuurt naar een kernregistratie of geen unieke content bevat.<br/>",
    "Let op: Indien niet geselecteerd, wordt het domein als defensieve registratie beschouwd."
]);

// #########################################################################
// #########################################################################
// # Add reusable translations for ALL PROVIDERS                           #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ----------------------- DNSSEC MANAGEMENT ----------------------------
// ----------------------------------------------------------------------
$_LANG["cnicdnssecmanagement"] = "DNSSEC beheer";

// Statusmeldingen
$_LANG["dnssecautomaticupdatesuccessmsg"] = "DNSSEC is voor uw domein <span style=\"color:green;font-weight:bold;\">geactiveerd</span>.<br> De DNSSEC-records zijn geïmporteerd uit uw DNS-zone en bij uw domeinregistrar bijgewerkt.<br><br><span style=\"color:#007bff;\">Voor uw veiligheid helpt DNSSEC uw domein te beschermen tegen bepaalde soorten aanvallen door DNS-antwoorden te valideren.</span>";
$_LANG["dnssecautoenable"] = "DNSSEC inschakelen en DNSSEC-records automatisch uit de DNS-zone importeren";
$_LANG["dnssecsyncrecords"] = "DNSSEC-records synchroniseren vanuit de DNS-zone";

// Beheer van records
$_LANG["dnssecaddnewdskey"] = "Nieuwe DS-sleutel toevoegen";
$_LANG["dnssecaddnewkeyrecord"] = "Nieuw sleutelrecord toevoegen";

// Modal-Dialog
$_LANG["dnssecconfirmdisable"] = "Weet u zeker dat u DNSSEC voor dit domein wilt uitschakelen? Deze actie kan de domeinresolutie beïnvloeden.";
$_LANG["dnssecmodaltitle"] = "DNSSEC uitschakelen";
$_LANG["dnssecmodalcancel"] = "Annuleren";
$_LANG["dnssecmodaldisable"] = "DNSSEC uitschakelen";
