<?php

// #########################################################################
// #########################################################################
// # Add translations for CNR registrar module additional domain fields    #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ------------------ .DK Checkout Page ---------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrdkcheckoutheading"] = "Conditions générales des noms de domaine .dk";
$_LANG["cnrdkcheckoutintro"] = "Pour enregistrer un nom de domaine .dk, vous devez conclure un accord avec Punktum.dk A/S. Punktum dk est l'administrateur de tous les noms de domaine .dk.";
$_LANG["cnrdkcheckoutdomains"] = "Noms de domaine :";
$_LANG["cnrdkcheckoutregistrant"] = "Titulaire :";
$_LANG["cnrdkcheckoutregistrantaddress"] = "Voir ci-dessus";
$_LANG["cnrdkcheckoutadmin"] = "Administrateur du domaine :";
$_LANG["cnrdkcheckoutadminaddress"] = "Punktum dk A/S<br/>Ørestads Boulevard 108, 11e étage<br/>DK-2300 Copenhague S";
$_LANG["cnrdkcheckouttac"] = implode("<br/><br/>", [
    "Je consens par la présente à conclure un contrat sur le droit d'utiliser le nom de domaine .dk spécifié conformément aux conditions applicables. Cela signifie notamment que je veillerai à ce que mes coordonnées en tant que titulaire soient exactes en tout temps. Je procéderai à la vérification de mon identité par Punktum dk A/S sur demande.",
    "Mon droit d'utiliser le nom de domaine .dk spécifié peut être transféré, suspendu, supprimé ou bloqué conformément aux conditions définies dans les conditions d'utilisation de Punktum dk A/S.",
    "Conformément à l'article 18 (2) (13) de la loi danoise sur les contrats de consommation, je renonce au droit de me rétracter du contrat concernant le droit d'utiliser le nom de domaine .dk spécifié.",
    "Je donne mon consentement à Punktum dk A/S, en tant qu'administrateur de domaine, pour utiliser mes données personnelles conformément à sa politique de confidentialité.",
    "Je consens à payer à ce fournisseur les frais pour la première période d'enregistrement du nom de domaine .dk spécifié, et que le paiement des périodes d'enregistrement suivantes dépend de mon choix d'arrangement de gestion, cf. section 2.1 des conditions générales de Punktum dk A/S."
]);
$_LANG["cnrdkcheckouttacurl"] = "https://www.punktum.dk/en/articles/terms-and-conditions-for-the-right-of-use-to-a-dk-domain-name";
$_LANG["cnrdkcheckouttacurltext"] = "Conditions générales pour le droit d'utiliser un nom de domaine .dk";
$_LANG["cnrdkcheckoutpolicyurl"] = "https://www.punktum.dk/en/articles/privacy-policy";
$_LANG["cnrdkcheckoutpolicyurltext"] = "Politique de confidentialité";
$_LANG["cnrdkcheckoutabouturl"] = "https://www.punktum.dk/en/about-us";
$_LANG["cnrdkcheckoutabouturltext"] = "À propos de Punktum dk A/S";
$_LANG["cnrdkcheckouttacagree"] = "Oui, j'accepte l'accord utilisateur avec Punktum dk A/S.";

// ----------------------------------------------------------------------
// ------------------ Common CNR Translations ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrchoose"] = "Veuillez choisir";
$_LANG["cnroptional"] = "optionnel";
$_LANG["cnr1"] = "Oui";
$_LANG["cnr0"] = "Non";
$_LANG["cnrconsentforpublishing"] = "Titulaire, Consentement pour la Publication";
// .abogado, .aero, .attorney, .bank, .broker, .dentist, .forex, .insurance, .lotto, .law, .lawyer, .markets, .trading
$_LANG["cnrxallocationtoken"] = "Jeton d'allocation du registre";
$_LANG["cnrxallocationtokendescr"] = "Requis uniquement pour les domaines Premium. Émis par le fournisseur de registre. Faites-nous savoir si vous avez besoin d'aide.";
// .app, .page, .dev, .new, .day, .channel, .boo, .foo, .zip, .mov, .nexus, .dad, .phd, .prof, .esq, .rsvp, .meme, .ing, .new
$_LANG["cnrxacceptsslrequirement"] = "Exigences SSL";
$_LANG["cnrxacceptsslrequirementdescr"] = "Je confirme que je comprends et accepte les exigences pour HTTPS / un certificat SSL. Ce TLD est un domaine plus sécurisé, ce qui signifie que HTTPS est requis pour tous les sites Web. Vous pouvez acheter votre nom de domaine maintenant, mais pour qu'il fonctionne correctement dans les navigateurs, vous devez configurer HTTPS basé sur un certificat SSL.";
$_LANG["cnrxacceptsslrequirement0"] = $_LANG["cnr0"];
$_LANG["cnrxacceptsslrequirement1"] = $_LANG["cnr1"];
// .attorney, .dentist, .lawyer
$_LANG["cnrxunitedtldregulatorydata"] = "Informations sur l'organisme de réglementation";
$_LANG["cnrxunitedtldregulatorydatadescr"] = "Extension contenant des informations sur l'autorité d'approbation/l'autorité de contrôle/l'organisme de réglementation";
// .barcelona, .cat, .madrid, .scot, .sport, .swiss
$_LANG["cnrxintendeduse"] = "Utilisation prévue";
$_LANG["cnrxintendedusedescr"] = implode("<br/>", [
    "Déclaration d'utilisation prévue pour le nom de domaine. Le cas échéant, veuillez inclure une référence explicite au droit revendiqué par le demandeur sur le nom (si ce n'est pas le nom commercial du demandeur).",
    "Par exemple, si le nom de domaine correspond à une marque déposée, le numéro de la marque doit être fourni (max. 256 caractères)."
]);
// .mk
$_LANG["cnrxcompanyvatid"] = "Titulaire, Numéro de TVA de l'entreprise";
// $_LANG["cnrxcompanyvatiddescr"] = "";
// .nu, .se
$_LANG["cnrxrequestauthcode"] = "Demander un nouveau code EPP";
$_LANG["cnrxrequestauthcode0"] = $_LANG["cnr0"];
$_LANG["cnrxrequestauthcode1"] = $_LANG["cnr1"];
$_LANG["cnrxrequestauthcodedescr"] = "Si vous souhaitez transférer le domaine vers un autre registrar, vous avez besoin du code d'authentification. Nous l'enverrons à l'adresse e-mail du propriétaire du domaine.";

// NOTE: The following translations are labeled as boilerplate and should
// be used as a template for other languages. English texts are returned
// by default from the CNR Backend System. If you want to override these
// default texts, please consider a language override file in WHMCS using
// the below translation keys.
// We added some translations to override the API defaults which sometimes
// suck.

// ----------------------------------------------------------------------
// ------------------ DOMAIN DETAILS (and sub pages) --------------------
// ----------------------------------------------------------------------
$_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] = (
    "<small>Nous avons détecté des problèmes avec les informations de contact de votre domaine qui nécessitent votre attention. Pour résoudre ceci :<br/><br/><ol>" .
    "<li>Basculez vers l'espace client (les champs supplémentaires y sont également listés, le cas échéant)</li>" .
    "<li>Accédez à la page <b>Informations de Contact</b> de ce domaine</li>" .
    "<li>Effectuez les corrections nécessaires</li>" .
    "<li>Complétez le processus de vérification juste après, si applicable</li></ol></small>"
 );
$_LANG["cnrdomaincontactvalidationerrorsummary"] = (
    "<small>Nous avons détecté des problèmes avec les informations de contact de votre domaine qui nécessitent votre attention. Pour résoudre ceci :<br/><br/><ol>" .
    "<li>Accédez à la page <b><a href=\"clientarea.php?action=domaincontacts&domainid=:domainid\">Informations de Contact</a></b> et vérifiez vos données</li>" .
    "<li>Effectuez les corrections nécessaires</li>" .
    "<li>Complétez le processus de vérification juste après, si applicable</li></ol></small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspensionadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Veuillez terminer ces étapes avant le <b>:suspensiondate</b> pour éviter la suspension de votre domaine.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspension"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Veuillez terminer ces étapes avant le <b>:suspensiondate</b> pour éviter la suspension de votre domaine.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspendedadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>Votre domaine a été suspendu. Veuillez terminer ces étapes pour réactiver votre domaine.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspended"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>Votre domaine a été suspendu. Veuillez terminer ces étapes pour réactiver votre domaine.</small>"
);

// ----------------------------------------------------------------------
// ------------------ .AERO Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaeroensauthid"] = "ID d'adhésion";
$_LANG["cnrxaeroensauthiddescr"] = "L'ID d'adhésion .AERO est nécessaire pour enregistrer un domaine dans l'aviation. Vous pouvez en faire la demande <a style=\"text-decoration:underline\" href=\"https://information.aero/node/add/request-aero-id\" target=\"_blank\">ici</a>.";
$_LANG["cnrxaeroensauthkey"] = "Mot de passe d'adhésion";
$_LANG["cnrxaeroensauthkeydescr"] = "Le mot de passe/code d'authentification respectif fourni par le site web ci-dessus en même temps que l'ID d'adhésion .AERO.";

// ----------------------------------------------------------------------
// ------------------ .AU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaudomainrelation"] = "Relation";
$_LANG["cnrxaudomainrelation1"] = "Le nom de domaine de deuxième niveau est une correspondance exacte, un acronyme ou une abréviation du nom de l'entreprise ou du nom commercial, du nom de l'organisation ou de l'association, ou de la marque déposée.";
$_LANG["cnrxaudomainrelation2"] = "Le nom de domaine de deuxième niveau est étroitement et substantiellement lié à l'organisation ou aux activités entreprises par l'organisation.";
$_LANG["cnrxaudomainrelationdescr"] = "Cela indique la relation entre le type d'éligibilité (par exemple, nom commercial) et le nom de domaine.";
$_LANG["cnrxaudomainrelationtype"] = "Type de Relation";
$_LANG["cnrxaudomainrelationtypecompany"] = "Entreprise";
$_LANG["cnrxaudomainrelationtyperegisteredbusiness"] = "Entreprise enregistrée";
$_LANG["cnrxaudomainrelationtypesoletrader"] = "Entrepreneur individuel";
$_LANG["cnrxaudomainrelationtypepartnership"] = "Partenariat";
$_LANG["cnrxaudomainrelationtypetrademarkowner"] = "Propriétaire de marque";
$_LANG["cnrxaudomainrelationtypependingtmowner"] = "Propriétaire de marque en attente";
$_LANG["cnrxaudomainrelationtypecitizenresident"] = "Citoyen / Résident"; // .id.au only
$_LANG["cnrxaudomainrelationtypeincorporatedassociation"] = "Association incorporée";
$_LANG["cnrxaudomainrelationtypeclub"] = "Club";
$_LANG["cnrxaudomainrelationtypenonprofitorganisation"] = "Organisation à but non lucratif";
$_LANG["cnrxaudomainrelationtypecharity"] = "Charité";
$_LANG["cnrxaudomainrelationtypetradeunion"] = "Syndicat";
$_LANG["cnrxaudomainrelationtypeindustrybody"] = "Organisme de l'industrie";
$_LANG["cnrxaudomainrelationtypecommercialstatutorybody"] = "Organisme statutaire commercial";
$_LANG["cnrxaudomainrelationtypepoliticalparty"] = "Parti politique";
$_LANG["cnrxaudomainrelationtypeother"] = "Autre";
$_LANG["cnrxaudomainrelationtypereligiouschurchgroup"] = "Groupe religieux / Église";
$_LANG["cnrxaudomainrelationtypehighereducationinstitution"] = "Établissement d'enseignement supérieur";
$_LANG["cnrxaudomainrelationtyperesearchorganisation"] = "Organisation de recherche";
$_LANG["cnrxaudomainrelationtypegovernmentschool"] = "École gouvernementale";
$_LANG["cnrxaudomainrelationtypechildcarecentre"] = "Centre de garde d'enfants";
$_LANG["cnrxaudomainrelationtypepreschool"] = "École maternelle";
$_LANG["cnrxaudomainrelationtypenationalbody"] = "Organisme national";
$_LANG["cnrxaudomainrelationtypetrainingorganisation"] = "Organisation de formation";
$_LANG["cnrxaudomainrelationtypenongovernmentschool"] = "École non gouvernementale";
$_LANG["cnrxaudomainrelationtypeunincorporatedassociation"] = "Association non incorporée";
$_LANG["cnrxaudomainrelationtypeindustryorganisation"] = "Organisation de l'industrie";
$_LANG["cnrxaudomainrelationtyperegistrablebody"] = "Organisme enregistrable";
$_LANG["cnrxaudomainrelationtypeindigenouscorporation"] = "Corporation autochtone";
$_LANG["cnrxaudomainrelationtyperegisteredorganisation"] = "Organisation enregistrée";
$_LANG["cnrxaudomainrelationtypetrust"] = "Fiducie";
$_LANG["cnrxaudomainrelationtypeeducationalinstitution"] = "Établissement éducatif";
$_LANG["cnrxaudomainrelationtypecommonwealthentity"] = "Entité du Commonwealth";
$_LANG["cnrxaudomainrelationtypestatutorybody"] = "Organisme statutaire";
$_LANG["cnrxaudomainrelationtypetradingcooperative"] = "Coopérative commerciale";
$_LANG["cnrxaudomainrelationtypecompanylimitedbyguarantee"] = "Société à responsabilité limitée par garantie";
$_LANG["cnrxaudomainrelationtypenondistributingcooperative"] = "Coopérative non distributive";
$_LANG["cnrxaudomainrelationtypenontradingcooperative"] = "Coopérative non commerciale";
$_LANG["cnrxaudomainrelationtypecharitabletrust"] = "Fiducie caritative";
$_LANG["cnrxaudomainrelationtypepublicprivateancillaryfund"] = "Fonds auxiliaire public / privé";
$_LANG["cnrxaudomainrelationtypepeakstateterritorybody"] = "Organisme de pointe de l'État / du Territoire";
$_LANG["cnrxaudomainrelationtypenotforprofitcommunitygroup"] = "Groupe communautaire à but non lucratif";
$_LANG["cnrxaudomainrelationtypeeducationandcareserviceschildcare"] = "Services d'éducation et de garde d'enfants";
$_LANG["cnrxaudomainrelationtypegovernmentbody"] = "Organisme gouvernemental";
$_LANG["cnrxaudomainrelationtypeproviderofnonaccreditedtraining"] = "Fournisseur de formation non accréditée";
$_LANG["cnrxaudomainrelationtypedescr"] = "Précisez ce qui rend le titulaire éligible pour enregistrer le nom de domaine";
$_LANG["cnrxauownerorganization"] = "Titulaire, Organisation";
$_LANG["cnrxauownerorganizationdescr"] = "Le nom de l'organisation (titulaire)";
$_LANG["cnrxauidwarranty"] = "Titulaire,<br>est citoyen ou résident australien";
$_LANG["cnrxauidwarranty0"] = $_LANG["cnr0"];
$_LANG["cnrxauidwarranty1"] = $_LANG["cnr1"];
$_LANG["cnrxauidwarrantydescr"] = "Le titulaire d'un domaine .id.au doit garantir qu'il est résident ou citoyen australien";
$_LANG["cnrxaueligibilityname"] = "Nom d'éligibilité";
$_LANG["cnrxaueligibilitynamedescr"] = "Le nom du type d'éligibilité (par exemple, nom commercial)";
$_LANG["cnrxaudomainidnumber"] = "Titulaire, Numéro d'identification";
$_LANG["cnrxaudomainidnumberdescr"] = "";
$_LANG["cnrxaudomainidtype"] = "Titulaire, Type d'identification";
// $_LANG["cnrxaudomainidtypetm"] = "TM";
// $_LANG["cnrxaudomainidtypeabn"] = "ABN";
// $_LANG["cnrxaudomainidtypeacn"] = "ACN";
// $_LANG["cnrxaudomainidtypeother"] = "Autre";
// $_LANG["cnrxaudomainidtypeact"] = "ACT";
// $_LANG["cnrxaudomainidtypensw"] = "NSW";
// $_LANG["cnrxaudomainidtypent"] = "NT";
// $_LANG["cnrxaudomainidtypeqld"] = "QLD";
// $_LANG["cnrxaudomainidtypesa"] = "SA";
// $_LANG["cnrxaudomainidtypetas"] = "TAS";
// $_LANG["cnrxaudomainidtypevic"] = "VIC";
// $_LANG["cnrxaudomainidtypewa"] = "WA";
// $_LANG["cnrxaudomainidtypeprivate"] = "Privé";
$_LANG["cnrxaudomainidtypedescr"] = "";
$_LANG["cnrxaueligibilityidnumber"] = "Éligibilité, Numéro d'identification";
$_LANG["cnrxaueligibilityidnumberdescr"] = "";
$_LANG["cnrxaueligibilityidtype"] = "Éligibilité, Type d'identification";
$_LANG["cnrxaueligibilityidtypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .CA Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcalegaltype"] = "Titulaire, Type juridique";
$_LANG["cnrxcalegaltypeabo"] = "Peuples autochtones du Canada";
$_LANG["cnrxcalegaltypeass"] = "Association non constituée en société canadienne";
$_LANG["cnrxcalegaltypecco"] = "Société (Canada ou province ou territoire canadien)";
$_LANG["cnrxcalegaltypecct"] = "Citoyen canadien";
$_LANG["cnrxcalegaltypeedu"] = "Établissement d'enseignement canadien";
$_LANG["cnrxcalegaltypegov"] = "Gouvernement ou entité gouvernementale au Canada";
$_LANG["cnrxcalegaltypehop"] = "Hôpital canadien";
$_LANG["cnrxcalegaltypeinb"] = "Bande indienne reconnue par la Loi sur les Indiens du Canada";
$_LANG["cnrxcalegaltypelam"] = "Bibliothèque, Archive ou Musée canadien";
$_LANG["cnrxcalegaltypelgr"] = "Représentant légal d'un citoyen canadien ou résident permanent";
$_LANG["cnrxcalegaltypemaj"] = "Sa Majesté la Reine";
$_LANG["cnrxcalegaltypeomk"] = "Marque officielle enregistrée au Canada";
$_LANG["cnrxcalegaltypeplt"] = "Parti politique canadien";
$_LANG["cnrxcalegaltypeprt"] = "Partenariat enregistré au Canada";
$_LANG["cnrxcalegaltyperes"] = "Résident permanent du Canada";
$_LANG["cnrxcalegaltypetdm"] = "Marque déposée au Canada (par un propriétaire non canadien)";
$_LANG["cnrxcalegaltypetrd"] = "Syndicat canadien";
$_LANG["cnrxcalegaltypetrs"] = "Fiducie établie au Canada";
// $_LANG["cnrxcalegaltypedescr"] = "";
$_LANG["cnrxcatrademark"] = "Est une marque déposée";
$_LANG["cnrxcatrademark0"] = $_LANG["cnr0"];
$_LANG["cnrxcatrademark1"] = $_LANG["cnr1"];
$_LANG["cnrxcatrademarkdescr"] = "Indique si le domaine est une marque déposée ou non.";

// ----------------------------------------------------------------------
// ------------------ .COM.BR Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxbrregisternumber"] = "Titulaire, Identifiant Légal Brésilien";
$_LANG["cnrxbrregisternumberdescr"] = "Le numéro d'enregistrement de l'entreprise brésilienne (CNPJ) ou le numéro d'enregistrement individuel brésilien (CPF).";

// ----------------------------------------------------------------------
// ------------------ .CN Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcnownertype"] = "Titulaire, Type";
$_LANG["cnrxcnownertypei"] = "Individu";
$_LANG["cnrxcnownertypee"] = "Entreprise";
$_LANG["cnrxcnownertypedescr"] = "";
$_LANG["cnrxcnowneridtype"] = "Titulaire, Type d'identification";
$_LANG["cnrxcnowneridtypesfz"] = "SFZ (ID) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypehz"] = "HZ (Passeport) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypegajmtx"] = "GAJMTX (Permis de sortie et d'entrée pour voyager vers et de Hong Kong et Macao) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypetwjmtx"] = "TWJMTX (Passeports des résidents de Taiwan pour entrer ou quitter le continent) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypewjlsfz"] = "WJLSFZ (Carte d'identité de résident permanent étranger) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypegajzz"] = "GAJZZ (Permis de résidence pour les résidents de Hong Kong / Macao) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypetwjzz"] = "TWJZZ (Permis de résidence pour les résidents de Taiwan) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypejgz"] = "JGZ (Carte d'identité d'officier) - Type de titulaire est Individu";
$_LANG["cnrxcnowneridtypeqt"] = "QT (Autres) - Type de titulaire est Individu ou Entreprise";
$_LANG["cnrxcnowneridtypeorg"] = "ORG (Certificat de code d'organisation) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypeyyzz"] = "YYZZ (Licence commerciale) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypetydm"] = "TYDM (Certificat pour le Code Uniforme du Crédit Social) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypebddm"] = "BDDM (Désignation du code militaire) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypejddwfw"] = "JDDWFW (Licence de service externe payé par militaire) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypesydwfr"] = "SYDWFR (Certificat de personne morale d'établissement public) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypewgczjg"] = "WGCZJG (Formulaire d'enregistrement des bureaux de représentation résidents des entreprises étrangères) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypeshttfr"] = "SHTTFR (Certificat d'enregistrement de personne morale d'organisation sociale) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypezjcs"] = "ZJCS (Certificat d'enregistrement de site d'activités religieuses) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypembfqy"] = "MBFQY (Certificat d'enregistrement d'entité privée non-entreprise) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypejjhfr"] = "JJHFR (Certificat d'enregistrement de personne morale de fondation) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypelszy"] = "LSZY (Licence de pratique de cabinet d'avocats) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypewgzhwh"] = "WGZHWH (Certificat d'enregistrement de centre culturel étranger en Chine) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypewlczzg"] = "WLCZJG (Certificat d'enregistrement des représentations résidentes des services touristiques d'un gouvernement étranger) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypesfjd"] = "SFJD (Licence d'expertise judiciaire) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypejwjg"] = "JWJG (Certificat d'organisation à l'étranger) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypeshfwjg"] = "SHFWJG (Certificat d'enregistrement d'agence de service social) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypembxxbx"] = "MBXXBX (Permis d'école privée) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypeyljgzy"] = "YLJGZY (Licence de pratique d'établissement médical) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypegzjgzy"] = "GZJGZY (Licence de notaire) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypebjwsxx"] = "BJWSXX (Permis de l'école de Beijing pour les enfants du personnel diplomatique étranger en Chine) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypeqttyzm"] = "QTTYDM (Autres - Certificat pour le Code Uniforme du Crédit Social) - Type de titulaire est Entreprise";
$_LANG["cnrxcnowneridtypedescr"] = "Type d'identité de la carte d'identité";
$_LANG["cnrxcnowneridnumber"] = "Titulaire, Numéro d'identification";
$_LANG["cnrxcnowneridnumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COOP Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcoopeligibility"] = "Conditions d'éligibilité";
$_LANG["cnrxcoopeligibilitydescr"] = "Acceptez que mon organisation remplisse au moins une des conditions d'éligibilité .COOP. Lisez <a style=\"text-decoration:underline\" href=\"https://identity.coop/coop-policies-and-agreements/\" target=\"_blank\">ici</a>.";
$_LANG["cnrxcoopeligibility0"] = $_LANG["cnr0"];
$_LANG["cnrxcoopeligibility1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .DE Fields ----------------------------------------
// ----------------------------------------------------------------------
//$_LANG["cnrxdensentry0"] = "";
$_LANG["cnrxdensentry0descr"] = implode(" ", [
    "Permet l'utilisation de nsentrys au lieu de serveurs de noms pour les domaines .de;",
    "Les enregistrements NS vous permettent de configurer des sous-domaines avec des serveurs de noms alternatifs.",
    "<a target=\"_blank\" href=\"https://www.denic.de/en/domains/de-domains/registration/nameserver-and-nsentry-data/\" style=\"text-decoration:underline\">Lire en détail</a>."
]);
//$_LANG["cnrxdensentry1"] = "";
$_LANG["cnrxdensentry1descr"] = "voir ci-dessus";
//$_LANG["cnrxdensentry2"] = "";
$_LANG["cnrxdensentry2descr"] = "voir ci-dessus";
//$_LANG["cnrxdensentry3"] = "";
$_LANG["cnrxdensentry3descr"] = "voir ci-dessus";
//$_LANG["cnrxdensentry4"] = "";
$_LANG["cnrxdensentry4descr"] = "voir ci-dessus";
//$_LANG["cnrxdegeneralrequest"] = "";
//$_LANG["cnrxdegeneralrequestdescr"] = "";
//$_LANG["cnrxdeabusecontact"] = "";
//$_LANG["cnrxdeabusecontactdescr "] = "";

// ----------------------------------------------------------------------
// ------------------ .DK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdkusertype"] = "Titulaire, Type";
$_LANG["cnrxdkusertypeperson"] = "Personne";
$_LANG["cnrxdkusertypecompany"] = "Entreprise";
$_LANG["cnrxdkusertypeassociation"] = "Association";
$_LANG["cnrxdkusertypepuborg"] = "Organisation Publique";
// $_LANG["cnrxdkusertypedescr"] = "";
$_LANG["cnrxdkuseridnumber"] = "Titulaire, Numéro d'Identification";
$_LANG["cnrxdkuseridnumberdescr"] = implode("", [
    "Numéro d'identification du contact titulaire. Cela peut être <i>EAN, CVR ou P number.</i> ",
    "Le <i>numéro CVR</i> est utilisé pour identifier l'organisation, et le <i>numéro EAN</i> garantit ",
    "que les documents liés à la facturation électronique sont envoyés au bon compte. ",
    "Le <i>numéro P</i> est un identifiant de succursale attribué par le Registre Central des Entreprises Danoises pour ",
    "lier les sites physiques à une organisation."
]);

// ----------------------------------------------------------------------
// ------------------ .ES Fields ----------------------------------------
// ----------------------------------------------------------------------
$types = [
    1 => "Individu",
    39 => "Groupement d'intérêt économique",
    47 => "Association",
    59 => "Association sportive",
    68 => "Association professionnelle",
    124 => "Caisse d'épargne",
    150 => "Communauté de biens",
    152 => "Communauté de propriétaires",
    164 => "Ordre ou institution religieuse",
    181 => "Consulat",
    197 => "Association de droit public",
    203 => "Ambassade",
    229 => "Autorité locale",
    269 => "Fédération sportive",
    286 => "Fondation",
    365 => "Mutuelle d'assurance",
    434 => "Organisme gouvernemental régional",
    436 => "Organisme gouvernemental central",
    439 => "Parti politique",
    476 => "Syndicat",
    510 => "Partenariat agricole",
    524 => "Société anonyme",
    525 => "Association sportive",
    554 => "Société civile",
    560 => "Société en nom collectif",
    562 => "Société en nom collectif et en commandite",
    566 => "Coopérative",
    608 => "Entreprise détenue par les employés",
    612 => "Société à responsabilité limitée",
    713 => "Bureau espagnol",
    717 => "Alliance temporaire d'entreprises",
    744 => "Société anonyme détenue par les employés",
    745 => "Entité publique régionale",
    746 => "Entité publique nationale",
    747 => "Entité publique locale",
    877 => "Autres",
    878 => "Conseil de surveillance de l'appellation d'origine",
    879 => "Entité gérant les espaces naturels"
];
$idtypes = [
    0 => "Autre (pour les contacts hors Espagne)",
    1 => "DNI/NIF (pour les contacts espagnols)",
    2 => "Obsolète, utilisez l'option suivante.",
    3 => "NIE (pour les contacts espagnols)",
    4 => "TVA (numéro fiscal) - valable uniquement pour les entités juridiques non espagnoles"
];
$idtypesdescr = implode("<br/>", [
    "DNI = &quot;Documento Nacional de Identidad&quot;",
    "NIF = &quot;Número de Identificación Fiscal&quot;",
    "NIE = &quot;Número de Identificación de Extranjero&quot;. C'est l'équivalent d'un NIF espagnol, mais délivré par les autorités espagnoles aux étrangers qui prévoient de rester plus de 3 mois en Espagne."
]);
$idnodescr = "Le numéro d'identification de ce contact. Pour les contacts espagnols, il s'agit du numéro DNI/NIF/NIE - le numéro de carte d'identité ou de passeport sinon.";

$_LANG["cnrxesownertipoidentificacion"] = "Titulaire, Type d'identification";
$_LANG["cnrxesadmintipoidentificacion"] = "Admin, Type d'identification";
$_LANG["cnrxestechtipoidentificacion"] = "Tech, Type d'identification";
$_LANG["cnrxesbillingtipoidentificacion"] = "Facturation, Type d'identification";

foreach ($idtypes as $key => $value) {
    $_LANG["cnrxesownertipoidentificacion$key"] = $value;
    $_LANG["cnrxesadmintipoidentificacion$key"] = $value;
    $_LANG["cnrxestechtipoidentificacion$key"] = $value;
    $_LANG["cnrxesbillingtipoidentificacion$key"] = $value;
}

$_LANG["cnrxesownertipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesadmintipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxestechtipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesbillingtipoidentificaciondescr"] = $idtypesdescr;

$_LANG["cnrxesowneridentificacion"] = "Titulaire, Numéro d'identification";
$_LANG["cnrxesadminidentificacion"] = "Admin, Numéro d'identification";
$_LANG["cnrxestechidentificacion"] = "Tech, Numéro d'identification";
$_LANG["cnrxesbillingidentificacion"] = "Facturation, Numéro d'identification";

$_LANG["cnrxesowneridentificaciondescr"] = $idnodescr;
$_LANG["cnrxesadminidentificaciondescr"] = $idnodescr;
$_LANG["cnrxestechidentificaciondescr"] = $idnodescr;
$_LANG["cnrxesbillingidentificaciondescr"] = $idnodescr;

$_LANG["cnrxesownerlegalform"] = "Titulaire, Forme juridique";
$_LANG["cnrxesadminlegalform"] = "Admin, Forme juridique";
$_LANG["cnrxestechlegalform"] = "Tech, Forme juridique";
$_LANG["cnrxesbillinglegalform"] = "Facturation, Forme juridique";

foreach ($types as $key => $value) {
    $_LANG["cnrxesownerlegalform$key"] = $value;
    $_LANG["cnrxesadminlegalform$key"] = $value;
    $_LANG["cnrxestechlegalform$key"] = $value;
    $_LANG["cnrxesbillinglegalform$key"] = $value;
}

$_LANG["cnrxesownerlegalformdescr"] = "";
$_LANG["cnrxesadminlegalformdescr"] = "";
$_LANG["cnrxestechlegalformdescr"] = "";
$_LANG["cnrxesbillinglegalformdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .EU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxeuregistrantlang"] = "Titulaire, Langue";
$_LANG["cnrxeuregistrantcitizenship"] = "Titulaire, Citoyenneté";
$_LANG["cnrxeuregistrantlangdescr"] = "Langue à utiliser pour la communication avec le fournisseur de TLD (Par défaut = Anglais)";
$_LANG["cnrxeuregistrantcitizenshipdescr"] = "Les particuliers ayant la citoyenneté européenne qui ne résident pas dans l'UE peuvent enregistrer des domaines .eu en utilisant ce paramètre.";

// ----------------------------------------------------------------------
// ------------------ .FI Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxficompanyregid"] = "Titulaire, Numéro d'Entreprise ou d'Enregistrement";
$_LANG["cnrxficompanyregiddescr"] = "Entité commerciale locale (enregistrée au registre du commerce finlandais ou une société au sein de la République finlandaise)<br/>(requis pour les entités non finlandaises)";
$_LANG["cnrxfipersonalid"] = "Titulaire, Numéro d'Identité Personnel";
$_LANG["cnrxfipersonaliddescr"] = "Numéro d'identité personnel finlandais<br/>(requis pour les particuliers non finlandais)";
$_LANG["cnrxfibirthdate"] = "Titulaire, Date de Naissance";
$_LANG["cnrxfibirthdatedescr"] = "Date de naissance (AAAA-MM-JJ)<br/>(requis pour les particuliers non finlandais)";
$_LANG["cnrxficontacttype"] = "Titulaire, Type de Contact";
$_LANG["cnrxficontacttype0"] = "Personne Privée";
$_LANG["cnrxficontacttype1"] = "Entreprise";
$_LANG["cnrxficontacttype2"] = "Société";
$_LANG["cnrxficontacttype3"] = "Institution";
$_LANG["cnrxficontacttype4"] = "Parti Politique";
$_LANG["cnrxficontacttype5"] = "Commune";
$_LANG["cnrxficontacttype6"] = "Gouvernement";
$_LANG["cnrxficontacttype7"] = "Communauté Publique";
$_LANG["cnrxficontacttypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .GAY Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxgayacceptrequirements"] = "Accepter les exigences";
$_LANG["cnrxgayacceptrequirements0"] = $_LANG["cnr0"];
$_LANG["cnrxgayacceptrequirements1"] = $_LANG["cnr1"];
$_LANG["cnrxgayacceptrequirementsdescr"] = "Je confirme que le domaine NE SERA PAS utilisé pour inciter à la violence, harceler, intimider ou tenir des propos haineux et NE SERA PAS utilisé par des groupes de haine reconnus. DotGay fait don de 20% de chaque nouveau domaine enregistré à ses partenaires, GLAAD et CenterLink.";

// ----------------------------------------------------------------------
// ------------------ .HK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxhkownerdocumenttype"] = "Titulaire, Type de Document";
$_LANG["cnrxhkownerdocumenttypehkid"] = "Individu: Numéro d'Identité de Hong Kong";
$_LANG["cnrxhkownerdocumenttypeothid"] = "Individu: Numéro d'Identité d'un autre pays";
$_LANG["cnrxhkownerdocumenttypepassno"] = "Individu: Numéro de Passeport";
$_LANG["cnrxhkownerdocumenttypebirthcert"] = "Individu: Certificat de Naissance";
$_LANG["cnrxhkownerdocumenttypeothidv"] = "Individu: Autre Document d'Identité";
$_LANG["cnrxhkownerdocumenttypebr"] = "Organisation: Certificat d'Enregistrement d'Entreprise";
$_LANG["cnrxhkownerdocumenttypeci"] = "Organisation: Certificat de Constitution";
$_LANG["cnrxhkownerdocumenttypecrs"] = "Organisation: Certificat d'Enregistrement d'École";
$_LANG["cnrxhkownerdocumenttypehksarg"] = "Organisation: Département du Gouvernement de Hong Kong";
$_LANG["cnrxhkownerdocumenttypehkordinance"] = "Organisation: Ordonnance de Hong Kong";
$_LANG["cnrxhkownerdocumenttypeothorg"] = "Organisation: Autre Document d'Organisation";
$_LANG["cnrxhkownerdocumenttypedescr"] = "";
$_LANG["cnrxhkownerdocumentnumber"] = "Titulaire, Numéro de Document";
$_LANG["cnrxhkownerdocumentnumberdescr"] = "";
$_LANG["cnrxhkownerdocumentorigincountry"] = "Titulaire, Pays d'Origine du Document";
$_LANG["cnrxhkownerdocumentorigincountrydescr"] = "Le pays où ce document a été délivré (veuillez fournir le code pays ISO à 2 caractères, par exemple DE ou US).";
$_LANG["cnrxhkownerotherdocumenttype"] = "Titulaire, Autre Type de Document";
$_LANG["cnrxhkownerotherdocumenttypedescr"] = "Requis si le type de document précédemment sélectionné est soit '" . $_LANG["cnrxhkownerdocumenttypeothidv"] . "' soit '" . $_LANG["cnrxhkownerdocumenttypeothorg"] . "'.";
$_LANG["cnrxhkdomaincategory"] = "Catégorie de Domaine";
$_LANG["cnrxhkdomaincategoryi"] = "Individu";
$_LANG["cnrxhkdomaincategoryo"] = "Organisation";
$_LANG["cnrxhkdomaincategorydescr"] = "Type Juridique de tous les Contacts de Domaine";
$_LANG["cnrxhkownerageover18"] = "Titulaire, Âge supérieur à 18 ans";
$_LANG["cnrxhkownerageover18no"] = $_LANG["cnr0"];
$_LANG["cnrxhkownerageover18yes"] = $_LANG["cnr1"];
$_LANG["cnrxhkownerageover18descr"] = "Je confirme que le Titulaire a au moins 18 ans (requis uniquement pour les Individus).";

// ----------------------------------------------------------------------
// ------------------ .IE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxiecontacttype"] = "Titulaire, Type de Contact";
$_LANG["cnrxiecontacttypecom"] = "Entreprise";
$_LANG["cnrxiecontacttypecha"] = "Charité";
$_LANG["cnrxiecontacttypeoth"] = "Autre";
$_LANG["cnrxiecontacttypedescr"] = "";
$_LANG["cnrxielanguage"] = "Titulaire, Langue";
$_LANG["cnrxielanguageen"] = "Anglais";
$_LANG["cnrxielanguagefr"] = "Français";
$_LANG["cnrxielanguagedescr"] = "Langue à utiliser pour la communication avec le fournisseur de TLD (Par défaut = Anglais)";
$_LANG["cnrxiecronumber"] = "Titulaire, Numéro CRO";
$_LANG["cnrxiecronumberdescr"] = "Le numéro du registre des entreprises (CRO)";
$_LANG["cnrxiesupportingnumber"] = "Titulaire, Numéro de Charité";
$_LANG["cnrxiesupportingnumberdescr"] = "Numéro de Charité / Numéro de Soutien";

// ----------------------------------------------------------------------
// ------------------ .IT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxitconsentforpublishing"] = $_LANG["cnrconsentforpublishing"];
$_LANG["cnrxitconsentforpublishing0"] = $_LANG["cnr0"];
$_LANG["cnrxitconsentforpublishing1"] = $_LANG["cnr1"];
$_LANG["cnrxitconsentforpublishingdescr"] = "Autoriser la publication des données personnelles des contacts. Refus uniquement possible si le type d’entité ci-dessous est 1.";
$_LANG["cnrxitentitytype"] = "Titulaire, Type d'entité";
$_LANG["cnrxitentitytype1"] = "[1] Personnes physiques italiennes et étrangères";
$_LANG["cnrxitentitytype2"] = "[2] Entreprises/entrepreneurs individuels";
$_LANG["cnrxitentitytype3"] = "[3] Travailleurs indépendants/professionnels";
$_LANG["cnrxitentitytype4"] = "[4] Organisations à but non lucratif";
$_LANG["cnrxitentitytype5"] = "[5] Organisations publiques";
$_LANG["cnrxitentitytype6"] = "[6] Autres sujets";
$_LANG["cnrxitentitytype7"] = "[7] Étrangers correspondant aux catégories 2-6";
$_LANG["cnrxitentitytypedescr"] = "Type d'entité pour identifier la typologie du titulaire.";
$_LANG["cnrxitpin"] = "Titulaire, Numéro fiscal";
//$_LANG["cnrxitpindescr"] = "";
$_LANG["cnrxitnationality"] = "Titulaire, Nationalité";
$_LANG["cnrxitnationalitydescr"] = "La nationalité du titulaire spécifiée par le code pays ISO à 2 caractères.";
//$_LANG["cnrxitsect3liability"] = "";
$_LANG["cnrxitsect3liabilitydescr"] = "";
$_LANG["cnrxitsect3liability0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect3liability1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect5personaldataforregistration"] = "";
$_LANG["cnrxitsect5personaldataforregistrationdescr"] = "";
$_LANG["cnrxitsect5personaldataforregistration0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect5personaldataforregistration1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect6personaldatafordiffusion"] = "";
$_LANG["cnrxitsect6personaldatafordiffusiondescr"] = "";
$_LANG["cnrxitsect6personaldatafordiffusion0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect6personaldatafordiffusion1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect7explicitacceptance"] = "";
$_LANG["cnrxitsect7explicitacceptancedescr"] = "";
$_LANG["cnrxitsect7explicitacceptance0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect7explicitacceptance1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .LV Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxlvownerregnr"] = "Titulaire, Numéro d'enregistrement";
$_LANG["cnrxlvownerregnrdescr"] = "Le numéro d'enregistrement du citoyen letton à utiliser pour le contact du titulaire (par exemple, numéro d'enregistrement de l'entreprise)";
$_LANG["cnrxlvadminregnr"] = "Admin, Numéro d'enregistrement";
$_LANG["cnrxlvadminregnrdescr"] = "Le numéro d'enregistrement du citoyen letton à utiliser pour le contact administratif (par exemple, numéro d'enregistrement de l'entreprise)";
$_LANG["cnrxlvvatnr"] = "Titulaire, Numéro de TVA";
$_LANG["cnrxlvvatnrdescr"] = "Le numéro de TVA du contact du titulaire (uniquement pour les entreprises).";

// ----------------------------------------------------------------------
// ------------------ .LT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxltcompanynumber"] = "Titulaire, Numéro d'Entreprise";
$_LANG["cnrxltcompanynumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .MY Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxmybusinessnumber"] = "Titulaire, Numéro d'Entreprise";
$_LANG["cnrxmybusinessnumberdescr"] = "Le numéro d'enregistrement de l'entreprise du titulaire (uniquement pour les entreprises)";
$_LANG["cnrxmyorganizationtype"] = "Titulaire, Type d'Organisation";
$_LANG["cnrxmyorganizationtypedescr"] = "Le type d'entreprise du titulaire (uniquement pour les entreprises)";
$_LANG["cnrxmyperidentity"] = "Titulaire, Numéro d'Identité Personnel";
$_LANG["cnrxmyperidentitydescr"] = "Le numéro d'identité personnel du titulaire (uniquement pour les particuliers)";
$_LANG["cnrxmyperdateofbirth"] = "Titulaire, Date de Naissance";
$_LANG["cnrxmyperdateofbirthdescr"] = "La date de naissance du titulaire (AAAA-MM-JJ, uniquement pour les particuliers)";
$_LANG["cnrxmyrace"] = "Titulaire, Ethnie";
$_LANG["cnrxmyracemalay"] = "Malais";
$_LANG["cnrxmyracechinese"] = "Chinois";
$_LANG["cnrxmyraceindian"] = "Indien";
$_LANG["cnrxmyraceothers"] = "Autres";
$_LANG["cnrxmyracedescr"] = "(uniquement pour les particuliers)";

// ----------------------------------------------------------------------
// ------------------ .NO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnoorganizationnumber"] = "Titulaire, Numéro d'Organisation";
$_LANG["cnrxnoorganizationnumberdescr"] = "Le numéro d'enregistrement norvégien délivré par le Registre central de coordination pour les entités juridiques.";
$_LANG["cnrxnopersonidentifier"] = "Identifiant de personne Norid";
$_LANG["cnrxnopersonidentifierdescr"] = "Identifiant personnel requis pour enregistrer un nom de domaine privé .PRIV.NO. Laissez vide sinon.";

// ----------------------------------------------------------------------
// ------------------ .NU Fields ----------------------------------------
// ----------------------------------------------------------------------
// see further .nu fields at the top of the file
$_LANG["cnrxnuiisidno"] = "Titulaire, Numéro d'identification";
$_LANG["cnrxnuiisidnodescr"] = "Numéro d'identification personnel, numéro d'identité de l'entreprise ou désignation d'enregistrement dans un registre gouvernemental. Pour les contacts situés en Suède, un numéro d'identification suédois valide est nécessaire (par exemple : 123456-1234).";
$_LANG["cnrxnuiisvatno"] = "Titulaire, Numéro de TVA";
$_LANG["cnrxnuiisvatnodescr"] = "Le numéro de TVA du titulaire (uniquement pour les entreprises)";

// ----------------------------------------------------------------------
// ------------------ .NYC Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnycextcontact"] = "Contact Externe NY";
$_LANG["cnrxnycextcontactadmin"] = "Contact Administratif";
$_LANG["cnrxnycextcontacttech"] = "Contact Technique";
$_LANG["cnrxnycextcontactbilling"] = "Contact Facturation";
$_LANG["cnrxnycextcontactowner"] = "Contact du Titulaire";
$_LANG["cnrxnycextcontactdescr"] = "Le contact spécifié doit avoir une adresse physique valide dans la ville de New York.";

// ----------------------------------------------------------------------
// ------------------ .PARIS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxafniccode"] = $_LANG["cnrxallocationtoken"];
$_LANG["cnrxafniccodedescr"] = $_LANG["cnrxallocationtokendescr"];

// ----------------------------------------------------------------------
// ------------------ .FR, .PM, .RE, .TF, .WF, .YT Fields ---------------
// ----------------------------------------------------------------------
// Organizations (Companies, Associations, etc.)
$_LANG["cnrxfrannounce"] = "Organisation/Entreprise, N° d'annonce<br/>(Journal Officiel)";
$_LANG["cnrxfrannouncedescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises (associations/entreprises). Laissez vide pour les personnes physiques.<br/>",
    "Numéro de l'annonce au Journal Officiel (chiffres uniquement).",
    "Si vous utilisez les informations du Journal Officiel comme identifiant, veuillez renseigner tous les champs JO associés :",
    "Date de publication, N° d'annonce, N° de page et Date d'association."
]);
$_LANG["cnrxfrdatepublicationjo"] = "Organisation/Entreprise, Date de publication<br/>(Journal Officiel)";
$_LANG["cnrxfrdatepublicationjodescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises (associations/entreprises). Laissez vide pour les personnes physiques.<br/>",
    "Date de publication au Journal Officiel.",
    "Format de date AAAA-MM-JJ.",
    "Si vous utilisez les informations du Journal Officiel comme identifiant, veuillez renseigner tous les champs JO associés :",
    "Date de publication, N° d'annonce, N° de page et Date d'association."
]);
$_LANG["cnrxfrnumerodepageannouncejo"] = "Organisation/Entreprise, N° de page<br/>(Journal Officiel)";
$_LANG["cnrxfrnumerodepageannouncejodescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises (associations/entreprises). Laissez vide pour les personnes physiques.<br/>",
    "Numéro de page au Journal Officiel (chiffres uniquement).",
    "Si vous utilisez les informations du Journal Officiel comme identifiant, veuillez renseigner tous les champs JO associés :",
    "Date de publication, N° d'annonce, N° de page et Date d'association."
]);
$_LANG["cnrxfrwaldec"] = "Organisation/Entreprise, ID Waldec (Associations)";
$_LANG["cnrxfrwaldecdescr"] = implode(" ", [
    "Associations uniquement. Laissez vide pour les personnes physiques.<br/>",
    "Identifiant Waldec lié à une association (chiffres uniquement).",
    "S'il est fourni, il suffit à identifier l'association.",
    "Conseil : en général, un seul identifiant suffit ; si vous indiquez Waldec, vous pouvez laisser vides les autres identifiants d'organisation (SIREN/SIRET, TVA, DUNS, marque, ID local, champs Journal Officiel)."
]);
$_LANG["cnrxfrdateassociation"] = "Organisation/Entreprise, Date d'association";
$_LANG["cnrxfrdateassociationdescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises (associations/entreprises). Laissez vide pour les personnes physiques.<br/>",
    "Format de date AAAA-MM-JJ.",
    "Requis si vous renseignez les informations du Journal Officiel (N° d'annonce, N° de page, Date de publication)."
]);
$_LANG["cnrxfrduns"] = "Organisation/Entreprise, Numéro DUNS";
$_LANG["cnrxfrdunsdescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises. Laissez vide pour les personnes physiques.<br/>",
    "Le numéro DUNS est un identifiant unique à neuf chiffres pour les entreprises. Abréviation de Data Universal",
    "Numbering System; il s'agit d'un nouvel identifiant pouvant être envoyé pour une vérification d'éligibilité",
    "au niveau européen.",
    "Conseil : en général, un seul identifiant suffit (p.ex. SIREN/SIRET, TVA, DUNS, marque, ID local, Waldec ou champs Journal Officiel)."
]);
$_LANG["cnrxfrlocal"] = "Organisation/Entreprise, ID Local";
$_LANG["cnrxfrlocaldescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises. Laissez vide pour les personnes physiques.<br/>",
    "Un identifiant local spécifique à un pays de l'Espace Économique Européen (par exemple, numéro de certificat d'entreprise).",
    "Conseil : en général, un seul identifiant suffit (p.ex. SIREN/SIRET, TVA, DUNS, marque, ID local, Waldec ou champs Journal Officiel)."
]);
$_LANG["cnrxfrnoprezonecheck0"] = $_LANG["cnr0"];
$_LANG["cnrxfrnoprezonecheck1"] = $_LANG["cnr1"];
$_LANG["cnrxfrsirenorsiret"] = "Organisation/Entreprise, Numéro SIREN/SIRET";
$_LANG["cnrxfrsirenorsiretdescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises. Laissez vide pour les personnes physiques.<br/>",
    "Renseignez ce champ si vous enregistrez en tant qu'organisation/entreprise en France avec un SIREN/SIRET valide.",
    "Conseil : en général, un seul identifiant suffit ; si vous indiquez SIREN/SIRET, vous pouvez laisser vides TVA, DUNS, marque, ID local, Waldec et champs Journal Officiel.",
    "Le code SIREN est le numéro d'identification unique des entreprises en France. Il est délivré par l'",
    "Institut national de la statistique et des études économiques (INSEE) et comporte 9 chiffres.",
    "Les 9 premiers chiffres sont le numéro SIREN et les 5 chiffres suivants sont le numéro NIC",
    "(Numéro Interne de Classement). Le numéro SIRET est délivré une fois que vous avez enregistré votre",
    "entreprise auprès de la Chambre de Commerce (RCS) pour le commerce, de la Chambre de Métiers pour les artisans",
    "et les travaux manuels ou auprès de l'URSSAF pour les services intellectuels. Les numéros SIRET sont composés de 14",
    "chiffres. Le numéro SIRET fournit des informations sur l'emplacement de l'entreprise en France",
    "(pour les entreprises établies). Le nom de l'entreprise fourni dans les détails du contact du titulaire doit",
    "être exactement le même que celui indiqué dans la base de données SIREN/SIRET ( https://www.infogreffe.fr/ )."
]);
$_LANG["cnrxfrtrademark"] = "Organisation/Entreprise, Numéro de marque";
$_LANG["cnrxfrtrademarkdescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises. Laissez vide pour les personnes physiques.<br/>",
    "Numéro de marque (si l'enregistrement est basé sur des droits de marque).",
    "Conseil : en général, un seul identifiant suffit ; si vous indiquez un numéro de marque, vous pouvez laisser vides SIREN/SIRET, TVA, DUNS, ID local, Waldec et champs Journal Officiel."
]);
$_LANG["cnrxfrvatid"] = "Organisation/Entreprise, Numéro de TVA";
$_LANG["cnrxfrvatiddescr"] = implode(" ", [
    "Uniquement pour les organisations/entreprises. Laissez vide pour les personnes physiques.<br/>",
    "Numéro de TVA (si disponible).",
    "Conseil : en général, un seul identifiant suffit ; si vous indiquez la TVA, vous pouvez laisser vides SIREN/SIRET, DUNS, marque, ID local, Waldec et champs Journal Officiel."
]);

// Individuel
$_LANG["cnrxfrbirthpc"] = "Titulaire, Code Postal (Lieu de Naissance)";
$_LANG["cnrxfrbirthpcdescr"] = implode(" ", [
    "Personnes physiques uniquement. Laissez vide pour les organisations/entreprises.<br/>",
    "Requis uniquement pour les personnes nées en France ou dans les territoires français d'outre-mer (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Veuillez fournir le code postal du lieu de naissance (ou au moins le code du département)."
]);
$_LANG["cnrxfrbirthcity"] = "Titulaire, Ville de Naissance";
$_LANG["cnrxfrbirthcitydescr"] = implode(" ", [
    "Personnes physiques uniquement. Laissez vide pour les organisations/entreprises.<br/>",
    "Requis uniquement pour les personnes nées en France ou dans les territoires français d'outre-mer (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "Veuillez fournir le nom de la ville."
]);
$_LANG["cnrxfrbirthdate"] = "Titulaire, Date de Naissance";
$_LANG["cnrxfrbirthdatedescr"] = "Personnes physiques uniquement. Date de naissance au format AAAA-MM-JJ. Laissez vide pour les organisations/entreprises.";
$_LANG["cnrxfrbirthplace"] = "Titulaire, Pays de naissance";
$_LANG["cnrxfrbirthplacedescr"] = "Personnes physiques uniquement. Code pays du lieu de naissance (p.ex. FR, DE). Laissez vide pour les organisations/entreprises.";
$_LANG["cnrxfrrestrictpub"] = "Titulaire, Restreindre la publication (WHOIS)";
$_LANG["cnrxfrrestrictpub0"] = $_LANG["cnr0"];
$_LANG["cnrxfrrestrictpub1"] = $_LANG["cnr1"];
$_LANG["cnrxfrrestrictpubdescr"] = "Personnes physiques uniquement. Choisissez 'Oui' pour restreindre la publication et masquer les données personnelles dans le WHOIS.";
$_LANG["cnrxfrnoprezonecheck"] = "Supprimer la vérification DNS préalable";
$_LANG["cnrxfrnoprezonecheckdescr"] = "Détermine si le système doit effectuer une vérification DNS préalable avant d'envoyer la commande au registre.";

// ----------------------------------------------------------------------
// ------------------ .PT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxpttechidentification"] = "Contact Technique, Numéro de TVA";
$_LANG["cnrxpttechidentificationdescr"] = "Le Numéro d'Identification Fiscale du Contact Technique";
$_LANG["cnrxptowneridentification"] = "Titulaire, Numéro de TVA";
$_LANG["cnrxptowneridentificationdescr"] = "Le Numéro d'Identification Fiscale du Titulaire";
$_LANG["cnrxpttechmobile"] = "Contact Technique, Téléphone Mobile";
$_LANG["cnrxpttechmobiledescr"] = "Le Numéro de Téléphone Mobile du Contact Technique";
$_LANG["cnrxptownermobile"] = "Titulaire, Téléphone Mobile";
$_LANG["cnrxptownermobiledescr"] = "Le Numéro de Téléphone Mobile du Titulaire";

// ----------------------------------------------------------------------
// ------------------ .RO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrocompanynumber"] = "Titulaire, Numéro de Société";
$_LANG["cnrxrocompanynumberdescr"] = "(requis uniquement pour les entreprises)";
$_LANG["cnrxroidcardorpassportnumber"] = "Titulaire, Numéro de Carte d'Identité ou de Passeport";
$_LANG["cnrxroidcardorpassportnumberdescr"] = "(requis uniquement pour les particuliers)";
$_LANG["cnrxrovatnumber"] = "Titulaire, Numéro de TVA";
$_LANG["cnrxrovatnumberdescr"] = "(requis uniquement pour les entreprises)";

// ----------------------------------------------------------------------
// ------------------ .RU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrubirthdate"] = "Titulaire, Date de Naissance";
$_LANG["cnrxrubirthdatedescr"] = "La Date de Naissance du Titulaire (JJ.MM.AAAA)<br/>(requis uniquement pour les particuliers)";
$_LANG["cnrxrufirstname"] = "Titulaire, Prénom";
$_LANG["cnrxrufirstnamedescr"] = "Le Prénom du Titulaire en russe. À remplir avec des lettres russes et latines, sans points.<br/>(requis uniquement pour les particuliers)";
$_LANG["cnrxrumiddlename"] = "Titulaire, Deuxième Prénom";
$_LANG["cnrxrumiddlenamedescr"] = "Le Deuxième Prénom du Titulaire en russe. À remplir avec des lettres russes et latines, sans points.<br/>(requis uniquement pour les particuliers)";
$_LANG["cnrxrulastname"] = "Titulaire, Nom de Famille";
$_LANG["cnrxrulastnamedescr"] = "Le Nom de Famille du Titulaire en russe. À remplir avec des lettres russes et latines, sans points.<br/>(requis uniquement pour les particuliers)";
$_LANG["cnrxruorganization"] = "Titulaire, Nom de l'Organisation";
$_LANG["cnrxruorganizationdescr"] = "Le Nom de l'Organisation du Titulaire en russe. Ce champ peut contenir des lettres russes et latines, des chiffres, des signes de ponctuation et des espaces.<br/>(requis uniquement pour les organisations incorporées en Fédération de Russie)";
$_LANG["cnrxrucode"] = "Titulaire, Numéro d'Identification Fiscale";
$_LANG["cnrxrucodedescr"] = "Le Numéro d'Identification Fiscale (NIF) du Titulaire. Ce champ doit contenir un numéro à dix chiffres (le dernier chiffre est un chiffre de contrôle).<br/>(requis uniquement pour les organisations incorporées en Fédération de Russie)";
$_LANG["cnrxrukpp"] = "Titulaire, Code de Raison";
$_LANG["cnrxrukppdescr"] = "Le Code de Raison (KPP) du Titulaire. Ce champ doit contenir un numéro à neuf chiffres.<br/>(requis uniquement pour les organisations incorporées en Fédération de Russie)";
$_LANG["cnrxrupassportdata"] = "Titulaire, Données du Passeport";
$_LANG["cnrxrupassportdatadescr"] = "Les Données du Passeport du Titulaire. Ce champ est rempli en russe et peut contenir des lettres russes et latines, des chiffres, des signes de ponctuation et des espaces. Format : Numéro du document, Délivré par, Date de délivrance<br/>(requis uniquement pour les particuliers)";

// ----------------------------------------------------------------------
// ------------------ .SE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnicseidnumber"] = "Titulaire, Numéro d'identification";
$_LANG["cnrxnicseidnumberdescr"] = "Numéro personnel ou organisationnel.";
$_LANG["cnrxnicsevatid"] = "Titulaire, Numéro de TVA";
$_LANG["cnrxnicsevatiddescr"] = "";
$_LANG["cnrxsediscloseemail"] = "Titulaire, Divulguer l'Email";
$_LANG["cnrxsediscloseemaildescr"] = "Autoriser la divulgation de l'adresse email du titulaire dans la base de données WHOIS publique.";
$_LANG["cnrxsedisclosefax"] = "Titulaire, Divulguer le Fax";
$_LANG["cnrxsedisclosefaxdescr"] = "Autoriser la divulgation du numéro de fax du titulaire dans la base de données WHOIS publique.";
$_LANG["cnrxsedisclosevoice"] = "Titulaire, Divulguer le Numéro de Téléphone";
$_LANG["cnrxsedisclosevoicedescr"] = "Autoriser la divulgation du numéro de téléphone du titulaire dans la base de données WHOIS publique.";
foreach (["email", "fax", "voice"] as $field) {
    $_LANG["cnrxsedisclose$field" . "0"] = $_LANG["cnr0"];
    $_LANG["cnrxsedisclose$field" . "1"] = $_LANG["cnr1"];
}

// ----------------------------------------------------------------------
// ------------------ .SG Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxsgrcbid"] = "Titulaire, ID RCB";
$_LANG["cnrxsgrcbiddescr"] = "Le numéro d'entité unique (UEN) ou le numéro d'enregistrement de l'entreprise (RCB) du titulaire. Pour les <u>entreprises</u> situées à Singapour, le numéro d'enregistrement de l'entreprise correspondant doit être spécifié OU la carte d'identité du contact pour une présence locale à Singapour (Format : S1234567D).";
$_LANG["cnrxsgadminsingpassid"] = "Admin, ID SingPass";
$_LANG["cnrxsgadminsingpassiddescr"] = "La carte d'identité du contact (ID SingPass) du contact administratif<br/>(pour les <u>particuliers</u> singapouriens uniquement, Format : S1234567D)";

// ----------------------------------------------------------------------
// ------------------ .SK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxskcontactlegalform"] = "Titulaire, Forme Juridique";
$_LANG["cnrxskcontactlegalformdescr"] = "";
// $_LANG["cnrxskcontactlegalformcorp"] = "";
// $_LANG["cnrxskcontactlegalformpers"] = "";
$_LANG["cnrxskcontactidentnumber"] = "Titulaire, Numéro d'Entreprise";
$_LANG["cnrxskcontactidentnumberdescr"] = "Numéro de registre du commerce. Obligatoire pour les entreprises/organisations";

// ----------------------------------------------------------------------
// ------------------ .SWISS Fields -------------------------------------
// ----------------------------------------------------------------------
// see other .swiss fields at top of the file
$_LANG["cnrxswissuid"] = "Titulaire, UID ou UPI";
$_LANG["cnrxswissuiddescr"] = implode("", [
    "Le ...<ul>",
    "<li>UID (Numéro d'Identification Unique, Format: \"CHE-ddd.ddd.ddd\") pour les Organisations ou</li>",
    "<li>UPI (Identification Universelle de la Personne, Format: \"756.dddd.dddd.dd\") pour les Personnes Physiques</li>",
    "</ul>... du Titulaire (d = chiffre).<br/>",
    "Veuillez noter : Le nom de la personne et l'UPI ne sont PAS publiés dans le Whois/RDAP contrairement au nom de l'organisation et à l'UID, qui sont visibles."
]);
$_LANG["cnrxswissownertype"] = "Titulaire, Type";
$_LANG["cnrxswissownertypep"] = "Personne Physique";
$_LANG["cnrxswissownertypeo"] = "Organisation / Entité Juridique";
$_LANG["cnrxswissownertypedescr"] = "Le Type d'Identité du Titulaire.";

// ----------------------------------------------------------------------
// ------------------ .TRAVEL Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxtravelindustry"] = "Industrie du Voyage";
$_LANG["cnrxtravelindustryn"] = $_LANG["cnr0"];
$_LANG["cnrxtravelindustryy"] = $_LANG["cnr1"];
$_LANG["cnrxtravelindustrydescr"] = "Je confirme que le titulaire est membre de l'industrie du voyage et possède un identifiant de membre valide.";

// ----------------------------------------------------------------------
// ------------------ .UK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxukownercorporatetype"] = "Titulaire, Type d'Entreprise";
$_LANG["cnrxukownercorporatetypedescr"] = "";
$_LANG["cnrxukownercorporatetypeother"] = "Autre";
$_LANG["cnrxukownercorporatetypefother"] = "Autre (Non-UK)";
$_LANG["cnrxukownercorporatetypeind"] = "Individu";
$_LANG["cnrxukownercorporatetypefind"] = "Individu (Non-UK)";
$_LANG["cnrxukownercorporatetypefcorp"] = "Société (Non-UK)";
// $_LANG["cnrxukownercorporatetypeltd"] = "LTD";
// $_LANG["cnrxukownercorporatetypeplc"] = "PLC";
// $_LANG["cnrxukownercorporatetypellp"] = "LLP";
// $_LANG["cnrxukownercorporatetypeip"] = "IP";
$_LANG["cnrxukownercorporatetypecrc"] = "Entreprise par Charte Royale";
$_LANG["cnrxukownercorporatetypegov"] = "Organisme Gouvernemental";
$_LANG["cnrxukownercorporatetypeptnr"] = "Partenariat UK";
$_LANG["cnrxukownercorporatetyperchar"] = "Charité Enregistrée";
$_LANG["cnrxukownercorporatetypesch"] = "École";
$_LANG["cnrxukownercorporatetypestat"] = "Organisme Statutaire";
$_LANG["cnrxukownercorporatetypestra"] = "Auto-Entrepreneur";
$_LANG["cnrxukownercorporatenumber"] = "Titulaire, Numéro d'Entreprise";
$_LANG["cnrxukownercorporatenumberdescr"] = "Numéro d'enregistrement auprès de Companies House UK";

// ----------------------------------------------------------------------
// ------------------ .US Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxusnexusapppurpose"] = "US Nexus, But de l'application";
$_LANG["cnrxusnexusapppurposep1"] = "Usage commercial à but lucratif";
$_LANG["cnrxusnexusapppurposep2"] = "Entreprise à but non lucratif, Club, Association, Organisation religieuse, etc.";
$_LANG["cnrxusnexusapppurposep3"] = "Usage personnel";
$_LANG["cnrxusnexusapppurposep4"] = "Objectifs éducatifs";
$_LANG["cnrxusnexusapppurposep5"] = "Objectifs gouvernementaux";
$_LANG["cnrxusnexusapppurposedescr"] = "";
$_LANG["cnrxusnexuscategory"] = "US Nexus, Catégorie";
$_LANG["cnrxusnexuscategoryc11"] = "[C11] Citoyen américain";
$_LANG["cnrxusnexuscategoryc12"] = "[C12] Résident permanent américain";
$_LANG["cnrxusnexuscategoryc21"] = "[C21] Organisation américaine";
$_LANG["cnrxusnexuscategoryc31"] = "[C31] Entité étrangère avec activités aux États-Unis";
$_LANG["cnrxusnexuscategoryc32"] = "[C32] Entité étrangère avec bureau aux États-Unis";
$_LANG["cnrxusnexuscategorydescr"] = "Catégorisation de l'entité demandant l'application.<br/>Remarque : Les possessions et territoires des États-Unis sont également inclus.";
$_LANG["cnrxusnexusvalidator"] = "US Nexus, Pays";
$_LANG["cnrxusnexusvalidatordescr"] = "Spécifiez le code pays à deux lettres du titulaire (si la catégorie Nexus est C31 ou C32)";

// ----------------------------------------------------------------------
// ------------------ .XXX Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxxxxcommunityid"] = "ID de membre de la communauté";
$_LANG["cnrxxxxcommunityiddescr"] = "ID de membre de la communauté sponsorisée .XXX";
$_LANG["cnrxxxxdefensive"] = "Enregistrement défensif<br/>(Domaine non résolu)";
$_LANG["cnrxxxxdefensive0"] = $_LANG["cnr0"];
$_LANG["cnrxxxxdefensive1"] = $_LANG["cnr1"];
$_LANG["cnrxxxxdefensivedescr"] = implode("", [
    "Je confirme que le domaine est un enregistrement défensif. ",
    "L'enregistrement défensif consiste à enregistrer des noms de domaine, ",
    "souvent sur plusieurs TLD et dans divers formats grammaticaux, ",
    "dans le but principal de protéger la propriété intellectuelle ou la marque contre les abus, ",
    "tels que le cybersquattage. Il est défini comme un enregistrement qui n'est pas unique, ne résout pas, ",
    "redirige le trafic vers un enregistrement principal ou ne contient pas de contenu unique.<br/>",
    "Remarque : si non sélectionné, le domaine sera considéré comme un enregistrement défensif."
]);

// #########################################################################
// #########################################################################
// # Add reusable translations for ALL PROVIDERS                           #
// #########################################################################
// #########################################################################

/// ----------------------------------------------------------------------
// ---------------- EMAIL VERIFICATION ----------------------------------
// ----------------------------------------------------------------------
// $_LANG["cnicemailverification"] = "Vérification de l'e-mail";
// $_LANG["emailverificationtitle"] = "Vérifiez votre e-mail";
// $_LANG["emailverificationinfo"] = "La vérification est requise pour les informations de contact suivantes";
// $_LANG["emailverificationconsequences"] = "Le non-vérification de votre e-mail peut entraîner la suspension de votre domaine.";
// $_LANG["emailverificationresendemailinfo"] = "Si vous n'avez pas reçu l'e-mail, veuillez cliquer sur le bouton ci-dessous pour renvoyer l'e-mail de vérification.";
// $_LANG["verified"] = "Vérifié";
// $_LANG["emailverificationpending"] = "En attente";

// ----------------------------------------------------------------------
// ----------------------- DNSSEC MANAGEMENT ----------------------------
// ----------------------------------------------------------------------
$_LANG["cnicdnssecmanagement"] = "Gestion DNSSEC";

// Messages d'état
$_LANG["dnssecautomaticupdatesuccessmsg"] = "DNSSEC a été <span style=\"color:green;font-weight:bold;\">activé</span> pour votre domaine.<br> Les enregistrements DNSSEC ont été importés depuis votre zone DNS et mis à jour auprès de votre bureau d'enregistrement de domaine.<br><br><span style=\"color:#007bff;\">Pour votre sécurité, DNSSEC aide à protéger votre domaine contre certains types d'attaques en validant les réponses DNS.</span>";
$_LANG["dnssecautoenable"] = "Activer DNSSEC et importer automatiquement les enregistrements DNSSEC depuis la zone DNS";
$_LANG["dnssecsyncrecords"] = "Synchroniser les enregistrements DNSSEC depuis la zone DNS";

// Gestion des enregistrements
$_LANG["dnssecaddnewdskey"] = "Ajouter une nouvelle clé DS";
$_LANG["dnssecaddnewkeyrecord"] = "Ajouter un nouvel enregistrement de clé";

// Boîte de dialogue modale
$_LANG["dnssecconfirmdisable"] = "Êtes-vous sûr de vouloir désactiver DNSSEC pour ce domaine ? Cette action peut affecter la résolution du domaine.";
$_LANG["dnssecmodaltitle"] = "Désactiver DNSSEC";
$_LANG["dnssecmodalcancel"] = "Annuler";
$_LANG["dnssecmodaldisable"] = "Désactiver DNSSEC";
