<?php

// #########################################################################
// #########################################################################
// # Add translations for CNR registrar module additional domain fields    #
// #########################################################################
// #########################################################################

// ----------------------------------------------------------------------
// ------------------ .DK Checkout Page ---------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrdkcheckoutheading"] = "شروط وأحكام أسماء النطاق .dk";
$_LANG["cnrdkcheckoutintro"] = "لتسجيل اسم نطاق .dk، يجب عليك إبرام اتفاق مع Punktum.dk A/S. Punktum dk هو المسؤول عن جميع أسماء النطاق .dk.";
$_LANG["cnrdkcheckoutdomains"] = "أسماء النطاق:";
$_LANG["cnrdkcheckoutregistrant"] = "المسجل:";
$_LANG["cnrdkcheckoutregistrantaddress"] = "انظر أعلاه";
$_LANG["cnrdkcheckoutadmin"] = "مسؤول النطاق:";
$_LANG["cnrdkcheckoutadminaddress"] = "Punktum dk A/S<br/>Ørestads Boulevard 108, الطابق 11<br/>DK-2300 كوبنهاغن S";
$_LANG["cnrdkcheckouttac"] = implode("<br/><br/>", [
    "أوافق بموجب هذا على إبرام اتفاق على حق استخدام اسم النطاق .dk المحدد وفقًا للشروط المطبقة عليه. من بين أمور أخرى، يعني هذا أنني سأحرص على أن تكون تفاصيل الاتصال الخاصة بي كمسجل دقيقة في جميع الأوقات. سأقوم بإجراء التحقق من الهوية من Punktum dk A/S عند الطلب.",
    "قد يتم نقل أو تعليق أو حذف أو حظر حقي في استخدام اسم النطاق .dk المحدد وفقًا للشروط المحددة في شروط الاستخدام الخاصة بـ Punktum dk A/S.",
    "وفقًا للفقرة 18 (2) (13) من قانون عقد المستهلك الدنماركي، أوافق على التنازل عن الحق في سحب الموافقة على الاتفاق بشأن حق استخدام اسم النطاق .dk المحدد.",
    "أعطي موافقتي لـ Punktum dk A/S، كمسؤول عن النطاق، لاستخدام بياناتي الشخصية وفقًا لسياسة الخصوصية الخاصة بها.",
    "أوافق على أنني سأدفع لهذا المزود رسوم فترة التسجيل الأولى لاسم النطاق .dk المحدد، وأن الدفع للفترات اللاحقة يعتمد على اختياري لترتيب الإدارة، كما هو مذكور في القسم 2.1 من شروط وأحكام Punktum dk A/S."
]);
$_LANG["cnrdkcheckouttacurl"] = "https://www.punktum.dk/en/articles/terms-and-conditions-for-the-right-of-use-to-a-dk-domain-name";
$_LANG["cnrdkcheckouttacurltext"] = "الشروط والأحكام لحق استخدام اسم النطاق .dk";
$_LANG["cnrdkcheckoutpolicyurl"] = "https://www.punktum.dk/en/articles/privacy-policy";
$_LANG["cnrdkcheckoutpolicyurltext"] = "سياسة الخصوصية";
$_LANG["cnrdkcheckoutabouturl"] = "https://www.punktum.dk/en/about-us";
$_LANG["cnrdkcheckoutabouturltext"] = "عن Punktum dk A/S";
$_LANG["cnrdkcheckouttacagree"] = "نعم، أقبل اتفاق المستخدم مع Punktum dk A/S.";

// ----------------------------------------------------------------------
// ------------------ Common CNR Translations ---------------------------
// ----------------------------------------------------------------------
$_LANG["cnrchoose"] = "يرجى الاختيار";
$_LANG["cnroptional"] = "اختياري";
$_LANG["cnr1"] = "نعم";
$_LANG["cnr0"] = "لا";
$_LANG["cnrconsentforpublishing"] = "المسجل، الموافقة على النشر";
// .abogado, .aero, .attorney, .bank, .broker, .dentist, .forex, .insurance, .lotto, .law, .lawyer, .markets, .trading
$_LANG["cnrxallocationtoken"] = "رمز تخصيص السجل";
$_LANG["cnrxallocationtokendescr"] = "أخبرنا إذا كنت بحاجة إلى مساعدة في ذلك. مطلوب فقط للنطاقات المميزة. يصدره مزود السجل.";
// .app, .page, .dev, .new, .day, .channel, .boo, .foo, .zip, .mov, .nexus, .dad, .phd, .prof, .esq, .rsvp, .meme, .ing, .new
$_LANG["cnrxacceptsslrequirement"] = "متطلبات SSL";
$_LANG["cnrxacceptsslrequirementdescr"] = "أؤكد أنني أفهم وأقبل المتطلبات الخاصة بـ HTTPS / شهادة SSL. هذا النطاق الأعلى مستوى (TLD) هو نطاق أكثر أمانًا، مما يعني أن HTTPS مطلوب لجميع المواقع. يمكنك شراء اسم النطاق الخاص بك الآن، ولكن لكي يعمل بشكل صحيح في المتصفحات، تحتاج إلى تكوين HTTPS بناءً على شهادة SSL.";
$_LANG["cnrxacceptsslrequirement0"] = $_LANG["cnr0"];
$_LANG["cnrxacceptsslrequirement1"] = $_LANG["cnr1"];
// .attorney, .dentist, .lawyer
$_LANG["cnrxunitedtldregulatorydata"] = "معلومات الهيئة التنظيمية";
$_LANG["cnrxunitedtldregulatorydatadescr"] = "امتداد يحتوي على معلومات حول السلطة الموافقة / السلطة المسيطرة / الهيئة التنظيمية";
// .barcelona, .cat, .madrid, .scot, .sport, .swiss
$_LANG["cnrxintendeduse"] = "الاستخدام المقصود";
$_LANG["cnrxintendedusedescr"] = implode("<br/>", array_reverse([
    "بيان الاستخدام المقصود لاسم النطاق. إذا كان ذلك ممكنًا، يرجى تضمين إشارة صريحة إلى الحق المطالب به من قبل المتقدم للاسم (إذا لم يكن اسم الشركة للمتقدم).",
    "على سبيل المثال، إذا كان اسم النطاق يتطابق مع علامة تجارية، يجب تقديم رقم العلامة التجارية (بحد أقصى 256 حرفًا)."
]));
// .mk
$_LANG["cnrxcompanyvatid"] = "المسجل، معرف ضريبة القيمة المضافة للشركة";
// $_LANG["cnrxcompanyvatiddescr"] = "";
// .nu, .se
$_LANG["cnrxrequestauthcode"] = "طلب رمز EPP جديد";
$_LANG["cnrxrequestauthcode0"] = $_LANG["cnr0"];
$_LANG["cnrxrequestauthcode1"] = $_LANG["cnr1"];
$_LANG["cnrxrequestauthcodedescr"] = "إذا كنت ترغب في نقل النطاق إلى مسجل آخر، فأنت بحاجة إلى رمز المصادقة. سنقوم بإرساله إلى عنوان البريد الإلكتروني لمالك النطاق.";

// NOTE: The following translations are labeled as boilerplate and should
// be used as a template for other languages. English texts are returned
// by default from the CNR Backend System. If you want to override these
// default texts, please consider a language override file in WHMCS using
// the below translation keys.
// We added some translations to override the API defaults which sometimes
// suck.

// ----------------------------------------------------------------------
// ------------------ DOMAIN DETAILS (and sub pages) --------------------
// ----------------------------------------------------------------------
$_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] = (
    "<small>لقد وجدنا بعض المشكلات في معلومات اتصال النطاق الخاصة بك والتي تحتاج إلى انتباهك. لحل هذا:<br/><br/><ol>" .
    "<li>انتقل إلى منطقة العميل (يتم سرد الحقول الإضافية هناك أيضًا، إن وجدت)</li>" .
    "<li>انتقل إلى صفحة <b>معلومات الاتصال</b> الخاصة بهذا النطاق</li>" .
    "<li>قم بإجراء أي تصحيحات ضرورية</li>" .
    "<li>أكمل عملية التحقق مباشرة بعد ذلك إن أمكن</li></ol></small>"
 );
$_LANG["cnrdomaincontactvalidationerrorsummary"] = (
    "<small>لقد وجدنا بعض المشكلات في معلومات اتصال النطاق الخاصة بك والتي تحتاج إلى انتباهك. لحل هذا:<br/><br/><ol>" .
    "<li>انتقل إلى صفحة <b><a href=\"clientarea.php?action=domaincontacts&domainid=:domainid\">معلومات الاتصال</a></b> وراجع تفاصيلك</li>" .
    "<li>قم بإجراء أي تصحيحات ضرورية</li>" .
    "<li>أكمل عملية التحقق مباشرة بعد ذلك إن أمكن</li></ol></small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspensionadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>يرجى إنهاء هذه الخطوات بحلول <b>:suspensiondate</b> لمنع تعليق نطاقك.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspension"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>يرجى إنهاء هذه الخطوات بحلول <b>:suspensiondate</b> لمنع تعليق نطاقك.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspendedadmin"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummaryadmin"] .
    " <small>تم تعليق نطاقك. يرجى إنهاء هذه الخطوات لإلغاء تعليق نطاقك.</small>"
);
$_LANG["cnrdomaincontactvalidationerrorsuspended"] = (
    $_LANG["cnrdomaincontactvalidationerrorsummary"] .
    " <small>تم تعليق نطاقك. يرجى إنهاء هذه الخطوات لإلغاء تعليق نطاقك.</small>"
);

// ----------------------------------------------------------------------
// ------------------ .AERO Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaeroensauthid"] = "معرف العضوية";
$_LANG["cnrxaeroensauthiddescr"] = "معرف العضوية .AERO مطلوب لتسجيل نطاق في مجال الطيران. يمكنك التقديم للحصول عليه <a style=\"text-decoration:underline\" href=\"https://information.aero/node/add/request-aero-id\" target=\"_blank\">هنا</a>.";
$_LANG["cnrxaeroensauthkey"] = "كلمة مرور العضوية";
$_LANG["cnrxaeroensauthkeydescr"] = "كلمة المرور/رمز المصادقة المقدم من الموقع المذكور أعلاه في نفس الوقت مع معرف العضوية .AERO.";

// ----------------------------------------------------------------------
// ------------------ .AU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxaudomainrelation"] = "العلاقة";
$_LANG["cnrxaudomainrelation1"] = "اسم النطاق من المستوى الثاني هو مطابق تمامًا، أو اختصار أو اختصار لاسم الشركة أو الاسم التجاري، أو اسم المنظمة أو الجمعية، أو العلامة التجارية.";
$_LANG["cnrxaudomainrelation2"] = "اسم النطاق من المستوى الثاني مرتبط بشكل وثيق وجوهري بالمنظمة أو الأنشطة التي تقوم بها المنظمة.";
$_LANG["cnrxaudomainrelationdescr"] = "يشير هذا إلى العلاقة بين نوع الأهلية (مثل اسم العمل) واسم النطاق.";
$_LANG["cnrxaudomainrelationtype"] = "نوع العلاقة";
$_LANG["cnrxaudomainrelationtypecompany"] = "شركة";
$_LANG["cnrxaudomainrelationtyperegisteredbusiness"] = "عمل مسجل";
$_LANG["cnrxaudomainrelationtypesoletrader"] = "تاجر فردي";
$_LANG["cnrxaudomainrelationtypepartnership"] = "شراكة";
$_LANG["cnrxaudomainrelationtypetrademarkowner"] = "مالك العلامة التجارية";
$_LANG["cnrxaudomainrelationtypependingtmowner"] = "مالك علامة تجارية قيد الانتظار";
$_LANG["cnrxaudomainrelationtypecitizenresident"] = "مواطن / مقيم"; // .id.au فقط
$_LANG["cnrxaudomainrelationtypeincorporatedassociation"] = "جمعية مدمجة";
$_LANG["cnrxaudomainrelationtypeclub"] = "نادي";
$_LANG["cnrxaudomainrelationtypenonprofitorganisation"] = "منظمة غير ربحية";
$_LANG["cnrxaudomainrelationtypecharity"] = "جمعية خيرية";
$_LANG["cnrxaudomainrelationtypetradeunion"] = "نقابة عمالية";
$_LANG["cnrxaudomainrelationtypeindustrybody"] = "هيئة صناعية";
$_LANG["cnrxaudomainrelationtypecommercialstatutorybody"] = "هيئة قانونية تجارية";
$_LANG["cnrxaudomainrelationtypepoliticalparty"] = "حزب سياسي";
$_LANG["cnrxaudomainrelationtypeother"] = "أخرى";
$_LANG["cnrxaudomainrelationtypereligiouschurchgroup"] = "مجموعة دينية / كنيسة";
$_LANG["cnrxaudomainrelationtypehighereducationinstitution"] = "مؤسسة تعليم عالي";
$_LANG["cnrxaudomainrelationtyperesearchorganisation"] = "منظمة بحثية";
$_LANG["cnrxaudomainrelationtypegovernmentschool"] = "مدرسة حكومية";
$_LANG["cnrxaudomainrelationtypechildcarecentre"] = "مركز رعاية الأطفال";
$_LANG["cnrxaudomainrelationtypepreschool"] = "روضة أطفال";
$_LANG["cnrxaudomainrelationtypenationalbody"] = "هيئة وطنية";
$_LANG["cnrxaudomainrelationtypetrainingorganisation"] = "منظمة تدريبية";
$_LANG["cnrxaudomainrelationtypenongovernmentschool"] = "مدرسة غير حكومية";
$_LANG["cnrxaudomainrelationtypeunincorporatedassociation"] = "جمعية غير مدمجة";
$_LANG["cnrxaudomainrelationtypeindustryorganisation"] = "منظمة صناعية";
$_LANG["cnrxaudomainrelationtyperegistrablebody"] = "هيئة قابلة للتسجيل";
$_LANG["cnrxaudomainrelationtypeindigenouscorporation"] = "شركة للسكان الأصليين";
$_LANG["cnrxaudomainrelationtyperegisteredorganisation"] = "منظمة مسجلة";
$_LANG["cnrxaudomainrelationtypetrust"] = "صندوق ائتماني";
$_LANG["cnrxaudomainrelationtypeeducationalinstitution"] = "مؤسسة تعليمية";
$_LANG["cnrxaudomainrelationtypecommonwealthentity"] = "كيان الكومنولث";
$_LANG["cnrxaudomainrelationtypestatutorybody"] = "هيئة قانونية";
$_LANG["cnrxaudomainrelationtypetradingcooperative"] = "تعاونية تجارية";
$_LANG["cnrxaudomainrelationtypecompanylimitedbyguarantee"] = "شركة محدودة بالضمان";
$_LANG["cnrxaudomainrelationtypenondistributingcooperative"] = "تعاونية غير موزعة";
$_LANG["cnrxaudomainrelationtypenontradingcooperative"] = "تعاونية غير تجارية";
$_LANG["cnrxaudomainrelationtypecharitabletrust"] = "صندوق خيري";
$_LANG["cnrxaudomainrelationtypepublicprivateancillaryfund"] = "صندوق مساعد عام / خاص";
$_LANG["cnrxaudomainrelationtypepeakstateterritorybody"] = "هيئة قمة الدولة / الإقليم";
$_LANG["cnrxaudomainrelationtypenotforprofitcommunitygroup"] = "مجموعة مجتمعية غير ربحية";
$_LANG["cnrxaudomainrelationtypeeducationandcareserviceschildcare"] = "خدمات التعليم والرعاية (رعاية الأطفال)";
$_LANG["cnrxaudomainrelationtypegovernmentbody"] = "هيئة حكومية";
$_LANG["cnrxaudomainrelationtypeproviderofnonaccreditedtraining"] = "مزود تدريب غير معتمد";
$_LANG["cnrxaudomainrelationtypedescr"] = "حدد ما يجعل المسجل مؤهلاً لتسجيل اسم النطاق";
$_LANG["cnrxauownerorganization"] = "المسجل، المنظمة";
$_LANG["cnrxauownerorganizationdescr"] = "اسم المنظمة (المسجل)";
$_LANG["cnrxauidwarranty"] = "المسجل،<br>هو مواطن أو مقيم أسترالي";
$_LANG["cnrxauidwarranty0"] = $_LANG["cnr0"];
$_LANG["cnrxauidwarranty1"] = $_LANG["cnr1"];
$_LANG["cnrxauidwarrantydescr"] = "يجب على المسجل لنطاق .id.au أن يضمن أنه مقيم أو مواطن أسترالي";
$_LANG["cnrxaueligibilityname"] = "اسم الأهلية";
$_LANG["cnrxaueligibilitynamedescr"] = "اسم نوع الأهلية (مثل اسم العمل)";
$_LANG["cnrxaudomainidnumber"] = "المسجل، رقم التعريف";
$_LANG["cnrxaudomainidnumberdescr"] = "";
$_LANG["cnrxaudomainidtype"] = "المسجل، نوع التعريف";
// $_LANG["cnrxaudomainidtypetm"] = "TM";
// $_LANG["cnrxaudomainidtypeabn"] = "ABN";
// $_LANG["cnrxaudomainidtypeacn"] = "ACN";
// $_LANG["cnrxaudomainidtypeother"] = "Other";
// $_LANG["cnrxaudomainidtypeact"] = "ACT";
// $_LANG["cnrxaudomainidtypensw"] = "NSW";
// $_LANG["cnrxaudomainidtypent"] = "NT";
// $_LANG["cnrxaudomainidtypeqld"] = "QLD";
// $_LANG["cnrxaudomainidtypesa"] = "SA";
// $_LANG["cnrxaudomainidtypetas"] = "TAS";
// $_LANG["cnrxaudomainidtypevic"] = "VIC";
// $_LANG["cnrxaudomainidtypewa"] = "WA";
// $_LANG["cnrxaudomainidtypeprivate"] = "Private";
$_LANG["cnrxaudomainidtypedescr"] = "";
$_LANG["cnrxaueligibilityidnumber"] = "الأهلية، رقم التعريف";
$_LANG["cnrxaueligibilityidnumberdescr"] = "";
$_LANG["cnrxaueligibilityidtype"] = "الأهلية، نوع التعريف";
$_LANG["cnrxaueligibilityidtypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .CA Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcalegaltype"] = "المسجل، النوع القانوني";
$_LANG["cnrxcalegaltypeabo"] = "الشعوب الأصلية في كندا";
$_LANG["cnrxcalegaltypeass"] = "جمعية غير مسجلة في كندا";
$_LANG["cnrxcalegaltypecco"] = "شركة (كندا أو مقاطعة أو إقليم كندي)";
$_LANG["cnrxcalegaltypecct"] = "مواطن كندي";
$_LANG["cnrxcalegaltypeedu"] = "مؤسسة تعليمية كندية";
$_LANG["cnrxcalegaltypegov"] = "حكومة أو كيان حكومي في كندا";
$_LANG["cnrxcalegaltypehop"] = "مستشفى كندي";
$_LANG["cnrxcalegaltypeinb"] = "فرقة هندية معترف بها بموجب قانون الهند في كندا";
$_LANG["cnrxcalegaltypelam"] = "مكتبة أو أرشيف أو متحف كندي";
$_LANG["cnrxcalegaltypelgr"] = "الممثل القانوني لمواطن كندي أو مقيم دائم";
$_LANG["cnrxcalegaltypemaj"] = "جلالة الملكة";
$_LANG["cnrxcalegaltypeomk"] = "علامة رسمية مسجلة في كندا";
$_LANG["cnrxcalegaltypeplt"] = "حزب سياسي كندي";
$_LANG["cnrxcalegaltypeprt"] = "شراكة مسجلة في كندا";
$_LANG["cnrxcalegaltyperes"] = "مقيم دائم في كندا";
$_LANG["cnrxcalegaltypetdm"] = "علامة تجارية مسجلة في كندا (بواسطة مالك غير كندي)";
$_LANG["cnrxcalegaltypetrd"] = "اتحاد تجاري كندي";
$_LANG["cnrxcalegaltypetrs"] = "صندوق مؤسس في كندا";
// $_LANG["cnrxcalegaltypedescr"] = "";
$_LANG["cnrxcatrademark"] = "هل هو علامة تجارية مسجلة";
$_LANG["cnrxcatrademark0"] = $_LANG["cnr0"];
$_LANG["cnrxcatrademark1"] = $_LANG["cnr1"];
$_LANG["cnrxcatrademarkdescr"] = "يحدد ما إذا كان النطاق علامة تجارية مسجلة أم لا.";

// ----------------------------------------------------------------------
// ------------------ .COM.BR Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxbrregisternumber"] = "المسجل، معرف قانوني برازيلي";
$_LANG["cnrxbrregisternumberdescr"] = "رقم تسجيل الشركة البرازيلية (CNPJ) أو رقم التسجيل الفردي البرازيلي (CPF).";

// ----------------------------------------------------------------------
// ------------------ .CN Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcnownertype"] = "المسجل، النوع";
$_LANG["cnrxcnownertypei"] = "فرد";
$_LANG["cnrxcnownertypee"] = "مؤسسة";
$_LANG["cnrxcnownertypedescr"] = "";
$_LANG["cnrxcnowneridtype"] = "المسجل، نوع الهوية";
$_LANG["cnrxcnowneridtypesfz"] = "SFZ (بطاقة الهوية) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypehz"] = "HZ (جواز السفر) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypegajmtx"] = "GAJMTX (تصريح الدخول والخروج للسفر من وإلى هونغ كونغ وماكاو) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypetwjmtx"] = "TWJMTX (تصاريح السفر لسكان تايوان للدخول أو الخروج من البر الرئيسي) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypewjlsfz"] = "WJLSFZ (بطاقة هوية المقيم الدائم الأجنبي) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypegajzz"] = "GAJZZ (تصريح الإقامة لسكان هونغ كونغ وماكاو) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypetwjzz"] = "TWJZZ (تصريح الإقامة لسكان تايوان) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypejgz"] = "JGZ (بطاقة هوية الضابط) - نوع المسجل فرد";
$_LANG["cnrxcnowneridtypeqt"] = "QT (أخرى) - نوع المسجل فرد أو مؤسسة";
$_LANG["cnrxcnowneridtypeorg"] = "ORG (شهادة رمز المنظمة) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypeyyzz"] = "YYZZ (رخصة تجارية) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypetydm"] = "TYDM (شهادة رمز الائتمان الاجتماعي الموحد) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypebddm"] = "BDDM (تعيين الرمز العسكري) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypejddwfw"] = "JDDWFW (رخصة الخدمة الخارجية العسكرية مدفوعة الأجر) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypesydwfr"] = "SYDWFR (شهادة الشخص الاعتباري للمؤسسة العامة) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypewgczjg"] = "WGCZJG (نموذج تسجيل مكاتب الممثلين للمؤسسات الأجنبية) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypeshttfr"] = "SHTTFR (شهادة تسجيل الشخص الاعتباري للمنظمة الاجتماعية) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypezjcs"] = "ZJCS (شهادة تسجيل موقع النشاط الديني) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypembfqy"] = "MBFQY (شهادة تسجيل كيان خاص غير مؤسسي) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypejjhfr"] = "JJHFR (شهادة تسجيل الشخص الاعتباري للصندوق) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypelszy"] = "LSZY (رخصة مزاولة مهنة المحاماة) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypewgzhwh"] = "WGZHWH (شهادة تسجيل المركز الثقافي الأجنبي في الصين) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypewlczzg"] = "WLCZJG (شهادة تسجيل موافقة مكتب الممثل المقيم لإدارات السياحة لحكومة أجنبية) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypesfjd"] = "SFJD (رخصة الخبرة القضائية) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypejwjg"] = "JWJG (شهادة منظمة في الخارج) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypeshfwjg"] = "SHFWJG (شهادة تسجيل وكالة الخدمة الاجتماعية) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypembxxbx"] = "MBXXBX (تصريح مدرسة خاصة) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypeyljgzy"] = "YLJGZY (رخصة مزاولة مهنة الطب) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypegzjgzy"] = "GZJGZY (رخصة ممارسة منظمة كاتب العدل) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypebjwsxx"] = "BJWSXX (تصريح مدرسة بكين لأطفال موظفي السفارة الأجنبية في الصين) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypeqttyzm"] = "QTTYDM (أخرى - شهادة رمز الائتمان الاجتماعي الموحد) - نوع المسجل مؤسسة";
$_LANG["cnrxcnowneridtypedescr"] = "نوع هوية بطاقة الهوية";
$_LANG["cnrxcnowneridnumber"] = "المسجل، رقم الهوية";
$_LANG["cnrxcnowneridnumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .COOP Fields --------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxcoopeligibility"] = "متطلبات الأهلية";
$_LANG["cnrxcoopeligibilitydescr"] = "أقبل أن مؤسستي تفي بواحد على الأقل من متطلبات الأهلية .COOP. اقرأ <a style=\"text-decoration:underline\" href=\"https://identity.coop/coop-policies-and-agreements/\" target=\"_blank\">هنا</a>.";
$_LANG["cnrxcoopeligibility0"] = $_LANG["cnr0"];
$_LANG["cnrxcoopeligibility1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .DE Fields ----------------------------------------
// ----------------------------------------------------------------------
//$_LANG["cnrxdensentry0"] = "";
$_LANG["cnrxdensentry0descr"] = implode(" ", array_reverse([
    "تمكين استخدام nsentrys بدلاً من خوادم الأسماء لنطاقات .de;",
    "تسمح سجلات NS بتكوين النطاقات الفرعية باستخدام خوادم أسماء بديلة.",
    "<a target=\"_blank\" href=\"https://www.denic.de/en/domains/de-domains/registration/nameserver-and-nsentry-data/\" style=\"text-decoration:underline\">قراءة مفصلة</a>."
]));
//$_LANG["cnrxdensentry1"] = "";
$_LANG["cnrxdensentry1descr"] = "انظر أعلاه";
//$_LANG["cnrxdensentry2"] = "";
$_LANG["cnrxdensentry2descr"] = "انظر أعلاه";
//$_LANG["cnrxdensentry3"] = "";
$_LANG["cnrxdensentry3descr"] = "انظر أعلاه";
//$_LANG["cnrxdensentry4"] = "";
$_LANG["cnrxdensentry4descr"] = "انظر أعلاه";
//$_LANG["cnrxdegeneralrequest"] = "";
//$_LANG["cnrxdegeneralrequestdescr"] = "";
//$_LANG["cnrxdeabusecontact"] = "";
//$_LANG["cnrxdeabusecontactdescr "] = "";

// ----------------------------------------------------------------------
// ------------------ .DK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxdkusertype"] = "المسجل، النوع";
$_LANG["cnrxdkusertypeperson"] = "شخص";
$_LANG["cnrxdkusertypecompany"] = "شركة";
$_LANG["cnrxdkusertypeassociation"] = "جمعية";
$_LANG["cnrxdkusertypepuborg"] = "منظمة عامة";
// $_LANG["cnrxdkusertypedescr"] = "";
$_LANG["cnrxdkuseridnumber"] = "المسجل، رقم الهوية";
$_LANG["cnrxdkuseridnumberdescr"] = implode("", array_reverse([
    "رقم تعريف جهة اتصال المسجل. يمكن أن يكون <i>EAN، CVR أو P number.</i> ",
    "يستخدم <i>رقم CVR</i> لتحديد المنظمة، ويضمن <i>رقم EAN</i> ",
    "إرسال المستندات المتعلقة بالفواتير الإلكترونية إلى الحساب الصحيح. ",
    "<i>رقم P</i> هو معرف فرع يتم تعيينه بواسطة السجل المركزي للأعمال الدنماركية ",
    "لربط المواقع الفعلية بالمنظمة."
]));

// ----------------------------------------------------------------------
// ------------------ .ES Fields ----------------------------------------
// ----------------------------------------------------------------------
$types = [
    1 => "فردي",
    39 => "مجموعة المصالح الاقتصادية",
    47 => "جمعية",
    59 => "جمعية رياضية",
    68 => "جمعية مهنية",
    124 => "بنك الادخار",
    150 => "ممتلكات عامة",
    152 => "مجتمع المالكين",
    164 => "أنظباط أو مؤسسة دينية",
    181 => "قنصلية",
    197 => "جمعية القانون العام",
    203 => "السفارة",
    229 => "السلطة المحلية",
    269 => "الاتحاد الرياضي",
    286 => "مؤسسة",
    365 => "شركة التأمين التعاوني",
    434 => "الهيئة الحكومية الإقليمية",
    436 => "هيئة الحكومة المركزية",
    439 => "حزب سياسي",
    476 => "اتحاد تجاري",
    510 => "الشراكة الزراعية",
    524 => "الشركه العالميه المحدوده",
    525 => "الاتحاد الرياضي",
    554 => "المجتمع المدني",
    560 => "الشراكة العامة",
    562 => "الشراكة العامة والمحدودة",
    566 => "تعاوني",
    608 => "شركة مملوكة للموظف",
    612 => "شركة محدودة",
    713 => "المكتب الاسباني",
    717 => "التحالف المؤقت للمؤسسات",
    744 => "شركة محدودة مملوكة للموظف",
    745 => "الكيان العام الإقليمي",
    746 => "الكيان العام الوطني",
    747 => "الكيان العام المحلي",
    877 => "اخر",
    878 => "تسمية مجلس الإشراف على المنشأ",
    879 => "كيان إدارة المناطق الطبيعية"
];
$idtypes = [
    0 => "لمالك غير إسباني",
    1 => "لفرد أو منظمة أسبانية",
    2 => "Deprecated⸴ Use next option instead.",
    3 => "بطاقة تسجيل الأجنبي",
    4 => "ضريبة القيمة المضافة (الرقم الضريبي) - صالح فقط للكيانات القانونية غير الإسبانية"
];
$idtypesdescr = implode("<br/>", [
    "DNI = &quot;Documento Nacional de Identidad&quot;",
    "NIF = &quot;Número de Identificación Fiscal&quot;",
    "NIE = &quot;Número de Identificación de Extranjero&quot; (رقم تعريف الأجنبي). وهو ما يعادل NIF الإسباني، ولكنه يصدر من قبل السلطات الإسبانية للأجانب الذين يخططون للبقاء لأكثر من 3 أشهر في إسبانيا."
]);
$idnodescr = "رقم تعريف هذا الاتصال. بالنسبة للاتصالات الإسبانية، هذا هو رقم DNI/NIF/NIE - رقم بطاقة الهوية أو جواز السفر.";

$_LANG["cnrxesownertipoidentificacion"] = "المالك، نوع التعريف";
$_LANG["cnrxesadmintipoidentificacion"] = "المسؤول، نوع التعريف";
$_LANG["cnrxestechtipoidentificacion"] = "التقني، نوع التعريف";
$_LANG["cnrxesbillingtipoidentificacion"] = "الفواتير، نوع التعريف";

foreach ($idtypes as $key => $value) {
    $_LANG["cnrxesownertipoidentificacion$key"] = $value;
    $_LANG["cnrxesadmintipoidentificacion$key"] = $value;
    $_LANG["cnrxestechtipoidentificacion$key"] = $value;
    $_LANG["cnrxesbillingtipoidentificacion$key"] = $value;
}

$_LANG["cnrxesownertipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesadmintipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxestechtipoidentificaciondescr"] = $idtypesdescr;
$_LANG["cnrxesbillingtipoidentificaciondescr"] = $idtypesdescr;

$_LANG["cnrxesowneridentificacion"] = "المالك، رقم التعريف";
$_LANG["cnrxesadminidentificacion"] = "المسؤول، رقم التعريف";
$_LANG["cnrxestechidentificacion"] = "التقني، رقم التعريف";
$_LANG["cnrxesbillingidentificacion"] = "الفواتير، رقم التعريف";

$_LANG["cnrxesowneridentificaciondescr"] = $idnodescr;
$_LANG["cnrxesadminidentificaciondescr"] = $idnodescr;
$_LANG["cnrxestechidentificaciondescr"] = $idnodescr;
$_LANG["cnrxesbillingidentificaciondescr"] = $idnodescr;

$_LANG["cnrxesownerlegalform"] = "المالك، الشكل القانوني";
$_LANG["cnrxesadminlegalform"] = "المسؤول، الشكل القانوني";
$_LANG["cnrxestechlegalform"] = "التقني، الشكل القانوني";
$_LANG["cnrxesbillinglegalform"] = "الفواتير، الشكل القانوني";

foreach ($types as $key => $value) {
    $_LANG["cnrxesownerlegalform$key"] = $value;
    $_LANG["cnrxesadminlegalform$key"] = $value;
    $_LANG["cnrxestechlegalform$key"] = $value;
    $_LANG["cnrxesbillinglegalform$key"] = $value;
}

$_LANG["cnrxesownerlegalformdescr"] = "";
$_LANG["cnrxesadminlegalformdescr"] = "";
$_LANG["cnrxestechlegalformdescr"] = "";
$_LANG["cnrxesbillinglegalformdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .EU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxeuregistrantlang"] = "المسجل، اللغة";
$_LANG["cnrxeuregistrantcitizenship"] = "المسجل، الجنسية";
$_LANG["cnrxeuregistrantlangdescr"] = "اللغة المستخدمة للتواصل مع مزود النطاق (الافتراضي = الإنجليزية)";
$_LANG["cnrxeuregistrantcitizenshipdescr"] = "يمكن للأشخاص الطبيعيين الذين يحملون جنسية أوروبية ولا يعيشون في الاتحاد الأوروبي تسجيل نطاقات .eu باستخدام هذا الإعداد.";

// ----------------------------------------------------------------------
// ------------------ .FI Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxficompanyregid"] = "المسجل، معرف العمل أو رقم التسجيل";
$_LANG["cnrxficompanyregiddescr"] = "كيان تجاري محلي (مسجل في السجل التجاري الفنلندي أو شركة داخل جمهورية فنلندا)<br/>(مطلوب للكيانات غير الفنلندية)";
$_LANG["cnrxfipersonalid"] = "المسجل، رقم الهوية الشخصية";
$_LANG["cnrxfipersonaliddescr"] = "رقم الهوية الشخصية الفنلندية<br/>(مطلوب للأفراد غير الفنلنديين)";
$_LANG["cnrxfibirthdate"] = "المسجل، تاريخ الميلاد";
$_LANG["cnrxfibirthdatedescr"] = "تاريخ الميلاد (YYYY-MM-DD)<br/>(مطلوب للأفراد غير الفنلنديين)";
$_LANG["cnrxficontacttype"] = "المسجل، نوع الاتصال";
$_LANG["cnrxficontacttype0"] = "شخص خاص";
$_LANG["cnrxficontacttype1"] = "شركة";
$_LANG["cnrxficontacttype2"] = "مؤسسة";
$_LANG["cnrxficontacttype3"] = "مؤسسة";
$_LANG["cnrxficontacttype4"] = "حزب سياسي";
$_LANG["cnrxficontacttype5"] = "بلدية";
$_LANG["cnrxficontacttype6"] = "حكومة";
$_LANG["cnrxficontacttype7"] = "مجتمع عام";
$_LANG["cnrxficontacttypedescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .GAY Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxgayacceptrequirements"] = "قبول المتطلبات";
$_LANG["cnrxgayacceptrequirements0"] = $_LANG["cnr0"];
$_LANG["cnrxgayacceptrequirements1"] = $_LANG["cnr1"];
$_LANG["cnrxgayacceptrequirementsdescr"] = "أؤكد أن النطاق لن يُستخدم للتحريض على العنف أو التنمر أو التحرش أو خطاب الكراهية ولن يُستخدم من قبل مجموعات الكراهية المعترف بها. تتبرع DotGay بنسبة 20٪ من كل نطاق جديد مسجل لشركائها، GLAAD و CenterLink.";

// ----------------------------------------------------------------------
// ------------------ .HK Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxhkownerdocumenttype"] = "المسجل، نوع الوثيقة";
$_LANG["cnrxhkownerdocumenttypehkid"] = "فرد: رقم هوية هونغ كونغ";
$_LANG["cnrxhkownerdocumenttypeothid"] = "فرد: رقم هوية بلد آخر";
$_LANG["cnrxhkownerdocumenttypepassno"] = "فرد: رقم جواز السفر";
$_LANG["cnrxhkownerdocumenttypebirthcert"] = "فرد: شهادة الميلاد";
$_LANG["cnrxhkownerdocumenttypeothidv"] = "فرد: وثيقة فردية أخرى";
$_LANG["cnrxhkownerdocumenttypebr"] = "منظمة: شهادة تسجيل الأعمال";
$_LANG["cnrxhkownerdocumenttypeci"] = "منظمة: شهادة التأسيس";
$_LANG["cnrxhkownerdocumenttypecrs"] = "منظمة: شهادة تسجيل المدرسة";
$_LANG["cnrxhkownerdocumenttypehksarg"] = "منظمة: دائرة حكومة هونغ كونغ";
$_LANG["cnrxhkownerdocumenttypehkordinance"] = "منظمة: مرسوم هونغ كونغ";
$_LANG["cnrxhkownerdocumenttypeothorg"] = "منظمة: وثيقة منظمة أخرى";
$_LANG["cnrxhkownerdocumenttypedescr"] = "";
$_LANG["cnrxhkownerdocumentnumber"] = "المسجل، رقم الوثيقة";
$_LANG["cnrxhkownerdocumentnumberdescr"] = "";
$_LANG["cnrxhkownerdocumentorigincountry"] = "المسجل، بلد إصدار الوثيقة";
$_LANG["cnrxhkownerdocumentorigincountrydescr"] = "البلد الذي أصدرت فيه هذه الوثيقة (يرجى تقديم رمز البلد المكون من حرفين ISO، مثل DE أو US).";
$_LANG["cnrxhkownerotherdocumenttype"] = "المسجل، نوع الوثيقة الأخرى";
$_LANG["cnrxhkownerotherdocumenttypedescr"] = "مطلوب إذا كان نوع الوثيقة المحدد سابقًا هو إما '" . $_LANG["cnrxhkownerdocumenttypeothidv"] . "' أو '" . $_LANG["cnrxhkownerdocumenttypeothorg"] . "'.";
$_LANG["cnrxhkdomaincategory"] = "فئة النطاق";
$_LANG["cnrxhkdomaincategoryi"] = "فرد";
$_LANG["cnrxhkdomaincategoryo"] = "منظمة";
$_LANG["cnrxhkdomaincategorydescr"] = "النوع القانوني لجميع جهات اتصال النطاق";
$_LANG["cnrxhkownerageover18"] = "المسجل، العمر فوق 18";
$_LANG["cnrxhkownerageover18no"] = $_LANG["cnr0"];
$_LANG["cnrxhkownerageover18yes"] = $_LANG["cnr1"];
$_LANG["cnrxhkownerageover18descr"] = "أؤكد أن المسجل يبلغ من العمر 18 عامًا على الأقل (مطلوب للأفراد فقط).";

// ----------------------------------------------------------------------
// ------------------ .IE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxiecontacttype"] = "المسجل، نوع الاتصال";
$_LANG["cnrxiecontacttypecom"] = "شركة";
$_LANG["cnrxiecontacttypecha"] = "جمعية خيرية";
$_LANG["cnrxiecontacttypeoth"] = "أخرى";
$_LANG["cnrxiecontacttypedescr"] = "";
$_LANG["cnrxielanguage"] = "المسجل، اللغة";
$_LANG["cnrxielanguageen"] = "الإنجليزية";
$_LANG["cnrxielanguagefr"] = "الفرنسية";
$_LANG["cnrxielanguagedescr"] = "اللغة المستخدمة للتواصل مع مزود النطاق (الافتراضي = الإنجليزية)";
$_LANG["cnrxiecronumber"] = "المسجل، رقم CRO";
$_LANG["cnrxiecronumberdescr"] = "رقم مكتب تسجيل الشركات (CRO)";
$_LANG["cnrxiesupportingnumber"] = "المسجل، رقم الجمعية الخيرية";
$_LANG["cnrxiesupportingnumberdescr"] = "رقم الجمعية الخيرية / الداعم";

// ----------------------------------------------------------------------
// ------------------ .IT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxitconsentforpublishing"] = $_LANG["cnrconsentforpublishing"];
$_LANG["cnrxitconsentforpublishing0"] = $_LANG["cnr0"];
$_LANG["cnrxitconsentforpublishing1"] = $_LANG["cnr1"];
$_LANG["cnrxitconsentforpublishingdescr"] = "لسماح بنشر البيانات الشخصية لجهات الاتصال. الرفض ممكن فقط إذا كان نوع الكيان أدناه هو 1.";
$_LANG["cnrxitentitytype"] = "نوع الكيان للمسجل";
$_LANG["cnrxitentitytype1"] = "[1] الأشخاص الطبيعيون الإيطاليون والأجانب";
$_LANG["cnrxitentitytype2"] = "[2] الشركات/الشركات الفردية";
$_LANG["cnrxitentitytype3"] = "[3] العاملون المستقلون/المهنيون";
$_LANG["cnrxitentitytype4"] = "[4] المنظمات غير الربحية";
$_LANG["cnrxitentitytype5"] = "[5] المنظمات العامة";
$_LANG["cnrxitentitytype6"] = "[6] جهات أخرى";
$_LANG["cnrxitentitytype7"] = "[7] الأجانب الذين ينتمون إلى الفئات 2-6";
$_LANG["cnrxitentitytypedescr"] = "نوع الكيان لتحديد نوع المسجل.";
$_LANG["cnrxitpin"] = "رقم التعريف الضريبي للمسجل";
//$_LANG["cnrxitpindescr"] = "";
$_LANG["cnrxitnationality"] = "جنسية المسجل";
$_LANG["cnrxitnationalitydescr"] = "جنسية المسجل المحددة بواسطة رمز الدولة المكون من حرفين ISO.";
//$_LANG["cnrxitsect3liability"] = "";
$_LANG["cnrxitsect3liabilitydescr"] = "";
$_LANG["cnrxitsect3liability0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect3liability1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect5personaldataforregistration"] = "";
$_LANG["cnrxitsect5personaldataforregistrationdescr"] = "";
$_LANG["cnrxitsect5personaldataforregistration0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect5personaldataforregistration1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect6personaldatafordiffusion"] = "";
$_LANG["cnrxitsect6personaldatafordiffusiondescr"] = "";
$_LANG["cnrxitsect6personaldatafordiffusion0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect6personaldatafordiffusion1"] = $_LANG["cnr1"];
//$_LANG["cnrxitsect7explicitacceptance"] = "";
$_LANG["cnrxitsect7explicitacceptancedescr"] = "";
$_LANG["cnrxitsect7explicitacceptance0"] = $_LANG["cnr0"];
$_LANG["cnrxitsect7explicitacceptance1"] = $_LANG["cnr1"];

// ----------------------------------------------------------------------
// ------------------ .LV Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxlvownerregnr"] = "المسجل، رقم التسجيل";
$_LANG["cnrxlvownerregnrdescr"] = "رقم تسجيل المواطن اللاتفي لاستخدامه في جهة اتصال المسجل (مثل رقم تسجيل الشركة)";
$_LANG["cnrxlvadminregnr"] = "المسؤول، رقم التسجيل";
$_LANG["cnrxlvadminregnrdescr"] = "رقم تسجيل المواطن اللاتفي لاستخدامه في جهة الاتصال الإدارية (مثل رقم تسجيل الشركة)";
$_LANG["cnrxlvvatnr"] = "المسجل، رقم ضريبة القيمة المضافة";
$_LANG["cnrxlvvatnrdescr"] = "رقم ضريبة القيمة المضافة لجهة اتصال المسجل (للشركات فقط).";

// ----------------------------------------------------------------------
// ------------------ .LT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxltcompanynumber"] = "المسجل، رقم الشركة";
$_LANG["cnrxltcompanynumberdescr"] = "";

// ----------------------------------------------------------------------
// ------------------ .MY Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxmybusinessnumber"] = "المسجل، رقم العمل";
$_LANG["cnrxmybusinessnumberdescr"] = "رقم تسجيل الأعمال للمسجل (للشركات فقط)";
$_LANG["cnrxmyorganizationtype"] = "المسجل، نوع المنظمة";
$_LANG["cnrxmyorganizationtypedescr"] = "نوع العمل للمسجل (للشركات فقط)";
$_LANG["cnrxmyperidentity"] = "المسجل، الهوية الشخصية";
$_LANG["cnrxmyperidentitydescr"] = "رقم الهوية الشخصية للمسجل (للأفراد فقط)";
$_LANG["cnrxmyperdateofbirth"] = "المسجل، تاريخ الميلاد";
$_LANG["cnrxmyperdateofbirthdescr"] = "تاريخ ميلاد المسجل (YYYY-MM-DD، للأفراد فقط)";
$_LANG["cnrxmyrace"] = "المسجل، العرق";
$_LANG["cnrxmyracemalay"] = "ماليزي";
$_LANG["cnrxmyracechinese"] = "صيني";
$_LANG["cnrxmyraceindian"] = "هندي";
$_LANG["cnrxmyraceothers"] = "آخرون";
$_LANG["cnrxmyracedescr"] = "(للأفراد فقط)";

// ----------------------------------------------------------------------
// ------------------ .NO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnoorganizationnumber"] = "المسجل، رقم المنظمة";
$_LANG["cnrxnoorganizationnumberdescr"] = "رقم السجل النرويجي الصادر عن السجل المركزي لتنسيق الكيانات القانونية.";
$_LANG["cnrxnopersonidentifier"] = "معرف الشخص في نوريد";
$_LANG["cnrxnopersonidentifierdescr"] = "معرف شخصي مطلوب لتسجيل اسم نطاق خاص .PRIV.NO. اتركه فارغًا في غير ذلك.";

// ----------------------------------------------------------------------
// ------------------ .NU Fields ----------------------------------------
// ----------------------------------------------------------------------
// see further .nu fields at the top of the file
$_LANG["cnrxnuiisidno"] = "المسجل، رقم الهوية";
$_LANG["cnrxnuiisidnodescr"] = "رقم الهوية الشخصية، رقم هوية الشركة أو تعيين التسجيل في سجل حكومي. بالنسبة للجهات الموجودة في السويد، يلزم وجود رقم هوية سويدي صالح (مثل: 123456-1234).";
$_LANG["cnrxnuiisvatno"] = "المسجل، رقم ضريبة القيمة المضافة";
$_LANG["cnrxnuiisvatnodescr"] = "رقم ضريبة القيمة المضافة للمسجل (للشركات فقط)";

// ----------------------------------------------------------------------
// ------------------ .NYC Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnycextcontact"] = "جهة الاتصال الخارجية في نيويورك";
$_LANG["cnrxnycextcontactadmin"] = "جهة الاتصال الإدارية";
$_LANG["cnrxnycextcontacttech"] = "جهة الاتصال التقنية";
$_LANG["cnrxnycextcontactbilling"] = "جهة الاتصال بالفواتير";
$_LANG["cnrxnycextcontactowner"] = "جهة الاتصال بالمسجل";
$_LANG["cnrxnycextcontactdescr"] = "يجب أن يكون لدى جهة الاتصال المحددة عنوان فعلي صالح في مدينة نيويورك.";

// ----------------------------------------------------------------------
// ------------------ .PARIS Fields -------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxafniccode"] = $_LANG["cnrxallocationtoken"];
$_LANG["cnrxafniccodedescr"] = $_LANG["cnrxallocationtokendescr"];

// ----------------------------------------------------------------------
// ------------------ .FR, .PM, .RE, .TF, .WF, .YT Fields ---------------
// ----------------------------------------------------------------------
// Organizations (Companies, Associations, etc.)
$_LANG["cnrxfrannounce"] = "المنظمة/الشركة، رقم الإعلان<br/>(الجريدة الرسمية)";
$_LANG["cnrxfrannouncedescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط (الجمعيات/الشركات). اتركه فارغًا للأفراد.",
    "رقم الإعلان في الجريدة الرسمية (أرقام فقط).",
    "إذا كنت تستخدم بيانات الجريدة الرسمية كمعرّف، يرجى إدخال جميع حقول JO المرتبطة:",
    "تاريخ النشر، رقم الإعلان، رقم الصفحة وتاريخ الجمعية."
]));
$_LANG["cnrxfrdatepublicationjo"] = "المنظمة/الشركة، تاريخ النشر<br/>(الجريدة الرسمية)";
$_LANG["cnrxfrdatepublicationjodescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط (الجمعيات/الشركات). اتركه فارغًا للأفراد.",
    "تاريخ النشر في الجريدة الرسمية.",
    "صيغة التاريخ YYYY-MM-DD.",
    "إذا كنت تستخدم بيانات الجريدة الرسمية كمعرّف، يرجى إدخال جميع حقول JO المرتبطة:",
    "تاريخ النشر، رقم الإعلان، رقم الصفحة وتاريخ الجمعية."
]));
$_LANG["cnrxfrnumerodepageannouncejo"] = "الشركة، رقم صفحة الإعلان<br/>(الجريدة الرسمية)";
$_LANG["cnrxfrnumerodepageannouncejodescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط (الجمعيات/الشركات). اتركه فارغًا للأفراد.",
    "رقم صفحة الإعلان في الجريدة الرسمية (أرقام فقط).",
    "إذا كنت تستخدم بيانات الجريدة الرسمية كمعرّف، يرجى إدخال جميع حقول JO المرتبطة:",
    "تاريخ النشر، رقم الإعلان، رقم الصفحة وتاريخ الجمعية."
]));
$_LANG["cnrxfrwaldec"] = "المنظمة/الشركة، معرف Waldec (للجمعيات)";
$_LANG["cnrxfrwaldecdescr"] = implode(" ", array_reverse([
    "<br/>للجمعيات فقط. اتركه فارغًا للأفراد.",
    "معرف Waldec المرتبط بجمعية (أرقام فقط).",
    "إذا تم إدخاله فهو كافٍ لتحديد الجمعية.",
    "ملاحظة: عادةً يكفي مُعرّف واحد؛ إذا أدخلت Waldec يمكنك ترك بقية معرّفات المنظمة فارغة (SIREN/SIRET، VAT ID، DUNS، العلامة التجارية، المعرف المحلي، حقول الجريدة الرسمية)."
]));
$_LANG["cnrxfrdateassociation"] = "الشركة، تاريخ الجمعية";
$_LANG["cnrxfrdateassociationdescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط (الجمعيات/الشركات). اتركه فارغًا للأفراد.",
    "صيغة التاريخ YYYY-MM-DD.",
    "مطلوب عند إدخال بيانات الجريدة الرسمية (رقم الإعلان، رقم الصفحة، تاريخ النشر)."
]));
$_LANG["cnrxfrduns"] = "الشركة، رقم DUNS";
$_LANG["cnrxfrdunsdescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط. اتركه فارغًا للأفراد.",
    "رقم DUNS هو معرف فريد مكون من تسعة أرقام للشركات. اختصار لنظام الترقيم العالمي للبيانات؛",
    "يشير إلى معرف جديد يمكن إرساله للتحقق من الأهلية",
    "على المستوى الأوروبي.",
    "ملاحظة: عادةً يكفي مُعرّف واحد (مثل SIREN/SIRET أو VAT ID أو DUNS أو العلامة التجارية أو المعرف المحلي أو Waldec أو حقول الجريدة الرسمية)."
]));
$_LANG["cnrxfrlocal"] = "الشركة، معرف محلي";
$_LANG["cnrxfrlocaldescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط. اتركه فارغًا للأفراد.",
    "معرف محلي خاص بدولة من المنطقة الاقتصادية الأوروبية (مثل رقم شهادة الأعمال).",
    "ملاحظة: عادةً يكفي مُعرّف واحد (مثل SIREN/SIRET أو VAT ID أو DUNS أو العلامة التجارية أو المعرف المحلي أو Waldec أو حقول الجريدة الرسمية)."
]));
$_LANG["cnrxfrnoprezonecheck0"] = $_LANG["cnr0"];
$_LANG["cnrxfrnoprezonecheck1"] = $_LANG["cnr1"];
$_LANG["cnrxfrsirenorsiret"] = "الشركة، رقم SIREN/SIRET";
$_LANG["cnrxfrsirenorsiretdescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط. اتركه فارغًا للأفراد.",
    "أدخله إذا كنت تسجل كمنظمة/شركة في فرنسا ولديك رقم SIREN/SIRET صالح.",
    "ملاحظة: عادةً يكفي مُعرّف واحد؛ إذا أدخلت SIREN/SIRET يمكنك ترك VAT ID وDUNS والعلامة التجارية والمعرف المحلي وWaldec وحقول الجريدة الرسمية فارغة.",
    "رمز SIREN هو رقم تعريف الأعمال الفريد في فرنسا. يتم إصداره من قبل",
    "المعهد الوطني للإحصاء والدراسات الاقتصادية (INSEE) ويتكون من 9 أرقام.",
    "الأرقام التسعة الأولى هي رقم SIREN والأرقام الخمسة التالية هي رقم NIC",
    "(رقم التصنيف الداخلي). يتم إصدار رقم SIRET بمجرد تسجيل عملك",
    "مع غرفة التجارة (RCS) للتجارة، غرفة الحرف للأعمال اليدوية",
    "أو مع URSSAF للخدمات الفكرية. تتكون أرقام SIRET من 14",
    "رقمًا. يوفر رقم SIRET معلومات حول موقع العمل في فرنسا",
    "(للشركات القائمة). يجب أن يكون اسم الشركة المقدم في تفاصيل الاتصال بالمسجل",
    "مطابقًا تمامًا لما هو موضح في قاعدة بيانات SIREN/SIRET ( https://www.infogreffe.fr/ )."
]));
$_LANG["cnrxfrtrademark"] = "الشركة، رقم العلامة التجارية";
$_LANG["cnrxfrtrademarkdescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط. اتركه فارغًا للأفراد.",
    "رقم العلامة التجارية (إذا كان التسجيل بناءً على حقوق العلامة التجارية).",
    "ملاحظة: عادةً يكفي مُعرّف واحد؛ إذا أدخلت رقم علامة تجارية يمكنك ترك SIREN/SIRET وVAT ID وDUNS والمعرف المحلي وWaldec وحقول الجريدة الرسمية فارغة."
]));
$_LANG["cnrxfrvatid"] = "المنظمة/الشركة، VAT ID";
$_LANG["cnrxfrvatiddescr"] = implode(" ", array_reverse([
    "<br/>للمنظمات/الشركات فقط. اتركه فارغًا للأفراد.",
    "VAT ID (إن وجد).",
    "ملاحظة: عادةً يكفي مُعرّف واحد؛ إذا أدخلت VAT ID يمكنك ترك SIREN/SIRET وDUNS والعلامة التجارية والمعرف المحلي وWaldec وحقول الجريدة الرسمية فارغة."
]));

// Individual
$_LANG["cnrxfrbirthpc"] = "المسجل، الرمز البريدي (مدينة الميلاد)";
$_LANG["cnrxfrbirthpcdescr"] = implode(" ", array_reverse([
    "<br/>للأفراد فقط (أشخاص طبيعيون). اتركه فارغًا للمنظمات/الشركات.",
    "مطلوب فقط للأشخاص المولودين في فرنسا أو الأقاليم الفرنسية فيما وراء البحار (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "يرجى تقديم الرمز البريدي لمكان الميلاد (أو على الأقل رمز المقاطعة)."
]));
$_LANG["cnrxfrbirthcity"] = "المسجل، مدينة الميلاد";
$_LANG["cnrxfrbirthcitydescr"] = implode(" ", array_reverse([
    "<br/>للأفراد فقط (أشخاص طبيعيون). اتركه فارغًا للمنظمات/الشركات.",
    "مطلوب فقط للأشخاص المولودين في فرنسا أو الأقاليم الفرنسية فيما وراء البحار (FR, RE, MQ, GP, GF, TF, NC, PF, WF, PM, YT).",
    "يرجى تقديم اسم المدينة."
]));
$_LANG["cnrxfrbirthdate"] = "المسجل، تاريخ الميلاد";
$_LANG["cnrxfrbirthdatedescr"] = "للأفراد فقط (أشخاص طبيعيون).<br/>تاريخ الميلاد بصيغة YYYY-MM-DD. اتركه فارغًا للمنظمات/الشركات.";
$_LANG["cnrxfrbirthplace"] = "المسجل، بلد الميلاد";
$_LANG["cnrxfrbirthplacedescr"] = "للأفراد فقط (أشخاص طبيعيون).<br/>رمز بلد مكان الميلاد (مثل FR, DE). اتركه فارغًا للمنظمات/الشركات.";
$_LANG["cnrxfrrestrictpub"] = "المسجل، تقييد النشر (WHOIS)";
$_LANG["cnrxfrrestrictpub0"] = $_LANG["cnr0"];
$_LANG["cnrxfrrestrictpub1"] = $_LANG["cnr1"];
$_LANG["cnrxfrrestrictpubdescr"] = "للأفراد فقط (أشخاص طبيعيون). اختر 'نعم' لتقييد النشر وإخفاء البيانات الشخصية في WHOIS.";
$_LANG["cnrxfrnoprezonecheck"] = "تعطيل التحقق المسبق من DNS";
$_LANG["cnrxfrnoprezonecheckdescr"] = "يحدد ما إذا كان النظام يجب أن يقوم بالتحقق المسبق من DNS قبل إرسال الأمر إلى السجل.";

// ----------------------------------------------------------------------
// ------------------ .PT Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxpttechidentification"] = "جهة الاتصال التقنية، رقم ضريبة القيمة المضافة";
$_LANG["cnrxpttechidentificationdescr"] = "رقم التعريف الضريبي لجهة الاتصال التقنية";
$_LANG["cnrxptowneridentification"] = "المسجل، رقم ضريبة القيمة المضافة";
$_LANG["cnrxptowneridentificationdescr"] = "رقم التعريف الضريبي للمسجل";
$_LANG["cnrxpttechmobile"] = "جهة الاتصال التقنية، رقم الهاتف المحمول";
$_LANG["cnrxpttechmobiledescr"] = "رقم الهاتف المحمول لجهة الاتصال التقنية";
$_LANG["cnrxptownermobile"] = "المسجل، رقم الهاتف المحمول";
$_LANG["cnrxptownermobiledescr"] = "رقم الهاتف المحمول للمسجل";

// ----------------------------------------------------------------------
// ------------------ .RO Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrocompanynumber"] = "المسجل، رقم الشركة";
$_LANG["cnrxrocompanynumberdescr"] = "(مطلوب للشركات فقط)";
$_LANG["cnrxroidcardorpassportnumber"] = "المسجل، رقم بطاقة الهوية أو جواز السفر";
$_LANG["cnrxroidcardorpassportnumberdescr"] = "(مطلوب للأفراد فقط)";
$_LANG["cnrxrovatnumber"] = "المسجل، رقم ضريبة القيمة المضافة";
$_LANG["cnrxrovatnumberdescr"] = "(مطلوب للشركات فقط)";

// ----------------------------------------------------------------------
// ------------------ .RU Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxrubirthdate"] = "المسجل، تاريخ الميلاد";
$_LANG["cnrxrubirthdatedescr"] = "تاريخ ميلاد المسجل (DD.MM.YYYY)<br/>(مطلوب للأفراد فقط)";
$_LANG["cnrxrufirstname"] = "المسجل، الاسم الأول";
$_LANG["cnrxrufirstnamedescr"] = "الاسم الأول للمسجل باللغة الروسية. يجب أن يحتوي على أحرف روسية ولاتينية، بدون نقاط.<br/>(مطلوب للأفراد فقط)";
$_LANG["cnrxrumiddlename"] = "المسجل، الاسم الأوسط";
$_LANG["cnrxrumiddlenamedescr"] = "الاسم الأوسط للمسجل باللغة الروسية. يجب أن يحتوي على أحرف روسية ولاتينية، بدون نقاط.<br/>(مطلوب للأفراد فقط)";
$_LANG["cnrxrulastname"] = "المسجل، اسم العائلة";
$_LANG["cnrxrulastnamedescr"] = "اسم العائلة للمسجل باللغة الروسية. يجب أن يحتوي على أحرف روسية ولاتينية، بدون نقاط.<br/>(مطلوب للأفراد فقط)";
$_LANG["cnrxruorganization"] = "المسجل، اسم المنظمة";
$_LANG["cnrxruorganizationdescr"] = "اسم المنظمة للمسجل باللغة الروسية. يمكن أن يحتوي هذا الحقل على أحرف روسية ولاتينية، أرقام، علامات ترقيم ومسافات.<br/>(مطلوب للمنظمات المسجلة في الاتحاد الروسي فقط)";
$_LANG["cnrxrucode"] = "المسجل، رقم التعريف الضريبي";
$_LANG["cnrxrucodedescr"] = "رقم التعريف الضريبي (TIN) للمسجل. يجب أن يحتوي هذا الحقل على رقم مكون من عشرة أرقام (الرقم الأخير هو رقم تحكم).<br/>(مطلوب للمنظمات المسجلة في الاتحاد الروسي فقط)";
$_LANG["cnrxrukpp"] = "المسجل، رمز السبب";
$_LANG["cnrxrukppdescr"] = "رمز السبب (KPP) للمسجل. يجب أن يحتوي هذا الحقل على رقم مكون من تسعة أرقام.<br/>(مطلوب للمنظمات المسجلة في الاتحاد الروسي فقط)";
$_LANG["cnrxrupassportdata"] = "المسجل، بيانات جواز السفر";
$_LANG["cnrxrupassportdatadescr"] = "بيانات جواز السفر للمسجل. يجب أن يحتوي هذا الحقل على أحرف روسية ولاتينية، أرقام، علامات ترقيم ومسافات. التنسيق: رقم الوثيقة، الجهة المصدرة، تاريخ الإصدار<br/>(مطلوب للأفراد فقط)";

// ----------------------------------------------------------------------
// ------------------ .SE Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxnicseidnumber"] = "المسجل، رقم الهوية";
$_LANG["cnrxnicseidnumberdescr"] = "رقم الهوية الشخصية أو التنظيمية.";
$_LANG["cnrxnicsevatid"] = "المسجل، رقم ضريبة القيمة المضافة";
$_LANG["cnrxnicsevatiddescr"] = "";
$_LANG["cnrxsediscloseemail"] = "المسجل، الكشف عن البريد الإلكتروني";
$_LANG["cnrxsediscloseemaildescr"] = "السماح بالكشف عن عنوان البريد الإلكتروني للمسجل في قاعدة بيانات WHOIS العامة.";
$_LANG["cnrxsedisclosefax"] = "المسجل، الكشف عن الفاكس";
$_LANG["cnrxsedisclosefaxdescr"] = "السماح بالكشف عن رقم الفاكس للمسجل في قاعدة بيانات WHOIS العامة.";
$_LANG["cnrxsedisclosevoice"] = "المسجل، الكشف عن الهاتف";
$_LANG["cnrxsedisclosevoicedescr"] = "السماح بالكشف عن رقم الهاتف للمسجل في قاعدة بيانات WHOIS العامة.";
foreach (["email", "fax", "voice"] as $field) {
    $_LANG["cnrxsedisclose$field" . "0"] = $_LANG["cnr0"];
    $_LANG["cnrxsedisclose$field" . "1"] = $_LANG["cnr1"];
}

// ----------------------------------------------------------------------
// ------------------ .SG Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxsgrcbid"] = "المسجل، معرف RCB";
$_LANG["cnrxsgrcbiddescr"] = "رقم الكيان الفريد (UEN) أو رقم الشركة المسجلة (RCB) للمسجل. بالنسبة <u>للشركات</u> الموجودة في سنغافورة، يجب تحديد رقم تسجيل الشركة المقابل أو بطاقة هوية الاتصال للحضور المحلي في سنغافورة (التنسيق: S1234567D).";
$_LANG["cnrxsgadminsingpassid"] = "المسؤول، معرف SingPass";
$_LANG["cnrxsgadminsingpassiddescr"] = "بطاقة هوية الاتصال (معرف SingPass) لجهة الاتصال الإدارية<br/>(للفرد السنغافوري <u>الأفراد</u> فقط، التنسيق: S1234567D)";

// ----------------------------------------------------------------------
// ------------------ .SK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxskcontactlegalform"] = "المسجل، الشكل القانوني";
$_LANG["cnrxskcontactlegalformdescr"] = "";
// $_LANG["cnrxskcontactlegalformcorp"] = "";
// $_LANG["cnrxskcontactlegalformpers"] = "";
$_LANG["cnrxskcontactidentnumber"] = "المسجل، رقم الشركة";
$_LANG["cnrxskcontactidentnumberdescr"] = "رقم السجل التجاري. إلزامي للشركات/المنظمات";

// ----------------------------------------------------------------------
// ------------------ .SWISS Fields -------------------------------------
// ----------------------------------------------------------------------
// see other .swiss fields at top of the file
$_LANG["cnrxswissuid"] = "المسجل، UID أو UPI";
$_LANG["cnrxswissuiddescr"] = implode("", array_reverse([
    "المعرف ...<ul>",
    "<li>UID (رقم التعريف الفريد، التنسيق: \"CHE-ddd.ddd.ddd\") للمنظمات أو</li>",
    "<li>UPI (معرف الشخص العالمي، التنسيق: \"756.dddd.dddd.dd\") للأشخاص الطبيعيين</li>",
    "</ul>... للمسجل (d = رقم).<br/>",
    "يرجى ملاحظة: لا يتم نشر اسم الشخص وUPI في Whois/RDAP على عكس اسم المنظمة وUID، التي تكون مرئية."
]));
$_LANG["cnrxswissownertype"] = "المسجل، النوع";
$_LANG["cnrxswissownertypep"] = "شخص طبيعي";
$_LANG["cnrxswissownertypeo"] = "منظمة / كيان قانوني";
$_LANG["cnrxswissownertypedescr"] = "نوع هوية المسجل.";

// ----------------------------------------------------------------------
// ------------------ .TRAVEL Fields ------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxtravelindustry"] = "صناعة السفر";
$_LANG["cnrxtravelindustryn"] = $_LANG["cnr0"];
$_LANG["cnrxtravelindustryy"] = $_LANG["cnr1"];
$_LANG["cnrxtravelindustrydescr"] = "أؤكد أن المسجل عضو في صناعة السفر ولديه معرف عضوية صالح.";

// ----------------------------------------------------------------------
// ------------------ .UK Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxukownercorporatetype"] = "المسجل، نوع الشركة";
$_LANG["cnrxukownercorporatetypedescr"] = "";
$_LANG["cnrxukownercorporatetypeother"] = "أخرى";
$_LANG["cnrxukownercorporatetypefother"] = "أخرى (غير بريطانية)";
$_LANG["cnrxukownercorporatetypeind"] = "فرد";
$_LANG["cnrxukownercorporatetypefind"] = "فرد (غير بريطاني)";
$_LANG["cnrxukownercorporatetypefcorp"] = "شركة (غير بريطانية)";
// $_LANG["cnrxukownercorporatetypeltd"] = "LTD";
// $_LANG["cnrxukownercorporatetypeplc"] = "PLC";
// $_LANG["cnrxukownercorporatetypellp"] = "LLP";
// $_LANG["cnrxukownercorporatetypeip"] = "IP";
$_LANG["cnrxukownercorporatetypecrc"] = "شركة بموجب الميثاق الملكي";
$_LANG["cnrxukownercorporatetypegov"] = "هيئة حكومية";
$_LANG["cnrxukownercorporatetypeptnr"] = "شراكة بريطانية";
$_LANG["cnrxukownercorporatetyperchar"] = "جمعية خيرية مسجلة";
$_LANG["cnrxukownercorporatetypesch"] = "مدرسة";
$_LANG["cnrxukownercorporatetypestat"] = "هيئة قانونية";
$_LANG["cnrxukownercorporatetypestra"] = "تاجر فردي";
$_LANG["cnrxukownercorporatenumber"] = "المسجل، رقم الشركة";
$_LANG["cnrxukownercorporatenumberdescr"] = "رقم تسجيل الشركات في المملكة المتحدة";

// ----------------------------------------------------------------------
// ------------------ .US Fields ----------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxusnexusapppurpose"] = "الغرض من التطبيق، US Nexus";
$_LANG["cnrxusnexusapppurposep1"] = "استخدام الأعمال للربح";
$_LANG["cnrxusnexusapppurposep2"] = "منظمة غير ربحية، نادي، جمعية، منظمة دينية، إلخ.";
$_LANG["cnrxusnexusapppurposep3"] = "استخدام شخصي";
$_LANG["cnrxusnexusapppurposep4"] = "أغراض تعليمية";
$_LANG["cnrxusnexusapppurposep5"] = "أغراض حكومية";
$_LANG["cnrxusnexusapppurposedescr"] = "";
$_LANG["cnrxusnexuscategory"] = "US Nexus، الفئة";
$_LANG["cnrxusnexuscategoryc11"] = "[C11] مواطن أمريكي";
$_LANG["cnrxusnexuscategoryc12"] = "[C12] مقيم دائم في الولايات المتحدة";
$_LANG["cnrxusnexuscategoryc21"] = "[C21] منظمة أمريكية";
$_LANG["cnrxusnexuscategoryc31"] = "[C31] كيان أجنبي لديه أنشطة في الولايات المتحدة";
$_LANG["cnrxusnexuscategoryc32"] = "[C32] كيان أجنبي لديه مكتب في الولايات المتحدة";
$_LANG["cnrxusnexuscategorydescr"] = "تصنيف الكيان الذي يطلب التطبيق.<br/>ملاحظة: تعتبر ممتلكات وأقاليم الولايات المتحدة مشمولة أيضًا.";
$_LANG["cnrxusnexusvalidator"] = "US Nexus، البلد";
$_LANG["cnrxusnexusvalidatordescr"] = "حدد رمز البلد المكون من حرفين للمسجل (إذا كانت فئة Nexus هي C31 أو C32)";

// ----------------------------------------------------------------------
// ------------------ .XXX Fields ---------------------------------------
// ----------------------------------------------------------------------
$_LANG["cnrxxxxcommunityid"] = "معرف عضو المجتمع";
$_LANG["cnrxxxxcommunityiddescr"] = "معرف عضو المجتمع المدعوم .XXX";
$_LANG["cnrxxxxdefensive"] = "تسجيل دفاعي<br/>(نطاق غير قابل للحل)";
$_LANG["cnrxxxxdefensive0"] = $_LANG["cnr0"];
$_LANG["cnrxxxxdefensive1"] = $_LANG["cnr1"];
$_LANG["cnrxxxxdefensivedescr"] = implode("", array_reverse([
    "أؤكد أن النطاق هو تسجيل دفاعي. ",
    "يشير التسجيل الدفاعي إلى تسجيل أسماء النطاقات، ",
    "غالبًا عبر نطاقات المستوى الأعلى المتعددة وفي تنسيقات نحوية متنوعة، ",
    "لغرض أساسي هو حماية الملكية الفكرية أو العلامة التجارية من الإساءة، ",
    "مثل الاستيلاء على النطاقات. يتم تعريفه على أنه تسجيل غير فريد، لا يمكن حله، ",
    "يعيد توجيه حركة المرور إلى تسجيل أساسي أو لا يحتوي على محتوى فريد.<br/>",
    "ملاحظة: إذا لم يتم التحديد، سيتم اعتبار النطاق تسجيلًا دفاعيًا."
]));

// #########################################################################
// #########################################################################
// # Add reusable translations for ALL PROVIDERS                           #
// #########################################################################
// #########################################################################

/// ----------------------------------------------------------------------
// ---------------- EMAIL VERIFICATION ----------------------------------
// ----------------------------------------------------------------------
// $_LANG["cnicemailverification"] = "التحقق من البريد الإلكتروني";
// $_LANG["emailverificationtitle"] = "تحقق من بريدك الإلكتروني";
// $_LANG["emailverificationinfo"] = "مطلوب التحقق من معلومات الاتصال التالية";
// $_LANG["emailverificationconsequences"] = "قد يؤدي عدم التحقق من بريدك الإلكتروني إلى تعليق نطاقك.";
// $_LANG["emailverificationresendemailinfo"] = "إذا لم تستلم البريد الإلكتروني، يرجى النقر على الزر أدناه لإعادة إرسال بريد التحقق.";
// $_LANG["verified"] = "تم التحقق";
// $_LANG["emailverificationpending"] = "قيد الانتظار";

// ----------------------------------------------------------------------
// ----------------------- DNSSEC MANAGEMENT ----------------------------
// ----------------------------------------------------------------------
$_LANG["cnicdnssecmanagement"] = "إدارة DNSSEC";

// رسائل الحالة
$_LANG["dnssecautomaticupdatesuccessmsg"] = "تم <span style=\"color:green;font-weight:bold;\">تفعيل</span> DNSSEC لنطاقك.<br> تم استيراد سجلات DNSSEC من منطقة DNS الخاصة بك وتحديثها لدى مسجل النطاق الخاص بك.<br><br><span style=\"color:#007bff;\">لأمانك، يساعد DNSSEC في حماية نطاقك من أنواع معينة من الهجمات عن طريق التحقق من استجابات DNS.</span>";
$_LANG["dnssecautoenable"] = "تفعيل DNSSEC واستيراد سجلات DNSSEC تلقائيًا من منطقة DNS";
$_LANG["dnssecsyncrecords"] = "مزامنة سجلات DNSSEC من منطقة DNS";

// إدارة السجلات
$_LANG["dnssecaddnewdskey"] = "إضافة مفتاح DS جديد";
$_LANG["dnssecaddnewkeyrecord"] = "إضافة سجل مفتاح جديد";

// مربع الحوار
$_LANG["dnssecconfirmdisable"] = "هل أنت متأكد أنك تريد تعطيل DNSSEC لهذا النطاق؟ قد يؤثر هذا الإجراء على حل النطاق.";
$_LANG["dnssecmodaltitle"] = "تعطيل DNSSEC";
$_LANG["dnssecmodalcancel"] = "إلغاء";
$_LANG["dnssecmodaldisable"] = "تعطيل DNSSEC";
