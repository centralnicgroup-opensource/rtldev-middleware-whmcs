// ui.js: UI enhancements and accessibility for CentralNic Config
$(document).ready(function () {
    // Initialize UI components
    initUiEnhancements();
    // Ensure keyboard accessibility
    enhanceKeyboardAccessibility();
    // Field focus/blur highlighting
    initFieldInteractions();

    // Add special handling for the TLD lookup form
    setupTldLookupInteractions();
});

// Additional function to ensure proper form interactions
function setupTldLookupInteractions() {
    // Fix input group styling when selectize is inside
    $('#lookupFieldsForm .input-group').each(function () {
        var $this = $(this);

        // Add proper classes to selectize control's parent
        if ($this.find('.selectize-control').length) {
            $this.addClass('has-selectize');
        }

        // Fix z-index issues with the dropdown
        $(window).on('resize', function () {
            var $selectizeDropdown = $('.selectize-dropdown');
            if ($selectizeDropdown.length && $selectizeDropdown.is(':visible')) {
                var selectize = $('#tldInput')[0].selectize;
                if (selectize) {
                    selectize.close();
                    selectize.open();
                }
            }
        });
    });

    // Ensure proper click handling for Bootstrap dropdowns
    $(document).on('shown.bs.dropdown', function () {
        // Close any open selectize dropdown when a Bootstrap dropdown opens
        var selectize = $('#tldInput')[0].selectize;
        if (selectize) {
            selectize.close();
        }
    });
}

function initUiEnhancements() {
    if ($("h1").length > 0 && $("h1").text().trim() === "CNIC Configuration") {
        $("h1").remove();
    }

    // Initialize Selectize for TLD input with enhanced options
    var $tldInput = $("#tldInput").selectize({
        selectOnTab: true,
        allowEmptyOption: false,
        dropdownParent: "body",
        searchField: ['text', 'value'],
        closeAfterSelect: true,
        onType: function (str) {
            var self = this;
            setTimeout(function () {
                var $content = self.$dropdown.find('.selectize-dropdown-content');

                if (!$content.length) return;

                // Remove existing message
                $content.find('.no-results').remove();

                // Check for actual options
                var hasOptions = $content.children(':not(.no-results)').length > 0;

                if (!hasOptions && str.length > 0) {
                    // Add message
                    $content.append('<div class="no-results">No results found</div>');

                    // Force dropdown open
                    self.$dropdown.css('display', 'block');
                    self.$dropdown.addClass('active'); // optional, for styling

                    // Adjust positioning manually if needed
                    self.positionDropdown();
                }
            }, 10); // slight delay to let search filter apply
        },
        onClear: function () {
            var self = this;
            self.$dropdown.find('.no-results').remove();
        },
        onDropdownOpen: function ($dropdown) {
            // Add animation when dropdown opens
            $dropdown.hide().fadeIn(150);
            // Announce to screen readers
            $dropdown.attr('aria-expanded', 'true');
            // Improved positioning for all screen sizes
            setTimeout(function () {
                const inputPos = this.$wrapper[0].getBoundingClientRect();
                const viewportHeight = window.innerHeight;
                const spaceBelow = viewportHeight - inputPos.bottom;
                const minSpace = 250; // Minimum space needed for dropdown

                // Position dropdown based on available space
                if (window.innerWidth < 768) {
                    // Mobile positioning - fixed position aligned with input
                    $dropdown.css({
                        'position': 'fixed',
                        'top': inputPos.bottom + window.scrollY + 'px',
                        'left': inputPos.left + window.scrollX + 'px',
                        'width': inputPos.width + 'px',
                        'max-width': 'calc(100vw - 30px)'
                    });
                } else if (spaceBelow < minSpace && inputPos.top > minSpace) {
                    // Show above if there's not enough space below but enough above
                    $dropdown.css({
                        'top': 'auto',
                        'bottom': '100%',
                        'border-top': '1px solid #1a5b98',
                        'border-bottom': '0',
                        'border-radius': '3px 3px 0 0',
                        'margin': '0 0 -1px 0'
                    });
                }

                // Ensure the dropdown is fully visible
                const dropdownRect = $dropdown[0].getBoundingClientRect();
                const overflowRight = dropdownRect.right - window.innerWidth;
                if (overflowRight > 0) {
                    $dropdown.css('left', (parseInt($dropdown.css('left'), 10) - overflowRight - 10) + 'px');
                }
            }.bind(this), 0);
        },
        onItemAdd: function(value, $item) {
            // Automatically trigger the lookupFieldsButton click
            $('#lookupFieldsButton').trigger('click');
        }
    });

    // Attach onInitialize event handler after initialization
    let selectizeInstance = $tldInput[0]?.selectize;  
    if (!selectizeInstance) {
        console.log("Selectize instance not found for #tldInput");
        return;
    }
    selectizeInstance.on('initialize', function () {
        var self = this;

        // Add ARIA attributes for accessibility
        self.$control_input.attr('aria-controls', 'selectize-dropdown');
        self.$dropdown.attr('id', 'selectize-dropdown');
        self.$dropdown.attr('aria-label', 'Available TLDs');
        // Improve mobile experience
        if ('ontouchstart' in window) {
            self.$wrapper.addClass('touch-device');
        }
        // Special fix for input group styling in the screenshot
        if (self.$input.closest('.input-group').length) {
            var $inputGroup = self.$input.closest('.input-group');
            var isBetweenElements = $inputGroup.find('.input-group-addon').length && $inputGroup.find('.input-group-btn').length;
            if (isBetweenElements) {
                self.$wrapper.addClass('selectize-between-elements');
                setTimeout(function () {
                    $inputGroup.find('.input-group-addon').css('z-index', '3');
                    $inputGroup.find('.input-group-btn').css('z-index', '3');
                }, 0);
            }
        }
    });

    // Focus handling is now managed in the Selectize initialization
}

function enhanceKeyboardAccessibility() {
    $(document).on('keydown', '.field-row', function (e) {
        if (e.key === 'ArrowDown') {
            $(this).next('.field-row').find('.form-control').focus();
        } else if (e.key === 'ArrowUp') {
            $(this).prev('.field-row').find('.form-control').focus();
        }
    });
    $('.btn, select, input').attr('tabindex', '0');
}

function initFieldInteractions() {
    $(document).off('focus.fieldHighlight', '.form-control');
    $(document).off('blur.fieldHighlight', '.form-control');
    $(document).on('focus.fieldHighlight', '.form-control', function () {
        $(this).closest('.field-row').addClass('active');
    });
    $(document).on('blur.fieldHighlight', '.form-control', function () {
        $(this).closest('.field-row').removeClass('active');
    });
    $('.field-label').each(function () {
        let id = $(this).attr('for');
        if (id) {
            $('#' + id).attr('aria-labelledby', $(this).attr('id') || '');
        }
    });
}
