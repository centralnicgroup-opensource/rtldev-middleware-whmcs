/**
 * CentralNic Domain Expiry Sync - Main Entry Point
 * Loads all modules and initializes the application
 * 
 * This is the main file that should be included in your HTML.
 * It loads all the required modules in the correct order.
 */

// Module loading order is important for dependencies
const SYNC_MODULES = [
    'AlertManager.js',
    'UIManager.js', 
    'DomainManager.js',
    'TableManager.js',
    'NavigationManager.js',
    'SyncEngine.js',
    'SyncApp.js'
];

// Base path for sync modules
const SYNC_MODULE_PATH = '/resources/cnic/assets/js/cnicadmin/sync/';

/**
 * Load all sync modules dynamically
 */
function loadSyncModules() {
    let loadedModules = 0;
    const totalModules = SYNC_MODULES.length;
    
    // Function to load next module
    function loadNextModule() {
        if (loadedModules >= totalModules) {
            console.log('All sync modules loaded successfully');
            return;
        }
        
        const modulePath = SYNC_MODULE_PATH + SYNC_MODULES[loadedModules];
        const script = document.createElement('script');
        
        script.src = modulePath + '?ts=' + Date.now(); // Cache busting
        script.type = 'text/javascript';
        
        script.onload = function() {
            console.log('Loaded sync module:', SYNC_MODULES[loadedModules]);
            loadedModules++;
            loadNextModule(); // Load next module
        };
        
        script.onerror = function() {
            console.error('Failed to load sync module:', SYNC_MODULES[loadedModules]);
            loadedModules++;
            loadNextModule(); // Continue loading other modules
        };
        
        document.head.appendChild(script);
    }
    
    // Start loading modules
    loadNextModule();
}

// Check if jQuery is available
if (typeof jQuery === 'undefined') {
    console.error('jQuery is required for CentralNic Sync modules');
} else {
    // Load modules when DOM is ready
    $(document).ready(function() {
        loadSyncModules();
    });
}
