// ajax.js: AJAX for TLD lookup and field saving for CentralNic Config
$(document).ready(function () {
    // Lookup Fields Button Handler
    $("#lookupFieldsButton").on("click", function () {
        // Get value from Selectize if available, otherwise fallback to standard select
        let tld;
        if ($("#tldInput")[0].selectize) {
            tld = $("#tldInput")[0].selectize.getValue().trim();
        } else {
            tld = $("#tldInput").val().trim();
        }

        $('#alertContainer').empty();
        if (!validateTld(tld)) {
            showAlert('danger', '<strong>Error:</strong> Please enter a valid TLD (e.g., .it)');
            if ($("#tldInput")[0].selectize) {
                $("#tldInput")[0].selectize.focus();
            } else {
                $("#tldInput").focus();
            }
            return;
        }
        // Clean up old container if it exists, otherwise create a new one
        if ($("#fieldsContainer").length === 0) {
            $("#tldFields").wrap('<div id="fieldsContainer" class="fields-wrapper"></div>');
        }

        const currentHeight = $("#fieldsContainer").height();
        // Set a reasonable minimum height for the container
        if (currentHeight > 100) {
            $("#fieldsContainer").css('min-height', currentHeight + 'px');
        } else {
            $("#fieldsContainer").css('min-height', '300px');
        }

        // Fade existing content if present
        if ($("#tldFields").children().length > 0) {
            $("#tldFields").fadeTo(200, 0.3);
        }

        // Show loading indicator
        $("#loadingIndicator").appendTo("#fieldsContainer").css({
            'position': currentHeight > 100 ? 'absolute' : 'relative',
            'top': '50%',
            'left': '50%',
            'transform': 'translate(-50%, -50%)',
            'z-index': 100,
            'width': '100%',
            'background': 'rgba(255,255,255,0.7)'
        }).fadeIn(200);
        $.ajax({
            url: window.location.href,
            type: "POST",
            data: {
                action: "loadtld",
                tld: tld,
            },
            dataType: "json",
            success: function (response) {
                if (response?.success) {
                    addRecentTld(tld);
                }
                $("#loadingIndicator").fadeOut(200);

                if (response && response.success) {
                    // Fade out old content, then immediately set new HTML and fade in
                    $("#tldFields").stop(true, true).fadeTo(150, 0.3, function () {
                        $(this).html(response.html || '').fadeTo(200, 1, function () {
                            $("#fieldsContainer").css('min-height', '');

                            if (!response.html || response.html.trim() === '') {
                                $("#fieldsContainer").remove();
                            }

                            // Field focus/blur highlighting
                            initFieldInteractions();

                            // generate bootstrap toggle
                            generateBootstrapSwitches();

                            if (response.html && response.html.trim() !== '') {
                                $('html, body').animate({
                                    scrollTop: $("#tldFields").offset().top - 50
                                }, 300);

                                $(".field-row").each(function (index) {
                                    $(this).css({
                                        'opacity': 0,
                                        'transform': 'translateY(10px)'
                                    }).delay(index * 30).animate({
                                        'opacity': 1,
                                        'transform': 'translateY(0)'
                                    }, 200);
                                });
                            }
                        });
                    });
                } else {
                    $("#tldFields").stop(true, true).fadeTo(200, 1);
                    $("#fieldsContainer").css('min-height', '');
                    showAlert('danger', '<strong>Error:</strong> ' + (response.error || "Failed to load fields for this TLD."));
                }
            },
            error: function (xhr, status, error) {
                $("#loadingIndicator").fadeOut(200);
                $("#tldFields").stop(true, true).fadeTo(200, 1);
                $("#fieldsContainer").css('min-height', '');
                console.error("AJAX Error:", error);
                showAlert('danger', '<strong>Error:</strong> Failed to load fields. Please try again or contact support.');
            }
        });
    });


    // Ensure both values (0 or 1) are posted
    $(document).off('change.toggleSync').on('change.toggleSync', '.slide-toggle-mini', function () {
        let $cb = $(this);
        let hiddenName = $cb.data('hidden');
        let $hidden = $('input[type="hidden"][name="' + hiddenName + '"]');
        // Update hidden input value based on checkbox state
        $hidden.val($cb.is(':checked') ? '1' : '0');
    });

    // Save Fields Button Handler
    $(document).on("submit", "#saveFieldsForm", function (e) {
        e.preventDefault();
        const emptyRequiredFields = [];
        $('.field-row').each(function () {
            const $row = $(this);
            const hasRequired = $row.find('.required-indicator').length > 0;
            if (hasRequired) {
                const $input = $row.find('.form-control');
                if ($input.val() === '') {
                    $row.addClass('has-error');
                    emptyRequiredFields.push($row);
                } else {
                    $row.removeClass('has-error');
                }
            }
        });
        // If there are any empty required fields, show an error and focus on the first one
        if (emptyRequiredFields.length > 0) {
            showAlert('danger', '<strong>Error:</strong> Please fill in all required fields before saving.');
            $('.field-row.has-error:first .form-control').focus();
            return;
        }

        // Sync hidden input values on page load
        $('.slide-toggle-mini').each(function () {
            let $cb = $(this);
            let hiddenName = $cb.data('hidden');
            let $hidden = $('input[type="hidden"][name="' + hiddenName + '"]');
            $hidden.val($cb.is(':checked') ? '1' : '0');
        });

        const formData = $(this).serialize();
        $('#saveFieldsButton').button('loading');
        $('.field-row').addClass('saving');
        $("#loadingIndicator").fadeIn(300);
        $.ajax({
            url: window.location.href,
            type: "POST",
            data: formData,
            dataType: "json",
            success: function (response) {
                $("#loadingIndicator").fadeOut(300);
                $('#saveFieldsButton').button('reset');
                $('.field-row').removeClass('saving');
                if (response && response.success) {
                    showAlert('success', '<strong>Success:</strong> Fields have been saved successfully!');
                    // $(".field-row").each(function (index) {
                    //     // ...visual feedback animation...
                    // });
                    $("#saveFieldsForm").addClass("saved");
                    // Remove the saved class after 3 seconds
                    setTimeout(function () {
                        $('#saveFieldsForm').removeClass('saved');
                    }, 3000); // Timeout duration in milliseconds

                } else {
                    showAlert('danger', '<strong>Error:</strong> ' + (response.error || "Failed to save fields."));
                }
            },
            error: function (xhr, status, error) {
                $("#loadingIndicator").fadeOut(300);
                $('#saveFieldsButton').button('reset');
                $('.field-row').removeClass('saving');
                console.error("AJAX Error:", error);
                showAlert('danger', '<strong>Error:</strong> Failed to save fields. Please try again or contact support.');
            },
        });
    });

    // With Selectize, the enter key is already handled by the plugin
    // Add custom handler for Selectize dropdown
    $(document).on('keydown', '.selectize-input', function (e) {
        // Check if Enter key was pressed and there's a value selected
        if (e.which === 13 && $("#tldInput")[0].selectize.getValue()) {
            e.preventDefault();
            $("#lookupFieldsButton").click();
        }
    });
});

function validateTld(tld) {
    if (!tld) return false;

    // Ensure we're working with a string
    tld = String(tld).trim();

    // Add the dot prefix if not present
    if (!tld.startsWith('.')) {
        tld = '.' + tld;

        // Update the value in Selectize if available, otherwise fallback to standard select
        if ($("#tldInput")[0].selectize) {
            $("#tldInput")[0].selectize.setValue(tld, true);  // true to silence the change event
        } else {
            $("#tldInput").val(tld);
        }
    }

    // Validate that we have a proper TLD (dot plus at least one character)
    return tld.length > 1;
}

function showAlert(type, message) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            ${message}
        </div>
    `;
    $('#alertContainer').html(alertHtml);
    if (type === 'success') {
        setTimeout(function () {
            $('.alert-success').fadeOut('slow', function () { $(this).remove(); });
        }, 5000);
    }
}
