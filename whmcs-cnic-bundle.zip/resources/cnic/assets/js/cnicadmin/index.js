(function (window, $) {
    'use strict';

    const RegistrarHelper = {
        getSelect: function (selector) {
            return selector && selector.jquery ? selector : $(selector);
        },

        getValue: function (selector) {
            const $select = this.getSelect(selector || '#registrar');

            if ($select.length === 0) {
                return '';
            }

            return (($select.val() || '') + '').trim();
        },

        autoSelectSingle: function (selector) {
            const $select = this.getSelect(selector || '#registrar');

            if ($select.length === 0 || this.getValue($select) !== '') {
                return false;
            }

            const $options = $select.find('option').filter(function () {
                return $(this).val() !== '';
            });

            if ($options.length !== 1) {
                return false;
            }

            $select.val($options.first().val()).trigger('change');

            return true;
        },

        autoSelectAll: function () {
            const helper = this;

            $('[data-registrar-select="true"]').each(function () {
                helper.autoSelectSingle($(this));
            });
        },

        requireSelection: function (selector, onMissing, message) {
            const registrar = this.getValue(selector || '#registrar');

            if (registrar !== '') {
                return registrar;
            }

            if (typeof onMissing === 'function') {
                onMissing(message || 'Please select a registrar first.');
            }

            return '';
        },

        reloadWithRegistrar: function (selector) {
            const registrar = this.getValue(selector || '#registrar');

            if (registrar === '') {
                return false;
            }

            const url = new URL(window.location.href);
            url.searchParams.set('registrar', registrar);
            window.location.href = url.toString();

            return true;
        }
    };

    window.CnicAdminRegistrarHelper = RegistrarHelper;

    $(document).ready(function () {
        if ($('h1').length > 0 && $('h1').text().trim() === 'CNIC Configuration') {
            $('h1').remove();
        }

        RegistrarHelper.autoSelectAll();
    });
})(window, jQuery);