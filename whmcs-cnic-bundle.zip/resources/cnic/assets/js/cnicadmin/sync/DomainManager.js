/**
 * DomainManager - Clean Domain Data Management
 * Handles domain fetching, caching, and selection logic
 * 
 * @author CNIC Development Team
 * @version 2.0.0
 */

'use strict';

class DomainManager {
    /**
     * DomainManager constants
     */
    static get CONSTANTS() {
        return Object.freeze({
            CACHE_DURATION: 300000, // 5 minutes
            MAX_DOMAINS_PER_REQUEST: 100,
            REQUEST_TIMEOUT: 15000, // 15 seconds
            RETRY_ATTEMPTS: 2
        });
    }

    /**
     * Constructor
     * @param {SyncApp} app - Main application instance
     */
    constructor(app) {
        if (!app) {
            throw new Error('[DomainManager] Application instance is required');
        }

        this.app = app;

        // Bind methods to maintain context
        this.validateRegistrar = this.validateRegistrar.bind(this);
        this.updateSyncButtonState = this.updateSyncButtonState.bind(this);
        this.reset = this.reset.bind(this);
    }

    /**
     * Validate registrar selection and navigate to configuration
     * @returns {Promise<boolean>} Validation success status
     */
    async validateRegistrar() {
        const registrar = this.getSelectedRegistrar();

        if (!registrar) {
            console.warn('[DomainManager] No registrar selected');
            this.app.getModule('alertManager')?.showWarning('Please select a registrar first');
            return false;
        }

        try {
            // Get domain count for this registrar
            const count = await this.getDomainCount(registrar);
            
            if (count === 0) {
                this.app.getModule('alertManager')?.showWarning('No active domains found for this registrar');
                return false;
            }

            // Update UI with domain count
            $('#domainCount').text(count);
            $('#selectedRegistrarName').text(this.app.state.supportedRegistrars[registrar] || registrar);

            // Automatically navigate to step 2 after successful validation
            await this.navigateToConfigurationStep();

            return true;

        } catch (error) {
            console.error('[DomainManager] Failed to validate registrar:', error);
            this.app.getModule('alertManager')?.showError('Failed to validate registrar: ' + error.message);
            return false;
        }
    }

    /**
     * Get domain count from server
     * @param {string} registrar - Registrar identifier
     * @returns {Promise<number>} Domain count
     * @private
     */
    async getDomainCount(registrar) {
        try {
            const response = await $.ajax({
                url: 'addonmodules.php?module=cnicadmin&action=sync',
                method: 'POST',
                data: {
                    type: 'getDomainCount',
                    registrar: registrar,
                    syncType: 'all',
                    token: csrfToken
                },
                timeout: 15000,
                dataType: 'json'
            });

            if (response && response.success) {
                return response.count || 0;
            }
            throw new Error('Failed to get domain count');
        } catch (error) {
            console.error('[DomainManager] Failed to get domain count:', error);
            throw error;
        }
    }

    /**
     * Search domains by term (for autocomplete)
     * @param {string} searchTerm - Search term
     * @returns {Promise<boolean>} Success status
     */
    async searchDomains(searchTerm) {
        const registrar = this.getSelectedRegistrar();
        
        if (!registrar) {
            console.warn('[DomainManager] No registrar selected');
            return false;
        }

        if (!searchTerm || searchTerm.trim().length < 2) {
            this.hideSearchResults();
            return false;
        }

        try {
            this.showSearchLoading();

            const response = await $.ajax({
                url: 'addonmodules.php?module=cnicadmin&action=sync',
                method: 'POST',
                data: {
                    type: 'searchDomain',
                    registrar: registrar,
                    search: searchTerm.trim(),
                    token: csrfToken
                },
                timeout: 10000,
                dataType: 'json'
            });

            if (response && response.success) {
                this.displaySearchResults(response.domains);
                return true;
            }
            throw new Error('Failed to search domains');
        } catch (error) {
            console.error('[DomainManager] Failed to search domains:', error);
            this.displaySearchResults([]);
            return false;
        }
    }

    /**
     * Setup domain search functionality
     */
    setupDomainSearch() {
        const $searchInput = $('#domainSearchInput');
        const $searchBtn = $('#domainSearchBtn');
        const $clearBtn = $('#clearDomainSelection');
        
        if ($searchInput.length === 0) {
            return;
        }

        // Unbind existing events to prevent duplicates
        $searchInput.off('input keypress');
        $searchBtn.off('click');
        $clearBtn.off('click');

        let searchTimeout;

        // Autocomplete on typing
        $searchInput.on('input', (e) => {
            clearTimeout(searchTimeout);
            const term = $(e.target).val();

            if (term.length < 2) {
                this.hideSearchResults();
                return;
            }

            // Debounce search
            searchTimeout = setTimeout(() => {
                this.searchDomains(term);
            }, 300);
        });

        // Search on button click
        $searchBtn.on('click', () => {
            const term = $searchInput.val();
            if (term && term.length >= 2) {
                this.searchDomains(term);
            }
        });

        // Search on Enter key
        $searchInput.on('keypress', (e) => {
            if (e.which === 13) {
                e.preventDefault();
                const term = $searchInput.val();
                if (term && term.length >= 2) {
                    this.searchDomains(term);
                }
            }
        });

        // Clear selection
        $clearBtn.on('click', () => {
            this.clearDomainSelection();
        });

        // Close results when clicking outside
        $(document).on('click', (e) => {
            if (!$(e.target).closest('.domain-search-wrapper').length) {
                this.hideSearchResults();
            }
        });
    }

    /**
     * Display search results
     * @param {Array} domains - Search results
     * @private
     */
    displaySearchResults(domains) {
        const $results = $('#domainSearchResults');
        
        if ($results.length === 0) {
            return;
        }

        $results.empty();

        if (domains.length === 0) {
            $results.append(`
                <div class="domain-search-result-item no-results">
                    <i class="fas fa-info-circle"></i> No domains found
                </div>
            `);
        } else {
            domains.forEach(domain => {
                const $item = $(`
                    <div class="domain-search-result-item" data-domain-id="${domain.id}" data-domain-name="${domain.domain}" data-domain-expiry="${domain.expirydate}">
                        <div class="domain-name">${domain.domain}</div>
                        <div class="domain-expiry">Expires: ${domain.expirydate}</div>
                    </div>
                `);

                $item.on('click', () => {
                    this.selectDomain(domain);
                });

                $results.append($item);
            });
        }

        $results.show();
    }

    /**
     * Show loading state in search results
     * @private
     */
    showSearchLoading() {
        const $results = $('#domainSearchResults');
        if ($results.length) {
            $results.empty().append(`
                <div class="domain-search-result-item loading">
                    <i class="fas fa-spinner fa-spin"></i> Searching...
                </div>
            `).show();
        }
    }

    /**
     * Hide search results
     * @private
     */
    hideSearchResults() {
        $('#domainSearchResults').hide();
    }

    /**
     * Select a domain from search results
     * @param {Object} domain - Domain object
     * @private
     */
    selectDomain(domain) {
        // Store selected domain
        $('#selectedDomainId').val(domain.id);
        $('#selectedDomainName').text(domain.domain);
        $('#selectedDomainExpiry').text(domain.expirydate);
        
        // Show selected domain display
        $('#selectedDomainDisplay').show();
        
        // Clear search input and hide results
        $('#domainSearchInput').val('');
        this.hideSearchResults();
        
        // Update sync button state
        this.updateSyncButtonState();
    }

    /**
     * Clear domain selection
     * @private
     */
    clearDomainSelection() {
        $('#selectedDomainId').val('');
        $('#selectedDomainName').text('');
        $('#selectedDomainExpiry').text('');
        $('#selectedDomainDisplay').hide();
        $('#domainSearchInput').val('');
        
        // Update sync button state
        this.updateSyncButtonState();
    }

    /**
     * Setup domain search functionality
     * @returns {Promise<boolean>} Success status
     */
    async loadDomainsForDropdown() {
        this.setupDomainSearch();
        return true;
    }

    /**
     * Setup TLD search functionality
     * @returns {Promise<boolean>} Success status
     */
    async loadTldsForDropdown() {
        this.setupTldSearch();
        return true;
    }

    /**
     * Search TLDs by term (for autocomplete)
     * @param {string} searchTerm - Search term
     * @returns {Promise<boolean>} Success status
     */
    async searchTlds(searchTerm) {
        const registrar = this.getSelectedRegistrar();
        
        if (!registrar) {
            console.warn('[DomainManager] No registrar selected');
            return false;
        }

        if (!searchTerm || searchTerm.trim().length < 1) {
            this.hideTldSearchResults();
            return false;
        }

        try {
            this.showTldSearchLoading();

            const response = await $.ajax({
                url: 'addonmodules.php?module=cnicadmin&action=sync',
                method: 'POST',
                data: {
                    type: 'searchTld',
                    registrar: registrar,
                    search: searchTerm.trim(),
                    token: csrfToken
                },
                timeout: 10000,
                dataType: 'json'
            });

            if (response && response.success) {
                this.displayTldSearchResults(response.tlds);
                return true;
            }
            throw new Error('Failed to search TLDs');
        } catch (error) {
            console.error('[DomainManager] Failed to search TLDs:', error);
            this.displayTldSearchResults([]);
            return false;
        }
    }

    /**
     * Setup TLD search functionality
     */
    setupTldSearch() {
        const $searchInput = $('#tldSearchInput');
        const $searchBtn = $('#tldSearchBtn');
        const $clearBtn = $('#clearTldSelection');
        
        if ($searchInput.length === 0) {
            return;
        }

        // Unbind existing events to prevent duplicates
        $searchInput.off('input keypress');
        $searchBtn.off('click');
        $clearBtn.off('click');

        let searchTimeout;

        // Autocomplete on typing
        $searchInput.on('input', (e) => {
            clearTimeout(searchTimeout);
            const term = $(e.target).val();

            if (term.length < 1) {
                this.hideTldSearchResults();
                return;
            }

            // Debounce search
            searchTimeout = setTimeout(() => {
                this.searchTlds(term);
            }, 300);
        });

        // Search on button click
        $searchBtn.on('click', () => {
            const term = $searchInput.val();
            if (term && term.length >= 1) {
                this.searchTlds(term);
            }
        });

        // Search on Enter key
        $searchInput.on('keypress', (e) => {
            if (e.which === 13) {
                e.preventDefault();
                const term = $searchInput.val();
                if (term && term.length >= 1) {
                    this.searchTlds(term);
                }
            }
        });

        // Clear selection
        $clearBtn.on('click', () => {
            this.clearTldSelection();
        });

        // Close results when clicking outside
        $(document).on('click', (e) => {
            if (!$(e.target).closest('.tld-search-wrapper').length) {
                this.hideTldSearchResults();
            }
        });
    }

    /**
     * Display TLD search results
     * @param {Array} tlds - Search results
     * @private
     */
    displayTldSearchResults(tlds) {
        const $results = $('#tldSearchResults');
        
        if ($results.length === 0) {
            return;
        }

        $results.empty();

        if (tlds.length === 0) {
            $results.append(`
                <div class="tld-search-result-item no-results">
                    <i class="fas fa-info-circle"></i> No TLDs found
                </div>
            `);
        } else {
            tlds.forEach(tld => {
                const $item = $(`
                    <div class="tld-search-result-item" data-tld="${tld.tld}">
                        <div class="tld-name">
                            <span class="tld-extension">${tld.tld}</span>
                        </div>
                    </div>
                `);

                $item.on('click', () => {
                    this.selectTld(tld);
                });

                $results.append($item);
            });
        }

        $results.show();
    }

    /**
     * Show loading state in TLD search results
     * @private
     */
    showTldSearchLoading() {
        const $results = $('#tldSearchResults');
        if ($results.length) {
            $results.empty().append(`
                <div class="tld-search-result-item loading">
                    <i class="fas fa-spinner fa-spin"></i> Searching TLDs...
                </div>
            `).show();
        }
    }

    /**
     * Hide TLD search results
     * @private
     */
    hideTldSearchResults() {
        $('#tldSearchResults').hide();
    }

    /**
     * Select a TLD from search results
     * @param {Object} tld - TLD object
     * @private
     */
    selectTld(tld) {
        // Store selected TLD
        $('#selectedTld').val(tld.tld);
        $('#selectedTldName').text(tld.tld);
        
        // Show selected TLD display
        $('#selectedTldDisplay').show();
        
        // Clear search input and hide results
        $('#tldSearchInput').val('');
        this.hideTldSearchResults();
        
        // Update sync button state
        this.updateSyncButtonState();
    }

    /**
     * Clear TLD selection
     * @private
     */
    clearTldSelection() {
        $('#selectedTld').val('');
        $('#selectedTldName').text('');
        $('#selectedTldDisplay').hide();
        $('#tldSearchInput').val('');
        
        // Update sync button state
        this.updateSyncButtonState();
    }

    /**
     * Get domain count from server
     * @param {string} registrar - Registrar identifier
     * @returns {Promise<number>} Domain count
     * @private
     */
    async getDomainCount(registrar) {
        try {
            const response = await $.ajax({
                url: 'addonmodules.php?module=cnicadmin&action=sync',
                method: 'POST',
                data: {
                    type: 'getDomainCount',
                    registrar: registrar,
                    syncType: 'all',
                    token: csrfToken
                },
                timeout: 15000,
                dataType: 'json'
            });

            if (response && response.success) {
                return response.count || 0;
            }
            throw new Error('Failed to get domain count');
        } catch (error) {
            console.error('[DomainManager] Failed to get domain count:', error);
            throw error;
        }
    }

    /**
     * Get currently selected registrar
     * @returns {string} Registrar identifier
     * @private
     */
    getSelectedRegistrar() {
        return $(this.app.constructor.CONSTANTS.SELECTORS.registrar).val() || '';
    }

    /**
     * Update sync button state based on selections
     * @returns {boolean} Update success
     */
    updateSyncButtonState() {
        try {
            const $syncButton = $('.sync-start-button');
            const selectedSyncType = $('input[name="syncType"]:checked').val();

            let enableButton = false;

            switch (selectedSyncType) {
                case 'all':
                    enableButton = true; // Always enabled for all domains
                    break;
                case 'single':
                    // Check if domain is selected via search
                    const selectedDomainId = $('#selectedDomainId').val();
                    enableButton = selectedDomainId && selectedDomainId.length > 0;
                    break;
                case 'tld':
                    // Check if TLD is selected via search
                    const selectedTld = $('#selectedTld').val();
                    enableButton = selectedTld && selectedTld.length > 0;
                    break;
                default:
                    enableButton = false;
            }

            if (enableButton) {
                $syncButton.removeClass('disabled').prop('disabled', false);
            } else {
                $syncButton.addClass('disabled').prop('disabled', true);
            }

            return true;

        } catch (error) {
            console.error('[DomainManager] Failed to update sync button state:', error);
            return false;
        }
    }

    /**
     * Navigate to configuration step after successful registrar validation
     * Provides automatic navigation from step 1 to step 2
     */
    navigateToConfigurationStep() {
        try {
            // Get navigation manager from app modules
            const navigationManager = this.app.modules.navigationManager;
            if (!navigationManager) {
                console.warn('[DomainManager] NavigationManager not available');
                return;
            }

            // Navigate to step 2 (configuration)
            navigationManager.goToStep(2);
        } catch (error) {
            console.error('[DomainManager] Failed to navigate to configuration:', error);
        }
    }

    /**
     * Reset manager to initial state
     * @returns {boolean} Reset success
     */
    reset() {
        try {
            // Reset UI elements
            $('#domainCount').text('0');
            $('#selectedRegistrarName').text('-');

            return true;

        } catch (error) {
            console.error('[DomainManager] Reset failed:', error);
            return false;
        }
    }

    /**
     * Destroy manager instance
     */
    destroy() {
        try {
            // Clear references
            this.app = null;
        } catch (error) {
            console.error('[DomainManager] Destroy failed:', error);
        }
    }
}

//=============================================================================
// EXPORT - Make DomainManager available
//=============================================================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = DomainManager;
} else if (typeof window !== 'undefined') {
    window.DomainManager = DomainManager;
}