/**
 * Domain Manager - Handles domain fetching, filtering, and validation
 */

class DomainManager {
    constructor(app) {
        this.app = app;
    }
    
    /**
     * Fetch domains from selected registrar
     */
    fetchDomains() {
        const selectedRegistrar = $(this.app.SELECTORS.registrar).val();
        
        if (!selectedRegistrar) {
            this.app.alertManager.showError('Please select a registrar first');
            return;
        }
        
        $(this.app.SELECTORS.loadingOverlay).show();
        this.resetStep2Form();
        
        $.post("addonmodules.php", {
            module: 'cnicadmin',
            action: 'sync',
            type: 'fetchDomains',
            registrar: selectedRegistrar
        })
        .done(response => this.handleFetchDomainsSuccess(response))
        .fail((jqXHR, textStatus) => {
            this.app.alertManager.showError('Error fetching domains: ' + textStatus);
        })
        .always(() => {
            $(this.app.SELECTORS.loadingOverlay).hide();
        });
    }
    
    /**
     * Handle successful domain fetch response
     */
    handleFetchDomainsSuccess(response) {
        if (response && Array.isArray(response)) {
            this.app.domains = response;
            this.updateRegistrarInfo();
            this.app.navigationManager.goToStep(this.app.STEPS.SYNC_CONFIGURATION);
            
            setTimeout(() => {
                this.app.uiManager.initializeSyncTypeToggle();
            }, 200);
        } else if (response && response.error) {
            this.app.alertManager.showError('Error: ' + response.error);
        } else {
            this.app.alertManager.showError('Failed to fetch domains - Invalid response format');
        }
    }
    
    /**
     * Filter domains based on search term
     */
    filterDomains() {
        const searchTerm = $(this.app.SELECTORS.domainSearch).val().toLowerCase();
        const $domainField = $(this.app.SELECTORS.domain);
        
        $domainField.empty().append('<option value="">Select a domain</option>');
        
        const filteredDomains = this.app.domains.filter(domain => 
            domain.domain.toLowerCase().indexOf(searchTerm) !== -1
        );
        
        filteredDomains.forEach(domain => {
            $domainField.append(`<option value="${domain.domain}">${domain.domain}</option>`);
        });
        
        $(this.app.SELECTORS.domainHelp).text(`Showing ${filteredDomains.length} of ${this.app.domains.length} domains`);
    }
    
    /**
     * Update domain help text
     */
    updateDomainHelp() {
        let helpText = 'No domains loaded. Please select a registrar first.';
        
        if (this.app.domains && this.app.domains.length > 0) {
            helpText = `Select a domain from ${this.app.domains.length} available domains`;
        }
        
        $(this.app.SELECTORS.domainHelp).text(helpText);
        this.updateSyncButtonState();
    }
    
    /**
     * Update sync button state based on available domains
     */
    updateSyncButtonState() {
        const $syncButton = $('.sync-start-button');
        
        if (!$syncButton.length) return;
        
        const hasValidDomains = this.app.domains && this.app.domains.length > 0;
        const syncType = $('input[name="syncType"]:checked').val() || this.app.SYNC_TYPES.ALL;
        let isValidForSync = false;
        
        if (hasValidDomains) {
            if (syncType === this.app.SYNC_TYPES.ALL) {
                isValidForSync = true;
            } else if (syncType === this.app.SYNC_TYPES.SINGLE) {
                const selectedDomain = $(this.app.SELECTORS.domain).val();
                isValidForSync = selectedDomain && this.app.findDomainByName(selectedDomain);
            }
        }
        
        this.updateButtonAppearance($syncButton, isValidForSync, hasValidDomains);
    }
    
    /**
     * Update button appearance based on validation state
     */
    updateButtonAppearance($button, isValid, hasValidDomains) {
        if (isValid) {
            $button.removeClass('disabled')
                .prop('disabled', false)
                .find('i').removeClass('fa-exclamation-triangle').addClass('fa-rocket');
            
            $button.find('.btn-text').text('Start Synchronization');
        } else {
            $button.addClass('disabled')
                .prop('disabled', true)
                .find('i').removeClass('fa-rocket').addClass('fa-exclamation-triangle');
            
            const disabledText = !hasValidDomains ? 'No Domains Available' : 'Select Domain First';
            
            if (!$button.find('.btn-text').length) {
                $button.append('<span class="btn-text"></span>');
            }
            $button.find('.btn-text').text(disabledText);
        }
    }
    
    /**
     * Update registrar information display
     */
    updateRegistrarInfo() {
        const selectedRegistrar = $(this.app.SELECTORS.registrar).val();
        const registrarName = this.app.supportedRegistrars[selectedRegistrar] || selectedRegistrar;
        
        $("#selectedRegistrarName").text(registrarName);
        $("#domainCount").text(this.app.domains.length);
        
        this.updateSyncButtonState();
    }
    
    /**
     * Reset Step 2 form to default state
     */
    resetStep2Form() {
        // Reset sync type to "all"
        $(`input[name="syncType"][value="${this.app.SYNC_TYPES.ALL}"]`).prop('checked', true);
        $(`input[name="syncType"][value="${this.app.SYNC_TYPES.SINGLE}"]`).prop('checked', false);
        
        // Hide and reset domain input section
        $(this.app.SELECTORS.domainInput).hide();
        $(this.app.SELECTORS.domainSearch)
            .hide()
            .prop('disabled', true)
            .val('');
        
        $(this.app.SELECTORS.domain)
            .prop('disabled', true)
            .empty()
            .append('<option value="">Select a domain</option>')
            .val('');
        
        $(this.app.SELECTORS.domainHelp).text('Select a domain from the loaded list');
        
        // Reset choice card visual states
        this.app.uiManager.updateChoiceCardStates();
        this.app.uiManager.updateModernChoiceCardStates();
    }
    
    /**
     * Validate domains for sync
     */
    validateDomainsForSync() {
        const syncType = $('input[name="syncType"]:checked').val() || this.app.SYNC_TYPES.ALL;
        
        // Check if we have any domains loaded
        if (!this.app.domains || this.app.domains.length === 0) {
            this.app.alertManager.showError('No domains available for synchronization. Please select a registrar and ensure domains are loaded.');
            return false;
        }
        
        // For single domain sync, validate selected domain
        if (syncType === this.app.SYNC_TYPES.SINGLE) {
            const selectedDomain = $(this.app.SELECTORS.domain).val();
            
            if (!selectedDomain) {
                this.app.alertManager.showError('Please select a domain to synchronize.');
                return false;
            }
            
            const domain = this.app.findDomainByName(selectedDomain);
            if (!domain) {
                this.app.alertManager.showError(`Selected domain "${selectedDomain}" not found in available domains.`);
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Get domain name for display purposes
     */
    getDomainNameForDisplay(domainId) {
        let domainName = domainId;
        
        if (this.app.domains && this.app.domains.length > 0) {
            const domainObj = this.app.domains.find(domain => 
                domain.id == domainId || domain.domain == domainId
            );
            
            if (domainObj) {
                domainName = domainObj.domain;
            }
        }
        
        return domainName;
    }
}
