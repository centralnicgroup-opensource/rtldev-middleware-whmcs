/**
 * SyncEngine - Clean Domain Sync Processing Engine
 * Handles all domain sync operations with modern async/await patterns
 * 
 * @author CNIC Development Team
 * @version 2.0.0
 */

'use strict';

class SyncEngine {
    /**
    * Constructor
    * @param {SyncApp} app - Main application instance
    */
    constructor(app) {
        if (!app) {
            throw new Error('[SyncEngine] Application instance is required');
        }

        this.app = app;
        this.state = SyncEngine.CONSTANTS.SYNC_STATES.IDLE;
        this.activeRequest = null;
        this.totalCount = 0;
        this.processedCount = 0;
        this.successfulCount = 0;
        this.unchangedCount = 0;
        this.failedCount = 0;
        this.currentOffset = 0;
        this.shouldContinue = true;
        this.allFailures = []; // Track all failures for final logging

        // Bind methods to maintain context
        this.startSync = this.startSync.bind(this);
        this.cancelSync = this.cancelSync.bind(this);
        this.reset = this.reset.bind(this);
    }

    /**
    /**
     * Initialize sync environment
     * @returns {Promise<boolean>} Initialization success
     * @private
     */
    async initializeSync() {
        try {
            // Clear table for fresh sync
            const tableManager = this.app.getModule('tableManager');
            if (tableManager && typeof tableManager.clearTableForNewSync === 'function') {
                tableManager.clearTableForNewSync();
            }

            // Reset application sync state
            this.app.updateState({
                syncCancelled: false,
                totalDomainsToSync: 0,
                completedDomainsCount: 0
            });

            // Reset engine state
            this.processedCount = 0;
            this.successfulCount = 0;
            this.unchangedCount = 0;
            this.failedCount = 0;
            this.totalCount = 0;
            this.currentOffset = 0;
            this.activeRequest = null;
            this.shouldContinue = true;
            this.allFailures = []; // Clear failures from previous sync

            return true;

        } catch (error) {
            console.error('[SyncEngine] Failed to initialize sync environment:', error);
            return false;
        }
    }

    /**
     * Setup progress tracking UI
     * @param {number} totalDomains - Total domains to sync
     * @private
     */
    setupProgressTracking(totalDomains) {
        this.totalCount = totalDomains;
        this.processedCount = 0;

        // Update application state
        this.app.updateState({
            totalDomainsToSync: totalDomains,
            completedDomainsCount: 0
        });

        // Show progress indicators
        this.showProgressIndicators();
        this.updateProgressDisplay();
    }

    /**
     * Update sync progress
     * @private
     */
    updateProgress() {
        // Update application state
        this.app.updateState({
            completedDomainsCount: this.processedCount
        });

        // Update UI display
        this.updateProgressDisplay();

        // Check if sync is complete
        if (this.processedCount >= this.totalCount) {
            this.handleSyncCompletion();
        }
    }

    /**
     * Handle sync completion
     * @private
     */
    async handleSyncCompletion() {
        // Hide cancel button since sync is complete
        $(this.app.constructor.CONSTANTS.SELECTORS.cancelSyncBtn).hide();

        // Update final stats
        this.updateProgressDisplay();
        
        // Update progress title and icon to show completion
        $('.progress-title').text('Synchronization Complete!');
        $('.loading-spinner i')
            .removeClass('fa-sync fa-spin')
            .addClass('fa-check-circle')
            .parent().addClass('status-success');

        // Set completed state
        this.state = SyncEngine.CONSTANTS.SYNC_STATES.COMPLETED;

        // Log all failures to WHMCS activity log if any exist
        if (this.allFailures.length > 0) {
            await this.logFailedDomains();
        }

        // Show completion message
        const alertManager = this.app.getModule('alertManager');
        if (alertManager) {
            if (this.failedCount === 0) {
                alertManager.showSuccess(
                    `Sync completed successfully! Processed ${this.processedCount} domains ` +
                    `(${this.successfulCount} updated, ${this.unchangedCount} unchanged)`
                );
            } else {
                alertManager.showWarning(
                    `Sync completed with ${this.failedCount} errors. ` +
                    `Successfully processed ${this.successfulCount + this.unchangedCount} domains.`
                );
            }
        }
    }

    /**
     * Log all failed domains to WHMCS activity log
     * @private
     */
    async logFailedDomains() {
        try {
            const syncConfig = this.getSyncConfiguration();
            
            await $.ajax({
                url: 'addonmodules.php?module=cnicadmin&action=sync',
                method: 'POST',
                data: {
                    type: 'logFailures',
                    registrar: syncConfig.registrar,
                    syncType: syncConfig.syncType,
                    failures: JSON.stringify(this.allFailures),
                    token: csrfToken
                },
                timeout: 30000,
                dataType: 'json'
            });
        } catch (error) {
            console.error('[SyncEngine] Failed to log failures:', error);
        }
    }

    /**
     * Update progress display with detailed stats
     * @private
     */
    updateProgressDisplay() {
        const percentage = this.totalCount > 0 ? Math.round((this.processedCount / this.totalCount) * 100) : 0;
        
        // Update progress bar if exists
        const $progressBar = $('.sync-progress-bar');
        if ($progressBar.length) {
            $progressBar.css('width', percentage + '%');
            $progressBar.attr('aria-valuenow', percentage);
            $progressBar.find('.progress-percentage').text(percentage + '%');
        }

        // Update stats display
        $('#sync-total-count').text(this.totalCount);
        $('#sync-processed-count').text(this.processedCount);
        $('#sync-successful-count').text(this.successfulCount);
        $('#sync-unchanged-count').text(this.unchangedCount);
        $('#sync-failed-count').text(this.failedCount);
        $('#sync-remaining-count').text(this.totalCount - this.processedCount);
        
        // Update progress text
        const progressText = `Processing: ${this.processedCount} / ${this.totalCount} domains (${percentage}%)`;
        $(this.app.constructor.CONSTANTS.SELECTORS.progressText).text(progressText);
    }

    /**
     * Show progress indicators
     * @private
     */
    showProgressIndicators() {
        // Reset progress title and icon to initial state
        $('.progress-title').text('Syncing in progress...');
        $('.loading-spinner')
            .removeClass('status-success status-warning')
            .find('i')
            .removeClass('fa-check-circle fa-exclamation-triangle')
            .addClass('fa-sync fa-spin');
        
        $(this.app.constructor.CONSTANTS.SELECTORS.syncProgress).show();
        $(this.app.constructor.CONSTANTS.SELECTORS.cancelSyncBtn).show();
        $('.sync-stats-container').show();
    }

    /**
     * Clear progress indicators
     * @private
     */
    clearProgressIndicators() {
        $(this.app.constructor.CONSTANTS.SELECTORS.syncProgress).hide();
        $(this.app.constructor.CONSTANTS.SELECTORS.cancelSyncBtn).hide();
        $(this.app.constructor.CONSTANTS.SELECTORS.progressText).text('');
        $('.sync-stats-container').hide();
    }

    /**
     * Show cancellation status
     * @private
     */
    showCancelledStatus() {
        const progressText = $(this.app.constructor.CONSTANTS.SELECTORS.progressText);
        const cancelBtn = $(this.app.constructor.CONSTANTS.SELECTORS.cancelSyncBtn);

        // Update progress title and icon to show cancellation
        $('.progress-title').text('Synchronization Cancelled');
        $('.loading-spinner i')
            .removeClass('fa-sync fa-spin fa-check-circle')
            .addClass('fa-exclamation-triangle')
            .parent().addClass('status-warning');

        // Update progress text to show cancelled status
        progressText.text(
            `Processed: ${this.processedCount}/${this.totalCount} domains ` +
            `(${this.successfulCount} successful, ${this.failedCount} failed)`
        );

        // Hide cancel button
        cancelBtn.hide();

        // Update progress bar color
        const progressBar = $('.sync-progress-bar');
        if (progressBar.length) {
            progressBar.removeClass('bg-primary bg-info bg-success').addClass('bg-warning');
        }

        // Show alert
        const alertManager = this.app.getModule('alertManager');
        if (alertManager) {
            alertManager.showWarning('Sync cancelled by user');
        }
    }

    /**
     * Get selected registrar
     * @returns {string} Registrar identifier
     * @private
     */
    getSelectedRegistrar() {
        return $(this.app.constructor.CONSTANTS.SELECTORS.registrar).val() || '';
    }

    /**
     * Handle sync error
     * @param {Error} error - Error object
     * @private
     */
    handleSyncError(error) {
        const alertManager = this.app.getModule('alertManager');
        if (alertManager) {
            alertManager.showError('Sync failed: ' + error.message);
        }

        this.clearProgressIndicators();
    }

    static get CONSTANTS() {
        return Object.freeze({
            SYNC_STATES: Object.freeze({
                IDLE: 'idle',
                INITIALIZING: 'initializing',
                RUNNING: 'running',
                CANCELLING: 'cancelling',
                COMPLETED: 'completed',
                ERROR: 'error'
            }),
            BATCH_SIZE: 5,
            REQUEST_TIMEOUT: 60000, // 60 seconds for batch
            RETRY_ATTEMPTS: 2,
            RETRY_DELAY: 2000 // 2 seconds
        });
    }

    /**
     * Start domain synchronization process with server-side batch processing
     * @returns {Promise<boolean>} Sync success status
     */
    async startSync() {
        if (this.state !== SyncEngine.CONSTANTS.SYNC_STATES.IDLE) {
            console.warn('[SyncEngine] Sync already in progress, state:', this.state);
            return false;
        }

        try {
            this.state = SyncEngine.CONSTANTS.SYNC_STATES.INITIALIZING;

            // Initialize sync environment
            const initSuccess = await this.initializeSync();
            if (!initSuccess) {
                throw new Error('Failed to initialize sync environment');
            }

            // Get total domain count from server
            const totalCount = await this.getTotalDomainCount();
            if (totalCount === 0) {
                throw new Error('No domains available for synchronization');
            }

            // Setup progress tracking
            this.setupProgressTracking(totalCount);

            // Navigate to results step
            if (this.app.getModule('navigationManager')) {
                this.app.getModule('navigationManager').goToStep(
                    this.app.constructor.CONSTANTS.STEPS.SYNC_RESULTS
                );
            }

            // Start batch sync process
            this.state = SyncEngine.CONSTANTS.SYNC_STATES.RUNNING;
            await this.processBatchSync();

            this.state = SyncEngine.CONSTANTS.SYNC_STATES.COMPLETED;
            return true;

        } catch (error) {
            console.error('[SyncEngine] Sync failed:', error);
            this.state = SyncEngine.CONSTANTS.SYNC_STATES.ERROR;
            this.handleSyncError(error);
            return false;
        }
    }

    /**
     * Cancel ongoing synchronization
     * @returns {Promise<boolean>} Cancellation success
     */
    async cancelSync() {
        // Stop all further processing immediately
        this.shouldContinue = false;
        this.state = SyncEngine.CONSTANTS.SYNC_STATES.CANCELLING;

        // Update application state
        this.app.updateState({ syncCancelled: true });

        // Cancel active HTTP request
        if (this.activeRequest && typeof this.activeRequest.abort === 'function') {
            try {
                this.activeRequest.abort();
            } catch (error) {
                // Ignore abort errors
            }
        }

        // Show cancelled status
        this.showCancelledStatus();

        // Set to idle state
        this.state = SyncEngine.CONSTANTS.SYNC_STATES.IDLE;

        return true;
    }

    /**
     * Get total domain count from server
     * @returns {Promise<number>} Total domain count
     * @private
     */
    async getTotalDomainCount() {
        const syncConfig = this.getSyncConfiguration();
        
        try {
            const response = await $.ajax({
                url: 'addonmodules.php?module=cnicadmin&action=sync',
                method: 'POST',
                data: {
                    type: 'getDomainCount',
                    registrar: syncConfig.registrar,
                    syncType: syncConfig.syncType,
                    tld: syncConfig.tld || '',
                    domainId: syncConfig.domainId || 0,
                    token: csrfToken
                },
                timeout: 30000,
                dataType: 'json'
            });

            if (response && response.success) {
                return response.count || 0;
            }
            throw new Error('Failed to get domain count');
        } catch (error) {
            console.error('[SyncEngine] Failed to get domain count:', error);
            throw error;
        }
    }

    /**
     * Process batch synchronization
     * @returns {Promise<void>}
     * @private
     */
    async processBatchSync() {
        let hasMore = true;

        while (hasMore && this.shouldContinue) {
            try {
                const batchResult = await this.processSingleBatch();
                
                if (!this.shouldContinue) {
                    break;
                }

                // Update counters
                this.processedCount += batchResult.batchSize;
                this.successfulCount += batchResult.results.successful || 0;
                this.unchangedCount += batchResult.results.unchanged || 0;
                this.failedCount += batchResult.results.failed || 0;

                // Add failures to table and collect for final logging
                if (batchResult.results.failures && batchResult.results.failures.length > 0) {
                    this.addFailuresToTable(batchResult.results.failures);
                    this.allFailures.push(...batchResult.results.failures);
                }

                // Update progress
                this.updateProgress();

                // Check if more batches exist
                hasMore = batchResult.hasMore;
                this.currentOffset += batchResult.batchSize;

                // Small delay between batches
                if (hasMore && this.shouldContinue) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                }

            } catch (error) {
                if (!this.shouldContinue) {
                    break;
                }
                console.error('[SyncEngine] Batch processing error:', error);
                
                // Retry logic
                const shouldRetry = await this.handleBatchError(error);
                if (!shouldRetry) {
                    throw error;
                }
            }
        }
    }

    /**
     * Process a single batch
     * @returns {Promise<Object>} Batch result
     * @private
     */
    async processSingleBatch() {
        const syncConfig = this.getSyncConfiguration();
        
        const request = $.ajax({
            url: 'addonmodules.php?module=cnicadmin&action=sync',
            method: 'POST',
            data: {
                type: 'syncBatch',
                registrar: syncConfig.registrar,
                syncType: syncConfig.syncType,
                tld: syncConfig.tld || '',
                domainId: syncConfig.domainId || 0,
                offset: this.currentOffset,
                limit: SyncEngine.CONSTANTS.BATCH_SIZE,
                forceUpdate: syncConfig.forceUpdate ? '1' : '0',
                token: csrfToken
            },
            timeout: SyncEngine.CONSTANTS.REQUEST_TIMEOUT,
            dataType: 'json'
        });

        this.activeRequest = request;

        try {
            const response = await request;
            
            if (response && response.success) {
                return response;
            }
            throw new Error('Batch processing failed');
        } catch (error) {
            // If this is an abort, re-throw immediately to stop processing
            if (error.statusText === 'abort' || !this.shouldContinue) {
                throw error;
            }
            // For other errors, let them be handled by retry logic
            throw error;
        } finally {
            this.activeRequest = null;
        }
    }

    /**
     * Handle batch processing error
     * @param {Error} error - Error object
     * @returns {Promise<boolean>} Should retry
     * @private
     */
    async handleBatchError(error) {
        console.error('[SyncEngine] Batch error:', error);
        
        // Don't retry if user cancelled
        if (error.statusText === 'abort' || !this.shouldContinue) {
            return false;
        }
        
        // Check if it's a network/timeout error that can be retried
        if (error.statusText === 'timeout' || error.status === 0) {
            // Wait before retry
            await new Promise(resolve => setTimeout(resolve, SyncEngine.CONSTANTS.RETRY_DELAY));
            return true;
        }
        
        return false;
    }

    /**
     * Add failures to table
     * @param {Array} failures - Array of failure objects
     * @private
     */
    addFailuresToTable(failures) {
        const tableManager = this.app.getModule('tableManager');
        if (!tableManager) {
            return;
        }

        failures.forEach(failure => {
            tableManager.addResult(failure.domain, failure.status, {
                domain: failure.domain,
                status: failure.error || failure.status,
                old_expiry: 'N/A',
                new_expiry: 'N/A',
                next_due_date: 'N/A',
                next_invoice_date: 'N/A'
            });
        });
    }

    /**
     * Get sync configuration
     * @returns {Object} Sync configuration
     * @private
     */
    getSyncConfiguration() {
        const syncType = $('input[name="syncType"]:checked').val() || 'all';
        const registrar = $(this.app.constructor.CONSTANTS.SELECTORS.registrar).val() || '';
        const forceUpdate = $('#forceUpdateExpiryDate').is(':checked');
        
        let tld = null;
        let domainId = null;
        
        if (syncType === 'tld') {
            tld = $('#selectedTld').val();
        } else if (syncType === 'single') {
            const selectedDomainId = $('#selectedDomainId').val();
            if (selectedDomainId) {
                domainId = parseInt(selectedDomainId, 10);
            }
        }
        
        return {
            syncType,
            registrar,
            tld,
            domainId,
            forceUpdate
        };
    }

    /**
     * Reset engine to initial state
     * @returns {boolean} Reset success
     */
    reset() {
        try {
            // Cancel any active sync
            if (this.state === SyncEngine.CONSTANTS.SYNC_STATES.RUNNING) {
                this.cancelSync();
            }

            // Reset state
            this.state = SyncEngine.CONSTANTS.SYNC_STATES.IDLE;
            this.processedCount = 0;
            this.successfulCount = 0;
            this.unchangedCount = 0;
            this.failedCount = 0;
            this.totalCount = 0;
            this.currentOffset = 0;
            this.activeRequest = null;

            // Clear UI
            this.clearProgressIndicators();

            return true;

        } catch (error) {
            console.error('[SyncEngine] Reset failed:', error);
            return false;
        }
    }

    /**
     * Get current sync statistics
     * @returns {Object} Sync statistics
     */
    getStats() {
        return Object.freeze({
            state: this.state,
            totalCount: this.totalCount,
            processedCount: this.processedCount,
            successfulCount: this.successfulCount,
            unchangedCount: this.unchangedCount,
            failedCount: this.failedCount,
            remaining: this.totalCount - this.processedCount
        });
    }

    /**
     * Check if sync is currently active
     * @returns {boolean} True if active
     */
    isActive() {
        return this.state === SyncEngine.CONSTANTS.SYNC_STATES.RUNNING ||
            this.state === SyncEngine.CONSTANTS.SYNC_STATES.INITIALIZING;
    }

    /**
     * Destroy engine instance
     */
    destroy() {
        try {
            // Cancel any active operations
            if (this.activeRequest && typeof this.activeRequest.abort === 'function') {
                try {
                    this.activeRequest.abort();
                } catch (error) {
                    // Ignore abort errors
                }
            }

            // Clear all references
            this.app = null;
            this.activeRequest = null;
            this.state = SyncEngine.CONSTANTS.SYNC_STATES.IDLE;

        } catch (error) {
            console.error('[SyncEngine] Destroy failed:', error);
        }
    }
}

//=============================================================================
// EXPORT - Make SyncEngine available
//=============================================================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = SyncEngine;
} else if (typeof window !== 'undefined') {
    window.SyncEngine = SyncEngine;
}