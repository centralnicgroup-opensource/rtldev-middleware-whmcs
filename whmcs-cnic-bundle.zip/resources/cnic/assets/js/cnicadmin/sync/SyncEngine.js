/**
 * Sync Engine - Handles all synchronization logic and processing
 */

class SyncEngine {
    constructor(app) {
        this.app = app;
    }
    
    /**
     * Start the domain synchronization process
     */
    start() {
        // Validate that we have domains to sync
        if (!this.app.domainManager.validateDomainsForSync()) {
            return;
        }
        
        this.initializeSyncState();
        this.setupSyncUI();
        this.executeSyncBasedOnType();
    }
    
    /**
     * Initialize sync state variables
     */
    initializeSyncState() {
        this.app.syncCancelled = false;
        this.app.activeRequests = [];
        this.app.completedDomainsCount = 0;
    }
    
    /**
     * Setup UI for sync process
     */
    setupSyncUI() {
        $(this.app.SELECTORS.loadingOverlay).show();
        
        // Prepare DataTable for new sync FIRST - clear existing content and ensure proper structure
        this.app.tableManager.prepareForNewSync();
        
        // Then navigate to step 3
        this.app.navigationManager.goToStep(this.app.STEPS.SYNC_RESULTS);
        
        setTimeout(() => {
            $(this.app.SELECTORS.loadingOverlay).hide();
            
            // Use single source of truth for sync controls
            this.app.uiManager.showSyncInProgress();
            
            $(this.app.SELECTORS.progressText).html('Starting domain synchronization...');
        }, 300);
    }
    
    /**
     * Execute sync based on selected type
     */
    executeSyncBasedOnType() {
        const syncType = $('input[name="syncType"]:checked').val() || this.app.SYNC_TYPES.ALL;
        
        if (syncType === this.app.SYNC_TYPES.ALL) {
            this.executeAllDomainsSync();
        } else {
            this.executeSingleDomainSync();
        }
    }
    
    /**
     * Execute sync for all domains
     */
    executeAllDomainsSync() {
        // Additional validation - should not reach here if no domains
        if (!this.app.domains || this.app.domains.length === 0) {
            this.app.alertManager.showError('No domains available for synchronization.');
            this.app.navigationManager.goToStep(this.app.STEPS.SYNC_CONFIGURATION);
            return;
        }
        
        this.app.totalDomainsToSync = this.app.domains.length;
        
        this.app.domains.forEach((domain, index) => {
            if (!this.app.syncCancelled) {
                this.syncSingleDomain(domain.id, index, this.app.domains.length);
            }
        });
    }
    
    /**
     * Execute sync for single domain
     */
    executeSingleDomainSync() {
        this.app.totalDomainsToSync = 1;
        const domainName = $(this.app.SELECTORS.domain).val();
        
        if (!domainName) {
            this.app.alertManager.showError('Please select a domain to synchronize.');
            this.app.navigationManager.goToStep(this.app.STEPS.SYNC_CONFIGURATION);
            return;
        }
        
        const domain = this.app.findDomainByName(domainName);
        
        if (domain) {
            this.syncSingleDomain(domain.id, 0, 1);
        } else {
            this.app.alertManager.showError(`Selected domain "${domainName}" not found.`);
            this.app.navigationManager.goToStep(this.app.STEPS.SYNC_CONFIGURATION);
        }
    }
    
    /**
     * Synchronize a single domain
     */
    syncSingleDomain(domainId, index = 0, total = 1) {
        if (this.app.syncCancelled) return;
        
        const domainName = this.app.domainManager.getDomainNameForDisplay(domainId);
        
        this.updateProgressDisplay(domainName, index, total);
        this.app.tableManager.addProcessingRow(domainName, index + 1, total);
        
        const request = $.post("addonmodules.php", {
            module: 'cnicadmin',
            action: 'sync',
            type: 'syncDomain',
            domainid: domainId
        })
        .done(response => {
            this.handleSyncSuccess(domainName, response);
        })
        .fail(jqXHR => {
            this.handleSyncFailure(domainName, jqXHR);
        });
        
        this.app.activeRequests.push(request);
    }
    
    /**
     * Update progress display
     */
    updateProgressDisplay(domainName, index, total) {
        const progressHtml = this.buildProgressHTML(domainName, index, total);
        $(this.app.SELECTORS.progressText).html(progressHtml);
    }
    
    /**
     * Build progress HTML
     */
    buildProgressHTML(domainName, index, total) {
        return `<div class="cnic-d-flex cnic-align-items-center progress-container">
            <div class="cnic-d-flex cnic-align-items-center progress-info">
                <i class="fa fa-sync fa-spin progress-spinner"></i>
                <span class="progress-label">Syncing domain ${index + 1} of ${total}:</span>
            </div>
            <div class="progress-domain-badge">${domainName}</div>
        </div>`;
    }
    
    /**
     * Handle successful sync response
     */
    handleSyncSuccess(domainName, response) {
        if (!this.app.syncCancelled) {
            this.app.tableManager.updateProcessingRowWithResult(domainName, response);
            this.app.completedDomainsCount++;
            this.app.checkSyncCompletion();
        }
    }
    
    /**
     * Handle sync failure
     */
    handleSyncFailure(domainName, jqXHR) {
        if (!this.app.syncCancelled && jqXHR.statusText !== 'abort') {
            const errorResult = this.buildErrorResult(domainName, jqXHR);
            this.app.tableManager.updateProcessingRowWithResult(domainName, errorResult);
            this.app.completedDomainsCount++;
            this.app.checkSyncCompletion();
        }
    }
    
    /**
     * Build error result object
     */
    buildErrorResult(domainName, jqXHR) {
        let errorMessage = 'Sync failed';
        
        if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
            errorMessage = jqXHR.responseJSON.message;
        }
        
        return {
            domain: domainName,
            status: 'Error: ' + errorMessage,
            old_expiry: '',
            new_expiry: '',
            next_due_date: '',
            next_invoice_date: ''
        };
    }
    
    /**
     * Cancel the sync process
     */
    cancel() {
        // Prevent multiple cancel attempts
        if (this.app.syncCancelled) {
            return;
        }
        
        if (confirm('Are you sure you want to cancel the sync process?')) {
            this.app.syncCancelled = true;
            
            // Update progress text to show cancellation in progress
            $(this.app.SELECTORS.progressText).html('<span style="color: var(--status-warning);">⚠ Cancelling sync process...</span>');
            
            // Abort all active requests
            this.app.activeRequests.forEach(request => {
                if (request && request.readyState !== 4) {
                    try {
                        request.abort();
                    } catch (e) {
                        console.warn('Error aborting request:', e);
                    }
                }
            });
            
            this.app.activeRequests = [];
            
            // Clean up processing rows
            this.app.tableManager.cleanupProcessingRowsOnCancel();
            
            this.finish();
        }
    }
    
    /**
     * Finish sync process
     */
    finish() {
        // Ensure progress indicators are hidden
        $(this.app.SELECTORS.loadingOverlay).hide();
        
        // Use single source of truth for sync controls
        this.app.uiManager.showSyncComplete();
        
        // Only initialize DataTable for successful sync completion, not for cancellation
        if (!this.app.syncCancelled) {
            setTimeout(() => {
                this.app.tableManager.initDataTable();
            }, 200);
        } else {
            // For cancelled sync, just ensure the table is visible without DataTable re-initialization
            $(this.app.SELECTORS.domainTable).show();
            console.log('Skipping DataTable re-initialization after cancellation');
        }
        
        if (this.app.syncCancelled) {
            this.app.alertManager.showError('Sync was cancelled by user');
            // Update progress text to show cancellation
            $(this.app.SELECTORS.progressText).html('<span style="color: var(--status-warning);">⚠ Synchronization was cancelled by user</span>');
        } else {
            // Update progress text to show completion
            $(this.app.SELECTORS.progressText).html('<span style="color: var(--status-success);">✓ Synchronization completed successfully!</span>');
        }
        
        // Reset sync state for future sync attempts
        this.resetSyncState();
    }
    
    /**
     * Reset sync state for fresh start
     */
    resetSyncState() {
        this.app.syncCancelled = false;
        this.app.activeRequests = [];
        this.app.completedDomainsCount = 0;
        this.app.totalDomainsToSync = 0;
        this.app.inCancellationCleanup = false;
    }
}
