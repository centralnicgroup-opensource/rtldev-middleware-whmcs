/**
 * Alert Manager - Handles all notifications and alert messages
 */

class AlertManager {
    constructor(app) {
        this.app = app;
    }
    
    /**
     * Show error message
     */
    showError(message) {
        const alertHtml = `<div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong>Error:</strong> ${message}
        </div>`;
        
        $(this.app.SELECTORS.alertContainer).html(alertHtml);
        
        // Auto-hide after 8 seconds
        setTimeout(() => {
            $('.alert-danger').fadeOut();
        }, 8000);
        
        // Scroll to top to show the error
        $('html, body').animate({
            scrollTop: $(this.app.SELECTORS.alertContainer).offset().top - 100
        }, 500);
    }
    
    /**
     * Show success message
     */
    showSuccess(message) {
        const alertHtml = `<div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong>Success:</strong> ${message}
        </div>`;
        
        $(this.app.SELECTORS.alertContainer).html(alertHtml);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            $('.alert-success').fadeOut();
        }, 5000);
    }
    
    /**
     * Show warning message
     */
    showWarning(message) {
        const alertHtml = `<div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong>Warning:</strong> ${message}
        </div>`;
        
        $(this.app.SELECTORS.alertContainer).html(alertHtml);
        
        // Auto-hide after 6 seconds
        setTimeout(() => {
            $('.alert-warning').fadeOut();
        }, 6000);
    }
    
    /**
     * Show info message
     */
    showInfo(message) {
        const alertHtml = `<div class="alert alert-info alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <strong>Info:</strong> ${message}
        </div>`;
        
        $(this.app.SELECTORS.alertContainer).html(alertHtml);
        
        // Auto-hide after 4 seconds
        setTimeout(() => {
            $('.alert-info').fadeOut();
        }, 4000);
    }
    
    /**
     * Clear all error and success messages
     */
    clearMessages() {
        $('.alert, .error-message, .success-message').remove();
        $('.sync-error').removeClass('sync-error').empty();
    }
    
    /**
     * Show loading message
     */
    showLoading(message = 'Loading...') {
        $(this.app.SELECTORS.loadingOverlay).show();
        if (message !== 'Loading...') {
            $(this.app.SELECTORS.loadingOverlay).find('.loading-text').text(message);
        }
    }
    
    /**
     * Hide loading message
     */
    hideLoading() {
        $(this.app.SELECTORS.loadingOverlay).hide();
    }
}
