/**
 * Navigation Manager - Handles step navigation and route management
 */

class NavigationManager {
    constructor(app) {
        this.app = app;
    }
    
    /**
     * Navigate to a specific step
     */
    goToStep(step) {
        // Handle single registrar case
        if (Object.keys(this.app.supportedRegistrars).length === 1 && step === this.app.STEPS.REGISTRAR_SELECTION) {
            step = this.app.STEPS.SYNC_CONFIGURATION;
        }
        
        // Validate step 3 navigation (except for sync initiation)
        if (step === this.app.STEPS.SYNC_RESULTS && !this.validateStep3Navigation()) {
            return;
        }
        
        this.handleStepTransition(step);
        this.showTargetStep(step);
        this.cleanupPreviousSteps(step);
    }
    
    /**
     * Validate navigation to step 3 (sync results)
     */
    validateStep3Navigation() {
        // Allow if we're actively syncing or have completed a sync
        if (this.app.activeRequests.length > 0 || this.app.completedDomainsCount > 0) {
            return true;
        }
        
        // Allow if we have domains and this might be a direct sync initiation
        if (this.app.domains && this.app.domains.length > 0) {
            return true;
        }
        
        // Block navigation if no domains available
        this.app.alertManager.showError('Cannot view sync results. No domains are available for synchronization. Please select a registrar and load domains first.');
        return false;
    }
    
    /**
     * Handle step transition logic
     */
    handleStepTransition(step) {
        if (step === this.app.STEPS.REGISTRAR_SELECTION) {
            // Complete reset when going back to step 1
            this.completeStateReset();
            $("#selectedRegistrarName").text('');
            $("#domainCount").text('0');
            $(this.app.SELECTORS.alertContainer).empty();
        } else if (step === this.app.STEPS.SYNC_CONFIGURATION) {
            this.app.domainManager.resetStep2Form();
            $(this.app.SELECTORS.alertContainer).empty();
            setTimeout(() => {
                this.app.uiManager.initializeSyncTypeToggle();
            }, 100);
        } else if (step === this.app.STEPS.SYNC_RESULTS) {
            $(this.app.SELECTORS.alertContainer).empty();
        }
    }
    
    /**
     * Show target step
     */
    showTargetStep(step) {
        // Hide all steps and their buttons explicitly
        $('.sync-step').each(function() {
            $(this).removeClass('active').hide().css('display', 'none');
            // Don't hide sync control buttons as they have their own visibility logic
            $(this).find('button, .btn').not('#cancelSyncBtn, #startOverBtn').hide();
        });
        
        // Show target step with explicit styling
        const $targetStep = $('#step' + step);
        
        if ($targetStep.length > 0) {
            $targetStep.addClass('active').show().css('display', 'block');
            // Don't show sync control buttons as they have their own visibility logic
            $targetStep.find('button, .btn').not('#cancelSyncBtn, #startOverBtn').show();
        }
        
        // Special handling for step 3 (sync results)
        if (step === this.app.STEPS.SYNC_RESULTS) {
            this.handleSyncResultsStep();
        }
    }
    
    /**
     * Handle special setup for sync results step
     */
    handleSyncResultsStep() {
        console.log('Setting up sync results step...');
        
        // Ensure table structure exists
        this.app.tableManager.ensureTableStructure();
        
        // Reset UI state for sync controls
        this.resetSyncUIState();
        
        // Check if we have any data in the table to determine if we should initialize DataTable
        const hasTableData = $(this.app.SELECTORS.domainResults + ' tr').length > 0;
        const isActivelySyncing = this.app.activeRequests.length > 0;
        const hasCompletedSync = this.app.completedDomainsCount > 0;
        
        console.log('DataTable init - Existing rows:', hasTableData, 'Active sync:', isActivelySyncing, 'Completed:', hasCompletedSync);
        
        // Only initialize DataTable if we have completed data or existing rows
        // Don't initialize for fresh syncs (empty table) or active syncs
        if ((hasTableData && hasCompletedSync) || (hasTableData && !isActivelySyncing)) {
            console.log('Initializing DataTable with existing data');
            this.app.tableManager.initDataTable();
        } else {
            console.log('Deferring DataTable initialization - fresh sync will initialize after completion');
        }
        
        // Set appropriate button state based on sync status
        if (this.app.activeRequests.length > 0) {
            // Sync in progress
            this.app.uiManager.showSyncInProgress();
        } else if (this.app.completedDomainsCount > 0) {
            // Sync completed
            this.app.uiManager.showSyncComplete();
        } else {
            // No sync activity, hide all controls
            this.app.uiManager.resetSyncControls();
        }
        
        // Debug table state
        this.debugTableState();
    }
    
    /**
     * Reset sync UI state
     */
    resetSyncUIState() {
        // Hide progress indicator if not actively syncing
        if (this.app.activeRequests.length === 0) {
            $(this.app.SELECTORS.syncProgress).addClass('cnic-d-none').hide();
        }
        
        // Clear any temporary error messages
        $('.temp-error-message').remove();
    }
    
    /**
     * Debug table state - helps identify table issues
     */
    debugTableState() {
        console.log('=== Table Debug Info ===');
        console.log('Table element exists:', $(this.app.SELECTORS.domainTable).length > 0);
        console.log('Table is visible:', $(this.app.SELECTORS.domainTable).is(':visible'));
        console.log('Table HTML:', $(this.app.SELECTORS.domainTable).length > 0 ? $(this.app.SELECTORS.domainTable)[0].outerHTML.substring(0, 200) + '...' : 'N/A');
        console.log('DataTable initialized:', $.fn.DataTable && $.fn.DataTable.isDataTable ? $.fn.DataTable.isDataTable(this.app.SELECTORS.domainTable) : 'DataTable not available');
        console.log('domainResults element exists:', $(this.app.SELECTORS.domainResults).length > 0);
        console.log('Current step:', $('.sync-step.active').attr('id'));
        console.log('========================');
    }
    
    /**
     * Complete state reset - use when going back to step 1
     */
    completeStateReset() {
        // Reset all application state
        this.app.resetState();
        
        // Complete form reset
        this.app.domainManager.resetStep2Form();
        
        // Complete DataTable destruction and table cleanup
        this.destroyAndClearDataTable();
        
        // Reset all sync controls to initial state
        this.app.uiManager.resetSyncControls();
        
        // Clear all messages
        this.app.alertManager.clearMessages();
        
        // Clear progress text
        $(this.app.SELECTORS.progressText).empty();
    }
    
    /**
     * Destroy DataTable and clear all table content completely
     */
    destroyAndClearDataTable() {
        try {
            // Destroy DataTable but keep DOM structure
            if ($.fn.DataTable && $.fn.DataTable.isDataTable(this.app.SELECTORS.domainTable)) {
                $(this.app.SELECTORS.domainTable).DataTable().destroy();
            }
            
            // Clear all DataTable related classes and attributes
            $(this.app.SELECTORS.domainTable).removeClass('dataTable no-footer');
            $(this.app.SELECTORS.domainTable).removeAttr('style role aria-describedby');
            $(this.app.SELECTORS.domainTable).find('thead th').removeClass('sorting sorting_asc sorting_desc');
            $(this.app.SELECTORS.domainTable).find('thead th').removeAttr('style tabindex aria-controls aria-label');
            
            // Remove any DataTable wrapper elements that might exist
            $('.dataTables_wrapper').remove();
            $(this.app.SELECTORS.domainTable + '_wrapper').remove();
            $(this.app.SELECTORS.domainTable + '_info').remove();
            $(this.app.SELECTORS.domainTable + '_paginate').remove();
            $(this.app.SELECTORS.domainTable + '_length').remove();
            $(this.app.SELECTORS.domainTable + '_filter').remove();
            
            // Clear table content completely
            $(this.app.SELECTORS.domainResults).empty();
            
            // Ensure clean table structure exists
            this.app.tableManager.recreateTableStructure();
            
        } catch (e) {
            console.warn('Complete DataTable destruction error:', e);
            // Fallback: force clean the table
            this.app.tableManager.recreateTableStructure();
        }
    }
    
    /**
     * Cleanup when going back to previous steps
     */
    cleanupPreviousSteps(step) {
        if (step < this.app.STEPS.SYNC_RESULTS) {
            // Complete cleanup when leaving sync results
            this.destroyAndClearDataTable();
            
            // Reset sync state completely
            this.app.syncEngine.resetSyncState();
            
            // Reset all sync controls
            this.app.uiManager.resetSyncControls();
            
            // Clear any error messages
            this.app.alertManager.clearMessages();
            
            // Clear progress text
            $(this.app.SELECTORS.progressText).empty();
        }
    }
}
