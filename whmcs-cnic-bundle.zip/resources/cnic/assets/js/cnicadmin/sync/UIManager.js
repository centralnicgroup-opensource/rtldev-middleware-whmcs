/**
 * UI Manager - Handles all user interface interactions and visual states
 */

class UIManager {
    constructor(app) {
        this.app = app;
    }
    
    /**
     * Initialize sync type toggle functionality with modern interactions
     */
    initializeSyncTypeToggle() {
        // Remove existing event handlers to prevent duplicates
        $('input[name="syncType"]').off('change.syncToggle');
        $('.sync-choice-card, .modern-choice-card').off('click.syncToggle mouseenter.syncToggle mouseleave.syncToggle');
        
        // Handle radio button changes
        $('input[name="syncType"]').on('change.syncToggle', () => {
            this.updateModernChoiceCardStates();
            this.toggleDomainInput();
        });
        
        // Handle modern choice card clicks with enhanced animations
        $('.sync-choice-card, .modern-choice-card').on('click.syncToggle', (e) => {
            e.preventDefault();
            this.handleChoiceCardClick($(e.currentTarget));
        });
        
        // Enhanced hover effects for modern cards
        $('.sync-choice-card, .modern-choice-card')
            .on('mouseenter.syncToggle', (e) => {
                this.handleChoiceCardHover($(e.currentTarget), true);
            })
            .on('mouseleave.syncToggle', (e) => {
                this.handleChoiceCardHover($(e.currentTarget), false);
            });
        
        // Initialize with default state
        this.updateModernChoiceCardStates();
        this.toggleDomainInput();
    }
    
    /**
     * Handle choice card click animation
     */
    handleChoiceCardClick($card) {
        const $radioButton = $card.find('input[name="syncType"]');
        
        // Add click animation
        $card.css('transform', 'scale(0.98)');
        
        setTimeout(() => {
            $card.css('transform', '');
            $radioButton.prop('checked', true).trigger('change');
        }, 100);
    }
    
    /**
     * Handle choice card hover effects
     */
    handleChoiceCardHover($card, isEntering) {
        const isSelected = $card.find('input[type="radio"]').is(':checked');
        
        if (!isSelected) {
            if (isEntering) {
                $card.css({
                    'transform': 'translateY(-4px)',
                    'box-shadow': '0 12px 32px rgba(0, 0, 0, 0.1)',
                    'transition': 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
                });
            } else {
                $card.css({
                    'transform': 'translateY(0)',
                    'box-shadow': '0 4px 16px rgba(0, 0, 0, 0.05)'
                });
            }
        }
    }
    
    /**
     * Toggle domain input visibility based on sync type
     */
    toggleDomainInput() {
        const syncType = $('input[name="syncType"]:checked').val() || this.app.SYNC_TYPES.ALL;
        const $domainInput = $(this.app.SELECTORS.domainInput);
        
        if (syncType === this.app.SYNC_TYPES.SINGLE) {
            this.showDomainInput($domainInput);
        } else {
            this.hideDomainInput($domainInput);
        }
        
        // Update sync button state when sync type changes
        this.app.domainManager.updateSyncButtonState();
    }
    
    /**
     * Show domain input section
     */
    showDomainInput($domainInput) {
        $domainInput.show();
        $(this.app.SELECTORS.domain).prop('disabled', false);
        $(this.app.SELECTORS.domainSearch).prop('disabled', false).show();
        
        // Add smooth animation class
        $domainInput.addClass('domain-selection-row');
        
        // Populate domain dropdown if domains are available
        if (this.app.domains && this.app.domains.length > 0) {
            this.app.domainManager.filterDomains();
        } else {
            $(this.app.SELECTORS.domainHelp).text('No domains loaded. Please select a registrar first.');
        }
        
        this.app.domainManager.updateDomainHelp();
    }
    
    /**
     * Hide domain input section
     */
    hideDomainInput($domainInput) {
        $domainInput.hide();
        $(this.app.SELECTORS.domain).prop('disabled', true);
        $(this.app.SELECTORS.domainSearch).prop('disabled', true).hide().val('');
        
        // Clear selection
        $(this.app.SELECTORS.domain).val('');
        
        // Remove animation class
        $domainInput.removeClass('domain-selection-row');
    }
    
    /**
     * Update visual states - Legacy support
     */
    updateChoiceCardStates() {
        const checkedValue = $('input[name="syncType"]:checked').val();
        
        // Reset all choice cards
        $('.sync-choice-card, .enhanced-choice-card').removeClass('active');
        $('.choice-indicator i')
            .removeClass('fa-check-circle')
            .addClass('fa-circle-o')
            .css('color', '#ddd');
        
        // Update the selected choice card
        const $checkedCard = $('input[name="syncType"]:checked').closest('.sync-choice-card, .enhanced-choice-card');
        
        $checkedCard.addClass('active');
        $checkedCard.find('.choice-indicator i')
            .removeClass('fa-circle-o')
            .addClass('fa-check-circle')
            .css('color', '#5cb85c');
        
        this.updateContainerClasses(checkedValue);
    }
    
    /**
     * Enhanced function to update modern choice card visual states
     */
    updateModernChoiceCardStates() {
        const checkedValue = $('input[name="syncType"]:checked').val();
        
        this.resetAllChoiceCards();
        this.updateSelectedChoiceCard(checkedValue);
        this.updateContainerClasses(checkedValue);
    }
    
    /**
     * Reset all choice cards to default state
     */
    resetAllChoiceCards() {
        $('.sync-choice-card, .modern-choice-card, .enhanced-choice-card').each((index, element) => {
            const $card = $(element);
            const $indicator = $card.find('.choice-indicator');
            const $overlay = $card.find('.choice-overlay');
            
            $card.removeClass('active').css({
                'border-color': '#e2e8f0',
                'transform': 'translateY(0)',
                'box-shadow': '0 4px 16px rgba(0, 0, 0, 0.05)',
                'transition': 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
            });
            
            this.resetIndicatorIcon($card, $indicator);
            
            if ($overlay.length) {
                $overlay.css('opacity', '0');
            }
        });
    }
    
    /**
     * Reset indicator icon styles
     */
    resetIndicatorIcon($card, $indicator) {
        let $icon;
        
        if ($indicator.length) {
            $icon = $indicator.find('i');
        } else {
            $icon = $card.find('.choice-indicator i');
        }
        
        $icon.removeClass('fa-check-circle')
            .addClass('fa-circle-o')
            .css('color', '#cbd5e1');
    }
    
    /**
     * Update the selected choice card with modern styling
     */
    updateSelectedChoiceCard(checkedValue) {
        const $checkedCard = $('input[name="syncType"]:checked').closest('.sync-choice-card, .modern-choice-card, .enhanced-choice-card');
        
        if ($checkedCard.length === 0) return;
        
        const colors = this.getChoiceCardColors(checkedValue);
        const $indicator = $checkedCard.find('.choice-indicator');
        const $overlay = $checkedCard.find('.choice-overlay');
        
        // Apply modern selected styling
        $checkedCard.addClass('active').css({
            'border-color': colors.border,
            'transform': 'scale(1.02)',
            'box-shadow': colors.shadow
        });
        
        this.updateSelectedIndicatorIcon($checkedCard, $indicator, colors.icon);
        
        if ($overlay.length) {
            $overlay.css('opacity', '1');
        }
    }
    
    /**
     * Get colors for choice card based on type
     */
    getChoiceCardColors(checkedValue) {
        return {
            border: checkedValue === this.app.SYNC_TYPES.ALL ? '#667eea' : '#10b981',
            shadow: checkedValue === this.app.SYNC_TYPES.ALL 
                ? '0 8px 32px rgba(102, 126, 234, 0.2)' 
                : '0 8px 32px rgba(16, 185, 129, 0.2)',
            icon: checkedValue === this.app.SYNC_TYPES.ALL ? '#667eea' : '#10b981'
        };
    }
    
    /**
     * Update selected indicator icon
     */
    updateSelectedIndicatorIcon($checkedCard, $indicator, iconColor) {
        let $icon;
        
        if ($indicator.length) {
            $icon = $indicator.find('i');
        } else {
            $icon = $checkedCard.find('.choice-indicator i');
        }
        
        $icon.removeClass('fa-circle-o')
            .addClass('fa-check-circle')
            .css('color', iconColor);
    }
    
    /**
     * Update dynamic layout classes for responsive behavior
     */
    updateContainerClasses(checkedValue) {
        const containers = [
            $('.choice-cards-container').closest('.panel-body'),
            $('.choice-cards-container').parent(),
            $('.panel-body').first(),
            $('body'),
            $('.sync-step.active')
        ];
        
        containers.forEach(container => {
            if (container.length > 0) {
                container.removeClass('sync-type-all sync-type-single single-selected all-selected');
                
                if (checkedValue === this.app.SYNC_TYPES.ALL) {
                    container.addClass('sync-type-all all-selected');
                } else if (checkedValue === this.app.SYNC_TYPES.SINGLE) {
                    container.addClass('sync-type-single single-selected');
                }
            }
        });
    }
    
    /**
     * Single source of truth for sync control state management
     */
    resetSyncControls() {
        // Reset cancel button to enabled and hidden state
        $(this.app.SELECTORS.cancelSyncBtn)
            .removeClass('cnic-d-none hidden')
            .prop('disabled', false)
            .css('display', 'none')
            .hide();
        
        // Reset start over button to hidden state  
        $(this.app.SELECTORS.startOverBtn)
            .removeClass('cnic-d-none hidden')
            .css('display', 'none')
            .hide();
        
        // Hide progress indicator
        $(this.app.SELECTORS.syncProgress)
            .addClass('cnic-d-none')
            .hide();
    }
    
    /**
     * Show sync controls when sync starts
     */
    showSyncInProgress() {
        $(this.app.SELECTORS.cancelSyncBtn)
            .removeClass('cnic-d-none hidden')
            .prop('disabled', false)
            .css('display', 'inline-block')
            .show();
        
        $(this.app.SELECTORS.startOverBtn)
            .addClass('cnic-d-none hidden')
            .css('display', 'none')
            .hide();
        
        $(this.app.SELECTORS.syncProgress)
            .removeClass('cnic-d-none')
            .show();
    }
    
    /**
     * Show sync complete controls
     */
    showSyncComplete() {
        $(this.app.SELECTORS.cancelSyncBtn)
            .addClass('cnic-d-none hidden')
            .css('display', 'none')
            .hide();
        
        $(this.app.SELECTORS.startOverBtn)
            .removeClass('cnic-d-none hidden')
            .css('display', 'inline-block')
            .show();
        
        $(this.app.SELECTORS.syncProgress)
            .addClass('cnic-d-none')
            .hide();
    }
}
