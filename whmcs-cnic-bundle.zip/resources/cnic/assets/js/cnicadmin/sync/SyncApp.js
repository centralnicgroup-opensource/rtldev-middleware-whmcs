/**
 * CentralNic Domain Expiry Sync - Core Application
 * Main application class that coordinates all sync functionality
 */

class SyncApp {
    constructor() {
        // Core application state
        this.domains = [];
        this.supportedRegistrars = window.supportedRegistrars || {};
        this.domainId = window.domainId || '';
        this.activeRequests = [];
        
        // State tracking
        this.syncCancelled = false;
        this.totalDomainsToSync = 0;
        this.completedDomainsCount = 0;
        this.inCancellationCleanup = false;
        
        // Constants
        this.STEPS = {
            REGISTRAR_SELECTION: 1,
            SYNC_CONFIGURATION: 2,
            SYNC_RESULTS: 3
        };
        
        this.SYNC_TYPES = {
            ALL: 'all',
            SINGLE: 'single'
        };
        
        this.SELECTORS = {
            loadingOverlay: '#loadingOverlay',
            registrar: '#registrar',
            domainInput: '#domainInput',
            domainSearch: '#domainSearch',
            domain: '#domain',
            domainHelp: '#domainHelp',
            syncProgress: '#syncProgress',
            progressText: '#progressText',
            cancelSyncBtn: '#cancelSyncBtn',
            startOverBtn: '#startOverBtn',
            domainResults: '#domainResults',
            domainTable: '#domainTable',
            alertContainer: '#alertContainer'
        };
        
        // Initialize modules
        this.domainManager = new DomainManager(this);
        this.uiManager = new UIManager(this);
        this.syncEngine = new SyncEngine(this);
        this.tableManager = new TableManager(this);
        this.navigationManager = new NavigationManager(this);
        this.alertManager = new AlertManager(this);
    }
    
    /**
     * Initialize the application
     */
    init() {
        this.initializeStepVisibility();
        this.bindEvents();
        this.handleAutoSync();
        this.handleSingleRegistrar();
    }
    
    /**
     * Initialize step visibility
     */
    initializeStepVisibility() {
        $('.sync-step').removeClass('active').hide();
        $('#step' + this.STEPS.REGISTRAR_SELECTION).addClass('active').show();
    }
    
    /**
     * Bind event handlers
     */
    bindEvents() {
        const self = this;
        
        // Initialize sync type toggle functionality with delay for DOM readiness
        setTimeout(() => {
            self.uiManager.initializeSyncTypeToggle();
            self.uiManager.updateModernChoiceCardStates();
        }, 100);
        
        // Bind domain selection change event
        $(document).on('change', this.SELECTORS.domain, function() {
            self.domainManager.updateSyncButtonState();
        });
        
        // Bind registrar change event to load domains
        $(document).on('change', this.SELECTORS.registrar, function() {
            if ($(this).val()) {
                self.domainManager.fetchDomains();
            }
        });
        
        // Bind fetch domains button
        $(document).on('click', '.fetch-domains-btn', function(e) {
            e.preventDefault();
            self.domainManager.fetchDomains();
        });
        
        // Bind navigation buttons
        $(document).on('click', '.sync-prev-button', function(e) {
            e.preventDefault();
            const step = $(this).data('step') || self.STEPS.REGISTRAR_SELECTION;
            self.navigationManager.goToStep(step);
        });
        
        $(document).on('click', '.sync-next-button', function(e) {
            e.preventDefault();
            const step = $(this).data('step') || self.STEPS.SYNC_CONFIGURATION;
            self.navigationManager.goToStep(step);
        });
        
        // Bind sync start button
        $(document).on('click', '.sync-start-button', function(e) {
            e.preventDefault();
            if (!$(this).hasClass('disabled')) {
                self.syncEngine.start();
            }
        });
        
        // Bind cancel sync button
        $(document).on('click', this.SELECTORS.cancelSyncBtn, function(e) {
            e.preventDefault();
            self.syncEngine.cancel();
        });
        
        // Bind start over button
        $(document).on('click', this.SELECTORS.startOverBtn, function(e) {
            e.preventDefault();
            self.navigationManager.goToStep(self.STEPS.REGISTRAR_SELECTION);
        });
    }
    
    /**
     * Handle auto-sync for single domain
     */
    handleAutoSync() {
        if (this.domainId) {
            this.navigationManager.goToStep(this.STEPS.SYNC_RESULTS);
            this.syncEngine.syncSingleDomain(this.domainId);
        }
    }
    
    /**
     * Handle single registrar auto-selection
     */
    handleSingleRegistrar() {
        const registrarKeys = Object.keys(this.supportedRegistrars);
        if (registrarKeys.length === 1) {
            $(this.SELECTORS.registrar).val(registrarKeys[0]);
            this.domainManager.fetchDomains();
        }
    }
    
    /**
     * Reset application state for fresh start
     */
    resetState() {
        this.domains = [];
        this.completedDomainsCount = 0;
        this.totalDomainsToSync = 0;
        this.activeRequests = [];
        this.syncCancelled = false;
        this.inCancellationCleanup = false;
    }
    
    /**
     * Get domain object by name
     */
    findDomainByName(domainName) {
        return this.domains.find(domain => domain.domain === domainName);
    }
    
    /**
     * Check if sync is completed
     */
    checkSyncCompletion() {
        if (this.completedDomainsCount >= this.totalDomainsToSync) {
            this.syncEngine.finish();
        }
    }
}

// Initialize application when this module loads
const syncApp = new SyncApp();
syncApp.init();
