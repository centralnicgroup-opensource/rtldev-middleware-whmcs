/**
 * Table Manager - Handles all table operations and DataTable management
 */

class TableManager {
    constructor(app) {
        this.app = app;
    }
    
    /**
     * Prepare DataTable for new sync - clear content and ensure proper structure
     */
    prepareForNewSync() {
        console.log('Preparing DataTable for new sync...');
        
        // Destroy existing DataTable if it exists
        try {
            if ($.fn.DataTable && $.fn.DataTable.isDataTable(this.app.SELECTORS.domainTable)) {
                $(this.app.SELECTORS.domainTable).DataTable().destroy();
                console.log('Destroyed existing DataTable');
            }
        } catch (e) {
            console.warn('Error destroying DataTable:', e);
        }
        
        // Clear all table content - this is for a fresh sync start
        $(this.app.SELECTORS.domainResults).empty();
        console.log('Cleared table content for fresh sync start');
        
        // Ensure clean table structure
        this.ensureTableStructure();
        
        // Table is ready - processing rows will be added as domains are processed
        $(this.app.SELECTORS.domainTable).show();
    }
    
    /**
     * Add processing row to results table
     */
    addProcessingRow(domainName, currentIndex, total) {
        // Get domain ID for consistent row identification
        const domainId = this.getDomainIdForName(domainName);
        const rowId = this.generateDomainRowId(domainId);
        
        console.log('Adding processing row for:', domainName, 'ID:', rowId);
        
        // Check if row already exists - if so, update it instead of removing
        const $existingRow = $('#' + rowId);
        if ($existingRow.length > 0) {
            console.log('Updating existing processing row for:', domainName);
            this.updateExistingProcessingRow($existingRow, domainName, currentIndex, total);
            return;
        }
        
        // Only create new row if none exists
        console.log('Creating new processing row for:', domainName);
        const rowHtml = this.buildProcessingRowHTML(rowId, domainName, currentIndex, total);
        $(this.app.SELECTORS.domainResults).append(rowHtml);
    }
    
    /**
     * Update existing processing row with new progress info
     */
    updateExistingProcessingRow($row, domainName, currentIndex, total) {
        // Update the status cell with new progress info
        const $statusCell = $row.find('td:nth-child(2)'); // Status is the 2nd column
        const newStatusHtml = `<div class="cnic-d-flex cnic-align-items-center">
            <div class="status-icon-container cnic-d-flex cnic-align-items-center cnic-justify-content-center cnic-mr-3">
                <i class="fa fa-sync fa-spin processing-spinner"></i>
            </div>
            <span class="processing-text">Processing (${currentIndex}/${total})</span>
        </div>`;
        
        $statusCell.html(newStatusHtml);
        
        // Ensure row has correct classes and data attributes
        $row.addClass('processing-row')
            .removeClass('completed-row')
            .attr('data-domain', domainName);
    }
    
    /**
     * Get domain ID for a given domain name
     */
    getDomainIdForName(domainName) {
        // Handle special cases (system messages, etc.)
        if (!domainName || domainName.startsWith('---') || domainName === 'SYNC CANCELLED') {
            return domainName.replace(/[^a-zA-Z0-9]/g, '');
        }
        
        if (this.app.domains && this.app.domains.length > 0) {
            const domainObj = this.app.domains.find(domain => domain.domain === domainName);
            
            if (domainObj && domainObj.id) {
                return domainObj.id;
            }
        }
        
        // Fallback: use domain name if ID not found
        return domainName.replace(/[^a-zA-Z0-9]/g, '');
    }
    
    /**
     * Generate consistent row ID using domain ID
     */
    generateDomainRowId(domainId) {
        return 'domain-row-' + domainId.toString().replace(/[^a-zA-Z0-9]/g, '');
    }
    
    /**
     * Build processing row HTML
     */
    buildProcessingRowHTML(rowId, domainName, currentIndex, total) {
        return `<tr id="${rowId}" class="processing-row" data-domain="${domainName}">
            ${this.buildProcessingDomainCell(domainName)}
            ${this.buildProcessingStatusCell(currentIndex, total)}
            ${this.buildProcessingPlaceholderCell()}
        </tr>`;
    }
    
    /**
     * Build processing domain cell
     */
    buildProcessingDomainCell(domainName) {
        return `<td class="processing-domain-cell">
            <div class="cnic-d-flex cnic-align-items-center">
                <div class="domain-indicator cnic-mr-2"></div>
                <span class="cnic-text-nowrap">${domainName}</span>
            </div>
        </td>`;
    }
    
    /**
     * Build processing status cell
     */
    buildProcessingStatusCell(currentIndex, total) {
        return `<td class="processing-status-cell">
            <div class="cnic-d-flex cnic-align-items-center">
                <div class="status-icon-container cnic-d-flex cnic-align-items-center cnic-justify-content-center cnic-mr-3">
                    <i class="fa fa-sync fa-spin processing-spinner"></i>
                </div>
                <span class="processing-text">Processing (${currentIndex}/${total})</span>
            </div>
        </td>`;
    }
    
    /**
     * Build processing placeholder cell
     */
    buildProcessingPlaceholderCell() {
        return `<td class="processing-placeholder-cell">
            <div class="cnic-d-flex cnic-align-items-center cnic-justify-content-center processing-placeholder-content">
                <i class="fa fa-clock processing-placeholder-icon"></i>
                <span class="processing-placeholder-text">Synchronizing...</span>
            </div>
        </td>
        <td class="processing-placeholder-cell">-</td>
        <td class="processing-placeholder-cell">-</td>
        <td class="processing-placeholder-cell">-</td>`;
    }
    
    /**
     * Update processing row with final result
     */
    updateProcessingRowWithResult(domainName, result) {
        const domainId = this.getDomainIdForName(domainName);
        const rowId = this.generateDomainRowId(domainId);
        const $existingRow = $('#' + rowId);
        
        console.log('Updating processing row with result for:', domainName, 'Row ID:', rowId, 'Row found:', $existingRow.length > 0);
        
        if ($existingRow.length === 0) {
            console.log('No existing row found, creating new result row for:', domainName);
            this.addResultRowWithId(result, rowId);
            return;
        }
        
        console.log('Updating existing row in place for:', domainName);
        const statusInfo = this.getStatusInfo(result.status || '');
        const updatedRowHtml = this.buildResultRowHTML(result, domainName, statusInfo);
        
        this.updateRowStyling($existingRow, updatedRowHtml);
        this.refreshDataTableIfExists();
    }
    
    /**
     * Add result row with specific ID
     */
    addResultRowWithId(result, rowId) {
        const $existingRow = $('#' + rowId);
        
        console.log('addResultRowWithId called for:', result.domain, 'Row ID:', rowId, 'Existing row:', $existingRow.length > 0);
        
        // If row exists, try to update it in place first
        if ($existingRow.length > 0) {
            console.log('Updating existing row in place for:', result.domain);
            const statusInfo = this.getStatusInfo(result.status || '');
            const updatedRowHtml = this.buildResultRowHTML(result, result.domain || '', statusInfo);
            
            this.updateRowStyling($existingRow, updatedRowHtml);
            
            if (!this.app.inCancellationCleanup) {
                this.refreshDataTableIfExists();
            }
            return;
        }
        
        // Only create new row if none exists
        console.log('Creating new result row for:', result.domain);
        const statusInfo = this.getStatusInfo(result.status || '');
        const rowHtml = this.buildCompleteRowHTMLWithId(result, statusInfo, rowId);
        
        $(this.app.SELECTORS.domainResults).append(rowHtml);
        
        if (!this.app.inCancellationCleanup) {
            this.refreshDataTableIfExists();
        }
    }
    
    /**
     * Get status information for styling
     */
    getStatusInfo(status) {
        const statusLower = status.toLowerCase();
        
        if (statusLower.includes('success') || statusLower.includes('processed')) {
            return { icon: 'fa-check-circle', color: 'var(--status-success)', class: 'success' };
        } else if (statusLower.includes('error') || statusLower.includes('failed')) {
            return { icon: 'fa-times-circle', color: 'var(--status-error)', class: 'error' };
        } else if (statusLower.includes('cancelled')) {
            return { icon: 'fa-ban', color: 'var(--status-warning)', class: 'cancelled' };
        } else if (statusLower.includes('unchanged')) {
            return { icon: 'fa-minus-circle', color: 'var(--status-warning)', class: 'warning' };
        } else {
            return { icon: 'fa-info-circle', color: 'var(--text-muted)', class: 'info' };
        }
    }
    
    /**
     * Build result row HTML with standardized colors
     */
    buildResultRowHTML(result, domainName, statusInfo) {
        const oldExpiryColors = this.getDateCellColors('old_expiry');
        const newExpiryColors = this.getDateCellColors('new_expiry');
        const dueDateColors = this.getDateCellColors('next_due_date');
        const invoiceColors = this.getDateCellColors('next_invoice_date');
        
        return this.buildDomainCell(result.domain || domainName) +
            this.buildStatusCell(result.status || '', statusInfo) +
            this.buildDateCell(result.old_expiry, oldExpiryColors.bg, oldExpiryColors.text) +
            this.buildDateCell(result.new_expiry, newExpiryColors.bg, newExpiryColors.text) +
            this.buildDateCell(result.next_due_date, dueDateColors.bg, dueDateColors.text) +
            this.buildDateCell(result.next_invoice_date, invoiceColors.bg, invoiceColors.text);
    }
    
    /**
     * Build complete row HTML with specific ID
     */
    buildCompleteRowHTMLWithId(result, statusInfo, rowId) {
        return `<tr id="${rowId}" class="completed-row" data-domain="${result.domain || ''}" style="border-bottom: 1px solid var(--border-light); transition: all 0.2s ease;">
            ${this.buildResultRowHTML(result, result.domain || '', statusInfo)}
        </tr>`;
    }
    
    /**
     * Build domain cell HTML
     */
    buildDomainCell(domainName) {
        return `<td class="cnic-border-0" style="padding: var(--spacing-xl) var(--spacing-2xl); font-weight: 500; color: var(--text-primary); font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace; font-size: 14px;">
            <div class="cnic-d-flex cnic-align-items-center">
                <div class="domain-indicator cnic-mr-2" style="animation: none;"></div>
                <span>${domainName}</span>
            </div>
        </td>`;
    }
    
    /**
     * Build status cell HTML
     */
    buildStatusCell(status, statusInfo) {
        const statusClass = statusInfo.class || 'info';
        
        return `<td class="cnic-border-0" style="padding: var(--spacing-xl) var(--spacing-2xl);">
            <div class="cnic-d-flex cnic-align-items-center">
                <div class="status-indicator ${statusClass} cnic-d-flex cnic-align-items-center cnic-justify-content-center cnic-mr-3">
                    <i class="fa ${statusInfo.icon}"></i>
                </div>
                <span class="cnic-text-secondary" style="font-size: 14px; font-weight: 500;">${status}</span>
            </div>
        </td>`;
    }
    
    /**
     * Build date cell HTML with consistent styling
     */
    buildDateCell(dateValue, bgColor, textColor) {
        let content = '-';
        
        if (dateValue) {
            content = `<div style="background: ${bgColor}; color: ${textColor}; padding: var(--spacing-sm) var(--spacing-md); border-radius: var(--radius-sm); font-size: 13px; font-weight: 500; display: inline-block;">${dateValue}</div>`;
        }
        
        return `<td style="padding: var(--spacing-xl) var(--spacing-2xl); border: none; color: var(--text-muted); font-size: 14px;">${content}</td>`;
    }
    
    /**
     * Get standardized date cell colors
     */
    getDateCellColors(type) {
        const colorSchemes = {
            old_expiry: {
                bg: 'var(--status-warning-bg)',
                text: 'var(--status-warning-text)'
            },
            new_expiry: {
                bg: 'var(--status-success-bg)',
                text: 'var(--status-success-text)'
            },
            next_due_date: {
                bg: 'var(--status-processing-bg)',
                text: 'var(--status-processing-text)'
            },
            next_invoice_date: {
                bg: 'var(--status-info-bg)',
                text: 'var(--status-info-text)'
            }
        };
        
        return colorSchemes[type] || { bg: 'var(--bg-muted)', text: 'var(--text-muted)' };
    }
    
    /**
     * Update row styling
     */
    updateRowStyling($row, updatedRowHtml) {
        const rowId = $row.attr('id');
        const domainName = $row.data('domain') || $row.find('td:first').text().trim();
        
        $row.removeClass('processing-row')
            .addClass('completed-row')
            .attr('data-domain', domainName)
            .css({
                'background': 'var(--bg-white)',
                'animation': 'fadeInUp 0.5s ease',
                'border-bottom': '1px solid var(--border-light)'
            })
            .html(updatedRowHtml);
        
        // Keep the same row ID - don't remove it
        if (rowId) {
            $row.attr('id', rowId);
        }
    }
    
    /**
     * Clean up processing rows when sync is cancelled
     */
    cleanupProcessingRowsOnCancel() {
        console.log('Starting cleanup of processing rows on cancel...');
        
        this.app.inCancellationCleanup = true;
        
        // Handle active processing rows
        $(this.app.SELECTORS.domainResults + ' tr.processing-row').each((index, element) => {
            const $row = $(element);
            const domainName = $row.find('td:first span, td:first').text().trim() || $row.data('domain');
            
            if (domainName && domainName !== '') {
                const cancelledStatusInfo = this.getStatusInfo('Cancelled');
                const updatedRowHtml = this.buildResultRowHTML({
                    domain: domainName,
                    status: 'Cancelled',
                    old_expiry: '',
                    new_expiry: '',
                    next_due_date: '',
                    next_invoice_date: ''
                }, domainName, cancelledStatusInfo);
                
                this.updateRowStyling($row, updatedRowHtml);
                console.log('Updated processing row to cancelled for:', domainName);
            }
        });
        
        this.app.inCancellationCleanup = false;
    }
    
    /**
     * Initialize DataTable
     */
    initDataTable() {
        if (typeof $.fn.DataTable === 'undefined') {
            console.warn('DataTable library not available');
            return;
        }

        try {
            this.ensureTableStructure();
            
            const hasExistingData = $(this.app.SELECTORS.domainResults + ' tr').length > 0;
            console.log('DataTable init - Existing rows:', hasExistingData);

            // Destroy existing DataTable if it exists
            if ($.fn.DataTable.isDataTable(this.app.SELECTORS.domainTable)) {
                $(this.app.SELECTORS.domainTable).DataTable().destroy(false);
            }

            // Clear DataTable classes but preserve content
            $(this.app.SELECTORS.domainTable).removeClass('dataTable no-footer');
            $(this.app.SELECTORS.domainTable).find('thead th').removeClass('sorting sorting_asc sorting_desc');
            $(this.app.SELECTORS.domainTable).removeAttr('style role aria-describedby');
            
            // Initialize DataTable
            setTimeout(() => {
                try {
                    $(this.app.SELECTORS.domainTable).DataTable(this.getDataTableConfig());
                    console.log('DataTable initialized successfully');
                } catch (e) {
                    console.warn('DataTable initialization failed:', e);
                }
            }, 100);
            
        } catch (e) {
            console.warn('DataTable setup failed:', e);
        }
    }
    
    /**
     * Get DataTable configuration
     */
    getDataTableConfig() {
        return {
            pageLength: 15,
            order: [[0, 'asc']],
            responsive: true,
            searching: true,
            paging: true,
            info: true,
            autoWidth: false,
            processing: false,
            deferRender: true,
            dom: '<"row"<"col-sm-6"l><"col-sm-6"f>>' +
                 '<"row"<"col-sm-12"tr>>' +
                 '<"row"<"col-sm-5"i><"col-sm-7"p>>',
            language: {
                search: "Search domains:",
                lengthMenu: "Show _MENU_ domains per page",
                info: "Showing _START_ to _END_ of _TOTAL_ sync results",
                infoEmpty: "No sync results available",
                infoFiltered: "(filtered from _MAX_ total results)",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                },
                emptyTable: "No sync results available"
            },
            columnDefs: [
                { targets: [0], orderable: true, searchable: true, width: "20%" },
                { targets: [1], orderable: true, searchable: true, width: "15%" },
                { targets: [2, 3, 4, 5], orderable: true, searchable: false, width: "16%" }
            ],
            error: function(settings, helpPage, message) {
                console.warn('DataTable error:', message);
                return true;
            }
        };
    }
    
    /**
     * Refresh DataTable if it exists
     */
    refreshDataTableIfExists() {
        try {
            if ($.fn.DataTable && $.fn.DataTable.isDataTable(this.app.SELECTORS.domainTable)) {
                const table = $(this.app.SELECTORS.domainTable).DataTable();
                table.draw(false);
            }
        } catch (e) {
            console.warn('DataTable refresh failed:', e);
        }
    }
    
    /**
     * Ensure table structure exists for DataTable initialization
     */
    ensureTableStructure() {
        const $table = $(this.app.SELECTORS.domainTable);
        
        if ($table.length === 0) {
            console.warn('Domain table element not found in DOM');
            return;
        }
        
        // Check if table has proper structure
        const hasValidStructure = $table.find('thead').length > 0 && $table.find('tbody' + this.app.SELECTORS.domainResults).length > 0;
        
        if (!hasValidStructure) {
            console.log('Recreating table structure for DataTable');
            this.recreateTableStructure();
        }
    }
    
    /**
     * Recreate clean table structure
     */
    recreateTableStructure() {
        const cleanTableHTML = `
            <thead class="results-table-header">
                <tr>
                    <th class="domain-column"><i class="fa fa-globe"></i> Domain Name</th>
                    <th class="status-column"><i class="fa fa-check-circle"></i> Status</th>
                    <th class="old-expiry-column"><i class="fa fa-calendar-times"></i> Old Expiry</th>
                    <th class="new-expiry-column"><i class="fa fa-calendar-check"></i> New Expiry</th>
                    <th class="next-due-column"><i class="fa fa-clock"></i> Next Due Date</th>
                    <th class="invoice-column"><i class="fa fa-file-invoice"></i> Invoice Date</th>
                </tr>
            </thead>
            <tbody id="domainResults" class="results-table-body">
            </tbody>`;
        
        $(this.app.SELECTORS.domainTable).html(cleanTableHTML);
    }
}
