// jQuery script for AJAX submission of registrar settings form
$(document).ready(function () {
    var registrarHelper = window.CnicAdminRegistrarHelper;
    var $form = $("#registrarSettingsForm");
    var $btn = $("#saveRegistrarSettingsBtn");
    var $loader = $("#loadingIndicator");
    var $registrar = $("#registrar");
    var $loadBtn = $("#loadRegistrarSettingsBtn");
    var loadedRegistrar = (($form.data("loadedRegistrar") || $registrar.val() || "") + "").trim();

    function showAlert(type, message) {
        const alertTypes = {
            success: 'alert-success',
            error: 'alert-danger',
            warning: 'alert-warning',
            info: 'alert-info'
        };
        const alertClass = alertTypes[type] || 'alert-info';
        const alert = `
            <div class="alert ${alertClass} alert-dismissible" role="alert">
                ${message}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        `;
        $('#alertContainer').html(alert);
        if (type !== 'error') {
            setTimeout(function () {
                $('.alert').fadeOut();
            }, 5000);
        }
    }

    function updateSaveButtonState() {
        var selectedRegistrar = registrarHelper.getValue($registrar);
        $btn.prop('disabled', selectedRegistrar === '' || selectedRegistrar !== loadedRegistrar);
    }

    $registrar.on('change', function () {
        var selectedRegistrar = registrarHelper.getValue($registrar);

        updateSaveButtonState();

        if (selectedRegistrar !== '' && selectedRegistrar !== loadedRegistrar) {
            showAlert('info', 'Load settings for the selected registrar before saving changes.');
        } else {
            $('#alertContainer').empty();
        }
    });

    $loadBtn.on('click', function (e) {
        var selectedRegistrar;

        e.preventDefault();
        selectedRegistrar = registrarHelper.requireSelection($registrar, function (message) {
            showAlert('error', message);
        });

        if (selectedRegistrar === '' || selectedRegistrar === loadedRegistrar) {
            return;
        }

        registrarHelper.reloadWithRegistrar($registrar);
    });

    $btn.on("click", function (e) {
        e.preventDefault();

        if (!registrarHelper.requireSelection($registrar, function (message) {
            showAlert('error', message);
        })) {
            return;
        }

        if (registrarHelper.getValue($registrar) !== loadedRegistrar) {
            showAlert('warning', 'Load settings for the selected registrar before saving changes.');
            return;
        }

        $btn.prop("disabled", true);
        $loader.show();
        var formData = $form.serialize();
        $.ajax({
            url: window.location.href,
            type: "POST",
            data: formData,
            dataType: "json",
            success: function (response) {
                if (response.success) {
                    showAlert('success', 'Settings saved successfully.');
                } else {
                    showAlert('error', response.error || 'Failed to save settings.');
                }
            },
            error: function () {
                showAlert('error', 'AJAX request failed.');
            },
            complete: function () {
                $btn.prop("disabled", false);
                $loader.hide();
            }
        });
    });

    updateSaveButtonState();
});
