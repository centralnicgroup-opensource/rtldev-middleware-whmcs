/**
 * Additional Fields JavaScript Module
 *
 * Handles all JavaScript functionality for the TLD Additional Fields
 * configuration section including TLD lookup, field saving, toggle switches,
 * and recent TLDs management.
 */

$(document).ready(function () {
	// Check if we're on the right page
	if (!$('#tldInput').length) {
		return;
	}

	// Initialize immediately
	AdditionalFields.init();

	// Double-check after WHMCS scripts load and re-initialize if needed
	setTimeout(function () {
		if (!$('#tldInput')[0].selectize) {
			AdditionalFields.initSelectize();
		}
	}, 1500);

	// Additional check for conflicts with other scripts
	$(window).on('load', function () {
		setTimeout(function () {
			if (!$('#tldInput')[0].selectize) {
				AdditionalFields.initSelectize();
			}
		}, 500);
	});
});

/**
 * Main Additional Fields Module
 */
const AdditionalFields = {
	/**
	 * Initialize the module
	 */
	init: function () {
		try {
			this.initSelectize();
			this.attachEventListeners();
			this.initFormSubmission(); // Initialize AJAX form submission
			this.initCancelButton(); // Initialize cancel button functionality
			this.initRecentTlds(); // Initialize recent TLDs on page load
			this.generateBootstrapSwitches(); // Initialize any existing toggles
			this.initTraditionalPhpButton(); // Initialize traditional PHP button
			this.initFieldTexts(); // Initialize field texts language picker
		} catch (error) {
			console.error('Additional Fields: Initialization failed:', error);
		}
	},

	/**
	 * Attach event listeners
	 */
	attachEventListeners: function () {
		// Attach click handler for lookup button
		$(document)
			.off('click.additionalFields', '#lookupFieldsButton')
			.on('click.additionalFields', '#lookupFieldsButton', function () {
				AdditionalFields.performTldLookup();
			});

		// Handle form submission
		$(document)
			.off('submit.additionalFields', '#lookupFieldsForm')
			.on('submit.additionalFields', '#lookupFieldsForm', function (e) {
				e.preventDefault();
				AdditionalFields.performTldLookup();
			});
	},

	/**
	 * Initialize TLD lookup button
	 */
	initLookupButton: function () {
		$('#lookupFieldsButton').on('click', function () {
			AdditionalFields.performTldLookup();
		});
	},

	/**
	 * Initialize Selectize dropdown for TLD input
	 */
	initSelectize: function () {
		const $tldSelect = $('#tldInput');
		if (!$tldSelect.length) {
			return;
		}

		// Check if selectize is available
		if (typeof $.fn.selectize === 'undefined') {
			console.error(
				'Additional Fields: Selectize plugin not available, using fallback',
			);
			this.initFallbackSelect();
			return;
		}

		// Destroy existing selectize if present
		if ($tldSelect[0].selectize) {
			$tldSelect[0].selectize.destroy();
		}

		// Initialize our own selectize instance
		try {
			const selectizeConfig = {
				create: false,
				sortField: 'text',
				placeholder: 'Choose or search for a TLD...',
				searchField: ['text', 'value'],
				maxOptions: 1000,
				loadThrottle: 300,
				hideSelected: false,
				selectOnTab: true,
				openOnFocus: true,
				closeAfterSelect: true,
				dropdownParent: 'body', // Append dropdown to body to avoid z-index issues
				maxItems: 1,
				onChange: function (value) {
					AdditionalFields.toggleLookupButton(value);
					// load the fields on selection, the button stays for reloading the same TLD
					if (value) {
						AdditionalFields.performTldLookup();
					}
				},
				onInitialize: function () {
					// Set initial button state after initialization
					const currentValue = this.getValue();
					AdditionalFields.toggleLookupButton(currentValue);
				},
				render: {
					option: function (item, escape) {
						return (
							'<div class="option">' +
							escape(item.text || item.value) +
							'</div>'
						);
					},
					item: function (item, escape) {
						return (
							'<div class="item">' + escape(item.text || item.value) + '</div>'
						);
					},
				},
			};

			$tldSelect.selectize(selectizeConfig);

			// Additional verification
			if ($tldSelect[0].selectize) {
				// Set initial button state
				const initialValue = $tldSelect[0].selectize.getValue();
				AdditionalFields.toggleLookupButton(initialValue);
			} else {
				throw new Error('Selectize instance not created');
			}
		} catch (error) {
			console.error(
				'Additional Fields: Failed to initialize selectize:',
				error,
			);
			this.initFallbackSelect();
		}
	},

	/**
	 * Fallback select initialization for when selectize fails
	 */
	initFallbackSelect: function () {
		const $tldSelect = $('#tldInput');

		// Remove any existing change handlers and add our own
		$tldSelect
			.off('change.additionalFields')
			.on('change.additionalFields', function () {
				const value = $(this).val();
				AdditionalFields.toggleLookupButton(value);
			});

		// Add keyboard support for better UX
		$tldSelect
			.off('keyup.additionalFields')
			.on('keyup.additionalFields', function (e) {
				if (e.which === 13) {
					// Enter key
					const value = $(this).val();
					if (value && value.trim() !== '') {
						AdditionalFields.performTldLookup();
					}
				}
			});

		// Set initial button state
		const initialValue = $tldSelect.val();
		AdditionalFields.toggleLookupButton(initialValue);
	},

	/**
	 * Toggle lookup button based on TLD selection
	 */
	toggleLookupButton: function (value) {
		const $button = $('#lookupFieldsButton');
		if (!$button.length) {
			console.error('Additional Fields: Lookup button not found!');
			return;
		}

		if (value && value.trim() !== '') {
			$button.prop('disabled', false).removeClass('disabled');
		} else {
			$button.prop('disabled', true).addClass('disabled');
		}
	},

	/**
	 * Perform TLD lookup
	 */
	performTldLookup: function () {
		// Get value from Selectize dropdown
		let tld = this.normalizeTld($('#tldInput').val());

		$('#alertContainer').empty();

		if (!this.validateTld(tld)) {
			this.showAlert(
				'danger',
				'<strong>Error:</strong> Please enter a valid TLD (e.g., .it)',
			);
			$('#tldInput').focus();
			return;
		}

		// selecting via Enter also submits the form - one request per TLD is enough,
		// and a lookup for a TLD no longer selected is dropped
		if (this.lookupXhr) {
			if (this.lookupTld === tld) {
				return;
			}
			this.lookupXhr.abort();
		}
		// the fields are replaced now: ask before unsaved translations get lost
		if (!AdditionalFields.confirmDiscard()) {
			return;
		}

		this.prepareLookupContainer();
		this.showLoadingIndicator();

		this.lookupTld = tld;
		this.lookupXhr = $.ajax({
			url: window.location.href,
			type: 'POST',
			data: {
				action: 'loadtld',
				tld: tld,
			},
			dataType: 'json',
			success: function (response) {
				AdditionalFields.handleLookupSuccess(response, tld);
			},
			error: function (xhr, status, error) {
				if (status !== 'abort') {
					AdditionalFields.handleLookupError(error);
				}
			},
			complete: function (xhr) {
				if (AdditionalFields.lookupXhr === xhr) {
					AdditionalFields.lookupXhr = null;
				}
			},
		});
	},

	/**
	 * Normalize a TLD to the notation WHMCS uses: lowercase, exactly one leading dot.
	 * The server normalizes as well - this only keeps request payload, recent TLD list
	 * and displayed values consistent.
	 */
	normalizeTld: function (tld) {
		if (!tld) return '';
		const normalized = String(tld).trim().toLowerCase().replace(/^\.+/, '');
		return normalized === '' ? '' : '.' + normalized;
	},

	/**
	 * Validate TLD format
	 */
	validateTld: function (tld) {
		return this.normalizeTld(tld).length > 1;
	},

	/**
	 * Prepare lookup container
	 */
	prepareLookupContainer: function () {
		if ($('#fieldsContainer').length === 0) {
			$('#tldFields').wrap(
				'<div id="fieldsContainer" class="fields-wrapper"></div>',
			);
		}

		const currentHeight = $('#fieldsContainer').height();
		if (currentHeight > 100) {
			$('#fieldsContainer').css('min-height', currentHeight + 'px');
		} else {
			$('#fieldsContainer').css('min-height', '300px');
		}

		if ($('#tldFields').children().length > 0) {
			$('#tldFields').fadeTo(200, 0.3);
		}
	},

	/**
	 * Show loading indicator
	 */
	showLoadingIndicator: function () {
		$('#loadingIndicator')
			.appendTo('#fieldsContainer')
			.css({
				position: 'absolute',
				top: '50%',
				left: '50%',
				transform: 'translate(-50%, -50%)',
				'z-index': 100,
				width: '100%',
				background: 'rgba(255,255,255,0.7)',
			})
			.fadeIn(200);
	},

	/**
	 * Handle successful TLD lookup
	 */
	handleLookupSuccess: function (response, tld) {
		if (response?.success && response?.state !== 'nofields') {
			this.addRecentTld(tld);
		}

		$('#loadingIndicator').fadeOut(200);

		// TLD without additional fields: a valid answer, but there is nothing to render
		if (response?.success && response?.state === 'nofields') {
			$('#tldFields').stop(true, true).empty().fadeTo(200, 1);
			$('#fieldsContainer').css('min-height', '');
			this.showAlert(
				'info',
				'<strong>No Additional Fields Required:</strong> ' +
					(response.msg ||
						tld + ' does not require any additional fields for registration.'),
			);
			return;
		}

		if (response && response.success) {
			$('#tldFields')
				.stop(true, true)
				.fadeTo(150, 0.3, function () {
					const $fieldsContainer = $(this);

					// Insert the new HTML
					$fieldsContainer.html(response.html || '');

					// Reset opacity and container height
					$fieldsContainer.fadeTo(200, 1, function () {
						$('#fieldsContainer').css('min-height', '');

						// Remove container if no content
						if (!response.html || response.html.trim() === '') {
							$('#fieldsContainer').remove();
							AdditionalFields.showAlert(
								'info',
								'<strong>Info:</strong> No additional fields are configured for this TLD.',
							);
							return;
						}

						// Initialize field interactions and toggle switches
						AdditionalFields.initFieldInteractions();
						AdditionalFields.generateBootstrapSwitches();
						AdditionalFields.initFormSubmission(); // Initialize AJAX form submission

						// Store original values for reset functionality
						setTimeout(function () {
							AdditionalFields.storeOriginalValues();
						}, 100); // Small delay to ensure all fields are fully initialized

						// Smooth scroll to fields
						if (response.html && response.html.trim() !== '') {
							$('html, body').animate(
								{
									scrollTop: $('#tldFields').offset().top - 50,
								},
								300,
							);

							// Animate field rows with staggered effect using CSS transitions
							$('.cnic-field-row').each(function (index) {
								const $row = $(this);
								$row.css({
									opacity: 0,
									transform: 'translateY(20px)',
									transition: 'all 0.3s ease',
								});

								// Use setTimeout for staggered animation
								setTimeout(function () {
									$row.css({
										opacity: 1,
										transform: 'translateY(0)',
									});
								}, index * 50);
							});
						}
					});
				});
		} else {
			console.error('Additional Fields: Lookup failed:', response);
			// clear the previous TLD's form: leaving it live under an error about another
			// TLD invites saving its values against the wrong TLD
			$('#tldFields').stop(true, true).empty().fadeTo(200, 1);
			$('#fieldsContainer').css('min-height', '');
			this.showAlert(
				'danger',
				'<strong>Error:</strong> ' +
					(response?.error || 'Failed to load TLD fields.'),
			);
		}
	},

	/**
	 * Handle TLD lookup error
	 */
	handleLookupError: function (error) {
		$('#loadingIndicator').fadeOut(300);
		console.error('AJAX Error:', error);
		this.showAlert(
			'danger',
			'<strong>Error:</strong> Failed to load TLD fields. Please try again or contact support.',
		);
	},

	/**
	 * Initialize form submission
	 */
	initFormSubmission: function () {
		// Remove any existing handlers to prevent duplicates
		$(document).off('submit.saveFields', '#saveFieldsForm');

		// Add form submission handler
		$(document).on('submit.saveFields', '#saveFieldsForm', function (e) {
			e.preventDefault();
			e.stopImmediatePropagation();
			AdditionalFields.saveFields();
			return false;
		});
	},

	/**
	 * Save additional fields data
	 */
	saveFields: function () {
		// the Translations mode saves the translations only
		if ($('.fields-configuration-panel').hasClass('cnic-translation-mode')) {
			AdditionalFields.saveFieldTexts();
			return;
		}
		const $form = $('#saveFieldsForm');

		if (!$form.length) {
			console.error('Additional Fields: Save form not found!');
			AdditionalFields.showAlert(
				'danger',
				'<strong>Error:</strong> Form not found. Please refresh the page and try again.',
			);
			return;
		}

		const formData = $form.serialize();
		const $saveButton = $('#saveFieldsButton');

		// Modern loading state
		$saveButton
			.prop('disabled', true)
			.addClass('disabled')
			.html('<i class="fas fa-solid fa-spinner fa-spin"></i> Saving...');
		$('.cnic-field-row').addClass('saving');

		$.ajax({
			url: window.location.href,
			type: 'POST',
			data: formData,
			dataType: 'json',
			headers: {
				'X-Requested-With': 'XMLHttpRequest',
			},
			success: function (response) {
				const $saveButton = $('#saveFieldsButton');
				$saveButton
					.prop('disabled', false)
					.removeClass('disabled')
					.html('<i class="fas fa-solid fa-save"></i> Save Fields');
				$('.cnic-field-row').removeClass('saving');

				if (response && response.success) {
					AdditionalFields.showAlert(
						'success',
						'<strong>Success:</strong> Additional fields have been saved successfully.',
					);
					AdditionalFields.showSuccessMessage();
				} else {
					AdditionalFields.showAlert(
						'danger',
						'<strong>Error:</strong> ' +
							(response.error || 'Failed to save fields.'),
					);
				}
			},
			error: function (xhr, status, error) {
				console.warn('Additional Fields: AJAX error:', xhr, status, error);
				const $saveButton = $('#saveFieldsButton');
				$saveButton
					.prop('disabled', false)
					.removeClass('disabled')
					.html('<i class="fas fa-solid fa-save"></i> Save Fields');
				$('.cnic-field-row').removeClass('saving');
				console.error('AJAX Error:', error);
				AdditionalFields.showAlert(
					'danger',
					'<strong>Error:</strong> Failed to save fields. Please try again or contact support.',
				);
			},
		});
	},

	/**
	 * Initialize cancel button
	 */
	initCancelButton: function () {
		$(document).on('click', '#cancelButton', function (e) {
			e.preventDefault();
			if (!AdditionalFields.confirmDiscard()) {
				return;
			}

			// Remove any success messages
			$('.save-success-message').remove();

			// Reset all form fields to their original values before clearing
			AdditionalFields.resetFormFields();

			// Clear the tldFields container (this is where the form content is loaded)
			$('#tldFields').fadeOut(200, function () {
				$(this).empty();
				$(this).show(); // Keep the container, just empty it
				$('#fieldsContainer').css('min-height', 'auto');
			});

			// Clear and focus the TLD input
			if ($('#tldInput')[0].selectize) {
				$('#tldInput')[0].selectize.clear();
				$('#tldInput')[0].selectize.focus();
			} else {
				$('#tldInput').val('').focus();
			}
		});
	},

	/**
	 * Reset form fields to their original values
	 */
	resetFormFields: function () {
		const $form = $('#fieldsForm');
		if ($form.length === 0) return;

		// Reset all input fields to their original values
		$form.find('input, select, textarea').each(function () {
			const $field = $(this);
			const originalValue = $field.data('original-value');

			if (originalValue !== undefined) {
				$field.val(originalValue);
			} else {
				// If no original value stored, reset to empty or default
				if ($field.is(':checkbox') || $field.is(':radio')) {
					$field.prop('checked', $field.data('original-checked') || false);
				} else {
					$field.val('');
				}
			}

			// Update selectize if present
			if ($field[0].selectize) {
				$field[0].selectize.setValue(originalValue || '');
			}
		});

		// Reset any visual states
		$('.cnic-field-row').removeClass('saving');
		$('.form-group').removeClass('has-error');
		$('.help-block').remove();
	},

	/**
	 * Store original form values for reset functionality
	 */
	storeOriginalValues: function () {
		const $form = $('#fieldsForm');
		if ($form.length === 0) return;

		$form.find('input, select, textarea').each(function () {
			const $field = $(this);

			if ($field.is(':checkbox') || $field.is(':radio')) {
				$field.data('original-checked', $field.prop('checked'));
			} else {
				$field.data('original-value', $field.val());
			}
		});
	},

	/**
	 * Initialize field interactions
	 */
	initFieldInteractions: function () {
		$('.cnic-field-row')
			.off('focusin.fieldHighlight focusout.fieldHighlight')
			.on('focusin.fieldHighlight', 'input, select, textarea', function () {
				$(this).closest('.cnic-field-row').addClass('field-focused');
			})
			.on('focusout.fieldHighlight', 'input, select, textarea', function () {
				$(this).closest('.cnic-field-row').removeClass('field-focused');
			});

		$('.cnic-field-row input, .cnic-field-row select, .cnic-field-row textarea')
			.off('input.validation change.validation')
			.on('input.validation change.validation', function () {
				const $field = $(this);
				const $row = $field.closest('.cnic-field-row');
				const isRequired =
					$field.attr('required') || $field.hasClass('required');
				const hasValue = $field.val() && $field.val().trim() !== '';

				$row.toggleClass('field-valid', hasValue && isRequired);
				$row.toggleClass('field-invalid', !hasValue && isRequired);
			});
	},

	/**
	 * Generate bootstrap toggle switches
	 */
	generateBootstrapSwitches: function () {
		// Use delegated event handling for dynamic content
		$(document)
			.off('change.toggleBootstrap', '.cnic-toggle')
			.on('change.toggleBootstrap', '.cnic-toggle', function () {
				const $this = $(this);
				const $wrapper = $this.closest('.cnic-toggle-wrapper');
				const hiddenName = $this.data('hidden');
				const $hidden = $('input[type="hidden"][name="' + hiddenName + '"]');

				$hidden.val($this.is(':checked') ? '1' : '0');

				$wrapper.toggleClass('toggle-on', $this.is(':checked'));
				$wrapper.toggleClass('toggle-off', !$this.is(':checked'));

				$wrapper.addClass('toggle-animate');
				setTimeout(function () {
					$wrapper.removeClass('toggle-animate');
				}, 300);
			});

		// Add click handler for toggle wrapper (better UX)
		$(document)
			.off('click.toggleWrapper', '.cnic-toggle-wrapper')
			.on('click.toggleWrapper', '.cnic-toggle-wrapper', function (e) {
				// Only trigger if clicking the wrapper itself, not the checkbox
				if (e.target === this || $(e.target).hasClass('cnic-toggle-label')) {
					const $toggle = $(this).find('.cnic-toggle');
					$toggle.prop('checked', !$toggle.prop('checked')).trigger('change');
				}
			});

		// Initialize existing toggles
		$('.cnic-toggle').each(function () {
			const $toggle = $(this);
			const $wrapper = $toggle.closest('.cnic-toggle-wrapper');

			if ($wrapper.hasClass('initialized')) {
				return;
			}

			$wrapper.addClass('initialized');

			const isChecked = $toggle.is(':checked');
			$wrapper.toggleClass('toggle-on', isChecked);
			$wrapper.toggleClass('toggle-off', !isChecked);
		});
	},

	/**
	 * Initialize recent TLDs
	 */
	initRecentTlds: function () {
		const recentTlds = this.getRecentTlds();
		if (recentTlds.length === 0) {
			// Hide the recent TLDs section if no recent TLDs
			$('#recentTldsSection').hide();
			return;
		}

		const $recentContainer = $('#recentTldsList');
		if (!$recentContainer.length) return;

		$recentContainer.empty();

		recentTlds.forEach(rawTld => {
			const tld = AdditionalFields.normalizeTld(rawTld);
			const $btn = $('<button>', {
				type: 'button',
				class: 'recent-tld-btn btn btn-outline-primary btn-sm',
				text: tld,
				'data-tld': tld,
				style: 'margin: 3px;',
			});
			$recentContainer.append($btn);
		});

		// Show the recent TLDs section
		$('#recentTldsSection').show();

		// Bind click events for recent TLD buttons (this runs again after every lookup,
		// so drop the previous binding or a single click fires one lookup per rebind)
		$(document)
			.off('click.recentTld', '.recent-tld-btn')
			.on('click.recentTld', '.recent-tld-btn', function (e) {
				e.preventDefault();
				const tld = $(this).data('tld');
				if (!AdditionalFields.confirmDiscard()) {
					return;
				}

				// Set the TLD in selectize without triggering change event to avoid duplicate loading
				if ($('#tldInput')[0].selectize) {
					const selectize = $('#tldInput')[0].selectize;
					selectize.setValue(tld, true); // Silent set to avoid triggering change
				} else {
					$('#tldInput').val(tld);
				}

				// Update lookup button and trigger single lookup
				AdditionalFields.toggleLookupButton(tld);
				AdditionalFields.performTldLookup();
			});

		// Keyboard accessibility for recent TLD buttons
		$(document)
			.off('keydown.recentTld', '.recent-tld-btn')
			.on('keydown.recentTld', '.recent-tld-btn', function (e) {
				if (e.which === 13 || e.which === 32) {
					e.preventDefault();
					$(this).click();
				}
			});
	},

	/**
	 * Get recent TLDs from localStorage
	 */
	getRecentTlds: function () {
		try {
			const stored = localStorage.getItem('cnic_recentTlds');
			return stored ? JSON.parse(stored) : [];
		} catch (e) {
			console.error('Failed to get recent TLDs', e);
			return [];
		}
	},

	/**
	 * Add TLD to recent list
	 */
	addRecentTld: function (tld) {
		try {
			const normalized = this.normalizeTld(tld);
			if (!normalized) return;
			let tlds = this.getRecentTlds()
				.map(item => this.normalizeTld(item))
				.filter(item => item && item !== normalized);
			tlds.unshift(normalized);
			tlds = tlds.slice(0, 5);
			localStorage.setItem('cnic_recentTlds', JSON.stringify(tlds));

			// Re-initialize recent TLDs display
			this.initRecentTlds();
		} catch (e) {
			console.error('Failed to save recent TLD', e);
		}
	},

	/**
	 * Show alert message
	 */
	showAlert: function (type, message) {
		const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                ${message}
            </div>
        `;
		$('#alertContainer').html(alertHtml);

		if (type === 'success') {
			setTimeout(function () {
				$('.alert-success').fadeOut('slow', function () {
					$(this).remove();
				});
			}, 5000);
		}
	},

	/**
	 * Show success message below the save button with auto-dismiss
	 */
	showSuccessMessage: function (message = 'Fields saved successfully!') {
		// Remove any existing success message immediately
		$('.save-success-message').remove();

		const $formActions = $('.additional-fields-form-actions');
		if ($formActions.length === 0) return;

		// Create success message using existing CSS classes
		const successHtml = `
            <div class="save-success-message alert alert-success text-center" style="margin-top: 15px; max-width: 300px; margin-left: auto; margin-right: auto;">
                <i class="fas fa-solid fa-check-circle"></i>
                ${$('<div>').text(message).html()}
            </div>
        `;

		// Insert success message below the form actions
		$formActions.after(successHtml);

		// Add fade-in animation using existing class
		$('.save-success-message').addClass('cnicadmin-main');

		// Auto-remove after 3 seconds with fade out
		setTimeout(function () {
			$('.save-success-message').fadeOut(300, function () {
				$(this).remove();
			});
		}, 3000);
	},

	/**
	 * Bind keyboard events
	 */
	bindKeyboardEvents: function () {
		// Handle Enter key in selectize input
		$(document).on('keydown', '.selectize-input', function (e) {
			if (e.which === 13 && $('#tldInput')[0].selectize.getValue()) {
				e.preventDefault();
				$('#lookupFieldsButton').click();
			}
		});
	},

	/**
	 * Initialize Traditional PHP Button
	 */
	initTraditionalPhpButton: function () {
		$(document)
			.off('click.traditionalPhp', '#loadTraditionalPhpButton')
			.on('click.traditionalPhp', '#loadTraditionalPhpButton', function () {
				const tld = $(this).data('tld');
				AdditionalFields.loadTraditionalPhpConfiguration(tld);
			});

		// Clean up when modal closes
		$('#modalAjax')
			.off('hidden.bs.modal.traditionalPhp')
			.on('hidden.bs.modal.traditionalPhp', function () {
				// Remove custom class
				$(this).removeClass('traditional-php-modal');
				// Reset modal dialog size
				$('#modalAjax .modal-dialog').removeClass('modal-lg');
				// Clear footer left
				$('#modalFooterLeft').empty();
				// Reset footer buttons
				$('#modalAjaxSubmit').show();
				$('#modalAjaxLoader').show();
				// Unbind shown event
				$(this).off('shown.bs.modal');
			});
	},

	/**
	 * Load Traditional PHP Configuration
	 */
	loadTraditionalPhpConfiguration: function (tld) {
		if (!tld) {
			console.error(
				'Additional Fields: TLD is required to load traditional configuration',
			);
			return;
		}

		const $modal = $('#modalAjax');

		// Add custom class for styling
		$modal.addClass('traditional-php-modal');

		// Set modal title
		$('#modalAjaxTitle').html(
			'<i class="fas fa-solid fa-code"></i> Traditional PHP Configuration for ' +
				tld,
		);

		// Set modal body with loading state
		$('#modalAjaxBody').html(`
            <div class="text-center" style="padding: 40px;">
                <i class="fas fa-solid fa-spinner fa-spin fa-3x text-primary"></i>
                <p style="margin-top: 20px; color: #666;">Loading PHP configuration...</p>
            </div>
        `);

		// Hide loader in footer
		$('#modalAjaxLoader').hide();

		// Configure footer buttons - hide submit, keep close on the right
		$('#modalAjaxSubmit').hide();
		$('#modalAjaxClose').show().text('Close');

		// Add Copy button to modalFooterLeft (left side of footer)
		$('#modalFooterLeft').html(`
            <button type="button" id="copyPhpCodeButton" class="btn btn-success copy-to-clipboard" data-clipboard-target="#phpCodeSource">
                <i class="fas fa-solid fa-copy"></i> Copy to Clipboard
            </button>
        `);

		// Bind click event to WHMCS's clipboard function
		$('#copyPhpCodeButton').off('click').on('click', WHMCS.ui.clipboard.copy);

		// Make the modal wider
		$('#modalAjax .modal-dialog').addClass('modal-lg');

		// Show the modal
		$modal.modal('show');

		// Fix aria-hidden accessibility issue after modal is shown
		$modal.on('shown.bs.modal', function () {
			$modal.removeAttr('aria-hidden');
		});

		// Make AJAX request
		$.ajax({
			url: window.location.href,
			type: 'POST',
			data: {
				action: 'getTraditionalConfiguration',
				tld: tld,
			},
			dataType: 'json',
			success: function (response) {
				if (response?.success && !response.html) {
					$('#modalAjaxBody').html(`
                        <div class="alert alert-info">
                            <i class="fas fa-solid fa-info-circle"></i>
                            ${response.msg || 'This TLD does not require any additional fields.'}
                        </div>
                    `);
					return;
				}
				if (response && response.success && response.html) {
					// Extract PHP code from the <pre> tag
					const tempDiv = $('<div>').html(response.html);
					const phpCode = tempDiv.find('pre').text() || tempDiv.text();

					// Build the modal content
					const content = AdditionalFields.buildTraditionalPhpModalContent(
						phpCode,
						tld,
					);
					$('#modalAjaxBody').html(content);
				} else {
					$('#modalAjaxBody').html(`
                        <div class="alert alert-danger">
                            <i class="fas fa-solid fa-exclamation-circle"></i> 
                            ${response?.error || 'Failed to load PHP configuration'}
                        </div>
                    `);
				}
			},
			error: function (xhr, status, error) {
				console.error(
					'Additional Fields: AJAX error loading traditional PHP:',
					error,
				);
				$('#modalAjaxBody').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-solid fa-exclamation-circle"></i> 
                        Failed to load PHP configuration. Please try again or contact support.
                    </div>
                `);
			},
		});
	},

	/**
	 * Build Traditional PHP Modal Content
	 */
	buildTraditionalPhpModalContent: function (phpCode, tld) {
		// Escape HTML entities for display in <pre>
		const escapedCode = $('<div>').text(phpCode).html();

		return `
            <div class="alert alert-warning cnic-instructions-alert">
                <h5 style="margin-top: 0; margin-bottom: 10px; font-weight: 600;">
                    <i class="fas fa-solid fa-exclamation-triangle"></i> Important Instructions
                </h5>
                <ul style="margin-bottom: 0; padding-left: 20px; line-height: 1.8;">
                    <li><strong>Copy Exactly:</strong> Use the "Copy to Clipboard" button for accuracy. Do not modify, rearrange, or reorder any fields.</li>
                    <li><strong>File Location:</strong> Add this code to your WHMCS <code>resources/domains/additionalfields.php</code> overrides file - create it if it does not exist yet. Never edit <code>dist.additionalfields.php</code>: WHMCS replaces that file on every update, which silently removes your configuration.</li>
                    <li><strong>Keep the Leading Dot:</strong> The array key must stay exactly as generated (e.g. <code>".co.ae"</code>). WHMCS ignores a key without the leading dot without reporting an error.</li>
                    <li><strong>Field Order Matters:</strong> The order of fields is critical. Changing the order will cause mapping issues with existing domain registrations.</li>
                    <li><strong>Backup First:</strong> Always backup your existing <code>additionalfields.php</code> file before making changes.</li>
                    <li><strong>Only If You Need It:</strong> The CNIC registrar module already provides these fields dynamically. This snippet is meant for TLDs you serve through a different (traditional) registrar module.</li>
                    <li><strong>Test Thoroughly:</strong> After adding the code, test domain registration for this TLD to ensure all fields work correctly.</li>
                </ul>
            </div>
            
            <h5 style="margin: 20px 0 10px 0; font-weight: 600;">
                <i class="fas fa-solid fa-code"></i> PHP Configuration Code
            </h5>
            
            <!-- Hidden textarea for WHMCS clipboard function -->
            <textarea id="phpCodeSource" style="position: absolute; left: -9999px; opacity: 0;" readonly>${phpCode}</textarea>
            
            <pre id="phpCodeBlock" class="cnic-php-code-block" style="user-select: text; cursor: text;">${escapedCode}</pre>
            
            <p style="margin-top: 10px; font-size: 12px; color: #666;">
                <i class="fas fa-solid fa-info-circle"></i> You can also click inside the code block and use Ctrl+A (or Cmd+A) and Ctrl+C (or Cmd+C) to copy manually.
            </p>
        `;
	},
	/**
	 * Initialize the "Default values / Translations" switch, the language picker and the translation rows
	 */
	initFieldTexts: function () {
		$(window)
			.off('resize.fieldTexts')
			.on('resize.fieldTexts', function () {
				AdditionalFields.positionPreview();
			});
		$(document)
			.off('click.fieldTexts', '.cnic-mode-btn')
			.on('click.fieldTexts', '.cnic-mode-btn', function () {
				const translations = $(this).data('mode') === 'translations';
				const $panel = $('.fields-configuration-panel');
				if (
					translations === $panel.hasClass('cnic-translation-mode') ||
					!AdditionalFields.confirmDiscard()
				) {
					return;
				}
				$('.cnic-mode-btn').removeClass('active');
				$(this).addClass('active');
				$('#fieldTextsLanguage').toggle(translations);
				$panel.toggleClass('cnic-translation-mode', translations);
				AdditionalFields.loadFieldTexts(
					translations ? $('#fieldTextsLanguage').val() : '',
				);
			})
			.off('focus.fieldTexts', '#fieldTextsLanguage')
			.on('focus.fieldTexts', '#fieldTextsLanguage', function () {
				$(this).data('previous', $(this).val());
			})
			.off('change.fieldTexts', '#fieldTextsLanguage')
			.on('change.fieldTexts', '#fieldTextsLanguage', function () {
				if (!AdditionalFields.confirmDiscard()) {
					$(this).val($(this).data('previous'));
					return;
				}
				$(this).data('previous', $(this).val());
				AdditionalFields.loadFieldTexts($(this).val());
			})
			.off('input.fieldTexts', '[data-text-key]')
			.on('input.fieldTexts', '[data-text-key]', function () {
				AdditionalFields.updateTranslationRow($(this).closest('.cnic-tr-row'));
				AdditionalFields.updateSaveButton();
				AdditionalFields.renderPreview($(this));
			})
			.off('focusin.fieldTexts', '[data-text-key]')
			.on('focusin.fieldTexts', '[data-text-key]', function () {
				AdditionalFields.renderPreview($(this));
			})
			.off('click.fieldTexts', '.cnic-tr-reset')
			.on('click.fieldTexts', '.cnic-tr-reset', function () {
				const $row = $(this).closest('.cnic-tr-row');
				$row.find('[data-text-key]').val($row.data('default'));
				AdditionalFields.updateTranslationRow($row);
				AdditionalFields.updateSaveButton();
				AdditionalFields.renderPreview($row.find('[data-text-key]'));
			})
			.off('click.fieldTexts', '.cnic-tr-filter')
			.on('click.fieldTexts', '.cnic-tr-filter', function () {
				$('.cnic-tr-filter').removeClass('active');
				$(this).addClass('active');
				AdditionalFields.filterTranslations();
			})
			.off('click.fieldTexts', '.cnic-tr-preview-head')
			.on('click.fieldTexts', '.cnic-tr-preview-head', function () {
				const collapsed = $('#cnicTrPreview')
					.toggleClass('is-collapsed')
					.hasClass('is-collapsed');
				$(this).attr('aria-expanded', String(!collapsed));
				try {
					window.localStorage.setItem(
						'cnicTrPreviewCollapsed',
						collapsed ? '1' : '0',
					);
				} catch (error) {
					// no storage: the choice lasts until the next reload
				}
			})
			.off('input.fieldTexts', '.cnic-tr-search')
			.on('input.fieldTexts', '.cnic-tr-search', function () {
				AdditionalFields.filterTranslations();
			});
	},

	/**
	 * Ask before unsaved translation changes get lost
	 */
	confirmDiscard: function () {
		const $dirty = $('.cnic-tr-row.is-dirty');
		if (
			$dirty.length &&
			!window.confirm(`Discard ${$dirty.length} unsaved translation change(s)?`)
		) {
			return false;
		}
		$dirty.removeClass('is-dirty'); // discarded: a lookup triggered twice must not ask again
		return true;
	},

	/**
	 * Load the translations of the TLD's fields in the given client language, empty: back to the default values
	 */
	loadFieldTexts: function (language) {
		const $picker = $('#fieldTextsLanguage');
		const $toolbar = $('#fieldTextsNotice');
		$picker.data('request')?.abort();
		$('.cnic-field-texts, .cnic-field-texts-more, .cnic-tr-preview').remove();
		$(
			'.cnic-tr-row, .cnic-field-row, #saveFieldsForm .cnic-form-section',
		).removeClass('cnic-hidden');
		const $button = $('#saveFieldsButton');
		if (!$button.data('defaultHtml')) {
			$button.data('defaultHtml', $button.html()); // "Save Fields" of the default values
		}
		if (!language) {
			$toolbar.hide().empty();
			$button.prop('disabled', false).html($button.data('defaultHtml'));
			return;
		}
		$toolbar.text('Loading translations...').show();
		$button.prop('disabled', true);

		const showError = message =>
			$toolbar.empty().append($('<span class="text-danger">').text(message));
		$picker.data(
			'request',
			$.ajax({
				url: window.location.href,
				type: 'POST',
				data: {action: 'loadFieldTexts', tld: $picker.data('tld'), language},
				dataType: 'json',
				success: function (response) {
					if (!$.contains(document, $picker[0])) {
						return; // another TLD was loaded meanwhile
					}
					if (response?.success && response.texts) {
						AdditionalFields.renderFieldTexts(response);
						return;
					}
					showError(
						response?.error || response?.msg || 'Failed to load translations.',
					);
				},
				error: function (xhr, status) {
					if (status !== 'abort') {
						showError('Failed to load translations. Please try again.');
					}
				},
			}),
		);
	},

	/**
	 * Show each field's texts the way customers see them, one editable row per text.
	 * Server data is set via .text()/.val() only.
	 */
	renderFieldTexts: function (data) {
		const hints = {
			custom: 'Customised - saved in the CNIC section of the override file',
			file: 'From your override file - moved into the CNIC section once you change it here',
			missing:
				'Not translated yet - customers see the English or registry text',
		};
		const names = {
			label: 'Label',
			descr: 'Help text',
			generic: 'Next to optional fields',
		};
		const counts = {custom: 0, file: 0, missing: 0};

		// texts without a field card: the shared optional marker and fields shown at checkout only
		const $more = $(`<div class="cnic-form-section cnic-field-texts-more">
                <div class="field-group-header">
                    <h5 class="field-group-title">
                        <div class="cnic-icon-wrapper blue"><i class="fas fa-solid fa-shopping-cart"></i></div>
                        Checkout &amp; shared texts
                    </h5>
                </div>
                <div class="field-group-body"><div class="fields-grid"></div></div>
            </div>`).appendTo('#saveFieldsForm .field-group-container');

		data.texts.forEach(text => {
			const field = text.field || 'cnroptional';
			let $card = $(`.cnic-field-row[data-field-name="${CSS.escape(field)}"]`);
			if (!$card.length) {
				$card = $('<div class="cnic-field-row">')
					.attr('data-field-name', field)
					.append(
						$('<div class="cnic-field-header">').append(
							$('<label class="cnic-field-label">').text('Optional marker'),
						),
					)
					.appendTo($more.find('.fields-grid'));
			}
			if (
				text.type === 'label' &&
				$card.closest('.cnic-field-texts-more').length
			) {
				$card
					.find('.cnic-field-label')
					.text(`${text.registry || text.field} (checkout)`);
			}
			let $box = $card.children('.cnic-field-texts');
			if (!$box.length) {
				$box = $('<div class="cnic-field-texts">').appendTo($card);
			}

			const state = text.state;
			if (state) {
				counts[state]++;
			}
			const value = text.override || text.default;
			// registry option values like "PUBLIC_ORGANIZATION" read better as "Public organization"
			const option = (text.registry || text.default).replace(/_/g, ' ');
			const optionName =
				option === option.toUpperCase()
					? option.charAt(0) + option.slice(1).toLowerCase()
					: option;
			$('<div class="cnic-tr-row">')
				.addClass(`${state ? `is-${state} ` : ''}is-type-${text.type}`)
				.attr(
					'title',
					(state ? hints[state] + '\n' : '') + `Translation key: ${text.key}`,
				)
				.data({
					default: text.default,
					type: text.type,
					search: [
						text.key,
						text.default,
						text.source,
						optionName,
						$card.find('.cnic-field-label').first().text(),
					]
						.join(' ')
						.toLowerCase(),
				})
				.append(
					$('<span class="cnic-tr-dot">'),
					$('<span class="cnic-tr-name">').text(
						names[text.type] || `Option "${optionName}"`,
					),
					$(
						text.type === 'descr'
							? '<textarea rows="2">'
							: '<input type="text">',
					)
						.addClass('form-control input-sm')
						.attr({
							'data-text-key': text.key,
							placeholder: text.default === '' ? 'No text' : '',
						})
						.val(value)
						.data('original', value)
						.prop('disabled', !data.writable),
					$(
						'<button type="button" class="cnic-tr-reset" title="Back to the default text">',
					).html('<i class="fas fa-solid fa-undo"></i>'),
					// what it means: the english text next to a translation
					data.language !== 'english' &&
						text.source &&
						text.source !== text.default &&
						// an option's name is its english text already
						!(
							text.type === 'option' &&
							text.source.toLowerCase() === optionName.toLowerCase()
						)
						? $('<div class="cnic-tr-source">').text(`English: ${text.source}`)
						: null,
				)
				.appendTo($box);
		});
		if (!$more.find('.cnic-field-row').length) {
			$more.remove();
		}
		$('.cnic-tr-row').each(function () {
			AdditionalFields.updateTranslationRow($(this));
		});

		const filters = [
			['all', 'All', data.texts.length],
			['missing', 'Not translated', counts.missing],
			['custom', 'Customised', counts.custom],
			['file', 'From your file', counts.file],
		];
		$('#fieldTextsNotice')
			.data('fieldTexts', {language: data.language, hash: data.hash})
			.empty()
			.append(
				$('<div class="cnic-tr-tools">').append(
					$(
						'<input type="search" class="form-control input-sm cnic-tr-search" placeholder="Find a text, e.g. Sole Proprietorship" aria-label="Find a text">',
					),
					$('<div class="cnic-tr-filters">').append(
						filters
							.filter(([filter, , count]) => filter === 'all' || count > 0)
							.map(([filter, label, count]) =>
								$('<button type="button" class="cnic-tr-filter">')
									.toggleClass('active', filter === 'all')
									.attr('data-filter', filter)
									.append(
										$('<span class="cnic-tr-dot">').addClass(`is-${filter}`),
										$('<span>').text(`${label} ${count}`),
									),
							),
					),
					$('<span class="cnic-tr-empty">').text('No text matches.').hide(),
				),
				$('<div class="cnic-tr-where">')
					.toggleClass('text-danger', !data.writable)
					.text(
						data.writable
							? `Saved to ${data.file} of your WHMCS - empty or ↺ restores the default text`
							: `${data.file} is not writable by the web server, translations cannot be saved here`,
					),
			)
			.show();
		AdditionalFields.updateSaveButton();

		// where the work is: translated texts per language in the picker
		$('#fieldTextsLanguage option').each(function () {
			const done = data.progress?.[this.value];
			const name = this.value.charAt(0).toUpperCase() + this.value.slice(1);
			$(this).text(
				done === undefined
					? name
					: `${name}  ${done === data.total ? '✓' : `${done}/${data.total}`}`,
			);
		});

		// beside the page where there is room for it, otherwise a tab at the window's corner
		let collapsed = AdditionalFields.positionPreview() === null;
		try {
			const stored = window.localStorage.getItem('cnicTrPreviewCollapsed');
			collapsed = stored === null ? collapsed : stored === '1';
		} catch (error) {
			// no storage: keep the default
		}
		$(`<aside id="cnicTrPreview" class="cnic-tr-preview" aria-live="polite">
                <button type="button" class="cnic-tr-preview-head" aria-expanded="${!collapsed}">
                    <i class="fas fa-solid fa-eye"></i> Customer view <span class="cnic-tr-preview-lang"></span>
                    <i class="fas fa-solid fa-chevron-down cnic-tr-preview-caret"></i>
                </button>
                <div class="cnic-tr-preview-content">
                    <div class="cnic-tr-preview-where">Shopping cart &rsaquo; Domain configuration</div>
                    <div class="cnic-tr-preview-body"></div>
                </div>
            </aside>`)
			.toggleClass('is-collapsed', collapsed)
			.appendTo('#tldFields') // goes with the fields, see .panel-default:has(#cnicTrPreview)
			.find('.cnic-tr-preview-lang')
			.text(data.language.charAt(0).toUpperCase() + data.language.slice(1));
		AdditionalFields.positionPreview();
		AdditionalFields.renderPreview($('[data-text-key]').first());
		AdditionalFields.filterTranslations();
	},

	/**
	 * Place the customer view in the empty space right of the page, if there is enough of it
	 *
	 * @return {number|null} the left position used, null if there is no room
	 */
	positionPreview: function () {
		// the outer card of the page, the space right of it is free
		const $page = $('.fields-configuration-panel').closest('.panel');
		const right = $page.length
			? $page[0].getBoundingClientRect().right
			: window.innerWidth;
		const left =
			window.innerWidth - right >= 276 ? Math.round(right) + 16 : null;
		$('#cnicTrPreview')
			.toggleClass('is-beside', left !== null)
			.css({
				left: left === null ? '' : `${left}px`,
				width:
					left === null
						? ''
						: `${Math.min(window.innerWidth - left - 16, 360)}px`,
			});
		return left;
	},

	/**
	 * Customer view: the field of the given text the way the shopping cart shows it,
	 * live while typing, the text being edited highlighted
	 */
	renderPreview: function ($input) {
		const $body = $('#cnicTrPreview .cnic-tr-preview-body');
		const texts = {};
		const options = [];
		$input
			.closest('.cnic-field-row')
			.find('.cnic-tr-row')
			.each(function () {
				const $text = $(this).find('[data-text-key]');
				const item = {
					key: $text.data('text-key'),
					value: $text.val().trim() || $(this).data('default'),
				};
				if ($(this).data('type') === 'option') {
					options.push(item);
				} else {
					texts[$(this).data('type')] = item;
				}
			});
		const mark = ($element, item) =>
			$element
				.attr('data-key', item.key)
				.toggleClass('is-focus', item.key === $input.data('text-key'))
				.text(item.value);

		$body.empty();
		if (texts.generic) {
			$body.append(
				$('<div class="cnic-tr-preview-label">')
					.text('Any optional field ')
					.append(
						mark($('<em>'), {
							...texts.generic,
							value: `*${texts.generic.value}`,
						}),
					),
				$('<div class="cnic-tr-preview-input">'),
			);
			return;
		}
		$body.append(
			texts.label
				? mark($('<div class="cnic-tr-preview-label">'), texts.label)
				: null,
			options.length
				? $('<div class="cnic-tr-preview-select">').append(
						options.map(item => mark($('<div>'), item)),
					)
				: $('<div class="cnic-tr-preview-input">'),
			texts.descr?.value
				? mark($('<div class="cnic-tr-preview-help">'), texts.descr)
				: null,
		);
	},

	/**
	 * Mark a translation row as changed and offer the reset to its default text
	 */
	updateTranslationRow: function ($row) {
		const value = $row.find('[data-text-key]').val().trim();
		$row.toggleClass(
			'is-dirty',
			value !== $row.find('[data-text-key]').data('original'),
		);
		$row
			.find('.cnic-tr-reset')
			.toggle(value !== '' && value !== $row.data('default'));
		// help texts: grow with the text instead of hiding it behind a scrollbar
		const textarea = $row.find('textarea[data-text-key]')[0];
		if (textarea) {
			textarea.style.height = 'auto';
			textarea.style.height = `${Math.min(textarea.scrollHeight + 2, 160)}px`;
		}
	},

	/**
	 * Save button of the translations: number of unsaved changes, disabled without any
	 */
	updateSaveButton: function () {
		const dirty = $('.cnic-tr-row.is-dirty').length;
		$('#saveFieldsButton')
			.prop('disabled', dirty === 0)
			.html(
				`<i class="fas fa-solid fa-save"></i> Save translations${dirty ? ` (${dirty})` : ''}`,
			);
	},

	/**
	 * Show only the translation rows of the active status chip that match the search
	 */
	filterTranslations: function () {
		const filter = $('.cnic-tr-filter.active').data('filter') || 'all';
		const query = ($('.cnic-tr-search').val() || '').trim().toLowerCase();
		$('.cnic-tr-row').each(function () {
			const $row = $(this);
			const text = `${$row.data('search')} ${$row.find('[data-text-key]').val().toLowerCase()}`;
			const matches =
				(filter === 'all' || $row.hasClass(`is-${filter}`)) &&
				(!query || text.includes(query));
			$row.toggleClass('cnic-hidden', !matches);
		});
		$('.cnic-field-texts').each(function () {
			$(this)
				.closest('.cnic-field-row')
				.toggleClass(
					'cnic-hidden',
					!$(this).children('.cnic-tr-row:not(.cnic-hidden)').length,
				);
		});
		$('#saveFieldsForm .cnic-form-section').each(function () {
			$(this).toggleClass(
				'cnic-hidden',
				!$(this).find('.cnic-field-row:not(.cnic-hidden)').length,
			);
		});
		$('.cnic-tr-empty').toggle(!$('.cnic-tr-row:not(.cnic-hidden)').length);
		// a card alone in the last row takes the whole row instead of leaving a gap
		$('#saveFieldsForm .fields-grid').each(function () {
			const $cards = $(this)
				.children('.cnic-field-row')
				.removeClass('is-wide')
				.not('.cnic-hidden');
			$cards.last().toggleClass('is-wide', $cards.length % 2 === 1);
		});
	},

	/**
	 * Save the changed translations to the WHMCS language override file
	 */
	saveFieldTexts: function () {
		const settings = $('#fieldTextsNotice').data('fieldTexts');
		const texts = {};
		$('.cnic-tr-row.is-dirty [data-text-key]').each(function () {
			texts[$(this).data('text-key')] = $(this).val();
		});
		if (!settings || $.isEmptyObject(texts)) {
			return;
		}
		const $picker = $('#fieldTextsLanguage'); // the fields the texts belong to
		$('#saveFieldsButton')
			.prop('disabled', true)
			.html('<i class="fas fa-solid fa-spinner fa-spin"></i> Saving...');

		const showError = message => {
			AdditionalFields.showAlert(
				'danger',
				'<strong>Error:</strong> ' + $('<div>').text(message).html(),
			);
			AdditionalFields.updateSaveButton();
		};
		$.ajax({
			url: window.location.href,
			type: 'POST',
			data: {
				action: 'saveFieldTexts',
				tld: $('#fieldTextsLanguage').data('tld'),
				language: settings.language,
				hash: settings.hash,
				texts: JSON.stringify(texts),
			},
			dataType: 'json',
			success: function (response) {
				if (!response?.success) {
					showError(response?.error || 'Failed to save translations.');
					return;
				}
				if (response.changed) {
					AdditionalFields.showSuccessMessage(
						'Translations saved successfully!',
					);
					AdditionalFields.showAlert(
						'success',
						'<strong>Success:</strong> Translations have been saved.',
					);
				}
				// still the same fields and language? the admin may have moved on meanwhile
				if (
					$.contains(document, $picker[0]) &&
					$picker.is(':visible') &&
					$picker.val() === settings.language
				) {
					AdditionalFields.loadFieldTexts(settings.language);
				}
			},
			error: function () {
				showError('Failed to save translations. Please try again.');
			},
		});
	},
};
