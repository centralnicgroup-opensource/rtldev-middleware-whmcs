// recent-tlds.js: Recent TLDs logic for CentralNic Config
$(document).ready(function () {
    initRecentTlds();
    // Cancel button handler
    $(document).on("click", "#cancelButton", function () {
        if (confirm('Are you sure you want to cancel? Any unsaved changes will be lost.')) {
            // Clear fields container and remove fieldsContainer wrapper to prevent empty space
            $("#fieldsContainer").fadeOut(200, function() {
                $("#tldFields").empty();
                $(this).remove(); // Remove the wrapper completely
                // Return to initial state
                if ($("#tldInput")[0].selectize) {
                    $("#tldInput")[0].selectize.clear();
                }
                $('#alertContainer').empty();
            });
        }
    });
});

function initRecentTlds() {
    const recentTlds = getRecentTlds();
    if (recentTlds.length > 0) {
        // Enhanced animation for the section
        $('#recentTldsSection').css('opacity', '0').show().animate({
            opacity: 1
        }, 400);
        
        // Generate HTML with improved semantic markup, animation properties, and ARIA attributes
        const tldsHtml = recentTlds.map((tld, index) =>
            `<a href="#" class="btn btn-default recent-tld-btn" data-tld="${tld}" 
                style="--btn-index: ${index}" aria-label="Load fields for ${tld}" 
                role="listitem" tabindex="0">
                <span class="tld-text">${tld}</span>
            </a>`
        ).join('');
        $('#recentTldsList').html(tldsHtml);
        $(document).off('click', '.recent-tld-btn');
        $(document).on('click', '.recent-tld-btn', function (e) {
            e.preventDefault();
            const tld = $(this).data('tld');
            if ($("#tldInput")[0].selectize) {
                // Set value in Selectize dropdown
                $("#tldInput")[0].selectize.setValue(tld);
            } else {
                // Fallback to standard select
                $("#tldInput").val(tld);
            }
            $("#lookupFieldsButton").click();
        });
        $(document).off('keydown', '.recent-tld-btn');
        $(document).on('keydown', '.recent-tld-btn', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                $(this).trigger('click');
            }
        });
    }
}

function getRecentTlds() {
    try {
        const tlds = JSON.parse(localStorage.getItem('cnic_recentTlds')) || [];
        return tlds;
    } catch (e) {
        return [];
    }
}

function addRecentTld(tld) {
    try {
        let tlds = getRecentTlds();
        tlds = tlds.filter(item => item !== tld);
        tlds.unshift(tld);
        tlds = tlds.slice(0, 5);
        localStorage.setItem('cnic_recentTlds', JSON.stringify(tlds));
        initRecentTlds();
    } catch (e) {
        console.error('Failed to save recent TLD', e);
    }
}
