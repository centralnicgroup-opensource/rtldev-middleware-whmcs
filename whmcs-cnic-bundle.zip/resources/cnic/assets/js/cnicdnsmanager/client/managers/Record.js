export class Record {
    constructor(ui) {
        this.ui = ui;
        // Clear a field's inline validation error as soon as the user edits it.
        // Delegated on document so it works regardless of when the add-record
        // panel is rendered/shown.
        $(document)
            .on('input', '#newDnsRecordHost', () => $('#newDnsRecordHostWrapper').removeClass('has-error'))
            .on('input', '#newDnsRecordAddress', () => $('#newDnsRecordAddressWrapper').removeClass('has-error'));
    }

    addRecord() {
        const dnszone = $('input[name="dnszone"]').val();
        // fetch host name and check if it matches dnszone then replace with '@'
        const host = (() => {
            const h = $('#newDnsRecordHost').val()?.trim();
            return h === dnszone ? '@' : h;
        })();
        let ttl = $('#newDnsRecordTtl').val();
        const type = $('#newDnsRecordType').val();
        const address = $('#newDnsRecordAddress').val();
        const priority = $('#newDnsRecordPriority').val();
        
        // For record types that don't support TTL, set it to empty string
        const noTtlTypes = ['ALIAS'];
        if (noTtlTypes.includes(type)) {
            ttl = '';
        }
        const prioritySupportedTypes = $('input[name="prioritySupportedRecordType[]"]').map(function () {
            return $(this).val();
        }).get();

        // Clear any previous inline validation state before re-validating
        this.clearValidationErrors();

        if (!host.length) {
            this.showFieldError('#newDnsRecordHostWrapper', '#newDnsRecordHost');
            return;
        }

        if (!address.length) {
            this.showFieldError('#newDnsRecordAddressWrapper', '#newDnsRecordAddress');
            return;
        }

        // Build record object
        const recordData = {
            hostname: host,
            ttl: ttl,
            type: type,
            address: address,
            priority: priority,
            recid: '' // New record has no ID
        };

        // Use centralized method to build row (DRY principle)
        const $newRow = this.ui.buildDnsRecordRow(recordData, this);

        // Insert the new row in the correct position based on the record type and hostname values
        const rows = $('#dnsRecordsTableBody').find('.dns-record');
        let inserted = false;
        rows.each(function () {
            const currentType = $(this).find('select[name="dnsrecordtype[]"]').val();
            const currentHost = $(this).find('input[name="dnsrecordhost[]"]').val();
            if (type < currentType || (type === currentType && host < currentHost)) {
                $(this).before($newRow);
                inserted = true;
                return false; // Break the loop
            }
        });
        if (!inserted) {
            $('#dnsRecordsTableBody').append($newRow);
        }

        // Remove the empty record row if it exists
        $('.dns-record-empty').remove();

        this.ui.showPendingSave();
        this.clearInputFields();
    }

    deleteRecord(event) {
        const $row = $(event.currentTarget).closest('tr');
        // Brand new, never-saved rows can be removed outright — they don't exist on the API yet.
        // The `.new-record` class is the source of truth; it's set in `UI.buildDnsRecordRow`
        // when the row is created without a recid.
        if ($row.hasClass('new-record')) {
            // Destroy any selectize instance to avoid orphaned dropdowns
            const $select = $row.find('.record-type');
            if ($select.length && $select[0].selectize) {
                $select[0].selectize.destroy();
            }
            $row.remove();
            this.ui.evaluatePendingState();
            return;
        }
        $row.addClass('pending-delete');
        this.ui.showPendingSave();
    }

    getDnsRecordOptions(selectedType) {
        const selectizeInstance = $('#newDnsRecordType')[0].selectize;
        const options = selectizeInstance.options;
        return Object.keys(options).map(key => {
            const option = options[key];
            const type = option.value;
            const label = option.text || type; // Use the actual label from selectize
            return `<option value="${type}" ${type === selectedType ? 'selected' : ''}>${label}</option>`;
        }).join('');
    }

    /**
     * Flag a form field as invalid by adding `.has-error` to its wrapper.
     * The error message is pre-rendered (and translated) in the template as a
     * hidden `.invalid-feedback` element; the `.has-error` class reveals it via
     * CSS. Replaces the previous modal-based validation feedback.
     * @param {string} wrapperSelector - Selector for the field's wrapper div
     * @param {string} fieldSelector - Selector for the input to focus
     */
    showFieldError(wrapperSelector, fieldSelector) {
        $(wrapperSelector).addClass('has-error');
        $(fieldSelector).focus();
    }

    /**
     * Remove all inline validation error states from the add-record form.
     */
    clearValidationErrors() {
        $('#newDnsRecordHostWrapper, #newDnsRecordAddressWrapper').removeClass('has-error');
    }

    clearInputFields() {
        this.clearValidationErrors();
        $('#newDnsRecordHost').val('');
        $('#newDnsRecordTtl').val('');
        $('#newDnsRecordAddress').val('');
        $('#newDnsRecordPriority').val('');

        // Let the UI class handle priority field visibility based on current type
        // This ensures the field state matches the selected record type
        const currentPriorityType = $('#newDnsRecordType').val();
        const supportsPriority = this.ui.supportsPriority(currentPriorityType);
        if (supportsPriority) {
            $('#newDnsRecordPriorityWrapper').show();
            $('#newDnsRecordPriority').attr('type', 'text');
        }
    }
}