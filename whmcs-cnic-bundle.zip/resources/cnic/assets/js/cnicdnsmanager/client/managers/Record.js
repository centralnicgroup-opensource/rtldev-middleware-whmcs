export class Record {
    constructor(ui) {
        this.ui = ui;
    }

    addRecord() {
        const dnszone = $('input[name="dnszone"]').val();
        // fetch host name and check if it matches dnszone then replace with '@'
        const host = (() => {
            const h = $('#newDnsRecordHost').val()?.trim();
            return h === dnszone ? '@' : h;
        })();
        let ttl = $('#newDnsRecordTtl').val();
        const type = $('#newDnsRecordType').val();
        const address = $('#newDnsRecordAddress').val();
        const priority = $('#newDnsRecordPriority').val();
        
        // For record types that don't support TTL, set it to empty string
        const noTtlTypes = ['ALIAS'];
        if (noTtlTypes.includes(type)) {
            ttl = '';
        }
        const prioritySupportedTypes = $('input[name="prioritySupportedRecordType[]"]').map(function () {
            return $(this).val();
        }).get();

        if (!host.length) {
            $('#cnicModal .modal-title').text('Error');
            $('#cnicModal .modal-body').text("Host is required.");
            $('#cnicModal').modal('show');
            return;
        }

        if (!address.length) {
            $('#cnicModal .modal-title').text('Error');
            $('#cnicModal .modal-body').text('Address is required.');
            $('#cnicModal').modal('show');
            return;
        }

        // Build record object
        const recordData = {
            hostname: host,
            ttl: ttl,
            type: type,
            address: address,
            priority: priority,
            recid: '' // New record has no ID
        };

        // Use centralized method to build row (DRY principle)
        const $newRow = this.ui.buildDnsRecordRow(recordData, this);

        // Insert the new row in the correct position based on the record type and hostname values
        const rows = $('#dnsRecordsTableBody').find('.dns-record');
        let inserted = false;
        rows.each(function () {
            const currentType = $(this).find('select[name="dnsrecordtype[]"]').val();
            const currentHost = $(this).find('input[name="dnsrecordhost[]"]').val();
            if (type < currentType || (type === currentType && host < currentHost)) {
                $(this).before($newRow);
                inserted = true;
                return false; // Break the loop
            }
        });
        if (!inserted) {
            $('#dnsRecordsTableBody').append($newRow);
        }

        // Remove the empty record row if it exists
        $('.dns-record-empty').remove();

        this.ui.showPendingSave();
        this.clearInputFields();
    }

    deleteRecord(event) {
        $(event.currentTarget).closest('tr').remove();
        this.ui.showPendingSave();
    }

    getDnsRecordOptions(selectedType) {
        const selectizeInstance = $('#newDnsRecordType')[0].selectize;
        const options = selectizeInstance.options;
        return Object.keys(options).map(key => {
            const option = options[key];
            const type = option.value;
            const label = option.text || type; // Use the actual label from selectize
            return `<option value="${type}" ${type === selectedType ? 'selected' : ''}>${label}</option>`;
        }).join('');
    }

    clearInputFields() {
        $('#newDnsRecordHost').val('');
        $('#newDnsRecordTtl').val('');
        $('#newDnsRecordAddress').val('');
        $('#newDnsRecordPriority').val('');
        
        // Let the UI class handle priority field visibility based on current type
        // This ensures the field state matches the selected record type
        const currentPriorityType = $('#newDnsRecordType').val();
        const supportsPriority = this.ui.supportsPriority(currentPriorityType);
        if (supportsPriority) {
            $('#newDnsRecordPriorityWrapper').show();
            $('#newDnsRecordPriority').attr('type', 'text');
        }
    }
}