/**
 * The record form: adds a record (opens below the toolbar) or edits one (moves under its row,
 * a bottom sheet on phones). Each save or delete is written straight away through the zone save.
 */
export class Record {
	constructor(ui) {
		this.ui = ui;
		this.mode = null; // null (closed), "add" or "edit"
		this.$editRow = null;
		this.dirty = false;

		this.$form = $('#addNewRecordContainer');
		this.$home = $('#addRecordHome');
		this.$backdrop = $('#recordFormBackdrop');

		$(document)
			// Clear a field's inline validation error as soon as the user edits it
			.on('input', '#newDnsRecordHost', () =>
				$('#newDnsRecordHostWrapper').removeClass('has-error'),
			)
			.on('input', '#newDnsRecordAddress', () =>
				$('#newDnsRecordAddressWrapper').removeClass('has-error'),
			)
			.on(
				'input change',
				'#addNewRecordContainer input, #addNewRecordContainer textarea, #newDnsRecordType',
				() => {
					this.dirty = true;
					this.ui.updateFormState();
				},
			)
			// Enter saves from a single-line field
			.on('keydown', '#addNewRecordContainer input', e => {
				if (e.key === 'Enter') {
					e.preventDefault();
					if (!$('#addRecordButton').prop('disabled')) this.save();
				}
			})
			.on('click', '[data-dns-add]', e => {
				e.stopPropagation();
				this.mode === 'add' ? this.close() : this.openAdd();
			})
			.on('click', '.dns-edit', e => {
				e.stopPropagation();
				const $row = $(e.currentTarget).closest('.dns-record');
				this.$editRow && this.$editRow[0] === $row[0]
					? this.close()
					: this.openEdit($row);
			})
			// on phones the whole row opens the record
			.on('click', '.dns-record', e => {
				if (this.isPhone() && !$(e.target).closest('button').length) {
					this.openEdit($(e.currentTarget));
				}
			});

		$('#addRecordButton').on('click', () => this.save());
		$('#cancelAddRecordButton').on('click', () => this.close());
		$('#recordFormClose').on('click', () => this.close());
		this.$backdrop.on('click', () => this.close());
		$('#deleteRecordButton').on('click', () =>
			$('#deleteConfirm').prop('hidden', false),
		);
		$('#deleteKeepButton').on('click', () =>
			$('#deleteConfirm').prop('hidden', true),
		);
		$('#deleteConfirmButton').on('click', () => this.remove());
	}

	isPhone() {
		return window.matchMedia('(max-width: 720px)').matches;
	}

	/**
	 * Ask before throwing away changes made in the open form
	 * @returns {boolean} true when it is fine to leave the form
	 */
	confirmLeave() {
		return (
			!this.mode || !this.dirty || window.confirm(this.ui.t('jsDiscardChanges'))
		);
	}

	openAdd() {
		if (!this.confirmLeave()) return;
		// finish a closing animation first, so its clean-up runs before the form moves
		this.$form.stop(true, true);
		this.close(true);
		this.mode = 'add';
		this.fill({
			type: $('#newDnsRecordType').val(),
			host: '',
			address: '',
			priority: '',
			ttl: '',
		});
		this.$home.after(this.$form);
		$('[data-dns-add]').attr('aria-expanded', 'true');
		this.show();
		$('#newDnsRecordHost').trigger('focus');
	}

	openEdit($row) {
		if (!this.confirmLeave()) return;
		// finish a closing animation first, so its clean-up runs before the form moves
		this.$form.stop(true, true);
		this.close(true);
		this.mode = 'edit';
		this.$editRow = $row.addClass('editing');
		$row
			.find('.dns-edit')
			.attr('aria-expanded', 'true')
			.text(this.ui.t('jsClose'));
		this.fill(this.ui.rowData($row));
		$row.after(
			$('<tr class="dns-edit-row"><td class="cnic-td" colspan="5"></td></tr>'),
		);
		$row.next('.dns-edit-row').children('td').append(this.$form);
		this.show();
		$('#newDnsRecordAddress').trigger('focus');
	}

	/**
	 * Put a record's values into the form
	 * @param {{type:string,host:string,address:string,priority:string,ttl:string}} data
	 */
	fill(data) {
		const selectize = $('#newDnsRecordType')[0].selectize;
		if (selectize) {
			selectize.setValue(data.type, true);
		} else {
			$('#newDnsRecordType').val(data.type);
		}
		this.ui.handleTypeChange();
		$('#newDnsRecordHost').val(data.host);
		$('#newDnsRecordAddress').val(data.address);
		if (this.ui.supportsPriority(data.type)) {
			$('#newDnsRecordPriority').val(
				data.priority === 'N/A' ? '' : data.priority,
			);
		}
		if (this.ui.supportsTtl(data.type)) {
			const ttl = /^\d+$/.test(data.ttl)
				? data.ttl
				: this.ui.CONSTANTS.DEFAULT_TTL;
			const $ttl = $('#newDnsRecordTtl');
			// a record with its own TTL keeps it as an extra choice
			if (!$ttl.find(`option[value="${ttl}"]`).length) {
				$ttl.append(new Option(this.ui.readableSeconds(ttl), ttl));
			}
			$ttl.val(ttl);
		}
		this.clearValidationErrors();
		$('#deleteConfirm').prop('hidden', true);
		$('#deleteRecordButton').prop('hidden', this.mode !== 'edit');
		$('#recordFormTitle').text(
			this.ui.t(this.mode === 'edit' ? 'jsEditRecord' : 'jsAdd'),
		);
		$('#addRecordButtonLabel').text(
			this.ui.t(this.mode === 'edit' ? 'jsSave' : 'jsAdd'),
		);
		this.ui.updateFormState();
		this.dirty = false;
	}

	show() {
		this.ui.closePopovers();
		// on phones the form is a bottom sheet with its own slide-in, so it skips the height animation
		this.isPhone()
			? this.$form.stop(true, true).show()
			: this.$form.stop(true, true).slideDown(150);
		this.$backdrop.prop('hidden', false);
		this.$form[0].scrollIntoView({block: 'nearest', behavior: 'smooth'});
	}

	/**
	 * Close the form and put it back below the toolbar
	 * @param {boolean} [instant] - skip the closing animation (another record opens right away)
	 */
	close(instant = false) {
		if (!this.mode) return;
		this.$backdrop.prop('hidden', true);
		// a user-initiated close gives the focus back to the button that opened the form
		const opener = instant
			? null
			: this.$editRow
				? this.$editRow.find('.dns-edit')[0]
				: $('[data-dns-add]:visible')[0];
		if (this.$editRow) {
			this.$editRow
				.removeClass('editing')
				.find('.dns-edit')
				.attr('aria-expanded', 'false')
				.text(this.ui.t('jsEdit'));
		}
		// the form goes back below the toolbar only once it is hidden, so it never shows up there while closing
		const $editRow = this.$form.closest('.dns-edit-row');
		const putBack = () => {
			this.$home.after(this.$form);
			$editRow.remove();
		};
		this.$form.stop(true, true);
		if (instant || this.isPhone()) {
			this.$form.hide();
			putBack();
		} else {
			this.$form.slideUp(150, putBack);
		}
		$('[data-dns-add]').attr('aria-expanded', 'false');
		this.mode = null;
		this.$editRow = null;
		this.dirty = false;
		if (opener) opener.focus();
	}

	save() {
		const dnszone = $('input[name="dnszone"]').val();
		const typed = $('#newDnsRecordHost').val()?.trim() || '';
		// the zone itself is the root of the zone
		const host = typed === dnszone ? '@' : typed;
		const type = $('#newDnsRecordType').val();
		const address = ($('#newDnsRecordAddress').val() || '').trim();

		this.clearValidationErrors();
		if (!host.length) {
			this.showFieldError('#newDnsRecordHostWrapper', '#newDnsRecordHost');
			return;
		}
		if (!address.length) {
			this.showFieldError(
				'#newDnsRecordAddressWrapper',
				'#newDnsRecordAddress',
			);
			return;
		}

		const record = {
			hostname: host,
			ttl: this.ui.supportsTtl(type) ? $('#newDnsRecordTtl').val() : '',
			type: type,
			address: address,
			priority: $('#newDnsRecordPriority').val(),
			recid: this.mode === 'edit' ? this.ui.rowData(this.$editRow).recid : '',
		};
		const $newRow = this.ui.buildDnsRecordRow(record);
		let message = this.ui.t('jsRecordSaved');

		if (this.mode === 'edit') {
			this.$editRow.replaceWith($newRow);
		} else {
			message = this.ui.t('jsRecordAdded');
			this.insertSorted($newRow, type, host);
		}
		this.close(true);
		this.ui.saveZone(message, $newRow);
	}

	remove() {
		if (this.mode !== 'edit') return;
		const $row = this.$editRow;
		this.close(true);
		$row.remove();
		this.ui.saveZone(this.ui.t('jsRecordDeleted'));
	}

	/**
	 * Insert a new row next to its type and name
	 */
	insertSorted($newRow, type, host) {
		let inserted = false;
		$('#dnsRecordsTableBody')
			.find('.dns-record')
			.each((index, element) => {
				const data = this.ui.rowData($(element));
				if (type < data.type || (type === data.type && host < data.host)) {
					$(element).before($newRow);
					inserted = true;
					return false;
				}
			});
		if (!inserted) {
			$('#dnsRecordsTableBody').append($newRow);
		}
	}

	/**
	 * Flag a form field as invalid by adding `.has-error` to its wrapper; the translated message
	 * is pre-rendered in the template as a hidden `.invalid-feedback` element
	 */
	showFieldError(wrapperSelector, fieldSelector) {
		$(wrapperSelector).addClass('has-error');
		$(fieldSelector).trigger('focus');
	}

	clearValidationErrors() {
		$('#newDnsRecordHostWrapper, #newDnsRecordAddressWrapper').removeClass(
			'has-error',
		);
	}
}
