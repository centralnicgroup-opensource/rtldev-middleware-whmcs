export class UI {
    constructor(selectize) {
        // Instance properties
        this.tapInsideRow = false;
        this.isMobile = window.matchMedia("(max-width: 768px)").matches;
        this.selectizeInstance = selectize;
        
        // Constants - Single source of truth
        this.CONSTANTS = {
            DEFAULT_TTL: '3600',
            GRID_TOTAL_COLUMNS: 12,
            SELECTORS: {
                hostWrapper: '#newDnsRecordHostWrapper',
                ttlWrapper: '#newDnsRecordTtlWrapper',
                ttlField: '#newDnsRecordTtl',
                typeWrapper: '#newDnsRecordTypeWrapper',
                typeField: '#newDnsRecordType',
                addressWrapper: '#newDnsRecordAddressWrapper',
                addressField: '#newDnsRecordAddress',
                addressHelpText: '#addressHelpText',
                priorityWrapper: '#newDnsRecordPriorityWrapper',
                priorityField: '#newDnsRecordPriority',
                priorityInputs: 'input[name="prioritySupportedRecordType[]"]',
                submitButton: '#submitButton',
                pendingSave: '#pendingSave',
                tableBody: '.cnic-table tbody'
            },
            COLUMN_CLASSES: 'col-md-2 col-md-3 col-md-4 col-md-5 col-md-6',
            NO_TTL_TYPES: ['URL', 'FRAME', 'ALIAS']
        };
        
        // Cache frequently accessed elements
        this._cacheElements();
        
        // Initialize
        this.selectizeInstance.initSelectize();
        this.selectizeInstance.initNewDnsRecordTypeSelectize();
        this.storeOriginalData();
        
        // Initialize help text for default record type
        this.updateAddressHelpText(this.$elements.typeField.val());
        
        // Initialize import/export button states
        $('#applyImportedRecordsButton').hide();
        $('#zoneImportResults').empty().hide();
    }

    /**
     * Cache jQuery elements for better performance
     * @private
     */
    _cacheElements() {
        this.$elements = {
            hostWrapper: $(this.CONSTANTS.SELECTORS.hostWrapper),
            ttlWrapper: $(this.CONSTANTS.SELECTORS.ttlWrapper),
            ttlField: $(this.CONSTANTS.SELECTORS.ttlField),
            typeField: $(this.CONSTANTS.SELECTORS.typeField),
            addressWrapper: $(this.CONSTANTS.SELECTORS.addressWrapper),
            addressField: $(this.CONSTANTS.SELECTORS.addressField),
            addressHelpText: $(this.CONSTANTS.SELECTORS.addressHelpText),
            priorityWrapper: $(this.CONSTANTS.SELECTORS.priorityWrapper),
            priorityField: $(this.CONSTANTS.SELECTORS.priorityField),
            submitButton: $(this.CONSTANTS.SELECTORS.submitButton),
            pendingSave: $(this.CONSTANTS.SELECTORS.pendingSave)
        };
    }

    attachEventHandlers(record) {
        // Button handlers
        $('#addRecordButton').click(() => record.addRecord());
        $('#cancelAddRecordButton').on('click', () => {
            this._closeAddRecordPanel();
        });
        $('#headerAddRecordButton').click(() => {
            // Close import/export panel if open
            if ($('#importExportPanel').is(':visible')) {
                this._closeImportExportPanel();
            }
            $('#addNewRecordContainer').slideToggle(150);
        });
        $('#resetButton').click(() => this.resetTableRows());
        this.$elements.submitButton.click((event) => this.handleSubmit(event));

        // Import/Export toggle
        $('#importExportToggle').on('click', () => {
            // Close add record panel if open
            if ($('#addNewRecordContainer').is(':visible')) {
                this._closeAddRecordPanel();
            }
            // Ensure apply button is hidden when opening panel
            if (!$('#importExportPanel').is(':visible')) {
                $('#applyImportedRecordsButton').hide();
                $('#zoneImportResults').empty().hide();
            }
            $('#importExportPanel').slideToggle(200);
        });
        $('#closeImportExportPanel').on('click', () => {
            this._closeImportExportPanel();
        });
        
        // File handling
        $('#zoneFileBrowse').on('click', (e) => {
            e.preventDefault();
            // Use native click to avoid jQuery trigger issues
            $('#zoneFileInput')[0].click();
        });
        $('#zoneFileInput').on('change', (e) => this.handleZoneFile(e));
        $('#exportZoneButton').on('click', () => this.handleZoneExport());
        $('#applyImportedRecordsButton').on('click', () => this.applyImportedRecords(record));
        this.initZoneDropArea();

        // Search box handler
        $('#dnsRecordSearch').on('input', (e) => this.handleSearch(e.target.value));

        // Record type change
        this.$elements.typeField.change(() => this.handleTypeChange());

        // Focus/blur handlers for form fields
        const $formFields = $(`${this.CONSTANTS.SELECTORS.hostWrapper},
                              ${this.CONSTANTS.SELECTORS.ttlWrapper},
                              ${this.CONSTANTS.SELECTORS.addressWrapper},
                              ${this.CONSTANTS.SELECTORS.priorityWrapper}`).find('input, select');
        $formFields.focus((event) => this.handleFocus(event))
                  .blur((event) => this.handleBlur(event));

        // Delegated event handlers for dynamic content
        $(document)
            .on('change', '#dnsForm', () => this.showPendingSave())
            .on('click', '.delete-record', (event) => record.deleteRecord(event))
            .on('change', '.dns-record select', (event) => this.handleTypeChangeEvent(event))
            .on('mouseenter', '.dns-record', (event) => this.handleMouseEnter(event))
            .on('mouseleave', '.dns-record', (event) => this.handleMouseLeave(event))
            .on('click', '.dns-record', (event) => this.handleClick(event))
            .on('click', (event) => this.handleDocumentClick(event));
    }

    handleSearch(query) {
        const q = (query || '').toLowerCase().trim();
        const $rows = $('#dnsRecordsTableBody').find('.dns-record');
        if (!q) {
            $rows.show();
            $('.dns-record-empty').toggle($rows.length === 0);
            return;
        }
        let visibleCount = 0;
        $rows.each(function () {
            const $row = $(this);
            const type = ($row.find('select[name="dnsrecordtype[]"] option:selected').text() || '').toLowerCase();
            const host = ($row.find('input[name="dnsrecordhost[]"]').val() || '').toLowerCase();
            const address = ($row.find('input[name="dnsrecordaddress[]"]').val() || '').toLowerCase();
            const match = type.includes(q) || host.includes(q) || address.includes(q);
            $row.toggle(match);
            if (match) visibleCount++;
        });
        $('.dns-record-empty').toggle(visibleCount === 0);
    }

    /* ----------------------------- IMPORT / EXPORT ----------------------------- */
    /**
     * Initialize drag-and-drop functionality for zone file upload
     */
    initZoneDropArea() {
        const $drop = $('#zoneDropArea');
        const $fileInput = $('#zoneFileInput');
        
        // Handle drag and drop
        $drop.on('dragover', (e) => { 
            e.preventDefault(); 
            $drop.addClass('drag-over'); 
        });
        
        $drop.on('dragleave', () => $drop.removeClass('drag-over'));
        
        $drop.on('drop', (e) => {
            e.preventDefault();
            $drop.removeClass('drag-over');
            const file = e.originalEvent.dataTransfer.files[0];
            if (file) this.readZoneFile(file);
        });
        
        // Make icon and text clickable (but not the button which has its own handler)
        $drop.find('.cnic-drop-icon, .cnic-drop-text').on('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            $fileInput[0].click();
        });
    }

    /**
     * Handle file input change event
     * @param {Event} e - Change event from file input
     */
    handleZoneFile(e) {
        const file = e.target.files[0];
        if (file) this.readZoneFile(file);
    }

    /**
     * Read zone file using FileReader API
     * @param {File} file - File object from input or drag-drop
     */
    readZoneFile(file) {
        const reader = new FileReader();
        reader.onload = (evt) => this.parseZoneContent(evt.target.result);
        reader.onerror = () => this.showModal('Error', 'Failed to read file');
        reader.readAsText(file);
    }

    parseZoneContent(content) {
        const $results = $('#zoneImportResults');
        const $applyBtn = $('#applyImportedRecordsButton');
        
        // Store content for later submission
        this.lastZoneFileContent = content;
        
        // Show loading state
        $results.html('<div class="text-info"><i class="fa fa-spinner fa-spin"></i> Parsing zone file...</div>').show();
        $applyBtn.hide();
        
        const data = {
            action: 'import-zone',
            m: 'cnicdnsmanager',
            zonefile: content,
            domainid: $('input[name="domainid"]').val()
        };
        
        $.post(cnicWebRootPath + '/index.php', data, (response) => {
            if (response.success) {
                this.renderImportPreview(response.parsedRecords, response.info);
            } else {
                this.showModal('Error', response.error || 'Failed to parse zone file');
                $results.empty().hide();
            }
            // Reset file input after processing
            $('#zoneFileInput').val('');
        }).fail(() => {
            this.showModal('Error', 'Unexpected error while importing zone');
            $results.empty().hide();
            $('#zoneFileInput').val('');
        });
    }

    /**
     * Render preview of imported DNS records
     * @param {Array} records - Array of parsed DNS records
     * @param {string|null} infoMessage - Optional info message about skipped records
     */
    renderImportPreview(records, infoMessage = null) {
        const $results = $('#zoneImportResults');
        const $applyBtn = $('#applyImportedRecordsButton');
        
        if (!records.length) {
            $results.html('<div class="text-danger"><i class="fa fa-exclamation-circle"></i> No valid records found in zone file.</div>').show();
            $applyBtn.hide();
            return;
        }
        
        const recordCount = records.length;
        let countMsg = `<div class="text-success" style="margin-bottom: 8px;">` +
            `<i class="fa fa-check-circle"></i> Found ${recordCount} record${recordCount > 1 ? 's' : ''} to import` +
            `</div>`;
        
        // Add info message if there are skipped records
        if (infoMessage) {
            countMsg += `<div class="text-warning" style="margin-bottom: 8px;">` +
                `<i class="fa fa-info-circle"></i> ${this.escapeHtml(infoMessage)}` +
                `</div>`;
        }
        
        const rows = records.map(r => 
            `<div class="cnic-zone-import-row">` +
            `<code>${r.hostname}</code> ${r.ttl} IN <strong>${r.type}</strong> ` +
            `${r.priority !== 'N/A' ? r.priority + ' ' : ''}${this.escapeHtml(r.address)}` +
            `</div>`
        ).join('');
        
        $results.html(countMsg + rows).show();
        $applyBtn.show();
        this.importBuffer = records;
    }

    /**
     * Apply imported records by submitting to backend
     * @param {Object} recordManager - Record manager instance (unused but kept for compatibility)
     */
    applyImportedRecords(recordManager) {
        if (!this.importBuffer?.length) {
            this.showModal('Warning', 'No records to apply.');
            return;
        }
        
        const recordCount = this.importBuffer.length;
        const $applyBtn = $('#applyImportedRecordsButton');
        const $saveBtn = $('#submitButton');
        
        // Disable both buttons to prevent any submissions during import
        $applyBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Applying...');
        $saveBtn.prop('disabled', true);
        
        // Show loading indicator
        $('#loaderIcon').show();
        
        // Get zone file content from the last upload
        const data = {
            action: 'importandsave-zone',
            m: 'cnicdnsmanager',
            zonefile: this.lastZoneFileContent,
            domainid: $('input[name="domainid"]').val()
        };
        
        this._submitAjaxRequest(
            data,
            (response) => {
                // Success: update table with returned records
                let successMessage = response.message || `${recordCount} record${recordCount > 1 ? 's' : ''} imported and saved successfully.`;
                
                // Append info message if there are skipped records
                if (response.info) {
                    successMessage += `\n\n${response.info}`;
                }
                
                // Update table with new records if available
                if (response.records && Array.isArray(response.records)) {
                    this._updateDnsRecordsTable(response.records, recordManager);
                    this._closeImportExportPanel();
                    this.showModal('Success', successMessage);
                    // Hide pending save indicator
                    this.hidePendingSave();
                } else {
                    // Fallback to reload if records not returned
                    this.showModal('Success', successMessage, () => window.location.reload());
                    this._closeImportExportPanel();
                }
                
                // Re-enable and restore buttons
                $applyBtn.prop('disabled', false).html('<i class="fa fa-check"></i> Apply Imported Records');
                // Save button remains disabled (no pending changes after import)
            },
            (error) => {
                // Error: show error message and re-enable buttons
                this.showModal('Error', error);
                $applyBtn.prop('disabled', false).html('<i class="fa fa-check"></i> Apply Imported Records');
                $saveBtn.prop('disabled', false);
            }
        );
    }

    /**
     * Handle zone file export
     */
    handleZoneExport() {
        const data = {
            action: 'export-zone',
            m: 'cnicdnsmanager',
            domainid: $('input[name="domainid"]').val()
        };
        
        $.post(cnicWebRootPath + '/index.php', data, (response) => {
            if (response.success) {
                const filename = response.filename || 'dns-zone.txt';
                this.downloadTextFile(response.zone, filename);
                this.showModal('Success', 'Zone file exported successfully.');
                this._closeImportExportPanel();
            } else {
                this.showModal('Error', response.error || 'Failed to export zone');
            }
        }).fail(() => this.showModal('Error', 'Unexpected error while exporting zone'));
    }

    /**
     * Submit AJAX request with common error handling (DRY)
     * @private
     * @param {Object} data - Request data
     * @param {Function} onSuccess - Success callback
     * @param {Function} onError - Error callback
     */
    _submitAjaxRequest(data, onSuccess, onError) {
        $.ajax({
            type: 'POST',
            url: cnicWebRootPath + '/index.php',
            data: data,
            success: (response) => {
                $('#loaderIcon').hide();
                if (response.success) {
                    onSuccess(response);
                } else {
                    onError(response.error || 'Operation failed');
                }
            },
            error: (xhr) => {
                $('#loaderIcon').hide();
                onError(xhr.responseJSON?.message || 'An unexpected error occurred');
            }
        });
    }

    /**
     * Build a DNS record table row (DRY - single source of truth)
     * @param {Object} record - Record data {hostname, ttl, type, address, priority, recid}
     * @param {Object} recordManager - Record manager instance for getDnsRecordOptions
     * @returns {jQuery} jQuery object of the row
     */
    buildDnsRecordRow(record, recordManager) {
        const prioritySupportedTypes = $('input[name="prioritySupportedRecordType[]"]').map(function() {
            return $(this).val();
        }).get();
        
        const isPriorityType = prioritySupportedTypes.includes(record.type);
        const priorityValue = isPriorityType ? (record.priority || '') : 'N/A';
        const priorityFieldType = isPriorityType ? 'text' : 'hidden';
        const options = recordManager.getDnsRecordOptions(record.type);
        const recid = record.recid || '';
        const isNewRecord = !recid;
        
        const rowHtml = `
            <tr class="dns-record cnic-tr ${isNewRecord ? 'new-record' : ''}" data-record-type="${record.type}">
                <td class="cnic-td cnic-td-type">
                    <input type="hidden" name="dnsrecid[]" value="${recid}" />
                    <select name="dnsrecordtype[]" class="form-control record-type" disabled>
                        ${options}
                    </select>
                </td>
                <td class="cnic-td">
                    <input type="text" name="dnsrecordhost[]" value="${this.escapeHtml(record.hostname)}" size="10" class="form-control" readonly />
                </td>
                <td class="cnic-td address-field">
                    <div class="address-priority-wrapper d-flex align-items-center">
                        <input type="text" name="dnsrecordaddress[]" value="${this.escapeHtml(record.address)}" size="40" class="form-control cnicEllipsis" readonly />
                        <input type="${priorityFieldType}" name="dnsrecordpriority[]" value="${priorityValue}" size="2" class="form-control priority-input" placeholder="* Priority" readonly />
                    </div>
                </td>
                <td class="cnic-td">
                    <input type="text" name="dnsrecordttl[]" value="${record.ttl || ''}" size="6" class="form-control" readonly />
                </td>
                <td class="cnic-td ${isNewRecord ? 'delete-field' : 'text-right'}">
                    <button type="button" class="btn btn-sm delete-record cnicDeleteBtn"><i class="fa fa-trash"></i></button>
                </td>
            </tr>
        `;
        
        const $row = $(rowHtml);
        
        // Initialize selectize for the type dropdown
        $row.find('.record-type').selectize({
            create: false,
            sortField: 'text',
            dropdownParent: 'body',
            selectOnTab: true
        });
        
        return $row;
    }

    /**
     * Update DNS records table with new data
     * @param {Array} records - Array of DNS records from server
     * @param {Object} recordManager - Record manager instance
     * @private
     */
    _updateDnsRecordsTable(records, recordManager) {
        const $tbody = $('#dnsRecordsTableBody');
        
        // Clear existing rows
        $tbody.empty();
        
        // Check if no records
        if (!records || records.length === 0) {
            $tbody.html('<tr class="cnic-tr dns-record-empty"><td class="cnic-td text-center" colspan="5">No DNS records found</td></tr>');
            return;
        }
        
        // Build new rows using centralized method
        records.forEach(record => {
            const $row = this.buildDnsRecordRow(record, recordManager);
            $tbody.append($row);
        });
        
        // Store original HTML for reset functionality
        this.originalHTML = $tbody.html();
    }

    /**
     * Close import/export panel and reset state
     * @private
     */
    _closeImportExportPanel() {
        $('#importExportPanel').slideUp(200);
        // Clear import state
        $('#zoneImportResults').empty().hide();
        $('#applyImportedRecordsButton').hide();
        $('#zoneFileInput').val('');
        this.importBuffer = [];
        this.lastZoneFileContent = null;
    }

    /**
     * Close add record panel and reset state
     * @private
     */
    _closeAddRecordPanel() {
        $('#addNewRecordContainer').slideUp(150);
    }

    /**
     * Trigger download of text file
     * @param {string} content - File content
     * @param {string} filename - Name for downloaded file
     */
    downloadTextFile(content, filename) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    /**
     * Escape HTML special characters to prevent XSS
     * @param {string} str - String to escape
     * @returns {string} Escaped string
     */
    escapeHtml(str) {
        const escapeMap = { 
            '&': '&amp;', 
            '<': '&lt;', 
            '>': '&gt;', 
            '"': '&quot;', 
            "'": '&#39;' 
        };
        return str.replace(/[&<>"']/g, c => escapeMap[c]);
    }

    /**
     * Display modal dialog with title and message
     * @param {string} title - Modal title
     * @param {string} body - Modal body text
     * @param {Function} [callback] - Optional callback to execute when modal is hidden
     */
    showModal(title, body, callback) {
        const $modal = $('#cnicModal');
        $modal.find('.modal-title').text(title);
        $modal.find('.modal-body').text(body);
        
        if (callback && typeof callback === 'function') {
            // Remove any existing hidden event handlers to avoid duplicates
            $modal.off('hidden.bs.modal');
            // Attach one-time callback
            $modal.one('hidden.bs.modal', callback);
        }
        
        $modal.modal('show');
    }

    showPendingSave() {
        this.$elements.submitButton.prop('disabled', false);
        this.$elements.pendingSave.show();
    }

    hidePendingSave() {
        this.$elements.submitButton.prop('disabled', true);
        this.$elements.pendingSave.hide();
    }

    storeOriginalData() {
        this.originalHTML = $(this.CONSTANTS.SELECTORS.tableBody).html();
    }

    resetTableRows() {
        $(this.CONSTANTS.SELECTORS.tableBody).html(this.originalHTML);
        this.storeOriginalData();
        this.hidePendingSave();
    }

    handleTypeChange() {
        const type = this.$elements.typeField.val();
        const hasPriority = this.supportsPriority(type);
        const hasTtl = this.supportsTtl(type);

        // Toggle field types and visibility
        this.toggleAddressField(this.$elements.addressField, type);
        this._toggleFieldVisibility(this.$elements.priorityWrapper, this.$elements.priorityField, hasPriority, '');
        this._toggleFieldVisibility(this.$elements.ttlWrapper, this.$elements.ttlField, hasTtl, this.CONSTANTS.DEFAULT_TTL);
        
        // Update help text for complex record types
        this.updateAddressHelpText(type);
        
        // Apply layout
        this.applyLayout(this.determineLayoutType(hasTtl, hasPriority));
    }

    /**
     * Toggle field visibility and value based on show flag
     * @private
     */
    _toggleFieldVisibility($wrapper, $field, show, defaultValue = '') {
        show ? $wrapper.show() : $wrapper.hide();
        $field.val(show ? ($field.val() || defaultValue) : 'N/A')
              .attr('type', show ? 'text' : 'hidden');
    }

    handleFocus(event) {
        if (!this.$elements.ttlWrapper.is(':visible')) return;
        
        const id = event.target.id;
        const config = this.getLayoutConfig();
        const hasPriority = this.$elements.priorityWrapper.is(':visible');
        
        const focusMap = {
            'newDnsRecordHost': hasPriority ? config.hostnameFocus.withPriority : config.hostnameFocus.standard,
            'newDnsRecordAddress': hasPriority ? config.addressFocus.withPriority : config.addressFocus.standard
        };
        
        const layout = focusMap[id];
        if (layout) {
            this._applyColumnClass(this.$elements.hostWrapper, layout.hostname);
            this._applyColumnClass(this.$elements.addressWrapper, layout.address);
        }
    }

    handleBlur(event) {
        if (!this.$elements.ttlWrapper.is(':visible')) return;
        
        const id = event.target.id;
        if (id === 'newDnsRecordHost' || id === 'newDnsRecordAddress') {
            this.applyLayout(this.$elements.priorityWrapper.is(':visible') ? 'withPriority' : 'standard');
        }
    }

    handleSubmit(event) {
        event.preventDefault();

        // show loader
        $('#loaderIcon').show();

        // save original data
        this.originalHTML = [];
        this.storeOriginalData();

        // disable submit button
        $('#submitButton').prop('disabled', true);

        // Temporarily enable all dns-record rows to include them in the form data
        $('#dnsForm').find('.dns-record').each(function () {
            $(this).find('input, select').prop('disabled', false);
        });

        // Collect DNS records
        const dnsRecords = [];
        $('#dnsForm').find('.dns-record').each(function () {
            const selectizeInstance = $(this).find('select[name="dnsrecordtype[]"]').data('selectize');
            const record = {
                dnsrecid: $(this).find('input[name="dnsrecid[]"]').val(),
                dnsrecordhost: $(this).find('input[name="dnsrecordhost[]"]').val(),
                dnsrecordttl: $(this).find('input[name="dnsrecordttl[]"]').val(),
                dnsrecordtype: selectizeInstance ? selectizeInstance.getValue() : '',
                dnsrecordaddress: $(this).find('input[name="dnsrecordaddress[]"]').val(),
                dnsrecordpriority: $(this).find('input[name="dnsrecordpriority[]"]').val()
            };
            dnsRecords.push(record);
        });

        const formData = $('#dnsForm').serialize();

        this._submitAjaxRequest(
            formData,
            (response) => {
                // Success
                this.showModal('Success', 'DNS records have been updated successfully.');
                this.hidePendingSave();
            },
            (error) => {
                // Error
                this.showModal('Error', error || 'An error occurred while saving DNS records.');
                this.showPendingSave();
            }
        );
    }

    makeFieldsEditable(row) {
        row.addClass('editing');
        const type = row.find('.record-type').val();
        
        this.toggleAddressField(row.find('input[name="dnsrecordaddress[]"]'), type);
        this.togglePriorityField(row, type);
        this._handleRowField(row, 'dnsrecordttl[]', this.supportsTtl(type));
        row.find('input:not([name="dnsrecordttl[]"]):not([name="dnsrecordpriority[]"])').prop('readonly', false);
        this._toggleRowSelectize(row, true);
    }

    makeFieldsReadOnly(row) {
        row.removeClass('editing');
        this.toggleAddressField(row.find('textarea[name="dnsrecordaddress[]"]'), row.find('.record-type').val());
        row.find('input').prop('readonly', true);
        this._toggleRowSelectize(row, false);
    }

    /**
     * Handle field state in table row (generic for TTL, priority, etc)
     * @private
     */
    _handleRowField(row, fieldName, enabled) {
        const $field = row.find(`input[name="${fieldName}"]`);
        const $cell = $field.closest('td');
        
        $field.prop('readonly', !enabled);
        $cell.toggleClass('text-muted', !enabled);
        
        if (!enabled && $field.val() && $field.val() !== 'N/A') {
            $field.data('original', $field.val());
        } else if (enabled && (!$field.val() || $field.val() === 'N/A')) {
            $field.val($field.data('original') || this.CONSTANTS.DEFAULT_TTL);
        }
    }

    /**
     * Toggle selectize controls in row
     * @private
     * @param {jQuery} row Table row element
     * @param {boolean} enable Whether to enable selectize
     */
    _toggleRowSelectize(row, enable) {
        row.find('select').each(function () {
            const selectize = $(this)[0].selectize;
            if (selectize) {
                enable ? selectize.enable() : selectize.disable();
            }
        });
    }

    handleMouseEnter(event) {
        const row = $(event.currentTarget);
    
        // Check if any row is currently in an editable state
        const currentlyEditingRow = $('.dns-record.editing');
    
        // If no row is currently editable, make this row editable immediately
        if (!currentlyEditingRow.length) {
            this.makeAllFieldsReadOnlyExcept(row);
            row.data('shouldBeEditable', true);
            this.makeFieldsEditable(row);
            return;
        }
    
        // Clear any existing hover timer for this row
        if (row.data('hoverTimer')) {
            clearTimeout(row.data('hoverTimer'));
        }
    
        // Set a new hover timer for subsequent hovers
        const hoverTimer = setTimeout(() => {
            if (currentlyEditingRow[0] !== row[0]) {
                this.makeAllFieldsReadOnlyExcept(row);
                row.data('shouldBeEditable', true);
                this.makeFieldsEditable(row);
            }
        }, 500); // Replace 300 with your desired threshold in milliseconds
    
        // Store the timer in the row's data
        row.data('hoverTimer', hoverTimer);
    }
    
    handleMouseLeave(event) {
        const row = $(event.currentTarget);
        
        // Clear the hover timer when the mouse leaves the row
        if (row.data('hoverTimer')) {
            clearTimeout(row.data('hoverTimer'));
            row.removeData('hoverTimer');
        }
    }

    handleClick(event) {
        const row = $(event.currentTarget);
        this.makeAllFieldsReadOnlyExcept(row);
        row.data('shouldBeEditable', true);
        this.makeFieldsEditable(row);
        if (this.isMobile) {
            this.tapInsideRow = true;
        }
    }

    handleDocumentClick(event) {
        if (!$(event.target).closest('.dns-record').length) {
            $('.dns-record').each((index, element) => {
                const row = $(element);
                row.data('shouldBeEditable', false);
                this.makeFieldsReadOnly(row);
            });
            this.isEditing = false; // Reset the flag when clicking outside
        }
    }

    makeAllFieldsReadOnlyExcept(row) {
        $('.dns-record').each((index, element) => {
            const currentRow = $(element);
            if (currentRow[0] !== row[0]) {
                currentRow.data('shouldBeEditable', false);
                this.makeFieldsReadOnly(currentRow);
            }
        });
    }

    handleTypeChangeEvent(event) {
        const row = $(event.currentTarget).closest('.dns-record');
        const type = $(event.currentTarget).val();
        const $address = row.find('input[name="dnsrecordaddress[]"], textarea[name="dnsrecordaddress[]"]');
        
        if ($address.length) {
            this.toggleAddressField($address, type);
            this.togglePriorityField(row, type);
            this._handleRowField(row, 'dnsrecordttl[]', this.supportsTtl(type));
        }
    }

    /**
     * Get list of DNS record types that don't support TTL configuration
     * Single source of truth from CONSTANTS
     * @returns {string[]} Array of record types without TTL support
     */
    getNoTtlSupportTypes() {
        return this.CONSTANTS.NO_TTL_TYPES;
    }

    /**
     * Get priority supported record types from DOM
     * @returns {string[]} Array of record types that support priority
     */
    getPrioritySupportedTypes() {
        return $(this.CONSTANTS.SELECTORS.priorityInputs)
            .map(function () { return $(this).val(); })
            .get();
    }

    /**
     * Check if record type supports TTL
     * @param {string} type DNS record type
     * @returns {boolean} True if type supports TTL
     */
    supportsTtl(type) {
        return !this.getNoTtlSupportTypes().includes(type);
    }

    /**
     * Check if record type supports priority
     * @param {string} type DNS record type
     * @returns {boolean} True if type supports priority
     */
    supportsPriority(type) {
        return this.getPrioritySupportedTypes().includes(type);
    }

    /**
     * Get current form field visibility state
     * @returns {Object} State object with visibility flags
     */
    getFormFieldState() {
        return {
            ttlVisible: this.$elements.ttlWrapper.is(':visible'),
            priorityVisible: this.$elements.priorityWrapper.is(':visible'),
            type: this.$elements.typeField.val()
        };
    }

    /**
     * Determine appropriate layout based on field visibility
     * @param {boolean} showTtl Whether TTL field is visible
     * @param {boolean} hasPriority Whether priority field is visible
     * @returns {string} Layout type key
     */
    determineLayoutType(showTtl, hasPriority) {
        if (!showTtl && hasPriority) return 'noTtlWithPriority';
        if (!showTtl) return 'noTtl';
        if (hasPriority) return 'withPriority';
        return 'standard';
    }

    /**
     * Layout configuration for different field states
     * Defines column widths for responsive Bootstrap grid (total 12 columns)
     * @returns {Object} Layout configurations
     */
    getLayoutConfig() {
        return {
            // Standard layout: TTL visible, no priority
            standard: {
                hostname: 'col-md-4',
                ttl: 'col-md-2',
                type: 'col-md-2',
                address: 'col-md-4',
                priority: 'col-md-2'
            },
            // With priority: TTL visible, priority visible
            withPriority: {
                hostname: 'col-md-3',
                ttl: 'col-md-2',
                type: 'col-md-2',
                address: 'col-md-3',
                priority: 'col-md-2'
            },
            // No TTL: TTL hidden, no priority (URL/FRAME records)
            noTtl: {
                hostname: 'col-md-4',
                ttl: 'col-md-2',
                type: 'col-md-2',
                address: 'col-md-6',
                priority: 'col-md-2'
            },
            // No TTL with priority: TTL hidden, priority visible
            noTtlWithPriority: {
                hostname: 'col-md-4',
                ttl: 'col-md-2',
                type: 'col-md-2',
                address: 'col-md-4',
                priority: 'col-md-2'
            },
            // Focus states for hostname field
            hostnameFocus: {
                standard: { hostname: 'col-md-5', address: 'col-md-3' },
                withPriority: { hostname: 'col-md-4', address: 'col-md-2' }
            },
            // Focus states for address field
            addressFocus: {
                standard: { hostname: 'col-md-2', address: 'col-md-5' },
                withPriority: { hostname: 'col-md-2', address: 'col-md-4' }
            }
        };
    }

    /**
     * Apply layout configuration to form fields
     * @param {string} layoutType Layout configuration key
     */
    applyLayout(layoutType) {
        const config = this.getLayoutConfig();
        const layout = config[layoutType];
        
        if (!layout) {
            console.warn(`Unknown layout type: ${layoutType}`);
            return;
        }

        // Apply new layout using cached elements
        this._applyColumnClass(this.$elements.hostWrapper, layout.hostname);
        this._applyColumnClass(this.$elements.addressWrapper, layout.address);
        
        // TTL and Priority visibility is managed separately, just update classes if visible
        if (this.$elements.ttlWrapper.is(':visible')) {
            this._applyColumnClass(this.$elements.ttlWrapper, layout.ttl);
        }
        if (this.$elements.priorityWrapper.is(':visible')) {
            this._applyColumnClass(this.$elements.priorityWrapper, layout.priority);
        }
    }

    /**
     * Apply column class to element
     * @private
     */
    _applyColumnClass($element, columnClass) {
        $element.removeClass(this.CONSTANTS.COLUMN_CLASSES).addClass(columnClass);
    }

    /**
     * Toggle address field between input and textarea (TXT records need textarea)
     */
    toggleAddressField(element, type, name = "dnsrecordaddress[]") {
        if (!element || !element.length) return;
        
        const isTxt = type === 'TXT';
        const attrs = {
            name, 
            id: element.attr('id') || '',
            placeholder: 'Address',
            class: `form-control ${name === 'dnsrecordaddress[]' ? '' : 'dnsrecordaddress'}`
        };

        if (isTxt && !element.is('textarea')) {
            element.replaceWith($('<textarea>').attr({...attrs, rows: 5, class: attrs.class + ' cnicMultiline'}).val(element.val()));
        } else if (!isTxt && element.is('textarea')) {
            element.replaceWith($('<input>').attr({...attrs, type: 'text', class: attrs.class + ' cnicEllipsis'}).val(element.val()));
        }
    }

    /**
     * Toggle priority field in table row
     */
    togglePriorityField(row, type) {
        const $priority = row.find('.priority-input');
        const show = this.supportsPriority(type);

        if (show && $priority.attr('type') === 'hidden') {
            // Restore original value or empty string
            const originalValue = $priority.data('original-priority') || '';
            $priority.attr({type: 'text', size: 2}).val(originalValue).prop('readonly', false);
        } else if (!show) {
            // Store current value before hiding
            const currentValue = $priority.val();
            if (currentValue && currentValue !== 'N/A') {
                $priority.data('original-priority', currentValue);
            }
            $priority.attr('type', 'hidden').val('N/A').prop('readonly', true);
        } else if (show) {
            // Already visible, just make it editable
            $priority.prop('readonly', false);
        }
    }

    /**
     * Update help text for address field based on record type
     */
    updateAddressHelpText(type) {
        const helpTexts = {
            'SRV': {
                brief: 'Format: weight port target',
                detail: 'Example: "5 5060 jabber.example.com"'
            },
            'SVCB': {
                brief: 'Format: target [params]',
                detail: 'Example: "svc.example.net. port=443 ipv4hint=192.0.2.1" | Supported: port, ipv4hint, ipv6hint, ech, mandatory, no-default-alpn | Not supported: alpn with h2/h3, dohpath, ohttp, tls-supported-groups'
            },
            'NAPTR': {
                brief: 'Format: preference flags service regexp replacement',
                detail: 'Example: "10 \\"A\\" \\"\\" \\"!^.*$!prodserver.example.com!\\" ."'
            },
            'MX': {
                brief: 'Format: mail server hostname',
                detail: 'Example: "mail.example.com"'
            },
            'CAA': {
                brief: 'Format: flags tag value',
                detail: 'Example: "0 issue letsencrypt.org"'
            },
            'TLSA': {
                brief: 'Format: usage selector type certificate-data',
                detail: null
            },
            'SSHFP': {
                brief: 'Format: algorithm fp-type fingerprint',
                detail: null
            },
            'LOC': {
                brief: 'Format: latitude longitude altitude size hp vp',
                detail: null
            },
            'DHCID': {
                brief: 'Format: base64-encoded identifier data',
                detail: null
            },
            'DS': {
                brief: 'Format: key-tag algorithm digest-type digest',
                detail: null
            },
            'DNSKEY': {
                brief: 'Format: flags protocol algorithm public-key',
                detail: null
            },
            'SMIMEA': {
                brief: 'Format: usage selector type certificate-data',
                detail: null
            }
        };

        const helpConfig = helpTexts[type];
        if (helpConfig) {
            // Create help text with expandable detail if available
            if (helpConfig.detail) {
                const helpHtml = `
                    <span class="help-brief">${helpConfig.brief}</span>
                    <a href="#" class="help-toggle" data-expanded="false"> [more]</a>
                    <span class="help-detail" style="display: none;">${helpConfig.detail}</span>
                `;
                this.$elements.addressHelpText.html(helpHtml).show();
                
                // Attach click handler for toggle
                this.$elements.addressHelpText.find('.help-toggle').off('click').on('click', (e) => {
                    e.preventDefault();
                    const $toggle = $(e.currentTarget);
                    const $detail = $toggle.siblings('.help-detail');
                    const isExpanded = $toggle.attr('data-expanded') === 'true';
                    
                    if (isExpanded) {
                        $detail.slideUp(200);
                        $toggle.text(' [more]').attr('data-expanded', 'false');
                    } else {
                        $detail.slideDown(200);
                        $toggle.text(' [less]').attr('data-expanded', 'true');
                    }
                });
            } else {
                this.$elements.addressHelpText.text(helpConfig.brief).show();
            }
        } else {
            this.$elements.addressHelpText.hide();
        }
    }
}