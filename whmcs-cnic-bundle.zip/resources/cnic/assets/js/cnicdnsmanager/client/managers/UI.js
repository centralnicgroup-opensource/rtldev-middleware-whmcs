export class UI {
	constructor(selectize) {
		this.selectizeInstance = selectize;

		// Constants - Single source of truth
		this.CONSTANTS = {
			DEFAULT_TTL: '3600',
			SELECTORS: {
				hostWrapper: '#newDnsRecordHostWrapper',
				ttlWrapper: '#newDnsRecordTtlWrapper',
				ttlField: '#newDnsRecordTtl',
				typeField: '#newDnsRecordType',
				addressWrapper: '#newDnsRecordAddressWrapper',
				addressField: '#newDnsRecordAddress',
				addressHelpText: '#addressHelpText',
				priorityWrapper: '#newDnsRecordPriorityWrapper',
				priorityField: '#newDnsRecordPriority',
				priorityInputs: 'input[name="prioritySupportedRecordType[]"]',
				tableBody: '#dnsRecordsTableBody',
			},
			NO_TTL_TYPES: ['URL', 'FRAME', 'ALIAS'],
			// example values shown as placeholders, the same in every language
			PLACEHOLDERS: {
				A: '192.0.2.10',
				AAAA: '2001:db8::10',
				ALIAS: 'example.net',
				CNAME: 'example.net',
				DNAME: 'example.net',
				MX: 'mail.example.com',
				MXE: '192.0.2.25',
				NS: 'ns1.example.net',
				PTR: 'host.example.com',
				TXT: 'v=spf1 include:example.net ~all',
				SPF: 'v=spf1 include:example.net ~all',
				SRV: '5 5060 sip.example.com',
				CAA: '0 issue letsencrypt.org',
			},
			// which summary sentence (jsSummary<Kind> translation) describes a record type
			SUMMARY_KIND: {
				A: 'Address',
				AAAA: 'Address',
				ALIAS: 'Address',
				CNAME: 'Alias',
				DNAME: 'Redirect',
				MX: 'Mail',
				MXE: 'Mail',
				NS: 'Delegation',
				TXT: 'Text',
				SPF: 'Text',
			},
			// record types with a format hint (jsTypeHelp<TYPE>) and maybe an example (jsTypeExample<TYPE>)
			HELP_TYPES: [
				'SRV',
				'SVCB',
				'NAPTR',
				'CAA',
				'TLSA',
				'SSHFP',
				'LOC',
				'DHCID',
				'DS',
				'DNSKEY',
				'SMIMEA',
			],
		};

		this.i18n = this._readI18n();
		this.zone = $('input[name="dnszone"]').val() || '';
		this.typeFilter = 'All';
		this.page = 1;
		this.perPage = 25;
		this.query = '';
		this.sort = {key: null, dir: 1};
		this.importBuffer = [];
		this.lastZoneFileContent = null;

		this._cacheElements();
		this.selectizeInstance.initNewDnsRecordTypeSelectize();
		this.storeOriginalData();
		this.handleTypeChange();
		this.formatTtlCells();
		this.refreshChips();
		this.initSecondsHints();
		$('.cnic-ui [data-toggle="tooltip"]').tooltip();

		$('#applyImportedRecordsButton').hide();
		$('#zoneImportResults').empty().hide();
	}

	/**
	 * Cache jQuery elements for better performance
	 * @private
	 */
	_cacheElements() {
		this.$elements = {
			ttlWrapper: $(this.CONSTANTS.SELECTORS.ttlWrapper),
			ttlField: $(this.CONSTANTS.SELECTORS.ttlField),
			typeField: $(this.CONSTANTS.SELECTORS.typeField),
			addressHelpText: $(this.CONSTANTS.SELECTORS.addressHelpText),
			priorityWrapper: $(this.CONSTANTS.SELECTORS.priorityWrapper),
			priorityField: $(this.CONSTANTS.SELECTORS.priorityField),
		};
	}

	/**
	 * Translations embedded by the template as JSON
	 * @private
	 * @returns {Object<string,string>}
	 */
	_readI18n() {
		try {
			return JSON.parse($('#cnicDnsI18n').text() || '{}');
		} catch (e) {
			return {};
		}
	}

	/**
	 * Translated text with {placeholders} filled in (plain text, not HTML)
	 * @param {string} key - Translation key
	 * @param {Object<string,string|number>} [vars] - Placeholder values
	 * @returns {string}
	 */
	t(key, vars = {}) {
		const text = this.i18n[key] ?? key;
		return text.replace(/\{(\w+)\}/g, (match, name) =>
			name in vars ? String(vars[name]) : match,
		);
	}

	attachEventHandlers(record) {
		this.record = record;
		this.initPopovers();

		// File handling
		$('#zoneFileBrowse').on('click', e => {
			e.preventDefault();
			// Use native click to avoid jQuery trigger issues
			$('#zoneFileInput')[0].click();
		});
		$('#zoneFileInput').on('change', e => this.handleZoneFile(e));
		$('#exportZoneButton').on('click', () => this.handleZoneExport());
		$('#applyImportedRecordsButton').on('click', () =>
			this.applyImportedRecords(),
		);
		this.initZoneDropArea();

		// Search, type filter and sorting
		$('#dnsRecordSearch').on('input', e => {
			this.query = (e.target.value || '').toLowerCase().trim();
			this.goToPage(1);
		});
		$('#dnsPerPage').on('change', e => {
			this.perPage = parseInt(e.target.value, 10) || 25;
			this.goToPage(1);
		});
		$('#dnsPagePrev').on('click', () => this.goToPage(this.page - 1));
		$('#dnsPageNext').on('click', () => this.goToPage(this.page + 1));
		$(document)
			.on('click', '#dnsTypeChips .cnic-chip', e => {
				this.typeFilter = $(e.currentTarget).attr('data-type');
				this.page = 1;
				this.refreshChips();
			})
			.on('click', '.dns-sort', e =>
				this.sortBy($(e.currentTarget).attr('data-sort')),
			)
			.on('click', '.cnic-copy-btn', event => this.handleCopyAddress(event));

		// Record type change of the record form
		this.$elements.typeField.on('change', () => this.handleTypeChange());
	}

	/* ------------------------------- POPOVERS ------------------------------- */

	/**
	 * Toolbar popovers (zone settings, import, export, more actions): one open at a time,
	 * closed by their toggle, the close buttons, a click outside or Escape
	 */
	initPopovers() {
		$(document)
			.on('click', '[data-cnic-popover]', e => {
				e.preventDefault();
				e.stopPropagation();
				this.togglePopover(
					$(e.currentTarget).attr('data-cnic-popover'),
					e.currentTarget,
				);
			})
			.on('click', '[data-cnic-popover-close]', e => {
				e.preventDefault();
				this.closePopovers(true);
			})
			.on('click', e => {
				if (!$(e.target).closest('.cnic-popover, .modal, .tooltip').length) {
					this.closePopovers();
				}
			})
			.on('keydown', e => {
				if (e.key === 'Escape') {
					this.closePopovers(true);
					this.record.close();
				}
			});
	}

	togglePopover(id, opener = null) {
		const $host = $(`#${id}`);
		if (!$host.length) return;
		const wasOpen = !$host.prop('hidden');
		this.closePopovers();
		if (wasOpen) return;
		this.record.close();
		$host.prop('hidden', false);
		// line the popover up with its toolbar button, kept inside the toolbar
		const toggle = $(
			`.dns-toolbar-actions [data-cnic-popover="${id}"]:visible`,
		)[0];
		const popover = $host.find('.cnic-popover')[0];
		if (toggle && popover) {
			const bar = $('.dns-toolbar')[0].getBoundingClientRect();
			const right = Math.min(
				bar.right - toggle.getBoundingClientRect().right,
				Math.max(0, bar.width - popover.offsetWidth),
			);
			popover.style.setProperty(
				'--cnic-popover-right',
				`${Math.max(0, right)}px`,
			);
		}
		$(`.dns-toolbar-actions [data-cnic-popover="${id}"]`).attr(
			'aria-expanded',
			'true',
		);
		// keyboard and screen reader users land in the dialog, and get back to its button on close
		this.popoverOpener = opener;
		if (popover) {
			popover.setAttribute('tabindex', '-1');
			popover.focus({preventScroll: true});
		}
	}

	closePopovers(restoreFocus = false) {
		const wasOpen = $('.cnic-popover-host:not([hidden])').length > 0;
		$('.cnic-popover-host').each((index, element) => {
			const $host = $(element);
			if ($host.prop('hidden')) return;
			$host.prop('hidden', true);
			if (element.id === 'importPopover') {
				this._resetImportState();
			}
		});
		$('.dns-toolbar-actions [data-cnic-popover]').attr(
			'aria-expanded',
			'false',
		);
		const opener = this.popoverOpener;
		if (restoreFocus && wasOpen && opener && $(opener).is(':visible')) {
			opener.focus();
		}
	}

	/* ------------------------- FILTER, SORT, FORMAT ------------------------- */

	/**
	 * Read a record's values from its row's hidden inputs
	 * @param {jQuery} $row - Record row
	 * @returns {{recid:string,type:string,host:string,address:string,priority:string,ttl:string}}
	 */
	rowData($row) {
		const value = name => $row.find(`input[name="${name}[]"]`).val() || '';
		return {
			recid: value('dnsrecid'),
			type: value('dnsrecordtype'),
			host: value('dnsrecordhost'),
			address: value('dnsrecordaddress'),
			priority: value('dnsrecordpriority'),
			ttl: value('dnsrecordttl'),
		};
	}

	/**
	 * Show the rows matching the search and the type filter
	 */
	applyFilters() {
		const $tbody = $(this.CONSTANTS.SELECTORS.tableBody);
		const $rows = $tbody.find('.dns-record');
		const matches = $rows.get().filter(element => {
			const data = this.rowData($(element));
			const haystack =
				`${data.host}.${this.zone} ${data.type} ${data.address}`.toLowerCase();
			return (
				(this.typeFilter === 'All' || data.type === this.typeFilter) &&
				(!this.query || haystack.includes(this.query))
			);
		});

		// show one page of the matching records
		const total = matches.length;
		const pages = Math.max(1, Math.ceil(total / this.perPage));
		this.page = Math.min(Math.max(1, this.page), pages);
		const first = (this.page - 1) * this.perPage;
		$rows.hide();
		$(matches.slice(first, first + this.perPage)).show();

		$tbody.find('.dns-filter-empty').remove();
		if ($rows.length && !total) {
			$tbody.append(
				`<tr class="cnic-tr dns-filter-empty"><td class="cnic-td text-center" colspan="5">${this.escapeHtml(
					$tbody.attr('data-empty-text') || '',
				)}</td></tr>`,
			);
		}

		$('#dnsPager').prop('hidden', total <= 25);
		$('#dnsPagerInfo').text(
			this.t('jsShowing', {
				from: total ? first + 1 : 0,
				to: Math.min(first + this.perPage, total),
				total,
			}),
		);
		$('#dnsPagePrev').prop('disabled', this.page <= 1);
		$('#dnsPageNext').prop('disabled', this.page >= pages);
	}

	/**
	 * Go to a page of the records (closes an open record form first)
	 * @param {number} page - Page number
	 */
	goToPage(page) {
		this.record.close();
		this.page = page;
		this.applyFilters();
	}

	/**
	 * Rebuild the type filter chips from the records in the table
	 */
	refreshChips() {
		const counts = {};
		$(this.CONSTANTS.SELECTORS.tableBody)
			.find('.dns-record')
			.each((index, element) => {
				const type = this.rowData($(element)).type;
				counts[type] = (counts[type] || 0) + 1;
			});
		const types = Object.keys(counts).sort();
		if (this.typeFilter !== 'All' && !counts[this.typeFilter]) {
			this.typeFilter = 'All';
		}
		const total = types.reduce((sum, type) => sum + counts[type], 0);
		const chip = (type, label, count) =>
			`<button type="button" class="cnic-chip" data-type="${this.escapeHtml(type)}" aria-pressed="${
				this.typeFilter === type
			}">${this.escapeHtml(label)}<span class="cnic-chip-count">${count}</span></button>`;
		$('#dnsTypeChips').html(
			total
				? chip('All', this.t('jsAll'), total) +
						types.map(type => chip(type, type, counts[type])).join('')
				: '',
		);
		this.applyFilters();
	}

	/**
	 * Sort the rows by a column; the same column again flips the direction
	 * @param {string} key - name, type, content or ttl
	 */
	sortBy(key) {
		this.record.close();
		this.sort = {key, dir: this.sort.key === key ? -this.sort.dir : 1};
		const value = $row => {
			const data = this.rowData($row);
			switch (key) {
				case 'name':
					return data.host === '@' ? '' : data.host.toLowerCase();
				case 'content':
					return data.address.toLowerCase();
				case 'ttl':
					return parseInt(data.ttl, 10) || 0;
				default:
					return data.type;
			}
		};
		const $tbody = $(this.CONSTANTS.SELECTORS.tableBody);
		const rows = $tbody.find('.dns-record').get();
		rows.sort((a, b) => {
			const x = value($(a));
			const y = value($(b));
			return (x < y ? -1 : x > y ? 1 : 0) * this.sort.dir;
		});
		$tbody.append(rows);
		$('.dns-sort').each((index, element) => {
			const $button = $(element);
			const active = $button.attr('data-sort') === key;
			$button
				.closest('th')
				.attr(
					'aria-sort',
					active ? (this.sort.dir === 1 ? 'ascending' : 'descending') : 'none',
				);
			$button
				.find('.dns-sort-icon')
				.text(active ? (this.sort.dir === 1 ? '↑' : '↓') : '↕');
		});
	}

	/**
	 * A number of seconds in a readable unit, e.g. 3600 -> "1 h"
	 * @param {string|number} value - Seconds
	 * @returns {string} Readable value, empty when not a whole number
	 */
	readableSeconds(value) {
		const text = String(value ?? '').trim();
		if (!/^\d+$/.test(text)) return '';
		const seconds = parseInt(text, 10);
		const units = [
			[86400, 'd'],
			[3600, 'h'],
			[60, 'min'],
		];
		for (const [size, unit] of units) {
			if (seconds >= size) {
				const amount = Math.round((seconds / size) * 10) / 10;
				return `${amount * size === seconds ? '' : '≈ '}${amount} ${unit}`;
			}
		}
		return `${seconds} s`;
	}

	formatTtlCells() {
		$('.dns-cell-ttl').each((index, element) => {
			const $cell = $(element);
			$cell.text(this.readableSeconds($cell.attr('data-ttl')) || '—');
		});
	}

	/**
	 * Readable value below each SOA timing field of the zone settings
	 */
	initSecondsHints() {
		$(document).on('input', '.dns-seconds', e => {
			const readable = this.readableSeconds(e.target.value);
			$(e.target)
				.closest('.cnic-field')
				.find('.dns-seconds-hint')
				.text(readable ? `= ${readable}` : '');
		});
		$('.dns-seconds').trigger('input');
	}

	/* --------------------------------- TOAST -------------------------------- */

	toast(message) {
		const $toast = $('#dnsToast');
		clearTimeout(this.toastTimer);
		$toast.prop('hidden', true).text(message);
		// re-show on the next frame so the slide-in runs for every message
		requestAnimationFrame(() => $toast.prop('hidden', false));
		this.toastTimer = setTimeout(() => $toast.prop('hidden', true), 3000);
	}

	/**
	 * Copy a row's value to the clipboard.
	 * @param {Event} event - Click event from the copy button
	 */
	handleCopyAddress(event) {
		event.preventDefault();
		event.stopPropagation();

		const $btn = $(event.currentTarget);
		const value = this.rowData($btn.closest('.dns-record')).address;
		if (!value) return;

		const showCopied = () => {
			const $icon = $btn.find('i');
			$btn.addClass('copied');
			$icon.removeClass('fa-copy').addClass('fa-check');
			if ($btn.data('copyTimer')) clearTimeout($btn.data('copyTimer'));
			$btn.data(
				'copyTimer',
				setTimeout(() => {
					$icon.removeClass('fa-check').addClass('fa-copy');
					$btn.removeClass('copied');
				}, 1500),
			);
		};

		// Prefer the async Clipboard API; fall back to execCommand for older
		// browsers and non-secure (non-HTTPS) contexts where it's unavailable.
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard
				.writeText(value)
				.then(showCopied)
				.catch(() => this._fallbackCopy(value, showCopied));
		} else {
			this._fallbackCopy(value, showCopied);
		}
	}

	/**
	 * Clipboard fallback using a temporary off-screen textarea + execCommand.
	 * @private
	 * @param {string} value - Text to copy
	 * @param {Function} onSuccess - Callback invoked when the copy succeeds
	 */
	_fallbackCopy(value, onSuccess) {
		const $temp = $('<textarea>')
			.css({position: 'fixed', top: '-9999px', opacity: 0})
			.val(value)
			.appendTo('body');
		$temp[0].select();
		try {
			if (document.execCommand('copy') && typeof onSuccess === 'function') {
				onSuccess();
			}
		} catch (e) {
			// Clipboard unavailable — silently ignore.
		}
		$temp.remove();
	}

	/* ----------------------------- IMPORT / EXPORT ----------------------------- */
	/**
	 * Initialize drag-and-drop functionality for zone file upload
	 */
	initZoneDropArea() {
		const $drop = $('#zoneDropArea');
		const $fileInput = $('#zoneFileInput');

		// Handle drag and drop
		$drop.on('dragover', e => {
			e.preventDefault();
			$drop.addClass('drag-over');
		});

		$drop.on('dragleave', () => $drop.removeClass('drag-over'));

		$drop.on('drop', e => {
			e.preventDefault();
			$drop.removeClass('drag-over');
			const file = e.originalEvent.dataTransfer.files[0];
			if (file) this.readZoneFile(file);
		});

		// Make icon and text clickable (but not the button which has its own handler)
		$drop.find('.cnic-drop-icon, .cnic-drop-text').on('click', e => {
			e.preventDefault();
			e.stopPropagation();
			$fileInput[0].click();
		});
	}

	/**
	 * Handle file input change event
	 * @param {Event} e - Change event from file input
	 */
	handleZoneFile(e) {
		const file = e.target.files[0];
		if (file) this.readZoneFile(file);
	}

	/**
	 * Read zone file using FileReader API
	 * @param {File} file - File object from input or drag-drop
	 */
	readZoneFile(file) {
		const reader = new FileReader();
		reader.onload = evt => this.parseZoneContent(evt.target.result);
		reader.onerror = () => this.showModal('Error', 'Failed to read file');
		reader.readAsText(file);
	}

	parseZoneContent(content) {
		const $results = $('#zoneImportResults');
		const $applyBtn = $('#applyImportedRecordsButton');

		// Store content for later submission
		this.lastZoneFileContent = content;

		// Show loading state
		$results
			.html(
				'<div class="text-info"><i class="fa fa-spinner fa-spin"></i> Parsing zone file...</div>',
			)
			.show();
		$applyBtn.hide();

		const data = {
			action: 'import-zone',
			m: 'cnicdnsmanager',
			zonefile: content,
			domainid: $('input[name="domainid"]').val(),
		};

		$.post(cnicWebRootPath + '/index.php', data, response => {
			if (response.success) {
				this.renderImportPreview(response.parsedRecords, response.info);
			} else {
				this.showModal('Error', response.error || 'Failed to parse zone file');
				$results.empty().hide();
			}
			// Reset file input after processing
			$('#zoneFileInput').val('');
		}).fail(() => {
			this.showModal('Error', 'Unexpected error while importing zone');
			$results.empty().hide();
			$('#zoneFileInput').val('');
		});
	}

	/**
	 * Render preview of imported DNS records
	 * @param {Array} records - Array of parsed DNS records
	 * @param {string|null} infoMessage - Optional info message about skipped records
	 */
	renderImportPreview(records, infoMessage = null) {
		const $results = $('#zoneImportResults');
		const $applyBtn = $('#applyImportedRecordsButton');

		if (!records.length) {
			$results
				.html(
					'<div class="text-danger"><i class="fa fa-exclamation-circle"></i> No valid records found in zone file.</div>',
				)
				.show();
			$applyBtn.hide();
			return;
		}

		const recordCount = records.length;
		let countMsg =
			`<div class="text-success" style="margin-bottom: 8px;">` +
			`<i class="fa fa-check-circle"></i> Found ${recordCount} record${recordCount > 1 ? 's' : ''} to import` +
			`</div>`;

		// Add info message if there are skipped records
		if (infoMessage) {
			countMsg +=
				`<div class="text-warning" style="margin-bottom: 8px;">` +
				`<i class="fa fa-info-circle"></i> ${this.escapeHtml(infoMessage)}` +
				`</div>`;
		}

		const rows = records
			.map(
				r =>
					`<div class="cnic-zone-import-row">` +
					`<code>${this.escapeHtml(r.hostname)}</code> ${this.escapeHtml(String(r.ttl))} IN <strong>${this.escapeHtml(
						r.type,
					)}</strong> ` +
					`${r.priority !== 'N/A' ? this.escapeHtml(String(r.priority)) + ' ' : ''}${this.escapeHtml(r.address)}` +
					`</div>`,
			)
			.join('');

		$results.html(countMsg + rows).show();
		$applyBtn.show();
		this.importBuffer = records;
	}

	/**
	 * Apply imported records by submitting to backend
	 */
	applyImportedRecords() {
		if (!this.importBuffer?.length) {
			this.showModal('Warning', 'No records to apply.');
			return;
		}

		const $applyBtn = $('#applyImportedRecordsButton');
		const applyHtml = $applyBtn.html();

		// Prevent a second submission during the import
		$applyBtn
			.prop('disabled', true)
			.html('<i class="fa fa-spinner fa-spin"></i>');
		$('#loaderIcon').show();

		// Get zone file content from the last upload
		const data = {
			action: 'importandsave-zone',
			m: 'cnicdnsmanager',
			zonefile: this.lastZoneFileContent,
			domainid: $('input[name="domainid"]').val(),
		};

		this._submitAjaxRequest(
			data,
			response => {
				$applyBtn.prop('disabled', false).html(applyHtml);
				this.closePopovers();
				if (response.records && Array.isArray(response.records)) {
					this._updateDnsRecordsTable(response.records);
					// skipped records are worth reading, so they keep the dialog
					if (response.info) {
						this.showModal(
							'Success',
							`${response.message || this.t('jsRecordsImported')}\n\n${response.info}`,
						);
					} else {
						this.toast(response.message || this.t('jsRecordsImported'));
					}
				} else {
					// Fallback to reload if records not returned
					this.showModal(
						'Success',
						response.message || this.t('jsRecordsImported'),
						() => window.location.reload(),
					);
				}
			},
			error => {
				this.showModal('Error', error);
				$applyBtn.prop('disabled', false).html(applyHtml);
			},
		);
	}

	/**
	 * Handle zone file export
	 */
	handleZoneExport() {
		const data = {
			action: 'export-zone',
			m: 'cnicdnsmanager',
			domainid: $('input[name="domainid"]').val(),
		};

		$.post(cnicWebRootPath + '/index.php', data, response => {
			if (response.success) {
				const filename = response.filename || 'dns-zone.txt';
				this.downloadTextFile(response.zone, filename);
				this.closePopovers();
				this.toast(this.t('jsZoneExported'));
			} else {
				this.showModal('Error', response.error || 'Failed to export zone');
			}
		}).fail(() =>
			this.showModal('Error', 'Unexpected error while exporting zone'),
		);
	}

	/**
	 * Clear the import preview and file
	 * @private
	 */
	_resetImportState() {
		$('#zoneImportResults').empty().hide();
		$('#applyImportedRecordsButton').hide();
		$('#zoneFileInput').val('');
		this.importBuffer = [];
		this.lastZoneFileContent = null;
	}

	/**
	 * Submit AJAX request with common error handling (DRY)
	 * @private
	 * @param {Object|string} data - Request data
	 * @param {Function} onSuccess - Success callback
	 * @param {Function} onError - Error callback
	 */
	_submitAjaxRequest(data, onSuccess, onError) {
		$.ajax({
			type: 'POST',
			url: cnicWebRootPath + '/index.php',
			data: data,
			success: response => {
				$('#loaderIcon').hide();
				if (response.success) {
					onSuccess(response);
				} else {
					onError(response.error || 'Operation failed');
				}
			},
			error: xhr => {
				$('#loaderIcon').hide();
				onError(xhr.responseJSON?.message || 'An unexpected error occurred');
			},
		});
	}

	/* ------------------------------ TABLE ROWS ------------------------------ */

	/**
	 * Build a DNS record table row (DRY - single source of truth, matches index.tpl)
	 * @param {Object} record - Record data {hostname, ttl, type, address, priority, recid}
	 * @returns {jQuery} jQuery object of the row
	 */
	buildDnsRecordRow(record) {
		const esc = value => this.escapeHtml(String(value ?? ''));
		const hasPriority = this.supportsPriority(record.type);
		const priority = hasPriority ? record.priority || '' : 'N/A';
		const name =
			record.hostname === '@'
				? esc(this.zone)
				: `${esc(record.hostname)}<span class="dns-zone">.${esc(this.zone)}</span>`;
		const content = `${hasPriority && priority !== '' ? `${esc(priority)} ` : ''}${esc(record.address)}`;

		return $(`
            <tr class="dns-record cnic-tr" data-record-type="${esc(record.type)}">
                <td class="cnic-td dns-cell-name">
                    <input type="hidden" name="dnsrecid[]" value="${esc(record.recid)}" />
                    <input type="hidden" name="dnsrecordtype[]" value="${esc(record.type)}" />
                    <input type="hidden" name="dnsrecordhost[]" value="${esc(record.hostname)}" />
                    <input type="hidden" name="dnsrecordaddress[]" value="${esc(record.address)}" />
                    <input type="hidden" name="dnsrecordpriority[]" value="${esc(priority)}" />
                    <input type="hidden" name="dnsrecordttl[]" value="${esc(record.ttl)}" />
                    <span class="dns-name" title="${esc(record.hostname === '@' ? this.zone : `${record.hostname}.${this.zone}`)}">${name}</span>
                </td>
                <td class="cnic-td dns-cell-type"><span class="cnic-badge">${esc(record.type)}</span></td>
                <td class="cnic-td dns-cell-content">
                    <span class="dns-content" title="${esc(record.address)}">${content}</span>
                    <button type="button" class="cnic-copy-btn" title="${esc(
											$('.cnic-copy-btn').first().attr('title') || 'Copy',
										)}" aria-label="${esc($('.cnic-copy-btn').first().attr('aria-label') || 'Copy')}"><i class="fa fa-copy"></i></button>
                </td>
                <td class="cnic-td dns-cell-ttl" data-ttl="${esc(record.ttl)}">${esc(this.readableSeconds(record.ttl) || '—')}</td>
                <td class="cnic-td dns-cell-action text-right">
                    <button type="button" class="cnic-btn cnic-btn--quiet dns-edit" aria-expanded="false">${esc(this.t('jsEdit'))}</button>
                </td>
            </tr>
        `);
	}

	/**
	 * Replace the table with the records returned by the server (zone import)
	 * @param {Array} records - Array of DNS records from server
	 * @private
	 */
	_updateDnsRecordsTable(records) {
		const $tbody = $(this.CONSTANTS.SELECTORS.tableBody);
		$tbody.empty();
		(records || []).forEach(record =>
			$tbody.append(this.buildDnsRecordRow(record)),
		);
		this.afterTableChange();
	}

	/**
	 * Keep chips, filters and the rollback copy in line with the table
	 */
	afterTableChange() {
		const $tbody = $(this.CONSTANTS.SELECTORS.tableBody);
		const hasRecords = $tbody.find('.dns-record').length > 0;
		$tbody.find('.dns-record-empty').remove();
		if (!hasRecords) {
			$tbody.append(
				`<tr class="cnic-tr dns-record-empty"><td class="cnic-td text-center" colspan="5">${this.escapeHtml(
					$tbody.attr('data-empty-text') || '',
				)}</td></tr>`,
			);
		}
		this.storeOriginalData();
		this.refreshChips();
	}

	/**
	 * Save the whole zone from the table's hidden inputs; on failure the table is rolled back
	 * @param {string} successMessage - Toast shown after saving
	 */
	saveZone(successMessage, $savedRow = null) {
		const $form = $('#dnsForm').addClass('is-saving').attr('aria-busy', 'true');
		const done = () => $form.removeClass('is-saving').removeAttr('aria-busy');
		this._submitAjaxRequest(
			$form.serialize(),
			() => {
				done();
				this.afterTableChange();
				this.toast(successMessage);
				// show where the saved record is
				if ($savedRow) {
					$savedRow.addClass('dns-row-saved');
					setTimeout(() => $savedRow.removeClass('dns-row-saved'), 1600);
				}
			},
			error => {
				done();
				this.resetTableRows();
				this.showModal(
					'Error',
					error || 'An error occurred while saving DNS records.',
				);
			},
		);
	}

	storeOriginalData() {
		this.originalHTML = $(this.CONSTANTS.SELECTORS.tableBody).html();
	}

	resetTableRows() {
		$(this.CONSTANTS.SELECTORS.tableBody).html(this.originalHTML);
		this.refreshChips();
	}

	/**
	 * Trigger download of text file
	 * @param {string} content - File content
	 * @param {string} filename - Name for downloaded file
	 */
	downloadTextFile(content, filename) {
		const blob = new Blob([content], {type: 'text/plain'});
		const url = URL.createObjectURL(blob);
		const a = document.createElement('a');
		a.href = url;
		a.download = filename;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
	}

	/**
	 * Escape HTML special characters to prevent XSS
	 * @param {string} str - String to escape
	 * @returns {string} Escaped string
	 */
	escapeHtml(str) {
		const escapeMap = {
			'&': '&amp;',
			'<': '&lt;',
			'>': '&gt;',
			'"': '&quot;',
			"'": '&#39;',
		};
		return String(str).replace(/[&<>"']/g, c => escapeMap[c]);
	}

	/**
	 * Display modal dialog with title and message
	 * @param {string} title - Modal title
	 * @param {string} body - Modal body text
	 * @param {Function} [callback] - Optional callback to execute when modal is hidden
	 */
	showModal(title, body, callback) {
		const $modal = $('#cnicModal');
		$modal.find('.modal-title').text(title);
		$modal.find('.modal-body').text(body);

		if (callback && typeof callback === 'function') {
			// Remove any existing hidden event handlers to avoid duplicates
			$modal.off('hidden.bs.modal');
			// Attach one-time callback
			$modal.one('hidden.bs.modal', callback);
		}

		$modal.modal('show');
	}

	/* ------------------------------ RECORD FORM ----------------------------- */

	/**
	 * Adapt the record form to its type: value label, example, priority and TTL fields, format hint
	 */
	handleTypeChange() {
		const type = this.$elements.typeField.val();

		this.toggleAddressField($(this.CONSTANTS.SELECTORS.addressField), type);
		this._toggleFieldVisibility(
			this.$elements.priorityWrapper,
			this.$elements.priorityField,
			this.supportsPriority(type),
			'',
		);
		this._toggleFieldVisibility(
			this.$elements.ttlWrapper,
			this.$elements.ttlField,
			this.supportsTtl(type),
			this.CONSTANTS.DEFAULT_TTL,
		);
		$('#newDnsRecordAddressLabel').text(
			this.i18n[`jsTypeLabel${type}`] || this.t('jsTypeLabelDefault'),
		);
		$(this.CONSTANTS.SELECTORS.addressField).attr(
			'placeholder',
			this.CONSTANTS.PLACEHOLDERS[type] || '',
		);
		this.updateAddressHelpText(type);
		this.updateFormState();
	}

	/**
	 * Refresh the summary sentence and whether the record can be saved
	 */
	updateFormState() {
		const type = this.$elements.typeField.val() || '';
		const host = ($('#newDnsRecordHost').val() || '').trim();
		const address = (
			$(this.CONSTANTS.SELECTORS.addressField).val() || ''
		).trim();
		const priority = (this.$elements.priorityField.val() || '').trim();
		const needsPriority = this.supportsPriority(type);

		const name = !host
			? this.t('jsNamePlaceholder')
			: host === '@' || host === this.zone
				? this.zone
				: `${host}.${this.zone}`;
		const strong = (text, className, empty) =>
			`<strong class="${className}${empty ? ' dns-summary-empty' : ''}">${this.escapeHtml(text)}</strong>`;
		const template = this.escapeHtml(
			this.t(`jsSummary${this.CONSTANTS.SUMMARY_KIND[type] || 'Default'}`),
		);
		const shownValue =
			address.length > 60 ? `${address.slice(0, 60)}…` : address;
		$('#recordSummary').html(
			template
				.replace('{name}', strong(name, 'dns-summary-name', !host))
				.replace(
					'{value}',
					strong(
						shownValue || this.t('jsValuePlaceholder'),
						'dns-summary-value',
						!address,
					),
				)
				.replace('{priority}', this.escapeHtml(priority || '?'))
				.replace('{type}', this.escapeHtml(type)),
		);

		const valid =
			host !== '' &&
			address !== '' &&
			(!needsPriority || /^\d+$/.test(priority));
		$('#addRecordButton').prop('disabled', !valid);
	}

	/**
	 * Toggle field visibility and value based on show flag
	 * @private
	 */
	_toggleFieldVisibility($wrapper, $field, show, defaultValue = '') {
		show ? $wrapper.show() : $wrapper.hide();
		$field.val(
			show
				? ($field.val() === 'N/A' ? '' : $field.val()) || defaultValue
				: 'N/A',
		);
	}

	/**
	 * Get priority supported record types from DOM
	 * @returns {string[]} Array of record types that support priority
	 */
	getPrioritySupportedTypes() {
		return $(this.CONSTANTS.SELECTORS.priorityInputs)
			.map(function () {
				return $(this).val();
			})
			.get();
	}

	/**
	 * Check if record type supports TTL
	 * @param {string} type DNS record type
	 * @returns {boolean} True if type supports TTL
	 */
	supportsTtl(type) {
		return !this.CONSTANTS.NO_TTL_TYPES.includes(type);
	}

	/**
	 * Check if record type supports priority
	 * @param {string} type DNS record type
	 * @returns {boolean} True if type supports priority
	 */
	supportsPriority(type) {
		return this.getPrioritySupportedTypes().includes(type);
	}

	/**
	 * Toggle the value field between input and textarea (TXT records need a textarea)
	 */
	toggleAddressField(element, type) {
		if (!element || !element.length) return;

		const isTxt = type === 'TXT';
		const attrs = {
			id: element.attr('id') || '',
			autocomplete: 'off',
			class: 'cnic-input cnic-input--mono',
		};

		if (isTxt && !element.is('textarea')) {
			element.replaceWith(
				$('<textarea>')
					.attr({...attrs, rows: 3, class: `${attrs.class} dns-textarea`})
					.val(element.val()),
			);
		} else if (!isTxt && element.is('textarea')) {
			element.replaceWith(
				$('<input>')
					.attr({...attrs, type: 'text'})
					.val(element.val()),
			);
		}
	}

	/**
	 * Format hint (and example, behind "more") for record types with a structured value
	 */
	updateAddressHelpText(type) {
		const $help = this.$elements.addressHelpText;
		if (!this.CONSTANTS.HELP_TYPES.includes(type)) {
			$help.hide();
			return;
		}
		const brief = this.escapeHtml(this.t(`jsTypeHelp${type}`));
		const example = this.i18n[`jsTypeExample${type}`];
		if (!example) {
			$help.html(brief).show();
			return;
		}
		$help
			.html(
				`<span class="help-brief">${brief}</span> <a href="#" class="help-toggle" data-expanded="false">${this.escapeHtml(
					this.t('jsHelpMore'),
				)}</a><span class="help-detail" style="display: none;"><br>${this.escapeHtml(example)}</span>`,
			)
			.show();
		$help
			.find('.help-toggle')
			.off('click')
			.on('click', e => {
				e.preventDefault();
				const $toggle = $(e.currentTarget);
				const expanded = $toggle.attr('data-expanded') === 'true';
				$toggle.siblings('.help-detail').toggle(!expanded);
				$toggle
					.text(this.t(expanded ? 'jsHelpMore' : 'jsHelpLess'))
					.attr('data-expanded', String(!expanded));
			});
	}
}
