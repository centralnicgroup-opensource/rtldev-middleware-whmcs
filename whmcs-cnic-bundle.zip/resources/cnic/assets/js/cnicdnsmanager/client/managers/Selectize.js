export class Selectize {
    initNewDnsRecordTypeSelectize() {
        $('#newDnsRecordType').selectize({
            create: false,
            sortField: 'text',
            dropdownParent: 'body'
        });
    }

    initSelectize() {
        $('#dnsRecordsTableBody').find('.record-type').selectize({
            create: false,
            sortField: 'text',
            dropdownParent: 'body'
        });
    }
}