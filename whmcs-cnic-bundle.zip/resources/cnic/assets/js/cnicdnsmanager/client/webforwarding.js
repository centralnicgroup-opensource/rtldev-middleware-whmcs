/**
 * Web Forwarding Management - AJAX Enhanced
 * Modern interface with real-time updates, no page reloads
 */
(function() {
    'use strict';

    // Configuration
    const config = {
        modulelink: '',
        domainid: '',
        dnszone: ''
    };

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        loadConfig();
        initAddPanel();
        initCardTypeSelector();
        initHostnamePreview();
        initFormSubmit();
        initDeleteButtons();
        initEditButtons();
    }

    /**
     * Load configuration from hidden inputs
     */
    function loadConfig() {
        config.modulelink = document.getElementById('modulelink')?.value || '';
        config.domainid = document.getElementById('domainid')?.value || '';
        config.dnszone = document.getElementById('dnszone')?.value || '';
    }

    /**
     * Show loading spinner
     */
    function showLoader() {
        const loader = document.getElementById('webForwardingLoader');
        if (loader) {
            loader.style.display = 'flex';
        }
    }

    /**
     * Hide loading spinner
     */
    function hideLoader() {
        const loader = document.getElementById('webForwardingLoader');
        if (loader) {
            loader.style.display = 'none';
        }
    }

    /**
     * Show message to user
     */
    function showMessage(message, type = 'success') {
        const messageDiv = document.getElementById('webForwardingMessage');
        if (!messageDiv) return;

        const iconClass = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
        const bgColor = type === 'success' ? '#d1fae5' : '#fee2e2';
        const borderColor = type === 'success' ? '#10b981' : '#ef4444';
        const textColor = type === 'success' ? '#065f46' : '#991b1b';

        messageDiv.innerHTML = `
            <div style="padding: 16px 20px; background: ${bgColor}; border-left: 4px solid ${borderColor}; border-radius: 8px; display: flex; align-items: center; animation: slideDown 0.3s ease-out;">
                <i class="fa ${iconClass}" style="font-size: 24px; color: ${borderColor}; margin-right: 16px;"></i>
                <div style="flex: 1;">
                    <p style="margin: 0; font-size: 15px; font-weight: 600; color: ${textColor};">${escapeHtml(message)}</p>
                </div>
                <button onclick="this.parentElement.parentElement.style.display='none'" style="background: none; border: none; font-size: 20px; color: ${textColor}; cursor: pointer; padding: 0; margin-left: 16px; opacity: 0.7; transition: opacity 0.2s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">
                    <i class="fa fa-times"></i>
                </button>
            </div>
        `;
        messageDiv.style.display = 'block';

        // Auto-hide success messages after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 5000);
        }

        // Scroll to message
        messageDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    /**
     * Initialize the add forwarding panel toggle
     */
    function initAddPanel() {
        const addButton = document.getElementById('addForwardingButton');
        const addPanel = document.getElementById('addForwardingPanel');
        const cancelButton = document.getElementById('cancelAddForwardingButton');
        
        if (!addButton || !addPanel) return;

        const addNewLabel = addButton.getAttribute('data-lang-add') || 'Add New Web Forwarding';
        
        addButton.addEventListener('click', function() {
            const isVisible = addPanel.style.display !== 'none';
            
            if (isVisible) {
                addPanel.style.display = 'none';
                addButton.innerHTML = '<i class="fa fa-plus"></i> ' + addNewLabel;
            } else {
                addPanel.style.display = 'block';
                addButton.innerHTML = '<i class="fa fa-minus"></i> Close Form';
                
                // Reset form and scroll to it
                const form = document.getElementById('addWebForwardingForm');
                if (form) form.reset();
                
                // Reset type selection to URL
                const cards = document.querySelectorAll('.forwarding-type-card');
                if (cards.length > 0) {
                    cards[0].click();
                }
                
                setTimeout(() => {
                    addPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    document.getElementById('newHostname')?.focus();
                }, 100);
            }
        });
        
        if (cancelButton) {
            cancelButton.addEventListener('click', function() {
                addPanel.style.display = 'none';
                addButton.innerHTML = '<i class="fa fa-plus"></i> ' + addNewLabel;
            });
        }
    }

    /**
     * Initialize card-based type selector
     */
    function initCardTypeSelector() {
        const cards = document.querySelectorAll('.forwarding-card--selectable');
        const hiddenTypeInput = document.getElementById('newType');
        
        if (!cards.length || !hiddenTypeInput) return;

        cards.forEach(function(card) {
            card.addEventListener('click', function() {
                const selectedType = this.getAttribute('data-type');
                const allowsPath = this.getAttribute('data-allows-path') === 'true';
                hiddenTypeInput.value = selectedType;
                
                // Update help text based on type
                updateTargetHelpText(allowsPath);
                
                // Update active states - remove from all, add to selected
                cards.forEach(function(c) {
                    c.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    }

    /**
     * Initialize hostname preview
     */
    function initHostnamePreview() {
        const hostnameInput = document.getElementById('newHostname');
        const hostnamePreview = document.getElementById('hostnamePreview');
        
        if (!hostnameInput || !hostnamePreview) return;

        hostnameInput.addEventListener('input', function() {
            const value = this.value.trim();
            const dnszone = config.dnszone || hostnamePreview.textContent.replace(/^\./, '');
            
            if (value === '' || value === '@') {
                hostnamePreview.textContent = dnszone;
            } else {
                hostnamePreview.textContent = value + '.' + dnszone;
            }
        });
    }

    /**
     * Update target URL help text based on selected type
     */
    function updateTargetHelpText(allowsPath) {
        const targetHelp = document.getElementById('targetHelp');
        if (!targetHelp) return;

        if (allowsPath) {
            // URL type allows path
            targetHelp.textContent = 'Enter the full URL to redirect to. Example: https://example.com/page';
        } else {
            // TRD and FRAME types don't allow path
            targetHelp.textContent = 'Enter hostname only (no path allowed). Example: https://example.com';
        }
    }

    /**
     * Validate target URL for path restrictions
     */
    function validateTargetUrl(url, allowsPath) {
        try {
            const urlObj = new URL(url);
            const hasPath = urlObj.pathname && urlObj.pathname !== '/';
            
            if (hasPath && !allowsPath) {
                return {
                    valid: false,
                    message: 'This forwarding type does not allow URL paths. Please use hostname only (e.g., https://example.com)'
                };
            }
            
            return { valid: true };
        } catch (e) {
            return {
                valid: false,
                message: 'Invalid URL format. Please enter a valid URL starting with http:// or https://'
            };
        }
    }

    /**
     * Initialize form submit with AJAX
     */
    function initFormSubmit() {
        const form = document.getElementById('addWebForwardingForm');
        if (!form) return;

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const newHostname = formData.get('dnsrecordhost[]');
            const newType = formData.get('dnsrecordtype[]');
            const newAddress = formData.get('dnsrecordaddress[]');
            
            if (!newHostname || !newType || !newAddress) {
                showMessage('Please fill in all fields', 'error');
                return;
            }

            // Validate target URL based on type
            const selectedCard = document.querySelector(`.forwarding-card--selectable[data-type="${newType}"]`);
            if (selectedCard) {
                const allowsPath = selectedCard.getAttribute('data-allows-path') === 'true';
                const validation = validateTargetUrl(newAddress, allowsPath);
                
                if (!validation.valid) {
                    showMessage(validation.message, 'error');
                    return;
                }
            }
            
            // Collect all existing forwardings
            const allRecords = collectAllForwardings();
            
            // Check if we're editing (hostname already exists) or adding new
            const existingIndex = allRecords.findIndex(r => r.hostname === newHostname);
            if (existingIndex >= 0) {
                // Update existing record
                allRecords[existingIndex] = {
                    hostname: newHostname,
                    type: newType,
                    address: newAddress
                };
            } else {
                // Add new record
                allRecords.push({
                    hostname: newHostname,
                    type: newType,
                    address: newAddress
                });
            }
            
            // Send ALL records to backend
            submitAllForwardings(allRecords, 'Web forwarding saved successfully!');
        });
    }

    /**
     * Initialize delete buttons with AJAX
     */
    function initDeleteButtons() {
        document.addEventListener('click', function(e) {
            if (e.target.closest('.delete-forwarding-row')) {
                const btn = e.target.closest('.delete-forwarding-row');
                const hostname = btn.getAttribute('data-hostname');
                const type = btn.getAttribute('data-type');
                const target = btn.getAttribute('data-target');
                
                // Show confirmation modal
                showDeleteConfirmation(hostname, type, target);
            }
        });
    }

    /**
     * Show delete confirmation modal
     */
    function showDeleteConfirmation(hostname, type, target) {
        const displayName = hostname === config.dnszone || hostname === '@' 
            ? config.dnszone 
            : (hostname.includes('.') ? hostname : hostname + '.' + config.dnszone);
        
        // Set modal title
        const modalTitle = document.getElementById('webForwardingModalLabel');
        if (modalTitle) {
            modalTitle.textContent = 'Are you sure you want to delete this web forwarding?';
        }
        
        // Set modal body content
        const modalBody = document.getElementById('webForwardingModalBody');
        if (modalBody) {
            modalBody.innerHTML = `
                <div style="padding: 8px 0;">
                    <div style="background: #fff; border: 2px solid #e9ecef; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                        <div style="display: flex; align-items: start; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid #f1f3f5;">
                            <div style="flex: 0 0 80px; font-size: 12px; font-weight: 600; color: #6c757d; text-transform: uppercase;">Source</div>
                            <div style="flex: 1; font-size: 15px; color: #212529; font-weight: 600;">${escapeHtml(displayName)}</div>
                        </div>
                        <div style="display: flex; align-items: start; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid #f1f3f5;">
                            <div style="flex: 0 0 80px; font-size: 12px; font-weight: 600; color: #6c757d; text-transform: uppercase;">Target</div>
                            <div style="flex: 1; font-size: 14px; color: #0ea5e9; font-weight: 500; word-break: break-all;">${escapeHtml(target)}</div>
                        </div>
                        <div style="display: flex; align-items: start;">
                            <div style="flex: 0 0 80px; font-size: 12px; font-weight: 600; color: #6c757d; text-transform: uppercase;">Type</div>
                            <div style="flex: 1;">
                                <span style="display: inline-block; padding: 4px 12px; background: ${type === 'URL' ? '#d1fae5' : '#dbeafe'}; color: ${type === 'URL' ? '#065f46' : '#1e40af'}; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                    ${type === 'URL' ? 'URL Redirect' : 'URL Frame'}
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; padding: 12px; display: flex; align-items: center;">
                        <i class="fa fa-exclamation-triangle" style="color: #856404; font-size: 18px; margin-right: 12px;"></i>
                        <span style="color: #856404; font-size: 13px; font-weight: 500;">This action cannot be undone.</span>
                    </div>
                </div>
            `;
        }
        
        // Show the modal
        $('#webForwardingModal').modal('show');
        
        // Set up the confirm button (remove any existing handlers first)
        const confirmBtn = document.getElementById('confirmDeleteForwarding');
        if (confirmBtn) {
            // Clone the button to remove all event listeners
            const newConfirmBtn = confirmBtn.cloneNode(true);
            confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
            
            // Add new click handler
            newConfirmBtn.addEventListener('click', function() {
                // Hide the modal
                $('#webForwardingModal').modal('hide');
                
                // Execute the delete
                deleteForwarding(hostname, type, target);
            });
        }
    }

    /**
     * Delete forwarding via AJAX
     */
    function deleteForwarding(hostname, type, targetToDelete) {
        // Find and remove the card from DOM immediately for instant feedback
        const cards = document.querySelectorAll('.forwarding-card');
        let cardToRemove = null;
        
        cards.forEach(function(card) {
            const cardHostname = card.getAttribute('data-hostname');
            const cardType = card.getAttribute('data-type');
            if (cardHostname === hostname && cardType === type) {
                cardToRemove = card.closest('.col-sm-12');
            }
        });
        
        // Remove from DOM
        if (cardToRemove) {
            cardToRemove.remove();
        }
        
        // Now collect all remaining records from the updated DOM
        const keepRecords = collectAllForwardings();
        
        // Send all remaining records to backend
        // updateForwardingsDisplay will be called in submitAllForwardings success handler
        submitAllForwardings(keepRecords, 'Web forwarding deleted successfully!');
    }

    /**
     * Initialize edit buttons
     */
    function initEditButtons() {
        document.addEventListener('click', function(e) {
            if (e.target.closest('.edit-forwarding-btn')) {
                const btn = e.target.closest('.edit-forwarding-btn');
                const hostname = btn.getAttribute('data-hostname');
                const type = btn.getAttribute('data-type');
                const target = btn.getAttribute('data-target');
                
                // Open panel first if needed
                const addButton = document.getElementById('addForwardingButton');
                const addPanel = document.getElementById('addForwardingPanel');
                
                if (addPanel && addPanel.style.display === 'none') {
                    addButton.click();
                    
                    // Wait for panel to open before populating
                    setTimeout(function() {
                        populateEditForm(hostname, type, target);
                    }, 100);
                } else {
                    populateEditForm(hostname, type, target);
                    addPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
                
                showMessage('Edit the forwarding details and save', 'success');
            }
        });
    }
    
    /**
     * Populate edit form with existing data
     */
    function populateEditForm(hostname, type, target) {
        // Normalize hostname for form input
        let normalizedHostname = hostname;
        if (hostname === config.dnszone) {
            normalizedHostname = '@';
        } else if (hostname && hostname.endsWith('.' + config.dnszone)) {
            // Remove domain suffix to get subdomain only
            normalizedHostname = hostname.substring(0, hostname.length - config.dnszone.length - 1);
        }
        
        // Populate form fields
        document.getElementById('newHostname').value = normalizedHostname;
        document.getElementById('newType').value = type;
        document.getElementById('newTarget').value = target;
        
        // Select appropriate card
        const card = document.querySelector(`.forwarding-card--selectable[data-type="${type}"]`);
        if (card) card.click();
    }

    /**
     * Collect all existing web forwarding records from the page
     */
    function collectAllForwardings() {
        const cards = document.querySelectorAll('.forwarding-card');
        const records = [];
        
        cards.forEach(function(card) {
            const deleteBtn = card.querySelector('.delete-forwarding-row');
            if (deleteBtn) {
                let hostname = deleteBtn.getAttribute('data-hostname');
                const type = deleteBtn.getAttribute('data-type');
                const address = deleteBtn.getAttribute('data-target');
                
                // Normalize hostname: convert full domain to @ for root
                if (hostname === config.dnszone) {
                    hostname = '@';
                } else if (hostname && hostname.endsWith('.' + config.dnszone)) {
                    // Remove domain suffix to get subdomain only
                    hostname = hostname.substring(0, hostname.length - config.dnszone.length - 1);
                }
                
                if (hostname && type && address) {
                    records.push({
                        hostname: hostname,
                        type: type,
                        address: address
                    });
                }
            }
        });
        
        return records;
    }
    
    /**
     * Submit all web forwarding records to backend
     */
    function submitAllForwardings(records, successMessage) {
        showLoader();
        
        // Use FormData for proper PHP array handling
        const formData = new FormData();
        formData.append('m', 'cnicdnsmanager');
        formData.append('domainid', config.domainid);
        formData.append('dnszone', config.dnszone);
        formData.append('webForwardingAddon', '1');
        
        // Add all records as proper PHP arrays
        if (records.length > 0) {
            records.forEach(function(record) {
                formData.append('dnsrecid[]', ''); // Empty ID for all records
                formData.append('dnsrecordtype[]', record.type);
                formData.append('dnsrecordhost[]', record.hostname);
                formData.append('dnsrecordaddress[]', record.address);
                formData.append('dnsrecordpriority[]', 'N/A');
                formData.append('dnsrecordttl[]', '3600');
            });
        } else {
            // Send empty arrays to delete all
            formData.append('dnsrecid[]', '');
            formData.append('dnsrecordtype[]', '');
            formData.append('dnsrecordhost[]', '');
            formData.append('dnsrecordaddress[]', '');
            formData.append('dnsrecordpriority[]', '');
            formData.append('dnsrecordttl[]', '');
        }
        
        // Post to saveWebForwarding action
        const url = config.modulelink + '&action=saveWebForwarding&domainid=' + config.domainid;
        
        $.ajax({
            type: 'POST',
            url: url,
            data: formData,
            processData: false,  // Don't process FormData
            contentType: false,  // Let browser set content-type with boundary
            success: function(response) {
                hideLoader();
                
                // Check if response contains error
                if (response && typeof response === 'string' && response.includes('error')) {
                    showMessage('Error saving web forwarding', 'error');
                    return;
                }
                
                showMessage(successMessage, 'success');
                
                // Update the DOM dynamically instead of reloading
                updateForwardingsDisplay(records);
                
                // Close the add panel and reset form
                const addPanel = document.getElementById('addForwardingPanel');
                const addButton = document.getElementById('addForwardingButton');
                const form = document.getElementById('addWebForwardingForm');
                
                if (addPanel && addButton && form) {
                    addPanel.style.display = 'none';
                    const addNewLabel = addButton.getAttribute('data-lang-add') || 'Add New Web Forwarding';
                    addButton.innerHTML = '<i class="fa fa-plus"></i> ' + addNewLabel;
                    form.reset();
                    
                    // Reset type selection to URL
                    const cards = document.querySelectorAll('.forwarding-type-card');
                    if (cards.length > 0) {
                        cards[0].click();
                    }
                }
            },
            error: function(xhr, status, error) {
                hideLoader();
                showMessage('Error: ' + error, 'error');
            }
        });
    }

    /**
     * Update the forwardings display dynamically
     */
    function updateForwardingsDisplay(records) {
        let container = document.getElementById('forwardingCards');
        const noRecordsMessage = document.getElementById('noRecordsMessage');
        const recordsContainer = document.getElementById('webForwardingRecordsContainer');
        
        // If no records, show empty state
        if (records.length === 0) {
            // Remove cards container if it exists
            if (container) {
                container.remove();
            }
            // Show empty state
            if (noRecordsMessage) {
                noRecordsMessage.style.display = 'block';
            }
            return;
        }
        
        // Hide empty state if it exists
        if (noRecordsMessage) {
            noRecordsMessage.style.display = 'none';
        }
        
        // Create container if it doesn't exist (when adding first record)
        if (!container && recordsContainer) {
            container = document.createElement('div');
            container.id = 'forwardingCards';
            container.className = 'row';
            container.style.margin = '0 -8px';
            recordsContainer.appendChild(container);
        }
        
        if (!container) {
            console.error('Could not find or create forwardingCards container');
            return;
        }
        
        // Build the cards HTML
        let cardsHTML = '';
        records.forEach(function(record, index) {
            const typeClass = record.type.toLowerCase();
            
            // Determine type label and icon based on type
            let typeLabel, typeIcon, infoMessage;
            if (record.type === 'URL') {
                typeLabel = 'URL Redirect';
                typeIcon = 'fa-arrow-right';
                infoMessage = 'Visitors will see <strong>' + escapeHtml(record.address) + '</strong> in their browser';
            } else if (record.type === 'TRD') {
                typeLabel = 'Temporary Redirect';
                typeIcon = 'fa-clock';
                infoMessage = 'Temporary redirect (HTTP 302) - useful for temporary moves';
            } else {
                typeLabel = 'URL Frame';
                typeIcon = 'fa-window-restore';
                infoMessage = 'Your domain name stays visible in the browser';
            }
            
            // Display hostname
            let displayHostname = record.hostname === '@' ? config.dnszone : record.hostname + '.' + config.dnszone;
            
            cardsHTML += `
                <div class="col-sm-12 col-md-6" style="padding: 4px; margin-bottom: 16px;">
                    <div class="forwarding-card type-${typeClass}" data-hostname="${escapeHtml(record.hostname)}" data-type="${escapeHtml(record.type)}" data-index="${index}">
                        
                        <!-- Type Badge -->
                        <div class="forwarding-type-badge type-${typeClass}">
                            <i class="fa ${typeIcon}"></i>
                            ${escapeHtml(typeLabel)}
                        </div>

                        <!-- Card Content -->
                        <div class="forwarding-card-content">
                            <!-- Source Domain -->
                            <div class="forwarding-card-section">
                                <label class="forwarding-card-label">
                                    <i class="fa fa-globe"></i> Source
                                </label>
                                <div class="forwarding-source editable-hostname" data-field="hostname">
                                    ${escapeHtml(displayHostname)}
                                </div>
                            </div>

                            <!-- Target URL -->
                            <div class="forwarding-card-section">
                                <label class="forwarding-card-label">
                                    <i class="fa fa-external-link"></i> Target
                                </label>
                                <div class="forwarding-target editable-target" data-field="target">
                                    <i class="fa fa-link"></i>
                                    ${escapeHtml(record.address)}
                                </div>
                            </div>

                            <!-- Visual Flow Indicator -->
                            <div class="forwarding-info-banner type-${typeClass}">
                                <i class="fa fa-info-circle"></i>
                                <span>${infoMessage}</span>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="forwarding-card-actions">
                            <button type="button" class="btn btn-sm edit-forwarding-btn btn-edit-${typeClass}" 
                                    data-hostname="${escapeHtml(record.hostname)}" 
                                    data-type="${escapeHtml(record.type)}" 
                                    data-target="${escapeHtml(record.address)}">
                                <i class="fa fa-edit"></i> Edit
                            </button>
                            <button type="button" class="btn btn-sm delete-forwarding-row btn-delete" 
                                    data-hostname="${escapeHtml(record.hostname)}" 
                                    data-type="${escapeHtml(record.type)}" 
                                    data-target="${escapeHtml(record.address)}">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        // Update the container
        container.innerHTML = cardsHTML;
    }

    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
    }

    // Make functions globally available
    window.webForwarding = {
        showMessage: showMessage,
        showLoader: showLoader,
        hideLoader: hideLoader,
        deleteForwarding: deleteForwarding,
        updateForwardingsDisplay: updateForwardingsDisplay
    };
})();
