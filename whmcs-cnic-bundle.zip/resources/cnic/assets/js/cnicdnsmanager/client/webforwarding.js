/**
 * Web Forwarding: add, edit and delete the domain's web forwardings without page reloads.
 * Every change sends the full list of forwardings to the saveWebForwarding action.
 */
(function () {
	'use strict';

	const config = {
		modulelink: '',
		domainid: '',
		dnszone: '',
	};
	let i18n = {};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	function init() {
		config.modulelink = document.getElementById('modulelink')?.value || '';
		config.domainid = document.getElementById('domainid')?.value || '';
		config.dnszone = document.getElementById('dnszone')?.value || '';
		try {
			i18n = JSON.parse(
				document.getElementById('cnicWfI18n')?.textContent || '{}',
			);
		} catch (e) {
			i18n = {};
		}
		initForm();
		initRowActions();
	}

	/**
	 * Translated text with {placeholders} filled in (plain text)
	 */
	function t(key, vars = {}) {
		const text = i18n[key] ?? key;
		return text.replace(/\{(\w+)\}/g, (match, name) =>
			name in vars ? String(vars[name]) : match,
		);
	}

	function escapeHtml(text) {
		const map = {
			'&': '&amp;',
			'<': '&lt;',
			'>': '&gt;',
			'"': '&quot;',
			"'": '&#039;',
		};
		return String(text).replace(/[&<>"']/g, m => map[m]);
	}

	function normalizeSourceHostname(hostname) {
		return typeof hostname === 'string'
			? hostname.trim().replace(/\/+$/g, '')
			: '';
	}

	/**
	 * Host name relative to the zone: "@" for the zone itself
	 */
	function relativeHostname(hostname) {
		const host = normalizeSourceHostname(hostname);
		if (host === '' || host === config.dnszone) {
			return host === '' ? '' : '@';
		}
		if (host.endsWith('.' + config.dnszone)) {
			return host.substring(0, host.length - config.dnszone.length - 1);
		}
		return host;
	}

	function fullHostname(hostname) {
		const host = relativeHostname(hostname);
		return host === '@' ? config.dnszone : `${host}.${config.dnszone}`;
	}

	function typeLabel(type) {
		return (
			{URL: i18n.webForwardingUrlType, TRD: i18n.webForwardingTrdType}[type] ||
			i18n.webForwardingFrameType ||
			type
		);
	}

	function showLoader(show) {
		const loader = document.getElementById('webForwardingLoader');
		if (loader) loader.style.display = show ? 'flex' : 'none';
	}

	/**
	 * Confirmation (fades out) or error message above the list
	 */
	function showMessage(message, type = 'success') {
		const box = document.getElementById('webForwardingMessage');
		if (!box) return;
		clearTimeout(showMessage.timer);
		box.innerHTML = `<div class="cnic-toast${type === 'error' ? ' wf-toast-error' : ''}" role="${
			type === 'error' ? 'alert' : 'status'
		}"><i class="fa ${type === 'error' ? 'fa-exclamation-circle' : 'fa-check-circle'}" aria-hidden="true"></i> ${escapeHtml(message)}</div>`;
		box.style.display = 'block';
		if (type === 'success') {
			showMessage.timer = setTimeout(() => {
				box.style.display = 'none';
			}, 4000);
		}
		box.scrollIntoView({behavior: 'smooth', block: 'nearest'});
	}

	/* ------------------------------ FORM ------------------------------ */

	function panel() {
		return document.getElementById('addForwardingPanel');
	}

	function selectedOption() {
		return document.querySelector('.wf-type-option[aria-checked="true"]');
	}

	function selectType(type) {
		const options = document.querySelectorAll('.wf-type-option');
		const target =
			document.querySelector(`.wf-type-option[data-type="${type}"]`) ||
			options[0];
		options.forEach(option =>
			option.setAttribute('aria-checked', String(option === target)),
		);
		if (!target) return;
		document.getElementById('newType').value = target.getAttribute('data-type');
		const help = document.getElementById('targetHelp');
		if (help) {
			help.textContent = t(
				target.getAttribute('data-allows-path') === 'true'
					? 'jsWfHelpPath'
					: 'jsWfHelpNoPath',
			);
		}
		updateFormState();
	}

	function openForm(record = null) {
		const form = document.getElementById('addWebForwardingForm');
		form.reset();
		selectType(record ? record.type : 'URL');
		document.getElementById('newHostname').value = record
			? relativeHostname(record.hostname)
			: '';
		document.getElementById('newTarget').value = record ? record.address : '';
		updateFormState();
		panel().style.display = 'block';
		// one call to action at a time: the empty list's button hides while the form is open
		const empty = document.getElementById('noRecordsMessage');
		if (empty) empty.style.display = 'none';
		document
			.getElementById('addForwardingButton')
			.setAttribute('aria-expanded', 'true');
		panel().scrollIntoView({behavior: 'smooth', block: 'nearest'});
		document.getElementById(record ? 'newTarget' : 'newHostname')?.focus();
	}

	function closeForm() {
		panel().style.display = 'none';
		const empty = document.getElementById('noRecordsMessage');
		if (empty)
			empty.style.display = document.querySelector('.wf-row') ? 'none' : '';
		document
			.getElementById('addForwardingButton')
			.setAttribute('aria-expanded', 'false');
	}

	/**
	 * Problem with the target URL for the selected type, or an empty string
	 */
	function targetProblem(url, allowsPath) {
		try {
			const parsed = new URL(url);
			if (!/^https?:$/.test(parsed.protocol)) return t('jsWfInvalidUrl');
			if (!allowsPath && parsed.pathname && parsed.pathname !== '/')
				return t('jsWfPathNotAllowed');
			return '';
		} catch (e) {
			return t('jsWfInvalidUrl');
		}
	}

	/**
	 * Refresh the summary sentence and whether the forwarding can be saved
	 */
	function updateFormState() {
		const option = selectedOption();
		const host = normalizeSourceHostname(
			document.getElementById('newHostname')?.value || '',
		);
		const target = (document.getElementById('newTarget')?.value || '').trim();
		const type = option ? option.getAttribute('data-type') : 'URL';
		const strong = (text, empty, className = '') =>
			`<strong class="${className}${empty ? ' dns-summary-empty' : ''}">${escapeHtml(text)}</strong>`;
		const summary = document.getElementById('wfSummary');
		if (summary) {
			summary.innerHTML = escapeHtml(t(`jsWfSummary${type}`))
				.replace(
					'{source}',
					strong(host ? fullHostname(host) : t('jsWfSourcePlaceholder'), !host),
				)
				.replace(
					'{target}',
					strong(
						target || t('jsWfTargetPlaceholder'),
						!target,
						'dns-summary-value',
					),
				);
		}
		const hostValid =
			/^(@|[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*)$/.test(
				host,
			);
		const allowsPath = option
			? option.getAttribute('data-allows-path') === 'true'
			: true;
		const save = document.getElementById('saveForwardingButton');
		if (save)
			save.disabled = !(
				hostValid &&
				target &&
				!targetProblem(target, allowsPath)
			);
	}

	function initForm() {
		const addButton = document.getElementById('addForwardingButton');
		const form = document.getElementById('addWebForwardingForm');
		if (!addButton || !form) return;

		addButton.addEventListener('click', () =>
			panel().style.display === 'none' ? openForm() : closeForm(),
		);
		document
			.querySelectorAll('[data-wf-add]')
			.forEach(button => button.addEventListener('click', () => openForm()));
		document
			.getElementById('cancelAddForwardingButton')
			?.addEventListener('click', closeForm);
		document
			.querySelectorAll('.wf-type-option')
			.forEach(option =>
				option.addEventListener('click', () =>
					selectType(option.getAttribute('data-type')),
				),
			);
		form.addEventListener('input', updateFormState);
		document.addEventListener('keydown', e => {
			if (e.key === 'Escape' && panel()?.style.display !== 'none') closeForm();
		});

		form.addEventListener('submit', e => {
			e.preventDefault();
			const option = selectedOption();
			const hostname = relativeHostname(
				document.getElementById('newHostname').value,
			);
			const type = document.getElementById('newType').value;
			const address = document.getElementById('newTarget').value.trim();
			if (!hostname || !type || !address) {
				showMessage(t('jsWfFillAll'), 'error');
				return;
			}
			const problem = targetProblem(
				address,
				option ? option.getAttribute('data-allows-path') === 'true' : true,
			);
			if (problem) {
				showMessage(problem, 'error');
				return;
			}
			// the host name is the key: saving an existing one replaces it
			const records = collectAllForwardings().filter(
				r => r.hostname !== hostname,
			);
			records.push({hostname, type, address});
			submitAllForwardings(records, t('jsWfSaved'));
		});
	}

	/* --------------------------- ROW ACTIONS --------------------------- */

	function rowRecord(row) {
		return {
			hostname: relativeHostname(row.getAttribute('data-hostname')),
			type: row.getAttribute('data-type'),
			address: row.getAttribute('data-target'),
		};
	}

	function initRowActions() {
		document.addEventListener('click', e => {
			const row = e.target.closest('.wf-row');
			if (!row) return;
			if (e.target.closest('.edit-forwarding-btn')) {
				openForm(rowRecord(row));
			} else if (e.target.closest('.delete-forwarding-row')) {
				confirmDelete(rowRecord(row));
			}
		});
	}

	function confirmDelete(record) {
		document.getElementById('webForwardingModalLabel').textContent =
			t('jsWfDeleteTitle');
		document.getElementById('webForwardingModalBody').innerHTML = `
            <dl class="wf-delete-summary">
                <dt>${escapeHtml(t('webForwardingSource'))}</dt><dd>${escapeHtml(fullHostname(record.hostname))}</dd>
                <dt>${escapeHtml(t('webForwardingTargetLabel'))}</dt><dd class="dns-mono">${escapeHtml(record.address)}</dd>
                <dt>${escapeHtml(t('webForwardingType'))}</dt><dd>${escapeHtml(typeLabel(record.type))}</dd>
            </dl>
            <p class="cnic-callout cnic-callout--warning"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i><span>${escapeHtml(
							t('jsWfCannotUndo'),
						)}</span></p>`;
		$('#webForwardingModal').modal('show');

		// replace the button to drop the handler of an earlier confirmation
		const button = document.getElementById('confirmDeleteForwarding');
		const fresh = button.cloneNode(true);
		button.parentNode.replaceChild(fresh, button);
		fresh.addEventListener('click', () => {
			$('#webForwardingModal').modal('hide');
			const records = collectAllForwardings().filter(
				r => !(r.hostname === record.hostname && r.type === record.type),
			);
			submitAllForwardings(records, t('jsWfDeleted'));
		});
	}

	/* ------------------------------ SAVING ------------------------------ */

	function collectAllForwardings() {
		return Array.from(document.querySelectorAll('.wf-row'))
			.map(rowRecord)
			.filter(r => r.hostname && r.type && r.address);
	}

	function submitAllForwardings(records, successMessage) {
		showLoader(true);
		const formData = new FormData();
		formData.append('m', 'cnicdnsmanager');
		formData.append('domainid', config.domainid);
		formData.append('dnszone', config.dnszone);
		formData.append('webForwardingAddon', '1');

		if (records.length > 0) {
			records.forEach(record => {
				formData.append('dnsrecid[]', '');
				formData.append('dnsrecordtype[]', record.type);
				formData.append(
					'dnsrecordhost[]',
					normalizeSourceHostname(record.hostname),
				);
				formData.append('dnsrecordaddress[]', record.address);
				formData.append('dnsrecordpriority[]', 'N/A');
				formData.append('dnsrecordttl[]', '3600');
			});
		} else {
			// empty arrays delete all forwardings
			[
				'dnsrecid',
				'dnsrecordtype',
				'dnsrecordhost',
				'dnsrecordaddress',
				'dnsrecordpriority',
				'dnsrecordttl',
			].forEach(name => formData.append(`${name}[]`, ''));
		}

		$.ajax({
			type: 'POST',
			url: `${config.modulelink}&action=saveWebForwarding&domainid=${config.domainid}`,
			data: formData,
			processData: false,
			contentType: false,
			success: response => {
				showLoader(false);
				if (
					response &&
					typeof response === 'string' &&
					response.includes('error')
				) {
					showMessage(t('jsWfError'), 'error');
					return;
				}
				renderRows(records);
				closeForm();
				showMessage(successMessage, 'success');
			},
			error: (xhr, status, error) => {
				showLoader(false);
				showMessage(`${t('jsWfError')} ${error || ''}`.trim(), 'error');
			},
		});
	}

	/**
	 * Rebuild the list (same markup as webforwarding.tpl)
	 */
	function renderRows(records) {
		const table = document.getElementById('forwardingTable');
		const empty = document.getElementById('noRecordsMessage');
		const body = document.getElementById('forwardingCards');
		if (!table || !body) return;

		table.style.display = records.length ? '' : 'none';
		if (empty) empty.style.display = records.length ? 'none' : '';

		body.innerHTML = records
			.map(record => {
				const host = relativeHostname(record.hostname);
				const type = String(record.type).toUpperCase();
				const name =
					host === '@'
						? escapeHtml(config.dnszone)
						: `${escapeHtml(host)}<span class="dns-zone">.${escapeHtml(config.dnszone)}</span>`;
				return `
                    <tr class="cnic-tr dns-record wf-row" data-hostname="${escapeHtml(host)}" data-type="${escapeHtml(
											type,
										)}" data-target="${escapeHtml(record.address)}">
                        <td class="cnic-td dns-cell-name"><span class="dns-name" title="${escapeHtml(fullHostname(host))}">${name}</span></td>
                        <td class="cnic-td dns-cell-type"><span class="cnic-badge wf-badge-${escapeHtml(type.toLowerCase())}">${escapeHtml(
													typeLabel(type),
												)}</span></td>
                        <td class="cnic-td dns-cell-content"><span class="dns-content" title="${escapeHtml(record.address)}">${escapeHtml(
													record.address,
												)}</span></td>
                        <td class="cnic-td dns-cell-action text-right">
                            <button type="button" class="cnic-btn cnic-btn--quiet edit-forwarding-btn">${escapeHtml(t('webForwardingEdit'))}</button>
                            <button type="button" class="cnic-btn cnic-btn--quiet wf-delete delete-forwarding-row">${escapeHtml(
															t('webForwardingDelete'),
														)}</button>
                        </td>
                    </tr>`;
			})
			.join('');
	}

	window.webForwarding = {showMessage, renderRows};
})();
