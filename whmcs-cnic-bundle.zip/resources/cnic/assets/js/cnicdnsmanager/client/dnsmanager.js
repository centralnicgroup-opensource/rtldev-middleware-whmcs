import { Dns } from './managers/Dns';

$(document).ready(() => {
    new Dns();
});