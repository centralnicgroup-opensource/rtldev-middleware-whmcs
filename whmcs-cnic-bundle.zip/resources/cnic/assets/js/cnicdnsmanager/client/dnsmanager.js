import { Dns } from './managers/Dns.js';

$(document).ready(() => {
    new Dns();
});