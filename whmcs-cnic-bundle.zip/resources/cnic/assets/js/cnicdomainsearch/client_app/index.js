/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$3=globalThis,e$5=t$3.ShadowRoot&&(void 0===t$3.ShadyCSS||t$3.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,s$3=Symbol(),o$4=new WeakMap;let n$3 = class n{constructor(t,e,o){if(this._$cssResult$=!0,o!==s$3)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e;}get styleSheet(){let t=this.o;const s=this.t;if(e$5&&void 0===t){const e=void 0!==s&&1===s.length;e&&(t=o$4.get(s)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),e&&o$4.set(s,t));}return t}toString(){return this.cssText}};const r$4=t=>new n$3("string"==typeof t?t:t+"",void 0,s$3),i$4=(t,...e)=>{const o=1===t.length?t[0]:e.reduce(((e,s,o)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(s)+t[o+1]),t[0]);return new n$3(o,t,s$3)},S$2=(s,o)=>{if(e$5)s.adoptedStyleSheets=o.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet));else for(const e of o){const o=document.createElement("style"),n=t$3.litNonce;void 0!==n&&o.setAttribute("nonce",n),o.textContent=e.cssText,s.appendChild(o);}},c$3=e$5?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return r$4(e)})(t):t;

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:i$3,defineProperty:e$4,getOwnPropertyDescriptor:r$3,getOwnPropertyNames:h$2,getOwnPropertySymbols:o$3,getPrototypeOf:n$2}=Object,a$2=globalThis,c$2=a$2.trustedTypes,l$2=c$2?c$2.emptyScript:"",p$2=a$2.reactiveElementPolyfillSupport,d$2=(t,s)=>t,u$2={toAttribute(t,s){switch(s){case Boolean:t=t?l$2:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t);}return t},fromAttribute(t,s){let i=t;switch(s){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t);}catch(t){i=null;}}return i}},f$2=(t,s)=>!i$3(t,s),y$2={attribute:!0,type:String,converter:u$2,reflect:!1,hasChanged:f$2};Symbol.metadata??=Symbol("metadata"),a$2.litPropertyMetadata??=new WeakMap;let b$1 = class b extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t);}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,s=y$2){if(s.state&&(s.attribute=!1),this._$Ei(),this.elementProperties.set(t,s),!s.noAccessor){const i=Symbol(),r=this.getPropertyDescriptor(t,i,s);void 0!==r&&e$4(this.prototype,t,r);}}static getPropertyDescriptor(t,s,i){const{get:e,set:h}=r$3(this.prototype,t)??{get(){return this[s]},set(t){this[s]=t;}};return {get(){return e?.call(this)},set(s){const r=e?.call(this);h.call(this,s),this.requestUpdate(t,r,i);},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??y$2}static _$Ei(){if(this.hasOwnProperty(d$2("elementProperties")))return;const t=n$2(this);t.finalize(),void 0!==t.l&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties);}static finalize(){if(this.hasOwnProperty(d$2("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(d$2("properties"))){const t=this.properties,s=[...h$2(t),...o$3(t)];for(const i of s)this.createProperty(i,t[i]);}const t=this[Symbol.metadata];if(null!==t){const s=litPropertyMetadata.get(t);if(void 0!==s)for(const[t,i]of s)this.elementProperties.set(t,i);}this._$Eh=new Map;for(const[t,s]of this.elementProperties){const i=this._$Eu(t,s);void 0!==i&&this._$Eh.set(i,t);}this.elementStyles=this.finalizeStyles(this.styles);}static finalizeStyles(s){const i=[];if(Array.isArray(s)){const e=new Set(s.flat(1/0).reverse());for(const s of e)i.unshift(c$3(s));}else void 0!==s&&i.push(c$3(s));return i}static _$Eu(t,s){const i=s.attribute;return !1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev();}_$Ev(){this._$Eg=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach((t=>t(this)));}addController(t){(this._$ES??=[]).push(t),void 0!==this.renderRoot&&this.isConnected&&t.hostConnected?.();}removeController(t){this._$ES?.splice(this._$ES.indexOf(t)>>>0,1);}_$E_(){const t=new Map,s=this.constructor.elementProperties;for(const i of s.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t);}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return S$2(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$ES?.forEach((t=>t.hostConnected?.()));}enableUpdating(t){}disconnectedCallback(){this._$ES?.forEach((t=>t.hostDisconnected?.()));}attributeChangedCallback(t,s,i){this._$AK(t,i);}_$EO(t,s){const i=this.constructor.elementProperties.get(t),e=this.constructor._$Eu(t,i);if(void 0!==e&&!0===i.reflect){const r=(void 0!==i.converter?.toAttribute?i.converter:u$2).toAttribute(s,i.type);this._$Em=t,null==r?this.removeAttribute(e):this.setAttribute(e,r),this._$Em=null;}}_$AK(t,s){const i=this.constructor,e=i._$Eh.get(t);if(void 0!==e&&this._$Em!==e){const t=i.getPropertyOptions(e),r="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==t.converter?.fromAttribute?t.converter:u$2;this._$Em=e,this[e]=r.fromAttribute(s,t.type),this._$Em=null;}}requestUpdate(t,s,i,e=!1,r){if(void 0!==t){if(i??=this.constructor.getPropertyOptions(t),!(i.hasChanged??f$2)(e?r:this[t],s))return;this.C(t,s,i);}!1===this.isUpdatePending&&(this._$Eg=this._$EP());}C(t,s,i){this._$AL.has(t)||this._$AL.set(t,s),!0===i.reflect&&this._$Em!==t&&(this._$Ej??=new Set).add(t);}async _$EP(){this.isUpdatePending=!0;try{await this._$Eg;}catch(t){Promise.reject(t);}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this._$Ep){for(const[t,s]of this._$Ep)this[t]=s;this._$Ep=void 0;}const t=this.constructor.elementProperties;if(t.size>0)for(const[s,i]of t)!0!==i.wrapped||this._$AL.has(s)||void 0===this[s]||this.C(s,this[s],i);}let t=!1;const s=this._$AL;try{t=this.shouldUpdate(s),t?(this.willUpdate(s),this._$ES?.forEach((t=>t.hostUpdate?.())),this.update(s)):this._$ET();}catch(s){throw t=!1,this._$ET(),s}t&&this._$AE(s);}willUpdate(t){}_$AE(t){this._$ES?.forEach((t=>t.hostUpdated?.())),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t);}_$ET(){this._$AL=new Map,this.isUpdatePending=!1;}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$Eg}shouldUpdate(t){return !0}update(t){this._$Ej&&=this._$Ej.forEach((t=>this._$EO(t,this[t]))),this._$ET();}updated(t){}firstUpdated(t){}};b$1.elementStyles=[],b$1.shadowRootOptions={mode:"open"},b$1[d$2("elementProperties")]=new Map,b$1[d$2("finalized")]=new Map,p$2?.({ReactiveElement:b$1}),(a$2.reactiveElementVersions??=[]).push("2.0.0");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$2=globalThis,i$2=t$2.trustedTypes,s$2=i$2?i$2.createPolicy("lit-html",{createHTML:t=>t}):void 0,e$3="$lit$",h$1=`lit$${(Math.random()+"").slice(9)}$`,o$2="?"+h$1,n$1=`<${o$2}>`,r$2=document,l$1=()=>r$2.createComment(""),c$1=t=>null===t||"object"!=typeof t&&"function"!=typeof t,a$1=Array.isArray,u$1=t=>a$1(t)||"function"==typeof t?.[Symbol.iterator],d$1="[ \t\n\f\r]",f$1=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,v$1=/-->/g,_$1=/>/g,m$1=RegExp(`>|${d$1}(?:([^\\s"'>=/]+)(${d$1}*=${d$1}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),p$1=/'/g,g$1=/"/g,$$2=/^(?:script|style|textarea|title)$/i,y$1=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),x$1=y$1(1),w$1=Symbol.for("lit-noChange"),T$1=Symbol.for("lit-nothing"),A$1=new WeakMap,E$1=r$2.createTreeWalker(r$2,129);function C$1(t,i){if(!Array.isArray(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==s$2?s$2.createHTML(i):i}const P$1=(t,i)=>{const s=t.length-1,o=[];let r,l=2===i?"<svg>":"",c=f$1;for(let i=0;i<s;i++){const s=t[i];let a,u,d=-1,y=0;for(;y<s.length&&(c.lastIndex=y,u=c.exec(s),null!==u);)y=c.lastIndex,c===f$1?"!--"===u[1]?c=v$1:void 0!==u[1]?c=_$1:void 0!==u[2]?($$2.test(u[2])&&(r=RegExp("</"+u[2],"g")),c=m$1):void 0!==u[3]&&(c=m$1):c===m$1?">"===u[0]?(c=r??f$1,d=-1):void 0===u[1]?d=-2:(d=c.lastIndex-u[2].length,a=u[1],c=void 0===u[3]?m$1:'"'===u[3]?g$1:p$1):c===g$1||c===p$1?c=m$1:c===v$1||c===_$1?c=f$1:(c=m$1,r=void 0);const x=c===m$1&&t[i+1].startsWith("/>")?" ":"";l+=c===f$1?s+n$1:d>=0?(o.push(a),s.slice(0,d)+e$3+s.slice(d)+h$1+x):s+h$1+(-2===d?i:x);}return [C$1(t,l+(t[s]||"<?>")+(2===i?"</svg>":"")),o]};let V$1 = class V{constructor({strings:t,_$litType$:s},n){let r;this.parts=[];let c=0,a=0;const u=t.length-1,d=this.parts,[f,v]=P$1(t,s);if(this.el=V.createElement(f,n),E$1.currentNode=this.el.content,2===s){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes);}for(;null!==(r=E$1.nextNode())&&d.length<u;){if(1===r.nodeType){if(r.hasAttributes())for(const t of r.getAttributeNames())if(t.endsWith(e$3)){const i=v[a++],s=r.getAttribute(t).split(h$1),e=/([.?@])?(.*)/.exec(i);d.push({type:1,index:c,name:e[2],strings:s,ctor:"."===e[1]?k$1:"?"===e[1]?H$1:"@"===e[1]?I$1:R$1}),r.removeAttribute(t);}else t.startsWith(h$1)&&(d.push({type:6,index:c}),r.removeAttribute(t));if($$2.test(r.tagName)){const t=r.textContent.split(h$1),s=t.length-1;if(s>0){r.textContent=i$2?i$2.emptyScript:"";for(let i=0;i<s;i++)r.append(t[i],l$1()),E$1.nextNode(),d.push({type:2,index:++c});r.append(t[s],l$1());}}}else if(8===r.nodeType)if(r.data===o$2)d.push({type:2,index:c});else {let t=-1;for(;-1!==(t=r.data.indexOf(h$1,t+1));)d.push({type:7,index:c}),t+=h$1.length-1;}c++;}}static createElement(t,i){const s=r$2.createElement("template");return s.innerHTML=t,s}};function N$1(t,i,s=t,e){if(i===w$1)return i;let h=void 0!==e?s._$Co?.[e]:s._$Cl;const o=c$1(i)?void 0:i._$litDirective$;return h?.constructor!==o&&(h?._$AO?.(!1),void 0===o?h=void 0:(h=new o(t),h._$AT(t,s,e)),void 0!==e?(s._$Co??=[])[e]=h:s._$Cl=h),void 0!==h&&(i=N$1(t,h._$AS(t,i.values),h,e)),i}let S$1 = class S{constructor(t,i){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=i;}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:i},parts:s}=this._$AD,e=(t?.creationScope??r$2).importNode(i,!0);E$1.currentNode=e;let h=E$1.nextNode(),o=0,n=0,l=s[0];for(;void 0!==l;){if(o===l.index){let i;2===l.type?i=new M$1(h,h.nextSibling,this,t):1===l.type?i=new l.ctor(h,l.name,l.strings,this,t):6===l.type&&(i=new L$1(h,this,t)),this._$AV.push(i),l=s[++n];}o!==l?.index&&(h=E$1.nextNode(),o++);}return E$1.currentNode=r$2,e}p(t){let i=0;for(const s of this._$AV)void 0!==s&&(void 0!==s.strings?(s._$AI(t,s,i),i+=s.strings.length-2):s._$AI(t[i])),i++;}};let M$1 = class M{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,i,s,e){this.type=2,this._$AH=T$1,this._$AN=void 0,this._$AA=t,this._$AB=i,this._$AM=s,this.options=e,this._$Cv=e?.isConnected??!0;}get parentNode(){let t=this._$AA.parentNode;const i=this._$AM;return void 0!==i&&11===t?.nodeType&&(t=i.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,i=this){t=N$1(this,t,i),c$1(t)?t===T$1||null==t||""===t?(this._$AH!==T$1&&this._$AR(),this._$AH=T$1):t!==this._$AH&&t!==w$1&&this._(t):void 0!==t._$litType$?this.g(t):void 0!==t.nodeType?this.$(t):u$1(t)?this.T(t):this._(t);}k(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}$(t){this._$AH!==t&&(this._$AR(),this._$AH=this.k(t));}_(t){this._$AH!==T$1&&c$1(this._$AH)?this._$AA.nextSibling.data=t:this.$(r$2.createTextNode(t)),this._$AH=t;}g(t){const{values:i,_$litType$:s}=t,e="number"==typeof s?this._$AC(t):(void 0===s.el&&(s.el=V$1.createElement(C$1(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===e)this._$AH.p(i);else {const t=new S$1(e,this),s=t.u(this.options);t.p(i),this.$(s),this._$AH=t;}}_$AC(t){let i=A$1.get(t.strings);return void 0===i&&A$1.set(t.strings,i=new V$1(t)),i}T(t){a$1(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH;let s,e=0;for(const h of t)e===i.length?i.push(s=new M(this.k(l$1()),this.k(l$1()),this,this.options)):s=i[e],s._$AI(h),e++;e<i.length&&(this._$AR(s&&s._$AB.nextSibling,e),i.length=e);}_$AR(t=this._$AA.nextSibling,i){for(this._$AP?.(!1,!0,i);t&&t!==this._$AB;){const i=t.nextSibling;t.remove(),t=i;}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t));}};let R$1 = class R{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,i,s,e,h){this.type=1,this._$AH=T$1,this._$AN=void 0,this.element=t,this.name=i,this._$AM=e,this.options=h,s.length>2||""!==s[0]||""!==s[1]?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=T$1;}_$AI(t,i=this,s,e){const h=this.strings;let o=!1;if(void 0===h)t=N$1(this,t,i,0),o=!c$1(t)||t!==this._$AH&&t!==w$1,o&&(this._$AH=t);else {const e=t;let n,r;for(t=h[0],n=0;n<h.length-1;n++)r=N$1(this,e[s+n],i,n),r===w$1&&(r=this._$AH[n]),o||=!c$1(r)||r!==this._$AH[n],r===T$1?t=T$1:t!==T$1&&(t+=(r??"")+h[n+1]),this._$AH[n]=r;}o&&!e&&this.O(t);}O(t){t===T$1?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"");}};let k$1 = class k extends R$1{constructor(){super(...arguments),this.type=3;}O(t){this.element[this.name]=t===T$1?void 0:t;}};let H$1 = class H extends R$1{constructor(){super(...arguments),this.type=4;}O(t){this.element.toggleAttribute(this.name,!!t&&t!==T$1);}};let I$1 = class I extends R$1{constructor(t,i,s,e,h){super(t,i,s,e,h),this.type=5;}_$AI(t,i=this){if((t=N$1(this,t,i,0)??T$1)===w$1)return;const s=this._$AH,e=t===T$1&&s!==T$1||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,h=t!==T$1&&(s===T$1||e);e&&this.element.removeEventListener(this.name,this,s),h&&this.element.addEventListener(this.name,this,t),this._$AH=t;}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t);}};let L$1 = class L{constructor(t,i,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=i,this.options=s;}get _$AU(){return this._$AM._$AU}_$AI(t){N$1(this,t);}};const Z$1=t$2.litHtmlPolyfillSupport;Z$1?.(V$1,M$1),(t$2.litHtmlVersions??=[]).push("3.1.0");const j$1=(t,i,s)=>{const e=s?.renderBefore??i;let h=e._$litPart$;if(void 0===h){const t=s?.renderBefore??null;e._$litPart$=h=new M$1(i.insertBefore(l$1(),t),t,void 0,s??{});}return h._$AI(t),h};

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let s$1 = class s extends b$1{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const i=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=j$1(i,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return w$1}};s$1._$litElement$=!0,s$1[("finalized")]=!0,globalThis.litElementHydrateSupport?.({LitElement:s$1});const r$1=globalThis.litElementPolyfillSupport;r$1?.({LitElement:s$1});(globalThis.litElementVersions??=[]).push("4.0.0");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$1={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},e$2=t=>(...e)=>({_$litDirective$:t,values:e});let i$1 = class i{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i;}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};

const t=2147483647,n=36,o$1=/[^\0-\x7F]/,r=/[\x2E\u3002\uFF0E\uFF61]/g,e$1={overflow:"Overflow: input needs wider integers to process","not-basic":"Illegal input >= 0x80 (not a basic code point)","invalid-input":"Invalid input"},i=Math.floor,s=String.fromCharCode;function l(t){throw new RangeError(e$1[t])}function a(t){const n=[];let o=0;const r=t.length;for(;o<r;){const e=t.charCodeAt(o++);if(e>=55296&&e<=56319&&o<r){const r=t.charCodeAt(o++);56320==(64512&r)?n.push(((1023&e)<<10)+(1023&r)+65536):(n.push(e),o--);}else n.push(e);}return n}const c=t=>String.fromCodePoint(...t),f=function(t,n){return t+22+75*(t<26)-((0!=n)<<5)},u=function(t,o,r){let e=0;for(t=r?i(t/700):t>>1,t+=i(t/o);t>455;e+=n)t=i(t/35);return i(e+36*t/(t+38))},h=function(o){const r=[],e=o.length;let s=0,a=128,c=72,f=o.lastIndexOf("-");f<0&&(f=0);for(let t=0;t<f;++t)o.charCodeAt(t)>=128&&l("not-basic"),r.push(o.charCodeAt(t));for(let d=f>0?f+1:0;d<e;){const f=s;for(let r=1,a=n;;a+=n){d>=e&&l("invalid-input");const f=(h=o.charCodeAt(d++))>=48&&h<58?h-48+26:h>=65&&h<91?h-65:h>=97&&h<123?h-97:n;f>=n&&l("invalid-input"),f>i((t-s)/r)&&l("overflow"),s+=f*r;const u=a<=c?1:a>=c+26?26:a-c;if(f<u)break;const m=n-u;r>i(t/m)&&l("overflow"),r*=m;}const m=r.length+1;c=u(s-f,m,0==f),i(s/m)>t-a&&l("overflow"),a+=i(s/m),s%=m,r.splice(s++,0,a);}var h;return String.fromCodePoint(...r)},d=function(e){return function(t,n){const o=t.split("@");let e="";o.length>1&&(e=o[0]+"@",t=o[1]);const i=function(t,n){const o=[];let r=t.length;for(;r--;)o[r]=n(t[r]);return o}((t=t.replace(r,".")).split("."),n).join(".");return e+i}(e,(function(r){return o$1.test(r)?"xn--"+function(o){const r=[],e=(o=a(o)).length;let c=128,h=0,d=72;for(const t of o)t<128&&r.push(s(t));const m=r.length;let p=m;for(m&&r.push("-");p<e;){let e=t;for(const t of o)t>=c&&t<e&&(e=t);const a=p+1;e-c>i((t-h)/a)&&l("overflow"),h+=(e-c)*a,c=e;for(const e of o)if(e<c&&++h>t&&l("overflow"),e===c){let t=h;for(let o=n;;o+=n){const e=o<=d?1:o>=d+26?26:o-d;if(t<e)break;const l=t-e,a=n-e;r.push(s(f(e+l%a,0))),t=i(l/a);}r.push(s(f(t,0))),d=u(h,a,p===m),h=0,++p;}++h,++c;}return r.join("")}(r):r}))};let m=(t,n)=>Array(n).fill(t),p=t=>new Uint32Array(t),g=6291456,w=23068672,v=14680064,C=2097409,k=2097889,b=2097249,I=2097825,A=2097217,x=2097505,S=2097697,y=2097857,E=2106753,D=2097153,j=2097281,F=2097441,N=2097537,P=2097729,z=2097761,q=2097793,L=2097921,W=2097953,O=2097377,U=2097473,$$1=2097601,M=2097665,R=18874368,_=2097185,B=2097313,G=2097345,H=2097569,J=2097633,K=2107105,Q=2106945,T=2106977,V=2107009,X=2106657,Y=2106785,Z=10486593,tt=2106593,nt=2106561,ot=2107137,rt=2107073,et=2107201;const it=[p([v,v,v,v,v,v,v,v,v,v,v,v,v,v,v,v]),p([v,v,v,v,v,v,v,v,v,v,v,v,v,g,g,v]),p([g,g,g,g,g,g,g,g,g,g,v,v,v,v,v,v]),p([v,D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1]),p([J,M,S,P,z,q,I,y,k,L,W,v,v,v,v,v]),p([v,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,v,v,v,v,v]),p([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([Z,g,g,g,g,g,g,g,10486626,g,D,g,g,2097152,g,10486690]),p([g,g,2098145,2098177,10486818,2098273,g,g,10486914,2098369,$$1,g,2098403,2098499,2098595,g]),p([2098689,2098721,2098753,2098785,2098817,2098849,2098881,2098913,2098945,2098977,2099009,2099041,2099073,2099105,2099137,2099169]),p([2099201,2099233,2099265,2099297,2099329,2099361,2099393,g,2099425,2099457,2099489,2099521,2099553,2099585,2099617,4196802]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([2099713,g,2099745,g,2099777,g,2099809,g,2099841,g,2099873,g,2099905,g,2099937,g]),p([2099969,g,2100001,g,2100033,g,2100065,g,2100097,g,2100129,g,2100161,g,2100193,g]),p([2100225,g,2100257,g,2100289,g,2100321,g,2100353,g,2100385,g,2100417,g,2100449,g]),p([2100482,g,2097410,2097410,2100545,g,2100577,g,g,2100609,g,2100641,g,2100673,g,2100706]),p([2100706,2100769,g,2100801,g,2100833,g,2100865,g,2100898,2100961,g,2100993,g,2101025,g]),p([2101057,g,2101089,g,2101121,g,2101153,g,2101185,g,2101217,g,2101249,g,2101281,g]),p([2101313,g,2101345,g,2101377,g,2101409,g,2101441,g,2101473,g,2101505,g,2101537,g]),p([2101569,g,2101601,g,2101633,g,2101665,g,2101697,2101729,g,2101761,g,2101793,g,P]),p([g,2101825,2101857,g,2101889,g,2101921,2101953,g,2101985,2102017,2102049,g,g,2102081,2102113]),p([2102145,2102177,g,2102209,2102241,g,2102273,2102305,2102337,g,g,g,2102369,2102401,g,2102433]),p([2102465,g,2102497,g,2102529,g,2102561,2102593,g,2102625,g,g,2102657,g,2102689,2102721]),p([g,2102753,2102785,2102817,g,2102849,g,2102881,2102913,g,g,g,2102945,g,g,g]),p([g,g,g,g,2102978,2102978,2102978,2103042,2103042,2103042,2103106,2103106,2103106,2103169,g,2103201]),p([g,2103233,g,2103265,g,2103297,g,2103329,g,2103361,g,2103393,g,g,2103425,g]),p([2103457,g,2103489,g,2103521,g,2103553,g,2103585,g,2103617,g,2103649,g,2103681,g]),p([g,2103714,2103714,2103714,2103777,g,2103809,2103841,2103873,g,2103905,g,2103937,g,2103969,g]),p([2104001,g,2104033,g,2104065,g,2104097,g,2104129,g,2104161,g,2104193,g,2104225,g]),p([2104257,g,2104289,g,2104321,g,2104353,g,2104385,g,2104417,g,2104449,g,2104481,g]),p([2104513,g,2104545,g,2104577,g,2104609,g,2104641,g,2104673,g,2104705,g,2104737,g]),p([2104769,g,2104801,g,g,g,g,g,g,g,2104833,2104865,g,2104897,2104929,g]),p([g,2104961,g,2104993,2105025,2105057,2105089,g,2105121,g,2105153,g,2105185,g,2105217,g]),p([O,2105249,F,S,2105281,2105313,2105345,y,L,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,10493986,10494050,10494114,10494178,10494242,10494306,g,g]),p([2102241,x,P,k,2105761,g,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([18883009,18875457,w,18883041,18883074,18883137,w,w,w,w,w,w,w,w,w,R]),p([2105953,g,2105985,g,2106017,g,2106049,g,0,0,10494690,g,g,g,10494753,2106177]),p([0,0,0,0,10486818,10494819,2106305,2100737,2106337,2106369,2106401,0,2106433,0,2106465,2106497]),p([g,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913]),p([Q,T,0,V,2107041,rt,K,ot,2107169,et,2107233,2107265,g,g,g,g]),p([g,g,4204161,g,g,g,g,g,g,g,g,g,g,g,g,2107297]),p([nt,E,rt,2106465,2107265,K,Q,g,2107329,g,2107361,g,2107393,g,2107425,g]),p([2107457,g,2107489,g,2107521,g,2107553,g,2107585,g,2107617,g,2107649,g,2107681,g]),p([Y,T,V,g,E,X,g,2107713,g,V,2107745,g,g,2107777,2107809,2107841]),p([2107873,2107905,2107937,2107969,2108001,2108033,2108065,2108097,2108129,2108161,2108193,2108225,2108257,2108289,2108321,2108353]),p([2108385,2108417,2108449,2108481,2108513,2108545,2108577,2108609,2108641,2108673,2108705,2108737,2108769,2108801,2108833,2108865]),p([2108897,2108929,2108961,2108993,2109025,2109057,2109089,2109121,2109153,2109185,2109217,2109249,2109281,2109313,2109345,2109377]),p([2109409,g,2109441,g,2109473,g,2109505,g,2109537,g,2109569,g,2109601,g,2109633,g]),p([2109665,g,2109697,g,2109729,g,2109761,g,2109793,g,2109825,g,2109857,g,2109889,g]),p([2109921,g,g,w,w,w,w,w,w,w,2109953,g,2109985,g,2110017,g]),p([2110049,g,2110081,g,2110113,g,2110145,g,2110177,g,2110209,g,2110241,g,2110273,g]),p([2110305,g,2110337,g,2110369,g,2110401,g,2110433,g,2110465,g,2110497,g,2110529,g]),p([2110561,g,2110593,g,2110625,g,2110657,g,2110689,g,2110721,g,2110753,g,2110785,g]),p([0,2110817,g,2110849,g,2110881,g,2110913,g,2110945,g,2110977,g,2111009,g,g]),p([2111041,g,2111073,g,2111105,g,2111137,g,2111169,g,2111201,g,2111233,g,2111265,g]),p([2111297,g,2111329,g,2111361,g,2111393,g,2111425,g,2111457,g,2111489,g,2111521,g]),p([2111553,g,2111585,g,2111617,g,2111649,g,2111681,g,2111713,g,2111745,g,2111777,g]),p([2111809,g,2111841,g,2111873,g,2111905,g,2111937,g,2111969,g,2112001,g,2112033,g]),p([2112065,g,2112097,g,2112129,g,2112161,g,2112193,g,2112225,g,2112257,g,2112289,g]),p([2112321,g,2112353,g,2112385,g,2112417,g,2112449,g,2112481,g,2112513,g,2112545,g]),p([0,2112577,2112609,2112641,2112673,2112705,2112737,2112769,2112801,2112833,2112865,2112897,2112929,2112961,2112993,2113025]),p([2113057,2113089,2113121,2113153,2113185,2113217,2113249,2113281,2113313,2113345,2113377,2113409,2113441,2113473,2113505,2113537]),p([2113569,2113601,2113633,2113665,2113697,2113729,2113761,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,2113794,g,g,g,0,0,g,g,g]),p([0,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,g,w]),p([g,w,w,g,w,w,g,w,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,0,g]),p([g,g,g,g,g,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,g,0,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,w,w,w,w,w]),p([w,g,g,g,g,2113858,2113922,2113986,2114050,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,w,w,w,w,w,w,w,0,g,w]),p([w,w,w,w,w,g,g,w,w,g,w,w,w,w,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,0,0]),p([g,w,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,0,0,g,g,g]),p([g,g,g,g,g,g,w,w,w,w,w,w,w,w,w,w]),p([w,g,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,g,g,g,g,g,g,g,0,0,w,g,g]),p([g,g,g,g,g,g,w,w,w,w,g,w,w,w,w,w]),p([w,w,w,w,g,w,w,w,g,w,w,w,w,w,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,0]),p([g,g,g,g,g,g,g,g,g,w,w,w,0,0,g,0]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,w,w,w,w,w,w,w,w]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,w,w,w]),p([w,w,0,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,g,w,w]),p([g,w,w,w,w,w,w,w,2114114,2114178,2114242,2114306,2114370,2114434,2114498,2114562]),p([g,g,w,w,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,0,g,g,g,g,g,g,g,g,0,0,g]),p([g,0,0,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,0,g,g,g,g,g,g]),p([g,0,g,0,0,0,g,g,g,g,0,0,w,g,w,w]),p([w,w,w,w,w,0,0,w,w,0,0,w,w,w,g,0]),p([0,0,0,0,0,0,0,w,0,0,0,0,2114626,2114690,0,2114754]),p([g,g,w,w,0,0,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,w,0]),p([0,w,w,w,0,g,g,g,g,g,g,0,0,0,0,g]),p([g,0,g,2114818,0,g,2114882,0,g,g,0,0,w,0,w,w]),p([w,w,w,0,0,0,0,w,w,0,0,w,w,w,0,0]),p([0,w,0,0,0,0,0,0,0,2114946,2115010,2115074,g,0,2115138,0]),p([w,w,g,g,g,w,g,0,0,0,0,0,0,0,0,0]),p([0,w,w,w,0,g,g,g,g,g,g,g,g,g,0,g]),p([g,g,0,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,0,g,g,0,g,g,g,g,g,0,0,w,g,w,w]),p([w,w,w,w,w,w,0,w,w,w,0,w,w,w,0,0]),p([g,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,0,0,0,0,0,0,0,g,w,w,w,w,w,w]),p([0,w,w,w,0,g,g,g,g,g,g,g,g,0,0,g]),p([w,w,w,w,w,0,0,w,w,0,0,w,w,w,0,0]),p([0,0,0,0,0,w,w,w,0,0,0,0,2115202,2115266,0,g]),p([g,g,g,g,g,g,g,g,0,0,0,0,0,0,0,0]),p([0,0,w,g,0,g,g,g,g,g,g,0,0,0,g,g]),p([g,0,g,g,g,g,0,0,0,g,g,0,g,0,g,g]),p([0,0,0,g,g,0,0,0,g,g,g,0,0,0,g,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,w,w]),p([w,w,w,0,0,0,w,w,w,0,w,w,w,w,0,0]),p([g,0,0,0,0,0,0,w,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,g,g,g,g,g,g,g,g,0,g,g]),p([g,0,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,w,g,w,w]),p([w,w,w,w,w,0,w,w,w,0,w,w,w,w,0,0]),p([0,0,0,0,0,w,w,0,g,g,g,0,0,g,0,0]),p([0,0,0,0,0,0,0,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,g,g,g,g,g,g,g,g,g,0,g,g]),p([g,g,g,g,0,g,g,g,g,g,0,0,w,g,w,w]),p([0,0,0,0,0,w,w,0,0,0,0,0,0,g,g,0]),p([0,g,g,w,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,0,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,w,w,g,w,w]),p([w,w,w,w,w,0,w,w,w,0,w,w,w,w,g,g]),p([0,0,0,0,g,g,g,w,g,g,g,g,g,g,g,g]),p([0,w,w,w,0,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,0,0,g,g,g,g,g,g]),p([g,g,0,g,g,g,g,g,g,g,g,g,0,g,0,0]),p([g,g,g,g,g,g,g,0,0,0,w,0,0,0,0,w]),p([w,w,w,w,w,0,w,0,w,w,w,w,w,w,w,w]),p([0,0,w,w,g,0,0,0,0,0,0,0,0,0,0,0]),p([0,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,g,2115330,w,w,w,w,w,w,w,0,0,0,0,g]),p([g,g,g,g,g,g,g,w,w,w,w,w,w,w,w,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,0,0,0]),p([0,g,g,0,g,0,g,g,g,g,g,0,g,g,g,g]),p([g,g,g,g,0,g,0,g,g,g,g,g,g,g,g,g]),p([g,w,g,2115394,w,w,w,w,w,w,w,w,w,g,0,0]),p([g,g,g,g,g,0,g,0,w,w,w,w,w,w,w,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,2115458,2115522,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,2115585,g,g,g]),p([g,g,g,g,g,g,g,g,w,w,g,g,g,g,g,g]),p([g,g,g,g,g,w,g,w,g,w,g,g,g,g,w,w]),p([g,g,g,2115618,g,g,g,g,0,g,g,g,g,2115682,g,g]),p([g,g,2115746,g,g,g,g,2115810,g,g,g,g,2115874,g,g,g]),p([g,g,g,g,g,g,g,g,g,2115938,g,g,g,0,0,0]),p([0,w,w,18893218,w,18893282,18893346,18893411,18893506,18893571,w,w,w,w,w,w]),p([w,18893442,w,w,w,g,w,w,g,g,g,g,g,w,w,w]),p([w,w,w,18893666,w,w,w,w,0,w,w,w,w,18893730,w,w]),p([w,w,18893794,w,w,w,w,18893858,w,w,w,w,18893922,w,w,w]),p([w,w,w,w,w,w,w,w,w,18893986,w,w,w,0,g,g]),p([g,g,g,g,g,g,w,g,g,g,g,g,g,0,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,g]),p([g,g,g,g,g,g,w,w,w,w,g,g,g,g,w,w]),p([w,g,w,w,w,g,g,w,w,w,w,w,w,w,g,g]),p([g,w,w,w,w,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,w,w,w,w,w,w,w,w,w,w,w,w,g,w]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,w,g,g]),p([0,0,0,0,0,0,0,2116833,0,0,0,0,0,2116865,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,2116897,g,g,g]),p([g,g,g,g,g,g,g,g,g,0,g,g,g,g,0,0]),p([g,g,g,g,g,g,g,0,g,0,g,g,g,g,0,0]),p([g,0,g,g,g,g,0,0,g,g,g,g,g,g,g,0]),p([g,0,g,g,g,g,0,0,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,w,w,w]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,2116929,2116961,2116993,2117025,2117057,2117089,0,0]),p([g,g,g,g,g,g,g,g,g,0,0,0,0,0,0,0]),p([g,g,w,w,w,w,0,0,0,0,0,0,0,0,0,g]),p([g,g,w,w,w,g,g,0,0,0,0,0,0,0,0,0]),p([g,g,w,w,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,0,g,g]),p([g,0,w,w,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,16777216,16777216,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,w,0,0]),p([g,g,g,g,g,g,0,g,g,g,g,R,R,R,0,R]),p([g,g,g,g,g,w,w,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,w,g,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,w,w,w,0,0,0,0]),p([g,0,0,0,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,g,g]),p([g,g,g,g,g,g,g,w,w,w,w,w,0,0,g,g]),p([g,g,g,g,g,w,w,w,w,w,w,w,w,w,w,0]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,0,0,w]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,0]),p([w,w,w,w,w,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,g,g,g,g,g,g,g,g,0,0,0]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,g,g,0]),p([w,w,w,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,w,w,w,w,w,w,w,w,w,w,g,g]),p([w,w,w,w,0,0,0,0,0,0,0,0,g,g,g,g]),p([w,w,w,w,w,w,w,w,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,g,g,g]),p([2108449,2108513,2108833,2108929,2108961,2108961,2109217,2109441,2117121,0,0,0,0,0,0,0]),p([2117153,2117185,2117217,2117249,2117281,2117313,2117345,2117377,2117409,2117441,2117473,2117505,2116897,2117537,2117569,2117601]),p([2117633,2117665,2117697,2117729,2117761,2117793,2117825,2117857,2117889,2117921,2117953,2117985,2118017,2118049,2118081,2118113]),p([2118145,2118177,2118209,2118241,2118273,2118305,2118337,2118369,2118401,2118433,2118465,0,0,2118497,2118529,2118561]),p([w,w,w,g,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,w,g,g,g,g,w,g,g]),p([g,g,g,g,w,g,g,w,w,w,g,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,D,2098881,_,g]),p([b,j,2102081,G,O,C,F,U,x,N,H,g,$$1,2104545,J,S]),p([z,q,y,D,2118593,2118625,2118657,_,b,j,2102113,2102145,2118689,G,g,U]),p([N,2100961,$$1,2101921,2118721,2118753,J,z,q,2118785,2102369,I,2118817,nt,tt,2106625]),p([K,ot,C,S,q,I,nt,tt,T,K,ot,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,2108801,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,2118849,A,2118881,2099201,2118689]),p([B,2118913,2118945,2118977,2102305,2102273,2119009,2119041,2119073,2119105,2119137,2119169,2119201,2119233,2102401,2119265]),p([2119297,2102433,2119329,2119361,2102625,2119393,2105025,2102753,2119425,2102785,2105057,W,2119457,2119489,2102881,E]),p([2119521,g,2119553,g,2119585,g,2119617,g,2119649,g,2119681,g,2119713,g,2119745,g]),p([2119777,g,2119809,g,2119841,g,2119873,g,2119905,g,2119937,g,2119969,g,2120001,g]),p([2120033,g,2120065,g,2120097,g,2120129,g,2120161,g,2120193,g,2120225,g,2120257,g]),p([2120289,g,2120321,g,2120353,g,2120385,g,2120417,g,2120449,g,2120481,g,2120513,g]),p([2120545,g,2120577,g,2120609,g,2120641,g,2120673,g,2120705,g,2120737,g,2120769,g]),p([2120801,g,2120833,g,2120865,g,2120897,g,2120929,g,2120961,g,2120993,g,2121025,g]),p([2121057,g,2121089,g,2121121,g,2121153,g,2121185,g,2121217,g,2121249,g,2121281,g]),p([2121313,g,2121345,g,2121377,g,2121409,g,2121441,g,2121473,g,2121505,g,2121537,g]),p([2121569,g,2121601,g,2121633,g,2121665,g,2121697,g,2121729,g,2121761,g,2121793,g]),p([2121825,g,2121857,g,2121889,g,g,g,g,g,2121922,2121057,g,g,2121985,g]),p([2122017,g,2122049,g,2122081,g,2122113,g,2122145,g,2122177,g,2122209,g,2122241,g]),p([2122273,g,2122305,g,2122337,g,2122369,g,2122401,g,2122433,g,2122465,g,2122497,g]),p([2122529,g,2122561,g,2122593,g,2122625,g,2122657,g,2122689,g,2122721,g,2122753,g]),p([2122785,g,2122817,g,2122849,g,2122881,g,2122913,g,2122945,g,2122977,g,2123009,g]),p([2123041,g,2123073,g,2123105,g,2123137,g,2123169,g,2123201,g,2123233,g,2123265,g]),p([2123297,g,2123329,g,2123361,g,2123393,g,2123425,g,2123457,g,2123489,g,2123521,g]),p([g,g,g,g,g,g,g,g,2123553,2123585,2123617,2123649,2123681,2123713,2123745,2123777]),p([g,g,g,g,g,g,0,0,2123809,2123841,2123873,2123905,2123937,2123969,0,0]),p([g,g,g,g,g,g,g,g,2124001,2124033,2124065,2124097,2124129,2124161,2124193,2124225]),p([g,g,g,g,g,g,g,g,2124257,2124289,2124321,2124353,2124385,2124417,2124449,2124481]),p([g,g,g,g,g,g,0,0,2124513,2124545,2124577,2124609,2124641,2124673,0,0]),p([g,g,g,g,g,g,g,g,0,2124705,0,2124737,0,2124769,0,2124801]),p([g,g,g,g,g,g,g,g,2124833,2124865,2124897,2124929,2124961,2124993,2125025,2125057]),p([g,2106305,g,2106337,g,2106369,g,2106401,g,2106433,g,2106465,g,2106497,0,0]),p([2125090,2125154,2125218,2125282,2125346,2125410,2125474,2125538,2125090,2125154,2125218,2125282,2125346,2125410,2125474,2125538]),p([2125602,2125666,2125730,2125794,2125858,2125922,2125986,2126050,2125602,2125666,2125730,2125794,2125858,2125922,2125986,2126050]),p([2126114,2126178,2126242,2126306,2126370,2126434,2126498,2126562,2126114,2126178,2126242,2126306,2126370,2126434,2126498,2126562]),p([g,g,2126626,2126690,2126754,0,g,2126818,2126881,2126913,2126625,2106305,2126690,10515554,2105921,10515554]),p([10515618,10515683,2127170,2127234,2127298,0,g,2127362,2127425,2106337,2127169,2106369,2127234,10516067,10516163,10516259]),p([g,g,g,2127745,0,0,g,g,2127777,2127809,2127841,2106401,0,10516483,10516579,10516675]),p([g,g,g,2128161,g,g,g,g,2128193,2128225,2128257,2106465,2128289,10516931,10494819,10517025]),p([0,0,2128450,2128514,2128578,0,g,2128642,2128705,2106433,2128449,2106497,2128514,10486818,10516482,0]),p([Z,Z,Z,Z,Z,Z,Z,Z,Z,Z,Z,2097152,4194304,4194304,0,0]),p([g,2128737,g,g,g,g,g,10517378,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,g,0,0,0,0,0,0,0,Z]),p([g,g,g,2128834,2128899,g,2128994,2129059,g,g,g,g,10517762,g,10517826,g]),p([g,g,g,g,g,g,g,10517890,10517954,10518018,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,2128836,g,g,g,g,g,g,g,Z]),p([2097152,0,0,0,2097152,0,0,0,0,0,0,0,0,0,0,0]),p([2129473,C,0,0,2098465,2129505,2129537,2129569,2129601,2129633,10518273,2129697,10518337,10518369,10518401,H]),p([2129473,2098369,2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633,10518273,2129697,10518337,10518369,10518401,0]),p([D,j,$$1,k,2102113,O,U,x,N,H,J,P,z,0,0,0]),p([g,g,g,g,g,g,g,g,2097698,g,g,g,g,g,g,g]),p([w,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([10518435,10518531,A,2130018,g,10518691,10518787,2102145,g,2130274,G,O,O,O,O,2100321]),p([C,C,x,x,g,H,2097570,g,g,J,M,S,S,S,g,g]),p([2130338,2130403,2130498,g,W,g,et,g,W,g,U,2098849,_,A,g,j]),p([j,B,0,N,$$1,2130561,2130593,2130625,2130657,C,g,2130691,Q,tt,tt,Q]),p([2130785,g,g,g,g,b,b,j,C,F,g,g,g,g,g,g]),p([2130819,2130915,2131012,2131139,2131235,2131331,2131427,2131523,2131619,2131715,2131811,2131907,2132003,2132099,2132195,2098402]),p([C,2132290,2132355,2132450,I,2132514,2132579,2132676,2132802,k,2132866,2132931,x,A,b,N]),p([C,2132290,2132291,2132450,I,2132514,2132579,2132676,2132802,k,2132866,2132931,x,A,b,N]),p([g,g,g,0,g,g,g,g,g,2133027,g,g,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,2133122,2133187,g,2133282]),p([2133347,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,2133441,2133473,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,0,0,0,0,0,0,0,0]),p([2098369,2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633,2131074,2098370,2133506,2133570,2133634,2133698,2133762]),p([2133826,2133890,2133954,2134018,10522691,10522787,10522883,10522979,10523075,10523171,10523267,10523363,10523459,10523556,10523684,10523812]),p([10523940,10524068,10524196,10524324,10524452,10524580,10524708,10524836,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,0,10524963,10525059,10525155,10525251]),p([10525347,10525443,10525539,10525635,10525731,10525827,10525923,10526019,10526115,10526211,10526307,10526403,10526499,10526595,10526691,10526787]),p([10526883,10526979,10527075,10527171,10527267,10527363,D,_,A,b,j,B,G,O,C,F]),p([U,x,N,H,$$1,J,M,S,P,z,q,I,y,k,L,W]),p([D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1,J]),p([M,S,P,z,q,I,y,k,L,W,2129473,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,2133124,g,g,g]),p([g,g,g,g,10527459,10527554,10527523,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,2139010,g,g,g]),p([g,g,g,g,0,0,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,g,g,g,g,g,g,g,g,g]),p([2139073,2139105,2139137,2139169,2139201,2139233,2139265,2139297,2139329,2139361,2139393,2139425,2139457,2139489,2139521,2139553]),p([2139585,2139617,2139649,2139681,2139713,2139745,2139777,2139809,2139841,2139873,2139905,2139937,2139969,2140001,2140033,2140065]),p([2140097,2140129,2140161,2140193,2140225,2140257,2140289,2140321,2140353,2140385,2140417,2140449,2140481,2140513,2140545,2140577]),p([2140609,g,2140641,2140673,2140705,g,g,2140737,g,2140769,g,2140801,g,2118625,2119201,2118593]),p([2118849,g,2140833,g,g,2140865,g,g,g,g,g,g,F,I,2140897,2140929]),p([2140961,g,2140993,g,2141025,g,2141057,g,2141089,g,2141121,g,2141153,g,2141185,g]),p([2141217,g,2141249,g,2141281,g,2141313,g,2141345,g,2141377,g,2141409,g,2141441,g]),p([2141473,g,2141505,g,2141537,g,2141569,g,2141601,g,2141633,g,2141665,g,2141697,g]),p([2141729,g,2141761,g,2141793,g,2141825,g,2141857,g,2141889,g,2141921,g,2141953,g]),p([2141985,g,2142017,g,2142049,g,2142081,g,2142113,g,2142145,g,2142177,g,2142209,g]),p([2142241,g,2142273,g,2142305,g,2142337,g,2142369,g,2142401,g,2142433,g,2142465,g]),p([2142497,g,2142529,g,g,g,g,g,g,g,g,2142561,g,2142593,g,w]),p([w,w,2142625,g,0,0,0,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,g,0,0,0,0,0,g,0,0]),p([g,g,g,g,g,g,g,g,0,0,0,0,0,0,0,2142657]),p([g,0,0,0,0,0,0,0,0,0,0,0,0,0,0,w]),p([g,g,g,g,g,g,g,0,g,g,g,g,g,g,g,0]),p([g,g,g,g,g,g,g,g,g,g,0,g,g,g,g,2142689]),p([g,g,g,2142721,0,0,0,0,0,0,0,0,0,0,0,0]),p([2142753,2142785,2142817,2142849,2142881,2142913,2142945,2142977,2143009,2143041,2143073,2143105,2143137,2143169,2143201,2143233]),p([2143265,2143297,2143329,2143361,2143393,2143425,2143457,2143489,2143521,2143553,2143585,2143617,2143649,2143681,2143713,2143745]),p([2143777,2143809,2143841,2143873,2143905,2143937,2143969,2144001,2144033,2144065,2144097,2144129,2144161,2144193,2144225,2144257]),p([2144289,2144321,2144353,2144385,2144417,2144449,2144481,2144513,2144545,2144577,2144609,2144641,2144673,2144705,2144737,2144769]),p([2144801,2144833,2144865,2144897,2144929,2144961,2144993,2145025,2145057,2145089,2145121,2145153,2145185,2145217,2145249,2145281]),p([2145313,2145345,2145377,2145409,2145441,2145473,2145505,2145537,2145569,2145601,2145633,2145665,2145697,2145729,2145761,2145793]),p([2145825,2145857,2145889,2145921,2145953,2145985,2146017,2146049,2146081,2146113,2146145,2146177,2146209,2146241,2146273,2146305]),p([2146337,2146369,2146401,2146433,2146465,2146497,2146529,2146561,2146593,2146625,2146657,2146689,2146721,2146753,2146785,2146817]),p([2146849,2146881,2146913,2146945,2146977,2147009,2147041,2147073,2147105,2147137,2147169,2147201,2147233,2147265,2147297,2147329]),p([2147361,2147393,2147425,2147457,2147489,2147521,2147553,2147585,2147617,2147649,2147681,2147713,2147745,2147777,2147809,2147841]),p([2147873,2147905,2147937,2147969,2148001,2148033,2148065,2148097,2148129,2148161,2148193,2148225,2148257,2148289,2148321,2148353]),p([2148385,2148417,2148449,2148481,2148513,2148545,2148577,2148609,2148641,2148673,2148705,2148737,2148769,2148801,2148833,2148865]),p([2148897,2148929,2148961,2148993,2149025,2149057,2149089,2149121,2149153,2149185,2149217,2149249,2149281,2149313,2149345,2149377]),p([2149409,2149441,2149473,2149505,2149537,2149569,0,0,0,0,0,0,0,0,0,0]),p([Z,g,2149601,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,2149633,g,2143489,2149665,2149697,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,0,w,w,10538338,10538402,g,g,2149858]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,2149922]),p([0,0,0,0,0,g,g,g,g,g,g,g,g,g,g,g]),p([0,2149985,2150017,2150049,2150081,2150113,2150145,2150177,2150209,2150241,2150273,2150305,2150337,2150369,2150401,2150433]),p([2150465,2150497,2150529,2150561,2150593,2150625,2150657,2150689,2150721,2150753,2150785,2150817,2150849,2150881,2150913,2150945]),p([2150977,2151009,2151041,2151073,2151105,2151137,2151169,2151201,2151233,2151265,2151297,2151329,2151361,2151393,2151425,2151457]),p([2151489,2151521,2151553,2151585,0,2151617,2151649,2151681,2151713,2151745,2151777,2151809,2151841,2151873,2151905,2151937]),p([2151969,2152001,2152033,2152065,2152097,2152129,2152161,2152193,2152225,2152257,2152289,2152321,2152353,2152385,2152417,2152449]),p([2152481,2152513,2152545,2152577,2152609,2152641,2152673,2152705,2152737,2152769,2152801,2152833,2152865,2152897,2152929,0]),p([g,g,2142753,2142945,2152961,2152993,2153025,2153057,2153089,2153121,2142881,2153153,2153185,2153217,2153249,2143009]),p([g,g,g,g,0,0,0,0,0,0,0,0,0,0,0,0]),p([10541891,10541987,10542083,10542179,10542275,10542371,10542467,10542563,10542659,10542755,10542851,10542947,10543043,10543139,10543235,10543331]),p([10543427,10543523,10543619,10543715,10543811,10543907,10544003,10544099,10544195,10544291,10544387,10544483,10544579,10544676,10544804,0]),p([10544931,10545027,10545123,10545219,10545315,10545411,10545507,10545603,10545699,10545795,10545891,10545987,10546083,10546179,10546275,10546371]),p([10546467,10546563,10546659,10546755,10546851,10546947,10547043,10547139,10547235,10547331,10547427,10547523,10547619,10547715,10547811,10547907]),p([10548003,10548099,10548195,10548291,2159777,2159809,2144865,2159841,g,g,g,g,g,g,g,g]),p([2159875,2133538,2159970,2098146,2160034,2160098,2160162,2160226,2160290,2160354,2160418,2131298,2131202,2160482,2160546,2160610]),p([2149985,2150081,2150177,2150241,2150497,2150529,2150625,2150689,2150721,2150785,2150817,2150849,2150881,2150913,2154657,2154753]),p([2154849,2154945,2155041,2155137,2155233,2155329,2155425,2155521,2155617,2155713,2155809,2155905,2160674,2160738,2160801,g]),p([2142753,2142945,2152961,2152993,2156737,2156833,2156929,2143105,2157121,2143489,2145089,2145473,2145441,2145121,2148065,2143745]),p([2145025,2157985,2158081,2158177,2158273,2158369,2158465,2158561,2158657,2160833,2160865,2143937,2160897,2160929,2160961,2160993]),p([2161025,2159521,2161057,2161089,2153025,2153057,2153089,2161121,2161153,2161185,2161217,2158945,2159041,2159137,2159233,2159329]),p([2161249,2161282,2161346,2161410,2161474,2161538,2098466,2160066,2160578,2161602,2161666,2161730,2161794,2161858,2161922,2161986]),p([2162050,2162114,2162178,2162242,2162306,2162370,2162434,2162498,2162562,2162627,2162723,2162819,2162914,2162979,2163074,2163139]),p([2163233,2163265,2163297,2163329,2163361,2163393,2163425,2163457,2163489,2149921,2163521,2163553,2163585,2163617,2163649,2163681]),p([2163713,2163745,2163777,2149953,2163809,2163841,2163873,2163905,2163937,2163969,2164001,2164033,2164065,2164097,2164129,2164161]),p([2164193,2164225,2164257,2164289,2164321,2164353,2164385,2164417,2164449,2164481,2164513,2164545,2164577,2164609,2164641,2164674]),p([2164740,2164868,2164996,2165123,2165220,2165347,2165443,2165541,2165700,2165827,2165923,2166019,2166116,2166244,2166371,2166467]),p([2166562,2166627,2166724,2166852,2166978,2167045,2167206,2167397,2167107,2167557,2167717,2167876,2168003,2168099,2168195,2168292]),p([2168421,2168580,2168707,2168803,2168899,2168994,2169058,2167650,2169122,2169187,2169283,2169381,2169539,2169636,2169765,2169923]),p([2170018,2170082,2170149,2170308,2170437,2170595,2170693,2170850,2170915,2171011,2171107,2171203,2171299,2171396,2171523,2171618]),p([2171683,2171779,2171875,2171972,2172099,2172195,2172291,2172389,2172548,2172674,2172741,2172898,2172964,2167268,2173091,2173187]),p([2173283,2173380,2173506,2173571,2173668,2173794,2173861,2167459,2174018,2174082,2174146,2174210,2174274,2174338,2174402,2174466]),p([2174530,2174594,2174659,2174755,2174851,2174947,2175043,2175139,2175235,2175331,2175427,2175523,2175619,2175715,2175811,2175907]),p([2176003,2176099,2176194,2176258,2176323,2176418,2176482,2176546,2176611,2176707,2176802,2176866,2176930,2176994,2177058,2177124]),p([2176130,2177250,2177314,2177378,2177442,2177506,2177570,2177634,2177699,2177796,2177922,2177986,2178050,2178114,2178178,2178242]),p([2178306,2178371,2178467,2178275,2178563,2178658,2178722,2178786,2097474,2178850,2178914,2178978,2179042,2179106,2179170,2179235]),p([2179331,2176642,2179427,2179523,2179619,2176738,2179715,2179811,2179908,2176130,2180035,2180131,2180227,2180323,2180421,2180582]),p([2180770,2180834,2180898,2180962,2181026,2181090,2181154,2181218,2181282,2181218,2181346,2181410,2181474,2181538,2181602,2181538]),p([2181666,2181730,0,2181794,2130050,2097218,2181860,0,2181986,2182050,2182114,2176098,2182178,2182242,2179170,2182306]),p([2097506,2182370,2182435,2182530,2177570,2182595,2182691,2182786,0,2182851,2182946,2180546,2183010,2183074,2183139,2183235]),p([2183330,2183394,2183458,2183522,2183586,2183650,2183714,2183778,2183842,2183907,2184003,2184099,2184195,2184291,2184387,2184483]),p([2184579,2184675,2184771,2184867,2184963,2185059,2185155,2185251,2185347,2185443,2185539,2185635,2185731,2185827,2185923,2186019]),p([2186113,g,2186145,g,2186177,g,2186209,g,2186241,g,2117121,g,2186273,g,2186305,g]),p([2186337,g,2186369,g,2186401,g,2186433,g,2186465,g,2186497,g,2186529,g,2186561,g]),p([2186593,g,2186625,g,2186657,g,2186689,g,2186721,g,2186753,g,2186785,g,g,w]),p([w,w,w,g,w,w,w,w,w,w,w,w,w,w,g,g]),p([2186817,g,2186849,g,2186881,g,2186913,g,2186945,g,2186977,g,2187009,g,2187041,g]),p([2187073,g,2187105,g,2187137,g,2187169,g,2187201,g,2187233,g,2109217,2109281,w,w]),p([w,w,g,g,g,g,g,g,0,0,0,0,0,0,0,0]),p([g,g,2187265,g,2187297,g,2187329,g,2187361,g,2187393,g,2187425,g,2187457,g]),p([g,g,2187489,g,2187521,g,2187553,g,2187585,g,2187617,g,2187649,g,2187681,g]),p([2187713,g,2187745,g,2187777,g,2187809,g,2187841,g,2187873,g,2187905,g,2187937,g]),p([2187969,g,2188001,g,2188033,g,2188065,g,2188097,g,2188129,g,2188161,g,2188193,g]),p([2188225,g,2188257,g,2188289,g,2188321,g,2188353,g,2188385,g,2188417,g,2188449,g]),p([2188449,g,g,g,g,g,g,g,g,2188481,g,2188513,g,2188545,2188577,g]),p([2188609,g,2188641,g,2188673,g,2188705,g,g,g,g,2188737,g,2118977,g,g]),p([2188769,g,2188801,g,g,g,2188833,g,2188865,g,2188897,g,2188929,g,2188961,g]),p([2188993,g,2189025,g,2189057,g,2189089,g,2189121,g,2105249,2118689,2118945,2189153,2119009,g]),p([2189185,2189217,2119073,2189249,2189281,g,2189313,g,2189345,g,2189377,g,2189409,g,2189441,g]),p([2189473,g,2189505,g,2189537,2119361,2189569,2189601,g,2189633,g,0,0,0,0,0]),p([2189665,g,0,g,0,g,2189697,g,2189729,g,0,0,0,0,0,0]),p([0,0,A,B,M,2189761,g,g,2100321,2101089,g,g,g,g,g,g]),p([g,g,w,g,g,g,w,g,g,g,g,w,g,g,g,g]),p([g,g,g,w,w,w,w,w,g,g,g,g,w,0,0,0]),p([w,w,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,0,0,0,0,0,0,0,0,g,g]),p([w,w,g,g,g,g,g,g,g,g,g,g,g,g,g,w]),p([g,g,g,g,g,g,w,w,w,w,w,w,w,w,g,g]),p([g,g,g,g,g,g,g,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,0,0,0,0,0,0,0,0,0,0,0,g]),p([g,g,g,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,g,g,g,g,g,g,g,g,g,g,g,g,g,0,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,g,g]),p([g,g,g,g,g,w,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,0,0,0,0,0,0,0,0,0]),p([g,g,g,w,g,g,g,g,g,g,g,g,w,w,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,w,w,w,g,g]),p([w,g,w,w,w,g,g,w,w,g,g,g,g,g,w,w]),p([g,w,g,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,w,w,0,0,0,0,0,0,0,0,0]),p([0,g,g,g,g,g,g,0,0,g,g,g,g,g,g,0]),p([0,g,g,g,g,g,g,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,2187329,2189793,2140641,2189825]),p([g,g,g,g,g,g,g,g,g,2189857,g,g,0,0,0,0]),p([2189889,2189921,2189953,2189985,2190017,2190049,2190081,2190113,2190145,2190177,2190209,2190241,2190273,2190305,2190337,2190369]),p([2190401,2190433,2190465,2190497,2190529,2190561,2190593,2190625,2190657,2190689,2190721,2190753,2190785,2190817,2190849,2190881]),p([2190913,2190945,2190977,2191009,2191041,2191073,2191105,2191137,2191169,2191201,2191233,2191265,2191297,2191329,2191361,2191393]),p([2191425,2191457,2191489,2191521,2191553,2191585,2191617,2191649,2191681,2191713,2191745,2191777,2191809,2191841,2191873,2191905]),p([2191937,2191969,2192001,2192033,2192065,2192097,2192129,2192161,2192193,2192225,2192257,2192289,2192321,2192353,2192385,2192417]),p([g,g,g,w,w,w,w,w,w,w,w,g,w,w,0,0]),p([g,g,g,g,g,g,g,0,0,0,0,g,g,g,g,g]),p([2192449,2192481,2147809,2192513,2192545,2192577,2192609,2149537,2149537,2192641,2148065,2192673,2192705,2192737,2192769,2192801]),p([2192833,2192865,2192897,2192929,2192961,2192993,2193025,2193057,2193089,2193121,2193153,2193185,2193217,2193249,2193281,2193313]),p([2193345,2193377,2193409,2193441,2193473,2193505,2193537,2193569,2193601,2193633,2193665,2193697,2193729,2193761,2193793,2193825]),p([2193857,2193889,2193921,2193953,2146721,2193985,2194017,2194049,2194081,2194113,2194145,2194177,2194209,2194241,2194273,2194305]),p([2149057,2194337,2194369,2194401,2194433,2194465,2194497,2194529,2194561,2194593,2194625,2194657,2194689,2194721,2194753,2194785]),p([2194817,2194849,2194881,2194913,2194945,2194977,2195009,2195041,2195073,2195105,2195137,2195169,2192961,2195201,2195233,2195265]),p([2195297,2195329,2195361,2195393,2195425,2195457,2195489,2195521,2195553,2195585,2195617,2195649,2195681,2195713,2195745,2195777]),p([2195809,2147873,2195841,2195873,2195905,2195937,2195969,2196001,2196033,2196065,2196097,2196129,2196161,2196193,2196225,2196257]),p([2196289,2143937,2196321,2196353,2196385,2196417,2196449,2196481,2196513,2196545,2143329,2196577,2196609,2196641,2196673,2196705]),p([2196737,2196769,2196801,2196833,2196865,2196897,2196929,2196961,2196993,2197025,2197057,2197089,2197121,2197153,2197185,2197217]),p([2197249,2195777,2197281,2197313,2197345,2197377,2197409,2197441,2164673,2197473,2195265,2197505,2197537,2197569,2197601,2197633]),p([2197665,2197697,2197729,2197761,2197793,2197825,2197857,2197889,2197921,2197953,2197985,2198017,2198049,2198081,2198113,2192961]),p([2198145,2198177,2198209,2198241,2149505,2198273,2198305,2198337,2198369,2198401,2198433,2198465,2198497,2198529,2198561,2198593]),p([2198625,2156833,2198657,2198689,2198721,2198753,2198785,2198817,2198849,2198881,2198913,2195329,2198945,2198977,2199009,2199041]),p([2199073,2199105,2199137,2199169,2199201,2199233,2199265,2199297,2199329,2148033,2199361,2199393,2199425,2199457,2199489,2199521]),p([2199553,2199585,2199617,2199649,2199681,2199713,2199745,2146465,2199777,2199809,2199841,2199873,2199905,2199937,2199969,2200001]),p([2200033,2200065,2200097,2200129,2200161,2200193,2200225,2200257,2147329,2200289,2147425,2200321,2200353,2200385,g,g]),p([2200417,g,2200449,g,g,2200481,2200513,2200545,2200577,2200609,2200641,2200673,2200705,2200737,2146689,g]),p([2200769,g,2200801,g,g,2200833,2200865,g,g,g,2200897,2200929,2200961,2200993,2201025,2201057]),p([2201089,2201121,2201153,2201185,2201217,2201249,2201281,2201313,2201345,2201377,2201409,2201441,2144161,2201473,2201505,2201537]),p([2201569,2201601,2201633,2201665,2201697,2201729,2201761,2201793,2201825,2201857,2201889,2201921,2158177,2201953,2201985,2202017]),p([2202049,2158561,2202081,2202113,2202145,2202177,2202209,2196929,2202241,2202273,2202305,2202337,2202369,2202401,2202401,2202433]),p([2202465,2202497,2202529,2202561,2202593,2202625,2202657,2200833,2202689,2202721,2202753,2202785,2202818,2202881,0,0]),p([2202913,2202945,2202977,2203009,2203041,2203073,2203105,2203137,2201281,2203169,2203201,2203233,2200417,2203265,2203297,2203329]),p([2203361,2203393,2203425,2203457,2203489,2203521,2203553,2203585,2203617,2201537,2203649,2201569,2203681,2203713,2203745,2203777]),p([2203809,2200449,2193633,2203841,2203873,2145217,2195809,2198433,2203905,2203937,2201793,2203969,2201825,2204001,2204033,2204065]),p([2200513,2204097,2204129,2204161,2204193,2204225,2200545,2204257,2204289,2204321,2204353,2204385,2204417,2202209,2204449,2204481]),p([2196929,2204513,2202337,2204545,2204577,2204609,2204641,2204673,2202497,2204705,2200801,2204737,2202529,2195201,2204769,2202561]),p([2204801,2202625,2204833,2204865,2204897,2204929,2204961,2202689,2200705,2204993,2202721,2205025,2202753,2205057,2149537,2205090]),p([2205154,2205218,2205281,2205313,2205345,2205378,2205442,2205506,2205569,2205601,0,0,0,0,0,0]),p([2205634,2205698,2205762,2205667,2205827,2097730,2097730,0,0,0,0,0,0,0,0,0]),p([0,0,0,2205922,2205986,2206050,2206114,2206178,0,0,0,0,0,2206242,w,2206306]),p([2206369,2130561,2130657,2206401,2206433,2206465,2206497,2206529,2206561,10518273,2206594,2206658,2206723,2206819,2206914,2206978]),p([2207042,2207106,2207170,2207234,2207298,2207362,2207426,0,2207490,2207554,2207618,2207682,2207746,0,2207810,0]),p([2207874,2207938,0,2208002,2208066,0,2208130,2208194,2208258,2206722,2208322,2208386,2208450,2208514,2208578,2208642]),p([2208705,2208705,2208737,2208737,2208737,2208737,2208769,2208769,2208769,2208769,2208801,2208801,2208801,2208801,2208833,2208833]),p([2208833,2208833,2208865,2208865,2208865,2208865,2208897,2208897,2208897,2208897,2208929,2208929,2208929,2208929,2208961,2208961]),p([2208961,2208961,2208993,2208993,2208993,2208993,2209025,2209025,2209025,2209025,2209057,2209057,2209057,2209057,2209089,2209089]),p([2209089,2209089,2209121,2209121,2209153,2209153,2209185,2209185,2209217,2209217,2209249,2209249,2209281,2209281,2209313,2209313]),p([2209313,2209313,2209345,2209345,2209345,2209345,2209377,2209377,2209377,2209377,2209409,2209409,2209409,2209409,2209441,2209441]),p([2209473,2209473,2209473,2209473,2209505,2209505,2209537,2209537,2209537,2209537,2209569,2209569,2209569,2209569,2209601,2209601]),p([2209633,2209633,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,2209665,2209665,2209665,2209665,2113985,2113985,2209697,2209697,2209729,2209729,2113986,2209761,2209761]),p([2209793,2209793,2209825,2209825,2209857,2209857,2209857,2209857,2209889,2209889,2209922,2209922,2209986,2209986,2210050,2210050]),p([2210114,2210114,2210178,2210178,2210242,2210242,2210306,2210306,2210306,2210370,2210370,2210370,2210433,2210433,2210433,2210433]),p([2210466,2210530,2210594,2210370,2210658,2210722,2210786,2210850,2210914,2210978,2211042,2211106,2211170,2211234,2211298,2211362]),p([2211426,2211490,2211554,2211618,2211682,2211746,2211810,2211778,2211874,2211938,2212002,2212066,2212130,2212194,2212258,2212322]),p([2212386,2212450,2212514,2212578,2212642,2212706,2212770,2212834,2212898,2212962,2213026,2213090,2213154,2213218,2213282,2213346]),p([2213410,2213474,2213538,2213602,2213666,2213730,2213794,2213858,2213922,2213986,2214050,2214114,2214178,2214242,2214306,2214370]),p([2214434,2214498,2214562,2214626,2214690,2214754,2211842,2211906,2214818,2214882,2214946,2215010,2215074,2215138,2215202,2215266]),p([2215330,2215394,2215458,2215522,2215586,2211714,2215650,2215714,2214722,2215778,2215618,2215842,2215906,2215970,10604643,10604739]),p([10604835,10604931,10605027,10605123,2216610,2216674,2210594,2216738,2210370,2210658,2216802,2216866,2210914,2216930,2210978,2211042]),p([2216994,2217058,2211298,2217122,2211362,2211426,2217186,2217250,2211554,2217314,2211618,2211682,2213474,2213538,2213730,2213794]),p([2213858,2214114,2214178,2214242,2214306,2214562,2214626,2214690,2217378,2214818,2217442,2217506,2215202,2217570,2215266,2215330]),p([2215970,2217634,2217698,2214722,2214978,2215778,2215618,2210466,2210530,2217762,2210594,2217826,2210722,2210786,2210850,2210914]),p([2217890,2211106,2211170,2211234,2211298,2217954,2211554,2211746,2211810,2211778,2211874,2211938,2212066,2212130,2212194,2212258]),p([2212322,2212386,2218018,2212450,2212514,2212578,2212642,2212706,2212770,2212898,2212962,2213026,2213090,2213154,2213218,2213282]),p([2213346,2213410,2213602,2213666,2213922,2213986,2214050,2214114,2214178,2214370,2214434,2214498,2214562,2218082,2214754,2211842]),p([2211906,2214818,2215010,2215074,2215138,2215202,2218146,2215394,2215458,2218210,2211714,2215650,2215714,2214722,2215362,2210594]),p([2217826,2210914,2217890,2211298,2217954,2211554,2218274,2212322,2218338,2218402,2218466,2214114,2214178,2214562,2215202,2218146]),p([2214722,2215362,2218531,2218627,2218723,2218818,2218882,2218946,2219010,2219074,2219138,2219202,2219266,2219330,2219394,2219458]),p([2215682,2219522,2219586,2219650,2215746,2219714,2219778,2219842,2219906,2219970,2220034,2220098,2218402,2220162,2220226,2220290]),p([2220354,2218818,2218882,2218946,2219010,2219074,2219138,2219202,2219266,2219330,2219394,2219458,2215682,2219522,2219586,2219650]),p([2215746,2219714,2219778,2219842,2219906,2219970,2220034,2220098,2218402,2220162,2220226,2220290,2220354,2219970,2220034,2220098]),p([2218402,2218338,2218466,2212834,2212130,2212194,2212258,2219970,2220034,2220098,2212834,2212898,2220418,2220418,g,g]),p([2220483,2220579,2220579,2220675,2220771,2220867,2220963,2221059,2211811,2211811,2221155,2221251,2221347,2221443,2221539,2221635]),p([2221635,2221731,2221827,2221827,2221923,2221923,2222019,2222115,2222115,2222211,2222307,2222307,2222403,2222403,2222499,2222595]),p([2222595,2222691,2222691,2222787,2222883,2222979,2223075,2223075,2223171,2223267,2223363,2223459,2223555,2223555,2223651,2223747]),p([2223843,2223939,2224035,2224131,2224131,2224227,2224227,2224323,2224323,2224419,2211843,2224515,2224611,2214755,2211907,2224707]),p([0,0,2224803,2224899,2224995,2225091,2225187,2225283,2225283,2225379,2225475,2225571,2225667,2225667,2225763,2225859]),p([2225955,2226051,2226147,2226243,2226339,2226435,2226531,2226627,2226723,2226819,2226915,2227011,2227107,2227203,2215651,2227299]),p([2227395,2227491,2227587,2227683,2223651,2223843,2227779,2227875,2227971,2228067,2228163,2228259,2228163,2227971,2228355,2228451]),p([2228547,2228643,2228739,2228259,2222979,2222019,2228835,2228931,0,0,0,0,0,0,0,g]),p([2229027,2229123,2229220,2229348,2229476,2229604,2229732,2229860,2229988,2230115,10618834,10619400,2231044,g,g,g]),p([R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R]),p([10619777,2231201,0,10527457,10494753,10517761,10517889,2231233,2231265,0,0,0,0,0,0,0]),p([0,2231297,2231329,10619969,10619969,10518369,10518401,10620001,10620033,2231457,2231489,2231521,2231553,2231585,2231617,2133441]),p([2133473,2231649,2231681,2231713,2231745,g,g,10620385,10620417,10517826,10517826,10517826,10517826,10619969,10619969,10619969]),p([10619777,2231201,0,0,10494753,10527457,10517889,10517761,2231297,10518369,10518401,10620001,10620033,2231457,2231489,10620449]),p([10620481,10620513,10518273,2231937,10620577,10620609,10518337,0,10620641,10620673,10620705,10620737,0,0,0,0]),p([10620770,2232226,10604642,g,10604738,0,10604834,2218530,10604930,2218626,10605026,2218722,10605122,2232290,10620962,2232418]),p([2232481,2232513,2232513,2232545,2232545,2232577,2232577,2232609,2232609,2209921,2209921,2209921,2209921,2113857,2113857,2210721]),p([2210721,2210721,2210721,2232641,2232641,2211105,2211105,2211105,2211105,2211489,2211489,2211489,2211489,2210497,2210497,2210497]),p([2210497,2210561,2210561,2210561,2210561,2210881,2210881,2210881,2210881,2229569,2229569,2215841,2215841,2215905,2215905,2216705]),p([2216705,2212129,2212129,2212129,2212129,2218401,2218401,2218401,2218401,2212385,2212385,2212385,2212385,2212513,2212513,2212513]),p([2212513,2212769,2212769,2212769,2212769,2212897,2212897,2212897,2212897,2212961,2212961,2212961,2212961,2213089,2213089,2213089]),p([2213089,2213217,2213217,2213217,2213217,2213601,2213601,2213601,2213601,2213857,2213857,2213857,2213857,2214145,2214145,2214145]),p([2214145,2210625,2210625,2210625,2210625,2215009,2215009,2215009,2215009,2215393,2215393,2215393,2215393,2113921,2113921,2209889]),p([2209889,2114049,2114049,2114049,2114049,2232674,2232674,2232738,2232738,2232802,2232802,2230914,2230914,0,0,2097152]),p([0,10517761,10621473,10620449,10620673,10620705,10620481,10621505,10518369,10518401,10620513,10518273,10619777,2231937,2149601,10518465]),p([2129473,2098369,2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633,10527457,10494753,10620577,10518337,10620609,10517889]),p([10620737,D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1]),p([J,M,S,P,z,q,I,y,k,L,W,10620385,10620641,10620417,10621537,10619969]),p([10517025,D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1]),p([J,M,S,P,z,q,I,y,k,L,W,10620001,10621569,10620033,10621601,2233025]),p([2233057,2149601,2231649,2231681,2231201,2233089,2164641,2164961,2170337,2233121,2170529,2165473,2233153,2166753,2172481,2166177]),p([2164801,2163233,2163265,2163297,2163329,2163361,2163393,2163425,2163457,2163489,2149921,2163521,2163553,2163585,2163617,2163649]),p([2163681,2163713,2163745,2163777,2149953,2163809,2163841,2163873,2163905,2163937,2163969,2164001,2164033,2164065,2164097,2164129]),p([2164161,2164193,2164225,2164257,2164289,2164321,2164353,2164385,2164417,2164449,2164481,2164513,2164545,2165025,2149761,2149825]),p([2150465,2150497,2150529,2150561,2150593,2150625,2150657,2150689,2150721,2150753,2150785,2150817,2150849,2150881,2150913,0]),p([0,0,2150945,2150977,2151009,2151041,2151073,2151105,0,0,2151137,2151169,2151201,2151233,2151265,2151297]),p([0,0,2151329,2151361,2151393,2151425,2151457,2151489,0,0,2151521,2151553,2151585,0,0,0]),p([2233185,2233217,2233249,10486690,2233281,2233313,2233345,0,2233377,2233409,2233441,2233473,2233505,2233537,2233569,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,0,g,g,0,g]),p([g,g,g,0,0,0,0,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,w,0,0]),p([w,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,0,0,0,0,0,0,g,g,g]),p([g,g,g,g,g,g,w,w,w,w,w,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,0,g]),p([g,g,g,g,0,0,0,0,g,g,g,g,g,g,g,g]),p([2233602,2233666,2233730,2233794,2233858,2233922,2233986,2234050,2234114,2234178,2234242,2234306,2234370,2234434,2234498,2234562]),p([2234626,2234690,2234754,2234818,2234882,2234946,2235010,2235074,2235138,2235202,2235266,2235330,2235394,2235458,2235522,2235586]),p([2235650,2235714,2235778,2235842,2235906,2235970,2236034,2236098,g,g,g,g,g,g,g,g]),p([2236162,2236226,2236290,2236354,2236418,2236482,2236546,2236610,2236674,2236738,2236802,2236866,2236930,2236994,2237058,2237122]),p([2237186,2237250,2237314,2237378,2237442,2237506,2237570,2237634,2237698,2237762,2237826,2237890,2237954,2238018,2238082,2238146]),p([2238210,2238274,2238338,2238402,0,0,0,0,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,0,0,0,0,0,0,0,0,g]),p([2238466,2238530,2238594,2238658,2238722,2238786,2238850,2238914,2238978,2239042,2239106,0,2239170,2239234,2239298,2239362]),p([2239426,2239490,2239554,2239618,2239682,2239746,2239810,2239874,2239938,2240002,2240066,0,2240130,2240194,2240258,2240322]),p([2240386,2240450,2240514,0,2240578,2240642,0,g,g,g,g,g,g,g,g,g]),p([g,g,0,g,g,g,g,g,g,g,0,g,g,0,0,0]),p([g,2240705,2240737,2098881,2240769,2101825,0,2240801,2240833,2240865,2240897,2101985,2102017,2240929,2240961,2240993]),p([2241025,2241057,2241089,2102209,2241121,2100321,2241153,2241185,2241217,2241249,2241281,2189153,2241314,2241377,2241409,2241442]),p([2241505,2241538,2099425,2241601,2241633,M,2241665,2241698,2140705,2241761,2102561,2241793,2241825,2241857,2241889,2102689]),p([2241921,0,2241953,2241985,2242017,2242049,2242081,2242113,2242145,2242178,2242242,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,g,0,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,g,g,0,0,0,g,0,0,g]),p([g,g,g,0,g,g,0,0,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,0,0,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,0,g]),p([g,g,g,g,g,g,g,g,0,0,0,0,g,g,g,g]),p([0,0,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,0,w,w,0,0,0,0,0,w,w,w,w]),p([g,g,g,g,0,g,g,g,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,0,w,w,w,0,0,0,0,w]),p([g,g,g,g,g,w,w,0,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,g,0,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,0,g,g,g,g,g,g,g,g]),p([g,g,g,0,0,0,0,0,g,g,g,g,g,g,g,g]),p([g,g,0,0,0,0,0,0,0,g,g,g,g,0,0,0]),p([0,0,0,0,0,0,0,0,0,g,g,g,g,g,g,g]),p([2242306,2242370,2242434,2242498,2242562,2242626,2242690,2242754,2242818,2242882,2242946,2243010,2243074,2243138,2243202,2243266]),p([2243330,2243394,2243458,2243522,2243586,2243650,2243714,2243778,2243842,2243906,2243970,2244034,2244098,2244162,2244226,2244290]),p([2244354,2244418,2244482,2244546,2244610,2244674,2244738,2244802,2244866,2244930,2244994,2245058,2245122,2245186,2245250,2245314]),p([2245378,2245442,2245506,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,0,0,0,0,0,0,0,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,w,w,g,0,0]),p([g,g,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,0,0,w,w,w]),p([w,g,g,g,g,g,g,g,g,g,0,0,0,0,0,0]),p([g,g,w,w,w,w,g,g,g,g,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,g,g,g,g,g,g,g,0,0]),p([w,g,g,w,w,g,0,0,0,0,0,0,0,0,0,w]),p([w,w,w,w,w,w,w,w,w,w,w,g,g,0,g,g]),p([g,g,w,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,0,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,w,w,g,0,0,0,0,0,0,0,0]),p([g,g,g,w,g,g,g,0,0,0,0,0,0,0,0,0]),p([w,g,g,g,g,g,g,g,g,w,w,w,w,g,w,w]),p([g,g,g,g,g,g,g,g,g,g,g,g,w,w,w,w]),p([w,w,w,w,w,w,w,w,g,g,g,g,g,g,w,g]),p([g,w,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,0,g,0,g,g,g,g,0,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,w]),p([w,w,w,w,w,w,w,w,w,w,w,0,0,0,0,0]),p([w,w,w,w,0,g,g,g,g,g,g,g,g,0,0,g]),p([g,0,g,g,0,g,g,g,g,g,0,w,w,g,w,w]),p([g,0,0,0,0,0,0,w,0,0,0,0,0,g,g,g]),p([g,g,w,w,0,0,w,w,w,w,w,w,w,0,0,0]),p([w,w,w,w,w,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,g,w,g]),p([w,w,w,w,g,g,g,g,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,0,0,w,w,w,w,w,w,w,w]),p([g,g,g,g,g,g,g,g,g,g,g,g,w,w,0,0]),p([w,g,g,g,g,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,g,g,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,w,w,g,0,0,0,0]),p([2245570,2245634,2245698,2245762,2245826,2245890,2245954,2246018,2246082,2246146,2246210,2246274,2246338,2246402,2246466,2246530]),p([2246594,2246658,2246722,2246786,2246850,2246914,2246978,2247042,2247106,2247170,2247234,2247298,2247362,2247426,2247490,2247554]),p([g,g,g,0,0,0,0,0,0,0,0,0,0,0,0,g]),p([g,g,g,g,g,g,g,0,0,g,0,0,g,g,g,g]),p([g,g,g,g,0,g,g,0,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,0,w,w,0,0,w,w,w,w,g]),p([w,g,w,w,g,g,g,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,0,0,g,g,g,g,g,g]),p([g,w,w,w,w,w,w,w,0,0,w,w,w,w,w,w]),p([w,g,g,g,w,0,0,0,0,0,0,0,0,0,0,0]),p([g,w,w,w,w,w,w,w,w,w,w,g,g,g,g,g]),p([g,g,g,w,w,w,w,w,w,w,g,w,w,w,w,g]),p([g,g,g,g,g,g,g,w,0,0,0,0,0,0,0,0]),p([g,w,w,w,w,w,w,w,w,w,w,w,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,0,w,w,w,w,w,w,w,w]),p([0,0,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,0,w,w,w,w,w,w,w]),p([g,g,g,g,g,g,g,0,g,g,0,g,g,g,g,g]),p([g,w,w,w,w,w,w,0,0,0,w,0,w,w,0,w]),p([w,w,w,w,w,w,g,w,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,0,g,g,0,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,w,w,0]),p([w,w,0,w,w,w,w,w,g,0,0,0,0,0,0,0]),p([g,g,g,w,w,w,w,g,g,0,0,0,0,0,0,0]),p([w,w,g,w,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,w,w,w,0,0,0,w,w]),p([g,g,0,0,0,0,0,0,0,0,0,0,0,0,0,g]),p([w,g,g,g,g,g,g,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,g,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,0,0,0,0,0,g,g,g]),p([2247618,2247682,2247746,2247810,2247874,2247938,2248002,2248066,2248130,2248194,2248258,2248322,2248386,2248450,2248514,2248578]),p([2248642,2248706,2248770,2248834,2248898,2248962,2249026,2249090,2249154,2249218,2249282,2249346,2249410,2249474,2249538,2249602]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,0,w]),p([g,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,0,0,0,0,0,0,0,w]),p([g,g,g,g,w,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,0,g,g,g,g,g,g,g,0,g,g,0]),p([0,0,g,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,0,0,g,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,g,g,g,g,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,g,w,w,g]),p([2097152,2097152,2097152,2097152,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,0,0]),p([g,g,g,g,g,g,g,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,2249668,2249796]),p([2249926,2250118,2250310,2250502,2250694,w,w,w,w,w,g,g,g,w,w,w]),p([w,w,w,0,0,0,0,0,0,0,0,w,w,w,w,w]),p([w,w,w,g,g,w,w,w,w,w,w,w,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,2250884,2251012,2251142,2251334,2251526]),p([2251718,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,w,w,w,g,0,0,0,0,0,0,0,0,0,0]),p([M,S,P,z,q,I,y,k,L,W,D,_,A,b,j,B]),p([G,O,C,F,U,x,N,H,$$1,J,M,S,P,z,q,I]),p([y,k,L,W,D,_,A,b,j,B,G,O,C,F,U,x]),p([N,H,$$1,J,M,S,P,z,q,I,y,k,L,W,D,_]),p([A,b,j,B,G,0,C,F,U,x,N,H,$$1,J,M,S]),p([P,z,q,I,y,k,L,W,D,_,A,b,j,B,G,O]),p([C,F,U,x,N,H,$$1,J,M,S,P,z,q,I,y,k]),p([L,W,D,_,A,b,j,B,G,O,C,F,U,x,N,H]),p([$$1,J,M,S,P,z,q,I,y,k,L,W,D,0,A,b]),p([0,0,G,0,0,F,U,0,0,H,$$1,J,M,0,P,z]),p([q,I,y,k,L,W,D,_,A,b,0,B,0,O,C,F]),p([U,x,N,H,0,J,M,S,P,z,q,I,y,k,L,W]),p([y,k,L,W,D,_,0,b,j,B,G,0,0,F,U,x]),p([N,H,$$1,J,M,0,P,z,q,I,y,k,L,0,D,_]),p([A,b,j,B,G,O,C,F,U,x,N,H,$$1,J,M,S]),p([P,z,q,I,y,k,L,W,D,_,0,b,j,B,G,0]),p([C,F,U,x,N,0,$$1,0,0,0,P,z,q,I,y,k]),p([L,0,D,_,A,b,j,B,G,O,C,F,U,x,N,H]),p([$$1,J,M,S,P,z,q,I,y,k,L,W,D,_,A,b]),p([j,B,G,O,C,F,U,x,N,H,$$1,J,M,S,P,z]),p([q,I,y,k,L,W,D,_,A,b,j,B,G,O,C,F]),p([y,k,L,W,2251905,2251937,0,0,2106529,nt,tt,2106625,X,2106689,2106721,E]),p([2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,E,V,2107041,rt,K,ot,2107169]),p([et,2251969,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881]),p([2106913,Q,T,V,V,2107041,rt,K,ot,2107169,et,2252001,X,E,Y,K]),p([T,Q,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881]),p([2106913,Q,T,E,V,2107041,rt,K,ot,2107169,et,2251969,2106529,nt,tt,2106625]),p([X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,V,V,2107041]),p([rt,K,ot,2107169,et,2252001,X,E,Y,K,T,Q,2106529,nt,tt,2106625]),p([X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,E,V,2107041]),p([rt,K,ot,2107169,et,2251969,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y]),p([2106817,2098273,2106849,2106881,2106913,Q,T,V,V,2107041,rt,K,ot,2107169,et,2252001]),p([X,E,Y,K,T,Q,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y]),p([2106817,2098273,2106849,2106881,2106913,Q,T,E,V,2107041,rt,K,ot,2107169,et,2251969]),p([2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q]),p([T,V,V,2107041,rt,K,ot,2107169,et,2252001,X,E,Y,K,T,Q]),p([T,E,V,2107041,rt,K,ot,2107169,et,2251969,2106529,nt,tt,2106625,X,2106689]),p([2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,V,V,2107041,rt,K]),p([ot,2107169,et,2252001,X,E,Y,K,T,Q,2107393,2107393,0,0,2129473,2098369]),p([2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633,2129473,2098369,2098145,2098177,2098465,2129505,2129537,2129569]),p([2129601,2129633,2129473,2098369,2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633,2129473,2098369,2098145,2098177]),p([2098465,2129505,2129537,2129569,2129601,2129633,2129473,2098369,2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633]),p([w,w,w,w,w,w,w,g,g,g,g,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,g,g,g]),p([g,g,g,g,w,g,g,g,g,g,g,g,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,w,w,w,w,w]),p([0,0,0,0,0,g,g,g,g,g,g,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,0,0,w,w,w,w,w]),p([w,w,0,w,w,0,w,w,w,w,w,0,0,0,0,0]),p([2108385,2108417,2108449,2108481,2108513,2108545,2108577,2108609,2108641,2108705,2108737,2108769,2108833,2108865,2108897,2108929]),p([2108961,2108993,2109025,2109057,2109089,2109121,2109153,2109249,2109313,2109345,2186945,2111169,2108065,2108129,2111425,2110529]),p([2252033,2108385,2108417,2108449,2108481,2108513,2108545,2108577,2108609,2108641,2108705,2108737,2108833,2108865,2108929,2108993]),p([2109025,2109057,2109089,2109121,2109153,2109217,2109249,2110049,2108065,2108033,2108353,2110465,2186337,2110561,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,w]),p([g,g,g,g,g,g,g,0,g,g,g,g,0,g,g,0]),p([g,g,g,g,g,0,0,g,g,g,g,g,g,g,g,g]),p([2252066,2252130,2252194,2252258,2252322,2252386,2252450,2252514,2252578,2252642,2252706,2252770,2252834,2252898,2252962,2253026]),p([2253090,2253154,2253218,2253282,2253346,2253410,2253474,2253538,2253602,2253666,2253730,2253794,2253858,2253922,2253986,2254050]),p([2254114,2254178,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,w,w,w,g,0,0,0,0]),p([2113857,2210721,2210497,2229569,0,2113921,2216705,2210561,2212769,2114049,2213857,2214145,2210625,2215009,2212129,2212961]),p([2213217,2212385,2213601,2215905,2218401,2211105,2211489,2210881,2215841,2212513,2212897,2213089,2254241,2209441,2254273,2254305]),p([0,2210721,2210497,0,2215393,0,0,2210561,0,2114049,2213857,2214145,2210625,2215009,2212129,2212961]),p([2213217,2212385,2213601,0,2218401,2211105,2211489,2210881,0,2212513,0,2213089,0,0,0,0]),p([0,0,2210497,0,0,0,0,2210561,0,2114049,0,2214145,0,2215009,2212129,2212961]),p([0,2212385,2213601,0,2218401,0,0,2210881,0,2212513,0,2213089,0,2209441,0,2254305]),p([0,2210721,2210497,0,2215393,0,0,2210561,2212769,2114049,2213857,0,2210625,2215009,2212129,2212961]),p([2213217,2212385,2213601,0,2218401,2211105,2211489,2210881,0,2212513,2212897,2213089,2254241,0,2254273,0]),p([2113857,2210721,2210497,2229569,2215393,2113921,2216705,2210561,2212769,2114049,0,2214145,2210625,2215009,2212129,2212961]),p([2213217,2212385,2213601,2215905,2218401,2211105,2211489,2210881,2215841,2212513,2212897,2213089,0,0,0,0]),p([0,2210721,2210497,2229569,0,2113921,2216705,2210561,2212769,2114049,0,2214145,2210625,2215009,2212129,2212961]),p([0,10642946,10643010,10643074,10643138,10643202,10643266,10643330,10643394,10643458,10643522,g,g,g,g,g]),p([10524963,10525059,10525155,10525251,10525347,10525443,10525539,10525635,10525731,10525827,10525923,10526019,10526115,10526211,10526307,10526403]),p([10526499,10526595,10526691,10526787,10526883,10526979,10527075,10527171,10527267,10527363,2254979,A,S,2097218,2255074,g]),p([M,S,P,z,q,I,y,k,L,W,2255138,2181218,2255202,2099650,2255267,2255362]),p([g,g,g,g,g,g,g,g,g,g,2179074,2176578,2255426,g,g,g]),p([2255490,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([2255554,2255618,2163521,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([2144769,2255681,2255713,2168993,2142945,2255745,2255777,2153217,2255809,2255841,2255873,2198113,2255905,2255937,2255969,2256001]),p([2256033,2256065,2145921,2256097,2256129,2256161,2256193,2256225,2256257,2142753,2152961,2256289,2161121,2153057,2161153,2256321]),p([2147713,2256353,2256385,2256417,2256449,2256481,2158081,2145089,2256513,2256545,2256577,2256609,0,0,0,0]),p([2256643,2256739,2256835,2256931,2257027,2257123,2257219,2257315,2257411,0,0,0,0,0,0,0]),p([2257505,2257537,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,0,0,0,0,0,0,g,g]),p([g,g,g,0,g,g,g,g,g,g,g,g,g,g,g,g]),p([2129473,2098369,2098145,2098177,2098465,2129505,2129537,2129569,2129601,2129633,0,0,0,0,0,0]),p([2257569,2257601,2257633,2257666,2257729,2201089,2257761,2257793,2257825,2257857,2201121,2257889,2257921,2257954,2201153,2258017]),p([2258049,2258081,2258114,2258177,2258209,2255969,2258242,2258305,2258337,2258369,2258401,2202945,2258434,2143265,2258497,2258529]),p([2258561,2258593,2256545,2258625,2258657,2203105,2201185,2201217,2203137,2258689,2258721,2195393,2258753,2201249,2258785,2258817]),p([2258849,2258881,2258881,2258881,2258914,2258977,2259009,2259041,2259074,2259137,2259169,2259201,2259233,2259265,2259297,2259329]),p([2259361,2259393,2259425,2259457,2259489,2259521,2259521,2203201,2259553,2259585,2259617,2259649,2201313,2259681,2259713,2259745]),p([2200033,2259777,2259809,2259841,2259873,2259905,2259937,2259969,2260001,2260034,2260097,2260129,2260161,2255745,2260193,2260225]),p([2260258,2260322,2260385,2260417,2260449,2260481,2260513,2260545,0,2260577,2260609,2260609,2260642,2260705,2260737,2195265]),p([2260769,2260802,2260865,2260897,0,2144097,2260929,2260961,2144161,2260993,2261025,2261058,2261121,2261154,2261217,2261249]),p([2261281,2261313,2261345,2261377,2261409,2261441,2261473,2261505,2261537,2261570,2261633,2261665,2261697,2261729,2193601,2261762]),p([2144481,2261826,2261826,2261889,2261921,2261921,2261953,2261986,2262050,2262113,2262145,2262177,2262209,2262241,2262273,2262305]),p([2262337,2262369,2262401,2201473,2262434,2262497,2262529,2262561,2203585,2262561,2262593,2201537,2262625,2262657,2262689,2262721]),p([2201569,2192737,2176897,2262753,2262785,2262817,2262849,2262881,2262914,2262977,2263009,2263041,2263073,2263105,2263138,2263201]),p([2263233,2263265,2263297,2263329,2263361,2263393,2263425,2263457,2201601,2263489,2263522,2263585,2263617,2263649,2263681,2201665]),p([2263713,2263745,2263777,2263809,2263841,2263873,2263905,2263937,2193633,2203841,2263969,2264001,2264033,2264066,2264129,2264161]),p([2264193,2264225,2201697,2264258,2264321,2264353,2264385,2205281,2264417,2264449,2264481,2264513,2264546,2264609,2264641,2264673]),p([2264706,2264769,2264801,2264833,2264865,2195809,2264897,2264930,2264994,2265058,2265121,2265154,2265217,2265249,2265281,2265313]),p([2265345,2201729,2198433,2265377,2265409,2265441,2265474,2265537,2265569,2265601,2265633,2203937,2265665,2265698,2265761,2265793]),p([2265826,2265890,2265953,2265985,2203969,2266017,2266049,2266081,2266113,2266145,2266177,2266210,2266273,2266306,2266369,0]),p([2266401,2204033,2266433,2266466,2266529,2266561,2266594,2266658,2266721,2266753,2266785,2266817,2266849,2266849,2266881,2266913]),p([2204097,2266945,2266977,2267009,2267041,2267074,2267137,2267170,2195361,2267234,2267297,2267330,2267394,2267458,2267521,2267553]),p([2204289,2267586,2267650,2267714,2267778,2267841,2267873,2267873,2204321,2205345,2267905,2267937,2267969,2268002,2268065,2194177]),p([2204385,2268097,2268130,2202049,2268194,2268258,2200673,2268321,2268353,2202145,2268385,2268417,2268450,2268514,2268514,0]),p([2268577,2268610,2268673,2268705,2268737,2268770,2268833,2268865,2268897,2268929,2268961,2268994,2269057,2269089,2269121,2269153]),p([2269185,2269217,2269250,2269314,2269377,2269410,2269473,2269506,2269569,2269601,2202337,2269634,2269698,2269761,2269794,2269857]),p([2269890,2269953,2269985,2270017,2270049,2270081,2270113,2270146,2270210,2270274,2270338,2261889,2270401,2270433,2270465,2270497]),p([2270529,2270561,2270593,2270625,2270657,2270689,2270721,2270754,2195905,2270817,2270849,2270881,2270913,2270945,2270977,2202433]),p([2271009,2271041,2271073,2271105,2271138,2271202,2271266,2271329,2271361,2271393,2271425,2271458,2271521,2271554,2271617,2271649]),p([2271682,2271746,2271809,2271841,2194017,2271873,2271905,2271937,2271969,2272001,2272033,2204609,2272065,2272097,2272129,0]),p([2272161,2272193,2272225,2272257,2147361,2272290,2272353,2272385,2272417,2272449,2272481,2272514,2272578,2272641,2272673,2272705]),p([2204769,2204801,2147585,2272738,2272801,2272833,2272865,2272897,2272930,2272994,2273057,2273089,2273121,2273154,2273217,2204833]),p([2273250,2273314,2273377,2273409,2273441,2273474,2273537,2273569,2273601,2273633,2273665,2273697,2273729,2273762,2273825,2273857]),p([2273889,2273922,2273985,2274017,2274049,2274081,2274114,2274178,2274241,2274273,2274305,2274338,2274401,2274434,2205025,2205025]),p([2274497,2274530,2274593,2274625,2274657,2274689,2274721,2274753,2274785,2274818,2205057,2274881,2274913,2274945,2274977,2275009]),p([2275042,2275105,2275138,2275202,2275266,2149121,2275329,2149249,2275361,2275393,2275425,2275457,2149409,2275490,0,0]),p([g,g,g,g,g,g,g,g,g,g,g])],st=new Uint16Array([0,0,1,2,3,4,5,6,7,7,8,9,10,11,12,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,...m(12,6),34,12,35,36,12,...m(37,4),38,37,37,39,40,41,42,12,43,44,45,46,47,48,49,12,12,12,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,12,12,66,67,37,68,69,12,70,71,72,73,12,12,74,37,12,75,...m(12,5),76,77,12,78,79,12,37,80,...m(12,5),81,82,12,12,74,83,12,84,85,86,12,87,88,12,86,89,12,12,90,37,91,37,92,12,12,93,37,94,95,12,96,97,98,99,100,101,102,103,104,97,98,105,106,107,72,108,109,110,98,111,112,113,102,114,115,97,98,111,116,117,102,118,119,120,121,122,123,124,72,88,125,126,98,127,128,129,102,130,131,126,98,132,128,133,102,134,135,126,12,136,137,138,102,12,139,140,12,141,142,143,72,144,145,12,12,146,147,148,7,7,149,12,150,151,152,153,7,7,154,155,12,156,157,158,159,160,161,162,163,164,165,88,7,7,12,12,74,166,12,167,168,169,170,171,7,7,172,12,12,173,...m(12,5),86,145,...m(12,13),174,175,12,12,174,12,12,176,177,178,12,12,12,177,12,12,12,179,12,180,12,181,...m(12,5),182,...m(12,40),145,180,...m(12,5),183,12,184,12,185,12,186,187,188,12,12,12,189,37,190,181,181,191,181,...m(12,5),183,192,12,193,...m(12,4),194,12,86,195,195,196,12,78,71,12,12,148,12,181,197,12,12,12,198,12,12,12,199,37,200,181,181,78,37,201,7,7,7,202,12,12,203,204,12,74,205,206,12,207,12,12,12,81,208,12,12,203,209,210,12,12,12,211,212,213,214,118,215,216,217,12,12,218,219,220,221,222,223,12,224,225,226,...m(37,4),227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,12,113,37,37,270,271,272,273,274,275,276,277,278,279,...m(12,9),280,281,...m(12,14),282,...m(12,15),283,7,88,7,284,285,286,287,288,289,290,291,292,...m(12,81),293,...m(12,6),294,...m(12,5),295,...m(12,9),296,12,297,...m(12,6),298,299,300,12,12,12,301,302,303,304,305,306,307,308,309,310,12,12,311,12,12,12,312,313,12,283,...m(314,4),37,37,...m(12,5),78,7,7,12,315,...m(12,5),316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,7,7,331,12,90,332,145,...m(12,4),333,...m(12,5),334,335,12,12,336,337,338,339,340,341,342,...m(12,4),343,12,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,...m(12,1800),180,12,12,12,283,...m(12,21),148,7,376,377,378,379,380,381,...m(12,5),382,12,12,383,384,385,386,387,388,389,390,391,392,393,394,7,395,396,12,397,181,12,12,12,118,398,12,12,203,399,181,37,400,12,12,401,12,402,403,12,180,92,12,12,404,405,406,407,86,12,12,408,409,410,411,12,412,12,12,12,413,414,415,74,416,417,418,314,12,12,419,420,421,422,423,424,425,12,12,426,181,...m(12,698),343,12,427,12,12,148,...m(7,528),428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,7,7,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,12,494,495,496,497,498,499,500,501,7,7,502,503,504,37,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,336,528,529,530,531,7,532,12,178,533,78,78,7,7,...m(12,7),88,534,12,12,535,...m(12,4),86,180,113,7,7,12,12,536,...m(7,8),12,180,12,12,12,113,537,148,12,12,538,12,88,12,12,539,12,540,12,12,541,194,7,7,542,543,544,...m(12,6),78,181,545,546,547,12,148,12,12,118,12,12,12,548,549,550,551,110,552,7,7,7,7,...m(12,19),283,12,194,118,7,553,554,555,556,7,7,7,7,557,12,12,558,12,297,12,12,12,86,130,7,7,7,12,559,12,560,12,561,7,7,7,7,12,12,12,562,12,563,12,12,564,565,12,566,183,183,...m(12,4),7,7,12,12,567,283,12,12,12,568,12,569,12,570,12,571,572,...m(7,5),...m(12,4),183,7,7,7,573,574,575,576,12,12,12,577,12,12,578,181,...m(7,18),12,86,12,12,579,580,7,7,7,581,12,12,118,12,81,582,7,12,583,7,7,12,148,7,12,283,206,12,12,584,585,563,12,586,206,12,12,587,588,12,183,181,206,12,402,589,590,12,12,591,206,12,12,404,592,12,145,71,12,110,593,594,595,7,7,7,596,540,181,12,12,597,598,181,599,97,98,600,116,601,602,603,...m(7,8),12,12,12,604,605,606,580,7,12,12,12,37,607,181,...m(7,10),12,12,597,608,537,609,7,7,12,12,12,37,610,181,180,7,12,12,74,611,181,7,7,7,12,179,195,12,283,...m(7,11),12,12,593,612,...m(7,6),613,614,12,12,12,615,616,617,12,618,619,181,7,7,7,7,620,12,12,621,622,7,623,12,12,624,625,626,12,12,90,627,470,...m(12,4),183,181,...m(7,15),98,12,597,628,194,12,180,12,12,629,630,409,7,7,7,7,631,12,12,632,633,181,634,12,635,636,181,...m(7,19),12,637,638,126,12,639,206,181,...m(7,5),113,12,12,12,640,...m(12,57),181,...m(7,6),...m(12,6),86,71,...m(12,12),343,...m(7,164),...m(12,6),470,...m(12,67),7,641,642,...m(7,250),...m(12,36),283,...m(7,539),...m(12,35),183,12,86,406,...m(12,4),86,181,12,78,643,12,12,12,605,194,644,110,645,12,...m(7,43),646,647,12,12,12,88,...m(7,6),...m(12,4),648,649,37,37,650,206,7,7,7,7,651,652,...m(12,383),118,...m(12,77),194,7,7,183,...m(7,558),653,...m(12,18),470,654,7,655,656,...m(12,24),148,...m(7,144),...m(12,6),88,180,183,657,658,...m(7,293),37,37,659,37,409,...m(12,7),343,7,7,7,...m(12,15),194,12,12,660,12,12,661,662,663,664,12,171,665,666,12,88,7,...m(12,4),667,...m(7,7),12,343,12,343,...m(12,5),283,12,183,...m(7,8),291,668,669,670,671,672,673,674,675,676,677,678,679,291,668,669,680,681,682,683,684,685,686,687,688,290,291,668,669,670,671,682,673,674,675,686,687,688,290,291,668,669,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,702,704,705,706,707,708,709,...m(12,32),37,37,37,710,37,37,711,407,712,713,67,...m(7,69),12,86,714,...m(7,13),628,715,716,717,718,719,720,7,721,...m(7,7),12,12,180,585,406,...m(7,20),12,103,7,12,12,593,561,...m(7,29),12,593,181,...m(7,46),722,86,...m(12,12),723,409,7,7,724,725,726,12,727,406,...m(7,49),145,12,12,12,71,7,7,7,7,145,12,12,78,...m(7,12),728,729,730,731,732,733,734,735,736,737,738,737,7,7,7,580,...m(7,16),12,12,148,...m(12,6),343,86,...m(145,3),12,194,739,740,741,291,742,12,743,12,12,744,78,7,7,7,72,12,745,746,747,748,749,750,194,...m(7,9),...m(12,61),562,180,180,...m(12,7),427,...m(12,5),181,148,113,148,12,12,12,118,181,12,12,118,12,78,580,7,7,7,7,...m(12,21),343,78,180,183,12,12,540,751,148,183,183,...m(12,9),752,12,12,88,7,7,753,...m(7,64),...m(12,2670),7,7,...m(12,259),181,...m(12,13),78,...m(12,360),580,...m(12,467),113,...m(12,38),78,...m(7,154),754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,...m(7,93),7]),lt="abcdefghijklmnopqrstuvwxyz  ̈ ̄23 ́μ ̧11⁄41⁄23⁄4àáâãäåæçèéêëìíîïðñòóôõöøùúûüýþssāăąćĉċčďđēĕėęěĝğġģĥħĩīĭįi̇ĵķĺļľl·łńņňʼnŋōŏőœŕŗřśŝşšţťŧũūŭůűųŵŷÿźżžɓƃƅɔƈɖɗƌǝəɛƒɠɣɩɨƙɯɲɵơƣƥʀƨʃƭʈưʊʋƴƶʒƹƽdžljnjǎǐǒǔǖǘǚǜǟǡǣǥǧǩǫǭǯdzǵƕƿǹǻǽǿȁȃȅȇȉȋȍȏȑȓȕȗșțȝȟƞȣȥȧȩȫȭȯȱȳⱥȼƚⱦɂƀʉʌɇɉɋɍɏɦɹɻʁ ̆ ̇ ̊ ̨ ̃ ̋ʕ̀̓̈́ιͱͳʹͷ ι;ϳ ̈́άέήίόύώαβγδεζηθκλνξοπρστυφχψωϊϋϗϙϛϝϟϡϣϥϧϩϫϭϯϸϻͻͼͽѐёђѓєѕіїјљњћќѝўџабвгдежзийклмнопрстуфхцчшщъыьэюяѡѣѥѧѩѫѭѯѱѳѵѷѹѻѽѿҁҋҍҏґғҕҗҙқҝҟҡңҥҧҩҫҭүұҳҵҷҹһҽҿӂӄӆӈӊӌӎӑӓӕӗәӛӝӟӡӣӥӧөӫӭӯӱӳӵӷӹӻӽӿԁԃԅԇԉԋԍԏԑԓԕԗԙԛԝԟԡԣԥԧԩԫԭԯաբգդեզէըթժիլխծկհձղճմյնշոչպջռսվտրցւփքօֆեւاٴوٴۇٴيٴक़ख़ग़ज़ड़ढ़फ़य़ড়ঢ়য়ਲ਼ਸ਼ਖ਼ਗ਼ਜ਼ਫ਼ଡ଼ଢ଼ําໍາຫນຫມ་གྷཌྷདྷབྷཛྷཀྵཱཱིུྲྀྲཱྀླྀླཱྀྒྷྜྷྡྷྦྷྫྷྐྵⴧⴭნᏰᏱᏲᏳᏴᏵꙋაბგდევზთიკლმოპჟრსტუფქღყშჩცძწჭხჯჰჱჲჳჴჵჶჷჸჹჺჽჾჿɐɑᴂɜᴖᴗᴝᴥɒɕɟɡɥɪᵻʝɭᶅʟɱɰɳɴɸʂƫᴜʐʑḁḃḅḇḉḋḍḏḑḓḕḗḙḛḝḟḡḣḥḧḩḫḭḯḱḳḵḷḹḻḽḿṁṃṅṇṉṋṍṏṑṓṕṗṙṛṝṟṡṣṥṧṩṫṭṯṱṳṵṷṹṻṽṿẁẃẅẇẉẋẍẏẑẓẕaʾßạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹỻỽỿἀἁἂἃἄἅἆἇἐἑἒἓἔἕἠἡἢἣἤἥἦἧἰἱἲἳἴἵἶἷὀὁὂὃὄὅὑὓὕὗὠὡὢὣὤὥὦὧἀιἁιἂιἃιἄιἅιἆιἇιἠιἡιἢιἣιἤιἥιἦιἧιὠιὡιὢιὣιὤιὥιὦιὧιὰιαιάιᾶιᾰᾱ ̓ ͂ ̈͂ὴιηιήιῆιὲ ̓̀ ̓́ ̓͂ΐῐῑὶ ̔̀ ̔́ ̔͂ΰῠῡὺῥ ̈̀`ὼιωιώιῶιὸ‐ ̳′′′′′‵‵‵‵‵!! ̅???!!?056789+−=()a/ca/s°cc/oc/u°fsmteltmאבגדfax∑1⁄71⁄91⁄101⁄32⁄31⁄52⁄53⁄54⁄51⁄65⁄61⁄83⁄85⁄87⁄8iiiiiivviviiviiiixxixii0⁄3∫∫∫∫∫∮∮∮∮∮〈〉121314151617181920(1)(2)(3)(4)(5)(6)(7)(8)(9)(10)(11)(12)(13)(14)(15)(16)(17)(18)(19)(20)(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)(l)(m)(n)(o)(p)(q)(r)(s)(t)(u)(v)(w)(x)(y)(z)::===⫝̸ⰰⰱⰲⰳⰴⰵⰶⰷⰸⰹⰺⰻⰼⰽⰾⰿⱀⱁⱂⱃⱄⱅⱆⱇⱈⱉⱊⱋⱌⱍⱎⱏⱐⱑⱒⱓⱔⱕⱖⱗⱘⱙⱚⱛⱜⱝⱞⱟⱡɫᵽɽⱨⱪⱬⱳⱶȿɀⲁⲃⲅⲇⲉⲋⲍⲏⲑⲓⲕⲗⲙⲛⲝⲟⲡⲣⲥⲧⲩⲫⲭⲯⲱⲳⲵⲷⲹⲻⲽⲿⳁⳃⳅⳇⳉⳋⳍⳏⳑⳓⳕⳗⳙⳛⳝⳟⳡⳣⳬⳮⳳⵡ母龟一丨丶丿乙亅二亠人儿入八冂冖冫几凵刀力勹匕匚匸十卜卩厂厶又口囗土士夂夊夕大女子宀寸小尢尸屮山巛工己巾干幺广廴廾弋弓彐彡彳心戈戶手支攴文斗斤方无日曰月木欠止歹殳毋比毛氏气水火爪父爻爿片牙牛犬玄玉瓜瓦甘生用田疋疒癶白皮皿目矛矢石示禸禾穴立竹米糸缶网羊羽老而耒耳聿肉臣自至臼舌舛舟艮色艸虍虫血行衣襾見角言谷豆豕豸貝赤走足身車辛辰辵邑酉釆里金長門阜隶隹雨靑非面革韋韭音頁風飛食首香馬骨高髟鬥鬯鬲鬼魚鳥鹵鹿麥麻黃黍黑黹黽鼎鼓鼠鼻齊齒龍龜龠.〒卄卅 ゙ ゚よりコトᄀᄁᆪᄂᆬᆭᄃᄄᄅᆰᆱᆲᆳᆴᆵᄚᄆᄇᄈᄡᄉᄊᄋᄌᄍᄎᄏᄐᄑ하ᅢᅣᅤᅥᅦᅧᅨᅩᅪᅫᅬᅭᅮᅯᅰᅱᅲᅳᅴᅵᄔᄕᇇᇈᇌᇎᇓᇗᇙᄜᇝᇟᄝᄞᄠᄢᄣᄧᄩᄫᄬᄭᄮᄯᄲᄶᅀᅇᅌᇱᇲᅗᅘᅙᆄᆅᆈᆑᆒᆔᆞᆡ三四上中下甲丙丁天地(ᄀ)(ᄂ)(ᄃ)(ᄅ)(ᄆ)(ᄇ)(ᄉ)(ᄋ)(ᄌ)(ᄎ)(ᄏ)(ᄐ)(ᄑ)(ᄒ)(가)(나)(다)(라)(마)(바)(사)(아)(자)(차)(카)(타)(파)(하)(주)(오전)(오후)(一)(二)(三)(四)(五)(六)(七)(八)(九)(十)(月)(火)(水)(木)(金)(土)(日)(株)(有)(社)(名)(特)(財)(祝)(労)(代)(呼)(学)(監)(企)(資)(協)(祭)(休)(自)(至)問幼箏pte2224252627282930333435참고주의우秘男適優印注項写正左右医宗夜3637383940444546474849501月2月3月4月5月6月7月8月9月10月11月12月hgergevltdアイウエオカキクケサシスセソタチツテナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヰヱヲ令和アパートアルファアンペアアールイニングインチウォンエスクードエーカーオンスオームカイリカラットカロリーガロンガンマギガギニーキュリーギルダーキロキログラムキロメートルキロワットグラムトンクルゼイロクローネケースコルナコーポサイクルサンチームシリングセンチセントダースデシドルナノノットハイツパーセントパーツバーレルピアストルピクルピコビルファラッドフィートブッシェルフランヘクタールペソペニヒヘルツペンスページベータポイントボルトホンポンドホールホーンマイクロマイルマッハマルクマンションミクロンミリミリバールメガメガトンヤードヤールユアンリットルリラルピールーブルレムレントゲン0点1点2点3点4点5点6点7点8点9点10点11点12点13点14点15点16点17点18点19点20点21点22点23点24点hpadaaubarovpcdmdm2dm3iu平成昭和大正明治株式会社naμamakakbmbgbcalkcalpfnfμfμgmgkghzkhzmhzthzμlmldlfmnmμmmmcmkmmm2cm2km2mm3cm3km3m∕sm∕s2kpampagparadrad∕srad∕s2psnsμsmspvnvμvmvkvpwnwμwmwkwkωmωbqc∕kgdbgyhainkkktlnloglxmilmolphppmprsvwbv∕ma∕m1日2日3日4日5日6日7日8日9日10日11日12日13日14日15日16日17日18日19日20日21日22日23日24日25日26日27日28日29日30日31日galꙁꙃꙅꙇꙉꙍꙏꙑꙓꙕꙗꙙꙛꙝꙟꙡꙣꙥꙧꙩꙫꙭꚁꚃꚅꚇꚉꚋꚍꚏꚑꚓꚕꚗꚙꚛꜣꜥꜧꜩꜫꜭꜯꜳꜵꜷꜹꜻꜽꜿꝁꝃꝅꝇꝉꝋꝍꝏꝑꝓꝕꝗꝙꝛꝝꝟꝡꝣꝥꝧꝩꝫꝭꝯꝺꝼᵹꝿꞁꞃꞅꞇꞌꞑꞓꞗꞙꞛꞝꞟꞡꞣꞥꞧꞩɬʞʇꭓꞵꞷꞹꞻꞽꞿꟁꟃꞔᶎꟈꟊꟑꟗꟙꟶꬷꭒʍᎠᎡᎢᎣᎤᎥᎦᎧᎨᎩᎪᎫᎬᎭᎮᎯᎰᎱᎲᎳᎴᎵᎶᎷᎸᎹᎺᎻᎼᎽᎾᎿᏀᏁᏂᏃᏄᏅᏆᏇᏈᏉᏊᏋᏌᏍᏎᏏᏐᏑᏒᏓᏔᏕᏖᏗᏘᏙᏚᏛᏜᏝᏞᏟᏠᏡᏢᏣᏤᏥᏦᏧᏨᏩᏪᏫᏬᏭᏮᏯ豈更賈滑串句契喇奈懶癩羅蘿螺裸邏樂洛烙珞落酪駱亂卵欄爛蘭鸞嵐濫藍襤拉臘蠟廊朗浪狼郎來冷勞擄櫓爐盧蘆虜路露魯鷺碌祿綠菉錄論壟弄籠聾牢磊賂雷壘屢樓淚漏累縷陋勒肋凜凌稜綾菱陵讀拏諾丹寧怒率異北磻便復不泌數索參塞省葉說殺沈拾若掠略亮兩凉梁糧良諒量勵呂廬旅濾礪閭驪麗黎曆歷轢年憐戀撚漣煉璉秊練聯輦蓮連鍊列劣咽烈裂廉念捻殮簾獵囹嶺怜玲瑩羚聆鈴零靈領例禮醴隸惡了僚寮尿料燎療蓼遼暈阮劉杻柳流溜琉留硫紐類戮陸倫崙淪輪律慄栗隆利吏履易李梨泥理痢罹裏裡離匿溺吝燐璘藺隣鱗麟林淋臨笠粒狀炙識什茶刺切度拓糖宅洞暴輻降廓兀嗀塚晴凞猪益礼神祥福靖精蘒諸逸都飯飼館鶴郞隷侮僧免勉勤卑喝嘆器塀墨層悔慨憎懲敏既暑梅海渚漢煮爫琢碑祉祈祐祖禍禎穀突節縉繁署者臭艹著褐視謁謹賓贈辶難響頻恵𤋮舘並况全侀充冀勇勺啕喙嗢墳奄奔婢嬨廒廙彩徭惘慎愈慠戴揄搜摒敖望杖滛滋瀞瞧爵犯瑱甆画瘝瘟盛直睊着磌窱类絛缾荒華蝹襁覆調請諭變輸遲醙鉶陼韛頋鬒𢡊𢡄𣏕㮝䀘䀹𥉉𥳐𧻓齃龎fffiflfflմնմեմիվնմխיִײַעהכלםרתשׁשׂשּׁשּׂאַאָאּבּגּדּהּוּזּטּיּךּכּלּמּנּסּףּפּצּקּרּתּוֹבֿכֿפֿאלٱٻپڀٺٿٹڤڦڄڃچڇڍڌڎڈژڑکگڳڱںڻۀہھےۓڭۆۈۋۅۉېىئائەئوئۇئۆئۈئېئىیئجئحئمئيبجبحبخبمبىبيتجتحتختمتىتيثجثمثىثيجحجمحمخجخحخمسجسحسخسمصحصمضجضحضخضمطحطمظمعجعمغجغمفجفحفخفمفىفيقحقمقىقيكاكجكحكخكلكمكىكيلجلحلخلملىليمجمممىمينجنحنخنمنىنيهجهمهىهييحيخيىذٰرٰىٰ ٌّ ٍّ َّ ُّ ِّ ّٰئرئزئنبربزبنترتزتنثرثزثنمانرنزننيريزئخئهبهتهصخلهنههٰثهسهشمشهـَّـُّـِّطىطيعىعيغىغيسىسيشىشيحىجىجيخىصىصيضىضيشجشحشخشرسرصرضراًتجمتحجتحمتخمتمجتمحتمخحميحمىسحجسجحسجىسمحسمجسممصححصممشحمشجيشمخشممضحىضخمطمحطممطميعجمعممعمىغممغميغمىفخمقمحقمملحملحيلحىلججلخملمحمحجمحيمجحمخممجخهمجهممنحمنحىنجمنجىنمينمىيممبخيتجيتجىتخيتخىتميتمىجميجحىجمىسخىصحيشحيضحيلجيلمييجييميمميقمينحيعميكمينجحمخيلجمكممجحيحجيمجيفميبحيسخينجيصلےقلےاللهاكبرمحمدصلعمرسولعليهوسلمصلىصلى الله عليه وسلمجل جلالهریال,、〖〗—–_{}〔〕【】《》「」『』[]#&*-<>\\$%@ ًـًـّ ْـْءآأؤإةلآلألإ\"'^|~⦅⦆・ゥャ¢£¬¦¥₩│←↑→↓■○𐐨𐐩𐐪𐐫𐐬𐐭𐐮𐐯𐐰𐐱𐐲𐐳𐐴𐐵𐐶𐐷𐐸𐐹𐐺𐐻𐐼𐐽𐐾𐐿𐑀𐑁𐑂𐑃𐑄𐑅𐑆𐑇𐑈𐑉𐑊𐑋𐑌𐑍𐑎𐑏𐓘𐓙𐓚𐓛𐓜𐓝𐓞𐓟𐓠𐓡𐓢𐓣𐓤𐓥𐓦𐓧𐓨𐓩𐓪𐓫𐓬𐓭𐓮𐓯𐓰𐓱𐓲𐓳𐓴𐓵𐓶𐓷𐓸𐓹𐓺𐓻𐖗𐖘𐖙𐖚𐖛𐖜𐖝𐖞𐖟𐖠𐖡𐖣𐖤𐖥𐖦𐖧𐖨𐖩𐖪𐖫𐖬𐖭𐖮𐖯𐖰𐖱𐖳𐖴𐖵𐖶𐖷𐖸𐖹𐖻𐖼ːˑʙʣꭦʥʤᶑɘɞʩɤɢʛʜɧʄʪʫ𝼄ꞎɮ𝼅ʎ𝼆ɶɷɺ𝼈ɾʨʦꭧʧⱱʏʡʢʘǀǁǂ𝼊𝼞𐳀𐳁𐳂𐳃𐳄𐳅𐳆𐳇𐳈𐳉𐳊𐳋𐳌𐳍𐳎𐳏𐳐𐳑𐳒𐳓𐳔𐳕𐳖𐳗𐳘𐳙𐳚𐳛𐳜𐳝𐳞𐳟𐳠𐳡𐳢𐳣𐳤𐳥𐳦𐳧𐳨𐳩𐳪𐳫𐳬𐳭𐳮𐳯𐳰𐳱𐳲𑣀𑣁𑣂𑣃𑣄𑣅𑣆𑣇𑣈𑣉𑣊𑣋𑣌𑣍𑣎𑣏𑣐𑣑𑣒𑣓𑣔𑣕𑣖𑣗𑣘𑣙𑣚𑣛𑣜𑣝𑣞𑣟𖹠𖹡𖹢𖹣𖹤𖹥𖹦𖹧𖹨𖹩𖹪𖹫𖹬𖹭𖹮𖹯𖹰𖹱𖹲𖹳𖹴𖹵𖹶𖹷𖹸𖹹𖹺𖹻𖹼𖹽𖹾𖹿𝅗𝅥𝅘𝅥𝅘𝅥𝅮𝅘𝅥𝅯𝅘𝅥𝅰𝅘𝅥𝅱𝅘𝅥𝅲𝆹𝅥𝆺𝅥𝆹𝅥𝅮𝆺𝅥𝅮𝆹𝅥𝅯𝆺𝅥𝅯ıȷ∇∂ӏ𞤢𞤣𞤤𞤥𞤦𞤧𞤨𞤩𞤪𞤫𞤬𞤭𞤮𞤯𞤰𞤱𞤲𞤳𞤴𞤵𞤶𞤷𞤸𞤹𞤺𞤻𞤼𞤽𞤾𞤿𞥀𞥁𞥂𞥃ٮڡٯ0,1,2,3,4,5,6,7,8,9,〔s〕wzhvsdppvwcmrdjほかココ字双多解交映無前後再新初終販声吹演投捕遊指打禁空合満申割営配〔本〕〔三〕〔二〕〔安〕〔点〕〔打〕〔盗〕〔勝〕〔敗〕得可丽丸乁𠄢你侻倂偺備像㒞𠘺兔兤具𠔜㒹內𠕋冗冤仌冬𩇟刃㓟刻剆剷㔕包匆卉博即卽卿𠨬灰及叟𠭣叫叱吆咞吸呈周咢哶唐啓啣善喫喳嗂圖圗噑噴壮城埴堍型堲報墬𡓤売壷夆夢奢𡚨𡛪姬娛娧姘婦㛮嬈嬾𡧈寃寘寳𡬘寿将㞁屠峀岍𡷤嵃𡷦嵮嵫嵼巡巢㠯巽帨帽幩㡢𢆃㡼庰庳庶𪎒𢌱舁弢㣇𣊸𦇚形彫㣣徚忍志忹悁㤺㤜𢛔惇慈慌慺憲憤憯懞戛扝抱拔捐𢬌挽拼捨掃揤𢯱搢揅掩㨮摩摾撝摷㩬敬𣀊旣書晉㬙㬈㫤冒冕最暜肭䏙朡杞杓𣏃㭉柺枅桒𣑭梎栟椔楂榣槪檨𣚣櫛㰘次𣢧歔㱎歲殟殻𣪍𡴋𣫺汎𣲼沿泍汧洖派浩浸涅𣴞洴港湮㴳滇𣻑淹潮𣽞𣾎濆瀹瀛㶖灊災灷炭𠔥煅𤉣熜爨牐𤘈犀犕𤜵𤠔獺王㺬玥㺸瑇瑜璅瓊㼛甤𤰶甾𤲒𢆟瘐𤾡𤾸𥁄㿼䀈𥃳𥃲𥄙𥄳眞真瞋䁆䂖𥐝硎䃣𥘦𥚚𥛅秫䄯穊穏𥥼𥪧䈂𥮫篆築䈧𥲀糒䊠糨糣紀𥾆絣䌁緇縂繅䌴𦈨𦉇䍙𦋙罺𦌾羕翺𦓚𦔣聠𦖨聰𣍟䏕育脃䐋脾媵𦞧𦞵𣎓𣎜舄辞䑫芑芋芝劳花芳芽苦𦬼茝荣莭茣莽菧荓菊菌菜𦰶𦵫𦳕䔫蓱蓳蔖𧏊蕤𦼬䕝䕡𦾱𧃒䕫虐虧虩蚩蚈蜎蛢蜨蝫螆蟡蠁䗹衠𧙧裗裞䘵裺㒻𧢮𧥦䚾䛇誠𧲨貫賁贛起𧼯𠠄跋趼跰𠣞軔𨗒𨗭邔郱鄑𨜮鄛鈸鋗鋘鉼鏹鐕𨯺開䦕閷𨵷䧦雃嶲霣𩅅𩈚䩮䩶韠𩐊䪲𩒖頩𩖶飢䬳餩馧駂駾䯎𩬰鱀鳽䳎䳭鵧𪃎䳸𪄅𪈎𪊑䵖黾鼅鼏鼖𪘀";function at(t){return t>=196608?t>=917760&&t<=917999?18874368:0:it[st[t>>4]][15&t]}function ct(t,n,o){const r=[],e=a(t);for(let t=0;t<e.length;t++){const i=e[t],s=c([e[t]]),l=at(i),a=l>>23,f=l>>21&3,u=l>>5&65535,h=31&l,d=lt.substr(u,h);if(0===f||n&&1&a)throw new Error("Illegal char "+s);1===f?r.push(d):2===f?r.push(o?d:s):3===f&&r.push(s);}return r.join("").normalize("NFC")}function ft(t,n,o){void 0===o&&(o=!1);let r=ct(t,o,n).split(".");return r=r.map((function(t){return t.startsWith("xn--")?ut(t=h(t.substring(4)),o,!1):ut(t,o,n),t})),r.join(".")}function ut(t,n,o){if("-"===t[2]&&"-"===t[3])throw new Error("Failed to validate "+t);if(t.startsWith("-")||t.endsWith("-"))throw new Error("Failed to validate "+t);if(t.includes("."))throw new Error("Failed to validate "+t);if(ct(t,n,o)!==t)throw new Error("Failed to validate "+t);const r=t.codePointAt(0);if(at(r)&2<<23)throw new Error("Label contains illegal character: "+r)}function ht(t,n){void 0===n&&(n={});const o=!("transitional"in n)||n.transitional,r="useStd3ASCII"in n&&n.useStd3ASCII,e="verifyDnsLength"in n&&n.verifyDnsLength,i=ft(t,o,r).split(".").map(d),s=i.join(".");let l;if(e){if(s.length<1||s.length>253)throw new Error("DNS name has wrong length: "+s);for(l=0;l<i.length;l++){const t=i[l];if(t.length<1||t.length>63)throw new Error("DNS label has wrong length: "+t)}}return s}function dt(t){const n=Array.isArray(t);n||(t=[t]);const o={IDN:[],PC:[]};return t.forEach((t=>{let n,r;try{n=ht(t,{transitional:!t.match(/\.(?:be|ca|de|fr|pm|re|swiss|tf|wf|yt)\.?$/)}),r={PC:n,IDN:mt(n)};}catch(n){r={PC:t,IDN:t};}o.PC.push(r.PC),o.IDN.push(r.IDN);})),n?o:{IDN:o.IDN[0],PC:o.PC[0]}}function mt(t,n){void 0===n&&(n={});return ft(t,!1,"useStd3ASCII"in n&&n.useStd3ASCII)}

class UniqueObjectCache {
	constructor(sessionKey) {
		this.sessionKey = `cnic${activeLanguage}${sessionKey}`;
	}

	get _sessionKey() {
		return this.sessionKey;
	}

	set _sessionKey(key) {
		this.sessionKey = `cnic${activeLanguage}${key}`;
	}

	cacheKey(key) {
		return (
			key?.idnDomainName || key?.domainName || key?.key || this._sessionKey
		);
	}

	cacheObject(object, singleData = false) {
		const key = this.cacheKey(object);
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};
		if (singleData && !cache) {
			return sessionStorage.setItem(this._sessionKey, JSON.stringify(cache));
		}
		if (!cache[key]) {
			cache[key] = object;
			sessionStorage.setItem(this._sessionKey, JSON.stringify(cache));
		}
	}

	findCacheObject(object, getData = false) {
		const key = this.cacheKey(object);
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};

		if (getData && cache[key]) {
			return cache[key];
		}
		if (!cache[key]) {
			return false;
		}
		return true;
	}

	deleteDomainCache(domain) {
		const key = this.cacheKey({domainName: domain});
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};

		if (typeof cache[key] === undefined) {
			return false;
		}

		delete cache[key];
		sessionStorage.setItem(this._sessionKey, JSON.stringify(cache));
		return true;
	}

	clearCache() {
		sessionStorage.removeItem(this._sessionKey);
	}

	getCache() {
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};
		return Object.values(cache);
	}
}

class Util {
	static updateCurrentURLState() {
		var queryParams = new URLSearchParams(window.location.search);

		// Set new or modify existing parameter value.
		queryParams.set('searchTerm', this.session.searchTerm);

		// Replace current querystring with the new one.
		history.replaceState(null, null, '?' + queryParams.toString());
	}

	static async fetchData(data) {
		const formData = new FormData();
		let url = `${cnicWebRootPath}/mydomainsearch.php`;
		const requestType = data.type;
		const searchTerm = data.searchTerm || '';
		const searchPage = data.searchPage || 1;
		const searchAction = data.searchAction || '';
		const advancedOptions = this.session.advancedOptions || [];

		formData.append('token', csrfToken);

		switch (requestType) {
			case 'addToCart':
				url = `${cnicWebRootPath}/cart.php`;
				formData.append('a', requestType);
				formData.append('sideorder', 0);
				formData.append('whois', data.domainPremium ? 1 : 0);
				formData.append('domain', data.domainPc);
				break;
			case 'addDomainTransfer':
				url = `${cnicWebRootPath}/cart.php`;
				formData.append('a', requestType);
				formData.append('domain', data.domainPc);
				if (data.eppcode !== 'true' && data.eppcode?.length > 0) {
					formData.append('epp', data.eppcode);
				}
				break;
			case 'removeFromCart':
				formData.append('action', 'cart');
				formData.append('type', 'remove');
				formData.append('idnDomain', data.domainIdn);
				break;
			case 'updateCart':
				url = `${cnicWebRootPath}/cart.php`;
				formData.append('a', 'updateDomainPeriod');
				formData.append('period', data.domainPeriod);
				formData.append('domain', data.domainPc);
				break;
			case 'getCartDomains':
				formData.append('action', 'cart');
				formData.append('type', 'list');
				break;
			case 'config':
				formData.append('action', 'loadconfiguration');
				break;
			case 'tldsPricing':
				formData.append('action', 'tldsPricing');
				formData.append('request', data.request);
				break;
			case 'clearCache':
				formData.append('action', 'clearCache');
				break;
			case 'cnicDomainSearchLoadMore':
				if (searchAction === 'suggestions') {
					formData.append('action', searchAction);
					formData.append('page', searchPage);
					formData.append('last', JSON.stringify(data.lastResults));
					formData.append('total', JSON.stringify(data.totalResults));
					if (advancedOptions.length) {
						formData.append('advancedOptions', advancedOptions);
					}
					this.updateCurrentURLState();
					break;
				}
			default: // fallback to search request type
				formData.append('action', searchAction);
				if (advancedOptions.length) {
					formData.append('advancedOptions', advancedOptions);
				}
				this.updateCurrentURLState();
				break;
		}

		let groupList = [];
		let promises = [];
		// Check if search action is "register" and search term exists
		if (searchAction === 'register') {
			if (!searchTerm) {
				return; // Exit early if search term is empty
			}
			groupList = this.buildGroupList(
				this.getPunyCodeName(searchTerm, false),
				searchPage,
			);
		} else if (searchAction === 'suggestions') {
			if (!searchTerm) {
				return; // Exit early if search term is empty
			}
			formData.append('searchTerm', this.getPunyCodeName(searchTerm));
		}

		if (!groupList.length) {
			if (searchPage === 1 && searchAction === 'suggestions') {
				// raw search parameter to track search logs
				formData.append('rawSearchTerm', searchTerm);
			}
			promises.push(this.fetchApi(url, formData));
		} else {
			groupList.forEach((group, index) => {
				const cleanedGroup = group.map(domain => {
					const {order, tld, registrationPrice, renewPrice, ...cleanedDomain} =
						domain;
					return cleanedDomain;
				});

				formData.set('search', JSON.stringify(cleanedGroup));
				if (searchPage === 1 && index === 0) {
					// raw search parameter to track search logs
					formData.append('rawSearchTerm', searchTerm);
				}
				promises.push(this.fetchApi(url, formData));
			});
		}

		return promises;
	}

	static async fetchApi(url, formData) {
		const response = await fetch(url, {
			method: 'POST',
			body: formData,
		});
		let responseData = [];
		if (!response.ok) {
			$(document).ready(function () {
				$('search-engine').before(
					"<center><h1>Oops! Something went wrong.</h1><br /> Please try reloading the page and give it another shot.<br /><br /> If you're an admin, please double-check your configurations to ensure everything is set up correctly.</center><br /><br />",
				);
			});
			throw new Error('Network response was not ok');
		}
		try {
			responseData = await response.json();
		} catch (error) {
			return console.error('Error:', error.message);
		}
		return responseData;
	}

	static getPunyCodeName(keyword, stringify = true) {
		const lines = keyword
			.trim()
			.split(/\n/)
			.map(line => line.trim());
		const punyCodeNames = [];

		for (const line of lines) {
			const words = line.split(/\s+/).map(word => word.trim()); // multi-keyword search
			const keywords = [];
			for (const word of words) {
				if (word.length === 0) {
					continue;
				}

				try {
					let newKeyword;

					if (!/\./.test(word)) {
						newKeyword = dt(word).IDN;
						keywords.push({keyword: newKeyword}); // generate a domain list
					} else {
						let domain = word;
						if (!/http/gi.test(word)) {
							domain = 'https://' + domain;
						}
						domain = new URL(domain);
						const unicodeDomain = mt(domain.hostname);
						newKeyword = dt(this.getDomain(unicodeDomain)).IDN;
						keywords.push({exact: this.cleanUpSearchKeyword(newKeyword)}); // exact domain search
					}
				} catch (e) {
					// ignore errors
				}
			}

			if (keywords.length > 0) {
				punyCodeNames.push(...keywords);
			}
		}
		if (!stringify) {
			return punyCodeNames.flat(1);
		}
		return JSON.stringify(punyCodeNames);
	}

	static get params() {
		return new Proxy(new URLSearchParams(window.location.search), {
			get: function (searchParams, prop) {
				if (prop === 'getAll') {
					return searchParams.toString();
				}
				return searchParams.get(prop);
			},
			set: (searchParams, prop, value) => {
				if (value) {
					searchParams.set(prop, value);
				} else {
					searchParams.delete(prop);
				}
				const newUrl = `${window.location.protocol}//${window.location.host}${
					window.location.pathname
				}?${searchParams.toString()}`;
				window.history.pushState({path: newUrl}, '', newUrl);
				return newUrl;
			},
		});
	}

	static get session() {
		return new Proxy(sessionStorage, {
			get: function (storage, prop) {
				prop = 'cnic' + prop;
				const item = storage.getItem(prop) || null;
				return JSON.parse(item);
			},
			set: (storage, prop, value) => {
				prop = 'cnic' + prop;
				value = JSON.stringify(value);
				if (value.length > 0) {
					storage.setItem(prop, value);
				}
				return true;
			},
			deleteProperty: (storage, prop) => {
				prop = 'cnic' + prop;
				if (storage.getItem(prop)) {
					storage.removeItem(prop);
				}
				return true;
			},
		});
	}

	static availabilityCompareFn(a, b) {
		a = a.isAvailable;
		b = b.isAvailable;
		// if a is available and b is not available
		if (a && !b) {
			return -1;
		}
		// if a is not available and b is available
		if (!a && b) {
			return 1;
		}
		// a must be equal to b
		return 0;
	}

	static ordinalSuffixOf(i) {
		var j = i % 10,
			k = i % 100;
		if (j == 1 && k != 11) {
			return `${i}<span class="Text-size-xsmall_superscript">st</span>`;
		}
		if (j == 2 && k != 12) {
			return `${i}<span class="Text-size-xsmall_superscript">nd</span>`;
		}
		if (j == 3 && k != 13) {
			return `${i}<span class="Text-size-xsmall_superscript">rd</span>`;
		}
		return `${i}<span class="Text-size-xsmall_superscript">th</span>`;
	}

	static toggleButtons(element, inputs) {
		let value = element.target.value;
		let inputElements = [];
		inputs.forEach(input => {
			let label = input.labels[0];
			if (input.value === value) {
				inputElements['check'] = {class: label.className, element: label};
			} else {
				inputElements['uncheck'] = {class: label.className, element: label};
			}
		});
		let tmpEl = inputElements['check'].element;
		tmpEl.className = inputElements['uncheck'].class;
		tmpEl = inputElements['uncheck'].element;
		tmpEl.className = inputElements['check'].class;
	}

	static cleanUpSearchKeyword(keyword) {
		if (!keyword) {
			return false;
		}
		const invalidChars =
			/(~|`|!|@|#|\$|%|\^|&|\*|\(|\)|_|\+|=|{|}|\[|\]|\||\\|;|:|"|'|<|>|,|\?|\/)/g;
		return keyword.trim().replace(invalidChars, '');
	}

	static getDomain(keyword) {
		// Check if the tlds array has already been initialized
		if (!this.session?.allTlds) {
			let tlds = [];
			const categories = this.session.config.categories;
			categories.forEach(category => {
				const tmpTlds = category.tlds;
				tlds = {...tlds, ...tmpTlds};
			});
			this.session.allTlds = tlds;
		}

		// Loop through the tlds to find a match with the keyword
		const findTld = this.isValidDomain(keyword);

		if (!findTld) {
			// If no match is found, return the original keyword
			return keyword;
		}

		// If a match is found, extract the domain name from the keyword and return it with the matching tld
		const domainName = keyword.slice(0, -findTld.length).replace(/\./g, '');
		return `${domainName}.${findTld}`;
	}

	static isValidDomain(keyword) {
		// Check if the tlds array has already been initialized
		if (!this.session?.allTlds) {
			let tlds = [];
			const categories = this.session.config.categories;
			categories.forEach(category => {
				const tmpTlds = category.tlds;
				tlds = {...tlds, ...tmpTlds};
			});
			this.session.allTlds = tlds;
		}

		// Loop through the tlds to find a match with the keyword
		const tldFound =
			Object.keys(this.session.allTlds).find(tld => keyword.endsWith(tld)) ||
			false;

		// If no match is found, return the original keyword
		return tldFound;
	}

	static searchBulkMode(keyword, bulk) {
		if (this.params.action !== 'transfer') {
			if (bulk) {
				keyword = keyword.replace(/\s/g, '\n');
			} else {
				keyword = keyword.replace(/\n/g, ' ');
			}
		}

		return keyword;
	}

	static deleteValueFromArray(array, key, value) {
		for (let i = 0; i < array.length; i++) {
			if (array[i][key] === value) {
				array.splice(i, 1);
				i--; // update loop index to account for removed element
			}
		}
		return array;
	}

	static findValueInArray(array, value, key = null) {
		if (!key) {
			return array.find(obj => obj.type === value);
		}

		if (key === 'suggest') {
			return array.find(
				obj =>
					obj.suggest === value.domainName ||
					obj.suggest === value.idnDomainName,
			);
		} else {
			return array.some(obj => obj[key] === value || obj[key] === value);
		}
	}

	static buildDomainList(data, searchType, searchTerm, firstRequest) {
		if (searchType === 'transfer') {
			return this.buildDomainTransferList(searchTerm);
		}
		let domainSuggestionList = [];
		let domainBaseList = [];

		// Check if data exists and has "suggestions" or "exact" properties
		if (
			!data ||
			(!data.hasOwnProperty('suggestions') && !data.hasOwnProperty('exact'))
		) {
			return;
		}

		// Loop through each type of data
		for (const type of Object.keys(data)) {
			if (type === 'info') {
				continue;
			}

			// Get the list of domains for the current data type
			const domains = data[type];

			// Create a temporary list to store the reformatted domains
			const tmpList = [];

			// Loop through each domain in the list
			for (const domain of Object.values(domains)) {
				// Skip domains without pricing information
				if (!domain.pricing) {
					continue;
				}

				// Get domain properties
				const {
					domainName,
					tld,
					idnDomainName,
					pricing: domainPricing,
					status: domainStatus,
					group: domainGroup,
					isAvailable,
					isPremium,
					isAftermarket,
					tldSupported,
					availabilityReason,
				} = domain;
				let isBaseDomain = false;

				// Set isBaseDomain to true for exact search domains
				if (type === 'exact') {
					isBaseDomain = true;
				}

				let addToCart = false;
				let cartItemType = '';
				let registerPeriod = domain.shortestPeriod.period;

				// Add reformatted domain to temporary list
				const domainObject = {
					domainName,
					tld,
					idnDomainName,
					domainPricing,
					domainStatus,
					domainGroup,
					addToCart,
					cartItemType,
					isAvailable,
					tldSupported,
					isPremium,
					isAftermarket,
					isBaseDomain,
					registerPeriod,
					availabilityReason,
				};

				// add domain object to caching
				const cachedData = new UniqueObjectCache('CachedDomainList');
				cachedData.deleteDomainCache(domainName);
				cachedData.cacheObject(domainObject);

				tmpList.push(domainObject);
			}

			// Add temporary list to the appropriate domain list property
			if (type === 'suggestions') {
				domainSuggestionList = tmpList;
			} else if (type === 'exact') {
				domainBaseList = tmpList.sort(this.availabilityCompareFn);
			}
		}

		let returnData = {domainBaseList, domainSuggestionList};
		if (data.info?.total) {
			returnData = {...returnData, info: data.info};
		}
		return returnData;
	}

	static sortByTlds(tlds) {
		return Object.keys(tlds).sort((a, b) => tlds[a] - tlds[b]);
	}

	static sortDomainList(a, b) {
		// destructuring to get the values from the objects
		const {order: orderA, tld: tldA, suggest: suggestA} = a;
		const {order: orderB, tld: tldB, suggest: suggestB} = b;

		// Parse the order values only once
		const orderNumA = parseInt(orderA);
		const orderNumB = parseInt(orderB);

		// Get the sort and sort order from the Util params
		const {sort, sortDir} = Util.params ?? {};
		const sortOrder = sortDir === 'DESC' ? -1 : 1;

		// handle different sort cases
		switch (sort) {
			case 'TldOrder':
				return (orderNumA - orderNumB) * sortOrder;
			case 'TldName':
				if (tldA && tldB) {
					// Use localeCompare to compare strings
					return (
						tldA.localeCompare(tldB, undefined, {
							sensitivity: 'base',
						}) * sortOrder
					);
				}
			case 'DomainName':
				if (suggestA && suggestB) {
					// Use localeCompare to compare strings
					return (
						suggestA
							.replace('.', ' ')
							.localeCompare(suggestB.replace('.', ' '), undefined, {
								sensitivity: 'base',
							}) * sortOrder
					);
				}
			// case "RegistrationPrice":
			// case "RenewPrice":
			//     if (tldA && tldB) {
			//         // Use optional chaining and nullish coalescing to get the prices
			//         const tldsPricing = (sort === "RegistrationPrice" ? Util.session.tldsRegisterPricing : Util.session.tldsRenewPricing) ?? [];
			//         const priceA = tldsPricing[tldA] ?? 10000;
			//         const priceB = tldsPricing[tldB] ?? 10000;
			//         if (sortOrder === -1) {
			//             return priceA - priceB;
			//         } else {
			//             return priceB - priceA;
			//         }
			//     }
			//     break;
			default:
				return (orderNumA - orderNumB) * sortOrder;
		}
	}

	static sortDomainByOrder(a, b) {
		return parseInt(a.order) - parseInt(b.order);
	}

	static filterTlds(item) {
		const {filter, filterPriceRange: range} = Util.params ?? [];
		if (item?.exact?.length > 0 || !filter) {
			// exclude filtering of exact domain searches
			return true;
		}
		return filter === 'RegistrationPrice'
			? item.registrationPrice <= range
			: item.renewPrice <= range;
	}

	static buildGroupList(searchTerms, searchPage = 1) {
		let tlds = {};
		if (!this.session?.sortedTlds) {
			const categories = this.session.config.categories;
			let selectedCategories = this.session.selectedTldCategories;
			if (!selectedCategories?.length) {
				selectedCategories = categories;
			}

			selectedCategories.forEach(category => {
				const tmpCat =
					category.tlds ||
					categories.find(categoryTlds => category === categoryTlds.id)?.tlds ||
					{};
				tlds = {...tlds, ...tmpCat};
			});

			Util.session.sortedTlds = this.sortByTlds(tlds);
		}

		tlds = Util.session.sortedTlds;

		const domainSet = new Set();
		let domainList = [];
		searchTerms.forEach(search => {
			if (search.exact && !domainSet.has(search.exact)) {
				domainSet.add(search.exact);
				domainList.unshift({exact: search.exact});
			} else if (search.keyword) {
				const suggest = `${search.keyword}.`;

				tlds.forEach((tld, j) => {
					const value = {suggest: suggest + tld, tld, order: j + 1};

					const tldsRegisterPricing = Util.session.tldsRegisterPricing ?? [];
					const tldsRenewPricing = Util.session.tldsRenewPricing ?? [];

					if (tldsRegisterPricing && tldsRenewPricing) {
						value.registrationPrice = tldsRegisterPricing[value.tld];
						value.renewPrice = tldsRenewPricing[value.tld];
					}
					domainList.push(value);
				});
			}
		});

		domainList = domainList.sort(this.sortDomainList).filter(this.filterTlds);
		Util.session.domainList = domainList;

		if (!searchPage || searchPage === 0) {
			searchPage = 1;
		}

		const resultsPerPage = searchPage * 12;
		let domainListCurrentPage = domainList.splice(
			Util.session.lastResult || 0,
			12,
		);
		// Use arrow functions instead of function expressions
		domainListCurrentPage = domainListCurrentPage.filter(domain => {
			const domainName = domain.suggest || domain.exact;
			if (domainName.length > 0) {
				// Use const instead of let for variables that are not reassigned
				const cachedData = new UniqueObjectCache('CachedDomainList');
				// Use shorthand property names for objects
				const data = cachedData.findCacheObject({domainName});
				if (data === false) {
					return domain;
				}
			}
		});

		const groups = domainListCurrentPage;
		this.session.lastResult = resultsPerPage + 1;
		this.session.totalResults = domainList.length;

		const result = [];
		let exp = 0;
		while (groups.length) {
			result.push(groups.splice(0, 2 ** exp));
			if (++exp > 3) {
				exp = 0;
			}
		}
		return result;
	}

	static getCachedDomains(domains, page, type) {
		const cachedData = new UniqueObjectCache('CachedDomainList');
		const cachedDomains = cachedData.getCache();
		if (!cachedDomains.length) {
			return {};
		}

		const currentPageResults = 12 * page; // get total items in the group
		const lastResultIndex = page > 1 ? this.session.lastResult : 0;
		const domainList = this.session.domainList.splice(
			lastResultIndex,
			currentPageResults,
		);

		const result = domainList
			.map(domain => (type === 'baseList' ? domain.exact : domain.suggest))
			.reduce((result, domainName) => {
				const find = cachedDomains.find(
					dom => dom.idnDomainName === domainName,
				);
				if (
					type === 'baseList' &&
					typeof find?.isBaseDomain !== 'undefined' &&
					!find.isBaseDomain
				) {
					find.isBaseDomain = true;
				} else if (type === 'suggestionList' && find?.isBaseDomain) {
					find.isBaseDomain = false;
				}

				if (domains.length) {
					const domainExistsInDomainsList = domains.some(
						domain => domain.idnDomainName === domainName,
					);
					if (find && !domainExistsInDomainsList) {
						result.push(find);
					}
				} else {
					if (find) {
						result.push(find);
					}
				}

				return result;
			}, []);

		domains.push(...result);
	}

	static getDomainsWithEpp(keyword) {
		const lines = keyword
			.trim()
			.split(/\n/)
			.map(line => line.trim());
		const keywords = [];
		for (const line of lines) {
			const words = line.split(/\s+/).map(word => word.trim()); // multi-keyword search
			let lastIndexKey = '';
			for (const word of words) {
				if (word.length === 0) {
					return;
				}

				try {
					if (!/\./.test(word) && keywords[lastIndexKey]) {
						keywords[lastIndexKey] = word;
					} else if (/\./.test(word)) {
						const domain = new URL(`https://${word}`);
						const unicodeDomain = mt(domain.hostname);
						lastIndexKey = unicodeDomain;
						keywords[unicodeDomain] = true; // exact domain search
					}
				} catch (e) {
					// ignore errors
				}
			}
		}
		return keywords;
	}

	static buildDomainTransferList(searchTerms) {
		const domainsWithEpp = this.getDomainsWithEpp(searchTerms);
		const categories = this.session.config.categories;
		let eppNotProvided = 0;

		this.updateCurrentURLState();
		if (!this.session?.allTlds) {
			let tlds = [];
			categories.forEach(category => {
				const tmpTlds = category.tlds;
				tlds = {...tlds, ...tmpTlds};
			});
			this.session.allTlds = tlds;
		}
		const domainObjects = domainsWithEpp
			? Object.entries(domainsWithEpp)
					.map(domain => {
						if (domain.at(0)) {
							const tldRegex = /[.]{1}[A-Za-z]{2,}$/; // Matches the last dot followed by 2 or more letters
							const tld = domain[0].match(tldRegex)[0].substring(1);
							const tldNotRequireEppCode = Object.keys(
								Util.session.config.tldsWithoutEppCode,
							).includes(tld);
							let tldFound = false;
							if (tld) {
								tldFound = Object.keys(this.session.allTlds).includes(tld); // Exclude the dot from the result
							}
							if (!tldNotRequireEppCode && domain[1] === true) {
								eppNotProvided += 1;
							}

							return {
								domainName: domain[0],
								idnDomainName: domain[0],
								eppCode: domain[1] !== true ? domain[1] : tldNotRequireEppCode,
								domainPricing: [],
								shortestPeriod: [],
								isBaseDomain: true,
								isAvailable: false,
								tldSupported: tldFound,
								addToCart: false,
								domainTld: tld,
								domainStatus: tldFound ? 'registered' : 'tldnotsupported',
							};
						}
					})
					.filter(dom => dom !== undefined)
			: [];

		return {
			domainBaseList: domainObjects,
			domainSuggestionList: [],
			eppNotProvided: eppNotProvided,
		};
	}

	/**
	 * Trims the middle of a string and replaces it with "..." if the length of the string exceeds the specified length.
	 *
	 * @param {String} string
	 * @param {Number} length
	 * @returns String : the trimmed string
	 */
	static trimMiddleString(string, maxLength = 35, separator = ' ... ') {
		if (string.length <= maxLength) {
			return string;
		}

		const parts = string.split('.');
		const first = parts[0];
		const frontWeightage = 3; // higher shows less characters
		const backWeightage = 4;
		const frontChars = Math.ceil(maxLength / frontWeightage);
		const backChars = Math.floor(maxLength / backWeightage);

		const start = first.slice(0, frontChars);
		const end =
			first.slice(first.length - backChars) +
			'.' +
			parts.splice(1, parts.length - 1);

		return `${start}${separator}${end}`;
	}

	static initTooltip(element) {
		if (typeof bootstrap !== 'undefined') {
			jQuery(element).tooltip({
				selector: '[data-toggle=tooltip]',
				placement: 'left',
			});
			jQuery(element).popover({
				selector: '[data-toggle=popover]', // Define the selector for elements that trigger the popover
				trigger: 'hover | focus | manual',
				container: 'body',
				html: true,
				placement: 'auto',
				// Add any other popover options you need here
			});
		}
	}

	static async fetchTemplate(path) {
		if (/\./g.test(path)) {
			path = path.split('.');
			path = path[0];
		}

		const cacheKey = path + themeVersion;
		const cachedData = new UniqueObjectCache(cacheKey);

		// to enable/disable html file caching add/remove the comments below
		const htmlData = cachedData.findCacheObject(cacheKey, true);
		if (htmlData) {
			return htmlData;
		}
		// to enable/disable html file caching add/remove the comments above

		const response = await fetch(
			`${cnicSearchClientThemePath}html_components/${path}.html?version=${themeVersion}`,
		);
		const template = await response.text();
		cachedData.cacheObject(template, true);
		return template;
	}

	static async waitForElement(selector, element) {
		return new Promise(resolve => {
			const checkElement = () => {
				const targetElement = element.renderRoot?.querySelector(selector);
				if (targetElement) {
					resolve(targetElement);
				} else {
					requestAnimationFrame(checkElement);
				}
			};

			checkElement();
		});
	}
}

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class e extends i$1{constructor(i){if(super(i),this.et=T$1,i.type!==t$1.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(r){if(r===T$1||null==r)return this.vt=void 0,this.et=r;if(r===w$1)return r;if("string"!=typeof r)throw Error(this.constructor.directiveName+"() called with a non-string value");if(r===this.et)return this.vt;this.et=r;const s=[r];return s.raw=s,this.vt={_$litType$:this.constructor.resultType,strings:s,values:[]}}}e.directiveName="unsafeHTML",e.resultType=1;const o=e$2(e);

class Translations {
	static localize = null;
	static supportedLanguages = ['english', 'arabic', 'german', 'portuguese-br'];
	static defaultLanguage = 'english';
	static maxRetries = 10;

	static async loadTranslations(baseUrl, locale, retries = 0) {
		locale = Translations.supportedLanguages.includes(locale)
			? locale
			: Translations.defaultLanguage;

		const messageUrl = `${baseUrl}languages/${locale}.json?version=${themeVersion}`;

		try {
			const response = await fetch(messageUrl);

			if (!response.ok) {
				if (retries < Translations.maxRetries) {
					return Translations.loadTranslations(
						baseUrl,
						Translations.defaultLanguage,
						retries + 1,
					);
				} else {
					throw new Error('Failed to load translations');
				}
			}

			const messages = await response.json();

			Translations.localize = messages;
		} catch (error) {
			console.error(error);
		}
	}

	static getMessage(key, label, rawData) {
		if (!Translations.localize) {
			throw new Error('Translations not initialized');
		}

		key = key.replace(/\s/gi, '_', key).toLowerCase();
		const translation = Translations.localize[key];

		if (!translation || !translation.length) {
			return key;
		}

		if (rawData) {
			return translation;
		}

		if (!label) {
			return this.htmlWrapper(translation);
		}

		return this.replaceLabels(translation, label);
	}

	static replaceLabels(translation, label) {
		const regex = /##(\w+)##/gi;
		const replacedTranslation = translation.replace(
			regex,
			(match, keyword) =>
				label[keyword] || (typeof label !== 'object' ? label : match),
		);
		return this.htmlWrapper(replacedTranslation);
	}

	static htmlWrapper(text) {
		const htmlTagRegex = /<[^>]+>/g;
		if (!htmlTagRegex.test(text)) {
			return text;
		}
		return x$1`${o(text)}`;
	}
}

await Translations.loadTranslations(cnicSearchClientThemePath, activeLanguage);

const translation = Translations.localize;
const getMessage = (key, label = null, rawData = false) => {
	return Translations.getMessage(key, label, rawData);
};

class LoadCss {
	static async fetchCSS() {
		const style = await fetch(
			cnicFontawesomePath + '?version=' + themeVersion,
			{method: 'get'},
		);
		const fontStyle = await fetch(
			cnicSearchClientThemePath + '/css/style.css?version=' + themeVersion,
			{method: 'get'},
		);
		let cssText = '';

		if (style.ok && fontStyle.ok) {
			cssText += await fontStyle.text();
			cssText += await style.text();
		}

		return cssText;
	}

	static async init() {
		const cssData = await LoadCss.fetchCSS();
		return cssData;
	}
}

const cssData = await LoadCss.init();

class TopTabs extends s$1 {
	static properties = {
		tabs: {type: Array},
	};

	constructor() {
		super();
	}

	generateTabs() {
		return this.tabs.map(tab => {
			const id = 'tab-' + tab;
			const label = getMessage('tab_label_' + tab);
			const headingId = 'tabHeading-' + tab;
			const headingLabel = getMessage('tab_heading_' + tab);
			return {id, label, headingId, headingLabel, tab};
		});
	}

	render() {
		const bindings = {tabs: this.generateTabs()};

		return x$1`<load-template
			path="tabs"
			.bindings=${bindings}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('top-tabs', TopTabs);

class SearchEngine extends s$1 {
	static get styles() {
		return i$4`
			${r$4(cssData)}
		`;
	}

	static properties = {
		searchAction: {
			hasChanged(value, oldValue) {
				Util.session.searchAction = value;
				return value !== oldValue;
			},
		},
		searchConfig: {
			type: Object,
			hasChanged(value, oldValue) {
				return value !== oldValue;
			},
		},
		tabs: {},
		cacheInterval: {},
	};

	constructor() {
		super();
		this._clearCache();
		this.searchAction =
			Util.params.action?.length > 0 ? Util.params.action : 'home';
		this._loadConfiguration();
		this.addEventListener('cnicUrlUpdate', this._handleCnicUrlUpdate);
	}

	connectedCallback() {
		super.connectedCallback();
		this.startCacheClearInterval();
	}

	disconnectedCallback() {
		super.disconnectedCallback();
		this.stopCacheClearInterval();
	}

	startCacheClearInterval() {
		this.cacheInterval ??= setInterval(async () => {
			const domainCache = new UniqueObjectCache('CachedDomainList');
			domainCache.clearCache();
			delete Util.session?.allTlds;
			const configDataPromise = await Util.fetchData({type: 'clearCache'});
			await Promise.all(configDataPromise);
			// this.requestUpdate(); // Trigger a re-render to update the displayed count
		}, 1800000); // Interval of 30 minutes (1800000 milliseconds)
	}

	stopCacheClearInterval() {
		clearInterval(this.cacheInterval);
	}

	_handleCnicUrlUpdate() {
		this.searchAction =
			Util.params.action?.length > 0 ? Util.params.action : 'home';
		this.updateTabs();
	}

	_clearCache() {
		delete Util.session.searchTerm;
		delete Util.session.searchAction;
		delete Util.session.searchPage;
		delete Util.session.lastResult;
		delete Util.session.totalResults;
		delete Util.session.domainList;
		delete Util.session.config;
	}

	_onTabChange(event) {
		this.searchAction = event.target.value;
		Util.params.action = this.searchAction;
		this.updateTabs();
	}

	/**
	 * This function updates the tabs and highlights the selected one
	 * It finds the tabsSwitchIndicator div and sets its width and left properties to fit the selected tab
	 * It then finds all the tabHeadings and hides the ones that do not correspond to the selected tab
	 * and unhides the one that does.
	 */
	updateTabs(selectedTab = null) {
		const indicator = this.renderRoot?.querySelector('div#tabsSwitchIndicator');
		if (indicator) {
			// Get the selected tab and its width and left properties
			selectedTab ??= this.renderRoot.querySelector(
				`[id$=tab-${this.searchAction}]`,
			);
			selectedTab.checked = true;
			// Set the width and left properties of the indicator to fit the selected tab
			const {offsetWidth, offsetLeft} = selectedTab.labels[0];
			indicator.style.width = `${parseInt(offsetWidth)}px`;
			indicator.style.left = `${parseInt(offsetLeft)}px`;

			// Hide all tabHeadings that do not correspond to the selected tab and unhide the one that does
			Array.from(
				this.renderRoot.querySelectorAll("[id^='tabHeading']"),
			).forEach(pill => {
				if (pill.id.includes(this.searchAction)) {
					pill.removeAttribute('hidden');
				} else {
					pill.setAttribute('hidden', true);
				}
			});
		}
	}

	async _loadConfiguration() {
		// Fetch config if not already present in the session
		if (
			!Util.session?.config ||
			Object.keys(Util.session?.config).length === 0
		) {
			const configDataPromise = await Util.fetchData({type: 'config'});
			const [resolvedConfigData] = await Promise.all(configDataPromise);
			Util.session.config = resolvedConfigData;
			if (Util.session.config?.cartData) {
				Util.session.cartList = Util.session.config.cartData;
			}
		}

		{
			const tldsRegisterPricePromise = await Util.fetchData({
				type: 'tldsPricing',
				request: 'register',
			});
			const tldsRenewPricePromise = await Util.fetchData({
				type: 'tldsPricing',
				request: 'renew',
			});
			Promise.all(tldsRegisterPricePromise).then(data => {
				[Util.session.tldsRegisterPricing] = data;
			});
			Promise.all(tldsRenewPricePromise).then(data => {
				[Util.session.tldsRenewPricing] = data;
			});
		}

		// Extract relevant configuration options
		const {features} = Util.session.config;
		this.searchConfig = Util.session.config;
		const actions = {
			home:
				(this.searchConfig.spotlightTlds?.length && features?.Home) ?? false,
			register: features?.RegularSearch ?? true,
			suggestions: features?.Suggestions ?? false,
			transfer: features?.BulkTransfers ?? false,
			whois: features?.WhoIs ?? false,
		};

		// Set default search action if current one not found
		if (!actions[this.searchAction]) {
			this.searchAction = 'register';
		}

		// Set tabs based on available actions
		this.tabs = Object.keys(actions).filter(action => actions[action]);

		const selectedTab = await Util.waitForElement(
			`#tab-${this.searchAction}`,
			this,
		);
		if (selectedTab) {
			this.updateTabs(selectedTab);
		}
	}

	mainHeader() {
		return x$1`<load-template path="main-header"></load-template>`;
	}

	mainSearchContainer() {
		const {searchAction, searchConfig, tabs = []} = this;
		const tabContainers = tabs.map(tab => {
			const showContainer = searchAction === tab;
			if (tab === 'whois') {
				return x$1`<whois-container
					.showContainer=${showContainer}
					.searchConfig=${searchConfig}
				></whois-container>`;
			} else if (tab === 'home') {
				return x$1`<home-container
					.showContainer=${showContainer}
					.searchConfig=${searchConfig}
				></home-container>`;
			}

			return x$1`<search-container
				searchAction=${tab}
				.showContainer=${showContainer}
				.searchConfig=${searchConfig}
			></search-container>`;
		});

		return x$1`
			<top-tabs .tabs=${tabs} @change=${this._onTabChange}></top-tabs>
			${tabContainers}
		`;
	}

	mainFooter() {
		return x$1`<load-template path="main-footer"></load-template>`;
	}

	render() {
		if (!translation || !this.searchAction || !this.searchConfig) {
			return;
		}

		if (!this.searchConfig.lookupprovider) {
			return x$1`<load-template
				path="error-lookup-provider.html"
			></load-template>`;
		}

		return x$1`
			${this.mainHeader()} ${this.mainSearchContainer()} ${this.mainFooter()}
		`;
	}
}

customElements.define('search-engine', SearchEngine);

class Search extends s$1 {
	static properties = {
		showContainer: {type: Boolean},
		showSpotlightTlds: {type: Boolean},
		searchResultsAvailable: {type: Boolean},
		searchConfig: {
			type: Object,
			hasChanged(val, oldVal) {
				return val !== oldVal;
			},
		},
		searchPage: {
			type: Number,
			hasChanged(val, oldVal) {
				Util.session.searchPage = val;
				return val !== oldVal;
			},
		},
		totalSuggestionResults: {type: Number},
		lastResults: {type: Number},
		totalUnavailableDomains: {type: Number},
		data: {type: Object},
		totalResultsRaw: {type: Object},
		lastResultsRaw: {type: Object},
		cartData: {type: Object},
		searchToggleBtns: {
			type: Array,
			hasChanged(val, oldVal) {
				if (val !== undefined && val.length > 0) {
					Util.session.filters = val;
				}
				return val !== oldVal;
			},
		},
		domainBaseList: {type: Array},
		domainSuggestionList: {type: Array},
		errorMessages: {type: Array},
		searchAction: {type: String},
		searchEventName: {type: String},
		containerId: {type: String},
		searchTerm: {type: String},
		sortBy: {type: String, state: true},
		lastWindowScrollPosition: {type: Number, state: true},
		lastContentsScrollPosition: {type: Number, state: true},
	};

	constructor() {
		super();
		this.domainSuggestionList = [];
		this.domainBaseList = [];
		this.errorMessages = [];
		this.searchPage = 1;
		this.searchTerm = Util.session.searchTerm || '';
		this.searchResultsAvailable = true;
		this.showSpotlightTlds = false;
		this.containerId = `div${Date.now()}`;
		this.sortBy = Util.params?.sort;
		this.searchTerm =
			Util.params.searchTerm?.length > 0 &&
			Util.params.searchTerm.trim() !== 'undefined'
				? Util.params.searchTerm
				: this.searchTerm;
		this.addEventListener('cnicDomainFilters', this._searchFilters);
		this.addEventListener('cnicDomainSearch', this._searchHandler);
	}

	updated(changed) {
		if (changed.has('searchConfig')) {
			this._searchFilters();
			this.showSpotlightTlds = this.searchConfig.showContainerSpotlight;
		}

		if (changed.has('showContainer') && this.showContainer) {
			let contentsLazyLoad = this.renderRoot?.querySelector(
				`#${this.containerId}`,
			);
			if (contentsLazyLoad) {
				contentsLazyLoad.addEventListener(
					'scroll',
					event => this._handleContentsLazyLoadScroll(event),
					{passive: true},
				);
			}
		}

		if (
			changed.has('showContainer') &&
			this.showContainer &&
			Util.params.referrer === 'whmcs'
		) {
			this._searchHandler();
		}

		Util.initTooltip(this.renderRoot);
		this._scrollToLastPosition();
	}

	_scrollToLastPosition() {
		const element = this.renderRoot?.querySelector(`#${this.containerId}`);
		if (element && this.searchResultsAvailable && this.showContainer) {
			element.scrollTop = this.lastContentsScrollPosition;
			window.scroll(0, this.lastWindowScrollPosition + 1);
			window.scrollTo({
				top: this.lastContentsScrollPosition,
				behavior: 'smooth',
			});
		}
	}

	_handleContentsLazyLoadScroll(event) {
		const contentsLazyLoad = event.target;
		const {scrollTop, scrollHeight, clientHeight} = contentsLazyLoad;

		// GUARD: If element is not scrollable, remove all classes
		const isScrollable = scrollHeight > clientHeight;

		if (!isScrollable) {
			contentsLazyLoad.classList.remove(
				'is-bottom-overflowing',
				'is-top-overflowing',
			);
			return;
		}
		const isScrolledToBottom = scrollHeight - 50 <= clientHeight + scrollTop;
		const isScrolledToTop = scrollTop <= 50;

		contentsLazyLoad.classList.toggle(
			'is-bottom-overflowing',
			!isScrolledToBottom,
		); // bottom fade styling class
		contentsLazyLoad.classList.toggle('is-top-overflowing', !isScrolledToTop); // top fade styling class

		if (
			isScrolledToBottom &&
			this._totalItemsInList() &&
			this.searchResultsAvailable
		) {
			this._searchHandler({type: 'cnicDomainSearchLoadMore'});
		}
	}

	_isValidContainer(tab = 'register') {
		return this.searchAction === tab;
	}

	_totalItemsInList(info = {}) {
		if (this._isValidContainer()) {
			this.lastResults = Util.session.lastResult;
			this.totalSuggestionResults = Util.session.totalResults;

			return this.totalSuggestionResults > this.lastResults;
		}

		if (info?.last || info?.total) {
			const lastResultValues = Object.values(info.last);
			const totalResultsValues = Object.values(info.total) || 0;

			this.lastResultsRaw = info?.last || 0;
			this.totalResultsRaw = info?.total || 0;
			this.lastResults = lastResultValues.reduce(
				(accumulator, currentValue) => accumulator + parseInt(currentValue),
				0,
			);
			this.totalSuggestionResults = totalResultsValues.reduce(
				(accumulator, currentValue) => accumulator + parseInt(currentValue),
				0,
			);
		}

		return this.totalSuggestionResults > this.lastResults;
	}

	async _searchHandler(e) {
		const searchType = e?.type ?? 'cnicDomainSearch';
		const searchTerm = e?.detail?.searchTerm ?? this.searchTerm;
		this.lastWindowScrollPosition = window.scrollY;
		this.lastContentsScrollPosition = this.renderRoot?.querySelector(
			`#${this.containerId}`,
		).scrollTop;
		try {
			const errors = [];

			// Toggle boolean values
			this.searchResultsAvailable = false;
			this.showSpotlightTlds = false;

			// Handle different search events
			if (searchType === 'cnicDomainSearch') {
				this._resetSearchSession();
				this.searchTerm = searchTerm;
				this.searchPage = 1;
			} else if (searchType === 'cnicDomainSearchLoadMore') {
				this.searchPage++;
			}

			// Check search term length
			if (this.searchTerm.length > 63 && this.searchAction !== 'transfer') {
				errors.push('error_keywordlength');
			}

			// Fetch data from API
			const result = await Util.fetchData({
				type: searchType,
				searchAction: this.searchAction,
				searchTerm: this.searchTerm,
				searchPage: this.searchPage,
				lastResults: this.lastResultsRaw,
				totalResults: this.totalResultsRaw,
			});

			// Process result data
			for (const data of result) {
				// Build data list
				const domainsList = Util.buildDomainList(
					await data,
					this.searchAction,
					this.searchTerm,
				);

				// Add domain lists to base and suggestion lists
				if (
					domainsList?.domainBaseList.length ||
					domainsList?.domainSuggestionList.length
				) {
					this.domainBaseList.push(...domainsList.domainBaseList);
					this.domainSuggestionList.push(...domainsList.domainSuggestionList);
				}

				// Calculate total number of items in list
				this._totalItemsInList(domainsList?.info);

				// Handle registration action
				if (this._isValidContainer()) {
					Util.getCachedDomains(
						this.domainBaseList,
						this.searchPage,
						'baseList',
					);
					Util.getCachedDomains(
						this.domainSuggestionList,
						this.searchPage,
						'suggestionList',
					);

					this.domainSuggestionList = this.domainSuggestionList
						.map(domain => {
							const checkDomainExistsInBaseList = Util.findValueInArray(
								this.domainBaseList,
								domain.domainName,
								'domainName',
							);
							if (checkDomainExistsInBaseList) {
								return null;
							}
							const findOrder = Util.findValueInArray(
								Util.session.domainList,
								domain,
								'suggest',
							);
							return Object.assign({order: findOrder.order}, domain);
						})
						.filter(item => item !== null);
				}

				// Finalize error checking and update UI
				if (result.indexOf(data) === result.length - 1) {
					this.searchResultsAvailable = !this.searchResultsAvailable;
					this.totalUnavailableDomains = this.domainSuggestionList.filter(
						domain => !domain.isAvailable,
					).length;
					const totalResults =
						(this.domainSuggestionList?.length || 0) +
						(this.domainBaseList?.length || 0);

					if (
						this.searchAction === 'transfer' &&
						(!domainsList?.domainBaseList.length ||
							domainsList?.eppNotProvided > 0)
					) {
						errors.push('error_noAuthCodeProvided');
					}

					if (totalResults === 0 && this.searchAction !== 'transfer') {
						errors.push('error_noResultsFound');
					}

					if (this.totalUnavailableDomains > 0) {
						errors.push('error_domainUnavailable');
					}

					this.errorMessages = errors;
				}
			}
		} catch (error) {
			console.error(error);
		}
	}

	_domainListItem(domains) {
		if (domains.length === 0) {
			return [];
		}

		domains.sort(Util.sortDomainByOrder);
		const cartData = Util.session.cartList;
		return domains.map(domain => {
			let addToCart = domain.addToCart;
			let cartItemType = domain.cartItemType;
			let registerPeriod = parseInt(domain.registerPeriod) || 0;
			let isAvailable = domain.isAvailable;
			// Check if domain is in the cart
			Object.keys(cartData).forEach(key => {
				if (key === domain.idnDomainName || key === domain.domainName) {
					addToCart = true;
					cartItemType = cartData[key].type || 'register';
					registerPeriod = parseInt(cartData[key].regperiod);
				}
			});
			return x$1`
				<domain-list-item
					domainName=${domain.domainName}
					domainStatus=${domain.domainStatus}
					domainGroup=${domain.domainGroup}
					idnDomainName=${domain.idnDomainName}
					domainTld=${domain.tld}
					.domainEppCode=${domain.eppCode}
					cartItemType=${cartItemType}
					.addToCart=${addToCart}
					.itemInCartSession=${addToCart === true}
					.registerPeriod=${registerPeriod}
					.isBaseDomain=${domain.isBaseDomain}
					.domainPricing="${domain.domainPricing}"
					.isAvailable=${isAvailable}
					.tldSupported=${domain.tldSupported}
					.availabilityReason=${domain.availabilityReason}
					.isPremium=${domain.isPremium}
					.isAftermarket=${domain.isAftermarket}
					.searchToggleBtns=${this.searchToggleBtns}
				>
				</domain-list-item>
			`;
		});
	}

	_resetSearchSession() {
		if (this._isValidContainer()) {
			delete Util.session.lastResult;
			delete Util.session.totalResults;
			delete Util.session.domainList;
		}
		delete Util.session.searchPage;
		this.domainSuggestionList = [];
		this.domainBaseList = [];
		this.errorMessages = [];
		this.lastResults = 0;
		this.totalSuggestionResults = 0;
	}

	/**
	 * Updates the search filter buttons based on the filter settings passed in the event detail
	 *
	 * @param {Event} el
	 */
	_searchFilters(el) {
		// Get the filters from the event detail if present, or from the session if not
		const filters = el?.detail.filters || Util.session?.filters || [];

		// Initialize an array to store the buttons
		const btns = [];

		// Add default filters if no filters are present
		if (!filters.length) {
			if (this.searchConfig.showTakenDomains) {
				filters.push({type: 'unavailable', show: true});
			}
			if (this.searchConfig.showPremiumDomains) {
				filters.push({type: 'premiums', show: true});
				filters.push({type: 'aftermarket', show: true});
			}
		}

		// Add an "unavailable" filter if it doesn't exist
		if (!filters.some(filter => filter.type === 'unavailable')) {
			filters.push({type: 'unavailable', show: false});
		}

		// Add applicable filters to the buttons array
		for (const filter of filters) {
			if (
				filter.type === 'unavailable' ||
				filter.type === 'filterType' ||
				(filter.type === 'premiums' && this.searchConfig.showPremiumDomains) ||
				(filter.type === 'aftermarket' && this.searchConfig.showPremiumDomains)
			) {
				btns.push(filter);
			}
		}

		// Update the search toggle buttons with the new array of buttons
		this.searchToggleBtns = btns;
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		return x$1`
			<domain-input
				searchAction=${this.searchAction}
				.searchTerm=${this.searchTerm}
				.searchPage=${this.searchPage}
				.searchResultsAvailable=${this.searchResultsAvailable}
				.totalUnavailableDomains=${this.totalUnavailableDomains}
				.searchConfig=${this.searchConfig}
				.searchToggleBtns=${this.searchToggleBtns}
			>
			</domain-input>
			<search-container-info-box
				.errorMessages=${this.errorMessages}
			></search-container-info-box>
			<spotlight-tlds
				.spotlightTlds=${this.searchConfig.spotlightTlds}
				.showContainer=${this.showSpotlightTlds}
			></spotlight-tlds>
			<data-list
				.data="${{
					sorting: x$1`<data-sorting
						.searchTerm=${this.searchTerm}
						.showContainer=${this._isValidContainer() &&
						this.domainSuggestionList?.length > 0}
					></data-sorting>`,
					checkout: x$1`<data-list
						.isHidden=${!this.totalSuggestionResults ||
						this.totalSuggestionResults <= 0}
						template="Container/Search/checkout-btn"
					></data-list>`,
				}}"
				template="Container/Search/head"
			></data-list>
			<div class="contentsLazyLoad" id=${this.containerId}>
				<data-list
					data="~${this.totalSuggestionResults} results"
					template="Container/Search/header"
					.isHidden=${!this.totalSuggestionResults ||
					this.totalSuggestionResults <= 0}
				></data-list>
				<data-list
					.data=${this._domainListItem(this.domainBaseList)}
					template="Container/Search/base-list"
					.isHidden=${!this.domainBaseList.length}
				></data-list>
				<data-list
					.data=${this._domainListItem(this.domainSuggestionList)}
					template="Container/Search/suggestion-list"
					.isHidden=${!this.domainSuggestionList.length}
				></data-list>
				<loading-domain-list
					.searchResultsAvailable=${this.searchResultsAvailable}
				></loading-domain-list>
			</div>
			<load-more-button
				@cnicDomainSearchLoadMore=${this._searchHandler}
				.totalResults=${this.totalSuggestionResults}
				.lastResults=${this.lastResults}
				.searchResults=${this.searchResultsAvailable}
				datatype="loadmore"
			>
			</load-more-button>
		`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('search-container', Search);

class Home extends s$1 {
	static properties = {
		showContainer: {type: Boolean},
		searchConfig: {type: Object},
		containerId: {type: String},
		containerContent: {type: Object},
	};

	constructor() {
		super();
		this.containerId = `div${Date.now()}`;
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		return x$1`
			<div id=${this.containerId} class="container">
				<domain-promotions
					.searchConfig=${this.searchConfig}
				></domain-promotions>
				<spotlight-tlds
					.spotlightTlds=${this.searchConfig.spotlightTlds}
					.showContainer=${this.showContainer}
					tldBoxWidth="300px"
				></spotlight-tlds>
			</div>
		`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('home-container', Home);

class Whois extends s$1 {
	static properties = {
		showContainer: {type: Boolean},
		searchResultsAvailable: {type: Boolean},
		searchConfig: {type: Object},
		containerId: {type: String},
		containerContent: {type: Object},
		searchTerm: {type: String},
	};

	constructor() {
		super();
		this.searchResultsAvailable = true;
		this.containerId = `div${Date.now()}`;
		this.searchTerm = '';
	}

	updated(changed) {
		if (!this.showContainer) {
			return;
		}

		this.searchTerm =
			Util.params.searchTerm?.length > 0
				? Util.params.searchTerm
				: this.searchTerm;
		if (changed.has('searchTerm') && this.searchTerm) {
			if (this.searchResultsAvailable) {
				this._searchHandler();
			}
		}
	}

	async _searchHandler(e) {
		this.searchResultsAvailable = !this.searchResultsAvailable;
		this.containerContent = x$1`<loading-domain-list></loading-domain-list>`;

		if (e?.detail?.searchTerm) {
			this.searchTerm = e.detail.searchTerm;
			Util.params.searchTerm = this.searchTerm;
		}

		const [domain] = Util.getPunyCodeName(this.searchTerm, false);
		const url = `${cnicWebRootPath}/mywhois.php?domain=${domain.exact}`;
		const response = await fetch(url);

		if (response.ok) {
			const textContent = await response.text();
			const parser = new DOMParser();
			const body = parser
				.parseFromString(textContent, 'text/html')
				.querySelector('body');
			const innerHTML = body.innerHTML.replace(/\<br\>/g, '\n');
			this.containerContent = new Function(
				'html',
				'return html`' + innerHTML + '`',
			)(x$1);
			this.searchResultsAvailable = !this.searchResultsAvailable;
		}
	}

	render() {
		if (!this.showContainer) {
			return;
		}
		const bindings = {
			containerId: this.containerId,
			containerContent: this.containerContent,
		};

		return x$1`
			<domain-input
				@cnicDomainSearch=${this._searchHandler}
				searchAction="whois"
				.searchTerm=${this.searchTerm}
				.searchResultsAvailable=${this.searchResultsAvailable}
				.searchConfig=${this.searchConfig}
			>
			</domain-input>
			<load-template
				path="Container/whois"
				.bindings=${bindings}
			></load-template>
		`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('whois-container', Whois);

class ComboBox {
	selectedEl = {};
	el = {};
	inputEl = {};
	options = {};
	listboxEl = {};
	idBase = '';
	activeIndex = 0;
	open = false;
	_selectedIndex = [];
	Keys = {
		Backspace: 'Backspace',
		Clear: 'Clear',
		Down: 'ArrowDown',
		End: 'End',
		Enter: 'Enter',
		Escape: 'Escape',
		Home: 'Home',
		Left: 'ArrowLeft',
		PageDown: 'PageDown',
		PageUp: 'PageUp',
		Right: 'ArrowRight',
		Space: ' ',
		Tab: 'Tab',
		Up: 'ArrowUp',
	};

	MenuActions = {
		Close: 0,
		CloseSelect: 1,
		First: 2,
		Last: 3,
		Next: 4,
		Open: 5,
		Previous: 6,
		Select: 7,
		Space: 8,
		Type: 9,
	};

	// filter an array of options against an input string
	// returns an array of options that begin with the filter string, case-independent
	filterOptions(options = [], filter, exclude = []) {
		return options.filter(option => {
			const matches = option.toLowerCase().indexOf(filter.toLowerCase()) === 0;
			return matches && exclude.indexOf(option) < 0;
		});
	}

	// return an array of exact option name matches from a comma-separated string
	findMatches(options, search) {
		const names = search.split(',');
		return names
			.map(name => {
				const match = options.filter(
					option => name.trim().toLowerCase() === option.toLowerCase(),
				);
				return match.length > 0 ? match[0] : null;
			})
			.filter(option => option !== null);
	}

	// return combobox action from key press
	getActionFromKey(event, menuOpen) {
		const {key, altKey, ctrlKey, metaKey} = event;
		// handle opening when closed
		if (
			!menuOpen &&
			(key === this.Keys.Down ||
				key === this.Keys.Enter ||
				key === this.Keys.Space)
		) {
			return this.MenuActions.Open;
		}

		// handle keys when open
		if (key === this.Keys.Down) {
			return this.MenuActions.Next;
		} else if (key === this.Keys.Up) {
			return this.MenuActions.Previous;
		} else if (key === this.Keys.Home) {
			return this.MenuActions.First;
		} else if (key === this.Keys.End) {
			return this.MenuActions.Last;
		} else if (key === this.Keys.Escape) {
			return this.MenuActions.Close;
		} else if (key === this.Keys.Enter) {
			return this.MenuActions.CloseSelect;
		} else if (key === this.Keys.Space) {
			return this.MenuActions.Space;
		} else if (
			key === this.Keys.Backspace ||
			key === this.Keys.Clear ||
			(key.length === 1 && !altKey && !ctrlKey && !metaKey)
		) {
			return this.MenuActions.Type;
		}
	}

	// get index of option that matches a string
	getIndexByLetter(options, filter) {
		const firstMatch = this.filterOptions(options, filter)[0];
		return firstMatch ? options.indexOf(firstMatch) : -1;
	}

	// get updated option index
	getUpdatedIndex(current, max, action) {
		switch (action) {
			case this.MenuActions.First:
				return 0;
			case this.MenuActions.Last:
				return max;
			case this.MenuActions.Previous:
				return Math.max(0, current - 1);
			case this.MenuActions.Next:
				return Math.min(max, current + 1);
			default:
				return current;
		}
	}

	// check if an element is currently scrollable
	isScrollable(element) {
		return element && element.clientHeight < element.scrollHeight;
	}

	// ensure given child element is within the parent's visible scroll area
	maintainScrollVisibility(activeElement, scrollParent) {
		const {offsetHeight, offsetTop} = activeElement;
		const {offsetHeight: parentOffsetHeight, scrollTop} = scrollParent;

		const isAbove = offsetTop < scrollTop;
		const isBelow = offsetTop + offsetHeight > scrollTop + parentOffsetHeight;

		if (isAbove) {
			scrollParent.scrollTo(0, offsetTop);
		} else if (isBelow) {
			scrollParent.scrollTo(0, offsetTop - parentOffsetHeight + offsetHeight);
		}
	}

	constructor(options, selectedEl) {
		// element refs
		this.el = selectedEl.querySelector('.cnic-multiselect');
		this.inputEl = this.el.querySelector('input#tldCategories');
		this.listboxEl = this.el.querySelector('.combo-menu');
		this.idBase = this.inputEl.id;
		this.selectedEl = this.el.querySelector('#tldCategories-selected');
		// data
		this.options = options;
		this._selectedIndex = Util.session.selectedTldCategories ?? [];
		// state
		this.activeIndex = 0;
		this.open = false;
		this.init();
	}

	init() {
		this.inputEl.addEventListener('input', this.onInput.bind(this));
		this.inputEl.addEventListener('blur', this.onInputBlur.bind(this));
		this.inputEl.addEventListener('click', () => this.updateMenuState(true));
		this.inputEl.addEventListener('keydown', this.onInputKeyDown.bind(this));
		this.listboxEl.addEventListener('blur', this.onInputBlur.bind(this));
		const selectIndexLength = this._selectedIndex?.length;
		this.options.map((option, index) => {
			const optionEl = document.createElement('div');
			optionEl.setAttribute('role', 'option');
			optionEl.id = `${this.idBase}-${index}`;
			optionEl.className =
				index === 0 ? 'combo-option option-current' : 'combo-option';
			optionEl.setAttribute('aria-selected', 'false');
			optionEl.innerHTML =
				(option?.icon?.length
					? `<i class="fas fa-${option.icon}"></i>&nbsp;`
					: '') + option.name;
			optionEl.addEventListener('click', () => {
				this.onOptionClick(index);
			});
			optionEl.addEventListener('mousedown', this.onOptionMouseDown.bind(this));
			this.listboxEl.appendChild(optionEl);
			if (
				!selectIndexLength &&
				!this._selectedIndex.includes(option.id) &&
				option.default
			) {
				this._selectedIndex.push(option.id);
				Util.session.selectedTldCategories = this._selectedIndex;
				delete Util.session.sortedTlds;
			}
		});
		if (this._selectedIndex) {
			this._selectedIndex.forEach((option, index) => {
				if (option && !isNaN(option)) {
					option = this.options.find(op => op.id === option);
					this.selectOption(this.options.indexOf(option));
				}
			});
		}
	}

	onInput() {
		const curValue = this.inputEl.value;
		const matches = this.filterOptions(this.options, curValue);

		// set activeIndex to first matching option
		// (or leave it alone, if the active option is already in the matching set)
		const filterCurrentOption = matches.filter(
			option => option === this.options[this.activeIndex],
		);
		if (matches.length > 0 && !filterCurrentOption.length) {
			this.onOptionChange(this.options.indexOf(matches[0]));
		}

		const menuState = this.options.length > 0;
		if (this.open !== menuState) {
			this.updateMenuState(menuState, false);
		}
	}

	onInputKeyDown(event) {
		const max = this.options.length - 1;

		const action = this.getActionFromKey(event, this.open);

		switch (action) {
			case this.MenuActions.Next:
			case this.MenuActions.Last:
			case this.MenuActions.First:
			case this.MenuActions.Previous:
				event.preventDefault();
				return this.onOptionChange(
					getUpdatedIndex(this.activeIndex, max, action),
				);
			case this.MenuActions.CloseSelect:
				event.preventDefault();
				return this.updateOption(this.activeIndex);
			case this.MenuActions.Close:
				event.preventDefault();
				return this.updateMenuState(false);
			case this.MenuActions.Open:
				return this.updateMenuState(true);
		}
	}

	onInputBlur() {
		if (this.ignoreBlur) {
			this.ignoreBlur = false;
			return;
		}

		if (this.open) {
			this.updateMenuState(false, false);
		}
	}

	onOptionChange(index) {
		this.activeIndex = index;
		this.inputEl.setAttribute(
			'aria-activedescendant',
			`${this.idBase}-${index}`,
		);
		// update active style
		const options = this.el.querySelectorAll('[role=option]');
		[...options].forEach(optionEl => {
			optionEl.classList.remove('option-current');
		});
		options[index].classList.add('option-current');

		if (this.open && this.isScrollable(this.listboxEl)) {
			this.maintainScrollVisibility(options[index], this.listboxEl);
		}
	}

	onOptionClick(index) {
		this.onOptionChange(index);
		this.updateOption(index);
		this.inputEl.focus();
	}

	onOptionMouseDown() {
		this.ignoreBlur = true;
	}

	removeOption(index) {
		const option = this.options[index];
		// update aria-selected
		const options = this.el.querySelectorAll('[role=option]');
		options[index].setAttribute('aria-selected', 'false');
		options[index].classList.remove('option-selected');

		// remove button
		const buttonEl = this.selectedEl.querySelector(
			`#${this.idBase}-remove-${index}`,
		);
		this.selectedEl.removeChild(buttonEl.parentElement);
		this._selectedIndex.splice(this._selectedIndex.indexOf(option.id), 1);
		Util.session.selectedTldCategories = this._selectedIndex;
		delete Util.session.sortedTlds;
	}

	selectOption(index) {
		if (index < 0) {
			return;
		}
		const selected = this.options[index];
		this.activeIndex = index;
		const inputElement = this.el.querySelector('input');
		inputElement.setAttribute('placeholder', '');

		// resizing to fit selected categories contents
		let tldCategoriesHeight = this.el.querySelector(
			'#tldCategories-selected',
		).clientHeight;
		tldCategoriesHeight =
			inputElement.clientWidth > 1000
				? tldCategoriesHeight + 25
				: tldCategoriesHeight;
		inputElement.setAttribute('style', `height: ${tldCategoriesHeight}px`);

		// update aria-selected
		const options = this.el.querySelectorAll('[role=option]');
		options[index].setAttribute('aria-selected', 'true');
		options[index].classList.add('option-selected');

		// add remove option button
		const buttonEl = document.createElement('button');
		const listItem = document.createElement('li');
		buttonEl.className = 'remove-option';
		buttonEl.type = 'button';
		buttonEl.id = `${this.idBase}-remove-${index}`;
		buttonEl.setAttribute('aria-describedby', `${this.idBase}-remove`);
		buttonEl.setAttribute('data-id', selected.id);
		buttonEl.addEventListener('click', () => {
			this.removeOption(index);
		});
		buttonEl.innerHTML = `<i class="fas fa-${selected.icon}"> ${selected.name} `;
		listItem.appendChild(buttonEl);
		this.selectedEl.appendChild(listItem);
		this.updateMenuState(false);
		if (!this._selectedIndex.includes(selected.id)) {
			this._selectedIndex.push(selected.id);
			Util.session.selectedTldCategories = this._selectedIndex;
			delete Util.session.sortedTlds;
		}
	}

	updateOption(index) {
		this.options[index];
		const optionEl = this.el.querySelectorAll('[role=option]')[index];
		const isSelected = optionEl.getAttribute('aria-selected') === 'true';

		if (isSelected) {
			this.removeOption(index);
		} else {
			this.selectOption(index);
		}
		this.inputEl.value = '';
	}

	updateMenuState(open, callFocus = true) {
		this.open = open;

		this.inputEl.setAttribute('aria-expanded', `${open}`);
		open ? this.el.classList.add('open') : this.el.classList.remove('open');
		callFocus && this.inputEl.focus();
	}
}

class LoadHtmlTemplate extends s$1 {
	static properties = {
		template: {},
		path: {type: String},
		bindings: {type: Array},
	};

	constructor() {
		super();
		this.template = '';
	}

	async firstUpdated() {
		if (Util.params?.action === 'register') {
			const selector = await Util.waitForElement(`#tldCategories`, this);
			if (selector && this.bindings?.tldCategories) {
				new ComboBox(this.bindings.tldCategories, this.renderRoot);
			}
		}
	}

	updated() {
		Util.initTooltip(this);
	}

	async connectedCallback() {
		super.connectedCallback();
		this.template = await Util.fetchTemplate(this.path);
	}

	render() {
		if (!this.template) {
			return x$1`<div
				class="Box-paddingX-small_2LJQE Box-paddingLeft-small_1mVBq Box-paddingRight-small_Mw0L5 Box-paddingY-xsmall_34kFF Box-paddingTop-xsmall_22Udt Box-paddingBottom-xsmall_15dmU Box-backgroundColor-white_3LQ-e Flex-flex_uh_R2 PlaceholderRow-root__z9Q6b Box-gap-xsmall_1_DKb Flex-flex_uh_R2 Flex-flexJustifyEnd_1I0qk Flex-flexAlignItemsCenter_3oJ12"
			>
				<span
					class="Placeholder-root_G1eL2 Placeholder-effect_1YLEe"
					style="min-width: 3ch;"
				></span>
			</div>`;
		}

		const dynamicTemplate = new Function(
			'bindings',
			'html',
			'getMessage',
			'return html`' + this.template + '`',
		)(this.bindings, x$1, getMessage);

		return x$1`${dynamicTemplate}`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('load-template', LoadHtmlTemplate);

class SearchContainerInfoBox extends s$1 {
	static properties = {
		errorMessages: {type: Array},
	};

	constructor() {
		super();
	}

	get messages() {
		const messages = this.errorMessages
			.map(type => {
				return x$1`<p>${getMessage(type)}</p>`;
			})
			.filter(messages => messages !== undefined);
		return {message: x$1`${messages}`};
	}

	render() {
		if (!this.errorMessages.length) {
			return;
		}

		return x$1`<load-template
			path="Container/infobox"
			.bindings=${this.messages}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('search-container-info-box', SearchContainerInfoBox);

class LoadMoreBtn extends s$1 {
	static properties = {
		searchTerm: {},
		searchAction: {},
		searchPage: {},
		searchResults: {reflect: true},
		datatype: {},
		totalResults: {reflect: true},
		lastResults: {reflect: true},
	};

	constructor() {
		super();
	}

	_loadMore() {
		if (this.searchResults) {
			this.searchResults = !this.searchResults;
			let loaderEvent = new Event('cnicDomainSearchLoadMore', {
				bubbles: true,
				composed: true,
			});
			this.dispatchEvent(loaderEvent);
		}
	}

	render() {
		const bindings = {
			spinner: x$1`<load-template
				path="LoadMore/spinner-icon"
			></load-template>`,
		};

		if (this.datatype && this.datatype.match(/search/gi)) {
			if (!this.searchResults) {
				return x$1`<load-template
					path="LoadMore/spinner-icon"
				></load-template>`;
			}
			return x$1`<load-template
				path="InputSearch/search-button"
				.bindings=${bindings}
			></load-template>`;
		} else if (
			this.datatype &&
			this.datatype.match(/loadmore/gi) &&
			this.totalResults > this.lastResults
		) {
			if (!this.searchResults) {
				return x$1`<load-template
					?disabled=${!this.searchResults}
					path="LoadMore/spinner-btn"
					.bindings=${bindings}
				></load-template>`;
			} else if (this.searchResults) {
				return x$1`<load-template
					path="LoadMore/button"
					@click=${this._loadMore}
					.bindings=${bindings}
				></load-template>`;
			}
		}
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('load-more-button', LoadMoreBtn);

class DomainPromotions extends s$1 {
	static properties = {
		searchConfig: {type: Object},
		showContainer: {type: Boolean},
	};

	constructor() {
		super();
		this.showContainer = true;
	}

	get _promotions() {
		const promotions = [];
		for (let i = 1; i < 5; i++) {
			const findKey = `promotions_descr_list_${i}`;
			const findMsg = getMessage(findKey);
			if (findMsg !== findKey) {
				promotions.push({msg: findMsg});
			}
		}

		return promotions;
	}

	render() {
		const promos = this._promotions;

		if (
			!this.searchConfig?.showPromotions ||
			!promos.length ||
			!this.showContainer
		) {
			return;
		}

		const bindings = {tagLine: getMessage('promotions_label'), promos: promos};

		return x$1`<load-template
			.bindings=${bindings}
			path="Container/domain-promotions"
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('domain-promotions', DomainPromotions);

class SearchOptionsToggle extends s$1 {
	static properties = {
		showBulkInput: {},
		searchAction: {},
		searchTerm: {},
	};

	constructor() {
		super();
	}

	limitLines(el) {
		let values = el.target.value.replace(/\r\n/g, '\n').split('\n');
		if (values.length > 10) {
			el.target.value = values.slice(0, 10).join('\n');
		}
	}

	render() {
		if (this.searchTerm && this.searchTerm.length > 0) {
			// Break search keywords in to multiple lines when using Bulk Mode
			this.searchTerm = Util.searchBulkMode(
				this.searchTerm,
				this.showBulkInput,
			);
		}

		const bindings = {
			showBulkInput: this.showBulkInput,
			searchTerm: this.searchTerm,
			searchType: this.searchAction.toLowerCase(),
		};
		const inputField = this.showBulkInput
			? x$1`<load-template
					path="InputSearch/bulk-input"
					.bindings=${bindings}
			  ></load-template>`
			: x$1`<load-template
					path="InputSearch/single-input"
					.bindings=${bindings}
			  ></load-template>`;

		return x$1`<load-template
			path="InputSearch/input-field"
			.bindings=${{inputField: inputField}}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('search-options-toggle', SearchOptionsToggle);

class SearchFiltersToggle extends s$1 {
	static properties = {
		searchOptions: {type: Boolean},
		showPremiums: {type: Boolean},
		showUnavailable: {type: Boolean},
		showAftermarket: {type: Boolean},
		showContainer: {type: Boolean},
		filterType: {type: Boolean},
		searchResultsAvailable: {type: Boolean},
		searchConfig: {type: Object},
		advancedOptions: {type: Array},
		searchToggleBtns: {type: Array},
		tldCategories: {type: Array},
		totalUnavailableDomains: {type: Number},
		currentPriceRange: {type: Number, state: true},
		searchAction: {type: String},
		checkedClass: {type: String},
		unCheckedClass: {type: String},
	};

	constructor() {
		super();
		this.advancedOptions = Util.session.advancedOptions ?? [];
		this.checkedClass =
			'Box-gap-spacing-2x_2hvKl Box-backgroundColor-blue_2PS2q Box-borderColor-blue_28uxe Box-bordered_ZIQTS Box-interactive_ij9NR Box-hoverable_1FPu7 Flex-flexInline_PeciM Flex-flexAlignItemsCenter_3oJ12 Text-size-base_3CRhE Text-weight-regular_Flodb Text-color-white_MQZPd Pill-root_3TDMD Pill-default_22iwf TogglePill-root_zPTX9 ToggleGroup-pill_2ytf9';
		this.unCheckedClass =
			'Box-gap-spacing-2x_2hvKl Box-backgroundColor-transparent_3WlDE Box-borderColor-grey_1sG0g Box-hoverBorderColor-blue_1Igbc Box-bordered_ZIQTS Box-interactive_ij9NR Box-hoverable_1FPu7 Flex-flexInline_PeciM Flex-flexAlignItemsCenter_3oJ12 Text-size-base_3CRhE Text-weight-regular_Flodb Text-color-anthracite_2apnl Pill-root_3TDMD Pill-default_22iwf TogglePill-root_zPTX9 ToggleGroup-pill_2ytf9';
	}

	async updated(changed) {
		if (changed.has('searchConfig') && this.searchAction === 'register') {
			this.tldCategories = this.searchConfig.categories.map(category => {
				return {
					id: category.id,
					name: category.name,
					icon: category.settings?.icon,
					default: category.settings?.default,
				};
			});
		}

		if (
			changed.has('searchToggleBtns') &&
			this.searchToggleBtns &&
			this.searchToggleBtns.length > 0
		) {
			this.showUnavailable = Util.findValueInArray(
				this.searchToggleBtns,
				'unavailable',
			);
			this.showPremiums = Util.findValueInArray(
				this.searchToggleBtns,
				'premiums',
			);
			this.showAftermarket = Util.findValueInArray(
				this.searchToggleBtns,
				'aftermarket',
			);
			this.filterType = Util.findValueInArray(
				this.searchToggleBtns,
				'filterType',
			);
		}
	}

	_priceRange(event) {
		if (event.target.id !== 'priceRangeInput') {
			event.preventDefault();
			return;
		}
		this.currentPriceRange =
			event.target.value > 1 ? event.target.value - 1 : 1;
		Util.params.filter = this.filterType ? 'RegistrationPrice' : 'RenewPrice';
		Util.params.filterPriceRange = this.currentPriceRange;
	}

	get _additionalConfig() {
		if (this.searchAction !== 'suggestions') {
			return;
		}
		const bindings = {
			requestLocationBasedResults: this.advancedOptions.includes(
				'locationBasedResults',
			),
			requestNoWeightedDomains:
				this.advancedOptions.includes('noWeightedDomains'),
		};
		return x$1`<load-template
			path="Container/Search/additional-config"
			.bindings=${bindings}
		></load-template>`;
	}

	get _categories() {
		if (this.searchAction !== 'register') {
			return;
		}

		const bindings = {
			totalCategories: this.tldCategories?.length ?? 0,
			tldCategories: this.tldCategories,
		};
		return x$1`<load-template
			path="Container/Search/categories"
			.bindings=${bindings}
		></load-template>`;
	}

	get _priceFilters() {
		if (
			this.searchAction !== 'register' ||
			!Util.session?.tldsRegisterPricing ||
			!Util.session?.tldsRegisterPricing
		) {
			return;
		}

		const tldRegisterPrices = Object.values(Util.session?.tldsRegisterPricing);
		const tldRenewPrices = Object.values(Util.session?.tldsRegisterPricing);
		const registerMax = Math.max(...tldRegisterPrices); // fetch the maximum tldPrice
		const renewMax = Math.max(...tldRenewPrices); // fetch the maximum tldPrice
		let max = registerMax > renewMax ? registerMax : renewMax;
		this.currentPriceRange = Util.params?.filterPriceRange ?? max;
		const rangeValues = [];
		rangeValues.push(1);
		const firstMedian = Math.ceil(parseInt(max) / 3);
		rangeValues.push(firstMedian);
		const secondMedian = Math.ceil(parseInt(firstMedian + max) / 2);
		rangeValues.push(secondMedian);
		rangeValues.push(Math.ceil(max / 10) * 10); // to nearest 10
		const rangeLabels = [];
		for (let i = 0; i < rangeValues.length; i++) {
			rangeLabels.push(
				x$1`<option value="${rangeValues[i]}">${rangeValues[i]}</option>`,
			);
		}

		const bindings = {
			checkedClass: this.checkedClass,
			unCheckedClass: this.unCheckedClass,
			filterType: this.filterType,
			currentPriceRange: this.currentPriceRange,
			currentPriceRangeLabel: this.searchResultsAvailable
				? '' + this.currentPriceRange
				: x$1`<data-list template="LoadMore/spinner" />`,
			rangeLabels: rangeLabels,
			maxRange: max + 10,
			resultsAvailable: !this.searchResultsAvailable,
		};
		return x$1`<load-template
			path="Container/Search/price-range-filter"
			.bindings=${bindings}
		></load-template>`;
	}

	render() {
		if (!this.searchOptions || !this.showContainer) {
			return;
		}

		const bindings = {
			categoriesTemplate: this._categories,
			additionalConfigTemplate: this._additionalConfig,
			priceRangeFilterTemplate: this._priceFilters,
			checkedClass: this.checkedClass,
			unCheckedClass: this.unCheckedClass,
			filterType: this.filterType,
			showPremiums: this.showPremiums,
			showUnavailable: this.showUnavailable,
			showAftermarket: this.showAftermarket,
			totalUnavailableDomains: this.totalUnavailableDomains,
		};
		return x$1`<load-template
			@change=${this._priceRange}
			path="Container/Search/search-filters"
			.bindings=${bindings}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('search-filters-toggle', SearchFiltersToggle);

class DomainInput extends s$1 {
	static properties = {
		searchTerm: {
			hasChanged(value, oldVal) {
				if (!oldVal) {
					Util.session.searchTerm = value;
					return true;
				} else if (!value) {
					return false;
				}
				Util.session.searchTerm = value;
				return value.length > 0 && value !== oldVal;
			},
		},
		searchResultsAvailable: {type: Boolean},
		searchToggleBtns: {type: Array},
		searchConfig: {type: Object},
		totalUnavailableDomains: {type: Number},
		searchAction: {type: String},
		showBulkInput: {type: Boolean},
		searchOptions: {type: Boolean},
	};

	constructor() {
		super();
		this.showBulkInput = Util.params.bulk ? true : false;
		this.searchOptions = Util.params.options ? true : false;
	}

	get _input() {
		this._advancedOptions();
		return this.renderRoot?.querySelector('#search') ?? null;
	}

	_advancedOptions() {
		let checkboxes = this.renderRoot.querySelectorAll(
			'input[type=checkbox][name=advancedOption]',
		);
		let enabledSettings = Array.from(checkboxes) // Convert checkboxes to an array to use filter and map.
			.filter(i => i.checked) // Use Array.filter to remove unchecked checkboxes.
			.map(i => i.value); // Use Array.map to extract only the checkbox values from the array of objects.
		Util.session.advancedOptions = enabledSettings;
	}

	/**
	 * This function toggles buttons based on user input and dispatches an event with updated filters
	 *
	 * @param {Object} element
	 * @returns void
	 */
	_toggleButtons(element) {
		// Get the name and value of the element triggering the function
		const {name, value} = element.target;
		// Get all inputs with the same name as the triggering element
		const inputs = this.renderRoot?.querySelectorAll(`input[name="${name}"]`);

		// Remove any existing filter with the same type as the triggering element
		Util.deleteValueFromArray(this.searchToggleBtns, 'type', name);

		// Create a new filter object and add it to the searchToggleBtns array
		const isHidden =
			name !== 'filterType' ? value !== 'hide' : value !== 'renewPrice';
		const filter = {type: name, show: isHidden};
		this.searchToggleBtns.push(filter);

		// Create a custom event with updated filters and dispatch it
		const options = {
			detail: {filters: this.searchToggleBtns},
			bubbles: true,
			composed: true,
		};
		this.dispatchEvent(new CustomEvent('cnicDomainFilters', options));

		// Toggle the buttons and return the result
		Util.toggleButtons(element, inputs);
	}

	/**
	 * This function handles a search event and dispatches an event with search term and search page information
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_searchHandler(event) {
		// Prevent the default form submission behavior
		event.preventDefault();

		if (!this.searchResultsAvailable) {
			return;
		}

		// Get the search term from the input element
		this.searchTerm = this._input?.value;

		// Check if the search term ends with a space and the search tab is "transfer"
		if (this.searchTerm.endsWith(' ') && this.searchAction === 'transfer') {
			// If the conditions are met, set the flag to show the bulk input
			this.showBulkInput = true;

			// Set the 'bulk' parameter to "1" in the current URL
			Util.params.bulk = '1';
		}

		// trim any whitespace
		this.searchTerm = this.searchTerm.trim();
		if (!this.searchTerm.length) {
			return; // return if search field is empty
		}

		// Toggle the search results availability flag
		this.searchResultsAvailable = !this.searchResultsAvailable;

		// Create a custom event with search term and search page information, and dispatch it
		const options = {
			detail: {searchTerm: this.searchTerm, searchPage: this.searchPage ?? 1},
			bubbles: true,
			composed: true,
		};
		this.dispatchEvent(new CustomEvent('cnicDomainSearch', options));
	}

	/**
	 * This function handles changes in the search form and calls the appropriate functions depending on the input
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_onFormChange(event) {
		// Define an array of available options
		const availableOptions = [
			'premiums',
			'unavailable',
			'aftermarket',
			'filterType',
		];

		// If the change is related to advanced options, call the _advancedOptions function
		if (event.target.name === 'advancedOption') {
			this._advancedOptions();
		}

		// If the changed input is an available option, call the _toggleButtons function and return
		else if (availableOptions.indexOf(event.target.name) > -1) {
			this._toggleButtons(event);
			return;
		}

		// If the changed input is not an available option, call the _searchHandler function and return
		return this._searchHandler(event);
	}

	/**
	 * This function handles the event when the user toggles the bulk input field and updates the URL accordingly
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_toggleBulkInputFieldHandler(event) {
		// Prevent the default behavior of the event
		event.preventDefault();

		// Get the current URL
		let oldUrl = window.location.href;

		// Toggle the showBulkInput flag
		this.showBulkInput = !this.showBulkInput;

		// If showBulkInput is true, add a "bulk" parameter to the URL
		if (this.showBulkInput) {
			Util.params.bulk = '1';
		} else {
			Util.params.bulk = '';
		}

		// Update the URL based on whether it already has a "bulk" parameter
		event.target.href = !oldUrl.match(/bulk/gi) ? window.location.href : oldUrl;
	}

	/**
	 * This function toggles the search options and updates the URL accordingly.
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_toggleSearchOptionsHandler(event) {
		// Prevent the default behavior of the event
		event.preventDefault();
		// Get the current URL
		let oldUrl = window.location.href;

		// Toggle the searchOptions flag
		this.searchOptions = !this.searchOptions;

		// If searchOptions is true, add an "options" parameter to the URL
		if (this.searchOptions) {
			Util.params.options = '1';
		} else {
			Util.params.options = '';
		}

		// Update the URL based on whether it already has an "options" parameter
		event.target.href = oldUrl.match(/options/gi)
			? window.location.href
			: oldUrl;
	}

	get _hideAdvancedOptions() {
		if (this.searchAction === 'transfer' || this.searchAction === 'whois') {
			this.searchOptions = false;
			return !this.searchOptions;
		}
	}

	get _hideBulkButton() {
		if (this.searchAction === 'whois') {
			this.showBulkInput = false;
			return !this.showBulkInput;
		}
	}

	get _hideTransferInfoIcon() {
		return this.searchAction !== 'transfer';
	}

	render() {
		const bindings = {
			showBulkIcon: this.showBulkInput,
		};

		const inputBulkButton = x$1`<data-list
			@click=${event => this._toggleBulkInputFieldHandler(event)}
			template="InputSearch/bulk-button"
			.data=${bindings}
			.isHidden=${this._hideBulkButton}
		/>`;
		const advancedOptionsButton = x$1`<data-list
			@click=${event => this._toggleSearchOptionsHandler(event)}
			template="InputSearch/options-button"
			.isHidden=${this._hideAdvancedOptions}
		/>`;
		const transferInfoIcon = x$1`<data-list
			template="InputSearch/transfer-info-button"
			.isHidden=${this._hideTransferInfoIcon}
		/>`;
		const searchOptionsToggleTemplateStartTag = x$1`<search-options-toggle
			.searchTerm=${this.searchTerm}
			searchAction=${this.searchAction}
			.showBulkInput=${this.showBulkInput}
		></search-options-toggle>`;
		const searchOptionsToggleTemplateEndTag = x$1`</search-options-toggle>`;
		const loadMoreButtonTemplate = x$1`<load-more-button
			@click=${event => this._searchHandler(event)}
			.searchResults=${this.searchResultsAvailable}
			searchTerm=${this.searchTerm}
			searchAction=${this.searchAction}
			datatype="search"
		/>`;
		const mobileAdvancedOptionsTemplate = x$1`<data-list
			@click=${event => this._toggleSearchOptionsHandler(event)}
			template="InputSearch/mobile-advanced-options"
			.data=${{searchOptions: this.searchOptions}}
			.isHidden=${this._hideAdvancedOptions}
		/>`;
		const domainPromotionsTemplate = x$1`<domain-promotions
			.showContainer=${!this._hideBulkButton}
			.searchConfig=${this.searchConfig}
		/>`;
		const searchFiltersToggleTemplate = x$1`<search-filters-toggle
			.showContainer=${!this._hideAdvancedOptions}
			.totalUnavailableDomains=${this.totalUnavailableDomains}
			.searchToggleBtns=${this.searchToggleBtns}
			.searchConfig=${this.searchConfig}
			searchAction=${this.searchAction}
			.searchOptions=${this.searchOptions}
			.tldCategories=${this.tldCategories}
			.searchResultsAvailable=${this.searchResultsAvailable}
		/>`;

		const data = {
			inputBulkButton: inputBulkButton,
			advancedOptionsButton: advancedOptionsButton,
			transferInfoIcon: transferInfoIcon,
			searchOptionsToggleTemplateStartTag: searchOptionsToggleTemplateStartTag,
			searchOptionsToggleTemplateEndTag: searchOptionsToggleTemplateEndTag,
			loadMoreButtonTemplate: loadMoreButtonTemplate,
			mobileAdvancedOptionsTemplate: mobileAdvancedOptionsTemplate,
			domainPromotionsTemplate: domainPromotionsTemplate,
			searchFiltersToggleTemplate: searchFiltersToggleTemplate,
		};

		return x$1`<data-list
			@change=${this._onFormChange}
			@submit=${this._searchHandler}
			template="Container/Search/main"
			.data=${data}
		/>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('domain-input', DomainInput);

class CartHandler {
	constructor(idnDomainName, domainName, isPremium, tldSupported, isAvailable) {
		this.idnDomainName = idnDomainName;
		this.domainName = domainName;
		this.isPremium = isPremium;
		this.tldSupported = tldSupported;
		this.isAvailable = isAvailable;
	}

	/**
	 * @param {String} code
	 */
	set eppCode(code) {
		this.domainEppCode = code;
	}

	/**
	 * @param {String} code
	 */
	set period(year) {
		this.registerPeriod = year;
	}

	static _updateCartCounter(totalItems) {
		const counterElement = document.querySelector('#cartItemCount');
		if (counterElement) {
			counterElement.innerHTML = `${totalItems}`;
		}
	}

	async _addDomainTransfer(payload) {
		const data = await Util.fetchData(
			Object.assign(
				{type: 'addDomainTransfer', eppcode: this.domainEppCode},
				payload,
			),
		);
		const [resolvedData] = await Promise.all(data);
		await this._getCartDomains();
		return resolvedData;
	}

	async _removeFromCart(payload) {
		const data = await Util.fetchData(
			Object.assign({type: 'removeFromCart'}, payload),
		);
		const [resolvedData] = await Promise.all(data);
		await this._getCartDomains();
		CartHandler._updateCartCounter(resolvedData?.cartCount ?? 0);
		return resolvedData ?? {result: 'removed'};
	}

	async _addToCart(payload) {
		const data = await Util.fetchData(
			Object.assign({type: 'addToCart'}, payload),
		);
		const [resolvedData] = await Promise.all(data);
		await this._updateCart(payload);
		await this._getCartDomains();
		return resolvedData;
	}

	async _getCartDomains() {
		const data = await Util.fetchData({type: 'getCartDomains'});
		const [resolvedData] = await Promise.all(data);
		Util.session.cartList = await resolvedData;
		CartHandler._updateCartCounter(Object.keys(Util.session.cartList).length);
		return resolvedData;
	}

	async _updateCart(payload) {
		const data = await Util.fetchData(
			Object.assign({type: 'updateCart'}, payload),
		);
		const [resolvedData] = await Promise.all(data);
		return resolvedData;
	}

	async init(
		addToCart,
		registerPeriod,
		updateRequest = false,
		domainTransfer = false,
	) {
		if (
			!addToCart &&
			!this.tldSupported &&
			!this.isAvailable &&
			!domainTransfer
		) {
			return;
		}

		this.period = registerPeriod;

		let payload = {
			domainIdn: this.idnDomainName,
			domainPc: this.domainName,
			domainPeriod: this.registerPeriod,
			domainPremium: this.isPremium,
		};

		if (domainTransfer) {
			const data = await this._addDomainTransfer(payload);
			return data;
		}

		if (addToCart && updateRequest === true) {
			const data = await this._updateCart(payload);
			return data;
		}

		if (addToCart) {
			const data = await this._removeFromCart(payload);
			return data;
		} else {
			const data = await this._addToCart(payload);
			const cachedData = new UniqueObjectCache('CachedDomainList');
			cachedData.deleteDomainCache(this.domainName);
			return data;
		}
	}
}

class DomainListItem extends s$1 {
	static properties = {
		domainName: {type: String},
		domainTld: {type: String},
		idnDomainName: {type: String},
		domainStatus: {type: String},
		domainEppCode: {type: String},
		domainGroup: {type: String},
		cartItemType: {type: String},
		availabilityReason: {type: String},
		registerPeriod: {type: Number},
		isAvailable: {type: Boolean},
		isPremium: {type: Boolean},
		isBaseDomain: {type: Boolean},
		tldSupported: {type: Boolean},
		addToCart: {type: Boolean},
		itemInCartSession: {type: Boolean},
		searchToggleBtns: {},
		domainPricing: {},
		showLoading: {},
		showPremiums: {},
		showUnavailable: {},
		showAftermarket: {},
		showTransferBtn: {},
		transferMsgError: {},
		cartHandler: {},
	};

	constructor() {
		super();
		this.showLoading = false;
		this.addToCart = false;
		this.registerPrices = [];
		this.renewPrices = [];
		this.showTransferBtn = Util.session.config.showDomainTransfers;
	}

	async updated(changed) {
		if (changed.has('searchToggleBtns') && this.searchToggleBtns) {
			this.showUnavailable = Util.findValueInArray(
				this.searchToggleBtns,
				'unavailable',
			)?.show;
			this.showPremiums = Util.findValueInArray(
				this.searchToggleBtns,
				'premiums',
			)?.show;
			this.showAftermarket = Util.findValueInArray(
				this.searchToggleBtns,
				'aftermarket',
			)?.show;
		}

		if (
			changed.has('domainEppCode') &&
			!this.addToCart &&
			this._isTransferable()
		) {
			await this.initiateTransfer();
		}
	}

	async initiateTransfer() {
		if (Util.params.action !== 'transfer') {
			return;
		}
		const data = this._addToCart(false, true);
		data.then(data => {
			const result = data?.result ?? data;
			if (result === 'added') {
				this.cartItemType = 'transfer'; // set cart item type to transfer
				this.addToCart = true; // add to cart
			} else if (result?.unavailable) {
				// data.unavailable property tells why the domain not available to add into the cart
				this.transferMsgError = result.unavailable;
			} else {
				this.transferMsgError = x$1`${getMessage(
						'domain_transfer_epp_error_msg',
					)}
					<a
						href="#toggle"
						@click=${async event => await this._domainTransfer(event)}
						id="domainTransferBtn"
						>${getMessage('transferable_domain_link_label_tryagain')}</a
					>`;
			}
		});
	}

	async _addToCart(updateRequest = false, domainTransfer = false) {
		if (this.showLoading) {
			return;
		}

		this.showLoading = !this.showLoading;
		this.cartHandler ??= new CartHandler(
			this.idnDomainName,
			this.domainName,
			this.isPremium,
			this.tldSupported,
			this.isAvailable,
		);

		this.cartHandler.eppCode = this.domainEppCode;

		const data = await this.cartHandler.init(
			this.addToCart,
			this.registerPeriod,
			updateRequest,
			domainTransfer,
		);
		if (data?.result) {
			this.addToCart = !this.addToCart;
			this.itemInCartSession = false;
			if (!domainTransfer) {
				this.cartItemType = 'register';
			}
		}
		this.showLoading = !this.showLoading;
		return data;
	}

	availableStatusIcon() {
		return x$1`<data-list
			template="Container/DomainListItem/status-available-icon"
		/>`;
	}

	notAvailableStatusIcon() {
		return x$1`<data-list
			template="Container/DomainListItem/status-not-available-icon"
		/>`;
	}

	infoStatusIcon() {
		return x$1`<data-list
			template="Container/DomainListItem/status-info-icon"
		/>`;
	}

	_isTransferable() {
		return (
			this.showTransferBtn &&
			!this.isAvailable &&
			this.tldSupported &&
			this.isBaseDomain &&
			!this.showLoading
		);
	}

	addToCartBtn() {
		if ((this.addToCart && !this.cartItemType) || !this.tldSupported) {
			return;
		}
		if (this.showLoading) {
			return x$1`<data-list
				template="Container/DomainListItem/add-to-cart-loading-icon"
			/>`;
		}

		if (this.addToCart) {
			return x$1`<data-list
				@click=${() => this._addToCart()}
				template="Container/DomainListItem/remove-from-cart-icon"
			/>`;
		}

		if (!this.isAvailable) {
			return;
		}

		return x$1`<data-list
			@click=${() => this._addToCart()}
			template="Container/DomainListItem/add-to-cart-btn"
		/>`;
	}

	_domainRegisterPeriods() {
		if (!this.isAvailable && !this.domainPricing && this.domainPricing.length) {
			return;
		}
		let pricingOptions = [];
		this.registerPeriod = parseInt(this.registerPeriod);
		pricingOptions = Object.keys(this.domainPricing).map(period => {
			period = parseInt(period);
			return x$1`<option
				class=""
				value="${period}"
				?selected=${this.registerPeriod === period}
			>
				${period} ${getMessage('year_label')}
			</option>`;
		});

		return pricingOptions;
	}

	_showBadges() {
		let badges = [];
		if (this.isPremium && !this.isAftermarket) {
			badges.push(
				x$1`<data-list
					template="Container/DomainListItem/domain-premium-badge"
				/>`,
			);
		}

		if (this.isPremium && this.isAftermarket) {
			badges.push(
				x$1`<data-list
					template="Container/DomainListItem/domain-aftermarket-badge"
				/>`,
			);
		}

		if (
			this.isAvailable &&
			this.tldSupported &&
			this.domainPricing[this.registerPeriod].register.price >
				this.domainPricing[this.registerPeriod].renew.price
		) {
			badges.push(
				x$1`<data-list
					template="Container/DomainListItem/domain-lower-renew-price-badge"
				/>`,
			);
		}

		if (this.tldSupported && this.domainGroup) {
			const badgeColors = {
				hot: 'Badge-intentDanger_1Tpoo',
				sale: 'Badge-intentPromotional_sbT5N',
				new: 'Badge-intentNew',
			};

			const data = {
				badgeColor: badgeColors[this.domainGroup] ?? '',
				domainGroup: this.domainGroup,
			};
			badges.push(
				x$1`<data-list
					template="Container/DomainListItem/domain-group-badge"
					.data=${data}
				/>`,
			);
		}

		if (this._isTransferable() && !this.transferMsgError) {
			badges.push(
				x$1`<data-list
					template="Container/DomainListItem/transferable-label"
				/>`,
			);
		}

		if (this._isTransferable() && this.transferMsgError) {
			const data = {msg: this.transferMsgError};
			badges.push(
				x$1`<data-list
					template="Container/DomainListItem/transfer-error-msg"
					.data=${data}
				/>`,
			);
		}

		if (badges.length > 0) {
			const data = {badges: badges};
			return x$1`<data-list
				template="Container/DomainListItem/domain-badges-main"
				.data=${data}
			/>`;
		}
	}

	_hideDomain() {
		let hideDomain = false;
		if (!this.isBaseDomain && this.isPremium && !this.showPremiums) {
			hideDomain = true;
		}
		if (!this.isBaseDomain && this.isAftermarket && !this.showAftermarket) {
			hideDomain = true;
		}
		if (!this.isBaseDomain && !this.isAvailable && !this.showUnavailable) {
			hideDomain = true;
		}
		return hideDomain;
	}

	_domainWhois(e) {
		e.preventDefault();
		window.history.pushState(null, null, e.target.href);
		let loaderEvent = new Event('cnicUrlUpdate', {
			bubbles: true,
			composed: true,
		});
		this.dispatchEvent(loaderEvent);
	}

	async _domainTransfer(event) {
		event.preventDefault();
		const target = event.target; // transfer link element
		const modal = jQuery('#modalAjax');
		modal.modal('show');
		const loader = modal.find('.loader');
		const modalBody = modal.find('.modal-body');
		const modalSubmit = modal.find('.modal-submit');
		modalSubmit.prop('disabled', false);
		loader.hide(); // hide modal loader
		modal.find('.modal-title').text('Transfer domain ' + this.domainName);

		const data = {
			transferMsgError: this.transferMsgError ?? '',
			domainEppCode: this.domainEppCode ?? '',
		};
		const modalBodyTmpl = `<data-list template="Container/DomainListItem/domain-transfer-modal" .data=${data} />`;
		modalBody.html(modalBodyTmpl);

		modalSubmit.click(async e => {
			e.preventDefault();
			loader.show(); // show modal loader
			const modalInput = modalBody.find('input');
			this.domainEppCode = modalInput.val();
			const tldNotRequireEppCode =
				Util.session.config.tldsWithoutEppCode[this.domainTld];

			modalBody.find('.modal-info').html('');
			if (!tldNotRequireEppCode && !this.domainEppCode.length) {
				loader.hide(); // hide modal loader
				modalBody
					.find('.modal-info')
					.html(getMessage('domain_transfer_epp_error_msg'));
				return;
			}
			modalInput.prop('disabled', true);
			const data = await this._addToCart(false, true);
			const result = data?.result ?? data;

			if (result === 'added') {
				loader.hide(); // hide modal loader
				target.remove(); // remove transfer link element
				this.cartItemType = 'transfer'; // set cart item type to transfer
				this.addToCart = true; // add to cart
				this.transferMsgError = null;
				modal.modal('hide'); // toggle modal
				modalSubmit.prop('disabled', true);
			} else if (result?.unavailable) {
				loader.hide(); // hide modal loader
				modalBody.find('.modal-info').html(result.unavailable);
			}
		});
	}

	_additionalInfo() {
		const infos = [];

		if (this._isTransferable() && !this.addToCart) {
			infos.push(
				x$1`&nbsp;<a
						href="#toggle"
						@click=${async event => await this._domainTransfer(event)}
						id="domainTransferBtn"
					>
						${this.transferMsgError
							? `${getMessage('transferable_domain_link_label_tryagain')}`
							: `${getMessage('transferable_domain_link_label_transferit')}`}</a
					>`,
			);
			infos.push(x$1`&nbsp;${getMessage('separator_label')}&nbsp;`);
		}

		if (!this.isAvailable && Util.session.config.features.WhoIs) {
			const whoisUrl = new URL(`${cnicWebRootPath}/mydomainsearch.php`);
			whoisUrl.searchParams.append('searchTerm', this.idnDomainName);
			whoisUrl.searchParams.append('action', 'whois');
			infos.push(
				x$1`&nbsp;<a
						href=${whoisUrl.toString()}
						@click=${this._domainWhois}
						data-toggle="tooltip"
						title="${getMessage('tab_heading_whois')}"
						>${getMessage('whoisLabel')}</a
					>`,
			);
			infos.push(x$1`&nbsp;${getMessage('separator_label')}&nbsp;`);
		}

		if (this.domainStatus === 'reserved') {
			const contactUrl = new URL(`${cnicWebRootPath}/contact.php`);
			contactUrl.searchParams.append(
				'subject',
				getMessage('contact_reserved_subject', this.idnDomainName),
			);
			contactUrl.searchParams.append(
				'message',
				getMessage('contact_reserved_message', this.idnDomainName),
			);
			infos.push(
				x$1`&nbsp;<a
						href=${contactUrl.toString()}
						data-toggle="tooltip"
						title="${getMessage('label_descr_reserved')}"
						>${getMessage('reserved_label')}</a
					>`,
			);
			infos.push(x$1`&nbsp;${getMessage('separator_label')}&nbsp;`);
		}

		// remove the last value from array which is "separator_label"
		infos.pop();

		return infos;
	}

	_getDomainStatus() {
		if (this.cartItemType !== 'transfer' && !this.addToCart) {
			return getMessage(this.domainStatus);
		}
	}

	_domainPricing() {
		if (this.isAvailable && this.tldSupported) {
			const data = {
				domainRegisterPeriods: this._domainRegisterPeriods(),
				registerPrice: this.domainPricing[this.registerPeriod].register.format,
				renewPrice: this.domainPricing[this.registerPeriod].renew.format,
				periodSuffix: Util.ordinalSuffixOf(this.registerPeriod), // returns 1st, 2nd, 3rd etc
			};
			return x$1`<data-list
				template="Container/DomainListItem/domain-price"
				.data=${data}
			/>`;
		}

		const data = {
			domainStatus: this._getDomainStatus(),
			availabilityReason: this.availabilityReason,
		};
		return x$1`<data-list
			template="Container/DomainListItem/domain-status"
			.data=${data}
		/>`;
	}

	async _changeHandler(event) {
		event.preventDefault();
		const targetId =
			event.target.id ||
			event.target.parentElement.id ||
			event.target.parentElement.parentElement.id;

		if (targetId === 'changeDomainPeriod') {
			this.registerPeriod = parseInt(event.target.value);
			if (this.addToCart) {
				await this._addToCart(true);
			}
		}
	}

	get _addToCartMsg() {
		if (!this.addToCart || (this.addToCart && this.itemInCartSession)) {
			return;
		}
		const bindings = {domainName: this.domainName};
		return x$1`<data-list
			.data=${bindings}
			template="Container/DomainListItem/add-to-cart-success-alert"
		/>`;
	}

	render() {
		if (this._hideDomain()) {
			return;
		}

		const domainBadges = this._showBadges();
		let domainStatusIcon = '';
		if (this.isBaseDomain && this.isAvailable) {
			domainStatusIcon = this.availableStatusIcon();
		} else if (this._isTransferable()) {
			domainStatusIcon = this.infoStatusIcon();
		} else if (this.isBaseDomain && !this.isAvailable) {
			domainStatusIcon = this.notAvailableStatusIcon();
		}
		const domainPricing = this._domainPricing();
		const domainAdditionalInfo = this._additionalInfo();
		const addToCartBtn = this.addToCartBtn();
		const trimmedDomainName = Util.trimMiddleString(this.domainName);
		const data = {
			domainPricing: domainPricing,
			domainAdditionalInfo: domainAdditionalInfo,
			addToCartBtn: addToCartBtn,
			trimmedDomainName: trimmedDomainName,
			domainStatusIcon: domainStatusIcon,
			domainBadges: domainBadges,
			domainName: this.domainName,
			idnDomainName: this.idnDomainName,
			isExactSearchDomain: this.isBaseDomain,
			availabilityReason: this.availabilityReason,
			addToCartMsg: this._addToCartMsg,
		};

		return x$1`<data-list
			@change=${this._changeHandler}
			template="Container/DomainListItem/main"
			.data=${data}
		/>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('domain-list-item', DomainListItem);

class LoadingDomainList extends s$1 {
	static properties = {
		searchResultsAvailable: {},
	};

	constructor() {
		super();
	}

	render() {
		if (this.searchResultsAvailable) {
			return;
		}

		return x$1`<load-template
			path="LoadMore/domains-placeholder"
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('loading-domain-list', LoadingDomainList);

class Spotlight extends s$1 {
	static properties = {
		spotlightTlds: {type: Object},
		tldBoxWidth: {type: String},
		showContainer: {type: Boolean},
		content: {},
	};

	constructor() {
		super();
		this.content = [];
		this.defaultWidth = '150px';
	}

	firstUpdated() {
		if (!this.spotlightTlds?.length) {
			return;
		}

		this._spotlightTlds();
	}

	generateDarkColor() {
		// Generate random values for red, green, and blue between 0 and 127
		const r = Math.floor(Math.random() * 140);
		const g = Math.floor(Math.random() * 155);
		const b = Math.floor(Math.random() * 145);

		// Return the RGB value as a string
		return `rgb(${r},${g},${b})`;
	}

	async _spotlightTlds() {
		const content = [];
		for (const tld of this.spotlightTlds) {
			const spotlightObject = {
				color: this.generateDarkColor(),
				tldName: tld.tld,
			};
			if (tld?.img) {
				spotlightObject.tldImage = tld.img;
			}

			if (tld?.group) {
				spotlightObject.tldGroup = tld.group;
				spotlightObject.tldGroupBadge = `--background-ribbon-color: var(--tld-group-${
					tld.group
				}-bg);--badge-label: "${getMessage(`group${tld.group}`)}"`;
			}

			if (tld?.register && tld?.renew) {
				spotlightObject.tldRegisterPrice = tld.register;
				spotlightObject.tldRenewPrice = tld.renew;
			}

			if (tld?.transfer) {
				spotlightObject.tldTransferPrice = tld.transfer;
			}

			let fontSize =
				parseInt(this.tldBoxWidth ?? this.defaultWidth) /
				(tld.tld.length * 0.6);
			fontSize = fontSize > 80 ? 80 : fontSize;
			spotlightObject.fontSize = `${fontSize}px`;

			content.push(spotlightObject);
		}

		this.content = content;
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		const bindings = {
			spotlight: this.content,
			webRootPath: cnicWebRootPath,
			tldBoxWidth: this.tldBoxWidth ?? this.defaultWidth,
		};

		return x$1`<load-template
			path="Container/spotlight"
			.bindings=${bindings}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('spotlight-tlds', Spotlight);

class DataList extends s$1 {
	static properties = {
		data: {},
		isHidden: {},
		template: {},
	};

	constructor() {
		super();
	}

	render() {
		if (this.isHidden) {
			return;
		}
		const bindings = {data: this.data};
		return x$1`
			<load-template
				.path=${this.template}
				.bindings=${bindings}
			></load-template>
		`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('data-list', DataList);

class DataSorting extends s$1 {
	static properties = {
		searchTerm: {type: String},
		sort: {type: String},
		sortDirection: {type: String},
		showContainer: {type: Boolean},
	};

	constructor() {
		super();
		this.sortDirection = Util.params?.sortDir ?? 'ASC';
		this.sort = Util.params?.sort ?? 'TldOrder';
	}

	async _requestSorting(e) {
		const {target} = e;
		const {name, value} = target;
		const {params} = Util;

		this.searchResultsAvailable = false;

		if (name === 'sortBy') {
			params.sort = value;
		} else if (name === 'sortByDir') {
			const direction = value === 'ASC' ? 'DESC' : 'ASC';
			params.sortDir = direction;
			target.value = direction;
			const icon = target.parentNode.querySelector('i');
			const iconClass = direction === 'ASC' ? 'down' : 'up-alt';
			icon.className = `fas fa-sort-alpha-${iconClass} selectSortListDir`;
		}

		if (!params.sort) {
			params.sort = 'TldOrder';
		}

		if (!params.sortDir) {
			params.sortDir = 'DESC';
		}

		this.sort = Util.params.sort;
		this.sortDirection = params.sortDir;

		const searchParams = {
			searchPage: 1,
			searchTerm: this.searchTerm,
			sort: this.sort,
			sortDirection: this.sortDirection,
		};

		const options = {
			detail: searchParams,
			bubbles: true,
			composed: true,
		};
		this.dispatchEvent(new CustomEvent('cnicDomainSearch', options));
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		const orderType = ['TldOrder', 'TldName', 'DomainName']; // "RegistrationPrice", "RenewPrice"
		const orderList = orderType.map(
			item =>
				x$1` <option value="${item}" ?selected=${this.sort === item}>
					${getMessage(`sort_label_${item.toLowerCase()}`)}
				</option>`,
		);
		const bindings = {orderList: orderList, sortDirection: this.sortDirection};
		return x$1`
			<load-template
				@change=${this._requestSorting}
				path="Container/Search/sort-selector"
				.bindings=${bindings}
			></load-template>
		`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('data-sorting', DataSorting);
