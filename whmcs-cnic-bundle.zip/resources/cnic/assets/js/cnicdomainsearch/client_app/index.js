/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$3=globalThis,e$5=t$3.ShadowRoot&&(void 0===t$3.ShadyCSS||t$3.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,s$3=Symbol(),o$4=new WeakMap;let n$3 = class n{constructor(t,e,o){if(this._$cssResult$=!0,o!==s$3)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e;}get styleSheet(){let t=this.o;const s=this.t;if(e$5&&void 0===t){const e=void 0!==s&&1===s.length;e&&(t=o$4.get(s)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),e&&o$4.set(s,t));}return t}toString(){return this.cssText}};const r$3=t=>new n$3("string"==typeof t?t:t+"",void 0,s$3),i$4=(t,...e)=>{const o=1===t.length?t[0]:e.reduce(((e,s,o)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(s)+t[o+1]),t[0]);return new n$3(o,t,s$3)},S$2=(s,o)=>{if(e$5)s.adoptedStyleSheets=o.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet));else for(const e of o){const o=document.createElement("style"),n=t$3.litNonce;void 0!==n&&o.setAttribute("nonce",n),o.textContent=e.cssText,s.appendChild(o);}},c$3=e$5?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return r$3(e)})(t):t;

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const i$3=globalThis,e$4=i$3.trustedTypes,h$2=e$4?e$4.emptyScript:"",r$2=i$3.reactiveElementPolyfillSupport,o$3={toAttribute(t,s){switch(s){case Boolean:t=t?h$2:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t);}return t},fromAttribute(t,s){let i=t;switch(s){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t);}catch(t){i=null;}}return i}},n$2=(t,s)=>s!==t&&(s==s||t==t),a$2={attribute:!0,type:String,converter:o$3,reflect:!1,hasChanged:n$2},c$2="finalized";let l$2 = class l extends HTMLElement{static addInitializer(t){this.finalize(),(this.i??=[]).push(t);}static get observedAttributes(){this.finalize();const t=[];for(const[s,i]of this.elementProperties){const e=this._$El(s,i);void 0!==e&&(this._$Eh.set(e,s),t.push(e));}return t}static createProperty(t,s=a$2){if(s.state&&(s.attribute=!1),this.finalize(),this.elementProperties.set(t,s),!s.noAccessor&&!this.prototype.hasOwnProperty(t)){const i=Symbol(),e=this.getPropertyDescriptor(t,i,s);void 0!==e&&Object.defineProperty(this.prototype,t,e);}}static getPropertyDescriptor(t,s,i){return {get(){return this[s]},set(e){const h=this[t];this[s]=e,this.requestUpdate(t,h,i);},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)||a$2}static finalize(){if(this.hasOwnProperty(c$2))return !1;this[c$2]=!0;const t=Object.getPrototypeOf(this);if(t.finalize(),void 0!==t.i&&(this.i=[...t.i]),this.elementProperties=new Map(t.elementProperties),this._$Eh=new Map,this.hasOwnProperty("properties")){const t=this.properties,s=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const i of s)this.createProperty(i,t[i]);}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(s){const i=[];if(Array.isArray(s)){const e=new Set(s.flat(1/0).reverse());for(const s of e)i.unshift(c$3(s));}else void 0!==s&&i.push(c$3(s));return i}static _$El(t,s){const i=s.attribute;return !1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}constructor(){super(),this._$Ep=new Map,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this.v();}v(){this._$E_=new Promise((t=>this.enableUpdating=t)),this._$AL=new Map,this._$Eg(),this.requestUpdate(),this.constructor.i?.forEach((t=>t(this)));}addController(t){(this._$ES??=[]).push(t),void 0!==this.renderRoot&&this.isConnected&&t.hostConnected?.();}removeController(t){this._$ES?.splice(this._$ES.indexOf(t)>>>0,1);}_$Eg(){const t=this.constructor.elementProperties;for(const s of t.keys())this.hasOwnProperty(s)&&(this._$Ep.set(s,this[s]),delete this[s]);}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return S$2(t,this.constructor.elementStyles),t}connectedCallback(){void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),this._$ES?.forEach((t=>t.hostConnected?.()));}enableUpdating(t){}disconnectedCallback(){this._$ES?.forEach((t=>t.hostDisconnected?.()));}attributeChangedCallback(t,s,i){this._$AK(t,i);}_$EO(t,s,i=a$2){const e=this.constructor._$El(t,i);if(void 0!==e&&!0===i.reflect){const h=(void 0!==i.converter?.toAttribute?i.converter:o$3).toAttribute(s,i.type);this._$Em=t,null==h?this.removeAttribute(e):this.setAttribute(e,h),this._$Em=null;}}_$AK(t,s){const i=this.constructor,e=i._$Eh.get(t);if(void 0!==e&&this._$Em!==e){const t=i.getPropertyOptions(e),h="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==t.converter?.fromAttribute?t.converter:o$3;this._$Em=e,this[e]=h.fromAttribute(s,t.type),this._$Em=null;}}requestUpdate(t,s,i){let e=!0;void 0!==t&&(((i=i||this.constructor.getPropertyOptions(t)).hasChanged||n$2)(this[t],s)?(this._$AL.has(t)||this._$AL.set(t,s),!0===i.reflect&&this._$Em!==t&&(void 0===this._$EC&&(this._$EC=new Map),this._$EC.set(t,i))):e=!1),!this.isUpdatePending&&e&&(this._$E_=this._$Ej());}async _$Ej(){this.isUpdatePending=!0;try{await this._$E_;}catch(t){Promise.reject(t);}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;this.hasUpdated,this._$Ep&&=this._$Ep.forEach(((t,s)=>this[s]=t));let t=!1;const s=this._$AL;try{t=this.shouldUpdate(s),t?(this.willUpdate(s),this._$ES?.forEach((t=>t.hostUpdate?.())),this.update(s)):this._$Ek();}catch(s){throw t=!1,this._$Ek(),s}t&&this._$AE(s);}willUpdate(t){}_$AE(t){this._$ES?.forEach((t=>t.hostUpdated?.())),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t);}_$Ek(){this._$AL=new Map,this.isUpdatePending=!1;}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$E_}shouldUpdate(t){return !0}update(t){this._$EC&&=this._$EC.forEach(((t,s)=>this._$EO(s,this[s],t))),this._$Ek();}updated(t){}firstUpdated(t){}};l$2[c$2]=!0,l$2.elementProperties=new Map,l$2.elementStyles=[],l$2.shadowRootOptions={mode:"open"},r$2?.({ReactiveElement:l$2}),(i$3.reactiveElementVersions??=[]).push("2.0.0-pre.0");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$2=globalThis,s$2=t$2.trustedTypes,e$3=s$2?s$2.createPolicy("lit-html",{createHTML:t=>t}):void 0,n$1="$lit$",o$2=`lit$${(Math.random()+"").slice(9)}$`,h$1="?"+o$2,r$1=`<${h$1}>`,a$1=document,l$1=()=>a$1.createComment(""),c$1=t=>null===t||"object"!=typeof t&&"function"!=typeof t,d$1=Array.isArray,u$1=t=>d$1(t)||"function"==typeof t?.[Symbol.iterator],m$1="[ \t\n\f\r]",p$1=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,v$1=/-->/g,f$1=/>/g,g$1=RegExp(`>|${m$1}(?:([^\\s"'>=/]+)(${m$1}*=${m$1}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),_$1=/'/g,$$2=/"/g,y$1=/^(?:script|style|textarea|title)$/i,k$1=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),b$1=k$1(1),T$1=Symbol.for("lit-noChange"),w$1=Symbol.for("lit-nothing"),A$1=new WeakMap,E$1=a$1.createTreeWalker(a$1,129),C$1=(t,i)=>{const s=t.length-1,h=[];let a,l=2===i?"<svg>":"",c=p$1;for(let i=0;i<s;i++){const s=t[i];let e,d,u=-1,m=0;for(;m<s.length&&(c.lastIndex=m,d=c.exec(s),null!==d);)m=c.lastIndex,c===p$1?"!--"===d[1]?c=v$1:void 0!==d[1]?c=f$1:void 0!==d[2]?(y$1.test(d[2])&&(a=RegExp("</"+d[2],"g")),c=g$1):void 0!==d[3]&&(c=g$1):c===g$1?">"===d[0]?(c=a??p$1,u=-1):void 0===d[1]?u=-2:(u=c.lastIndex-d[2].length,e=d[1],c=void 0===d[3]?g$1:'"'===d[3]?$$2:_$1):c===$$2||c===_$1?c=g$1:c===v$1||c===f$1?c=p$1:(c=g$1,a=void 0);const k=c===g$1&&t[i+1].startsWith("/>")?" ":"";l+=c===p$1?s+r$1:u>=0?(h.push(e),s.slice(0,u)+n$1+s.slice(u)+o$2+k):s+o$2+(-2===u?i:k);}const d=l+(t[s]||"<?>")+(2===i?"</svg>":"");if(!Array.isArray(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return [void 0!==e$3?e$3.createHTML(d):d,h]};let P$1 = class P{constructor({strings:t,_$litType$:e},r){let a;this.parts=[];let c=0,d=0;const u=t.length-1,m=this.parts,[p,v]=C$1(t,e);if(this.el=P.createElement(p,r),E$1.currentNode=this.el.content,2===e){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes);}for(;null!==(a=E$1.nextNode())&&m.length<u;){if(1===a.nodeType){if(a.hasAttributes())for(const t of a.getAttributeNames())if(t.endsWith(n$1)){const i=v[d++],s=a.getAttribute(t).split(o$2),e=/([.?@])?(.*)/.exec(i);m.push({type:1,index:c,name:e[2],strings:s,ctor:"."===e[1]?I$1:"?"===e[1]?M$1:"@"===e[1]?R$1:S$1}),a.removeAttribute(t);}else t.startsWith(o$2)&&(m.push({type:6,index:c}),a.removeAttribute(t));if(y$1.test(a.tagName)){const t=a.textContent.split(o$2),i=t.length-1;if(i>0){a.textContent=s$2?s$2.emptyScript:"";for(let s=0;s<i;s++)a.append(t[s],l$1()),E$1.nextNode(),m.push({type:2,index:++c});a.append(t[i],l$1());}}}else if(8===a.nodeType)if(a.data===h$1)m.push({type:2,index:c});else {let t=-1;for(;-1!==(t=a.data.indexOf(o$2,t+1));)m.push({type:7,index:c}),t+=o$2.length-1;}c++;}}static createElement(t,i){const s=a$1.createElement("template");return s.innerHTML=t,s}};function V$1(t,i,s=t,e){if(i===T$1)return i;let n=void 0!==e?s._$Co?.[e]:s._$Cl;const o=c$1(i)?void 0:i._$litDirective$;return n?.constructor!==o&&(n?._$AO?.(!1),void 0===o?n=void 0:(n=new o(t),n._$AT(t,s,e)),void 0!==e?(s._$Co??=[])[e]=n:s._$Cl=n),void 0!==n&&(i=V$1(t,n._$AS(t,i.values),n,e)),i}let L$1 = class L{constructor(t,i){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=i;}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:i},parts:s}=this._$AD,e=(t?.creationScope??a$1).importNode(i,!0);E$1.currentNode=e;let n=E$1.nextNode(),o=0,h=0,r=s[0];for(;void 0!==r;){if(o===r.index){let i;2===r.type?i=new N$1(n,n.nextSibling,this,t):1===r.type?i=new r.ctor(n,r.name,r.strings,this,t):6===r.type&&(i=new H$1(n,this,t)),this._$AV.push(i),r=s[++h];}o!==r?.index&&(n=E$1.nextNode(),o++);}return e}p(t){let s=0;for(const e of this._$AV)void 0!==e&&(void 0!==e.strings?(e._$AI(t,e,s),s+=e.strings.length-2):e._$AI(t[s])),s++;}};let N$1 = class N{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,i,s,e){this.type=2,this._$AH=w$1,this._$AN=void 0,this._$AA=t,this._$AB=i,this._$AM=s,this.options=e,this._$Cv=e?.isConnected??!0;}get parentNode(){let t=this._$AA.parentNode;const i=this._$AM;return void 0!==i&&11===t?.nodeType&&(t=i.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,s=this){t=V$1(this,t,s),c$1(t)?t===w$1||null==t||""===t?(this._$AH!==w$1&&(this._$AR()),this._$AH=w$1):t!==this._$AH&&t!==T$1&&this._(t):void 0!==t._$litType$?this.g(t):void 0!==t.nodeType?this.$(t):u$1(t)?this.T(t):this._(t);}k(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}$(t){this._$AH!==t&&(this._$AR(),this._$AH=this.k(t));}_(t){if(this._$AH!==w$1&&c$1(this._$AH)){const s=this._$AA.nextSibling;s.data=t;}else this.$(a$1.createTextNode(t));this._$AH=t;}g(t){const{values:s,_$litType$:e}=t,n="number"==typeof e?this._$AC(t):(void 0===e.el&&(e.el=P$1.createElement(e.h,this.options)),e);if(this._$AH?._$AD===n)this._$AH.p(s);else {const t=new L$1(n,this),e=t.u(this.options);t.p(s),this.$(e),this._$AH=t;}}_$AC(t){let i=A$1.get(t.strings);return void 0===i&&A$1.set(t.strings,i=new P$1(t)),i}T(t){d$1(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH;let s,e=0;for(const n of t)e===i.length?i.push(s=new N(this.k(l$1()),this.k(l$1()),this,this.options)):s=i[e],s._$AI(n),e++;e<i.length&&(this._$AR(s&&s._$AB.nextSibling,e),i.length=e);}_$AR(t=this._$AA.nextSibling,i){for(this._$AP?.(!1,!0,i);t&&t!==this._$AB;){const i=t.nextSibling;t.remove(),t=i;}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t));}};let S$1 = class S{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,i,s,e,n){this.type=1,this._$AH=w$1,this._$AN=void 0,this.element=t,this.name=i,this._$AM=e,this.options=n,s.length>2||""!==s[0]||""!==s[1]?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=w$1;}_$AI(t,i=this,s,e){const n=this.strings;let o=!1;if(void 0===n)t=V$1(this,t,i,0),o=!c$1(t)||t!==this._$AH&&t!==T$1,o&&(this._$AH=t);else {const e=t;let h,r;for(t=n[0],h=0;h<n.length-1;h++)r=V$1(this,e[s+h],i,h),r===T$1&&(r=this._$AH[h]),o||=!c$1(r)||r!==this._$AH[h],r===w$1?t=w$1:t!==w$1&&(t+=(r??"")+n[h+1]),this._$AH[h]=r;}o&&!e&&this.j(t);}j(t){t===w$1?this.element.removeAttribute(this.name):(this.element.setAttribute(this.name,t??""));}};let I$1 = class I extends S$1{constructor(){super(...arguments),this.type=3;}j(t){this.element[this.name]=t===w$1?void 0:t;}};let M$1 = class M extends S$1{constructor(){super(...arguments),this.type=4;}j(t){this.element.toggleAttribute(this.name,!!t&&t!==w$1);}};let R$1 = class R extends S$1{constructor(t,i,s,e,n){super(t,i,s,e,n),this.type=5;}_$AI(t,s=this){if((t=V$1(this,t,s,0)??w$1)===T$1)return;const e=this._$AH,n=t===w$1&&e!==w$1||t.capture!==e.capture||t.once!==e.once||t.passive!==e.passive,o=t!==w$1&&(e===w$1||n);n&&this.element.removeEventListener(this.name,this,e),o&&this.element.addEventListener(this.name,this,t),this._$AH=t;}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t);}};let H$1 = class H{constructor(t,i,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=i,this.options=s;}get _$AU(){return this._$AM._$AU}_$AI(t){V$1(this,t);}};const Z$1=t$2.litHtmlPolyfillSupport;Z$1?.(P$1,N$1),(t$2.litHtmlVersions??=[]).push("3.0.0-pre.0");const j$1=(t,s,e)=>{const n=e?.renderBefore??s;let o=n._$litPart$;if(void 0===o){const t=e?.renderBefore??null;n._$litPart$=o=new N$1(s.insertBefore(l$1(),t),t,void 0,e??{});}return o._$AI(t),o};

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let s$1 = class s extends l$2{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0;}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const r=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=j$1(r,this.renderRoot,this.renderOptions);}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0);}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1);}render(){return T$1}};s$1.finalized=!0,s$1._$litElement$=!0,globalThis.litElementHydrateSupport?.({LitElement:s$1});const i$2=globalThis.litElementPolyfillSupport;i$2?.({LitElement:s$1});(globalThis.litElementVersions??=[]).push("4.0.0-pre.0");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$1={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},e$2=t=>(...e)=>({_$litDirective$:t,values:e});let i$1 = class i{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i;}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};

const t=2147483647,n=36,o$1=/[^\0-\x7F]/,r=/[\x2E\u3002\uFF0E\uFF61]/g,e$1={overflow:"Overflow: input needs wider integers to process","not-basic":"Illegal input >= 0x80 (not a basic code point)","invalid-input":"Invalid input"},i=Math.floor,s=String.fromCharCode;function l(t){throw new RangeError(e$1[t])}function a(t){const n=[];let o=0;const r=t.length;for(;o<r;){const e=t.charCodeAt(o++);if(e>=55296&&e<=56319&&o<r){const r=t.charCodeAt(o++);56320==(64512&r)?n.push(((1023&e)<<10)+(1023&r)+65536):(n.push(e),o--);}else n.push(e);}return n}const c=t=>String.fromCodePoint(...t),f=function(t,n){return t+22+75*(t<26)-((0!=n)<<5)},u=function(t,o,r){let e=0;for(t=r?i(t/700):t>>1,t+=i(t/o);t>455;e+=n)t=i(t/35);return i(e+36*t/(t+38))},h=function(o){const r=[],e=o.length;let s=0,a=128,c=72,f=o.lastIndexOf("-");f<0&&(f=0);for(let t=0;t<f;++t)o.charCodeAt(t)>=128&&l("not-basic"),r.push(o.charCodeAt(t));for(let d=f>0?f+1:0;d<e;){const f=s;for(let r=1,a=n;;a+=n){d>=e&&l("invalid-input");const f=(h=o.charCodeAt(d++))>=48&&h<58?h-48+26:h>=65&&h<91?h-65:h>=97&&h<123?h-97:n;f>=n&&l("invalid-input"),f>i((t-s)/r)&&l("overflow"),s+=f*r;const u=a<=c?1:a>=c+26?26:a-c;if(f<u)break;const m=n-u;r>i(t/m)&&l("overflow"),r*=m;}const m=r.length+1;c=u(s-f,m,0==f),i(s/m)>t-a&&l("overflow"),a+=i(s/m),s%=m,r.splice(s++,0,a);}var h;return String.fromCodePoint(...r)},d=function(e){return function(t,n){const o=t.split("@");let e="";o.length>1&&(e=o[0]+"@",t=o[1]);const i=function(t,n){const o=[];let r=t.length;for(;r--;)o[r]=n(t[r]);return o}((t=t.replace(r,".")).split("."),n).join(".");return e+i}(e,(function(r){return o$1.test(r)?"xn--"+function(o){const r=[],e=(o=a(o)).length;let c=128,h=0,d=72;for(const t of o)t<128&&r.push(s(t));const m=r.length;let p=m;for(m&&r.push("-");p<e;){let e=t;for(const t of o)t>=c&&t<e&&(e=t);const a=p+1;e-c>i((t-h)/a)&&l("overflow"),h+=(e-c)*a,c=e;for(const e of o)if(e<c&&++h>t&&l("overflow"),e===c){let t=h;for(let o=n;;o+=n){const e=o<=d?1:o>=d+26?26:o-d;if(t<e)break;const l=t-e,a=n-e;r.push(s(f(e+l%a,0))),t=i(l/a);}r.push(s(f(t,0))),d=u(h,a,p===m),h=0,++p;}++h,++c;}return r.join("")}(r):r}))};let m=(t,n)=>Array(n).fill(t),p=t=>new Uint32Array(t),g=6291456,w=23068672,v=14680064,C=2097409,k=2097889,b=2097249,I=2097825,A=2097217,x=2097505,S=2097697,y=2097857,E=2106753,D=2097153,j=2097281,F=2097441,N=2097537,P=2097729,z=2097761,q=2097793,L=2097921,W=2097953,O=2097377,U=2097473,$$1=2097601,M=2097665,R=18874368,_=2097185,B=2097313,G=2097345,H=2097569,J=2097633,K=2107105,Q=2106945,T=2106977,V=2107009,X=2106657,Y=2106785,Z=10486593,tt=2106593,nt=2106561,ot=2107137,rt=2107073,et=2107201;const it=[p([v,v,v,v,v,v,v,v,v,v,v,v,v,v,v,v]),p([v,v,v,v,v,v,v,v,v,v,v,v,v,g,g,v]),p([g,g,g,g,g,g,g,g,g,g,v,v,v,v,v,v]),p([v,D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1]),p([J,M,S,P,z,q,I,y,k,L,W,v,v,v,v,v]),p([v,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,v,v,v,v,v]),p([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([Z,g,g,g,g,g,g,g,10486626,g,D,g,g,2097152,g,10486690]),p([g,g,2098145,2098177,10486818,2098273,g,g,10486914,2098369,$$1,g,2098403,2098499,2098595,g]),p([2098689,2098721,2098753,2098785,2098817,2098849,2098881,2098913,2098945,2098977,2099009,2099041,2099073,2099105,2099137,2099169]),p([2099201,2099233,2099265,2099297,2099329,2099361,2099393,g,2099425,2099457,2099489,2099521,2099553,2099585,2099617,4196802]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([2099713,g,2099745,g,2099777,g,2099809,g,2099841,g,2099873,g,2099905,g,2099937,g]),p([2099969,g,2100001,g,2100033,g,2100065,g,2100097,g,2100129,g,2100161,g,2100193,g]),p([2100225,g,2100257,g,2100289,g,2100321,g,2100353,g,2100385,g,2100417,g,2100449,g]),p([2100482,g,2097410,2097410,2100545,g,2100577,g,g,2100609,g,2100641,g,2100673,g,2100706]),p([2100706,2100769,g,2100801,g,2100833,g,2100865,g,2100898,2100961,g,2100993,g,2101025,g]),p([2101057,g,2101089,g,2101121,g,2101153,g,2101185,g,2101217,g,2101249,g,2101281,g]),p([2101313,g,2101345,g,2101377,g,2101409,g,2101441,g,2101473,g,2101505,g,2101537,g]),p([2101569,g,2101601,g,2101633,g,2101665,g,2101697,2101729,g,2101761,g,2101793,g,P]),p([g,2101825,2101857,g,2101889,g,2101921,2101953,g,2101985,2102017,2102049,g,g,2102081,2102113]),p([2102145,2102177,g,2102209,2102241,g,2102273,2102305,2102337,g,g,g,2102369,2102401,g,2102433]),p([2102465,g,2102497,g,2102529,g,2102561,2102593,g,2102625,g,g,2102657,g,2102689,2102721]),p([g,2102753,2102785,2102817,g,2102849,g,2102881,2102913,g,g,g,2102945,g,g,g]),p([g,g,g,g,2102978,2102978,2102978,2103042,2103042,2103042,2103106,2103106,2103106,2103169,g,2103201]),p([g,2103233,g,2103265,g,2103297,g,2103329,g,2103361,g,2103393,g,g,2103425,g]),p([2103457,g,2103489,g,2103521,g,2103553,g,2103585,g,2103617,g,2103649,g,2103681,g]),p([g,2103714,2103714,2103714,2103777,g,2103809,2103841,2103873,g,2103905,g,2103937,g,2103969,g]),p([2104001,g,2104033,g,2104065,g,2104097,g,2104129,g,2104161,g,2104193,g,2104225,g]),p([2104257,g,2104289,g,2104321,g,2104353,g,2104385,g,2104417,g,2104449,g,2104481,g]),p([2104513,g,2104545,g,2104577,g,2104609,g,2104641,g,2104673,g,2104705,g,2104737,g]),p([2104769,g,2104801,g,g,g,g,g,g,g,2104833,2104865,g,2104897,2104929,g]),p([g,2104961,g,2104993,2105025,2105057,2105089,g,2105121,g,2105153,g,2105185,g,2105217,g]),p([O,2105249,F,S,2105281,2105313,2105345,y,L,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,10493986,10494050,10494114,10494178,10494242,10494306,g,g]),p([2102241,x,P,k,2105761,g,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([18883009,18875457,w,18883041,18883074,18883137,w,w,w,w,w,w,w,w,w,R]),p([2105953,g,2105985,g,2106017,g,2106049,g,0,0,10494690,g,g,g,10494753,2106177]),p([0,0,0,0,10486818,10494819,2106305,2100737,2106337,2106369,2106401,0,2106433,0,2106465,2106497]),p([g,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913]),p([Q,T,0,V,2107041,rt,K,ot,2107169,et,2107233,2107265,g,g,g,g]),p([g,g,4204161,g,g,g,g,g,g,g,g,g,g,g,g,2107297]),p([nt,E,rt,2106465,2107265,K,Q,g,2107329,g,2107361,g,2107393,g,2107425,g]),p([2107457,g,2107489,g,2107521,g,2107553,g,2107585,g,2107617,g,2107649,g,2107681,g]),p([Y,T,V,g,E,X,g,2107713,g,V,2107745,g,g,2107777,2107809,2107841]),p([2107873,2107905,2107937,2107969,2108001,2108033,2108065,2108097,2108129,2108161,2108193,2108225,2108257,2108289,2108321,2108353]),p([2108385,2108417,2108449,2108481,2108513,2108545,2108577,2108609,2108641,2108673,2108705,2108737,2108769,2108801,2108833,2108865]),p([2108897,2108929,2108961,2108993,2109025,2109057,2109089,2109121,2109153,2109185,2109217,2109249,2109281,2109313,2109345,2109377]),p([2109409,g,2109441,g,2109473,g,2109505,g,2109537,g,2109569,g,2109601,g,2109633,g]),p([2109665,g,2109697,g,2109729,g,2109761,g,2109793,g,2109825,g,2109857,g,2109889,g]),p([2109921,g,g,w,w,w,w,w,w,w,2109953,g,2109985,g,2110017,g]),p([2110049,g,2110081,g,2110113,g,2110145,g,2110177,g,2110209,g,2110241,g,2110273,g]),p([2110305,g,2110337,g,2110369,g,2110401,g,2110433,g,2110465,g,2110497,g,2110529,g]),p([2110561,g,2110593,g,2110625,g,2110657,g,2110689,g,2110721,g,2110753,g,2110785,g]),p([0,2110817,g,2110849,g,2110881,g,2110913,g,2110945,g,2110977,g,2111009,g,g]),p([2111041,g,2111073,g,2111105,g,2111137,g,2111169,g,2111201,g,2111233,g,2111265,g]),p([2111297,g,2111329,g,2111361,g,2111393,g,2111425,g,2111457,g,2111489,g,2111521,g]),p([2111553,g,2111585,g,2111617,g,2111649,g,2111681,g,2111713,g,2111745,g,2111777,g]),p([2111809,g,2111841,g,2111873,g,2111905,g,2111937,g,2111969,g,2112001,g,2112033,g]),p([2112065,g,2112097,g,2112129,g,2112161,g,2112193,g,2112225,g,2112257,g,2112289,g]),p([2112321,g,2112353,g,2112385,g,2112417,g,2112449,g,2112481,g,2112513,g,2112545,g]),p([0,2112577,2112609,2112641,2112673,2112705,2112737,2112769,2112801,2112833,2112865,2112897,2112929,2112961,2112993,2113025]),p([2113057,2113089,2113121,2113153,2113185,2113217,2113249,2113281,2113313,2113345,2113377,2113409,2113441,2113473,2113505,2113537]),p([2113569,2113601,2113633,2113665,2113697,2113729,2113761,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,2113794,g,g,g,0,0,g,g,g]),p([0,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,g,w]),p([g,w,w,g,w,w,g,w,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,0,g]),p([g,g,g,g,g,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,g,0,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,w,w,w,w,w]),p([w,g,g,g,g,2113858,2113922,2113986,2114050,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,w,w,w,w,w,w,w,0,g,w]),p([w,w,w,w,w,g,g,w,w,g,w,w,w,w,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,0,0]),p([g,w,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,0,0,g,g,g]),p([g,g,g,g,g,g,w,w,w,w,w,w,w,w,w,w]),p([w,g,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,g,g,g,g,g,g,g,0,0,w,g,g]),p([g,g,g,g,g,g,w,w,w,w,g,w,w,w,w,w]),p([w,w,w,w,g,w,w,w,g,w,w,w,w,w,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,0]),p([g,g,g,g,g,g,g,g,g,w,w,w,0,0,g,0]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,w,w,w,w,w,w,w,w]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,w,w,w]),p([w,w,0,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,g,w,w]),p([g,w,w,w,w,w,w,w,2114114,2114178,2114242,2114306,2114370,2114434,2114498,2114562]),p([g,g,w,w,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,0,g,g,g,g,g,g,g,g,0,0,g]),p([g,0,0,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,0,g,g,g,g,g,g]),p([g,0,g,0,0,0,g,g,g,g,0,0,w,g,w,w]),p([w,w,w,w,w,0,0,w,w,0,0,w,w,w,g,0]),p([0,0,0,0,0,0,0,w,0,0,0,0,2114626,2114690,0,2114754]),p([g,g,w,w,0,0,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,w,0]),p([0,w,w,w,0,g,g,g,g,g,g,0,0,0,0,g]),p([g,0,g,2114818,0,g,2114882,0,g,g,0,0,w,0,w,w]),p([w,w,w,0,0,0,0,w,w,0,0,w,w,w,0,0]),p([0,w,0,0,0,0,0,0,0,2114946,2115010,2115074,g,0,2115138,0]),p([w,w,g,g,g,w,g,0,0,0,0,0,0,0,0,0]),p([0,w,w,w,0,g,g,g,g,g,g,g,g,g,0,g]),p([g,g,0,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,0,g,g,0,g,g,g,g,g,0,0,w,g,w,w]),p([w,w,w,w,w,w,0,w,w,w,0,w,w,w,0,0]),p([g,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,0,0,0,0,0,0,0,g,w,w,w,w,w,w]),p([0,w,w,w,0,g,g,g,g,g,g,g,g,0,0,g]),p([w,w,w,w,w,0,0,w,w,0,0,w,w,w,0,0]),p([0,0,0,0,0,w,w,w,0,0,0,0,2115202,2115266,0,g]),p([g,g,g,g,g,g,g,g,0,0,0,0,0,0,0,0]),p([0,0,w,g,0,g,g,g,g,g,g,0,0,0,g,g]),p([g,0,g,g,g,g,0,0,0,g,g,0,g,0,g,g]),p([0,0,0,g,g,0,0,0,g,g,g,0,0,0,g,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,w,w]),p([w,w,w,0,0,0,w,w,w,0,w,w,w,w,0,0]),p([g,0,0,0,0,0,0,w,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,g,g,g,g,g,g,g,g,0,g,g]),p([g,0,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,w,g,w,w]),p([w,w,w,w,w,0,w,w,w,0,w,w,w,w,0,0]),p([0,0,0,0,0,w,w,0,g,g,g,0,0,g,0,0]),p([0,0,0,0,0,0,0,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,g,g,g,g,g,g,g,g,g,0,g,g]),p([g,g,g,g,0,g,g,g,g,g,0,0,w,g,w,w]),p([0,0,0,0,0,w,w,0,0,0,0,0,0,g,g,0]),p([0,g,g,w,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,0,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,w,w,g,w,w]),p([w,w,w,w,w,0,w,w,w,0,w,w,w,w,g,g]),p([0,0,0,0,g,g,g,w,g,g,g,g,g,g,g,g]),p([0,w,w,w,0,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,0,0,g,g,g,g,g,g]),p([g,g,0,g,g,g,g,g,g,g,g,g,0,g,0,0]),p([g,g,g,g,g,g,g,0,0,0,w,0,0,0,0,w]),p([w,w,w,w,w,0,w,0,w,w,w,w,w,w,w,w]),p([0,0,w,w,g,0,0,0,0,0,0,0,0,0,0,0]),p([0,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,g,2115330,w,w,w,w,w,w,w,0,0,0,0,g]),p([g,g,g,g,g,g,g,w,w,w,w,w,w,w,w,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,0,0,0]),p([0,g,g,0,g,0,g,g,g,g,g,0,g,g,g,g]),p([g,g,g,g,0,g,0,g,g,g,g,g,g,g,g,g]),p([g,w,g,2115394,w,w,w,w,w,w,w,w,w,g,0,0]),p([g,g,g,g,g,0,g,0,w,w,w,w,w,w,w,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,2115458,2115522,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,2115585,g,g,g]),p([g,g,g,g,g,g,g,g,w,w,g,g,g,g,g,g]),p([g,g,g,g,g,w,g,w,g,w,g,g,g,g,w,w]),p([g,g,g,2115618,g,g,g,g,0,g,g,g,g,2115682,g,g]),p([g,g,2115746,g,g,g,g,2115810,g,g,g,g,2115874,g,g,g]),p([g,g,g,g,g,g,g,g,g,2115938,g,g,g,0,0,0]),p([0,w,w,18893218,w,18893282,18893346,18893411,18893506,18893571,w,w,w,w,w,w]),p([w,18893442,w,w,w,g,w,w,g,g,g,g,g,w,w,w]),p([w,w,w,18893666,w,w,w,w,0,w,w,w,w,18893730,w,w]),p([w,w,18893794,w,w,w,w,18893858,w,w,w,w,18893922,w,w,w]),p([w,w,w,w,w,w,w,w,w,18893986,w,w,w,0,g,g]),p([g,g,g,g,g,g,w,g,g,g,g,g,g,0,g,g]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,g]),p([g,g,g,g,g,g,w,w,w,w,g,g,g,g,w,w]),p([w,g,w,w,w,g,g,w,w,w,w,w,w,w,g,g]),p([g,w,w,w,w,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,w,w,w,w,w,w,w,w,w,w,w,w,g,w]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,w,g,g]),p([0,0,0,0,0,0,0,2116833,0,0,0,0,0,2116865,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,2116897,g,g,g]),p([g,g,g,g,g,g,g,g,g,0,g,g,g,g,0,0]),p([g,g,g,g,g,g,g,0,g,0,g,g,g,g,0,0]),p([g,0,g,g,g,g,0,0,g,g,g,g,g,g,g,0]),p([g,0,g,g,g,g,0,0,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,w,w,w]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,2116929,2116961,2116993,2117025,2117057,2117089,0,0]),p([g,g,g,g,g,g,g,g,g,0,0,0,0,0,0,0]),p([g,g,w,w,w,w,0,0,0,0,0,0,0,0,0,g]),p([g,g,w,w,w,g,g,0,0,0,0,0,0,0,0,0]),p([g,g,w,w,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,0,g,g]),p([g,0,w,w,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,16777216,16777216,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,w,0,0]),p([g,g,g,g,g,g,0,g,g,g,g,R,R,R,0,R]),p([g,g,g,g,g,w,w,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,w,g,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,w,w,w,0,0,0,0]),p([g,0,0,0,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,g,g]),p([g,g,g,g,g,g,g,w,w,w,w,w,0,0,g,g]),p([g,g,g,g,g,w,w,w,w,w,w,w,w,w,w,0]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,0,0,w]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,0]),p([w,w,w,w,w,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,g,g,g,g,g,g,g,g,0,0,0]),p([w,w,w,w,g,g,g,g,g,g,g,g,g,g,g,0]),p([w,w,w,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,w,w,w,w,w,w,w,w,w,w,g,g]),p([w,w,w,w,0,0,0,0,0,0,0,0,g,g,g,g]),p([w,w,w,w,w,w,w,w,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,g,g,g]),p([2108449,2108513,2108833,2108929,2108961,2108961,2109217,2109441,2117121,0,0,0,0,0,0,0]),p([2117153,2117185,2117217,2117249,2117281,2117313,2117345,2117377,2117409,2117441,2117473,2117505,2116897,2117537,2117569,2117601]),p([2117633,2117665,2117697,2117729,2117761,2117793,2117825,2117857,2117889,2117921,2117953,2117985,2118017,2118049,2118081,2118113]),p([2118145,2118177,2118209,2118241,2118273,2118305,2118337,2118369,2118401,2118433,2118465,0,0,2118497,2118529,2118561]),p([w,w,w,g,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,w,g,g,g,g,w,g,g]),p([g,g,g,g,w,g,g,w,w,w,g,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,D,2098881,_,g]),p([b,j,2102081,G,O,C,F,U,x,N,H,g,$$1,2104545,J,S]),p([z,q,y,D,2118593,2118625,2118657,_,b,j,2102113,2102145,2118689,G,g,U]),p([N,2100961,$$1,2101921,2118721,2118753,J,z,q,2118785,2102369,I,2118817,nt,tt,2106625]),p([K,ot,C,S,q,I,nt,tt,T,K,ot,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,2108801,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,2118849,A,2118881,2099201,2118689]),p([B,2118913,2118945,2118977,2102305,2102273,2119009,2119041,2119073,2119105,2119137,2119169,2119201,2119233,2102401,2119265]),p([2119297,2102433,2119329,2119361,2102625,2119393,2105025,2102753,2119425,2102785,2105057,W,2119457,2119489,2102881,E]),p([2119521,g,2119553,g,2119585,g,2119617,g,2119649,g,2119681,g,2119713,g,2119745,g]),p([2119777,g,2119809,g,2119841,g,2119873,g,2119905,g,2119937,g,2119969,g,2120001,g]),p([2120033,g,2120065,g,2120097,g,2120129,g,2120161,g,2120193,g,2120225,g,2120257,g]),p([2120289,g,2120321,g,2120353,g,2120385,g,2120417,g,2120449,g,2120481,g,2120513,g]),p([2120545,g,2120577,g,2120609,g,2120641,g,2120673,g,2120705,g,2120737,g,2120769,g]),p([2120801,g,2120833,g,2120865,g,2120897,g,2120929,g,2120961,g,2120993,g,2121025,g]),p([2121057,g,2121089,g,2121121,g,2121153,g,2121185,g,2121217,g,2121249,g,2121281,g]),p([2121313,g,2121345,g,2121377,g,2121409,g,2121441,g,2121473,g,2121505,g,2121537,g]),p([2121569,g,2121601,g,2121633,g,2121665,g,2121697,g,2121729,g,2121761,g,2121793,g]),p([2121825,g,2121857,g,2121889,g,g,g,g,g,2121922,2121057,g,g,2099650,g]),p([2121985,g,2122017,g,2122049,g,2122081,g,2122113,g,2122145,g,2122177,g,2122209,g]),p([2122241,g,2122273,g,2122305,g,2122337,g,2122369,g,2122401,g,2122433,g,2122465,g]),p([2122497,g,2122529,g,2122561,g,2122593,g,2122625,g,2122657,g,2122689,g,2122721,g]),p([2122753,g,2122785,g,2122817,g,2122849,g,2122881,g,2122913,g,2122945,g,2122977,g]),p([2123009,g,2123041,g,2123073,g,2123105,g,2123137,g,2123169,g,2123201,g,2123233,g]),p([2123265,g,2123297,g,2123329,g,2123361,g,2123393,g,2123425,g,2123457,g,2123489,g]),p([g,g,g,g,g,g,g,g,2123521,2123553,2123585,2123617,2123649,2123681,2123713,2123745]),p([g,g,g,g,g,g,0,0,2123777,2123809,2123841,2123873,2123905,2123937,0,0]),p([g,g,g,g,g,g,g,g,2123969,2124001,2124033,2124065,2124097,2124129,2124161,2124193]),p([g,g,g,g,g,g,g,g,2124225,2124257,2124289,2124321,2124353,2124385,2124417,2124449]),p([g,g,g,g,g,g,0,0,2124481,2124513,2124545,2124577,2124609,2124641,0,0]),p([g,g,g,g,g,g,g,g,0,2124673,0,2124705,0,2124737,0,2124769]),p([g,g,g,g,g,g,g,g,2124801,2124833,2124865,2124897,2124929,2124961,2124993,2125025]),p([g,2106305,g,2106337,g,2106369,g,2106401,g,2106433,g,2106465,g,2106497,0,0]),p([2125058,2125122,2125186,2125250,2125314,2125378,2125442,2125506,2125058,2125122,2125186,2125250,2125314,2125378,2125442,2125506]),p([2125570,2125634,2125698,2125762,2125826,2125890,2125954,2126018,2125570,2125634,2125698,2125762,2125826,2125890,2125954,2126018]),p([2126082,2126146,2126210,2126274,2126338,2126402,2126466,2126530,2126082,2126146,2126210,2126274,2126338,2126402,2126466,2126530]),p([g,g,2126594,2126658,2126722,0,g,2126786,2126849,2126881,2126593,2106305,2126658,10515522,2105921,10515522]),p([10515586,10515651,2127138,2127202,2127266,0,g,2127330,2127393,2106337,2127137,2106369,2127202,10516035,10516131,10516227]),p([g,g,g,2127713,0,0,g,g,2127745,2127777,2127809,2106401,0,10516451,10516547,10516643]),p([g,g,g,2128129,g,g,g,g,2128161,2128193,2128225,2106465,2128257,10516899,10494819,10516993]),p([0,0,2128418,2128482,2128546,0,g,2128610,2128673,2106433,2128417,2106497,2128482,10486818,10516450,0]),p([Z,Z,Z,Z,Z,Z,Z,Z,Z,Z,Z,2097152,4194304,4194304,0,0]),p([g,2128705,g,g,g,g,g,10517346,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,g,0,0,0,0,0,0,0,Z]),p([g,g,g,2128802,2128867,g,2128962,2129027,g,g,g,g,10517730,g,10517794,g]),p([g,g,g,g,g,g,g,10517858,10517922,10517986,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,2128804,g,g,g,g,g,g,g,Z]),p([2097152,0,0,0,2097152,0,0,0,0,0,0,0,0,0,0,0]),p([2129441,C,0,0,2098465,2129473,2129505,2129537,2129569,2129601,10518241,2129665,10518305,10518337,10518369,H]),p([2129441,2098369,2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601,10518241,2129665,10518305,10518337,10518369,0]),p([D,j,$$1,k,2102113,O,U,x,N,H,J,P,z,0,0,0]),p([g,g,g,g,g,g,g,g,2097698,g,g,g,g,g,g,g]),p([w,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([10518403,10518499,A,2129986,g,10518659,10518755,2102145,g,2130242,G,O,O,O,O,2100321]),p([C,C,x,x,g,H,2097570,g,g,J,M,S,S,S,g,g]),p([2130306,2130371,2130466,g,W,g,et,g,W,g,U,2098849,_,A,g,j]),p([j,B,0,N,$$1,2130529,2130561,2130593,2130625,C,g,2130659,Q,tt,tt,Q]),p([2130753,g,g,g,g,b,b,j,C,F,g,g,g,g,g,g]),p([2130787,2130883,2130980,2131107,2131203,2131299,2131395,2131491,2131587,2131683,2131779,2131875,2131971,2132067,2132163,2098402]),p([C,2132258,2132323,2132418,I,2132482,2132547,2132644,2132770,k,2132834,2132899,x,A,b,N]),p([C,2132258,2132259,2132418,I,2132482,2132547,2132644,2132770,k,2132834,2132899,x,A,b,N]),p([g,g,g,0,g,g,g,g,g,2132995,g,g,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,2133090,2133155,g,2133250]),p([2133315,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([v,g,g,g,g,g,g,g,g,g,g,g,g,g,v,v]),p([g,g,g,g,g,g,g,g,g,2133409,2133441,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,0,0,0,0,0,0,0,0]),p([2098369,2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601,2131042,2098370,2133474,2133538,2133602,2133666,2133730]),p([2133794,2133858,2133922,2133986,10522659,10522755,10522851,10522947,10523043,10523139,10523235,10523331,10523427,10523524,10523652,10523780]),p([10523908,10524036,10524164,10524292,10524420,10524548,10524676,10524804,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,0,10524931,10525027,10525123,10525219]),p([10525315,10525411,10525507,10525603,10525699,10525795,10525891,10525987,10526083,10526179,10526275,10526371,10526467,10526563,10526659,10526755]),p([10526851,10526947,10527043,10527139,10527235,10527331,D,_,A,b,j,B,G,O,C,F]),p([U,x,N,H,$$1,J,M,S,P,z,q,I,y,k,L,W]),p([D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1,J]),p([M,S,P,z,q,I,y,k,L,W,2129441,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,2133092,g,g,g]),p([g,g,g,g,10527427,10527522,10527491,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,2138978,g,g,g]),p([g,g,g,g,0,0,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,g,g,g,g,g,g,g,g,g]),p([2139041,2139073,2139105,2139137,2139169,2139201,2139233,2139265,2139297,2139329,2139361,2139393,2139425,2139457,2139489,2139521]),p([2139553,2139585,2139617,2139649,2139681,2139713,2139745,2139777,2139809,2139841,2139873,2139905,2139937,2139969,2140001,2140033]),p([2140065,2140097,2140129,2140161,2140193,2140225,2140257,2140289,2140321,2140353,2140385,2140417,2140449,2140481,2140513,2140545]),p([2140577,g,2140609,2140641,2140673,g,g,2140705,g,2140737,g,2140769,g,2118625,2119201,2118593]),p([2118849,g,2140801,g,g,2140833,g,g,g,g,g,g,F,I,2140865,2140897]),p([2140929,g,2140961,g,2140993,g,2141025,g,2141057,g,2141089,g,2141121,g,2141153,g]),p([2141185,g,2141217,g,2141249,g,2141281,g,2141313,g,2141345,g,2141377,g,2141409,g]),p([2141441,g,2141473,g,2141505,g,2141537,g,2141569,g,2141601,g,2141633,g,2141665,g]),p([2141697,g,2141729,g,2141761,g,2141793,g,2141825,g,2141857,g,2141889,g,2141921,g]),p([2141953,g,2141985,g,2142017,g,2142049,g,2142081,g,2142113,g,2142145,g,2142177,g]),p([2142209,g,2142241,g,2142273,g,2142305,g,2142337,g,2142369,g,2142401,g,2142433,g]),p([2142465,g,2142497,g,g,g,g,g,g,g,g,2142529,g,2142561,g,w]),p([w,w,2142593,g,0,0,0,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,g,0,0,0,0,0,g,0,0]),p([g,g,g,g,g,g,g,g,0,0,0,0,0,0,0,2142625]),p([g,0,0,0,0,0,0,0,0,0,0,0,0,0,0,w]),p([g,g,g,g,g,g,g,0,g,g,g,g,g,g,g,0]),p([g,g,g,g,g,g,g,g,g,g,0,g,g,g,g,2142657]),p([g,g,g,2142689,0,0,0,0,0,0,0,0,0,0,0,0]),p([2142721,2142753,2142785,2142817,2142849,2142881,2142913,2142945,2142977,2143009,2143041,2143073,2143105,2143137,2143169,2143201]),p([2143233,2143265,2143297,2143329,2143361,2143393,2143425,2143457,2143489,2143521,2143553,2143585,2143617,2143649,2143681,2143713]),p([2143745,2143777,2143809,2143841,2143873,2143905,2143937,2143969,2144001,2144033,2144065,2144097,2144129,2144161,2144193,2144225]),p([2144257,2144289,2144321,2144353,2144385,2144417,2144449,2144481,2144513,2144545,2144577,2144609,2144641,2144673,2144705,2144737]),p([2144769,2144801,2144833,2144865,2144897,2144929,2144961,2144993,2145025,2145057,2145089,2145121,2145153,2145185,2145217,2145249]),p([2145281,2145313,2145345,2145377,2145409,2145441,2145473,2145505,2145537,2145569,2145601,2145633,2145665,2145697,2145729,2145761]),p([2145793,2145825,2145857,2145889,2145921,2145953,2145985,2146017,2146049,2146081,2146113,2146145,2146177,2146209,2146241,2146273]),p([2146305,2146337,2146369,2146401,2146433,2146465,2146497,2146529,2146561,2146593,2146625,2146657,2146689,2146721,2146753,2146785]),p([2146817,2146849,2146881,2146913,2146945,2146977,2147009,2147041,2147073,2147105,2147137,2147169,2147201,2147233,2147265,2147297]),p([2147329,2147361,2147393,2147425,2147457,2147489,2147521,2147553,2147585,2147617,2147649,2147681,2147713,2147745,2147777,2147809]),p([2147841,2147873,2147905,2147937,2147969,2148001,2148033,2148065,2148097,2148129,2148161,2148193,2148225,2148257,2148289,2148321]),p([2148353,2148385,2148417,2148449,2148481,2148513,2148545,2148577,2148609,2148641,2148673,2148705,2148737,2148769,2148801,2148833]),p([2148865,2148897,2148929,2148961,2148993,2149025,2149057,2149089,2149121,2149153,2149185,2149217,2149249,2149281,2149313,2149345]),p([2149377,2149409,2149441,2149473,2149505,2149537,0,0,0,0,0,0,0,0,0,0]),p([Z,g,2149569,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,2149601,g,2143457,2149633,2149665,g,g,g,g,g]),p([g,g,g,g,g,g,g,0,0,w,w,10538306,10538370,g,g,2149826]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,2149890]),p([0,0,0,0,0,g,g,g,g,g,g,g,g,g,g,g]),p([0,2149953,2149985,2150017,2150049,2150081,2150113,2150145,2150177,2150209,2150241,2150273,2150305,2150337,2150369,2150401]),p([2150433,2150465,2150497,2150529,2150561,2150593,2150625,2150657,2150689,2150721,2150753,2150785,2150817,2150849,2150881,2150913]),p([2150945,2150977,2151009,2151041,2151073,2151105,2151137,2151169,2151201,2151233,2151265,2151297,2151329,2151361,2151393,2151425]),p([2151457,2151489,2151521,2151553,0,2151585,2151617,2151649,2151681,2151713,2151745,2151777,2151809,2151841,2151873,2151905]),p([2151937,2151969,2152001,2152033,2152065,2152097,2152129,2152161,2152193,2152225,2152257,2152289,2152321,2152353,2152385,2152417]),p([2152449,2152481,2152513,2152545,2152577,2152609,2152641,2152673,2152705,2152737,2152769,2152801,2152833,2152865,2152897,0]),p([g,g,2142721,2142913,2152929,2152961,2152993,2153025,2153057,2153089,2142849,2153121,2153153,2153185,2153217,2142977]),p([g,g,g,g,0,0,0,0,0,0,0,0,0,0,0,0]),p([10541859,10541955,10542051,10542147,10542243,10542339,10542435,10542531,10542627,10542723,10542819,10542915,10543011,10543107,10543203,10543299]),p([10543395,10543491,10543587,10543683,10543779,10543875,10543971,10544067,10544163,10544259,10544355,10544451,10544547,10544644,10544772,0]),p([10544899,10544995,10545091,10545187,10545283,10545379,10545475,10545571,10545667,10545763,10545859,10545955,10546051,10546147,10546243,10546339]),p([10546435,10546531,10546627,10546723,10546819,10546915,10547011,10547107,10547203,10547299,10547395,10547491,10547587,10547683,10547779,10547875]),p([10547971,10548067,10548163,10548259,2159745,2159777,2144833,2159809,g,g,g,g,g,g,g,g]),p([2159843,2133506,2159938,2098146,2160002,2160066,2160130,2160194,2160258,2160322,2160386,2131266,2131170,2160450,2160514,2160578]),p([2149953,2150049,2150145,2150209,2150465,2150497,2150593,2150657,2150689,2150753,2150785,2150817,2150849,2150881,2154625,2154721]),p([2154817,2154913,2155009,2155105,2155201,2155297,2155393,2155489,2155585,2155681,2155777,2155873,2160642,2160706,2160769,g]),p([2142721,2142913,2152929,2152961,2156705,2156801,2156897,2143073,2157089,2143457,2145057,2145441,2145409,2145089,2148033,2143713]),p([2144993,2157953,2158049,2158145,2158241,2158337,2158433,2158529,2158625,2160801,2160833,2143905,2160865,2160897,2160929,2160961]),p([2160993,2159489,2161025,2161057,2152993,2153025,2153057,2161089,2161121,2161153,2161185,2158913,2159009,2159105,2159201,2159297]),p([2161217,2161250,2161314,2161378,2161442,2161506,2098466,2160034,2160546,2161570,2161634,2161698,2161762,2161826,2161890,2161954]),p([2162018,2162082,2162146,2162210,2162274,2162338,2162402,2162466,2162530,2162595,2162691,2162787,2162882,2162947,2163042,2163107]),p([2163201,2163233,2163265,2163297,2163329,2163361,2163393,2163425,2163457,2149889,2163489,2163521,2163553,2163585,2163617,2163649]),p([2163681,2163713,2163745,2149921,2163777,2163809,2163841,2163873,2163905,2163937,2163969,2164001,2164033,2164065,2164097,2164129]),p([2164161,2164193,2164225,2164257,2164289,2164321,2164353,2164385,2164417,2164449,2164481,2164513,2164545,2164577,2164609,2164642]),p([2164708,2164836,2164964,2165091,2165188,2165315,2165411,2165509,2165668,2165795,2165891,2165987,2166084,2166212,2166339,2166435]),p([2166530,2166595,2166692,2166820,2166946,2167013,2167174,2167365,2167075,2167525,2167685,2167844,2167971,2168067,2168163,2168260]),p([2168389,2168548,2168675,2168771,2168867,2168962,2169026,2167618,2169090,2169155,2169251,2169349,2169507,2169604,2169733,2169891]),p([2169986,2170050,2170117,2170276,2170405,2170563,2170661,2170818,2170883,2170979,2171075,2171171,2171267,2171364,2171491,2171586]),p([2171651,2171747,2171843,2171940,2172067,2172163,2172259,2172357,2172516,2172642,2172709,2172866,2172932,2167236,2173059,2173155]),p([2173251,2173348,2173474,2173539,2173636,2173762,2173829,2167427,2173986,2174050,2174114,2174178,2174242,2174306,2174370,2174434]),p([2174498,2174562,2174627,2174723,2174819,2174915,2175011,2175107,2175203,2175299,2175395,2175491,2175587,2175683,2175779,2175875]),p([2175971,2176067,2176162,2176226,2176291,2176386,2176450,2176514,2176579,2176675,2176770,2176834,2176898,2176962,2177026,2177092]),p([2176098,2177218,2177282,2177346,2177410,2177474,2177538,2177602,2177667,2177764,2177890,2177954,2178018,2178082,2178146,2178210]),p([2178274,2178339,2178435,2178243,2178531,2178626,2178690,2178754,2097474,2178818,2178882,2178946,2179010,2179074,2179138,2179203]),p([2179299,2176610,2179395,2179491,2179587,2176706,2179683,2179779,2179876,2176098,2180003,2180099,2180195,2180291,2180389,2180550]),p([2180738,2180802,2180866,2180930,2180994,2181058,2181122,2181186,2181250,2181186,2181314,2181378,2181442,2181506,2181570,2181506]),p([2181634,2181698,0,2181762,2130018,2097218,2181828,0,2181954,2182018,2182082,2176066,2182146,2182210,2179138,2182274]),p([2097506,2182338,2182403,2182498,2177538,2182563,2182659,2182754,0,2182819,2182914,2180514,2182978,2183042,2183107,2183203]),p([2183298,2183362,2183426,2183490,2183554,2183618,2183682,2183746,2183810,2183875,2183971,2184067,2184163,2184259,2184355,2184451]),p([2184547,2184643,2184739,2184835,2184931,2185027,2185123,2185219,2185315,2185411,2185507,2185603,2185699,2185795,2185891,2185987]),p([2186081,g,2186113,g,2186145,g,2186177,g,2186209,g,2117121,g,2186241,g,2186273,g]),p([2186305,g,2186337,g,2186369,g,2186401,g,2186433,g,2186465,g,2186497,g,2186529,g]),p([2186561,g,2186593,g,2186625,g,2186657,g,2186689,g,2186721,g,2186753,g,g,w]),p([w,w,w,g,w,w,w,w,w,w,w,w,w,w,g,g]),p([2186785,g,2186817,g,2186849,g,2186881,g,2186913,g,2186945,g,2186977,g,2187009,g]),p([2187041,g,2187073,g,2187105,g,2187137,g,2187169,g,2187201,g,2109217,2109281,w,w]),p([w,w,g,g,g,g,g,g,0,0,0,0,0,0,0,0]),p([g,g,2187233,g,2187265,g,2187297,g,2187329,g,2187361,g,2187393,g,2187425,g]),p([g,g,2187457,g,2187489,g,2187521,g,2187553,g,2187585,g,2187617,g,2187649,g]),p([2187681,g,2187713,g,2187745,g,2187777,g,2187809,g,2187841,g,2187873,g,2187905,g]),p([2187937,g,2187969,g,2188001,g,2188033,g,2188065,g,2188097,g,2188129,g,2188161,g]),p([2188193,g,2188225,g,2188257,g,2188289,g,2188321,g,2188353,g,2188385,g,2188417,g]),p([2188417,g,g,g,g,g,g,g,g,2188449,g,2188481,g,2188513,2188545,g]),p([2188577,g,2188609,g,2188641,g,2188673,g,g,g,g,2188705,g,2118977,g,g]),p([2188737,g,2188769,g,g,g,2188801,g,2188833,g,2188865,g,2188897,g,2188929,g]),p([2188961,g,2188993,g,2189025,g,2189057,g,2189089,g,2105249,2118689,2118945,2189121,2119009,g]),p([2189153,2189185,2119073,2189217,2189249,g,2189281,g,2189313,g,2189345,g,2189377,g,2189409,g]),p([2189441,g,2189473,g,2189505,2119361,2189537,2189569,g,2189601,g,0,0,0,0,0]),p([2189633,g,0,g,0,g,2189665,g,2189697,g,0,0,0,0,0,0]),p([0,0,A,B,M,2189729,g,g,2100321,2101089,g,g,g,g,g,g]),p([g,g,w,g,g,g,w,g,g,g,g,w,g,g,g,g]),p([g,g,g,w,w,w,w,w,g,g,g,g,w,0,0,0]),p([w,w,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,0,0,0,0,0,0,0,0,g,g]),p([w,w,g,g,g,g,g,g,g,g,g,g,g,g,g,w]),p([g,g,g,g,g,g,w,w,w,w,w,w,w,w,g,g]),p([g,g,g,g,g,g,g,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,0,0,0,0,0,0,0,0,0,0,0,g]),p([g,g,g,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,g,g,g,g,g,g,g,g,g,g,g,g,g,0,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,g,g]),p([g,g,g,g,g,w,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,0,0,0,0,0,0,0,0,0]),p([g,g,g,w,g,g,g,g,g,g,g,g,w,w,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,w,w,w,g,g]),p([w,g,w,w,w,g,g,w,w,g,g,g,g,g,w,w]),p([g,w,g,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,w,w,0,0,0,0,0,0,0,0,0]),p([0,g,g,g,g,g,g,0,0,g,g,g,g,g,g,0]),p([0,g,g,g,g,g,g,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,2187297,2189761,2140609,2189793]),p([g,g,g,g,g,g,g,g,g,2189825,g,g,0,0,0,0]),p([2189857,2189889,2189921,2189953,2189985,2190017,2190049,2190081,2190113,2190145,2190177,2190209,2190241,2190273,2190305,2190337]),p([2190369,2190401,2190433,2190465,2190497,2190529,2190561,2190593,2190625,2190657,2190689,2190721,2190753,2190785,2190817,2190849]),p([2190881,2190913,2190945,2190977,2191009,2191041,2191073,2191105,2191137,2191169,2191201,2191233,2191265,2191297,2191329,2191361]),p([2191393,2191425,2191457,2191489,2191521,2191553,2191585,2191617,2191649,2191681,2191713,2191745,2191777,2191809,2191841,2191873]),p([2191905,2191937,2191969,2192001,2192033,2192065,2192097,2192129,2192161,2192193,2192225,2192257,2192289,2192321,2192353,2192385]),p([g,g,g,w,w,w,w,w,w,w,w,g,w,w,0,0]),p([g,g,g,g,g,g,g,0,0,0,0,g,g,g,g,g]),p([2192417,2192449,2147777,2192481,2192513,2192545,2192577,2149505,2149505,2192609,2148033,2192641,2192673,2192705,2192737,2192769]),p([2192801,2192833,2192865,2192897,2192929,2192961,2192993,2193025,2193057,2193089,2193121,2193153,2193185,2193217,2193249,2193281]),p([2193313,2193345,2193377,2193409,2193441,2193473,2193505,2193537,2193569,2193601,2193633,2193665,2193697,2193729,2193761,2193793]),p([2193825,2193857,2193889,2193921,2146689,2193953,2193985,2194017,2194049,2194081,2194113,2194145,2194177,2194209,2194241,2194273]),p([2149025,2194305,2194337,2194369,2194401,2194433,2194465,2194497,2194529,2194561,2194593,2194625,2194657,2194689,2194721,2194753]),p([2194785,2194817,2194849,2194881,2194913,2194945,2194977,2195009,2195041,2195073,2195105,2195137,2192929,2195169,2195201,2195233]),p([2195265,2195297,2195329,2195361,2195393,2195425,2195457,2195489,2195521,2195553,2195585,2195617,2195649,2195681,2195713,2195745]),p([2195777,2147841,2195809,2195841,2195873,2195905,2195937,2195969,2196001,2196033,2196065,2196097,2196129,2196161,2196193,2196225]),p([2196257,2143905,2196289,2196321,2196353,2196385,2196417,2196449,2196481,2196513,2143297,2196545,2196577,2196609,2196641,2196673]),p([2196705,2196737,2196769,2196801,2196833,2196865,2196897,2196929,2196961,2196993,2197025,2197057,2197089,2197121,2197153,2197185]),p([2197217,2195745,2197249,2197281,2197313,2197345,2197377,2197409,2164641,2197441,2195233,2197473,2197505,2197537,2197569,2197601]),p([2197633,2197665,2197697,2197729,2197761,2197793,2197825,2197857,2197889,2197921,2197953,2197985,2198017,2198049,2198081,2192929]),p([2198113,2198145,2198177,2198209,2149473,2198241,2198273,2198305,2198337,2198369,2198401,2198433,2198465,2198497,2198529,2198561]),p([2198593,2156801,2198625,2198657,2198689,2198721,2198753,2198785,2198817,2198849,2198881,2195297,2198913,2198945,2198977,2199009]),p([2199041,2199073,2199105,2199137,2199169,2199201,2199233,2199265,2199297,2148001,2199329,2199361,2199393,2199425,2199457,2199489]),p([2199521,2199553,2199585,2199617,2199649,2199681,2199713,2146433,2199745,2199777,2199809,2199841,2199873,2199905,2199937,2199969]),p([2200001,2200033,2200065,2200097,2200129,2200161,2200193,2200225,2147297,2200257,2147393,2200289,2200321,2200353,g,g]),p([2200385,g,2200417,g,g,2200449,2200481,2200513,2200545,2200577,2200609,2200641,2200673,2200705,2146657,g]),p([2200737,g,2200769,g,g,2200801,2200833,g,g,g,2200865,2200897,2200929,2200961,2200993,2201025]),p([2201057,2201089,2201121,2201153,2201185,2201217,2201249,2201281,2201313,2201345,2201377,2201409,2144129,2201441,2201473,2201505]),p([2201537,2201569,2201601,2201633,2201665,2201697,2201729,2201761,2201793,2201825,2201857,2201889,2158145,2201921,2201953,2201985]),p([2202017,2158529,2202049,2202081,2202113,2202145,2202177,2196897,2202209,2202241,2202273,2202305,2202337,2202369,2202369,2202401]),p([2202433,2202465,2202497,2202529,2202561,2202593,2202625,2200801,2202657,2202689,2202721,2202753,2202786,2202849,0,0]),p([2202881,2202913,2202945,2202977,2203009,2203041,2203073,2203105,2201249,2203137,2203169,2203201,2200385,2203233,2203265,2203297]),p([2203329,2203361,2203393,2203425,2203457,2203489,2203521,2203553,2203585,2201505,2203617,2201537,2203649,2203681,2203713,2203745]),p([2203777,2200417,2193601,2203809,2203841,2145185,2195777,2198401,2203873,2203905,2201761,2203937,2201793,2203969,2204001,2204033]),p([2200481,2204065,2204097,2204129,2204161,2204193,2200513,2204225,2204257,2204289,2204321,2204353,2204385,2202177,2204417,2204449]),p([2196897,2204481,2202305,2204513,2204545,2204577,2204609,2204641,2202465,2204673,2200769,2204705,2202497,2195169,2204737,2202529]),p([2204769,2202593,2204801,2204833,2204865,2204897,2204929,2202657,2200673,2204961,2202689,2204993,2202721,2205025,2149505,2205058]),p([2205122,2205186,2205249,2205281,2205313,2205346,2205410,2205474,2205537,2205569,0,0,0,0,0,0]),p([2205602,2205666,2205730,2205635,2205795,2097730,2097730,0,0,0,0,0,0,0,0,0]),p([0,0,0,2205890,2205954,2206018,2206082,2206146,0,0,0,0,0,2206210,w,2206274]),p([2206337,2130529,2130625,2206369,2206401,2206433,2206465,2206497,2206529,10518241,2206562,2206626,2206691,2206787,2206882,2206946]),p([2207010,2207074,2207138,2207202,2207266,2207330,2207394,0,2207458,2207522,2207586,2207650,2207714,0,2207778,0]),p([2207842,2207906,0,2207970,2208034,0,2208098,2208162,2208226,2206690,2208290,2208354,2208418,2208482,2208546,2208610]),p([2208673,2208673,2208705,2208705,2208705,2208705,2208737,2208737,2208737,2208737,2208769,2208769,2208769,2208769,2208801,2208801]),p([2208801,2208801,2208833,2208833,2208833,2208833,2208865,2208865,2208865,2208865,2208897,2208897,2208897,2208897,2208929,2208929]),p([2208929,2208929,2208961,2208961,2208961,2208961,2208993,2208993,2208993,2208993,2209025,2209025,2209025,2209025,2209057,2209057]),p([2209057,2209057,2209089,2209089,2209121,2209121,2209153,2209153,2209185,2209185,2209217,2209217,2209249,2209249,2209281,2209281]),p([2209281,2209281,2209313,2209313,2209313,2209313,2209345,2209345,2209345,2209345,2209377,2209377,2209377,2209377,2209409,2209409]),p([2209441,2209441,2209441,2209441,2209473,2209473,2209505,2209505,2209505,2209505,2209537,2209537,2209537,2209537,2209569,2209569]),p([2209601,2209601,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,2209633,2209633,2209633,2209633,2113985,2113985,2209665,2209665,2209697,2209697,2113986,2209729,2209729]),p([2209761,2209761,2209793,2209793,2209825,2209825,2209825,2209825,2209857,2209857,2209890,2209890,2209954,2209954,2210018,2210018]),p([2210082,2210082,2210146,2210146,2210210,2210210,2210274,2210274,2210274,2210338,2210338,2210338,2210401,2210401,2210401,2210401]),p([2210434,2210498,2210562,2210338,2210626,2210690,2210754,2210818,2210882,2210946,2211010,2211074,2211138,2211202,2211266,2211330]),p([2211394,2211458,2211522,2211586,2211650,2211714,2211778,2211746,2211842,2211906,2211970,2212034,2212098,2212162,2212226,2212290]),p([2212354,2212418,2212482,2212546,2212610,2212674,2212738,2212802,2212866,2212930,2212994,2213058,2213122,2213186,2213250,2213314]),p([2213378,2213442,2213506,2213570,2213634,2213698,2213762,2213826,2213890,2213954,2214018,2214082,2214146,2214210,2214274,2214338]),p([2214402,2214466,2214530,2214594,2214658,2214722,2211810,2211874,2214786,2214850,2214914,2214978,2215042,2215106,2215170,2215234]),p([2215298,2215362,2215426,2215490,2215554,2211682,2215618,2215682,2214690,2215746,2215586,2215810,2215874,2215938,10604611,10604707]),p([10604803,10604899,10604995,10605091,2216578,2216642,2210562,2216706,2210338,2210626,2216770,2216834,2210882,2216898,2210946,2211010]),p([2216962,2217026,2211266,2217090,2211330,2211394,2217154,2217218,2211522,2217282,2211586,2211650,2213442,2213506,2213698,2213762]),p([2213826,2214082,2214146,2214210,2214274,2214530,2214594,2214658,2217346,2214786,2217410,2217474,2215170,2217538,2215234,2215298]),p([2215938,2217602,2217666,2214690,2214946,2215746,2215586,2210434,2210498,2217730,2210562,2217794,2210690,2210754,2210818,2210882]),p([2217858,2211074,2211138,2211202,2211266,2217922,2211522,2211714,2211778,2211746,2211842,2211906,2212034,2212098,2212162,2212226]),p([2212290,2212354,2217986,2212418,2212482,2212546,2212610,2212674,2212738,2212866,2212930,2212994,2213058,2213122,2213186,2213250]),p([2213314,2213378,2213570,2213634,2213890,2213954,2214018,2214082,2214146,2214338,2214402,2214466,2214530,2218050,2214722,2211810]),p([2211874,2214786,2214978,2215042,2215106,2215170,2218114,2215362,2215426,2218178,2211682,2215618,2215682,2214690,2215330,2210562]),p([2217794,2210882,2217858,2211266,2217922,2211522,2218242,2212290,2218306,2218370,2218434,2214082,2214146,2214530,2215170,2218114]),p([2214690,2215330,2218499,2218595,2218691,2218786,2218850,2218914,2218978,2219042,2219106,2219170,2219234,2219298,2219362,2219426]),p([2215650,2219490,2219554,2219618,2215714,2219682,2219746,2219810,2219874,2219938,2220002,2220066,2218370,2220130,2220194,2220258]),p([2220322,2218786,2218850,2218914,2218978,2219042,2219106,2219170,2219234,2219298,2219362,2219426,2215650,2219490,2219554,2219618]),p([2215714,2219682,2219746,2219810,2219874,2219938,2220002,2220066,2218370,2220130,2220194,2220258,2220322,2219938,2220002,2220066]),p([2218370,2218306,2218434,2212802,2212098,2212162,2212226,2219938,2220002,2220066,2212802,2212866,2220386,2220386,g,g]),p([2220451,2220547,2220547,2220643,2220739,2220835,2220931,2221027,2211779,2211779,2221123,2221219,2221315,2221411,2221507,2221603]),p([2221603,2221699,2221795,2221795,2221891,2221891,2221987,2222083,2222083,2222179,2222275,2222275,2222371,2222371,2222467,2222563]),p([2222563,2222659,2222659,2222755,2222851,2222947,2223043,2223043,2223139,2223235,2223331,2223427,2223523,2223523,2223619,2223715]),p([2223811,2223907,2224003,2224099,2224099,2224195,2224195,2224291,2224291,2224387,2211811,2224483,2224579,2214723,2211875,2224675]),p([0,0,2224771,2224867,2224963,2225059,2225155,2225251,2225251,2225347,2225443,2225539,2225635,2225635,2225731,2225827]),p([2225923,2226019,2226115,2226211,2226307,2226403,2226499,2226595,2226691,2226787,2226883,2226979,2227075,2227171,2215619,2227267]),p([2227363,2227459,2227555,2227651,2223619,2223811,2227747,2227843,2227939,2228035,2228131,2228227,2228131,2227939,2228323,2228419]),p([2228515,2228611,2228707,2228227,2222947,2221987,2228803,2228899,0,0,0,0,0,0,0,g]),p([2228995,2229091,2229188,2229316,2229444,2229572,2229700,2229828,2229956,2230083,10618802,10619368,2231012,g,g,g]),p([R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R]),p([10619745,2231169,0,10527425,10494753,10517729,10517857,2231201,2231233,0,0,0,0,0,0,0]),p([0,2231265,2231297,10619937,10619937,10518337,10518369,10619969,10620001,2231425,2231457,2231489,2231521,2231553,2231585,2133409]),p([2133441,2231617,2231649,2231681,2231713,g,g,10620353,10620385,10517794,10517794,10517794,10517794,10619937,10619937,10619937]),p([10619745,2231169,0,0,10494753,10527425,10517857,10517729,2231265,10518337,10518369,10619969,10620001,2231425,2231457,10620417]),p([10620449,10620481,10518241,2231905,10620545,10620577,10518305,0,10620609,10620641,10620673,10620705,0,0,0,0]),p([10620738,2232194,10604610,g,10604706,0,10604802,2218498,10604898,2218594,10604994,2218690,10605090,2232258,10620930,2232386]),p([2232449,2232481,2232481,2232513,2232513,2232545,2232545,2232577,2232577,2209889,2209889,2209889,2209889,2113857,2113857,2210689]),p([2210689,2210689,2210689,2232609,2232609,2211073,2211073,2211073,2211073,2211457,2211457,2211457,2211457,2210465,2210465,2210465]),p([2210465,2210529,2210529,2210529,2210529,2210849,2210849,2210849,2210849,2229537,2229537,2215809,2215809,2215873,2215873,2216673]),p([2216673,2212097,2212097,2212097,2212097,2218369,2218369,2218369,2218369,2212353,2212353,2212353,2212353,2212481,2212481,2212481]),p([2212481,2212737,2212737,2212737,2212737,2212865,2212865,2212865,2212865,2212929,2212929,2212929,2212929,2213057,2213057,2213057]),p([2213057,2213185,2213185,2213185,2213185,2213569,2213569,2213569,2213569,2213825,2213825,2213825,2213825,2214113,2214113,2214113]),p([2214113,2210593,2210593,2210593,2210593,2214977,2214977,2214977,2214977,2215361,2215361,2215361,2215361,2113921,2113921,2209857]),p([2209857,2114049,2114049,2114049,2114049,2232642,2232642,2232706,2232706,2232770,2232770,2230882,2230882,0,0,2097152]),p([0,10517729,10621441,10620417,10620641,10620673,10620449,10621473,10518337,10518369,10620481,10518241,10619745,2231905,2149569,10518433]),p([2129441,2098369,2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601,10527425,10494753,10620545,10518305,10620577,10517857]),p([10620705,D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1]),p([J,M,S,P,z,q,I,y,k,L,W,10620353,10620609,10620385,10621505,10619937]),p([10516993,D,_,A,b,j,B,G,O,C,F,U,x,N,H,$$1]),p([J,M,S,P,z,q,I,y,k,L,W,10619969,10621537,10620001,10621569,2232993]),p([2233025,2149569,2231617,2231649,2231169,2233057,2164609,2164929,2170305,2233089,2170497,2165441,2233121,2166721,2172449,2166145]),p([2164769,2163201,2163233,2163265,2163297,2163329,2163361,2163393,2163425,2163457,2149889,2163489,2163521,2163553,2163585,2163617]),p([2163649,2163681,2163713,2163745,2149921,2163777,2163809,2163841,2163873,2163905,2163937,2163969,2164001,2164033,2164065,2164097]),p([2164129,2164161,2164193,2164225,2164257,2164289,2164321,2164353,2164385,2164417,2164449,2164481,2164513,2164993,2149729,2149793]),p([2150433,2150465,2150497,2150529,2150561,2150593,2150625,2150657,2150689,2150721,2150753,2150785,2150817,2150849,2150881,0]),p([0,0,2150913,2150945,2150977,2151009,2151041,2151073,0,0,2151105,2151137,2151169,2151201,2151233,2151265]),p([0,0,2151297,2151329,2151361,2151393,2151425,2151457,0,0,2151489,2151521,2151553,0,0,0]),p([2233153,2233185,2233217,10486690,2233249,2233281,2233313,0,2233345,2233377,2233409,2233441,2233473,2233505,2233537,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,0,g,g,0,g]),p([g,g,g,0,0,0,0,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,w,0,0]),p([w,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,0,0,0,0,0,0,g,g,g]),p([g,g,g,g,g,g,w,w,w,w,w,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,0,g]),p([g,g,g,g,0,0,0,0,g,g,g,g,g,g,g,g]),p([2233570,2233634,2233698,2233762,2233826,2233890,2233954,2234018,2234082,2234146,2234210,2234274,2234338,2234402,2234466,2234530]),p([2234594,2234658,2234722,2234786,2234850,2234914,2234978,2235042,2235106,2235170,2235234,2235298,2235362,2235426,2235490,2235554]),p([2235618,2235682,2235746,2235810,2235874,2235938,2236002,2236066,g,g,g,g,g,g,g,g]),p([2236130,2236194,2236258,2236322,2236386,2236450,2236514,2236578,2236642,2236706,2236770,2236834,2236898,2236962,2237026,2237090]),p([2237154,2237218,2237282,2237346,2237410,2237474,2237538,2237602,2237666,2237730,2237794,2237858,2237922,2237986,2238050,2238114]),p([2238178,2238242,2238306,2238370,0,0,0,0,g,g,g,g,g,g,g,g]),p([g,g,g,g,0,0,0,0,0,0,0,0,0,0,0,g]),p([2238434,2238498,2238562,2238626,2238690,2238754,2238818,2238882,2238946,2239010,2239074,0,2239138,2239202,2239266,2239330]),p([2239394,2239458,2239522,2239586,2239650,2239714,2239778,2239842,2239906,2239970,2240034,0,2240098,2240162,2240226,2240290]),p([2240354,2240418,2240482,0,2240546,2240610,0,g,g,g,g,g,g,g,g,g]),p([g,g,0,g,g,g,g,g,g,g,0,g,g,0,0,0]),p([g,2240673,2240705,2098881,2240737,2101825,0,2240769,2240801,2240833,2240865,2101985,2102017,2240897,2240929,2240961]),p([2240993,2241025,2241057,2102209,2241089,2100321,2241121,2241153,2241185,2241217,2241249,2189121,2241282,2241345,2241377,2241410]),p([2241473,2241506,2099425,2241569,2241601,M,2241633,2241666,2140673,2241729,2102561,2241761,2241793,2241825,2241857,2102689]),p([2241889,0,2241921,2241953,2241985,2242017,2242049,2242081,2242113,2242146,2242210,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,g,0,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,g,g,0,0,0,g,0,0,g]),p([g,g,g,0,g,g,0,0,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,0,0,g]),p([g,g,g,g,g,g,g,g,g,g,0,0,0,0,0,g]),p([g,g,g,g,g,g,g,g,0,0,0,0,g,g,g,g]),p([0,0,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,w,w,w,0,w,w,0,0,0,0,0,w,w,w,w]),p([g,g,g,g,0,g,g,g,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,0,w,w,w,0,0,0,0,w]),p([g,g,g,g,g,w,w,0,0,0,0,g,g,g,g,g]),p([g,g,g,g,g,g,0,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,0,0,g,g,g,g,g,g,g,g]),p([g,g,g,0,0,0,0,0,g,g,g,g,g,g,g,g]),p([g,g,0,0,0,0,0,0,0,g,g,g,g,0,0,0]),p([0,0,0,0,0,0,0,0,0,g,g,g,g,g,g,g]),p([2242274,2242338,2242402,2242466,2242530,2242594,2242658,2242722,2242786,2242850,2242914,2242978,2243042,2243106,2243170,2243234]),p([2243298,2243362,2243426,2243490,2243554,2243618,2243682,2243746,2243810,2243874,2243938,2244002,2244066,2244130,2244194,2244258]),p([2244322,2244386,2244450,2244514,2244578,2244642,2244706,2244770,2244834,2244898,2244962,2245026,2245090,2245154,2245218,2245282]),p([2245346,2245410,2245474,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,0,0,0,0,0,0,0,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,w,w,g,0,0]),p([g,g,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,0,0,w,w,w]),p([w,g,g,g,g,g,g,g,g,g,0,0,0,0,0,0]),p([g,g,w,w,w,w,g,g,g,g,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,g,g,g,g,g,g,g,0,0]),p([w,g,g,w,w,g,0,0,0,0,0,0,0,0,0,w]),p([w,w,w,w,w,w,w,w,w,w,w,g,g,0,g,g]),p([g,g,w,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,0,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,w,w,g,0,0,0,0,0,0,0,0]),p([g,g,g,w,g,g,g,0,0,0,0,0,0,0,0,0]),p([w,g,g,g,g,g,g,g,g,w,w,w,w,g,w,w]),p([g,g,g,g,g,g,g,g,g,g,g,g,w,w,w,w]),p([w,w,w,w,w,w,w,w,g,g,g,g,g,g,w,g]),p([g,w,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,0,g,0,g,g,g,g,0,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,w]),p([w,w,w,w,w,w,w,w,w,w,w,0,0,0,0,0]),p([w,w,w,w,0,g,g,g,g,g,g,g,g,0,0,g]),p([g,0,g,g,0,g,g,g,g,g,0,w,w,g,w,w]),p([g,0,0,0,0,0,0,w,0,0,0,0,0,g,g,g]),p([g,g,w,w,0,0,w,w,w,w,w,w,w,0,0,0]),p([w,w,w,w,w,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,0,g,w,g]),p([w,w,w,w,g,g,g,g,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,0,0,w,w,w,w,w,w,w,w]),p([g,g,g,g,g,g,g,g,g,g,g,g,w,w,0,0]),p([w,g,g,g,g,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,g,g,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,w,w,g,0,0,0,0]),p([2245538,2245602,2245666,2245730,2245794,2245858,2245922,2245986,2246050,2246114,2246178,2246242,2246306,2246370,2246434,2246498]),p([2246562,2246626,2246690,2246754,2246818,2246882,2246946,2247010,2247074,2247138,2247202,2247266,2247330,2247394,2247458,2247522]),p([g,g,g,0,0,0,0,0,0,0,0,0,0,0,0,g]),p([g,g,g,g,g,g,g,0,0,g,0,0,g,g,g,g]),p([g,g,g,g,0,g,g,0,g,g,g,g,g,g,g,g]),p([w,w,w,w,w,w,0,w,w,0,0,w,w,w,w,g]),p([w,g,w,w,g,g,g,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,0,0,g,g,g,g,g,g]),p([g,w,w,w,w,w,w,w,0,0,w,w,w,w,w,w]),p([w,g,g,g,w,0,0,0,0,0,0,0,0,0,0,0]),p([g,w,w,w,w,w,w,w,w,w,w,g,g,g,g,g]),p([g,g,g,w,w,w,w,w,w,w,g,w,w,w,w,g]),p([g,g,g,g,g,g,g,w,0,0,0,0,0,0,0,0]),p([g,w,w,w,w,w,w,w,w,w,w,w,g,g,g,g]),p([w,w,w,w,w,w,w,w,w,w,g,g,g,g,g,g]),p([w,w,w,w,w,w,w,0,w,w,w,w,w,w,w,w]),p([0,0,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,0,w,w,w,w,w,w,w]),p([g,g,g,g,g,g,g,0,g,g,0,g,g,g,g,g]),p([g,w,w,w,w,w,w,0,0,0,w,0,w,w,0,w]),p([w,w,w,w,w,w,g,w,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,0,g,g,0,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,w,w,w,w,w,0]),p([w,w,0,w,w,w,w,w,g,0,0,0,0,0,0,0]),p([g,g,g,w,w,w,w,g,g,0,0,0,0,0,0,0]),p([w,w,g,w,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,w,w,w,0,0,0,w,w]),p([g,g,0,0,0,0,0,0,0,0,0,0,0,0,0,g]),p([w,g,g,g,g,g,g,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,g,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,0,0,0,0,0,g,g,g]),p([2247586,2247650,2247714,2247778,2247842,2247906,2247970,2248034,2248098,2248162,2248226,2248290,2248354,2248418,2248482,2248546]),p([2248610,2248674,2248738,2248802,2248866,2248930,2248994,2249058,2249122,2249186,2249250,2249314,2249378,2249442,2249506,2249570]),p([g,g,g,g,g,g,g,g,g,g,g,0,0,0,0,w]),p([g,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,0,0,0,0,0,0,0,w]),p([g,g,g,g,w,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,0,g,g,g,g,g,g,g,0,g,g,0]),p([0,0,g,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,0,0,g,0,0,0,0,0,0,0,0,0,0]),p([0,0,0,0,g,g,g,g,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,g,g,g,g,0,0,g,w,w,g]),p([2097152,2097152,2097152,2097152,0,0,0,0,0,0,0,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,w,0,0]),p([g,g,g,g,g,g,g,0,0,g,g,g,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,g,g,g,2249636,2249764]),p([2249894,2250086,2250278,2250470,2250662,w,w,w,w,w,g,g,g,w,w,w]),p([w,w,w,0,0,0,0,0,0,0,0,w,w,w,w,w]),p([w,w,w,g,g,w,w,w,w,w,w,w,g,g,g,g]),p([g,g,g,g,g,g,g,g,g,g,g,2250852,2250980,2251110,2251302,2251494]),p([2251686,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,w,w,w,g,0,0,0,0,0,0,0,0,0,0]),p([M,S,P,z,q,I,y,k,L,W,D,_,A,b,j,B]),p([G,O,C,F,U,x,N,H,$$1,J,M,S,P,z,q,I]),p([y,k,L,W,D,_,A,b,j,B,G,O,C,F,U,x]),p([N,H,$$1,J,M,S,P,z,q,I,y,k,L,W,D,_]),p([A,b,j,B,G,0,C,F,U,x,N,H,$$1,J,M,S]),p([P,z,q,I,y,k,L,W,D,_,A,b,j,B,G,O]),p([C,F,U,x,N,H,$$1,J,M,S,P,z,q,I,y,k]),p([L,W,D,_,A,b,j,B,G,O,C,F,U,x,N,H]),p([$$1,J,M,S,P,z,q,I,y,k,L,W,D,0,A,b]),p([0,0,G,0,0,F,U,0,0,H,$$1,J,M,0,P,z]),p([q,I,y,k,L,W,D,_,A,b,0,B,0,O,C,F]),p([U,x,N,H,0,J,M,S,P,z,q,I,y,k,L,W]),p([y,k,L,W,D,_,0,b,j,B,G,0,0,F,U,x]),p([N,H,$$1,J,M,0,P,z,q,I,y,k,L,0,D,_]),p([A,b,j,B,G,O,C,F,U,x,N,H,$$1,J,M,S]),p([P,z,q,I,y,k,L,W,D,_,0,b,j,B,G,0]),p([C,F,U,x,N,0,$$1,0,0,0,P,z,q,I,y,k]),p([L,0,D,_,A,b,j,B,G,O,C,F,U,x,N,H]),p([$$1,J,M,S,P,z,q,I,y,k,L,W,D,_,A,b]),p([j,B,G,O,C,F,U,x,N,H,$$1,J,M,S,P,z]),p([q,I,y,k,L,W,D,_,A,b,j,B,G,O,C,F]),p([y,k,L,W,2251873,2251905,0,0,2106529,nt,tt,2106625,X,2106689,2106721,E]),p([2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,E,V,2107041,rt,K,ot,2107169]),p([et,2251937,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881]),p([2106913,Q,T,V,V,2107041,rt,K,ot,2107169,et,2251969,X,E,Y,K]),p([T,Q,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881]),p([2106913,Q,T,E,V,2107041,rt,K,ot,2107169,et,2251937,2106529,nt,tt,2106625]),p([X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,V,V,2107041]),p([rt,K,ot,2107169,et,2251969,X,E,Y,K,T,Q,2106529,nt,tt,2106625]),p([X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,E,V,2107041]),p([rt,K,ot,2107169,et,2251937,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y]),p([2106817,2098273,2106849,2106881,2106913,Q,T,V,V,2107041,rt,K,ot,2107169,et,2251969]),p([X,E,Y,K,T,Q,2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y]),p([2106817,2098273,2106849,2106881,2106913,Q,T,E,V,2107041,rt,K,ot,2107169,et,2251937]),p([2106529,nt,tt,2106625,X,2106689,2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q]),p([T,V,V,2107041,rt,K,ot,2107169,et,2251969,X,E,Y,K,T,Q]),p([T,E,V,2107041,rt,K,ot,2107169,et,2251937,2106529,nt,tt,2106625,X,2106689]),p([2106721,E,2105921,Y,2106817,2098273,2106849,2106881,2106913,Q,T,V,V,2107041,rt,K]),p([ot,2107169,et,2251969,X,E,Y,K,T,Q,2107393,2107393,0,0,2129441,2098369]),p([2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601,2129441,2098369,2098145,2098177,2098465,2129473,2129505,2129537]),p([2129569,2129601,2129441,2098369,2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601,2129441,2098369,2098145,2098177]),p([2098465,2129473,2129505,2129537,2129569,2129601,2129441,2098369,2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601]),p([w,w,w,w,w,w,w,g,g,g,g,w,w,w,w,w]),p([w,w,w,w,w,w,w,w,w,w,w,w,w,g,g,g]),p([g,g,g,g,w,g,g,g,g,g,g,g,0,0,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,w,w,w,w,w]),p([0,0,0,0,0,g,g,g,g,g,g,0,0,0,0,0]),p([w,w,w,w,w,w,w,w,w,0,0,w,w,w,w,w]),p([w,w,0,w,w,0,w,w,w,w,w,0,0,0,0,0]),p([2108385,2108417,2108449,2108481,2108513,2108545,2108577,2108609,2108641,2108705,2108737,2108769,2108833,2108865,2108897,2108929]),p([2108961,2108993,2109025,2109057,2109089,2109121,2109153,2109249,2109313,2109345,2186913,2111169,2108065,2108129,2111425,2110529]),p([2252001,2108385,2108417,2108449,2108481,2108513,2108545,2108577,2108609,2108641,2108705,2108737,2108833,2108865,2108929,2108993]),p([2109025,2109057,2109089,2109121,2109153,2109217,2109249,2110049,2108065,2108033,2108353,2110465,2186305,2110561,0,0]),p([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,w]),p([g,g,g,g,g,g,g,0,g,g,g,g,0,g,g,0]),p([g,g,g,g,g,0,0,g,g,g,g,g,g,g,g,g]),p([2252034,2252098,2252162,2252226,2252290,2252354,2252418,2252482,2252546,2252610,2252674,2252738,2252802,2252866,2252930,2252994]),p([2253058,2253122,2253186,2253250,2253314,2253378,2253442,2253506,2253570,2253634,2253698,2253762,2253826,2253890,2253954,2254018]),p([2254082,2254146,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([g,g,g,g,w,w,w,w,w,w,w,g,0,0,0,0]),p([2113857,2210689,2210465,2229537,0,2113921,2216673,2210529,2212737,2114049,2213825,2214113,2210593,2214977,2212097,2212929]),p([2213185,2212353,2213569,2215873,2218369,2211073,2211457,2210849,2215809,2212481,2212865,2213057,2254209,2209409,2254241,2254273]),p([0,2210689,2210465,0,2215361,0,0,2210529,0,2114049,2213825,2214113,2210593,2214977,2212097,2212929]),p([2213185,2212353,2213569,0,2218369,2211073,2211457,2210849,0,2212481,0,2213057,0,0,0,0]),p([0,0,2210465,0,0,0,0,2210529,0,2114049,0,2214113,0,2214977,2212097,2212929]),p([0,2212353,2213569,0,2218369,0,0,2210849,0,2212481,0,2213057,0,2209409,0,2254273]),p([0,2210689,2210465,0,2215361,0,0,2210529,2212737,2114049,2213825,0,2210593,2214977,2212097,2212929]),p([2213185,2212353,2213569,0,2218369,2211073,2211457,2210849,0,2212481,2212865,2213057,2254209,0,2254241,0]),p([2113857,2210689,2210465,2229537,2215361,2113921,2216673,2210529,2212737,2114049,0,2214113,2210593,2214977,2212097,2212929]),p([2213185,2212353,2213569,2215873,2218369,2211073,2211457,2210849,2215809,2212481,2212865,2213057,0,0,0,0]),p([0,2210689,2210465,2229537,0,2113921,2216673,2210529,2212737,2114049,0,2214113,2210593,2214977,2212097,2212929]),p([0,10642914,10642978,10643042,10643106,10643170,10643234,10643298,10643362,10643426,10643490,g,g,g,g,g]),p([10524931,10525027,10525123,10525219,10525315,10525411,10525507,10525603,10525699,10525795,10525891,10525987,10526083,10526179,10526275,10526371]),p([10526467,10526563,10526659,10526755,10526851,10526947,10527043,10527139,10527235,10527331,2254947,A,S,2097218,2255042,g]),p([M,S,P,z,q,I,y,k,L,W,2255106,2181186,2255170,2099650,2255235,2255330]),p([g,g,g,g,g,g,g,g,g,g,2179042,2176546,2255394,g,g,g]),p([2255458,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g]),p([2255522,2255586,2163489,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([2144737,2255649,2255681,2168961,2142913,2255713,2255745,2153185,2255777,2255809,2255841,2198081,2255873,2255905,2255937,2255969]),p([2256001,2256033,2145889,2256065,2256097,2256129,2256161,2256193,2256225,2142721,2152929,2256257,2161089,2153025,2161121,2256289]),p([2147681,2256321,2256353,2256385,2256417,2256449,2158049,2145057,2256481,2256513,2256545,2256577,0,0,0,0]),p([2256611,2256707,2256803,2256899,2256995,2257091,2257187,2257283,2257379,0,0,0,0,0,0,0]),p([2257473,2257505,0,0,0,0,0,0,0,0,0,0,0,0,0,0]),p([g,g,g,g,g,g,0,0,0,0,0,0,0,0,g,g]),p([g,g,g,0,g,g,g,g,g,g,g,g,g,g,g,g]),p([2129441,2098369,2098145,2098177,2098465,2129473,2129505,2129537,2129569,2129601,0,0,0,0,0,0]),p([2257537,2257569,2257601,2257634,2257697,2201057,2257729,2257761,2257793,2257825,2201089,2257857,2257889,2257922,2201121,2257985]),p([2258017,2258049,2258082,2258145,2258177,2255937,2258210,2258273,2258305,2258337,2258369,2202913,2258402,2143233,2258465,2258497]),p([2258529,2258561,2256513,2258593,2258625,2203073,2201153,2201185,2203105,2258657,2258689,2195361,2258721,2201217,2258753,2258785]),p([2258817,2258849,2258849,2258849,2258882,2258945,2258977,2259009,2259042,2259105,2259137,2259169,2259201,2259233,2259265,2259297]),p([2259329,2259361,2259393,2259425,2259457,2259489,2259489,2203169,2259521,2259553,2259585,2259617,2201281,2259649,2259681,2259713]),p([2200001,2259745,2259777,2259809,2259841,2259873,2259905,2259937,2259969,2260002,2260065,2260097,2260129,2255713,2260161,2260193]),p([2260226,2260290,2260353,2260385,2260417,2260449,2260481,2260513,0,2260545,2260577,2260577,2260610,2260673,2260705,2195233]),p([2260737,2260770,2260833,2260865,0,2144065,2260897,2260929,2144129,2260961,2260993,2261026,2261089,2261122,2261185,2261217]),p([2261249,2261281,2261313,2261345,2261377,2261409,2261441,2261473,2261505,2261538,2261601,2261633,2261665,2261697,2193569,2261730]),p([2144449,2261794,2261794,2261857,2261889,2261889,2261921,2261954,2262018,2262081,2262113,2262145,2262177,2262209,2262241,2262273]),p([2262305,2262337,2262369,2201441,2262402,2262465,2262497,2262529,2203553,2262529,2262561,2201505,2262593,2262625,2262657,2262689]),p([2201537,2192705,2176865,2262721,2262753,2262785,2262817,2262849,2262882,2262945,2262977,2263009,2263041,2263073,2263106,2263169]),p([2263201,2263233,2263265,2263297,2263329,2263361,2263393,2263425,2201569,2263457,2263490,2263553,2263585,2263617,2263649,2201633]),p([2263681,2263713,2263745,2263777,2263809,2263841,2263873,2263905,2193601,2203809,2263937,2263969,2264001,2264034,2264097,2264129]),p([2264161,2264193,2201665,2264226,2264289,2264321,2264353,2205249,2264385,2264417,2264449,2264481,2264514,2264577,2264609,2264641]),p([2264674,2264737,2264769,2264801,2264833,2195777,2264865,2264898,2264962,2265026,2265089,2265122,2265185,2265217,2265249,2265281]),p([2265313,2201697,2198401,2265345,2265377,2265409,2265442,2265505,2265537,2265569,2265601,2203905,2265633,2265666,2265729,2265761]),p([2265794,2265858,2265921,2265953,2203937,2265985,2266017,2266049,2266081,2266113,2266145,2266178,2266241,2266274,2266337,0]),p([2266369,2204001,2266401,2266434,2266497,2266529,2266562,2266626,2266689,2266721,2266753,2266785,2266817,2266817,2266849,2266881]),p([2204065,2266913,2266945,2266977,2267009,2267042,2267105,2267138,2195329,2267202,2267265,2267298,2267362,2267426,2267489,2267521]),p([2204257,2267554,2267618,2267682,2267746,2267809,2267841,2267841,2204289,2205313,2267873,2267905,2267937,2267970,2268033,2194145]),p([2204353,2268065,2268098,2202017,2268162,2268226,2200641,2268289,2268321,2202113,2268353,2268385,2268418,2268482,2268482,0]),p([2268545,2268578,2268641,2268673,2268705,2268738,2268801,2268833,2268865,2268897,2268929,2268962,2269025,2269057,2269089,2269121]),p([2269153,2269185,2269218,2269282,2269345,2269378,2269441,2269474,2269537,2269569,2202305,2269602,2269666,2269729,2269762,2269825]),p([2269858,2269921,2269953,2269985,2270017,2270049,2270081,2270114,2270178,2270242,2270306,2261857,2270369,2270401,2270433,2270465]),p([2270497,2270529,2270561,2270593,2270625,2270657,2270689,2270722,2195873,2270785,2270817,2270849,2270881,2270913,2270945,2202401]),p([2270977,2271009,2271041,2271073,2271106,2271170,2271234,2271297,2271329,2271361,2271393,2271426,2271489,2271522,2271585,2271617]),p([2271650,2271714,2271777,2271809,2193985,2271841,2271873,2271905,2271937,2271969,2272001,2204577,2272033,2272065,2272097,0]),p([2272129,2272161,2272193,2272225,2147329,2272258,2272321,2272353,2272385,2272417,2272449,2272482,2272546,2272609,2272641,2272673]),p([2204737,2204769,2147553,2272706,2272769,2272801,2272833,2272865,2272898,2272962,2273025,2273057,2273089,2273122,2273185,2204801]),p([2273218,2273282,2273345,2273377,2273409,2273442,2273505,2273537,2273569,2273601,2273633,2273665,2273697,2273730,2273793,2273825]),p([2273857,2273890,2273953,2273985,2274017,2274049,2274082,2274146,2274209,2274241,2274273,2274306,2274369,2274402,2204993,2204993]),p([2274465,2274498,2274561,2274593,2274625,2274657,2274689,2274721,2274753,2274786,2205025,2274849,2274881,2274913,2274945,2274977]),p([2275010,2275073,2275106,2275170,2275234,2149089,2275297,2149217,2275329,2275361,2275393,2275425,2149377,2275458,0,0]),p([g,g,g,g,g,g,g,g,g,g,g])],st=new Uint16Array([0,0,1,2,3,4,5,6,7,7,8,9,10,11,12,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,...m(12,6),34,12,35,36,12,...m(37,4),38,37,37,39,40,41,42,12,43,44,45,46,47,48,49,12,12,12,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,12,12,66,67,37,68,69,12,70,71,72,73,12,12,74,37,12,75,...m(12,5),76,77,12,78,79,12,37,80,...m(12,5),81,82,12,12,74,83,12,84,85,86,12,87,88,12,86,89,12,12,90,37,91,37,92,12,12,93,37,94,95,12,96,97,98,99,100,101,102,103,104,97,98,105,106,107,72,108,109,110,98,111,112,113,102,114,115,97,98,111,116,117,102,118,119,120,121,122,123,124,72,88,125,126,98,127,128,129,102,130,131,126,98,132,128,133,102,134,135,126,12,136,137,138,102,12,139,140,12,141,142,143,72,144,145,12,12,146,147,148,7,7,149,12,150,151,152,153,7,7,154,155,12,156,157,158,159,160,161,162,163,164,165,88,7,7,12,12,74,166,12,167,168,169,170,171,7,7,172,12,12,173,...m(12,5),86,145,...m(12,13),174,175,12,12,174,12,12,176,177,178,12,12,12,177,12,12,12,179,12,180,12,181,...m(12,5),182,...m(12,40),145,180,...m(12,5),183,12,184,12,185,12,186,187,188,12,12,12,189,37,190,181,181,191,181,...m(12,5),183,192,12,193,...m(12,4),194,12,86,195,195,196,12,78,71,12,12,148,12,181,197,12,12,12,198,12,12,12,199,37,200,181,181,78,37,201,7,7,7,202,12,12,203,204,12,74,205,206,12,207,12,12,12,81,208,12,12,203,209,210,12,12,12,211,212,213,214,118,215,216,217,12,12,218,219,220,221,222,223,12,224,225,226,...m(37,4),227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,12,113,37,37,270,271,272,273,274,275,276,277,278,279,...m(12,9),280,281,12,12,282,...m(12,11),283,...m(12,15),284,7,88,7,285,286,287,288,289,290,291,292,293,...m(12,81),294,...m(12,6),295,...m(12,5),296,...m(12,9),297,12,298,...m(12,6),299,300,301,12,12,12,302,303,304,305,306,307,308,309,310,311,12,12,312,12,12,12,313,314,12,284,...m(315,4),37,37,...m(12,5),78,7,7,12,316,...m(12,5),317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,7,7,332,12,90,333,145,...m(12,4),334,...m(12,5),335,336,12,12,337,338,339,340,341,342,343,...m(12,4),344,12,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,...m(12,1800),180,12,12,12,284,...m(12,21),148,7,377,378,379,380,381,382,...m(12,5),383,12,12,384,385,386,387,388,389,390,391,392,393,394,395,7,396,397,12,398,181,12,12,12,118,399,12,12,203,400,181,37,401,12,12,402,12,403,404,12,180,92,12,12,405,406,407,408,86,12,12,409,410,411,412,12,413,12,12,12,414,415,416,74,417,418,419,315,12,12,420,421,422,423,424,425,426,12,12,427,181,...m(12,698),344,12,428,12,12,148,...m(7,528),429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,7,7,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,12,495,496,497,498,499,500,501,502,7,7,503,504,505,37,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,337,529,530,531,532,7,533,12,178,534,78,78,7,7,...m(12,7),88,535,12,12,536,...m(12,4),86,180,113,7,7,12,12,537,...m(7,8),12,180,12,12,12,113,538,148,12,12,539,12,88,12,12,540,12,541,12,12,542,194,7,7,543,544,545,...m(12,6),78,181,546,547,548,12,148,12,12,118,12,12,12,549,550,551,552,110,553,7,7,7,7,...m(12,19),284,12,194,118,7,554,555,556,557,7,7,7,7,558,12,12,559,12,298,12,12,12,86,130,7,7,7,12,560,12,561,12,562,7,7,7,7,12,12,12,563,12,564,12,12,565,566,12,567,183,183,...m(12,4),7,7,12,12,568,284,12,12,12,569,12,570,12,571,12,572,573,...m(7,5),...m(12,4),183,7,7,7,574,575,576,577,12,12,12,578,12,12,579,181,...m(7,18),12,86,12,12,580,581,7,7,7,582,12,12,118,12,81,583,7,12,584,7,7,12,148,7,12,284,206,12,12,585,586,564,12,587,206,12,12,588,589,12,183,181,206,12,403,590,591,12,12,592,206,12,12,405,593,12,145,71,12,110,594,595,596,7,7,7,597,541,181,12,12,598,599,181,600,97,98,601,116,602,603,604,...m(7,8),12,12,12,605,606,607,581,7,12,12,12,37,608,181,...m(7,10),12,12,598,609,538,610,7,7,12,12,12,37,611,181,180,7,12,12,74,612,181,7,7,7,12,179,195,12,284,...m(7,11),12,12,594,613,...m(7,6),614,615,12,12,12,616,617,618,12,619,620,181,7,7,7,7,621,12,12,622,623,7,624,12,12,625,626,627,12,12,90,628,471,...m(12,4),183,181,...m(7,15),98,12,598,629,194,12,180,12,12,630,631,410,7,7,7,7,632,12,12,633,634,181,635,12,636,637,181,...m(7,19),12,638,639,126,12,640,206,181,...m(7,5),113,12,12,12,641,...m(12,57),181,...m(7,6),...m(12,6),86,71,...m(12,12),344,...m(7,164),...m(12,6),471,...m(12,67),7,642,643,...m(7,250),...m(12,36),284,...m(7,539),...m(12,35),183,12,86,407,...m(12,4),86,181,12,78,644,12,12,12,606,194,645,110,646,12,...m(7,43),647,648,12,12,12,88,...m(7,6),...m(12,4),649,650,37,37,651,206,7,7,7,7,652,653,...m(12,383),118,...m(12,77),194,7,7,183,...m(7,558),654,...m(12,18),471,655,7,656,657,...m(12,24),148,...m(7,144),...m(12,6),88,180,183,658,659,...m(7,293),37,37,660,37,410,...m(12,7),344,7,7,7,...m(12,15),194,12,12,661,12,12,662,663,664,665,12,171,666,667,12,88,7,...m(12,4),668,...m(7,7),12,344,12,344,...m(12,5),284,12,183,...m(7,8),292,669,670,671,672,673,674,675,676,677,678,679,680,292,669,670,681,682,683,684,685,686,687,688,689,291,292,669,670,671,672,683,674,675,676,687,688,689,291,292,669,670,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,703,705,706,707,708,709,710,...m(12,32),37,37,37,711,37,37,712,408,713,714,67,...m(7,69),12,86,715,...m(7,13),629,716,717,718,719,720,721,7,722,...m(7,7),12,12,180,586,407,...m(7,20),12,103,7,12,12,594,562,...m(7,29),12,594,181,...m(7,46),723,86,...m(12,12),724,410,7,7,725,726,727,12,728,407,...m(7,49),145,12,12,12,71,7,7,7,7,145,12,12,78,...m(7,12),729,730,731,732,733,734,735,736,737,738,739,738,7,7,7,581,...m(7,16),12,12,148,...m(12,6),344,86,...m(145,3),12,194,740,741,742,292,743,12,744,12,12,745,78,7,7,7,72,12,746,747,748,749,750,751,194,...m(7,9),...m(12,61),563,180,180,...m(12,7),428,...m(12,5),181,148,113,148,12,12,12,118,181,12,12,118,12,78,581,7,7,7,7,...m(12,21),344,78,180,183,12,12,541,752,148,183,183,...m(12,9),753,12,12,88,7,7,754,...m(7,64),...m(12,2670),7,7,...m(12,259),181,...m(12,13),78,...m(12,360),581,...m(12,467),113,...m(7,193),755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,...m(7,93),7]),lt="abcdefghijklmnopqrstuvwxyz  ̈ ̄23 ́μ ̧11⁄41⁄23⁄4àáâãäåæçèéêëìíîïðñòóôõöøùúûüýþssāăąćĉċčďđēĕėęěĝğġģĥħĩīĭįi̇ĵķĺļľl·łńņňʼnŋōŏőœŕŗřśŝşšţťŧũūŭůűųŵŷÿźżžɓƃƅɔƈɖɗƌǝəɛƒɠɣɩɨƙɯɲɵơƣƥʀƨʃƭʈưʊʋƴƶʒƹƽdžljnjǎǐǒǔǖǘǚǜǟǡǣǥǧǩǫǭǯdzǵƕƿǹǻǽǿȁȃȅȇȉȋȍȏȑȓȕȗșțȝȟƞȣȥȧȩȫȭȯȱȳⱥȼƚⱦɂƀʉʌɇɉɋɍɏɦɹɻʁ ̆ ̇ ̊ ̨ ̃ ̋ʕ̀̓̈́ιͱͳʹͷ ι;ϳ ̈́άέήίόύώαβγδεζηθκλνξοπρστυφχψωϊϋϗϙϛϝϟϡϣϥϧϩϫϭϯϸϻͻͼͽѐёђѓєѕіїјљњћќѝўџабвгдежзийклмнопрстуфхцчшщъыьэюяѡѣѥѧѩѫѭѯѱѳѵѷѹѻѽѿҁҋҍҏґғҕҗҙқҝҟҡңҥҧҩҫҭүұҳҵҷҹһҽҿӂӄӆӈӊӌӎӑӓӕӗәӛӝӟӡӣӥӧөӫӭӯӱӳӵӷӹӻӽӿԁԃԅԇԉԋԍԏԑԓԕԗԙԛԝԟԡԣԥԧԩԫԭԯաբգդեզէըթժիլխծկհձղճմյնշոչպջռսվտրցւփքօֆեւاٴوٴۇٴيٴक़ख़ग़ज़ड़ढ़फ़य़ড়ঢ়য়ਲ਼ਸ਼ਖ਼ਗ਼ਜ਼ਫ਼ଡ଼ଢ଼ําໍາຫນຫມ་གྷཌྷདྷབྷཛྷཀྵཱཱིུྲྀྲཱྀླྀླཱྀྒྷྜྷྡྷྦྷྫྷྐྵⴧⴭნᏰᏱᏲᏳᏴᏵꙋაბგდევზთიკლმოპჟრსტუფქღყშჩცძწჭხჯჰჱჲჳჴჵჶჷჸჹჺჽჾჿɐɑᴂɜᴖᴗᴝᴥɒɕɟɡɥɪᵻʝɭᶅʟɱɰɳɴɸʂƫᴜʐʑḁḃḅḇḉḋḍḏḑḓḕḗḙḛḝḟḡḣḥḧḩḫḭḯḱḳḵḷḹḻḽḿṁṃṅṇṉṋṍṏṑṓṕṗṙṛṝṟṡṣṥṧṩṫṭṯṱṳṵṷṹṻṽṿẁẃẅẇẉẋẍẏẑẓẕaʾạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹỻỽỿἀἁἂἃἄἅἆἇἐἑἒἓἔἕἠἡἢἣἤἥἦἧἰἱἲἳἴἵἶἷὀὁὂὃὄὅὑὓὕὗὠὡὢὣὤὥὦὧἀιἁιἂιἃιἄιἅιἆιἇιἠιἡιἢιἣιἤιἥιἦιἧιὠιὡιὢιὣιὤιὥιὦιὧιὰιαιάιᾶιᾰᾱ ̓ ͂ ̈͂ὴιηιήιῆιὲ ̓̀ ̓́ ̓͂ΐῐῑὶ ̔̀ ̔́ ̔͂ΰῠῡὺῥ ̈̀`ὼιωιώιῶιὸ‐ ̳′′′′′‵‵‵‵‵!! ̅???!!?056789+−=()a/ca/s°cc/oc/u°fsmteltmאבגדfax∑1⁄71⁄91⁄101⁄32⁄31⁄52⁄53⁄54⁄51⁄65⁄61⁄83⁄85⁄87⁄8iiiiiivviviiviiiixxixii0⁄3∫∫∫∫∫∮∮∮∮∮〈〉121314151617181920(1)(2)(3)(4)(5)(6)(7)(8)(9)(10)(11)(12)(13)(14)(15)(16)(17)(18)(19)(20)(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)(l)(m)(n)(o)(p)(q)(r)(s)(t)(u)(v)(w)(x)(y)(z)::===⫝̸ⰰⰱⰲⰳⰴⰵⰶⰷⰸⰹⰺⰻⰼⰽⰾⰿⱀⱁⱂⱃⱄⱅⱆⱇⱈⱉⱊⱋⱌⱍⱎⱏⱐⱑⱒⱓⱔⱕⱖⱗⱘⱙⱚⱛⱜⱝⱞⱟⱡɫᵽɽⱨⱪⱬⱳⱶȿɀⲁⲃⲅⲇⲉⲋⲍⲏⲑⲓⲕⲗⲙⲛⲝⲟⲡⲣⲥⲧⲩⲫⲭⲯⲱⲳⲵⲷⲹⲻⲽⲿⳁⳃⳅⳇⳉⳋⳍⳏⳑⳓⳕⳗⳙⳛⳝⳟⳡⳣⳬⳮⳳⵡ母龟一丨丶丿乙亅二亠人儿入八冂冖冫几凵刀力勹匕匚匸十卜卩厂厶又口囗土士夂夊夕大女子宀寸小尢尸屮山巛工己巾干幺广廴廾弋弓彐彡彳心戈戶手支攴文斗斤方无日曰月木欠止歹殳毋比毛氏气水火爪父爻爿片牙牛犬玄玉瓜瓦甘生用田疋疒癶白皮皿目矛矢石示禸禾穴立竹米糸缶网羊羽老而耒耳聿肉臣自至臼舌舛舟艮色艸虍虫血行衣襾見角言谷豆豕豸貝赤走足身車辛辰辵邑酉釆里金長門阜隶隹雨靑非面革韋韭音頁風飛食首香馬骨高髟鬥鬯鬲鬼魚鳥鹵鹿麥麻黃黍黑黹黽鼎鼓鼠鼻齊齒龍龜龠.〒卄卅 ゙ ゚よりコトᄀᄁᆪᄂᆬᆭᄃᄄᄅᆰᆱᆲᆳᆴᆵᄚᄆᄇᄈᄡᄉᄊᄋᄌᄍᄎᄏᄐᄑ하ᅢᅣᅤᅥᅦᅧᅨᅩᅪᅫᅬᅭᅮᅯᅰᅱᅲᅳᅴᅵᄔᄕᇇᇈᇌᇎᇓᇗᇙᄜᇝᇟᄝᄞᄠᄢᄣᄧᄩᄫᄬᄭᄮᄯᄲᄶᅀᅇᅌᇱᇲᅗᅘᅙᆄᆅᆈᆑᆒᆔᆞᆡ三四上中下甲丙丁天地(ᄀ)(ᄂ)(ᄃ)(ᄅ)(ᄆ)(ᄇ)(ᄉ)(ᄋ)(ᄌ)(ᄎ)(ᄏ)(ᄐ)(ᄑ)(ᄒ)(가)(나)(다)(라)(마)(바)(사)(아)(자)(차)(카)(타)(파)(하)(주)(오전)(오후)(一)(二)(三)(四)(五)(六)(七)(八)(九)(十)(月)(火)(水)(木)(金)(土)(日)(株)(有)(社)(名)(特)(財)(祝)(労)(代)(呼)(学)(監)(企)(資)(協)(祭)(休)(自)(至)問幼箏pte2224252627282930333435참고주의우秘男適優印注項写正左右医宗夜3637383940444546474849501月2月3月4月5月6月7月8月9月10月11月12月hgergevltdアイウエオカキクケサシスセソタチツテナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヰヱヲ令和アパートアルファアンペアアールイニングインチウォンエスクードエーカーオンスオームカイリカラットカロリーガロンガンマギガギニーキュリーギルダーキロキログラムキロメートルキロワットグラムトンクルゼイロクローネケースコルナコーポサイクルサンチームシリングセンチセントダースデシドルナノノットハイツパーセントパーツバーレルピアストルピクルピコビルファラッドフィートブッシェルフランヘクタールペソペニヒヘルツペンスページベータポイントボルトホンポンドホールホーンマイクロマイルマッハマルクマンションミクロンミリミリバールメガメガトンヤードヤールユアンリットルリラルピールーブルレムレントゲン0点1点2点3点4点5点6点7点8点9点10点11点12点13点14点15点16点17点18点19点20点21点22点23点24点hpadaaubarovpcdmdm2dm3iu平成昭和大正明治株式会社naμamakakbmbgbcalkcalpfnfμfμgmgkghzkhzmhzthzμlmldlfmnmμmmmcmkmmm2cm2km2mm3cm3km3m∕sm∕s2kpampagparadrad∕srad∕s2psnsμsmspvnvμvmvkvpwnwμwmwkwkωmωbqc∕kgdbgyhainkkktlnloglxmilmolphppmprsvwbv∕ma∕m1日2日3日4日5日6日7日8日9日10日11日12日13日14日15日16日17日18日19日20日21日22日23日24日25日26日27日28日29日30日31日galꙁꙃꙅꙇꙉꙍꙏꙑꙓꙕꙗꙙꙛꙝꙟꙡꙣꙥꙧꙩꙫꙭꚁꚃꚅꚇꚉꚋꚍꚏꚑꚓꚕꚗꚙꚛꜣꜥꜧꜩꜫꜭꜯꜳꜵꜷꜹꜻꜽꜿꝁꝃꝅꝇꝉꝋꝍꝏꝑꝓꝕꝗꝙꝛꝝꝟꝡꝣꝥꝧꝩꝫꝭꝯꝺꝼᵹꝿꞁꞃꞅꞇꞌꞑꞓꞗꞙꞛꞝꞟꞡꞣꞥꞧꞩɬʞʇꭓꞵꞷꞹꞻꞽꞿꟁꟃꞔᶎꟈꟊꟑꟗꟙꟶꬷꭒʍᎠᎡᎢᎣᎤᎥᎦᎧᎨᎩᎪᎫᎬᎭᎮᎯᎰᎱᎲᎳᎴᎵᎶᎷᎸᎹᎺᎻᎼᎽᎾᎿᏀᏁᏂᏃᏄᏅᏆᏇᏈᏉᏊᏋᏌᏍᏎᏏᏐᏑᏒᏓᏔᏕᏖᏗᏘᏙᏚᏛᏜᏝᏞᏟᏠᏡᏢᏣᏤᏥᏦᏧᏨᏩᏪᏫᏬᏭᏮᏯ豈更賈滑串句契喇奈懶癩羅蘿螺裸邏樂洛烙珞落酪駱亂卵欄爛蘭鸞嵐濫藍襤拉臘蠟廊朗浪狼郎來冷勞擄櫓爐盧蘆虜路露魯鷺碌祿綠菉錄論壟弄籠聾牢磊賂雷壘屢樓淚漏累縷陋勒肋凜凌稜綾菱陵讀拏諾丹寧怒率異北磻便復不泌數索參塞省葉說殺沈拾若掠略亮兩凉梁糧良諒量勵呂廬旅濾礪閭驪麗黎曆歷轢年憐戀撚漣煉璉秊練聯輦蓮連鍊列劣咽烈裂廉念捻殮簾獵囹嶺怜玲瑩羚聆鈴零靈領例禮醴隸惡了僚寮尿料燎療蓼遼暈阮劉杻柳流溜琉留硫紐類戮陸倫崙淪輪律慄栗隆利吏履易李梨泥理痢罹裏裡離匿溺吝燐璘藺隣鱗麟林淋臨笠粒狀炙識什茶刺切度拓糖宅洞暴輻降廓兀嗀塚晴凞猪益礼神祥福靖精蘒諸逸都飯飼館鶴郞隷侮僧免勉勤卑喝嘆器塀墨層悔慨憎懲敏既暑梅海渚漢煮爫琢碑祉祈祐祖禍禎穀突節縉繁署者臭艹著褐視謁謹賓贈辶難響頻恵𤋮舘並况全侀充冀勇勺啕喙嗢墳奄奔婢嬨廒廙彩徭惘慎愈慠戴揄搜摒敖望杖滛滋瀞瞧爵犯瑱甆画瘝瘟盛直睊着磌窱类絛缾荒華蝹襁覆調請諭變輸遲醙鉶陼韛頋鬒𢡊𢡄𣏕㮝䀘䀹𥉉𥳐𧻓齃龎fffiflfflմնմեմիվնմխיִײַעהכלםרתשׁשׂשּׁשּׂאַאָאּבּגּדּהּוּזּטּיּךּכּלּמּנּסּףּפּצּקּרּתּוֹבֿכֿפֿאלٱٻپڀٺٿٹڤڦڄڃچڇڍڌڎڈژڑکگڳڱںڻۀہھےۓڭۆۈۋۅۉېىئائەئوئۇئۆئۈئېئىیئجئحئمئيبجبحبخبمبىبيتجتحتختمتىتيثجثمثىثيجحجمحمخجخحخمسجسحسخسمصحصمضجضحضخضمطحطمظمعجعمغجغمفجفحفخفمفىفيقحقمقىقيكاكجكحكخكلكمكىكيلجلحلخلملىليمجمممىمينجنحنخنمنىنيهجهمهىهييحيخيىذٰرٰىٰ ٌّ ٍّ َّ ُّ ِّ ّٰئرئزئنبربزبنترتزتنثرثزثنمانرنزننيريزئخئهبهتهصخلهنههٰثهسهشمشهـَّـُّـِّطىطيعىعيغىغيسىسيشىشيحىجىجيخىصىصيضىضيشجشحشخشرسرصرضراًتجمتحجتحمتخمتمجتمحتمخحميحمىسحجسجحسجىسمحسمجسممصححصممشحمشجيشمخشممضحىضخمطمحطممطميعجمعممعمىغممغميغمىفخمقمحقمملحملحيلحىلججلخملمحمحجمحيمجحمخممجخهمجهممنحمنحىنجمنجىنمينمىيممبخيتجيتجىتخيتخىتميتمىجميجحىجمىسخىصحيشحيضحيلجيلمييجييميمميقمينحيعميكمينجحمخيلجمكممجحيحجيمجيفميبحيسخينجيصلےقلےاللهاكبرمحمدصلعمرسولعليهوسلمصلىصلى الله عليه وسلمجل جلالهریال,、〖〗—–_{}〔〕【】《》「」『』[]#&*-<>\\$%@ ًـًـّ ْـْءآأؤإةلآلألإ\"'^|~⦅⦆・ゥャ¢£¬¦¥₩│←↑→↓■○𐐨𐐩𐐪𐐫𐐬𐐭𐐮𐐯𐐰𐐱𐐲𐐳𐐴𐐵𐐶𐐷𐐸𐐹𐐺𐐻𐐼𐐽𐐾𐐿𐑀𐑁𐑂𐑃𐑄𐑅𐑆𐑇𐑈𐑉𐑊𐑋𐑌𐑍𐑎𐑏𐓘𐓙𐓚𐓛𐓜𐓝𐓞𐓟𐓠𐓡𐓢𐓣𐓤𐓥𐓦𐓧𐓨𐓩𐓪𐓫𐓬𐓭𐓮𐓯𐓰𐓱𐓲𐓳𐓴𐓵𐓶𐓷𐓸𐓹𐓺𐓻𐖗𐖘𐖙𐖚𐖛𐖜𐖝𐖞𐖟𐖠𐖡𐖣𐖤𐖥𐖦𐖧𐖨𐖩𐖪𐖫𐖬𐖭𐖮𐖯𐖰𐖱𐖳𐖴𐖵𐖶𐖷𐖸𐖹𐖻𐖼ːˑʙʣꭦʥʤᶑɘɞʩɤɢʛʜɧʄʪʫ𝼄ꞎɮ𝼅ʎ𝼆ɶɷɺ𝼈ɾʨʦꭧʧⱱʏʡʢʘǀǁǂ𝼊𝼞𐳀𐳁𐳂𐳃𐳄𐳅𐳆𐳇𐳈𐳉𐳊𐳋𐳌𐳍𐳎𐳏𐳐𐳑𐳒𐳓𐳔𐳕𐳖𐳗𐳘𐳙𐳚𐳛𐳜𐳝𐳞𐳟𐳠𐳡𐳢𐳣𐳤𐳥𐳦𐳧𐳨𐳩𐳪𐳫𐳬𐳭𐳮𐳯𐳰𐳱𐳲𑣀𑣁𑣂𑣃𑣄𑣅𑣆𑣇𑣈𑣉𑣊𑣋𑣌𑣍𑣎𑣏𑣐𑣑𑣒𑣓𑣔𑣕𑣖𑣗𑣘𑣙𑣚𑣛𑣜𑣝𑣞𑣟𖹠𖹡𖹢𖹣𖹤𖹥𖹦𖹧𖹨𖹩𖹪𖹫𖹬𖹭𖹮𖹯𖹰𖹱𖹲𖹳𖹴𖹵𖹶𖹷𖹸𖹹𖹺𖹻𖹼𖹽𖹾𖹿𝅗𝅥𝅘𝅥𝅘𝅥𝅮𝅘𝅥𝅯𝅘𝅥𝅰𝅘𝅥𝅱𝅘𝅥𝅲𝆹𝅥𝆺𝅥𝆹𝅥𝅮𝆺𝅥𝅮𝆹𝅥𝅯𝆺𝅥𝅯ıȷ∇∂ӏ𞤢𞤣𞤤𞤥𞤦𞤧𞤨𞤩𞤪𞤫𞤬𞤭𞤮𞤯𞤰𞤱𞤲𞤳𞤴𞤵𞤶𞤷𞤸𞤹𞤺𞤻𞤼𞤽𞤾𞤿𞥀𞥁𞥂𞥃ٮڡٯ0,1,2,3,4,5,6,7,8,9,〔s〕wzhvsdppvwcmrdjほかココ字双多解交映無前後再新初終販声吹演投捕遊指打禁空合満申割営配〔本〕〔三〕〔二〕〔安〕〔点〕〔打〕〔盗〕〔勝〕〔敗〕得可丽丸乁𠄢你侻倂偺備像㒞𠘺兔兤具𠔜㒹內𠕋冗冤仌冬𩇟刃㓟刻剆剷㔕包匆卉博即卽卿𠨬灰及叟𠭣叫叱吆咞吸呈周咢哶唐啓啣善喫喳嗂圖圗噑噴壮城埴堍型堲報墬𡓤売壷夆夢奢𡚨𡛪姬娛娧姘婦㛮嬈嬾𡧈寃寘寳𡬘寿将㞁屠峀岍𡷤嵃𡷦嵮嵫嵼巡巢㠯巽帨帽幩㡢𢆃㡼庰庳庶𪎒𢌱舁弢㣇𣊸𦇚形彫㣣徚忍志忹悁㤺㤜𢛔惇慈慌慺憲憤憯懞戛扝抱拔捐𢬌挽拼捨掃揤𢯱搢揅掩㨮摩摾撝摷㩬敬𣀊旣書晉㬙㬈㫤冒冕最暜肭䏙朡杞杓𣏃㭉柺枅桒𣑭梎栟椔楂榣槪檨𣚣櫛㰘次𣢧歔㱎歲殟殻𣪍𡴋𣫺汎𣲼沿泍汧洖派浩浸涅𣴞洴港湮㴳滇𣻑淹潮𣽞𣾎濆瀹瀛㶖灊災灷炭𠔥煅𤉣熜爨牐𤘈犀犕𤜵𤠔獺王㺬玥㺸瑇瑜璅瓊㼛甤𤰶甾𤲒𢆟瘐𤾡𤾸𥁄㿼䀈𥃳𥃲𥄙𥄳眞真瞋䁆䂖𥐝硎䃣𥘦𥚚𥛅秫䄯穊穏𥥼𥪧䈂𥮫篆築䈧𥲀糒䊠糨糣紀𥾆絣䌁緇縂繅䌴𦈨𦉇䍙𦋙罺𦌾羕翺𦓚𦔣聠𦖨聰𣍟䏕育脃䐋脾媵𦞧𦞵𣎓𣎜舄辞䑫芑芋芝劳花芳芽苦𦬼茝荣莭茣莽菧荓菊菌菜𦰶𦵫𦳕䔫蓱蓳蔖𧏊蕤𦼬䕝䕡𦾱𧃒䕫虐虧虩蚩蚈蜎蛢蜨蝫螆蟡蠁䗹衠𧙧裗裞䘵裺㒻𧢮𧥦䚾䛇誠𧲨貫賁贛起𧼯𠠄跋趼跰𠣞軔𨗒𨗭邔郱鄑𨜮鄛鈸鋗鋘鉼鏹鐕𨯺開䦕閷𨵷䧦雃嶲霣𩅅𩈚䩮䩶韠𩐊䪲𩒖頩𩖶飢䬳餩馧駂駾䯎𩬰鱀鳽䳎䳭鵧𪃎䳸𪄅𪈎𪊑䵖黾鼅鼏鼖𪘀";function at(t){return t>=196608?t>=917760&&t<=917999?18874368:0:it[st[t>>4]][15&t]}function ct(t,n,o){const r=[],e=a(t);for(let t=0;t<e.length;t++){const i=e[t],s=c([e[t]]),l=at(i),a=l>>23,f=l>>21&3,u=l>>5&65535,h=31&l,d=lt.substr(u,h);if(0===f||n&&1&a)throw new Error("Illegal char "+s);1===f?r.push(d):2===f?r.push(o?d:s):3===f&&r.push(s);}return r.join("").normalize("NFC")}function ft(t,n,o){void 0===o&&(o=!1);let r=ct(t,o,n).split(".");return r=r.map((function(t){return t.startsWith("xn--")?ut(t=h(t.substring(4)),o,!1):ut(t,o,n),t})),r.join(".")}function ut(t,n,o){if("-"===t[2]&&"-"===t[3])throw new Error("Failed to validate "+t);if(t.startsWith("-")||t.endsWith("-"))throw new Error("Failed to validate "+t);if(t.includes("."))throw new Error("Failed to validate "+t);if(ct(t,n,o)!==t)throw new Error("Failed to validate "+t);const r=t.codePointAt(0);if(at(r)&2<<23)throw new Error("Label contains illegal character: "+r)}function ht(t,n){void 0===n&&(n={});const o=!("transitional"in n)||n.transitional,r="useStd3ASCII"in n&&n.useStd3ASCII,e="verifyDnsLength"in n&&n.verifyDnsLength,i=ft(t,o,r).split(".").map(d),s=i.join(".");let l;if(e){if(s.length<1||s.length>253)throw new Error("DNS name has wrong length: "+s);for(l=0;l<i.length;l++){const t=i[l];if(t.length<1||t.length>63)throw new Error("DNS label has wrong length: "+t)}}return s}function dt(t){const n=Array.isArray(t);n||(t=[t]);const o={IDN:[],PC:[]};return t.forEach((t=>{let n,r;try{n=ht(t,{transitional:!t.match(/\.(?:be|ca|de|fr|pm|re|swiss|tf|wf|yt)\.?$/)}),r={PC:n,IDN:mt(n)};}catch(n){r={PC:t,IDN:t};}o.PC.push(r.PC),o.IDN.push(r.IDN);})),n?o:{IDN:o.IDN[0],PC:o.PC[0]}}function mt(t,n){void 0===n&&(n={});return ft(t,!1,"useStd3ASCII"in n&&n.useStd3ASCII)}

class UniqueObjectCache {
	constructor(sessionKey) {
		this.sessionKey = `cnic${activeLanguage}${sessionKey}`;
	}

	get _sessionKey() {
		return this.sessionKey;
	}

	set _sessionKey(key) {
		this.sessionKey = `cnic${activeLanguage}${key}`;
	}

	cacheKey(key) {
		return (
			key?.idnDomainName || key?.domainName || key?.key || this._sessionKey
		);
	}

	cacheObject(object, singleData = false) {
		const key = this.cacheKey(object);
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};
		if (singleData && !cache) {
			return sessionStorage.setItem(this._sessionKey, JSON.stringify(cache));
		}
		if (!cache[key]) {
			cache[key] = object;
			sessionStorage.setItem(this._sessionKey, JSON.stringify(cache));
		}
	}

	findCacheObject(object, getData = false) {
		const key = this.cacheKey(object);
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};

		if (getData && cache[key]) {
			return cache[key];
		}
		if (!cache[key]) {
			return false;
		}
		return true;
	}

	deleteDomainCache(domain) {
		const key = this.cacheKey({domainName: domain});
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};

		if (typeof cache[key] === undefined) {
			return false;
		}

		delete cache[key];
		sessionStorage.setItem(this._sessionKey, JSON.stringify(cache));
		return true;
	}

	clearCache() {
		sessionStorage.removeItem(this._sessionKey);
	}

	getCache() {
		const cacheJson = sessionStorage.getItem(this._sessionKey);
		const cache = cacheJson ? JSON.parse(cacheJson) : {};
		return Object.values(cache);
	}
}

class Util {
	static updateCurrentURLState() {
		var queryParams = new URLSearchParams(window.location.search);

		// Set new or modify existing parameter value.
		queryParams.set('searchTerm', this.session.searchTerm);

		// Replace current querystring with the new one.
		history.replaceState(null, null, '?' + queryParams.toString());
	}

	static async fetchData(data) {
		const formData = new FormData();
		let url = `${cnicWebRootPath}/mydomainsearch.php`;
		const requestType = data.type;
		const searchTerm = data.searchTerm || '';
		const searchPage = data.searchPage || 1;
		const searchAction = data.searchAction || '';
		const advancedOptions = this.session.advancedOptions || [];

		formData.append('token', csrfToken);

		switch (requestType) {
			case 'addToCart':
				url = `${cnicWebRootPath}/cart.php`;
				formData.append('a', requestType);
				formData.append('sideorder', 0);
				formData.append('whois', data.domainPremium ? 1 : 0);
				formData.append('domain', data.domainPc);
				break;
			case 'addDomainTransfer':
				url = `${cnicWebRootPath}/cart.php`;
				formData.append('a', requestType);
				formData.append('domain', data.domainPc);
				if (data.eppcode !== 'true' && data.eppcode?.length > 0) {
					formData.append('epp', data.eppcode);
				}
				break;
			case 'removeFromCart':
				formData.append('action', 'cart');
				formData.append('type', 'remove');
				formData.append('idnDomain', data.domainIdn);
				break;
			case 'updateCart':
				url = `${cnicWebRootPath}/cart.php`;
				formData.append('a', 'updateDomainPeriod');
				formData.append('period', data.domainPeriod);
				formData.append('domain', data.domainPc);
				break;
			case 'getCartDomains':
				formData.append('action', 'cart');
				formData.append('type', 'list');
				break;
			case 'config':
				formData.append('action', 'loadconfiguration');
				break;
			case 'tldsPricing':
				formData.append('action', 'tldsPricing');
				formData.append('request', data.request);
				break;
			case 'clearCache':
				formData.append('action', 'clearCache');
				break;
			case 'cnicDomainSearchLoadMore':
				if (searchAction === 'suggestions') {
					formData.append('action', searchAction);
					formData.append('page', searchPage);
					formData.append('last', JSON.stringify(data.lastResults));
					formData.append('total', JSON.stringify(data.totalResults));
					if (advancedOptions.length) {
						formData.append('advancedOptions', advancedOptions);
					}
					this.updateCurrentURLState();
					break;
				}
			default: // fallback to search request type
				formData.append('action', searchAction);
				if (advancedOptions.length) {
					formData.append('advancedOptions', advancedOptions);
				}
				this.updateCurrentURLState();
				break;
		}

		let groupList = [];
		let promises = [];
		// Check if search action is "register" and search term exists
		if (searchAction === 'register') {
			if (!searchTerm) {
				return; // Exit early if search term is empty
			}
			groupList = this.buildGroupList(
				this.getPunyCodeName(searchTerm, false),
				searchPage,
			);
		} else if (searchAction === 'suggestions') {
			if (!searchTerm) {
				return; // Exit early if search term is empty
			}
			formData.append('searchTerm', this.getPunyCodeName(searchTerm));
		}

		if (!groupList.length) {
			if (searchPage === 1 && searchAction === 'suggestions') {
				// raw search parameter to track search logs
				formData.append('rawSearchTerm', searchTerm);
			}
			promises.push(this.fetchApi(url, formData));
		} else {
			groupList.forEach((group, index) => {
				const cleanedGroup = group.map(domain => {
					const {order, tld, registrationPrice, renewPrice, ...cleanedDomain} =
						domain;
					return cleanedDomain;
				});

				formData.set('search', JSON.stringify(cleanedGroup));
				if (searchPage === 1 && index === 0) {
					// raw search parameter to track search logs
					formData.append('rawSearchTerm', searchTerm);
				}
				promises.push(this.fetchApi(url, formData));
			});
		}

		return promises;
	}

	static async fetchApi(url, formData) {
		const response = await fetch(url, {
			method: 'POST',
			body: formData,
		});
		let responseData = [];
		if (!response.ok) {
			$(document).ready(function () {
				$('search-engine').before(
					"<center><h1>Oops! Something went wrong.</h1><br /> Please try reloading the page and give it another shot.<br /><br /> If you're an admin, please double-check your configurations to ensure everything is set up correctly.</center><br /><br />",
				);
			});
			throw new Error('Network response was not ok');
		}
		try {
			responseData = await response.json();
		} catch (error) {
			return console.error('Error:', error.message);
		}
		return responseData;
	}

	static getPunyCodeName(keyword, stringify = true) {
		const lines = keyword
			.trim()
			.split(/\n/)
			.map(line => line.trim());
		const punyCodeNames = [];

		for (const line of lines) {
			const words = line.split(/\s+/).map(word => word.trim()); // multi-keyword search
			const keywords = [];
			for (const word of words) {
				if (word.length === 0) {
					continue;
				}

				try {
					let newKeyword;

					if (!/\./.test(word)) {
						newKeyword = dt(word).IDN;
						keywords.push({keyword: newKeyword}); // generate a domain list
					} else {
						let domain = word;
						if (!/http/gi.test(word)) {
							domain = 'https://' + domain;
						}
						domain = new URL(domain);
						const unicodeDomain = mt(domain.hostname);
						newKeyword = dt(this.getDomain(unicodeDomain)).IDN;
						keywords.push({exact: this.cleanUpSearchKeyword(newKeyword)}); // exact domain search
					}
				} catch (e) {
					// ignore errors
				}
			}

			if (keywords.length > 0) {
				punyCodeNames.push(...keywords);
			}
		}
		if (!stringify) {
			return punyCodeNames.flat(1);
		}
		return JSON.stringify(punyCodeNames);
	}

	static get params() {
		return new Proxy(new URLSearchParams(window.location.search), {
			get: function (searchParams, prop) {
				if (prop === 'getAll') {
					return searchParams.toString();
				}
				return searchParams.get(prop);
			},
			set: (searchParams, prop, value) => {
				if (value) {
					searchParams.set(prop, value);
				} else {
					searchParams.delete(prop);
				}
				const newUrl = `${window.location.protocol}//${window.location.host}${
					window.location.pathname
				}?${searchParams.toString()}`;
				window.history.pushState({path: newUrl}, '', newUrl);
				return newUrl;
			},
		});
	}

	static get session() {
		return new Proxy(sessionStorage, {
			get: function (storage, prop) {
				prop = 'cnic' + prop;
				const item = storage.getItem(prop) || null;
				return JSON.parse(item);
			},
			set: (storage, prop, value) => {
				prop = 'cnic' + prop;
				value = JSON.stringify(value);
				if (value.length > 0) {
					storage.setItem(prop, value);
				}
				return true;
			},
			deleteProperty: (storage, prop) => {
				prop = 'cnic' + prop;
				if (storage.getItem(prop)) {
					storage.removeItem(prop);
				}
				return true;
			},
		});
	}

	static availabilityCompareFn(a, b) {
		a = a.isAvailable;
		b = b.isAvailable;
		// if a is available and b is not available
		if (a && !b) {
			return -1;
		}
		// if a is not available and b is available
		if (!a && b) {
			return 1;
		}
		// a must be equal to b
		return 0;
	}

	static ordinalSuffixOf(i) {
		var j = i % 10,
			k = i % 100;
		if (j == 1 && k != 11) {
			return `${i}<span class="Text-size-xsmall_superscript">st</span>`;
		}
		if (j == 2 && k != 12) {
			return `${i}<span class="Text-size-xsmall_superscript">nd</span>`;
		}
		if (j == 3 && k != 13) {
			return `${i}<span class="Text-size-xsmall_superscript">rd</span>`;
		}
		return `${i}<span class="Text-size-xsmall_superscript">th</span>`;
	}

	static toggleButtons(element, inputs) {
		let value = element.target.value;
		let inputElements = [];
		inputs.forEach(input => {
			let label = input.labels[0];
			if (input.value === value) {
				inputElements['check'] = {class: label.className, element: label};
			} else {
				inputElements['uncheck'] = {class: label.className, element: label};
			}
		});
		let tmpEl = inputElements['check'].element;
		tmpEl.className = inputElements['uncheck'].class;
		tmpEl = inputElements['uncheck'].element;
		tmpEl.className = inputElements['check'].class;
	}

	static cleanUpSearchKeyword(keyword) {
		if (!keyword) {
			return false;
		}
		const invalidChars =
			/(~|`|!|@|#|\$|%|\^|&|\*|\(|\)|_|\+|=|{|}|\[|\]|\||\\|;|:|"|'|<|>|,|\?|\/)/g;
		return keyword.trim().replace(invalidChars, '');
	}

	static getDomain(keyword) {
		// Check if the tlds array has already been initialized
		if (!this.session?.allTlds) {
			let tlds = [];
			const categories = this.session.config.categories;
			categories.forEach(category => {
				const tmpTlds = category.tlds;
				tlds = {...tlds, ...tmpTlds};
			});
			this.session.allTlds = tlds;
		}

		// Loop through the tlds to find a match with the keyword
		const findTld = this.isValidDomain(keyword);

		if (!findTld) {
			// If no match is found, return the original keyword
			return keyword;
		}

		// If a match is found, extract the domain name from the keyword and return it with the matching tld
		const domainName = keyword.slice(0, -findTld.length).replace(/\./g, '');
		return `${domainName}.${findTld}`;
	}

	static isValidDomain(keyword) {
		// Check if the tlds array has already been initialized
		if (!this.session?.allTlds) {
			let tlds = [];
			const categories = this.session.config.categories;
			categories.forEach(category => {
				const tmpTlds = category.tlds;
				tlds = {...tlds, ...tmpTlds};
			});
			this.session.allTlds = tlds;
		}

		// Loop through the tlds to find a match with the keyword
		const tldFound =
			Object.keys(this.session.allTlds).find(tld => keyword.endsWith(tld)) ||
			false;

		// If no match is found, return the original keyword
		return tldFound;
	}

	static searchBulkMode(keyword, bulk) {
		if (this.params.action !== 'transfer') {
			if (bulk) {
				keyword = keyword.replace(/\s/g, '\n');
			} else {
				keyword = keyword.replace(/\n/g, ' ');
			}
		}

		return keyword;
	}

	static deleteValueFromArray(array, key, value) {
		for (let i = 0; i < array.length; i++) {
			if (array[i][key] === value) {
				array.splice(i, 1);
				i--; // update loop index to account for removed element
			}
		}
		return array;
	}

	static findValueInArray(array, value, key = null) {
		if (!key) {
			return array.find(obj => obj.type === value);
		}

		if (key === 'suggest') {
			return array.find(
				obj =>
					obj.suggest === value.domainName ||
					obj.suggest === value.idnDomainName,
			);
		} else {
			return array.some(obj => obj[key] === value || obj[key] === value);
		}
	}

	static buildDomainList(data, searchType, searchTerm, firstRequest) {
		if (searchType === 'transfer') {
			return this.buildDomainTransferList(searchTerm);
		}
		let domainSuggestionList = [];
		let domainBaseList = [];

		// Check if data exists and has "suggestions" or "exact" properties
		if (
			!data ||
			(!data.hasOwnProperty('suggestions') && !data.hasOwnProperty('exact'))
		) {
			return;
		}

		// Loop through each type of data
		for (const type of Object.keys(data)) {
			if (type === 'info') {
				continue;
			}

			// Get the list of domains for the current data type
			const domains = data[type];

			// Create a temporary list to store the reformatted domains
			const tmpList = [];

			// Loop through each domain in the list
			for (const domain of Object.values(domains)) {
				// Skip domains without pricing information
				if (!domain.pricing) {
					continue;
				}

				// Get domain properties
				const {
					domainName,
					tld,
					idnDomainName,
					pricing: domainPricing,
					status: domainStatus,
					group: domainGroup,
					isAvailable,
					isPremium,
					isAftermarket,
					tldSupported,
					availabilityReason,
				} = domain;
				let isBaseDomain = false;

				// Set isBaseDomain to true for exact search domains
				if (type === 'exact') {
					isBaseDomain = true;
				}

				let addToCart = false;
				let cartItemType = '';
				let registerPeriod = domain.shortestPeriod.period;

				// Add reformatted domain to temporary list
				const domainObject = {
					domainName,
					tld,
					idnDomainName,
					domainPricing,
					domainStatus,
					domainGroup,
					addToCart,
					cartItemType,
					isAvailable,
					tldSupported,
					isPremium,
					isAftermarket,
					isBaseDomain,
					registerPeriod,
					availabilityReason,
				};

				// add domain object to caching
				const cachedData = new UniqueObjectCache('CachedDomainList');
				cachedData.deleteDomainCache(domainName);
				cachedData.cacheObject(domainObject);

				tmpList.push(domainObject);
			}

			// Add temporary list to the appropriate domain list property
			if (type === 'suggestions') {
				domainSuggestionList = tmpList;
			} else if (type === 'exact') {
				domainBaseList = tmpList.sort(this.availabilityCompareFn);
			}
		}

		let returnData = {domainBaseList, domainSuggestionList};
		if (data.info?.total) {
			returnData = {...returnData, info: data.info};
		}
		return returnData;
	}

	static sortByTlds(tlds) {
		return Object.keys(tlds).sort((a, b) => tlds[a] - tlds[b]);
	}

	static sortDomainList(a, b) {
		// destructuring to get the values from the objects
		const {order: orderA, tld: tldA, suggest: suggestA} = a;
		const {order: orderB, tld: tldB, suggest: suggestB} = b;

		// Parse the order values only once
		const orderNumA = parseInt(orderA);
		const orderNumB = parseInt(orderB);

		// Get the sort and sort order from the Util params
		const {sort, sortDir} = Util.params ?? {};
		const sortOrder = sortDir === 'DESC' ? -1 : 1;

		// handle different sort cases
		switch (sort) {
			case 'TldOrder':
				return (orderNumA - orderNumB) * sortOrder;
			case 'TldName':
				if (tldA && tldB) {
					// Use localeCompare to compare strings
					return (
						tldA.localeCompare(tldB, undefined, {
							sensitivity: 'base',
						}) * sortOrder
					);
				}
			case 'DomainName':
				if (suggestA && suggestB) {
					// Use localeCompare to compare strings
					return (
						suggestA
							.replace('.', ' ')
							.localeCompare(suggestB.replace('.', ' '), undefined, {
								sensitivity: 'base',
							}) * sortOrder
					);
				}
			// case "RegistrationPrice":
			// case "RenewPrice":
			//     if (tldA && tldB) {
			//         // Use optional chaining and nullish coalescing to get the prices
			//         const tldsPricing = (sort === "RegistrationPrice" ? Util.session.tldsRegisterPricing : Util.session.tldsRenewPricing) ?? [];
			//         const priceA = tldsPricing[tldA] ?? 10000;
			//         const priceB = tldsPricing[tldB] ?? 10000;
			//         if (sortOrder === -1) {
			//             return priceA - priceB;
			//         } else {
			//             return priceB - priceA;
			//         }
			//     }
			//     break;
			default:
				return (orderNumA - orderNumB) * sortOrder;
		}
	}

	static sortDomainByOrder(a, b) {
		return parseInt(a.order) - parseInt(b.order);
	}

	static filterTlds(item) {
		const {filter, filterPriceRange: range} = Util.params ?? [];
		if (item?.exact?.length > 0 || !filter) {
			// exclude filtering of exact domain searches
			return true;
		}
		return filter === 'RegistrationPrice'
			? item.registrationPrice <= range
			: item.renewPrice <= range;
	}

	static buildGroupList(searchTerms, searchPage = 1) {
		let tlds = {};
		if (!this.session?.sortedTlds) {
			const categories = this.session.config.categories;
			let selectedCategories = this.session.selectedTldCategories;
			if (!selectedCategories?.length) {
				selectedCategories = categories;
			}

			selectedCategories.forEach(category => {
				const tmpCat =
					category.tlds ||
					categories.find(categoryTlds => category === categoryTlds.id)?.tlds ||
					{};
				tlds = {...tlds, ...tmpCat};
			});

			Util.session.sortedTlds = this.sortByTlds(tlds);
		}

		tlds = Util.session.sortedTlds;

		const domainSet = new Set();
		let domainList = [];
		searchTerms.forEach(search => {
			if (search.exact && !domainSet.has(search.exact)) {
				domainSet.add(search.exact);
				domainList.unshift({exact: search.exact});
			} else if (search.keyword) {
				const suggest = `${search.keyword}.`;

				tlds.forEach((tld, j) => {
					const value = {suggest: suggest + tld, tld, order: j + 1};

					const tldsRegisterPricing = Util.session.tldsRegisterPricing ?? [];
					const tldsRenewPricing = Util.session.tldsRenewPricing ?? [];

					if (tldsRegisterPricing && tldsRenewPricing) {
						value.registrationPrice = tldsRegisterPricing[value.tld];
						value.renewPrice = tldsRenewPricing[value.tld];
					}
					domainList.push(value);
				});
			}
		});

		domainList = domainList.sort(this.sortDomainList).filter(this.filterTlds);
		Util.session.domainList = domainList;

		if (!searchPage || searchPage === 0) {
			searchPage = 1;
		}

		const resultsPerPage = searchPage * 12;
		let domainListCurrentPage = domainList.splice(
			Util.session.lastResult || 0,
			12,
		);
		// Use arrow functions instead of function expressions
		domainListCurrentPage = domainListCurrentPage.filter(domain => {
			const domainName = domain.suggest || domain.exact;
			if (domainName.length > 0) {
				// Use const instead of let for variables that are not reassigned
				const cachedData = new UniqueObjectCache('CachedDomainList');
				// Use shorthand property names for objects
				const data = cachedData.findCacheObject({domainName});
				if (data === false) {
					return domain;
				}
			}
		});

		const groups = domainListCurrentPage;
		this.session.lastResult = resultsPerPage + 1;
		this.session.totalResults = domainList.length;

		const result = [];
		let exp = 0;
		while (groups.length) {
			result.push(groups.splice(0, 2 ** exp));
			if (++exp > 3) {
				exp = 0;
			}
		}
		return result;
	}

	static getCachedDomains(domains, page, type) {
		const cachedData = new UniqueObjectCache('CachedDomainList');
		const cachedDomains = cachedData.getCache();
		if (!cachedDomains.length) {
			return {};
		}

		const currentPageResults = 12 * page; // get total items in the group
		const lastResultIndex = page > 1 ? this.session.lastResult : 0;
		const domainList = this.session.domainList.splice(
			lastResultIndex,
			currentPageResults,
		);

		const result = domainList
			.map(domain => (type === 'baseList' ? domain.exact : domain.suggest))
			.reduce((result, domainName) => {
				const find = cachedDomains.find(
					dom => dom.idnDomainName === domainName,
				);
				if (
					type === 'baseList' &&
					typeof find?.isBaseDomain !== 'undefined' &&
					!find.isBaseDomain
				) {
					find.isBaseDomain = true;
				} else if (type === 'suggestionList' && find?.isBaseDomain) {
					find.isBaseDomain = false;
				}

				if (domains.length) {
					const domainExistsInDomainsList = domains.some(
						domain => domain.idnDomainName === domainName,
					);
					if (find && !domainExistsInDomainsList) {
						result.push(find);
					}
				} else {
					if (find) {
						result.push(find);
					}
				}

				return result;
			}, []);

		domains.push(...result);
	}

	static getDomainsWithEpp(keyword) {
		const lines = keyword
			.trim()
			.split(/\n/)
			.map(line => line.trim());
		const keywords = [];
		for (const line of lines) {
			const words = line.split(/\s+/).map(word => word.trim()); // multi-keyword search
			let lastIndexKey = '';
			for (const word of words) {
				if (word.length === 0) {
					return;
				}

				try {
					if (!/\./.test(word) && keywords[lastIndexKey]) {
						keywords[lastIndexKey] = word;
					} else if (/\./.test(word)) {
						const domain = new URL(`https://${word}`);
						const unicodeDomain = mt(domain.hostname);
						lastIndexKey = unicodeDomain;
						keywords[unicodeDomain] = true; // exact domain search
					}
				} catch (e) {
					// ignore errors
				}
			}
		}
		return keywords;
	}

	static buildDomainTransferList(searchTerms) {
		const domainsWithEpp = this.getDomainsWithEpp(searchTerms);
		const categories = this.session.config.categories;
		let eppNotProvided = 0;

		this.updateCurrentURLState();
		if (!this.session?.allTlds) {
			let tlds = [];
			categories.forEach(category => {
				const tmpTlds = category.tlds;
				tlds = {...tlds, ...tmpTlds};
			});
			this.session.allTlds = tlds;
		}
		const domainObjects = domainsWithEpp
			? Object.entries(domainsWithEpp)
					.map(domain => {
						if (domain.at(0)) {
							const tldRegex = /[.]{1}[A-Za-z]{2,}$/; // Matches the last dot followed by 2 or more letters
							const tld = domain[0].match(tldRegex)[0].substring(1);
							const tldNotRequireEppCode = Object.keys(
								Util.session.config.tldsWithoutEppCode,
							).includes(tld);
							let tldFound = false;
							if (tld) {
								tldFound = Object.keys(this.session.allTlds).includes(tld); // Exclude the dot from the result
							}
							if (!tldNotRequireEppCode && domain[1] === true) {
								eppNotProvided += 1;
							}

							return {
								domainName: domain[0],
								idnDomainName: domain[0],
								eppCode: domain[1] !== true ? domain[1] : tldNotRequireEppCode,
								domainPricing: [],
								shortestPeriod: [],
								isBaseDomain: true,
								isAvailable: false,
								tldSupported: tldFound,
								addToCart: false,
								domainTld: tld,
								domainStatus: tldFound ? 'registered' : 'tldnotsupported',
							};
						}
					})
					.filter(dom => dom !== undefined)
			: [];

		return {
			domainBaseList: domainObjects,
			domainSuggestionList: [],
			eppNotProvided: eppNotProvided,
		};
	}

	/**
	 * Trims the middle of a string and replaces it with "..." if the length of the string exceeds the specified length.
	 *
	 * @param {String} string
	 * @param {Number} length
	 * @returns String : the trimmed string
	 */
	static trimMiddleString(string, maxLength = 35, separator = ' ... ') {
		if (string.length <= maxLength) {
			return string;
		}

		const parts = string.split('.');
		const first = parts[0];
		const frontWeightage = 3; // higher shows less characters
		const backWeightage = 4;
		const frontChars = Math.ceil(maxLength / frontWeightage);
		const backChars = Math.floor(maxLength / backWeightage);

		const start = first.slice(0, frontChars);
		const end =
			first.slice(first.length - backChars) +
			'.' +
			parts.splice(1, parts.length - 1);

		return `${start}${separator}${end}`;
	}

	static initTooltip(element) {
		if (typeof bootstrap !== 'undefined') {
			jQuery(element).tooltip({
				selector: '[data-toggle=tooltip]',
				placement: 'left',
			});
			jQuery(element).popover({
				selector: '[data-toggle=popover]', // Define the selector for elements that trigger the popover
				trigger: 'hover | focus | manual',
				container: 'body',
				html: true,
				placement: 'auto',
				// Add any other popover options you need here
			});
		}
	}

	static async fetchTemplate(path) {
		if (/\./g.test(path)) {
			path = path.split('.');
			path = path[0];
		}

		const cacheKey = path + themeVersion;
		const cachedData = new UniqueObjectCache(cacheKey);

		// to enable/disable html file caching add/remove the comments below
		const htmlData = cachedData.findCacheObject(cacheKey, true);
		if (htmlData) {
			return htmlData;
		}
		// to enable/disable html file caching add/remove the comments above

		const response = await fetch(
			`${cnicSearchClientThemePath}html_components/${path}.html?version=${themeVersion}`,
		);
		const template = await response.text();
		cachedData.cacheObject(template, true);
		return template;
	}

	static async waitForElement(selector, element) {
		return new Promise(resolve => {
			const checkElement = () => {
				const targetElement = element.renderRoot?.querySelector(selector);
				if (targetElement) {
					resolve(targetElement);
				} else {
					requestAnimationFrame(checkElement);
				}
			};

			checkElement();
		});
	}
}

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class e extends i$1{constructor(i){if(super(i),this.et=w$1,i.type!==t$1.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(r){if(r===w$1||null==r)return this.vt=void 0,this.et=r;if(r===T$1)return r;if("string"!=typeof r)throw Error(this.constructor.directiveName+"() called with a non-string value");if(r===this.et)return this.vt;this.et=r;const s=[r];return s.raw=s,this.vt={_$litType$:this.constructor.resultType,strings:s,values:[]}}}e.directiveName="unsafeHTML",e.resultType=1;const o=e$2(e);

class Translations {
	static localize = null;
	static supportedLanguages = ['english', 'arabic', 'german', 'portuguese-br'];
	static defaultLanguage = 'english';
	static maxRetries = 10;

	static async loadTranslations(baseUrl, locale, retries = 0) {
		locale = Translations.supportedLanguages.includes(locale)
			? locale
			: Translations.defaultLanguage;

		const messageUrl = `${baseUrl}languages/${locale}.json?version=${themeVersion}`;

		try {
			const response = await fetch(messageUrl);

			if (!response.ok) {
				if (retries < Translations.maxRetries) {
					return Translations.loadTranslations(
						baseUrl,
						Translations.defaultLanguage,
						retries + 1,
					);
				} else {
					throw new Error('Failed to load translations');
				}
			}

			const messages = await response.json();

			Translations.localize = messages;
		} catch (error) {
			console.error(error);
		}
	}

	static getMessage(key, label, rawData) {
		if (!Translations.localize) {
			throw new Error('Translations not initialized');
		}

		key = key.replace(/\s/gi, '_', key).toLowerCase();
		const translation = Translations.localize[key];

		if (!translation || !translation.length) {
			return key;
		}

		if (rawData) {
			return translation;
		}

		if (!label) {
			return this.htmlWrapper(translation);
		}

		return this.replaceLabels(translation, label);
	}

	static replaceLabels(translation, label) {
		const regex = /##(\w+)##/gi;
		const replacedTranslation = translation.replace(
			regex,
			(match, keyword) =>
				label[keyword] || (typeof label !== 'object' ? label : match),
		);
		return this.htmlWrapper(replacedTranslation);
	}

	static htmlWrapper(text) {
		const htmlTagRegex = /<[^>]+>/g;
		if (!htmlTagRegex.test(text)) {
			return text;
		}
		return b$1`${o(text)}`;
	}
}

await Translations.loadTranslations(cnicSearchClientThemePath, activeLanguage);

const translation = Translations.localize;
const getMessage = (key, label = null, rawData = false) => {
	return Translations.getMessage(key, label, rawData);
};

class LoadCss {
	static async fetchCSS() {
		const style = await fetch(
			cnicFontawesomePath + '?version=' + themeVersion,
			{method: 'get'},
		);
		const fontStyle = await fetch(
			cnicSearchClientThemePath + '/css/style.css?version=' + themeVersion,
			{method: 'get'},
		);
		let cssText = '';

		if (style.ok && fontStyle.ok) {
			cssText += await fontStyle.text();
			cssText += await style.text();
		}

		return cssText;
	}

	static async init() {
		const cssData = await LoadCss.fetchCSS();
		return cssData;
	}
}

const cssData = await LoadCss.init();

class TopTabs extends s$1 {
	static properties = {
		tabs: {type: Array},
	};

	constructor() {
		super();
	}

	generateTabs() {
		return this.tabs.map(tab => {
			const id = 'tab-' + tab;
			const label = getMessage('tab_label_' + tab);
			const headingId = 'tabHeading-' + tab;
			const headingLabel = getMessage('tab_heading_' + tab);
			return {id, label, headingId, headingLabel, tab};
		});
	}

	render() {
		const bindings = {tabs: this.generateTabs()};

		return b$1`<load-template
			path="tabs"
			.bindings=${bindings}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('top-tabs', TopTabs);

class SearchEngine extends s$1 {
	static get styles() {
		return i$4`
			${r$3(cssData)}
		`;
	}

	static properties = {
		searchAction: {
			hasChanged(value, oldValue) {
				Util.session.searchAction = value;
				return value !== oldValue;
			},
		},
		searchConfig: {
			type: Object,
			hasChanged(value, oldValue) {
				return value !== oldValue;
			},
		},
		tabs: {},
		cacheInterval: {},
	};

	constructor() {
		super();
		this._clearCache();
		this.searchAction =
			Util.params.action?.length > 0 ? Util.params.action : 'home';
		this._loadConfiguration();
		this.addEventListener('cnicUrlUpdate', this._handleCnicUrlUpdate);
	}

	connectedCallback() {
		super.connectedCallback();
		this.startCacheClearInterval();
	}

	disconnectedCallback() {
		super.disconnectedCallback();
		this.stopCacheClearInterval();
	}

	startCacheClearInterval() {
		this.cacheInterval ??= setInterval(async () => {
			const domainCache = new UniqueObjectCache('CachedDomainList');
			domainCache.clearCache();
			delete Util.session?.allTlds;
			const configDataPromise = await Util.fetchData({type: 'clearCache'});
			await Promise.all(configDataPromise);
			// this.requestUpdate(); // Trigger a re-render to update the displayed count
		}, 1800000); // Interval of 30 minutes (1800000 milliseconds)
	}

	stopCacheClearInterval() {
		clearInterval(this.cacheInterval);
	}

	_handleCnicUrlUpdate() {
		this.searchAction =
			Util.params.action?.length > 0 ? Util.params.action : 'home';
		this.updateTabs();
	}

	_clearCache() {
		delete Util.session.searchTerm;
		delete Util.session.searchAction;
		delete Util.session.searchPage;
		delete Util.session.lastResult;
		delete Util.session.totalResults;
		delete Util.session.domainList;
		delete Util.session.config;
	}

	_onTabChange(event) {
		this.searchAction = event.target.value;
		Util.params.action = this.searchAction;
		this.updateTabs();
	}

	/**
	 * This function updates the tabs and highlights the selected one
	 * It finds the tabsSwitchIndicator div and sets its width and left properties to fit the selected tab
	 * It then finds all the tabHeadings and hides the ones that do not correspond to the selected tab
	 * and unhides the one that does.
	 */
	updateTabs(selectedTab = null) {
		const indicator = this.renderRoot?.querySelector('div#tabsSwitchIndicator');
		if (indicator) {
			// Get the selected tab and its width and left properties
			selectedTab ??= this.renderRoot.querySelector(
				`[id$=tab-${this.searchAction}]`,
			);
			selectedTab.checked = true;
			// Set the width and left properties of the indicator to fit the selected tab
			const {offsetWidth, offsetLeft} = selectedTab.labels[0];
			indicator.style.width = `${parseInt(offsetWidth)}px`;
			indicator.style.left = `${parseInt(offsetLeft)}px`;

			// Hide all tabHeadings that do not correspond to the selected tab and unhide the one that does
			Array.from(
				this.renderRoot.querySelectorAll("[id^='tabHeading']"),
			).forEach(pill => {
				if (pill.id.includes(this.searchAction)) {
					pill.removeAttribute('hidden');
				} else {
					pill.setAttribute('hidden', true);
				}
			});
		}
	}

	async _loadConfiguration() {
		// Fetch config if not already present in the session
		if (
			!Util.session?.config ||
			Object.keys(Util.session?.config).length === 0
		) {
			const configDataPromise = await Util.fetchData({type: 'config'});
			const [resolvedConfigData] = await Promise.all(configDataPromise);
			Util.session.config = resolvedConfigData;
			if (Util.session.config?.cartData) {
				Util.session.cartList = Util.session.config.cartData;
			}
		}

		{
			const tldsRegisterPricePromise = await Util.fetchData({
				type: 'tldsPricing',
				request: 'register',
			});
			const tldsRenewPricePromise = await Util.fetchData({
				type: 'tldsPricing',
				request: 'renew',
			});
			Promise.all(tldsRegisterPricePromise).then(data => {
				[Util.session.tldsRegisterPricing] = data;
			});
			Promise.all(tldsRenewPricePromise).then(data => {
				[Util.session.tldsRenewPricing] = data;
			});
		}

		// Extract relevant configuration options
		const {features} = Util.session.config;
		this.searchConfig = Util.session.config;
		const actions = {
			home:
				(this.searchConfig.spotlightTlds?.length && features?.Home) ?? false,
			register: features?.RegularSearch ?? true,
			suggestions: features?.Suggestions ?? false,
			transfer: features?.BulkTransfers ?? false,
			whois: features?.WhoIs ?? false,
		};

		// Set default search action if current one not found
		if (!actions[this.searchAction]) {
			this.searchAction = 'register';
		}

		// Set tabs based on available actions
		this.tabs = Object.keys(actions).filter(action => actions[action]);

		const selectedTab = await Util.waitForElement(
			`#tab-${this.searchAction}`,
			this,
		);
		if (selectedTab) {
			this.updateTabs(selectedTab);
		}
	}

	mainHeader() {
		return b$1`<load-template path="main-header"></load-template>`;
	}

	mainSearchContainer() {
		const {searchAction, searchConfig, tabs = []} = this;
		const tabContainers = tabs.map(tab => {
			const showContainer = searchAction === tab;
			if (tab === 'whois') {
				return b$1`<whois-container
					.showContainer=${showContainer}
					.searchConfig=${searchConfig}
				></whois-container>`;
			} else if (tab === 'home') {
				return b$1`<home-container
					.showContainer=${showContainer}
					.searchConfig=${searchConfig}
				></home-container>`;
			}

			return b$1`<search-container
				searchAction=${tab}
				.showContainer=${showContainer}
				.searchConfig=${searchConfig}
			></search-container>`;
		});

		return b$1`
			<top-tabs .tabs=${tabs} @change=${this._onTabChange}></top-tabs>
			${tabContainers}
		`;
	}

	mainFooter() {
		return b$1`<load-template path="main-footer"></load-template>`;
	}

	render() {
		if (!translation || !this.searchAction || !this.searchConfig) {
			return;
		}

		if (!this.searchConfig.lookupprovider) {
			return b$1`<load-template
				path="error-lookup-provider.html"
			></load-template>`;
		}

		return b$1`
			${this.mainHeader()} ${this.mainSearchContainer()} ${this.mainFooter()}
		`;
	}
}

customElements.define('search-engine', SearchEngine);

class Search extends s$1 {
	static properties = {
		showContainer: {type: Boolean},
		showSpotlightTlds: {type: Boolean},
		searchResultsAvailable: {type: Boolean},
		searchConfig: {
			type: Object,
			hasChanged(val, oldVal) {
				return val !== oldVal;
			},
		},
		searchPage: {
			type: Number,
			hasChanged(val, oldVal) {
				Util.session.searchPage = val;
				return val !== oldVal;
			},
		},
		totalSuggestionResults: {type: Number},
		lastResults: {type: Number},
		totalUnavailableDomains: {type: Number},
		data: {type: Object},
		totalResultsRaw: {type: Object},
		lastResultsRaw: {type: Object},
		cartData: {type: Object},
		searchToggleBtns: {
			type: Array,
			hasChanged(val, oldVal) {
				if (val !== undefined && val.length > 0) {
					Util.session.filters = val;
				}
				return val !== oldVal;
			},
		},
		domainBaseList: {type: Array},
		domainSuggestionList: {type: Array},
		errorMessages: {type: Array},
		searchAction: {type: String},
		searchEventName: {type: String},
		containerId: {type: String},
		searchTerm: {type: String},
		sortBy: {type: String, state: true},
		lastWindowScrollPosition: {type: Number, state: true},
		lastContentsScrollPosition: {type: Number, state: true},
	};

	constructor() {
		super();
		this.domainSuggestionList = [];
		this.domainBaseList = [];
		this.errorMessages = [];
		this.searchPage = 1;
		this.searchTerm = Util.session.searchTerm || '';
		this.searchResultsAvailable = true;
		this.showSpotlightTlds = false;
		this.containerId = `div${Date.now()}`;
		this.sortBy = Util.params?.sort;
		this.searchTerm =
			Util.params.searchTerm?.length > 0 &&
			Util.params.searchTerm.trim() !== 'undefined'
				? Util.params.searchTerm
				: this.searchTerm;
		this.addEventListener('cnicDomainFilters', this._searchFilters);
		this.addEventListener('cnicDomainSearch', this._searchHandler);
	}

	updated(changed) {
		if (changed.has('searchConfig')) {
			this._searchFilters();
			this.showSpotlightTlds = this.searchConfig.showContainerSpotlight;
		}

		if (changed.has('showContainer') && this.showContainer) {
			let contentsLazyLoad = this.renderRoot?.querySelector(
				`#${this.containerId}`,
			);
			if (contentsLazyLoad) {
				contentsLazyLoad.addEventListener(
					'scroll',
					event => this._handleContentsLazyLoadScroll(event),
					{passive: true},
				);
			}
		}

		if (
			changed.has('showContainer') &&
			this.showContainer &&
			Util.params.referrer === 'whmcs'
		) {
			this._searchHandler();
		}

		Util.initTooltip(this.renderRoot);
		this._scrollToLastPosition();
	}

	_scrollToLastPosition() {
		const element = this.renderRoot?.querySelector(`#${this.containerId}`);
		if (element && this.searchResultsAvailable && this.showContainer) {
			element.scrollTop = this.lastContentsScrollPosition;
			window.scroll(0, this.lastWindowScrollPosition + 1);
			window.scrollTo({
				top: this.lastContentsScrollPosition,
				behavior: 'smooth',
			});
		}
	}

	_handleContentsLazyLoadScroll(event) {
		const contentsLazyLoad = event.target;
		const {scrollTop, scrollHeight, clientHeight} = contentsLazyLoad;

		// GUARD: If element is not scrollable, remove all classes
		const isScrollable = scrollHeight > clientHeight;

		if (!isScrollable) {
			contentsLazyLoad.classList.remove(
				'is-bottom-overflowing',
				'is-top-overflowing',
			);
			return;
		}
		const isScrolledToBottom = scrollHeight - 50 <= clientHeight + scrollTop;
		const isScrolledToTop = scrollTop <= 50;

		contentsLazyLoad.classList.toggle(
			'is-bottom-overflowing',
			!isScrolledToBottom,
		); // bottom fade styling class
		contentsLazyLoad.classList.toggle('is-top-overflowing', !isScrolledToTop); // top fade styling class

		if (
			isScrolledToBottom &&
			this._totalItemsInList() &&
			this.searchResultsAvailable
		) {
			this._searchHandler({type: 'cnicDomainSearchLoadMore'});
		}
	}

	_isValidContainer(tab = 'register') {
		return this.searchAction === tab;
	}

	_totalItemsInList(info = {}) {
		if (this._isValidContainer()) {
			this.lastResults = Util.session.lastResult;
			this.totalSuggestionResults = Util.session.totalResults;

			return this.totalSuggestionResults > this.lastResults;
		}

		if (info?.last || info?.total) {
			const lastResultValues = Object.values(info.last);
			const totalResultsValues = Object.values(info.total) || 0;

			this.lastResultsRaw = info?.last || 0;
			this.totalResultsRaw = info?.total || 0;
			this.lastResults = lastResultValues.reduce(
				(accumulator, currentValue) => accumulator + parseInt(currentValue),
				0,
			);
			this.totalSuggestionResults = totalResultsValues.reduce(
				(accumulator, currentValue) => accumulator + parseInt(currentValue),
				0,
			);
		}

		return this.totalSuggestionResults > this.lastResults;
	}

	async _searchHandler(e) {
		const searchType = e?.type ?? 'cnicDomainSearch';
		const searchTerm = e?.detail?.searchTerm ?? this.searchTerm;
		this.lastWindowScrollPosition = window.scrollY;
		this.lastContentsScrollPosition = this.renderRoot?.querySelector(
			`#${this.containerId}`,
		).scrollTop;
		try {
			const errors = [];

			// Toggle boolean values
			this.searchResultsAvailable = false;
			this.showSpotlightTlds = false;

			// Handle different search events
			if (searchType === 'cnicDomainSearch') {
				this._resetSearchSession();
				this.searchTerm = searchTerm;
				this.searchPage = 1;
			} else if (searchType === 'cnicDomainSearchLoadMore') {
				this.searchPage++;
			}

			// Check search term length
			if (this.searchTerm.length > 63 && this.searchAction !== 'transfer') {
				errors.push('error_keywordlength');
			}

			// Fetch data from API
			const result = await Util.fetchData({
				type: searchType,
				searchAction: this.searchAction,
				searchTerm: this.searchTerm,
				searchPage: this.searchPage,
				lastResults: this.lastResultsRaw,
				totalResults: this.totalResultsRaw,
			});

			// Process result data
			for (const data of result) {
				// Build data list
				const domainsList = Util.buildDomainList(
					await data,
					this.searchAction,
					this.searchTerm,
				);

				// Add domain lists to base and suggestion lists
				if (
					domainsList?.domainBaseList.length ||
					domainsList?.domainSuggestionList.length
				) {
					this.domainBaseList.push(...domainsList.domainBaseList);
					this.domainSuggestionList.push(...domainsList.domainSuggestionList);
				}

				// Calculate total number of items in list
				this._totalItemsInList(domainsList?.info);

				// Handle registration action
				if (this._isValidContainer()) {
					Util.getCachedDomains(
						this.domainBaseList,
						this.searchPage,
						'baseList',
					);
					Util.getCachedDomains(
						this.domainSuggestionList,
						this.searchPage,
						'suggestionList',
					);

					this.domainSuggestionList = this.domainSuggestionList
						.map(domain => {
							const checkDomainExistsInBaseList = Util.findValueInArray(
								this.domainBaseList,
								domain.domainName,
								'domainName',
							);
							if (checkDomainExistsInBaseList) {
								return null;
							}
							const findOrder = Util.findValueInArray(
								Util.session.domainList,
								domain,
								'suggest',
							);
							return Object.assign({order: findOrder.order}, domain);
						})
						.filter(item => item !== null);
				}

				// Finalize error checking and update UI
				if (result.indexOf(data) === result.length - 1) {
					this.searchResultsAvailable = !this.searchResultsAvailable;
					this.totalUnavailableDomains = this.domainSuggestionList.filter(
						domain => !domain.isAvailable,
					).length;
					const totalResults =
						(this.domainSuggestionList?.length || 0) +
						(this.domainBaseList?.length || 0);

					if (
						this.searchAction === 'transfer' &&
						(!domainsList?.domainBaseList.length ||
							domainsList?.eppNotProvided > 0)
					) {
						errors.push('error_noAuthCodeProvided');
					}

					if (totalResults === 0 && this.searchAction !== 'transfer') {
						errors.push('error_noResultsFound');
					}

					if (this.totalUnavailableDomains > 0) {
						errors.push('error_domainUnavailable');
					}

					this.errorMessages = errors;
				}
			}
		} catch (error) {
			console.error(error);
		}
	}

	_domainListItem(domains) {
		if (domains.length === 0) {
			return [];
		}

		domains.sort(Util.sortDomainByOrder);
		const cartData = Util.session.cartList;
		return domains.map(domain => {
			let addToCart = domain.addToCart;
			let cartItemType = domain.cartItemType;
			let registerPeriod = parseInt(domain.registerPeriod) || 0;
			let isAvailable = domain.isAvailable;
			// Check if domain is in the cart
			Object.keys(cartData).forEach(key => {
				if (key === domain.idnDomainName || key === domain.domainName) {
					addToCart = true;
					cartItemType = cartData[key].type || 'register';
					registerPeriod = parseInt(cartData[key].regperiod);
				}
			});
			return b$1`
				<domain-list-item
					domainName=${domain.domainName}
					domainStatus=${domain.domainStatus}
					domainGroup=${domain.domainGroup}
					idnDomainName=${domain.idnDomainName}
					domainTld=${domain.tld}
					.domainEppCode=${domain.eppCode}
					cartItemType=${cartItemType}
					.addToCart=${addToCart}
					.itemInCartSession=${addToCart === true}
					.registerPeriod=${registerPeriod}
					.isBaseDomain=${domain.isBaseDomain}
					.domainPricing="${domain.domainPricing}"
					.isAvailable=${isAvailable}
					.tldSupported=${domain.tldSupported}
					.availabilityReason=${domain.availabilityReason}
					.isPremium=${domain.isPremium}
					.isAftermarket=${domain.isAftermarket}
					.searchToggleBtns=${this.searchToggleBtns}
				>
				</domain-list-item>
			`;
		});
	}

	_resetSearchSession() {
		if (this._isValidContainer()) {
			delete Util.session.lastResult;
			delete Util.session.totalResults;
			delete Util.session.domainList;
		}
		delete Util.session.searchPage;
		this.domainSuggestionList = [];
		this.domainBaseList = [];
		this.errorMessages = [];
		this.lastResults = 0;
		this.totalSuggestionResults = 0;
	}

	/**
	 * Updates the search filter buttons based on the filter settings passed in the event detail
	 *
	 * @param {Event} el
	 */
	_searchFilters(el) {
		// Get the filters from the event detail if present, or from the session if not
		const filters = el?.detail.filters || Util.session?.filters || [];

		// Initialize an array to store the buttons
		const btns = [];

		// Add default filters if no filters are present
		if (!filters.length) {
			if (this.searchConfig.showTakenDomains) {
				filters.push({type: 'unavailable', show: true});
			}
			if (this.searchConfig.showPremiumDomains) {
				filters.push({type: 'premiums', show: true});
				filters.push({type: 'aftermarket', show: true});
			}
		}

		// Add an "unavailable" filter if it doesn't exist
		if (!filters.some(filter => filter.type === 'unavailable')) {
			filters.push({type: 'unavailable', show: false});
		}

		// Add applicable filters to the buttons array
		for (const filter of filters) {
			if (
				filter.type === 'unavailable' ||
				filter.type === 'filterType' ||
				(filter.type === 'premiums' && this.searchConfig.showPremiumDomains) ||
				(filter.type === 'aftermarket' && this.searchConfig.showPremiumDomains)
			) {
				btns.push(filter);
			}
		}

		// Update the search toggle buttons with the new array of buttons
		this.searchToggleBtns = btns;
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		return b$1`
			<domain-input
				searchAction=${this.searchAction}
				.searchTerm=${this.searchTerm}
				.searchPage=${this.searchPage}
				.searchResultsAvailable=${this.searchResultsAvailable}
				.totalUnavailableDomains=${this.totalUnavailableDomains}
				.searchConfig=${this.searchConfig}
				.searchToggleBtns=${this.searchToggleBtns}
			>
			</domain-input>
			<search-container-info-box
				.errorMessages=${this.errorMessages}
			></search-container-info-box>
			<spotlight-tlds
				.spotlightTlds=${this.searchConfig.spotlightTlds}
				.showContainer=${this.showSpotlightTlds}
			></spotlight-tlds>
			<data-list
				.data="${{
					sorting: b$1`<data-sorting
						.searchTerm=${this.searchTerm}
						.showContainer=${this._isValidContainer() &&
						this.domainSuggestionList?.length > 0}
					></data-sorting>`,
					checkout: b$1`<data-list
						.isHidden=${!this.totalSuggestionResults ||
						this.totalSuggestionResults <= 0}
						template="Container/Search/checkout-btn"
					></data-list>`,
				}}"
				template="Container/Search/head"
			></data-list>
			<div class="contentsLazyLoad" id=${this.containerId}>
				<data-list
					data="~${this.totalSuggestionResults} results"
					template="Container/Search/header"
					.isHidden=${!this.totalSuggestionResults ||
					this.totalSuggestionResults <= 0}
				></data-list>
				<data-list
					.data=${this._domainListItem(this.domainBaseList)}
					template="Container/Search/base-list"
					.isHidden=${!this.domainBaseList.length}
				></data-list>
				<data-list
					.data=${this._domainListItem(this.domainSuggestionList)}
					template="Container/Search/suggestion-list"
					.isHidden=${!this.domainSuggestionList.length}
				></data-list>
				<loading-domain-list
					.searchResultsAvailable=${this.searchResultsAvailable}
				></loading-domain-list>
			</div>
			<load-more-button
				@cnicDomainSearchLoadMore=${this._searchHandler}
				.totalResults=${this.totalSuggestionResults}
				.lastResults=${this.lastResults}
				.searchResults=${this.searchResultsAvailable}
				datatype="loadmore"
			>
			</load-more-button>
		`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('search-container', Search);

class Home extends s$1 {
	static properties = {
		showContainer: {type: Boolean},
		searchConfig: {type: Object},
		containerId: {type: String},
		containerContent: {type: Object},
	};

	constructor() {
		super();
		this.containerId = `div${Date.now()}`;
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		return b$1`
			<div id=${this.containerId} class="container">
				<domain-promotions
					.searchConfig=${this.searchConfig}
				></domain-promotions>
				<spotlight-tlds
					.spotlightTlds=${this.searchConfig.spotlightTlds}
					.showContainer=${this.showContainer}
					tldBoxWidth="300px"
				></spotlight-tlds>
			</div>
		`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('home-container', Home);

class Whois extends s$1 {
	static properties = {
		showContainer: {type: Boolean},
		searchResultsAvailable: {type: Boolean},
		searchConfig: {type: Object},
		containerId: {type: String},
		containerContent: {type: Object},
		searchTerm: {type: String},
	};

	constructor() {
		super();
		this.searchResultsAvailable = true;
		this.containerId = `div${Date.now()}`;
		this.searchTerm = '';
	}

	updated(changed) {
		if (!this.showContainer) {
			return;
		}

		this.searchTerm =
			Util.params.searchTerm?.length > 0
				? Util.params.searchTerm
				: this.searchTerm;
		if (changed.has('searchTerm') && this.searchTerm) {
			if (this.searchResultsAvailable) {
				this._searchHandler();
			}
		}
	}

	async _searchHandler(e) {
		this.searchResultsAvailable = !this.searchResultsAvailable;
		this.containerContent = b$1`<loading-domain-list></loading-domain-list>`;

		if (e?.detail?.searchTerm) {
			this.searchTerm = e.detail.searchTerm;
			Util.params.searchTerm = this.searchTerm;
		}

		const [domain] = Util.getPunyCodeName(this.searchTerm, false);
		const url = `${cnicWebRootPath}/mywhois.php?domain=${domain.exact}`;
		const response = await fetch(url);

		if (response.ok) {
			const textContent = await response.text();
			const parser = new DOMParser();
			const body = parser
				.parseFromString(textContent, 'text/html')
				.querySelector('body');
			const innerHTML = body.innerHTML.replace(/\<br\>/g, '\n');
			this.containerContent = new Function(
				'html',
				'return html`' + innerHTML + '`',
			)(b$1);
			this.searchResultsAvailable = !this.searchResultsAvailable;
		}
	}

	render() {
		if (!this.showContainer) {
			return;
		}
		const bindings = {
			containerId: this.containerId,
			containerContent: this.containerContent,
		};

		return b$1`
			<domain-input
				@cnicDomainSearch=${this._searchHandler}
				searchAction="whois"
				.searchTerm=${this.searchTerm}
				.searchResultsAvailable=${this.searchResultsAvailable}
				.searchConfig=${this.searchConfig}
			>
			</domain-input>
			<load-template
				path="Container/whois"
				.bindings=${bindings}
			></load-template>
		`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('whois-container', Whois);

class ComboBox {
	selectedEl = {};
	el = {};
	inputEl = {};
	options = {};
	listboxEl = {};
	idBase = '';
	activeIndex = 0;
	open = false;
	_selectedIndex = [];
	Keys = {
		Backspace: 'Backspace',
		Clear: 'Clear',
		Down: 'ArrowDown',
		End: 'End',
		Enter: 'Enter',
		Escape: 'Escape',
		Home: 'Home',
		Left: 'ArrowLeft',
		PageDown: 'PageDown',
		PageUp: 'PageUp',
		Right: 'ArrowRight',
		Space: ' ',
		Tab: 'Tab',
		Up: 'ArrowUp',
	};

	MenuActions = {
		Close: 0,
		CloseSelect: 1,
		First: 2,
		Last: 3,
		Next: 4,
		Open: 5,
		Previous: 6,
		Select: 7,
		Space: 8,
		Type: 9,
	};

	// filter an array of options against an input string
	// returns an array of options that begin with the filter string, case-independent
	filterOptions(options = [], filter, exclude = []) {
		return options.filter(option => {
			const matches = option.toLowerCase().indexOf(filter.toLowerCase()) === 0;
			return matches && exclude.indexOf(option) < 0;
		});
	}

	// return an array of exact option name matches from a comma-separated string
	findMatches(options, search) {
		const names = search.split(',');
		return names
			.map(name => {
				const match = options.filter(
					option => name.trim().toLowerCase() === option.toLowerCase(),
				);
				return match.length > 0 ? match[0] : null;
			})
			.filter(option => option !== null);
	}

	// return combobox action from key press
	getActionFromKey(event, menuOpen) {
		const {key, altKey, ctrlKey, metaKey} = event;
		// handle opening when closed
		if (
			!menuOpen &&
			(key === this.Keys.Down ||
				key === this.Keys.Enter ||
				key === this.Keys.Space)
		) {
			return this.MenuActions.Open;
		}

		// handle keys when open
		if (key === this.Keys.Down) {
			return this.MenuActions.Next;
		} else if (key === this.Keys.Up) {
			return this.MenuActions.Previous;
		} else if (key === this.Keys.Home) {
			return this.MenuActions.First;
		} else if (key === this.Keys.End) {
			return this.MenuActions.Last;
		} else if (key === this.Keys.Escape) {
			return this.MenuActions.Close;
		} else if (key === this.Keys.Enter) {
			return this.MenuActions.CloseSelect;
		} else if (key === this.Keys.Space) {
			return this.MenuActions.Space;
		} else if (
			key === this.Keys.Backspace ||
			key === this.Keys.Clear ||
			(key.length === 1 && !altKey && !ctrlKey && !metaKey)
		) {
			return this.MenuActions.Type;
		}
	}

	// get index of option that matches a string
	getIndexByLetter(options, filter) {
		const firstMatch = this.filterOptions(options, filter)[0];
		return firstMatch ? options.indexOf(firstMatch) : -1;
	}

	// get updated option index
	getUpdatedIndex(current, max, action) {
		switch (action) {
			case this.MenuActions.First:
				return 0;
			case this.MenuActions.Last:
				return max;
			case this.MenuActions.Previous:
				return Math.max(0, current - 1);
			case this.MenuActions.Next:
				return Math.min(max, current + 1);
			default:
				return current;
		}
	}

	// check if an element is currently scrollable
	isScrollable(element) {
		return element && element.clientHeight < element.scrollHeight;
	}

	// ensure given child element is within the parent's visible scroll area
	maintainScrollVisibility(activeElement, scrollParent) {
		const {offsetHeight, offsetTop} = activeElement;
		const {offsetHeight: parentOffsetHeight, scrollTop} = scrollParent;

		const isAbove = offsetTop < scrollTop;
		const isBelow = offsetTop + offsetHeight > scrollTop + parentOffsetHeight;

		if (isAbove) {
			scrollParent.scrollTo(0, offsetTop);
		} else if (isBelow) {
			scrollParent.scrollTo(0, offsetTop - parentOffsetHeight + offsetHeight);
		}
	}

	constructor(options, selectedEl) {
		// element refs
		this.el = selectedEl.querySelector('.cnic-multiselect');
		this.inputEl = this.el.querySelector('input#tldCategories');
		this.listboxEl = this.el.querySelector('.combo-menu');
		this.idBase = this.inputEl.id;
		this.selectedEl = this.el.querySelector('#tldCategories-selected');
		// data
		this.options = options;
		this._selectedIndex = Util.session.selectedTldCategories ?? [];
		// state
		this.activeIndex = 0;
		this.open = false;
		this.init();
	}

	init() {
		this.inputEl.addEventListener('input', this.onInput.bind(this));
		this.inputEl.addEventListener('blur', this.onInputBlur.bind(this));
		this.inputEl.addEventListener('click', () => this.updateMenuState(true));
		this.inputEl.addEventListener('keydown', this.onInputKeyDown.bind(this));
		this.listboxEl.addEventListener('blur', this.onInputBlur.bind(this));
		const selectIndexLength = this._selectedIndex?.length;
		this.options.map((option, index) => {
			const optionEl = document.createElement('div');
			optionEl.setAttribute('role', 'option');
			optionEl.id = `${this.idBase}-${index}`;
			optionEl.className =
				index === 0 ? 'combo-option option-current' : 'combo-option';
			optionEl.setAttribute('aria-selected', 'false');
			optionEl.innerHTML =
				(option?.icon?.length
					? `<i class="fas fa-${option.icon}"></i>&nbsp;`
					: '') + option.name;
			optionEl.addEventListener('click', () => {
				this.onOptionClick(index);
			});
			optionEl.addEventListener('mousedown', this.onOptionMouseDown.bind(this));
			this.listboxEl.appendChild(optionEl);
			if (
				!selectIndexLength &&
				!this._selectedIndex.includes(option.id) &&
				option.default
			) {
				this._selectedIndex.push(option.id);
				Util.session.selectedTldCategories = this._selectedIndex;
				delete Util.session.sortedTlds;
			}
		});
		if (this._selectedIndex) {
			this._selectedIndex.forEach((option, index) => {
				if (option && !isNaN(option)) {
					option = this.options.find(op => op.id === option);
					this.selectOption(this.options.indexOf(option));
				}
			});
		}
	}

	onInput() {
		const curValue = this.inputEl.value;
		const matches = this.filterOptions(this.options, curValue);

		// set activeIndex to first matching option
		// (or leave it alone, if the active option is already in the matching set)
		const filterCurrentOption = matches.filter(
			option => option === this.options[this.activeIndex],
		);
		if (matches.length > 0 && !filterCurrentOption.length) {
			this.onOptionChange(this.options.indexOf(matches[0]));
		}

		const menuState = this.options.length > 0;
		if (this.open !== menuState) {
			this.updateMenuState(menuState, false);
		}
	}

	onInputKeyDown(event) {
		const max = this.options.length - 1;

		const action = this.getActionFromKey(event, this.open);

		switch (action) {
			case this.MenuActions.Next:
			case this.MenuActions.Last:
			case this.MenuActions.First:
			case this.MenuActions.Previous:
				event.preventDefault();
				return this.onOptionChange(
					getUpdatedIndex(this.activeIndex, max, action),
				);
			case this.MenuActions.CloseSelect:
				event.preventDefault();
				return this.updateOption(this.activeIndex);
			case this.MenuActions.Close:
				event.preventDefault();
				return this.updateMenuState(false);
			case this.MenuActions.Open:
				return this.updateMenuState(true);
		}
	}

	onInputBlur() {
		if (this.ignoreBlur) {
			this.ignoreBlur = false;
			return;
		}

		if (this.open) {
			this.updateMenuState(false, false);
		}
	}

	onOptionChange(index) {
		this.activeIndex = index;
		this.inputEl.setAttribute(
			'aria-activedescendant',
			`${this.idBase}-${index}`,
		);
		// update active style
		const options = this.el.querySelectorAll('[role=option]');
		[...options].forEach(optionEl => {
			optionEl.classList.remove('option-current');
		});
		options[index].classList.add('option-current');

		if (this.open && this.isScrollable(this.listboxEl)) {
			this.maintainScrollVisibility(options[index], this.listboxEl);
		}
	}

	onOptionClick(index) {
		this.onOptionChange(index);
		this.updateOption(index);
		this.inputEl.focus();
	}

	onOptionMouseDown() {
		this.ignoreBlur = true;
	}

	removeOption(index) {
		const option = this.options[index];
		// update aria-selected
		const options = this.el.querySelectorAll('[role=option]');
		options[index].setAttribute('aria-selected', 'false');
		options[index].classList.remove('option-selected');

		// remove button
		const buttonEl = this.selectedEl.querySelector(
			`#${this.idBase}-remove-${index}`,
		);
		this.selectedEl.removeChild(buttonEl.parentElement);
		this._selectedIndex.splice(this._selectedIndex.indexOf(option.id), 1);
		Util.session.selectedTldCategories = this._selectedIndex;
		delete Util.session.sortedTlds;
	}

	selectOption(index) {
		if (index < 0) {
			return;
		}
		const selected = this.options[index];
		this.activeIndex = index;
		const inputElement = this.el.querySelector('input');
		inputElement.setAttribute('placeholder', '');

		// resizing to fit selected categories contents
		let tldCategoriesHeight = this.el.querySelector(
			'#tldCategories-selected',
		).clientHeight;
		tldCategoriesHeight =
			inputElement.clientWidth > 1000
				? tldCategoriesHeight + 25
				: tldCategoriesHeight;
		inputElement.setAttribute('style', `height: ${tldCategoriesHeight}px`);

		// update aria-selected
		const options = this.el.querySelectorAll('[role=option]');
		options[index].setAttribute('aria-selected', 'true');
		options[index].classList.add('option-selected');

		// add remove option button
		const buttonEl = document.createElement('button');
		const listItem = document.createElement('li');
		buttonEl.className = 'remove-option';
		buttonEl.type = 'button';
		buttonEl.id = `${this.idBase}-remove-${index}`;
		buttonEl.setAttribute('aria-describedby', `${this.idBase}-remove`);
		buttonEl.setAttribute('data-id', selected.id);
		buttonEl.addEventListener('click', () => {
			this.removeOption(index);
		});
		buttonEl.innerHTML = `<i class="fas fa-${selected.icon}"> ${selected.name} `;
		listItem.appendChild(buttonEl);
		this.selectedEl.appendChild(listItem);
		this.updateMenuState(false);
		if (!this._selectedIndex.includes(selected.id)) {
			this._selectedIndex.push(selected.id);
			Util.session.selectedTldCategories = this._selectedIndex;
			delete Util.session.sortedTlds;
		}
	}

	updateOption(index) {
		this.options[index];
		const optionEl = this.el.querySelectorAll('[role=option]')[index];
		const isSelected = optionEl.getAttribute('aria-selected') === 'true';

		if (isSelected) {
			this.removeOption(index);
		} else {
			this.selectOption(index);
		}
		this.inputEl.value = '';
	}

	updateMenuState(open, callFocus = true) {
		this.open = open;

		this.inputEl.setAttribute('aria-expanded', `${open}`);
		open ? this.el.classList.add('open') : this.el.classList.remove('open');
		callFocus && this.inputEl.focus();
	}
}

class LoadHtmlTemplate extends s$1 {
	static properties = {
		template: {},
		path: {type: String},
		bindings: {type: Array},
	};

	constructor() {
		super();
		this.template = '';
	}

	async firstUpdated() {
		if (Util.params?.action === 'register') {
			const selector = await Util.waitForElement(`#tldCategories`, this);
			if (selector && this.bindings?.tldCategories) {
				new ComboBox(this.bindings.tldCategories, this.renderRoot);
			}
		}
	}

	updated() {
		Util.initTooltip(this);
	}

	async connectedCallback() {
		super.connectedCallback();
		this.template = await Util.fetchTemplate(this.path);
	}

	render() {
		if (!this.template) {
			return b$1`<div
				class="Box-paddingX-small_2LJQE Box-paddingLeft-small_1mVBq Box-paddingRight-small_Mw0L5 Box-paddingY-xsmall_34kFF Box-paddingTop-xsmall_22Udt Box-paddingBottom-xsmall_15dmU Box-backgroundColor-white_3LQ-e Flex-flex_uh_R2 PlaceholderRow-root__z9Q6b Box-gap-xsmall_1_DKb Flex-flex_uh_R2 Flex-flexJustifyEnd_1I0qk Flex-flexAlignItemsCenter_3oJ12"
			>
				<span
					class="Placeholder-root_G1eL2 Placeholder-effect_1YLEe"
					style="min-width: 3ch;"
				></span>
			</div>`;
		}

		const dynamicTemplate = new Function(
			'bindings',
			'html',
			'getMessage',
			'return html`' + this.template + '`',
		)(this.bindings, b$1, getMessage);

		return b$1`${dynamicTemplate}`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('load-template', LoadHtmlTemplate);

class SearchContainerInfoBox extends s$1 {
	static properties = {
		errorMessages: {type: Array},
	};

	constructor() {
		super();
	}

	get messages() {
		const messages = this.errorMessages
			.map(type => {
				return b$1`<p>${getMessage(type)}</p>`;
			})
			.filter(messages => messages !== undefined);
		return {message: b$1`${messages}`};
	}

	render() {
		if (!this.errorMessages.length) {
			return;
		}

		return b$1`<load-template
			path="Container/infobox"
			.bindings=${this.messages}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('search-container-info-box', SearchContainerInfoBox);

class LoadMoreBtn extends s$1 {
	static properties = {
		searchTerm: {},
		searchAction: {},
		searchPage: {},
		searchResults: {reflect: true},
		datatype: {},
		totalResults: {reflect: true},
		lastResults: {reflect: true},
	};

	constructor() {
		super();
	}

	_loadMore() {
		if (this.searchResults) {
			this.searchResults = !this.searchResults;
			let loaderEvent = new Event('cnicDomainSearchLoadMore', {
				bubbles: true,
				composed: true,
			});
			this.dispatchEvent(loaderEvent);
		}
	}

	render() {
		const bindings = {
			spinner: b$1`<load-template
				path="LoadMore/spinner-icon"
			></load-template>`,
		};

		if (this.datatype && this.datatype.match(/search/gi)) {
			if (!this.searchResults) {
				return b$1`<load-template
					path="LoadMore/spinner-icon"
				></load-template>`;
			}
			return b$1`<load-template
				path="InputSearch/search-button"
				.bindings=${bindings}
			></load-template>`;
		} else if (
			this.datatype &&
			this.datatype.match(/loadmore/gi) &&
			this.totalResults > this.lastResults
		) {
			if (!this.searchResults) {
				return b$1`<load-template
					?disabled=${!this.searchResults}
					path="LoadMore/spinner-btn"
					.bindings=${bindings}
				></load-template>`;
			} else if (this.searchResults) {
				return b$1`<load-template
					path="LoadMore/button"
					@click=${this._loadMore}
					.bindings=${bindings}
				></load-template>`;
			}
		}
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('load-more-button', LoadMoreBtn);

class DomainPromotions extends s$1 {
	static properties = {
		searchConfig: {type: Object},
		showContainer: {type: Boolean},
	};

	constructor() {
		super();
		this.showContainer = true;
	}

	get _promotions() {
		const promotions = [];
		for (let i = 1; i < 5; i++) {
			const findKey = `promotions_descr_list_${i}`;
			const findMsg = getMessage(findKey);
			if (findMsg !== findKey) {
				promotions.push({msg: findMsg});
			}
		}

		return promotions;
	}

	render() {
		const promos = this._promotions;

		if (
			!this.searchConfig?.showPromotions ||
			!promos.length ||
			!this.showContainer
		) {
			return;
		}

		const bindings = {tagLine: getMessage('promotions_label'), promos: promos};

		return b$1`<load-template
			.bindings=${bindings}
			path="Container/domain-promotions"
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('domain-promotions', DomainPromotions);

class SearchOptionsToggle extends s$1 {
	static properties = {
		showBulkInput: {},
		searchAction: {},
		searchTerm: {},
	};

	constructor() {
		super();
	}

	limitLines(el) {
		let values = el.target.value.replace(/\r\n/g, '\n').split('\n');
		if (values.length > 10) {
			el.target.value = values.slice(0, 10).join('\n');
		}
	}

	render() {
		if (this.searchTerm && this.searchTerm.length > 0) {
			// Break search keywords in to multiple lines when using Bulk Mode
			this.searchTerm = Util.searchBulkMode(
				this.searchTerm,
				this.showBulkInput,
			);
		}

		const bindings = {
			showBulkInput: this.showBulkInput,
			searchTerm: this.searchTerm,
			searchType: this.searchAction.toLowerCase(),
		};
		const inputField = this.showBulkInput
			? b$1`<load-template
					path="InputSearch/bulk-input"
					.bindings=${bindings}
			  ></load-template>`
			: b$1`<load-template
					path="InputSearch/single-input"
					.bindings=${bindings}
			  ></load-template>`;

		return b$1`<load-template
			path="InputSearch/input-field"
			.bindings=${{inputField: inputField}}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('search-options-toggle', SearchOptionsToggle);

class SearchFiltersToggle extends s$1 {
	static properties = {
		searchOptions: {type: Boolean},
		showPremiums: {type: Boolean},
		showUnavailable: {type: Boolean},
		showAftermarket: {type: Boolean},
		showContainer: {type: Boolean},
		filterType: {type: Boolean},
		searchResultsAvailable: {type: Boolean},
		searchConfig: {type: Object},
		advancedOptions: {type: Array},
		searchToggleBtns: {type: Array},
		tldCategories: {type: Array},
		totalUnavailableDomains: {type: Number},
		currentPriceRange: {type: Number, state: true},
		searchAction: {type: String},
		checkedClass: {type: String},
		unCheckedClass: {type: String},
	};

	constructor() {
		super();
		this.advancedOptions = Util.session.advancedOptions ?? [];
		this.checkedClass =
			'Box-gap-spacing-2x_2hvKl Box-backgroundColor-blue_2PS2q Box-borderColor-blue_28uxe Box-bordered_ZIQTS Box-interactive_ij9NR Box-hoverable_1FPu7 Flex-flexInline_PeciM Flex-flexAlignItemsCenter_3oJ12 Text-size-base_3CRhE Text-weight-regular_Flodb Text-color-white_MQZPd Pill-root_3TDMD Pill-default_22iwf TogglePill-root_zPTX9 ToggleGroup-pill_2ytf9';
		this.unCheckedClass =
			'Box-gap-spacing-2x_2hvKl Box-backgroundColor-transparent_3WlDE Box-borderColor-grey_1sG0g Box-hoverBorderColor-blue_1Igbc Box-bordered_ZIQTS Box-interactive_ij9NR Box-hoverable_1FPu7 Flex-flexInline_PeciM Flex-flexAlignItemsCenter_3oJ12 Text-size-base_3CRhE Text-weight-regular_Flodb Text-color-anthracite_2apnl Pill-root_3TDMD Pill-default_22iwf TogglePill-root_zPTX9 ToggleGroup-pill_2ytf9';
	}

	async updated(changed) {
		if (changed.has('searchConfig') && this.searchAction === 'register') {
			this.tldCategories = this.searchConfig.categories.map(category => {
				return {
					id: category.id,
					name: category.name,
					icon: category.settings?.icon,
					default: category.settings?.default,
				};
			});
		}

		if (
			changed.has('searchToggleBtns') &&
			this.searchToggleBtns &&
			this.searchToggleBtns.length > 0
		) {
			this.showUnavailable = Util.findValueInArray(
				this.searchToggleBtns,
				'unavailable',
			);
			this.showPremiums = Util.findValueInArray(
				this.searchToggleBtns,
				'premiums',
			);
			this.showAftermarket = Util.findValueInArray(
				this.searchToggleBtns,
				'aftermarket',
			);
			this.filterType = Util.findValueInArray(
				this.searchToggleBtns,
				'filterType',
			);
		}
	}

	_priceRange(event) {
		if (event.target.id !== 'priceRangeInput') {
			event.preventDefault();
			return;
		}
		this.currentPriceRange =
			event.target.value > 1 ? event.target.value - 1 : 1;
		Util.params.filter = this.filterType ? 'RegistrationPrice' : 'RenewPrice';
		Util.params.filterPriceRange = this.currentPriceRange;
	}

	get _additionalConfig() {
		if (this.searchAction !== 'suggestions') {
			return;
		}
		const bindings = {
			requestLocationBasedResults: this.advancedOptions.includes(
				'locationBasedResults',
			),
			requestNoWeightedDomains:
				this.advancedOptions.includes('noWeightedDomains'),
		};
		return b$1`<load-template
			path="Container/Search/additional-config"
			.bindings=${bindings}
		></load-template>`;
	}

	get _categories() {
		if (this.searchAction !== 'register') {
			return;
		}

		const bindings = {
			totalCategories: this.tldCategories?.length ?? 0,
			tldCategories: this.tldCategories,
		};
		return b$1`<load-template
			path="Container/Search/categories"
			.bindings=${bindings}
		></load-template>`;
	}

	get _priceFilters() {
		if (
			this.searchAction !== 'register' ||
			!Util.session?.tldsRegisterPricing ||
			!Util.session?.tldsRegisterPricing
		) {
			return;
		}

		const tldRegisterPrices = Object.values(Util.session?.tldsRegisterPricing);
		const tldRenewPrices = Object.values(Util.session?.tldsRegisterPricing);
		const registerMax = Math.max(...tldRegisterPrices); // fetch the maximum tldPrice
		const renewMax = Math.max(...tldRenewPrices); // fetch the maximum tldPrice
		let max = registerMax > renewMax ? registerMax : renewMax;
		this.currentPriceRange = Util.params?.filterPriceRange ?? max;
		const rangeValues = [];
		rangeValues.push(1);
		const firstMedian = Math.ceil(parseInt(max) / 3);
		rangeValues.push(firstMedian);
		const secondMedian = Math.ceil(parseInt(firstMedian + max) / 2);
		rangeValues.push(secondMedian);
		rangeValues.push(Math.ceil(max / 10) * 10); // to nearest 10
		const rangeLabels = [];
		for (let i = 0; i < rangeValues.length; i++) {
			rangeLabels.push(
				b$1`<option value="${rangeValues[i]}">${rangeValues[i]}</option>`,
			);
		}

		const bindings = {
			checkedClass: this.checkedClass,
			unCheckedClass: this.unCheckedClass,
			filterType: this.filterType,
			currentPriceRange: this.currentPriceRange,
			currentPriceRangeLabel: this.searchResultsAvailable
				? '' + this.currentPriceRange
				: b$1`<data-list template="LoadMore/spinner" />`,
			rangeLabels: rangeLabels,
			maxRange: max + 10,
			resultsAvailable: !this.searchResultsAvailable,
		};
		return b$1`<load-template
			path="Container/Search/price-range-filter"
			.bindings=${bindings}
		></load-template>`;
	}

	render() {
		if (!this.searchOptions || !this.showContainer) {
			return;
		}

		const bindings = {
			categoriesTemplate: this._categories,
			additionalConfigTemplate: this._additionalConfig,
			priceRangeFilterTemplate: this._priceFilters,
			checkedClass: this.checkedClass,
			unCheckedClass: this.unCheckedClass,
			filterType: this.filterType,
			showPremiums: this.showPremiums,
			showUnavailable: this.showUnavailable,
			showAftermarket: this.showAftermarket,
			totalUnavailableDomains: this.totalUnavailableDomains,
		};
		return b$1`<load-template
			@change=${this._priceRange}
			path="Container/Search/search-filters"
			.bindings=${bindings}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('search-filters-toggle', SearchFiltersToggle);

class DomainInput extends s$1 {
	static properties = {
		searchTerm: {
			hasChanged(value, oldVal) {
				if (!oldVal) {
					Util.session.searchTerm = value;
					return true;
				} else if (!value) {
					return false;
				}
				Util.session.searchTerm = value;
				return value.length > 0 && value !== oldVal;
			},
		},
		searchResultsAvailable: {type: Boolean},
		searchToggleBtns: {type: Array},
		searchConfig: {type: Object},
		totalUnavailableDomains: {type: Number},
		searchAction: {type: String},
		showBulkInput: {type: Boolean},
		searchOptions: {type: Boolean},
	};

	constructor() {
		super();
		this.showBulkInput = Util.params.bulk ? true : false;
		this.searchOptions = Util.params.options ? true : false;
	}

	get _input() {
		this._advancedOptions();
		return this.renderRoot?.querySelector('#search') ?? null;
	}

	_advancedOptions() {
		let checkboxes = this.renderRoot.querySelectorAll(
			'input[type=checkbox][name=advancedOption]',
		);
		let enabledSettings = Array.from(checkboxes) // Convert checkboxes to an array to use filter and map.
			.filter(i => i.checked) // Use Array.filter to remove unchecked checkboxes.
			.map(i => i.value); // Use Array.map to extract only the checkbox values from the array of objects.
		Util.session.advancedOptions = enabledSettings;
	}

	/**
	 * This function toggles buttons based on user input and dispatches an event with updated filters
	 *
	 * @param {Object} element
	 * @returns void
	 */
	_toggleButtons(element) {
		// Get the name and value of the element triggering the function
		const {name, value} = element.target;
		// Get all inputs with the same name as the triggering element
		const inputs = this.renderRoot?.querySelectorAll(`input[name="${name}"]`);

		// Remove any existing filter with the same type as the triggering element
		Util.deleteValueFromArray(this.searchToggleBtns, 'type', name);

		// Create a new filter object and add it to the searchToggleBtns array
		const isHidden =
			name !== 'filterType' ? value !== 'hide' : value !== 'renewPrice';
		const filter = {type: name, show: isHidden};
		this.searchToggleBtns.push(filter);

		// Create a custom event with updated filters and dispatch it
		const options = {
			detail: {filters: this.searchToggleBtns},
			bubbles: true,
			composed: true,
		};
		this.dispatchEvent(new CustomEvent('cnicDomainFilters', options));

		// Toggle the buttons and return the result
		Util.toggleButtons(element, inputs);
	}

	/**
	 * This function handles a search event and dispatches an event with search term and search page information
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_searchHandler(event) {
		// Prevent the default form submission behavior
		event.preventDefault();

		if (!this.searchResultsAvailable) {
			return;
		}

		// Get the search term from the input element
		this.searchTerm = this._input?.value;

		// Check if the search term ends with a space and the search tab is "transfer"
		if (this.searchTerm.endsWith(' ') && this.searchAction === 'transfer') {
			// If the conditions are met, set the flag to show the bulk input
			this.showBulkInput = true;

			// Set the 'bulk' parameter to "1" in the current URL
			Util.params.bulk = '1';
		}

		// trim any whitespace
		this.searchTerm = this.searchTerm.trim();
		if (!this.searchTerm.length) {
			return; // return if search field is empty
		}

		// Toggle the search results availability flag
		this.searchResultsAvailable = !this.searchResultsAvailable;

		// Create a custom event with search term and search page information, and dispatch it
		const options = {
			detail: {searchTerm: this.searchTerm, searchPage: this.searchPage ?? 1},
			bubbles: true,
			composed: true,
		};
		this.dispatchEvent(new CustomEvent('cnicDomainSearch', options));
	}

	/**
	 * This function handles changes in the search form and calls the appropriate functions depending on the input
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_onFormChange(event) {
		// Define an array of available options
		const availableOptions = [
			'premiums',
			'unavailable',
			'aftermarket',
			'filterType',
		];

		// If the change is related to advanced options, call the _advancedOptions function
		if (event.target.name === 'advancedOption') {
			this._advancedOptions();
		}

		// If the changed input is an available option, call the _toggleButtons function and return
		else if (availableOptions.indexOf(event.target.name) > -1) {
			this._toggleButtons(event);
			return;
		}

		// If the changed input is not an available option, call the _searchHandler function and return
		return this._searchHandler(event);
	}

	/**
	 * This function handles the event when the user toggles the bulk input field and updates the URL accordingly
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_toggleBulkInputFieldHandler(event) {
		// Prevent the default behavior of the event
		event.preventDefault();

		// Get the current URL
		let oldUrl = window.location.href;

		// Toggle the showBulkInput flag
		this.showBulkInput = !this.showBulkInput;

		// If showBulkInput is true, add a "bulk" parameter to the URL
		if (this.showBulkInput) {
			Util.params.bulk = '1';
		} else {
			Util.params.bulk = '';
		}

		// Update the URL based on whether it already has a "bulk" parameter
		event.target.href = !oldUrl.match(/bulk/gi) ? window.location.href : oldUrl;
	}

	/**
	 * This function toggles the search options and updates the URL accordingly.
	 *
	 * @param {Event} event - The event object
	 * @returns void
	 */
	_toggleSearchOptionsHandler(event) {
		// Prevent the default behavior of the event
		event.preventDefault();
		// Get the current URL
		let oldUrl = window.location.href;

		// Toggle the searchOptions flag
		this.searchOptions = !this.searchOptions;

		// If searchOptions is true, add an "options" parameter to the URL
		if (this.searchOptions) {
			Util.params.options = '1';
		} else {
			Util.params.options = '';
		}

		// Update the URL based on whether it already has an "options" parameter
		event.target.href = oldUrl.match(/options/gi)
			? window.location.href
			: oldUrl;
	}

	get _hideAdvancedOptions() {
		if (this.searchAction === 'transfer' || this.searchAction === 'whois') {
			this.searchOptions = false;
			return !this.searchOptions;
		}
	}

	get _hideBulkButton() {
		if (this.searchAction === 'whois') {
			this.showBulkInput = false;
			return !this.showBulkInput;
		}
	}

	get _hideTransferInfoIcon() {
		return this.searchAction !== 'transfer';
	}

	render() {
		const bindings = {
			showBulkIcon: this.showBulkInput,
		};

		const inputBulkButton = b$1`<data-list
			@click=${event => this._toggleBulkInputFieldHandler(event)}
			template="InputSearch/bulk-button"
			.data=${bindings}
			.isHidden=${this._hideBulkButton}
		/>`;
		const advancedOptionsButton = b$1`<data-list
			@click=${event => this._toggleSearchOptionsHandler(event)}
			template="InputSearch/options-button"
			.isHidden=${this._hideAdvancedOptions}
		/>`;
		const transferInfoIcon = b$1`<data-list
			template="InputSearch/transfer-info-button"
			.isHidden=${this._hideTransferInfoIcon}
		/>`;
		const searchOptionsToggleTemplateStartTag = b$1`<search-options-toggle
			.searchTerm=${this.searchTerm}
			searchAction=${this.searchAction}
			.showBulkInput=${this.showBulkInput}
		></search-options-toggle>`;
		const searchOptionsToggleTemplateEndTag = b$1`</search-options-toggle>`;
		const loadMoreButtonTemplate = b$1`<load-more-button
			@click=${event => this._searchHandler(event)}
			.searchResults=${this.searchResultsAvailable}
			searchTerm=${this.searchTerm}
			searchAction=${this.searchAction}
			datatype="search"
		/>`;
		const mobileAdvancedOptionsTemplate = b$1`<data-list
			@click=${event => this._toggleSearchOptionsHandler(event)}
			template="InputSearch/mobile-advanced-options"
			.data=${{searchOptions: this.searchOptions}}
			.isHidden=${this._hideAdvancedOptions}
		/>`;
		const domainPromotionsTemplate = b$1`<domain-promotions
			.showContainer=${!this._hideBulkButton}
			.searchConfig=${this.searchConfig}
		/>`;
		const searchFiltersToggleTemplate = b$1`<search-filters-toggle
			.showContainer=${!this._hideAdvancedOptions}
			.totalUnavailableDomains=${this.totalUnavailableDomains}
			.searchToggleBtns=${this.searchToggleBtns}
			.searchConfig=${this.searchConfig}
			searchAction=${this.searchAction}
			.searchOptions=${this.searchOptions}
			.tldCategories=${this.tldCategories}
			.searchResultsAvailable=${this.searchResultsAvailable}
		/>`;

		const data = {
			inputBulkButton: inputBulkButton,
			advancedOptionsButton: advancedOptionsButton,
			transferInfoIcon: transferInfoIcon,
			searchOptionsToggleTemplateStartTag: searchOptionsToggleTemplateStartTag,
			searchOptionsToggleTemplateEndTag: searchOptionsToggleTemplateEndTag,
			loadMoreButtonTemplate: loadMoreButtonTemplate,
			mobileAdvancedOptionsTemplate: mobileAdvancedOptionsTemplate,
			domainPromotionsTemplate: domainPromotionsTemplate,
			searchFiltersToggleTemplate: searchFiltersToggleTemplate,
		};

		return b$1`<data-list
			@change=${this._onFormChange}
			@submit=${this._searchHandler}
			template="Container/Search/main"
			.data=${data}
		/>`;
	}

	createRenderRoot() {
		return this;
	}
}
customElements.define('domain-input', DomainInput);

class CartHandler {
	constructor(idnDomainName, domainName, isPremium, tldSupported, isAvailable) {
		this.idnDomainName = idnDomainName;
		this.domainName = domainName;
		this.isPremium = isPremium;
		this.tldSupported = tldSupported;
		this.isAvailable = isAvailable;
	}

	/**
	 * @param {String} code
	 */
	set eppCode(code) {
		this.domainEppCode = code;
	}

	/**
	 * @param {String} code
	 */
	set period(year) {
		this.registerPeriod = year;
	}

	static _updateCartCounter(totalItems) {
		const counterElement = document.querySelector('a.cart-btn>span.badge-info');
		counterElement.innerHTML = `${totalItems}`;
	}

	async _addDomainTransfer(payload) {
		const data = await Util.fetchData(
			Object.assign(
				{type: 'addDomainTransfer', eppcode: this.domainEppCode},
				payload,
			),
		);
		const [resolvedData] = await Promise.all(data);
		await this._getCartDomains();
		return resolvedData;
	}

	async _removeFromCart(payload) {
		const data = await Util.fetchData(
			Object.assign({type: 'removeFromCart'}, payload),
		);
		const [resolvedData] = await Promise.all(data);
		await this._getCartDomains();
		CartHandler._updateCartCounter(resolvedData?.cartCount ?? 0);
		return resolvedData ?? {result: 'removed'};
	}

	async _addToCart(payload) {
		const data = await Util.fetchData(
			Object.assign({type: 'addToCart'}, payload),
		);
		const [resolvedData] = await Promise.all(data);
		await this._updateCart(payload);
		await this._getCartDomains();
		return resolvedData;
	}

	async _getCartDomains() {
		const data = await Util.fetchData({type: 'getCartDomains'});
		const [resolvedData] = await Promise.all(data);
		Util.session.cartList = await resolvedData;
		CartHandler._updateCartCounter(Object.keys(Util.session.cartList).length);
		return resolvedData;
	}

	async _updateCart(payload) {
		const data = await Util.fetchData(
			Object.assign({type: 'updateCart'}, payload),
		);
		const [resolvedData] = await Promise.all(data);
		return resolvedData;
	}

	async init(
		addToCart,
		registerPeriod,
		updateRequest = false,
		domainTransfer = false,
	) {
		if (
			!addToCart &&
			!this.tldSupported &&
			!this.isAvailable &&
			!domainTransfer
		) {
			return;
		}

		this.period = registerPeriod;

		let payload = {
			domainIdn: this.idnDomainName,
			domainPc: this.domainName,
			domainPeriod: this.registerPeriod,
			domainPremium: this.isPremium,
		};

		if (domainTransfer) {
			const data = await this._addDomainTransfer(payload);
			return data;
		}

		if (addToCart && updateRequest === true) {
			const data = await this._updateCart(payload);
			return data;
		}

		if (addToCart) {
			const data = await this._removeFromCart(payload);
			return data;
		} else {
			const data = await this._addToCart(payload);
			const cachedData = new UniqueObjectCache('CachedDomainList');
			cachedData.deleteDomainCache(this.domainName);
			return data;
		}
	}
}

class DomainListItem extends s$1 {
	static properties = {
		domainName: {type: String},
		domainTld: {type: String},
		idnDomainName: {type: String},
		domainStatus: {type: String},
		domainEppCode: {type: String},
		domainGroup: {type: String},
		cartItemType: {type: String},
		availabilityReason: {type: String},
		registerPeriod: {type: Number},
		isAvailable: {type: Boolean},
		isPremium: {type: Boolean},
		isBaseDomain: {type: Boolean},
		tldSupported: {type: Boolean},
		addToCart: {type: Boolean},
		itemInCartSession: {type: Boolean},
		searchToggleBtns: {},
		domainPricing: {},
		showLoading: {},
		showPremiums: {},
		showUnavailable: {},
		showAftermarket: {},
		showTransferBtn: {},
		transferMsgError: {},
		cartHandler: {},
	};

	constructor() {
		super();
		this.showLoading = false;
		this.addToCart = false;
		this.registerPrices = [];
		this.renewPrices = [];
		this.showTransferBtn = Util.session.config.showDomainTransfers;
	}

	async updated(changed) {
		if (changed.has('searchToggleBtns') && this.searchToggleBtns) {
			this.showUnavailable = Util.findValueInArray(
				this.searchToggleBtns,
				'unavailable',
			)?.show;
			this.showPremiums = Util.findValueInArray(
				this.searchToggleBtns,
				'premiums',
			)?.show;
			this.showAftermarket = Util.findValueInArray(
				this.searchToggleBtns,
				'aftermarket',
			)?.show;
		}

		if (
			changed.has('domainEppCode') &&
			!this.addToCart &&
			this._isTransferable()
		) {
			await this.initiateTransfer();
		}
	}

	async initiateTransfer() {
		if (Util.params.action !== 'transfer') {
			return;
		}
		const data = this._addToCart(false, true);
		data.then(data => {
			const result = data?.result ?? data;
			if (result === 'added') {
				this.cartItemType = 'transfer'; // set cart item type to transfer
				this.addToCart = true; // add to cart
			} else if (result?.unavailable) {
				// data.unavailable property tells why the domain not available to add into the cart
				this.transferMsgError = result.unavailable;
			} else {
				this.transferMsgError = b$1`${getMessage(
						'domain_transfer_epp_error_msg',
					)}
					<a
						href="#toggle"
						@click=${async event => await this._domainTransfer(event)}
						id="domainTransferBtn"
						>${getMessage('transferable_domain_link_label_tryagain')}</a
					>`;
			}
		});
	}

	async _addToCart(updateRequest = false, domainTransfer = false) {
		if (this.showLoading) {
			return;
		}

		this.showLoading = !this.showLoading;
		this.cartHandler ??= new CartHandler(
			this.idnDomainName,
			this.domainName,
			this.isPremium,
			this.tldSupported,
			this.isAvailable,
		);

		this.cartHandler.eppCode = this.domainEppCode;

		const data = await this.cartHandler.init(
			this.addToCart,
			this.registerPeriod,
			updateRequest,
			domainTransfer,
		);
		if (data?.result) {
			this.addToCart = !this.addToCart;
			this.itemInCartSession = false;
			if (!domainTransfer) {
				this.cartItemType = 'register';
			}
		}
		this.showLoading = !this.showLoading;
		return data;
	}

	availableStatusIcon() {
		return b$1`<data-list
			template="Container/DomainListItem/status-available-icon"
		/>`;
	}

	notAvailableStatusIcon() {
		return b$1`<data-list
			template="Container/DomainListItem/status-not-available-icon"
		/>`;
	}

	infoStatusIcon() {
		return b$1`<data-list
			template="Container/DomainListItem/status-info-icon"
		/>`;
	}

	_isTransferable() {
		return (
			this.showTransferBtn &&
			!this.isAvailable &&
			this.tldSupported &&
			this.isBaseDomain &&
			!this.showLoading
		);
	}

	addToCartBtn() {
		if ((this.addToCart && !this.cartItemType) || !this.tldSupported) {
			return;
		}
		if (this.showLoading) {
			return b$1`<data-list
				template="Container/DomainListItem/add-to-cart-loading-icon"
			/>`;
		}

		if (this.addToCart) {
			return b$1`<data-list
				@click=${() => this._addToCart()}
				template="Container/DomainListItem/remove-from-cart-icon"
			/>`;
		}

		if (!this.isAvailable) {
			return;
		}

		return b$1`<data-list
			@click=${() => this._addToCart()}
			template="Container/DomainListItem/add-to-cart-btn"
		/>`;
	}

	_domainRegisterPeriods() {
		if (!this.isAvailable && !this.domainPricing && this.domainPricing.length) {
			return;
		}
		let pricingOptions = [];
		this.registerPeriod = parseInt(this.registerPeriod);
		pricingOptions = Object.keys(this.domainPricing).map(period => {
			period = parseInt(period);
			return b$1`<option
				class=""
				value="${period}"
				?selected=${this.registerPeriod === period}
			>
				${period} ${getMessage('year_label')}
			</option>`;
		});

		return pricingOptions;
	}

	_showBadges() {
		let badges = [];
		if (this.isPremium && !this.isAftermarket) {
			badges.push(
				b$1`<data-list
					template="Container/DomainListItem/domain-premium-badge"
				/>`,
			);
		}

		if (this.isPremium && this.isAftermarket) {
			badges.push(
				b$1`<data-list
					template="Container/DomainListItem/domain-aftermarket-badge"
				/>`,
			);
		}

		if (
			this.isAvailable &&
			this.tldSupported &&
			this.domainPricing[this.registerPeriod].register.price >
				this.domainPricing[this.registerPeriod].renew.price
		) {
			badges.push(
				b$1`<data-list
					template="Container/DomainListItem/domain-lower-renew-price-badge"
				/>`,
			);
		}

		if (this.tldSupported && this.domainGroup) {
			const badgeColors = {
				hot: 'Badge-intentDanger_1Tpoo',
				sale: 'Badge-intentPromotional_sbT5N',
				new: 'Badge-intentNew',
			};

			const data = {
				badgeColor: badgeColors[this.domainGroup] ?? '',
				domainGroup: this.domainGroup,
			};
			badges.push(
				b$1`<data-list
					template="Container/DomainListItem/domain-group-badge"
					.data=${data}
				/>`,
			);
		}

		if (this._isTransferable() && !this.transferMsgError) {
			badges.push(
				b$1`<data-list
					template="Container/DomainListItem/transferable-label"
				/>`,
			);
		}

		if (this._isTransferable() && this.transferMsgError) {
			const data = {msg: this.transferMsgError};
			badges.push(
				b$1`<data-list
					template="Container/DomainListItem/transfer-error-msg"
					.data=${data}
				/>`,
			);
		}

		if (badges.length > 0) {
			const data = {badges: badges};
			return b$1`<data-list
				template="Container/DomainListItem/domain-badges-main"
				.data=${data}
			/>`;
		}
	}

	_hideDomain() {
		let hideDomain = false;
		if (!this.isBaseDomain && this.isPremium && !this.showPremiums) {
			hideDomain = true;
		}
		if (!this.isBaseDomain && this.isAftermarket && !this.showAftermarket) {
			hideDomain = true;
		}
		if (!this.isBaseDomain && !this.isAvailable && !this.showUnavailable) {
			hideDomain = true;
		}
		return hideDomain;
	}

	_domainWhois(e) {
		e.preventDefault();
		window.history.pushState(null, null, e.target.href);
		let loaderEvent = new Event('cnicUrlUpdate', {
			bubbles: true,
			composed: true,
		});
		this.dispatchEvent(loaderEvent);
	}

	async _domainTransfer(event) {
		event.preventDefault();
		const target = event.target; // transfer link element
		const modal = jQuery('#modalAjax');
		modal.modal('show');
		const loader = modal.find('.loader');
		const modalBody = modal.find('.modal-body');
		const modalSubmit = modal.find('.modal-submit');
		modalSubmit.prop('disabled', false);
		loader.hide(); // hide modal loader
		modal.find('.modal-title').text('Transfer domain ' + this.domainName);

		const data = {
			transferMsgError: this.transferMsgError ?? '',
			domainEppCode: this.domainEppCode ?? '',
		};
		const modalBodyTmpl = `<data-list template="Container/DomainListItem/domain-transfer-modal" .data=${data} />`;
		modalBody.html(modalBodyTmpl);

		modalSubmit.click(async e => {
			e.preventDefault();
			loader.show(); // show modal loader
			const modalInput = modalBody.find('input');
			this.domainEppCode = modalInput.val();
			const tldNotRequireEppCode =
				Util.session.config.tldsWithoutEppCode[this.domainTld];

			modalBody.find('.modal-info').html('');
			if (!tldNotRequireEppCode && !this.domainEppCode.length) {
				loader.hide(); // hide modal loader
				modalBody
					.find('.modal-info')
					.html(getMessage('domain_transfer_epp_error_msg'));
				return;
			}
			modalInput.prop('disabled', true);
			const data = await this._addToCart(false, true);
			const result = data?.result ?? data;

			if (result === 'added') {
				loader.hide(); // hide modal loader
				target.remove(); // remove transfer link element
				this.cartItemType = 'transfer'; // set cart item type to transfer
				this.addToCart = true; // add to cart
				this.transferMsgError = null;
				modal.modal('hide'); // toggle modal
				modalSubmit.prop('disabled', true);
			} else if (result?.unavailable) {
				loader.hide(); // hide modal loader
				modalBody.find('.modal-info').html(result.unavailable);
			}
		});
	}

	_additionalInfo() {
		const infos = [];

		if (this._isTransferable() && !this.addToCart) {
			infos.push(
				b$1`&nbsp;<a
						href="#toggle"
						@click=${async event => await this._domainTransfer(event)}
						id="domainTransferBtn"
					>
						${this.transferMsgError
							? `${getMessage('transferable_domain_link_label_tryagain')}`
							: `${getMessage('transferable_domain_link_label_transferit')}`}</a
					>`,
			);
			infos.push(b$1`&nbsp;${getMessage('separator_label')}&nbsp;`);
		}

		if (!this.isAvailable && Util.session.config.features.WhoIs) {
			const whoisUrl = new URL(`${cnicWebRootPath}/mydomainsearch.php`);
			whoisUrl.searchParams.append('searchTerm', this.idnDomainName);
			whoisUrl.searchParams.append('action', 'whois');
			infos.push(
				b$1`&nbsp;<a
						href=${whoisUrl.toString()}
						@click=${this._domainWhois}
						data-toggle="tooltip"
						title="${getMessage('tab_heading_whois')}"
						>${getMessage('whoisLabel')}</a
					>`,
			);
			infos.push(b$1`&nbsp;${getMessage('separator_label')}&nbsp;`);
		}

		if (this.domainStatus === 'reserved') {
			const contactUrl = new URL(`${cnicWebRootPath}/contact.php`);
			contactUrl.searchParams.append(
				'subject',
				getMessage('contact_reserved_subject', this.idnDomainName),
			);
			contactUrl.searchParams.append(
				'message',
				getMessage('contact_reserved_message', this.idnDomainName),
			);
			infos.push(
				b$1`&nbsp;<a
						href=${contactUrl.toString()}
						data-toggle="tooltip"
						title="${getMessage('label_descr_reserved')}"
						>${getMessage('reserved_label')}</a
					>`,
			);
			infos.push(b$1`&nbsp;${getMessage('separator_label')}&nbsp;`);
		}

		// remove the last value from array which is "separator_label"
		infos.pop();

		return infos;
	}

	_getDomainStatus() {
		if (this.cartItemType !== 'transfer' && !this.addToCart) {
			return getMessage(this.domainStatus);
		}
	}

	_domainPricing() {
		if (this.isAvailable && this.tldSupported) {
			const data = {
				domainRegisterPeriods: this._domainRegisterPeriods(),
				registerPrice: this.domainPricing[this.registerPeriod].register.format,
				renewPrice: this.domainPricing[this.registerPeriod].renew.format,
				periodSuffix: Util.ordinalSuffixOf(this.registerPeriod), // returns 1st, 2nd, 3rd etc
			};
			return b$1`<data-list
				template="Container/DomainListItem/domain-price"
				.data=${data}
			/>`;
		}

		const data = {
			domainStatus: this._getDomainStatus(),
			availabilityReason: this.availabilityReason,
		};
		return b$1`<data-list
			template="Container/DomainListItem/domain-status"
			.data=${data}
		/>`;
	}

	async _changeHandler(event) {
		event.preventDefault();
		const targetId =
			event.target.id ||
			event.target.parentElement.id ||
			event.target.parentElement.parentElement.id;

		if (targetId === 'changeDomainPeriod') {
			this.registerPeriod = parseInt(event.target.value);
			if (this.addToCart) {
				await this._addToCart(true);
			}
		}
	}

	get _addToCartMsg() {
		if (!this.addToCart || (this.addToCart && this.itemInCartSession)) {
			return;
		}
		const bindings = {domainName: this.domainName};
		return b$1`<data-list
			.data=${bindings}
			template="Container/DomainListItem/add-to-cart-success-alert"
		/>`;
	}

	render() {
		if (this._hideDomain()) {
			return;
		}

		const domainBadges = this._showBadges();
		let domainStatusIcon = '';
		if (this.isBaseDomain && this.isAvailable) {
			domainStatusIcon = this.availableStatusIcon();
		} else if (this._isTransferable()) {
			domainStatusIcon = this.infoStatusIcon();
		} else if (this.isBaseDomain && !this.isAvailable) {
			domainStatusIcon = this.notAvailableStatusIcon();
		}
		const domainPricing = this._domainPricing();
		const domainAdditionalInfo = this._additionalInfo();
		const addToCartBtn = this.addToCartBtn();
		const trimmedDomainName = Util.trimMiddleString(this.domainName);
		const data = {
			domainPricing: domainPricing,
			domainAdditionalInfo: domainAdditionalInfo,
			addToCartBtn: addToCartBtn,
			trimmedDomainName: trimmedDomainName,
			domainStatusIcon: domainStatusIcon,
			domainBadges: domainBadges,
			domainName: this.domainName,
			idnDomainName: this.idnDomainName,
			isExactSearchDomain: this.isBaseDomain,
			availabilityReason: this.availabilityReason,
			addToCartMsg: this._addToCartMsg,
		};

		return b$1`<data-list
			@change=${this._changeHandler}
			template="Container/DomainListItem/main"
			.data=${data}
		/>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('domain-list-item', DomainListItem);

class LoadingDomainList extends s$1 {
	static properties = {
		searchResultsAvailable: {},
	};

	constructor() {
		super();
	}

	render() {
		if (this.searchResultsAvailable) {
			return;
		}

		return b$1`<load-template
			path="LoadMore/domains-placeholder"
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('loading-domain-list', LoadingDomainList);

class Spotlight extends s$1 {
	static properties = {
		spotlightTlds: {type: Object},
		tldBoxWidth: {type: String},
		showContainer: {type: Boolean},
		content: {},
	};

	constructor() {
		super();
		this.content = [];
		this.defaultWidth = '150px';
	}

	firstUpdated() {
		if (!this.spotlightTlds?.length) {
			return;
		}

		this._spotlightTlds();
	}

	generateDarkColor() {
		// Generate random values for red, green, and blue between 0 and 127
		const r = Math.floor(Math.random() * 140);
		const g = Math.floor(Math.random() * 155);
		const b = Math.floor(Math.random() * 145);

		// Return the RGB value as a string
		return `rgb(${r},${g},${b})`;
	}

	async _spotlightTlds() {
		const content = [];
		for (const tld of this.spotlightTlds) {
			const spotlightObject = {
				color: this.generateDarkColor(),
				tldName: tld.tld,
			};
			if (tld?.img) {
				spotlightObject.tldImage = tld.img;
			}

			if (tld?.group) {
				spotlightObject.tldGroup = tld.group;
				spotlightObject.tldGroupBadge = `--background-ribbon-color: var(--tld-group-${
					tld.group
				}-bg);--badge-label: "${getMessage(`group${tld.group}`)}"`;
			}

			if (tld?.register && tld?.renew) {
				spotlightObject.tldRegisterPrice = tld.register;
				spotlightObject.tldRenewPrice = tld.renew;
			}

			if (tld?.transfer) {
				spotlightObject.tldTransferPrice = tld.transfer;
			}

			let fontSize =
				parseInt(this.tldBoxWidth ?? this.defaultWidth) /
				(tld.tld.length * 0.6);
			fontSize = fontSize > 80 ? 80 : fontSize;
			spotlightObject.fontSize = `${fontSize}px`;

			content.push(spotlightObject);
		}

		this.content = content;
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		const bindings = {
			spotlight: this.content,
			webRootPath: cnicWebRootPath,
			tldBoxWidth: this.tldBoxWidth ?? this.defaultWidth,
		};

		return b$1`<load-template
			path="Container/spotlight"
			.bindings=${bindings}
		></load-template>`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('spotlight-tlds', Spotlight);

class DataList extends s$1 {
	static properties = {
		data: {},
		isHidden: {},
		template: {},
	};

	constructor() {
		super();
	}

	render() {
		if (this.isHidden) {
			return;
		}
		const bindings = {data: this.data};
		return b$1`
			<load-template
				.path=${this.template}
				.bindings=${bindings}
			></load-template>
		`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('data-list', DataList);

class DataSorting extends s$1 {
	static properties = {
		searchTerm: {type: String},
		sort: {type: String},
		sortDirection: {type: String},
		showContainer: {type: Boolean},
	};

	constructor() {
		super();
		this.sortDirection = Util.params?.sortDir ?? 'ASC';
		this.sort = Util.params?.sort ?? 'TldOrder';
	}

	async _requestSorting(e) {
		const {target} = e;
		const {name, value} = target;
		const {params} = Util;

		this.searchResultsAvailable = false;

		if (name === 'sortBy') {
			params.sort = value;
		} else if (name === 'sortByDir') {
			const direction = value === 'ASC' ? 'DESC' : 'ASC';
			params.sortDir = direction;
			target.value = direction;
			const icon = target.parentNode.querySelector('i');
			const iconClass = direction === 'ASC' ? 'down' : 'up-alt';
			icon.className = `fas fa-sort-alpha-${iconClass} selectSortListDir`;
		}

		if (!params.sort) {
			params.sort = 'TldOrder';
		}

		if (!params.sortDir) {
			params.sortDir = 'DESC';
		}

		this.sort = Util.params.sort;
		this.sortDirection = params.sortDir;

		const searchParams = {
			searchPage: 1,
			searchTerm: this.searchTerm,
			sort: this.sort,
			sortDirection: this.sortDirection,
		};

		const options = {
			detail: searchParams,
			bubbles: true,
			composed: true,
		};
		this.dispatchEvent(new CustomEvent('cnicDomainSearch', options));
	}

	render() {
		if (!this.showContainer) {
			return;
		}

		const orderType = ['TldOrder', 'TldName', 'DomainName']; // "RegistrationPrice", "RenewPrice"
		const orderList = orderType.map(
			item =>
				b$1` <option value="${item}" ?selected=${this.sort === item}>
					${getMessage(`sort_label_${item.toLowerCase()}`)}
				</option>`,
		);
		const bindings = {orderList: orderList, sortDirection: this.sortDirection};
		return b$1`
			<load-template
				@change=${this._requestSorting}
				path="Container/Search/sort-selector"
				.bindings=${bindings}
			></load-template>
		`;
	}

	createRenderRoot() {
		return this;
	}
}

customElements.define('data-sorting', DataSorting);
