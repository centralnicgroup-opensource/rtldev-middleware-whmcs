$(document).ready(function () {
	let selectedTr;
	let premiumPrices = {};
	const successElement = $('#successMsgModal');
	const errorElement = $('#errorMsgModal');
	const spinnerElement = $('#modalSpinner');
	const domainMonitoringList = $('#domain-monitoring-list');

	domainMonitoringList.dataTable({order: [[3, 'desc']]});

	// Function to handle Fix Now button click
	function handleFixNowClick() {
		selectedTr = $(this).closest('tr');
		const rowDataId = selectedTr.data('id');
		const domain = selectedTr.find('[data-domain]').data('domain');
		const type = selectedTr.data('type');
		const desc = selectedTr.find('[data-desc]').data('desc');

		$('#domainModalLabel').text(domain);

		successElement.hide();
		errorElement.hide();
		spinnerElement.show();

		$.ajax({
			url: `${addonModuleLink}&action=fetchPrice`,
			method: 'GET',
			data: {
				id: rowDataId,
				type: type,
			},
			dataType: 'json',
			success: function (response) {
				if (response?.success === false) {
					successElement.hide();
					spinnerElement.hide();
					errorElement.show().html(response.message);
					return;
				}

				let priceText = '<br />New Prices Are As Shown Below:<br />';
				premiumPrices = {};

				if (response?.renew) {
					priceText +=
						'* Renew: ' + response.renew + ' ' + response.currency + '<br />';
					premiumPrices.renew = response.renew;
					premiumPrices.currency = response.currency;
				}

				if (response?.transfer) {
					priceText +=
						'* Transfer: ' + response.transfer + ' ' + response.currency;
					premiumPrices.transfer = response.transfer;
					premiumPrices.currency = response.currency;
				}

				const postText =
					`Kindly <strong>'Confirm'</strong> the pricing update by approving this pop-up.<br /><br />Once processed, you can reattempt the pending <strong>'${
						type === 'renew_premium_price_missing' ? 'Renewal' : 'Transfer'
					}'</strong> for the <strong>'${domain}'</strong> domain through Module Queue.<br /><br />` +
					`<small>* We'll be updating pricing details in tbldomains_extra. Keep in mind, WHMCS will factor in coupons, along with any additional costs like premium margin, DNS management, email forwarding, URL forwarding, etc. You can view the final recurring amount on the domain level after the update is complete and follow the next steps.</small>`;

				errorElement.hide();
				spinnerElement.hide();
				successElement.html(
					desc +
						'<br /><strong>' +
						priceText +
						'</strong><br /><br />' +
						postText,
				);
				successElement.show();
			},
			error: function (xhr, status, error) {
				console.error(status + ': ', error);
				successElement.hide();
				spinnerElement.hide();
				errorElement.show().html(status + ': ' + error);
			},
		});
	}

	// Function to handle Confirm button click
	function handleConfirmClick() {
		const rowDataId = selectedTr.data('id');
		const todoId = selectedTr.data('todoid');
		const domainId = selectedTr.data('domainid');
		const domainName = selectedTr.find('[data-domain]').data('domain');
		const domainRegistrar = selectedTr.data('type');
		const desc = selectedTr.find('[data-desc]').data('desc');

		spinnerElement.show();
		successElement.html(
			'Sit tight while we work on updating domain prices and status for you...',
		);

		$.ajax({
			url: `${addonModuleLink}&action=updatePrice`,
			method: 'POST',
			data: {
				id: rowDataId,
				todoId: todoId,
				domainId: domainId,
				domainName: domainName,
				domainRegistrar: domainRegistrar,
				renewPrice: premiumPrices?.renew ?? '',
				transferPrice: premiumPrices?.transfer ?? '',
				currency: premiumPrices.currency,
			},
			dataType: 'json',
			success: function (response) {
				if (response?.success === false) {
					successElement.hide();
					spinnerElement.hide();
					errorElement.show().html(response.message);
					return;
				}

				successElement.html(
					"Great news! We've successfully updated the domain prices and status for you. Your domains are now ready to Renew/Transfers!",
				);
				successElement.show();
				errorElement.hide();
				spinnerElement.hide();
				$('#domainFixModal').modal('hide');
				selectedTr.find('[data-status]').text('Action Required');
				selectedTr.find('[data-desc]').html(
					`${desc}<br /><br />` +
						`<p><strong>For accurate billing, please follow these steps:</strong></p>
                    <ol>
                        <li>Click on the provided URL: <a target="_blank" style="text-decoration:underline" href="./clientsdomains.php?id=${domainId}">clientsdomains.php?id=${domainId}</a></li>
                        <li>Toggle "Recalculate on Save" to "Yes".</li>
                        <li>Click the "Save" button to apply the changes and recalculate the prices.</li>
                        <li>* Cancel & Refund the original Invoice & Order.</li>
                        <li>Initiate the renewal/transfer again via Client Area.</li>
                    </ol>
                    <p><small>
                            * Additionally, please be aware that the domain may have either been upgraded to premium status
                            and/or the renewal/transfer pricing has been adjusted. It's crucial to thoroughly review and
                    update the billing to maintain precise records and prevent any discrepancies between your
                    reseller cost and the customer's original payment. In the event of a discrepancy, you may be
                            required to cover the difference instead of the customer.
                    </small></p>
                `,
				);
				$('#dataActions').html(`<button type="button"
                class="btn btn-danger deleteBtn">Delete</button>`);
			},
			error: function (xhr, status, error) {
				console.error('Error:', error);
				successElement.hide();
				spinnerElement.hide();
				errorElement.show().html(error);
			},
		});
	}

	// Event delegation for delete button click
	$(document).on('click', '.deleteBtn', function () {
		selectedTr = $(this).closest('tr');
		const todoId = selectedTr.data('todoid');

		$.ajax({
			url: `${addonModuleLink}&action=deleteRecord`,
			method: 'POST',
			data: {
				id: todoId,
			},
			dataType: 'json',
			success: function (response) {
				selectedTr.html(
					`<td colspan="5" style="text-align: center;">Item has been deleted successfully.</td>`,
				);
			}.bind(this),
			error: function (xhr, status, error) {
				console.error('Error:', error);
			},
		});
	});

	// Attach event handlers to Fix Now and Confirm buttons
	$('.fixNowBtn').click(handleFixNowClick);
	$('.btn-submit').click(handleConfirmClick);
});
