$(document).ready(function () {
	let selectedTr;
	let premiumPrices = {};

	const successElement = $('#successMsgModal');
	const errorElement = $('#errorMsgModal');
	const spinnerElement = $('#modalSpinner');

	// Initialize DataTables
	$('#domain-monitoring-list').dataTable();

	// Handle Fix Now button click
	$('.fixNowBtn').click(function () {
		// Extract data attributes
		selectedTr = $(this).closest('tr');
		const rowDataId = selectedTr.data('id');
		const domain = selectedTr.find('[data-domain]').data('domain');
		const type = selectedTr.data('type');
		const desc = selectedTr.find('[data-desc]').data('desc');

		// Populate modal content
		$('#domainModalLabel').text(domain);

		// Show spinner, hide messages
		successElement.hide();
		errorElement.hide();
		spinnerElement.show();

		// Ajax request for fetching price
		$.ajax({
			url: `${addonModuleLink}&action=fetchPrice`,
			method: 'GET',
			data: {
				id: rowDataId,
				type: type,
			},
			dataType: 'json',
			success: function (response) {
				// Handle successful response

				if (response?.success === false) {
					successElement.hide();
					spinnerElement.hide();
					errorElement.show().html(response.message);
					return;
				}

				// Build the success message with response data
				let priceText = '<br />New Prices Are As Shown Below:<br />';
				premiumPrices = {};
				if (response?.renew) {
					priceText +=
						'* Renew: ' + response.renew + ' ' + response.currency + '<br />';
					premiumPrices.renew = response.renew;
					premiumPrices.currency = response.currency;
				}

				if (response?.transfer) {
					priceText +=
						'* Transfer: ' + response.transfer + ' ' + response.currency;
					premiumPrices.transfer = response.transfer;
					premiumPrices.currency = response.currency;
				}

				const postText =
					`Kindly <strong>'Confirm'</strong> the pricing update by approving this pop-up.<br /><br />Once processed, you can reattempt the pending <strong>'${
						type === 'renew_premium_price_missing' ? 'Renewal' : 'Transfer'
					}'</strong> for the <strong>'${domain}'</strong> domain through Module Queue.<br /><br />` +
					`<small>* We'll be updating pricing details in tbldomains_extra. Keep in mind, WHMCS will factor in coupons, along with any additional costs like premium margin, DNS management, email forwarding, URL forwarding, etc. You can view the final recurring amount on the domain level after the update is complete.</small>`;
				errorElement.hide();
				spinnerElement.hide();
				successElement.html(
					desc +
						'<br /><strong>' +
						priceText +
						'</strong><br /><br />' +
						postText,
				);
				successElement.show();
			},
			error: function (xhr, status, error) {
				// Handle errors
				console.error(status + ': ', error);
				successElement.hide();
				spinnerElement.hide();
				errorElement.show().html(status + ': ' + error);
			},
		});
	});

	// Handle Confirm button click
	$('.btn-submit').click(function () {
		const rowDataId = selectedTr.data('id');
		const todoId = selectedTr.data('todoid');
		const domainId = selectedTr.data('domainid');
		const domainName = selectedTr.find('[data-domain]').data('domain');

		spinnerElement.show();
		successElement.html(
			'Sit tight while we work on updating domain prices and status for you...',
		);
		// Ajax request for updating price
		$.ajax({
			url: `${addonModuleLink}&action=updatePrice`,
			method: 'POST',
			data: {
				id: rowDataId,
				todoId: todoId,
				domainId: domainId,
				domainName: domainName,
				renewPrice: premiumPrices?.renew ?? '',
				transferPrice: premiumPrices?.transfer ?? '',
				currency: premiumPrices.currency,
			},
			dataType: 'json',
			success: function (response) {
				if (response?.success === false) {
					successElement.hide();
					spinnerElement.hide();
					errorElement.show().html(response.message);
					return;
				}

				// Handle successful response
				successElement.html(
					"Great news! We've successfully updated the domain prices and status for you. Your domains are now ready to Renew/Transfers!",
				);
				successElement.show();
				errorElement.hide();
				spinnerElement.hide();
				$('#domainFixModal').modal('hide');
				selectedTr.hide();
			},
			error: function (xhr, status, error) {
				// Handle errors
				console.error('Error:', error);
				successElement.hide();
				spinnerElement.hide();
				errorElement.show().html(error);
			},
		});
	});
});
