$(document).ready(function () {
	let selectedTr;
	let premiumPrices = {};
	const successElement = $('#successMsgModal');
	const errorElement = $('#errorMsgModal');
	const spinnerElement = $('#modalSpinner');
	const domainMonitoringList = $('#domain-monitoring-list');
	const submitButton = $('#domainFixModal .btn-submit');
	const hasPrice = (value) => value !== null && value !== '' && typeof value !== 'undefined' && Number.isFinite(Number(value));

	// Initialize DataTable
	const table = domainMonitoringList.DataTable({
		order: [[3, 'desc']],
		columnDefs: [{
			targets: 3,
			orderable: true,
		}],
	});

	function hasCompletePricing(pricing) {
		return hasPrice(pricing?.renew) && hasPrice(pricing?.transfer) && Boolean(pricing?.currency);
	}

	function pricingFromResponse(response) {
		const pricing = {
			renew: response?.renew,
			transfer: response?.transfer,
			currency: response?.currency,
		};
		return hasCompletePricing(pricing) ? pricing : null;
	}

	function showModalError(message, allowRetry = false) {
		successElement.hide();
		spinnerElement.hide();
		errorElement.show().html(message);
		submitButton.prop('disabled', !allowRetry).text('Apply & Recalculate');
	}

	function renderPriceReview(domain, issueType, pricing) {
		const pendingAction = issueType === 'renew_premium_price_missing' ? 'renewal' : 'transfer';
		successElement.html(`
			<p>Review the raw registrar costs returned for <strong>${domain}</strong>:</p>
			<div class="table-responsive">
				<table class="table table-bordered table-condensed cnic-price-review">
					<thead><tr><th>Operation</th><th class="text-right">New registrar cost</th></tr></thead>
					<tbody>
						<tr><td>Renewal</td><td class="text-right">${pricing.renew} ${pricing.currency}</td></tr>
						<tr><td>Transfer</td><td class="text-right">${pricing.transfer} ${pricing.currency}</td></tr>
					</tbody>
				</table>
			</div>
			<div class="alert alert-info cnic-text-small">
				Applying this update stores these registrar costs, marks the domain as premium, and asks WHMCS to recalculate the customer-facing recurring amount. Existing invoices are unchanged.
			</div>
			<p>After reviewing the updated billing, retry the pending <strong>${pendingAction}</strong> from the Module Queue.</p>
		`);
		successElement.show();
		spinnerElement.hide();
		submitButton.prop('disabled', false);
	}

	function renderCompletedRow(domainId) {
		selectedTr.find('[data-status]').html('<span class="badge badge-success cnic-custom-badge-success">Updated Successfully</span>');
		selectedTr.find('[data-desc]').html(
			`<p>The registrar costs have been updated and WHMCS has recalculated the domain's recurring amount.</p>
                <p>Review the domain's <a target="_blank" style="text-decoration:underline"
                    href="./clientsdomains.php?id=${domainId}">billing details</a> before retrying the pending module action.</p>
                <p class="text-muted">Existing invoices are not recalculated automatically and may need to be cancelled and reissued.</p>`,
		);
		selectedTr.find('[data-actions]').html(`<button type="button" class="btn btn-danger btn-sm deleteBtn">
                <i class="fas fa-trash-alt"></i> Delete</button>`);
		selectedTr.attr('data-status', 'Completed').data('status', 'Completed');
		table.row(selectedTr).invalidate('dom').draw(false);
	}

	// Create the status filter element
	var statusFilterHtml = `
		<label for="statusFilter" class="control-label">Status:</label>
		<select id="statusFilter" class="form-control">
			<option value="">All</option>
			<option value="Updated Successfully">Completed</option>
			<option value="Pending">Pending</option>
		</select>
	`;

	// Append the status filter to the DataTables filter container
	$('#domain-monitoring-list_filter').append(statusFilterHtml);

	// Custom filter for status
	$.fn.dataTable.ext.search.push(
		function (settings, data, dataIndex) {
			const statusFilter = $('#statusFilter').val();
			const status = data[3]; // Assuming status is in the 4th column (index 3)

			if (statusFilter === "" || status.includes(statusFilter)) {
				return true;
			}
			return false;
		}
	);

	// Event listener for the status filter
	$('#statusFilter').change(function () {
		table.draw();
	});

	// Handle Fix Now button click
	function handleFixNowClick() {
		selectedTr = $(this).closest('tr');
		premiumPrices = {};
		const rowDataId = selectedTr.data('id');
		const domain = selectedTr.find('[data-domain]').data('domain');
		const type = selectedTr.data('type');

		$('#cnicDomainModalLabel').text(`Review premium pricing — ${domain}`);
		successElement.hide();
		errorElement.hide();
		spinnerElement.show();
		submitButton.prop('disabled', true).text('Apply & Recalculate');

		$.ajax({
			url: `${addonModuleLink}&action=fetchPrice`,
			method: 'GET',
			data: { id: rowDataId, type: type },
			dataType: 'json',
			success: function (response) {
				if (response?.success === false) {
					showModalError(response.message);
					return;
				}

				const pricing = pricingFromResponse(response);
				if (!pricing) {
					showModalError('The registrar did not return complete renewal and transfer pricing.');
					return;
				}

				premiumPrices = pricing;
				renderPriceReview(domain, type, pricing);
			},
			error: function (xhr, status, error) {
				console.error('AJAX Error:', { status, error, response: xhr.responseText });
				const errorMessage = xhr.responseJSON?.message || 'Failed to fetch pricing information. Please try again or contact support.';
				showModalError(`<strong>Error:</strong> ${errorMessage}`);
			},
		});
	}

	// Handle Confirm button click
	function handleConfirmClick() {
		if (!selectedTr || !hasCompletePricing(premiumPrices)) {
			return;
		}

		const rowDataId = selectedTr.data('id');
		const todoId = selectedTr.data('todoid');
		const domainId = selectedTr.data('domainid');
		const domainName = selectedTr.find('[data-domain]').data('domain');
		const domainRegistrar = selectedTr.find('[data-registrar]').data('registrar');

		spinnerElement.show();
		successElement.html('Updating registrar costs and recalculating the recurring amount...');
		submitButton.prop('disabled', true).text('Applying...');

		$.ajax({
			url: `${addonModuleLink}&action=updatePrice`,
			method: 'POST',
			data: {
				id: rowDataId,
				todoId: todoId,
				domainId: domainId,
				domainName: domainName,
				domainRegistrar: domainRegistrar,
				renewPrice: premiumPrices?.renew ?? '',
				transferPrice: premiumPrices?.transfer ?? '',
				currency: premiumPrices.currency,
			},
			dataType: 'json',
			success: function (response) {
				if (response?.success === false) {
					showModalError(response.message, true);
					return;
				}

				successElement.html("Great news! We've successfully updated the domain prices...");
				successElement.show();
				errorElement.hide();
				spinnerElement.hide();
				$('#domainFixModal').modal('hide');
				renderCompletedRow(domainId);
			},
			error: function (xhr, status, error) {
				console.error('Error:', error);
				showModalError(error, true);
			},
		});
	}

	// Event delegation for delete button click
	$(document).on('click', '.deleteBtn', function () {
		selectedTr = $(this).closest('tr');
		const todoId = selectedTr.data('todoid');

		$.ajax({
			url: `${addonModuleLink}&action=deleteRecord`,
			method: 'POST',
			data: { id: todoId },
			dataType: 'json',
			success: function (response) {
				table.row(selectedTr).remove().draw(false);
			},
			error: function (xhr, status, error) {
				console.error('Error:', error);
			},
		});
	});

	// Attach event handlers to Fix Now and Confirm buttons using event delegation
	domainMonitoringList.on('click', '.fixNowBtn', handleFixNowClick);
	$('#domainFixModal').on('click', '.btn-submit', handleConfirmClick);

	// Properly manage aria-hidden attribute for modal accessibility and reset state
	$('#domainFixModal').on('show.bs.modal', function() {
		$(this).removeAttr('aria-hidden');
	}).on('hidden.bs.modal', function() {
		$(this).attr('aria-hidden', 'true');
		// Reset modal content to prevent stale data
		successElement.hide().empty();
		errorElement.hide().empty();
		spinnerElement.hide();
		submitButton.prop('disabled', true).text('Apply & Recalculate');
		selectedTr = null;
		premiumPrices = {};
	});
});
