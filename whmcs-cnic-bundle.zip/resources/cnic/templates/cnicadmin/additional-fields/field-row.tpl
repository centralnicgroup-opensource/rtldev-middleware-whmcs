<div class="cnic-field-row {$rowClass}" data-field-type="{$type}" data-field-name="{$fieldKey|escape:'html'}">
    <div class="cnic-field-header">
        <div class="cnic-field-label-wrapper">
            <label class="cnic-field-label">
                {$field.label|unescape:'html'}
                {if strpos($field.html, 'required') !== false}
                    <span class="cnic-required-badge">Required</span>
                {/if}
            </label>
        </div>
        <div class="cnic-field-visibility">
            <span class="cnic-visibility-label">Visibility</span>
            <div class="cnic-toggle-wrapper">
                <input type="hidden" name="toggle_{$fieldKey|escape:'html'}" value="{$field.visibility}" class="toggle-hidden" />
                <input type="checkbox" class="cnic-toggle" data-hidden="toggle_{$fieldKey|escape:'html'}"
                    {if $field.visibility === 1}checked{/if} />
                <label class="cnic-toggle-label"></label>
            </div>
        </div>
    </div>
    <div class="cnic-field-input">
        <span class="cnic-field-sublabel">Default value</span>
        {$field.html|unescape:'html'|replace:'form-control':'form-control cnic-input'}
    </div>
    {if isset($helpTexts[$fieldKey])}
        <div class="cnic-field-help">
            <i class="fas fa-solid fa-info-circle"></i>
            <span>{$helpTexts[$fieldKey]}</span>
        </div>
    {/if}
</div>