<div class="fields-configuration-panel">
    <div class="panel-heading cnic-panel-header cnic-panel-header-with-picker">
        <h4 class="panel-title">
            <div class="cnic-icon-wrapper blue">
                <i class="fas fa-solid fa-cogs"></i>
            </div>
            Additional Fields for {$tld|escape}
        </h4>
        <div class="cnic-mode-switch" role="group" aria-label="What to configure">
            <button type="button" class="cnic-mode-btn active" data-mode="defaults">
                <i class="fas fa-solid fa-sliders-h"></i> Default values
            </button>
            <button type="button" class="cnic-mode-btn" data-mode="validation">
                <i class="fas fa-solid fa-check-double"></i> Validation
            </button>
            {if isset($languages) && count($languages) > 0}
                <button type="button" class="cnic-mode-btn" data-mode="translations">
                    <i class="fas fa-solid fa-language"></i> Translations
                </button>
                <select id="fieldTextsLanguage" class="form-control input-sm" data-tld="{$tld|escape}" aria-label="Client language" style="display: none;">
                    {foreach from=$languages item=language}
                        <option value="{$language|escape}"{if $language == $defaultLanguage} selected{/if}>{$language|escape|ucfirst}</option>
                    {/foreach}
                </select>
            {/if}
        </div>
    </div>
    <div class="panel-body cnic-card-body">
        <form id="saveFieldsForm" method="post" action="" class="cnic-form">
            <input type="hidden" name="action" value="saveAdditionalFieldsData">
            <input type="hidden" name="tld" value="{$tld|escape}">
            <div class="cnic-field-texts-notice">
                <span><i class="fas fa-solid fa-info-circle"></i> Applies only while {$tld|escape} is assigned to a CNIC registrar module (cnic, cnic1, cnic2, ...) in Domain Pricing.</span>
                {if $validationEnabled}
                    <span class="cnic-check-state" title="Additional Fields Validation is enabled in the {$registrarId|escape} registrar module, format checks run on the domain configuration step of the cart.">
                        <span class="cnic-check-chip cnic-check-chip--auto">Format checks active</span>
                    </span>
                {else}
                    <span class="cnic-check-state">
                        <span class="cnic-check-chip cnic-check-chip--warning">Format checks off</span>
                        enable <a href="configregistrars.php" target="_blank">Additional Fields Validation</a> in the {$registrarId|escape} module
                    </span>
                {/if}
            </div>
            <div class="cnic-validation-intro">
                Catch typing mistakes before checkout. Phone, email and date fields are checked automatically, unless you turn that off.
                For other fields you can set a rule - customers see it as a hint under the field and get a clear message if their entry does not fit.
            </div>
            <div id="fieldTextsNotice" class="cnic-tr-toolbar" style="display: none;"></div>

            {if isset($errorMessage)}
                <div class="alert alert-danger">
                    <div class="alert-content">
                        <i class="fas fa-solid fa-exclamation-triangle"></i>
                        <div>
                            <strong>Error:</strong> {$errorMessage}
                        </div>
                    </div>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            {/if}

            {if isset($successMessage)}
                <div class="alert alert-success">
                    <div class="alert-content">
                        <i class="fas fa-solid fa-check-circle"></i>
                        <div>
                            <strong>Success:</strong> {$successMessage}
                        </div>
                    </div>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            {/if}

        {if isset($fields) && count($fields) > 0}
            {* Sort fields by name (label) and hide the sort result *}
            {assign var="sortedKeys" value=array_keys($fields)}
            {assign var="sortResult" value=$sortedKeys|@sort}

            {* Group fields by type for better organization *}
            {assign var="acceptFields" value=[]}
            {assign var="registrantFields" value=[]}
            {assign var="otherFields" value=[]}

            {foreach from=$sortedKeys item=fieldKey}
                {assign var="fieldLabel" value=$fields[$fieldKey].label}
                {if strpos($fieldLabel, 'Accept') !== false}
                    {append var="acceptFields" value=$fieldKey}
                {elseif strpos($fieldLabel, 'Registrant') !== false}
                    {append var="registrantFields" value=$fieldKey}
                {else}
                    {append var="otherFields" value=$fieldKey}
                {/if}
            {/foreach}

            <div class="field-group-container">
                {if count($acceptFields) > 0}
                    <div class="cnic-form-section">
                        <div class="field-group-header">
                            <h5 class="field-group-title">
                                <div class="cnic-icon-wrapper green">
                                    <i class="fas fa-solid fa-check-circle"></i>
                                </div>
                                Contract Acceptance
                            </h5>
                        </div>
                        <div class="field-group-body">
                            <div class="fields-grid">
                                {foreach from=$acceptFields item=fieldKey}
                                    {include file="additional-fields/field-row.tpl"
                                        fieldKey=$fieldKey
                                        field=$fields[$fieldKey]
                                        rowClass="field-accept field-full"
                                        type="accept"
                                        helpTexts=$helpTexts
                                    }
                                {/foreach}
                            </div>
                        </div>
                    </div>
                {/if}
                
                {if count($registrantFields) > 0}
                    <div class="cnic-form-section">
                        <div class="field-group-header">
                            <h5 class="field-group-title">
                                <div class="cnic-icon-wrapper blue">
                                    <i class="fas fa-solid fa-user"></i>
                                </div>
                                Registrant Information
                            </h5>
                        </div>
                        <div class="field-group-body">
                            <div class="fields-grid">
                                {foreach from=$registrantFields item=fieldKey}
                                    {include file="additional-fields/field-row.tpl"
                                        fieldKey=$fieldKey
                                        field=$fields[$fieldKey]
                                        rowClass="field-registrant"
                                        type="registrant"
                                        helpTexts=$helpTexts
                                    }
                                {/foreach}
                            </div>
                        </div>
                    </div>
                {/if}
                
                {if count($otherFields) > 0}
                    <div class="cnic-form-section">
                        {if count($acceptFields) > 0 || count($registrantFields) > 0}
                            <div class="field-group-header">
                                <h5 class="field-group-title">
                                    <div class="cnic-icon-wrapper purple">
                                        <i class="fas fa-solid fa-list-alt"></i>
                                    </div>
                                    Additional Information
                                </h5>
                            </div>
                        {/if}
                        <div class="field-group-body">
                            <div class="fields-grid">
                                {foreach from=$otherFields item=fieldKey}
                                    {include file="additional-fields/field-row.tpl"
                                        fieldKey=$fieldKey
                                        field=$fields[$fieldKey]
                                        rowClass="field-other"
                                        type="other"
                                        helpTexts=$helpTexts
                                    }
                                {/foreach}
                            </div>
                        </div>
                    </div>
                {/if}
            </div>

            {* Validation tab: one list of all text fields and how customers' entries are checked *}
            <div class="cnic-validation-panel">
                <div class="cnic-check-summary"></div>
                <div class="cnic-check-list">
                    {assign var="checkableFields" value=0}
                    {foreach from=$sortedKeys item=fieldKey}
                        {assign var="field" value=$fields[$fieldKey]}
                        {if $field.type === "text"}
                            {assign var="checkableFields" value=$checkableFields+1}
                            {assign var="format" value=$field.format}
                            {assign var="formatKey" value=$fieldKey|escape:'html'}
                            {if $field.valueType == "PHONE" || $field.valueType == "EMAIL" || $field.valueType == "DATE"}
                                <div class="cnic-check-row cnic-format-auto">
                                    <div class="cnic-check-main">
                                        <div class="cnic-check-field">{$field.label|unescape:'html'}</div>
                                        <div class="cnic-check-rule" data-rule="{if $field.valueType == "PHONE"}A phone number with country code, written as +CC.NUMBER{elseif $field.valueType == "EMAIL"}An email address{else}A date, written as YYYY-MM-DD{/if}"></div>
                                    </div>
                                    <div class="cnic-check-side">
                                        <span class="cnic-check-chip cnic-check-chip--warning cnic-check-unsaved">Not saved yet</span>
                                        <span class="cnic-check-example">{if $field.valueType == "PHONE"}+45.12345678{elseif $field.valueType == "EMAIL"}name@example.com{else}2026-12-31{/if}</span>
                                        <span class="cnic-check-chip cnic-format-chip" title="Set by the field type the registry uses"></span>
                                        <button type="button" class="cnic-btn cnic-format-off-toggle"></button>
                                    </div>
                                    <input type="hidden" name="format_{$formatKey}[off]" value="{if $format.off|default:false}1{/if}" class="cnic-format-off" />
                                </div>
                            {else}
                                {assign var="formatChars" value=$format.chars|default:''}
                                <div class="cnic-check-row cnic-format">
                                    <div class="cnic-check-main">
                                        <div class="cnic-check-field">{$field.label|unescape:'html'}</div>
                                        <div class="cnic-check-rule cnic-format-summary"></div>
                                    </div>
                                    <div class="cnic-check-side">
                                        <span class="cnic-check-chip cnic-check-chip--warning cnic-check-unsaved">Not saved yet</span>
                                        <span class="cnic-check-example cnic-format-example"></span>
                                        <span class="cnic-check-chip cnic-format-chip"></span>
                                        <button type="button" class="cnic-btn cnic-format-toggle"></button>
                                    </div>
                                    <div class="cnic-format-editor" style="display: none;">
                                        <div class="cnic-format-step">
                                            <span class="cnic-format-question">Which characters may customers use?</span>
                                            <div class="cnic-segmented" role="radiogroup">
                                                <label><input type="radio" name="format_{$formatKey}[chars]" value="digits" class="cnic-format-part" data-part="chars"{if $formatChars == "digits"} checked{/if} /><span>Digits</span></label>
                                                <label><input type="radio" name="format_{$formatKey}[chars]" value="letters" class="cnic-format-part" data-part="chars"{if $formatChars == "letters"} checked{/if} /><span>Letters</span></label>
                                                <label><input type="radio" name="format_{$formatKey}[chars]" value="alnum" class="cnic-format-part" data-part="chars"{if $formatChars == "alnum"} checked{/if} /><span>Letters &amp; digits</span></label>
                                            </div>
                                        </div>
                                        <div class="cnic-format-step">
                                            <span class="cnic-format-question">How many characters?</span>
                                            <div class="cnic-format-inline">
                                                <input type="number" min="1" max="255" name="format_{$formatKey}[min]" value="{$format.min|default:''|escape:'html'}"
                                                    class="cnic-format-input cnic-format-part" data-part="min" placeholder="any" aria-label="At least" />
                                                <span>to</span>
                                                <input type="number" min="1" max="255" name="format_{$formatKey}[max]" value="{if $format.max|default:0 > 0}{$format.max|escape:'html'}{/if}"
                                                    class="cnic-format-input cnic-format-part" data-part="max" placeholder="any" aria-label="At most" />
                                            </div>
                                        </div>
                                        <div class="cnic-format-step">
                                            <span class="cnic-format-question">Must it start with a fixed text, like a country code? <small>Leave empty if not.</small></span>
                                            <div class="cnic-format-inline">
                                                <input type="text" name="format_{$formatKey}[prefix]" value="{$format.prefix|default:''|escape:'html'}"
                                                    class="cnic-format-input cnic-format-part" data-part="prefix" placeholder="e.g. DK" autocomplete="off" aria-label="Fixed start" />
                                                <span class="cnic-format-prefix-note"></span>
                                            </div>
                                        </div>
                                        <div class="cnic-format-step cnic-format-try">
                                            <span class="cnic-format-question">Try it</span>
                                            <div class="cnic-format-inline">
                                                <input type="text" class="cnic-format-input cnic-format-try-input" placeholder="Type a value a customer would enter" autocomplete="off" aria-label="Try a value" />
                                                <span class="cnic-format-try-result"></span>
                                            </div>
                                        </div>
                                        <div class="cnic-format-footer">
                                            <span class="cnic-format-preview"></span>
                                            <span class="cnic-format-actions">
                                                <button type="button" class="cnic-btn cnic-btn--link cnic-format-remove">Remove rule</button>
                                                <button type="button" class="cnic-btn cnic-btn--primary cnic-format-done">Done</button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            {/if}
                        {/if}
                    {/foreach}
                    {if $checkableFields == 0}
                        <div class="cnic-check-row cnic-check-empty">{$tld|escape} has no free text fields: its other fields only offer the registry's own choices.</div>
                    {/if}
                </div>
            </div>
        {else}
            <div class="alert alert-info">
                <div class="alert-content">
                    <i class="fas fa-solid fa-info-circle"></i>
                    <div>
                        <strong>No Additional Fields Required</strong>
                        <p>This TLD does not require any additional fields for registration.</p>
                    </div>
                </div>
            </div>
        {/if}
        </form>
    </div>
    
    {* Action buttons moved to card footer *}
    <div class="panel-footer additional-fields-form-actions">
        <button type="submit" id="saveFieldsButton" class="btn btn-gradient-primary btn-lg hover-lift-modern" form="saveFieldsForm"
            data-loading-text="<i class='fas fa-solid fa-spinner fa-spin'></i> Saving...">
            <i class="fas fa-solid fa-save" style="margin-right: 10px;"></i>
            Save Fields
        </button>
        <button type="button" id="cancelButton" class="btn btn-default btn-lg hover-lift-modern">
            <i class="fas fa-solid fa-times" style="margin-right: 10px;"></i>
            Cancel
        </button>
        <button type="button" id="loadTraditionalPhpButton" class="btn btn-info btn-lg hover-lift-modern" style="float: right;" data-tld="{$tld|escape}">
            <i class="fas fa-solid fa-code" style="margin-right: 10px;"></i>
            Load Traditional PHP Code for Additional Fields
        </button>
    </div>
</div>