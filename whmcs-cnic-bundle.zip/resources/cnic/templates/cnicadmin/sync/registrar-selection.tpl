<!-- Step 1: Registrar Selection -->
<div id="step1" class="cnic-step active">
    <!-- Progress Steps -->
    {include file="sync/includes/progress-steps.tpl" currentStep=1 completedSteps=[]}

    <form id="domainSyncForm" role="form">
        <!-- Modern Registrar Selection Panel -->
        <div class="panel panel-modern">
            <div class="panel-heading cnic-panel-header">
                <h4 class="panel-title">
                    <div class="cnic-icon-wrapper orange">
                        <i class="fas fa-solid fa-server"></i>
                    </div>
                    Registrar Selection
                    <div class="panel-badge">
                        Step 1
                    </div>
                </h4>
            </div>
            <div class="panel-body cnic-card-body">
                {include file="shared/registrar-selector.tpl"
                    registrarSelectorTitle="Choose Your Registrar"
                    registrarSelectorDescription="Select the registrar you want to synchronize domain expiry dates from"
                    registrarSelectorShowLabel=false
                    registrarSelectorButtonEnabled=true
                    registrarSelectorButtonVisibleWhenSingle=true
                    registrarSelectorButtonClass="btn btn-gradient-primary validate-registrar-btn"
                    registrarSelectorButtonLabel="Continue"
                    registrarSelectorWrapperClass="margin-bottom-0"
                }

                <div class="alert alert-info" style="margin-top: 20px;">
                    <div class="alert-content">
                        <i class="fas fa-solid fa-lightbulb"></i>
                        <div>
                            {if $supportedRegistrars|@count eq 1}
                                <strong>Registrar Selection:</strong> Click "Continue" to proceed to sync configuration. Domain validation will happen on the server side.
                            {else}
                                <strong>Registrar Selection:</strong> Select your registrar from the dropdown above and
                                click "Continue" to proceed to sync configuration. Domain validation will happen on the server side.
                            {/if}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- End Step 1 -->