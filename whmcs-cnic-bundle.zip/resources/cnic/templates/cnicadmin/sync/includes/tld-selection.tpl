{* TLD Selection Section - Enhanced UI for TLD-specific domain synchronization *}
<div class="form-group tld-selection-group" id="tldInput" style="display: none;">
    <div class="sync-section-header">
        <label class="control-label">
            <i class="fas fa-solid fa-search text-purple"></i> Search TLD for Domain Filtering
        </label>
        <p class="help-block">
            Type the TLD extension to search - no need to load all TLDs
        </p>
    </div>

    <div class="cnic-section tld-selection-section">
        {* TLD Search Form *}
        <div class="tld-search-wrapper">
            <div class="input-group input-group-modern">
                <span class="input-group-addon">
                    <i class="fas fa-solid fa-search text-purple"></i>
                </span>
                <input type="text" id="tldSearchInput" name="tldSearch" class="form-control form-control-modern"
                    placeholder="Enter TLD (e.g., .com, .net, .org)..." autocomplete="off">
                <span class="input-group-btn">
                    <button type="button" id="tldSearchBtn" class="btn btn-primary">
                        <i class="fas fa-solid fa-search"></i> Search
                    </button>
                </span>
            </div>
            <div id="tldSearchResults" class="tld-search-results" style="display: none;">
                <!-- Autocomplete results will appear here -->
            </div>
        </div>

        {* Hidden field to store selected TLD *}
        <input type="hidden" id="selectedTld" name="tld" value="">
        
        {* Display selected TLD *}
        <div id="selectedTldDisplay" class="selected-tld-display" style="display: none;">
            <div class="alert alert-success">
                <div class="alert-content">
                    <i class="fas fa-solid fa-check-circle"></i>
                    <div>
                        <strong>Selected TLD:</strong> 
                        <span id="selectedTldName"></span>
                        <br>
                        <small>Will sync all domains with this extension</small>
                    </div>
                    <button type="button" class="btn btn-xs btn-default" id="clearTldSelection">
                        <i class="fas fa-solid fa-times"></i> Clear
                    </button>
                </div>
            </div>
        </div>

        {* Enhanced Info Alert *}
        <div class="alert alert-modern alert-info tld-info-alert">
            <div class="alert-icon">
                <i class="fas fa-solid fa-info-circle"></i>
            </div>
            <div class="alert-content">
                <div class="alert-title">
                    <strong>TLD-Specific Synchronization</strong>
                </div>
                <div class="alert-description">
                    Enter the TLD extension (e.g., .com, .net) or start typing for suggestions. 
                    All domains with the selected extension will be synchronized. 
                    This allows you to synchronize all domains of a specific type (e.g., all .com or .it domains).
                </div>
            </div>
        </div>
    </div>
</div>