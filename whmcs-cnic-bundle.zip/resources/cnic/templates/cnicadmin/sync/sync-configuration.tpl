<!-- Step 2: Sync Configuration -->
<div id="step2" class="cnic-step">
    <!-- Progress Steps -->
    {include file="sync/includes/progress-steps.tpl" currentStep=2 completedSteps=[1]}

    <form id="syncForm" role="form">
        <!-- Enhanced Registrar Status -->
        <div class="alert alert-success sync-success-alert">
            <div class="row cnic-align-items-center">
                <div class="col-sm-8">
                    <div class="sync-success-content">
                        <div class="sync-success-icon">
                            <i class="fas fa-solid fa-check-circle"></i>
                        </div>
                        <div class="sync-success-text">
                            <strong>Successfully Connected</strong>
                            <div class="sync-success-details">
                                <span id="selectedRegistrarName">-</span>
                                <span class="separator">•</span>
                                <span id="domainCount">0</span> domains ready for sync
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 text-right">
                    <div class="sync-ready-badge">
                        <small>Ready to sync</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modern Synchronization Options Panel -->
        <div class="panel panel-modern sync-options-panel">
            <div class="panel-heading cnic-panel-header">
                <h4 class="panel-title">
                    <span>
                        <div class="cnic-icon-wrapper blue">
                            <i class="fas fa-solid fa-sliders-h"></i>
                        </div>
                        Synchronization Options
                    </span>
                    <div class="panel-badge">
                        Step 2
                    </div>
                </h4>
            </div>
            <div class="panel-body cnic-card-body">
                <!-- Enhanced Sync Type Selection -->
                <h5 class="cnic-subsection-title">
                    <i class="fas fa-solid fa-list"></i>
                    Choose Sync Method
                </h5>
                <p class="help-block">
                    Select how you want to synchronize domain expiry dates with your registrar
                </p>

                    <div class="row choice-cards-container">
                        <div class="col-sm-4 choice-card-wrapper" id="allDomainsWrapper">
                            <div class="radio">
                                <label class="cnic-choice-card" data-value="all">
                                    <input type="radio" name="syncType" value="all" checked class="choice-input">
                                    <div class="choice-content">
                                        <div class="choice-header">
                                            <div class="choice-icon">
                                                <div class="cnic-icon-wrapper blue">
                                                    <i class="fas fa-solid fa-globe"></i>
                                                    
                                                </div>
                                            </div>
                                            <div class="choice-info">
                                                <div class="choice-title">
                                                    <strong>All Domains</strong>
                                                </div>
                                                <div class="choice-description">
                                                    Synchronize expiry dates for all domains from your registrar account
                                                </div>
                                            </div>
                                            <div class="choice-indicator">
                                                <i class="far fa-regular fa-circle"></i>
                                            </div>
                                        </div>
                                        <div class="choice-recommendation">
                                            <small>
                                                <i class="fas fa-solid fa-info-circle"></i>
                                                Recommended for bulk operations
                                            </small>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div class="col-sm-4 choice-card-wrapper" id="singleDomainWrapper">
                            <div class="radio">
                                <label class="cnic-choice-card" data-value="single">
                                    <input type="radio" name="syncType" value="single" class="choice-input">
                                    <div class="choice-content">
                                        <div class="choice-header">
                                            <div class="choice-icon">
                                                <div class="cnic-icon-wrapper green">
                                                    <i class="fas fa-solid fa-crosshairs"></i>
                                                </div>
                                            </div>
                                            <div class="choice-info">
                                                <div class="choice-title">
                                                    <strong>Single Domain</strong>
                                                </div>
                                                <div class="choice-description">
                                                    Select and synchronize a specific domain from the list below
                                                </div>
                                            </div>
                                            <div class="choice-indicator">
                                                <i class="far fa-regular fa-circle"></i>
                                            </div>
                                        </div>
                                        <div class="choice-recommendation">
                                            <small>
                                                <i class="fas fa-solid fa-search"></i>
                                                Ideal for targeted sync operations
                                            </small>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div class="col-sm-4 choice-card-wrapper" id="tldDomainsWrapper">
                            <div class="radio">
                                <label class="cnic-choice-card" data-value="tld">
                                    <input type="radio" name="syncType" value="tld" class="choice-input">
                                    <div class="choice-content">
                                        <div class="choice-header">
                                            <div class="choice-icon">
                                                <div class="cnic-icon-wrapper purple">
                                                    <i class="fas fa-solid fa-filter"></i>
                                                </div>
                                            </div>
                                            <div class="choice-info">
                                                <div class="choice-title">
                                                    <strong>TLD-Specific</strong>
                                                </div>
                                                <div class="choice-description">
                                                    Synchronize all domains with a specific TLD extension
                                                </div>
                                            </div>
                                            <div class="choice-indicator">
                                                <i class="far fa-regular fa-circle"></i>
                                            </div>
                                        </div>
                                        <div class="choice-recommendation">
                                            <small>
                                                <i class="fas fa-solid fa-layer-group"></i>
                                                Perfect for TLD-focused management
                                            </small>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>

                <!-- Enhanced Domain Search (No Pre-loading) -->
                <div class="form-group domain-selection-group" id="domainInput" style="display: none;">
                    <div class="sync-section-header">
                        <label class="control-label">
                            <i class="fas fa-solid fa-search"></i> Search Domain to Sync
                        </label>
                        <p class="help-block">
                            Type the domain name and search - no need to load all domains
                        </p>
                    </div>

                    <div class="cnic-section domain-selection-section">
                        <div class="domain-search-wrapper">
                            <div class="input-group input-group-modern">
                                <span class="input-group-addon">
                                    <i class="fas fa-solid fa-search"></i>
                                </span>
                                <input type="text" id="domainSearchInput" name="domainSearch" class="form-control form-control-modern"
                                    placeholder="Enter domain name (e.g., example.com)..." autocomplete="off">
                                <span class="input-group-btn">
                                    <button type="button" id="domainSearchBtn" class="btn btn-primary">
                                        <i class="fas fa-solid fa-search"></i> Search
                                    </button>
                                </span>
                            </div>
                            <div id="domainSearchResults" class="domain-search-results" style="display: none;">
                                <!-- Autocomplete results will appear here -->
                            </div>
                        </div>

                        <!-- Hidden field to store selected domain ID -->
                        <input type="hidden" id="selectedDomainId" name="domainId" value="">
                        
                        <!-- Display selected domain -->
                        <div id="selectedDomainDisplay" class="selected-domain-display" style="display: none;">
                            <div class="alert alert-success">
                                <div class="alert-content">
                                    <i class="fas fa-solid fa-check-circle"></i>
                                    <div>
                                        <strong>Selected Domain:</strong> 
                                        <span id="selectedDomainName"></span>
                                        <br>
                                        <small>Expiry Date: <span id="selectedDomainExpiry"></span></small>
                                    </div>
                                    <button type="button" class="btn btn-xs btn-default" id="clearDomainSelection">
                                        <i class="fas fa-solid fa-times"></i> Clear
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info domain-info-alert">
                            <div class="alert-content">
                                <i class="fas fa-solid fa-lightbulb"></i>
                                <div>
                                    <strong>Single Domain Mode:</strong> Enter the exact domain name or start typing for suggestions. 
                                    Only the matching domain will be synced - no need to load thousands of domains.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TLD Selection Section -->
                {include file="sync/includes/tld-selection.tpl"}
            </div>
        </div>

        <!-- Processing Configuration Panel -->
        <div class="panel panel-modern">
            <div class="panel-heading cnic-panel-header">
                <h4 class="panel-title">
                    <span>
                        <div class="cnic-icon-wrapper green">
                            <i class="fas fa-solid fa-cogs"></i>
                        </div>
                        Processing Configuration
                    </span>
                    <div class="panel-badge">
                        Performance
                    </div>
                </h4>
            </div>
            <div class="panel-body cnic-card-body">
                <!-- Server-Side Processing Information -->
                <h5 class="cnic-subsection-title">
                    <i class="fas fa-solid fa-server"></i>
                    Server-Side Batch Processing
                </h5>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info domain-info-alert">
                            <div class="alert-content">
                                <i class="fas fa-solid fa-info-circle"></i>
                                <div>
                                    <strong>How it works:</strong> Domains are processed in batches of 5 on the server. 
                                    The progress is displayed in real-time as each batch completes. This approach:
                                    <ul style="margin-top: 8px; margin-bottom: 0;">
                                        <li>Prevents browser memory issues with large domain counts (10k+)</li>
                                        <li>Provides reliable progress tracking</li>
                                        <li>Continues processing even if you navigate away</li>
                                        <li>Shows only failed syncs in the results table</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Advanced Options Section -->
                <hr class="cnic-divider">
                <h5 class="cnic-subsection-title">
                    <i class="fas fa-solid fa-exclamation-triangle text-warning"></i>
                    Advanced Options
                </h5>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" id="forceUpdateExpiryDate" name="forceUpdateExpiryDate" value="1">
                                    <strong>Force Update Expiry date</strong>
                                </label>
                            </div>
                            <p class="help-block">
                                <i class="fas fa-solid fa-info-circle"></i>
                                Can be helpful in scenarios where the expiry date is up to dated on WHMCS but the next due date needs to be refreshed.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Enhanced Action Buttons -->
        <div class="sync-actions-section">
            <div class="sync-action-buttons">
                <button type="button" class="btn btn-default hover-lift-modern sync-prev-button" id="prevButtonStep2"
                    data-step="1">
                    <i class="fas fa-solid fa-arrow-left" style="margin-right: 10px;"></i> Previous Step
                </button>
                <button type="button" class="btn btn-gradient-primary hover-lift-modern sync-start-button">
                    <i class="fas fa-solid fa-rocket" style="margin-right: 10px;"></i><span class="btn-text">Start
                        Synchronization</span>
                </button>
            </div>
        </div>
    </form>
</div>
<!-- End Step 2 -->