{*
 * Shared registrar selector for CNIC Admin pages.
 *
 * Required variables:
 * - $supportedRegistrars
 * - $selectedRegistrar
 *
 * Optional variables:
 * - $registrarSelectorTitle
 * - $registrarSelectorDescription
 * - $registrarSelectorIcon
 * - $registrarSelectorId
 * - $registrarSelectorName
 * - $registrarSelectorLabel
 * - $registrarSelectorPlaceholder
 * - $registrarSelectorHelp
 * - $registrarSelectorShowLabel
 * - $registrarSelectorButtonEnabled
 * - $registrarSelectorButtonVisibleWhenSingle
 * - $registrarSelectorButtonId
 * - $registrarSelectorButtonClass
 * - $registrarSelectorButtonLabel
 * - $registrarSelectorButtonIcon
 * - $registrarSelectorAriaLabel
 * - $registrarSelectorInputGroupClass
 * - $registrarSelectorWrapperClass
 *}

{if !isset($registrarSelectorTitle)}{assign var="registrarSelectorTitle" value=""}{/if}
{if !isset($registrarSelectorDescription)}{assign var="registrarSelectorDescription" value=""}{/if}
{if !isset($registrarSelectorIcon)}{assign var="registrarSelectorIcon" value="fas fa-solid fa-server"}{/if}
{if !isset($registrarSelectorId)}{assign var="registrarSelectorId" value="registrar"}{/if}
{if !isset($registrarSelectorName)}{assign var="registrarSelectorName" value="registrar"}{/if}
{if !isset($registrarSelectorLabel)}{assign var="registrarSelectorLabel" value="Registrar"}{/if}
{if !isset($registrarSelectorPlaceholder)}{assign var="registrarSelectorPlaceholder" value="Choose a registrar..."}{/if}
{if !isset($registrarSelectorHelp)}{assign var="registrarSelectorHelp" value=""}{/if}
{if !isset($registrarSelectorShowLabel)}{assign var="registrarSelectorShowLabel" value=true}{/if}
{if !isset($registrarSelectorButtonEnabled)}{assign var="registrarSelectorButtonEnabled" value=false}{/if}
{if !isset($registrarSelectorButtonVisibleWhenSingle)}{assign var="registrarSelectorButtonVisibleWhenSingle" value=false}{/if}
{if !isset($registrarSelectorButtonId)}{assign var="registrarSelectorButtonId" value=""}{/if}
{if !isset($registrarSelectorButtonClass)}{assign var="registrarSelectorButtonClass" value="btn btn-gradient-primary hover-lift-modern"}{/if}
{if !isset($registrarSelectorButtonLabel)}{assign var="registrarSelectorButtonLabel" value="Continue"}{/if}
{if !isset($registrarSelectorButtonIcon)}{assign var="registrarSelectorButtonIcon" value="fas fa-solid fa-check-circle"}{/if}
{if !isset($registrarSelectorAriaLabel)}{assign var="registrarSelectorAriaLabel" value=$registrarSelectorLabel}{/if}
{if !isset($registrarSelectorInputGroupClass)}{assign var="registrarSelectorInputGroupClass" value="input-group input-group-lg"}{/if}
{if !isset($registrarSelectorWrapperClass)}{assign var="registrarSelectorWrapperClass" value=""}{/if}

{assign var="registrarSelectorIsSingle" value=false}
{if $supportedRegistrars|@count eq 1}
    {assign var="registrarSelectorIsSingle" value=true}
{/if}

{assign var="registrarSelectorHasVisibleControl" value=true}
{if $registrarSelectorIsSingle && (!$registrarSelectorButtonEnabled || !$registrarSelectorButtonVisibleWhenSingle)}
    {assign var="registrarSelectorHasVisibleControl" value=false}
{/if}

{if !$registrarSelectorHasVisibleControl}
    <select id="{$registrarSelectorId}" name="{$registrarSelectorName}" class="form-control cnic-registrar-select hidden"
        data-registrar-select="true" aria-label="{$registrarSelectorAriaLabel|escape:'html'}" tabindex="-1">
        <option value="">{$registrarSelectorPlaceholder|escape:'html'}</option>
        {foreach from=$supportedRegistrars key=key item=value}
            <option value="{$key}" {if $key == $selectedRegistrar}selected{/if}>{$value|escape:'html'}</option>
        {/foreach}
    </select>
{else}
    <div class="form-group margin-bottom-4 {$registrarSelectorWrapperClass}">
        {if !$registrarSelectorIsSingle}
            {if $registrarSelectorTitle neq ""}
                <h5 class="cnic-subsection-title">
                    <i class="{$registrarSelectorIcon}" aria-hidden="true"></i>
                    {$registrarSelectorTitle|escape:'html'}
                </h5>
            {elseif $registrarSelectorShowLabel}
                <label for="{$registrarSelectorId}">{$registrarSelectorLabel|escape:'html'}</label>
            {/if}

            {if $registrarSelectorDescription neq ""}
                <p class="help-block margin-bottom-4">{$registrarSelectorDescription|escape:'html'}</p>
            {/if}
        {/if}

        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12">
                {if !$registrarSelectorIsSingle}
                    <div class="registrar-selection-wrapper">
                        <div class="{$registrarSelectorInputGroupClass}">
                            <span class="input-group-addon">
                                <i class="fas fa-solid fa-server" aria-hidden="true"></i>
                            </span>
                            <select id="{$registrarSelectorId}" name="{$registrarSelectorName}" class="form-control cnic-registrar-select"
                                data-registrar-select="true" aria-label="{$registrarSelectorAriaLabel|escape:'html'}">
                                <option value="">{$registrarSelectorPlaceholder|escape:'html'}</option>
                                {foreach from=$supportedRegistrars key=key item=value}
                                    <option value="{$key}" {if $key == $selectedRegistrar}selected{/if}>{$value|escape:'html'}</option>
                                {/foreach}
                            </select>

                            {if $registrarSelectorButtonEnabled}
                                <span class="input-group-btn">
                                    <button type="button" {if $registrarSelectorButtonId neq ""}id="{$registrarSelectorButtonId}"{/if}
                                        class="{$registrarSelectorButtonClass}">
                                        <i class="{$registrarSelectorButtonIcon}" aria-hidden="true"></i>
                                        {$registrarSelectorButtonLabel|escape:'html'}
                                    </button>
                                </span>
                            {/if}
                        </div>
                    </div>
                {else}
                    <select id="{$registrarSelectorId}" name="{$registrarSelectorName}" class="form-control cnic-registrar-select hidden"
                        data-registrar-select="true" aria-label="{$registrarSelectorAriaLabel|escape:'html'}" tabindex="-1">
                        <option value="">{$registrarSelectorPlaceholder|escape:'html'}</option>
                        {foreach from=$supportedRegistrars key=key item=value}
                            <option value="{$key}" {if $key == $selectedRegistrar}selected{/if}>{$value|escape:'html'}</option>
                        {/foreach}
                    </select>

                    <div class="text-left">
                        <button type="button" {if $registrarSelectorButtonId neq ""}id="{$registrarSelectorButtonId}"{/if}
                            class="{$registrarSelectorButtonClass}">
                            <i class="{$registrarSelectorButtonIcon}" aria-hidden="true"></i>
                            {$registrarSelectorButtonLabel|escape:'html'}
                        </button>
                    </div>
                {/if}

                {if !$registrarSelectorIsSingle && $registrarSelectorHelp neq "" && $registrarSelectorHelp neq $registrarSelectorDescription}
                    <small class="help-block margin-top-2">{$registrarSelectorHelp|escape:'html'}</small>
                {/if}
            </div>
        </div>
    </div>
{/if}