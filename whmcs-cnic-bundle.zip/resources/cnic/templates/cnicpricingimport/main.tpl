{extends file="layout.tpl"}

{block name="content"}
<div class="system-settings-index">
    <div class="setup-links-container">
        <div class="setting-col" data-category="products" data-weighting="9">
            <a href="{routePath('admin-utilities-tools-tld-import-step-one')}" id="Setup-Domain-Pricing" class="setting">
                <div class="icon"><i class="fas fa-globe fa-fw"></i></div>
                <div class="content">
                    <span class="title">Domain TLDs &amp; Pricing</span>
                    <span class="desc">Import domain extensions and synchronize pricing</span>
                </div>
            </a>
        </div>
        <div class="setting-col" data-category="products" data-weighting="10">
            <a href="./addonmodules.php?module=cnicpricingimport&amp;category=ssl" id="Setup-Servers" class="setting">
                <div class="icon"><i class="fas fa-lock fa-fw"></i></div>
                <div class="content">
                    <span class="title">SSL Certificates &amp; Pricing</span>
                    <span class="desc">Import SSL certificate products and synchronize pricing</span>
                </div>
            </a>
        </div>
        <div class="setting-col" data-category="products" data-weighting="10">
            <a href="./addonmodules.php?module=cnicpricingimport&amp;category=hosting" id="Setup-Servers" class="setting">
                <div class="icon"><i class="fas fa-server fa-fw"></i></div>
                <div class="content">
                    <span class="title">cPanel Products &amp; Pricing</span>
                    <span class="desc">Import cPanel hosting products and synchronize pricing</span>
                </div>
            </a>
        </div>
    </div>
</div>
{/block}
