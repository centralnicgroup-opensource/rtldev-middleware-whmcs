{if $widgetStatus eq -1}
    <div class="cnic-widget">
        <div class="cnic-widget-notice cnic-widget-notice--danger">
            Please install or upgrade to the latest { $widgetTitleWithCompany } Registrar Module.
            <span data-toggle="tooltip"
                title="The { $widgetTitleWithCompany } Registrar Module is regularly maintained, download and documentation available at github."
                class="glyphicon glyphicon-question-sign"></span>
        </div>
        <a href="{$repoLink}">
            <img src="{$logo}?ts={constant("CNIC_VERSION")}" class="cnic-widget-logo" alt="" />
        </a>
    </div>
{else}

    {if $widgetStatus eq 0}
        <div class="cnic-widget">
            <div class="cnic-widget-notice">{$widgetDisableMessage}</div>
        </div>
    {/if}
    <script type="text/javascript">
        const {$moduleName} = new Widget(`{$widgetId}`, `{$widgetTTL}`, `{$widgetExpires}`, `{$widgetStatus}`, `{$widgetStatusIcon}`, `#cnrbalexpires{$widgetId}`);
        {$moduleName}.mainWidget();
    </script>
{/if}

{if $widgetStatus eq 1}
    <div class="cnic-widget">
        <div class="cnic-widget-head">
            <img src="{$logo}?ts={constant("CNIC_VERSION")}" class="cnic-widget-logo" alt="" />
            {if $latestVersion neq false}
                <a class="cnic-widget-pill cnic-widget-pill--update"
                    href="https://github.com/centralnicgroup-opensource/rtldev-middleware-whmcs/raw/main/whmcs-cnic-bundle.zip"
                    target="_blank" rel="noopener"><i class="fas fa-download" aria-hidden="true"></i> v{$latestVersion} available</a>
            {else}
                <span class="cnic-widget-pill"><i class="fas fa-check" aria-hidden="true"></i> Up to date</span>
            {/if}
        </div>
        {$balanceHTML}
        <div class="cnic-widget-foot">
            {if $quotaStatistics neq ""}
                <span><i class="fas fa-tachometer-alt" aria-hidden="true"></i> {$quotaStatistics}</span>
            {/if}
            <span class="cnic-widget-version">v{$currentVersion}</span>
        </div>
    </div>
    {if $refreshRequest eq ""}
        <script type="text/javascript">
            {$moduleName}.cnrStartCounter();
        </script>
    {/if}
{/if}
