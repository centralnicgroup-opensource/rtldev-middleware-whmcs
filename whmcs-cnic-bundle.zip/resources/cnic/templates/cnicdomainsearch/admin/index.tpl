<div id="tabs" style="display:none">
  <ul>
    <li><a href="#tabs-1">Settings</a></li>
    <li><a href="#tabs-2">Categories</a></li>
  </ul>
  <div id="tabs-1">
    <div class="cnic-settings-app">
      {* Real tab semantics: the panels below are one-at-a-time views, so
         screen readers should hear "tab 2 of 6, selected" rather than six
         unrelated buttons. Roving tabindex + arrow keys are wired in the
         admin JS (initSettingsNav). Sections locked behind a missing
         lookup provider carry aria-disabled, not just a class. *}
      <nav class="cnic-settings-nav" id="cfgnav" role="tablist" aria-label="Domain Search settings sections">
        <button type="button" role="tab" id="cfgtab-lookup" aria-controls="cfgpanel-lookup" aria-selected="true" tabindex="0" class="cnic-settings-nav-item is-active" data-section="lookup">Lookup Provider</button>
        <button type="button" role="tab" id="cfgtab-default-categories" aria-controls="cfgpanel-default-categories" aria-selected="false" tabindex="-1" class="cnic-settings-nav-item" data-section="default-categories">By-default active Categories</button>
        <button type="button" role="tab" id="cfgtab-features" aria-controls="cfgpanel-features" aria-selected="false" tabindex="-1" class="cnic-settings-nav-item" data-section="features">Features</button>
        {foreach $settingsGroups as $group}
        <button type="button" role="tab" id="cfgtab-{$group.slug}" aria-controls="cfgpanel-{$group.slug}" aria-selected="false" tabindex="-1" class="cnic-settings-nav-item" data-section="{$group.slug}">{$group.heading nofilter}</button>
        {/foreach}
      </nav>
      <div class="cnic-settings-panels">
        <section class="cnic-settings-panel is-active" role="tabpanel" id="cfgpanel-lookup" aria-labelledby="cfgtab-lookup" tabindex="0" data-section="lookup">
          <div class="row">
            <div class="col col-md-6">
              <p>Domain lookup provider <span id="cfglookupregistrar" style="font-weight: 600;font-size:0.8em;"></span>
                CentralNic Reseller. <br />This is necessary to have this addon correctly running.</p>
            </div>
            <div class="col col-md-2 lookup-actions">
              <p><a id="configureLookupProvider" class="cnic-btn open-modal"
                  href="configdomainlookup.php?action=configure" data-modal-title="Configure Lookup Provider"
                  data-btn-submit-id="btnSaveLookupConfiguration" data-btn-submit-label="Save" onclick="return false;"
                  data-modal-size="modal-lg">Configure</a></p>
              <p><a id="changeLookupProvider" class="cnic-btn open-modal"
                  href="configdomains.php?action=lookup-provider" data-modal-title="Choose Lookup Provider"
                  onclick="return false;" data-modal-size="modal-lg">Change</a></p>
            </div>
          </div>
        </section>
        <section class="cnic-settings-panel" role="tabpanel" id="cfgpanel-default-categories" aria-labelledby="cfgtab-default-categories" tabindex="0" data-section="default-categories">
          <p class="cnic-panel-intro">Click on a category below to select or deselect it. Active categories (shown filled) will be
            activated by default when your clients initially visit the domain search form.</p>
          <p class="cnic-panel-intro">Available search-url parameters are documented in the <a class="hx"
              href="https://support.centralnicreseller.com/hc/en-gb/articles/13508150601373-WHMCS-Domain-Search-Addon"
              target="_blank">CentralNic Reseller</a> Usage Guide.</p>
          <div id="defaultCatsEmpty" class="cnic-empty-state" style="display:none">
            <p>No categories yet. <a href="#" id="goToCategoriesTab">Go to the Categories tab</a> to add some,
              or use its "Import Default Categories" button to start from a ready-made set.</p>
          </div>
          <div id="categories" class="catcontainer"></div>
          <button type="button" id="savedefaultcats" class="cnic-btn cnic-btn--primary">Save Changes</button>
        </section>

        <section class="cnic-settings-panel" role="tabpanel" id="cfgpanel-features" aria-labelledby="cfgtab-features" tabindex="0" data-section="features">
          <div class="feature-item-container">
            <p class="cnic-panel-intro">This section allows for toggling the features you want to offer.</p>

            {foreach $featureRows as $index => $feature}
            <div class="feature-item row" data-feature="{$feature.key}">
              <div class="setting-row-header feature-item-header">
                <input id="feature-toggle-{$feature.key}"{if $feature.disabled} disabled{/if} class="dsfeature" type="checkbox" />
                <label for="feature-toggle-{$feature.key}">{$feature.label}</label>
                {if $feature.disabled}<span class="cnic-badge" title="This feature can't be turned off">Always on</span>{/if}
                <span class="position-number">#{$index + 1}</span>
                <div class="move-button-group">
                  <button class="move-button move-up" aria-label="Move Up"><i class="fas fa-caret-up"></i></button>
                  <button class="move-button move-down" aria-label="Move Down"><i class="fas fa-caret-down"></i></button>
                </div>
              </div>
              <div class="setting-row-body feature-item-body">
                <p>{$feature.desc}</p>
              </div>
            </div>
            {/foreach}
          </div>
        </section>

        {foreach $settingsGroups as $group}
        <section class="cnic-settings-panel" role="tabpanel" id="cfgpanel-{$group.slug}" aria-labelledby="cfgtab-{$group.slug}" tabindex="0" data-section="{$group.slug}">
          {foreach $group.fields as $field}
            {if isset($field.advanced) && $field.advanced}
              <details id="advanced-theme-settings" class="settings-advanced">
                <summary>Advanced</summary>
                {include file="setting-row.tpl" field=$field}
                <p id="themePathOverrideNote" class="theme-path-note" style="display:none">A custom theme path is
                  set &mdash; the Client theme selection and Appearance settings above are ignored.</p>
              </details>
            {else}
              {include file="setting-row.tpl" field=$field}
            {/if}
          {/foreach}
        </section>
        {/foreach}
      </div>
    </div>
  </div>
  <div id="tabs-2">
    <button class="cnic-btn" id="importdefaultcategories"><i class="fas fa-download"></i> Import Default
      Categories</button>
    <button class="cnic-btn" id="addcategory"><i class="fas fa-plus"></i> Add Category</button>
    <button class="cnic-btn" id="addtld"><i class="fas fa-plus"></i> Add TLD to Category</button>
    <br /><br />
    <div id="maingrid-loading" class="cnic-grid-loading"><i class="fas fa-circle-notch fa-spin"></i> Loading categories&hellip;</div>
    <div id="maingrid" class="grid"></div>
  </div>
</div>

<div id="dialog-confirm">
  <p id="contentholder"></p>
</div>
