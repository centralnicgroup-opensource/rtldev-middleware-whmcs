{* One settings row, driven by the SettingsSchema field definition passed
   as $field (see lib/Admin/SettingsSchema.php for the shape). DOM ids are
   load-bearing — the admin JS wires bootstrapSwitch, save handlers and
   color pickers to them. descHtml/afterHtml/hintHtml are trusted static
   strings from the schema, hence nofilter.

   Layout: a header line (control + label + optional badge) and a body
   below it (the field's own control for non-toggle types, then its
   description) — replaces the old col-md-1/3/6 three-way split. *}
<div class="row setting-row" data-setting="{$field.id}"{if isset($field.themeOnly)} data-theme-only="{$field.themeOnly}"{/if}>
  <div class="setting-row-header">
    {if $field.type == 'toggle'}
      <input id="{$field.id}" type="checkbox" />
    {/if}
    <label for="{$field.id}">{$field.label nofilter}</label>
    {if isset($field.badge)}<span class="label label-success sitejet-badge-new sitejet-success">{$field.badge}</span>{/if}
  </div>
  <div class="setting-row-body">
    {if $field.type == 'toggle'}
      {if isset($field.descHtml)}<p>{$field.descHtml nofilter}</p>{/if}
    {elseif $field.type == 'select'}
      <select id="{$field.id}" class="form-control setting-control">
        {foreach $field.options as $value => $optionLabel}
          <option value="{$value}">{$optionLabel}</option>
        {/foreach}
      </select>
      {if isset($field.descHtml)}<p>{$field.descHtml nofilter}</p>{/if}
      {if isset($field.afterHtml)}{$field.afterHtml nofilter}{/if}
    {elseif $field.type == 'text' || $field.type == 'number'}
      <input id="{$field.id}" type="{$field.type}"{if isset($field.name)} name="{$field.name}"{/if}
        class="form-control setting-control"{if isset($field.placeholder)} placeholder="{$field.placeholder}"{/if} />
      {if isset($field.hintHtml)}<small class="form-text text-muted">{$field.hintHtml nofilter}</small>{/if}
      {if isset($field.descHtml)}<p>{$field.descHtml nofilter}</p>{/if}
    {elseif $field.type == 'colorset'}
      <div class="appearance-card">
        <p>
          <label for="input-appearanceBrandColor">Brand Color</label>
          <span class="color-field">
            <input id="input-appearanceBrandColor" type="text" class="form-control" placeholder="Theme default"
              maxlength="9" />
            <input id="picker-appearanceBrandColor" type="color" title="Pick a brand color" />
            <a href="#" id="reset-appearanceBrandColor">Reset</a>
          </span>
        </p>
        <p>
          <label for="input-appearanceSurfaceColor">Surface Color</label>
          <span class="color-field">
            <input id="input-appearanceSurfaceColor" type="text" class="form-control" placeholder="Theme default"
              maxlength="9" />
            <input id="picker-appearanceSurfaceColor" type="color" title="Pick a surface color" />
            <a href="#" id="reset-appearanceSurfaceColor">Reset</a>
          </span>
        </p>
        <p>
          <label for="select-appearanceRadius">Corner Radius</label>
          <select id="select-appearanceRadius" class="form-control">
            <option value="">Theme default</option>
            <option value="0px">Square (0px)</option>
            <option value="4px">Subtle (4px)</option>
            <option value="8px">Rounded (8px)</option>
            <option value="14px">Extra rounded (14px)</option>
          </select>
        </p>
      </div>
      {if isset($field.descHtml)}<p>{$field.descHtml nofilter}</p>{/if}
    {/if}
  </div>
</div>
