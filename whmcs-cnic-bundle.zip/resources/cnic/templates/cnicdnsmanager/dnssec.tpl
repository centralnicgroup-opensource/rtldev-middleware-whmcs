{* Compact DNSSEC status strip — sits above the DNS Management card *}
{if $dnssec.disabled && !$dnssec.success}
    {assign var="dnssecBg" value="#fff5f5"}
    {assign var="dnssecBorder" value="#dc3545"}
{elseif $dnssec.disabled && $dnssec.success}
    {* Enable was just submitted but signing is async — show pending *}
    {assign var="dnssecBg" value="#fffbf0"}
    {assign var="dnssecBorder" value="#ffc107"}
{elseif !$dnssec.dsData && !$dnssec.keyData}
    {assign var="dnssecBg" value="#fffbf0"}
    {assign var="dnssecBorder" value="#ffc107"}
{else}
    {assign var="dnssecBg" value="#f0fff4"}
    {assign var="dnssecBorder" value="#28a745"}
{/if}
<div class="d-flex align-items-center justify-content-between flex-wrap mb-3 px-3 py-2 rounded"
     style="background:{$dnssecBg}; border:1px solid #dee2e6; border-left:4px solid {$dnssecBorder};">

    {* Left side: shield icon + label + status badge/toggle *}
    <div class="d-flex align-items-center" style="gap:0.5rem; flex-wrap:wrap;">
        <i class="fas fa-shield-alt {if $dnssec.disabled && !$dnssec.success}text-danger{elseif $dnssec.disabled || (!$dnssec.dsData && !$dnssec.keyData)}text-warning{else}text-success{/if}"></i>
        <strong class="small text-nowrap">{$lang.dnszoneDnssecManagement}:</strong>

        {if $dnssec.disabled && $dnssec.success}
            {* Signing request accepted; zone signing is now in progress *}
            <span class="badge badge-warning text-uppercase" style="font-size:0.7rem;">
                {$lang.dnssecPending}
            </span>
            <span class="text-muted small">— {Lang::trans("changessavedsuccessfully")}</span>
        {elseif $dnssec.disabled}
            <span class="badge badge-danger text-uppercase" style="font-size:0.7rem;">
                {$lang.dnssecInactiveMessage}
            </span>
        {elseif !$dnssec.dsData && !$dnssec.keyData}
            <span class="badge badge-warning text-uppercase" style="font-size:0.7rem;">
                {$lang.dnssecPending}
            </span>
        {else}
            <button class="btn btn-outline-success btn-sm py-0 px-2" style="font-size:0.75rem; line-height:1.6;"
                    data-toggle="collapse" data-target="#dnssecRecords"
                    aria-expanded="false" aria-controls="dnssecRecords">
                {$lang.viewDnssecRecords} <i class="fas fa-chevron-down ml-1" style="font-size:0.65rem;"></i>
            </button>
        {/if}
    </div>

    {* Right side: Enable / Disable form — hide enable button once request was accepted *}
    <form method="post" class="form mb-0" role="form" id="dnsSecForm">
        {if $dnssec.disabled && !$dnssec.success}
            <button type="submit" name="dnssec-enable" class="btn btn-success btn-sm"
                    aria-label="{$lang.dnssecSignZoneTooltip}"
                    data-toggle="tooltip" data-placement="left"
                    title="{$lang.dnssecSignZoneTooltip}">
                <i class="fas fa-shield-alt mr-1"></i>{$lang.dnssecSignZoneBtn}
            </button>
        {elseif !$dnssec.disabled}
            <button type="submit" name="dnssec-disable" class="btn btn-outline-danger btn-sm"
                    aria-label="{$lang.dnssecDisableTooltip}"
                    data-toggle="tooltip" data-placement="left"
                    title="{$lang.dnssecDisableTooltip}">
                <i class="fas fa-power-off mr-1"></i>{Lang::trans("disable")} DNSSEC
            </button>
        {/if}
    </form>
</div>

{* Active-state messages and auto-import action (shown when zone has DS/key data) *}
{include file="$templateDir/includes/dnssec_status.tpl"}

{* Collapsible unified DNSSEC keys panel (KSK + ZSK in one table, CNR-style) *}
<div id="dnssecRecords" class="collapse mb-3">
    {if $dnssec.keys}
        <div class="card">
            <div class="card-header py-2 d-flex align-items-center justify-content-between">
                <h6 class="card-title mb-0">
                    <i class="fas fa-key mr-1"></i> {$lang.dnssecKeysTitle}
                </h6>
                <span class="text-muted small">{count($dnssec.keys)} {$lang.dnssecKeysCountLabel}</span>
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th style="width:55px;">{$lang.dnssecKeyType}</th>
                            <th style="width:95px;">{$lang.dnssecKeyStatus}</th>
                            <th style="width:130px;">{Lang::trans("domainDnsSec.algorithm")}</th>
                            <th>{Lang::trans("domainDnsSec.publicKey")}</th>
                            <th>{$lang.dnssecDsRecord}</th>
                            <th style="width:160px;">{$lang.dnssecAction}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {foreach item=key from=$dnssec.keys}
                            <tr style="{if $key.type == 'KSK'}background:rgba(0,123,255,0.04);{/if}">
                                <td class="align-middle">
                                    <span class="badge {if $key.type == 'KSK'}badge-primary{else}badge-secondary{/if}" style="font-size:0.75rem;">
                                        {$key.type}
                                    </span>
                                </td>
                                <td class="align-middle">
                                    {if $key.statusKey == 'pending'}
                                        <span class="badge badge-warning" style="font-size:0.72rem;">{$lang.dnssecStatusPending}</span>
                                    {elseif $key.statusKey == 'ready'}
                                        <span class="badge badge-info" style="font-size:0.72rem;">{$lang.dnssecStatusReady}</span>
                                    {else}
                                        <span class="badge badge-success" style="font-size:0.72rem;">{$lang.dnssecStatusActive}</span>
                                    {/if}
                                    <div class="text-muted" style="font-size:0.68rem; margin-top:3px; line-height:1.3;">
                                        {if $key.statusKey == 'pending'}{$lang.dnssecDescPending}{elseif $key.statusKey == 'ready'}{$lang.dnssecDescActivating}{else}{$lang.dnssecDescConfigured}{/if}
                                    </div>
                                </td>
                                <td class="align-middle text-nowrap small">
                                    {$dnssec.algOptions[$key.alg]}
                                </td>
                                <td class="align-middle" style="min-width:200px;">
                                    <div class="d-flex align-items-start">
                                        <code style="font-size:0.72rem; word-break:break-all; flex:1; line-height:1.4;">{$key.flags} {$key.protocol} {$key.alg} {$key.pubkey}</code>
                                        <button type="button" class="btn btn-link btn-sm p-0 ml-2 flex-shrink-0 dnssec-copy-btn"
                                                data-value="{$key.flags} {$key.protocol} {$key.alg} {$key.pubkey}"
                                                title="{$lang.dnssecCopyTooltip}" data-toggle="tooltip" data-placement="top">
                                            <i class="fas fa-copy text-muted" style="font-size:0.8rem;"></i>
                                        </button>
                                    </div>
                                </td>
                                <td class="align-middle" style="min-width:200px;">
                                    {if $key.dsData}
                                        {foreach item=ds from=$key.dsData}
                                            <div class="d-flex align-items-start {if !$ds@first}mt-1{/if}">
                                                <code style="font-size:0.72rem; word-break:break-all; flex:1; line-height:1.4;">{$ds.keytag} {$ds.alg} {$ds.digesttype} {$ds.digest}</code>
                                                <button type="button" class="btn btn-link btn-sm p-0 ml-2 flex-shrink-0 dnssec-copy-btn"
                                                        data-value="{$ds.keytag} {$ds.alg} {$ds.digesttype} {$ds.digest}"
                                                        title="{$lang.dnssecCopyTooltip}" data-toggle="tooltip" data-placement="top">
                                                    <i class="fas fa-copy text-muted" style="font-size:0.8rem;"></i>
                                                </button>
                                            </div>
                                            <div class="text-muted" style="font-size:0.68rem; margin-top:1px;">SHA-256 &middot; tag {$ds.keytag}</div>
                                        {/foreach}
                                    {else}
                                        <span class="text-muted">—</span>
                                    {/if}
                                </td>
                                <td class="align-middle">
                                    {if $key.type == 'KSK' && $key.dsData}
                                        {if !$dnssec.dnssecDataMatches && $KeyDnsActive}
                                            {* DS in zone doesn't match domain — push the new/initial KSK DS record to the parent zone *}
                                            <form action="/clientarea.php" method="post" class="mb-0">
                                                <input type="hidden" name="prefill" value="1" />
                                                <input type="hidden" name="action" value="domaindetails" />
                                                <input type="hidden" name="modop" value="custom" />
                                                <input type="hidden" name="a" value="dnssec" />
                                                <input type="hidden" name="domainid" value="{$domainid}" />
                                                <button type="submit" class="btn btn-warning btn-sm w-100" style="white-space:normal; font-size:0.78rem;">
                                                    <i class="fas fa-upload mr-1"></i>
                                                    {if $dnssec.domainDnssecData}{$lang.autoUpdateBtn}{else}{$lang.autoActivateBtn}{/if}
                                                </button>
                                            </form>
                                        {elseif $dnssec.dnssecDataMatches && $key.rolloverPending}
                                            {* DS matches domain but new KSK awaits ACK — complete the rollover to remove the old KSK *}
                                            <form method="post" class="mb-0">
                                                <input type="hidden" name="dnssec-ksk-rollover-keytag" value="{$key.dsData[0].keytag}" />
                                                <button type="submit" name="dnssec-ksk-finish-rollover" class="btn btn-success btn-sm w-100" style="white-space:normal; font-size:0.78rem;">
                                                    <i class="fas fa-check-circle mr-1"></i>{$lang.dnssecFinishRolloverBtn}
                                                </button>
                                            </form>
                                        {else}
                                            {* Normal state — DS is in sync, offer KSK rollover (recommended every 1-2 years) *}
                                            <form method="post" class="mb-0">
                                                <button type="submit" name="dnssec-ksk-rollover" class="btn btn-outline-secondary btn-sm w-100"
                                                        style="white-space:normal; font-size:0.78rem;"
                                                        title="{$lang.dnssecRolloverKskTooltip}" data-toggle="tooltip" data-placement="left">
                                                    <i class="fas fa-sync-alt mr-1"></i>{$lang.dnssecRolloverKskBtn}
                                                </button>
                                            </form>
                                        {/if}
                                    {elseif $key.type == 'ZSK'}
                                        <span class="text-muted small" title="{$lang.dnssecZskAutoTooltip}" data-toggle="tooltip">
                                            <i class="fas fa-magic mr-1"></i>{$lang.dnssecZskAutomatic}
                                        </span>
                                    {/if}
                                </td>
                            </tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>
        </div>
    {/if}
</div>

<script>
$(function() {
    $('[data-toggle="tooltip"]').tooltip();

    $(document).on('click', '.dnssec-copy-btn', function() {
        var val = $(this).data('value');
        var btn = $(this);
        if (navigator.clipboard) {
            navigator.clipboard.writeText(val).then(function() {
                btn.find('i').removeClass('fa-copy text-muted').addClass('fa-check text-success');
                setTimeout(function() {
                    btn.find('i').removeClass('fa-check text-success').addClass('fa-copy text-muted');
                }, 1500);
            });
        } else {
            var ta = $('<textarea>').val(val).appendTo('body').select();
            document.execCommand('copy');
            ta.remove();
            btn.find('i').removeClass('fa-copy text-muted').addClass('fa-check text-success');
            setTimeout(function() {
                btn.find('i').removeClass('fa-check text-success').addClass('fa-copy text-muted');
            }, 1500);
        }
    });
});
</script>
