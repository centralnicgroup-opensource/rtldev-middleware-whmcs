{if !$dnssec.disabled && ($dnssec.dsData || $dnssec.keyData)}
    <div class="alert alert-success alert-dismissible fade show p-4" role="alert"
        style="border-left: 5px solid #28a745; background-color: #e9f7ef;">
        <div class="d-flex align-items-center">
            <div>
                <span class="small">
                    {* 
                        Show different messages based on DNSSEC status:
                        - If DS Data matches and domain is signed, show success message.
                        - If DS Data matches but domain is not yet signed, show pending message.
                        - Otherwise, show generic active message.
                    *}
                    {if $dnssec.dnssecDataMatches && $dnssec.domainSigned}
                        {* DS Data matches and domain is signed *}
                        {$lang.dnssecDataMatchesAndSigned|replace:'#dnszone_placeholder#':$dnszone|replace:'#dnssecmanagementlink_placeholder#':$dnsseclink}
                    {elseif $dnssec.dnssecDataMatches && !$dnssec.domainSigned}
                        {* DS Data matches but domain is not signed yet *}
                        {$lang.dnssecSignedPending|replace:'#dnszone_placeholder#':$dnszone|replace:'#dnssecmanagementlink_placeholder#':$dnsseclink}
                    {else}
                        {* DS Data does not match or other state *}
                        {$lang.dnssecActiveMessage|replace:'#dnszone_placeholder#':$dnszone|replace:'#dnssecmanagementlink_placeholder#':$dnsseclink}
                    {/if}
                </span>
            </div>
        </div>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"
            style="position: absolute; top: 10px; right: 10px;">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

    {* DS push action is shown in the DNSSEC Keys table Action column when records are expanded *}
{/if}


{if !empty($dnssec.error)}
    <div class="alert alert-danger alert-dismissible fade show mt-3 p-4" role="alert"
        style="border-left: 5px solid #dc3545; background-color: #f8d7da;">
        <div class="d-flex align-items-center">
            <i class="fas fa-exclamation-circle text-danger mr-2" style="font-size: 1.5rem;"></i>
            <div>
                <span class="small"><b>{$lang.oopsError}</b> {$dnssec.error}</span>
            </div>
        </div>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"
            style="position: absolute; top: 10px; right: 10px;">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
{/if}