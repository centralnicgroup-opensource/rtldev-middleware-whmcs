<div class="cnic-dns-controls">
    <div class="row cnic-controls-row">
        <div class="col-sm-7">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" id="dnsRecordSearch" class="form-control" placeholder="{$lang.searchDnsRecordsPlaceholder}" />
            </div>
        </div>
        <div class="col-sm-5">
            <div class="cnic-button-group">
                <button type="button" id="importExportToggle" class="btn btn-default">
                    <i class="fa fa-exchange"></i> {$lang.importAndExportBtn}
                </button>
                <button type="button" id="headerAddRecordButton" class="btn btn-primary">
                    <i class="fa fa-plus"></i> {$lang.addRecordBtn}
                </button>
            </div>
        </div>
    </div>
    
    <!-- Combined Import/Export Panel -->
    <div id="importExportPanel" class="cnic-zone-panel">
        <div class="cnic-zone-panel-body">
            <div class="row cnic-panel-content">
                <!-- Import Section -->
                <div class="col-md-6 cnic-import-section">
                    <h4 class="cnic-zone-section-title"><i class="fa fa-upload"></i> {$lang.importDnsRecordsTitle}</h4>
                    <p class="text-muted cnic-section-desc">{$lang.importDnsRecordsDesc}</p>
                    <div class="alert alert-warning" style="margin-bottom: 15px; padding: 10px 15px; font-size: 0.9em;">
                        <i class="fa fa-exclamation-triangle"></i> <strong>{$lang.importWarningLabel}</strong> {$lang.importWarningText}
                    </div>
                    <div id="zoneDropArea" class="cnic-zone-drop-area-compact">
                        <input type="file" id="zoneFileInput" accept="text/plain,.txt,.zone" style="display:none;" />
                        <i class="fa fa-cloud-upload cnic-drop-icon"></i>
                        <p class="cnic-drop-text">{$lang.selectFileOrDragText}</p>
                        <button type="button" id="zoneFileBrowse" class="btn btn-primary">
                            <i class="fa fa-folder-open"></i> {$lang.browseFilesBtn}
                        </button>
                    </div>
                    <div id="zoneImportResults" class="cnic-zone-import-results"></div>
                    <div class="cnic-apply-button-wrapper">
                        <button type="button" id="applyImportedRecordsButton" class="btn btn-success btn-block cnic-apply-button">
                            <i class="fa fa-check"></i> {$lang.applyImportedRecordsBtn}
                        </button>
                    </div>
                </div>
                
                <!-- Export Section -->
                <div class="col-md-6 cnic-export-section">
                    <h4 class="cnic-zone-section-title"><i class="fa fa-download"></i> {$lang.exportDnsRecordsTitle}</h4>
                    <p class="text-muted cnic-section-desc">{$lang.exportDnsRecordsDesc}</p>
                    <div class="well cnic-export-info">
                        <p><i class="fa fa-info-circle"></i> {$lang.exportInfoText}</p>
                    </div>
                    <button type="button" id="exportZoneButton" class="btn btn-primary btn-block">
                        <i class="fa fa-download"></i> {$lang.exportZoneFileBtn}
                    </button>
                </div>
            </div>
            
            <!-- Footer with Close Button -->
            <div class="cnic-panel-footer">
                <button type="button" id="closeImportExportPanel" class="btn btn-default btn-sm">
                    <i class="fa fa-times"></i> {$lang.closeBtn}
                </button>
            </div>
        </div>
    </div>
</div>
