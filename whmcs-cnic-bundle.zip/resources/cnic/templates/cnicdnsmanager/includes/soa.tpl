{* Zone settings (SOA) popover — open again after a submit so its result shows *}
<div id="zonePopover" class="cnic-popover-host"{if !isset($smarty.post["soa-save"])} hidden{/if}>
    <button type="button" class="cnic-popover-backdrop" data-cnic-popover-close aria-label="{$lang.jsClose}"></button>
    <div class="cnic-popover dns-zone-popover" role="dialog" aria-labelledby="zonePopoverTitle">
        <div class="dns-popover-head">
            <h2 class="cnic-popover-title" id="zonePopoverTitle">{$lang.soaBtn} (SOA)</h2>
            <button type="button" class="cnic-btn cnic-btn--icon dns-popover-close" data-cnic-popover-close aria-label="{$lang.jsClose}">{include file="$templateDir/includes/icon.tpl" name="close"}</button>
        </div>
        <p class="cnic-callout">{$lang.soaDesc}</p>

        {if !empty($soa.error)}
            {include file="$templateDir/includes/alert.tpl" type="error" msg=$soa.error|escape:'html'}
        {elseif !empty($soa.fieldErrors)}
            {include file="$templateDir/includes/alert.tpl" type="error" msg=$lang.soaInvalid}
        {elseif $soa.success}
            {include file="$templateDir/includes/alert.tpl" type="success" msg=$lang.soaSaved}
        {/if}

        <form method="post" class="dns-zone-form" role="form" id="soaForm">
            <div class="dns-zone-grid">
                {foreach $soa.ranges as $key => $range}
                    {assign var="labelKey" value="soaLabel`$key`"}
                    {assign var="helpKey" value="soaHelp`$key`"}
                    <div class="cnic-field">
                        <label class="cnic-label" for="soa{$key}">
                            {$lang.$labelKey}
                            <i class="fa fa-question-circle dns-help-icon" tabindex="0" data-toggle="tooltip" title="{$lang.$helpKey|escape:'html'} ({$range[0]} - {$range[1]} {$lang.soaSeconds})"></i>
                        </label>
                        <div class="cnic-input-group">
                            <input type="text" inputmode="numeric" pattern="[0-9]*" id="soa{$key}" name="{$key}" class="cnic-input dns-seconds" value="{$soa.values.$key|escape:'html'}"{if isset($soa.fieldErrors.$key)} aria-invalid="true"{/if} />
                            <span class="cnic-input-suffix">s</span>
                        </div>
                        {if isset($soa.fieldErrors.$key)}
                            <span class="cnic-field-error">{$lang.soaAllowed} {$range[0]} - {$range[1]} s</span>
                        {else}
                            <span class="cnic-field-hint dns-seconds-hint"></span>
                        {/if}
                    </div>
                {/foreach}
            </div>
            <div class="cnic-field">
                <label class="cnic-label" for="soaSOARNAME">
                    {$lang.soaLabelSOARNAME}
                    <i class="fa fa-question-circle dns-help-icon" tabindex="0" data-toggle="tooltip" title="{$lang.soaHelpSOARNAME|escape:'html'}"></i>
                </label>
                <input type="text" id="soaSOARNAME" name="SOARNAME" class="cnic-input" value="{$soa.values.SOARNAME|escape:'html'}"{if isset($soa.fieldErrors.SOARNAME)} aria-invalid="true"{/if} />
            </div>
            <div class="cnic-actions">
                <button type="button" class="cnic-btn" data-cnic-popover-close>{lang key='cancel'}</button>
                <button type="submit" name="soa-save" class="cnic-btn cnic-btn--primary">
                    {include file="$templateDir/includes/icon.tpl" name="check"} {$lang.soaSaveBtn}
                </button>
            </div>
        </form>
    </div>
</div>
