<p>Dear {$client_name},</p>

<p>
    This is a reminder from {$reseller_name}:<br>
    The validity period of your issued SSL certificate is nearing its expiration. To ensure uninterrupted protection for your website, please re‑issue your certificate before the deadline.
</p>

<p>
    <strong>Certificate Details:</strong><br>
    Certificate ID: {$certificate_id}<br>
    Certified Domain(s): {$ssl_domain}<br>
    Expiration Date: {$days_until_reissue} day(s)
</p>

<p>
    <strong>Why Re‑Issuing Matters</strong><br>
    Re‑issuing your SSL certificate renews its validity and keeps your visitors’ connections secure.<br>
    We also recommend taking this opportunity to rotate your keys by uploading a CSR based on a fresh key pair—an important best practice for long‑term security.
</p>

<p>
    <strong>Key Points</strong><br>
    Re‑issuance is free of charge.<br>
    Simply upload your CSR in your customer account during the re‑issuance process.<br>
    The new certificate will receive a fresh validity period within the remaining lifetime of your SSL product.
</p>

<p>To begin, log in to your account and follow the steps in the <a href="{$ssl_reissue_link}">SSL management area</a>.</p>

Stay secure,
Your {$reseller_name} Team

<p>{$signature}</p>
