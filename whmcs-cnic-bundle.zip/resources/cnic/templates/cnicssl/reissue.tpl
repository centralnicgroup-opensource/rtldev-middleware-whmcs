<h1>{$LANG.reissue}</h1>

<p>{$LANG.reissueHint}</p>

<form method="post" action="">
    <div class="form-group">
        <label for="csr">{$LANG.sslcsr}</label>
        <textarea id="csr" name="csr" rows="8" cols="64" class="form-control" required placeholder="-----BEGIN CERTIFICATE REQUEST-----&#10;&#10;-----END CERTIFICATE REQUEST-----"></textarea>
    </div>

    <a href="clientarea.php?action=productdetails&amp;id={$id}" class="btn btn-default">{$LANG.clientareabacklink}</a>
    <button type="submit" class="btn btn-primary">{$LANG.reissue}</button>
</form>
