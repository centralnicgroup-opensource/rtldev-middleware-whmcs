<p>Dear {$client_name},</p>

<p>Thank you for your order! Your hosting account has now been setup and this email contains all the information you will need to begin using your account.</p>

<p><strong>New Account Information</strong></p>
<p>
    Hosting Package: {$service_product_name}
    <br />Domain: {$service_domain}
    <br />First Payment Amount: {$service_first_payment_amount}
    <br />Recurring Amount: {$service_recurring_amount}
    <br />Billing Cycle: {$service_billing_cycle}
    <br />Next Due Date: {$service_next_due_date}
</p>

<p><strong>Login Details</strong></p>
<p>Control Panel (cPanel): <a href="{$cpanel_login_url}">{$cpanel_login_url}</a></p>
<p>
    Username: {$service_username}
    <br />Password: {$service_password}
</p>

<p><strong>Server Information</strong></p>
<p>
    Server Name: {$service_server_name}
    <br />Server IP: {$service_server_ip}
</p>
<p>If you registered a new domain during signup, DNS propagation may take up to 48 hours. During this time, the domain may not yet be visible online.</p>
<p>If you're using a domain from another provider, please update your DNS records as follows:</p>
<p>{$dns_template}</p>

<p><strong>Uploading Your Website</strong></p>
<p>
    WebFTP: <a href="{$webftp_login_url}">{$webftp_login_url}</a>
    <br/>FTP Hostname: {$service_domain}
    <br />Webpage URL: <a href="http://www.{$service_domain}">http://www.{$service_domain}</a>
</p>

<p><strong>Email Settings</strong></p>
<p>Webmail: <a href="{$webmail_login_url}">{$webmail_login_url}</a></p>
<p>For email accounts that you set up, you should use the following connection details in your email program:</p>
<p>
    Incoming Mail (POP3/IMAP4): mail.{$service_domain}
    <br />SMTP Server.{$service_domain}
    <br />Username: The email address you are checking email for
    <br />Password: As specified in your control panel
</p>

<p>
    If you need help at any point, our support team is here for you.
    <br />Thank you again for choosing us—we’re excited to have you onboard!
</p>

<p>{$signature}</p>
