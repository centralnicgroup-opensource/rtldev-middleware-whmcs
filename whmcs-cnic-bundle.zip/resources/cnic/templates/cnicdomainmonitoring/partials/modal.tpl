<!-- Domain Fix Modal -->
<div class="modal fade" id="domainFixModal" tabindex="-1" role="dialog" aria-labelledby="cnicDomainModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cnicDomainModalLabel">Review Premium Pricing</h5>
                <button type="button" class="close pull-right" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="successMsgModal" aria-live="polite" role="status"></div>
                <div class="alert alert-danger" id="errorMsgModal" role="alert" style="display: none;"
                    aria-live="assertive"></div>
                <div class="text-center" id="modalSpinner" style="display: none;" aria-label="Loading content">
                    <i class="fas fa-spinner fa-spin" aria-hidden="true"></i>
                    <p>Loading...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary btn-submit" disabled>Apply &amp; Recalculate</button>
            </div>
        </div>
    </div>
</div>
