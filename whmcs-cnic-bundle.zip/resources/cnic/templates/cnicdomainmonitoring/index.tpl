<link rel="stylesheet" href="{$cssPath}/style.css">
<!-- Page Container -->
<div class="container-fluid mt-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <p class="text-muted">Review premium-domain cost changes and safely update WHMCS billing.</p>
        </div>
    </div>

    <!-- Domain Monitoring Table -->
    <div class="row">
        <div class="col">
            <table id="domain-monitoring-list" class="table table-striped table-bordered table-responsive">
                <thead>
                    <tr>
                        <th>Domain Name</th>
                        <th class="col-xs-6">Description</th>
                        <th>Registrar</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {foreach $issues as $issue}
                        <tr data-id="{$issue->id}" data-status="{$issue->status}" data-type="{$issue->type}"
                            data-domainid="{$issue->domainId}" data-todoid="{$issue->todoId}">
                            <td data-domain="{$issue->domainName}" class="text-center"
                                style="vertical-align: middle;font-size:1.2em;">
                                <a href="./clientsdomains.php?id={$issue->domainId}"
                                    target="_blank">{$issue->domainName}</a>
                            </td>
                            <td data-desc="{$issue->todoDesc|nl2br}" class="text-wrap" style="vertical-align: middle;">
                                {if $issue->status eq "Completed"}
                            <p>The registrar costs were updated and WHMCS recalculated the domain's recurring amount.</p>
                            <p>Review the domain's <a target="_blank" style="text-decoration:underline"
                                    href="./clientsdomains.php?id={$issue->domainId}">billing details</a> before retrying the pending module action.</p>
                            <p class="text-muted">Existing invoices are unchanged and may need to be cancelled and reissued.</p>
                            {else}
                            Our addon has detected that the domain has been upgraded to a premium domain by the TLD
                            provider, or its premium pricing has been adjusted. Click 'Review Update' to
                            update the status and reflect the new premium domain pricing in WHMCS. {/if}
                        </td>
                        <td data-registrar="{$issue->domainRegistrar}" style="vertical-align: middle;text-align:center">
                            {if $issue->domainRegistrar eq 'cnic'} CentralNic Reseller (CNIC)
                            {else}
                            {$issue->domainRegistrar}
                            {/if}
                        </td>
                        <td data-status="{$issue->status}" style="vertical-align: middle;text-align:center">
                            {if $issue->status eq "Completed"}
                            <span class="badge badge-success cnic-custom-badge-success">Updated Successfully</span>
                            {else}
                            <span class="badge badge-warning cnic-custom-badge-warning">{$issue->status}</span>
                            {/if}
                        </td>
                        <td data-actions style="vertical-align: middle;text-align:center">
                            {if $issue->status eq "Completed"}
                            <button type="button" class="btn btn-danger btn-sm deleteBtn">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                            {else}
                            <button type="button" data-toggle="modal" data-target="#domainFixModal"
                                class="btn btn-primary btn-sm fixNowBtn">
                                <i class="fas fa-search-dollar"></i> Review Update
                            </button>
                            {/if}
                        </td>
                    </tr>
                    {/foreach}
                </tbody>
                <tfoot>
                    <tr>
                        <th>Domain Name</th>
                        <th>Description</th>
                        <th>Registrar</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="alert alert-warning" role="note">
            <strong>Important:</strong> The domain may have been upgraded to premium status and/or its
            renewal or transfer pricing may have changed. Thoroughly review and update the customer's billing
            to keep records accurate and prevent discrepancies between your reseller cost and the customer's
            original payment. Existing invoices are not updated automatically. If there is a shortfall, you may
            be required to cover the difference rather than the customer.
        </div>
            </div>

            <!-- Domain Fix Modal -->
            {include file="partials/modal.tpl"}
        </div>
