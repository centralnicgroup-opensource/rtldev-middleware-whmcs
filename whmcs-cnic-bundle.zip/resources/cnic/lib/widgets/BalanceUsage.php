<?php

namespace CNIC\Widgets;

use CNIC\Widgets\Currency;

class BalanceUsage
{
    /** @var array<string, mixed> */
    private $data = [];
    /** @var \CNIC\Widget\Currency */
    private $currencyObject = null;
    /** @var string */
    private $widgetid = null;
    /** @var string */
    private $registrarid = null;

    public function __construct($widgetid, $registrarid)
    {
        $this->widgetid = $widgetid;
        $this->registrarid = $registrarid;

        /**
         * @codeCoverageIgnore
         */
        // init status
        if (isset($_SESSION[$this->widgetid]["data"])) { // data cache exists
            $this->data = $_SESSION[$this->widgetid]["data"];
        } else {
            $this->data = [];
            $fn = $this->registrarid . "_getAccountDetails";
            $accountsStatus = $fn(); // @codeCoverageIgnore
            if ($accountsStatus["success"]) {
                $this->data['amount'] = $accountsStatus['amount'];
                $this->data['currency'] = $accountsStatus['currency'];
                if (isset($accountsStatus['deposit'])) {
                    $this->data['deposit'] = $accountsStatus['deposit'];
                }
                if (isset($accountsStatus['total_query_quota'])) {
                    $this->data['total_query_quota'] = $accountsStatus['total_query_quota'];
                }
                if (isset($accountsStatus['current_quota_usage'])) {
                    $this->data['current_quota_usage'] = $accountsStatus['current_quota_usage'];
                }
                $_SESSION[$this->widgetid]["data"] = $this->data;
            }
        }

        // a reference to the currency instance in main class: CnicWidget
        $this->currencyObject = new Currency();
    }

    /**
     * get balance data
     * @return array<string, mixed>|null
     */
    public function getData(): ?array
    {
        if (empty($this->data)) {
            return null;
        }
        $amount = floatval($this->data["amount"]);
        $deposit = floatval($this->data["deposit"] ?? 0);
        $fundsav = $amount - $deposit;
        $currency = $this->data["currency"];
        $currencyid = $this->currencyObject->getId($currency);
        return [
            "amount" => $amount,
            "deposit" => $deposit,
            "fundsav" => $fundsav,
            "currency" => $currency,
            "currencyID" => $currencyid,
        ];
    }

    /**
     * get formatted balance data
     * @return array<string, mixed>|null
     */
    public function getDataFormatted(): ?array
    {
        $this->data = $this->getData();
        $newData = [];
        if (is_null($this->data)) {
            return null;
        }
        $keys = ["amount", "deposit", "fundsav"];
        if (is_null($this->data["currencyID"])) {
            foreach ($keys as $key) {
                $newData[$key] = number_format($this->data[$key], 2, ".", ",") . " " . $this->data["currency"];
            }
        } else {
            foreach ($keys as $key) {
                $newData[$key] = formatCurrency($this->data[$key], $this->data["currencyID"]);
            }
        }
        return $newData;
    }

    /**
     * generate balance as HTML
     * @return string
     */
    public function toHTML(): string
    {
        $newData = $this->getDataFormatted();
        if (is_null($newData)) {
            return <<<HTML
                <div class="widget-content-padded widget-billing">
                    <div class="color-pink">Loading Account Data failed.</div>
                </div>
HTML;
        }

        $balanceColor = $newData["amount"] < 0 ? "pink" : "green";
        return <<<HTML
            <div class="item text-right">
                <div class="data color-{$balanceColor}">{$newData["amount"]}</div>
                <div class="note">Account Balance</div>
            </div>
HTML;
    }

    /**
     * Get query requests allocated quota, remaining quota and remaining quota percentage
     *
     * @return string|null
     */
    public function getQuotaDataHTML()
    {
        if (empty($this->data)) {
            return null;
        }

        if (isset($this->data['total_query_quota']) && isset($this->data['current_quota_usage'])) {
            $totalQueryQuota = $this->data['total_query_quota'];
            $currentQuotaUsage = $this->data['current_quota_usage'];
            $quotaPercentage = (float)($currentQuotaUsage / $totalQueryQuota) * 100;

            return "Used quota: "
                . $quotaPercentage . "% (" . (int)$currentQuotaUsage . " out of " . (int)$totalQueryQuota . ")";
        }
    }
}
