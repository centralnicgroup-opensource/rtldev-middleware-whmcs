<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxPIqdt5iYPoaE17NfZdiDE8yF4kf7isXjM6zMku1Qw3d/DSp36fTc6PYoXb6SCzN7LYtSvV
mrlWeckAKQk4sfNPECoBN3E/7Dehd6h3Uo/bGoCEnhRjC/7EWf8iJ6IyUDVYGcoNx0wcc3YRpcXt
88UJwHHwnthytdE98e+fsFIL6jN0QgvBxPsyRgB6rOfQGFZVSV4fQpABbRjHiqU1hDcfCO5Perfs
Sz2MPGt6gO63w4giiUGtYyuTNmByUMZ3B1Kz2ku+vZTL4SIu8of24mbqKokYRfN25XXL4wEAfX4y
JHF8G2EXC7pRSLFHrbafX5zjDO1SuASEOtL5Q4uTAovH3A2cje8riu1RE7xZePSKFkz+suyqL4uD
eg0YeaUTO9Kr5tIYkRbdeU/h6AKnUMMx5rbSt7Fda/S279N+sV5VO8dNTwKHjmn0zZPuzaJkWeLX
500RGhQZDGBDKICZFXLxduc4A8VITrsI6JdYethrtpQTkapAdTbZw9FxMEcsZne0lfkx+iSkry+O
7GrSY7VDU1heHytHkWbw9gwOWYbwzcCzXNMBpNejUelpIpvR4ta6rX6+Rd4/5jcZLysE//DSWgWn
Mo5haX/o7RsCRFnSOIfj5LXqdAbtpo3W22CYfqgU9nd/ITdhKFbNP4PUnCw0IvuXLEACzzVjrdmb
wIoNSTQP7DqxcOtdaWhFOIg3zex6FZ/XdsvLOsB/v3VAxnZkozJOL+wxBPwlePbe6Z9TlCBNLzgh
p0p/Si3sjzwHHtqevjTz6Ki/BScWIXyNYEUNvn9XDB09ItSYqxDeTs5AOVsBdETfFjHqjgG9/xaq
dcXuHqO1jyZZujOeFSIBj42SzaTxOrCSYhEN098GrTFoCaEEwzgpH7we4lVDxxsHNYa1GMcUtPBv
8sMn0nBO9oj7/OaIz9BH9ZYLTzX6az4RM67S5YZkQdNaOvtn7RmuO9QY4rhUR5q+O7NitAh0bk+T
/3Wh8rbXZhMZ3QD1ncFP0dAA4o0IE7u+h5/JMb0pg17TBqSBZJCrn9+WmujqaQzCpXm0S4t8KqdH
dDmG9XWOsWDRnyu5W2fOQHZS+qYLM6xp54JpSszmG73pC3O1qCZjr1zakz3WyaUC5fY8nE9zJ9Ys
DZ2GiyD6Br2/S5lcR2n6Ax7ASF2aoSMIYGk3PY4kVy1AbXN9DGHLi6c+aavk55vc9pZ+on5P07RA
qsrxRfUUZy94ZXb9B0Aq8CNh6lp7ykZCnzkoK7l8NNnBaXOS/n17BsY0RBrUSYr+Y9Vvgzh1rhSp
YQuVCghd00eS0LJ6VeScw3FSaN1Tjk3tN2udFmDC2FZVRjiKbzyuyOMa7+JMTS2CmA+GAblx9arD
LI3yvVQJwFYxRkbCwkVp9E6naSt6PqaaMk0NuBPKs9AgiME2uQ+WC4n/zzOZy+NVJeSkqcC/LNV9
LOhRWMnmUscH8FckjiWNrZtA3ePsSB5odTl1YL2em4hXndrOzVMnq+ZeXg2SdbSrv4IYh4ZlEOZJ
Z2uOqigRIP6J7ZhGpMpjXzN/tDMM1HWUZJqEYHjiItENJLYHoAt8HS1rr7k+19NC0871ltw1AC1W
Gq2mj3WNCgTNrGj4aHS+Y/hTC4Y8jEQI+HKkb0H9jB+2xfVSnCSi1yiomhA4g1VvTGxpDuAOvtCo
aLhlojdBmGXBJBXXpa1oO0H/ybXychJKo6jcISSb4EvYLysxsHnQyAdNebd2i/25o7yt/k8EQqj5
EZ+3xZJKmmY2vEYbAaWYWxVgRIydahasG4aTdnVcTVAtr0niQdnnfPHEuypwWlxskPy/EPCbO34g
QF4Xzr+m/SBgUFBSMnGVRIfrDe3WzLle7qR0J0ChajZhmHMIawBOxCA53lLnP8WeSSDTiDIe9CEA
LlX6l85JIY0c7YQKPeyY7epNxbQuCFt821X1HTsGh9jqBXdC7CUconMQ9rOe0oEpKaW5qMCWyRHf
Vl8XBqqY6e9nQ7cJ+2IoBX8G6J2qVQnFj5jSjC+PDXmY41O7rdG0DtkuC5GCQGTNKCS8smvWHqfw
gqA6646iqA0xzGGedTEpaX2TcG/Fp90/s9SBLYenlFLBGo891zB+DptFHz538TVGcCN06ALAfPNi
