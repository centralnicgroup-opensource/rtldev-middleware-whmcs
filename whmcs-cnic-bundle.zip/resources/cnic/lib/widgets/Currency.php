<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt9hPPo2j5tKMzdmlx+ALxvwrYvLmzaU4AcuSeO2nJznz9iNdeGDpb3lZHAS1W8pFRYCrMqZ
++vWcCK8v3Bsj1M5R+qLZ8K5cykbcyiKU2lhrDRdHW45H279STXBh5JB2RKhP10RAXwV2v8UOqrm
XqU6fiMwA96wAGTxK+sJxSlCZEH1p5+cKw7BZu1VYh34gaxRpoTrhZ2/1SN8MJ5CpxobitBUO6wd
5tNn+wbElajqRpj6bMdqcQLPvoS9iHQ5InN+Vx3TJcoLmpISkowBr9pBQJfgMMmZZTO15RPaLalX
leSbnj8YUNHjUJLEYUxvmSr9YqU93wV3uwKQIX+ynt2duxiYDu88kWZz41QsnObFJHJeWIe+bC4B
jBZMbdXqW+HA6McohcBCJyqRUMVsLyRsmEdqQ83lYGqwQSrDbK1l3W63dVL0V2D0ajc/1AwschH6
9ckwepqVREXUG2bXkP4ptnBwlhMxiP15KDyWEUmh4l7wpfC62VrnzgECK2FEwfATjvcwkTqSXzCo
zLufDe7O2WQNzbUMCz8qMLE/LJ6zNCDDtWelhqpG9uM/B3Yt86rheNCLXMhL1ICT+HeiWlqKzFml
zK38AdHdoEaNKxTDYhZ3HsXUtk8ndBvkmF+mPNNekrEI+G9QJv+dLChFUDVk/jTU0t4JFnC1nlm3
t34C3t/B3c+//1xrQyRQNDV61zL+bVxF161FAzw5hUDdP+kv7jKusoMNutVUDIKP6xgz1ZQHWvAO
QJ/qRSluk2aSNwcgWjHA4PV3gED3DvFyn3ffsM401dfZYlbtNIxykARA43/+lpltwvtJtCZqKKdv
1IlR7hH02gcSPqmBp2Y7Kfgn7ZkRct4EvOMUCVp7eGYUbVEzdUEz3qDnxVlFgyUq2BwwjJ5Qucst
xs78wEMq0UxlGMNUYLzMyPV7HpGPAt4F8vs0cZ/gHn2eIvIznVdOZ7KUWPmUx+XuHkQ6QI/12tFl
ZmJVSvzGX34hMeL/ElnTS7dl2+BI02nPEsTIKcFclwl21e2Uvuo9eBMskFbb1tXwcDbTfX6Ts0px
yZqnic78MRUqxfYTh2s5q5okt72+D9+03kcqT0DCgi9LWRmzh3Y/1sLjh4CNIwSmgTr+hghFOP/z
WJvjvX6AhVO5DB9lwgvxZxSm8T+ZQ7Cxa6HtXNwH12X46VEhpL5yPLmD0lxNIHm63rwnYjnDNjhl
PloScnLAbKBvaFdkj8mWVYINjKHX7Rg9y3WIEn9JToyfvhJdgCjq5c+gPrTOLE6dgRNG9bIHeaEO
DfuMItZYzsx6EDCvop+/1ia2tXKWse/qGBJW/S5GPdxr3+Dc/cgeB2Y17hNce+1WIxiZvxrFvtXx
G3u6bcBCBWouL4iL9jVGOpQH1b5iOO12xL37433r4kdUf+HT1VAGzOc545IySELFkunQmloUp6ff
rQhS30g7lkcV3O2DE7crRMnw+jpKhIT/RMnP7lDepCUaefzzjvDJEe5ANNxTH47xAaO8ZcR3O2UQ
ZAU7DTu1uW0N2rT2KMTvLGBdC1qdM/6jcVSlESklY7mQXPJcE29kkkVYJqIya8HJtyqAi+HZ2W4q
OOltpS4H/HE6+fCWksDOu5o7znAIc3H8ES5EyHFmIuUSFzMRtuBExAuVH+etGm5W2Ckpb5tL67f3
25tEfYYTshtb43fSgJR09anNxCzi/vKxg1qLLZPCI1ITy8txrx4kAlULa75+J0F6dO1EXD+sjioK
W4zZZSN2yK7+RpRmGO0qAD4LnMFu3BVkFm7rkZ799UGGhW90GFw8arXdK87cIEFLcQ8NdD4G5xSe
Oec5UOEKTBn5Z8inp2ju27oX5CnSJ4tYsfXXWXjdJ0epjI+3iIG5ldQST+2/aivrxwy/S/5rZvs2
+DLgKZCuw7LS1V7FXexC8LafE0PDVJ3eO7E1kIfg0+TsoAz1jVeRw19KGwenBo87HFFEkMjCNplp
bAWav8aYJqDUW/K72aQuAxBPxcEh6wvSICluVTbDsYZZ2WcphheZ80PF8jzk3oc8MO5dE0h6QRZG
yU2OQldzT2kCiD8Ggz4+qfjlc7Gh/RdHYJCTiQTglxm3S1JtxF5llkvhBBdVJqc4G92th2kkUSi=