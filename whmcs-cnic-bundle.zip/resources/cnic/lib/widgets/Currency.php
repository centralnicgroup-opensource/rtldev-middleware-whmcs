<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuYxItsbXR1oi0dUNkBGioRw/zasW/NmEDOcngBoYk73Ao6p+m4g/g4QBpvqumzkOGEaTNme
QY1tPMNHegqowTdEUo5Xwfx5J/NfEbgmKzPbrPawL30aW63PmKSBRyc5b12DgukjIZa3ITr3e1aw
LP10eP5rczRLiFb6ZZZ/q9WeX3Ez0wJ44yHaxYGwpxA/M+FeyVyNxv1LrGoIxQwwmpflPfc4Tkx3
Y6l2UCB5OEhuKO9VM5SMRFNN3OTSze8LAThNb9tl0kntYEvn2mU+CZ5uloET1d0Dsc9xuKndqoSU
2L6LY1cax7YU7t8sjRGxn7pvrPTKJbZ9d7eZ2ISeqXLdqBYMxw7XwFGMlCOYjte7/DEAi8upMtiN
YavvlFuNcReR3cy5j6X4Djbp/UChyAlYYAq/XUxc04PbrR+3vuHceiSQ+G9RU/+6X1syFs8GihSF
UrR9PEglqFdYP+PAzl0kuDOW91huYSo/0XuMev6tYUn7FyrduvIBijjZsvuPH7FJwxa+mzARHKAP
TZPD1bGZpk7RXg1urbRrOjMcmxPtm1ucjws8j+AdkPgC3VH57113d3Zo+Pd9KOSMuFFsb3xswRDC
W6y0yQXqlmE7euzVNnKFk9eFHs6aT8cMsIWCSItyPlHqkPW2jobQ5/+XvyQpH0PIhr5MgxP/iBDc
1aUMwvLMa5E35om1lnl33JIc5tgFdE/AVQLSfG+o0wNHQMf/ClH1V3SAyIPB8rH52j9RrO6o7d9+
J3LldWZ9cJ9bD2/65JyYiPGud7YihIDqsALRRQPdHriDyycumpuOOmR1WXdGAocDyRmlXN0o2+8Z
iiuKKGyvYaqp6oWixYP51AZdBoLCV+3JOv9hWgL5P7FvlXqTleAUZ1OhoQLWCFk/2DR+D5+blzIE
3SHob87mxBSdbKtrdivJA+KRbgkXerro3SZ8t8/Bsswy2DKbOr0M/ibiJjp/kaIXS3BPvr4j4SDV
vp4dLHvGjPS7W4qu0MUOIaFTJs2TB0Pb2qgnln9qHfFL2JBT2ZDclwy0OMvEUiQGwsxSsadud4+Z
Q0HMCjmrbpFQl6Ux57qVIDRffuXE76f+b9TUGMWUWUcGr/Mu7oQTMXzAB3zdrdn7+BXrT3u399Jm
7D703HeVdwnfnQ0RPWe1aj0xz1waTVveSOqgRIMNx5awrzrj8TYFV7LLJLxqyd72FYtHyCMr02WN
q9MRBxpXuXFSFxlzpnyu57V8+j2et+GhrOPVrLD/uI5GWdby5mwG0Jjko0CSboKNWMmeEUAzE290
gK/Cy6h4NZSZs6k3SXmVbCFCEfNRP0SJSJkV9MEyAF+2kiBQucZgSakpvng03mx/mhpzGTCJ4PfS
pG2JNfQUyUWzTYtYz5SfL4/KRNAbInkMcQF2g7P4NUW6dz+2zoNkJZghPu6ilYprTftVjyFBHkwk
NJd7QMkU6imG81z71BqcLxu7/qTLP9Jg4Vs9D+vCWrT6XfiR7gVqlIRpqPa2omeVMv+41qrx0oZP
RAfxHi9cWT1KjRN8e+bBMlfQ1cEJr9a4mpJN2CUwqu9brqzWd9WbGtxOmGckd3tLdP54tLl+AM+L
lAJzRzkIAk/lPT8L6vAWJpkQLiZ9Jho+cWjlIO15QdwMQrWg+j7ifqIiVre6kC7tYEwzfUotS2Ii
xjLLrVhoI8nd4n28RRE0MSI65Z/flyXlkHnSO0FoAJPVMjni5KALbbY3VdVitnI6nS9iOZTPYc8m
1C96XEg64XofQi6tpzCt0eXXghBYeMn/YJwMDLo/OLHK24aE406Pq2WtpOpWHtsIaIozWGAyxgb/
F/a3avye+20hdog2GsIFc2LCtumuoialT4scde++Y8uH9iGwXOhJf7LlKQJnPlFlSNqomB+IemRa
ocHpjBDi2vqRVJ61YTw1dP+HssxW0iaW7Ut98fmeqcdaRKfUN5WTm36EcbywFWKdNBCVlrCVgSpw
ISmfYU189PwFE8KmGc2BNKwgm6doOPzo5sHieQIsRBx6R6EhW2rC+Ru9713apDs4z6mT9+RXOrGt
rebWHksOFKU4yFaofi18hVnplZupsmZOxWC60xeVp83KJxDybX56