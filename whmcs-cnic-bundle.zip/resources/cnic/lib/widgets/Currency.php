<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtea9O2m2vwtJPQmewPytu4b3j2SBuRwXOYut3B0DVYJc/MPz5o3xF4/vLqsJ7Yq4r54xIje
Y0LoRs4oY9voBddjjc096gChMPl2NEN6HrtxilsvYOYbfkpNGQTV/9IibwkvuWB1YCfAO4B0Yghd
slA4fJ39S/hvVz00NfLgshjtUdihAT9ab4c9Qb23iQJhaYXcGhdC07EFajvwt7l4+3NUTQNqH2Nz
XbqlqWRvCUz4Bs0VNBnCofoLzaJW5rnaHm7z38PGOQjJKu8SAFAUjXXANGHkhZHGfPY3bAe8XTZs
BwXq9WOd1HnnbeaXlwU4VHG3ix4eJzhx9nKWYi+hweiARAr6GVJ2mee8bCKfUelL2CI8iyU3VPBa
U8uT3Bc2sQHeHVlSaaymUQQY7LBYYp63k9k23y5L5//IGU4ICMXAJL8MBm/bZHTcGHGnGHlg3IbH
iym1nuHP2KnWGNezzqcNK7LQ8iS/LhQYSKWNJsn7GriK9knmwtohDNRFd73WTxs0WrTecHLLYRvA
AxQUiFLG1afrnb86wH/A1u6caXNQngiZH74fEZvkiT/Q1HbUA83RPnyfMh+AjYyDJSjhxVLiUlQM
0rdLme+FJ2CuigPOpH7OWp3kmntUdzJ2QXm23Brpx903ul+JISIRFgQN+dF/8Y1JVLvve7KCrUln
sl0HdUIBXwQII8wXu/6VoYx6jZD2ylvllSy29uXmI6qs4GdkBemEus3CsmJN7FtHiU/jmcZkt3ri
CB8rOAmxy6JYLTxfOd4X5QDiwkDc2WDxp/PuHK5YSDgSBcmVxX4MohUdjOOTHomUDRBl78OsLvmP
DjhHP3OFTU7Zi6MXW+y905ze4v72FUlQnp2ZW3HdgjQccRQKSmqGrImG1mRafuR6Riy8fHPwjGPx
DiE8VbtUccAzMrgB+iwRuaJCxqXVAQYam7n0JgfscC5LZ7rtPnFTrKktu4nKWDNx6H7CiuzDcjxx
6Je8WF16YHxNPdMF8Cx5MKkrYKMarSjztCi5oQrTiJSZ1PnDc2tH9oNLgNYXD7MgqzWzu4fB/Ykz
fOWCpg0tI/CJDztD5LL5RBfWCejU7E6Vh58lT9G/kJVjc3sP0XcpxXoSir3G3zqVusj1aGPt6Ryd
WVPWMcJxj1olTjJxc/6KwNnMLBlUuZPkwW6v0ekEpBw4DxzM+hIADIfwE32Efgrx9YSUuok8XF1l
Zp1yClmCTgKYTey1TLIjliBBc84bLbY+uBadc3c/Q64pVKZkZ98zPgntofVB5JKT49dcA8uzAXVD
LtIaBU0lBP3+aU98LOABRHokQ8ofiHdWtbcf4Lh3tx3XyafvQMSeeol69HRD3aa5dYV/AAKRfl2h
FKemlr0rSnx/K39dr01nnKKvPzLrMdbVZ4Xw40lGZBIlT8dOgM7zqxh+aNQgjKSwdeCD3nIxCmRC
hB+rr79MUrMwqXd3a/a4iHqv828q886WHufTzY7oRY/fQ/nLyKo9ccbqVGCcDEzyjwrwlX9dSmOi
L+xGzx9i9in0J7eAHUQMvtu+RQ3cJd2cTdTskwOUBeemwr/iXQa85u4p1gnsUjvAUIo+ilumvj39
WKCOe+s0YBaWI3J20L6ju3c3O6egXDN/DkZzGurPM7HI30h6Amw9g+i49YiBxBWBgpsmWtZlXJby
wYmMM5T0N6kWSfIB6O+wIfDKH4TSdu2YzZd/q0EpyUL8z75caioCFOPGUkhpn9NBS/aT80Dz9cvm
MqP2dNfw3vkYFUQbdzUQH+shvp1MXrFLGUvwYiisTOOnGs+b81X+bfGTvhOnD0BdKYduWa0sqqBa
ZKuQBa1OSIcRu+rY7GORbF/uv3vjJV8Qg9J1jJ6jqW9EchuIXejYBQUFCs5nl9u3N3838cjBtid4
ztF0uwFPDzM3BkjJerhJzWTSEl5WumY/u4PPBRfG9SWocj5jjvlnWNKXFjFdN5TyKGkjRjnu7jMa
QiCYLvhdH6ndKNMBSNxkwzQI+qQrwnt92Rdt0I9rX9PKCUsMZ70Dr0p2SCZget4m9MHCNKh/RIPs
UdYGaMQFp4cNGiMkXTycGy0BgddEvVQgg+wzkL7kmGY34m0OxgTiaSho