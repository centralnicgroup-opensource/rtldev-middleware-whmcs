<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw3MHMxtFhv1ZcJGJG0dPKpT6vYhdmkS0FWCrdwfOf474eYU79gMxc7898U159HAv8n4YmR3
Xj8SsYCqzNrmFTOY7dtLG/wD5LIAjEwTXIDt45CZ7JZuiWcWZgRcM8t5zwdSuEJtHlVmP6sEPRQT
SZOn70RiDaZta8Nnknn3O69OwZatctjsDqhukqbB38+Tasbf3qhLu2BGidklGP71tDl+k1+lznm/
4XR6bvZx7beVss5vt4gBdVQiVndaIX6IDNZn/YqtSMaNgVaeYGs+i8eP79IKYcXt86oyCt9UFzGy
KA8dw5t/LMDK6LRJSwDMEuA3wjhy8wTTP3lUVjqIKHhulQAufU2Hsj0IRzSSUzjH6TpCEEVyeOoi
u8EP3OE5Ln/bcoG0gDS4EG3Ab8Bx0JtOjE4jq7oZ+jGrhRdlsQ2uqKCSt58mFGx+rYSibZ54q5jJ
vXt4SsfcmRVL2GGumXAbOaXfeBgAS4hJOzf17RUKqDbDBwCeGhJAhtHyTVHMlgbrkDq9VewNaNVH
cPLergjP4livbQpoq6MyasTIEmWgwt4r5YmcLZWU7E+CjdoE7KKZAJxJ44dHLv9/EcTKPL0Zsrvw
pGe3dxOVL1cXsTsnhJVKA5dcQA211s3bz8ebWeN8EiSg9Yv4CY0PwbRdBky/hPshQrg5MMoAPDq1
6IDwKUU9KEP1Sc2AJBMyNAu76h36lrDkXaSSVP2M53dvMmvhen7ZgoRPxYuiYLOGBiUXstXztOsp
dbsAuYmWNhOUVFkMdRUCz+pF+5uHcHk9mK8VZjANbyDa8nPUhwXAZhvtsn4GkimJP5qLlMYGd9ng
VUm9hw31jxnt+4YOf4Jr8FGW7Peut0DktTIm3pa1FrkNN4VrABQHd15f5IBkPnUTJhqtckltP29k
a+wfyFHTI8coSZinoALGQPb7Y9tmzRHXN7i/EVApeaDOZ3gWdo16sK4AgF/47XrShn7hOyeLe879
ZF09ETDhbe+IdDPGPMK1dXkcxbj03+fPZnkjagocvzv2rxsy2DrxsM6/mLtQYMyvHHX8R0pDy85+
UwaOIiyu3MkIUETuFfh2uxPh8x55ijx3RtF2GYr0+onnsW8GiNeoCf6NdxRh0/LIseE1tPNMqfan
9ub3w1ncnQsBebZCObUwUX5O3F2Sj6s/MBXzoiOmkjabvSsHfNAz0isbmWjRbER/T4PcJax0/lVa
Mg8dTOtNpbTexcN/+fidALZw+NXmQA17PuIRrYuNMgeQSpxe5hP5N0gqhWB5Y1kPUxGMb9Kq6IkI
J3SFkE0IC3DMvSrLJAycv6bcljFe0mHM2EJvK1lGFQHgI3jvLvQssnBuNwZvfqeL49eEKWGm5EzE
s+LLFh+hzLgHD3tymSfQALwiqlzAHKp1RDZxtqwJEkhn2BO9D//JVRHPNLssCItzAGpDtLZitqrD
85NCfR0ZMyQe1VQqDBjAf/l6xsakvBUoTZ9l2TQlGZ+VV162DWZMqphCT5EVkQB6wGULH7XFT7xR
9qMHEdo2X0OVUJdQFSK1PrKUfbjpqxfjOFvti5GMwpvAa9zyPA1Oacug/TLAz67pZcDG79bKoMJt
35KuV+KugCD3g43oZDdJpBU9v5VrI7zhK+c9p1gpR+6xydFPO6WNv2BoRGV1mx/X7wYyS5hNZ/J5
47z+8VWrX5NFGO2VtJKq1wgMlS3DxunL/m8fI8glZcSlpecSKejEAplxqmuuRClkTW5nk76S/NCJ
j/ZZMPMq9z4N6eJYJDxoWTFk/2FO6AdTgFupav4Mvg+TvH9nRMUVv9yNE1hWsS00eUphQLkW7taM
BasWXju3ifUly4iBETU4N40wVycQ1LVqv5N3OeXM0FHjDURELLLDfFSlUWjpTs5gX9aZTjnwAe9b
hndTLO2eBbZK+7abbOmBwp5/GnW0bm28jNdg5YcFMjZU2mKeiLjIm4gtYab9FkccxRfZo6iU+zRP
KrqF41VTUKS0nt4TkCPll5cBTS3EAjXz+LlzKzjYCb63WUjD6L/kcshcT4/VHwY7k0LNHmil98Zl
80mALDmpC1GdugCE4GJ/9HB0mCViLEqr2mUPr7RENw0+XiMLTwYxBiJavFwg8wJQX0==