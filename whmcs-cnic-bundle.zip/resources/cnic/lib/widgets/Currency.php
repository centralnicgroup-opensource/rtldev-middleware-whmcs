<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwXd+RRIoS6vgzLibQkliX0CNtcPXw1cquQu/XaBIHHzO2bUXBZH+kpeYcP/bmzGbDKwoxpc
D1zNUSBvKO+zzLVaf+BfBhXYB7NebgU9THcRd7SmQj09yO7QsdprCVvylJkiJShfatBoHS4laUG8
6TKP2j4T/RH2MozqzbcuSQrmfuId8jCX8LiensHmesUlCH2kiBOt3DMKMAKHPEytY7QH/zzdo8TK
SdrRPbAAlwPmQk8rFHR+K9TPJQwa5atTgRfWiVziFXhP3NoA6aoR1ZAhpLnj/V2wge09MR+DYSuX
EeW/oKOwtFmLJE/ryG3EqGk+KygNuYgmmmu9OBO49DZICw+1WpfGrzv7LPlTHG0oxRTnTxzvP4Lm
wqeL7XdgmMs+AJ6BeCYDJcfYithp1lT+e84SRVmOmjL2hbNKGs9+kR04LXZjkjU5zy2CfY02FsKL
5k+7bc+Sl+Qw3FeeRgH2m7jRo6tnMw6Y79Ee+shxD3Mt+vydKqQBhzfGD/mhLhH0eYQ4lU58gPoG
Kai1jxIx9qdmWDxE57EerzRJTHAf8nHrbLKOTaEr8N3gYf/F6JMaXllhOuL8uyrrscKT9gnn0iz9
KVh5foG5HUTH4IZ5LeOKKtEweGTG4u4VnHuOvDLff5Vn+r3/0I8cTpV1oDPWjT5YR76RrSM03R9E
fUHuzeSBGAhOMACBsBAstQZAnNn05Rw0YiLiDkZfdezCrCGmOwobxN6HvRIQvQ8jm2s7Uyv0X7nu
3a+qMKFkrlRxSXlN2X1w6edJQxGHlpG47WEp9UVJOUdJW/LpIbdrwS5zTEKDyUwKoMZYHcscByPR
6nNguDNwrlMJ9SMkgQDY3yj78Gizjd3DmRw+qJA+X5wFRlWaQlobOd9vI7U0TutppIUMt2SMmWpE
tF3zXURNS0jWD1abYc3462n77Glf9tVs4C6XVINTh/A9+aoa28WzTFKClbbFlS+AnMbVmTvAD2T1
hBdtpcuJ2/yeqywtlQ5Hn1R8MMyqsAJPorTdyieSB+l7aCfVfefaC/jNvjUutUP2pZRXmE+bGUM7
wPn9XTLHO5TkF/soWuegzlKwLRD7gravrwEmP7ctRyKK/JVzkbM2VEzSVVaqeRaMX14piq0YdkWr
m/pTjV/7Us61ixPH7/fpNlC6CCFrrjJwago7S/sgTGXaH7CaXzcjVEQ+iw/SypZpeAB+S2qZ45NC
B57v727s6DDjw577ZufC7Mp0i7/VYEMcw7DS4uMj2daH5h1a8HJ7h2Em0Loi6IaqUmWN+NPQreRx
5VMGZv69W/O21yV2YmjKehhK8yvcdX6K8mv3vnHX9jIxE/jqeoC902yXLm5gMehSkrDO9Stqq/P1
+NXNUa2cDWj+3PT6wl73bfUb9RILy2Ik4VDkrWJPpOFsbXV7zFlt787XCdmdUJAzbdITUrLInWbf
JbsZ+ZsoFJJg3lSRtyGWBbP1p6ov3PkvvIBURi3m/yonA6V/tWkg6JCYKT6+56pSGYRxvIzDovOG
KMHlSc7QFp+VmjQtcqIMV1oSSaDTH+JhevWdiacKvo9RkLhiWDtkXNVSHTzTOokVLMTYmmF4FrZ9
tBLH2HjSbB0WEv8X+Aag4DuO4QQnPUO1NUUv8ibXPS4PHlu7OBPBze9+E3bO1qYeassuNFfzvcep
WV+uT7kVUfkWAcWQ525/QzVPIgcwkrY/N4z0DQln+LftUvi6NwQ83KNaxgwsGSDb3t5rNnN0Cnrv
s1VD1jzToRuRDX3RoxgQFfwHSszZgSHCr95wHsbSqIXo6cwen6WjQdrV6G21H3jb2Ylm85UlyBjR
7US1/SfbOQkDLO+Xi/ujqtBjIFwZ9J8DNfvHxPlJatF8oEXRPYu453aGSlGhQPbIQfSqfsmOcrjN
+u+V+ieUXmq/dxwWz/ZViPHLADKp/HrQSTyncmtrsQgDEYqdFUWDOyoc/uXT7bibdK9y0VZppJIQ
7g1YNhZV6MtlO9cJnthZ74ZI3jDfHJWP4ugyESr3DrHT2QxHFitQWdHE9YRGQ1DG5scBceLwiikJ
jcV582/fVJeqQvCtIetXhvXbZj2RGYFyAh/OfH3B