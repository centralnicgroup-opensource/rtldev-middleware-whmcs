<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyEF/+mgFb653SSzgGcbWAUtXaEghRMSJx2uORrR/oNH9iqItVDYxG4pvYhOMAoTb/1JMhpX
jRoCN5bNBYBvP26RUJhbJpLRiXTYPLMcSzA89AZK/UTvbiVqDTwFMyBf7mELdrwwaSPG272KlBMs
+3A0NIKGyFauJhrcFYkiGqU4XtexCPX9aln51i2POvZ8DP/T0+fIpphtV+O2/sNz2KziN5D4sTfv
e3idhdE8dYdQZGzvjvHW3/eF4t1Bw5JcPRQm1RvSKut9IebCxzBCMPaEOHnhMm7SLXGLCVq74ja7
I6Sg/u/jPPC2/nBhi7x1lepZdRUNFl81W/CrX4h65J9q6GIaLqAH44yLys/jSJVOuRUxx8oCarUD
D1QGCgTMQosbqdL/tlI8oV03KfvSHQ/iDu/6W2xI6EfvzYS0edliOAFB8dQ5KIQTDkkZagCr+EVQ
4RenTnZiFHJm3Plwoo2kCFBbgr0cIJYYz3NnckHCeaRjZISqWU+xu8kRgTgYDi78nk6K0w7VWq87
6hRmSWA6QZ44J+qbuqsARu+11RCIXt8HY/h1uCxJJ/uF+qdR0Hdqy/I/spfEHRJYiv0PXhrCGUmd
AvdDXHcI6iZP2ZrG/6nN++Ex9PWeQGjRVpCRqqY8qZUJXQb8Cj5CGlt9SFzVs7/s62tCQ174njoI
P3SBw1x1Q+QYtkCWR7EhEsz+gNupGgVMuYjsf8p2HmKe6wlURXQUcuuJJKmx25RgKhNfYAKRAPlJ
XhR7nxocugS2LhMop+MHeG+b7TqjAk6XVH24zlotZ0NUkL61QnBRgN06cuKTGCZADYycE3ZapPMl
4hnrqchRIBL/boDJQwuLwLZbjJxB1wYC4eisDe51M1MODYiYtoccW5Mj1lS41oSDs+IdBBWiQbK3
KZZFHK3gQgGLJiUDLElxWY9tpLHhv2eixWXZ9JHr++phrsGuB0NbsgmAFjUJppI+B0IZprYO0BVf
RYClCSSkOW5UWciPcne4EpgZ530fQMCF2tX+MvTnVruIO8YKpcFkD4Qs36mBxb4z/7zFx0oaAR1T
VapYTzvCc6gUXoCLzorVQj6eGKoTebJkVVRCbQt7J48PLRW0Yt97v3BU0ZNyXWMV7f9J+hatmMqw
Owsv7RD2PPevM5ChdaZVBfipqhXLLVDqeRnDoPtgNX1b4Y/yqW8LlMFgEb5EFSNvNzdnQuBkcQTr
ONjFz1zGkxHyO45MbYYUcchvsnaha/ncZeSaaObNfFfcZ5MPoUGgE4UoFcUT45VJQgF4jMVdih6y
FtLPJvaDEmfXd1DZRcxnHUZNJkpoHlSrO07HZf/vG42i0eS1HZwIVNmJ/ulZCsecH+jQVI2hMkS1
B330GVdEtxFdEkK+FYmUz1jZ4iwF28S5leYe3J/jyiV4Kn2UXQOtq2qLyuzCn+yV6YoZtZZ+JV/d
BwZQY/mim3i6gzyrUjcgbtFslwc8L0lHXeQaKhZIP/W3hl/1V2XOAjNOxln+qzbum5CtKf+PgfKZ
USp6dGw5GLyoNG35aPv57SvR2EGFZqBeE3Xc7U/BOgVYNRirmxgBCXlpjlfnKUgT1pFgMtQmxY0c
zimqCti7eTocCWLKBruoV44zXziqTEh0P2vJHUyERryrgnFVPghZ6OMtpSbeMG4D1TUZrIy3T/F9
kX9uNiUS5ctVb6Bz5KjKZNLdjmVdFnvSmI0fPHt6YVKAnLem75ldvQkC7cCHvfAFv5R5q3Cp6eZJ
+xqjUFnfNdmiOGan35Id5YJSXmiTZACebMzMJKyw1TuEsRd4n0KzqNvnYx06geXsoTRLLGwGzRnr
gTxuH6PZKsoLUol3ewFP5VuOxnYtf/y6oaCV7xq8X/z3R5yUCQ5oaO6hc1UjGMtmNy3pOcDfLtn7
LLQz7jlNn/ODHxVpxI/htiMQ7zj1o3+1JCeLj9ER2bhvoA/CenC5ljG8Va1bAsbFPZQ43lgWa9ZF
e8mnY2NFv66BnDuf+WxQEvL+uH++xgFr2yfPV1luhpwmNdYk2e8eXmPK2AeoVo2VtIVfjWerf+Hp
0BX939dNUiNy5TgcunBuRgKDvwvbKhzTZoaN