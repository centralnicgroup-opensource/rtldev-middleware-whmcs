<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs71w26OBj4MPNDz0fms3XxCqevoj8gQtesuM947Ras0C84T52VDHDw4CsUp6rSJpoYFyNS4
PbRtLoTSl1EAqpscGh/QOR2QvPZ3mN0SLjcb9DUpayeSvA1vSFJMbrZwwft0oKSK8BYKrJOICC+0
neG1xw5ozpY+svRdUWn+W07uaddS4ks0pDHOKjyuen8PPYXENzLRFLKNPPuJJ7KwhRKKxTLe+WkF
hFhiCGwyKZWT1Lcth53/8BacH0KhPCBiVhG+88+sbNsLarLopROfv+mPx9zdCapMdLuYo/3JWj57
UWXU/tdIvcgXae5erAoSiphL3iVAg+R65HAbKXb+caOvr60sKNnaZ8OX/v8JEhoPo/AYDOPKCwzl
uaxMLihbEYoXpopLM42Vs4/hfZfoe6NQPDtbiOl7nnkL4yiEpQnjXcaamGX+1WG9b3StStmkqUL6
NRnNdWKLGvN1mQi8YKwp7kavGgu7i+Xtw5DIWVu0h/ZysAMkcKK0x4+OjN9/BgElp6Aa2jPv2yzS
GvgazDkT5tgPg6xpeUCGVjI+a+JffNeOFpOmhqzSfc3YLs+Mn7TiL7l102/8sG2bkIEqzRODUeFs
PPBHA5u5BlE/KWbgiX6zkgtT7sh9yOXhrZvV4SKtbMB0PMetAZS2OFI/baisUiyb4fIyStU/AHNe
vGEmwNNkH2vqsD7NBmozSfhAxjaAGtDsG2WHCU8/OuEvdijiW42DlNzW58NNlhairgZb4BtPTOiS
+RXvAkc32mlswEoJ5aq25HMqYbb1KWURr/hnAnZzu23DVCg0kg7jkHpDge21xFS4MJOzN4DOBLto
+bPz+b9CzpMznSnZRNqZbY/qBwFzNlSvVh9j6rET8EYRwE2/fP5TNLRrv6ZuuVh4BnhvorMWWgOF
FZ6d7BoNIiZiqHnxtjWEE8ekL9HcSzGspcdMSn8bSDLqTgeEH2gHKjZjbd6fGgFOLXk96Co6RJuJ
Xoomg8fcHlyfo1bGXQ6nz/OQgepMceeV9ad+FaamwRrqJLCSt7T9ykEuLE2CooLJscTlMEiXdQ89
ykHkuzVDbcSxWzQ6z0fxrfFXmcoyQJTfGNiKlbDi8AeQHlUhtzjsx6ssaLZ+pNwj7qfAP75tR5iQ
4qt5Olnr0mOSu6fOdF1plchLbeziLCtyqyUEJ5ymT81KaD1rUKB2hqO9nu9DuqKuCjYURNG87HX0
rXrdrSWanJtQzbBYWDsM5Bi79CaiD0c9Kna4BtFphdpDC+hPlQeYU3k5UGPE3VdN49h0abXI1Dkc
vpLEBCYjl6jtl71EbULt5E77iu7nsjv4JwAvrT9bvoWbq/XdERZqekvG1+LQXIH4U/y1NC88koiO
V25yIrtEz/YNgebeMyfC0TLl3mA4JpTG88R75Rhz1hT50dWKeOUT6Gmk/96E+2vX6njxrxQPHK2u
4BcfAFYB0eSe6rmSPeSuDVfACD06dcjD4nfQ9YrQLzBBt+GIWZwsDKuMeIf2lHAOMtKwbvS+X8W1
7gUgab3xRVGmxXmrVaG3N/nXPcKIDe8vi4QWlPRhyTUxdrssSPXO+bC4a4BkWDxbLCFDNvSt6NMJ
bvzKaMYAUoykZ4KR87//E2O5CTS4PQICnhYBgrYrC+vhYmV5PAo1gof4c6zbmUXqTVmrNhZDQ6AY
8WYfxdRzKPY5JzXgCbB/MKcCtG8I5/UFbXiSDm7HNhU86r7NMJsJ0vk2fDx4oJxG0ZU3an7/q8HU
59c4YNL5unP1G5756u4eKoRQh4muszrU6s1XGdAjuE6t4neVT6id9Ky/Y2ygk+Y1Is3SDyOlybqT
TeKJrSqZudh4CTGIvxakz8tEZCTVrwFgPH0jDlt1C2ZeDp8rSXMYw/mRYMDbKGocITNU+laKjqGx
saTxcut4kbE5PsOSvF7jJYeHpa8Zo+0SjbKjY7VItsWUgjl/VdFG9/q2ECK/nF8MLZ24ZYpM8mKx
o0vNlFR0bZfsaAj4eR480iQo1RzQ1HrvjcqxsmtUY5EIQgBkd+5m+ROS9YDirhVdctVMzNo71uFA
uU38lmhc6gm6xN9R9jvRLclYBILthAdraYrT