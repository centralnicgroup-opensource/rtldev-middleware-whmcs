<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyIBhY8rLHCLm3ax0RuwOsXORGgZLlWjb9UuudkDTuOliXgI+bDapny/Z4sfGiuNoYssGQWo
4uPZIx7PmkgZvKr2DYFA0XMNNLRLLC21Ic/5EQz9dHNwDGtrKSLUh+4I2X+jd4N/7Rhdf0fZFq4k
AAUI/27lpZKE51tYCtg8+DFl0oyXZE0RbXzTtPlvdksM4fm8OvDWfqHWe51C2KADg20X9yWhIBzA
VXk+ArZaLO3ChFEuBoV8lzqETp8U83PohyqIKFHTFJwo43LofB0Qo/2MmobWr4al9r44vQUSTKED
QgTNZXHP/fnahkYpERBupyvIJl55V5FAAZiQMdX/Ac6WpsHVLVJrdNtDnfeeTJa2h/1j32we8L7N
0JemgtaVljZOcwTxIb7lCzyDUiddz4geT21iYjmGwOhVw+vmY2gJmOU9AwFCQcPJf98eypZPrRj8
f/Nahv6jicS1OEVE66WU3o+Yq3PjVFYQ61Nk7fkY+cENjofm88nazgLMROFoiYyg4oym6cSZ8yaV
hB9SEHOf6S5kxNOc2LwKJ0zCE2k1oghWDCdzlVLj9yOzzb0SHLDHPeyNqryBCOjSICYsVeBOdSB8
lG2fUh2nLdsw5KRrn60/X5fJoP6FCE5DBCcOI5Eysv96/n//oFBXb+Szecgo2eNwu6rEoFNqqeT0
T2l8QSTyP8p7CXJ5qbEe5N8n8eedAR/XxPctkafyedZSiZ5fGRuh3ckixBLoOBSOKxwweCjPKkoo
G/YUht2kHTYBUXky/F+M7uo9DbneHy/8yNqstEo9zfq37wEKuK8naFvDEPKB8xKoTD8zNC9I82D8
wVu4U/Li307sMgwtlj26/GKR7UCXoY3+WK2frBLmdNcxhdEob3AtCIbzuQf040lo4f+W3fBV0016
ipHRg1fQJj1Nh0HUfPtLDDKHCTv/R2wCEIBlVeRjlQZM0Uu/OLB6WgmWUBeqPzAsNHS+BJYBPUH4
scwW102a7Hy40GtEw7YJbtB1J5BQ7B18FYoF7Mqa5b2gPPR8lVfRdNnl8GAi+7qYY9chvA3G0gg8
c6D7x24TPAZOLTFzYnKRyI9YWey07Bt8A3Oz7n4aNueTDRZrU3w6GdeHRPVh+UOxrOJ1bZuchl2R
xkxHGtLgaRAmot2HLXR6mnZIa2nVtw486pLqd6ENCq0VjnMoFHpKh66MTkX7s5qkjhrj7MfvPnYS
vavmwalGHljydjYkUAlBd7Y1jxf24SJq8z5HhKrmqgfiYJkEPLChS8RjE9bY2UdnggdPGMJhl8Qq
UkfeFHYrWYesTn67IoCB8CQqYhlMDpRy7Jd+JO5k2ltuWgiJRE6VbcGY/++gTs3IDQF4yuoI4RVD
ue3YR1JNS/Z7Mm5DzeJ0R5Yupwztcc/3jehYoYdgBYCKEOSahy6eT2Jtr+mVpfy3EQy4HLqHfWx9
jIxKtpSvPhEL1g6865Ij6G20TJq8uWGKTmMyaCASxH3zApxyBw0YMMl7VnYwbmrmmMr3QLKNQTUf
h9LjfJINweraJd2SuWeB//6z3GngR6kSZlyWjllUsoT6k7hMLFfwSqaA5juhu/LZxhv4JBWoBDIj
0Y3Xmgr7tW0D1s5PwOSxWKFTvHsVjsTNlB5IPUmIBCblTOyMDU0SpMOIX5QyiHJQHupQkbD9aIlq
VpA97kJGEzXBsNrr+NsZSXNYL25Y9ojgPgNPtqO2I/C5y8vf9zp8K9gMOS88GTxNsGfaB13UWlM4
6gf6JD32eTbP+z6YaKfhZXTEA0XREKP3CXM9nKZl8hnmqHR/m3jm2aBORbtrjHmG/mYQZwHC5tGU
K7UIqj1Fq5wu2x19NzkYO4LWhghzXVh8FzDEvb3W4uVKjadsGBBsIA3Xu+Ij8hkmGT/C90J+wz+A
G7eUhJb17vqTVri31wJKPyXsT0dl0HNhNP4WH8RzI6nWg//31rfxVjGpIzWURSHdFTwkxOZzDfc1
CpkaLxutAIlwhJxFAw1K9kXE6Z9YWIxY7g/447/z0/JsGUkHn5ZOTnKI4htQDY1u2dh6d+1dLxgX
ncP7jrIAS+OA7urQnKb5RAKLC6Zp6h7OaKUI