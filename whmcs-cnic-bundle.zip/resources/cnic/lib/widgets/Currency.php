<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwaNq07B+IWsagL58e2I0huJXYVhT6jnuyDsVao0wRFpaSet39MDBhJ7I2E/gN54/Bu5EXgm
fgNz+PbDoC9gLIL1L5TLPCPsm6/4q3BghCLjEfnMH8p8d3VyYEaDfX//wDHSMvsWK0Wk8AdyuATd
clGr+eeco6O6uDXAGdTHuP9pCWn4y36GFRPDIpNvRXlxqfH1XPhhbIZYTWUPgIb9uqsXcMF3IuO1
tPoAKbFY77RiocSfTH1HZg/B+cIBGN8Sk5+aYqLnBc5XMRATCsgUDe4RlvwbQUrX0KcKnj8dwKHF
H+jdDVzgvjpK5m5F+BAtvYF73/1mPzf7hFysIaQzOd3mFfWOtir/pk3ynQv+wS3PhhNr/L6JnObh
MLR8T2RxhwqlIFOpVcl2OErGNsqd7+swd5us/z4trnqk9hE1nDXZEYuURAwGVQwL1FNNIGHNTDjJ
MrJymKe5Xu6hZrQAE59ZybKjqgEjE1kwgsDkrKdgGcMvuej8MAK8tSc4cbYzQMdMaj4JWb4mJbvm
UsTY6RFqDRx3K56Ovxza0jqeIT/VOFLIzDlX6SD4emdy0v7gM2Z7dxIc4YAPPgWbmHL/27+v8ca+
BidlklvUt3+raahV+fgPEJLQIufPREi2CEM8Xup+TgHp5Xf4uMD6KI1Zkt3lrSlU2tuF6gZCOzUJ
+q+G3g/rHpCX291h1AzhkOgCWgx3Ks7po6yrp2P5Fxb7YLd3TJ7jQG0Tm4DmlumGwOer/+X6OZT9
zeiUCuqlsOcXPqAqMbb7GnandlG+depIUYpVwjdVbVMKhtsg9yNE4k8KsezxfqMOkVcEFtQB8TT3
RuzUzhwnTiiWV+GLl8BGqZiHBL+s1LWiG3uIFh/K5ON+Zn8YANUOE0D0emeENz9Q90QLKiIA1Gov
vMCqcxN8Ab9CV3u3NQyVw3wRNmFeWcDzBSxBiCzCeEA4SN69gkT5V7T4pvrbMyecXnkgGYd9yCJP
QNEjezZNtRvkST7/3YBjTwuFo0E21UXqTh/rTJ+NnD/HWw1GKnbJdAlzVTkn98w8UkjsjKys4XWS
uoBF+GIPcz6E84EzntCiQ2BNGKd9UNx6RqVGg1mrcZWF78YGeA3zRxUIBKR9tCDr5BhUEdJUdWFC
Jr1/M3rjGJeMasPSV500Xg0CJxNe/hcgO9LZotkWVn+UHhJF6eO99iXbEuytOwHzXAyIGaUk8zC4
QrCNu7I0KcA5Oj2R/SXq04uOy5Q7+CGv/7l2BBWBSht3QCzLWsEy7hgAuKkO4+iGkfyLyE6SbAzt
bQjGT8H0p+pkiAd7FLZGnJZjuGTo+dUoWWy14GEaKCtoDv0peqkfRYLSRXkU3VzY+nBkuJBSZinL
jjQczMmwmkVMxm+CjetAKn/Pj5KG4J6fho3ZfIL0HaSMV5Sqk5orzFNKjMNQbQscXtU90kO7EzbQ
7q3e90eeCK2K6wBO4TKoGZ6K1dSfbnEyEeoTIFWFOHK24ew8AuYmKlpW1Y2hJvUGRjaf/F7g70MC
WPlWuesfZncJeY1+83Vr1fNWU41yJZBzB+TZt0siX/D0UzbQ7ASl0eFAHQCvHta8A+NuEAF/8TUU
CQQOWhpdAIsR2mL78zg9py0Of166jPmKrYcNOD7+XeBrZGAI71XbvbGPOk7jUky8iJ2Lmd3RXpI8
gV+qfp2PrR7x/fkpOR4Zcw8fActUaQ6SynWgpSC9X6xFA8DsIGwvzLrVMKOgMTY4iiG08v907+Px
mvihIeaQ2bz8C+6qiutuw9xKwT/+imYL+XVHjnNO1AbtCgX/DUNS6ymje4QaP99tNGruSnOC8N33
LulPtt6hde9stBs7JFnxL2kcFOLouh8mlFArNPXnW4TYj8uhZFoffQZJyGdADehn0NJ2/uPcE1f2
NcnjOVzZ/6kHFTSM+uo/cpDxuJaHdDZiFSqYM5Ku/e/whLhIbESFXlQAIWpYielVcOfaoHlyLFPH
LXG8KAQRaLetJRSZPfquuVyhE46Fws51XK+VKQUN573eCD0Mm+eJv30ZOgElhKbOwbqPW1ma3N5a
xfdoM44kYZPaf77OYLLIiq84c8KSNvQw5P5ovGHsQGukl1+SGGO=