<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwdooDgcKZ4Tlq1T+QJ9Acb/w0LhHM9JlVkpuIe7of0AQGU7QDjwk1lTrD/qkFKMMVykBI6d
vEAJuSm9Jt5qGmux9Hxpet1fXRnjcVUiTRwmGtbLwfHIOu7lJ76t2HVu9qNyxELoyZFgnA86D7r7
ECBM2w+XRm3N+6EnUGlvM1W9RZ47XV356MGQ6DJIqFrn59wQtc4bbHRzbo6ZOnGcsmp7o0L67kRe
wkm3MDmmbMq4bhOeDuRfCuq1+pH2y3bvSpeQppVM9qz4A2UD5RIy1AMk9vbvPsYqCi3gWaD8iFPt
0Qe73nKmoaZl1Dhk8whlmZ7+sdVB8s+3I72FjNlfa/mH76l0Rj//lJtTXlr+OxHuV0ST2JvkKGR0
janPvxBj1Y1j0JFGTuuNXYQilzcaahtjs3Of7X7zMb7Ouec93vwx6nKTltJCzY51aaB5xojMyJDI
Q2L8/wmgc+tnnPMa+FUxoEcv5Tj78mbFj19PgaPJFI5936I/uriiTHlvb8uEsA/CQRL6VLTFwgox
YEPTzZvycqYFsKJ5XI6aSleWeKMZVsl9RCZKcflH2TSmTmzm7UL/4SWDUdJfF/zerswxCbOuO850
MQjDf+tRwHLKktuAAmD7FTZjO9jAhOOp6U6GOHILBNd5LmvBbeoojzALNYDHgx+t6dBX/EHB4ZNf
imNZNarCSpgPCICPQFAD5lyUte5bu+Qt53N5bAYtXnifEMNNa0hmzZ/54vXbV8fCkFxUMeMRq2Si
5oDbrjua3vbfEpeD8rGGb/T+FzSPVncyGaaYlJLIGIL07z0uBoKO8I0Q46IvlaWNwE2pduWnWyLp
kl0GGISA7Z0Biwz8cIlSrekm8cXbaFu+7SPjOirLNXd8mBs4BHY009ivHxmfFvf7Zc78DcjuPVTN
H/vK4IS/fXCE0w6tcF5RuSxVMWPBhUEDZBv63ejHjvessjcnlhuhTw70kvgfGlahrdgMqPh1r9TD
2A6v8AJuWpUiUmIarL/7iB5WE0GTx0OHgO2G5SB7meEm31wOXGDSHzd3FGTiWAg2h5563bVTxg9k
jO0Tprv19Rqdi0LwDRKE0QCO90zWARloQu2f7FTTwm/QP6kiHAvKrRlePzE6l+47Tk7XfJSV14M3
az6EfLLdt2AKGg1WINhAXMBSspJ1wEkKnewpt+eNcVT7mD2SDcRphlR0+maLKDmeFTB5qyuXR5mD
TwL/9RY4CXXQE8LcnF4drGm1e5DeqLybBJSlpPLCUdlYV9rXFyAk9pzOc+WUQkgaKcJCzhD46bCi
/6lAsHwtFzvXh3M9j4QmbE0JOjsHHzvxRm2u6swrVN0NmdeC/AAqM0cj29+IgXmrJFYXDpMxN+ZB
NdjgZNJd4XHWAmyjbvbJSvZIlaBaV169Xctmv/mr4mjTWm6o5DJHAzpBqRNJFRh7gIq93VrbAUYI
iGirhqsdpURlYMD9QgtWgcEvNfTkHvTWu3inQf5Ap1P7JgvQCcRXTodNCIe4IB2/Q1dusx0Cc5oP
Vbgz94+FMyZx+fmrICbH4vDA4L526KCjIODXMutzSPg8J347LeFsz4MEB97ySpAyDfwKK4zWLq2D
1M0Zx9pwqrA8MNJYBaLBHB8tOVqjiUv31z5fzFAHCHAPEtJcNjfn+PCX72H09yPQTHKdwYX8txXH
IJS30zBzfoVs1qjfwikeskBtXSfs+5y1/tral+7/334uh5E2spJFThwBcDhiaSra2vnW0Vbc2S4V
kEQAmTCiXXCFUrUHeLTIpCPauW5lL2LvcgSIigjFxoi4sbrQ3U3l/qsFAPqs136WFbKMhSWNnEMN
Xa1LgjaKBTwSSThoSktdYgbE4YBpL+MILFZkcHWTLiCXxdSI4Zk8hlRv1O/x8ztSRV1+CGYIsR/a
RdYFDPmXrJ+Jg+zcI9CjlK/FApEpgUf9yc1/UgIgDb2qE/+7SNC8sWvoEzyFDmblFykP0sACQ/Bs
cywh/2SRfrZT5SgDlyqteDPo28i+jics6NcxXAHhwsg1M/k6z4Q+x23XGbtGc4gBwB5W/qmIPm/L
ZguzEniQn9+vMbg6dNdWeNA8j3C=