<?php

namespace CNIC\Widgets;

use CNIC\Widgets\Balance;
use WHMCS\Config\Setting;

/**
 * CentralNic Reseller Account Widget
 */
class CnicWidget extends \WHMCS\Module\AbstractWidget
{
    /** @var string */
    protected $title;

    /** @var int */
    protected $cacheExpiry = 120;

    /** @var int */
    protected $weight = 150;

    /** @var string */
    public $widgetid;

    /** @var int */
    public static $sessionttl = 3600; // 1h

    /** @var \WHMCS\View\Asset */
    protected $assetHelper;

    /** @var string */
    protected $repoLink;

    protected $module;

    protected static $headerOutputInitiated = false;

    /**
     * constructor
     */
    public function __construct($module, $title, $widgetid, $repoLink)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $this->title = $title;
        $this->widgetid = $widgetid;
        $this->repoLink = $repoLink;
        $this->module = $module;
        if (!self::$headerOutputInitiated) {
            add_hook("AdminAreaHeadOutput", 1, function ($vars) {
                $cssPath = cnic_getAssetPath("css");
                $jsPath = cnic_getAssetPath("js");
                if ($vars["pagetitle"] === "Dashboard") {
                    return <<<HTML
                        <script type="text/javascript" src="{$jsPath}/widget.js"></script>
                        <link rel="stylesheet" type="text/css" href="{$cssPath}/widget.css" />
                    HTML;
                }
            });

            // Include only once
            self::$headerOutputInitiated = true;
        }
    }

    /**
     * Overrides default widget id
     *
     * @return string
     */
    public function getId()
    {
        return $this->widgetid;
    }

    /**
     * Fetch data that will be provided to generateOutput method
     * @return array<string, mixed> data array
     */
    public function getData()
    {
        $id = $this->getId();
        $statusId = $id . "status";
        // status toggle
        $status = \App::getFromRequest("status");
        if ($status !== "") {
            if (in_array($status, [0, 1])) {
                Setting::setValue($statusId, $status);
            }
        } else {
            $status = Setting::getValue($statusId);
        }
        $status = (int)$status;

        // hidden widgets -> don't load data
        $isHidden = in_array($id, $this->adminUser->hiddenWidgets);
        if ($isHidden) {
            return [
                "status" => 0,
                "widgetid" => $id
            ];
        }

        // load data
        $data = [
            "status" => is_null($status) ? 1 : (int)$status,
            "widgetid" => $id
        ];

        if (
            !empty($_REQUEST["refresh"]) // refresh request
            || !isset($_SESSION[$id]) // Session not yet initialized
            || (time() > $_SESSION[$id]["expires"]) // data cache expired
        ) {
            $_SESSION[$id] = [
                "expires" => time() + self::$sessionttl,
                "ttl" =>  self::$sessionttl,
                "latestVersion" => $this->checkLatestVersion()
            ];
        }

        $balance = ($data['status'] == 1) ? new Balance($this->widgetid, $this->module) : null;

        return array_merge($data, [
            "balance" => $balance,
        ]);
    }

    /**
     * generate widget"s html output
     * @param mixed $data input data (from getData method)
     * @return string html code
     */
    public function generateOutput($data)
    {
        $widgetStatusIcon = ($data['status'] === 1) ? "on" : "off";
        $widgetStatus = $data["status"];
        $balance = $data["balance"];
        $widgetExpires = $_SESSION[$data["widgetid"]]["expires"] - time();
        $widgetTTL = $_SESSION[$data["widgetid"]]["ttl"];
        $latestVersion = $_SESSION[$data["widgetid"]]["latestVersion"];
        $templatevars = [
            "WEB_ROOT" => cnic_getAssetPath("root"),
            "BASE_PATH_CSS" => cnic_getAssetPath("css"),
            "BASE_PATH_JS" => cnic_getAssetPath("js"),
            "BASE_PATH_IMG" => cnic_getAssetPath("img"),
            "widgetExpires" => $widgetExpires,
            "widgetTTL" => $widgetTTL,
            "widgetId" => $this->getId(),
            "moduleName" => $this->module,
            "widgetStatus" => $widgetStatus,
            "widgetStatusIcon" => $widgetStatusIcon,
            "balanceHTML" => !empty($balance) ? $balance->toHTML() : null,
            "refreshRequest" => !empty($_REQUEST["refresh"]),
            "latestVersion" => $latestVersion,
            "currentVersion" => CNIC_VERSION,
            "widgetTitleWithCompany" => $this->title,
            "widgetDisableMessage" => "Widget is currently disabled. Use the first icon for enabling.",
            "repoLink" => $this->repoLink,
            "logo" => cnic_getAssetPath("logo", $this->module),
        ];

        $smarty = new \WHMCS\Smarty();
        foreach ($templatevars as $key => $value) {
            $smarty->assign($key, $value);
        }

        $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "widgets", "cnic"));
        return $smarty->fetch("index.tpl");
    }

    /**
     * Checks if the current version is outdated
     *
     * @return boolean
     */
    protected function checkLatestVersion()
    {
        $check = cnic_getVersionCheck(true);
        if (isset($check['version'])) {
            return $check['version'];
        }
        return false;
    }
}
