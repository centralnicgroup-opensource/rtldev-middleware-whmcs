<?php

require "init.php";

global $CONFIG;

$domain = $_REQUEST["domain"] ?? $_REQUEST["idn"] ?? $_REQUEST["pc"] ?? "";
$domain = strtolower($domain);
$reachedLimit = false;

//get the sld and tld
if (strpos($domain, ".") === false) {
    die("Domain is incorrect");
}

$tldidn = preg_replace("/^[^.]+/", "", $idn);

//Get the WHOIS
// load registrar module
$lookupProvider = $CONFIG["domainLookupRegistrar"];
$registrar = new \WHMCS\Module\Registrar();
$registrar->load($lookupProvider);
$registrarWhoisFn = $lookupProvider . "_whoislookup";

if (function_exists($registrarWhoisFn)) {
    //use API
    $response = call_user_func($lookupProvider . "_whoislookup", $registrar->getSettings(), $domain);
    if ($response["CODE"] == 200 && !preg_match("/you have exceeded this limit/i", urldecode($response["PROPERTY"]["WHOISDATA"][0]))) {
        $reachedLimit = true;
    }
}

//Fallback to WHMCS's lookup for any issue with API or whois query limit exceeded
if (!$reachedLimit) {
    //use WHOIS
    $check = localAPI("domainwhois", ["domain" => $domain]);
    $whois = urldecode($check["whois"]);
}
?>
<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <title><?php echo strtoupper($lookupProvider);?> - WHOIS Results</title>
</head>

<body style="background-color: #F9F9F9">
    <?php
    if (function_exists($registrarWhoisFn)) {
        $whoisData = $response["PROPERTY"]["WHOISDATA"] ?? $response["WHOIS"];
        echo "<fieldset><legend><pre><small>";
        for ($i = 0; $i < count($whoisData); $i++) {
            echo nl2br(htmlentities(urldecode($whoisData[$i])));
            echo "<br />";
        }
        echo "</small></pre></legend></fieldset>";
    } else {
        if (empty($whois)) {
            $whois = "No data returned.";
        } ?>
        <fieldset>
            <legend>
                <pre><small><?php echo $whois; ?></small></pre>
            </legend>
        </fieldset><?php
    } ?>
</body>

</html>