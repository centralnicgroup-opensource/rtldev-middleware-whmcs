<link href="resources/cnic/templates/cnichosting/css/client.css" rel="stylesheet">
<div class="row">
    <div class="col-md-7">
        <div class="panel panel-default panel-account">
            <div class="panel-heading">
                <h3 class="panel-title">Account Information</h3>
            </div>
            <div class="table-responsive">
                <table class="table-striped table-hover table">
                    <tbody>
                        <tr>
                            <td class="text-strong">Username</td>
                            <td> {$username}</td>
                        </tr>
                        <tr>
                            <td class="text-strong">Primary Domain</td>
                            <td> {$domain}</td>
                        </tr>
                        <tr>
                            <td class="text-strong">Package</td>
                            <td> {$product} <em>{$groupname}</em> </td>
                        </tr>
                        {if $firstpaymentamount neq $recurringamount}
                            <tr>
                                <td class="text-strong">{$LANG.firstpaymentamount}</td>
                                <td> {$firstpaymentamount}</td>
                            </tr>
                        {/if}
                        {if $billingcycle != $LANG.orderpaymenttermonetime && $billingcycle != $LANG.orderfree}
                            <tr>
                                <td class="text-strong">{$LANG.recurringamount}</td>
                                <td> {$recurringamount}</td>
                            </tr>
                        {/if}
                        <tr>
                            <td class="text-strong">{$LANG.orderbillingcycle}</td>
                            <td> {$billingcycle}</td>
                        </tr>
                        <tr>
                            <td class="text-strong">{$LANG.orderpaymentmethod}</td>
                            <td> {$paymentmethod}</td>
                        </tr>
                        <tr>
                            <td class="text-strong">{$LANG.clientareahostingregdate}</td>
                            <td> {$regdate}</td>
                        </tr>
                        <tr>
                            <td class="text-strong">{$LANG.clientareahostingnextduedate}</td>
                            <td> {$nextduedate}</td>
                        </tr>
                        <tr>
                            <td class="text-strong">Status</td>
                            <td> {if $systemStatus == 'Active'}<span class="label label-success">{$systemStatus}</span>{else} <span class="label label-danger">{$systemStatus}</span>{/if}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        {if $availableAddonProducts}
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">{$LANG.addonsExtras}</h3>
                </div>
                <div class="panel-body text-center">
                    <form method="post" action="cart.php?a=add" class="form-inline">
                        <input type="hidden" name="serviceid" value="{$serviceid}" />
                        <select name="aid" class="form-control input-sm">
                            {foreach $availableAddonProducts as $addonId => $addonName}
                                <option value="{$addonId}">{$addonName}</option>
                            {/foreach}
                        </select>
                        <button type="submit" class="btn btn-default btn-sm">
                            <i class="fas fa-shopping-cart"></i>
                            {$LANG.purchaseActivate}
                        </button>
                    </form>
                </div>
            </div>
        {/if}
        {if $systemStatus == 'Active'}
            <div class="panel panel-quickShortcuts">
                <div class="panel-heading">
                    <h3 class="panel-title">{$LANG.quickShortcuts}</h3>
                </div>
                <div class="panel-body text-center">
                    <div class="row cpanel-feature-row">
                        <div class="col-sm-3 col-xs-4" id="cPanelEmailAccounts">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Email_Accounts" target="_blank">
                                <img src="modules/servers/cpanel/img/email_accounts.png" height="36" />
                                {$LANG.cPanel.emailAccounts}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelForwarders">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Email_Forwarders" target="_blank">
                                <img src="modules/servers/cpanel/img/forwarders.png" height="36" />
                                {$LANG.cPanel.forwarders}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelAutoResponders">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Email_AutoResponders" target="_blank">
                                <img src="modules/servers/cpanel/img/autoresponders.png" height="36" />
                                {$LANG.cPanel.autoresponders}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelFileManager">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=FileManager_Home" target="_blank">
                                <img src="modules/servers/cpanel/img/file_manager.png" height="36" />
                                {$LANG.fileManager}
                            </a>
                        </div>
                    </div>
                    <div class="row cpanel-feature-row">
                        <div class="col-sm-3 col-xs-4" id="cPanelBackup">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Backups_Home" target="_blank">
                                <img src="modules/servers/cpanel/img/backup.png" height="36" />
                                {$LANG.cPanel.backup}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelSubdomains">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Domains_SubDomains" target="_blank">
                                <img src="modules/servers/cpanel/img/subdomains.png" height="36" />
                                {$LANG.usagebilling.metric.subDomains}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelAddonDomains">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Domains_AddonDomains" target="_blank">
                                <img src="modules/servers/cpanel/img/addon_domains.png" height="36" />
                                {$LANG.usagebilling.metric.addonDomains}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelCronJobs">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Cron_Home" target="_blank">
                                <img src="modules/servers/cpanel/img/cron_jobs.png" height="36" />
                                {$LANG.cPanel.cronJobs}
                            </a>
                        </div>
                    </div>
                    <div class="row cpanel-feature-row">
                        <div class="col-sm-3 col-xs-4" id="cPanelMySQLDatabases">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Database_MySQL" target="_blank">
                                <img src="modules/servers/cpanel/img/mysql_databases.png" height="36" />
                                {$LANG.mysqlDatabases}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelPhpMyAdmin">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Database_phpMyAdmin" target="_blank">
                                <img src="modules/servers/cpanel/img/php_my_admin.png" height="36" />
                                {$LANG.cPanel.phpMyAdmin}
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-4" id="cPanelAwstats">
                            <a href="clientarea.php?action=productdetails&amp;id={$serviceid}&amp;dosinglesignon=1&amp;app=Stats_AWStats" target="_blank">
                                <img src="modules/servers/cpanel/img/awstats.png" height="36" />
                                {$LANG.cPanel.awstats}
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        {else}
            <div class="alert alert-warning text-center" role="alert" id="cPanelSuspendReasonPanel">
                {if $suspendreason}
                    <strong>{$suspendreason}</strong><br />
                {/if}
                {$LANG.cPanel.packageNotActive} {$status}.<br />
                {if $systemStatus eq "Pending"}
                    {$LANG.cPanel.statusPendingNotice}
                {elseif $systemStatus eq "Suspended"}
                    {$LANG.cPanel.statusSuspendedNotice}
                {/if}
            </div>
        {/if}
    </div>
    <div class="col-sm-5">
        <div class="panel panel-stats">
            <div class="panel-heading">
                <h3 class="panel-title">{$LANG.usageStats}</h3>
            </div>
            <div class="panel-body text-center cpanel-usage-stats">
                <div class="row">
                    <div class="col-sm-5 col-sm-offset-1 col-xs-4" id="diskUsage">
                        <strong>{$LANG.diskUsage}</strong>
                        <br /><br />
                        <input type="text" value="{$diskpercent|substr:0:-1}" class="usage-dial" data-fgColor="#444" data-angleOffset="-125" data-angleArc="250" data-min="0" data-max="{if substr($diskpercent, 0, -1) > 100}{$diskpercent|substr:0:-1}{else}100{/if}" data-readOnly="true" data-width="100" data-height="80" />
                        <br /><br />
                        {$diskusage} M / {$disklimit} M
                    </div>
                    <div class="col-sm-5 col-xs-4" id="bandwidthUsage">
                        <strong>{$LANG.bandwidthUsage}</strong>
                        <br /><br />
                        <input type="text" value="{$bwpercent|substr:0:-1}" class="usage-dial" data-fgColor="#d9534f" data-angleOffset="-125" data-angleArc="250" data-min="0" data-max="{if substr($bwpercent, 0, -1) > 100}{$bwpercent|substr:0:-1}{else}100{/if}" data-readOnly="true" data-width="100" data-height="80" />
                        <br /><br />
                        {$bwusage} M / {$bwlimit} M
                    </div>
                </div>

                {if $bwpercent|substr:0:-1 > 75}
                    <div class="text-danger limit-near">
                        {if $bwpercent|substr:0:-1 > 100}
                            {$LANG.usageStatsBwOverLimit}
                        {else}
                            {$LANG.usageStatsBwLimitNear}
                        {/if}
                        {if $packagesupgrade}
                            <a href="upgrade.php?type=package&id={$serviceid}" class="btn btn-xs btn-danger">
                                <i class="fas fa-arrow-circle-up"></i>
                                {$LANG.usageUpgradeNow}
                            </a>
                        {/if}
                    </div>
                {elseif $diskpercent|substr:0:-1 > 75}
                    <div class="text-danger limit-near">
                        {if $diskpercent|substr:0:-1 > 100}
                            {$LANG.usageStatsDiskOverLimit}
                        {else}
                            {$LANG.usageStatsDiskLimitNear}
                        {/if}
                        {if $packagesupgrade}
                            <a href="upgrade.php?type=package&id={$serviceid}" class="btn btn-xs btn-danger">
                                <i class="fas fa-arrow-circle-up"></i>
                                {$LANG.usageUpgradeNow}
                            </a>
                        {/if}
                    </div>
                {else}
                    <div class="text-info limit-near">
                        {$LANG.usageLastUpdated} {$lastupdate}
                    </div>
                {/if}

                <script src="{$BASE_PATH_JS}/jquery.knob.js"></script>
                <script type="text/javascript">
                    jQuery(function () {
                        jQuery(".usage-dial").knob({
                            'format': function (value) {
                                return value + '%';
                            }
                        });
                    });
                </script>
            </div>
            {if $remote.STATUS.0 == 'ACTIVE'}
                <table class="table small">
                    <tbody>
                        <tr>
                            <td class="text-strong"> Server Hostname</td>
                            <td> {$remote.HOSTNAME.0}</td>
                        </tr>
                        <tr>
                            <td class="text-strong"> Server IP</td>
                            <td> {$remote.IP.0}</td>
                        </tr>
                        <tr>
                            <td class="text-strong"> Server Location</td>
                            <td> {$remote.LOCATION.0} {$remote.REGION.0}</td>
                        </tr>
                        <tr>
                            <td class="text-strong"> CALDAV Login URL</td>
                            <td> <a href="{$remote.CALDAVLOGINURL.0}" target="_blank">{$remote.CALDAVLOGINURL.0}</a></td>
                        </tr>
                        <tr>
                            <td class="text-strong"> cPanel Login URL</td>
                            <td> <a href="{$remote.CPANELLOGINURL.0}" target="_blank">{$remote.CPANELLOGINURL.0}</a></td>
                        </tr>
                        <tr>
                            <td class="text-strong"> WEBFTP Login URL</td>
                            <td> <a href="{$remote.WEBFTPLOGINURL.0}" target="_blank">{$remote.WEBFTPLOGINURL.0}</a></td>
                        </tr>
                        <tr>
                            <td class="text-strong"> WEBMAIL Login URL</td>
                            <td> <a href="{$remote.WEBMAILLOGINURL.0}" target="_blank">{$remote.WEBMAILLOGINURL.0}</a></td>
                        </tr>
                    </tbody>
                </table>
            {/if}
        </div>
    </div>
</div>

{foreach $hookOutput as $output}
    <div>
        {$output}
    </div>
{/foreach}



{if $customfields}
    <div class="panel panel-default" id="cPanelAdditionalInfoPanel">
        <div class="panel-heading">
            <h3 class="panel-title">{$LANG.additionalInfo}</h3>
        </div>
        <div class="panel-body">
            {foreach from=$customfields item=field}
                <div class="row">
                    <div class="col-md-5 col-xs-4 text-right">
                        <strong>{$field.name}</strong>
                    </div>
                    <div class="col-md-7 col-xs-4 text-left">
                        {if empty($field.value)}
                            {$LANG.blankCustomField}
                        {else}
                            {$field.value}
                        {/if}
                    </div>
                </div>
            {/foreach}
        </div>
    </div>
{/if}
