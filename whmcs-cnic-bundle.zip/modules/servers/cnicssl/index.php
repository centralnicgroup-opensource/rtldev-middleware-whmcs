<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPup/SH6TUbhgqWD8XBu6iDQLzkTrw9Q/NR+uvxnWsnt/prXQBmgbT3v6qumelqZ6W4Prz9Bt
NNhA6T4CiUOuoMVRXN8h3nDaTdQJSKJWneqIfF22mcoB0NtFnF/2N1gDPIMDhRDc/RofiF58/q/s
BIJoCaAJbx/DJdRaopt+lyD/wbiO02OzY61G77xSN64rBktxitDeuFartY3CRFS0gI2h38ZIIF3v
VmjkFQSEuMAcl+WChPoEzl995rQEx7xZQ82bZD9i0s3r8Bdvcc7vv6pVtnfojhEd9Nvc8iZVTooN
6ATC4+y1qiqhgOtFPkxaDEwqXE6dtZsC3MMv0MvT04g54CjJw/fvsi24JMBFnZgTozuNXMzeIsHV
H1aXg4GL9jepaNX6OZtH7yU9hgv1cSBTR40hwEtzPiI6Ug07T8M/SJ6ignqJkXjQ0dsMWyZf7AOH
L5RNOEvaizMp3sJ1xK60t+VZ4Z7v+EXpTIIjV/hI3H95M3/FQeByZS3TLcaJZUEb4xVH9sfmwLx4
/ycI+pZ010cOPnrEcn+A14WqJfYy31RKqD7Ia1D7lIsmckBKQtjgzkQ5Q3u4eeRkLPxoS2nPX0Sa
tfkZ0QqBYhLq9BVp9ndZ6kjl4tY5qWohGtTdfPXmMGblDylFerVD0L6UVX35Klu7OH7/9vKW+vh9
yB5LIx8EyG45r18oPSmk22V/Ao0YkNolOcGpQVTjFG5h8QgzgNiG+3NTgc7R/1P2ZsXATlhpy4ME
+TM9zUqsJj/EAlmxBLa+pI3Qx2kck3NYSkqgr7SKvTvsDpaufaNOMZU9yQAyGUsRKeCu8bmC5Pj3
cUaAxHPFSmpg6rgYvAFBUjSCvn3o0hu3ZbdRYhgrWjChLm==