<?php //ICB0 81:0                                                             ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+rFbuLbgckgSFW2fed/z6VJHAD+HpIzMULgVbFf2zJpg2653rfjB6o822DlWhf8SkvwqWbZ
yZMRGRJzrKGfOLFG8tV/3BXhGuHHeh+N0xgfXwrB5QqJkkyaU5yjmG1/xvlfLvmNJZKvYiwbU6g6
1Du5dtLJUBG+5oblxKXw626xYjzNe9nD1d1TfjBeL5FhWr6KgreGgDzIzQGNlE1wf98u03CvvvKZ
sxhSUqR2h9rM0KYxngb+MJILdX64dFca0zAQHUA9iqD51yGjquZVhbtm2mgqPnqiEtPYRb0KVeb0
/mhdVl/w34zLtFKkrN4Oc4MbZdd3frWrOr4dUPiIRHtjKPxNkrhZ5TsoqijejiLyQZZbFvissX4H
t4HNtSsd6orVctmZQnvRCU6BgwPDL6vhPn1wrLg+fMB9lmwuKdq2mDAlzTSFbulvLT69k39hQawg
SzCD+0c+nVNPWGyT2VMTkOy70paavrjWrcb02GEFHtbti/6nz3GK7Yu0spHM3yC1IxM6gAIRWv9O
ansZyAKOeS1j1K/+y+3YOVixgxlaslq/WVGhiUn18iqzWyTiLyaYS+r5od1oISUnJWKsBGzAGLou
Lg4e2pY4sxF0rTtWybfXzaO0Hty5Ai8IhGiPIUgi/PHpL5g6GHXGXk/kE4c120f9c6E1nlrXdsnF
zZUHvdvV1gpyllXY/XHZrStIiqiRU438j/ZRKAGsYaS3vfQpKQDrkCAjiXSI3/TbhJjghB+SpUOj
dfZ9ovDfN4lveH4blxUXWZ9QuLiiBimFkxzi9IRS2q4FfggI1mpyNvtdz0VSQFy2a7OnclcOMhWp
jAa6vrlZ75hLMwrYiaL84/qpyQ1arz1/BxgqSDCld0==