<?php //ICB0 72:0 81:c09 74:f82                                               ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqGIuHiT+TbSsALqEB/cFubpfWwRrr22kRQu3tLym7S3SPL/mH4axZvOc5HMf9I0b+CqCd3v
PQaOY1CqnoCZgSxbP989+VtpQfXjsjmXJMfYCnYm8uSmpWjwM3ipqEr/9/z+pu02VGDhH6rUuadc
K3XUjOYLbI+WUdspQQwPyoiO5LwR9yWZLXhEL5UkJG/7WwS8oXUl7M/HxUk9wJZtQJXPTUCIlkR3
M0V61AxQ4o9iPcI8HFqM56xCicOFrG9cLpZv9CwIl08AcR/Npsy9LnR7I7rZ7QQEbJXb8dz5l6EI
JiTm/ty5vgxZ/KX4/j4TxlRgCff/Y9bbiE7WNaT7heNgCswbefW2ptuc2rFKv217kAaWptbkCeDg
raBXyTGqCwqVw8uwUfj5zyO72HSfXAFVG1BdAi3GLGcCpaU4ahCXhauF/PJphO9Eq/woe45MQSfp
bsdW3HP+1aMAKbxtycx9ML5RlRNTMkozMEnZxOimjMC+w3HDqHGEIbTaNdTUt8ty+cczraWLjHbl
fzSusPAlCtFRUKw2O67DNRpgOnSO9upUk8jKE2ZPwo4fO212nIEJGEtdrB7vipRqCPZNeeoXPWhg
A1TXAce7+1kkWNWWAsIWRWLcTzUrxetCWW07yz7ty0rF/lWRCQ5lJDlKXokx6UjgPlQC82d2STOw
Kd0Z8+z4D0tyWK0UOl2e8jHbv3OKRtTp6rgxI3kLcjoFHrSbHJvqcdprTLxRWvNCn5UHpJKBQOqr
N51MgtUIe4c8ua/7A1Ro0VNUHpBSGk8Cm3brC1n4+9Cw7l5bX3QccbLiDS060LVh0G6fHVyMt0R/
942qSRCYoXwd5hSKtyTXwHN5/jagHpRqUx8QqVYi=
HR+cPpjk83Q9pPWvLD2r5MqLvEr88+nbJqk05AkuOzJpDgb/N73uchy8z509v7NE0eLVjOA1XbN/
IjPNLpl1GbB4YWlVog3pwCdM7SJ+6vUdgh6G5aJRI11khsQwJEcaQYm24GYA3XsjtowqbtcrQIoT
EGouz74k3kx3iIm+PsieaWeTy6rYA0sQYtR7vS3y2xk9MbyP4jkZ29DN6+GPtJRHFZ+julnBkobg
fTWWWkCCaciCuJgqQxRhncrcZpOztPUvqxGiqs71KOWXqBMZdTepAISo0czcncGs9n8Bv1a+D0Fr
A4SGSgjfo13L3fjJHwF04bgaO0bQ1rac6aQKLCV7o4FruxqeFMnhqkvBv87qpfrj1RqiCkzV/Rxe
48r7Tv+Ij8DYtCCwVPTubosLyBdRkmxNBgHorY1e1P2aq/79R/Zlhs47Tn3qAcp+ChmqErIxw2Rf
FLfV6f3r1emIF/5BmgT4TgaIW9QgtyjamK+zbDnqWiFswQ82SvofhKUgWQ2mYGu4i0upFRNBTSpu
kTUE9Q2xMvT3N1T/n+kdJBByE9uECSapROWtCrXnHlev3qDKkiKj/LkGuXee9LWkdW49kUWr7uJk
rZK+UKbv2dT7uV85jViHer7Rlon2vulYVMnAsxVCWxyKAXcVVF5beJg0SaPHrrXptICNg1dJS5g/
zVa1pI6gk2UsT+SYeou+EWd9m+SFo5/1R6O5WX/J/oPod6CZ95zFGrjSezm2bRuMohXaaIlqw3aj
ZxukruczV5T6XLTjCpRdk2drOA6zCvGoVrKIBNN24TNe0tXznWnH0buh4X+UCs0ZbUiFrG821VjV
ra1JLJNiBAy2xnZsb5s3+EkRgY3Rr0tEezFC9tK==
HR+cPsx9rP57Aowc7dT0ije5UjE8kzNK3qizOz6lWi+WmdyzDx/7eUhUEjwzSlbHowMg7z7wPWdB
lxzgaBmTVc4V63u0Im5l4tK9VhSsdOffiQShgr7nPWtfTvT/Ch6X99x/mor1yyZMx0nfQbxTFlq7
s1gjK7zNi4uEcWkhjX+rd9ZilEZU4cOn9QvTXTky92AB7K8WoBq11uKuJWpfANN5+q/fjOvQs3l1
xuoDJxFYVwSNn5rYKhiCVMkrak3w5169xmxmYCj+Tt5JHPq8bqod4zaPkhI7QHidqilShV8CpfiJ
68c6IlzqujiSAY2Z3T+u5FXfDl0FoNCAg9EmX8jbJHW3IPmkhjNb5znLYxvPSanUT6qGsA15kX/J
I17VNcKLwrTX+mty4ojJX65+BKI40z7wUZ6WvxBwqxBSJQLv0RmWyHGNOWAcAAWaZwB+Dvwf23xH
KYELAHaPqvB5q4tuZTqY8RleOO81JJrp/3jXXMjvzYSD7nd/ACzdbtmEYuRsG0EJgiHaWZ30YRq2
y8+WDOVmD4PYqrOUBJWqlM58yaBceJsSXuUPGDlPm59niYtAU6FzkiqiME4aGRbz7bRDvbqmofN4
vwcR1HCSAS3aosCeZBtkrqDXU3M2dmwSINoB8/SYZT8tdi+yxfTtn3ZUUSysnmjPjDnjrfOJjGMO
swTOAWI6wKPONO6ts+YcW0I8zRN6I49AP5JP9DYS6rJaqSTUrkGekq+MGcLRv+hy3Ue58WRmRGKP
kI/W1JsEjqWYPgKaSIbyO2E5T+xVEIgtIMZ4mhiqHIeJq7V/dqyHHfzgBrTjncKC6UFktdACiJLi
hMCupRHj/mg9Hc41PyeQ0KQSuPYufEF9Nam=