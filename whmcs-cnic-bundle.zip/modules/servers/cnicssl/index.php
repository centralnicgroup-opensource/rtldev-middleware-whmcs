<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyO2BLkBw9MSKhMuUC3mGJ1YSdO/AUoUceYuPml/fFUN0zxuA2A08y2v7KIYHaCsKuQXSmnC
WtoWEJ6jmN+1X9QienGbnjFIVDWhIW/4qrfl+GV58p29WqrGxj82BlhzRr/zu/lE2kCmPfRnwb7l
5+PqM4nU8KpJhtDlMwOT/BbhhhRNHCknpgyNsUlg0sSXrcKvZcuRrVMTucrOUxryhMMBEExxYux3
8KamGHC8LvRO8Qpbr7cHYdrtejrgXrvQDVko43QPeGRaHq3h8KcuIEYSSgjhK1Fpgul+32mQr2Y1
FYOkjQqEWeX9eRzPS6Lqdqj5gHPV/tTs0qG8sT9M5tKzyXFl5lP8pzkJc469RWD/WKS6qNtZ9alZ
jtPYntZ2/B7amw7Qp8rNhvocbKEEM7ZqcMOLVfYgVmxoBjw62/ogsRuM1UVmO3Y8XF/ZqygiVbQr
8ekiWSxWlPnJqbWGGYJEiw0s/CfYhVdjiao+XyU9XSNcFURTV5ha6y4z1nETPXz9mIau5lgPD3BX
La+dYOPZs2UYK6dxHF6EJYn9yzB4P1t90btmlTuWGb41ie5wwjDvScOZ51IP3ionvLLvzZctGjcV
/tQilLNI7fYVVw7SQVZd7ISll9YCUQzSNpE5grMv4OOTwMQTPzGV7at9tqcJJc4BzUeGEgr4HYXJ
QE1B+xoSVrnI0NeLmOONZn3iaiz96Q8+I4GZ+NSJbMNSbknFHq0baMrrFnIRGi/ABu7pHt91PHwW
NJcEnha0MV6rHfVb6Aud5QMrEQMqG/IDi3Jeb+MqOr0HxDR0Cg1gBuYxSPNWp1qBC0g2+BhwEoJ5
JJCsBWnrFdaRxb/TWrXmydITi4M28A3FqOiN