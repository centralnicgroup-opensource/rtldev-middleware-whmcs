<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPthg/VFlCSR4zbreq2Tqj9l4zVdglHUcZ9QuMOKKnw6WfwHvo+fCRk/RyQ9pRHCjPsWEwPNf
bfP+HEM5cFZ7JPI299K3cdjr3Pn3IvG8UfBTzyeNxaCX0+GuaitynIhYbwySLoDq9t5gRXeKPBcr
Bg//XOGh2+ElOWSw81etK1lsWtsXTydnH2kEnz0IalTLn7WYcfOlj4g8EsrEuzvhv/2bCtt+FJii
BkuQ9f3r1EXbKiTjnDzKA7D6w7LNiqNvh2w9NazPctGn2vxb75HMiM0PiMDhLivUpx9b3uRJ6RQ6
t+OYWUGiLJcWeRRI7yy8bvC/X3/Y0U1c++SUpWiNmgLhVB013CUGHUdFv73sQ0PdnMEjsuQYuRaN
vTPyK9KQU62+eqxk1mD8tGg71M0FPAdhzZF1mCXJ3CJrgoyf6d0NwoRrUjkLRqDnWLMHXjdB4WCs
8gL1LF9v80do7LL6ZuT4Av1OKe99KLMGhD5ExS/Ldh/fkNXTq+GRvwl+CKYCCeF5hKEoJIZwTZdG
+Ny4/rqFaBbpDlW9uR9rWtYFS0gbfmlZr4RM8ZHXGlF2e0eYG0bApHQElowvuKfZLvH8aT9H9m5w
TnTNG2l2Xt+C6O4iAaZHJhDis0WvCM5EFbrC2VUlKskqfVRWENMFN0TrX0MH6d2gZ33BNbXjm1hq
6VvYfQVf9NZYFIBto53PkV/IWWxk72HhVmKdQyu5LH+u3Yy0tts9lwtkvvy1AagOaR52B0LRmp1w
8iSPeWbAY16Qd13OU6gYx7tuC8hXDx78XmlpTel6ISW8RbH1tbCcPB1Lx6lc6kLBnzthAdrA/0Wf
RSw/ufVwlG4GZJNLUpeFrZrf89DIJdHgkh2y1Ou6gFlBt7y=