<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPptjjhJPD0kxf5eZbyoijos9JmsQltQhIQ+uRLpqlSxIu4bF4M10nUfpYUeF/SLccVqoWz2D
v4cqgFU92l6j5HoemAly22HcBjDju6VeqBrYZSVpgWRywWLvzs0SgwqPNh/eMP8BimY20rFPPGyQ
gVnk8dlSGRZpoObx2AQIwTubvPV4Os0Mi5Ngtx2Zdxfux9miBWi0pH7W7blPiIIW6FMMX4Y7Kc+U
xOcLpPVZPIsTcfafOpSekJ32l+M66HC9bIpEPr7xiogPqoBwarRZit/zahLloA6+SYe/l4AfMgnX
BQTk/mz1IykYx66+aH1X+XEjuJMqIXgt5+d2dAJEJ7mhEg+AVfnZjWlWvjofY/EiNGmMYa/6aZhl
nQ47XybJn9ZUwcRexgd234ZcdBgiFumFaJqgrga5HRh5qWSuquOukz5/uM+KKYcbg/OCEHcQIVvh
YEULpzXv8CLE8/e5FR1B9y5/hLCaZtw6K9m57CgtdMO3N0CfHURPaopoyuBbxV+TMGCCHQBjDhM8
Vcu7osRdiR6d1F+ZOmr+VH0Q3fR0KVJ/NFwMjIGRBq9A4PsJxjNAqBA1pWHPYebl/IShXpy03UE7
y+hcrB/qte6uprGO94yqHA7+EUxkatl6PtDmlB4mk7wT9FrCouSk56yqVNVav4TXNm+pD3xlhYuT
aXUoruFM+DQkqdJOMyE7KCd67Mqm2DoYk/n7sZlXEqmTWtzOh0PJ/EgzFjHO+IqP4qy2VyuOAh7r
Y9vpqAfsHHQBCkdg8v8hAXtavXrdnWRLFJCYUfD6R7irSXVmYLEky6WTedc6wzZ479/G8bBktQB8
UJ+lEKdcM+c+o6u/r2hfaqXQ2h6+rCRY