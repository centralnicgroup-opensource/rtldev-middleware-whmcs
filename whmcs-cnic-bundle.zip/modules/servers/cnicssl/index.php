<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyTEPQE5b5sLKFdmWE6DJio9/DgFeFkIa/wowdshZrm5jJkZBrJURPY30T8cVwRuj183VodP
5kmscivzGf1v1l2SX3HYXGhhrn8eXT3ItyvG63Sxub64qHEqhEc4mul7p5AREIeXLwj4smE2ajhP
DYpbzi1pD1z9A/ZGDoqccjDAQja7FshfO/V4nAqjsaP6zdncAHEYhpdKz1zolfeaSSu02yfL4FdZ
hWjh3AdYiOKi1wMAiviQxduSntcnD6rwX+5z45jjQx9jvyVm+uq5jTiNvpOpRGic7fWHzwpmQvqP
RMedDVziMV3trQu9Srs9KebGfXrr4gAhSLjYt0+1VZN/XzkUCHI6dECexhBDKuQ4qm1STU24N4LL
InOFpnfcwph0I/9yeZ7bC378V/N7dHSGJYlraGWs8VMnqg8aQzut6+uHg+o6SUecEmxkCNJA0m3R
rXV/v2ReHJWd316KcSnAPxyhpMOFOJC3NdnTgUKGUhS5tUu+R1uruO83rEnvEOFlxiXjhhI3jq1E
PZBojhwbb+BsveSYiYfXe7roHpJU78XH+4bUV7O7ORakT9LAYmLk03rSIrdLXUwtSJA6fQyh5c/m
IGbOdlgbBRwtHIDo3Op6OGjAMlaqdg04Ly/zNcp8nIGsdlOWU970nCt+yqr7Y9bGmYghYHBpXpSk
E1VjHDgBFoFx3TLw9QN1o/+zAMHIeRQ8h5ANHm3faoD/lgYX2+STYy6cKhUHsCSDKIyHipUCKNr/
SSYpBGxQKyaUWKuciAEfmeUL3xsew3ttknWJrLz7NIxjB0R4uyQ8ky0TqfhSuBuKiTh/JEIRb/t+
jhhuRvBdiqfoybSw1f98FiqPOpyZgQ/ERR0=