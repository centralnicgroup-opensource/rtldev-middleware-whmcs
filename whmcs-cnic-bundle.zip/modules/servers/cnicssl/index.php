<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtniVl0IjqBuwzlhqrOv3yhXQ9+693KC7hgug0TnhI5uM+r+igfP97uKVyyS/vWaU52ZEbvR
PD/6P8gmz+FFJUZeYkt2za+6q2+pMwPxLGgoeZlRg1OcpnK2XRaO6lzRpYZAeVFQd7E52lJQnVIY
7VqpRZKZy3U2FQ9qDq+GpWhgw/63IKFovZ7lwkcPrRoPBmpQJtNdc95KD3VsGQpv+t2YVmikhwQ8
ut+jy6DynBPUsbg9/SJo8n4ZxGqSeKvGodr2HCJbVPVNPnWIKKGpvUxVHivl7/Gp+jDbvh+/vY6T
I+P3/xYE1jFZ45RFXmIrPhbC2xOQ7RH4bgxzK43rBVNyPbl5KrOGTSDsf6PHoVlnR2HMOhtdNCl0
oqn5SRnmBF8al5kxURzxPR1xJGpSrQei+TJ9cQO0DJWYK9vilYLug1mfYlsMUptohkI95UuFJhEx
wyOkRP7P6Hdo1kYZHotBjEl1fTq/0rjK/Y6O8Li6+vIRP0hNtpQnSyq68/9YrQ9ouhJ7seJUqbb5
SpbNBwciUpWl2up/Q/SfFHMRA1/PXxjnjdakkub5Oh89+EFuzpKAw/GGUWe2XHZ8CBeZfeQVjdz5
Af5M3ouP7e5iBsmcWq4lAAkzSY1NfuLPqgqsgUs4bM+VZH3Qj6vHzfulB/z0K/P4iRQP/LvSAlWb
D9L+3mqfJn7uM/XCQFUuScNlTgZCbvdSmNh7sWwT4zoEnTBcPvCxv54JRRZu7ZPLhp1IyUGsyXuS
UdM+IdXnqvtJRH7ZQjurWwpWJv8aNRFyYpxPbjrlOhz9GuHb3L+94Z08j44Lm3hgRWwsT4fYevq2
xeEzRAYqEsG60ihZTocUqOf4oSHPiv7GVc8=