<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuFpWGD8Ndeq5KGK87+2F/rqQF30Teako/CKX2nvYV9jCQoB4pzhBJdqalLGwnpxLRFhQFMN
B4HHjjgbf6nK2r7QnhAUFX7b0KoNh4BltSi9o6xahAUkH/0ZHLAEIGRokRdRb+oCRaVtVTer254n
dc/aYUmOl/UNY1d2x4jAcbAaathnRBoZJT4Ba/1Mx7RUIl6Kc4OiyCChhohGociM8IxCMltpLaWZ
0d8+7gN1BpV4432gGAgtntrAm//oTY8qidnN5UYgqkylOZxrd786ZNSFIvTZUcl4esrTkRfN4P4+
TB4rHmfMGgpv+J8ijiy5gjOzv6XF6uMOUL2x6IKSdRWf4SSUYMM6FvHMHZhoynfbbfRG9e9Uz23X
xyDplAKZqWx+zR3V2Ekx15RKKMVNy6YZDC6cpTMeFStXO/+AQWAD+0djlwpVy9jjDiYHghBulxlX
+oV0XTiC32pUGhN9ro+oavJAVqBc9z0zCcNKI5ty84GjUhqKbf5uT4XyDZOmIsoqnqs2Ahu1JyIl
JVEE+JrgBB6lXe+y5y+JKuTLBm0gJy11rT6zZN2Tyyg4qyDYMpMJu9jXenIjMlhJHd/2Q8YOgWyR
eiEYHjP7qLxaWk816X9cnLzexmZyKrxPNUpRZaCJEmKdUunZ5sg1Et9EZBpvvWbKAN/7cH63LCkF
KpEM/CeBZN8msnbR6AigtgWFoIveIStgyrHkLnYcPrDnC37pxV6L9zfIgq1Q1HGMKQLqLxPyUkW1
WAa+EHbOtRHESBArnuRAhKpYYBREklDVM6/VTmP/xYiIgBb+6jxh/awRus0hg+9rQCQmHLeqXA7w
uhoGOlR55BN1feeV9y8zAtPiLSThaneFjPgw0wa9SxOSs84F