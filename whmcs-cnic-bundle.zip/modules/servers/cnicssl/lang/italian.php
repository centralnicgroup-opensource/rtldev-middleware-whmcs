<?php

// CNIC SSL Language File - English

$_LANG = [
    'adminContact' => 'Contatto amministrativo',
    'billingContact' => 'Contatto di fatturazione',
    'created' => 'Creato',
    'expiration' => 'Scadenza',
    'orderId' => 'ID ordine',
    'owner' => 'Detentore',
    'sslcacrt' => 'CA / Certificato intermedio',
    'rootcrt' => 'Certificato Root',
    'sslcrt' => 'Certificato',
    'sslprocessingstatus' => 'Stato di elaborazione',
    'sslresendcertapproveremail' => 'Reinvia email di approvazione',
    'sslresendsuccess' => 'Email di approvazione reinviata con successo',
    'techContact' => 'Contatto tecnico',
    'updated' => 'Aggiornato',
    'vendorId' => 'ID ordine fornitore',
    'webServerType' => 'Tipo Web Server',
    'resend' => 'Reinvia configurazione',
    'triggerValidation' => 'Convalida certificato',
    'changeValidation' => 'Modifica convalida',
    'reissue' => 'Richiedi nuovo certificato',
    'revoke' => 'Revoca certificato',
];
