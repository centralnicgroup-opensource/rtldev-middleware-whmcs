<?php

// CNIC SSL Language File - English

$_LANG = [
    'adminContact' => 'Contatto amministrativo',
    'billingContact' => 'Contatto di fatturazione',
    'created' => 'Creato',
    'expiration' => 'Scadenza',
    'orderId' => 'ID ordine',
    'owner' => 'Detentore',
    'sslcacrt' => 'CA / Certificato intermedio',
    'rootcrt' => 'Certificato Root',
    'sslcrt' => 'Certificato',
    'sslprocessingstatus' => 'Stato di elaborazione',
    'sslresendcertapproveremail' => 'Reinvia email di approvazione',
    'sslresendsuccess' => 'Email di approvazione reinviata con successo',
    'techContact' => 'Contatto tecnico',
    'updated' => 'Aggiornato',
    'vendorId' => 'ID ordine fornitore',
    'webServerType' => 'Tipo Web Server',
    'resend' => 'Reinvia configurazione',
    'triggerValidation' => 'Convalida certificato',
    'changeValidation' => 'Modifica convalida',
    'reissue' => 'Richiedi nuovo certificato',
    'reissueHint' => 'Invia un CSR per richiedere la riemissione del certificato. La riemissione crea un nuovo certificato che deve essere nuovamente convalidato: dopo l\'invio, completa la convalida del dominio indicata nella panoramica del certificato.',
    'reissueSuccess' => 'La richiesta di riemissione è stata inviata. Completa la convalida del dominio indicata qui sotto per ottenere il nuovo certificato.',
    'reissueFailed' => 'La riemissione non è riuscita:',
    'revoke' => 'Revoca certificato',
];
