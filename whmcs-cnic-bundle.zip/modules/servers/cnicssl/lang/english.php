<?php

// CNIC SSL Language File - English

$_LANG = [
    'adminContact' => 'Admin Contact',
    'billingContact' => 'Billing Contact',
    'created' => 'Created',
    'expiration' => 'Expiration',
    'orderId' => 'Order ID',
    'owner' => 'Owner',
    'sslcacrt' => 'CA / Intermediate Certificate',
    'rootcrt' => 'Root Certificate',
    'sslcrt' => 'Certificate',
    'sslprocessingstatus' => 'Processing Status',
    'sslresendcertapproveremail' => 'Resend Approver Email',
    'sslresendsuccess' => 'Successfully resent the approver email',
    'techContact' => 'Tech Contact',
    'updated' => 'Updated',
    'vendorId' => 'Vendor Order ID',
    'webServerType' => 'Web Server Type',
    'resend' => 'Resend Configuration Email',
    'triggerValidation' => 'Trigger Validation Check',
    'changeValidation' => 'Change Validation Method',
    'reissue' => 'Reissue certificate',
    'revoke' => 'Revoke certificate'
];
