<?php

// CNIC SSL Language File - English

$_LANG = [
    'adminContact' => 'Admin Contact',
    'billingContact' => 'Billing Contact',
    'created' => 'Created',
    'expiration' => 'Expiration',
    'orderId' => 'Order ID',
    'owner' => 'Owner',
    'sslcacrt' => 'CA / Intermediate Certificate',
    'rootcrt' => 'Root Certificate',
    'sslcrt' => 'Certificate',
    'sslprocessingstatus' => 'Processing Status',
    'sslresendcertapproveremail' => 'Resend Approver Email',
    'sslresendsuccess' => 'Successfully resent the approver email',
    'techContact' => 'Tech Contact',
    'updated' => 'Updated',
    'vendorId' => 'Vendor Order ID',
    'webServerType' => 'Web Server Type',
    'resend' => 'Resend Configuration Email',
    'triggerValidation' => 'Trigger Validation Check',
    'changeValidation' => 'Change Validation Method',
    'reissue' => 'Reissue certificate',
    'reissueHint' => 'Submit a CSR to reissue your certificate. Reissuing creates a new certificate which has to be validated again: once submitted, complete the domain validation shown on the certificate overview.',
    'reissueSuccess' => 'The reissue has been submitted. Please complete the domain validation shown below to get the new certificate issued.',
    'reissueFailed' => 'The reissue failed:',
    'revoke' => 'Revoke certificate'
];
