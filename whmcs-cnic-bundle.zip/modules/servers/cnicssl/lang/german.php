<?php

// CNIC SSL Language File - German

$_LANG = [
    'adminContact' => 'Administrativer Kontakt',
    'billingContact' => 'Abrechnungs-Kontakt',
    'created' => 'Erstellt',
    'expiration' => 'Verfallstag',
    'orderId' => 'Bestellungs-ID',
    'owner' => 'Inhaber',
    'sslcacrt' => 'CA / Zwischenzertifikat',
    'rootcrt' => 'Root Zertifikat',
    'sslcrt' => 'Zertifikat',
    'sslprocessingstatus' => 'Verarbeitungsstatus',
    'sslresendcertapproveremail' => 'Bestätigungsemail erneut senden',
    'sslresendsuccess' => 'Bestätigungsemail erfolgreich verschickt',
    'techContact' => 'Techinscher Kontakt',
    'updated' => 'Aktualisiert',
    'vendorId' => 'Bestellungs-ID Lieferant',
    'webServerType' => 'Webserver-Typ',
    'resend' => 'Konfigurationsmail senden',
    'triggerValidation' => 'Validierung anstoßen',
    'changeValidation' => 'Validierung "ändern',
    'reissue' => 'Zertifikat neu ausstellen',
    'revoke' => 'Zertifikat widerrufen'
];
