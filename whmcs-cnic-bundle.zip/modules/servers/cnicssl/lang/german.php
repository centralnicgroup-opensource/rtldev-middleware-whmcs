<?php

// CNIC SSL Language File - German

$_LANG = [
    'adminContact' => 'Administrativer Kontakt',
    'billingContact' => 'Abrechnungs-Kontakt',
    'created' => 'Erstellt',
    'expiration' => 'Verfallstag',
    'orderId' => 'Bestellungs-ID',
    'owner' => 'Inhaber',
    'sslcacrt' => 'CA / Zwischenzertifikat',
    'rootcrt' => 'Root Zertifikat',
    'sslcrt' => 'Zertifikat',
    'sslprocessingstatus' => 'Verarbeitungsstatus',
    'sslresendcertapproveremail' => 'Bestätigungsemail erneut senden',
    'sslresendsuccess' => 'Bestätigungsemail erfolgreich verschickt',
    'techContact' => 'Techinscher Kontakt',
    'updated' => 'Aktualisiert',
    'vendorId' => 'Bestellungs-ID Lieferant',
    'webServerType' => 'Webserver-Typ',
    'resend' => 'Konfigurationsmail senden',
    'triggerValidation' => 'Validierung anstoßen',
    'changeValidation' => 'Validierung "ändern',
    'reissue' => 'Zertifikat neu ausstellen',
    'reissueHint' => 'Übermitteln Sie einen CSR, um Ihr Zertifikat neu ausstellen zu lassen. Dabei wird ein neues Zertifikat erstellt, das erneut validiert werden muss: Schließen Sie nach dem Absenden die in der Zertifikatsübersicht angezeigte Domain-Validierung ab.',
    'reissueSuccess' => 'Die Neuausstellung wurde beantragt. Bitte schließen Sie die unten angezeigte Domain-Validierung ab, damit das neue Zertifikat ausgestellt werden kann.',
    'reissueFailed' => 'Die Neuausstellung ist fehlgeschlagen:',
    'revoke' => 'Zertifikat widerrufen'
];
