<?php

namespace CNIC\WHMCS\SSL;

use Exception;
use phpseclib3\File\X509;

class SSLHelper
{
    /**
     * Send SSL configuration e-mail to the customer
     * @param int $serviceId
     * @param int $sslOrderId
     */
    public static function sendConfigurationEmail(int $serviceId, int $sslOrderId): void
    {
        global $CONFIG;
        $sslconfigurationlink = $CONFIG['SystemURL'] . '/configuressl.php?cert=' . md5((string)$sslOrderId);

        $sslconfigurationlink = '<a href="' . $sslconfigurationlink . '">' . $sslconfigurationlink . '</a>';
        $postData = [
            'messagename' => 'SSL Certificate Configuration Required',
            'id' => $serviceId,
            'customvars' => base64_encode(serialize(["ssl_configuration_link" => $sslconfigurationlink])),
        ];
        localAPI('SendEmail', $postData);
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function getProviders(): ?array
    {
        $file = realpath(__DIR__ . '/../../../addons/cnicssl_addon/resources/providers.json');
        if ($file === false) {
            return null;
        }
        $json = file_get_contents($file);
        if ($json === false) {
            return null;
        }
        return json_decode($json, true);
    }

    /**
     * @param string $provider
     * @return array<string, mixed>|null
     */
    public static function getCertificates(string $provider): ?array
    {
        $file = realpath(__DIR__ . '/../../../addons/cnicssl_addon/resources/' . strtolower($provider) . '.json');
        if ($file === false) {
            return null;
        }
        $json = file_get_contents($file);
        if ($json === false) {
            return null;
        }
        return json_decode($json, true);
    }

    /**
     * @param float $price
     * @param string $currency
     * @param string $defaultCurrency
     * @param array<string, array<string, mixed>> $exchangeRates
     * @return float|null
     */
    public static function getPrice(float $price, string $currency, string $defaultCurrency, array $exchangeRates): ?float
    {
        $currencies = self::getCurrencies();
        $arrayKey = array_search($currency, array_column($currencies, 'code'));
        if ($arrayKey === false) {
            if (in_array($currency, $exchangeRates['CURRENCYFROM'])) {
                // Product currency is same as ISPAPI base currency
                $exchangeKey = array_search($defaultCurrency, $exchangeRates['CURRENCYTO']);
                if ($exchangeKey === false) {
                    return null;
                }
                $price = round($price * $exchangeRates['RATE'][$exchangeKey], 2);
            } else {
                // Convert to ISPAPI base currency
                $exchangeKey = array_search($currency, $exchangeRates['CURRENCYTO']);
                if ($exchangeKey === false) {
                    return null;
                }
                $price = round($price / $exchangeRates['RATE'][$exchangeKey], 2);
                if ($defaultCurrency != $exchangeRates['CURRENCYFROM'][$exchangeKey]) {
                    // Convert to WHMCS default currency
                    $exchangeKey = array_search($defaultCurrency, $exchangeRates['CURRENCYTO']);
                    $price = round($price * $exchangeRates['RATE'][$exchangeKey], 2);
                }
            }
        } else {
            $price = round($price / $currencies[$arrayKey]['rate'], 2);
        }
        return $price;
    }

    /**
     * get product type for given type value
     * @param string $featVal
     * @return string
     */
    public static function getProductType(string $featVal): string
    {
        static $map = [
            "DV" => "domain",
            "EV" => "extended",
            "OV" => "organization"
        ];
        if (isset($map[$featVal])) {
            return $map[$featVal];
        }
        return "unknown";
    }

    /**
     * Import the SSL products
     * @throws Exception
     * @returns int
     */
    public static function importProducts(string $registrar): int
    {
        $currencies = self::getCurrencies();
        $providers = self::getProviders();
        $certs = self::getCertificates($registrar);
        $assetHelper = \DI::make("asset");
        $webRoot = $assetHelper->getWebRoot();

        if ($providers === null || $certs === null) {
            return 0;
        }

        $imported = 0;
        foreach ($_POST['SelectedCertificate'] as $certificateClass => $val) {
            $product = $certs[$certificateClass];
            $provider = $providers[$product["provider"]];
            $productName = $product['name'];
            $existingProduct = DBHelper::getProduct($certificateClass);

            $productDescription = '';
            if ($_POST['ProductDescriptions']) {
                $logo = $provider['logo'];
                $productDescription = '<img rel="prefetch" src="' . $webRoot . '/modules/addons/cnicssl_addon/logos/' . $logo . '" />';
                if (!isset($product['features']['domains'])) {
                    $product['features']['domains'] = null;
                }
                foreach ($product['features'] as $featKey => $featVal) {
                    switch ($featKey) {
                        case 'type':
                            $productType = self::getProductType($featVal);
                            $productDescription .= PHP_EOL . 'validation: ' . $productType;
                            break;
                        case 'wildcard':
                            $productDescription .= PHP_EOL . 'wildcard: ' . ($featVal ? 'included' : 'no');
                            break;
                        case 'domains':
                            $productDescription .= PHP_EOL . 'additional domains: ' . ("up to $featVal" ?? 'no');
                            break;
                        case 'subdomains':
                            $productDescription .= PHP_EOL . 'additional subdomains: ' . $featVal;
                            break;
                        default:
                            $productDescription .= PHP_EOL . $featKey . ': ' . $featVal;
                            break;
                    }
                }
            }

            if (@$_POST['ProductGroups']) {
                $productGroupId = DBHelper::getProductGroupId($product['provider']);
            } else {
                $productGroupId = $existingProduct ? $existingProduct->gid : DBHelper::getDefaultProductGroup();
            }
            if (!$productGroupId) {
                throw new Exception("Product group ID could not be determined for {$product['provider']}");
            }

            if (!$existingProduct) {
                $productId = DBHelper::createProduct($registrar, $productName, $productDescription, $productGroupId, $certificateClass, $_POST['AutoSetup']);
            } else {
                $productId = $existingProduct->id;
                DBHelper::updateProduct($productId, $productName, $productDescription, $productGroupId, $_POST['AutoSetup']);
            }

            $productPrices = [];
            foreach ($currencies as $currency) {
                $productPrices[$currency['id']] = self::roundPrice($_POST['NewPrice'][$certificateClass], $currency['rate']);
            }

            $productCurrencies = DBHelper::getProductCurrencies($productId);
            foreach ($productCurrencies as $currencyId) {
                if (!in_array($currencyId, array_column($currencies, 'id'))) {
                    continue; // this should not happen, but just to be sure...
                }
                DBHelper::updatePricing($productId, $currencyId, $productPrices[$currencyId]);
            }
            foreach ($currencies as $currency) {
                if (in_array($currency['id'], $productCurrencies)) {
                    continue;
                }
                DBHelper::createPricing($productId, $currency['id'], $productPrices[$currency['id']]);
            }

            if ($_POST['NewConfigOptionPrice'][$certificateClass]) {
                $existingConfigGroupId = DBHelper::getConfigGroupId($productId);
                $configGroupName = "{$product["provider"]} $productName Options";

                if (!$existingConfigGroupId) {
                    $configGroupId = DBHelper::createConfigGroup($configGroupName, (int)$product['features']['domains'], $productId);
                } else {
                    $configGroupId = $existingConfigGroupId;
                    DBHelper::updateConfigGroup($configGroupId, $configGroupName, (int)$product['features']['domains']);
                }

                $configGroupPrices = [];
                foreach ($currencies as $currency) {
                    $configGroupPrices[$currency['id']] = self::roundPrice($_POST['NewConfigOptionPrice'][$certificateClass], $currency['rate']);
                }

                $configOptionId = DBHelper::getConfigOptionId($configGroupId);

                $configGroupCurrencies = DBHelper::getConfigGroupCurrencies($configGroupId);
                foreach ($configGroupCurrencies as $currencyId) {
                    if (!in_array($currencyId, array_column($currencies, 'id'))) {
                        continue; // this should not happen, but just to be sure...
                    }
                    DBHelper::updateConfigOptionPricing($configOptionId, $currencyId, $configGroupPrices[$currencyId]);
                }
                foreach ($currencies as $currency) {
                    if (in_array($currency['id'], $configGroupCurrencies)) {
                        continue;
                    }
                    DBHelper::createConfigOptionPricing($configOptionId, $currency['id'], $configGroupPrices[$currency['id']]);
                }
            }

            $imported++;
        }
        return $imported;
    }

    /**
     * @param $cost
     * @param $currencyRate
     * @return float|int|mixed
     */
    private static function roundPrice($cost, $currencyRate)
    {
        $newPrice = round($cost * $currencyRate, 2);
        if ($_POST['RoundAllCurrencies'] && !empty($_POST['Rounding'])) {
            $whole = floor($newPrice);
            $fraction = $newPrice - $whole;
            $roundTo = $_POST['Rounding'];
            $newPrice = $whole + $roundTo;
            if ($fraction > $roundTo) {
                $newPrice += 1;
            }
        }
        return $newPrice;
    }

    /**
     * Import the SSL Product Groups
     * @throws Exception
     */
    public static function importProductGroups(): void
    {
        $providers = self::getProviders();
        if ($providers === null) {
            return;
        }
        foreach ($providers as $name => $provider) {
            $productGroupId = DBHelper::getProductGroupId($name);
            if ($productGroupId) {
                DBHelper::updateProductGroup($productGroupId, $name, $provider);
            } else {
                DBHelper::createProductGroup($name, $provider);
            }
        }
    }

    /**
     * Get list of available currencies
     * TODO: check DCHelper::getCurrencies
     * @return array<int, array<string, mixed>>
     */
    public static function getCurrencies(): array
    {
        $currencies = localAPI('GetCurrencies', []);
        if ($currencies['result'] === 'success') {
            return $currencies['currencies']['currency'];
        }
        return [];
    }

    /**
     * Load appropriate language strings
     */
    public static function loadLanguage(): void
    {
        $language = $GLOBALS["CONFIG"]["Language"] ?? 'english';
        if ($_SESSION["uid"]) {
            $language = DBHelper::getUserLanguage($_SESSION['uid']);
        } elseif (isset($_SESSION["adminid"])) {
            $language = DBHelper::getAdminLanguage($_SESSION['adminid']);
        }

        $dir = realpath(__DIR__ . "/../lang");
        $englishFile = $dir . "/english.php";
        $languageFile = $dir . "/" . strtolower($language) . ".php";

        $_LANG = [];
        $translations = [];
        if (file_exists($languageFile)) {
            require $languageFile;
            $translations = $_LANG;
        }
        if (file_exists($englishFile)) {
            require $englishFile;
            $translations += $_LANG;
        }
        $GLOBALS['_LANG'] += $translations;
    }

    /**
     * @param string $csr
     * @return array<string, mixed>
     * @throws Exception
     */
    public static function parseCSR(string $csr): array
    {
        $x509 = new X509();
        $result = $x509->loadCSR($csr);
        if ($result === false) {
            throw new Exception("Invalid CSR");
        }
        $data = $x509->getSubjectDN(X509::DN_OPENSSL);
        $data['SAN'] = [];
        foreach ($x509->getExtension("id-ce-subjectAltName") as $item) {
            $data['SAN'][] = $item["dNSName"];
        }
        return array_change_key_case($data, CASE_UPPER);
    }

    /**
     * @param string $domain
     * @return array<string>
     */
    public static function getValidationEmails(string $domain): array
    {
        // https://publicsuffix.org/list/public_suffix_list.dat
        $path = implode(DIRECTORY_SEPARATOR, [ROOTDIR, "modules", "servers", "cnicssl", "lib", "public_suffix_list.dat"]);
        $contents = file_get_contents($path);
        if ($contents === false) {
            return [];
        }
        $contents = preg_grep(
            "/^(\/\/\s|$)/", // match comments and empty lines
            explode("\n", $contents),
            PREG_GREP_INVERT // but consider the opposite
        );
        array_walk($contents, function (&$item) {
            $item = "." . $item;
        });
        $tlds = array_flip($contents);

        $domain = preg_replace("/^\*\./", '', $domain);
        if (!preg_match("/^https?:\/\//", $domain)) {
            $domain = "https://" . $domain;
        }
        $d = parse_url($domain, PHP_URL_HOST);
        $parts = explode(".", $d);
        $tldsearch = "";
        do {
            $tldsearch = "." . array_pop($parts) . $tldsearch;
        } while (array_key_exists($tldsearch, $tlds));

        $d = substr($tldsearch, 1);

        return [
            "admin@" . $d,
            "administrator@" . $d,
            "hostmaster@" . $d,
            "postmaster@" . $d,
            "webmaster@" . $d
        ];
    }
}
