<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmz5B61zg9HNUFQvGxU1sgpmBpNXNe7t+vEuc1voxY3EZHqprV0qKp+AV16k01CwALNzyr9s
hs1OAz2LJfB/+OYbk/WP1skjS+aqJp+48atVnLPxY41z2b6NnfB57XWb3X7iH6SqAxsOBrjHpTIc
IHMfaC7n1/CzLek4niMkNt3XR17xk13b9todiO04pq1HN43NVi5FHL/IWUZUGtnBf6L/ydZJ2K3d
dZBBSyZClY+8h2mnofke226E4dDutB0Jzyd07gppYEhJ9G9xXWTad9nBMjTdnQv3bv8n57OOtDZd
QaPu2gKTblUMcYdozzMOLmYERDZ6fV9qS4ihagkcNCwCHYLItbLwfKnXAhdoS5jvyquLJJTx3wl/
l6Fn3bhd5GC5pL9pD49fyjIN7Hb0NpZPPlE4fcD1Sb9N2PLX8YYIIBEzhQA19lFzzVe9ZjG29Uz4
hUlwq9CO+WGuwOZvXdAs9i3lBRhHWl0faqWBlYgjP2Njs83Gh0Et99RTXytu2OZkMMNcvno576HE
V3vPK2vcRBUyxEAyThBUvxRgYDDc/jyJ332pLNGLZlm1ADXi3Zv42V7rOzz5IfPzRe5qr+6bNEzG
RCl2ErasxNRxBtWiZ5Vd/sWFCfE95Sx4eK1ItIeql+IKJhThXZZ/g2BUyDngbmUg7XPP+Tya5xV2
IS/NvYAoMvHjhBAhYoHBTIu/+/baTEW/0vumCbqwliz0Ddg5FoAPDe+ZNb5KeMjBW1JzSaGZhPa4
D9hWiZ7L6fimcEDEQ9lv0JkEi5vDdhzhVYRCMcvFbY3Yup2TrzY8DoNIRp/hrJs+9BqtbJj/AbtZ
DH1S4CFVSvMaCaeRB9+9DxVEZh5Ono2/cy+DN40HKUo24NYONpjt9GYKlsdvghXTlr2yr9KWlLMR
+9DyZu3yxckzNK3unVCCHpuaYsVu6NkoSDKuAzkVjloX3ZXy3ctyLvLvN+X08JOo0U/qQtzOZXv2
um9DoGQmcrs+JYu0VToMYMes4Q3ezPuFTS0kKKNaTr3xg47jA64T9EHdWx/eC5wwWoaIy3vzrRef
ZjjG0X7ca2rRpH8SV3jaFP/fK7B6Q0Qa1xNV06kwaSdmmsPc7VmAOgqopEvole5L6uGnz6kNb6IN
ZcG1cK0On1SZauhHdRwlSDvwQcDi91J6x8HzulDlkYcVlS151Xl15D8CfFYIrWsoaLlWb2dmtcxd
WDQSFcGidBKUycXFyACJktb9trXKMAw0oKxIoQrT/dxXlVXGthgXN5eV5+4wEI3AVfDXM+hERnY4
Jck3meX0wGaADR3ukhnaSzBaLx8TSOc32F1cQ05jKLhJx+C0JD7+pt7+SEaJ/qf3RiFddqOwdrGt
lAvqQp4zmrrkBGXttWDJz0gyFc3hbH6220LvkWttaE8DdL1N0t7ogvr5r1XuQ4DrumJggBDxjeRt
ohTY/nqG354oVtM5SBo8W8Pd3WE5Lwm2vwVAY5lSRyAZiNZ5nHNBOQMcy/3g1fR6joJK8fcgrkgn
QDKPdDMFfUgdZVDNobGoT7AAHWBw2+4j6Vvg/JqfXKPWIH/pbVsELFPoDhp1I2oG1w6YssMGx70D
G+Fvr3fgMhMuB+7PxPccRavNdO+bYVGsRjP6dJ4sDA81hFHnRZ5M+LfOgV95KAjgkyxiPd+EYFMu
l+J2UYiXF/xj4YRlJkoiMYd388bXRNbsd3WEsEfH3AgyJD9DyEiNk+1yVMgdd/te1j0CwBlsu/sU
Pn64sSdjpW5SLX4q8Ec/Lh4Bd//jozm5m4sH/0Tig7fVArdTCA9zHbSEX00+qUpSAGC+OKzyCivo
BCpc6RXHNA2JijIEkeH7pFHAoONEoRKaQuXk7ggnAbWgRRQQiMXQSEd7hbhR0HI3i87MnyyGoz1z
VhAOpwU5Hb6nEKknmlMydNuRS1jzG794rHRXIB2fujc8pXtgvjGHUjPcYKDcE/8YXZNWTRsb4H4O
QPcC9gT7+22H0+yPYMxnzSTptJWuOze+C+uYYMKcDDU1Gb+yjRI8qGMG8G9dechR5+nFfYi/JADq
Z7azPa8FvgxI2T7BLdztynQJ1dMjIfNgri1GAI7GHZI9QZLsrrELwbuv67mQe8o9Cr7rtIF2/McC
KZhKr2s8dQ8gXng+uNwuYiPr7UkxbBSr3TIuLJeHsmgL5MvojhqhbudukdHCnSv4o3dYVjZBoFZH
HQAbag0eJ2pyjzm025mpWgBToqlplp7Jfpi7L4Ly2MQl62uGOHrkbJZE407udrjVVnYHKRjhk7Ze
Gn0tFGue9I4OIkLBhDcW706Jl7yAlpXa4r9EHb2OoxGJISET4UxA3VjWA5t6tp6Iz2tDoxKuvodX
cAW01P5n