<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvbrfJ0Qs1q7uyOm4zS/Tb29kMWiIt/3GzGbgIu73LNvcOBK0uZNk39zbM/jEO5UL8WaSXMu
fKyCmb+SRD4oyggIBxUM8kQavmRNbIGTgIAY3a/Wei9b0Nz4Z1H/LFOd7ffY8lS+7KG1KqxuO1AF
r9hFxiIFPl3/UrBDUC8/P2o8HauWvLjF6gFbZkgiUVpSCKAw+GXEiNcGh2bo5hMS0UBCBK29l6NT
a9rKkPlvYlQN1Ffabb0hdaPSqm9uGdrdg4FWry0ecS5h5/SQ9v2j2HIeQ9c5PI0cDTaDOkRV9uhN
PlA6P/+1YJN1JfDr0ORnaBN6XNstcP+XoOhPSPe7MUN1NKwQMOHJKweaoigYGG1pcD7aVM2Vr6wd
sUYzeKzGtToL1YoM16jPM+QOBKo4HWAY+X5PkbUFONcH+jaDM/wyKudz1XwXmCWKEEr6RNDqFs9H
I7rexKDyFiID5dc8emG1a0zdfRPvQdlsxRgttIercxGmlbs/Dtp0H/apLrdhBz1cROIhLhGvOlBK
lQCHB/v1s3xJaFxTQhxvDUJYb3L32CeJVRjwHZXv5butfKSu56TEmGe7K0Gi5i2xqes5yOVOpRB9
fhLBLxLfjCpqZ+QNV4mH+oocJlne3sUNjY/DMGH2Iciz/tMotx8lldAT0h9zW5phZ7LIuLwvkdPo
ujI9S50tUEHz7+L/9m5/HiTW0AixAbrmz+xEQQvMCQdl5TYhxNNaYZR5y9uoeX7+dMM0OCn2+HBR
jwODTV+3VgerenkjLCew+AOijQmKYypCAbJO3Tgi29xAnRdd7I9n21Ez6kHEREfK5mE28OHoXeRa
bFSWoM9pOfQX6XD5fM4K0HWVZCK7WlvIdLh9pWD/rFQHQ+/fKvAGAQDLEcg6pYED9fr1Fk/m8PPt
pftVx8C6V66Bt3xyq4KP/1mzykoTbjkrssW3W9wTTI+ARFKFOTGjOCPs58COztf94tg591SVZiCU
zjDBUm+DLwwM14eeeSsa287inm5tiDpSl9IkcR6E/mVmJwtugQC2JMWLzsIbnjK+4SdWXzWIsirP
aCLFaFDGhAECdjomvoEtP6DVVScKDqtatswgpj2t961aIjTXp3r1Cf2rHo4X8z85rb8ZfH2r9qJb
50CulC6JftPKHn3RMe+EmUFvdbymlZ6tvLpIEt0YuYRqZ+0QSSd1e+oyjSGHJVsw+BJmhz1Jocz8
mljSmqPNYYxBxCbdBUuowpzSm7FxIfnRaDyO0bFO/TedEJlJQ16qz/wqvaj7fAv/21XgB3uSu1A3
03AiwiY/2RVlgJRXLR7KRj1BZ6+SQ3xNgCOuZfP9/l5KbrjBNH0uE1aVp2sc0feXGBhpgecZdTOb
lbqasoD8QtHZ9waKFxBu0FNoTPX9PjZiGTd/DhP0P24NctMw/Tae8MJzBPw1HwprdiPY/KqnccIV
Qq3npA7zI+ZgjWuSMTgpPWWiFiDI9xosHwhEnqFFh3eL6rzj5R2TIbNaGNgG1izC9omjLh5Pzscf
WsLnRJUJ/lBXYzoGFltbBfRgsTRaEsTUKRDsf1JJPFg1Gh1S+8CuoFUBr6hXduEsbAJchQI4sr1f
6HcJv2OUxgn59xPoAwwzOUNsa2E5BX4l1SXzlsbGM0BMXfhH8pRVnrwZY9+xn5HqIFRXiLzr/nI2
HPN1nWsdji7IgkTT4i1U/mr+HVfz7OUm4zww/DpgbrUohZsFDORET4NC1YdAK+fg/2mcV/vyJD99
gPpE2ejx5omdI+fctz5XKPwvodWpsxKdi761SyeNCpqGjMvJmuqUqvhDvFLpzA6iPAUFtdjhjDB1
uwQu7Ah0njkpwAvmcGA7wBnrD5kQ/Hd0r9NhR7+Za3XJXw4IfoV8HYxFNyUIKenxcj+MUfa2i/t/
uEc/yItCf7CWRHm2EDE73gxF5MCDhDPSsfYewcoqMCdvk5BmR81TAlBWFkJOpaqcSmXcanqv3E/b
+duJKAr5BDgSdNtFmHuzKXcYpKO7OftrG7iIgfv7CV1b1aix5hmAfU93p5L28OeWWcuP9vGI89xO
XY89e32mhWtA0X/q3T0D6R6R6RsXwnBBn9uADNZMGAMEUhab+uhkABUuc+A57pOpeD/Xm1UWbQ1M
bT12cmsLEiAHsbFW6IvqDZ3cs0of9ChdEuKBHPEQaubrrS9bPvCHH6yUjwWaLnkkDvuQ7So0mm76
yZ2tcdOawUQubp4AdeTk4Tkf5IBg/rgFHAxHnVVurUPXJwgdz0gIym3RBIdVOcikEVasGKOMvixw
27I+siDgJYqXI0R7+GXKxi/LiXirTEvZ7f5tHsUg/Lt+9IfGbaGL3UBI1PArTLvur16UzNwt/W/F
3W==