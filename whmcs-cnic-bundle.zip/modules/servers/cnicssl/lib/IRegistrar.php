<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr4m7sqi7+H2AOEAJc+1p2ieXAVDU37Vjfsuc7AfUhG2nQqRP7K/BFwPMse4mR9wFu1TuFv+
bobMGKXEnuqndR0wJKZlVFWuPVlytxZGmoBtL4ZZXoksNU1i0KGaTTWIwSn6sCk6J3Vv8SKehU0u
wTcPAmERcMR5l3Gdx0r/qDjvQp70iaYKYEz4NnexYw4LTZb0l3XNHm8buXKbU2Ip8e23RN4cN4N1
W/N28Ckk8zn/lT9yNA1qHeS96hdAL8JI989piVziFXhP3NoA6aoR1ZAhpPzaX+fJ1iIAMwhB9yun
2+X7Ue4CLrm3rd8RYPuapzIgIrEJUhFxH7csMbGdLl6FHTxzqMmqBVLyIi6Z5v32ihXbfSeDVY0f
JSx+1zADKJQYJSzN8nfwbXviPizhOJgVAAw28YNakxg9KJCYi/+9+9ZG0R4mgnfuQihmVy2SHowW
3VN6z2S9BUSaRjSPXvSjTAM54y7Kx8LcDNjRvTca6dXR/mr/M0R97KyGZovOdw15SijRJteYYzPz
zYVc5w/fslYzliqveqL8sF+cNXBdYGrwb2WJLOAoKfhG+sl2hMrmBhTxNLocXxcAeCJyxpXXqbt0
21nIv+sE/lkkCgYndhXlDItxZRaM3rNvCVUmRqaBK7bd8ysmtcl/ImM3OOGlGf6aaGCFR55nNrHx
Ji/WguyY9nek3fYrHgz87vajvePRc8cfjgpPgee7/zBC9g8shD7nAN1m9UgZcnPxWPgF4B5juIyV
5D9p3fSp/5bTBD9nETY2ly7WfM1YnZAP0ftuBjPNchqVAjKmFYNMbA885SisnNrx14b5AM2TTbdG
TvX73KEqqq3NIZXoFVWp0iisMGE+impKjr2CCg0ZfDfol2tT5Ly+qff9c+NoLadGIFGOC2K9JM0p
oohwMaXyb8rlKkWQIJ0TOCXfk9lkkWMKPCKBUqqxR8+QK5Vn61tVQloJ3ByX54OuzybzO1gVn1VG
fBJhEBeiFK3a0l/zBmvA7zWAbA4TKuVyCLV4OTBo4wr2ATKQQn7XR4JZgae4+mme1o0ErSFsKrf3
alyUaqloZ/rPuUOFyo6YmBM4TbQD3bFPZIdiwiJOfeSENT6P2S+DKn8UyAmUMPkDXQQZKroWM+uG
ClAvwfVktbaxKyvqjRVUKvNPs0ct9TvNkKI0p2mSgYSLXR4Vc1e/PXEeA23+fDTuostBDg7umFFZ
IHbD3116kJCYAK6P8c5kAVwWEGJnzPNJZa8rLP0gBvvv3ynxC0EIvLUmfVItqABk05sozTbgohPn
rVL1hH2gKeohEbEQgqM16VqviEWcFVWRTHZM5ZS7FiRWiRqEBAzpOabeIwESV7o7OMf5OKJB7O6Z
2RqM3p4YO0h7d5gaC3+v/g4JI+k9UcHxhPLn9rVpHzeCvB5fd2U54JgE9CScE9ubG/v6a4b4Qm4w
P4z372iJhKdxuTNG30MR25JLiIGR/B32a/jNd0Sv6vh03XSCyfB9Xpxlyo8ozFinh05Pr24ieVMH
b7g1jw4axkuHZkIOqmJ6G62dAfXZB/Dcxpcvv86GP8GnVWucqrYvTMnJCSQByb2FdWR4c0JDn7Ve
cjjCmLxHnUdjursQ0DI15UhEd4kiEQrC77h6LoJGaBzE0d/wMWJnLPFSCWRbd0Ji7yEzjKlnyavb
tnndg0VKn/KjJhVwz27/d9aVSfZGCml3f94/ZGRe2HrZdXAAzxIrtosCJXLVR5sg2Y5W/6Ilz4bO
IGzfKOJYkIft7QR02OAlkalBkzQBd2w/E90qu7WRC1/KTpGjGen/qFwgsA4Cr6hi8q9t78RRsPdu
W6b22GvSnTUikiub2CfMil5ufNWzaH6FuIru65jBmWpQx776D2PJOqlqnKP3PThLiraZPTiKnUfX
+Lmc6y14gFBSfVZHYxVyggKQD7/BBkaYBluP+Cyp32wNp57L/mWmfF5B7sDuoDgtBRFYMfm+0BdD
0HOmCt4O4Bk7zdSWwRskVIlF6Rj7gF+MndVKnLgzlgJZ/6F/9uz9OaUyAk/BXxe0f+bvqaU6weVe
g5wrgxxq59skh+txuB6ixRNQZIuK8+VN4NxI6iFfTfIM2kztcIGqhCSEf5izbIQWAgE+TE5wJFTM
YY1mDfmgRD0mWWsEzqy1/2J4/hf0+/3YcMBys9s1jllIh2H0gj5EAygdI+DHcr4al215qKA2daLA
xBWUDsG8Z6ZIl732WoRIlwWgRPcyrZzeT29fUM8Ek0rSki3RCaA/Lu2TqbrBuL9Ju25aV+cALR34
6azWQ/WUf6fst04/nBeqEmA4Vn4xe0pNVso2syTQX8rMgmKugO3LLW+FXfhAkwfjVOSELHz0nxtz
zgcz