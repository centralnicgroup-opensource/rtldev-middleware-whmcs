<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPua/BPNY1fRQ+uoujYLkipvoEssUpYXzLzyIxlK1Mb5E7resEk25TbdogGkI+rOFEMZmED/p
1OjcA+lOkvGH2HxLf0fQC4OWzMuRi1UOSL6PE3LWOGk+PVTZNJRM8Drit3FlogNJMQaRWN3Yfzm/
56/rFp3DWR2B/P+3bNsIuUpJdTTi58bEvyzxpm/XBG9woBAQ9lDGpFLjr2g8aP0o2b7cR8+tTHue
Emf4JqA1SBFpQqP3ZrO/zHW1EY0EExfI6fh9ajKEUEe0ZoafcF9EzKRfgWoR3MP9ojaQHlKUn52T
Tb6VHZSKh6NgbTvImGEfmtUt6SYVM1Itj2wN4ssv7rqRI7i0/YdHQ+MBgUvgscnA79XjvYQsR7U2
ehbz/9/Va7ZCHU25kY8s91v4iYHUdS3aFygijLZXu09Xm6b5o+wQDYZJ/DuhlWKOgFgIylCgxXsy
DkQJVrR6qtyIdVmc3DQYCEDF5STz98jfie4fiOghWgVsaqI5BA+Gu098BnQRxs+EWM/neCIWEX7l
saWOlwVQ5dmYoI1CfIrfNe3ofwTc48DzUPF68aQZtRP+ROgdryqvOfkEa1wDTsamR8yUtT5EwIO4
GE/UvZAjWl8Eb2hu3absQWbiC2uA8i7k6tWut2BTPzUiTEl5526sVFz1SlD1twdwrCOkJjG6T3xH
yk8IywSCmqctLVYaEY9NMRD64g+C9dpDzVzeIx0bi/5T2Ksd6bGpiwygP80KJpHK/LKMnGTz1ozM
Ya7KqBzG3Tl0KwFXVd+A3UZXRive8oI3PzdLyBK6fa5xMt/LtIPI+PQiyfKVNpNrZ2/vSzjU4PLs
TXnQf4EBPov3nXqriDoYv6uoWv0stjLwJFrCcN0IwugRD6DXpF0KMh0eQQ9ExM36+8WZZfTmqbD2
MttpyuBQ/hSkdZXBczpDvQExuXeeLFejih2oV8gwQOGgzwj7BRUqRvGOnNqkzDUy9oadyGbw/u3q
VaDe7b+zr416n3LeMPab/o/EYp2NihZQCOA7Sgm/C1aBZBwbxQoZwsb6ikgwDZPZ2AGv7WYF71XH
4u2cxnPKIFXrU2L+tlL80Iz91kMhnEkn7SaRt141ExfL8R7ywv4ErvXWu/NIYEudfPZUr2umPPo+
roJQvzOTIMFKEa3r91r8NgVf7LQwTZIOES2Q+axwd7ECFbwovJ/7xrYJWv7PcNPBY08uh+jNjmfX
dd/57NQS5nllS7Rn6DiWVL/taLa0DlMHF+/mKvskMCIvYgEbafJmdu1jjsUpD4Xw6wZAVq+AvTpS
QYXz+TNzEljyD9l53D7j2KfvHS+dV4F/o0g8AbktEBNIXZMzYbSxsU1WoHmgGYTsXl8nGgafYKpG
lEKTzSZihfMU0EYomtI4wA7JfoCJoOo7pvjgTfoHd3eZZN/WDkYn2Yo1oZ8DYbVXECkB8zmXKB+f
ZGXsMH9vSCQ83mPnZphnCKbzNpdc2zeMWUuAJROXi5XhqUYWxgUddWof3tIHe0IVIWokTgsIwZvH
eNmF8qarybrBeb5qqP2NEXv07Ghlj7uR+FmQcELmSK3pYrCv1KlIZuiJNIJvafzC7MR9nH/HNZsp
Jz10X8CBC4PqSkdS/ra5s7NVYFs5TVy4IAmDjEiFXSTlSIfq2SWUKLjm07GEEt5cApGkZVVkKHWQ
sWglneos4lQUu2HjmBg+ELrrbzszKOgC8zMB1P9cvRzIIYNqzNm+BP0DQBUrbCp1m0Z59yg4NO/e
/C7tyCbff80HXhdc16nCak68L5JjgZeIxDhwqxpVrnZhqaiIcPNucO8nA19WnmTg0/2FHk/h84tq
WGoZx4YyUkdrxKsf6KsftaCxPHY62N5ZD4TbDqV3dIo75fbhYtuFAG6eQUlSVfgHUvzx3bj05l89
Rs9CBXRr+MECIIiaY8N+ygUQxE3eFPxNmBj6gHRZlByhQ7dXRamGcbW4hrF/din6KG4Bh/PttfWo
SWPD1HYuLOkpvo56KOVPu7p600GVgdTyGc14Y9xcZgao5mG4Syr/J7YXtzNX7GKPsf22o1mkK7XO
0+lhhJPN4Ze5grR7ixQJmMvzLAwHMn/2ky2AIv5CrtNlZWCXNuSdcKWC0gfGhoPnkADnl6fvSKAg
tygd9iMf2kbcSj9VNbi/ROJziCfWdV8+ZyRSF//nKgOflyyOUJUmAFKsO2wknSl2j/gk7LwQkULK
L5pQi51NJxIupl+aiwyhWLk9uCVJyWt/kQ7jzItfidu9wVq3r5k6OepU2DzpSBowo8QrxMXkQTQZ
oY5AYjViMQSMJXyzCU+6IYAz5WQoTLTfJ3b1xZ8c7GdFdSb77ZJ1A8LblkWBZdG6avzQIu9ZzsDZ
OR4Jmn8GTw0aW/X10SEZD0d/0xq=