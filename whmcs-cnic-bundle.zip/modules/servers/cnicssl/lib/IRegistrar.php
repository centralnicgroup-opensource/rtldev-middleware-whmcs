<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+2tDcB1dejLd0IZGMMaZOSmqV1QNQ8L+j1P32OH3cIiafs6LVUrVAOakbgjYzTZMdaNqgkK
H/9eYZ0f76sNsX4n48ZLMmGepavMC4fr0gc70tPzyJR8ErJyYnwUFtToxB0q45RRfFbvi7Ksp+Ej
d7kWr9hzCwC/wDJtrKtI5uDIusMdZjIS6uwI6BYS/mrc2TADU4bbdO/87dH3BQip56KYOOKHxex3
Qemg/yWR4Illj0L9mDml3UxiIHBzLcPegKTTe0PGz5qzFh8GDNAai1hBy9R3uMO3rRDJJ+6R2bm4
Gpsz9mB/i/qEAQEkqc4QASl2gfyOKL9dcsI95VDV0hl/rTbNhfbhhpft89a3bQwHsqDhCjwRj7+D
zonQxcXgAqNyElvzEz9zSgVlzY8PSCUqu2l2s/kCdyEBfMdxwAb0UtseiU4XFT5Q/2XBGyorTA93
P4RahIFTgv84T8Com8rH9X/P2QAbq8FzoLgdChsQyJ5Htk7LtTOiCUsXgzx3zZ02McX8mUNV5UcQ
pUHA3fTnEKuiaVQeHADh08SOQSH+jUt8J/ggjnRmxLhjJ9IaLfHxWbY2ukdjMHfTRwUZo6ltsiRh
sOqg3TI5JFekpD+lhtZYTQH/4ngpg8U8yRgUf3Vue0Hr6FzugGt07BUFqGjaoPITeUFVfFV13Hja
/2tq23siUwuiY8blDknSsT/8y8eBnMWaSFWCRdFDEpOSKNq9asvW1fcptAej7uPs8dgXYEqMGK1l
EIleHnxgv8xk3f9TBaiwJtqohm2xEFD9zyergnH+DDngWetPmg81Um9ZgDCRWCGDHb4n2nSZ/BZc
tzzrGnVpes07REXAjmBcP7Iw1wRF0xNghXxPMQxKabuCndZwJ91qZ/qDFRlLg1Zj8ImnaXi8S5e7
sNG7zI8sDlWgRCd6qbsPm2+z3lsl/QNqOJkYxqDMNifZ5raAx9tNTW6X0+eVXkTZgKeGViB6bQVZ
sYj0hSSb//GLJWeN/iOcoZrH6Et358trpFHJQum+yMltJ+HYvh/W2RO+GM80u8AfmLcfxldyKaRC
qhUEU4Po+Z94FJebo8z2FcFPOU7EVispYHjArf0XyxA9hWPJzMxn+OWfQ/xrTvLkkd3duvZaAg8x
KQQJx+u7ikYDQ96nYHVGWgShhkoXSAL1t5xlenuaYiHEZenk1FV89I3RGzpcwvURlCsvsjgR5JD3
zhrLwgejpaMk4KvzjfFwwex0Vga4E2Q1hhFAl04bw1lcZp2AhnRqAzouBE5OX2N2iM1by8dpeVLh
8+gSVeaJMsHIbl9HbfGDS8GdMUEw2rxN4wKp5Uj6Nrx0kHv3fs15Rk4kKfD7fvsXm8AO9bIfgkk3
XYfJ0fjE0V4ng0TlF/5IOS2PX3ZxXwkv+Tf5tUr7EdI1pTY3YLAvuZK+K+VbsPud24RZ3avCqgR6
k51y1r8XxxslewouK2OKIiLOxSa+OC2O+1ejTVFoHxlbCy+Q+qgCtDP/i0CNQOWfi6IKby6Xxh2O
yJibpknxY11ATC/okIy+k9ifqDqqnobTNqsWU6Wgf9XOvQX12jbmhMExKU/34AhdVwLAHp7i0RCZ
ht9w4eWdBIcwZEJ+q1ipFXLTrl6l50CqjmKO4s4JTlmgRz0/YoZGQxe659BFKAkTLWU5OYSwHukW
8faLUn9UkA1Lxt1lNWYPUJOZU91DUfuQF/OFXb7mlosWTXsMBSMFkyex29KWGIIQ4fqWtdPSCfid
jP5av8HBd9+z9N8exs2k4pwui3NBd5XEXD3yWLcD/Jl5JTzAq7co/GmauqZdQeEBwhKDBfdqkm0s
32MXXF9sn/y1qSbdE6WH3uUKs5KzUv9SHZ/Dd65twm7d/gGTXPF4E2XJy+9ueI4bLAaUEls34+Oj
bL7x1EWNVp5YUfQOEaPLMsUKIE1833JifY9XaiZWEWvpxTEt6lgrTmzwzqcYoRKCbCz6hbZUZv8x
x91Am/RUYtcp9iL4T6jHDvyPNUSrEpLAUAs68K3kCW7vcIPGiW0EEIjca7PswMRA7Ep5JNj/OFNM
SKiZHkkJHhIh7vN9vmslw7+O/E8dxHOU/aqkZ13V6jMW9g/Q4yFhEP1bhznPpDt+Ii5BLnKBIeZV
fCITs10ZT60XPBHzOBgLYT5haiuA3CFoOi8Q02injMtEbZEFgQvRZ17ALhHEDsB1GIuhJANtebfm
kfeJQ5A3/N33BubagXMHbbnh09rH7THW2UPDTJ1EqlKViqsW5pKpXKqn1qkGLlWWDn878xuGU1jM
RbKVlbAo9ZGlcWC8338W1Wqkz0IkYAESrw0GlEQ48Ws/ThAo/lqOTH27L9mkqL9QuvK9hvF+Ajq=