<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwqm/TC87yRarODey0qNCEEPu9lcZoKhovQuNGPS2sQafFgYGOU1m9/LDJK1nPWqV1o+xPFm
1RZSehoIl1HE2LQq/5MFBP0515sj10xq4bOJNqAXM6J40PigEtmrahRhAOUthxpoBiq8suUfhH2V
4Lr8VZ+3I+Gcvkxf/sMKZCMkQrv2ijJnR5fP04SO+PQfgqt7fFoQdtZNwnPKShpF0G+zLS7PEuiH
q4JVN+zzsVHBBoAEB2PKPgGBz2GqfHBBOzMT4LZ16OUBPrHyK4fycPXPjtHdwWj76Qd3m2cW9pkj
EyTxZnNsK8WBxBF85f+wI3RCzq/bX5FORBgjyOHepcpJK+HsUK5DnI8CGjlm8/upr4tKZwcQbQ04
lG+VkUK/GTNdidCNGHyYi+xe+eEk9GvqiXJvXyrZAM459VmlAhPdm4Wv8ue0eq5qa0xasiCf+tzZ
pPnUlf/6sENoCcRhvdWvo+wmmG/0efX5Xg0B2R+owtjZcpq9QF948MojLxhcMpdSHpNfrhXKXaz7
PIES1/sWDoAeEHy2SxaWn6hQO+okrNV87/+HnWweuw/mPD7+VNaNMDbyeDXiCAWhJKKM1K79ksPC
zQ1bDPqxbl7lk7UzNmFVH6ax2hn5NH/Pg5VAYLCM1lgR6nHV+77/jC7mzm76NvnEX1LLNnaCxWQU
RGW9OPyTN5wiI8AOIgE+1vow+RPYHZem0L5vmZ3u8zzP7QE6fpxX05yj+mBUa/4wzJePsjVH/VYT
02BhudEe497woDT93ImVoy/I92h0R3r2Bq1dtuip3oHId//Pn/sP7b1/Rl0xn1gQ2o71QRsEgKjz
rzi0Ga8+YDst7jge0nvhxLM7Ieak+MKPaBrk6HdDMyrIgwf4zrE+heJudJ+pmnlKbvot19RlHqVh
1wwKV76kTX7FR16rZAJ+zO34S30duNNogkcUjX8gyIKxNyfjJz/E/OnEphs2pVJ5f/hHov0wbX7R
0SjdS1QivpNUB/zPtINj7bT3OePKoaFMmVka11M9Maz8yEE2G68ntd6vJoDxwb6F5QkT5LZWNd9U
zJBq1vsPJ1P7B84OUgQap517IQ3XgVhK9On5x3IPOlSHfKEiNwaNLGBbecM7ESBZKDi4vX9k91+Y
Rdwq928hFtIKqkgQdaJjdrJOo9Ztu9Bp2cRB0p/5XK7IP7K3aa2sa36fN+qA+wd2LQ2TjZ/7x864
GkpTfvTb0TrMm+NEqrnZlw/NjMc+K9QNTr88FJ6GSK3rvZ7J+Y6uiqcUZl4hhNwHhemHFVQ0ODLs
SbGa8mMkpd4ziAcXxRzeOnmPDfn/ynTofQxj9uFP9BvvLrF5PMmPsNgThkANwEEZLS6mqOtuloE9
rB3uY8fX6v9MVTXDHrKofLp/d7LPHyKkmNH+9sg/fEiv4+qnY7D493Q6OeyGZPDkpLtoo1Hnvy44
JfIOMisv1C01Fjof5h5meMh/BHRMfMQlAefb32oNpSV9Y+EOdfjE1kLQIBCCdblYgzFLbofbtvDm
C22H3MNyAOETClFfgC4q1BTAqvCnOWEkFsg4Ah+j95M7uiVsx00/3v2dxLu5Vqj60KqK/d/ohQmw
K8jDlw4DiqdZNma3A7RX2UySncnD9ggbXVIMDc2Pgb8baJKGAvYQLr3BR+pTNaW7Y0PXs9wC/4z1
phf/isoadV2ePNgqVNF/N8TnaFEbwFTl1+krfELbIiCkSjV70XdBif8uKV+Loh8iPsNpOHw6uWRt
UeLMLqbZQGaFA6QJiIEWRjFKsroKtDJfNElFVgCPItxCwBofZ10n7z6nzwvavLuD14rOGuTvI+fS
sKveDyPwRyv+4nkPyPOQpbZ5fg+mg2Brwoe07naa+WmG6WrL+FRm4ohO/ldGh0SU3vX6Rg9gN6p5
rvgN5W2JmJqrwgCf8uy2XniP562WIWls/i7q3y8ziK2e3UdXbZZUcUmchEbMSsngdwLWDrU2VMpt
SCOF408xcjiItMGwWiiAJrXX5NvsabU3TVc9ZN9OcyK6c3WuI+GLfymREvMCD7TYKQMCtCufBUD9
G1AqNFZVfrA4A7tI+2PtJ/jh1X01lK1g5SrfTGzHFjQaVYxF4ezCcLNihpdSb0NSEj2CcTb7GD+7
ckaVw/2TNH+hTQ07W84Y3tPF5k0zbD14oFrQFLs1ru8rjalujcY0xkF3oe9JaVOSjxEXgeiTbHMX
8HnhkMwMK321OLPK/5Du0gLlBht/0vkI6rOaG9IzlYm8WcnB+87Rd0Fj9wcgagcUkRPYTsLGA0GJ
YaH7gMRRifOo7Uxro4/NsUAjjMrmM4fS6tjxMQVbhWTVXb7WLX+lKRafO9/vflvxAu36JIwibxgw
0ULB