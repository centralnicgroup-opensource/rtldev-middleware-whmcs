<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw4R8ZOS+fOvsQYt5TYngXJz18PQUNN2J+kKyYoeIN2mWH5dOGfcqUx/IjZm176HkQ/BLLR5
adk1xxUiXJEh1vDbdy98TlDQygc9WK6gYpR+kclrvU5LE4WgIYMCm26E0Xm4ktS/7M9xvVO7ZlNm
NOpPz40PMNnYhywxTWpqdv8W+BRFr3t+2spoeIL7bA06tKgk9GlwESpZcxlB6o8Fok+XqkoQx26j
8hVJ5mEE088ZCkAR+A8cBTmmLoGK3hll9gQ823cUmGR5TtnuCaEknTiC+jsGQ+eGTwQTdsyAgBRF
rqde4F+Fv3d8e53YItz/zH4V87Sj/h9YmBeLhp8XSmjtkzXNwkJPWbUhoQ4RSDgvqJjcQm+YKIpo
28iCjB3IoRdgZrXZthWM9EXEnlfjR3+mC1yu+CMBsQY6UyWpgevUpNqZWepgKd8DnjDTicJWnGxJ
5E8Bp1uvoS5c4/vJL4E24akZo0WRL+aWsVduZhmIrpl10gBJPSvyX7cJt0IZnfZfUdKkFWgiyz7Q
/zGwIiWh+HMP/oqiMDedMcAuv3k5QoY4MO8wN8Qz1p3IUDzLSN6uVGaJ++pAvZ4Xm121V3G2VOfu
skOhL7bhUUEMjFlov5gobWVRQ517kvBBoK14l3Yc8u582Iu8Lqa2FLrQc8YH70IommgEd8vky4eE
ysK0AR6Q3DC8R6wsLV7o3iyJLbFu6Sn54RkfyrtmPH6UI1CiMpAXqrdSeLbe5DGcfAriFWkYxVl9
hG5em2UZvC+AP+s99HzJYaXS+QgeQa09aQkVgEFThC23h/tlELxFW6Y4zFp1oaBHnPsl6SWOxzQP
YNESUCtylYWCMugdQ9bvGX+r1n8+Q/UfrO0jFjNqBQwtXFAP/6nHvNXHnPWesJIFSeq7Rly1Tly+
Ysvp48jjnZLC2wX12mLB2sycyiJOWknslCd2NPyHqycDYdf9+MJGrB//AVlvDWkXUqRjKmlRjGU5
9z9ahrjfNuKjoJijHO3tgw29gDAOAypw3Jvp9b7SNugzZNkNBD2lU8/7AzNgBeKpLWNsL6Rr1lZp
c/iWp3JACSBI9GYhnevbnEeuCNoQhyy8EYr069aWzm0qDK+DdFKIUsQs6dyKlJIxfL1YV6UsZNL9
0ps8k4oXNahrfnginjZop2kYRWyCqwsghMZcs76BX5Ps+nOGA1m+WslJERtHw8m8MCsgwtRpXGng
2rlUvstReMh4A+kXpVPYpM/nfVGsWHDqRg88DmSMR7Wg+GoX+sn8E/Hod2LfQ7Al6STh0J+G11jT
N9T3BzQVXDDDUZjxMW5twM/ZM67iLJcFzLUJM4ICIuh4i8G9ge0520HWGSWp5WzconWvopSj2Cpl
dmjcE6EMVJ/lAbZHleq1mrRU/o5lAaK/EQdFh1+u9hn3QTaFuXdd5zsPoRF9v9bO0l3vdcVQ8+G+
Vs2BMZUWcbSqkSU5qSAaja/jx90duxpRcO4iOheQogLmlC1VJfHWzqWWClYwdCMAW3vnQpED3eZ5
iYuqpK+CvA4aMTBSGVGZbc528b/R/uGaNLz4gJDLcLs3HAl2fb+gSxLtoOrkyS5OhsMmWX9lX7JX
u+M00UbAvMoEIJ7+6y/QEf+7VJdfDSChSwywfMwG3eqBovIiqHN8KoFqUQcPIcjZdoPPNIOBgw/s
SbIzvniKqyoKFlhLShNYAxUPxY4WpAUnkVvL5h5P+zFQ38Y9xR/EhOAbnnGKtxJ+ob104u5hk0GC
vx27Xa0i4+PBn0pZ66i4Wi93uQdfdprHhjEGFb5ZuX2b4DT+P4gIxnXQJw2t3TfoQBcIVrKPoevw
DjmfZ4/epZtuaGrGqYDW9IQVAOSbRhpQ3p9dabYpQ7S2oiJofx4uq/LQeR5fkT+RQ8fQijsI++aO
rQtPSwCNq4SoA/9d8HXIwj6tYUAgEu719Pn0BrXxeDm22oE57b49pgJiazKXpQMCfDvUe/3Q782u
FZATpFiFCdePMpRhTicr2s2SbW4oGhCww2azMqzR3UAUMK2DVmRxFPldWfR227d8fDsMecpEQboG
UFa13atcMzwRyNzfEagnjWczlZxvoa0Ze4ePvjPX8ewAM8o4V4Ih71/ygh4FgbUxyRMtq+o/6huY
MbsDYJ/OCs0UxYW3Gugq6fEK2ZgzozSi1HBJ/sKnrBOvohGEZtYLUYxCWosm4S25Apw5tzkbIPwi
IEgyDLWmZdLs1Qma0W6PygM+bYurvF3OTC+P31yDWw+31Hz31s4wuWLQdMmIATxLmpIeyygr1vDM
GZJPqmmIfglgytdUa8Ndj5qxLbOx9NPDXbjZdZOoEdgCyHWJFgSz6RPok8QAgy2G7xv9IbMZ7wrv
/9TI