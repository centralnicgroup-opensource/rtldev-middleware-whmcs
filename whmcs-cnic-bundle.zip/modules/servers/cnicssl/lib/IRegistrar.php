<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsJFjQHB5WwB4dmWX/WrhUC1jhg0/fu0FyEL1eHNchoC2T/Ij8pkEaXnI20Pbef7gxe9DYdf
hw14Y3B7b+aa/i9g906aTtRfj1h1kIenLaBe82C62qcUNIuRTude87YeR7aaAii1zacPsVNg2fQT
88q9N8ExvbDmcxVoRO+TON6lzMfKwBb1MMLH6CAk8g60DAM2LlhFZ+obxdzy3kryfU76gmp+Lz43
cl8uzlEU5hlr3SoOuPpMxuHrzD+f+MI259jlwwl6tuUd3kJcOoFmA/ikA/6+QMwI8xnm0hDojywp
JnARHtB/dlJqZCgJj90dtDbxV7aEhg9O1zFYpPfiHohNlW8luPoJrmofoWqeXQAzVW1DjlGnOmGM
P5yboq7dSmcNy+dNNlAes23k/dBZtW3Ik9IjMiFyvsYySPEjULGAf2XD6AfSQy2BDBonII5/v8ac
TOFekBPx7WhKSe05oJjBe5AmzDHDf5dH6Hw85jlQhiA2gpAOCw3YjN0g9MqdknQkCuziHzpi+H40
VQgg/5RfLiBM/+EsR02v3Hoxu6Qy5Pr0LVUjJ6xx603gWMZCIfavs9Smz4ClDfifVNq0R53xr1dC
1q8LLYq1UXJyofXaNRaiJh/P54IBzNUZJ9/qmFOSFlCYJ/+alB5qnPZfwpfDOIFR9HJn06zKBq/5
RB1I4b6pWjjfEV7DHReCMIe6PvOEtiiOv3/ujvulgTWjo3MsUdYiKuDn9jmgkFSg/96y1hMXUG3J
cCW6YXH2sCH6AN6QdY6VJnHsgDIWhSBd79WsATNu2eOs+xA6tT9tpwEzu5tw8vLnzs2c/bi7/1T+
9CHmEEO9wmNTA3+Ke/bQv4uVP57syHE+iX0x7rDGx41amTNsQs6jc9AV0hgKjciwMjI8fhVfBC8L
EARD/GQxM3G/D3++ZvEoaiBbHLZGPH4z1OBNA9iwa4kJPQnnUoCricBoUGJkerSdDuxLJxTNt/00
o8pj8QSa/pk+AU8N2QJSTYkJPBZgvxmYic3Nj2rXjehfwp9KCK7VfbffzEiQlECDuKkavOWPww17
YgYrPah/fwsx734vt9s/zBWBsN9AuARWS9a3H+gZ8sFhHa+v9E7XD6bJiHtf64MkXRsZOxMbOFBq
SW262z+XW/QOrINslP5g7nf42ia0E9MTcqpDNC3jEhLr4CtLXBsgmL4iAX+815/BepjfLT+zDbxv
WtQ2pY6MGF1wdo34woL3qHeBtvoVkQiJwZHR47z3XW2bejNa14l5Nd7BlELROHKpQJ/ZssdNGc/e
zgSRKSxLIAG35vQ7kMEPwQZoGMEGmFLNfd+9ZdaAOURDjWUHRu0RCEvxdblOIXZnxYDJglTozety
dcZchjds06en8uhnENgtICcTFXdub7qBXEZhZME787oakqJaZB7VrpZrvBfYTBRyTJvOyqogz1pS
6spLCwIujFOdhSyO4ytkAbT6NHmUGxc9sSap/ighoHoFPBmgusk/SZ6Z8zVjV24oD59w0Asl5J9M
fkbKqS1626Idj8S37sqEtsQGzIBjFOp4VqeMytsIiMhPvpXkMZlAFVJWoPN67S9LwpvUbzw31W0l
H/O3qntZSYDlZAaoTXiwkv6D2gKK7DQbrJ8YVpEx+rFrIo5aQ2a/wKNzySkVhOqRrz7smxy3uIK4
QTVsWO97pTH/NElVxbNM6Xl1OOoDVRPahHOaS9Ajh1Cn2vNglyIsAbAq0/RebJSSW0tfj4XIjwDN
euQ+jtcGQB/uL3zFBYZmYeytZ9UGmgWN4JcdaoSwulJTJVtzoRg/HjywxhCoOa9FG9ZClOjg5tSv
nONLV1y0d9wndXUXI2FJWMNOUxCSBrhBKW6U6yIzd8tCMwrIRIsfTIuedWehycmoeo+F7J3iKx35
iH8SWOOb0vxm1w69RO0zaGVa+r/MBL6jLLFsfFM/gpvmi5t3LSQnDcvUllVUBRdJdw8q3mpbMxPr
V7BLlUCMt+zmBd77rzjeIJ5udDH/4w25MoMteZ1rqvxpW3QGqhZs9DavyWOSo4DsS9WW5hMlMpJx
b8fkPAIWf0ZxymMqDfgtfIieZcHw1RnxiyLImAO2TveEG30u//Pgtb6FXnk1kBg0jpaDrXje6lj9
YtsW3EAZWVwkNxhg8TQtNxJm9tNZ87sC0F7Wn24nh2lt6WhtaQAehz7KuDBjANI8r5fKEB5y0Jyw
jK8JZ1Tu3zectSTv3mxMgcFK45dVXBDmw96hXVLR2pPljybbYFZ4/C5kurVDwo1R48yjyX93EHGe
EQxI0pVp9ss6HHq7r1Fva7rO4U48W20rpIzh6DCKdl3oJ9usVxT3/thJOSqItVfpm/lbOiKK8Wfq
eSaEcn4=