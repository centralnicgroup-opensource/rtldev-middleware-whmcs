<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnl7H4zjBhrWQ7JHR6v3fpHvyYbzAtipYPAuPa5LunTHwHUG0Pqf6QFP5BM/+RV1M8sb6ubQ
TvBpgmRmgyJiDfQNTzThvkv0qUUrYg2JubjDClV8nh4AOpfoQ5i9wdDxDz7AUUXQwqobBzi5hswn
iIeg0SOisWNH0PVDMSGB1RlqKHwZrN/k1Ted4lu5ZTokA9sKUtkVkTofZ/7uemrGOt/VYqdmutsN
yBmxQv08H/V3fTO0sPglNRw/2DnC6le0Md1aQM4BibGvDFIXHeienCM7UbvhGCGAwz9JINLW2Kw7
ggTv/sVq8eGXa378Ki+UOtGlZDeGGXqWaqsyj71xG4OnjmFSIYrHNMZwUa2AgO8HmtfTvQttVKxi
Fk6Pq41khExjMZ51QVjF+Ei1hW29hfEJSzHrAYYtHVkwHI4u6IS3MesfDQdCdkeSTWpHyQYcA5zM
W8btvPwbE+fteCSiM9Ur4C9T4VyihWT2rQ6s7173WTbkT/xVeM7YAuKB9WFTTl6iY7adJ89Dq2Xl
McPmShFvh383HytWYQxfgOz4Lovm40zDd0O5qYDtwlmohnFHTH1sGQS4jnCLXfTyvJA/6O5MaSdw
zWBlrZAFxcJeHhN7C0KRyysvUy+ISPGdle/U3TuA557eBiuesGVJeLBdM26nyAn7q7NRCRceOdvD
lhfW3MftpG1yWiifMC6rCOCS8oZzo71QI+AJUNaoyfdUdU69V5hIUScmB+I4k/bvSbtNydejoAWd
GWhpVm0ZIR5zo5t6YA1CjYzd5B3wl0ycvntdYPaZ5iJOAXLGytpl2ELrQKeS5AOBGXqf65lyhYBg
nviHg3eNoIWt55qvaWGz/OMCwxhtGx4zkOljbj+kdFolNDAxCN2/953X+yutcUvmSnqlakf9YxdF
DbxscDKb358u04+FoH+ax6RUEXA7d71MF+9h2TlEywDKp9PxIf6z7HO7G0wpzYYvhUQ/H9ZLcFF9
0JToXwotQ6FaKIHA8PALMQdXZiS6T4saSknQEqFWpnsC/uyx2+2Gt1eIdhmnzeB50xEoo57TIAXw
I6qF8oH+11bxT6f68Ami+1FXbMkl/+sEAv+Sh6YSLRwMETM47r1j510JNN78v38c2SM88XqCxgtu
u7tQesRhDmuxdVyl7BjC3qD5oqs/U6Yr0ndSowc+/p8aQxE5nacPf4AFUq1n/8KW7Nam+QtqRbkP
MPOfuZsZ2EW2u+cB7oIGUi82OQ6J0uNqojgU6XgZ/x/Pk7lQyziclyz37K6n1qJ+xClvcAKdS1lE
/z02cGlj57dtVCD9szuH5ETaeQzlxodgX+504sIskx/7sYD9Pnwx8L2C29LI+QcRsFNecY+u7kiH
m3NxiqpIKjWq8IzoR6r8+WVu2W9aeY1MSSZ6cbSaJyooO7QG0+SSRjubSEeTakM+5JdG+6q0a1k2
3bnz7v1YcnXBwqdvcGbdlblZ9Nv3D//wogKgLZkRdFwmDYuG0LS+6o572QL+QNKMsrAD8PsTDRFo
caLlmWBSiCp9PMo/uY+moK3NTd0Fm4NOxy5CvnD+tgH5qZwvXYAe5Maaea9gxuJnGWnukOEujBIx
MK86/X4aKgTMiVhlSjSe2OjvZp3hrIhzeN4bqME5MPi6hfGAFUxO9Z7ijcvOvnpdNqENE2DiqVYY
K3kIWvWSAsfQk99SH0MP0Nl5RL455X/ftZIHDGC7DgdGHosfXeElOV5qkWGbqH6gaDGFvsu7ZC83
W286mSlGsv2KV7/SxFXML82GbhR2QFbQQzWJfGLLk71LV5lm8zJiS1Fi3nmgoYRF2F+Hjddyrt9t
eYEMbXTQ9TcevY0Sdpgnqha/WW/gLUE3yuFg4ztFNVCGd/AiMCLq/B0VXn7mL9KPKU36YtOK8vvj
L8+Ry2tDmGjBPJq6CFDhqtWqtWmddId3rR5z2pkJ4Sw776tsbA5mZn0LMXa/d7JkA05w3ECB6GcD
/vmPdZhICfZeq6+VU0mqiwZ0/UmoK4PVlULZb3An3+ZYNFdUp1jT4zA92Bb0R98Y6igW9k0LV+hQ
brEJr3edKECrJAqfNFYdkxD1s92LPOjdY482dMwTlUKCxpjrk6QZYWxrUvMBk8Ql7EGvnBqK7Owc
oYcYcVImQBIvm3wAHs/90N4/siJ82G6dxw11hDNoTmzKF/CalCBPOegrvbK6gQ2AmwEIm2TNIIL8
alHuAWEYwvAnu97DAwhDtRM24hSsuTWrWfNOlWTdxSLKBDPbcgmm3jbL8s/7kuJB+YORXrA694lh
nO7c390Fu5TLOJ0pmqWm6tojhbs1lYg6k2c+Bw4K0vP7+AjWm0HKnDkIphunm4qC6LY7jylRnfv+
gMUK6hkXQ/nR1G==