<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyMkxCBISTNrgnrvuOX7eu1KyCqF/+ednBYuFnCCHNh7t4+GaNS0QpuM7SdEqUI8DWRJt9Ee
E7tcS0aWBwoW4ONbl5KvzsZW/sJPEIa+6OLEFOEfVq2ie4wtrKSDBpHeB9kbdfPDQ2FQlhibXQlU
qJjoPdO8xUTa4A3lvTvXtlc5mUXvWrm5Oy1+68ZDyzRbwgn53x1vakfmNzlPVMwtMxGfMBqgitaU
zQ2u+3NXhkTcGg2v1HYMR+PvR6asMUYM6XPrIdtbqdmqCchhCinmfHNvkfDk7CIbtMF0iFZGOGVX
toSjgpHOmUmlVtvBeVc8uQjXIZJCMjlD5LOFeRKD18lKrHOwO/z1ll0le3SRiqfdYcZdPjdwMCD1
xG1kwiFRYWhOBOu9nYUwFSL37BABvMkVpy9JXFMhxAjjoT2NtGkwydOOkZOgt8yTn/+aN0+3SWjL
MYusCv1Olv5Zcc92dkC6I03gZ2sxEBtVATu7ZWm8btDI2yvxb6dTr9xOuGoc/+uqsH1/MXFIjyQI
cmS2CesdUbDtV3Y6ELgh64xb9gaVCYGvnwzzHsRcpTPMBMbvDe6X1c6YltvfqpdZr3HcO9xKiWMs
PUQ/2VgLRWLleqCgjZXHCZcw9iVBzo5r6winvroXqN3l/n5fGV7e9tvLa5guXK85wOL4XFS5TRaO
HldKdd1ms+ADUMtMQvB0mIpriI/2YDAtrUdiYfsm9aUqdqW1BTOV+/R7aVYNfOm73F2B+yF1D2Vg
xUNwVhgzsQ6vVAVVrMnen/w6pzgOb8+GwA3zaUjnbRtxl08Hup9g2nPO+yuAqFZGC+IA8TNy8CCt
E/A5/BZqFoFwyWuJ+8t6iOJK5iVXeU7+YB+lNUTYlXMDQz9ZLPK0vPxm5WD+pyUAKHOBHVLLsY/i
XmKhJyCTgXuBMB1zuCt3bDSBE+C8pq903ywKT9ZhflkaFNbHpV0RZRJMz12/f4sig4UyI8+gypu/
9ALAH4bvqgueRlyovjLYUZUcyTaOTmYD5m2gKnPibnmeH1IxvN4ijEgw/ORhBR87TvLVUTjVn5ZW
HwElJP3CXDhUabx39hMJA5CYuU33Tok2xwiRXsoI2WPLEeN7qlTVlKd0WeNs1aDhjEb0zg9lX2OY
lLlZVuszeH4ojygZRV283fLqf7AqpoeS8Q372/3YEwZxicBDc5MJzVGc2Z7DYxGGiTIKDYD8BNJY
hFcwoymWontExjKgrrxZnME3XP4FkXI1akLyhgeVcsjM+kGVQHuKp81Dkpdd8YSQYxwIc/7XKNaC
BIZYzP/lVhTDfuIpLNTOjW4Wj7vT8zUOjd+c94fQuz3Lt+ei8j4IVQnvOqyrme8WXFIkRApLweCP
nF7g4/HMsxgrAVtUdKkzki5pnFgizEOdGWfC8miaZPA6hXb7qPV9k9nFcBnzJ/tlAuWFOULkGgAR
sW+PIujAmIf2ElJE9LJKME5dlCvWQH29PtflmbjCC7RX5iGjAjEwvYZ1z2YKtHoEqi7KacGgWHg0
eYWMuxeITbTBUAtCbYjIn5oWHzLZbMz//o3RhcbTqiePQWtKsOK1owIQ0MqWatf11ph/21hRILMc
PcKFnK+b0gXEGnLHBf34uKSA3G4U8xdPzyoggWXbCvHG5DekMAWMNK/sWCoRyuEKNCjZt+W8Uzj3
FX/EPlL99xnT0k/pu74DEXGNSL2GGtjYkBuWgv6fDm7Gbz1DSQAsQ4hOCVCO+E2rByYh61m4GSC1
iohE79vLjbloDamLL+ELTzhnoE9wGtYOCROf4u5RUEmsFVuWwJP0+HOR7cZ6Sl+eZzvm7BUKuK12
OuCUwNJvX68MPzW5LHKgAxS3uFxv3xd78PG0D6mdxn8Bq/8aZLWGVVzmVqraBVC8hU5u8v+MBq/b
dFCOmpYGSj+eeli0kW3V1an7GXvHPT4KCfjjW2Wi1iVLBDZbmtRGiJGE7+aUIxRGENno5qh3y//M
0RdXX8Qa/sI3zz2T2qmgqLs1QY/fUNa8y9tA/p+jObvHBokBnvVtxp0s/bM1Zb8RL4rAEMp5EMqw
MlSOfzkD1mmFbexA3kRFjrR4fOrPPa/CRCysAEJnNon5fo/6I5RPUUXRPUqctIkWxegs6hjvbb7o
NkdJBk3Z4WgJWN1YK+4IXDDybprq3Zkpgjbvy0rPRJDhXX1pKYfJ6IFucAoN/s6P0t8UYbJVW8d3
Kf0QGR7VAR0lvOe3e8SP4ZdbSG6r4XwYakrMNeOOfQhGKPjDYLcpSPEw0/0Uep3NUfuGhculnjxP
Za0VhmISpe4XAELyNbycen+neAPqJWk1dh5QwphB6rGciHc+mj/DbqaniFzA+njeKeLLhIZXA3qQ
I+V0Wzq5zjk+hWnd7W==