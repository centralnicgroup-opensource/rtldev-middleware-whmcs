<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyYXaoxVZ6W1fX863Q2n6CGGLMKQiTNRN/TrMNFyglFkjIfwV/bsSHFEvAdxbZwqw7Du1/YJ
6du6U6jtVB2G/wF+P9yNkVfxgy2yKQ8tb1zQsEZpoi2rIN1IbyJ7oe6G4+DowXDY1GgW6m4Q/6IA
2mNItVPyB+56QJlgP+1z9qwbS9bmFcY+BxuMoyv+mm2jj48dZEiQ9m0d2FPhAFPdiYyfFl1rQ5hz
TRArhYETHo2+ev6uRiXK/IDLwkq8Jc3SdcBrerZwRhmuno3jWo8BgGYcap9XQuT1jF1byVowpMTA
8Med3d5mLs1vGCfMystmK7Mp+Z5IFpjjruUjUnKE6ZsoWKWfqxefJGCPWCBpcnQXEgWEG9QgYvJL
7UacBG9olWfwE3wffktP++Un8SFWqleSLQ2WgYTX7YiKXeVB7MZWevj+a7pOqeLKPmmidIFck6Tt
tn+p+ev1P7XrEJ+IAxhWEn2F4pPWGrzU1qwKieDN5IQYZZAae7J2mT+Ej5mY/4HtmHeb22lkOLaj
O7MnY2hKgbuwLB8UdCVbEF7RNN/NkBPwIaRxZWm9iskMCX5RLkIG/e4SJN/exjtabYdRFL2nvWVQ
VNyoUSW1Cpbdb04DR164+p0KSQt/KSmStWyEDKg3iQRHeBHN3JSHH9+HpvfqoBVTb2NRNxlnGAD0
UfzGssduOV8iW+ZFdDRVcP/Eo5ldXTho3yjAlYiuJkMJaWT+YIrhq9INFNr/U2YGLoElaULYgyqo
p+2888BU7COm5SykJ6PUL5fxSyUJ1IEBPeqslp0ISuqNtjTMU1O25BCELdRDWpDQoFxGTnLDqTtw
4LC711ubV0P+yLjd1/wtIXEGCoTdPNhivJsDM0WvZ6JDW7vC9dHETN5f+eP+tKN0ElTNG+GTJFcq
QF7RoqRorRg0XihOlU1tuYttzVgIfT+RdTVJVbwSaW3Gk+2BrbrIC4aV9JK2Gr2xvt6SUUZpXO8O
10uAxQeQ6sql3SUYkYLRZcCC01rFUq0WRnPNn8Y3WvvA6RNhS6ekoKXnwp8RwVYaXJx/U0P7xI3w
EVkAlXMQkcyHXV/PK1nE5nxdgHUMe9pCQJXG5NyI2ojYD+qMD0vkcJLDDE0HOj5IUgmqM6lCcf6q
1nWkCfD3+P9ecIPiBtrJt2WwWPO4X9bV4W0smgcj2DiMaBRvnUMcGjw2maFmVo5buqlO7XfwGGog
mp5uxOoij24nsa8cStUNosXhqVIHSoyz93R+ED5ADtLFIcMj7miEvxR6qqWtUfMJ63t7Dck19ePP
MLdTmczTpq1z0UnIQgw8a0OzCgRS2bJh851YHGZilet79IGZOgYihf4dp+cKXeIm7LN5bQYvKl/F
jAGv8jyvtV+qZ+zbAUHkRg9DHgfNyet5B90x3IYwvY6zV1mhkDQ3EGCXqND/vieZG4ntOdwac5gu
/wvdPbF3JZN303O1RC1l1mQBaPonpFu8cP7K6H5bCkZfxqpBfIH8aO/vKykRJA5lQFFty0lobpMV
6ZwZ6eFEbWNVmRlYgRr16G4uWuCPPpsKcTbAICCm7C/RlOV+hHRv0sTuA6gjbRPT5JAeENfLyddz
Tbcb5Lj/pm3BDYtm/F7l3B6nMwJPflVxaeMgZD4mhIHW8AugawyWM9VZCn3ArPTvZb86XJx6vSC9
nNFP5fjT0sCdkTLj835LMjCmuQTXPAUBPRfygBjTIGOhFoWq70iwHVoYm6oyMTqM7nemxHkj+dN9
a8fBPfxOvV2jChSUQMP6SyaxJ6Xta0csJMDlQYfMmG6R0T3OItmONuShmqBFdZQrdJk9S5NSX/Tt
8IWtzr3GMB8zycWqghFUjPHuvgbJ1fg02SsvTT9fMJjLGuMUXp9aIg+93ITC+tTKC0vZBZUa/Rhg
/KjIXpfQJgzJyAtpQbzIFbVO73vD52OZ09niJI2ASAJs+FlUIV6J/8yLiBC/40kD7kUJssBr7Vyq
znnaOet45pMljsDtnMMzs0x30Dxc/u68ECyR2U5W25cSu8oo9Pbpbrziik6CvMuVDxzu3IbApv1l
b3q/9MZcwbBEs0gWnudWKTwudEd02f/J2+19/tTIMF6FuOgsEgP6Yh4Za+xEKCAvqqdurAf4ssCl
UoqCIQtgxTGpwvbfQ1CTL665fdnhobTJFOvcD9GNKioSz4xZwsbsMZZ7ppWQehyb4qXkpDzCugTL
c4oiicRmurlmCQH8GQGa3WunQ0oMsfQ17yXdrZNhZZJDiL4TdYX4lc6zRkER7v7g0OF4SZt/PtO3
QTKNaiAsiaTQbfxPEvPizoCXstOwgHTcmJieVj50bmG9eBQOJLp4SIboFhxKqheb/iotiMssjw7M
9B+SERYxuY6kj+xR1W==