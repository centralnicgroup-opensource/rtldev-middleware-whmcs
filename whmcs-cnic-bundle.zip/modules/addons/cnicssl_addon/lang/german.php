<?php

// CNIC SSL Addon Language File - German

$_ADDONLANG = [
    'roundAllCurrencies' => "Alle Währungen runden",
    'roundAllCurrenciesDescription' => "Umgerechnete Preise ebenfalls runden",
    'products' => "Produkte",
    'certificate' => "SSL-Zertifikat",
    'autoRegistration' => "Auto-Registrierung aktiviert",
    'productDescriptions' => "Produktbeschreibungen generieren",
    'productDescriptionsDescription' => "Mit Provider-Logos und Feature-Highlights",
    'productGroups' => "Produktgruppen generieren",
    'productGroupsDescription' => "Eine Produktgruppe pro Hersteller mit gemeinsamen Features",
    'setAutoRegistrarDescription' => "Automatische Registrierung bei Bezahlung",
    'base' => "Basis"
];
