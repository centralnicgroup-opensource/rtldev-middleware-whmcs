<?php

// ISPAPI SSL Addon Language File - English

$_ADDONLANG = [
    'roundAllCurrencies' => "Apply rounding to all currencies",
    'roundAllCurrenciesDescription' => "Also round the converted prices",
    'products' => "products",
    'certificate' => "SSL Certificate",
    'autoRegistration' => "Auto-registration enabled",
    'productDescriptions' => "Generate product descriptions",
    'productDescriptionsDescription' => "With provider logos and feature highlights",
    'productGroups' => "Generate product groups",
    'productGroupsDescription' => "One product group per vendor with common features"
];
