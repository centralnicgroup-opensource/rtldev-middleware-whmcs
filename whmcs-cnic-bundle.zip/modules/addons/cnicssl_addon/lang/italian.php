<?php

// CNIC SSL Addon Language File - Italian

$_ADDONLANG = [
    'roundAllCurrencies' => "Arrotonda tutte le valute",
    'roundAllCurrenciesDescription' => "Arrotonda i prezzi convertiti",
    'products' => "prodotti",
    'certificate' => "Certificato SSL",
    'autoRegistration' => "Registrazione automatica attivata",
    'productDescriptions' => "Genera descrizioni",
    'productDescriptionsDescription' => "Con logo dei provider e feature highlights",
    'productGroups' => "Genera gruppi prodotti",
    'productGroupsDescription' => "Un gruppo per ogni marca, con features comuni",
    'setAutoRegistrarDescription' => "Acquisto automatico a pagamento effettuato",
    'base' => "Base"
];
