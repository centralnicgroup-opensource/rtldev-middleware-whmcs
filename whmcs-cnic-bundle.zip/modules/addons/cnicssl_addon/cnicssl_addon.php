<?php

/**
 * CentralNic SSL Addon for WHMCS
 *
 * SSL Certificates Registration using WHMCS & HEXONET or CNR
 *
 * For more information, please refer to the online documentation.
 * @see https://centralnicgroup-public.github.io/rtldev-middleware-documentation/docs/cnic/whmcs/whmcs-ssl/
 * @noinspection PhpUnused
 */

use CNIC\WHMCS\SSL\APIHelper;
use CNIC\WHMCS\SSL\DBHelper;
use CNIC\WHMCS\SSL\SSLHelper;

require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]));

/**
 * Configuration of the addon module.
 * @return array<string, mixed>
 */
function cnicssl_addon_config(): array
{
    return [
        "name" => "CNIC SSL",
        "description" => "Quickly add and configure SSL Certificates",
        "author" => cnic_getLogoHTML(),
        "language" => "english",
        "version" => CNIC_VERSION,
        "fields" => [
            "registrar" => [
                "FriendlyName" => "Registrar",
                "Type" => "radio",
                "Options" => "ISPAPI,CNIC",
                "Default" => "ISPAPI",
                "Description" => "Please note, the corresponding registrar module must be installed!"
            ],
        ]
    ];
}

/**
 * This function will be called with the activation of the add-on module.
 * @return array<string, string>
 */
function cnicssl_addon_activate(): array
{
    DBHelper::migrateCertificateClasses();
    APIHelper::migrateCertificates();
    return ['status' => 'success', 'description' => 'Installed'];
}

/**
 * This function will be called with the deactivation of the add-on module.
 * @return array<string, string>
 */
function cnicssl_addon_deactivate(): array
{
    return ['status' => 'success', 'description' => 'Uninstalled'];
}

/**
 * This function will be called when upgrading the add-on module.
 * @param array<string, mixed> $vars
 * @return void
 */
function cnicssl_addon_upgrade($vars)
{
    DBHelper::processUpgradeSteps($vars['version']);
}

/**
 * Module interface functionality
 * @param array<string, mixed> $vars
 */
function cnicssl_addon_output(array $vars): void
{
    global $templates_compiledir;

    $registrarid = strtolower($vars["registrar"]);
    $label = "ISPAPI";
    $class = "\WHMCS\Module\Registrar\Ispapi\Ispapi";
    $productregistrarid = "ISPAPI";
    if ($registrarid !== "ispapi") {
        $registrarid = "cnic";
        $productregistrarid = "CNIC";
        $label = "CentralNic Reseller";
        $class = "\WHMCS\Module\Registrar\CNIC\APIClient";
    }

    $registrar = new \WHMCS\Module\Registrar();
    if (
        !$registrar->load($registrarid)
        || !$registrar->isActivated()
    ) {
        // unable to load the registrar module
        echo "The " . $label . " Registrar Module is missing or not activated.";
        return;
    }

    if (!class_exists($class)) {
        echo "Class not found ${class}.";
        return;
    }

    $smarty = new \WHMCS\Smarty();
    $smarty->setCompileDir($templates_compiledir);
    $smarty->setCaching(Smarty::CACHING_OFF);
    $smarty->assign('lang', $vars['_lang']);

    try {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (@$_POST['ProductGroups']) {
                SSLHelper::importProductGroups();
            }
            $countImported = SSLHelper::importProducts($productregistrarid);
            $smarty->assign('success', $countImported . ' products have been imported');
        }
        $smarty->assign('logo', cnic_getLogoHTML()); // extends layout.tpl
        $smarty->assign('products', APIHelper::getProducts($productregistrarid));
        $smarty->assign('currency', DBHelper::getDefaultCurrency()->code);
    } catch (Exception $ex) {
        $smarty->assign('error', $ex->getMessage());
    }

    try {
        $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "cnicssl_addon"));
        $smarty->display("import.tpl");
    } catch (Exception $e) {
        echo "ERROR - Unable to render template: {$e->getMessage()}";
    }
}
