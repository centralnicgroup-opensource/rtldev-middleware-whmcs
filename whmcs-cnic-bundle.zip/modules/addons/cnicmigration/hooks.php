<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzoi/A39ESMNb6LfWt9N9lHCfkSU09v9WfkuV5c8cNMF6BPrPPW2NloL3S6CoZJQYPDkhjxH
lgdo977XVD16PLZ8dym4tjO/zlwDV5/ByROpHY0Dw4CFwYcSqpaM1NX+o3lSenwNcv9DCiw4yMkF
IHqv+ZIi6jPvE2KO55vlL6fZrSZVXxFjvXTfWIL85xeZ6U6216ak2uEnaSNkv4QFIcMZK83ng3hV
EyzuPhEsjzJHg6W+UIrXQc9qtjy8ZqEvWUY4u08rschs7159idl4hwtDlxvh6ySEP0F5vWfEUzS7
5AWdpGU9giIDhd5Tit5qXYVnVGcl/9TxXMZTrdp95L3+q7z2oAgWXBRie+GPs1Dchykv6yWNzvK1
lK4AEXmXn82H6bI/YvUA6BafMCtC9yck9P3RSL8/NEhcTnZkF+PA5ePn4WZEJl23ZOFgaiB75F4v
gpbv3sHjznmb5ZSbpjn4EDNhqfEb1Krqo6a8wsEB2NPKYIm5Yy4G0jIQ2CTiJI9csVHLGLJyA71D
YApSrkQT1G11z/b2S4ZzrX+3JxdnQeVAI5eoUh4LC7RyFh/zs3I7d1a17PdrLYy99aAnH89f45be
+DhY+0EpT1gtClWPgPyALOY9WZjorbVE+RQ3e4/1X32QlLmrKmh/4v1AkSb33w+Jr0Zf2zPIa5r+
Wuyum766eiA51A4Iw+wwh59tQh/as6kpybU1jk54KgOw8v6xBE0kpRfsHUkenDuW1RXV0eEnX6hc
eUXi6fxfjnyqXIeiyYeNXAhHo8p0yfIE4gw1UtaW5epMUEweRMJchgQTmhXta7qs+hycv3H7qG/C
SzVT2thK5mP68yyvuA3wauXZDvT7u9XZezVp/ulPrI4/ltNX4ka2WOOo81sVkeJnL5iz+tEnuIkS
WGc2LO2OR8BI942ajALsB7eP+md60nuYj3Ja/7JeF+ufMEPvD5bbMbBzVeWGdmXnjLzIq8qCJfJK
1olLbZR4Lct/9Fy26RXVB1K6tQNlPjGDjhKM0Bfh6rI2PCX6lJ5M35IReg0LgN0zN1n5hP6VbLGN
nAAeePTMLCVd503I3w6kyY1HEiCHA4a4f1Ls3hJAME/O8VDniPrMh5j32kHIfhvGbpxnRGTrhv58
10XsDohW3cBv0kl/JthZAcceoIWiHBGoD2kYhV54ccF5PzMRZCgxW9UUX6rT27EmH+L5hYdd8Uow
bis/YdfC7jY8BReVvS5zAheamqoQCPT67Ie2s3aYaC8ah5/RkVKw07QKGKfsbebySkb0La4K2+0H
wzLviIvwLY76OnkJtr7rjLENJKZ7PHlu6YP8wmyDmCcFeraHWVvP//iFo5rGP+M/HSGIVrILrHiz
rWnQXlAGgF/E9pXqpOXQ9MKnv2bJb5XrkqeYLpyS0jw8djglGw8jPLoNY47P++MLmekYnUrVJJGV
w/lNKiEBxnFQKERaZU36xT5yN8hU0FvlJH8Hoo/i0t6RK2pd5KsyUtF7E+ReG01UYcO5v5j3a/JC
sjIiwsBzS6d8g4Y0ObgIdSqj2R/DGzxTeMRGI4+E+y+E6Ck11iP0ZifzXfNXTa8JjKeMwscMOwG3
O/KdoXXGmjhkUPGZnyLLiD5hSROETXiJ2U3LZScC5GybQ5ol21k9aLhGzsVEH1850IRhuxCR0Xt7
QMNVDdhu5MJ6ap//Dbdv4qt7scQhs+gDLQoZPA8OTdzhDECLG+Uzxg5V/m5wkPmiZZz25BE6Szdj
h6ImGN4Kppw/emPJPmaRGy+vKjp+cJToO/8mAY/mojPJgDSo9Ty3Z7gIa76LvaziZjxzNFwbFwsV
Edxvg7QJa/ncDONgHmnZQRyrvf+EGn1A+EtBVs6ZG8MOFPFsd32xhllYTKe8jykk3najPRpYMt1D
QowGFKPhQUlU5DFRE6sT5MbHlWb8YyjFBt+78jiLqe8GnCHdAiN4M0TY10JkPMlNTTVRQY0WDVz8
MJwtdWy/GeWwISEckXwtk1MGEVU2IKewGjHLxpqwpGynUt9e3EStQtcdq/s1bPpD1hyiWcCPdGzE
npTZPHg7EmkaHtN31kTQOJksVF+X8vxgRG7qUATD231RqlDrM+Q1/mBS6s3r+ukO3HOkOjSNe/IB
JaOEScA0xe9KFSaNXMlwfibBL6kcgzLQKfxKJDt+opQVOGsoptvvW7t4kfuC8gubYvDBXHJmv/KF
E2WXQSlGI9cp56aV72cDa3svo5I/9H24xKOYFxN8XALD24xGVMG/GOijvTLvRqYEkZvnGk9sYxyz
Y5vunOaTiTbhJuAyThKqIl2L3PRidZkQLMLOUgfEIMEX39S+7jJhoO8QrrtfIsNcMxtxQaG7LHxz
75g7Ik3vqEaKq0oi+X9+zj0vzSD5cUCaVPPUM0umj/r+AuWHuG/JNqQrZk7f3GkN4hZbiu3DusH5
8K91ZoRbKaF7JNEq+uHLKJ9QT4qiN8Zi4zZbqL8f8iwSbWOSsdPwtcT5qARat0ZQBEuGEw2itoD0
7mG1ujhip0ZrHF3zp9Ad6Rh1UkUpU1WMehfjmVGLAZc/FHEySzKb4aQRymiIXReOs88p7SETYIFg
stHWZIEskKTOVcK+yAA2EnNYFO+57DJAJemkjT+rhgWi/5JaLpZhSR1LgTQtgk6kVaIPYjAUry1j
pVMOyW/tPcPEK3hf+awcRz6cDIK7O9oTjilLlDKp0pXB6PubV0WGQS98e+r6CYgGuL/5Z/6KkA/m
gbLtgsRljT7Df/sGnrEcVlxprp9Ujt7ZrTaEDOPDqG/g3otzqVv8O79cf1d9aQVmyTSjz+8weelQ
MaRGXY/12/QKqTGofDoU4R8/JVE4B/X9kzX43J3+BUY3VLmQfBsqopKffyQzP5DKQJrPTHJF3Yb8
MV4CPFYE4CMoPWng+AVDAQJswVUPYXHrAOgDrPzCnsEiOGq5NdaS8vZ7uWX/iv85ESuamrirJgWw
X+7L0bveifQjbOSDH5Iu9x0BNsAQDMgs114BhJMcbjEdJcFiYFlpvN9vSMkX1Imx3DxIDF2znTDa
7e4+uCUQg+heu4NnPMeWDdzyPCwEWdsOI/z+fQ6dWbZMxanJkotEnat8b+7LN8vCMYu0wG6TyKhu
ZULko59+qWgn2HqHafKeAsduK8DV9YgfdMpef2X/Zz3kI1KG5ZV+uykjJexUvXOLyETPYsuNCwh5
FgILvXVP1aLofycYo1X1MKna3Ubs02udSzJ8T1CvVaGarc+gy13c2x54T2i5JBjEI5QiGH5q1KTZ
WHdWuZhsEuAV6Z2FfOm/WgWp8FUOHqdLSQyMYKj015yWsoaeiWo+Upi7HO/bggSI3StYzTdZcpQZ
m/AEeEk+lty5plMUgsceLyY7BtssTG3Zmimof5gcYNX6ORzinmJjYAht0f3P93S3fg4V18KX/+Rx
Vr54h5xT13IEN0aLmhI91OTXvjGYiP1yjVWd3u6BS8iIyjwtaoYnrPlY24BSN95UlxzxOLJXU4Ax
nTdo4CxV+WGn9Gz8WvPlKtpvpACSLIJjcgzZFYz7OYUkI5o3zpjgadvSNahBESw/gwXikEj+C4+8
Sp5teqtRMc5DcDHKNGKlAdID/JJAHO1HGjYbMkg2Kt5ele1+0clzd1NiINx+fAVjZS483God3HQN
l2tMWM8k8FMhxO3wHBz8L06qi9qdQ9W6iusQWmjHUr0DE518hJAh+/IOdhfeaxSxx54r9nEFayrQ
W7p7QDm1snuwCOjhsYRSsNgTvTSpdLFd4GG4FM83UiHxNd+cmUBFY0jskuJnzMZ910CEyUoMynzJ
nhLyySWO5KZjwf5ttTPZ1lm3OTTQ6Byp5Z/K4rSkrm5fIL8P+qIJ2iN+c0d2zNFAt9mplTgvDgBM
pd+gi6msZGAAXD/GtoYO/dD6q8ab7ilXYvFG1mMzk7eXM1ASxMW6O2ifvZR20hE8dcbWEPZlBzKf
YILBXPSVshfwhhbcAkoILk9UMkagxWLJOPqwC5aJWMykvSxflgpO/RSZUY2cEGEeLQxspO1G3q23
tBhvYRVp0Rxr/qCMzb9904nEO14TyOOHFX9kdGuPASvR4NDtg3kO3dVFJnuw9af7rn9Mxw0tkm0z
VMcQktps0xwvRSGg94B6B4xdUIenSBUeZfHBccsKmuu5c2HWtHVAFjwfEQgiVhydGNgq5VWfRFeA
xvdtOzt+rQ33fR6iEMGrYR35XWA436RavHJeTDl+n+Ihxg5S5sxiSBah1Fs091xGcAmQgF8hGArt
XWpEEr/2mR+8PMBcn2ma+uumvt7dRRT95OvQzFe2Siqkn00IYGVIiHJCQzDQJs9o/y1KyXmMKGGR
5TMiowuD3ACLLZwLX2BOXW3ZC5dxMtyNhJZDWmn11T8ts6TNg57eLE4=