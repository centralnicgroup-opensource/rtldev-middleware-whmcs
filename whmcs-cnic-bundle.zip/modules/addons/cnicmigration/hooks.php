<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnRQKoHhZwWBSXF61y8HXo8O+IsSdiy2XiUoKqRddoQ2Jl2fx7xOFu+T4nTuL1GJzvpw1Fei
+sEhvU3cOAXAwAtDuKYqOgpwvjOzsHVZhHlRWz+reCKHeiLHF/ZUtfgeoZTsFbuf/pEvylXi93b2
EA06okf+o7kJjDq+gXHzDJ+FOVA8pGsPuqXk/fOVrPpC1kO9oNRJHn8mk7UJWmApN7+GnAhR96Q4
onXmY9SbJRPoL2jaqOvZGQ85XXxEJIalaKz245jjQx9jvyVm+wC5jTiNvpOBRBG+GXu4L//2TFyv
/PE7DaDGe+toinPrGCZIY6Ktalm/hg8JObIRq/J6OGppX20i0blPrvTG4WT36pFJ7H+OIqMjga9V
AOIJWQaSM3awEqBBk6V3bg1dkpw48tRbnSzpAbfnOs/+MamI9PwkqHvyo9DWjpzB9jFNoFZ1Vo/r
D7+XWwmpXOv4uVl9MW9L23q+hRFnofqkShdaTJNUU6QtI4c6bsgUDGHTWwRdd7Ekg3BPsrWgsAkx
cQCRZ0pO77UNhoKwI7s0iiGNb+UifOsy1qUtl/RE0aykOo58slE9oUdBdBmiSXUBxmVMwZSDzfpb
OuF79JEwrHmTTgUY+2Ad09WeuWd2tzdVpvidoIXdqiTrCKmefXKlSlk2p4f8AU8D/t8meoECfGdp
ONgCJJrQ1Gk5riemoDJ6deRzgGyU058+hzW0ZaGLG1vn59wo0wupHaV1ZtEgjXhtp8eGJOoQRN1K
ut4fBf3mcUWl0825ngtnzsLzgA18/BsILuRKKX0csdBD6wgXODp/hhJdRoCCQPJZAzF3Un2/V4IR
yeoHen8kePl3hEjJIq1zut3c7FOnua/XumITH4JOGG68h5jOMzdTyy2GAsvh6sTa+AFL4E/ALh79
Blgyc8Ztc95+uMWBN7YiZ25J2GEIsifXIah1gCOt81QUDdc4d2Fz0jMVxBtKkwUM6nZCgGvVuPuO
xAXDX3FrfKLRBssTfY8vBw0Ygnzoj2WBmkKVTb1G5AIpEilTCow4p8tpLgUf8dtpVj88pljNT9j4
stga2S+ISphaoCLzYgqGx+0vQOLr/d7bdm/1mjl6oPWOCTiN+HZaa7ymtMKmaODDXn/TJu7GHnY1
rRNuPwyfJFh+NsCVy6e3o2sKxsY572bj3F6tndOIbkSDxeM3Zqz4qDTfDT3PxHhY0e2PJEa6hesq
Es4sDwKAXqa87vHmL15D0t1lGEI4mPzFWR7ff1aCAkpk1mQW4EOnvO2k0a7hxbXn8E9Aw3bvAANY
Elve3I+v7RLZsy4EEpG/p5NHWg6acHM8x12k1XZQk0z2qIih6MAwM3ek2WQkZMVh5I+A/dDPIvFF
v87XWoTH7SHq+dDdKgQJPp8jCeXvEgd7h/9n5sX0o75r/yMZ+sahS29yuh2fZZefMUKGK9prgKpw
OkFZArccHYLbzzvIJVK9/M66QBWXRKs6f0chdbMJUs+UPKh1/5RRMyujVQrVbVhCwqf37bowKySg
XxjgyAUNawgstteO9r/BwFQ+XM2hQUljC/AvcRc/76hoC7alZYXcg0qOCOlV+6EhILg6XDqAHxJB
41g1GCiarmozsZ9PVI8AfO/hMMP/689jei6igOZUv5RwurL60TKZIWxyxXc3wuTSYN9cNjwX8Wws
Z3vDD1MbGu5Vh/lprCmLcHLx+IGQ/wWtP1aENuLbB29we1ure8KhgCWqruF50RKNSTdqOlFwqmcL
y36yS3HMQBPGDGNn75EW4vPU2QlXQvxoOnIhtMlH9fW+GnIMrwUDRTmxb9e7DNtIvVXukxm1A2nY
FPYVGuoTOoSvgtsBBcDmlIqlUabQGmM2uwz2tYxJYGX4j1o126nO4bwVAWzTKKO6G0tWGGhcFwft
uYASjwGJgoHV1dNEiYE+Soq4OSfe1jLYG43TnsNnYNg4ymEKiOOPOJfz1mCGT08NzmU57iqZSd1M
72zANjVwEB9MhUqFwCyzbHCRxa/grSitr4HfhI5K+Z2wBUB77pq2Wjpa92u98lQPnd5N00KoqV96
wprbM2udmSmMwejaeQgcoNJPR9bg9CUsdjaGs9qG5MDN0Vn8j5W7zDFrpnvsNhlzKYhMgnE6HEq7
/1PtO2yWPezZaRXfqNwEhdeoSvV3dozQaMi/9Nhm0hK4yWgWMimul6zh2ALOq4g0wHPc+UPU17Ij
qaAu3Y2B1JEVNM8R3USE9N2rTisXtZcHEDN2ccIsA8JwQEb0nsDUWb4iGu+82pttIwkZalqpH+yT
kHYjXBC7+4kThAn3cZsTK2eYDrJHCRPZPIt66DE7AWoZkqbWa6l2OaAjnCXhIud0iK+u7BwCvKiM
O9npJMZM7LsGSG0XfxwOjANRVK3qLOkjSGgRc42zjU66zvH12YnNC/2Q4BwPl8NcZ2ItWstkWTrl
tr60Tg7EkYhkSYFJ3pF9UXR7quyVDXnFK8emRJE8Q9Ns4/h2ffs/UNVKn8DaiNE/SFosrg581bg6
xQyF8QsMXVu5pD3LzyNj7ZIW0AaC+0sDT1sU45uGr13+X4A15X1hxclU70SZyBYioXiqVq4prN4l
euzGI7I7CuqUfNwiIKZG6ECi9en8h1epfp21Gz0BQqTraZui/CjrhPA9A5bQxu9nRGjLH/rX5Nyc
eJfCdxlhnbfRLYdWcthBZS5wRl9JJN1nG9lWixjbzqiqI8n2c4VqyWIkv+36xgGv9N4S8OybWInw
Wsc8E9MeRW8XUhLYTJXxX2RiVYxyPtP8tWwMV3TRwfE6iYuVfaeIdBerMHSVHwkxPrkjhW1vjAK/
vq2aBS+VYT9BJcd4aODSg+lU6/+mRRSrozMQDVquX20OgLEJkko3/Bhrq5xwkKmaChKDr37sAKsA
aH02rkq97tNKPdwnI8G0LGswzNc0NEbCA/OXW+fgjnOhuvkH8L6v88CJebm/VMgqOLjFTXKNt+Fo
E542TXrDxummU2QKQTjieuzSKq8UxWbJz13bq8dKwHYmdPwg+XN4/bNGosopWKNPz6+PLI4D5fB8
SfDRR/A1gMyedyQsm44JTY6jZ+NHba/XA60P7TaehAo1nnGo0M9e1EXjl49SIAfCr405FrZAJW20
mb5hTwC/TBlByzIhjEA2zVbTHpMRyQh/Sc/3SlAxeM34YANhq1g2bfg1ekYNr/2/WNVVawhaEFYQ
JwR3jmVEhyqChx/nI/b0kl4YNANiggtlgWuWAHtUKgM8XVkYxdgHNvtiYx/JZe240mGcANAHmdjD
2lDt1BZvnGbDEffDzYjA9OEgQX3ayWAexhlhZsqs5WAlWZVO09G6Te2Jh2A7R7WTR59i2PVXpWno
kUb6LKDHZ07NdFhsoSORuJVB6VURuoC/cBZVIeEAhih8Ky63G+zphXirnT8zq+rbMGDmSN2d4NhN
Gxlavau/PYyi/500UB6enwBlgaNKa1ZVk5gKRxcW3REMwyyKz5RRqWP+c1soa628d4xF3H3fmdDk
maGphhZx3EfaiU8bVEA/SMS09tCAYrAmMjvDPML8jmseo0MA0GeEvdu83imeBQ5WpDma6prWOvYK
yZ8BBE8PlTI8jaXP0UNNNVLfIC20zBhMDBBtDWzS9Ru2gRYz2HiiD3vhCHflJgX0kjT/KTVb5Afa
R7neqig4oicHnluI/C9yqrfPurp7+t1nWHQl0/VBzmj2dlzWE6fBweqpNZJvqgHPD+cdiJCPrhBR
Ik+H/0zJRsZXCfUu3Yck1aY60RakxOgnQItuL3u0ez1TFXvs99IpdhC+5cSjTEY/WaBjt9+724R5
IdyBzPb826eR/zRTXk5k1vQginuWJV6M03ua0BsQ416kcr3uJtEDsIpKWqyedCX+KlV1d3xTW19B
9DGcAuW8vzHoUo4Q/1ITuHKTzw2Eida6dLKrmBBffO6I7gDD3eGYgGWl6/XJa0H14bJO8vhdfsjQ
8B2g+ZJPhw1BM2SmhwGhHjc2EtkIN1seVR/iOm1FpjXkyuIUzc5NzxkYx4iTweznxRUXa0O5BfQG
zcMdAgxIXp0aDAJSfAKDQgkfP0ucATTxslw2MvXgOqlYknDYr/XudksDWhYKaNuSfpNuUe0TVcpU
rlCm1m7mTtBjZF4FV6o/T8n5yUElA9syOYeETw1nCs2HMK3Ec0rbL1j11SykqzV4ZVqStQGf9G5D
JJ1Cap9O6iSNuXG0n++Rv3yJ7rAuZV4XRp6WWkludvwcIL4RGnLzLBtX4PRIjTbZfKt5bI2kUWTM
1KChnXoYAtgY0ssarH7SQIU+rdxZPd24afQDIaqP+xAc9X9u71k1vyF7Tl/YwkMxk0bWSuRDUusr
JqQcilq0nhDBXFyKo+ic3wTGdjtjPUot6GWYyYIX9GVi3IyO0PfdoAy//gGdVoh/zTGkNASEM3xz
P+8AQvejOLOrkqund+M5gyliaf4=