<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvcFGZqKMBSouKRN7laqlTxDj8CqxT4JAg+uqx2NihLiHdcedyi2EBXlDLBdKb+sbWfxb2pl
1YaaNyZ9lnqir0S2KHtu43fbwCKJ/ZGnxC7rrU/HVX4bSQ6V/MEtAO4fZwmA5rdxiu8x+uYqqM1K
8wNu/u1rRczNUDjNkNyO4Lxlpa8O1wzAW8kv82B/JAY4t5S3BDrdwydFMQEKI0SBThTv9+s8Gj7o
iURKhOgy7mF9UfTf6rIx6yBMgDzHN5z8b0Z5FHgssC1YTuRUSO5ryYqJAijeA4VJGsMJjkPdYKs2
FaWxuNjq/e7IdfunboDLxqmOfD2wxZ2ulP1A1Y2zxec8hj3cDh8YTB5QQ0nqeabsPV08m59qSJd7
NZLclxyXBRGnAcQT7Cba405+tUOSzbNkFudjd3+k7fOwyPbetxYerbQ8qVwo8VbbRJEplMVDC3zg
+9oXYlpWXlKBlQ/CwxVWPgRGCSrCXPZGSe69Db8Pq/4lM1GocfZ5XqEVH9kBu/RJi+H1Wq1RA8KA
VcMBSAgHphm2qHOmcjfpRqKqnNDgOX17pKTeGj94pupPetEG829uBdyhlE9sKm45CWbnuqPr7cy4
vvlB51rhBJdlsS5T/SWqZquujboUZ8i1a/INlGf/xYtBVHSjryf04M32GIV4XJy9Q8LGlYrDm4I3
/l/7zCdqP9ms0Vp7QOgJ2zJeUCgtzWXtb/ezfm+lJC5gdkpSt0uOIL7gyXwX4XS38rRpuQIzrAmR
m7jgfXkztbabTYYudN2Bjr/Me1ApxbKhtjuaf4tacLYgncvypBG1P+GeRZlASfMtkwb41UOD9YUu
4oWvDMlbIQNZoY9uX6WgYJRw1oDjODx7vfQKs7bo/h/EiuUDhPynfQJRz2yZZqmhnzselrC7tmHz
yVA3RkYi05AfNhNsFwupjSWjt3PD7whkdIaFALxBiQrUZOacRM/P4BS2LmaQMWJoTSH9QoQH7Np0
5+TJY7zL79GiLD1PR9j/xPtHDjnVIFQqtTsxuTdaDu4pbI0Y2fTHt2tkMx5v6WeguHFUINCSEJZH
AOiFqWxEuctDlp7x+oWHklooRRGbNmj3oLS3LV8CVM/1qCAR2Wln+Lwtqxsxe6/ixQRzGz5/H3+O
GRMyhtLXFKFzXimJ+b7VXPOve03DfZUOptQbJkaQJp4zUYO+tmxuU88wBZ6z3VqWVYCWBV/WC8oD
ImxdnykVP1c27O+Op6j4deja71wKKtqisipO8lCPiNwlSHuT8DoV7/cPRb3XTJiSn/QSfJSrnif/
Qg4u1OXpEpzYdMtCxiEqUaZJKMlItBm5hjpwe+DQQAUXtaIbSXsoQiLjIaV4xuvfkIKT/tjkMbSI
03fX1TfeapP+4tg5CaS651RzxOsAOX1GWZSxyhhKlWm/Qe3VDskpe0p9XrL+cvFt5J91S4Go9vHt
MAtFZaT8lxmm5AmMPLeIDqat2ZSOSvhy8jcZYdLVL1xhGcjWcb0frVxUks5QCcPxBjUHpEs0vozy
CLBiSwk17NmVRbINeFuj0z/L4V/xQNIQsXdlyq2lpenyzV+8JVY9A++NesoWVPxR/fQGNhErfaoU
9uFLfps5WUJxkCZsZB7YT0Dwf1Na2fv0LHZ5WwAQtvUxYm4+Kcb8WIUdsbVS9PnSs1yBQB0tyGbt
QZqpRnMd0Mda/hAeBf5CUTkmocqc3NR/6/PWMMXxYjFXuUmx50yLchu49zsW8vAfUwBrPQQrNj6Q
RXTMv5R1laqDhiWIEGEkxQrtfzy1cWv9sPC3iNTirIU8p2t2tsJLdWXIxsiBQagiFwlzv9XPQBzI
2etlheD91JIhNBfikW11mAVyOm3fHdMq6CuwPrAe/9Uxg10IbLpZPU2TuksZWLvovK6emLk12hmA
GthK6o2y1rv6AWS7azxX6IdN97t6DrfBFhytjXfAMI8bwlpJEKHASvqncW3imB6+jW660aTh2m8E
bLpSrm0jV7di7WFoHeBYdlQc+jhBZI60+p3ldzAp47ka7KGLmE8Yb4lQf8VoLilShh4tKV+z8v2V
afhcbrShNfU1Ts0+y/AHspNl4U+keD/PyAarEdU8GjF7QqaLu4isJfRF8KtFSMq5XOroQFxIofVH
vdcw6t2YwoGYCujgmCdMuNDJAKX5b1EyK55M/l6gLHvE8Ai395PCAslZvfmnMwQS3A+iiIkNGPwe
ingDayvXorGeBEMwEdJs1PrUFW8jp6s3x7rAGW4SWP9eSnY8TplJCjaMGV3PuSJFO7b5VFXuKgky
Hzv2FZZeEK+X3iCC2aUJAXvvYWAdjeKnKLpwwEEec6pfUr7BuRjfrbCImgb17blI8JLr88cSSOTV
Y3OBbR+qlQUllZEKve1Bw9PmpgzGQmWsIxDW9Vlt6MAkh+bwFc1r2XhbTF+A1D5SUIJBKU+9bWDR
ghgwujuDEUlqoTFr+nlgPWgVZSaxIafR0DI9ZX5WKTydkpQjx/G+XaIqavRN5cuoLbLv6RoKEsi2
FagZIYaP2mydLmpYesUbpfKcgL5Tuk03aOCJ+bxp+6Z1r2GrDhBwj68Gzz1NusVfcFn4nge2Y1RY
SNbVu7VACkXrfFCt1aRcJDkxJihkXL0QIpz4bphthI94UuRZU96B9h84TvOE2aG8crLPZ2AtbQ7T
cHUIsUnIGnmZjE5cncApdFYc4ZIt+8jRR+1yfiLYhHAlHcH1HCiZu+ZSuyBF1K13MSbmq8bAv50S
6dF/Udi+/h+T7JizRDXrB9EAcvIfG/uNEJTrMF4oQK6AjczYelrDq5a95+bxw7AE4QsJ5gv2jq3Y
S8yr0FacFIQ3Y8JXYWzv1QqVjZXjgsUmP5cHIo0RLbPaUni8/p4APofyV6FO69GTMzFJTG9Sur8Z
8iW/eJl1R06tncZra0TSxKdleWUX85FApoLXiuxOoEi6aIjN4B/SxsmGbFdzU5ipay5KEBanNs17
DHPpAiIEs84FQGHKgqxWRrrqWb/rXT5kcgGI1ST7+WpApqrCdkZAzKW0arSWI8nAcB2yC8lpc7ES
ZgK4vdKKM7/oOhMx82efA01ywz2yRFn5rt3dANZY12FKzVDkNHWutM7GQMq1StJG1TIybW8fPU4N
gGL51NYsqaXvn8HnNDlBpe+QF+9UJEe4lb0wvWY1CDxxPqphrWO9LieYjqzGk1agoEKI5Ht0C54f
SLmkk7Ij/XLuAT0GK2jzJ5U34BYxGdgIV5SV7v6ZjVvbuilVYUbgWFaolu1+Anw0Xs/r0PqK0CkZ
McfIOEszfZqLIblryiv567n5m3q0gYtVCMRMc+MTaLHcz4yii7BJ+czZ90lTojV0OlUaWVpL9K45
3dl6o2dMkyZdVXro5ei6UJeOJoloIo+J9dXAnqCTcGjKKJQTE5JWBgP+NgX+n4HP/dF1kx9xp+db
6CAsuCa36ZxippKHbtJ5aRlJhUT5WnyLmKAppqOHYhgXWpv/7W3bPbCd5QO3kllwY+2fnGmWApuD
Eiez7w+gc2wDof+M8IeZ5aFRARNQnF2fPygZvDmwpM4EvbtvCFEerC72OMiKkalNhuUlBAiUYbY1
jZUQNi7Z24nMWAxV2g8YmwDd9UX/sPwLH3cLO5K9BqvPp9jUgjBrM1CE6UjIgVjHnNkF5ahiWDVz
mWyz4uPOs9pf1L5ggPbho/6lS7Zc9QL+PMPtXhJj/rSthlJu0ZOW3WIpJN++8bkjWvLxnb9p5nPv
GmbTQZWOeUa1kkCHL4Gf9Kz/6eKOB/A2IJx2uf+nUQm2HzOYAA/9Hk2FVHLqbhiMpFldbN3i4Cq+
5boWRiGaBK7jEHdMYBq+qEwvXV62wrP1SNE/yeDw/NzlsNCm6iX1SG9E/6cP5iFWy3r6dd/dPIbM
QpvC3eJRP4YobmBIU8DrgzWH+GZd585SprPCQVrHpAAOX1Ycd9aMOs5BQZeBm6wLWpM40Ez229hb
msK/+0Q7/Jav89Uwc9d3e1tStrqJaohzdg/Hdz0T7TzGd/d7Vko2izp0M7aBo0JrKChp4XgOGNiR
8C1Xwr3GzOQVBnaji8fnX8l7SHe+GBB/SXfUDvyp1dnOi8pYg+G5isotuj2EzqurLbj0UGD6Xnqs
ovDokkktJQ+HhDQUbTia1N1SUKj2NCX819WwLlGFK+a/ViO23SP+5Z5i0vw+0UMr4E/EJGlHRcUM
MNr8MfTHpLugfcyY2XSmxhpxaGMb7IP8BomPbpcKjQ3BTv09Vu/0Yx9P2APUmWpFG/xP8kiVE1WV
3jajeB0QUL0Ubrr8t37R8oKOTK5PmB27f48TSxefREjgOCq96RD417iqSIAPLJ0Fwv45kB6VmCFk
ge8bXu8Vg0fzdNTkmHS1tYfY+3DIdREKkTs3FrMxUd5ht0mLDIP84KmcQjZ4g8tyTe6d1BbbtfTB
