<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPornnh+7rJgmNhXJdBWNyR7d/LCZ8t5JixEuzxnkseVMGiqdT3VHUNL/bh3+5qSIvE6y0IuD
URGQZwpdiox/gyYosH6Lu375cC2rCECVLZjFdqmN2MGlz9H2ZFATkJSii7kArm14yYiYIoSXfXBr
fxFIQUz0jsM+mgj1TCKv261r6f//AwJ519EDJGfFHqOPQuNkZCjPyF+R0eQCoL58uqA0a/szC3tR
+KBz2s5hotZVzAJCnsP+1AJdYpb1GBWtFtBAgu3L3W3OXwtmeEhzGSlm2JfjhF2DhgE6dCOpoGQ1
lYW7IrdAeh2cMAwpdH/88EHgDP01r9PwJP8fYvQrNCoc3B/NQb5hUCBnB1VXUzuWU/tDW27ozfMu
W4i2AalHtamZGvSnkSRBWnvB17WRDeU3Cp4zvGibyFXOvNJJkboygDHHzO5kYoTEiY/HcTlJKUvJ
E5OKcBCUZl3rh4Huinjk9wfRauDf42i9QoMX9ddBhBGAHR5vP1+9rWHmrzzkz7RMKjTiuEl8fGqX
fDZKYZfyWtqPaqE2DWxn2OvjyUc4IwzuQ+GFNl4XlCLVuij+VKnQgK1c09WOzTO99I2+qyAXsa9a
8cK+xAee0NEA7SIWVSumyDxrGdt1v0NZlNLTypxNlI+HAlRh4x2bfMHXGDxSQTEPtW6lOYkvQQwm
Ys94/MpRwn7LEl5tfI/azk+oitq3CcOwFflpZqtqwB7PeNLzMHFCz4566eEHQUw5MNmBk1AKUM6U
XPootkXkdKIiVcQkBtWbVAS18eqebkt+PuHg5fsPLRqWXBpBbvTF686iLOEIg4Mhg329u7Q6Vg5J
rYEa/9znUTBaoxJQ3rjc0uPRzoADNOUJihAukrH9tm5QqCCZn1bFYD0OyAICsEmCgc/ZujXi4wB6
HG5azY3P5iXWDSBBB4BItJdZrmVvr4C3zMRXSDysTqYVuZqmtEIZwwkS4oIjUKyM1v9934sQtnHX
NXQc2++rShjcGFTPu1d5C/yH0DAJMZv6AJlC0DsX7VP8W3rxAKrDgkZjkrqQsXQQZu2qkQpNGE3s
EBjgb4pYu78StBmXtkPD3lklxHk7aPMoW33QxGSGZVGn9kWFUICIvoYz5IqusE11hzYAJj6IwYfb
AaadRdHoZVH+1DBhAD2WSjcQKLfxf6iPc7tH2lxHmaDsjBA5ZQpAIycwfVcT+4ytNT8VWxVNaeVn
t6vWx0IDpk6T6FwJd6ny/UFxyjqaN6ZnE0qfcRhrxLFLavj2slxBpVHAyCMaHkVmHLXeBxncWkR1
waeBTokvD9Pi/iz46e2pjZV02W7071yct1kPFZknetKHjGhZ9cj0odLFLU1N//uKc18MWynbUpae
grTZSxUL1Nc4Vi9mTjputnURsiWW+Dnsv+mxftIgILDD2H9vyKpr4t17NQWpJ8kBA9JlGYfX0919
rvlpDbFe6n9TYpj3g8Tn7h1p9ps5thqmgCaqBy/H774m5lUq0t+jjYUkds7iRuF5+fJtEjA+SKR9
c4BpUp4/hv+Wv+YfHmICm3JpsJGpaLT2/8ox1X5pynJwSWCNviW3OW2sZrOEez/upJL3Mm9qpObY
HFTRXM6e3KhFHz6W9U+C7WfcZsoeYDrFgFp1DxR6SaCr1FKxpiH2crwJETVSBYJu8P1zpYUR22q4
m4uvm/HkBO/NJrNFnfv+Mb1ZeCt6bVdHWZ6rOAJAasRJXmXWSL9Kj9OZmT+wrVBDzoFOAzJhqHMN
ac+mq2zjULJuO3IZmBc5PFadnntbCwJ+xhZ19O14blqUSydmgUAfUtz+FcF8oBGdxNmgaUmZmryF
dTw8aFSNcxC6KpXBoGGajXa/L9iE65DwZ7qeUT0x6uv272jEN/+hne7wDwjkWRhhtYaa08FyRn/R
Pmpr/I57CB8zZe0hiFr1Vh1l7PxdnGYDNgd8T4FaY2B/oHrDNr7TEERSU362ZiacGWF3MwrKJjJA
PxbwNnp65kh5+iI71Qj+OdF3M4fPccVGDBN1GAGt/V12dUZoOndg474kZZkcrfTiGF+uTeKSH32+
KdCR92fRn6xcqjDz+t+kDeIyrpsT+8q5o3NRV/8EJSN8kG2HqiB67+ouakTdrSQUkaHTQJsSN5Vt
bzAf1oecbwPzo89I6MiGqPZzyfmX7CVRMgFKUBUjo7iUJW7M+R2dRW/+hp3Xx2vW1vf+Gchud7Fr
NfYMrCsu2RxnCtr7eEpEp6OruZzEfPmEekS3vuljRedqzbm6MXyZ8nm7ZCgNKq+LzugzOBC3lIDg
dXND0TQJiF7ZjYFRmHjYY4wSEq7hlnKpvqpnN2+hZRbWjcku7qJHjNutEeMX4yu2qGmQe3tMWevL
YdyfVo9VaI8l5p8k+uiMfmMZxhu2/q5Si2BwOjA1CMC0IpvlqOFlC2AQbMVtXGtmQBpcez7GZHD1
nb4PSIyb5Bbf/A/pbndULU7z4LO7GbTuXtDcf4hPWHiM3LYqvmPfUY9jcu7AUhI6owHHiEB5I9O+
zjHF/uTbkL3NsTjyHU2rvfSa6TzVhoj2hFFtl8tytctXZ+eqW1nlWVwWoTyk2jWf9cQ5Qk/6heOc
54XmZhxvTa1+w01N/2YpPMa1QvkIpyQuefrsvFIkaHtxnDDluu0bIrnVvAydTfVozbXaTgQbCcyR
TSJ4ffpNfvnSVdX/bX4Ecm7MeWsyqtxLOnafnHzRRHnaG+HzjuIZCXMYKysRkO2ncKZ/0v6bmoVE
oQTvQ1VKfQKMe1/hsEqdC2Lq0LH664Ih70ZHZUeriwF6uPo46BmH4wNkUvRG76MoQC6bBXPNM4KP
g9+NDDqase375YJAMrnvSKYyRwI4SqmRV0GEZmOwJxJ1dKxM3T4zSpzmeEPObac+TM3SR8aSA2yt
eKbNflUT853zYFy7SqLGAEu6nZE6tDPahtyYg0IiBySUmcfZ474Jl8Nt7cBt2k+yiUax0fQCHebg
s/MJAt+NUa9CIot4t8VrCfT7FrkB6E5KbW0Vd+nNPvQ60sHqawwjrzxOnkJtkk3XIBh/0B7GodRN
Q2y3b43ZhVQm5Uo3HXC3ENL8LSVuPYjJc7o7CMoFVU+KavICryU4zrsS+VtE31lREy2yU9KH1qLK
F/6zRjWFN+lzXdrYTCKgyMMSKVlYFdlb+bcMKR6hhRCibEfSRKoV7G35JB1MLXYRjLKxPTQ+XAqE
LObAilbevpLLfHZY5Nqq0iJVp4ZHnGB+ilEXAWEezj7c2qltxiVQbX6T6OQk0TOKa8I/wwVaW7Jo
o9fylwRXHp33/MmtdXI7WcnFNeWqLS0IeKLKHE/Ub37d24G9MuPbkh5iwngAlL74K1f28FKlpNZK
99dypzhiHcXdSDLmHCHU0HQ/eKIYOQimFjmLIlmuiUyktmydUr52zBtWLtAel1CCgWUvneeJnfvL
qbQ6ub0g/Hi7f+gEdVdPfPTxAjhDl1dx0x9HHPSQMkGP1BFpHqL5L+ub6v7G3Tedg/E/jzoFPXyX
Xf/wqzIRHG0Bf3dCCqjVzu8zqTXW5hVqjrqkQa9AWc3YQCT/fa8voiRxh62eek/ISo4e+vOAKFe2
JiRES504WIxF4YSrzIwJcfdX0KJJ++TUdjeQhJXFp9W8c+723H02bhFN6lf8yfePKiGg+HqcAOmZ
7/HP96kdU+xbw7m1Cq8uE+oBVSyV3eXLWhBlR3QpA0PBRtu6hNv3avKIEopaxyit5okoc3MTb0IW
3Kv97wzSItDIoXy6Ze0Jc/liHM0oDz3aD9CfDCq2YtPC9hQ7zleuVFBpU1zE+zq5bo/itryJCJ5R
x09otLmmM5eH44P3KgDAHp3VC8TgTsQm1qWOAkOr//y3JGnEsLtBNxs9ggFmsPeXF+HanfQ2EYlC
lXgECex6y60kkOpHUC6DZ6H6XYXNJCaFnQBFIxZUHcttXcLwjdKo0sr1cWm9Fa+P029RPla7k/iB
A3W6C1iUBjh0BCs9W54UVJHg8W5CI5abGxhU+Gj14qsDqgKDSrtZZEWbm1zPZ5LUMIJYYNqD65jV
/NWg4zLiww1xUqRUKG9rGn2kITEMi8qZN2fREBTExFn7Hz3qC9fxercJFOHQwgbr9ScUrsNJc1xU
Je66sB+sHmPz/swSaGe3CdBE63VSSB14BarbaDY9MDSt+4DjEiRVnfk2aKqoPk7+LxLFN0pCUBQp
1N2JqB3DzULmBAK6irOEgILFc8ajOcjzjlkiwVf6W/HCXqBXISm343yeBdYRSChKrDOpi4pHoEGd
j1i2duthYQEjVlB9pUy5TOqiGsu9CBi1Iz3J7c1vLEgu04+pGQ9RdUhKdGGJVdV5MuKHULYoZOjE
5/wqJhk7ZN0JCKAo7qFWRaM2fibeiKHtqlIgyLxiSylb6nfc7+8LewV0N6Rn0aHIcSq4OuW8mCyU
gDkWpmh9Vm==