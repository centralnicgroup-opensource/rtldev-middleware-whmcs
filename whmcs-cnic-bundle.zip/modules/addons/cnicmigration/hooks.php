<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzUaKOVS8QgecMt4fBOFGLNgpykhhweWg+CscUXGmItxy648+Sab6zE4T7V/BdrO/hDbXeDG
uLT9RAvBzR2FXKdDue7w3+ZfzMnyOTv5QnJ+k87nZysowZ4vm/ndTNxo9upM6ULlP343YoAQa6vw
0se0gxUlTJ8K21O8WigmN+kj599d288vPqXoRS9WSM0HLZsBltj1wGL+UymLNbPIyAftiksanvEO
BWNTgphl5aAHNqllELnm6dTm9vbn74voJ+6RLZKwgWAuiOK6FaTVkzuoxwktQKDPeje+cpFF0p3R
rjHd6/qzrgPqDkyUHlmEKaqWQYiWl9Jq00IL/Fj5q7N2zj9Q9/OVwH4jXIXy8UuRXb6kZKaVYWjA
RXuW8FEwTQgu8yBqrI4AHw11x6jLyrbjD3/5A/MeL9uOYOZNPqAfde9oRQjtDjnVQgTW1GxMcSEM
zc4c2XV3FNaDyguJuIcB/KlG8T1szoycCCsrK/zO8xkKs8rMhnobMTH7EDZIj0eXmPI/rzAq4FOk
+issMejF8n3+GEf7sLoehG1Yb4DKFyNoB5fLn2gC7PK6hbtIdO3fb2pv0FF88mom6BZn7OEhBFoZ
claSiePdZo0zFdshfYTmOUEzZs8x0manG0ZI+CY8cnC+0TLl/zI+IrBjFUvAJyUdUcmuSAamDXXg
Dxh5TOMj2EF69RHS6dsJ0hEjvZzbZKiD+GTbjoq6yPid/5PVwoVY+Bjw42nwxhhsbg9npjtLWZCm
t99IddYojzshourFKI/2KE9NVFW5IKB0yLT2UkZM3A5WgL5t8CuzB8LUosKKE+qdKIeLZo/JUFnl
gseHQuefm0aPRhYr28It5bjTeYprCOr/iQdExX2mC8Pcx4ymaL0pC3GT57qdfYOez+mJyhdycXpN
BBjKDxNg6QDMyB5r3iuXg4ucXRMGj1rIXhTxhGncScajyckK1duTZAJJ1leUd8b9UaXdnZTMQSLO
FX+W7Mbpcm3//ZeZdZMKL7HXePPzFb4/DV+xC65t3clZtNgLNeKJs6XNpCl6T3EYG/Fkn3SLynxm
9AFWmw4u1aUIsq0WWbXBr2v+5xtMvmf2tysM7w5cUtQODk0klr2U4slbBAoULrYFJQbaTYTXfuEX
Y9L6TXScvJxl4PzwwKEcoIZJkFR8FMqJwRCQxqj4gkdKl8pjdnFS50OfIrztqFFbmtPb/EZj9iGN
cTigfodkoFXgfvQqva2dN66dtfTnIY46ySCfR8tG9i+Lrnz0abJF/1wtn7j3x6JWZLw4Bo3f7EV3
iwVeBmiazVXIxYue3hEsZgHw0uIOowGwlFpPwLnN/IWOEjHZGV+dTO33WM1nl03Ddw4x8gmw0u9o
nnnzR4PDZ+oRvZUwPCQHmPiQPKeVfJYcSc0/XQ7YhPOzyI9BQxNwU1kzFveS80xiRzNk2uV+gEfg
hxRjHO6oiExF9YZ1Zmg9KJsQn8rLrHxpHQ782oJ3qr63bBUDacwalLetduIecx2ztJOuz9rQQ+y9
KzKvkcDPHdVdTJ2raTdadWvJWN8NCmIiftvbfdhbLdZgTz9xKUGB3QlMKBQeYM12VXJjKfyPcSVw
ASGe2kTjTGyLjU/u+wQ4jv8IQOdZACbA5qign6l1rW9GIx67Q9dJW8VF8ECoNOBixzVkGbrNqorR
BsqC0BweTYr/u/PBI4tJuNtQbNG0xbG6VH+lxJ0eBMos4CqmJnkqkiJuB6xquOnzmm2XyrX4tyTv
FvViZ6+53Nqu1GdM0/QSpSElpKa3tUBSkM9figq89YANJPdL8GF4bhRieRZd3Nkj88tvA5ztN8CI
5wrrFMZt1YW7FuUfIQSAwyZKrxeQLtU2N/4xee5pwYxtiDTra147gZeDdRwVwDqUYrsBxg1zPub9
LysQbfndUhRnCI0o993Em2edEW6N7Ok3cuwZU4896GP3FwutDs8AwE19ty/d/hedOgQvqeyWPz+9
1pMgwjuMItkzdzvp6mx8dYqn1jdIuBFQogrbkEIwzwbkxSq/cRYB45l/Usq5Ls3vDZAcTcAesFU4
pdntnnMbYw9chxVt1RLqeeKAdxxjC1l5ZCi3G3gAX8SZp6nbkieXebiY/dC8JOqk/4Wq43ZGXnhk
HeVGCqbOlE0bv3l06PDedgZ6LvlWiOaL+dvp1CfDm7P4GK9fbZSfSwalp7xoFnHuYd/6UShYVfP2
w7khX0tgjDUC0DbMOTM4PwNDcB7ktOiV6tgyoy9pKrQ8IrYyxnjO8TBoT1zTnKYeZXW55eGNVuPg
vZwjfiLWiIyi254DkRjJAuQHeQlFDxKKc45pOaopXiUq/KSVI4JpZTD0xu2PWxHySdNqX1KBct0W
JatRgjntasCa2juRTF/qH5YGfLx53qB702wOQe8HPBs3bPrrcDJJHLEyPhylJ4Ex9NenaCG9+8E/
tbzKZQNEnEEQao/qS4piyseAfa+kIGnqTQbqz6THJP7GCcn7fKUAHooUjYHxFge1RgwzgOLmaRVY
HzDh1KSRj45RvyE5BuSWr0xlK1ZeOLGp2cOH6pdF4wl63SaBVVo5ynjuizGBpo1WcargcxxpE50v
uIWLGJSPo4jSyuw70HUUjyZDHx89ERph5Z/Qiye+OwOGQlFl8PAiAhHx4cUtxQEkX3sdCOTcZsx+
0Cgkmypa8IdoylkmpgXEhmBsBAMhkYg5V4UoPohT30QNbc5vYKAfLOCoyKK0JN9zQ16gb5xu6yEA
eDMUXK5T5Mj4I5h0yNf+S16pbOf66gQhrMGv0/9kxlPsmiVcOhdcPw+FNpHSyz9fI8cQ96WeRYGq
UIl7Kfv3dFwXsX2yds/uAbNtQIUsCZ1DBS2MA57iYpW8snHTwG145IZiuHfiFsKB1a0EnIPHTlvH
s+npTm99ir/q1SenI6r6ODUE6InaCo/p3aOZiTUTHM1BrpjspdK3EbBe7Jzd9cQcKgpibkpqTJCe
H/1ExZA3Pv7Dl1XGEzmMTRHYJrQy4oUWpmkZC0MgmHeOytMmjLiAxuwSxnfbda4PBr83ZeUY8QgI
XWyDiXIJqaIKe5/zlqFG14CxPge63M7YH6LhgG3j5uo41VFh7lDebG1N6GSlkckitIzoSaJmOO/b
FhGUvMUDu4QiDCJRuKZcgeqdXxk3/5XXUH3u3Ff9zDHqxymCeR2GbQW5IxyK7ZcBREeOAmf2+uNO
JZHXHEXGGh33ph3qp3N/9EjOrXcU+mQKzGblus7furaY6+yrsRfV6y8hplfRjgygyJG6jVLiiEg7
26tzAkgVRPYE6c5QYohpRAlYbFpr/b0tyeURlBwMplf+ns39jjh2rtom+2k6fgToJXEfd6frjZzh
dceCjUo8eFRhbo1MPZGspqHR995JCyfRNBJGo6OLq/mmS9L9C92pXJDPjbPwrIhf1tpeIVyR9/Op
cmJRJgIiv5imqUTxHFQvjzhRJOavtRskMj3sqSGwlCkC7uAolcWhoKkmCWzW98ldy/oM+gMXc8v5
o5vlQL4cGURhIrdDWxvka+Bx+nGmcrio3kFl772lW/88bdFGS3Lz/KhMIdcF0oDKvtTJHL/tdJt3
nX25eyUfq5DdmF8ZnQtIwVxKIyI+XwJX4UMSHBy5ZPv0JCncmeEfpfLvzD7kDHrVYK+ZNyXTiVe9
tEUyE90aJltW3TkV8T0av+9A049Gs+Y62dtxHJ8LIugkGMHTh4jYv+B6hVw+GmZ73fzaCw0jkHkN
ZsSQAV9rEH+alNjegqIY1GRWCeWMiryt/xm6rFZRrNu7tvAtPeLYqLDtVntjo8eG7syroPBcQL5r
RuinS3fj/TWtZz/HI/qQMU2seaegmjRFS42Kdfj8jA2WJ6OkCwD48dha5bjk0bVxlan9wvpg4X9N
5nMTVooyKED5HiVROAOBCsQWIw+8JZQJ2mmsCbX6HODDliZfo5hgwadAtDdpznLCGC3RubQ+1UBd
xEkqz26hhVCbGzcrHeFvH65Yjf+5aC8O/R8jKRP3iZ5bxPbT0HrNNB5fKhLZ/2uVUNrVRCU1ya/Q
93ObLWovFVtXwoNJ/F/0Di09NWuqRZCI+9Q06snWAYd0LtL/DfzLYaIMVgluIxlAFT/ehZxCaG4f
ru0qhdPhfMYOjfogR4uwQrKJZk9IFQ+KvyG3g/oe26t2JXGewVPwRjCz5lb1PnKi379nDB8shFVB
LjDXmYOYIo3Qr2JEE6I/b1U8X7SYuDJKh5hqm33kipkT0weTrzdtkEA8qns7zLGm6ygZw5vhC6Sb
RjUxJUmCKqHRdhivVslhMsZqfj+xPYAaORyAKLOCiIF5KlFzaUvTWPYdjg+6XIbGfGqgRj3yvC8O
qJUP/NQJk2pF2klrRTfdJ7S09HNZE0eBd/pm7hpNgtNoWRi=