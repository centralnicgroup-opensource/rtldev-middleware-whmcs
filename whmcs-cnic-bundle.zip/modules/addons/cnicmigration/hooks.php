<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwrFwvmT6D3Js8P+l/ojnaaXD2QAuHbqmSy0mg8Naz2R8wZTwkHBrttT/fg7rd35E4ZM648K
4dyKfuhxlT93vtKKQz2sfFxu9etddMD+/wkDSumns7cVYujX+5GEnVtNFTTOMnqm2GcNQ+gTsjNx
ccSm+kZK/ofZ3zUI8I5oA8EDgKCp7/t+YZ4xT3/rNmRUc9n3xLH2CrBr0UIKw09p33eM2MzQWTlQ
UDfZHaTkiidIfu3DdB/iDfi8ppKQK5695Dlu/4IgqkylOZxrd786ZNSFIvTZfMvYULFRKlzfPRoJ
T27Fg2gL2s1vDW1Tj1HpRB5L5CI/MAv7eb5IhtfLNc3NLPLLws2IMc/p1gPStb+UuSdpCh19u0Fy
53bTra7ov7zvD6/8xp5Skab/KB8QMBvZPoLGJ9WbR+nWgF7x3SLXnxuUivi/+fBOJW93ym6GBkx1
/RHooPbNpk0D4mPNMOWPZWvEaqpavawRSGz9xLfxL/0XeWHa9YC6n2kAgnnfH+F1NANr6l1TztFj
1EPyGkP9WcJmZxHRLsiJBAoxtFUU5ymE2XplEH13qtH29kuUu9Zw0qvC739+54me12W2strvfJX9
hcRaFaT8Tnrqh6fphvvZ4CA0YD1MbemLMu7lWr564Fgwr/8QP2/I8n6PAKiwflALTRmDC+QqawG5
YYTu0urGPUq1ILB/NlbrQcNXTfGNYdNIPl+inOINI9BGsk/mTVHY3mTgWxTgZ+c/3swlRJL9v8LE
ma7ym+ool4gVvUJgCr02mmfiOdlMa/Jvk4YFPq/5PRBmuE7Uh3jyJXCOuifAgVyZc6/HDUfyRlv9
aUPrjfxYSShonVsG0RmU/6ED71fpr/1R0CEpoS9A3X0US9jbKp5qQPNgwRW1W+Xr1USNpYSAMshI
UdYjxzxb+OZrKZjtPzm5qYfJLGopcODhM8CzrE3/wsOgUAtjI11ys3KpOvsObezhnZhtfEyV+Tx3
kYlOZrxN08ZriWKPsH01/sjV47jd5V68yTAOdb/0eVUg/xZCszctuVcPRGy8aUXefhoDirHh57T6
rSchaMMJEBHSXK00bI1iJ0GFsQGQ5od2mDwv1qbYyLSkx9tgjyztmLK5/FSve6Ib/DdwdIAKkKQB
bXgVymwvjKW4lhvw7Td/LbvQ0H8qfXSf7V1whsi+NrukGBQ8GI4dJ+jiX+hEZxLpXYLJwXh9Mpfz
SvA+zn+us1u49GIEsVO0JRdNUpuhjodvsXoYCrrHb7xBF/6ogPUPxg7xf6lQ+oklB2Byqd8h051M
rbXBPgtFnvxThbShxsnrB6Ovr4X8CL8xnSbFFICEVa0JaUv3lG5TKlYdcyZ8BYcI9//aMPmn6eA2
aS9SwQ+d50/Y8DMKXXoIw9wHaWwEapscopWNQFRmrdl+/mtFfTtqyAIdvs5edPTM1UmWi0cJ56h2
ZnOLEKJeS8d7GRzs53CuLzVCVyJEItPX5JLfvHd/wy5FMCtog4Cc5nCFr58SKS1HaSk+vrWZo5NT
QZjFGf24/1lEsojvKS27QY91Oo/yj6kUvidA7r4rw+2toejwJsi70FGa4M/1cqKUmUGIMcR7qfdI
Dzmchk3gDGfEkxFNAzBlgf8MTR0ly1NYJQ0J7dZ3L3hBqMXtcunuKjibiIrPS/TXB8Hy1i1J7cZU
FUNahbj7PLsFcXv9yzUT+ZglqQix/nW1PPWjVF8jQ9FHWnddEBtNstElWMyflit2vC0DYpI4iCFQ
r/SvLidMeobKSLHsU1qwlanToyE0EXHsJn+n97ZotSgF4pDDWMeBnYPR/HMKNThQsTo6dfKgL0yb
aGEJx/vY4quCkQFrlyY0kTlfvEqJuz91z6IfnS3KJI/vb4mUZDS5+bjz2raSzAPlXaFt0PKxHipO
LiWJPCfBVvsfgqD9UHIzNmtga4x9hy+X2LLxBcH98WE3mMBfheQr6kKYsCIctnKca3AGWo8JLEjw
XEbHE37iBc/SEyXjlTm306iKUVs7vFbHWeD6NkJ2+5mOo3tyoOuwxdkGt6XcXY7Ch0BxRYesG9nJ
YxGNsp8/KeKLWsgUdkc4YcJAzGZk2oCF1pCYeDESLKcvcKnpjYg9CI9PY7L9/6NdQP7kz/XIfQNq
6XGSSjLExB4I0P6DXZFSh4WLT7nFm6QLAJvD1Bjv/ujR+vKCPaVRFWaAFL5OZg//c9jLeWPPr6K/
H+aKHOVxDBal6V8Z3XSHG3xshItVoIlzHYld8IgFtaNeGKqpPUe7j66OiKMGmD/5knPcJ2v97hQT
Dewquo9RGrZ/6GrU1sS9UPX6daeV7n6GQpSezV+qeJYabKJYOkHVH1FKNCsqn8E1YjARsmu6HJxX
Jbzw2oxoaGdTN8eWbKNQAoc2fo43pyQP1kIrdSk17HFyM1GMFsAfO05Mr98KYb2OIP8hgcop9OsN
2uxVVqnrRiY295COAnOk+O8eOpdfuFBlK2LV6GUprEGfXx9TA363psv1cr0ia69bTuQ0X+UjQj3N
SFbvHumHGfzJiz5z6yFkg88F7i9xxN656JIlO87vq4DjX/XSaAD4wIRuwnxFXeVm/1nNDZMwQqfQ
GMjHMfwThtiP+ILxFr/tAMsNQGKJRocTpLU52EMilQY1+9KiPWLMnRsw4U++IGQwH3WQW9pimhwV
RApvB0xGtiQS8jfG7ufHp0BgGbrzV69Gsgl6UtKQC5eZdXtmG5OBiOaF3TKCTR/ByuB+OtzVSiHn
CCQHf9V1SOhQeCZOEMLDSjPr2qNY9/hW5o+JXP8T3Y0up1ltc52O2p7f5voLoXEW4f6z8iudTXaF
eJNQcqu7vIRQ8IhCodHI5eaYUNkWH9xyJNsjpiub/geFykt0mB54eQcRiTGu3ibQ0zvyra8c2Uiu
nms5503tpA/QcNsWWXV534SV93uc3CRDaM9nXj3ORiZslh/KbSg+tuJ4o0tR4NwC88h99sbjEoOf
piZ6y3sizBo7dOgi7lW7vwcAiTBE6INjSDpC/ZgKt6229Ded0UlTdDHNSTd26TzTIpOLKdmJWmcp
2o7yl1ATLDl04QofPWaVbD8VCUWE73DNY/jg3N0Qxarn6XD+vuFep14Y2TsQIEG7BuwmRZOcsp+f
yNlwuaQ28/arePvtxseOA7d9Vex9MHFPL1wwrzF+szrm9e1V1zULmSgsBfwWLLFtrGfWm3S8vNMS
zPdSqSBTyXEeAxdOpsQjGUVBOptN6kNZ7ilHiSULCVAD3t+DT8/QiqfQWJP+nCTqPSJ1Evee+RC0
Mx7Zg9hWC/E0Z1F9WE7F7dLfWEadrlSGt+d09TonjfZ8seFCZ3lA9iblVOR4wK6I72hW03Q4VW1D
zJ1XCEB1sePnR5OAYHcL3aYW5Xxz++nSXNxWmWDN+WpkGxhw0+iEpF+6x9gb4XxwdQrYiwD0IetK
b5tHbCiL6KzyQpl5cvLpsHX8rp1vjAZr5rv13o21u76a9ObX6wkKbE+zb4g1oS1CfeBug3g4kHsx
fjKi0yRyPH7Wrx1XOK6Y2/CxO2UQT4qK3GzbIpY4cIXaDHtoW/OqY1x17qoKGqCQOnYvSQPIcOhr
HIlY81CU5+5cZUPsOQNCN6ExWilByhj9af0IUszyXEOQUJTO56vBR6BUU9wXYRyXwqkjKBjiHEIb
RQfun8rSgM75WkwJC/bWAkVWSUJmTwPIpmAdi3+zvurzzDU0Tg8wt37F4toL7WWjCyfcWLyDgd+B
GarC27lzQDRFSwzi0CNqmgps+uwk0JgYzxoYL72Wk+7ui100FV9mD/K4KMnhpB4Rnj1vRn2/LCsK
DknLqO7oczdQJkAbBbuXxsMBITAIVOw1Kwq33HiJJfx9mMRbs8CZFz/uVIR1op2kw2BPQ3UEjPIO
obY88XvryCw6QOI4HJiBtSSlu0wrm9hJsZ/uIo79pZjJ/YyL2tNCpVq5xY7PkRbTk4hNE1Yk0RG5
wS41661BdPL1AoRq3/F8+eMeRt5O+v6bzMv4LtRClVMY66TiXgrPAQc3AicK0oMYu6eVZKpNTY/v
WGbQK+sxVkz/VqrFWo/2JZcfIt1ZH93r2BdZs6nXODwmIxTrcwZCdIpLZl6V8bYjrxkEMpjnnsPO
ojhPIX9ShAcDfKD/5zY+KNRnsc4g6GJltTVu2fqdwAmQJyc3K7F2LI+8fyMBRAHXtOD1Lsg5noMt
wH40pqFgWNHlh6uwpgbo/HJOzDaLF/L8p1NuxAOzO5l7cQcEeKmDsXTA8XTtnN8YUEcunDiC+ZZQ
O+FOynm3cyGTR0b1LGVV/ZvpiNd+nsU1BRfLSzmIM0QzKJJ5lW90uN2NEBrZnAdEZa3LnlUfzj/5
BeZAx3C91PbtAqJJ+Gx/aGxaY4G81vG82ZSWUQEA0yZWS7DNWjsYxqZJkDjXVgBtBmwNo7phmKwd
rdvCj3tVfxBavEcuqWtC6W==