<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/nWBeZvvPAlXAcxgmTuweG26md+RF4aCjjgKz9tReBxmtEQTAirXThi2elhpUy3Kuri9F25
4TBFYlWOXceCJQK51l9q1tKji9xyo05o3pgLgUKYpFrN+2phHBvHYDVt44PTOiokhIItRywlch+z
+PnYS1PnDO0WkOAU0zLS42UHl9c79T8Q63G2HV90RkZKmdlNu6cwV+kufMRkRDW2f0kYCkvHSosO
v0gdI0cZg+tNxCw4ZgfkmXZBaDsU+QVA0NTgTEmGDfcX1kH7GEiXIRX8w9nogcxC7Mm+mHEguFHq
I96824//Wu4RiASeTsp3cjdJjjkJy1ptTXyHnVuHbs7LOp/IAdPAiLuT09IqpsGf634OLamBd3if
I9PqE9LwchlgqFNmHA21tTVDMECBCKzdiPU4Iqaor3LQ8nWesJ3SVmdjeYXyHe0gEu5VRKTCvYWZ
4vPmh5vkl1EZJQeK0ccAzfgj1Ekit8eEHPBXYjtvj+E0lztsIXXh0nODCtTz6sKs8ZeuTGA2NPj6
HSRZ0mmffv8skbKrUnj1KSBI4xBqTVivAW++p564jE7N9f7KyX94YH18ftGHTUShB9+zocqBLeKj
vDc3Bd+u4j9bivx01injy+k1P/xI57oJ8okjrC0BtA8f3pYdcWyHpuwZEBjOCEPO0nxf5SW6KrMb
7gHyP/erc7ZNkeNemLOXoLmimEEkjqMHZxvepE+I3uRMmu+31PQOZBWUvLPrLFqi6zcQHQHJqjKn
IqjwfHYnMO2yOGL8GPhX0uqBdmNJMLjOfo5Ri2CwoEPTKKUGWN5XXs9/NPahCW6obO+qERZlFXKg
0A1e4fStySLSun0HN7KpXmgy0117KCLGSJqsaNrb/eDs3Fny0I4Jwp67p2DpZuN/9LZFCMbVtdng
uW5uhzgyQKyjQA5AoPCVrt25RqilAGND4m3URpQzR3h17o3pzpB3gjg0SAY1H+ebgJSvRH1IK3kA
D2a9pSlB1XKoLMWI4wLi4I60Mq9JVbg7ac0cRrHjZAQI6L+/6Uvy171xFJk9UCwQcuQ+aNbJXpb4
+kCbxowN+z0HhIIutMv6fJZXyZIEG52AqiHnssVo2jp62VCrobDiTZZ+HGhnv8vdvIgb81ivijnJ
gLqSaizGS4tYfTiMhficDUa7ii3fhnO/HEGAYcJr7H/HmtostjmxAmTTvkciG2U52+mokN8PwdwD
NhKrml93+zy/QhVkbtAcMTJlh+RERawoK6XffC14rB2TYBZOoKt+fbTL9YO8VNcdAn3QjWTFCRYV
csKhMfi2fLrfh+NqfRuuCXRJIhgeNBBWeDbxwwu3mheWzFhtqRAZYgt0iB/j5X7/hDcBAJFuLLBd
Vp/f5aGMazFCDIq7ioPN6SSTHrgdOeMk5zksP2u7+RZ3jKPDnYEd+N5Q+e5NFh1qPdua1TttKAB9
JoZV2mwdAWFJIgR8EiuJbKzwl6V9UpBYj48mk7r7tKimzd1YH4CNov0Ecke3Bf305pUigLkC98YK
INn+kFgws4CmeYKjyckrEj3Yjkb86ro+EvK8J08ZSAi3ld6nTD/R9ZVj80IF5FIRTBph2fGzkOIz
EgE1hS0rUGMLBlINz45RDiFmAlBJn1RZ7y52mX0FD18sAUz9ok5l6biaaQxsCZWNDqxQWTigYY4f
sV6MyocOhBoItO1x0pNOiREVUc8Zs/ic/oo5lch5Z17jZTX5g66Eexonl8VNCIaWs1MFHqRdbPcE
0iAxrBdNePqKE5U06red6R7RSHZaokRWtH6ZVDH9UOzHimkCLT5jJM0XL883Oj30eqSea54L8G0B
gdAjqPe+GvnsifRVts2jQqoftjzzRzh+3Go7/AYBPVgJ9glaRkJuIjWFblRUXpl3LBJyO8MRloao
Mn0K/hZSD2bDSVg2NLUDEQVoCMG76bBcBya+NJeKQdDsTebTkqJV4oTrLwLgnmtp9tS6aeHXnIUb
BkMfZ6G20OlGdoGqUXID/U/KbZK5w5ec/vxGucavpxrIAIK1A2zri1/hBILZhXXBj0WxVANUtqZy
Tcs1LLF10up0yjc4HAqYvD/cn6+hlvlSlZWE56C1G2V+yPDsN+k8Qbu3ZEEBwyLWcO3kcfH1aeVY
Lj4qil/uBLZM9j4Cw55i3/J4iu1S1IeVNtlS+6UZZ5VzX/TXqalSeqBFOfT9aXNyXBEFnW3bof/W
xLejr12RDGHSlNh46wQW7NoPuTWTwkJPIAvI9UO0tVsrHIBA+jbI9GuQSeHz/hNiUm1BgjVAbGnp
0ukmohZjf+03OlKVMOsJAjvAPaZi+HPXAGt2Xvk8JrJpPqmNRoLbWsqsRQg4gGibDx94LEUrQinP
NSxHaloTWYn54BVpaSwP3ekRB3Xck2tpmmqcRWeRSkNvgHI/DOQmFZwSW4LgHgf6Ko7Z/vgfVNhN
YcXQuqsFCYzVUSpxLbew2Z5l7psK4miq18Ju+sly6yHfsIUCjBSNKmoX5w2i4b3S1mXqJRU8waZP
Wn0gYwmtk4lXSCytKZFFYvM9+wQwkf2WocccPNijNg06gFVCWN1R11sE8t2ENXWNIahxnPP3G8bl
19pVlevGcXlwekNRMWfyOT5T5kkbWapr3hQfIUID7R0MrSQ85AhzdqEemjvnVAWin9sGNf33ahvG
Ofx15VAu3C/Q8kP2vGYdg1DOShNb8O9UZN7Hb/IfuQKasnCYo8qD0UaCO8wKFu1YXku0SwAWe2NJ
Wh3aO0zfm7ToqhTqZpKLjKuNhKM014Rl10slzfoqc4+IWZ+bIw3e9a6u9LJgmq0vrYDL+5TU7eQL
GSoCGjH/WwNw28ueMEqlSwJOshfZ1OLBYe8uZ+HN7rlFgMjfl6UvUEEfeEKMELFJeAxOCexcLsLs
f7vTz85W7SVLvX8bZ6cOMUQL1vRlgjl+9q1p1z8AY4HM7xBL5k/QxAvCqh1T1WWnZdysXpvPwLjX
N0J165uIylBX7gRtEA9MZsHTfkFx2NdW4orUSfFwXB8MFNKEOPRTmNN3XeGY2iMnNE918mkUSBEk
+Q/O04uBWT3DLeLyLMNspu92V7YNWLyd2DYleOmUVBC1hm1ukrnEITkj4nNXwvZKszoA0Izj4Vd4
zip3KK7oZhzn3fsQVmjaxPuIjx2FXLYz9o76FhPx+fBnna+tWa21fIux71KBGhaapdTkXKuFY3Wo
vX0osp/ALel8wJxxYFyfVHZsa4uWbtfVxHL7mLohBsjFuCPCOLHvvPfPnJqZnLCgfM59qk5+hAZD
vsGMHDdO9k0aQk6GeAxSS2l3ooHJEgzmaUcvMRf35uR210s1M8VHBnTYBJbKcVoxqYku0WYOzZ53
+hc84tb8naMiWycDXbAS2Jvw1YggsVuujXe2M+C3/c85PtA+1IIVYnVxj2WgTcgWFXpk739Nd/06
e4sQxfDCABYup0smD1Xj+2jbtFggvQwQxj90yhP3YtrzPewecIg8PNlofALZfL+5OjyaBE9Wqu4r
j22z5Je8UPkFSTFCnATAhFOV4B++gGEtUkzujhAn5EWm6uUsDB+8ya3WcK0zIYrheyf6h6UYiSBA
lc1Kyr9zpoY3GE78unWDOJh+oMHIZANtgFhUQhrPav09DPXaDAsqxF6LUVP6uw2ozYD/7qJW6Hzd
WVvvxPlU6yEnx5t8gG4BbBsDEobE1tAyUK36ebj9jneuFsN6AnZm7a9AiX54THBrFKyZpIUq4r41
37jNt+ZREgO958aJBbLDuD4AuMpQTERNU32Plqf3QTmn3BXwFwyAtPkcGlywtY/Egwg0tDDjLnWn
5cLA75KtIcw8ezAhUNminmOfrjTgIe4o4pwAL4tR8pclX1TjhDV2tEW0k2jiOA4uAyvdbCVkiPY4
MTUtSkzFJQhWNUFM93u+FSahSy8GciVXKKw3aEYY9IKt7M35FnIQtyJX+Chy6A5Hb864hkLlngVM
M7S4DDIrHW1wZZe+DJGlVAuevIC3TLz2fB/4D5ul8UVgHeyod93CGPnR5w5DItXSsObWqMfmx85S
jX2UATJ/5aH6rIRUo2md1U5AVTgdy97A5Vtngv0xICfWI8sb3ygUXHnaEI2eKfYVGsKzMm1CK55X
BHKn/aCliGF/vV1xCMehIdiGWKa/J/FBw8NO+933LAQxN5XAcbrBPYkuqmmAuNB7hYOCKbHd0oVS
JBoFW1JRsN+zy96ZDdLogXhpZqPCV6fMlAWi7QHTxL3XYyy9RhHRQXZ31pASjjM3Iw85e6xMt/0f
n8cK5A6vXKgOxfXc1eutNHaawwH2uvZMioHINngIClzsAZh/wlTX05RFmGIaBPkV1YL9m3LZ8wu4
r4qYjK9lxRpGsTaNYZjsM2Nw22CZOvrE42KpJ84Fa6tXYOC73pEVnlbflnYoQoARDEJcbhfdsJwn
