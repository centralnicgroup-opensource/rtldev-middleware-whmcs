<?php

require_once(ROOTDIR . '/resources/cnic/vendor/autoload.php');

use WHMCS\Module\Addon\cnicmigration\Migrator;

/** @noinspection PhpUndefinedFunctionInspection */
add_hook("PreRegistrarRenewDomain", 1, function ($vars) {
    if (!Migrator::isEnabled()) {
        return [];
    }
    try {
        $migrator = new Migrator($vars["params"]);
        $result = $migrator->transferDomain();
        if (isset($result["success"])) {
            return ["abortWithError" => $result["message"]];
        }
        return [];
    } catch (Exception $e) {
        return ["abortWithError" => "Domain marked for migration - however, the migration failed: " . $e->getMessage()];
    }
});

/** @noinspection PhpUndefinedFunctionInspection */
add_hook("EmailPreSend", 1, function ($vars) {
    if (($vars["messagename"] !== "Domain Renewal Failed") || !isset($vars["mergefields"]["domain_id"])) {
        return [];
    }
    if (!Migrator::isEnabled()) {
        return [];
    }
    $domainId = $vars["mergefields"]["domain_id"];
    $domainData = Migrator::getDomainData($domainId);
    $migrationStatus = Migrator::getMigrationStatus($domainId);
    if ($domainData && $migrationStatus === "INIT_TRANSFER_SUCCESS") {
        return [
            "abortsend" => true
        ];
    }
    return [];
});
