<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzNEsQBHcoALh0TCWGx6f+nQF+b15n9DJf6u340Ee/zOh9bcBm/JWqV6YzEdvXPxd2TuDCNQ
CM62YP7kHFSb6SfSzYNSiyD5p3/v6/sP2w18MRsty2WxUX4zHItMQZIRyk1njCuMYe+qk0H/sY0+
rdJHI0fcZpazBDnZykhn3Fnu2UZ2gqRZTSxkthbfgBx79hIbx3SthoYiis7Ts0alyXx1XnnECZjN
HiqjURbiXgFcDssp/sclxflYaFACjTnv79QUPr7xiogPqoBwarRZit/zalTk6ZBfQT7vHqWqJCm1
GsX+/rNu7nVGoZjDUm/WtMo/oX+FG6KTkNjL7Nb/WttTHJG0AXgBkgJayl33XfhVll6ezNXjptaF
UoSXm+2EdHOAJQ+Ew7kwwKcO7GmucCJidkigkoSXR2MTBixQLZqWdWttfw7Fc6wNsaa8t4jCf6jy
IPELtKu/6A3nuZKtw8XCyBKIKL8EvvUACYSwwg6obwr4KKHUX4azKg2m36dmfElY7U3gEMsuJsWn
u0lNJHWooGL7Nt68n1rUUeQJV1F1nnprL4fGDoQGXLE2RI2MwgjWmJ3glCv7WgT/Gn5hLIDYTN+L
0zU+FI84WzQF3oTg+LhnUNRo356I35WlYloUuVUv/Kx4JSmjVFig8HaF2nrY+owhdyse18M9Mj/9
r3lE2jIYIHLglAUpMyKtUzz+iyYxzDU9SKmQ/epwgQCJHufR2NxefRr5X+X20yJeP63shAc0OIHL
Qkz9AufsvdRQNovgDuaCyq6e4EEBUgFU3IcVG22Xuj2tVx+BSdCxtHwSPLO99+1jgXD8AQfFOvQA
CNJeJP8JuvNUDGMKHBkmZ2uFCZvIyOSM08rvGAUaX/AnnXIDiVOhFghg4bTaANhhU6QaUUdChjOu
WOwF70ls5Iz+34dVCyjnIvnt3ow6VmRCZXghHyvl0zd2KtaREWb4j0Ua/4XBEM8Zh8Q352Br/Urt
7Y+4BI1tLSPzBlz1lA40TO8vyYEM+a5fqkZjQQbIc2dKU7hOxQtwph5X+uAdRJg5+5egwQ/aJAgz
VVos80BbTC9PK2ltU33yRbtopcYrMesNmJLouxEpjNpbfAM60l5tIAkFFMQ3XhuBgCGngsc23eff
D250W+QYKibGg47ntpWD/taDkpsi9alTBboevFLSDOnXVIVJUd0xc75KQtpDl2/5LhGHt6DN1If5
BRwU/YZsmutLtNlLLy7NVFHXytjjn4PazAia0TfFtS+/gJQ3LbZPZoAShmcE+6gzv31t1/WQ0S8K
ItLI40cDB9txgwkk/tDBtZVJNzRCi687R/4Zcve8zvfOhbyVAFHM21m6ZPsVQ/L/bkOEV9DaBrUv
cZRGkrVMxZNvINzCEXzR+Gs7CcY3Gm0Epb64zydvAkjMyUJIn25k/d3mh9c0aBmShCUCIi5HZ7mg
tAo3iPaBZeIKPlZjs6wdtci0ClVyY3eIMabrzh56JMzASeD815+62pO8qJqZtOSHD6oEOJ8cewHY
1G2+5P+E5IiBprdz1jGUSr84lLsBRY1jBPFZl3Rx5Bd6hSB9g/k2+a3OYSdhLtQg3imiPgITUOhL
fW9Cyu09hBu8MlDEYbYICrX6dx0/zLyzGUP2VM1gNWYYS79FCvy7SfKsM4dDCP5UR4OclWN19LQ1
hMp8FxSX/L3sz1biIlXWtlbC2qh/9afapUebzhL+3ZdRYQajEqktFfcCJaTouiHqlg5EeiyHMIKp
MEdiTfz3v+WY6wtk/HyeQ6+ngy9qT6rPscDTvNsd5oOP/54WUrW0kfdkYpiZIUbV6DAlLjDvL35Y
D6ylCTnAbAbRZ7XSZgzJNwNcH8UfrJblMMta9nLDH+LQXfCz0pCmkY1crggK+V8UeyB9Ej4lDTvS
BnJck8Qhy5fiZde/w2rLW3taW0cP67NlIscLDXN4MPGIOgrCvm29xboO8aNhcfOW0FeJQCUpc/rW
drdT9FSaW3xm5Dcloz/bZ5TyClw9BILLQdvKC/6qu6OHtZUVrm/5xH9G7ylt1DwmQV/4/v9Ydulh
tInVZgPGVj8NZZcqRlQsxkvZ00j4eDtXo8jFBcX1tJgRGmBrguvAGjNY4Eyb7yuQbDD6QTskrRHi
LpjNAqts1JNL9PINEsbMaOofBkt2CP1nfhzImNHqHlTX3CfuyJspottIPQwIn7A6IJHNPFi0hvp7
BUFH4/RcrSaPzqj++YuJDqWBAggSEw6OinD93VcUD6v8GI30NgrfXD3SsqLutXz2HC/91VwwiUia
54x+wWk6FM0ginf3/AcwnBWqDcALi4nqzIBPd5QzyjcQ5hXKtyn8XqwBtHzgR+SWMAgaxJc1fp2l
QKh+xA45b5FZ5UDlNF/alV2kUYK2rIvOu01s/eYIlyNQlnjXenxb+4n3tUno82oPAo+kyjQlEiHb
hs/qLqq+Hoaa3+goQBrAA8Ndk7sD7svPI6gHwCyNIDu0tuxRvGx1wZZx6QQoviUOcGvDk0Yqhhy8
HRB45/4+QVvmccVurCoHQHium8MquNZXbmshPvWWWciFPn1j3jpgeftAXU6zQww5fuRqzyUtAJqA
LrZhOjfbdNzu53XSCU33ItyX0+smAbschQig48BkLwFHbOnEN03zmVg4ZPWMYKTbWDS4SLd+0zXe
aFQctEpmhO8ZGob3efd/Vso1cw2Nb0N88bkfCeTvHcCqSz6z+3dQQwDeFkSkCUhp6My5hWl/G6Nq
346Mm+c/MuYUMfHf0/o+7DpXVmB4qVKQgM+bbsguAsWzNLlZ0fuAJH2pHNyLXodY/jsFCTQ6hkUu
mPOFKbaDUlWv3YrDDRCv0dEmgZaEq/txI7Rnfm4IttHjPPxTqkyjsFjNb3XAHQOBXnaRlMA977ii
eXankVMBZSqOVqJUXSSNBxA9Jj08tA2XsufHVCfYrJCzBblYL+lph/CnDb2cZjsfzWhS/03ShMBV
fgY6i9L8dDuhGQNxPcXfKDfKn58tr5tP/23uQVAr3r1JvYuk2V/+NTOe2/i4dMtTev4sG9oVdW2K
BthETZ0vf7OK69JfEkm3tevGIYElqPl7NUiGjTlIbfDnjylBC/2HKrKEZIFhkvaqiSoCb7e9kKJt
e3TXGsyo/e7cnJg8IWhvTrl9r+pbu1AK45SIjlac40HuYDEHIzaOWnBFZhGIBjq5LqCl2xZhQq+F
CKGDtTeE9f0I5yqgtCYm5ZvYq9Bupn3+y67Q6pOFr2LDIkPNkRJDrf5gzs1WB5YxHmkB+V/IzXHC
XrL/DlRQ95TUun+l9E1v13BgSgzGEiZKmNDROopXQh4vp9ET1ud6AGA4r8YTpTYmbS0mwoDrcQjQ
Ix17ol0shaP1xOppk4pwVaiIPSvb4kuJrqCrK0fBvjBldL104t2Q8gmcP0ZI2QqRmMCNdYQLBwnD
lLyfOfdMhWqjGbokO1Deyl6Um5UqjtIFQkOW/3sq+6i9qJKN4WCQSqU4bcn69nFhYXrpoTkIQA74
2AiRS0iew9rfUvPJXWMa5aFhpNLNTwsdfUnYjkp0p8nYu2tUXkeNr6qAHw6Q+KCF2cWNb8tm0/RU
kNPb3tlcLlDN0tYacrYA4tGofsOwtJeQl81q2DEz7tpvIqrPrVMCXziBrwshZvT8d34UnieNxhy8
PJDMFmhUK5db+uU1qAhsxMc5tuqHSq5bAX1zjdGmNkekd9RLYySUR0H0RY5VTzLTVENSOCnxvgI5
xuPWv4F1p08UbFXAyGT08YGQKT9mDXBCI/coT3cV/JlnpnNlohTDITBSiy/14cFWm54VkdRen/1H
NipGlJ+VgJLKCYH5D1vBiuVq4cbBaFh9Rg8NMSLJM2dba2q4v3+cXF8tQruxuMmM70WoGfTTb4yY
oroVy9QuQbsINFoc3G4JBe+8QNwLJ08HIxRQab8QhVAKRW1Oxj2k9w27EDS75HYQjxsGvk8YkJxM
lgNCPTx0bwwb2hPv0Z7fRXFVRtcwE+zViqvEtSco4VdGST9DITmVK+6w6nTNPe79hXq0VsrJaNzU
1cynpO4MynptpqjkrWxQMt4Cx5QnMIH6hdR1389DOvM6Tlh/I1LM9axgUfYfFfi330PZ7QhMle2C
qJa6vMhM/D2kUd4nU8RjmQSSCufTJKaBKGuRQOLZWHduz2qjjUwv2vJ2i7ebj0XJhN82YnrM7HyQ
jmJvMaHfnXdh8PiihuLe4nlXjxNgewhr8PP1jyLS4blFuHlin/wl2cU9UN0mRvTbGn3a5nGTS8bz
QeM489+H51EJAfhZRGSUEtnxUhsaZUaMLMQqxCWNJPGKRkIoVzS17MXNyhRon86nDsezOdkt/NkA
W9TkfgOWUPd9hfORUqALnsy3miOos42I6Jf8J2itVVwrVowa11rPpF4OaFtODyU2yFYx7aYp9lCS
10==