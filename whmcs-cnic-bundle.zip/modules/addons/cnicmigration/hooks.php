<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoJoBiI8LfFhLJkxvyLjy2STV1oVjWpwqBoudIWcNrQU1BAxbD5poqacHPeh1zGeigSmGbSN
E4Qd5GEv0uEzvnm3vQS3Cf+abpQr8RlEhV0cytlZuvM9IO+5QCYI5DY9GfxZxj17lD+z639/Zsbw
hoaJcYOTpinK8Qbpi/iKG3vlSdYp6I0rfvszadQ5D/ixoz1CSdoTKa65PimO8quxD+n0eqR5jR+k
EKI1k5KBsPZTbKoqtQFsk0laaZFc6seYBtPiNazPctGn2vxb75HMiM0PiGTbxXtE/Vi3/CNBzjOM
P0S4/sls21FvXxmrWFuo1bYqoiz6HMpixhDkO2uSxUMsgOXFBvq8VqTHrxH8k8VshkeZXuQoYlCz
Vh1ZNrAf7OpI4pWMVnpVI/6H7gtw7eHMdyyVyeQrtOHvKbe3yax/vSqzTWNnhA+UbGDNA7/0wKQx
D1BX7EiaW+gyUjGOw3EaEZ4/s1Olnq/9qwtSsOTZgZIqTScm9HIHLpBBwSMB55TAn3dMAqinsC1K
95LKwBfqWyurwAOuV7dgp7psBqB/vGB+qz5v6XQCu+/v0gRj2C+SRp9tHY4Z9oEfLR6gBh+Mwt0B
9JCMxjv6jtsuHrq4HBuIXbr3acNc64S6lOgzdP//NtTSrVDI5yr/spLzFy3f8odOWn/ed7MQqJu7
92mruv5VCABQvkgiqJrDoCBFvNyr+ztvuTQ1ozR6WyWON9Krch8HI1hTFpHFfhR+oDIYTsbrrkJp
6KtD1mNWpiSTRQwNNZb26oam/DdRrWp9WDlw7dAUreKov59ZKtkKszRnwYJ4nmg9HzEjJFG3dfqw
/5atD8TrcXbQtBfmBl5LlDmMPqGKD1s7cIuRNtEWCAGN2PYdjavslADLbA7qVVIMkdUcQUxKr+f3
zuwPx4/NSYdQgMmrFSzhIv+AceQjZlqberqUbERCeKZ1hclN8q7z7lGnH66n3PG22PYvkGwmbsPG
sAgBX6ptHwtfRF/slv8z/xxsuZvXZx21IOF/by3kjaWisamidur5V8lE6CHwAi9ebKTxZEHd9E48
/mi+j5QyFnjPD81A9G65pvN8QY4fqkvUoA5m1+Vj5EHPXKhopEP8pPPip1YMb2tOwRv0yXqMlPYV
dn2i+op9+hrOmGTp6QCF5GAQSZ2eswzkhAXtN0yYf1UGJx0ZUKGmYVBpwYqDsrB81wNMpWd2cDsZ
5DZDIp4MpxR5ZnvM1SoDoKH0GjnzIEMH2G7UVWaVU2mcknnFLqWpgmt/wlU0Uz22wqRcCjSMoxkM
N2u8KXZmknuRAPjVWc0b5zXcQhImZktjw+7Wt/l5QuGtZR7UHYDb9C/KtlRoQQA8MC+JtsHtjK3S
YW0egcJidk8TlPvSrjhAec3wmOKQ2YfC7F6xwSGB7zSoaOwaijLh8msk/khdLAsra9Km4WNek9nw
1EmikXa84EUA6s1Vr5b1Ycw5cWX3IAEUccjUBd17hNuB4mQGRbvCzLzqrjQ7nq6LQ1mQaTz6tdeE
y16LItAHzifQ/eTkGUz0JEJmLT41FOg4gDTulnC2faJmBWJDJ4KbpsN7XbtQaQh4QLw0S6zFWX6e
MmUomo84wI5i36gx+jo0ID9kVHdD5EhObA0xAomBG1zp3DVW3vknK0fHPp0FEW7D8nTJd4thh65I
gijRjOY4R7DfB3kZokr4dSdh65cJvl2ua5ULcO74VpOc8QOQWB3qS8v2l1HrnIBbPjN5oRWRLddF
sPjKmXp1mMk4PYdgxzqnJp8wg/L3A4/5qxlD5XZmsPwr0QxwLf+3kFKb9ZDWEUsedUWPMiekvcAp
5ieJIDQhi18bmUQYSY4d4ivWaI6XSF8pj3H7OHiPDYrH+46J4Cw4+Tn86cBORpUPnpaSJ0qBcNve
6uJHKrI6ocTLQN/TBOQbsEZfN21p5Yw/R2BKUOXR2a+iroBC93bkeUvVhYpL2cWvtUNfmC7/qhXx
7feegRD05WTe/+EryTnciBCWgbg3mzs0s1ve/ErnkrGu7zZBQyZduL1tksllsQPIuIvLT2d/QV/E
a1GYPo1jLFtzfI34gq+Mu48ADtVXeFjOgdolfUDf29EIrA9iMEeORBgHwqA14vi+LSrt6KKzD4ha
xpDY5heAWPlp8nrJBIJHRFJ/fnB8MXidpWv81qtVUze4STuhAZhVN/4pZmVQmtkET+Zfjv3SoH6t
7A8Wr4xqaAx4IiQVLNfLp9jhIRbEHjzpcz07Jm/FXMDiD5b9yVOkNSnRBJAslszjTwHzTrRBJw24
x8Pq36qcJq9dsQ1+vM74/z1JGdbhStWkjyihEOhGSt6jKF1756lpgy8BvvfFykG1YWI3i+kYNdyn
rX695bXyiBGcx+VYudj8Jc+B6BVVzi34xnHn7bseDy2qZm2Rnt3MiiPL5JJB/JOKV/I0nuwkf+yD
gf52V+3ZAYQRrsgqaKnCY5o6Ckbrop2d6a0fQvLFk63FUdUXIWuoywpizUpTYfo3rsxyil4Im0lS
RHFDKiOuNUB0maH5Ox6OWxDRbLDvtbb8Hfg6PpusDtf48n6NyAaswYkAuMjp7R7w2Y8VqUWwx6k1
UcuLAimCW43ywzqzY5KO+7fn7zX/OZUvutQtCJJy31aC9jnqb+c3ERQzKZvAxynqcbeUD+xJ7nPT
2xPk7A3aoJM/RVqBSwXNBjIYraqmfL6s1V/iJa8SLWfPSAEAbDWswmH+CNgjtkG7DL77ex2posca
2m8vEpOWgnHTL2bnb+pXGqWPeuqAylWiTow+Bbbm1xih7X6L68AApgrdcsO/N05sag8PEQ/0fNxV
B72hWfXfkfyWu+K7uYJy2uSF0PAHdpWO81wH1y1q9fYkIk9MZHHluV1hrkfvl4OJ+yepCieYC8Gw
ceKLOGwjYCA4feAXs+epy5pLcYs2sPmaZftoP4x464IQWI2pRRJcbfQAoYktZGH1D1IvgSKtuCpK
mgnIgUV51dAkhLlifZ3Oqckt8ngv0y1+xthKjNJgb+gsHJNcJRa03wFpLlHzDxGcdtsXW30OfyK0
a3z3lcYAdARD/rnKWkRXapHOdb/RsOd3LWeZ1WM00SuLuPXQAfEt+hRqyrOqcaJ+pUCkQ70BAJ3l
YNaFpyQHHDxDwfqom7sbuuCaHvxi9cwNJUgEVy3EU94nY8mu2D9R1jjGFKUhoTN1fuVY8wvufroQ
cIsdf8R1X7oGsbQ9a5pm+GsqNgoXJWuYdYvw4U1/h55LCU1SNMLjmylhaMUVCnwryRYhoOryIiv9
dqDOXwajSOKZsZr6MrMA3IzVojABFGKHjHDqw409BR0Rjv1gXeBAvgi6oGjUno5sjQ9Il52rEjH2
1FkrUI/RzkHnTjorpL0zRegR8eFWnRLwyq0R9PygRBccIpWkuWixloxm1hJDmg8KK5jgjLtccyoF
boyBkLSVAYhwqGBfmRXf/naMpcDXbraTonA6o5dYLHh6NZKO99aSskMt2v7f264Ke/fWDVB0Mlzj
xQSoFdmj86isWJgW68+foQ1pN3WBosKXybR+nr/FdNOJq8fNdFW/p3wFR0XqFwK1IWrJ4Wxh+hmP
VAOYisPuJ5DK3AiEW0yxZgxqvzaCxz+ZO4dkRbEqSleHH86zadECfABT+Tv/kHak0nT5aXlpn4rN
THBSZYtgrbdn6qnOTMsIEDy/5dCT87FpWykzMJK4DVgyuvcu9XLR+uCO73kc9j/Kezq9MbuHy8H5
7q2hhW13pP2fyAq+rDjbcLQc1lu7imXB4G9gQdU4XcllgEwmMoGjkEFD9ZHuKAQBA/MQQcq9/WU/
pG054d1YkCtNLbZ64hdTw7y9oqlG3KjbHXaB3CtT4E36u/weWBTXatDDlQiGsNmoVZd6MajxOrYY
3Hiv4q2+UoJBmXcRaa3K/St6dnBrId/1bmx0y2QfQIRHv1jR4heH41OcvSIfvZV+E7mgb6uwXYNT
koX4sTPUnCkG8ZSlmTXFD990tS9I196vq6AXuEgFFjlpFwFVR5sj0Is9qnlr4GuIYAwf7sfVQlUM
en1lrcenuG0YhbPX9RA59S2+GkJTAd6UdR09hwrsYY/MHkimbilv8t44aiGpkDmq3KMypyNvMv2x
xSVZhHQWu0i2wVfRkN1ErJiMS1mNbsmgPhWc5c/wtWr3xCTa7YBJyPZjuQogtkP5aDfLa3X/O9aK
Wd0VVV3SPO+ZUhze4HK+QjzcTiB7SeXS/SiFZuRXsbHuNyFbW6M7jiuc6lQI40wulBMILVcBKben
m0phQcgDAVg1aziON9AUIZXvXnQOGiQrl4Fv+4qafefDvAoHyLrIZMyOiFHDGwLGvC5e1mkKx+MW
I7NVAoqvDHFzHIsQTPObRdH1fJcEyD96fvMFR21vu10etC7RIH8JWL7/dTcIstwLnwP2sT1V9CYi
gp4PLg3M1hpI