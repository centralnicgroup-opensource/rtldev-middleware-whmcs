<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrNoxVTPLzRu93jur21WJAreVzNaJeCiZesuf2zfUghK8BjeK/j7MuxXYFEX6NnSno7fqRIs
GbHrKwvt7pxtbtQno6H6h60tbyuSl5COu1zVHrHzRlLUDusIvAyqyIKpGglap/fBuUnsikMplr6D
bzJb9hxk2LgH+pJCkhAcGqAA2Zd77uApQegRoLAULdUMGf66XfAvVH8GidqZ1wZDsX1/wBdeKtEb
W5kUOZCYPKo+0ulsPEch3ib0NpGfhZbYmboSHCJbVPVNPnWIKKGpvUxVHYHiG9Lyzlp9+lBiya4j
k0TB/qcvP+iRshhgc4Zpo6yDHCd+p4LxFdfpT3AgiZ0mzOXHZRWJtZGhykW/N3iFCSAbjqGq+dtr
Fqfbxpd78ME/wMNAWKvMOjAR5MwFAl+yYasvpHoV9EMhSxr1G3yh3yy7hLVqr1omkXJTWApESGr4
4nbEqNaIPD/yzl0b8YuYuUmaDMosmMmsGkqXSt/d53NROnQu6nhGCWtqd5kZ0iDwVb/6egGvQMIk
qScSbR+hYux7spQcWu5TU67cDRAsSsMRLqNnG1u8YQNWfQW16NLi0lgcUQZnUdA2bluMWBhdkkC2
9eoDDQkACzDfaWM/4DlU/SwcOnvaJu7UR8CLNvPd7t5mHPLwwbWEBibuBKyp6NVdNDDiK6lq5c9i
cQhOodFbFrf5tYsnyKiuVwagDIzOeeqof/TNfTZk8u5pNwupxDy9OsWFo/UTkzjCtNV9PxHUnFlp
bE2NtI63+WVNa4uQ40X1gld94yjL2v+/dOZ/jPsOvP6VRuv4BQXm06XtlFx6Ah0TgPCwNun4XXn3
tiOJJrus91kFW+Zb1ZJmfAX+dI9lLq8YqW293qu0Nz1WGMkZ4h4zPFO4YaNuVs8g78YdElaqdHhY
ZXovse//E4gdNSSRJJa1Zlj2xJLPS7OVnA9QubYA3zP6cYFcXZKBF+IGEM9eLxYGhCnVjfDBANv5
aHfBElmBIwZ7qZVOqVwMoARHlYwRaX806yulQcH8fk00S01rYgSbSiEyt/f1+eiqIUGsbN0tICtO
4n3jWbzAoCx8g/uMXLxPewWU9B6iyngwPqumtIwdL+fPWvOqlyTqfTzUa4h25paK8zDUE5xr7FM0
I4IySE0z+toDNFzxnukh3748PTPL1/qujDRlAL3VzyQVHh1i/8ehowyaCIga/4z5UzxBVrbLeKFb
704D7IsBDMTMO4OZApfO2kgRqhgeFvHrjQNf7BkzXgOjt61kK6A5CTE2OhOned07Gs5LBTAY6HEX
rr5qmnT7xrLB/5iSoX4C/Ww4ZE6IlMKb1uotBLnt4j3QX+GUFfXSTEuvWR9YYsFNao2winvFx6DP
XgXwUeOGqpBJavDn3sLqvr2B7nq/+wo8NEMXb81f9/GYIFTVsiUALBRGiHz80eoadwL3RN7kYlFn
NQqbd+eJncfV79L/14fXb/ZYdisrS8jIdtcoNW8pyIfsCXY48wvv+ZLqdCe/SS6KdGm2sr6CgsPZ
ZdemFsr3w4iYag2V0mOzePu7FXxIqgHtHhGDnZKOmdgkxOFYzCxvYyaBNM1dDsDJNfAXC+tsGpaQ
9SxvYgy4U1eU1dBb3DvpIPw4ExjNkpRUUPEW0sau6tFtUrTxye+8jl6VPAVgdvX51SaSzu9cXK8f
4kGS/X80Pj9XClXndpqRmuZOW66A8LwuHCJQVJraHMd7xFqv7rYwaR4UNPS9MuVIn2v87WAB2CHH
x+lYTQLSkp00gXIjrQ3nHAiqETt1xjLBz7xZW0kmIMz/vG/qgglL5HL04EKg6yKkIe8sRORfMrxq
2NNQETICNF3ARZliyiXktHhe/VWJB44ZALE4V1FLB40Ni2ysM7w1HL3Rt98tWQCr28o8B6+dD+8r
bHygQuWxSiA1KBwsGb2T7j7lX197/uau4xnB3Li2Qx2t0lbuKiN22A2gksJs2p0H0+P7yrwLOS98
DBeNKo7aK1NcvkpHKBYpT3NITJY6IfqouljNdzDXqUeRQDOztUpo/ubLLILTtIjglvG3wHhnLHWr
I4zOjE2uUvfKfJizdiUcs2iWhcOaCfULhqAVxBaByHiIep/Kv5tBs+4RqY9ReXkuvEqSQtVt0avy
2jH2jmmswBLKNqY02EHmbRds2V9ag9jZlwgcefWvn9agCPhdrhDRgePeos7XuEGzt3sp0JzRo7hY
+4hsFfI9NAL+QcUHmml8MQWtW/0/xl1GxTr1V4RHGkWS3g32jzBsjwbAuphn9TD9VvCSDu13Pds9
/hmu8lEyPEtZkNelC8UPWjXDHaAyVMW3PVmj61iZtvHTqNlkgvRjqvlK3b4ess2X1qasDdhAu6ZW
FiuhgFt2KHAeHPKgrhELXnzcxFIbGT38zQzdeRMNSCPPKemVTv+IrVQqpx292pDKJ+OlvM064rbf
kTbIsupHM80iymEKCXH1GBUwRsE2LrQuuCHop9JzZe0YOjEAnDfC7m3G0XeHtVadNaLhY2XaCBg5
bFcPMJsiFpy+PuTDuRGJ+obEsuHqHrYKjiRWMiVBI9nii/MUM1g9d6CbTSeHWgJNN4fkfaVtjOht
MdyArpgi6O/CJtbLVVBQ6nDYKCK8N2IAAUXrmxa3qqVn0JyHAfeT5CXXcsygTm/8jsE/m+1RdzjA
/D48XdzDJJ7MURKAifJ0oewgbQvwtW0ViBDicLClDXmcRpICupgjlFvZWUKZkzm+XjwSE9xXYVst
0dztClynj1M5HXxW2jj1WSpL/gDOhcM8cvRY95zVy0iaXbB/Dqs5Ta/bbFjp9hdMg7tBKt4wKNuI
bhXRbK9V0bJv1U1Xl0E16WKfMGWLv20wDuUh3nrim2xx9d+v6oFEcoj7EzYLDBiug778Er/96b6w
Diotphyh1q5B28WESbVpxwyT9XO4nwl3f3ekSfLtIt43+S4rWI/njkMbf4HX/0YmRPnqQCh4I9Sb
BeFEAuBOJb7Fxe5oeqBOI//r4EZPXVbAYW7jvqzVMuz/s8JSqnl6VPzXP6TJKlS+TWr4d4kHaB/Q
sb1dbj/kD5PoLynKzjdOt3ZvFKk7HIRr94CM58kdwejAN0TGvxbCfxom68dV9au4olyLmzXTs+3L
rdUpSC4EDBRDKfwZrO1uYrKhRckfzOSDSt5vkGFIYgKSea7TOPIyzlgX1rn3x5bN/9FSRNZyFeqZ
6hUPFMzfUtHlC4tuoJY4CNohkiZmDPggrU46wVPQsG54z00wO9vTkML0bFCOAXL7wOeKjA017lzv
2E7ABJkE2ABzwfXw6pWgvuT0+sc1mYUHMUP3pa1qv0lUsskur9fxayJYERBugzBbLVrNJHrQ8+RL
dPjMWY70MiRFweoSo9kG03lLDCcpitMgj7lPy1G+hId3XFXa+DctG8XXnIRFajfF5O8gfZY/gV6N
nPb5V58/zIAlb9L32FPdHuF767u1MMN/W4dC9UWVlZIuIahsoHv43r2QKH20jjMy5O7WJjvXieFO
l4/5vgyFwlZPxoVghZYWq8sXNocjPO20a7qT2MtM0sAJ8gpU+/NzABTMg28WXNlM5XWD+zV3SeLR
/GbLokRWrBBzx4TlT1blVnMqucEgjsTTp47uEdk908fwJnNQIzrLECwideTzFTOsvt6yZKdZMHWJ
HOocp4QCttDWyEjaA1RbKDzDoQseysDuBjYjFQBmJFY55rYyW+oNqfB11SupzRvITozsxQITI2vw
+RGlE5ANQEex8yIdCuzkXdMiSNl/G3BcGfk7XGUin8pq5Mhdi8ZHMvPE8bf9k9bWpf4GOSk1+LHO
vlt1YbBFrYqNn6Z2LXKa9Mw9Fye7BSxKESgFLaE00luGojN17qcR1JKqSnffGJNaV+HMtP4pcfNI
9f2uPgaHUn/e9cQTvCyjKeHx8+BVaBQ9Yg4mLA8witsILh+2MYPHGJ8N5rCTTzr2hfxnMRG9lGq7
VaN30UR8wQftltpNWvC+tGx9sLhZhXpeU81ikWpsP+t4ybKRCCP9W8BXJG19DL725Lm/1ExbsJca
6216wxhlwC1Uhv2LN24Fr47r+FQF+VXGFqlVE84NPpE3yxfjAVaIIpUsGa1xxKJ4mbDU0vuA3ViB
olt4XAbyTozFnfGSyCq9QZEz5DzVIEDIsqGnpDWCRHfP8KqN0/v11QcZuBezfR66WO0NZDj0xmgJ
cn6oW8yiYkf0O009uc8J16bcHi/UZvfIxHCHnjar1bVZn3CngwMonWI/f9J9R46/LgTLccbjIz0A
CiGv8ncDNqEdhoAJv77JbtaXDfDKGNBZlkAnKPEJTXJSi6Pek0t9EKsZ2mMzQZ9L7qR5kzmsaNxn
8N+xM7cZUMXHRCsQVVdfZVCdEDWN1O+pYHuqxSVuTt6kJzO8t0IU81wq0npx9eZZWnWNrKlW431z
EN7X3xGl/BSt