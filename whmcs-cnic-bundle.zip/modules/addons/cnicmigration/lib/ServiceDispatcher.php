<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPryiiA97ymYL7fybWR4erVFm87LY6fvtXRwuaZqKKMk0WG07y8EQzdnRsQQ/3DMalwYxy9e4
k2mMgt96HfGDc6WFMVhgLmnAccmp33+lWm/ZYIm5Kj+JQ7PzK71YQzRq4bCxHj3YJtHFcSapZGlJ
1HJU4MTV7xDZsG+8oIKxSA5OMTIIoQFMyV3Xi7LXMsiQD/6IZWDuVUyeWmRicJJE9+6KE9DWCeFQ
PLTwaYbeIFKe5NNwyjgK4ZLPz4rQVgeqdx5Xu08rschs7159idl4hwtDlm9b4/Om5oH3RluGIXSu
W0TxtcNLxIN3ivMfZhMdZFmb5bl0K6l8p3DOThb3eeSAaMWkZtAGP37jzc+JBqWNaGUoqQdKiktB
rCcfMcHlahT8mi+ZBf74HYxDscx7QBk0GPkeZmSBtTpTGUdNeGSY1HAjewmzvxfc4U6DMNf5Tnbq
9zpdq5/cBA36L4V3d8RzGSCtj3QwMIaSg+sGTj73T2YhoSE4mwVLc4LrrKI3wgw7Ku/oW4W3Ihhk
9eXFaR0Vw082I5VxylGH1JJQaA02JfZJtTaMAdZhof80Vj05XRtgQU6YkJcS8x3AwtxIKa8SlfiL
TmfHOELjEY53sePGb+jf5OYDGXDKMx3oe2632yczzSbyJjXqXKZ/VFhg30kuB1Yx7d6Oi9m1d1yN
uRE27T+5pJApuedNrMoQAypfSotvwiLHG4MNZwtBwo8FW/2/dfinpQG8YLfHOlhXGg9v3jTTQqSA
7dZUuqHAlDLlith7Ff8Wr5w2pBgh/cLAX53QcJEn6kOAeyEBM9O3wClZWYXsOOz+A1B7xSkEV6Cq
E+V1mAJRBnhwNqcq7vQOPaiq7PlYYTduSavnP1C5xEk3pCt3CmIFjZvUlhe2haD+g06/LAl0KYa1
sVaS66d90uL4+YZN9cxbf7Db8xghLJK7jLY6GtXYv3ArXEbqeG/q4X9c7k1/L2YDmsoNRbA9sLrX
fFKfrfRKHet5E/yu2VRcfApmYSy5jA/P16cBRIXof8YHI0dvZbCjy/VfTB7bGfxvO/dUdzcFMTQj
k0jR6LkGvzftc+DUx9pYXMzGq90O4LD8kn868H72xrSdpqypNG+Ii9xV21cPIKg8LKaGCxMgjxy6
GJ1b+qMTkFIT2NWNni8kMh6Nw6LNuGqa3VA2KW1x5ORvATYhWP67OgTOBUhom38dwWYARK6UO9Wl
TRkvVndPvT0Ymuxq5wN0IezqQq8eYIxByfpiqLhw0SDnOf7dFRnntMIC8v60ThTqj9L26dq58oIy
wdBS8lBU2T+BE+p+eoEHBGH4KRMf8YDxXe7psW2rA5pWsIQ5+6qk/nADTQJCRChJnN0hzQEQha/r
xg1npCMhVgWQ1EafzvsoXyDRMo8XJZSEOSeBnQo4GK+X5d2W1COn53XxKE8sAkOu3Uot8IGBSb1M
4TFXUsXyelL4o9FnYEyUys+m2GqDRN5fP2R66Ls9sL/uBxaUiBj3IKS6r2KUxPyRS8b3RLTY/QLf
n/M+Br2Wz4xL7M5ueOAexY1Sug4/rb42cHcI0DxgCPgOP59VkpxbCWBi8wj7KybRaWuV2EuzoaB8
zTGS76ArX7AhQLwe1eicoVtVfHa6narZvG14fSBCWLjw0WXDP367oOUgRtpYmoJLeaw74NolvGbY
Dre9WGAt15y1Q1nqVIQYL4WoxokTwN/bxbOBHIJW90U7AoU3HgjG6w2G4rtMd+vhhJVjOUcxg9aM
QOm0Bzb8hrRuGIntb3N5CHKm7UUjsSKIgURjQrUl3vmrbyoKEg820yH5/NGgY2gJ25QpNHZc3ZVV
OezfwB+qAJbUhoo/LNkSoaAAIw9mhokSOYH0OAEGFoPYPIjvQ+2vTt4z/cZnTKrpNeLjEeC9CFcV
N1mzeXzwcH41vijhgGuGsoNqIiS/XC/GQ3aTy+7oc4pRVCIvKnvAyhR6Y4VP4BoB1hUpQBX85RKH
WbO2MENAckomwjlGk1g98i6cCd7CWW49TqMF2iVuj2P4342TanHgsVJz4SJMWWRD0gugroCCLC8p
5GvEO+iCqKf8WWAGjCtee4Tgpp1piop+ZCMkd8xztG4nvtx/4phqnBO2fo22ovXXI44DSgASnbRO
nr13cwq5bsWKbFLiPHK0TRhiRBVl4sDISQkT55Xubtpv2lg7ieAuPF+Sq6t1CzRRW/eC2jOo/NjC
Qhsm1XjSzUGvvzhdNxLhSJhHo6JMw8kE6rPNoJCoIFOL7Yo1+aCY0P/vD1/BlxRcvlWr1/BenvL/
joq9igTr5KVk2bZVaT4880cBXbnPkWYIhGQxSkCvN4cYYAn5PPdcaFO1ki1GB4LnkilrPRi=