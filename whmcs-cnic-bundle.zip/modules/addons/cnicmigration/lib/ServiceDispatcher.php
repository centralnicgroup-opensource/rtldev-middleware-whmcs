<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+Q1TtB6R4n6dpBYKV6z7YAI2EbOeU7gzf6u4bVHILprbFuUn9sILpIJU/oLCaXT1f0C7fit
LKUS62+KQ30a5rkX3ooqwx5c6eEUJNNYCW5wfaSZUteDIi8rhAStlw7kAJXNZN8mbal5AhVNtH6n
rfdc9/b3FTKKSgOTJ7zM3+fWtKZOHJcVdGYbuni4BjdOw1vrykxE5MVslP5yNMUzBp2xeV+eT1wI
VREa17XMkE26vCpuqe8f2W59rQB940xWmiIjPr7xiogPqoBwarRZit/zagPeIPxN+Nv5zHWZ7mnY
HEXY/uBNZgDc9ldbIHIJnqCi2xLjSVeUC7JqDy9LJK1fm6+792jO3qz7f4C1Gmw7oPTbjdfoQdMl
2sCpvF2AGc9XGKNCdhX91xEpCRW6FUnYhI3EOpwiRT9L2POnOL0FLL4XEH0sWrRwuxv+1hOvuPNF
RjjB1cDQerUlASbIZzYYSW1B9/YGA6f+DKg6Z08vNvpxwn4gJdEXRPTmkFpJN7lOiaVtBCkwDKGr
PvW7vV53+VK1g7J50JSNXToN2Yn5hO/sQ+53RxUIRNHov4aXna8zkhWwFsaZONtyM3whQd8prt44
UfWmeEBmrMRwGjsm4FPI8WrErLFmKzjwgl2pbPLVhdcBR0UDVyfgojSH0hAsE7UXlmnSLRce6gkz
/goI9tximXHQ7pfFcC9fSRNF7JE4gS5mGw/JFXEf7CCY8uAEbPw6LhpnmUWHzPhz5FT884WzVd7y
P7AGk88KU+j+Ekby7htdyWRm+W/lNtQ65uiwbGd+SRiep554cCdZK0ec7NahosXWPZ376TcVZw/P
ZPaX9Y4xEoufmmJIJ99t/8gUDUG1ck7BURd6nky7EtL27MuBQjA65bfHKxIrg8vhtDiU/x08W2nY
usp1EXs2MJOR+8fwleOVGZBivlhCUviUVPpot+yXHFSGrTu2GsCHzAJZS0rv8ViSoEuOb+jkVysp
EM2dpGP6wbGm9l+wqA6A8N34h2GdDTYpRcNkHW/6eKhyzvTTTZfI/JyHg8U6EaALlcMSNdbyYC5V
YkcB6XRDQbUHe/znI1xDBtD+uJtarJ6nxMckdXccB3iFIhXvvaTVI5UrY3CeaAQucXXYRMe19/rK
WiMzTqh4SYvnBu1g8p282/zXtdirKF5xz1H5qj+IZomMaXuEQXJTAP8XipUh2owzzyAc8bvv18GO
FwnA32zFApuJEm9x1/14qwfxIr/QN0SZmyUtedXryIbGR7OO/AKAl1S6m8kxHpEtAxIvVplZJB1n
fTKlSDPxa9rleeDQgYcIbh+mSkESBmrvH5TwuuHjX1fTwoFqkRjDR66cV/crHhXBk8ucfdwAi5JZ
k8Xwm5nqWbyR7uHisCWTMdzGAf9zcj6L6Q0hh22AxkgTgWEo4UNQ5KMYFGC3lqoNJKHykW+oLHcA
Kl61Ry0dp1DfG+As9pccO/njn3NfEM5uWon3SILqgBM5C8rz7OalqHm+nlTrrFxDKB+MVUJGfUbt
UeBsJQv0qjI3ISnuzowiEDS/vQBpn/1ByPTo0Vj8IdU0eFhqgtM0bXPPeSbfkTu42J3GKTkWKHKR
IXTN1KsQTnr5nugdmv8VkhPOEt4Zj4usw8mkMoR37pu8tVxdED73YyLbRN99rmbonVNxPn905zeL
HWzaLPsM7WXJbXZozR9Eg5H2HGSl30cp8F3Nj5N+DQdm3Oy4hFX86nK+GGBa6QzPjIRTk8lMjKLz
Q3xa84RV1SlsOwGgPG0LfEp3OSGzSkXlegMNb78llEPv2to5dgh3r5pprMeiDZy6bzcO05lyA9c+
OhcIC7bd8+y9Km21WTHvdowrlGP/dLikFfKrcPvo6Xnrjq7A+vnSrfBLm/9iVyQxjLY2dzMCIipQ
e0YyWLu3IAdKPm5R1Aj/035Py0uzsNS0w0jULLwKu9o8nEgKcWnImi7p85dvkXb1sPuHFpT796Ok
25REfd7t5GdSDT3cRdKm1KFlkKNm5aaIgYHldM2qNp9E/hS2mrD5aAEUnzRlb7K4V7z88RniRIcV
PGo96jpwn+xC4DeEXz7xLUP/H1i+LHJJi9w4NcUgGFxrZ2rJsi5jVP2VOHt1oGZWT9hMVpq9V0rv
lBXiXKoTJrplI40RagBVGkjJOHTGEngG9kufLZl3KwPiWN4Pv0XhWEgModUziCoReKeGU8Uqp16+
SwweXRI3dBujP/LnjNE4JrHskGcE8ZUAu/isFbLOCVerVBOcLVPdwTy6lLuWTqwnFryc5Kyaxhzx
yieJ516X0sco7UzsiJJkEgNl9M9K729l3z3vlgYNt/ap3TqV0bdtJ2kZvbI3QhKvuiYEFhbfK+wy
qkP670==