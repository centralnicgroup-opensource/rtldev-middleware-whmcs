<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv9098GGhvohxVEnfpEUbtzUFlgmlVqiiAwuiOMS6aM4f3PHj0F043LnR7wZ9BibuyBVYJ9x
CZaPvhD03drMaXkL4yL8Yy7owRZWTFz32fO6yuXEPebyqW6ptL+raie5nd9o5oNUBsudqIL5DgBK
B8IkRicLmRbop3fVo58iHaAHAk96m33Q78gchNC8VLS7rLriBTeeTEvLT/USkiGQiQc/+cMbxFCt
DLitz/dh6+aeu9UNdIl6uFl6LqItGYFcedUNNazPctGn2vxb75HMiM0PiUjfb8z3QwW7IMWLhnQt
TOTR/xvrVfiAhSvI94Pj7xNnZFbu6/QSdjWcb/bf0znSnmVczIocHdzlWkc2q0uVWsFGHCqDIBYx
lVWDlMETEwJvn07LV0qzcRqxMOGB3j8vTYS5pO7xrKjfxQiJGs9UN9a/ZqzoN8VoI4Fe5AEnNr6R
bFbVswI+DfXlPzQ2H3wowrcEWvkHOQl5WZKWzzogJmJPu9YhiTj8ODM+Rz8XxIs5/M69/4MXAk21
teqakdQzIIGek9vKJ3ROfpLwd8jIEe4fTqgWX8Dg50C2p7RKDg+nhe2PRXMDEqVNJT5tUg4JNEjO
m7NZDpbAA0Nfv4YC3OKWGpAl+55y6BgWNvAEHyN+Cp+INj4h+VaSq0DPykupTraocOZGgel0bfgZ
WX/y5qys67T0oCebpqwkd00p8Ue3J+fqDNQw+le+sqzkQ8iJplYu73QrDw0FP6blDbKq2zmARP/H
IVDIhQJZQnnrUJ12YnPzkAtkczjzeKf90u3m1GL00uTh4Uf4HmYWKiOtC/CfgXArjgKK9ry5NJK+
ehPSKvZtH1YVTMy+ARYumVvYa8STtiaa7FSZXkf9YN1WLm/5ncK69ENXSqrz5i1ttjPOSJJU39k/
SGXWHbrara82Ag+cypdknHkF010jOhCvNOMrCAkgx58Ox1JW/tLaOEzSnWMRn5D+RkiuoB4zJkBX
CPb3mqo8L7yFDQPOnenbB8q4c9TPG0ByDn4Nwk4daXNf5Jzmt8c7P8pKKmu55L9ODH6i6+hbfR1e
ja9Hqh4DZI/w02yCd8A5E+1VnLHKU3Thc9Mj6lSP+2Nlsqy+GItuasvKAawqxgaSMmQWKtZfIP52
fP+UrPInskhcIjgDp1HeeX5FzWwzOe5JahFB0AK57+QxSzKfm/7gtLgmxZwTbvspPsLGblMU1mII
DPSD1yO8bNqaM4QBISY9W/19/cuRuAVWBR/h/BxvfU96BSYEZWunjbpSv/XzCqHdxVsQ7qUckJDt
0FQTdNAF3Y+pVczTseQ6SmoBpojHHWYS87LtKv02aB2CuxH0hsevE6O474MOcHcb8yEfoJOU+qNY
VaXJQBsn95lI9GMMK5k4mHYqqeJlAZKT0+T2+R8mLeBa36hyCdnslRSTNtdOn2wgg5IvwSylUTS9
sAe1+fEwc7AwMwFfxMm4O5gLWnIdjAD4f0H/iOvIPw0mu0geayrmRjH1dvsMGwnm9Fvm4f0L+V05
qDV0CmOwAbLqVm0IjWYj8NeFl/hwToUVJEfa4eIeVEVRiq/YMav/dccl2hepJasfc4EB8pxPz9YG
dymtu7xBtdDo2S2SHNRsg0Ls6HUEL8Fat2Jdc59uBOlQ5ugnnWqAMBzu7Q+GpzR5EORnILKrHQFz
Fi/VUDgDlnECHBa+lN0znDyRjGR/51bEnL2Uxd+UKhk3PH92dRqP8BLWjs9+fmnrsQOgAuJczP7z
bvLHbQW1QHDV7TwQtK0luF9NExM6OuY30THt8r84KPnpd7ewovHpEQ1OEoLbPmWjCXqp4zTVFheG
PeZsab56lD4vVhqzXK0sJVY7UVm7A5/OnozJekP07wGEdd2dHhKDvs2Rp6vHUDyEYHgHZCVBcwlL
OZjKFr+iky0KRl0V71K6FZ8z45EYAdDI7gADnsFOQ5s+rl+lC2ycGOsjJB3jJGu7KzMtY4J/AYto
HqeaWTQMmXxjAcMwISi3Ksi1AtYOKCh/RFtTuVC+jNALAIe/qN4w1Nj01buA9eUI0EHj/UDzNZ6B
fxDajqL5fTghaKM/c7Q5ZbGj9tBgwQKWJgEDyagtWSZjoaPejhxydLj9d126ogcPgELuiHXpVIqG
XAZxqvIRUcUGJzppDk0p+mvVbx7iJfNeExSfD5Xi/a/0KE7xNlvTCGnhCgq1LZVkSaswO36v8Ss0
bYbtt09QY/LAnApewUHxxc2ZjtrdAI8CyudT+488hyUC7YobPuHIG14K/0G8ShjJIGIVOtbV6Mw5
/F5HDgM00Lm5h+eK1U5muGaA+5Fgm72cuM9g7MHzHiHuWzyQb8dxbkapD0w3QTwxjQ6oykR36W==