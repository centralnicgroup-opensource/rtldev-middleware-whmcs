<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPms8csbbLs1ES3iEIlr6JRfZ7xbCWhfGJeUuRIEIKmqowXvw1LFrJyv+0bd625Vcg3AmCFkt
8drV++CA3jFj30I9Z+KiXr5iflf/2+dyO0wwZbGoT1cdjUwoZVNMGIRVxCHNckdRlvKF3mztyLFt
T6Ys9lbhRWm0RgaYjpw8VX1oP3toMIfoClyVbCGtlAts32dH+PHNl31e4DmNj9JuH6prveMQ/i/1
t2ewetszrKjsHWRLrGLRsZ8+H5PeVfxKc19NDJgg0hYnXGO+Hr+xtZBlgvLbj+HW2KiWbaidMnjt
BeTz/m8gbsw5qX0v4mKb2nHOZX5A/NKR2LfaRQ93fv4N3XWh4ssJ/zAunIMXwkeawNI12cco0jwO
02ZOsgsMBaSOKVOvMRSrxckRQATAkinvTXViH5g9fDYENj6KTNi+ZfURiEE0dDvgDWUDgVoF349n
OcUdb49M49wWVsy3kC/0V9Jln9wm+iisaIuoyOhKQkZ28cTNnlzXyb236EkQUCBEIgAGPkqvDeQB
/PHXI/sW1+0arkvLItFGNIVFUK3I9sX6wfY3cURsuJeDDxyS7HNa/oBafG0VTBHaxbxxUgRmt7DK
bm2CqhEN/rr2UplAAbhqjn5l7aw+ms4QeU/T9DCB51B/mQ17hhKdHipDwZ3Rf51FBXZ2B+WL1e5z
kejxjZaNu1wf0TSQ3pucTgafLO/IcP6IdH9EzUW1TcBULSO6WSt/cg+rsR4JCjOW4yjrCjhgGiKP
D6c3Kl6i/vTpHg4DpxkcN1nY9ONHgUNKgK2vTcnAey8jIMu0AhXrWwX/kNKO2eBLTDZmZqoosH7/
pkdIOzJhHSjS0slr0TfGTzoRhKGzWeRRMKfVW5/XNKQIbCBpgRiig+7g90hGfj3sMd0rAvYgs9Ty
fOgqFxiaLt4KBFdo0tfgxZahETm5zV/tyKddiHZ8nGexSQTDWjVPZsECX4NwhSnPsDsUeUm7ysE6
udBXQakQ/wCkOr9kOTa91vKqJ/I2dsUV1dIcyhRkIDGKyZOcTDC/IWuM5pZyScaO9MqjseNOo/T2
IGaBLjZ2wN8UVCiCFSqHDg4t4vB/ZuYALdwpwyjTCCNgwqPFczsUqLNyZJ9vzKXgFuQgQEIXkuVp
WqIHXKTy5zABVAXVNVq4S431SbFh5fEAdxBmKSoDelRslzi6Kby2WXfzvvqkXfTBV1j2zeXNEgL1
1qeftW18e0OCnopvikv7hgzyc54q+2MkiKe1TMXA7mnxrsx9FL4CNTsFjcBGVfkqYCeFQSkgIipl
yIO7vnuGxI/8rF+tq+ZxR6O7rTq5FHoCzUwxd8ROW/iQVwqqDgIPEGjmbRJyXDkw7F8s8U6EeHJM
Ey4+bk8w8EStspbrHQ+RAxWKoPg27F5RI0qwOYy4nqEHRPHcOiZeEKT8rjbm6SRAnXoxjb3a0tY/
i1/y0AwF2FyGdGWT+ZwsvC5cBigRt/Q7dwVLtn9Ck+mkc5Z4a3NeMDOQdalKMc4IkPnXgHS6sXKR
J75J0XQsNjjn9Fnp5MKcauYsXpCLFVnYTraSMfuTzKhkkKWGcyPuVzG93XDPqxyVHYf/0NPzASrV
6Q+unADBhqQInj+XfKDgSG3wBRnYzTBdock8roqWX583vY02uMGvaWyNG5giYmcW7R5BhvqUSJ4a
zmmuN+DAosxLQ2h5zX5Oi07fG27NasURx9FX0ASHVpAt0gNVm4QQKnjEWy2FSpdHhU9m7sX7d3b7
emwdXHcYyK/MlTLm63xgTS8j8KaWQrqENfChbxnuJKaEaK7p5Plb7J03s2rqKl7YwiLToj6ERNy7
PpS4vUbWSM3IQ9CsYXxxrlrCwMcBHGlOJlO5AV9ejC5zzBD8ovyiRx/KuQK9mtU51G5lCzN81QH/
22MScfYqsCpTdnee9c0PrUdbRxgun4iT0K5HHgr21rZklNo829sAiHavTtbmomvXuodSVi46Ff+y
Pe3U9Kjky9vnffIC1WHo2Z8Lk28YdRNhotGf0geRmw/eM3hs80J4dsMSLtfjTW/+j9dyvFtYVsEa
FqIRJe+HrpI6rkJ5yQdVUYonK5YbM7Z42rfMAL6Mj3WRPxYsVJBE+nMBN3Ad+PvloG8vfdBZ9Bdq
t9GGn5M4SKyiA6tGL9CB3T/qZg3USu9WY9FYqk02d7udowbA/dPGMBA8/WJdewCtJrCuyvTJJ6wR
a274aVXV+NSRmYCvtqsW5qLva+fNPoMM1GddylEZmx92bsbR1CCQV/AKOOqZsCUiyRqUHJ4Qnd4s
+akkpXsNw9n9mNCKbOTegnEty6TuKlgg3F+Ws4O8pKC9GqZ9gFnDzw/OZRy/pLkD9L+/+Bjv/4Zo
