<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy18k7kkbm1yj/ijM6UA3cTHiIGFaUoScC+95ZeRIoAjLCoUhMfnz8pJcpqFHql7ny9T+8Kl
80uS4P75CGFlUbyrlIgWY//agTRZGizFj4WCwqTSPbydzXSeMKiSA+Sq7Y7CbF90cQBUkc1mSMnC
0JGsrKqA8GrWVzEOf4wMWSx8rqQLVnZTdQjxmFcYspvZhH02MRrbLL9x12TugFVU0z7aXEs4BkUH
4phtx61Lu3/LNbnL2w2Wf7DlEeC8ZoqrnstmgZJSBdtRSIv/lRHX+YhcDVm6PYreiT4ARrfKl5fV
74m8AVzqsC+OUsRpmqqXvsjTmk+bhFBXkp84Kr1uzD0jPEHTuYcRBDAFUTmj4a6+MW8ugo8LWuxf
DwyVn34dkXrvXYUvpzRV50kkwQ5aLezZG9pOGxz5LnkqkAtCE7LVzJgERLvD9Re5ASrGAEKZg9Og
DiyeT7TRAS2nqU+Z+5ZYStrqOqmhocq7dqixPzfX1ilyZp+SLQUmj5OChdQQPg+CCjwJgkE5zkac
dEQzh8Gkwk/lua5eqMkMhE342BuYNqCoxpUFPGdGHCuEv1w0K+bWhpQxdII4FYYpgl3Tksj+Yohh
HjyIqix2pX5hWPWlGgDSIM7gi43RMg4v2mUExfPNLh1ONxvQW4ElnMDMF/qKP95KaPgtfPQ0Hc/I
v+m2+CV8KnZcud0+R4YRulVQfGcJQRgT7yzjc4ICfzL6lsZ9Va8p7yIOfhbfgaG3Sh5ATBxqn5ox
jF5BmTnbm0+LNPSXwyAmc89Gd26hjEOr6mQminNFsKbFES5GqSpOEllDRYCkd/W55penfoUWh/sD
W7ZR1Po2H7aLIOL5IiGW1HT14ObMvCDUpVz7YRjHehBpb3QhV8KMSghqZmBxcDndEDyZI2/zf0tL
5x3R8UeUuHbv0Hq5NLY4uOcs/O4JBGKiZZZfrC58W2zY4ajORH3CxZ5qVF7/+bnixtlh1cEcozKY
ZyBQUf1Y8W8zKNl/ZGc9DQNEFqO3EgaUuku66L0Teoe/JTf0oalTwxW4FpgHIdmhl5y+ZIBrqsBy
CeBlJ2pAtgitZrUpdCryEPRYYNhDJ7UmiOS/72Vwco1TKhj8E0t/SiheZpKIm8fM0VrTS/PkD/Qa
QOyMWybJ0GdhCjEJnlvIphP6i7L+Tb97sjhH39kwhRj+h6AVIatEdv1Eq8Tb8AFExNiZzQT+hlrG
iNZjKcC60SgqGXusIfAzsRI7ywQ0PVD3SajRAMCT4u54RbxZy5AnMfhnlwx6sshlOht3UHjbVZ1H
MBIM85XW2Op2xyhE7sYnvs41VcOotmmJDbq+tnjahLzB/gL5GHfSOeyhPov9p0CF/sZxu4/w8crD
wM6oH6ZNvV7fzrJxKauOCO5drQLWhBvHlFv/saMXZ+sj8nhe/Y0TKQFX72nkh2jwcis+Xobcs3YR
TTuh/ZLq2hGG/XdeaMamdBLBDL0B+D1Vj5Iyh4DSwvEbQIHmxrtM5WMqA2GZ0Ji/lEv6ESxMMe6e
3JYttS/si+HvkX7zze9aMcy9N28Xf463Vv8Y2FjfdqUCuM+51oFQNV9ADtjm3HEsSuOulVzMO33h
saR+ebEOaOiYqdLdOwVmu0uV4/YK3LU0yInhCSySIVYuPqY0zlzqKAav845tkY3r/X7rS4EMgv/q
r6Py3a3NVACZLzYGHIC5IbZtiWBeqvXnzEMC5UzKmueZjp5DqwFG8YxSzJcOHB5GOTbghbuBCGpH
9VV2oHd8auacUYjk9y/QzIUd1JYttBmPKQkTXA40JNoeXJSfj3ri3u0/QKtdgLF1TZjCm5Arl9/+
GOM3ovNfTWV58INgunN/TtEk3GJxx18/81BH0pFzIKD40gB3vdNj0nBmf/+OYiOJKIe2NfeaS+nK
z6ZD0Rv/zsZ7CghsMKKW8dfBijs6pGIo3h3o7IpHQp42NjVcerWfTIyeFbeDnSNytFuonZ5TKWt8
zZutcA2m1qvfKJkB0LlO4Eh566ItmV18KxxxvKhYcZYc278HtzUxX2bBYkS+iXG64avWLjjOb21U
nzg+qMX/jh7LSI5SO/04R29YoBGc046y6wKhzIg8kLfm3Vsa2/OlNRgHar/f9HPPNTm8bXgGAUUB
Cfs9ygsZcv0d8gqbWZb8GQc3c7RMBkwKrs9IS01FoZYqlvI0uVOidlsJCRgzZofPJPLHZ/UGKo+R
ON8avJd/QteIa0ZkOaZJpY8oYvB3MWvQ4eW884/7K/jqhZQmCwWmr9DKcHXKs/b/foBoiXuv7D6M
u7/HA/94wMbZTXTZ6lwYs4QuWHiMz51BtZasApUUvt4PU/PFy4t2RHPrAe1aXxGa/aTNOPH4otV5
2xJr+D5Y