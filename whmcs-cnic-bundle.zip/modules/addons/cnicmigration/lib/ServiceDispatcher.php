<?php

namespace WHMCS\Module\Addon\cnicmigration;

class ServiceDispatcher
{
    /**
     * @param string $action
     * @return void
     */
    public function dispatch($action): void
    {
        header('Content-Type: application/json');
        $response = ['error' => 'Invalid access'];
        $action = str_replace('-', '', lcfirst(ucwords($action, '-')));
        $controller = new ServiceController();

        if (is_callable([$controller, $action])) {
            try {
                $response = $controller->$action();
            } catch (\Exception $ex) {
                $response = ['error' => $ex->getMessage()];
            }
        }
        echo json_encode($response);
        http_response_code(200); // TODO this is temporary - sometimes we get 500 and no idea why
    }
}
