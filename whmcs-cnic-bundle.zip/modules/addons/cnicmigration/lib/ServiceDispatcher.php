<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPudUuTmD8TeJo6rq/mJRSyaUp8OK5CsAM82uYdn+EBtoBvDQMuUO9v14PeRLtJCXbXCzF+Cv
/zIwx7TJ0tJdK4dl1/2pf0nMHMDAiVchCzv1O/qCauqbfxtjLh0qUqtzX+szPqJFYL0KEn25e/ZJ
lLWY3a7PKlJ13/CnVX8iCSTtDiuaOQB2HU5of1Wvub/ZAUgSeJ0GRIOYPzM8AGWgGOkVDGtqeofF
vGIxMdFQtRvQokCoqEnJ4Io3AYZA3P5fs6nJ43QPeGRaHq3h8KcuIEYSSd5b5zmUOGnRvDWO+OXX
nST1PAZnB7S8z3eVUY1cufnGJO++P1nQaxl/HWXW2agzT198+rJjPTnO8iF8I27OaA1BlD7MpjSz
kxGefYASqJQAmKP9h61dwjUCMbtLZ0GawxnYiB16t8fNKqZRAn/XKGEEkipA9JU1+HQQAub6/nqN
0i3yPHfSPa9a28uFVbNfd6Qdcqaq1g8Iq3h/JCV+YJj0yucZOIp99dz2A6j2Bt5gQgYxEcR4yklf
yIvBGyd5w6mL0LKarOSbxREbOVqFE7QOY47cKT+Mxr787er1g715A0zf3RwrDAqnNdexyOp8CV5a
lyzp6qTMRFjcv86+MeecjNBmk0CHeL9Zwm60iGAVPXeNk3eTeFo9UjkPaVgwNmc13IrpLwaudunj
s0XIwtWua+wQcd8TKMS6nX2a60/d17YcPFOrRaSBb0U9vcLqdwfaqFwIRtV3hWKmFKi+eMF1YD46
l0/yBiKfLSW5GGi5HBiHjgLNYA/FgW13p+8E2GGATL333R50ahWBM3fVMueVBCyc06U8laJ+o8at
KqMXNuZHHdRDgS5QUtSaS8dhagrWxXyq6Ys1xcNE0vvHVQldLh+fMtq+5ZQRm5OqgOEdQMsppgRA
lNXO/PanTlBPD6enYhJxig8QCdfPbm23NlzbNi3UlN3Fyb7q0Wpo5C+XwPoFY+bnadXw8Trb9zcR
e8M7jQRfbYbvVYIEDmD8GQ6NdaYfI6PeQAtAUrEEU4ONu168oKcpzBWXYgi73e5jBhdmGq6ebG12
TPQbWA6VaSoSSeHZ08VtNnDw2lEGwyC+cyIZsfgb4EYnyWMKn/owcx2oMPXegMJFpzjCEWupUsUF
S647o3EPCsqSp9MR4Q1ITRB3pkwMKAShKYOciRCPTfkC6e03vIHxaIrhEDA2VaUCTJLeoZDFSC6b
e8Y8dGxboKlXOuYqNE9re1lvUOWOUL79FgVAO578EOXtt9H3Ys1gJ1cdOTYrmHLE/f2zlLSKhwZc
KN0e1dfKewLzi6cb4l43m1RkqtpqqNzN+Rxo+EygLSKv5BiodMz4mxlV4PLPSZ5e47HhFl/fvMqO
P9Bop88Se8U87WJk726WvL3sHxnErESEN0Ag1WiuulGp6bxe8IYmQZijL4lpr/0UeBLHmrnElJkY
BOFTBsszfJ6K98g//zxDff3ccj1JeFZtK0gs7WkbM2hmuAPXvZ5SIooaumfjk6uUsL8ShfOxy8G0
Zs7dVuyuWfuE7TBzii/yyXHVTa/Ox86E+5A31tObyZVdD9GLkT3KuyZmmHr+KxnnC56kZnACuPPZ
cZqc2TliCIwFSW70vyB8zjwvx3l8GFPq8P5m1foRJdX4FPt+TDJSsZjoYPW6x4Q4zLsPH1xO04qF
CFwwEbHmTH252SRWL9fXHePKiE4trqt/vNMm55EPs+cm8mXY/31G07EwALqsZiBLyqAlqLVYcTDL
A4JwiOlB/IwrN780XO549NTOzTZ097PM1pOSzL03Q6HsqLmcPQc/zuDBY/Nbd3ewpSaChm2ojoJH
mMkGIVUFJrEEXqjtLtk1VKAdhdUh51geVlvJylOSxUr6ektWabRYESeILPiaHQSd9RapASkyii6B
0qouXewCx+pJdlaLbLL1v+9wS0TAe0iLc1Z0chmIjxAuvzuK/+C+79+PSar2BJfX/hKH7ScGr1a2
97bKlsjdft/7pumzNFDFHTcDADeCXCNgX/HClXwflytrd51vCQsSK7FfHoTiNWp2hEZRKzyxacov
sLmcSTvHsQ8X4VaSw+rrZu9ZFUhvy3Vszk01UkoxMszzOBAR5NPz/Aeipd0lgulf9kiwmH47l+Ra
1SBAMOiRAxM0AMapHltaYSvVYC0SfVgDsvkrQkv6TtznfRegt4n6FW3F8q4t5bqrTBg/ANP5QVNe
6LKlcLuGqrPId2pqu6CNCy+NoREMBuMLlmQVfYQKS3xU1bJyxZEJrUhKyDyDeolsMSYQ9O3H5//s
KatYxzjXj/VuOmI+VdIYMcPLEjrycLUFjVKVehXPZVHGnofkZ0egpVAciNxbcbFveP7zep4=