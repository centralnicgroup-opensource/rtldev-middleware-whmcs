<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxsGyZqAVySoqoDd7aCIM9ooXwJ0mCACyPAuwPSsjt7W3F6HsshsBabMicacXGFmfojW4VPR
hbRoPhudFO4lgQhkt1CjDh7zPYxAeTKDZL1PfsOGh6DMgls2pYSLPOE+fBSB1Xp2WKL5kPSb6BWa
R/mTmpeuxE9XfnNmX46E+4/SOadRUTCYCxpY+bExdl+b4P0kJLA1fm1kIVy8z2BHBrHHxYeBNnYF
BZZbaN9pOLf64ISL6T4ulvJOI4/CLH4qCp6sZD9i0s3r8Bdvcc7vv6pVtxTcZ0N5wM36Z5Sd3Omd
3aWR2RX0M0rRdfiK5vjhGM4u3j4bJubNlb/IGsKcy+DsgysFzl9DN5bBOfUgU0wuP/MOGPSNjyu5
iW0XNOIQ54LCQRc40FSgwjPu5EFZb1kIbr5u0YF89BuMN64sBzsWvOES/HXI7t5yFGDegPF7bnGz
WVCtKeteTrOEkKbGvSk0IVDRE8HoDXLReBezMi3AgcOofA2K4fKneGiqfiDtcx2kXQ1VC20ZKUd7
r96uHHh6oSYr0vykhk7Mht54INtlnKIejD3yRigNtZX0IT0RDRH7BpWMH/dHZeST0KL89laXkQth
INkKs3QPWwDGxSuTHR8XJe6qisIwuMwHKDGHShVj9wdD7J6VH+4nrJN/bZaV7CDN1DIVkE1t0XP6
rNVxYoFQUUDaK1vokGEbtkDu4UE/wN9c1vxPnAE6pgYDQHvXDmfmvS/jCZNpuo3kqpSYqv6ZQZa6
bNeBdf2IcqauC4uvPr3V32H06fSnBBgiqbdg6T7qr+Yn3QNKsnFsBTnUQJbrqvGd6wB/zm80Ajgh
cyFpoZ+Q9f2wrRgUJAmITvgiKc5TSWCm73lWT/K9vJRX0CjzjGpcaD0LG80Kbc4Mr37taWJ2ZQn6
fjSKQeIxy9DtNKwhKjC+E7Gov55uBaQOsANfzwIsT8DvoG5nLJwlD7SUjyRlHilpQOJzGlrqbh8p
S4rz9x6DlvX7jZ/PC8rNmoE6IaC1mt+UWJLyhxcKX+ks0HS7qPP0t7ipQGQh/sV1AXKGtEpeS2XC
Dqnd3hA/afu6JIzaieRa5qfDIEamafnJzsIWqNWjPmHto0ft44Tb0BdZFLmz2fJw181vgdkK3crk
t9pM2vy7Tt5wpp2Y/d8epzEjZt7O5y8tFo5NzjRXscRt3MOdypC6yi+GtMHnBwWNi2rWWuz3R+Ly
Fn4FO/srAHNNAfYgm2mfgVgJwafT7LuhsMrwgS5dIs9LBImbFqsgNWFlc47Vww6Ko/TsX5HZ+NUI
ghbyKfcdoc4Ytz1ct9/BcXCeoWJzFP0SPjzzksV3cMe83xsXD6o3RM65SiLx5b3LGi5Fv2LQQ7a1
wgna0PqAgUh0NT2R4WuvcmxmGtaL1lX3YEsQwdR06pLvMBi+ig/53xtXniUJOl6EadpFfM/yW48/
e/HwE9pwuNC7npw7X37MZbLZhbWKNEtn+bU0kylXSeW0mu5sT4wAlbqMHMxfcqMPFgm9XpjGc6oj
PxnK3l2aQuXUekdggTR8arLWdvSBv1FEwjunOSFMGbHWJk+sMqFOoJ/6LGTyNRnHqPt28DJhyQ7r
yOfFwE9421R6MtPsYuuexQFmsg0WuyeJaUHcBU6Z6oDRfG5v9LHEZ8IVdbEh8LF5rLwba2juCwUD
wg7QGLynjFMttqG3NqsUZaTsrl1RHm8JOimQeBnvOrx1sahl0Gc8UUsZxO9oNEiAkH86BA3sx1cN
z0zZP1CF5xhmBgl2YrSQUcnDYai/fAjXWIekvcxNNXbcC2h7/HShgZ1kyPKH7WIJT3/VNRSmBg6h
D3d979QhPt9LoAb8/4mBRwE9ZKL8GOesrcQAR9zrPvrH9/P90uF76K53QQB/DaKZq8RGBz3MHtxz
hsW2/HsP6bHXzIyRr37GGBvURoYgS7BOztWlYwb1jdexYohTsF9OWttT1f5WeHeasFhVnl07MdsD
mpYC5hxDTx8ES2fr+kJq1jQL0nzqyJGRwTvyumUbfKKHrEAEU0nVbjVFujOESI3zoHpzOsd57UnC
AFw1MNk98bGlqPJf4j9VyE7zfcxYiibEPv9Vmqc9phNoRN5t0bFFKClFC498D5Ykb/JQdV7oE5+X
/ZxlC+1M52PHCSZ6YD9DwuQRPGCW/wV7Rm3j9v8u/6azX8IvvPHaEurxTmHIBmXvCXWS5bE3M6Hv
RESuCHbv9xf8ef7MK6E+YheOx0WlvfgFS/eDeWKoDwPZ/vwSwBtITtDCY7awCh256BhXcly6xCKV
3dP1jXQRXSkJTZlJcU6y3ObrZiUXT5e2cutAXRAUVoo20sE/QvbgNBflcUfWdyZ6qVzsPJc9b6Cl
Xf/anLkGTxh/6lfLy0==