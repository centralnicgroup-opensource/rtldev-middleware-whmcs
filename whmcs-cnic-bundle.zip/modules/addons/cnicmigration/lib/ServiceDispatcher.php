<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPynRmrNnkZUQZEXMTei7H7lCaWNkYmJbjfwusPxrqCKxuERv99KtB6oRHhseiN2zSUu+ofoO
d6qtGFsbABDgm92dn+zkPSSpqIsrsFZw9gM9TcxX12CdFdXTedvXh1Sv844FrcUmTJaUPawaZ1U/
BTS7JuYsiWfLCYyo5Wxkk7d6Wc5IFuyzILUrOwRMKAd6YoUKzrx0HbQ+TfiZEyQ/Y1z4WTf6MMuS
Sz0dWzkPZVas6EPAwWB54qYD15amwjam32n1hLmNTQBmEO+CXpAnqZy6G6jcRwhQgvf4+P4aN0xe
PcTZ5p7XykROJVLtoPTa+oiMf44f4VRsiUiHWsLyAowEoo/4MsiJfBtxJ+ZgPaX2/N+mQplKUqj2
jC/uidoa57uFlkL3IvxFU/ASm5gxy+osDVSnNDkJbiTBCtqkHhsqjdasDbaAcVm27EXLKSmKIyNY
JhkOncFJarPJs4qSEKdz+94TLzAwDWmh37GKJtFh5W6p9b3RSUTeXvuIuhFHaYapc37GbNcsMDH1
qX7r+oF7a4kH8L++a7M5KCHt+tKr94gMx3h6MukBgKscREj9Eb8ztAShFJEFST3+Ta+V5/2CDDev
SCuzmXgyhfq+Id/4G1IFxdEQuJjZRy+9Jra3J6TGGDrckeGdE77skiv6jYBLX6GtYU7vEBjVwKPd
236/mSVdMnOPI67t8COlnSz6fs2ZIm+ypkykplusjQqp3jrGv7pL1OH4GpNlhnMg9HcdXUR2NBjW
d3bUJDuhgmZMrK7YFHmr4r+AC8kbQhJAr5+WsbxfTQc/HA998X9H8PIlkPICqPCGDxtEqMr6MCcN
hX8u1QEk6Cn5N0ZbWLVsm6PQKA4OGuq+KLpEvc3hCIRuNxNW7nfRpy9JlOkFJGTqcvPTJ83Keb7g
6gy94TAYAMArBimMQAo7agBHSnpqkrIDYS/5OwQJPNsGv1OdK0v/8Y2ZoF/49GNg2HkO7DJGn6dT
aIPQ21CpJsDjKYtrUdR9iWtZTIU41yZ71GgsltmHTzLAxF5i+ssNgq7mbrDTLuALLcGdlTS2pOSf
5QtsnRJP6bzCjVdbpF6v11+0XlGIK3gzO3es2I4P/rJvDpUPfeI9wbnvqMTkFl0Vt/oKO0i+k8rD
DHDHwe3fXfKA4F1AajGEixEdcWKZY9dATwCzYMzDKZD0kw/DdLgq3Xs2ppgo2IreYJTmOeLC5C1r
ILCVDNDMENEm+EXjHmxFE5NoxFX0/kJDwH3xFlXwhqjNg9qwnK/vih6GW5Hh4NDss6HuIXGYGj72
68sHKt+JjJ8svjjN9fZ45oO9GgzHkT7zBR+nMsCjiD3PBjF3rqKUgVCbNR4T9uLfcncAo/zZ0p21
S+MMM41C8qoTe5kT6LfmshI++T/tAG4Ub27J4vtnCTUrCXmC3A+SErs0VUWTe9EyIb5XDAL4JkEA
Dggr06r94IFl2NEXExIq8d5zzvTKjoJwd69v89QGPZ6bDk2DyLxmGpAUlgti4R60YSjysY7TLELZ
grvnayKJrdYX4WE9udPlqSFcLC8w+yKSG3R7dC1DJNJ+NhHDJvlGE3v7VMsYSUPNQ+aUqwWIfFyl
vElqN2eYGLKHInITsoQN/yoRzZcCX5L/FrkC5bMAAUHSwZ7WPdXt4YvEVSWeSEcqylzRyXh0NBhj
NobhaDVMraaKpy+gcU+UaiiBCpl/i/ybYPsy2ao8cLNhBA0M3inWqk3lIU1e0zyiaNlTVwZh4JY0
reYfMZScXoatVMH4Pq8t0Lee4GJ65ytmbeDu706aGVuLiDj3F/5QwbUZFaUCrxFJpNBTv9Z7X9XG
sGdqhat1gGPs4loxD3XxYg3c78PgceaQC++eZRNC5mVpj0IOWR1EDkvMFP0MJl0kqQNj6Bbx3YEu
LrcM+8jlysEffJeCe6PynJ/ebYBJO4BRgM2+yho2+XtUVgewYgT7X7cwhTC9hL1KvwB/UG7Eg44h
rDjw2DEl8N6JktXOaUdyaibhAEF3jTaW8h2l4DtiCdpvMAGkOnnUhO+wgrbJP0r1Ik7tVGGES4GM
am7Lb6iuwdsG762Nm1UdrtSevp22yjuhoOp4RG+P2GD08NVxDJyRuSPijvvJGMDsJg5aDlVAypYP
ko38oqcQ2M0YcsG1oSDxxrBPRWSQa7JNGnuNZ2w0iwi4ez/G8bKt4KXjKc36iLXWPHvalK6sRGPt
B+MCdBxGjSXv4CDCugg5slGZzONUfTDcLsjpIju52gE08VF/UoQyBG61mFTOWkolINRxBzqDrzrf
JPQzos+2sjNu4aOHvgQhC2w4q0ljPRje304ErWMr4hT+843BK+wF3CjYyyNft8csqFQQ2m==