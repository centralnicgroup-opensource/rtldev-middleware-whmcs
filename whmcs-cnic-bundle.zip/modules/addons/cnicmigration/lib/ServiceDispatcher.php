<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpf1y72EhyX7L/9bKvwZmXWjNack3vnW0R+uTQaCqhAwnXpaJigcjvAEjOdLMA/5Wx0GfxsE
L20T24z4zUDKvvRemWBvqrCpFxs8e0ot2CAKOG1bPx4OFc/4qoDqpbTUXzg9fkTyUnLkxq9LqEPN
g8wD8QKulAN6poJm9pwmKsXSt183jklpexV7zLxFZEF6IbMm+DhSbkk6n+l8SwxxDUtgTyTi5bQh
8lMmYpqtZ9lDFJqIW0w53aeeiU/p5qYHyb9Fgu3L3W3OXwtmeEhzGSlm2G1maqb9HQBwisEN3aP1
36STKXffMt+UjBAIe6jxEb5AVfB4LvW96eDcfWXeHTgb0okbu1bsCUjKZOSvVV9s3fnSddPKMP5l
SaYNlJQOIET07egzZP9IUSz3w9ZtQPjW7tfMB7ITA0cZ71mCajrduMT3oS7udl5VzKpDvH0LBcgr
Qv7dnDZ2kxEkejqdXOrYCJGPiyjG1l0ZrwSus94hj5dAuGGq3RjXcx6uLBcpzPnGbsS4HPNCbkrb
/FrTCVPOrQ3mK8O5vmWJQjJITJOkNhnn+E1m07Q+7LfJiKFa1R5LsYesgt0v7dSYrghclZYPxjSE
2t+QsMqSp8hLXfFKDcH+oWurc6+UCUP788daPGWoiQVCet1j5NtLK61vBLF6IcYI58iKsHZvCfzZ
EV7KkbouG0z3aXy/nOYczXa/i5S7T3vzslIyKnzX7QQH+CxtyEktdFwoJaDfC/QvV9YUo1RC6xWh
DXVg5nnUaOckBjwXFTqR3IuItp70/1mGqwdmXzxZ3vu2hXdzmfwsYFRSHR+dZ2cWO2hR2ThoBB+u
gUR+Tzg2sGZqL7/t4qLPlo5SDKVjzfEn0LLlLLrOriO+pcT3fun69cozar62LEDRshybYfFWXf8t
8uKhogZKZpyGMUsiNHb5I3LoPzaMrICEdS0OAJy6A+Ofx6+WRnTkWDQpiIs33qWbS8u3F/FG7mWG
VWNCcrpLREzfYtv584cXlcqIhOdyPUNDUY/ICCWRZtiDuA7JI7KIBeKtwMGxApMTXylxXgejAzlQ
s7upEEdv3BpMgIOpAHwcqUIx1pM7IYBhbO0tPGmpW1GmjQy1Ux0u7scLP2TdikpR7dIr1+ywOE7Z
0ANdCRCND+hJm/KrAs4i1Y4IOe/MEQvgZS+V2myDWdyc3CFNxKWWBv/9ggOQ3KYUNmjqvV07hhGA
85GdjfJdZKZd1H5N/n69/ZE/dqWjXd+6V8sQKcYqUJjFcHOfUbg2b2aRmXOMue5g9Qyc0f5UcVZb
66LO52nEx8t/AKn75lN+UItKpnLdE3tOoGGoSg7rIUtXT14YsyLq/J17vsCmJ6K4B7wRl8uH/CW0
BtwDvcE6U0v8uiC7DcCnx6SxT0xyG213WccWm/yD4+qrzlEzslfkSDcVnM6p/Af4hyraY1coLB90
DQxX+dmjAn2GLLkoGcMWK5IXe2vfJ8dSLG0nipr9pbyqTGHRBhd8fYgRmhe/lc6vaLyHNcbQjGss
k1KMg5A/Xu/tUdz/J2hsED+zIGV5imwVFrjcWQP45Lg5aEpgGn+OUwR7XHKmF+NDXezyVSUXkwjh
EIlo3GMRp6rDp1nI5DIiGSI3BOjrcz+Xqmc/j1Pm3wj7bouN3xkrRu5EVNrccl6LcadNNKnDm/3D
WCrlZEgdsGyBkoSMj97uVEkS8cpCmAok1Tck5zHqC1Y1rXH478M6X09/RuTXOeZGQoGA5Geb9zvB
Sk/3cKFrgNK6x5ZlINy3qDW+ohUE8ezlgqzjvn2zGL2izhz5/ICCzR2lZHaRB523KD+urnh0MYSB
H9AW15UKSNExXARuX73W8HHXyJqZkgoUHO2UC+r3YPDA9BT/tnvPLVLAL68+QOb9D8vFiaYNKtbR
haB9wQJLl42Puwn7sVwf2/QDmsSt3T0qHIlv9HwhcaJU8mHQahFdaemRluAa+MH2iiYltn3VZ0Pw
CYRWOABitaHuQpxV7IOHcv/Q5HFu1Fo5L1CNgYZjo0aKzd2l3clNeLSbHWOewToth+U23P4ZdbdO
Aj1VCfyQAPEqTgwi0OVa5boFZYbJAl+JBRLULvCnM9mlba3hMJAcY2VMqiEAvvu3fGgI1ucLZixO
5K8/YFN3gER2mmq0GNJSwGCXfa0DQo03RDFRhUhnaL26EQGarlPasYIU+mt4+3H9fzIi2Ngm0i2W
Rhw2FllJPNE3OpeILaw8GsLBIj5IZiKe0GSqZH8CD4cp6dVPHdY+s2rRN3U+TxdI5OYGaKguGE/r
3FIR1AwU/IB9KBQQXkBNAWlf4alqHWSScTkCOdqcRSdC35x5YyEhVKRHInTyHkXB+OaTuBNCWQ/D
QH2K5WiuW1PZ2Z6bb+VDPG==