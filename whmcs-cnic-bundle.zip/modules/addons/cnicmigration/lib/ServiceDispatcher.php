<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqDUBI8bePKLCEsu0V0kCgj84rN++ErqozbI+J0Dwp9Emg3/tNYa4+MHR+dgSh6vbfJoGYml
29SjXjRozXv/XkJjgasObhmUYw9SRRoJZo5qUCAtXpgC+9uYzNwDSontz4NUh82O9tlpQyDUSiOQ
UzNRFuae6CMmIOFbsTZsA8y2mDM/PtCYmOAwIYwPSDp2flej6MU2gLdDgOeXBkyaTpNeTZcyBtza
NdzW9Qia2n0BLPV0UZSZ86OiNF/elkSXy4XAdM4z6hROm69tXjvnWNNoBHCgW6k0w63cABhwLsR2
ZI9YXqaRQZ+mW9BlCuVl+ldKVD0q4v9g8n44AUaF0aj+YKOOusbYbFqey4nLt9DRAotaX2LMVtoI
VSzDc203MQY7oYOs1rDN4RsKmJGnfI4RZxeb9n7h30OqnrGtXtq17Ij8YhUkTvP6l/IThg3GD+N6
ZIcce5B7BG8qBJtklTrjAQ/Ivb3KvS8Lt9do7hl7WD15Ug4/zowQD2rtptszK9WuyipdfZNVIljH
PkDFDqeP+xy/Pfef4K+bKqBoS4SapBdcqCI8oHg4oo1+/ss+VUwGBGxmcASCoplLaDIighdtU1jg
ATTqTeYXG+bi07BF8JyMyfXWgxn5jU83LETrE5unr4ySEaaRESCntfqFoTY3GcM1CDRLgYx8OEJG
s87tKcSZHIm6cx5Wh9HGTz/9keQKeQiwJOzCB/wfZWApdan7/cL4uRm9DMpWjHubrn6k8hsMpj7g
EMEPTPsK0mCM1ozmmB/IRqgUx1OT6cEqiLlR+8k9FvSAhkbGaNB5rvvHuD9/yw976yFIHJyvg10p
w6W7U1MFjkXnQGgpB/7mIYF/snpW3cV/IeG+iE9T65t1LubudXQiJLmmE5SNxG9VR/yZuatWNLpw
yX5uv4kPRdmfHBymn4qLoh7be5054iYrm6K7MDqJ8UgYoHC2dyX4FSDgcQa59p6XL0kS57WH8RC0
njnwMmUnjmNKlex858SW/m7emfG3ELSoOBK2DaiWR+UTYmU9BByqLaES2ESpd3b3abCdwCKfS93k
MNFWIlItUcu5qrbtgGn0zwxHDlr4l5nvBvWmKVOT0A8FQwpYZqfLVB4hBhGRZabC4xulFKy+uoFQ
swhwpQdckb6zsmFnhpBYZhK/z7Lw+38urGGCHJ/ES9g/ib1ZymOTJhJpHvNGJadDtae2X114Pqx0
eoanXDRlnMekATpmT9HhmjYfro/Q/PWg0o8KavanU2QdAswCAJ7uCPLcO+TGO/iZK6KtZ2vuSJzn
i7qaay8WIJInRhTUnSSJwSGcdvKbIE1XCEOwGPK+L9F2QqL+l3Dw64zYdcd/RxJMTDiXNdVWzGy/
Fkc+x8IofXgCze3RZsl3JIn6WmX9hWXQdadlJKRVZSTkunWRpAWA5aKPYr6F6Hpl8OVIPzFglWCk
KVJmkxzKVFyj1k1R5DFCJTGLEOeYbMJ7IrSQsHstabFq1zxvfS+O72/TVG9q8uAWE48VHq3V35JK
kjuqJ/URH3j216ll4hzCKskTQdkTkDee6VxuileLHgP2bopKqLLxB0AJrO2AyFroKJvykHAHSI/l
XS1z8IGQgoRacFc07htYhwiI/nBNVkUKPlabJHhxp/anL5HEAV4e6JhKVGRJVojV1PWlDjaPq1S+
nR4d1Eo7t1LzT2BFmTW52M0TWXGR09osa/EHow08KL4uxrpUW0wkfQBkjbOLDHcJ2JuXuTpF7S3p
jJQsxZZXAg4RzFRQM5Iut+OLcMWKAGgYSJKpWOxXQV5G3nM71pPjgR2Fw/E7oZXOgIbCMVKZeas9
YInqtGUoOh+s0hanppaDqZgNFZQFIjV58UdZ8FIKDwcnw8up0hpbt3XuVNvKGxmRnB8cGSYWjNx8
ziZsofiJRCS4rFlAqHIbd7Y23hItuuN6660sNc6t0lkE828lR/32X0ag9d4GFdZy5BYAPNESnesx
XXti0bgClpefcFC/rkEzWwsYwgvBXRjLHXWxUTGFdNAoFGDJCLq6A9J4DcxRhgsA4K1Vxl521368
NL93SE4cpEW//rERx60Q04m13sc+5wQrpfa1BGOoewh5ELt7z7bGDdrcjme22HHGdx1mHv4GiteK
ciTKFy7nJL1Xx0/tYZiKrjVSm/rqphxOvTR52a1xuuLk2FUeFVqb/IKj9tBcG5oAPTXlEd2Uun/d
uKBd3H+sxPemtSoTUN9B/dHzwawH+5kwEOpsmBzHnAYjNQ+v+zPoJ88gJ6Ic2TdDquHwYcgWE9Vg
Ee0wuXhMpy+ZSjKA5qwqGT4vO90l9SLg0MQMxmD37hYQkQDV4c552xQCRUaasXVlQJeqPprL7co0
43Km9tcYv+UpC0==