<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrPKaSHMksdhB+S4vxhnosKiT/7/L91U+F4R5J4opHpQSeFQEoMV19lXmUbNeJ4Y8fkm+qPL
xdq/y71N/JdLD34TFZFRjdHX8Ei97IV857ZyT9QwljN9TM4C0mTJ+b4F44t6Avhvw0/9WcqZ1hqL
+16/7iEdoe1dcuN0sDBQLlRKnmvntHgiIIoOl9VGu7C0ZUFDv8avcKa3Ir4vRetXAIIHGBpk8x+0
gZiAKKgHq+6I4nyTCUO9I0VsfE/fkCjqgHIAT86+zJ+PedukJPKmH71Gvf9HSzzfxj1QOWFM+VtI
sdejf+SH/utsz3kOwQ09aY5ldy8Dj2ZbajJhvTflhf/VDLAAqVDwvejXm3HHuHEeQ4knsFLn1TpL
FcYCrdDxejXCHPYtY8eRP7RTDcw4Q+rFq1R1a3eRpOzWgs59ta2s5JimEYPFNLg47eOZHZB6cJuw
sqRIQI4UpSIxxKZ4xroHrHeAAVprlw5ZimUa4kh3sVFZLSwbFhCFMWlnq/yPYW1nzIRW0AGKOYEa
cv/52D5XTlV49cl70fgxpQjmyvDY6zBtzf145VoV/00achmGonLUcTDqjdfEnop0tKDwjSnAoW2X
MMAeygYSTnm/0z3u0gaPAVi494bk9TUf/e+vI6f62ZcLNOsH2VvxC1mEmAsSgfQPIUrmbCsCTGsw
47fNb5ici+IJgrHe402Ygq2Yy38A23GbdZQWWlG3pzFBQpR24AUefeb9Vlj2DrfBtcQ83Y4ZPYSM
dS7EKGaMxYu8cpQ5UJfekfTuc7CA+h1wutF56NP0zd4+GmDGbdCG22U9dxlDNi17Cpb++SrfdbQn
KinsMXAB/h6dHHUJdynb74htSNxSSFNyS0SGYkjKREPLaobG9JCLPdTccDLfEnpSN4MsvX2SsZJb
veZ6gJqbc376TVxaC2wa2DJ4H6+Irb2ObpM70+1LXTCQQMGiLFu2ckId1R9/0plgukGnP1B1OC+u
EdhnWzYOxLokwr8QAo6kjWPp2utxA7i4CkD/qVnFdqc3ReQ14J9/yUAjf0WdhuKqw89jK3eo8rRz
hUrQtPPWnv2wAGWWMxHjph1eniywjY+ZRfWr4H/Ti8ca7UrpzeqtNWo5i6ZEq+e2Bq3J6oBSl2WL
8+MTYQePPSN/hTUhEFFuc//76xFlmIF4iyVqoIa/eA2riltApq73pjHODNi7OG3Qy4w4qcUb6EtB
cVX5W2Sks50ty8FZdFbMKFmYtLNeC3NAXWsWpw+HjZ6kQL7Wl2RDdzZcwhsIUd980lItp6raTuMn
wVQ+PHaFAMeasoAx/0E0op4zwj452wvm/458m9A4tybNUGFhb+cwBp/5INcUoYj5vbeMC6rCMjxS
VkWpHTsPU8yZmfAhS/FLCFh3RReSxwU7uiHGo7DmfuuZtjJTUwzQd9gQLXjWQ1sFyc2/d60Pe+zN
2nxCNr5/uJ8GiNKL/xICO3Bx/mWOvrlt1L6syEECL/0rcT2+3pehlFmmFRuJY4GTmLNlB/2OuMOm
J/HuSCDd1OWSp50OuxqVpFeFfXKCbBkXg+ZoeN3KVUcUUYunG1fA4NC/AL/4s/3jPrx6qFtCsbRe
iTvls6GpfB00MhCs27srL0izxMURTBWfAyiBvFuUA5WPsHOwdSVTh3QOY8Y2mb1dyklSguy7ZDoV
MTch2HtQpWPq2+QTEi1sT9eON+tc/skEhshIDzHyrmTwLuSqcaKd5a7qJCdWXvl5kqZaLfQllVrb
Da4sB3EuUbXfQuPFaNiXQaNAUvEEASfFvxVWV2XZ4dea1KYF1aCiCyjbyRGClDFZPj/xrfwNxQXk
zwFB3ilA92mZ0A+5dNBIE/IjbeeUG5uEvQ6SjzaepzTVfZEEmV2GyjwtxCluSYjCdGOkX1qk0nn8
ofCmObobhZ6nPuN6IOPuOEXTakFO3KXy3ix9KkQUyNj9LA6bsQlR3kFemv2lIPhXe6IzPUtPHy7U
VxF/8GDm1a2xSmVIOPilv3HXS2lg79+1rCIwA80/Z7fnrZFb9hikc91+pQu+vG6FX5BfIHoMD5hl
J3hmeLFTBj4ges4a69dxjvSiYFPaeV5HsRE9Yt23ffDKdnEW14UHsAHkwOv1iUQTWN/yFSPQq5HR
UznUXYxBCyE60LSOO0I8NqK6tSzIFh4qkVmCG6HYVkgB+Pq2AnM04QR1lNEenxolqJrii7I4JAYh
mjYQM8ktQ/Mx9z+Ke1Sb4iDy+HOlU3rhKciYK8Sdx/bx5jCB22Yb94QpTWz5rE3Ah6BHfy7idEA1
5klhaqVZzvfXCq9wD0Ny8yoRwOiMk6eqcmkqY3eRa3gafbJindaOjuAvCS37fbo7Nqk7HrJa8GYf
QmkSa0==