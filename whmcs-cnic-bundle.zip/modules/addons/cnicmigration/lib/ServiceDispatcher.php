<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPosgtkI2T2FBMnbBnzjv22KBm+AdKK6i6Fbx2EqGVK3MPe02VG9vqKLWzoO6Uwa4m+CSbc1N
sTXco5o/YQ08N++T9T7HPex/p//J+lCYne8dFjfddE1NV3kfnNxxuHcv39QIoRGsWLhycqeG2nrZ
qFY8TeHrZlgFeIRj5Y1+tiMbx7LS73TXC6iogRHg1wKXpnh17cPaiZlpQlDQyrmBSZks4bU6QjNo
2vVe49efVKrCuzXBaY84FlsMXDJFWxpW3ITrxaJ4vNsNrsSO4b54C+Nktv01HiLgjiULx3h9WB/s
Iu4T6mSJIwTJi54qunmF1sMIkA5Rl65EbKS19Vq7i8dhaJinArDaEANcZgBXsKPCHhXZeg7QRYfA
jwu81hUkPiKQ505ZPTIFlZ7oB0SlphpXmPCGShF8TzhmvndMXAGhUwrSQUFbKGl1eZI3By14uSnU
93E4n70pP5ohb97/Eohk4+qeBYaIqAHONfmEjSDzKY4ObD+u49IZ3lja2uZDZakQ7FR5PHkfaTxZ
2BpkWgdmrTxok3BLN/NV1o2RAOHgf5kJngaZIQbCPotwl3jjgK78I5ovh9Ja/JtWzyxBqoP9obO+
OK/2In/IyLH8hOyum3/5m4DtALLwcGYrBjcXgCwYqQ2v+eCqdrF/WSCxuSUNKC+MbUI//mTyGU9A
te8k569D+XsyyUBMjkGU7kbyEfOLYEuqjvWRWe4U4VR9Xav7Bcy71LtqUI0LyoG7qFdR+EYmUYfA
TwM8ilrzTS8x7JVCzPeDTAG8l4mIvMy5wdw0nIPnPzh4GZ/QoOBo/X7ulVNl9PMDPRXXy8w6Ke7V
YQ4TO7YpZVKpaxfDlFb6xpEcFLFSRd+WinBajK9qQLn3mlwj3hXa6Y8X2MqAjbFgmMoB37Uu0cNQ
604lh4jLNAh/jaj30AhfidwRIgOSNujKY79pgNjiAhJTHqCLduF3JA3Ux2QRaBjSz1yI4xqR7eD4
VKON32ITkF/rN1b4sMux3n8H5DMEaQVLJge/uY/g5Dyn4Vpvd64kC6z2SV5qgWfgpJubwsutcqS5
HAYx0dRa6TXDlpUwLzevgK6qS1QvgGdqObM8K7FAa8vK5hJYFdlmYYf8TUj6qB23TLS9LAWeznA2
yC3l4SLjR5Bz2TvyZpXSjQnrozmZttvOR7WSlH11UbD9+fLwDnVunRT3KKf5Nx2BTNtlST/rASTF
BhGInNS15voJ3wV2J4Sk7yhw+ArTug6TLX2omuX93+TZDheto5hkK64kwtxQ+wJKZ8D81mRWs8mz
4qnEZwkIhQp2p/41krtOC4fZ00sq9fPuEf5021Y+J2Md/EER6yoAv46hkzD08drWEwH1XlqlKDfu
LlOwXhTC5w597D/16jofnyrD23CFFJ20Bm/S1O/7VXHk0AfKyDxA5tvyJXjIWZaMXFwvVZQS6GIq
ibLrP8JErMOgfY+fvkgRqq4gVAG5zABcq5YabbDSBvkuMLmbd9hTo1zOx4HNZzAF98yfzBRgvkOn
KKBRirBwwuu9AmDNzen7fP4nIEiXIxhYA11z8tggwv4DdWoN3yTg5bwMclGG4AOcdy9wHG3Y1QhA
CXoicobOjl8tFPW87Zc9PhIPFM0P6Zl5DRWaBGm/gr0g+ZN9YCx2HWLXb1AQ879GRL00ZtkliTKM
qlJB8Ayvta7yBsWezpvSOc2HGMt/4qBjgmb0iqfyhbYHWnMiKaN9gctMyzqiIQqqAzGtX/dggajs
M0qh0QzFWIZd9MCMZfcHnNlLOVDTWbLjfUfmMPkTGBNSwbz+LLj2406RXe/6tuhmcSlIjBRqK8Wn
KdbHlnY2L9J3oJNd/CHVTJuToji/NebeejK9teK4iH4N1+M5zJSKhqJ4PE/6YCZsOuuJztxcd7XI
4e9xP5lB+I2I+KPTLHTPXosXfTOW8yExHHZdmuBTBPcfIADERUF2UfGRp2pX0BUKgIQBupdsMLBc
pXYOMn9HruwlK/Fd/oXVNn4jJCyTvxLS4ds9i1nvVj7hv1EtvWxvrsnTZKzWgOkXUkiHsnCRr1NF
Prd7TfcIj46szniwNtYTVSyI0xFUM25PSNj2NJy+VaUIfgCPIWHeIfX0JvVEEi5Kn5BSra82KV1X
Nbs+W+wX/IF57+c5lfya1O4QkblutPVkt21OuvrIgBGD7dbpV2lMvMEyRCyRz9FpMOSK+lpbBWXS
ImNEDBUWWF52Lj9tzuq7i/MfNzUt+h763JhF2yzP8/Ak7uo0vYONBlxPFr/b9XpM5kvJn8J28J0g
Xc94+Dm6ZVvST2bnTRgJrFdTeahVFGVKLPQ8mZ80SkaR4U6HoblH5peESrf1IilRgQ4APe0C4Z1N
kSFpRwm=