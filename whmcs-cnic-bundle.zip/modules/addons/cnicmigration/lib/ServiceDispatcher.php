<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyMVM83uPg6tXIpDewSh7QRIAe3ZFNCTPQAu3Wl/qxzxo1Ap9hj63FS+9GzShFM5tzxlz4fI
4YaQQ04qXXAd5V6RsCGqWAtnG030656LzGELxTMvqNyJXS14YejmJfB7au0kkyjAT/zwfLwr4xYo
ug195RwwEHgWFgEIkC2Go4vn7141l6KFab4mjOViZzU6+vvVCd6HeY8a9FSUkmNNqtggx4RK+1ex
QtGZqwTgIq37BNaO56e4r2a044qo3JZo3LJHgjBlBs8+zPno1ert3qkNOynam0AJoVTjqyNkFMIH
9OTj1G11wQBwZLKVG7Ny2/ZPaYnaHdiSPCsIL7lKdML+pwFo+csEqGDz8yBMRlpnrEJ1xyG/8g7A
Vb7M3W/5LmmbS/TCSMtHPl2FxX+VQdIu1iFKqA/IWy86IJybmBzEvSjAiV9LADCtU05N7RC0mLuL
0tsn91DTYaARsEhLJYy0uNC+dncUykZsuoKOd4Aao0l14CHZ59y2d5jK2elaHKYih9vlch22d3e7
wlC2YeMz2tTE7GAShonMqLotIP3qj+HUwAaIHCh2dpDyKSyJ2xHzt34jt5RCMOIQ2mJWiGQ9+Q20
zAPw7MXooAcV97H8xhDnUZGtEhH6W3c6Xjuodfwj9sjXb1EI0mJ/DxrAyov4pO0MvEc+7Z0JJ0Al
RVQo+U7MCrJd8Z3uesBqLWWCyprtgmMwOPtRXCjG1syE02fJhM7KpVwmA03pb0ZWZ65GjJ3wriAU
8YXO1uvjB6fLLENrxm3MZlBTqI003nG4J5sQqRtw3czySUEteWwqXiHAGNJnVnFo406jojbtc3Ka
vkyrn4fbxeJ6EXh6Kv9dTbh5Y9OAsRbwuVWRFNK8UCpGJC0fnIbSdrXFJBBbrChs4/A/hTnZ6QnQ
C4vPObdAwujGG0GW4ICRSY4Sn+wgRFpD1ROaa105qFmPY/oqaZ3UdUVIu3OvEGUO4i+smaIRwTiv
g62YY8copm6F6F/ESP1oIbkoxTmsIujxh8wjYMl/Fks498KvQLsAj840ivMiHzdXrzlUSg+USnHD
P89lxaWoTL0ByJS2EF4gd38BNSErKMkuEvwss/kZpTe7KQj4lLiMy7CMyAMG3A/MaUtmVLPbRjEU
myOFISzHzsZR8QcFm5SQo/AIIcf4kd004atD7TlTij8+SQohlcce7JB4V7U6R+olqkNgeYClR7HL
x05i5vxERnCUvQVc5G+vChqxCgsWu3gVMdDdeSXI++22Sx3/NsKBwNzwLKqivAieW35YZJFBAGqn
0T1X6IR2pVQU4oZTBOce1IzAvZUUMVhn+XAfJczRnfvher+LQQqZt1cOQlCbXIXodya29YgE6UU7
oNaGYpCR1BlbkIzROTqr7Cvz/0tDeGiDcB/yRM531kW7vUkdHD1xSOq64bMeXNVzpqeKEtPGlxF1
VPHzeOp5rX4kzEjpSRnojw5lGW1OijAilj5efSIbeAXm6WV8ikdwqObNMuddn9cjCBVO3U/6klIY
qzCJbZRK28OdwJ8q/CK55ankpzxX8csOBU+VbmFKqwy0BuKXGKY3ap7MHkM1N5bpcu76kL52Yhdk
qctI/w7goiiJ5iZ+u8L12KmUI4QUqX2nUYV2nH+Rn56333CYkvcfyWBSUibd6JTPMbII6E4BiWV6
yESVZm0hc8WNvQWwd5hKAuj6hYe/1C3gvMJPWjx/60Z2N2P4vRNLbcgsw2yNk5c1saERjFRAWzWU
V+7S9aN3PevX5reL6pPOA7R15PiHN9h3Kg+IlaJWi+4kakiNSIuFPFluZT0CjNlwxaUUdsNfhlTh
AF/SyTE48LRunll2D62KRnUhM79TRkAM4dqLVX3P4QcTjU8BnLWU09KcAp9G1K5pu/dsRZ/lfjoZ
84w+VE1fWanS6JNrh6VC1hTYpmt/TNhms0PEUEl1TRJBdfw5pPVOdL9PuE3kqK7Ob7hfJ1PJ6G6Q
3tqdOwDzU3XuR0RaqKNBS62hy9q+bXQ9UKFEDfaCDkqgSQONOtAQDdo4dTu90kudD+mw9YvTQ/mv
baWTl8BlJuEEghaKIoOuOHlM12VkyjaxcWGD5htbgMS8PWC635WEM18ebGk+mcXIPSgfLsLyzcqf
pRL9xnC72iogRRyF8LUCTyceGpcGVEC9P/94y2YaD18qAKlxVK2IqmuXXVUOe29LIS6N3Cc/ugpE
EVhM+t1HUOuhuvUZh+xBwerv2K3JHs5nPIA7N1TVY6fSSCLuWCxiqcZFpLWt/1KBeSpa/rz6dG/+
1LTH+m0kQXUCkCbwaoOShKs79hDSHdN9ukqOgoIztqOAUMrgEIZ5EdFzLZDfnQZMXjbZnfQR9VcQ
+B2V/QSn