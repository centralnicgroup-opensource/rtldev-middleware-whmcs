<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use WHMCS\Database\Capsule;
use WHMCS\Module\Registrar;

/**
 * @property int $id
 * @property string $registrarfrom
 * @property string $registrarto
 * @property string $tld
 * @property bool $epp
 * @property bool $active
 */
class TldModel extends Model
{
    /**
     * The TLD table configuration model.
     *
     * @var string
     */
    protected $table = "cnic_mig_mappings";
    /**
     * @var string
     */
    protected static $tblName = "cnic_mig_mappings";
    public $timestamps = false;
    public $incrementing = false;
    /**
     * @var array<string>
     */
    protected $fillable = ["tld", "registrarfrom", "registrarto", "epp", "active"];
    /**
     * @var array<string>
     */
    protected $primaryKey = ["id"];
    /**
     * @var string[] array<string>
     */
    protected $appends = ["registrarfromlabel", "registrartolabel"];

    /**
     * @return bool
     */
    public static function hasTable(): bool
    {
        return Capsule::schema()->hasTable(self::$tblName);
    }

    /**
     * @return array<string,string>
     */
    public static function createTableIfNotExists(): array
    {
        if (self::hasTable()) {
            return [
                "status" => "success",
                "description" => ""
            ];
        }
        try {
            Capsule::schema()->create(self::$tblName, function (Blueprint $table) {
                $table->increments("id");
                $table->string("tld", 63); // RFC 1035
                $table->string("registrarfrom", 50);
                $table->string("registrarto", 50);
                $table->boolean("epp");
                $table->boolean("active");
                $table->unique(["tld", "registrarfrom", "registrarto"]);
                $table->charset = "utf8";
                $table->collation = "utf8_unicode_ci";
            });
            return [
                "status" => "success",
                "description" => ""
            ];
        } catch (Exception $e) {
            return [
                "status" => "error",
                "description" => "Could not create table `" . self::$tblName . "`: " . $e->getMessage()
            ];
        }
    }

    /**
     * Drop table if existing
     */
    public static function dropIfExists(): void
    {
        Capsule::schema()->dropIfExists(self::$tblName);
    }

    /**
     * Add Gaining Registrar Label
     *
     * @return string
     */
    public function getRegistrartolabelAttribute(): string
    {
        $registrar = new Registrar();
        $registrar->load($this->registrarto);
        $name = $registrar->getDisplayName();
        if (!empty($name)) {
            return $name;
        }
        return ucfirst($this->registrarto);
    }

    /**
     * Add Losing Registrar Label
     *
     * @return string
     */
    public function getRegistrarfromlabelAttribute(): string
    {
        $registrar = new Registrar();
        $registrar->load($this->registrarfrom);
        $name = $registrar->getDisplayName();
        if (!empty($name)) {
            return $name;
        }
        return ucfirst($this->registrarfrom);
    }
}
