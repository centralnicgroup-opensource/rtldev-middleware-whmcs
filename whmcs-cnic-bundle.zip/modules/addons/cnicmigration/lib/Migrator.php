<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Exception;
use Illuminate\Database\Capsule\Manager as DB;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use WHMCS\Config\Setting;
use WHMCS\Domains\Domain;

class Migrator
{
    /**
     * @var mixed
     */
    private $cfg;
    /**
     * @var array<string, string>
     */
    private $trans;
    /**
     * @var mixed[]
     */
    private $params;
    /**
     * @var array<string, mixed>
     */
    private $data = [];
    /**
     * @var int
     */
    private $domainId;
    /**
     * @var string
     */
    private $domainName;
    /**
     * @var array<string,mixed>
     */
    private $domainData;
    /**
     * @var string
     */
    private $sld;
    /**
     * @var string
     */
    private $tld;

    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        // get the params
        $params["original"] = $params;
        $this->domainId = $params["domainid"];
        if (isset($params["sld"]) && isset($params["tld"])) {
            $this->domainName = $params["sld"] . "." . $params["tld"];
        } elseif (isset($params["domainname"])) {
            $this->domainName = $params["domainname"];
        } else {
            $this->domainName = "unknown";
        }
        $this->data["isTransferInitiated"] = false;

        // load configuration settings ...
        $result = $this->loadConfiguration();
        if ($result["success"] === false) {
            $this->abortWithError("ERROR_CONFIG", is_bool($result["message"]) ? null : $result["message"]);
            throw new Exception("ERROR_CONFIG - {$result['message']}");
        }
        $this->cfg = $result["cfg"];

        // load translations
        $this->trans = $this->getTranslations();

        // load domain data
        $this->domainData = $this->getDomainData($this->domainId);
        if (!$this->domainData) {
            $errorMsg = "Unable to load Domain Data for $this->domainName";
            $this->abortWithError("ERROR_DOMAIN_DATA", $errorMsg);
            throw new Exception("ERROR_DOMAIN_DATA - $errorMsg");
        }

        $this->domainName = $this->domainData['domain'];
        $this->data['domainData'] = $this->domainData;
        $params['domainObj'] = new Domain($this->domainData['domain']);
        $this->sld = $params["sld"] ?? $params['domainObj']->getSLD();
        $this->tld = $params["tld"] ?? $params['domainObj']->getTLD();
        $params['sld'] = $this->sld;
        $params['tld'] = $this->tld;
        $this->data["params"] = $params;
        $params['original'] = $params;
        $this->params = $params;
    }

    /**
     * @return bool
     */
    public static function isEnabled(): bool
    {
        return DB::table('tbladdonmodules AS m')
            ->where('m.module', '=', 'cnicmigration')
            ->where('m.setting', '=', 'access')
            ->exists();
    }

    /**
     * @param string $status
     * @param string $msg
     * @param bool $saveData
     */
    public function log(string $status, string $msg, bool $saveData = false): void
    {
        $fullMsg = $msg;
        if ($this->data["domain"]) {
            $msg = "{$this->data["domain"]}: $msg";
        }
        if ($this->cfg["logActivity"]) {
            logActivity("[cnicmigration] " . $fullMsg);
            $log = new LogModel();
            $log->instance = $this->cfg['whmcsInstanceID'];
            $log->domain = $this->domainName;
            $log->status = $status;
            $log->message = $msg;
            $log->registrar_from = $this->data['losingRegistrarId'];
            $log->registrar_to = $this->data['gainingRegistrarId'];
            $log->save();
        }
        $this->notify($fullMsg, $saveData);
    }

    /**
     * Forward configuration and message to the WHMCS notification system
     * @param string $message
     * @param bool $addData
     */
    private function notify(string $message, bool $addData = false): void
    {
        $notification = [
            'notification_identifier' => "cnic.migration.log",
            'title' => 'CentralNic Migration Notification',
            'message' => $message,
            // 'url' => '',
            // 'status' => '',
            // 'statusStyle' => 'success',
        ];
        if ($addData) {
            foreach ($this->data as $key => $val) {
                $notification['attributes'][] = ['label' => $key, 'value' => $val];
            }
        }
        /** @noinspection PhpUndefinedFunctionInspection */
        localAPI('TriggerNotificationEvent', $notification);
    }

    /**
     * @return bool[]|string[]
     */
    public function transferDomain(): array
    {
        if ($this->domainData["is_premium"]) {
            $this->params["premiumEnabled"] = Setting::getValue("PremiumDomains");
            /** @noinspection PhpUndefinedMethodInspection */
            // @phpstan-ignore-next-line
            $this->params["premiumCost"] = \WHMCS\Domain\Extra::whereDomainId($this->domainId)
                ->whereName("registrarRenewalCostPrice")
                ->value("value");
            if (is_null($this->params["premiumCost"])) {
                $this->params["premiumCost"] = "0.00";
            }
        }

        // losing registrar
        $losingRegistrarId = $this->domainData["registrar"];
        $this->data["losingRegistrarId"] = $losingRegistrarId;
        $losingRegistrarLabel = $this->getRegistrarLabel($losingRegistrarId);
        $this->data["losingRegistrarLabel"] = $losingRegistrarLabel;
        // continue with renewal in case the domain has a different status than "Active" / "Expired" / "Grace"
        if (!in_array(strtolower($this->domainData["status"]), ['active', 'expired', 'grace'])) {
            return $this->continueWithRenew("SKIP_DOMAIN_STATUS");
        }

        // continue with renewal when status is expired (or in Grace) and configured to renew
        if ($this->cfg["renewIfExpired"] && strtolower($this->domainData["status"]) !== "active") {
            return $this->continueWithRenew("SKIP_DOMAIN_EXPIRED");
        }

        $gainingRegistrar = $this->getGainingRegistrar($losingRegistrarId, $this->tld);
        // @phpstan-ignore-next-line
        $gainingRegistrarId = $gainingRegistrar ? $gainingRegistrar->registrarto : null;
        $this->data["gainingRegistrarId"] = $gainingRegistrarId;
        if (!$gainingRegistrarId || ($gainingRegistrarId === $losingRegistrarId)) {
            // proceed Renewal of this domain as
            // * it is already on gaining registrar's side
            // * no migration planned for losing registrar
            // * the TLD is not part of the TLDs marked for migration
            return $this->continueWithRenew("SKIP_NO_MATCH");
        }

        // In case renewal is manually triggered from addon, we skip transfer
        if (str_ends_with($_SERVER['PHP_SELF'], 'addonmodules.php') && $_GET['action'] === 'renew-domain') {
            return $this->continueWithRenew("SKIP_MANUAL_RENEW");
        }

        $gainingRegistrarLabel = $this->getRegistrarLabel($gainingRegistrarId);
        $this->data["gainingRegistrarLabel"] = $gainingRegistrarLabel;

        // check if loading the authcode/eppcode works
        $authInfo = $this->getEPPCodeFromDB();
        if ($authInfo === null) {
            // @phpstan-ignore-next-line
            if ($gainingRegistrar === null || !$gainingRegistrar->epp) {
                return $this->abortWithError("ERROR_AUTH_CODE", "No EPP code found in database");
            }
            // check loading of the losing registrar module and existance of the GetEPPCode implementation
            /** @noinspection PhpUndefinedFunctionInspection */
            $r = localAPI("DomainRequestEPP", [
                "domainid" => $this->domainId
            ]);
            if ($r["result"] == "error") {
                return $this->abortWithError("ERROR_AUTH_CODE", $r["message"]);
            }
            $authInfo = html_entity_decode($r["eppcode"]);
        }

        //Create email templates if they don't exist.
        $this->prepareMailTemplates();

        // get gaining registrar's module configuration
        $registrar = new \WHMCS\Module\Registrar();
        if (!$registrar->load($gainingRegistrarId) || !$registrar->isActivated() || !$registrar->functionExists("TransferDomain")) {
            return $this->abortWithError("ERROR_REG_MODULE");
        }
        $gainingRegistrarCfg = $registrar->getSettings();

        // --- unlock domain if locked ---
        // we do not check the result as some registrar modules have this badly integrated
        // and we get an error message returned, even though successfully processed
        // (e.g. opensrs, tppwregistrar -> #CORE-15667)
        /** @noinspection PhpUndefinedFunctionInspection */
        localAPI("DomainUpdateLockingStatus", [
            "domainid" => $this->domainId,
            "lockstatus" => false
        ]);

        // INITIATE TRANSFER
        // check if migration is activated for the losing registrar
        $registrar = new \WHMCS\Module\Registrar();
        if ($registrar->load($losingRegistrarId)) {
            try {
                $losingRegistrarCfg = $registrar->getSettings();
            } catch (Exception $e) {
                $losingRegistrarCfg = [];
            }
        } else {
            $losingRegistrarCfg = [];
        }
        // build new $params for TransferDomain fn call
        // cleanup losing registrar's module configuration
        $paramsnew = $this->params;
        foreach ($losingRegistrarCfg as $key => $val) {
            unset($paramsnew[$key]);
            unset($paramsnew["original"][$key]);
        }
        // add gaining registrar's module configuration
        $paramsnew = array_merge($paramsnew, $gainingRegistrarCfg);
        $paramsnew["original"] = array_merge($paramsnew["original"], $gainingRegistrarCfg);

        // add authorization/epp code
        if ($authInfo) {
            foreach (["eppcode", "transfersecret"] as $key) {
                $paramsnew[$key] = $authInfo;
                $paramsnew["original"][$key] = $authInfo;
            }
        }

        // Get contact details
        $fn = $losingRegistrarId . "_GetContactDetails";
        if (function_exists($fn) && is_callable($fn)) {
            $contacts = $fn($this->params);
            foreach (["Registrant", "Admin"] as $contactType) {
                if (!isset($contacts[$contactType])) {
                    continue;
                }
                $prefix = ($contactType == "Admin") ? "admin" : "";
                $paramsnew[$prefix . "firstname"] = $contacts[$contactType]["First Name"];
                $paramsnew[$prefix . "lastname"] = $contacts[$contactType]["Last Name"];
                $paramsnew[$prefix . "fullname"] = implode(".", [$paramsnew[$prefix . "firstname"], $paramsnew[$prefix . "lastname"]]);
                $paramsnew[$prefix . "organization"] = $contacts[$contactType]["Company Name"];
                $paramsnew[$prefix . "address1"] = $contacts[$contactType]["Address"];
                $paramsnew[$prefix . "address2"] = $contacts[$contactType]["Address 2"];
                $paramsnew[$prefix . "city"] = $contacts[$contactType]["City"];
                $paramsnew[$prefix . "state"] = $contacts[$contactType]["State"];
                $paramsnew[$prefix . "country"] = $contacts[$contactType]["Country"];
                $paramsnew[$prefix . "zip"] = $contacts[$contactType]["Postcode"];
                $paramsnew[$prefix . "phonenumber"] = $contacts[$contactType]["Phone"];
                $paramsnew[$prefix . "fullphonenumber"] = $contacts[$contactType]["Phone"];
                $paramsnew[$prefix . "fax"] = $contacts[$contactType]["Fax"];
                $paramsnew[$prefix . "email"] = $contacts[$contactType]["Email"];
            }
        }

        //Call transfer method of gaining registrar's module
        $fn = $gainingRegistrarId . "_TransferDomain";
        if (function_exists($fn) && is_callable($fn)) {
            // $this->log('DEBUG', "Calling registrar function $fn with parameters " . print_r($paramsnew, true));
            $values = $fn($paramsnew); // call_user_func($fn, $paramsnew);
        } else {
            $values = [
                "error" => "Registrar Module function TransferDomain not callable"
            ];
        }
        $this->data["params"] = $paramsnew;
        $this->data["isTransferInitiated"] = !isset($values["error"]);

        //Send client email on demand
        $mail = $this->sendClientMail();

        // assign gaining registrar and pending transfer status in case transfer has been initiated
        if ($this->data["isTransferInitiated"]) {
            // prepare for transfer sync
            $this->reflectTransferStatus($gainingRegistrarId);
        }

        //Stop WHMCS from renewing the domain
        return  $this->abortWithError(($values["error"]) ? "ERROR_TRANSFER_FAIL" : "INIT_TRANSFER_SUCCESS", $values["error"]);
    }

    /**
     * Check if configuration settings are valid
     * @param object $cfg configuration settings
     * @return array<string,string|bool>
     */
    private function validateConfiguration(object $cfg): array
    {
        // check existence of configured mail template files
        $errors = [];
        // @phpstan-ignore-next-line
        foreach ($cfg->templates as $tlds) {
            foreach ($tlds as $tpl) {
                $path = implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "templates", "cnicmigration", "email", $tpl->file]);
                if (!file_exists($path)) {
                    $errors[] = $tpl->file;
                }
            }
        }
        if (!empty($errors)) {
            return [
                "success" => false,
                "message" => "file(s) not found, check README.md: " . implode("; ", $errors)
            ];
        }
        return [
            "success" => true,
            "message" => ""
        ];
    }

    /**
     * Load configuration from file
     * @return array<string,mixed>|array<bool|string>
     */
    private function loadConfiguration(): array
    {
        try {
            $cfg = [];
            $path = implode(DIRECTORY_SEPARATOR, [__DIR__, "..", "configuration.json"]);
            if (!file_exists($path)) {
                $path = implode(DIRECTORY_SEPARATOR, [__DIR__, "..", "dist.configuration.json"]);
            }
            if (file_exists($path)) {
                $contents = file_get_contents($path);
                if ($contents === false) {
                    return ['success' => false, 'message' => 'Failed to get file contents'];
                }
                $json = json_decode($contents);
                if ($json === null) {
                    return ['success' => false, 'message' => 'Invalid json configuration'];
                }
                $cfg = json_decode($contents, true);
                $result = $this->validateConfiguration($json);
                if (!$result["success"]) {
                    return $result;
                }
            }
            $moduleConfig = DB::table('tbladdonmodules AS m')
                ->where('m.module', '=', 'cnicmigration')
                ->pluck('m.value', 'm.setting');
            if (is_object($moduleConfig)) {
                $moduleConfig = json_decode(json_encode($moduleConfig), true);
            }
            $result["cfg"] = array_merge($cfg, $moduleConfig);
            return $result;
        } catch (Exception $e) {
            return ["success" => false, "message" => $e->getMessage()];
        }
    }

    /**
     * Get matching gaining registrar id based on losing registrar id
     * @param string $losingRegistrarId
     * @param string $tld
     * @return Builder|Model|object|null
     */
    public static function getGainingRegistrar(string $losingRegistrarId, string $tld)
    {
        return TldModel::query()->where('active', '=', true)
            ->whereIn('registrarfrom', ["*", $losingRegistrarId])
            ->whereIn('tld', ["*", "." . $tld])
            ->orderBy('tld', 'ASC')
            ->orderBy('registrarfrom', 'DESC')
            ->first();
    }

    /**
     * Get Email Subject
     * @param String $case case identifier
     * @return String
     */
    private function getSubject(string $case): string
    {
        switch ($case) {
            case 'INIT_TRANSFER_SUCCESS':
                return "{$this->domainData['domain']}: Domain Migration initiated";
            case 'ERROR_TRANSFER_FAIL':
            case 'SKIP_DOMAIN_STATUS':
            case 'SKIP_DOMAIN_EXPIRED':
            case 'SKIP_NO_MATCH':
            case 'SKIP_MANUAL_RENEW':
                return "{$this->domainData['domain']}: Domain Migration skipped";
            default:
                return "{$this->domainData['domain']}: Domain Migration failed";
        }
    }

    /**
     * Get Email Body
     * @param string $case case identifier
     * @param string|null $additionalMessage error details
     * @return string
     */
    private function getMessage(string $case, string $additionalMessage = null): string
    {
        switch ($case) {
            case 'ERROR_CONFIG':
                return "<p>Issue with configuration file (configuration.json).</p><pre style=\"background-color:#CCC;\">$additionalMessage</pre>";
            case 'ERROR_DOMAIN_DATA':
                return "<p>Unable to load Domain Data.</p>";
            case 'ERROR_AUTH_CODE':
                return "<p>Unable to load Authorization/EPP-Code.</p><pre style=\"background-color:#CCC;\">$additionalMessage</pre>";
            case 'ERROR_REG_MODULE':
                return "<p>Gaining Registrar's Registrar Module ({$this->data['gainingRegistrarId']}) couldn't be loaded, is inactive or has no integration of Method &quot;TransferDomain&quot;.</p>";
            case 'ERROR_TRANSFER_FAIL':
                return "<p>By configuration the migration should have been initiated to {$this->data['gainingRegistrarLabel']} instead of renewing at current registrar {$this->data['losingRegistrarLabel']}.</p><p>This failed with the following error:</p><pre style=\"background-color:#CCC;\">$additionalMessage</pre>";
            case 'INIT_TRANSFER_SUCCESS':
                return "<p>By configuration the migration has been initiated to {$this->data['gainingRegistrarLabel']} instead of renewing at current registrar {$this->data['losingRegistrarLabel']}.</p>";
            case 'SKIP_DOMAIN_STATUS':
                return "<p>Domain Status was <b>{$this->domainData['status']}</b> and therefore not considered for migration. Renewal processed.</p>";
            case 'SKIP_DOMAIN_EXPIRED':
                return "<p>Domain Status was <b>{$this->domainData['status']}</b>. By configuration not considered for migration. Renewal processed.</p>";
            case 'SKIP_NO_MATCH':
                return "<p>Assigned Registrar ({$this->data['losingRegistrarLabel']}) or TLD ($this->tld) not configured for migration. Renewal processed.</p>";
            case 'SKIP_MANUAL_RENEW':
                return "<p>Domain was renewed manually at current Registrar ({$this->data['losingRegistrarLabel']}).</p>";
            default:
                return "<p>Unexpected unknown error.</p>";
        }
    }

    /**
     * Log a standard message and return an abort message to hook PreRegistrarRenewDomain
     * @param string $case case identifier and optional error message, format "<id>::<error>" or "<id>"
     * @param string|null $additionalMessage additional error details
     * @return array<string,bool|string>
     */
    private function abortWithError(string $case, string $additionalMessage = null): array
    {
        $mail = $this->sendAdminMail($case, $additionalMessage);
        $key = $this->data["isTransferInitiated"] ? "defaultSuccessMsg" : "defaultErrorMsg";
        $err = $this->trans[$key];
        if ($additionalMessage) {
            $err .= " [" . $case . ": " . $additionalMessage . "]";
        }
        $this->log($case, $err, true);
        return [
            "message" => $err,
            "success" => !str_starts_with($case, 'ERROR')
        ];
    }

    /**
     * Log a standard message and continue the domain renewal in PreRegistrarRenewDomain
     * Called in case no migration is active/planned for the given registrar
     * @param String $case Renewal Case Identifier
     * @return array<string,string>
     */
    private function continueWithRenew(string $case): array
    {
        $mail = $this->sendAdminMail($case);
        $msg = $this->trans["defaultRenewMsg"];
        $this->log($case, $msg);
        return ['message' => $this->domainData['domain'] . ": " . $msg . " " . $this->data["losingRegistrarLabel"]];
    }

    /**
     * Get domain data from db table
     * @param int $domainId the domain id
     * @return array<string,mixed>
     */
    public static function getDomainData(int $domainId): array
    {
        try {
            $result = DB::table("tbldomains")->where("id", $domainId)->first();
        } catch (\Throwable $e) {
            return [];
        }
        return $result ? get_object_vars($result) : [];
    }

    /**
     * Get domain migration status
     * @param int $domainId
     * @return null|string null if no data available in db table
     */
    public static function getMigrationStatus(int $domainId): ?string
    {
        return DB::table('cnic_mig_logs AS l')
            ->join('tbldomains AS d', 'd.domain', '=', 'l.domain')
            ->select('l.status AS status')
            ->where('d.id', '=', $domainId)
            ->orderBy('l.created_at', 'DESC')
            ->value('status');
    }

    /**
     * Set the Domain to Pending Transfer and assign it to the new Registrar in WHMCS
     * after having the Transfer successfully initiated
     * @param String $gainingRegistrarId Id of the gaining registrar e.g. ispapi
     */
    private function reflectTransferStatus(string $gainingRegistrarId): void
    {
        DB::table("tbldomains")->where("id", $this->domainId)->update([
            "registrar" => $gainingRegistrarId,
            "status" => "Pending Transfer"
        ]);
    }

    /**
     * Loading the EPP/Authorization Code from DB (see README.md)
     * @return null|string null if no epp code in table, otherwise the epp code as string
     */
    private function getEPPCodeFromDB(): ?string
    {
        try {
            $result = DomainModel::query()->where("domain", $this->domainData['domain'])->first();
            // @phpstan-ignore-next-line
            return ($result === null) ? null : html_entity_decode($result->eppcode);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Get the Label of a registrar id by loading it from respective registrar module.
     * It corresponds to the module's DisplayName / FiendlyName.
     * @param String $registrarId Id of the registrar
     * @return String
     */
    private function getRegistrarLabel(string $registrarId): string
    {
        if (isset($this->cfg["registrarLabels"][$registrarId])) {
            return $this->cfg["registrarLabels"][$registrarId];
        }
        if ($registrarId === "ispapi") {
            $registrarId = "hexonet";
        } elseif (preg_match("/^(cnic)$/", $registrarId)) {
            $registrarId = "cnic";
        }
        $registrar = new \WHMCS\Module\Registrar();
        $registrar->load($registrarId);
        try {
            $dn = $registrar->getDisplayName();
        } catch (Exception $e) {
            return ucfirst($registrarId);
        }
        return $dn;
    }

    /**
     * Sends support request to CentralNic
     * @param string $msg
     * @return bool[]|string[]
     */
    public function supportDomain(string $msg): array
    {
        $logs = LogModel::query()->where('domain', $this->domainData['domain'])
            ->orderBy('created_at', 'DESC')
            ->get();
        if (is_object($logs)) {
            $logs = json_decode(json_encode($logs), true);
        }
        $msg = '<h1>Customer message</h1>' . nl2br($msg);
        $msg .= '<hr><h1>Diagnostic data</h1><pre>' . print_r($this->data, true) . "</pre>";
        $msg .= '<hr><h1>Log messages</h1>';
        $msg .= '<table border="1" cellpadding="2"><tr><th>Losing Registrar</th><th>Gaining Registrar</th><th>Status</th><th>Message</th><th>Timestamp</th></tr>';
        foreach ($logs as $log) {
            $msg .= "<tr><td>{$log['registrar_from']}</td><td>{$log['registrar_to']}</td><td>{$log['status']}</td><td>{$log['message']}</td><td>{$log['created_at']}</td></tr>";
        }
        $msg .= '</table>';
        return $this->sendPHPMail(
            'middleware@hexonet.net', // help@hexonet.support
            "Support request for WHMCS migration of {$this->domainData['domain']}",
            $msg
        );
    }

    /**
     * Get the generic email template identifier
     * @param String $gainingRegistrarLabel Label of the gaining registrar
     * @param String $losingRegistrarLabel Label of the losing registrar
     * @return String
     */
    private function getMailTemplateId(string $gainingRegistrarLabel, string $losingRegistrarLabel): string
    {
        return strtoupper(implode("_", [
            "MIGRATION_FIXED",
            strtoupper(implode("_", explode(".", $this->tld))),
            $losingRegistrarLabel,
            $gainingRegistrarLabel
        ]));
    }

    /**
     * Add eMail templates to tblemailtemplates if necessary
     */
    private function prepareMailTemplates(): void
    {
        //Client email templates
        if (!$this->cfg["sendMailsClient"]) {
            return;
        }
        $tld = $this->tld;
        $tplId = $this->getMailTemplateId(
            $this->data["gainingRegistrarLabel"],
            $this->data["losingRegistrarLabel"]
        );
        if (DB::table("tblemailtemplates")->where("name", $tplId)->count()) {
            return;
        }
        if (!isset($this->cfg["templates"][$tld])) {
            $tld = "default";
        }
        foreach ($this->cfg["templates"][$tld] as $lang => $tpl) {
            $path = implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "templates", "cnicmigration", "email", $tpl["file"]]);
            if (!file_exists($path)) {
                continue;
            }
            $message = file_get_contents($path);
            DB::table("tblemailtemplates")->insert([
                "type" => "domain",
                "name" => $tplId,
                "subject" => $tpl["subject"],
                "message" => $message,
                "custom" => 1,
                "language" => $lang
            ]);
        }
    }

    /**
     * Deletes mail templates created by this addon
     */
    public static function cleanupMailTemplates(): void
    {
        DB::table('tblemailtemplates')
            ->where('name', 'LIKE', 'MIGRATION_%')
            ->where('custom', '=', 1)
            ->delete();
    }

    /**
     * Send email notification to the client if activated
     * @return null|array<string,mixed>
     */
    private function sendClientMail(): ?array
    {
        if (!$this->data["isTransferInitiated"] || !$this->cfg["sendMailsClient"]) {
            return null;
        }
        $tplId = $this->getMailTemplateId(
            $this->data["gainingRegistrarLabel"],
            $this->data["losingRegistrarLabel"]
        );
        $result = localAPI("SendEmail", [
            "messagename"   => $tplId,
            "id"            => $this->domainId,
            "customvars"    => base64_encode(serialize([
                "gainingRegistrarLabel" => $this->data["gainingRegistrarLabel"],
                "losingRegistrarLabel"  => $this->data["losingRegistrarLabel"],
                "resellerContactURL"    => $this->cfg["resellerContactURL"],
                "resellerContactEmail"  => $this->cfg["resellerContactEmail"],
                "resellerLabel"         => $this->cfg["resellerLabel"]
            ]))
        ]);
        $this->log("CLIENT_EMAIL_SENT", "Client Email send result: " . print_r($result, true));
        return $result;
    }

    /**
     * Send a notification to the Administrators if activated
     * @param string $case case identifier
     * @param string|null $additionalMessage error details
     * @return null|array<string,mixed>
     */
    private function sendAdminMail(string $case, string $additionalMessage = null): ?array
    {
        if (!$this->cfg["sendMailsAdmin"]) {
            return null;
        }
        $subject = $this->getSubject($case);
        $msg = $this->getMessage($case, $additionalMessage);
        if ($this->data) {
            $fn = $this->data["gainingRegistrarId"] . "_getConfigArray";
            $tmp = ["Password" => ["type" => "password"]];
            if (function_exists($fn) && !empty($fn)) {
                // @phpstan-ignore-next-line
                $tmp = call_user_func($fn, $this->data["params"]);
            }
            foreach ($this->data["params"] as $key => $val) {
                if (isset($tmp[$key]) && strtolower($tmp[$key]["type"]) === "password") {
                    $this->data["params"][$key] = "*****";
                    $this->data["params"]["original"][$key] = "*****";
                }
            }
            $data = $this->data;
            if (isset($data['Password'])) {
                $data['Password'] = '********';
            }
            if (isset($data['original']['Password'])) {
                $data['original']['Password'] = '********';
            }
            $msg .= ("<br/><b>Case ID:<b/> #" . $case . "<br/>" .
                "<b>Configuration Data:</b><pre>" . print_r($this->cfg, true) . "</pre>" .
                "<b>Migration Process Data:</b><pre>" . print_r($data, true) . "</pre>");
        }
        $result = localAPI("SendAdminEmail", [
            "type"        => "system",
            "customsubject" => $subject,
            "custommessage" => $msg
        ]);
        $this->log("ADMIN_EMAIL_SENT", "Admin Email send result: " . print_r($result, true));
        return $result;
    }

    /**
     * Send mail out using php mail function
     * @param String $to recipient mail address
     * @param String $subject email subject
     * @param String $message email message
     * @param string|null $company
     * @param string|null $email
     * @return array<string,bool|string>
     */
    private function sendPHPMail(string $to, string $subject, string $message, string $company = null, string $email = null): array
    {
        if (is_null($company)) {
            $company = Setting::getValue("CompanyName");
        }
        if (is_null($email)) {
            $email = Setting::getValue("Email");
        }
        $sender = $company . " <" . $email . ">";

        $headers = implode("\r\n", [
            "Reply-To: " . $sender,
            "Return-Path: " . $sender,
            "From: " . $sender,
            "Organization: " . $company,
            "MIME-Version: 1.0",
            "Content-type: text/html; charset=utf-8",
            "Content-Transfer-Encoding: quoted-printable",
            "Subject: " . $subject,
            "X-Mailer: PHP" . phpversion()
        ]);

        $result = [
            "success" => mail($to, $subject, $message, $headers),
            "message" => ""
        ];
        if (!$result["success"]) {
            $result["message"] = "Sending mail using php mail() function failed.";
        }
        return $result;
    }

    /**
     * Load translation file
     * @return array<string,mixed>
     */
    private function getTranslations(): array
    {
        $_ADDONLANG = [];

        $language = $_SESSION['uid'] ? DB::table('tblclients')->where('id', '=', $_SESSION['uid'])->value('language') : null;
        if (!$language || !file_exists(__DIR__ . "/../lang/$language.php")) {
            $language = Setting::getValue('Language');
            if (!file_exists(__DIR__ . "/../lang/$language.php")) {
                $language = 'english';
            }
        }

        $langFile = __DIR__ . "/../lang/$language.php";
        $overrideFile = __DIR__ . "/../lang/overrides/$language.php";

        include $langFile;
        if (file_exists($overrideFile)) {
            include $overrideFile;
        }

        return $_ADDONLANG;
    }
}
