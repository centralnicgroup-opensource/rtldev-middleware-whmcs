<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/YBp8cSNJMkMK1PgiiL6TWXFOl1Bfk67xsudqm4L05acggLjmQ4DqrCD5orEfBkYBAm+kIi
hfrEChNvSPDvzpV7gPOCd5JUZpTZlgN89kxz6BVgWwMMhKK278X31TgYVxCscVMKCou3ILZ5C1v3
2Ya44O2a1JJ3L9+mISAEsNvxnX4UODWJCuJyUJgDKY5570XTifTIbvoUYmdU3FgkOg+RAGHjE1HO
K5tA8bqYKVG8v5SodFe1fnBC54Xkbc3SZOj0DDmkVTjnBd+zj67wAkOr/EPXLX95cD9iJlLxdH+C
38Xz//37bTA9P5E8w2OtDgbihpwY4Kydoo6B7koYryObNh3mCs0l9oxZLRe7u8uTzeCJOZgGAS7j
piQ/bJuluHQ7OXzQUspFFKlFzxl2es5xLGm9h+/K4CfN+LdtmOtafFNclHYV17BD6//h2bOD4Mw9
m5vKKHUrRHMsQQ6HXa3YEcHX7cdxmHAiB5hn6tNl/QeGbMJLvqjLAxfy/QGIDaEBjqLZdVP5+27J
3LaK/uWQnkYnW3vzxxNw/d67PlGKBV5CsR2DuoWgMkbZsT0mwAzflRhSmjhGKx8NJ+sJrOfCAESR
9YR4Fb+UJZ33uchuGDuMx86H8ria23tY5QZEtXL43G3/7p8OQT5IuD/PbKlj7P4HQqnyIcOAHr30
dUNBd5RePXAZkQ62Pk6RnpbsjiR3GXlo1Cj+mg+9JRdJSCceZ1EKX9ag1Aze0ZO5V1OswNxTrNr9
ExaVXEpOZAjs+tYEudLtfgAJGhIIxyJ6VjSp3f6+08k/hRHfJMqrUH5RUhD7tIZ9HJT/axapaiKX
gcRx0HtV6wI2WEtBasssgMIsu1AdKMmD0iee0A7wpTBpmJimzrBk6RqWLPU2tinl7S89x0MMJGdK
8GXRmMSX+noPS1FcJTkOy8Ehqoq5MT0F875SiAV5BYbY/wfsY2ZABJhCq2fIgYQoadR0IiT8FrSz
YcbgB/yDU/wRRk7bnMdOsDu9yD4ZT1IJUJRh6JDQeFFQgwp/atJdSkO16NnJozoRDvmmPVl/2h3Z
JGcgzD6lYuKW/M8xhf35NZT6W2CpJmqT/wannG5OnevX+0VLzXlb5Z9zIis9mb6o98xOz/0RviRV
1apZEpYwwDxaoAlOyQvrtK2t8PNvqCQhvFSkiWvDhogN4H0SpqI1Fy1MURvlBFTTCAUR43LQL6Kp
JBDYPhEpWJc2wcjhM/AyHy1Wq8Rh/mkGs+/YRFWf5g88EzXQelu5vip0mgDtmGnX0vyKBYFS2t39
4J2NJM/jEwjiqE6X3BoOo8TgCTbUrrCghxOvMWX4pW0r/vlTZ9eMslvTsuUyWw1E0l6w18ajSbxQ
PCgR0QDqcKvMedqkuLc9omPgmDKwOKp/w+46TqikawTxsjxtgMDjHwC9fvQCke9ujFB+1hwJHiEr
gJUV46OLucVfQKO6GiWAWMlqLVw8+VXMIVrszAeBH1AWyCOAO1sjnW7+vR5+p+r1fLMZSYxVi3DY
jurF1jxa5UmDPc8H4ytn/l4ZOsMdl+qVibdtynFLeY/VZWGzQRqU0ls69zJmudPb9wneKsFSFiaB
zQHry6gMbYthJ1OgArk8jKAIhQc7MBIGlsZlailXXN1/+JG6GTgLo73VCkH7WSfVFsg5Gx2eK/7Z
CNrTv1R/607puCkQ9lTTv7vi3C6b+F6GkZ4Hx3MZrxvenlPRdwuLgipL5op7i7ibs4QMoejtDvPg
OCdaqP7HZ/Tj1Mdegf245tF6J7ZHLY7hea0JdfbDuzbdoJio6QmG7KD73OO2X5J3h+xmStwk+ToP
eCJpnGuzA4y4tD5b9+O9XqlfUySbytiZJgXasfgfxlzZr3Ni9W/LE6sFRSY9pQDLYsM2yep+Ress
9G5/7mjDOvcEnzeAOZFp+av9SIx4bfvy3DSLYZuBbwofg+AGgMHa44rtntAoU83ZKtNvgFAnpFhu
w54c4G5dVk+zin9oEjAA+FAECFkpv/w+XPponDKh7AcsVFz36I9VhMt09B7v6AVVqF3ZXXmovGkb
dUnUqCqNg5R7DmKNQ6kpD//q7Tc6P7AtrYgmyRtBaSgqrnnweozRvyNltNrTTnpNe5I162SPfaVF
okF3W+//949nRDzy2pxpECLY6vjsfaGhqHvxaWJcr4i7jmxw8m8ijTlIb3DRQCIs6thqVGjbgKIT
LkKcoGWXNpLB0/RXaR0bIMJCKbM9/n/36cMccU7n3cx4ebRHZYh9O3jyDYWzILOBQgS9wLuJhWfL
RyMOInIHctCU9UXKFuJysSwTd9GPR5UbgLh1w4rakG/v2mPscJG2IzpnuOzNQO/J6GtOlUrDy5E0
/atS590cqPGW36GX1+D0tnEK+rGpbi00tkxcW0yuJ1a5ZWdn83afwLKbr6OJHWyaRjCDercm5IV8
ecIu2ZTEFYVpDVbv2FqX0X68I75xfTrunBCcHfjBwZzqiPKWe5qb+j4IhtpqApG/1DUfk91WrCSj
igDKou5+TDB7gXuznO2gwDbEqz/jW4a7QnHWfngD7cuz/3QQI9npXihYGd3D0nMheHcwoUc+/Ylb
porQxtergHC+vjxitDPM0dMgjP+F/zcLOlP8sq6uWlgxeRT533xXt/XOSW1FXazjBRLlwSvbWG3W
gEwRDO76M+F8HxJ1s98Zib4Ds6qUSWv9wAozWNS7o+1pq+rspXB//eyqAPm/MofTBEdas6F+qHq8
zajRZKydnnauIfbNdeFNM/KrYNSemUCeY5oqTcQy58Qp1YhKsGZ31PY4ijhZ3pFWvSFAg3D+NJ75
pW7+cFVpBg+cqtAiQJ/QB32zUqt5X1uRGb5FpNpQcuh1lfo0vgrQSIcOsO9Em8pzfQJgcn8YBwzs
isXWaZglCydkJ0IVi6prLdVw7C5YrHRtD5AtfWO7nIQG4+8agiCiFoArxV4I39+zYx/ZF/wpillJ
w6IAZuL7oy8h4HLsU0JMe/GDv5aKZbq4eHwZwwRdrjRzFW7aRoxFy475t2nkCBn2IJULTzaaIpNI
ef2G+OLCHMYLPMzEv8bci7awZA9s2MCGToQWUzkkQV1gjQr8xOizjKn0X8nmWfaV6RQxpoIz09mK
74wQgmt4wyIG3PzmSIj4woVK039pAkjTQ2xLFkzB4jVfAMzDC0lqVi+5DUTDd2XXhtCbVgkBsQa5
/VM1rZsSKRY5/2gFQ1vM1fEyIxu6zhbxsITPNfVJb9lYO+Xi0z5733KGmv0M+eymPvzTvL92HxxE
TFA0Mqcg1sRjrIHKUEpBdqTBygDKwj8nMuryK2dn/DCgTt2q4sAF6ZcbKdgsMvhC9FpAM6WA/eye
IznOVT3yWRJA/oitFdib3OMw0NpSANDs9OseqZkA3QaGaA61No1bqOCI/uAISF1EuudT5d/JeZso
Oiq0GTzf4BrQsadFE4X6WgJI/v8d/rhCke4c1Gadkfizqzv1hi/Q/ykr5oNj9qgmlX/YeEG2o4VB
GwXWtpLuYvg/jQyY35vIFw6Q3zVt5tvNOfRbqT1BGjXgYc65plKmj+rY4LvlvKFj/zMnbLnHKUes
3XEgtB/A+0EKzxaWoJeMZ70QIAnN4m8ZR4PpZT12Dpx+oHdq6EbqL2Wjrc2v7/Qv8ka7i6c/JZ9M
IuW9ThOre8lTgcIRbBCfo4JzrTK4Ckwb9bech2nnZk68MmvSFij2foAtLArvoWFDMuFNKhYnFY/4
mj7+sxOC/J+a0OiPgJOEvl3e7QKMm09fb1+GyRgMK5+uUvj+3m9DFMYjnOTXHbeGIvCwT61PdY7t
1uY6tFv0oPY1PI0zGHc35/G7cvUWQA+REeUAOA5m6I8b9nOq5MG1ZPQ5HBxCrgp6fxqHJLcqRm9u
NCJdrUykWo7Ce9DLzdDoxjBbveHg91bCAEhexy/J5+JznbPygVfxA+n+4uasrytICS8xT9Y+K8W5
2dDPYerrXMHR8dIt1W70mtGZw019C9NXEqpPHCeSxbQbEJJCdAfXa586iPqbGP+OIZUrd+25Zv44
6Y/2Fs5y33D/3SKPNnV48khUkUjrksr59t0wZR2ioM3l+Jvg8zc+0W0U4PSJBnEn4F/mqpcVG9/d
85OJQnYBXuKmg7hoWE+B/goO/NIJkBGbyJbE7wBxVUnG52XfJzhLAZI8396yd7q2LwQUSAvMZQc5
1ZWNUiGGnBkmtAGuvRHx+8FIfS/N5rJI1353Fia3T0yn8c3gawtEZu9YlUkxrgECukreDFyMkGtT
TjiLCU6iEbou43Wqx2zXpCvxpOqweWWpp0fKqc+4ycKmZFgDYhvCVdP5EBEa8zhlgfsyn2joyybR
Af1PvqJlc2WLDrXwhCUw/eDaPpdkLGyv34a6XDQPnbzjq+70z1B6gL3+ujpPzKYdwEb7y3MV1Rqm
f8J3Te6Ko53IGiB6gOyCy+fJ16i+vndv1m4jSrxbzOLhJq5jD0aJpmzSgAjtVR8Vds5bMvmRWupa
2LO/V6AiKh1a5STzn96SmuNgsXUxaURLpfDcpRTmJHm2Wg5GcvIjVaqHHJ0wMtLqBoggGzJJbgpP
6lGb3t1Bip09OEMnCyRsMPR7Fbf4nxxKfPiJqzuZUrj+bA4V/Sk/5TKwtPFNQxhN4ZqVoa5ZICGn
AvKS3kuVoWg/vyWhZUAJ+y8pGUWYKierODK7MYJ3dAyRYK5W8b+KmEu07aq4k8p3/bhH2fwv0giL
/VBA8j5bYXeC8TV1jg7DfPqeC+kSv5bLX9wSBnVILSYLli+KDt46GDKfpHwVl99wVef7ht5zS1zo
GX32iy1c+epju3PZTNfUvdwPLTzhTf4bJLh6OrG6MiY3FRmrwIozjrj90dy4tyiExlMTQHq9hGT1
tJAMTpZxKsG5rQRJC9y808u1mqAmgHPyrfLm6J0iLqQ+RMtmz6TKGmnno1yjr2rf/PFn65Qde+f1
LxQAMFOoefYHt1ydnLftJ/FSipklEevzdJWm/DQUn921ZFuYO2s/EfM6A++x+z0Lp4h/dvnZ3bo3
p6x8Fs8N+2DMmo21hBBzb3G=