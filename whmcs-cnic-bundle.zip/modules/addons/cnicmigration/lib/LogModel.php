<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use WHMCS\Database\Capsule;

/**
 * @property int $id
 * @property string $domain
 * @property string $status
 * @property string $message
 * @property string $registrar_from
 * @property string $registrar_to
 * @property boolean $locked
 * @property string $nameservers
 * @property string $contact_details
 * @property string $instance
 * @property string $created_at
 * @property string $updated_at
 */
class LogModel extends Model
{
    /**
     * The logs model.
     *
     * @var string
     */
    protected $table = "cnic_mig_logs";
    /**
     * @var string
     */
    protected static $tblName = "cnic_mig_logs";
    public $timestamps = true;
    /**
     * @var array<string>
     */
    protected $fillable = ["domain", "status", "message", "registrar_from", "registrar_to", "locked", "nameservers", "contact_details"];

    /**
     * @return bool
     */
    public static function hasTable(): bool
    {
        return Capsule::schema()->hasTable(self::$tblName);
    }

    /**
     * @return array<string,string>
     */
    public static function createTableIfNotExists(): array
    {
        if (self::hasTable()) {
            return [
                "status" => "success",
                "description" => ""
            ];
        }
        try {
            Capsule::schema()->create(self::$tblName, function (Blueprint $table) {
                $table->increments("id");
                $table->string("domain", 255);
                $table->string("status", 24);
                $table->text("message");
                $table->string("registrar_from", 50)->nullable();
                $table->string("registrar_to", 50)->nullable();
                $table->boolean("locked");
                $table->text("nameservers")->nullable();
                $table->text("contact_details")->nullable();
                $table->string("instance", 16);
                $table->timestamps();
                $table->charset = "utf8";
                // RSRMID-1303, $table->collation = "utf8_unicode_ci";
            });
            return [
                "status" => "success",
                "description" => ""
            ];
        } catch (Exception $e) {
            return [
                "status" => "error",
                "description" => "Could not create table `" . self::$tblName . "`: " . $e->getMessage()
            ];
        }
    }

    /**
     * Drop table if existing
     */
    public static function dropIfExists(): void
    {
        Capsule::schema()->dropIfExists(self::$tblName);
    }
}
