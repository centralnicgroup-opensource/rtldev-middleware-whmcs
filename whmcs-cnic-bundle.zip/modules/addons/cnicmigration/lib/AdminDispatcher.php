<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoaSegeJu1QDwgutYLjBb3z2L5Z1Io+JmfwulSF9kQtEj1UGCkkJ3BjBwQjHQsqtTfkJbHw/
rNhRtuJUmeEDmDV9Ah/JMTecxv5t1B71UbXUa/O14T7ws1qsqs0PUnNzGrez4aBPsNqakqYQ8s6a
qFAmAUQmLIMAumJ8oDHfu1HG6geN5ol8CHe3GPrABPWg3l6GJZ6bowIKMvYRwzB69ui3g1w4aqJT
KebMUIcQX991rQ+XtJZy62MUkjGZfxUEbnbrHCJbVPVNPnWIKKGpvUxVHZ5fzUUSPZNLsuGqvu6z
UAWSRk1T8asnZFqk5s8uOdXL3mcjsRP0pGG3gKUbPiO2MJFLqphrROi2poVvAeUJ+fn7JBzn0cIt
UajHtivKAZhblJA1fIeMuvMtsJfY6etxCXY+Un7MWz7UhhUBP2pOJyOhFeOaqq2h0Ai1G67cHDFL
dBn3BSL/59+fxFtIkHwDJR/TDN3Pb4S/xPiI9LWgEZguqcGBR1tqrH/dmD6BxAu/uOEt6c95M8xs
xaG+PEW8r/Cumr0Jklgb0VMTwfom49uKJqHnczqnJWu+NWxhkXRf4b4SZp/ymAQWGBK1lpV1aMfH
41wl0FKAg3bm52X3EQn8bzs3Jn+wp9dFvMHHvYJeHVY9tT+x6Lp/0WN1xEtuOdvbQMb7DMQ6p5JT
H9uJUPVq88x82btoRGzFmFjLSBVQLOsid+qN4B2EvvCIuGJSbiT0gKdA0pGKBY+rNVbURm8pSAN5
Rx8xyDkrIGZuJtpBxTLMk8hSA9u57DACDLkY6tnUAkmsh7/wPRky5SiBeQAjNc7qEy2nRpS5o9V8
kat9esFiKpaQAjY8BIEeNEBMZf1xM3twkC2IICx0TEA+ZOudvXEt4TCfxkxV0ZAZYwxH5iFGr5qg
EomYKo+2Dn6lgtKW3KL00H5egmanMCkSvmjK14QuiWUgSL7CZasCxieSs0jH35jLzGuduXtBhl0c
Q/6u7oR7BCjFS//FNs/uI8KP3owrtlz6hQErNVq6bv2W5osu2E+IvsLRXb7fxMJ5PnYC07j7xTKX
Wg/KuUhzSNZLMVoBzfxZjpK4oH+M60YBP91GT67D1i4dGOdihptftCbNrEByY8K78nziB2xsQ1+O
kJrzsK+s7mpGyn7A3opJcpfhCz2Ot6DReM+8KL0tarA3/Vp/hxbKy79Y9UwlXtpTKPV0Nqhfqw4F
Lbzo0b/r9mKpvawKozMVzSATTu+FehiN/m/vNLF4cR1MPAlXEBgyZH/8ZHNCAIEe/OKY4Sj3fIvr
p9AIB17D2jnpjv2Cq/LK33VKAqtXgN4hrkTxwBeHEAyqst7foUuE/x9wYnpPMU2hx3LEOUeg/6w2
8fEUoHJOSZRSFTIGkI3Zfu6cWp6oIKGDcJ1GR0mNHSx5I/hcoySlMOpmPXqWKYlGLi/Xpjg2OrnI
X66OhtK/aRHCJCbadm7UY0DEa+0dXM/6HvnHalQR4obXLOVJPZy3UMzy6pHMDwntOeKxSLflsUSG
NNivxo6MZ4KMBMNRPqNqM0IZcMmgY2DE9vhlTuUROoqxiUDXlx7QszEe2UHf8pMEgzyjpSn9XRcK
mUUvQ8NcRVG0GnZ3g+TgZqlbcNaXJevz+b6UNSZt0aeQKl+6Em/+60cvCRL3BhD4gnnIYHn76ZXT
hecAB3djDS1I/7HR+NwJVMy7jAj6SpCFxLd1A8IU0WSWwxow7WL+hXNQ5Wr8FVPeBOQSykbj/4bj
rEhPWHTH/Iy70HWlHziqLf01qngbaIPB2lpOQlex6NheFh5fEajss+AvV8dFtPGCMWjRl13SLjf3
3ER7HhvlCfIy