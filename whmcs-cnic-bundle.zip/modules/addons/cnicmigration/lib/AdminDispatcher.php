<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwjX2M25pl5NKDESGt169BywTaXBH12cjwoueAmPYFGzJBAZ6drehEj0+1akzspu0lR+MQbl
HpJPblPLFtJe6s9MLjFrRlKA4beJjReg/bEuU5UAljM0rDyjU5wY4s8KnSnnwcMJK3O/w7dsrZkq
wBUHUUp7FMex6n7HTczKhT4A+zboT4N2KAK3Iosm3uXxy9iE1OKM9N/c92ju8v4jJjjF5aUCyVpU
NfXe25znEj+dTt6KrAQ7KB503+b/CMd4X7HHPr7xiogPqoBwarRZit/zaWXfLnlDpVx1nngmcmpY
42Sl8VJ/i4z59J6Qz4sMcGn7Sm9K1Lu9/URiDyiRs9RCQVUukezgb6fTtFm4Jf91gN46zQXWl7iw
llBIGLQLzHkewbFw/FI+gMPVerfFLIENKOUFq6Z2cXr1bcU7b9dKjk5qvhfWMLFIu9GHs6wdslRd
I1t6U8WYNJGao9bO5RM6orCH6+CE/ZVyddmcnITrd+otdcBe0+294ybdDD4h9GT+3yxwKLS6hJDW
M/UyvR64n5/dXKyZAjDdHL/xJTKn6Si59jXLr5h3Dwbfv8jnJNtlGrHxvECxsJfN+oNwBthb793l
klc04wFNzcgie/2snQ01zYfZISICY4bcuHhuAhCaG26HxCPXNAnk2jzk0vrUdRjrDPpiI2/9HWcI
wPKmjhhwBftYAXReyA+3QzgCnLYq3JiPl+F0dpAGNsc/xISec9izeOfm0+Lxn7QMcDwewNuw2zaK
a5xVFRTkylmJRRrqAJAOWNSGed83rJSHMDgSTs3Luw2/TJHt8V1TBDkFKFENgwEmNOQX13C+nDEL
OcfoHaQDnFBFSxigSF3kkWOJ84vq1eVewqSHU7e7pqN65n+lYmc+PsTCLcICITJXwUlEJFM3cRvc
IzysPS1DWukz4ixvADv9O7HViYo6Htp4VlQRIEvmevOc4yrKy6z1zvDx/FzwhwRnPYnGX2h+g6MT
Mvu2FPr1Z/tnDqV/lDEsd/rCXiqni5QlDOBGqD3eyZXbiRuWXT4QEGO4VgerCGTz3AHc6s5IJZki
ezcxmXtHe/l/yeiPG2NWiuKE52/TWBfP/aC1JuzBhw/A5p8le0DVqpM8V+hWJnbEgv98vdP/fa24
GCPzG2kMwFR7hy3t4PIV325rrr5gqI4mBAXrEA5TyvG+OyD6ybk2eYl7QMJoNsxx9gWxC0Vfehzg
QrrgoFVGwzce2I/UPw6+4UF5nPN4+2jRAvIV6mVgCFoZM5mEcil7ZdvRvmD4B35b/A8Rg8ciBC9f
aaKgRgPRmRzn4pRMGIu3NFZUc3Rm4riYlpJBhEMJ2ht8aeq/eHy/E9bWx7RdhJauVGBRqZzcLC22
tSwa10/FEAhwijA+lZTgwmdANqz+ZKMwDqjLdjDj0y+BdIq6tou7hghdtj2ZiM9wtCuuHgfSQDLb
g6kzhfDnSXZKQ09IhBMwsN496Hz2hlaM7gU3S4AO5pOmkKAyXohePhdMgKY3RF1+7PN9nFXBHl5r
0d8I8/AdWWl/A5XlkHkUdWMTp/pZNOdOUnWKhwhDm2/VdjK5hBKVRC6z5UwY/yYO5paeFeTnlKdy
xb3BLWRZKr8RV/KiwYy50fDwcQilUgzUMocdU+tPvbGV6fdiUIT+zKv/d3jp82D/PUSvWmWlAZqt
mFJOM+0473RBAwzSpv7c1YXhzcqFQC2y0vLDrmJQSDBAzsE/KpcsPpGBhwhVlZh+MP2WpX+Xx/Kw
xPYm/cdBIFXGGkJ5Y7dqWebznaWgHxWrkhMWgyAQIfOKkPAPptShyhVw7dYv6aV18VfCadYzccGn
gehQNfNdGxAw8yQRiFbBdau=