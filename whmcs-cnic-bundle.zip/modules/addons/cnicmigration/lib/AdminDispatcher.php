<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv5MPKELkLrrOEJmODEVvvqedNwAWb2DdSbzPXzXWtwMxSC5FOM7/sbqRco6nq5t8JWrw9mR
O6ZwEvJVPSH1s+M9cQeUp8WiGENCBISWI2F08rLAA0RlVgZTyrCeLBGx6DWmvs8m5PVJ4n+NyWkW
iUNR1Lbl2zJKpIcYMRbJ+M/KsA23mteAA6vaAfPevSBnOkbal368/tgEEkrxWY8wnxg0mrHTzm6N
o5SnkI8fAuyXMpRWeWOMDFKTpTmYUuKnPgRP5lK/cQ9+BasLC4HmKEQIKNC+PysM+njxrJ1w1tPw
FGc8NIf66DVZVCGQJXAmU4g6oR3IOYUgQiQCnwNh1JbJw78E8B4UpvVJLhbjvjETtIFIAfw3Iurf
MZKpTWW6Yhy6rSoMy6K7GzRYIf9WHZ3vbCMWP9WAJ/gOYxlCXMEqlaLH3mq8jvCI0qe87QkU0vtY
zCCJGUyhgZqOIzdG7iFlT1UmbuPfLV7bbC+EYh47ulPgBpOnpwZAdwbljVEXaNlFFeis4FtysHah
xh/2UjKmORbPIjYl0vBpMMlR6dyEU1zInW2DoaG8Pjdem5uuylDd9pjXwRhF7mvOjA7ylLnkhns5
hufpZIJ5vK+gBO2NjJdYbd5WM243gnvHtWTcjmOONlwkWyOb0G1yHoBBjHOnbZaaORuVr4AlkwRR
PpaAdS7K7/GuTJhnjxiK7XspYQ352GaSN79rBcbzH7k9uu80l7RlCs1TagHKbpTDm5uSeBFtdCzj
BbORtlXt5qdmLSkx2TmV3qOsUjS/MIkpIBlZOnZQ4SMBpiiPcezsXrwQcgz+AEYDG410CAkk89Kf
hGetxFLom0FE6qOwLOI66ju0Vc1k8xNqA4KHcisyGogZrhqiJD6ozG4aP7U4XffrpNXPBZg3O3Ie
b83BIqSPjya+tvTYWaSJ3I5dafxEteVGRpqEiFOca12n4jwi0Zeg8Cvw7S5uNZlUT8uZ66gw8WLO
63zleQiuWr3v8bRrGLtcQbcce7eBy65Y5R6wBn7xhLEQK3GFQ6SpJCijqnUlTii9Kgbkb3PDuyvB
ncSC0guHInQH0S09+eRsI0m0DWjqOKXrqlxfCUmfnXYQjU7x2Y/VlRt2ecsFnG05xOTYwaILThG4
d6cInIuQEGKR0oLbRlGAB6+LooLPIW+ks6tQidlSZFG7tCJKXk2jAXwm9O8hgzsSmLZUbAqNr/ew
5xeniNJu2+RlPZLxUogUwLtGYrMTk64osQBtq4I4AfZz1v7pEeB9Y2Ibk72ujMsspprCzvJ0cLgg
HC/pCLrurBV7szFvtpJlrKpJtCm0u+ktq+IoNyCaXhtoEU35T88xgmxN7MMlqyrMO35xKwHo2PIQ
NPcpXc9fhzTJAqshQQvXiKJQoxUEB7icZdLKDMyEotBBvQytyEmcA8U7pL2w010u7+7fAfvhy403
rATXZBTpdgU9JuQo5Xwsok1SMcSpcpOL5AhxyvNe7Q60s8gK+mFPnqOSidaf/WwtyCwiVMm9hqHa
FtDFcbXiL+nAGhJeCOJu959OZWDvOt2kVb62A3URefjvYNDzQWgg3EakMcMTdHYAaYwilIxsyaA0
XS01jJOMUZt1ev0c6L5Maeo/Nse/vQg/wMLkguO3s14r/fp4D07weDs+bEqxBfpQMFVyiW9T7Xvh
q8ppQZ+nyQmpK+2ob0KZL8U1JsUwWDPFDSpXRlzWDVlHrGi3rPLK7j6/TRxMHc92ANJBSk19OjJW
MRXK0D1vmUhQD3zeMIXsFUbNVITW9TmpJU8RW08PC9jW03Gf94iBkRATpMWZAYUR65Vr/EKHDfLE
N2JG8zJAsDdKV6If9cq10IeebVNoJRxoCw14