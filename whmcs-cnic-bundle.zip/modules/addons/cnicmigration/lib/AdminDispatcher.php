<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+SDxx9OqzE59RzwaQaKFT/dWosT9Vro0jHi8NYL9OB1lxvBf9yhOtEYcygRlmusms5woxFW
ldM3fNdWhq+HlYGoKeWopyzJSyf+ekY0AyHIe/I4htQCChh638gcmoDgnvCKN8ZuNBqHJE2RYWO2
49PUekmYUos0bsPaZqfVLXUlzjupJ6zmkqi8DFJObox4T/vnKzufmgsJsb1kNzI5w7pEHBZqjc9u
dundrm+32CRc9WFS68AOTJgwgnkj5nsav5+n5rvFMPjqCGkUvHnKLh5W6R4dQd1IK4duFWekdiyM
HrS87Iv3NITY0dFhGmnhZg4+ffGuMsOWYSFRgjBIOCSWZzbC1SmgHrlRkUYC3trzPWDzdPyd2ctN
HbIBRv5Pwfg7H1PkxTaN+OOCmSMi9zy7eQ+ibrSSRO6B6YWPx/CZLfDA4ACiBM/4W04X67LZlgeN
jgpLI11XjuqFARfbSHGw+wcTYvNiTiAeoyhs26c0ESv4Ml+1wv760UyBdAwVoEJBAw2Xqmv8T4oR
QzNoRoKF2qEM+4nJUp3t4kvZ5oUPnBlAdgkHcglGAWcIt1KOuBRju9CEUuB3wvJTqCHvkoso5Osq
2PPIUHhHdUmakoXAdiyPC6DH2eWTgXsmS/y6GLKr26hJ6zLVEr2Cl7a2UTa1bOAGm1wTmjomoI+w
aTSLM+MUvQXrRv5iXcmMo9KDC7ZCo94xW/SXCY1MRw0uvmwAgTT+ucDoSDJ0Ik6oByLjNRg+Qo/R
6qzmX0kAzShR03U6qkKDQZN+t5MEsrmv16c2as5yCzOovoLL5uR0dzezk7jbsIdrTS+q7xaSWoLH
Hw3NrVrfYjU6vj5R2MLy1TecyW9ub4QYWPbSQHNEVLZyIQ82bmG81JuZKpb1OOEeGKRvl263CDAm
rLWGT+gA311qB3vouW3I3cVlHDTRgczUL/pfUV9Tyr7XS4HULKx0bqrYywGrXVsNvQocgLKU8VXr
v3L/GRcZkwMzdnOPWCXv7KEcd5x/9NV57X5P4CZI7npFQmQxgWFHakWFaBFp0axOIWzNCInu3PWU
9xto6unafK2WcDuexzQH/jlZvxwsqcqmUSl8DNGonC7LIAoD/mpnB1W95kULgRIuEM/SZ+DLdKuS
7It2m4M5Ewmr5xo9JvwusiBxxtZXNZZRZVdrVFs84M5S+C7q1pqkXJteRH7PW2ZclZQx49r0opZ/
ws4DDEbu8lNj1eGrsr5wpQi46rQgUlQxlgOq1QZR6SvJqx+dLTG6zVwJkzxMW2rXqavVTu1Rs3sx
v2Zu/7fpZye+VuNOIpjJ6SvdtyfnkTbB/uKEhEVWPJd1tdMquY8S0dQjwGNIqIiDSlzWPBXgc+B4
5Z49bg4cNkl7Z9k6JSeln5vUujgGZU/jxoog/sI/EyOG6NF8H+lSLUGIf+FUO2IOM/24j50YxwRp
AV0KV7+SjdlzX+QnB1Z0ucTsqNXLm9rdDphACMJ/9c4TcUJ2zlUEGSH9DMSwip2b/1wMhF4cAkm0
tX03lwlNyRWMcdJKDYSZ+rF955ipgvAp/UoEUXjMbUlvWc7MDhSxvGVKRK60M8JVANYtTArrpdL2
JsNu9bYGTcTNHUN0ZaAIvC/DSQlPOYa+t6qTGDEvqd2i/p8MV/wV8vP9kbJ3Dqn8dXoh0hVrfXu2
yW0e2HPdyU9nnYG26U+GioGHviqeNXpNrbeCOebdQWb8RjLhD1PpR2tuWUDq3cuRbArhwkyRj51Q
csw2hDyffnNcczZ2pMd8mzu7DkBaMVvjNl/k/9yacbrJBeedEI5rb0qiDj0OMbD3mQ0g8gp79A7c
WoMeTF/QevK=