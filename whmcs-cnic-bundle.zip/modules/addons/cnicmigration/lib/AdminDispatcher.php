<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr0sEhlE7f+ybuIlc1Q0EUVvEhI3uTFPZe2utILDkFTuSRYjj8VHx7lfFdTDyyavY/eK4oHF
8/qGHurAxsIuCXIb3QWRyDimhR8R3SZJuT80yn0FyZyGnDyZrbuWsugYWjZluG6VIZY8quS2xo2M
KyvB45mbb9YLA5vgV5FMTay4BRZhk7vqZ5iYm9bLJm0MUMsGt8jSbKLL9yhDd0FV7scMIU3LPiD1
2cc9HGF0B/mDL5j0OB4xct1707P3KwjdqugZDJgg0hYnXGO+Hr+xtZBlgwvbXjaZ2n29Qr+nKHl7
HyS8/ouBgMACi0YlJdL8y5tjlas6EodEZ2t8PHU8/7Fmzv15hMC0hIjEra+AanFxQzkKIyf3Ba6t
w2PNQVLNaq/NIv0v5p3hYS8dtitTYX26XVinudDV8fCZHc7uqIAkThA3my+Xv+oWQ2mM5lmhNLsl
OwKPUcll3JVrzFO2LwHHgCjUPlUuEqzC0UrA1l3kRvJAGbPEQbqhGVWmRJcJG/OkMC25XZH2OjHD
csfO2mL6DelvazezQgjKw5qs0B8KBrcwqOSjslQAa9gbGA8JUTmqMuOHrrhpAifo7FEa87HTC/fj
ftv4/h3+LS/QSGnFFKabFQigENiTqXnrKBC5wBJZHGU+rtkVN+toJLM6nBqNtw18KoxEFaDFzTe9
m1Y6VoStYMqCgRjeyGKr+K5Ob7+xy/bT26VmE3LBFeWuUUmZIDhVs6D9Qi3OrZ+lLH6MYlCLBw1n
h7QXs50ME/YIWxmJtjnRQAZ3/LzLy5nO+mMk8xSQ44qKWp+NR5kMWiI5Nh8B2Y8Z8OCrW+O0RaOB
Dn8vEyRrjDhgqAflAYB0B055C2jlUsCYOEjy1maq1wSh8m8bwQsuY4jyGoLkHk2oy4OdbOS2Sq0v
aUfswux+/1qw/W6l6IVf/YqDcJkjlCFzsGDDBJ3775eQRE80cz4HKJTwj6+MqI7UR/AGJ0qR0ZTU
1JM/GdNfSFzaABO2o6eQzfkjuWY1G1GlaNu+iC9G8VgFryKC5ynjzuXvBPoIAan3YxkM+rzdzC01
kVgX4sk1NA/8WWTC9yzCSwjWPCp8l7eccuBf+EGAZa3IIYF6uvhvaECp4KgxLIWgcMRAB2LxXwHK
OnaTgSFZMEAKhurm42toAZYaTefKx7vvPwbGby2zYp+MQ5qCKTGDxjzGPdP2c1gYivCvYbJl8UBv
cMxjCkyN9ycXZ9BTrxJKoKpDIRCEw02EGW46TkJ7R6EnOzeTPegbulDhpIf6P6RdpG7EPzcYle5F
zQj5qOlmg2rTzZsWfN4Ll99OI/CYweifoEDUII7dJAXp6sf4ErCbhTe7iZgh4OoNP1JiuVlBiMlL
DEqE0I+Od/e1UEV6ZgKCNtwwgKmh/6ZODpHzQGtbrRsm+zs1RZTcX0PjmsT3HabEEhpRGt3yEMJU
jvUhyKFwpowxnEw4YiX9m+VWMNH8uL66PEl/f52foSa2BHe4gNkww/B+pUabzG4rw+gFtc1RqRgq
DfGHlirpOOVr36eeyXipblyxwkxp8ntb6LlezhpjLssi9m2GqUiktw15TzaAR1rf7XeLI60bk4j9
EuXZJb7odTPyEj2jbDLUDrOGGgXMDtk6iMYtS3U5z+aDptgM60kGNTNfcTkEAQkNxOtql2MwDu7j
ev7gIevjAlPuBdjc6XbLmHO1xWA1Auy5QRmbWLhYfbIZ+XjtuqLhRXaDkxsgVyp0dJOVejtWctfH
I+LeNRCLZSNp7WCPYXWlucX2lQ32PAYfhyF0IUPuWdUAPFNdbmSxOB+J1ArQwiXhijKgtTQiEE7f
keapYha=