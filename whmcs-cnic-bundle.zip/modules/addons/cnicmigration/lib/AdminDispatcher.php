<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpEW0CZyZFdl+HALwpsGkRYlsxQ0CVUanQUuyMx+Wjesg2sxhaaw0BdqCtWQsrp9fk30Bv/1
rtG9dz+4JgCJwh99hzuan865t1t+4GAnd0MS4yZO8l8uT9njqm+6xv9HA8zIVEBDZF2L+fn4r+Cw
MfFNs1um42dJQZl3JN9CoSbrsnFNASSbQ2zg4ajw+BIAb0n/0UTTmnSKP83F5hNeMzQit2pHkM9I
nRQpe9GVmOuNm9MzMOyeHFEqpdg3+F1dFuVF43QPeGRaHq3h8KcuIEYSSXbmg9kKMwByZGidIOZH
ruSc/pZwHMIKmgsk9kmjANSQjH1vm3y9oSxOSVpPjk9BKnormWt/eO8r29Ucnmy3do+cWUmApxlS
utVACczr8t+jUpW1VB9zw0vbKYlUGN6sZIvmy+IeuvCLziICqvciC6GQ4kbqgWKIJDWbqMWK5dUn
JrkjnOgzeiMJWxn5fY6K+4KcxEtccxqIjsc+s6txZdQ4cNgyEgZL8ZC7jTX5eZWPpMBDGNzN7o6Y
IE144jsoHUZoNUXWQLpJgMCpD2c4kf4buVTnaqiv0Y45xGHnb5mltRAGxk53rABzmg4ddgeH0yuf
8+OaksYhkEk9iabTdrQa//95up9tgr6PofvigfECi0///jSIX6tvQuehlM1H67Z0MfUndbPXjNLU
4d4tof8RPuNylk2s1qeV+HXtzq/PEFubOK39NC3QoeiCwfCzbkdVxQOP3PFoH4IoJRDb1rfJ33Bd
c5w20x9VcL+jgQs9JBu/9t6TMAiLvJxwxWkWqE4AaxHPzjJ+2aYpw+H/3I/k3Y2zOatYG0x01R90
6UniiM73IJ59ugc4pE0GODqMez9kfZC+W3F3yk/+enDRR5ia+Es+ZQ+HH9btBOqR3wc1RNhC92jB
/X7BYLp258noL02HqnChiAmQIxzzlTFhOlnMQnCOdQT4f6j0pqRwqgsQTEgLiy181ulRqo1P9VcF
lLtCQuy+cWBMeRyx+jt3GX6uWiOTxwvWgTw7lT2IqVK5I9B9Ndn1gLt+Rs3GVxNrHzjSFs6I5G7K
xCL5RP7NQe2Q3kM9kPcD/eNpUUZC8YTFhbht3QkbTbH7SW76Il6sf4pprl0JhRMhEXuTv4+9hzjt
LYJeouLWlduMCH+Zq4a1h3Lh99tXIvf8tGx8esd8gcbJJ8kW76+DKeUdyaXOYVCfCUqtV4TlBtBo
lcOaBUWR8bluW/BmkCa5n+LLs1IRiaWPiB+3vqvMPIeWyTQ2HsOcJZ3TQDzou/CgX4VyAPKXnP+K
ql+kJB6yWl2XelSE7h1rligpEjs1iU8kQzh4GEMGmkdd5bXkHIzgvuP9cSqowaQleOup4ip+cDOK
bmeX81/GCPPB8AdhrLLW1V+1nCDlweUKm9a7RxPjO6qqeKGVkC+EXU4cUGwMgZL08uvM54GfZWIT
Ugsr4JAo+PRnbsIhRKIHyIVGM/6S1KOwrvDg3Lzv6JLuHCVVbShDQnHitU0ZL/6ul2Rn0uWW4kMN
XQlUnD5DyvIo8NIYPoRh8xaqrbQR7600l7XfEPe109FMI7937Vg3BEg7+amJ3m9ybkkZKOpPGGto
i/4/9SpvhDyF1BeUw4QgSMWkfTrOJMEHe9pQGM4jYJIBa8aj66JyLQs5OTJVPDzh4QtGFMUt9Qc8
EioYoFaTLryTH8KRzGbUTv3s6LB4EiHsYok+zQjj/U3Lg2xNtnXry9BrPTu6CX8x8aZdbOZpY+AR
hCtgM8z0kEZGJNL/dP+izZUHdU0nH/k++7oZHQZvzFHetJPGN1pSJXQj16AnqLPuavnVax+BHGFT
