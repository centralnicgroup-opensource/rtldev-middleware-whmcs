<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpT4VQGwg4MCm/ReX/W3PvFBJOghq0cFpgsu7Q+GosV9i9+xVYzYi/7bniSw+2x3asB3v/51
+MCNWnNmJG7YtWqGH4wsiBvZOSW8YyLr+D6J9bVJCypnE9+1KKACBb7+hRNy+Zy6KmqKb1DKkPnG
VULN83vUz1kT6Vp5q4xOSD5O0XyoVaRAItjO7A5BHbAv6sW3ds3dVLRjYyEXlwQuS1rjOMD1Y707
dOFfqCNJ+ebwFSPg2NgD85QZZKOupLXIEmHwFHgssC1YTuRUSO5ryYqJAb5fw40zQ0OBzHPQvet2
J8Wj//aPLhB5WltwNBXUFQpv+QnPteJXwxLILyH4dmkbMfeqO8yHSP0rnEmpFdY2A4nKW5PmpwQK
sQliO4vwReVLm2D8WI0AizI/X+pqn2PefHRbcAOIxZa6b2oU1zJPqUEdz5mh5E6oP1UfXX8NXC9K
tdf1OxoaKDUePyYLJu3Ha2dPCowciMNTjX/DLvY4pK7AT03KQ2hU/0n1WIdZVo7ut/BcaMHG/zd0
SZqPeMQSH860DfNStIo9G0PMYsvJeJFk2SCtgHVR706ue/mN61kmrMEX6u9xngpqFdL3N1cnP1cb
IP+EONS+9jEbLGgpyzfh9y5ESndpWcmxTtLEZq4R5tzsx/NhwO6WyEmNzXg4xfgvu0foFu2WqjXj
GH+yMx10lbMHbR+TngWqSvYY9OPcwH3skID5cZhs1xGUsnFUs9JFfj1tDJTXE2JdZ0KV2+/pcJ6r
bjJznyM3kjNv/m6Leq8UEFqkQxtLq+NG8rF81FzgJjQW+b2SGfz4TOZ41jbI1jG0pKWwsStcS8Lq
/eWgVuVD3CmWJy7KVL9ogI4uG/gMzCzivpBsAOFIq2bV/YyaIRQDfDGdAXNRYMTab8B02CYt6hA4
2S6SjNsWTMlDNzF/M5PR+kcxaZBbI+YQn6OINYaWAaFwmGmxTmGYxGC6jVSuEyXo8cQWhxtcpXru
CG6dkjgn5HgNIIlBWDBGnpNXi0+sgSnjUbMixrndDwaJYPLG4buTzVtQ6IN9XHoQCgetA6+pAi5K
uMl3QCBB9rURvRSxCgXYtNrbtRkEzT6QCV2tdBfMW6TcBmJkFrvMlbSPvsiLUP0+g8xhrHgjG4FA
FZ/kfj/7PRZpSvoq11cZfQvZaYXAJH7ID3QJ1zP2A4Vo0JOde8QsSk8ZMNFS6z5NiduFq6+cq2BD
NCOWa0X5WiM4LD6GL7fePY659DggWE3mpKEis1/HUp2yKnv03BJdMzdGYbepDqXPo27NBK4f1Bv2
qnTuqgVixV3Wqrul777g0jEcX5bVHz6AZMDuAqn0DjPHeF+avTZTCx2+494UCW/J3T4UYUN18M7k
SiiT5gLdvuGAOr4MCi22ATUZfsDyrImhPd+RnU/Ll3xVEVz2/OA6dWWEEZ7Epa7NFmvks/s12QYf
M//gawbpjl/k0CInsjNOA0SfsH3isjsiNyuGsR9lmu1vMZ/Y2sSAXPvLECsEb5QHV3aakaFF9YdV
W3HGrOhS26P85mco0R6G9lQk4Rjs1tO7qEtmN+g011OssG95d4BeykEecR3uvL6wR/FTh9R8vDQX
v2TOtGyk3gDVQ6m/LzPS0qM3nBy94PpBUausPiPDB5aDbDsSfgn7fyhSspDKbaeWAyeaXs4fC+k+
Fw0X5GS/RdYFcl0ig2APAx0Dv3UNp59h4rPa4jWBDu8w0QELlB6nXj5VhpORftfntr+PdIX4ZFZO
O4ObRu4Xw+F5+Bk1LGIpDxqOosBQsSd7PYlqoz28PFQzgW5H5UF4+PMYvoXCxV144kGmDb1Ja/Pr
OwcWsXg2sPZya9W6PCJqpcQsxaaFT0==