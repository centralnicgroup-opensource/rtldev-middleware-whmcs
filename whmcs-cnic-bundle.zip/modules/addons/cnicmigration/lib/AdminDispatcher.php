<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq68zjdmLCiUZJfZ+hXlhr7aFI/vqhSMbBsurP455uMXTwWtN3NVL/b9WjhJ/I7P4RevcuuT
M84RuOyQf5agzNeg9B0sifh9dZ/XUFTfgOOR8QQ6z29PSsxNUbPx0yJjLJ0rtPVjERMDwFlSIhTH
+8vUwPAWTCsWJMxvCKfi9scGtKW3Ba7sHJHYnKnwo95SkYaj09i+Jf0PR20IwvB7ZBkZqWzelghx
PVsYnjGijHdjZTi62z/J199d56WVtmW7nY8Wu08rschs7159idl4hwtDlrbg8T83qdbffKd3AXTO
WMWc/xyFSPLfjDqbfHmglFndU5Nd3xAbwWtgFpzkDyqq/NV+YuylNEqQJ4mdR/ldZE4iJq9M8LEG
Pa0ksN0pqK0bZ+U9TCGkHie6Rk1HUtwyh75GZtfpjNcmkQeu8ho6YHLPMa/YCSqwJHT6kQOIc56E
21RFVYc48tY9oLh4z3PCzTVT8yLbgGvGZd95CHlx7XeL/PVmEQ9Qhz+iZHQlJIywa7KGOtIxQ+jv
L2HcE6bOMR+S2WWsLTq6YvT2YZhl7btbqw4CkmhuGK+blgfcYjDB8xKN9c1q4OvF77U+qYCtKRQ3
pBZLwQIV27REYywdRBijzziRnSDX4uQk1zcavEQqD13/rtR7pqSdxw8hRnDifvDkcpIvirrS319E
9a2K/VYZGWCIJ1ZU5LIim9ac4uimzMPWg77QrDlD9jXap5eCyDD+/YkSFVEvHruA8t+S/OusWLmq
VZZVGIm2Vqzz2XLa75/65pqmXr9gze35a7VWTKxW1t4cu02RSURyoaegzyEcJD1KelaCrmHjsshO
gCkYSTHN3mTt/OJbdUg9PGj0YG2reulESrFxDdyva04i+5pSU1yINst4HvaH8AN0z6HiRPoyqJl0
4SVjZ8o2YJ1Pbly30IizoS6MjRPqEY7fWFn2d6SoSk/hG656xpgA/aZcsWd9EkbtrC1J+TD54yP3
fa0+1lyjlOQjCun4UazwjuBBR4eQnR6H/TnadLAABCj+QXdCiG/jh/Ef5I29kNJDL1eDtoIz14mG
E6MuboqMRE0Oi4WZ4BQvnPR7UcMiizEEj9dwnvVbOec9Wgu4+MOE5jTO6riewOVv2mMAO5jomiwl
16quRVuDW6CT53asEpHwE9qN5Y2WV7FTvDmnzepNmsWcRG9vYO/6oJ3GDFTUf70haR3RtfUQOis+
+liGIa6P1iZUOgkd7e+EgYwJMTRodGG1ekR6b14Sc6gq+l8EwcYjOCMtnGIdLzcKp2bU5H6b1m7m
5u2530buSIZTKcMfAkv05N2o6qXLi4QILW1fsnqRpy1mLNT0OHIVnp+hPYAhnWIcOHcF383CtVx2
fvTG1A0F2qVCzSv3w8Fzt5oLDL5vdviA1nwwdYI4+b7FkblIP9Gk8Rv7afajNaeE1ZH+TkLeEExB
vJfKeoMGFaCQVvT4UHEXDvWTL2qIuqXNj+CFZWWZJDyQA8k3xIOU0xZEaFlF8mo9Pewm9pALec8T
I2EWT/Dp6aXaZ7wgXb5DRv2suci4H7cwRrKS6SiTyAxlbCYJ35++LawvWPuD45eRy7tI+LSMn1og
lZJwWz07QD+vNUF/i/pm4HCWgjgGVKEbPoKRagmFNvDhQAMeR1jtFHEM9rKquuXUQ0NXxtRfkTSQ
ihMW3vrDREi61GYKlZXSnYuQ+n1y9bsssVWEpz5+xV98VDhazh1pWfVUNAEvmKGt4sD3XwJcyYVh
dGBL+KVnP5oF8wZR+xcOIxeghSA9LU4pMZCuMAFyrBDw2mrw8IocTm4+ZxNRTsNiZIgvxY4Y70==