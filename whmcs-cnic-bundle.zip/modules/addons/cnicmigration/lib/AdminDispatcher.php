<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtaCJO+dqBMWlhxOh7gjpcAtgfhSCytbVQgufmRac1sb5Df2oD2yrxYOcjl1a6ictNQkSKK0
POMZymPX0K4bQYnheZ61ybGXNOFxmHa+vrdi6P67VseFzwWrz4s+ZGo6gwS2w2kIPbNSnVbVlKo1
oRa9E/jDo7psOgx7N73iG8vCPjP6YCJAOx8k25wPfPqUAoHvAx6kM3OY8nkMn8LZmKIWn9U3m9U5
Xtw5p4mBbzpz6wVJFZ5JeITH6J+LMqMGFdFbgu3L3W3OXwtmeEhzGSlm2J5iDQfrmsYabA02lqP1
H4Tw/p1N+5Naf8rOORaedl1yIR7xNPmtDP3msPuOMItmsXAMgRZ+CEpDxCuozJBD5ANJovgNa63k
opZJ2l1kwV7/XUfOsXBNba6jsFpT2U6dAeTIbLaBDmyQuwftrosvkrml9gF51RuM/8nNUQI41SCp
ExX6HVznjP/VIZejJW6rtAmOu6e3YlU/85O6MMzNMxhdDb6CFVrm7QisbmmHB8BsQrib2LqfKMrw
otrHyRot1/qCwzJuTn9Z03zo4PqNwkjcBKOhOrslOYBjwn8hXzDZ/tZr2tbLSgEfNRNKAx+ke65T
tEljtgYeXXlW3ce6a29OkXuYcpGs88V4kwPToHV/pZ7/bmzjdaCJPhPvi+Se04EEPsHIF/smWc33
aqbtFvnDAFNliPX5mMh1u/fgrSWYJRHQay3NdM3I5Mct4z/TCr5AMUeQftNtOerDG/kPR6K1nh3v
RPkWJ73LI91Um7PYH7C/yTpPj8jQ0P5344RVR70GykIQpVTVZ91bCZ2oBlHX1T6VgCAtUU96mNQn
z3x/noa8up+EqwleWFIL7EXuui8H4a3ejSL0WD5t+8OKcZEUxEfThW0snnpJ0PZBy6wS+bIl4Zj0
zGVKexioNpcFnDubZ7wv/MAdoAmpGOoWeWGszcri57ycIci2BXWjfrW1KeYginQbqszUI/MvU9+1
o0ue3lywApswLjGF5xqnjma3GrRxXMkiZ9ZHJyLeZhTNnN4RjDX7v65QEtR97sLYOl5h4z83+sC5
L/mMKDftLi/GsoBT3OSFWDglr3lOz+pnBDQfoP5h9F8RH+kuQZAsWOhUSiZkgC1tKWxvTmhwWwFB
fgKVuAtEOskIHYGveiOKaWM/cHxTjz2yMXhzT88dkcmlR8ABuaYz2R/GUQRWlqaqjqRW5DUmdcSz
4xp/ZBn3AWj00VwilUDSOHuGeCSaOD3LI5LL2gnNtXiEqz7CKpqlmxHsVP7Q5AkZ1AqsN7Jo18Ld
fHQEmfCAzfFx4cQrxbU1IISm60f+FqdsxtrUxNJ1hvyrbs+5+94h/s3ADKC6UkbefKcQGBgBqyht
gA83Vl9nO8uqRrbfwNLjuiy6AQN44NzYhWHw0uErxv87KIQFf/VI023OJyzaW0xIeu615QeK1WAE
H4J7yY9J5CIeL2mRjLEDfLps5Tw0wZbHuvxCRPBY71HnpLTxzCxFRijmzamj11jhxddjptJ3qzur
JmB/yDhjYIqCex3ctWALGH9dXbMTJ+sd9P1s5srEg7P1r6KtgO+cDQm9TJqc3TRmArj0tDhuHGmC
qwDW5aEGw6dicVQsE5g2e1w2NoWzcq8Nj97VWXO/WoO6zEVpNJ0bwgCaTByqZfkTEmM8kuyNEMtc
wNnwxW6/WtXfVMLfLHWRj20P+8iTuyizvNOnPQz3e1gfj/MBZrExhXeWlow0YMIUqYve03SLDgOZ
v54E5zBTRkUTQYsKB8HkudsTIrzuaBt5G99JfQceY15B/VAKx1ZpR2kASYFqSikzhur31lxg6pL+
ewqwNTi=