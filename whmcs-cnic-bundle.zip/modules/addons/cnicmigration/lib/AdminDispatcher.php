<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/du5kn+HEl31qg3pra2lK/gCSjjdv32j+oXWLl6jsVchr7bR2gPuKapXgXwlEsPyQZjlCXa
oI0SsM804VipoDSLL4yQxX7WSiqu7tL5aAPb274uPOvH1U65AnDG0ORqkGErBncAftQzvrkTiyjK
EAEMc+pD2KwxOs0PDiCMVbBLrVCQfxBCyExjjLR8x/cvwFQKrMZIMvaF6H/ohW+AjLqWksB6Es9v
9HJ3f5Nf+75oBldaJkKIg6Pi+do75azR2mIveJJSBdtRSIv/lRHX+YhcDVoTRja+YVTS/LS1kdnV
7Cic5nRiVZ4WiIIrreuHETO8AQVYtTuwadqTbmzhwELISm1V3iVBOXU+vplICE9CA20gttrjkM2p
hhoqYw8qrefvUIn7CwBFDR6anaDrRG4w3bpdw3L8Tmfu5M/mEQohaxF/m3AUwkr6PVB/1QozBz5X
VN+mf4GC9NHF5maa0vI17x9gSgUjBT18aqbId/X1IgckEzmXIu0tO3vrS9f6NfrJACNPHEE8u7nG
cQ+J4Vyt0hHfwwluNM71RsoqSAHBbbj1uU9iWHZaBEHFiR9hymUkeoPH8yRIEdhRlvApMgRyGJ/3
IIeSJQYOT31B2FHVNdOnS8btu9Ba+js2VjXqmVQFFgUB3xPNDa/HWX50OaZTaFTVFfOrsBXPCgmW
3Snx1Z7Yq2qjiA9fFmCoBxnAmsRDPlMvlK9OW5XfY4ooyvSvJ8xwXLhz4FN3t77Bb6rZCaRQhTDs
2aE37GHchX/WO8PazA66aVNvusDtjiXXVpiU4DZrZJH5aIhc+8NoYyMGPIChOlGMU4gLm5DcgyU5
9uL2f5Cr5Fr/EXGjYJkSxyfuh9lociRGFwGaQZwXoJwLqhpoppUI7WEhQwIXV9hhyoZFmmnnU0RF
/OfQnBWSBU11Z40REM1iAQdclYeUbd+gtAr2A/3mFXVjQJt3sRGrgiMRBtECZU4ZEL/vTpcqgCqU
6g0AMdvRJgdqNuUsmtcQ3F3tOpg4Nw+hLYan1Fz4t6VSa2YYNIbaPH3chUoAQ00UVStjpRrK2UJ/
O6ezkd1PcsYjlAiBNNL8zr7873HuEUnSO3ya7TLLjpDp4XLMmZtAiRS5dWiczaN2dPVQqBJbBC/y
xPkqWDKeStz1yRslialdX4qdKkGxxlGtBPUmoW0ZbGKkywX1JdqVjijg6vUplKIhk7vQ9iFbmPbV
TMHou4XaSJQAuXjh3uq087QLvNrnxYKFOGZgIQIoyKwqQ16Ga8JqVP1ds4eaQ8fLPqeS183hIYVf
VXDr0Oi3UiJig+WaDhku56SdOX0MCVeq+KGpjQJwCswn8kUmS2WrwP4IffX7MJFjPFN29j8M/GQN
HtwezuvqUdugFIYXrFQV2UsHrvrvGlOt4p9yDazYUc/cD0AB0w3UfOoPsNNBRe3jMokM+uLUvctI
ggT2Xo2GjcpZaTIAYmz7V7or98Vyj8zm8EtHQ57ygYA6x0cGe3VTmnOnWmSH32WIhYYTUh2WNNWq
CxAbaDQDTNUluzJHjedRXfJIIjFZf9522uwdCFO+5ykqfbQC9qHQBOicgMb4/oYULeD76ZuYhQSb
tMPfXcMHegV1LbYcXhedCXU9BASWn9g7LJPYZFo5apv+uZRSnwgK9EpQPznihcL2KJyY20zxD8HZ
w2ptIEK8Sc4QBeZ+0sQDCZVsquDCOx2yFVdjSmfI1D+XEe74SstR37R5W58+EN1N9yO1iM8WvzmW
2Q13tKleOTBmC7LkYdmbnNFx5u9nu0Wof7+NwAIK4nGU/EERCazmjG+MKocZRuBy27amww+jnJbY
8tjPvGfuMRz1CSiY