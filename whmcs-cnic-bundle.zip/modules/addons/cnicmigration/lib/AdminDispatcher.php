<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmYSL0hbOAqjy2x1AHf9jKBg6LexgWIwWzbRLyOpeeXXGNtH2iaF/Xeh0VRU0lLQ3THVCHHs
xQ5DjFJsyE8O5qO6/ZGgKVMcFJuQTdS6AClDYdGArvNCxwm8UNM7H7kLG9XTvQ0CfkdVJcA6U9f5
b/SnUdTl291SpFMQXdmkMlFdQmWRahNxDmSpLpdtoWOYRC/RyX+6MAp3YxTAIyMk1EeD+q8bada8
bXuYrpVKZ+tCDzRHdn+84rvAJ87jwbBzFo4XMOpIR0DWzI2v+PfX+UHitzyQPzOwPD+CpwPFyUoC
zqHdN/yshJYvUnubbSt/Hx3+BZ4J0yfYsQMmD2y+CodwRJtyrfWSZ4IQ17TyyoxDQedQI+esnx7A
hoiS5WgXX8Kk0R9J7KA+NDf4alsmlTv1DbG2Q9CmhoAd30MFDyZgUUM3cwYYGwGsRp8q4/nTQK9V
YjduUM+HcJbcGpqxAbgM03J8r16c2JwZYRRMmzxWNVxOVKMQtaEJPyRffMF8P5AWJqLnKPJY5SWD
neF23bkjgfWL/UUis9mAHBEgob9wDcmuus5bb5wIq6TqJMbkQESqRdhrshUS4gIVpMA+qp5L7bX6
QiSuwS/SHRCXWeTnd4DUxEuR+FeN6cGVbOtirdcP55CTHQS8mqzlrzn1UbQsyux6Z6CMB6I5muu/
DVT1qjUUmbjj+DOPupPgTdJbSGWes5POHo6cXpsUsqsJ7kJDc8CbNap45NrLB9tZDta00e+c4vOD
ih2qpUwIfcGelddqqi6tpcJHapiELuq4K1HVSiRsQmqmb2axoCi5G+dQZBMi5RY3PmmzCSEDBMVT
aVlgi3LV9pIDhhPmjefFPC3IA2BqE/HT6el1AtVodMxgoDtvG1ScIFvC9qcdL/1J/RFrSM0ft7dK
b/HnFr9ar+4QhCgCR7mL569XtcRgHGutPQhutGHgV+6WALGAZC434LxlnCkvyRwCKcoaLjEuOAsn
TNXD/y/tEWN2pYp/zdE6wkOalv/KJ+zaUxg2kF+feXENgDjHi8WsILnYvHi5O9IJfr0WKjQiuAuh
NQlkelbansfaA6bdngBO4RDvUZWmzafMwARTBnP0vtRPvjW2nT/owKSSv7SVhLiZe/JTj/lfKh4A
HZJhghVEh/fCcV7C3H6U+7XeFpGRYN3eCr+XTPQ72a+xclRxkExuEbtX4KIZ1zG5nqXAHEfY1DHk
uQynAl+lRTt4NZzFwk8W6VGYcWUwo1aUGHf3WoiRCf2BPImTRiVyCOqLPVVGFUwNR+Q6nWZIWVaM
TnOuZpYyBDd2gMwO5F11NtoUgzcXmbklgmJX7451itzVK0Ot7WVuGI+SafGeA4uAi0zMGg+JNoXp
LlyhQ4C6Btb1NI3ODJFcvoJs34QOYHakNC1ym0obsu4uKX/J3mDwvxXqmhE50DdvjcRiiI8swBmC
/TKou6/JT06Taa0kZDr0yHdHSfwAImwS+KFreb7kaC32XGxPiv3jIbiXgMzwPxVK5XJFXG95FXjN
Jm3+g0/Ab8EPi5/v9jCfRClJO7uLPTgJbohVWT6NzB6WhbGVLqic454NQCZtd5o5Gb4RiVJkUaSc
ZlQG5+/+TeugjpMFGgzJl+ZBOHz5oSEWWAjXX4OtctY7sgDkrN7zZafe8evNo4dNDpXmzywUtpT1
5UttnKwZWPR1uOKae1yEQRwzh3f9NlaD5t6iK4NDKThytO2BxslbQaNSLbFZZ/yBN/lcTI/YQ+lh
oUVNfRoZoEj97sG7MJ/xiY294t3GmPtcT+F5OscO2RkrAS0gh6JxTCw785QTls7JX+aO4NqQ1Xix
feI9lJi7zytu8bCHwQH7HVsb