<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Smarty;
use SmartyException;

/**
 * Admin Area Dispatch Handler
 */
class AdminDispatcher
{
    /**
     * Dispatch request.
     *
     * @param string $action
     * @param array<string, mixed> $args
     * @param Smarty $smarty template engine instance
     *
     * @return string|null
     * @throws SmartyException
     */
    public function dispatch(string $action, array $args, Smarty $smarty)
    {
        $action = str_replace("-", "", $action);
        $controller = new AdminController();
        // Verify requested action is valid and callable
        if (is_callable([$controller, $action])) {
            return $controller->$action($args, $smarty);
        }
        // action error
        $smarty->assign("error", "Invalid Access.");
        return $smarty->fetch('error.tpl');
    }
}
