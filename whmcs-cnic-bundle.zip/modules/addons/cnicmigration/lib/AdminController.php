<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPspHpTYcTpOVlnjO+ybCOsJAPpKZQXdyvQguIjzHrkbPK5Wj3n+mzPyhXxaLqL3fWPOJqrfV
2ees77KXSEgrhSW0E2NJzKauZlmv5ujc8kzP62YVCy4iO/VnsceKvFkpn6cKhNJIpeW0VXXpZNKY
5+F6dF+n34ymWh3owWDEFXrmE97jWbiH6o69RYGCG1qh/ahDbqJz4Lg12vbAf5oHOlj6mMst9y+a
mj2zvIaByH1o+Lyn6DVQHa5iiSBWX8pbBSQdgjBlBs8+zPno1ert3qkNOuDcFJt4SC9uBqB2pcGn
swW0/nB7QhlGttmdMLsTB+dr6O8Iegl2ydcXMbNPh2RPwwXzRQTe0oRCN6SGwy1gK9RH/uToZXqJ
In5JhAMZYI5+ImsblC6erYd87ZOn/Tpn/0PAWsdOciUD6Td1u/90nV3QvKfXp/ncuUVXAfN7NEQC
LaWIEtLqL/BjlXl14a9uxSL2y6j+5KSDiliOb9FU5AFNFRNz3Qst46bkANe/LD8lmXxCKR+r5tS1
xRlGQ9voM0Eo/OCOjyLmFODPAjDxr15HiNgkdi1JHs2lFRKTzNJDtDIqeR1COscSehTc2aMoGzvY
hnlNB+k58M5aN6FaYUJySi2uLOKzxJ+LYTn0k410jYx/JFTccE/20vIXytJz+raxRO1/TCWe9Ylf
rETk+NoigMqi8uakdA7N/kRYMQhb8VLcV7Yqti9los1580A8/NB4r4eLR5/WLeyzxHBop8ehlRXa
PNGQbqeSnzaRfOfDB3bLRQnr+TVrwgEmH4+nJLakUr1SeicZrmW5bwV39vRzMldUjld46OQJUgOE
eNso4fKcXnH+CezpinaVcQM4CRtw0TC6sVK8RLpC1RwL44jpVEb1+4DzZnJm5OJ0+VHIfxl7kICm
gxfyOcjGHe2RrFKATWnDUg+E+XGKVyzyv4nPuuQXYuIuBKR5vafbO9iZZyJmO+SHZTknX5hCo+8j
yfdh33Brfzn7T/LUrLLi0oGhgtFCszfuMuorEiIihijmi8S1O9ePJU4Hn8xtCxqQnjdabayzlenc
Mym9tUAzi4S/Gs4jIpjDERMTmbx7wvKaQ61aD0WeOQY0pzCk7hWJhB2qdRPcITxL1rBivv2cQJln
Haz4tDiGACkcYLr7H5VcR1ypTqaWzuGt/HAKA8+wi6fhJXsATx29YfLlGhArparwbQ9js0ZlkQa3
e/QSWKKoJKH9KE07Y4g+hAYEzDc4xtiG7l7RX2izB4iU4I9wqmg3S24OV69ru0sqKnYiHy2J/UHn
luTBPFRCTWy+pa8UdD7lCbfTB6Z1zxlNk9LVxekoLmSIdyzcsP5Qj/NGTUzDLvCzYcXCXGON3fd5
PQrrsujqmcWFECOEAuPO8yLDlWyiTjoG5It3f7jRvf+yhMXNk1UsllOD0zgzySk4v+US5njaNmb/
6EfQslrLW8POkLUtce0E+cSMO8sqZIyj8i5j1DyE8wQMcc+HT/Rffzet0lLegd/YwoHztIhs7Sns
roCOKMaOLmuC3HBK4Up1IJSQaEwRPj2kSEZ1qlygARoN3Pczo6TJQDKbvJksHJYMtInD2bnyyVg5
im73KvF4bxeGC4bvUXukmY/mGlFHh2lanQ66orm1ovpEFoCAKTm1B/9Hes9SjYuXILDru5EdfPsg
7rpvhWjals7I/448u3y5kGq0xzcVI1IHZ2Hv0it6obubt821pd1rPoLcf4chedWbvMqztbyGEa3j
ObYJwScke2En1Z3ZXeSB8B8p3K4+isxsHKdRBAs63JQeqNdRWESpyml1HqFUzAXA2Wq3fPWzBtN2
UopA0W3Zqss9dYbSAt8NKaXFKu+q5eoliUK++xzvERfVO2CDhfsQ0sc4eEx8nMzZPytjk1ZddPJY
RsT7fFQDxqNpiTCIgCDl3ux/O7xRixJGgWpCKGONHSBxA+YnkxIHrqSO9PsZdJyES2dzsW2jbxk/
WA8OyQ0Gk0tEVr+Y6vYrUJfABeHJRxO3/EVH5uD/eHksf8eGIwswr0otjkDo14zzA/+DlseZ1BSx
pKIGHbs2lsI7YBODAIXO2DTuJYlbX2v59p/7EjNN2lDeQWVsR7VBqaJx/2+eRDvU3dMNkRFd8TCB
Td2VX1bU6GDIGUZ7bPx9nGddCLjSeXCGFJ0uAhOCMrGkIGrX1hBW6tfBNGokDVHksg5V9YlQJAct
ezKZV6VISH8xEi8OzSqSe+q2FhX1c/1CeXEgKd3Ol6DG8nl5sq3TYDMkHMbz69Iki9wplGoiuSRq
KaLE1FOuZK2eNs5YVpIoazKexwB7zXiJ/aT953BnVoan+2cdVoLe4UFr5JV3vm7Rwqt+hP35DhxL
rdI3+8lYzJ7sOnbFFntmA00KWAr037jqofmdYow004Mr7e1p9F9CzMLliM+07oEgAPbNGAqQzM5t
K+6QxKn0saCj22ZUDbG3eRDpXQNohW471ARCzZe1rr2vnup0iJ2gQvJoNEibM8g2osURxmD1K30a
l6ynMRCCSNS+7E4k+XZN2jZUwx/50Sc8wHBejuQGqpHfwigVrc7BvHjv4aFO1xri1JOKMtr534JA
N5pbaqNg2eq52xMy1rscDZge478dO3WedOJNQRhKBK96QlAKI3AgZx+tsm2N0mIy7Ui0KN2N+PYf
hwFqddjGh2TFNfNN0C3qZgauiaBs9TI7GOt2nziS1PzS6OLNLNWdP1jIP5mYrjq+jtfpt7KlN0DW
DZWC3N0Ndt2plLMP0dudPCYq+x0VP2+RbAzt5ND/1UVzvsg4736nsYfDGnwLy07FeLigP/63cB1N
GBVg8vXDElfJgTbmhtXrnL/w4MT0xauW6lLERRYseijsIGGx3x8Zs6JmlT5UEtSlwF6MkQiQ0nHN
3fdkeOupUCtVwSB50riWXBIw6SOXBJUa0pjmcMpM0OHLn8zLEUg3wCV/NoMIgNc2chlmVxXpioGG
EhQ/VOOQTBNsVKSJ2cTGcoHJXcpx1aACys5/2rsPDGBNQp2slehTXHHHlG3aI7F+2vKcdvMKGDrB
bkaF9bboh+AoDpJgTjpnFSjx+hPaASdV/SSUUF/emEjUC18sO5Tt3KKf53ZcZ9vcpiaaeS66cg5N
g5UjhSikiYuY94XcsMchm1cZx0B95f99JAY8d6CxU42qPsoeNBnOOuyNluf5Guu+R9DVCr2pxZkk
H2blAVHlysrZwm0x52smMteQK7hBIB21ey5KhOEkpv2HdJ5NHYPEgSQ6tJR3XyIYW9BRfVIStSsm
0k5LdeJc8tX1ZnhEMqTnuh3emjIZUzJgt19ofPNDAkh8TSjXLHE8Cfjlt7jcQ8rTrPouedwv37ty
3BNE0pJUjbs8dguC2nzX8FSAj9+uMwPj2uw1nqF3Aj9hMNwl9MNzVF8UL/S0TyzAGkTtkoY1pfnu
5xk1mmex23Ez0XNfmxvOv0/79WrBJQYac3fx2efP6Cu3I0PX6ooR0qFSmPlZ86+hGs3QEDG4L2qK
W6Uq0GDOdr8ar/5agfeNwFjs0dcH8jIRa85dkAxnYzwvH2TIGjYDyG3KK/lWuJie895k5XDoOhHz
/3tqLI8BBu7Xc2QiaoiQqxjXm161Hs4Ar8n2ndNku3rYKDWg42MNrVH8t2PPbBnRdJOv6gtYQfeW
3vLAk7d88oUKGNxzLQfg29xyPBttgOjvshogrFsU4XNGuSKUHvFrK5A/IqRKrZ3Z63va+DyqIOZe
ACYw+MNfR0KfLXvlVAuiPkG4dfAWJ4pkHmJN90Y+dj8KGtl/xQHBHJ2QNyBR+X5tTt5oDciXXDUQ
9Ezb5N60r4mlDbCDDIHcM/oAGcidSYonw7ePVMLiNL9UdNkJm39sPy+7+0+5jRRIOTo6HEcUupgc
QrJNsWOIJAp55CIA9Wabfo/37DVf5p1O4IqePMDcxC4SY+3S4cG8CRWqKXLyIhrYEOqQ7h7N5xlL
C8jchfid+07RxsCL96s89mgZVz5xRUQ83eR3CSfgAyKtbQp8dbEKXOTXsMJUvAdULXt8URRvTHBb
L4mhgtJ4w2CGQ0BmVK5zptumInaz3w9jIaDsiGdyH6RQul6nrG03OqAvhcg6B0FbZUQDQv2h6gon
aTjPl+np5RtZKkktFPbgC4yfUAW/Ufp7n3xbiFuXtlJyqPh+rLWDeuOee/J13/rV68UAnn7H+civ
2q5AqtOV36k7ENgddDIxp3qimRESeNtnSBWD9avRrooNZXB04jAys6nlw7hwCHSxhUBcLNp3FweY
EmXs8NtkwpRMHQXBoE8FSGerahLH9IAe9Y7qbsyYX80Nmi6F5pwRYiZmA5TZMySKlHSCjtK2fjH+
ZUpVTNUk69EQjHWYf4wrwi2KPUw0JCmGKiULfof1DrsosuzaULO4jSgaf3fnmUfec51oyEoS26XA
5VzwFK1p/OZU2t8YcyEcDwLTfk1z7nOmUc4djR32W0B/Xe1RsXGpHL/PEZhPAe+ur9owWIjsBSCx
MwZkLGJY0lSnwBqHQbnb8kXYu9dK4gPJtPenUTpFuhHil2gyj/0ZBlvHLJ/EP0be3GNJpBYV8AGm
