<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Illuminate\Database\Capsule\Manager as DB;
use Smarty;
use SmartyException;
use WHMCS\Module\Registrar;

/**
 * @param string $tld1
 * @param string $tld2
 * @return int
 */
function sortTLDs(string $tld1, string $tld2): int
{
    $a = implode(".", array_reverse(explode(".", $tld1))); //com, uk.co
    $b = implode(".", array_reverse(explode(".", $tld2))); //ca, de.com
    if ($a == $b) {
        return 0;
    }
    return ($a > $b) ? 1 : -1;
}

/**
 * Admin Area Controller
 */
class AdminController
{
    /**
     * Index action.
     *
     * @param array<string, mixed> $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return void page content
     * @throws SmartyException
     */
    public function index(array $vars, Smarty $smarty): void
    {
        $smarty->assign("tlds", self::getTLDs());
        $smarty->assign("registrars", self::getActiveRegistrars());
        $smarty->display("index.tpl");
    }

    /**
     * Get list of TLDs without leading dot
     * @return array<int|string,array<string,mixed>>
     */
    public static function getActiveRegistrars(): array
    {
        $list = [];
        $registrar = new Registrar();
        foreach ($registrar->getList() as $module) {
            $registrar->load($module);
            if ($registrar->isActivated()) {
                $name = $registrar->getDisplayName();
                $list[$module] = [
                    "id" => $module,
                    "name" => $name,
                    "active" => true,
                    "isCNIC" => self::isCNICRegistrar($module)
                ];
            }
        }
        http_response_code(200); // TODO this is temporary - sometimes we get 500 and no idea why
        return $list;
    }

    /**
     * Get list of TLDs without leading dot
     * @return array<string>
     */
    public static function getTLDs(): array
    {
        $tlds = DB::table('tbldomainpricing')
            ->pluck("extension")
            ->toArray();
        usort($tlds, "WHMCS\Module\Addon\cnicmigration\sortTLDs");
        return $tlds;
    }

    /**
     * @param string $module
     * @return bool
     */
    public static function isCNICRegistrar(string $module): bool
    {
        return preg_match("/^(ispapi|hexonet|cnic|tppwregistrar|ibs|internetbs)$/", $module) === 1;
    }
}
