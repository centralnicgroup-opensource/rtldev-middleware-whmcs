<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPve+5p+BgUimKlI273LcB9tXs5JwpDOmE8suIUYL3X76fGo4aPRJOYMJbcQZgIxj24tJGqPq
0hMmkpiReGIyOHorLvV4vqFbkT3SYPGi/2wEdF6QqKVEMqc4L58J/b0kDWaRyi/UpkSIB5594U4j
edejMhGxtn9cEIx7ZFG4JrTNXRzuK7nzG02PZusZwPW0xCeqLobuyGYB0aulOEzS15Kl8vlxQXBk
PnaOnu2Wijal9mNNRFS/qV7LVyELjDE1jhVjhLmNTQBmEO+CXpAnqZy6GCHb4jDI4qxGf0h0Bmv8
ucS0ZWQHtlKvyiFH5lF+ax8Wk5VPXImPZnTcoYCFDjj1uzF3dVByU1QxHp1hz+bctsbJKlgXMnOs
IzrtAHHv8C0TbtHqjH31BAnL7okzI50E8VGTY0cPv2FDhDel1AcV5M1jG1LI/9pRajqf4w5h82MF
PwGDYLo8wLt5XYFoJXXMbKV74LSEPrAZwVK6KBpXD5g0Oofm+koYYSBo1/BsrslCIr83co3kQuSk
LpIL7KDu+/BCylaCQe+uDawDHXtbmIUdrXIXHOjRMWl1lk4TxxY50FDNRUUZbv5Zd0fx/sqSjdkR
QluKQlDRcfpDkDwxSmkhLf0C6F1kfgiA/hh7Gfv+zDwqT4R/pFtTJ8gPkeaOt12piy1E8fZyc+l3
Kv87/AG+o/UlTfQjGPc3RTyG+6JOeyWslQksDzRFTwWCIBF61ihVHvaKuiWnK7lm4H3CPCKVh7HJ
LTWIaIoPdEKMW1DrCWhB+HNIxbQxMSrIFKb+EBcJiRteCmw+uoo61B13sA9kaqsg41sfdqBq44hn
q3Jp+OGOsYwG4frpEvaD99/hyJOun7TW9+hnDP9OTMmr5LJborx1mAgGlGc+bInoen/FUZZGOto6
TITPC4XuzdMK4SOX2M9Q+YYSFdcCTHzSd3+rYwvYIjvgl3fkdzvF3+Zfr6OmE9gH7uYjY2kurFah
rTrKRDz48bJEegmZ+vb8slZTotInwqlL5WBalTkWo+tlevr0hqu5lbRIzdpQi4H+ARVIKNm+zDCb
ctXwl4+LSrt1gcFsqBHxeSfTO/FSNVRY6GC7uB1IpqBMG3+2dMPvOLhnbg1kciG4NV/Ij0t7EjDH
AEw7lMYke23cvwPq26aQa6wpM3xGWomE8aLBt7bSAfPoaTwI8MTzgei2hWxpd5+imWUci+GlArq0
jTwk+woSZ4kZ+8tjLFjyfwZ/jt7rgH88LtrdJLyo3tqrMYd43glq2FDXVZ8ckuRMM31tP+XxTNgo
FOVc8uhWLVEHpRsiPeSSPvNIGrhVhQl8qCnfCwYYOKFCKC5A/B5Dw7ri2/X7uZaxxBKHSqoYZ7jd
sSvYihss9qFvaBI5FILKczuvLJRRp9EErKQLoA/meTJbJaaMPw5SmEuuVaRNs+lr/4jX4/fEMgQr
XU3AHFAzq3lgZyDa2YpmgLip4aBHp0jp5c8iekP+7XV2uXjWdk+dg58hte4SsF9oDkCYE0i5auZ8
umTqjPAwPuYXP5XaEtTBmaWeHrMmSuF8QnVZPP+TSgMT/QgzL3wgk7iKTnv4l54eAVzyXMrtdod7
HNc9iIw+NzpjRLZoZVGoye9uZCKFmu15aqSpsfAQNtDEWuubYpM8yXEcXZONAjA7P5yPs/retoxC
h2+3kwy+UXQXBeZYFrR+mO6RJXzL6tvDiWnCQCUtKwyUvAENRdUvKLjM2HgkKA+dmsTjQvG6/jkO
ebYCiSXG9YVeFrLjUVMpKl3ZZNVea5HkCSCj7bLHpzKPcSQ614icVglujXJfP5jZl9zIKwc6ysJo
j+tltno+28cVIer1qqtB1/+CgqGUseavfcbHr63osavb1Dl0VMAQGMC9HmL8A/O9N3lHtVMeAibh
OmTAv0/BfhkY7ea6rkb4JP9LgBZK/T3w/nTSX8AX0AzVOfI4cYH8kqfGeWIkxZ6VzBuH9nTeRUHw
qFjERzPcdfB7KHBFlFTpQ8gMSWZCRbf+G15IgJXgeiN75955vjLi89/p0h1/8iaB50/HEWn7c7ND
JoGeIKJHJSwQg3YexEqiiG4qx9LpMH4Xw5/5zREmLclA/LzKCr3EMNznPVSQJrwi39qeltegAomR
R6nZcVPE5SQQdGyJ6hwMXYNJIYdSUqpL/mkm6bTB8x8QMb2/g575S5N+HJbKa/CEn2/C3QYOlrWM
6hMySb4I1NC4R2chQcbPaseLmkKo3K1aD8u/KTRjNFxUWzpQDboCw2ms+Brx70LPmliB+3Fp4Pt0
/ZrHsmScfv9NcCaHIUEMuplr4Q+O/8DvaaLuLyFucG3oZTqCmrjXzMFp9kRqXWX0pAnc7vUKAnal
3pEXqshX5gLzwYFsZNCaBTLS+PkcSli6Poc9lKaKUqSS1lOiu/b3nNs/nTA1Vg+oAq7osk1prKAt
UtBUxPHNo8N2CxwryyskcA7IC2FEnKW1RPWJYveH3gnoE0LcUEEb8Ef2EVKHC+6JNUZWpMfoOuJE
yo5sQ13zbfksRH+EYyXOmtHqjDUz3PotQaCZuzFIN6pSPg4x2RBt19G0M36MjFDQxM6IsreKagKa
cz/6g8MdzE4Q5daHqx4Jv4fRGwM73P2cmGc3icH2GdFHErotcEX8KPZC4z+b0rMv3qsSIRWEPg+g
kS93lbRDAMbJNDpxv0gwzGp9WMIxjn6UTSKlgklQPXMbd3eYQYktX5+NoCre7rOz6QBPX7ajx34D
Is6w9E1W143/2qzVLnqxu8OX/xcP/8J5r2aeLWd3mXe+Gi73cQfGOjaWGNbTMbpH4PiUplHSMnFJ
1aa8WGyqKnHqmIC5hcD3SZ6XySFZOUo8Ceb8zBvGy3hNkFCwgV9lthW6ycGg3FZ+VxJ59RESPME9
zqyRazcgBF/D69DlK+izxDREim2o8t1pAdrWf49Ou5w9i+ERpZl2o9mrETi1PuWuhzz7CH0c6zd6
us0hh6EMDyl7nZ6A6VQRd1gqi0IWXTk5gXoBIzG436CRXgv5mR8tZQbzKmRbzizOeI+O+Eq+5ngU
yOzt5XTfC8rjS1UljVsPgGh9pL430mYz72/eF/GuDFIl4zl4Pl/rKRql5U32PC5qE52dBFP/PMQt
55oEwQM0d7uZizLDOC8eSf1rwaAY66d9AfNdqWMbWmtGnCcUYZv697iDhIUQdTjbczCe6Siuu0Nc
Ye1r7YISqDvsGF7yoH9H+qsBxDVw1vsp+UTcDOlkzp4NbcFqbcvVOkpzDIm/3LYp2YA3N4xsd/iN
bUyqjSfU1FDIzH5myRlOl2YbQYXYHvIoAC4UAtatW5xMOT6OFZLpCXWWAJCWKU5uiXihCrDd1YwY
WNOE5+L992xct7qioxdydqGoKwtMZEfIZtxUCfEM9kyC88AaaIeLD+tDWYivCN98GjRmtHvBbESP
Fp6yP1RTVmb3/tuJtzeUeOEh98thy5U83yldh58BaVtV6syP0r4e2aVB3oSnbPdUwL/qIoV8/kXr
5DCzwoQhMF/uGHCmzALhluIAVgDpBaEPasySIDke/oMTEX2b3FaIMKIyR7feYR/5YqLimgXieq6F
byX1vDJaxXRiI22OP6p8pNByREAy21rcx0DTaY0e21V3jXSD5BRqEMVC5RtoNTfQPZAC2XeWrMca
uED6h34vE9GEG6+h9UX6LFN+eWvi+hNQt33Uj/cryC3N8X9yw+JqG7u0ZyW5Cn//XrUrHkG1M1vX
AYeF7wEU2p0WuO0aLdArKOKcBqk7ntRY4NJSis90PuqDFmhy8dvIsclI68xoCNblNS3MJ9xplEIg
9fZSC13cIT79tJDb5SwxaI0tA8mc9Y8uZiXvpbkIvuTwZNDH8DvfgfX9EP0GVxhZFXu6gq9JN5CS
XcYlLGYckPxE0KmXthy+DdVAgPmNfIDrXuwfqw+qwzv00i6MQgvKNzg3RTeqTgsZ9oFuxDV5uofb
Tj3g6pY7Qjso54JFh+S9BXitCHO//KWCxnCXRPuPWVe56Trc5J9Y4IT+P4Kg/hm5cK064pOV0Gpx
tyI5sIT5/Rs6AsqOry5b9rFiEElISzUUCsxd8mGXDatt1F7FeER2opVZSkZDFtt6UBbc8kL0nl7S
qYeE+m6oJENWKeSWOzV8YCcBB5TQrhLHy5l8a84Kbo7OHNaSme1KLerFUBe7Gp7Zm4BSVid9oKFO
KVgBRuPige89K3K1VJvYubGAoweJBcITRKmP8Ds3zqUiwS9G4dAuBm9sdyOpmRTFwW6Ca5esQdfh
9FF5PBfUK6MwmshRzA6IIGyFqOcHW0OmGsGX99SC9ZaBRPfg1aR+vOMRt2C3wYOVUdWNciH4SArw
HwxrbpzGUWJnI/YjJka+kIQVmpYbxqVMBQd4oqOwY3fPAN+Ac9pWLKoFj/YTLLLXlujhLEvgR1p/
y5JiHmV5AczC5Cc83LmQU9m7wF/8fTB8syRTDif4aE6DTIogSydax/mWnkThLxBzb7gC7pP9D3h4
XQBZRkkHkpPMWMb8j9p+Q8O6AnzhQvfhZAeTwyPuFhRH+OcOrkIIByveV0yY2ClHW+AqyZ4V9W==