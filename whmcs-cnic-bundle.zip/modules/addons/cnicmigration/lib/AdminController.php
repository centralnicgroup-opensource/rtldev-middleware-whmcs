<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPojHschyzpvD+PjFIOnwbJ0ai3bwaVpE+FHYBl7IhAf6WAGWxB0LmXlR35JLIl75ws2Hn9ge
idcVCfeR8fbO1u9iWoiW3Bxq+Fm1yuIqCEj0O3Ykj+ao/ceiJfbSTp7z6D4d12n3icvGTOlm0AAK
xHYQ8k7AH13sKJwumYs5LGLh6kKT3i4bXbIwPtQ5vioSGZDrMszuSM60NuokExpnMjScDH1XjTyH
hHEuPUAqVT0wm/4IRD5Dih7+8Ih5KnJjwoTz/U02DTfgzXmHIR9xnA+jpR+QQaHns78Eg10BLyuN
2Cq72wKTiaHmmBYdyqgkrCApookPSamRfOHbtG9AEb7r1elsnyfu77z5RL2yCfuJp5L8XKPpnqJY
3+ALsPg5TOE7DwM0FuZwlZ9YHcA8reNCeJ9meMeoxzAzRJbwvfHIw9d4Ncb8LL0bDlhyGF3jaGC+
0FD5hLfKp7NE7f6Y3ew/hOHalU6K/stQ3V3RGeezRtR+ed9qjVZ8d/LpkHUdKN1DvN3tk/gNc+AB
WILPflro2GsKsxSl6G24Wb2ycWJpTzyYpen+sxPfe0VgOQuBxopxtYq0Ar2IWJGWO5gc7ASmHDT+
ZZ1GGz10TMv2cw3EsnKNvIrI9hisVVQ8CJdEIW0Ua0UeG2mmS5f5PfcimGh8sEeVbSyWVY/Eudvj
VcBZBuNMzDbelOo8NR67cwH52/mzy5U0C53VskFk45yexMnRcC9d8q+GCJfkH2Xlze/CDDztaA5R
UsFiUjrqpkGlwGw1L2ADIb6PhYf9e8Aq35eY6ivA8FC0kBAGisXVgTTVPrmjcWAvZWVTQYqjCdCM
UVkhFOkLFwQ+bd4ntt6Ezjb9z9NIvNtCVxSaZO/H09iCRyFvfm2I6d8O8r1BUrzh2h9QNXcWMRvi
vuna2cJ93Mk+yQnZbomEvJLFWpw8unukLEJURwQt85EEaR6YERCvrIfPoj0ijr65ur/RrPB4tkXm
oJZayaRva6uQTu6URXt/+hCd8AXg/7mMdRc9GrmbkLPSEljlb4kI9GI/i/3UuisfKSNi5OXnfyWY
QRdwspsTruXe6Agwi3KggPszz/XO8OMKj+GnmzxGDKM9pXMZm4WIq2Hc8z9QSo1tG28x1cqM8rJq
5Gjg7BSC6S+GqxWuR+9J2bwsIM7waJRvsO968SD61AxiKdiPhzfr7+i6kh0qDdC1HN3YATqh3wPV
vbUXC+ZquWeYrRlJvMf352UDtsYgk+irnBHKS2pPa6VPkG0vxLlJSck4jyHkXpbD1M93Lfk+Qkv2
ejlxWtgR4gDWPX2s0rHVsFQhfku7ZZ5fuxs6iJUBevo/ql7l1wJ0CUTv4V/I8xQ99iKbXu32HNZE
CA1BbQ/3TCyUWQUkNWjYYBdUHpkAYlIGi1bahmNEKdN/3bIzeOpKCnG6eYd3yO1UrQRyCho+cSh7
5lowlZ1/iZdNx2cUULEGNCXwnVKskJXbgYHLOsQM7RiCiwgWqKTtOWv3ycczSXHdzgHph1CRYAJx
cUKLwlWv+zjauRSXjtYAAqaQCbn2Q5OZo2pCUZ85Y8bIeezTmMoSLFxa8Y4WzzlmcUtmhLb+NFmY
1tuBxoytE6CHxMMb96uxIEz2ew4s7Pn3UkqJTBBD66hRNBLa8sNPe6lAlP0fCBIiV4AcCmQQBuG0
GBMfo3/qqPqnqHsmuZ4T/+par07jaKKYRCG/fmM9S07xCHDFDtps91ztc9QOGRFpPz03anN0yOxI
uw+KRDSfbF5jAXiPSzPexmYAm7LaC0YN9wLW04fqQKF/p3ZMJftPa/YRNsmRhB/Qk7ADhBfMUj+X
Hq8d+EaIOVDsXGrKivkhQJFUEum3TLdyt+pJYET4qbILc3eXKPvy87y791CU076NlpSuzBpBQ7ts
ASkXKouTbpKFRnKVq70iMROoawkqGmrhSmnqhyTh+MHDSJ9KkwBtO4brEuIvK11kQQMh7LPwrPIK
o2BdydNracRSCPRaNUWVrqZXvCtFNHvwo1uEGCbx2L8N3voNVMfyX033B0V/XpS1DzBQgnH9x9V9
LsP4gchjt9IS930dab7U+9ya7yWunDProqKUdTfCGQJrQENOfp86zSbt2dQ+Vv9fCJUvFSdaswLs
LiMyE36tu3zmGYEi5227p1ZvdBr4fuvT2tFQ5K4/j/9FLZ0plqAS3eFmkhlJKqYbG/CfVKHNGFN8
kVbovcZSoYxX+iKbntj+G/hZ+Gwbok+9Fmzwt/BtrOzPEBV2B76d7Zdl3NitFXmDLN7n+A70RcQ4
VeMSDHF5yVeoW2eBmqYx2Nu9QF9JMGF/luDiptNXbNw5nG99XQMw+yXPx8Fpf6aqwOWUDG48rSMY
Kr4XU30z2sxPDWdkkDQVQbDGZZ2Y/gLw/W07uZRAWxYDrXfYtzZziYBad/qQLcrt0q3kPPBXMVA7
mwJrMMFCQi1hyLx0wdlcWO1cuCQmFjWDKbkB31qeDCGhjz5k/gfb4hBVj8gFS0M1A8WW990V2wNn
AEhQNClv5YalkfcM0CRtGbZ6f2HmFOCH6+bNimtpGsrjHbD+Z0jC70ABiPs+9MlxyYoc0zVh+gpO
LxVCVZdVtsUWN1LhHLflQjIJs60kidkDfgUQCIZtZ/Qd5vhEK2iJbCeM0QuEk8/WRw0+6LP4SRUl
aaSDIhia8mhaQX90+6qLW9VNllNCvShUvfc35fOwwP/KEaXoPcFoZ5icMWLLFHBnQZXr/zNbL6+4
hZ9VrRFs0KZ9xYkNapZXTnw69puUjr6jUwCY/NGEIWxmv9rNjudLh6pnFvwTNrUsXbnL5pBg2ZLe
IBm+8b5engJTJNGFp8mqe8XQb+PxGJtXeSMpElKDIL9hfGThtrmJfNxXHpvrLGU99zPz0rkIwY6A
/rV2ftMDIRoQ76swjb4pjOHp9R3/rLqd2bum0d7uXWLHwjFxkDY8EL6/MbARW+nqm/fGXUUj6HNu
zc1YfVsIMezS4fePy8nS8W+q6mD4uNl0uWnlgvbeMIhdGoRURRbCiOYaawne1qFB5alcOPa0iiaB
IybxP2tLQ1XitPJbN/tsBO6sBPW5yombL+Llaei7Gj5joS3442A2LkcahKS8O3z03/dCfbh9d+0K
uTzhvuoAFjcTQFo7ReGIc2lGxI7NvOwHszSVcqbqHtW8A7c7aGF6a0ZLWGn85Gl2yW/DeH/hgYRK
04l9VbXlWs1N+TJYsUUyxhQCEzN3iVB8ACpGr/lsBZvJS7kq6fSP5GoHmipu2qWHDFdpYhVuwf4h
61932fmOHgOVahpjXYBHh2dVG7/3E3tfz5kqI3iOkEIEOG2BG/n3w66hzLlbCLEZsmK+bSmPJr3k
lFPkCraHmnufv2yoOFDitNoJsm71mOmTgzyhlnWRNNMXncuuanLQMd2oJsWluY5rOF2ZX4sNFlyu
beLq8R01kYxjM/OuLn4vZGmVGU+4WS/C0z3UMZdzO15JQpOAe15ueWKmrA0IDZM9VmVkjoNVD6ZO
4NJC38kq76LjZVgTCxTd3uiRlyRDZBc8YtuTJ+qkEh6EnVP1KC81HATcxwmbbmwWVr+p89bPm1X6
+emGc9ncKW5O/CCG4QHszDdxy+VMJPrtO071kn5Pg4vQgShBk8NATv9EGYUNuA9RJst7H08nBJg1
aDSa0J0WcZ30enlbTBltwf4PldAco6QvhcuP6BIcUD3zKK7g87i7/2MGdbrV0FX9X+7S914oEnDW
f8Ucrb3QpQ86+W9bLxqn6FsMn08wfxSFUz0b/pGJX7pXVPvETDphdokbb/Sji9k8nw7QHRjCVtQO
lezsDo1WuqQ045mR2tiM9ilRm55pahqeIDQa9nOaHes81fzVepfVhD+yPDhGcmpxzPq9eRFamuM4
qFEA6eaX01unZASzkRIVsCYrtHMggKmsPOyPV7EvMaAgAaKeaJ/wa6t5Nw4Sgj5af5s4EFLBrR3J
B1UTBJNJ1OkoeYfpBdyDQFfRzvkhZVcRNKTKetncbi8v/FzgARHRfXBDYEciyoMuuhdwFJRyMbfM
VxAY/nO0VEs7APRI7wrOiHapasfB4jAjv9WBYS2OubXwPUjuMfmUD+ufMe1PIHT6q1mr6ugTn174
TqQg+DgMTwDEbI+XniZcnghiMkC82J5WH5XP50sMDuhnHdBsBt+oCXM/7rddf2dSuHvpLBRKFTJj
MR5fV8ggx2VoJNyDpWmcdsYEky9fvGxGS3GaTMy1pMa/SpLqPqbjfz2x1Al7oqM0PC64G/9Yb7pS
c9SEPckxzz0doqVZOj0AbeRC31j+PYbmomhd1CSm8Rr/7brieyRPawWsSJZ+mXQ7T7UjuiiWZtmS
KWa1kDZySnSQjvnbORctpadFh9UtMHwzBv7dQ14gmzm4EZMxsME/wH+8EcW90uYsM2XVfeMOlycd
+xlU/Hbwj2rOoUxk18HhzebfMErjeBObsHn4/OcLZwWQ0JlLvOcEEf3gXfL1szurQxLzBdIiXt1Q
44966zZm742oip/VknbM5nidcSkFm50QzFSJcgz1Cn93/QglJGq1UQR2A0zo