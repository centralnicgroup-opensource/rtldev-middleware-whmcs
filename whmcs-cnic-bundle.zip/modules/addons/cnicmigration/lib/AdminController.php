<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxAsJTIQ4ROROtpOztyIpSRjJloy1ZtvBVuPtf4RrE7A0EPc+dihdpL2jqjE3JwdOSaALQoU
86oxjxL0fXCEU+OhzZAZ15mmytiMdhQ/mofC5HW+IGWeV3bH2qphU677xcvjKp+gFJd/6j+TdzJa
0/RPhkeAvrwpSSJen/eSCWeZANZfnvBtzzvZTyzRJbnpaj5qeuppavrxnIQCXPfPYuKQhuu1f0z8
lYXjzgE3zpzg7P39gn6UEjyrtJWOScO4opdgdFK/cQ9+BasLC4HmKEQIKNFNQEw+QEMwpYppQRDw
BOe7EGnLXH76egFinSn1UlwPHrZcfugCKAnBt2S+fIXQ5C/C3cBoRAcw6MgbEhIQjANzaUiDJsO9
52KsIBEfQBGM2OtBzXn513DFXLAKjINiLyMflqC4vdYANh9F7XTqdA8nYDYJuJ7XDG+swtNDLyGY
QLWzUcrEHdeNGK53KqV+Fmg53abjIBOPfUz241HXq6lv7lSSdgWl1DgrMpVOWrEeW7aVoKTYNwxz
q/Hkx5X5rIEQBTz237tdmJVWDnGgI8Dk75IJZbIo4XD/X/uv52ubCAordQnaVaM2zAs/5cCFIr7y
wvnVx6PMc+1cS2qg9Zjz21VewU+pC/QOdYqBtTJJeLWFOS01vTPA/qVAr2kThyqx8SfFitASm7wd
3YGlAHiF4npggLJKDWY1RDgN5tSo37SO059qPxc83jgbTsug384sM4upOfd4aPtSBIkFSfX5Nfd6
CNyAP1SLYvRchR73TKwheQtuzw/BbKOdxTfyUPkwM4lbeuQ5mQvP94+lkOOeU6wX2Kp2R3yZIcjm
6o8EwtctphgYEB2KzNQ/VmjVsMhkQABi1rncgnCM6FYcPpVEC0KWykDkmuZXkjHn/kQ0Bn9BcoNm
nfQ2toVEhj+HssYS2xzqIgJgMYdeFJbteysTG1Mn9zlZRJyOz6ixg702oQKNq9VQCvnz8HHK+N7z
2z7TW2/BAna/HdU1x2alX7ra5idOk5rwxdCZWAfOCqSl1DQOkxLLNfZ1GFHdzcQ091Umggxc2gXC
pYBYyb0F5+yRWbwNfLEoZG4FkuOT5ra1zVXgAdIzYuYvwSVoyavT+wZ/qwMIX05ZsmNwgkH0kNZc
+2Gj485xvdftpeOsxVn1Io7OLTRWGoDbk+QPbzihVR1vFMcO6scS8ZZtDsaSQ/DoxzbKmvXp8RIV
PYweZk74+wMFO6U2fvRF5h76et9bBCm+t/5Q7GtCnkVsFUXZtPf1lP+EW/Jeb+MGsbE25DrT2P23
9NnzfhxrzERpgjignGX5dwjySHTGd1fFKjqlZBiCiUN3rUISzDKhtAYT1V/kcoKD0PY6gvNjDT12
ssdrkvyK1CilSk7l32hryGIFadDDQlgr1hZkEB1UQujf1+o9FXTH6uhj65YOHkymLUoD6xCtxTdH
3HtVmehTtu6szcnOLJb7JqGJ6FG26axhfhC3T148bbb18igb4B6rQxyC6/4wejpWS5uw/EcAS5Bn
BF7mVu2RE6G/IBnqkPZkq1qZISQXbKNCCQL0KptPmgTM6hx9y4VKGibshRsnGguuEURjfMrS8DDG
mrQm0p8C6vfUv8JPwHOBCnCjiVuuHNW6jQMZVUOmcdlkC0lXoYB3cMHf7d+wnsQ+bMtRyEtAUhEr
1PvI6RNDsXKGYMB4Xruj/p6vb8SKV8KFNKmj0b3AFIfNQW5D2B608dLG4BdU3rQuCS7HMTutQii+
YiCTbvlowNoDUtHbzGR2ULPo04E2oELoXrvJDkB6QxUB08hJnkEJwCJCqYd4xGvvkw1BrpKH/GgX
hsxx+SXlAr5VySroONmutlESHP6g3KpUd0LSl0RHwm7uWjAbLdHEUxQEhY1/V7p+RQy1RLxG+65P
qYG/eqCUu0TCzdVkXX/xGG+coR6yyLegyqnbOFWiHjR3xCKZpMRDkCBjdj6D/V5NkIy4epPeLYzo
XeZM7MTcNqMl7wtWuKj1VSA6sV1dSDJvvhZivEwRaNp/j1i/n+wiMZzGFbd9tiAluwjRoYTbiaem
T97bbDvKEqOFd2SNjov/18Y6zp+hSP8kwD7c9FnHbAxnIux17aSULFftNo/z06iYFi20uIZnPzlm
QfFhWUn8GUyaUd0Ar1pMalXdiWDqxP6epSlwn9ZX/1Hfc8JA12+j7KlG9irrI+cp4AsdaZNp+g1Z
I7MIAov9Z1yO8zMdYLT759j7euc8nL2SMCQqD11CypXBMeNEfaFGH0hS79VNEoBlcn0s049mvdtt
kVCn6gm6tVAmZpyBc1mTmOS2cI1XDOqA9m3B8gKEprfnVMCqOcpHvzOfbtFiNSH9LcSLG4BgBjiq
AHieMl+4YSg/4A2MUi2RC/2F4Fz8qpcQOR+QOnHnJkvjar9HqJr2AgEkgRjtpKIeLdqKxYKXsc1/
fFfnxyyL7umAaR3QUhffc7hpavGPmjW9SzRCl9sOPwraoSezDYg/ystuULqOqE7LQEK1nXo1U1z8
BsSqxKdtsEcBB5kn9DGIy8VFFiEm6ejMOvUbobi0rvjsfGoSi4lmXPJdTEpwbwMP/zBLXkzNm26/
2u878yGk2/IWBm3IVL6QNx7ycw+DUgIF/u/6go1SCFd3GlC1qlxWLqGT6bNwsC5kWZGc0nn5pC5O
zSxZ08jdesiKzttrQHqmJIAee4U4ltJiANRyOeHB+JjUU7s9EhIAKbvC5osVpI9a/rnAOR6Q/jXk
zBtfrr4rmrzbLxNu/PD1DbCB29JDteco/n0eb4O0DmPwuQamPgJPLgs01f/83PmK+gMmjgutR8z/
EBDN8+KjghIsX/bF5V2arO0kVN8umZskXRWpODnYjx0PjqVzI5Sr1w27eGvT6ikYzcLyrmJPvXIg
FLfDIZqM+dOiuZWlfkcszTo93KZ/tnqDPlCQZzQUBVQEU13O9iEXjQKpAY/kh/olnZ6g4CRXaWhc
mrZtsfiRxE3HZXW1ceBWY/je2AWMDl+s08wwDxgA8NCEAKh6dxLiOgUXrg2saMgg3usCD+Y9LFZM
30Nkd7x2hrNZvZQF9yceXN/S+aX/VPAQ5WP8R984/XksUxTMH0se6ZN3x/PHtHH4a91uEK9jlalz
qsKXNhcbRpwBXDw68Ky2c/fc29fkfY8vjrA90LTPmrWJt4RlMZglXq8HaCUthQs9g/Dh3l9rH0p+
yp9dmN8zPpicv1YAwZ7lfsyFBmV3DLk4idg3zxb99ErvIOYOOqOQ5yl7K1DVKv5quStv4zzQD2lp
qrqvo51cw5Bi0bM94njiUduUOLcf5TUPIRinRAFaEEujGIfM72u8YyJLS+AT+/xcrOOGWp5fABT+
JKJeJ/oiVTA4AJe6MnEoh3SHNNu+A8vtaXGc38YH7KcDgNMD0PM9V48FsWsWWyVNaTdNh+8VQvSd
3g/0NAsEiuX31faE7ywFaJLpeMy8zI7U/g33I9RYK27JtSHu2CmXd0h2aVUNwZOeH6kL52YvtM1T
hir/B8zb7lcbECqhwIuGogiVXGJaavsWdEMPTovvQwcTlP4exbL8K8TwhGkdYSb6ZbnzKfwqZev2
SiZr9dk8pwtoBOvea7gWxYruiVi0vYgzw6x02KnVUDg6oSEvKUVgGa4N/wlnfHWBipV4/FaubGIi
Nv0da4s0Zhz+J/EXaUuOMph4k54IQ0M72/xKgRX4MM6dPEFclFx2L+8o35RSACST61zdnp93zAj6
1pgju2fsGITxao+M1mJYRDF4kGRFs1go7HwEj3ClN+rJ2HoJNgpsPr68TPFcFVMEtMwn2KlqK5Xe
stJmXOB7BpV3pysn3pqDhnrOv7YGcEC8ivT5vAnPbSSOMomTcYiiYKdXNzxPnFmh7NRgZBxfYpam
plrjboAHSmwWOGpancCEmPo842CvrX6yU1sGCze3oAChxKZP/zDnUX4/uBWtiKM7azLpwaaeKBHu
44dY3h7CRz5MNM13kFQOcRUxPSr87bN9UX27ju7ZYcJDxaq3x51DtPwwuvootq58AjnfHzZIGc2Z
RIsw05FWCbiexGvw3r67bg6uGvtA7VjsUQl7oNKLyn5NAkHoxzl88lNxrHkIRt+AcEyuCvmmfY+e
lOn6dr3iw2Z/wJa3boV7ZK828CgS0FrmchbBuiLfh2sfgXJYrx+V/bv1dTYONrtE6EESKMlKoGt/
1tr0SgGpQIV5hTppCU0X3L/yyg2Eo+Yy8ubRHWkxHi2zzxDxIor8stfcKVRV/9cDDXV2EqIZFtD2
KuBusbN3h/hCY2FaZt8hptaZuBqGurVeaBbMmFV1C0f4QtoKQzbyGdeZmGjReH6t335yCrpt/y0z
p3NCszC+rWdBkhoYPyfVic2hH7SXY0YW17zyyRJ0sf0gwqPAnxw0Lohxiv6zrBs1/qdAaSaCy+gw
DGdboktnIaR8rYmcpGH9+CWNqBaFXZvIq30WE1hSLOyXe/jFIJuh//XYdI9efrJ7tPOYnt8vEl06
hXngZR/BMwLZ3lFCoI8/+ypYlDHd727D5rE6vgvPDg8W3YrU/PRYozJNGwJsFqmz