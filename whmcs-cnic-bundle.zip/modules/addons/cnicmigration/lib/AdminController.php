<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs1EOc3L7bT8e8JtGy2E0JCGKoNnf4LJMxcu/WGareBupm8zMYWnwvcLPPtGmFArVnlRDPSf
+FTv+kR/TXxoFnTTGrlnDWJqkke4gAtkMbCnXnBYb87ia+Xxp2uJGxbCO0DpdqOJlqwB2Y6RtXVL
Fyb2kHddMYgBZOYCt/MxvGHnSknUlD5SMUGfSTSsB/TunHHGAy6jQMAkFlVxTVnFsURLJAkwasK4
Xm1HSZvbkKhp6dhkuG5PDzKZ4aonXesxnh+vDDmkVTjnBd+zj67wAkOr/0HhirX8cWZjJ0EtBr/C
fcSRLMoeIsXMMiofmthZgFAw3Gx/GleE7M5jH8zjdcfNdx+De0VJtrlq1XV6D/olisuEHhada8m8
zz+FGSIpWPQzdijJx/q1/ZdrGD6BQ2lcCwV+O6J2hygRLWQfpQN6KkN0x27Lg2eE7Ntx4u3iBYAg
oqZFPImP0Ak2eT3naXWYE+nI98Ab9CIrt0ht4Sk3IeR4HNqzJ8Y16DYtU789LYoABFyEh5X6kBVg
PCg7neM1BoitN32m+rn/lm/jmrKCejGFidpcNmCk9N6eycaWPBOfAu3gV1Pbf55T3fVot8dgMY1k
xyYbFZfXbGUZXHPR3aKbuujnIop2WemeSyo9/4Z2V60deZ7/vrqpa5Fac5u+/OWYMOu1UR30rxMo
fDZlP90YyEYlVkKRqG06cXd5NXmVEKZEdUI7b4jVfnmg5lSsRcZQIvvBOEWxMOdOjGcW9pSu9PDI
7PHFmFc8sX24YRTznpSbFd2MSe85n101jT9NsIBNlFPAdc/PONbHpVrsd4xZcwJT/8EaTz34HVMQ
5rkzWf0jL79lfKp+US+f+8Ri3RmGb/k6Vk4gDxTv6cxxpVedaWcLY4TYtF2Wpj+q8XaCCFV+zW/G
NKXL4pgHl021+bSUutM+qUarTbxBARvVRBMmUbQrBVeWB9OblKvfJZVY9gRaejl08qLQQkaR7QZE
cCitlMhKKFyHP+zY3gYzIvTdSw/swxfx6pX2M3DA3iUXj9w5hIW6yM2PZj0XH/RZxEMNjNN8Zt3O
3nyMaedJMg6tE+aw+Vje88YAY7uCyMicap6kWAKPMi9CDLUt3BbUkmuNycizxux0HorUbgIV6WXS
SAVFi23KKNeZpiRIpC5hfMZZYkCqsKQVaoZR6nDvcumL6UOp8+AXOZM+ELqLcQrFdulUgt1cYzku
6n3FtiYAMFtS0tqd/YHBP3G31qvdUe3aWSiddggunbzYzMtd/6OxEsyIG7z5Pgsi9dsWxoIVMz0B
WShPIeUSoTMPUufRqKm+JeyUNmjNEM75RWz9wMDpEI6XHr9kNR0/2ZdkGpYETFrOLTLxiTCp1ubT
QekPVe9CYRMRq+08Xrjb0CDumSoQuT3qGs/Kt8jBGrsalPabZPMUMPVRBwLVn3Q3P8Nj1jlxWSpF
hBBdRTvbcC4Z3qcpzNiD0Ow88Q6DHgA5fDIaqxhRxo/FnifiYnMEuNdX0M9LoIKVf2YQ5khdHnXy
gLJj4X0w5hDvcEGoNViGh/b5tFJ3/uEZQTNXTIk1gx31aW4BESEOr1EagRaetOCY+gLdT3GZTmt+
ix2owVB60GfViloW7QLoJRpjaR2Mf848uBR+hqr8IRz+zrwWQgRIWVj/u7dzkoKIOqPoTJ6vW8ij
njxuBxpabQZ2xHG5yGx3gWoK/W9p0hrlpzmG8Sdbl5eey0b399aoggGzT2PtUYXssCUrfIenNP9n
Hv2908beNTiNuqtDYTdaW1CC8ZFyTPCDg09/4ov9LPH8z46pNDPYmUzvHsS2/t3CoTXO+SXRl1Jv
FevysCdUAJLBs1uZirtFO35wYWa/t88hNONo5dbv2Evy4Xh7nOElshfcx1E7fjz5vpx6rWoHMSQA
Mny4kLFq2iUbbs8raqJE2hs6l+ZK5jdNAGZEO9uVVp2MseDUaOjQoQ6KJSUKJ5ZPFVsRBU6ZDZQH
HmRJuWCSmfQQMghyeHdDuiuo/e/Z1OQHd7WiUqERpvGJRAfE7W01pGZ3Ma+D2XwHcwOQPTYGt9tG
ckDqNc1cKMO5gwdRxuhzRjWtV1wAG19Dix7z2NX5IWHJxXYmxecdA9XLSsdU4zTdqqYzBcWk+7/W
UoieBtptTfQ8+zNB4oCUWEsmk1poMdxTs3qe0n5koIuzl9cryLx/S6XRHtAIhs0+DI3gVoDED7zN
yOhldBqTRqQJtL8uk0BPhWd9kKpPxjkd5YyolMGcz9dZjhWEQ6/AK3rltp002DJ+SAg0quQ06IqM
1SGTUIxxi7DGAxlAA6urYc17Lf/EU8sR9pjkW9Jci3PAxm64GeQ3Xeg8IWkCw8OWuK4nIStJJJlV
jq7DL8Ja67RCpYp9+5bTQD2S1wEOPIBXbtP1hMW10HCt/vn/j/TH44rwNlhvHPmuPsAGr0hNwtX2
3eD7+NgUw2AONEx81ogFqc/JG6Y6unJsG77kROKfifEWQCSK4kid4nuDrPHm9amZgVGMzxtLIlVv
wLRl4ZisjtLJnW69i2dSCQcHqI0nnQYTM5Zc6eUqZR7axtuNsSq75IVtDYHOjiWbjsgh7ER98hyL
orzRwk94Q+kAFfpe5FpjU4C2X6anaNLCuKoDXbyDQKZcgtW1fs7FYHgAKWzOI6PlTMllg2x4UE/j
fp3g/Vi6gJThQU55cJHYXLbt402auI+prsJJJLlZHilHbXn55WPXRrL5gilgmQ8aPSAx+/08tTqk
AQoc4T3JQLRqtt0OngV9zRIIBjlYbxX7nZE0Ri13OSDUrg1ihGRkaozgDx4XFk9AaWG29MSFa047
XNxJEypMwUrynCJlA+AvWTsVsEm3XaCx/FD5GA9Srb0T8OE3w8arBgYJwMaStsGbIiCn9Vd12kP3
WNHDnlSIz5s/ckvSwZOCkpceMHQmrAeLi5lHZZhkbWBe/pMlQirfSpVccnb1XY8rP5qBMyb+fVsK
b1NczbUSyjSlYbyJceQfo0KMYrmbyP9nV1U+UlrRtIzJ3YdeLQd2j5KjPW7nzWMAiaGWLDXpS/Z8
9MRBFP0/LRZB1/rxQLeROLMla3s/iun4V+VThLfmeq2lr5bHVGPRxqwItUDb2eCFzv0+S51my8c6
sFTKfDNztFCnWeNj/lmXyPK0uMqDCmtNu+/T+OxIR13jYFCEXiXcUTbOnl6e7z/7QiW6i4FpCECC
zdArX3feQLxQVORFH2TI3FA1tCOco2iAqSmvSjUWa8CjktQdflzzPscXU3J8LLmIpZVyyj7GYcyu
WOa+df2nodh413VE956XZ4UHepg/FKx26/mly3ZisSY5HbQ+JyEaYibhGsqOBxPaJ4YvbS4WoskT
33BW2qtjDK0brogg770Aw11Q3FXBk8S/R/efm3aGy7BVj02kjAUwMuIwpuikbu/xQfPUcmGp3qSm
/g4YLPxsq9mfFtCrRrDdV+9UYrunsb64QwkCVjiKsmd/CvkVU7LF8TW4lFP+QOjG2hMdBNLbmnHE
uuGsLqlfxsBq08pZ76idEboPfntMRYIv6O81/x0mZTiLQIm2tgbayJrQOnN+WtlmA4oI+/yUvWCn
0WRVyPE7E9JCM7vLK7vu/VtcM02kH3eWaRKbWAyesnrwgd06fmJcsQsUdDXHZhxksa15Onx1dGMT
cBlQMwFNOrz9/WM0qgLpxVdrVpNcAKQm4Q/ym0XmJO9ZNBp/YQS0PMtiOdjA4IlSLSRVvldLSskO
buDeLN/Rs+aflmVOKHdCpWe2UyQvcGtnqUoRkDIZWNYKISnuP37pKYuIc6Sg0ipqHmQJb61I/fQ7
onkPOVdzyQWnp7jEw1jID4KmK7Nly/om90mtpC8dLk7MSD1OHU1ib9WDPh98Ko27bscfN9z1twu8
7xoBAvTBcCNVxGA9GgVsmVMs4h+k/5fStooGdA7Ke5+x96RSAFSTw8mOeLe7tA4VA6M6I99IP++I
0K8C41MySavSPeivtSsMKErswpxtgywnDMOa54AqLXdichK/V5ToZRa/cr5ONakbPOeAdsJlvZ6o
WpHtsMdWJCvUoqQ3X5mE19HQM3UP5svL9twcoII9+m1kKDe+Qn/lgFtKdfimf1U5XHQGuEriyexM
/PaZtmn1EgtBbPbyVF8K+XLyJuwSTnX2+xXoLB2Ru7syJYq2RUG5d6Hjk/1GcuGcTDeG1pNcPLa0
BwZkL2GOn/y3l0O1QJF2L5D37SnmAbrwMXshZDDeyWzdXH1JEdI995IsoGOaePrsXixNWYj8jfBG
KgD38mO76LxVyr7+x5n/ltqixY1YOXLK5bZVI+83451RGi85huIuWmsgWwrcgwl9UDCD45yu+a52
YAwgqYk2Bv+L0I9QBAJf+5nY2xRrGSb1scvDGeU5jx/NG8p0zgAhJLrHt3835xw04iyMh/Tmqc0W
//aYbHyOWwnxrjMfbUES+qzVHuGXkmkcmsG4yMympbU0oJqwQO9PRnPEvzNtVZMuqshoad121c24
4WNoiWmqzTf2k/PJIdOZ7K/iF++dfzB2eaxSAOKmJslkhlscfNPWmgrnJfsVbZvGnVPaIt8pIQUm
6wVoFhSe