<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzTQnnjS0l+xN1cGKZYILCd7++9g1gV88xUuoCle8ElD8yf677cwuN+G18N01BUQwH6S7BC4
QBCVsV3XzLibijYifzY+HVruE1Gl3rVVXGhbBNEtdQsUZbnsdqhz+mkH1Fb4Yywlu5FFyJrn1+48
zWpavk9acnp1CjLHC7gMMyM6LoTDRcGzA0OZCrpjPqlZlW9stpzBEQbynrmO9xKTkOzU5TRCgYxm
JCwLXl4REQ1KKY65RqioCjVDSIWNbhg68yiWZD9i0s3r8Bdvcc7vv6pVtnTgDt7HMLxJ6UFLNuod
LKWIQ3FovndRSZrlsbohr8G0WA3VvtKHpvfgeV2qTG/86Z0lpOweixW1q4roIEU6DpFAYVkM6WqF
82xRKfAJ88ZC+K43wx465px8vvgmW8roQVVbhc4oP424uLsTSjtmDARq81fOlK9B283AalOUbdU7
UsKGpcejOeYDl0Odbgu/7/vW3U+xGLHRynb1CG+hb1tHJ6gTtVy9CjV0Zzy3rEgGfu74BmbWNTyS
aaxaXRmjPEe/Z+Qx04Dj6DKHb3vvt1UgXtH1eLHxInKXimJSmg+9MQ6kXFjY/4dckJ99yKQhttBg
gHX1dlKpWkJp5rnpYncKDgwoDwHqABRLL2AkvHmN0w0kHZV/ZOo8diAnwg6WpQgDQJERWLSkIMkq
M91dKz+FxMrxKR8EudXGPw7KkOneLmcJ5dBCgte4V+pDX6E2F+zqCC2ZII2JNhZHqoGjQrXPjrvC
cCEUGKUCUZjFSnTEdqcr0ipQOhT0lylPM4o7/9vdWsA7dn6BkSRpTbSmf9f8w5Hz9isWQkHbUyvu
u51oq1RUxSifEss5+J0U8a1RXRm8rZZAYDaxV/LRfUjwFTteZmPDsPbYfHPKLF451sFteOOTpbYG
vefcvV4B/QCZi0w9RlwVnxrN1EFOzG+VMVyxSt6dty7qLcR18zMC1pec1o6htRj9WkIt4VImU0tz
nV2wU8kuUFy2FJzmsOI0RE83IgCntseItyWobJeHtEG1JHYAsjV338qbMo/pLp+P62Pp/5LX8Lye
duAwlfLYkkKamiRflSb8PkfaQMUlig9h64ZPYIRzOzfvvctY5OscQ7R7+fpW3FlMzDFjzdGqfBc+
R6KIh4tfWC2wRhsvPo3j6No8d3AoTmCeLK3DmU/XYCaveqDJ01xl4Em0D9y/b8KX/VQ2mAvlfCep
C14/aa6oN71g25c8/FlPWYOsQmFeK69b21N4SWddxZQIY87w03C0R8e+GeLB/6F4j1S6isvVC0gD
1daD42Bm6wO0iFOolWDcsUKolpuvRjBp5/XrA6EXY9dDM75RY0GmaGIpy484tdMzfnpQ7GIZXeGk
ojDdvyfshXf1UPh4uOwiV5zJXQ11VHAsXlrx5PpCxhR3SfQndX2nYQ+tE1x0uluehdJNfdtOZ0dv
+ZOk1I8lbEqnGbmRXTcudR5M6QelwEFDJNKaNYxDYk2CIzwe+WQG4jZEUdbhbW2X09AdkBd75UvQ
RPoRCNfG5FambJezDi6a31tDVqPFV4gJue44X230IrJr2TvTd7twfkZvruwke2tsOA1SJL3kzMYd
zOwMCEFWEGqBOVCiuQQcJKyOzJTiq5z/X4UzXw2QcH8OhTuNB6fcv9YDi4Er5FnMRQ9tOJUtKSbb
ai8O31Qe5o1rebO/fMW/J7Z/GdbyJ66NKX/JU78U6JSC91716DTEtzfq/M7QkXmmQlIgb/C7nDsg
dofR2E1GddV78V9V+gdv6LvxBvtx2OP/BPh7mD8Uqqo2X1AAJwIwsgOoaHvlzo6ypEjzJlIPepHi
D26MhgoslPa92MVEKbZKkVHjgFupivxxXpZm/psC3kHuIQnsZZhn4RsmhfHwmCyvlINDd5pBDa/q
drf7D8atlSIlwRTCFwImEsOE9lfkZWWP9z5ivwJ41x9GG9HThBC/3ZUbvgd31qim/Ea4vq5cG23N
mIAFzHZm5nHbAt53dZyAFfpJF/wceXxrYwruejESA5QUP/RQ7mHvTSJu59jSEF/Cf+hcZy5wJY3q
rp0HNk2LRAMVzrzjHI5sNhTT4PWn/JlR3s4K5djAPIrEjbsUYj+HI6bhV/CdkVP2XvzLCdKr6/bM
wGWwxa5f53foI3lnUpiTTOnsb86n6brGOtuudxtS1lNj4uLl7A1lZBlsoNCX/OuEqifFkP5jCm6R
r7ezryLgmU5qDKN3gbG2I/akoSk6mmCx7G90a5jgpEyRDRwqto2r3I3f3QDH0dtzbVkuJ4Tsd6Xq
b4Ht39Ggcm9HSI6IhGvVVLDoHANSmcB1Gx4ZnNnv5IBtNA3IXnhkeKnEIvrQwomeW8kXzrlSIkxA
Oc4txAyMVUaFUCz4CIZj868eBhiA0p7iEtovhEre5mwuQHFapUsRESikoHHbcp/OEQXJpgTpfcVX
NEUyffJBPmc8y49oOryrK9ec+NceV1RNXu2n+qqWy51BVqkcRd+bEpdSXiIP7HbF0ozgk6jx4TA9
bh8Dy22TKb97yaPSzIam76eFTl2ElZIoQqtqGBuu1W3Una3tTyVQRC2C65u1lOkezXKkSU9V1z1Z
94CgyjT8rz2XrXHvWab6NGi0K7OVN8hGiDmpPx755WIl4BT9CEoQe/6288OkHVzjZEpU6WRoLjhN
cQj4z3aceYs89bUg+SWr6nybyb7QcTCL3elufY0luyyBPO84+h5OJBqCZ6X8rPIKDwq5L1pAadUq
dRRejXKCX9i3ebIcx0uge/tQKTatcdiSJFxrzeeOG5bLtCsXDsW6gU7t3NxJnPatgKGPz9cFX7Lu
LLcvho1r7Vb9NN5kdmwfSCAZVHH4lu9Z0TmcNwDW8zLodCuPJYbczYmLyGKVNow9vdhlfbZQtF+O
BPcModQwv8a8QfrazhZreDfiLW6CUOEJX4L01Zh9HWReJuLISBuY6AIL/AmHWbZ5hsIcFT957Ryu
AtvFzCgBYFK+AwG43F7tiSoBmUmQcqS24+FgqPo5ApJJwoNTf2BOgnGM98UIR7AOUDB2cWvqx0Ls
CMQteB/7z49fIFehCpTe9cetIaCRlOedk4EXVk1j2UrTtC9+MPTSVBjLHNP5cVdvkhavpd3/M4pv
MLG+Ht1D1M3K8whXX3xgUw7jsTURoBTc1hmJRvFqK1P8OAmMCDZ4FypPl9wxPwsLFJ8zhqiF6OPN
JeWtIITF/iIEB9cNZda+/WCr0oPPGpwTGx+2I0bTHfVCjL7SWNevispjLoJxmTeEs+nD/+2w26FM
4ihTbY6EZCMr6o8Ai5CvpmGimYXNkNFKcYXNVnz6gRleEChbc7MztHrZq2XeMYUA3HKp705MJPkC
Xwdme1PhaLdcyT/GCgqGQcKJqQB6pUai+fuOR1wRr90oNrxsDfdWZn32Vm6IyB0NqzHbIo7C9E4R
a94hN/VYToZv7Pms7BuZW1mpiJM9yEsGjCGeUJiiGdMdkhpkcVm6VbV/75kE8rmEBWtTfBoXRj59
o3yobi+oQ3JlEXKIPRv7cBorTliC9ZfYmXGs6MFuGbDfM155XPFHgvalY/TtdwCMO6Y7T0iNg5S4
mDmzskdP3xBupepks6mYEUBDMmBlZfJNJ+B6o/UqWe01eA/Bebop0k6M9f1xfnkbZO5GNw0eOTR0
x4T7kVQ/7bAoHCZrZXdMxkWIkRGNO6akvbsBWnMFTjNpkWygKnmMGDqd7UlC8OtpA6U/lq1j2y7z
winmCyqwKmWpGwIl7F/TC0STdoGNcGWT8ucjtuAsTnWTh5Z6pi9RlflUQEQ10OWjRW8u/cIbi13N
FXESiaKvf3jmdvoUDiIKWH/fRqL4FlfvSF+9VTSVBn/0FUueveGldjw1nvyEGzjzukUH1o38KceF
dJvKGMTKErLbkBwgAB+b8ftyLo17armm7Eqt70pUwtHTUhA5U5Va2Rc/3TGczxVxWwoDGyISp/6u
70rZ0buSf4BgoeadafSTw07qlJxxMDkwauslU0Fs2i2D+Yaa3iBobWk6Hg+rrRuu7/nMjI0tRsWK
ESxLhLDGc0C/EBDRoq9dZrl8Io8V8Mi4q44d+vGXm2dgwcXXdiXYnGUZITxYjmOr6BaWC9TzOycc
2P7+UQhg7sm+70J/h7/Td9PDotNyKtCLBc3PKWyNfnhJBkW1hoS2JWzUESe2hs1wHQ/anvkFD3iZ
i2yT7dIWB/Fe+Yle0FT8JChHAdl9Qpw1srPLE50DqONqBRJ7SKIo2hilwLhgi1yhhMZ9N+0XrMrb
NSNppvZ8inBW5bgw+Qdm/bUsqpazynydh5RQSVXhe08iJ2EbL0yC711bVZu81M2U9KSDlb/EJlgN
PSNNMVncBJT5/WpG/kKRwijW2u79U8HMgxWbus0LJQO9+euAr140VgfCqXIBtVDqYQQTZRWIBbnw
9gUCcY6IZguUExYBYWvoeUArb3TNS4CE/zaPuQk44YjLS/ZiJvOPPS7EKDCVDupnemc7Og+nMO3U
V8UASBUC1AQ02Y50tXNSNBqS6ElSZllLUmTaLZI2zbUQ26bJrc6Ka6Atak+cEnbC3m==