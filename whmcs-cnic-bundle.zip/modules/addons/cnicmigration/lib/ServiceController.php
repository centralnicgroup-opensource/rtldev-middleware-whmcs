<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Illuminate\Database\Capsule\Manager as DB;
use Illuminate\Database\Query\Builder;
use WHMCS\Config\Setting;
use WHMCS\Module\Addon\cnicmigration\TldModel as TldModel;

class ServiceController
{
    /**
     * @return object
     */
    public function getUpcomingDomains()
    {
        $allowedStatus = $this->getAllowedStatus();
        $registrars = AdminController::getActiveRegistrars();
        $query = DB::table("tbldomains AS d")
            ->join('tblclients AS c', 'c.id', '=', 'd.userid')
            ->leftJoin('cnic_mig_logs AS l', 'l.domain', '=', 'd.domain')
            ->whereRaw("d.status IN ('" . implode("','", $allowedStatus) . "') AND (l.id IS NULL OR l.id = (SELECT MAX(id) FROM cnic_mig_logs WHERE domain = d.domain))")
            ->whereNotNull(DB::raw("(SELECT m.registrarto
                    FROM cnic_mig_mappings AS m
                    WHERE m.active = 1
                    AND m.registrarfrom IN ('*', d.registrar)
                    AND m.tld IN ('*', SUBSTRING(d.domain FROM (LOCATE('.',d.domain))))
                    ORDER BY m.tld ASC, m.registrarfrom DESC
                    LIMIT 1)"))
            ->select(
                'd.id',
                'd.domain',
                'd.registrar',
                DB::raw("(SELECT m.registrarto
                    FROM cnic_mig_mappings AS m
                    WHERE m.active = 1
                    AND m.registrarfrom IN ('*', d.registrar)
                    AND m.tld IN ('*', SUBSTRING(d.domain FROM (LOCATE('.',d.domain))))
                    ORDER BY m.tld ASC, m.registrarfrom DESC
                    LIMIT 1) as registrarto"),
                'd.expirydate',
                'd.status AS domain_status',
                'd.userid',
                'c.firstname',
                'c.lastname',
                'c.companyname',
                'l.status AS migration_status'
            );

        self::paginateQuery($query);
        $items = $query->get();
        $dateFormat = self::getDateFormat();
        $data = [];
        $skippedCount = 0;

        foreach ($items as $item) {
            $client = $item->firstname . ' ' . $item->lastname;
            if ($item->companyname) {
                $client .= ' (' . $item->companyname . ')';
            }
            $migrationStatus = $item->migration_status;
            if ($migrationStatus === null) {
                $domainObj = new \WHMCS\Domains\Domain($item->domain);
                if ($this->isFreeTransfer($domainObj, $item->registrarto)) {
                    $migrationStatus = 'FREE';
                }
            }
            $data[] = [
                'id' => $item->id,
                'domain' => $item->domain,
                'registrar' => $registrars[$item->registrar]['name'],
                'registrarto' => $registrars[$item->registrarto]['name'],
                'expirydate' => strftime($dateFormat, strtotime($item->expirydate)),
                'domain_status' => $item->domain_status,
                'migration_status' => $migrationStatus,
                'clientid' => $item->userid,
                'client' => $client,
            ];
        }
        $totalCount = DB::table('tbldomains')
            ->whereIn('status', $allowedStatus)
            ->count();
        $dt = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $totalCount - $skippedCount,
            'recordsFiltered' => $query->getCountForPagination() - $skippedCount,
            'data' => $data
        ];
        return (object) $dt;
    }

    /**
     * @return string[]
     */
    private function getAllowedStatus(): array
    {
        $renewIfExpired = DB::table('tbladdonmodules')
            ->where('module', '=', 'cnicmigration')
            ->where('setting', '=', 'renewIfExpired')
            ->value('value');
        $allowedStatus = ['Active'];
        if (!$renewIfExpired) {
            $allowedStatus[] = 'Expired';
            $allowedStatus[] = 'Grace';
        }
        return $allowedStatus;
    }

    /**
     * @return array<mixed>
     */
    public function getFreeTransferDomains(): array
    {
        AdminController::getActiveRegistrars();
        $allowedStatus = $this->getAllowedStatus();
        $items = DB::table("tbldomains")
            ->whereIn('status', $allowedStatus)
            ->select('id', 'domain', 'registrar')
            ->get();
        $data = [];

        foreach ($items as $item) {
            $domainObj = new \WHMCS\Domains\Domain($item->domain);
            $gainingRegistrar = Migrator::getGainingRegistrar($item->registrar, $domainObj->getTLD());
            // @phpstan-ignore-next-line
            if (!$gainingRegistrar || ($gainingRegistrar->registrarto === $item->registrar)) {
                continue;
            }
            // @phpstan-ignore-next-line
            if (!$this->isFreeTransfer($domainObj, $gainingRegistrar->registrarto)) {
                continue;
            }
            $data[] = [
                'id' => $item->id,
                'name' => $item->domain
            ];
        }

        return $data;
    }

    /**
     * @return object
     */
    public function getPendingDomains()
    {
        $registrars = AdminController::getActiveRegistrars();
        $query = DB::table("tbldomains AS d")
            ->join('tblclients AS c', 'c.id', '=', 'd.userid')
            ->join('cnic_mig_logs AS l', 'l.domain', '=', 'd.domain')
            ->whereRaw("d.status = 'Pending Transfer' AND l.id = (SELECT MAX(id) FROM cnic_mig_logs WHERE domain = d.domain)")
            ->select(
                'd.id',
                'd.domain',
                'd.registrar',
                'd.expirydate',
                'd.status AS domain_status',
                'd.userid',
                'c.firstname',
                'c.lastname',
                'c.companyname',
                'l.status AS migration_status'
            );

        self::paginateQuery($query);
        $items = $query->get();
        $dateFormat = self::getDateFormat();
        $data = [];
        foreach ($items as $item) {
            $client = $item->firstname . ' ' . $item->lastname;
            if ($item->companyname) {
                $client .= ' (' . $item->companyname . ')';
            }
            $data[] = [
                'id' => $item->id,
                'domain' => $item->domain,
                'registrar' => $registrars[$item->registrar]['name'],
                'expirydate' => strftime($dateFormat, strtotime($item->expirydate)),
                'domain_status' => $item->domain_status,
                'migration_status' => $item->migration_status,
                'clientid' => $item->userid,
                'client' => $client,
            ];
        }
        $totalCount = DB::table('tbldomains AS d')
            ->join('cnic_mig_logs AS l', 'l.domain', '=', 'd.domain')
            ->whereRaw("d.status = 'Pending Transfer' AND l.id = (SELECT MAX(id) FROM cnic_mig_logs WHERE domain = d.domain)")
            ->count();
        $dt = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $totalCount,
            'recordsFiltered' => $query->getCountForPagination(),
            'data' => $data
        ];
        return (object) $dt;
    }

    /**
     * @return object
     */
    public function getLogs()
    {
        $registrars = AdminController::getActiveRegistrars();
        $query = DB::table("cnic_mig_logs")
            ->select('*');
        self::paginateQuery($query);
        $items = $query->get();
        $dateTimeFormat = self::getDateTimeFormat();
        $data = [];
        foreach ($items as $item) {
            $data[] = [
                'id' => $item->id,
                'domain' => $item->domain,
                'registrar_from' => $registrars[$item->registrar_from]['name'],
                'registrar_to' => $registrars[$item->registrar_to]['name'],
                'status' => $item->status,
                'message' => $item->message,
                'locked' => $item->locked,
                'nameservers' => $item->nameservers,
                'contact_details' => $item->contact_details,
                'created_at' => strftime($dateTimeFormat, strtotime($item->created_at)),
                'updated_at' => strftime($dateTimeFormat, strtotime($item->updated_at))
            ];
        }
        $totalCount = DB::table('cnic_mig_logs')->count();
        $dt = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $totalCount,
            'recordsFiltered' => $query->getCountForPagination(),
            'data' => $data
        ];
        return (object) $dt;
    }

    /**
     * @return mixed
     */
    public function getMappings()
    {
        return TldModel::all();
    }

    /**
     * @return mixed
     */
    public function addMapping()
    {
        return TldModel::query()->updateOrCreate([
            'tld' => $_POST["tld"],
            'registrarfrom' => $_POST["registrarfrom"],
            'registrarto' => $_POST["registrarto"],
            'epp' => (bool) $_POST["epp"],
            'active' => (bool) $_POST["active"]
        ]);
    }

    /**
     * @return mixed
     */
    public function removeMapping()
    {
        return TldModel::query()->where([
            "id" => $_POST["id"]
        ])->delete();
    }

    /**
     * @return mixed
     */
    public function toggleMappingActive()
    {
        return TldModel::query()->where('id', $_POST["id"])
            ->update(['active' => $_POST["active"] == 'true']);
    }

    /**
     * @return mixed
     */
    public function toggleMappingEpp()
    {
        return TldModel::query()->where('id', $_POST["id"])
            ->update(['epp' => $_POST["epp"] == 'true']);
    }

    /**
     * @return object
     */
    public function getEppCodes()
    {
        $query = DB::table("cnic_mig_domains")
            ->select('*');
        self::paginateQuery($query);
        $data = $query->get();
        $totalCount = DB::table('cnic_mig_domains')->count();
        $dt = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $totalCount,
            'recordsFiltered' => $query->getCountForPagination(),
            'data' => $data
        ];
        return (object) $dt;
    }

    /**
     * @return false|\Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model
     */
    public function addEpp()
    {
        $domain = trim($_POST['domain']);
        $eppcode = html_entity_decode(trim($_POST['eppcode']));
        if (!strpos($domain, ".") || empty($domain)) {
            return ["status" => "error", "msg" => $domain . " is not a valid domain."];
        } elseif (empty($eppcode)) {
            return ["status" => "error", "msg" => "No EPP Code provided."];
        }
        return $this->addUpdateDomain($domain, $eppcode);
    }

    /**
     * Import multiple domains with eppcode
     * @return boolean
     */
    public function addEppCsv()
    {
        $csv = array_map('str_getcsv', file($_FILES['CSV']['tmp_name']));
        $return = [];
        $return["totalSuccess"] = 0;
        foreach ($csv as $domainItem) {
            $domain = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $domainItem[0]); // removes non-printable characters
            $eppcode = $domainItem[1] ?? null;
            // Checks if domain is valid and epp code is not empty
            if (!strpos($domain, ".") || empty($domain) || empty($eppcode)) {
                continue;
            }
            $add = $this->addUpdateDomain($domain, $eppcode);
            if ($add['status'] === 'success') {
                $return["status"] = "success";
                $return["totalSuccess"] += 1;
            } else {
                $return["errorMsg"] .= $add["msg"] . "<br />";
            }
        }
        if (isset($return["status"]) && $return["totalSuccess"] > 0) {
            $return["successMsg"] = number_format($return["totalSuccess"]) . " domains added.";
        } else {
            $return["status"] = "error";
            $return["msg"] = $return["errorMsg"];
            unset($return["errorMsg"]);
        }

        unset($return["totalSuccess"]);

        return $return;
    }

    /**
     * @return mixed
     */
    public function removeEpp()
    {
        return DomainModel::query()->where(["id" => $_POST["id"]])->delete();
    }

    /**
     * @return mixed
     */
    public function renewDomain()
    {
        /** @noinspection PhpUndefinedFunctionInspection */
        return localAPI('DomainRenew', ['domainid' => (int) $_POST["id"]]);
    }

    /**
     * @return array<string,string|bool>
     */
    public function migrateDomain(): array
    {
        if (isset($_POST['domain'])) {
            $domainId = DB::table('tbldomains')
                ->where('domain', '=', trim($_POST['domain']))
                ->value('id');
        } else {
            $domainId = $_POST['id'];
        }
        $params = [
            'domainid' => (int) $domainId,
            'domainname' => $_POST['domain'] ?? null
        ];
        try {
            $migrator = new Migrator($params);
            return $migrator->transferDomain();
        } catch (\Exception $e) {
            logActivity("[cnicmigration] " . $e->getMessage());
            return [
                'message' => 'Domain marked for migration - however, the migration failed: ' . $e->getMessage(),
                'success' => false
            ];
        }
    }

    /**
     * @return array<string,string|bool>
     */
    public function supportDomain(): array
    {
        $params = [
            'domainid' => (int) $_POST['id']
        ];
        try {
            $migrator = new Migrator($params);
            return $migrator->supportDomain($_POST['message']);
        } catch (\Exception $e) {
            return [
                'message' => 'Sending support message failed: ' . $e->getMessage(),
                'success' => false
            ];
        }
    }

    /**
     * @return bool
     */
    public function checkConfiguration(): bool
    {
        return file_exists(ROOTDIR . "/resources/cnic/templates/cnicmigration/email/tpl_client_default_english.tpl");
    }

    /**
     * @param Builder $query
     */
    private static function paginateQuery(Builder $query): void
    {
        if ($_POST['length'] > 0) {
            $query->limit($_POST['length']);
            $query->offset($_POST['start']);
        }
        foreach ($_POST['order'] as $order) {
            $query->orderBy(explode(',', $_POST['columns'][$order['column']]['name'])[0], $order['dir']);
        }
        if ($_POST['search']['value']) {
            $query->where(function ($query) {
                foreach ($_POST['columns'] as $column) {
                    if ($column['searchable'] != 'true') {
                        continue;
                    }
                    foreach (explode(',', $column['name']) as $name) {
                        $query->orWhere($name, 'like', "%{$_POST['search']['value']}%");
                    }
                }
            });
        }
    }

    /**
     * @return string
     */
    private static function getDateFormat(): string
    {
        return str_replace(["DD", "MM", "YYYY"], ["%d", "%m", "%Y"], Setting::getValue('DateFormat'));
    }

    /**
     * @return string
     */
    private static function getDateTimeFormat(): string
    {
        return self::getDateFormat() . ' %T';
    }

    /**
     * Determines if the domain is eligible for a free transfer (without renewal)
     * @param \WHMCS\Domains\Domain $domainObj
     * @param string $gainingRegistrar
     * @return bool
     */
    private function isFreeTransfer(\WHMCS\Domains\Domain $domainObj, string $gainingRegistrar): bool
    {
        $fn = $gainingRegistrar . "_GetZoneFeatures";
        if (!function_exists($fn) || !is_callable($fn)) {
            return false;
        }
        $registrar = new \WHMCS\Module\Registrar();
        if (!$registrar->load($gainingRegistrar)) {
            return false;
        }
        $params = $registrar->getSettings();
        $params["sld"] = $domainObj->getSLD();
        $params["tld"] = $domainObj->getTLD();
        $features = $fn($params);
        return ($features !== null && $features->transfer->isFree);
    }

    /**
     * Add or update domain with eppcode in table
     *
     * @param string $domain
     * @param string $eppcode
     * @return int
     */
    protected function addUpdateDomain($domain, $eppcode)
    {
        $domainId = DB::table("tbldomains")
            ->where('domain', '=', $domain)
            ->value('id');
        if ($domainId > 0) {
            $getDomain = DomainModel::query()->firstOrCreate(['domain' => $domain]);
            $getDomain->domain = $domain;
            $getDomain->eppcode = $eppcode;
            $getDomain->save();
            return ["status" => "success", "msg" => "EPP code for <strong>" . $domain . "</strong> added."];
        }
        return ["status" => "error", "msg" => "Domain <strong>" . $domain . "</strong> not available in WHMCS."];
    }
}
