<?php

namespace WHMCS\Module\Addon\cnicmigration;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use WHMCS\Database\Capsule;

/**
 * @property int $id
 * @property string $domain
 * @property string $eppcode
 */
class DomainModel extends Model
{
    /**
     * The logs model.
     *
     * @var string
     */
    protected $table = "cnic_mig_domains";
    /**
     * @var string
     */
    protected static $tblName = "cnic_mig_domains";
    public $timestamps = false;
    /**
     * @var string[]
     */
    protected $fillable = ["domain", "eppcode"];

    /**
     * primaryKey
     *
     * @var integer
     * @access protected
     */
    protected $primaryKey = 'id';
    /**
     * @return bool
     */
    public static function hasTable(): bool
    {
        return Capsule::schema()->hasTable(self::$tblName);
    }

    /**
     * @return array<string,string>
     */
    public static function createTableIfNotExists(): array
    {
        if (self::hasTable()) {
            return [
                "status" => "success",
                "description" => ""
            ];
        }
        try {
            Capsule::schema()->create(self::$tblName, function (Blueprint $table) {
                $table->increments("id");
                $table->string("domain", 255);
                $table->string("eppcode", 32);
                $table->unique(["domain"]);
                $table->charset = "utf8";
                // RSRMID-1303, $table->collation = "utf8_unicode_ci";
            });
            return [
                "status" => "success",
                "description" => ""
            ];
        } catch (Exception $e) {
            return [
                "status" => "error",
                "description" => "Could not create table `" . self::$tblName . "`: " . $e->getMessage()
            ];
        }
    }

    /**
     * Drop table if existing
     */
    public static function dropIfExists(): void
    {
        Capsule::schema()->dropIfExists(self::$tblName);
    }
}
