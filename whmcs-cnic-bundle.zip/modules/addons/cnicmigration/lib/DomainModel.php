<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoMsN0ms4wKZpt/9B+F4QrPokBuRRFHsegwu89lCmfDka6JX3WsZwepTSzFXFxDaJRzd0HOk
cxOOEe7d/M1OQMJNZSWTpFdQl0+HfKkl9OZEOQBur3ybLAenQgkBamxm3EtXtIbvSwtQuWQfCEoB
S2PncLFj8UCT7nv5zvC9YuI1I4Z1qx0IAjiF8HzIHh8vfuj+NS95rik84fozFyBz09abGl3JDUTl
VewbbjFUpS8QxjmU/CtnaZ0os3Um7dxETSETgu3L3W3OXwtmeEhzGSlm2OHj6WeSm7gnPB+7XGQn
8uXHV1aiOkN5oObSFPK/a18hkzGOTy56sbcB5/ES/Zj4ORBlqSIoPImiu09OjZitCmleX3BAAPub
dfYcbuILGAP9nP0kGGEu1klu4pulsUATw0CM3/0Euu6BqHZGqdIgjS5EG1Xv3Kk0X+t12PtB1lhD
EQD0PTftzICuUBG3u1UHoZM2jZVm7B0Sb4aAfgiNp4lvkMBqMPu/okw4Lne2y8v4WvXf+yJzu8ta
3XISY2aJoDnWgx00+g2sqs3PWD2OPyEnRQpHzku7WU/JK+wuQXEC99S2DiEqI+k14vfLS+2p80gy
gSetTBKLV8ZtuXUarQQ+4KAQ9w7c//ME+SvSToGAUPjs9WJNR0jWkHpy+xFs0frTxnGvtKoTS7H6
WnoL+uP+LcQ2YJd1+FFoCbNwKECzi3ZBQfkS10BP5jR9JM75JYdgEmwJMALeT932oDmw9gzWdAsw
eNCBNz4R3WWcCR0osSrl0mS91OET5BW4+px6IARbKwT1FItZ0V2QNPRtoy2/j7LQqHDHSqADiw3d
DF0DMTWG0x7GasVIqMicwc7iSpF7Zv61z7atySWa27SWjknTbT7lTOHWlS52PaCNJfyDTaXTm5u1
mCJN+pR3KJ1eAxvqwa8SgFFd2wc3DOE4w5Odsu1e1OFUckvH9RLpc8p5IcR5W71FwWb7cROqx1/9
cVQIapeV6fcWBFzxcf06qejhgEPAbu78+u31/MJx0I8O0uBt9EvpvUUiBuNGH4kK4mBNps+G8z4g
w8hXoprsNG/cpkeb23eLNZ2oGfkSzasGu707J29FZ6EoT/H8PijZtTIPY6QLfVe+/0yJkQ6GZ2vj
w+jQMcSgacSQCRTAIBkgh7AzS3k5qffou7RE6wX+zjsLVgwmoPRCz4fB8Q+12n9Piz63Mcqr4QCI
+8tSksQsf6yN2eGs2I1oG6QW9UgjAl/hOqdMIugs/3QFgTEOwJvi1Fcjpr04k/+4ooTOygX3XMOs
qJCeMCr8WKQ+Cxd5KF082NkOYe3yC2aEUkuLnHlCI7dJoe5ut9Ce/zAW9tx7c6VUWeflzHuhbc73
cTgH1UxiRqCs/8Lf4juYU8QgEwyE3lUArWIN/zuZ0aGPw+bmyDTw69mpFgPMz/8vVN5Echs52P0E
Wq0EJQ/RBpOxFhvr/e+GCktynXo86FeFIh4n+3toORHIqxs4tGKtzK/hJMYZo8TIP8dlbGf117sC
62gi8fGi6gonIAL2XuUV+d1uDwXmZYqWO6lFmLXM9Yt0hOC7LCqdSNE+VR2ZW/K/gF7tcnAuInRw
LKbLk36t10fblL0hwjsjCFV0nWIqjU9fx8O8hfoCUX9lQZ7mkxzSZsrH5XANxAiO9+QykwO1iqUs
qrBlz3ekZ4GiFpG8xdLhSnvU0u+KK0wIOrfsipGKWj2atVqnZYnFBdvfBLpId/K8CIGnQu0nrX28
di5f/bmhXJUT3X7XMntIaMDrsNOQgDMbzOsvQUmEKdG5NLtm7ty6VulmSPX/YHukYjJPf2cvwdVY
gMLqj5Kg2jzmfNNj/cC/hRtE+o+YAAPr/6DNcrz3tiTAhx9hQf9tYbv29o7eLTLcmdE37Ig/HX6E
vr43eXoQaGSGIX2yMiD9SQRAhZdpV3X4dXY7/qHPeyuRi9QzSNrL+dnd4LHphYsung6J8HhOaBy5
3pXB1x5Iusqa19HFA+moK0mWGhkQh8zkLagkaDye5AjffpTV3x2ZXbl+mPCqucOppZdWRFz+grJY
nP0qzE01LORpuVzHCo0mGa3iS1kMU8xMBd01NEtTiyGqkOFRxgyoz/WwYjbOrs/9ZUnrFqeBbZff
ES2cNB8O9mlTH9GgHnJ1I7OVHT9CxnmYDCUdn+ipyWNGg7j3U6wJXgYz5WDQMwU0BvXnb4GgkYTT
dFesCkcxk3wWgfXLbH3Lt7OKGccriUSpdwwDYFZlJb4/WspVJXWldAX2wV3PXyBW/Jv68cnOPA/w
TD9cNSrKMX2kAcmh6U6bnNCgDaxbYRmm4lF+a1zZt0CTBJK13nPvvPrYAy3W3rlCiA/s9cU5ldUh
Jz3IYMVO3ZhyIaLQeg6CyxqsnSWnXb541oTmqfqNRQQ4LL3t1WSj746fzjdLxTjFMkz9KYwjf+W1
qRECL0mUxSAPjjuDwcGxe9Vvq3tGYKVsmd/Y8enYwowTroIw734eZsPW/Y1M64JOCDEu7YvDtpit
kq6FOO51Fsi8JebA5qvmREwisqnWn5PYHKQPo6YTbTwTbOAlN99nQKUHabzm070I21vCkWJT8Don
iRcStvmrshVfkxegVjKJsOT1PaI8Q8ZH5daJsw7VLAAun7Od5IGcJAtprVeMdoXPCv0z/fwv8zsf
HPYhDGkYAxCB7wgHjG/0xDRV2zsVHf4Gu/cPmvj6GANTRnj2oZE/FjMuqpuLIzFgrtd66lsipYj4
YvrT/5d4IXBC7NKWaFb78viAjU4k8It7ZY8DnfLxFXq60bW4JFRPl0n6Bv3lwm3NuUbh/Kz6q5Q0
a1cxNy9qd+zWz6QB/KYwnFH1lO8+kCGt1UYrrk48velRjsgo/rU7WdMMAHbFgFQJIDkewxB9SZFl
1/N3Q4RJzZBUjVImK6G28OEzu1rD52qx+RjJ8tVGiU+tG9Eq5M1VCOk2nR0BwG6tTL3r5z7bvWZs
42MlI6aBbCgS/X7Jdi92uBoIc/r7qd/9VFhpdprPd1XrhrQTYkDmAREOgXQu4X4H3om7sPCJ+W51
JDhAz79IjDUBgkVJ3h0cYZMDMyopcEGF3uht10M59vvVR+OGzoSJw0xUMQGjPru9n/9SWRMVCbfW
7or7YuGddFlLB+A08RKN9c2WuF90G3sMriycwxAbDyZojANFETw0qe2Cj0rB6mlGXiyqi2dVhkly
QoOLOMfN03RsFHE+8TRW17H2PT/6F/Y+5jTawb74pCBTO68s2cPV63kFL4H4o/cvnFaCTVCgwKo1
X35Ia1NT8iGeYEZlAqdZesmxbuT2Ds2yXSS1nBF56+nec3ZsrSnky4RqRfLDM+zHHulrt5O1J047
POHiRATGzKc/eDP6Hx7UUQU/mVxKfADVab9y/c9F9oJ5YRYf+vBHad33/q1uFtlQZJHT2WkhdFn/
tjX1uaj/Rk5YtzaGmCvtlOBMYW5qdPneA9fladVGpU3w8eTQlfe20lzO3htPT1BMZYPNlRIL65u7
IEgSc5zy+ArDKT3wj46VIAR3r9jfvL+npxmNZ/c5h8cJpUfALqy3bDN902fm1FihwrbBG3CBhNwh
u6SBdqa+UatpwmifvUQfdJtVMmx7RpIsjlfsxCJdPaSChgKkoj8OSl8SAHXJPxe3Hdj+a8hrMRh6
W0QoIePYoQKTod611DI8vvYyZWX9jDF+N52gTZYCIdVbebNCuqF0YVVYMtHOIt+kgrG4xOL21FzF
pRfhSZldOvgIVkWGfpLDdeHq0Y61bFSI4j4t/4OmfKHTeJtxvDxTxCdaS0PISkyb/C8VbQxuzcoM
mxjnmdcYEh54b/GoU5vAGq1hOxwEWYEh4ROb+sj/0OQg14uex3lhEPwxOaJOAgwdMK9TP7v/56tT
PwvXpagpkktnfyl3+eQJRd27alcFLPN3gjBKAZiYSvOLolKiGyNtvTnLou4BKTIBIexwKcKUzikb
xpaAiinTEyDL/Unn6IpNtFY7ZmRymdQJmxPRAdsxrSd4u1QoYispG15AQr34Uc2NSXbsW0earkhU
lcUYu6yZtedKtNGY8bceZZrUEvKsJdHofgny4lrgVobzm5u2rfsN6QFooCzKfn6FuQ7eP8TOOA9B
7zHZFUuWKcX/kD6ls4FAtFR/cSbs3rOmDV25cu486+4Lq8iRi7G1G08CyvzL9JH8cENgvtA4+Yr/
PkAuvltNQIrScOqSTOE2rhi3X/GIUYjEQfT9QOY1XtCgii9smkeiJTI8j2ueATWN1OfFoAnFqZ9w
