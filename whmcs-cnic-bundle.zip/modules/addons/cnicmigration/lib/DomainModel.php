<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnXObRe13Mwzt940cSJs641DDyq57dC17l0izwgZB4/b6mJv9IDJY5hkkgwizcGcdTXXutPT
s9T+RuzrhNbjhzyP/KDwR+UcYxjA/pY6EwZ/C7q5y9Hbr+uDsh+uY5lhzwH3fj0M+JOU7/gFwt5I
SEYf3Xa+B4K5oD2co12yzBMzuOioIaqXYciHcSkiOHZT/8aRjGsjVb45Hkzm9wWrgFqq25pX06vi
VKekhR727oWIWECMUY0Jf9/UdWnLMlcvP5pH5whIxozYFlMSSWQDTmzBbsF/QcPyDSjr7o1XIGba
0GodFVZQh9humSOAjFoJN+p0yQO91cOVxu3Gx20YCve8Y1xER9mDXpQZPSm1C0X9kqJmlY1ABGq7
MWar/dr3Kh4eO3MxZfFcS0CoxwEgKDPhjBv4SIWT3RS9d/oyLcClKUO70vLTArhVwzTY2BkW7Qk7
K41afyFGWv9ja2bc2C+GuT8dJ8ia+RPAhKHP1SKbEG51OzfcVPkdcKUw/6bWkMPrx/zaJSXn/b2K
rVhk+kWWMqkl/qhiDt2rCDo1/EXLGE1+kipdNH+sx58hyK2ztxVinl7OYrwzt3ll8Q0088U1Znwf
N3HF045Lc4eHNlwACR3aGwhNt6kWFvaDUvsiT0OUGxF79cPn/mvx85C/OXphuvtY5XfGYSEhXRJb
ynCq2FiqkMWknVgcQHaR3kVbiCQjgXM3BeZRp8/RTQS6KG0XmxmEDgye/seSzbtPQvOwoi0w9UjK
OEAUE3+VmW4ao/3pXQUzwmfH4tbwJVnMcVsoV7SnI7cOz598HdllAAOVAldtjo9kpgJr8RtKUmUC
uaCIyp45ABvizZg+ByY6zfYmYe+74zcbOgrW+wDqPVCFoyZm4emLL3AipjU9ohK6wL5p8Z6z7nqT
bxoTYwWmdmsAPDw0jU4T/B+yq854d3ZWPQzj6+Q4LsmrClh+U5rlyi5n2xtIgC25QkVBVGpT+KxX
ii3eJe7mb6d/z4lFgbNCeqAj9NLvrtnlTS2432p9e9QbAG2Fa8JEmBX9wkBdNcvNfd954EwYyi2m
1abR82mIVYBD6bF8TtDv9d9ntbkl4S8A4MyUn5rZBX83LWq1yV11isi8SPvCbU0VaS3h1HMBuzBU
0RmT/m167oKBxfCHUk08iqlAxtUSgFSpEobWyKLeYxDlHKYUmI8mPoH9gcGQ8EAge9RkxqDoQ1bR
EBbhOPEuVuDNOKcc7GdJQ8SfBejgwiUrDUBdd2+fD2JQR4Dp+tZoxG7CjLOnp2d2P9GXkkV7b+t2
pgAVEel7GZefyDMkRpfGdC0esogfXFDYB3/UHSvcpP0x8uvGKF/um7jYhuFdlEYnfad6WOnzpJAG
fwOHZ1N3bFPkCFGSH8ACYVlHMP+EPL14fhM2knc2lOLCc6oE+iwnUhuEqkzN0S7BoT1WHVEng0ZN
JtWMm9roG8xqxxSb3xRYcJiUnNeMsznBCdUlCKB+iPgjAmIl6ZU8Hfhtc5uqxePsSXenvPjvx2m0
j2UHkjPFtj3BDWIB9cGlwLKvUzfbrpI3OeCu8sG5yui/Wt65AFLCN5//q/wgBX4A9o/iGcPx0yJT
GUssCgF+KTQwT7cD7sHYbbjpHQNQxlmp6keNLE44XcYUBDLLRFZef+ZtGL0maXyk1iRpI5dqjj9T
/F2fa+b7jqT8/v47YKJvTSLkCsi+JAmWH1rwrmGmsd2GbkXq73KUk8yceWpjxNaMXy2ROpM8HKGV
SVqECv04xOKJjxxC3LNbjzgLXl9huP4Xy7JboFKPyiAjJFcxQ2L873dgsPGjjREMtth0rhvIHoio
DrPrvSjh2z/Or/T0JXrrkWati8arxiWI+Flf1qO/1nK72/Z3CQFMVnvSp5x1bvkE80/WVioJHGPa
XPc7IThLr1mL9Va+GnaSLT7v4f4OI4+xtNT7GvKr/RR+G9eNAb1Y7ExLGi72AtktSOmI1ZQ1/yyj
N6W1qLk/W1ZjyKgvzNDnpoQ59N4Vf76Mweol4SSfHJk1q4bOHWB/9zkT3uHQuAtxdy0M/IlQSAT6
AAQ0fdCSfmYyKqNysWaT0FcycU73YsdAnkNljg03h98QkwPxTwGHglmKt2dx/B8Z/T8N/I6urBEd
ovmzijUiLzPrSe+m/7HDXmAWCfujqb7lKqQCkYyBIi8qMvFZlPICUUbD37h3PNLCptJbM5J2dEf2
JIh35QHrxv2yXafG6DUHnWou9UdKjrA2aNVsbrKwXHp/RQygtFRlg3995YNWB3QHAa6eckPNeHeq
InlwgD2Yd+MU7pU0oJIJd8PvyGC1iV6g1Lakm0t75X9omB8CSMoNowIGGMF5M4+t1moAiJWrCUHL
N/Tv9HD/UcQDRV/YMNbDXbgR2NG7FX5nULLIQ2V8NisGgPrj0WeEb7GQmsW8qXANU9x1j3dK0AgT
gShUVb1MWK1zDXpXnE4NSiYWtoi2DbtO9BO+KfzYlE42trFLT4dGBI8qdtZLen4QbkS1t83RKQI+
KvL26i66bEHBy7ngrFXffKnb6HxGv5f9qgRQU6Kl1KvSut1LlnJVtCf6rxQFr6bl0lWmVfo1ePDC
pQezwjjQZsCZJQ+GBrDlTd6Nx4RvTFbCcgaiK7DsYwYlnLN6LkRH8twmZ55SUMBd/rRAHHjeMShB
iF+S91Uye2BPehYvVySPeYok2BKzNTnujf1gAW+YB5deUxVIM09OqHGJcOzyYTZP26n1Wdvzq5G3
VJG6uGSfoZ9OHJj2KcqVc3XjO03YJi3uRoIdDl3fvDlwgs+EMyh3Nj0Xv9QtCur9P17Xa362uIx9
SLvlvhn9+VDmB82NPiVMFzcA8rq5wLdnDny6cPH22IZ/lnzg0ibZt3IXkHnCPZwqPYIsxWWRlnRr
ny9lmUJYMKmGtFTXG+l1Im3xy4kkTuma4M3OxpWxPOGLHXsyrD8ewGAhn2Xp+Qy/CQeKpw+IDQJp
+aQT0GIpiRqUhBGqBo///82EQ/Ikc5mY7sD/zYbE8tsclJZKAUP6EATVhOj+6ZdxN0F+lCm67Ac2
a5eDc4fkYfcQOdXOjNp57o3tk227gVSd/mpg6MFOb1sQiaF10P5hzfmF38LLC/vIW5AiyYNTpNG4
ZbdGGBjbI8LQ3sLkMsmpNC4Lcysl+TSWWLnDYcBn9+rWCNllS2mI4gEzLJaohVyWYs6TddLQ4C//
zK60ZqtRzHjrMlkxtXEwc65tCTgMstDvgJQ4DsgMENYdbIADOb7mmKN6ncZTzIktBX8YRchxr5gb
u0HmB0Y7ACSYVnQlsUWx1ieQfVVQ7+f9i9ui2oc2dxBWLPrHuHIj4EJ2U9ciUg7JWDcxtlmWtg37
Zm2/iTUgMESftRoTlg0URtvOelIigzi3tI33ffMpsTNjPY79nu2BMGVhsYeUlXxXB8OCzYMWKSqC
QNNoAbp8fzFRG5q/JlGu60JajC36qSpgidnL3+3BfpCNhMct0rprMbR3GFKiG9kVmeRlE78ddG1v
iFAL3eqBGRldmii6+IkqIO5P+v0ktR6E39OHTYIEiu7wPzBbiaSmMAMff2ruL5i/xh9KBFblLyLY
ktCd/UG3ld3Jcl5ykums5dZA4WcrPcYlO+4734OL66ouWg6n905VxkF1fQtHkmJ7L7gqyhdwW7Ug
Ijpbw13rI384Cf8Hl2y4dbbkXIf06wZU4Qx1AJrF7V3F1EmtEYHyWpQC3wL/u7qxCXxYwduYbr//
hj++IuWitmtxZlHCIrh6l2ZWY6fbKj07HciNAdCZlovT3mjHd+oatNy5Yhb6Gjyw+q/zbmBDaeRY
uHsObU+89znb7MxjLk/HiH3RpQBkY9X0WqfGgG4Vy7i4g9zVdr67+IwuB02wDQspR6ZhaosS0z7a
yb6oSr7aJQ0NzmTcivIf0WEdLsAxoiOd/skZvHym5daJ0TY5M1PBCZwsxDK0eVXyVMtfqYmCjcFe
i2cBTvzagTf1JaQcAFU9Vbo7NMNTi8lUkeGbtwTnQc4BUscJdC1tmNI2aZcJE0G4sImM9O33byLP
UPE4f8vObMOP1yqUGZrSi7Gjpf/oAVFPChMDJ9FcwlAfmMfvaqugAxP/thsPeLS7ed5ePdVQeWTU
zMn4cNrTRNabwrNAXbmFiUcnBL9+HZb+ytinYENCiO0GRfhcYh/uSkcpu1xTh6g7/30pS7Jiu/L+
MT7+bBN1pRPtiadszODe+HkLd+wsSgR35nzdriO2K7f895M6fwIUo87k