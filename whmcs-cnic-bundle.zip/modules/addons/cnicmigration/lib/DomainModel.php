<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo2NAgm9CA+3r5w/ZvcZS8HNMya9kLzesV9FPkZNfObTBwBp9hxR2uEkLeqJFQdeUQxxV1HD
TVrNDEzli80r4dnCcRYYZ8ZcVDkieBibidwL7ebMHFCAfFohHjqJlnWeLX7eKKiTiNrqgQLeflJF
PB4pgc3i3m7CbdiMYOkTP1yUPmcIHJH90xGB4svaJsnOwXcT2t5nxVL1EslsCrl10JtggXZqbDM1
4PCaDiWjy7tSvrDPbNywAJKrg7dLNQ2trlueLQrS5tMYy3cFZ8SoiT8/1a2wPIKBAaogk/4FuHpE
Hva88V/+cuHgkjQdSktDMhWttziFixyCBHKPhjlL4A1Mx1NsBFX+0xDt0z7JsGLwlo9ekWJxPdUd
YdwJXaS1G8OSrAcxg+/eu34jn7r8DrYPDk3D0S8ehRRQjj+ppPWoebOb6zvwpPfpJBjtp5vVT91I
EzEDGaOw5REOq3d2pY+z4I9xdngGDuylpjiYWmZY0nOeErqnSNdu1099/4+0WTU4h5TxL6OWB6j0
MG4H/lwGjTvdx6AJUxuZ+kHQxiaI9Pe1EQWoTlmQwI2idd2FXnBNTbZTwkJ2KVRW8r21QfFYUdyz
jJURIe0k9lwDjaRftIS62Aze5bjNRaNpqJUw1+ED51Cm/wd9G6WUqdlf2Zw2bSREP7PYAXNi34cv
PyFqUqo9PdhocSMJVE1jFuhmwNOouHTTbqVQ9JVPqeR7vUPFO1c/Kr0aNXid5BLLkKIxo+3SoMyH
Gsfyw+SAXBLWgcP9uk0oCGP/Gt5/w/rK8JGdAtA2Ynf/gOuwAFXQqcLfipTkg5xge0fBM3i/OXmE
heMf8SmGNxnQXf+cdIdgeog3pPhPyeo7ulMeDB4QQ2qSd1HSRFdrnE+BvBfJ+D1IiaUP2jHEw5o4
ltV7Ls2wig9seuDs3hUHKZew7WURIUT/d+OrdhrXo2MLwuu1w9HW8d8d6JyshJuwF/n+psC4R7lt
z8J6ZWT2HzeX21/TYBkGyg5ioc74aYlkX33a8EDNogXY6oS3piuqzl6p3zY7xql6xxNV3zmt7Lpy
6bmrewkdzj4K+05S5FTjXvaYl9PcZFKhhyIVbllkjl3Vv9fDIh3R0RE254AHFeU0wnQ08YGaKmb3
IkSJl8lKguBLXApOpyrLRqhb9Rl66Vi1dyh/lDg8azfHmqscz5PU4ZygKGLisQgb8eN79HfiAxDT
cRaf44Lok4e3ohC/kJcb9a9JcA58bWI7+AqJcpujYvSB5Udkiuh3XuQ38xwuMdgqgML6H1VOsbDo
ieL9gT+23S388GaiYjy+IaT27ebEFVpNJd4r0S9lUVRk6/+7LZ6oClPXcuzR8sjVvfSIIecmuDef
KSJwyLHR7bRnPNJ2/1MHvoZLzTTFkt+WcSvArnVnbgzXpIJB9NyhSlhTJAnFvOyh516R+vg4C/MP
bxOdssYc4Ikbsr3x61rxd3xQr1298MAiDqIKo1GgwztpAbG8A25tys+/F/1peAB+Yz7Q30NdNWIq
VuFE1Wa3EoZ+V3LvlcyIeBoWnFQyTjfP1Kp88EHPqK4Xg/11wdb8ODRZA7sJ7vyelULWgDSCGE6O
1ikFttbty+MkHm8Qb1y0fZMgsH5p+kBTKzMxweKvYCEjGO2tAerASM6Rcgzk7fNTY3WtGrYFIurh
mhLqcp350x5ndNnw/538ufDq53Qj+2M9vsw0BL0Qz9jY5Azg0A1o8knuGmOG1R2HfBdMKDsN0gpe
7qD7tOh9wWwoBF5QCYaf2+ySdrqPhcVP0wY64MOxwSMRVjLXNyzwzuPCv0wNZJZ1rWSkYFvGiISg
DOnIbnaUFJZ9wzzecroX93ywgcQHsKNVz3VKoxQEJg00eZYei8UhZEqJFX2TTwN1AjWoSmQ2IFT/
YiWsZqihhhm30yDuW+sf/tCfMwdE7P34ohGaJoyoghz0YseKA1H9g5cPY5fHa4H2FOZWUnm3ZBWJ
wrYFc7Jf0dWCXGmssrhdzw3tkSTuPKNEt2qn8y1RBlZXZT2OUffEQmBYGnx/2mdEnLhVQJ5GGtUf
gXkZb8UfYIsffIDw5dlnnkJ2hkg1FjNIf+rEqlnwZObStqLr6u1eroWAZ6LrieUwFtKJVboc2nvm
qe3QQuwtFV9+rneFcBTWVqVZ0CpQRHRZ9K5kU3O5Mcsjz02S9o125kPWbnfiahHfog0oeCuvyhMS
CcZCrjGrYWc2pf4rPBcemEe9Ui5/Iu0gWlXMnTQmjaU62BGlWRvPOI5HEo50+mkvnM393O4NVYL8
bLrwseqrcqLroFXnRYOE36JocPi4tNsM0EA9bPplfcVo0KhGXercTC1ndcVYMOGREGJcQkhDtZzU
jeQ4wtkeMYNxHNkpPsigMo75zu79NtxpOyAxeZSLZE/7Erd9buFM8QQhkICZC+HqBTURD6DvQqdV
gDzRFrXkUlPHRt46edkIQHgtJENNTWKDZW9OtVs9ez+ySIAbAMtbyhiCVO3ZGoA5GaxFAlifdQP8
Vx/mZs9DTlwn728wHZ/zzgPO8K5rO+rQgN9CIXNmnieq/FyVgM2aZfzGRn1BLBf3CNSxc4YnaCZN
/xlpXODTDsD778O7Yb6hGXhOI0ejvyqsObzlgOaLYvpViNDcEr5z/NyLZcDJN/BE3WAlcFlJlAIK
9uzDqeZx3q3SKgpxLAS0xG5XTbgm9Wgw5m9XeIuuEmWn55+mKTYC91gTxuH6QCZ0JG4+E/deq+dQ
taAOgk4bVTe4zrA8q3ITBLnTc1/AmdNPucqcsVPi8YASGeYjdTde0GfQhLLeFPBQDJ2jjxwpdeTY
dYd3dS7oxce4CbdsiXRK44OVXkvRZCDzpZ0e/T5V+C18daVUH/Y19ow8krE3afGlAcZM7MI++WQJ
zCoLh5/kJJLCSIUijlV+i/7bQQDXZlq4p2Hyhmz5CXNYuqbLS06rDncGo3xI2KA1MaJf5WCC4/Wg
SU3VBEBFbql5f+OgDWdjZqs3cwqfEurtxU5XmInLpR8fIYxnFZTVzUpqw3bFWfH890rCHhRc+aqd
zO4hB333ZI72MjSwiGoYi0hMXJHJD5aZpRMmaGTiETq2qvbhILDJrRlpggHk2jroPGPzFYqYO8c7
7CCVdVzzEqZFAMV7qSAnCJTd4hyJeWXdT3lnsgRW/+wAxGD85iISKsGHo+C7aLGsGv8x+uabq6vB
0SuXEXcF1YmB4md9Olymk/uanMJ13L39Xp8GadUHUZygWnpNzxmRNlXO4OeSLoZh/bExRRaW+IPO
KsikWzVuCS9ST2H7yTNZdE+I4ml+9K6kauP+qVbtjy6MNBeCCLXP3cuir236WQd8q4xWFRVUIb+l
CpuD4BjER6v0W/bu7QYmJd9YXIo3VvLFv4XFKXKX77YU2kyp738+zYPe/z11mQOjVRFOiFrr5SKX
C36RKcRmsCnESEnfYkcBCfa2I5ygSwkUBQgumEwIWpW6wB5s7opECTLLelqoTGl+aJOHa4hGvPpv
RYXe5NCDe5nYSjA4qSAqs7BK06FzeGoyAAGe8U8/lZud5+EQhuWLS0rVhauikIw78KEIuHMOCgSp
hmF3JH3dwRch6xqsmL9hWqXvOLG4JASnTx8LvqZAQKoZkKB7oL2ECxA7Sx1xocIMst5heTttnvVG
U8KQWNNUFVM81lKwDR19lECee0ycHjCXFm2qv14tvbRnwLErKDby5ex0wsgV8IXd3pHm9DGC3A8e
iOWgRmNgaFKpR6xb5qhbN6Y2UT7/hUNgH0klDqACoeYDr2i6lxEiEXD3p5RNLGHFhaEYpL0GpFMQ
ZlTqTNEFcZt2Np1kWEOKsxFeueldrQQFoQMnrYpFLpUMDjEE9TwZkrBqBsSdeRWKIS0umh29LrOb
8hHMlrFRux7QCl/qKwCTnZG1obGhzDijjIF90fHcKZw8b6C63vHj9S+1UxK0gcwG92XmLTevV6B9
aTnKvNYnWV0NYFzUWQJrj19npotcN8kbs03KvfR7ieM0ylsB5q/gZF+vsEvL8c5ezK5EErzuJuVo
XkWoCtLDNkOE5lsyGk3dTCsxk5d2h1pKxEJxwu0VYB1VR17ZeQT0g7nfuERodhNtL/TMTdW2qv8q
DWlFpjg6RNxxEPTWvNvK98XpgXcFSYGYeFC1kSk+2Nt5vKzl/6C8eHDDVHIN8Cz+iysH1LsrJTif
JFYSdvdTjhWKX8DsvFtX9jvMC55Rh2CXndZOiARvGR4tDR2/NaEK5qv2gC2qmPy=