<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoD7tmkX02Gil8vAADFi5QrPw+KIkdFq+RAu16H3SCUjlI7Mhnd2RBVCMlIC8Hvwjdfjzwx+
hAiw6s9wRtQIK9VtmDyXtTJ39LumYeNfjrGKvV3iL9XdDLGb5fGvWcQJMmjNk1rVC0wFtNiXIVG7
/lHCaSUp8vGFfGantOVrWl5qmoJ+ZKyfhLotbWa3kGfHcRPqskoH/0s2iihtSOR0PVtGcrp0hN20
RLMeh8ulFnok9WmHDMAN+c+RYBsrUpQn9fNSzJ+PedukJPKmH71Gvf9HS+jfCEPSHAw0bDxtqZeD
Z8SOSeyjVLCmUCciwHPYZ6ZbdNpf73K3vF72rvqB+9PO7vKlIff0hqoSiZizRz/w98K12SwggDac
Ihmbx/sj56H9NZf1qxernt5CKKr4zu+j+7LvQGgIgBS3pYKLc/MvMuiKOWsjKIXgQE9/k1Oxcc0E
CnGDofW04mpymohfOne7kbz7gzkJ6KnHpHtz3PN+028LYXmLqoC7gFJqrzO9zGTbjNdCmu+/Eegf
XhKB2nNLlQvjly5gOemsMsjHEDCBKbVYoKAd3e+11Fa7AdbtidlGMEGs14K39tHVZBOTBToo733M
ltt6PxNExuOliOdyYSCuGtJxDbRv60GO0CJDI4gheUUxb6OgpFscq0S4CZKH18UuDiVtBoTgL4d5
HZFK97Bt7VWwK35oFH4ti/JBqs0UP/zsCo/C3q8WPZNj8mbMXNr/+p4bRLxRwW2WY74iwlSQzFG5
xDKGu0qMuVXLyaj92TeJBo2ON/qQCaoKSidd5vslhaQAKiGMWqybRJMbY6DWgIp7kjmuRll11oTV
W1Fyc7sRBbsMFRbKiBzcakfE59KeiqQPPF15mXY2cPJHEfYHzi0ObUNY5AQ+5ESxBRZul7McmVr0
fd5nWnjYGuW1dsX+ROb052LYgCvVbkSSCjcfout6R4bQRESS5Xj5WiKBzzFNnNtCtlj616Uqswi7
C5bTfcPA6/jpY+yQ748ZA7zMOaMsMrnskkAGo1hRt80ozPgzjJApeF6jOV7+MSJ5kCbvtOnzBZeh
9GRimTUJeOzC0R+Ova6Hc8+RD6WfP1GhiqKM4oLPQ7c2UtUvfcKf1iU2CLZOZED0T9evl19hW83C
smEYG86Mp3kU0BmC5pyjaxlPeDEwRED22PJlQjMXyqN6NuLRsodcd532zxtBMuGSEZEOTWJdzqVJ
3Dj0kq70PphxvSQipTCqsjib5c4b518uZGvCDBbjggLh6NIHrNnLE2Z/sRx2YXVIZjg/lOn4RyNh
UtPMJFe/3dwjbBvgPvZ4Imy2PraGU4qvcLRvHBWtfaWvhttSBzQsAjHDtKuJLQTkEXWrCMGaZ/cz
Kx9AMSf36C44DpddEC6Hh1I6fao5BS30tGXX7C+5o2SfwjTMQ93zPOAOH7YLbqIWVYm0g8xZlIwO
H34Wa+DcexWrjiKwSiaXRiR2XWc6Nlu4pwjasUrQ9Bgorip/vt7NhrTanyMd2QoZZZiug8y1XAPc
b/xRf2PkSz+AaBISGLLIGvS6Y3dfK4cqBdPquVkJ00InCefBXjdhnTBd9gg9QEuLkNH23DmS4AAC
7GAUYSPxECCKOk7AdKWrmOKFrKeN0dpj09S2A2SJcK0MaLwqTeJpC2nKkOVTQk5DnkOdRrTQli0g
CoHPRKZbzWMdy5KMaRlNpTc44V2WokAEMulRqIJtJqb2hW2C5snSc7E5T1LzMyPDLRR6ZnswrxeI
a+f45PD0VeAtbkKi1erjY2OI+E44P8KhooXeioYJK9JBYY2ArmOg/iLDd/UeDa9pn2ZdXpCoWTKp
lIbOWJGcN+LSnRyn7HQQ+MLcPAijnCwndqvLDBu+UCIUfn+VkRPEL2VF+2epxnMmwy1KnrJIusjO
BEyKTxiugHsx0STbyAMpCOVkYqnA815kLu1jMlx87PE3qX4ptkn5N2QTg3XsGaen1YAbR4Yx7Wvp
xSc1VmjdQsRAixtvvkyuDRDTQMiiesRjPqPmxwNqkawJTYNLLgyC/ykE/sbRllmAwuGB8WTB0t5k
+quvCsCKM2i4S8nvXgfhOu7AStO7xGDZTIbc0iXInSznP1TIZiardA+x3P25gH1eMQg0DbeibRw+
/tFsOOXm7++CaEBMOwl3vkdGo7o4IL85EYGqDwk1Bpc9fUyhhRt3kIN0D0UqIkwJV418VjciR9Cs
+NfBZ4Hr+rI00b9okoGlDXGzlvi6D0t1Fed58PUSwUEnIynblex6wAAAOzn4RqfWQjTr1y4LU7IB
OrrC23Z2nKqfW7zp6qSQCltS/IypBW53zjh8eShFuzad/Brd5OINH9D16ZP8lBNY2khmtW3YQaG5
10RE1mr6bch9wunkPU3mNB5bHf6J/ZrU6IzYwn/ylL2PZKbuik54NZvXboPxSLBR7ltaxR/1FZ5i
N8kwvUN+EEvqoKmKQV8gCeFduhFsuHhyOUj7S5cycdXS5jsbv0dDxmIztgc8VepbKpYus4quAR8M
HL5YhKYVM/iJNKzJih126MGfqcT8M+VK7Q7E4zKPezC8q9/uuXClf1BYODdRiN7XFhDJ8nxZGvwC
VSMhahdYzmxJGdpln1VSoMpBRyFFgLE1KW9dSJ/Kp1F5Z+iZHDTTb8SfoYZtx1L/EDTJyphIe1NO
ws3pUmPgM0HB2nZZ+FiKZHdqp4ufS4mm5xYfLFsDHQy3ZTQsco1m9EtURTfwXe3DRuap8y37qJZB
oW5pwihsVlLBL4jvYD72FXJ/9AZuo6du1jhP2KvdueSuHcPNxAmqWAXzlS4XqT3PV4l9Bon8RlpP
9r3eSsI9YBUQRgoVgCvuvbs7+/hrCqEim/IyVXdkAmTRI/scmWgETMl+twtysvdO3NwiIfFYpFuv
N8DoCZIYkjCzgFtXf+6Qv6Oj5+RAHMzJz1UtIm6EKsVx98AdmdrUeQJHSVr2ZbvITy3v3YtD+5wn
ks4eqCmMEkpDEorlOJqDeDvHeepQpPbCLz4G2cxYfaKzFHxpPAxevFbOcakagjrlb6JtYv9L7FKi
qvZEsQ2ZXuEUsMl4wPZWcWZ0PqsvBGmE4zMEea7kwntq7gTX/b6OUOKaU21L1qv81HMM5BatTXAL
bOSd7ChBR/MdEg9pJEshkMBHRh8KBSfZSUWRhDxVLDjV+03dPTfdshGbP6m4+0ACsiO0eAKLUlqj
IaTweDzDxqPXWpU7zZ9jrTO4pKeb+c7RG7vPYTjn+5YTYiLmExeuuh/DgKcl2H5vXjEGruFAoOpc
K8Mc85RKDnnK4Soi2nA2ecFj99B45mJLmndwXtBUQ/jQDS7vwU46hiN5vv625oySYAMfUJhaNO2M
ZlJ7aVv4GFcxXvACA4BnMOTrcsV6OI8uKRJGBT/A7NNVhj4x+4a2pnm44zU4ROlZsfrc24MUaQRX
fTH0A/YCX+nBQaEHHCyfsdmBed0qFRm7Z5BW7i/RoetvoEmaMMHSNys5muQLH6p5FNi93euqMiwD
kBUEBsrHR6OIrZVy3zDhtBlhEgovkmAueP+pzpEWODp+fWMPk8Y0HGr1vMcWm/TT/I+UljCwJB2+
r9ocDHAbBbynjjJW+7DJTZ7IvfQuQNPPjlXLd6dXqeqnODwFlHZ+U0oti6gEiiMym+43X+HgJ8Im
A2STCmswOROOKiGfac2YPA52Z/q9UiJo4Hm9oU/wTSNi7BNVBDFLRNTbmL7rpxLZxEF2iLwMO5rM
fzlm3GTTuSKFAOlJ15q7JMMAAtqbrWTjbXkNo/8fxpbp4lZY4Lv+VoQuha2xkAPlluFiC9tIGqbU
NsHimb4MfxIR6sUqFcRAKD3yI0Eyf93owP01CIYzCx0efNwDn1MeZynQ86jv261PZUeGn4b4Sl5+
zYlxcL+eUD84zBvZQdxJ6CberzszWpVfFzrrczoQJYon0cZR9NIhdd0loiZv5YnxBlzHCN10XCDA
aY+VwXar3BA+2ek8okp4jnvIehgDH56gocp7IqBmPYE34tW8sk8BvBt5L3sUA87M0ooEfUQaqmqz
Rg2zyFZCSS2QY80RtU4K35PzToQroCFcsyXR0dGuCCI+8UHnB0Uj8I9rUCSrefkLalC/MI1v/87N
kg+rmfXdQhV47YPvKr1bmQqW2PT1wghmWcg4RYMw6Fq1U5TNCR6nr7JTJ5HlwHfFQhkLxzlO8wq5
OlPSpMUW5ytrOYhcmxuYp7ONJwmbfWPiMWL7aVz0qx9CEfcT5K9fFgj5VYEPQFe+gO8NSeig6IT7
rZs7udOVfeMgnilV8W==