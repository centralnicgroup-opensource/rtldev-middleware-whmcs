<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPusX5THfEkuRT6Y0znog+0Q5zVlMcbyrFjzesbPHU4+q9RBkgp04hdJDpRFw2dMAawy45uew
cNREQyDlM9/5WDZcd3q7M7+XSJHQpA+zzW0uNn9LsEbH7b/UYManM5NmJ24iLLhxVHyNj5PshcrC
UxRHqMPJLldAh1/h/Ka0OpsSZFshJutoLPDXKJjoGwU6etsKdh/yPnVhPKMZcdCIiUMokfKJDrAH
If29K6f+J3hmXm37+45aS1C5lW+kHD7bz95spsTH+xCgcTCY+fDMuxD//PB1Qz8r0n5eJ+GB9o/C
GK/8Pg4WJCS4rWzncyvWyjh24k0ZPnn7N6yzocwOo+/3tTj99ngBXLuxmQjF9jsXbHwK9yYfMFIm
dTOXZWtMVEF1dguEe3FOT9EC7Hup78e+HSw7QRgP5PQVdHPkPbfuHqoYhQ8mIlHsnIlTUeT5S7+1
QfYpjLOk8jJz2Qmo5weZc8iF34Piu1zj4thS+Pp49p3amTo19tsciDEB2QtW/K9w/J0tZ8Ra3brI
cfas5qM1PHfrLZKK4wMua1/dycsg+TpThCEIqijxQ/92ftcs6CuEk0oOthcfYQ5NArL0jCxaEBPC
zcJgMjw6SO6UrTYGIdIixQspsLi0CZ+Slg/VpPcZPDkr5BSM75UGpKCVrG1I9ujTW2gclrhoTdnq
wB6HJVJnhS2MVpZYU+q+wcshku55fn7N5xMrgX9EiASIFvW6eKRNNGE1f0rrnX949rwF1YlcYG99
V9OIzlbS1KiiFvAGU1kgDm5hJdGgm99Iq0rfrhLejjXk7Ktc5u3ss/eM8NbPQd5pR6gXt6Doazut
Pz8A1qgk5Ro37GEICepanl9I5OEwfUiRDNbY7ETF5eOGn4ODAH0os5lLS45IMv8+T/SDchPoj4D3
8heNc8+fxkvsQFUaVc/AMlpz0saAODaH7O/H2xOPk+znaMrxLF2cw6SFmsNpv7Ie5u2yMaUPf3ai
wTbchKXuF/mK30D9G4gl9N8BWoixZU1d80mC5gj4kbW3Affxm8HeqONYfRuhjcNYayteNQmwdHNa
g0bstgA4iKEpyzYKtsVPP7AF9EJfjOPzA5IuquEw8hNafceRG8iAhAyvdyO2C1zLfgrKdYrqa1NI
EkYHP/P3wJq7UoO6BrPEJtKwUla9jdnwSPLHubgWZydUPgpa/o7k+uNQD++nac1aZM9VIVDh/R+r
aNm20yQ4Phlqtt0XKSMWPShr5ghwuGUPLM544E4/+P3v0hCXd+sF2x7tyX4qx1FU+AkR/2tSZNVO
0JgwbKXneEopo6FCB353WW07I7cuRGqi3R8NM64PXAE0/H92a5jCY6vk87OMv8skKMKxGvvfQaeB
THS1Dp4VrByRQk3CAL0HTo+XqpgMYnl6QvOKlq7zpcv9nXCwN5ZsJdk2bahXNRMbO4TL5kdbq7BQ
2JkiqetRTb8aj8nCwte/JX4aOIJV+0pvUYwfAwUi452Src77MGehaVtHJPaM36P6W9XUQcxyO6TY
3LgpFLmw1DecawlqhwHmmfFQOdl+fBxqbRrR5t+08Pd+Wlzg85SlBTzzLkihcJjOHxuxAVMGMJ3/
b2VEd6qL6s9O2Xu8dtjFEWsySx6fCS/X0q7tE/eqhYp0v2ShjypWwpa8rr2URZGTrlxXkVcJX+Mz
VpUO1FIU8fBK64kw1biip5CjFjvV6+gqO1XuVAwIFHrqz72m8WIejF1hA2p7cSpdofz98UEmbT49
rkcah/5jyK+Vw8SiZKKK0xcnT9R7/f16qF9gz9jz0ggomHk26y8mrfp4/giGm0Cv3JIf2lbs9VUC
XxvnI/AfErozBHKDWL0OHFE8xAErVumruoyWvynY07rVb/vZxVG1rgd8fzDzztK7cpkG9g25KV81
n+Z8PEl8CQ+j5Hrj8FqY6iC7FWFNYQTM5z2N1jlHcv2uFPJMc0VNDyBUPpF7dYE5/k9PX7bXrDMT
ZPH6yxogfS5S/d3YOVmrgczkRO3imFrJK7Hc/CIS9mqoCaRBH0GmPK+EXvHXkwHXIRCaU7dPjweU
k+QjtPAJn5gtLbFNir6KNsm1Jjr9fX0sWrvJpXvZmo2YDCRRhAD+XaXOFpvHy9z5MWeUK0KAXc0P
ODTrX/jd8yYum8nVzGxwCzKSq1T4kFfSs0DVTPZeZMoUKKVEsn1unKE1YXK+qGlacNu6OywE8fAF
Ww1oOI40PqgAUrWzrhFhrq1JYWM7Tz/FusHgHOw78Z1LRue5+KRzPeJGQTggnyQNQVa0VXOBgjXh
R4rRjkDPAyj/en9V/YRvcMhAxSF4pYGlj5pv2MtVbE9bFgG7V0unWYEz09bHRILe4J1xRGrLxbu9
x/5EyJr7Ffw2Ji58yFU7C5wdTVMSrLryjt3BPlzY2emrUS3lQhuBovt/MYxfHDRH+5VgNxbhSUjx
7kXCklZe1DTjYoK9EVwXrDW6M9Rrmm7vf9Jo7bYHB5kCnwCDrpA2kj1e6b8ZIVEyJBs8+vaPWldb
G/tPXgWKdkiI/sBQEigwCiqwDTHgJj7IoDA76nffsgqOCTJILolFLbixqQtqCer9YcJOLlkIrp09
4DBCi7ZaZ1AoTumSf42Z6WmxPL7opuWcTvimn+NpCUQbL0WabUHZRuNtzvTXVO8/eZeNc4P0frA8
2NNnVAikpNAEXPbK9tpvQt43DKKj6MGlfTcjJkGRUXo0APYFOqYf88fVxaHdRXZUFhcQEVEzkb9m
50bIaSNMQa62fCTCnCzSmtYK88RIaFibwYUn6egHmdMc+wlGznGqbPVDiqMa6q4/FUd3oBNt7L6D
srtao95W5P1r3w/XyNNL9aeMLkNRwvJSyeXs/gxt+LzIjdMTWn2PGIN9RhwYuSuR5Ew08ohuMIQk
zQu3634c8Rd3QuEwvTm+Sta5pSvge+PDD7Hzc/j0Uq76Ne9eFpRaz8sHT7uEqnByNPM7J6Ru+cdn
i0uSqc1TVPMFX1NlN/mrwS2pKA/RD5fPzmpuFIcPhNTmgHEC+thvCKvWwfQqAKnglcpowtTreDl8
arhorUNfOQjmnVjU4XQ3O9Z3D8Ic5bV9kFYur3NevaVT1F7SHixi5iOEQt7nNLWxY8OqBd/ySynU
W8qKRNzNOmwxFf8gEOv2WgDbnQRndDzxCYlmdWCb3myoaXxbLVXp82dtg/vM9j9OjDuubbat3NzZ
iyMFw36/8nfUaBxirrnuCN90NvsvXhvY9PoYdE2PeMTnL7GkCG8f0oUpOp9G4o+5Ovlm+FM0D+wC
oBHfsu3KcFFeJ6xn5nH8qMrZuKum9+hD1963l3/HWc25XswcSxdKZU4PaLGZZIgRb73QnYk68KOP
+BJOOJKKvS+kN0IiV+7doLIE4zKu6gbaUEY782CXw/gtMBvISX85G8wWb7IT1VISS9baNTNqq/fL
i2SuHyn/RF/FEg8VAZITRCT9cIOMC2V/LbydiCkVR8TEj5DwpNcjH9dFJLzyKXEAs4UBwJTQGO9+
8siEEPa3qInheYg5f4N7XjKn608WCovuTUlvOuOk0nDNamwCzkGV7DU4XzDljLMymtEs+I066/zR
eyTySW2bxIbByGHtN6Rk6ELce4flKKffmJBeVUEYpe1AbjaLCDuVryEJwI+BPWwGEPu4XKFLVxQc
luSPCreoJOLD8ikcBp0Pj1tYF/cGRWeRfi6CT7LE9sL6xvTd9mmQSQEmSCo3o5VDFceJtmdQ6c5X
QJ+3R70mCofuucPPuhQjyigWCxkHMqN5xcEreRE10rj3sheELom3IEQdXcypxhEEEnZ5+6IZiPVb
OXTZZlPE24SAOfS3Lnvojloxa176Y06QU9Rwh+9xJw5qoW4TGAx/Q5bq8/CZLHKm3HWm69gE2/MI
ZsVYrRg+EFKLA8u3IQS0cCtk0FejMchoNulBxhGY/uPJj1ghSayagDss3awwLbP9vL5ysD3i/aUp
a07XH58AhdfzkP5BTn6H07HwXD9/4zr/sWOpRD5FDL4Iza3uoxmIaGPBZORu34kyJVr/Xvv2fczN
V4qeHiMvLzcSjcg/et7TDULGqPBtWVpmyHC2ueMyTjIRtLUK0nYFnZ0i9StvLMA4d7g3LCRLRlVg
7X23r8+Np7UkAWnKPW3jSoWpNkZoiffczGIm147u3lHau+nROgS/x6e69lNzY1I1sj2UyheRgBoy
Ryo1ZdrZGPlOkq1XY8a8uE9g3mYBbq0g2zrGIRlsVyazjFNICv1NfX+vFna=