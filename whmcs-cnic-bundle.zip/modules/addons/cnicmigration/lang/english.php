<?php

$_ADDONLANG = [
    "defaultErrorMsg" => "Domain Migration to the new subcontractor open. Don't renew the domain.",
    "defaultSuccessMsg" => "Domain Migration to the new subcontractor initiated. Don't renew the domain.",
    "defaultRenewMsg" => "Renewal processed. Domain Migration skipped as not activated for registrar.",
];
