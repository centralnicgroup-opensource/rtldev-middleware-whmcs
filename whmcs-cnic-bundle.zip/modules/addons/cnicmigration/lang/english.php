<?php

$_ADDONLANG = [
    "defaultErrorMsg" => "Domain Migration to the new subcontractor open. Don't renew the domain.",
    "defaultSuccessMsg" => "Domain Migration to the new subcontractor initiated. Don't renew the domain.",
    "defaultRenewMsg" => "Renewal processed. Domain Migration skipped as not activated for registrar.",
    "downloadEppSampleMsg" => "Click to download a sample .CSV file",
    "eppSingleBtn" => "Add a EPP Entry",
    "eppSingleBtnToolTipMsg" => "Use this button only if you want to add a single domain entry with an EPP code",
    "eppBulkBtn" => "Choose a <b>.CSV</b> file for Bulk Migration",
    "eppBulkBtnToolTipMsg" => "<em>Accepted CSV Format:</em><br />* Do not include any header row<br />* Comma separated Domain & EPP Code<br />* Column 1: Domain, Column 2: EPP code",
];
