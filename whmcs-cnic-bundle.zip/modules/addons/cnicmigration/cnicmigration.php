<?php

use WHMCS\Config\Setting;
use WHMCS\Module\Addon\cnicmigration\AdminDispatcher;
use WHMCS\Module\Addon\cnicmigration\DomainModel;
use WHMCS\Module\Addon\cnicmigration\Migrator;
use WHMCS\Module\Addon\cnicmigration\ServiceDispatcher;
use WHMCS\Module\Addon\cnicmigration\TldModel;
use WHMCS\Module\Addon\cnicmigration\LogModel;

require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]));

/**
 * Define addon module configuration parameters.
 *
 * Includes a number of required system fields including name, description,
 * author, language and version.
 *
 * Also allows you to define any configuration parameters that should be
 * presented to the user when activating and configuring the module. These
 * values are then made available in all module function calls.
 *
 * Examples of each and their possible configuration parameters are provided in
 * the fields parameter below.
 *
 * @return array<string, string|array|int|bool>
 */
function cnicmigration_config()
{
    return [
        "name" => "CNIC Migrator",
        "description" => "This Module allows for Domain Name Consolidation to Registrar Brands of the CentralNic Group PLC.",
        "author" => cnic_getLogoHTML(),
        "language" => "english",
        "version" => CNIC_VERSION,
        "fields" => [
            "sendMailsAdmin" => [
                "FriendlyName" => "Send mails to admins",
                "Type" => "yesno",
                "Default" => true
            ],
            "sendMailsClient" => [
                "FriendlyName" => "Send mails to clients",
                "Type" => "yesno",
                "Default" => false
            ],
            "logActivity" => [
                "FriendlyName" => "Log activity",
                "Type" => "yesno",
                "Default" => true
            ],
            "whmcsInstanceID" => [
                "FriendlyName" => "WHMCS Instance ID",
                "Type" => "text",
                "Size" => "8",
                "Description" => "Short ID for identifying this WHMCS instance in the logs",
                "Default" => "WHMCS"
            ],
            "renewIfExpired" => [
                "FriendlyName" => "Renew if expired",
                "Type" => "yesno",
                "Description" => "Renew domain at current registrar if already expired",
                "Default" => true
            ],
            "resellerLabel" => [
                "FriendlyName" => "Reseller name",
                "Type" => "text",
                "Size" => "32",
                "Description" => "",
                "Default" => Setting::getValue("companyname")
            ],
            "resellerContactURL" => [
                "FriendlyName" => "Reseller URL",
                "Type" => "text",
                "Size" => "32",
                "Description" => "",
                "Default" => Setting::getValue("domain")
            ],
            "resellerContactEmail" => [
                "FriendlyName" => "Reseller email",
                "Type" => "text",
                "Size" => "32",
                "Description" => "",
                "Default" => Setting::getValue("email")
            ],
        ]
    ];
}

/**
 * Upgrade.
 *
 * Called the first time the module is accessed following an update.
 * Use this function to perform any required database and schema modifications.
 *
 * This function is optional.
 *
 * @see https://laravel.com/docs/5.2/migrations
 *
 * @return void
 */
/*function cnicmigration_upgrade($vars)
{
    $currentlyInstalledVersion = $vars["version"];
    // do something, no return
}*/

/**
 * @return array<string, string>
 */
function cnicmigration_activate(): array
{
    $result = TldModel::createTableIfNotExists();
    if ($result["status"] === "error") {
        return $result;
    }
    $result = LogModel::createTableIfNotExists();
    if ($result["status"] === "error") {
        return $result;
    }
    $result = DomainModel::createTableIfNotExists();
    if ($result["status"] === "error") {
        return $result;
    }
    return ['status' => 'success', 'description' => ''];
}

/**
 *
 */
function cnicmigration_deactivate(): void
{
    TldModel::dropIfExists();
    LogModel::dropIfExists();
    DomainModel::dropIfExists();
    Migrator::cleanupMailTemplates();
}

/**
 * Admin Area Output.
 *
 * @param array<string, mixed> $vars
 * @return void
 * @throws SmartyException
 * @see AddonModule\Admin\Controller::index()
 */
function cnicmigration_output(array $vars): void
{
    if ($_REQUEST["page"] === 'service') {
        $dispatcher = new ServiceDispatcher();
        $dispatcher->dispatch($_REQUEST["action"]);
        exit;
    }

    //init smarty and call admin dispatcher
    $smarty = new \WHMCS\Smarty();
    $smarty->setCompileDir($GLOBALS["templates_compiledir"]);
    $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "cnicmigration"));

    //populate smarty variables. eg: WEB_ROOT
    global $aInt;
    $aInt->populateStandardAdminSmartyVariables();
    $smarty->assign($aInt->templatevars);
    $smarty->assign($vars);
    //call the dispatcher with action and data
    $dispatcher = new AdminDispatcher();
    http_response_code(200); // TODO this is temporary - sometimes we get 500 and no idea why
    $action = $_REQUEST["action"] ?? "index";
    $dispatcher->dispatch($action, $vars, $smarty);
}
