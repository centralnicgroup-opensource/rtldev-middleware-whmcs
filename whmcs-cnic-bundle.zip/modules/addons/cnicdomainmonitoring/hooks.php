<?php

add_hook('AdminAreaHeadOutput', 1, function ($vars) {
    return <<<HTML
    <style>a#Menu-Addons-CNIC\ Domain\ Monitoring {text-overflow: clip;}</style>
    HTML;
});
