<?php

/**
 * WHMCS Domain Monitoring Addon Module
 *
 * This Addon allows to syncronise existing Domains from any CentralNic Brand's System.
 *
 * @see [link]
 *
 * @copyright Copyright (c) Team Internet Group PLC, 2023
 * @license https://github.com/centralnic-reseller/LICENSE/ MIT License
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Module\Addon\CnicDomainMonitoring\Admin\Dispatcher;

require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]));

use Illuminate\Database\Capsule\Manager as DB;

/**
 * Define addon module configuration parameters.
 *
 * Includes a number of required system fields including name, description,
 * author, language and version.
 *
 * Also allows you to define any configuration parameters that should be
 * presented to the user when activating and configuring the module. These
 * values are then made available in all module function calls.
 *
 * Examples of each and their possible configuration parameters are provided in
 * the fields parameter below.
 *
 * @return array
 */
function cnicdomainmonitoring_config()
{
    return [
        // Display name for your module
        "name" => "CNIC Domain Monitoring",
        // Description displayed within the admin interface
        "description" => "Syncs Premium Status and Applies Domain Pricing Updates.",
        // Module author name
        "author" => cnic_getLogoHTML(),
        // Default language
        "language" => "english",
        // Version number
        "version" => CNIC_VERSION,
        // fields
        "fields" => []
    ];
}

/**
 * Admin Area Output.
 *
 * @see CnicDomainMonitoring\Admin\Controller::index()
 *
 * @param array $vars
 * @return string
 */
function cnicdomainmonitoring_output($vars)
{
    //init smarty and call admin dispatcher
    $smarty = new \WHMCS\Smarty();
    $smarty->escape_html = true;
    $smarty->caching = false;
    $smarty->setCompileDir($GLOBALS['templates_compiledir']);
    $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "cnicdomainmonitoring"));
    $smarty->assign($vars);
    //call the dispatcher with action and data
    $dispatcher = new Dispatcher();
    $r = $dispatcher->dispatch($_REQUEST['action'], $vars, $smarty);
    if ($_REQUEST['action']) {
        //send json response headers
        header('Cache-Control: no-cache, must-revalidate'); // HTTP/1.1
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Content-type: application/json; charset=utf-8');
        //do not echo as this would add template html code around!
        // WORKAROUND: we get 500 when error_reporting is set to E_ALL
        // ADDED BY: asif-nawaz 08-08-2023
        http_response_code(200);
        die(json_encode($r));
    }
    echo $r;
}

/**
 * Create table if not exist when activating addon
 *
 * @return array success/failure message
 */
function cnicdomainmonitoring_activate()
{
    try {
        // Create table and import default categories
        if (!DB::schema()->hasTable('cnic_domainmonitoring')) {
            DB::schema()->create('cnic_domainmonitoring', function ($table) {
                $table->id();
                $table->integer('domainId');
                $table->integer('todoId');
                $table->string('type', 64);
                $table->charset = 'utf8mb3';
                $table->collation = 'utf8mb3_unicode_ci';

                // Define the foreign key constraint
                $table->foreign('domainId')->references('id')->on('tbldomains')->onDelete('cascade');
                $table->foreign('todoId')->references('id')->on('tbltodolist')->onDelete('cascade');

                // Add a unique constraint
                $table->unique(['domainId', 'todoId', 'type']);
            });
        }
        return [
            'status' => 'success',
            'description' => 'CNIC Domain Monitoring Addon has been activated successfully.',
        ];
    } catch (\Exception $e) {
        return [
            'status' => "error",
            'description' => 'Unable to create cnic_domainmonitoring: ' . $e->getMessage(),
        ];
    }
}
