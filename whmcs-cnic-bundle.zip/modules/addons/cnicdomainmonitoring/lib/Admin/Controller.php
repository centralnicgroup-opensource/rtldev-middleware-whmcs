<?php

namespace WHMCS\Module\Addon\CnicDomainMonitoring\Admin;

use Illuminate\Database\Capsule\Manager as DB;

/**
 * Admin Area Controller
 */
class Controller
{
    /**
     * Index action.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return string page content
     */
    public function index($vars, $smarty)
    {
        add_hook('AdminAreaHeadOutput', 1, function () use ($vars) {
            $jsPath = cnic_getAssetPath("js", "cnicdomainmonitoring");
            $version = CNIC_VERSION;
            return <<<HTML
            <!-- Include DataTables Bootstrap JS file -->
            <script type="text/javascript">
                const addonModuleLink = "{$vars["modulelink"]}";
            </script>
            <script type="text/javascript" src="{$jsPath}/index.js?v={$version}"></script>
            HTML;
        });

        $issues = DB::table('cnic_domainmonitoring')
            ->join('tbldomains', 'cnic_domainmonitoring.domainId', '=', 'tbldomains.id')
            ->join('tbltodolist', 'cnic_domainmonitoring.todoId', '=', 'tbltodolist.id')
            ->select('cnic_domainmonitoring.*', 'tbldomains.domain as domainName', 'tbldomains.registrar as domainRegistrar', 'tbltodolist.title as todoTitle', 'tbltodolist.description as todoDesc', 'tbltodolist.status as status')
            ->get();
        $smarty->assign("issues", $issues);
        $smarty->assign("modulelink", $vars['modulelink']);
        $smarty->debugging = true;
        $smarty->escape_html = false;
        return $smarty->fetch('index.tpl');
    }

    public function fetchPrice($vars, $smarty)
    {
        $domain = DB::table('cnic_domainmonitoring')
            ->join('tbldomains', 'cnic_domainmonitoring.domainId', '=', 'tbldomains.id')
            ->where('cnic_domainmonitoring.id', '=', $_GET["id"])
            ->select('tbldomains.domain as name', 'tbldomains.registrar as registrar', 'tbldomains.id as id')
            ->get();
        $domain = cnic_objectToArray($domain)[0];
        $additionalFieldsFn = $domain["registrar"] . "_CheckAvailability";
        $registrar = new \WHMCS\Module\Registrar();
        if (
            !$registrar->load($domain["registrar"])
            || !is_callable($additionalFieldsFn)
        ) {
            return ["error" => "Required registrar module is not active: " . $domain["registrar"]];
        }

        $params = $registrar->getSettings();

        $params["premiumEnabled"] = true;
        $params["domains"][0] = $domain["name"];
        $domain = $additionalFieldsFn($params)[0];
        if (isset($domain->errorMissingCurrency)) {
            return ["success" => false, "message" => "Oops! It seems like the <strong>" . $domain->errorMissingCurrency . " currency</strong> is missing from WHMCS. In order to update domain pricing, it's important to have it available.<br /><br />Please make sure to <strong>add the " . $domain->errorMissingCurrency . " currency</strong> to your WHMCS system."];
        }
        if (!empty($domain)) {
            $price = [];
            $domainArray = $domain->toArray();
            if ($domainArray["isPremium"]) {
                if (isset($domainArray["premiumCostPricing"]["renew"])) {
                    $price["renew"] = $domainArray["premiumCostPricing"]["renew"];
                }
                if (isset($domainArray["premiumCostPricing"]["transfer"])) {
                    $price["transfer"] = $domainArray["premiumCostPricing"]["transfer"];
                }
                if (isset($price["renew"]) || isset($price["transfer"])) {
                    $price["currency"] = $domainArray["premiumCostPricing"]["CurrencyCode"];
                }
            }
            return $price;
        }
        return ["success" => false, "message" => "Looks like premium pricing is not available or temporary API connectivity issue!"];
    }

    public function updatePrice($vars, $smarty)
    {
        $success = false;
        $domain = $_POST["domainName"];
        $domainId = $_POST["domainId"];
        $domainRegistrar = $_POST["domainRegistrar"];
        $todoId = $_POST["todoId"];
        $renewPrice = $_POST["renewPrice"];
        $transferPrice = $_POST["transferPrice"];
        $currency = $_POST["currency"];
        if (!empty($renewPrice) && !empty($transferPrice) && !empty($domain)) {
            // check if registrar currency is supported
            $currencyid = DB::table("tblcurrencies")->where("code", "=", $currency)->value("id");
            if (is_null($currencyid)) {
                return ["success" => false, "message" => "Oops! It seems like the <strong>" . $currency . " currency</strong> is missing from WHMCS. In order to update domain pricing, it's important to have it available.<br /><br />Please make sure to <strong>add the " . $domain . " currency</strong> to your WHMCS system."];
            }
            // use whmcs search result for price calculation
            list($sld, $tld) = explode(".", $domain, 2);
            $success = self::updOrAddDomainExtraBulk($domainId, [
                "registrarCurrency" => $currencyid,
                "registrarCostPrice" => $transferPrice,
                "registrarRenewalCostPrice" => $renewPrice
            ]);
            if ($success) {
                /* // registrarRenewalCostPrice + configured Markup + Domain Addon Prices
                $recurringamount = $renewPrice;
                $hookReturns = run_hook("PremiumPriceRecalculationOverride", [
                    "domainName" => $domain,
                    "tld" => $tld,
                    "sld" => $sld,
                    "renew" => $recurringamount // without markup!
                ]);
                $domainObj = DB::table("tbldomains")->where("id", $domainId)->first();
                $domainObj = cnic_objectToArray($domainObj);
                $userCurrency = getCurrency($domainObj["userid"]);
                $recurringamount = convertCurrency($recurringamount, $currencyid, $userCurrency["id"]);
                $skipMarkup = false;
                foreach ($hookReturns as $hookReturn) {
                    if (array_key_exists("renew", $hookReturn)) {
                        $recurringamount = $hookReturn["renew"];
                    }
                    if (
                        array_key_exists("skipMarkup", $hookReturn)
                        && $hookReturn["skipMarkup"] === true
                    ) {
                        $skipMarkup = true;
                    }
                }
                if (!$skipMarkup) {
                    $recurringamount *= 1 + \WHMCS\Domains\Pricing\Premium::markupForCost($recurringamount) / 100;
                }
                $pricing = DB::table("tblpricing")
                    ->where("type", "=", "domainaddons")
                    ->where("currency", "=", $currencyid)
                    ->where("relid", "=", 0) // domainaddons
                    ->first();
                $pricing = cnic_objectToArray($pricing);
                if ($domainObj["dnsmanagement"]) {
                    $recurringamount += $pricing["msetupfee"];
                }
                if ($domainObj["emailforwarding"]) {
                    $recurringamount += $pricing["qsetupfee"];
                }
                if ($domainObj["idprotection"]) {
                    $recurringamount += $pricing["ssetupfee"];
                } */
                DB::table("tbldomains")->where("id", $domainId)->update([
                    "is_premium" => 1,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
                DB::table("tbltodolist")->where("id", $todoId)->update(["status" => "Completed", "admin" => \WHMCS\Session::get("adminid")]);
                cnic_track(["custom" => "{$domain}: Domain pricing and status updated using CNIC Domain Monitoring Addon.", "registrar" => $domainRegistrar]);
                return ["success" => true, "message" => "Domain Status and Pricing Updated Successfully"];
            }
        }
        return ["success" => false, "message" => "Oops! something went wrong."];
    }

    public function deleteRecord($vars, $smarty)
    {
        $id = $_POST["id"];
        if (!empty($id)) {
                DB::table("tbltodolist")->where("id", $id)->delete();
                return ["success" => true, "message" => "Domain Status and Pricing Updated Successfully"];
        }
        return ["success" => false, "message" => "Oops! something went wrong."];
    }

    /**
     * bulk update or add domain extra data for given domain
     * @static
     * @param int $domainid id of the domain
     * @param array $arr associative array (field name => field value)
     * @return bool
     */
    protected static function updOrAddDomainExtraBulk($domainid, $arr)
    {
        $success = false;
        foreach ($arr as $name => $value) {
            $success = self::updOrAddDomainExtra($domainid, $name, $value);
            if (!$success) {
                break;
            }
        }
        return $success;
    }

    /**
     * update or add domain extra data for given domain
     * @static
     * @param int $domainid id of the domain
     * @param String $name name of the extra data field
     * @param mixed $value value of the extra data field
     * @return bool
     */
    protected static function updOrAddDomainExtra($domainid, $name, $value)
    {
        $extraDetails = \WHMCS\Domain\Extra::firstOrNew([
            "domain_id" => $domainid,
            "name" => $name
        ]);
        $extraDetails->value = $value;
        return $extraDetails->save();
    }
}
