<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - Italian
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Aggiungi Record";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "Annulla Modifiche";
// Save Changes
$_ADDONLANG["saveChanges"] = "Salva Modifiche";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Tipo";
// Priority
$_ADDONLANG["priority"] = "Priorità";
// Address
$_ADDONLANG["address"] = "Indirizzo";
// Hostname
$_ADDONLANG["hostname"] = "Nome Host";
// MX Description
$_ADDONLANG["mxdesc"] = "* Record di Priorità solo per MX e SRV";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "Ci sono modifiche in sospeso ai tuoi record DNS. Controlla e salva le modifiche.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "Nessun record DNS trovato.";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "Questa zona non è attiva perché il tuo dominio non ha i nameserver corretti configurati.<br>Imposta i tuoi nameserver su: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "Gestione DNSSEC per Zona DNS";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "Visualizza Record DNSSEC";
// Oops Error
$_ADDONLANG["oopsError"] = "Ops! Si è verificato un errore.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Processo di Firma in SOSPESO";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC NON È ATTIVO</b>";
// Auto Activate Button
$_ADDONLANG["autoActivateBtn"] = "Importa automaticamente i record DNSSEC e attiva DNSSEC per il tuo dominio";
// Auto Update Button
$_ADDONLANG["autoUpdateBtn"] = "Aggiorna automaticamente i record DNSSEC per il tuo dominio";
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC è <span class="font-weight-bold">attivo</span> sulla tua zona DNS.
            </strong>
            <div class="text-info mb-2">
                Tuttavia, i record DNSSEC sul tuo dominio potrebbero non corrispondere a quelli nella tua zona DNS.
            </div>
            <div class="text-muted mb-2">
                <em>Suggerimento:</em> Puoi gestire DNSSEC nella sezione 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>Gestione DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                Le modifiche DNSSEC potrebbero richiedere fino a <b>24-48 ore</b> per propagarsi su Internet a causa dei ritardi di propagazione DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Ottime notizie! DNSSEC è completamente attivo e protetto per il tuo dominio.
            </strong>
            <div class="text-success mb-2">
                I record DNSSEC nella tua zona DNS e sul tuo dominio sono firmati e corrispondenti.
            </div>
            <div class="text-info mb-2">
                Non sono necessarie ulteriori azioni.
            </div>
            <div class="text-muted">
                <em>Suggerimento:</em> Puoi 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>visualizzare e gestire i tuoi record DNSSEC</u>
                </a> in qualsiasi momento nella sezione Gestione DNSSEC.
                Le modifiche DNSSEC potrebbero richiedere fino a <b>24-48 ore</b> per propagarsi su Internet a causa dei ritardi di propagazione DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC è attivo sulla tua zona DNS e la tua richiesta di attivazione è stata ricevuta.
            </strong>
            <div class="text-success mb-2">
                I record DNSSEC nella tua zona DNS sono ora sincronizzati con il tuo dominio.
            </div>
            <div class="text-info mb-2">
                Non sono necessarie ulteriori azioni al momento, ma puoi aggiornare manualmente i record se necessario.
            </div>
            <div class="text-muted mb-2">
                <em>Suggerimento:</em> Gestisci le tue impostazioni DNSSEC nella sezione 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>Gestione DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                Le modifiche DNSSEC potrebbero richiedere fino a <b>24-48 ore</b> per propagarsi su Internet a causa dei ritardi di propagazione DNS.
            </div>
        </div>
    </div>
';
