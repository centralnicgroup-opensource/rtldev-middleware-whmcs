<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - Italian
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Aggiungi Record";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "Annulla modifiche";
// Save Changes
$_ADDONLANG["saveChanges"] = "Salva modifiche";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Tipo";
// Priority
$_ADDONLANG["priority"] = "Priorità";
// Address
$_ADDONLANG["address"] = "Indirizzo";
// Hostname
$_ADDONLANG["hostname"] = "Nome Host";
// MX Description
$_ADDONLANG["mxdesc"] = "* Record di Priorità solo per MX e SRV";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "Ci sono modifiche in sospeso ai tuoi record DNS. Controlla e salva le modifiche.";
// Pending Delete Banner
$_ADDONLANG["pendingDeleteStatus"] = "Contrassegnato per l'eliminazione";
$_ADDONLANG["pendingDeleteHint"] = "Fai clic su <strong>Annulla modifiche</strong> per annullare l'eliminazione.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "Nessun record DNS trovato.";
// Add Record Form
$_ADDONLANG["addRecordNameLabel"] = "Nome";
$_ADDONLANG["addRecordContentLabel"] = "Contenuto";
$_ADDONLANG["addRecordCancelBtn"] = "Annulla";
$_ADDONLANG["addRecordSaveBtn"] = "Salva";
// Add Record Validation
$_ADDONLANG["hostRequired"] = "Il nome host è obbligatorio.";
$_ADDONLANG["addressRequired"] = "L'indirizzo è obbligatorio.";
// Copy to Clipboard
$_ADDONLANG["copyAddress"] = "Copia negli appunti";
$_ADDONLANG["copiedToClipboard"] = "Copiato";
// Zone Import / Export Controls
$_ADDONLANG["searchDnsRecordsPlaceholder"] = "Cerca record DNS";
$_ADDONLANG["importAndExportBtn"] = "Importa ed esporta";
$_ADDONLANG["addRecordBtn"] = "Aggiungi record";
$_ADDONLANG["importDnsRecordsTitle"] = "Importa record DNS";
$_ADDONLANG["importDnsRecordsDesc"] = "Carica un file di zona per importare i record DNS";
$_ADDONLANG["importWarningLabel"] = "Importante:";
$_ADDONLANG["importWarningText"] = "L'importazione di un file di zona sostituirà tutti i record DNS esistenti. Esporta prima i tuoi record attuali se desideri conservare un backup.";
$_ADDONLANG["selectFileOrDragText"] = "Seleziona un file o trascinalo qui";
$_ADDONLANG["browseFilesBtn"] = "Sfoglia file";
$_ADDONLANG["applyImportedRecordsBtn"] = "Applica record importati";
$_ADDONLANG["exportDnsRecordsTitle"] = "Esporta record DNS";
$_ADDONLANG["exportDnsRecordsDesc"] = "Scarica tutti i record DNS come file di zona in formato standard";
$_ADDONLANG["exportInfoText"] = "Il file esportato conterrà tutti i record DNS nel formato file di zona BIND";
$_ADDONLANG["exportZoneFileBtn"] = "Esporta file di zona";
$_ADDONLANG["closeBtn"] = "Chiudi";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "Questa zona non è attiva perché il tuo dominio non utilizza i nameserver corretti.<br>Imposta i nameserver su: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "Gestione DNSSEC per Zona DNS";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "Visualizza Record DNSSEC";
// Oops Error
$_ADDONLANG["oopsError"] = "Ops! Si è verificato un errore.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Processo di Firma in SOSPESO";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC NON È ATTIVO</b>";
// Auto Activate Button — invia i record DS dalla zona DNS firmata al dominio
$_ADDONLANG["autoActivateBtn"] = "Invia Record DS al Dominio";
// Auto Update Button — aggiorna i record DS del dominio dopo un rollover KSK
$_ADDONLANG["autoUpdateBtn"] = "Aggiorna Record DS sul Dominio";
// DNSSEC Sign Zone Button (replaces generic "Enable")
$_ADDONLANG["dnssecSignZoneBtn"] = "Firma la Zona DNS &amp; Genera Chiavi ZSK/KSK";
// DNSSEC keys table column headers
$_ADDONLANG["dnssecKeyType"] = "Tipo";
$_ADDONLANG["dnssecKeyStatus"] = "Stato";
$_ADDONLANG["dnssecDsRecord"] = "Record DS (SHA-256)";
$_ADDONLANG["dnssecAction"] = "Azione";
// KSK rollover action buttons
$_ADDONLANG["dnssecRolloverKskBtn"] = "Rollover KSK";
$_ADDONLANG["dnssecRolloverKskTooltip"] = "Avvia un rollover KSK. Verrà generata una nuova chiave KSK. Sarà poi necessario inviare il nuovo record DS alla zona padre e completare il rollover. Consigliato ogni 1-2 anni.";
$_ADDONLANG["dnssecFinishRolloverBtn"] = "Completa Rollover";
$_ADDONLANG["dnssecZskAutomatic"] = "Automatico";
// DNSSEC keys table labels & tooltips
$_ADDONLANG["dnssecKeysTitle"] = "Chiavi DNSSEC";
$_ADDONLANG["dnssecKeysCountLabel"] = "chiavi";
$_ADDONLANG["dnssecCopyTooltip"] = "Copia negli appunti";
$_ADDONLANG["dnssecZskAutoTooltip"] = "La ZSK viene rinnovata automaticamente dalla piattaforma";
$_ADDONLANG["dnssecSignZoneTooltip"] = "Firma la tua zona DNS e genera le chiavi ZSK/KSK. I record DS saranno quindi disponibili per l'attivazione a livello di registrar. Può richiedere fino a 48 ore.";
$_ADDONLANG["dnssecDisableTooltip"] = "Rimuove la firma crittografica dalla tua zona DNS. La protezione DNSSEC verrà disattivata.";
// DNSSEC per-key status badges and descriptions (mirror the CNR control panel)
$_ADDONLANG["dnssecStatusPending"] = "IN ATTESA";
$_ADDONLANG["dnssecStatusReady"] = "PRONTO";
$_ADDONLANG["dnssecStatusActive"] = "ATTIVO";
$_ADDONLANG["dnssecDescPending"] = "In attesa della propagazione DNS (conferma in sospeso).";
$_ADDONLANG["dnssecDescActivating"] = "Attivazione della chiave in corso.";
$_ADDONLANG["dnssecDescConfigured"] = "DNSSEC configurato correttamente.";
// DNSSEC: info panel shown when the zone is not yet signed
$_ADDONLANG["dnssecNotSignedInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>La tua zona DNS è in grado di utilizzare DNSSEC.</strong>
            <p class="mb-1 mt-1">Cliccando su <em>Firma la Zona DNS &amp; Genera Chiavi ZSK/KSK</em> verrà eseguito quanto segue:</p>
            <ul class="mb-2 pl-3">
                <li>Firma crittografica della tua zona DNS</li>
                <li>Generazione automatica di una <b>ZSK</b> (Zone Signing Key) e una <b>KSK</b> (Key Signing Key)</li>
                <li>Produzione di <b>record DS</b> che verranno poi pubblicati a livello di registrar per completare l\'attivazione DNSSEC</li>
            </ul>
            <div class="text-muted small">
                <i class="fas fa-clock mr-1"></i> Questo processo può richiedere fino a <b>48 ore</b>.
                Una volta firmati, i record DS verranno automaticamente importati nelle impostazioni DNSSEC del tuo dominio.
            </div>
        </div>
    </div>
';
// DNSSEC: info panel shown when signing is in progress (pending)
$_ADDONLANG["dnssecPendingInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-hourglass-half text-warning mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>Il processo di firma della zona è stato avviato.</strong>
            <p class="mb-1 mt-1">Le chiavi ZSK/KSK sono in fase di generazione. Questo può richiedere fino a <b>48 ore</b>.</p>
            <div class="text-muted small">
                Una volta completata la firma, i record DS appariranno qui e potranno essere pubblicati a livello di registrar.
                Non sono necessarie ulteriori azioni al momento.
            </div>
        </div>
    </div>
';
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC è <span class="font-weight-bold">attivo</span> sulla tua zona DNS.
            </strong>
            <div class="text-info mb-2">
                Tuttavia, i record DNSSEC sul tuo dominio potrebbero non corrispondere a quelli nella tua zona DNS.
            </div>
            <div class="text-muted mb-2">
                <em>Suggerimento:</em> Puoi gestire DNSSEC nella sezione 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>Gestione DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                Le modifiche DNSSEC potrebbero richiedere fino a <b>24-48 ore</b> per propagarsi su Internet a causa dei ritardi di propagazione DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Ottime notizie! DNSSEC è completamente attivo e protetto per il tuo dominio.
            </strong>
            <div class="text-success mb-2">
                I record DNSSEC nella tua zona DNS e sul tuo dominio sono firmati e corrispondenti.
            </div>
            <div class="text-info mb-2">
                Non sono necessarie ulteriori azioni.
            </div>
            <div class="text-muted">
                <em>Suggerimento:</em> Puoi 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>visualizzare e gestire i tuoi record DNSSEC</u>
                </a> in qualsiasi momento nella sezione Gestione DNSSEC.
                Le modifiche DNSSEC potrebbero richiedere fino a <b>24-48 ore</b> per propagarsi su Internet a causa dei ritardi di propagazione DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC è attivo sulla tua zona DNS e la tua richiesta di attivazione è stata ricevuta.
            </strong>
            <div class="text-success mb-2">
                I record DNSSEC nella tua zona DNS sono ora sincronizzati con il tuo dominio.
            </div>
            <div class="text-info mb-2">
                Non sono necessarie ulteriori azioni al momento, ma puoi aggiornare manualmente i record se necessario.
            </div>
            <div class="text-muted mb-2">
                <em>Suggerimento:</em> Gestisci le tue impostazioni DNSSEC nella sezione 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>Gestione DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                Le modifiche DNSSEC potrebbero richiedere fino a <b>24-48 ore</b> per propagarsi su Internet a causa dei ritardi di propagazione DNS.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingTitle"] = "Inoltro Web";
$_ADDONLANG["webForwardingDescription"] = "Gestisci l'inoltro URL e Frame per ";
$_ADDONLANG["webForwardingProcessingMessage"] = "Elaborazione in corso...";
$_ADDONLANG["webForwardingAddNew"] = "Aggiungi nuovo inoltro web";
$_ADDONLANG["webForwardingUrlType"] = "Reindirizzamento URL";
$_ADDONLANG["webForwardingTrdType"] = "Reindirizzamento Temporaneo";
$_ADDONLANG["webForwardingFrameType"] = "Frame URL";
$_ADDONLANG["webForwardingTargetHelp"] = "Inserisci l'URL completo incluso http:// o https://";
$_ADDONLANG["webForwardingUrlDescription"] = "Reindirizza all'URL di destinazione (visibile nella barra degli indirizzi)";
$_ADDONLANG["webForwardingTrdDescription"] = "Reindirizzamento temporaneo (HTTP 302) - utile per spostamenti temporanei";
$_ADDONLANG["webForwardingFrameDescription"] = "Mostra l'URL di destinazione in un frame (nasconde la destinazione nella barra degli indirizzi)";
$_ADDONLANG["webForwardingSaveButton"] = "Salva Inoltro Web";
$_ADDONLANG["webForwardingCancelButton"] = "Annulla";
$_ADDONLANG["webForwardingGetStarted"] = "Crea la tua prima regola di inoltro web per reindirizzare o mostrare in frame il tuo dominio.";
$_ADDONLANG["webForwardingSource"] = "Origine";
$_ADDONLANG["webForwardingTargetLabel"] = "Destinazione";
$_ADDONLANG["webForwardingEdit"] = "Modifica";
$_ADDONLANG["webForwardingDelete"] = "Elimina";
$_ADDONLANG["webForwardingVisitorsSeeUrl"] = "I visitatori vedranno";
$_ADDONLANG["webForwardingInBrowser"] = "nel loro browser";
$_ADDONLANG["webForwardingDomainVisible"] = "Il tuo dominio rimane visibile mentre viene mostrato il contenuto dalla destinazione";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "Nessun inoltro web configurato";
$_ADDONLANG["webForwardingCreateButton"] = "Crea inoltro web";
$_ADDONLANG["webForwardingDeleteConfirm"] = "Conferma eliminazione";
$_ADDONLANG["webForwardingSourceHostname"] = "Hostname di origine";
$_ADDONLANG["webForwardingTargetUrl"] = "URL di destinazione";
$_ADDONLANG["webForwardingStep1"] = "Passo 1: Scegli il tipo di inoltro";
$_ADDONLANG["webForwardingStep2"] = "Passo 2: Configura l'inoltro";
$_ADDONLANG["webForwardingExampleLabel"] = "Esempio:";
$_ADDONLANG["webForwardingAllowsPaths"] = "Consente percorsi • HTTP 301";
$_ADDONLANG["webForwardingNoPaths302"] = "Nessun percorso • HTTP 302";
$_ADDONLANG["webForwardingNoPathsKeepsDomain"] = "Nessun percorso • Mantiene visibile il dominio";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ oppure www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.esempio.com/percorso";
$_ADDONLANG["webForwardingRootDomainInfo"] = "Usa @ per il dominio principale o inserisci un sottodominio valido";
$_ADDONLANG["webForwardingUrlValidation"] = "Inserisci un URL valido (http:// o https://)";
$_ADDONLANG["webForwardingTemporaryRedirectInfo"] = "Reindirizzamento temporaneo (HTTP 302) - utile per test o spostamenti brevi";
$_ADDONLANG["webForwardingFrameInfo"] = "Mostra l'URL di destinazione in un frame (il tuo dominio resta nella barra degli indirizzi)";
