<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - Arabic
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "إضافة سجل";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "إلغاء التغييرات";
// Save Changes
$_ADDONLANG["saveChanges"] = "حفظ التغييرات";
// TTL
$_ADDONLANG["ttl"] = "مدة الصلاحية";
// Type
$_ADDONLANG["type"] = "النوع";
// Priority
$_ADDONLANG["priority"] = "الأولوية";
// Address
$_ADDONLANG["address"] = "العنوان";
// Hostname
$_ADDONLANG["hostname"] = "اسم المضيف";
// MX Description
$_ADDONLANG["mxdesc"] = "* سجل الأولوية لـ MX و SRV فقط";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "هناك تغييرات معلقة في سجلات DNS الخاصة بك. يرجى مراجعة وحفظ التغييرات.";
// Pending Delete Banner
$_ADDONLANG["pendingDeleteStatus"] = "تم وضع علامة للحذف";
$_ADDONLANG["pendingDeleteHint"] = "انقر على <strong>إلغاء التغييرات</strong> للتراجع عن الحذف.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "لم يتم العثور على سجلات DNS.";
// Add Record Form
$_ADDONLANG["addRecordNameLabel"] = "الاسم";
$_ADDONLANG["addRecordContentLabel"] = "المحتوى";
$_ADDONLANG["addRecordCancelBtn"] = "إلغاء";
$_ADDONLANG["addRecordSaveBtn"] = "حفظ";
// Add Record Validation
$_ADDONLANG["hostRequired"] = "اسم المضيف مطلوب.";
$_ADDONLANG["addressRequired"] = "العنوان مطلوب.";
// Copy to Clipboard
$_ADDONLANG["copyAddress"] = "نسخ إلى الحافظة";
$_ADDONLANG["copiedToClipboard"] = "تم النسخ";
// Zone Import / Export Controls
$_ADDONLANG["searchDnsRecordsPlaceholder"] = "البحث في سجلات DNS";
$_ADDONLANG["importAndExportBtn"] = "الاستيراد والتصدير";
$_ADDONLANG["addRecordBtn"] = "إضافة سجل";
$_ADDONLANG["importDnsRecordsTitle"] = "استيراد سجلات DNS";
$_ADDONLANG["importDnsRecordsDesc"] = "قم بتحميل ملف منطقة لاستيراد سجلات DNS";
$_ADDONLANG["importWarningLabel"] = "هام:";
$_ADDONLANG["importWarningText"] = "سيؤدي استيراد ملف المنطقة إلى استبدال جميع سجلات DNS الحالية. تأكد من تصدير سجلاتك الحالية أولاً إذا كنت بحاجة إلى الاحتفاظ بنسخة احتياطية.";
$_ADDONLANG["selectFileOrDragText"] = "اختر ملفاً أو اسحبه هنا";
$_ADDONLANG["browseFilesBtn"] = "تصفح الملفات";
$_ADDONLANG["applyImportedRecordsBtn"] = "تطبيق السجلات المستوردة";
$_ADDONLANG["exportDnsRecordsTitle"] = "تصدير سجلات DNS";
$_ADDONLANG["exportDnsRecordsDesc"] = "قم بتنزيل جميع سجلات DNS كملف منطقة بالتنسيق القياسي";
$_ADDONLANG["exportInfoText"] = "سيحتوي الملف المُصدَّر على جميع سجلات DNS بتنسيق ملف منطقة BIND";
$_ADDONLANG["exportZoneFileBtn"] = "تصدير ملف المنطقة";
$_ADDONLANG["closeBtn"] = "إغلاق";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "هذه المنطقة غير نشطة لأن نطاقك لا يستخدم خوادم الأسماء الصحيحة.<br>يرجى تعيين خوادم الأسماء إلى: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "إدارة DNSSEC لمنطقة DNS";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "عرض سجلات DNSSEC";
// Oops Error
$_ADDONLANG["oopsError"] = "عذراً! حدث خطأ.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "عملية التوقيع معلقة";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC غير نشط</b>";
// Auto Activate Button — يرسل سجلات DS من منطقة DNS الموقعة إلى النطاق
$_ADDONLANG["autoActivateBtn"] = "إرسال سجلات DS إلى النطاق";
// Auto Update Button — يحدث سجلات DS على النطاق بعد تجديد مفتاح KSK
$_ADDONLANG["autoUpdateBtn"] = "تحديث سجلات DS على النطاق";
// DNSSEC Sign Zone Button (replaces generic "Enable")
$_ADDONLANG["dnssecSignZoneBtn"] = "توقيع منطقة DNS وإنشاء مفاتيح ZSK/KSK";
// DNSSEC keys table column headers
$_ADDONLANG["dnssecKeyType"] = "النوع";
$_ADDONLANG["dnssecKeyStatus"] = "الحالة";
$_ADDONLANG["dnssecDsRecord"] = "سجل DS (SHA-256)";
$_ADDONLANG["dnssecAction"] = "إجراء";
// KSK rollover action buttons
$_ADDONLANG["dnssecRolloverKskBtn"] = "تجديد مفتاح KSK";
$_ADDONLANG["dnssecRolloverKskTooltip"] = "بدء عملية تجديد مفتاح KSK. سيتم إنشاء مفتاح KSK جديد. ستحتاج بعد ذلك إلى تقديم سجل DS الجديد في المنطقة الأصلية وإتمام عملية التجديد. يُنصح بذلك كل 1-2 سنة.";
$_ADDONLANG["dnssecFinishRolloverBtn"] = "إتمام التجديد";
$_ADDONLANG["dnssecZskAutomatic"] = "تلقائي";
// DNSSEC keys table labels & tooltips
$_ADDONLANG["dnssecKeysTitle"] = "مفاتيح DNSSEC";
$_ADDONLANG["dnssecKeysCountLabel"] = "مفاتيح";
$_ADDONLANG["dnssecCopyTooltip"] = "نسخ إلى الحافظة";
$_ADDONLANG["dnssecZskAutoTooltip"] = "يتم تجديد مفتاح ZSK تلقائيًا بواسطة المنصة";
$_ADDONLANG["dnssecSignZoneTooltip"] = "يوقّع منطقة DNS الخاصة بك وينشئ مفاتيح ZSK/KSK. ستتوفر سجلات DS بعد ذلك للتفعيل على مستوى المُسجِّل. قد يستغرق ذلك ما يصل إلى 48 ساعة.";
$_ADDONLANG["dnssecDisableTooltip"] = "يزيل التوقيع التشفيري من منطقة DNS الخاصة بك. سيتم إلغاء تفعيل حماية DNSSEC.";
// DNSSEC per-key status badges and descriptions (mirror the CNR control panel)
$_ADDONLANG["dnssecStatusPending"] = "قيد الانتظار";
$_ADDONLANG["dnssecStatusReady"] = "جاهز";
$_ADDONLANG["dnssecStatusActive"] = "نشط";
$_ADDONLANG["dnssecDescPending"] = "في انتظار انتشار DNS (في انتظار التأكيد).";
$_ADDONLANG["dnssecDescActivating"] = "تفعيل المفتاح قيد التقدم.";
$_ADDONLANG["dnssecDescConfigured"] = "تم تكوين DNSSEC بنجاح.";
// DNSSEC: info panel shown when the zone is not yet signed
$_ADDONLANG["dnssecNotSignedInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>منطقة DNS الخاصة بك قادرة على استخدام DNSSEC.</strong>
            <p class="mb-1 mt-1">بالنقر على <em>توقيع منطقة DNS وإنشاء مفاتيح ZSK/KSK</em> سيتم:</p>
            <ul class="mb-2 pl-3">
                <li>توقيع منطقة DNS الخاصة بك تشفيرياً</li>
                <li>إنشاء <b>ZSK</b> (مفتاح توقيع المنطقة) و<b>KSK</b> (مفتاح توقيع المفاتيح) تلقائياً</li>
                <li>إنتاج <b>سجلات DS</b> التي يتم نشرها بعد ذلك على مستوى المسجل لإتمام تفعيل DNSSEC</li>
            </ul>
            <div class="text-muted small">
                <i class="fas fa-clock mr-1"></i> قد تستغرق هذه العملية ما يصل إلى <b>48 ساعة</b>.
                بعد التوقيع، سيتم استيراد سجلات DS تلقائياً إلى إعدادات DNSSEC لنطاقك.
            </div>
        </div>
    </div>
';
// DNSSEC: info panel shown when signing is in progress (pending)
$_ADDONLANG["dnssecPendingInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-hourglass-half text-warning mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>تم بدء عملية توقيع المنطقة.</strong>
            <p class="mb-1 mt-1">يتم إنشاء مفاتيح ZSK/KSK. قد يستغرق ذلك ما يصل إلى <b>48 ساعة</b>.</p>
            <div class="text-muted small">
                بعد اكتمال التوقيع، ستظهر سجلات DS هنا ويمكن نشرها على مستوى المسجل.
                لا يلزم اتخاذ أي إجراء آخر في الوقت الحالي.
            </div>
        </div>
    </div>
';
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC <span class="font-weight-bold">نشط</span> على منطقة DNS الخاصة بك.
            </strong>
            <div class="text-info mb-2">
                مع ذلك، قد لا تتطابق سجلات DNSSEC على نطاقك مع تلك الموجودة في منطقة DNS الخاصة بك.
            </div>
            <div class="text-muted mb-2">
                <em>نصيحة:</em> يمكنك إدارة DNSSEC في قسم 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>إدارة DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                أخبار رائعة! DNSSEC نشط بالكامل ومؤمن لنطاقك.
            </strong>
            <div class="text-success mb-2">
                سجلات DNSSEC في منطقة DNS الخاصة بك وعلى نطاقك موقعة ومتطابقة.
            </div>
            <div class="text-info mb-2">
                لا يلزم اتخاذ أي إجراء إضافي.
            </div>
            <div class="text-muted">
                <em>نصيحة:</em> يمكنك 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>عرض وإدارة سجلات DNSSEC الخاصة بك</u>
                </a> في أي وقت في قسم إدارة DNSSEC.
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC نشط على منطقة DNS الخاصة بك، وتم استلام طلب التفعيل الخاص بك.
            </strong>
            <div class="text-success mb-2">
                تمت مزامنة سجلات DNSSEC في منطقة DNS الخاصة بك مع نطاقك.
            </div>
            <div class="text-info mb-2">
                لا يلزم اتخاذ أي إجراء إضافي في الوقت الحالي، ولكن يمكنك تحديث السجلات يدوياً إذا لزم الأمر.
            </div>
            <div class="text-muted mb-2">
                <em>نصيحة:</em> قم بإدارة إعدادات DNSSEC في قسم 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>إدارة DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingTitle"] = "إعادة توجيه الويب";
$_ADDONLANG["webForwardingDescription"] = "إدارة إعادة توجيه URL و FRAME لـ ";
$_ADDONLANG["webForwardingProcessingMessage"] = "جاري المعالجة...";
$_ADDONLANG["webForwardingAddNew"] = "إضافة إعادة توجيه ويب جديدة";
$_ADDONLANG["webForwardingUrlType"] = "إعادة توجيه URL";
$_ADDONLANG["webForwardingTrdType"] = "إعادة توجيه مؤقتة";
$_ADDONLANG["webForwardingFrameType"] = "إطار URL";
$_ADDONLANG["webForwardingTargetHelp"] = "أدخل عنوان URL الكامل بما في ذلك http:// أو https://";
$_ADDONLANG["webForwardingUrlDescription"] = "إعادة التوجيه إلى عنوان URL المستهدف (مرئي في شريط العنوان)";
$_ADDONLANG["webForwardingTrdDescription"] = "إعادة توجيه مؤقتة (HTTP 302) - مفيد للتغييرات المؤقتة";
$_ADDONLANG["webForwardingFrameDescription"] = "عرض عنوان URL المستهدف في إطار (إخفاء الوجهة في شريط العنوان)";
$_ADDONLANG["webForwardingSaveButton"] = "حفظ إعادة توجيه الويب";
$_ADDONLANG["webForwardingCancelButton"] = "إلغاء";
$_ADDONLANG["webForwardingGetStarted"] = "قم بإنشاء قاعدة إعادة توجيه الويب الأولى الخاصة بك لإعادة توجيه نطاقك أو تأطيره.";
$_ADDONLANG["webForwardingSource"] = "المصدر";
$_ADDONLANG["webForwardingTargetLabel"] = "الهدف";
$_ADDONLANG["webForwardingEdit"] = "تعديل";
$_ADDONLANG["webForwardingDelete"] = "حذف";
$_ADDONLANG["webForwardingVisitorsSeeUrl"] = "سيرى الزوار";
$_ADDONLANG["webForwardingInBrowser"] = "في متصفحهم";
$_ADDONLANG["webForwardingDomainVisible"] = "يظل نطاقك مرئيًا أثناء عرض المحتوى من الهدف";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "لم يتم تكوين إعادة توجيه الويب";
$_ADDONLANG["webForwardingCreateButton"] = "إنشاء إعادة توجيه ويب";
$_ADDONLANG["webForwardingDeleteConfirm"] = "تأكيد الحذف";
$_ADDONLANG["webForwardingSourceHostname"] = "اسم المضيف المصدر";
$_ADDONLANG["webForwardingTargetUrl"] = "عنوان URL الهدف";
$_ADDONLANG["webForwardingStep1"] = "الخطوة 1: اختر نوع إعادة التوجيه";
$_ADDONLANG["webForwardingStep2"] = "الخطوة 2: قم بإعداد إعادة التوجيه";
$_ADDONLANG["webForwardingExampleLabel"] = "مثال:";
$_ADDONLANG["webForwardingAllowsPaths"] = "يسمح بالمسارات • HTTP 301";
$_ADDONLANG["webForwardingNoPaths302"] = "بدون مسارات • HTTP 302";
$_ADDONLANG["webForwardingNoPathsKeepsDomain"] = "بدون مسارات • يبقي النطاق مرئيًا";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ أو www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.example.com/path";
$_ADDONLANG["webForwardingRootDomainInfo"] = "استخدم @ للنطاق الرئيسي أو أدخل نطاقاً فرعياً صالحاً";
$_ADDONLANG["webForwardingUrlValidation"] = "يرجى إدخال عنوان URL صالح (http:// أو https://)";
$_ADDONLANG["webForwardingTemporaryRedirectInfo"] = "إعادة توجيه مؤقتة (HTTP 302) - مفيدة للاختبارات أو النقل المؤقت";
$_ADDONLANG["webForwardingFrameInfo"] = "يعرض عنوان URL الهدف داخل إطار (يبقي نطاقك في شريط العناوين)";
