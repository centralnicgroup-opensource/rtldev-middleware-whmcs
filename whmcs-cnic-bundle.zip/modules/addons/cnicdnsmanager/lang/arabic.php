<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - Arabic
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "إضافة سجل";
// TTL
$_ADDONLANG["ttl"] = "مدة الصلاحية";
// Type
$_ADDONLANG["type"] = "النوع";
// Priority
$_ADDONLANG["priority"] = "الأولوية";
// Address
$_ADDONLANG["address"] = "العنوان";
// Hostname
$_ADDONLANG["hostname"] = "اسم المضيف";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "لم يتم العثور على سجلات DNS.";
// Add Record Form
$_ADDONLANG["addRecordNameLabel"] = "الاسم";
$_ADDONLANG["addRecordContentLabel"] = "المحتوى";
$_ADDONLANG["addRecordCancelBtn"] = "إلغاء";
$_ADDONLANG["addRecordSaveBtn"] = "حفظ";
// Add Record Validation
$_ADDONLANG["hostRequired"] = "اسم المضيف مطلوب.";
$_ADDONLANG["addressRequired"] = "العنوان مطلوب.";
// Copy to Clipboard
$_ADDONLANG["copyAddress"] = "نسخ إلى الحافظة";
$_ADDONLANG["copiedToClipboard"] = "تم النسخ";
// Zone Import / Export Controls
$_ADDONLANG["searchDnsRecordsPlaceholder"] = "البحث في سجلات DNS";
$_ADDONLANG["addRecordBtn"] = "إضافة سجل";
$_ADDONLANG["importDnsRecordsTitle"] = "استيراد سجلات DNS";
$_ADDONLANG["importDnsRecordsDesc"] = "قم بتحميل ملف منطقة لاستيراد سجلات DNS";
$_ADDONLANG["importWarningLabel"] = "هام:";
$_ADDONLANG["importWarningText"] = "سيؤدي استيراد ملف المنطقة إلى استبدال جميع سجلات DNS الحالية. تأكد من تصدير سجلاتك الحالية أولاً إذا كنت بحاجة إلى الاحتفاظ بنسخة احتياطية.";
$_ADDONLANG["applyImportedRecordsBtn"] = "تطبيق السجلات المستوردة";
$_ADDONLANG["exportDnsRecordsTitle"] = "تصدير سجلات DNS";
$_ADDONLANG["exportDnsRecordsDesc"] = "قم بتنزيل جميع سجلات DNS كملف منطقة بالتنسيق القياسي";
$_ADDONLANG["exportZoneFileBtn"] = "تصدير ملف المنطقة";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "هذه المنطقة غير نشطة لأن نطاقك لا يستخدم خوادم الأسماء الصحيحة.<br>يرجى تعيين خوادم الأسماء إلى: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "إدارة DNSSEC لمنطقة DNS";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "عرض سجلات DNSSEC";
// Oops Error
$_ADDONLANG["oopsError"] = "عذراً! حدث خطأ.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "عملية التوقيع معلقة";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC غير نشط</b>";
// Auto Activate Button — يرسل سجلات DS من منطقة DNS الموقعة إلى النطاق
$_ADDONLANG["autoActivateBtn"] = "إرسال سجلات DS إلى النطاق";
// Auto Update Button — يحدث سجلات DS على النطاق بعد تجديد مفتاح KSK
$_ADDONLANG["autoUpdateBtn"] = "تحديث سجلات DS على النطاق";
// DNSSEC Sign Zone Button (replaces generic "Enable")
$_ADDONLANG["dnssecSignZoneBtn"] = "توقيع منطقة DNS وإنشاء مفاتيح ZSK/KSK";
// DNSSEC keys table column headers
$_ADDONLANG["dnssecKeyType"] = "النوع";
$_ADDONLANG["dnssecKeyStatus"] = "الحالة";
$_ADDONLANG["dnssecDsRecord"] = "سجل DS (SHA-256)";
$_ADDONLANG["dnssecAction"] = "إجراء";
// KSK rollover action buttons
$_ADDONLANG["dnssecRolloverKskBtn"] = "تجديد مفتاح KSK";
$_ADDONLANG["dnssecRolloverKskTooltip"] = "بدء عملية تجديد مفتاح KSK. سيتم إنشاء مفتاح KSK جديد. ستحتاج بعد ذلك إلى تقديم سجل DS الجديد في المنطقة الأصلية وإتمام عملية التجديد. يُنصح بذلك كل 1-2 سنة.";
$_ADDONLANG["dnssecFinishRolloverBtn"] = "إتمام التجديد";
$_ADDONLANG["dnssecZskAutomatic"] = "تلقائي";
// DNSSEC keys table labels & tooltips
$_ADDONLANG["dnssecKeysTitle"] = "مفاتيح DNSSEC";
$_ADDONLANG["dnssecKeysCountLabel"] = "مفاتيح";
$_ADDONLANG["dnssecCopyTooltip"] = "نسخ إلى الحافظة";
$_ADDONLANG["dnssecZskAutoTooltip"] = "يتم تجديد مفتاح ZSK تلقائيًا بواسطة المنصة";
$_ADDONLANG["dnssecSignZoneTooltip"] = "يوقّع منطقة DNS الخاصة بك وينشئ مفاتيح ZSK/KSK. ستتوفر سجلات DS بعد ذلك للتفعيل على مستوى المُسجِّل. قد يستغرق ذلك ما يصل إلى 48 ساعة.";
$_ADDONLANG["dnssecDisableTooltip"] = "يزيل التوقيع التشفيري من منطقة DNS الخاصة بك. سيتم إلغاء تفعيل حماية DNSSEC.";
// DNSSEC per-key status badges and descriptions (mirror the CNR control panel)
$_ADDONLANG["dnssecStatusPending"] = "قيد الانتظار";
$_ADDONLANG["dnssecStatusReady"] = "جاهز";
$_ADDONLANG["dnssecStatusActive"] = "نشط";
$_ADDONLANG["dnssecDescPending"] = "في انتظار انتشار DNS (في انتظار التأكيد).";
$_ADDONLANG["dnssecDescActivating"] = "تفعيل المفتاح قيد التقدم.";
$_ADDONLANG["dnssecDescConfigured"] = "تم تكوين DNSSEC بنجاح.";
// DNSSEC: info panel shown when the zone is not yet signed
$_ADDONLANG["dnssecNotSignedInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>منطقة DNS الخاصة بك قادرة على استخدام DNSSEC.</strong>
            <p class="mb-1 mt-1">بالنقر على <em>توقيع منطقة DNS وإنشاء مفاتيح ZSK/KSK</em> سيتم:</p>
            <ul class="mb-2 pl-3">
                <li>توقيع منطقة DNS الخاصة بك تشفيرياً</li>
                <li>إنشاء <b>ZSK</b> (مفتاح توقيع المنطقة) و<b>KSK</b> (مفتاح توقيع المفاتيح) تلقائياً</li>
                <li>إنتاج <b>سجلات DS</b> التي يتم نشرها بعد ذلك على مستوى المسجل لإتمام تفعيل DNSSEC</li>
            </ul>
            <div class="text-muted small">
                <i class="fas fa-clock mr-1"></i> قد تستغرق هذه العملية ما يصل إلى <b>48 ساعة</b>.
                بعد التوقيع، سيتم استيراد سجلات DS تلقائياً إلى إعدادات DNSSEC لنطاقك.
            </div>
        </div>
    </div>
';
// DNSSEC: info panel shown when signing is in progress (pending)
$_ADDONLANG["dnssecPendingInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-hourglass-half text-warning mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>تم بدء عملية توقيع المنطقة.</strong>
            <p class="mb-1 mt-1">يتم إنشاء مفاتيح ZSK/KSK. قد يستغرق ذلك ما يصل إلى <b>48 ساعة</b>.</p>
            <div class="text-muted small">
                بعد اكتمال التوقيع، ستظهر سجلات DS هنا ويمكن نشرها على مستوى المسجل.
                لا يلزم اتخاذ أي إجراء آخر في الوقت الحالي.
            </div>
        </div>
    </div>
';
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC <span class="font-weight-bold">نشط</span> على منطقة DNS الخاصة بك.
            </strong>
            <div class="text-info mb-2">
                مع ذلك، قد لا تتطابق سجلات DNSSEC على نطاقك مع تلك الموجودة في منطقة DNS الخاصة بك.
            </div>
            <div class="text-muted mb-2">
                <em>نصيحة:</em> يمكنك إدارة DNSSEC في قسم 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>إدارة DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                أخبار رائعة! DNSSEC نشط بالكامل ومؤمن لنطاقك.
            </strong>
            <div class="text-success mb-2">
                سجلات DNSSEC في منطقة DNS الخاصة بك وعلى نطاقك موقعة ومتطابقة.
            </div>
            <div class="text-info mb-2">
                لا يلزم اتخاذ أي إجراء إضافي.
            </div>
            <div class="text-muted">
                <em>نصيحة:</em> يمكنك 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>عرض وإدارة سجلات DNSSEC الخاصة بك</u>
                </a> في أي وقت في قسم إدارة DNSSEC.
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC نشط على منطقة DNS الخاصة بك، وتم استلام طلب التفعيل الخاص بك.
            </strong>
            <div class="text-success mb-2">
                تمت مزامنة سجلات DNSSEC في منطقة DNS الخاصة بك مع نطاقك.
            </div>
            <div class="text-info mb-2">
                لا يلزم اتخاذ أي إجراء إضافي في الوقت الحالي، ولكن يمكنك تحديث السجلات يدوياً إذا لزم الأمر.
            </div>
            <div class="text-muted mb-2">
                <em>نصيحة:</em> قم بإدارة إعدادات DNSSEC في قسم 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>إدارة DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingProcessingMessage"] = "جاري المعالجة...";
$_ADDONLANG["webForwardingAddNew"] = "إضافة إعادة توجيه ويب جديدة";
$_ADDONLANG["webForwardingUrlType"] = "إعادة توجيه URL";
$_ADDONLANG["webForwardingTrdType"] = "إعادة توجيه مؤقتة";
$_ADDONLANG["webForwardingFrameType"] = "إطار URL";
$_ADDONLANG["webForwardingTargetHelp"] = "أدخل عنوان URL الكامل بما في ذلك http:// أو https://";
$_ADDONLANG["webForwardingUrlDescription"] = "إعادة التوجيه إلى عنوان URL المستهدف (مرئي في شريط العنوان)";
$_ADDONLANG["webForwardingTrdDescription"] = "إعادة توجيه مؤقتة (HTTP 302) - مفيد للتغييرات المؤقتة";
$_ADDONLANG["webForwardingFrameDescription"] = "عرض عنوان URL المستهدف في إطار (إخفاء الوجهة في شريط العنوان)";
$_ADDONLANG["webForwardingCancelButton"] = "إلغاء";
$_ADDONLANG["webForwardingGetStarted"] = "قم بإنشاء قاعدة إعادة توجيه الويب الأولى الخاصة بك لإعادة توجيه نطاقك أو تأطيره.";
$_ADDONLANG["webForwardingSource"] = "المصدر";
$_ADDONLANG["webForwardingTargetLabel"] = "الهدف";
$_ADDONLANG["webForwardingEdit"] = "تعديل";
$_ADDONLANG["webForwardingDelete"] = "حذف";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "لم يتم تكوين إعادة توجيه الويب";
$_ADDONLANG["webForwardingCreateButton"] = "إنشاء إعادة توجيه ويب";
$_ADDONLANG["webForwardingDeleteConfirm"] = "تأكيد الحذف";
$_ADDONLANG["webForwardingSourceHostname"] = "اسم المضيف المصدر";
$_ADDONLANG["webForwardingTargetUrl"] = "عنوان URL الهدف";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ أو www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.example.com/path";
$_ADDONLANG["webForwardingRootDomainInfo"] = "استخدم @ للنطاق الرئيسي أو أدخل نطاقاً فرعياً صالحاً";
// SOA settings of the DNS zone
$_ADDONLANG["soaBtn"] = "إعدادات المنطقة";
$_ADDONLANG["soaDesc"] = "القيم الافتراضية مناسبة لمعظم المناطق. الحقول الفارغة تحتفظ بقيمتها الحالية.";
$_ADDONLANG["soaLabelSOARNAME"] = "البريد المسؤول (RName)";
$_ADDONLANG["soaHelpSOARNAME"] = "عنوان البريد الإلكتروني لمسؤول المنطقة، مكتوب بنقطة بدلاً من @ (admin.example.com). يتم تحويل عنوان البريد الإلكتروني تلقائياً.";
$_ADDONLANG["soaLabelSOAREFRESH"] = "التحديث (Refresh)";
$_ADDONLANG["soaHelpSOAREFRESH"] = "عدد مرات تحقق خوادم الأسماء الثانوية من تحديثات المنطقة";
$_ADDONLANG["soaLabelSOARETRY"] = "إعادة المحاولة (Retry)";
$_ADDONLANG["soaHelpSOARETRY"] = "مدة انتظار خوادم الأسماء الثانوية قبل إعادة محاولة تحديث فاشل";
$_ADDONLANG["soaLabelSOAEXPIRE"] = "الانتهاء (Expire)";
$_ADDONLANG["soaHelpSOAEXPIRE"] = "مدة استمرار خوادم الأسماء الثانوية في الرد عند تعذر الوصول إلى خادم الأسماء الأساسي";
$_ADDONLANG["soaLabelSOAMINTTL"] = "الحد الأدنى لـ TTL";
$_ADDONLANG["soaHelpSOAMINTTL"] = "المدة التي يجوز فيها للمحللات تخزين الإجابات السلبية (مثل NXDOMAIN)؛ القيم الأقل تجعل السجلات الجديدة مرئية أسرع";
$_ADDONLANG["soaAllowed"] = "المسموح:";
$_ADDONLANG["soaSeconds"] = "ثانية";
$_ADDONLANG["soaSaveBtn"] = "حفظ";
$_ADDONLANG["soaSaved"] = "تم حفظ إعدادات SOA بنجاح.";
$_ADDONLANG["soaInvalid"] = "يرجى تصحيح القيم المحددة.";
// DNS Manager redesign: toolbar, popovers, record form, confirmations (record type formats stay as they are)
$_ADDONLANG["importBtn"] = "استيراد";
$_ADDONLANG["exportBtn"] = "تصدير";
$_ADDONLANG["moreActionsBtn"] = "إجراءات أخرى";
$_ADDONLANG["moreZoneDesc"] = "قيم توقيت SOA والبريد المسؤول";
$_ADDONLANG["moreImportDesc"] = "استبدال جميع السجلات من ملف منطقة BIND";
$_ADDONLANG["moreExportDesc"] = "تنزيل جميع السجلات كملف منطقة BIND";
$_ADDONLANG["filterByType"] = "التصفية حسب النوع";
$_ADDONLANG["jsEdit"] = "تعديل";
$_ADDONLANG["jsClose"] = "إغلاق";
$_ADDONLANG["jsSave"] = "حفظ";
$_ADDONLANG["jsAdd"] = "إضافة سجل";
$_ADDONLANG["jsAll"] = "الكل";
$_ADDONLANG["jsRecordAdded"] = "تمت إضافة السجل";
$_ADDONLANG["jsRecordSaved"] = "تم حفظ السجل";
$_ADDONLANG["jsRecordDeleted"] = "تم حذف السجل";
$_ADDONLANG["jsZoneExported"] = "تم تنزيل ملف المنطقة";
$_ADDONLANG["jsRecordsImported"] = "تم استيراد السجلات";
$_ADDONLANG["jsDeleteConfirm"] = "حذف هذا السجل؟ يسري ذلك فوراً.";
$_ADDONLANG["jsDeleteKeep"] = "إبقاء";
$_ADDONLANG["jsDeleteBtn"] = "حذف";
$_ADDONLANG["jsDiscardChanges"] = "تجاهل التغييرات على هذا السجل؟";
$_ADDONLANG["jsNamePlaceholder"] = "[الاسم]";
$_ADDONLANG["jsValuePlaceholder"] = "[القيمة]";
$_ADDONLANG["jsSummaryAddress"] = "{name} يشير إلى {value}";
$_ADDONLANG["jsSummaryAlias"] = "{name} اسم بديل لـ {value}";
$_ADDONLANG["jsSummaryRedirect"] = "تتم إعادة توجيه النطاقات الفرعية لـ {name} إلى {value}";
$_ADDONLANG["jsSummaryMail"] = "يتم تسليم بريد {name} إلى {value} (الأولوية {priority})";
$_ADDONLANG["jsSummaryDelegation"] = "تم تفويض {name} إلى خادم الأسماء {value}";
$_ADDONLANG["jsSummaryText"] = "{name} له القيمة النصية {value}";
$_ADDONLANG["jsSummaryDefault"] = "{name} له قيمة {type} التالية: {value}";
$_ADDONLANG["jsTypeLabelA"] = "عنوان IPv4";
$_ADDONLANG["jsTypeLabelAAAA"] = "عنوان IPv6";
$_ADDONLANG["jsTypeLabelALIAS"] = "اسم المضيف الهدف";
$_ADDONLANG["jsTypeLabelCNAME"] = "اسم المضيف الهدف";
$_ADDONLANG["jsTypeLabelDNAME"] = "النطاق الهدف";
$_ADDONLANG["jsTypeLabelMX"] = "خادم البريد";
$_ADDONLANG["jsTypeLabelMXE"] = "عنوان IPv4 لخادم البريد";
$_ADDONLANG["jsTypeLabelNS"] = "خادم الأسماء";
$_ADDONLANG["jsTypeLabelPTR"] = "اسم المضيف";
$_ADDONLANG["jsTypeLabelTXT"] = "القيمة النصية";
$_ADDONLANG["jsTypeLabelSPF"] = "قيمة SPF";
$_ADDONLANG["jsTypeLabelDefault"] = "القيمة";
$_ADDONLANG["jsTypeHelpSRV"] = "الصيغة: الوزن المنفذ الهدف";
$_ADDONLANG["jsTypeExampleSRV"] = "مثال: 5 5060 jabber.example.com";
$_ADDONLANG["jsTypeHelpSVCB"] = "الصيغة: الهدف [المعاملات]";
$_ADDONLANG["jsTypeExampleSVCB"] = "مثال: svc.example.net. port=443 ipv4hint=192.0.2.1 | مدعوم: port, ipv4hint, ipv6hint, ech, mandatory, no-default-alpn | غير مدعوم: alpn مع h2/h3, dohpath, ohttp, tls-supported-groups";
$_ADDONLANG["jsTypeHelpNAPTR"] = "الصيغة: الأفضلية العلامات الخدمة التعبير-النمطي الاستبدال";
$_ADDONLANG["jsTypeExampleNAPTR"] = "مثال: 10 \"A\" \"\" \"!^.*$!prodserver.example.com!\" .";
$_ADDONLANG["jsTypeHelpCAA"] = "الصيغة: العلامات الوسم القيمة";
$_ADDONLANG["jsTypeExampleCAA"] = "مثال: 0 issue letsencrypt.org";
$_ADDONLANG["jsTypeHelpTLSA"] = "الصيغة: الاستخدام المحدد النوع بيانات-الشهادة";
$_ADDONLANG["jsTypeHelpSSHFP"] = "الصيغة: الخوارزمية نوع-البصمة البصمة";
$_ADDONLANG["jsTypeHelpLOC"] = "الصيغة: خط-العرض خط-الطول الارتفاع الحجم hp vp";
$_ADDONLANG["jsTypeHelpDHCID"] = "الصيغة: بيانات معرّف مرمّزة بـ base64";
$_ADDONLANG["jsTypeHelpDS"] = "الصيغة: وسم-المفتاح الخوارزمية نوع-الملخص الملخص";
$_ADDONLANG["jsTypeHelpDNSKEY"] = "الصيغة: العلامات البروتوكول الخوارزمية المفتاح-العام";
$_ADDONLANG["jsTypeHelpSMIMEA"] = "الصيغة: الاستخدام المحدد النوع بيانات-الشهادة";
$_ADDONLANG["jsHelpMore"] = "المزيد";
$_ADDONLANG["jsHelpLess"] = "أقل";
$_ADDONLANG["selectFileLink"] = "اختر ملفاً";
$_ADDONLANG["dragFileHereText"] = "أو اسحبه إلى هنا";
// Web Forwarding redesign
$_ADDONLANG["webForwardingTypeLabel"] = "نوع التوجيه";
$_ADDONLANG["webForwardingType"] = "النوع";
$_ADDONLANG["jsWfHelpPath"] = "أدخل عنوان URL الكامل، مثل https://example.com/page";
$_ADDONLANG["jsWfHelpNoPath"] = "أدخل اسم المضيف فقط دون مسار، مثل https://example.com";
$_ADDONLANG["jsWfInvalidUrl"] = "أدخل عنوان URL صالحاً يبدأ بـ http:// أو https://";
$_ADDONLANG["jsWfPathNotAllowed"] = "لا يسمح نوع التوجيه هذا بمسار. استخدم اسم المضيف فقط، مثل https://example.com";
$_ADDONLANG["jsWfSummaryURL"] = "{source} يعيد التوجيه بشكل دائم إلى {target}";
$_ADDONLANG["jsWfSummaryTRD"] = "{source} يعيد التوجيه مؤقتاً إلى {target}";
$_ADDONLANG["jsWfSummaryFRAME"] = "{source} يعرض {target} داخل إطار";
$_ADDONLANG["jsWfSourcePlaceholder"] = "[المصدر]";
$_ADDONLANG["jsWfTargetPlaceholder"] = "[عنوان URL الهدف]";
$_ADDONLANG["jsWfFillAll"] = "يرجى ملء جميع الحقول.";
$_ADDONLANG["jsWfSaved"] = "تم حفظ التوجيه";
$_ADDONLANG["jsWfDeleted"] = "تم حذف التوجيه";
$_ADDONLANG["jsWfError"] = "تعذر حفظ التوجيه.";
$_ADDONLANG["jsWfDeleteTitle"] = "حذف هذا التوجيه؟";
$_ADDONLANG["jsWfCannotUndo"] = "لا يمكن التراجع عن ذلك.";
// DNS records page: title and paging
$_ADDONLANG["dnsRecordsFor"] = "سجلات DNS لـ";
$_ADDONLANG["dnsRecordsIntro"] = "تحكّم في كيفية العثور على مواقع نطاقك وبريده وخدماته الأخرى على الإنترنت.";
$_ADDONLANG["jsShowing"] = "عرض {from}–{to} من {total}";
$_ADDONLANG["jsPerPage"] = "لكل صفحة";
$_ADDONLANG["jsPreviousPage"] = "الصفحة السابقة";
$_ADDONLANG["jsNextPage"] = "الصفحة التالية";
$_ADDONLANG["webForwardingFor"] = "توجيه الويب لـ";
$_ADDONLANG["webForwardingIntro"] = "أرسل زوار اسم مضيف في نطاقك إلى عنوان ويب آخر.";
$_ADDONLANG["jsEditRecord"] = "تعديل السجل";
