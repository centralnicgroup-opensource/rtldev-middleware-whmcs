<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - Arabic
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "إضافة سجل";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "إلغاء التغييرات";
// Save Changes
$_ADDONLANG["saveChanges"] = "حفظ التغييرات";
// TTL
$_ADDONLANG["ttl"] = "مدة الصلاحية";
// Type
$_ADDONLANG["type"] = "النوع";
// Priority
$_ADDONLANG["priority"] = "الأولوية";
// Address
$_ADDONLANG["address"] = "العنوان";
// Hostname
$_ADDONLANG["hostname"] = "اسم المضيف";
// MX Description
$_ADDONLANG["mxdesc"] = "* سجل الأولوية لـ MX و SRV فقط";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "هناك تغييرات معلقة في سجلات DNS الخاصة بك. يرجى مراجعة وحفظ التغييرات.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "لم يتم العثور على سجلات DNS.";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "هذه المنطقة غير نشطة لأن نطاقك لا يحتوي على خوادم الأسماء الصحيحة.<br>يرجى تعيين خوادم الأسماء إلى: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "إدارة DNSSEC لمنطقة DNS";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "عرض سجلات DNSSEC";
// Oops Error
$_ADDONLANG["oopsError"] = "عذراً! حدث خطأ.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "عملية التوقيع معلقة";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC غير نشط</b>";
// Auto Activate Button
$_ADDONLANG["autoActivateBtn"] = "استيراد تلقائي لسجلات DNSSEC وتفعيل DNSSEC لنطاقك";
// Auto Update Button
$_ADDONLANG["autoUpdateBtn"] = "تحديث تلقائي لسجلات DNSSEC لنطاقك";
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC <span class="font-weight-bold">نشط</span> على منطقة DNS الخاصة بك.
            </strong>
            <div class="text-info mb-2">
                مع ذلك، قد لا تتطابق سجلات DNSSEC على نطاقك مع تلك الموجودة في منطقة DNS الخاصة بك.
            </div>
            <div class="text-muted mb-2">
                <em>نصيحة:</em> يمكنك إدارة DNSSEC في قسم 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>إدارة DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                أخبار رائعة! DNSSEC نشط بالكامل ومؤمن لنطاقك.
            </strong>
            <div class="text-success mb-2">
                سجلات DNSSEC في منطقة DNS الخاصة بك وعلى نطاقك موقعة ومتطابقة.
            </div>
            <div class="text-info mb-2">
                لا يلزم اتخاذ أي إجراء إضافي.
            </div>
            <div class="text-muted">
                <em>نصيحة:</em> يمكنك 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>عرض وإدارة سجلات DNSSEC الخاصة بك</u>
                </a> في أي وقت في قسم إدارة DNSSEC.
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC نشط على منطقة DNS الخاصة بك، وتم استلام طلب التفعيل الخاص بك.
            </strong>
            <div class="text-success mb-2">
                تمت مزامنة سجلات DNSSEC في منطقة DNS الخاصة بك مع نطاقك.
            </div>
            <div class="text-info mb-2">
                لا يلزم اتخاذ أي إجراء إضافي في الوقت الحالي، ولكن يمكنك تحديث السجلات يدوياً إذا لزم الأمر.
            </div>
            <div class="text-muted mb-2">
                <em>نصيحة:</em> قم بإدارة إعدادات DNSSEC في قسم 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>إدارة DNSSEC</u>
                </a>.
            </div>
            <div class="text-muted">
                قد تستغرق تغييرات DNSSEC ما يصل إلى <b>24-48 ساعة</b> للانتشار عبر الإنترنت بسبب تأخيرات انتشار DNS.
            </div>
        </div>
    </div>
';
