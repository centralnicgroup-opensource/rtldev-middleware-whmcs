<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - English
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Add Record";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "Cancel Changes";
// Save Changes
$_ADDONLANG["saveChanges"] = "Save Changes";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Type";
// Priority
$_ADDONLANG["priority"] = "Priority";
// Address
$_ADDONLANG["address"] = "Address";
// Hostname
$_ADDONLANG["hostname"] = "Hostname";
// MX Description
$_ADDONLANG["mxdesc"] = "* Priority Record for MX and SRV Only";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "There are pending changes to your DNS records. Please review and save your changes.";
// Pending Delete Banner
$_ADDONLANG["pendingDeleteStatus"] = "Marked for deletion";
$_ADDONLANG["pendingDeleteHint"] = "Click <strong>Cancel Changes</strong> to undo the deletion.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "No DNS records found.";
// Add Record Form
$_ADDONLANG["addRecordNameLabel"] = "Name";
$_ADDONLANG["addRecordContentLabel"] = "Content";
$_ADDONLANG["addRecordCancelBtn"] = "Cancel";
$_ADDONLANG["addRecordSaveBtn"] = "Save";
// Add Record Validation
$_ADDONLANG["hostRequired"] = "Host is required.";
$_ADDONLANG["addressRequired"] = "Address is required.";
// Copy to Clipboard
$_ADDONLANG["copyAddress"] = "Copy to clipboard";
$_ADDONLANG["copiedToClipboard"] = "Copied";
// Zone Import / Export Controls
$_ADDONLANG["searchDnsRecordsPlaceholder"] = "Search DNS Records";
$_ADDONLANG["importAndExportBtn"] = "Import and Export";
$_ADDONLANG["addRecordBtn"] = "Add record";
$_ADDONLANG["importDnsRecordsTitle"] = "Import DNS records";
$_ADDONLANG["importDnsRecordsDesc"] = "Upload a zone file to import DNS records";
$_ADDONLANG["importWarningLabel"] = "Important:";
$_ADDONLANG["importWarningText"] = "Importing a zone file will replace all existing DNS records. Make sure to export your current records first if you need to keep a backup.";
$_ADDONLANG["selectFileOrDragText"] = "Select a file or drag it here";
$_ADDONLANG["browseFilesBtn"] = "Browse Files";
$_ADDONLANG["applyImportedRecordsBtn"] = "Apply Imported Records";
$_ADDONLANG["exportDnsRecordsTitle"] = "Export DNS records";
$_ADDONLANG["exportDnsRecordsDesc"] = "Download all DNS records as a zone file in standard format";
$_ADDONLANG["exportInfoText"] = "The exported file will contain all DNS records in BIND zone file format";
$_ADDONLANG["exportZoneFileBtn"] = "Export Zone File";
$_ADDONLANG["closeBtn"] = "Close";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "This zone is not active because your domain does not have the correct nameservers configured.<br>Please set your nameservers to: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "DNSSEC Management for DNS Zone";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "View DNSSEC Records";
// Oops Error
$_ADDONLANG["oopsError"] = "Oops! An error occurred.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Signing Process is PENDING";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC IS NOT ACTIVE</b>";
// Auto Activate Button — pushes DS records from the signed DNS zone to the domain registrar for the first time
$_ADDONLANG["autoActivateBtn"] = "Push DS Records to Domain";
// Auto Update Button — updates the domain registrar's DS records after a KSK rollover
$_ADDONLANG["autoUpdateBtn"] = "Update DS Records on Domain";
// DNSSEC Sign Zone Button (replaces generic "Enable")
$_ADDONLANG["dnssecSignZoneBtn"] = "Sign DNS Zone &amp; Generate ZSK/KSK Keys";
// DNSSEC keys table column headers
$_ADDONLANG["dnssecKeyType"] = "Type";
$_ADDONLANG["dnssecKeyStatus"] = "Status";
$_ADDONLANG["dnssecDsRecord"] = "DS Record (SHA-256)";
$_ADDONLANG["dnssecAction"] = "Action";
// KSK rollover action buttons
$_ADDONLANG["dnssecRolloverKskBtn"] = "Rollover KSK";
$_ADDONLANG["dnssecRolloverKskTooltip"] = "Initiate a KSK rollover. A new Key Signing Key will be generated. You will then need to submit the new DS record to the parent zone and complete the rollover. Recommended every 1-2 years.";
$_ADDONLANG["dnssecFinishRolloverBtn"] = "Complete Rollover";
$_ADDONLANG["dnssecZskAutomatic"] = "Automatic";
// DNSSEC keys table labels & tooltips
$_ADDONLANG["dnssecKeysTitle"] = "DNSSEC Keys";
$_ADDONLANG["dnssecKeysCountLabel"] = "keys";
$_ADDONLANG["dnssecCopyTooltip"] = "Copy to clipboard";
$_ADDONLANG["dnssecZskAutoTooltip"] = "The ZSK is rotated automatically by the platform";
$_ADDONLANG["dnssecSignZoneTooltip"] = "Signs your DNS zone and generates ZSK/KSK cryptographic keys. DS records will then be available for registrar-level activation. May take up to 48 hours.";
$_ADDONLANG["dnssecDisableTooltip"] = "Removes the cryptographic signing from your DNS zone. DNSSEC protection will be deactivated.";
// DNSSEC per-key status badges and descriptions (mirror the CNR control panel)
$_ADDONLANG["dnssecStatusPending"] = "PENDING";
$_ADDONLANG["dnssecStatusReady"] = "READY";
$_ADDONLANG["dnssecStatusActive"] = "ACTIVE";
$_ADDONLANG["dnssecDescPending"] = "Waiting for DNS propagation (pending acknowledgement).";
$_ADDONLANG["dnssecDescActivating"] = "Key activation in progress.";
$_ADDONLANG["dnssecDescConfigured"] = "DNSSEC successfully configured.";
// DNSSEC: info panel shown when the zone is not yet signed
$_ADDONLANG["dnssecNotSignedInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>Your DNS zone is capable of using DNSSEC.</strong>
            <p class="mb-1 mt-1">Clicking <em>Sign DNS Zone &amp; Generate ZSK/KSK Keys</em> will:</p>
            <ul class="mb-2 pl-3">
                <li>Cryptographically sign your DNS zone</li>
                <li>Automatically generate a <b>ZSK</b> (Zone Signing Key) and <b>KSK</b> (Key Signing Key)</li>
                <li>Produce <b>DS records</b> that are then published at the registrar level to complete DNSSEC activation</li>
            </ul>
            <div class="text-muted small">
                <i class="fas fa-clock mr-1"></i> This process may take up to <b>48 hours</b> to complete.
                Once signed, DS records will be automatically imported into your domain\'s DNSSEC settings.
            </div>
        </div>
    </div>
';
// DNSSEC: info panel shown when signing is in progress (pending)
$_ADDONLANG["dnssecPendingInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-hourglass-half text-warning mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>The zone signing process has been initiated.</strong>
            <p class="mb-1 mt-1">ZSK/KSK Keys are being generated. This may take up to <b>48 hours</b> to complete.</p>
            <div class="text-muted small">
                Once signing is complete, DS records will appear here and can be published at the registrar level.
                No further action is needed at this time.
            </div>
        </div>
    </div>
';
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC is <span class="font-weight-bold">active</span> on your DNS zone.
            </strong>
            <div class="text-info mb-2">
                However, the DNSSEC records on your domain may not match those in your DNS zone.
            </div>
            <div class="text-muted mb-2">
                <em>Tip:</em> You can manage DNSSEC in the 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC Management</u>
                </a> section.
            </div>
            <div class="text-muted">
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';
// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Great news! DNSSEC is fully active and secured for your domain.
            </strong>
            <div class="text-success mb-2">
                The DNSSEC records in your DNS zone and on your domain are signed and matched.
            </div>
            <div class="text-info mb-2">
                No further action is needed.
            </div>
            <div class="text-muted">
                <em>Tip:</em> You can 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>view and manage your DNSSEC records</u>
                </a> anytime in the DNSSEC Management section. 
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';
// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC is active on your DNS zone, and your activation request has been received.
            </strong>
            <div class="text-success mb-2">
                The DNSSEC records in your DNS zone are now synced with your domain.
            </div>
            <div class="text-info mb-2">
                No further action is required at this moment, but you can update the records manually if needed.
            </div>
            <div class="text-muted mb-2">
                <em>Tip:</em> Manage your DNSSEC settings in the 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC Management</u>
                </a> section.
            </div>
            <div class="text-muted">
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingTitle"] = "Web Forwarding";
$_ADDONLANG["webForwardingDescription"] = "Manage your web forwarding settings for the domain ";
$_ADDONLANG["webForwardingProcessingMessage"] = "Processing...";
$_ADDONLANG["webForwardingAddNew"] = "Add New Web Forwarding";
$_ADDONLANG["webForwardingUrlType"] = "URL Redirect";
$_ADDONLANG["webForwardingFrameType"] = "URL Frame";
$_ADDONLANG["webForwardingTrdType"] = "Temporary Redirect";
$_ADDONLANG["webForwardingTargetHelp"] = "Enter the full URL including http:// or https://";
$_ADDONLANG["webForwardingUrlDescription"] = "Redirects to the target URL (visible in address bar)";
$_ADDONLANG["webForwardingFrameDescription"] = "Shows target URL within a frame (hides target in address bar)";
$_ADDONLANG["webForwardingTrdDescription"] = "Temporary redirect (HTTP 302) - useful for temporary moves";
$_ADDONLANG["webForwardingSaveButton"] = "Save Web Forwarding";
$_ADDONLANG["webForwardingCancelButton"] = "Cancel";
$_ADDONLANG["webForwardingGetStarted"] = "Create your first web forwarding rule to redirect or frame your domain.";
$_ADDONLANG["webForwardingSource"] = "Source";
$_ADDONLANG["webForwardingTargetLabel"] = "Target";
$_ADDONLANG["webForwardingEdit"] = "Edit";
$_ADDONLANG["webForwardingDelete"] = "Delete";
$_ADDONLANG["webForwardingVisitorsSeeUrl"] = "Visitors will see";
$_ADDONLANG["webForwardingInBrowser"] = "in their browser";
$_ADDONLANG["webForwardingDomainVisible"] = "Your domain stays visible while showing content from the target";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "No Web Forwarding Configured";
$_ADDONLANG["webForwardingCreateButton"] = "Create Web Forwarding";
$_ADDONLANG["webForwardingDeleteConfirm"] = "Confirm Deletion";
$_ADDONLANG["webForwardingSourceHostname"] = "Source Hostname";
$_ADDONLANG["webForwardingTargetUrl"] = "Target URL";
$_ADDONLANG["webForwardingStep1"] = "Step 1: Choose Forwarding Type";
$_ADDONLANG["webForwardingStep2"] = "Step 2: Configure Forwarding";
$_ADDONLANG["webForwardingExampleLabel"] = "Example:";
$_ADDONLANG["webForwardingAllowsPaths"] = "Allows paths • HTTP 301";
$_ADDONLANG["webForwardingNoPaths302"] = "No paths • HTTP 302";
$_ADDONLANG["webForwardingNoPathsKeepsDomain"] = "No paths • Keeps domain visible";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ or www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.example.com/path";
$_ADDONLANG["webForwardingRootDomainInfo"] = "Use @ for root domain or enter a valid subdomain";
$_ADDONLANG["webForwardingUrlValidation"] = "Please enter a valid URL (http:// or https://)";
$_ADDONLANG["webForwardingTemporaryRedirectInfo"] = "Temporary redirect (HTTP 302) - useful for short-term redirects or testing";
$_ADDONLANG["webForwardingFrameInfo"] = "Shows target URL within a frame (keeps your domain in address bar)";
