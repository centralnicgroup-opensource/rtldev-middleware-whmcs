<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - English
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Add Record";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "Cancel Changes";
// Save Changes
$_ADDONLANG["saveChanges"] = "Save Changes";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Type";
// Priority
$_ADDONLANG["priority"] = "Priority";
// Address
$_ADDONLANG["address"] = "Address";
// Hostname
$_ADDONLANG["hostname"] = "Hostname";
// MX Description
$_ADDONLANG["mxdesc"] = "* Priority Record for MX and SRV Only";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "There are pending changes to your DNS records. Please review and save your changes.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "No DNS records found.";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "This zone is not active because your domain has not the correct nameservers configured.<br>Please set your nameservers to: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "DNSSEC Management for DNS Zone";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "View DNSSEC Records";
// Oops Error
$_ADDONLANG["oopsError"] = "Oops! An error occurred.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Signing Process is PENDING";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC IS NOT ACTIVE</b>";
// Auto Activate Button
$_ADDONLANG["autoActivateBtn"] = "Auto-import DNSSEC records & activate DNSSEC for your domain";
// Auto Update Button
$_ADDONLANG["autoUpdateBtn"] = "Auto-update DNSSEC records for your domain";
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC is <span class="font-weight-bold">active</span> on your DNS zone.
            </strong>
            <div class="text-info mb-2">
                However, the DNSSEC records on your domain may not match those in your DNS zone.
            </div>
            <div class="text-muted mb-2">
                <em>Tip:</em> You can manage DNSSEC in the 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC Management</u>
                </a> section.
            </div>
            <div class="text-muted">
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';
// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Great news! DNSSEC is fully active and secured for your domain.
            </strong>
            <div class="text-success mb-2">
                The DNSSEC records in your DNS zone and on your domain are signed and matched.
            </div>
            <div class="text-info mb-2">
                No further action is needed.
            </div>
            <div class="text-muted">
                <em>Tip:</em> You can 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>view and manage your DNSSEC records</u>
                </a> anytime in the DNSSEC Management section. 
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';
// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC is active on your DNS zone, and your activation request has been received.
            </strong>
            <div class="text-success mb-2">
                The DNSSEC records in your DNS zone are now synced with your domain.
            </div>
            <div class="text-info mb-2">
                No further action is required at this moment, but you can update the records manually if needed.
            </div>
            <div class="text-muted mb-2">
                <em>Tip:</em> Manage your DNSSEC settings in the 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC Management</u>
                </a> section.
            </div>
            <div class="text-muted">
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingTitle"] = "Web Forwarding";
$_ADDONLANG["webForwardingDescription"] = "Manage your web forwarding settings for the domain ";
$_ADDONLANG["webForwardingProcessingMessage"] = "Processing...";
$_ADDONLANG["webForwardingAddNew"] = "Add New Web Forwarding";
$_ADDONLANG["webForwardingUrlType"] = "URL Redirect";
$_ADDONLANG["webForwardingFrameType"] = "URL Frame";
$_ADDONLANG["webForwardingTrdType"] = "Temporary Redirect";
$_ADDONLANG["webForwardingTargetHelp"] = "Enter the full URL including http:// or https://";
$_ADDONLANG["webForwardingUrlDescription"] = "Redirects to the target URL (visible in address bar)";
$_ADDONLANG["webForwardingFrameDescription"] = "Shows target URL within a frame (hides target in address bar)";
$_ADDONLANG["webForwardingTrdDescription"] = "Temporary redirect (HTTP 302) - useful for temporary moves";
$_ADDONLANG["webForwardingSaveButton"] = "Save Web Forwarding";
$_ADDONLANG["webForwardingCancelButton"] = "Cancel";
$_ADDONLANG["webForwardingGetStarted"] = "Create your first web forwarding rule to redirect or frame your domain.";
$_ADDONLANG["webForwardingSource"] = "Source";
$_ADDONLANG["webForwardingTargetLabel"] = "Target";
$_ADDONLANG["webForwardingEdit"] = "Edit";
$_ADDONLANG["webForwardingDelete"] = "Delete";
$_ADDONLANG["webForwardingVisitorsSeeUrl"] = "Visitors will see";
$_ADDONLANG["webForwardingInBrowser"] = "in their browser";
$_ADDONLANG["webForwardingDomainVisible"] = "Your domain stays visible while showing content from target";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "No Web Forwarding Configured";
$_ADDONLANG["webForwardingCreateButton"] = "Create Web Forwarding";
$_ADDONLANG["webForwardingDeleteConfirm"] = "Confirm Deletion";
$_ADDONLANG["webForwardingSourceHostname"] = "Source Hostname";
$_ADDONLANG["webForwardingTargetUrl"] = "Target URL";
$_ADDONLANG["webForwardingStep1"] = "Step 1: Choose Forwarding Type";
$_ADDONLANG["webForwardingStep2"] = "Step 2: Configure Forwarding";
$_ADDONLANG["webForwardingExampleLabel"] = "Example:";
$_ADDONLANG["webForwardingAllowsPaths"] = "Allows paths • HTTP 301";
$_ADDONLANG["webForwardingNoPaths302"] = "No paths • HTTP 302";
$_ADDONLANG["webForwardingNoPathsKeepsDomain"] = "No paths • Keeps domain";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ or www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.example.com/path";
$_ADDONLANG["webForwardingRootDomainInfo"] = "Use @ for root domain or enter a valid subdomain";
$_ADDONLANG["webForwardingUrlValidation"] = "Please enter a valid URL (http:// or https://)";
$_ADDONLANG["webForwardingTemporaryRedirectInfo"] = "Temporary redirect (HTTP 302) - useful for short-term redirects or testing";
$_ADDONLANG["webForwardingFrameInfo"] = "Shows target URL within a frame (keeps your domain in address bar)";
