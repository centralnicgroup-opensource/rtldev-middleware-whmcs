<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - German
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Eintrag hinzufügen";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "Änderungen verwerfen";
// Save Changes
$_ADDONLANG["saveChanges"] = "Änderungen speichern";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Typ";
// Priority
$_ADDONLANG["priority"] = "Priorität";
// Address
$_ADDONLANG["address"] = "Adresse";
// Hostname
$_ADDONLANG["hostname"] = "Hostname";
// MX Description
$_ADDONLANG["mxdesc"] = "* Prioritätseintrag nur für MX und SRV";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "Es gibt ausstehende Änderungen an Ihren DNS-Einträgen. Bitte überprüfen und speichern Sie Ihre Änderungen.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "Keine DNS-Einträge gefunden.";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "Diese Zone ist nicht aktiv, da Ihre Domain nicht die korrekten Nameserver konfiguriert hat.<br>Bitte setzen Sie Ihre Nameserver auf: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "DNSSEC-Verwaltung für DNS-Zone";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "DNSSEC-Einträge anzeigen";
// Oops Error
$_ADDONLANG["oopsError"] = "Ups! Ein Fehler ist aufgetreten.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Signierungsprozess AUSSTEHEND";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC IST NICHT AKTIV</b>";
// Auto Activate Button
$_ADDONLANG["autoActivateBtn"] = "DNSSEC-Einträge automatisch importieren & DNSSEC für Ihre Domain aktivieren";
// Auto Update Button
$_ADDONLANG["autoUpdateBtn"] = "DNSSEC-Einträge für Ihre Domain automatisch aktualisieren";
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC ist in Ihrer DNS-Zone <span class="font-weight-bold">aktiv</span>.
            </strong>
            <div class="text-info mb-2">
                Allerdings stimmen die DNSSEC-Einträge Ihrer Domain möglicherweise nicht mit denen in Ihrer DNS-Zone überein.
            </div>
            <div class="text-muted mb-2">
                <em>Tipp:</em> Sie können DNSSEC im Bereich 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC-Verwaltung</u>
                </a> verwalten.
            </div>
            <div class="text-muted">
                DNSSEC-Änderungen können aufgrund von DNS-Propagierungsverzögerungen bis zu <b>24-48 Stunden</b> dauern, bis sie im Internet verbreitet sind.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Großartige Neuigkeiten! DNSSEC ist für Ihre Domain vollständig aktiv und gesichert.
            </strong>
            <div class="text-success mb-2">
                Die DNSSEC-Einträge in Ihrer DNS-Zone und auf Ihrer Domain sind signiert und stimmen überein.
            </div>
            <div class="text-info mb-2">
                Keine weiteren Maßnahmen erforderlich.
            </div>
            <div class="text-muted">
                <em>Tipp:</em> Sie können Ihre 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC-Einträge jederzeit einsehen und verwalten</u>
                </a> im Bereich DNSSEC-Verwaltung. 
                DNSSEC-Änderungen können aufgrund von DNS-Propagierungsverzögerungen bis zu <b>24-48 Stunden</b> dauern, bis sie im Internet verbreitet sind.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC ist in Ihrer DNS-Zone aktiv, und Ihre Aktivierungsanfrage wurde empfangen.
            </strong>
            <div class="text-success mb-2">
                Die DNSSEC-Einträge in Ihrer DNS-Zone sind jetzt mit Ihrer Domain synchronisiert.
            </div>
            <div class="text-info mb-2">
                Derzeit sind keine weiteren Maßnahmen erforderlich, aber Sie können die Einträge bei Bedarf manuell aktualisieren.
            </div>
            <div class="text-muted mb-2">
                <em>Tipp:</em> Verwalten Sie Ihre DNSSEC-Einstellungen im Bereich 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC-Verwaltung</u>
                </a>.
            </div>
            <div class="text-muted">
                DNSSEC-Änderungen können aufgrund von DNS-Propagierungsverzögerungen bis zu <b>24-48 Stunden</b> dauern, bis sie im Internet verbreitet sind.
            </div>
        </div>
    </div>
';
