<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - German
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Eintrag hinzufügen";
// Cancel Changes
$_ADDONLANG["cancelChanges"] = "Änderungen verwerfen";
// Save Changes
$_ADDONLANG["saveChanges"] = "Änderungen speichern";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Typ";
// Priority
$_ADDONLANG["priority"] = "Priorität";
// Address
$_ADDONLANG["address"] = "Adresse";
// Hostname
$_ADDONLANG["hostname"] = "Hostname";
// MX Description
$_ADDONLANG["mxdesc"] = "* Prioritätseintrag nur für MX und SRV";
// Pending Changes
$_ADDONLANG["pendingChanges"] = "Es gibt ausstehende Änderungen an Ihren DNS-Einträgen. Bitte überprüfen und speichern Sie Ihre Änderungen.";
// Pending Delete Banner
$_ADDONLANG["pendingDeleteStatus"] = "Zum Löschen markiert";
$_ADDONLANG["pendingDeleteHint"] = "Klicke auf den Button <strong>«Änderungen verwerfen»</strong>, um die Löschung rückgängig zu machen.";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "Keine DNS-Einträge gefunden.";
// Add Record Form
$_ADDONLANG["addRecordNameLabel"] = "Name";
$_ADDONLANG["addRecordContentLabel"] = "Inhalt";
$_ADDONLANG["addRecordCancelBtn"] = "Abbrechen";
$_ADDONLANG["addRecordSaveBtn"] = "Speichern";
// Add Record Validation
$_ADDONLANG["hostRequired"] = "Host ist erforderlich.";
$_ADDONLANG["addressRequired"] = "Adresse ist erforderlich.";
// Copy to Clipboard
$_ADDONLANG["copyAddress"] = "In die Zwischenablage kopieren";
$_ADDONLANG["copiedToClipboard"] = "Kopiert";
// Zone Import / Export Controls
$_ADDONLANG["searchDnsRecordsPlaceholder"] = "DNS-Einträge durchsuchen";
$_ADDONLANG["importAndExportBtn"] = "Import und Export";
$_ADDONLANG["addRecordBtn"] = "Eintrag hinzufügen";
$_ADDONLANG["importDnsRecordsTitle"] = "DNS-Einträge importieren";
$_ADDONLANG["importDnsRecordsDesc"] = "Laden Sie eine Zonendatei hoch, um DNS-Einträge zu importieren";
$_ADDONLANG["importWarningLabel"] = "Wichtig:";
$_ADDONLANG["importWarningText"] = "Das Importieren einer Zonendatei ersetzt alle vorhandenen DNS-Einträge. Exportieren Sie zuerst Ihre aktuellen Einträge, wenn Sie ein Backup behalten möchten.";
$_ADDONLANG["selectFileOrDragText"] = "Datei auswählen oder hierher ziehen";
$_ADDONLANG["browseFilesBtn"] = "Dateien durchsuchen";
$_ADDONLANG["applyImportedRecordsBtn"] = "Importierte Einträge übernehmen";
$_ADDONLANG["exportDnsRecordsTitle"] = "DNS-Einträge exportieren";
$_ADDONLANG["exportDnsRecordsDesc"] = "Laden Sie alle DNS-Einträge als Zonendatei im Standardformat herunter";
$_ADDONLANG["exportInfoText"] = "Die exportierte Datei enthält alle DNS-Einträge im BIND-Zonendateiformat";
$_ADDONLANG["exportZoneFileBtn"] = "Zonendatei exportieren";
$_ADDONLANG["closeBtn"] = "Schließen";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "Diese Zone ist nicht aktiv, da für Ihre Domain nicht die korrekten Nameserver konfiguriert sind.<br>Bitte setzen Sie Ihre Nameserver auf: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "DNSSEC-Verwaltung für die DNS-Zone";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "DNSSEC-Einträge anzeigen";
// Oops Error
$_ADDONLANG["oopsError"] = "Ups! Ein Fehler ist aufgetreten.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Signierung ausstehend";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC IST NICHT AKTIV</b>";
// Auto Activate Button — überträgt DS-Einträge aus der signierten DNS-Zone zur Domain
$_ADDONLANG["autoActivateBtn"] = "DS-Einträge zur Domain übertragen";
// Auto Update Button — aktualisiert DS-Einträge nach einem KSK-Rollover
$_ADDONLANG["autoUpdateBtn"] = "DS-Einträge auf Domain aktualisieren";
// DNSSEC Sign Zone Button (replaces generic "Enable")
$_ADDONLANG["dnssecSignZoneBtn"] = "DNS-Zone signieren &amp; ZSK/KSK-Schlüssel generieren";
// DNSSEC keys table column headers
$_ADDONLANG["dnssecKeyType"] = "Typ";
$_ADDONLANG["dnssecKeyStatus"] = "Status";
$_ADDONLANG["dnssecDsRecord"] = "DS-Eintrag (SHA-256)";
$_ADDONLANG["dnssecAction"] = "Aktion";
// KSK rollover action buttons
$_ADDONLANG["dnssecRolloverKskBtn"] = "KSK-Rollover";
$_ADDONLANG["dnssecRolloverKskTooltip"] = "Einen KSK-Rollover einleiten. Ein neuer Key Signing Key wird generiert. Anschließend müssen Sie den neuen DS-Eintrag in der übergeordneten Zone hinterlegen und den Rollover abschließen. Empfohlen alle 1-2 Jahre.";
$_ADDONLANG["dnssecFinishRolloverBtn"] = "Rollover abschließen";
$_ADDONLANG["dnssecZskAutomatic"] = "Automatisch";
// DNSSEC keys table labels & tooltips
$_ADDONLANG["dnssecKeysTitle"] = "DNSSEC-Schlüssel";
$_ADDONLANG["dnssecKeysCountLabel"] = "Schlüssel";
$_ADDONLANG["dnssecCopyTooltip"] = "In die Zwischenablage kopieren";
$_ADDONLANG["dnssecZskAutoTooltip"] = "Der ZSK wird automatisch von der Plattform erneuert";
$_ADDONLANG["dnssecSignZoneTooltip"] = "Signiert Ihre DNS-Zone und generiert ZSK/KSK-Schlüssel. Die DS-Einträge stehen anschließend zur Aktivierung auf Registrar-Ebene bereit. Kann bis zu 48 Stunden dauern.";
$_ADDONLANG["dnssecDisableTooltip"] = "Entfernt die kryptografische Signierung Ihrer DNS-Zone. Der DNSSEC-Schutz wird deaktiviert.";
// DNSSEC per-key status badges and descriptions (mirror the CNR control panel)
$_ADDONLANG["dnssecStatusPending"] = "AUSSTEHEND";
$_ADDONLANG["dnssecStatusReady"] = "BEREIT";
$_ADDONLANG["dnssecStatusActive"] = "AKTIV";
$_ADDONLANG["dnssecDescPending"] = "Warten auf DNS-Propagierung (Bestätigung ausstehend).";
$_ADDONLANG["dnssecDescActivating"] = "Schlüsselaktivierung läuft.";
$_ADDONLANG["dnssecDescConfigured"] = "DNSSEC erfolgreich konfiguriert.";
// DNSSEC: info panel shown when the zone is not yet signed
$_ADDONLANG["dnssecNotSignedInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>Ihre DNS-Zone unterstützt DNSSEC.</strong>
            <p class="mb-1 mt-1">Das Klicken auf <em>DNS-Zone signieren &amp; ZSK/KSK-Schlüssel generieren</em> wird:</p>
            <ul class="mb-2 pl-3">
                <li>Ihre DNS-Zone kryptografisch signieren</li>
                <li>Automatisch einen <b>ZSK</b> (Zone Signing Key) und <b>KSK</b> (Key Signing Key) generieren</li>
                <li><b>DS-Einträge</b> erstellen, die anschließend auf Registrar-Ebene veröffentlicht werden, um die DNSSEC-Aktivierung abzuschließen</li>
            </ul>
            <div class="text-muted small">
                <i class="fas fa-clock mr-1"></i> Dieser Vorgang kann bis zu <b>48 Stunden</b> dauern.
                Nach dem Signieren werden DS-Einträge automatisch in die DNSSEC-Einstellungen Ihrer Domain importiert.
            </div>
        </div>
    </div>
';
// DNSSEC: info panel shown when signing is in progress (pending)
$_ADDONLANG["dnssecPendingInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-hourglass-half text-warning mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>Der Prozess zur Zonensignierung wurde gestartet.</strong>
            <p class="mb-1 mt-1">ZSK/KSK-Schlüssel werden generiert. Dieser Vorgang kann bis zu <b>48 Stunden</b> dauern.</p>
            <div class="text-muted small">
                Nach Abschluss der Signierung erscheinen DS-Einträge hier und können auf Registrar-Ebene veröffentlicht werden.
                Es sind derzeit keine weiteren Maßnahmen erforderlich.
            </div>
        </div>
    </div>
';
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC ist in Ihrer DNS-Zone <span class="font-weight-bold">aktiv</span>.
            </strong>
            <div class="text-info mb-2">
                Allerdings stimmen die DNSSEC-Einträge Ihrer Domain möglicherweise nicht mit denen in Ihrer DNS-Zone überein.
            </div>
            <div class="text-muted mb-2">
                <em>Tipp:</em> Sie können DNSSEC im Bereich 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC-Verwaltung</u>
                </a> verwalten.
            </div>
            <div class="text-muted">
                DNSSEC-Änderungen können aufgrund von DNS-Propagierungsverzögerungen bis zu <b>24-48 Stunden</b> dauern, bis sie im Internet verbreitet sind.
            </div>
        </div>
    </div>
';

// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Großartige Neuigkeiten! DNSSEC ist für Ihre Domain vollständig aktiv und gesichert.
            </strong>
            <div class="text-success mb-2">
                Die DNSSEC-Einträge in Ihrer DNS-Zone und auf Ihrer Domain sind signiert und stimmen überein.
            </div>
            <div class="text-info mb-2">
                Keine weiteren Maßnahmen erforderlich.
            </div>
            <div class="text-muted">
                <em>Tipp:</em> Sie können Ihre DNSSEC-Einträge jederzeit im Bereich
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC-Verwaltung</u>
                </a> einsehen und verwalten.
                DNSSEC-Änderungen können aufgrund von DNS-Propagierungsverzögerungen bis zu <b>24-48 Stunden</b> dauern, bis sie im Internet verbreitet sind.
            </div>
        </div>
    </div>
';

// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC ist in Ihrer DNS-Zone aktiv, und Ihre Aktivierungsanfrage wurde empfangen.
            </strong>
            <div class="text-success mb-2">
                Die DNSSEC-Einträge in Ihrer DNS-Zone sind jetzt mit Ihrer Domain synchronisiert.
            </div>
            <div class="text-info mb-2">
                Derzeit sind keine weiteren Maßnahmen erforderlich, aber Sie können die Einträge bei Bedarf manuell aktualisieren.
            </div>
            <div class="text-muted mb-2">
                <em>Tipp:</em> Verwalten Sie Ihre DNSSEC-Einstellungen im Bereich 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC-Verwaltung</u>
                </a>.
            </div>
            <div class="text-muted">
                DNSSEC-Änderungen können aufgrund von DNS-Propagierungsverzögerungen bis zu <b>24-48 Stunden</b> dauern, bis sie im Internet verbreitet sind.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingTitle"] = "Web-Weiterleitung";
$_ADDONLANG["webForwardingDescription"] = "URL- und Frame-Weiterleitungen verwalten für ";
$_ADDONLANG["webForwardingProcessingMessage"] = "Verarbeitung läuft...";
$_ADDONLANG["webForwardingAddNew"] = "Neue Web-Weiterleitung hinzufügen";
$_ADDONLANG["webForwardingUrlType"] = "URL-Weiterleitung";
$_ADDONLANG["webForwardingTrdType"] = "Temporäre Weiterleitung";
$_ADDONLANG["webForwardingFrameType"] = "URL-Frame";
$_ADDONLANG["webForwardingTargetHelp"] = "Geben Sie die vollständige URL einschließlich http:// oder https:// ein";
$_ADDONLANG["webForwardingUrlDescription"] = "Leitet zur Ziel-URL weiter (sichtbar in der Adressleiste)";
$_ADDONLANG["webForwardingTrdDescription"] = "Temporäre Weiterleitung (HTTP 302) - nützlich für vorübergehende Änderungen";
$_ADDONLANG["webForwardingFrameDescription"] = "Zeigt die Ziel-URL in einem Frame an (verbirgt das Ziel in der Adressleiste)";
$_ADDONLANG["webForwardingSaveButton"] = "Web-Weiterleitung speichern";
$_ADDONLANG["webForwardingCancelButton"] = "Abbrechen";
$_ADDONLANG["webForwardingGetStarted"] = "Erstellen Sie Ihre erste Web-Weiterleitungsregel, um Ihre Domain umzuleiten oder zu framen.";
$_ADDONLANG["webForwardingSource"] = "Quelle";
$_ADDONLANG["webForwardingTargetLabel"] = "Ziel";
$_ADDONLANG["webForwardingEdit"] = "Bearbeiten";
$_ADDONLANG["webForwardingDelete"] = "Löschen";
$_ADDONLANG["webForwardingVisitorsSeeUrl"] = "Besucher sehen";
$_ADDONLANG["webForwardingInBrowser"] = "in ihrem Browser";
$_ADDONLANG["webForwardingDomainVisible"] = "Ihre Domain bleibt sichtbar, während Inhalte von der Ziel-URL angezeigt werden";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "Keine Web-Weiterleitung konfiguriert";
$_ADDONLANG["webForwardingCreateButton"] = "Web-Weiterleitung erstellen";
$_ADDONLANG["webForwardingDeleteConfirm"] = "Löschung bestätigen";
$_ADDONLANG["webForwardingSourceHostname"] = "Quell-Hostname";
$_ADDONLANG["webForwardingTargetUrl"] = "Ziel-URL";
$_ADDONLANG["webForwardingStep1"] = "Schritt 1: Weiterleitungstyp wählen";
$_ADDONLANG["webForwardingStep2"] = "Schritt 2: Weiterleitung konfigurieren";
$_ADDONLANG["webForwardingExampleLabel"] = "Beispiel:";
$_ADDONLANG["webForwardingAllowsPaths"] = "Erlaubt Pfade • HTTP 301";
$_ADDONLANG["webForwardingNoPaths302"] = "Keine Pfade • HTTP 302";
$_ADDONLANG["webForwardingNoPathsKeepsDomain"] = "Keine Pfade • Domain bleibt sichtbar";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ oder www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.beispiel.de/pfad";
$_ADDONLANG["webForwardingRootDomainInfo"] = "Verwenden Sie @ für die Root-Domain oder geben Sie eine gültige Subdomain ein";
$_ADDONLANG["webForwardingUrlValidation"] = "Bitte geben Sie eine gültige URL (http:// oder https://) ein";
$_ADDONLANG["webForwardingTemporaryRedirectInfo"] = "Temporäre Weiterleitung (HTTP 302) – ideal für kurzfristige Weiterleitungen oder Tests";
$_ADDONLANG["webForwardingFrameInfo"] = "Zeigt die Ziel-URL in einem Frame an (Ihre Domain bleibt in der Adressleiste)";
