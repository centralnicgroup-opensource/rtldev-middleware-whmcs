<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzuvSuou1aYaHOlchx2rXt6/+gucv7kUNvYuT04KwGi6bcN5+ENEM5EkYKnKw1ws2g2RUlal
t9CgbX4OhRPRJ4h9rg5aq+hI/uau61RBa3d16GErPdV9NoqQxtFwc/Rj3KIaQrI6J0ZS7aYQ6alT
q9TEu5qhr0rIFfAd06mUvsu913LVCKaD2jgemM01XCUvkrbm7BuiFxpafTPK3azbMBbpljhO7LDF
3e1ifRLRGdsdyxbZ9NeHnkgZxUgRWpKuuO8WmbNL3Aaz1Aeez3//eS++riTdQ0fY6AsjYXCMCH1u
+yTs/uAF0kcUywTRt2n+IintdfYRuHYnAnykdXz/O4kKmWK7GcpkggZ/DCvWt3L1MV8VcxDfEWBQ
W+SWXizO0kTZft6heGgm4he3wfOSuG3OxbEtcAdfLBgPwixo9mrIh+jwej3D/RNX6gf9ZPMn5k2E
bivqH5qhttFUvipPTDtLD4qesGpQbHAM01NSGGE9840sae7pDA9PDdT2jKVA5C0TYawwG51G7fRy
PR0BWrUnNb98zIxlqoc0wI39B/7F88B5WeDtx0sm/OSL5lqMwcBJBE2ovey08SUetDrvdqIBShrk
+HvZgE9twkt7c2yHXnJk9q6aHR6TOfJgtEYY0q/5oWR/AXzfRZhAg+5HGHbrrcjF4L8En1BC/sil
PgKIdQ7KunFMf207IIebuXYM4o7GvSHo/5AOOSOFgeOHZg4PuL3ZGD8L1ETBIUNSXwvYfeFqFeAB
+/kRqOLIYQp7K1pSI02caDi+US9Io2vtoLfO1g41BVZWFdIoEp3rasi/pAqxDSwsvMhbJPLUef+X
sYxLafZY/nIkeQ8xUlLzWgLfhdzEcuzH9x6pxLDhW8/LCoc0uQxvv2zJ3xNj4pFzgHFM4KTHN9R4
VZL0ebJa/Vv6LxILj0yCn2qS/gwuEkU4CAIie563tmpbQESoyf6VTmanbEXQfFX4IEMNfP+tJshM
zLJKMRBM/AcCzmqAGLnY/yXEfC16oWeXpMt6dGMILXjvDgC9ytXtneu0xU4w2m3RVsOMqU21L/Ls
FRL/nLxoD1cqRIYUHeDckPGpFMBcYJjAcD/wzHqfSennajqaIE2jQGsutti09d2OBN7NdiSF5Idi
b5WYY4tG7mnvsa8+azjFc0Dqbg/duAXj/oDgBKfGV9tuzGd386WwDnuSHbOrE5u/g/wXgDIVoZSX
C1kRwGCJBXUuCM7/cO1CJBRQpALtA31gLMT1atIYixafcfqH5er/V8b4fIOaYy0Cg9uSWA+dhE3N
+nanxey0MD+YdTggm7FNjSRQkUUU5Yo+rbANI3HyV5VyB5WcEUWN4mhLzcCSIfwLZmotJZfGoQUy
O2zzriGuk8ZOW+EVPCzPoc4aqEaDQIUi4/8B7L6I0vhcVqgSCORS0SMm9FzWKTN3zKFI+5CQUNxX
wjx28LGPFXTTIHBlpMWfdZcTifDZMX2O+MEeMMgfbWpcmChz8WoMwszH5DGdqBxm1h9amPgsNodh
0qz0uozDDpvrqx/0aFrvorHnvg5FZCmb5YrZuiXffgapUn7tE1jhCgsYKkL6BTSrLWNqaMgfxTcH
Op3Qu+lYOH3j4Pdl2/OM7A8AOnpPj/5nWJ+1bPGk3CIYnk7zs94ClM3GJRLZSMnHjfS0p1Cp7RTO
pvodli/ocwm1qNf5vIoIl6XkSzIRyMHp90x/n0nTB7uh2a2fF+1bmlsZg8XTLFDUatd3lo+czCSj
mCyFG9VX2eUR6ZErQqKSY9j2WLBeyHxicar8IMc58zAVITyqX63dk803u++VrswHQuaUElwl/GR0
96GiKgAJVNHRsiLbgSp2SqpZ+h70s/N+BMc7yQWLiF7UkQcY6WJa7TE8tw6wfbah10==