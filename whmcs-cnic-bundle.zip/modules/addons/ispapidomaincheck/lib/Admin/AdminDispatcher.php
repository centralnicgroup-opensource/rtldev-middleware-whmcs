<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsiBemhcrHSj/mMvDYdFi0FXCx5tZ/u15QUupjl5YArVwReNeXOJLqLgG7OseJehvkZJfKgY
uCOfSHTfByNflXVh80TQucDqkiojPoQA05xUqpQOZfkuumpYX2pGlEbREbcGhF7P5etmiCFt8YwJ
MhDKzK0R7U4M8kWvuSbDyZ6YrXRSZLJD1TYvu94L4P1DCHNPPeGsUJMA+C8OYuKp/C+rz4Uqkbuw
MNyfPpXjMBDsAUKjByntySX1HuL4nHqVRBd74LZ16OUBPrHyK4fycPXPjyzdrZMq3hdqtZWxddjj
q6Tv/rZU2xw9d4f1yfKNJnMxipLBaZZPGf6oPt9Dcaubk2bWzME8NuEMMxvWfS8h/zEhcLLrbieB
SYnCd/T8CZ3V5ygzRT41Yd/7vGJ4Oi1xijurdiELE7CjpO2jFr/tDtc30jkoZyeEUUr/WmM9muTS
N5xrCJ60i7HxmD3+k5RomXnow2U/svS+criZLvWd2BXsKLnh3Ik7eN28eiUStmAN79FXMVgrpfKu
EA8vhSjdykmsZagp2w7/T6lPWMu8Su7yhY76FXNgvhqhliDN+AXV7pbajnHkmAfQ3grm4Tz3j7IP
ISx33jnzRH5mDTh75ns5K7I0dc92zXLP7QImKX2FQnfOybji1WktbKVgkbpwNQJtLHfKDj3XPMbG
7xXKGWyNOBsjeSemutiXNjSdFO8cxQdl71slzkXOmLGQlWjNpue3uzeHJM7hiwVbfMb3LTLwTMN1
gbmr9QKj0fhy2wOcpUy7voqhKw95Y4HJ065ca1rrxveFoS7uFrLbIXINCVmOTVMlffSnbR1EwGYR
AEBSaK8LNvbgvjPO6qhRb9Vswm1U34tUbLB4PxlPSDUA0E3eX/uLQmqgRtBTZvgYxTG8QCMx7YGY
1XxZ3JvEufqx3Bz8Rnny4idU9eDDDyDurc0nd0P+SPlTgPa0IXAhahzsEngDhDCXYmn/N1JFzTHP
vSoKktXhDl/bpVVA5+edyVrAbmPq+F6RPMV7vG2TLUy4VF7CDrl14v7DQ6WkoaPiZqYY4naoM8mF
91CB9dxXfdYgGElvbfTHebntuCcUlUAzER7fYKCrEhFl1FTL5G+XFQzRcfPNnlk5yid/YoUfyTLS
wNvNWLap/LkNxTVmohNt9DTdgBpaEctHgeY979qetsEJkcuo9QTQ1dxxqS0cpgAvCywD/CFGBjzY
olXbDEd8/ckoxid5pGpI94PbYCDEJuqxWoZH5K+AEqO+yGtFhudDCDxd+2ROXRKf0lbZu6Yq6gxB
P6e7NS2UcPYYpHV6Y5YdP7XqQaMNhkrUVeZneAJzFvvDdqPbMcbzpOGPhxqHW9Q9q1CSZkWYoiam
VDuZ43vs0aCcyVafGNxM2xSDjVp331wEe7/a02WrC4+71CT5kN9K0YBAPbQ9ZQsC/HM5JVu4HlYh
txCG+JU5znZtQG5e/OK+2qzWmXBxWpZ08h2E75Zup4olsSjGAzmXoHtgTtnj8lOv9xz5utsXKwql
o5EbOCJiLo0DoxFtIVPQD3TuChHG17aZQ/xUHxTiCIJmq4FHLJXZYyDYLAdGIuaC10plelNmwG3A
AgU7INmrlPXyFwjejaP9h3WlVBNt8lqH4e9JhwFSdEXIDIbnPHJgBceEClTk5s9WnjqanQHgzjxV
1x+1CMpA/JC0dboJ01cKlcos8YdwARI11f6mq2q9UX4BD5OWidAYUa9IVLG0ydvr83YZ2Bsj7MFy
aOpGNxI58YTKEGBxsLYhEIPQzwQCCFvYCSgYmsnaDz+2pdQ2Gmv3BlzuWQEbpC6xO28lqidWmkAj
rt+oYj3yZzjmJeY+wb6Pf9GRb/CSQgyQnYVgUMl34knhsLH1B55416QbRttxh5urVxWWK2Zh