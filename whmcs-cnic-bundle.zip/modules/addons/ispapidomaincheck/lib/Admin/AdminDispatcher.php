<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPphScS2f86Btj6uCuqYZFuB+rOKsD1XWCk2NzGU/EY626Pjic/AfJ26rArMOD+nTl3E8xr+r
waS606u/SCmINbW/yWY5MAU5XjWpGNaJz7awk8N56DMu2EFJxHNFKZCNGjL+zvj32bMid8PNt5UA
nPUECPZqZS3R5Ou5wKUPSsuZj2OgZgJuq6EXq9SYH7SGBOD4l/MsnqNe0iFS0fQtm25VV2rTL1du
1ybz/o0qZXHAugWWQZ2EyxEZbcLCWo6g3Q0Pmr3qNJq+iX0rSgIm6ilmbiDZPlH/T7D2hfZmGGs3
pIw71maD/5/GGFUoGMY7TLRrzJz7/4/8YSP4LryO0XZEIWrOGOwwPzbVBLGit7IY+YMWf7JPB1Nk
e4BCDTYRb5si9DnIt4lEfBwVHrbBOxYUed9m/J+KmA7hzxUne8q3+F+jrPRAz3BGlxRpzCwp5sZF
+YdlwibcpPJlLKaKt16iJlRskxGB2165Q3fMgq4XkzV022QrkzLZz7Kq4liJ4u3Q9jAPI+QG7QKS
pIPjex6g9SQG+0NIxWdr0wv39UBhu4obcZLO9fpzuv3XityanncFUovn/OBydSXkGvuKmcYd88/8
xCc29MMt6hoBnxBnDzLaR/zAppIAqLsW5ULw3pKcM7TCcdbL/nNtGNN/USF+FNzk7O8blt+RCzlc
EhD+/1GcUiiJPuRqwmYYJ3OHqrzHqXKYYxXTgr8o9Szh5oeJysWSHVR9mPYTVpzR30KMjeumfz2H
yIvmKUiLlY9fqEjAD7fDiYzQJzY4yHgqy+AEXM9tcV+m+/Gz3+KSiEDg6lIBCHjOC6KpKreFUuXw
KqJi/v1VRM/TFmIBwyXBhl8gBX3lJePwTOQRI2UWyAqv6ZjBujdV+6xqh4zGAxIFYos5vTWGgvDO
HqC7WTWlyszTXtfosLRzOZBtmJq7U+DrSBg1sESM1736K2U43lfGI+/1Qvt7OKba4Hj0pyo0EDVh
0Q1kC2YdvYh/bz5BGmbzRTQ26Vk9RoYzwBA9L+QNdiFFoiRtEtgZkUc6PCd9KCIlvrtlwnTc7KlR
bHJ0GOYzXJA27YCEfxPiuYvHMZQkHTY0WxpBAKyIH+w6NI71k3XbZvUNQLdEfmnBZrgLRnGmXr38
VQw0Ts/KUtRA8x7vqgSAz59OystOr/mKpzkAftXXaDt3GuIOSlTS10usSCFHH4poPgECmf89UTIh
xlw/fNftG6vZPWQcBMy8XKD6Hvqc/NCAtckIEZJTZUkg3m0xPf8J6lcp3nX5DCTw0AXx2IfUArf+
S8DMvm2yA2TDIuK9opUxNPIvxa50c8UnY4nvRd0oMdXsBYVaUaMI1Bb6oowUZ0NSwqYya9nby+aY
U6Xi60w8/1ZHDLuh7uK7oFtkNkd7HHxju8VKGOaLAgb73q5WIirPcrTjJ0ycMBXba1kQ00KPJoBI
+Q4iGwmWLqmRtRuAzwKeQVI9hGH6IuKH1n1GW/SJE9GWD/KDwMq+k6IgXoiKV0AuB+otvVjAIPXa
uJz/hS3yI8zkGCv7UCEmGvf7tz1DTZjSrtWMIKXYql/qb9v8V9BUh1cdyUiDaL3D71N5wU26Jhi2
b3HG8n0b8KMQEJ1nU0az+hedz/+iaB1mJd9WFcSBzHLzw7rvUT2+HJKBbZhyU1bmxlEBBUx742cK
NZKHPKo3/EZV1WK5KgY1SwXjDcaYatABMBMc7sYGoWuSE0/QfB4jYZTDpBVLuWiawxX1X5CcaAXw
QhsAzWW3NFsbj+RoH19ykBfTt/pYxR8QVPk0MA15iUFiepALfNG/Z7CMsMDwPk3zPJPikm1WPguH
FsD9X4gYu5qX50hiVvM2UtmkqPvAHKSpP9AFbvbq7aM1Sar4Yjr8BUtCUeAISh5QiAPi74vh8ByV
Imrz