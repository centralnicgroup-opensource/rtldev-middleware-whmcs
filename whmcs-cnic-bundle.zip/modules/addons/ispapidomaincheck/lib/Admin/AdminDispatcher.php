<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpGvGVcz1xh+k8lKsX3ZwRwZk52iWUTRjOkuvx+JYXCcSZt1b4U2FhcxzhMziGouRVQWHz/O
gp7nY+CPlWTsJUbZnCla5UBct/bvC+wSM7idOD73xTNKv74GjjIjOAtmm8fMDAxjn9NTViUxGhRK
zgVxQDr+x5sRBL2ge6qIHL+LW/UvGxr96tmWcqpdqb3tkmWQT56mR0xpI0FrsGYgLhC1IiLdwt2x
UrjoYZJmNUzstf9yxy+2hpgpSlfO3xT5m5wJnj+7fmxavcCZy2lxBYlnleLt0KqlIZjVFnqOKO/2
SAWlKdaoCZ8UYbsuHd1izumkw0Ouil6JIw70ZA0vSW5yIFz5L+33tT2w92Y8Lcsk12pPQObDR10x
y5PA78Bs0a5wtDsTyC/4Ju375qddAE1628/EEuwFgGYitk/skiGBYb1fnobWvkiE28ktbDgZFu/0
iMfTxtUgaYhbv3xsm4JkGgsNiR2qFXPVwMIXGpKABiHL6oxE8ds70h/+Gr7hVgmnJ160pYrV2n6T
DQwufhQ66lUMDiXOIKP8nMd2zh3SlrvD5nk/WnPLVUPZE/ZFfwQuEDaOEdGsIwg3LYoDRNQMdtmG
zwIJ3SgtLRNuW9+Bs0g2htpAXI+N6isgzVmiLz2Rc2JPFZ6e3cCgTwRi64630cZHiTW9JJQW7hrO
qy2YyNP4AOpBkZIXWeuQYpytyTxSRmUE1Y5PYvSJLe6om6FkuHWnl0TVPkO2CuTSMNl+9pVNaxcK
ljrfRwh+PBhQ1Tj7t72xUymzCS+y0UafLUMafjs8CjuJbe4NBQw4KevpkIvrrBR4hVOC6QwL7+py
HsGIeojTNsTLANvU+hTdRsNDOECgBD53kMEnTxkJ43USaVL0LklRKynJgPQXjGcHQcmeGyHLpiBX
4zEwPyOBhbgrPRoC7zqXWWG/1ylR2dIGEh5xkOkoESyxxPMtM7wZMuiBJCWKmsHdUwmJJa9BgPiv
fX86clFfwr8ELMk4LMGKb+/yET41PxYfM0iplScX5MsYsyd99BSmrjSTl8KcdyCSk+1wTX3s4OV2
DiEJ/wpsSrpowDtvlrmABvivXmlh0zaLLY3bVruJ3hjDH7IUjsFD0KXZOXSdPmXGhBtN6w6s88pF
9BBJ7vLB6fC+PBe1+JO9agXGn2seGLbTCIDJZ5nzYUYagvpeOsOEAq5aklKq8iInj3IT7sWvR/Ct
BX99+PXWazMdf1TpMJ96i+gavBN4kkiB2qV9AQBeprjbpvwBZLv9REFPv8UEHDom3mlLA3OIvtaX
q60/MJG7E92x5xcnD41SV4jVpsyW2+p0R0rNW7Ez3g4Ilmm6ZKZsv3e4/sTgKuGYQxbRWfuKuCaU
osaIwzGC+G9gJZ5gWd669gaH7q2wK/qwT+cH23Zar03FHweoA6kVLjTmI54lMZ6Ts73xmYkdbaDn
cIE+x0c12xzGXGjxdrBmTjGLObJFcKy3El/U0WI9XjMcSWpySULJvfjyjCpMXqYkQyIgwj5A7yog
+ddxUZgMFa22lP7Q4DwOWuDNjczEVFJi4Ik8LAnGp3um7CFcPJlD5fqxZJBcG0/vNQKV6eU1S229
Ef+nk9ob4lsNgk0ic7cDqIFQQa7GT8SWEKWYbfM7j98TZJFr3hiSwXYYH/tDgs/1/V5WZKqD4akL
faPYj4Qif09o8pNQRKijHcYkj4a84TSgg/zkdPiORYlHTlCNuZXu38j+Cd8qoB2zpMnMj+eO4tl5
cu5HYtTAQoFxsn7chvAqL2QkHLqsXT3ZbXg05A3+Pyp5oxSjZKLSun/2gnO8UFnH31hhFeDr410q
rs25cprLYRHcoktYrrY8amIjVXNTTWyj+nBpSZhOampVFXBS1aYC0DghwuHt4eCWy5XjhFn/00gA
lwX4rs4=