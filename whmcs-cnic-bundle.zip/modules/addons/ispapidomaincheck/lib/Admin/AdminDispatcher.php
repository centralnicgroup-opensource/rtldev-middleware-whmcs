<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr6WxvWxZDJVmX9wku2mG6htyIaUzP5pS8ouOAT4Nyo6qR1FlYyrY2WmSjPooUTLfIpK6cG0
IXfUuxD/bjmm7O431GHnA7tt12VwZCvm2J8zfpOsqiE+qZjMf0AWmLqTyQgM5Q27Mo2Y6S4GBu04
YlkUFkwS00dspmmqrZSidVmcwSzrE6Gr0APpQIaUoc39oH/6altfawFCamPzOrz7XyJ85v1FPQgS
BFaoQAy3LDbj8+BuHS7Bp82jV9RRaaWx/3O3MFfkl3Z78Es38Wkf2AQJCdrbeW2m9lN6ZNps8egn
QaX3SYst6X7QFdFuZy1Nqk2qM2lyju58wkbGa7YPTMsphuaJw2gWykDMvgNwbUAhnB8Gt7F9D7Sh
+w3lLlWjOeA2h31Mm+UabkAs7fKibbN0DUo27WVjsnK5NI8+ZbMaKgImD8TJRV5onLmg8o3pEs6j
8IEig8FaKe16AQvTx2ZqISCNVa/wHs0RU3DMX+RqWKnI+8CT603Gxom/be10QB4iBWSSe0L7+Dy/
hs4pTFCp/Hn0+o2yqqJrJU21zW0dhFxjMyxnH3VrXTNXQlZJEq822z1FuA6Zq+5bBCe5II1+TPPj
kPGuHQENX4nuSDnW2pIl2HfeqhIIQfAVTGjfeEoz/qQl3LLPCotV9aMEf+m5TSGMRgvvbwlTJwvw
rrpn4bb6GAgGPlDDcIohthaNjd5oYAYQVBYLq8Sj2+MpTBW6CtUqSaawInKiDdlUV8P3PQf88URo
9fzalukdSHbxAHZDYA+R9eZyeFahcgZUBZhGFaZ3r4LitYZLpcVsLjxTm3TnKQONTtrOqjQd8LPk
AuJ2h2G8XHbrk4Tg5vhN1WExR/G182sxUL/Q1aPgbKtOSh6U5G4VCONAdB/jnBGbKGkOwiemZK5N
Vfldc0z28Jz2vlRj5dkTU65nSISmoasx4OSvahewlzSjv8snMX/WVqo4zKnBUBWPOxtXeBiEJxpW
FGREnD1SXwwII5EFCVzS1d4IoSI1a9l9FT0lOm9QfeL8dACjzZRaSn4owUJMiJRb+S2gao0kiFh8
uGMp3NMEDNS0GUJKGnY+6Vy2Qx8+H9QCq8l98nBPAuJPSFv83KhuMOZW4fEaE98hCiyCXuy3gqlk
6VAhMib6/xywgsWuxN51qPn0AsSG4cbIyA5By9yq03/u1c0bXqiePaSu8EbhyVOcRLaajWVmcdmU
fHymYPT2TT3Zi1sk0H5IYVG3lnMzTb7A7Z6cXzUElLtW+nAFg7w/FXsDdvv5TY6cwmJ/z1dzjPaW
bEPIfhDBV7aGDqHiCpRehQ8OtrJTyFwtNoIgYriZOe9zg9msq2h7C7Sr/ts7n7E1TD+5J9Xng4c8
2Ds1d9iq6IBxfGQkril34tBs+0+bQy0cHivDvuUffx6E8CL4g59QbWTPlsBoBys5kFa8adWZzThh
StyOsezvIQ2LJtTs/OQx8d1p+fkcVakw0pdkSNvglujuImkSLaKtQ7RS+D65lc+gPQkhrPJRz6Xu
NeBWACLZt1jrS8YQy4zQIahFbNc6TY0PBkK59g0wJcl/PqzZK8cWkSmaQCWftg2lmGnb4w2tAZE4
uAnIb2zux2E0ZwlwnjpoVdwujVB6XQ9HdYio//nhi4WKMcSjox0qB8otPcJvtdpf6HpE5dl3ROut
UYRGsIVVbFJxIj966NO83UOoRBTUtg6MN76BcqN2wFBqpq/xdD6/4RGBv40XVKcGGyifjj0nt/W3
85KB67EmUIu+PadB477/yhXi6l4XuwjvudGEmVFo7k7spF6MS9TW48IuS5BwEqrKHuK8qFhHl/1l
D7I4EIuHlfGCGz58clHr15MvGBbVihN0ghqWs7k3YSr3JQUxY6l4Hn4qEmvpYVJYvkA7RxSpLBsz
