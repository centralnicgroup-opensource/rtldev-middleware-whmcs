<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxVQ/yCbKJg52YnegGQ0+KMp+zuS0CQX79AucHms09NS5u9BFyBDCHi1+M4lakPI5jaVFdAR
SOHSnSEx0XaPJToxN6UKEZ4b05Mt+jSThHgG85swfBp0x/yb7S+dLU9+5a4RoGoseXvAOtqJ+BGO
6SASMwXcYfXO09jokfN4NQfGZ58PDWyfoskxtU2B4kLqGpLih7B7rsqH4vUW0J9BHS1385a+q0rU
NxDyCrAUMa93zeDzNB8C1ydSTxlsv7CFuzPo3dZg08yfAPZoJlL6wQeCcn5XfBgswKC30md8TeP1
xEO4/w0ENmm2fZ4I+FELpHOP/pZWk131WAK3cvmt4T4j7BC2A6m+RmxOxEZEcs5B2b7a4yYz6OMC
QsHNPk5fLy4raCEEexhcNh6cXUVmclUy2l/fvNyQnx1bdV/67qvdraRccXcd6Wzi2+yXqQb3eH+q
/GX3x+A55Afurry3MWobTY4YXOFBTdv5hLIicUItfIY905gXzYeSrMmMTlLcE1pqI9/D8BK/JSyW
4iDt9WT0gUtUWcXKgvVFVHG61BCEZgszq6L02hkadaPHhIlxtWOjhTFuanQd0MqMZj2Cy404p36J
XgouIgQsmZJPJPCgZjDFuD538JWbxuk3KWuQFqFYBIqJ28x+27KGDfEIKXQXfOCEeV2Twes+EUjf
qEzxcsx+YEk9I2JvFioTWobg1KQHm4uh+n5Cf4sQKeHTfcir+y9NlbvdOgiFLHxLFpHKmIHRTIjf
9JYhYYtWv0K0n8qhJuhOK+lWovILVz4l0Mg4kIELDjxZ2A+IcBeSkp56wAzC5/4P1JdwtnAN4To5
YZiJhqqMZpOTtLt35Aa0CXW0Dt88b/RlKvF+A4y28WeBLYpdTp/m4EM8KaD5BtLhp5VJuhct5661
Iw2PUuNh74/r/S/uKFhDke8lKBC90aZLV6TGjLIkQ64AUFgy2KAl520nZu0oJc3/xfbvckK1e2+M
ROQ1TOb/8lzwRyLxhAKfX4xqGR+Zqjlo4i+GZZWw7+JU2njmUMEv3w5a6WI2Rk6bzcN7PR07PnIV
/J40E+LAAH4lcOJX274k4eAg80s3FPlhgBaVHZwB7Fod1VxvJq2NwsEK+1ApCdBXqA71QVkrCktN
c2I87yDxjiFIJ3NvbZsmdqLkzSWV6LvBUb6+M29OMOJsR0sKTDvKA++X5T8lC8RsQadcDV4vBv2/
QM0nYiHzLS3HzTE3/B6GL2X/1oFkLfHt3aMSjndXQw1J0zNaj4QJ2Z/mJ63kpMaP6bKKPEkoakiR
rBJ5RMak7m1Qp+2OBNuptBnleXvbHSbTugllaDGd4KgDrU07IQ35bLyEfMkb7vs5e1LXukhztjFm
wu3xSFtBmuJ0Qlm3qpNnfFOriXscNHeMTD3uJ1vxgoKKmmmpaeIa7QgkFj/CB5OWi1b+k4c7QYsr
IkRwCgE6xPgYj5fhH6G+qib1OIGKaiSae6E68tmEZ/SYdpXEBG20m9oilkZQC1HPriK3svATRj7V
ReiN+1tr/Dnd6dsMjImk+lPdXE6ASnuEwXW9+uj+Vrfn2OFW0exOXVJOmSc+hKFGFJkM5e2URLi9
ImOZAkopwYP0XOgXkoP1webK7EOz1LwHm19TEHyEoF0tVJN4zZ2e7MqdyoDqhZEv6VwjmAuVQN5s
czCR6mwyvafev0QTb7iBV1VPk472Gsl2dEiQQrFX0cyOaAkLkgRQFW82oE3kkWXwpNPpREsctzpH
eTWCEgbCWBz2T4gv39nerND1DyqmmlESHm7i/kBATvukfT0Vi+OH4sCP7DTQvYI7024F53tYGMXn
fnB818CX0ztN0uHgz3MJ2sJh6wTxj0PJvchF4ByQybZRgwYc0tkV7IxshsAqlmeLmgceDI6bqQUW
GgZv