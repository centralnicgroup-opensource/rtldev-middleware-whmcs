<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm4gUPhs2aBUZvZikMCOsmhTSUAChnIwUvCxLne+g0WAYxUhK6vUjwYphKUg9eFRud9CITD0
vf3jNeh95TTEYlDSvMK56IDeGJ4mPvTNbt4IqOI2jBVv0UseU+vOaqC2i7Eidr+x7/jx7U2/Sg22
+6wDJLFJAH65zepq6C0MLyCqY+tITWbMggcvtY/J3CpmhJZ4zRgR9YDwrVp3GQL/KxSCQar9zqog
QYFMiJUkYLHNSN40KWzNGrzRTbp3ps4VC8IlgGzQ7gppYEhJ9G9xXWTad9nBMgne0rxnY6wMfpre
VHWudaWc/xKOlPBXSlCemO8cQ2hbmjb236J3UWXyIE+YVRLwOPIEJ2AQ+jXCqArOoKAQQ2EOhwWY
sOqb3kan9x23CxySJDvvzyIhI9r37ydbHgqFvou/vnqrOEANKJCMEN0/jsNAvDc+n09SIwQc4kpq
ZMbGXtMJYNyMCjxDuDMKQ41vKwI+SUqaBg+KjdK1D4QRme3S6PqbgwzPXz5zZiowOLd6h3YxHs3W
yrmi42Ez7+Emtve1LslUZn/meD4CiR7AWMwoxB/Zh/V/XaO0xfOSEFUjZj4BtfkHEq8FyLLXTamE
yrNNQAdWV/OCdxczu6NvXmeSkb2jy01qRIBZkmUZSxrHCmABL/UwSwYONr9/9TSpvEW1lnXW32aG
m6AWE9Rvg/EhrkvAQcfahQd7SuegZXek/YRePVEB1Rfv1r2FEb0LwWp9OprhuvcHOSUkXDPpuOsK
9BnuBv/7Qz1QfVxUoulWp9Ismq6NBi1hS+TRgoJnAIviN0FpLoWEcu4IfATGgBYJpe9/YmwUjU8s
43vitOB/PNF92kA7H9fDNypigIO1cthNc6AZttfDtCxuP8eZJkbC9qAdIGiXJ71l8HC8EHfovlJ9
lMXXFfGnylJvOoNWfSBvXa13SsaDtxGPYIlg8litNqW/bHjxHuef1IiNudzY1RIWDyB2AMs9XtUp
X/jdPhOAwnGlFZ03kTwbLlh6P6eM8tAN6yHSNV0SiJKrXN8YYdTpWrO9Ibq3FhgyU12do+fSBres
fnsUqsE4rz7IdijPLsnqYoxyoyZOVx2pR+2xlw8HXFCl7VQGd8tP4H1+R28jImSdXVL+wINQZeVE
7GZvuLd+MkNpIIn+kOlP+YCxVs8mfpsjHnnMeACB4tJrUeMYKzsZdgY3Cjsy6U8sRGtTKcdyV1Gh
wDHiVcsMo2LBESsZqK1j20liSKn5YdTgWtjGISTarMsMFc7Y2lAjLc/QAgN5zrDuSZGbV+47dZzG
W9rJ9F/apoa40EbilG6LUnEekWPLsniwV4YIHV2OvFpj0bcw2EGmqyGQJe80/nj0HQ9h7v7krfxd
JE8T1xQntywXID77Fsbma5ppnoeD3UNhl/nd+7t1u9JdiYBz+R9+/K2BJ2gzt51SXTPP/Ig4IvXb
2hoqCb03SxmHt/HmM0M+lqtqw1xf31jAwdJYXmPxNQMwmTBbI8AzudHoSPpwOpk5t/gZxQKGfqia
iQGRk3a9T9g089pFg3IsrYQrI50hLK5UeJZdlG5p2WMN3mH7kLUbFa5r7l49BYeeOwCPkOhA+nzd
r6YPAmbZrONnU1oIbUinq06lTD+JlnG2RwkxHxVkfqqR7bOQp1Wo2+3kCUiVAeyDNW/fjzi9RqQw
gRQI6yeHNgZ7K9NinLTq46j8aj3YypYtzih2EjGwcaryw0TI81MkboU0SsVhlGqz9uXVkHIhGcpi
o+2ctxCWUAzI8ShR5e/QbNISCbr/twqVB7j8yeOCbE8RYm0MInipYwWRcFY1m03N+fqdpbjPK4+5
RWM7CbX7fKKSE8mzJ6j3pz00z5FrpQGnXHsw+WxFKElCD8XVFy9XxQhYtPo4Bl+GbfydHYLlbxjP
JqPG