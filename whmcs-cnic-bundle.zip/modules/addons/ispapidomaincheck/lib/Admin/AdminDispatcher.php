<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPybKS9+6kqZHN+Rbl1aBFShaqRNZSTt38iy+tqCV/xuxmv/Tp3Ypiswh9PZ8T8qSnO1IpXa/
bkNYOoLOjO5mPU85tmdMzMF1UtHb76Byw/9BypMAXLJN/3BXPCbTYtcvvAqBBdDioa+2zTa8cOOR
952ozPLvAArHKIOcMtVzNtQMx+VkiM+jxftCzPGs715TWhP4cwNS/i39gK6IO2LC0ghLyX7kRphh
LtJ0d2pXE/n36G1g0qozMfCiPz6oBFcU5EjEXwQn/sm+6jaDV8eQJ9i6CglDxcyxFQ+oiyYwc03Y
3f9hvrl/rUbYJunPnBuqW2GzTnOMf2N2tZ1LToV0MmpHX9iZrqO/Ub58vaQliqMCLYfLcsoY57XS
CqfJEraMI7+Wf+04M6kT/oU/GJSJh310orjg+548zJxPIfPOJpfWn91UB35ptmlVtc0bvB0R77ds
euU8w2jfhx/1N5GHVD/WhKHYlkmCMdP7Qs7yC4ENpAGSyptFU6HeB0Mrng4UlLuFUb5LRRB4RuPG
65J8FWBc4KYNiumPZSLr4tQgz+UVvsEoK78cj5Lvw3K8H7lUWgxvwRJs7MlfV5vCrOuQkRdI3rZ6
WjpmqLxYC5VOdGomAK/z9VGLg09eMt+hgvZ1RzoV6rwOJly5tTvqvEpcpEYE9m9o+q561UGZPTte
5QAAD6wq3LyMtB5SnQQfVZbVTVzDPNUrIfQpjp/HUBJ32Sh43by91ZxZxUYX+xCqUdAKHu1eTdGP
VFP2Es4MFbjyPIceKn9ua1Td+00JXl7tUXSPi/E0PFicDl6i5mQPim9pwIYzmZZkp8isv/DRcJDY
lIDQt6VLnW9DpJeAAL4dJu4D1eCdx6pssLmEgy5fPwM3a9KA68SKrMbdvaxjJeCauQa1YmcFfQzi
b+VV/d3GcBWgm2wFynwyt25pqvlN3lwMPm34LTRdg/XywY6NwwI1eRT2mK0zZw3rQhBtsBTiPLVQ
ME3RIeW+QY6+qYkab22z1SUqkHyLbPUGVnZfcOPNjnpnHAiNwbgn7lxZWCVLO2qIYkvdO3l2iGpM
Qw+Zha0Hil7sHhr7nGOXx1yJanfocTbPWYLk1sgfAfi372b7r5If4ea3cqiHOhz25c/bzGxrkAAU
SckKr3etDx9HV7PwrvE8migzjVabvrR7kFz3Yhg00zEPE5AgY56s1Ct/xu7wvNvlSSanQRSszCvI
c7OvsjTJFPxtmTXcd4JVpfyWSNpirILlP87a9JrU7G2ckKhyEfw6eSbDdyzXomx5eIppYahC60sC
1upgd7gC7QI0TFyVV+KRPBqQ9G0erA55Pt1fWM1Jz6hLrKTFs1J/CrGeB6uzZ6MGfyp19GXcSj32
0UpJ6LBemmGJVUm09DmcLrMAUtZqRKRDismtLqqFZVl6ukRqsqtAVCw3WlUls0hk4ilNWiZZ1S+b
mYS/ND0YVSB5PfnlGR/FYO7wbtiZmHJz35bTe4q77mO+QyslWJMOh+xiQPdzbJJwRIuqfsmDrtfP
XIcRCAm6iPaN0gvEKHR2VWbhn6rDgAwg+uVUUYZxqpAL3+QmvZAAVxWd23cPtuLnf6t96iGY0zYg
8QTFlTvrzeq4X863vgSbWfe8mAHMZubHUENf7+qA+4BFlwJDpvdhESEKZx6ZAOmepNne2Hm9tnFy
7E4TdoTkxzA13vP2zF6njPsG40AvSCJsYNl73UbUgfp/gU/emWfgME7jx3kU9WiEkKLhe/7ezyTC
qbW3kLvhtyU39lnONDW0VKHj80vMVURUrC//II7UKWcNM1m+mLppsmg1sP1jdC1I5Tmat5iUP/vc
kil7TD5/xfx/SC9L1Xb97EQ1H70h2bjUvjnOgvr68BP3DNJlaKorTEzBEeMOlWUqe5Ergm==