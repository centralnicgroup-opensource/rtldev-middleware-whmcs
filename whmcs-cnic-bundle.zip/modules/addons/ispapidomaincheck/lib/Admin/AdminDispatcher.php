<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt9xPGNWnLqh/Sdm9d3TPCjysGrXtIC1sEbjtWClzbWXkJKU/0jkCbtPn2p6TOXCnEK8Z0td
1shAYr+lkD1dBdC+rqN51el+qxOPY/fW5AdCn7DqSd3ITf+d56ijpvJf59XaKMqJ6MFPAxiGUTQ/
GeCxvw4Ji9XoIjGMBiTINal1EiMV85ymJvnA3StJ3ZbHV/5FAf7MDWl3z6D2oDA5/6A5oC5G9Z9L
eA42iYdM961cKslAzd3ACvYuUuHBzmFI8bBIsy0ecS5h5/SQ9v2j2HIeQ9chPkSICf/DZly1PIeN
TufdCyj1AIwo4cjKL0nnsIWHfHByVF1NC3vQCQE3HUPytumfFu4egIdn8xXiflujLzzof/K+vGVA
eVigXN4rfWk2R/65VXh4H3OUCI5UPYUw0zMJr9qX/YnRdnmI9WmbZl0/yD6BpKf6WYNcpBfCmBia
NId1lmzCbR87pD4rnkSqOYMjk5VBBeRS21B7uPYkZNjDbFiX/w/516VkB2S5OK96mP8IkGSzaMBt
DW79QoV9WEUXUq7vJugYVb9e/BRAIXeA0o74Xu/viYPFOWAzGPEYHpDF+sJ1+8b5wACRbQAmLbJ5
u4CECF3l/gmSOQ4nS3LFsNpRGGt+mIPkKJbFLjlnC/pi9p03/yJi99PNY6oDq6cBXvG7qHdjW7zh
RRWX0Rdtmh/5WJsYtB2C5czVI5cLY+LnqBP9LXeroxy9w245khVt4Og3j60SopPv2GsMLDXaISYS
ILdZR9yiNKsmuMj7n1+5v7+aE00jPOmcrlXd5PZTXYhsWdcJXe7lyXksk0ctmAl/4YJerOrDOcIy
0v1KNR7NpEMWb8UU56w5edrjxVRVNaInfGragcn2zr7NzZc0ZmUAV+LA39MWFdabNj+kBlB04fd1
PF0PVgZRqA1867GfCKtK/vsDQXECej0iKQeEVbmkIeHdWf33YtCAzeHFLCCpRxzf2pq72sEzL6HJ
3t+5HTNVpWB/y1KZf+8/RR4WUzhSqIifyT3n15RARocvnNfie1l9Mi7bV+mexaoNew0nfFQfudBK
MK4O4PcGgIlcw/0FGqVZQfEybQxwE9HhsJ5zSc20uwLjv2oQZ7AAncnlkaRzSnCIbJ03Rfs+9ojk
1O4nZBzKvNue3sih4sm7VYbHrCOXCbPdAenNZA/44RnNRtE8pv26gr8NUQCE43u6h97HLZH5xvMj
CnL24SkDlFCHpY4v+mVyCZLIT9u/Nw8rW+n06sdMNbNqrC/2BUgbJY/E++Unez9FgrBAuC05Mquf
xpWS5BsxWhBiMVAXI3cEs4jpVwg+qVyW145QSxhTgZLtdsqxUmZXZPD11mTIlflaFuzwP35R22b2
XXMjxuaMD5/VX4c5jdpxgvCHAYyhNnnuanZ3QhVW6lsB9Hyuv2GfQpJIRfM6/5S8y/BdVLDFJK+B
wyaMvG3jwzQERTnTw08zy14S7PLfjFiDakH6EzBX7Wgp2VbPe4Le2qlr6xwJwlXW4ngN4JBSWpeR
u9nQPg7vk6pU6YxOR+Hvew7MQ2nfxP+i5sPeRqlhOXjdPWazRjCO+RX/l5LobXTgaP/N03lenf85
H9yQGCaggnINKUxwhAdcBkqFRknZn4LsJmDHbwqtt4C7HhbXMYO4Lb+2sfZDfmS8UAhy1egGDzsI
vhxUgJ16M9Yj3MKEI5DgAcnTe7DuBsJxkxQlURna0lCtSQpjGkmn8g+63/tpqjivHR4JPjSA+IJX
quh7L6JJOMe1ACUtrbZBhH5E/82TYWLMiMPK2w/0Ij+arYGfRmGSuJtFlhFjr5l7QkxS3zh5gxxI
aozcfSWwcIsGixwEVfwlnDxeNr/yYzWIfFTuSvJIcvjdhvq+79fBsI1ydMacgKF1bC9L15/Jx/Uz
f4gF80==