<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx6klUmcTWR3FnmepsF56mtyUF+D5/fUFwsua2IXMZDZvTExSc/KBrqC0nyXN/C+ygkTg5p8
zUsXL6OopYDBy+OeCcZA2IU7M2vZFKFGNdgERbfI4a5wStq7jY+QhZidILoUkgtRiAny0Gfvxqfp
k3FEfYPBxj2K4f+cGGf1+Y4EXcZ6hwxsN4OpNYkIbb2LMlfsqu2AZrS/tugVIggy/iiKYVCnpvwW
utB6Eb9O8e5hivgW9kU98USqveMpfHvVLAuQxIqRXP/lhvZxOR6zLnCA7Zzc4wT14wNJ16P6haXH
HWTmOTfnodSfLJgrlPbyV6NzbtAqWKXGsFIsmfLv6uKcfHsJxF9ibVAXDWSIEzArwz/TN5GtNmVg
8UPO2bXFEGmNV7LlCCOtuguX15O05hi4DbfVYVtWrW1CXGLoCQCJYd981hsGZpITBMRERCQffPFC
mge2b8BS6bJUK29/MQG7vL1oBgWKhdlD/OkwlkQ0vPQ1rjYJ4bZjCZGOg+LkFup59Prh5K6v6fz1
XegWWUzIqN2DGMO09kDhgUobMW6OL5r/diPrkcSl8P/F+CdgxLc7w+SxvJaaOQtFGdk0f6UEJAN9
85Ari6fxwyj8EYqeOGHJ39JJuNqHQRmwx/bP8mAQ7Ne23ZECLvVdoFQ65a7Z7gVCbss8EltpdghE
aqrkPM395lmVj98a6bq77EloZvmOYAFvxjCeAptKVYV6hRy3jNk6NNBPnktgcdGiZTpH+kxbk+nC
kamVdtx4vtNXLayXw3St+q5VSL//P8YhUmi5910m3rToapiJDavjHT8LBUJjx0pyWLstVNMGlB03
uPUTRD2JeqDovziNPaloaEf9TqdgOskYnQsjbbBFpYzxCJQWtYAPJEhtJ+cueoZMPtGh6uw/2LJA
NgS6LIWvJGY6UtTp+j+XiF2E1QQ2OPKgG5XB03t8ZEIyVHhkFoPLQI1UrYqRj4TDW1Zl6DbK6MEk
fI6tDXQit52wJAv5p7/1Z8iV+4OHKK+mFglR+ddGgcVRwLzM7v0+7gFkumw9KJkAXJVRZCPwz8am
bkM1KioWBi1rggh4VlnavRXSag6uQnKWh9OAc9EkJe7yZzOWnuXgAP3enkh1RTaw2xwRWMS+ytdj
aj6ppfU4dzYuM+rGwTwhYzydhniKnj89bjKmDzt1NmSnobK9ytF9wbkD0vGNi1kYq/8PfY55GYZz
QyG02hBlawbn17WlQlACk0zGd5KJWbWl8tfTsUDbAUBoz1yxSuhdlkSWe4vVa6A75z9amCdjbkcO
1uN5XsrLup/X+HcaexzshKD50uTZdwAEgLZS+1fKM1oa8ombPy7r+RqC/rBPW9xFwfowPut1Y9QQ
nrWQE1LD6x9xETSCNJgqWAZ3jIZsBXHW8aVrpitxNfPV/oPgQWyoYfKvQbK/ZwJOBPexzMQQlj20
8U8RBBlDh1qz+oRpSewNEttZD0Sn8arL6tbbdmBvlGqQJi8keVxHx72fSaCxPY4nj3LU1DPsCSIQ
1iI3CXkis9n4U2tNxDJm8sig8pdT9iZ7PhUNhYSvxSFTdoGT+LiaUqKg8Z4TcGNnZ5XlwMvq6ejL
BZahQCKmKpxVGHPBquv/p/TJcdOQM1Uf2tHUx8r5ZlQ1VyZ0vf1VeFj29pGKz8qhh4IkvHZssUwp
ZFXBzRurL60a3Ab01pUQ5anyyNQM1v0FDlJjffQjdtFEhWJL6IRjQuGn4B1Hsh+agCCBGeARnYbF
zi7wfw/D7ls8GiUrE/QfiE4cKoAnlWQdS19Ohv0rn4Ap0Yr1Aj0PhWgDAXFy5m0slRJNmixsBJEE
jW8kAPan7yixSY3AJBaPKfG/+o1A/mnVAN/YQWNF8iGDhuAZTQX22Ep8Gw3hnD+qiPlq5IJ4sQ9L
JmIi