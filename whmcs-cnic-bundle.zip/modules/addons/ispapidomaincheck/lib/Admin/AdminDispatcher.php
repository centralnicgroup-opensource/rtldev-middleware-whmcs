<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqw+ITiqXh8SmGpS+2Yn/YCxBz+amvMjSA+uyKbrQmeaQPfRRe1Q8Ex3Na8C6QyugdCqgxn+
6BDNksMIM3+rXzICajSx5FEBIchojWch43a39jK10cG+Tx36L5rFOWN/eRQFH9H1CYjEoL4OAP7h
pGbd9WWDvR4L6kL5Ch6gbDedN9nbe/yTuIDQtMJEjQZJST8CVu5LMbbaWQGIvyO+6N0S88PErUzy
18ca+MJ47kJtidAmqNbrvfkGKoEtTp6ohFSpQM4BibGvDFIXHeienCM7UdzaDkaP9mse0IxRAuwd
7YS8YiIai/DVgv2ZrAwInem+JONbuOpm17sp7EtAkBR3kmI4xLJ189hVQnHPtcu9uu7vtQ3PNyqn
DlSxUeAy0FnNx13Nr8eE2DkzooBsCn0NQLF5CDJdzTe0VHeOkRphs4d0PMKYAEOKD+rF/vkoHSH4
LZAnv5AS4xAH8aR5771Jja92uvLQgAWHscTnGeWoFNIzaGdW5AZkQtovRi+Bj12joMPnLfbHN3RS
sMbXnsDoj82Lh8zl/G5NWmpIycPNePZZ+bAYw3y4+uT0QQ6W36QHjQ2vMF6LyeIdw3XHdki9B7ig
e7btYJuY5l+Bz3y3WwLRa+yUzgIOgkkeUtLnpWsGtVCjp0F//Onwc4DQtQByE748BTfSqEwPRb50
7hPTlYWcG/6kItr4Wqw5ZBF6fR5Ia9PvRNXVseMOUsc0WobtTUD4y1RVp+FwGls4aonBJV7V+uwD
YMinrDlMIp9u3ivo9Uu3AX4apAZ/oPhmOKg+fnObhtIqno2FE52Hv0RqafE0Uxw1hSCom3eaEKfo
n7mAB3NWKQwoTpD54lTYNa/FdJ+yZZ5hELRTieHB9gp5QLiQ5zz4iw7Q6AeHY2zJYQ0WVCFk5m2B
cqbkucNEXyc31yXe3U6bEtwqm+3yb7O5u5OgANeWiE1CpJMMsX4N/eLBFiKDMph2g4/mH2x49uiu
os1qZN2XRWwdaQsiaZ9MVJiUtNq2T8uAIF3pEnvxldrs3tuaWFFsUW0dckHzu233VcrUlfzlBZ9/
uZUAE9Nnj+mbySZ4ostnz5KOwujP2lUEq8Y5RzdQfhL7+6xpMAGa3t7UeR3f4YKLmtUQD6NRElTw
fVcFI7AlHEYnffSm1c4WLq4ne+IVoNLpzieQ4hMYAY6imI3+sn03VeUl3PjOaxvYgcy8+mIaGRCr
3Rutohn6sg/Yuv9J6DWDO1MH2qNavD1SqUeCgyt3kShs456ghEooQb+AWahqHYstAZFmTEOoFjEA
RkfFnVesAgziKm2BU2pOHrLSeHfZ+TBGBv/XcuV59Ab/ldPhV+ez/yZO/DWKEvJLEnO2w9E3CICR
QcPhLZPI5aLIxb1opxvlhz/bE6+RJ/Gm3hmJa4yRUcWjfcANi8b7ORaqPfMv/pEuEJzmEV5Ti2f7
N0ZWKg8iNx7G5DM1NngIyg0PeYMpyuBpfjeFZ2NHLO10xvrHv7L9VcbmtpR8lFd6BW8w0k25iJsP
3Uvm1HbY+M7NbU0lXPFcy0Kw/hIY7QPXP75Knzf27/ouQvhcI8TQNhgPFb4mwtY5mZ6IRZsN/wgr
I0c3DKV/chGi7AyxlFGtQ88rwcac5L9ydsnFtSeOkNoCfLJlgbijXAmnlFGKi+Iebr9za17nelFO
pfFiBOYqgvV29LereFvVe8IOYA/oh9PmLft4h29WdhSczvIRIYoHKCZ6ynGe32XcPwRZC6KjZIzS
HT2OGrXY7IkQP7WEvsKH69aI5rrw7QsdpMMO55rJxXSBKBuFE0B7lb0dYA0lrAfFR0t0yhXiYBK2
oyEeBxN6lDPIR0rP/Y6BXqrPz8uYzEOVSUrvq7YI0zus5l1PnfyE682UreeOGpT0CqitFu6Ze2Iv
3LdtFG==