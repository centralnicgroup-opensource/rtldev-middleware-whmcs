<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvlBL5/qAgsGWNZ1VAqNQ/k7Kp6EvnTjlv+ua32uUKl9xiv4ElHdGNE7ytaUT0KwMLdaqLOd
5pFiW0jNeR4qRR9r4QD0vmAPfISml4J0hloWYeOGnotisYzTWl1UoSTkY5j4muShHq7uQomSKD1M
xqO80yVaTPtxB8rmTEyxSzmRScKfcT0JmszO4N7HGD+wIUSnvAqjE7kKCpaYO807xj+qCyhik9i1
HtFoHjJEiWHI9EaF2H0NGykBnSII2kcEP9WcxIqRXP/lhvZxOR6zLnCA7Zfcexx7VUwz6RaAhaWX
IqSmtja72VdYrd2yVElor6b6NGye7DXWj5mAvq4f6GDVgLPiBCZqviWc5ZusaHScJHia0MLhwClT
0pQxgAU8opOlcKnGeIXuRvew4o2lWmBHFmuBbrsuIkoVJy3Qe5uqLdpBxZil8xvxSGUxFT9xk6cq
flSuKpEG8b0A82YA/JMvDrESy+GXO0jsvq//UexqUI3jTOTtaZKehrQR2pBrcdaebMDI7qorQlpl
mR7Sfwx7dBtAdDB9hIlUJNhpnRpiWp3jRvVaGlaB+UkxgaO7eAtWZZV29Zs+OcElKQGv508Cnf0B
QY1WNuDfT1kvw5NrWuWJRm5KURpfGKxS3LZg3Xq7kjm+zLx/ehl9DeR9J6I9szmEwGR2Gw6/xo4F
YM2wT0gJ3TCIxsCz7zk5l6Z2onr6tpemFalirlDrugr85xjukWiOSF1KOTZ4NIBwsi4oJl/RqJrn
g7VGIn4Dkkzb2/rHB42flVKPWqxq7s+vCZu/WcpYjno1SuFzS9zW4/GmEdf5Q3qhPB2+57cG/AKD
gT2xjodDCwS3rN5OM3HKKrML6IwqKDprcsfqSVn6FIdQFiVCmiu/pYsPGFI6OnOLZOMpCi6H2/5e
vjt9YuYyz9sifhXgIIrdtCQTXkolEU1XD+VxSPgeDLAncLbzTvsi99vnXPmWMPZR31Dwe2ZxNrBr
NefbUjNZ7onL7mOUR6r1xQcZ4QERopqnRPR4YK9+hRo3qTl+tCpd2ip+Vk1/WrWS+X2lCPyX7S9a
+80gqZ8OKz9JAeSkvv7NvwOrUjzttkW/IxpUZpdQirbvaScHUkwjSR0/7NVoX7cdrSB9qVxd6K9g
eFkOntAcB05V9iyajtv6TcEhjsRT9ElGcvUgbDnDa4eihihHUxkOYHoM+2a7X+ujKSpHocgmRfFy
7Skmi4uc1kXbMENw1+H9aa4biLXgrhx+jZj8QcuCrVN+y1EZa+dj9lR0aVrYGudqJlsbftA6IzQb
TvYocpiOO3c1HmULdS708WGDVw4J39qEAm/4DjxzFuxp26LFHTTtXciY/tdUoLAzvhDwJ8S49C9Y
x+y2GY0mYcNbuEd0IuFloEsfPgydLQscvsoD6yvQlM5l4VWTk1TagYN9uJULJjTw5+flIbxHPtHf
bJ5enlbMtrdmpRbsOp0bf/pThwlVcelAqZA7c2srzL/5ToQjzYFlkaS/2STu5oL2CTrACbFmE7N4
HbERvutuzNc1VUlf48taMYj2/Wq/gcxHrbuLu6oHYeM4g8nZlqGsshHoRVjIOBGxhU0EmIFsqG9H
aI5V35reni+aRo/tkDZDZ6JGFhfuKnqpJUurzth5EkjzYyPtVNuYt8NQftKjZwqlh6yS9BB/it2C
fIJI7iAqVrs+WRu4ZI//SXMkudLp0ptj8R8Ax6hl+oHkKeo8/fVlJL/cnVRzZHeU0Sb/QJtbAmfl
pzCzQpN1Yo2nP3fXuRm8zZZDHL2W5VgLBV/phhQTeAa89VrIMk42ITbrDnqTFHQUpvgDJ/L/3B40
rDGzd9DoECTMGwr+RcleH/i1hCd46Z5v4mDcqLk+wZdIk9s3biInB+8wxQVMKjc8YqZa6ip0QrIM
hujjnBHmJJ6pWPQ6/1AlrH2Wk82uvVU//2pD7lmHEilIkGE4QhFmHNufBBF87LAmC527vTTh/J2e
2M9juauDQKn84NT93KOkD5XEkok+sTJ2uCnnVec4mMT12efW2FkF+beg9Ix3TTz5PyeOTq6jZuz+
m9EBqb8ZJAaxdHDpwGT505huxuleAKtOmt61VNPWtudPXJfeq8jVEkT4W+Zceg0Y8rzcjfcRgU2y
GsuBX9kVS8j0oerCWYUskByKbyZlCALUgFwGZV79PG8vezw7ruLsPZIwaRWm6fsSm5Hi5G3hUeCC
KJ2nhoZwpY/mgWxfVWtqJWLtE8nBpdI9IF2LKOX0kqHzvz/HfAaKR9YjHwGbT0bMfNi3yxnQkbR2
iloyM+n6/mEY8sbIXJztM4lPJ+D6PWUKVK2TcBPNOfdmYAcklg1Tf3tzAk3BOXYY3Aj5X1nIjW8p
HRiBHxE5OxK9Frzfo+q79XaK2K+5e/u/u+t22x0V6+p7