<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyRZX8OmGdsfpL0HfH8fhnVxlgnosICuDDuEjy/2GBNT6t/vVuBDo8M/gIkLC8Un1OZBpVEn
od/La1xAFigWgtBriwXhKcH8ehErRH2kXalzQSbSWBz+PgqWBI7YMOJEuqDtuqNIUBu2P0RmA89G
e/UWlIS+5tFteqIFytgadQdb26rscmnm0Y7gWrPrOXb1rE2MljLBxIHM0+odRec0ulF9XfWsSavG
RbaqcEQT0rlSPxRMjMjTlijPATS1w+DmbnbszyRVXwSEvEPZ8/0h+ouhyRwYRxqR4EFaJDz9mjsF
Sd3eTqwwbL5I77Pcabb0ilbtYfsKcKprPF1B/EPXaBPzZB5X3B/E9gY1EtVQ5W4CWwq+tmaHpNn2
v6xUTP1Rj7g04k6l3aDj7CtgZDhn0Bgdlm2N37n6TkY3tjfrWoCuzmWN/L/DnMEBUGOJyP/E+1qW
q2FQlCl4aIs/blBipGPHE4M4T8cFAVHDTG5BkigA+qrJEUH70LmRWqNd0PmU3sbyjbIDURW8bdj3
IXximhVqQ+64WAOTfYmvxWnva8oumHQZAbMTcP1LSP0Cw2X946eBTETtx8C8IQI3r0thLRUnn2DK
SZOdBL4dUhPJNtzGBcDNcCHFufvPAT/1jKD+JYLVDMd1NRSLxzvs6j93b/N8G52c/GYWlMFR1/DM
gUCtLyFnvjM/bXj8QP6JnQPbYcS6j7dgR3ryPhhQpRWcyQULwYsVXURtVzOQGiE4IHBGowrBLnyb
gwNu/xgh3vV6qIQp3B1u3Ed27UApNU1WnpU69g0Kwi18oln9STKrQq4pto+RihbqEbUpMZZqoMMa
bS6psuYyB61k1duGleJ8YgokTt0hKHpdDKjYjf+L67uAbv8zJ7QylYvigdWZ3EDsnbo0tS5Owg3R
uurImb5xuzfDw025NJ2GvKPsdyu+Z4yR2heq4rDVn8d82SDmcA8pKqSK1GEaSboCYLGA1mHV+e8S
qphfjfGACmvlk9Boi89v1OF41XU8yIF/N/uNX22zzcMO8JgwHA1l7ezaBSVLIn7l6tDt5j5Fev0b
oQ0MPFPaUWx6T1PQbrRqbWO6t2Gb63X9WqTBMQ58YcULJK7B76cC5w85HMdV8XTXEc4OT1cEH9Hk
CKbWboXmyRCnuY2whHSl6pJqjYwkQ8a/tjBD5qjaPQwoYuYY7Rbg+FxUUFUJwL83n2Pez0kSN3CX
8ky5kZ0FgP+fr1DYXr76K81MBY6hq+8QrfU2s5lLrs0OyDyUfQ57b7xH9ro5lXSbkh9a+T7Kow6Z
8T0Nfe/R/uVINgkF6yg1k8v8EeQTiPhPviMAQDqnXvsKDJBvs+wUdHqHUw2pt0KcXZuRLJ8sCYAE
BrFwFgogfDZ2C2IhojjOC9/5nOyYc2dE62vNE3BddM3adCNbAlPJMDgbB016KfKg8KO7NYmClLiC
nou/903cJ5n/mUvC8WJfHVAGtvF9soCNnZOKJ+QKRdJNKnJbHhIZYLpSOs1Upn0BZAWJGgKUUqJC
C6EiTdFMWRq7MTFPFTabiO5H6QTKl/wcJQanJl4e5z1AK7ZSbDtrL+lNfmODuTZDdbOrhJfsw6ru
x2J8nDUxYRz/UbcGbAl6dXkxk1H14ZCxecTDbFLVkpFlzUzeho9I11CZXubKAzbIMcyTfKXEGOef
bS8klXrASzFva9d2xaOrhxWPf/PDadbLaalSJHjUEXq0/wrG5S2s9nKUwf/hQQMkvLezgn633xsS
Psoka9RFK7Mxey+j+votvt7uQue92UCWmM5jCCtuMfKJT7zmoa+85mgms61b9kXNm7maZ0jcM7vU
K0/B5A8BzIolpbje8nr3dTwjIl80NmuW42nqiDNxFWw2oZ18wNSZozos+RK0ZawolAG0lJ7stlX7
QOdVt6ieEBFom7aUnAFCtJz5SL6N+eq4cir9rK8weERtQ9vkC+upLQVn3sbRC7vIzkWxoJsREf9o
WnSUkZJAoKhevO0Fcwh5p4NTXQZU0Xz59TVbqWo5MyYXHARD/cW2ynN3Ppcx7fCFpON5nyRM4mXX
65AsO1l/5dJCGjb/ENm8PW80+A8tuxtlTsmk+u2R+SKdkbIRv3Ud9H4fTIykrWQcFxV/AEY9qkd3
qSjUBVwWhnUuOxS0VkERVHdZu2JuUU4WdLt1xf75h3Q1shp1oa7sSUCC7+bo3TP+Guji8XTpq9Zh
fVM/7hYWB/nHNxgMoxNKon6FNOSW2gGmdSVsSGatae3EZmm5D3gE+4pM9uxjTjAkm4xJdo4KjZah
ZuN+2vEskFb7Ol7mCp/nPfLzfF1C6KGZtoaKK7EuYUNlzGpQhEubnglZP70tqZkf0u+6kk+1gJ41
wzEWnIHdCrZpZex7tYtuyhVeqexFuXQPt/BMj3bFQ7ERS0eEU+Vk9gGt9KAjksaHVBG=