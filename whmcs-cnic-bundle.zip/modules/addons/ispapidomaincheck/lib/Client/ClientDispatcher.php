<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/C83baJr/AUwhkRUkSwHiyDZ++BXeywsioBk7c7jCwex9w4vnc6dcTpGxfgpL67GBz7iVNo
jlTSHM1HkPylVaMYlpV/Ly7XD2kFwZSIA2DSpfvXn+UyZG3KL8OVqL2Jjui4lAIOJ5jFZx/XRgFi
VQzlFgMPt4b+2tXMgraTwC3lWZuT+IVH2jEiiIt2UuorcMEmRdJ12sWnCdoguubpcuYRMqFMcv0i
Gv/jcoVLI5AT9xytCzCOSSvansCX7F7N2VMCfLZwRhmuno3jWo8BgGYcap9lRTwrxdxyuh3WnQsA
OJT8DVy6yB1+6HRg7s3OebQq3AVWclgfwzbZhLPMaQ6bBa8aDvKXKlOrg76CygJJGMoahokMKCM5
4lZ+kTMjctwfhix3fxHm4ImmrNbm6P3tDg5AWauvDWJH/ImdZBT9dq9QChmFOXKd11qkwqlr9P02
fynbsdKB+HF6+LIpnlLwHdTdEaKcgSfW26Y84pgKoRrq6m3noox4x1Rh6X7s75LrmB6eu0ZlWrsS
W9p5/d9Nj7DWi0Nvs5yBxicC+HgYXrYfg86FukyhUk3LYEYHtG+P7v43S3imuFUH9O+nq7zUbNZb
IxRRAMjVg9UbBIpkmmjpcaBTEhwinpCPL3IJQK2RJuCUPdRZWryqJf8R6Yp96L4GwI7LtNpyrkdi
vgjeExDYSwFnZOU3QG4lyzv429qDcVPtWl2J1tguSdbUET98n8wghIoHopbJFlSKxO+ZNRodDNAb
Ft/cYKPoBrIDCEBDfe2EyDbsqdlk6PxYGPWxyXWmhoNrGZ9wsKP9cAcdOON724frU+yzke6aSaSC
5g/odAbcGnj9mefsotMxvJbAsVMhb/uMPyh3ZrJpLrW0nRjlAj9kw1QUc1LbOKtHPYD4N0fquLHA
lDsB2vH2l/CXikIht+dArPThNEMCbO4Dm635GMX37nwA3Xrtwy5QT8mPhgzAXpqY3hFXbbMPhNs5
JamZz1X2iIQs1zxfuGOuHDFxIJtMcDoDmd03gG6aB17DGFLAkDT2PzaJS99HeFnYaPD37SsSwsVx
H9GHrepBGDF36w9+l80i3Ee5Sbl4nY5QCaZSRfj7TqQyMFMT37TwAQ15/LIO5/6jNZMTjprijCQ+
tzbVxidgH48WShCieSkFJdQ7l/qAZwtKBjp/qZQulHmMMtcKTvYXUrv+pEFWfTdub7i93E6Ep8os
wwdLtTFm0oTb8g4OvyzM0lHrheY6Iqn8RLVPqkr1gejlzRFsGuzhVQMOqmXI3ZHlbk+5Y9wFkEZF
Wp0l2h6cgx7mdOGQI1mTRcdzhcDx0iRkjFJGWsoR/xmG6eij0p2OAIqBC09Xg0IuY7F8vU/uiJt+
amrkhzAn+G7Tqjfq7B9GI+UrFwAIfmlLYoPnhPY9gZHNXH6OYINWsGrgZWkRhkged+tRMjH/Qt19
w1LBEGlGHx7IU1ufwlB9rA1l/7USEO7foyLfoQqTRTZFuojKatIOFnPscaYnXGKdry3eL7pi6t/U
CRz/Jcq6b5ncUKIs2wU4cPbUKJzWS32nRmTv93wKMUaeVlwmw7F821l19jdK1qEGiSJjX3G0lt/R
bkpfEoShzOExyINVc0fy02iLN8amNb3HFGkssfvnKDE9OeIp/OAlRY1FR6I2VPDXCZir2cdS+01/
ggxR7m5z4yurSHVEFyXmcQzmCUfYFlZBajjvrivzkOW3jMHyt30CEkkeMj3AeN2VAfMVbz+IyHvH
9D+a7qhPCuTh0IQGqt/DF/uX5UJHrpQnBFp0SZeE98l7w2AZbtiooovfmVvKEiTUEEum4c8SCu/x
UIFEAuTMgjy2ZuaU/jAP1G7rmW4XFnafSzXv97UrlctdLcGFeYCdPA/MMcRf3gy/X+ueHKZGmpaG
K7NOIPII0yeJC7NMrOz1Cp8wOrm1IgKvCRv45qp/x34BppEiUyN8UYTOtV74b228g/iqNsE52jT/
8JChRVmQtNIVg0je1atti1swtxBlws2Y/WfRs/coW5Fhv88xThbufdsk/OmOj8nEzGmxE5PCcBCC
Il5EqA9seHF4dfKwSmyC9PXenFmoRE15XU7WIqQ7eslzJh//KJ98pcDhm65XZI0/PHJalouB0HMB
dqN2bJaqKk3vWGF2Lg3NcaO+7e+40pWAEECF2MluY6tzkSgmo8QlU3KcIb0Ef5wJhaXXKqgucfyT
Ns7lxBg6E634lFwqNXn9Z8sRZn2UQyi4FPdzEa1LbSYGZlspjtCAbkfGxx0KwHG3ZmG+A2eZgnJY
C8o9+UQw0/nMdEWjcJEsq7Y7Q1LWcwi9wPYT4i9gTlYMk6XdbetW7I92OOJr6M+RY5/pya0jlA93
7LnI4NCjGIvlyUnKbml3G9rcex0IgnbSqZLg0snnWBDQ3U3f