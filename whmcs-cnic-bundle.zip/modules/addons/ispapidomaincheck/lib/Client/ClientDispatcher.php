<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwm9hhlLr1AyeBexc3ugRoqN++urH0wgyDzZ132sfjQM705+5e9TysUU99gHhPmqkYo2EKVA
3Xon6lODCx7tGSTrzkwqBjLE4y7doiaQlnS0khu9AIQaX59/X43a4fCIhqwn7H/TRcjeOgA4qHPe
Fzid+OXIZv6n8+/uojJ/e5JcogfFwYfrW/0VXCpJa6xMj0wtSSqM3i2EkL2Y+3KIQHqGODQP8SiQ
LwqPgCsSst3zckpcL+M1MESjT57nOQt4CXT8SMbX2x9KEJJqeKQBACJ5XtfeQUi6T1+D+/GtIJEE
PxOeFhK8JE78g5GNPytKwNSls3gpcaEHRYrx3gvxhM5PomD24FWID1xn5xN2hUc3cT8lnAV+VUX9
I9ZfWypS+4C+RqPnZdlXYXOK6D5vmPY2RapHYDmkWZgZmbngXQU84qWUWFzFThNOvr+lXwoHkSu3
oH50hyeSNUgZrIMVXGXl199kZo82d9Dojpb0pht1yqE4Nf9/l7hkOBEJUJYNs3HSfUFDEQgOriyq
htzT2SK3t7xq8ODthMlMdirYHKV/rspquMhhlU7VzEK6QKNt+BU/PkswKj+eCfrCd9lYcFmceCOM
yBRKHykO6widTmW68hUwagaJcFLJoqZnuR+L9EZY4eA+QGDrBOjsCLbnWA+b4tB+BlAZvg98tEjK
tm2/HJW8A/FD5C/GW2mYouVEUOPdeKd8e8L+v4ri5WUMPq7Dl679g9J5J5w23Cs/LZhS3ygsNmcM
ltrW2j4c1t+u+F5FhveM1+21abVe/7uYjDiUd27R7+/R98+uV/R/P2hNNKln5pO7JNvpCMb9O1LG
VNDuqJKItOzFqYnuLin9pxYYcI6cdSrF0mrt7EiHuEKdB3S5kR4DEXO9MIxYbgpDjKWVQ7XR2BxZ
PSAplfR2X4b4OrJSILcMCHC5D2jz/iUXdqq4KozYEPV90qGf654GHvek963D0m2e8ZgJAb77ugmj
KOHQjwNEyxRq9Kl5QJQqRKufKcrsEDrPvQwWBGEJpPZcAUZmkfdLoXVkkeLlzv2QhHlDESTKKXSV
crVoGE4EPA8lbwQNPz1Yyv+dvHmW7GUp5E2+wdPsmXnfL2vFM0Ip9IifLvcN8quMvH/A56L0A022
oeu8vE73JONL+o8Std85j3Zry0SJ2jn7h5QROn/jKp9pO55nCB8RpCSArJRN3WeQ4b7wg3GH4UlX
4gWPN6l/m3eD7ydSd4E2/ht3dZr0HiKlbZPHIagYrLYDdmZ3/GkpC/qPwP4IBGK9OzYPWN6deRQY
IzxboBTVwoJK6NkDlpD52PQbl8QZ4nf0LE+ttTcd1Kd4Yew+rulzupXSfVj+4vTRopkYf+dq9VOK
Q4cybM/m3TTJFPTDWCfjd91XeDabVghEUy8RMvqdTMo0reNvhLq2UOWm/yO9xFFdc2rXakT5ucew
PgJPouc4Wk9DtFbbxRtP3gRmg2iByGATcqdvoXvqCo397hzuK8rtcdYxDOz/NGsKAGQU1kd0gXf8
ZAtevxsS1vZ5fmkB8aENEmmeSyqt1hErljuGasmZPsnDZaOFj8rfnzsecqntBwZ9ZaRYg/U0ylV/
5KyVvb0s8BLjTHN4ToMkm09EsnNncBWYMJKTqf6n0Y4/A6Njj9LtVcCw9mwDFW2I0PPupM4QRAQd
ThRUZ3468bKB36oSmf44drt/8suXW6IP448W9eNSx0H94/6RiA3d6x2QEPFQYKC7n2GqBXisc/X3
pYxKZzy6loQfCfv2/Bz8b77uaA38LhZBzMSb9VQIZn9VZuhu8sdh7kefKQCmy38sPwTYNLg4VERV
8OhEK1XH31so3OkZaRAfZFYRFTqebOL6Ror1vXg6VlMUYcnSWRjnVc2NgnreZMXK8ehoZCNokqSq
9IIihB6QUlFey+fjurjhxoznjnom2KdOBooba0zlwySNkz6V75Otz7glIaeWHil5KLniY7kQCxgN
S5c0bZtFj/LTNXBluWifaN1v21ri3DPVRU7oAGlyqRYOKpMIFxt/i+q7Qk8dsZJRs72kDGCn278k
f6oshaGfsbBAzGmtVH3y0VvVUJJhQLDtZBZcJhsXEilBW1iY8vF2MJFo/hGGzeE5Cr9RbHK+atr7
Of2qhT8//1rVJ4gKiNc6KbsuP6pfUArLFyzw2YLqsXRQGggohvxI9NGcVxdPcArzbR75qiPtrIR5
Tj6qLBK+5vr5La3z9gbdRhfRazTAUjTKBuov+N7ZYT7iNrESxdNfSTDqgRMVQO5aEd2VjFd1O6P0
fpCDBqCNeL/6L6ombBte/tBTXwjlUqUxdjDl9r6TyEkA8DpXM5d4wmP42EYIbjeRxbN06Ck6rs3w
COFVy/DX4d8xYEqBjAiLIqrT0hwhlVaW6Zq18NVqCmfLNowFFKtEpbiagHWElby=