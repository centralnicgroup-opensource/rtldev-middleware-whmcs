<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPovfdlAsjsB5JzeBqJrOX6YYIuVO/3us2RUud/ucYxrjVEjZJmiG9Qx6tUbok2xwAUL3myPm
6CJ8mZb39cvVlD+2qGmpl1YiyZCK7LLN9nB94n/7vSQaH/g5rIKOs/zHsbrhmKYDiwtmsv7Bh4wR
VOXX1TKpretzldBOQqm2riUh4yu1i25wcrUxL7KEBjwKzgGUVwycuECBbOQqVBoT0u3zistOE2Jz
fpgDNQx1dM9acrMPK8n09D0YoNiHQ8lJ0H14KFHTFJwo43LofB0Qo/2MmvrgQPDcuumtBn3EcOED
fWTf/urmg1AVJ98pDmsVy4JtkVFVkDe54iA4WNijjUPaH0wvJEnGiPFfQ0T1Vxy/VFHh0egzBR6x
HcEq6c1fazCTnCvv4cVVcvKLOhdPXpaXzoZVl8OjjduhC1y6fTmAGj5vsv6miIJJlMAz/GpEiB7g
rM+ShoXqp2Bhsne8GVcQjolQkBs8Ym8OJWgPdpI0EfMavwKrVsb2EEOVy3WtuklrTIr8ghrGqzJh
riHtJgPKLF2WmHB7Jeh/8rrMZPMPixCkpg1HGu49/s7xu+oQ+Tc5P7fH5rNhUF0CQRUoUehEVb8B
lqMOUxSc13UtMMrCYLUlZRQpgQamWiF45kp+tYw4jmB/aGxOaUiMFt8Iu+fWLsM28QA56ZOXvGms
kWx52gutEtMJjpFkUlcih0uc7s6pcrnFtmpezqNfkaePwxm1lVeHL/N+VqT83xw5/aapioO5DTUA
xxonGx3iyek4K4TZ3PoCVode55Ks24QMiETBUuj9v1CWMTHDTbg8qpCsTrIT0kp8TWVU+owcDCJy
VSTxx+VLxAjiKtskYojW1XOAJffeAq7SPDNw0Y4aqIuvrrkHSofk74qcOSufuLI52Uimvr4misXW
KWpPApI4CgAEUK+pL/LimF4cvlDZporXNE1Q774BJTHZ4VLIMV72srCDjInZ+zJ1uxFulA0rT7I3
k7gx0V+ze9EycyC4DZLS9iRuPJSrK9hQTNJLHa2puFxiYNd7v2Vt7GJq61tV2pacGCSwQ7+EEbv+
yDmxySRfYD2wHwN/E6SfMeKsOhn53pDPp4rfaJ1Wk3QiD3+5Gtw7FTnu7K0T99sySrrFW3XgqCYQ
1hIAMac6TDn4mbhkClJH1N0mQHKuvzBwsrgnv2xcRAK6NRa1nYSFfrh3Vne2A99DLhROjut4a2k/
JdLGjBod1caaJ0yuTI9u0hgCwixuYWxopZdRmpsLh+MnQ/wdcoAbX/WWrpLyJP2F8vrXkVGF6XC0
jXQIllVZcA9n/PxbdFaKXbIfqrQWOeK4aX4DbFFZ4fndLBeG01bcxMW7f7IHMEyqYmOqiG46Gbxx
E59rVDX2jQyatu400LN8Rf00ar1SpQpggOWFdXhbS7J5BdYmxNIg6c+dLDa//sKpsz8LouS5mcMs
mvINl8Ur425jGjmabWJy5vSgW6vB+5T5o7lVyyzjGaouA5YcOAl5WBwGXY68q8cFiEcnsHZrVjPp
Bykxd+06jZuId9xwoKIiMcfhqjNe2CsJl5sULis+ICF3HZr1PMM0QiQV2TIZac5w8qAqI4ajHtBm
utf7AgeFYHhnvIz1PHyd1HynmjtLSw6kNfJjqOKoaoS21VdVYT47aDsVZQ53AuVyT1OXGaz1aOY5
sDS7jpAhDg8BxsR/LjDMsNtBgKYGaUS7zMOIk+JWyfkV3JFudpbdB1xEYQ++X3CmhV2cwUkUDzNC
7xQpXB0PXpEdUNZ40IB2hsS+hrqtcN+e/cIDtO7XoM2kBc4SxhiQE8+dw7qn2mk6reGAFQhE/AGJ
Xc5GUKiYJln1Z8PFpowz2qdS4TxVBV+qY4kylPCb9inRVkuBblWRgytEW7LNZwuBRr5qSz7RR8Xb
gezRgKV7ttxrGPKQN6SlV5E1WdNsx3rG+/CSbJ/tu+RvB4fCkxUusuXQ4qLzOfou08/N3/E5JR1S
HAP1xmJJenA3wGS8RjahOre8+CvO9JQ9t3LUalf/FlD2GvM/4/uG1nPcG57ZLybf8UlAUsWKPRc1
E+G84VN7XwXdXdWQgX63uwx1XTxoe5tAo2Hk/aFBKKZ8A1wvHEFkPcShDTI1QAQcgljF7EVu793G
BWBMPcv6HBInM/GDIP7smiqv7vBJKOTKlHrA4QEht8ogy8bEeJSNrV29ZlycBETYVqBVWGlofioM
Q2jIBJj6hBd8LBkDINKE16vHeVuFJAE/5e9oNoE/XouXOStL+M8fuzQhyye9I8Gzzv3q96D6g7OC
kNe388mHyxNmBUPq/xdh1eIQgZdIa6BgcGdmGz58nA7EV4yBxtFhc3STjpCqBel6yDvV/8/ef/Wa
NhCMxrkM8itA+MJPoJ7YDlDJ1DEJFskp1n5wKG==