<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwv1meOoh3Qfo/9NfVJNh7R60PoeYRtq7lEZMTtbNN1aQWrKIx1PmDJ42Bk1DDBoE1585fKl
c97aFie5lNIQWtN5NV+4WlUqrIDOfss600nV6IfJBtxC693TltdVlLnz8jE7O0/hJUI3JztWkXP9
u2nLPmavAtFsOyb6d9dIuZWw993K+cJ4K7jAhumjDchFlNIDDCVUEqTYEzzHpv+LDNkPMZFflZjh
cIhCDmiLzwdr2Fhy1nm01sMjzsaiGOiK95Q0u0vuwW2FAIcOyaxrHkcg39keQ0ZVwFy12hs7tINs
CN/871gpE49FrwUKRTj1mY9zN4RNLyYJhKgSEvpJMPo64+GpttURUPNazXXPuF2sLgS/JBx01pTL
N0UkH9xv7Ar7y5lNC0CqjgtISjLBIvG7LSN6ifT6i4sh6wcUmU13ioLHsgNq7cUubHXlolOe2R+N
RCwE8zE+HYL3YDi4x2pItVU/67SjRRncoPe7IIDcxN8VfCZ2gNxvzlOwwr4pPRb6DNPbPDGMjrPj
Yg052QeiSq5+v9Fg+G77ARShOP8SUk3PU0zPvaYnCigcD8QDxxJOxHWPe38JkAMDxQAIij3vguPw
Erb7+/bkyY3pK/iHeVQJZt1FxYQYY/MHdG1+iie2wIMP7r03o2oA0aMR2Vvt/jsg7V6AjSM0VI5Q
OdK9gj0xcLKfop2kowjoaX0LmEo2JHfSemwQPSEBRB0dOcR78/UpKj80N0n8qQHkuHukDlJBZeIE
9tNnQdz61sdjnjFlufLR72/dN0DmEa6mq3KLf+Dmx04j0PBRK1cLTEbeZalJ6IDTdRkG87LMzwsP
0G13gm2udD6SUodPhAQ43+Tq51zTohjjQOZ73Hba5O4Kxt2fVuL8kBEGcmSwWa6jjGckboJ5DplO
IXXS4dQqwnR3Wyrg6RCLLV3tQiUDR40KwuoyE1OkdX6PFK7es4kAoZGSVdk0iFkF+GgpoXa9OYWM
kI6IT38+m26IMqtTTcF/KIxj5fuJVkQHJpSXJiDdEDNw2kR1LAp/qOomQ+6GLOzLyo3BOyNIWhjJ
xXrKOq41RW8L0qvK/8nbTKM0C+kHGfQHJTDRh/RbcuZ6wDOGoPVBrDd4CE1rkdSaWgM1WamnmeDy
5KU2jsOx6hdvmovR5lWM14b4TtOVmHSvkM6uUycC2Tl5vR1XAktInGUAOzU5awlzeHScIhxLvKrT
NojczPAWVqlUpVn53jj7lp+N1ihgeYLtCJ8trdYGcMKqj6u3WIXI6kVbpVIevTOK2X0ThhMbAZvs
XKFCouRM8DtzM9PLHwyU6yptXP8q3vCqU1B2GP+jzFoZd1txtKbl3NdWRNR6PIGY+ktwONVrDQtT
qLXLpRzrvhyw46m3W6p+vR4TXlKexrsjXfWISMeE+8BuQeoY3Vp+3IaF/B38vs/6jyqvQiGJRIBq
Vjpwc0284SFdz8kB9UEgud/6vGxU5qu6qS5yUxAikNPhjUhNt1nuQEp0S6VnWAEhZUL6Y4ZwaIbN
RW5JwXjNIvoRnKoEEQePdBkIzZ3lCx6xngBFbRWlkr3jmeLjOWbPUVfmPKBqOtgJfebkLQy2rVuJ
AtjFPDpPXPJCbQZgq89L9Yv2dyguoEQ5XGwmgjvCTB80tFN1xhM4LlvNwozCrhNd4SPwVeNXqqNG
QFQ0sapGvrzfoUL+hXerqI1M/+Vp1glfD0n37a9KO+0qsD52zfaCeUm179IV3UWdL7sQOyZOYpdX
zkQX6tZzotP41o86sEEGLfL4dIIGSmjG1zy6M33pqWNWIkhvQoKtDoNoJ+a2xCbDHQ5+sDHBEGe8
FL5xexi8HcW6RpAiKUtfkX4KwjIHsxvVpPJ3to4V/cwJ1l+fuLQ6K4RTFdnDy6IiDLhEaKyqJA1w
Ni8Xz2WtlztfWsY3QF61fFV3+EPhfhXiIGcUWPz4egom8iCBR3R1dSQsTc2ZUx+VcsU1MmsaN/wP
qT1WVSyeWeDEnVUUmvi68eI5wwCZDo5CPWEYwlJb1V+mQqKq2ARhthC5VnPiVMk7gu1p1jkkLMxp
Q8WeLk8iPC8XQBCx8ZBjN9bmWjPto6mhMjDgXXWCrH0UGFzpagHWvuIAPsUZFgTjNDS/PIbHWfQc
fkChG9z+Lw1oaWKWP+XGBrRHgovLLHCTFLLZLMC09RDuHp0kQhzN/dCPBavMDnhujwuoqDacbOkK
CToIzt8SO2rzrMw2YnzwTxx9RtwR75bEQcNTrKcCwZBGunooNdc2oLDJ4bem9gVnKsLTxHp3le1Q
BLWTL3WFb4PwrM2COiYfoICWbMG6hgrCpK5826J0AWxs7mbGuIgrmC2DcpBkErgcsWX6r2NLq1YV
a6lbu7Rmdes8onbjMDRLkG0HO8PxGWSi/g4aBdJzlkKHtK4=