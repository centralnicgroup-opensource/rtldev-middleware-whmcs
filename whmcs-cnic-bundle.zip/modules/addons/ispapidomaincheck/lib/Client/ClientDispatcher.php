<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtSdDOMK2OwgOPIWfcjprCeYXFb+RMrBwSu9vWTSkmVRn1NMfAvYOPGfJmdZlOT1WDlXU623
2Iu9ja6h3H3m+6GDqzrUTSivP32zXggYDloiLxz1Nrz/8YC5VbVMGyaC5LS7N95USXl4SCLYOP6n
MJeLJQipuUkZDS2fsKP0Cjqiv7OZRM0iFY4fw1qn9hcgzis+Uhde0KfBvPkqf7nTvPAD00sSaVD4
UaUuM3uGGL3K32P1Sn3Eg7ds4vsIAOws6pSvGx7/R3uQsGryYXfCcmOogytxOFqQvTGHhh9We84E
yWOeJIrwBEcFVOROTJymwC0ptnTVVLCtGvXrfBDyFZzggnUrPTSz2JiWSKJDmCDpsF+D2YtHSYKL
fjvxAOk4n6YS2VCe6A42SKpyfv7xHD5IXKF+vP+2gyIZ9MI2CzcNWKImlGb4mfeFBMtnEdAbtKWI
sYXeG/1y+hD7Nxo6kdgdUTlf59Pcz6qlOlep36ojVaRHvreuJg9UUwR+MMk1RCKJ218Rr5vGUoQC
FaJYBU3oSzQju0htmVtT1ygIsy9btGVKe3SrDYNTTm+MnJBYNoTpYc37s3zkcWO+4gXyoGEmrRPS
TPEjpmtbuUt494xF1dWXbhJAQZVb6Jxsjq3rBLZmi676yZ5r/pvDFvybmdvXwhUXS7okUoFf/z0b
YzVKUk9wAsu5f6+eOrQtORXtt9UIWZThLyUvyBH1U3DzflPxiiC7cc1ylBF/ieJMRfFx9L/POvsl
EIO7A0bqIrrxDeyINaOGyooAGYrIo33mBCQKKCUreBWzEX0ioNoLKL0HBx1rs2HGo4bxg8LGXWpO
1jxlnzcG3I9zWuD5/pYZU9BJTYf8DcxLklnb+9l6nVB1U8MeKaWg1iq14W82pZf2qKbtWPoeFvp2
esH7lTD9Lwd9+hgXGeR88hBp2Fbmd5SQXaRC/hucZhNUkhTf8ft/qeLO7DoMCBCHNyGetNKYTUmW
Ach1efrL/MR/WJEH1tvprRU4sTEHHqnEaCbSS8732+bRNHvRAocAy8kurxqoSk6T6RAgAmWWd51r
emxTu4l5ur2QdafyXVkexE8V7360gd6TJlKKlOH2/AYxZjpPGAyhUME0cYdo3MwsjeO22OBqH0nj
vUcIQ3uYLm0GeNL1R6qCYvm/23g/6jb0oCZZhhcmYFERsGQ7Z5niWIHTm0+E5Qvjpcg9Yh9nMBoP
rST1EA0Y0dr47eu2Tm7YoqCLjQptff33ZxGcrGiUe7pWIK/X/RdXrS66d/kAZR0riSWIjsSJFncg
c9Nc2YZ5igzfxrtwEcD+WoAgZ9C1RNRjBTPQ5CKI6CkB1qLrXsf48ldz4EspRmYfxl9giFKPSvUz
y/XGPtuwL6h6BALQegzLRg24Aq4z8cdURSSokSUW9GORwNjgLKvwBk3AK4MyBv+UIFh24G/sZaZx
L86QrKCQnEWNlw4ESlW+2mN+SqloVGtyh87DLfqsOzWSb5zcfh1myTZtc90ZsvPta5zM4WWsgeCp
yvLPwbLTxTnNMy6L168MYvB72xQ9QubjGhzb7JBBn3XcNASpAAaHIvwYZnkXnzRzoCvuKaRbW2hp
CXBdwUF4JRlZLLpZfpVvVlbbuxxcyEnqOphu2N4V2uTEPdIlm5Mc75f1dv7CnokuEwAplo/8MQtS
xEcmMuNwf9zJnTOYI232GuV9vqOT4LJ7nJGYdM8pY6cJwQvzlGJH8WuEhHxizyzUa9U4gC3F8CVa
7x3N0EoJCjgjbzfW27Z7v2Fgd+1T4bNhJFQj3AtETKQ35kFgn+nlGvsg7lA46mIOd7kl2Ysxq1XY
PDlcZ30D2AqBzDJnOxAPK1GXGG5nuaX84KMZFp9MJs9dQ/qGEYk3YGXOY40iKzyOcStQhzMsR8SL
sXlfyNhi/jQvCKAQeI+x7tRJUYkf8iWof5giXPJ3YU21gcATL6+7JKiiqY9B7KVW4li/rCXMrxY1
4yVyHLi0bsJgMap9B5UT+uZZCXuIb2kyIZV6kagNQbE0DMos2DqXa8GzCwheMUZ2Sofuj211GVoG
7n8V77vgB/14URCHpW+AKiycIrpeXd6jDI+/QeKIbqG6doZ8o6Z7TX+zYK2eGJDT/xKBQozCJPdR
b+C0sWDj7KehTVgnpnkokQ8pXn1REySSszUpIlklnLDmgDnvBq0vcAzsxIzqMXWAdrn+gVsioAOO
xwyx1hE0BfXIIlbzcjCRJQJjksJurT3/HL/eEVy4nRbayQtn24lSb4En1iIxJDzdrZBQhENYByyJ
rLOnBvZy6qh93bkdYLIBW+JwnMdRMXL+KboNe2P4aVbKmkCoV9enA7Tpzyf96gXgeYcWvUcjNxDM
jlaQPOWGiBiMfeVa0tpyiI27s9Hu59HKWKi5Ngot6X+vEXBYd0==