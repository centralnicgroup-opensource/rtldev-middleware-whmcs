<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwvY+bcdpTwUlj5lUXWGhpOeILUOflPPH/O5XiFGGERFHxnPv5+hANLn5at9OMa79wymGRA4
gV07Uxd9hvDdrsXGLWh6ilyDX9T6aJldJgt/gtzdYmaudQzD6TNZVkNXyj6GB6vI7Oz9dchgkNQf
D/Ptcidj22UNTeY2wAuVdAge137twuRAwf1o+Fxj3F/sPiiw4YIaH+yMRQ2VFq9Ne8s+22f2lGFE
4hCsGx28TWATPCuP1Qs4yJlEQDCvUgWTb3Ig47/2LTKCgJq4gYZqF/+XpxxMwsmSprfXyjI9PBXj
4BYPPqJywoKtGAL10JEpnRDX2UCojBNBqGe5DEAyj2dnkj0G7Ycucckm2vKPdgKQ4zVu5axtcCDy
4pPNltYX0LZj8+UG0Dx5CfoAswTIzwbthFltPHB5scQnnofjPnZeN468GcJbjRhs2d0HV00OojQd
KWugfTgaCIk5mI51+dixx5An592aR5B73ndY4o/QODkt3z/SYpUU2Xnt9+7Pv71OsNMPcHgSRhEC
IMmP5+3SyIqwg8OudHY18BO+N/o7XqEgwGP1osBavwnJgqkDm8BUmfUkuznSV+CGIbVqZaO0m/75
Y1PMTI4AoNGVVjMpT3NkHALTGkoRakzTArFKHK/DX74C0W9oDF+SLyuJAdBYuvLr8sI+Buljuq0x
vD+fsvaM78pofeMJLvv1hyPC9Un5re4tJm78VnJLW4rxuS3cSdHxSB5KjOT8HgsFYzkBnFKkjH3G
4CluZDSaf2seDkVLCHBBuwG22rLchGrM8gSG7/1SydybhxvVO/wz8jNfilE3vwBGCsTQDNFy/ODb
Bb/DVVbDSqQa2FIyCVVvIhj+aR0UMUbM28bm5ST7BPbUXrVqt1OzjLhKFGqT5LgFWuHNTBnUMnx8
sGsWaRoe9zGq/ke5WW1XkBVAgQTPpepSbzd4apIVyVPPpgZYjtINTNYU0DUDBzG9rKWwZp0OfKmj
nVLSWAFI0cipB04B/kurxkWkouZ6eSV2gjRYmEaLcUfIeBWfhOdQe5lrrFPEFndFyVEazGWnaqLF
XsugjtC1+oYzGiImFe/Gd7UaxVLL8028+Qwc2cZzzSpLmeqvy3Yg/HZ1CullZDNyxjYjbU3Nw80l
ZwVXaEFCMHnJdnkCLVFRqHdr7digWGxvAYjK5T/pu9m2OhUkNysO3fgPlr/wMFOQ7Y07WdZHBEyx
hAk3I0HGb4wgD8tXqYUawwOuGeyJiuz+0qhMOmcMa8cEKJXqbYc9pVHZTHVJeXiYWF/CdJWmOjqH
Kk5Ziy7ARxiD9xugJRYLngoxGdeT7V3fqDpSj1Qzy8TFs9T+IpqaEIYZymCsl/d1MHgExcZ14wcA
WgIDJCvs5Ol6VoCNnR8R2XvcKaPCJu/swKkLg8sedLWrkExeKPro4Hz/W+XDgEp9nENbC3tJpZk3
b+8ebL/hCTy2OjpqWzQSMR6oGvUDzSGpNozzmRu+xOeuUqmq5qOJ9Z4+qFnW0h1hEwPC00Kn8WSc
IbxCiwLkx7p0TE9OOyWaxYwTqGLfOgnw7l6AWcl9xJcZ+jfiBpK/X/6dfqRLdYFaBw23o0avPLjH
B91bz42UEnacdsl194iQsupMJWlS/maB6i3S9pPspZ6r6kxwAem6RfUV7erQGHz40sWsxHWoWT3D
vEfRbSPSKXh4g19Swr7pslJax4bz6PTNAvWejhBefxd30FhO+TwjGQNyCqf660ZkLfB5VSzPQic6
9gWa66tE3qCpdnag4UncIM1MWdPXRyjrBJy4QGvYjpJKmAV1shOs1y1jQvtKT1e/2uuWK2wFMsFj
KsPR5JZudea7hiyHd+Ucw0SA105VGkZQRICA16sDtPUrSRsiFGuOjpZouQ9BtHWLVL/eq4ZSK7hB
HfB1cPmiPyPeTtgycePquC4hKwzrHs1DJRTqf460gLfAcsnSRqfUhhLpb+ir0mSJ9EEu75N20yCi
d12LXHPcahZjXQWtnoSahdIKjXxdd75ZuLAOJlumKSGgiHQlPxWuH5lwioeQCVshBs5tlDWZ0yGZ
G8EZND7AIIlPWcs6OpcwE9oIlGI+jOB0GRgEdhVWqjhcc9bU+l0oHJ7nbaz3uz4CNIw2XC1DUbmg
Z/OrqWypEWjB+Qmu90L+8YhIIrB76yQTChVgBQiALoyfT5dOfBJE2gLLtn7rj02CmWf6MjyzitWW
B+enB7jJLjQle+q9AteXtLXHUbd9uDaOVHCR4/A0Nubr8sMFDMCJcdbyi/r6GYIGX0wu5XQ9ecHt
tGcIsjhbiJe16vC4WbHD4N3sPYORZ09+kGDc9Vqpo+gcGiQJGZKjxVkBJPpTMYddA0EuBb/BjP3H
8HdWPtuQznaoE76KNwPz4zC2gO2ANTxsvXI2jjHIPtO5hC5KVrA+FWe14G==