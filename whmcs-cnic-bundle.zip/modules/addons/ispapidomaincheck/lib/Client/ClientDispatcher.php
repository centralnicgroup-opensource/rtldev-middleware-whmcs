<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+ryDOplmusZzi+WhwvwvizmeyiGIusbAi0BeN+Qr8IEbvLOVclAVgSW1A2cclU+fIprTtDL
WhIIK+KfQd4EakdJ9y92piU5QnLBVXaG0ekjSCid2wb+kOOrpYmpb5wLzRPrTC/nQQEsvLYts3Vr
q2jhGIDHYy+Lnt+Rz4LFXPd64305tKf2zFThMzq8y2QgyB7jiTY+akZvSCvNNUzeooLa+ufCvRGj
6kAvJHfndonIS1Tbz6r/lfHVTGv2fvT7L82cQe0UhFE8wjCb0dk61sISd4jQOM/rc7veG3bv26EH
6AXx1m//I6HkJvHX/g5EDJ4XSGv8u6vHgyPgovbZShh/SLt8heJEi80cOL+RuL/5KZu7Mwnro2Nv
ZzZtxOWjKs4X6bFAcpfJndkIKy+nVH9Fdcm1wIuXJ6pJ7+IVA/icBbyYok40iQIRubFMcj+D5Mvx
ZH5hIxb74FxFHVivx3eZE/bixxoB5b1ZDDats4uveXr9q/RPorgbZNCDgbjNQo4rvEdD2UX8fSF9
2yTD47PcfzNKrkVQ1rMmZvkoPRIha/ym1kW6Xukv3HlQR842LMx1mwaaa3ZsSfdc7ScOe92m1TPy
gwE3JZFoOwcbtgcv6sHd0hmll7xPYSTRrd5hBKZx7nspBV/YprN+K3JYwiGrFuitsk0OL+APtzr/
+dYiQwiTnYIsYRGi4+jgr/HEDfnmfofoJ0XPRmtRKsrW95v1upcqZtd7WA9OE6GCjKsDabQhiJwE
uR+ZbC9NnxOcu7m5ChrBdmpvVY6hczX2bio98ra/zg75RWBOi4mC7KA2WGQmr/nlOAQjgluqTRaC
C+VmSSHQjwTFRheecaGNRXfqqfc2OkJ9PEbZudzYehiD+gRdKLJjjNNAtUG7iqLUllOSBLuwKVGZ
qO6KwjZxnhJtOwcbsd4P30Rk/Nq7hSIo+I35W1moUzcxwG+96GFHjBzIqmBojioAo5SoGgTk+tDd
pJUVv8P1qS5PggDy2cXW0L3Gw13RDdoIyXwn9P905n+8L/NmyHAzQl7RjSr6+rT36qlZNBDQWFf2
huwvMalrt3kt5ioR6zKMZXPUxbFXXBU3+HARGXl+qhuSgRMDndoGBTCjginN2/842jLk+Z4kXpul
HV4e/rUePgFtGOfZCKxAE6aYScIR8l9CHHbhHAxS4zI5Z2RDmf0P8Z/MIlMQ+zvTWkELwTN8Q4dn
7weY7RbldjgTkF+K/fa6cUb/PR3bU59zv8yHps+FRVTNoenoIvDgIoakqkn3WSyCBVFAKaPKn8fc
AO+RhtN7w4rP+Knp892/qOTPxv7NUNq9V2Bxq/wO7BFWD1tvaXJ/QmX6iFPwGQJhOq63j5iV8JvM
x6qbBcUx+gvB6s6SWgfkcSEiIj7x56tLHSWZQW4ArBeFlcmYS3Q83ssHuRwE/1wBPmpyBfsrPX6l
5Xwmka9/9Wz5qcAh11bRQBmjZfEXU/FlxSgc+Jvj9CpMZySGTbOgIcm9j8pxw78TOsKPioyblb//
NdSFb8ii9vtTkGy2gYN9VCNfVtZy83zHZYz01LvId+wyNQipLq2d2gz4mLA7RXweTaPdsFqfDs2M
bvzvOs+oEbkIE2ZwQsH/d8W4iab6yDzt9F0HrB/wtP/NVBPw12jtBtjI/+skdR9iTxil7CSpbJyN
6MHP1muI2g+QN8BqBUSxId45BCrNhDaIiBJcuIFRcinkQoPQxIPh5BAOmFGoZYW4MQ4NZpCYS4cq
924XZ5EzxP5mXAQ0Z0gE8EY55L/g2OijL/x9R12NRR1U4HcMpgq/5lE3W7FQwM1AIO6a3B0Shi3s
OEAxQ5Zg4J+87jBgi41yt9r+5m24ClXtc/M7dAiWPhEq1oJFDOsylwV3rZjNTAbGcq0UZFomWxKq
b6DGRJDgbq6+f80OrkAjWaV1RQFOdRWwZboggsiQk7dR/9CL8MpdDvpd3DxNBNEqk+AAKWw9T+oW
Px9IH9aAKngcNcOWv2/izHJJh83W6nMjg4FitkyE1sd+JqaXZdSVmtLgq2WsCpuoseDo0i56ABtn
9js55xW/VLJ90igrTQv0NSLvRv/9UB/RE9Szb1tpuCfeo9V5uPJQHPR/VZx/qe3pKaYPIW7GdzFb
zuToNo8rzTx2hm+tq/qruF0Jndm4lqx3M6kdmc83pAuvMw7epPSPZM4DD6Lx2rnYC9wLQupNbH0s
YH0W+g54r/2LQOKBGG1N2/xZrPkOoYzyvV9HvINMUcPRq6Zy745K5zkrIL97kJqUzKFVNBA2hdqo
vO+sIYlsp5ps/g6enfeLEaQ7G//tjGzfvUbxJt3CqzzptPhkE/FUR/fM2nhonv/LP9AjvgIu8+ya
BfzPPGP2LwZtnn8RRyN40XzC1zkVKYm5TqL20xUfDnS1wG==