<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtA57LYIQ+QVQpQ8UyE0w7RoKhLzqKgv+BUuzDw5PWMr08npjDXAI8uhMOEGHyef3+S5cOvr
1IJlTsVhgMnOACVwYtviskyddFaI1JMx5LzN5CsygLHdwPzHgkI4J0BtphXDvd8KYBEua6AxIcNd
ou0zNrJdXZhg/bFqUDbkOdbtwAz9GTLdcnqc24MH+bZMaLuY3ZCFgy0ukXS8ndmV99Dmo7ZQnF3T
oaEaBEljgoo12BRUkX/rk7VDQ8/fdysC+FFK4LZ16OUBPrHyK4fycPXPjuXjXktp4KVAID7Vitjj
AySUaCDg2vyN73jPrqE6f+iumXquczh1iC2JKEYggotbJZuTaqPtgD+jVBlCD5oeO1lyU+5mLVZj
Ng3gQzOvbkvrSm8wgV+ZzqlN24Zgu29pQSd8C+AbaCHVcb2nr14iYQiCm1JZTnuUjdS2lQdTcPLB
vNeK9lit1mx7jqa7G5m5WuKKsvE+pD9Vf8DYqPzvFPXDWvwWNM9hQhoZZ+fkguiV1YM/fq1Uv3l1
2wyE0QRLzB4SoQ2voWYwUm8TZRVee9eJNSbSLOxnXbegtMAoIHqtHVisNFNZ7bSzDdr78LzcwtIM
4BUiEN2cSk/rkaaQzhRMRIJCN884HPtVRmk6pRVBldftNSMOx0V/DRDgqxzgpkKOyHn7HuxNVmrN
L9fYHOBIdRSxRHhQuAiEdxh2dS77OWJDqa93krlWlx+iaUcSKCbJMkSRRj2M07aFElajjc/i08rR
lNfecHSI7sZoJcjKvwa6dc0KrY4O8+dsS84Sl8YoMUORzrM2whpmy4EIL4WZ6zrjKVewqsjc/tzU
kDXpqBy0kF8OIXnVZz/jXTs2jRDu0GhC3vw+PgJWc6C0bfppaqQFB5XajOtaLxILJeCIAbZlYr1F
ckmvWEK9PcZri+jpFsyfxruoO7Yw/k8Ja3P8bEUmlVbd3vtHzxMYjGxldc+8PxWM8qt7ki5pnNeg
86Tx58KgWXMyLnJmFeMDK8Au4Pnl4DlMpPlDe5k979UENKD4+inGkpJjZe3DuIz8N06GwBg8xF67
232W9WTYGuzDEIDBZfhOQgmu+i0cKyHQAIaeZDSHqfvxHJugfKx3PhYvUn+MdPUKbnUbw+gloyMS
KOvhsaBkOMT74URw6Xo3w7SeVbfJ4nOKP+ct+CkLQGe2201mfSqg/RWPRbXmS9R00+lR1s+yp1Uv
+6B096bjyt4Y6FCxcfCOAI44B0ERANefIZrY3d54HUtYWcsldxXdIMRjjzdiYINLrW5qMh2vB7qX
Cqqs8sHe3Qt2otW3KPgfiU+3+EyXlR4PmfzDqHz0uDatVR8+aBOlhYExwQuCH2REa1ewNJKiaxCf
BeTnHe4OYfyIsFflLd7HofTw2iEUYUNL3irFGOH1MzWjwYzXEZrvPgx3zGvcC19DUP2sVnL7rwTF
V2wHehFUJmP3L26h/HvxEGK1kwLgDNsBxgS1/GfxCuqhZXm6HYfnEB9u9aarPpJx8pbTlj3el0JV
gRGjG/jWVyvE//OmB4980RefqKHt0Reo5U9pD+vslhjIN8t4se3CQ2mbY2BO6El3iUdEH7yLQ3eJ
mqC+bUf7ZgQrTVO/eyLR447ouwYBrjlDZz5bgiyDT4GuH2ynrkUAO4g8Ct1ZlEqctmhBX7djH+me
wD0oiJJ6Ik3L2Ay/XAqlqC3ORI4X/+l5vF/VwZEn3joPSHhAKkF708+K6p2garGPrV392XApIaIv
YLW4zXC37BLuMQcM08Wb5E3zXnDSnwZMb6HL2KYZij7nzbSOJBTCMMZ2IfbAG0Ci7n8i1BHxyLX0
EkgH1B5iwQXkvDQzDwJc+tZ7O8XjzVCwqKoL6MdahBErroKliLFIiEhnZV2M7zO2j6Z7udBTXaRp
lF4xlCPwZS8FzlJtRndOVo+3iIt6Qstr7XQCnljFzAyJiBo4aZEOSucBgQ1YrMW8pIBLBVihjCdc
j+YpnoEL589Q4pXgve9bWvmbgt49xDO43FL+LCC/IFwAWWmFIIpTWkS80+x2KZILJLsb9fAIQbPQ
b5VUqjPiHoPLIuYLAta05vmv6AU+AtTUjB/TTxf9Oraffly0wtmT5pCaea+9zjHCxI4dNLXVqcNu
ei3L13WSyPx6B8v/YiFSTYzsUAi/6JQTrFgjBWbtmgmOvpSxOsyTQ/pVwfuVtoNvVJP8IOoD2vV9
6fVzRJ+0925my1x5bS8DFNoa5H0BJvWimZJI63yurwD/+EN1AUlfGWkQmT26dV4WMPZ7Mgkab7lA
LfnV7rV27oZyZZ0pOTVzrWFnpu1T7FVriIh4nIZ5ZbbvvtEoVlGf5UDY0ZWiCdN3FMP+zMemROZf
pAzSnqKFmnfhan8JC2ahbHfZhoGi54ZBKmKqjPp3gRZn1giQ