<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqRZmYQ9JJS9L51N1Lp7RCNj6WNuKWwFg+zKuRaOmT3DzmfGOMnf1cp1+Oh5zUt/A3Lkd9ls
LC8NHR+7y5HVzepzgNXdLD35JuLZjtOxZflIu2iZZc78hx7pqyiJItpIeAbgJ1h8qvhdlq1N5XBe
snAI0OTCAleTHXrinatVTQ5get7a8oy6xANVhYKfZvbZJwtRoFFGHwBPfp45SVVdymvgpWIB4UIQ
WIp/nVBbxjCpOgaOgb2WrtOe9jobC4faHfuqnEKUm2YPmMiNznedaAq95AXecUvjQKfo4xGJvDXR
y1Ut2oXd89IiewhojngyAK5G5kLrfon5/BBwjK9cVhIacIm2M1ppXnGa9ZJq+A5NJjFlCPz83nSw
DwYUbDnX8A0MaVtXj6dVbqyY3H7WM9baX09/D3SJWJGigKaaWoFabvDrDDRKkZxgk0SZKx2NXfxm
8fNElrmd0ub385iSyaQatYmX4imLYtMV1caOc+yFrpYXwbcfMdNo9xAY+oCi+XLmBuLaYUqUQKuW
jK+5PoPoDMJ6T7MDU20iSWATNUi/XwWb7MXiVMnKYhiFbSHzZ76z1RhR2yLWWYS135AhykqO2W5m
i/NR3L8fMIlZBKh+mV4cqgTVkEqGUcIG4GKKCoYR8GSogFT/J5m9izBFKn3FG2t/8tgO1lYHDSh2
SBpDT2CqyZDLZCQ9nKdqz8FiFPrq1BPTL6cSihl675/V4mFVQLMf940BY2ojt3xv1o448tbmrVBY
96ZlY7OCknziU/skQc1n7R7ZaKceao4elPf8BUUMyxdgz77W7cmYMK9CjQGTNUFOz97IbHdyxpF/
T2IGRnlUn0i0Q2SawJuh2lGhxYa96ckYXodWSvoNoU3HySWzAIYTi3jZSUH/T5Fiz8mZo1D8Fi5s
w9+jHgMNd2CYWyN3sSjITmY+vgNwRAdphQB4IuXa7syRUXYIIP/M3bYgJ8WOgPn1XpjsZ6EfSMlN
Vb2kETTq/3JoetB6Wz8L072NE/yk4dV0tKAqESJb3WtZQn8fsWsVf7leG20VbkJSAcFjh3kKhDbd
9jZolAPi1QKvdWXw2Uf7nhcDwnmiCBrlPj1h7coFfosmpOEzaKvcRfRSnBnSlvTVokTOVcoCg0Pa
fMy7M2tyCPCedDQlyhFzsBcWWHHS4xq6FlS2ZcXHabQ+tVvpEfkS/3REdjIRxFt9JQixPZLsThnP
/0IH8v4POwLESxatvikZVCcXwr96hBEqA2JbXxJZyRQmI8SOco7+SB13cWK/Cfj2N1+B9DoBw2PJ
4blwYmOj58Ys3OiFpW5x/6oQ3THlVe8fbIcGAQUJWy8IWzj5XBq7b/gMksIkdF42/wyWZqbnuEWJ
U5r7N3+yo6w/vwXbLw/j7oVfqQhubzYhyxwK37AsoNUToUrFDUYdUwKHe7mlwEVBq23vCnJOjwdh
JH9vUiyquRIObUeUcT+ODuh0NhMnND3SqMzIEjktrbW4xtBeTkiVrzFd0f4jCrOaYBsmAagpznyN
zoD7U3P0YKPEfl6CSoKxugxH/iw7+UV1rdt7zBoZWzDNsxSbT1QSbkwA2Ql5DkNUflkc5huwA8y4
GXgx+NPwGGJo5ltzwfiam9sy6QfefoxqKwa6tf4NEKWdVZyN1xDasv84BT5mxQOU6u3eD1MWB6li
BOTWt3EEPAuE19qDO4RHi252PqN/23ICuRi7t/oxrtzCzidTJ//fJZLAs9taSDBReiXR2H+GLMZ4
lVrqjlP0qSr0hmVA9feZALnzkc9a4LS0xBkOcd4rIahpQqTOqcFK3DfafbA8/4ba1GJnfTT2xFuW
m7pI8UHfGEYntqB3JPO5eeBnhl/apKN1MKa76TTtEW6+Cu1L9foHcGaY0SEN0nNzYnevqUSoO0zF
OYwbikPYMRkaO1AA1ITXg2pePlvUiCBjukbDGpRGZUsEDFId4HrTHUZIOwUqyBmQt0mVuAz+bP+2
sfO5NUNE5KXD+1AsiE/iYuVCJl5JmdAmy8/x4HEmZ3ZtHlL0QnRG5mzWMl9EDnVgE8vEoRhEtxxv
tuspYucyKoiQ9FU9qQlYnACViFoAKhtuAIypaaMUvyHhqMqHy2ZLcBvHsS2GcRDXsFWWmF/5DoMP
HWaIatChN7ELCOBtvy3vxshPqWLhpUyHJzZrrPD8SAbVc1IcvztotjVHrLvHo1aTx/1zcK4fPQDJ
8uSOUcorA1ssf8NQow1ZzB9Lxs5Zc3y+4FNPPAhLD1ol8gDNDYYcHlEUFsXVpGhj++JmI6dSv//x
lkSLfZLVoOrXSpJ3TrxLr0Yae9SmeKv091nR88QyvBW0fmq0IWDf7sLhKJUsaH+vAOoR/PVBo10I
2zIwzat/PLXeOJymQMaq5NeuV9upO+LAk34N2CdRN7cWNLOhjsCLvVa=