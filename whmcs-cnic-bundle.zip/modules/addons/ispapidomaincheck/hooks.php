<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuWQRL57vLLd7gduSW6Jzg/y/PwY2g4S096uzWQIgVeSJiAR5esDloplN2h2cDSYKqFtzyHn
vh2Itz8NBx8ahJllmvKMg6EW/QEyRmCYlKxSGGIhYdbTgjjz+RSi43bzaKNx0TIxf6lg9GUMwQ27
TlbPXi8bqctoc+MZzClYEesNbT2LlIsEiDFh8Rn6QFO5kBYpoiu+wWeGWjJPjgXYR1E8VNMfp4gy
huoAORLrAe09obsvVCQ4GOKe8WbwUmq+XHSB6Xvx2Kcg5sZutGYHisO+NiHhnUplLuDBLqZRCCr7
EQSkHr8iq0CQZGDx0Qf+A37xFRIwXGS+Nlv1+TFUn05NfoqW4mxCMg/Bg7EQHYf4N0e0gbks3nHG
RtUwWM8bQhPsbmnMpWXcXCtQZW57Vg047PvpOowGvcR5OEvuD3SSHjC8zr8/mR5BVMCZLowCCVMP
4GHcm4/7qTjM2p+DwQUSsO88on4uE7ZWWm+ePjQuh0Ta3gqeYDFQYFxOTPyGrNzyeSKNe3YJae2/
0HF+l44u5sGgj167yo7R96buhkocH07evoV97HZYj5jHJOV943WpK/YzSLew2JWeoprdBbDZnPYt
nhk4JlsUq2ObnQ5hRuanSZcC8c29AT+P18zIC0CWB8Ylq7MXn6x/86b7mtGqJCy4BrRduAl3MPn7
NCBrLg495WZyk16rhhisciKE9Pf0k6/UiayHTufOMAQu/HFRNpUUOj7yQPr9RpgcGQ8REgS7zEl3
AoV6vgk3Zw/VoGWm5Bpxp2ykfLuSjn1Bv6R4jmLZA5LIJDtEOq/XzVfnc5+q2wrgoJHcSsoMM+8g
hgXS9zZjklLF6Qqqo9g+oxupaqg/9xf+7qKNPfq18vh/jv9gwTHtQOQ15nw1rYID9r5qgU4Cpdx4
ApFQz1XFUPAbsSVqDft1pXv3Gh4vemWkkAFKsLPU38jUUTfufTj/+VBFYP0O9agicondTxNG1tyF
dS+Q4AMy1qkI4Q/qMJRYrMxnnOa/vgHSKk81ao8Go9PdLN/07b4GPKXlV9f32i5xrGvBeC1EuMm/
mRj6A1KzeMxM60iVl9H+3DQJyH/aHW+bwBtj9gUShA87fZwAtTRxpCdUa+lHJU9iaFo0Xhpn3Dh7
/Qyt0zlCPprSAZkGXR1XeBaOL90oTiYbCxTg+ayrSKwGNE0erAIYHKtIunAGFqN0NQf3MHvFN1YF
m3jW9wdWUJTwpmOK/BebaMygJwQArB2q7QFLu8TSq/L45knS2MvUx3cLuMMH/nwlxrNQvw0V3J1F
EciLDg/WHbf3JMM2owK3UPkPSgpwsG39cVDYU2+zy+q2Hsrf4VkeoOLkOO0JvN/tLL4JQOTKEsyA
VmB1EsX2aF5kfVJ0YFviu4vOswZ8RdQ3LNyHjqJUMsnCj//Tuc9amSq4ZxEz9cCev9kT1hhveMMO
LM5eiQeEN0HZK+K0QJ2NuW0q4ZiqGf3yJSoEXmITdmAVzbYmGbI5h9weGR3ZjpjeO9s7e1At+Hgn
Iumz+D3VVth6M7NYdlHl4DP+BtBIr1Ed0+KXLbWYJkXjH597Jh2AIiHfvTGxeqfHcZhycLENP+9A
uvu2b+btovgwsfCIvdp4BGNts/Q4FawOhP3I47uJyGX8Jw7Chu8nu1sbYbM5h6PSAIWC27g9QjcQ
EurNykwLb6gqZB3RoO8n1GTAm1bznccxPZQ8vdjWmZfj4iwrxm1EQXaUTkQFke3CId34KyCiMHCA
XW+SCYbCIHuDTj0rkETFENXZFRW7Y3befR9HJttKoJ+9SrA7fXz1ogVAzoZfuAhCasTkziAKybUY
azTQLI78StMKP8vbepZ2GsKgtJT2W61s/6TD9xa9YNLoWjLByjSuO8TpGO12vLkVp1XozPegWFP5
uvCTPzfxRJX9FyUbn4dkm7c4jYJZ9GNOOR9M813Y1ADmJpfyiYmKreP//fpvgjmXlVSms215mLPj
zUM2Ycc7XRGQPGqFQ3Fy4BFq/SL7dJEO3+FIsvBWFKzxn2zwsoX8jlwlseYhL32t3ntyPeZTlXnD
xv38Qc6iXJs9+Y2TRTsOgn9sRoj33yr0troIz3+M3WkwBafRGvXYHjzgeVFchjNpXZkpVGiOxiN2
HmhokxnFjj/8Kt2bNGovlHzFRuu071OE3GOPl+FCfqDEy0BivTacUVph+zxzEpfdqtXu0t6NBsgR
aU6Jx+mujUp5v+nCEGa3fof0fSR4AR4=