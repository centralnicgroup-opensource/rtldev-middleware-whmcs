<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt8bGY7i2BSMwPRN0Y2lMHNXVBcXX6T+tjWaER2MVRN7aw06HTQQ2Ujg1T0wfLe0zLGPP2dy
gcoMdbrkRdp2uHSpJyuQ/plSGwxUguma3VrVcH3K1gIn8eXxybHbsz8LgQjh5ChiP01naY1Y4Rky
NWJS/q1N+lmRbxK2Q8nlHEIwIryGlb7qte9GvFFwZrGZKVA9pfoQwq/gX6nqeTHConQC9JTu1bfA
ARgPqlQeuJA1LpDcvY2DXiINanpjw0WJ6yBUbP5dKVkpAfdJ8lgJLkEpV/sI4MpTdIJKtQ9IrL7X
pE7KnaaMixGfPuXEYQg2C+zF6tZheWLh+Oe0KOahR2G6FinDMaO7ZIYPXfFZzvJFor07P5NHEKsI
vTvqvMAIsxG+Aw6CE0MlKJLmARVQE4ivdhGaJHuVdZaYGhoFFd2w0KLbA4la3G2mbQ8opG40+szU
kgoOPRnQaGV17EoOV1ScdeNlIykmEyC5bkYEuYKXlKmBnPO2w+i6LOk8Vdxyb3b7k4vBtS7gTbES
3S3JznBtvRYlpeWbdzhez4i/J0KH40qWn1Zm1i8iij+Aqc3H1HdIZM0pUwKfY69I0HR4ONBeHpYu
AwVedEuxZ/bVAdvbETOKf/O2iOLwTHEoHW+nlqYQ9XLBke9lq+sQHOBfDlyU/N4r+5GZX1NSOl4A
WYUV0xW14RFNJNFkHODRB7V+Iwku6om3hgHvrSjIpcmBXagfimCgmdpJsWzTUUJg8GBg5OSN2Ahm
x9wtRn6kV3Oh4tzwWJjZdI8nXF0UW0XQeGBNWjjAmWvUYPK1iyuxJKj8yJeqqa+w6Q3/LlBn/i9D
gk9l2cv75jfEaVFBZHaS6Zh/0c96p/x7qf/SiRLMGeu9hfRd25advifAiXXQTVwq2KuScfmAlTEb
gIKpv4pq9qBq2xAFr9NY2gKMO58Br7FiA+EpQ/0GcnCwAKaLCoKt6rIFtDzkBof6Ym20TuCmbTEP
gizSaJf2GJeY17Ik5fng/EpBWEw6r1XhGoc/0DTZWieH0+Y2LvsiE/LYrzP1UEh2dpRjtUaQ/I+p
KIt8fS9q7BlZhKjmo74fsZDDLJfIq0Bxo+FiVFabM6HNEcUT89WdDtsHVYauB477Jekl696w5Mom
3QqM+ke0/wGTrtKt5bKPTMVNsVm6a9C3yaXWFynVImEuhN4OUgMx0ZU17U9QpamTnQ+xASTXwTPr
oPQsNmpbvu3/nihFJ2tjuiHOdGW3Q3IZ3UWGBfP5apqshzvQ0NcRPYUWvMHTSf8a/gKwKejqoL0R
xUFAKSgN7M9ggfqS5XnLQRnpY+n34Vk2ZnQmx0eq8q2JLxZB+C17bug3CW8Pp3F/eDhc0jq+LjeB
Yu5uaTc3GGt670RyBGgHxJJxYOgXubLoO8zHtvXuqt5dXqzUVEkurcQO7qfDJTQ5nMCI7t5XVGWa
el5tt1RVdQNrcr+bzGQaJRSzVqsZNvpFrmxbr4gmTTjcaN4A/X01ul6Ph8xqKeErSr4zfVvWLihm
qeN4ZqreKwl9a5iRYJsW19EtDa99NG4/gfOdpjcFMvaTEK3aJDRBqM9JRmmWRrt2dNJYyzwpXAKh
UXK+M1O0t4gpDvYcAcfjtHG6mz3tTsSKQg8iw12bwHypUdgGwYglXa5niBACRe1H9pO66LBOcSJJ
q7ZQGevQPGuZchiVU6G26U2xGMFO8JOLtYtQsh0w3zpee/YcoSa0UQNrS5/d3sPjIrDShOY4B04J
6abREa/kHq2h9fcb4rANufGp8braBMqOxB+u2OVyb5ZSD7DstWB/ID0XevbY8wPGRPA+9wIwmng+
anFJjcU1k4ERJ6P/YgwEgvsr8ujxyNXiRvmWxUY5QbFjelBgLBQGWfRHZMmEpYKrJ5pEunY8hqr7
sM+9nO1wYy4bpFrN01037pMCNvs4RV83Oixl+c2Yry1X78ijNGBz0jF05TkPvm+80qU2dY/aetVL
Q6vW6/KL45kNehK0s34toa+f9bgDg4omsbBjeFHbcy4UfTNG5JfBaD8gGrUgPGomJW0CXivODp0b
ZzYi1W75LnvJ2/8UC05Xh+QyIK6xNN/LNVvYIhAfyq3AlRTq3yDLB6T42+LtX2muR+fdvbmY1sGo
/hNALf9M3HhrJ3cXanY/fHiN/wFMaVrgK+v/ilGrqdnuu+o4C9pPdLRTz3+DhG9IdEAJYTm4O/zL
04+mkTHhHGLEZBrv5diViWkqTJS=