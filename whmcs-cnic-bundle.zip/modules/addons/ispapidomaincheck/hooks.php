<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs2Bs33zQY47+3XD4th0bjNjCg/ASF9VLuIumbPOobiIsZWTFWmkYLoUxEqDENM3mTJsjyOG
2NCCrZ8QQ5zOJdDLdaEUE6SQcjRsmnH3UXCkUOjKeAz+yovguX2a+iVqSs60x63hzHpKgLAZvaID
SIB5rItaMtI/983ceAtyyxOVePZX3JwR8nzOGX+vUTarPihg4wNRptKKkk3OP17OXyg/Wt/3baTf
9bm2EJcuCWyrm4SXrVAwtLxmXyYtgL6YN2gKNazPctGn2vxb75HMiM0PiN1ezXU7ZI7H+1+HzjRc
o4TpPmlaowM+zdmgexmjGqrzTXB7uhLLCRtCH//Ao137erSk+9emGpOu2iflvM0WNLVhZhV8o6LZ
De6YWMJM2SVCvqqKQ5Du4cQCnK2gbK0VSKqp2XbTdOFxxWNV8m1hd8Jk1AIah9D/gtIJ09m0M8nq
pMDZE9Nftr2tvMSZbcrb0lss6sELX4N04uQ4qeXInZX9PCk4vZ5pq9oL2W9OkKolwQxLZBkitS9J
gUF/GpNmEN6CWFp4MtY5yDesHB8KkzTuwnZZZ0EJv4wtoHXN5e+kbhLawiQ/6IpeylBGuK9e33si
HL4JXMMEMxnIVz7NgQz6IfIajHEMINt1i9W/EWagZlgTXQtg+XngQ8brZiCWcEnFdYl9pFdelQM8
ScdqRYEX6ne23YI401+Kax6C9r6rEmRpjfGY7q6TCL5wRv9BHDQndr7b06jJBIqNkWpWrolU+647
z8zxwcsARLlceTUfNCCHoLsgKBcy+bUxfehw+NfbYfDsbbIPPZqYtAlvGZ72H8KV3uXM2OL+DdFc
nmnlr579BhQwaFm0LfqO5+8KT3yVfDp0bRJAtDzdYwRAe2LUkD1Azk4fruJJrFe2nbzQdspTSSKf
I0TmoE+SNdaoFbSSl3Ilb947bSlHUT2n1E2nCLsxAJdl2nco35WkaEA90O8Hjee53tfL573jVEr8
eCtaeVmdQGHUsL9bucelrt0wVayOfdiB3x2oHfusrzP+qaJ+YPDHVYUzcFXq+b5Gv2pwLqeQMzYX
ApI/kuYA9LPZKAU6Gl4Owky2VLTVXRXaBmFMdLCIX9eYvKhuEvso/pWK2jXqXcH3wboUJWTHZ36g
lBfzQqP7wt7S1t7sYQjV0QmYwb0PuU2p+UicKJrMWZH28vBb37Fcm/v9UWxtPohEGj0WbaqM2+5Q
m40Gz4V/flbvbdewNuzUNEXA0narTs43pD57CcZts+RLjpVdCmxv5hTXrdS2gZyCKD/pejlxOwtJ
OZEPpvgFt4tX1SFjpM8Tw0MkH7Tu40ukIoyYJfWhzsHIlDyooRNVAObXqxqXYN0C3P5pEF/ZxlVq
Je3S2Sto2qQPgGl7uycqXmNhzTrkOgeCs9xJi4M3sCQxHs5ynCH5g9zybLDNkzsVib4UACUnUuKg
o7lETnyH8HCCy531LU/rD5G3JdSsTtt9+0KSEqDuFj+L3/8pt9iE5QPPqRM3haa0Tt7wYonkQxKU
ugFpMrHOiqYhoIVzOwqHZRWGI7aBrmNOoORGHuXNzSO23cw0Ih7r3VeQgOutpAkA1CEVEVSG0cnH
BszZGJzDOjBltMv4mTpX1VXI7DwihDbXM83WwZbFD72poPOQbSiglgQlHVT3+Vj4zYx2kjcnTFeY
OUPKLAsuB/J/TN1r32Ew3P4DWpWHIxvw/nQAFcP0Q6Avy4DrlA6mCigefpupeMftcsdt6H/msTTr
eG7nVLiiPRk68UwZ2dlB/B5IGvv9b9o2AfYznOzAoDacJsRHer3j2JFPtX416BKgbJApl07MVuUc
ATTv2pMOjyImajnERBYQ14gXbCOu3yj3+KPeaaUrW4U8KsTiHykUNuWvffH9opjuCiFpZcNoUueq
8HYWcaVaijxC6CMclwxjqlSlFuCeDTG8Ovk0TV7nltkT7j6FodbghGYd9FB2bKf/uephJ3MeaPpY
5a0gnTNGpi6sAPGD6STLr8oUDrb1rLYYayrn+tt1KVN+hAuri4rkRrnrYJ57L4/Emps9FoaeTk4k
CslGvGp53W1MXjbNIKDyrnyXPnfHjXdzDXQBH4JkSYBCOgiFJOdA7Lb5uOahysepvhJs2JGOzQ1k
WbZVHdlPc8ubu1rkvP3iczTrIoyDWRM1XhevKaWTmRB68WTjKjYKpjuUj0ZnNUSJftBcG6AisRmu
onqMLJyTXUsVhG29YhUhBQtnpyNU