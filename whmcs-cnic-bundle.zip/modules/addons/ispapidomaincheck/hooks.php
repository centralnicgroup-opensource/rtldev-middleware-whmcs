<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzyrNAez6AMDE8R9YU7ofSgy0gIw0fZIaj2Ed+aS2zA3JdJsEtOzPrG0SpwYvUi1WJqtBv97
/gUc2/PMhbprhafRtOueCp2OII+cTL8Kp41dMSgex5wNGsC1TkYHE1NDzAlBhw+KRlOjDiIHXeyR
yo8TuD3Y89/P9hJL+qj9nzMF6VO5SBrLBu8kXS3NmP6UHeAs09zo/UeTCpVRh4hg9eCsZ9y0kXyJ
5gyfzQhUiztaBFsazdFW0sGPDplZjeSceos1RaJ4vNsNrsSO4b54C+NktqRzQYj93hbU5DXvqhv1
dTMcN//mrCnORCDvm32XMPdYgXpnWrY159JGAHcKm1ANEivgqkHIv53iuP8DJyOZ7hchzbsLm81m
AyooTT+A0OcPWUD/eXp0pmi4RcJK55wMRo5obTvb/I1n+FAUVkZipLkKjAuQSOOIMQqnxXVW00zA
/WRY4Rks1+liTl/UiixffvbscKxsI+euNJAd/59tXnwDjzYj9tALI6ywG42vvNY5wR/XOvJ/Hu7E
GLyi68Ln7sYLbZ7BGAspWvV/0HNoLYmb6mOxf1qFHh2DatWSN1ivOxICxc3a5wLb/qDPyUytvkt6
9tJZAeOvfHYZ4e2ojxEZaCtKCFoFZh8/WEKGQFOLWdz1/qabv+FlWtBZeSkfv5b+EVh7Yk4s/XN2
ZiJdvWgnQi8mLT8paBYBPNq/oD1hkAnUIPM/mksdM8LQ5yS7qfmwxVhhw71Oa15rNO/V6vDi4DjJ
vzhmz0K/PlKUpwN4mhUwQC1QHSvXwDohl5enRUwE/Nuc+KEzsBwa1ziW5Dn/R27vtMP3/MuwbdSF
ytV61Hqi6O98NeMGN3FZbLtV7TflfnW9QXzk2HlsX8rsONOB5/Ft/oTpNfnRcXaKNRSQBgi+qelU
LYR28SUWyNz4TMgyHs/8WpNoOUy76swgxhxuyf8jt59flLsPyojy+G1qi3FFs00CLBtTr7h6cL6g
LPQsN0B/zB/f7E60CbQlQ3uUvy6gePabzTwdsCD0NNMdA5p5jl25BDVV2l4bhj50P5+2ol8Ge38D
flzpe+eO2BANSut3u7YZiRTZxguwtyf5EXeqweCu06HrZBhN066GVbgwICvKM0xJPNhQOgDIwXiB
BpZzFa1XchsEC1G46hRt/Vj5EE0TGMngfhqj9EHSnh/Jt2bqbri1m+zgSLRpEKJShGXEdX78a8fC
x8rlhn/iXSOfqSjh//pyMn50jal+AIK35kru8EBZQXGxFeKlFwiM5kNQ4TwlguSJ38ybGAsYd/Sm
egAf+0+/AZ0EttUWM+yqjlWOa7glirieuftPBsnXnQZL5F/6xFuZrPU3pBTqvGHrb54tuzngh4mb
H9Jt251y8ECOfgoqev9Wb2HNd6gpEMqj/hnD2f+avQzUZiXV1w2507vZlf0pn4aS+IdBR8ub1a+L
Qf9/FLsfFtBIrXvDVQwFZc4pdhMX59XJsDoKOko6DOUq84Nbd18pTQCUwvRtdepD5NNnCgVfTdr6
AwaOUqu6Vcy6xtntcYfBkjk6i+NymQqwwOtvdAd3YCBxHF5Obfn6L3FUsW81Gx0ryDV+LIx6v7Ks
UwPqUVU/gVxSWSBiMLO5bQ/WH9Cj+2Z2jI5W4MTusTbX1hVALICC+vyCthmgWlZw77hEp/sus7JR
1vnoQLrjDNH0AWj8sUzZ88gdo+zb0iRpgt7Cah0uwAFlGTJ3TZdPxNzyGVGW5yt99qI6D2zhOsIZ
I333ZGCzoSeh7dGNRPTedaUWM1mtLmSnXtCplz5+m3dDzpLj78dmjxqc0fmH7UharF1tt/vrAY6g
Ev8lTSFeQH4U6LmhSa8u1/c0PyLPjMfXYLnZGK75mo6lPRfYmbCG3TFNCPs6IIF6zhXJ11nAScb5
aED8I63UjJDDkmOfKFJ5ls5/WvXBQrqQRbH2JUgyzc6g1GubA6HKJcp1Mebvho9j4E1NMdUS18b9
cq7CeIBNhlx7FjNnJ9/8OkraM5sAsXkygoHvd0XP7im2pQfrLtE7KPwF9HHt7l5N5QWu9eBqTp0J
uNSrXOzG1mPfRiZwI5mdCMXuSCSzhaYa6+MpNz1aI5SbnyaWpotFdx49MAN7LTTI8MHXlDv4Pdti
kh+JI10p2Aa7aPSGiEBO3Eq8Mm5/gXztp9rn8A2uIkXI7xmts1LVXzhZ1U2MeBWCKJq1nq9joG7f
JAutiOFEruu=