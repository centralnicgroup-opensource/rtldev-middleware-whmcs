<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzBK7kcSEkFEMMUBoXvTHoBC5FzLJovjgF2onsRDiUnfkDNCoafrN1afmrbM0q2NBmq9uJaa
ARZCYIVDwVlHFqd4DVAbLHBEWmjiQOKYR0sehVU7joh9sc7QgMQsUwX/+Vb4oWZ6k6SbxP347xcE
2WUnEbP1edOrX+xFXWoWu+jCHoBL5nxy7DJlGDmXdpeSm9WqG5is2WylHQi9tOkKokCGavojr8oM
PB4ujB7kFlKCg/J450LyTGAUBsii8A1I86nB45jjQx9jvyVm+wy5jTiNvpPzQ5eA8NxIMff3+yCv
RI58UFyM0vqrypNdpaPWQMKbYkdKq6qShOh9RVsktCsb/ME2jf0Val7IJRWkX4PqyyCq4kaK8mXi
GrW7HjNHDZip4/SioRRNKJYZ9OSRThfmFJIYbldsDUAZ2Q1afP/UiVxH51Gdb28vh5sRhOXBoNJZ
KHYWgP+Sp4sLjOagIS+4qtnN2i2QfJq8koyLM8sZYxDV9yG8tRO9XxRrVv0iC5fdY/tqSdsjs/j7
ul3g+qlsP4ZcxeDfuny0tuVEsfkH3Kge8MVbhmdloOtx/dmp2GdLN92nuCLNw2FR4o/AvXl0t1oV
WJHhi90b1ibMXGK/KCENAHXXRunC2oIdsbfcINwPkNj7lHtgVohv47OfidR5gX8pBekau8CBjWQ/
53BL1tUT6BH/dLrphpHHd8b2z+p5JTog7eMjPAD/yejQbLb2zuDyTKQ49PwSgNYZLF/FoXJVNuYa
YpMK+BzSpSiXNK4dzHwWKM7yg2h0Qnhus46MwDlCDjdypOTQ5fG3HKP/yDIenIheRo9Mc1Mm1FXf
NHY/vJGQRSG3UBDmShb/0lE26Gzm/5tfa6vtD49r39N/ePOXsJzEuLyYmr1O6tdjp+xM+eUp7K4/
5aQBJLumfYeksbIPNEmGei1yyobM7Od2V33IXEroUOfrbZMvk9vgLpOJ1na3nTd0nwW/b8eF9CpT
yd0zTUEzPaiIEaGKI7DgkQVTzYZz5UUiTjIzYoH9ZiDCiSAKxiEV9WgCJu9BxQ4zZc7IsaDI798O
teb7AFMLlcqG5Hl0yiP/dN/wLXFAVYktPAioWSj0oi1WYgerKy9Rc2R3cYPovgq58a2YdWj6wFs+
zEKxey97NqIercrAdsuwnwUE/nriDQYdADzSKY3BU6uX75Fn9IM3JBj3Czt/ki6DTOGg8GkMQHQE
gp296n9TFz1d5tj9kM12ozqM76xraAlcmofAm04JgnIkLWmthhEJZo+N7NvtEBjGbGHhiKsnhkSC
ax42wNNlH3TlAJ5yXf9xCy3IH5vdg5IM5Eq4fiMUK//A6WzHs7JS8yxa6u5Cucsli/BTbT2Cq+Is
sigUZkLBy2LLcTo3jcCBhMn66yNKKk8mbOI6GRilq/zsfKHhnPNTw6z+DypVcmp8zzknFokDwB0G
LTIysJPld7aWkfAL6Ws9GLxGQwZDc+Wbzue8/lnAJ/Hkcb05gB8JvzcY//f1J3zggbf0Mm+RGy0+
tUkR9HGcLDB/Fn8WwwYs/44v/hR/ZcXwepqWj75isnAX7ZD0JMG8vmtB9yQKCtTMc0yFIVq6EhHu
rMvyryUfZwTi3eFRt5RuU6iDSh9HKj8qnoNAtmjbI/gn1kUA9vEe+Ga+PqOHeehkyYhzHh/omCQo
SNCzyd6BYT9wMCVafzq3xCSHOC4oYCTJ/q/S5RtocA79FTab9JwisW0D0d2+DNK27UIsCNhBy+Hs
0fWh4giMYlrxKLc1j0i0YCcSMW1TrziejoWiFraqxD+192g6cjM6u/OG8zTsYrIk7/LvCVgqwWaq
pNS8pUzdVDPkRIqmnDaTjSacG1XXttJy/fS7DmYWCRGgVrrsO8iPA10+dVoIsGXshV3/mX31Ld9m
X+/bvmImNfumArq/iKe5EoYxRPhYxow/ED2rpo9SE9w/Z5mkdboci0QC6cUSwL58NMlZyL08VRBr
dmJ27zTTRA5nIb/cH4ixRr6PIwAtC6U3Id5euwrsAc8q+CNTMGAn4SOVXvor2NHIV7QZPM8wHcWd
LxGlfwY/Bn6Q8WSNaDttAcZz1UQM9hW+rjeIKj3g2aO74yy6iMY6AGcjaisGQU+1ya4prRbqG891
40dTxrYJ0LX5EqQG6Lf9MylmX3qfo3swCeHLH8J/60yvJhi25AtXkLl5gpAw7tE5T8UQzUEMulxd
q3XM87500n3Uy8WAsX8oTkrQ9+GBn4ZjpbCoCzDaQx8+pqvX