<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwWDuVWfqDd/DJI+TDl90BbJ/+65nbB+5DHe9wlrIWJ1b3hZmXxzNqUIzU+hPVMCU9UxlzPG
NKqV8TtSLZwaRF0WT55wn6lKfoQkBe/6tI9zaB+R3Q9MWBo4iytZXrY55qaA6u8WyO0+CJYiqtXw
BjPwynux3ikdEtFklSQqPIwZXY+ZJw3fJCAK2NTjJd7B6nf0TxIa2u9zEER5VBJeCkD754w8in1C
LUtFhKaji3vL+PcUBioFEx/3t712X6REg9li43qQjjZ0OdU6td61TV8j4ohGR0vazD6JTd3wIJTD
mZm8Sl/f2WvbaICt0eVBXuDn7NmfXxQw1LvmudlGu7M9OM/9dsVOYx07sOlfs7XUQsjaYGjE1tjA
JyzbRUoJXhaFX7zd4GD/UJSkIV0le/WwvoCo1T/Ew3AwQwePQCMESAiNQp7MhRldUUYXk+GfBvNH
OIvqzVAxMlDVO5u3AF7+utVja02VmKNfrgq6BvVKV0QhSGrV9YLPcRLJsORNVK2vc9dPkSkO35J4
KM6avbln5y0eUcydHMEnrHynkZ+XgMOgvT7pUqdMdaH3QtaFkasUgsXsrqipYr43UIt2KtSPOo1Y
ZaH2S91QncrmNcXHgyVZWMHMpUnGZSTW0Jr7q0gppVj2QJBW5sOa10qMICHVFnRxlQjS+2BcQWda
wuBbGYex5KCj9wtmPerTIzS/mY4AQ914wLR6H85GaHgI2Qt2jPWXuZNSXTQfLwnBBIOBX9XIcX6x
GsIfpxwZxKMbvQ7BzyYNqSxgnGLoUipevO9T8PK2vuBGnhKhdYodOEffJM2xAbNWupZxN7dZOMwD
9nDDP02nXE7JzkbmpPNYL/qzrvBiFn0nfYtqmgpyLGSjo7nkwPH/MnUlCsqFwRZXmy6QxmKQyLvt
7Fw0Vke/Tk9/koIvqFrkuMNQhwwb1h1VmZ0ULqPa4LEIevRASTX4YwscZZh5EWP8i4zAS7ITTIfV
6u5uQlu613d/K8h6A3BbGVC1YTZEtP34U+dBoaIZj7wQXnjDw8gm2HWoZoxtltAxBUjpXdE6uXer
o3UoxYqPO3hVh88vlb9Vy13nrUr1nQsKxiWthQH9AvhVm78cLBj8wVSCqPohyrEbCQClrHUT2Hpw
PG9rtQtVtDfdmuR4faKjbEhrDQf8EynsI0ojnakYag6mdrXDWc41LnYoaj8D0zm5Z6wZbw5knvyZ
wx7n9sC4j19UlntdfNd6EQfM0V+yu+fV9Os9Kyk6ELRs8g3cgrS36ruw8N8rk1hWrZEFS8RVtqih
yne7CvWOx2hFMwxiepyTTXhJs99C5P5OJ5gHuy/N/pcWb7/CJV/7Ygl51nIwsHJwhGvL2iMlrA9o
jnr9BqN8ZumMLFqKyXl/90cv+FPCC0UpLZimYLFeJCZ1cPfQ61uog3fHTdtmn6fR8Jr4v+KxVEHH
CNpIhbhv95X21pMLKvrG5DQT+5nZVvPnxch3xGeaGbyI4c0dfYfJfqTblQvpIZ971AA2D4Ln/CxX
Bk1HXsqfNUKkxAy+hokZ+v0UysjBnRrfcSat710Wol1PCqzGuecgtw74OrwXaccXaX+iCQac2Iza
6LZ52ysiljFi+PeBqp6BolaAEzXpw2p/vqZMRbO+ICcY/g7BdJUViGM2YxmL+hQPeJwEOBRtjMzF
oXjQMmzgpmWPea8FCQs/EheT6AeKfi0RJIYLqxx+T6DZjl4JYrBAa1nP9LjiHd8n81U1ZXRRaC+r
ZFlJCalLPKTL22MeZC1alzHieREXqtQ4bn+khYtWgZO2P+qcOnoDeW0DylHDjZXEJSyWnZ3nyySA
TMIzzPzvUIwxMy9rZcEnVXIir991BYzVvxLm285I2btvFXl1xMyCPgX5f5iUcEP1MGLXhXFtYNTr
n9dO5JOZ3mEC60VufkBHAkgoPYLLfqOkcSqGZUE7ciBFMKB1J9//4nAYQZzvzJ7F2CKVrdV39pEP
g0ILNKmbnms35eEQHPi/nyTM1mFUo0e8jscUw5d/UwEVl0Xbg7GcVgpWSG+97hgz7+ywMeULAFrI
hMzoSoDth4yZnECT71z6EADfqDq+HUKi939mMrobej3mA0HP5J6MByMYJpLXWfwaxdE0tX9H282N
nAstLkEe5JVEoPRllk/ItcvTGkYcdgzFJZAZmnD5QnDddWAWjiyPgI9lWW/OJLCAXubow6RhUFPR
ktpRQSEcLkTIqtIgIyEC/oq=