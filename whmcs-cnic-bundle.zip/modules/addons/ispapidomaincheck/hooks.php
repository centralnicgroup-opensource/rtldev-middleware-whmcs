<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsj6Hl0RgRh7ulNJqtDsyFtvGyIf5Cl4Z8cunBEw5qj1kY71hMAg+eM3iP8N4Vm/nyMkqdx/
hojniXTUpd3DGY+lOcewTzgK865bA5RnU57PseoLGTURnxp28siUlrpN2SnzGz8pbhw0UU92iXzf
LK4CLJAfleUxwSVtIHcELBPl5UbaVP8zfY+FiSMZ8BxldXTvYVa8JHuBjhTvZoKBfHAUhw1oyZPo
+gxZz7dRCECqG+izyXIUCf/F2rDbcVzgn+oogu3L3W3OXwtmeEhzGSlm2JvndIrp7DvnUrKD7mO1
PYTO/vpOX8dva8/Ep66vBK0ZxD/d4Q1p9K9Xs+ggf9crfVSW0ca0hAsHYuLox9Db7r+TGHbFchw2
UIK5Ion2aOUZ5jj9Dm/HwLs8DnoNtseovlzW2CQpiWAN2K2TlOkLJBm8FY5xMlDwXTZE+wKg0zLg
lSd/cZ+6SvR3npR6DDJbJ+nSP41pyh2M0uItq8DBykNKsrIA5BcQoxM/QZQusqWt+A33/1KGCXd1
CSF3kL4o7lZcSnxHxmFjtpIy/ET1hXMrzjGbms1Sm0Ug4pLupJ4dmMj3ELcUXF3yuRxdlr1iKq4K
ucF5Z16dk7Ikizcp9FO4/MCMxnCFhmNt1D+3vF4D/tB/NDzDYtEW9NxMXLNoGUn1a48CPsbcZN+S
NIVgDAKu0sWZ3+xIew554BkkPBrZMvThz8q1Pd6t0A2O2pTcpdevoEkkSxdkeAm/1FFhAEHELac1
9VSP/1bEx0XCxuUdipxMhu2HYT1qpA50NIAcJaYXLVH4DjOeU0O3eZ631q6kPshrzjt7Gypl6eYG
zwmiZe8YnCVmm0OMMswa9DG/wawp0RIolI7Mi5lMjyc1wWMdTt0nw9C71HOzflsPenfAV5l87HHw
ZqY2/oqrUs05B76vJX9A9Pb0EWKPxYV85Vn9KV0VvTiC4Aj5lZucIX6/CgOItga9HX97kdn+rWo1
+asORAHtPhtU0ltiUHEx8icG9bI8EO7v96CBkPoXYt2pIzu3CTO50MXHMpcBUfwiSjuPBN4s1lMp
O3c8TQ3/vXDWthGM4MyY9KFF9U+lAegVpXmTldISg9p/GdDCHsl6/3k6FeAbnKblf0yEC+ndDISu
EtvNpj03FnZx9QRRhkm4yH6un4R2vIHvn7j9vBxCRcesC3zi8Kh9klMssDo22PcI+yLkORfZK8oF
IbeYCUIRSEAEgYCtetsvJytfy1F2O8yU+cpA3BX3LIsXBkHO4PN1nPU3JYv0vkTyAfvcEV8cRNGS
FRfK/36rh+ButCl7fwMmy5uMpe3LVXA5vokBoMCLMjUl6oCVYBjMMEBPwuJ/TJVEI55iw53DfsXG
NxYbqxPc05tQx/QsOI5KVVjHP0Xt8j0Ses86g4k9RN9V68nWqY9i1mzurVp7ojeEb/vj2MFOL+x0
4fxT0VisT+enI9sRus9p0lxHwVHewteFgroCzeHwddM1jPYbreg9wPJ3QSDhbphWUrfIgszT4B/A
LuAVb4PsQp4osZ3lLXLEBknFYdaWcTljerie2Ii0BZN4JBbBs9pVU77DpHSg11GOcuTxeP0Oi5D8
FdoB8fble2wh8E46iS0/lvTWZY4g8hsg9zr9AQNQRlkSiunTsKf33nUmov2XsInbnPCMzoi/pqyO
Hch+QF9/P4H6JKwY0Z1C/9TulyWG/hxloczorUTOKRHH96dctEb+CHvESA9/sgM51Aaz7KReiytA
JvV3JPZK4Nc6Rv7Sh1/JcSMK2cL7KHnpAHxH+cbRls+kzU5otefjPnex4jeThW5t8/8c9VOF+qxx
O3NKd9ggthFi3oZGk3bJ11Gpr5vZR3j3J8ndYgP+d74XN8XXZUXu2mDgz7LnnLg1JzbYDk9Pfu/H
vYS9ZirQ1QyohFobck0QLcLj2vI8WDmzU3/AR+1VLDJ6lF+ZCMEASRnf+tnrgl/Nqm3rjfVaLVwj
zhRwNzPWQQ81NMeFj9KCj5w33PgMzPYC9r+TB3/4uCp0hW9rDvL2xv8HxAxvVpxCkpH68KjsohHL
t86jVmFz2MIBoGP79TZxguuzK3Ta/U2aA9GtEyO1deGwBqtQGrQEKB0upynEuxvOTQs/UvyOV3jm
98c6c2t0X53Plrch+DPbchWzMCN9yBSxWBUefThnVVK996O5rWsimcPM5h0rxT6BRyOiuO+kyPKu
g3C1cvCmEncEJXDyOG27qtjoI9AJuWcLlviQLPrq+tmOeYxO6CO=