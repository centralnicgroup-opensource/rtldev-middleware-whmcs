<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxmpcIbU4c8E9u0C2iuNUvyTNze6nIBrSTEZJwhYuFKSQTtKVMbiC55qnr4HBH8COhzlIkFk
Cz2QVH2Gw+S1c0rvpfCno6Ywe2yLJSJ1kdo0tovUhzoEhohbZ9VLePUPjD+3E21JvqbzGwyqdE/U
zrV8e9RmOmTwEDmAjOTbkDXs5p1d9Rq4bkvkJuo9g9ru0qnQS6omdoriUA+S9a9XkJ2g7UyKe7jd
pYExMLmmixEocEBWGFLfEkKqXUxWcBiKaiDfeOpIR0DWzI2v+PfX+UHitzyXQpLmDh/Cm3k8rPrC
TvZ8QdbItnETR4dslI1uUWJwcXJstmw1eZL8Gp+2PYj4tqFLJHRAd4iIx8GcOfhqUEqXOW2odVzd
nacEJ9NOTe1xC82YLmHqCfa3WU8d3jUCPakI2Er1wbDUeJqDl8Ux7yUDZo6z5qkI4q9huHmMD09P
ks13Tn9yWbAod4nJYiaFXGfx2CnQo+aFzYhM0hxI8umnf97tim/8VLNoAIaNkcCYdrEPDo7+tO0+
pgCoc037rVD3TAsu/Ero9Xc90V9KjxIHkAz2JPKU5lg84QtDmU0aGSfkKjuLD9pC3a0xPErn1s+C
uEddvvf/R/Z13EZNUTXubxKPX79z8H6/kge6eJIUai9TyC4+NJ06lh08bax4BMlk3VNyJC0/+288
D1/Qs7YgEyk+Ze2dCXx9Dme4Taz40kGAmPoaAXFd1gL44rl2Z0xtv8Cvln2O/GgShSy7c9FUSACR
PeGwrmYZdSsRiG3zCvt3l9x8DdBA1+OGg6robLmChO1TvrTRnwgSuDk4fjtMrE9Xu4pSIyNOpxUV
7Sx9t5vtJZg2g7gOmmVyZY4klzVQJhIvaYnsnEJnQEoTFh+xvGSXM7Q1rjPzVtAJawDFQ9FxS18D
VZPJ1ja9xgnQcJAqZ4qhGPwLy9AMXdSk5R2GRRdPwFeoRWy4+E0SfDNKWLVCG1WhvF/YZ/rDGDuW
DaVmVDAo+RqZsiNIkXV/nX49ZIi7OKheVe1OngXex6UxSl+4jCNNJDnvMCd+VjR94qZRiFA4KroF
zlMN4NhA0bKh7rIS7rYiX3copNL4t807+PJgzr0xj9UtQqs/u/sKcIofemM2/elsQqMuWsDuNdaw
hzHtu4aTTX3Xna+w2Bv5HEtPii7HtaBkW6q5NzfP3//Qb7nfnfdOgrJUJ9Uf4BMbYR6m1BQmo5KK
b2hNl14IfwBoyanUEVztRgxUYbK94H/P21dL+SHPgytjPnZk0quY6HyeLqwKD5gvxmif498SefAl
LI1IDqdGgswY9GazOq3E9CsPt5S86MXKa9k1xwcfjk/0cF5bkDQRS/7m4FBfz11sj4Yhqax0nUp5
+CY/AINUG0yt4E0ppqn6aF4E0y4qlw75euR4e9mQ9HHx9Qc+bX79oAeeoGL9Q/heynP1dzOVdnM/
EO0IMjj48LImpBYB+L5giQvNWsUyKMvwewXgrnazbTqjryXn9XJiDbacNmfyf5nW7Uya0TRAzj4x
tmmAog3z9+EIOM/uxpcsmrsuGwxOyf9Qr131njswomtbCXlr9mrJWBM4EpA8DA2EIDyqfQitC1ZJ
iOIPT1+GVCWMlR7DY4CjXRCiSwqwQy9yAuN13Pl/5WHZ+UTMAV6GoQrr7Xg3fS20s1FQ5CawW/5A
NP1qNmmBQNHaLEV2fhPVW8O6/pxtedxSWT1QtlFX7vYqNdCu/8d/h0SYrUZpCkliMEllajITnnnC
Mf5vJIA8xmxGtlQ0D0WQXszy6TB22Gb8/+7/Hu7mj2D6TC6pB8xpP8JG/Nb9hdp6FpM6yPLQktcN
i7UBNBQcY5q99fBGgIfe08i/oyBeiSE7hOXuCvFG20NjYqGCJyHhU4iJei/FS1ZY3aIqZYKJ74gH
J00Kk/RUDOLuoSX8stzQXZzCCpekX1aG0owNpOzPCGrLQwL6qbUDrWQyD81ILfofcZenU/Rz5F9T
jNLretVN4T0LExrTqVkzIq2YTazXagfMMqvI2odKeG22/gZE4uy2GCnlSt5GALgAc3T1wZel7Xvi
/c1S8tI8o2gotVTPGXo51rna+qVb5hACb6TkvgJlwxdbG6stoHwd00zMh32i+AZGNWscoDyVCogB
43cTRdKutLzxrp7uzMTHLKxyC9YISn8TtWe/Rnun0HDl0JOiEEZqApYSxKMF5aqWREvl8gs5FU6m
X45ybaaDs54g6DNOf+tIleZDX20=