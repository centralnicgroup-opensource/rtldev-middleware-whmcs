<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoMZrAsaWYs2iH11ZfR4qWLQY7Cl+wmFmf2u1BH9nHaZp6a4iqJYV0Kd2eNXeCzKW5uOwNcU
LxGAQQr8jiPcD+vk0fAwdYyLSVrqeOfjdU7m0ebR+FWk0K5AIuhauSXxQk4Fjqrr50KCSUg5G+xT
cjVgewg3Mey7e/jAm4TW1/KEtbncndFkOvYydls1/PaRTV7iSjJGeGRArJDQSMfhD3De/F5YKItd
4OlPBT1D2tpBFgAZOT1mw4hipQJTN7oLsB8P43QPeGRaHq3h8KcuIEYSSXnhNpd0feEPb1/TXKZ1
n2SuUxtMywSsgROmFcq36qRfUzR5Xt0clu5qvzfrFTORpVk4bXGnaRTwmb80AEhsuuQ81d/XtX04
g2Oa0JGPg40FX2rRcPippijFY7hjEaiTzH0iFZLNqy1Uh8T9Hk851WvlWlBT8fm+A9iXwWrWTqeX
ApGpJuss/uVqd1DqcvZ/NeFwVhPA0ZzibQbaAnUkAnLALQ+zf1QrqKRiFXUF+ZyrA7T98+zNly+O
YbdS9gwA+VGPod2NbeKAvhxu7IFb33HLBwqmeQ1yHyNiNfLn2kTe0w3tIUMVuUUcNp5ldD+PTC4e
gBTFjU/gbXoHNZiKVy8Jdb9Qzb4+v+XCQVyQDqWShsnpOM1Di5uvdodhBZZN1/Z36+PGbnELBcDg
bhhN//2wPSx7Rb1Mcq4W6/PXRPOBO36sL0PQX7FTTTjk7cd0c7qp4ANbLMfy8ETieu0LFW7AdXA0
joEnCx6eu6H3drofprsyPAtkGPdvpITorlToCGKXQLnAaZZCZzGSC/JxshDMi0GUpbWWVkSEIqKP
ZlK2SE54tek6gClo3dnKqzAzVI2FXB335K3UdhvDIVykdzlp9yN6P62E3Tu5OR3Q/IxIrTli0oR4
41rfq8axTKwn4fTKOVtRlQKZ/QVFCraiD6PeEbx4J8ntHytZr2y3f9w8WAejYcSJNPKZuRZko4Kf
1nAl3sLjkdlrSJ1iredzJz7uUW2TjQBt65YeUd9zbiJlPd0qOM8dWMoKH/pZk+vZbuRxxiMoWAUQ
/ycHymcd8vBRrtQ0SbKVaX6SqZT4L1utqF3V2pIdL/nITCIdWZu+fIDlW1xibLoj34MkyZvCCKcS
syx6GWsJSQXoM3iqemq+FyteQDjRmc5afn5SmJivWGw3sfrjP2elqxcr+6pnUnmxuCWnqNRfAYcV
JuAkB2HBBeH+bjVJT37l2gCEdzDErNcQ+Ecg/4swMZHDTsRmWucuatpThoLDeXmgzsb2goFaBZJU
TU29tdKcagp2Jx0lIki4dt3py1r+d3JJUdXHcxgyWEes/LcSJueJBfaMXAOP5EePmR34eDVr3/3J
7xeH8ARIvKv1cVWMwBxIVQD+9hz7XMHvx8/tfFLT60C6/kSoV0WAH7VcrIuag+VWD1zFqfUdTCCt
KIiFAHcmaTLiX2acz2iLrHAnUSfmfl2Vigz68FyjHlh5UxkNeyaYXzqwuU3kxxoV8gs66tbAmafn
YrJW4s70q8cbN74cUBlisC7YBa03Rx1VdbnQ2iqDUInygL5F0/wR8Lp+wWfaIdnzXXqv3QcJh1wi
Dva++Qim6GLcIDmgUgU711PWLvfsjYMYx6kyZEwy8+AObYP7c98b5vqss579sL2UW1N6pSkUhxk9
g4aDjdhdlR+CCFzRcqUUxnoM/be1wd7/HofHigbtDOuNxZMpILtrPD1MkVsrRbP+1shy/deTvJBG
EPMkcTRfjR3O5pd5VxyW8Mkp45KcBIl4CxbizCN2IjkLC1xHn7Ibk6YFtxDyvo+3lgDveTTwuA3b
TYJEh5b4coobEDpuvPYugTUyL6+Laj7UGJGwg4HCkNq5JpeWgQTpRFCtenA+YbkdHGqn5VB9yXTH
phFzai/W4Wsa6dzZYhgMs/+ybkDtlvO57ec8LC4kUvMzP4rbjpXlecUCxxxNTOzYQwDH4aZQMC8R
+qD4hhneCkf/1Wcb+nvlUw/oH8+nmaWqsaPxtLVlUZrqC1IqCAVbCKCoNAe7TKmQ2m9XK8fKl78U
jATpuO0M0uU+sv7GhbQ7/Ka0TxiNKYZaNlFOBVpB39Oz82yfC0BJAajlKktOn0pa7kEmJPyMerBJ
XLkaLzW+HOH6vFR8DkdhQWEBitkmhrvQrnt6R6iZQtAmD8hklDhCT9oiH+zPTOYLR2F4fa9umTzT
FHemJW3QO7IGJMJ/mTG54lTN85cxdT1SRG==