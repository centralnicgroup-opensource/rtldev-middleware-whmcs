<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/YfvOz4TDwW4Hfmh5WNrG2Q1FeaNqpmWfguDyRFgHg4lBF27Hu191963eH8N1wwVGD3wJ5R
BvmrRm3tNR6TigUspAtjMmM5pmV8Vo3VVb6VVbKB+OSsf7pLRNDZhauV+gcTmoDj4PUf+wlYC4D1
j+rBHADyNH+kwXKZnfMDV57erL/A1DuKhXNXy0FT5OwBShazvm9RHCJFP/qs4aq6X+ECBIEFPVOr
lBUpl5t5361AwfAnUgZSX7vxJnw75//WwUf8u08rschs7159idl4hwtDlmzepfZ+/ssk20nVoDVN
MSS2/paImswv3Jexhi5nERs0gWox84nzwxXWvMVUPU0ZWiQDOxgSLd/PvPa+IiXLssJy5zLdConc
a67Y+2sokCBbKnvB2aG9GfWpP+0mt/FQyHRYZy9NKybEZV2LjORkiwkVQUk/x2vD76T40hwUnWgw
KOs/V4e8EnAwkgQNUrlLrFZCPL6aB3c+R58GBsFI0HLo5qyMcno3JDah5btfksLGND1bqU4RYLlc
KdrOfoHds+Y/0/aJUbbr3fTgjJ9ZAylidc6FeaG4QjdMZj6QJOkQfh0LFsvp+KB0kemnVeCnvv2Z
Nrub0FfEkAxfYnuz1BgsATJD+F1PKNs4gmUdMnsFh7yT6pRmv37fG6TuLmrZFtcqujTjgLZl65DS
Pa1LsmcVSpZX6fXyLypCEUr00xpXOXaRiHyC698w1A+0eoJ7T+pS/nhGbkSEOGtFkCAlWnzNpEiN
cDI0XJNnblS4/CXRx67IwQ2MNbmFv4mZxPn9xYeAIQ5KgZZ5/XVCcrfKatLKVCJ7xtZW59zZXwOj
GoIg2F4539MCm+3eDPPKvHMpfpTpjw6j7Xn068fLaV7z3yqiQAk2guV3X1mjaB0jxVTrlvRnq+vh
0mHVHygUypfDLiGDjowPwvhvAiMsJKZyQCzHRS4MXLnM+hoR0/ckUUc0xgoFDTDAguV972UUDJ7i
igPscxD8NVz+aFP73/fjahfhI08aKALM+M5uUr+jcyBJeMqXu9mdQgRAsR4u/jLAox7PYkKY+Cd1
L6zvL8ddsycItKlPl1fU6TB07znoKGmBuXVL4DvHIrodcjaMqqizjtGgd5ko2qh0QLjaaHmTnfrB
wIbzo7s9NY+rm2Pu80EBxigO1LxhSGHqDuJa+U2E1lfyXu5XNBZSotKhMR8UgjXHnI6T6do+asdX
Gri/iPTmM9Bzm1s2yDRKMns34wyFAEmt3+2c/ehQ9VfP452moOJBWhp4Wq/XRjQlqEqB6hgmelLT
+LAZb85EVQ4S7XP6i1P7gn5NkiGY79EtlXTxJdoEbX9zkabHG8696Uqchj8PBPYzJ3qpfwOCCx/9
orIHU3TQIN9m/liHuSsAL7g7ijJwQ9BUWN9AJNS00SLpd7ZGrisX9eejSn2Hqmc+W+83MuWBvx8Y
8wNQ+WrO+ip18/4/gcyKVMoJfUgLisI0bw5oZgGK+LQaAfZ08YgxTrixhoLPnZaYE9W/SvxFoSon
AvVl6o8nkSBDqnXdavoGZ2tnY2O3KgGF+GDhjXUemJSwz3UUQFHZlP9XCxv8StOeeoSDDBZRaZCa
bNi61oJiUQXMIdaI8nqFVZU1nfP5YvRQ/oEb3DYZ98tjgcnPSV9wAmEDSJXcevBCi88E+7J3qj8N
HJszWh2zrtzt8oh/k9QcfrVbiXcp3JJ13VTKm/BswlYOBx6xgZu3OuO0LF+FLTMcuWqp6HKVTRwc
ojdkAyeWfcRxokEKIwUwYsQeXnAiSehZIQqKwL7rXj0IllOo3P/rpngeuQNq1uFqB0FfNWO+18Wp
AIW34RhhCpdyIBDk9J91LZLNXX+X7AU1OdTzXr6KQXmc9oiS/PW22gVKGt6wjRwrNmi2klAHBcHx
EERW20IprmI59MG3eQDBKfRKCgfzikQItIujyvDgtS2PuI/WEVBaGdqiKKggr/7DnooxcSshYdYr
4/xzLcTnyzYQeJYjPdndVp9pit8sQVPOrgLI5cMYXrber4vEeNF+08DmhtxzLuFS+nBw5dndv2V7
oV++y0fZePliVG1KPDrx/lIq8ch/ZXEE5z7WwQVqJp9fHCk7xCJlZL2gwWyFiSM7wZ92+YaXezwq
rOyWhUPKmjIj2DsxXpPtb/q7Tvr87b00NN8v/2uKUbM6xwbAAuY7ByYQdz/amG25yiWrrAp9VQJx
YRofp/8p