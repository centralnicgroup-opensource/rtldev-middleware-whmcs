<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxFI4GOWFUefFM649NcVV4dr58EgQeBElF4D/vTOT95tmsIFylsGDybwlGkqhbGWCSS65N/8
7qRi4jj9lZCkTM+Rs0HxEEX/CCqmT24Brp8wpPQlcNceDjkHxLIOkGJEQIDsrwQwM4JyWbrNfPJ4
gmGfLlC+69fJba4I7dQr/oPgwNzWf03YH5mih/X/IXXCdb2u4zBSbiDieGWH9+sH+O6DGcghBwY8
XJ32ZTAZxgwGlwOqKrw2u+yaEWVXyHilrC7eBhkgqkylOZxrd786ZNSFIvTZ7MWXiIa1WR831+Nj
T051HmWORha7dUa9/wI/4xkIURegYp4G6YQuvA/WY3yvKaO8t39NtWcLP5YBSE6DymMz4j686zQO
CoZ5Pq3B2oeahxbRhBrdovZXia7rOn99kePHcFjCJKfk8N7SBBTO2b1V1deV2FYXaV4fD+V3ehxx
PKIPs6afU8k0McIS54W1imPASNUd+mEbAtO5QHcB9lE7rhm7brMEICJ8ELGB99w9yoyMix3ikgyF
FQCPyeXseyOELva/lvFGguyK8rADHaSpPwxTu7wRddwwFj0AYcSOnNevJKruv0QWwNbFT+GYRcC3
bQ8x3ZBB9FwVkZhahZqHkB7LSmX/iflK49QYKb1C3NvTpQwVLjZ2CF3R8oBc8cRFNPCAlsCj22H3
mpFy2N+3jcfHH1O5PO+13jWqokjDZFhwPKvKMslBZWhvR2raaicIfu5UNTcM+jKUpCKHGZjRgeie
l0w9JI2YX9Vb+mw9X7cL6r0sG5qmWLFl8F8n8TM/l7Xf+gc2FYbpR5c0FUR9KdHmZpadCuDFq8C3
5Kw7DaAXR0pkR6VvggpSWJX9yPg5Y6oJPXp/EjtBqLQ7Yeoc2u8nRDA66xUtfuuWIrIY7MOnkC16
0hGSvZEBQWer59WWfV7zFdz/dH4bRzoUUy3x0DMN8knI4AeNRP6VE8cZSG/wqJ1/nd9PstoRMz3t
LhIH6m4K64601BiSQfJ+1YTmNB7O7DKGQ+ifgEFqpNGj0uAKMsGJ8uHImWBGxOXItMcznvDiymHs
lKywhyIrDas0tw4U5ot+1AHH0wm2snjlO/hXkkxN+lC2w+6ctJrTi3vGBBE+CDqASnbaIgIiwE8D
X9+5AD3u3uK+BuCo1ynFrkpdOPLTbt6m6Aum8FZvoXc9a2z4R+vZMX6dy6rfAOcZn9bZZcj2gnKl
m0KVpAnnf+AS2okYVIXs/RjWrZJWVAa4yOcoS5PTXWmrKovrHgBq8GpOolVvP9xiN7UxMo8OiOX/
DCn4A+LRpyPqcuSwhcS1ZdoTtkZApSFFainG2eQ6BrERD36DEw8kAGiL62LvTY/0XuLNtbctkuwt
Qrx/GAI9DRswcdfsCNuWkXsYKvUMaoEhZiJI9m295wJlI0jZMfbAIM2l6Ul0IJEye4vxjbfzv35u
4iJwNRPtZHsasbz5DosSasBHJvzVrsfHCX8zSM5z03+/hm1Hve4vy32nO6JLYL7t8FHY+8jYSOwb
LBLhW8r50+GvFzWaXY8TvWO/igrUVUF2SfROJyuFREWScr11O+twd7u0kyrw3c26PRjd9YxR1rTn
lX1RawxYq86Z083ocNh9mjcYQeQS1DFzK85Ls0rRY+p+YuDDFhuEn0ZmAtmk28EPrTQVgcRlTl8x
YC5GyyMLUawKu6Cgh0/+Yn+PtcLADxV8528RYTN295/z+QYK+oYrgR3CfyGD2VbKGezaQ+axqvcc
sew8zUPqZmbvS0pykZYMK2AAewC9+ZQfa8o9zhNNpF55pcLcHZx+VM5yJHoxgycO1HOS6hgspy1S
LetSWk4EgL2kFbiefeHv0v+r//QKskFN7blFslmPq+sGxCmDH/Y+derdLl8VTHDKs52RiQpxl+PZ
VYDWoSP+7C0PJW1kFtORNOOPLJ2euFuE1gR8ao3mfsMQ4VEDnJ+BjIM6vird5+2ar1eP/LrurVOO
RPcDr99HbNrda58RH/SNLAtvg6QWzcxEn+Goe/mYR88uowHGLwxaSvP979Rl/Qw3OWj1C6eD/w41
A489UCeOa3RtfL8cRo1bRj0G2R/FrR6GUuyLyrqtXW8IySf2Cgo5ip9EyruDzyQJbm3hGYOHt/8g
3gBRYgKY1DAdKmni5T4dBqAS8GGI2u2C0sGnSImRc6YNobb1MYhtOLylVZhhtiN2J/uMMQjTPrOf
HRMXWOo/kYxvg2F4mFrlmh+jrQ88JwL1DSmjbZyUg4bVmu0XmxYRnIpJ