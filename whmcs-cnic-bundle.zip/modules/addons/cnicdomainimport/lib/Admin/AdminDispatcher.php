<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx0pg1Oc4X5PFu0zDUACplpRQYwiZRD3LgAuDIwtz+GpkmjqEqz69cq970HMOE5ldgO3rAf7
O8lVrXgpDS+g9FUz1FbGEWuo5y+dg4pPhMu4iD6QgEIp7RSYUfUDGhwLBJBsYf35+1WpGrPYycPc
AB4RrG8luQNvlkTUL61u8Q6HlVOjTwQPfH677K/ThYmAAqn0jIQs5trcebMvutKZEOvuNrxKpNET
QZV/xrNhzRsv0tI9dIm6Ar6syyrl1CE22JLTnj+7fmxavcCZy2lxBYlnlgTbESUvOfgttn8J6e+2
tsOwz9zQbQZX3009qLMmDYxRdvmKQRH1FXob3V3VDOKOVRWxRtxuvFaEeuN+3nPmIqVjVNDNVA9s
XcS/yCCnLaqGOoviPAe8NYam70W6rtVoJaR451ZwAY1Qbwvcofji2HAxJSKawyka8CJneKEa/8/H
zsHiibJuslWRc4ouHMS5QNBV6+b6IESMCy2MCqfxFbPwwBL4pX5Iq1V1u8rAtvLZU2L6fy6cdyj+
wcI+SQS/Lwf/tY8Pv8LBk+ya3DQxd78/BgjbJlRQJt9mlLfVgAigjvYYjuLCxrksyPAzh3qhwDeK
VbyeoJMb+vfLIYWOtYewxWi9AJkQRKOADgmN3bLryG1pnMDsAX0xPGMBELfjyhu8AiJthV5Cl4HZ
6ITVfmIebEDCpPvC+gxV+0AZU3B0QwoJeAhnn2XLr7IimkXlR1yt2yuLgLjYNdRBzJMXQLPQUquc
DSXk+1dm2/Afk/KW1+8Cbap7fGYXzWimJaJ5QoiY5u3pn0aaklPbeuC4JeYiFhligfntcfREOQN5
yBv8sBVAxI1s9dL+6+0M7TlexWigSX17nybF+JUC0GKgo2Pzx2tmKMR6qOvnTSItuaEwU6GV9CrI
IouEYrR56RvkBGHePbH8N0gyrVp3xYfKj0d0cru3GpSro4M1ZVFXiZOEwN/xa1Gt5KwTPEqUEBd4
MTQYflcO/pi7EF+7yQjxCoMkXrg187BgMGLyMTxhJUTbVYNMpuWv1jaToDPBhcYUOWT1wkm57MVO
Sjd8rCILKBPSeYFCPJ0n2cKFwnj9ryX3GYOD36XCKaemMFn36mYqJR1znxs3BLVlb4AIQQIwPE09
CpZSWLftobiGosyxLTwxoca0cFswtblc9K7HpPAJAPOqk7MI9xWIvzaGMhfV89R8UPjRb9OlxdAz
2acqwbEi1ylh+WOxFv/skYSeeZaFS+JHU0m3QK6lYOATbwqzZYjGEnd1sgYJbV/+S1jgzBFKPCGX
0oAtg/a23s3vxkEVt11n1YjMO81YqCzf0LNQO8YxEOicx5mjrxfXENKaucJhntiOsOyjXEg+Thqt
qDyPL1E8mNLypdBInakXdHzeFm3jn3vMqDr68LDx3I8ly/0ISEzL1e4GAOF/CwkqRUCztz79+QK3
mYkUQ0a4cnXHhnkpdWzMpqv3L5+73edc8xKC9T1WnbBS5NbMaBO1VajNoXVxCY/kzBlQtpxAnlRT
BHOdLQMJ+F+mN4EHn2O5y1J6auXGaWCnivr1EHAXBcwbNErw/La/mg6PvOHskfSEAbBWE3JAP3F1
G+Bxxed53q6MLwAAISNRQbkuSI0WlFVojaRVZJljSoOhuaWuMba5j6IDv6xxgoceaSjbvWiZPGU+
NEp41YH3NJ7DLVlupFlj02lGK736r2XnlRHf1js/raMrC3QCWSffB7pd0kaCShCLXK7uqSXCrVVa
16KZP1szcHXhz2qHPjIgjGS/5ZZx2Xm0E1uDYQja0FEIHCX30tFQ0+lEEDTREopoNjNI5tT4mPPs
376XZCt7n2qUA6oUr80fmAIfGUzNVqFbKvS6+7qVZ+4Ywq8Vrci18NMV4p01/DNsUdwmUErokkl7
v6vCsFrNPCohx45YHeaRPLFfN+nQL7O1Bk45pek4Q6i1lzBPUatb7UFdjNnGXuV4bm3hlfpWcui+
MouD0K7k5yg0mTK5vCpwLXo6K77WA6/HhH1vWUFrqIqtH5RkeCI9w/AoNEBxWuQWHmo1o6wT2xIN
1sgc6m27y3Y4TiImWFcaqnfUGVLOJ6LSheXzMsZYcefjrdNTgS+p/nUUiAZ56wp/KlJyPUF9uPYL
0NKcprG02Ne8NkH9guqnC5DQmUDBefS8/vmZWE7NlxWnjShO+IgKBIANTCL06DthvsTl0+dmk0in
dSHu2wXkRGqR2GfDcVxZZTiSnzehygG1Y8pkiUVBbyC=