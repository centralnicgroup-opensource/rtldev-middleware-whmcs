<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnHF9RVebfsuzVomb4/EjT9Fk3K+ov4cLOEugKDXVpDVL1y3EMTPBKCMiwMEbrgAfdodSW3s
o2BI9PdkEyW48cJDdKjDsuDXajKxrnQmgX3iBIo3BNXne5KDaJKmzBQQJKuBuRyo+VB9HFH+JSVy
UD4EHfOhEE1HU/JV//v7yW3LLphu038UhUdhSt+KU2qucuADLVKViLNlvx7KJUho6wtxd4vcRG3L
P9MwkSRsnVGDLIW1Ys2OHcBrQLAQvvEjiHzIKFHTFJwo43LofB0Qo/2MmoXhPKnQ5eyKW1UWV8Cz
bCPH/vU+ltGCWYVvJhXmVLgysNS1NSgSN0uX8mR/PO8EkG4i3SoBNMmPZarbqyIdMnG0MaCIH9te
VuyFXRHI8L5ih8EWEpNZFiZQ9rBRXHYc+WFO4iQb8ubgv/tvucRmADVPeQv5WPl0ctZBH/TNEea1
Rv0NuU0ExB4Dxbd7fTwx+s7WJ+G9RYS0CL5G1XAoGd6D2IVTJkT/k5NKM8on3eqXD6pkbD+mhWtv
RxSsnSXcJYGSDrZOao9eRiK9Emny3b7OciRSnVZifm9dII19tHdypHOCmcEIrhPJ1KR13/sJKDKD
gPcrm7IEou0z6wsqMrijV5oDIzEwcevi0SjjpwI1gn8p3Sv6tF1qsfI8H/biXY3BSwKXgiFSvp3l
MwUhbGWcfl2oII/BDZPPZTmoWIVaBr4X4P7MaYTwo/01xWhNHL6JMoaGzuC/2IpJcyE7lsbblq3k
rnWIpIuwBdmYyDnFIPzF/pwZHiz+yuTdryqvJIt0UEBOFp5nUTKqilnH9PMioZAh2+7iikunFhbb
Do9l8rqFM/0haHvG4sl4uOiG7hFmQxDt9Q1YYNDKf256MXKL0WKmwW/ZUCk7dRES+Chz9t9yKSQu
rL0EhBif5sMJqkgX82iWHbDnqS3ULxZeyculVYguetq2UybkFne2bd4OJJri/7F629JR/OqT6vXP
JQkav09xIVzh+lJyCFdyWktaI1dgDqSQUaXJIDoZV42NwxECHhTnjg+g9iJkCdC0JIj4dVm4uFT+
tzUfESoJ/8QTq1ChRIqgrLXUiTtDnTgIDrPpKBoXTCty33e1wY3oNlAO7dwWcANNqJRxRRiLWd1D
2ew8lpvjBl2xOyxDrmGgn8iAXo3nlMYpQzUT8nYgOZ/bXmXuMIml36Wbulj1k96YkH7Cxj8KDeB0
MAaWuQgOXNoRM0dqrNIR27sRffH6cjofXIq8N11mf9PkjSANS96GpEIeMc586EjxYfNp3jdtrPp2
4rJ+PlHflu7XmFfv1YqYDrShB+E7iFBshOXRjaIQbw4xTaDRFm+oHIsc+zoLfMECvlrw60YMP0tX
hWf+RjKlGYLREy+GlE5QtXUTj8HovO5zrf78les9xLZu3wwJILpwgjBF6PlK4x/gLcUhxwzuMAIG
ZPXrfG+k1IIDqDh9u/eoF/ICKnLjGO/J/Rhjn+m7O2nc7J5tvdAyM/IFky0xlMg45OLY289KMDkb
b2SOfkbpTV+CegePUVnsIA+pBbnMr+uQr7rx++iY6dzAi1DmxeEit8nN8i4UBL8I/mFlzunG8+Hl
ncxX15dMOXWL603E4ivba5PeVrQRITp1nLLLUST+2Lcc0PrrZJl8zuRhlK1QK/K58whr2YwS2dMa
tV+4dlK3sx5euYl/mUa7KOnWylHgO4D9FOnkon9rRzR2MYenXZ5PBBQS/OzekCRc2C0PvWjV/9rs
v7uik0WwWCV49FmU40g6vJgvqd+vZbJUsXr0w5Ks84WPzXA6zYAViQ7CRRrS5ctBA7OGDwDfkDeW
PWyfwHh2aR+sgWZLt6yd88XhNCjSPDuzzkL+2TvKVWTWl5lhBCO3iRMVeeKls+tFdQaSWvE7NYbl
ALHWRl5VKY7hNsS5sAK26lk7PVp2rJchBOT80n8UXgmjZaOOmlxi0htRilxF9JLcSRpGPSabkQLX
RHdrMzsZ9POZaalwPBV143KTLoceNuGia3HTJZ/unRpL/5b1xCdcELVGAM82DuiiDehA5YHbC9kL
jj7cZyu9uaE/Ir5AaesXvBCtdINO37CZO/Uq/nbRC4AWnDyLoM2zbxOrZmbjenngxchQFXk70mfm
YDap9UTIOwGiwmegiaoPsXGmaj2Eu3ZQJckFeOWbLuMBECH1cq9JgmNXRrDOMNflJRamboacNz/B
PEzBzX59Qrwpl0p8f6m=