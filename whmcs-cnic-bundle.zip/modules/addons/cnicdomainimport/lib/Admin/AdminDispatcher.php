<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs1Nfl7glXh6y+GpqbQQxAcRPphvD/4QJREuKMczFh9xqOnIAQqTon3rTeS/aX8Ec3rojL7f
Wa+3fIcOvV4oyNfKyfl+WbO9zW+7dO+PTWWeqpO9tZZSbXK+aYY3OHl/tsChnuEsTemOuOZPx/pi
Iihyto2yWJFYSkpCO8LNcaIeB7QtXJDCQoL2SIrYh4oSIrcw+5isoQxzLC57vnOJIL9XD7p1W9pn
7x9dxqJiYuQo2akMOBkyoeBA41B6AowuZQW44LZ16OUBPrHyK4fycPXPjt1gj3Kgpo2NUfuiVNjz
HKPY/t20nFNQHGxenysHTv+YDsi4y9OJlr8j09WWZzLkZA165nBH+oSB1RNI/SWNZcCVhdnu+CNy
uI0qspwbiC1n74D8Ig6YUfeefiM7KI2646tEHvFkrcuDrVZ5YVZuy2DlBrzBDVor/ycr/r4gkAGe
fLksI9ish/4VX0IztxqTgGIhWGnIuBEwROFT6N4Lctu3ukpmxZl8jtvzsBN94a+CaaY1orZpuNCO
Jbp/oXROomK5E110I9y2HzOZ4vOF+kubrLfQW2YdvBq8E5AcoMIzdu566kU3pjTEXrB+ji5ZF+nh
DJdWf8Y5eRcnM2NhBwqNR01Y3QZl0BHrzBJj9k9WKJsrA4cwO78UJf70Dvio8ryPmw0CDEpyYcxw
n44c9DtofEK8g3srmTYQCqhtplsh8dyheDSv09FS5Y0QSSx9rrGu/qpZyASjNnDrAoCNb4xQ0kyo
YNHXt4jwQWejn4/weDPpbBS/x+lIKd+IIGRL8dnXeEo8Kj2UHuHZp/ejJwNEsK118FEnoghcawOM
/gHUn8jietJOmTBqsgNWulYxmShsgSDm0Ld68uet9UrQt+CovGbhxVjJ+vtL6KbolEuhKY4pZgjl
uPDzvLecpq1KnfXrP0t92pjHKZBacrgDgdqGBUgYXSFXSYWJe0Rr7DzNKg7whaYNSE7MNjNiBedb
0zLNm89p5XVxNUzzj6B2A3uvGcyIzrLT9WmcwrHeKPQpDqQdRkTyWXRSYMT9Ozii6tmihmAip7gF
XAWpcsKVQ1fuSlPF6kGDhRgD1IKzQXHxBJrOM6Hof+X8BUyJenl27GrPQAOIljjjbwLkLoc9IMpz
MBjWMrqSc0XM8CU172qSopeH7n1yQu2Mxe7eCwAS0v6LwvCR0WX2KcITkxkeyOYZTuoS5SXQi+cI
sFFjYRNlsU2gGJJnNi/hUA+nQHcwn7Iv+8urMaZ9CQ6VwnGmOdUQxh4o4rrsULWqmH3INcyVpC9H
psHXGQqrgzZfk85C6y+JHGBXW2/ypL59/7mLlm9xesXfFY6XeXHnHdvHD8SSw8SOYQlJEs0iu+Ij
PRjd1OZ2fxcyZera3GPDxKDNXIz1fuCn23FYdDK/MhoampQpVQ0PORMdtN50v547aFnv0+w24BAK
06U+WUmzmDjvjVcH3hAmPDrhMCe6zqONt95aQzySQRmQUBapiF2GxQg6gksEYATNz/Y1p8QurGA7
qEDcBl4jU5qoCt2EyJzA0p3uKAt7AbRwpcS7SowMafBqvZGHX5hL2hn3++xvPQlrxQpi0q9ftxPY
Wbhbuu8PmMcwwZzW71pBZLS3j3hXdm8mo2BjrLYxzy3V+4vxgu1yW7WACLNlCmCSreISsGyMaYEo
Pu+oCzU8G59hlnSD4dZJv5wLj2F/+OoCyy++9tCdzLl5shG3Q5/IaiRqAmz9s9Z1zxxqpWUBnIh8
xycHt+OPsLU6+JWfxWSJFVWphXyEsgyHzwJu9UVt5Q2ep//qHMmOvZ4EYHYIDUo+cwP46UjjBBRV
Lx8uP9+IVEcK2gT4PeBd3XOj80W2NEvRhkrtk4+LVa0xjigcpzRvfF+sGD8l1C0mRwwFMngxI8+J
pVdm87ZX8qDOo1fT+DKpbq6HNwMVEYWPl2cf0KLDreV3AjsGgu9ynEKjtBnH7JJtMn9auicaoKm1
s0Jw6cOnId+kqTFgoh+sM5tFAhyp7ilg4UwOdgZhGmfOn44UrCmDY3x5epzC3WM2Hf0NZCyzKHmP
vc9kGSQsAifB5gPHceMwg6HsvT75YHNPzF+F3E10IO/BVC5XKbPAiuwamj0MNgeWbdK1mll8svZg
sjPqb2cUzsBWflp7WLk8HutBvGFWBhPDMhuXVzNd+B1BsHP/hpSsq0Abm5qCotule08rnQSuZwEI
Z7ehXR4CdUP1xCoeSDJ+3+sWb+tlN7AwB+8NUm==