<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy4md6k27cLCMuC9IFiSbbcQ7D0QptyNsPEu/BbfuuHKu4qKK2I6VeX+QTiOtXhSvwH6PVrU
HYjrG34kWArBA3PJH64zE1Qd1639h3uGGgIpAgHHd5VHAw/hPeOJURqjjAiQCctDmuFd4U8z4JHc
OVF6Zz/lnKr+EKhYeLdvgpJDTiVLxao7njmXkQ1JbjAgZajxblxIiS5lxhksAnfgQDTONwMEo/GN
V+1iKcVJuk4cmsfVNt6VP9O4FWa3RaiPDsShQM4BibGvDFIXHeienCM7Uj9bU6rFc/ip4JbrCuvN
9uW9/twmPUkVFWVYdc6/08rsQhassQ4RjFIt+v+xUxGeC6mQvYElxzGl/sk0eewxew5dTM5Daa2p
eLrorjVa/WKwwGRH3VI6UGeIpulbqvRK/QwgTvlySkfPWDwBZut6J/6Tc2W5GVRoe+zfOtUdeWug
0iE6plRwPn5fZ0jLHsmq4Coymhj0e00r+RAfjIp5UexFU3GmQM7+a31TEs7pIFDBOq5Syd07BBmf
4fdn/vTPkgeQnPbcUA48gALTKQwvtWjS1zLQqkh5DXZskqa78N4HRUy8KGYIz63gdKrFmmqjZpA4
XNoWOlO7l6H786jizVCTczBplzTkS40wdd5ujLDD6oXWHB399esnAnPh0dPfx1HZPLroUQHaOCXT
oBBwv4Dm0AQYhMTEwirwXxhBqmmpt7GmARYvl8tjGL4eQuVzNELjOxCBdQzC8d1fDiRVIXwYvNF3
Itoq+2ZW2x+nh0Nk8EthY3jtddzQuL6Vn5ZCVu54uOeKGmR0ohNT49cVfi+FEdOh2US7nBw/Lvsn
kLgveMvV9jDzAblW7GZBCqFwvlEsj0Qg4gCC5z891LZabqcLvWtHo+bdAtjmh7QA0b47dD75oh5m
xhU3/8s9EMIyXkDJvsExIBYbZTqUtsraUpg/lig0X5Ypdd1OBW59gjgHX2vWpneQGX8OeWBDufS3
9ELkCPVH5FyUQzuA3y8HHvZ6s9Mc5gcBeWutHLfIGQMGTR9OFjNuOifpZowtbDg+vqswSoBrewf5
TDsCyqxe4yaF5phAKJP4+t1BgS3OG/MzsVVRZtpzHqMk6osyrFpAnriBtI+AUbVve9dJrEzlEaAR
AAbAe5xVf51HFh9QCxyOrQUZvx283W1xJ38ulAre7DJq13cUh1H6FKI+c7Z2TRRyw7zi8wHvMOVw
vggDYPz/JajrdWz3OXEKIH7FMjj/P2ySojP5b8L1aXxzru449Dc2GVOqtFpHfUc+Dyz4BxWxnm9j
DiQ4IhzGUsTaeAaOr2ypxdj2/9V3cTqHFjwWJfPELY+KgzGtOu/zdMWCXsiGSzcQylSUWz7RTGww
q4jEereZn7QknOwlrQLWIij7xY8Upmzegcg0pna/1YwyXRHSwjJ5Y57wt1Ol1ghIg88+u+5g62Oi
oQ522n3vs3H39sNfUPjVjrt7lLnQ5vTxU9klhNBYRPPEpTzNHSZJAqbMfsfFOxX8kHg51HOKX470
6gweH66TWgyL7CpCkUxzt8RYxiusG/FsiMCMIR19Q2xaX6d1un/TpIRPa9hYzwPuZ0XVwNtRWoIy
jBMh/F5Dv5E7e3w/MGWPWr8QKXyBvC4rSYQfv9s+wL8UuwVKRberxKW+gq0wJ3gazIfhbOC3yJfw
9W4I8wc1PcH8d3N/0nPk9R6T6MbUjl8Kzz8ul6gUk1i7HSbN166XuyGM7nzwTMlKyviXd0/bl+pg
KaWpZcwdHQ1SJn4f+ETFXL1W1cvXpWS+ar3gMEBNPtXvbu1xPsM4aN8gBjOoeHyBV8Rklb4CcALu
UNUwAozMO+lBDqonghR0D5Z86qK8Tyj/YsO60JH0ygr1M9pMdCQd310hbrISlYb7gaLgbxlDyMGR
uLxw1rUe/0AcN+IsgtnM4JwdJKUrqrpWnueIiNyNfFdQrZKH6JLo2imv+DU4NXsi/cGF0oMsZlth
UKrI5yLneAgs6/Z6wNi6FwLigbHdw+DTKvrfcvPjHNtjIEAmrEIg8f3/uHHrmmt2wgMz2xOlgpHF
uL+ua1/+VaQhwEdip/59zW0BkmNYqXDQWSNckmRuV7Y9izhiJQR3ygOGdtcLToTPsAApAduP5CEr
39LLZuBMO9mULcOJhmLxfel2BfE8HgBRwNUnDcAQM0JaSP5pGBsTqgzIM1YACekR3bXsu9Jtb5An
875XbMWM/FVWiBMMRKUzCTQqbW==