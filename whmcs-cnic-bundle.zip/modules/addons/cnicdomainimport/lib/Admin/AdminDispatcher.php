<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyK2Lcc7xAfENh73IgMrHn+hKXaVMQi+MBQuPM7ajsq9zYgcpV6UYuBafhp0lIV5zQteGW1U
ZO8+jxBQwjpFb5V+g3XS86MM1WXNIJs0vZCOzsdDbjmo0ZqUp1EkEIAEI5F4D9Emt0g3X1B6R/n/
6XlgTNu478wcwUYKZWPsNdX763J/ml6E/cH+tc/EkyKStRf4cQBqKsJWEgCh/Kc/OK+OX+68ySsM
X5GZl48/XFjaSmY4ai+3NX/J3uO4b+YFbaOI3dZg08yfAPZoJlL6wQeCc/HfjFjGmvI6cepVGsRX
pkTP/oqY6oY3rH4B0kzubIkuGZvYtouHCb5jbTuIjwm0uTTUMbNYceYCXpWV6oyUXBYxKDjSkqkq
MsEBqsYGNzGYry7scEAHly+gyaPdGymsozoIixBRCkt4y25DGaxSgtywAXJp5Puc/OjjEKgvQzGC
hmL3ZO5v5aNQJrHjSxD0hHPH1T5bMc96/Nc4znwKarKeYZzZ1EMEDqaTrkNrBOxP18azqxMw/aJa
DN9xT+uBq8ZIp0vXbOhYup9ipGylXZ5rcFGIrz61vCJ5InQs9f/bKiwMzqS6L7LeTEq9fl8bsEy7
1Yekyco7NZgPt4+i2NTPDEHyh7WX/20f3sJHtjeSZYE0wYFlDaQDcABKqJi/xW8vYfKxyaAIsVR+
DzFFhhuLhAtYGBEvgUWof8+wGianwisX0PeH7LYoLGwIRgVU6zazFH2nfydcTqlzHtAyS9OG2nd1
mMskoTToCQg5bJuCj372CJbzrqx/WIG0MGdF3qb1rnilN0l1EvVb7SzZLcFmf0c3MWD+esBSudES
Gv/wWFBHq5S8RVcBU/ZczprKt0snSHBLu3hGviDpPzVHXBjlDW7hqbIRvlk7TtGTYOXK85aPM+jj
oNe8r6D4DDeEjBu2g6TM2MWrT5inR9wl8UapIdCY+j4dQVZbyGvOneq6E3wqxZJ4SRLb7fW06Fdh
MsefbZHFHMvghtCYYg7vSPi50qH98irAtjZsRvVcN1u3osDzBlInn2i2L13U4+0j4QM34OaJFyxf
4aza8LQIlNiGyt2+w7KCO+p1BHSq/mAPBu+kKMyrSzFeiPfsbm6oBpq4d/lich4dC8jccFbjlNv4
ioAh18LyNmT4ME6VNMcgdqGjY6cbQ7JOdzS5s+rE6jOXjYrLZ0aAtKo3aDgH5WqCWhMstVZMhvXp
+EzMWJGEo9GfX58O/pz5KEvf3QlE+7i81yMhQecnt+bKvy0Mfk0i4D6yjaOtw9Vd/cfzLFF5zrcM
OKohC7UoTzcdoRi7pKsCFvwor1L1A87LULwjgmdCMrGCChkHwvorOAW+/qb1WFsgfy6s3Xho9AaQ
t+xVh27Cns2iRkudD5OK0eKGQin077TsVsxO52wI3j0NSWHKRehgjepIy1ncifjjSOyRLby8ToQQ
g+HQ0OhtYt9rO4aTXzn9IHGayzc3UKRHpIBLMX1uVOdWFqKln1y05MeZjfArkUQyR5syDx1wvWeS
TRjS6pZWGWjTXvENFyzZxv5+QDEVbuwG+VP+OJBxcU0QaiWTL4sX34K/tEF2xp/jH0nbdDzJB8Ve
hPr6njEzGaBtzDar9ozu1cDy+M9QQ2WcHl68d6yOvXsVzQgDn4yEjUycGnSrLH4Y4SG4qqen7WE/
jzBSQ7B4NEusZBR+N5m5wJPopi+SWqHrQC+30/IZ+TzOEL+ivHzl6lV6qfiCGWHjpCz5QTP/1WzF
i9MlyBuqVmkKEdmYAWWv53v6UCpARuqLzLX0N2TKkgFqaQebRO3DgDSknSuOfb7TRSZUrtBxCipM
UHBmRGogTB9SRx3dD+cx4VSA5jaL5AwNlxRPXB4rWy0vkrS9PLkmkG07J9LTDgKCyMgR5BEfUmZM
6HEmoI0vB30qllzcel9ZsZf9moTwwo5VQrNQbEc9uvhpJVHjEbgo4e6mKbPp457Ptqm5bs6/el3U
OP157CMxAsYoKQfpPZDPNepUMBk25K7dPG2iDhDhcc+ESoggLr6AkSBfG5TA/FmJ9vEPTE0GH3R8
zrleAJgZYSnAWsplU25z6lJOz0r8h3f18XGWvXbekniJ70kjzASbkqSw7TwyCWqaUOnleXh1eYEa
r7gSEnR0eZQ6X/lpDidonJ6m6PwIhA4fOavzqxJrZ5cAcSEJgq9tr7kNPr+vCsbgR9vcZnd855Kd
tFUGv+K7pW2/kr3xFxxNAAcWeiW+F/yjLBonXSTw8m==