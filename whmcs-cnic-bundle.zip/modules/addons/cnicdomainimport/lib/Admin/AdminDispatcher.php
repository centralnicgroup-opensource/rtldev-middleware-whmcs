<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxwrN8POcAMf9GR9fTgZwaDhkSi7ybHisV+RUMbFT2sGtRivjdTlWNbOtWaCHsQ/g8HiPwUL
Tp3I1LHz5KZjYFan6X+zCjAClbQSUZZ+HgGJzRsnYT8fJhXItMSDIli+gqAJw7Wb9yXW50zsj49d
c4xLZq5o95OFANz2+dwpQK2e5hsg2LRXQvyTrfLeVTMTThCJiwZQ6/ApdUJ9EM2Yc6/WLi/de9MZ
nAi6aQh/XVKrye87Ktkk7999lCshDVe8QYZIBi0ecS5h5/SQ9v2j2HIeQ9cZQHdp3yVjgJt69r0N
TzOdSFzKwfDNlgpYOdTiLUjaAYDYkYKIwB10r5CRKLBusRp9+B520KfW9sz3eSBVjaQnZqiTiYDZ
vzR+hX68Fqmad55xzkOsb0WfL98AVQLp0zo6ZEIC6z2+zhVv+KJzV8k9icAPuGQxW7mbcf6G0NJM
vd2bmpVn9U4RHLQXXIEMmpC/0Yw/rCS1rMP6kNp8KIr4gsh5qE7EAC9/ifZS/TDlCKmgaVSSf1/9
2dEHgG/JqM+15oe8akBLUN4MzPTudzyzMYIRDOllNU8aTKI52D1iWgauAlq1oJYFp2JyntH0bOAY
HxoHZC2Her5dKQ+owKmkABbeKCVlu7Io7FUYFdPa9TGxhey5ye5ASutUuWha4yOrkcdeXhODN5KZ
+QqFzOx8Ol3nvQdqeVcFCUHN6Jy0+uXDxwjMD/xQPN5N58WTpNAb8PPwixDpG7tV4aMbdSWmR9jB
eeqA9lf9wBRLVmqBXF8QoSflrI6BRp0PEjWdnq8bepYZRi0/xTtOcDDP5Xp77MVkOCT7k+3FJLvj
AGSxoKSBBVJFHyi609h95ifJieoGcrXH5v0u6iC49llPSU+mg9jLOr2U+a5MCbun/BzFbd114+mQ
k99BzZ7lgoaDqVJFRILapfWDdhJIQME93Rk8w1umH99XFgbj3kE2l5NNw8nqQBXmHyPRU48pXnms
B1MEo8m56rB/Roh99KtpQgvBgguuW+OGqK3RzYfOhyQzirGIJAnvU493kQC4K5hZNJ7t1pDmHWqE
NiaHnmdiZ/wEcqWDyCpLRMulBWyMN10HJ2BHNTt9FOk690R4/hni9Zfi57TW7dzddFHInQ32orHt
oVkHjOVWOV8gh6WkCFxusiaeGMdareVImxOjClgusTfKNRh6vInC3XtFUfZRK3ybOZu2iJR7/9p7
eDPLlfX/L7M5EYhZtReGv+wqsOTRPrA3ZufZg2Yz7TwOk4rXrzY91T1ltvE2N4v6YueTdc59ClkX
D/4K4PAqSE+L69Ulx5Qdkc1kv2cGRmw9re7HS+hmOvys9+i/BpYCS1iuh1gbKEz63syMAZbPJ2GN
576kzE1Pdut72MEyjRm9jfzjWalVkLUmk1GQMjgZ7boamtcSo8z+GCPeJmvGM3NDcbyojcZ1an6W
CvI+Tf8BiEQTXXA7I5VQ2u3qJt+yiIypliqJU9yNDrSYp1IktuZ41OghFvEu2vdHSjN7qUwy37FR
pFTjcoo35d3BGzuCoRN0gfotUBwovFkdANrUTUoumcfgAh+KQ6ViusugHPuz4DSqL3gqFVwE0UOL
OUjIIHCuXMSC5slHhxmqAS9s8EwimGLtmWJBnSshcR0inZh60565zhInUTnjoC8fz11BlTy0PSQW
RzTDGibPWPOFmZypsIOb8iS4fGlP1t7uOllVijOadFFcKnbyyKg9r+HKQC8a18w+0rthAcsr5Zkk
CX9J49xIVpwFtORsvzJ41iCgHJPB4GJB+apEBQ8AX93Hu7kcvzp+hmIF9Rvk7EI1s204gfAh2CW+
S9lyM7NOMolIjYCQhkqCRC4AJLkSxwrQIEa4zJUsPmp4Z+nu4NqmMmbat1c3kICzdIJ+4xQOs0W+
pmG77yiBEhzdSOvD4NdLcblqtyPbdSGuSFd69E5gMYkG5FPZBNTfGsy7eTMh9IhRRDtt9ArGMJgX
czgJZYybZlmoQu88TyCjGEE8h0o3Tb4MeI+UzgooCBIyiWj/SC5Pd5B4Qrz09kwwagP6Ty+jrIjy
Lj8lJrE9GEr91pZC975JqQ2NYi/XQZINa+OE5+c+5HTqqRot/PhuId77x5JO7DMPDMmT4v+NCadh
ugp4htd3sI8+C4S9I2/IBqvJpLbKCMeUMMe0T39tp5rDXb96orDeM845dbiD9Ql+uRFJmL5PPBCl
zliz4/tuEb4JNRr+myrEkwp8rXm=