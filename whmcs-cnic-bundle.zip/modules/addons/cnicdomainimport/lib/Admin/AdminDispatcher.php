<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmHjhTt5i1KIaDuu/j5oxCn4tgOHPyexpDDgR/vOQeKBx+IsyrK6ONXcNmFb/hFb6qXeH3du
Rd9IHX/crCh3Cg1dHznc6ofVm7cy1tKCUK8QvvUiDPSrnp/TmmOFmIIHFO/+xNY9SaAY6b7p5Lp6
rn9NKt9iLuQqPTyJjDaoHlxLCFI4dO1D4MXHh+dz/NluMlPOkBPA6frY07Mf5FVb4VH+jYwvJ3/O
9d8B7RdsFfSNECXcwcWCZaOiceScouP91VG0rnwiyuZgqoK2UuO7P9oSIrfwQBrNIWVS47AS1q8O
o2ldLp9k1+oPi0WY6NfRg3PvMKAYCj2fZfJ60K3Nkx6H+ykqje2WQXyV691rExHHLtF3HHAelfUM
3CnyIq8zYGtvj8h9dnuWDLTSYSWVgu6S6VKNQFaMhrL6TzLvALbS6OnesWc54vLH/xpDJNu048jY
7Jl/dhxqAdh43YuIHyagNobfPcWfkeMzSyOd7hyWoJ9tILZlUpHbEkWFWwzmzafkiH1522LB2ZQn
mNgjWeWBGYdtfIv3Z1ZSS1FMOkJzP7qeTPH/PTFqckGP/ia4GPC8jRKrwW6itbZUHXfuxhdPyko5
s8jG46yHXzUebEYu3hrga/Rb8FalQGka1RCZKKq5X4cyPlr/mxH3XhHoJDOnpmC6HW3mvxsa3iJ1
AkTVJwuAQ0h437srbbAUWmLWxmL/ilEGxeON3FYiOErHJjEIVlw/8LytzakjiCqqiRLHDe7qPBDB
5sFn8m1+ODs3B7aHqLk9oogTWRtRMNdcP/2Bnlj4AxQ8qpvQSYT+t0E439iL+JJSDl76gJ3wP0Us
02xrASnfY8EIGuzYwT9foBu2ujlLJCj4mGIkcaTNm7DRgWa/5PG7GN4eKJXvEZ5sgpPky1SXKN0g
Wym+nP+rVJiq+vmiSY5sQY5UqYQA/3bJCIiMjky4x1eISk+6qKx4AnqRN5rxJbwT5YfypYj/13GF
jpTQlww9YGVJ1a7/Ii51YKXRSO0Og7pKwtCCu2qr21yNINZpuukr4ro6ScNinyfmmC6wTDh/tk/9
j9cdgEyfaA9ilYBXkEQ5k1gLznMjExmbrezPigPH+NS9TirugQMcHLJzk3d+fBQdlu+OJmjKjHtJ
8eJ0h8oXSqFXgqGv0sPFiWjvxM3pBL4AyiGi/8eehgzpxFSdIuShJg58roomwfiOQOH2c4/G8Vn3
sFtCs0bhzCPX1QXyVXY2qJudUhp81Hy3M24u7BW7uZbrIw26FGv7oC0NMcwBH9ndnpuvNXW7IuyJ
4m+TKkCwJ2QJDaFZ71iKrJfCf0jAW3h3c39po9MIpsHklNYdwSllFYOsa/U625HsvctdhNGNiBqJ
NqCm/Mh8YkrcwbSPV5eorzN2zHEh29weNtD6lzbVfqPV3BmA6oHW1qg9rG8g3Ubse4nuPYhAMHMq
eSfYxuaQp8/B9xyGnWqzffbEE7Flh5px4DvHaEkwPQfSmBHCtgk8c1wmyEddrvd3NEHNsVnysg6m
VvlYaeYExcTBEs/WSOiu6FhuYq94f28+nmXjdnvh66g5hfIFriHr5s+YYZqzchM+UVqCfxEWAOj0
Aqj4CmxE3VcW/VMR9OvA6vtw7jBQgtNRWkcMK2476VTaAqKpS458AOyNtqw3X44NB3TQojo/YXjs
gc5UqxbyYLdk1ZxVpyaOAzhIKOmT//YVfId7he5Knzioz+AxvCydKk7uNAvlSlbBpN5MKMBqGgo9
ZxXwyNgfyyjhNojy5F84hCq4EyoD7XC/nE/S+sYYyjWJnkU1stPZyUNBG/ky2KlAl6/53QW95xws
p/30/IsfxcI7cFrSXevR23Fdhl3E9Q7M7k+J/UPOOGZOH6Ya5a3k0A9ijHumP/9eVNrFM5B8V65B
bhUa7C/5QpNFLZ3Vts1zIeOlaHzWxHgQe2HGH2aNya2qju24AlB0Axj4yQOrbPVlErRVKWREBXZC
OMsqYVcucKteNEzIDmIN436NLam7L6iTyb6k2+itE7xq8VKHbkhNnMerK26zvHzqRsvFJEYwU6g6
sNVtCXQE1mKrSFczYupefLjz7gEdXPG170Vq4wxH8A03Z+NgelSFtfB0TRPpjnFJ/YBPMKLwjkgj
lGpM+/gdVL8P1XBj9BCf1Ox3VZblLxmnUFQNkF6NQ8ZgoQQ4wfJlpgkn8tZI2S/YL8+l+NT+vM3J
Tn8mGPF7FPGjF+V/0pePmzhxfyEv3CcuWG==