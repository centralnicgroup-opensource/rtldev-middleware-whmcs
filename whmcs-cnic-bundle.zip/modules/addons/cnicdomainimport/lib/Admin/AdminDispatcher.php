<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnxHfVp5/vSUyv1YCDyhCAz34Z28oqeI5PIu47s31SmGPLX+CfjVGhZwoCgxTTRfbjQtAjkU
RVqhXxLTvh1X+twfewWoaBWaf7siknxq7D7m4+LMOz688moBVom/CrRtCW8+d5y3ZFxvZSeE+GGR
WbGYLcoyuw27Wt1HfrmwS7CHeOxOJzgff7m7lmveD+6O5jYFyEQ4o5SjkITtYrCrQ9mSCrY+p4Uu
HP/wxVrh0TyqQCUBYqLOGHJaKAZfZfNWE9f0iVziFXhP3NoA6aoR1ZAhpObeUAsev/VvNpJxp0wI
T0TbKXAjXcCBHAMOPeAanuAsdsZVU9VvQB7vZB/iWJx9N2jtK+iracYrNoqPgKXSNhQ1pTT4k4DB
mAF1rLp+dRViPwQ41agZKChbamdkTGG3RsSw4pA5B7+i1G5AjQkqcSCtLX06TWClg5atUvrfBb/i
zrioUmnUVhkZj5mbdpUgncK0i1qokd/p/JYctX6QCcVmDZk9lXUTZJWRsgZKOsioAO2K+Qs4GEUa
wYpyrZ1mfXpb3VzZbo2ayianSWI/hpxMNHZpuWr7EJR0zrgzghnB9Yzr2aMsW16BvWQzuvFIEayF
PmM3oU+bdkJtgQn149Gh/iTi+PWEqMFzYTQIT3g5MR04YNqBwMpgQXnZgW6ROuYT4pRp5btfCpuH
DCfblfa0Q79nobyatsot9C1M5Z23kj0N1mm0IbBDVEvzsB0pyY93JO/pkHxiIABB2UEs+ZNB49je
hXw66kgsEZgLpi6LCesO1px8H3UsptAF9ehZQm03WCdTfxunSYAb6ozyyTVXagkJNjXL6AaisYRz
YeInU9YElzt8cUA/iVQF3nq/U5QM16JE7Cp3pytQDBaKnaWegp093cQuQfaeFPc0qZXWh2e9rzHw
Nypxgiqc3OGZq1uKnmgDWN9Oi73TnRJ1Id4/wyvYpCvcAi9rWpHTvFU2cXV434Heqf6NMmBXw5bh
Q9LPae6xFwRkUM0RS8uQPHSYToG7D5pkdk9ir2MbU4sLYE2/NdGesY1e3T7HbnJFmevMJzOKPJiO
mmAAlx6t1QrddiEzQWCBGlmwhf12131Z+OYLxOA8CC7iRV2/ehNrIbuZTkJ9tNNhJTkPOr5nsEPf
GDKeCeA95eLS7nFqwWQe2Hvb/6kFuommVFH1Uk7TWN527moDCtBJ7XvMakySZk5V+6TMqsDl+TGA
DX13kaCQ8/0Mtdo1PDUQ1x4g1J9eIQvBUnlET171reV0h1QvVSKRDAj2MoUVJ1se8wCEzQUHDWSi
wWbIVMqmnn2WmCHHYHaVp2KSmQSi6XgYhPESrz8TGJda3UK5v2Bju2tfU48KkfCE6OridPuwFbrx
+q+3oYWORPDlLNgvo9rIxRFMND/oyslydRfrNoavc7wml71okKucd56nyTzya1Za/keZBWdYMEfQ
oEG0h/n5C8rBdaRH4wnPOfVs+/5O+jNSLF/w4fNoE3KYuMoT1k4mkrrW1PJF/ARHjMDtZlbF5As+
6CIVyDtWGlqUu16SAnSGSlEY/kqj76h47Im1H966FZVFtkBu2gAfWOuoHlqsoC2FeLq7qza4Ew8v
VVypXvGA44G7ckrnJke5UwtoBSd9kBO1QDPJQU9byoS82SIeGE9z122eCFgfwBBGvXs4mYvI4Oed
ejRT606LTByZDN3OpIfTylCVFH8/NZxksmiutEQ8EKALqQcEnz6yZPALB0AiCoUsqzsFPT20HovM
t6DmacTpM2GMQIhgwxFqDGCuE1Ij3MdiLE2najWElrbTvX5JabLM7DV7Yp3SKIL40ga84qBtq/BL
AYD9jhKmzO+xZjMv2dha2GtS0PAb8QCAqTy6yu/aRQhD8UXnyyQOSaZymu7RtejbFjT8/Mwi8SyR
JGCiFx9/tjlQDZfRvKsk4TPLWdjhSTQAYcKL8FBf7NcoTotSz/B/jX2ioR1y9QctWuWrz5ybVSzn
/bBoCA5ZECqQ+n43Tos+SqLUp8BiuT+u6zjUeXsM5wvuOlVasZ+vx7xV+P2m9QuXNDhPV93gXWXr
9rSgk3v6Bihved25JqaBPwzB/0u1WgB3TrETGndU/0B8phWODrHgo74Zmz02uEswBvvXs5vGRhEx
K0t/kqBg/5PabUkr107vMaqepNY/8PF8UKrbWilsYNNUU5DhemXgJfcr04AD5gAOXDrbOgohpHfx
vzVBsWLpxpKaPmc3QUx+77eERocX9mFok1UbHyzFI0==