<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+9Tfw5ke1kMT+uoWaTrzz3Jkwojsqk4fR6u2q5VMwmIRpDjXFX9TyXBoFLTa60NxMHKZRuX
lCMP4zgVqInBV5R6qqRrnRnGqPps/IchQcgYSO7PyaR7TabSOKKpISJZePjbfvZT9/F16ekfvYLn
f6tESrHaHpyfnobLj552DXIeV2QN/fzP4jOsjBk4AEExKrj3hKS7+sX3BRDOHUJd0quZRSkd/WQn
1OdcOfF8ySdAwtkvjyATIg31Q8zg7NBgzEJuMFfkl3Z78Es38Wkf2AQJChTkUVVqnRuIhMOloeeH
+0SXb8aFlRX+4g8TYvBXeTxDLuT2vWol5SzuXBID+LdqWgxBg8KtHkKwZawSDnyHNtiTJ19FcTgx
BU6sXWp5unrM7b5fBuaH4Gr5zDl3ukiEDaMG8HJsCCeQuZNStW6OTv8iLwyMcIX+3P5rilKeEn+h
+ZlG7TMwXkE8+i7o1roZXGeb3qFwY92Cif2tSocWAHzXRsZq+jw1RsTgBhEE0MKTuNOP/aPi+j4j
PR1xpfp4XvsZir0tnX++6PWlJIvAEmxFfNdsLZRmN7UntB+5T44gBdiz556rlCaFAWL1xQ7fW5k+
JH8CXh8e3tL4xGb14xUOaENKjBgCNZtj1kAgKFVAMFjw05V/FP4jjLFkTtfZ9FCoZAZVBo/HycZY
bR3RMzZCcG9Sjbo74AV0jmdgQwa/JsjLNEwz3cA4QaynMp4l4i3iZsFlqf3sxPLR7Zt+2l0xXWrW
oeZpZYudP1B+FLWPFXGYbBs6uN52XxZvNqzOGRi5OcjYmbLnGIarwJ8YsdkuF/KppGjmrAX+SkLW
fWEKGki+Gd4t2tDyGFuLMFFr62c0KF0eAhF5zLpwpncim29xz+89BpSgHRTZaEMGD0nmsNQXGdB/
jxe6sDO8VecgOgCeho2sIlRVhqw220l4Lg8Gmcmo0j2N9q1Mxb1B6Q5WloAT+YlOyVZMkLGrtFE1
HnPdlPl62dSCuR9anHxJFsGRJ9xx7nBA5RWO+CRKhBFdhLsONaRLmOS1uS0vgoXRi8nyBJgXd/eH
pCjDrC2y2Y2xgOgwbF7tUVyj0k9mB2Uhjb1Y+hyrXVEviuhw9y5TwJ2P6Lz53g+68/6mvNeOrIXI
nmpf2Fe35rb7Va5VFeeuIuVmixgH7Ak6p5Of1SFrXerD0laGXEFmgmRxDhDW91uu61EYEyODCSLh
zhtYZQ2goRFiktYqzqJp0J4RhnxmgOfqpULgQCigJsdV0hnaxupEP0UNnmyfbK37iDmVCg6faHrT
hU7h42LViiWSVHbGPOci9Ea8Y5g3SP8/ll+m8LkKJpkp+JShRrGn/zRef/n0/u5NEVIry9BY/Re1
efpOCcWVefoyP1tnskdkE8uprzMcZ5iYfnaATi34d7+cTMXvIxEvXrwijC8+Uun/000DXFYd0un5
qw/sAhLd4a8FmCsFuemlKpHPur7Vmq43c1O/2vjNQVDweNLXe5dJCspc9rWMIhI5r6Bu3r94ggzm
v2FZuYu+GRGOQqZrT4F8Oe219vbfDO1BZFGMPcVuvvJ1i0PWc6FAYrHtt4DR/IUe1miXeA/GR4ku
3qyLXKpp7+wuS+O5Mug+b9Hv7IytoAUDE6AjRzXvDNep3UEW/bOKKiAAMVG3RTrsr/f5vjd2PN45
YfPpfn5W4FsU0NWrJYROiUAVQa3tSY8UVCbb5Xf9NL21eOuP/e6JtC6ojz3CoT2BVOjkZ+ruvjOH
E7uSPD1tPW+OPGyYS96h1iar+HPHt8Mv8/wkKTib24phHVux30jClMG/NOOxeu+QBWgmjg20fk0F
jr8tZb6IKNwQ3hmOhruL4Y8ks5s/lt9E9O+bqj+oDp2RdrlNOZkS9zNVehPXhI8sa4cikHjZpg/1
25lT6zJEa/QiLnbU6h83893aOBUHlZv8j6Po7pTtiVJscd2C0yz6PBz6BQ2GkLehbRUJoIOn7/yF
A61Vhg3Sic4Tw2H9pxyA0h6fT5CJFY/wpuKhJOgtBLtV17E5EyU1dywInBnSxxeTWNwDrqIeGA7I
8/bGQJl6wk5uRruVLWtrRR5dFVf09xOUmSb9D2m+EgOcRSwon4hBcnwCBLVTPWrDMnvFvhdX5BgN
bJ1vcrSiNquu6cnI34Dzu76bomqtFPFjedMrbfV4lC3u3ZDQ/b8itnfRpDelWE3sYqlTvJiNjU7V
OkUOuJ0J9lBNNbgBDkbLOb+baGNNfR34XDG=