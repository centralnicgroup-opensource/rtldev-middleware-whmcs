<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPogIMgVKVR+8eI7FX1YYxgz6yTDfSbJ+yESsV8sRpVV5kqr43rJHz8LDRz1MwCovPUwnuLNR
nabWKUWv6F55IJliBp6sufT1xnsLRJ2crxAqku5A0VGo8Ip0HGrDYIeaJgq6VRYJHcfEpbIvjug3
M/wyejjrAiNu6dyE2DnEHm72dRdYPM87negxhYOErpg//GUCWOVgS8KgSVuffX0PuxPXL2aXMGer
eapU4mXyTfQy0oz7vH5EZ5nbSPZbxjPo8j8IhpcUmGR5TtnuCaEknTiC+jqKQk6npUqv63Dl6hmF
E5v7Emm+vv2gJifLGFSfX2sRIWrmcSWAAkCIz+goXzCbap82iNVqvf3LKGK66mWouvPvRKX//FXl
idmowKVZwEN+nFnweajqOMehs5NPb/0vsngnehHrxp5cubmaJ2hOv0Cq+VgmXmyft1kkRgFW71UY
Za3AN0lTwuUmuzzYyVqK106IjutRVe6QMQMV096p2uK+nqKa4uqu6GJrii6aVUFlIun+EefjI4Z/
tYvRKzqN06b1kFU+TDPA/4VVmXtqesij24NoLD9+Yo7bhjvQfQKoVrFbDKI8eF3mHsSNm1zO/9H7
vSQSIibVsmxpS0smaBZ6z3dJ8l69ztEMca4LBuhBatirBW2fCWDZUOLGNE9WqHGh2GWNPFlQ1etu
d9ai43Laomm67P7+qWGNKHEtt/Lw+UGpIkl3bQpA52ugZXwGNs/LUdj0GJv2LIAQQY8pKxOglKMv
24FL+JJA8J2oFYS3hh7UIWiMs/+Le5wQW3F0DVbUcQeeuoXIbnANf+Ap1tluz+23yrg5+LmryAWW
ceVByHIvY/YVnBEyTPJE9NWd8/kka2lyeVWzo3xuATAiWhFAv2o7sCkTuGCEpGExH0pg2ebQuITN
WoUV1hQSgwB9TZYmcwoYp6+8HCaNI9K+Ach6/sM1BdomhU5QH+HuFT17gPS0tVhg/cXkQOuAFimL
zIPK7140InJAsVLX2YOPtxXi4uwLfwYP3jsICPLq0aUh82qxPux97uR5Sm+CoTRszRhlgNEGmTu8
vI2J+HHBiBKnIM2TQjEbuQhER+z+XAgqePyVEHpZPzxwb5fd84+Wnn211fZClU3LT9nSAsTEZdBy
W2WGL9JLHXRYDync09Ou2Go9z5KBj2TPbEL2YVcUY2jJ8Y9ryGuoPKRWKB7QtstpJ9rG7j4I6wNL
qnpiUU2N8eXs8anvdeerwhsRIWQijy53IZtCinhGwXDis1tLSNG4SJHroUtmuaPy/dslmU+wK41W
SJvcgmfO6o9ei4OHHqYdf7G21wHnEfT/Hu7qEbR0qsuvgQUn0kXbXTF+OvHIbW6Z73jE2HGjN+D3
RlKvCRFIOqT8Cry189rgYObWMkgkkr6xNEJ4nlyR6I5QOJIW3ux2G36u8Abdk1mUP3ZBIsZYUlK2
6/W/Pcbnl5Zjq74cK4emRIvStkmxIv48xVscED4quYlh9DWSZpc3eANN1f63JmGHPALfQ73W4zq7
kHi3GS+CuaRXL2jtIcBQ2Coi0WQZ1o+NmNvCjghuVfYYQP9GLV1/riJZoT5X1PZl7w33JmKvT9vn
LDtiWtU0PFpXnJ1ZWmRw+Hw8SQhd/888chvxd2CAX3dvWCAQkOZMNmPN4QgjuRBRldDasxl6FvyP
y5BDJyMj4JN43YC+dY3RIvlDNpLL7yUO7vHHsVYbV/OiRdZRiIAp/hF1JCjEf3jGVG730x918iKP
t78K43Oeoc7nfzohp9odm+NvKM6YqcTV1un3PZfz26u3uuuZjDMVhsNLP/zQLoFlx5FeItD8J6E+
WM/yyITuS7l/YwjoH/B5YKht7EUlyacKB0As7ZBFjd8Vfa0j1+cH70CkKe1Mbfdji4X3u5hMIIVa
D9e8fZ+fRPQTuovGsczkd7vwhmktceMPQR5TZpHhzAo2PvCiAeyaICoyFZAZ06BlH1mPx0Hv1Yh0
UAiXBnJ6lCd1SKTgK0+l8Y+HuO/XS2HfSaSUWnKoWAZjO+i+A0Vqqwau/xq9n+s+UanpeBfjjLcZ
y50P1Y9+SGx0Z9cdSuE9kznyVUX5mCYE5SP29lMVwbKbvYKOrtXUTX6CKvfXCB7r4lQZjZaeon3l
ZoY+oZSu6JZdleYVAZ456mS5ij2bLPv9MCeH0QjYVCr8VlBQeoHmGFFHflcGep0SR8hhHC7Vke63
5VjuswPdM4xzoC2Rv86sDM7g3iMObzvjV1UpD+VzwgqWq92D