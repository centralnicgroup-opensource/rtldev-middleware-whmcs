<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPysMOqExU5XrGYNsOCeO24/jsv5J03Pg9Q2uMUew0kFVk9y/ETKD7y5ZiX4CurqWoW/X+Hek
t2m9bhilXRKkkA+mxkYAQfwaA6zZBzppTDJcuNX69EgdrmFg08xcRtvO5IHPye1F4S4cOv1Tgphd
KMhoMZMaLec+PTkWqq0c3D3gdBonGrIbeFQI6DrwsQ5aLIUvlDKv8qCjNO6Bsdm6VRZzFuuOi5qP
hkDXE1nM+OnSYuGN5cobmFpc3mnOl1sK3hB8xIqRXP/lhvZxOR6zLnCA7Xjd16+TXnmmIPR1nqXn
7gXQ/yWpKcnUn1vERvT4p/WuKwMphISQdtC2qiBV3MH62cP+6/PuDszQuiaYGm5cZCEyTmSl75ko
m4SfYYidac3SUfvZZP36RJ9vsQ3QJh+dhoZu+YgfJIdNDN353jnklF1O9B6v00Rz8zL2xLIx5OM0
mjZ1fy9Nv4X61ZY+oaT8Nc2gxJaEoOdn2Rwh8NeCpGereEjVXdntRM2m09IjNETs7WbKdAEj5BZd
yaIcPz7QvqXdQL+2Usn7sdfLhZMojAwofKHsM9SMBdkZsXsMgNOefYpVMjgntTwCzF84SvPs3IzJ
9DY+QkcDTBs+ZLbUpxWSrdjJoXLy98wEMS/bvo55Gmp/iV2xrrESsfvYn5y9f6Rf12w3TrIZ58Nq
7foGBaXFXftzR0vnDA7oU/tKYJwx9kbo1JHgDjABZmk2TqPEWt2rjQcVHYa/xawBYGFT63IM+zej
kv5NekMBW3zZ98PXLEhuFYKzwF7JRNfViuuoE6YRLghQHri0CDTAMqMIgUFilgnXk3ZothhNlitz
f2wXxmZCO9W7+skbeeex3xbz4eJyWNHejUQ8kfmUiU00QaZUCGOZDgN9yn27AE5ErmgxsDBO7LMt
wjE6Sb8M3L5miIroeCWFxLvd9goU3SJWfu27/o+YzqVKl6X93XUM0jRsY7lvE1Mw5Qk1sNuOpwA6
Adj7Nl+q0QWnyU5oQ1+Jp0aoYE8l8l1fCFv1pcO+yfHS4Er5ss1CTXl/0vQAmEB7dEcOJyGH/lAl
hCAaYVUN3y7/UgbzANGmX83XmBK8TjGiy6OTPdWCJ8VbeNghwt/qX0N01JHk2mq5VcJ7XqEkt4bG
YWc+SROfsucCnKf7yiehqk0+c/BQytu2lH/g9wWQCXz8Q30trrTUOWGeURooNZIp86J1ajcLb5IO
bNWnYrJnlBmTfc9LUN0jsmULiZ+x+Yy5JS3TVGRawvqwwoc+IKgBo0eGoa25vJ8GBanFfh6JXPlU
Su7FvRs/vo0WBjOeoGNRz7BovPfE9qTUFNrrIvnB/11DlH5Vdl7qXu+/pGa+lh56VyV/ZCQ85R7f
Sou+lDcuJAKL5RkwPWw80UHMa2GgkCbiwytOMsDfR0CwR0DvhUP4lKiAdfRVGxU16dwInKGuxrws
hhRDNQ0iuWM4+flIrEsElJfN5I3F0Xqq+/iO5PWwi6h64aGv2hsklZr8NoFD/nCXP/GiOZ/Wf5A9
/GVKkj/QrdZdXaPIqjTZoXRTBsIb14aAZpTiz4iJc8PUnx8q9YngeCwuUHQc8fbT0z6tweq1DpZ/
6zoEiWt21yKm34c+bWLq9fPTuR+9z0FLpHYmOLqwA+pzh8l1fqzuUURx7dk82dWuC/8sTLmkavVB
9mXgn5K5bg2PaImtbwZvn3ZQTNvxXEN6sNdIDzrmD5OjvDP2ycpEESmggFVGitiwA1D2xUxJLyrb
YMMsqUVehZeTfepxM2X+x5GVwTGtVu0FnAKxOFKn4cM7603UihNbKaKoLoAyDMBOA0qrLHBDc0v3
dibbkCMjYSKJ2cI5MScuMR8Hv+bO7zPpUefcBK23Ikoopw+OSvZtO09z1scWSs2qrH7YeFcJoSgs
MNZE+9VqMh8SFn8FwEh59wp+3dvIU0Nks39rJRnVmdRxCX/DvstyL/LK+C/R7b1QOvCXC26FeGUe
T3NJWq4EY3rbrKjldcTC1H4t+rAMyLrS35bd4bv+QA6iFJkmbCkROwvZh1Me9vTpsueVCoS1pVRK
hvn4mhWpwv+YFPBlQ4IHlOA9/izZnDnLl96jqndX2WGLEaYRWj3GNJvAnB1PsE5rZo8qRanZY++6
lkXY61oe58qZguXpSqP0tGpwQo8wnv0Oqx42IDiZCqGRQbzZ4BdUrdADVCJQVmKvo9LyfRvM8rLB
wk3CfQvULbKtfxiWDxnyjmAOgDcshtuJ/fXKeolKefm=