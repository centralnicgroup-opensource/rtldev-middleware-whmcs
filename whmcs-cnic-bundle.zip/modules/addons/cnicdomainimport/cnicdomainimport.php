<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxNN27RWS/5v/H+TLUZdl+9tbbfNS/z9buMue2o4njR8xOUbuGKzoJyEAF+RC4VZspF/fK1k
7LpecMWWOsjce00hE0TYXKtkgt2MmpN+EQ6EUden0R456Y9UfzvUGTCO1fDRzv3J+XcQQY3vxVJx
+iLxTTDdt9NXPiDi47nmffeLXbq1pNF0dUvP+EZhBkqEfilhTcMAlO3OYjfunYz6CW8jJvbHHRvs
hdbbry0srbycNNLrvtzRj8v3Us2B+1eQIs/HZD9i0s3r8Bdvcc7vv6pVtoPlzCfrmqM41B3mvOnd
tKSA/oepRTWOdlqRbIFHvb+6ej/vSQyPTM0nYPzbFHynjOiQ6xd4l3AzxZPRt8EexS2uVm53eA8W
BUJehe0KSI7JyD3jHCV1kNYNWNP1kh7vHPUQ1h4IsN5fZTDhk/ud5EKhYCmQOFuP0kuCD4xCRezq
/WaPNcU8/7KYnDfP1RowrkQS9Fb3q2sem/vbPlwCC+vHn140M+QMBnpiQVsQob0Icbb8s4PQvO7/
RkrAvLltLDv+A4yufno0ps54EuHxxBbc2tAJYpe8uc3MyLgxbEbraVE2/wwiRQGABqr5k8uAlbKW
oMdTECwdAV9fqXib5bWuV4hmHclgq/5fOwJSrCI6spirRGMklQQCguf1E7mfrU3vKmgkU8Sa9JCR
SBeNLtaaLu0/nT0TffZfILoQcKQKAiv91XhdDjsRiZ10SR/JMkO5LDv4cz9tRcWd84OcnXtdU7Am
Jl414/lv/LhOCzxF+E5nXqcIMhu+eJvLPSKivgKkLPl0z63q0G2d092RPeZ5QJvY6KtiWO68tEot
pSboSB9klCCuFdHdswPSLtE0XgAS9HiAuJ7Lw41PuBNi/MV0DzMCSxOqJ8B0BJeBHYJyJgedPykg
GwACMkRD54cpg+G8ajZ33xCO69nUOJgrJn6lRCyBL+a2k4uS0czbHglEh9KqQCq0uwD8S1ZBbdI7
ZOfvyZwa0xVm41DkzhbtgrV1cKGx1oCQoUgAPsVxa00pWwSsKkv5bJMsPy0k+6v7qXUPj8dJ4omB
hbKXSAhbWuhuayIOwtdWwNhbACucCDlem0xuLej8eVzqb57frgBhFoVMkp8c3xupew2pm3NltYNc
miZ/FojyIK/TY5aJiylBgFwXwHjGcKQnpWWCn0DjESP4rkcHCiVUyCEywsX70jg3QtUvaxjCLteh
Su3RKqZeqJ2/PXr0VtMFWZq3iQe5gT5lLMV/WZP8kJvRKYbBTvlfM78w0AB5QRxteyidxbwWKsVE
JOz35I1schVqJka5Mu4BvsCS+oU10GYOoziOV8o56WyofvaAe8G1nvz/f0LZjWjtClfQJuiInPKn
sL7YPAPXjbfZie7RrCH/tlwR0eOAaHtEEnsA7gRSV/WxUCmeZEMxdN3wbyGXf07Fmv0LrozHQg8g
qdUq1R9uCfEtJSaMISZPPBsnWCGv38WmKqPqcGbWYrt7/TwI8goGKqj3gHj1Xy+Oy4mby8R038Wx
ge0tASjarpEIJ1HtL6gewyUbaNk+W9CL6nnnrTXgmBWq1khGLLHYurVmdgxf5bsMv2Ncp79S1l68
MOwATvdG7ITvOvAmCfluwzs3IvxfOOc9WQ5EIesmO1A3OR6LCpeXWIy59t4ZqzGRergIC0lrGMQK
4kIW0y/ofh4PdM5dm2FB7U02oLwV8GJP1oykb7utTiPeEbNiby7B78Pj/DqKqNT55rlzcG0EvEEV
RGKnKzZMC0ms5/IfPO4zI8+qTj3I3lhcPle40LX0t24+M1lZzcf47cUewCxX+paV4dEZrRwcJR5R
2+XX0IJjTqbUVuYW87lqfp6dQgboz8r9TRVpri8n4YHWZ1D5bwbLazwL4Aj53JviXgn74B5mHIMy
vrNlV5goJ0BVHBYUDvHdUVQKaR6ExZuGp4hPLfm7EqBTclRaqHrcOqPH777Rv5MShU/x8YgDFOfK
kOCYM4XOPYpGg00KVivH44ssLvhNYjziNSf8KX2UByzBBw8oKol1vBB1bosmnk2k2t/4h+xnWcLs
0Fy6buk7LICK6wsVrDTjYARdaoLytPKEMeHgegV/qMT9telvwHem2ldkmOqF9Qad2/IDTtv7YDb0
CKF2QO3UNQ/DwMyUhqs+aorRtL+KFyH7xXwyCdK8l7WVi/wjFurQ8aK6H0kjXXIJ92xB6obJy5BA
bf7blL/iDw2getSoEaw4KK6vptZxrbZTaR7PWJFpaAJ3QWx3KyXnjl5MwSS0MK7MH3u68NllaNK3
auOXm0x4BTGB9xk0Wrjq069wQ/Lzyl6tcpfUsO0RRbbmfvpQ30+QOlwPDdveQcGceD8hldadIrB9
PNlGMpReFSxbQZyldCkkjvITQXnQZXgROHlOiwCiMU0x4dkxFJyCifTr8msxfUqzk0YaVVZfVxfn
HFKKa0iYw0bWbFTKxuNMjkOav6N3GzjWvKtZzONZEVwlFy5ZgP2wfisKeepbcb4lkPudB950aL97
lO5vSDhVZ6XYfJ4gC1W4qr6czsWYOm/Nf4IfqYn2nB66fleR7Sf1qrpxVu6vmldiJgD7T4bzuEKF
GrJjsxhv2E+Ib3aLzAvHEA9LA0SSJ2Y2cCUOcOLc9xYwOnz8xToiqYV2NTaiymbX1C820ATZhJPV
GZ3clIO3quyjrLwQaAxF/o97uCKFi6u7JAdQ3Fyh3agVRcQi3BIP2Ty7TRhKmULJVa8mVo5h0hJ8
Ze4ihnHP/ikWv2JT33Yr2WR/6hK1WZ9s3RRQD1lSDGj5WB1K6ipQU6BL/Ct2mIrL/pPLQgyUe67W
Ww1qlqCwicr8Grn9DFRhYMUx+3YnOmsBV9o6tEU9ktvGdYPM2IsKFZ2WLXL//0zrygpXO68OuS2+
lj5Ru1/bRYZ07Aw7N2qTGhHPRWHHsZ1yVt07rtuE17QvQZuLKd09ccIClPH07/BcgfhFXZH8AbGV
qF3DEVcqD2dkGg6xTH9W5V7hDBVnJ9ZyzAgU6mv20ALlkgbUrX/wpfM6fBOp8xTmoUIyzwT8Xxtc
O1HiLSr+0bkxUn+uoiFScoBLhBM7vWUhvpkr4ZuK5P2tCmIPlyB1A/yKu2aOHLL7OQEmDl38hHvZ
LA3TmrMiRj+Ywy8PzAYOFNsg97IJwAN7/IlkZ0Zrd11+NIhxqm67AeOzNEaTyjcyGJ443QqtyFax
poN2w5iGK90ApabpAFr0zmp9DavfW9uG6bNDIcJOJMPwdkNbY0mnW51012PiqE/C8zDyPRhcvbFv
eYehLAkzW7LEHCnX1FpjEsK7Aa2PCJGzSwlH6lN1+ZdQp5he9LWZWxp40c7Er/QKmlP/TzIV7ATD
++lXCYcV3VDYl/5j7cn5Lw7QVs0dSmrHDHN6acFMGnmcvR4+x5DsiE+yror7qkAI0AZ4y1Tz6MSv
NTYaBZulCgzAj5WiFIFJbEyxonBO9ldON31G6VqkouNOeT5TXhJAoxCen8HUApvMD8wRj4RGIPEl
PJNp3yEGqLsRZTxzoejoz/kCy5eLYDl0XYvIP0YhePJ16J3ZiF7pY1PKciyLWmkICquATpqGMyF7
Ig5vtlGcpp4hkZRZme88yvI0GIR9boinjIyncm/RmyRKExNVvmHfuovc7e1I/fs1x+ihakGOCVSU
kkqd4j2qiW3MHUBnxR5RSAvD5EshLG8sAjFi3Aed3iXNAK03hFuIPaaWEBKtHH2h68J362CaaIxJ
jtHU1o9HbSu89PkeQhT/Mpqgn9u6/RpvJaPsmIOQFpaaxJZQHKdbZGWq+9VF6EQ8QcS1hcEsO+o8
bqQr0iib0ePvBlIu9MfIah8H2YuUMAElGVoxPzFK626X+l+SQbGmvsr9YeOlRI0/1zLsUPqW50hr
g/j1vvTMM2Jm49o0LTJ6HdGOCEEv4yZSTXo1HXZmqf5eafSPvy2/m5NkWs+Bh1MqOlzYufnLYutB
tO4CKtEXJwlcR2hC8geO/QhXoTng6mPvIyYLIxUiasNSnX0kRspnjV4oX1a8XDmcIAvnOOahuZPp
qM7TesKBgUYtTsr6MG==