<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPscBvt8DNzn5o4DoKSxnbAgmO5PGjIMrPy8iSWSgMP6wKWfqFimlzR047mXhYixeRIaZ3C2A
QzaANdWnbI3D4zt4iUsDsIQGYnQHtykGBAG258OL/6o75OI5CZ321KoakHxpC21sPdvSSO4JCUhC
pRGkYdKJmg4e6SrXuaVYkBEI2/IKmtawSDzIEB2z8hcau4iOPN3KpUj8hoDlKenLz8U7CSWBHb1f
1yV/A4OfA6mzbfq9o1wmO+dQpG7kIhDlXaqPQH0scQ46v4T0wo59k4Zed7BoOl+VzDaABnBsewY8
uMk7KVzufX0hpOBD1NCC6eF0m7Kuqnp9IZsEKn7EtFaEHvUOQZMuGfuaC5DWnROo+BtnPhs5Oj4L
ssby4g4jxgiE9XEEydkHkBwkihhzXNW3UYKujipmOhUsZ90AQGLnwMyvMtKFEhIsEaN4NWT7bStW
QX82Fo9uk1uF7sL2UXIeH0b1CrfGaNATGfzzSVmFlwg2+IreNK9X7NKwaRwDku+2fg9FZkL1riHa
Fy/rZN5R+HhZRb65swXF8WG2lRNtV42Zo85pbtL1Xe6djNBGt6X9vMpPJ0QuNHGxVlkCNihBikXg
C1f8jzt+qhPrOA25ZjEbeX8WxTzU5WFUaaBG5xGDeGHX/+hQJLghrtM01M4D/wzUROuEbrqcT8BU
odcu/LjuM2TbT1XKZPIS/dyksq35w6IwWHSSWR/EbAzA4ZjEjVJnGzhT5ZEoeddhU4rYu4UN/OW1
9TwcRaSgBNHKff0IXuhNaRxPiizggwkri8kMRp3EHBLDeZUHEiE8vs/zB5A56MQEeFw11YDJORTy
kScsbPCtymm76MjKRy3zcCy5wCPQsqcd2WRmYfcB8/kdJawaNEHHZCn0lToAPAmX+3isxDBZyKZm
/vC6/NiJB14InmXLvhLXXHIBDf8XgOznDjF02yv7tsrtv6aUwI9CSDPBeGNliWmJcpRJBOyWKHoJ
KnF7809cz0YAHjokgfrudHGTg5v6i1+xnLHRGCyv5Umj0RxLG5uvfXdT9L3BGRO/xEy9hjmgeWgy
bf9uHKShOezrcNSXSjk46yg6zycwwiyijGdgDVPNQjaNHa4V27/t/1/Wv7ykaOkY+vo2WYzmEEg4
q05oCRevM7LHnEaKBgajQg8mZb5XHfEDCDWrpcwi2w+VttwugVoIMnej82K7kLn9MoCime1Za0OM
Hk2ZPBLhE6JGG2y3/Hzac79ynIm4Q+f4XUzh7U2DPSzvDknRjxf0Az5vpbHckXhzT0fKHRbTEzSO
sfGxEgM3/U05xZxFmYkMXK0OykhgEaIdNI8YRDOQjfg9N9FJJKesKoiCD9c/s1kWRqknYCNUdnas
2sEyj5ql1RKXaDh9/kZTRxLi+2mrNCqwQ1sdCLWofdpGOs2m8InuIdSupvwfCIAeR9M2NT9UodL+
5Oy294ZEL5c6WIEO2WlVhSaFNwrMprGDN9u7bydnwkvQOHppY+CVu7nj7MficNGezOy1QyWZMYb9
BGlAwgcvtC8GaP+J9hiXwZsnqeBQCYtVM92KQrXbrexFQCec0fs9xgK2cqNivmM/XajQoI3ITUk3
ScBrN5TjJH1MuZYbcUhDryvLyLMmOuO7A5yVmXjh3u3DwHT0ugOoBaeiLYkygFY/gNHWwF3hCclX
qDRP6BX7b1ytcN6+XrfMgcCn/q+y/lrTQsqIwLOfWzftdORXKG1m07JVZLSfVuWgf0t9vnfTgD4R
Uf0WogGjr5mRdtwsf7JETXsNOoodUIsBSap4Q4xezeWcARvIfcHMTCHn1mki+lbrnvxtfK/D+rc+
39zPS2oiHIwJq6aH2WvJ4+wjtjzB8Sybns558gtDUhteWLwVcSYEDmvJLGURjNcvzwJuZVg38eQ7
2IK8wQN99i5bLaCJYatmAA6N1rCnFcO3mbIzyEqzOVwPfe7lCGnUgauP5qA0MKDXlj4V9bjsHYbv
ELXfycFtjuxVFOQWnX/7SoSJN4Ij0yF+57pqDa3pZBjgl/cyD0GHuQWicXYCC6//4uDGEUBVl9uq
LIx0+/7LZGFdUovsR+nv3KAEyjahzoSueAI7++yHYeqbecfvGKlpuNbmZGIfN+ZjFbAMMeHuyLcZ
Ugl+oG13mjgfsL4F6c4acMiK1LLnacIBGiqDJ/jI/ukrailZBEXxAM3Oj9Zi3+mNCIQOQtuNidFS
aIc33+VWaAo9XKfyZf70+674bs78IEMoLp8Om/EvhcgDtCw5yqSs9rJW0IGE0bPOPWkYYTDvlm5f
Z/iQTSUPh7Og9BejOs6XGJW8qzDAMGpf0x2hLe74I5aZdbWWXkTLRB5pZrDqZyM3ZqQAtJu87hym
tmROj89F7cm65OEvr+TxTsnfJhnMtyWMUvnIs3WjAawBlERAGabbTRL81h6rQpjEWZ0cJ3GC9+E4
45bfOFmAhn3lowGwijtkamK69T8s8W+I7JJM1+2VANV5kGAsYDzuh2kB6zsxaXVAhcOikM11Xtos
MAZuu9Snlpjl2Mch9tCl6LvI/rzMKTEZOYtk2nd/70l7acmC4Qc+O2o3nggSTdf/P7pVnCIrNGaO
U3Wr+f1eSt5EgFhLwRO7G+W97Zd+ifq2e3/JtMt+gXdwds5LSOx78nnjSZAJKqWk2lzVzLVZyj04
7j0gSQp4Q0ALN/QdW/Xo9R3vABqQnywj+AOH1if8vkJaQzH9EO8oU2sauADiZw5yWRY2gki7/sOW
HvJoN+JDANJdbC6wlnkQi8KTLRdcROA6X4l0uLQ/5V3LUmgpXWUV3sHfMW3e3lgcEqGQ7N60OMdO
gmg4J3jUf2BOjepX0I4Ms827EkCHvo4dTbkiVFJdDF865fcPzhIsD5Y3pHjA9qsw6xfdRcqVSEsg
12Bta11NrYViwFp+CWdSj1eq0bmRVHpYcYxfbz1HFjBKT+9kI1oxF+P2b1kfIuxdckzfSTXpHjM7
faaKkutwVy2EiIpTd1XILR2zf6/bUb6TExQJ7sN7YOcbrxgUXLKqEhtmYJSjJMLJ2mkl6VYzZCT2
mszUVpME5MOtzR0xDzeG1bYYkTna2sitW5F/ZdlBngblQsMuA4PMGxiCCr7xOSXsvXsw053MBStv
NI5BQERYfcXfucKwKJ1u6EsbAXn2QJ+tfKm8+e4+kp26xj7Zg6gDH7n/lfF3ros/GLo2NRN97vOA
3UADv9q1j6spRP3Ddac140pbKzn6IckUYCZcEWuoueYoKjyeYTIlk8hyE0HzPhYc1pkHY+cZkY1i
KKBhgu0vzRcl4UUHbUEK2slygRLgWz2rKzutBXunVnemXQZbuKU29/bmx06Vr4PRZU9hXp3gStnW
tH7ZbzTQMwogzEhapCoisL5OusGr+2W6mS1S8fScKde2tHuNAr7jReD7UmPllVzQylO8+hd5JvDf
7cBEL6EZj5lf3dVI7NcPUlVz2zxyclZ6dlqAJxfdp6UekWS9/MG9XcPSJm/+k7OzpM/YgiJgaxEA
8YGuMm5LUx3apC90oSLc65sxh0QKJrNvpXPtjQFi8YvfigZUTWbVK5ZVn2aKFVDslz5nEhe4rrry
Kkfyt+i2ePEBrjrTNAZFacuJ8Ak9OZLJHasTKCnZZKYFroThxqF5305aHDh/uyqwNCFH3WF3fmoH
89dEDlrM+AB9vCHwFPyiik6Ln2LIsHhLGYajnreDHorPLOOtd5p5wvJaJG6YZrt9CSAlR7qVUXfB
/7iE48GKYtE7XdoMEGtasfhN8hwYj+MoXulZ8mmJjXbq+mwEzbEWdYJFBR4GL9p41OTtB3EMKkDv
Vyj9UwIyl7f4sc/+o93f/qzwGcDbhHkmok4SRBo85ur2tl86w9GkUXPKUz95DOErln9CjNfjAVLO
lsltloNDaCmtFqREyGl9UWU51tYg9q1NaktlSHIDAsN3i5Hf+7NPz4NvL38pmTtTPt7G0cfHA72O
5gwDQn/YaNW+Ncx+bLx8zCPDr0vVOC28jHvWGDGXdePYcACrEwmJ2MRHevfKaVi=