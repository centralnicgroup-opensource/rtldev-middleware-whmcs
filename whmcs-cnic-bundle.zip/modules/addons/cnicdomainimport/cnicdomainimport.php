<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPniUrEI8oopBLTP1ntX9OGhDD6fXBoM/szWmWeyLSkpf+nisnsDdgBY9YLFSPm4nUD2ssa/7
gGczWdRl6AWlAyy9iqloN39VZ419hOTxVHEyTnUUV5dxwpvzaNnu19FbRqo31gz/7j836Cfp9MPw
SbLvGAKk0zNnf1zzSPyJtHH8dYAQbgitSGFJp6co9C/UuPieutAjIokYioqcMPUdJnuaIUgKKnIe
rffnGjV5QlCzNP4I0y1qnqx5mE+GXyjDwVxD/gPw+iLMj5XVjx0+17kMLosPP+Gg/UqzMhh6G6f5
OHIeOW54WbX0t6+fSSjcIrGrC2C/P/F+y/wsPDZHjQzL7iIl4wvZ2o+RL1rG8SJcB2FeL48Lfl7G
qhLV3UU758hw50fS3pVpOhMa7xeH5jRoQMMnRI2PA+4P4JXjhg4wbm+quoi45lfB5YvRyoV5n2ML
fodas8R0afYoR1VdBb1K7eyvuw6etm8r2gZdUUTmwDJmYEb8kNi5/6djvE1ccKqkJVhsUsTl4cZe
osvYpkTOaj77P3Rc6hzRtnhHjDoPR2PEuEBqwxTCfcNh7/DojaPJAMliMTauy6x0baGEvZzqU18b
HOY0kHmWz9DK7830k0Q5mF/RS664xY5JfiTujIa/+YdhfGHzK5OJ/mbxNwJCn52Um2jpHoDQQSzo
34acS/xZaeVnxknU0AWhr7zXlvmh9Vb/HlEJz2d8uciPqMiXj0sHOCYI0W1saZKcRT5PLDdxeMAp
czxBCgG+gYjsRfefbhU4qC9kzRbTuRAY7+qEJr7iZvqvmiEp47f7Db3688/AGNKZlBvNPC9CyXcP
n7fXkKNgm7rlHJGOSKN+4bpSSF+assv5uFNhuTPgc/Zor6/hD7W+R6AhsdmxEK5mzIkx3Pege3xK
gzdqZItez7tPYZ+LFrgfRfNm4e1jTMSOp32l3F+HpSpk8FfOxPWrRtSLgQr/PKOfAV32VNjmURox
LnT/6BlKB27/pYnTTbZxN3OArpwTiJjbKHq43NBRJ1gaJjqE77F3ynHI2vLflLI/wXJy0BIcGIG5
erp+A0JrceyviD4VWl6JK0+duAAZF/uoz0puslLCDLtWVt+cDIfrDsczZYEeqiz2ZDiveMtnQ935
nkw5qLxkgYnWlyRDW98vdtisq7xy+YUxq8VR9UOVI2cNYWAGnvCr7Cqlj7MuE3aXxNZ3NBOOZQC1
nS+pTrdCbu5yK6FxZg1kcOLWeV3KO4HHgPyq+7OmLwVOWMxuTWWXZJqOWRD4+xYgpt8nuTVu2Y0O
va+eOL5NDXp6MWyLeWWaptRe9t+Yjks1stWRQZP18M1UxWpKovyVY1YuI8rYRz4x9i519SV5mzLS
wcPOB0Y07DrGIULAYksO196cBaSIdK5iMmxq92zJAeUEGi/haycKi0nPoCu4Q3usvOI9oPRrxsDE
BD1AQz9fKxyEesRg9F6MkDhon43YbxVqLluqN4hD84PCpyHagOheprKtj2JOX3WA/LLL4K5TbUMk
pqkHMfqxgjwMEe1N3gQ8979nXFoHPS5CWOrLUYmeEkaKPhBkRlnR07C+RDVmoW5ImMYBxnZIMGi1
ar20pQoO4C7X7dc1eXVVB79tmoml2J/eXcrwv/+LnjidXrTiIWfNOYMpVD0TaNTA50jpUoW9JjVM
hbsgBw+7Atj8QgovyTpIh+PP/yfAnO3QNj2xiNmhc46pWnm06PHpxR9A9HWpNQChAYs9jdSpR5O7
xfwPLoruDjzr7ujDlZJGegXeUfL7wDrgXsyb5fDE48ozM7qUZj2z3wzQ8M26x1t4ohdCumOBZZiK
MRCOfBrotOWil7WHGXMD0f0DeL+bD9NqJVHto3ceGjFCiuZGJbZSCp8oDqwdnobmosiEFg+1HN+X
lGl6JgcHsYWX6cPj0OZs0oF0qHxKh7KUtxFNu5Exhq+0a8vAaCjVQ421t43Jcfrvl6dXg35K/DyY
M/GT1UbY3zTfLmMwZ1nMmCLTS8xo8PUONq3EfGqqNVbsIZYSdUIwVFySLdB9o2XRTiUb0Tp3sAqf
Miaa9hE416EG1RPylbTVDZW6Bi55Ywam2X3RMOWmuEYWQ4HNGy8cq2+0/OjoYzxjyH5n+e4fFZbb
v0kQVvFlsby2dg0YE4YOJrZSYa35afDtAeZLHe8tuAnojzm0NmtAeldjB9sjtIIjOSNnXEmdtsoD
W4GPNiLYTCa6o6aILeMGpaQvhmXMbfpcwE0Gl+ekCumxl9QF0kNZFWZOuV7quTsOynd9c1QcrkZg
t1wj9O+HP/lKZ10zlSA7Seq7wYstb8vuVUsdPECvumvtofTQGoR/6JN4zhSlXe1k88CgJHnqgAEW
/fodXBMhQyslwqXYR55llC9AMckr2AsO3FmvMLA5QbiGkgooIJP+CgtbAcCMD8C8v0hhc89PY8/1
kP4LuATZ8zG4tbz2sitE7qr4E9zV60r07A/Z++Mbh1kxPnpcXFqdFZGnX8Z9HJq8Qi82a2Uw2nhw
VAYfKNDFVWJ2GWKET3NxrDgTj1e7BGhgb/MVQOihZ2W1R8CIY96ztkyeeetcoBFIJBwDg3hJ1dA3
Wt35l90wEKJS12FwqUAwpzowvI79R83a4At9qpx+leO6XLiHOAc41N38Yw7UcZzt7IZ/PAcZclow
6cwp9XfCdbh19KWe7VbL9a6t/zKBa7QNZkSn6CrZWLnoYR1nGQf61IcN3ZWU1/JH01UCwbu2Ef41
8XbnuAWbcR5LrOBWSSnN+uHCFb+N8EpGld4/tRLhvem8c/A1Y4RSgY7qDu6ZElRBhe6nMy08Znjd
ftqGMI4Jna0o+5OwWMbONhRJPEFJsH66gsRYlCVBjQrd1SsVh2vaXf4mq2sPeWHBT+jnZ5SqoiTu
PXgHEePGpt+JxdixVopLOqnSsC+xVJ2+/xsrKXz5ml4c1UDb295BZ84Az3uwIX4apcEgELdwc6Yx
NxS10wdhEHFdx5ItI7uv2n24AX9o3XQ4TZPn+Z0QOqTLBkLWkwWIIwMQyzGpxGpng6WX9zak0iUK
dIWDjiz6fiVFmrBLDXL8wYt5Tgq14YEPdVA479UDFMlAdH0hT2J//ARWbKXuk8bwoyrII55kI5AK
zqKNs8+5f750RRNvnB866L0CMFNiRpE/JZq3ejQjzvFh9FEzWPi2LKwTdDFS07maQ7k5/I51qKj9
byFV+BMixsPyfN4rml7rh5lE/Ymv+7CMLYv4o5I2ecADLFXcNTp9Q3XbzBZu858a1pZDZvw3OVru
rAPMnWjEfPdLuucJDDa11Q94SUG8b7Qr/nPsIbUfg92uERh3nz32f8+DclnC+1s+M4Udrkz7NTFl
xwUs5fwXZelI4pG4ByJN6hL7iqI8IDUJYEZeQ0qFCDkWuiR4HFUWbFfRd0qOtw5HuyhvQTjOxH8C
ptY4IIDDLXIewgd52c7z6iZlEVU+SH5GI7q/bfPF3kfiJ0+kDpks7lrsNulkcoATCQ0i2P6ytDK3
niXphr3Oe/r5+AUd0um94v1I2I+85Hb2yKkFCm6QW76Ae9YK1KJ+GEWcYq92MADltUlTdLRn9jlH
w0GVTXuEsZbMfKA1FHg733uJB00aHpOsaWPbumem2V9m6C83ojLQnQH543gRL42k6UTeFUuewXhL
tSRYAQexIYiCyNW6V4uYEtlSgkQ7+vVhL14Z0ivJBRGMGr/ILQDCxd14gVjF+bmZuRCPVFSAtlLH
vPlMYIZ7vGhaMXXZcdalgiYHsRB51MAMwZPDI43gmfqBXAzMeg0f6q212GYMgsVurOxPwK/gqnGh
1NKX8ySuwdRKB8dZOf++ATfimFStRhi6Ygghpd4hZRqtpQiNlepfP+v2jHfyeAXTcaCgFzxh2vHw
hxb9ud+wRM143dRJMWhtnlaSu+jvJpYNTzKDJaCiqkNNEGFE+B6qQnSGSj1Ao18XmW+y7vYGnmz2
ve581s/wGFa3i5omEI6190zudNph31ybokgmBbvBVaKfrbDbxc6zzetHf251hBz3GoqoDAPCSHRF
R2IsCMUq0G==