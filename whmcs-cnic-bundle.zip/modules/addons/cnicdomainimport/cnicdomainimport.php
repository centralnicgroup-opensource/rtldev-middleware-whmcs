<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/XyzSJCwythYRTWvxIFu+5xes5eAwbBZV1zZG8/EFxYxDOJPAYhFsAoaoEGUhkHXPmalCa/
YiaNVeNTGAJYhyGVjkFtivX6N8pLxhMxxtCYxs0T15getIfr/5O4kS2eZBns5ks3a48siFaPHnFM
78g6OUigfwl2320Vn+DYxtQ+AIIvmhw+hAP6CoOTyxq4pdORMi7HlpA3EZh4Q6upnsLq4CnjSrRz
8nfSvsluhuD4MG8ez+HF3fq7erHJoqZYWtMjQ5vFMPjqCGkUvHnKLh5W6R5uRIPVRoSfygeoML4M
bys7GlyXWgXQ05dJDY4FeAuAdgQaLFw1sqeGmTmGtAPKNjt8Rzcp7QC11uMQBC0eSJSG/4B8KxvX
CKY43PHE944rtpBqGLD1dLtDzONrpLK+6K6N52Ecn1vhz5ZwH/IDicRj6ZMvABYkIwCir8b2mhbr
eDavEIaevcEtrpISj6hX69OIY+nq6MCrdJKaQkVILCEIl3vUS92NJrWJDF8kdCBIwqXK0hEuisox
9i9CJuXdOoMwH8oNB2zthoCfvvj4qkV0wE4URRu9Rd70shvvv3Skpip7M58j17Qe8jG2tCE7J4na
rqXhw5PxSCOdtwRZHurp/Pq8zDEBMZJ1zaog+Q7Q1iSL0JwLt1kZLs8aizfQcFGApfqZf3kvRbVB
SgOR7/zuavDQL7uVGR+A8zkUswp6ZBjvgoTQ0Dc3EHj4u3cbuac+LWMt2caMhI/wT95McJ2kyztG
jAyOVd7i0ln7x+GCx0VEcKVB+KJl9jsd4xMCx8g59DUv6wHYHmc6PRgjs6zWZ/RtP28DBXRqhwqh
lZexoBTSA5t0chcbeYeb2Wz6ZCT3Tep4/UQ0yRzH5PlyIb8GNBbUiUOKEEERXGhucyrVktgxmKLJ
7duCtyZ6UGteAhniuI40n8DuFM6xbOgrHAKZoPV5jeuMZgGm8Gjdhu/+7ESfsg/yx5dfAT+vTFh4
BClbYlWd1h/weCuFbpOWm5Bhn7YdfLTnPFenWvL+XvlZO8MA58hdAFIxVkCO2JYMuY2RL6u+v3Ft
WzQKj1xVsKpQEKAYG4DebPDW6mPYXtAwb9Duu8eBOBLqu/ziuf3xGn1nLP9kp1oqReUvTmV9tt5j
O9q1mXknNsuOq+at8XoLHHuagavaPXObk9Rgbfgd6KOLBBNZeLGV/DceSY0QNvQFPTOTpHlKpdwF
VS2X3R8S7UIjl1X4fvRGs++ojf6dTYJXbQ4VFGxWzcwZYuM0zp52z2sGUz5/nRBSz/2AZ+9Abvdc
59WmwhdCJsh60jNPbV3SvrsqKWgavlwzx3yomtIvVAwZvuy6pCSAs9QGOnraryFRRhzVjzhW4EBp
C9QZZRL/blAEYqBTMF2gc/isIc0HUZN3JZ7XrU38vsP0JMlDp0wuzfjamj3oQau+Am58ZBWByzeA
4LPPJoHVjJt0Aq1sULk9MMv3MpksEDv1ap+zbz+hv5D80Bg8kHU98H80Via6hczqKoUM8nbKz93Q
/1LJvMioBMfg40IUaYf0K87lXNzGOY89XoAbYqDaAAYr65YRqtBY1SAlpiW9Iu2U72kFoyk1Iq65
82Osu9TU3P22aHy4e8wrFJ/zV7/ehkzU//ftgrwhEU2HGREy0wdKIyRgfVpaj5LDBtPDggNQeYDX
AZ6q//yetdmiiUhbucflfB+PEgDhc+zS/o4d0PETlxqUiBgftqrRhhi1wmqLVtRTLCM2A1TajHBM
WPMVjarILTZhgu6XWquz0jldULaCs02I3GnvdfWkhyQJFL1ZVZS+CPTMSZEJVLPPTh8tHwbWCupl
mGFCNAWHqY88sxEHFoGjlFBzwJ84vSz56Un3DzwNqBRLjLUDIJ7smrE4tRhbHXmFbr0Xy+ZJQDWf
AgMprDjyHeUdQkoHMlNhns5HETBE94tQtKQd65e3X82iPgEKc99VDlc8oShlk8vDETQOlVX3a1qC
crbRBIHo5MaENUM6HOMoQMHU9+Bco2HNqS61shNoAOsagL0hY5gl1g2oYwC0lqdM3Nogiap/9INX
VqXtKFMH6noWQFfms9C7qKJe91h2DLLwzVkRXJL5Vp/ZrKoL53c5qEjUMam9sb5cGqH3T6QA07GE
WmFgiS3vm2ytX00BsP8w1xo9NGSi4rNrMWEpfYvhiZ/P2AgBVddpXwz/602YtyOhpTpwQGfEA1ZM
g0s8UUWXiNv5ZQX8o8R/kYzAZ4AuSxSeTrd2ULHRnnzI7reIQ+MRlGvT9feQAH++07CleCC7yBAw
cuHpvmF6n8501JZv6G5z/isAzTQ4kJfIqK0iM/a++ui5EE3O/JIkznuTYGmQiiGT9mYxlLU2iYM6
oGr/beBeEOlqxAKmUtvKtMPhiZGYGXtOBZUGQxljimedanGzrd6V8nkM6PHpD+3KmSv6/7030MXd
I2znbCyYk2pQQIODQntFREJ2b4h5A+rVZgDYnneFTMaGfm8Re8VvbS/Uq6tqwZXAYhAOqTD5Zp6B
uPkiAFFqjHrn9ubEu35YZwUlxyu+aa6FJ3GrwSiXCmHYSDpgFmVteVzLWUx0fYWtsRFxdLpotL3n
dLXzhdROeH1RJtoqc8MtgYmT5quVX9/Ta4ZsLh842OBii4X3koyjPuF9PCAMA3xM5698+pqOp/qX
5W8aqS0G3IESm5KZgqJR4Tb0rUaRUHFVwbOK/d1BSmdBwDCOWu/TfY164vrkojuScdXBWqom9Ube
6Tq7Q+5mYe5m51oC0wf/WihLs50QOp1Ta968iMhb8mkaWEvF0SrjmiThglBFBl7rjFkdK/guBJMt
EVmrFVyuWhbw0R3+IzQrB/GtUYnBxMCNd/HzdcAUrAShge6octa19GhkqhmKpNMjqtKcw2qI0Vtb
ejC2ADgwWM2xUg/GiHMqBm7Efp5MAp1jyEKfqJHvrlM9BdS8PXrsbx+XWRSKcBsTcX5r5gg32U8G
5yhmyefx1rV6gv9E4FwC81tfsX2ujm22uBNH3CN6kHna36TpNN+MqcxaO9JVOvXzJB8kbjOAHN06
EBeUAXtFG8gTc4qIlOzzDFYVaJSOSi3WqkbSp9f9a6Q7lIiRHCE3bcY8H5jS69wJ6ZOWVVqY/I8H
oC2sM+VZDDrCR7yAfqVPjfXvlIVNPQC4TXxJ2cK8465tEC+h1CXlsCBTuyr2GHGhj1A/wGb4TPis
+3FNAysWZGD1wfF8Ilrrli9w/Gg2FytULgQmWnSuMGaG1nLsFmeSBXw2RVe0pSUBRPw5dAn+XaGe
T/xbF+TY7Gi8CGcU0yaroTCPHFTUZVtcrOSHNwDttxIpJ7awbeh3GUPxbW6MlbHyTAXDgAJRoSIP
U5KtjAcgyVEwTY4xzDh0DWeM/C2tNmX9SdQNB9ZvA3rhBb/gDL5ZNcOF4/PGBJSLNfRqSjlZDZZD
1tQ7ZFIj1/zpQADBqTDf2QXxXkDoNUyHJOvz7JqcVFxcKFsdhnN7FzioLyJCUqTF4QWpVrl0eyxU
EpVPQ4DQ/HXDsUz6fKhX4vAPwCFyBnsbyZI4FLQS3ttxjwHaWTeepFOqsIpHBWXNxa0aoNf8Ywxi
5tfKv86wCGvmwaXdCm/XR+4jEdxh3tV+vmMXxNTfthWEaVupKNI6ZIS5xRYcckJjgCFrx0xkrsxP
1v6AwxmcKedK6Wqn3Pgw2HXv/JDmLNUgkFQl5Mzwkhs0jyIqbfeVRt4wT+UHH8itKDs4rF+bUwUY
pnDpfLsJZ3yAZtf2mMMA2BCHKk9gd7ohma8w/BOu/gCXHwX//sHGU+KIaCAWh8NukIzZl5zR07F7
zsKlBFrulOu3jb0G0v3rUnZC9RSOFM7lf++eT65WbXQvLBlGsWH8bImIMgGsoaK3IXm6X4RQ8p/r
+iAIWQDHwpZ1a+YzzaI9ZlvYYYjUHVm+yh+/PaBBdpXrhmOw9x/RnvHAbdTh8S7EvOME8u437qDv
RSfFt25ilx/jjHCEXfCrDit2hXnRdZ8449WM1iL01/4BjfeI1br7CntOCLFQ9Xf5QRnUQvS+eKVa
26snv6eDNdS7R+EAao67KtybQrOdUo9Bd6NckQpFRPDB/PsRJFVq7o7j777h7EWAgk/T5NqVytcO
RDxnXr6T6KqeEfYZqCx3df0cAsDTPwyps7r/Rx4VuORNISs+RyL6Tg7xTrSwGPCgierXNXTCrQI/
0RuNug72xl1S2HT51gea+GYs/fv8IhuGNAsivCEpxQpzNQTSmW6ypeJu15ZUO9FIQpGrkywfDqd7
65fPM5NFTDpgoLx82f4RUTPn6z6awuEPGOf/lvZwSBg/5gh+Zi0C3rYV+egNQ7YdQYj3sRTYnWUe
k7Z0+imAmVl0OVG0m2nmqVc8q/bBuJNf9Lk+zfPmiJ1aatW01mNLm+22+n2RSuY+kmpUadjEK/ud
3nreyzhKZ/CsSZsoumYdbGgcgaNh5CQ8BJewONWOEKcAnyQ9tI3aFmn/L1F5KIKrRhmg0hTWOEm5
9EM/iz44bD8KqnKNhP9WsnksV7e+er69Zy7710Q3olgIWNGDFq1qL4vm5qQ2nd6PT0j2osQpFQx0
aUxcxxrRNJFFtlpJAwkKkBZsIyx7ihspW9ravMn1qOn+LiDnxtHPOdBArackfEs1Mq9be6wVw+eV
Skw2JdakYj5+UCRiyLm3scRuBHPr0RSJodVk7/X2rEdfWjNUgsJoebjwahzkGDyFdtTQKhjtd/CC
8GZP9drJB96WaWsn/UGu2B4aVywVaMJdZjY92EAh3QyjJC4KUBL5CB2Xx7ioOGTZPtcKI5aNxD9T
C8GxyB62tAh+RL8Qx26S7dT3JcTlqTMJ205vIL9Nj4ZJYaypeaMu1FJ6xfmwu0s3p4RrwOFsi+Bj
+8HlFRnAsPCCKRccRUfdmIZZrdrrpUlSyFjLqqMEbcI+Obmh4+Hb/aBtGWBbrQKGUWsnoy4svxob
RYjlRPHU0z9HvPmOQAhyvR1QvTEyy0GJ9tVwm9TXXY5QGh1Drdt2FzG9v8aqa/YCkiIar9cG8/M0
WO2KkswaTdj1tg4sZzrQVVEbtVSJPbpJTVB+CuHnl1ZGnhDzld6bVIruPDgB1KtDz+Iq4AqBe6pp
ASsee1iE+ka=