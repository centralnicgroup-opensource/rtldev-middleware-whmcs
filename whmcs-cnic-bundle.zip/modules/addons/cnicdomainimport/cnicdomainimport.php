<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvo54s8oGUXLoqs6GJAGnLikpxfvzh+p/Uco3a0lwaWuVp+rb++0ob9A8PgyD14OBRK/aEAV
3oPqK9EgkurTTphI7WE6dFNf6ElebD29Vwd8vKFlGYx27/F/A+ZwGiL2KWgVxKRwlCr9C3q5q2EK
3b3lcPT8qyU4crqI3dzQCn+XvoNbv7s5iEuO9pyCA8i7/hSqaicPYcQuf1AdoRcStPaKoNJztMnf
2nS+dnvzae1O5p3gTtwJ6NQQdfnWnkLfAIVA45jjQx9jvyVm+wC5jTiNvpO9QfV5Sl7QbVCDjjLv
3KMeEVyCIHAwzCbCzFWwPbPOmS2yT47/efykirKaRRMuJlCGMSzPGF3iK6XrzHqqaDS2HeyGIw9A
lv5G/1US94XKBxSLZZlKcGDrbwAREhMDm/hmuJJhM1dlnGCSLg/nzekrk/qwzk6xAYF+wpUEO1Ux
wqK+IDVTzSLoQ08wfO7hAyVZV4/DKZwT3MreMBLgQnMYNZhekiHBQcPvx5vleHJghYj3lMUYnCAn
IchFpQVNfO5pm+ERdn444QqPOtTQ7fMo8r/kedUDUD12a0aBflw17KPU4mfLl8lRxm7iIhj4Q8uH
mI03xTYjyHuBYlZnnx6xtJXCAL1zu5LE0O4qsZGeFnLp6ixObXxXdKVFlFREXlFgiRAOD5F24TAz
wM/yanLZv52Ai0izERnzxc4Z8q/We6c6CMTyvvq2X8xSJTf0CpghoQfeXH1sriXP/LXwrPifLSM0
vQ6hjcFrFPVAQycxftOJ59SNtY9ucze2KWMHPk9zAGbcYU7PdpRX61cudv+IHEqo31NAIitdqPqu
eMTXxbIep2LtTVUEmDBXmK0KhEi65IwVyu/6hD+THBCOWLjlWnGL8H21zargy55E66Ck3hE4Y8Dg
xD7BDmStTrI4Z4LYZG/L/qQY9FZgcXZydo83VmaQEsCY5D+CfbkO7Xg9zKBD5BSFwEVmlQwnlsC2
21hd5vEIKtJ/KQBC4AgKiKCuFOd+od5xL9rHpvi1MiA+Ql5h7uyxUIK1SUM4v6CIsuB5JcnGRN3V
V/OGdvGjzOno08/W6h01YUTrA3hvsAOQz0pCJGfBl1Qcael/UyyCMoizK061WaC37kD7nXa27C+k
7qx5IGXiU1lYTBi3sN0poQs+uqb9WXvJTjlzHZ9meRyH7ejA17WV8RbypjSaIwC0jRK28CF8pOU8
J+4P2ltn97m3kL0wdotqNb74cuJwS1hGBwl5bl+A2BLdnK5XoNTpWeSVTZM9NMN5ssaWPzYEy7wo
NfcwIseJphCm00Sn+7M1fZ6+h2VJPX7CyfUeVbwOP8Tr3Mx34Yf/H4l+MzahqKZr2Sz8NgygMa86
VobHs0lG9KDBc8gH6HmC+sh9fIOIX2YI7cSu0aLI358+cEeZub02SXw4wBZT4HqY0yjLRn7C1zHi
FpPPdi47UTqJY1CVCcUs6kCkAPx/T7xqDO27upfNe2WIVfbxLChuvWIOTHTOD8DUOucYGr4IAlfU
O3crGua7hxaK8ZXyoVDH/a//JMfQhKOYjNFsA+DVL3+2xkC5dQlU1+cbLMzHeywLRU/CNnClBACF
zamRcfKzGombCqqFRkg4l2sLfNAGKfqOAHJLR/WszycbFNF9Q6IJZnQcO/tQ5/e5K+76Ebkuxr13
nIDWIcqBm+zwtBbMUpNbgPrs14vEPBoMLd4cFd5JexywbWsvayOIcgOFT1l6rfU11Gj63z4zHTTL
v7jp8/lnMY6HyYNJcyf/QfAzMxvYumy2c0JEv97kolcZa9pDLZffmX1tno2by0f+rmXeQ27kdLgv
NAHhqOJpFs9LknkVB5oUWAdIwDRul9b8dZ69A1LuLoanSjnqabCNoJCBtuT6KDEn8//sVnJeG9vS
vSh6xwpoQfVM3/8Dk6Zz0QBxzorzYYHsdWqpNKNu7Ak8P44t6CfSsjDDYsrqLi51rCh10Pkglbqs
939sO0FH6/HhvsShzeB1GBD/3O3wNTQQhDkrYdSMkl8zRnT2UWhUO766Yd9MWxbozp996Myh82by
XgHQdEdF61sybgQAG18iW1bhIhEZD6dFVjvzm7B3qAhmLscWSVGRjeyWEjFDcFFnYNGkxnAFIT1U
R2gd2K7EtTefw36wOMbQwJSaHe8c512f4rwxC5umVCmPL7nC5nbSs98C0P/qKnfO9Fa+hH2k5+w+
KLeRAV2DO0Nxp5mH5EqV5hccaVAy5ydmqpEIyHdj31yfp9HzpbXQD1Tpj2cuEDqOWYULM72Jkuo9
8QDX/VdTQGhj7ti7LCxpRDdr3yOXrudUcRbk++nBWfpN29+/ZR0+Ip08Qt08I/FMp2UyoWwRKjO9
NOU/5qDtd5ulQU+I2DzNVdjIYp7c4htjP6KFQF/aIyXEa+BgVPOCLbQLwbrlA/ByIaLQof2+Rqby
7+KIPn5OsnWPseF/Pi2YPQpYot8nA9TZysfDpPUX0BfE99a/SUWoBPIurxPSCNmnesdkjWtZe1Ew
cdvchnAROZQTBGaYwnGiV2feuVrlj0LIC2i5BvmVthvp82jJBrZKsb4zeRl2FJTU+O1xBbT/Z2ux
ol1t5sSzJLP45VJZSdcWsg2ybRpizvaGdgIWSH3/j7vow0h1+Dc+Z0FXjDiirAP2Mz3BJHhBn1OY
1E78g+B2R0hut8Mm6LgIB1ZIUZQHJAs4a/k7sC0I8wwiShKs8Hk20OW4uGpmWD4HDvDmJAJUu+K8
/ujLaAE0GsqSn5dQ9BLgFRY5ShDyx/lfuxgZtFnfrkoVk568drHYSupax+7hRVfDseSkTIrji6tK
jK+Qc7A58WE/kj92y5y/Rpr04h6jyy//Lyex0anT8JjM1pDLDFu89vpIt0igng9z0CDQw47Czw65
Lyq5SNJ2AghsEGuigs4I5OQ/gu07SwJgkUyDRGoD86s1e3k/tAw4iBFC6689VZ6SxP6uUhaR4TnL
AV/i9J8aFbz/T2fm9AQV88zNZufagaA/GnzDpky7mK9H4ZNqNE1gB/36HAFrxh7OY5NYb0kZriVr
U6pHjUV9/g3+1LTcoSWQqvkAYUJNlDfNGEGlsnp/pdQUqQ38Jp23g8/W/YRtuiaIRganFJkENPnP
AAU2AkCWzN0LAeHD163kZydL5/Mv2n0DY0IjcuIy+GJemamn1T61MRTbKz1e5EXr+4RLJSahAqVC
z+3ufXkb8TBVBUeSKQEJL4oOpTS4tzvkJ/cKAqONxVhVlDG28B/ZmdPSg1o59u/TO+AUQ//k1DNC
MP6kJW6IfNaZthDprD97V3FQDK/FU//XTzUrarieJ2zyUwptA2AfIWLWo4GlcMXsC/vZalHjbmod
paKQignPQm+1K54RJ1UV7su6hUJbAgmYAGEO4IvScGy6vlQuhq4+d2/i+mmfxjTgWf0SGDHG6SE0
Ao0Kt2KITIY596nbZsuAyOhCWKJxGeAr5LWZyze8aTyV7uig1COjvb/NzWAQmJTuGkI921sOl0dc
xKqtxkcmZrg56kNoqeNSCHlNZnVzoZl+3sGqaCEBG0xZNSq5x5zAp0oH6TRyWaE/ZHCi5ymLtf/6
mYIOqguVbPEhwLbDG5B50BGIB2HPHaqPtY4CVRu0nUJA5WUYCIjSlOq/p4e2aC6VRZudYLKEoOYB
XQXaVbVnFikvQ4FjtGCZRnm6GrwZVR5vKNBDxUumd+gIXbWIk1CsPDm/LqOFZ7ylDSa7k9IbR/HS
0Bl9kWouIkA4Z50Nbztp7l0hGwISipMtxiBCNEON/ZM3UubFkgzkROCxDIzvJ5fmU0wDy4kF9GI3
KGjDJDgubo4O8s+bt7ZGFlCHhtLJw4KOwjIJxbO1HQluYm1mEfEuYZ8PqGWB4ODO71EowhlkwhkB
bHPKiBkzYtCzrqWsnw0XIctf3flGe/esqQc057RX0LixPtn7mW4aM/xPdknZ6LiEbnIh5yY8waEB
kGCS7/RtU/3k2W6tu8YSnt92TFRfRQlsSd08mVJsptISX93thJE+xAgtv4mNrMpHlxUEnA8hLlb8
