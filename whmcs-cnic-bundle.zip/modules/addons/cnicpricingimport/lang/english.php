<?php

// CNIC SSL Addon Language File - English

$_ADDONLANG = [
    'roundAllCurrencies' => "Apply rounding to all currencies",
    'roundAllCurrenciesDescription' => "Also round the converted prices",
    'products' => "products",
    'certificate' => "SSL Certificate",
    'autoRegistration' => "Auto-registration enabled",
    'productDescriptions' => "Generate product descriptions",
    'productDescriptionsDescription' => "With provider logos and feature highlights",
    'productGroups' => "Generate product groups",
    'productGroupsDescription' => "One product group per vendor with common features",
    'productGroup' => "Generate product group",
    'productGroupDescription' => "Generate a new product group to assign the products to",
    'setAutoRegistrarDescription' => "Enable auto-register upon payment for synced certificates",
    'setAutoActivate' => "Automatic Activation",
    'setAutoActivateDescription' => "Enable auto-activate upon payment for synced products",
    'base' => "Base",
    'crossSell' => 'Cross-sell',
    'crossSellDescription' => 'Automatically configure cross sell options for products in the selected categories',
    'hostingRegion' => 'Default Region',
    'hostingRegionDescription' => 'Specify the preferred datacenter',
];
