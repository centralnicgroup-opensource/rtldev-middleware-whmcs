<?php

// CNIC SSL Addon Language File - German

$_ADDONLANG = [
    'roundAllCurrencies' => "Alle Währungen runden",
    'roundAllCurrenciesDescription' => "Umgerechnete Preise ebenfalls runden",
    'products' => "Produkte",
    'certificate' => "SSL-Zertifikat",
    'autoRegistration' => "Auto-Registrierung aktiviert",
    'productDescriptions' => "Produktbeschreibungen generieren",
    'productDescriptionsDescription' => "Mit Provider-Logos und Feature-Highlights",
    'productGroups' => "Produktgruppen generieren",
    'productGroupsDescription' => "Eine Produktgruppe pro Hersteller mit gemeinsamen Features",
    'productGroup' => "Produktgruppe",
    'productGroupDescription' => "Wähle eine Produktgruppe fuer die Produktzuweisung",
    'generateProductGroup' => "Generiere neue Produktgruppe",
    'setAutoRegistrarDescription' => "Automatische Registrierung bei Bezahlung",
    'setAutoActivate' => "Automatische Aktivierung",
    'setAutoActivateDescription' => "Automatische Aktivierung bei Bezahlung",
    'base' => "Basis",
    'crossSell' => 'Cross-Sell',
    'crossSellDescription' => 'Konfiguriere automatisch Cross-Sells für Produkte in den ausgewählten Kategorien',
    'hostingRegion' => 'Standard-Region',
    'hostingRegionDescription' => 'Das bevorzugte Rechenzentrum wählen',
    'monthlyPricing' => "Monatliche Preise generieren",
    'monthlyPricingDescription' => "Wenn das inaktiv ist, werden lediglich jährliche Preise generiert",
];
