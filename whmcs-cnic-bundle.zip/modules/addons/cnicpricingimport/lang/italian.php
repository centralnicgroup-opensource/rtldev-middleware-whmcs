<?php

// CNIC SSL Addon Language File - Italian

$_ADDONLANG = [
    'roundAllCurrencies' => "Arrotonda tutte le valute",
    'roundAllCurrenciesDescription' => "Arrotonda i prezzi convertiti",
    'products' => "prodotti",
    'certificate' => "Certificato SSL",
    'autoRegistration' => "Registrazione automatica attivata",
    'productDescriptions' => "Genera descrizioni",
    'productDescriptionsDescription' => "Con logo dei provider e feature highlights",
    'productGroups' => "Genera gruppi prodotti",
    'productGroupsDescription' => "Un gruppo per ogni marca, con features comuni",
    'productGroup' => "Genera gruppo prodotti",
    'productGroupDescription' => "Genera un gruppo prodotti al quale assegnare i nuovi prodotti",
    'setAutoRegistrarDescription' => "Registrazione automatica a pagamento effettuato",
    'setAutoActivate' => "Attivazione automatica",
    'setAutoActivateDescription' => "Attivazione automatica a pagamento effettuato",
    'base' => "Base",
    'crossSell' => 'Cross-sell',
    'crossSellDescription' => 'Configura automaticamente i cross-sell per i prodotti nelle categorie selezionate',
    'hostingRegion' => 'Regione',
    'hostingRegionDescription' => 'Specifica il data center',
    'monthlyPricing' => "Genera prezzi mensili",
    'monthlyPricingDescription' => "Disattivando questa opzione verranno generati unicamente prezzi annuali",
];
