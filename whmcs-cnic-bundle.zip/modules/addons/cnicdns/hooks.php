<?php

/**
 * CentralNic Reseller DNS Addon for WHMCS
 *
 * DNS management using WHMCS & CentralNic Reseller
 *
 * For more information, please refer to the online documentation.
 * @see https://centralnicgroup-public.github.io/rtldev-middleware-documentation/
 * @noinspection PhpUnused
 */

require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]));

use CNIC\WHMCS\DNS\DNSHelper;
use CNIC\WHMCS\DNS\Product;
use CNIC\WHMCS\DNS\Template;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

add_hook("AfterRegistrarRegistration", 1, 'cnicdns_apply');

/**
 * @param array<string, mixed> $vars
 */
function cnicdns_apply(array $vars): void
{
    if (isset($vars['functionSuccessful']) && $vars['functionSuccessful'] === false) {
        return;
    }
    if ($vars['dnsmanagement'] === false) {
        return;
    }
    $registrar = DNSHelper::getDomainRegistrar($vars['params']['domainid']);
    if (!in_array($registrar, ['ispapi', 'cnic'])) {
        return;
    }

    $domainName = "{$vars['params']['sld']}.{$vars['params']['tld']}";
    $template = Template::getForDomain($domainName);
    if ($template === null) {
        localAPI('LogActivity', ['description' => "[DNS] INFO: no matching template for domain"]);
        return;
    }
    $enforceNameservers = \WHMCS\Database\Capsule::table('tbladdonmodules')
        ->where('module', 'cnicdns')
        ->where('setting', 'EnforceNameservers')
        ->value('value');
    Template::apply($template->id, $domainName, $enforceNameservers === 'on');
}

add_hook('ProductDelete', 1, function ($vars) {
    Product::delete($vars["pid"]);
});
