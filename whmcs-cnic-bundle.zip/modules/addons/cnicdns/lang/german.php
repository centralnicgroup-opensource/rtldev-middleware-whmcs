<?php

// CentralNic DNS Addon Language File - Deutsch

$_ADDONLANG = [
    'bulkApply' => "DNS Vorlage anwenden",
    'bulkErrors' => "Im Fehlerfall bitte das WHMCS Activity Log prüfen",
    'bulkInfo' => "Nur aktive Domains mit eingeschaltetem DNS-Management und auf von CentralNic unterstützten Registrar-Modulen werden hier angezeigt.<br>Einfach eine beliebige Anzahl von Domains auswählen und anschließend auf Anwenden klicken, um fortzufahren.",
    'bulkLog' => "DNS Vorlage wird angewendet auf",
    'deleteConfirm' => "Möchten Sie diese Zonenvorlage wirklich löschen?",
    'description' => "DNS-Vorlagen für Ihre Domains konfigurieren",
    'errorRegistrar' => "Kein kompatibles Registrar-Modul aktiv. Kompatible Module sind: CentralNic Reseller.",
    'errorRender' => "Vorlage kann nicht ausgegeben werden",
    'example' => "Beispiel",
    'instructions' => "Anleitung",
    'instructions1' => "Schreiben Sie einen Record pro Zeile in diesem Format",
    'instructions2' => "&lt;Hostname&gt; &lt;Typ&gt; &lt;Adresse&gt; (&lt;Priorität&gt;)",
    'instructions3' => "Typ sollte einer der folgenden sein",
    'instructions4' => "Sie können '@' zur Verwendung des Domainnamens verwenden",
    'instructions5' => "Sie können '%ip%' verwenden, um die IP des Servers zuzuweisen",
    'instructions6' => "Priorität ist nur für MX-Records erforderlich",
'instructions7' => "<b>NS-Einträge unterstützen jetzt optionale TTL- und IN-Felder:</b><br /><code>&lt;hostname&gt; [TTL] [IN] NS &lt;address&gt;</code>",
    'setDefaultGlobal' => "Als globalen Standard festlegen",
    'setDefaultProducts' => "Als Standard für die folgenden Produkte festlegen",
    'template' => "DNS-Zonenvorlage",
    'zone' => "Zone",
];
