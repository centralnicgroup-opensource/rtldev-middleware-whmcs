<?php

// CentralNic DNS Addon Language File - English

$_ADDONLANG = [
    'bulkApply' => "Bulk apply DNS template",
    'bulkErrors' => "In case of errors, please check the WHMCS Activity Log",
    'bulkInfo' => "Only active domains with enabled DNS management and on CentralNic supported registrar modules are shown here.<br>You can select any domains you want to apply a template to and proceed by clicking on Apply.",
    'bulkLog' => "Applying DNS template to",
    'deleteConfirm' => "Are you sure you want to delete this zone template?",
    'description' => "Configure DNS templates for your domains",
    'errorRegistrar' => "No compatible registrar module is active. Compatible modules are: CentralNic Reseller.",
    'errorRender' => "Unable to render template",
    'example' => "Example",
    'instructions' => "Instructions",
    'instructions1' => "Write one record per line in this format",
    'instructions2' => "&lt;hostname&gt; &lt;type&gt; &lt;address&gt; (&lt;priority&gt;)",
    'instructions3' => "Type should one of the following",
    'instructions4' => "You can use '@' for getting the domain name",
    'instructions5' => "You can use '%ip%' for assigning the IP based on the server",
    'instructions6' => "Priority is only necessary for MX records",
    'instructions7' => "<b>NS records now support optional TTL and IN fields:</b><br /><code>&lt;hostname&gt; [TTL] [IN] NS &lt;address&gt;</code>",
    'setDefaultGlobal' => "Set as global default",
    'setDefaultProducts' => "Set as default for the following products",
    'template' => "DNS Zone Template",
    'zone' => "Zone",
];
