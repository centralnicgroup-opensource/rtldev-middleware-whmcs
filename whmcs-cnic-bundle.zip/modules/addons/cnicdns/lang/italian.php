<?php

// CentralNic DNS Addon Language File - Italiano

$_ADDONLANG = [
    'bulkApply' => "Applica modello DNS",
    'bulkErrors' => "In caso di errori, si prega di controllare il WHMCS Activity Log",
    'bulkInfo' => "Unicamente domini attivi con l'opzione DNS management e su registrar supportati da CentralNic vengono visualizzati su questa pagina.<br>Puoi scegliere un numero qualsiasi di domini ai quali applicare un modello e procedere cliccando su Applica.",
    'bulkLog' => "Applicando modello DNS a",
    'deleteConfirm' => "Sei sicuro di voler eliminare questo modello di zona?",
    'description' => "Configura modelli DNS per i tuoi domini",
    'errorRegistrar' => "Nessun modulo registrar compatibile attivo. I moduli compatibili sono: CentralNic rivenditori.",
    'errorRender' => "Impossibile visualizzare la pagina",
    'example' => "Esempio",
    'instructions' => "Istruzioni",
    'instructions1' => "Scrivi un record per riga in questo formato",
    'instructions2' => "&lt;hostname&gt; &lt;tipo&gt; &lt;indirizzp&gt; (&lt;priorità&gt;)",
    'instructions3' => "Digita uno dei seguenti",
    'instructions4' => "Puoi utilizzare '@' per utilizzare il nome di dominio",
    'instructions5' => "Puoi utilizzare '%ip%' per assegnare l'IP in base al server",
    'instructions6' => "La priorità è necessaria solo per i record MX",
    'instructions7' => "<b>Ora i record NS supportano i campi opzionali TTL e IN:</b><br /><code>&lt;hostname&gt; [TTL] [IN] NS &lt;address&gt;</code>",
    'setDefaultGlobal' => "Imposta come predefinito globale",
    'setDefaultProducts' => "Imposta come predefinito per i seguenti prodotti",
    'template' => "DNS Zone Template",
    'zone' => "Zona",
];
