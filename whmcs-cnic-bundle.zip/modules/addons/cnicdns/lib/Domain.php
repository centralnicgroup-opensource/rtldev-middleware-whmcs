<?php

namespace CNIC\WHMCS\DNS;

use Illuminate\Database\Capsule\Manager as DB;

class Domain
{
    /**
     * @return \Illuminate\Support\Collection<mixed>
     */
    public static function getAll(): \Illuminate\Support\Collection
    {
        return DB::table("tbldomains AS d")
            ->join("tblclients AS c", "c.id", "=", "d.userid")
            ->where("d.status", "=", "Active")
            ->where("d.dnsmanagement", "=", 1)
            ->whereIn("d.registrar", ["hexonet", "ispapi", "rrpproxy", "keysystems", "centralnic", "cnic", "tppwregistrar", "internetbs", "ibs"])
            ->select([
                "d.id AS domain_id",
                "d.domain",
                "d.registrationdate",
                "d.expirydate",
                "d.registrar",
                "c.id AS client_id",
                "c.firstname",
                "c.lastname",
                "c.companyname"
            ])
            ->get();
    }

    /**
     * @param string $domainName
     * @return int
     */
    public static function getId(string $domainName): int
    {
        return DB::table('tbldomains')
            ->where('domain', '=', $domainName)
            ->value('id');
    }
}
