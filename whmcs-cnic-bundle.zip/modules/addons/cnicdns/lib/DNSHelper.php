<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrEaoEKfCZ7AD61TnZtuNRhoSbIcNmCExj0Vm3LBBP9u5hDscYMDGoOI0UHjutiLQEIIBgL3
Yw3UzUTCjmewuc66p0BB/Mjpe86JcICilJB11RmKsMnvz9fAHH3oLqN0yRO6UfQty8wl2EVgPgGp
3hAlRwbJDGmBNMqLRMR54Vl84GV90CG28BXBVP5ReL6RVIlccptD5QM6ynsLF+18QNbjAmUhKXZw
0g4Jc+JGDgXZr790styDIPEHaJG6qRSmw2PvckMgqkylOZxrd786ZNSFIvTZRMJL02smvrXaTFNK
T342Xth/gEJHSvmL5mr2ByK8cgSZN35f3mvGMlzuj+ORTvL5mqlcc3Q+iTwZoDCq4cbvHYFa0IdX
oOpTATn3lJxikmiWFz+URFtG4R/k6WsGwTHeAT0dEQl8XLw7oJ+c112laELYGSmMX8ZMM72GEAgX
H8yY8HYnD6/WXs5iztvCaReN5fZ1GicgYaUt1i990r/CTNvWGCES63hDHtSCSSDPa9s8JccFrf2C
6ybtR59hl3EiQOSPOdmw6Lf1YuCG5j0JuAR3PlgpCQZUeR+yUQIgsktctChb1dIuhZIJdaQeIUUh
h1rsZa3uEOiR7eObaGY9MP6CyWCQqxEwZqqaEEQY4Fz0V/y8rEeXtDOQFOVjfaJuuYLQaYoSH4iN
S6ngvziPCSnoldy3A3973vuCNfQqGLNX4d0zKqDlUYPq1iFp6NUPfL3bnijzOS7Xzbn6VxrTSTDE
H5mDoEjqBRY8yNIoP9Vhp0Chxb6Zbh+Zwfaqp2m+HOZbEgCOAqM+x9RkIDkGe1APOCOxPmyNCpAX
PrhDKOkjeFd9RvMbXN0vO26a5l1qVE8T0HyNZWjAkZZj6bYUW9cBYY1muUmzoyrmBq2uRkh16Pnx
OLql8OwWGIOKaLdio4EFt0re4OkYSThw6EgQ68Ulii8qvjHzr5e3KV6X3gPe4uWVWdnYdhER21/0
vz3x9tTq/sllVKknUyzIzaJLU6CjF+Ykkp8FpSF5BEbKaAju8Ks/MZEYN+ZfmgedmX5TFfcrCFC4
micEyXLeCpJJS8gCXFcugg3K2G478HYGHYwFfWUYI8q1veS7Mtl8vsqjtPEHZix1JNSsLncAE1nA
3SpxU8jnHUvspxwX4l2a5UBPrVMTdFlLUebk/u1HZvkuhXiVHJTvCnki0QMkV68vLpTAfW+XJ/+9
zk4lDG2f3evGHyYaJtXBJQx2ym27LYhmpjYjk4GptNMnyG4KNNBh4teaQTMbACLtcMJfvbcduhTa
yQG+KksQhynI0YEc8IXHO3q7t42Z8BNfr2a0cdHzA7HE2uB5EcVbVi9cHDbmoiNxqFsETpr46YMF
jVma/Ic36UAnTji5knC+GbcJRrmnMgmINWV0HCS5eb8A1hTUOWS90TamjVLPzrjey96E+lvvRiz+
h7eztUGVtX6PgQAnqdzmebLULHy11NZy5Fooca47baqVBj97R2LHX4hA6FpG+gn4aTdwqve0FNas
XbnWwfjktGY0zFP0AkMg4pzuFPzgAZVbrt5MAEmRQY4mcrZzDAp1iMKQl/T/RPszd7fVglNXAB4+
R5Qixhdyrust7fl8bF9Us/0mZm8WHK1uM/bh526gBLkOSL0ITJsulYMp5GCcxMvEcq3OhDimg9G5
q5iYj4oRT0Kn4WqHLNr9tzZqxDf/GEC/vxhVZEMD1rxj78SaYfYJ3+Fdct3UO8/3WYzugwlGtMC6
rCgbihTCSZSlgfoCi/hbagnxwkIKW6EFddOIq/CepH/1d9tNVrTk6EG+goQ8IREoOJua/8c//cEZ
pQ7HeIEItwZlmWQnwNHx/NW8mJRA/ike/8KRUwM5nJamfhezjF7E/AuefvxqSQYeXb623+Y+CXtQ
MS/nC6JnSgMN+JEmKdEIMb7oKUS6xg+sgX7KkunHemCbXGBPu0UMOm2a4cB8oKxcTkpngzW9d/7u
TShHGWgWUDabCbrzxoyG5qB5oYInYkNwNHfNSI9edZvm1pu/xLa+i1xwImN1n2LLSujO0tYifWUV
V9ArQsSue9igBt3JgC4itwUeE8YGfCfOcGjPfxQuZv4UYGW8YXHOucJ4gN4UYBgotx4rHcrLhnWK
auTiIcYEAEyOm2BRnZWn2swSGA04FtYCZv3E1I3ew4K23reNfecDUzr2PjUzEdPjgc49t8tGJEkL
Wf+3Nt1JnUXEPbEkawlrwDTrXnyPQTEw1F+knrXDKmIhKf9iBLnHKQx+MQREggbUSyVMp6BH1dHF
M5TQzCLmWsPJC9R3kgiMz91EHrad8wMfc+74Fb0uDBkGrmyilYSODufC1uWDyjuLQYHMsxoiTsa7
bd2079DWY/IF6incGiBzSAI4a59GnxWZlFB07Of1Tz9JZEck086VIPhISjNGb8V9QknX+yTPSutV
EImkPwSSZx5H6uMC4XHCu/N8B+/rigeOymE8ozkRguBv4f34WOTp3ErdccFT+/gav/cZUdUCpAH7
GBAfrJj0us8sKAbNdzQ4XS3Z+zEbwuGWEcIXVSHo69F1S7LADIi/Pm1deYctPOOQqJ6OpY6zRXQu
/56clwwylOM0HxTsdmJsUWyuWQ/7MoPbypxey/JAqlppB6YufIw8L/E5WpyLGkBmpzpACWkag4N5
8kEcoN5P3SA9LRr0AUeatv9wbxkufv3vmeJ0mHhYt9tWBeSMbyiK28dsbWi1Qyh56WdRR0bX7t3/
XgGCrkcTCLKIdyBtkaCCCTCneS0F+KuSeyE9J5S1m2V05eApLZ2LH/KcP5ztpp6fTVZ7NOagyRNg
lIVIDLagVqIAM/LEOjkAM8yHXgoToZGUvVLtt/1+fhijQbMxaa1L5c8utN+CRsKuH1cpKVcATcf1
2bcR3Juk3Yfmtzz5buX2K8PILSeSg7XB/OjDZy3Xevh7mvfiNnQrZ+uaOcdY2Tu/gnCeh74nw9WX
SWxlNGt2gFKVkVQE243NMsKYOy7gj8JfjtwIy5gylLhA7REywFv/rWtiyOf+oB9MXv2+dzE6thuL
DY17nDscHDFw2hToQKXAeyYfDhB5S2UD5Beq1V/iJPNUEasK1aWnec+m37rKCV9801xm4ID4Fe7l
NyHxX3BxkqtFxZ2DAgudhSaDT85PmX176DQIEOEM/+meNPkxIdAZ32WuLc1RUxTapBrG2H6CVAyk
ee5NbK/GcCgAJPP3j8cnFMqXlfe6NNnPFTwtS3GicJybyGo3A/1aUkP137wOjc0DMUczBB6E2a5D
KCAo4c9f4HNtBpXjyruUqCKZ8jgQ7FpYAb5yKakf5HXwkQHtQUuiL7cldRn4vRy2r/Ud+vfOEVfP
bOrpMXvV7mq7hl3k76KQgal3P2RknlkP80QB7YKnsKx9OwLLUzSV4fDMaPWBkIYRpYZEmtwtVFK0
TWBgiyxwtQagt1YH4qJn0hW+cq6oIQW0fVT9Nzydus5tbJ/M2o8jd8JbMxB+xi255EsIJyYxU7vK
4akom4Kubiz5RuyJk3INVHPqBlgXBbBD74iWGu8VKnHyL8sWFeahvIR1XjixTS2vTkuwByJ443X4
EgeAp/s0nqeIir1lGU1SWV3xNVeV1OasYi+8YcH0TMUXcmZIHeUmcZTtSXEYkS/txUlOAuj+u4Bz
nsfLndmTc/FNAvazrKumQLP8bKm+TKLVdwrDyJYPdP76oJV/B68aPRVD/9qPvFGslByVEAfY4UVh
jAZ96sZ5dZKDlpePHXTMtv6oiPv8X5MQQO4NDzpz1s/T/69fhwKvoFFMwPbtAvONySNWM79rKLT5
fycsoRYK0sXAQcBCq47RPHM6yPxCpVRw5RTKAaoCroYLclmrcXpnoAOw6FsinqS2KyZbftJhZBRV
fNgIIuQQ8PKsbatFhCAA/uw6suqzz28McY45WgzE9B4NVTqkrhFmJ94Fskmqi4OM/g70m3rBm2JO
or/qIuBMf7uSFexXCN1aS0rkeygrvsoA8y3ga52diDqwaW2s3mXli12pjYsSmf594cKDchn1Tl/s
yuK+3awhe0p8UcPQLMCbppXR/lFk6eZRXnjpmbV7+Fk0p7aH/1Ex+1d58vCjQhGo8gskx02TRU1h
6TFkgB72cKyxUazHBXme2zn/nw2Ilbcef2kMxBhsDlUEOh7b7iXTK4dqZg4tN4K/vg8j6oAs9vy0
Q96ZIXOCH/buHFUd3wQacgs3Yb6rvgIaODTe5j1d0xwQQKFiXeFdn9tB1UJzTBpdP+RqL1pxfYXB
H6Kk6ZVShTbSyybBTyx1/Vzfq+/vNclJbyKq9P05wkV6PGZhifsff2ZqPSiAGfDd4HKngdmG/AS/
kSAYQbGnFXYK2oLVtXCiBGsssHQ5sXkB2JVDSbzbPIX5Jow6YRmPuwXJnnLd/jw9D75O1mLA3of/
9z9cq2helx1kRao9TkfhgeAKpQ0Qscinsv0x3nFfmVTDTG86t9XYhwkwJQnt/nTmMkfewObp4r8d
Aqs5CFIZkMWBj+lsDA+A8Y1RqTEVV8ZBMbisWCHf/rbqq3vjall4BlVShuN8+X20imH5BV7IZBIQ
nx/KDj8ToI8LyoUPbVxy4zubA49SkMKFDgg2N7V9zYsGUMvrmGj2r6F/kZ6krpL+ACp8OvCYnVd4
Lv17PdGqCDVM2D7Tpal0GaVgka/XDLiEHNWH5RXX+9BsWyEUiipWBC1QXWDshd6KhdX9QmyNHKW5
kKorc+dhwYW7YrqHJMvLLrYC6hmxK5w1I4gB0cijuOwk6XQLeHjtMx2VZE6Cf2Xj/1h6oKnyIzka
Y7Ld5Oiz1ZgtTpIVK9o7/3S7oA+f3p2+c5i//ScuynVOVEBVDWXgI3MMf9fXCqL8PUVpoisLiErC
2AkdMtmv4BjwukwOgaJtQobUuS1W09KswpjzYg1V8YACc/PWlo/lrh16MaxC/ZM4jq8XgLUcNeXk
9JF19Wqliory6xI59iSKiNEzZpW0ugFqxuHjj4d/RTGg8J8TdnW5eFcG1PQEYvMtBeRd8wDXQMs5
RgLE5x4LFJYrImbpqRdkXWYqmNRCIowCm05jlS3b2jXhOd5f/rg8rY4aADJp5+iaQn92iPR5KKD7
rbWti1nrneWxX2J5XspAmc048IBKoRKMY5pH/fxLeCsT6vH+gcXFj+6WI5FohP7em/RDcw8w2Xh8
0DsivFzJ/KWwjTrjym4LX8vHDG+u/gxVTELMAY38oH+qB2S4BitWVMzETaJO+DtaGrE+TMyEmmBN
Eon+Gjc+nwOGLSADEhzVKDKq7Nf/bJJeISXsvBC2s/erOuhny5AQp8Rrh1Wdm1uKy6xtg3r+idH7
kKl/SeU8e2BcTy2A8onbIIRM1EbSC18RHdMDWSyQJU/sWtmKhOxRfIEFbgnWSWlPpZ7Oh6FZVe+F
oyDOdevs0QLmQtYD5RH8vmHrRjEhCNy+Rspr6dDDAqoFLNl0eliD+iWiCqBJuyTTJ7PR5QHDZ09c
