<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv9Z4rWOu+UVvQ+6Uy7BzSnPPS0oN49ZJAsuEBf6luOPmODZbbychLjimg7yaB6MtOi7q7wn
dkMaT0zFZrQQqz0+gN9e+qOpDTUi9xd4L3tSCtqZLlKCBgH4GF1cPdqVMsM1TMc+4GJ6mWOsAoI4
wRJVgqIxHBZ0cPkDzIsq5cIUkXeq7VJqGt/W18mlTZw9IKXsh25t9I7pos8pplqlHkn8KPXMeNBD
CalknvjtAy6ZFy1pVt0Zbok2sV/gGAaWLmFhPr7xiogPqoBwarRZit/zaYDgHSZylOCE6w1chCpX
P2S/CLmo9G3oucZseb70QIp79PsMEix4HSw2PhN5nfp9aCbMl8fLsGUgdNLRePZNUOaEE82V94/D
dcw9jhNGYF0FRRmODtnr7oBaS3gPw051lTQArGhO+PMlsK69ys78bRhAjYNrG4duapfhw58beCjK
GNGx1jDEzbF6vOduij2uquOEu4at8bkYYF+v3m+Pe8KoeuglW6AUg3zcZ6cfrndZVhPDtJiS4QKF
o8yrd/w2galihxARgH9xXgyKoroiUVPdfQgERTlNlH8GmlZN3Jly7/n1vFNPl77+onXdPg8ucw/e
YFxFSbFS28mKgVilFlXfTrnx2awiRZHuedaV5CKirXkwfNjNprxuvNq4TdUQhMPX+nWu117EXbSL
Bdr6ei0tAShuyRewbh9cxlpTjOUMz1XQsLUJisw8MD5Vj/56NVLjcj+6v501X1JPv2pIw34PB7EG
Hvr0veEuaw40cxjPClV+y7U1je1rrvyNDRCmynBxtJ9d4UFfwYlpL0bUYQLm1A1numTTYhskmsCH
Pgo4gH26cMa9BMPCzDpYgkL6UcNkbTaeQ6Q369QdVn91yyN8+snHbl5TmZZgDUnDYmEbuKlU1Od+
OaPdXvP72WxVnhmH5ISkAPEQjB69leVO/ovxhdPd9aWTnjeGJXFFwbrNPMRt3zdaH1h7xixwy3c7
p5xhTh8sDfh7GIASwu3uCF+UbxcTBovI7f3KgKVmvM4N/OUdhaDE5fI34Xc0wlLXdTgumpMPa7rp
YQyXoBiLANNUL5K2WdDBRfoV0k8SJsVL9kdUd2NwHAyw8mRlJPazb++/5jL7InSqZT4q7M2c2QYf
WSiSXl+QCWWiFtIwCaLHy6bv/gTpU0L0WsAVNnlnWZAllY4/ohyd3+QtruH3b+zKLF/L2E8GAKPL
0HQTj3MCeHEV176edAxQgAGD6sA+fJB3iicbt/FqpSx6ZcZOEbQJJo0ePHOTFei1+wDvaOsvqWom
48ACbbxEGAWmtnVy7701kBuHAfu8vdrY/e0JHaROWnRTfKFTfcY7mRkO+NeA/zUx8dy7ti0AwXVe
xu1WVQav/hdjWsbAaey3k+1C9ZrJVFs/cEGzj4XJIpFYeVhp75M/qbo5u2LYs+IBfbh5di6gjFEd
GZvo+C6siigK4zyuYXOPUwYX6C8XJyXWR7jH1dEpAJuhok+kRuJnOgHtdCOvmHJN6orDdUn99jPw
frifkRsHGpZmkE6VpPONpdaTz6XqqZj6ZyAFxphtZBm6qGl61sJ6DBapu4gwAJeGwcLwu7hexR5Z
vBpQqdDfBDtYVRfyPAw9dh+Y2g14BNOBd36TWHuI7PaWml8zCFh+VgF5gSf8fnbn1Rw1MyIaW4cf
4LW57RLAVFeJbSq9puFBG1ul3nHGRFxv3IsQbEXkgw7V7HWzoDL0/CSqWQt4QXh7ZT8V+GJh5lvT
N1NMh9qE+e2Up2lFrDZUG23anKrsaDaAGgN9RhR0qzJDuAq9UrZ25ziP8B0dPUkPxl0Lf//ubeqx
Osg/eDi6z+LVbkDedG3SEsbCedn6p0FFRejckWw2wvViaH33qXtS6CUGk5dwAjxdDi9JGrbfku3L
s+/OkWdYQ+QAGN1RAVm66VGUhqIh8B6XM2hURGidzRMnwI+EZbJ6bijmDaZmxzk7ttQsfMzOWx2M
1C+ntzFo1IkPNP1QPO1lT6zH7EMme5xhLkjIXi59RrD9mKAPj8ZZ5w/e2qsoBHuPAntW6Vc4yswu
U46c0Ho0VohIoseG+06rYsSDP6O6nOjASE52dacMIssImZevYWHMg5esvMlfpfkU4ufYi6KGk8u0
zwwCD+9OWngno0OtawC/GMR1o/B/EcitJAxWjlUCPfzhEyxR6bq0fsIXMCN7csDJAeVw1CPtm0el
nulNYexlxp13zHyik+CZNa+gN541KxcOwoze5oi3JEhQngcFV1dqqWYLpIv64i+XbHYVOyHUMRml
F/zfvh8nFHg7xNsxX5ukSrK7oZG9rp23Xn9yvapYtDOzz7Ca3UhypryI/OEuaD/1zmDsP/O7UTKf
ettIMWT0oHicAcmYSrslK/fDSTY2CrTx5sCTtrNF+4shmPJL/i2DBoYVL91ac0rJcsSlRc4SLESV
kma1RluYKJq/KFzDUvzb31FzqDMN4tTznq6878IdNHUJWHHVn3HnxeTouxAHn9IQsX6kIHnd+pu/
fc0gt9eS5++XCTG94LWe4xxCzdFi/pE8ftF4NOO8G8z878daZVY2/n1wSkKpH9VUZmW2Mp67NCaY
61GJ5wUU+S3d2FWQsU3FlD84fCKu4P6nww+Edf6XVVX3UD9c/7sA8LhrINPrke/bLrV4nve1ST89
mgtWCuAIMbmDTDuChAN1vCCuV8HpW1X9DfGb9Qg+SP2F/G==