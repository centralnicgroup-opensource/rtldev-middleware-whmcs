<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvc20LG3GFgRsawKT+c2u3sFcevv/D5QmOouhT0w6qzeLzgo/B2/1WehX2UobeEnlftVpkjg
JoZ+PVoUYyve/GnX/0zp6c49u9TR2nu+ZhZpKAZm7pbea0yMXulrKh63HMw0GvbaP/8i/ZvAZJw3
0YQ2p3IKz4TWu+rVJkEDEnvAZITd4h/8jKl02Ax9o0xkqHKl7kBnASUE1ifUU49HlPBrQurGbGV1
ukJ4OWKlW7oS2bKMkfmwVtgPnj+hJQ7Y8/vIgu3L3W3OXwtmeEhzGSlm2Grh5W3HKgjIcQyrBGOX
YWOTbBQzhn2jVZjwDgnGLyZLa0WTwgcNRj3VbW1Lx8bQDjPmIHP7tYVKNGlE4+lGrLRL+D/XbZI6
wPe9Ta18A57dn+HGh8XFj8wulbwQQYEYTm+NVVNfSooRKFSe94DuhR8A0m6PpsHn1J8ESF1PWprL
MvcE8txEVfU2iP4GT1zQrdrNhWrbenzkBACuEk3MggLjqlJm1hMTar1gr1EBoPY9eTwWOkL+wP/a
e0WH5+C9wHYKxCRTW7lrH6UWDr4ucoMjSAECptYjgbLPFOaHeN+HSRYs/IEPS8Sxk381qPHKpWQn
kuhD5QIPFpK0M5PEx751YBQpQbN1vs2xzYQMdCnUCLxG7qN/gnVpr9W4qfNAfxlewR7tm1hizOge
N3STIcTMLCya5AGAC/irSJdqCxvdm4iUNgYFtvSm2dHOMWmxcVHUf7cB6EGFBHPB9/AuHSFYTL6T
AeQckY+1XBz1mTjM5izg9+nm2vp3JkZgigY6Yfmbf1e4oMiqMbxOpk9cQroiESieivun4cwGtFaC
nshGMBmqwD+sFkkTdXrJ7d5+t3Zd7MLgcH4gd3yurY+JgqZ3A+TODW70r9StnfAWj4zPGglPeu2y
sbpyGrr8G8uVHlpDvijO9oQfLFJYap3mPaklGGgjp2KYzy+W6AAdxgDGmZR2UeYimF0wf87mrChs
PHknmeFw0/zpMMt2BDD3vTm9GGsg/ThqV/XcfH1JDLDr0YXr392JebdKZC/Z0JT03EWYKF0lGTXw
q6Xx0o505d9SgWaZSulG3IgnO/rN5Va3CTBjs9ipuSbi7smDEAudkhOKcCzOWqprPFQoxjIwvYil
ZFjRrwsfVWGR8PJF2dPnzw5gvPhxTnOJAMLx62Pp/m6bZ2SKP3w5s2mDXrxP4Q8+OBbJKj8JKGH+
agkwXqaEsHpwCKAuSLnmcQR/B2LOpD5JOBUXX6IShnSMCfCwMqijoJkF7RwqBpZVVwulFXAUXuYC
SU74uVv3GpaqY1Erdy8HVKX5Hmtemj9wvTVO00CrUSgbeUyVnSqmeWJD8Nokas1ZPVUiL8dpOpFz
h56iKL//oV9KvmAyGlHVDixxJ5AhJ4kuwckwQFaHZgVcbSIaAzrfr62uTPn774YzhbZCOJOjj6LT
iz6eOgYCR/jRQGzR+EptK2gkyFoNoRke8TCt3iCwj17mo/f/GS9oHoDotlaJBZ2OU1jhgMAn8eh6
VJQxa1mCfLVpbNK3y/PLPfMvo1jwIC5z3FMVWtJYRbE8Ai1xm6yYYR4fqm2aZhKw8qk6BtRQiGAY
sbQ98jtXd+CiEUHQyLhPeWHiSJWBlirfKuPxaKE49rJCM41DdisS0ptQT1Zun2YbMH/IGNnzxKnP
qeGSxey4J81e57M0JBrGZ6OA7RzvvDNgkI1Jt2oDGoOG+PIQG31RWSgTlSwaTcoOzhd81NPlTAtd
kFGYFQyZXNJ7rJ2Zvg4DFaajsKfOl3XYIv4phyYg+4dDRqNFuFmOBpwuc2KYbUO80iq0tp5j6m0M
mJF4AwOKfAE2tWYQxa30AARrym5gOXH7hykLnrn+pb7Ez+OvD9wr/VAPfpkuE/gKTzNLee7PvvGj
hElojcdVzet604WuN6u1+py9rB8bFldDD0RmSfl+qoo0IFNZoXkmDYA3b9Wv4SasoQPlwtmqP7Iv
bFBbJc0EjW8mO5MwMqanK4LF2c5rLksUJvukhmasnyW3NrA01ptUFdQhKV+gmh40nSrMAPxRbYVC
9ve/prffCn4Oc4u8LfOGS5LHiMKcdRGcT3wbRdlZGVaDvkNghImJkeLnkxHj2a9TCp4XN49xkn+Q
IP5fxxicUME9WMDzDPtfRSpqZoaOl4xfuKfYcYVHQZuah0ZzY/inarHcdVPwfhVMlDflBO3MF/oj
JO5kRZ1HQnbiblYKRWKvK2i09oS5gGkURTTloHuQnCZH0/YJahGDxMD0+l8G7w4U/DKLTzDnGIgK
VqZz1+pL1cCWPttMeBa2GGErXk2zMn5xPjFPg8TW+VqHmis92v7CXUhwHe7KFy5Qz8IzhZSrXsX8
Fo+YJLxWCY+f5TdRTYrOvMCCmuJF2zg0U2TwASSouK1x70dRbZThqonlZJbbD6P26zGI7KkSpmNq
6gCuA5loPJqFWdYTTUHsIZPma4Sf5t1P3Z0z0ocwmx5M6pttVE+sc+2AbqeSaVLyZAWLLeZY4Jde
q+vXV6nuVDAY2m2FOYQ5mGNZeMyWjJhjNBnKZHBHO4gpPFaRSvTQ7nc3wl6/X2IkOfGZnt8/cupt
mDxY4xWUzN2u4NfTVa39po+l1Pn0qWCHz1wSleDYnbNo2UZmot/IwvdV0lrqAnLI2m49sRTouvhe
ABqCUA/3+/d/m5DKFxIhr12fHd6g30==