<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtVrjQ1mLGwN3JaWWshGLabIPQk10JWi2V6RJoFdZIxO6NotXYC69H+4oIrAyk5uR6QyW66I
HxeMYKPvXIFGfyVPDKkkEiXcNRz271PUO7JL+N5yacjeJQeUTRhZAA781sZA5pCzoi5QmR8Ilb4H
Bxc7BIo/qGbcUmCK0cSeM1rJbWuPxUwvZWSmRCN5LGcVtQjMtUfb1ONqzmxV6qXku5hCcpzoXBKi
uYq6nHq0mGUp5FRYbLIZ79yAmuudIujtrjC+k8pIR0DWzI2v+PfX+UHitzzcOeKE3+3fUPSDffHC
Dx17NrTd5XDd+yMq2MRt+AGMzo44JgDZf6/F5Jtx5pvUjLldYCvVgeSJetrnOmk/i1RBgpY1q6jT
zpuhn6j9ZIEYsWY8ka1dUsYUxMMFxiTBiuacceb6g7SzRSQVltwdQCqvDJurIATigurmQtS2plxn
D5plJn9qu+FawqsquBN8w4NTRX8tD/Y3mqHbdw1hpavU8pgUCQVRTzqo/8QjPAPNjOywjvjsl2x5
4/QkIT24JzVJSrWNn/PPf9wwwjtQVpKtdq4f3KG1UMndPQHh9Gewh4hroZivzcSJukXm4u6NNhnA
Lg4Wsqlqb7WQ28lDoTJKnJka0KWXRtAxIcu2ygjdC30GUVyQbgfkhiTjpPGxTJIT8usyrvHC8q3O
EeBxxKzZjdmuXflIhGYnVUdNA75kde3L+ZMAH7TtX7xrRVzvasyP+RqG1O9ZWXTi+cWeTTzDnUuG
C7/TlfznKvTsVvCDDQL6PsD/DyYO5LIIeprPEDmuGjYVY6HN+12dGkAAmL1NgUYBiFdcoYZn2oqC
389ijuh37vcCXpXwKA6VUfetD5/OxzTu/o1iQPGxB4qS2SJg7iPqCZwt4D45wX/L5hozkSBHbXk4
ECxZrK+pe4c4rI8Nd8vM7IsN5SThPfwZDRkz4T8zSg8Hywr4i10ugllHK8YfD3DDiVFBrpibGizI
8PGFOmWtq4kZ9Z7xcoF/++xMR81MDijrhJukR8glpPIyfQl8X0FesvKTIEJxX/PNtb1wuLrp54/Y
6J8XLYcvWmtjLrXqkHQHLrgehjjXYOD1/ntZb497vjqwLYP0+atiFVecUkct/lqP9zYPfwkfZebl
85jr2qSdfabRAfIujXBskdymDavPafjaXzKvB0RuPxC+nX2BqPrLObyzXpiMdRIGqxRfHLd29Wsu
5/ZUBLZ2fOWXgd21XJUtIieC2szTmJWAG77gilvXAXIMvMaXG3PyELad4oz4Fp9gYf8NAUu/Y5N8
evwfEzxcjIyMV4SWjISRswUKtplQA8U3di3S99b7Xmiify+uOf5j6dt9QoxjcgAgKQc3NGpIf2V4
zNKx/GKkORiGhKbpOJTPYY3rnUSbBj4ZEHmqq3V4IaqbY+uCq4iwrL3CLBA98bUhq8rv1Ql6IrqW
rEA3dBEuGTLcs9s8vYH92A04mloNnAGDXwIA1stmPKLfCku6kG7ubrmGYLSCxRBXv5mkqEPCt/YT
FIdrgSrW6uVexfz9M+jqLt8ml6GPP0G18/2E1IY0MuMvPAs1EkW49GS+9uqwT3h5tPP5gEiKl4KV
Y8Kx8muSkkYvyn8pGztgRys6pZskC8QDZcEcVIRvv7UKjGm8VO5L4XTyYk23Ex7ePvau33KYd+3S
Gr2uHjihKcr0InUHjZU4z/qX7PoR7djaVDixWAfpZyD0UPO3oqD6efNAPgeZw/iuWUKpuVWcIKC+
LIVzI2kwO/D2sNyfwCiLPztdVcqzowrPzGLRq6IaPyTXZHKNHSQRPi6KaXazYh4b0CmfLTelRbEN
CFEOh3vgW0hjUHwIfhls+WoKpIwfThofcFm8SBrY+3CjOlOx7g3DmEidskEVtQqRQcjPWkEjWrhA
YODxkWyh8HgIEJj8jggik6fBJDhz0TLGOv3bf5cJ1taTguDF1dcqU3NxWN/PWncGFTdO7kYsP3FO
rhxKbtO1KD4aM3WnSUUmYfui7NweSBGgtIG/YIT2cYswoj1JRuHV0tzhMcXSuUR3CXvE4K03j6Pc
5u7Mt405oG2i4G2RGMZqlKdKdD3jocvA4vkW8QFCQfOeBsmB/BmCtH0JtNSrQHUV/DzlMeJDD0Ei
f0nQB9tBumSjNxboHkF/dl8zi7AglVZxqPGZj5/YUIK2OB0ZhAcDmZUPB4f/JaJtSMpwVuBnPdXb
o8LqGSiiwbiOmzAPH180WIrUZFZRVRITph3AojTrEZKQWAQGbuDBCbYOmZCTMn1l4B1dtQE8jMwo
G0Kn5ohWtHD6zoSibRZd2U4hFalDSNyFfgt02g7CxXeUY7/wlu4htM+D6UrGdKvER8afzPxnQlbO
XayxtJZ8EdpvPAnWeul0PXPXbSNIIF1fBU98mpsIYO2CRTu0Pq3+T9EUTJdtHYkmv0QLvLLoGgdl
JO3TEJOrTGbEyfbU1IxNtfEpuaq2ji1RE5vaOS368tbvGjd+69RogdZ3RQrB+7WI56WbHLMhBJX3
LEReYKBOXq0U9eIvKDRQ2N+gkMHzRx5H7w91uM/7ogwGwQ9wXrPjeyXXEiiSijDfa40++5+8PNqV
Y6Y4CAyYSRuV2iGGZuYfDyrVRRnISOaHo6LFXsZxixm3BXehmP63LxcaGTEHmY2nrayYI3qEgi+t
GV5QGQVhZyod7uady0P2KzPDuA7cN4CDexjg2TO=