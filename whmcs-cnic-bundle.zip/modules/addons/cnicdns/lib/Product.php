<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoElrTI9FYuRL6D0zwjZMZhoslEPWEIzj8Uuwr0x/4Pdjh1+tLBezN9wUVt02UYYlZEFhucr
1nXRM0t+tWEG0/8WIwMddiGMs7uUzVMURGJBSRJFJ7rv8LKZ/tPvdrcKhXRwq7xmItvpJ8tSwqki
WWjL3J/SFWGoaoYHnLWxNbwZyH6L5+HyMAb85jDzE2pn/Str/NTRI/IHtzMjuhvBEY2lSc0Es3Vb
VYGvsJN4LjMaefPZcwHD2sJ16ie3Xd+ejJBMhLmNTQBmEO+CXpAnqZy6G0LiogYzX25oXGT3wCxN
wmTRvewStBcEDMYNjcmPtbOW4s5YY1bn6KUzd6U0WOt5nskCDikm9TUmuLtCaZ161CvxE9NV3SZQ
8rkzXu6+KhSTbG70liaYaePS2384DlmW/jNmuPxNs6Yh7djtmNGat2QnQbnzO69GKhcbEgnDg7HC
kT5t8IBXzeVqOJVQMi+X3QCHwILd2Jz/vrV65raart2dzuGHt+TKzuFgwcvL2F1z0UII6e9YIU0d
RHkrHf+pofKxyfn1Xo4fyeo69WhL6s2Ei2ZqIc0NXi0LX3KVzWafVLrvXCSnAuvqj334fXeZbmB6
ZzqofGluctnd63JS767W7PPZ2S1PhkXERtt5r3s0tg9PW30ZXO9EDj5Hzy9dNNI05+WTVmgruygh
EZYJlb0TBfQ6mU0cGQ6Gdq7R3E3ZCpuW9XrzMiAi1llaj0YI/xjxGk/eOAY1ILuQ4HuwIqAW5Add
7XaANc9gH21f2spB/I2jEU9otAYuMUlLo2sHfZqdkgi7zjlzfYSJSLcODMVj0g0OsiD9AfYO1ry1
u7lazJqRUNcGjqBOvthldp7IN9z4tDBLV7Bnd+miFUMzrlQ6rj4SzoGH4EVCRYCv+Z1jsWRNmzvz
LJH5e/1QvG/5zFDm0NqF6sm0TVgEU0CMemDMVA9rzKD1VY+u/zLtK2dK4nRDZY3HpgxqtDKU5PJs
NKBZYMsrNd2/Q/+WmOvfNoCjknCjN1QHUpE4+fDadJFvVWkci1/rqlgaJ+sGs/0vvDFJ/1zLpR0l
wLOEcdSVKKj270Bl/1pnRJSrE2gUKqeOE4mKjiE1AU4WfDd9dviD4dcMSFstMYqRb5XFsPXodpHv
vYxVj4s3NOKelU3aGyOiCuVFgeHnkIvVbSUUTwEdUVnwYS3M2VB1GTSniQa4el5t4K4BHp1eGUHe
aV+NNPZCIoETEoS0yhWdPXaKJ6pCJNS5VR39HjDBYwt1i0nwDvz2xKLhDkUlsNwrrKrHJYVwgpS7
smHXVo/iKxV0g2uzox4BVA1E4M9TbxXMgQ5Thf3UxZaoNEj9K0Kt/oAaA1tuP12MPMFD1XbaEWGB
yvWD908503ivkiU5BLEG8FWxU2464Pz5IfX+TsBslxZ5Q7xHyZszzNxKKARHlvti4Vkw2OgFUxDE
RGJRo083jnje7gul7ZBbrfB7DTyJnhBpNMWjalo2rbxLVfhUxoM1AmUaEVbwjWvXvDy0o3heN9xb
0cDFzN22bB8AGSABPygQBre1TvGMdBlN5lO9UAxhvH3j+5Exf1P0R8tXkFPms8UwehwTmImSjlGU
yMqKO9BQc/jnLsq+qTLehnxy7kFNoJqa3yd2Bhhbz0lIjoVEHiQVP64Bvh1BejiL2I2aVT75FsW+
cerItQkoRXuEIo5TKwcrlBhU8oZhSW9MZ3elAyJYnfLOY9v+dpep82jH4e60FLLddKgtbT8Z/K1b
ebwz8yiEViIh5AlfxOhCmgyG4oTSlzPtTKbff8jjfmWY1qA6HRnpwUEDHkDeNrpvWKS/bAlmSpX7
hdN4E6eRfkkONCRJKSNXVcGDDCEWUY+9uT7uldzb1mReVcBHrlOnGMAGb5KJT4+YVFhvAY8krHUc
rOghf+Z7fshqzO1irXYA2tkNmVND+YNmFU4V/AZJttI3SAlJiPE0spdp/rDnjqzMmKK6rW3lB3LB
Z9mYwoz1p0JiyT9zIvmVSkpVFd9xGESQViIKTCMVTZW3hSwHc21d2AGePz77TnByQ3lWgcpkB974
aNboO9kZen4zmk1NAk5Tai23N0AEAYpkHdgntzwIXiKCtzTuIiUVd6g5375VhXAyyqC+aOX04BZl
/djkfyZgZReqztOGjVcpWNe9ypXU57RJI6v8sVFyaye7FZaeXpPOddNKnKAnfdR5ot0mYTHWFZWF
dbm2mNBHESsw64EaBhmE1PfWJHH5i1tJsavJ/sFac8uefkMxNzfI748KPZTUirkkXccT3k6QCxR6
uE7S85ea/KsKk1hQfgOhZFKJWrki1mtMbnNAi1zPcdcZfRLOvKkxRmq06GfB4V22vWwRkrFTPfvH
2q3r8sHQD877ySRfaCPG2gVpwe7IV19p4myzshCGaKw9pGn0k+j0rCykzJ3npKGhSNDh+jxWp+NK
PAiX7Yl2bjJI7ka2Wi0WLBvwAWOwRNMC5aaEDUGCFwn5Y7fyjXCXUbdup+1kyeydV0Z24ntYydGj
xRgLGbKF/U6B2M8X08OEa9YyGzsz3SalotJuhcyrCCt8XIbXZJTzTLMO684+7ZGwWxH+/w3tqEc1
FwoV8RzJ1bRLfBT6TnZotZqAiCdCSqwpxZLQq/f68wICOOZD223EuTkJ2VsS6rvw5XW7YUZ43kPj
YLXSvmwbdAgFxJeqik6gvDTZdVrs1wAGlbXAx6sr1No6lm==