<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqoi7mHmCkGh3M2A9zIy6YMYbMEADH/MO9cu0ULWM1tzyCOMqC+Xh9R1HNQaz/dSmoUdV8fC
rXtU+NBKoTAxden0E4+XsWuaplBVNGe4DobTQ9RXgTzPe3gIB+LC8P8Bnyb7SyxxK4cDLKJivw20
J1xukuXU277GCruE1AodX+sLGipwsUIpJTNDdP4SgmemtnmEJXCKnjLDL1fzULhIhm1uK5+8oNN6
j35jICjubeuU/lGvKcihBu6HPPF4IUNaZ9r+HCJbVPVNPnWIKKGpvUxVHi9fme8460TnKEExVK5j
bISXNJWbaL8qePnFsFDo9UytlztlrXifDOPptgBcGlmUnE1b9qzkcJfvx4eg3rzTf2yNEAdf302z
WJOznHXtxnwH02AzQjt9n65GoXylQZI509PbaFdRqrGoMFyYQJu/Ae4HVdaOvpJ8iP3i7Mdz/bRO
Adowmn3pE4wEoh4KWXMQQOLbnx+1zswDhe1UpQLutH4WIndIr1XOmvrZ1CHrPuVOMVIdRtYGw8ld
UJja8jnbJccR+9IZGSfcmfS56Jj5yRoDZpFB2sVXT6wLmbBTB3dgKZ/d/eAo+oF14bTfdYfp9rFX
yAeKf6+bfeMOywHinJ1iIaLe6TIxb9jFNIgAf5BKxenBfa+tVYu+ITPk8CVB8RGAwVyOdSTcH1bc
lBOTQB02hdIzpBsI8aaco/xeZAwtZraKmVhxy5PD+0ctrmUHdC6i0KT1S3AE/tl0XESKf104RzJG
wTR9fVW8iFGxBTUtHI+5Jz2mIy8q8WaNvLPyn3yYWLQ2p6cLqbjJClE9oIEaCec5NAcWydG5VCMo
Tujvx3/l88MI5V5hqNm9wJ24AUGufYtf8mvqn7wt40N5sHJ54t+GDnk6G5EEmPvaKlbmM942dGbP
ibi6hSBQmC+r2xlGZKqPLbdCa6fHy1em86flJn8dE870xc/IIn8u0q1IK39+b0/Zcv7ptYa86f+h
BOnW+T0S4UG7KPib7EaasfON6AxGBBmfq6lWOZdh2fQQWSAeGcXcsXbrEwrWCaMpSQKwbmO09c/8
LAZ1ZetOSLdvPKU/NBQgcyPa5XtLQKlxJtsmTnWYhszlefNCESppjIjrQEbUqNqYfM2921Bkebgg
UYABsS6LARzHtKrV2hT3wgMof8F7Po7QnTBGmE3CIfaVcHUdNGa9aRuYJUQgKS86yCQHNFVJL1km
zL4JgdwClYt+rXSB57fBmCaLgMxBDfaqHlz50u0fXRUHxorZ1LD3DL3G1zO3MIO1IpwexURnuQVP
mkua6CowTwZGw9rJ1w/TtR4YL9m50HM38XahgBZokQYNnIDvx1EbX+MeWZvDhxoKaKW7I+c5ngPX
QhI2+WsgsX++JBwlcVkZmNzTz0j7XracADaE+cfWsU4vRqvJpWtA3q3NPO9I6xGQbCqnXg0EHJC3
zUvvZMBUSPfjlPRR1y+wjYD+VOXYbjVyfVAk1qnScgCYBbmqVikmaU7iwaZEDjhk1b7Em/mdgO9G
DES19AMFGmQsXDSH7HjC/f6sn+XCpujUxuI+dgwl7ux7RCgmbFJLch+cET0+FcYG3t+DB2TFy2Jj
YNF+IxwUg82Pbtl5mt7H+sHeo1c1XgnZQFIBHfWSW6cSoo/bALbpBQCVONgo+roJw3H3u1oJOLcJ
6SgOIF2W8ZluysXVYNwB9Hi16cbi1TnQs9pyZnrO1QdNHVDsyo/pgFILSaRW0s9pc9Ld5eb3QprS
WBYLNLrvZGc46/ZgxmdUieaCSLxbaHwcG+3mW4MX4gvYK8RgE0p/BPBvxvpdq+asCF3+qfADIUpg
H8zxY1vx4h9ZQGtDjP3nYHnwafHYGFoWMfXRZdGktBL9uCX3qsOpzeZxq9tlTyUFLT0rMZ03OE5j
PazJMjy0OVMwGokHGVAc49k9ZphL3b6mPCQzfYbsMk3T6t8m4NlF4eofCsPhz7TmOP/dsAFmd64b
Mmq5Mktw+oxTqk4QxCeYiQ6o0h++p9fRQ/cw0OS8ZAG1ciBe/uj+2rdD8Rrc85EmYMG38bxemj15
vjnbanMx5dj5OJkLTkX8shRWBS0e5948W+M2O9068egFmIWNJTeSzYdMd5dO6kk2R5aUzSywe6Is
sEIKTLN8VlaXD62d5lOQHnRornWzVvu9ZQ6qwcpmo5efWfSce5c0Ou7EM5rc/zqOfbQm0pQCTAqD
x1bxbkWBrnhM3UmeX1P1UkUAzBx8QFinQzdlssYotdwxERkv6SXfVa5U2ni8JmVjVw7EGW13571G
YzgS+9QfwfySLSzvGhIigBBDbKMhfuSrJvO2uvpzuYWdDVdJbtjUVxN5U/vvXi5Ky5pA5kNuQQDZ
fKmLa4KS7SJ6z6sxr2yRAlPtSTzIZ3bcAdv4syxwzFtXAduMIoCTfkDvJLtAblTwzzZF6vMlIMb6
XSzOAPXWpSXdEp40lgI1xr1RyG44ztxZP2ESr7Ea5g4R/maCS83Dg7l9U5Q0biMqWdTiqaxBI8Bd
lO3140KbEVq3mThrmdKA7PwplQ8NvjvPXMfi/v5IBrjctJ5DRsxLW1DakzxSaqijYNZdsIEFR3z9
pFIExs29gJMmY1gEMnac/UYrOwTmuRG+76EWyfFHcsq9LtZ6h+2a14TnRYTHKCUxIb2gMkBf5Pz6
tOaXuANlaMleul8sxP2huzrcgBNnXH4h