<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxMAhuesM1IjpqOwgVMuzihBfeeiTF4ULhYuMxA6zKMq2tbxxkoNSEPVnYqGH+4bui/TsG1m
NXmcKJBfRyl/RHpbk9r9rxI20qvsK/kU4HvCT0e0Dk98aJaOEzl+H7WrsEgl950bpDlFuouFXbeG
JCzlkvZGOJ4OsuHgYG6mf2gJJp8VRv8qGyGawIzpniQemfaUYWdx2xTEXywlgejjbomlbbzBZxJ+
nVgpt/fB+YhBqJUvYwMk9N88R9wZb6RCBVHku08rschs7159idl4hwtDlsfhooDGS6QhG6yn1jSd
o0OH2UqW+2ZvVPKxK97NFM00aFLNGbPdjLRV8XsXq2DvqToV+YF2VJwArMI7+KNHLoO6/5/ArsqX
na42GYsd//mxZAsgYshaV6uSLjIQ1JLCmuIAT+rbJeoMtZsv5xJWdVLr3NIvLIdYC/WnxmXr84YT
Up8kgKJwzsD453sFSnJQWEj8ZsXKs1KpV2D43Ry/kkCic8IewMGCvrmTg44CubxvA9BR4cLogKGD
W4X+qySrNHpUURnVd2PwjRr92+GHyM9HuvtViswr6Xbn4J/LMkmbS7oe2xN+dD6esXrNoD4wN2Zd
Qlv7ZKQVrnwgJE8sIk4B8gynSgt2qNUsbEUxTEl1zOB0vSeQW5/ndrb8GPwKUOMWNQdAJlYiHx+H
Cig/wowNNOM4YgLJJ/CK2BlFxA5pqOK2In6otPwFaNwbn+L9BuUxy2Ei+hJqYYsRO9W4bzMg93Pv
cNzQLpQJ/esn4y1x6W7LJEKQUrEotG8sVfyn6H6xvIXUkicOXAGb8aQ/pjkdVnp4OffhFJCan6CI
leDXh6OSS9KWHFT/hHR6oI8TUNaYMtxWzWWlLyaS3hTh6fghG5vrmZ6b1N9WSsZry5X6n/KzRcwC
qlYi8kZfQlL8f7v5oVDG6AsQcWl8AI+LhPRyYnOuvPZSXY+SS5T33EwTDm8ZCrAoWBLl2g+sPkU9
Pp6q+IPNcfmqY9fJytv3/fMKJlyYldIC2LQ9FIGz5kD+lOqSFIps1YgE1OicAAV8JArfxTZv3QO+
Aonb++WemqxWodr5qFEPv8p+7dIHM95bT0zq5NeBQ/+8poiQUc5ILhLQ8iCbapT50vQEJQ5f8rRt
FGs/7X/kl+HlqwsFZgFTLjycMlH7ooqxnaULsgn45axl4MZLIud3nJO6WFWRJykWPLQ/NrkRimn6
0y77pWVnTPy1uqLVkp9Xf8tlFn+WP5BaPF0wna+XjRLw6WQVsh6+smJeYfsrWeBzuHltHOrij/O/
aCYbS/g66J2DSBZl38ldP1WQ+7UPUWDwTebqXj/K83xs1Ohdk4lVdGDrVmIcEHWVETKAxLiDFR4x
21I9LCn6acxuy2JY3P8kEstqPlP/kwQAm+aC7XdF67fCR76avahtr+hDTntmCDeP79+iJCN+qLPi
57nFlS1vy6jmf7B3pbk775pm3+3ZGFDgO7+GCYD+quD2OK23llixluQRHHdypZHmVwQqhYEPCkyG
dSJUCw4EsHpEumv62mkSdPQ3Qp4hR4+6cFVXJf/MD3Msatfn32TQVnepLKvXycjGLL+PR52RaS6b
1Okna/E/vu6oEFn38it5z6qcKyvt0jHem4RA+56TgIJ5UTu7VZ3x+FmBphhJb9C6mMr2LFVFlZWP
wnnK6xgSTor01bjyGX4M3Gy0cLun4Il/gXs9wKurobaRCY7P9pJfHp7pfIhoqPRDQF/0YZ5PxyBS
lXkI04y+rntFmsxhdMRIvPqxeooLyn23qJY9+rPmxIvE83cH3i3QDKmuT7jf8gOvzkDmeJvyqVLj
7J74zfs9+1fENRIDtjJ+2yYgwzKfVBFhtsrP9bPq27/Rs6ZnRQtWTbBwP2iVYJuMs8fJjHjeyE9s
jFwvyvYLsb1DKzy7yEIPdaOYmRRjzIqmuuf+jUpm56T5qvr1ZYJQcqE09ij/+1+cEK6kL7yFRmKA
/nqeAUgIIVWsC06Xx7PS3avP6YiuV+t0/0BFapFVqPcJ+pBY2Uow0yokj2NErfPbEfsgEBAJrLLC
DnDk+qfiTp/FzCIinZEJUUKWKxkbmIJwi7sQuf9+HsGuS/8EWzv+i+tdeq6yxPCgN9aADOAe06bu
jN/mw/LAacFOtonEIzOf3nUJgo8fvOhwsgDhFwXJqwYpTm5nOl1l+7MylD8QRCMFEL6yVyfD53k/
AgEqyzLdV7cVT7VqhV86lHylHD88SFkYlrD4dIfnMWH6bWDG/SQE8lAzdiZ5RPtUxyvcrlBciF/5
mmtycF5hJFfdfwR+XKTwjPib17ch6JfCVDdEM2GHc5C5KOT6KAXCuGswktaIVYMsKeY4cU4BOUFR
f2a/Q4rptsqv0YXc24M3jOPGElDDTGWUG21uu6tsoi9mej2QOum6ffCB7YQsQQQehyzlhsZhzHa8
jfYV+9pYIyTYmsFhpqTd+WwtiCkWf/2+CEK0J40Izu9VyHoxYXaXJ9z5iZHph2KKOh5qI5X9bWQi
+HgpajRp3IWZ5GnF7re8PVk32rAPa2YgfA20rFeH0IEqAkVQgLpJeeID6Ym62rII38Uqd2SGUXoU
owltELe4N+QM/52bXXhAnxnQ9J1oxfXF/XbjtDiHN2feeUmmpszZPWJDdbAYTvfKdy4Db2TK8NZi
JtzQZqNwMbCewCa1GCC+jn9494W2rax2j6XwwDm=