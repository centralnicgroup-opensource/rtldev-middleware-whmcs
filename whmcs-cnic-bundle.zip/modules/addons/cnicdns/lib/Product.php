<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoLJsm5WypysVPzE8g8w2xPI/FXqxYoa6fgumoountfLiCxQ0xmVRY/kAkMI0ecfchyj3Jrr
Izb7fWtu2bl8NCSKBpPJz6XhtakUgDOP8ErpAIAFfBc/BxptMxDzRR2IYs0fEI3uDvWFMx8QpToT
iA3ebJ+HS0nVKZH0GDciMUt3U97JPyPIZjfZtxcGD7/7vOpWRhD2n2bFDNkJHqSAw8AoMsxQAYId
ezOEjHm5dATLEPiirNzharEG/u3VhdL8ODdDgjBlBs8+zPno1ert3qkNOz9d7Jvn4ERPrV68edJX
3cX0TOdukZQ5G+lLvAgsJ3DMcbOtiRvyTlIbO44A4UByjBinsIpSaAzaY0zPlYSv3n/hfTEkJVsN
UVvdJeTT+QSpPTiiXwCCJ//ncZspLJlVK0CMXgmQBgOUKsw1ZvwHaTaB7z5g/IwuJXJZ5lb40yUv
j2Q87tJwcu1NGeVHWjMvb0ZtBz/BSVwJ+zz2FNjwB883gOFYICJO+lCxIcr/Lxn568S93tENGxi6
Ighlf+45ZcoIWcG8tmjs2KpxrGLGdty3JwS8mymRVlyn9lXrlAuUzu/TiHf5RwMeA9yJauMkZMrW
a8J+Jdl034aHDfeO+r4aki/vUJiOzsQav4PKGpCDDZg2V6018dJ/hAXdqij/qx0UnUM81z7qNayf
OkSdX1Z6JVkGkImZzZza7kJVHUp+P6ABf5O/+A6GDkKEtSVB6ZU1+IjrMTCc9fmSfCcywj57udDR
AJ23heNv/eP34xrmNg/1YoTd77mnzUAGqqPU4pOdD7hAl7S0bbWKb4h0NcUPLK+VhTsqAIzdQTF8
SJjuZiknRBhXTDf47sFiPfp6EJVF9OnCnMrw7lDGb6/b+r1wOt/355BsCLvPxqh+395xu3bRwNyj
WNoMv9N6XBE6Oi54/DD3VBiC1l+dTx0j7YL5XWFJxROz5W6ZqbTV9iRdUmJzQaJMQXoUi+bIBB3k
5Jxq8FySLv+w5VznZa/DuQjrh9uXvE6cm38TEuTBWbeuU4fZrDMg8bAwZ/lWZGsXVXWY5KxLA1BN
AtVKjMUZ7YNfXf+pA5KEis2cNNqlvjHrUlmJAGV/ATX4NxIGHzuz8tjUnFD+BUFXb0AgQCcQtz54
/76B7WLQa1wWz4KPYzQ8+nqCXimA+1yDToBBY86VvwyM9S2EMm3JVkyOgNJGEraBpuWRKKslLGrH
0p2fE0xoCWhuH6W6Tw8paS1VhHAEBM7KEj0WVJrXOQqGOckF2+PydYs1NAbwXrzcgEGfAJj4Cw+E
2N8E4bGD78QXIJqHLhMJHHWPwpBHIs09RX5fDAXi7ZbjQzA3TUyD5ujtUYitqy7Ew77Y44DVPMqC
88bQ6RAiZGbjvzZBHVyDM/WOaSDP3fE8mtgG5NnN0g+TwHgsumAgR12WTCMkYsxhDoZwgKXfawcE
TX+SZX//yp1peR5sLUerl6YVt1KwpnGlmiABvS3uftnBvjdvN4if7D4CUn0U0WL1YaUKUWL8lv4E
dw7XQSSd0yfQ5S9mNX+5/ykWrbc5AKN4LqNW5l9T1IzaUz+X3xU0A66/GD+/hxtd2jPJmwHP0fn7
3qny0T2D4LYz8GeZvn4a+eE4lFE3neZrAjh2+kqTAmqiBuQe0Qf7pceNsBL5ZTasN5J3T/LtfOLy
vZS97kdRQF5+wT1RzrF/wJXr1ZY9rkRRLVowhbb1HH0WyW2aSIJQXffo7tUeZmA7AW7Kmgn9OYD6
pl0wdjd975cEmX03UyrOKffhEHLhirlC5bFaAlrxh4tHhnD59zvFHL9IRAVLQDx+h/QzqC5CEW3f
lD8kwYIPVt19wTPAO8MnJG0ONmFsC69YC5GmkhfL8qSp5lMiE4EOKbiuJjx9mtZSrZgJMYwogV3s
nCLiE2tmLriFaQ2sdRjmni8QsrFJK9gah5Ev1u9cC+YuNl1E4x45tYwKkgWxVVm/sJDVZBL30yeo
GVom5wyTV59/WpLL3fxhnZQQNmO5shZhwpLKJb+Cqx5KrI5+R73c0bNe9F/Wj9Yf8BB4DbRWwBoy
TsVgk2K7uAG6XWp30Bz28EyCDep4O6fvIc4im5aj9KDNV2gwcCGtzfmx/otHaqE6qnVYWiw+0noV
CBFwyohDcRfvxh1uB6/sNp/jC4nqN7d3+FDXHKZBTDyoYI6Yd8K5t999x7ZwQ2sWBAluFTDYLOqC
Em8PI+rQUH8V3kMAbu2rj4mUUHmL3mn3aNtg4iV/oMwRnQiBChxwVsQAn8riIBP/q15vPv2LGy8a
hyfe6wN0rSlXrY1DKUYBKrTxYS1RD5kVlEYuiXv6250lA0Z3wFRwq1SuVUeMTO6p3WcKQwQoqFv5
nTT5PLSUxxb+XyRTsxj8sVW//rNr6yT9UwV7wayLAASe63ulbcsPSV+ZLHv47dTRojkcENhi21mY
54wdHSTeDvEnudCPputVQVPzDmBBPLZ2RpwOUhwFDKGly/7CUgJs4cnFbyAcCSeQTfJ4Yh3T9mkS
a78olM448LqFY01hTlip73Cs7TM9Hf4ihc5RbLdXe3qOpYSWt/Xwzxn+IxICpU5n4bClOsD2YzU6
MuNdS51PahXeEDOMp8CxdDUycJUHCHVWpdoWI80aFXq0ANkAKvWUILo/i9KAJ2ZL1ZTJmtsDviZ4
gV1Sk0ss4LoOD0==