<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+LcfcF1v1fKdAepG3VmgJTFEOfvvr07bUMo/OQllb1W8Pb33CJEAsLIk2PERyC25qadQDC/
AIHdgczdkrBcGJsJHJyLycXtDEtkb+5uVx8p2hsG1DywQ1Dl5OcSELfZhj+K8ofmxj50nzB7dqJc
NYt75KPWq49POizTkbhYrero7YoPJxQ69PPscAlupJr51iVF8Z0dHdECZ5BLCIQjE8UTqw02mIIJ
ZMu31rxHeDAYBmEaNmzcUUY6GIVmePM4w5LE45jjQx9jvyVm+um5jTiNvpPUP38faVEMkkJwBY4v
ZKI72Pd4JwGEDbNE8CJPfkKl3iT+sQaHXY1vOX7orw66UvdmGmG12yyl/BcK+EIe9ZIxR2L8Zllk
A6N1zwTsAZQTpKlhKgjPDbxVoA6Jwr9soHxPmzS0BfHkFS3+apB+BhG5+4OaOEXQER3ZX0Wjm4D8
wxGq3xeWcCsQ4XE34nufFgjVivFS8j/1RdTDjOuU1/H7hunpIFJ9HQvsGz29RpjbXlcOgdf5Rm+w
5JITlvTedxsh6Rvj7VQemPS3TA2Ax5sDHYCDUEg9Jhoi48JEfnA1wjowyvVBdlwSf/maxjixz/YI
Sm6G9CXwbqmXanxz1Q2vY17YeQYGWx1yosbSJrhLU3YPHY93ZAD/+a0xiN12TZDgSHl0R1nng7FL
w6gbXg0vo9BzPUM8qwf1aef3vWr8NbAOPW/mxUYTTS0SZPFiHPqEBNdZcAfU5Ccx34QXLgjHSGN7
Jt7jnnZyCtqakhS0dn5pG1y/D4S84ImpElG7s+zzsy8MS+6WDd86EEN13m0Pd/bYpArvRsxMAji3
R061CC76Wze4Sign8VdhcCZhwa5mpwVMJug3JEOFbY/0FgoKsIlmqCLoIK/eIbHZA2RSdtNgO/dq
cm1OPD8J2z7OG1AKfdVVwDVe2H5V7XrAWQTmPURBh1ueWji0roj6QR4HGm1RYo9RiqMqMCxa+AUt
GM+nniDlZN+6j0OwzDvgRya4+0YK5HQXTuc5DfeIP7AkXiKWLpwiJ/it+sjnA54xXJeYHKTMFmgz
N2MhcZCbkkyvN/uUAOOXNSIUVu5rXIrBsBdOX9GPwLMn7hoKzltaKu2dakjP1mUSc8aieAZn5I7/
22lSDdNvNbKT2EL6VkeekPYHT6GAoJuOB9gtQobNjcmZ2xeZc0kCyQvKce5ZtIOh3MiScKQKJxIs
n30k8oBfBzx/r1Bhl6AANb/JQ50DzFdmZ0m8ZOzyuMPQAlvG6QfoLiER2kKmAY5NMeBIvCfTDpQb
WCT2f0bgpiGqU49DwvM7thVX+zt21ArSVu3iB/X/T452DkRUzVz1T1DsPJTCe5d/noHY5bqjtpOE
1M5HwfQkrJ7ANr2ZiRY0QkPVyj7bNuEvzQ8YiT3D67xdpMMjgqSqEhKOXK4pn/QPb2oCNfe6OZHQ
7aH0zk44smuMLGGHkBkQdiHU0Gi8isnAsL8MEHF/CudFltcV7KqqUL49hlSpRz1TcKOPf4z7aIDd
WzVpQhUur0SzCJ5ipZQpr8+JG1ZHH82pgvw8WRWEJy4In206IhwtJeHAlJDQnVpanqvyMiSVUKWp
Prx4g3Ypg4cwGNO54qBUzMNqzD+E2d+9Jm/2nyGT2VnwyKl4Sl4aff0815ikfcAZvtZY01mfJYlV
cWAC4qTt+YGB6N/NgChXjmWjTgIFSaitLsDMd/aEscALTTl5+3slAbHY/PtfcYIyStgjCoZ9vsYa
31GcZlJqiTgDbMt1e5RvSqFB8pD9jmluia2gC5V0anfyuNl32zXs9k4OgKW+FKWVcmKxxMUepOr9
ew8KUk4k60SOjFyEkatiA8oGuEwUahcDHcI84Xt4w8bL6shuY9zUa+WkCEM8kQpTBV3CEJPns+sN
68WvULwdJvCZV80gO7qudcTFnn9yXjvBO7faqjTwB85X/Sakr6rUpqiBBYyQaHNY7KSDB8J3lte9
kx8IRNGepbtC6fdLtgqPKBz1e4tqapwIqXhlznZCySUSiz+7ORX2jbpDb8fhBWsOhbS/J+scmKou
HJjMhGdFQmxqSUMqBmgqR7eSqmPNFnguR0pJN9oe6PrE5m0qvyyznotC4Nw3ltRei7kv1AnT6/Ch
b/ehlpPgm0IdDGdKvYWId+U8q7GgyfulxXJmYKtBVF2sBu29HG/OByfHIu6Z64rFz8jN1yj9lUNi
EcHK3atCuiPs0VULa3hi3LmA5ktfAOZ369RXGXV+U6OEYUXTipgjWmA0xVaD6BKnZjE9BhyOFL0U
4GMgzCN90MjMyTqJa6M5fLehL6ziwqiS4WkwgVUYks8PmtXCDUbEbB/g34qJOvrC2Rwf7xYDCdQ8
40pTo58pkBAkBHhGv8cx7d7rVSIIwUIZUa6d2/2jUTNUwh57fhs/287SIYlZkg7x4r5ZoPoj2DC3
OP+xAkhrXAO8AMMoM2BXG0OtoKQtZkJtsZDdHR0XQBcQ3vgvFg0CkZ0HXSGj4FP7LcN4xx5O28hy
1ti42D/LX9ds9ox7/Zk5lqjYpOgOZlDCDx6Mj24c6XUg9iKVLNvH3eE/ICGR3OZMzoauzTmPTUAv
aPZsTgz+ywFVRG6RD27JbXehojHGKyyLiw2DzDm+c6WLUmmZFwAhLzNT6QjTI7xGSNS49JU5Vkow
2sWrw7tZCgSf8qwRqHJl4PgBpvoSorew2PIEh+DfmHG=