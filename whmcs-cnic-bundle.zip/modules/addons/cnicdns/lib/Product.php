<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtzccxKcv7+wFweEbg/g0Few2pqrCJ4znPEu3b88TavIzzPqyvbFLdg2t4KBMPAjfxnqNpFq
X8PuiMitKcGlW89+59i3dHUqjJ2HKOURYBcUOWKJc1RFRfsv9rOwVF6chZy//obdHPCOsvSvqPnc
TEMqEFKH7GB607z5cFB7xc3EUDYnSrCwwwY5ajWQcQztz2SW/Utz1yAYWEBC1XWd0ZFYHyxTqw00
TC44rR3qy2n1sGI2plEIk2AaD/56INcG0a0P43QPeGRaHq3h8KcuIEYSShLbnqeGzEb9MdPcwqX1
9iTxf3fS58vaxNlrxTyHHuWBtE9OL7bviq1WRPrujkgG3pNNatBn0OvdTm63AOOKTFEo5zM1aIpi
oPpkLSy+f5tTno4ZGJZa5Q1dWiNdR/0URy+b2aCPsIEGqEfzlXg4dv1JZV2CvsAa+HiS/hPrCPEs
PAy1eaXRnKv3pBZQqLaME2QHHnzsagOQffSOb8T9YmPXyxniLkDN2I8xTSXPxYdLTEhKSyePcwux
MloDH1SuY6mRu4oYJkOU0ucTr5mEuZQU8jyDtODS8R7sUrgio/lFoVEovflsjYxONSuifqll0v9H
LNpOXRL21YGg0P6bvhpHzSFNGxCVrZUalC9btCArDFMqB5QcrvYPCqiThzws/4N5Ax59cF7b47iW
UgWoEwrp3j3AHPFS5T4wPCRrDW/JmZxe+RhdYFgFJUfgaQcqpMeAwljO63wDOI9aBxPmdHh5+12Z
E3R9JJSQ2ypw79S4ZgUkMpRTftT5rrGTPjleF+cJ4fMOgM+M7qzsRoM5oLPB5eqUeNU5fbSHlCTT
TNuD2N4lZPOBxGcoWwuFj7HpGlVIGsV8f2ciRhngOPObSm+LJpfO/HvOr2A2G9maDw6J5LP87Ogr
sN7KDHXmHW712kUKRRIwOIj9aJNnvBiZFNuHIv0jP7/Io2jRwNmiHyl5TBeoopFp+LoPd0sokHzi
QYpZ/ZUzuw02vOBM3nh3jdqfIPFwmyZ2yXLl5U5uEhqtYyd30kQnEe/IQfjyjo4Yx7IlYqXfYlK9
hy3znCR28bB+lrL9mjIWnXPv2GY0GYV5FpurhnosYfL3/RXxTICvaU4ePXs243Vqyxms88IHlZYH
ijUi4Do72lC1DbPLggB5o0NkpV7W8t/HNbgywbeYKIuwjaWRq/lFfVJ+VeaTmADNF/ILYSUH0Yps
Yaas+29vgL73ATSILGtkts8P3d5DGlpN6UyK1OggEaYgLfXb6QQV7lx4JVaO25YjVtN2GTCIniVT
Oajr2qpR+lG/qJPLSjqTrTK26foGSGVpomFXiyvqFOH6CA1LGEtMomdROeSacBLmQYOihyryWFVx
J4pFkTrZsgTiKuXvGZtEt/jpsW+ACLuAlf20GRNRri8cn49AKULAqSIOnhxc5NIVY3MUcFgakJ2p
hClq+b4s+3k09OWk/k2cMabiWBnlArq5zTO5JK7BnFta9/GepfqVGJ6GZnAKHgzfqikNj9PIIs1g
CHKWZO74mJGqxs3phvRLZuL8ezsLKpJPQFqf/TnYeDnhlUPrGnNEdEGO/5tWgAap/osr7XPROwjo
ERfOiiuWqDU5X9MkCYhn5aRjDQOub6lzZLaNZ3TzG61iybrRM4Oi6R/d1PflH2XZU+pDZnsvOGUw
gY7lEuPtm9ui6Yg+Ad29gN9fOicTz6zNe8mJTVV8b5tDO/WMHmPDIt/hJpjfml/718qZ2GQEzX7B
nCy5zCfMCBe/rLH4qphccvOksd4GJ9b4amExv1BQHam9+r7NPHJgrnmNx/yGv9VVy9f/rNodZw1C
WyjPI3R/D7I3GqM8lb8ZrT6YotMRXgA3sWP4X+saDbkaH884GLO6REkUlLpZeAi5v7/xKc48vESJ
6FsXFlmALRUSkX0bgeP7nn42QrInxQex3dVetKybL7SYKgVKx600SbW7vUhVun/RBuy81/O0kVn8
69V1wGdwu0lqJ2P8P58hyPDKZ0HZ8rAkTg+PVY1UCswLfBaEBxJd1nhqRDCWdxYQTPyVR7EasAmJ
Ll+cKVsL4WkvQz5c68IJtphTseGonj/36bXBihU8xCDbOJTopQyknip3M4dg4bV4Gmg0TcszgBsr
Oq7ePoI6QfBJiGmgcJZVIds4v6z01eBHCxG6GhMB1n86NMLDNDH89La/ediG+huKjFx2P1c9WBSa
wpAHfD8oiDxirRdEE6AZS/K4vVEQkAwdrs9nQlx/E8y3ngeA5z7TpJ5dElIv6P4bR27zb7vvshvr
U5iCyEcqFIs46AIrHh5WmBEGZKADWhUfBZSbgtYuU/ciMplAQrCg9ywH+yhTrOh1qZCJ4/IUGKv5
/q0Zbh3XsoBNLsiiChx4jVGdgqsbE4quaQd6KQymroWD9GGrcBYMHCkcTNhXYqZNTqBLg7e3gCw1
qou+/dP3WQCYBdPJG1+tNzGbyzGo0+FJwtmmD2mfcbYT2aqFoj5qiLlSVo6FEAMRjaSTsWm3fM50
OE3z1La9FePWN2Pli81zGzVX71aYo7bZlK6fZJFHTOZ/yG1svNyBfoTl6gNIokgyl4/45ajyIvMy
6H8m2wiXxpuSGnbP+twS9EbG+g/BtOhjr58OWm3FhKAEN5w783lAABgtwN1mikUktS5GT/QOO39C
w3DA7OlE6IAD3SCmBBXEImingPzvss8=