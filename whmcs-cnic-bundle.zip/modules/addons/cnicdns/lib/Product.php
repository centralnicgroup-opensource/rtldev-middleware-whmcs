<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+/hU/JGUq3yhIVkrwjyXNNT55e0D/B7A9EuRQHcerAOH5yw1WNzEvBvQKoCkscIk9067N2u
DmrkLNHjzOthPgfG6Op91R0bK0ocgHSqnNKz84EJBoioRPgacfY7Dia5SqwLLnras9n6hvu3E1hK
yWy6DKVglT1wZ0OBcMZLMtq25G4hyZSDMD7SZ3HGyjTd6I1Iwesf359aWocw8gGpjnlv8l+gYz5C
4907N+8Tb8B/Ybyd7JFSyQDZh3qlXtDli2BlFHgssC1YTuRUSO5ryYqJAkzWOBiA3yKXrD2+iKqY
eATW/qeAAQCcAual8y9svnVoUGoajzvmVkCSo2pncxERUIitnRPN1FPqpvA1I5XEE4/ScGj++FsI
radnHKzIbWAIbjl1sHq4BGrcruYXeAs8hZCPBeoQM+lj7YvGpqy/uHTVlEid2l9p2906JJjT7eo5
h7meKvpgtKcEzFrr8xC7m/cBhzs+ZmoPKHWCO3jpLMnnfHjuDGGq7rvyNBNH9yxngvai4M+0jwlg
fInynxEHtEa1abI5qujD2X1zwSWz31ysuB604jRNRW/bDNO9Pai0VYUmwhFFr2tj/9Qrcb8HsOGs
znvZCvvBB8M8HrsQhdPJNFCreZFB1sPWFc/0jSL7poh2kxIX/CNyCCR3KIa2VH0KjX/k0I4V0Y5c
vZ5aLmENY+o269zba3yuDSLJ52IrGnzhGDdcgRDuyc1BcT2WlE7bM0dWEoXG1k8m/M/sO9qFYqBU
6wMU14pps4dSRobDuBKxY3eSRMJvWlQu4uuQAeAfS23nyK4k9TIu7pOXiq/hUUVBv7mWpe3f+LAX
h3e5JCo+jrbiH+Qa0RQDjij60Ui0Wd2fQlU5EmZNrFBJdVWZZPl+G0tru7T3mfKtNBadlj0ODJgA
pmaxgeq559Nkug9+Q0c9LXI7df0QnkXDzjfiJzBJ9Yx+FmK6mKnqo3Pba1ywhOxbWbyPBXpgoBZS
utYXBVLZ0Mjo/qqVDCiGNM7/kWPr962JWIbwdI4Daa1O0wRolJysYAP24CQ2OEjWBcTvsTktztIy
DkN77QMyP2gCkMc1Ui1a1NyJ63jhXPkR7UbIQuN/xydqorFnxJ4PpmAAPkDuG1yIUNH+3nkffPWl
3gtg82G7ABhDwn2c2MVz2WUwA9hZL5IsnSOPoeMCJQlH0X5QZUWMNRDEwzd3OsqQqSrIXMfAC/Ny
MXmZIu8M61Y42tCADgO0GuXR3uo+mtE27dKQeP/fBd/2PPuwrP33qmdMVyb3KN/OpEAtwUsKe0qd
Zi9M9Kc2n5LtE3VaMab4FimaUPY4DVswW5nKtFvNAZSBR2wU1N7/pV17OZfQEcP08LqweRWWvFRX
V/glKH+P9TgcFaVzxlrpAmq0LEE+B/gYih5/i/wvHAQBuKSHJiomqbd80s/fd9fGZtjy9DkEnnkn
eBLVO5o5bf+12f+T3wmwTzev4LcF6GYppCUOyZRNkCjusX2++TpDATefMEvc42/Spwwl6rA3XM6a
bnF6cmQ9pMsCu9bOK3qO1ctnS36DHYVPu+lCNC043YTdSMvD7XMD0xf8qmoLtsPdISX8WEASYFYc
v6qj31QZXsu9ks54G0glDgUdKtwADpbvrLmazRWwI0Pp4hTgxLn4TXytipPmm0pWUitgQcmpNLva
UkuYaPulWIvPAZJxwijbib+z6K1pBa26AS3TVi/bUUClwjHdS5voukLxEQI+nDvkf/60xjtjomkr
0wmK5Hk1YcWoAN1aJu057u6HRbuN/Qv09G4C3/8b2eQNopKCzkwSjtuwwa8i5aiWBsndacKKe6c4
q1nbpxuQkaBjkTbiAehRrDrVwmFdseT6lxBPpwiTo4ktceRJn/wyEbbLYU0n4fMomKYrXYdmdpHi
mQnThIecVEyGomd5ojSW6grgl6P6xBQQ+rsSsW7AaeAiaIUy1ZVL9mXwrRkZbuiSxYdMaT0+7U48
8iw1ijoAMpIvnyeDGg86OgLs5whIj/+8k3NG/yfcH0toFlWtE80tBLuCqyOO6pHftEbg1LCWXCri
OCumBw456VL2YhYYZSH+BvZ5CrimHszTaEjXCloTv90hwlO6lBOD0D5cVMGQsDO2efAycO067g0i
WwqKNxr3Z7FylLAODctZfxENj0x5boDdxlZxxCcynwBrmsdw0hr4RHzSaYi2v42KXttvYH/zatS3
XmkLD6Wx+9ljiebYWCIkXxTcsaSNGs3L+DeY9NliWQd3GLFbhycYwQF9Cg/BDZxu+JccWG0Q5TlU
pY7KnyuxG5ficoUSkd/hGhCljll3I+KIqrNSGSA1kCq8dhTqfd7R9KSvtpqFVpBTwFSo8c6f5+U5
RlLkH8wj7suzC6v6g8+4Fq2pakcJHGtSiaScvB6SYGHNFxjTpm0htV/o+e4cPS+9VXcawluL0qLO
QC0ztspHEbeDd1Gx1Q7Pm1f/FaKDaS+tl5Viy3XZnvCRiu4IVlc5tgtBCsSEtEGMval7RNC3nU8g
ij7/PrqF47X9SWdt6DggV071BWTxPQ9C6Wx1QhgDNMM4fZDfNPTJtq0bkIBoEzJA2AI0I6cY052v
AVfbZx0owNTg+5KQukQ8o3BX3CxZTcGHKi4WAV0zmusR4Fhb1oj/CwvKB2Fz99L1656Pi2tlLDXT
XMnF8puEVMQBbPuQ5ofyAAs4POGU