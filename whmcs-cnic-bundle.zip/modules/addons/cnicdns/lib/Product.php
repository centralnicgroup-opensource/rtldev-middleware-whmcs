<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrwEPev3N5kY6aBphO/cBFu2zLQ3Z/QGGUb3QY4+1wUKQkZW/YXbEfBV6E5X2kQPPDlPbO2R
bCjH5/Ba6H0TQO3dR8wHHdp3LJ/L1AiwINwO+0p/WyMx3ad26+pBaUWqLysANejaPXEhykK6wQPb
xDgI/5Nr702GGuCMUPTHw+yCvhqDfviDScSvWzMvnVfGQLMnMCOKbyWIakivx9sR0OaKnZc2REmw
VFQuAeQLjUXuPUQvDugNukfBEP1Su1vD5dgoGTy3NazPctGn2vxb75HMiM0PiHPiRCpLvMN76xjM
iDQc66TWhoSaARyxsOCLEqmsSxh3OEsYUOSQZBz6BnomBK+nGXxa7nhUp/LMNKC/xYfYMzqLra4C
6hs6DeRx7EQzGecrFhJJ54k/Wdp+XZVa0aHRgpW/HXkb0PCYA+p/M/PbRe9hj207+mbW2nb9BklU
oxoBSjFGIk4CT5AJ2ktjxC1jFpwv4X/DWTomPDBiK7gmonjCdE05+9cFq0QOK3h6H+coE/Bf8wtk
cLR/rgTa8bIBiGQ0PmSR9zp3dvASgog6Yk3iXbPcEF3ss2MJpSSv4wSPXqDl5epShrglYQdgyjnt
E/EBmZB4u33U7FEFwMmSd9NwXNCWGUZcWBIDexHTK4s9/qdi4ZgIXBIQxox/CShwBEsafQPkW57d
VhZtbkiwL67BnC+j3uGigABMWi8v7qoEcZI03NzTT7xCIFrVu/3N0orUADUJRyyL/HxjRIMLWrHq
3tAIKPgDrnBKV4I//BFdwDe0zSlmnko4T3kLbYVelcFf5ZdKvQcVQeR8Zr1C5dTAAzkTTIIHmXox
Mshxxz6lITHAfngx5cXLI5c7nWYW2G6Uvj5DDTH8/vaPBrD3dfwRG2aL3zci2vbK9pEUD0/kjcqW
G/E5IlSMxRDhw6h/Y8qDbXKQWmitwENrDqL9TtWdFlF/xdozGCCtMG6hxGBBch42mBkyqznF5DwH
ZElhxrH9nNLJ8s2hvvaPVVymZEOzQ+9g9LkDR5IBqgP1gFPzLKdbg8HGUX//NNXX7ZHj5ZtFrGwJ
YyZPTkH2MpMB+H3y4sL47jnyodXzf+dizp8YLatmZ9crRxFyzo1rj7GrQkmYLbnPMit8DdhZppjz
SSuJiTAkoNSl4WwGWphI9xYBXNnftx5dMiv2rhaX01Qjq5K9RJQGMeNWd9REiu0Wpn672icfz2G9
9VtJbm5HC5jhu1frNSjAz8fhgqJXwo2FZdVYs6CZMD8M6z6Yj/ZMRrIjQN1tZzDi+VG9hMu8lpfx
Q+DGcUhLhD5n5SVE/eQzMJrbqaYZL10227+3737peLjCUJExZWFVFXVCCSimIgGqcPEGdrcbW/oI
cxfwHXiKw9fY3b/tFJjrbxq/Bq9pGfqeWzj1bdxd7PQQ7JV4J7EKDvI49dZLQ9vPe8VXnFuWGG8/
otnS+cIPaEShj7QSLlj039qAJTKaAG+QGdnbo9Qn4XefBtFlZD+1LI3r4JSxp+zHKJkRyx+ZNPap
wdvlLQXiQdCQ6ua6+ncDDrBMCLMmBI2QimCsHDT9c84kpixVmlsvbDQLmSpu1JJxpGJR/IDdo+IA
2alj6HiV/geRQhalmZvWnug1UAjDn7Tjv4Z8khL2ocD+JyrjY2ifKeWiE6E5swfKrU5hP6MKfuT4
vvt4UNFzrrB7+NAKtNzrFelFCnB/Q96YKdC2lWf/q6pSSPgL+Vb+hA7slZeodZeNHYjAN518fWB5
XiHUV6GnxYqO880stOrCweWhku3bfu8oM+FYfqVM8NDLDb6EPkXhvOVbLnjZDl4q9C+ycGfgXFoc
G0iTHIawqmSSqeaazAfeT4oFmC1H+WffOmNbLYdY0XfF5HZPd+Z9AjgnlXi+IB+97QT3uiHYNdNr
29DEUNGwhPf+dz/+NOIeyac3jP0YkrQs4J3qYaC2miFllKRd+2pflUz/WQKqQ/58vkDdfV8aI74f
npWB0fNp/S0Avdqqyp+rxV3vloi9ifCdX/aWqb/bV1dvKfBdpE7uNx9zOpFaIxZ3UuuT3+PfK5Ox
fVVIyMcJ0VMTED3avmJlWOWW0rn/Old5lOsBHapcUC2xKiSlGq62gOi72eKpGV4+YM7JNtjjzfTn
QZ8cSXLy/ciK1Oc77Us11Y/GdmPe549Ky1fALdp+sqMbDxxa//Gs0f8ShimEYrCrSXEMpOzvpZPr
EQSNDLUVBt6uqAUAlo6/6mcRD3q5cozgRsuj+FRDZcFAjy1IcbT3v0af4UUU/qQ1/9gFtciBc+4l
RDFEVTNj3WyOOD2RHGNbo8l0JwBHxSDXf9Vhe7ithFKhRTDg3JLqWPxm3LakNOd3wsvGqu7dSJ2t
otN4QIwuOBP3jJXXY74Z30ta8Qx/s8gV8DX3aoSsIM661gp6osSLoqT+QDhFGeoK1/bxD1h9W4dp
1YzR/m1gFXSvoAMtv8a0GjiuDWmZ+xArcV54TsCcDLp5OzKSFz9qQQdIx7BKrq44zFkb9lzXwvwx
wujhHNMlONVssB8/KfIi0lTYExuUAddmm5/5BO6Lu59Ge1P53+gzE1YzkUK9VdAawzZgqi6UOeQ/
OUeVbpwqOH4WGEySWNK40/WPqSQ+4C9ARdh/clm20YWHHQzimGpOeHRqPKADC5ddvUBLCmR0ODh7
s/IC5CheR4pZALect96l3Nyt80==