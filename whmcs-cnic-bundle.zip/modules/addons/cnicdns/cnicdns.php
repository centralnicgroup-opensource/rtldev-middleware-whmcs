<?php

/**
 * CentralNic DNS Addon for WHMCS
 *
 * DNS management using WHMCS & CentralNic brands
 *
 * For more information, please refer to the online documentation.
 * @see https://centralnicgroup-public.github.io/rtldev-middleware-documentation/
 * @noinspection PhpUnused
 */

use CNIC\WHMCS\DNS\DNSHelper;
use CNIC\WHMCS\DNS\Product;
use CNIC\WHMCS\DNS\Template;
use CNIC\WHMCS\DNS\Domain;

require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]));

/**
 * Configuration of the addon module.
 * @return array<string, mixed>
 */
function cnicdns_config(): array
{
    return [
        "name" => "CNIC DNS",
        "description" => "Configure DNS templates for your domains",
        "author" => cnic_getLogoHTML(),
        "language" => "english",
        "version" => CNIC_VERSION,
        "fields" => [
            "EnforceNameservers" => [
                "FriendlyName" => "Enforce Registrar Nameservers",
                "Type" => "yesno",
                "Description" => "Sets the correct nameservers on the domain on zone creation"
            ],
        ]
    ];
}

/**
 * This function will be called with the activation of the add-on module.
 * @return array<string, string>
 */
function cnicdns_activate(): array
{
    DNSHelper::dropSchema();
    DNSHelper::createSchema();
    return ['status' => 'success', 'description' => 'Installed'];
}

/**
 * @param array<string, mixed> $vars
 */
function cnicdns_upgrade(array $vars): void
{
    DNSHelper::updateSchema($vars['version']);
}

/**
 * This function will be called with the deactivation of the add-on module.
 * @return array<string, string>
 */
function cnicdns_deactivate(): array
{
    DNSHelper::dropSchema();
    return ['status' => 'success', 'description' => 'Uninstalled'];
}

/**
 * Module interface functionality
 * @param array<string, mixed> $vars
 */
function cnicdns_output(array $vars): void
{
    global $templates_compiledir;

    if (!DNSHelper::compatibleRegistrarActive()) {
        echo "<div class=\"alert alert-danger\">{$vars['_lang']['errorRegistrar']}</div>";
        return;
    }

    switch (@$_GET['page']) {
        case 'service':
            cnicdns_output_service($_REQUEST['action'], @$_REQUEST['id'], $vars);
            break;
        default:
            $smarty = new \WHMCS\Smarty();
            $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "cnicdns"));
            $smarty->setCompileDir($templates_compiledir);
            $smarty->setCaching(Smarty::CACHING_OFF);
            $smarty->assign('lang', $vars['_lang']);
            $smarty->assign('modulelink', @$vars["modulelink"]);
            $smarty->assign('enforceNameservers', @$vars["EnforceNameservers"] === "on");

            try {
                $smarty->assign('products', Product::getAll());
                $smarty->assign('templates', Template::getAll());
            } catch (Exception $ex) {
                $smarty->assign('error', $ex->getMessage());
            }

            try {
                $smarty->display("index.tpl");
            } catch (Exception $e) {
                echo "<div class=\"alert alert-danger\">{$vars['_lang']['error']} - {$vars['_lang']['errorRender']} : {$e->getMessage()}</div>";
            }
    }
}

/**
 * Handle the XHR requests
 * @param string|null $actionName
 * @param int|null $actionId
 * @param array<string, mixed> $vars
 */
function cnicdns_output_service(?string $actionName, ?int $actionId, array $vars): void
{
    header('Content-Type: application/json');
    $response = [];
    try {
        // WORKAROUND: we get 500 when error_reporting is set to E_ALL
        // ADDED BY: asif-nawaz 08-08-2023
        http_response_code(200);
        switch ($actionName) {
            case 'getTemplates':
                $response = ['data' => Template::getAll()];
                break;
            case 'getTemplate':
                if ($actionId == null) {
                    throw new Exception('Missing parameter');
                }
                $response = Template::getWithProducts($actionId);
                break;
            case 'createTemplate':
                $response = Template::create();
                break;
            case 'editTemplate':
                if ($actionId == null) {
                    throw new Exception('Missing parameter');
                }
                $response = Template::edit($actionId);
                break;
            case 'deleteTemplate':
                if ($actionId == null) {
                    throw new Exception('Missing parameter');
                }
                $response = Template::delete($actionId);
                break;
            case 'applyTemplate':
                $response = Template::apply($_POST["templateId"], $_POST["domainName"], $_POST["enforceNs"] === "true");
                break;
            case 'getDomains':
                $response = ['data' => Domain::getAll()];
                break;
            default:
                http_response_code(404);
                $response['error'] = 'Unknown action';
        }

        echo json_encode($response);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}
