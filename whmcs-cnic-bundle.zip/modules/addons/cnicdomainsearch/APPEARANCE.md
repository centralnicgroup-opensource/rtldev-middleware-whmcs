# Domain Search — v2 Theme Appearance & Token Contract

The v2 client theme (`resources/cnic/templates/cnicdomainsearch/client_theme_v2/`) is styled
entirely through CSS custom properties (design tokens) defined in its `css/design-system.css`.
Because the search app renders inside a shadow root, custom properties set on the host element
(`<search-engine>`) pierce the shadow boundary and override the theme defaults — no template or
CSS file edits required.

## Admin Panel Settings (Addons → Domain Search → Appearance (v2 Theme))

| Setting | Stored key | Accepted values | Effect |
|---|---|---|---|
| Brand Color | `AppearanceBrandColor` | Hex color, `#[0-9a-fA-F]{3,8}` | Sets `--ds-brand` |
| Surface Color | `AppearanceSurfaceColor` | Hex color, `#[0-9a-fA-F]{3,8}` | Sets `--ds-surface` |
| Corner Radius | `AppearanceRadius` | `0px`, `4px`, `8px`, `14px` | Sets `--ds-radius` |
| Typography | `AppearanceTypography` | empty (addon fonts) or `theme` | `theme` sets `--ds-font-sans` and `--ds-font-display` to `inherit` and skips loading the bundled webfonts |

The color and radius settings default to empty ("Theme default"). When all are unset, no `<style>` block is emitted
at all. Values are validated server-side; anything not matching the patterns above is ignored.
These settings apply **only to the v2 theme** — they are never emitted for v1 or when a custom
Client Theme Path is configured.

Note: `--ds-brand-ink` (the text color placed on brand-colored surfaces) is **not** derived
automatically and stays white by default — choose a brand color dark enough for white text.
If your brand color is light, override `--ds-brand-ink` yourself (see below).

## Full Token List

| Token | Meaning |
|---|---|
| `--ds-font-sans` | UI typeface for the whole app. Ships as Inter; set to `inherit` to hand typography back to your WHMCS theme |
| `--ds-font-display` | Display typeface for the landing headline and the searched domain. Ships as Fraunces |
| `--ds-radius-lg` | Corner radius for large surfaces (search shell, hero card) |
| `--ds-shadow-sm` / `--ds-shadow-md` | The two elevation steps |
| `--ds-ease`, `--ds-duration-fast` / `--ds-duration` / `--ds-duration-slow` | Motion curve and durations |
| `--ds-brand` | Primary brand color (buttons, active tabs, focus rings) |
| `--ds-brand-ink` | Text/icon color placed on top of `--ds-brand` |
| `--ds-ink` | Primary body text color |
| `--ds-muted` | Secondary/muted text color |
| `--ds-line` | Border and divider color |
| `--ds-surface` | Primary card/panel background |
| `--ds-surface-2` | Secondary/recessed background (page areas, wells) |
| `--ds-radius` | Base corner radius for cards, inputs, and buttons |
| `--ds-good` | "Available"/success foreground color |
| `--ds-good-bg` | Success badge/alert background |
| `--ds-promo` | Promotion/sale foreground color |
| `--ds-promo-bg` | Promotion badge background |
| `--ds-danger` | "Taken"/error foreground color |
| `--ds-danger-bg` | Error badge/alert background |
| `--ds-info` | Informational accent color |

## Overriding More Than the Admin Panel Offers

Add a rule targeting the host element from any stylesheet on the client-area page (e.g. your
WHMCS theme's `custom.css`):

```css
search-engine {
    --ds-brand: #7a1f8a;
    --ds-brand-ink: #ffffff;
    --ds-surface: #fffdf8;
    --ds-surface-2: #f6f1e8;
    --ds-radius: 12px;
    --ds-good: #157347;
}
```

### Typography

The v2 theme ships and loads its own typefaces (Inter for UI, Fraunces for the landing
headline and the searched domain) instead of inheriting your WHMCS theme's font. Consistent
type is most of what separates a designed product from an embedded widget, so this is the
default.

To use your own face, or to hand typography back to your theme:

```css
search-engine {
    /* your own brand face */
    --ds-font-sans: "Your Brand Sans", system-ui, sans-serif;
    --ds-font-display: "Your Brand Display", Georgia, serif;

    /* ...or defer entirely to the surrounding WHMCS theme */
    /* --ds-font-sans: inherit; */
    /* --ds-font-display: inherit; */
}
```

Load any custom `@font-face` from your **WHMCS theme's** stylesheet, not from the addon's
`custom.css`. The addon's stylesheets are inlined into a shadow root, and browsers only
register font faces declared at document level.

Custom-property overrides on `search-engine` always win over the theme defaults and combine
with (or supersede) the admin-panel settings.

## Template Overrides

If you override v2 HTML component templates (via a custom Client Theme Path), reference the
existing `ds-*` classes and `--ds-*` tokens rather than hard-coding colors or radii, so your
overrides keep responding to admin-panel and CSS branding automatically.
