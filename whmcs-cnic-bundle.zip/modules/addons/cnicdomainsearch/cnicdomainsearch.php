<?php

/**
 * Require any libraries needed for the module to function.
 * require_once __DIR__ . '/path/to/library/loader.php';
 *
 * Also, perform any initialization required by the service's library.
 */

use WHMCS\Module\Addon\CnicDomainSearch\Client\Dispatcher as ClientDispatcher;
use WHMCS\Module\Addon\CnicDomainSearch\Admin\Dispatcher as AdminDispatcher;
use Illuminate\Database\Capsule\Manager as DB;
use WHMCS\Module\Addon\CnicDomainSearch\Admin\Controller;
use WHMCS\Module\Addon\CnicDomainSearch\Client\Helper;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]));
require_once(implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes","domainfunctions.php"]));

/**
 * Cnic Domain Search Configurations
 *
 * @return array
 */
function cnicdomainsearch_config()
{
    return [
        // Display name for your module
        'name' => 'CNIC Domain Search',
        "description" => "This addon provides domain search with a new interface with high speed checks, suggestions and premium support.",
        "version" => CNIC_VERSION,
        "language" => "english",
        "author" => cnic_getLogoHTML()
    ];
}

/**
 * Client Area Output.
 *
 * @see CnicDomainSearch\Client\Controller::index()
 *
 * @return array
 */
function cnicdomainsearch_clientarea($vars)
{
    add_hook('ClientAreaHeadOutput', 1, function ($vars) {
        $rootPath = rtrim($vars["systemurl"], "//");
        $userThemePath = $themeJson["path"] ?? null;
        $defaultThemePath = $rootPath . Helper::getSetting("ClientThemePath", true, cnic_getTemplateDir(null, "cnicdomainsearch", "client_theme"));
        $jsPath = cnic_getAssetPath("js", "cnicdomainsearch", "client_app");
        $templatesPath = $userThemePath ? $userThemePath : $defaultThemePath;
        $fontawesomePath = $rootPath . \DI::make("asset")->getCssPath() . "/fontawesome-all.min.css";
        $themeJson = json_decode(file_get_contents($defaultThemePath . "theme.json"), true);
        $themeVersion = $themeJson["version"] ?? date('ymdh', time());
        $moduleVersion = CNIC_VERSION;
        return <<<HTML
        <script>
            const cnicWebRootPath = "{$rootPath}";
            const cnicSearchClientThemePath = "{$templatesPath}";
            const activeLanguage = "{$vars['activeLocale']['language']}";
            const themeVersion = "{$themeVersion}";
            const cnicFontawesomePath = "{$fontawesomePath}";
        </script>
    <script type="module" src="{$jsPath}/index.js?version={$moduleVersion}"></script>
HTML;
    }, $vars);
    //init smarty and call admin dispatcher
    $smarty = new \WHMCS\Smarty();
    $smarty->escape_html = true;
    $smarty->caching = false;
    $smarty->setCompileDir($GLOBALS['templates_compiledir']);
    $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "cnicdomainsearch") . "/");
    $smarty->assign($vars);
    //call the dispatcher with action and data
    $dispatcher = new ClientDispatcher();
    $r = $dispatcher->dispatch($vars['POST_DATA']['action'], $vars, $smarty);
    // WORKAROUND: we get 500 when error_reporting is set to E_ALL
    // ADDED BY: asif-nawaz 08-08-2023
    http_response_code(200);
    if ($vars['POST_DATA']['action']) {
        return json_encode($r);
    }
    return $r;
}

/**
 * Admin Area output
 */
function cnicdomainsearch_output($vars)
{
    add_hook('AdminAreaHeadOutput', 1, function ($vars) {
        $cfg = cnicdomainsearch_config();
        $cssAdminPath = cnic_getAssetPath("css", "cnicdomainsearch", "admin");
        $jsAdminPath = cnic_getAssetPath("js", "cnicdomainsearch", "admin");
        $version = $cfg["version"];
        $wr = $vars['WEB_ROOT'];
        $fontawesomePath = "$wr" . \DI::make("asset")->getCssPath() . "/fontawesome-all.min.css";
        return <<<HTML
        <!-- JS -->
        <script>const wr = "{$wr}";</script>
        <script>const cnicFontawesomePath = "{$fontawesomePath}";</script>
        <script src="{$jsAdminPath}/web-animations.min.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/uts46bundle.min.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/muuri.min.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/jquery-ui.min.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/mustache.min.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/jquery.mustache.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/tplmgr.js?ts={$version}"></script>
        <script src="{$jsAdminPath}/index.js?ts={$version}"></script>
        <!-- CSS -->
        <link href="{$cssAdminPath}/jquery-ui.min.css?ts={$version}" rel="stylesheet" type="text/css" />
        <link href="{$cssAdminPath}/categories.css?ts={$version}" rel="stylesheet" type="text/css" />
        <link href="{$cssAdminPath}/index.css?ts={$version}" rel="stylesheet" type="text/css" />
HTML;
    });

    //init smarty and call admin dispatcher
    $smarty = new \WHMCS\Smarty();
    $smarty->escape_html = true;
    $smarty->caching = false;
    $smarty->setCompileDir($GLOBALS['templates_compiledir']);
    $smarty->setTemplateDir(cnic_getTemplateDir($smarty->getTemplateDir(), "cnicdomainsearch", "admin"));
    $smarty->assign($vars);
    //call the dispatcher with action and data
    $dispatcher = new AdminDispatcher();
    $r = $dispatcher->dispatch($_REQUEST['action'], $vars, $smarty);
    if ($_REQUEST['action']) {
        //send json response headers
        header('Cache-Control: no-cache, must-revalidate'); // HTTP/1.1
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Content-type: application/json; charset=utf-8');
        //do not echo as this would add template html code around!
        // WORKAROUND: we get 500 when error_reporting is set to E_ALL
        // ADDED BY: asif-nawaz 08-08-2023
        http_response_code(200);
        die(json_encode($r));
    }
    echo $r;
}

function cnicdomainsearch_activate()
{
    // Create table and import default categories
    if (!DB::schema()->hasTable('cnic_tblcategories')) {
        DB::schema()->create('cnic_tblcategories', function ($table) {
            $table->id();
            $table->text('name')->charset('utf8mb3')->collation('utf8mb3_unicode_ci');
            $table->text('tlds')->charset('utf8mb3')->collation('utf8mb3_unicode_ci');
            $table->integer('position')->default(1);
            $table->text('settings')->collation('utf8mb3_unicode_ci');
        });
        (new Controller())->importdefaults();
    }
    return ['status' => 'success'];
}

function cnicdomainsearch_deactivate()
{
    DB::schema()->dropIfExists('cnic_tblcategories');
    return ['status' => 'success'];
}
