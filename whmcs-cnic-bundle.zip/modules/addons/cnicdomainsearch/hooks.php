<?php

use WHMCS\Module\Addon\CnicDomainSearch\Common\Helper;

add_hook("ClientAreaSecondarySidebar", 1, function ($navbar) {
    $transfersFeature = (bool) Helper::getSetting("FeatureBulkTransfers", true, "1");
    $whoisFeature = (bool) Helper::getSetting("FeatureWhoIs", true, "1");

    $navItem = $navbar->getChild("Client Shortcuts") ?? $navbar->getChild("My Domains Actions") ?? $navbar->getChild("Actions");
    if (is_null($navItem)) {
        return;
    }
    $children = $navItem->getChildren();

    $transferFound = false;
    foreach ($children as $c) {
        $itemName = $c->getName();
        if (preg_match("/Register(.*)Domain|Domain Registration/i", $itemName)) {
            $c->setUri("mydomainsearch.php?action=register");
        }

        if ($transfersFeature && preg_match("/Transfer(.*)Domain|(.*)Domain Transfer/i", $itemName)) {
            $c->setUri("mydomainsearch.php?action=transfer&bulk=1");
            $c->setOrder(31);
            $transferFound = true;
        }
    }

    if ($transfersFeature && !$transferFound) {
        $navItem->addChild(
            "bulkDomainsTransfer",
            array(
                "name" => "Transfer in a Domain",
                "label" => "&nbsp;" . \Lang::trans("Transfer in a Domain"),
                "uri" => "mydomainsearch.php?action=transfer&bulk=1",
                "order" => 21,
                "icon" => "fa-share"
            )
        );
    }

    if ($whoisFeature) {
        $navItem->addChild(
            "checkDomainWhois",
            array(
                "name" => "Domain Whois Lookup",
                "label" => "&nbsp;" . \Lang::trans("Domain Whois Lookup"),
                "uri" => "mydomainsearch.php?action=whois",
                "order" => 22,
                "icon" => "fa-search-plus"
            )
        );
    }
});

add_hook("ClientAreaPrimaryNavbar", 1, function ($navbar) {
    $transfersFeature = (bool) Helper::getSetting("FeatureBulkTransfers", true, "1");
    $whoisFeature = (bool) Helper::getSetting("FeatureWhoIs", true, "1");

    $navItem = $navbar->getChild("Domains") ?? $navbar->getChild("Store");
    if (is_null($navItem)) {
        return;
    }
    $children = $navItem->getChildren();
    foreach ($children as $c) {
        $itemName = $c->getName();
        if (preg_match("/Register(.*)Domain|Domain Registration/i", $itemName)) {
            $c->setUri("mydomainsearch.php?action=register");
        }

        if ($transfersFeature && preg_match("/Transfer(.*)Domain|(.*)Domain Transfer/i", $itemName)) {
            $c->setUri("mydomainsearch.php?action=transfer&bulk=1");
        }

        if ($itemName === "Domain Search") {
            $c->setUri("mydomainsearch.php");
        }
    }

    if ($whoisFeature) {
        $navItem->addChild(
            "checkDomainWhois",
            array(
                "name" => "Domain Whois Lookup",
                "label" => \Lang::trans("Domain Whois Lookup"),
                "uri" => "mydomainsearch.php?action=whois",
                "order" => 71
            )
        );
    }
});
