<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Common;

use Illuminate\Database\Capsule\Manager as DB;

class Helper
{
    // settings prefix
    public static $prefix = "cnicdomainsearch"; // addon id

    public static function getTLDList($onlyTlds = true)
    {
        $tlds = DB::table('tbldomainpricing')->distinct()->select("order", DB::raw("SUBSTR(extension, 2) as tld"))->orderBy('order', 'asc')->get();
        $tlds = self::objectToArray($tlds);
        if ($onlyTlds) {
            $tlds = array_map(function ($item) {
                return $item['tld'];
            }, $tlds);
        }
        return $tlds;
    }

    public static function getCategoriesList()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION["cnic_cache"]["tldCategoriesList"])) {
            $categories = DB::table('cnic_tblcategories')->select("id", "name")->distinct()->orderBy('id', 'asc')->get();
            $categories = self::objectToArray($categories);
            $_SESSION["cnic_cache"]["tldCategoriesList"] = $categories;
        } else {
            $categories = $_SESSION["cnic_cache"]["tldCategoriesList"];
        }

        return $categories;
    }

    /**
     * save a configuration setting
     *
     * @param string $key configuration setting id
     * @param string $val configuration setting value
     * @return array operation result
     */
    public static function saveSetting($key, $val, $doPrefix = true)
    {
        $realkey = ($doPrefix ? self::$prefix : "") . $key;
        $setting = \WHMCS\Config\Setting::setValue($realkey, $val);
        if ($setting->value == $val) {
            return [
                "success" => true,
                "msg" => "Setting saved successfully."
            ];
        }
        return [
            "success" => false,
            "msg" => "Update not processed."
        ];
    }

    /**
     * get a configuration setting by key
     *
     * @param string $key configuration setting id
     * @param boolean $doPrefix use our settings prefix
     * @param mixed $defaultValue default value if setting not present
     * @return string settings value
     */
    public static function getSetting($key, $doPrefix = true, $defaultValue = null)
    {
        global $CONFIG;
        $realkey = ($doPrefix ? self::$prefix : "") . $key;
        if (!isset($CONFIG[$realkey]) && !is_null($defaultValue)) {
            return $defaultValue;
        }
        return $CONFIG[$realkey];
    }

    /**
     * loadtranslations action.
     *
     * @param array $vars Module configuration parameters
     * @param smarty smarty instance
     * @return array
     */
    public static function loadtranslations($vars)
    {
        //translation texts
        return $vars["_lang"];
    }

    /**
     * Returns the domainchecker mode.
     *
     * @return string The domainchecker mode
     */
    public static function isValidLookupProvider($returnProvider = false)
    {
        $registrar = \WHMCS\Config\Setting::getValue('domainLookupRegistrar');
        if ($registrar === "ispapi" || $registrar === "cnic") {
            if ($returnProvider) {
                return $registrar;
            }
            return true;
        }
        return false;
    }

    public static function objectToArray($data)
    {
        if (is_object($data)) {
            $data = json_decode(json_encode($data), true); // object to array
        }
        return $data;
    }

    public static function sessionTimeoutCheck($force = false)
    {
        $timeout = isset($_SESSION["cnic_cache"]["ttl"]) ? time() > ($_SESSION["cnic_cache"]["ttl"] + 10 * 60) : true; // delete data after timeout
        if ($timeout === true || $force) {
            unset($_SESSION["cnic_cache"]);
            return ["success" => "cache cleared successfully"];
        }
    }
}
