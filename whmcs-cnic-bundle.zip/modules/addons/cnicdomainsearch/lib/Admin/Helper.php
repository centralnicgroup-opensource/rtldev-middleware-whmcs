<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Admin;

use WHMCS\Module\Addon\CnicDomainSearch\Common\Helper as Help;
use Illuminate\Database\Capsule\Manager as DB;

class Helper extends Help
{
    public static function load()
    {
        //import default categories
        $categories = self::getCategoriesWithTlds();
        $allTlds = parent::getTLDList();

        // collect current configuration data
        // and build list of tlds in use by this configuration
        // TODO: rename table
        // TODO: auto-rename ispapi settings
        $alltldsinuse = [];
        $defcats = array_map(function ($cat) use (&$alltldsinuse) {
            $alltldsinuse = array_merge($alltldsinuse, $cat['tlds']);
            return $cat['id'];
        }, $categories);

        usort($categories, function ($a, $b) {
            return $a["position"] <=> $b["position"];
        }); // sort categories by position

        $alltldsinuse = array_values(array_unique($alltldsinuse));

        // default active categories
        $defaultCategories = array_filter($categories, function ($cat) {
            return $cat['settings']['default'] ?? true;
        });
        $defaultCategoryIds = array_column($defaultCategories, 'id');

        //build response format
        return [
            // all configured tlds
            "alltlds" => $allTlds,
            //not-assigned tlds
            "notassignedtlds" => array_values(array_diff($allTlds, $alltldsinuse)),
            // load categories + tlds + prices
            "categories" => $categories,
            // lookup registrar
            "lookupRegistrar" => parent::getSetting("domainLookupRegistrar", false),
            // default active Categories
            "defaultActiveCategories" => $defaultCategoryIds,
            // search engine features
            "features" => [
                "RegularSearch" =>  (int) parent::getSetting("FeatureRegularSearch", true, "1"),
                "Suggestions" => (int) parent::getSetting("FeatureSuggestions", true, "1"),
                "BulkTransfers" => (int) parent::getSetting("FeatureBulkTransfers", true, "1"),
                "WhoIs" => (int) parent::getSetting("FeatureWhoIs", true, "1"),
                "Home" => (int) parent::getSetting("FeatureHome", true, "1")
            ],
            // premium domains availability
            "premiumDomains" => (int) parent::getSetting("PremiumDomains", false),
            //taken domains availability
            "takenDomains" => (int) parent::getSetting("TakenDomains", true, "1"),
            // search result's transfer button
            "domainTransfers" => (int) parent::getSetting("DomainTransfers", true, "1"),
            // spotlight tlds on regular search/suggestion/bulktransfers container
            "containerSpotlight" => (int) parent::getSetting("ContainerSpotlight", true, "1"),
            // promotions container
            "promotions" => (int) parent::getSetting("Promotions", true, "1"),
            // search logs
            "searchLogs" => (int) parent::getSetting("SearchLogs", true, "0"),
            // default client theme path
            "clientThemePath" => parent::getSetting("ClientThemePath", true, cnic_getTemplateDir(null, "cnicdomainsearch", "client_theme")),
        ];
    }

    public static function getCategoriesWithTlds()
    {
        $categories = DB::table('cnic_tblcategories')->distinct()->orderBy('id', 'asc')->get();
        $categories = parent::objectToArray($categories);
        $categories = array_map(function ($cat) {
            $tlds = [];
            if (!empty($cat["tlds"])) {
                $tlds = explode(" ", trim($cat["tlds"]));
            }
            $cat["tlds"] = $tlds;
            $cat["name"] = htmlspecialchars_decode($cat["name"]);
            $cat["settings"] = json_decode($cat["settings"], true);
            return $cat;
        }, $categories);

        return $categories;
    }
}
