<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Admin;

use Illuminate\Database\Capsule\Manager as DB;

/**
 * Admin Area Controller
 */
class Controller
{
    /**
     * Index action.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return string page content
     */
    public function index($vars, $smarty)
    {
        $smarty->assign("modulelink", $vars['modulelink']);
        //get all categories with tlds for displaying
        // TODO: rename table
        $categories = Helper::getCategoriesWithTlds();
        $smarty->assign("categories", $categories);
        return $smarty->fetch('index.tpl');
    }

    /**
     * action savetakendomains.
     * save configuration value for setting `ispapiDomaincheckTakenDomain`
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function savefeatures($vars, $smary)
    {
        $result = [
            "success" => false,
            "msg" => "Update not processed."
        ];
        foreach ($_REQUEST["features"] as $key => $val) {
            $result = Helper::saveSetting("Feature" . $key, $val);
            if ($result["success"] === false) {
                break;
            }
        }
        return $result;
    }

    /**
     * action saveCategoriesOrder.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function saveCategoriesOrder($vars, $smary)
    {
        $categoryWithOrder = [];
        foreach ($_REQUEST["categories"] as $position => $category) {
            $position++;
            $categoryWithOrder[$category['id']] = $position;
            DB::table("cnic_tblcategories")->where("id", $category)->update(["position" => $position]);
        }

        return [
            "success" => true,
            "msg" => "Categories order saved successfully."
        ];
    }

    /**
     * action saveSetting.
     * save configuration value for config settings
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function saveSetting($vars, $smarty)
    {
        $doPrefix = $_REQUEST["prefix"] ?? 1; // prefix by default
        $doPrefix = (bool) ((int) $doPrefix);
        if ($_REQUEST["type"] === "PremiumDomains" && !((bool) $_REQUEST["value"])) {
            Helper::saveSetting("FeatureAftermarket", 0);
        }
        return Helper::saveSetting($_REQUEST["type"], $_REQUEST["value"], $doPrefix);
    }

    /**
     * action savedefaultcategories.
     * save configuration value for setting `ispapiDomaincheckDefaultCategories`
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function savedefaultcategories($vars, $smarty)
    {
        $categories = DB::table("cnic_tblcategories")->get();
        $categories = Helper::objectToArray($categories);
        $paramCategories = $_REQUEST["categories"] ?? [];
        foreach ($categories as $category) {
            $category["settings"] = json_decode($category["settings"], true) ?? [];
            $category["settings"]["default"] = count($paramCategories) > 0 ? in_array($category["id"], $paramCategories) : true;
            DB::table("cnic_tblcategories")->where("id", $category["id"])->update(["settings" => json_encode($category["settings"])]);
        }

        return [
            "success" => true,
            "msg" => "Setting saved successfully."
        ];
    }

    /**
     * action addcategory.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function addcategory($vars, $smarty)
    {
        if (isset($_REQUEST["category"])) {
            $icon = ["icon" => $_REQUEST["icon"]];
            $settings = array_merge(["default" => true], !empty($_REQUEST["icon"]) ? $icon : []);
            // TODO: rename table
            $maxPosition = DB::table("cnic_tblcategories")->max('position');
            $insertId = DB::table("cnic_tblcategories")->insertGetId([
                "name" => $_REQUEST["category"],
                "tlds" => isset($_REQUEST["tlds"]) ? implode(" ", $_REQUEST["tlds"]) : "",
                "settings" => json_encode($settings),
                "position" => $maxPosition + 1
            ]);
            // TODO: rename table
            return [
                "success" => true,
                "msg" => "Category added.",
                "category" => $insertId
            ];
        }
        return [
            "success" => false,
            "msg" => "Adding Category failed."
        ];
    }

    /**
     * action addcategory.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function editcategory($vars, $smarty)
    {
        if (isset($_REQUEST["id"])) {
            $settings = ["icon" => $_REQUEST["icon"]];
            $update = DB::table("cnic_tblcategories")->where('id', $_REQUEST["id"])->update([
                "name" => $_REQUEST["name"],
                "settings" => (!empty($_REQUEST["icon"]) ? json_encode($settings) : null)
            ]);
            if ($update) {
                return [
                    "success" => true,
                    "msg" => "Category updated."
                ];
            }
        }
        return [
            "success" => false,
            "msg" => "Updating category failed."
        ];
    }

    /**
     * action updatecategory.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function updatecategory($vars, $smarty)
    {
        if (isset($_REQUEST["category"])) {
            $id = (int)$_REQUEST["category"];
            // TODO: rename table
            DB::table("cnic_tblcategories")
                ->where("id", $id)->update([
                    "id" => $id,
                    "tlds" => isset($_REQUEST["tlds"]) ? implode(" ", $_REQUEST["tlds"]) : "" //jquery removes empty arrays
                ]);
            return [
                "success" => true,
                "msg" => "Category update processed."
            ];
        }
        return [
            "success" => false,
            "msg" => "Category update failed."
        ];
    }

    /**
     * action deletecategory.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result
     */
    public function deletecategory($vars, $smarty)
    {
        if (isset($_REQUEST["category"])) {
            // TODO: rename table
            DB::table("cnic_tblcategories")
                ->where("id", (int)$_REQUEST["category"])
                ->delete();
            return [
                "success" => true,
                "msg" => "Category deletion processed."
            ];
        }
        return [
            "success" => false,
            "msg" => "Category deletion failed."
        ];
    }

    /**
     * Returns admin configuration
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array configuration
     */
    public function loadconfiguration($vars, $smarty)
    {
        return Helper::load();
    }

    /**
     * action importdefaults.
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array operation result or configuration object
     */
    public function importdefaults($vars = null, $smarty = null)
    {
        // build list of tlds configured in WHMCS (so available for use)
        $tldCategories = new \WHMCS\Domain\TopLevel\Categories();
        $allTlds = Helper::getTLDList();
        $categories = $tldCategories->getCategoriesByTlds($allTlds);
        ksort($categories);
        // TODO: rename table
        DB::table("cnic_tblcategories")->delete();
        DB::update("ALTER TABLE cnic_tblcategories AUTO_INCREMENT = 1;");
        $order = 0;
        foreach ($categories as $category => &$tlds) {
            $order++;
            $tlds = preg_replace("/^\./", "", $tlds);
            DB::table("cnic_tblcategories")->insert([
                "name" => $category,
                "tlds" => implode(" ", $tlds),
                "position" => $order,
                "settings" => json_encode(["default" => true])
            ]);
        }
        if (!$smarty && !$vars) {
            return [
                "success" => true,
                "msg" => "Default category import processed successfully."
            ];
        }
        return Helper::load();
    }
}
