<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Config;

use WHMCS\Module\Addon\CnicDomainSearch\Client\Helper as ClientHelper;
use WHMCS\Module\Addon\CnicDomainSearch\Common\Helper;

class Configuration
{
    protected static function defaults()
    {
        // search engine tabs
        $featureHome = true;
        $featureBulkTransfers = true;
        $featureWhoIs = true;
        $featureSuggestions = true;
        $featureRegularSearch = true;
        $featureAftermarket = true;

        // additional search engine config
        $showDomainTransfers = true; // transfer button in the search results
        // Add a section below the "Regular Domain Search/Transfers/Suggestions" tab to highlight top-level domains (TLDs) available for registration.
        // This section can be called "Featured/Spotlight TLDs."
        $showContainerSpotlight = true;
        $showPremiumDomains = true;
        $showTakenDomains = true;

        // promotions container below all tabs except whois
        $showPromotions = false;

        $spotlightTlds = ClientHelper::spotlightTldsWithPricing();

        // collect current configuration data
        // and build list of tlds in use by this configuration
        $categoriesWithTlds = ClientHelper::getCategoriesWithTlds(true, $spotlightTlds);

        // lookup provider
        $lookupProvider = Helper::isValidLookupProvider();

        // get domains in the cart session
        $cartDomains = ClientHelper::cartHandler(["POST_DATA" => ["type" => "list"]]);

        return [
            "categories" => $categoriesWithTlds,
            "cartData" => $cartDomains,
            "lookupprovider" => $lookupProvider,
            "spotlightTlds" => $spotlightTlds,
            "features" => [
                "BulkTransfers" => $featureBulkTransfers,
                "Home" => $featureHome,
                "WhoIs" => $featureWhoIs,
                "Suggestions" => $featureSuggestions,
                "RegularSearch" => $featureRegularSearch,
                "Aftermarket" => $featureAftermarket
            ],
            "showContainerSpotlight" => $showContainerSpotlight,
            "showPremiumDomains" => $showPremiumDomains,
            "showDomainTransfers" => $showDomainTransfers,
            "showTakenDomains" => $showTakenDomains,
            "showPromotions" => $showPromotions,
            "tldsWithoutEppCode" => ClientHelper::tldsWithoutEppCode()
        ];
    }

    public static function load()
    {
        $provider = Helper::isValidLookupProvider(true);
        if ($provider === "ispapi") {
            return Hexonet::config();
        } elseif ($provider === "cnic") {
            return CNIC::config();
        }
        return ["lookupprovider" => false];
    }
}
