<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Config;

use WHMCS\Module\Addon\CnicDomainSearch\Common\Helper;

class Hexonet extends Configuration
{
    protected static function config()
    {
        $defaults = parent::defaults();

        // search engine features
        $defaults["features"] = [
            "RegularSearch" => (bool) Helper::getSetting("FeatureRegularSearch", true, "1"),
            "Suggestions" => (bool) Helper::getSetting("FeatureSuggestions", true, "1"),
            "BulkTransfers" => (bool) Helper::getSetting("FeatureBulkTransfers", true, "1"),
            "WhoIs" => (bool) Helper::getSetting("FeatureWhoIs", true, "1"),
            "Home" => (bool) Helper::getSetting("FeatureHome", true, "1")
        ];

        // premium domains availability
        $defaults["showPremiumDomains"] = (bool) Helper::getSetting("PremiumDomains", false);
        // taken domains availability
        $defaults["showTakenDomains"] = (bool) Helper::getSetting("TakenDomains", true, "1");
        // search result's transfer button
        $defaults["showDomainTransfers"] = (bool) Helper::getSetting("DomainTransfers", true, "1");
        // spotlight tlds on regular search/suggestion/bulktransfers container
        $defaults["showContainerSpotlight"] = (bool) Helper::getSetting("ContainerSpotlight", true, "1");
        // promotions container
        $defaults["showPromotions"] = (bool) Helper::getSetting("Promotions", true, "1");

        return $defaults;
    }
}
