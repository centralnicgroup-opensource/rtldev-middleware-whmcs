<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Client;

/**
 * Client Area Controller
 */
class Controller
{
    /**
     * Index action.
     *
     * @param array $vars Module configuration parameters
     *
     * @return array
     */
    public function index($vars, $smarty)
    {
        return [
            "vars" => [
                "_lang" => $vars["_lang"],
                "modulelink" => $vars["modulelink"],
                "modulepath" => "/modules/addons/cnicdomainsearch/",
                "components_path" => implode(DIRECTORY_SEPARATOR, [
                    cnic_getAssetPath(), "templates", "cnicdomainsearch", "client", "components"
                ]),
                "domain" => isset($vars["POST_DATA"]["domain"]) ? $vars["POST_DATA"]["domain"] : "",
                "currency" => $_SESSION["currency"],
            ]
        ];
    }

    /**
     * search action.
     *
     * @param array $vars Module configuration parameters
     * @param smarty smarty instance
     * @return array
     */
    public function register($vars, $smarty)
    {
        $jsonData = [];
        $lookupProvider = Helper::isValidLookupProvider(true);
        $registrar = new \WHMCS\Module\Registrar();
        $registrar->load($lookupProvider);
        $params = $registrar->getSettings();
        $searchTerms = Helper::getSearchTerm($vars["POST_DATA"]["search"]);
        Helper::logSearch($vars["POST_DATA"]["rawSearchTerm"], "Regular Search"); // log keywords

        $params["lookupProvider"] = $lookupProvider;
        $params["showUnavailable"] = true;
        $params["requestType"] = "availability";
        $advancedOptions = explode(",", $vars["POST_DATA"]["advancedOptions"]);
        $params["premiumEnabled"] = (bool) Helper::getSetting("PremiumDomains", false);
        $params["suggestionSettings"]["suggestionsnoweighted"] = in_array("noWeightedDomains", $advancedOptions) ? true : false;

        $domains = [];
        if (!$searchTerms) {
            return;
        }

        foreach ($searchTerms as $term) {
            if ($term["exact"]) {
                $domains[$term["exact"]] = $term["exact"];
            } else {
                $domains[] = $term["suggest"];
            }
        }

        $params["domains"] = $domains;
        $results = Helper::cachedResults($params);

        if (count($results) > 0) {
            $exactDomainKeys = implode(" ", array_keys($domains));
            foreach ($results as $domain) {
                $availabilityReason = $domain->availabilityReason ?? "";
                $domainArray = $domain->toArray();
                // Define the domain name and its IDN variant
                $domainName = $domainArray['domainName'];
                $idnDomainName = $domainArray['idnDomainName'];

                // Create a regex pattern to match either the domain name or its IDN variant case-insensitively
                // Check if the pattern matches in the exact domain keys
                $type = (preg_match("/{$domainName}|{$idnDomainName}/i", $exactDomainKeys)) ? "exact" : "suggestions";

                $domainArray["isAftermarket"] = $domain->isAftermarket ?? false;
                // $domainArray["isAvailable"] = $domainArray["isAftermarket"] || $domainArray["isAvailable"]; // do not show aftermarket domains as available
                $domainArray["availabilityReason"] = $availabilityReason;
                Helper::getDomainPricing($domainArray);
                if ($domainArray) {
                    $jsonData[$type][$idnDomainName] = $domainArray;
                }
            }
        }

        return $jsonData;
    }

    /**
     * getsuggestions action.
     *
     * @param array $vars Module configuration parameters
     * @param smarty smarty instance
     * @return array
     */
    public function suggestions($vars, $smarty)
    {
        $jsonData = [];
        $lookupProvider = Helper::isValidLookupProvider(true);
        $registrar = new \WHMCS\Module\Registrar();
        $registrar->load($lookupProvider);
        $params = $registrar->getSettings();
        $searchTerms = Helper::getSearchTerm($vars["POST_DATA"]["searchTerm"]);
        $spotlights = getSpotlightTldsWithPricing();
        Helper::logSearch($vars["POST_DATA"]["rawSearchTerm"], "Suggestions"); // log keywords

        // get categories with tlds, flatten it and sort it according to their priority
        $categoriesWithTlds = Helper::getCategoriesWithTlds(false, $spotlights);
        $tldsWithOrder = array_merge(...array_column($categoriesWithTlds, "tlds"));
        asort($tldsWithOrder);

        $params["searchEngineAddon"] = true;
        $params["lookupProvider"] = $lookupProvider;
        $params["tldsToInclude"] = array_keys($tldsWithOrder);
        $params["suggestionSettings"]["suggestions"] = true;
        $params["showUnavailable"] = true;
        $params["requestPage"] = $vars["POST_DATA"]["page"] ?? 1;
        $resultsPerPage = count($searchTerms) > 2 ? 5 : 12;
        $params["suggestionSettings"]["suggstionsamount"] = $resultsPerPage;
        $lastResultData = $vars["POST_DATA"]["last"] ?? null;
        if ($lastResultData) {
            $lastResultData = json_decode(htmlspecialchars_decode($lastResultData), true);
        }

        $totalResultsData = $vars["POST_DATA"]["total"] ?? null;
        if ($totalResultsData) {
            $totalResultsData = json_decode(htmlspecialchars_decode($totalResultsData), true);
        }

        $advancedOptions = explode(",", $vars["POST_DATA"]["advancedOptions"]);
        $params["premiumEnabled"] = (bool) Helper::getSetting("PremiumDomains", false);
        $params["suggestionSettings"]["suggestionsnoweighted"] = in_array("noWeightedDomains", $advancedOptions) ? true : false;
        $params["locationBasedResults"] = in_array("locationBasedResults", $advancedOptions) ? true : false;
        $domains = [];
        if ($searchTerms) {
            foreach ($searchTerms as $term) {
                if ($term["keyword"]) {
                    $params["searchTerm"] = $term["keyword"];
                    $params["start"] = $lastResultData[$term["keyword"]] ?? 0;
                    if ($totalResultsData && $lastResultData && $lastResultData[$term["keyword"]] >= $totalResultsData[$term["keyword"]]) {
                        continue;
                    }
                    $results[$params["searchTerm"]] = Helper::cachedResults($params);
                } elseif ($term["exact"] && $params["requestPage"] === 1) {
                    $domains[$term["exact"]] = $term["exact"];
                }
            }
        }

        if ($domains) {
            $params["domains"] = $domains;
            $params["requestType"] = "availability";
            $domainKey = "exact_search";
            if ((!$totalResultsData && !$lastResultData)) {
                $results[$domainKey] = Helper::cachedResults($params);
            }
        }

        if (count($results) > 0) {
            $jsonData["info"]["last"] = $lastResultData;
            $jsonData["info"]["total"] = $totalResultsData;
            foreach ($results as $domKey => $domData) {
                $type = ($domKey === "exact_search") ? "exact" : "suggestions";

                foreach ($domData as $domain) {
                    $availabilityReason = $domain->availabilityReason ?? "";
                    $domainArray = $domain->toArray();
                    $domainArray["isAftermarket"] = $domain->isAftermarket ?? false;
                    $domainArray["status"] = $domain->isAvailable ? "available" : ($domainArray["isAftermarket"] ? "unavailable" : $domainArray["status"]);
                    //$domainArray["isAvailable"] = $domainArray["isAftermarket"] || $domainArray["isAvailable"]; // do not show aftermarket domains as available
                    $domainArray["availabilityReason"] = $availabilityReason;
                    if ($type !== "exact") {
                        $jsonData["info"]["last"][$domKey] = $domData->last ? $domData->last + 1 : 0;
                        $jsonData["info"]["total"][$domKey] = $domData->total ?? $totalResultsData[$domKey];
                    }
                    Helper::getDomainPricing($domainArray);
                    if ($domainArray) {
                        $jsonData[$type][$domainArray["idnDomainName"]] = $domainArray;
                    }
                }
            }
        }

        return $jsonData;
    }

    /**
     * getsuggestions action.
     *
     * @param array $vars Module configuration parameters
     * @param smarty smarty instance
     * @return array
     */
    public function aftermarket($vars, $smarty)
    {
        $lookupProvider = Helper::isValidLookupProvider(true);
        $registrar = new \WHMCS\Module\Registrar();
        $registrar->load($lookupProvider);
        $params = $registrar->getSettings();
        $searchTerms = Helper::getSearchTerm($vars["POST_DATA"]["searchTerm"]);
        Helper::logSearch($vars["POST_DATA"]["rawSearchTerm"], "Aftermarket"); // log keywords

        $params["searchEngineAddon"] = true;
        $params["lookupProvider"] = $lookupProvider;
        $params["requestPage"] = $vars["POST_DATA"]["page"] ?? 1;
        $params["requestType"] = "aftermarket";
        $params["premiumEnabled"] = (bool) Helper::getSetting("PremiumDomains", false);
        $domains = [];
        $jsonData = [];
        if ($searchTerms) {
            foreach ($searchTerms as $term) {
                if ($term["keyword"]) {
                    $params["searchTerm"] = $term["keyword"];
                    $results[$params["searchTerm"]] = Helper::cachedResults($params);
                } elseif ($term["exact"]) {
                    $domains[$term["exact"]] = $term["exact"];
                }
            }
        }

        if ($domains) {
            // in case if want to perform checkavailability on exact searches
            // if ($lookupProvider === "ispapi") {
            //     $params["domains"] = $domains;
            //     $params["requestType"] = "availability";
            // }
            $params["searchTerm"] = $domains[array_key_first($domains)];
            $params["limit"] = 1;
            $domainKey = "exact_search";
            $results[$domainKey] = Helper::cachedResults($params);
        }
        $jsonData["info"]["last"] = 0;
        $jsonData["info"]["total"] = 0;
        if (count($results) > 0) {
            foreach ($results as $domKey => $domData) {
                $type = ($domKey === "exact_search") ? "exact" : "suggestions";

                foreach ($domData as $domain) {
                    $availabilityReason = $domain->availabilityReason ?? "";
                    $domainArray = $domain->toArray();
                    $domainArray["isAftermarket"] = $domain->isAftermarket ?? false;
                    $domainArray["status"] = $domain->isAvailable ? "available" : $domainArray["status"];
                    $domainArray["isAvailable"] = !isset($domain->errorMissingCurrency) ?? $domainArray["isAftermarket"];
                    $domainArray["availabilityReason"] = $availabilityReason;
                    $domainArray["isPremium"] = $domain->isPremium ?? false;
                    Helper::getDomainPricing($domainArray);
                    $isExactDomain = $type === "suggestions" ? array_key_exists($domainArray["idnDomainName"], $domains) : false;
                    // check if domain array is not empty and the domain does not already exists in the list
                    if ($domainArray && !$isExactDomain) {
                        $jsonData[$type][$domainArray["idnDomainName"]] = $domainArray;
                        $jsonData["info"]["last"] += 1;
                        $jsonData["info"]["total"] += 1;
                    }
                }
            }
        }

        return $jsonData;
    }

    /**
     * Returns client area configuration
     *
     * @param array $vars Module configuration parameters
     * @param Smarty $smarty smarty instance
     * @return array configuration
     */
    public function loadconfiguration($vars, $smarty)
    {
        return Helper::load($vars);
    }

    public function cart($vars, $smarty)
    {
        return Helper::cartHandler($vars);
    }

    public function categories($vars, $smarty)
    {
        return Helper::getCategoriesList();
    }

    public function tldsPricing($vars)
    {
        $categoriesWithTlds = Helper::getCategoriesWithTlds(true);
        $priceType = $vars["POST_DATA"]["request"];
        $tlds = array_merge(...array_map(function ($category) {
            return array_keys($category["tlds"]);
        }, $categoriesWithTlds));

        // Fetch tlds with register and renewal pricing
        $tldPricing = multipleTldPriceListings($tlds);

        $return = [];
        foreach ($tldPricing as $tld) {
            if (!empty($tld["register"]) && !empty($tld["renew"])) {
                $return[$tld["tld"]] = (float) number_format($tld[$priceType]->toNumeric(), 2);
            }
        }

        return $return;
    }

    public function clearCache($vars)
    {
        return Helper::sessionTimeoutCheck(true);
    }

    public function transfer($vars, $smarty)
    {
        return ["success" => true];
    }
}
