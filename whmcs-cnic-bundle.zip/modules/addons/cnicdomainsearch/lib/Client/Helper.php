<?php

namespace WHMCS\Module\Addon\CnicDomainSearch\Client;

use Exception;
use WHMCS\Module\Addon\CnicDomainSearch\Common\Helper as Help;
use Illuminate\Database\Capsule\Manager as DB;
use WHMCS\Module\Addon\CnicDomainSearch\Config\Configuration;

require ROOTDIR . "/includes/domainfunctions.php";

class Helper extends Help
{
    /**
     * loadconfiguration action.
     *
     * @param array $vars Module configuration parameters
     * @param smarty smarty instance
     * @return array
     */
    public static function load($params)
    {
        // if (parent::getSetting("FeatureBulkTransfers", true, "1") || parent::getSetting('DomainTransfers')
        // ) {
        //     // to enable transfers we have to forecly complete captcha
        //     \WHMCS\Session::set("CaptchaComplete", true);
        // }

        return Configuration::load();
    }

    public static function getDomainPricing(&$data)
    {
        $domainPricing = $data["pricing"];
        $shortestPeriod = $data['shortestPeriod'];
        //$domainPricing = getTLDPriceList($data["tld"], true); //alternate method
        if (empty($domainPricing) && empty($shortestPeriod)) {
            $data["pricing"] = [];
            $data["shortestPeriod"] = [];
            $data["tldSupported"] = false;
            $data["status"] = "tld not supported";
            $data["legacyStatus"] = "tld not supported";
            $data["status"] = strtolower(str_replace(" ", "", $data["status"])); // generating status label translation key
            return;
        }

        $data["tldSupported"] = true;

        $return = [];
        if (!$data["isAftermarket"]) {
            $shortestPeriod = -1;
            foreach ($domainPricing as $domainPeriod => $domainPrice) {
                if (!isset($domainPrice["register"]) || $domainPrice["register"]->toNumeric() === -1 || !isset($domainPrice["renew"])) {
                    continue;
                }
                if ($shortestPeriod === -1) {
                    $shortestPeriod = $domainPeriod;
                }
                $return[$domainPeriod]["register"]["format"] = $domainPrice["register"]->toPrefixed();
                $return[$domainPeriod]["register"]["currency"] = $domainPrice["register"]->getCurrency();
                $return[$domainPeriod]["register"]["price"] = (int) $domainPrice["register"]->toNumeric();

                $return[$domainPeriod]["renew"]["format"] = $domainPrice["renew"]->toPrefixed();
                $return[$domainPeriod]["renew"]["currency"] = $domainPrice["renew"]->getCurrency();
                $return[$domainPeriod]["renew"]["price"] = (int) $domainPrice["renew"]->toNumeric();

                if (isset($domainPrice["transfer"]) && $domainPrice["transfer"]->toNumeric() !== -1) {
                    $return[$domainPeriod]["transfer"]["format"] = $domainPrice["transfer"]->toPrefixed();
                    $return[$domainPeriod]["transfer"]["currency"] = $domainPrice["transfer"]->getCurrency();
                    $return[$domainPeriod]["transfer"]["price"] = (int) $domainPrice["transfer"]->toNumeric();
                }
            }
        } else {
            $domainPrice = $shortestPeriod;
            $domainPricing = getTLDPriceList($data["tld"], true);
            $shortestPeriod = $domainPrice['period'];
            if (isset($domainPrice["register"]) && $domainPrice["register"]->toNumeric() > -1 && isset($domainPricing[$shortestPeriod]["renew"])) {
                $return[$shortestPeriod]["register"]["format"] = $domainPrice["register"]->toPrefixed();
                $return[$shortestPeriod]["register"]["currency"] = $domainPrice["register"]->getCurrency();
                $return[$shortestPeriod]["register"]["price"] = (float) number_format($domainPrice["register"]->toNumeric(), 2);

                $return[$shortestPeriod]["renew"]["format"] = $domainPricing[$shortestPeriod]["renew"]->toPrefixed();
                $return[$shortestPeriod]["renew"]["currency"] = $domainPricing[$shortestPeriod]["renew"]->getCurrency();
                $return[$shortestPeriod]["renew"]["price"] = (float) number_format($domainPricing[$shortestPeriod]["renew"]->toNumeric(), 2);
            }

            if (isset($domainPrice["transfer"]) && $domainPrice["transfer"]->toNumeric() > -1) {
                $return[$shortestPeriod]["transfer"]["format"] = $domainPrice["transfer"]->toPrefixed();
                $return[$shortestPeriod]["transfer"]["currency"] = $domainPrice["transfer"]->getCurrency();
                $return[$shortestPeriod]["transfer"]["price"] = (float) number_format($domainPrice["transfer"]->toNumeric(), 2);
            }
        }

        $data["pricing"] = $return;

        if ($shortestPeriod > -1 && $data["pricing"]) {
            $data['shortestPeriod'] = $return[$shortestPeriod];
            $data['shortestPeriod']['period'] = $shortestPeriod;
        } else {
            $data["pricing"] = [];
            $data["shortestPeriod"] = [];
            $data["tldSupported"] = false;
            $data["legacyStatus"] = "tld not supported";
            $data["status"] = "tld not supported";
        }
        $data["status"] = strtolower(str_replace(" ", "", $data["status"])); // generating status label translation key
    }

    /**
     * Get Search Terms
     *
     * @param string $keyword
     * @return array
     */
    public static function getSearchTerm($searchTerms)
    {
        $decodedSearchTerms = html_entity_decode($searchTerms);
        $searchTermsArray = json_decode($decodedSearchTerms, true);
        return $searchTermsArray;
    }

    /**
     * Carthandler removes items from cart and returns cart items
     *
     * @param array $vars Module configuration parameters
     * @param $domain request domain name
     * @return array
     */
    public static function cartHandler($params, $domain = null)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $requestType = $params["POST_DATA"]["type"];
        $orderForm = new \WHMCS\OrderForm();

        switch ($requestType) {
            case "list":
                $cartitems = array_filter(
                    $orderForm->getCartDataByKey('domains', []),
                    function ($item) {
                        return ($item["type"] === "register" || $item["type"] === "transfer");
                    }
                );

                $cartItemsByDomain = array_combine(
                    array_column($cartitems, 'domain'),
                    $cartitems
                );

                return $cartItemsByDomain;

            case "remove":
                $domain = $params["POST_DATA"]["domain"];
                $idnDomain = $params["POST_DATA"]["idnDomain"] ?? false;

                foreach ($_SESSION["cart"]["domains"] as $key => $row) {
                    if ($domain === $row["domain"] || $idnDomain === $row["domain"]) {
                        unset($_SESSION["cart"]["domains"][$key]);
                        $_SESSION["cart"]["domains"] = array_values($_SESSION["cart"]["domains"]);
                        return [
                            "result" => "removed",
                            "cartCount" => $orderForm->getNumItemsInCart()
                        ];
                    }
                }

                break;
        }
    }

    /**
     * Request cached results from backend API
     *
     * @param array $params
     * @return array
     */
    public static function cachedResults($params)
    {
        // Start session if it's not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Clear session data inherited from parent class
        parent::sessionTimeoutCheck();

        // Generate a hash key based on the input parameters
        $hashKey = md5(base64_encode(serialize($params))) . time(); // add time() to temporarily disable cache

        // Check if the cached result exists in the session
        if (isset($_SESSION["cnic_cache"][$hashKey]) && !empty($_SESSION["cnic_cache"][$hashKey])) {
            // If yes, retrieve the cached result
            $results = unserialize(base64_decode($_SESSION["cnic_cache"][$hashKey]));
            if (!empty($results)) {
                // If the cached result is not empty, return it
                return $results;
            }
        }

        // If the cached result does not exist, generate new results based on the input parameters
        $lookupProvider = $params["lookupProvider"];
        $functionName = isset($params["checkAvailability"]) ? "{$lookupProvider}_CheckAvailability" : "{$lookupProvider}_GetDomainSuggestions";
        $results = call_user_func($functionName, $params);

        // Cache the new results in the session
        $_SESSION["cnic_cache"][$hashKey] = base64_encode(serialize($results));
        $_SESSION["cnic_cache"]["ttl"] = time();

        // Return the new results
        return $results;
    }

    /**
     * Retrieves categories along with their corresponding TLDs and priorities.
     *
     * @param bool $cache Whether to use cached results.
     * @return array Array of categories with their corresponding TLDs and priorities.
     */
    public static function getCategoriesWithTlds($cache = false, $spotlights = [])
    {
        global $_LANG;
        // Start a new session if one has not already been started.
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $cache = false;
        // Check if cached results are available and valid.
        if (isset($_SESSION["cnic_cache"]["categoriesWithTlds"]) && $cache) {
            // Retrieve the results from the cache.
            $categories = $_SESSION["cnic_cache"]["categoriesWithTlds"];
            return $categories;
        }

        // Retrieve categories from the database then convert to an array.
        $categories = self::objectToArray(
            DB::table('cnic_tblcategories')
                ->distinct()
                ->orderBy('id', 'asc')
                ->get()
        );

        // Map each category to an array containing its TLDs.
        $categories = array_map(function ($category) use ($_LANG) {
            $category["tlds"] = empty($category["tlds"]) ? [] : explode(" ", trim($category["tlds"]));
            $category["settings"] = json_decode($category["settings"], true);
            if (isset($_LANG["domainTldCategory"][$category["name"]])) {
                $category["name"] = $_LANG["domainTldCategory"][$category["name"]];
            }
            return $category;
        }, $categories);

        // Retrieve the list of TLDs along with their priorities.
        $tldWithPriority = parent::getTLDList(false);

        // Get categories order to reorder categories
        $getSpotlightTlds = array_reduce($spotlights, function ($carry, $item) {
            $carry[$item["tldNoDots"]] = true;
            return $carry;
        }, []);

        // Replace each TLD in each category with an array containing its TLD and priority.
        foreach ($categories as &$category) {
            $tmpTlds = [];
            foreach ($category["tlds"] as $tld) {
                foreach ($tldWithPriority as $tldP) {
                    if ($tld === $tldP['tld']) {
                        if (!empty($getSpotlightTlds) && $getSpotlightTlds[$tld]) {
                            $tmpTlds[$tldP['tld']] = 0;
                            continue;
                        }

                        $tmpTlds[$tldP['tld']] = $tldP['order'] ?? 9999;
                        continue;
                    }
                }
            }
            $category["tlds"] = $tmpTlds;
        }

        usort($categories, function ($a, $b) {
            return $a["position"] <=> $b["position"];
        }); // sort categories by order

        // Cache the results.
        $_SESSION["cnic_cache"]["categoriesWithTlds"] = $categories;

        // Return the results
        return $categories;
    }

    public static function spotlightTldsWithPricing()
    {
        $featuredTlds = [];
        $spotlights = getSpotlightTldsWithPricing();
        foreach ($spotlights as $spotlight) {
            if (file_exists(ROOTDIR . "/assets/img/tld_logos/" . $spotlight["tldNoDots"] . ".png")) {
                $spotlight["img"] = "/assets/img/tld_logos/" . $spotlight["tldNoDots"] . ".png";
            }
            if ($spotlight["register"]) {
                $spotlight["register"] = $spotlight["register"]->__toString();
            }

            if ($spotlight["renew"]) {
                $spotlight["renew"] = $spotlight["renew"]->toPrefixed();
            }

            if ($spotlight["transfer"]) {
                $spotlight["transfer"] = $spotlight["transfer"]->toPrefixed();
            }

            $featuredTlds[] = $spotlight;
        }

        return $featuredTlds;
    }

    public static function logSearch($terms, $tab)
    {
        $searchLogsEnabled = (bool) Helper::getSetting("SearchLogs", true, "0");

        if (!$searchLogsEnabled || empty($terms)) {
            return;
        }

        $clientId =  \WHMCS\Session::get("uid") ?? null;
        if (function_exists("cnic_logSearch")) {
            return cnic_logSearch($terms, $tab, time(), \WHMCS\Utility\Environment\CurrentRequest::getIP(), $clientId);
        }

        $log = "Searched Keyword(s): {$terms} Tab: {$tab}";
        logActivity($log, $clientId);
    }

    public static function tldsWithoutEppCode()
    {
        $tlds = DB::table('tbldomainpricing')->distinct()->select("extension")->where("eppCode", 0)->pluck("extension");
        $tlds = self::objectToArray($tlds);
        $return = [];
        foreach ($tlds as $value) {
            $return[ltrim($value, ".")] = true;
        }
        return $return;
    }
}
