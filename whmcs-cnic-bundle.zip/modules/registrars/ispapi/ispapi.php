<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as DB;
use WHMCS\Module\Registrar\Ispapi\Ispapi as Ispapi;
use WHMCS\Module\Registrar\Ispapi\WebApps as WebApps;
use WHMCS\Module\Registrar\Ispapi\DomainTransfer as HXTransfer;
use WHMCS\Module\Registrar\Ispapi\Dns as HXDns;
use WHMCS\Module\Registrar\Ispapi\Domain as HXDomain;
use WHMCS\Module\Registrar\Ispapi\DomainTrade as HXTrade;
use WHMCS\Module\Registrar\Ispapi\DomainApplication as HXApp;
use WHMCS\Module\Registrar\Ispapi\Contact as HXContact;
use WHMCS\Module\Registrar\Ispapi\User as HXUser;
use WHMCS\Domains\DomainLookup\SearchResult as SR;
use WHMCS\Module\Registrar\Ispapi\AdditionalFields as AF;
use WHMCS\Module\Registrar\Ispapi\Lang as L;

require_once implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]);

/**
 * Get Transferlock settings of a domain name
 * Deprecated after CORE-17038
 * @param array $params common module parameters
 * @return array $values - an array with transferlock setting information
 */
function ispapi_GetRegistrarLock($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    // NOTE: returning an error still shows up as "unlocked"
    // Removing the menu entry by hook therefore ftw.
    // asked to get this also patched via CORE-17038
    return HXDomain::getRegistrarLock(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
}

/**
 * Return Nameservers of a domain name
 * Deprecated after CORE-17038
 *
 * NOTE: This function is invoked in case GetDomainInformation throws an exception Or returns no nameservers
 *
 * @param array $params common module parameters
 * @return array $values an array with the Nameservers
 */
function ispapi_GetNameservers($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $r = HXDomain::getStatus(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
    if ($r["success"]) {
        return Ispapi::castNameservers(
            $r["data"]["NAMESERVER"]
        );
    }
    return [];
}

/**
 * Check the availability of domains using HEXONET's fast API
 * @param array $params common module parameters *
 * @return \WHMCS\Domains\DomainLookup\ResultsList An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 * @see https://confluence.hexonet.net/pages/viewpage.action?pageId=8589377 for diagram
 * @throws \Exception in case of an error
 */
function ispapi_CheckAvailability($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $maxGroupSize = 25;
    $premiumEnabled = (bool) $params["premiumEnabled"];
    // if the request is from our aftermarket tab search engine
    if ((isset($_REQUEST["action"]) || isset($_REQUEST["aftermarket"])) && ($_REQUEST["aftermarket"] === "on" || $_REQUEST["action"] === "aftermarket")) {
        $params["AFTERMARKETDOMAINS"] = "on";
        if (isset($_REQUEST["domain"])) {
            cnic_aftermarketDomains($_REQUEST["domain"], true);
        }
    }

    $command = [
        "COMMAND" => "CheckDomains",
        "PREMIUMCHANNELS" => $premiumEnabled ? "*" : ""
    ];

    // build domainlist to check
    if (!empty($params["domains"])) {
        $tocheck = $params["domains"];
    } elseif (!empty($params["suggestions"])) {
        // for domain name suggestion mode (we get already a list of domains)
        // remove duplicates and empty ones
        $tocheck = $params["suggestions"];
    } else {
        $label = strtolower(
            ($params["isIdnDomain"] && !empty($params["punyCodeSearchTerm"])) ?
                $params["punyCodeSearchTerm"] :
                $params["searchTerm"]
        );
        // for common availability checks (we get just a search label and list of tlds)
        // remove duplicates and empty ones
        $tocheck = array_values(array_unique(array_filter($params["tldsToInclude"])));
        $tocheck = array_map(function ($tld) use ($label) {
            return $label  . "." . ltrim($tld, ".");
        }, $tocheck);
    }

    // build the result list for WHMCS
    // chunk the check list, only ~250 are allowed at once
    $results = new \WHMCS\Domains\DomainLookup\ResultsList();
    $results->totalAvailable = 0;
    foreach (array_chunk($tocheck, $maxGroupSize) as $command["DOMAIN"]) {
        $r = Ispapi::call($command, $params);
        foreach ($command["DOMAIN"] as $idx => $domain) {
            list($sld, $tld) = explode(".", $domain, 2);
            if (empty($sld) || empty($tld)) {
                continue;
            }
            $sr = new SR($sld, $tld);
            $sr->setStatus($sr::STATUS_REGISTERED);

            $row = [
                "DOMAIN" => $domain,
                "PREMIUMCHANNEL" => "",
                "REASON" => "",
                "CLASS" => "",
                "CURRENCY" => "",
                "PRICE" => "",
                "DOMAINCHECK" => "421 Temporary issue",
            ];
            foreach ($row as $key => &$val) {
                if (
                    isset($r["PROPERTY"][$key][$idx])
                    && strlen($r["PROPERTY"][$key][$idx])
                ) {
                    $val = $r["PROPERTY"][$key][$idx];
                }
            }
            list($row["CODE"], $row["CHECK"]) = explode(" ", $row["DOMAINCHECK"], 2);
            $params["isAftermarketCase"] = false;
            $sr->availabilityReason = $row["REASON"];
            if ($row["CODE"] === "421") {
                //TMP. ERROR OCCURED
                $sr->setStatus($sr::STATUS_UNKNOWN);
            } elseif ($row["CODE"] === "549") {
                // TLD not supported at HEXONET or check failed
                // WHMCS does fallback to whois lookup
                $sr->setStatus($sr::STATUS_TLD_NOT_SUPPORTED);
            } elseif ($row["CODE"] === "210") {
                //DOMAIN AVAILABLE
                $sr->setStatus($sr::STATUS_NOT_REGISTERED);
            } elseif ($row["CODE"] === "211") {
                // $sr::STATUS_REGISTERED already set
                // PREMIUM DOMAINS
                if (
                    strlen($row["CLASS"])
                    && preg_match("/^PREMIUM_/i", $row["CLASS"])
                ) {
                    // n/a or available
                    $sr->setPremiumDomain(true);
                }
                if (
                    // DOMAIN BLOCKS
                    stripos($row["REASON"], "block")
                    // RESERVER DOMAIN NAMES
                    || stripos($row["REASON"], "reserved")
                    // NXD DOMAINS
                    || preg_match("/^collision domain name available \{/i", $row["CHECK"])
                ) {
                    $sr->setStatus($sr::STATUS_RESERVED);
                } elseif (
                    strlen($row["PREMIUMCHANNEL"])
                    && $sr->isPremiumDomain()
                    && !isset($params["AFTERMARKETDOMAINS"])
                    && preg_match("/^premium domain name available/i", $row["CHECK"])
                ) {
                    // CASE: PREMIUM OR AFTERMARKET PREMIUM
                    $params["AvailabilityCheckResult"] = $r;
                    $params["AvailabilityCheckResultIndex"] = $idx;
                    // available premium domain
                    try {
                        $prices = ispapi_GetPremiumPrice($params);
                        $row["prices"] = var_export($prices, true);
                        // logActivity("{$domain}: " . json_encode($prices));
                        $sr->setPremiumCostPricing($prices);
                        // TODO why prices empty?
                        if (isset($prices["register"])) {
                            //PREMIUM DOMAIN AVAILABLE
                            $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                        }
                    } catch (\Exception $e) {
                        $sr->setPremiumCostPricing([]);
                        $sr->setStatus($sr::STATUS_RESERVED);
                    }
                } elseif (
                    !strlen($row["PREMIUMCHANNEL"])
                    && $sr->isPremiumDomain()
                    && !isset($params["AFTERMARKETDOMAINS"])
                    && preg_match("/^premium domain name not available/i", $row["CHECK"])
                ) {
                    // CASE: PREMIUM / PREMIUM AFTERMARKET - taken ones
                    $params["AvailabilityCheckResult"] = $r;
                    $params["AvailabilityCheckResultIndex"] = $idx;
                    // available premium domain
                    try {
                        $prices = ispapi_GetPremiumPrice($params);
                        $row["prices"] = var_export($prices, true);
                        $currency = \WHMCS\Billing\Currency::where("code", $prices["CurrencyCode"])->first();
                        if (!$currency) {
                            $sr->errorMissingCurrency = $prices["CurrencyCode"];
                            throw new Exception("Missing required currency configuration for: " . $prices["CurrencyCode"]);
                        }
                        // logActivity("{$domain}: " . json_encode($prices));
                        $sr->setPremiumCostPricing($prices);
                        // TODO why prices empty?
                    } catch (\Exception $e) {
                        $sr->setPremiumCostPricing([]);
                        $sr->setStatus($sr::STATUS_RESERVED);
                    }
                }
                if (
                    (!isset($_REQUEST["a"])
                        || $_REQUEST["a"] !== "addDomainTransfer"
                    ) // if not a domain trasfer request
                    && isset($params["AFTERMARKETDOMAINS"])
                    && $params["AFTERMARKETDOMAINS"] === "on" // check if aftermarket is enabled
                    && (preg_match("/^NAMEMEDIA|AFTERNIC|SEDO$/i", $row["PREMIUMCHANNEL"]) || isset($_REQUEST["aftermarket"])) // domain is an aftermarket domain
                    && preg_match("/not available/i", $row["CHECK"]) //domain is not available
                ) {
                    // logActivity(json_encode($_REQUEST));
                    $sr->setPremiumDomain(true);
                    // CASE: PREMIUM / PREMIUM AFTERMARKET - taken ones
                    $params["AvailabilityCheckResult"] = $r;
                    $params["AvailabilityCheckResultIndex"] = $idx;
                    $params["isAftermarketCase"] = true;
                    $sr->isAftermarket = $params["isAftermarketCase"];
                    try {
                        try {
                            $prices = ispapi_GetAftermarketDomainPrice($domain); // do not rely on checkavailability prices
                            if (!isset($prices["CurrencyCode"]) || !isset($prices["register"])) {
                                throw new Exception("Missing required currency configuration for " . $prices["CurrencyCode"] . " and Aftermarket register price.");
                            }
                        } catch (\Exception $e) {
                            if (!isset($prices["CurrencyCode"])) {
                                $currency = \WHMCS\Billing\Currency::where("code", $_REQUEST["currencyCode"])->first();

                                if (!$currency) {
                                    $sr->errorMissingCurrency = $_REQUEST["currencyCode"];
                                    throw new Exception("Missing required currency configuration for " . $_REQUEST["currencyCode"]);
                                }

                                $prices["CurrencyCode"] ??= $currency->code;
                                $prices["CurrencyID"] ??= $currency->id;
                            }

                            // if register price is not available use aftermarket price from payload
                            $prices["register"] ??= $_REQUEST["registerPrice"];
                        }

                        $row["prices"] = var_export($prices, true);
                        if (strlen($row["CLASS"]) && !preg_match("/^PREMIUM_/i", $row["CLASS"])) {
                            unset($row["renew"]);
                            unset($row["transfer"]);
                        }
                        // AFTERMARKET DOMAIN AVAILABLE
                        $sr->setPremiumCostPricing($prices);
                        $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                    } catch (\Exception $e) {
                        $sr->setPremiumCostPricing([]);
                        $sr->setStatus($sr::STATUS_RESERVED);
                    }
                }
            }

            //ONLY RETURNS AVAILABLE DOMAINS FOR DOMAIN NAME SUGGESTIONS MODE OR REQUESTED SHOW UNAVAILABLE
            //AND ALL RESULTS OTHERWISE
            if ((isset($params["showUnavailable"]) || !isset($params["suggestions"])) || $sr->getStatus() === $sr::STATUS_NOT_REGISTERED) {
                if (isset($params["showUnavailable"]) && $sr->getStatus() === $sr::STATUS_NOT_REGISTERED) {
                    $results->totalAvailable += 1;
                }
                $results->append($sr);
            }
        }
    }
    return $results;
}

/**
 * Provide domain suggestions based on the domain lookup term provided
 *
 * @param array $params common module parameters
 *
 * @return \WHMCS\Domains\DomainLookup\ResultsList An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 */
function ispapi_GetDomainSuggestions($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    // go through configuration settings
    if (empty($params["suggestionSettings"]["suggestions"])) {
        return new \WHMCS\Domains\DomainLookup\ResultsList();
    }
    $suppressWeighted = $params["suggestionSettings"]["suggestionsnoweighted"];
    $suggestionsLimit = 100;
    if (!empty($params["suggestionSettings"]["suggstionsamount"])) {
        $suggestionsLimit = $params["suggestionSettings"]["suggstionsamount"];
    }

    // build search label
    if ($params["isIdnDomain"]) {
        $label = empty($params["punyCodeSearchTerm"]) ? $params["searchTerm"] : $params["punyCodeSearchTerm"];
    } else {
        $label = $params["searchTerm"];
    }
    $label = strtolower($label);

    // build zone list parameter
    $zones = [];
    foreach ($params["tldsToInclude"] as $tld) {
        // IGNORE 3RD LEVEL TLDS - NOT FULLY SUPPORTED BY QueryDomainSuggestionList
        // Suppress .com, .net by configuration
        $tld = strtoupper(ltrim(trim($tld), "."));
        if (!preg_match("/\./", $tld) && (!$suppressWeighted || !preg_match("/^(com|net)$/i", $tld)) && strlen($tld) > 0) {
            $zones[] = $tld;
        }
    }

    // request domain name suggestions from engine
    $first = $params['start'] ?? 0;
    $command = [
        "COMMAND" => "QueryDomainSuggestionList",
        "KEYWORD" => $label,
        "ZONE" => $zones,
        "SOURCE" => "ISPAPI-SUGGESTIONS",
        "LIMIT" => $suggestionsLimit
    ];

    if ($params['locationBasedResults']) {
        $command["IPADDRESS"] = \App::getRemoteIp();
    }

    $results = new \WHMCS\Domains\DomainLookup\ResultsList();
    do {
        // get domain name suggestions
        $command["FIRST"] = $first;
        $r = Ispapi::call($command, $params);
        if ($r["CODE"] !== "200" || empty($r["PROPERTY"]["DOMAIN"])) {
            break; //leave while and return $results
        }
        // check the availability, as also taken/reserved/blocked domains could be returned
        $params["suggestions"] = array_values(array_unique(array_filter($r["PROPERTY"]["DOMAIN"])));
        $tmp = ispapi_CheckAvailability($params);
        // add entries to the list of entries to return
        $resultsCount = count($results);
        if (isset($params["showUnavailable"])) {
            $resultsCount = $tmp->totalAvailable;
        }
        $resultsFilled = $resultsCount >= $suggestionsLimit;
        foreach ($tmp as $sr) {
            if (isset($params["showUnavailable"])) {
                $results->append($sr);
                continue;
            }

            if ($resultsFilled) {
                break 2; //leave foreach and while
            }
            $results->append($sr);
            $resultsCount++;
            $resultsFilled = $resultsCount >= $suggestionsLimit;
        }
        $first += $suggestionsLimit;
    } while (!$resultsFilled && ($r["PROPERTY"]["TOTAL"][0] > $first));
    $results->total = $r["PROPERTY"]["TOTAL"][0];
    $results->last = $r["PROPERTY"]["LAST"][0];
    return $results;
}

/**
 * Define the settings relating to domain suggestions
 *
 * @param array an array with different settings
 */
function ispapi_DomainSuggestionOptions($params)
{
    $meta = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . "whmcs.json"), true);

    $version = implode(".", array_slice(explode(".", $params["whmcsVersion"]), 0, 2));
    if (version_compare($version, "7.6") === -1) {
        $marginleft = "60px";
    } else {
        $marginleft = "220px";
    }

    /*$r = Ispapi::call([
        "COMMAND" => "QueryDomainSuggestionList",
        "SOURCE" => "ISPAPI-CATEGORIES"
    ], $params);
    $categories = ["" => "Not set (default)"];
    if ($r["CODE"] !== "200") {
        $r["PROPERTY"]["CATEGORY"] = [ // 06-08-2020
            "professions", "geographic", "education", "entertainment", "business", "adult", "travel", "technology", "realEstate", "community",
            "identity", "arts", "shopping", "other", "financial", "food", "fitness", "lifestyle", "culture", "popular", "health", "idns"
        ];
    }
    sort($r["PROPERTY"]["CATEGORY"]);
    foreach ($r["PROPERTY"]["CATEGORY"] as $category) {
        $categories[$category] = $category;
    }

    $languages = ["" => "Not set (default)"];*/
    $url = $meta["_priv"]["UrlSignup"];
    return [
        "information" => [
            "FriendlyName" => "<b>Not signed up yet?</b>",
            "Description" => "Signup here for free: <a target=\"_blank\" href=\"{$url}\">{$url}</a><br/><br/>
			<b>We provide the following features:</b>
			<ul style=\"text-align:left;margin-left:" . $marginleft . ";margin-top:5px;\">
			<li>High Performance availability checks using our incredible fast API</li>
			<li>Suggestion Engine</li>
			<li>Premium Domains support</li>
			</ul>"
        ],
        "suggestions" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Suggestion Engine based on search term:</b>",
            "Type" => "yesno",
            "Description" => AdminLang::trans("global.ticktoenable") . " (" . AdminLang::trans("global.recommended") . ")"
        ],
        "suggstionsamount" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">" . AdminLang::trans("general.maxsuggestions") . "</b>",
            "Type" => "dropdown",
            "Options" => [
                10 => "10",
                25 => "25",
                50 => "50",
                75 => "75",
                100 => "100 (" . AdminLang::trans("global.recommended") . ")",
                150 => "150",
                200 => "200"
            ],
            "Default" => "100",
            "Description" => ""
        ],
        /*"suggestionscategories" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Category-based suggestions:</b>",
            "Type" => "dropdown",
            "Multiple" => true,
            "Size" => 5,
            "Options" => $categories,
            "Default" => "",
            "Description" => "<br/>Get Suggestions related to the selected categories."
        ],
        "suggestionslangs" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Language-dependent Suggestions:</b>",
            "Type" => "dropdown",
            "Multiple" => true,
            "Size" => 3,
            "Options" => $languages,
            "Default" => "",
            "Description" => "<br/>(Better localized Suggestions)"
        ],
        "suggestionsip" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Use IP Address for region-dependent Suggestions:</b>",
            "Type" => "yesno",
            "Default" => "",
            "Description" => AdminLang::trans("global.ticktoenable") . " (Better localized Suggestions)"
        ],*/
        "suggestionsnoweighted" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Suppress .com and .net:</b>",
            "Type" => "yesno",
            "Default" => "",
            "Description" => AdminLang::trans("global.ticktoenable") . "<br/>.com and .net have by default a very high weight."
        ]
    ];
}
/**
 * Get Premium Price for given domain,
 * $params -> [
 *      "domain" => ...,
 *      "sld" => ...
 *      "tld" => ...
 *      "type" => ...
 * ];
 * @throws Exception in case currency configuration is missing
 */
function ispapi_GetPremiumPrice($params)
{
    if (isset($params["AvailabilityCheckResult"])) {
        $index = $params["AvailabilityCheckResultIndex"];
        $r = $params["AvailabilityCheckResult"];
        unset(
            $params["AvailabilityCheckResultIndex"],
            $params["AvailabilityCheckResult"]
        );
    } else {
        $index = 0;
        $r = Ispapi::call([
            "COMMAND" => "CheckDomains",
            "DOMAIN0" => $params["domain"],
            "PREMIUMCHANNELS" => "*"
        ], $params);
    }
    // no data available, api error
    if ($r["CODE"] !== "200") {
        return [];
    }
    $r = $r["PROPERTY"];
    /* if (
        // aftermarket
        // any case not being AFTERMARKET in context of our domain search
        // HINT: WHMCS is looking up availability for transfers
        // aftermarket has to be returned as taken
        (empty($r["CLASS"][$index]) ||
            !(bool)preg_match("/^PREMIUM_/", $r["CLASS"][$index])
        ) &&
        (!isset($params["isAftermarketCase"]) ||
            !$params["isAftermarketCase"]
        )
    ) {
        return [];
    } */
    //GET THE PRICES
    if (isset($r["CURRENCY"][$index]) && isset($r["PRICE"][$index]) && is_numeric($r["PRICE"][$index])) {
        $prices = [
            "CurrencyCode" => $r["CURRENCY"][$index]
        ];
        $currency = \WHMCS\Billing\Currency::where("code", $prices["CurrencyCode"])->first();
        if (!$currency) {
            throw new Exception("Missing currency configuration for: " . $prices["CurrencyCode"]);
        }
        $prices["CurrencyID"] = $currency->id;
        // probably registration case (domain name available), API provides PRICE/CURRENCY Properties
        // get registration price (as of variable fee premiums calculation is more complex)
        $renewprice = ispapi_getPremiumRenewPrice($params, $r["CLASS"][$index], $currency->id);
        if ($renewprice !== false) {
            $prices["renew"] = $renewprice;
        }
        $registerprice = ispapi_getPremiumRegisterPrice($params, $r["CLASS"][$index], $r["PRICE"][$index], $currency->id);
        if ($registerprice !== false) {
            $prices["register"] = $registerprice;
        }
        return $prices;
    }
    $prices = [
        "CurrencyCode" =>  ispapi_getPremiumCurrency($params, $r["CLASS"][$index])
    ];
    if ($prices["CurrencyCode"] === false) {
        $racc = Ispapi::call([ // worst case fallback
            "COMMAND" => "StatusAccount"
        ], $params);
        if ($racc["CODE"] !== "200" || empty($racc["PROPERTY"]["CURRENCY"][0])) {
            return [];
        }
        $prices["CurrencyCode"] = $racc["PROPERTY"]["CURRENCY"][0];
    }
    $currency = \WHMCS\Billing\Currency::where("code", $prices["CurrencyCode"])->first();
    if (!$currency) {
        throw new Exception("Missing required currency configuration for: " . $prices["CurrencyCode"]);
    }
    $prices["CurrencyID"] = $currency->id;
    $prices["renew"] = ispapi_getPremiumRenewPrice($params, $r["CLASS"][$index], $currency->id);
    // probably transfer case (domain name n/a), API doesn't provide PRICE/CURRENCY Properties
    if ($prices["renew"] === false) {
        return [];
    }

    $transferprice = ispapi_getPremiumTransferPrice($params, $r["CLASS"][$index], $currency->id);
    if ($transferprice !== false) {
        $prices["transfer"] = $transferprice;
    }
    return $prices;
}

/**
 * Get the API currency for the given premium domain class
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @return string/bool the premium currency, false if not found
 */
function ispapi_getPremiumCurrency($params, $class)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        return HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_CURRENCY");
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    return preg_replace("/(^.+_|:.+$)/", "", $class);
}

/**
 * Calculate the domain premium registration price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param string $registerprice the price we have from CheckDoamins
 * @param integer $cur_id the currency id of the currency we have form CheckDomains
 *
 * @return integer/bool the renew price, false if not found
 */
function ispapi_getPremiumRegisterPrice($params, $class, $registerprice, $cur_id)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        return $registerprice; // looking up relations not necessary API provided the prices
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    $p = preg_split("/\:/", $class);
    $cl = preg_split("/_/", $p[0]);
    $premiummarkupfix_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_SETUP_MARKUP_FIX");
    $premiummarkupvar_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_SETUP_MARKUP_VAR");
    if ($premiummarkupfix_value && $premiummarkupvar_value) {
        $relation_currency_code = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_CURRENCY");
        if ($relation_currency_code !== false) {
            $currency = \WHMCS\Billing\Currency::where("code", $relation_currency_code)->first();
            if (!$currency) {
                return false;
            }
            if ($currency->id !== $cur_id) {
                $premiummarkupvar_value = convertCurrency($premiummarkupvar_value, $currency->id, $cur_id);
                $premiummarkupfix_value = convertCurrency($premiummarkupfix_value, $currency->id, $cur_id);
            }
        }
        return $p[2] * (1 + $premiummarkupvar_value / 100) + $premiummarkupfix_value;
    }
    return false;
}

/**
 * Calculate the domain registration price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param integer $cur_id the currency of the domain name
 *
 * @return integer/bool the premium transfer price, false if not found
 */
function ispapi_getPremiumTransferPrice($params, $class, $cur_id)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_CURRENCY");
        if ($currency === false) {
            return false;
        }
        $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
        if (!$currency) {
            return false;
        }
        $transfer = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_TRANSFER");
        // premium period is in general 1Y, no need to reflect period in calculations
        if ($transfer !== false && ($currency->id != $cur_id)) {
            return convertCurrency($transfer, $currency->id, $cur_id);
        }
        return  $transfer;
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    $p = preg_split("/\:/", $class);
    $cl = preg_split("/_/", $p[0]);
    $premiummarkupfix_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_TRANSFER_MARKUP_FIX");
    $premiummarkupvar_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_TRANSFER_MARKUP_VAR");
    if ($premiummarkupfix_value && $premiummarkupvar_value) {
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_CURRENCY");
        if ($currency !== false) {
            $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
            if (!$currency) {
                return false;
            }
            if ($currency->id != $cur_id) {
                $premiummarkupvar_value = convertCurrency($premiummarkupvar_value, $currency->id, $cur_id);
                $premiummarkupfix_value = convertCurrency($premiummarkupfix_value, $currency->id, $cur_id);
            }
        }
        return $p[1] * (1 + $premiummarkupvar_value / 100) + $premiummarkupfix_value;
    }
    return false;
}

/**
 * Calculate the premium domain renew price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param integer $cur_id the currency of the domain name
 *
 * @return integer/bool the premium renew price, false if not found
 */
function ispapi_getPremiumRenewPrice($params, $class, $cur_id)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_CURRENCY");
        if ($currency === false) {
            return false;
        }
        $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
        if (!$currency) {
            return false;
        }
        $renewprice = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_ANNUAL");
        if ($renewprice && ($currency->id != $cur_id)) {
            $renewprice = convertCurrency($renewprice, $currency->id, $cur_id);
        }
        return $renewprice;
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    $p = preg_split("/\:/", $class);
    $cl = preg_split("/_/", $p[0]);
    $premiummarkupfix_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_ANNUAL_MARKUP_FIX");
    $premiummarkupvar_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_ANNUAL_MARKUP_VAR");
    if ($premiummarkupfix_value && $premiummarkupvar_value) {
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_CURRENCY");
        if ($currency !== false) {
            $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
            if (!$currency) {
                return false;
            }
            if ($currency->id != $cur_id) {
                $premiummarkupvar_value = convertCurrency($premiummarkupvar_value, $currency->id, $cur_id);
                $premiummarkupfix_value = convertCurrency($premiummarkupfix_value, $currency->id, $cur_id);
            }
        }
        return $p[1] * (1 + $premiummarkupvar_value / 100) + $premiummarkupfix_value;
    }
    return false;
}

/**
 * Calculate the domain renew price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param integer $cur_id the currency of the domain name
 * @param string $tld the tld of the domain name
 *
 * @return integer/bool the renew price, false if not found
 */
function ispapi_getRenewPrice($params, $class, $cur_id, $tld)
{
    if (empty($class)) {
        //NO PREMIUM RENEW, RETURN THE PRICE SET IN WHMCS
        $pdo = \WHMCS\Database\Capsule::connection()->getPdo();
        $stmt = $pdo->prepare("select * from tbldomainpricing tbldp, tblpricing tblp where tbldp.extension = ? and tbldp.id = tblp.relid and tblp.type = 'domainrenew' and tblp.currency=?");
        $stmt->execute(["." . $tld, $cur_id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!empty($data) && !in_array($data["msetupfee"], ["-1", "0"])) {
            return $data["msetupfee"];
        }
        return false;
        //API COMMAND GetTLDPricing IS TRIGERING JS ERROR AND IS UNUSABLE.
        // $gettldpricing_res = localAPI("GetTLDPricing", ["currencyid" => $cur_id]);
        // $renewprice = $gettldpricing_res["pricing"][$tld]["renew"][1];
        //return !empty($renewprice) ? $renewprice : false;
    }

    return ispapi_getPremiumRenewPrice($params, $class, $cur_id);
}

/**
 * Undocumented function to validate user inputs in getConfigArray's form - only invoked if configuration settings are submitted
 * commenting out as things are cached, not reliable to use
 * @link https://www.whmcs.com/members/viewticket.php?tid=ESD-183344&c=wjZ1LjOs #ESD-183344
 * @param array $params common module parameters
 * @throws Exception if estabilishing the API connection failed
 */
function ispapi_config_validate($params)
{
    $r = Ispapi::call([
        "COMMAND" => "CheckAuthentication",
        "SUBUSER" => $params["Username"],
        "PASSWORD" => $params["Password"]
    ], $params);

    if ($r["CODE"] !== "200") {
        $system = $params["TestMode"] === "on" ? "OT&E" : "LIVE";
        $error = $r["CODE"] . " " . $r["DESCRIPTION"];
        $url = "https://github.com/hexonet/whmcs-ispapi-registrar/wiki/FAQs#39-login-failed-in-registrar-module";
        throw new \Exception(
            <<<HTML
            <h2>Connecting to the {$system} Environment failed. <small>({$error})</small></h2>
            <p>Read <a href="{$url}" target="_blank" class="alert-link" style="text-decoration:underline">here</a> for possible reasons.</p>
HTML
        );
    } else {
        unset($_SESSION["ConfigurationWarning"]);
    }
}

/**
 * Return the configuration array of the module (Setup > Products / Services > Domain Registrars > ISPAPI > Configure)
 *
 * @param array $params common module parameters
 *
 * @return array $configarray configuration array of the module
 */
function ispapi_getConfigArray($params)
{
    static $meta = false;
    if (!$meta) {
        $meta = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . "whmcs.json"), true);
    }

    $migrate = !empty($meta["_priv"]["bttn_migrate"]);
    if ($migrate) {
        $newModule = $meta["name"];
        $oldModule = "hexonet";
        $oldConfig = \getregistrarconfigoptions($oldModule);

        if (@$_GET["migrate"]) {
            $migrate = false;
            // migrate registrar module settings
            if (!$params["Username"]) {
                $isLowerWHMCS8 = version_compare($params["whmcsVersion"], "8.0.0") === -1;
                foreach ($oldConfig as $key => $val) {
                    $tmp = $val;
                    if (!$isLowerWHMCS8) {
                        $r = localAPI("EncryptPassword", [
                            "password2" => $val
                        ]);
                        if ($r["result"] === "success") {
                            $tmp = $r["password"];
                        }
                    }

                    DB::table("tblregistrars")
                        ->where("registrar", $newModule)
                        ->where("setting", $key)
                        ->update([
                            "value" => $tmp
                        ]);
                }
                // reassign domains
                DB::table("tbldomains")->where("registrar", $oldModule)->update(["registrar" => $newModule]);
                // reassign pricing settings
                DB::table("tbldomainpricing")->where("autoreg", $oldModule)->update(["autoreg" => $newModule]);
                // deactivate built-in hexonet module
                DB::table("tblregistrars")->where("registrar", $oldModule)->delete();
            }
        } else {
            $matchingConfig = false;
            if ($params["Username"]) {
                $matchingConfig = (!empty($oldConfig)
                    && ($oldConfig["Username"] === $params["Username"])
                    && ($oldConfig["Password"] === $params["Password"])
                    && ($oldConfig["TestMode"] === $params["TestMode"])
                );
            }
            $migrate = (
                (!$params["Username"] || $matchingConfig) && (DB::table("tbldomains")->where("registrar", $oldModule)->count() > 0
                    || DB::table("tbldomainpricing")->where("autoreg", $oldModule)->count() > 0
                )
            );
        }
    }

    global $CONFIG;
    $parts = parse_url($CONFIG["SystemURL"]);
    $ip = gethostbyname($parts["host"]);

    return [
        "FriendlyName" => [
            "Type" => "System",
            "Value" => "\0 " . preg_replace('/v([.\d]*)/i', 'v' . CNIC_VERSION, $meta["description"]["name"])
        ],
        "Description" => [
            "Type" => "System",
            "Value" => ($meta["_priv"]["description"] .
                ($migrate ? $meta["_priv"]["bttn_migrate"] : "")
            )
        ],
        "Username" => [
            "FriendlyName" => "Username",
            "Type" => "text",
            "Size" => "20",
            "Description" => "Enter your Account Login ID"
        ],
        "Password" => [
            "FriendlyName" => "Password",
            "Type" => "password",
            "Size" => "20",
            "Description" => "Enter your Account Password"
        ],
        "TestMode" => [
            "FriendlyName" => "Use Test Environment",
            "Type" => "yesno",
            "Description" => "Connect to OT&amp;E (Test Environment)"
        ],
        "DefaultTTL" => [
            "FriendlyName" => "Default TTL",
            "Type" => "text",
            "Size" => "10",
            "Default" => "28800",
            "Description" => "Default TTL value in seconds for DNS records"
        ],
        "ProxyServer" => [
            "FriendlyName" => "Proxy Server",
            "Type" => "text",
            "Description" => "HTTP(S) Proxy Server (Optional)"
        ],
        "IRTP" => [
            "FriendlyName" => "IRTP (Inter-Registrar Transfer Policy)",
            "Type" => "radio",
            "Options" => ("Check to act as Designated Agent for all contact changes. Ensure you understand your role and responsibilities before checking this option.," .
                "Fallback to your Account's IRTP Settings."
            ),
            "Default" => "Check to act as Designated Agent for all contact changes. Ensure you understand your role and responsibilities before checking this option.",
            "Description" => $meta["_priv"]["fields"]["IRTP"]
        ],
        "TRANSFERLOCK" => [
            "FriendlyName" => "Automatic Transfer Lock",
            "Type" => "yesno",
            "Description" => "Automatically locks a Domain after Registration"
        ],
        "NSUpdTransfer" => [
            "FriendlyName" => "Automatic NS Update",
            "Type" => "yesno",
            "Description" => "Automatically update the domain's nameservers after successful transfer to the ones submitted with the order.<br/>NOTE: By default WHMCS suggests your configured Defaultnameservers in the configuration step of the shopping cart."
        ],
        "CHUpdTransfer" => [
            "FriendlyName" => "Automatic Contact Update",
            "Type" => "yesno",
            "Description" => "Automatically update the domain's contact details after successful transfer to the contact data in request.<br/>NOTE: This may lead to an IRTP contact verification / Domain Trade."
        ],
        "DNSSEC" => [
            "FriendlyName" => "Offer DNSSEC / Secure DNS",
            "Type" => "yesno",
            "Description" => "Display the DNSSEC Management functionality in the Domain Details View."
        ],
        "TRANSFERCARTPRECHECK" => [
            "FriendlyName" => "Transfer Checkout Pre-Checks",
            "Type" => "yesno",
            "Description" => "Validate Domain Transfers on Shopping Cart Checkout. This will block the checkout until all Transfer pre-checks succeed. e.g. valid eppcode, unlocked domain etc."
        ],
        "SYNCIDPROTECTION" => [
            "FriendlyName" => "Sync Id Protection",
            "Type" => "yesno",
            "Description" => "Include Synchronizing TLD Settings in Registrar TLD Sync regarding Id Protection Support."
        ],
        "SUSPENDONEXPIRATION" => [
            "FriendlyName" => "Suspend after Expiration",
            "Type" => "yesno",
            "Description" => "Automatically suspend (clientHold) Domains after the expiration date has passed and automatically unsuspend again after Renewal."
        ],
        "WHOISERRPSETTINGS" => [
            "FriendlyName" => "WHOIS Output & ERRP Settings",
            "Type" => "yesno",
            "Description" => "Offer fields for domain-level custom WHOIS Output and ERRP Settings in Client Summary > Tab Domains."
        ],
        "HPPS" => [
            "FriendlyName" => "High-Performance Setup",
            "Type" => "yesno",
            "Default" => "",
            "Description" => ("In case you experience slow performance because of network latency regarding our API communication, please use this option. " .
                "Please read <a href=\"https://centralnicgroup-public.github.io/rtldev-middleware-documentation/docs/hexonet/whmcs/whmcs-ispapi-registrar#high-performance-setup\" " .
                "target=\"_blank\" style=\"text-decoration:underline;\">this guide</a> first."
            )
        ],
        "AFTERMARKETDOMAINS" => [
            "FriendlyName" => "Aftermarket Domains",
            "Type" => "yesno",
            "Description" => "Enable Support for Aftermarket Domain Names. Domains offered via Aftermarket are getting returned as available. This Feature is not compatible with the \"Domains Extended Addon\". Mandatory: Having Premium Domains enabled."
        ],
        "AutoEnableIDProtection" => [
            "FriendlyName" => "Precheck ID Protection",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the ID protection addon on shopping cart level."
        ],
        "AutoEnableDNSManagement" => [
            "FriendlyName" => "Precheck DNS Management",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the DNS Management addon on shopping cart level."
        ],
        "AutoEnableEmailForwarding" => [
            "FriendlyName" => "Precheck Email Forwarding",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the Email Forwarding addon on shopping cart level."
        ],
        "AdditionalFieldsValidation" => [
            "FriendlyName" => "Additional Fields Validation",
            "Type" => "yesno",
            "Description" => "Enable validation for additional fields on the domain cart configuration page."
        ],
        "WebApps" => [
            "FriendlyName" => "Offer Web Apps",
            "Type" => "yesno",
            "Description" => $meta["_priv"]["fields"]["WebApps"]
        ],
        "" => [
            "Type" => "system",
            "Description" => (<<<HTML
                <div class="alert alert-info" style="font-size:medium;margin-bottom:0px;">
                    Click on Save for testing your connection to the configured Registrar System. Only in case it fails, an error will be shown.<br/><b>Your Server IP Address</b>: {$ip}
                </div>
HTML
            )
        ]
    ];
}

/**
 * Provide custom buttons for domains in admin area
 * @param array $params common module parameters
 * @return array
 */
function ispapi_AdminCustomButtonArray($params)
{
    // load registrar module
    $registrar = new \WHMCS\Module\Registrar();
    if (
        ($params["registrar"] !== "ispapi")
        || !$registrar->load($params["registrar"])
    ) {
        return [];
    }

    // load domain details
    $domain = new \WHMCS\Domains();
    $params = array_merge($params, $domain->getDomainsDatabyID($params["domainid"]));

    if ((bool)preg_match("/^(Pending|Cancelled|Expired)$/", $params["status"])) { //TODO
        return [];
    }

    // Button for flushing TLD Settings
    $buttons = [
        "Refresh TLD Cache" => "flushzonefeatures"
    ];

    // Request Pending Outgoing Transfer List
    $r = Ispapi::call([
        "COMMAND" => "QUERYFOREIGNTRANSFERLIST",
        "USERDEPTH" => "SELF",
        "DOMAIN" => $params["sld"] . "." . $params["tld"]
    ], $params);
    if (
        $r["CODE"] === "200" &&
        $r["PROPERTY"]["TOTAL"][0] === "1"
    ) {
        $buttons["Reject Transfer Out"] = "rejecttransferout";
        $buttons["Approve Transfer Out"] = "approvetransferout";
    }

    // Buttons for Transfer-related Actions
    if ($params["status"] === "Pending Transfer") {
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainRepositoryInfo",
            "DOMAIN" => $params["sld"] . "." . $params["tld"]
        ], $params);
        if (
            isset($r["PROPERTY"]["ZONEPOLICYDOMAINTRANSFERAPPROVECONFIRMATION"])
            && $r["PROPERTY"]["ZONEPOLICYDOMAINTRANSFERAPPROVECONFIRMATION"][0] === "EMAIL"
        ) {
            $buttons["Resend Transfer Approval Email"] = "resendtransferapproval";
        }
        if (
            isset($r["PROPERTY"]["REGISTRYTRANSFERREALTIME"])
            && $r["PROPERTY"]["REGISTRYTRANSFERREALTIME"][0] === "NO"
            && !(bool)preg_match("/^REGISTRY|NONE$/i", $r["PROPERTY"]["REGISTRYTRANSFERNACKBY"][0])
        ) {
            $buttons["Cancel Domain Transfer"] = "canceldomaintransfer";
        }
        return $buttons;
    }

    // Return Buttons for manual suspension / unsuspension
    $params = array_merge($params, $registrar->getSettings());
    if (HXDomain::isSuspended($params)) {
        return array_merge($buttons, [
            "Unsuspend" => "unsuspend"
        ]);
    }
    return array_merge($buttons, [
        "Suspend" => "suspend"
    ]);
}

/**
 * Resend the Transfer Approval Email
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_resendtransferapproval($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "ResendDomainTransferConfirmationEmails",
        "DOMAIN" => $domain
    ], $params);
    if ($r["CODE"] === "200") {
        cnic_track([
            "item" => $domain,
            "success" => true
        ]);
        return [
            "message" => "Successfully resent the transfer approval email"
        ];
    }
    cnic_track([
        "item" => $domain,
        "success" => false,
        "reason" => $r["DESCRIPTION"]
    ]);
    return [
        "error" => "Failed resending the transfer approval email. (" . $r["DESCRIPTION"] . ")"
    ];
}

/**
 * Flush Zone Configuration Cache
 * @param array $params common module parameters
 * @return array
 */
function ispapi_flushzonefeatures($params)
{
    HXDomain::flushZoneInformation(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
    return [
        "success" => true
    ];
}

/**
 * Approve the Domain Transfer
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_approvetransferout($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXTransfer::approve($params, $domain);
    if ($r["success"]) {
        cnic_track([
            "item" => $domain,
            "success" => true,
        ]);
        return [
            "message" => "Successfully approved the domain transfer"
        ];
    }
    cnic_track([
        "item" => $domain,
        "success" => false,
        "reason" => $r["error"]
    ]);
    $error = "Failed to approve the Transfer Request. (" . $r["error"] . ")";
    return [
        "error" => $error
    ];
}

/**
 * Reject the Domain Transfer
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_rejecttransferout($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXTransfer::reject($params, $domain);
    if ($r["success"]) {
        cnic_track([
            "item" => $domain,
            "success" => true,
        ]);
        return [
            "message" => "Successfully rejected the domain transfer"
        ];
    }
    cnic_track([
        "item" => $domain,
        "success" => false,
        "reason" => $r["error"]
    ]);
    $error = "Failed to reject the Transfer Request. (" . $r["error"] . ")";
    return [
        "error" => $error
    ];
}

/**
 * Cancel the Domain Transfer
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_canceldomaintransfer($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXTransfer::cancel($params, $domain);
    if ($r["success"]) {
        cnic_track([
            "item" => $domain,
            "success" => true,
        ]);
        return [
            "message" => "Successfully cancelled the domain transfer"
        ];
    }
    cnic_track([
        "item" => $domain,
        "success" => false,
        "reason" => $r["error"]
    ]);
    $error = "Failed to cancel the Transfer Request. (" . $r["error"] . ")";
    return [
        "error" => $error
    ];
}

/**
 * Suspend the domain name
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_suspend($params)
{
    return HXDomain::suspend($params);
}

/**
 * Unsuspend the domain name
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_unsuspend($params)
{
    return HXDomain::unsuspend($params);
}

/**
 * Provide custom buttons (whoisprivacy, DNSSEC Management) for domains and
 * change of registrant button for certain domain names on client area
 *
 * @param array $params common module parameters
 * @return array $buttonarray an array custum buttons
 */
function ispapi_ClientAreaCustomButtonArray($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $buttons = [];

    $addflds = new AF($params["TestMode"] === "on");
    $addflds->setDomainType("whoisprivacy")
        ->setDomain($domain);
    if (!empty($addflds->getFields())) {
        // registry-specific id protection
        // (free of charge, don't cover it over _IDProtectToggle/ID Protection Addon)
        $buttons[L::trans("hxwhoisprivacy")] = "whoisprivacy";
    }
    if ($params["DNSSEC"] === "on") {
        $buttons[L::trans("hxdnssecmanagement")] = "dnssec";
    }
    if ($params["dnsmanagement"] && $params["WebApps"] && WebApps::canUse($params)) {
        $buttons[L::trans("hxwebapps")] = "webapps";
    }
    if ((bool)preg_match("/\.ca$/i", $domain)) {
        $status = HXDomain::getStatus($params, $domain);
        if (
            $status["success"]
            && (bool)preg_match("/^PENDING/i", $status["data"]["STATUS"][0])
            && !empty($status["data"]["X-CA-CONTACT-REGISTRANT"][0])
        ) {
            $buttons[L::trans("hxcacontactconfirmation")] = "cacontactconfirmation";
        }
    }
    return $buttons;
}

/**
 * Handle the .CA Contact Confirmation of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name and some variables
 */
function ispapi_cacontactconfirmation($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];
    $status = HXDomain::getStatus($params, $domain);

    return [
        "templatefile" => "tpl_ca_cacontactconfirmation",
        "vars" => [
            "L" => new L(),
            "domain" => $domain,
            "error" =>  !$status["success"],
            "status" =>  HXDomain::getStatus($params, $domain)
        ]
    ];
}

/**
 * Handle the WebApps management page of a domain
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name
 */
function ispapi_webapps($params)
{
    return WebApps::getPage($params);
}

/**
 * Handle the DNSSEC management page of a domain
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name
 */
function ispapi_dnssec($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $error = false;
    $successful = false;
    $domain = $params["sld"] . "." . $params["tld"];

    if (isset($_POST["submit"])) {
        $command = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain
        ];

        if ($_POST['submit'] == 0) {
            $command['SECDNS-REMOVE-ALL'] = 1;
        } else {
            //add DS and KEY records
            foreach (["SECDNS-DS", "SECDNS-KEY"] as $keyname) {
                if (isset($_POST[$keyname])) {
                    foreach ($_POST[$keyname] as $dnssecrecord) {
                        if (in_array('', $dnssecrecord)) {
                            continue;
                        }
                        $command[$keyname][] = implode(" ", $dnssecrecord);
                    }
                }
            }
            if (count($command) <= 2) {
                $command['SECDNS-REMOVE-ALL'] = 1;
            }
        }

        //process domain update
        if (count($command) > 2) {
            $r = Ispapi::call($command, $params);
            if ($r["CODE"] === "200") {
                $successful = $r["DESCRIPTION"];
            } else {
                $error = $r["DESCRIPTION"];
            }
        }
    }

    $secdnsds_newformat = [];
    $secdnskey_newformat = [];

    $r = HXDomain::getStatus($params, $domain);
    if ($r["success"]) {
        $r = $r["data"];
        $secdnsds = (isset($r["SECDNS-DS"])) ? $r["SECDNS-DS"] : [];
        //delete empty KEY records, if cb fn not provided, array_filter will remove empty entries
        $secdnskey = (isset($r["SECDNS-KEY"])) ? array_values(array_filter($r["SECDNS-KEY"])) : [];

        //split in different fields
        foreach ($secdnskey as $key) {
            list($flags, $protocol, $alg, $pubkey) = preg_split("/\s+/", $key);
            $secdnskey_newformat[] = [
                "flags" => $flags,
                "protocol" => $protocol,
                "alg" => $alg,
                "pubkey" => $pubkey
            ];
        }

        //split in different fields
        foreach ($secdnsds as $ds) {
            list($keytag, $alg, $digesttype, $digest) = preg_split("/\s+/", $ds);
            $secdnsds_newformat[] = [
                "keytag" => $keytag,
                "alg" => $alg,
                "digesttype" => $digesttype,
                "digest" => $digest
            ];
        }
    } else {
        $error = $r["error"];
    }

    $supports_ds_data = true;
    $supports_key_data = true;
    // TODO: Migrate this to TLD Settings
    $r = Ispapi::call([
        "COMMAND" => "QueryDomainRepositoryInfo",
        "DOMAIN" => $domain
    ], $params);
    if ($r["CODE"] === "200" && isset($r["PROPERTY"]["ZONESECDNSINTERFACE"][0])) {
        $supports_ds_data = $r["PROPERTY"]["ZONESECDNSINTERFACE"][0] === "DS";
        $supports_key_data = !$supports_ds_data;
    }

    return [
        "templatefile" => "tpl_ca_dnssec",
        "vars" => [
            "supportsTTL" => false,
            "flagOptions" => [
                256 => "Zone Signing Key",
                257 => "Key Signing Key"
            ],
            "algOptions" => [
                8 => "RSA/SHA256",
                10 => "RSA/SHA512",
                12 => "GOST R 34.10-2001",
                13 => "ECDSA/SHA-256",
                14 => "ECDSA/SHA-384",
                15 => "Ed25519",
                16 => "Ed448"
            ],
            "digestOptions" => [
                2 => "SHA-256",
                3 => "GOST R 34.11-94",
                4 => "SHA-384"
            ],
            "supports_ds_data" => $supports_ds_data,
            "supports_key_data" => $supports_key_data,
            "secdnsds" => $secdnsds_newformat,
            "secdnskey" => $secdnskey_newformat,
            "successful" => $successful,
            "error" => $error,
            "disabled" => empty($secdnsds_newformat) && empty($secdnskey_newformat)
        ]
    ];
}

/**
 * Handle the ID Protection (whoisprivacy) of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name and some variables
 */
function ispapi_whoisprivacy($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];

    $addflds = new AF($params["TestMode"] === "on");
    $addflds->setDomainType("whoisprivacy")
        ->setDomain($domain);

    $error = false;
    if (isset($_POST["idprotection"])) {
        $command = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain
        ];
        $addflds->addWhoisProtectiontoCommand($command, $_POST["idprotection"]);
        $r = Ispapi::call($command, $params);
        if ($r["CODE"] !== "200") {
            $error = $r["DESCRIPTION"];
        }
    }

    $r = HXDomain::getStatus($params, $domain);
    $addflds->setFieldValuesFromAPI($r);
    $protected = $addflds->isWhoisProtected();

    return [
        "templatefile" => "tpl_ca_whoisprivacy_" . ($addflds->isWhoisProtectable() ? "protectable" : "notprotectable"),
        "vars" => [
            "L" => new L(),
            "error" => $error,
            "protected" => $protected
        ]
    ];
}

/**
 * Modify and save Transferlock settings of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - returns an array with command response description
 */
function ispapi_SaveRegistrarLock($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $result = HXDomain::saveRegistrarLock($params, $domain);

    if (isset($result["error"])) {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $result["error"]
        ]);
    } else {
        cnic_track([
            "item" => $domain,
            "success" => true
        ]);
    }

    return $result;
}

/**
 * Returns domain's information
 *
 * NOTE: fallbacks to GetNameservers and GetRegistrarLock, find details there!
 *
 * @param array $params common module parameters
 * @return \WHMCS\Domain\Registrar\Domain
 * @see https://developers.whmcs.com/domain-registrars/domain-information/
 * @see https://classdocs.whmcs.com/8.7/WHMCS/Domain/Registrar/Domain.html
 * @throws Exception
 */
function ispapi_GetDomainInformation($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $r = HXDomain::convert($params, $domain);
    $domainapi = $r["punycode"];

    $r = HXTransfer::getStatus($params, $domainapi);
    if ($r["success"] && $r["data"]["TRANSFERTYPE"][0] !== "TRADE") {
        $ns = [];
        $r = HXTransfer::getRequestCommand($params, $domainapi);
        if ($r["success"]) {
            foreach ($r["data"] as $key => $val) {
                if (preg_match("/^NAMESERVER([0-9]+)$/", $key, $m)) {
                    $ns["ns" . ((int)$m[1] + 1)] = $val;
                }
            }
        }

        $thedomain = new \WHMCS\Domain\Registrar\Domain();
        $thedomain
            ->setDomain($domain)
            ->setNameservers($ns);
        return $thedomain;
    }

    $r = HXDomain::getStatus($params, $domainapi);
    if (!$r["success"]) {
        if ($r["errorcode"] === "531") {
            throw new \Exception("Domain no longer in management - probably transferred away.");
        }
        if ($r["errorcode"] !== "545") {
            throw new \Exception("Loading Domain information failed. You may retry in few minutes.<br/><small>" . $r["errorcode"] . " " . $r["error"] . "</small>");
        }

        $appid = \WHMCS\Domain\Extra::whereDomainId($params["domainid"])
            ->whereName("ispapiApplicationID")
            ->value("value");
        if ($appid) {
            $r = HXApp::getStatus($params, $appid);
            if ($r["success"] && !empty($r["data"]["STATUS"][0])) {
                switch ($r["data"]["STATUS"][0]) {
                    case "FAILED":
                        throw new \Exception("Domain Order failed. Application #{$appid}.");
                        break;
                    case "ACTIVE":
                    case "SUCCESSFUL":
                        throw new \Exception("Domain Order succeeded. Will be soon in your Account. Application #{$appid}.");
                        break;
                    default:
                        throw new \Exception("Domain Order is pending. Check back again later. Application #{$appid}.");
                        break;
                }
            }
        }

        $status = DB::table("tbldomains")
            ->where("id", $params["domainid"])
            ->value("status");
        if ($status === "Pending") {
            $thedomain = new \WHMCS\Domain\Registrar\Domain();
            $thedomain->setDomain($domain);
            return $thedomain;
        }

        $values = HXDomain::getExpiredStatus($params, $domainapi, null, false);
        if (isset($values["transferredAway"]) && $values["transferredAway"] === true) {
            throw new \Exception("Domain no longer in management - probably transferred away.");
        }
        if (isset($values["expired"]) && isset($values["expirationdate"])) {
            if ($values["expired"] === true) {
                // in redemption period
                throw new \Exception("Domain expired, but is still renewable leading to redemption fees.");
            }
            // in ARGP
            throw new \Exception("Domain expired, but is still renewable.");
        }
        if (isset($values["expired"]) && $values["expired"] === true) {
            // expired, deleted
            $params["searchTerm"] = $params["sld"];
            $params["tldsToInclude"] = [$params["tld"]];
            $ac = ispapi_CheckAvailability($params);
            $ac = array_pop($ac->toArray());
            $msg = "Domain not found in Registrar's System. ";
            switch ($ac["status"]) {
                case SR::STATUS_NOT_REGISTERED:
                    $msg .= "Available for registration.";
                    break;
                case SR::STATUS_RESERVED:
                    $msg .= "Reserved Domain Name.";
                    break;
                case SR::STATUS_TLD_NOT_SUPPORTED:
                    $msg .= "TLD not supported.";
                    break;
                case SR::STATUS_REGISTERED: // TODO: AFTERMARKET DOMAINS!
                    $msg .= "Not available for registration.";
                    break;
                default:
                    $msg = "Eventually available for registration.";
                    break;
            }
            throw new \Exception($msg);
        }
        throw new \Exception("Loading Domain information failed. You may retry in few minutes.");
    }

    // get data: expired, expirydate, active
    $values = HXDomain::getExpiryData($params, $domainapi, false, $r, true);

    //nameservers
    $values["nameservers"] = Ispapi::castNameservers($r["data"]["NAMESERVER"]);

    // init
    $thedomain = new \WHMCS\Domain\Registrar\Domain();

    //transferlock settings
    //itrp lock
    if (isset($r["data"]["TRADE-TRANSFERLOCK-EXPIRATIONDATE"][0])) {
        // e.g. 2022-08-16 20:13:57 UTC
        $ts = Ispapi::castDate($r["data"]["TRADE-TRANSFERLOCK-EXPIRATIONDATE"][0]);
        $thedomain->setIrtpTransferLock(($ts["ts"] > time()));
        $thedomain->setIrtpTransferLockExpiryDate(\WHMCS\Carbon::createFromFormat("Y-m-d", $ts["short"]));
    }

    //registrar lock
    $tl = HXDomain::getRegistrarLock($params, $domainapi);
    if ($tl === "locked") {
        $values["transferlock"] = true; // active
    } elseif ($tl === "unlocked") {
        $values["transferlock"] = false; // inactive
    } else {
        $values["transferlock"] = null; // not supported, or error
    }

    //addons
    $values["hasidprotection"] = (isset($r["data"]["X-ACCEPT-WHOISTRUSTEE-TAC"][0])
        && $r["data"]["X-ACCEPT-WHOISTRUSTEE-TAC"][0] === "1"
    );
    $values["hasemailforwarding"] = false;
    $values["dnsmanagement"] = isset($r["data"]["INTERNALNAMESERVER"]);

    if (!$values["dnsmanagement"]) {
        $r3 = HXDns::getCountRRs($params, $domainapi . ".");
        $values["dnsmanagement"] = $r3["success"];
        if ($values["dnsmanagement"] && $r3["totalrecords"] > 0) {
            $results = ispapi_GetEmailForwarding($params);
            $values["hasemailforwarding"] = (!isset($results["error"]) && !empty($results));
            $values["dnsmanagement"] = $values["hasemailforwarding"];
        }
    }

    //IRTP handling
    $values["setIsIrtpEnabled"] = false;
    $values["IRTPTriggerFields"] = [];
    $zi = HXDomain::getZoneInformation($params, $domainapi);
    if (!is_null($zi)) {
        $values["setIsIrtpEnabled"] = $zi->trade->isIRTP;
        $values["IRTPTriggerFields"] = $zi->trade->triggerFields;
    }

    //check if registrant change has been requested
    if (
        isset($r["data"]["X-REGISTRANT-VERIFICATION-STATUS"][0])
        && (bool)preg_match("/^PENDING|REMINDED$/i", $r["data"]["X-REGISTRANT-VERIFICATION-STATUS"][0])
    ) {
        $thedomain->setDomainContactChangePending(true)
            ->setPendingSuspension(false);
        if (isset($r["data"]["X-REGISTRANT-VERIFICATION-DUEDATE"][0])) {
            $ts = Ispapi::castDate($r["data"]["X-REGISTRANT-VERIFICATION-DUEDATE"][0]);
            if ($ts["ts"] > time()) {
                $thedomain->setDomainContactChangeExpiryDate(\WHMCS\Carbon::createFromFormat("Y-m-d H:i:s", $ts["long"]));
            }
        }
    }
    if (
        isset($r["data"]["X-REGISTRANT-VERIFICATION-STATUS"][0])
        && (bool)preg_match("/^OVERDUE$/i", $r["data"]["X-REGISTRANT-VERIFICATION-STATUS"][0])
    ) {
        $thedomain->setDomainContactChangePending(false)
            ->setPendingSuspension(true);
    }

    // Docs:
    // https://classdocs.whmcs.com/8.1/WHMCS/Domain/Registrar/Domain.html
    // https://developers.whmcs.com/domain-registrars/domain-information/
    // https://carbon.nesbot.com/docs/
    $thedomain->setDomain($domain)
        ->setNameservers($values["nameservers"])
        //->setRegistrationStatus($response["status"])
        ->setTransferLock($values["transferlock"])
        //->setTransferLockExpiryDate(null)
        ->setExpiryDate($values["expirydate"])
        //->setRestorable(false)
        //->setRegistrantEmailAddress($response["registrant"]["email"])
        // -- IRTP
        ->setIsIrtpEnabled($values["setIsIrtpEnabled"])
        ->setIrtpVerificationTriggerFields($values["IRTPTriggerFields"])
        //-- ->setIrtpOptOutStatus(false)
        // -- addons
        ->setIdProtectionStatus($values["hasidprotection"])
        ->setDnsManagementStatus($values["hasdnsmanagement"])
        ->setEmailForwardingStatus($values["hasemailforwarding"]);

    // add custom data (for import purposes)
    // registrant vatid
    $keys = array_keys($r["data"]);
    $vatid = "";
    $pnames = preg_grep(
        "/admin|tech|billing/i",
        preg_grep("/vatid/i", $keys),
        PREG_GREP_INVERT
    );
    foreach ($pnames as $prop) {
        if (!empty($r["data"][$prop][0])) {
            $vatid = $r["data"][$prop][0];
            break;
        }
    }

    // registration date
    $registrationdate = Ispapi::castDate($r["data"]["CREATEDDATE"][0]);

    // set custom data
    $thedomain->registrarData = [
        "isPremium" => (bool) preg_match("/^premium_/i", $r["data"]["SUBCLASS"][0]),
        "isTrusteeUsed" => (empty($r["data"]["X-TRUSTEE"][0])) ? 0 : 1,
        "createdDate" => $registrationdate["long"],
        "registrantTaxId" => $vatid
    ];

    // idnLanguage detection
    if ($r["data"]["DOMAINUMLAUT"][0] !== $r["data"]["ID"][0]) {
        if (isset($params["idnlanguage"])) {
            $lang = $params["idnlanguage"];
            $thedomain->registrarData["idnLanguage"] = $lang;
        } else {
            $lang = HXDomain::getIDNLanguage($params, $r["data"]["ID"][0]);
            if ($lang["success"]) {
                $thedomain->registrarData["idnLanguage"] = $lang["language"];
            }
        }
    }

    return $thedomain;
}
/**
 * Resend verification email
 *
 * @param array $params common module parameters
 *
 * @return array returns success or error
 */
function ispapi_ResendIRTPVerificationEmail($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "ResendDomainRegistrantVerificationEmail",
        "DOMAIN" => $domain
    ], $params);
    if ($r["CODE"] === "200") {
        cnic_track([
            "item" => $domain,
            "success" => true
        ]);

        return [
            "success" => true
        ];
    }

    cnic_track([
        "item" => $domain,
        "success" => false,
        "reason" => $r["DESCRIPTION"]
    ]);

    return [
        "error" => $r["CODE"] . " " . $r["DESCRIPTION"]
    ];
}

/**
 * Return the authcode of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values an array with the authcode
 */
function ispapi_GetEPPCode($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXDomain::getAuthCode($params, $domain);
    if (isset($r["error"])) {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $r["error"]
        ]);
    } else {
        cnic_track([
            "item" => $domain,
            "success" => true
        ]);
    }

    return $r;
}

/**
 * Modify and save Nameservers of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - returns an array with command response description
 */
function ispapi_SaveNameservers($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];
    $dnszone = $domain . ".";

    $r = Ispapi::call([
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $domain,
        "NAMESERVER" => Ispapi::castNameserversBE($params, false),
        "INTERNALDNS" => (int)$params["dnsmanagement"]
    ], $params);
    if ($r["CODE"] !== "200") {
        $error = $r["DESCRIPTION"];
        if ($r["CODE"] === "504" && preg_match("/TOO FEW.+CONTACTS/", $error)) {
            $error = "Please update contact data first to be able to update nameserver data.";
        }

        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $error
        ]);

        return [
            "error" => $error
        ];
    }

    if ($params["dnsmanagement"] || $params["emailforwarding"]) {
        $r = HXDns::getStatus($params, $dnszone);
        if (!$r["success"] && ($r["errorcode"] === "545")) {
            HXDns::create($params, $dnszone);
        }
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);

    return [
        "success" => true
    ];
}

/**
 * Get DNS Zone of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $hostrecords - an array with hostrecord of the domain name
 */
function ispapi_GetDNS($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $dnszone = $domain . ".";

    //convert the dnszone to punycode
    $r = HXDomain::convert($params, $domain);
    $domain = $r["punycode"];
    $dnszone_pc = $domain . ".";

    // Check if DNSZone exists, if not create it
    $r = HXDns::getStatus($params, $dnszone_pc);
    if (!$r["success"] && ($r["errorcode"] === "545")) {
        $r = Ispapi::call([
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "INTERNALDNS" => 1
        ], $params);
        if ($r["CODE"] !== "200") {
            return [
                "error" => $response["CODE"] . " " . $r["DESCRIPTION"]
            ];
        }
        HXDns::create($params, $dnszone_pc);
        return [];
    }

    // Load list of Resource Records
    $response = Ispapi::call([
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $dnszone_pc,
        "EXTENDED" => 1,
        "SHORT" => 1
    ], $params);
    if ($response["CODE"] !== "200") {
        if ($response["CODE"] === "545") {
            return [];
        }
        return [
            "error" => $response["CODE"] . " " . $response["DESCRIPTION"]
        ];
    }

    $supportedTypes = ("/^(" .
        implode("|", [
            "A", "AAAA", "ALIAS", "CAA", "CNAME", "MX", "MXE",
            "NAPTR", "NS", "PTR", "SPF", "SSHFP", "SRV", "TXT",
            "TLSA", "X-HTTP"
        ]) .
        ")$/"
    );

    $hostrecords = [];
    foreach ($response["PROPERTY"]["RR"] as $rr) {
        $fields = explode(" ", $rr);
        $domain = array_shift($fields);
        $ttl = array_shift($fields);
        $class = array_shift($fields);
        $rrtype = array_shift($fields);

        if (!(bool)preg_match($supportedTypes, $rrtype)) {
            continue;
        }

        if ((bool)preg_match("/^(A|AAAA|CNAME)$/", $rrtype)) {
            if (
                $rrtype !== "A" ||
                !preg_match("/^mxe-host-for-ip-(\d+)-(\d+)-(\d+)-(\d+)$/i", $domain, $m)
            ) {
                $hostrecords[] = [
                    "hostname" => $domain,
                    "ttl" => $ttl,
                    "type" => $rrtype,
                    "address" => $fields[0]
                ];
                continue;
            }
        }

        if ($rrtype === "SRV" || $rrtype === "MX") {
            $priority = array_shift($fields);
            $hostrecords[] = [
                "hostname" => $domain,
                "ttl" => $ttl,
                "type" => $rrtype,
                "address" => implode(" ", $fields),
                "priority" => $priority
            ];
            continue;
        }

        if ($rrtype === "X-HTTP") {
            if (preg_match("/^\//", $fields[0])) {
                $domain .= array_shift($fields);
            }

            $url_type = array_shift($fields);
            if ($url_type === "REDIRECT") {
                $url_type = "URL";
            }

            $hostrecords[] = [
                "hostname" => $domain,
                "ttl" => $ttl,
                "type" => $url_type,
                "address" => implode(" ", $fields)
            ];
            continue;
        }

        // TXT or other records
        $hostrecords[] = [
            "hostname" => $domain,
            "ttl" => $ttl,
            "type" => $rrtype,
            "address" => implode(" ", $fields)
        ];
    }
    return $hostrecords;
}

/**
 * Function to flatten WHMCS parsed DNS RR Format to API Parameter Values
 * @param string $domain the domain name
 * @param array list of resource records (e.g. result of GetDNS)
 * @param array $params common module parameters
 * @return array
 */
function ispapi_flattenRR($domain, $rrs, $params)
{
    if (empty($rrs)) {
        return [];
    }
    //convert the dnszone to punycode
    $r = HXDomain::convert($params, $domain . ".");
    $zonenames = array_unique([
        $r["punycode"],
        $r["idn"]
    ]);

    $flattened = [];
    foreach ($rrs as $recIdx => $values) {
        $hostname = $values["hostname"];
        // e.g.
        // hexonet.se. -> ""
        // asdf.hexonet.se. -> asdf
        // DELRR -> SHORT VERSIONS
        // ADDRR = INPUTS may be about non-short versions
        // ---> manually converting it to short variant to avoid duplicates
        foreach ($zonenames as $dzone) {
            //$dnszone_pc e.g. xn--[:ascii:]*\.
            //$dnszone_idn e.g. müller.com.
            $hostname = str_replace(
                ["." . $dzone, $dzone],
                "",
                $hostname
            );
            if ($hostname === "") {
                $hostname = "@";
            }
            if ($hostname !== $values["hostname"]) { // original value changed
                break;
            }
        }

        $address = $values["address"];
        $type = strtoupper($values["type"]);
        $ttl = $_POST["dnsrecordttl"][$recIdx] ?? $params["DefaultTTL"] ?? "28800";
        if (!is_numeric($ttl)) {
            $ttl = "28800";
        }

        // all types other than ...
        if (!(bool)preg_match("/^(FRAME|URL|SRV|MX|MXE)$/", $type)) {
            $flattened[] = "$hostname $ttl $type $address";
            continue;
        }

        if ((bool)preg_match("/^(FRAME|URL)$/", $type)) {
            $redirect = $type === "FRAME" ? $type : "REDIRECT";
            if (preg_match("/^([^\/]+)(.*)$/", $hostname, $m)) {
                $hostname = $m[1];
                $redirect = $m[2] . " " . $redirect;
            }
            $flattened[] = "$hostname $ttl X-HTTP $redirect $address";
            continue;
        }

        $priority = $values["priority"] ?? "0";
        if ($type === "SRV") {
            $flattened[] = "$hostname $ttl $type $priority $address";
            continue;
        }

        // keep MXE in front of MX
        if ($type === "MXE") {
            if (preg_match("/^([0-9]+) (.*)$/", $address, $m)) {
                $mxpref = $m[1];
                $address = $m[2];
            } elseif (preg_match("/^([0-9]+)$/", $priority)) {
                $mxpref = $priority;
            } else {
                $mxpref = "100";
            }

            if (preg_match("/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/", $address, $m)) {
                $mxe_host = "mxe-host-for-ip-$m[1]-$m[2]-$m[3]-$m[4]";
                $ip = $m[1] . "." . $m[2] . "." . $m[3] . "." . $m[4];
                $flattened[] = "$hostname $ttl MX $mxpref $mxe_host";
                $flattened[] = "$mxe_host A $ip";
                continue;
            }

            $address = "$mxpref $address";
            $type = "MX";
        }

        if ($type === "MX") {
            if (preg_match("/^([0-9]+)$/", $priority)) {
                $flattened[] = "$hostname $ttl $type $priority $address";
                continue;
            }
            if (preg_match("/^([0-9]+) (.*)$/", $address, $m)) {
                $priority = $m[1];
                $address = $m[2];
                $flattened[] = "$hostname $ttl $type $priority $address";
                continue;
            }
            $priority = "100"; // mxpref
            $flattened[] = "$hostname $ttl $type $priority $address";
            continue;
        }
    }
    return $flattened;
}

/**
 * Modify and save DNS Zone of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $hostrecords - an array with hostrecord of the domain name
 */
function ispapi_SaveDNS($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $dnszone = $domain . ".";

    $command = [
        "COMMAND" => "UpdateDNSZone",
        "DNSZONE" => $dnszone,
        "RESOLVETTLCONFLICTS" => 1,
        "INCSERIAL" => 1,
        "EXTENDED" => 1
    ];
    // add cleanup for supported existing RRs
    // replacement for not working wildcard deletion e.g. "% A" ...
    // we just delete RRs supported by WHMCS (and thus returned to it)
    // later, we'll be cleaning up DELRR/ADDRR for entries which haven't been touched
    // RR# would delete all RRs not supported by WHMCS
    $rrs = ispapi_GetDNS($params);
    if (isset($rrs["error"])) {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $rrs["error"]
        ]);
        return $rrs;
    }

    $command["DELRR"] = ispapi_flattenRR($domain, $rrs, $params);

    // remove invalid entries
    $params["dnsrecords"] = array_filter($params["dnsrecords"], function ($rr) {
        return (strlen($rr["hostname"])
            && strlen($rr["address"])
        );
    });

    // prepare update command
    $command["ADDRR"] = ispapi_flattenRR($domain, $params["dnsrecords"], $params);

    // remove duplicates from ADDRR array which ends in an api error otherwise
    $command["ADDRR"] = array_unique($command["ADDRR"]);
    $command["DELRR"] = array_unique($command["DELRR"]);

    // check for entries in ADDRR that match ones in DELRR
    // ... and thus haven't been touched and can be left out
    if (!empty($command["ADDRR"])) {
        foreach ($command["DELRR"] as $idx => $delrr) {
            $idx2 = array_search($delrr, $command["ADDRR"]);
            if ($idx2 === false) { // not found
                continue;
            }
            unset(
                $command["DELRR"][$idx],
                $command["ADDRR"][$idx2]
            );
        }
    }

    // cleanup index holes (unset used above)
    // otherwise the api either won't consider all RRs or ending in error
    $command["ADDRR"] = array_values($command["ADDRR"]);
    $command["DELRR"] = array_values($command["DELRR"]);

    // nothing to do ...
    if (empty($command["ADDRR"]) && empty($command["DELRR"])) {
        return [
            "success" => "success"
        ];
    }

    //send command to update DNS Zone
    #var_dump($command);
    $response = Ispapi::call($command, $params);

    //case 545: DNS Zone not existing, shouldn't happen any longer, see GetDNS fn
    if ($response["CODE"] !== "200") {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $response["DESCRIPTION"]
        ]);
        return [
            "error" => $response["CODE"] . " " . $response["DESCRIPTION"]
        ];
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);
    return [
        "success" => "success"
    ];
}

/**
 * Get Email forwarding of a domain name with its DNS zone
 *
 * @param array $params common module parameters
 *
 * @return array $result - returns an array with command response description
 */
function ispapi_GetEmailForwarding($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    //convert the dnszone to punycode
    $rconv = HXDomain::convert($params, ($params["sld"] . "." . $params["tld"]));
    $dnszone_pc = $rconv["punycode"] . ".";
    $domain = $rconv["punycode"];

    // Check if DNSZone exists, if not create it
    $r = HXDns::getStatus($params, $dnszone_pc);
    if (!$r["success"] && ($r["errorcode"] === "545")) {
        $r = Ispapi::call([
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "INTERNALDNS" => 1
        ], $params);
        if ($r["CODE"] !== "200") {
            return [
                "error" => $r["DESCRIPTION"]
            ];
        }
        HXDns::create($params, $dnszone_pc);
        return [];
    }

    // fetch X-DNS X-SMTP / MAILFORWARD RRs
    $r = Ispapi::call([
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $dnszone_pc,
        "SHORT" => 1,
        "EXTENDED" => 1,
        "RRTYPE" => "X-SMTP"
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    $result = [];
    foreach ($r["PROPERTY"]["RR"] as $rr) {
        $fields = explode(" ", $rr);
        if (
            // MAILFORWARD Identifier
            ($fields[5] !== "MAILFORWARD")
            // prefix
            || !(bool)preg_match("/^(.*)\@$/", $fields[4], $m)
        ) {
            continue;
        }
        $result[] = [
            "prefix" => (strlen($m[1])) ? $m[1] : "*",
            "forwardto" => $fields[6]
        ];
    }
    return $result;
}

/**
 * Save Email forwarding of a domain name by updating its DNS zone
 * TODO: Child Template for Error Reporting
 * @param array $params common module parameters
 * @return array $values - returns an array with command response description
 */
function ispapi_SaveEmailForwarding($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $dnszone = $params["sld"] . "." . $params["tld"] . ".";

    //Bug fix - Issue WHMCS
    // still required? present since Module v1.0.46!
    //###########
    if (is_array($params["prefix"][0])) {
        $params["prefix"][0] = $params["prefix"][0][0];
    }
    if (is_array($params["forwardto"][0])) {
        $params["forwardto"][0] = $params["forwardto"][0][0];
    }
    //###########

    $command = [
        "COMMAND" => "UpdateDNSZone",
        "DNSZONE" => $dnszone,
        "RESOLVETTLCONFLICTS" => 1,
        "INCSERIAL" => 1,
        "EXTENDED" => 1,
        "DELRR" => ["@ X-SMTP"],
        "ADDRR" => [],
    ];

    foreach ($params["prefix"] as $key => $prefix) {
        $target = $params["forwardto"][$key];
        if (!strlen($prefix) || !strlen($target)) {
            continue;
        }
        if ($prefix === "*") {
            $prefix = "";
        }
        $command["ADDRR"][] = "@ X-SMTP $prefix@ MAILFORWARD $target";
    }

    $response = Ispapi::call($command, $params);

    if ($response["CODE"] !== "200") {
        cnic_track([
            "item" => $dnszone,
            "success" => false,
            "reason" => $response["DESCRIPTION"]
        ]);
        return [
            "error" => $response["DESCRIPTION"]
        ];
    }

    cnic_track([
        "item" => $dnszone,
        "success" => true
    ]);
    return [];
}

/**
 * Contact data of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with different contact values.
 */
function ispapi_GetContactDetails($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $r = HXDomain::getStatus($params, $domain);
    if (!$r["success"]) {
        return [
            "error" => "Failed to load Contact Details (" . $r["errorcode"] . " " . $r["error"] . ")."
        ];
    }
    return HXContact::getInfo($params, $r);
}

/**
 * Modify and save contact data of a domain name
 *
 * @param array $params common module parameters
 * @param boolean $isPostTransfer if we are in Post-Transfer Processing
 *
 * @return array $values - an array with command response description
 */
function ispapi_SaveContactDetails($params, $isPostTransfer = false)
{
    $contacts = ispapi_GetContactDetails($params);
    $isEmailEmpty = (empty($contacts["Registrant"]["Email"]));

    $params_transliterated = $params;
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $msgPrefix = "{$domain}: " . ($isPostTransfer ? "Post-Transfer; " : "");

    $idprotection = ($params["idprotection"] === true) ? 1 : 0;
    // API Command Stub
    $command = [
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $domain,
        "X-ACCEPT-WHOISTRUSTEE-TAC" => $idprotection
    ];

    // protect .at whois data by default
    // no additional fields! (helloly)
    // TODO: probably worth moving it to addToCommand function
    // AT -> ZONEPOLICYREGISTRANTNAMECHANGEBY = UPDATE
    if (preg_match("/\.at$/i", $domain)) {
        $command["X-AT-DISCLOSE"] = "0";
    }

    // add contact data to the API command
    HXContact::updFromParams($command, $params_transliterated);

    // prepare additional domain fields (UPDATE)
    // https://developers.whmcs.com/domain-registrars/module-parameters/
    // while $_POST has a different key
    // in earlier version we shipped with a way for injecting fields on contact information page
    // which we deprecated with v21 on admin area side - this fallback is necessary therefore.
    // on client area we still have the domain fields injected as this is easy going via child themes
    if (!isset($_POST["domainfield"])) {
        $_POST["domainfield"] = $params["additionalfields"];
    }

    $updaddflds = new AF($params["TestMode"] === "on");
    $updaddflds->setDomainType("update")
        ->setDomain($domain);

    // Try Trade
    // check if change of registrant requires a trade
    $zi = HXDomain::getZoneInformation($params, $domain);

    if (!$isEmailEmpty && !is_null($zi) && $zi->trade->required) { // IRTP, Standard Trade
        $cmd = [
            "COMMAND" => "TradeDomain",
            "DOMAIN" => $domain,
            //"X-ACCEPT-WHOISTRUSTEE-TAC" => $idprotection // not supported atm
        ];

        // add contact data to the API command
        HXContact::updFromParams($cmd, $params_transliterated);
        // add additional domain fields to the API command
        $trdaddflds = new AF($params["TestMode"] === "on");
        $trdaddflds->setDomainType("trade")
            ->setDomain($domain)
            ->setFieldValuesFromPost();
        $trdaddflds->addToCommand($cmd);

        // IRTP specifics --- TODO: we could cover these fields over AdditionalFields
        if ($zi->trade->isIRTP) {
            $cmd["X-REQUEST-OPT-OUT-TRANSFERLOCK"] = ($params["irtpOptOut"] ? 1 : 0);
            // TODO: $params["irtpOptOutReason"]
            if ((bool)preg_match("/Designated Agent/", $params["IRTP"])) {
                $cmd["X-CONFIRM-DA-OLD-REGISTRANT"] = 1;
                $cmd["X-CONFIRM-DA-NEW-REGISTRANT"] = 1;
            }
            //HM-735: opt-out is not supported for AFNIC TLDs (pm, tf, wf, yt, fr, re)
            if (!$zi->isAFNIC) {
                $cmd["X-REQUEST-OPT-OUT-TRANSFERLOCK"] = 0;
                if ($params["irtpOptOut"]) {
                    $cmd["X-REQUEST-OPT-OUT-TRANSFERLOCK"] = 1;
                }
            }
        } else {
            $tld = strtolower(preg_replace("/^.+\./", ".", $domain)); //2nd lvl tld
            if (AF::requiresFaxForm($tld, "trade")) {
                $tldcl = substr($tld, 1); //strip leading dot
            }
        }

        // API request
        $r = Ispapi::call($cmd, $params);
        if ($r["CODE"] === "200") {
            $msg = $msgPrefix . "Contact Update by Trade Method succeeded/initiated ";
            try {
                $p = HXTrade::getPrice($params, $tldcl ?? $params["tld"]);
                if ($p) {
                    $title = "Manual Domain Trade Invoice";
                    $basemsg = "Domain: " . $domain . ", the successfully initiated Ownerchange wasn't for free: ";
                    $extmsg = "\n\nWHMCS Core isn't supporting such types of trades and their costs which is the reason why we as registrar are informing you.";
                    addToDoItem($title, $basemsg . ($p["price"] . " " . $p["currency"]) . "\n\n" . $extmsg);
                    $msg .= "(Price: " . $p["price"] . " " . $p["currency"] . ").";
                } else {
                    $msg .= "(free of charge).";
                }
            } catch (\Exception $e) {
            } // table ispapi_relations does not exist if Registrar TLD Sync hasn't been used yet
            cnic_track(["custom" => $msg]);
            $trdaddflds->saveToDatabase($params["domainid"], true);
            // respond including pending information
            return $trdaddflds->respondPending($r);
        }
        if (
            !(
                ($r["CODE"] === "506" || $r["CODE"] === "219")
                && (bool)preg_match("/(trade is only allowed for change of registrant|please use UPDATE method)/", $r["DESCRIPTION"])
            )
        ) {
            cnic_track(["custom" => $msgPrefix . "Contact Update by Trade Method failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")."]);
            return [
                "error" => "Updating Contact Information failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")."
            ];
        }
        // load additional domain fields from different type (TRADE)
        // hint: X-.+-REGISTRATION-TAC not allowed for update, but sent with trade
        $updaddflds->setFieldValuesFromPostType("trade");
    } else {
        $updaddflds->setFieldValuesFromPost();
    }

    // add additional fields to command
    $updaddflds->addToCommand($command);

    // API request
    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        cnic_track(["custom" => $msgPrefix . "Contact Update failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")."]);
        // Data management policy violation; Update domain combination of status, name server and registrant is not allowed
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    cnic_track(["custom" => $msgPrefix . "Contact Update succeeded."]);
    $updaddflds->saveToDatabase($params["domainid"], true);
    // respond including pending information
    return $updaddflds->respondPending($r);
}

/**
 * Add a new Private Nameserver (=GLUE RECORD)
 * A glue record is simply the association of a hostname (nameserver in our case) with an IP address at the registry
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_RegisterNameserver($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "AddNameserver",
        "NAMESERVER" => $params["nameserver"],
        "IPADDRESS0" => $params["ipaddress"]
    ], $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $params["nameserver"],
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);

        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    cnic_track([
        "item" => $params["nameserver"],
        "success" => true
    ]);

    return [
        "success" => "Private Nameserver Registration success"
    ];
}

/**
 * Modify a Private Nameserver
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_ModifyNameserver($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "ModifyNameserver",
        "NAMESERVER" => $params["nameserver"],
        "DELIPADDRESS0" => $params["currentipaddress"],
        "ADDIPADDRESS0" => $params["newipaddress"],
    ], $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $params["nameserver"],
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);

        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    cnic_track([
        "item" => $params["nameserver"],
        "success" => true
    ]);

    return [
        "success" => "Private Nameserver Update success"
    ];
}

/**
 * Delete a Private Nameserver
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_DeleteNameserver($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "DeleteNameserver",
        "NAMESERVER" => $params["nameserver"]
    ], $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $params["nameserver"],
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    cnic_track([
        "item" => $params["nameserver"],
        "success" => true
    ]);

    return [
        "success" => "Private Nameserver Deletion succeeded."
    ];
}

/**
 * Toggle the ID Protection of a domain name
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_IDProtectToggle($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $domain,
        "X-ACCEPT-WHOISTRUSTEE-TAC" => ($params["protectenable"]) ? "1" : "0"
    ], $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);

    return [
        "success" => "success"
    ];
}

/**
 * Register a domain name - Premium support
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_RegisterDomain($params)
{
    $params_transliterated = $params;
    $premiumDomainsEnabled = (bool) $params["premiumEnabled"];
    $premiumDomainsCost = $params["premiumCost"];
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $dnszone = $domain . ".";

    $command = [
        "COMMAND" => "AddDomain",
        "DOMAIN" => $domain,
        "PERIOD" => $params["regperiod"],
        "NAMESERVER" => Ispapi::castNameserversBE($params, false),
    ];
    // add contacts
    HXContact::getFromParams($command, $params_transliterated);

    if (preg_match("/\.swiss$/i", $domain)) {
        $command["COMMAND"] = "AddDomainApplication";
        $command["CLASS"] = "GOLIVE";
    }
    //#####################################################################
    //##################### PREMIUM DOMAIN HANDLING #######################
    //######################################################################
    //check if premium domain functionality is enabled by the admin
    //check if the domain has a premium price
    if ($premiumDomainsEnabled && !empty($premiumDomainsCost)) {
        $check = Ispapi::call([
            "COMMAND" => "CheckDomains",
            "DOMAIN0" => $domain,
            "PREMIUMCHANNELS" => "*"
        ], $params);
        if ($check["CODE"] === "200") {
            // RSRMID-1005 # Ignore CheckAvailability price as there is a difference in price between querydomainsuggestionlist and checkavailaibility command results.
            // $regprice = $check["PROPERTY"]["PRICE"][0];
            $regclass = !empty($check["PROPERTY"]["CLASS"][0]) ? $check["PROPERTY"]["CLASS"][0] : (
                !empty($check["PROPERTY"]["PREMIUMCHANNEL"][0]) ? "AFTERMARKET_PURCHASE_" . $check["PROPERTY"]["PREMIUMCHANNEL"][0] : "AFTERMARKET_PURCHASE_AFTERNIC"
            );
            $regcurrency = !empty($check["PROPERTY"]["CURRENCY"][0]) ? $check["PROPERTY"]["CURRENCY"][0] : "USD";

            // RSRMID-1005 # Ignore CheckAvailability price as there is a difference in price between querydomainsuggestionlist and checkavailaibility command results.
            // if ($premiumDomainsCost == $regprice) { //check if the price displayed to the customer is equal to the real cost at the registar
            $command["COMMAND"] = "AddDomainApplication";
            $command["CLASS"] =  $regclass;
            $command["PRICE"] = number_format(ceil($premiumDomainsCost * 100) / 100, 2, ".", "");
            $command["CURRENCY"] = $regcurrency;
            //}
        }
    }
    //#####################################################################

    $isDomainApp = $command["COMMAND"] === "AddDomainApplication";
    if (!$isDomainApp) {
        //--- TODO ---
        //INTERNALDNS, X-ACCEPT-WHOISTRUSTEE-TAC, TRANSFERLOCK parameters are not
        //supported in AddDomainApplication command. We need to sync this later.
        if ($params["TRANSFERLOCK"]) {
            $command["TRANSFERLOCK"] = 1;
        }
        if ($params["dnsmanagement"] || $params["emailforwarding"]) {
            $command["INTERNALDNS"] = 1;
        }
        if ($params["idprotection"]) {
            $command["X-ACCEPT-WHOISTRUSTEE-TAC"] = 1;
        }
    }

    // protect .at whois data by default
    // no additional fields! (helloly)
    // TODO: probably worth moving it to addToCMD function
    if (preg_match("/\.at$/i", $domain)) {
        $command["X-AT-DISCLOSE"] = "0";
    }

    AF::addToCMD($params, $command);

    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    // .SWISS, Premium Domains, Aftermarket, ...
    // specific application handling
    if ($isDomainApp) {
        $appid = $r["PROPERTY"]["APPLICATION"][0];
        $extraDetails = \WHMCS\Domain\Extra::firstOrNew([
            "domain_id" => $params["domainid"],
            "name" => "ispapiApplicationID"
        ]);
        $extraDetails->value = $appid;
        $extraDetails->save();

        cnic_track([
            "item" => $domain,
            "success" => true,
            "reason" => "APPLICATION ID {$appid} SUCCESSFULLY SUBMITTED"
        ]);

        return [
            "success" => true,
            "pending" => true,
            "pendingMessage" => (
                "APPLICATION ID <strong>" . $appid . "</strong> SUCCESSFULLY SUBMITTED." .
                " STATUS IS PENDING UNTIL THE REGISTRATION PROCESS IS COMPLETED"
            )
        ];
    }

    if (isset($command["INTERNALDNS"]) && $command["INTERNALDNS"] === 1) {
        $rdns = HXDns::getStatus($params, $dnszone);
        if (!$rdns["success"] && ($rdns["errorcode"] === "545")) {
            HXDns::create($params, $dnszone);
        }
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);
    if (isset($r["PENDING"]) && $r["PENDING"] === "1") {
        return [
            "success" => true,
            "pending" => true,
            "pendingMessage" => (
                "Domain Registration Request submitted. " .
                "Status is pending until the Completion of the Registration Process."
            )
        ];
    }
    return [
        "success" => true
    ];
}

/**
 * Transfer a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_TransferDomain($params)
{
    $params_transliterated = $params;
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $premiumDomainsEnabled = (bool) $params["premiumEnabled"];
    $premiumDomainsCost = $params["premiumCost"];

    $r = HXDomain::convert($params, $domain);
    $domainapi = $r["punycode"];

    //domain transfer pre-check
    $r = HXTransfer::precheck($params, $domainapi);
    if (isset($r["error"])) {
        return $r;
    }

    $command = [
        "COMMAND" => "TransferDomain",
        "DOMAIN" => $domainapi,
        "PERIOD" => $params["regperiod"], //this does not fit to all TLDs (vs default transfer period)
        "NAMESERVER" => Ispapi::castNameserversBE($params, false), // this may be taken, depends on tld
        "AUTH" => $params["eppcode"]
    ];

    // auto-detect user-transfer
    if (
        isset($r["data"]["USERTRANSFERREQUIRED"])
        && $r["data"]["USERTRANSFERREQUIRED"][0] === "1"
    ) {
        // user-transfers always require an auth - even for tlds that do not require an auth for transfer!
        // this is totally incompatible to the eppcode setting in whmcs and whmcs' transfer process
        $command["ACTION"] = "USERTRANSFER";
        if (!strlen($command["AUTH"])) { // this will fail for internal transfers
            cnic_track([
                "item" => $domain,
                "success" => false,
                "domainid" => $params["domainid"],
                "reason" => "eppcode is mandatory for registrar-internal transfers."
            ]);
            return [
                "error" => "eppcode is mandatory for registrar-internal transfers."
            ];
        }
    }

    $zi = HXDomain::getZoneInformation($params, $domainapi);
    if (!is_null($zi)) {
        // add contacts just not in case of ownerchange by trade / irtp-trade,
        // exception AFNIC TLDs: admin-c + tech-c == mandatory
        // IDEA: better would be a post-transfer update process (not in transfer process)
        if ($zi->transfer->includeContacts) {
            HXContact::getFromParams($command, $params_transliterated, $zi->transfer->contacts);
        }

        // BEGIN------------------------------------------------------------------------
        // auto-detect default transfer period
        // for example, .NO, .NU tlds require period value as zero (free transfers).
        // in WHMCS the default value is 1 (1Y)
        // if transfer for free is supported and regperiod not listed in supported periods
        // if provided period isn't supported for transfers at all, use the default one we support
        if (!in_array((int)$params["regperiod"], $zi->transfer->periods)) {
            $command["PERIOD"] = $zi->transfer->defaultPeriod;
            if ($zi->transfer->isFree) {
                $command["PERIOD"] =  "0Y";
            }
        }
        // END ------------------------------------------------------------------------
    }

    //#####################################################################
    //##################### PREMIUM DOMAIN HANDLING #######################
    //######################################################################
    if ($premiumDomainsEnabled && !empty($premiumDomainsCost)) {
        //check if premium domain functionality is enabled by the admin
        //check if the domain has a premium price
        $chk = Ispapi::call([
            "COMMAND" => "CheckDomains",
            "DOMAIN0" => $domainapi,
            "PREMIUMCHANNELS" => "*"
        ], $params);
        //todo - it would propbably be better to rely on ispapi_CheckAvailability
        if ($chk["CODE"] === "200" && !empty($chk["PROPERTY"]["CLASS"][0])) {
            //check if the price displayed to the customer is equal to the real cost at the registar
            $price = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $chk["PROPERTY"]["CLASS"][0] . "_TRANSFER");
            if ($price !== false && $premiumDomainsCost == $price) {
                $command["CLASS"] = $chk["PROPERTY"]["CLASS"][0];
            } else {
                cnic_track([
                    "item" => $domain,
                    "success" => false,
                    "domainid" => $params["domainid"],
                    "reason" => "Price mismatch. Got $premiumDomainsCost, but expected $price."
                ]);
                return [
                    "error" => "Price mismatch. Got $premiumDomainsCost, but expected $price."
                ];
            }
        }
    }
    //#####################################################################

    // prepare for .uk push
    if (preg_match("/\.uk$/i", $domainapi)) {
        $command["action"] = "request";
    }

    // add additional domain fields to the API command
    // load additional domain fields from different type (register)
    // hint: e.g. X-.+-REGISTRATION-TAC not allowed for transfer, but forwarded by WHMCS
    // e.g. 503 Invalid Parameter: X-NU-ACCEPT-REGISTRATION-TAC
    $trflds = new AF($params["TestMode"] === "on");
    $trflds->setDomainType("transfer")
        ->setDomain($domain)
        ->setFieldValuesFromParamsType($params, "register")
        ->addToCommand($command);

    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "domainid" => $params["domainid"],
            "reason" => $r["DESCRIPTION"]
        ]);
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    // add todo item: manual renewal after transfer
    if ($command["PERIOD"] === "0Y") {
        addToDoItem("Free Domain Transfer initiated", (
            "Domain: " . $domain . ". The Domain Transfer can't technically be initiated using WHMCS' " . (int)$params["regperiod"] . "Y " .
            "term, but allows for transferring for free. WHMCS is not perfectly compatible to this as it doesn't support this kind of transfer. " .
            "WHMCS always expects a renewal to be included in a domain transfer which is for some TLDs not supported. Please trigger a renewal " .
            "manually after successful completion of this transfer therefore."
        ));
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);

    return [
        "success" => true
    ];
}

/**
 * Renew (or restore) a Domain Name
 *
 * @param array $params common module parameters
 *
 * @return array
 */
function ispapi_RenewDomain($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    // --- Domain Restore
    if (isset($params["isInRedemptionGracePeriod"]) && $params["isInRedemptionGracePeriod"]) {
        $r = HXDomain::restore($params, $domain);
        cnic_track([
            "item" => $domain,
            "domainid" => $params["domainid"],
            "success" => isset($r["error"]),
            "reason" => isset($r["error"]) ? $r["error"] : ""
        ]);

        if (!isset($r["periodLeft"])) {
            return $r;
        }
        // continue with renewal below based on renewal period difference
        $params["regperiod"] = $r["periodLeft"];
    }

    $r = HXDomain::renew($params, $domain);
    if ($r["success"]) {
        cnic_track([
            "item" => $domain,
            "success" => true
        ]);
    } else {
        cnic_track([
            "item" => $domain,
            "domainid" => $params["domainid"],
            "success" => false,
            "reason" => $r["error"]
        ]);
    }

    return $r;
}

/**
 * Release a domain name
 * A domain name can be pushed to the registry or to another registrar.
 * This feature currently works for .DE domains (DENIC Transit), .UK domains (.UK detagging), .VE domains, .IS domains and .AT domains (.AT Billwithdraw).
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_ReleaseDomain($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXDomain::getRegistrarLock($params, $domain);
    if ($r === "locked") {
        $msg = "Please remove the Registrar Lock first.";

        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $msg
        ]);

        return [
            "error" => "Releasing failed. {$msg}"
        ];
    }

    $command = [
        "COMMAND" => "PushDomain",
        "DOMAIN" => $domain
    ];
    if (!empty($params["transfertag"])) {
        $command["TARGET"] = $params["transfertag"];
    }
    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);

        return [
            "error" => "Releasing failed. (" . $r["DESCRIPTION"] . ")"
        ];
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);

    return [
        "success" => "success"
    ];
}

/**
 * Delete a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_RequestDelete($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "DeleteDomain",
        "DOMAIN" => $domain
    ], $params);

    if ($r["CODE"] !== "200") {
        cnic_track([
            "item" => $domain,
            "success" => false,
            "reason" => $r["DESCRIPTION"]
        ]);

        return [
            "error" => "Deletion failed. (" . $r["DESCRIPTION"] . ")"
        ];
    }

    cnic_track([
        "item" => $domain,
        "success" => true
    ]);

    return [
        "success" => "success"
    ];
}

/**
 * Incoming Domain Transfer Sync.
 *
 * Check status of incoming domain transfers and notify end-user upon
 * completion. This function is called daily for incoming domains.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 *
 * @return array
 */
function ispapi_TransferSync($params)
{
    $domain = $params["sld"] . "." . $params["tld"];

    // check if the transfer is still pending
    $r = HXTransfer::getStatus($params, $domain);
    if ($r["success"] === true) {
        cnic_track(["custom" => "{$domain}: Domain Transfer is still pending (Existing Request)."]);
        return []; //still pending
    }

    // get date of last transfer request
    $r = HXTransfer::getRequestLog($params, $domain);
    if ($r["success"] === false || $r["data"]["COUNT"][0] === "0") {
        cnic_track(["custom" => "{$domain}: Domain Transfer is still pending (No Request Log found)."]);
        return []; //still pending
    }

    // existing transfer request
    // check for related failed entry
    $logdate = $r["data"]["LOGDATE"][0]; // 2019-11-15 12:25:05

    // check if the domain is already on account
    $r = HXDomain::getStatus($params, $domain);
    if ($r["success"]) {
        $values = HXDomain::getExpiryData($params, $domain, false, $r);
        $values["completed"] = true;
        cnic_track(["custom" => "{$domain}: Domain Transfer finished. expirydate: " . $values["expirydate"]]);
        return $values;
    }

    // in case neither domain nor transfer object are available in xirca
    // this is probably in progress atm or has failed

    // check for related failure entry
    $r = HXTransfer::getFailureLog($params, $domain, $logdate);
    if ($r["success"] && (int)$r["data"]["COUNT"][0] > 0) {
        $values = [
            "failed" => true,
            "reason" => "Transfer Failed"
        ];
        if (isset($r["data"]["LOGINDEX"])) {
            $r = HXTransfer::getLogDetails($params, $r["data"]["LOGINDEX"][0]);
            if ($r["success"] && isset($r["data"]["OPERATIONINFO"])) {
                $values["reason"] .= PHP_EOL . implode(PHP_EOL, $r["data"]["OPERATIONINFO"]);
            }
        }
        cnic_track(["custom" => "{$domain}: Domain Transfer failed.", "domainid" => $params["domainid"]]);
        return $values;
    }

    cnic_track(["custom" => "{$domain}: Domain Transfer is still pending."]);
    return []; // still pending
}

/**
 * Sync Domain Status & Expiration Date
 *
 * Domain syncing is intended to ensure domain status and expiry date
 * changes made directly at the domain registrar are synced to WHMCS.
 * It is called periodically for a domain.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @see https://developers.whmcs.com/domain-registrars/domain-syncing/
 * @see https://github.com/WHMCS/sample-registrar-module/blob/master/modules/registrars/registrarmodule/registrarmodule.php#L1613
 *
 * @return array
 */
function ispapi_Sync($params)
{
    $domain = $params["sld"] . "." . $params["tld"];

    // .SWISS, Premium Domain, Aftermarket, ... Applications Handling
    $appid = \WHMCS\Domain\Extra::whereDomainId($params["domainid"])
        ->whereName("ispapiApplicationID")
        ->value("value");
    if ($appid) {
        $rapp = HXApp::getStatus($params, $appid);
        if ($rapp["success"]) {
            if (!preg_match("/^(SUCCESSFUL|ACTIVE|FAILED)$/i", $rapp["data"]["STATUS"][0])) {
                cnic_track(["custom" => "{$domain}: Domain Order is pending. Application #{$appid}."]);
                return []; // don't change anything, still in progress
            }
            // delete app id as it either failed or succeeded
            \WHMCS\Domain\Extra::whereDomainId($params["domainid"])
                ->whereName("ispapiApplicationID")
                ->delete();
            // set failed items to status cancelled
            if ($rapp["data"]["STATUS"][0] === "FAILED") {
                cnic_track(["custom" => "{$domain}: Domain Sync finished. Application #{$appid} failed. Status updated to `Cancelled`"]);
                return [
                    "active" => true,
                    "cancelled" => true
                ];
            }
            cnic_track(["custom" => "{$domain}: Domain Order succeeded. Application #{$appid} - waiting for completion."]);
            return []; // pending cast from app to domain or pending order
        }

        if ($rapp["errorcode"] === "545") {
            // application no longer exists (probably auto-cleaned up)
            // delete app id as it succeeded obviously
            \WHMCS\Domain\Extra::whereDomainId($params["domainid"])
                ->whereName("ispapiApplicationID")
                ->delete();
        }
    }

    $r = HXDomain::getStatus($params, $domain);
    if (!$r["success"]) {
        // any other error, return error
        if (!(bool)preg_match("/^(545|531)$/", $r["errorcode"])) {
            cnic_track(["custom" => "{$domain}: Domain Sync failed. See Response of StatusDomain in Module Log."]);
            return $r;
        }
        if (
            $r["errorcode"] === "531"
            || HXDomain::isResigned($params, $domain)
            || HXTransfer::isTransferredAway($params, $domain)
        ) {
            $msg = "{$domain}: Domain Sync finished. Status updated to `Transferred Away`";
            if (preg_match("/\.dk$/i", $domain)) {
                $msg .= "Renewed at DKH?";
            }
            cnic_track(["custom" => $msg]);
            return [
                "transferredAway" => true
            ];
        }
        $values = HXDomain::getExpiryData($params, $domain, true);
        cnic_track(["custom" => "{$domain}: Domain Sync finished. Updated expirydate: " . $values["expirydate"]]);
        // don't try suspending as of return code 545 (n/a on api side)
        // plus don't return here an error (DELETEDDOMAIN eventually)
        return $values;
    }

    if (in_array("PENDINGCREATE", $r["data"]["STATUS"])) {
        return []; // no changes keep it pending in whmcs as well
    }

    //activate the whoistrustee if set to 1 in WHMCS
    //Trade doesn't support idprotection flag yet
    if ($params["idprotection"] && empty($r["data"]["X-ACCEPT-WHOISTRUSTEE-TAC"][0])) { // doesn't exist, "" or 0
        HXDomain::saveIdProtection($params, $domain, true);
    }

    // create the dnszone if not present in the System, when
    //   * dnsmanagement
    //   * emailforwarding
    // activated in WHMCS
    if ($params["dnsmanagement"] || $params["emailforwarding"]) {
        // dnszone is created as internal/hidden
        // make it visible
        $dnszone = $domain . ".";
        $rdns = HXDns::getStatus($params, $dnszone);
        if (!$rdns["success"] && ($rdns["errorcode"] === "545")) {
            Ispapi::call([
                "COMMAND" => "ModifyDomain",
                "DOMAIN" => $domain,
                "INTERNALDNS" => 1
            ], $params);
            HXDns::create($params, $dnszone);
        }
    }

    // Data Cleanup for Non-premium Aftermarket Domain (or downgraded premium)
    /*if ($params["premiumEnabled"]) {
        if (
            $r["data"]["CLASS"][0] === "DOMAIN"
            && !(bool)preg_match("/^PREMIUM_/i", $r["data"]["SUBCLASS"][0])
        ) {
            $is_premium = DB::table("tbldomains")
                ->where("id", "=", $params["domainid"])
                ->value("is_premium");
            if ($is_premium === 1) {
                DB::table("tbldomains")
                    ->where("id", "=", $params["domainid"])
                    ->update([
                        "is_premium" => 0
                    ]);
                \WHMCS\Domain\Extra::whereDomainId($params["domainid"])
                    ->where("name", "like", "registrar%")
                    ->delete();
            }
        }
    }*/

    //expirydate
    $values = HXDomain::getExpiryData($params, $domain, false, $r);
    cnic_track(["custom" => "{$domain}: Domain Sync finished. Updated expirydate: " . $values["expirydate"]]);
    if ($values["expired"] && $params["SUSPENDONEXPIRATION"] === "on") {
        HXDomain::suspend($params, true);
    }

    // .DK: set to cancelled in case of status PENDINGDELETE
    if (preg_match("/\.dk$/i", $domain) && in_array("PENDINGDELETE", $r["data"]["STATUS"])) {
        $values["active"] = true; // whmcs considers cancelled only with active
        $values["cancelled"] = true;
    }
    return $values;
}

/**
 * Return TLD & Pricing for sync (WHMCS 7.10)
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 *
 * @return \WHMCS\Results\ResultsList
 */
function ispapi_getTLDPricing($params)
{
    // fetch list of tlds offerable by reseller
    $tlds = WHMCS\Module\Registrar\Ispapi\Ispapi::getTLDs($params);
    if (isset($tlds["error"])) {
        return $tlds;
    }
    if (empty($tlds)) {
        return new \WHMCS\Results\ResultsList();
    }

    // fetch tld configurations for offerable tlds
    $domains = [];
    foreach (array_keys($tlds) as $tld) {
        $domains[] = "example" . $tld;
    }
    $zis = HXDomain::getZoneInformations($params, $domains);

    // fetch prices for offerable tlds
    $prices = WHMCS\Module\Registrar\Ispapi\Ispapi::getTLDPrices(array_flip($tlds), $zis);
    if (isset($prices["error"])) {
        return $prices;
    }

    $idprotections = [];
    //$debugPeriodIssues = [];

    //$tmp = "";
    $results = new \WHMCS\Results\ResultsList();
    foreach ($prices as $tld => $p) {
        $zi = $zis[$tld];
        if (is_null($zi)) {
            continue;
        }
        if ($zi->addons->idprotection) {
            $idprotections[] = $tld;
        }
        if (is_null($p["registration"])) {
            // there are of course TLDs in management which we no longer offer for registration in public
            // WHMCS doesn't offer the possibility to import registerPrice as null, therefore leaving out
            // 2022-05: no match
            // logActivity($tld . ": no reg price");
            continue;
        }
        if (empty($zi->registration->periods)) {
            throw new \Exception("Missing entry for $tld. Contact support, we will release a new version immediately.");
        }

        /*$p1 = $zi->registration->periods;
        $p2 = $zi->renewal->periods;
        $dbgRow = [
            "registration" => $p1,
            "renewal" => $p2,
            "unsupportedRenewalTerms" => array_values(array_diff($p1, $p2)), // all elements of p1 not in p2
            "missingRenewalTerms" => array_values(array_diff($p2, $p1)) // all elements of p2 not in p1
        ];
        $flag1 = empty($dbgRow["unsupportedRenewalTerms"]);
        $flag2 = empty($dbgRow["missingRenewalTerms"]);
        if (
            (!(
                !$flag1
                // 10y reg only -> whmcs keeps 10y for renewal otherwise not
                && count($dbgRow["registration"])>1
                && count($dbgRow["unsupportedRenewalTerms"]) === 1
                && in_array(10, $dbgRow["unsupportedRenewalTerms"])
            ) && !$flag1)
            || !$flag2
        ) {
            $debugPeriodIssues[$tld] = $dbgRow;
        }*/
        // WHMCS is auto-deactivating 10Y renewals
        // 2022-05: plenty of tlds having reg terms that are not supported for renewal

        // no extra fee, (= exclude renewal price)
        $redemptionFee = $p["redemption"];
        if (!is_null($redemptionFee) && $redemptionFee > 0) {
            $redemptionFee -= $p["renewal"];
        }

        // All the set methods can be chained and utilised together.
        $item = new \WHMCS\Domain\TopLevel\ImportItem();
        $item->setExtension($tld)
            ->setYears($zi->registration->periods) // 1st one is the minimum period also used for transfers
            ->setRegisterPrice($p["registration"])
            ->setRenewPrice($p["renewal"])
            ->setTransferPrice($p["transfer"])
            ->setGraceFeeDays($zi->renewal->graceDays)
            ->setGraceFeePrice($p["grace"])
            ->setRedemptionFeeDays($zi->redemption->days)
            ->setRedemptionFeePrice($redemptionFee)
            ->setCurrency($p["currency"])
            ->setEppRequired($zi->transfer->requiresAuthCode);
        $results[] = $item;

        /*if (!$zi->renewal->explicit) {
            $pp = -1 * $zi->renewal->paymentPeriod;
            $tmp .= "\$DomainRenewalMinimums[\"" . $tld . "\"] = \"" . $pp . "\";\n";
        }*/
    }

    // throw new Exception(json_encode($debugPeriodIssues, JSON_PRETTY_PRINT));

    // update id protection (missing feature in registrar tld sync)
    if (
        ($params["SYNCIDPROTECTION"] === "on") &&
        !empty($idprotections)
    ) {
        // disable id protection for all our TLDs
        DB::table("tbldomainpricing")
            ->where("autoreg", "ispapi")
            ->whereNotIn("extension", $idprotections)
            ->update(["idprotection" => 0]);
        // enable id protection for all our TLDs supporting it
        DB::table("tbldomainpricing")
            ->where("autoreg", "ispapi")
            ->whereIn("extension", $idprotections)
            ->update(["idprotection" => 1]);
    }

    // throw new Exception("<pre>" . $tmp . "</pre>");

    return $results;
}

/**
 * Return Zone Configuration / Feature data
 * @param array $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return object|null
 */
function ispapi_GetZoneFeatures($params)
{
    return HXDomain::getZoneInformation(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
}

/**
 * Return Additional Domain Fields per extension and order type
 *
 * @param array $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return array
 */
function ispapi_AdditionalDomainFields($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    // load and return our additional domain fields configuration
    AF::init($params["TestMode"] === "on");
    $fields = AF::getAdditionalDomainFields($params);
    // var_dump($fields);
    return $fields;
}

/**
 * Returns customer account details such as amount, currency, deposit etc.
 *
 * @return array<string, string>
 */
function ispapi_getAccountDetails()
{
    $r = Ispapi::call(["COMMAND" => "StatusAccount"]);
    $quota = Ispapi::call(["COMMAND" => "QueryServiceUsage", "USERDEPTH" => "SELF", "WIDE" => "1"]);

    if ((int)$r["CODE"] !== 200 && (int)$quota['CODE'] !== 200) {
        return [
            "success" => false
        ];
    }

    return [
        "success" => true,
        "amount" => $r["PROPERTY"]["AMOUNT"][0],
        "deposit" => $r["PROPERTY"]["DEPOSIT"][0],
        "currency" => $r["PROPERTY"]["CURRENCY"][0],
        "total_query_quota" => $quota["PROPERTY"]["SYSTEM_HARD"][0],
        "current_quota_usage" => $quota["PROPERTY"]["CURRENT"][0]
    ];
}

/**
 * Get Host Objects / GR per Domain
 * @param array $params registrar settings plus hook vars
 * @return array<string, string>
 */
function ispapi_getHostsForDomain($params)
{
    $r = HXDomain::getStatus($params, $params["domain"], true);
    $hosts = [];
    $tmp = empty($r["data"]["HOST"]) ? [] : $r["data"]["HOST"];
    foreach ($tmp as $host) {
        list($hname, $ip) = explode(" ", $host);
        $hosts[$hname] = [
            "ips" => [$ip],
            "sub" => str_ireplace("." . $params["domain"], "", $hname)
        ];
    }
    return $hosts;
}

/**
 * Return Result of Transfer Precheck
 *
 * @param array $params registrar settings plus hook data
 * @return array
 */
function ispapi_precheckTransfer($params)
{
    return HXTransfer::precheck($params, $params["domain"]);
}

/**
 * Whois lookup function
 *
 * @param string $domain
 * @return array
 */
function ispapi_whoislookup($params, $domain)
{
    //use API
    return Ispapi::call([
        "COMMAND" => "QueryDomainWhoisInfo",
        "DOMAIN" => $domain
    ]);
}

/**
 * Get Aftermarket Domains
 *
 * @param array $params
 * @return \WHMCS\Domains\DomainLookup\ResultsList An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 */
function ispapi_GetAftermarketDomains($params)
{
    $suggestionsLimit = $params["limit"] ?? 100;

    // build search label
    if ($params["isIdnDomain"]) {
        $label = empty($params["punyCodeSearchTerm"]) ? $params["searchTerm"] : $params["punyCodeSearchTerm"];
    } else {
        $label = $params["searchTerm"];
    }
    $label = strtolower($label ?? $params["domain"] ?? "");

    $command = [
        "COMMAND" => "QueryDomainSuggestionList",
        "KEYWORD" => $label,
        "FIRST" => 0,
        "LIMIT" => $suggestionsLimit
    ];

    $results = new \WHMCS\Domains\DomainLookup\ResultsList();
    $errorMissingCurrency = false;
    // get domain name suggestions
    $aftermarketDomains = Ispapi::call($command, $params);
    foreach ($aftermarketDomains["PROPERTY"]["DOMAIN"] as $idx => $domain) {
        list($sld, $tld) = explode(".", $domain, 2);
        if (empty($sld) || empty($tld)) {
            continue;
        }
        $sr = new SR($sld, $tld);
        $sr->setStatus($sr::STATUS_NOT_REGISTERED);
        $domainCurrency = $aftermarketDomains["PROPERTY"]["CURRENCY"][$idx];
        $currency = \WHMCS\Billing\Currency::where("code", $domainCurrency)->first();
        $sr->isAftermarket = true;
        if (!$currency) {
            $sr->errorMissingCurrency = $errorMissingCurrency = $errorMissingCurrency;
            $sr->setStatus($sr::STATUS_UNKNOWN);
            $sr->availabilityReason = "Missing required currency configuration for ${$domainCurrency}";
            $results->append($sr);
            continue;
        }
        $sr->setPremiumDomain(true);

        $domainPricingObject = new \WHMCS\Domains\DomainPricing((new \WHMCS\Domains\Domain($domain)));
        $shortestPeriodTransfer = $domainPricingObject->shortestPeriod()["transfer"] ?? false;
        if ($shortestPeriodTransfer) {
            $transferPrice = (float)convertCurrency($shortestPeriodTransfer->getValue(), $shortestPeriodTransfer->getCurrency()["id"], $currency->id);
        } else {
            for ($i = 1; $i <= 10 && $domainPricingObject->hasPricing("transfer", $i); $i++) {
                $periodTransfer = $domainPricingObject->forPeriod($i)["transfer"] ?? false;
                $transferPrice = !$periodTransfer ?: (float)convertCurrency($periodTransfer->getValue(), $periodTransfer->getCurrency()["id"], $currency->id);
                break;
            }
        }

        $sr->setPremiumCostPricing(["register" => $aftermarketDomains["PROPERTY"]["PRICE"][$idx] + ($transferPrice ?? 0.00), "CurrencyCode" => $domainCurrency]);
        $results->append($sr);
    }
    if ($errorMissingCurrency !== false) {
        cnic_track([
            "success" => false,
            "reason" => "Missing required currency configuration for ${errorMissingCurrency}"
        ]);
    }
    return $results;
}

function ispapi_GetAftermarketDomainPrice($domainName)
{
    $command = [
        "COMMAND" => "QueryDomainSuggestionList",
        "KEYWORD" => $domainName,
        "FIRST" => 0,
        "LIMIT" => 1
    ];

    $prices = [];
    // get domain name suggestions
    $aftermarketDomains = Ispapi::call($command, $params);
    foreach ($aftermarketDomains["PROPERTY"]["DOMAIN"] as $idx => $domain) {
        list($sld, $tld) = explode(".", $domain, 2);
        if ($domain !== $domainName || empty($sld) || empty($tld)) {
            continue;
        }
        $domainCurrency = $aftermarketDomains["PROPERTY"]["CURRENCY"][$idx];
        $currency = \WHMCS\Billing\Currency::where("code", $domainCurrency)->first();
        if (!$currency) {
            return [];
        }

        $domainPricingObject = new \WHMCS\Domains\DomainPricing((new \WHMCS\Domains\Domain($domain)));
        $shortestPeriodTransfer = $domainPricingObject->shortestPeriod()["transfer"] ?? false;

        if ($shortestPeriodTransfer) {
            $transferPrice = (float)convertCurrency($shortestPeriodTransfer->getValue(), $shortestPeriodTransfer->getCurrency()["id"], $currency->id);
        } else {
            for ($i = 1; $i <= 10 && $domainPricingObject->hasPricing("transfer", $i); $i++) {
                $periodTransfer = $domainPricingObject->forPeriod($i)["transfer"] ?? false;
                $transferPrice = !$periodTransfer ?: (float)convertCurrency($periodTransfer->getValue(), $periodTransfer->getCurrency()["id"], $currency->id);
                break;
            }
        }

        // Add domain transfer cost
        $prices["register"] = $aftermarketDomains["PROPERTY"]["PRICE"][$idx] + ($transferPrice ?? 0.00);
        $prices["CurrencyCode"] = $currency->code;
        $prices["CurrencyID"] = $currency->id;
    }
    return $prices;
}
