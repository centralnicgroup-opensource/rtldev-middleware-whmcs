<?php

/**
 * ISPAPI Registrar Module
 *
 * @author HEXONET GmbH <support@hexonet.net>
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as DB;
use WHMCS\Module\Registrar\Ispapi\Ispapi as Ispapi;
use WHMCS\Module\Registrar\Ispapi\Helper as Helper;
use WHMCS\Module\Registrar\Ispapi\WebApps as WebApps;
use WHMCS\Module\Registrar\Ispapi\DomainTransfer as HXTransfer;
use WHMCS\Module\Registrar\Ispapi\Dns as HXDns;
use WHMCS\Module\Registrar\Ispapi\Domain as HXDomain;
use WHMCS\Module\Registrar\Ispapi\DomainTrade as HXTrade;
use WHMCS\Module\Registrar\Ispapi\DomainApplication as HXApp;
use WHMCS\Module\Registrar\Ispapi\Contact as HXContact;
use WHMCS\Module\Registrar\Ispapi\User as HXUser;
use WHMCS\Domains\DomainLookup\SearchResult as SR;
use WHMCS\Module\Registrar\Ispapi\AdditionalFields as AF;
use WHMCS\Module\Registrar\Ispapi\Lang as L;
use WHMCS\Config\Setting as Setting;

require_once implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]);

/**
 * Get Transferlock settings of a domain name
 * Deprecated after CORE-17038
 * @param array $params common module parameters
 * @return array $values - an array with transferlock setting information
 */
function ispapi_GetRegistrarLock($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    // NOTE: returning an error still shows up as "unlocked"
    // Removing the menu entry by hook therefore ftw.
    // asked to get this also patched via CORE-17038
    return HXDomain::getRegistrarLock(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
}

/**
 * Return Nameservers of a domain name
 * Deprecated after CORE-17038
 * @param array $params common module parameters
 * @return array $values an array with the Nameservers
 */
function ispapi_GetNameservers($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $r = HXDomain::getStatus(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
    if ($r["success"]) {
        return Ispapi::castNameservers(
            $r["data"]["NAMESERVER"]
        );
    }
    return $r;
}

/**
 * Check the availability of domains using HEXONET's fast API
 * @param array $params common module parameters *
 * @return \WHMCS\Domains\DomainLookup\ResultsList An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 * @see https://confluence.hexonet.net/pages/viewpage.action?pageId=8589377 for diagram
 * @throws \Exception in case of an error
 */
function ispapi_CheckAvailability($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $maxGroupSize = 25;
    $premiumEnabled = (bool) $params["premiumEnabled"];

    $label = strtolower(
        ($params["isIdnDomain"] && !empty($params["punyCodeSearchTerm"])) ?
            $params["punyCodeSearchTerm"] :
            $params["searchTerm"]
    );

    $command = [
        "COMMAND" => "CheckDomains",
        "PREMIUMCHANNELS" => $premiumEnabled ? "*" : ""
    ];
    // build domainlist to check
    if (!empty($params["suggestions"])) {
        // for domain name suggestion mode (we get already a list of domains)
        // remove duplicates and empty ones
        $tocheck = $params["suggestions"];
    } else {
        // for common availability checks (we get just a search label and list of tlds)
        // remove duplicates and empty ones
        $tocheck = array_values(array_unique(array_filter($params["tldsToInclude"])));
        $tocheck = array_map(function ($tld) use ($label) {
            return $label  . "." . ltrim($tld, ".");
        }, $tocheck);
    }

    // build the result list for WHMCS
    // chunk the check list, only ~250 are allowed at once
    $results = new \WHMCS\Domains\DomainLookup\ResultsList();
    foreach (array_chunk($tocheck, $maxGroupSize) as $command["DOMAIN"]) {
        $r = Ispapi::call($command, $params);
        foreach ($command["DOMAIN"] as $idx => $domain) {
            list($sld, $tld) = explode(".", $domain, 2);

            $sr = new SR($sld, $tld);
            $sr->setStatus($sr::STATUS_REGISTERED);

            $row = [
                "DOMAIN" => $domain,
                "PREMIUMCHANNEL" => "",
                "REASON" => "",
                "CLASS" => "",
                "CURRENCY" => "",
                "PRICE" => "",
                "DOMAINCHECK" => "421 Temporary issue",
            ];
            foreach ($row as $key => &$val) {
                if (
                    isset($r["PROPERTY"][$key][$idx])
                    && strlen($r["PROPERTY"][$key][$idx])
                ) {
                    $val = $r["PROPERTY"][$key][$idx];
                }
            }
            list($row["CODE"], $row["CHECK"]) = explode(" ", $row["DOMAINCHECK"], 2);
            $params["isAftermarketCase"] = false;

            if ($row["CODE"] === "421") {
                //TMP. ERROR OCCURED
                $sr->setStatus($sr::STATUS_UNKNOWN);
            } elseif ($row["CODE"] === "549") {
                // TLD not supported at HEXONET or check failed
                // WHMCS does fallback to whois lookup
                $sr->setStatus($sr::STATUS_TLD_NOT_SUPPORTED);
            } elseif ($row["CODE"] === "210") {
                //DOMAIN AVAILABLE
                $sr->setStatus($sr::STATUS_NOT_REGISTERED);
            } elseif ($row["CODE"] === "211") {
                // $sr::STATUS_REGISTERED already set
                // PREMIUM DOMAINS
                if (
                    strlen($row["CLASS"])
                    && preg_match("/^PREMIUM_/i", $row["CLASS"])
                ) {
                    // n/a or available
                    $sr->setPremiumDomain(true);
                }
                if (
                    // DOMAIN BLOCKS
                    stripos($row["REASON"], "block")
                    // RESERVER DOMAIN NAMES
                    || stripos($row["REASON"], "reserved")
                    // NXD DOMAINS
                    || preg_match("/^collision domain name available \{/i", $row["CHECK"])
                ) {
                    $sr->setStatus($sr::STATUS_RESERVED);
                } elseif (
                    strlen($row["PREMIUMCHANNEL"])
                    && $sr->isPremiumDomain()
                    && preg_match("/^premium domain name available/i", $row["CHECK"])
                ) {
                    // CASE: PREMIUM / PREMIUM AFTERMARKET
                    $params["AvailabilityCheckResult"] = $r;
                    $params["AvailabilityCheckResultIndex"] = $idx;
                    // available premium domain
                    try {
                        $prices = ispapi_GetPremiumPrice($params);
                        $row["prices"] = var_export($prices, true);
                        // logActivity($domain . ": " . json_encode($prices));
                        $sr->setPremiumCostPricing($prices);
                        // TODO why prices empty?
                        if (isset($prices["register"])) {
                            //PREMIUM DOMAIN AVAILABLE
                            $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                        }
                    } catch (\Exception $e) {
                        $sr->setPremiumCostPricing([]);
                        $sr->setStatus($sr::STATUS_RESERVED);
                    }
                } elseif (
                    !strlen($row["PREMIUMCHANNEL"])
                    && $sr->isPremiumDomain()
                    && preg_match("/^premium domain name not available/i", $row["CHECK"])
                ) {
                    // CASE: PREMIUM / PREMIUM AFTERMARKET - taken ones
                    $params["AvailabilityCheckResult"] = $r;
                    $params["AvailabilityCheckResultIndex"] = $idx;
                    // available premium domain
                    try {
                        $prices = ispapi_GetPremiumPrice($params);
                        $row["prices"] = var_export($prices, true);
                        // logActivity($domain . ": " . json_encode($prices));
                        $sr->setPremiumCostPricing($prices);
                        // TODO why prices empty?
                    } catch (\Exception $e) {
                        $sr->setPremiumCostPricing([]);
                        $sr->setStatus($sr::STATUS_RESERVED);
                    }
                }
                if (
                    (!isset($_REQUEST["a"])
                        || $_REQUEST["a"] !== "addDomainTransfer"
                    )
                    && isset($params["AFTERMARKETDOMAINS"])
                    && $params["AFTERMARKETDOMAINS"] === "on"
                    && !strlen($row["CLASS"])
                    && preg_match("/^AFTERNIC|SEDO$/i", $row["PREMIUMCHANNEL"])
                    && preg_match("/not available$/i", $row["CHECK"])
                ) {
                    // logActivity(json_encode($_REQUEST));
                    $sr->setPremiumDomain(true);
                    // CASE: PREMIUM / PREMIUM AFTERMARKET - taken ones
                    $params["AvailabilityCheckResult"] = $r;
                    $params["AvailabilityCheckResultIndex"] = $idx;
                    $params["isAftermarketCase"] = true;
                    // available premium domain
                    try {
                        $prices = ispapi_GetPremiumPrice($params);
                        $row["prices"] = var_export($prices, true);
                        // logActivity($domain . ": " . json_encode($prices));
                        $sr->setPremiumCostPricing($prices);
                        if (isset($prices["register"])) {
                            //PREMIUM DOMAIN AVAILABLE
                            $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                        }
                    } catch (\Exception $e) {
                        $sr->setPremiumCostPricing([]);
                        $sr->setStatus($sr::STATUS_RESERVED);
                    }
                }
            }

            //ONLY RETURNS AVAILABLE DOMAINS FOR DOMAIN NAME SUGGESTIONS MODE
            //AND ALL RESULTS OTHERWISE
            if (!isset($params["suggestions"]) || $sr->getStatus() === $sr::STATUS_NOT_REGISTERED) {
                $results->append($sr);
            }
        }
    }
    return $results;
}

/**
 * Provide domain suggestions based on the domain lookup term provided
 *
 * @param array $params common module parameters
 *
 * @return \WHMCS\Domains\DomainLookup\ResultsList An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 */
function ispapi_GetDomainSuggestions($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    // go through configuration settings
    if (empty($params["suggestionSettings"]["suggestions"])) {
        return new \WHMCS\Domains\DomainLookup\ResultsList();
    }
    $suppressWeigthed = $params["suggestionSettings"]["suggestionsnoweighted"];
    $suggestionsLimit = 100;
    if (!empty($params["suggestionSettings"]["suggstionsamount"])) {
        $suggestionsLimit = $params["suggestionSettings"]["suggstionsamount"];
    }

    // build search label
    if ($params["isIdnDomain"]) {
        $label = empty($params["punyCodeSearchTerm"]) ? $params["searchTerm"] : $params["punyCodeSearchTerm"];
    } else {
        $label = $params["searchTerm"];
    }
    $label = strtolower($label);

    // build zone list parameter
    $zones = [];
    foreach ($params["tldsToInclude"] as $tld) {
        // IGNORE 3RD LEVEL TLDS - NOT FULLY SUPPORTED BY QueryDomainSuggestionList
        // Suppress .com, .net by configuration
        if (!preg_match("/\./", $tld) && (!$suppressWeigthed || !preg_match("/^(com|net)$/", $tld))) {
            $zones[] = $tld;
        }
    }

    // request domain name suggestions from engine
    $first = 0;
    $command = [
        "COMMAND" => "QueryDomainSuggestionList",
        "KEYWORD" => $label,
        "ZONE" => $zones,
        "SOURCE" => "ISPAPI-SUGGESTIONS",
        "LIMIT" => $suggestionsLimit
    ];
    $results = new \WHMCS\Domains\DomainLookup\ResultsList();
    do {
        // get domain name suggestions
        $command["FIRST"] = $first;
        $r = Ispapi::call($command, $params);
        if ($r["CODE"] !== "200" || empty($r["PROPERTY"]["DOMAIN"])) {
            break; //leave while and return $results
        }
        // check the availability, as also taken/reserved/blocked domains could be returned
        $params["suggestions"] = array_values(array_unique(array_filter($r["PROPERTY"]["DOMAIN"])));
        $tmp = ispapi_CheckAvailability($params);
        // add entries to the list of entries to return
        $resultsCount = count($results);
        $resultsFilled = $resultsCount >= $suggestionsLimit;
        foreach ($tmp as $sr) {
            if ($resultsFilled) {
                break 2; //leave foreach and while
            }
            $results->append($sr);
            $resultsCount++;
            $resultsFilled = $resultsCount >= $suggestionsLimit;
        }
        $first += $suggestionsLimit;
    } while (!$resultsFilled && ($r["PROPERTY"]["TOTAL"][0] > $first));
    return $results;
}

/**
 * Define the settings relating to domain suggestions
 *
 * @param array an array with different settings
 */
function ispapi_DomainSuggestionOptions($params)
{
    $meta = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . "whmcs.json"), true);

    $version = implode(".", array_slice(explode(".", $params["whmcsVersion"]), 0, 2));
    if (version_compare($version, "7.6") === -1) {
        $marginleft = "60px";
    } else {
        $marginleft = "220px";
    }

    /*$r = Ispapi::call([
        "COMMAND" => "QueryDomainSuggestionList",
        "SOURCE" => "ISPAPI-CATEGORIES"
    ], $params);
    $categories = ["" => "Not set (default)"];
    if ($r["CODE"] !== "200") {
        $r["PROPERTY"]["CATEGORY"] = [ // 06-08-2020
            "professions", "geographic", "education", "entertainment", "business", "adult", "travel", "technology", "realEstate", "community",
            "identity", "arts", "shopping", "other", "financial", "food", "fitness", "lifestyle", "culture", "popular", "health", "idns"
        ];
    }
    sort($r["PROPERTY"]["CATEGORY"]);
    foreach ($r["PROPERTY"]["CATEGORY"] as $category) {
        $categories[$category] = $category;
    }

    $languages = ["" => "Not set (default)"];*/
    $url = $meta["_priv"]["UrlSignup"];
    return [
        "information" => [
            "FriendlyName" => "<b>Not signed up yet?</b>",
            "Description" => "Signup here for free: <a target=\"_blank\" href=\"{$url}\">{$url}</a><br/><br/>
			<b>We provide the following features:</b>
			<ul style=\"text-align:left;margin-left:" . $marginleft . ";margin-top:5px;\">
			<li>High Performance availability checks using our incredible fast API</li>
			<li>Suggestion Engine</li>
			<li>Premium Domains support</li>
			</ul>"
        ],
        "suggestions" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Suggestion Engine based on search term:</b>",
            "Type" => "yesno",
            "Description" => AdminLang::trans("global.ticktoenable") . " (" . AdminLang::trans("global.recommended") . ")"
        ],
        "suggstionsamount" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">" . AdminLang::trans("general.maxsuggestions") . "</b>",
            "Type" => "dropdown",
            "Options" => [
                10 => "10",
                25 => "25",
                50 => "50",
                75 => "75",
                100 => "100 (" . AdminLang::trans("global.recommended") . ")",
                150 => "150",
                200 => "200"
            ],
            "Default" => "100",
            "Description" => ""
        ],
        /*"suggestionscategories" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Category-based suggestions:</b>",
            "Type" => "dropdown",
            "Multiple" => true,
            "Size" => 5,
            "Options" => $categories,
            "Default" => "",
            "Description" => "<br/>Get Suggestions related to the selected categories."
        ],
        "suggestionslangs" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Language-dependent Suggestions:</b>",
            "Type" => "dropdown",
            "Multiple" => true,
            "Size" => 3,
            "Options" => $languages,
            "Default" => "",
            "Description" => "<br/>(Better localized Suggestions)"
        ],
        "suggestionsip" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Use IP Address for region-dependent Suggestions:</b>",
            "Type" => "yesno",
            "Default" => "",
            "Description" => AdminLang::trans("global.ticktoenable") . " (Better localized Suggestions)"
        ],*/
        "suggestionsnoweighted" => [
            "FriendlyName" => "<b style=\"color:#FF6600;\">Suppress .com and .net:</b>",
            "Type" => "yesno",
            "Default" => "",
            "Description" => AdminLang::trans("global.ticktoenable") . "<br/>.com and .net have by default a very high weight."
        ]
    ];
}
/**
 * Get Premium Price for given domain,
 * $params -> [
 *      "domain" => ...,
 *      "sld" => ...
 *      "tld" => ...
 *      "type" => ...
 * ];
 * @throws Exception in case currency configuration is missing
 */
function ispapi_GetPremiumPrice($params)
{
    if (isset($params["AvailabilityCheckResult"])) {
        $index = $params["AvailabilityCheckResultIndex"];
        $r = $params["AvailabilityCheckResult"];
        unset(
            $params["AvailabilityCheckResultIndex"],
            $params["AvailabilityCheckResult"]
        );
    } else {
        $index = 0;
        $r = Ispapi::call([
            "COMMAND" => "CheckDomains",
            "DOMAIN0" => $params["domain"],
            "PREMIUMCHANNELS" => "*"
        ], $params);
    }
    // no data available, api error
    if ($r["CODE"] !== "200") {
        return [];
    }
    $r = $r["PROPERTY"];
    if (
        // aftermarket
        // any case not being AFTERMARKET in context of our domain search
        // HINT: WHMCS is looking up availability for transfers
        // aftermarket has to be returned as taken
        (empty($r["CLASS"][$index]) ||
            !(bool)preg_match("/^PREMIUM_/", $r["CLASS"][$index])
        )
        && (!isset($params["isAftermarketCase"])
            || !$params["isAftermarketCase"]
        )
    ) {
        return [];
    }

    //GET THE PRICES
    if (isset($r["CURRENCY"][$index]) && isset($r["PRICE"][$index]) && is_numeric($r["PRICE"][$index])) {
        $prices = [
            "CurrencyCode" => $r["CURRENCY"][$index]
        ];
        $currency = \WHMCS\Billing\Currency::where("code", $prices["CurrencyCode"])->first();
        if (!$currency) {
            throw new Exception("Missing currency configuration for: " . $prices["CurrencyCode"]);
        }
        // probably registration case (domain name available), API provides PRICE/CURRENCY Properties
        // get registration price (as of variable fee premiums calculation is more complex)
        $renewprice = ispapi_getPremiumRenewPrice($params, $r["CLASS"][$index], $currency->id);
        if ($renewprice !== false) {
            $prices["renew"] = $renewprice;
        }
        $registerprice = ispapi_getPremiumRegisterPrice($params, $r["CLASS"][$index], $r["PRICE"][$index], $currency->id);
        if ($registerprice !== false) {
            $prices["register"] = $registerprice;
        }
        return $prices;
    }

    $renewprice = ispapi_getPremiumRenewPrice($params, $r["CLASS"][$index], $currency->id);
    // probably transfer case (domain name n/a), API doesn't provide PRICE/CURRENCY Properties
    if ($renewprice === false) {
        return [];
    }
    $prices = [
        "CurrencyCode" =>  ispapi_getPremiumCurrency($params, $r["CLASS"][$index])
    ];
    if ($prices["CurrencyCode"] === false) {
        $racc = Ispapi::call([ // worst case fallback
            "COMMAND" => "StatusAccount"
        ], $params);
        if ($racc["CODE"] !== "200" || empty($racc["PROPERTY"]["CURRENCY"][0])) {
            return [];
        }
        $prices["CurrencyCode"] = $racc["PROPERTY"]["CURRENCY"][0];
    }

    $currency = \WHMCS\Billing\Currency::where("code", $prices["CurrencyCode"])->first();
    if (!$currency) {
        throw new Exception("Missing currency configuration for: " . $prices["CurrencyCode"]);
    }

    $prices["renew"] = $renewprice;
    $transferprice = ispapi_getPremiumTransferPrice($params, $r["CLASS"][$index], $currency->id);
    if ($transferprice !== false) {
        $prices["transfer"] = $transferprice;
    }
    return $prices;
}

/**
 * Get the API currency for the given premium domain class
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @return string/bool the premium currency, false if not found
 */
function ispapi_getPremiumCurrency($params, $class)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        return HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_CURRENCY");
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    return preg_replace("/(^.+_|:.+$)/", "", $class);
}

/**
 * Calculate the domain premium registration price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param string $registerprice the price we have from CheckDoamins
 * @param integer $cur_id the currency id of the currency we have form CheckDomains
 *
 * @return integer/bool the renew price, false if not found
 */
function ispapi_getPremiumRegisterPrice($params, $class, $registerprice, $cur_id)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        return $registerprice; // looking up relations not necessary API provided the prices
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    $p = preg_split("/\:/", $class);
    $cl = preg_split("/_/", $p[0]);
    $premiummarkupfix_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_SETUP_MARKUP_FIX");
    $premiummarkupvar_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_SETUP_MARKUP_VAR");
    if ($premiummarkupfix_value && $premiummarkupvar_value) {
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_CURRENCY");
        if ($currency !== false) {
            $currency = \WHMCS\Billing\Currency::where("code", $prices["CurrencyCode"])->first();
            if (!$currency) {
                return false;
            }
            if ($currency->id != $cur_id) {
                $premiummarkupvar_value = convertCurrency($premiummarkupvar_value, $currency->id, $cur_id);
                $premiummarkupfix_value = convertCurrency($premiummarkupfix_value, $currency->id, $cur_id);
            }
        }
        return $p[2] * (1 + $premiummarkupvar_value / 100) + $premiummarkupfix_value;
    }
    return false;
}

/**
 * Calculate the domain registration price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param integer $cur_id the currency of the domain name
 *
 * @return integer/bool the premium transfer price, false if not found
 */
function ispapi_getPremiumTransferPrice($params, $class, $cur_id)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_CURRENCY");
        if ($currency === false) {
            return false;
        }
        $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
        if (!$currency) {
            return false;
        }
        $transfer = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_TRANSFER");
        // premium period is in general 1Y, no need to reflect period in calculations
        if ($transfer !== false && ($currency->id != $cur_id)) {
            return convertCurrency($transfer, $currency->id, $cur_id);
        }
        return  $transfer;
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    $p = preg_split("/\:/", $class);
    $cl = preg_split("/_/", $p[0]);
    $premiummarkupfix_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_TRANSFER_MARKUP_FIX");
    $premiummarkupvar_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_TRANSFER_MARKUP_VAR");
    if ($premiummarkupfix_value && $premiummarkupvar_value) {
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_CURRENCY");
        if ($currency !== false) {
            $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
            if (!$currency) {
                return false;
            }
            if ($currency->id != $cur_id) {
                $premiummarkupvar_value = convertCurrency($premiummarkupvar_value, $currency->id, $cur_id);
                $premiummarkupfix_value = convertCurrency($premiummarkupfix_value, $currency->id, $cur_id);
            }
        }
        return $p[1] * (1 + $premiummarkupvar_value / 100) + $premiummarkupfix_value;
    }
    return false;
}

/**
 * Calculate the premium domain renew price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param integer $cur_id the currency of the domain name
 *
 * @return integer/bool the premium renew price, false if not found
 */
function ispapi_getPremiumRenewPrice($params, $class, $cur_id)
{
    if (!preg_match("/\:/", $class)) {
        //REGISTRY PREMIUM DOMAIN (e.g. PREMIUM_DATE_F)
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_CURRENCY");
        if ($currency === false) {
            return false;
        }
        $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
        if (!$currency) {
            return false;
        }
        $renewprice = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $class . "_ANNUAL");
        if ($renewprice && ($currency->id != $cur_id)) {
            $renewprice = convertCurrency($renewprice, $cur_id2->id, $cur_id);
        }
        return $renewprice;
    }
    //VARIABLE FEE PREMIUM DOMAINS (e.g. PREMIUM_TOP_CNY:24:2976)
    $p = preg_split("/\:/", $class);
    $cl = preg_split("/_/", $p[0]);
    $premiummarkupfix_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_ANNUAL_MARKUP_FIX");
    $premiummarkupvar_value = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_ANNUAL_MARKUP_VAR");
    if ($premiummarkupfix_value && $premiummarkupvar_value) {
        $currency = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $cl[0] . "_" . $cl[1] . "_*_CURRENCY");
        if ($currency !== false) {
            $currency = \WHMCS\Billing\Currency::where("code", $currency)->first();
            if (!$currency) {
                return false;
            }
            if ($currency->id != $cur_id) {
                $premiummarkupvar_value = convertCurrency($premiummarkupvar_value, $currency->id, $cur_id);
                $premiummarkupfix_value = convertCurrency($premiummarkupfix_value, $currency->id, $cur_id);
            }
        }
        return $p[1] * (1 + $premiummarkupvar_value / 100) + $premiummarkupfix_value;
    }
    return false;
}

/**
 * Calculate the domain renew price
 *
 * @param array $params common module parameters
 * @param string $class the class of the domain name
 * @param integer $cur_id the currency of the domain name
 * @param string $tld the tld of the domain name
 *
 * @return integer/bool the renew price, false if not found
 */
function ispapi_getRenewPrice($params, $class, $cur_id, $tld)
{
    if (empty($class)) {
        //NO PREMIUM RENEW, RETURN THE PRICE SET IN WHMCS
        $pdo = \WHMCS\Database\Capsule::connection()->getPdo();
        $stmt = $pdo->prepare("select * from tbldomainpricing tbldp, tblpricing tblp where tbldp.extension = ? and tbldp.id = tblp.relid and tblp.type = 'domainrenew' and tblp.currency=?");
        $stmt->execute(["." . $tld, $cur_id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!empty($data) && !in_array($data["msetupfee"], ["-1", "0"])) {
            return $data["msetupfee"];
        }
        return false;
        //API COMMAND GetTLDPricing IS TRIGERING JS ERROR AND IS UNUSABLE.
        // $gettldpricing_res = localAPI("GetTLDPricing", ["currencyid" => $cur_id]);
        // $renewprice = $gettldpricing_res["pricing"][$tld]["renew"][1];
        //return !empty($renewprice) ? $renewprice : false;
    }

    return ispapi_getPremiumRenewPrice($params, $class, $cur_id);
}

/**
 * Undocumented function to validate user inputs in getConfigArray's form - only invoked if configuration settings are submitted
 * commenting out as things are cached, not reliable to use
 * @link https://www.whmcs.com/members/viewticket.php?tid=ESD-183344&c=wjZ1LjOs #ESD-183344
 * @param array $params common module parameters
 * @throws Exception if estabilishing the API connection failed
 */
/*function ispapi_config_validate($params)
{
    $authOk = Ispapi::checkAuth($params);
    if ($authOk===false) {
        $parts = parse_url(Setting::getValue("SystemURL"));
        $ip = gethostbyname($parts["host"]);
        $error = Ispapi::getAuthError();
        $url = "https://github.com/hexonet/whmcs-ispapi-registrar/wiki/FAQs#39-login-failed-in-registrar-module";
        throw new \Exception(
            <<<HTML
            <h2>Connection failed. <small>({$error})</small></h2>
            <p>Read <a href="{$url}" target="_blank" style="text-decoration:underline;">here</a> for possible reasons. <b>Your Server IP Address</b>: {$ip}</p>
HTML
        );
    }
}*/

/**
 * Return the configuration array of the module (Setup > Products / Services > Domain Registrars > ISPAPI > Configure)
 *
 * @param array $params common module parameters
 *
 * @return array $configarray configuration array of the module
 */
function ispapi_getConfigArray($params)
{
    $meta = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . "whmcs.json"), true);

    $migrate = !empty($meta["_priv"]["bttn_migrate"]);
    if ($migrate) {
        $newModule = $meta["name"];
        $oldModule = "hexonet";
        $oldConfig = \getregistrarconfigoptions($oldModule);

        if (@$_GET["migrate"]) {
            $migrate = false;
            // migrate registrar module settings
            if (!$params["Username"]) {
                $isLowerWHMCS8 = version_compare($params["whmcsVersion"], "8.0.0") === -1;
                foreach ($oldConfig as $key => $val) {
                    $tmp = $val;
                    if (!$isLowerWHMCS8) {
                        $r = localAPI("EncryptPassword", [
                            "password2" => $val
                        ]);
                        if ($r["result"] === "success") {
                            $tmp = $r["password"];
                        }
                    }

                    DB::table("tblregistrars")
                        ->where("registrar", $newModule)
                        ->where("setting", $key)
                        ->update([
                            "value" => $tmp
                        ]);
                }
                // reassign domains
                DB::table("tbldomains")->where("registrar", $oldModule)->update(["registrar" => $newModule]);
                // reassign pricing settings
                DB::table("tbldomainpricing")->where("autoreg", $oldModule)->update(["autoreg" => $newModule]);
                // deactivate built-in hexonet module
                DB::table("tblregistrars")->where("registrar", $oldModule)->delete();
            }
        } else {
            $matchingConfig = false;
            if ($params["Username"]) {
                $matchingConfig = (!empty($oldConfig)
                    && ($oldConfig["Username"] === $params["Username"])
                    && ($oldConfig["Password"] === $params["Password"])
                    && ($oldConfig["TestMode"] === $params["TestMode"])
                );
            }
            $migrate = (
                (!$params["Username"] || $matchingConfig) && (DB::table("tbldomains")->where("registrar", $oldModule)->count() > 0
                    || DB::table("tbldomainpricing")->where("autoreg", $oldModule)->count() > 0
                )
            );
        }
    }

    $configarray = [
        "FriendlyName" => [
            "Type" => "System",
            "Value" => "\0 " . preg_replace('/v([.\d]*)/i', 'v' . CNIC_VERSION, $meta["description"]["name"])
        ],
        "Description" => [
            "Type" => "System",
            "Value" => ($meta["_priv"]["description"] .
                ($migrate ? $meta["_priv"]["bttn_migrate"] : "")
            )
        ],
        "Username" => [
            "FriendlyName" => "Username",
            "Type" => "text",
            "Size" => "20",
            "Description" => "Enter your Account Login ID"
        ],
        "Password" => [
            "FriendlyName" => "Password",
            "Type" => "password",
            "Size" => "20",
            "Description" => "Enter your Account Password"
        ],
        "TestMode" => [
            "FriendlyName" => "Use Test Environment",
            "Type" => "yesno",
            "Description" => "Connect to OT&amp;E (Test Environment)"
        ],
        "ProxyServer" => [
            "FriendlyName" => "Proxy Server",
            "Type" => "text",
            "Description" => "HTTP(S) Proxy Server (Optional)"
        ],
        "IRTP" => [
            "FriendlyName" => "IRTP (Inter-Registrar Transfer Policy)",
            "Type" => "radio",
            "Options" => ("Check to act as Designated Agent for all contact changes. Ensure you understand your role and responsibilities before checking this option.," .
                "Fallback to your Account's IRTP Settings."
            ),
            "Default" => "Check to act as Designated Agent for all contact changes. Ensure you understand your role and responsibilities before checking this option.",
            "Description" => $meta["_priv"]["fields"]["IRTP"]
        ],
        "TRANSFERLOCK" => [
            "FriendlyName" => "Automatic Transfer Lock",
            "Type" => "yesno",
            "Description" => "Automatically locks a Domain after Registration"
        ],
        "NSUpdTransfer" => [
            "FriendlyName" => "Automatic NS Update",
            "Type" => "yesno",
            "Description" => "Automatically update the domain's nameservers after successful transfer to the ones submitted with the order.<br/>NOTE: By default WHMCS suggests your configured Defaultnameservers in the configuration step of the shopping cart."
        ],
        "CHUpdTransfer" => [
            "FriendlyName" => "Automatic Contact Update",
            "Type" => "yesno",
            "Description" => ".com/.net/.cc/.tv: Automatically update the domain's contact details after successful transfer to the client details in case we were not able to parse data out of WHOIS data because of active id protection service.<br/>NOTE: This might lead to an IRTP contact verification."
        ],
        "DNSSEC" => [
            "FriendlyName" => "Offer DNSSEC / Secure DNS",
            "Type" => "yesno",
            "Description" => "Display the DNSSEC Management functionality in the Domain Details View."
        ],
        "TRANSFERCARTPRECHECK" => [
            "FriendlyName" => "Transfer Checkout Pre-Checks",
            "Type" => "yesno",
            "Description" => "Validate Domain Transfers on Shopping Cart Checkout. This will block the checkout until all Transfer pre-checks succeed. e.g. valid eppcode, unlocked domain etc."
        ],
        "SYNCIDPROTECTION" => [
            "FriendlyName" => "Sync Id Protection",
            "Type" => "yesno",
            "Description" => "Include Synchronizing TLD Settings in Registrar TLD Sync regarding Id Protection Support."
        ],
        "SUSPENDONEXPIRATION" => [
            "FriendlyName" => "Suspend after Expiration",
            "Type" => "yesno",
            "Description" => "Automatically suspend (clientHold) Domains after the expiration date has passed."
        ],
        "WHOISERRPSETTINGS" => [
            "FriendlyName" => "WHOIS Output & ERRP Settings",
            "Type" => "yesno",
            "Description" => "Offer fields for domain-level custom WHOIS Output and ERRP Settings in Client Summary > Tab Domains."
        ],
        "HPPS" => [
            "FriendlyName" => "High-Performance Setup",
            "Type" => "yesno",
            "Default" => "",
            "Description" => ("In case you experience slow performance because of network latency regarding our API communication, please use this option. " .
                "Please read <a href=\"https://centralnic-reseller.github.io/centralnic-reseller/docs/hexonet/whmcs/whmcs-ispapi-registrar#high-performance-setup\" " .
                "target=\"_blank\" style=\"text-decoration:underline;\">this guide</a> first."
            )
        ],
        "AFTERMARKETDOMAINS" => [
            "FriendlyName" => "Aftermarket Domains",
            "Type" => "yesno",
            "Description" => "Enable Support for Aftermarket Domain Names. Domains offered via Aftermarket are getting returned as available. This Feature is not compatible with the \"Domains Extended Addon\". Mandatory: Having Premium Domains enabled."
        ],
        "AutoEnableIDProtection" => [
            "FriendlyName" => "Precheck ID Protection",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the ID protection addon on shopping cart level."
        ],
        "AutoEnableDNSManagement" => [
            "FriendlyName" => "Precheck DNS Management",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the DNS Management addon on shopping cart level."
        ],
        "AutoEnableEmailForwarding" => [
            "FriendlyName" => "Precheck Email Forwarding",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the Email Forwarding addon on shopping cart level."
        ]
    ];

    $authOk = Ispapi::checkAuth($params); //keep this line here as it generates the canUse object
    if ($authOk !== false && $authOk["WEBAPPS"]) {
        $configarray["WebApps"] = [
            "FriendlyName" => "Offer Web Apps",
            "Type" => "yesno",
            "Description" => $meta["_priv"]["fields"]["WebApps"]
        ];
    }

    $system = $params["TestMode"] === "on" ? "OT&E" : "LIVE";
    $parts = parse_url(Setting::getValue("SystemURL"));
    $ip = gethostbyname($parts["host"]);

    if ($authOk === false) {
        $error = Ispapi::getAuthError();
        $url = $meta["_priv"]["UrlFaqAuthError"];
        $configarray[""] = [
            "Type" => "system",
            "Description" => (<<<HTML
                <div class="alert alert-danger" style="font-size:medium;margin-bottom:0px;">
                    <h2>Connecting to the {$system} Environment failed. <small>({$error})</small></h2>
                    <p>Read <a href="{$url}" target="_blank" class="alert-link">here</a> for possible reasons. <b>Your Server IP Address</b>: {$ip}</p>
                </div>
HTML
            )
        ];
    } else {
        $configarray[""] = [
            "Type" => "system",
            "Description" => (<<<HTML
                <div class="alert alert-success" style="font-size:medium;margin-bottom:0px;">
                    <h2>Connection to the {$system} Environment established.</h2><b>Your Server IP Address</b>: {$ip}
                </div>
HTML
            )
        ];
    }

    return $configarray;
}

/**
 * Provide custom buttons for domains in admin area
 * @param array $params common module parameters
 * @return array
 */
function ispapi_AdminCustomButtonArray($params)
{
    $domain = new \WHMCS\Domains();
    $params = $domain->getDomainsDatabyID($params["domainid"]);
    if (
        $params["registrar"] !== "ispapi"
    ) {
        return [];
    }

    $buttons = [
        "Refresh TLD Cache" => "flushzonefeatures"
    ];
    if ($params["type"] === "Transfer" && $params["status"] === "Pending Transfer") {
        return array_merge($buttons, [
            "Resend Transfer Approval Email" => "resendtransferapproval",
            "Cancel Domain Transfer" => "canceldomaintransfer"
        ]);
    }

    $registrar = new \WHMCS\Module\Registrar();
    if (
        preg_match("/^(Pending|Cancelled|Expired$)/", $params["status"]) //TODO
        || !$registrar->load($params["registrar"])
    ) {
        return [];
    }

    $params = array_merge($params, $registrar->getSettings());
    $r = HXDomain::getStatus($params, $params["domain"]);
    if ($r["success"]) {
        if (in_array("clientHold", $r["data"]["STATUS"])) {
            return array_merge($buttons, [
                "Unsuspend" => "unsuspend"
            ]);
        }
        return array_merge($buttons, [
            "Suspend" => "suspend"
        ]);
    }
    return $buttons;
}

/**
 * Resend the Transfer Approval Email
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_resendtransferapproval($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "ResendDomainTransferConfirmationEmails",
        "DOMAIN" => $domain
    ], $params);
    if ($r["CODE"] === "200") {
        logActivity($domain . ": Transfer Approval Mail successfully resend.");
        return [
            "message" => "Successfully resent the transfer approval email"
        ];
    }
    logActivity($domain . ": Failed resending the Transfer Approval Mail (" . $r["error"] . ").");
    return [
        "error" => "Failed resending the transfer approval email. (" . $r["error"] . ")"
    ];
}

/**
 * Flush Zone Configuration Cache
 * @param array $params common module parameters
 * @return array
 */
function ispapi_flushzonefeatures($params)
{
    HXDomain::flushZoneInformation(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
    return [
        "success" => true
    ];
}

/**
 * Cancel the Domain Transfer
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_canceldomaintransfer($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXTransfer::cancel($params, $domain);
    if ($r["success"]) {
        logActivity($domain . ": Transfer successfully cancelled.");
        return [
            "message" => "Successfully cancelled the domain transfer"
        ];
    }
    $error = "Failed to cancel the Transfer Request. (" . $r["error"] . ")";
    logActivity($domain . ": " . $error);
    return [
        "error" => $error
    ];
}

/**
 * Suspend the domain name
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_suspend($params, $bySync = false)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "ModifyDomain",
        "ADDSTATUS0" => "clientHold",
        "DOMAIN" => $domain
    ], $params);
    if ($r["CODE"] === "200") {
        logActivity($domain . ": Domain successfully suspended" . ($bySync ? " after Expiration" : "") . ".");
        return [
            "message" => "Successfully suspended."
        ];
    }
    logActivity($domain . ": Suspending the domain failed" . ($bySync ? " after Expiration" : "") . " (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ").");
    return [
        "error" => "Suspending failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
    ];
}

/**
 * Unsuspend the domain name
 * @param array $params common module parameters
 * @return array process result
 */
function ispapi_unsuspend($params)
{
    $domain = $params["sld"] . "." . $params["tld"];
    $r = Ispapi::call([
        "COMMAND" => "ModifyDomain",
        "DELSTATUS0" => "clientHold",
        "DOMAIN" => $domain
    ], $params);
    if ($r["CODE"] === "200") {
        logActivity($domain . ": Domain successfully unsuspended.");
        return [
            "message" => "Successfully unsuspended."
        ];
    }
    logActivity($domain . ": Unsuspending the domain failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ").");
    return [
        "error" => "Unsuspending failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
    ];
}

/**
 * Provide custom buttons (whoisprivacy, DNSSEC Management) for domains and
 * change of registrant button for certain domain names on client area
 *
 * @param array $params common module parameters
 * @return array $buttonarray an array custum buttons
 */
function ispapi_ClientAreaCustomButtonArray($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $buttons = [];

    $addflds = new AF($params["TestMode"] === "on");
    $addflds->setDomainType("whoisprivacy")
        ->setDomain($domain);
    if (!empty($addflds->getFields())) {
        // registry-specific id protection
        // (free of charge, don't cover it over _IDProtectToggle/ID Protection Addon)
        $buttons[L::trans("hxwhoisprivacy")] = "whoisprivacy";
    }
    if ($params["DNSSEC"] === "on") {
        $buttons[L::trans("hxdnssecmanagement")] = "dnssec";
    }
    if ($params["dnsmanagement"] && $params["WebApps"] && Ispapi::canUse("WEBAPPS", $params)) {
        $buttons[L::trans("hxwebapps")] = "webapps";
    }
    if ((bool)preg_match("/\.ca$/i", $domain)) {
        $status = HXDomain::getStatus($params, $domain);
        if (
            $status["success"]
            && (bool)preg_match("/^PENDING/i", $status["data"]["STATUS"][0])
            && !empty($status["data"]["X-CA-CONTACT-REGISTRANT"][0])
        ) {
            $buttons[L::trans("hxcacontactconfirmation")] = "cacontactconfirmation";
        }
    }
    return $buttons;
}

/**
 * Handle the .CA Contact Confirmation of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name and some variables
 */
function ispapi_cacontactconfirmation($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];
    $status = HXDomain::getStatus($params, $domain);

    return [
        "templatefile" => "tpl_ca_cacontactconfirmation",
        "vars" => [
            "L" => new L(),
            "domain" => $domain,
            "error" =>  !$status["success"],
            "status" =>  HXDomain::getStatus($params, $domain)
        ]
    ];
}

/**
 * Handle the WebApps management page of a domain
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name
 */
function ispapi_webapps($params)
{
    return WebApps::getPage($params);
}

/**
 * Handle the DNSSEC management page of a domain
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name
 */
function ispapi_dnssec($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $error = false;
    $successful = false;
    $domain = $params["sld"] . "." . $params["tld"];

    if (isset($_POST["submit"])) {
        $command = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "SECDNS-MAXSIGLIFE" => $_POST["MAXSIGLIFE"],
            "SECDNS-DS" => [],
            "SECDNS-KEY" => []
        ];

        //add DS and KEY records
        foreach (["SECDNS-DS", "SECDNS-KEY"] as $keyname) {
            if (isset($_POST[$keyname])) {
                foreach ($_POST[$keyname] as $dnssecrecord) {
                    $everything_empty = true;
                    foreach ($dnssecrecord as $attribute) {
                        if (!empty($attribute)) {
                            $everything_empty = false;
                        }
                    }
                    if (!$everything_empty) {
                        $command[$keyname][] = implode(" ", $dnssecrecord);
                    }
                }
            }
        }

        //remove DS records - bugfix (REASON? TICKET?)
        if (empty($command["SECDNS-DS"])) {
            unset($command["SECDNS-DS"]);
            $r = HXDomain::getStatus($params, $domain);
            if ($r["success"]) {
                $command["DELSECDNS-DS"] = $r["data"]["SECDNS-DS"];
            }
        }

        //process domain update
        $r = Ispapi::call($command, $params);
        if ($r["CODE"] === "200") {
            $successful = $r["DESCRIPTION"];
        } else {
            $error = $r["DESCRIPTION"];
        }
    }

    $maxsiglife = "";
    $secdnsds_newformat = [];
    $secdnskey_newformat = [];

    $r = HXDomain::getStatus($params, $domain);
    if ($r["success"]) {
        $r = $r["data"];
        $maxsiglife = (isset($r["SECDNS-MAXSIGLIFE"])) ? $r["SECDNS-MAXSIGLIFE"][0] : "";
        $secdnsds = (isset($r["SECDNS-DS"])) ? $r["SECDNS-DS"] : [];
        //delete empty KEY records, if cb fn not provided, array_filter will remove empty entries
        $secdnskey = (isset($r["SECDNS-KEY"])) ? array_values(array_filter($r["SECDNS-KEY"])) : [];

        //split in different fields
        foreach ($secdnskey as $key) {
            list($flags, $protocol, $alg, $pubkey) = preg_split("/\s+/", $key);
            $secdnskey_newformat[] = [
                "flags" => $flags,
                "protocol" => $protocol,
                "alg" => $alg,
                "pubkey" => $pubkey
            ];
        }

        //split in different fields
        foreach ($secdnsds as $ds) {
            list($keytag, $alg, $digesttype, $digest) = preg_split("/\s+/", $ds);
            $secdnsds_newformat[] = [
                "keytag" => $keytag,
                "alg" => $alg,
                "digesttype" => $digesttype,
                "digest" => $digest
            ];
        }
    } else {
        $error = $r["error"];
    }

    return [
        "templatefile" => "tpl_ca_dnssec",
        "vars" => [
            "L" => new L(),
            "error" => $error,
            "successful" => $successful,
            "secdnsds" => $secdnsds_newformat,
            "secdnskey" => $secdnskey_newformat,
            "maxsiglife" => $maxsiglife
        ]
    ];
}

/**
 * Handle the ID Protection (whoisprivacy) of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array an array with a template name and some variables
 */
function ispapi_whoisprivacy($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $domain = $params["sld"] . "." . $params["tld"];

    $addflds = new AF($params["TestMode"] === "on");
    $addflds->setDomainType("whoisprivacy")
        ->setDomain($domain);

    $error = false;
    if (isset($_POST["idprotection"])) {
        $command = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain
        ];
        $addflds->addWhoisProtectiontoCommand($command, $_POST["idprotection"]);
        $r = Ispapi::call($command, $params);
        if ($r["CODE"] !== "200") {
            $error = $r["DESCRIPTION"];
        }
    }

    $r = HXDomain::getStatus($params, $domain);
    $addflds->setFieldValuesFromAPI($r);
    $protected = $addflds->isWhoisProtected();

    return [
        "templatefile" => "tpl_ca_whoisprivacy_" . ($addflds->isWhoisProtectable() ? "protectable" : "notprotectable"),
        "vars" => [
            "L" => new L(),
            "error" => $error,
            "protected" => $protected
        ]
    ];
}

/**
 * Modify and save Transferlock settings of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - returns an array with command response description
 */
function ispapi_SaveRegistrarLock($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $result = HXDomain::saveRegistrarLock($params, $domain);
    logActivity(isset($result["error"]) ? $result["error"] : $result["success"]);
    return $result;
}

/**
 * Returns domain's information
 *
 * @param array $params common module parameters
 * @return \WHMCS\Domain\Registrar\Domain $thedomain
 */
function ispapi_GetDomainInformation($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $r = HXDomain::convert($params, $domain);
    $domainapi = $r["punycode"];

    $r = HXTransfer::getStatus($params, $domainapi);
    if ($r["success"] && $r["data"]["TRANSFERTYPE"][0] !== "TRADE") {
        $ns = [];
        $r = HXTransfer::getRequestCommand($params, $domainapi);
        if ($r["success"]) {
            foreach ($r["data"] as $key => $val) {
                if (preg_match("/^NAMESERVER([0-9]+)$/", $key, $m)) {
                    $ns["ns" . ((int)$m[1] + 1)] = $val;
                }
            }
        }

        $thedomain = new \WHMCS\Domain\Registrar\Domain();
        $thedomain
            ->setDomain($domain)
            ->setNameservers($ns);
        return $thedomain;
    }

    $r = HXDomain::getStatus($params, $domainapi);
    if (!$r["success"]) {
        if ($r["errorcode"] === "531") {
            throw new \Exception("Domain no longer in management - probably transferred away.");
        }
        if ($r["errorcode"] !== "545") {
            throw new \Exception("Loading Domain information failed. You may retry in few minutes.<br/><small>" . $r["errorcode"] . " " . $r["error"] . "</small>");
        }

        $r = HXApp::getStatus($params, $domainapi);
        if ($r["success"] && !empty($r["data"]["STATUS"][0])) {
            switch ($r["data"]["STATUS"][0]) {
                case "FAILED":
                    throw new \Exception("Premium Domain order failed.");
                    break;
                case "ACTIVE":
                case "SUCCESSFUL":
                    throw new \Exception("Premium Domain order succeeded. Will be soon in your Account.");
                    break;
                default:
                    throw new \Exception("Premium Domain order is pending. Check back again later.");
                    break;
            }
        }

        $status = DB::table("tbldomains")
            ->where("id", $params["domainid"])
            ->value("status");
        if ($status === "Pending") {
            $thedomain = new \WHMCS\Domain\Registrar\Domain();
            $thedomain->setDomain($domain);
            return $thedomain;
        }

        $values = HXDomain::getExpiredStatus($params, $domainapi, null, false);
        if (isset($values["transferredAway"]) && $values["transferredAway"] === true) {
            throw new \Exception("Domain no longer in management - probably transferred away.");
        }
        if (isset($values["expired"]) && isset($values["expirationdate"])) {
            if ($values["expired"] === true) {
                // in redemption period
                throw new \Exception("Domain expired, but is still renewable leading to redemption fees.");
            }
            // in ARGP
            throw new \Exception("Domain expired, but is still renewable.");
        }
        if (isset($values["expired"]) && $values["expired"] === true) {
            // expired, deleted
            $params["searchTerm"] = $params["sld"];
            $params["tldsToInclude"] = [$params["tld"]];
            $ac = ispapi_CheckAvailability($params);
            $ac = array_pop($ac->toArray());
            $msg = "Domain not found in Registrar's System. ";
            switch ($ac["status"]) {
                case SR::STATUS_NOT_REGISTERED:
                    $msg .= "Available for registration.";
                    break;
                case SR::STATUS_RESERVED:
                    $msg .= "Reserved Domain Name.";
                    break;
                case SR::STATUS_TLD_NOT_SUPPORTED:
                    $msg .= "TLD not supported.";
                    break;
                case SR::STATUS_REGISTERED:
                    $msg .= "Not available for registration.";
                    break;
                default:
                    $msg = "Eventually available for registration.";
                    break;
            }
            throw new \Exception($msg);
        }
        throw new \Exception("Loading Domain information failed. You may retry in few minutes.");
    }

    // get data: expired, expirydate, active
    $values = HXDomain::getExpiryData($params, $domainapi, false, $r, true);

    //nameservers
    $values["nameservers"] = Ispapi::castNameservers($r["data"]["NAMESERVER"]);

    //transferlock settings
    //itrp lock
    $values["setIrtpTransferLock"] = isset($r["data"]["TRADE-TRANSFERLOCK-EXPIRATIONDATE"][0]);
    //registrar lock
    $tl = HXDomain::getRegistrarLock($params, $domainapi);
    if ($tl === "locked") {
        $values["transferlock"] = true; // active
    } elseif ($tl === "unlocked") {
        $values["transferlock"] = false; // inactive
    } else {
        $values["transferlock"] = null; // not supported, or error
    }

    //addons
    $values["hasidprotection"] = (isset($r["data"]["X-ACCEPT-WHOISTRUSTEE-TAC"][0])
        && $r["data"]["X-ACCEPT-WHOISTRUSTEE-TAC"][0] === "1"
    );
    $values["hasemailforwarding"] = false;
    $values["dnsmanagement"] = isset($r["data"]["INTERNALNAMESERVER"]);

    if (!$values["dnsmanagement"]) {
        $r3 = HXDns::getStatus($params, $domainapi . ".");
        $values["dnsmanagement"] = $r3["success"];
        if ($values["dnsmanagement"] && $r3["data"]["RRSTOTAL"][0] > 0) {
            $results = ispapi_GetEmailForwarding($params);
            $values["hasemailforwarding"] = (!isset($results["error"]) && !empty($results));
            $values["dnsmanagement"] = $values["hasemailforwarding"];
        }
    }

    //IRTP handling
    $values["contactChangeExpiryDate"] = null;
    $values["setDomainContactChangePending"] = false;
    $values["setPendingSuspension"] = false;
    $values["setIsIrtpEnabled"] = false;
    $values["IRTPTriggerFields"] = [];
    $zi = HXDomain::getZoneInformation($params, $domainapi);
    if (!is_null($zi)) {
        $values["setIsIrtpEnabled"] = $zi->trade->isIRTP;
        $values["IRTPTriggerFields"] = $zi->trade->triggerFields;
    }

    //check if registrant change has been requested
    if (
        isset($r["data"]["X-REGISTRANT-VERIFICATION-STATUS"][0])
        && (bool)preg_match("/^PENDING|OVERDUE|REMINDED$/i", $r["data"]["X-REGISTRANT-VERIFICATION-STATUS"][0])
    ) {
        $values["setDomainContactChangePending"] = true;
        $values["setPendingSuspension"] = true;
        if (isset($r["data"]["X-REGISTRANT-VERIFICATION-DUEDATE"][0])) {
            $ts = Ispapi::castDate($r["data"]["X-REGISTRANT-VERIFICATION-DUEDATE"][0]);
            $values["contactChangeExpiryDate"] = \WHMCS\Carbon::createFromFormat("Y-m-d H:i:s", $ts["long"]);
        }
    }

    // Docs:
    // https://classdocs.whmcs.com/8.1/WHMCS/Domain/Registrar/Domain.html
    // https://developers.whmcs.com/domain-registrars/domain-information/
    // https://carbon.nesbot.com/docs/
    $thedomain = new \WHMCS\Domain\Registrar\Domain();
    $thedomain->setDomain($domain)
        ->setNameservers($values["nameservers"])
        //->setRegistrationStatus($response["status"])
        ->setTransferLock($values["transferlock"])
        //->setTransferLockExpiryDate(null)
        ->setExpiryDate($values["expirydate"])
        //->setRestorable(false)
        //->setRegistrantEmailAddress($response["registrant"]["email"])
        // -- IRTP
        ->setIsIrtpEnabled($values["setIsIrtpEnabled"])
        ->setIrtpTransferLock($values["setIrtpTransferLock"])
        ->setDomainContactChangePending($values["setDomainContactChangePending"])
        ->setPendingSuspension($values["setPendingSuspension"])
        ->setDomainContactChangeExpiryDate($values["contactChangeExpiryDate"])
        ->setIrtpVerificationTriggerFields($values["IRTPTriggerFields"])
        //->IrtpTransferLockExpiryDate($irtpTransferLockExpiryDate)
        //-- ->setIrtpOptOutStatus(false)
        // -- addons
        ->setIdProtectionStatus($values["hasidprotection"])
        ->setDnsManagementStatus($values["hasdnsmanagement"])
        ->setEmailForwardingStatus($values["hasemailforwarding"]);

    // add custom data (for import purposes)
    // registrant vatid
    $keys = array_keys($r["data"]);
    $vatid = "";
    $pnames = preg_grep(
        "/admin|tech|billing/i",
        preg_grep("/vatid/i", $keys),
        PREG_GREP_INVERT
    );
    foreach ($pnames as $prop) {
        if (!empty($r["data"][$prop][0])) {
            $vatid = $r["data"][$prop][0];
            break;
        }
    }

    // additional domain fields
    $addflds = new AF($params["TestMode"] === "on");
    $addflds->setDomain($domain)
        ->setFieldValuesFromAPI($r);

    // registration date
    $registrationdate = Ispapi::castDate($r["data"]["CREATEDDATE"][0]);

    // set custom data
    $thedomain->registrarData = [
        "isPremium" => (bool) preg_match("/^premium_/i", $r["data"]["SUBCLASS"][0]),
        "isTrusteeUsed" => (empty($r["data"]["X-TRUSTEE"][0])) ? 0 : 1,
        "createdDate" => $registrationdate["long"],
        "registrantTaxId" => $vatid,
        "domainfields" => $addflds
    ];

    // idnLanguage detection
    if ($r["data"]["DOMAINUMLAUT"][0] !== $r["data"]["ID"][0]) {
        if (isset($params["idnlanguage"])) {
            $lang = $params["idnlanguage"];
            $thedomain->registrarData["idnLanguage"] = $lang;
        } else {
            $lang = HXDomain::getIDNLanguage($params, $r["data"]["ID"][0]);
            if ($lang["success"]) {
                $thedomain->registrarData["idnLanguage"] = $lang["language"];
            }
        }
    }

    return $thedomain;
}
/**
 * Resend verification email
 *
 * @param array $params common module parameters
 *
 * @return array returns success or error
 */
function ispapi_ResendIRTPVerificationEmail($params)
{
    $r = Ispapi::call([
        "COMMAND" => "ResendDomainRegistrantVerificationEmail",
        "DOMAIN" => $params["sld"] . "." . $params["tld"]
    ], $params);
    if ($r["CODE"] === "200") {
        return [
            "success" => true
        ];
    }
    return [
        "error" => $r["CODE"] . " " . $r["DESCRIPTION"]
    ];
}

/**
 * Return the authcode of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values an array with the authcode
 */
function ispapi_GetEPPCode($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXDomain::getAuthCode($params, $domain);
    logActivity($domain . ": " . (isset($r["error"]) ? $r["error"] : "Successfully loaded the epp code."));
    return $r;
}

/**
 * Modify and save Nameservers of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - returns an array with command response description
 */
function ispapi_SaveNameservers($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $r = Ispapi::call([
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $params["sld"] . "." . $params["tld"],
        "NAMESERVER" => Ispapi::castNameserversBE($params, false),
        "INTERNALDNS" => (int)$params["dnsmanagement"]
    ], $params);
    if ($r["CODE"] !== "200") {
        $error = $r["DESCRIPTION"];
        if ($r["CODE"] === "504" && preg_match("/TOO FEW.+CONTACTS/", $values["error"])) {
            $error = "Please update contact data first to be able to update nameserver data.";
        }
        return [
            "error" => $error
        ];
    }
    return [
        "success" => true
    ];
}

/**
 * Get DNS Zone of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $hostrecords - an array with hostrecord of the domain name
 */
function ispapi_GetDNS($params)
{
    $values = [];
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $dnszone = $domain . ".";

    //convert the dnszone to punycode
    $r = HXDomain::convert($params, $domain);
    $domain = $r["punycode"];
    $dnszone_pc = $domain . ".";

    // Check if DNSZone exists, if not create it
    $r = Ispapi::call([
        "COMMAND" => "StatusDNSZone",
        "DNSZONE" => $dnszone_pc
    ]);
    if ($r["CODE"] === "545") { // Object not found
        $r = Ispapi::call([
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "INTERNALDNS" => 1
        ]);
        if ($r["CODE"] !== "200") {
            return [
                "error" => $r["DESCRIPTION"]
            ];
        }
    }

    $response = Ispapi::call([
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $dnszone_pc,
        "EXTENDED" => 1
    ], $params);
    if ($response["CODE"] !== "200") {
        return [
            "error" => $response["DESCRIPTION"]
        ];
    }

    $hostrecords = [];
    $i = 0;
    foreach ($response["PROPERTY"]["RR"] as $rr) {
        $fields = explode(" ", $rr);
        $domain = array_shift($fields);
        $ttl = array_shift($fields);
        $class = array_shift($fields);
        $rrtype = array_shift($fields);

        if ($domain === $dnszone) {
            $domain = "@";
        }
        $domain = str_replace("." . $dnszone_pc, "", $domain);

        if ($rrtype === "A") {
            $hostrecords[$i] = [
                "hostname" => $domain,
                "type" => $rrtype,
                "address" => $fields[0]
            ];
            if (preg_match("/^mxe-host-for-ip-(\d+)-(\d+)-(\d+)-(\d+)$/i", $domain, $m)) {
                unset($hostrecords[$i]);
                $i--;
            }
            $i++;
        }

        if ($rrtype === "AAAA") {
            $hostrecords[$i] = [
                "hostname" => $domain,
                "type" => "AAAA",
                "address" => $fields[0]
            ];
            $i++;
        }

        if ($rrtype === "TXT") {
            $hostrecords[$i] = [
                "hostname" => $domain,
                "type" => $rrtype,
                "address" => implode(" ", $fields)
            ];
            $i++;
        }

        if ($rrtype === "SRV") {
            $priority = array_shift($fields);
            $hostrecords[$i] = [
                "hostname" => $domain,
                "type" => $rrtype,
                "address" => implode(" ", $fields),
                "priority" => $priority
            ];
            $i++;
        }

        if ($rrtype === "CNAME") {
            $hostrecords[$i] = [
                "hostname" => $domain,
                "type" => $rrtype,
                "address" => $fields[0]
            ];
            $i++;
        }

        if ($rrtype === "X-HTTP") {
            if (preg_match("/^\//", $fields[0])) {
                $domain .= array_shift($fields);
                /*while(substr($domain, -1)=="/"){
                    $domain = substr_replace($domain, "", -1);
                }*/
            }

            $url_type = array_shift($fields);
            if ($url_type === "REDIRECT") {
                $url_type = "URL";
            }

            $hostrecords[$i] = [
                "hostname" => $domain,
                "type" => $url_type,
                "address" => implode(" ", $fields)
            ];
            $i++;
        }
    }

    //only for MX fields, they are note displayed in the "EXTENDED" version
    $response = Ispapi::call([
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $dnszone_pc,
        "SHORT" => 1
    ], $params);
    if ($response["CODE"] !== "200") {
        return [
            "error" => $response["DESCRIPTION"]
        ];
    }
    foreach ($response["PROPERTY"]["RR"] as $rr) {
        $fields = explode(" ", $rr);
        $domain = array_shift($fields);
        $ttl = array_shift($fields);
        $class = array_shift($fields);
        $rrtype = array_shift($fields);

        if ($rrtype === "MX") {
            if (preg_match("/^mxe-host-for-ip-(\d+)-(\d+)-(\d+)-(\d+)($|\.)/i", $fields[1], $m)) {
                $hostrecords[$i] = [
                    "hostname" => $domain,
                    "type" => "MXE",
                    "address" => $m[1] . "." . $m[2] . "." . $m[3] . "." . $m[4]
                ];
            } else {
                $hostrecords[$i] = [
                    "hostname" => $domain,
                    "type" => $rrtype,
                    "address" => $fields[1],
                    "priority" => $fields[0]
                ];
            }
            $i++;
        }
    }
    return $hostrecords;
}

/**
 * Modify and save DNS Zone of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $hostrecords - an array with hostrecord of the domain name
 */
function ispapi_SaveDNS($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $dnszone = $params["sld"] . "." . $params["tld"] . ".";
    $domain = $params["sld"] . "." . $params["tld"];

    $command = [
        "COMMAND" => "UpdateDNSZone",
        "DNSZONE" => $dnszone,
        "RESOLVETTLCONFLICTS" => 1,
        "INCSERIAL" => 1,
        "EXTENDED" => 1,
        "DELRR" => ["% A", "% AAAA", "% CNAME", "% TXT", "% MX", "% X-HTTP", "% X-SMTP", "% SRV"],
        "ADDRR" => []
    ];

    $mxe_hosts = [];
    foreach ($params["dnsrecords"] as $key => $values) {
        $hostname = $values["hostname"];
        $type = strtoupper($values["type"]);
        $address = $values["address"];
        $priority = $values["priority"];

        if (strlen($hostname) && strlen($address)) {
            if ($type === "A") {
                $command["ADDRR"][] = "$hostname $type $address";
            }
            if ($type === "AAAA") {
                $command["ADDRR"][] = "$hostname $type $address";
            }
            if ($type === "CNAME") {
                $command["ADDRR"][] = "$hostname $type $address";
            }
            if ($type === "TXT") {
                $command["ADDRR"][] = "$hostname $type $address";
            }
            if ($type === "SRV") {
                if (empty($priority)) {
                    $priority = 0;
                }
                $command["DELRR"][] = "% SRV";
                $command["ADDRR"][] = "$hostname $type $priority $address";
            }
            if ($type === "MXE") {
                $mxpref = 100;
                if (preg_match("/^([0-9]+) (.*)$/", $address, $m)) {
                    $mxpref = $m[1];
                    $address = $m[2];
                }
                if (preg_match("/^([0-9]+)$/", $priority)) {
                    $mxpref = $priority;
                }

                if (preg_match("/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/", $address, $m)) {
                    $mxe_host = "mxe-host-for-ip-$m[1]-$m[2]-$m[3]-$m[4]";
                    $ip = $m[1] . "." . $m[2] . "." . $m[3] . "." . $m[4];
                    $mxe_hosts[$ip] = $mxe_host;
                    $command["ADDRR"][] = "$hostname MX $mxpref $mxe_host";
                } else {
                    $address = "$mxpref $address";
                    $type = "MX";
                }
            }
            if ($type === "MX") {
                $mxpref = 100;
                if (preg_match("/^([0-9]+) (.*)$/", $address, $m)) {
                    $mxpref = $m[1];
                    $address = $m[2];
                }
                if (preg_match("/^([0-9]+)$/", $priority)) {
                    $mxpref = $priority;
                }

                $command["ADDRR"][] = "$hostname $type $mxpref $address";
            }
            if ($type === "FRAME") {
                $redirect = "FRAME";
                if (preg_match("/^([^\/]+)(.*)$/", $hostname, $m)) {
                    $hostname = $m[1];
                    $redirect = $m[2] . " " . $redirect;
                }
                $command["ADDRR"][] = "$hostname X-HTTP $redirect $address";
            }
            if ($type === "URL") {
                $redirect = "REDIRECT";
                if (preg_match("/^([^\/]+)(.*)$/", $hostname, $m)) {
                    $hostname = $m[1];
                    $redirect = $m[2] . " " . $redirect;
                }
                $command["ADDRR"][] = "$hostname X-HTTP $redirect $address";
            }
        }
    }
    foreach ($mxe_hosts as $address => $hostname) {
        $command["ADDRR"][] = "$hostname A $address";
    }

    //add X-SMTP to the list
    $response = Ispapi::call([
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $dnszone,
        "EXTENDED" => 1
    ], $params);

    if ($response["CODE"] === "200") {
        foreach ($response["PROPERTY"]["RR"] as $rr) {
            $fields = explode(" ", $rr);
            $domain = array_shift($fields);
            $ttl = array_shift($fields);
            $class = array_shift($fields);
            $rrtype = array_shift($fields);

            if ($rrtype === "X-SMTP") {
                $command["ADDRR"][] = $rr;

                $item = preg_grep("/@ MX [0-9 ]* mx.ispapi.net./i", $command["ADDRR"]);
                if (!empty($item)) {
                    $index_arr = array_keys($item);
                    $index = $index_arr[0];
                    unset($command["ADDRR"][$index]);
                    $command["ADDRR"] = array_values($command["ADDRR"]);
                }
            }
        }
    }

    // nothing to do ...
    if (empty($command["ADDRR"])) {
        return [
            "success" => "success"
        ];
    }

    //remove duplicates from ADDRR array which ends in an api error otherwise
    $command["ADDRR"] = array_values(array_unique($command["ADDRR"]));

    //send command to update DNS Zone
    $response = Ispapi::call($command, $params);

    //case 545: DNS Zone not existing, shouldn't happen any longer, see InvoicePaid subscription in hooks.php
    if ($response["CODE"] !== "200") {
        return [
            "error" => $response["DESCRIPTION"]
        ];
    }
    return [
        "success" => "success"
    ];
}

/**
 * Get Email forwarding of a domain name with its DNS zone
 *
 * @param array $params common module parameters
 *
 * @return array $result - returns an array with command response description
 */
function ispapi_GetEmailForwarding($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $params["sld"] . "." . $params["tld"] . ".",
        "SHORT" => 1,
        "EXTENDED" => 1
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    $result = [];
    foreach ($r["PROPERTY"]["RR"] as $rr) {
        $fields = explode(" ", $rr);
        $domain = array_shift($fields);
        $ttl = array_shift($fields);
        $class = array_shift($fields);
        $rrtype = array_shift($fields);

        if (($rrtype === "X-SMTP") && ($fields[1] === "MAILFORWARD")) {
            if (preg_match("/^(.*)\@$/", $fields[0], $m)) {
                $address = $m[1];
                if (!strlen($address)) {
                    $address = "*";
                }
            }
            $result[] = [
                "prefix" => $address,
                "forwardto" => $fields[2]
            ];
        }
    }
    return $result;
}

/**
 * Save Email forwarding of a domain name by updating its DNS zone
 *
 * @param array $params common module parameters
 *
 * @return array $values - returns an array with command response description
 */
function ispapi_SaveEmailForwarding($params)
{
    $values = [];
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    //Bug fix - Issue WHMCS
    //###########
    if (is_array($params["prefix"][0])) {
        $params["prefix"][0] = $params["prefix"][0][0];
    }
    if (is_array($params["forwardto"][0])) {
        $params["forwardto"][0] = $params["forwardto"][0][0];
    }
    //###########

    $username = $params["Username"];
    $password = $params["Password"];
    $testmode = $params["TestMode"];
    $tld = $params["tld"];
    $sld = $params["sld"];
    foreach ($params["prefix"] as $key => $value) {
        $forwardarray[$key]["prefix"] =  $params["prefix"][$key];
        $forwardarray[$key]["forwardto"] =  $params["forwardto"][$key];
    }

    $dnszone = $params["sld"] . "." . $params["tld"] . ".";

    $command = [
        "COMMAND" => "UpdateDNSZone",
        "DNSZONE" => $dnszone,
        "RESOLVETTLCONFLICTS" => 1,
        "INCSERIAL" => 1,
        "EXTENDED" => 1,
        "DELRR" => ["@ X-SMTP"],
        "ADDRR" => [],
    ];

    foreach ($params["prefix"] as $key => $value) {
        $prefix = $params["prefix"][$key];
        $target = $params["forwardto"][$key];
        if (strlen($prefix) && strlen($target)) {
            $redirect = "MAILFORWARD";
            if ($prefix === "*") {
                $prefix = "";
            }
            $redirect = $prefix . "@ " . $redirect;
            $command["ADDRR"][] = "@ X-SMTP $redirect $target";
        }
    }

    $response = Ispapi::call($command, $params);

    if ($response["CODE"] !== "200") {
        $values["error"] = $response["DESCRIPTION"];
    }
    return $values;
}

/**
 * Contact data of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with different contact values.
 */
function ispapi_GetContactDetails($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $r = HXDomain::getStatus($params, $domain);
    if (!$r["success"]) {
        return [
            "error" => "Failed to load Contact Details (" . $r["errorcode"] . " " . $r["error"] . ")."
        ];
    }
    return HXContact::getInfo($params, $r);
}

/**
 * Modify and save contact data of a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_SaveContactDetails($params)
{
    $params_transliterated = $params;
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $idprotection = ($params["idprotection"] === true) ? 1 : 0;
    // API Command Stub
    $command = [
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $domain,
        "X-ACCEPT-WHOISTRUSTEE-TAC" => $idprotection
    ];
    // add contact data to the API command
    HXContact::updFromParams($command, $params_transliterated);

    // prepare additional domain fields (UPDATE)
    $updaddflds = new AF($params["TestMode"] === "on");
    $updaddflds->setDomainType("update")
        ->setDomain($domain);

    // Try Trade
    // check if change of registrant requires a trade
    $zi = HXDomain::getZoneInformation($params, $domain);
    if (!is_null($zi) && $zi->trade->required) { // IRTP, Standard Trade
        $cmd = [
            "COMMAND" => "TradeDomain",
            "DOMAIN" => $domain,
            //"X-ACCEPT-WHOISTRUSTEE-TAC" => $idprotection // not supported atm
        ];
        // add contact data to the API command
        HXContact::updFromParams($cmd, $params_transliterated);
        // add additional domain fields to the API command
        $trdaddflds = new AF($params["TestMode"] === "on");
        $trdaddflds->setDomainType("trade")
            ->setDomain($domain)
            ->setFieldValuesFromPost();
        $trdaddflds->addToCommand($cmd);

        // IRTP specifics --- TODO: we could cover these fields over AdditionalFields
        if ($zi->trade->isIRTP) {
            if ((bool)preg_match("/Designated Agent/", $params["IRTP"])) {
                $cmd["X-CONFIRM-DA-OLD-REGISTRANT"] = 1;
                $cmd["X-CONFIRM-DA-NEW-REGISTRANT"] = 1;
            }
            //HM-735: opt-out is not supported for AFNIC TLDs (pm, tf, wf, yt, fr, re)
            if (!preg_match("/AFNIC/i", $repository)) {
                $cmd["X-REQUEST-OPT-OUT-TRANSFERLOCK"] = 0;
                if ($params["irtpOptOut"]) {
                    $cmd["X-REQUEST-OPT-OUT-TRANSFERLOCK"] = 1;
                }
            }
        } else {
            $tld = strtolower(preg_replace("/^.+\./", ".", $domain)); //2nd lvl tld
            if (AF::requiresFaxForm($tld, "trade")) {
                $tldcl = substr($tld, 1); //strip leading dot
            }
        }

        // API request
        $r = Ispapi::call($cmd, $params);
        if ($r["CODE"] === "200") {
            $msg = $domain . ": Contact Update by Trade Method succeeded/initiated ";
            try {
                $p = HXTrade::getPrice($params, $params["tld"]);
                if ($p) {
                    $msg .= "(Price: " . $p["price"] . " " . $p["currency"] . ").";
                } else {
                    $msg .= "(free of charge).";
                }
            } catch (\Exception $e) {
            } // table ispapi_relations does not exist if Registrar TLD Sync hasn't been used yet
            logActivity($msg);
            $trdaddflds->saveToDatabase($params["domainid"], true);
            // respond including pending information
            return $trdaddflds->respondPending($r);
        }
        if (
            !(
                ($r["CODE"] === "506" || $r["CODE"] === "219")
                && (bool)preg_match("/(trade is only allowed for change of registrant|please use UPDATE method)/", $r["DESCRIPTION"])
            )
        ) {
            logActivity($domain . ": Contact Update by Trade Method failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ").");
            return [
                "error" => "Updating Contact Information failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")."
            ];
        }
        // load additional domain fields from different type (TRADE)
        // hint: X-.+-REGISTRATION-TAC not allowed for update, but sent with trade
        $updaddflds->setFieldValuesFromPostType("trade");
    } else {
        $updaddflds->setFieldValuesFromPost();
    }

    // add additional fields to command
    $updaddflds->addToCommand($command);

    // API request
    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        logActivity($domain . ": Contact Update failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ").");
        // Data management policy violation; Update domain combination of status, name server and registrant is not allowed
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    logActivity($domain . ": Contact Update succeeded.");
    $updaddflds->saveToDatabase($params["domainid"], true);
    // respond including pending information
    return $updaddflds->respondPending($r);
}

/**
 * Add a new Private Nameserver (=GLUE RECORD)
 * A glue record is simply the association of a hostname (nameserver in our case) with an IP address at the registry
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_RegisterNameserver($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "AddNameserver",
        "NAMESERVER" => $params["nameserver"],
        "IPADDRESS0" => $params["ipaddress"]
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    return [
        "success" => "success"
    ];
}

/**
 * Modify a Private Nameserver
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_ModifyNameserver($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "ModifyNameserver",
        "NAMESERVER" => $params["nameserver"],
        "DELIPADDRESS0" => $params["currentipaddress"],
        "ADDIPADDRESS0" => $params["newipaddress"],
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    return [
        "success" => "success"
    ];
}

/**
 * Delete a Private Nameserver
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_DeleteNameserver($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "DeleteNameserver",
        "NAMESERVER" => $params["nameserver"]
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    return [
        "success" => "success"
    ];
}

/**
 * Toggle the ID Protection of a domain name
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_IDProtectToggle($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $params["sld"] . "." . $params["tld"],
        "X-ACCEPT-WHOISTRUSTEE-TAC" => ($params["protectenable"]) ? "1" : "0"
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    return [
        "success" => "success"
    ];
}

/**
 * Register a domain name - Premium support
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_RegisterDomain($params)
{
    $params_transliterated = $params;
    $premiumDomainsEnabled = (bool) $params["premiumEnabled"];
    $premiumDomainsCost = $params["premiumCost"];
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $command = [
        "COMMAND" => "AddDomain",
        "DOMAIN" => $domain,
        "PERIOD" => $params["regperiod"],
        "NAMESERVER" => Ispapi::castNameserversBE($params, false),
    ];
    // add contacts
    HXContact::getFromParams($command, $params_transliterated);

    if (preg_match("/\.swiss$/i", $domain)) {
        $command["COMMAND"] = "AddDomainApplication";
        $command["CLASS"] = "GOLIVE";
    }
    //#####################################################################
    //##################### PREMIUM DOMAIN HANDLING #######################
    //######################################################################
    //check if premium domain functionality is enabled by the admin
    //check if the domain has a premium price
    if ($premiumDomainsEnabled && !empty($premiumDomainsCost)) {
        $check = Ispapi::call([
            "COMMAND" => "CheckDomains",
            "DOMAIN0" => $domain,
            "PREMIUMCHANNELS" => "*"
        ], $params);
        if ($check["CODE"] === "200") {
            $regprice = $check["PROPERTY"]["PRICE"][0];
            $regclass = empty($check["PROPERTY"]["CLASS"][0]) ? "AFTERMARKET_PURCHASE_" . $check["PROPERTY"]["PREMIUMCHANNEL"][0] : $check["PROPERTY"]["CLASS"][0];
            $regcurrency = $check["PROPERTY"]["CURRENCY"][0];

            if ($premiumDomainsCost == $regprice) { //check if the price displayed to the customer is equal to the real cost at the registar
                $command["COMMAND"] = "AddDomainApplication";
                $command["CLASS"] =  $regclass;
                $command["PRICE"] =  $premiumDomainsCost;
                $command["CURRENCY"] = $regcurrency;
            }
        }
    }
    //#####################################################################

    if ($command["COMMAND"] !== "AddDomainApplication") {
        //--- TODO ---
        //INTERNALDNS, X-ACCEPT-WHOISTRUSTEE-TAC, TRANSFERLOCK parameters are not
        //supported in AddDomainApplication command. We need to sync this later.
        if ($params["TRANSFERLOCK"]) {
            $command["TRANSFERLOCK"] = 1;
        }
        if ($params["dnsmanagement"]) {
            $command["INTERNALDNS"] = 1;
        }
        if ($params["idprotection"]) {
            $command["X-ACCEPT-WHOISTRUSTEE-TAC"] = 1;
        }
    }

    AF::addToCMD($params, $command);

    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    if (preg_match("/\.swiss$/i", $domain)) {
        $appid = $r["PROPERTY"]["APPLICATION"][0];
        DB::table("tbldomains")
            ->where("id", "=", $params["domainid"])
            ->update([
                "additionalnotes" => "### DO NOT DELETE THE LINE BELOW ### \n.SWISS ApplicationID: " . $appid . "\n"
            ]);
        return [
            "pending" => true,
            "pendingMessage" => ("APPLICATION ID <strong>" . $appid . "</strong> SUCCESSFULLY SUBMITTED." .
                " STATUS IS PENDING UNTIL THE SWISS REGISTRATION PROCESS IS COMPLETED"
            ),
            "success" => true
        ];
    }
    return [
        "success" => true
    ];
}

/**
 * Transfer a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_TransferDomain($params)
{
    $params_transliterated = $params;
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    $premiumDomainsEnabled = (bool) $params["premiumEnabled"];
    $premiumDomainsCost = $params["premiumCost"];

    $r = HXDomain::convert($params, $domain);
    $domainapi = $r["punycode"];

    //domain transfer pre-check
    $command = [
        "COMMAND" => "CheckDomainTransfer",
        "DOMAIN" => $domainapi
    ];
    if ($params["eppcode"]) {
        $command["AUTH"] = $params["eppcode"];
    }
    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "218") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }

    if (isset($r["PROPERTY"]["AUTHISVALID"]) && $r["PROPERTY"]["AUTHISVALID"][0] === "NO") {
        // return custom error message
        return [
            "error" => "Invaild Authorization Code"
        ];
    }

    if (isset($r["PROPERTY"]["TRANSFERLOCK"]) && $r["PROPERTY"]["TRANSFERLOCK"][0] === "1") {
        // return custom error message
        return [
            "error" => "Transferlock is active. Therefore the Domain cannot be transferred."
        ];
    }

    $command = [
        "COMMAND" => "TransferDomain",
        "DOMAIN" => $domainapi,
        "PERIOD" => $params["regperiod"], //this does not fit to all TLDs
        "NAMESERVER" => Ispapi::castNameserversBE($params, false),
        "AUTH" => $params["eppcode"]
    ];
    // auto-detect user-transfer
    if (isset($r["PROPERTY"]["USERTRANSFERREQUIRED"]) && $r["PROPERTY"]["USERTRANSFERREQUIRED"][0] === "1") {
        $command["ACTION"] = "USERTRANSFER";
    }

    $zi = HXDomain::getZoneInformation($params, $domainapi);
    if (!is_null($zi)) {
        // add contacts just not in case of ownerchange by trade / irtp-trade,
        // exception AFNIC TLDs: admin-c + tech-c == mandatory
        // IDEA: better would be a post-transfer update process (not in transfer process)
        if ($zi->transfer->includeContacts) {
            HXContact::getFromParams($command, $params_transliterated, $zi->transfer->contacts);
        }

        // BEGIN------------------------------------------------------------------------
        // auto-detect default transfer period
        // for example, .NO, .NU tlds require period value as zero (free transfers).
        // in WHMCS the default value is 1 (1Y)
        // if transfer for free is supported and regperiod not listed in supported periods
        // if provided period isn't supported for transfers at all, use the default one we support
        if (!in_array((int)$params["regperiod"], $zi->transfer->periods)) {
            $command["PERIOD"] = $zi->transfer->isFree ? "0Y" : $zi->transfer->defaultPeriod;
            //TODO: execute a regperiod renewal after transfer
        }
        // END ------------------------------------------------------------------------
    }

    //#####################################################################
    //##################### PREMIUM DOMAIN HANDLING #######################
    //######################################################################
    if ($premiumDomainsEnabled && !empty($premiumDomainsCost)) {
        //check if premium domain functionality is enabled by the admin
        //check if the domain has a premium price
        $chk = Ispapi::call([
            "COMMAND" => "CheckDomains",
            "DOMAIN0" => $domainapi,
            "PREMIUMCHANNELS" => "*"
        ], $params);
        //todo - it would propbably be better to rely on ispapi_CheckAvailability
        if ($chk["CODE"] === "200" && !empty($chk["PROPERTY"]["CLASS"][0])) {
            //check if the price displayed to the customer is equal to the real cost at the registar
            $price = HXUser::getRelationValue($params, "PRICE_CLASS_DOMAIN_" . $chk["PROPERTY"]["CLASS"][0] . "_TRANSFER");
            if ($price !== false && $premiumDomainsCost == $price) {
                $command["CLASS"] = $chk["PROPERTY"]["CLASS"][0];
            } else {
                return [
                    "error" => "Price mismatch. Got $premiumDomainsCost, but expected $price."
                ];
            }
        }
    }
    //#####################################################################

    // add additional domain fields to the API command
    // load additional domain fields from different type (register)
    // hint: e.g. X-.+-REGISTRATION-TAC not allowed for transfer, but forwarded by WHMCS
    // e.g. 503 Invalid Parameter: X-NU-ACCEPT-REGISTRATION-TAC
    $trflds = new AF($params["TestMode"] === "on");
    $trflds->setDomainType("transfer")
        ->setDomain($domain)
        ->setFieldValuesFromParamsType($params, "register")
        ->addToCommand($command);

    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => $r["DESCRIPTION"]
        ];
    }
    return [
        "success" => true
    ];
}

/**
 * Renew (or restore) a Domain Name
 *
 * @param array $params common module parameters
 *
 * @return array
 */
function ispapi_RenewDomain($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];

    // --- Domain Restore
    if (isset($params["isInRedemptionGracePeriod"]) && $params["isInRedemptionGracePeriod"]) {
        $r = HXDomain::restore($params, $domain);
        logActivity($domain . ": " . (isset($r["error"]) ? $r["error"] : $r["message"]));
        if (!isset($r["periodLeft"])) {
            return $r;
        }
        // continue with renewal below based on renewal period difference
        $params["regperiod"] = $r["periodLeft"];
    }

    $r = HXDomain::renew($params, $domain);
    logActivity($domain . ": " . $r["message"]);
    return $r;
}

/**
 * Release a domain name
 * A domain name can be pushed to the registry or to another registrar.
 * This feature currently works for .DE domains (DENIC Transit), .UK domains (.UK detagging), .VE domains, .IS domains and .AT domains (.AT Billwithdraw).
 *
 * @param array $params common module parameters
 * @return array
 */
function ispapi_ReleaseDomain($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    $domain = $params["sld"] . "." . $params["tld"];
    $r = HXDomain::getRegistrarLock($params, $domain);
    if ($r === "locked") {
        $msg = "Releasing impossible. Please remove the Registrar Lock first.";
        logActivity($domain . ": " . $msg);
        return [
            "error" => $msg
        ];
    }

    $command = [
        "COMMAND" => "PushDomain",
        "DOMAIN" => $domain
    ];
    if (!empty($params["transfertag"])) {
        $command["TARGET"] = $params["transfertag"];
    }
    $r = Ispapi::call($command, $params);

    if ($r["CODE"] !== "200") {
        $msg = "Releasing failed. (" . $r["DESCRIPTION"] . ")";
        logActivity($domain . ": " . $msg);
        return [
            "error" => $msg
        ];
    }
    logActivity($domain . ": Releasing succeeded.");
    return [
        "success" => "success"
    ];
}

/**
 * Delete a domain name
 *
 * @param array $params common module parameters
 *
 * @return array $values - an array with command response description
 */
function ispapi_RequestDelete($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }

    $r = Ispapi::call([
        "COMMAND" => "DeleteDomain",
        "DOMAIN" => $params["sld"] . "." . $params["tld"]
    ], $params);

    if ($r["CODE"] !== "200") {
        return [
            "error" => "Deletion failed. (" . $r["DESCRIPTION"] . ")"
        ];
    }
    return [
        "success" => "success"
    ];
}

/**
 * Incoming Domain Transfer Sync.
 *
 * Check status of incoming domain transfers and notify end-user upon
 * completion. This function is called daily for incoming domains.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 *
 * @return array
 */
function ispapi_TransferSync($params)
{
    $domain = $params["sld"] . "." . $params["tld"];

    // check if the transfer is still pending
    $r = HXTransfer::getStatus($params, $domain);
    if ($r["success"] === true) {
        logActivity($domain . ": Domain Transfer is still pending (Existing Request).");
        return []; //still pending
    }

    // get date of last transfer request
    $r = HXTransfer::getRequestLog($params, $domain);
    if ($r["success"] === false || $r["data"]["COUNT"][0] === "0") {
        logActivity($domain . ": Domain Transfer is still pending (No Request Log found).");
        return []; //still pending
    }

    // existing transfer request
    // check for related failed entry
    $logdate = $r["data"]["LOGDATE"][0]; // 2019-11-15 12:25:05
    $logindex = $r["data"]["LOGINDEX"][0]; // 627992982

    // check if the domain is already on account
    $r = HXDomain::getStatus($params, $domain);
    if ($r["success"]) {
        // AUTO-UPDATE ns after transfer
        if ($params["NSUpdTransfer"] === "on") {
            // load the ones submitted in transfer request
            $newns = HXTransfer::getRequestNameservers($params, $domain, $logindex);
            // load the current ones assigned
            $currentns = HXDomain::getNameservers($params, $domain);
            if ($currentns["success"] && $newns["success"]) {
                sort($currentns["nameservers"]);
                sort($newns["nameservers"]);
                if ($currentns !== $newns && !empty($newns["nameservers"])) {
                    Ispapi::call([
                        "COMMAND" => "ModifyDomain",
                        "DOMAIN" => $domain,
                        "NAMESERVER" => $newns["nameservers"],
                        "INTERNALDNS" => (int)$params["dnsmanagement"]
                    ], $params);
                    logActivity($domain . ": Nameserver update requested.");
                }
            }
        }
        // TODO:---------- EXCEPTION [BEGIN] --------
        // Missing/Empty contact handles after Transfer over THIN Registry [kschwarz]
        // Ticket#: 2020041508019251 OTRS
        if (HXDomain::needsContactUpdate($params, $domain, $r)) {
            // load required registrant and admin data
            $d = HXDomain::getContactDetailsWHMCS($params["domainid"]);
            // --- AUTO-UPDATE PROCESSING
            // only run auto-update mechanism in case a non-empty email address is given
            // otherwise it would keep trying to update on each run
            if (!empty($d["registrant"]["EMAIL"])) {
                $rr = HXDomain::updateContactDetails($params, $domain, $d, $r);
                if (!is_null($rr)) {
                    logActivity($domain . ": Request Contact update " . ($rr["success"] ? "succeeded" : "failed"));
                }
            }
            //--------------- EXCEPTION [END] -----------
        }

        // activate internaldns / dns management if ordered with the transfer
        $dnsmanagement = (int)$params["dnsmanagement"];
        if ($dnsmanagement) {
            $r = Ispapi::call([
                "COMMAND" => "ModifyDomain",
                "DOMAIN" => $domain,
                "INTERNALDNS" => $dnsmanagement
            ], $params);
            if ($r["CODE"] === "200") {
                logActivity($domain . ": Activation of DNS Management requested.");
            } else {
                logActivity($domain . ": Activation of DNS Management failed.");
            }
        }

        $values = HXDomain::getExpiryData($params, $domain, false, $r);
        $values["completed"] = true;
        logActivity($domain . ": Domain Transfer finished. expirydate: " . $values["expirydate"]);
        return $values;
    }

    // in case neither domain nor transfer object are available in xirca
    // this is probably in progress atm or has failed

    // check for related failure entry
    $r = HXTransfer::getFailureLog($params, $domain, $logdate);
    if ($r["success"] && (int)$r["data"]["COUNT"][0] > 0) {
        $values = [
            "failed" => true,
            "reason" => "Transfer Failed"
        ];
        if (isset($r["data"]["LOGINDEX"])) {
            $r = HXTransfer::getLogDetails($params, $r["data"]["LOGINDEX"][0]);
            if ($r["success"] && isset($r["data"]["OPERATIONINFO"])) {
                $values["reason"] .= PHP_EOL . implode(PHP_EOL, $r["data"]["OPERATIONINFO"]);
            }
        }
        logActivity($domain_idn . ": Domain Transfer failed.");
        return $values;
    }

    logActivity($domain_idn . ": Domain Transfer is still pending.");
    return []; // still pending
}

/**
 * Sync Domain Status & Expiration Date
 *
 * Domain syncing is intended to ensure domain status and expiry date
 * changes made directly at the domain registrar are synced to WHMCS.
 * It is called periodically for a domain.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 *
 * @return array
 */
function ispapi_Sync($params)
{
    $domain = $params["sld"] . "." . $params["tld"];

    // .SWISS Applications Handling
    $domains = DB::table("tbldomains")
        ->select("id", "domain", "additionalnotes")
        ->where("registrar", "=", "ispapi")
        ->where("status", "=", "Pending Registration")
        ->where("domain", "like", "%.swiss")
        ->get();
    foreach ($domains as $d) {
        // just deal with last .swiss application received
        $regex = "/^\.SWISS ApplicationID: (\d+)(.+)?$/i";
        $apps = preg_grep($regex, array_reverse(explode("\n", $d->additionalnotes)));
        if (empty($apps)) {
            continue;
        }
        $app = array_shift($apps);
        preg_match($regex, $app, $appId);
        $rapp = HXApp::getStatus($params, $appId[1]);
        if ($rapp["success"] && $rapp["data"]["STATUS"][0] === "FAILED") {
            // do not return anything, not the domain context of the sync run
            logActivity($domain . ": Domain Sync finished. Application failed. Status updated to `Cancelled`");
            DB::table("tbldomains")->where([
                ["id", "=", $d->id]
            ])
                ->update(["status" => "Cancelled"]);
        } elseif ($rapp["success"] && $rapp["data"]["STATUS"][0] === "SUCCESSFUL") {
            // do not return anything, not the domain context of the sync run
            // Successful Applications will be auto-cleaned up, StatusDomain will follow
            logActivity($domain . ": Domain Sync finished. Application succeeded. Status updated to `Active`");
            DB::table("tbldomains")
                ->where([
                    ["id", "=", $d->id]
                ])
                ->update(["status" => "Active"]);
        } elseif (!$rapp["success"] && $rapp["errorcode"] === "545") {
            // do not return anything, not the domain context of the sync run
            $r = HXDomain::getStatus($params, $d->domain);
            if ($r["success"]) {
                DB::table("tbldomains")
                    ->where([
                        ["id", "=", $d->id]
                    ])
                    ->update(["status" => "Active"]);
            }
        }
    }

    $r = HXDomain::getStatus($params, $domain);
    if (!$r["success"] && $r["errorcode"] === "531") {
        logActivity($domain . ": Domain Sync finished. Status updated to `Transferred Away`");
        return [
            "transferredAway" => true
        ];
    }
    if (!$r["success"] && $r["errorcode"] === "545") {
        if (HXDomain::isResigned($params, $domain)) {
            logActivity($domain . ": Domain Sync finished. Probably renewed at DKH. Status updated to `Transferred Away`");
            return [
                "transferredAway" => true
            ];
        }
        if (HXTransfer::isTransferredAway($params, $domain)) {
            logActivity($domain . ": Domain Sync finished. Status updated to `Transferred Away`");
            return [
                "transferredAway" => true
            ];
        }

        $r2 = HXApp::getStatus($params, $domain);
        if ($r2["success"] && !empty($r2["data"]["STATUS"][0])) {
            $values = ["active" => true]; // pending cast from app to domain or pending order
            switch ($r2["data"]["STATUS"][0]) {
                case "FAILED":
                    logActivity($domain . ": Premium Domain Order failed.");
                    $values = [
                        "error" => "Premium Domain Order failed."
                    ];
                    break;
                case "ACTIVE":
                case "SUCCESSFUL":
                    logActivity($domain . ": Premium Domain Order succeeded. Waiting for completion.");
                    break;
                default:
                    logActivity($domain . ": Premium Domain Order is pending.");
                    break;
            }
            return $values;
        }

        $values = HXDomain::getExpiryData($params, $domain, true);
        logActivity($domain . ": Domain Sync finished. Updated expirydate: " . $values["expirydate"]);
        if ($values["expired"] && $params["SUSPENDONEXPIRATION"] === "on") {
            ispapi_suspend($params, true);
        }
        return $values;
    }
    if (!$r["success"]) {
        logActivity($domain . ": Domain Sync failed. See Module Log.");
        return $r;
    }

    //activate the whoistrustee if set to 1 in WHMCS
    //Trade doesn't support idprotection flag yet
    if ($params["idprotection"] && empty($r["data"]["X-ACCEPT-WHOISTRUSTEE-TAC"][0])) { // doesn't exist, "" or 0
        HXDomain::saveIdProtection($params, $domain, true);
    }

    // NON-Premium AFTERMARKET DOMAINS
    if ($params["premiumEnabled"]) {
        $is_premium = DB::table("tbldomains")
            ->where("id", "=", $params["domainid"])
            ->value("is_premium");
        if (
            $is_premium === 1
            && !(bool)preg_match("/^PREMIUM_/", $r["data"]["CLASS"])
        ) {
            DB::table("tbldomains")
                ->where("id", "=", $params["domainid"])
                ->update([
                    "is_premium" => 0
                ]);
        }
        // TODO - here we could add sync of non-premium to premium upgrade as well
    }

    //expirydate
    $values = HXDomain::getExpiryData($params, $domain, false, $r);
    logActivity($domain . ": Domain Sync finished. Updated expirydate: " . $values["expirydate"]);
    if ($values["expired"] && $params["SUSPENDONEXPIRATION"] === "on") {
        ispapi_suspend($params, true);
    }
    return $values;
}

/**
 * Return TLD & Pricing for sync (WHMCS 7.10)
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 *
 * @return \WHMCS\Results\ResultsList
 */
function ispapi_getTLDPricing($params)
{
    // fetch list of tlds offerable by reseller
    $tlds = WHMCS\Module\Registrar\Ispapi\Ispapi::getTLDs($params);
    if (isset($tlds["error"])) {
        return $tlds;
    }
    if (empty($tlds)) {
        return new \WHMCS\Results\ResultsList();
    }

    // fetch tld configurations for offerable tlds
    $domains = [];
    foreach (array_keys($tlds) as $tld) {
        $domains[] = "example" . $tld;
    }
    $zis = HXDomain::getZoneInformations($params, $domains);

    // fetch prices for offerable tlds
    $prices = WHMCS\Module\Registrar\Ispapi\Ispapi::getTLDPrices(array_flip($tlds), $zis);
    if (isset($prices["error"])) {
        return $prices;
    }

    $idprotections = [];
    //$debugPeriodIssues = [];

    //$tmp = "";
    $results = new \WHMCS\Results\ResultsList();
    foreach ($prices as $tld => $p) {
        $zi = $zis[$tld];
        if (is_null($zi)) {
            continue;
        }
        if ($zi->addons->idprotection) {
            $idprotections[] = $tld;
        }
        if (is_null($p["registration"])) {
            // there are of course TLDs in management which we no longer offer for registration in public
            // WHMCS doesn't offer the possibility to import registerPrice as null, therefore leaving out
            // 2022-05: no match
            // logActivity($tld . ": no reg price");
            continue;
        }
        if (empty($zi->registration->periods)) {
            throw new \Exception("Missing entry for $tld. Contact support, we will release a new version immediately.");
        }

        /*$p1 = $zi->registration->periods;
        $p2 = $zi->renewal->periods;
        $dbgRow = [
            "registration" => $p1,
            "renewal" => $p2,
            "unsupportedRenewalTerms" => array_values(array_diff($p1, $p2)), // all elements of p1 not in p2
            "missingRenewalTerms" => array_values(array_diff($p2, $p1)) // all elements of p2 not in p1
        ];
        $flag1 = empty($dbgRow["unsupportedRenewalTerms"]);
        $flag2 = empty($dbgRow["missingRenewalTerms"]);
        if (
            (!(
                !$flag1
                // 10y reg only -> whmcs keeps 10y for renewal otherwise not
                && count($dbgRow["registration"])>1
                && count($dbgRow["unsupportedRenewalTerms"]) === 1
                && in_array(10, $dbgRow["unsupportedRenewalTerms"])
            ) && !$flag1)
            || !$flag2
        ) {
            $debugPeriodIssues[$tld] = $dbgRow;
        }*/
        // WHMCS is auto-deactivating 10Y renewals
        // 2022-05: plenty of tlds having reg terms that are not supported for renewal

        // All the set methods can be chained and utilised together.
        $item = new \WHMCS\Domain\TopLevel\ImportItem();
        $item->setExtension($tld)
            ->setYears($zi->registration->periods) // 1st one is the minimum period also used for transfers
            ->setRegisterPrice($p["registration"])
            ->setRenewPrice($p["renewal"])
            ->setTransferPrice($p["transfer"])
            ->setGraceFeeDays($zi->renewal->graceDays)
            ->setGraceFeePrice($p["grace"])
            ->setRedemptionFeeDays($zi->redemption->days)
            ->setRedemptionFeePrice($p["redemption"])
            ->setCurrency($p["currency"])
            ->setEppRequired($zi->transfer->requiresAuthCode);
        $results[] = $item;
        /*$r = Ispapi::call([ // TODO -> $zi rewrite
            "COMMAND" => "QueryDomainOptions",
            "DOMAIN" => "example" . $tld
        ], $params);
        if ($r["PROPERTY"]["REGISTRYEXPLICITRENEWAL"][0] === "NO"){
            $pp = -1 * (int)$r["PROPERTY"]["ZONERENEWALPAYMENTPERIOD"][0];//-> RSRTPM-3834
            $tmp .= "\$DomainRenewalMinimums[\"" . $tld . "\"] = \"" . $pp . "\";\n";
        }*/
    }

    //throw new Exception(json_encode($debugPeriodIssues, JSON_PRETTY_PRINT));

    // update id protection (missing feature in registrar tld sync)
    if (
        ($params["SYNCIDPROTECTION"] === "on") &&
        !empty($idprotections)
    ) {
        // disable id protection for all our TLDs
        DB::table("tbldomainpricing")
            ->where("autoreg", "ispapi")
            ->whereNotIn("extension", $idprotections)
            ->update(["idprotection" => 0]);
        // enable id protection for all our TLDs supporting it
        DB::table("tbldomainpricing")
            ->where("autoreg", "ispapi")
            ->whereIn("extension", $idprotections)
            ->update(["idprotection" => 1]);
    }

    //mail("kschwarz@hexonet.net", "tlds", $tmp);
    return $results;
}

/**
 * Return Zone Configuration / Feature data
 * @param array $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return object|null
 */
function ispapi_GetZoneFeatures($params)
{
    return HXDomain::getZoneInformation(
        $params,
        $params["sld"] . "." . $params["tld"]
    );
}

/**
 * Return Additional Domain Fields per extension and order type
 *
 * @param array $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return array
 */
function ispapi_AdditionalDomainFields($params)
{
    if (isset($params["original"])) {
        $params = $params["original"];
    }
    // load and return our additional domain fields configuration
    AF::init($params["TestMode"] === "on");
    $fields = AF::getAdditionalDomainFields($params);
    // var_dump($fields);
    return $fields;
}

/**
 * Returns customer account details such as amount, currency, deposit etc.
 *
 * @return array<string, string>
 */
function ispapi_getAccountDetails()
{
    $r = Ispapi::call(["COMMAND" => "StatusAccount"]);
    $quota = Ispapi::call(["COMMAND" => "QueryServiceUsage", "USERDEPTH" => "SELF", "WIDE" => "1"]);

    if ((int)$r["CODE"] !== 200 && (int)$quota['CODE'] !== 200) {
        return [
            "success" => false
        ];
    }

    return [
        "success" => true,
        "amount" => $r["PROPERTY"]["AMOUNT"][0],
        "deposit" => $r["PROPERTY"]["DEPOSIT"][0],
        "currency" => $r["PROPERTY"]["CURRENCY"][0],
        "total_query_quota" => $quota["PROPERTY"]["SYSTEM_HARD"][0],
        "current_quota_usage" => $quota["PROPERTY"]["CURRENT"][0]
    ];
}
