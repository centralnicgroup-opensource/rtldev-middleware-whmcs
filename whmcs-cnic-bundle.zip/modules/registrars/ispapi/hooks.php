<?php

use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\Helper;
use WHMCS\Module\Registrar\Ispapi\Domain as HXDomain;
use WHMCS\Module\Registrar\Ispapi\DomainTransfer as HXDomainTransfer;
use WHMCS\Module\Registrar\Ispapi\AdditionalFields as AF;
use WHMCS\Module\Registrar\Ispapi\DomainTrade as HXTrade;
use WHMCS\Module\Registrar\Ispapi\Lang as L;
use Illuminate\Database\Capsule\Manager as DB;

$path = implode(DIRECTORY_SEPARATOR, [__DIR__, "hooks_migration.php"]);
if (file_exists($path)) {
    include $path;
}

// add widget output
add_hook("AdminHomeWidgets", 1, function () {

    require_once(ROOTDIR . '/resources/cnic/vendor/autoload.php');
    require_once __DIR__ . '/ispapi.php';

    return new CNIC\Widgets\CnicWidget("ispapi", "HEXONET Dashboard Widget", "HexonetDashWidget", "https://github.com/centralnicgroup-opensource/rtldev-middleware-whmcs");
});

/**
 * Subscription to ShoppingCartValidateCheckout Hook
 * Transfer Pre-Checking feature
 */
add_hook("ShoppingCartValidateCheckout", 1, function ($vars) {
    // load registrar functions
    if (!function_exists("getregistrarconfigoptions")) {
        include implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "registrarfunctions.php"]);
    }

    // error container
    $errors = [];

    // load registrar module settings and check if transfer precheck are activated
    $regcfg = getregistrarconfigoptions("ispapi");
    $cartprecheck = ($regcfg["TRANSFERCARTPRECHECK"] === "on");
    if (!$cartprecheck || empty($_SESSION["cart"]["domains"])) {
        return $errors;
    }

    // precheck all transfers
    foreach ($_SESSION["cart"]["domains"] as $d) {
        if ($d["type"] === "transfer") {
            $tld = preg_replace("/^[^.]+\./", "", $d["domain"]);
            // check if the registrar configured for that tld is `ispapi`
            $count = DB::table("tbldomainpricing")
                ->select("autoreg")
                ->where("extension", "." . $tld)
                ->where("autoreg", "ispapi")
                ->count();
            if (!$count) {
                continue;
            }
            $cmd = [
                "COMMAND" => "CheckDomainTransfer",
                "DOMAIN" => $d["domain"]
            ];
            if (!empty($d["eppcode"])) {
                $cmd["AUTH"] = html_entity_decode($d["eppcode"]);
            }
            $r = Ispapi::call($cmd);
            if ($r["CODE"] === "219") {
                $errors[] = $d["domain"] . ": " . $r["DESCRIPTION"];
            }
        }
    }
    return $errors;
});

add_hook("AdminClientDomainsTabFields", 1, function ($vars) {
    $domain = new \WHMCS\Domains();
    $params = $domain->getDomainsDatabyID($vars["id"]);
    $registrar = new WHMCS\Module\Registrar();
    if (
        $params["registrar"] !== "ispapi"
        || !$registrar->load($params["registrar"])
    ) {
        return [];
    }
    // merge registrar settings and domain data
    $params = array_merge($params, $registrar->getSettings());

    if (
        $params["type"] === "Transfer"
        && $params["status"] === "Pending Transfer"
    ) {
        //check for pending request - should be existing
        $r = HXDomainTransfer::getStatus($params, $params["domain"]);
        if ($r["success"]) {
            return [
                "Transfer Status" => "PENDING",
                "Transfer Log" => "<pre style=\"white-space:break-spaces;\">" . implode(PHP_EOL, $r["data"]["TRANSFERLOG"]) . "</pre>"
            ];
        }

        // get date of last transfer request
        $r = HXDomainTransfer::getRequestLog($params, $params["domain"]);
        if (
            $r["success"] === false
            || $r["data"]["COUNT"][0] === "0"
        ) {
            return [
                "Transfer Status" => "UNKNOWN",
                "Transfer Log" => "No Transfer Logs found."
            ];
        }

        // last transfer request's date
        $logdate = $r["data"]["LOGDATE"][0]; // 2019-11-15 12:25:05
        $reason = <<<HTML
            <table>
                <tr>
                    <td>Request Date:</td>
                    <td>{$logdate}</td>
                </tr>
HTML;

        // check for related failure entry
        $r = HXDomainTransfer::getFailureLog($params, $params["domain"], $logdate);
        if (
            $r["success"]
            && (int)$r["data"]["COUNT"][0] > 0
        ) {
            if (isset($r["data"]["LOGINDEX"])) {
                $logdate = $r["data"]["LOGDATE"][0];
                $reason .= <<<HTML
                    <tr>
                        <td>Failed on:</td><td>{$logdate}</td>
                    </tr>
                    </table>
HTML;
                $r = HXDomainTransfer::getLogDetails($params, $r["data"]["LOGINDEX"][0]);
                if (
                    $r["success"]
                    && isset($r["data"]["OPERATIONINFO"])
                ) {
                    $reason .=  "<pre style=\"white-space:break-spaces;\">" . implode(PHP_EOL, $r["data"]["OPERATIONINFO"]) . "</pre>";
                }
            }
            return [
                "Transfer Status" => "FAILED",
                "Transfer Log" => $reason
            ];
        }

        // check for related failure entry
        $r = HXDomainTransfer::getSuccessLog($params, $params["domain"], $logdate);
        if (
            $r["success"]
            && (int)$r["data"]["COUNT"][0] > 0
        ) {
            if (isset($r["data"]["LOGINDEX"])) {
                $logdate = $r["data"]["LOGDATE"][0];
                $reason .= <<<HTML
                    <tr>
                        <td>Succeeded on:</td><td>{$logdate}</td>
                    </tr>
                    </table>
HTML;
                $r = HXDomainTransfer::getLogDetails($params, $r["data"]["LOGINDEX"][0]);
                if (
                    $r["success"]
                    && isset($r["data"]["OPERATIONINFO"])
                ) {
                    $reason .=  "<pre style=\"white-space:break-spaces;\">" . implode(PHP_EOL, $r["data"]["OPERATIONINFO"]) . "</pre>";
                }
            }
            return [
                "Transfer Status" => "SUCCEEDED",
                "Transfer Log" => $reason
            ];
        }

        return [
            "Transfer Status" => "REQUESTED",
            "Transfer Log" => $reason . "</table>"
        ];
    }

    $customfields = [];

    // Active Domain Names
    if (
        $params["status"] === "Active"
        && $params["WHOISERRPSETTINGS"] === "on"
    ) {
        $values = [
            "WHOIS" => [],
            "ERRP" => []
        ];
        $hasERRP = false;

        // ERRP Settings domain-level Data
        $response = HXDomain::getStatus($params, $params["domain"]);
        if ($response["success"]  && isset($response["data"]["PROPERTY"])) {
            $defaultMsg = "<u>Your global settings are currently used, if set</u>. Otherwise our system defaults. Use the below fields to make domain-specific settings.";
            $keys = array_keys($response["data"]["PROPERTY"]);
            $defaultErrpHTML = "";
            if (!empty(preg_grep("/^X-ERRP-/i", $keys))) {
                $values["ERRP"] = $response["data"];
                $hasERRP = true;
            } else {
                $repoInfo = Ispapi::call([
                    "COMMAND" => "QueryDomainRepositoryInfo",
                    "DOMAIN" => $params["domain"]
                ]);
                if (
                    ($repoInfo["CODE"] === "200")
                    &&  ( // at least one matching
                        !empty(array_intersect(
                            ["gTLD", "nTLD", "brandTLD"],
                            $repoInfo["PROPERTY"]["CATEGORY"]
                        ))
                    )
                ) {
                    $hasERRP = true;
                    $defaultErrpHTML = $defaultMsg;
                };
            }
            // WHOIS Output Settings domain-level Data
            $defaultWhoisHTML = "";
            if (!empty(preg_grep("/^X-WHOIS-/i", $keys))) {
                $values["WHOIS"] = $response["data"];
            } else {
                $defaultWhoisHTML = $defaultMsg;
            }
        }
        $customfields = [
            "<b>Custom WHOIS Output Settings</b>" => ("Resellers may customize a domain's WHOIS result by filling in the following field(s). Note that this is only possible for certain domain types.<br/>" .
                "NOTE: These are domain-level custom settings. You can configure global settings in our registrar's <a style=\"text-decoration:underline;\" href=\"https://account.hexonet.net\" target=\"_blank\">frontend</a> (Reseller Settings > Domain Settings).<br/>" .
                $defaultWhoisHTML
            ),
            "Reseller Service Provider Name" => "<input type=\"text\" name=\"X-WHOIS-RSP\" value=\"" . htmlspecialchars($values["WHOIS"]["X-WHOIS-RSP"]) . "\" class=\"form-control input-300\">",
            "Reseller Service Provider URL" => "<input type=\"text\" name=\"X-WHOIS-URL\" value=\"" . htmlspecialchars($values["WHOIS"]["X-WHOIS-URL"]) . "\" class=\"form-control input-300\">",
            "Banner Line 1" => "<input type=\"text\" name=\"X-WHOIS-BANNER0\" value=\"" . htmlspecialchars($values["WHOIS"]["X-WHOIS-BANNER0"]) . "\" class=\"form-control input-300\">",
            "Banner Line 2" => "<input type=\"text\" name=\"X-WHOIS-BANNER1\" value=\"" . htmlspecialchars($values["WHOIS"]["X-WHOIS-BANNER1"]) . "\" class=\"form-control input-300\">",
            "Banner Line 3" => "<input type=\"text\" name=\"X-WHOIS-BANNER2\" value=\"" . htmlspecialchars($values["WHOIS"]["X-WHOIS-BANNER2"]) . "\" class=\"form-control input-300\">",
        ];
        // check if errp settings possible for this domain
        if ($hasERRP) {
            $customfields += [
                "<b>Custom ERRP Settings</b>" => ("In accordance with the Expired Registration Recovery Policy (ERRP), prior to the expiration of any gTLD registration, the sponsoring registrar must notify the registered name holder of the expiration at least two times. These notices may be customized with the following parameter(s).<br/>" .
                    "NOTE: These are domain-level custom settings. You can configure global settings in our registrar's <a style=\"text-decoration:underline;\" href=\"https://account.hexonet.net\" target=\"_blank\">frontend</a> (Reseller Settings > Domain Settings).<br/>" .
                    $defaultErrpHTML
                ),
                "Company Name" => "<input type=\"text\" name=\"X-ERRP-RSP\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-RSP"]) . "\" class=\"form-control input-300\">",
                "Support Phone Number" => "<input type=\"text\" name=\"X-ERRP-PHONE\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-PHONE"]) . "\" class=\"form-control input-300\">",
                "Support Email Address" => "<input type=\"text\" name=\"X-ERRP-EMAIL\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-EMAIL"]) . "\" class=\"form-control input-300\">",
                "Terms And Conditions URL" => "<input type=\"text\" name=\"X-ERRP-TAC-URL\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-TAC-URL"]) . "\" class=\"form-control input-300\">",
                "Renewal Website URL" => "<input type=\"text\" name=\"X-ERRP-URL\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-URL"]) . "\" class=\"form-control input-300\">",
                "Footer 1" => "<input type=\"text\" name=\"X-ERRP-SIGNATURE0\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-SIGNATURE0"]) . "\" class=\"form-control input-300\">",
                "Footer 2" => "<input type=\"text\" name=\"X-ERRP-SIGNATURE1\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-SIGNATURE1"]) . "\" class=\"form-control input-300\">",
                "Footer 3" => "<input type=\"text\" name=\"X-ERRP-SIGNATURE2\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-SIGNATURE2"]) . "\" class=\"form-control input-300\">",
                "Footer 4" => "<input type=\"text\" name=\"X-ERRP-SIGNATURE3\" value=\"" . htmlspecialchars($values["ERRP"]["X-ERRP-SIGNATURE3"]) . "\" class=\"form-control input-300\">"
            ];
        }
    }
    if (!empty($customfields)) {
        $customfields = (["" => "<br/><big><b>HEXONET custom domain-level Settings</b></big>"]
            + $customfields
            + [" " => "<br/>"]
        );
    }

    return $customfields;
});

//Obtain the values defined in the AdminClientProfileTabFields hook point and save them as required
add_hook("AdminClientDomainsTabFieldsSave", 1, function ($vars) {
    $registrar = new WHMCS\Module\Registrar();
    if (
        $vars["registrar"] !== "ispapi"
        || $vars["status"] !== "Active"
        || !$registrar->load($vars["registrar"])
    ) {
        return;
    }
    $params = $registrar->getSettings();
    // check if ERRP / WHOIS settings are active
    if ($params["WHOISERRPSETTINGS"] !== "on") {
        return;
    }
    // check if ERRP / WHOIS settings have been posted
    $command = [
        "COMMAND" => "ModifyDomain",
        "DOMAIN" => $vars["domain"]
    ];
    foreach ($_POST as $key => $val) {
        if (preg_match("/^X-(WHOIS|ERRP)-([A-Z0-9]+-?)+$/i", $key)) {
            $command[$key] = \App::getFromRequest($key);
        }
    }
    //Save WHOIS Output Settings via domain update
    $r = Ispapi::call($command, $params);
    if ($r["CODE"] === "200") {
        logActivity($vars["domain"] . ": Saving WHOIS Output / ERRP Settings succeeded.");
    } else {
        logActivity($vars["domain"] . ": Saving WHOIS Output / ERRP Settings failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")");
    }
});

add_hook("AdminAreaHeadOutput", 1, function ($vars) {
    if (basename($_SERVER["SCRIPT_NAME"]) !== "clientsdomaincontacts.php") {
        return "";
    }
    $domainid = (int)App::getFromRequest("domainid");
    $domain = json_decode(
        json_encode(
            DB::table("tbldomains")
                ->select("domain", "registrar")
                ->where("id", $domainid)
                ->first()
        ),
        true
    );
    if ($domain["registrar"] !== "ispapi") {
        return "";
    }
    // load registrar functions
    if (!function_exists("getregistrarconfigoptions")) {
        include implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "registrarfunctions.php"]);
    }
    // load registrar module settings and check if transfer precheck are activated
    $params = getregistrarconfigoptions("ispapi");

    $zi = HXDomain::getZoneInformation($params, $domain["domain"]);
    $showTradeInfo = 0;
    $tradeInfo = "";
    if (!is_null($zi) && $zi->trade->required) {
        $status = HXTrade::getStatus($params, $domain["domain"]);
        // Standard Trade and IRTP with no DA Authorization -> non-realtime
        $showTradeInfo = ($zi->trade->isStandard
            || (bool)preg_match("/Designated Agent/", $params["IRTP"])
        ) ? 1 : 0;
        $tradeInfo = (L::trans("hxdomaincontactstradeinfo") .
            (($status["success"] === true) ? "<br/><b>Trade</b>: " . L::trans("domainsPending") : "")
        );
    }

    $addflds = new AF($params["TestMode"] === "on");
    $addflds->setDomainType((!is_null($zi) && $zi->trade->required) ? "trade" : "update")
        ->setDomain($domain["domain"])
        ->getFieldValuesFromDatabase($domainid);
    $fields = $addflds->getFieldsForOutput();
    if (!empty($fields)) {
        $html .= <<<HTML
        <script type="text/javascript">
            const ispapi_show_tradeInfo = $showTradeInfo;
            const ispapi_tradeInfo = ' $tradeInfo';
            const ispapi_fields_html = '$fields';
            let form;
            $(document).ready(function(){
                form = $('form[action="/admin/clientsdomaincontacts.php?domainid=$domainid&action=save"]');
                if (ispapi_show_tradeInfo) {
                    const selector = 'table.form:first tbody tr:last';
                    form.find(selector).clone().insertAfter(selector);
                    form.find(selector + ' td').first().html('');
                    form.find(selector + ' td').last().html(ispapi_tradeInfo);
                }
                form.children().last().before(ispapi_fields_html);
            })
        </script>
HTML;
    }
    return $html;
});

add_hook("ClientAreaHeadOutput", 1, function ($vars) {
    $domain = Menu::context("domain");
    if (!$domain || $domain->registrar !== "ispapi") {
        return "";
    }

    $html = <<<HTML
    <style>
        img.webappthumb {
            width: 115px;
            padding: 4px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
HTML;

    // ---------------------------------------
    // Inject Private NS List into private NS Page
    // ---------------------------------------
    if (isset($_REQUEST["action"]) && $_REQUEST["action"] === "domainregisterns") {
        // load registrar functions
        if (!function_exists("getregistrarconfigoptions")) {
            include implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "registrarfunctions.php"]);
        }
        // load registrar module settings
        $params = getregistrarconfigoptions("ispapi");

        $r = HXDomain::getStatus($params, $domain->domain, true);
        if ($r["success"] && !empty($r["data"]["HOST"])) {
            $col1 = L::trans("domainregisternsns");
            $col2 = L::trans("domainregisternsip");
            $table = "<table class=\"table table-bordered table-striped\"><thead><tr><th>$col1</th><th>$col2</th></tr></thead><tbody>";
            foreach ($r["data"]["HOST"] as $host) {
                list($hname, $ip) = explode(" ", $host);
                $table .= "<tr><td>$hname</li></td><td>$ip</td></tr> ";
            }
            $table .= "</tbody></table>";
            $html .= <<<HTML
                <script type="text/javascript">
                    const ispapi_pns_html = '$table';
                    $(document).ready(function(){
                        const form = $('form[action="/clientarea.php?action=domainregisterns"]').first();
                        form.before(ispapi_pns_html);
                    })
                </script>
HTML;
            return $html;
        }
    }
    // ---------------------------------------
    // Inject Fields into Contact Details Page
    // ---------------------------------------
    if (isset($_REQUEST["action"]) && $_REQUEST["action"] === "domaincontacts") {
        // load registrar functions
        if (!function_exists("getregistrarconfigoptions")) {
            include implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "registrarfunctions.php"]);
        }
        // load registrar module settings
        $params = getregistrarconfigoptions("ispapi");

        $zi = HXDomain::getZoneInformation($params, $domain->domain);
        $showTradeInfo = 0;
        $tradeInfo = "";
        if (!is_null($zi) && $zi->trade->required) {
            $status = HXTrade::getStatus($params, $domain->domain);
            // Standard Trade and IRTP with no DA Authorization -> non-realtime
            $showTradeInfo = ($zi->trade->isStandard
                || (bool)preg_match("/Designated Agent/", $params["IRTP"])
            ) ? 1 : 0;
            $tradeInfo = (L::trans("hxdomaincontactstradeinfo") .
                (($status["success"] === true) ? "<br/><br/><b>Trade</b>: " . L::trans("domainsPending") : "")
            );
        }

        $addflds = new AF($params["TestMode"] === "on");
        $addflds->setDomainType((!is_null($zi) && $zi->trade->required) ? "trade" : "update")
            ->setDomain($domain->domain)
            ->getFieldValuesFromDatabase($domain->id);
        $fields = $addflds->getFieldsForOutput();
        if (!empty($fields)) {
            $html .= <<<HTML
            <script type="text/javascript">
                const ispapi_show_tradeInfo = $showTradeInfo;
                const ispapi_tradeInfo = ' $tradeInfo';
                const ispapi_fields_html = '$fields';
                $(document).ready(function(){
                    const form = $('form[action="/clientarea.php?action=domaincontacts"]');
                    if (ispapi_show_tradeInfo) {
                        form.parent().find('h3').next().append(ispapi_tradeInfo);
                    }
                    form.children().last().before(ispapi_fields_html);
                })
            </script>
HTML;
            return $html;
        }
    }
    return $html;
});

/**
 * Automatically precheck addons on cart page
 */
add_hook("ClientAreaHeadOutput", 1, function ($vars) {
    require_once(ROOTDIR . '/resources/cnic/vendor/autoload.php');
    $vars['registrar'] = 'ispapi';
    return cnic_precheckAddons($vars);
});

/**
 * Gather and submit Module Statistics
 * to improve support
 */
add_hook("AfterCronJob", 1, function ($vars) {
    Ispapi::sendStatisticsData();
});

/**
 *  Remove Menu Entry "Registrar Lock Status"
 *  if not supported by TLD
 */
function ispapi_domainMenuUpdate($vars)
{
    // TLDs not supporting Transfer Lock: remove "Registrar Lock" menu entry.
    $domain = Menu::context("domain");
    $menu = $vars["primarySidebar"]->getChild("Domain Details Management");
    if (
        !is_null($menu)
        && $domain->registrar === "ispapi"
    ) {
        if (!function_exists("getregistrarconfigoptions")) {
            require_once implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "registrarfunctions.php"]);
        }
        $r = HXDomain::getRegistrarLock(
            getregistrarconfigoptions($domain->registrar),
            $domain->domain
        );
        if (isset($r["error"])) {
            $vars["managementoptions"]["locking"] = false;
            $vars["lockstatus"] = false;
            $menu->removeChild("Registrar Lock Status");
        }
    }
    return $vars;
}

add_hook("ClientAreaPageDomainDNSManagement", 1, 'ispapi_domainMenuUpdate');
add_hook("ClientAreaPageDomainEPPCode", 1, 'ispapi_domainMenuUpdate');
add_hook("ClientAreaPageDomainContacts", 1, 'ispapi_domainMenuUpdate');
add_hook("ClientAreaPageDomainRegisterNameservers", 1, 'ispapi_domainMenuUpdate');
add_hook("ClientAreaPageDomainDetails", 1, 'ispapi_domainMenuUpdate');
