<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn2sSW/2dKSXcm7dB4C8tLkefrNk1nSx5wsuUTNHRhw54wVAh+hZls4ldUJS3bXYgqxR3L5y
CTLMDYJ4mtt2DAfX+lxWqCx7fkdmINQ/lvAjbyFKJb2tailibxAfLX/5rea7Csp4WRdXRGNx67+g
0hq8hgQfarNJPrqpudfT8zR6qOa/MxDABRsMRyjsPqGrlmf8AwkNfua2djG5Y8/5R4tZXhxcGXbN
0nLyRhriK6421tbtPQQyeTenAlcQQCsbzBkUHCJbVPVNPnWIKKGpvUxVHkPhyx2IigOHCxZyPK7j
78Sb9xgOcRURnBX+UVkYaArdUylloSKYeptZD/pezWnRALYfPIoY02mxU8LD5Lck/ktlqp0AaEgl
gTAineXP8WB4iLBZOt1DPMNLELr8fNJ9Eana/6Xr/B+eWd4160KRCAz6KxCD6r4MtG8dTK0HEQmw
QSMcfpuMc3jCp6cNetpYQMNhqN507vLs6rUGsg3pV5KBo2CZhGMjYL4XexcdQAsHrCxo6Ij4Dp8B
aG6D5m+GMkAItLyGtoZPDcIy3JJZFldxV//zQUFNa5WByL5suhGe1zqubCGWLJwhRiY+xLtmyFsR
hqabBuCSaUTIt9qF/w4uGrd4FMUYdXZ+1zZ1PWTJJpUpFNdUvDh0w7achgzVxTL+YKbV6lX+1b2i
ij/ZgLQHow/Rdo6KpMTuphVTk8geSJEP/GLuQGq3Eedk6XdhMbi0aOTJKmajFL1wVXh7CkKHqSjW
r7qbzBLLkgiFzHW3f6Yi/fb4+uQtsSxnZfz+Spzg+PLKmR0fpmMiR252bpUZXslbFzwJoXAS3+Nr
sF4IRBx/vCEoPoob7Lr/bs7/YXTIbvzMW17oSu5gRb6skPROaFa=