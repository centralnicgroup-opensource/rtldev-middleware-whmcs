<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnrxnjlAnZeSaynJ+29cVEEHwKdG5aU6MVyFKkGaiGobdbMrXTTA5umNZAWB3acI4J84pIaS
y9/qZnNGdtEhr+ZB+BwndKpT5ZQBTGROfjXd3taKJ91LqgzlOabxmi0PHHZ5r7fbWTH64xlCeOoR
LpQglAYVV+qZyTbdLgjPEr1B7fnmli6m4m6y2IAOD0tWPhWxoE1pABklaMN1c6i6SUbNTyUz3Qri
z4CjPn4raVao3fOfris8ddLGiG2zH9NCRLANRrvFMPjqCGkUvHnKLh5W6R7nPQOGK08zB02AhU7M
1bZc6YC5peEQ1aR3TyKQcEJsN3Nl8rgzXwL5QR3zcEFElbjOiiAHxPhH8zlccg/UROJ2hYH5g5SL
H3y+CvTShp8mU+Ln49/ZX+l/0WCtS+YEy4X+Q5eAPXW9m0VhI71qZYSZ1HtHNpjEcqobnTQYSb/E
3/t2gSz8yWT5qt4sSjs0/uZSnV2b0AceGI0Pc5qKhk2jA2W6JJXa9MQiEV293oiU2Tu3dsGPRZyb
isLe0xY/OJ0zkAMjfiNi9LF3lorUOhv5kitweOgGvMRgV3jj29vouvwDfeyjIzuMpTW71kzUiGAV
0Wwz5GpQyYPBgJN7VVqzibLDmpSpfZ/bFJiGrcXPUrQ0ZNWF2OGMGHFRgMNPQe+CDfKaMNSJXEWz
hBJfk/ICXE94VV+uyvwt1HeUuWyGRrZkin0rMokyoztaDlCB5ACj026jg9iJ8bz5Y2EG5EhbvL9p
u6dg42tsrIcvHZi4k0o9aJlkvcEddLcm8VgMQyuhq5ACCHYKxp7GJ5gFDQfWtVo+falwlSWxOduf
ETNs0rbV4QDYwXThq9SWitiCV+gg3NFtauO7JQlqo/c/