<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp965+ZIhUlFg/62omuPDeKWPI8KlXVAPhwuwo8+2ds9yqHor4Swcn5+2a2kLwqA7uz457A6
b8TeVZ1jM/1fvU7op17lwFyS/L50QnV8wf342UMYqByh/xMxDnoAu84FjUaVdSchGLm1jwXg/0xp
wJ1Li1mVB55L9GkEZiFvuhI3cniu/aveInUdZtik0CkxaZEcr4uhY/99T5JbeI/QZjET5UHrm2nk
GxhdNwDgZV9VlHlsJqzHNRtD6RFopAsQOfo/hLmNTQBmEO+CXpAnqZy6G5nf1iOUtQ0Pu7W2aix7
aQSI/pcDE2bngvHSoQF+1F3eeaGJvTrH+QGRyBT7BMlO36oGTc7nJd75QF8p3gmtGGHaz0UYtQRi
nKr+XcU0cAoEwoHPazjg2EMVNM2JxyEujtV7LF+eOYFLVDHuWsPXNevYh5IwOF0WeWu84EgMw+/9
XP2NNZqcnCejgR7JLdbMGBJ4VcnvgYlvJVcDwt1rza7eHKjSPDeDIpBIPuhWBuNt3LFeMtahUH7m
gA/gSZcir2/TgmHl0hwNON2lU3I+/t/YB98xZplFHf70ATJmgaVbr0usDpdA/fJnsXrH89tang30
zTFKWFQgoIp1Sw5ZR42al/wgWHgo4pA5NKeC8UwHGbMTa9L8RGdi38ET3q1HEU0HbKAEx9ahYJBh
hOQSXHUKINDlQ9dXRvJd+9MZKROCj71yGULdECfX1aFbv3C7X6PP/9F7QqC/+fRamvxqcLOhWSPx
eZVjdsJ0/c9CWVmv7XWXneLx5k6hUi+TYaCT8/7HuBvIzCuJkxwBznYX7GxTrgorh/xB4mgxmw9Y
pyq3ggRoY0Z2U3jxPQLqfBpt8xUxsWTV