<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmwRiyl6PWZidomcwFBSUBuJSnTWKXuxl8UuNwsXHY07R1Q86vSY0UsRLO8FHCD/Bs6etRYB
UV9SSN1GmQPW3xWmtRiSJucUtoUo++Y+JoJecdBq7W3co1CDMUt8hj/2lE7jaSPsXXY+hGuIKA4P
egF7sOl/m8kawWAtRWIpgE3aR06nI1uBp64L//ECAwGWeU+j7lnwCpieqedf0+J9bTf69FvxJZw2
j35eJrn4KJzbQe/FBnhdSqOqJiQ0uA0NHWQnDDmkVTjnBd+zj67wAkOr/0vfK1LcSVDvGc3xB1/S
mCLR3tm8NiAC3JHK/R0HB/v4MPiHMdikW2s+AWhC0IZjX65O5dQgNpWpgfqUSbzCuuDNX+RXOQl8
DgIvJo5fmaz6GmFVOZz42lXY8IpPyZT7gohhgeTdpbyzSAg1l66Ye7IgQ5dpZs8HG54lrG+17w8m
4x0oSoi8D4CK/YD1mClk+oacz4btixrrMzB0flYrFbYQnrfp0ugbfoq74+0uXIMeavBlarIiSrcF
qKycObl4bOItjUkxRtAaEyA2YkwjGvHqiniirY1ycuYCn196D9QlIkBLM0cc2w2zwssyqUNaMI0/
aUHPvHl/nVTASQg4dXOa5Bsw53VeSHgkoSAnl98SlSusUWdWjGUVy4tqSvQDgnW4ZCXDfFCaooZq
f9WktwDaE6G5fHdJXXwErZKKG/Twz3krAiQNh0ZabNUTBzzwClqb6xiWCBNRlhQk/IOeFd1l3vyA
PH8MWaJzVbDe9fdNAVS1Dp3ZGGtcBCJlmfvsnypW71VUffvy58tQURRJGN+AMSgVjN+1HkklTpeU
6QexjQLhSe2jMZ3es9mvezkXjoc30LkxYn7DlRVD9/S=