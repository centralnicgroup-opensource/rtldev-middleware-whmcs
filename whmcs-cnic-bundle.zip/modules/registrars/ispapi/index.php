<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpHm+IMYsy4AkyTi1ci6Tnm0mr9cmeKPMfouFpjZ50pC5WdvbJzfALQrxFsazNgjkiERhj+o
aZNW6vyIH4bNzAkjiaaAPZqgKjPouRUQWQLllPFmgzymdmYV3s8EL9hZeZrZN3AdEGNuRygjMcrU
m6UoaIZA1hKaNO38vqyJ+4PYDiJd2ccElHc+YCYkzdedwDWKbkxqMzuT+o7FsjQSWJahTLSKrsL0
RNSKpQFTjjtVIq3zSK3TMiI0gRFBmuHYuRF8ZD9i0s3r8Bdvcc7vv6pVtuTjVAqxI94OidgnZKnd
ToStmB/swz+wrr6DTcPFEda4/hOPn8VsYloA9kfnfyWh8kxaIbJ1z0ioXqI0vE0p9QKtLqhNv7xW
QsR65hUD6lgq5FYrUc93xUS/j2pE2X1oGxDl9KwZRj6gysNYqwsIgp7jBe2ju9p3mpuRoz9VO0jC
BocS99GosEuP1DrUYbhLYvnOt+cLoGIR15j5J5uUm73ZBIvd3z9ZXXxzL59K0+968JSvCTm3wxnl
XpqZIcNNHN6QT5ldytmWIVSRqfSahZ2Iv9Vw3IsnlDxVPx3PCyusjDY7O6DrnlJtQd4F7UjckXxK
3fIwwlKWRNa7rLDobXXB7+MDccOGqTkFEgDC28+bHVWekXWsQIDTfrEz7kuIrZ1hOM6Gi8TaK+kf
EIzeuFVsfdTSk1WnV/BKUaX8tWFXjM1oCha46tOn6SWl90qcgrZ6zh12tMpzeZN4AA91SULSQlef
E3T7atIYLWI7obcByG/m0hixWxiAG6NSb7V8RG5z0uF31TXsrUIi+JcHHwsxz5Knhs/dg/widehR
PCW+Ts0qR1o244ek6cxkk+6nPoBPGPu4Yk8VLqspijF9uG==