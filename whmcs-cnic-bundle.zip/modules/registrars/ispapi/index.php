<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx7kS2bQDKaF8rdb2eou/EJjbs8TwjU94SgoSxJzqJY75BOhfAQr94Y8N0tK8h8YOlLD9HyU
98sbLUvTHcJcizvHvIVBPNWdsio/x4W1vB7s/w39acxAlPl/BYLz4zJ9mqIBGcLPTZSQmFCL874S
expwv3IAyHUs6aUWUtb7SSv74w94zWy2b9H1PAMIOVxUvNLcYuOdjQ7wHloMa5PvYrGqknAJB0HG
5dM5ME6UTe0apDk621TK1Y9r2PRB9Q02phJc45jjQx9jvyVm+v85jTiNvpO8QK42N+dLW7kX2aGv
RSUcUlz2WS7ex3O2yoEfHeclwBCUQeKQYTz4qz5qlTl6sK7w169FateqjkENRGhgLVMCOCYuif9i
Nb1YRBKvmM2h9tMxnyWttWxSvzxm8lCpgdWu6uotDQbp1aXjwgqEWwU7kzLtp/CnQ7OtKoZ6H2Sq
Q976icvLsU6IwRm5lvo/ZSjhmP57TVPf1hnq1Ind8dDbG2+QW6qx6J7Zj95LovyGxd3DnyH6USPY
+e3eMVUdtGfz6d9kfBkQyTYz0CGXmUL51/UymC5KWd7n2ThKwFnp5NIAD1MiVqyX+SllMEy8Z/Iy
P0i3vzwZhrETGmYaDZIxh+dP6CqAI0LVuUQ9bhtTUV0s3y5xkCvSwEv6st27ShVB8fRw5Ou5+UD7
DVvf8xmpC8hXLg5YHGrBvqn5MitJzXBWwWkDKxgTI3W4OFNrZodN8TFzwLN1nRNOUsWtEo7LuVIf
p1emW8Luzf9i3dfmgFfHtOpkGNfDDcqgwj2zvcYNx4KFWhrvzmMdDihunULyL7rZ9epaY8xAfQo7
r3NiVof2pUC3pCKHb7Bl9bzaB1vqbabofnxVrjy=