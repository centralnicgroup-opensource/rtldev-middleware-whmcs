<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv+AoCj+KJ7i1prTw7xExHr1+rrAuRSgOvsuogPKZKcZwyljAgOXFrTGgm6sGz+GRO/qXj4r
+2Fs9nwFFSVFuo5TyQyW6cORaBZ08zhB62FwIYJOtmUXIPaQhapOZZ05E8iWs2J/Ve0ChMJUe6j7
9AUQ9NniU3rutNykAUKQJ7oRhTjq9Z1l09KClvq8kEm+Qkq80PIOyxiQiV40bkkjgifbVNUpQ9ie
EKmhB1XW8ProNFonMni/V6VmJF9r6M8SjhRkgjBlBs8+zPno1ert3qkNOxjbDWZ9ZFLPpTKOCdH1
zsOp/o5Kfkybp5ojv5Aex7LQrJ7EpPvuAd5CxBsQqLP1gTjf6LsPKQiWlZXbUa3CULj/huTiuzbh
TODnIgyAPNL58lFVEIWJtKHE6roD6OF/ZGGXpFgI167KYCj1eBWHo41KeK42DV1colGfGu/4OXnL
O0Lag1AhkuYb/sOBgPj06KRPfYKiZ8iAoV076WjdekNq8LEAqaMwe9Lul/0xi/L3wVrtj1u5yPQL
wwSid3hQFy/VwYJjR7NAA6PskfFHI2jLUh0rIFANEbOYSSM4eYcVUh2S8yArfrCAq6GfbkTu6Cx6
aHb3U427cRcB65fgp7IqrWmr87mSYz1Fu2qF5w3g3bqET1vs2iV3C6OWgv6B1XsTjca3kOUQYPqj
V5kdbq5IAXJ5r0arFhya7R/iIlPu/iTKhnUAyXVODKPl6SDBRe7P7RnEdcLMCgB6/v/bQ2zlQ71z
Vza4WcE/U/QgN/AQJ5nIDpqiN47nUjxi5fArhI6nM42G6gkTdiNKZlZwaHN8SlgZXesgkFVWvrGr
7W41rYTMhRE/GI2DEL4EobC9rjCEcMSKmPS7T+ArKCyKT0==