<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPngDfA7DL1sMY3enWgypy41P8BTfxXjwAgkut/JpS52yIBQAw55oY+A8NmqskH64mYu6WB8t
MYouPt5Lv7QugYYBdwJUkqeBjd0GSAAL7KHrsMLkKi6BtrNzh67kv7D/ARxiw0AE1g8cO8lcmUBy
rt9tvOiH+5xYHz/srkyuSQJMyRvWxd66nXD6pVvFqr+1LSSJJs5JZFKOlvNCESYs28TR1TOSzwaG
0MGNzDd1GoH3tpq/I0DwCk4+HWhXPko9JBSnu08rschs7159idl4hwtDl+9hjNWXB/OgJ92GqTUN
ZmT75O10iEC0zQiRTu70UkcKztP+lVDAvOTnO+dz3YVxStEkI4BRcIZmPVHunviTyDtflGf/fizO
3W9wwjbdjHvMSQ/ywkFcauHHLVzHrcwJTzX0ZR2cO2fatDBkkrk4CXf5YZzYDd+j9W4mkZ787wXI
amSkK3cx5QXbl2qtS3u5G9Ngm6aTX9zlHCp6kZJDtp06RUskj/yNj2S4sFnbYHpauRuOgEvitWbi
YvxEz1xQhW61j33EKpQX0MvgztN1FwZoMEbNOX3ppwWawPujx1UoTu4IFK5X3O4E9qDrm0zAeQuK
pQu+Dc+QBk3UhFGSIJ1loXpRdmLC41lSP0mjTw9Sqa3bS22V/hidW59nI87Jeue61J7eTet934OI
XVWZcC3QxS8VDLPEgI+HDXYkTVSd3abXkCr91IUQLf9DDEmPDdsUnNl0+OG8BDEqfOUK1J1+mcds
rX0fi/D+ES2vq3GCN3bkl0Jt7fQxVh6ilY4sMOaBLbUGrwDZ9MVZLz++W3E9GaVNJIgu9HQqzGhM
qd0ST1Ipy+m5xmEEp34eYJPQN2zZiPbJgBhCWnO=