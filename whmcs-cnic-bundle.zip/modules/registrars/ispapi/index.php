<?php //ICB0 81:0 72:c11                                                      ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsKMmm3W/JSt/Q5M8m8LtnDJX5xTPUi4mE+6Qt2EWVMZGZjBy5w1FozDVPb6YiGEvcQ6eXEX
1ciC8UVtZ12Ujo4bruw2TwBo+lWhfHvrGZke2PkpQ6QyXwHeznkvwPOTPMmA/Iu0ofsQZcJ7lEUw
CifpnArxbprIpUGZiZ/ZTQRyPwgpZsUN7o2CgG1ccDP4KEsoeRFgXKkQ3qYPfJJ1gRY+CKXNank1
bRSBvMfYGboJuTIB8yO8xRm0Q6HjzCiZMBBjG+A9iqD51yGjquZVhbtm2mhCQHSfYTa2ZCcyOGrm
/+36T0vVMV27IqadGBJbt/pDTPJhBV09gKxfUViusLnbf8l9KRWpe+Rl6m8RCDs7nBL4ol0XuYEc
kzR5I6OpiHQyTOn94KGrMNsh9F90Z3aYcxH4ZxA9CLFk9NhmbZ6aRbiURQfpAkEinoehvMAvetpB
TqZF1jftt3zSrtqd9XTKjZ0+WSf7zZRnIwtCLDYv7lsRygPh/JSETD1bHUZWX8DdWOGuPdDjEjd8
CpTdquwu6If5gFCtvRy6XwXUOLvEFfbPj7ZeBn3CjpA/t9sJ1WYbgFQt/mU50YKJ81ki36iuNQ7t
ctx+I07E/rOEqadTEv/x4uwKML9+yrpYVv4QM5UqfEfiDqXy7qPogdGzbjd3Bo+viGDzomklAfMP
73Xrk8aOCtbboD+SNMo00gJhZl8OJ/RWC2+31/GWvx3VT38xmLCndv4DjvFYcWDSFarW0OL6u64D
n9xnBnIYLiNJmJe+AVBy/xN8Ps/wIoJSRLYY+Ped+lNrDnNHgXOW8VbuPXd8zhdHsVaWAN1SfL+m
J278mSGzKoOb+573+tfxEa8qkmMvtX/192IJvQkZNDCIBG===
HR+cPzWhVVge2KR+jPNesR8/XC3n56b88IoV48ku3325CQTkqvd2iien1MEHN3L4pShA7KDA2Dzw
/1VbbfoBUsHn4wriITCq2SDapmPzKJ2kb+4nPbr0PrW/ZjZ7Bdo5dcuxamv2t66MMVnBdWCf5r6W
Jf0RbfGZ7nAJFMGd0iPLGIJmyEEPFNvwWLYknpZvy3KHGkiMb0qnN9R7yqEorJzEz7kCfhhgiGhU
R4EV14tYr2GP2uFRRBz61k9xlyCMLfXJa2ZEXFG33n3+Qe+d7+rbPutlImrZtj/hW9Y+EZY4TY0s
WmS5/yoMJgd+CR8RaWrzKE/6kAcquztsOYJMwxCka8sfJVC6B7gOqD6ucTModN5pXz//Y6AN8sVx
lRVmWy2EwwLlDQFw56MQtP09PQeCdGQZkmJo8mefa973kqfmMKIPXGjlgkIfkQNkdzEUkjqTnm7F
WBSR+rXWaiMqmz1a/PeZppkSgbD7jsHkhm8E0fUB9GCo5b0o1eMc/HKDTbiMdDwlxBFJ98uTZkIT
rdkHo2Ays/AG1Ot4Bk0WQCj1PQ8QFW+HVkH0c/tPLnmTg7OpSfEEJx1tgl3qE38BRBJDIb8wcB/y
jiUj+MSE3KyS/waTIOCOdTrqgYmTnhvRrGiV5BpW3NwGJhL5koUNaDGVt2g6SR3GGQpbOq28Vv0v
1Id1xtorxF4tWjjBdpP0y9i72Imk0DLQ3llLKAjeJBWcEkeuo3Uo1ZyIL4RUfn5q8fBS5Nsz3D1x
mUmZMq+yBjGMdeMrldt2OOMwuXQ4tgT01PJCC4vKRZWIPPQ3VldJjiOFHR+ZAxSm8T2MrwI1qH+V
eILteqkLdkTU1FrLPFcUQL08jnCh2u+ReBYtQDHRSm==