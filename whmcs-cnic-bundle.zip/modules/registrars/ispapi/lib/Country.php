<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt5xkcwSn1v1MSalJIiQSJxCR5ZWHglm4jH6BBWiRUduO2UO9m6+TwXvyuOLqLkrgcr9dw4h
FwQ7E/i6/1VJq/BoUU2qCLDKoMaYmnT9ncgRUXAGY0+cFrivekbXWElaETyhpPyDpvZQoj5gfEm+
qE2Ulf6wZ9xb08RATNO/rvDVI2qbHivMsZTVOpugKVyqni8jXy8iNDt5zQHTp3Sg7OYpKTQG4z4L
f3R/T3MDZ9tzwqwfWVEpZhgNiuYaVZsqsQaHwxaGAzyM9OqV3uQwVOh17D/d/29kbGSsgcmD86P/
FKs7IySA/nE+0OmcngxuGL4UQERdIvLZedToAWnIDssBrUbgiBJS/neMOr571GII08E5Dujqj8Lz
TT5EVEpW8MuEU2et7FchBwmWL+I2+V5to9LZj5WfFcn7qa9vWOu5GZOnqMpV2R3f5L2GNYmtiBN7
aK4/3N3S9WCmmo15CtRRPGyTn+oSITI16JUUTGtgnOwhVR1+4MpXPMg9TS+BILrezlg6oa4OOhSu
hW8AWCNDOg0Zbb0Un5wLXSDSUtfujfWkb6b4V+q43wtlBh2Bivd7Z1/44RHOdryXaLLNPShEJj0r
8qBs9Q+rAbfBxJ0MwUTQ6Stqdz0tBHsRoxIj+F8JamE4wW7/edumAMfYwb8Ygxc78UABKUNWfJZE
ZtYD/LhOdKY0GQPCrXpKVhZpmobpCLJeYM54RF7rfRJ5D7FGQONTX4Rq8J7BiKv/bfdbPHj0oon9
i1XNxBbCczDe0R1FIVbU5hXsWJGI9+lBFwg5qxDfI8Yco5tLXr6qX8qs61ZFRYDdtZDDJluKo/fF
z2ZzlbHeSVHXm93g3KZuX04G0DaqPAU3/rutzQAghMEbNiNvB0/1nejsjPHp85GuYJvULqpZwPcl
gFYTCqs9XkrEq1s+IGopQL4vdrTkzfhyxIbN1pT9p+IkQPzsp+6RnOq9xeImTFeJTwJq757JBFNs
K3vTB61G24zqTk0Qc5cHgEgWUkMnc5eG3Mwkhemd3ZCMfo5lvtXmOqQFY19Y8rirMtWpG7tlOR2L
+IZsB5UaNKrg0iP6P0f5i5JrKkzZQ+KtqlEPiT9zY84LhvPTRACuh3CoFSiLX9uw+gwMxkboLSFW
UlVcgXFDXRSdFi5GFM6l6H7cVlb1MVK/Gk8IKHr4Q8Ilz4qCB8vCjGQMTee1vcjvHdXn7Ta3eSQF
P2fPJgDq/yFFiduTGBoT+QeDGOjiUxvqmkhoyWk+J00/IOqHPi4xyPzZPUpCl7poSZVgb7mV49UH
LhLHCwbuHP2GQkh6RLdlOrFlnG+eR89wY0Bi9uMZffhKy4Igw9OmiOacCZB8ZfAiQzWchMJwJTVd
yBAMsRv+L01qEpEtjC9G0XnCHTgbgEi73gNFxz1OcygzW1pS4gFY796gqqfBs6Dw6SyH8J1kLP6n
/ZV56PEgAG35rxfhMAzm8ilXmBX3BVaJmjsTCjJHSulab9L4vl0dnNAivjY3atkMLnTeeeTUQ8ae
b/KwFa/bRWTNJ4DbXpsqQk60J6bWvSuMptQjY63yGOHDsxTv91OnA2CGn3V5lv2LM2xfYqRF/plp
NLOmKanFBf3FwuQrRbGiaGd6hVG3LSiPR3YnMqYMX/uiNpABIZdtc9Wv7kG5GaFOx+knmKbwohhK
/G8eKTfIEFa0rp1UML7yh5rMYWq6kxO7pnKO90NhweywLWGCPOyjj9IVpQ/JxYVYMU+lMxvKXHUr
SuejylDMInrQCdvc9xkeDJ0a/HbrPkqPklzgRPUpni9/joBHOJI4lqlrCYVnm6cTpcQejgliV0IL
SyxPTr4PyjP46WTddzHs6iYvS7z7BRFB8d+55cBOJwL8YIPMoXb+G1GK4lDniz+MAefhxqNwAeNT
E1jZEBbLAz52op+mx0AL9peNBTyN36f47srb7XCYFTmYWs6Py9iPrBlwutNbm8rhK46TJa6ntXqx
wzCUCQv2f6H5+H3fCTB9xQLwPIk/FRiiKbsa/Qz/63J6Sf/3VanVoc766BxZkSHuIJaSAvQlGQfI
p9thX7s7u18XYJixsm4uzriU3pNcr0rk16A9biE3dUQPc4j4Zhzfa1rQJjJ8ZXlpWF6ap9nh90==