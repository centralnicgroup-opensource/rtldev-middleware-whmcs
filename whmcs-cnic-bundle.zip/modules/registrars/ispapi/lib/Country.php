<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqDRudzhfTPmSkbtN6HQvL/tBKUps3/gUjkA9L6RobkPzAwMnNwLtihPEVkRoSyv1yQu8Tf7
9EEb4J8qhOV561ieYajk9ncFQGMRRCXkZsRyNwCr7jEM9jHMRdim/lqCaLPzT0/hW5vi1XRyuDPk
KlZrcMTTZBDps5df/a8t5DtoPVo/imrIghR83Yrgf4zoUBI4rrX18JxPquBiFjeXwa+4Wb5Rk2tQ
NrUfErR/oJXGwTyYYa+iSb0gXzJivrgDR4XnYKfzvT9yD39gwpBCSAKL+RgMRTgLiVwS+xgJnnK7
8IndHCNz6WVXugv9/qwh/zBXzOLIoaeHUcOdGaCce0j0qb5bKxDjeVjsfkTJchDq0/XoOjiE90aO
UOjCTtsXp+j8JKHWwOJ1zAoFLyNUISxlD7uzCHreQDxO6FjSeDGZJ6vpIxzjYvq0MOnHqiDE9Wjt
iEJLu7gvPA39z7qf17bvGfCO1etnPIQ2Sqc2LxqVoalCADA9QpzZNDCqXhPXkU1D6XHw1VXFiHmw
yy8BeTQ6POULt6nxvD4jsdk0YAnRZ0ue69fCBlh0C8H0B3bhbsd3aACWqjoldpPjEO/GB7W8EQJW
qvFmc7Q2SucqYfzlOB44hfj/PwOLVzlC+8TQOQVuWmQ+cD1P/uffPonoMnxb2nQYtaG43Lkl2gsr
Naxbtgk8Ht+TbDSQ0Tt5YNpRsPwFrzuA31GGGF6O9vo/2miknFMAiEFHG8gG+icihjeYog8+HyRQ
A8P2qYYvlYrlpJEsuf2rQTiehBREU/Ih9putV6wIj1KJdmUw4JWGASwsbNoNxnJceWPMJ0QRvBkw
dIHIxYjbLNJabIHTH1IYW50pkYkY5iM0FR65nu19aDk3wYPOi3Mm1APnH1wAmcrnPxMkKB2oMUqX
SA1rKSnOsYy+jonJv/k7ul0pRcXjwtwkgtzhJNqs1stCWHDYCIicXDuMi1+pNdDQo/+W+gqFYXk0
zM4m3jH8a0gokxaRBTW/nzYGW/a5Lf+KsdKeZjgpe1D3vnIHBkqvNKFef16OYWbuSKGt8eBHrq4E
6i1CrvniJ76kCjRwA03g24dZZsqu9aI8jOMZBRim+zhLECdw4h3ljogmJU3opgkMQZMgNWnRCmzZ
A65bs07VeGZDGshVtgpkQDhpdUVe+pe5gipf/I5arssS8QbkiUKCvnfLtGbR9TyK7lCpOqDvT1NJ
YptIXVhDivTmDxpOLtsmfOgZD30LFNiBQQ8MRko29YnKK3UyGuV9V1o2k3k6J7jE7Fq/y8NciwJy
DijhBb6U44FU5ygK7nmRJNQY/59o1WuU8Hj4femLJVpzi3BaVst0L6Df1l+3MXMbQuwmzlEvjdRQ
cNebuPCXTiAOBuyAhRp0iWXeOlXkJ+zb2MIqsvzWt+gukGthTm3MfFpZMSusfic/gFSZHU3IwwLb
uFIAd7EOilv+Bmmjl0e40Fv80LUJgOijx4yQprWNVRrDxMLl84ZpbvFhMP1GcXpEzlRy/Z8Cw9Z/
rTh8zAjGR7zoKjagPjFYGLoki8tAOiV35KqAxv6/f2E7nsURwiiaGJxKcW90cIkW70SWulRIx1O/
upRSoCwbyVjQDVZo/fYorGAeeXkUO9okt2+op/YvcoHh8Drh8kHBeR/R67j0iy7iQTxHHOBbEAOa
yiWAsdjK8xKxBWgZ2nik/y3zaXXI4fYnhOaxnwPnJIG/YxlTxX2qouqWMdIhumC/nCGNukdKTBtw
NvOODeLD5cYLMr2ncdtxb67nwYEqHL0mxDwFKW5rtLc6rbEpMyp+1NCM7pIH7CVHQEW1B0y297/F
ixwlPRbIG5DtRq6KZ4w6jonJrQxStliLO0FyQ0UE34ZP4CprSODsD08eRzZeLpileO7NLIi2ICl/
k7i7NBXCXN52/Aq+bD5JOCLAkgroaQYXj8NnlXyidzVIHJedDiUgMYyBjBIFpozwqnI7oYtXpUg9
oizQQPNs4x3OaGuIZj8H3xsP8FRsVitZLrQ8E6IRqnN7WYTscZHIu0m28rStJxEF8937ALSCO0zE
LWFruNIxczfmHArKQSOZ1Iu+0GgUCFTK1xRQwvp9Vy2g7RiSmviO2DuPGwlFf54K