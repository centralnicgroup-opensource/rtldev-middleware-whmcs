<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+TCZDe0a7GTtVuP+IhhPq2SxFxFp7hLRRguMBUvFHCC5NvNvyC8JybHE4lW9GpKR5Y6H7KC
xBFvUO0+FKiMXAdsVJSYXURZfK4P1pSQoKhJjzya5kKYp9JyFQLRvZljuUhIYnhSkiVERzruc1co
Y5uPnrOVZ4GlrCCNrtCif5zRGagdfvQjsdrR+np8h7QD7ArIMUTEV7ez2jBLFTjoekhCqUw4vnhC
KKoqmk8cre4PK/Uqo/lYLishLC1ct+EKRU3i7gppYEhJ9G9xXWTad9nBMdXlKFNWgxlYvo4RxjXt
K8SIniwGm6K65n/zDuMj//xF3Nyk0NRfVz/THVSn7rfoqIRPBlC/nskSJmRh501/cEuGx06ZcpEl
vFfHMvEn4Y9H7Ep3io6e6C7oIa1m9OoAf8Or1/5yPUem3yYLn+t/VVe1RtTF0RlXrHs3XSUNZfvY
UPjOJ4ETBVKMyervwlZiAJJbpYMt++Ncbqv/WqaWiz91LrCM6nQHXNjy9jB8yCLQdDbcq84pekIZ
bma+QmqrGL+Lz7RR4I4IWhVQkv0aoocH2p8AWvh6/f8DO0IWPOH5W1rDCswQbz9nGn1HB4pGBnEo
QfLC7efOO7CwfMN8ULF17DpnBg48oxUIU1s8A1AXhUXJKleNmIV/6d43lP/Jjtr1hCAOynH1zayc
o3ajY1Xy+bFgXhPjU0aF2luWcCENxT8lfzoxQUHElPgiLW/cVJvS9K/CqqQXCBJzqTYRvNCXCBQS
AvPjYj23fZCtB57TzMiunT/WN00ChBIh2F5DP/H/UvW/msM0bKmbSQ6JwIP2/V9zhip2xbJHan5Q
CQLtT7Zko/zr4ZJqH6E6zluHivEOTJMZyqAKth2rcExxwzzBSMLeAroWWb246AoBLd9vr/BSGERV
xWErzZky6XN+64xE9S6Y7xiwY+2DZwTwfPehKt8nZ3F0s7Qanf/M5yXuJBfQ3zhDHmCCm5isaICv
T/Z1Aa9Q4ORPVV+OTv6rnaDjGcYNBvfVRNfZZLxLS+KiGgmjLNnzRIq7R1SdBr9gTEZkFiLGSv40
tJ2REFEllFiXRKOuUqu9f/ye67SWSNItuQE9w0aX44I/cJKGn96oEgmoJYox9CjH6tYQK/iPFLii
VMI6EBQOPmJozbILGm5mJU1Zm6vLy2QEUNz05Xf+tiBdS5Z1wPxKQDpHN5jCvBV90yTf/fuSh6w0
dlz6pWXoXvc4nKmFzXxEHMwORjyUIG+JcEVvgN8l5oP4JDrDlWdfBebhWV2eWKhZj5eGfUFA8xth
0jEkYktGYDox3KjeUktrONjmh5xagoSmPaeAd0H/HfEguta4dff4/nKOxUrq6hj0FV6LPoatWs3I
i5udIRBV0myokJVDLsqo6XR3Ma9nRsUfKimJeh1zFcPoujRlh/qPPV4sHypcYcDLfjXlhY93zTzo
Ddn2yTSG/cKu34wcsUVPsbpiAjrWCATjmM+lTSDC3c1/v6hSzdSh9mBfRFU0Z4A+DXGofsi/Ab8j
nyFc2Kn9o7PZ9kD+gQu9Kt3DJ1FAGEPn88Cn6esMsMmgNkEqWiYJKG9WqSiBUQ/FQBoXc2fl5PYk
9wgMpWij0X8aaEvQSKaif/wvVZjk72w1XQ6GwJIeX3kwXrqrRRV4alxy4nI+YgwYdYTQbQkeTC18
/XFOkwm2wzNDd5d/ZcgrlvQS3uAZ+ZtbMtNamF4uWmdm89nH3azy3N6Tvjgi0KenjdGedkPl7M84
3bzwT72hK5ObBid5QzyofAb7R+cCKUIYUZjRGnDEIhgMo1TmriNhgvt6OPPDSwUEOg1JBTqhUcp/
+kU1XIwDIeXS3k7F3yFj5PxOhYN34pij0hCV9kx5eV7xLQo43hHATpPWMmuonSUygce61uBK+KNw
C+Yy+gP3rYMSAt3PnZqNVckfY08vMduQrPHIeQbDSR/6iNFHtvJFGrtNhLTmg4qJxopY6Ghf6A5j
QawzZz2UNNqYAjVQrEzt9vj0pfXYu5lqKKeo6Iueh35Rvw8l+vkuAJ32hOUPkv28n/pObPaDdg/T
RedKS/GPXISAvn3OgBPq9v8IU1J+zBHRI1PPwbVCQxshYfoScW==