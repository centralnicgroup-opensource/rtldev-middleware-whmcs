<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr6j7qhtSEHjZXwAQSxI9jdNCNz9oKTUSSvM2hxcZzX9vHnDwk1HlnVDTNstCaYfppjIqA2D
ZNMS4OjO6Efy/XHSykIfTzmT7x1EhTtHXy9J8wDKpip+L0HBKhdH8h5wpr6XJkWgavCN5V8/4f6V
XNd27q3ct/GaJK/f3GqIIFo11yDOSMIqHcomwHwBIkPJzbkXGPqK3yLC+C0WnN+FPFfHZgM3Sk28
zujZ2N0C/048RdHUswHvEbJNOiJrLQA/kxWui+8HMC4PXujdL7nGIdoPc5ctDsku7rHRvNOcP/86
ErtRfm+EuFIDagLIZY89S1Smk+rVB+gJP5Mpf6ZIm8wpb1CbWq9Byae3mPcOFpSndbYRNzub6r8G
zdGKsvXsPgDPKqxm/pQcfeJhZ0sH/OpucW0wMuDKRoxfvPtUpQSPoNqiYBwFaeaNjxeIEXOQbfEn
peSHSoR6SoBaC75P9uVlurAYdlZOx56Gb/AJlLrL7f0Jeu+XIt2Ad5HNi0ZCYnKM0y1kYcK8RCyz
WFCN9htJiceaUlq+aBYPPGY75n2QmqKOcb+C4qMDGrG1zwzOud7b251sz8ZPkp1DtjGDbv37/PIL
1cRejSFGQUNDOO2lzQJdx/KjgNLBZV7nH+1lZy1FN3PttUcEAabQeCPiLZUYkHtMJv49CbZ/mXuX
vhUGmG23CQnfHkPBfDoYAfvDm6BVZvLbMojbaGdCYH/OAZ8akGKp7pfjkF7giene8EQ4ePKdYWTd
OWZuin0fy2gASd9CBZEs7zGjt3PR8k4MHZVpBjhaIGtcZ4zW6wYrRe5Yl9OiQm7pdUXOCzLbSX3w
zZwtYax5GVdp5n7cNhnBo9OOp5uoYw4iAboWxBpU32Kqk9KsGEpUFeGuXmr9DPWkgh7iVy+se8uG
8ERohyZTLHYd21C4J35vrVdvsqdD9UyB2jk7xXnTHph+AhQxS6lf5ECiYJ5z5vPj7gzFgRDXZ+nQ
uONHfn8O/TNxns8idSeM10WqCKyv9DmbCD+DK/lInSTPfrEUbRdGbw4lDdgKjKBD0Z/puJz/DIp6
7PaAKDg8+SG+34ECT+0OwikT4TSuM7+3wI0xCy3FvnDGiQ6d/YWjQ2esqG4jWtti9iS6V0FI8sRs
XgA2fI4WilUGZcPMG5y6zvisA/RyNwSWVaAksc8qo6wKNN047mf4l0dUcIcUJgERLve/m1tSoRMm
Ko2d78dxrlz5iQyvl/jjl+3/3M1wXFGNFIVRo9xfDJ+3zpNXr0GHReZtqZTPg3zYDQ7wbata+6Of
Y9r8XRSn6DvMsaLlQTLBN7wtad9Dj2+YRLvL1UTXyXHwV//EaY+JBin786bATP5R+4O9ostqRSMK
sAkykIcci4O8GbQmw3gY1YpOIUVdoM5pzlX9Z/AKIje2iHJLGHsEY4GpKTsrODiGUILsiz0abbW+
ul5sEZ8jqGxAaSrfP8j8R4/kmyB4f5jAf/8GW0SJEzTyv1eSxeuof0QxjIZQxYp/z4tu4uGBxOUC
jl3Yubvzw7pVMI5O0y1u4u4FgX6QN8M/TCAyaO9wk6JP2GzEC3GULy5WpOJzxlGEwrKgBZf+ZhP2
Junufc22ZicooRBFJiKY325orJi0LxXHABmtnp8LcXyKeweJrhYh3ZJ9J4LuVBplqk2jYcIS0Udf
LTtD1XWwQkcxGkaS3eq7PWgfYsRVDW8zqSAR7/a6eWzpKPqt9J23nk8QsZSlFOtEouEL/fYEuyMV
Fk3K/aw4LZ5OvKbbfp1DlnIngNnYzUJGaSFDSe06lPdYc4/HSKrV6FG5ZO+9T5XiOCFePIDCHpFJ
A7BJ11RqXUkKWRM0A/a3qHh2Oxir285rhQV1Ff685RBDqbHK+755qyJRL9wN95D3UaIMMpvs/3PZ
408Ui9KmRNTZ8rjCJEqqEIXCEY/qEmZC+KPYw4C/qfXx9Suu944xW/dwP8f/vjJ9i0epIZHq5d4q
jA6BdUO76Koqn63ez1hbV3/WzW2jrUADSjosDXSLN5qoqzH1+SA27EaEJcjx4z6KqVcVdsy5etj+
TtWcEJ3ZCYt0O/vgzH+8O9i8v/Ib7oYqTp/leSTkLdmHpFBx0FAYNIwEzmaGSdxRKgvivvi9c72I
YaibNw9FeWXL