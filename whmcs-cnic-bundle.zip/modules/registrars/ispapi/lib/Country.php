<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrQvJ6zbXxL0S0lPJBV7PSPB/SXDkJv4YuguuRAAN6u9urD7N/1p44zeAjkAMpbq8HeNon1n
U3JAoGRllnAyz2bVCTnHVg8tfpANxhGDFJYo7eOgutEWnNht/JbwVKbkP//ECwpSy+m35y6g9Tu1
1mLxe+xSyP642hkgerQ+ccefR54it92WyWi3bxOpxWNwRLoJNCZhf/xIDBSjWxY9B0+McsScjnei
fxny1/AcCKV0YCaeWDjb1XY0O7jz1MGlStkxDDmkVTjnBd+zj67wAkOr/4nd8tQkB8TzyrecjX+S
YKXC/+Gxvsgaom+6p8AyuTgX55DA+TFdztfTGuxuyHwkP9PhmU+6/ShN8a7T3gSnqeI7DytYdO+d
trwHJikg5bpQ7KXEzRoBQvaFq2Qf3tFQcZ19PkfVwVyQ7uID6ev/yBIL0TW5QjAzI5Jz4p6nyz8f
eNrzQRoL/q6VoXQepWxrENcDOWAEX7wbGX7rjw3eMMptnZUrhAOB+of3a+ZOxYsd2lh1oeMZ+KzC
otFA8SbpJc35QXR4kNZq42zylwOTADIWOn6lkXD0Q4M6bzJ/0gDzeYeg/UirmBaPpzKJ6lPSiecS
+ZWljZsr3Mri0jQqpDUjAqh4jg4Mt6eV9odJDzLGDcl/kvL38aI1GQ+jo+hYsm0IneTmCyiZlvDg
OgBbq2gV4BakaIRYhYFzTQr8WnLOCrsPRwYS3gEhJCwo8jXlDEt9IHyYbs1pHpfQub882u55hJAp
L3jDUq/KnXtl6udDMyKu3WWItf8ubtmxsWV0D/xDH0V8NRjine/s5FRT/XNIisoiHkKrCKV843Hw
o6zo17cqQvHlqPfSyE3qq4LoiJvSAajI/SJBYsiQn5KGHtbbIcaHZHz7o9GM5pwXgmkb+s9dRYDf
Busm5JadFKXaVUAQFgctbOU+V7Chls4zdy0i63sGQGIbHX+VT63gDU/2wllXRIiWxypI3PsDB/B7
iqveHShrU4Udm6PjldVmLjrM6bAaIMO5Cx6buc7EnUyLGkzSUPAsMc6DNBFc6G8T9E6YxLVW1S/f
feOkWjU0gkB0Mz/qWUqUSBeSvzq0RqieJVA0Mh81gD/9aqir5vXJCg2xizZxzQskXylA9JCr3x7N
2K9RrCTekAJV2tmRUWcwX21tHFq8xmOnZvETfGjF3vm4VxKixXmOUfggSK+dYUbmc/HOv9sXVM2m
flkNbwr3GfdOtLLQSc4JVSebZh5A1Q0amehretHWWwtXti76XVqHD6FDuIFV6QOJSNJj4SIEaFhm
jQZog5HDghr3bBH8LrAvAW3nnDOnqI4tb6PXIufK1ry9M2HfC/EssFMm2J79PLoOEHDzQOYcDgy9
ST8kPoXVy82v+qD0XhPuoMKrZm8glXVGyc7RKchbAuaOHYrztmeGWSdjlsaM8wqbWCJFQ01GIs/G
ol2LEbTP833fcrI9uS/OsbVnK7l3So+60sATygm6tQx1OQDkSVTsl4k24ySkfY/Z2dXO905NYxXc
zlTs41Y02T5L+51kz1LXQL/S/0g8vEUmH6422EkKesFVSBgeOAVtYElI66qrjwPj/LlEledWJ8F3
L8zhvEbwCnhdpl+wacEZuB59cC7ayHOhQxSJ4lX1lYfQHc57EHTEIlubQaoluYfxoZ211YoXH666
3QdFNeesX6UM76QwypkqhywIazRnwLUzvBVJaXnazeMBUKPnTH+eUUcOqHn2mZw/32FU4ceZKBKO
t0zZeqyDE4PDzOzYh9zKTjA6RTM+uLq/JHLZe3XjKxajm99BYNsW0wsELTGp4UWFKlKJrGYVj7Dq
XI9k7Kah6ABy7wtVsSp2FW0SHLPfCaeaJJZ1jiLtESMM2kMI4hE/awbvd/BphGgKjDPRpFfeznwI
gs+h44Owlzxr97vZebwK2lPeqEjVq4K7conaIZe/LgqnTRRKaTs65vynLKMKx5WM5RwBF+gKVPMa
b8RwoWszV106+BngPEDbDuK8p23CTiJazIlyXacd++RtJU42fXUS7YK/nAa01ZjXCzfTEjOj0Ii+
hBrmoIZPS3XNbbn1//gj4QXDrgP1bzfzjmGzd+nRu9SI1YpIncCIazQ+bhnytcFcToe1cBalgqm6
