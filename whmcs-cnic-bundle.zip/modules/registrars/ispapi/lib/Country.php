<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrm/fqQN01nfReqoPUugDVxjVfnmwsO1NeEuRTFX06nS+oKxheFXsjw10bHB7Vq12b7pPdH8
bYKUtKMr0lsYS3EGJcflSjb9nea7XYUPOEf9g4fLDCyfUnxxtGUby7urScqXhZaDeTrxd6wcp5wS
SNk7Ur6X2gsg9/okjr/4PsLDqXBqUpGAme0fxk1X8irfxd12KRc4H7qHw7+l8TwnnzqfgheJK4IY
/DtLK+O6SG+CDiK7BF6Bj/lC3lmxMyjPExAfEPx11iLtV7WoGwx5smpwtMfdjazU13gQLups2izt
NMWt/w65bXdGfKw9pFyln5AX81Xxm804/Cgke7A2hs0xpQAzHwCfTIUDW2pwLs9HSJjZ2dFAHXuN
wh7IhGrtr18j4jER8nDCg5r1oLnSzZEeAxz8/nfdIc/18hjnd2igE3NXYpJ6Q+PNKwk336YdlGfS
gD3qElkXZhmsOUo2EwPL/t6Hu1DQq53J0ubGKw4KsiEjQHfa/njfM2ZD4gbuPVhAqSlbceP+1jqo
/2FEV2hZCrGd0y2NUT4VOQlLQxHD/+cUjLdKw8G0Y9TqWdPWLGs7v1kW6VYt6AC6jmP5bDBElhfg
GTnwDvFQYAaRFGVqvPidSg5kf2VF5M3xpjmHUiJL3oB/D1D4Bd3tP+wOWmQDIlQqYIzeFVIjFZLM
nokWInlUv4wzIwZm4NjX5nhmwxg6gZapROD79hw8c+kwOFNIffJKblhlJXXXYB5wEEhQicdykWFc
bn2hmJgvNw4oojdshcoh2yV3TyLlArxbhuC2Zj6bSt/dvfPXVwlZORelC+e/3ruBHCVlBmQ9anmd
EHRMmkAVq0xbmNfYj1oJOJab67fyEb/q+THEOhTGTA9Fd8M+bRYnrFWTTyTNOrk3h/dsjUPSZAiA
vYZoMa4M3nT7KoVOIm94ZJR2Ore+DjjOjc+psKhvBPiJYsEmSXoMuMlJzAaZSKa3gAw7mBoa51K/
o2EtLZkzC+xFG2P8zz6cdZWRGxGCnMA2wgflGZKYzmNRgY38Vg/xtafh2g2b/1bODIx7+gIS5NZM
EYF33NPoavRGRoFygM5m1nJi+sfRvfwKKevm3UVNpDQcsUDsJ3WFpX/gr27WFO/gFPyhh3559QLo
96jPYcXDJ+V08A/asCuXt+gXe7QnLtPKgNDIh6cQRGhO0XnsK41lSSbS1sefR22HDEqtOfFdI2jK
t/ZIHGb5SBLDA1DiqlPX6KFmPywT5KbBLfYcRLH+I/t3Tvx3KH62dxGBuy5l0DZDykUMPNP67Dcu
7iZPX84j7jRmh1OB9+jIXR23B13SUCuHrYJiJABV0Pug4rDVdBf+/vI9uWN20YRxnAGPZn4WPl+v
RciXNQ2BoeTpJedyjGiP8hxIeJCmrJEZPSw6BpHPtiNNdTMRzJCtco56JpADGsJEaKF9TFqC44dk
fJIJz7ObGkrjbs74CBCSb3t5AX5/6Ggk8VoLcsCEwnunndp+ibQKm/2Pv9xyKQtdSg5qaVquKW4E
XksSG1XwQ8o2G0OAjRFIwCJJ/QGM4HHwved38P60dLT0B4j/1bNQyRy07bIAIGzJnRS1oPpt5hig
D9hygzQsiC7t6LyUuTNTzcJi3W/YE9r6CQ3I/MH9rTzkXUtzAPcP+HHIv9fInwnUN9M+62S5Jrrk
MuOctefqPpW1jX827DBIUqpy1ItnL7gYxZ3ZzMIl7VbiZcbvREFmnLjq++eZZxUVp8J3/FNZSwee
/T2LWmGehW22n3RBXphjeM7Je57b+KPxWqH5z7DQb1yFTPNwHeF6mxVasiqNc2s8kAs8FuQfSMs1
/1ZFYW0Iv/91s8d+iyd9iA+AFf6ZgF5Y2x7samCjQDUR7DuGYb/D9nmsmXknxs7tfxuc4GHfqphf
SRj6QhsS8kg0S2fiD9iVAbm5dwl9ElcYO4YC7NzlpfK56sXJ7FSDdBZdPQtaU8Q2v5Cq6cBDV4Rf
Pz5IH2lWfoMB6sEpTxvkC9GPCEKR6TIKgGHAGPVctcrfZsBzMLC/tzkp2WH+7QzBYar8BMkmqKas
ODBuPTopqBE5XmjE1HDK6lTmtAlwWSI8ZhGFYduUzew7eMiug2aWlQKkfATN