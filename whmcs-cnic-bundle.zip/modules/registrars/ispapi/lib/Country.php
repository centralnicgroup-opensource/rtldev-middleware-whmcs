<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp0H5J5v/n/j1WIZW19HE5AasrqT1cesylbbaDe3r6p2OgJaf8ezBMXCg7UnQebWRtQDuoMk
0vJ3Hy3PhxpfwTeOJbuaCv7jFqAxaApiUqnty9i7l0MfSZXkW8wwbFOudvvb5kWRmBwYsHEvoRsJ
WVhfOcrPLQrvkgXyi0x0NeRG6aR4RaWgnxG0vrFYJrSXKN14eT5N7BCb4RhrdpTreYYtSD0US1Fi
oXN7II2S34uhhNCGuXGzH6E/XAqCvTAaLCcVgz58ZL0P798EfnubVj6ae0vK3cRcrkOcglrYNE55
TT5M26F/WgakVpTo3fWlpRpjhbqse1pLMvKlkVI7Jqz/90JUTLIxMz7OdL5fpS0WZJZ6wkiGtOlX
joiRS++UweNm1/Lm0t4HVdmJJ30jP10Vpdt2miBascbChSW5XeyufHPEwqAyG/EfIFnYuHVgKSlS
/1cLsESavVZJ8b/v2/+5ZYYszjGb/PXoSsAQaBrsFm/uOX9klbDwnmodsrcDY4BYLRDo3RuA6Olh
TWkKOXncFr0I/ivzvdTkcRdmxlex92w4G6HJzFRvJdb8IpBn12DSjFx4HzdGlN8V02R3s9NpavUw
QtLQ1m22yU5g4atIEpgBecabS7bbSW7NBcd5db3k+JTVB//W50R44OBuW9CPzDjjUiIVluGVuIR3
RCwTggWP59mThvzlX5hJ/t6fpT6ba6yZyKKJ9tOZarMfT7Ji7i/VeTmOst51PXt1475QoSIeVTtH
m/CaEXyc4vW0RJYJfgpEw/paQ1Pg2jzlw09E7/06gGP0mSaqJCUTm7YAEU9/Xt9gUGMDoWRZ8TWo
Ob1cOGenVlRRkK7B4LmRT3h/ybjzNmimb3yid7H4Kz2FIBUgfMyw3dqIXer0wzAqIfvw+MFjz0MB
PQnInGw6yM354CpJ2/DgOeaaprokx8PIGcrtU9VHRyq5U2i+CdVq+HXn+GmiVi+Z/X3/2Fys3b0u
5DPLWFaI/tFpgio0TTKzN9mE5qyr4uZuzm62GZKWa1b4o2o/DwvJVwgtq+WNs0+nvFpIgYXseEux
zO3Qt2FnNncoOdKC3EBgoqnE3qpscmQfQq9KCdSJ9cE0Gl/7omj+B7jB4/kvO+sPpWemSEoEOuU/
UBSNAxYTanK8wMLQlvVN9IgGA12U2+Up0ZHl+8si+kc8Uq6jVHi96ViFlbobwGDSvmUtSI+fhVzv
xRfoCGVEWNOQI5jyT0/03DhlzGppFZcO7HgQCnHF9EBF35c4rkPLi2owgPMfKVY5luPTjmXxg8+J
CWRYKNEOyrDypgWekEUC7gVA4gJpxKd+MIhKvm6LGaAmT68Z1uhjpBtS4pLxAXfNL1lREQawxZHp
zfG5m93ArRkK7unIdj22jMFRhSK7xzBbownbheC0CVh7E4/YSRUJ2IMgXyPjqQS3lY29Vg9p9Ha/
ZoRNGHu1jsxzSKygDwJKDQCcmSYkuzTj4WOpw80mhulEqcj7rdomU7IEmP/QNIJx9ZzqXgmQvpVM
VurPCk55J87FFvAPXN9VCT/nJaPsd315WJvwuqV9vmrfrb0ZAWw6xDRMC7KJM4UDXwB1wpXkdZN0
GZLhnSD7RJZ7kzuYZvwzfMOV6z66tBuJW9satcDTeUQL+QL8A+ulfTqlketlVGgFnLJdATmSiZSY
Cq0CZPstEZve9V+37Ikt4TIg0if791JEwC8OVGh00qFnnCyidQJgUFyEjnIkrlI4vKrK6x16OzN/
LMLMBPuhNWhNB9ChEDjzvTtFwyY82fb/LtM6VblYiDhHca2yjFIMxrB4XBPhknxBLHu6vt+hW+S8
HMcAA8aXxSq27RDRHkn/LCy2qr76z+ZxpJMC1NxN+LMsnPytY+e60Azuimbf53jDgNm4fn8nIA80
VQ4WNrDW1Rg2eUDIk/IA4Lfx+2hcdApaXtBEvfl5p8oma4BJJ4BNkmW8HPYtLpFUCaxa4nq9UhMB
jB9UEA7yxxsvX7TclTLkY0/NVHQEv99oYQ9hZD5oadd2v6rJboWlGWgDEfUFE73L8cIk5cvX7j9j
e5swEN5mZX/pje+a22KYGa2yXyrU4EXcQtZx/CrAsAXoPfaFUIBq0Xz8rrsnHJyeZBlFetvF