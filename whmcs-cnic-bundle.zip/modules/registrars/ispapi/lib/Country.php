<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoMZWXrqZNTI0H4NFWWlNI6IrN0FOqH0du+u8Ajbh2TmF+QQfDl5d0KmgXuZfTxHwpMYY3T2
zFwwc+tzx+1jwP+4d6cImZt1S+QSbx2+0XJ9MCyQp0DO/1xTuPrt9ln6OG8lWFjxzPMxntGFj3TU
oXU07unyIk74TkH3lopmzPJasc1nCGy4HloN9d6VGRG/3m8JelUuhoRlvRG/IXeHfkxGIdI2tQZB
lPTn11XoVd8ckKhkK/tsGeCausWKwdGDOHpAHWZ1sttWcThuhoRzMugetx5gBPiO1qaAB346SDn6
voT2EA6uGgmWDS2BZ2CFlRnBuTDXtDH578NhnaZ02qmVLrumrGewwkisuKITekCZdAYVJE65M5CQ
EG3lWb8TGbOn7B+d0PjCBUmQno8Au6ixe6O4IoQFUV8ICw1yQRanNzAXu32K4XnL7pLONuI1VyAs
4pH8L55q4F5TLcWYooZDPvsnTeFzfFy0m8B426jBlP/bMyxYpRBjeWH/+4pYJCVaJ8Pbm25mmYE4
QtSfPpTqshks7TiR0T5BkAEDP9Ji0v1cKSOw0TIad/xg5h0zEkQa9+Rfe1bf54SCN1eGeiY0APS5
mFb/Z2GtrTJT8KQqoZeKlzcNy5NvKzHCz7KICaxZyJwHt5R2/tHzxg9BTFElIzgSyXxa8LYDvVCT
UXHjy37uMYdEkiZy/lKYXNxxrjKHO/NhYCcbVv0t/YhLcV84AwCwT+jLm2NvpHm1LHm51Zx9ZBXI
UznoZ5B3wEJb5PRkv5hAGYlo7ItS4V//vR1aYT708nbQ8GZOs2cz0QoPAwo9G4hbGjUKSH6165eE
TEqtYWLh34tajWwv7pQXRWrSBsCsro4CJ3yLp3waYRsuAJfwSCKpi1S3k9oe8H+rPb5leJ5NmWBK
lUodgQiZCK9lf1cOuZdoJaYQSFv72dNkX5LR5thXjCIcjLGQJaJABFjtoVffsoiltfzCA4lRavXb
tuwwUaZbleRLOCYc7z1sQ6lUNYV+GFgaDhT5L2mecwUjVEri+pVcE9aIlWR6/1S9XU7fGzBDfG8q
DwkntUsJ9ydlgrH1nKONxOZU+A4UYWyjS3CU1JlBjI824wouBewftc7xf0nsuyEhwisraTCW8yhI
MXtCq6V0WoE5gafXeofrTSIfxMeU32CC1KJUZbWYISfsT8My57C36rfs7fdAZonqbAtF3SJVib9w
bj/f+uIoAKS3CxYVviCY5vqGEIO2Vms0SKxjB8bJCnoowjj+QgqY5ODhg66lSMKu44sEdsPQBloS
aSWOCm2gPzVT2qkuJfzg5yzvLoqhU2PwTgnbjNvFsgG1USCaohStPxJvtkCHDv2FzQHB43JpxfL3
dGF3UZWv+XUFBg7gaocsTM+QZ9sAU8ojxmeOkwyaPXrz0LZr6oLvZO/ofKMHWJN7lYDFdqkL4M2G
AYdXP+nmu/MUCV9P21mprRBKB8FjWaoSf3NShK7qqwbT6U2dGaj+PRorGAI+rLDbOruZYfwAhoRu
5f3gcju09DOfh32Cfu7KazixcE3JlUNh9gQBWR1jvE1VxXQg6K3FEgwdprj6PBDFO4FY/auspaf8
Wus2w488xaRq/nITJbIIR1LqS92IulohP+/DoFouxoJvGEqNKOUB+bDRlmYNYX4U16DACBedeVPV
A89zQholM5fiPqMFCG3ePOs4QHzhgXvmN2j3FYYCUNarwVL4xZ15MI++LCA6N5oJLkBMVhwHWApr
b1c/hgzO1GIdQmD77+qz5wDl4w+M6oEHwqM2mdM7BqfIoeZAy9C0xLd5NUcy4OEiVC4sEwcLAlch
vnQtjr06bo0GpSdpAkAV15gJ/DQS/bzyv4DnY7SLQ5GMhLElQF1zO0hVSvDnB1JRJxE/HWHZ3n4l
4z4LY+aSsxIt6AGrwUXJxnBozVkuL9W9u6c67aqYjX4X4+PhQAshq90Ddp9K3brQaQgfeXdF7mXo
qGrzC5i3v0pQjxEoSp1SK/FHnTMye1XGYJuQ4yUfqoTCkkzkJ6GeZkP0OeiRLCDkPl80DJgShlwt
VU34YbteoWWDmGQ+DLqYn7Ep17ofgYjDQsdBG15QtmckRmwDATmY4WJnev1yrz7AejVXM0j5jDEQ
pB4=