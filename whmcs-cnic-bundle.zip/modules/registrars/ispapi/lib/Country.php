<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmE7v+PRQTp98ZLonK7b1gr2zLnYStM+MQ6ulY18G4j8hjVvvDuZgXSh2i4mMoIrGMDIBriD
7JFx6wBse6aKCnOd7z6Xs/2huT6KoPR4BKFertxNPlKXgdZGySXWYnBaDVf+rQ9VbGmUEeO1j6Ll
cVIU4nNJ52ChcUlFANWaBmq1cv6+O7JIMMX3Ig5GkOfSuPWZwk7KJinMbq6q5VfNw7ck6qHbvQt+
3pUFTYn/sGvVZaBtFnovXFGu8UlYwW507cZtcBlKA6H8ahe357dMXSM94zPcZ72F4HVNkPQ4QKuY
/2Tk9pGFzvNMpjVtYcZua07c7sB+Mn4aWbY68jqjvHqm4rfc47W4H44008wvEb5gKiK10tFet0Nz
JRteLcmJboRknigFfou+viumOHhExWIFAYNL+j8FPuGf54L1s+0n8UY1em5Jgdn9IWzzBXkvyZGB
QdAsdkdqBGLCvOwgXV2Q8N4B22D05DmTkM/hhq2HOcbfA+Zelkeb6bd0YddADIzbAySLcrgPnf9/
myist/WiRJsL93wUeeFFFo/dQ26NC+ri6aKLAscj8EZxulWQNaZgA8cRp1NXSbp4Dk3hO0Hf7Sgt
lz1zQZyAT1rWmtXGBiJSFX1VtoFrwnhiYOSK3yJmIypG27iKdPc7VxkclKGpOkr1o7kQ1H9JXi54
eWopUchYR5GqMO242tAYhl96NbsC7PTmY1EuC5jcjcCsycVQEzN0X6bDoo9obdrWgc6O5U/rBLes
flmrRjgTwG5k3uKdSGvTinPaylbGQldssaojw3R5R5yLXMp0beO0Gr/IB4z7rCHQOTtdf1wkEN97
spwI0d0MUr1wuPyes352RYgp1unCJFFda6FX8xd+HtpyO6cIUWCqNKJlWrJ+86r3Q4kY4P//AHMC
QKFZHiPD0iJywEr/sGd0Yint3xtROcCxewMnSe9wQQRvtgbn0hJKn/uqunlp/GCVJFGSq5CI3goz
KAdv2Sy8iDfP5mVGzGN2XyNf3V+gfcrM8veMghVckKacwL3/2aGL2hF4eGivN+pImJ02RwA0rbUr
kEgWOvLYvP3XZShMWxft6tJyt5aLxn4IUdtPLfhCdxatlfzktslZDGVdPRNzpNjgInAxVDBwvHw4
uUsVtNXnvY3eYEjrR9V3pI0ivcoCYrQJCcN6rinC/ExUFjHadwOooJvKzTplL4JalQmcCS2+3oC/
xme79a5JP0typeCcnOsV7m6PX33jgZ/egNn77Dxgzqil73DsOA9bC2GOVemVoBhAEfnKe2HzMQSo
2X0/UYfJeKLc9d9MKlnjc6Qpd/LEwiBWHaU3+heJOZBTt1OqZh87UIQvhJwxjHCS/ufk1q0PmIok
bVmY22j7yWJblRFeRrYEd6tlWWKNTYF4lCOwCqjxRP8YXfZAh03hMmW96WdCHHHI6qy/PFyJkurH
f3WRa9HOZDw/O9Ksdt44EmESOGDDbJI+MKlsz8li52IhhO+WtRb43rRDderJrqVDyBcqvMU0bWo3
JYcKQprYU1CR1VzQrrCA/YRQYuEVmbsY8WYRbCPJHHbksRs3L0T7mFbwY/Yd8Sa1rR1MSsv8OnbH
0nqWbKBpT2S5e6OUSBGtPUKEZ4W6HYnHKkhSW0jOaFLsJHWBTpPVBs6kRwN563inpO+gUg0fyJ72
NbiBPuYY75d5dNi6RivtALEgTHCWNaMTq+Z6KGVc088/mf8oGabTVi8HOJ6Okd8Rx4+Rug+JI3/I
LIuL4GzUHvpZwqX76x5Y8lQjM0hi9+QEWxrl327DWLSf9JJNIbx3QmExT08XiNWVM5plTREIGKqi
Zn4LGUWoGgxH6vEPbTnMH27bm/fefHOsRa7HMdtFeDTHeVloYWs18EV790pW2tH8dnZ5FYrhXYSX
oIGJhPs46hML3KqJG/cQBusLAJHvqXGMRMIoCVfNdrHR7bl/psYBSjxbB1j+agtDwEbtesoqGmKi
KDaOb9bjcb/D4cxrKNXzgHdRJpt+y8lS859rKfkPZeq80P3O8W/8d/4h2qeeycCDVUXkHz2JKpjv
6vfNSAhidvNen7LAxo3VBBtfgnNd+woCE87p69+NBZL17gNNfZhTiFf5AX3wP0Im4loQeAR1xOD9
+we/ZV/ThW==