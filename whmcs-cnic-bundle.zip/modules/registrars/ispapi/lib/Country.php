<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw/FR1774LKdddtvCc8lHtjYp0QF24a3szHmqoeui6wuD+97vFSrMWkBEQwZk0PQitQIG8PM
bC3AnDqYuO//nzR665CZ3NBU90uGJyySWqF71qjkPMu+hP8H/nDC21n15lyOPOBODouDC/YLyg+C
WDgm3DBPHfURxjId0b8+wVOstka9NpGZkCyH6OP7nH2d+B5SUbxWGupOjiI/kTPEwYz5JQm8e1UJ
3Qrq0h39bR3o+WOceD5uWcJ6PU4ho7FWDDbs+nfyttnR8lj43fqn+qAsEbM5PXLRWtKode4eisFD
eTGdGl/DIgKro2Pq/jVGeNf/efHIBV2j80vl/lGU5PZyDflvuvidfudI1NM8Eaj/bIPeiunTa/AO
0TcBgwfLOKE9J0thHG3EuwEn9AP0xgglNf/L/hGmdnvcsoG3A0/nw9IvAOkb9e13+Ng6sMMzC3vB
pbM7ph3pz9t1+7YChEiK3FhXNoqJYv/AbbusGxviUNYIhm/jneCj3qSNBluHac4X5OYyArs+DdK4
vs4nlGrEm7QRP2FIrzqeG+7/XryuVvkTPsa3nC9zdwhv0iIQkhODejceW8WXpEx2QTIEHsmpZmRF
1TVSq1LaHt2sdk6SlBGjaekCBSNjUmewb8BExCnTIxXn/mfD0VJESWzohL3bgaGpGYm/PHIGmUT6
w4KsdZXe+mpDblMY96VgdqRo23cT8DyqK149kp4itjHNrBJZK1++Fj0Ra5ZzdBk2+rQmM8BymezU
mC+fNWv6VqJgfpHVQw7FVcBBZ2k1QvO2ONmzsbJdfJJEDEZtl/op5ttvwuBsg6e7gdv+DTq6nTNt
8cjbRqZurkCn3i/v1p5zeUxeP4nI+BxZarIU30Vksi+Odwthv8C/xFX5jLeFOGplROPabNY3/0Xv
FpZ/vw5+02CCTffgVgPluEaef/vWd6It3vKbF/ljL+EeVpSHDL8IRDwylGGg6o4xy6DMIy/Wmr8S
i1IIeHX7Lh0PMYkCaJf7izqQri8O79Br8XoSZh0TSEcB/TdUfsqMAbbSlF0AE83Ry0i6bd1uCQPk
6oWBl/kzL7+O9CRT1yLES4F6k4MOgbn/S6WEpHxfLL81oioiQVxf/XdQbZkxFjcE+OZycTlPYH4R
ivGxVce8SyS2a4YxrjGMYvQmk29btyOJOKriMlKLgRPOXqmiwgBbNuwywel12bvR84M92Vyk3KIs
Vj66gykZV4gg028YjTgBrimQQvsHvJe5oKHd3Xc9Un5LK0GhPvoeR16m00GFSo3UnylO97msfURF
Vun1KIN2D220z/Zay1EelYXy3oVy7k5Kpyx2ebutpWC8HVw+GPDKJaibPFyU8WZ2QTHTN5Am2hOr
WrfkwPcz9PgVRQJ8GmN1AKJSXQGoLAF04XNtN7bUzn5LjuGQY/zPuCuPxE0UXREhOjPKc5OgJK3/
NbALNJvHEUKrbvqXcUq95t+46MeSaHgWXN6lnT+OyTlPk7J4zxpQgPdRrg+hTZ9LqhEeqtDazjB/
0UpTHY33NcDpFTLqj3H4DfOCjWoMmH/1rQthfhjOJmz+eMeRIwfRlyR9CsIo6mzL7MBecEMrTqA0
GHbHXbsKOq9L6pQLGHdFE7asXALu8RqzKdYLJzydde+PJ1ugiewq0DofskfR9V0Hz384mQQf3do5
KJXDxObNfLiSnUZgGDDk/uqFLnVV/INWkuAwUQGXXD62dcztfBXI40JJ2lpMCwB31RMMR1E3PBc0
J0TJVIU2MoSGDoRZ9OUqKt32WZv5uW3CYJB/GEfk6ywv5J++PBltyoSFs2sGahIi5fbs5yhXGqk+
4kZep6BZ7QOoqV5YxE+3MmRNkA26jbOj/p9v/qMQJEkZ70q+XbB7Y7VHC2KzV+6JV38XFxbmfZKN
in09dSKYKQblMet+iVtgD86yGAiNfIPR+d8wFT4CmpHAMoWsZcFVAQWY9QFikHoG3w7hPEZOttar
oaPwnZimGVDdq8kdfEqR3+lFGeuOPpBVFd/pU/BR4MRwEZZRXC5T0VVNmdytgOtQkuWobonGstBH
SoJ8qlLD/QoXQ5kh0DPkwzeA7xILA9Q0mEIojyJOlqWWeyh7QFHYZOV+IR/Hfahv