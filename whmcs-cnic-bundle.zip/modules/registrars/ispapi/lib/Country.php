<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwRsXHVmNdvOZKGGD8mh96M+NemeYPJnYUDCH6j5v5waRZrLlCntoJ3TieKjywdwdZFPJtkh
cvVl7iyWBH7FEq6JlkJQagV6jca/UqJIpuqclBxMdKpIRRgT2rqnSSGDnU3G8thrEunhW+Tmrt7F
tWkQhKTZlTg5CEEmSd1uPq1N48POzV34MfEzfq/riYGu+IV/tyu53s2LMbcUDQZ7Q4Xu+PWA2Lb6
inm1ul6TxVENTGjoVQaX68jQkGIiB4iiPXV42S0ecS5h5/SQ9v2j2HIeQ9diQV+0EWcz3xhud2FN
vjudI/+kNSSLq1qGYL5MNwYJgZANc++iZxNBrkQWs5ZhXxy2fES7qbWFAwnDDe8H2eaSROgQg0Xf
A8rSv1n96e8gdF6p9AiJ6EYS+Dd3Q+HL77WwjZdFs6KgMVb6syc+sq85eAquECVD2BBDc9pnsGpy
ecr/h+y87SiiI+6EV6t0CCfTmTu6BcaSiynW6nRaB2za3wHnX7I1nvASet/l5efF8kywJo/psI6T
blpwpfTqskv/edtgXdx9yR56J3TmqiGE5pyuPrpBtQmVG8PJog4mG+9xqFkvyFAxf6YZCbF+pXIU
Go6pAQtqiMbhSSCFtdGc7wfp79pCh+uZdRUOP6tB0tC/Ha+F4506321I7mE5LtBmo9XQXKN8/Dko
vL1ixjf7JIJpCjbutsKNSLaWs8dOo42dbg1ApRJIgNOqumNgo4Tdu8DBxncn52UV/3UuIzNiwTdv
OAIKX0cpaRnGAXsT5z5cmPLD912PH8lValXY7/cVVX4JnFAjiLPlPQozH96AxU6P6/TtcN2KKxSe
GZFkOdOBe5qY/jAXUk7FCbcGk9ISN4XIX5FMiVEYrWl0z97KpJAsL3/9mwtX2Ym9YYvvZTPjTts/
hHLRtuBs8ac1ThIgdpUkKoghMDN4elFmvc2h0OhVU0NOQQr8WfToC/lMSQ/iNo708k4UVhwBu1bx
qehe/G0pB0t/F+Q2KhtIw4uNKYSdLPSvVIF4nSFOBXGs80LQI6Vxt+cQ7wHIXmNp9j8ko79/3wRt
v7RcRhXVJa0K6JB8+QSBvx4lykLF15KcensOtu7Uw17dQoR4VjLNxzoVauB9PZrIJ2mBzgiFMpY6
8QyjitQbOCo6PxrgXY6f5iwCgvuzVX8pwKn0JouTC341lxxocXuTzjvitLYGYsk6VCIbUM5DY2l4
bSZXmOPugLFwtO4CqaVni2cfOW3toB5Wv1w6H0frFb/y47u/KRFfYUH8lxpTmPDM5f8G52ucPipE
oTbLoh22ufBy7ldaxqmKzp7dIokfXwoBreZLkx79OnFaZQl3Qdn4oGHtbjnRW4S2mpPeJoFsZW4/
9vn/6SYKO+kVfkFGg3wH7fv5jnSQZ2jH4eVtS7egDliKOPZs8Incq7435p6FFaduwHk/64e6hP1y
wS9imumhZKgw4drFNgngsTv5BR1D1SVmtUJG9lWb1nZoAThEzOXOeuNrd+zdWPhiYfyCAxgEGKma
o7zdGy92pb0ku3vRYyJn/lZjkTYT9c6OH7DGuzWEQciQvPAUlhMC3MrCCGN4E2rK2azYs7guqMnO
PdkwzpwkIrRFD6F687FW2HLBXRr1zploPcvZxjlg2j4DlnQbKVisTgFn+EQhua/IeBA9PnG03h5q
RMzgVeqhI0c/MAgXpjBCXJWBJXvwZMQtnTdLwer+c/QVZBIoPraIAkr0uPQ3A06rBtyQO7HpdYen
bOJzPeUS0fpRLNi1yMxhZc4DBz+J03NTnPkVEitaKWq1nS7d+MFH/Oj0DWoo1PQV1Zjvf87q4FUM
cIEZN26Am9nAgiEghMBf6WZDoDvaYdGTphjCaJFOATGQzdQuGCMizS9Aou6vx1mcDqCXjqux7Qj4
+o/Hu2WczXcjpwdz9EZZYdx9xec+BiQWBKYsWtPAVzXKpda7BrprEuxp+zqzVqWgOx6OR9MbS0EB
Skd9ZXKHddMJoDkGsokhthdlPcfuFgx0ro4icu2py9l1QrRL2zBO30VSyQdTo1w3Vsv0P58oYs5b
Zv93bwO+bJ69SmXfbaxrVLOwCgsAQOzySOW53n4vSSQNuVLDffploSefgNLfuJcI0BN5ixjG