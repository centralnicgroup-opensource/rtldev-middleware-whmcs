<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt49vpAFrji5Lhjo4NcyrS8EeNfyJh4CEOsufsJHEeJfDxrFnPdcOHK5m1ZnIK1B0aPTnud7
OVwJfmFaOlDpar9b5PoBl4fvidIXZEtH9s05bIpCOjLDloI2LcH+5P33MTFv/koY9XtyKrN4H3yg
rA9lOtt9Grj6S19VyVoHlnNOHguw7fH4Lyy3gJ/n6rC+l1hydBlg/XU+c257bdLIt/HpVdGjl3HP
RASBQEmKceRnOzDSK3uNI1UF9F0IVhApu5xtSjssbBeja4egBIOQXBJ+EFTcfwUVICwx4zPgH49D
mMWG4Fp6bJbe470xy6naopgH1UEGVLif1y8LhBkDPAUROSfXlz0cI5nDp6TbHwVgMPgI7rxB+neX
MGkxszxUq3UR1tYbn17OQFj17jPsEuKr31/PDy1ySA+IK3h0WRS3yMzJaMUBaViXj41u6ESBcAYI
c45inldjPZQotLSTT4UOkanqIB5S1Hd9e7womp20O5t9QsakdoOcyl0d7a6hZyD7Yh8FofDulWK0
bQXjNuU6ymo5eU0Z+RwtckO4utrMhQt4/9zSNvG2NhsZD2snZlvzDJbLqgLh40YEy9WGQcfbKZMB
Fl9ATFficA077dBrDsJK4hGIswLjLsZBKkG3MOfgvtuz8Ymtq3U5o79r8dLCTYAcr9+/4X5Rfhaa
5TqLLxwzqPpd5SIpk6RbAW1hjKPpoPqFZfIpLeXxC/XxrPbyTY7ke95zPqPuBbZzhgP9vCBDOht3
6wfcd82rubYkIkxGZWT1QFlgUTtngQiQVAPyolxOA+XeqgrHNgpCp+b0tO1sakCSYQObIA07nigG
Zg30BV0IdXMEeGM69qssV+P/dCTCEEzcBCe5kYC4lmScMhJCbsd/AUjyGivTqAJqWngh95psbpFv
CMO5uuksr52Ae+jxBF2p3P6swBjPALLlLfRSRqYOrPHJvo8sBilSEZPJuKbgNxdkBAaPviU/uc+Y
uMAljBUny2ebgKbssHTKIh6rp8ZIo2Rf/vUVq36/OERGqC5wRqUrurAyg2gbVYQzMr5I48CPImxa
pwYAOsJSRM0OoaCFZw6UdXn/cRibNmA3WicEYOGWXfLjueTbPpHJJvbIiWiY/Ymg+K6il9bGUreb
OO5w37a9ntKSHyhGrfSdjOB54+T4c8LYStlhhisTgxxrSzsN7iqwuZtp0qcGPyecdYRj1/TyeEHa
HTFDYG3wcGhlcBN2OpXZdwKwbSJGdCEAN7jDw1Wblz1Y/MO8yfckzv94TmddzCewBLwfRBxpL5vA
CzPE9bO9VEGiYBxAiFXPavo3cXpObiDU1ozS1xPnu4aD+BcJooL4BBNcwT6G5/ebV4W5xJxCfsoC
+C5vv47Nx1752xOV1pDbyYpM3Oqu5de/mwGAIUe8tPXGu3yZ5qigX1aKV7iOJ6rooMRKHmqdLyoo
41HCBkCj92NDHi4VRTXpVXtq27Iq3cOdill1kV+bw38fa4xmRvKxgPE3984gfK/xJzM3kc84/+61
53Q587HeMlwenLRXc6VVa3j2cCTAad/9gL81HmViGY2qlZ7/u+xPK27XqSX91oxiA+mUT6Ys5ygj
vFlym0yl6Zhc4UeuTdAWQc295eG/iNlW/baSlxXT7VTgMBVwzhKVVjLxOOkx77rPfPSLaqQK8o0P
7OAC75Hl0GmHuNEFmY1hzFoGbBdI4Im7s3q26ewT0dtc8/Is7eUAfWePpH+B8EJS+x7prhh8y3hb
79ToC8P+tdy3C03zNTDj+ioaT7s4XzcgkAAkrj4urXkKQwKtJzTGEO9T90C2rpGmtNte4VeiXGwn
t8HMl1QKvA6OobotU7KU+E3HfQVXu5h8mCQ5xmw/092d1pMZSQK2wsGrI5AoM5mbfCz+l+kejJ2Z
9dY1RpiDpi2x9QzAmKtKV88zRG816Y9/zSibumYMDfHAMYN7k2clDtODZ+4UeRw3Czpc2QqPaMbk
sI91QMnBVOjRBeFGLFWpsQw/J7Q7NETNKFT+pdzvxNk4SAcTXnqLjB1XxOz165ej/eA59d67ap6i
Kgnh7p1vSwx3ecEJZZqkIPmP5angtf9B0PwjXGN8ip+PrtamboeDVHvhUJuI9sFe1OEB7fcgKAGH
L0==