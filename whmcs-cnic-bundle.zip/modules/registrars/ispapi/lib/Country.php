<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq1mw6HhtD1BSi9zH/g2g20ckrDJuwJOXTeu5ZQ3yxLnD5GDSl5mYi644NqgB9s0CpcLSH98
ol5WucHot041zPnD2XQX0+4XMumsq/1QQpRTXkV7TiEMW8Cd87vrnQjSJQDml0I/oAmkh4LLPkge
juPt7ZVYmzyXVikK/3DPKmO2UJOscFUfj/nWbb1QSdfwtFWzUMUgkbJTDRu2qskMEIuWlSh60kAs
A3VFXZZCfGQItLg8OBd7Tn5iZLokyLgUmn54DhoE9jJyXH2K2790wT8S1n6Ry6VOVEPZ+7nQan1C
IP41A1F/3iJsRD/LG5L87Mn8Ho2D2XKJ6WaOm77OB2YpNIaz9NQahRjVzPTvXbNH3wXJY+PhmBny
HK7uUFACMq8vEwze2jjt+sno3b8hkn7muH3Pd1zsrkXDSLbLIeHfuD53za89Qxlic250zHcUt/7p
ej+tab/VIyihX2Ho62GiAOBRnsdx2a5yh79sumZ+SmBqyFkiwqd4M81jcHHgLQ/eKyQQEtuQZAL9
JCxur9Z8Q9YHrrKHpYi7M62o00rzh+qPYqPMnH88dEX2C6zwgjDbqJ3NNkyuM39v6oX8NxhBp4fX
9LJ4LP4JG8kYBStNLQoQJSaFUShGYCcUMb3xlurNe1u8VF+qYqx8RTHKLi+vuaFAqyyqOQvWZQ/h
kGl5WV0B5hsEJxQfTDSTan9qv+hTU55K//H/mFktNHsUEZSKJVO/iw8KLsiTk20Dw6UzKwCE+5/M
yRv+02438DRGftkOi/yFxxpNjK0/iA9GVh7h19LLHd7YgtM8q/v2FHrdZAmYi46G1w/VZPulq1Q7
Zg3wgWd7LGFaZt8Dprzr+WsZAe0m2r0Ca2v2qpPywbzHATw6BlMWKNtg5wIN0n7INyHo0hT5HElz
qpiWHL9VNW7QZ2bOn7htN2GL/TnBHt8BeuIhXg+Mjb8sgXLWmQTe12nWLvIVitkeEFfc8padqmVt
DOR/S+WikOWMEskd3sICxYnYzcqJLBIXr1nNfqMpzrreGIUrWOPIgtzbTdyz966vRD56+2o61hur
LAoP/wQW/LPR30Md1DAtJukdB7TV/ORkhi4FMzRx60Atzh6ty9GtYLOd0XtQ/3+BwdAQVh9nzLUj
9iEsN4H/H07i4sZvYIctXFstIFXlBB0BTHHHk1kf15Ij0kQkchfAfmRanIbbfDm1A20d+AoPKQsm
YjTnufvIOrsK0EpVFXfkOJj7Zw+wZ8GQHQ3QIjvHP1jHp5bCCbz9uTP+HWYfo9tOduOXEwT2aR34
T7jCnHOuMDf822eamfRYdGtx3tRzfJBbH4lCnEBZbNgo1r4Cs1LGV6CX62lP2T3UxjxmCk2QTmFP
H8W97apuYs43LF++Of0vKQAgrWfohQPYWxtIFREu9UfuFUCBDwoRW6FwyQ86Yu0qRZKETYM/FgLk
V6S3IhQLmaW6+lFbWelzY4zPfx6BPkJF1PotHbrYu9yGtMDNrhxUWx/gVhNj0A+gW4tlUttZ5aFH
2Y9wJ7opuczGS6t6tbJbZqWvkLHjtBGogXq4Bvv+fCxlWaNR7I+60LfAG+NuPX6EEaZrOex7Bp3x
nbnQT3s7rIkxZto6MOGBTwZJ+F3MuSabeCMSRQOCxAYFFrQ7MtWFu+1WJ3UjnrURrHRVO73z2aFh
kzwpfq/o0lqos1zTT3hOUFzUz5hv5a9NMtrau4otljXsu6JurwjZ21D0aIQ50kRcy846HKWcHyPD
tJfOZBxdR2pKxSM4DofV+B7s/PPQ+sbfIPiHHFJi/YMMOZ+vXL8fdB6w6SRoDMXt2qC/9kl2hias
++Ha02c2m+LE3xHv67UuwsaIFkcQtM8JudqLczecy+WpFbfGL3lF6jeZb1SP9dFcrmnQXQzKFqcX
+KG3cvbjFvprSkDvmSJm5RMlpl+vpHrB9icm8s3upYSZ/bMIqssz3HQViHjXOCeuMkA0pIJEl5OD
XBSqLFa796BDbF7qn7YHK7ISBDSeSSm9yRtb00qAgYmz+RlPHTJlVdQWSJ5wCr+RPxyu29v4Wgna
Xyw1vNLfx5Vdyu5NIjGH7WLP9UMVSt6zTGv5uUi7lGaGIqIFOXcy3RDHdSWY