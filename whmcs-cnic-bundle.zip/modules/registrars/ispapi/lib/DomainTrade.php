<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+JI8mSeTvWeDHks94uiowavnOz2bISg3keZORmqcj21em5IqQD7EDmNFI6RYIcgHDgXtjhk
B9Ys+dANOl/b1ZaD3BMJHlKe0keMZ2LVn6+y9bzs/LNM+Jckrkyn5tZSXxS8pgFYbXnUq1XdIBr8
aBnaS7Z65Q2aY22ciE4Q6jPALu7lQRX6jx+8kCgSB+/nZxBxwQY4neGwqlUs2FKQol9vN5VG9X8x
f3STP4p9quwNYg6fTI/3f/xlFlCL8xNfJ2rmmfNASjssbBeja4egBIOQXBJ+EFjhyP8Uz08YHZdD
Kq8jLgTWeJrLYH6j2apu5u1meq860IGm9npMbS2zNHDkisncr+K9yyz3rIXU7f3qzY01kICem6SB
vvxYWMaZmrY0FsZ2PDf4OqG4zTUMIQ5KpO9M3HYF52lC4tgEXjexpQ2aR2DQlE2eQVl8uk5ussio
uQrx6vLhswBVSH4PbdtUNezYfDG6nDC1+RSFEcmdUDhR3fLO4tfYCa9l7h/Mq232q+Ks0htXW3Ca
NPH4/ViKVYzNWn6QO56E46b6CsVsI8kmSwmsFb7FsQzoNmvLdGFlIVXEQxkMUW+fhEFg2h4+RKZD
UvhPwjP/Vr1DwoogZm20BztXKDFrztwcbSxIfAkLkvTUidGny6ULZj3QGf1saNTs/brhBnputWcA
jOJGSVaD9STIXHWIpA95wBiHFSAXN4U2dQT1s3fqk04/g3vkfmps+qrhmjheXMBTZUaSRvT4M+aw
1Q6tnylFFqmmloRsZjId7GhktCtldd7zS0XLisXfybEQzMJNND6XzWN/3BZgkldW3/GXeL/bLGJz
6EdR698f34GWe2cp6HfmObQ7Lm5f2bDQAHl2HjkN23q1wjNozQjo4A8bmYO5UGfE5eqPFwMyYzIt
LQU5nQbRJvnvEfEZAd1u7GX7aIMKNXYWSX4GVP0cQ9Y569XotDcUsBxy39BHF/3Vuhuh8wjqXDYY
AoQoj5acusqOYDGE1E9CzaFoKF37L8C6+vazCWHc6tIvcb/7A/m/qhV5ijenC04ivVvPnmQuVLbq
bMWgikFftkedVn5FrwlADtml9hlF2qFMOcn5ZPo939+N2DThHYZ6Mn04ncmgPTmgXDN3ggEpXDWf
K5ocXEuGZNBVdAj7yBukciwK1vIFph4TW2oDyN+fmHvb/Cy0bn+yGGpafVmFPxE56jjeYjoFAHg8
zovvvWmiXCnIrMbYeg2gDKxgjqVFkjDIiuB4nNWQkX00IhX07wHSEJQjoLVFf7QF9mUX3zdYBClm
9t6ivmEuY5SZMMp3XAms72sLkz1C4wPLr50m1xgV1AUKNys5jEU+ZsUHIrnJxxqgqE6XmKFz9/ST
tsPFaRyVdRMAKybfL3v/7zMIAFrXW2BrYNxU9WLUpw9WmHg5nAvoxuEPXexoMVIRs00l9Yo0919Z
fr1X5addJE3EY43HqIEDkYSWhllNC6WRI501RUXmYtjC3a/a3uWQGihQOJvLs5p6fs+6UEYVGUX2
RVPNBalQeFHlXqdHzS3PTDCclhWbkBLSEtsBFQdSbQfcJHGCmSu8uSzilI8CpXxaFdtiH5EeJx9+
77mrb4MkWv5CEX7pe6ucPihNTiJEqV1NAn0wQIqf6F8JXnjO27iB9Rmo+gKkyIizshn9St/YCm2s
aq1o3w5U6XwYR1i8+bAZyLaYRrR/ORBRRCAmkKfpM6UKFn17qSYOdW26Z2zu2dzW0qVlfnhHmK0f
gwCoVerMxlN9Upi//21V6nUdtl88GEk9DG5Nu/8wnV5ddXd3xNGmUCKxLOaGb2dwB6wsjCqSj5NS
L5YQRA7EB840or114wQV9h1aIhdLByix8f1PMyVilDm4qyzq9hC2f6G66f+wzQ+Mkie8mI6UcvGB
sI8sIhkNiSLffmN/5mx5FRujXFkNTP4cIXPzU8CM0qKBnsj58I7mfueCEvA+O1WAgq0LpJJgrqXj
NKMn0hmExAvyB0CmJHtqznJL35XoBKnLaO1N/e0RaMlF/l5ltZupGucDu7TEXTo57qM1qNHd1/5Q
YMCwExhIR/ClmNTx+PLVmaehvEPD1bUOrMB7dMuWi8LNcyLTO8HvmFaiw1fUIEql0YhJlXiN18zJ
fo20NVAV0NzegLAjCR0lZgxsjBXw0Mylz1aH/obK1/CRBYeBYaaTElks3mgNUgPw6TcvLiWGqjCY
KTVcONb+/JKz+SkwObhSHoxBXKcAzwb2WFsDt6h7Cl2om3sQCw4wZR+yXM34zUv4BHomjZCkcekV
+tPGh51Dwpl2zfpdu5ZG+l+YbeyRZP0xULIfBMaGngfhAGFi2ytKNwXi/S7r83+8ESZqlHul7q6q
AJKGtgO4kK46y0q6lC1E8NqvOWc1u1V2iyDE/mMZD6KvTZNa2ekESG9Efbsei0XpTj7vAbTi2wtT
jbwhoQNROI+p5L4IXSrxJh2qVLTBdwrBSjIYiNTRc1ex8SsTCIPDQrjiWJOP8b3ElOd2LLzCQlw2
jQcGMB/xDUyPxvL6a2c7jbzmdatDQGu0ziaStHIbyeglmGJNi2Oru2W1h9n2prmg1c0g63vzKzBs
R7GqQB6hqqBIinAl6C18FJ+tVnZ9H2nCtLdzn331yQMxbT8JmLI2elUSj4KhlWZNCeezdtelEe10
Er9IuTZOmGuCa01/DsekxbrmHQr0WXmRMYb79OQZLcWzGY31IfXe01N2jKtjg0Mzq1ZEwjJuuZyu
OZ03SCYPol6XsCQvSw07DCsgWS8k9UWrgZHlFQVdW9wV/JCOlO3K209+zJesXHnC8HI82OHMDZIV
W5J6PdOQoKkiIM0FOFWWvN+XBR6woKqWqqHccg0UtcQjAMlpRUsTPlHSYONNdvOpKCIMrTeh6i6X
32je991qPCBLwJMnUSCsw9LlMIh0GkS3S0opsqKYG3qcJOxuE9JAaA1dzxShkV6QzwZgi7WKQSF3
fZXZ7tX5455bCrgFksNvOIUVEoSJltpc/ax2qpPartOrFd4pQO3PZGzezI9031XCqVhlmOlyaL6G
fusG2DsVCV+SbiEemxvbyry4/f9kMOFRIoStnxwoQVz06I9o5QSfBsiLDXy2KLTs+s8lukJNIJbi
Y+EuyIatxbX+CuPWQJcdhAujDUnjFpdHi8FD3IGd7diVmSZ6LcGHLJZ8IVl0BrUZKA4MDcn5kM9w
v8jSB91MfRJyyk4ql1Ev3xHMk4qRq13dH1JsfvO8z8G815qwrca/1q0GJMSB2d/xADVDBbVekI+J
bhKcKjTVk9DNGD7wU1CZvqIAat/81i8Go2/lsJSp/YM2B+EF27m8lfBQiUmMpQCcmEzxMhi88vv5
KjQLLFz3g/+Y2TVhEPlKuVazkHpGyLiZ0q+kUqCkSUyJzgHzN/nz7HO5GcyJrQqa++/hEWzt6rLe
dT9m/qCoPaz80k6O2vSE8qVlaAn56ZAnl3vel6SYAV2CXPKDxfzAiE53yXJLGD9ieMmna8egToTM
LZl84kE58Ac5PFpA+pSlO7uLJzyFylAL8ayVoOBG+i94JVhcdo7tNp38bApfWLLWUhpOAsv4dGDw
/tfwy45XKJsaIiI1cZtrcdD975XbBW5+A2k3RFrzyWo4oqF4Ig2gWiR30PffOWV3k51QDWua+g1Y
A/NhnGpCByJqU0h2JjLb4wkxHfgI8G3oee4FEAskvksGNUGIEWkh4gOjKAhuPTIfC9dCt5q5SArL
DXMNcbkuOM1TuJ3+ZFtJ8jdyE8deWWzfcjU2RLl2A5DfuuWUNttt2IdLmeq2jLgq22iZ4DNjeN/N
4nVTB8LnSypOfpkilaqagT6QDzM0VB99G10cHkEOgODQJWOha+h35tBo9thTGuygnx7sugNfwIBL
usD0ZpKUAJDB80OANg01HghiCZqs0XHWazuVMsn1nNWr2B3PFtKc79kQPAcjtAbAybXINmSGeKzu
jtZzYfNVUQ4wUUNGNBGZADkGrHT85K5v4CEljPa6EIvwpkJa4psgjyzxK33wbjAEBMIGNL7jlNwT
PIqqXp+Vk6uvQc93JoicUPIMyX40Rx/CrMabNm2+kpzD/4e7PUg1iuc6gDbGTrkEaOf7Uz5CsvuU
MYaiq+sC1lo/BptKNnB29Qqh1hp2Z2eECmHB7+lVFI7e6Ep4ly+luFRoqANZHO/glrb9PZv8mcbE
5cXtgxe5Zx/iDH+PwXp8haA8Y30=