<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwEUal27IcV7NbS7qqsx0uL9/ddkRyhG1EL1j9l2nGXh2BH0/Gw4ldVT2jGHlR6JReppIjFE
zcVvtjAw4P9YwkvTuk2fPJ4lCxuJoVqWDvMVChur58A5fgRL/pwNTknehbWlFlsrd23jEarHGOte
871ReUyl8KTtk/xANeg0kowgbLVh0liaYgIxQIyEUTk/cZbCiQVnIEtOZoJYHmPUJHzzzpdciCLI
tVhq3aMaYkiZ17qKOUmGorz1MoC1shSFa5ccYWvuwW2FAIcOyaxrHkcg39i4RPnvvzSSP6sZ3f4c
mVbc466Bg3y7imZaZLWdmOWRwWKBmDnIZZKlZsXjiVAAwg2A7v6TtePlEgrhobzfXq94ee8aUJvA
k04KqH9R7Cwu42HH4BhxnqxQvOVSe9A99IGlunoiNvcEvAgW6V0oMhrxQJxqaFzcWnjElzxvrAMf
WU8BXT95iuIiVc5DFfM9eKejBmXLDP83XF+VCtS4KjHCyaMXRuaOh/0Ut/CeRL+2vSGw/J9/BRvM
OkkwloNqZkA7Uwk9APTMFap+zMSUQbMEbvqpE6PiSdbU/NAxdhVbUCdL/UhPovIZsdaYS1RqsRQn
ODmwEji94NdBXlGq6JMDO7HQ3A0kC7v9Wg4p4q4tWSl+1qQe5SuYu6QgNzJcmv+ZA1xD6s2RC02a
EzTwbJlS1NAhfmdhxh5U8lFRGmlVpxCdsFIHtIBaplnxjRhPiSxzyzr740ZWAVxUqVuUnLj04ylf
D1LWMFtg4awvLK7d5F87v+2zvpl5z7FS5s+BPVK+3bAb+hbzzACTDIPod1YJktqVyjOmzHRpkGGw
J9tbbgv+emzzK5Ay61VEkiEkjf2yudN56cupxPE2J3s8Mu4Tv9aMB7A6slxt8p1RplukrmoPV5+g
vmRRLAu1g29Y0sTb5Qnick+Ji3JkGSAF68DC5X/afBwidfd9Wby37eniR8NUhZHkcJxpJ3RRhOkU
LWPcg4vASkheL1yrztdxelO+9THdO/ttZpXQ+wmY1k28KClfmpxBgVppf3JrmAMnkOVDnPBTSFPk
tlhEHLok6Vkqh3fZZk55DQ+n4ClOjzMFwM+NEGwXWZ2JEHk+QtqicuZ0Tvq7eBd2Qi6aT8y7+V6o
8FF8MW7E/TfJWDpxmPTag7EA3Z6cEq9QZlOMKYCvZHmurgHxkyEW5plPpU1oc4tdXqRz6mEGPg6o
jy8kMGC9QfNUhsyo1ArsIb5fku2FPD39G/lS4DY8SZbpOk8amclI/2pjRb8Q5mNkqjcExrvSUJMH
mYOOTihjXxqbbKbRJ1//8HGUswYZ/rpRKvUqJxQ6rXj2CV91kR+P6rC3c3zzJJ4epezVqw7WA8t+
qJUJq2WBcKESIdmBSFmhox7iLwrfNdrqDjCQnlUyGWI3YvqFTAIOZGedpU1ywFXuhKErPDi+9gI9
ZJzsAzrAp1YdGiAebVqZbvhvPI+lyUjKDp5Y6iBiW10OlNXl2slYSSt6fSjwACf1ah7FYsGnQCut
y81DMgBKAJw9E69Y6XcViAghS3BIFmTCm5IRETyeoVcQB92ZB/d+qpa3wURwbqBRiMaSCQHI4k/J
pAwbDelshsHuDwQp8UQf/7WTDNRJ9jglvCX6s3clOlEKgUppHPmTxvGoxCzRV8zkFG1NOZCKZhgS
uH9z2ux9CrA0PrhBbz8tQGdBO9qu/vHGkzrtFjJ5Ac33YYLnJCW0xiuFhO1JeVxIPeZUNmR56JWG
hUZeFQ/y26FSpLhLSOK8EYeb7i1qz1XoOr4thIneD8yb75doPMmqZd3HTmC+15tDAJB2KT1DbpKR
OI4u7kuOKZtc1aAdaVfE0igsSt8vHP/EIYl6ZPT2XtGQsVq4VZwONXZ4E5G7/zZgPG5C6BWFHowL
6qZ5wQ7ysvI5cA61rx+wa8GaQdNK9ljW90r/Hwk1KOXEjaFTLFVMlAm4DQ0Qx3gU8KoLLd6phs97
8+4MVSWuGSZK1taqDDfT8dUsTQP8LyXiesyXjoZ7LM0EwJgfAoCQ5OL05NNrjAryCal/RRftClig
yFv8n5uD+oGEMbttNtL2E5a6/ivF2/wHTsH8ZpNIOq3ZptgMunpLJPTdkB4iC6gdkurXiHaj5J2C
5AJLWoqnh89LzaVjSTQYwBZz7L/rdmEWAbPdrBcvkDQSBs4hnRhoDIT0/l/o+VMAFVTS7gDWdQtU
0h45tmsYulBOJJuRPaAxtIqK3OXVgjrp3eZJkqqaf9vFzdfuuY4NKBtWaMBRfXLQeGGrtNxFvWtm
jF6DBy02mqr2W9YDFOidZ3k/pUJAe8BDONsLxYd0G7oTJnMKR0VwcBwlNIIqI9IGDkmJNzhd655v
OhS/EpjUBcQQblVDb8F930U2ydT6S4iPmP/g6PZF6Ho88x/D0wA6AUTwm4ew5oPjP9iDLN2Ue0cU
7JY0mAUeAmuM2df5zEvSbvATAOrq+2f0yUhxzYirW0FDVWFMhJKdU5oGzXavOsqRuNN1MGocZ0/8
mfZET4XDJcRFvb6PZpCloFbwEyE7HG96IMVsTyn9MGHQMdX7zSiIeZcstTSbcGapKyX+ndn/ClD9
UbNwX7s2IPrTkROvfWV6aXPCGiW8xFdJrvIp6KFcOaLOG9HDUrFYa/Jny4U9xHPrxdwVqqonCT2W
K5G9xM6VHrxEGcWObT6wSW4+azqD9G/oeqcJhLzw5b3JtMTOwZ9JILSJDHRlZa7870RoWZTq72mi
MMnhsH2xuglL5SiU0tex6RQdlgQ75HrIXX7jkeB+B1S2Wa9EJgHlIKlcib66POiTzzCQ4mJFN3M5
yCChVgPhFMZDTgNjQwgI/SvJDNAHu4or0gJG69aufXWX5mKjc2mEdbcqLuvSRfVUME9nLO/BZn4W
VrmqWvixkk6cKAPnGW6E+vRv/X+NAjNXZ6ByyKKo17/IcyEmfoV3aVK6xjiSOiUUx/CF8qIOeQXQ
uN4VUFTHdkKf0owy7TtlW842YEriw9mHqh/8R1rc9Mi8xRV9nfv9WqbMe1tMoWSSyoMBYcGbS98C
4jpHjO6WAtjCX1ArnQWfLvqZPrZfgZdcEPhMBQQ8wWhMvtg/+U3/pOdIdSLjQHt3ONmgE+bXZcwl
HzMQULYUPELexjyEhilWxMHJlbZTPT7x+VR60iNbYemsSxc4x5MWbNfcIwIcuuSLp7FBlR0bEv3Z
NRoT2/nm3mbYRc6R/1DjLaBKa6Sty3yVzvwreUGxekVDc0Bkh0PQzLH5A8wQE1c+Ddg9VjFhEX02
EY8kMZt8WQld7wpHcAWjVg/D1C1Vlom+EjTuCtXEDeO85ov6PMq1Map9SHzQfhoYga53jVmJilMQ
K5e/2OTAf1iLqSBPFxWzCq+nEPX0nM0uY6Ru7RAAivI0actlWT1Tli2CQGJDxsM/t5oGfHV6yfQG
9X9YPLjKY18gQMpTZO7iwwilPXc0hLm11BNS9nH3SvikwqtNNwbLeOmftFOkdCqkq/hz9T7yVDmb
e/7kDZ8RZY6bwgBbB5PIe3ZyhLKIkbAUaFjOMZDTyRTei3z5qUjL4O0SAZAMwySMI6znRJH5/BLz
xiUB1QA9WYMIN1uukiyQYXOH+kLhKvoUAk3/jpU03xUAcEI5Ce48aD4gWib7gRL+YMqh3rJOr66t
5vzjBQArrWvjzFeDGOROZmVDBN7S0AF7hoejOGVFFLFgmf8lSdDIDd9fJ3yn/HzLxAidb2uZthU4
v3anAhvDFxLINng+q8IAc05W7c+A/EoGf0ScBu36+1epec80PzasmguG2gD4Fki7UkdLnNQG/21W
PpCnr52MGa/usgx90h1P88C4r3gzwpeO/r5N4w+aigPLcAHMD2OhrbMrDzCh1vWGqibTa7Yh26xh
DkAdwQzdi8SYm5xt5fNS1+XsP7EHldfIp8yN3ws3MZwsPuYtoLBuW0eXAgEUzImvh1r/Q4og6tFO
IgnNDBofcfzOyFIVzL7RxEMbvRETYbCezrkpre4x2KSBO44KEAfQuLIkYCmjoHnoUEzLDln2aGrT
WEX+RiPS95f5elG2SAj7ijG9GBY0e1OfODi9ye1bMUOaKIbUyILaTOaDzXAYXOaIEo0JQKh2lkgG
BPVeJrv7SEcDyItA7FBqhPkkQc/ldB7k86HCPfUdX4BHKowozGo3SL4hjdjGHSUxNW4pcLoYaZJ9
MMvRN/JEZd9v+CSbv/vUS+tHcuMxVXAkqx77QvvNNhqXCZvomSlggAfcwYHCjBnQlGxQ