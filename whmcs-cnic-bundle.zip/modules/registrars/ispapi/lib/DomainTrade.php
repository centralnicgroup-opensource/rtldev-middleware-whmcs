<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmhLyE8wTidLmnnbmK2lC5CZ36JFxXR8he+uA9pSo1cqWp7b3mAdoW4xuh95lILssBjZeneD
mrea+2aiNx/j/7GMc3u8+lKZBBDoIBXM18jcTbtZrWXwFLzaeVXfXNhBEPZ/gNPtSv5cD/yBUvk0
YfKKW+xPOLjAUW2ATHV4LDgFWWuplPrW93BZCh7Z+ZrWz1eelqQuP7J9wBcD0MaObnWElOY1Gb/q
flqopMoL9lZi89jcZiwyclE9G6/VrsP+UXnPAzyM9OqV3uQwVOh17D/d/71eBBO2BgJrRRQ6VKsd
UKXMofRQ5zfwb7noYa0SLBxCwf0LCfPNn1zS+2FQK2vxdPgFy8ExC8AhlfFw4XZAXLt9K424vCFj
2ERVFYV0ir7y0H4uWlUt7r7BxfhQdDhpKUzPYcM+3v7kHmhiyCplwPXc6AhBh54mY8vLTeq1+3yk
CfJKBlVibS2dtggRwx0lX5qbp/lMcAnIsPlRrmHyu+81rpJZ7rnkFtYlQqtkHwU5MoNCmhhdwJWo
pNHUrvBkduo3I9HAnys7E6l6/gmQheHPwco/N3d9EqiLGLgMhdyKucS22rQtZDGVzz8zOJNneopB
8X6VKcuVBKA4Hd88YvNXggtmqcIvA2bFqsiVK5PxeT4pReGXbJ3/j+s5G3cj+kyBPDe+1bs0QKX3
46caW4HT9D9KbZ0ByoQ9fCh8zlckzvFrOYIA+n87GibQP328EE1lnHqPYjjRsrz/79jYyXTv0iEm
YTImclbgq0iEvap5uYx6Qtxli5z5rql0rOYQ12JiQP5BrXtfQaAMnzp5KnLXW9otpBdDOqfiMtdG
jRf6vUZ/POKuwJeQREM5aIFmLT1zqHd9VBIYLChj+QGQrYgs0gEAHYb89QxAiW7lWhYETVdRCko3
VPP32lwLcFzFKw2MFv61hG8dBmbR97H9YpGmOoW+4EFoTTRdJd15XkvTwezxSXViqeWTYyfw1dlF
fmBu9Q490L5M84tszSBPnBfZA2ejyXBMxKLRStvjy6WtZFCkQyRG9kICGIDoEcJxmkQzhbKYrmIS
jZfqR/s7+S+OTwFTZSkXZYcYKhcf3jTQBSV2E1M/J83jTR7slga3SovXvNdC61BV7obIMIdU5qUA
12DAM2hN0rw0+5GbONkJqw69Rl0W4qiaVgNlaAMAJrdFH7Y0Qu/lD+wKT783DCRHwN9nxs968+JI
5EvnEn8rSX2P/HDZSmkqYaYzFuRiWNp35jA1vy2dr1zYKQcg4Gr+Z6H1aen6e9vckM4bTBZ68W7b
71U3tUJecHhptwc2oUGQnBmK7VcEQEI0GGtla+HRMHcAg1STj10t5d9d/uKS3eiDf4VwrSfaYwCw
Pzk0QziO+ncmpXH3KFiwEfZ1ewPJ/gcrE7tACb3sxpeFlYwvIbx3daEJ8hgKxu3qoi4dZI2ZIvOi
GYA3ef6EzMZio4L7eKwDlnyPnMdXmFJ1chDpolK/GbU9IoKLXlpBHGzIg4Ef9WnVlkL+9BL3z8D3
pXE/FSg3T6fZuuM+XAbu1i9Lrhbh5HZSzyDWXYIv4SC6+yBhsiUrkbFgRs7iWghyqI3BHpiiUjXS
gTtWh8RYP5hqgRhc73HfZmecFGMkmoJKvTqkTwXc/WfvNtUp7CFcMzGeJhADHfW+1zwm7OIg5PaP
hT/MZ8nrDvncPyTU1YZ/XF3lW2rQOOajZU7cB64EpFdZaJRs/M6hcH6FXf3l9oMJ41vk/gv/8ksf
hVy2vEJOUJx9OMdy/3UNN4LV6V1jEgjOmK0Aclh1FWYFjrltrf2slXFKGDOLCXJCwWt4dcn48O8a
gH3l7bQneshsgu/aN3Op1rNWXnEW45CflhStfRBTor5F3EqDNPIfbr/P5Cn5x5fS/uUt0q/XqJXY
IjB5JZDP61pdQM2VBMoKNNyT67ROMUu1r5ad1df72G2vKzfxPu/6cYeoGDVTBk2pcFClwsevn826
MaWVuS21fUqx2J1bcspxlLV3uYPFyUWNxZXmdyb6IZJZJylwcyGFWdnUIlyYCZWRkfgmmXAPpYL6
e3KLsNdUJltKpXGbEUrmfen5D02N5mYSX0iAVE34pdOljFp7/hV1HwssSOccEtoxgKz8jsJMyQtP
iNVVE0YzBL4Js4yupsoXdmu2jOGlAdajNuIETD4A6nc2xz77MSUMd/R3ZsCBy34YDfnWr2VHU8gE
6aJx7jMWZ/tbk2PNyI7UDR0njnkPjT0Z89trbjbq8Vv9HiF1cOR96A+6RfFiZ9+7PMthQdafO/bl
vXRv/6kMZJymKxk0wN84g2UsCehbqHDeB00MYf7fIItPp7bG3lqDD+++tVa4QWTekF2s2Kq6/QZ9
vYdu1KSKXSiQrW6VkhjM5MTbQ8E5yYB4w0yVLVcuxsnXAqKzJPOiREdl2z2TgEp2atxZde1jgleE
g0ny+0x2emctyAQXY3L9pSds9ev//PMwA+2Hw0c0Z4LDBfuTSw9fi8luviiRYsn3HJJg3a6H7EFe
0J2+Dt11y2jevktB9OSluFnFEgpAe1L0ok4/B2IKA89n8NOAZOppBeCQ89OPfqWty6bjaGm81bg1
PZFd226Um2vNUGWMJPj9akak+qOSPmARmHY2NeYA+vkYUMX7qvrElMDzL4Q6D3OwHKIguAGS9+Tr
eQ0LX1j/a7xKz9O3kxRdwyG+HSPVXlQXsqrTTnbfa18ST8Pxo76EKyrSKGgXi2xUgk/z3iWHw9vB
QkKGcIvfR8uMlaNakfYh41qkVN3goANV1Rw/H2v5kqGHjc44SKhTnA//QIWM2Wy0qTMK7B2qqdAI
pVF1OUwmvgiiEZLOBOfx5TrtDxyu33XkXgEHQswqCBUOITWXzRhTFoMRVSeNQy1Yl4rb7YEfUV1T
m8LzEymKx6X2MkuTqtNffiUm6FsV9pL+6hNmu69T229Q6YSQ3gLdpiXNItzPiN+sBEOFM0wENe15
fh60H0AWyTXG2ds3HmHzJb4WbizT72MsuyaAig3gAIcEgsjOltM0n5dHZcHP82haelL7tyU6tjjE
EUunBYZ6JpeZLDZD/UXIdX69+2hlODd/gpgeMlfIijPOl34w0dDHBXAEFaVmfPUu5Et26tU3NSIe
3ce4SRL5DPkwO0K/AigBA3jSahaxcKXMoRkrkoRVS0UAAkCQzl518EqeK6rynkAqfDdLsLwS0cMC
BNZEhjuSSg6redQ72goXi7uLbQMRYtSLHH9KuHWVQxRI+t3AGbxF8iYePnxjsWndMRmC24nmoayH
XwaMLjjXMnWrsJUWothur/+93eg8tNT+tNeLzEpgiApaertrP9zzfgcyOvRHFUAXrrWAMAJcoFBq
JdJjaIlP0Y0PFWMEW2DX2p8qsmiSipX7+mwtWNS46LO4b+v89tDYmuj9wxuCLBBjlTAO9PvYpFuR
/x5OS6s9ITFP+XVTJyx0pWPUAVCTVLkwA8wfKy+QXdi5n0ZxaViEdm/Tkv34RSlwetTRYZS5vT97
MBHGisQwb6b+h/kBlDtN14zkf01sfbzCTQQCnxNdQQwQQgwpWs8QfBr3l0fLiAqqOehUAc5zeaBB
5VpMVe8wdt4Qwx9tHSuZjPllD7yVK2/xWuGmuAgFOuY1ufNcuk5ejtXY6Zrd1r92mOlAqaNK04yo
bvA4g2xrJ1SOle/lAkUQkIwxvxiINB2ZRvITl8Nl1BXFhyC3mTw4IPlMgNgAQflJ2tNPMMEVRP1+
pg8PsAPlZnP1iYNkaOvshWTgatWF7p9upR85NsqYPcOXythdNwYvU2KgC+kAZsnaCCoOoKBeAh8O
Ej2KA5Tr1erVKTpPBOCQ7F4p3Sl9wMnW//kvquh8NxkGsP41dkKaacuUatJtoj8lAPl5yLVWOMM9
2LofIM+vWNOCcDx4Wlc6bSs+L+t3x1BdD1VqNPA/E2W+LAEsoWYj6V4tlIEWj9eT02p6i6jETrDN
rnpJPyVyN4AcOkjxbjI0R3Zn+sxRy1rw9t90wHin/+GbURItlmsX4relLb+YjieNptv20Msb2b09
pfrLo+Xt4s2QasclwfTifDGhsGx1pXxR9/xSDDV+kOFD1rg25wFhd8rivGpsII592WrM97P9Be4w
XLaAH45ieOqfhE/nvqADQdKtMh5pELIXH93iS7U8Ne62DeFThSr73uYpzHS/vcCRpRpqzLPVjXdl
NPEnLjPSP1D5aFWNf8Hz8WPInL+jQ7YnBByt1W==