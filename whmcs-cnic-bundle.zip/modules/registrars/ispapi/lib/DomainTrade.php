<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsSOWrdGpNUUhT4MUZgVFmtHa5f0aEHUIOAuFdCBCdYPBTBmljE36gvNMBAf1FMDt5b/ksd2
nXF4YKpuLSeoNyq290GbRIXMG0MqcEDJoe4UT3qQVLYsw9EY8qoN1hCOm6yl7K/CpxfI1iA0yxVj
TFty/8QAw1l3So/f2V42FwQ+lxZHiY5n1XrGfmPr3MqJBadBcCkvovA1CSFhO2HLjmFDV3YmhCnz
MVfwAb0bP9nN7Hp0fveKHPwhnLALxYq2GFnyEPx11iLtV7WoGwx5smpwtVzzPLFB9vQm1hnVyi/d
DeTF/y9rnS0gltBR9gyG1UJrmMpt6ROWG/1mc/Pap6UTYc/8E9KpEAIGfU5GDXG0r40sJx60B7kZ
XoNlWf7SalfLMAWKJTjmESVickCXRjIuBYcPfprvdrpAplZCND0iuWZqSrzJrYsB6+cUbtlt/zm2
1rcmPK7QTWpxf4x0TdkUiT9BRHz/47aI7k9GtD5LtADKy9Q+mVST96izrJOxdoukpMsJsNis8ylt
SOEs66BBqOlTlBtMGesVRmCe1m5SURRp5tU4y1DoELMp/iEFAbSDjgBLXn9aKigkUwwCm/BzQN1E
446SreOsfP3dnSVyKI4b7T3SQzR6a78gDNZkTq8bbXx/duiUJyhB8Fy0KnIaQY/M1Ly/P7utHSrS
GcK0s5p6jRsL4jvRxKDl8A6e4+ltfa5wPTpPftcGbfJcelov1eOwFHhgDv6HXKE9iGNcVpNILCfb
dHQay9W8h6skO3tPCFF4Rzl+V4A9A6wl/sQwwHvlaXcgyAPUpwDnUFyRZx5eccje9LlmJdx8S2zm
vwFc3rlVtudI56WpXtTqCY98GxkCt2jX97zK0QL+9rDAJhGj4a8oi9Dmfk2wR/2msxImIVRrUGbG
ZP6Kk4JcgUgtEO76e12ByA07vjFBurycj5iIQ3HiA4fJ+tLKOPirJPAbmiz8IUUvekk5d5sKHt9t
BvvhVV+3o9gJCG7e6LrhfzW2MznS6nItLvqbmeVU1y4304ImrxkO+m279S5A3EvZtH7Qvz0+QHKk
WaHY8Bbq7CVf1pKbsGMNIQdcutw6HdV/0XPqM2JTa2+4zrOIi8HGtqIn9n1EApXTbjkmhqaviR3f
+w17N73PqkkdNmDx7k3Iy/M57JVFgA5N5nnQZBw1Pf8TR3K0+rm1gF3fL4ATQ/0pavZ+u+SRmcHk
LV+tJ5n0h+/WvUpmcBpB6vZsvy2xprZjNb1RpCByfmNBMX/T76X6DAh2ZelJTvSY3LjSbJPN9rNu
LrBzuqnuE7hd1/gNCltRw232spUs3Ghhwy3RIe7uRzG1JIbJgR9J7uUMFwC4sk+m75oG8Ly25T8h
cgwCqdi8ahljUZ7/H5OpscpoAtlNhKNKG5gme9/k8r5dOMolskJE6mgMPyzrOZTPPOouRnY3WOzv
Sq0aRUXKNqbrjl2IuZvVOCL5+dNJ1dIP9BotZLLuwAVDodJIc8ie9L8t5Vh2JtRTq7yxV7mZ5kzi
Fe56ORNjCnIGSivEZ2r34Una3f+9DC3tZcojKysWkiVZprxhvovD/LeAAAUlxv++/Pdhm0G9kk6q
Ze+P1tOzpiNpU+7IY1s4zhz1j3/LlLEe5DNyUTCk88zYdNzxE6aJD9EjVUqaV2IcQp8SWvr2Vl/Y
usgksAM3iXgxVJQMGzRM4p1dQ0whvjSSbZIYksaqMCskM/0QHwPQRe+RxWvyHmgxxHFYxz4uGxb4
NprEWvotRyIxotsYC2tMSL/dZvuscVmtPMemXPGGME5knV+C0ATvxlqo/qZBb30Gl7mIUGECpYeW
mvu1Zt8CTnHmzdoLLAgtQVQoiHeoP1hyaKKPgmhLPYYdegPHQM+T2blqMvscG9rPbWP/Q4RZ6Gx2
7W50vC3z7XDBBqg9a/1lToKFpY1PqcI6WxtLWquwbi1ZnXU+66R4YXsT4qhHTCfr44jfqW82SfHt
yjuCFlwud+usQXL0bEAeH5v2MPNxoNTBCmNkw6YOK6EJ7hx4c3ZBasBs5+VeC2rY0D8gKwAIVBdh
llafk/sxIouf2VZNlT7BmMJ9imLdaagpUDsqme8Rovc4bZBdWOtWUZF22Zxxs/baXuOhO3exvrZg
g51qL/9Al4AfarbvbpbsyQZSiFW5AbCR60C2iqxCLd5ZXMYIpLSfg0WAc/2ycXijayfznSvBUgsP
2Jt5eLsSFry1Q3d/Z9W+5v05uyLR+QxTFaA+N/oA+QP4/pkGYLgoBL0AvfCqi4Xr0tw/qdfHL4Ef
176ZGdOu8EZ57irV+Q2Rt4A6eETeit0a3SL9bZORuqZoVjlni8hvjPeZDh3rLBwNhrCN8mF8TTap
KWNf3Y7dVmbcx1zNkR96NGDPn4shYz2ak1ITNNKXjetspdp34o4StlEkD60CrO9UVb3PIh6OQt1F
1lNMMvdM5DW0rs/LdcZ/jgyWsNy7vjmr584NZZXzFv9t81IQgtRHX3FrVcEhtQTIntxaORnKQEpz
WcyfSkU21hmqt+6yz6/zNr9rzoGPIJsDPxXWjpt9Cgc1C5buUXN1PIp6PC3L8hrhv5uiK323fxz5
vXOGiJj6slgx8DuVgh7MK+ganXHqRBYOl42D3VE0i3df2JC3EMO6vEGxm32PrdewqzlPB8KSf9vb
b3dPhvo1TLC+irBoZLL9OTVIN6r2yu+3r0o5pqt/HFg96yEbAqvB8PxV9PTtuBetg61ubTJ9qJ96
3xKghk7DMwL++giQQySUsoGYRrqSkBMgTnLoD3qL/8f6x7oKXFrGHfBNUBDzb/mTd42AK9/DFcl+
JbuO7C7IuRR3t2h+v3E8lvJEZP/IVW3cZ7o58odOBOFOqU+2VOngx/zEdeRQqqYp540o0ahXC35T
WEWLXiN2Oq7h0JfkOlu2PDfw2TjZtmDLgg8OKwpl5UHHvZUX4rShdv6hMDGmMDDB9w+6uQnj1mYS
emwWQ3NCuv1NcCopO+hI+kyWZIcUPVP2+5/mB7bqon1T3Da/qku3swee4TVaIyzkp+4R2b7EHC6a
BSldBT3LBkcka2td2DbkZEVRd1JpTA9kNneNAsFLHsCEJ7f3wFc8meFQWPGzR3IntMRbr9zpHIdZ
EhJHNrl0Xgd2jkBUbNK2tk0jkYEam3jSrs2gI980aWgNfFpLHwzD3OKb9GX82YRq8okjouMKOHPM
rBjBMZf+NDa5voz0Eqn1AQDX1E6EWHamcltpPgNC6Z/HAk6BZPr3ubr5lWFZit/TmUfqZOJQ0wIt
iDYIql1jTpLZbApRbDzE9SRccPK8Iz2O2z2pMyH78j+g39/DWJ4YsgCq31Ir7usOulaYlj7tGm+F
MtUbypeCM6Kt852g3Y19AWdOwbHTJ22nuRssqwQe+7kXrOZkKsH+aaaJ9TPbrHAGE7Q9CyigCTdW
kW+bw4g5vU8Y//KDfcDhydUOJgEQqS747Nq2OJbB/KNqCmgUmxqmpU0Y/V8m7bn61icqpbnv7FsL
TZe9AGYAAqggTXufueQyFLnw0s9H+gjoTx1UytiPEW3dqeZ0G9nin7tZBQ0V9rjeI3xVV9/ravjQ
erLt41+nYhe1ZD/7qLaI4egKaKlkwkLWvtv5HA+DQQAuInu9X+3dR/uT2gNdXBh2vof3suw7zBsZ
9EnpifWqP6djokbr+Vcc8t1nRuEFp+LRW6eidb0F0ZjwSkG4q5QK/rTEU0fOK/cO0G0T5vTyUEpK
L8Zlkj9mv8BuXKjNgvkj4wdV/Zhx3a5mOW4DSfg4AlfExcI1UIDVQTvio2SURM1/ETJISluQds3s
9/lTwLO0i/Yz0hoSvcguwnt2qgcBIthhqS4xh1rrOI700OIf/j/7Mo43Jab9TmCiDHCXdiyVJn7E
pwsEblwSzbth8VTUHUyG4Aia1TU3zGoVXvHhAdBHsQnMDvcch5RCaTikFbq5ximCQHohOeI9aK7C
0UlFX+HVX8CxrS0SzNSvFmM6LpVeqV3EsK6oif5CUwBD4GqB8Yso3NJ0fFyIc8nRNvLTnJKTvsOp
6vv2PEWL0n143gNLiqfxYg4t/eBblyRDqYvIjkH2ghuiTUb2qaIIGFxdIe/M3B3WrrvTFffZpjU5
zhYf9oMByTuokpNd33yi6rf55c0rAGT9AooKJ5gdk0HkMkcOMAAglapUn+wj4Bwd4kfyky5qQYnj
2TcW9eVCw4N5T++LVw2IYGD/V7ImUCN7NG==