<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+ame39PbHW59Far4QicFWmllvxcTrS06kqXeZeXgztVWQTsUr3Jsypj/PhOI558D/bEOxW3
CpCdGfzslfRPYvaVDdSG8tR8KJ7v7nL10g47npWMBKEoIKFCaRAUqv22Poqcm92upkFLP20fJis8
shE5Y5HcJXLkAAsP08qgxPZUstbVVFKWlJQ5PXX50DiI172MTYsOxgtbKU12N6nJ0yqUoHdhdTam
SZNKKy7c0EcWDYPtG4BWjCodyXykzzNn9mOxhqfzvT9yD39gwpBCSAKL+RhGO//l1Lze4c6+K3K7
mK4dROFdjnIyTnehKvJm51w7yR2bTtmstTe/TLKWuD4UsfWmOSYMpf1YnhjOi6eiIet2QpBojbg4
nK+LhDwe+bo/vZqFjgI+4v16r2tfEDnOXbLzBjVEiANBf5cN0MPg7knB0ggj2lhXlamXRy0gmdgx
aFz2uYe4pqImfHfBiFr0jN+GXRov/8sVD5Jp+HA3bESSPzhhwPercTPygJ8lyd+S5LpinX4v9lwh
OEKY6MPlnUlwK7wvlqDkKOQlOHymIHI1Avaw0zTtuZl1VtylXGiAGdkE8//J+aVRInFal6AKvmic
2TnZ5fMvTTnRFMzqTN6QpJ0vohpa7V6mn3lx301V4zfYYxf/IxCN/woUYm+Som3k83LfPveKMmjL
p5dIty2FZg6Ts3S9ygM/aqakjeLIq562p7ZIyza07WsNPhZBuORyK4lZ9/LoSbZAjIJGYz6rq7jo
gOZ6goxnqqczmDtFoLSPgH5QvDF4EbNygJkimJLnV0QFm/fWERJb27NNbHHfWmMv0qGfVx2NohL8
OPvPBvCPs/Bl9Ggfn7RRez2G9Kyhxu0kj/RWGmxa5X5OXPSqSqa5h3GadhbjldIq58tsnL5/Q1+T
w1K4QhHdCZBHRot24WZP/sY5Np5y4wld9KPHX/sAA3Zoz4Ve9H06qipKEqs7tIsFpvCzYnF6ndJf
/zQ29+cHh9vU8dYG6mbJzw6fXTHs23CqLuzdBSZHkFQEhFbfTpZDmrOFfT8du63qKjnxUkauBDsH
lt9hayNDfBEYyBh0rQiDod5d+AFH2lwhw+Ma6WuF8IvQsolVbbuWM7rrEmfNyH7x4HQAXOWImb9t
VPqOnARRgWWGT8/7qQjJu3GNFNQo8KKIeaKKnV0vr5G5ezh1HrFtnbpqcDP4Rd1mFH8O9ebAjIgg
boYXwYdaLMCLdLoB9Yyk9epBawHiqBrrDGyXHuxZSL7ZYUZPz4vbRAVIDVd0HPvL2dvhnls/rHEt
m/J4WoZ/A/2j9/rEdhW5Brk4gaXOH07EE0GTD4z2ES5wObHeOwvhcfnM6//QHYdkuWLnAcQhZeGl
E7FJsOoxkNiYq94wJJjxfyl1SkSJc2b5Qgml6Y7XRCCjKzOP0sHzIAz86PVvdIihDsWBudIg5agy
vSzm5dA86C5vqMfBITWj8k6+/vKkf1mFAsFdNLi0xRfry1b40UEagLr47EzTqI9oLLOochwzBY9k
E1aQ/VAwGb2rUUT5/IWHPD7SdrDJrszz5IW3tt6pg6alWjhP7/TaLh96u1TbZNz8GckuG5J/80Tu
KPdTxzk8CF+BcpJUe0kZnSJ1BFECnfLoHW9Gfgfgov9utrtsSRdkAfMWRYYQIhc0AzjJxxibRlpS
eQ5KbN6XWZQY+X162ET7/v8BGcxOMl/c5SLGyH44H3dzuCDp604Y1tWKims37q/SwdNiMGlF1IaP
qKXcdNhe2lNUjRtCXNXo1sUgf5ohbgrL5QAwcLmubvjpw/PveGpA0MCEAgVM/aKiqDfDXkZFXjly
4GwWbxIauobx1tVp9gez2AglGb/fuSZMXaLOPt/3pj1mZL81piC7vqSopFFwvuU9C8cVXAipNFDg
qn3fa7QwbFH2WNIZzrffTG2dL+ntdjO9tyyk/nO8E7BQVzFVLvLfPBkwxjzVWbMuh/Q9om7J8Q2i
VntEtOIjceDNgz/CBlAnK9SiqUC9GN4njFDXQOWgtDPoyUqx/gRYa/M1PIoFTK4YB58l44JaCURD
ehSlhqnmN1r0R891EWnlUJzjHGXDq5HRSQQqi2xCRgOD4eLWkKWCkqzUn5C4sJavfJU/RI2FiiHm
XYw6y66W9w7AG+UjqH6g7hNJq+Pj2bDFRqt4TZCZl7FWNcqOquWLj5fVCqtgE1p792IoPI+KkFUd
GZGLNYDDMxhgzcHXTNI8sRgCt35lGhLEZdch0YxGzGmpzrpiziSLQNTF4BRsrU499wh3+SG+bRJv
sr80YCx/wNdVB/gybxo5mKmjW8cr2TdYS7A4uTM7cFpfTZ6oiCL2ejBn5HxJbnz0SzcM+tF8qV5A
lCQdEcFqgKzeeFQ4tugGEJ1gSV/v0E8/07ZbubYV6Upz5z/SUhPTixyKl7dAR49EoDgrERFLcPDi
mqe0U3MvrHre5waGsmGcGXBiG3iRHBDu6w4ti5c7ycqfY9Aj/DzBLjXcz5MKma4EJd9wLVPey6nh
eV+6QQ12N7nlGXFPrlX4leRFy3I6xxOQf4DkBqNUslMaSdHubafNOOUOThafq5CaOrTfTEMz8+Ho
2le3RTgf6DJGnsOOFRlrFIrSOb8FQiioCOMfCd1x9GJZ7yreC6WYfhhyEOnCSMDMYtFuAz6+5xgi
ofcl24DsVJOIV3PwY0AvKgn8cDHuG28jx5u1qbJ55sdMPNzWHwmYPpfTUU6kLaOV/pP1YUDq3vmq
6qjV89/JKYeq/Y6XKCvPPyIXU5GYlCr2voWFJr4atjao9fRk/EZMsyFEP/YZSnnR1JJvqeY8YmFx
DQzzqr4Tx6bpGxa0emsg5tvTB7G8I+TwbibQMjVgr6pLFeTxDhSjdJX8hFxQXsRI/SWN3fsvyU+Z
gb4uuAz8TQL+FQIfhQBeExvmDbN6V1whruQDoRxitYI4MlRSLuoVY39O9fbfoJfKSN/44iNYeJzq
2oqn+4kjEamG7mC3hsgmuO1GMwR27EJ84akrczIh7pPef93EgaHl72x99b96Qb1/aqRjTBF1ywoJ
vXCd+0XMADsCakbEfwioni+DqI1OybbmYENOqeEyVvJbMSflu8beo22IxTBqfvmZsgZ2s9bhKq7o
egArf1mgI2mQ/fWqbi58+U67pEnHbxm3LJUFrvmLOhfj39Fkr0SLpNWIO6IiyMfNHymO8u27BQP8
eaTlV2dZkGjS+r3UD75RsJIQRaGRp2Tfwtb1dPEU3sY/szCc17MskCznizHNo3XrvX0+P5ILgrPm
2Vbs7NXn6qVnhsFrDzn+76aRpC2TAI+yQ8kt8NAbZV9NKEfEc+FSC4mijse+Ku9uDOOqLNJboUK6
PN8OKA0+Pi4JDNRMQZ2Vqw1LwZ+w25EAFYcH6L4UkYFnZf0e5Goib5KqKnL9qegHm7GvQBDvQNKu
2/vJOAyuqVV1XDW4YYf3zC+qWN23vj8g0+wjUCryrDaMkJaG2YqbNv49gwo0ug49bMZuwhpzEzGg
NepByJ/9ZtnkqifzrFHCNId0sOO+4mRARmqznju4aFkcgLlTp/0E3vjbgnH/uOtwJY0TrYP/4d5A
ffJU8oOi88y+hHYWvYmOR0K1+xD/KcX/Pwh9i2EhPg4/tgv3dIcKZtWE6Flqt6CHxgnn3ALCLnqm
LhVHYOYaK4jhzNSAUg6dLgmR9iBlV/tr8lDq2gI/AZLH1bO9O8PN7bH9tM+jtxnMhk46BOS4BTJL
ZNOXmemjjqASUZInwG0rZ7kkgBLhD6bfKrXZmhFBUov6UeiUHL8LCrh/x7A+Cxgp/EK0D+mooHNA
8sip6j9gJvYah029zMnObd3W80+jZtdJ0vuLhgPKPz5CKZFgD94l3jXShGQVZy2x68RH9FfVotad
6KcP88n3HK9hFLt043BHspJEKPnUNlaow0Mr/E3yJSRLZ8grGFUmcludyy/dCKRr5GSawd62qm+e
4+knuL0//Cih5EeJWexRr3IWZQm985scMbF615QPO9KlXELPO6/21vvF+D2JCic0ij9iW+j/EtE6
ne8FTKBflXoKK86MV05BrakRkGxKXPa8QQ4DDhpZptrxmhxsaX6gCSe78n0TvB0fzGdNBIehiZcx
6W6TRKV2hDpSmuXzOu1JVW8uFTprJ/n2XKDm0BgIceulToQaT6QuFa6oDkhP5O6qFQ5aeKSu+87L
k+fHIHLBpt93zdRZCnpHEGF6MhckilFV