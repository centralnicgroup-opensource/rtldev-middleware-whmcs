<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrZVPnx5Y5nIa1RoFObgiGNlB/i7vnvV4Q2ul+5J911YpnI83EwQnoEj6V8pWKrhpOS9uCae
THd8FewyDWgYeYw4ZZQXl/Nr+PVvQGk7eJtCGzn7rEdWoo1jJ/gPIZBRlpvGNKbIyDJsS5pWFaxE
VYsHeU64CwnB3SF7vqE4nZsj/hBt0aZDSK5hGFRI08G9B0SJLFeYQefAJJjsUpIy4ByAuKjT6Llg
+Eo7oGFOxBbpC+G6ZODMlcaKBs9d0GwEA1gAcBlKA6H8ahe357dMXSM94wTbuCJpi9iDDNIArqu2
Q+WK/wYSPGp5/QNpDFH+7QvDLx3nczDMc0s/7A4kZ6r2ct4+enawI2nzCNFHhcupcykFnFGzB8zi
03D5aZFvTIa+AQbCPfksLxBp35wDtj0Ly4jubRBk5dHX+CXvlwU5OoS5gcNRcUeegl54w3AK/QNO
SeI0FfXoJEuCR+x6MrK0nVI8VNntZkNV5rlCqXBqtVOoHwR+kPB5R1Dir6N3jXaUilasrwU5b+jy
wgyQn2PyeQGnx7LfvGyVUi80YUIjdEdppA+AeX1gBP0DNRVlf+NrozZCZSYHW8p70caZQbJrkFMF
pQQAKw2n5C2HEiMzXPZnzE1WnFushwlf4kq+fdsv7rycn7GOZItE3uYx/yS2L4U5nDGZMfXCKmwu
YsWCsDlrs+EG+INlf2YVzMUcfHskDp9AwKtC0j4El7s3LmCGk79KgeWxqlx+rNYncRK1HwrMWMNg
o+8O1HdYDSTdRYf1M2ooORPB4TellpTDQdVu+js2/uaa+vwohim/vTlPg47NjdfVa7Y4sJHfXzvn
NKv4x3edpyMgGKBTcBb4irTOz/SNks7b5K3BrtCzoSIj2yica5lwsGJOYiHy2U8e8nqc7L/6Aa0b
arv2pVjTG9uY5xIUCeVtQJ4EGhTdyuVfAEI0ViubTnMDy/jHiXM6MFZ1qvLac0AKsO6fOVti5FW5
YGWbLRb3b65R3F3cxfiLMeqNdTnrSeTNrLTcM8oYodjHhegFUULeErxYmAwrDCceThxzEfg92Sui
fmzXXGVRnYiX3Y89wyqQ1m8/fuOx8X1rU54TEgfoWZ5nx5K0UgyPiGYX75AJhI4+sH63MDJeDBXO
pyKJIgRfuMnVq2lfyG4cASkb+gT+17sNp71ylKtqO9MVMe502U7xUFJqkArX4y6kTIGK8kOZNZQr
wPZKRC6NovEss9xh/Zq+2ARxFrhpAP/7y4moa5EAN6xPmiiQi/NinU8YHyoQli9J6vkmS8taVb7I
r6ArW/lPwITYaWH2CTPB47g5XAfVhd+CddKEUmk4EOC6tf7cngGhInfQ/rN4q1E6waRtISV5B511
1fhvk7sCt4VlrCQAiKcaOgBGdXDP1OTPMIfRRMSo2qv+bVrNOmre523ijElEUh1wl2IZdBskaR9y
ltQfb2vBJYnoj6BMgkBh6JUmyGkwSPv85EibkElnHBrtJMskcai0HSguIu9GH9RhGNWvkQt9Zj8r
hvoA6UKO42x5DK0n890QOSUSXrlRdprcQVYW8kXixoleDJ0W4BqufkkISOTWWpGPW8MPpErg4IqE
OMEJKqqmibStU/jpELXmViIY/dGoLgoEYBFaxACr5nhRE7A+pfTag5jRARp2YrpRlSclWqHqwqEE
kvnQPu4VHcD6z8C0SHx/blfSOqAWkPaAagMjDQZUWwNvMV3cdJxhhyJ3UrJXdSRYhzcMDRfvKqMM
KpaR3t3Xp+eH33G5TasCx53qCdCz85yl4L5sh4h815K/7/lhwovu+0OBuBv9u/Nb/Ts9FwfmKTEI
Bv2L4nK9A/p+LPdfvw20TYN4mG6lYX4wmvHLZYCTsYAaze6WqtweAXrS9pJquayVRaQBZv26sUEp
MUO4Mqh37gXBiRHbKLIQiM9OzARYgSoy85RkfM7+gSpEujUiUBDIpuVrMna/p5e25h8oHbDrzAQK
tmVLVjjhOFWP/+vTbYs1Nv0fwara03KNRPIolXzQ0h895oqN+O2AfRHW0FyPSzCBm/5a/tf+JTKn
g7/X6l4TrsovwfpC/5j/XChnUf8e8/OMMLseixl5tXx6Sqk23EBWzEbnSv/vbuNDQ2rmcCSNxOS/
2llW8Oy8hK3LmQJDYgqZ8lq1fZfD0zZhSrHed+ik9Kn+9DY58g+EUxRRhB1AkOm9rW7Fbkp1J2M9
KasfSROBM7iv9PZU0/9gW5grYW8dvXBEviFR3KdwtBslEfQCLO7H9TNFMxubAXcdnxOsrdOay60j
YsrGHdk8Z3iJIMA6YogkG2GmaFtB3GLXBdqjyJYoZF0bxHwn/hNO3EC2BiX4cczSSlbGrSSZjElu
VdIe2lMWfAD0Qvf8x/14/pxQJYDkpEuqXSINv1kNe1HP1ZyI9+MSBzP+Lpa/8IOB0/OXtdO0SNUt
VWfTFkYA1BKmfwhMB1pho4vGCoL7RGdS6S9jGxgU0KnJMhDJlS+gqQV9SFU8r9clP/JwQFO4XmPg
LaTYm9sxv/8G9YU6XACkEV22eAbuQxZ7/PQQkymgo+p9LO6mloxtarwYAxemjWh0vnoQHiQyEjWm
olTE8wH0Ytq+WfY9QNrKMeZq6xtBjudsiH83VbNqZFB8in9x/4fgtVI24SFNcPEaCyvMJ99YB0Xh
15tXqvXkfTUOLZq6LapAw3lvDzwcTaQLoRt3Xf+ssoYGvxdm1UXWs2GDYW4On4NCQ94tLF9wzFVl
cG222yQhWTnv5aGOWUOT7R+ieLPt2F4C9BRjh/GPGQx6Vy3IDQllkxZr96NodRvlo0nVULNg9igI
MNe7SYzN4+/mXJW+OO4knz5IXEumt4JsB7HCeyjZt+QlNx3A17NyMEe2ySvTB1DEMQSfNOmu1LQr
U+ZD4UbknosmdJ//Tzo/wfMxECC2FSiXpxcCokqvx9OJ5jZZIurkicEw4X+H3ITZJlUTDsLDssHy
khdH06hzAvxURtKn8vfS/BQHteDpFqo6fovkgibYslFKkTjtvDNyc4KhUctFf0IZYt/tZ0WxIolF
8aG4uXbzhpUayWJ4FzipaeXS4jrxO39Mf3tksnAnyyL5x8pq/uQPiIxnj2G1HoosfbHFJA745cdx
zqkB/OgRi+H8Rz+iXq4wWu1iEHoOE+6nEYuBZiyuZ1NZryD4mtBV8+167ioTgU8kcP9RhpkFLtDp
/V3U9dZGhwU5edEjXOvIxcLCBgnJ7m7UBYWZW0pRgoqaL5Ay/bnqsEU/Lt5Qojh2iGdiT2CpCeM0
kojmliKSch7wqoynA/E3n/YpjOmoD5Nk6FHGarqN++IpR+HJmO1Sv+0KrgFQG8lofJY5I+gC7h9e
8PqHzc1WYzjCe+i1CLYlT6buO4FLyQ/63XANMexXd4FyvQbyHg6QzADsCR0CdjKJiws1jFWOEIuZ
7fnjESpZWKGBDQ/ID/18Gkfuh9sdhw+cveuxd7cgt8D7M+3MpV0R+IWoqrG9qiLWybnsr6kmOyCh
BV6kathNQyjdCViYXttZ9jWdiUC75jNKj9wNFntLgDa1NIbWEKDMT7ClrGe1/aeCUU/diCBw+7X+
aUgvDqPbMBs3la2CE0M1CYepV0SrndTdaAxuUARZsxuor5HhXWHs2HxXZbiZwReo1KvpTRv1LUAh
aoFiacCu9eJr+pBO940uWMAo9p0SPFpejQSdoELUvfJbgZI/JfUmPF35T/Xt8E9BQIE49q62kd/4
oA+8zXQOkjxPEp+jgECL0Vgo7fXiyqKku5+oU1rgAYi12eks8xpR5fxcBOWPYNPFSqXq3cMXKjyj
Gnv/9f7IXRs4yy7UnayGOL3C1R40gtb/VfFImrVsULgBvJ42dp6zz//tgXKhfMYcWcqq1y3R12hP
QioGcbDyuBL3j0MzTsS69RlihlG4pAeVr+fdsYDSOX48f/tN4W7WXVHTbPPOGjz03WjsZl+bdVnc
syx7P4TpDwn+cgFbn5N06V34grF5Ll+/zPF1qsOZFolUcjMmOXnvCzT/FSVpPdmH1oClLJNQxOD6
Pq2IrD5/r2RyV3NmFNG32J7tlKbgW4rQBU4KJRJM3lLqPXgOVfgcKHbYfH28slfYHuosMRzylTt0
nlp+XfpQIGvOSqHqEkYMKTUrppgfChgo0QNFhZZh7Nw0OqDqSILGE1AK/PkFbvWzBWhYzpCg2sRS
igBZDJ/Vh+8hVOvlSdXsL7wOKZUseBmCsv0X