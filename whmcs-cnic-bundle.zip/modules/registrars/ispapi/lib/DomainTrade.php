<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvnSmhw623UnNvLNdPeLRdMxTglu/gLL3Ci6nTbKcfQMhR6hw7cM09b25xSv2LaK2j6YdAcP
PvNhQWIrndgyta3Q+bIDtddMqph8V4zoCq6NmlHtSlta3LM/7V536Pu0z4xlR+8zSJWY71n7iTWJ
U+XrSVVZUHX+8b2SjLGlR7cRuQRk6PBDJF+tdOlNpdweRYucaclh+ZfuhZzHUnsbEakIdThPH925
z5oZzUFDrQya5fkaN1pViO+5wmFTDrGlXc0WO9QxGDcQ1+nOW1vT2fZM1eDGRBDMXiFjqLk1/v8W
3En66W8BKPfxCoORIWEDFrf/gvK74qksXZNUdDSQkSAcdo1FX/PG7F/1Oswm/sIQwPFZTPqJxaWM
xlpQXzcmDDxTwPZJGCWcg2Nr3ZFUtufVQ/0goHUcHhMZL8TMXr5qij4gSEhEUEfnliRCObUQY4yK
jpHjc/I8Y6tsQVfCMuVZQaKTUDb6rBq8VwOM90gowREN+2/Pkx0txzam3La1n+6wsag2aDW2GXEg
h+GKxXzM08Jfelra2N5UA/ZOEcKsN60Fx3QRIWL37TSLUikO1l7YbVfvDrnV/p8KG/noLXFdNKAn
gYKrIFOw2vg2L6mGwMY/67Vck/22X67jPxr5JvzqPKdB4rR61oiOwUOHL1YVJKSo7iXgKYIS20vX
KArbtogcClZ40J6ePlr6GpeslUrpXgrP8BeN8k/M+QQ6ETkGZlpE6s2yoWEHFJ/Ae8Ar222FH2cb
P5D/2PsDrnAA2e48696ZBweGj1k+A/5hOtQq1BD/iE564/RKUWLC3mvu9eBgr/ADhG9z7L3OvB0A
mAVvw40Lxfc5hst6Ka0Y7pATDBDVGzbSo5lccnKG/uS7xS42q/P21ec/qGCrmozAWgHDHgewox+v
OIn4IR7myz8qE4Y0sSR+DDwm8jMgmwrx+HC6n09t4BINBGNH0MJfWF9wgelm+F8CRBjhX95dQcsy
WjwzR+VF+vCUrgELwLB5/qQTq7Fn40jYzUcbGcfDcs1Rc7RX87YmtB4oPAN6HxE++6qBRHdClVpz
fsN/EAQsXWa1xtCY36l3Rj0fiU4nXGAgBfVgqjoAwfZAurtg6WKebQe1ObObA6O1TAigy4FekdkQ
XM0UkUHyONk+3RNaDJ3siBLsy67+GaJRSD9IxK0gYsDgHGoDhWpQOu6VfGG6AAaE509I5bqQrIbW
M4x70ePB2c4bTR/OEmiohHqTpIi6XeS2sxfORboWQKxbuKmSBSQ+U8hDAr+DhTstJ6OOcWvVATlv
n9w7LcqPSd5EltlLeuGYXme86tR2se1xV5ylaFWg4tqkmCfmXVfixQx+LIOtHNoIOoj/C4SnOXqM
ccVZaJ3dVu01VAHAoz6/3efvXuvNWSyq+YrZ+iJ41lOzxR9PW+vJQIF7ect17RutPgxHNEsfc4AO
Fw0LBfPhZVv47OZEVXvHIWGWaIunNFqvmxvEiU4vJ7iNw1knjeADnfYyR/9lnhJ1TUA7Y5ldVi2c
AXF4VpY86kVXzzZRcO5qNmqALHqosqxoqawgOaTI7fDIJMc5jjHTGbo85RTl5Gu0eGAsVCFmgOt+
1/5McyLUdAiQTgIi492fs5cbHtD20nQuKQaY8fsOqg6Hh729Bgys0J2K4pEE/DOzU60mtbpqDzQl
uha3YQ1xXybymgLycwW6ZIUBYQiag1SbhJzS/s8r9BUbYJL+2kQciOTA7SxN1p0KiSBo+Z1Ow0Cp
4lLQzqfH/Vfy8FTISdpW4oMP3s4wQnvPY8gwmTchYK5ADI4P4ZgM2PFpHOxQi+NkYvItmnX7ym2k
MKz0xp/cLQXtJ45Z038zCtFhtavWbgZwID6H1QAp1KD10KH9h0hyefsIpt1mT8d0FcygE83+JAqH
VX2fbCiriAD/RtgrI8CQKsscd2CQ9YGLaSy1sUw7sqDw4zYziEZovhoQwPvdqEBvmcOPePvMNwGs
DGEpsajgsv6dkQy1oEWczgcoXf++rOP2sGzsbN2WGs8XkUGzETdWYshl0dfGKYAtBPR8H2F6zs7/
gY0U44pFQ7Sp5uhnvQFMkoZgYXvMa8yaoTpSfhi+opTFOhW/cNnGXmJNsPDNELUYMKY+mr+1Sm42
BZMLrmF0MdHZtYmOP8Q26rTiX7HxxFFyuxLM6pM1yeLs1W2L/D68hx72S9AXG7V3DMMQr2q+pWPy
X+xp32PFeSAN6OZMc6UAiyjt+i6+Jfnk4vsV13u9jUJjZWCLR1DyPyFKcbZ4KWYxK6DEpLWEbgJd
USHhIyZ4shCqibra/5SFf0T7xEPDagURnojfRrB8lj0eQ7pI7gbvxYd59sEaNvBGbpv+qMQ70aqj
vVtfvbF+2y4FWrbD7zQYnQtJ9gXOH6IdxVOJU/y9NuBd2C/nMGWq19t+WRMAVYrizFKYQiRs9OjD
nGB86F02L3j4RmmxDPvAMaKYikggZ8V04OFOE1wz5Of47Gt4cD5oOPEDhCwuioX9DhA/7g0ua5BL
BoolO54H13TtREbpuklqB+BhJPl76MJ25QFuO2IVhMlR/DKSneOpYjPgKAYaHGyiqiQer089w5yQ
WMM8+xsOS54Raw64W0SEYrtKEbeLIgH164OGzDtFwcMFb7/RzlTs0zKPzgeuXwNM5xuh05k0frTW
aOZN+SlFsVK6R/VMc6ca6FkuNUzy0/FpER1mnZs4DIdNmroxD6FJ9HyFhHFWo6o5Bq6daC3Pep5j
3eDYjq45sdj4zNh49iRgZKWfIRRoreignvQP6jRKDlaHLDSJ+6NuPM6UKkpbOXifYN04oLgDyN9W
clfvlx/EhM0334mYzxso6Vi7JOn5VIKY0jqmTi/HcnPfFOo9osocUVJtRxaNGWEpSkBigbij5p4M
WhafrwtcTERgevdfD3MDVwlFEcSsWUDqTfCKlxB77W68Dui1lePlxCTMrlO5V0pjeNdWCsN1TX0q
VfM25pdkC8+osT/puQdIOt5mHE0777wYSYkQHC+zccn+hBGs3D1llMu6GnQ2Mq4wKwEjXYd0S+on
TwpW9v+zwhLNbvUg+xJMGoSw44Rp1cBzLUk+3ghKZTBx00uj8kRTlfFmI0d5vwbVDnjnPulC4YxB
c81S1jCOWa8kODnw2vSxxuI577TZebHkZajFqUL4TcRDZhKZjxq1jHNFrlYAp4GZzCYWtHu3tsgB
QqUvfA/G+BJq2jNMfqjx+19lObQQGAXtxtDWcieV/fA9UyBuVlZyTzL/dbD2jD93Pq50Ms1vh3Ab
5UU3ZqpgPoMW8iPJVHbtYsfNa7ZN+MopaRtIXB1wwHgfhUAUWbWpdllgOxkBB/u4oPSp7YafIFYw
H9+42T4vj6MtkweM+TBcUWP3rUrColSB+DiaQkdGwAH/azH2U1S4q+AS19ffXblMx9p5RRIkLwx5
W3zHpNbwnVJGPWLPLOrf58QRIVbiRnEpJnEhBAhjhyQh0O/K9PDcoynd8ybnj9jbugNrEs/Q4pTS
lXBfr/7C1vlKtUTuUOOgrPlf/qAsR7iHi7/BYf8jGKC7UDTbsSjoEnSH7bhCazWFBZ+miYkyBm5j
jadWbkXVIYhBKInSdjECxgQt7FEodYNasOW7OoeJf7cgXw8sZ+xyrN2PAhJD56Kvfi1uTwi4wxNK
lg58vOWds+wiratZ6eXPpStuHQY1OdKxW6vULEpF+xTbpgtswkwQ/bYOq/DGRUlEr8lGPqPsQO19
xLWUhe365sbNz9G1XjhHAUX490+bSx8V7TQWK3RSleODr7w5oyfZdxv8OoojexcfCNTf/Hx19Rf3
rg6YMAzbXtaw7x2ccZkSQYXzjwU222KCYS8FMik0ZWJy24I4HwxYkEh1NWaMJ0kyr87s29IINJlC
ikVBSpIN474HJocbGKXIWb0tkuCIu2t+5viZteX9GfkGWqKZxz0uHgbj71gszj6ffOQxbjKUalu/
Ys0X5xjp5/eZdjrWFmUM9UcZz2XPNvtjt1zwHMfaJHhc5p2/AE6yc/SD0PuB3FMab0q4KfeSkG29
YUhHRjDSrFAWxkyqihrslYg3KSkbDW+jM96eBvIbaQ8fq3Hbt/0mDnv9O7GQ+35fO2UBZ/oGairf
UNVLBL950b7yde3duJlrBX54OC4iGXXVkt02YPy0/MjeuLm+Sy8TaEm3+eYVljZsokX42ydEqHeS
oC9c4+NJFIEWQcquWD0RlOC5mTMnZnz7Ec5OmAMvFRlL4G==