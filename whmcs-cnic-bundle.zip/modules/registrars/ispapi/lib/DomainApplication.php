<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class DomainApplication
{
    /**
     * get domain status using QueryDomainList
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param string $regexp subclass regexp filter by default pointing to premium domains
     * @return array
     */
    public static function getStatus($params, $appId)
    {
        $r = Ispapi::call([
            "COMMAND" => "StatusDomainApplication",
            "APPLICATION" => $appId
        ], $params);
        if ($r["CODE"] !== "200") {
            return [
                "success" => false,
                "error" => "Loading domain status failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }
}
