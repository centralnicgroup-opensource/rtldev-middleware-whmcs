<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+uGslLl/3xwTg9FrjXAXs8ZVZY7fXlw8VyIhmTcqiWjW7agQ7lfO3ix9cfIXwMfubrzzhKR
Dxsy9JDjCf298UtRqzYQccWg1ngZJ25SCrsu6n5Lx4ZZlKMTu6hD7XXoZt98SMLxazRQ41uIOP4U
rJVTcCVDfZ/lySSBr+Ey1iOevy+qpC/tDRLo402Zk6EDUovykWKBcsmus0yCNImWVNKki3wL4IZz
Iu6xUi0n2X/nCxtNgZ2unhx1GFnmkURIKLIkiqO8mTjzu9dQ+Ayc/LkAgDyoQg4QpHTEdej0QhyS
9yAdJlzUr4MJYsPsje8uiiMzS/BRK8Hjw6IsOZG4L+G5bAnYET5b9JccXQHKgdtOL2P7BQ8KxOWu
D22i11X6FgZOIB11zhj2+WCc2tXiaq9N1kKDeCn5KZzDHAkFh/LP021ZiuCfTTt1h0YHDghcierm
JF16VwAGzfetcNefVk64Yv6Cboe2kLy7M0qvOyyEAhqMqWtld0olgCUdbqR/7Rl9xByW4sqAotmd
q4OY6HGCDcHnuWxAuE5jfzeX8w2SZ2hwJjnSgU0wGutANcRc7z/QR4uZF//wSLJaRN+Le6FiYLiK
Bmxm1QfiUoakgKJApeRBPYNqzzctPzYc4YCmOZJcDxDAaKe7vGJTeJDjXUcTk1HCw/bNSS1K/PVW
pTc3m13nbE1iZqdHXS1lToG904SwgH/UYN1sWjiZ1K/N5kW4rKM8wy5c0O5JFUnNY0RY2jpV86KD
ZP8brTO75gHZWvR4L65QEMsgnvPxOyhqn7K7lpxOjZZLiCEP7mWAvrhHH/iaYskBnmprlrxgXgeZ
hMXoc5pK/J6Ah5Smf0epYqB+y787COde+VdgKvjkNIYAEpGOoLjpb0oCUBBpfWc+14RPZUhHb1iX
gn6jb/DDExEXh2674cjYD/TK3BtBk2JkOKNXkK64Bcnf6cXpM8tAgC5pIpH340y1BH0mEcUt7ACG
GL8++bi1/Ube2m51NCdSqEXff0ECmRkxkqWWlJw3o7kEnrwts/xRi6aaDSp1qN4OV5+LbVLFvGyh
mpBlnwE10pvtZ5a957++K62tERGMjgCvz0A/afSVsmrZ/KzhSgjrLm75Dt43wxm3ysZzFm0vv0ur
CVfS9KC4oFEZU/Nfs0GKccMXNpq3ovstNaadkdMT1PwAPXI/Cl0Vdg6kVeg2kiCfpmOcnmCa5WjQ
ADPq2i+YccnRpe4YQddsEW0GJrY1t39M3Gg7LVyC0kYGhy7Czc0G8X2LnxwSqsag9CFTxFA4wLbk
KYvgvAJAGGsoUOw2Ge7fi+9irD6p5v1fD5M5WopvAcILYJeU2iUvyFiPmSlNykOEUCpoJyNXI7Hr
IjQSmlCFTfPlt+IgWyhMVvYMbnHghH1NUgktvfSvQINhtm/EeC/SxrrCcmegd6PaU1J6auVlgTNm
obxZMMBpzPIbQ1xU93iJ940H9RuGhhtZtxRjmUJF5gwklp0eYtM/VbrOwDk6yNtRBNSEozYReOxa
S8RHYbvYkDUWugVR5VU7yvo34uzoboIav7gJ3rzsq86gc706H4AhyypQE9LU0w94zu+tODJ2Ft+I
9OJ48x5SeRWX9A5Iza2AHLwL2OWrfRrGmg3NY3i6r9z5QDvJ+ndS0kYBoObmPPpswp/79f5908FE
nNZaD/3dT7JaJmnIfPpcEX6I0nMx65+7Qc2B6XUIddsjmGLvqbrf1tQzlpHSOLdoZ+FAftLiJEQo
RaqlWGL7BLp1yNUch0qbdgdB7dElG9nDaNVAcjD5lTk/WtT0o6jcYb21X//dEtP29DjTj1El8NXN
0AVSLETkuS5i5fsBoAAM0u3Hr8rfFmiFVHdpoLcm39hoO/3Fm34NwSKVfbSxkRrApnC=