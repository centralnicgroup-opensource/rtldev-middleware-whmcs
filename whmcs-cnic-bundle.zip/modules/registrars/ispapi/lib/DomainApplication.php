<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+ZVnP5C8Jwc2MrGikG4W0ac+Rp6fyaFkfYujzu8iA1OdVpUKXj7IR1pWXP0yTg6GgrWWFPk
mGwgXhNbtaAuWRdOl91Wznazf979HhpUNHYBoBkJPpA4ZrCaiRVP/AEOADNnK6eIs1OZjxsB/Hum
YavQmoVSR8mtRrhPFIAUWjmJ6c0AvcCZVRVf8RLtWQB+UoID7Pj5Rjafc8WIPFLBXn7iI6OuImrK
GnoKERm+UepzjpzvdHRn/FWjgpOqHs2U6IB4AzyM9OqV3uQwVOh17D/d/BreWQyDB87mFEmCGur7
SeSo/p7As5HjbzEt2FzVQ/LuSi/rxfE+A3iTkGCH0tIgpnbznXa6Xvoh8ByHMrLc6juiPF8tTP0/
pztkyfxMHuIUFPt+uXa44us31OqRA+TTnLvVlY4Lp3Xc+4/DwJeABp2ePRNeC0LzRfarkttkhOdT
MT/VVHJ+pbmU5F1rKNOQj8iI4pUDUlf68vnilCRvRSrTQ/XWkxDhVGAc2fZfyUAh8MWei+9iqpTh
eoGxBeEIkfLdfq2ueoqVrOqcJkSY1CeSJTKxagCPrqj/ynL+1LRaaoQoxLbfylOXpBHQPEC0h1+8
YPnzzGE/Min0T6c0QDv8zjjijflZo+7jVVqadF0YYIZ7T7x98aFw0gq2NfYxwMk+5s4fBrE7yFUZ
lwzOaGo2DaMV+3A98Xx29Ertri1Bwh+/CD0DAF2ZXbI5uqP19fKpIDA0+82gji7eu+Jv6ADbqptj
aWlRJFA9RErJItoTE46RNuT4PCfB44FEywRU6nmAOJCm79ljrGduCf6u5yTNa3vKtdgzpihInfHd
Oc1Vaj3IIXT/HIs+SH486vY1/lw7WWtGzLjFM0M9okUnRZ0Q1ZRNHn2t1YC+HNL0xAzylJyTv797
a35WkOWPDJSzseV1SIsGZUKG3h4GNQNgSufmUMEoUQ9pi8jgXQkUiyoAfLuJDVqkUsAZwJQW6xNB
yhl3byjRTV+hU1v1NOSmLRs6691dKRRDYTGkjn5bmFDuVVzialoijsiDSL0+GskU/agI3y8jUFxo
zP+FC9onOn/kpDNJU+DUu9s7a6GSaSHk6/oNO9CDzKaOQ4GYEoXWAnSFU/yX2zw2Uqadnhg/Zw6M
qD975Q1vJf6i2okbZy98JVWmoIGGA70FfUdKCdwJJsg8SmBbZn/4d/hZCjVSRu5sESdd0nAAYtTu
GHef8aA5Fm6IMi963pXvbFGHPh2URy7noG83HhSwgDZHrx93aua8ZkmIWhA1jjTpkooTr8TiYJ1V
PQ1EoyEf0vUy50lS2+F0r3MUunbz1vkx89FVzWZbdOj1Qrn5/+d5h0BE0I3JsxTe5Yl4oHKxjaKx
3ZTABV5sG30UvWas9E+5xcHIwnwebqAREzUIAyp8rnVhH4uj8OBJMgablBpqS8lIO2FwDc51VUDV
++EghnVoPk2G2ny5Cl38s/vsHvsG5udgRjLlXvW7NntU5ufWiNcfzky//s1w3g8KVvQkw4W5e1kE
cLq3xuUegB29W+Q4kT17H45Ushq8y1YzHBY7Rd5RmlC9NjkUjvw46GYh9PJgkODhvFob7IS/o910
BOGKHY5OSDt8fxUhjD884Rwe63aZe0O8dPInwECqlRGCmmgNdhb1pgiBpZ7H4ZJ1oR1feC9AFad0
MiSQ3FyiN2a/93snsig2N8lwJCgTSsEb2NkCDJLyTJyUcbxh3pgjfszzxDUYLTNzsu1q1OgldSNS
avCIY+amjpqW+FoV4ZG9YPvCEy6BcwG9mp/GvI9TlIn6/jhJHTZJYSiepDNufUXHWWUAVNMGH0ec
9Q83Oel5cwFVENGnWJeTOGQy46RfIm5yY/r42cRgNh9ILH1IULAZvaQSc0==