<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnEaofCQYC+aunPVi76JBpZos5G7DqM5Lla5uuXUDTN6Iy+rSO547jKB06VKsGdmLYbSf19/
2LeYhMkodZGhQ51nXxR+LSKjrzbyjXLmC4VwLIL4CmUhs34PmDYk8PkXVPoROEyuPsIbA/oNUwvc
IcSvqLGTUBdzKk6YMVYLTQBw/mejdwbRDqM6U/MkGl+NauR1+90cYtfraw6q8l1aA/aSdSGU9Xaj
CWvwN/bQa/1Uj1WAOd3EyAIFw6p/MpXK4btnTkL8ZL0P798EfnubVj6ae0vKHMQ2XpvGxvRR8TWv
PH4Rvtp/VTDo4o71gEWsqnS6h6BggeT6xgerQRvO4SDaf5IcmQ4XNuosnAC4vXDCvHsEg/WAnMit
vNFMWuyeA81VBRkPu+Orn2wwnLlC29vWisiGhzwbNX05oYJq7f7Qpa8cBe37a45G3K5AGJvSwI/e
PdyMBONv8qlaRdXATVjzD2sY6fZPHhUUvpxiQL/+CKN1XCD6a/yzCuUdRy86AIDIEX8DIYDbCFOo
hZBewmgcPsQhfcX9pIDeX1a27R5B4/MtrB6tVGz2fG2w5HlX+WDydTL4UfI7SCuucCT94fvURm0z
hJwqnlNIqZIKkesafYqJglEPEyny8yoK4xkEvoyETvGW4FyfHC8buFyGCr+ElVZ2hY7uMhS/5864
sl8H91N7COFuly8vIelzfvSbHxHiIVai3v+DW17FRdOvJCAAnTTzSQmGfIk/XbxKD7L+Z2iMZjWt
uU1A5BsuCZRhv+pr7pgn8p37XjPLSO/AMETkuIweZnN0REoV10+MWSjWa405qJ/78PdnGuDaGgVg
Zn/wdnF521mQZ9NJcJ6R/WeBRm34jtFDgsVj5vC6DUiM3GJxkMVIegmkNBTxTV7yTirdrnuqnfcF
87tzovaAM0iJ4E1VqzYX3j8ES5GDmrX43OUCzHCX7NHnVHiSYrLMo99Ae3215BbynSnUdyeK6V71
IriYiDjSvBLAvYof7IT7DB+Rj6CmmXGkMXlO+tGJId5x5NH9blrcxco+FZ8Cx6ht7IZipblKiwQd
t6c4tlorvcyGEyvLJpwOpc2ROxX/HW2FpGW70fQtJXv6n0ivAFR9HTxIickpX2xQUrNKJa0f7EU9
KHu+WajMyEpIn6KSnqjNghNOVctDk7ahqmd2fleU7rugkEXUCUxOcO0IC1fKsOs/+30P2IGaTscM
rgi9tMobU7PJfKUgPAFAwfIP36z2hA8lyyRLVLT1Uyigt0GKcCFHOCJ1YgOJHlB9no4w5639rIdV
xvGOzde5IPoi6nhYnRTogASvnJvPje9GVt/51+V1iJ72Ve6tEdu+7RPoaNSEv682xH+oChc5ksVa
DkhC63ACfFyNqm8kUtR/2/6RBnxpVpeA5dIW0fTHI/oaopvkgwGEffMUVicU26Z0FQIBk5o2iwQ4
QBSfoiCIIdSTIfpQYQQQK8Hm1jXxlCdZu13HP9uZFxMcOWdlQtyQ7FOJ2Z2f+AjVNznd74KUagdB
wYc5QI8qyWb9j1vGxuhtRInbAjApWDN2dMBCnF9cmCTRmZhynjLVxkk6eFbze4bkIwW3RdgJjtL1
6VhLzEaDeZjLv3tgk26JPcJ5gZi+igVBeqZUJccovSNmhUseUkd0edSV8LYlMhoGgxWKU4NG9ZdB
pHiU1JwXA6N3QTVs7eJQ2BWWe2KmYWCPI53+BvlgkmbP6VbUUy60aHAA8WDNcSC/u/EGs1vBcfhk
3ncX8hPaiNIcQqFKcEU47sjO97AZ/PQ6ea9eZ7UvMr4aT14Yyrz+GQ81l34hsneqiRATaBJ9Sjjq
mNFe0J4lgkLQsLYmAm46ZSVWxrH173VfESi91uC2efoXpZkH+m==