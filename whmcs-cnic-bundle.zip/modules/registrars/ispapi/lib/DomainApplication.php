<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtLxYLt9nN6IbCaSVkHe5jVwnch58pih2ib4idKs7uzLDGuJZ4Ug2gyOoY68wKH54gRT55G+
g2bcqhnBwKJ9VPUoD2jQciC/CV9Ud9GurID80XznKuhFrzH/ADAmoeQHSzvZ0p7cjjigMT7aSbjr
3m1+Hs9+s3uR7DIM37YYxE3nTUusQz6+XVBfCrwjGlj4IxCa6Zvb4usedLKl2XszozWb8Zc3vD4L
yFOrrprbhNb2Ub5b+UpnAKTgTxfatd8fsxwn4dBTjfIwBP1AAYqc6eIq/ZYoPPs7i/CeSda1r1A2
pP+71xwvMTwU6jgBrTpnKoGOtGY0dNUsMSg8ZffgrE596RQX6rE0GlFclRWLcj9JpiUZY4UyaUbb
x3UmF/YHkzhn+z9M2P8cvQFvTvmxRFUFHmjWXasW2tpUeEIhnurQAUO6hl2773iKWm/YZ1pXgGoa
TuTcSwzU7iy5Xj3DpM+luCengI2HFt0S5uAM5pgSf863RDPkVB744bN8xeUgYQ8x57pgC4JT4TZ4
hH9MuJOuLU9uk0IPjCQ25UNSeB8zUmm/XsH23jDj5W3Era2d27RgbS47WkvbCUuvwR0uSvjWQ+EV
jRR397FXlKx+EloWL0TeaBTvEzE/7ASFqzf01wyfyqOr9H6jrVrdJFfFV0mrIGAy5gy7OflA/5dN
dijYlhSHR+A38oImVULGuQwdXMUGcLZ1jSIVQ/FjY5bu5lQy5Qd3A3Fn2jVhSXczrADkUW8R6c+K
n+U7sn6oU0sJCZM2xRmi5nB7G19Xam3xntyxjLHk0DWo86jbGAhxE3V1+NrosMIwhnDbTnRdFTlY
ms0vWUpxttdo7oUjMifQcuo/TY17xm605WJyIGmCR9ZE+uEp69+SyK7RxOc7VL3pGOUDFXNKlz0f
W6pR+o/aob+1CkdrJ/N4IoXUem7q6uMDFdaSHb/O5HedZLYZNmSqr5k6Zi7CVCSQ5839XCmO8NEN
gH7cIS1hIMyxRDs07tRaiqJs8zEVzEf+okwQf/D7i64BhVnZmaQg2Oq3qJz3kk9yz4z0mncdCHox
cCnoSfcqKWjwAhCM537V5Dez7DU99XxqdE5qTIfnzZcbruZMN+sWPKBRxrYRZzU4aRWILkoRGH0j
DiH9mUM9D2izxtjHXkqAcmI+fimthtu5EG3TqcIy62UEfy19CwBOsTmkOv4YMjZh3qnp9JA2PYZP
TPQE/Fk1YLfAOcOa5mWssfbhn+zok4IHlcwN7018ZPUSKl9GkWszKCONtooHbzG3sd2riJK53MRB
U+JhvzKVEWVh/VffKayVbXWG6hU4QDLIQb0+2nchBZHDEis/biHx/3B9k48zHF+XQIARXhj9gyvU
o34w9gw/tGKWraKcu2BK7CVMisA7U9F4woZK3H0fLa8jdR+l8F+mmFPBxjBVx9zHP3YaXsWWti0N
QBEd2yMzWc/vRsHzpW+fNMyfapQpGKdgUQtvBLQ4Mmt1WR0C1XpJHfOzN5jSG1IVVaJ6yV8F3f8L
z2gGcsj8TpyQsiqlezprBPaO6VS+qwv8T2CFa3Gn8ELbTT342RRwm9DOfwN53+G7dnBvHl7UkvCX
xoUgCxDIJVEVk6ddshSZwB09TZI+heLDn5X9XJIhwvp2Hej5YpiEO9thXyRn9+RG4gAD6YJLqBXI
BEYVuAgc7euziMvIZOUwjSiqXGIVyIg4oG9LwUnkozXmongytSADI1kE51RuSFpKJie1o1HGKvgx
58LxB48+9/luwKoaf09FTH/Ch70hfycyGmXzKs9Y3EotqdtFLtLLTmZOvnhv4lBs0QyB0JvfxOWw
iNPu7CrRGVctR1qR/DuDoHdOsnJNjDRB5k8hLgVr+a1A55vmPNkvRqslwm==