<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnDxHPFknRsazydGiFFbNnfWzUqA/nEkRuAuue5IHigwyxhQpBalUm41meVDA7Sz2KaHh++V
QCOM3qCoholYdgXTMnvuuP4aeXxwstDSmgeJ7Iw1hg8LvdinSby3D+ipZFhWcRHuOZGqjcstNGDY
pI+W383LMgDbpY/mgFsPsqKv2O6wQiAyywejXMt87nGGtSBSU4E5+Tc9Jd34ejWCJ2X+Z5lL8jvy
V/z039u7LICsGkTgkFsrz3g63MUoQ9cy7ogkDDmkVTjnBd+zj67wAkOr/2zhzzRoT08FBlT6D5+i
w4ON/+ZtClnj7IO4z5y9szU0niozVSRRKbLXpJ+/x71xaUweOlhZZ/RX7OSMdGeCSP+FVyFYsnXn
vBnUKQiKoB8FDmdC2bYVSkECKCxu1XQ86x/S2YDS9pCu1ogEXpuWKaBElAESXUaxJ/d+KQSrU37+
/z+aD8gX8c62lMHSyUP+fJP6ZunNIv3E8BQZatYWo7XJYaDMiZMVS3dYT08Aiz2Y67IVFHV36dnz
BH9n+efWrVGBlzN1TZZPo/4SdfEF8WdHO5wWidTeAv/fFQyUCw1aTY2/TiYmW96CTrJBViIhK605
gsXnMIFJGMzl/5q1w38xn57QKF2pu1uLSC+iWMz+FNEVzHcW2gmtFqEQuvacck6EK2XOwUaY2EaN
uWnU8qucWKms8DjZGOZPekyBWtdYSc5NTxJZdVhMNOObH2RLGiPQh/p1nqYMbSbzkQrtNXi1gKgf
GhRdDgyYQtwTjIz6IhaTQK77SDb1cjyXRwFBDVClNmMVhd9Eoi+vo3bA+yAIBdvQbVNdDZqsSxPg
ZHhLHZg47MC32+oz0ST87/RUszqSaw9sN/Gis67wnyBNlrtDC3YcXq1G17iXFchdPsAVcXWuvdo9
Z2DycRO4RPdVlaKJsChFW7Nes1/6PYinhmyq10C/E8Dr37LbOB56zjLfJURmcADGOEUxyEvQyPdX
b1W3DBgoTy3un0L5ZkkSgthktE8mpf5/JinkQ3SddkB8a5kPgSYDoP+GULiR9t5loy4tBq7/TF2+
AI2FodW196n1HIKJKDD52kyEUYOKxSSaGozn9byuzw8I2F7lEdm+ZV5z4pYirtX+uFk0f1avCkh+
b12BvyxYU+uEOgb5DT0c44kP0Cf4IIVdnQrtHtGPi2gIWUj6ZuGDwkB9Obs0ESQ5UMwHIIbLgj77
FPfGbbXatzdVc7Xlin6Ix1hBN/aoNU41gq7pSq+NGby58fE1NNkV824GkvN6OphbI4ke0qVme1qN
g85z3YTs8paUsx98nRGuMKOLzj33vbFE7xUoZYgVuAcVtc9YBHep6Ek6GQPs/mBc3WXewr5FGqzl
P0zzpb2Cq/ccP8tEcQW8k2prwYO+rY5g0hR/jdQf9be5APqm3nJWmL2bz6YhbAkL6orcg1ce3jrP
SCF0LqlG1D9f/8ujQk7Df/rVW828RBZw4bAFtANT+i1BEbNzbwYGx+M5ZcZ8k/qxi9LRo3R/xiVo
RvTzboO5a/EKtZ7jxuPLhuJrRJR96zrtk/L18Gkr9CSiHLS60fpY2RX592iWzSjO8f6bO4dmMb3/
1Sd1OJyo4nrWKFd8126yPR/s5oPAQVjtseqmp8xo9NhdRpMbTQyS2ibUJHsuOcWj3c5n10ja7v9/
fHN6ai7o0Hn0dk/uU07Ufpg1k8uOBL/P9rkN+r0EpC2DXnLc0BYBWQMrvARk887MIhZMva4rAedG
IQfSaudVhQ+CEc5OuMwNlgvOLGzvGmVEzJKi8DrPGujxpxUZnD0RI86Fv9jFbKiQJiI8KPFkbaUM
z205VpCeqZMWQw14lI9DWF+vox4MRBYVvpqVdGCzOGXpkJz2E+8=