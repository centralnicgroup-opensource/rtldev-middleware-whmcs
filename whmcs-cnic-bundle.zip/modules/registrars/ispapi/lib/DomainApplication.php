<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnJ9uVFo5zh4YtjqqFMbkCpsGtABii+/uk4jPi0jm+xXrCYayFyH1Ir02vdRl1bNfMgXsZMi
EwHH1bpnpSzfQFWNbjWoWCiUjOh++DIjR2s3L5FC44QP9LAgWqNSROQPbK/+DBirr6UWL6NeORhz
UzheGR7vgjkzmLOAP1XFmcYDo7Le9hwegWkxzWqivL+ggPqBYOB6h4ZowL+3a9IH28s9N/QuOd30
l+eOLRCdBdrdYlmFJtf+KMt5sVwz4+XFCeOCLH5OmHc7YsTKV51AV9cOMRTMSJuuCqp+ILba7znx
hKse5mOt2mIv+WoN67lu6gm+SltUJ/6dmrF0TKOzPGSkXcjrwZTE9lWa/lIbRvIrVCB0U93TPqkM
s8hhNLHr7PCdbMMX+EpgV7Sj+aygP9z1Z0e6YVE6hqcNtzOZfpvK9eoHl9pxwGrEdUFg439XF+ui
MBhcExxyrN1TCzSTdIJSXTkJt8RmK3kNu9V5eIyo5PUKASoThc97g/zr+a6jkCBNXbiqxrLudcLb
IbTplALJwSbefZJPskV0S2piwrTINw9K6/vMJ8W79LC/G+i2KVm6NFhH3nuh91WCi0kL93HuqGLU
pjbws6UVS3WJie32wx42o+28Di7FHCDWfpEoGPm8JtNThi5C/rJZJnSSmZg+KeV5gUM3qwMq+QG8
ie7SxlkgTo4Rikwd7W199euDRYexhgMg2ABzi6w95xmYNQAyzJqZsdeIpXynru9ihVP3eA30UKyQ
TA5ikfHfpJs4P1FH7+PztBfjEvmDy9XD6+dHiD9EvVhxO2/ezsDgRsoSqM3TgTFZ4BN6yLUCuQ90
0fuDk5yPXRquSfY9UsB2iua1YPRAxyuE6wirXfrtHvUZrHdLUfF3GzFwOERfuBcr6kw3GZl04TSw
ayFoLyhzBBBqUjz+obXqVBQ6lJRQ+MrpmqeIUkJAEsyu0v3GE9lwewXrzulKYoSaFsFFC3NyvCu8
2O0pZGuuE6zF2omVJpq4+KYcimJ+FpylUV/w8+gKw8bLh0l4aTYupgtUXNaiOQtY/y3c0UtCVR3f
SuSfO0xHlrRjkfPdNTGGlN3k2jzStRMzgAXhdObWPO/B6rwdmxU5YPIWRVi05D3bJLMP+cqPcKDb
Ei9jLHFl0dqsKjA2Tghv5xIJtoyw/OpT4p0DFZ7KG3+8Oh8WtqpEyEtaXCCXMmXjVKukXO2K3O+E
Y8P73RWpeHzEuK1CDas1cyjEKEDUrKUqRhppxa94cUb6uwgR+S+he5zcy4T2yDuOVPGIkS6Pz7+Y
sNMSlAL1bIwOYZLzGD3gmHHs5KsDgVGLZhZSZMNG4n02rEhdunMNN8rHANEkJ9TjS1kHIVnc1TBl
zptNTeR3t22K/RRamVvYzhkpw8rHQ8cM0nN5pvrgCxsvJqqM9PLQY0sen1kMqGS7U13JjUGNP8uY
Muew+oucSVhds815KbylxLR42DaCBI04ATXuS4zgkS6cefYbHlsUbSElIo/wYJexYmGWAdNNjRg7
Ae+4cK3x5Wb3AtgoDjfSXjBODD84A42xI2H+v96X9FuhWf+g64HD9bkx39h7nSvKnO1vqFCVYRcM
2WguFk2Da3t1qNgOnEjztdoMa3rQyZtt7V+u6BCH/zZ8uwT9IHm5xkGp66V8c8IM3oE0ClUngasA
ymaiOBgakKFnvpxaV/U2dWeGXpjYzoTzEmwLldIYgmvbksga4YMZh6TCkT9KvsbKl4fZIwpDcV63
mY4jw+0IlMt1Fqg1ohEKZUfRBXqEFgKzUNCq3m03yev4ynsi6xjZ0JXzIW69VTya9Axs/HrSrRnO
SaUAkjgPQKbTzxucK1+bffjKatUqggQaWqxB9bWV01o+KZx1EVX4gA6NLxVj