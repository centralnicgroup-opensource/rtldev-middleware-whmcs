<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr9sCP4uteccnSIaikvT+kDozUeFxbJ0LFsb0T8a46MzQlVTDUM/2cTWKmV0R47PGxxBwMsz
eOonJHlMy5mb/V7mUmO+cQMUfONmPNBbLwDNK2cc8Pmt3Hrn6Wo9kiDHHtNjP/QHhWMa9M5gQONS
1T6B1qh/hxqzQI5OdeRCcP8K47MAHhukmobzVXRXSdHoEXsfjLc9pekiNxmK7nX4OIL3OwOTh+rR
OuAG5yzh1oyzM7+GNrhFKWTPHThPnzxMeHArs4fzvT9yD39gwpBCSAKL+RhwQ93nSthcUWlCHsb7
yI0e8S8TAM/4wjj8bTSWEK2a0P1Xzbqji26CPblcs9IBS2cOWfNAXO+XbLA0NKqEGwa0syrUjtaY
5asEj4wGvlZwe1qzncucKFxpxyjSKQqrgOCrShJ6kL0b8CM2B4KOlnvdYqjWG9RIV7QCP3BMwRPi
IJc6SIkzosOEyo7btCMbfCZyjWRdvS4vCv1AFhLggvBaL4I//vMxjR5a48cpQFJnbeqbXuNL7wJ3
3roZUTN5CMl5D3Yvfpecintxvge3D5NNS9tLou6cVpjKLo31h/EPX/AcTulwdtnm8DZNc8J21QsO
LwYvAbUsV6fWKuxWnNcVfZbn1c6xKrAv3e8rn90fAVb2Fpu1sGEtYY/WejDbLKZ12RgV88i47YsZ
xJZLsEp5w4h6m4mFTqYd8zxTHgFBsLlz8EzObjKQE3zdL9pOiFDEyGbCXGR1pOz+xTJvz/YxxT7Q
dfmtv5HiQfiJPo64ZTPKjGCNQ8xlfN3WQm8ZjcOYA+oRhLDteva5DikOpKrCLfgD21ideIPrwgAt
2TY3m6WAA6mSOKwu/Pjnk1wrFXKVFQa1JK3puog5Ee5D8jDHsh9aooZmEd6g0zqIEEz/W/uwHo1n
BTXiTlQCK0yPW5RqsqclLhB0Hpc4L30E8DOS3qagjLzptvT2Hg5AQlKBeGwOeqmWY45lNEvOTZUb
95bh65oSgLGWGmgdT/yGwoMEd7xUcR3NzRr3vdEkR2WD+27UqcbeDOKFfiQWvunXOkL1x/V2TfFG
7yMUU6OfP0mqX38RYBUAxowTlyle+4vvzNRJC8BwWGPQ58lIm/iB6FDa50whmnCPmmz3s9JK5lfs
f55maB1S836A8dO7oAczDfa0oUjyDwYe56Wzm4GLivekUH4Ln6E3RC/eNAREXSQHAP9XiafplZgD
IF0Nmm6F3csQuT/TWv5ZH7FHMsmm0QlyT3TyDNZo9NlkWPhogMEAw12yrE/PObIY1LptTrtIqsGr
zQ3V5uZLy9dA/kn/icG1Un/IGcf4ANVkJin2jeuKltCXGkoBV4omh1XEbfOi0Tu0ybqzJjoiqTKp
c5QmbME5enu7mQ6VOJegG6Dwtb9cmnBPMj0ZovxG1hflkinAM1D6Ish2uW0HXogB+D1T5tEAosT1
+Dqm+9ahP87E09waVyXexSZm4+WgCvWQAZvgN/Pc9LzfB6w4fRLsQJ3gxpgdQYSWat9BDmcUfYB9
I16/uidq9EkyOYIzse+LBO3SGnvuxuxK26XskbXNPI9XfhZvzqOmHm8OIfaJ2cf/MeQYTAol9Kgd
bvoxTBcmSTQxaGkMIWqRTrTgmmmbitSHbx7o36y1S5NLMPSTmucweaGjuxVbYgtQGZZ28Szxs3wD
cOMoIFsLtDIAcuapGmlJi0TPqWae3Helr2pcqxoFYDMSmFHTSTlMzUW7TuP8+vJqfSqVTNNAL53s
U/V15di9p3xGtiLvBtDbGCRaWXv9vgR0HHpN0re8bgWH4pBNZomqWmHIk0Dvf/TqdaE7YoSfu+0I
aqFn7TGPTleeh7k4yEj8u/WLSlIQTslg7GsAiD+wXXY/GICHzYs7ttu675b4m3ETeQHBdxy=