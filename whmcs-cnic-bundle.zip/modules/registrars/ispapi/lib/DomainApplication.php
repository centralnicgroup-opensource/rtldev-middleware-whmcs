<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvyxXCby1NtkUOaHwZL/tzqtbzVTmOPjNu2ug3hUknP3N+igVtvE3z2bE+3VPv0v5XImCT/R
i347YJgRx4LOJKPFcYaMtAZ/McChBN7bi6QT38shC3WZ35NlxzWY4wPl8u7IRv7Rd0x5XXBkzXht
RDDH253urJ65vHGYXpSsASX32lzklLC7BU5x8PKSSubxaVlEWKuLRaaPfKsH8XNt+RWEQDW5/eFq
p+qcoaJaKI1dl269sn3DTcalQTyHRunBR85A6dpVV5iY+qGEdJ7xGhOwLGjaC0ZFvVnID5ptyWtY
3sSOMitZowXNZpzCPkWDiVEM6QI8+9chqCTwV6ce8Kp66AgDQKX6DRTANwO/Lhl435llBvTqE2so
y+A9U72ds9zb/zu/TqnwOH13t3qSum7q3npJWRWWb7QB+0d0tPZnVgIgTqH87sBb2Dlz92nB5/BY
xTqUrsXyuxa+FZNH0BLXZDaWcKUHVzQI9kO2e2mRMWfEWOgJdnAe2e7fcXBEUfLLvv6787XwfB0z
Kje9hbsCrWgUmU6SwilkrdAGxtCsQSMsb8K0d4jfj66AxLzN/cZItX5W4EXYyy804J+7djplPHAh
9xJ6U2lfAzpkPHa4If5NxpMb2kfQrHoyqX5XM/QMrcYsPGzUmSmhx93x5t86C++ndAB36CdKBZ/r
bvWmtOmEnJQw6UZkmlUxVY0vRret/u2EpufT+Llj6AvwwzalL6h0YzPXI6GuVw4VG0XGjk3HDoDc
CqQ86kXznjfbCrKsQJgNS8/bLA2I8LemIEdbJXJsPxs4Vdb8S5eVAkVeYPsJhLNwIsqPon8xU+A0
UKCS/W9KO5cM5m6gpw+MlIH3Rjh8R3FTfOHVATvj2JJguwslqLgUDGaBqYhiv91CyCpiUUqeqNam
/Lv8NuIVHE3i4mO4/6cptBmsN+kPVQ0Tclx1UL13NW6Jl3Jxxg6EuPdBStqRG/k2kyAK0n1rnLJ4
L/jpt1Zb+ZqVVl+L2Jv1lVVYC++aP/MpEH3KLvKGFdBxjSIJS0WaR8O1Mxv7BXzUDQ4oqFkDai07
+dR3OB3g2VwPOcsKizztJ/Oxyo04PkPF9rd0Po2r6lGb/t0VUKn/9pKAG+qIp08Mg0JfmwWSYCIf
QGnlKSiKNkmv6+TbbfLNYuErj9oEHWn5Poxofbow6dnv4CiO5oIdwBwaRAvlhKf19WSpq8GJnWfM
EZRj/ai+1C4CwvGEchSavFqLgWljpfszWGvLf3MX8lrin36tnzQPGQUWQjkZXmWXBDHrWnnSDW36
+GSVXc7HPQIM/HCxx/P+CYZdw6kJSDyG2FlxKjHdIVosGnuhcnWc8pi0kQgwG952us2g1RDg5cXJ
pJhONZ7Ew3SrPL75Tmg/oEK3Xbi4smfivk0j7vhIvEYaW491nwXB1F4Mn2XjUaVh+9hG+3HoXWu2
SCCL+2tW67a5axlm5vPGdbW0/e642/gRu0r9xaiX2Lg8PqOMn2S4BFSnzDCfbZiJ5xDrisfkzvO7
UmWN6HOHaph0IilKj7QIAEZhr8+/3M9gs57sbZZt44ylbTqaNlLQZKh4Ec1vAOjGJx2UfU5Y1MVn
e/83nLUHyBhwjfOdqKy+Xe7J2+FWEKfnMvUvxBaD0p3vHp13qjvR7ZgFQRJrHrgG1HxXznrEzqyX
qnzucwiTe+RV6hZQprA2Oln+1s96PyDz1pJroy5wAE4DirEHGTVUuKMCLeYVzVnwxhJqXMN2ipE7
mKOQasYSXTZz1ar4fHrWLFCvJ8ZJfnhX9TacSNvAb2IYV23661tuYbfAngc0m8y4ro2xVgHV66R8
2oBzuZj05libC2M4soSxKK2khuVdDyvTcXu3NvprMhujGTUa