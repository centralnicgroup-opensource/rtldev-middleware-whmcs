<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsdCU1po445KYtxjFpxWii99RFs26yPfoD0GgjrqP2mx+kzGT2fsyVRexvEdVAedoKc5NDUi
iip57YWafKNwwtM1KE4SR24IsorRl6lT+NDH1Y85e9svQgfwcWFzHrFAMj9QznOqVZAYhpkde83N
x/BOfAKLA6YIDwGuBbgObYpqaVkTZgJD+H4tmAygkFlJXw76vZGNM3HQ47qnmKIZiPgjKnq0LhyA
7iAVEuf2u2GsTR5YCJUQX3Y6iBLnC2mQzoxjyC0ecS5h5/SQ9v2j2HIeQ9bpQG8m95r/11wYVQ8N
rnmd6/+h82rtFL2TDZdSX9H0GqmcjF+8Hv80Bk0J1zyFjphJr/t4Q9C/2aH/VzXWeCEDmckk2ZXb
HTDuhf+hnVQAHVllKUMIUnoaR9xzQSfBCPhMrWdk7zwT/bEXolZSj/H3EyesKrbeY0Kp1F89MHxj
HykiGQ2T5Q3xlE8/5NkzdGVvFptL3QMvmHyAGtMi11OZ4tfF+z60JEXfKNbcGYEO8Gfx9hLEyIQi
tn9dwhJVwo+QhpfQXyFoXbFGkVmXhipVz5DctvitbFeDEiKC6CZ6owz8+BTWsDIMn3wDhRRCZEgw
Nn7XmdGQx+SMTTXIidAVSFPqw5VTq8g8BdaEYbw83ia7UwUxB+Ei9FsGtYrp1+WUHQ3F5B1YtltA
Tt1O0IB20zGjkhzaO+MpppJYpQ+sFXyEC2KRXxKxGuEHX8yz1OHNSPlDNgQ+TEa6HvH+g54p+MNp
ji1vzCtcH1YRgL+qjvOlffbwu7uG3OuKpWfe991T89hYi4f8O2iQaS9N2OVkUeEUKuVGB0gI/eNW
9HNIhbxccIjE90F7Vv0R5TjP5tZ9zlzX5bFPeBypqK0zDLrmpV/LZkYddKjbojdb6cV7fDRJ4ZqA
uvSHkGalQDZMOLChf5s2bGufO+94hKlgaVIP+n182zWFbTN+NSDYSuHRWgw0iUbZUF6T18hfdl1M
4/oKFNAMp5CIZeoPt7JlIMvBkr4ZzreKBIGOavScx1mvaP2GXLxfHRB7sFYaCVQ0Kq8hOdgVrUU1
aqI0La8dNzJQd6yJU/7RYRBAHl2Nkmel8231emNzqxLCPTK05QmUHtUNyKpYhG4pGLOd+UhTJiYO
f1vtAFkYOl4YSeh8zMIS1DKOrFiI0S78ntJL/qXuUkRE1QC3AAvzVCC1FSRq6OGS/O/UA+2X2cob
9sdFjqusdZfK0TpjRElnzkwWjX/IaOFhyER1RzR8AWLpU2CCV6aTfSrg3Kq0kzVbzUFQDjauYB0X
6zZ6uU64dMCP9p28O3BtONkvQWOd/aYrxTFQzQ/rbc+UkBQR5ki9B/ym6XtqD4DOVc+tNennI55z
mohAcsiWFiSmqcbjMNez9qcXnzwKlX7qcQZrmgIJfqMaxiRPvzYbYTdQdXJKLQs0dG1HYseUh3R5
Lygb6IwYBDLSWyrHr+Ewpu4AhQiWSgKKkLqDiwPWIGUPZGen7BYUzFkx9in+cfGeClKenzS5NyW7
u+N8aGaAPpyWsbZjcks5m4fpr6B+Q6XfXb7Bzv1hgPgrWXUtP+slnWtFb1Lrscg1q5ll+QWuWvyF
OIPMzFi9urJkboXgy72CZYS9N5dnPTa7Rp8dngiJmIYrCys+6Prv+F1c9XpjMxqiMCecrv0KG4Gv
q2Ed77ADH5ES9p40Y5KvrhzoEMOM3YvLHYWYim8zegs7OqHe8zoviZY2u3KgQ2r+ijQgsMHAg3Lh
CYdvjINWPXrtHAPWheOQcOFksRlkMAXjeHJxBaGl7SwFee+Cg3+zhL4GHEWH/szMjY9tFgfOhrIY
3I3ZIbmZcJusnwfuewKj5/jre2V/IVcYAADX8Kt1BhHrhIsiM4+4KG==