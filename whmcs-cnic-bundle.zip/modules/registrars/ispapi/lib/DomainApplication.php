<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwXJxRErlDM4GE5uaBUGzl3UWGZ6LvQ4xDolSgOaS2AqZfpDO0hBw6+EOAhgewtVNYkpx7j3
ZtRaCYVMNFoaDnB8y586xXhUltYci/Bl4mzYB59N6Ad+QfyNHlE4AjMGlcmqykwTTvQHPWlnTDBU
vRaqQp9CuiF24XJCRQrVc/gofq35xFEclw9EjgOqsxNjXtKR8/u3KBkgXqQbhiDJQQm/pJXwqanC
YpeD3Kt6HnrHqudWAMZIuHI+V1oFx4qerlI9l8ucrFo54BW8Sa3fqXm74PkDSLti2jY3gtBzgic9
aPo7MV/EJrEMX68XHXzwXCIAizCA7kYbPMB3YYynGjnnVyTFE0HSMxFF/BW1wPCICscdSfJxVIAP
mDfvicDVozvmzF01iNx+ahOTyP6sjbFwAJ9Qj8WJVb/aEpz2Bl6s5PPysYdhCxxBHkwTlDZbM6PR
7db+THvI1idJxoTkon93HCAX8GBDRHb9NoMp+vUi1Y3u4mgZJo+GogPLndDS77tQCITMygZoqU9y
kP8U6FipbrAVLTE2hcVZmvbSYTB/xlifZeMhu0Ii9/cYxLb2T0lzsTTLfCyvPB/YfePeJ84A+RVy
IGxe+UorpNnLcXFOmlhDsKR7cO1hFt4bOEr8fNGntsye/vWqeMJlFR991KFNSl/9bS7zjUewl9ei
4yYmXitO3BgH5Hvwa9XXOGUYcjKkkaaGrwUqEyuM38Q2sQ5zVLjYUmVxNyCNMd+75tCEfTz/qlW3
55Qa/6PqTm05XTLU7DdKnZh0g9nZyrLBrGlOTR8K0sAtTGDzDBofXvVYCP0Sxp9hC9GG50i4y6Nh
P4xsSBE2bdDA4EWVbFwl20nbL14k7hflDDHpY3JyK2QFIyT9cu092fBkdqGgJhnETtRQ0EEU/+3l
w3ESr3zORtQcD7eJWYF4+nS59Ni+skmf43hrwKlkXWVEu5ZicWmptea8ngtxc4rlHodEvi9i0A0T
0R7Cmm6OLd3eBT8ofCHkHq/DL9LU9Gk9Re3eZZzLvMUrtA3MYTbKGKNav1J0HNj1VDxn5hIUKAGn
1wDUFaCwRV6eCco2W+ZZrcLAR2JehHgiBACTwvfE2zPnSu7FgJPRBmK8TMX6puqkg3cvC22GDCBH
WJYDcEYKxozKpmB2ngLNjUhZ6IWoPyGx+sI0Lb53Iynv49OXM2X29Bi0Ook1qJvcRumA5mEAmzio
bRy4689cJ1b2U+Z2w6TNBWCuubx5xZT+QZtgd4d0f1HyE1LWFuHytBsX5EgIArSc1Cn9Fvz6d4D0
dWuzAuvCodXAc9WVShsrLFVWzPpyUS1uyQUPT1xdrjBZA1dGHV/3zFVvAyiNa7QFMOzXnfhaHWN8
s+3vNNVXrCscQUZQuhoVi/0ja2kzJTgabjD0kkgZzHRmvkcR5tTfnva3Iy68JPYzWknA5EmDr7BS
hyrgbL9ndpUygaGiIOjpm+vUonc7HpEhqAV5TMRLtywWX0Wf4aSrTIaWiHhqWQEZO/Ht19NmdVrs
4BzRvfC48/7IAjPaLkenNK7tzkCkdQr14stvAvGiZVcy/MotGe0SVN7j7onySmgGbklIK61vv2PH
3zPwgI1mZN2XrLu8tw047N6Q3lTie6V3AGzkTvh0Ba32bSi9cnmBqH/Tjb2nf++U5zuHTrXc07Hb
7eoBr06ml38JXLYI8DzfzcQNDV5GksUSXn/dy2Eqn05Y/M1mHDsaK/IWHSswtR8S5xgarZt0+4+T
sUB6sgerSK7XUI8Zoaw1xDfHz4MaZWzrk6OtgPvSVQru4AUekrSYXPA8uAGK+PVN8JOBa0mT74Zr
Of9W7M6P/OP+iMhPRDdVuy5+0kPi664fcJtTQZ++0qiuNW==