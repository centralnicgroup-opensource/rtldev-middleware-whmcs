<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz08fpt/gjGRCZcwCXu7ROIf9jd4rbeWcf+uz4+pqlN9qTT5N9+imrfUITXGri9GdxLrpifa
ZzxkYXnxv3Yi/AY2qKxke4KcDN2UROxj962giWgPOAlCpFM4uSQOSgOJfemjHCWUX3AtG88MWlIg
//UhRJHxNDIEHXtMScIOGdct8yH1c/B+q/4rnKTBlWi2owPXcP8ZHzHVlYSa5c9rmVIxy4cYK8Ge
PtThkEia9Mr/DRjDT4WU/bOiij6uD881dR1REPx11iLtV7WoGwx5smpwtTLjPMyvMA+xMk1/0myu
Q0SCcJK/i4OgIl7r90xuz68N5vLWgU1kXBci10EEgLEtFZdzjPTVXzf+6fC8A4Yv7q5+cFpFxv0o
HcJdiBGKy4JvgqJtg8sw0Cfrs0F9aXwLid80MkSq92Sf6Qx5G49dbeU35sGapzGDdMaqPXZ9lDn6
yS3UNdVFZWscmC6GX/d8w4pGpvuIqbWBhmCic6Mejdupri40raFzodl/u8nzIcMmPnv1V/Lzb2Zm
s0j9zqYwHRWtrurq1CtgGSbGXkJdGEyhNo/lj/e44BTAJ0WAj5m7m9crDCphOLoSV4pqC/esUcoF
7FqB2eGCJrjht6tBvR7fYm+4+7041Oz1eI7fpDg/uL6uBsj4X4Bxl3GpdrilGxwjSXiAjCanRj4F
PZYTpsHO+lSPyDCYRpjVoYw1EvpBc5G3jPdpOYTrVavnRBW0DF60CDCuH08bYWcBVtcwf7iYMjpz
f+IBxsTao69z+nlpAoAs6JykphbZIJfjmzHcGzCPXfcRf1e6KY2MzLSsLaKBVy9E2x4eItuF6bA3
QQwmFl6xbMqPnaVS+IjjhrHu36Eoxq40r2+rTlGC+RciMH/hL6fg6bNUPZ0N52fWE9RKu8xqqjxU
nZ7UOmJk31OuFbr6qXPUwdKecQl9zk7AP57TNS3BXYPFJrGg8oMNbB7ChQJt1LvogfTHkZ+T/0WD
2tgkbHtm9qo80FyjcbEx+D6cTSlXuh0oSDDowcLV2p1r2Vk0pVj3PhKbsBJcEeOP75thSTD+kMri
RYZQ6mFHNeJaEqt70WLrOP9uXMqHPpU+HXBxlh+XqZ4TbaSgMbrwo5rDZg//HjdKX+o0FPd7+vKB
TQmcYuQbZYgmOr+qBWFsuBejNdyGzZUv4AaYHqFUh+OvaqYeIyUyNtvyWSRjGkkYmbD8LG/n0aSX
Psv65tnjvKOB4nUlSKHJfc/lwjr9Rp9XVCPjDtjIJ084H5aOWxFhJyRkHLOr31tlKPBVK+I0U+44
gmvMlovfTbh0BSrXsYJg4YYUO6qpeFh0dE898R9EbqTLmYDVuSPPLHO9BRemN5h2gD+aEJDC3EGX
6k5quTSzeUsGGicxtbJIR9QXfwbSDVtg6TrWaV4apOVr/NMySfXREiyKt52zt+epPPiYk75qrBPs
qkFBH/u/2K5ml+IP5rUfPoC+1Bp/rPQnPHFm6XuUkOfsGsdCV96J8//kEPMN06pQJR1RlwmKcewI
VYFGO4TgvdEZIBGKVUT6vsSkcfCODsNumB0nWkHxt2XBRWnssWwcQUhN3AJTlcJ6UxsZoWb/gLo1
cKk38ogWmv7Rl8cX46KmR6hz2MRGqPzIiPkPy0jos9dmmZF0VN+FRMF78lAruwMowzZtsFfKWfi+
13Wo3vVRp/SbQ4YTO0s1f1UPjoV2AY+9wYnjoX0ZX7HXY8YEhj6R5uNAI0NAtYnpazWuuN/yGmHK
WQlSTwyHGeKbQ1TrH3diR2xsxZAHtremdiww+RgL3RuAwL7QKZZWW5n0pWkagb/4pyMi0/7/XhFE
TplWNEHfjVPYkEZo8PDBbFoJ7oWcb0qmxZ4dXnjnhaT3x5O=