<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtIMTbmJVakKwYJZVqNdTVZI/rpVhTSN1v+uueGvNDYtG+P/chldbdyEl3eFWsrpe9g8okaj
W4I9h4sPp/rqNerjxYJDd582D151yqfNbAWZNMF8O3LprohX2dAVHXN2NxwfNCXXECHBMqd6HkNu
Mf88WfUPDO6N4HUSy35ShdAftxeeLb8oRL6+MIBt/Wc1Ov00rTtjM5XznV/HTJ6mUWTEQkJDgmXV
uhkdKEfGcafy63U/16Ngtznn1z+dveqwGZeD7gppYEhJ9G9xXWTad9nBMZ9f7agwHyXD0gtT81W8
PsSN/nbJSG+Vh4gENeWH69RwquNOLZ/5c+Y8xmCDUm156MxEs3YoupU/CaZZbXOFvzuz0IJXKeJz
uqznVCCwaaCmnjTfLLbhuIu2L52y9MESdrELqhpG/M5TWVDEC/yqnGwtKeWxjtJuncxPMqdq2gdt
1tLEzAC5MP2+kMQoj0AsL/cyY1vmrMvnUY+/A1eY5rLrVpZoifV9HgnpmOqt5/M94nTDKmNFzvxU
6XuaiJUaesncQH0wVGM92u4XkqE6I09kM3MWpqokqaUmPtHnsFY2uxtaN2wPBqRcx2soPsi31eqV
Tc+xuIXumBwxiDHeOiq0xFmuM2M7RTOF7IipJ11tp3PfZwyX1TPvTbUO5c28nzVPNlBr0j0fXymq
6kieYviPlksGWwSF/kVZ55OfZYxmnYNNfd9W4796Lj8qTx56k/S1pgVwvJKgGOaYf89rW5BvlBhp
qWOjxtL1sWa+TUWsQFm70IoeSh0D6YpRbl47D8K2IfPbUe3or/Bq9NWxZjl9cEs2jAlaY1sAdY0h
G9MhHTRcv0wZ2fuQ7AZTm7HDmBxwoE67vpLWu9+cBDr3jjgkP0mvoXIaacRUKeW8/5/mPMeAyII8
jzwLyHT59E6cJn0Kx3qdjKgyyG6GVvzrzNmINHRZM1d1w13ASE0+n4K7/toXRNt6a7uPCIvnmyUv
QMa1VCM9qjdbAGZK7UDY4UCmFOc03wESSZt5ZKuLKP8RWKZjn0prXbIbuGDBKGkS/ReK24Q9/cjQ
1GE0w+kI1vuR+t8CbbcMPEVJrYUhrttGBZPMDAMVDWJ2sNs2iYdV3VCm3w6mOnrmJ63p61dlC4Zy
Lre4dww0vtR/3SedTWBdh2dcMiNbB1krv0qiToUr94VnK9YLxJjKdOTh+uDrG3qQoP5UTr6eHeS7
CDL45dfZVxriEF6/iNcNZy0dKjgOjGedkB99iX+uKCc4L326kf/j+iP3/r3ih1SRYJlTdX1EQyna
RlOE2ffcr+zQUbFLmFRuCbwM9rbEv+aIsBZkWGp9MDzOBnVU+HkFPErmDhv97aNg6EbIbc30BGog
Kb9in/+JvVSmOQRMnEzYtuCKWudXLMhtk57HyhHw7a7FP0ujkepXDCdPm64qxquNjh+xOMNpLxJ7
8mRdPRBvX2/NcEUUsdHHKp3QcGnVBg1T0jAwUqQrWR6gdEVV4PnbRIOnZY55IpjZoKxVcM1+550B
Cu3VQpUdj6Z1UgV1xGy+bIGkTNr6mFrTtL9TEVdeE88nFkTR1jS4VbkXiagoeyL1BHQ2HWZ46gAN
guowMshvFuCsaDHVd6yZpVFyyS/yfS/tUggSbGfu09qiYqxceSJgu+U4zTZrpfjHa8a4UCTcUj8T
8ZYPah9Hi6NpcPTMh12KN5V+5uQNZoM156XVni9EGYBC4pXKv68hY2WHYtJqNm/lWtCottdjL6Gv
TLnxmMLfj7tY9OdxGwPUEvN2kNluUBNSvMQQsx7tyO6Ip7VoL4dYYAeUWzO3CIdAo84gjzI4+Sut
UxzX63fj1eC0KcsgstV17oF+KcSci83DFeE6dLtaDsBvOkVtlpZ8iOrCIeq=