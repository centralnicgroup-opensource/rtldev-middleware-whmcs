<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class Dns
{
    /**
     * get domain status
     * @param array $params common module parameters
     * @param string $dnszone puny code dnszone name
     * @return array
     */
    public static function getStatus($params, $dnszone)
    {
        if (!preg_match("/\.$/", $dnszone)) {
            $dnszone .= ".";
        }
        // DANGER! statusdnszone resolves for "hidden" dnszones
        // which are not visible to CP (QueryDNSZoneList command)
        $r = Ispapi::call([
            "COMMAND" => "QueryDNSZoneList",
            "DNSZONE" => $dnszone
        ], $params);
        if ($r["CODE"] !== "200") {
            return [
                "success" => false,
                "error" => "Loading dnszone status failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        if ($r["PROPERTY"]["COUNT"][0] === "0") {
            return [
                "success" => false,
                "error" => "Object not found or hidden.",
                "errorcode" => "545"
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }

    public static function parseRecordA($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)?$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $rdlength, $address) = $m;
        if (!empty($address)) {
            return [
                "name" => $name,
                "ttl" => $ttl,
                "class" => $class,
                "type" => $type,
                "rdlength" => $rdlength,
                "address" => $address
            ];
        }
        return [
            "name" => $name,
            "ttl" => $ttl,
            "class" => $class,
            "type" => $type,
            "address" => $rdlength
        ];
    }
    public static function parseRecordAAAA($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $data) = $m;
        return [
            "name" => $name,
            "ttl" => $ttl,
            "class" => $class,
            "type" => $type,
            "address" => $data
        ];
    }
    public static function parseRecordTXT($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $text) = $m;
        return [
            "name" => $name,
            "ttl" => $ttl,
            "class" => $class,
            "type" => $type,
            "text" => "\"" . $rr . "\"" // TODO really necessary, our API should do that
        ];
    }
    public static function parseRecordPRT($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $address, $ttl, $class, $type, $name) = $m;
        return [
            "address" => $address,
            "ttl" => $ttl,
            "class" => $class,
            "type" => $type,
            "name" => $name
        ];
    }
    public static function parseRecordCNAME($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $target) = $m;
        return [
            "name" => $name,
            "ttl" => $ttl, // TODO: TTL really existing?
            "class" => $class,
            "type" => $type,
            "target" => $target
        ];
    }
    public static function parseRecordMX($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s])$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $priority, $target) = $m;
        return [
            "name" => $name,
            "ttl" => $ttl, // TODO: TTL really existing?
            "class" => $class,
            "type" => $type,
            "priority" => $priority,
            "target" => $target
        ];
    }
    public static function parseRecordNS($rr)
    {
        //matches CNAME
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $target) = $m;
        return [
            "name" => $name,
            "ttl" => $ttl,
            "class" => $class,
            "type" => $type,
            "target" => $target
        ];
    }
    public static function parseRecordSPF($rr)
    {
        //matches TXT
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $ttl, $class, $type, $text) = $m;
        return [
            "name" => $name,
            "ttl" => $ttl,
            "class" => $class,
            "type" => $type,
            "text" => "\"" . $text . "\"" // TODO quoting maybe superfluous
        ];
    }
    public static function parseRecordSOA($rr)
    {
        if (!preg_match("/^([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)\s([^\s]+)$/", $rr, $m)) {
            return false;
        }
        list($rr, $name, $class, $type, $mname, $rname, $serial, $refresh, $retry, $expire, $ttl) = $m;
        return [
            "name" => $name,
            "class" => $class,
            "type" => $type,
            "mname" => $mname, //TODO multiple ones supported?
            "rname" => $rname,
            "serial" => $serial,
            "refresh" => $refresh,
            "retry" => $retry,
            "expire" => $expire,
            "ttl" => $ttl
        ];
    }
    private static function requestRRs($params, $dnszone)
    {
        $rrlist = Ispapi::call([
            "COMMAND" => "QueryDNSZoneRRList",
            "DNSZONE" => $dnszone,
            "SHORT" => 1
        ], $params);
        if ($rrlist["CODE"] !== "200") {
            return [
                "success" => false,
                "error" => "Loading Resource Records List failed. (" . $rrlist["CODE"] . " " . $rrlist["DESCRIPTION"] . ")",
                "errorcode" => $rrlist["CODE"]
            ];
        }
        return [
            "success" => true,
            "data" => $rrlist["PROPERTY"]
        ];
    }
    public static function getCountRRs($params, $dnszone)
    {
        $rrlist = self::requestRRs($params, $dnszone);
        if (!$rrlist["success"]) {
            return $rrlist;
        }
        return [
            "success" => true,
            "totalrecords" => (int)$rrlist["data"]["TOTAL"][0]
        ];
    }
    public static function getRRs($params, $dnszone)
    {
        $rrlist = self::requestRRs($params, $dnszone, true);
        if (!$rrlist["success"]) {
            return $rrlist;
        }
        $rrs = [];
        $unmatched = [];
        foreach ($rrlist["data"]["RR"] as $rr) {
            $matched = preg_match("/^[^\s]+\s[^\s]+\s[^\s]+\s([^\s]+)\s.+$/", $rr, $m);
            if ($matched) {
                $fn = "parseRecord" . strtoupper($m[1]);
                if (is_callable(["\WHMCS\Module\Registrar\Ispapi\Ispapi\Dns", $fn])) {
                    $rec = \WHMCS\Module\Registrar\Ispapi\Dns::$fn($rr);
                    if ($rec) {
                        $rrs[] = $rr;
                        continue;
                    }
                }
            }
            $unmatched[] = $rr;
        }
        return [
            "success" => true,
            "records" => $rrs,
            "unmatched" => $unmatched
        ];
    }
    public static function create($params, $dnszone)
    {
        $r = Ispapi::call([
            "COMMAND" => "CreateDNSZone",
            "DNSZONE" => $dnszone,
            "EXTERNAL" => 0
        ], $params);
        if ($r["CODE"] !== "200") {
            return [
                "success" => false,
                "error" => "Creating non-hidden DNSZone failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }
}
