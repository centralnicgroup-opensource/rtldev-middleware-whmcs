<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyw8/JMSMCOwMKLe5ddGS9+IAM6GIfRtFVaehNDTvOA9GT5bwvcu8exZ0xCVpZQfloAGekzt
+0bM4wbljuec1sDxjO+FrJZoyoeZsNHHEBbSLRCz8A4NiF1cxr0x291d4+06IKWGOIyqSD4UC8+X
hMt71+F2VGsSh4c2oCZgxaidKC18lWokWIfnk7AXrCREv7/+FoeTI4Wa1e946IkTYBg2r2NlPY8t
iHqtepxmSAmEZ+R+sITLs4dFxrIjNXdjRlNXRNBTjfIwBP1AAYqc6eIq/ZW6Px2rTrxqNVCiZ652
tTQ7FKOwGYK8a9bh++TXyd7dAKhPL9KprOLTZ/wmxRZt42yOffP3p6+JpZRnpViU9kRF5o4DIPOX
uInl22D3ylzN5bcstPODNyrQdQbf43E+XnZhdiz+qgjxELa/QtI9pdyHAoo03/udE3dGxc0RZ5Z+
UggVNdULQVFvfqILKmLX7rvtwwk6n2sZoiS3xPUN4K0WIx3sXtHNS00EWMvl15OHpPbg8fiVWoGI
+/hrkoyQkz/tOBx2znlh0kIwPMmEYwYhDW8gV0arA4VsmFmrZMhhaS5oks22LJvrcZczDhjX2xbV
cpGxL+ludgQqfzWCR5GDK7gNH4v0jZ9xrDJmtZerRTUSFroVpeVe/x8S5z3y0H3I/bopCYyNIWo0
XNQqX64gPxKpdAaDAjWoJVJMiqSvMsuO+G5ynbznUlqH3PeWayMHeqYmHLTWntwO5sI0TM9Fputd
TJa80fIgbBdcZqOpzhx6t2L0f/CcROEGdIdyzKEP46h6jCooTPCCrdLlWiNsixrDp66+kdCuUiDa
aYwLTmk2+yqVERI7sBd5AstJo4HVLvLcVt1hvtPp+mUzMcpJJ8RqZYQ5UAXm0S4TPs9DMoQnHJGF
p6gC1z8mAuB7rFV6bTnUnPAetnptWRNV5776rAKMwz4EPXOH4VEOdAIstM6MfCO5LG2iqcAUVIh2
V3O+1FsobjvNpwhyvlZH1irlZoCvJKIaP4GYyrvS3PpJVdFFfqeo17GLvgHYb1Aan8UhF+iLxBco
x27oZq/eBWnh8Pp0naEK1bqnVK7bndss4sJd+59srIVi0+hPzCqpMSyJ25Vix91bUsj+uYiOcq7q
pljl0i87BGP0J0JpAICMfpeiiDx34zSZoO0cre5pY75DZwL2GRPDJotWEBsM/BILCGAU/3qh3Pux
rBVHnmlQiwT21tUGk6u4zs+4d65QCnHOPolfh7+nYbt3zJezaciTolzyC///Dk6zSxQF2v+7+pCn
svo8v4XtQH9SyeFh/ePpJDdFmUQmDoB2U+H4Updy7EZc+pxe90UAql0kC5ylA8bdqzJxws0aGF/o
dUNdGspelbwS8AdMOZa0+76MIdu5Aqx6Dt6Z8q2kHGE1WffmktqeomYPheacZtC/ejapmZgP6ENk
Kt0iwD96T7GrJrsO5A6DgqELRrt5++2OSKO6Z1x1L+DEuX41w1D734lA8wp2ocXdwcWqZhMpXNuQ
cnReWv3ll0hFBrFLIsR6jcHNBqb4dW2m/cnROuqKPmNhUWTrcEUhii7xKYN5S8QSzTVwMIGF9QDx
C2FtKrbuuAUYlLx3W/uWH8sPfn7ao40Aj5SFYLvhxLzppA//GlfIRvngaRF7D8NNB6QiW5sFTlMY
SmYMmayLJkUGL/C9K13uTOzVqeFfBX3/kU45cPtQN0LuGr6YHgNosbgMq2IEmYyTk8jxX4aJK4ld
nyFgsufxttWUkTXG2RdAg7wVtZdCWDy4kP238KsKJqe9IvdRz1uaF+1Tx5YbOrgaeOgekhfjYKsu
+Cy2KFC9Y8Zgu2uf0JVyZxFlelyH9B2sY6IRNRH9yceTgxR9HcfCAl1eaZjNNDj+xdWgNYgraOZ6
/0qYyTGH+jeY9uNeOsNBasMgqNHpjFM/bqULXIThQeVgkthRUuV4ODLfnjuGPIT5qHqchtoninA8
+jwbFlMud3e2UlhkKKMqVa3Fu6lJel9JWZAONVqv+/0lNQtKwMCt5TsQErfOG7HkiY9+qf+fckIy
nIt85GRqfrz7FaplvnWDX3S2jRDDl4N5VmqBiokTlVJNAcplO58HmumfdO2C+jRvDqnpUTHTbOQa
AU41SVSpI5O926n4Py9xEUZDVNMIo+/YunIb9kiuj1fagi0V2DoyJ4BV79xKJr1mdTiUQt19aChN
VhE1j4snnx8wIcnxU8WVgSOQATvMfMm0CWdpATZeGNmJ5zQxDkrzM8GtgimCCuorRMpU4CRJlrvU
JGTehJeZIkBaO6/rvJWUOZUHV7wEb2/XuOVhj7ocob6DjpesyR0irWg/09bKIALhurnB1QVV/MIw
hbPLV7Dq90w0N43iRBo19Gb9WyK2XSieXc3Pt8AOQc4QIV+KHrenoa/UQgaFoPSbMXmdpdkr4LDA
T09oj+p/zSaDLUR8kpXVvffI8+T5BlefltNw1VLEEU3kD45KLA2Myn0r521Hb0i4PtzTb3dNEZAp
cvLtpLW0jn2vxvdu6UgsK9jgex+g8ZRtu5xs4cXUJ0dtCcCS1Er8gFbgEPsTM2kfzDmIFLnYwfoR
+SuJObwwENupFyIwSbINfV8pLJR3B9IXDiFJx0zkCh94aLZM+HnC0LfKYpb1VkYHDmcVImaOB5q7
YFre3Q9Q+V9b+F0o+WLOR5uKc3fN0g6fZe7LPDb277oSGR7LyKMgeLKlBQLPY7XpjGV9o8v7flgn
mbokVmrJVPpgTA2OvoEO78FUrG4sZZQEw6ue7O/Wxu+iuU2+QGIWoVVGcP1Waz/xv4R76b43Rsga
KzaWbu1efj3likEftRAQf2jdgbQAggnU3diRG60e4htbBpXyd+JgsV/ELQs/snMSYVf5b/5HOzUc
jVbBh8L8Kuo3W91FFIdLD5cdj+JK4JW=