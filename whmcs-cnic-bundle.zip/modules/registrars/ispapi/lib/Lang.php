<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn1wLC3+wwptXxV1uucvNslTQHkGFVW+g+9M6RQX5Kk02g0l47jlyh2eiW7x5Jz6nD7afi2t
xgpl2RyCUCM/PB8P0VjJ8qmJMsG9Xra/s7TF3owN9D7xVD2YLG5RZNUMtyg0NsZhn2gswUBDVtvn
50ATONzj8y9iWY+q76fr7ePM/Zdt3T8bhFKaVMVq6r0H1aeiBOYdI7Mgap8NOIHW6IHnxOM+O7bT
D74d7ln3haKY1DxKvifzorr9ihRQ5+nEJMg1rXwiyuZgqoK2UuO7P9oSIrhAPL65pzYXMkNwUT/O
roWeFQ1aBfxEPeBQlPvYDeabNfGMj6HDNA6PmR/jJg+TehnSn9mhQVh7Son40QKRJI+5j/Eg9VnY
xEDReMUaHWU90ZQ0O3AMFJBrzZK2ewzfJ8tR/qaShIDjp9SXeUHXDiE9wH8fqV0L6iXUFTnVCb9w
DqZwqcSKRC3Tgsf2BzOL6gWD+Jbo7sBZKHAL1egJ4RHfsVvRxtLwfVlwHUGJcyJEwcKtdO8rNcbH
I3/kn7EhmnxNkTdWReIx4Ar2XoRXsOYkOTfWA8pMxwOInAWEineHQNyAnmzFirMRAV//hrIRrFSL
woBe8HqlPh6dN16dOxGWDeXVV33Z8W6SspYMVbAONKx08SLA3vizpm578cvbPzlockcmYugtO7ii
mjQMfOi9sv0uhTnN/HEhrHFtio9905T4XRNlAxKT6opLbtXy5PqJWFTwD8zNR+soPgITs3EOp9fq
0kH821YGPD2O49+egCh5tocgPjWB4+NFlGEsX8v5hyOArPSkkzJYBDSiSi/QTdrSX1vL64DY7MG1
rAwwg7sagl20stuVxQnTaorjAfL6mUAL2cJzV3cVpglW+B0zAplQ2Y+DR9vrKHCfW3ZY8E9YgZDY
c5ojsmISNUDZaGPjFy+ZIzJqDEtcwtXlyO0UVspfVAV55zANf3Lr7jlVaEBs6E9hrkTi/PT6s7F7
UPF1iYPBWEU1R4WqGkd6wCjadql2ZZeUJNfuBTxBiIKYMcv5c4lHWxSGrwGN0uFF6cEEmkXJIMJD
eT5MBS82K+qFY9vOhwS9CnkqHyhWkuHiRwARsNIJ1FE+lFS0RIvTlj6RFlft2XJ5Hc5ETIqMDu1x
CFxYAwt+6vw3aCiElXyfwkpnTCTwV4WS/FKpwMkOUWOiZx++BNvXqtk2iT9D0UcOPtvg6bi5wVdv
QCBGjHP9TiPEWAJ0olS/Px7CfCkXv/FBszNHrSaUzUckRNxPN4dYfYWMfyoB/3Oxm1qY0wH1sQGe
YLs2Q38FPGvMPqmgrRuMxa8iWQqlFmDQS2fNbzoW1cU6QR5aq4VYq66+A//clMMgVJaj0V8C/v/P
sdKfXvyUvp61EsrUFyFzSMQlZ3P88k+8w59chWUMK/cKjZa4iPSiClo3746uadC+cefRGbkADbj5
ZjmigYkEbjKuK88dnVUaGOL5la6PIv4HuBysRURIHvJ0dWJeUTbo/Dabpw+NEi3+2xktMVYiSNVD
DQJyI0Yam/0MTLb6InLZwhYK3iY/3crS1+m+Glk1jvym8pwOQHzMwmB2RT7qPYWPK40zaZzPe9b4
4ve0ZlnDua0psBlfJeWsXrcXsAfpbDCb4vnfRDQ3MKJ/d+3DBCEwv9g/wXesvyhGtbktXAX27nTw
jFucMdyZaPigCkdSS2S/kt8mMAQSzVipP4p/zrqS4wbPIbWpXwkcBb9VqYVHtT4sByRbAL5FzKqE
N4ImCnQvv2NGUd5bJVV1+F7h1a/F7z/qcYqxCbDN6sYfDo7i6sTPeMwzMBO+/WQxcilgzZCUwLwA
jszZ9PazoZB2pZ7QlxmuCV+qG7gXxGmAM9Yxz1zsfCGvfBvnuufs7gGL4eA8LuwbV2t8HumMD8jD
zw/FCcGau2Y/I+HQjxg1ihAqQ7k17K42Or3wPDf4eFsUjzGl/EQTssZavpr0dZ+Ki3hDgzgPjn2T
fYnNSLjjHOwZ7l4/5cGG+az4U1sDuDMgBz8RjRqiC6C0gjjwcRh5jbWiG4zAX0Oq0LHA3YIoIl/5
zKr4htKOCcmn2kMKYUik7qkH9Cxm8WWEi0S69zyGkRWwThs5qVy1xl/s6gP1IU33V1dYR7Y4FGgb
o6S6gTdLGyjk57oA+PxSYHB/CXNL1jKGaTMAeHsANa8l/RnkmAH66Ct+lm1qstXumzRbVgC4IE/V
dCcpyad6UsdXBvqec36imuN5gPz+REYOjjBkn9KXQalEvqwypcCt0pYj80/3H5daNEqjmqu6bSaz
GKlfutNeSBPju5x5adKPzblxMoh6reG+UJGQfBuOBM+NcvtitWjM6m97QWoVPGwwtF0mC8gVWIq8
/nkbouCkKiw5CFtPDg1kYg9e5VUe1MGCOwOC/ypIpdi86Az5lvI8+vHyHoNcUIEOJNYAHpKIW+4Y
J21hBSRu+BIwlwzLFl5OaVIvytX0YwnIDh+xylJKImOuPeC4PQwN8vN1JgID+pDMIfRqeXxBfQxS
V9IgEQ//79KC7k5NlRYVVnWfn5MZCcA3DiZT24dO8GizoudAPo2r4W50ozQWy6beDMbkKfp3RKAW
rYXTg1TB3yfDLDYVv3g8hv49UzzSGn3Vc+8vQmsHyq8W9PQYytit7ykJHDdMmn40be2zI3eqf4ds
OoJKr6h462gZS5y0kPhgx2n6Ap7aoegE4aBdYFdkyniF03L1B602fcQUzDezMogFukxvAV7jNJXQ
KSic5O7b5JDPP5OJTr1yYaJnt+7TZ/4ngYMQjCWxw3wjUiyYgLzQ0h4MkWIsvzERISQ/ft3ARHvL
S6V2hB9by/NcHQs7oQ4MIYuOF+xLqI2+UxZMyHp4P0wGcCLO9hGmMpMN7sldPXY5sfr4J72vKrz6
ZwDyxdMP63wZKoXg2AXoLg94kRFGFSC=