<?php

namespace WHMCS\Module\Registrar\Ispapi;

/**
 * Lang class
 *
 * Covering translation logics as necessary
 */
class Lang
{
    public static $translations = [];
    public static function trans($transkey)
    {
        $loc = preg_replace("/^override_/", "", \Lang::getLocale());
        $fblocs = \Lang::getFallbackLocales();
        array_unshift($fblocs, $loc);
        $fblocs[] = "english";
        $fblocs = array_values(array_unique($fblocs));
        $found = false;
        foreach ($fblocs as $locale) {
            $found = $found || isset(self::$translations[$locale]);
            if ($found) {
                break;
            }
            $path = implode(DIRECTORY_SEPARATOR, [ROOTDIR, "modules", "registrars", "ispapi", "lang", "overrides", $locale . ".php"]);
            if (file_exists($path)) {
                include($path);
                self::$translations[$locale] = $_LANG;
                $loc = $locale;
                $found = true;
            }
        }
        if (isset(self::$translations[$loc][$transkey])) {
            return self::$translations[$loc][$transkey];
        }
        if (isset(self::$translations["english"][$transkey])) {
            return self::$translations["english"][$transkey];
        }
        // fallback to whmcs standard or override file
        return \Lang::trans($transkey);
    }
}
