<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqD5V+a96aJFr8ZgoaFGhuie/uj8krk/bCqTxAds5kc5Spgl2SKaURhk9aHUTgqcfwFbaAnX
2VwfcYUznJszcR57vqyUpvordoHRwir5meNis+b2K+8eVOkb4JLe6HoVurLgZCJL/NnFaXkxTbBi
cSDpUZFOJmh4BKKlR4eDw/uddQvccLk7PZc2m3EcIya4b4j/FvgkpqscZ/5Kexs8aD4EFosbn2ew
zFfWr5cbqUPbhABHpvIlg/2banALzuFHlIhkeHfyttnR8lj43fqn+qAsEbLPRvCFmYW6tdyL1ZBD
8JzeUlzjmUrWAhqvoIvgzUZINmScJzaiN+7mFThSfBSZp95XKSQ3/EBG9CgH1WyK6kg6cvqmmEnY
QzWWkD8dxNzHb5etRr+amvXH9gpASLsAwidxslNPtXKkZw9CvJxUkjG86euai0nw8+uMXyd+lP/U
s2z1wo+zuBJGK2VYnkVtyj2CUtB77tK2YQVU5a5CUo2OFgFVWTi1PlLpY1xrn7TMWW4hLSDPlhuK
Ow7u8E9sMr7ll2+Meb1YNivikjIZYcQligB/lo6oClFoxAzK752i7vgyPuLDXfbPdphp84cxexDF
8gt0Wae8Osfbo8Hx70ldettDPmkP9ZqJdmpuPgIpMH8qxBfaZhKMim1JEo6oaybKgimhYUYrFr6a
0yO2KXItbMYsAfMrQlcNHX4HBGBPzN2JWHQICoVBXITVh6n3pkXPKRUlftXHee1AM/w3RPMu4EUR
/LtzCiLOPYcbm8j2IEpoPL71XYAJ+peGLFCmPpeNXuE3Ra442bpYPTL6oL4p/NTQenOtIdJZK+nx
hloMZMrpBo3YUvW7LqaWaB63exba+Ln5POteYymnoN4QF+DSmRBdiuq+ptAfltL/LWdFzFDomoZv
jljfQTkmXXRvy2G4l0PttBcu0IXohaiZkxEtRjVX9AbnwPP/JFpQWAdCbFrL4aEU7bytDQo6gaX4
UYRfZRRs7MV/NYg6Cst/TyhCafZ2McDNYaNEo4L0StwhrGWtwb3VszhYnRUElzvOP+UYTWWm5E26
3+dCIPz/vR5BcxRXBrplkJiT+67AZ6AjV804jk5D9GwQuV5N3FPXRNcYmwK+zYPvgiq7NREN99HV
nd1eSNJEm8Ep3EX0oaUdGnyJgwr1eyjL85wgpQbHLKrhAlyOwZD8mSm3delyTK5axoaY4JKeuy3V
HuYrrjDgX+d9+AEKp5wHHlRAveogPXgfSj/Y24vx92/PaG+2scOKbpaplOvAmNOVOO4nZ2GE1qUU
ycvFxJxb0di8fnAQIxTEwC00pFctrY12h6KJmSQ/jgXLY5MMNNnPrD4qwCZh+iVlMP1GjQYOeMle
moxyb20UOOTpkknlPLU4a/TvMAl8f/ddAhbfRa2APT038YQTt64zijZjtB5V54ppFKHZZDCoXVpB
P4YBN/L9GJRjyW0zhFDTBlZEoMIFjyN/o3qdO91/3nD7RSj/p6+0Y547lGI/kCbbdI5P1yMor7SB
IEQPAoa3r+pVYT4iTjjXKEtdzyuHv23m3lUt+Izlo33Av6gqGO6hMTmg/4S6ETcS61B6QAYmxWcx
Xz6akxmqLpFB4frBbcaKFx0zRMzu2yNQ8zl9kGENNtRm5TEr6gf5Bi/qCNfjj5D2z9B7S3roCcme
6ZyRu32dYhLtm1CxZ56Q+6CO/xsAylfbcKL+FekuAzXFtrS/OQ491gBviqvNAtj3s0HTXOlsUNwA
nTOFHTH4dTXsZKggCA++g1c5/Art3eMk5neVQEnFva1sU54iUvKuX6yXtg6C4ehCVS+0ss6Ly38B
vj471yNhn3JenbUFpbkscVyepsuc0TAYNgzLO6tSCZYU8Uortr75T0H7HLXiMpqtXdBi7lqI3eFU
QD7pu0jjywpKHk1tfxqVTW/cG6dhLwkxVOaCoRsOFQ8lpSPzrawmjOZTPwvXl5j/1gj/lllaunAz
HltgmY8t3nd4ssYAbqrhFz5mKy+coBxNl+qEpPgMyOg4efe22BN+VEDYSbpXkX3/tWD8YQpT+qUh
CGPlCQYfJK0+fuTvUAptTRaTCAXIWeuBhI/nEDeLsFmYa7oiePq0/ES74RAnlib5Cf9+GPMQ18UP
XjODnwvOvgIwPvkQc8jK/ABsSHuznUaP8Lsj/yYlH88Jc9RMLNRTukNzddwlR/8M0hAaPYPkiZ/5
hooxpa+3VxmplTPvi5TWTJ3AlorlaywHVWN0ovtDfTzYXQooH/799cA61MLHEf/fbswaolllR27U
0ihORABoNgTaQB0OOnlsM0r//qJDAuQ/PgMHIqy6syMt/+Eg4TcZQspwfbPG+CAJRWz4eW+V25RN
u6wk7ImOLBZbJdUZDf4LNFtmQa6m0F/IqhNtk/ImaoQZx2XqUiwCG47GlR3jLHwbElJ7bTsUuWRi
udnrULTcH95EOFBX1snlACHpqrI0NgFumNERH8hZ52o+OfnWZgHSUYxphqzL1ojK9AcQLk1ugxeu
bPXUJOhDv8Ht9dWUNNgE6elfAfJ0Sa0lqwXijqUih2gC3jRW3E/oMpiG3737srCcciCpP6LhhbZ+
HcoXL/1ftF57gPm6u5hfcs4bY0qdlCS/h+iC7rpjaWjGJr83ZaINkIeO3q5meb/pMd3JjnCqtpl5
Ow+86w/b9w7AZi5k7+LoguKT27WMge35LJPoJeDdn3fBoebS6OfAAT9SV4opjbL0/lv1zpUpk6bm
8wBySAF/2W/T0LoSWti+dmYuJTI8WiU/vB/VZnRzrbP4lGshaFj7BJK08uE+YUyEudj9ogxmfwIo
E4agA2aCZ+QcmSLwTYm/390l68kz9nYSxhtMX8SMEYir8gYZGw3ktra91aruL89hHjs09jDqDDN8
fnn2t9YAYX13VUi+/OxjSFPWlg3h2Qe=