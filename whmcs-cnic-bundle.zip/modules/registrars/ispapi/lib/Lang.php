<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvsGNZ1tCQC73btB4yRS1hnNqr+KPPD1zfQuuUVaEdMPlcrcWpAMfW+sovG1x9MVGIZ9YfNW
RJiJ1iYmu+EAsOw55B6EgXVZRHtAiuwBlQPlE+9tzIePS4OOehk7Mfu/ad+EzEgSgQJKCeGPvQsr
3y0xqn3sJMQ74MSXgQps0bMJUxasC/y2iJC8oAF516HsOaTG1Ep3ptWBf8mKaygFCP79/d691esK
ihzbwLq8zvRi4v+6TekZf/SxPusOaTp5diYgm2YPmMiNznedaAq95AXecIvh8XzOGYU1Fk1rszU6
3KS87ziSQ1JLb9OG3K2VtQEfh2vDACTYyQW3AYFwviKj1dQ8mIjgDxxA3d/C2GbcFQm2y5A7fTuo
7Mnv4n3MsRkLp/S4z6JbHn2Ip1OXEtMI9rRy8E+xo33cMPBaNsbmL1lYgmjQ0aw4OI56xfJTWGyz
reIjiTEwhThWyCETLTky6MaDk6egmXZsm09rZXBvEulN2GyKl2HgKKy0kkzF8vhDd4w9/Wbal6kC
I1v83UAgsbY0qoWpl0N45lXUeqhy2NRUnrIjw6B1vMiYsrEMpMztazZ2Rvzy8r+TD5q4BrGI+/RV
91tz1/PnFPiS+/lSxXVsO0Fz8nlJ2k/INowVQ8ALbHx5rCqIfd1mtJKuWxtvJ207cG2P26doyg/B
2XwubOd1YzuZWG3zDwXivm3DRd1iTRkERm7r9bjLI6dw32KNUNLR0EkLgql6k3uBypcOAbZixfR0
C5sEKHyQ8G/HUepL/aLgMOqUvLo2XxWCbzMOaLQwOqy5c/qdhphIMg4aX8XWWRHZSiEpNIpBUG9R
x2rKsNV6ugMsqVJxDqCmdsvNSq5tinFiwKT9eqG8IXtH9QJSZMLowZ5GuuCb1kUnJ1tQMqfSwjqC
D6y3ZWWGvRP7Gk/pO3weGrQYCHJfQ19KWjIOZgsvB9bloY3gk7Oli9cHlVEHpxUU+I8BHf2hJnhD
boApX2rzlar6Ra8bhKBsJVyjeUoQlr7mtAcKS+3bBi9kFaQQVgiNUAHcSALHM4ztWWYpycKTIOI5
vYGvaXmUekQmCWF/QwTi6RfuLxGu1Rd7fd8SstTh2oQfl9T1V67bg+W2H5NBsgzKPPYJ2OAyH7fq
v7VAwzJUCSOhIQNEFJddGtcrYOnmQMTKPMcXlC4j8hBD+Kq984hQYj8z6a1c/IBINmF06tN3IQCU
2/XmlN6FoWJSLcXjA81wVfKRf/JuXd7R4wBRReuX9CvLmJV8W0l5LrP21johk2aA+RE6BR5pPHxn
zQoXI9+Kc/FnJEnf0Yn1ZCVIOl59a9SXfzf6TiL9qZPZtC9aEQ11oojYASLSk60NGKy5mI6jUzYD
qNRcD46lQr01ysBjlHTTlLNIGeVr+I02/pjxq8f0AyraIpZFOUhFJynIpzvwyfpNhCaADZgZwNdj
XZD0+Q1zeImY6PkJ9bFvvcBHAsqv5BBzea14ks/YAwnUTjt62DrzRvg0EY1iIwS3m3Pd+yv9AoBE
SKgx/tCB/roEB5OSXoZL5KbXgNG/r+6XEsXSq8QfdmOjVx7voarKuBL3Z2TE6613qykyUIOicunv
0hYSqqH6bnu7G0ETgENt54HUufuxIal1tNf7sG4Bj6eB0kyp6HPX7AON3dIH+00BnM6xm8apJRyL
Nus0XpNUjQB0YX6IA0eoITgHs1SarH71qYBJ0OaUd4sloAdJkQDSf5GLY4+g5xHjsJIRvzrhL5Pt
brq2474dpyKQpSwIxn5Mq2wp2vw2pY6Hv4205Hd2eyMjJD+Bcw0cymwsxlGG0wKMo6iV5LlusiPB
aNHHx/FFQOWxnvXNcUHq/toflgFuzSEvRVdTT/tfU9cR/OgJbvKI6KiohgWaVILvhHVPvpwP62NK
LfYAnj+0boe8lFhhn80NaS3s2+VOWcC4msFQtqXKED2KL+SXMAipIcgoPtEPUow3ehhKAKWawu7O
5pSVVSmd1dbNHKnMnJi4euTTbEuod/0NLpT3oYrWbpTgjicr7iqTA6J+9piAMcrSI1E+ac3fuhmr
0l/Cyp4bBp9MhtxAA0uJbNfRKB9dfUz6haPm01Fm+L/WWF3eo5YPLGNTA8SlGnnGFWwd7GpbGx8o
a0m0Z2pdKjsyEM2D8gvh3muKBVLEeDbOT4fXyB2BEdu2T/wqkMROxIm5N5OvRwZeHhzy3QoVBDPV
7JWYtVXjGK3RSnJIj+hfHu8MLpX+4rxxMcV7pFWkEKowmAcEyPRBItAPPURcZ79pf3ioQWn86T4o
cyOcMxnxpjX5dHLSgXi3e02fJOcaVY8BTDsz2+PIg6YwJpcL8wwOWhYJtQ8fu38BtkleFf4OPYLb
M7BhbdAkwo2Bmnn5m1vM6jRxtvEQm2i9hUQffTC//mMj9oxAY9gNNR0zmTqgshya1c7jMW9QGqkJ
5/SUhG9+cAyXv2waOyvch5xpjdZUanqmdNNriBf6NLOJoQCfkq9x3NjdjKiGr518Q6TMx4Fg5NJ/
tJ8nyOzuGAEwY6dKOv/tMgiYfq+JDkIfxxIxb0PFwq5YOUHXErYlbaK4Y1cmzWcbNaA/FsO+ZDfQ
/kGsy6s0OPvLEPaEq0eJK0mgbPnVpVZVeTYusTdA0pU6iYKUNQjb8EIC3iX+PTat9xo36Bsvt+Q6
8e8ajhzCmqCMmLLgo66ovwGDzEX4U8fL3AlTIDyo8Wjdlfsuu3d6TJ7GqmlAHnTw/nZweEMbBr+Y
ULQ5BIWsJ7TxAeG5O0KUGLtt6vVl3WQsVFBovfK84G1PTtyF+nwPGTr/zUjg/CM1gssw+fo74Q1L
ccbvHHDoi2V44s87xbd27uVpRkJisT4mySX7f4s8kcICvrJ3w7JlWMT5pOztm9KrdjNYSbM2cgA8
LRoNN53C8pMTTXHn2mgCbUZ4S2L1EgE+lUPo