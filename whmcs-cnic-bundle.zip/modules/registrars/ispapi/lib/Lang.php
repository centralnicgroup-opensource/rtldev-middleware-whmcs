<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyBFyLMSdygQMG9aTfQbmOFM3Icic+JMWh+uFb2NeZK1QWd4UYAyyKDVnUptCLT6HWjcwUYO
OR9Lq7FmKGyCZQBq8rZ4QFLNt6jYrXwIgTEyRjemteZ7ga1PwLRPbi4r1YY6XzoxG3IS7rpKd4UC
jdl02nIf48+hZdxZuyY4DIYNsu6+GfTIkQWeYVqb/aDVPU/DX3V6l7OlFu8jXHCNhnYsN4pPxt/y
kz7QvrzsLqo1BBxUktT6SuW4yQvK4g1b2byqEPx11iLtV7WoGwx5smpwtNni+LRYlKL3vnA4OSyd
naSuhw93SJWhV9Baox0BFeXmaURjvzFGWCRu+VB7vr83C7kvg3ZqrjeUqPFzxq+RPPk5LnIkbENa
/veSP02I3fm6VDWZDds/lGU15gp/BT7KGqa9U+Wueqfq8rSuXM9OttgzLidbrvbiNva5FZxhRa0/
BPPLTfg9Tn8ACcpjvjCUL+fB0e94lCTzBHxnEF6x0zeSO1JEuKbXq8azy1oFO5TTSu8J8/s7dwBv
WjEHI+kj2+cOQqfFhFtqmmY3ViNtMoo97jI80fJr/+5gi1ZcWO/HkcWNGCPbpYRCI3tu2ZPl/8Dt
Q4uQISAEr5I5l7kSSVbm5Vu/7Z5LctOuLVWBUY/r/f8J12C8YM4nPmJ9wvo3tKxsMZcZbGPDQw10
ObPft9Y9DwHY0XnzcVZWzKukLj5WczHwDeFx7xjG71RUiAAQKSOcRX+GGiVI3EU0txsNE/bo9dR4
khZI8v4itzzWblyEkNRvwk+DIu1YmUf5MivDQf+RYxsb2LITGzRJo/zcmcEfsd0Kn+L0U9vhCtAT
Z68kVQlcGE9J+/oNaF52IN05GADwIwPtByiAPRCpZHdJlLQ4aMeZXEEMriaSMRtYZua49sDh0BTz
8Wt932KD2VmoW8RcdDms+SxH+iCgHEjL8GNbgF1ZBEjRWXHDyW2tPblBjGqmNPT4SrK0pil1aTO2
MgPgX9xUJpUUTv1vjCQU2h0zLCtXj/OdQWzthHXD5KPCS95LwxZlXAfi4HtRwxm+1oc52G5ozbbt
3BZK+yAbNTD+5DqZqpsLm8bZl8ucWh/eJpC7AukhJ6lSTGZxJCZRCf0dXLZQZ1ZmgtZoJvAzvgOb
6QZSZvxKQh+ktDOw5NdIlEpI3Uwu30ZeC44YnUZm62LxPw8VW2gpzXENva5k+AbJkgGDaydSlWG4
gCLilZMIraW5QQu6PKSH9NAwqot4Ko4zjltHcg1fHEZV9Xk3thyx/+9dFcFnAVqZXQ8NcNWY1xEs
3xTsryPil370FUN/zqtkCdLzMRfqXWsNttcSSz5+Rm6BTKzKg4EHYSiO/z7zs3gqrsaLHITiNWS+
zCS6Mh+USg6qUQubOzW1xU7WUbwSN0Efw10Kf9jqrn+JEvN8SnD1tSEr79U51YQi3Mv8UvOkUtBZ
KEwFzGTKmz07yPAagQbTSMvjSIydHEN8vEODKr53cRZab1HLJ0pg9hTuOEojG1c78up/DdDJOgNV
JlFUCf2BZnY7ykMWqJTTH6rH1/AphJDIGY5TxulKPxLU/hJInXQzaCk+xzZMmHEl3uUYjx3/cK5E
mcEEckpmifu0xHsRZgzfrCSWXFj9ljtDiTQO7umJIMxikxBpKK1Mps+cpdOFecm+lyjW8FLHp7PK
zjcu0jm06n+brla2MdSuKJ3HWtmjUhe09Im8u6RMarDvkMU5WSWHQ23yMvAGNe+et1tsLAZAaoLz
hwhgZ5nm7AIWTqK4RRoN1ZCAnXrKQdSRPSHqm9CeVxiqNfpSvfgZzeaCseK8E7Nmo5nFWKmL03Z9
zvBXfINNcESEo/jHFHqrTJSIZyDkRF8F/j+7zKrEBomSy6jJoikQHErUrTQVWTHhCkDk4hJUfq70
dw2h6SByni9QG5xMtDVkaiLgrO6E7zDVwyXjULJ4eHRJvsqkqRX/eokRsvop+1LEX9JJ2hnf9Q+A
TdWpaJ2McZF/GNOVj45+EGEr62CQ4j6XY/2MPQHPax1fsCyQDHz6B0J6NwaTG0Ue2l+EePDiUAt7
cHjIfH28iloJGbPj8fQzRJgqbs2I4mNbNWZeQohkwYp7Tv/z+uKZdpQ2PdmTKDt2GxBxHK28s70s
WqAulRTvmud/pTR8V0JWk3gb6bnYJRtVz2gmu6WXB+7w9hoSIrtpBn8juJu4bbY1JDBBcYE16EC8
3Ne5htNDF+bxfc9M5a201XBpHn0VfixfTwtzea9WDunpaxV1JgJWYifG67blosx2KNXQdZgG/wCV
WXqwcuWZ5O51xiUX4Qa52+R9QBdy7IGg138T//HBHpARLvm6UeW8h6SJE+dztojLKMeCwbQJ9Lbp
lKXtnqjVQMUGs7Y2Os053mcGMbCU9T9zI4yZ5RHZF/2kNJWTztq0TjJTe4Gv8tVjsiBpNXk1Wm5O
iTgUjoFD0FlRNjwi4MJzxiVrk26sV3VGLMfheeuJElhSWHqTIAHHEfdMsY2thLidvxy/xIRg4U/+
mbJoDdyUx4684BH0z0SHMjhOWBGeikN8JwYSIX6NdO2WkA+npV+Ztd2thunbRUsSxl4cFHe/2P5M
mh3h7j6U8Y9lEp6Mm4C5DLQuMh8Bg/qre1Rxv9crjBJJcGpZFJFMHbg5zIpnu4PnIXSQ/+l73Ii0
wpIeKsBtya1kZPKSnXYNnGP1TTnt71OFtMPuIB4cQFxV3yuTSvMg18CdRWkS9YX1WkgB9VL4Ytc0
qxfVx9+CK7f1EZR8urt4AB7vcdzjASTdiCwYhvFAAN2BAmnnx5zLJMw744KmnyGFwUyZ5MrGuR1D
OO2x0PhlYhRq0wHNR+kFI55wb4C3Ev75/LCPZP0+OK7GRQxnzOc222x+4LSGynsjT9EnCEQKryUF
yfAF/X4cW/d5sBHofMQhXjMQyW==