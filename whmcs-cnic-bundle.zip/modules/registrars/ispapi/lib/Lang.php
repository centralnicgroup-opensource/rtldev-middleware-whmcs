<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzfl9AMq/tcSYa6YiOP8Bdw5jkiJe4QYbhAuvSppoSAvK0GOlfCiLsrctyw7ezUXrUrXqFMO
hH0kSrB+xb+Hnb5zV9RtjMzHghcAw9eshABUagt2MMde2Am0qGtrbcA39ZOeDU8QI9kvxnjhMVZ6
9NqtwAwS7YGqyMIyQTpQmm4m2j2Ihii77UpaLag0+uzQzZa3Gw79u4EOQMijwX6jDcF3kM4R3fUm
uaLey++4PFdmCraQUKiIfsqSXUPxtP3gg2W6IdtbqdmqCchhCinmfHNvkaDl0IhL3D45mF13K0Tn
fIWJ/tB/F/x5SldPNHpInz2PUTAaoCMfk+QIK/+Z9axPRW7/X+Yer9nBwcxkmQ9JSFskhEGhXpcx
1H67CCthfNkUxXvipNOIZkyUi79PhvfZKcZAqCSDVoJLMQ4p6YFWTMja1lSgb7PzHJ72x6+lZ+zw
WGguUXWgVWmwggPTs9DLIXqckBbdd0Vm8daZAioG7lQLQn46U8i5K0hC/kkSrnBDJ1+rrkyKOTzk
T16/+/DFBnV4nMQbkIRVZq0ESvjpOS/X/tFyn2zPJI+ttEtMhDmEbT1biegrRWY6sju2IxeQ4lsU
vjpnmYak0JUSPLnJ1dhymtEo9acNV+Gky6iT0jlByJl/2gDGaYQ1pxM1YtZxFljLRtaQXkn4N5X5
HaZdUNjKNk9g0miCflQNdR3+vexgkOmh34vbBsHFrilO8dKDm0sH50J+0CnNWqCtnPAEi0wKwHrn
/uLqRvOvujalff3CAAhzCG0oBSknpLM6m6ttkyjZQcVP9E/G/wkw9opIv3T9Po9mdIOidqbjGFij
dK8mlL3f8lxBYbpnhVZMt5tudthzRby25nD6Hn3zoWJCG3W2iYjJMtPrkerZ6gUWhtWe9X5BkKof
kX1MM3s1xwWRaIWIWpVIXM4LBWtDRmh9qQCc5RXSNfSvsyhMMS3DPrl9cEIh+XwBtDTl9qWf9VzW
AWoPH/+S1tth5V4Mad+Eq11bcvHJQNBo5iUk9RRH1Lt84YwnMm75cqEJpe02jRxbtAxFPUdMfQUv
3+ryPvo0z757QLsOBS6JtAu1M4BoDXe6OyEUIJ5UL36uYsQUeIGlV3+U+8jv9tzKeFcgGMnc2aiU
GItD6j+r1tSRXE4Kr8Kxt/QsbRDEX9OW40lbR6Wqlw1/cWYGz+/R79DnWjjtm7gZMRBnM/H58Ddc
bXCV9yNHFHhzJb0UmelQhQFzhdaelILcP/MGmTLN2OriiguwgloXy0cjUe0PqU1s6AkhRzp6qtN8
MqW7J09vwNBz30zagHXHu65zvrtyzF3h2+l+PZu6oAHR//KGGBpbXOOfZ+w7GDgO18+HVA8AywO/
H13U7sZgPblXqg0j+PK/GCY4DFsVjAE/wWlcM8hBKn8lBZHJaTxQBBOOJyZ/HyMhpdG3CS857PCA
kaUvQ8g1rXpJM8NvMm/HikIdfGCRo7rtucTFHlfV1CxCOCW11bwvAuQqMvddVg7k61GM8T0vo4WG
txt+/PWHQcGU2nG/pdRW0iuAC5z/Sha8AE3M59sAxwC+4r9male8lXWm3wtE8YWIeL4tApZOJijX
+gnry/llvD9/Oy4E57hF6TpePy4XZ9Y5CmvCsd9H14pmfpNoV1gzWU8GVw9IwPzNOSAGFsufdRjn
GAY+lJaGCmWkIcXv8LTnladdLHH2yfdZL+u/E8tLwRnhBsBubVbSBsuKs20qrFQ8NX4DunjUa7Ak
q4qz4+UMA5NgAaQP+2nR7G37t2OCnY8c06TLerOwlJwv7aLTI1X7ZhuNS9QEkb8r24TJLyrSd8Ez
LEG2wfQZRVSPgqrHxcOrLndp2FXJINnFu4N4157CbXCa7olq4f9H9XahrGHBKVoy7x4SgouJ4yyq
FZ/X4IDXZLdGSp3hsu6Zbvv/24tyzTLDSzTcoNvmsTxAKwKZSR7Tjk/fAlAfdo7W3UiD9C4jJoqb
9HZ0YXQbQVjJofla7+ljScZqJPKvnOdXbZKzaRnwqFtpr95oNJjrrmgTIyGi/BRrix12GywBnP5d
n+qvKUgcjTjdPLvYPGTIyLPXAlryNSXLHu4IkvBf/RvIPLnrirFj6fqeCyEQ3N1M7Gg0ZH5l5ALO
s6MjqcXu9rorHDQMO/9ykchlZfJda4whzkPCzQGPsNWjZMB5tXuKMD0IWlRvvIpMvQ2yZKEC7108
YSvS3BloAb3ACkFh/pApg4/NMCwjWFuJiKrnr2mxopRcu/iAFyZMNS+9qjc9kT0zwfeLMA4Qe6W1
EdamzSxfgaKMj3cjUN7vg12JR+XIIkAJjSKzZU7wnVVa0wHh/H2d/xCrZ1zqclma1cPrAydMOZ5F
FjDNq+L8zPByj1vnGEC/jwuz/OdGI03zrfjq5rc6tfqZuLdsXwaq6acChJJ5U+wkgUFJ3ce6hhS2
7LhdcweMfiNzhRPQk8LcGE3/MRUH1nj/mOw7uME+s0f/cDUmTkwau6HJBj9WjZxrQ86fUqvn9aQV
OojxUti7fetTTI5QLFvfHqmBYunBIdnqVTOx4gIQbx3xxjgrSvDKgJi55IdoClgJwaK/4cuXwFo2
e7JFbYdB01TD82/zv4qb0iicnNaCirRQBWCXrURFvhcxj/lLvviiFJxp3t0o2rN8iXmvdPOPfnUE
QaecXkbj+zvFGgP3h1kv++ncPX93TM0rbSKsTWpUt9ikJQgviFgpOt83+DAh8ajXkB+7C3E5ORic
ZcP0HS0FtaV4cQTGzcC8SoDcbT7LBXP8XxPBqXG/ZnQqlcA50XCheFy3FTIICemzXdRsEXmtWbKV
t9fY3PaUIlY4bMlsWTS7GaaGaf4Gx9Veb/ZUOG/hX8lwU1usdDLdHkMF+2ls75x7DVDknBBs40DU
kPqnI9RiCrkOhWK2Rjsl1j1aQW==