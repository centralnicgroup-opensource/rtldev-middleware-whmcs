<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrEf/HG0FiPRtMHeD+elC+Z6fkEuQlmZ0F1Lnpgy8V6NalUUK8DKUisQCcySLPklY14GdDwT
NzKOmJTrcAhJkeCFNEpUar+aLTSSQVTLfjpjvCCdGn1qK55enK4njMcQpyzBYBGHEdtH1kEhenvf
g9HY4wyA9JYape6oC+vMwVD0f0lz9MtpSYfNCDUKf276Z3+Zu7cSWPA7L87ONJ6ep9stqx3aJhEh
rwjzXMTMH+7ZkO6+hj0Ee0JkT/+O6/JeUNmRNMbX2x9KEJJqeKQBACJ5XthoRNGiRmVrANOZ7TLE
Lxzd2Z2ubCAEUGWg0GMCgUbYlGJjuM/pxq/dJc9PUiqoekcOKACDLpDFOPV2XMitjY21NR6AKoew
ugNi3P2eyupF0EOVni4a6SeJWBSe8LK2v5DrjJgRCSCkSDZ7b6WXT7PuyuPQSYdpfBCxLKLX2PPX
IefyPfD26XuYzVjULL2hMdnMt6IxPl5yrJrFUNLrILj8OY2lWXH9/JhH4/n3U/iATLGL2w4S85vo
quKVCpr0JGvcmmUi/QbrdmoVfvlBkW+/33/Ij4AgoUaYritcC3PYfCdWWh5ZSQ6lpTJvkCRJWGlM
jFMGNMxMEwlAZoS/Qw1PaMPLAtCS4JfqR0fmMUfWX7eAOlZ6CfvPDKHhYPA437TTVvEt4GG1O7GT
lbdjEK7nNiUp55ZPNp5HOiuUj0uYcaddN7e77hAkZn3URBPqcLPloLMXJzb0vGHn5DWIH/sV/xXM
45UM19gJElOUlu0cEMBrH/VPiWwL3sW60p6OaeZpHjkp719nzx1+TLY4Yv9+B/tRBtLOFL7DodUT
UgvYZy6J5xTQvSM5+xNX03qTYf8ICAwZzthcMaJ9l0NBff2ZKlZiI6uMBr6ecG5cH4dqIcl2OkyZ
VVHdzefxsWZFo83m8o/fDNfd1u9TT+dRHEopErqUr+TxquIF9erQICjGL1JbsNHmrsRObwaesvX1
R/m0sKAP2wWH01He56OIm8wNzxH1riV+bJtN+MpX90AGXc8J8o+gCbJ5mtVSsJg20w2BQCAsOtmL
ECzBe5tGHD5uPBEAhF9EaxXqo0hjDFeP+NQ9r8IyKuCJwkTJcJJwSWFgYc8UoI2D8xyxhs/8ApJX
0iV3aJyhb5JUagfKgG4X6q7PXglE7qwcyORkOW0okPU8p/82ESwOP6doC/94N30KqndlZYt/V6uC
PhrAP22CPt23m/1Nc3XANB34luRhse+wivrYiYa3k+HHWalTtJ0m8U5mvnjU1kL73aHereTFKmgC
96XRsVvfVM/InWm2gHtDpdkvtVlDcpuXvYYTfG5onZ4FGwAsKp0b1JQn9Qbdb1teDHRptrlpwOsa
Lb7C1iR0waATntq9JPAObNTJbZ8YRmld2ykOl4hA4khSry/T1e3DtinsrWBUwNG0KxangZkE3dzY
mG5zeNSSR8eJOELLvqjix98NO6bItfMUN4FvMnMa+EtQInYJ/1lTg6qM6icZwLlCK9L8/lIUiJaA
R6Izyi2ZrVLNukBiOK0loHt4rvzHsfBdppVDceSHOqepVBjuc6/fj0yxt7a0SEBs0bAZ2XOTgfDM
OJjFRzmn5ccezXUo/8Es3msIxcpY5mLLkgHwOYq1c0MF+1XI7lmpZS4/Uk5ZsJ58ANu0M/P1byEC
QRAmEGO1guO1D1JRtYZAyCQpUvMJxWhTNqMcaf0VXoXGKMNvSTjFHxCgBGtrJsFCC6LAAqh2f8kj
C4sjYHZ/pxAl/1xOnntdo6kVH1J+A2bU94oC7ohTjk7tx3swTuHXAXcV1ED/9g9r00nGMVnZ/EI8
MackjQ4x8eKPPzRDdDBoVrUlnQ1gSAgWXbO+tV8wyVlHSbdIBFyh/lYshlHjevint9bqhpwepep9
TQ+mHhKFvKo4Vy1suFGh3hwacAAqPIFPvSLMSre/Gk9oc0C7JhoilVfqrOHgTGTNuDSTagGV+9sg
QNR4G2OoSDwHG1D8ELjAREbgvb7mk0pB7LImQExWz5n9i7gAwAfcaBlxgl1dFO8Av2xjVP27rgtb
b1MIkAH/RH0JgjwnzKGcDAasV0/Jv7L4ZKCfxg7IJn7Znp2Ft+mOMSoK1AurphKOmf8KOo52lp/8
lhbLs1Nk2hscBzDbi5BtBhTqX/7wPxWNr07YPd/FzFOfU7GcqNIWKVhCRIxq8qtCu9lPlSdYWlpU
vqoOHguFgUoGlmusEMV5kKIrVbYGWQVT1j1U8U71BgPSd91EfQUqNy2b06h2Z5h189dzC/uBryyN
5+2voli0/JDj32EarBTn7WlB5E+39HKKPvZgLoky2DC2hfKiIo7v/+XORjk8Zv95zbssjKUdZI7V
t/ReKy8+EnqA+7ERRf9pAaGaouxDt0SDZeUdRDxKvPmdbhozyoia/pjuDk8uiH7nS5XJzDmGHbpj
t341by7yBb+HxUWQ3+KBLoM98iUyePgv3WQ/iQkR9xYB6Q+8n/q44w81t8riJpxwcLOB0VTAQemk
KAh4LStVyrHOOakAjIS0Jrlr4+s3+8Y5+6T+Jwke3uDFFmAkSlccapvAcXVCBpy+toXOILKCUHsH
3TJJhWBFmPUD89sq+29O4Bzi8ipuI4CJW0ZF41dFtqCY0vdIVPiTusLPGRbzMb1uL2idRhOA6JjB
VgzyfG3b7iXQ6O66u+ShYhya/pbInGfO6cELMQp2RzqqUsbePOlHUOnAscCee6kioPmY//FLqw+9
5y8xtg6oK8UGjGj/+5UdCL0mTkXlMTiwslaZ6VmiKz/mAh+9HcaRMt1BujsZplWjKYpWpLMTzs4f
JCnJpnbYPJiZJxo/CkOMW+/Os6bpZpRDQ+bOJRvNh7BlkR5NqNjLkukRagYQdrciRZEsxs5aq+q9
4AoUwxXNswWmf2YH3m5dVCmS0zBi1XJ1dwQSqbtq