<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxtbuYnGUjS3BIXt3zFzwBesCrubcOKIkVc0kKz9Sqz3yp2mV+EdqXbF3R+NI/9PX6WVG7Gw
FHAxC1SLHAi8rhkrfuvhlMC1l7ItcnBOlSpm2uuCDMJQk9P68/mcWhBeIcR9nhhpJF/RnKKfGlln
37lKsnRLnUCP0fcgqOS+MyzBTizdMNFaKrxHyQqZGPZS/+/zRH2kbhYj0dswDtcS/XXi/ooEr5gS
CEjxygmqI4spgCkOLqHZwvshlW5DZ/upIapuPqO8mTjzu9dQ+Ayc/LkAgD/bRWSflDSvxGOk2p7S
rZg86/+lp6IXjPVZVz/AeXEsmCgZIkoMOIu9ktFo3jD2XrkWOa5F65yeEXn2+uS4EuKY735PN+oI
OKjrcMbXH0yAgtaUtULLAV2Xk7/bmfNs8p2SgC/EZaWBO0klxR0m1KfZ5DJTeah6oshCubaC1Dxl
0Kn6ItT0WPfhp8ml8py206OclRrkyHqm1ljNc9weGgCLQCVCQ8gz+g3ceZg0F+Ab8dOup69SM8cw
r71+Y0vOZF53f0fIf/QJPSwGM30e29uM1N7sKQ6cJvsmBifOqdy0CwiHoKamsMR7VT1atelNfesZ
BhfSBwYvMj1pRr39YRj6NiFb8iDfDz0VgUEPbHfLlAPHMpPp+AF0f507nGJ198ixpYeASkUSJRYr
uKd8VOqGt/nzbO6yv9yh84WkXfUUSzlqMleY/a+5ck1NHvj3vEzhfdh0ijVRpFWZNNo3rcnqPRnc
C8qE590cuVdREJsH/7+ZIdaq3it/Dselwb22kCFQ5ACNaNxHfEQ/E3WbVcHsN+l6J3HC1lk/h4x5
BHWWqGcRT8DCZbtNIaromgSW2bn1AcY+GxeezjTxZ/bUwoVb8XNhwnhMEkiHli6wivwCs8uDWg7F
niLDFS79cU7/qG3UmbvuMrdjuQRV7Qn8XRb2YTBKtGl2vbUkbiYP1MKMLlZ2hQ4sa+VWc609X4IH
8lEXfNc1s0X9i3MzHebuUMr9BMD2/FMsrk5dC9NeWWY0jaZhvlkQycYBqCl163QvzO3IRrPEClqQ
pNBmNkznCS9T+EL078sfFykSBYPN4m5HfeY4OO6CPWmYY2GPMo9rVv/djCY4HiTY5LaFLbF9HP5g
umIRCGAA+FtQa27eUzN9kvVWm6Yu41DoFXWnKYTC7B6m0OIynR68/eriaWONKVPDCSssfDJpIjXN
faADuwIMfVjMLbW+dunEFZg5O8ymfOz1ZQi+54hh0TPKgMhdf6Bqp7oYOek105ujj/jiLR9fncPV
ls9yu4XV/8ECQQ5A2zPpuJZp77fZjuMi8+IhdcWfwB+fVK/7dbT/1IFKlBoFIogJ5bcqt5IrLwr9
LplluMP0Li0nUl4ItIe1cDE0ZBqdrbuq9VB0v7pASa6BHJHJtKJW/rAlr19zA4bPgcB6WiJOHGEk
8yhbJOJ+rqsCKnnQv++QVOP7ENa4Zj+k23Sp0gIaI0BDa4UaL3lamQ6evWbh7C7eikwQStuW12tC
wtSpi0kKqHg0dvnyR2ptLoakdZYet1PoOLz+N2curEqP991GSD7Pig6cGNlwYOLefF+k5nxXlJrQ
2q0wO6g9WhaljWKNjbgUXdmJfi2x6BPHHmQ7Q61EP7i5HFZtSAc3SdDZXKbVbWzbAn3vTkRGbcJI
TnTBB0a88tOBlqNhhAUktb0Osz3vZaKUdDJK8nQa+yzsPTB0H8j3RxNdIyDA/G8cQKNt0Sj159VP
CNlbP8Il92sShmbAbIz8CR2veJAWUCvA88Vy4uBLh0zcQFACUSXIwsI9vHhM2esu92OV5lnRW/Yk
UTDy0TjIcGaMn3w3uSDSaPjVzVNgGXeCXIVE39OGX4XlN7OeHkeFoElBPjIZf/HFyj8zZ6+LX8Zk
hey7NDJTtVGd3fuwFc8AT4tkrVT7jP9qy2Fln73/L+tswA4fnFHRnXkqjl9VIlkeM2VSe78R0sF6
1wny1HoKj7wohhIf9REgu3s3cQKmwQRuDgF+TiOGnHmRgCddNDwAiUgomWc1WKSgfbnaip8eX43/
CdrnkWBAytbt+wwlL5ScworNpo3fPDCDMOWII582pjcPUUzIeTAYNYp+eSx0Ab1jevf+rjpzHdET
fULMnv/Qv+J5+haiuH9t/mwvUWbYJEYDaRWHWITapI9Gv3hj1IzURe11aZwm/1vcda+6Sc88J1GF
GaCOp0KG5u0z8roMkWVov6RFWp/ZyGXhXBiAeVlwceZd2CPs+M93jXz507agx4HP/IWrf7BBN3Ow
3RnmbQUzA6OvzKC/6nvu2YPQ3EAJRU/gpEOJhuTbjatKv5VJgrbyvlA3M4X1dpJ6aLeby5QcnkLx
PKknUC7QfSXu4MKnKvkBRqZ66l4+5epzz9FmEB0OXnoM7iwR8bUqHaARp6kl38SN+WO/3fSJJWdR
dZfvMTXH6RxbT52PGamCbN82WNcgPLQKH1+MdyL/X4Zp7gUUSWLNKIsOlWOs5lHI7LxHjlWksWAU
3BY6Zl1pw9CZdkISJdibkNjkrTl1z+kTI4g2TG4R8xqJaCci1qb8UJ4QtpKYaG7jGi79D47t2mUR
90jMtJwQIyIgcuD8M+obnlfJsVsoA7qsiVMupgS7J072afZcC4vbNzPM4QqXKOCJtkG7uF6zH8Qz
9x6oBzjEzU2JZC1SP+5GY0MrU9FsQb5Svk7I5fiAkzeopxh3P09bHZ3oqhgcsYEbXNXDlqnUUUJJ
FUeFNX55c9SqRo9ecKJxZztw/9AEkqxX2hznzTX4t1A2giByRLoYWeUzfbISwO3yW63aOL3MCdf+
8gt+2m+Wp0U1CJ5/MlX9oYku/F22ZEaFDgKTGGGD9InXwxEJ5VDYGKEFlqSZVh85/8oLPam4JbFO
IVtStHVog5SrlNiaLs6kUTdH0uSGPdkfCTIQqW==