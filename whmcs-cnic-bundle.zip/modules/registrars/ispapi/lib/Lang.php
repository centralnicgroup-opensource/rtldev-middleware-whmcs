<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy+rnhHJAZkxAdXJbocUYKSimb2ZtWIt/wAuAGsPQD/p2syd8HQrvVMMNsOYeS3uT8acPqdI
V6ARNtBgCBROJjRx5vXO2VNvN6fJy5WC7Q68zxPytVDJvqjCO07RR/itJChI9A7rwqZbFRrjrBBS
8MfYCrE3Rl42raRh4129XovYPovrEHf0gWr56ysJONgaChnwmCAmK3EzKjpZYmsvnxPBDYj7ihFE
WG/sYHFMSFgBywvo5RuirDd0/IjBfPu9XEnCbhj0sPe7x5Y07bqAcDO6Wn5gvEBZ43xrAZRPXI3C
B6Tn/r5ZIq+YyQao92ZL2KxQ2JMycQeIuieoTHqPrhuPA4xzqHTNUJeqDeYomMsGNunruK1hqVGX
wOYWFL1dCIAH8kmoir9iympyAZcIeGsQ5CxEtZzkZgIsQL7Tetp+7SsGyXIVonJ7FhHi8p7qGAEA
78zSL0Es8+CP7DJvtgK/J/ZmE+5di7Zhdjlry5U833YiOTjCScYat0M5EGKub2i0JCPf+GUjGW8d
JqVpvMgGjN+8+l/e/L5mskFkzldPwSaE5NZxBhcHncDOM76vXW1TDa+PcY2sAiOU3hY7jAyNgmIC
33k1We1KpqqsEDBPVDH8WPMWqbvQ3im52kbeNWzX4Zt/QE9MezER/VMVMrxfZOmGjlH24KHR4x8Q
//Vew42o8oYLzM8/ESGGw2Jyb2oL1sn0fnUbKb2d04wxx2gl3YuM8E3+43c2iXhvbJHF7cFoZebb
hOK2VNY2rAMDE4EZLZ8A5Hbly1T17mGQ0M+dDwT84sur62czJl1JcJMVB1BCleZISi+EXvL4vrB+
UD3W0p2fSMGgTMwIBE8QRpPULXLxuAS2iqHZbezQnjU01yqHPGdy6DHwcou6UnrJmcfMC6hSAf9B
/JTpH1kplkpF6LWf1rhJuApDZJQ7KArIpvde4pZyvdiGQQigO7pCJPE5UCM5ESNORbTwEmRpg2No
BD0eFlzoCiYYoGthtY0Uwrrc6vllWsZKsXjQbnhQmMEHwGP8kwKjko2VS9wCBOAskHCMmF2oqzjR
AZ+lsxIlrQeEj+Iire13E+FaV8yztzQ8TscqNVTG5QfJiVMxm3vhFkwvuOMn/7UTl9/ED4e1+Bge
0ualFx58jkGdJa6csZlUCE5vblZau5lL6fdcpJVIux7Vc7iAg6XsCPVHoiDlW2Fq+yNBh+dGvjs9
RRdNjN9UyyE5dCs57FTUTCN3Pl8iPqcqifX5a9NFWMTMP4UKdAI0TRjxfHq3nYQFoX62ShFz3lZi
hRvdtqvAuyqzA5wBHWKWd2Ve42zXB1bzMkmUnt7oAHq1FkQf3sUP0VN6lU4ltOA7qAiEHjIkZzkf
FSbAchvwjxkUlsROEq0/YJtjq9rUK3gM2/Fc1wSgfhJU9V3Klna4WKDimFchoa6kXRIh5ibz0Hgn
OX4mrNqrRWjJUIEi7qXGS8/twHpSzFryGP6HOYP9k07WnlYXSd8rcfPeNKmMSmbConK8rBypBvuS
1Yk48CihvBdcOjrrhupCif3WjUvGk8Gfr6Yw6Ru3zfznq2Ccu/X8+xuIU4qp+m61EsFYzNwRdLwJ
UIJQ6g/w7qTnjmCumuufMvllsGMFJjwB1kp7/vOsYQ3Yah5x+Us1DHEHOoQ4+3guepStQjG48Pb5
cEjtwv9J8pawO6dWby6T5Fud7FGId8bKy4MMOYAUew6T8SEHN5mkiATcESFEUZ1M54wSLRRW9nsB
EOgIOAvuzCxEIPc6LyItYMEY+lv2fdGrp3vHTzMLP7cQZI36mYgrBtovjcfTBxNlrQPxur8+Bahc
DDd1bcHbu8H/XWYUVy79jYZhbnScMVlA9WAJRbdrLinvuaNWbcXmo1iz0ZKZ0mFncX3DXy14lUOq
nyikx4UYDUu3XTRieuqDcemFf5MH+u6EAkocCmo0kT1ytc1EMuOAxbJw2tB1qaJ5MAyCXMXKjjLD
XmeYUgtSvzlb4RWkBi/rn4iq75lX1XHXLTPlnoA8EPYuYRod1oafEFyuTEW3VZ3PseW3PU1cTrvj
TmZ8PxhFiA5CO7F8cPqXxbLSFyblpuvj2W/JTPwfeTVpBuh/n6kw9pXdoMvnDm5QXaI9Cg7smJyW
Nq1+Gd5MMMBVkWRWL4ry93hTvitWtuBUwbi0L1+67YlT9ztsz7hS+r33qwJLJ7ah3hCHhOun5V9V
IL6d4cBfDRNhWQptB8cZHEriDuj4uQ9DjuTZnoXrU2fOkSIeVqAoVKH0yrzUvKF84FkQwn7Gpw3Q
zDxl3tgZC9uUtpHD8KcY9bqvsuv7gEpD7n0K0xNA1ijEuZuql62yWu1T6mcYqmuPiqj1mUzLWCZ5
W7PBoQwfi6j0Xai8h6E4GAANktvu+NMapKaFJ3XetW/nH2cl3xNc6nN+Kg+ZDi8cb1OZ4fVvZhz1
7/4EEw6DuUPL8+5+qDqkAqYOybYEBl0jFxWFJd8hrZEb+c0jmWAa2mAWy6E86w2pw1v+u6303xV2
SR8NpAASoId0nHV7ZvsDK2XXWxjU/Q6ejhI2ENR8PuqZTnQehRmsFeDmiYI9OG7CCg6bMe/nTGBQ
7Xw+f+eMSFhkhG+I3vs8Z01IDxQXQ5rUGIzuHZ42iTN9ov1cVJv+pkrwcOWDqGj07WyZSiBMv07X
6SN4KbHmkS+Q3sutZV31u1gV8+QjiKFGhclfA9XnYWNkZ1jgLCO1jMQ/6K62E72nAEHebFAFRcJN
ZiN93JXjqzFCwNpi9LLnMEDuQJO0Axr+f0oj41S2JqaF7XSAcGYhfmHeqVEdIvcod9K9m3kD5geM
A4Z3jnXx/Z7VKDV4DmYV08uv72RmRdtbRm+3Ot9p39hHo0dJ/WjNyR6PnC8JiMFfQoGq3DN1cYvw
+xkWzgv6nEyC