<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq5W16eTuVnDsAsHILJ4GvnQPGjjies2dSCMGfDHaQBKMk0hIWl3scC40W1qzEG6/xYXaiYF
gdcjLefX+8W2qvlVxm2QiD6QcfObhI5QMzMJPsRqaLxh2JNgdAiIRITDqo244Qp/ZbBedZuDitbw
4H41S5aznE0kqsHP+JLubdfe1xRxac75JSbZmZwyf3jluZA/rpAWpWpQKfgsGT8pfwsmdawqkvgm
GpOf+wu97c+3MPFO0sFkC2t5NulsiY1ZZ1jDUrZwRhmuno3jWo8BgGYcapB9PoL6xmunTMki+5nA
qQ8dMKHJ/auSR4NEUy6JJPearAjL1LUvjSKrQKKHNSHyq3J2YSzfjt/nbreRJISgvgF8tWKPHL+K
oG0GLHT7amflgtnvLT5vxvbGT0OiUeViZTQKA6EpWWn9CKoyxQGNX7QlmqcEmke6Ar+jDvjU4V09
pVKxi6ibQlW+QYSR0z6QLF0xaAcP021pOIwoU0vL5Cg9rxzfcV9RYZ7K13Iwchu076IlKTCUwQg+
Bcz/7ofZyjnTvR1sEp3A5ciFabud5Fmb9IpUgLaBxaipjzzjKWGXCfC9f9AXsCytT2u2i3Uwh8V8
PkeVM4kcwbqnSheLGiUGpmzSxe3frsIJzL/1ZN/NQNAkeW8/drT4/so67DQmPxUwgoSNRLMeB/oi
OYDrkXjH3ow78xQuA/FQn5u2dHXmfxy6GWix9Y+brUbp1rMQkt3TjMViF/ZzLZiks/c5ZBbgGUgd
++GsiUAN2ZXdUiU8IWu1KTy/7jYHucG/uS7uDeLkcuiJhV4JDczhj8u03QM/MNWbj/36Qx+4pUTy
TSM8ZBSWFRpwD2X1C0I60vX7dTbzhW5QGaAv/ft5xYuxd1g+TB82e8YhBUWcUA92yH0hITeUFahH
mFLKJVjPr485Cdo5lVa3/sikpykx8QxixWjljd9CwHYRPNyre5QilZwZnTt5R5Ih6w1M7X70j1u0
I4eio0Nybo8Up2d/AsVvRsb663qBHG++zN/F3Jb1AYLa14whY1hKNlt+tVs5tXtoUtOBFxIEXA2s
wsoLx/+HpUfRH3xQJRUhvr46kTIt1yKkC0AoF+tlI++fRzdxPOUlqfB7GKGJDK4UXv8/ZspR8VX6
bIj9VTzGBei4XWZI5SC1ypa+/6Sr7wdQHjfPzaVQ+YIKn6DiI4gO066vccZs/Xt1r6ylOLGx+G7Q
MGj9X8WdD2+d+dkEI+23Fh3unwmQHvtUH41615m4xw+VfqmQ5z1zSOISrfh7zE78eHlAtJQja+Yq
bzJmN4L3FwXSNKhtFc2JTlhzmcKCKhxoUn5GuPVdNXSNYNlcMh9xTIeemhoSEgMI6+hcZSg+CHgt
1x1/zOIESzFtBiyCmO1w0woD4DtAs2jBtdsLcmiOFmg6YwX6PyeNVdWxJ35PRj2naY71iCgHYvX+
S6R7E9u19fktgRm1HGvAaSTvJHW3+iLw6kvunvIeX+SslxmHQCam8MbEnr+YEa4B/xhazkmFVffI
nLxI4CSWPzqTWjtre8S+da72HgHEZAz4sWdumaKa6XdKDzWbcOuFVZyTRGoblhKEId5hRpRWzR6U
pZLACV0+5+pnQ9S4J/JbcQXFb2VofYW0y6gIC5uGeVv0f/u32wb/QzJvT/f2wSOcvyx02NHVok8w
6JGrD0KFKY6j/KZ8dBL+dMt/4Pj3BEh2OYEviiS2gu3esOQ+dVc3aoya2GzKLt8Fetkk+JZ3U6sA
Fjz/6g1dJ8SBWnqdqc/E46RUe51uNFYDEfS3bjyaLTg3lm7ub9baqF+0QYM/ehMh22NnGK8xXH9D
kQUXotTS2hwQbUcTc6dVaniYdNONNBbDpdaCi7nm2k2BwCZYVvGIHuz/+PBTe/4Dn/jDt96rjT2N
+9xdfPKV0XRv05agoq7hFQXrJhXkR7CJaEatv2gUUkNKhFWl9AOGBDRyw8WEj7H69sIokTcsEs/N
BXYarWIrxu27OQFSx8L8Qa8uV9rsH7ueif3UUtEbCdETcduCwoJs1neYqjOeHQygm/Fc7Kl/Lv+z
EzdUTQLU01umrnH14smnJ6zcQLkRv1J7qUXgGyGwrQX16MghMZ4zRa+Rba23Rh8o79ILr85FIenJ
atKVjuVlVfNSfjlg106gwRefzasMyloJA/HYlxfkCLGOYGBbfun9wBPL2aK+1kpDVBqqY7kOtEEW
p0HjV0BIzEYY5aieGmlBnzc4nEk90PpI0OLSv/z46iH2slGeNVXO3l6aj/y1B8m2S2Q3s6bUj8yT
/2GnMh6lCS2YTByDHRNEewTqpsOxl8HbazNogvhxHi4ai6s/xxk4H1TEvP7SHw0L25KftD5KjjBg
7rUArA4J0fw0KwFu4/BBgY/IiYUsoJqTSpxzcvJ5cOGLzl+SxVJyohRwyvTGe2DuOxTLryAgE8Rg
zYbo77XibLkVLVA0NvCv4Ka6frfdpDNHMhC6G9vi5fF4LS1QUg1A3hQgnDYyuMtgIxb/e3akuzTi
sLMlL9fkX0+iw1omEQ4rm0GNcV3XU2BrXGQNI7xyVkhTxw0KHYhNMhyEf5fFN2F4cAW2HltgiGIg
BhI46WHzXheRZ9rJ/IoRq+BNaAjOrHj4Dda7pxgBFp3TChhjZK2S2XNnPexDuOSwwD4VSrLrB8Cx
gPt3T0rcbC99MY2mHOJuMXX2RRR8wEW1gQghwyHrfpAvOfyFUN5yBeCLHbaeb4PL0BKEYcjm/Bae
1smSCbdVNmE8yWns+2x8So7yJ0nQGmnkRI67DRQ3RFeXxKBDnixZXSnffZ5wC/grd7eWUHs8ezP5
snDPv3LLsF7V5lRq2GzG0mMwzWOlOsuE2yomaFWSlpkawUP4g1fB6vR7iqWexFR4+A7iUae7QRV0
zLI0lUeMZnre8UBlux6MhgF1oHs7