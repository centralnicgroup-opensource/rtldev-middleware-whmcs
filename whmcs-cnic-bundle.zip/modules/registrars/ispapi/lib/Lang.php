<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrZbgCauUX7knIWzwWnlcGAGJX1Qku6TpD6Y1xGXlH9XLimiWzL2jQSzOIGZ+YUNjghuWq9A
1Zts4b9bh50fXNImKSZc+MaSxIPbkAI61Ego65VdbcLpMZUZOx50gCIeOpwy3Xqk4v3ga+mjaguJ
gAQ1qAcjMcGjfgaCg3/qV7US4bqEepGnyFEVXdN4vVrnB7AGY++nsM0TcSZWGHFiDw9WQORv8lFq
VIASZK8x42jH2yFtK+2rN1+b1fIUjnNzEMaD59Yxr2XaI9Aw0nHvreN5YHD4PdbQnqQY1uWGrtPE
uiQ7BOMJ++vO+A+qVt5vRLDieY0NpEg5VJ5kGbrNGUHlCuKxlwulWAt9JgxbVGSKjshRbe896f8F
28Z5mHA5QdnRo4M31kS/XNSlrJxXGHUxqQLg0N3h8HqG4kPGcdp83sA2NO+MWTTEpWibhiUd1agv
xoBU54TrKR2dN0J2diuf3HiXNNI5hagRZOOZURHKpATetg/T9PQFxZP172tEmNoyQOApj3ic+OzM
8HZ/pyzwqBGuzWHcqOVu43uQ59A8FrOANksp96vZA3MrLmV/LD2rRZJGGWasEHLwlffc8jz2oilp
1loI8ib+MlPa0XBQVlIsFTYsdBDxAU7qlJ5tZrc1llBLeuPa/yW3m7M4Odv5LQ2nAvC+1ozzdb1G
XslSDfoValoV3NTd6XEAPoGFwG5AunkH9SXZxpqfUUVNQox9UISeP8bGclqrM9/3VD0qYIEbbTk3
EY1EDWitJTzEJUX3WgpReo+QwuPBA7rCIFYhCOWezM0mSTmo8QHZPUuh7yVCX82XQp0sqRUIJiSf
KRwz8to1RIFeOiXF6WxvIbX58CTCLEwcUyi8YDkEbyD9VPRD35epG1vZDCGogP9xIlmdKv91EiwB
Z4btMU/rzkYj7C0M0hy2htZieiTIGOAjyNvcBewRWGfOP+s+A8yxz9excYXHlEj5Db6cxaVkiy60
PH52nijuXaAornzA4anChEAdSDR3tPTZBUFYsKh4g4xW453BcBTFFwUGOhiSVm5Ow/0cKlExFYqd
hAD+TBASLjdl2tcotTAxIVdd8BfwD8SaIm2RbKH2nLHlG9TPdWx+klXfspE3MFU3W7C2vijV43vC
+snfBSOiBRR9MiCxAv1V30/lcGwXZ/R+Jl4F+JtAgT0a6MxzlhGQaSVhHxzD2a415PVfeVgz4vO5
vgapAP17LyGkJaQEa0qr3eBBGqpINxYc3rTYepN8dBcq61Y9vE6gcxnzhJcvUktnHcsS92qIzuQr
K/naQxUy7ScqMfl/TjWRD4RlGmSsHVY3Kg2fgE0v13jUJT84i89dJlzssE/+HKPYXdTa/3yl1ewX
RXWOA74DJpzTPw75QhF8NFX11ljd04bPJm0ekrbUifNiyJMJbBglRIa3Xubke5eHrOPC5J9We5vF
Qd+qYtXiSmv++6cMm+sUhMIr4GCcOeq3g+H5CzJEibTEPreHi7L8W6kRobdiy7CSIlWm1SLdG8KN
Px3iZnTTX9Pt2Qjdwt6ZFePBnljD+zn5G8J1U2rGuZwRZ9Kc5eus0Q9GBCAVDA/x5R6e1bNY5Bt4
DLwJiJRGgEyS8siU2OnwaqBBOzaeOgcJfVBAsFjemIZEXAdyTbC/XZ8Wjqg4bVRLlDD5W0JQZq7w
SZ1gqWm128aYyRjZZPlDdQ4N9UCtxq63U/Rfs0j6Hr/Fuk/MHwh1qAeWkq+BfYGtmUfMdxoJgwQA
UZL1GywjAEYohiP6TUh2HsN2tyYeaZatQ5tPfqcYmj12l29DnLI3OWmKFwZHH+QSmMKX497ng7M0
wvkN+LknyC7WK/RsPzZxT3VxmjyQ6fvDBPo/GDTnbQt7RS7mZFtJFeFmR74lQ5/imXf4VKXqsHjH
DyI1J2RbI+BuJdwpVcaDhj9lESIrW9q+f5A4H0JJXLWgZlrUm2gCGuxbdofS+uu30DUXYSgFRxrZ
YMHxc19BVc0Qz1yJBwHPlhLr5npIaBVS6rp65B1/cjN8Hiye44k/sG373LV/FWfPzt8QUv+8lErP
W8AJ2JXeozcbuWB2KfhVaBLGnanWB6fmC4QEyYdzSxYNRnvMErsotY3CL9VnwPizwk+jxkVKIOkw
yL2Q0KSDbEBTQyJgIjB5SfljrimFHAg3I3UxYwyEXAVM5FHTHEfcH3qK1zPc+XpZiRw9SbEMFk2q
WKsVcY4qg8pkxYI0uobMQEswpCEyg33foAbaUw/NWKaBbaB7vb0ZGn+aN6VB6HtV3tcn1wbu0Fw2
BVQKgL5yRtSxtHRudwSCwr2pOCLeXEoQ2VC7qRQxgIG1KeNKkWb8RFpdSk2lKOpWiHEkPFKzBQfP
81idBYsSwhcEtejQCsj42aDgIxrqTuPDIA0qW11cNjfOYin0qfQxmWPaRSUknxE0BMkgMh6Rid01
lBNwjU0rMwrdMbhtCviIb0n+H8qUbdWhgdcqYeLXiERSqW8nKIkSDP2DWVPunR3iCO2pkD6TDEM/
SkVSV9kOUdBkEGjasIMaoeGrutbXRCMFadq0d7zWc5qK1jGRT/CZfgAxSitczWoZ+zEJKliPsXXb
C6sD92nfyq+WsV+aNBwi3/bImxkURkqLrtyTfCckmg3t/213pfZDfN5MspRzu8jstnZOYhDHXMlG
MiyKXzFDOHfIlazog30YZjb8qK9a/XpXVG+STvH3MCf+t7E/WKzK2dM9RPp2yK+kGrSRBaamCS4d
yQznJhvuam8/57SNw8kvEcvvfKIxCTD3CpzdD2PvqTcGTjbKXz+0X3sRCWPHM1cJxgcZxGHb+g+O
1fJ4pW0N8L9aw/IY5dkwjZ3WRkL2idWoj+PBGshawmKXwMD0X8kdi7XZxmPThVcbgYuI4XBC54Gl
9amr3Cosg2tZkju9eW/AyYi=