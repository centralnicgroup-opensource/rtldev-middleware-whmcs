<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtTx1RWMwFs/xxQGco7Z6XHNVcEA++h1tB+u8hnknVBTRQlHEpGAZ/uADV//Xe45X5KqFdF4
O6K/NXPC4vudfh6WkHtnCgGVyyeTuQlXq2gfn/pLWK6Mh8Ujc40zzSF4aGVxpm5nRlb+zKQPlsHJ
ooqDTumOI/R9iihw12kCAXGEO/CuDEdZmRf6+xuuhdDsqMqlkM2wEOPm9GgSQjHBnCtnqxp3ax1H
fhjvoTAKIUkSxgO2ZbgWzdrL+VFobU1PNMx44LZ16OUBPrHyK4fycPXPj/HmAsqrJn2Fi6SFYJlj
WMXPLy3QOOxegaWNlNIDvIyq3hyLTzBx3Xnyl4MZUcQl3v4bSQ+Yyq+xONUtJoWIs3EDtKYrZWmJ
uVKArdZ4pggzXMqwcTiHQ6XbQe6Oo9cImbd0L33OzFXknPczJQTc5y59mO7e6fGXc6ZTveVatW3R
3MlFqEdoGFJxlaMKHV1zD+9ROEircU20/n8+exNVn9uqqFuTf96yGpZfIp5490C8Z1SS3oiexBbc
XKBj49lnEavvc78o/U6ye34MY4MDy0AFLXXpazLVjRUlGSj1azIcuGamjwTz/46i8anHYevW53h6
Fa2ZNuRZxDF5ll29KuBBeFHXDe6T2mKP5SEi4yny+BMp/ofHAHWLTLmg5G1i8o3blfCrckAHKMuS
QyauH1q4Xlya0myLDu35KEGtvx8+8JVmBHOtQGDI+3fMJATi5u9ixfLq3FTeDvu7LPvInEtbuCqS
mS1mYcKRPAUSQAZnCaX++5L7MsSoT4/eWamnKRBFqAWRlVlhKEAoNrvqakk0YW0o9RZFI6kBNTVq
GCWehK6V3EUFXb+f+tz+iubHmwfKM/i9k4uK6oSOVZD/M52qU9KD+orh8RyKdBHSw1ER22X8WDk6
lMor7T6ZfJBbzj4bncEA/pddXaOK2FoZf1AIabNC12SMzx+lJuQZEO5h/bDJfAdyZ1UCEAtdupyr
hoUYi51SyEskg9b49+bgxdoozcnK3A3wuZ0lpPLYIg0hYsZgG8D7+SP909ux8vE1pDhAfIShpFqp
Y9HY3XBVWv6f0q9F09jbzu0f8qj8vcO4WzVK0lWg7LzxQiUntAS8bf1/eKbIw4ILEaLaG/uD+XOe
ILXh3vemg+e7nc3h3cwVsx3vBvjkGCII77j0UYAqtgi2S5F4W48Z6sXJHlRLK7Q3Er7wzBbm1qAK
HVzKWeUxvJCG058BTB5zJHqkP/n6pGAGrrtLzJ5EE2SNqnn3JeyGjQ5Cr1YB02vH/MT0kMVhmuNQ
GxJyLrrQawFIsN/SJNoDx94Q/8V90XKcy7OMl+WbyVF7PhDHrrH20pAPdbzy0ePMd256331LuU8e
T9OCSs9OKeOY7+zbNueP4BpiS8Q/D4cV+rakbD7+16gJTLh7c6Myidzx5YHOHdUJVfH+PdjL0qmV
loaw5n99HERqeqsq9CCagwBv+tBX924Mj+vTPcy5A0YJkzQJY9ReidmP91XmQ/Ka4xlWM6omSrpA
VOGcKFaAX0I4ob/RBeJ3EhNbL6dQnM2n0wz83XXhHJWf07gISLOGoekmnQfU2qqLGobXKG3vpq3k
2IV2YwmRzpDvjWae25uBdARZnVq2Hfs7/Kka/sypzozVfP8rNOqhpG4FrFFwopTozWBDkSvnU/3x
NTI94MEU8H/W/w1iPfLBgIv30pW0bmhL79XMGbQYq7euDkGcxh/1JA1A3SdlUs+X3hcE90ML9WYW
N2fT8xNUNUpfU6v7SLdjyhgzWOCtR/hZ6Dck9jN0tReUw/lnLQYoFVIvb+EISuRndYgbq9N7Czw7
kWMjeASKvTA2Kb6+oilQ5nvaumld0XpBsxOXv4al844bGnWoOmOQVuXycZT+zw1NP/iMQFFPSPVm
qRy/rFvLGysxRMG+2U+0uJu2HByM4cNmsleuK9shEbWCiu9iAYHyClAi1yYCYmQ5OOppwBEHYJFw
wv5falVQRINqYa1mAVMX7R5k+srGRu4MLJTHRyfRySL7piHKdLTmsSet79l//ePOT0jVBvKMEVy5
VFpPOhEo14w3M+QcNBtv7zYSiZRq3WyRtWWH3/lYG2Zo5f3KmnjCkm0gsoia3cyXYn6RUqTtDr2C
MqjJ89gaAgyFx23wWkIB+vtJsQyYaf8a6+U/q/iSAJI2UxU+GYFoGSsoiCGqskKMXZzPdy8/iAEP
QtVK+6BToiaKAsidOw3w3iaFPNEy207OdE2Ai4pli0hcy8RncoKpt3kQWJJ7xpxqbQv1vsBXyb8o
5ReD8ACUG91T2epKNzbEle00MiIUB0CF5CWR9r9I89sT21WSWh2jJJqmq1aSN8xUhLYIj/hJtToH
Yff9xz0q8XGNEfOzti8XubA9ldgqfDfOBeXI/vRI2Z1vqBvlbaCTBmpg/4xEYFAoEzGXc+4gucjC
yyCU7EMXvjC0Vh0FlAY2dBn1Ic5Tu10+oQ7ryAgvBA7MJ+IC7GKrfrl1AUryR/5uRFDwoWx23C5A
sG2ms+T3tX3UoHhrqbuEgQfy1vJ3RjjE3UF0vzJ4+1lhQ5uszVodI8RkFq/iGRDIPeghBe+CkWnv
XOMDgtQ/01cENKGR81N5A9BdZDNY4nop8v3YV7CYM0SFcFCq+KEFlLvMzvtRr2eY6om59/OPxMEC
0aNi2Eje/QImMswEx1+Lf2lxGXceu5fvxH8F0UYHYapo5hy5Ky4VJN4KRkXdPyzsyDmKYmlvdHE1
zJeae8m6Z28hL5lo+1ul8MqraarkVkNXqglDQlBxpUEBWqeRRIH++gLK7ChLqXXsvdBKS5X/EUTX
t47HOONEinKOk3BLQH4FuHRfj3L6/W+a6pOg3lLIhSxouHS99zpSGRvH6sro1+E+/kh+KewXHFO3
XovCf/1Jk+AE7r7NEoDQl9A+Bo8=