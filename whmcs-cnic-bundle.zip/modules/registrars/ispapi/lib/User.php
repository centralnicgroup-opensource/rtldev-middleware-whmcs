<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyVRrPcEYoxULnP0ke9RvTcRHxBdAFNYc/qcJJusKjQuEoNXhQRAEVWCZSch5ctcL/PRl2SY
ahwWthyhkMO8I/37S0Og4dfpDxOu7od1Dcg4URQgvC0rOiDQKDBGQIp0WrV5QB+S5FnI01ULTSfc
2g4DFg/7RVAj+QPRseZIaFJ6WvWco9SgOtBJ/IWTXFkXiMUxvDFmvUBCtAd/1dfLEdqxBYlPwT8a
b79T9igEiehg+tAX81tqr4wYAsKL6VlaeSpa74qvdi46nNTyU393hiNR3FhTD761ppcKDHJyBpYo
pzVzPYqID+XmaoHNwMSuOCK2ObUbwLOZZVXbxD59AIBTbMr8sAVSDmiX/W6kS5nBHtyswcKCZKsj
Nd1RKUtrhQ5gBDG42E7OizKCuDptQHUGoBP+c3SWS7+ZXw8EvwYWTHGjYunleDZVJFzJQXZdfPDi
O8kKR9K1supZsKaFdnMPbrDWr+MzB4GQ3VxnZea4ewtyoFjvydB2R//6ulPkdObibmwXyMJSZNl8
OnDfjYjF+o2EQVjNVxaf2NdIy6yPxoC5bY5fKDKdFxoIySBTSGX95au04q62/h+vFb64sWcIYv0l
aM575wze84e66z+Xq08PJ8b/1rZBh/BpHnFhbo58C8eHJcdW2PTGwpDQ9nKK12aKlVQEjP6wQ+UV
TjbFuBmX8iFtbbpkSCuGze2Giia1IpQdNymzk15Nk2CYjjMbsMTqk6+CoUtMOH159xYOcCUC5/sx
JoHnNrCqDl3UqtiZklZLKc96ccYburFi7XuErqjxoO1d15gw1yZmKa8coswC7EunisX/zyrYdETC
lZOQnB+du6wNq+JNXUR5x2anYL4APwK3Z4/J2GOLJQgEQV8Qw4V+xwbPDsCRVQDSEvnARPCiXNQl
Eg1RbDyERP7p44Hpl2HI0tkBGYIP1JG2VDsb31ephV8h7W7TFowmUKEG4vl16Bxbg+z/xkbeA8o6
xILihgTcNbMmCqz+Lcgcv5zY9FwCjjFPM0SBWY2TWZudGcuqoLbG/B6s9RuFnUtSJTg9GiaG9Ep3
+/dtXcae2s+nscW9wj3jX3gB7jTitLrqbe20k4303aLdGGksLtu4mBNydYyZg13E4qrxC9J23e5t
g7K1rND8l+pgOGEG0BQOPENH5iaea7YFQU85YdVfrL+v+qT7/qqz16o2RPcpL30ORHFXZdwd9LoL
YihtT+PRB+BGu7TSp9SxU5TCVTLzNx/rGFSmZQOV8H8lpLD87vJFiBtP2c+Y0aP6tspOAuUc6GIt
A7O6pyTz/wvljMNXAdVznAxXDYDkjNV9oSEmC+jzrtmItJ4ioaMrRvu1063qX+5OhRzApNLh3nD1
P2xOsbNHyA5gcB9CcjoU6moBstg7Gskheil27kI04uQac6GC154RK0bCWEZHubYxnT8T5JGk1aFj
76VSwR7J/TV9JXPR+kcLYTKc724FV9Ex1xV+SrJ79EvaAfDCOJRIwtdFU8eX/lAJN0ZFvIvMH5hX
apclpey4aTK8Usuhn8BaPdFOnn4iJWoY2iSnjpLW7mwqCJftkpOHPaI8u0laRwUJyFx1U2WluhYs
qG4hXty/dhK3O0mNPyaRssmDZX6zRERTasgoXh/xYdzSk1wvNRtMpCeYAyzlLbgSZ/zJ9kiQXUCr
GTyM+O1KEGgEsr2FX9wlt5N45p9eLmWxLh2QxPkPtZrSruXVaO/srwe+rpsn1HnNLjy0l0DOoVWB
XiOXRWwFLZdN1yeu39SiQwqUfVtZ4Tj0bNbQ8oYXBGXieXRo8LKNavSIqjoBw6kAoIeiZDrIVUwn
4+PmH8naLLl0KvjoCb2xhaCWIOVgKcHjwk5T17Z5bR7L5d7y5ZZu84bMOxA22KQ3BqZl3Z/H6mNF
FaNFKTlefM6Ue2gJ36Xd9BpLWt/OkrL+ABXXSOfnN1UHuyTubxF+HoZ9e2DzEd3Q8l2Mat4Fd9n6
zh4TAOjulQPyN10dcEXBufZRMek5VHxcnFQPBI22iEWv8NZkqWr++F5SsaEKg371PokPFJqUssNg
T08DoeUCDcO6m9GzXCRXMEpHvrKIAvfPutvhOR8wAhbsYHzPbPZSbnWUmgJxHxZAgij8o5vKHeES
TIYYmqhqPMnrzY1mEaQB0uSQ+0Enp4qTe/g1d0IHjHieuhNCC+22Roo0Qy++CxCcBjI1zlCLj83S
VkHoC3/LyUUEfTpijJ31ze+vlC2nQPEIWB2gwlQRparGmV7+mYvlujE2G0qQWisIgcpuJ8ezv7Lo
063rt+HU7DNYi1ocowsgnuqMaI69YSu3BDKmeVsgped/vheosvWo5i4bjfeiW9xW4oDkKftvyrxf
G+KsZ3hii2ffUTPAMWfXhh7h58jeEsVc0M25SKvUMndH8lMyYsc33hmUrYrV61PAao+44XLgRD53
Tojgq1alCB7BplfcZw3QhLwL6QKfibvQ+G5bDfFdpU13psbceBr7RFEFRkscgBqvvnj3KAajBNp/
9NEkDJJPKuPft8w0Jg2FONw7fjbElMUOztrlf3LHvJAsOJOzdGqYtQYYlVIwT4VmUCVdsMiaqNOx
/o82rl7f+UuVchclakppvW+fxZARxQUw4RmDLFKiLmjpi5EfT/7hJxABuf1hgS9p5qMibGc19Lrf
vDxfScgWGnIlXLP1qbz6FTy2dWKfIkRgJiN07tlom2FmwX6qarCi4M/U3tKqexWHK1RU8Vgpv9Iz
y2dcFNtCiMdH2j5zhqbx79SSd+I+MjxLC2hune2oMvTGvpkwlfmP3jSbKO9ujC5NoQ6AH125Cnpv
K3TG5lziZw0Bc9VKmy57WPh43NYoVgIiCseU3qbQmVodhBmaKODGgMwfc/NmAF31AyArD7YAbZKz
BfPksRib1fgsAb/xMPa5cfs30mEZ8Vomoz2i7G==