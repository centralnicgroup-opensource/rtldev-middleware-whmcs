<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtVH+Hh2Ti9TcnniEQnbUP0zS+yxbfdS1fUuWra8zofe9miMm/qt860LsKwtKD9KcGvSShUd
/drw8luQ0qXJ5IAFPsm3JP2sd23vMjyB2BlXRtWez4OqbB1m47G0GLD5UyQ0hPiD2Oq6S0mrSbif
I2/a80iEYi3aKCegsYhuMCyxnXN4OYZpmIa2WgR1OqMrqJjev0z0yGDiwUUz+T3TYIa41wec/DlA
A/dohHfCoMspldfbOR9xP2+5YFhcvVuOfw75bhj0sPe7x5Y07bqAcDO6WuLZMOMxUJQkDe/9a21y
LYXI/t61VXjlQJQauD4glCV4Drle5sD5smbQ3fGVLxFNOWIEI9uB35Y+H1durfBLxYX1sHu71feV
3IsK8bmxBNagCv75jM4a25LUyMj43C7GnauCIqVgZsfbyvHRBinFbQQZURW6RV862xO0B3Spts9Z
yl8JuFef9y8KBigLPbjUT0xrClyjbr73pjaSlK8jRyCLC06LbmcY7lbst9L3b/HLvj+nuthsmMYz
c9J2n0WgsrxJy4CmMxV0Gr1/x47DnXqkPuhI3j+nZ7c3Bl/Lxy8iUFejjLFizCb2z0ntr3/72VV8
pJiBzgOwHE7TRN6vvUIaMvi4Q3y0tudHj9C1Jx9VUah/3o0K4/ghvBYiSXoyxJx69BbMx2mAjBSD
Kbw8+3bAYBXN8tBNvbQBMJkWYfoT0OkIBpcaMoRFp5bh1L0G57Icm89c5zrXqneqsFEC4Vqh39TL
jaH/57Pt89rdxTING8cVUW3DephnV9exbTYleb5SmOF4OB5qMOtKwzsOgq9kow5tPuYpmH6H6/sN
mlTEex4AFjpj2eFuNSiNzgTLmEkcCWDpo3cUG2owBmiViUXoNnyIEWGloMMwqZqi4t7aIsFFG7UD
2ALPsHnnThQIAFJIUjU29i6QZytxXFPQZYzhxFLn/ah6G1Taa/Z9qFrHv+uEmS0zjRulwOpcN3XB
85w8KF+1CLKJcIrBH4d5BGywAjuJW1N3GlIuTra3xJEzSo7ox/UUZJ2I+txb7HPpJD9AYB2zz/ps
i630Rcn0e8FMDnvQG5qEEJJqum6qw8LmBPWBvGlJU5clz+Zg8LoQRnnYNotSj4szSHiifpJF+MT+
WUkZlCAkEMDwlJc9+CtFmMSu1IMTS9zl0GRSbj/cGLK7E6YGcSlktS4xQj2zJH4e2z/EBwdgRo/6
P3zfZTvqZBrwSG0BH9XCiuJiSKASutOzHZKnxZUEHwURWI6Y19tYtjCJWian/7+MslhETmIymK+j
Hk0VY8/s74taZriQ03Rzy2tBTTDXBYRgFbIBMSR+z4K1/owDTSHQLUoxtaNGqYiDHbl/4upCD3w+
gwMKipGpX0NnLRWVtetC5uKYVfHeaZPN3ZFJaWwWH0qjWjnt4/UxPkoKWN6G3XKI4fZxDvPwHq6G
C07OoN6X0ptXtDeZqCqLNqxW3oz7cksf9KQONCMNJjEMtlSQbPc0JyGMfyiFdsVQed+fvwFj60sE
Ts0XSXWieBvtXTinQ86u/viLIizbm73jDOfkLqdY5zkyEY4t9lCGfBavCBhq1FfarToYUw9NyTpS
+DUGl1BMSqDYGtgdQSGamejwgm22SKlpZHlPOOrfHDMWdmOz2a9Db3zwNTbO92PnxLeW7ON1piX+
Zdd6IYZ/Nrt8TNziDp8r9nSL0SZlTvujPBNU+G1WbRM7Hl8KU4z9ezhCknbp07GxADTipKfSI2Sz
XR78ybxD3YR3YgWgnPpDJKP4pVWxN4aPjD49z3dWtdsotQFWj8el6giK0uofjnw5pe4kMNsnULio
jSmD4VvfIraEfsw1ONp3uAQypc8vip+3DXxYD7HB2Z6aztGhMFly2qtBX9o8hFl3cKJliWhqc3GC
vMRtXbjEdg9FRbZOE976DlONyrdRZ/lOYaB0+8DWe3Czs/nkH/RhjMJDRxlTaNNvdptDBdldPkxV
rtCnERWQxL+NAr5r2ibMIPmAtCnqcw/erHb1WtddeRSkDF+3MCchaYyBwxdJp+PTCzTKVmx+fktf
Y1QtcT6rNUePm/xn67qW8lTZIMTeFlHEDm8sWC/7CcUNrchbONK5AW8OJ9mJlMaBAiSZNI5FXjJH
92ouyilvl+k9qCRQZUF0ae37H5m/YFnC3IaoVfmrFkX7PbeUtAIV2Q2crqfyS4WzECBDGwBAi7tA
N7CEPZPjGyzCsSwSQVRb0s8l9SQiO4Dz9dPb44WdukT2LP24dPfqdGtXM/XrlWzI0cTAS8OkO02X
3vU36unFCdn7hUzThi8Ww8tUHs1lWDuw4q/S/iKMi5RLdgnlA5VsdZeLwiZ/x+lXgqBhOvInxH3n
lo8+j5m3/ui26De/rYC3gTuu/DzP5TcdaKxwIIQwAWHqBmsFSAwI+4Q+gTkz6hOLw+MUi/VmTvJL
PqPgrwJtwMJ//eqEIXgohZ9quBzGoZ+ShW6GkYxGEoQWMMl4WGPoop7lOwLdH5jvzQsavG113cKs
q7EPZdzXo9OnwD3AhuUItXMdZjcGWgrwtkTd+VsLqwJXTvaD2uMK7kF43u7fMh5cJlugGyfQSkuK
4DCixpRr/nzlXC244dO31zR96e1sK4BHR1o6oMUph6gFs1abISy21xDlq9o+wq8hc3g56452mDD/
gDSXB2DfQDGspnzz43SeSMF8DCi7p/5ph7G8B3WtJCxnI2+20wVScoSg1P4wZrbcAHtIi8gWTl+l
rWquR4CKYvA4Yt5UoyrD6P6QNorx32eKnBzi9psc45cA5zBVV+HDfzR0yAr/YvpdlFZN8O22isrf
NU53Kay4AJHGzaEYj+r+qY1glTYe/v66VwukDM9w/IZFim2g6S1z8YMp4YUrG9StYj3W9AMams9H
