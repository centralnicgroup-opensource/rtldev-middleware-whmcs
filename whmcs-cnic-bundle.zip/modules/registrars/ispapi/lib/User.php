<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw/+wDPGRz4PBJDzzRZqSIqdhUSlwmbsjE0G2k6iqwlUld4S0RQIlOgVF/Gt8NCGBYp18eZI
JrK1RvI5UlgTovwTWUh/T0s+ckB87ugV/t6IBfB3thGwDZ3/QL7GVF9mkPa/aejled1gPnadRkPt
YFDMDFkDcv4wtZ0OMvPEzsbPVsdmjlqtDb5w0+U7ij9h1qLgDGUXnt14RVhbj81IHyi5m7v2Q8jr
5zmeHEYgz7e/B95XfnCFMqRJaDerhZqdpzK/Nl962C7RVU2PslYl9lrRYgZVpMsSyM2wZ0oKO2DC
t7QWva//Gx9n2ur6AWMMMUZjFrZF3bySvu80u9DMXn2MKCCF3BhXz48xDaPBit+/sFQAUAvvCvry
p/LjNr1dSUEKu6Qtlw/nz1zsOI0DFe1wYanSCcTzDKkon4rR7Q6OxVmEAGXww4ciata5AZ83ZqI2
yMYJQoyPStPeU/Sk0HJoVk/sfctlmtd6XGc8uXsSwHMLfe2W7MfsSa6AzQE4QZ1C/Ehei4S/KYb2
A6C7SAHNTyIMzhMlbmO321Wj7d8H5/JpcszCWebekWCdIdAegtjusL5DTT8coHlcfJe5vHADMIOM
JnZpsIyPlKcxUPqztvqd20lVYFpKdHhnX3G4lThoxbyl0FyBhMrDFzNnMYa4fQkTi69WZu7KvB7Y
RjBuqWo7KmdKFVZd8pQ5gyIz0e1xuVkKnOSOeXuz8NJdBbLfLww4IVLSzNqSi8A0JNBdQb0MvA6v
/Cm2I+zO619eKHaG6oKm7cWk7z3TlGS5YlhLB8/79LB2ypFazb4aR5VrfiFWUhRNWedEzv8s0xrw
4gdsKd6neXKv2sM/yrH5r9YPkyP/NgICWW19/Hdd9Dcp9NmIURORaz50F+6vosC5JKKkCMb80Q++
kQpgDbqi/LKmsxP8mjMPZFO+vP7VIpzryCMcEYuXr0fD/BJiKgeP6ZQq+AsyRHEsCvZpvFTKN1yd
pnru4RbC0rIPdun1S1jx8WGpvmOvsDAA+qcfLCsvUg/hHnxDk5RFbQ2Gxrrn7/O7mfDXB7Tzbygd
rTrL0QDYeQAUb5Ym1bogomD5QysgqQScOpMZUSVkhBk2YoM3Gyg02qcdkHfiKxR3J1awBX/jE7X2
VgMrZg+CQTv4TTche29t4eGzYQqLKrFGd4A7kai5/e1ikWZuSnknIUjh80wTZZDjchVPiX2SVfbA
yCs/DRrbBAFaSdtZryAZjRH41Q7kMeiB8LSW7bHbGWjgY/X60b+yv06Z0ubOileTvlWIWCWDIMAk
GHzxAzl7MKT7aDJYCjkvbkLCRAUUKRb+OECzpxMC/2Uclx4LXVNSYcu/cGy1uu+pIEm30vX8OrTo
+ANEYkeBbK2Bg5zbBqht9O3YQRYhcY+YlLUiR+x+BEUwNjHR7ZUFz0WIn7JncvpnJONXemnqHgir
7/Gl/eDp5Bb+3UXNaSCkGZuCkpLguoCEGfqDUN3yO7tczlJw3NIE3dmx+XLtBemBWTpmPeBkAq5h
7v19zXPZEiuR2NeDABCW5mmq1uVjIn0JHy0gbS1AXOvMhAa4iXwMh1ckRlQGmTK9sVyxz7Jr7Vuz
0CqleyOw0nw3tjFxmocEZcVz3dH54ZvCDIDHT0fg7O/8L88iShoCIlRa/nPphMTFO3gENYwcKAry
juZi2n3ZolIWMo6Io6UFa17FedtDNC1SpuEhHKQaOpen/o9oRXLaoYHCo5Y6B1DlH9hFFUtRJ0RA
cYhunKcNAkpH+0WBTDj0KpcPSizugmSzhtFGCVDB8Nfwz9g61+Qfxl8w0ncZLhZbPzKeeT7Ex+Xc
qt+drlVmfNqG7KNhk20RRpRoHSJA4qmwPexXoSevidg3xbWcUquYI4nDEEOjvADxXCe22uv6jv3V
fMYKOZMc5IZHpRw0BLngrwEQdbb5zOVDJ0GBIXb4m2Je0rYm6dJAQIjqz/6SI1i+Br++glND07r5
nJFbE0ootlC9WkJ0FpeisngaqYLAjTrIPvMvUgxRLhGFWp6W0vkQm6XpqY4KdKCrShbpbvaxNcHz
ci5QsX0gtyqPl8Gu7goNLmVuz2401L9kCYYgHLtYiMkfMI4iRyHS4zG4MmKuk+QQNQs8wGywf8el
TTHsYsLJLdWsmpGQWSxWmRjrAXsAdAMiGSS5Gs0bgYjF2YwRZqoWLkqApQB99+8p0foqjwiGeABl
7dJI4sPzatJjuRcsYGvniM+p/Fy4p5HAWhuPZqfCObKqu9U0EEelabZND5ZaY15aZ+eHD9aoFeHy
lFBoE/xh7tqPoquvr4RjTn9/jwqsQA2DhFCL1XCAl3XuyNgAtwHascKA/CyNNQ8UNcx32mOpldVR
hSFo31XYE1merQpeKtAKqy7BHpOXuV+Qt282tb9kcGejlgtG2qzLjGA3j8ygMxNnZTJ7tICdLwfM
VOgIVAr0CIbDE0whxZ3+puIdfo9UHrRjRtDwthQu6KB3VCCP0cNTxeBusWTwoPcT0aWWKbegaLk8
qNZtXsF6Ndp9CuT3XBK8SJYXMI7rdW8LsV2IFMfK9FjIcUtYzyTjTrv6G3Vk7LnmnbjXCjR1Op79
7BktFQSexMx9bmm2W8//lvUl7d7kunD6bcpSSUkMmtvaivQX6b0Jvg6dxDWA2tvJgMr51K/GYIX6
YXH9ExrFkTs48bVJDCk+P/v9g2++iGGfnQ6+Wqy9bd9s7Gc189MN5Ct0XQvcZCUqVZVgDlPXoLQG
HdF8XpzE8WOLKpv5XIM2jLc5WjGjINeoKyoIQ4SLyB3lFiRypNFO3PkBAj8NAWdqK4DTM4kLXlwP
S5NqlhFEQot/9NgvWM3Yy0WF0K7qYKl8Ftmn2K+8WMYLhyRQ91I3NzqBInJiJ1KKxfkXVnEOQCTx
a1EQsNoeEvE4c1m4ShWIYcJckeAm3FaNQQFvhVvI7yJTq8qh0RpAkxOD