<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/F7BncJXvHUQWgwEgSWscDXgVnEE6Iy3Bku9enQI0/jc+W+Sh42Xg25zYRX2sxisCPpIV/q
0sAz3IlONp/TENtbRgiXFrXg1fR99va2uyt2cIV41oCfUa1p6d0k9KMGVzc05OHO9NE5j5767u/k
c4krUClHzDGHpm8LOKZBD9htEc2n3TKV0/MMK0VoWW+LkpGjwEpLbql8T0EMOfeakeir2iU/lnOi
+ihQ9ZFFLGN+0GFfZVlGBb7lCT2yeO9KlkY9m2YPmMiNznedaAq95AXecInbMsfuJdHsEDhfsjVs
H2SM/u82fenWLLxAdpJm1PQrthhbx4wzmt9quk+YcAJoyStT3Pnr4jtlj7xu137Sg2sg1Box96+/
x34axxGlTix5tAG52KfngBQmyb23WBiOjykIxUa84hGZkVeq1jtJsxg2E24EL/C+W+SrPQSE9s9j
tLI80z9g0zHrZaikCS10xEYlnc9vvD3ljpjxBeimSkmhu2ed1d/fwaEq1sPaUTzU5omlHX9EFM3b
mg1QofWHfIi4LlW3QQ7Wo143QBxg58PrEPb1lea9LPvfstxysQ1j4Hfce+saJwhSMGqOPQ3NxXpb
3zmqVcs6B3BA2Z3Db/p/TW7kJhmil3QRt/yCzznEYLg6/Bt9h6MZbKkgTGd+94A+gsuqRCzqw4aM
gA1/H2r6lydTHA6s9NSiSxm15TnGXbK7hyCrpdHkOQL5TJRhSLOFoCQs0CTy3b13i35bNQfjijMX
/PeNaEwP/LZ7boZbjJjpi9rIVXyGbwY5gczuJtW1SEvkWO+tNWN3TUuUIy+MP1fTTov/MrkQXXDG
Z2D1oMEue1GqIb845zV/bxBgzNQs+ggw96zo6uOfMf0qJTlGLi0e5XriSIVOYUl7QVHgN0so2ahc
cscFc6v53OvhV5InVgiW9wDVR22x+92JOoSdQGRcmRNRvBuqyqihh38W6gVUqRtDpVqKNxb8641h
TJ2Yw3/kmdfXOVzyS3Aq95CY7ugYTMvCkkt2hpNmL1uFmt/nq7Qmv7a0rPFWpMjz43wGYzh6myAB
p4megHE9sxW1OwfFAPP1RjBsHAh4nbW4jWQ2PEbSGsD8qF6pgAC+qwbg1sJx51LaS5R9fkeAtpbT
4OoxM74qxozmRpjMTa7MNyDzBgA2rRu7HudN0dqeXl9T2U5Rrx0ieU8ruOT9SGUGyfo3IQArmouN
n/ue+Mn1LQdnUPAzimpxV79TTo0WRD54dPEQw7bxOzuBrXTJfNvzZIgpNG3BtTCvs2MqBmGsLazH
l0zc+jzMBmK7R3kA/unH5dlqp0ACi+ExL3B9NUNAri7FL/putRKA72j0b4ho4fdoU9fLR9PYi9k/
L1IHcHEtiWTaCPUAwcjYn4kMO6Z2pj64VN8oXDxT3SIwVpgiK8vaCsDKnLQpBEhWbZE/AMeay0r1
Mi5ThcqnbDKEgeSJzxV3Jv1VTLOtQ61d3umPd/nE5hQ+OVd5vmt+roobQhu0WSt9Spw+AcQyPcYB
vmD/I470WNeEHAaiy+1RL0eD7t2btQoV0xtBZ5S82CypevlU7ZJNO1epLmFSVOcjeCVE46+JxuyB
V/ZpZKSfQByK1lINsQ7XdTGXaWeoQGvzyoCTpFD9B6PryhNSeGeZl/84hdecDI2+cwL8AIQxZQ0t
idPdWdNdv8vTjTvOmvUytLTlORMVbCp84HOGKrteqWvWQxcUt31LxSnLWivVY+vrBMZ7OEfZf+0T
KTlR9lP0xcxbUdy3UyOYip3E+bUwkc/77XsVys6wnIIezm5SFvHLaJjxQaks+ib1QU18oXqr1WaC
+VwyE70Y7YC4mxobS9/obvOuZmp8fua9toAfUvhB0Vv+PX9WksNYihbCWQg/zfKiatxE8hZNvQic
kjp8mhSHVBYrxTDRqybCzfgacj633XyGiDsC4bqu/0hbRiO93INQwv0MJvAbFcy2N9QfkkjI7dvb
mw9u1dEgkZ2ig6w0WU0RE2/KbY0VGBbYLH5xKBfmkiZ6n2BGGZgPn6KDmHlqsGW5E//Cypun1ryL
Gr4PM2ygxVCJCQ1rv+RxAHoVZJDMcAGbnCvkRiEHxBcYZ/U/9dizBs4T+5jB4IdkKUFcTGth34xD
NSsj27KpKabFtziJPwc4eoZ2nqGCdWQgVQQXDquYKYx/p6AsdspwUi4P1vQG3T6NN+q0cz8lzCqK
lYMONlUjI+L9ST7vbgk7HcadbT+0bGLUfn3e1MIW+tFfKQtDGOWYk/recMjhXHlHKz5C1RUTFuI2
ADDkMFFs20UR/hq+YXB8cvBbyIjrny62YJ3wOHYhrcXVp7WeaPuo2DNUcKD0TeN1vqaNFk66keah
mo1TdimzDeEsQGm6Jlo5JSZF59Pm/ubC7+SsrpA/6NtWHUQdJxJaP0O7nrhzQNFjv5HzDzxR12E6
7mzAeRXJ8sW23jw+WBk2UY5o9HzQpf7oE9TEZIkrDc8j42di0u+QBGm4oqX22mWx2Xk0/W8hOm16
NLonDNazjnlMQCK7HdBFQysZ5bTLmVIHOa+kuZrdDSsiIqIXH9xPTAeODRp/yt7cJRJJhTtUSD6W
HZKxmG0++zfMGB3kR8+Y+V6JhyckNOJgTsqa7P3zOqJpHlU8lzuji+QYoLG/JVMFB8E72QNzFY/v
dwLhygm3+Pljz9z+SwzLg17R9Xcv0Lju3/wY5WrENvRStoyWJz5/z7wTnuBY2B8/J2o8YwO0OMtc
IZLCPIg6ZRDgFMCieKegZK3VC4/fTMpT/pPF7EE78wPZyMgFWBZYRJOQHAGkYSiPlY0xA6q7w6mX
IkHjDMu+K3McH2/eAY2ZKiljGF8cfQ1vtuaHjjT4yoa4+d1BbVK6KyAw+kppttS/tOW5NVMutldx
GPuLnP+jK0P/6rm9nKdYzA/voKA0