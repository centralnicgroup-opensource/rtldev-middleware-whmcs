<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpFX8FSwPfdumoorr9sF2wVur11TlG9qgeguusksIFu+uFT6OCu7A7weCciRntmG7usLgH+S
mcolHcbi/4G9nUjoa3qTs9FfKJqGpRm+KJ30uU4eKOy8c5JhCPJbQ6Rq7wdLWxTbqid9yPCo68gO
DnsxgUvYSJiKowpdJhYrNfnoeq7wytvC5AkTpgn1ZD5zhWeo6Md5sC1R+BRwcKNHPKZVAamrE5ek
SEPolycUJmlXY41jMdu9VVNkaheIaY0zbAVG3dZg08yfAPZoJlL6wQeCcxzhmxuJNwwUhpVlyNPn
t+SQRZdck+9mqdJog5/GlrkcDFJv+jtFlOQKA8Dnvu2uSolsjrRXXFRmSotDbOFzOd0xn7ta+R74
07xahpPVanYlfhXbg/Y/uDaggJ6DQkfQyQB8wULhENP1JgslMlTBqiiK3BboVQ/D2wKI6E6y93zm
cZ4FX+pKvPA6PzAJGv6G+DLAqxqmycDQYG5VyGztkReJEQsgDinbO8va+MchJdLM6rdKe9lp/vOo
R2LEmtJCsswKgmi4iAhRXfX4arNzB6wiKquECUtOJajbHQ3Y1zGBT3NAslQIbPgaukYi2cEhTQXB
h+DtB2wD9nsmvd5UYTLKy9Zxl7lQT2ztp8z760WbgF+tJ03uMnx/WNgsWLkGgY1JrMP6CAa8RAYE
EUTrGzOmE0OP5ieVucTk8vHMrdhEjxDdgBBaBk/qRoubTw/N5UVqdo+WRQpKyTR0qmJ64ZD+iu1/
w4Jw6mgBjEDoN7imnVFQkmYWz+5y/KHOrClPfSHCxBoMkU16NnAxKPXiXdI31UGkfr9ZtECrXGFc
k+QSOQx96atzchcdjSS3tpd3+iPGqXdLvWWNutzv6vFROgZEtxJn7quOSU+P2yPVSWIS54BuwKHu
3u6zuuy7M7zKZjtKb1TWQvlpxghvA2sxhOSqUuqt7MHvflZIsIY5t9GETSisJF/uEA4IrSKpu2Yi
taZ3yZexZzx6BlzBMsAsfn2+7yPomkwlHTPKAcWWYWYr84cRixf/w9ejy3yeimxZrtSFh3hTtwAH
f7HKxT/nWbJ5tAMOyYfcYtUxjiDJPGCT23Ud4huPsazDFR1LKy2UC6dcSfTxqfSo9fd2RX6anIAS
nT9qEiLeu0hal+Lwj1elWc91DA+7in2yYlkemOSNqUxkHpXmsr6TMJrxecRhnEIaTDNEzIpxGmMx
naDzAkljXOzIzKjwyESMWiHvdHcY+2SRBYZDAm/QPCQm43dpG9pi/OyKT2OBfWxzVFfKT3DCwdbe
m1YiHyJcWVgqK/mZ62zR5fplxhc8kepB1grpTu8v/ivzKkxXe7fk/zPwKUU3XZtOQKaxW/d55IZb
m+I44qehJ++EWffRRcfH+zMrrtD4bqHCUWjZn5m9a8DKuqCKnchkbNcXNIklpEFOzkGQ0W7jAq0T
7cJR4kNrWZUd7L9F1gJlqprMyq4BghrLky70eDAACYugEm4PJpDxPqqkErly8ScN0qy3qKnqBASY
2YJyLmTu7A9TZ/GkvBSr82Zplf4gxLaJHJDQyGIwJMK77gl1CjYIkoGcGyt/XYkknwgVon/zVOlN
PvA27TsgfNZd9wQGZ6FVkZwXnO/rPu9Y1JKrhfnlBs6IeFtEkeuNJszsRkwvx/coXyq1YJ74j3Ni
0OewJd8GD6Ojhq7/LVPFgmYLGRh7x4YFe8yGESjEYbnXgYtAMfdftxDIV3WABUgwkUSDao1sUnbe
JJYX7qatMCrQZRr2l+5T4f26cbbmiuNssMXrh4OBTnvk8dW34BTAxY+z/COzUlZtLAxY0RYCZlBg
WjIbg8VDpVK89qiDV7U0P6T9yvbbLvnI4SezEHlyyxqooMn1d0SgGqy743NWlp6qg7sAJnAhC0ig
xGUrr9On6wt5VMgmtsDt6fqaxYKk0bMnRcNbI19+QRHIiZxvGyBseQO5AmXZjGfo4zig4BmWamQZ
meuDQ7WfR37CVqmw+5ZONvt9DFZWKMdrjmRgWDPaSYBO8PPWe4LrDVy4OZPxE37/c/aF+mH/5OeR
zCWV1JW17Q2zijICy2QsoJvzuxsEOL0d5dsRfac39xIBecTWvucCl2Pu5UHdzn3d3GPoSqOcX/NK
RwteksIj2JijoutNb72jFrrfYtWJSWm1rJiEBxNzNBRHOmLwsFysMFt2uNU7ZnE2m5qpKlIdCc4s
vk7lo+ptyjxHDlcgfSMeaswexTh8WZb45NkSR9DtwAGfconqop6kDcodQxVsmfqOD2pwgHem2mq+
xIzmRaRLB7b+6MUW9B24TfQ1aWup8eH3nefn8kIfx9pZRzBcPspXmqkV62WUO+h+k6lnrWzl4r5C
Yo97Mbu23vIAM08usKdpuE/6vLa9R6Sx8fCzz050oEkOjm6gVEKSkznR6SfIzM7U3mLGMSWcPbIL
7+es4kkNdhS9SpdMNhYR1gJ8xvtQDP3V0PTrrEqJLQzpuLzfSDqwx8NWRFCUur0V5J3ntMXDm71z
PufHL91ss+3brf8q8wFEgldNnMFvWPI0HQn4eumbl3qvs+YJKdPnycef6WiLPTQqh7N9qEVacS7e
jWXvd3ilQcakANkusuaPDsUpJL4a3KK6lG1ZtKnrQFFcL1m+AibgFbOac/0fETkDzxKln7RjQnmN
zhsOrbWbuHp16rSnCWmOSQr4PYT9nGdfmkS12hMdqOXO4cmLke8oey/YZMY0zHvAFkbGBh+KPPOt
WChyzMQELf1A14A1fPBaUOgTMmOeewPu16pKTlSgK+a8kmgHqf0VZgHWmURwyWCmiUVZSvMbQje2
QoIeVQZYB3+YsVA3HNUEEzhL92jJLD8Vwys7qngAviambMwh/J4fUKm9pY1WbA3b6fHWdMshV9P0
GpsigDQ0V0==