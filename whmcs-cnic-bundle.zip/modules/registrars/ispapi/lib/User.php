<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpvu0ZhKwVOzeRMN6P1hXqLskUr07PPB/+qR7+CzN6Fb3Fz5Dd7O+jmMyY33Ip5mgAMipctl
iPmU0HoNSf3y/QNawjoHBDAb74NfmXzgFltzmxUo0Bz27d5xUUv8to6e22iVT4HCC0Bfucoio37d
/mCBLconWO+8arUkiiEbFSXpQYlkdUQ5hP3jHrdkj2QeqW0woxRGOcCX7jI76ni+sQP5ESeRpAtx
8liXLzN6QBcH4mGObRBR3whSL8VnlnlsjwyeYHfyttnR8lj43fqn+qAsEbNvQwOtaMXnoC9/T9RD
0PCdLV2cZMPRsKBWFkENmVWGnhnPDsAk7Sg13kf/Ux7Nt3lb/bIXvvKjTYXI0PdRo5Mllgr4uwxR
mJR9vSojcwOvgwZTMWx/StsIdFkNgG0B7rmsGeOGC0O78RkN60Db2JdOAaxkIt6Od7/iQAlOughJ
NRcUvEjE7WSm62z9PH9/hOj55pMfoSBhTceKDaWSOIBsVpOshcSLOYOsjyivzUyN+aK47WMxyX4Y
rjv8qI0xI+LZFUm1UG0k2ZWm3eMKSI/7iiOnzLNWFV98jOhxKCHSek9Dvwkx5blBL99gpo0TyoVP
KsjEQudChXdo+bBjwUUCICML+qOE9G5XSgUUWg5e+96V39Hi/x0v1iDYCycmeMk6aTEJNQ4m0xmQ
O+D6yk2UAJXGbAMJPZ+0thVSsPSgoawiU6cW1LQq9aA9mrmwcShy4cztLbncuTM5B8lU6V+RJZaX
91JXgsh3Rw0YEGucsmsqQgoxTHZyuL+WWkWwFeLCBCR9ntDs4zjmUzj1DkXm+yNnYj+0VfArXCDi
ET4rjUbIy6pYdwLwoslL04PFQoNNIs7+WZadoiLFpXsWehtuHKOtfxizhRlxunh/wsTxfmfrXmC1
ja3pySGrzuqY+PanbJBYTFB1YZee1TXOKk3eaQBUpHn1OWQs0+iApzVYzkqez+rBmqknAgcJA26O
P6KUVkRwLIm4iELqQ8oCUlh9pxHadBPL81LyD8Fe7pEU7bBSEO8EbbAYm12nMdT77WBbRHkp31x9
6B8fPalNZqyalfrLGz3/dLruKMeMo6XPRCHo9B3ry/5OJf2G9r64x1X896QV4ctjUmj1Dgb3SVJW
xsMYj9mDxtp8lZ+/q9KCKHGWOBg7XgQZC9WVsK5jr6+PKxh9+oCGLd4+BT0fZMbHMiuGkKXkN4qa
0DRs5rKc8M3+inG4Xqqjc9xSfy3CdDYvNuTEr9rHurqhztZ9GnYk1nUWBx2B1+qTW6d3aPeeTeLy
WWEUf+ZqqurYGqitDAEO+L3NRanMMMkAgcNkmo/dCu07EJVpucnYVF+/5g2JjUfVDbu9Hf6a+r3C
vbco5k32nHCWUiPL+P40SsmZCfLqY9+MU5G23QP09cNFsKos0ePLMB9N8u7iTE9bYpDNXzA4Wkf6
LGxw0279BafZP/8NNdSvV3s4tN+fEbSWqEuaq657GtQ3AAHrvs3xcvBU9iHF8GbnNayTPWMmmZII
QQV9aeCIdIevELE6Q5G/NDUpwx7Li5o3pxDUERLPsfNInXQnSu3GNgzs0vv/ygYdokc6fz16p9mp
upPZ61/DaMIShU6cmshUhQrtAEAoHwrwMgXaGbjbp5jJGgNlr1ZDkhnGJxOdCpeHw9csjMGn6e/D
X/803XKmV5bQuXiS61x2kTyYwP15ctZa+297bHlLznfO50lqI9o09EQRBUWkHeNfLQ43feh7JVvD
P5BX186BKjx+xyvVU0UG3Rtpm0HHVPosOf2AtIqtnTdO39BR8BhfkCtehFr0R+2tW0ZBsHBaaAF7
IH/nA+JjwwTkUEgxCwDPTk1X3Umv84HR3me6DA3gl+yAQ346y7MgG80T4gwTBLHmiFSrEECvZup2
hjdq0PnPSFUeFqWBRSPJiqYr/y9li9o6iyLT8owsCT1kGHTcT5VNk/AblZYcOc+Fr5iDLB4RE5/1
utezxoJ9im/vthU59NBtouyljnr7eOfE7tf6FZz/NP6RNGNwEvRX9fDer2p/gnQ2yPltWVnGjPgE
th4zbbc5k0x9Vv4hkTWl1ozmmAu6l/nRhv5IWmfaVxxKHHi52P3f2I2XuI9631j+G3/yYhzPCGaz
QSn3csNgrLRm2JLRYNKIf+6oRmiZ6nOejXHi6dg1Crvvv86qqHUZNpJWz35e5e3QPZxfdx6y5Ei7
LFWV3pMxF+GK7mJOPeblHc6JYnJ6fvWxxpuhkQT67WizwS7K5TK+d5usM2l3pnrk9uwwz2xqy5EZ
s/5yMYWf45WP+lejnL6T99jtFJEfxR6FtX+6GEEfYEzbr446KPvmImadlySkEfAvpibsUzc2o9Z+
TWbf2UAl17eoV1z0M1LNS/zOQScb+H+EKDKmcbvEooPtJxAabXIsFXO2x0CdfInQn/N2wsumVitk
CNFPfIe7nB3WlR+EHsdOCfHtLIWkJVOth37mPH4+/a0m4cyujI4vezsUJ5EKSCOFC+ggWDap/Ds3
1d8m2fy2y1lRuunaUDOs/sps7htyaHk/NLrnK8MasC6IkDIF5xm6GpNo43ee8a6UFfCBCncZcTSm
0RgQmh+vaqI4SWLLLUGq40JMB2aTDyO2dsQ9Dcw6R6lFLN/OSLjq3Cyg7xiEC9MB4PjmA/YdVmKH
vDWYPztdeopX7Vj645LnUPZbJdlZSEJpON0z8+nBLGmH4fsPdP6Oi6ZCX0WbXdNb5ECsqdhmsyes
eQ0DocBV6crogFwcMoRKj/4bVe7F1/voQikP9fpwsfZlW2g0TmaZCMHOj1AnA0hBE79uXMyVPNzJ
VrvOyefAAIEJfIJZAjaXLyIiTjqCnR+rEPxk8wbK8pYhYYBVsSrddjXymIgdUVQS1F/rmAjGBHCK
LU+BnMzCmJMvhzsv/xjE