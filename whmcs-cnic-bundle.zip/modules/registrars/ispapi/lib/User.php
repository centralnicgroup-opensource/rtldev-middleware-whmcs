<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwHPOSWh3bhWCfJqw/mvo390WBGUCYosRQQurEyPm9Ep2NkXN2BxJjohBe+IBDAIr/UUfIyK
/I7X2mm0Vw7ZIRMVQ+ahSmn6MFlNuusUu+lKNUs0hCK0Mk0KeyZr6MDwIgqNc5aB/8F+w12jCKv5
wwl8/+oXzks4pmVCwXcY6flNjXhiN8aXUZzxHSOUHowYZkTIpi20Qsln8wO493TCJaBf2BOV44Fi
W5RLVTBwLD6iPPS0z/6X9FKZb6Wbs599/peqQM4BibGvDFIXHeienCM7UW1iYp/yiOJoWQ/Vs4vt
cCWPHS/sZnUi4fXdmMS7lc2HTuaKDoM0mCMCztmavINEkLw3u2bJZf8CB/o9EdtsuWnW8JB0Sasu
rEnW+W9KEtY3cJEfhM8Rs9bdHBcddmKDdNo5KcYala+JSEfc2aQ1MjBy5x60TrysSPkN+PqgAgN2
IhycD2ehsSmfKupzXQrM7zggIk0eFWs3s86aLU9NeeLoyJ7IbT1woe4cTlwfNHElFNRd0SA+hRZ9
/IXblwMsIB70qwB887AsifVYX6oND8/eByTvqWBgnOm/YcfahgLsrl2L7zmTidqtJIf4wU+1uuUi
MDxm4D2FYv7ZCvzuE7NUw0RGBtxyGJ6kwWdxadcd5aGcq05uTrNUXpUfUV6+pypNG8QpytduUHkJ
6dm2KimO+fbFckWon34OBni8j1QBw4xiaWdHeZIsVCdkSggWn5yhpqnBIHCbidM+yCPh/eN0Tmub
WLJLnJtAvqGMSZw+3BM8tuvFGHAqKNjh+FYMq/HjUgJQYFGg8ICoJnJBWN05Jzlt0d8sbN9byeBA
0z4KXFunFJ1W+0HV+DDT7Gsli5QDOo2HSarDmbG2ihFUXgCLxjeTLCvz6rc0ZonhiYPGIQ0mTzjo
EBqeqif0rwxwsY+50t4sEbhWtCBLEaZOwR4RfGJ6bsUOuObMkuxAeIjElTkHbse5U7Wsa3OLeVMX
4fgXOEKfpgZzWhzwONoVzLc9DdLio2Pr6Yqh5fo6kgm3vIKQkvaUy7PL6J777Cf+cRg0bSjyI8ZX
66k6AKa3vHseDY5wVi/8HpFFhDHAdfrB1GZDRCwpaPKchGYTQ7iWqTGbJot/IIF8VO0k+bibAbOx
JYShZlAnpsTZyBO3cdk741WHYXnJ0CwGWOiUWgOJ2o7hiQnNhBJUntUa6xhJH7W9KY4XCmcdZfqa
utpccrkF0wHtMpMnw7tKhylgXGADCqBwXdrk1zbX8DdSgkMrQPCxvkXVwozA3nkX5CD87JOcFN84
QWhRuKnRvMC7le4brPFlya6VY+4noEX5c+yb117QBSfS5uYeRTodFqkGAzXP/wGYfYjuXrN0dZIM
HkSrNwGzozpQOWWBXcaAVYk+nJrm+deathVJLBLf7P9h6PD28l/anJMUr15HfH7l3H3lBorBOmjh
lzlQMOwqqmTdTB8bGtGnMb68l/xcqrWrN5WcAMeAWXaPv34C+RiDd6alUBkyPMy2OfMD8/bYEnP/
aBUSUhFuMkir/8udzFjMjMvd5kd0iL7TlZt3J43QxtR2r6W4BrgFm2hhVwov1n059jMP8JBuiso2
fFwWAzyhm9039P0Ygk1DHTbsDWKFvGUSw0dwWVUOQLa75aCflG41mKQjMp9cezWMFYiS9uHHRjjb
cI6iVquTn0Wdkn9v0RW11qmGgaX/+iZlB4qAVdn35CRfmeo+9+4+lIFd6YRaUT1uh+kPYCdM3bO4
+L+AMnxLUlESoOFjsIkJSwBG1SUwa6KppqHx9TQ7i7FvCZhOppySDX9EcSiCgZcPe1QVJwKlSr0+
FG8sPi3+1SU7f9dvY3J1cK4NqinbagsHqkw1VrF52VNiGt8W4LvU7hHLrYF1xVuGQuEoveVSkxxQ
cQtwsz0q9OYoRBoDJ2yZKHS7CWd7zITOYN808uaapryVVOKghBdB1FI3ofaQXCMHnv/3sRWbb7yF
tRoAce4bQY3+ccpLCXVX3/zLc5hP+n1Dv0Xb5zx9NajkQIU78X8ClB1sAoHdWw0uPs0C5a32wfWE
7ONq3diamvds39JQa9KEJphoXfWw9U6cJo5E0FUBbkA87Yu5UC34TLHSffSvAMgcaC3THZGQExrM
5AKobdPwliyd0m09FjvoFHsj19Z5UeYg9zHO2CBJH4lk5rCoixI13Oln+ImV6hK0ItP2226z18bE
2nCx5STMoLrDir2WMISsrTyCrUfUcPpAOwzWyOJAnzbb7UswZkSbW0QbE+GAAcVoBy+TosVjaJVB
2Dv3B9Rj+2zxXhnejnbU7hHulYdgHY4Zp+j3PnEz2bSJolt4cB3NXDxLWNL4dNjVtc9i4OUr41Ju
Y/M2OflCsfShbaDmflolvU7JogJTR3rABZPdUKSHIwN8jIlG1dmAJIQySjN6JHJmNi/EEI/NnmCg
yfESIIu4pwn/yG6sBVDudBZ0lD8Tw6o6qvX2/rXQJUOZWJ+4tAA4dGS+yhXm0IZqQJUaObUoOO5g
0rrIn7ZfGUQeZ0D5gZxQk4NFWNcxfLdnEBJlV70jbcPgrvU7d265sfHGJYS9RCTtgwoe6Pwkr8+n
4/lJsOCiS5XurgpgSCpqpzeW7WD5XOddbPNTxJkkqSV77N+rYfpG7NfydxuQGNL3p7Itz6WaHot3
gtDLqZ8/ajNsPqa1AB7Xe3GHjiybBCed2gB4PN8BGNOxAKiPactUqpfdIV8vlLOBY58dgOvLt79A
S2w0H/3HASbqyINiRwyCq+ATvEaayxqdG7T9Yon4kOiRa+zLKV7Zbxfyyn2yxWyY+CL8bGIPGWj7
GL2JRhy3gYyKjLrehJ8Jat25MzHXiHw/X2byfp6JvvzYIUU1nvaLx6n2oa4J44bya4dWeNzoi3hy
fSRWuA+s+wPp3N/uviLI1HYdFxkfFG==