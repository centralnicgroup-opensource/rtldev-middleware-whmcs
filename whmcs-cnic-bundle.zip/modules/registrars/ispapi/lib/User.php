<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrSe0EODkVZ9oEMLnH2PY1TaAKtUdhYQBQQusH9jZsq+5zuZcrEO16MndHd+bjebp83Voxh5
aqeYcCT08/+/mKoA0kjtRUNhsRB3oklByJ7kzYUgGQtHeHqRMmmFazCbLOfjmsxPNC8qy4TXGiqw
f9KHfPz8qillZ8IeWg4wyGBWJZTGgzMsfp3EIHA4iSoqbnRJRoRUUiFwhVjaT/++Xl6WdEoyp1t7
fyd6TrMO/j844WCC8lnDu08MLF0Ai63xd9maSjssbBeja4egBIOQXBJ+E8flN3E7khHYKY+9j4AD
IOWs7WF9qAeGI0+d5wKg27haFYOITUiMnWwVDEs6AEGOt9OqRk2zZhzbrkG9y6UilxVmNl6f6k9Y
cOru7WISxXu1KRCKUCEaMJLl6gkhsf2VoKG6KWsvm9sWtqRMM4co+OWK3xKb/UCvqjQ6XsMLngSZ
jmBBWf0ZeBW6X6m3HMZzYhzgtUVG0nnQTHvX8EHbBRxdXeqsDOJVKuLI/jfnFmzwfJy6lYSU9bBz
U3PDEPBftqW1TuUGDCP0kxSFXl3sSLxLxXlg5gh8k8wYrpAbRjSTbm7Wmr7Sp3CFSoqjZ1lE/U4S
q2RhI1QrxaGH/fNHx87z6rZXxtWZPuM/rSodDXc+h3CFJamaVvQIbfLONVYhpaSHVvjSf5YGCYGu
lDRFS2jPs192VTV5Zcr5ZDyaUPalXezFVlEjxjztSv6Hb6B5vdZeKPnbx/58kSjQxHwWM1dVsZ0w
mjW29jG8uqbw70TCS9GS6Zgqi7GLkqT/IdIJU9lkr4aPZd7h7OnDV7J/g2XjhibNvtbKWL+iS2pf
sB84XG74uHqlwUHNNdC2RquXS09mXTYuq9o4DpvWxGPQ5lzSB64ssA7ucOinuygzdJUBKd0enQvP
C5g4Y9NqcJ+XzMhlb2n47RNa4nFGj26LInIQGcem0UvWiCgIyU2TxN6URIG78MCQDwUUUGK66iWW
ecKsBNxQVfupa3rP9F+79m8lGWQQ39GFooFghCzMek/xkJZ34N15+8i1x4xXarZfK9O07Q4T1YyR
Iewu3uKn2W6zTjlCK8LATuteoRlJILPGz5KI9wmrkc1LNk9NxBcjwP22giiavzddc69a8tk3SfeD
EIIrap52DeHp4yLiIV2Am/CAEqms1MVZQMyMy1i8qMjtFdT+e4r886mHMYe+CXpJyG/BYGINs64h
9KaO2VIKYlvDoi9VlxLml0LTeevRrUSOwGQvkwy/WcrN9oam+osBaWc5FWOAKUGTnvR2kOaPSO9P
O8wx1SfVxTOLeQwIHa71V46UNlgHqQ9iBzo4uH1iAzghYB7q+1bnLGWE/xgvVyRyPnYUw8zvAwlD
fnAhTnSsK2JQhRkH4DRhsH9Zy+tF42C4dfsUyMxRgb5bs47qTtiGOXWWs8IztM9lTV3LJzCP1DVV
9fuXI3QpQUSiBuL1ktMufbbASdveaQC65gnvWOgjtqTlKfS2sdscAl5d7oQmy6mvEyeNJ51OTs2N
0wUNUlHDKNNp3umCWdLPoWeDDPX9BFMT1W0JPKQOXbwL0Q7BVJyZcg+dxIZoqqL32uup8domFUQk
RzT6UpDpNPzwaS7L5bB8z54pqwMHd2yT2mHsyO5cD+awPdgZorSTPitg0JM1+YvVU+U7uMM/yhoE
e2avlFLwtQV9hTYB/q//If7tTIVwnlzqACy+z17yyRkbukQ0D8GKsVlw0r5VOTFltGs3aRQRP3Xw
DOPHMvW43ZJxjBWgmdhcDEPef7PaO85g6myV3WG5le8YmYyiAUdisYFkS1GhQjO/Rhv1eLJsQEQV
mBzWCko/HCcRN5i+pO7lYy9Y2XqEO68IwKDQIcAx6DC/MfJ9/j2XwzicFPUx0xtOrV+N19X0O5c0
afmpGwot0KD5rlACn1R2ZeE5t58DssF/U5wbK8X4UBwRHYdHcpEmnFRplonND1QT2ZQtA5YdtXl4
kEcs66JXeS00gDzsvXmEyu52iQiXWF78u22NMdBmPZ7/AMpu1sFAjgtcMFzacyGcdD57t42TD+ZE
mZS+BbL2veRdYFxCWuAOHI9CUdxYxThi44F3B9ITOj/B8GP7JVmHAbHNW7+BaJudnzGiVmV8c9g9
JTVAltVeKT2nDLZf1DEfvTOsKMd8ecv3niNIJHKZ0sa4Tkc7kk09lETGMCBS1XvRHaSUYh0OcgBy
Lc0ov6H25nanksI8fFt2JwD/mNMx1vJMmEO5jUSSM1t3tWSDelGHYRuMHZrph2hIugero6UhzXER
HlpvSmNOI+xHvz1k0bBdtl3SUBVB2GkWy7rX3MPeR/epxthOhNarQwDHD7xindf8AQ8wG+l6xtC4
63fHfVP9qOdMNNnaqous/zHZCpfEpyjgpb8KHgfUA8KchIXLWLpAlScANy6FFMLOOTk3Te+h0NOs
GQ72wl4shAGdR+LnT+OiheY0HWL65sn4fpNuidM/ktUksuXe4oIrKuFyLM5noY/uKfgnko5OZD5e
JRaMSPU+30pmaFB1suDZL0e+H2ntzLZY4+SjYEruwLrC5ZVp/hrXAk98Vy/MXbUxBUSnTfD+sYQY
j3uGKWurn/erRhxaZF1oxET7ZXIlzdpJHnyqoPC1lR3gwilA3uL51nOu60rPf2ljOWAVkP1TJAWw
RthxTPdxtDyHL08k/WdBeLhEPFDTXFu8g0RvE2/NSGTU0bt2gnVNPSdaV2U8YDGkdAvLOi7VGjEL
xYaszm2GzDojkmuLHSGmUZRHl7afhMtxGAkY9U68g/GL6tX3KXIVvAvh+bvrnTX1uXCg/WmhJHb4
mJVnL3TvgaqKUxLOByysBvVOiGc4WsMCZwnZ2CqTwoLhGiFWOuPZ+qclxBsXfYw1tlWqoY2zRM8r
ENohkyFMwgsJyQU/n1uo