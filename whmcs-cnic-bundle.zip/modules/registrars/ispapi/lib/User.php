<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+ZzMhAORR+5PJ3FaM3APg1Vbul69amp/kyA6gSTuDRtaxgOpjO9BfKOoFVcvfqZwIHLCiex
7t0RPVLe7adF9nqOJM82kdtb077yRn+unKUFQyNZX0VFQnU5PfQPtx7T5BX7IrN1NxlmnAwemuBe
/y7ErGgKouPz6u9F7qgFaegR4sJi4eMs99DpZzqxDDNxg2nv2MyIAsgwUCy54SaFN/7y6jvMc028
23HbDQ6ZQzzs/xMPmt2ENByw5jdXBn0t4eECZH8uciRVXwSEvEPZ8/0h+ouhyRxhQviYNlVD2iWb
Sk1F8e78XfL3O/4i5is5/G5zqusOwdO2Hu17LaPRIfIyTFXkafpSSMU7Z2naV2kVnz7QjVVU9rFJ
ih91KrXNzK5qijcC5kIYPwQIWZP26PA9ssNKQNWBqfc2kx/FBBjiT1nKdwDcJJW03gg0SOFTH9fI
1Q9qkscsj5WxD5wEcOdBstG+r3grlMhXjm3wg72F0jEhP3LFmg9IE3BRvmETKmksCWaJOdI27zQh
moXJ1rG1PymGskYHrUx8lrkpxmmJb1y/UvAVthMQONgaWhRQRelI1tCAz/Fp8LxRntV4WYURQfaU
7lRwI27I6vudQpWzRia4ObMZnQHE0liRQDlrOMPm0oYKuYnsmDyx2beN+fKzuraFETlLCuhkCST6
YQRj/lRu8xVJGXLWHqU6TkEk1FCVj5dqu9Q9bGwMYc7LdHNCHXmSDq+CfziLWmBZu5jr+hXVnsN2
833rnyy77eEbisqD6sbjVkEAmtAaL4/tCvgJgMGrObAEDmExq4YU84s7BYcV7T2+RYyE3z0POgH0
vHClx0sb3pgyiNFYbhMmgHwTo5DDQ7BUfXhvrF6Z+dp3GhdMBa8htb8zmjxI/APQycqfjL/Q/o99
Js3veK56yyp7d9WuvimwzCvG3WalNeVnkveY60kQlHJt99ySOrhX1jruB6cgn7k/XP+oWsxVNKr6
wauzCuB4b0jvgUwLIzbOKepP+PG8iQFBKGciSjSmot1vPlstbVeNBPEb1yzHPe2xIqTea6uWEtgZ
a5OrMwiqfUWU22B1HjOgBxYRPCkk67ByBk5+YnH8bXStX1Ocu9THkkYOW0bRlzsk88a3g6FTbCGi
y3IbOxziJ9q0L+S4GAuxj/EoPx6oyj0zc4T/OMdDpbvZUHv5pNnI4QF4hOSal13J8IwchmUDRzJ/
CG4VDjKs9lM7XstMJXyQEa0BDABoz8dFE16t8U2n3lpbpy98RI109Mq7xfX7CJvM5RMQ0m5UWMmv
gcGtmGiVjpfv4DvkwouK+is7jANC3UOAtgSu99RLGC+02+z1S560g8oiFrR2bK2ms3RlJsxNQpY5
8uKJR8KPbhtLzGaujdVDnfUAwuk0dD2neEUtSw2F5ao3/drpHwtznFbHVgGtdqxesiA9JE+GK9Vn
ed+Ko9QZCLfrrODwQREPOU0HG7SwW7/TGfGCUCPJzApfSJHK2ZICbxSVNHfyhP9mQIYtKVBSbJOF
lCY0dAgy1ft21RipRnl3oHtVI4DSkNHEmPZQr0y7Y2M+cWSXuD/7SMD0nNm5nibnTUUoGdMWBox3
FYv+kD3fNiLreGmgl8+EVBt/OcLSgdK0UaOXjF5RbsRfG1CUU9yHpNUEs2SdHaqOr2rBqk3Z4ls7
wtnreGbbIBXL+O3rxaLVKa/a8afsdbERamUzSKrxhnuOE+i5EBXDdj9B3qC4uk0tXdefV2FyzU+j
Y7anXX3cKiA0L3jcvfvgVjTcek7RYxxkeqx41xzirLYtLzJYhIOEnIN4xnV/rPuzqf70Kx6ZMMkp
v3DiZE8ZpVUkK96JsGF8wDnt5vzquhPyHLJqDJuP1gK/erWT5pUNZ+GfNsEpezKpAOaGXl88w6bl
nZvuLL/TI2uarHR/pk2Ihl8vn31T7KZdoGC3PGcA6CSwIeW55xUet+gxzZ4VrnNdipc+9YEiBtan
L+8uAWmurvKp1GAXYsav4f5wotWo3602wnCLyrabU7k4QVgfNW1EUV+LhnqWVmbCozzN1LSHNGNa
6hu46A7WRkj+E/FZRuZ5geswVRpoWn9SHKqNwuIDGURWdkyks44Zomjnf41Vf7WFZYJI9vEVr/VD
79jEfb45EOKj31FJfzy7L8MnJmQfZVcPvCgt1IA98PRkEjerrM5uycYGxB1gUM/DDpQvmhu+Rdkl
64eUGoRfhvdVPIYGXi8AzC56DD1DgKvNMvMyIT7jeePTzcPYJF+2x8v8W7DEQ9AUEbe1llaqJ6O2
FSJ2aAiZcuOEk52Emx9YoGwVntpwzARkPu5s0Ct28qbaAhVN51sEuABKOPQ+6wDeXjrkA2Q52Eps
8pl/663vRK0hNU5oeDcd95vnPumxTjLzy18C4nuIOrIqw0l/QMCsZOU3epkzvwDt//SVA5+T7Mlj
5kfCcGdJSLPBm9/2X0fraJ7jfzRbtWAVRhIlCGGtIiUCUhwiwu2Cn50tBdbWQuEyIE7eA4ZplzT9
FpdR/PGi1v+Fs1+E11uKsigP9hai2+6WmXlR1HXmzAQq/wdOW+FYrNJK0qgckfP1QctWaasw4Bmu
4kTc4V/16eEu/oddDU/uSLkTnFH7mU3AZLXJiy+/tJHjclAGJGA/1+7pgsgKTy1Fn7jkAJD1EFdx
aM7hJvYMx0Vpuu8lP9qK4QutKyZP0LERvlxSIsUP1PZIQIa0JM5AiuAJQEWs0kUxTOVwBcH3PE2Z
BH38i/NoC5AmgWAIKsJFhGUts9jHnws1JdOXIzyo39ddkbzh48KuOsPn9c7Smbj8ZDIu3p64avqo
yaKZ0L2JoE4DYEWMFhsKTeb+yhU8a5XWBMPQJBJ34pawa5LG8YY16+s61JwInvzu7RMd0NRvmLhM
5j5x5IfhqNhKDtzYKdUGppWAOvCKdCWdmhWSrAlto6Yy