<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+f9Eq5l7e1sTeIkOiEJiIooz9L6eoqtwiy+ISrFWYfsMUUG0swD/5kdO0HACNKaFabZkApA
IT1DAXWm79WwKRpIOsN+HIu6tmqKELUcKFSN9HBdua6UlRskUOZqQJla9wfEkN6VlK86rM0/uahY
4dw5tKUBBBmUV+/jdq/+Sm/rg5hJysj8PIq+bHgjhyXokJ3nNVJ7dEOndhpg25wKXvUYJ8Q2KPnE
GZkGLdpHldB37Qx/92+rxU3n0+PfoC/tExqIR5ZwRhmuno3jWo8BgGYcap9qQ2ZlKQIiIfpGkxfA
KN8d9m9uY8SBDiHR7XInkh4cND8qPAcly27rd4S8ugTP64wlbgRCdp9BqaCg9K6K3tiCa/57gDEq
+jDKeyQtrTP3+mp2gl08k+7KhsazYwj/z6AU+XnFOni5B6vP6HNe92FTxN8g5gUwrxitGvFv8O/p
G9o2TEyq2lLPFwwGk2M8/vwd9KiUgGRvhQ/UOXfm3oLwDqDCTETMoYGAeoAP0QtO/wRrAHv0Nt73
59The1QCt5ebh02Xq9NBNuhm9LS8AGmXtspJ939QnkZyLZ1mbireDmh/E22SgXI9Br7560wa9v4i
pqf44u11KT3cNClaQGuefmhqXTlo+WymsnUX9jRaycXrK/vClYax/ngCJljDOys1VP/65gg7BQbi
Et9mgJ2OpQlIKYJRQOzyQNKZngijYRSGNk1DjPFd63igZH7cEinbbqOT2K1tUVXYhyGd7jChSlyI
HrV2HVYSYoQVThPO2EB3UozuJt0j3DPf4/nQIZ1pqsrnNV4QGQ6oUiuVc7P16bM1DunJUw/kclZQ
hlvVtEjIRKc6ntYFYjVgAtrpEsIfCweBGQCGifEsgoRYCQJ+7wZfx9AANGslIUKzV401fe6kfoE1
OPeTrLp1cPBdV0YlcL/KXXf0mbWxoHlNiMp8bGG4r0VKy4AcuLUMC6gkcStBvd/u/sHfbWjPSZqf
Jd8CseAk2bG28WV/7jvlYVWQZ0MMEyLSc8t0lANPaXulNNTSMX4PCyDTmb17okxziechycG9hkjw
U8ZtXJyqVBeihnC/e8jAEx2IydKV76Z1L924OPTdaSQGKBgCTP3EKQSrnYf/IiQM8WhyQm1v3whG
3+gEbBPNylD5BLEREaafVSsqGCM3I5mK6bLk5S6a69g0Cq+CdTb26SOxzB6wEsNm+Btmx/HewTEq
I8hZfy/8WQNBO3D2pASqSC62BF1pV/lMCoajAA86ib3i/14CE7Di+2wBugOesea2JwrrpbFUJNP2
WwerFTbcE9Oh4NEEEVfoHVf25qczmoZrmWgqXYhK/tjmzke5QQPu9H7mw2QIzRR7jxMqnbZnViCf
tOMZE+sHl3H2PRa5qTQH1JvLLPfhPHlW+g9RMBzWIogN790bON0ElzH62o2nlyfrrzGEFMjY2hQ4
q3Du8cVt4+HUgRNvwj9QoKe2gJbBO6Za6WzyMKrh1OlqSJvS19Pb2//kVhxKZk7+ChTyqKDD/9mV
afmbtLJgYQpkfXF+GdubLm18LQjkhbu+TMXQx+meZMp4Qg/Lg/yCuLcxN/Ji6H8OTEgT2h8+p5hT
pbybdoTVv7C8L1AgEEIHutTieNYNYF0WImpvCbEGDtvi2JtMT3wsqNfDdZGFCp6j3XT7H5q7b4Id
wVjrknbHLGdpQL4YSvm2/sIXOXZL6ZGr9JaPzDLkjS+lB8UJyrBnhTPgcdcl/GGSFSJg+nYHxzPE
lGSjBtCJaYwlHAqft7rV7BnH/KFo083QqmYXWG7Km7KoTDQHaoOEBf6PdPuRZZg1zeV1iFi86UjH
OqLgNAdp7AJIBNtq/OZ6ZkuVSproIPblwho4EJxe/cYdnaQJyXzbVV73rNVMl/4YpFp9Iq6VTC3n
10/QLQ31ni+FrA4GjAWPqWqG488V08pSjMwG8h18m9fJ8yXz7K9glD6h+nhcdlqSdCHlLHJ+8S3p
nYKG6mNF8jxFO/hqdl9lGwJNCq0I1YVJXiz6ebc8/1Amz4Ih30oGGAVMe4a1bOccEVqYe5k4SbQm
SxEpLwh+U8V3aYdgr0/nn5Il3XgOuz/MXi2VXhmaFvVjCjnMIRbo2lI1h+G4lnGaMEBbOCiupre+
p975FTNvzkMREMK0x5R8BITjkXnbGokdreQI2ookuf/JPXmqDAtZdxkivmHHJ/C5gs+7o+AKHVYt
ZEWj33U9amK31er+MonUQHqaYKkMp7H/rPchTqsVRHdOB3wNKlFq/U7ISOKt1e9DhXDKmJletECD
OWxZJ43VUUO6qCEwpl4B+JghwaakCEpsB5PFAmoUQ2ll2KXyXvRR8+CKVFhdYvR8tu3JcP2KCg5P
gcVEFJXcwmA7VEO4ktXNfGg+GV+uEBknOCU+T6PkjHwWTAJH3FkHWcRDrZeECm5CxqmIyaKwS+5y
oJj/dvlHWRNnhUebNi+kBFQyIWjaiJCK61PH3HODAVUYCGeSsU7sxEVWfgzhllqvLhDB1qon8DyV
Apwc/R3o7VBbLkX38qh4L1b5eLVWlqxJu7QEJQ7RZxnxP2hSQJ57xRDO1DVm0CqgKY3391ZE1FEX
S/MhowK4C75FlJUmRURRTy/eVtdJwUoZOAz8CCldKom9/6LfgK4lba5EyoV9a3d4ExvcVC2CyRY+
HQ1Uz97QcmJXgEyw9l2EodNmcsCbNI9Sy7C00GF6xuEtJFLhfGE6C9Hh5yMjI7X/T+HzIcNs4Ibv
zOTPNBO4Yh0eh8C4JIgnGKWq/xqvOU0XRSXTbb0gPe4DqV4uqEkY6D0CnkEW1tsJ9Uon2NvRoU5R
FO40UBeGBiJwqI7wwVlyuxHQhDjOEdMbSPNF49uOyuIiG5RWJrn1LRGgMA/jWoj8OrD12bQMdyCN
2WokbDToNuU0seweLCdvP0==