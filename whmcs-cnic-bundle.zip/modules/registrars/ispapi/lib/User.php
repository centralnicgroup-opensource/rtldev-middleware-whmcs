<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+2VsQgOJoADPL9CYT+k4FLH7WJbnEav/RUuuvS2SCSq1u7YX0s+D1irXIsHZbb2k2Dr7ygM
B9tKsEzypIiDxcMJRhYEvi2fzI+1lJ+AV04J3qwYjo7WBNNRb7VtN09wmf1uc0qMU3uEAp/yscCI
XyzARSLmPjGkIVeK+yar3ifm+2EdfFWiqEO/2GJs3ImrxbgZp7I+2AROsRPAKE1pILRFhuvzEnHJ
mXkAy9vEWHt7RH4/Jpe+Tv8tshZ3nlus3lA87gppYEhJ9G9xXWTad9nBMW5dmEKvkIOgQXZBeTWt
vOS590j9ccRkDSComdtFD3IQo/xdzV/iUpU6B38pWzq2k9wnWVscOOMSI5AviTUhQ2cit/a+k5en
aZq3v8sMmA31/mrYtTImgk841vbKiYdXmgxogCbdEgsuYnR2SQtePh4JEgJahoT7Z9vqkQQhv7+2
TJYwHJUmaftW/n5iY00WEzn3b47r7LtczlLeQJUcEBcwbTHD32wjrXTynNFGpaT1whtOSnQKYUnj
Ok+VKGhGV8CoWekXtwChGGfcW5jSIzJ4DjzM+CU1Ey9FvUk8m7kycxzkQ5d/0u0Ew6vGZKxZVRCY
ebS4J/BfBuOtdDB0BR0EPDvTqkqFd1gv3jTI968scFYwrI0g2pjTdb7/wY6H/vcYQr7U9+BilzA5
KQHldb7wllN+qWboSkYkR+Fls6jKCnYhojyIp+jHpHCjCwJWPzHInMpk1tEYP+8pqQuPH8tNgIFD
fQ9pR7kaH3LR7ZXltU1eMz5ptetNm2ND+xcG7vB0DPpqaomLRyBRSj70pKwBLns8+Gl+N/06BBjw
5nEkZMV2Px0G3dvplUDOhaFnNZ9/qA31k6c6R7ADU8vuxtR/5GsFp0dAqtPd+y5XEVLbrdelQDMf
/SFOybNsORgt0HaRY4sBYIc2C8AtwC+t31gOtZHYZXqwkpeLkeF8lYj8pK4hQXKxGWMc1Q2540w0
M2n+xMp5ivq3sE4CTF+wsQ7xbc1s/2qudmL+CykUE/A1ybmtzhz+9Y+JMsQpXyZ62aGaqotrHsnU
dXz67xRQrs7K91UCdxsF757VLYe8YnG3XAYpzAYiIP0dN3L1dvQyh3OkTY3dIo1Lh+pWx7Se8Dcn
lhzJz33wzRpbs/5xBXUkd8vdGZwnPZR9QKSdykVUofQFlS4IUpbMS6bntNCdG6j4w1ANFRkd7Hzv
WUx8miUnJ1nL6+6Tqd8MGv4D7hU0rbBOO9x77dGB3waW+J6S4rraLDN7lHLXpdAmPEKRposVN7qv
/vv9DCRl8u5QXPV4tGLfjdJ0zx1xfI6L5JPYv7BtqD/F7yvC9UlWiZaZ/mwZQVrtuCgIIPlj25Om
74gueg8cWAZQFbff87ZN7jmRNyZbO6vnIKup6cMDHTqr84A9VtrnE6dGB/2m3/paihpsN6SumD2C
p9z8253C/7zsO6jP0znLYqMOR4S9+2Znsk7Gs4v8Zr05pmXgcTiJNRBJZFceC6C2eKOm9nbFT0Al
NAV0vSvNkTzgqmQnXuXACKB1dW3xHTZ7ZLQHlLNMBTtZaCEE9U0TbPPNMItgMHyDkrmm6gJRTYeS
+46HRWIm3ljkVP8EHN1l3HjJT6HrTkgAokY/eeC9LMkeyXVovZ6f2zIypymhAahL44HM0wMqhCrQ
DfRwskGmBDO5oMZT1Gx/hJtfDnhnBoe7p9fjHevbaJhaL6meMRIZfk9NMvmPpXsxNeQf6aJD00l3
CpMdfmBW8c9T0B8ONvdRr3gZ8ntqElu4MZ/c8BbJYTBfjtkspjIVANOECLQ1GfeGxDQOLXaAnVyw
mUTEdx1jG6V0YBQ5240IWf+WbhGjQDZlpzLWMSB5coqouYcHHxAsc95nScZ7IvP3nif30KPFNuB8
vOSQpdYOGhzup7msKDW6xIE1UG6xJSqbVBu4h/B9b3g95xcsaQTMwQWeI+bGMmwGcXJwjnZ1aZww
hAtPvzwlQaSdZqrVRd5cOFfjQPBOxTYvdsFEvfpLldHiA8UmYvSX7/ZfJGzzcpu/eA/jzK/pWejA
xVIDocpB79pFTgVC6agIbA5Oj7bzsABLLSPeWljvLOV5Eife1Bzcrj7qYvF+fMivxBvTJy+4KrMD
h9lF57Qvqu3C+7rsUDYhU99zvGi5zYZGud1AG1jsE19kvbvCiGyAwXjfaQaXHGQ6jgiiJM2wCCtG
3vZ6NF2Q1SX9w5MtjFedDJOS8k+eLPcBZDKUz8SkPLdXLEI22Rsjy9ITxBBqxY1xaYSHUqwTbAaU
CSubq/6COf8V5+JWa4DRGCtGg011+p+L7dfgiGrfidGuahI3hiUCBoOZYIW3aqbeVAkIchzys21d
Iz83fvargQieRmwvKAdQo7Ti6XWJ7XRnEioad5HrE7N2er2BYnCu2/tKaRxfZOZWXn7YSvCKG53W
FuK77U+VsVDbhEP9iHa5b+odQltDP7OKuNqxcNbiNLCxUHyNJPu5Jsrd+zYrRSoshJ7+SLxNm5nz
8pMX21TxVxhaZHrS5YOwdKe/Ysofre2YOYS0XJBTRjkZ9IVrhrKSl24pITO9PjsMl2tl5vysz4Wz
zUzcnr55jfA2Rn4QM3j1MYG5nIISvzbIhjXhkfDSl5gnUD9wAmQHGN8W8Rznj5jznv4/vnG+RBMT
t+WYGE+x+PW4nooR1ncscS2IP6ehbox3dunhecqbe8FNXruIkCtf2f9akCqHyGDt9XOffNnMAhkb
FQ6nCovXanoDHg/bSnLJaypTBY+zzCUeN9s732l9ZM31a78LURJPqAjb/vFqqoNERS9EOvkhHNem
gxdwy33oRgJOumJhdxQw0o30MWE0CmwzeY3FES7DyUC4CrUeL72NGs0Vf+J+kvIo4yWxbc6nIP+z
o3LUPjuOi80zJHVNx1XzQ3OCGlv4oI5/ZxnHTiW2MHt2CvM5fetXL+S=