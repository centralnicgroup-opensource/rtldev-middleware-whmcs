<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoM3J1QeGBLPjKxPDHDofXfHVqvEjsMjGTyOKYrPks1E4BfuFUqqhioTJGa/sHUhdJS8o1fZ
dJCOjmNbCCW3mkMLBLXnqemqUEQEqKv8oPM4Ta0PkegpIhlGKrfUkdb244yZNeOZS5aTYU6ZBwan
dKUABpHCP+PylItO8XkR6e72bYZOS8lE4Zc1xgLFbAExSLmHyj1/I8xAY4YY3Bwp8YP97JkjoxQE
fS2glL/Wr87mX7wZCT6AGxDHzmHelGCe8+q+0MWHMC4PXujdL7nGIdoPc5ct5c7kTQ+F5/k7F54r
E/s+XohNSQfqzn87qYtZ8pA7HupQS/MPogFhx8WZuOmc5t4Hy9jPYqhF0rfwURjuQHgEpcl0pzUB
1yvL08O0uWEIaIc/ugfhu0z/GHRwr1QIigQvd5zg3TzFuN8Q4EyfZN23X1O+p5y1xvJmD9SKqX5Y
Ri7PUCUtu6M+DdTxTKXWxijuW3IRvmzyz9jKJby8ByRZ1Smp0pSplSIs28rNYy4V9EfW1kDCDQ28
no+5s+hRe94IOn+fmYq6iuNbv2mwzUh5cmC0q9glWeWZUSr/TsLLFS0EPg7uRyxmRS6Atd4dt4f3
OweVosARmpFc626M1jPbgBCSmS3Py9rP/d55vwwmf8JdAH+Y1lzm2XsIDHjo7YOujzntL1IHbeEr
5pfrvfD/KkmZM17pUFfzAMs2bJs1Yj5NGeUj1Bp1IC740K3vdPle5ynNkhijEgAITO/7f+OFxm8v
3na0GLbS4t+1XNYFndVr+PD9spQJEq/Y4hSv9Mk8qb+3lnks+fp6qyp3GiHxTsvWH6Rvq4QRZnPu
FYaJYpU7AzIG51FFbb2woTBpkr4cPhNdVtRWvvnvOaXOS0OctgfRj6WNkeFbNc7C3MaJZgViJTqk
ZGvyvB5HMltYH2ULmofWCOegeipOQfRVCbPM0ra8u1Dpwk38FkYUd4GHIi3j1BFtZ8bvDFpO18Ct
ukRxA8kzY9m2P9Q0xm3lA9nQ/4X08TpRq5Je0INCayCdwky+R7IkXHknlsjSn8UzXX9RydflgicY
wL2KEBOAY/UoqOI0b84G4vz5koefcR27mJDPzHsvglfOnFwvdO/brvuOUoEVYKiEy9tEXjA2qokQ
Pq2hhDY2eHWWA7J2ikRXARHd244aQTBLjKOxkHNiO7iZmqJ5niJzHhL6SSjF6FXzv53OqQFFL0dS
jVGsxdzj/xK66No/c3W/hdYxysOIfXGwBzVMvjHCrswdflvYUAOT9z2hsy4MT5edEw3fpJHeP/1s
dBnojktryNOUoX0apZepNNG9qpEEWUAme47KYiU0jGaag8VHqyK+FWvisZM5onmWNAX2joQhWR4F
dK8qZweTOKqEpvRirjbgRyK2WyPzp0rWAEF1KDhu5eHDvH/te3ZiTeWcfg77mugPj6twEj4C1Fxx
Ptwzxf+6RGHs9WjB9cGSxZTDzB+9N/KrV8XqsI5GoKTptTAIZbCKaec0LMVQGAlFW8NwHuF74H0a
tG8lJU6HL7NP2XdL9UKSiPY8Hwq9/qlk9HAWCiLgAfqfx89blHH7n4OOpDyJaKLrd9WrjHKSexYJ
EHsdjyQg1mgv4TiAPsTczmADI3y/3N8voFAgJJJcFw4KBkiM91L+Y3HIy/2GW6eq7GBtESp734JK
6Wffi+D+NKca7fmG9ZjzUMo932Zdj0j5AS95Y0m9SqwOA63t2I3orlpshc1JMYIoA0qdAU7WfZ4l
4B3MDUgjKkPxkqxNxb+9T3tAihPelO2wRkgf8vtB+ZiPo9L23husjvg9ZmKOS2Hv2XZGCjflz+QU
Oqt1C3SkTtwtchYPDGsI6NXletqHr2affkgWBMzBdUuYgzoCC7j7zstnGh2u3Sya2kZ8C0f2TTaV
yQ4N7QvY8TK1ZyT5c0rU2oSQGvEfTVJMMRHEDoU3AhZCYphkPHug4dmPyZrdAQKA8e+7dZ/q5cXo
Sa3N7v7kAW2QgcqLRv8b+TRMDcKkvUpVvw/xq9/0FlO7NsmpsO2AB14pur5TiwnCA3OLO4uX82Mr
/i9rd1mZ+yXFOzzlx7DdtBUwnNUqMJcQSse/nvoD8uQC/s+fnaZWuatSDG4IsP7/DKm9yYuRIAu1
vpHSN5trkc/UlrzKQwQIwhbRvib2E0ytHrbt0t6DCyPACNJYX1E+FSvFKPupwy5ImqwMaafasqU2
t/+z7liQ0rYRESwT3nGtYDTCGFFTQ4l2qUAfomGMW7Ty+FtOQ139YWIaqpevHj3l/0pplR560iIO
56xcRvuYFI4+Z2Iy24YtqderOVHNbkLwSE7IBxxAIDPKVO/75Ymw4HuYFriNqTQpCLMC0iXdLUZt
RAf4dRUq2l3iyQdigCE08cwI3nhb6AkAMaoLBMAOnOf+8kaz5qdGuGO/w9QlTX5FLFjEpi0V2Jke
Khbv8Y8td2KF8MRPgEZUNsEaIhQrHrEr4dkmSZSiJwNUU+EJgA4LeNv1JbB0moi7tMvDEjubuhD/
FUdCsa/gVhHD/cgk3cEhIU/XCh/faKY1EYK5nYdw5DeWE2TK6PQgJeYk5NwXa3s3U7URP9pxMvKk
dlTuv5+C3t5fwivg/IK0RYhu6yUEWJb/1k/HUa0oMiweoBuU7eKiuEEeNPwjI7T4WelKegxbFeCY
r7v9zIje2B83n6oBfa/5/eR3VehfK+5Y7EGS+KPFTzo+j+f7WNQtq5MuhTJmW5sKXYKQIaEsUMGS
N61wmc2hggKOUoRx2GL5lq1nFYNzo1yi5eV2t69VDBPVpfTFHsOpPtcVijZfeoXiN9XNreYHiJ3p
3W1SkBiiwu0kLamMrGazDFwSCNZ47M1L8g2y8gAk+BUexGqdivvN1R+SbcmZKXO0ZWznPgf4oKCa
jk3zAC67LgZgKCQX6+7pc69zalc4PI2wYyFdV0==