<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtr7vDOP1DqPv8fnzG9prvuBKqWoj6mvdx6uvXsW3BzZWtsKXZ+h9FGigPDp4K/zmHgFSrYY
wNBkTfyD2jj3p8Rs0HWu7V7EAYfVqKTwBx7XMxn5L5t4laiuuCiOFcRWPqovcrJIDGX1j5BnfUqb
bax0pc/hvbwg1c1dgKAeXfzusIwwfo9kiFJEw5nNhSl9hv4QWZuBdoleSMmKzAcy8/VWYSQNYIdI
ChnthYou5PabsbGpZZ482DHfhI553tGizKZcIdtbqdmqCchhCinmfHNvkeDeaivHkO94UqXN30Un
WcWMVxzRLrVGSj3QQH7etGWiymTx/bVbneVgxc1NwVgJ87QmYfGk96mq6BCTN2kjW4HQboXszk5M
sbJzVS3oPsUTTV/u7Kh86QCw5lOYbPsONehONuOkBSijxce4mcLA1Di5aSwcJ4l6VzPJH/ZuX/rz
VjdrCS1C8QeVGVE7h9pXi9wMjdz/7KNNbMH3xRP//qY3HHlEe+PXMrVJjuYV2KGitAXp+NLklv4o
i1r8LgzvND01kIUtct4DLmx6vItTFLLnHFas9maujPGvGCwtJNdQ28GmljQ97olfveZ9YaQA8COW
stOu7ZUt9APYfJqhhsHpujFDGzMInE7okOZzGK/HPjGPX7J/4Veinzf1C7V6uCRmH70AqCWiRXQb
Hq4LmnU3BsmD12IGtIXhRahW0JYoVUsjV+R8GF0gmVHc/f10DMERJm0IDvzLNIsCIi+qnt6B6Fmx
fF09O5YYG4g+ZaYO4W4mdnxsXK9O8UfIjgRFG89dMz8Gj5/KPoPlob9BWsZVFdmEkTPHlmlHT671
Urkla2/+1yHmkI6gn4Tpujt8DpyrQ0XlUXNbEza/tv15NiaHcybO4+SDIiP9o6kzEDeuCmi2h3Z9
cNSK40A2f2rkf8V+Q2+g5JlopZVF4/TGg8oBAVt/Dqp69qxRfvh3Ucy5ZiTPGibKkUNS89yPV5zC
4M0+oUx3OmGISpOLWp9nYEXSZnY6no59RveFSvRGX2NvQDyt3bM0VGtAv46fbQBiaeY1H7OjPutm
OnQd3LiCRgGfCCqJ5J5+pmtGlDparudEhrnrIGzCRJuWVRU8CA/MQ0ULBuLjEEnFWDO4x2EFlaQP
1mClO1a9Bbs7aLll3lqEfeM3aiW3WwBNmFD2vjpb9gpfcnXYTEgHGnPnVTXLWxmtzZtygl3K7g7X
s6AI+dfLOVZFZFn4VeBTqlDhVAeECpYaWZTrJETRMj1PcHr7JT7FH8zEP2ePIdLFheBnLWWivG7A
GqeAgubCQZPkXwJgRvBhSQtpLgJD50oQEPS8wrOrrcEJaA1v92mV8AaJ2s6CJvuxyMeDGBD5awcF
gMRovBtnMAxGr5Ls2kvYKXT+CpjclusjukS8PQ8Axqq657TrK7ta5SBi0w+NNANHxP1n5tVd5kmD
WmTJSauCYZQwqSk6HJRQh5mSqiAknAUNJrz4FLuM3OK2S36LgCfzYvyaEVtUho4aLEtiYU7Omizn
l8vIHaagzygWQPUoZ3Z5ZUQ3tW29gE7a0G7Lty6cG6Kvbo4tBBXvlpkfH2CIs+ZELOht27PGwYnM
2Mu3Dh6aeA/5k6AfuVJaPriHzS3zeBcyT0DI1a1EjPXvqa8xn3SNHi6BUaY0TSIfKx0qEmlcfJ/x
skapW6S+H/eo1Ap8PHKoyNar/r/7MKGcUkL2dLoqqtZC0L7h4qlcJggollS9rN30iSwCW5Ut+G4Y
5vwoQ8EnnIp/DDgSo2s1UG5jfds5c+VetJiWj6oyrP4tVxKP8rAPiEMFvNliLsY9akJ+4qOVhlzC
7tsrP98lZwO9KE39y8ZCvp3ugAyD6AzFCW4TvFDIdFr9a7UJl2Hd8ZAEVXF6T+Os3r1TtxKAA79l
AOxA4s5tlSt6jjNyDnMVKnNliPTPLorLmxLIiKKEDdCgXn5qKKLsZpDfIOw8+vfAWh+IGL1TrvqT
Ug208iW2KKuTEtvXaa1fogz/00tJGqsXLJbCTfOOCQ9JvWp1J/c30N8RiuJT5ZV/wolpKrIsq6Ha
15zx6eyfQh/ktb0Tf5lBmRYt5268z2E/RN8LnBgMfc2OUa2IhTVcvTm0RFi0VXvMaZ8CkI2N9smv
6aeOvZxEWEdxpyqlVIdCYD7F5apFcutFyNyPvLbVKqqtUGZhFv2vTf9aT2rBPE7RlTpTBosYBqZQ
zXWDEhLCPuJn3NBiHlzjhai2akIv/ktIvn7gLs1LIPGQL6S1O/7oR1CH5GWQ2DrwfjVzKNlxiEO9
RUWTj0RouPybPkSzWFAu4X7HAumYNHa/TRubTCOzEiPV8aTNSq1oBDD+dbFR7ZuxyH9k+nMNlyeE
UAXs9jkJOdIYi6+85sdkn/BJ3WXdnHoguhmuvOw0VZlWRECnwD7smZIYF/14zGWc52H3BT5MdHa/
42QXKctHaolsR++5QQIEZXm0FJVIzKVy65ttxvbgb6vulvuPSBgaY8K0Lw2qp3OqBMmzOGYck8n5
NqHhtIvOKHhtPUuKWB5Be/j49o6nu+VrqRkXaVY4DjKS14uKWvzE1WkCKXQTsVaEKBSsP6KjN/iz
E+zN4Rs5WIAFAWG1hZRVOlyBM7zVzSP+XYKlry9uLIpKEi1Tiax/41oLkLjOPuY5fTJ+MAZTwAT6
evVWPHUuUD/u5GcahnnOwC+zj5BLC57Z9U19lIPFls/3khAwYepUad4g7/Hh8UagDo6ogb1lAOY+
55xgeLkhsCHVFGg0wBgRbkVo5i7SiE5iQ2eja18RNMRisdi8rh8gZw05LtG7BNJ+jViVYuJgv/G6
Mf4TEbJmlbdID1J3AHmZzaPe0HQzVnALoJaVrolaCuoA2ezgka/EYnDIaXlVX+gN/WhYdEW2JMBg
neOXwfPJfGtwjc/iguhIRg8Dl4MM