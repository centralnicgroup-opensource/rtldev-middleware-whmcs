<?php

namespace WHMCS\Module\Registrar\Ispapi;

use CNIC\ClientFactory;
use WHMCS\Module\Registrar\Ispapi\Domain as HXDomain;
use WHMCS\Module\Registrar\Ispapi\WebApps;
use Illuminate\Database\Capsule\Manager as DB;

if (defined("WHMCS")) {
    if (!function_exists("getregistrarconfigoptions")) {
        include implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "registrarfunctions.php"]);
    }
}

class Ispapi
{
    public static $tldclassmap = [];
    public static $ttl = 3600; // 1h
    public static $authttl = 3600 * 24 * 5; // 5h

    /**
     * Check if Authentication succeeded
     * @param array $params common module parameters
     * @return bool
     */
    public static function checkAuth($params = null)
    {
        if (!$params) {
            $params = \getregistrarconfigoptions("ispapi");
        }
        $defaultrights = [
            "WEBAPPS" => false
        ];
        $hash = hash("sha256", json_encode([
            "uid" => $params["Username"],
            "pw" => $params["Password"],
            "ote" => ($params["TestMode"] === "on") ? 1 : 0
        ]));
        $td = \WHMCS\TransientData::getInstance();
        $data = $td->retrieve("ispapiCheckAuthentication");
        if (!$data || $data !== $hash) {
            $td->delete("ispapiCanUse");
            $td->delete("ispapiCheckAuthentication");
            $td->delete("ispapiCheckAuthenticationError");
            //Check authentication
            $response = self::call([
                "COMMAND" => "CheckAuthentication",
                "SUBUSER" => $params["Username"],
                "PASSWORD" => $params["Password"]
            ], $params);
            // data valid for 5d
            $ttl = 3600 * 24 * 5;
            if ($response["CODE"] === "200") {
                $td->store("ispapiCheckAuthentication", $hash, self::$authttl);
                $td->store("ispapiCanUse", json_encode([
                    "WEBAPPS" => WebApps::canUse($params)
                ]), self::$authttl);
            } else {
                $td->store("ispapiCheckAuthenticationError", $response["CODE"] . " " . $response["DESCRIPTION"], self::$authttl);
                $td->store("ispapiCanUse", json_encode($defaultrights), self::$authttl);
            }
        }
        $data = $td->retrieve("ispapiCheckAuthenticationError");
        if (!is_null($data)) {
            //logActivity("Authentication failed for registrar module `ispapi`");
            return false;
        }
        //logActivity("Authentication succeeded for registrar module `ispapi`");
        $data = json_decode($td->retrieve("ispapiCanUse"), true);
        if (is_null($data)) {
            return $defaultrights;
        }
        return $data;
    }

    /**
     * Return last Authentication Error Message
     * @return String|null
     */
    public static function getAuthError()
    {
        return \WHMCS\TransientData::getInstance()->retrieve("ispapiCheckAuthenticationError");
    }

    /**
     * Make an API request using the provided command and return response in Hash Format
     * @param array $command API command to request
     * @param array $params common module parameters (optional)
     * @return array
     */
    public static function call($command, $params = null, $registrar = "ispapi")
    {
        if (!$params) {
            $params = \getregistrarconfigoptions($registrar);
        }
        $cl = \CNIC\ClientFactory::getClient([
            "registrar" => "HEXONET"
        ]);
        if ($params["TestMode"] === 1 || $params["TestMode"] === "on") {
            $cl->useOTESystem();
        }

        $modules = cnic_getStatisticsData(true, '/');
        $cl->setCredentials($params["Username"], html_entity_decode($params["Password"], ENT_QUOTES))
            ->setReferer($GLOBALS["CONFIG"]["SystemURL"])
            ->setUserAgent("WHMCS", $GLOBALS["CONFIG"]["Version"], $modules)
            ->enableDebugMode() // activate logging
            ->setCustomLogger(new Logger(["module" => "ispapi"]));
        if ($params["HPPS"] === 1 || $params["HPPS"] === "on") {
            if ($params["TestMode"] === 1 || $params["TestMode"] === "on") {
                // we must have an apache proxy config working for LIVE and OT&E in parallel
                // the only way to achieve this in a static way
                $cl->setURL(str_replace("/api/call.cgi", "/api-ote/call.cgi", $cl->getURL()));
            }
            $cl->useHighPerformanceConnectionSetup();
        }

        if (strlen($params["ProxyServer"])) {
            $cl->setProxy($params["ProxyServer"]);
        }
        $response = $cl->request($command);
        return $response->getHash();
    }

    /**
     * return if the reseller is allowed to use something (product, ...)
     * @param string $id identifier for what we check access rights for
     * @param array $params common module parameters
     * @return bool
     */
    public static function canUse($id, $params)
    {
        $canUse = \WHMCS\TransientData::getInstance()->retrieve("ispapiCanUse");
        if (!$canUse) {
            return false;
        }
        $canUse = json_decode($canUse, true);
        if (!isset($canUse[$id])) {
            return false;
        }
        return $canUse[$id];
    }

    /**
     * Save module statitics data to user environment
     */
    public static function sendStatisticsData()
    {
        // get hostname of whmcs server
        $parts = parse_url(\WHMCS\Config\Setting::getValue("SystemURL"));
        // don't save stats in dev env (independent of user account)
        if ((bool)preg_match("/\.(ispapi|hexonet)\.net$/", $parts["host"])) {
            return;
        }
        // load registrar module settings
        $params = \getregistrarconfigoptions("ispapi");
        // load statistics data
        $values = cnic_getStatisticsData();
        // BEGIN: cleanup old data
        $envs = self::call([
            "COMMAND" => "QueryEnvironmentList",
            "ENVIRONMENTKEY" => "middleware/whmcs/" . $parts["host"]
        ]);
        if ($envs["CODE"] === "200" && !empty($envs["PROPERTY"]["COUNT"][0])) {
            $i = 0;
            $cmd = [
                "COMMAND" => "SetEnvironment"
            ];
            foreach ($envs["PROPERTY"]["ENVIRONMENTNAME"] as $idx => $name) {
                if (!array_key_exists($name, $values)) {
                    $cmd["ENVIRONMENTKEY" . $i] = $envs["PROPERTY"]["ENVIRONMENTKEY"][$idx];
                    $cmd["ENVIRONMENTNAME" . $i] = $name;
                    $i++;
                }
            }
            if ($i > 0) {
                self::call($cmd, $params);
            }
        }
        // END: cleanup old data

        // BEGIN: set new data
        $i = 0;
        $command = [
            "COMMAND" => "SetEnvironment",
        ];
        foreach ($values as $key => $value) {
            $command["ENVIRONMENTKEY$i"] = "middleware/whmcs/" . $parts["host"];
            $command["ENVIRONMENTNAME$i"] = $key;
            $command["ENVIRONMENTVALUE$i"] = $value;
            $i++;
        }
        self::call($command, $params);
        // END: set new data
    }

    // @codingStandardsIgnoreStart
    /**
     * Load PF Data
     * @return array $pf PF Data
     */
    public static function getPF()
    {
        try {
            $rows = DB::table("tbldomains")
                ->selectRaw("registrar, count(*) as DomainTotalCount, sum(is_premium) as DomainPremiumCount")
                ->where("status", "=", "Active")
                ->whereIn("registrar", ["hexonet", "ispapi", "rrpproxy", "keysystems", "centralnic", "cnic", "tppwregistrar", "internetbs", "ibs"])
                ->groupBy("registrar")
                ->get();
        } catch (Exception $e) {
            // echo $e->getMessage();
            return [];
        }
        $registrarStats = [];
        if (!empty($rows)) {
            foreach ($rows as $row) {
                if (is_object($row)) {
                    $row = get_object_vars($row);
                }
                $registrarStats[] = $row;
            }
        }
        return $registrarStats;
    }
    // @codingStandardsIgnoreEnd

    /**
     * Cast our UTC API timestamps to local timestamp string and unix timestamp
     * @param string|int $date API timestamp (YYYY-MM-DD HH:ii:ss) or unix timestamp produced by strtotime
     * @return array
     */
    public static function castDate($date)
    {
        if (!is_int($date)) {
            $mydate = str_replace(" ", "T", $date) . "Z"; //RFC 3339 / ISO 8601
            $ts = strtotime($mydate);
        } else {
            $ts = $date;
        }
        return [
            "ts" => $ts,
            "short" => date("Y-m-d", $ts),
            "long" => date("Y-m-d H:i:s", $ts)
        ];
    }

    /**
     * Cast our EXPIRATIONDATE timestamp (UTC) to useful WHMCS data structure
     * @param string|int $date API EXPIRATIONDATE (YYYY-MM-DD HH:ii:ss) or unix timestamp produced by strtotime
     * @param string $status (optional) API STATUS (e.g. "ACTIVE")
     * @return array
     */
    public static function castExpirationDate($date, $status = "")
    {
        $expdate = self::castDate($date);
        $result = [
            "expirydate" => $expdate["short"],
            "expired" => strtotime("now") > $expdate["ts"]
        ];
        if (!empty($status)) {
            $result["active"] = (bool) preg_match("/ACTIVE/i", $status);
        }
        return $result;
    }

    /**
     * Map our API-side Nameserver list to WHMCS format
     * @param array $nameservers
     * @return array
     */
    public static function castNameservers($nameservers)
    {
        $ns = [];
        if (empty($nameservers)) {
            return $ns;
        }
        foreach ($nameservers as $idx => $n) {
            $ns["ns" . ($idx + 1)] = $n;
        }
        return $ns;
    }

    /**
     * Map the WHMCS Nameserver list to our API format
     * @param array $nameservers
     * @param bool $allowEmptyValues
     * @return array
     */
    public static function castNameserversBE($params, $allowEmptyValues = true)
    {
        $ns = [];
        $idx = 0;
        foreach ($params as $key => $n) {
            if (
                (bool)preg_match("/^ns[0-9]+$/", $key)
                && ($allowEmptyValues || !empty($n))
            ) {
                $ns[$idx++] = $n;
            }
        }
        return $ns;
    }

    /**
     * Load Prices and Exchange Rates from Backend System/API and return a boolean result
     * @param array $params common module parameters
     * @return bool
     */
    public static function loadPrices($params)
    {
        //load exchange rates
        static $rates = null;

        UserRelationModel::createTableIfNotExists();
        TldPriceModel::createTableIfNotExists();
        //unset($_SESSION["ispapidatattl"]);
        if (!isset($_SESSION["ispapidatattl"]) || (time() >  $_SESSION["ispapidatattl"])) {
            $_SESSION["ispapidatattl"] = time() + self::$ttl;
            UserRelationModel::truncate();
            TldPriceModel::truncate();
        }

        if (is_null($rates)) {
            $r = self::call([
                "COMMAND" => "QueryExchangeRates"
            ], $params);
            if ($r["CODE"] !== "200") {
                throw new \Exception(
                    "Could not load currency exchange rates.<br/>(" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
                );
            }
            $rates = ["EUR" => 1];
            $r = $r["PROPERTY"];
            foreach ($r["CURRENCYTO"] as $idx => $to) {
                $rates[$to] = (float)$r["RATE"][$idx];
            }
            if (isset($rates["IRR"])) {
                $rates["IRT"] = $rates["IRR"] / 10;
            }
        }
        TldPriceModel::setExchangeRates($rates);

        //load user relations into db
        if (!UserRelationModel::first()) {
            $r = self::call(["COMMAND" => "StatusUser", "PROPERTIES" => "TLDDATA"], $params);
            if ($r["CODE"] !== "200") {
                return false;
            }
            UserRelationModel::insertFromAPI($r);
            TldMapping::initialize($r);

            //parse relation prices into basic json format (standard domain prices only for now)
            //and insert them into db
            TldPriceModel::insertFromRelations(
                UserRelationModel::getDomainPriceRelations(),
                $r["PROPERTY"]["ACCOUNTCURRENCY"][0]
            );
        }
        return true;
    }

    /**
     * Get a Mapping of TLDLabels (e.g. .co.uk) to their TLDClass (e.g. COUK)
     * @param array $params common module parameters
     * @return array
     */
    public static function getTLDs($params)
    {
        if (!self::loadPrices($params)) {
            return [
                "error" => "Could not get user status from registrar API."
            ];
        }
        $tlds = [];
        $tldMapping = TldMapping::getTlds();
        $relations = UserRelationModel::getDomainPriceRelations();
        foreach ($relations as $relation) {
            if (isset($tldMapping[$relation->relation_subclass])) {
                $tlds[$tldMapping[$relation->relation_subclass]] = $relation->relation_subclass;
            }
        }

        return $tlds;
    }

    /**
     * Get Prices for the provided List of TLD Classes
     * @param array $tldclasses TLD Classes
     * @param array $zis TLD Configuration Settings
     * @return array
     */
    public static function getTLDPrices($tldclasses, $zis)
    {
        if (!TldPriceModel::first()) {
            return [
                "error" => "Load prices first from registrar API."
            ];
        }

        // return price list for all requested tlds
        return TldPriceModel::getTLDPrices($tldclasses, $zis);
    }
}
