<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class TldMapping
{
    private static $transientData;
    private static $cacheKey = 'tldMapping';

    /**
     * Generate Tld mappings, base64 encode and store in Transient cache
     * Tld mappings cache in Transient are stored for 1 year until new data is being replaced by the old one
     *
     * @param array $apiResponse
     * @return void
     */
    public static function initialize($apiResponse)
    {
        $tlds = [];
        $convertIdnTlds = [];
        self::$transientData = self::$transientData ?? \WHMCS\TransientData::getInstance();

        if (! empty($apiResponse['PROPERTY']['TLDCLASS']) && ! empty($apiResponse['PROPERTY']['TLDLABEL'])) {
            foreach ($apiResponse['PROPERTY']['TLDCLASS'] as $tldKey => $tldClass) {
                $tldLabel = $apiResponse['PROPERTY']['TLDLABEL'][$tldKey];
                $tldLabel = ! empty($tldLabel) ? $tldLabel : "."  . strtolower($tldClass);
                if (preg_match("/^XN--/", $tldClass)) {
                    $convertIdnTlds[$tldClass] = true;
                } elseif (! empty($tldClass) && ! isset($tlds[$tldClass])) {
                    $tlds[$tldClass] = $tldLabel;
                }
            }
        }

        if (! empty($convertIdnTlds)) {
            $idnKeys = array_keys($convertIdnTlds);
            $r = Ispapi::call([
                "COMMAND" => "ConvertIDN",
                "DOMAIN" => $idnKeys
            ], $params);
            if ($r["CODE"] === "200") {
                foreach ($idnKeys as $idnIndex => $idnSubClass) {
                    $tlds[$idnSubClass] = "." . $r["PROPERTY"]["IDN"][$idnIndex];
                }
            }
        }

        $cacheData = base64_encode(json_encode($tlds));
        $cacheLife = 3600 * 24 * 12;  // expires in 1 year

        if (self::$transientData->retrieve(self::$cacheKey)) {
            self::$transientData->delete(self::$cacheKey);
        }

        // store data in Transient cache
        self::$transientData->store(self::$cacheKey, $cacheData, $cacheLife);
    }

    /**
     * Get Tld mappings from Transient cache
     *
     * @return array
     */
    public static function getTLDs()
    {
        self::$transientData = self::$transientData ?? \WHMCS\TransientData::getInstance();
        $tldMapping = self::$transientData->retrieve(self::$cacheKey);
        $tldMapping = json_decode(base64_decode($tldMapping), true);
        return $tldMapping ?? [];
    }
}
