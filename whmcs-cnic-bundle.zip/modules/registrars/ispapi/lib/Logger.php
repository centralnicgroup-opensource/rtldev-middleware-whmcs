<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqRW29avPV7Un2cTke6Pc4wj2AF0S4mztDGo0Qi+ANWrLmCtuaAwj0Qi5O1Gm6b8lCm48Kax
1j04BOULTtiw4I5GVZI4fVLWBF5hdpwMXO+4qvnU2CITYjYN1hYOb/8QlA8LiqjBWVWmHFt7X5Wk
XSzX1dJz9y4vnTHdt+36iFwR1c77Z5VClzbdB1PIJpiidZuss2gU1XYmCRkEYIRrkEe3S/6RmbIl
CtV2ebtHLSBO7/wqOh9xKYqOJM1kdFId5wG8VWvuwW2FAIcOyaxrHkcg39jcPHWoKFvNcPT7VQHs
yQ3dPCpw1ZNJlC4N2mu3AkZ/PI3jZbv4PJZqoVyDuf+KdCfS4rvFBooJYVAQtM6rDErvVf+onAX3
W8DK3zSbY4n0dakN1Avgjx6WqLsSvgn57eZNrUV4ai1WK3wYif257tfT76rvTIkEEWteAu6LxLHY
GVKekBsVMtbJwEirYTxbKAHNHCziFypJFuXiznWlOLolLcPkXkvNkBj1e4HwLTIGVsSYieGhPOkH
XhO4sKgaW+nxcWRJYGzOBQH/aXbNXefdqFPJDK0UbnnKMM0rvJ647rWorg/Ogn28N4JKj+jG7ca6
NHl+OkcxcUdGGeANujkia9w4OgKXlNvNY7pOclrkU+jLLq8DMAK5pVxfkapuTyINtZ4YGL3nTItl
lG0bMxW+xCfAHDj/HP1492GWYVcZ4eQpT283/ZC+TC0Hjcs0Di1UcYp6o43tWJJ0SzDfhuSQ0uF6
NWz9tKH5rLZtG2sDg3EcVvT1tllZvuiSiuSKYYYZFahEcjHgjne9cKAaCsf/jzTZc+bU3jPC3DFw
/4tunibnhHDQEmooguaWnoGD4QNtAZNEmUQVuC7TVzfaAjfv5UnyzhbZDvALuGzehrO92ustn8DT
FkkortjPSrjABX0p76v8iKg25pqoZYCNMJsI1iolQjqgZQ/KwgY2tzCO/6Cv1RNsjBb+yvYtm/YL
KRr80qSD3Xc/gt7/FXwA7TuayOTUFOlws801A74g3uFuvtRw2c35u458qIJLEDkLb8jTZ4zayx7l
2zRcRuh366LqNh88Z0LKj5tix/LuYtnvLVXSJa/5Ak0lno6rdGCH3xQvnyZ1O0/GbSg8Sd5OXRJL
BG7LIy4PlTjp6ACqlEilLp9zaZf7II9K1vOtxkECVzSTjS005UVOcKwFelWWaFC9W5iEpvdQru1x
gxgiemO0cA+yvBdvp8jn8wh7TL8elNvDW22eNFlURsf8WjeJkSEgVYXbWhw4oS+45NZ6uaVUM7uG
kmRwoobJ2SkwH3w6eVZzk7+dogC1iW9OXoaNnUQf9c2hDVaiNdi1OIEde9k6Dz/gas657nledTtC
6XkWtPBvQUgVU/gMEruYTQcX/87dCzkPbZVFxhp5kL44BxIuDi5DEc9uSrZ7CqjMbm4nnRSt2t3y
LdXrrGNnIntR9zDgbF9JqbtQR15UmLH21Jb577Aai75A4hOXHsNRwB1Wj2xgR52AnAW4wwzLHjo9
ATmQA29NqvGDqOQlOGrSW4bvE0raC0nKBWWj/STXbIzqzNVBHq0oDQlK1qO0IGmPtZv45YMjge9/
/iXrhQNdb/NWjW1BYJZC//x8DSrxAvOWadAc5nkdRLsfLPmUHoxFyPn/16HLnC2qOgKljO4B7B8l
Bzd7YLzqZVNB6g1i0D1wTx2wAQbdQq7eUlvx0iXrimRCYPkj/8XaGc6NVrBX1xrKP0CYbK9FK6jp
Ot45bWw8k7G1f9e9xPtU+ffA1jVU8WiJhpcWbGolpkqBLIpI/JAu/8A4r8xcaH+bUjewJymrpCBu
7snth5kLLWd+tcpA9uXes/D+IDq9ckn7XpxLsZUUvf8cXlz4n+pZW47BK9i96hmxEFiZ3ONw8zEI
Yr2ZL87QsrXAktC89iSCo4Z3C7QJmlXJ2c9QWhgzNMweKDxrJ8W7dlSgokH0gS8HlS2kyPRI7ugb
SP5mEf3JsdYqP0MNawX3IWRlQFcg8qak4NbsDf29JvGt8Wxa4S9qIF7omTdEJtl/2yobi2O+SMif
APEq6fvTjJj6vb3ibOw9Nm6pVyQvQa7hV2Lf6BlrqGckbbM98RicQLtORmwKI1Iluy0BtDIiMcap
pcW2RXqP3a4+dzIrOjbxa88NBfSz6XtNfbnlzUDls/u2gl8P0737i6kuJquFOiDoYcOABsbNTTtm
739Sg+yg+ZcPZ7gJyoGh8RjSqRAjDJ+krN1wBOb3QfmUWQovNv+F/0r3hq7MdHS6XQFWB0HYTPsT
yXc7Hfa19XCv6zBO4Y+m4C7ZmRom98j84bRu4l+IP7b+E13ieqRdF/5Mj9x4fvfiUdGzY0iYk3Ye
DKeYYA6CZOaDcmjhN8yRCvif9OgI/dW+CcmUUbQLW7W1j65dsQdriOVNmI533TOloOyI/q1XFeVS
dmu6TOALApTlMJUkxvXfGzGlomwtT3YWzczyP7u9YSg5CGkTWXFK2kS8jhcb+1wDgz0xlFkaOuIe
bhgODwvFJrbaqq8MV1E8gFFcsZgWg0GCDHNI7yAGYdg1zNM52hB9enppJWE5VI4OJNHLXvSNaxQJ
Qiqou7hGGejDbRXDXGK7WQaXMtdJy6QMTRtZA/msnp6XgMfklWXkTNPyKOQoRQArXm58tDvhfAwQ
UFvoI0AsXdDRJaEFhvCVw5Ihr1uuwZGqXdzpvJSwsXHdxYHxHnTHODtmZNy5SSZkBIZ0ShXkSEpJ
U5SLEErFf4jzWkjzbjxtm9sy3BXq2dlZEcwjtnCcgG3v32a3+tE65XFj10isLd52PdfkRLNnG4kC
ehR8ARYFGWcBvra0v65tKZKLqqWtsmhf8R+5zLgMgB1e8YVemr8OBih/heWaui8ZBb7Znt+EQL+E
M2VJUeSJGW/1YbSPWs5f0WqGylOkSN+K8IRG8nBS8tb+QfQlovWf/vg9klfYsCjtSY1+7ART+inF
9sbrxz61ZB9I6le09+IFjvKiv+ubE4DVQbQ594RZZx/kR8L9P74rNr2gJoAi9iiE60FIpvNeGjzC
Dw13akg1M+By1qJ+kQjBBrTvAdhFDNQEcV6H433/f2vNZF9L2jtZ3XZTmcltSLUmHu7CcGS7qsth
WctFHKPaoT6gI3T1cR3wivSQ+yKgtOdlHsqWgCVx1q5Hmd+kPTUO9hm6ijLD5pVEsM1aOdm6u4+2
pkkE3B5sjczSLYE7XUVy4cVoXg4j00PK/VTle3UBcg6n26sL3QkF/oDVJvl+LvEuys9vxZUJZcDb
AMqDp5l1zHiMKHQscfMyCgkxe0C+OqbLf5AhrM2bKBnEFWm/Z0u2IKBuMEgyhkmfZ8Z0+2mfspjs
SH/QyU9/jxDFCzOJLgRcsd+u7MVEaeOgUz2e6qWnClRXnDNCa6uLJVeupjzDenrMzDm/QhudKxEt
Ll/ryoI7dARkv+/KUMVtlcKRtXa2AQkgWTaRMUnuq3IORToX4O/tRDy4s2CS0pVfZnkLC55DgFzd
tDjHpCXT4ca4BYTdn6Yh1nEat8FZZtMthr8P0d9nx1yOuqhseFEJiQBv/cgZ1NV3cYHIDJymSJ6l
rM6H6LPAGYws/WNcHwyO0c4xAKOiwUGu2TVROC01MO7jtPWzqzNaJkm8pMuxiIitN34s4WIt4d/n
uoyY9Y6fs2AzBMfgQ8hz26BSCqqJYJX6vUfgjo24JRc1AJLIrHjqBnmQnRXgsbNupxXjh1bGSjrs
TGjrQHrASI7xVYQwohuCPVxoMllYrIWWwpcrQlzY/o87Mf/L6ykYKYKYWIPhh8xL7WQPYNvxHVkH
+21ToDh9W9NeVGkRLcGFXXvKIHU+15BAznhHKk0SXSDzcp7JClfppge6V5YfzPKgu52Jp/wXVlDP
cx2isyyTV8bpq+oUWNIdPE7XWrk5rnS0/rM5rtDqmQ9iqDVjLQhqKiCvL/DaC1/zYaROJpcI+O/t
g0UawtlINGNAxTXGUI5iiMqV9Hy8EiGjYLrXlpBPs59TH+4ph0nepqHPmw0nyKMSpM3znMBlYezu
sOTN7aq6flSp1RmKQslPE4G3DPBdyP90D+htBwAU/VlCj8ikzvoFPL6xgzJaEXqvOgBX0+agmCmR
zYTAESAyGG7uaetDoavrrauziIEhXKYLmfgtAE35EbrRqIl8KtuUw2HaddiIV/pKqsg41xA/orXO
pAl8ZSB/5FAApl66IVGSduDD1sQ7nXjF9rLZXXJzxl7II2HlpkUDKnIBl5BSdo2GymzKLlZAnWnE
2Mjqv38aagLNiqr2i5xIRAMrv/AIT3fUoa1bd8t5QEPUZqKG6A7mA7+LXSeKXwabpszM