<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvESRX5IILCdArNxCj4lSk46ZQJcg8b+0R2u/BIYYzje3my3CbkmAmW0nkrBu7H9FTMqsuT3
gHSbHA5py1IbBVCtLQ5+lrixxDBxEdHgqgn4IJBiZG13ZGFg7P/MZBjYWL/7QbztLp+J/KWqHtLJ
0fMNUFc1b3K9/EAkHKXZ12nAoMu31w9x3TDwxf826oarOrImaMgiP/Eri3fjbKluRspY3darprem
HIJS7vD4aFmjmU1b92TVA6tqp77xnOf/L3GtQM4BibGvDFIXHeienCM7UkXX+5YIJWACc6/SPKxt
1EXi3xLDAKDFUDNePiz673DeIepPBmIafkqLZrWAM00XMME4eu8zpJE9R4msZ3IUsfDXWmhG8bWA
ug/Ijk6srgU9NAzrBxt9lhDzMWgvrVBeBdA17ysp9a0zWGdlmkLaf0Js4iHQ/WLW6zSE/QfzMZHB
C/45eWwApdYHmGMJ8uANu/VO+tQbOuAxx+Zs0KdKKJyjCy2XFcCmt3iuMAvlaLd5d52ZjM3IoNZP
HXOFYHQISjhEVLf8vFEYz5XSzRM7YCDH34vuNpCO877Vr/3rFQmTUMTqWRKFfonN6zIVeUDAnE+m
D3xZ5TTl3eXFEtcJbN5AbGCeGnXzTZeDLMkoLlm6N58BeEmwZ/LJGp//joxJXbe4TbEOClzwQIIl
KOTBh0P1qw2Ri49KXTyvyshTnYjUdVT10c6U/AddEtQbOw1bK6q/OC8X9zr8p4A5+r+/xYDFET2e
L6MkBm+jsxokDqA87OsRr2VV1qb4/InmzH6DpzjheJRwXpcHNbYS3AHS2NHyRZSvmGSBoB2WCVfl
XXhIXyEFOJUDoQGZaKC9GE/0bgGuSTmsaFD7KC5zgNH2EL4r9LuPGvSuZCD4E3A0ML1mS6a8ALZM
00IhnKkJwsmDuf8UXnkydu6qcy+9Hbmt2yEOZ9RpwZjRbzVheNPqpsHoRa3qvr7R4vmPkApTK/Sa
LgDkAZMMYyJfs9v7KTUsOpftbmwTCX4GbB5sg+Dcei9dxwI+8NGm6BNiK6rOieTMWn6RcqioNJvm
lCIunFHJeqrvin1cIJ3XNNId5/oPobnuyK77vYNjtm3jTpQsQQ8uDJH5zCd2Suv+8biNuUKWAXkA
dZI+dNX7XtjFxXInzMdcrGXB926AH5RatTpWYoCVBf+ErzRERsHxhWgFCm6Nsp3ebaGQ222DvFkq
PVET9RJfdrbhKi3Q0BluXH3V6IOCgzpm/8MeU9Rjl5/tir1Dn08TWDwgppZ5PESbebykAu2NUbic
/v7iPoU8Tfagd5EuuqIDZYvl8mudlXSqjKXv4nkYjMlMddP3EDyjXX8ny2O0/qBoW/OoA2wM2J7M
XkdvDjb+j3aoE50hCVydHkv4pI80JQBP/+X5jOdCWX0lJxH5n9NZCh/ZS846Cm3eiuRC0WP1PsZN
KTaE5ZBqg8XQrphL827CdCT2t2ct0kLNJJevYlFu5qPP9TEzD32BKjT934RE255oMT//oxARd3xR
VEptWqbKoQ/Cn5Vy8WSISp4TM8dr+h9HzpMVnS7wBf/ub9q70XHUSIKTymL/0SakuqpLggMVl5qC
ELvDEL2/d5psp5PhtVRc4WmLzgzq02n8v+i/TidKy9J6TfPVVjZtFLLhJ9GJgaLoNEOscPiCTtsq
cS7kw3yQtkcH2J62W5jODNKWMFB0BD7aRfTFQ9xBX3dfARkkrhDENMChYRy/y9sgdOALV3d5gblk
3XqoHr1CCSUxKLSb50yucG5Dwz8duwOJKJwapYJEtrd7fUXHi4vcgHau9TLnVUp0K0nBUhRfjLv0
cs1xp2DN2hMWQO+kvL9fmS9256kYDUkcrRQxtNH09lYc2dxy1WeSsuawGuckaN++yizu/yyFP6Xv
PFj/DEPZlDGCS5iw2zT7/VkB+cKY2k/XJRWpsKl57p5zwQ89pxHuTaMpI9uSoMzTbG7A+Ys5StVt
jRMzUZxf/hUVuTKJg7xW5y4O6a5LttkPJ4eOnQ3hJ47+Kp57WV4V1k2Jrccc5GP4NLu4MF/kd7bf
75jfsAj9SfgaiUQsm0BZS26DAT+zIwiC/AzjVMuzqsQn4B63Eb5dCmTvZQi0Y73F/5yp5xte3t+t
xcCU+vSPcUSgVXSJjD2jcAkex7GgfQYkAzT0cC27BwQaIy96AiHlIUImxIxWo8zpwj91eks/O3u0
RC3dBPQfVEs9BZ8FXGUo6UqQ/+MQ1ytEIT5fCqWbl6yFwmWDyi+I2XqwEKh7l+BQeVUtuGU0/id2
5hiS7AXRVeBS2LpSoZqZKomEc4gMIiW9RyuVVO/Fu5YoDo1DFq+TcoAyP8dl2KH9ZgmxFb2QDish
GnV17uSY8VOZ49Np4+gJTpTtd7GtD2CwfTZzwNv7Il2zUP6ngNs+xBZRGx/MXFXq8e8xBCWrMh8x
DRXZTfUQc1x288o9poZprk6SZAQ8o9CbVyqr8+Gf2iVy3ESFMmQJ3pACayNQKmVWSFDCBSnKMacy
uK9GfsGgyKB4qiUayljPxXUZRLpiWLgtZBPA9PKdEUYA1dKOonoowNWZOKkyjM7ka1dDWlE6cpqz
lLP6Asf4Z3JH+WCcEn84Ws71u9hgN5cP2f6MbZ2YiqsOiXjEaWAOvryuPgirunVI7xfwfKzQ9Ds3
dM0EKTcfwFd4hbIkpwwZ3nz0Ahn0EkZotT6KTzZV1osmjpjzY+SS/EPePgB0oNax9fehX1gH7ZB/
OYvSnnx9X+FkyT9uJndmISkgGYEz9dduMiO5io/FmVehhNcSj3sbczMY8n7CrhStPpUjQDWMki83
1EZwzeAFHe6EySDo//vYamVnfkntBC9T1E2m12wcxSJQORcv9jiaU8Rqp1yjV+eQi6niFMOpKgSq
o+FnjQetPzsIjne4D44HDLcOpL8B54I/zzU4IIsMAv5y7iEv3UAVqCnWIuX5iCTdXRqUVlih6Fu1
MtKBOY5QQwIy5Xm0WHPNy72BV/EwX9BNVljzy4uPJUSNmH0ll9DWi8JOkVQ+cM2SB0+NFtw3xllU
kabLSBqABIRGqkBuL78IW9nDwuwUa7pIwbuX6HVbRXAjQBG6Kub1UMoi3MxhUQMCs0saDfasQrvT
c1/AoDe4tkVnwCt9acXd4eOpy+mH6DaZKnik7jumGd3y7jKUT1qePrSrZi8YkKM/sSp1syWSXjd8
FNZjblfp/9dvMfWK26Z+5mqFyN99/rbudie+5mkwUBSBATXCYvLGYBQNePQEOGzYFMDy/19jNM+b
8bEH5CFMKhABQB5DWdm2Mwx0vUwcjoBKZEeBPw/qwYJr0To79uZsmaclPuk0xPz2zhml5v9Wubse
oYS/h8TjXncnkvjm1xuqJAXZ/E15AQmv2+ZAB6CktE0NCtoBOler2NBhSl4Qj4OgAoMMNHC+6aqb
wevRhumAKgK/MGNBgl+uztYZpoteWzHm6hvBOR8rvN64RxRH8CfC7j9AdUkUJnLq7NQtLOu7xMOC
ifjyfuVuuL94MwMvou8EiM3/Bga95XtPte7GtZkKFhAAVqnLBcAgtXqdsEsjZxA4/VhV6aOqSDYp
+F46pMgEEtjCsiSuyguwqcI5tD0wKt7AZsPlc8F/t94sZsvc7C9TrzCc860tqv17pbLRB+TCPXYH
Yr+Sn7JKDemUELOZGp4Te7Cajy3hf/gJS6LVk6caKphDZAaOly8lE6akrqXcEIdACeyzLN0hu5OO
UOefY19SKmMTwHsw8/6LMciYDX5kgCgCb8sywJD6s548TKGpAgxgw40Jfzg8NGWJl8AGi0Ir8+eF
gNxOdO3i58trshQXcZYj6lbOH8jHrIcUo64lxz4anq5f4ghDRukpS+a42gJPsl22tjpQn8kNmLhG
e8t0F/2Sh1ML229xdLP4l6xg/7y7j1+o0tUlsgFOUKMbOKhaYYrPgFaej4eHFxzmhHAYp/BkATdN
nbJsvsQH/Q22g8QvyWevHtU2s3iOWkbe91vTRisCZ2nVoTsK5qTTEMoUEy57WIioPBUaa7TIPBBM
SjOQMRZ/hdXLDyGGVLpMXJW/AFsaPZgjVWHO6rakRruoslZJWdhLBfK3ZsqNiIHPVQqavWC5m08x
K/qU+QdrOzJEigY5zzKi3LaLN8jvwMbxENSbvoa1subBtMpr/j7xo8MqhEcIZPCsU5OgIT06ojOi
BtRATQkOTIVnesSZApZNgUMVl1XfJGhk0J2E6osEYGkEYzeKu/Qx6UQV3SnQHIpW6jWfe8pqUQwl
5ITlGKPmLDSNub6QJriaSw5jyQY2Zd9L9hrNK8ZURVouHl9U/88Sudmq1umBkLFIAZe=