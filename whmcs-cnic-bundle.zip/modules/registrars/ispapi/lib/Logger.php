<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPofCYmhS6N0jcOKUATKKpiwnDrI8I+HYGA2ur0iM428miESvwuZAuk+VzqjF6t9hQ2SdwcxC
uXXJA084lWg2kllJYIGWp/Kbp8N6hcktQqEp6nhKtMA56bAgDkqEYYMzs/+e5Mnq9NpGcrBAt1IW
eUhcjXGkVZVDawNxiUeONMLN/v+1bMybIX4PaVZMq1kuv9ouOp5ZZnRq6He14krCHguHFqcAn7TX
5HHPBjOskwbmDLgc2P51vGGUmqlvkzjfBDercBlKA6H8ahe357dMXSM94zDZ5Zzql0aGB/9/Uaxo
8uSdapXm7ZjsZJ5azRmBXiCTFaLi55YO5eyTPIQ2NUFur9OVRqGGONVsK7pjke8SA7Zd6qK2YrXy
J18oP3Sodefrh9uzZsxP58icFL+f/i5DeWFHh5zE+ITRshOieLo1fV9gg2QAHBVlu6QU2qtl01YQ
6hUdVjbKC1q/t/PWuI3kiHw3p53+hCpMsIJ4Nudeepqi0lQ99uUnVMjWq3HwWksjnjcJEfmDJi5p
vkqIJ0YR4DKmvbw/GoNns98bEew+wK8FDGEA8iXaTDfsE99BBG4hzXBhhhgV1eqgNeTmxo7LisW7
+W/sFcYRAs+4pDKwo3egKEjuAP69NaApvzV01up05DXpMZ5hd5HA/NAWPyVALE7AeSPVA2HzHpS7
BFts8yE/VoL8C+9hKuKVBTEnK2hJFnIdA1k4y9EYtFvmcd4eT1rQNlEDjrAKyBWoeVj2yyhYUHI6
uTO7FpsvuL0hNkhRnNXV0xDB+gy1ZR2HqypQmn6HU6kJF+RsI56Y1xchD7v99oTcBUscgK+z6ONo
AAWL4itVLV6Ia52awrEpPd1Kq8OYJJzwHBGlAnoj6IRWAu0CFbg2q4Hd7A9fuimB3mgKozZ/ht+w
z0JwU87Yx7oRi1PoPgzMFzftrJbid+DB0/4AnTKMytzHeHI2rW7qfaVn+TB8Eqx9io0Sp7y4XwNb
pYlWjzeNUVTiT//iorB6ePrPHCziJ8HMbDMCtMT1jLTjYk4TdXGxcJOSuibqwEAqAbO7jZZc/B58
SodDAl5tVw+xE6/KbI0HIvSqp1qLFJKf9dP/XzYfkYb0o/eM81oTjUYIrTexKAKaTGzSinJbRdy9
eRCb7FroLvYUhi88ruIKWAOMxUJM6xL5W+vZea84oBygdnTCAH+6GXu8Lsck5EuVquavTE7uEyAL
bnhnWv9KTUYUcXy9ta/mQtvVk0fHKOxaNk/lIJSwftu2aX17v0332Uhlm8aeZP6zo/r0XIKJwgK/
ILiwvQiDNv9iFpSGLUvfHBk67comUPi15r4faQr4eO4rxce3pSGR/oGlv4ebaU8s1RYswRB7V8fL
zGO6eUnYk6Vf+F1jGkhDq0pSld80mMcUVMw+4JNx9LyXA7nU8F3jDqRb59rpU/Dj457tFb4UUTnz
1w8F7AJUhYmkZ323wNTM1OPyL156124BXJ9vFWQOy/gBIjW251eMqi/9McW/H2fd4jjZjv2x5E0B
GZiTlqua13xJNUAVmp8qzKm5aFdMwzevNc4tXCfAsvOgQcmcMa8BeA6cYQL0lzWV6aiVVEGGdjah
mK/kyPech9NLg3gVop8RXXADXbw314xETafxlLWZmf9OcI79xAy4dhrHjc9N40cQXgyiS4tslcn4
ocTEdrpJEN+mgo3/PDxMcXJLDzhOhS3K+ggzWBNTPl6ydUqPYWOiDhxh3HPnb4UWPDjMfRHv98YT
KHQFOsA7MO48nJR8tadw+Z1Fi9Re657bcLp6ChTyeZgoDLhm6TFDw0Qzb4sXlt52aonExN+pplmr
qGeko0RWsOGJ5KNCPzrVq+qSIF0DQGP7TdusXaoRcPYuR9BCFxXvv2ktx6DUU4iVt/EkYS2ylUeN
ogkURZywted2eM0leqbcXoycCm3bB42oH5jsoSlCDW0fO11GjtKPcExNAhWs1RDAcuuQAYE4YlR+
MSfGh+m3E+y9SxSoSwDs7bV0PtBMJq10ImYEwnz9GecUp8f+5SdzScyhL96IpWMft3484i53BbmB
BX4F7v6agi20bQI5Cm45mIN6SPl8VMq0AuwbtNAEEsPFT0i92RQ43r7np1Ls80QjXGWNIqh2RiKs
1Z49D8coh7Ewk725sHTNfqncqOjBBZ5eZyYEFRz91y+pce8b+lsI07PENeKwmaJtjr96h48mJ6EP
PoRrfGymfAk+EG+Gg8MP6z9Q2SWOZaYQiLfdeUNP8aiV5p5cPT5g9FxALjhioR2b7xAAyld7CTNj
iKiMi2Y7bdb5G5RwFft6ElB+yMI9iQFCYIMk6oUm9mfLHobhbuFQo2WGFZHlFXa1blRrts3mvyya
t3h2wQbAns5og2Yd8QncPJGcwnencToKgbsjN7n76yNGzWrtUy0eu9YNIZ9GWG4IcL5pu0PJdTUs
s8EMx/BOlQrRpjcTke7eFsZV1/T9rJqz517DnJ4JVHc1EMr2wy41K5hS0jUxZALgTm59lXg4nFXa
28pmjJ8IW3i52OTzAS8iD/h8dNzxpwBWZ3rJmsZndao9T/7/Ksa30RaYc5n1SqIMYd8t/ixXlxtu
7rWWRkmAU1GaBv+tpnKdrClqvBs3gg4ZCODlL320XFZrvDGx7j/CwPT9Qe18Ib6+a/22DSF62Ybt
8VUy54vf+VvfRI9QJJqK7Ue7ZyEzzYGAZQI6ZpCJZ5zJ7F3Sqr496+ZDsmxcFo7pmdiYvxwdbhSA
/VNvOm4mpVLHTZ/XXrMdyuz8RrNYePNl0rqbwPieHc2GlhfntiPHUahiy8pY88sBOJD9bdQmAxkv
/xmVFhyKGQME3bCDfvMJinLtxsDw5wC6yl97elDYm0Aaimtl4Vsqoh5aQUsL181qvB+5pPQfNzzM
eCql0mQFYsqwjacaxY66uNvxdNy8UBYSm7p+THFqf8ndQ3bJqW05Iqm/9NeYAnuXJLZWc1Z7Fq4h
UOyL40w3DZ/6wZxnMcA7+OIrklCbKi5xerFBleDrCWLhdtxki+jTvxB1oRfnXNmEELQ9jj5+igSD
v1tVH4ekG09LzfxWk+UL8MdYaYMSX6HOrpdDUogtFjq2Jdt2cS7Oo21YE7oe8CWQvW0IpIrHDDEX
MJB/FXR9w4uA0BWC8a6R/q0AExya4Le6/OvOie1M329gzOFiPfoLn449/Etz/Uo9han+tcRTolTT
MccaTItWvlDqZ1yXfZU+oR9MS8SCaOYiJkq6XP72UO4pzBKB4PbCVpy6eWgLfIWqkTaexs1O0Sca
/o8M/pexXG9BivtnW1wQLd0NaRqbjdNmC+FPq/MBo+MYVS++KmVjDmdg2gUJbBE8SgmYu3rSGpvZ
m6pop0PIjkwYBtU9lA2fKZgzKeOX+YRnCjZC0RnhdcQhZePhv18CyQxsQwFXfDCO8I5ZNFqukv5T
9fanwKg7PqTyR5aNJ2yQLpGn6KumkqKlJTJyDoJyEMGU9wz63zrJar1o0iq1b7//JX2FHKoqIzTV
lzUTJ6zZTYeRQH5SHW/m20GBJSJnp+smAdwA36HKX6XqKCfzHNL3ia1QtwKhwBQxTiH/Zi1tqiwl
U/iGa9ms9PBGRYLNEmZUXw9mnsUQwhx3nTDUjpQio/xHapyFQCRU4Khh0c8ETUU9455bB1QUPhwO
qCtTNGw3jV4EwlTuKc9QwOqQjezJfVZxU55fslSdeWuGJnLIJQobB2paUzBJCa+kW+ciy/WGJkTG
41eKH/QokZKx7o4Xzlv75kkTIAj56IB4JqyDJ/Q9ShpPbZG4lHqO9XjKKq3U3tdvGSKXoT4XwZv1
6GY2IKOS2HbjyafFfz7hD0JkvESd3qwTGaoXQOjEFOsmZZzbB7hYTw9jFw1RV2PK1SEZlFOFhCiw
QTch0xUP0nvY/LkTcxCad6BC78gFs8kNvsfPSr16gtGAVjxnHrjnPWgf1n/6RtF4fUxx7lsIt2hV
+diNnJ64YZ6xlbBaecEJs/Iqn9WnUMtYy1DZr3XY3qm0gxEw5nrnYr0qfp+Fcg49MIzcbTpLZ2Ok
lGPoIT6qH/Qlj0cp0b/FZ8pJj4Tjnsj74ukbHc36QypCeJTPGajJqToaS0CjY2eJaE03FZrosyZP
bOJF5mqIVALlkbQvgOvv8G3BQ4Wu/UddXH1/hHQISmgTWMS/FlTQROcaOx7ZNj+OT/O3bDWIpNOW
jFE2a+U7YnogrOf3fO5b83tOvg4ombocAqSRbEzUQP5GYfw8OIP6HxwWFqxZg91RVIGQBtbkbwYx
AcFXjWC3ZWjcQE9m7Du7j7uS2Y+fq8/n8H0bUqlnPeZXBQSjtrBlg+zWOnFau94tOSchPgaTjqAi
