<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxED9oLxNfmA0aIo1jxrmPmOHzYuOQUwc/X8cM9RlE2a1qPc5ydh4TwiPfObjLPeVAeMXJOm
pREOwGyviox69nB3evLRvPyIzdJNaeOodSUmzSSciPiZir1y3sHbbcFPgn0LfMykR3/dzE/36lTd
OAtv3GmQdSZ4BlzBL5JbTgeVw6rjm+lyKcvdvEybLGUpJSJobTiaTcoaa/Cwxj7tBzAjIWzpj9ea
7BlYoyvh3XHp9wE0GhSoHna2gVLjtMBsgOMN7n5OmHc7YsTKV51AV9cOMRSVQgd+GdyYnkYjVlGx
JPUd9TPO8A+LmsT3zvczyrmlp1QXsPZDeIvLSkTfrcJIvIFBfSW5FanY0XIejQG9PLE9xFKTir8U
PMZ9TUhZ0i/+YF1BDIAoCPx/5PyxG8DWfk92m+rNmlchGlpM0gazpUFTOPu+PdGdbjAWVS/7GQFd
6JG3S1UkjKKrbNglKGF66VvgYxHF9JVV52GzN6Tk6/XOGOdreVlfMg0hCtsaZiDQbbSbdPGpUrQO
saLiLs8Q6dEkSeZBwAeGVwqBXQjE8CvTOagQ2RgJPHxuYRWBV3ODfZlZw7IhKlTrXMTdA0avXVQl
67fXleabUzn7fqD8paYGX/D4Y0aaPJdMDuJgXxgP5ssrUkPA/z1UkSjXEm+cvwmTlPOQXYIKddyc
K8J8cqE6E2F2CHKpQxfhAa2JBSRHIgVfROpHul9L8wdotNK6C4vu9XszzWPNAKgD06pXNVv22L70
rWBq678Rfq4SHZZ+2lF51FEhcRGMkpNfmYvQyk/BubyrdUnZn8b17SEiN8IqeYFGIN///18efggl
Qt+eRMnm82IxftAvAqo5UbjMVhIjvfHu9FAMJeFwWQEeBBdlE2eHqEmZBI03ytkrYSYpd+BvL0Uv
4H4qckh+vMtRBAdRoPMGoCMLI9mdDEbhXEU/Foxw6HAJpWSb6kttxuIAClYSEnxNeh7d0+PABG22
j95nUSAJycgL2u62ogKrN/amZb54vNS2jYNTO/KQEJOdBDljYpWjK3XKv7L5m6/e5ZFT65uDyh7W
SJAxcz7TqU4jm27z0nTD3lHkYk3QI/xDl8OC6WfAlYgVKDIzNFAp0rHuuC76R6MlFIY10o6N+b7J
EKMEpW9h41zs7Chqg1W9uxa25SPtJZ2Rp+VtvxNdPIm4+OI3Vr6Pm4kOBtwAsZS6wDl/BSM2btHs
OePTvMbsfWzAoIa8zvIIE4P4VCXBBf+5w9K/Lsq0rWW2ThaxSPeFoqQQy+YhBlAoqUg/t4usWQXq
gXZhfbW8YftErPfg9oiUzzFZBirV3RPF+p/nQI23SchNPVGMj4z9MMGOHVyHRJ8sL5+Zpci3Rlhr
KJQNALGQAzXGQo2q2BE5jK6Mfor/CAsWBBAKs0R/sYrma6uVvzqx98NTxTDElgeOAtW3bwgJhWJx
+foe4/MEvdeLMXdJVAKx3hCqXZ7+y3Pb8EOsfZ1fm7mtm0iO1s22WK+Ex1mG1KyitPdAA+EFRNVl
QcMQ5X4Y4zpN6Rcw7r2OzQ5rozaVyFd9Ck5QL1Ir8d03ofOuyJywiwhVSTy6wRSh4CRpue1RBf5v
n1SIyjkOi+LhOu/LsgZm36rNlKurO52x/R15bRSRLBkD5Nbb7JbGiWuVkClJr4Ych91UMN2FrsW3
oP2BgZ7iI6tqIaW8weef4bCBet2sVPRG4Do2S412/lV1T8apVdQkm0ylGZ45l2jdaqxosttutEzk
pCFmzg/EYPf69q2DtOld3/hQaJ+fKhx5x13MrL96szOntD/vcaOD6amH99TivUkp2iOaG3GFe0c9
bqgtOQJWv0yaYK2Y0EJM1u3JYZ5Xku0w88/0W8WWcHZK+hWFxeAfnQZydhz/N/lpYFEcvn+A/rnn
h2StWj9YnTk7jlC6JBoLBXfo1wPsEfks+k47eKwopoVk70Tk2Bdv2OFyh1hW4eBYwa8vZrBd3Hmr
K5ZoHd5MNbMoxJdUmnv1fUhEiHP2KZceJepIds195OmEmk03WpTKMJAcPZxAlW4QDRAjI10GONOK
uPess4SJ6r9dhzpk9P2hLkwEOtE2gvcP4ICeiBrytJDuOBQq+zvF0kUVcWsRbF8Gpq0aanBd7V0w
T91/aFDRaHxZWAG35F/j86eevwdVTW99ehecGnaJlmrAxRQZgNMgTZtlklfqWcP3r0hkTfN2IPNA
3zdsZqaNTKvWtj5+WfSUYSQJxZjvn4PGtGeQmmN/ZocM0xlhPRxf8n+6JKER5hVsJWn/otnPmOX5
RhwvUk1vDqsmHi9UuqJ9nO1RGo19fmkG+yC4lbcOcTcnOfSohWic35ZIPkqZLD5V35UyeZMbFRqZ
Ae8TkT54D3Yt5oyrb7VE6IkAS7rbCEe5s5AgI/yPuURFkcovnwO54HKIXeXuxmp6tQJJMHU4UPyk
8/vGRrsM/MSQW4kSavraRJTrTH8E4jmNImvEk1c5LT2Mab+brVCeq007YtZV6AcASA089Ed/LSfO
zS9D1Aq99WBTBjFEZfZATq7AbyThWf5kUsVJuJY9a7/q3d+vuThGwYHVGgZ92sHzuD/OjwF2NqJF
BOJKOydUCBk8/TRfKE8AwA5M7Q4FzmvpUhmfh/LSmbcCtxHxBaR8HMEJcJYFqtZ76ilCUTPW30xA
zLYAcsHu32YNYrlNspJQk4dYYm4ueJ/5GwwT7vhWKWprX3PQsrJ11Q4btaMKyNwyXm9sOLHMOWHK
7HvqPJ1kPw0IMrxRji6CWJx4zacs+6rG6wsOoY36b5SAuMtegOSRw3VPdQoHYw0qB0Qfe6Opz6EF
59M4ryLmETAGvcaGDy6zmGMCOk4Drg+9oOQfDwm3fSI0iKCuLdFNHM8E9xDPfzW027M70wyw7uHi
+/rfxNKvQQPNARf8XbeYy5XvguDdQDeIBi7xUgFF/XQgnX+hcEBk+sNcucpPGOMndWWFfRrBb0ZE
QCBT4HOCGaW52a+nMM7m7bjt2XhnbBmLQTqTZLn+lPjmWJ/nflqQdAfkwk1U+hY6woGqYosSxqbC
Rhy5L2M+E6d0IOqiypVhGugjl3eGCWEzNzZGzEkGV2oOujygypM9GPxPLoUxtZY86X6gAyN6Y+1s
nnfUxVkPovp8IAkjosE/eSoScUmLlkx7PrDA3IP3ogy2HutpWDlOZyIQlMcrW+qbx0ok9ihqwUuo
qvl/wqQoQ145IHjDPNHPphKbp+H7xnYOoWjTOyeFLNZSnIUiYFESrxF9E+QGX4nGovR0A8YzKIb7
ZECKJhh4+6g9jqNJXi2CQnmADoU7NBmnQWwlO9nRVLikIR3Xw3Vdu49t671dofKCj4GSwlDd9M3V
II8A8Jyi7JLu2XUc96e+SMGDM+9VvIWZjpI6h6YQ4d/SAefSH/GzbIyYWq2kgHeVY6B1r08J9WeK
Q1PsV16X5G1rVHP/UgxnUyvBvfrdzxPTemjOnhuFJ7y3dGyNw4Ctga0jOIFfTg7CGDpARz/mXwj3
c5jbs1ALVWAvKB3hjJ816CEOBFXzcGBg7KeqrJbW1b+qWwVblAVeZEax2vlVfnumKZwOvKYz2mE7
D8A6B8lx02tWHqDrtYp2un2pAN3rYo6dpHrBEIh/cH/f88qWsnefJiS+dqDsgfrjgwBC1ttfPCbs
xGfODqzFomqQtQxWLv9O1g188uzbQvJ0xBKZL9xfcffabM3WYXGwRaL0gIPBT/Xq7iFKBr2ByVkU
nXXVe9Qpj8XF6XSRXtgj9z2xsPeHyLju16SREMs6VGBO+ZCSKvFD0njPdxDInTyw7izjvOyYpRTD
xczM0z+k+gEVxbPxp6zbO3fLc/XouNcuR0jY8OHAFPz7js3ma4eAixhDj2eib3udq9cd7XZlp6wY
Lr3zHNuSIHriLZHp6+U8KXHwY8lNc1HvJ5DQFTLr94w3c/Duf3Unbcex+dK7M0dSieynVm9w9dTW
8GAJ+jZguWH1DzGTM/lY2aZEvfREIXqPZM3eFTlUPvbXO5+OYXqZMoCKzFOVWtwPJjzTy8jP3B/B
V0h497S0iJFzGcpT/Q5ejrhu5M88xeNnCRrpArlkhu0jhqM2ZmgV7pGg34Ixo17UjKR1E0N3TPkp
9kC2W+yIjuSsMzfCwy0gFbsMMH+20zFQgOAezvPIn+PuTKIQxVd+BdkzTzuFqI2X3MlQGKveqcWV
t6HEeKIPRQA5hJ++4r1DdgMff+soSYzSdty9FywuvQFSaHnpTMFuSR0TVWhmez0MlKKflZJpUgaV
Anw5M58aqskbXX23hW3dTQRpk19mXa8+O+VdaDa/Oyp/0V2+cCFeVFykdx78+fBt4T9kuSD+l5hF
14i=