<?php

#declare(strict_types=1);

/**
 * WHMCS\Module\Registrar\Ispapi
 * Copyright © CentralNic Group PLC
 */

namespace WHMCS\Module\Registrar\Ispapi;

require ROOTDIR . "/resources/cnic/vendor/autoload.php";

/**
 * Logger Class
 *
 * @package WHMCS\Module\Registrar\Ispapi
 */

class Logger implements \CNIC\LoggerInterface
{
    private $additionalData;

    public function __construct($data = [])
    {
        $this->additionalData = $data;
    }

    /**
     * output/log given data
     */
    public function log(string $post, $r, $error = null): void
    {
        if (function_exists("logModuleCall")) {
            // fallback to command name, if we can't identify ispapi method used
            $cmd = $r->getCommand();
            $action = $cmd["COMMAND"];
            $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS | DEBUG_BACKTRACE_PROVIDE_OBJECT);
            do {
                $t = array_shift($trace);
                if (
                    preg_match("/^ispapi_(.+)$/i", $t["function"], $m)
                    && $m[1] !== "call"
                ) {
                    $action = $m[1];
                }
            } while (!empty($trace));

            logModuleCall(
                $this->additionalData["module"],
                $action,
                $r->getCommandPlain() . "\n" . $post,
                ($error ? $error . "\n\n" : "") . $r->getPlain(),
                "",
                hideDataFromLog($cmd, $post)
            );
        }
    }
}
