<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrzjmgNl/ZQAzgHNXgEMveNsWOumIWVppQAu3ojIicop8XEIxZlcsG0vQWBgMPmpmqZXAvZ4
DrcNop2b532Q2HaNUDN6gU+Vv7mly+9FGtU54GKH0bAiuZ0WReoLjoWabfOFjv67o9PNvUcgfi93
XyUo8i9NL2w8G0F7x+3jahawlk1kyQpZrkuCtnipVW5+qwcapsTQ3AxYpWFDcOGGbIwV8RTCMhhI
tlIPu4IAeM6BEb208wFNBpJhFVfh4mw8UC2ZMFfkl3Z78Es38Wkf2AQJCdTgApVnyUnUPnweR4gH
DUT+lbLGeWtkLgKm/o6S5QqLuWxyEtMoHLkLQpuuAAbd4j06JCmlapNPpyCDKKjwOZ/K/6K4HxQk
ER/+rqttfMgxgR4oz0kjyUTsRAoE/nQxq5DfAsVmrQPq9Wgnqam42w216qg/ZDWqar7g7C/xDMob
UmlYoln+IgqnYIxnNZqWncqdPhY94qtYU/rH1ahvrkzJ6Kripl164dFbf7ULRMSqG0DPC1hZXRb6
CdZ3GJG5UEhO73RowBV8P3wNqH9ryCwUbZb02sCUnfEqAy3GBMnp5yK4t1xjhWbvI3eRZacVDspt
VXGSKgWGnsNPP4x/EvOTw2lH+ffKTm8ThszZ183ADWXAo2nta5sAC8tSYuXikJzF6JdNjSk5ovFl
N7ynrTeQYtAIjqhRSROAfnYJvtoDcd9062Nw1K7N27EJrtWgw3CJedDfzqUomfM5OeY+x/Dqa0iH
10LXcA0tASLa+wR+6lPwmszOceBEaN0sk0wNCQZrCjWA0PcuXtln0wECLZuX2bLYdQuAn8HOUUVh
2iQdreL6PvfAlZcS80xs0nlArgNcdXjlHN1P1rcD0BmRlyI0i3DwktLVYcxqbhg0To0wEyCE4o9W
tjhB/4OgTNfUtFigg0Rs4V0Lw6cc2kc8IgTbks7+scvOKXd8BuzlEmkDp92VSkfFSBO62vjLHnCZ
K3A0qSYzPdOBApydviYqzdDuEnyNRdmPB4LJcf7u1tQcZcFN1ObxieC5QpZtlAHo+zypc/noLdlM
+wXuEsXvmjsEGlX1pL4h5pI+0yOQMZ35rFsqnS8nHaMe5HiYR1c6rHN/pP8SjgcJgQMFB51bT5pW
VeLizJ8gTEIPCNeEKdLj8tjG179yOEIGYVxPajePY32/vQiwFnXHVqvQOTo2kY/ayX3ESGkB6Y9Y
x602KM9c/SaOcHm+iCzhV2vGFm8IbtFHUG1hB85M8XhU6rvuUbwW9lldKT9VuFFqOwjvCmuMK3UR
6w1V4QvYhR65lh14TuQidoYhFKezK9tLPrhbcgWuy3HdetuWokqXaUjCPwUluJhqyOfzL/iKTpwS
euxyT2UD/q+uqOaS7gEX4+P0xtCZ/Y8MU1Te1P0/fhDgJaiT8FB940DPN8t2pshlG60AK76wO0fI
SBG8qOz0NPDgY/u4qqCHZcGGSl5wXnGwj5uGwhncxG7w+bG263V5drQ7IoDxMPsnFP5aoi8iLhVp
LGp/bFrKMhGPX4q02kvpN6TQUrPO1Zy0Xbgatcjb2FYxOClJZ3wFc3I9gNJ42wUXqPH8tJS3HEo+
nP7QET+ljUENzQCdC03mgeub75w8ctzlym/U9yiHySWLQ4gjgaoQhfIF3ooAGXSoqiqF/Korx8ue
tN+dN67m3+77lRQptek9/2baBpXG6vS5HuEeSptBMdHynqZTl3A2JX/G2PelIKJDgbwFPMwlbzwh
kZvkFhoA0Iq6YsdyQnFUpfPXEIrdgOpBdZfL9/5aOTSN6u0gpxVnOjG9jHfSV4av3v28T4NMd8JX
Sxz8Us1VatpPAvbKh/r9Yd3lf1ENPun+Lo/jjMCo9IM6dLj6vYLRxOUzxvIbBZHbNkFKSlPL6LpU
wKzXOuRh08c58e1/nqWu3+S9oyVWXopNK5B3OmnAYbBy6A4entwvUq/pZYrhJKNdR5GM5lm822Xd
1lHXoEwE/+XEsuza4ez54gw6wDPa2Si7L7NXW1CjoGKYtlL/p4iiiPsYyH2OOZA7mUT8oO1cqdDz
NIpjglDn92M1MuUj4fGZtjE5HS7h774dhzMpblEjON+0EpNQQ+VcVkqxYBjveiCfLuyChVSWW5Pu
nW/rBE3yUyfFQNk7gqqG1CMbDj5jfBzzuAdkqw6C3F6oNZa014qh3SC81CQ91VUeVST9WDzTHedz
cTWmrR8f0iKqoZgDKoAxbmytf11V19XR5488ubtkuSERit9teZsCR+Opk3IGALikZxhkTBWFT5mQ
m/YGKJirvwSUK4tTLol3c4VFtKKffHJLJdPxRHTXO3yAG+NOhT9DetFCRJS0tJHj2S37UcsJg968
zRlOq//uFTlmj75Ol472ZMRKOZvgi+BnLPxeoAil5UEQ+ozGnAoG+djm/mazyunqIBXc4UL80T7m
fE+NPN/BmX6yzxmo92fdrHTVBqD/2pBVY4PaHEYRvSxN0ONGO5McPCr25DncT8T8ms+bG/2KeK/G
GhItfDXPDMVceQdWUZGwaBjUAKce4A3BQOXCCYWc4Sb0rPx0VqS9EAW9JCCncdlSanVWjQGxE7ov
aNNa4qupProeCaOpBIPP/a3POdLIrvUJyNOD9LQggnfPJyR4OAEsNI0kd4ixHcNVLCtgS20kT97m
5Ocb+PPK6LDL9EoaK+E6QdoYQLMUaDOtrzuWOI3CbDjJJF1AW6X6ri1jnrVly1tdti1eUmNjvZkA
8tK3o/j1WUKD9F/LlbzTvxvIPT/Rhd92D37CyZXXWp4w+1n/WXEv5K9HElUkFenYUSaLqPgLuA8t
/I32SAz6kJFmLB5YH7aS2DmCZ6vt8K7gh19OUoJ+97NVmQ52+ZrDkcMxWraEY65ihaMXduWoeRKR
wLR2sMu/es9mxF0SCRuKcVop5LjUUFEVnZttQjNgi6CRYVaq+uaVtIe9H9Cv1Kw8Wp2ISHCtNF8c
KcqI2d2DHzE9X0QHKEAgzUPZ0wUka69mgKoPRLQOsOidgbQkOLIm0dnDCdiaX9u+oakDt0Irio98
h48lBx7fjiWhY/hIANTGb+5d+ZjShhzwCQJMLrgT63JtCJMnciLqpqm+KNfCFGnpX4VbqwB+XpQQ
YFYTNYbAHgktte1ebBoHG6Icw19U47OCd1yRmr9cntAyJIM+XMeYGBXBNmfoc+PVaIQqnTlZ10Jr
hYCXojEHt6x1dO488YsIpzhvi6eO0UE9H6LEKZf9YNgoAglkgFn9reWpY0GkJwQcCO6yg9IWLm8i
vbPOjgFNdVdRWxBJ/o4na3aSuLOXUo/4kLjhgEct+fB8/Vb4ouoyPd8ZNxmchD99XHuRMD+TSmkm
VU5WJ/IzySEmiJRQWuvDzre+R1XQGw8aLIFFvshIWeWz9nEefDjpItcVQc8vcKu/00ikVYWlAAB6
lwy8+pJY7IvhUG7XrU58/SJNx3A//raKsEC5/w+qQMAX830kX1cnWPl2WVRBaz2/u1kmRgBwnoIX
lJNhR5e9cmPjk62sMuGxhDLlDQHWFLcagYPprOisuN7hr70BPNjhDTSt02RhuBdL1uZnaGzSbMwK
TLbbr8KHyKzCzhXKl8XC/a2VOfXkrWEUvLtex8IMvL3QNiycvjfJxgmI3qrgwWdjlbb6MrwHr+5W
UyuIS2F1KnmemgOPk8YOHvCYyGi6gEOEWYaC3w/W4m9MJa771WvxthylILzMfKjz/Er77DAVGPyN
R9hg6Z0NWOERuS824hEQZOrsqfDZssw+ghfDk3USD2uc9C3u3aqfDi95tTNQgs+4rwhvov26apDF
1+ueiJNrZThWqJB3/BCsgi3+TFOH+y8eQDKMntX4LFxNRB1zAUZNPKmNH7miydGRjkmPpuefKCuV
MLLT5iqq8cXZlofT1d97C375y+s7GvDM7QHtQTnwkGkkzAnej7dedZZoB068l+CVjdPK8v40fTd/
zE2qtqwkl5r4v2ub/f1RL0DmZGiatifKo2xIPgX1l0SgeaGTrNAmxtjCdsvEZxwjGGkEN/cbl0k8
A+9bdCpCmofPkttfGhn6e5mZZF0b/Fm3NmXz8VfaOQLCofO2efcHzSSfxj/pTQP2kIXFMYR0qLOi
bug3ezybL1h/DnxjDNzFPqaxzfq78Wf91jjIIpX4oKWLNOqL7NYdZZZmouEAb+ZN+E5oYy+L90EI
S+Mw65+tHg9fvcJcC6j7IzTU9kgBkB9aNWaUOrLAnupjoou+uNiu5WdKmoOkZtfqS8QvWE8/UNU3
hXYUSyzwpd995U+4iI1RnuqBnKooGVoeVhk2qLa9uRFST6/EO926IVBwp3qlL+nDL0DvcYuO+TTv
so608bMiLCl+Um==