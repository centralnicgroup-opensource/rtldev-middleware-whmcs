<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPujDDqug7enXCuIYRLMGk3O+PPl63O9pyiK9RL1rZJYXUkp+w0zEg1nGMbHn/f12Jn9htigj
dk8hmEMvTSmakiFYKEu1VwO0c4KGGm5lLEBkuxEMoQevZzBlY1mFC2zxG68bE12AgAXGhTBonOio
HSuxA+Z/N9qfy3Q25h9aIQIfxGa8OWQfVwkwqveDVKj7Vo+gYsU0y+224PFtvFn5NQQ4t2Fj87mf
zJGnKuGE7mG9gB8aVqR2iXnz6hq+SfF3Xlh7gCaUhFE8wjCb0dk61sISd4jQVcOhPBxIADonQ26Y
s5TZPqHqbscKiJJMt9kwOJ+XBTYNxBwea7BKtL2FUdSZyL/+b09Xc0J4j10xY6rjlKtd3FJo9v1g
8hEQfN7QGSUz2T5x1hygsUcKhdFM+HmPXWFOgHXUUq6mnUE6hWLxPjQF08gD5oUCKwNCvJDnT+Lo
sjk8OWmt6II4mrEApfCn0+hO678skwxFibH1i3EDqrirb3lpM+ZkrAzRkuu0tXn9uZxzcI6vNFCI
H34nhwhnW/sk2rTpVrf97o5p/zA7MDXcOxxS3I4okM+GkcC6e05yoZ1+w1FecY32yU2RX+GnDYte
bHsrSVaAXenYc9qr9nb2tUaV6L9vFUB4LSoV6Litowyl3KWOVly/f/3P11LMhPHqCHpnOn+QED/E
IzhqVZj1k3thr4Um3ckUqIkOsKy/Km6AumYWPuL+AKl1GcP1mgyaKzjMjf9rw5Y1hrfl5xqL4sIC
zd8nCtCUYfGraoN4hHrCeVWUb35OvPYsP/whvKCv9mBE+YArq03FBqY+j7zACbF43mwZ/Dcm0QF/
PeeJZc08B2Fw3LAJZyb0cNcW83eHSpXNhHz0lvIQ6AoWA/8b+IQJkk+vs5TzB3SpZXinAhYYItal
ZXnEBTJkgH/mvleH2y+ryjG8WAyNv4M2fUm4CiWn2NFFLze8ZnXjYnsm+DgvuwW1brkgolx2O6bi
qIzujE70SSL9NnUuQvJeb+EAuCVUgdVOOaCBizc8IfNYXmP+BksE0kRDP0nX+9+7OWgAoskiYFpB
vxAooswxuhu7ZkHzA+yqWXPUUH3ZPjxL55L3ltVIy2VcNzp9cmtYemgunNKDUC2vYHWXdz5DRlE8
j4lp24jjqmbHRiaBxz0I/D/SakF5R79HOj/dFkPjKtrs73f0AAm6h1/iJnqdSE+lu4cHvdhLe7rv
iuIdy9O+LMiaBlQFpJA0a4tKD0R2XbN22Csx5B+8W0DUTx1LKU/rjXEDgGgkbNz5j645zBy2PUjH
r0t60o1InprvSdb9kETh7J7cSp+A1qUJSaGhn11J6raQx9r3cyVOBs3/xy0nW+Ax2XxR8uecin2Y
xI6dJBXd9/WImTkfYb+wmDNJTPtBxxfV9Bl3xGZsqepSL+aMu1XXKb9dtV3R6JU4MZ2Yp92m5jvi
IAkG0OIAQJJzIGd/RudNh/KHY4xZByrIlyb3eraC7f8VrCu1NgOYVL8kDVC2+qIkradTMMNo6Na2
XfOWtuCd9cKOQ2Wb9ht9ZFcvl9LrRnaGEFhobqRLzMf21dCYJHIw1Xa88v4Cn7PDdiTkkiUfHhHh
9PxQmVaEwUdgbB3IouO2yI5USyE4L4q4DL6eqewJveqvhFloIZvIpRhEdJfsGqVMYwaN3qcje/A0
J+GcHqpPBBLcO5Pt9//uDxWBP/GOi25MtzSpXHYI1H4Mubyme0+8vu+Wd9jOHxY7++qz0eCL7FfO
aXTP4b9bEis71hqMRLnJNcBZOdEbET5HWM5Ozy/CX7tIYNCWZVsUy/Zgm48Qn0Wbw++kl1+jnQxl
/JARs288hvXz3BHSwmqLLBgvqR9FwhEj9wtUGLdwm1E4PCt9Ydp+sgO8SB6saIYcv9VVDLBbGuFA
UCHYmtBZbOOORpWRLgjV56xKw8SxRljm+yNqW6VshJWrf0WAc+KJQNEc6Zu5TBNRbLgV8rwd3N3v
reWcxQZ4KexbnyfWwNL77H8FMfEJQtTd+t5PXLQpPyo1IO4HGGILV0ii/pIRu4Pk975Wg9iODTci
vrClgdXnC7wygGlUM3j8BWIT+/RSLuNROo2PPsOlsVtOlju5wnwDNbjSnMRVABQ4OYjdEjPzGn6A
gC5Rsw3VxC8XLlg/deBDq1/GEMWtp1kBbaOCHdLx+9VsfVr4u1eG5YzeOUVsMXFtnY3UxGBvCoZ9
46fO9bXIwwqjaTI1jHMNhzceES/T2jYN39VaXTPr+RqdYTLVPOjwufXVKDr09mIj0QXLRsT2Ml5l
eJireNyGbUVoM96IiCUm/IJkRetz6KTstnMVbYc0dpFbaFt+iRpacX+8+7wuSI5upxqqyttMSv/d
c+5nma+1XcRbLptKTMp//hKtC+uRgrLCXnM/SC+xXXbnsJRkA/tQq+IUiMoRcOEiQh1VFsfHVdW+
ouBiJDfLNXPXMWASSmyQq+d91V4Ha6XI2g/hBaguJHQMHGfoYYSRM9+O2PhQJxRMzBSwiahKAFu7
HBa/1c1lrqpaDIqQcG7KuOPOqkhIH51srUEoyETRAQIxh17u2WbGwnVnoeNS+rZz4rUBlkoORYDQ
QvIqm08nTX3NIEUerUnAewP8tVLph5giqB/Es+Lbbbt7PrVV6dPaXQZhWARakZcsNN3RzRFbZRRb
fIOuyJgxMmjL9LNtllOsM0T2idm8nsvvDjHdI2DEdQLYTwnWS+HVbbf3Kv7MMiW52oikxqFq7K1B
hX7KimRhrI4Wt1gi6w4uNsGpRRm7A29H3/8hc9pxtU87UI24w6Wrjv3oXCTocZuISxKt3NTJ6Iik
gyN49+/CBhaOnIGr9UsD9GeXbPd8sGvugQuipc65uS6wrTNCS+DDSCPHVxxUWd+ClntlQIc+xauV
JBtwJjw814f1Rp/uSkkl+4Eca/ub8qKpbS3+AA8zx4FCUT47HuTIjwsk/1sU9xgqPMcGgLbp/jdo
XPSLBvZsTbCbDAMkTsX8HyCtBz5AEy7ayUyTBukt5E3wvQFeoMMnWEHQe0DPiMeKXyvKbUf26Qmn
39fAamdRKNfBljR+ZhdQLccpsPH9jAOQmWAEtYKsw5SwHGZMi+aVsr24OAE4M5NpygyuMCPv1mBy
OsUpYKDdJYNO3vQfC6FCQSpLBh4nYw5CZ9cyMjilvNJ1bW19joA8p6ZNosM0nxUQPDsBfmjrhvpB
ri3NX5HDjbPrDI4wFQjeUZM0GCcwyhpsyqPYpOtQd16+MLt85Nk5btsABdB7mjjijtk+ukSMREds
lOuox5oOzf0oOqn13Yx0xj15VaD94+w4GMmPpOj1F/0+jDRXi+B5njpXwr9Hxog3cYgOAZ87Ovm0
/FAug9Ag8JELxw7+hN1fFNsiwPjTa0fyEusGLcN6krZxEvQ+ykzQOtx1L8BmFx3kh5/fguYoMKAg
xlWvowNJ8sCOIH9rHETRMkUyEib8YVvZqG3nqa8EqtwweQyt3zpsgaRmRxwj0EKfG5Sz92H5zK9j
6MNLFleVf806lbd2/tjry9vtCrBn08GAwgmHnSgFcD8zOvluES3FA/D9YN9Uxy0Y9dpQgRml/9aj
qDZ90lL2lpQnmUtI5cqLYyCXtYorfE7MNzc+kn2A7AcZZEOMjYcyKKLaaFI3kZRycylNXU23YuaX
8iC6ycZSt2cZr2uaaYrcyVVv7ErX1MeniZF1VvT0qidHxSX0cUnrC/EyZSr8wDfDNHbMswn2y7GK
xgeLnZN2PhvtRB1IeRzl6tbjOV6Q6MWW0A+opA0XFxEET5R/yxTBp2+DmSaUiCzUqFFLuUeSOJHm
0BqsUFKC2GXrjuckQnedmRiMAa6xizYiAI1u/x44zqgGD4v2tJsTdy8V1N64nL5hQkY0bGiEntfK
klTD02pdLAyTXTlYeV7TfuGB5js3BwvU48MaWEDjWLUjpubzIUrjwdNK1sCEX+EfWnkfwcstn2ql
WTQ33u+u+l3YNBD5zqTcqDDmJ8jiR4avrnnwzi+C/SfwQvLVr7DaSW2prLs2LOd+J/DBlSF/yYlU
bOJeXoQzeXxQ+zJSBMC8v/cDSi83oa0Yor1zb0vE+xIQorwNAp04FGIYuhp5NJeXJDhTW3doUHV/
UjiPZ5AqOmk+YexITUjB1b8uVOEGUXypNkhTwaehPFGldIDA00ZANj/+bLklg2oLYnhZwnwdsdic
PUAT4DvXrdOYlvM1CMVJwihoOrRhgkcjr/YJZWh+V5w+tuzK7oD4vApoq1sqvEZ9liuUDjdOTn2j
T+VlmjCxN9oFiHHdHnGPKoXiDb6hs/ELb/c13jNqvY3QaXpdf5VlJFNztYo/k0e7Flu=