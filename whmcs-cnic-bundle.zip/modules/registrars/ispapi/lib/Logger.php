<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/OINZvYjw8nUzlB7V1qexO3rbyFbAP5Eymed6ogPSZNGPAqQMICDr9DgjjN/zaspFklWZ/j
VQAfCs+aCBB+2CtHJhAF/XUw1lg7tYQFOADXVghTR56SJaaVG7hiXbuF3iWQyke7YA3wt7Ka1ZUg
q9LLPZFdaS6tAjs8DQu48weAI+q7enLosjplu8uHH06ew5q15uTr8uPDoWmKAlfSmL9XQiYOq0GH
ws2MEQ8zzV1X7cIVhlL9qicFK27kIEJuCiUvH3cUmGR5TtnuCaEknTiC+jt2QgzUYu1JbofuE9VF
XwZdNdvJuhde1kU2eYbZ88lc9XV0wrkSY0aMcLNeiUVR8wZgmV5zAmoS2Gw3tyRWVVNtzELpN2kJ
LtoQril+sSDPEcE9hHqOPRVZrfiGjyt2ujIJnyREmMWE5kQ5ZLBOA3d6Q0p+egpBeOUZmfK8A2Uw
CixNJOM/2P9CJiHkGMvpT9wUxHQ0z9/OdepeoRQAcmXA3MCJiV9tltVH4S6JCkGbZRH/ytugKd72
wypWSoGegfQQuXJtEHKR5ftLbvTcvLUWv/Ibx9Qwc4d05xQXr0GVoO8UkyVhJ9fAwRlS5vyHvQCG
6ZdkGKC7pLikOufs/YozFvSq2XPo9kWBU1upGLEtASUwnFiB/o3dUD/MS9b/lRnfZAzgraFsHFtW
JFVIUqSGTxZyfMjWt34nnGd4AtwRzbA9wVta61zJY8OOAAQYYmlcAO/6VmRv+CdKEwjBa3uKtDfw
Prc+c6VGBrmkh6O60IsmuQ0VZUmGu3sB14s8ifb957UjIpyVFroe7c9wb7vPGabcu0o3k7+4NxsZ
kY7UQWrzykai2P0wuyaMA7ddLwqe4tn7dsbwa9ZqjxZPj5XHZ9hs4pR1HrllqXOE0Obi/E45SAhC
P6fBQ/LtiCJhODqf+ufeQgzAT53K/6oU5n6EZP3opKSPQltf8ype/sIpBfCAMt/fQNahHPJBUlQE
+FdpdXDd03F/L86TZZdqNNmBxdcYRucZdoEZVhbv33ZmyFUHIChbQrt9qADBuBFZB+suoEfQE/DX
4oaRq49sfbZnGan6piX/BL9ptVrZW0L9rKNgh/4LWlNujTPjJpK2y/p1aKWVoDKwYBl2OE34v6Af
Z25MVm0ZuE35yM1rbT6I2Ut/JQkkU3VayFGzzohuQrnfmdXAMYfU7Rem+WACUWsGCo030hr2Et+d
p7lEuemGH3Ps6aHrId+k85TpwM6Gdi6e8O0c7qBkIbqKnV5PwYVt0ZiOntdg5xXIhBr1J+n7U5Tk
SL+5CXLdnbLo+A5qDzsHPVYACGFSMDWdjMGu35TQpXmqsqI7J/wkWXRu9MzVxfChjECTA9GfETYT
bDqEemrVx/cwcCHQxL1p9BsD1PUK0x5xydlu0pHyIgrD8qkrKkVPo2KfXpI1ZTqoquFgLYYQE86Q
uuRwH9IvuY3SN1maeiRhG4WMta74IyVln4bK05mZ+hSND+bApGks04FYzwtX+A1Bg1YTcgiIQZWt
tJIWQsJrd0gLEX0xavRqrFxvbL9cYtGSuiP+brbg9VOdjjFDHKg0dh+rX1RIBo7lBHQ/ytwxq4IH
gcj7gAjEPgjL9shFBrqb+lvoyNYwqU7X84oWzxSY5HS6YpBockUwvoBAHj6FlGDCEAAB1hn3EagO
KIzFau+MbeyHUF+uZnlUKNbhFw6R1UCck07Rd2houNJv3UuhiJKJzzO/P5kXsMWqMox2sBZWtdY+
oSnYy/ibqTSB2SQLpt6fM3NMQJCnSt03MzFXGRZ1VZhOhyidoTrBYHXffXnxdUrPCVMyMNgzMoKd
9Uxim7LaaPwv4HoX0vXRmEuJNaiVUOfVWMHeoLx2P9WNxgmp08Tnykzp5mIj9T8rKipLWoRXlcXI
r/27Rc1urEzkxIOTcFMFAJ6SVWlvWhGY0+yTPBRGefySas47XwH5E5f/I79mhBei8v0+JNJ/kPko
miljzQoKAH2CbpB2hPMymUzpcIsOAY5MaJ1wxb1scux680p/vXaK/tZqtrLQigPIYCSwDpdHmweu
fHvWmA8zhlL03nbdEFc0aZvBbNBVmmp1d3y1tx3ADIgFDGgHvCbBJ5fepabBp9EH8quQmfo0ynRT
As8fM8WsnX0sYX0mj78H43Zjv5cza8EMdUdbr7UShCSI6zvDagXsyr7qmXKIY7H1/lpOSbSUxyRb
c5LC3e1dfNW9svjpXpSxdePa3/aHrxk/+VQ58rWYsdPHumt/D7h9zfzXH3vKSLYxPoAXDwip27iI
XbJ+4+SxdQ43FvWA9R+xW43syzlUrjDjLvPGwPkOlrgC2m0FyFPtfgQjTSYfqNw5jAJS6gSS1/BG
RhRZFMiskAhZR2h/zGgUyXrKwVIny50Dq1hTN1pXlp0sbAIOI/Wr5K5Bcz/PL1xdw6yDC9Leyw/2
GVvKZJCO5F+IT5i05eKh4mAnj+hs96wUrxfbWpiBNyyO4hioqCUtsqRpvEfHDZ6gKjp86CS+jD5L
z00KPZj+qj7+/ONuyOJcdBYLOvPDdk9u7YRnY5o4rNdLrseQrMFeTsYzGkSWWWNt+eX8wWGAHSwP
VnHuLuIW8/WEUPq1wMtEVPSpDFBviIUbhHt337SoaSVlcKQL8R/5z2rjGGEdq4TXgpDgWjTd8HJv
uQvMwTLKnaZm4dlo+CvTMSIQ6+CddG0Nu022O8Qw28Avi0qmSNlaQEL2avGkaybvQD7oUS98VsHB
KlThCfp/e51yWr1N4e5fztKvyCzdy3QeFTgwuHHiHTMUHJN8B84Se6jL8/vzD5i+tpVjIGhoQUW2
4eCA7ThDZuW4Qk3Bh+Bw8Ppb7Se9O4W0DcX30ie7eoua6iMop9f/8GJy2QNzPbjNTrc880kIDcyB
dGr8rxtAVQpPR9FYiDkXoZZUCAWHoABRrpHJErsC0nMLj7J1taoRR1NiWQF8HRKbmK6wlhX2Xn9e
jKjIK3fH4AL8tgQciRSYHMJ+W3OH81/RaJ/wltJkgXmzo0MfqhXQm+vFYDLT6GK46WurM+UJU1Yk
suvMVla1kXgTBv1ZKTWh/qRkvDt2CAOqxmBoz1JzsMqwnIP3PhmSt4yO6rNA35fg4YjVyoMbgH3O
YhsqjquHOYmTsz/SLVr+KtS6v4oQBwxAh7U5HU+1ZHVVXjcRhSTuj1AuP3htt2u1orppCvDX47dC
GrqWU/0zHdZ170AUyhYPROZ3y8STJVwMkWNzWotx9eZJm3GfnuoGS/QI4XK+zMfCZbmNgGA3JXCa
s6R8CsNLGeX9gsv7/3P4GDmm7bWSU3+E4FHnJuUd/rL/MLpY4bKFaBIAdWbvoRTdexx7uP4vRyEu
cmlepV0L83lj+p5ST9pQS5wko72+xH5ujcE+t9y+rYdJ5hWIcM5DGAHO6XZ/oTydvZ2mad2Arajl
gNaixIFjtknCiDIVDpTuscLUFiLSzbdGm3swLDVT8HmVKa1JSo1t3lFm7sRzr5ROARPYjKl9e6Ah
zTJitnQGbSU3PcBrZOtQncdaW1isgKdJgB4CWXYZaK6oWlhqW/2Bi5fqWcyuLUOlDfw11tuYaNRm
6d8P+N63sPoZesZTTcmdR7/ExEkwW6zh+flkL+mwM5E7gSL5kNc+1QDeZyui3OzvHJNqtjQLVXk4
c0M0oHZmTQwPXhTeqglZYMKkiV+TvNdFz7Zpud4uCpa/DK10d1YWaCw4GgjnRcTr0sncxj/mB0ZM
OaQm+cgekeQXtMFMdFmnUQyFIuafZlXHaj2hy6S1CjxD5rFPd+X/BMSxyRFYw7hcHiocGtcOEOr9
qSiQa1wJruMUDm8ehXmWNnkKqJXjRS7+htofh82gQeqxurI6UxHZ5IdD81wguzeE8H7FXAJKHtg+
mum+60t5IYZjpJ5qQMVuZHMSyPz+TGXYOYAvyr2RceJryIRrBor2foCe1vdPFNWWksPTv+inZkSH
pNzfFzdy9OVgZmxi409E1ARe5yEbcIPNJq6TWfo3RT3ZnLLLy5lJn16nlHeFLFAlYBpx7TFKgGU7
WQme03MP64J2qbVe/HnEwseish+0LekAkKLBusnIB0+zSKLeNWfNuCfF5OP3MWmIb3VvhtXTq9IF
WTel9LIlEGOswVLzLvLXD5N3n8ICiSdzNLEv60u1j252K8WzqSnhO1B8fx6eJASfR3NZYLsTMM/R
W6UFHyqEdFMeZzuqqsy4MOj6VHMyq35GYUGhioBcnH+rPGW7nDIsmi8NpQVFFaDmkDj2NDC84ov+
WgK4bM0ZpRawmxY6UUjWhd+0PjxriGs66EIx8kaYHm==