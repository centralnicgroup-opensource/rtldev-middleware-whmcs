<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvdo1VigL/xyCpkGs7doclheQbaXAazWvC913l7h/Ej8CkA+eegSYPtB7R5n2eDqlxYfNkso
4w2l8EkCxsoFkH5b8+zb1n2mnB8KzPspriHCt9LqjXjl2ANFL42STZZNyfwwQIhzZ9HlLutUB1+g
FtuGZ6/cfRzmlaRq54zRoxVKEHCKpfc4rBtwQN1NudeiWdAWCGbGrZLp5hwsbVH1LU39qeQdB2RM
RBfxqP2gb/1uci7ymzqiXoJUq4gKzx3RBH1RCqO8mTjzu9dQ+Ayc/LkAgDzdSwYMqof06Ty1zj3S
zec7KmpoQVc4Bxj+qTC2sk2J95b+43h2TRfanUFNvLglrWTfX0AtmFttXDiebcqAmd0e0wyrHaqi
k7B4fTHZdrHHlUecaQ4ro1RwFSAyGxELLfkFRDzgui/2OLaLNsSHn2LeHkS6MIDrNXzJAzsju34T
H4vBpJuMT8+K1nJq1JLklDa6ML3r69Aaoy1UNv5jAwU0cGmnSq93SaKkJKItPLFfkHPp/d2Kdk74
WAK6ZmmbdaKI7zhNMReFJcb9QPxwLj4wEscVKMwbbdIQwKmjodraZ0F5xCKpVWphsQVwS4hCRFNz
2tGZb70anaXx05U0ycf3lXkY2IJEHZsIFYbO0nMOykHZAinFzID70wyzGOV39/k2Z/h7/SERqsv1
eMjbmH2Z06ypfE/d5e66u7XIg+NTdINeXCBnWyZJ+XYOC2/Sz9ODFgD5AC4NDJ4O/YuhXSD6WnX0
fYOiRM0ozNSpJyikCIsZBzBVr1iPoEi8uv1Z8ikOczUrdxlMSVcLTdOUmUSvJbEzbUVn/0za/Hom
BFnFKnETudZVdlga3v70DlYB8Wig8j8epag8QKEnwlr1fczVH90Vow5VdMyQsHNlBwBg6QaTJ/o/
J91gpZZh6bx2lEhcBCM8oucjNb+05Rc2PBCjiOHmtdMP4jP7y1GJIeaV/ttZhlBxoHsPJ3Sn2SbE
CRW6aCmVwzVh8g/q2Jl/h/lLwl2ftc3npsSevyi+WkjAgUqu2khlgJ13siuLeVwy/4rQyKDHpNPU
EY+rb1B0O9wOdmOJCgAvQ8jTvCAbWgwfqkMHkYvz7WY3RIxxziwjA0KWk3RZzYaqIcTjdD3x3CY5
nk2SSZ+8Wy47p+XZ8AdZEXeW35mwjnxnsg+nRk+qOlYlVRWWTclpTSYNH5ZYGMIplCs3EhwIMoNJ
9tT9Th4HCccRMVx0vELwfgrTfdd4+iZy5px5j/gAMjyOKavkKKaKPYSN9T+y0rLpqVLBt3ME2IDS
JU5grpc6+Yj/swCNoTp9HaLLGx7Iuynv6iSMQj5LoBnrVqD27GYwM5/aP5UVpYVWM5f02AKCSwCZ
66liHk++8hooHcATs5ptlDBqQkCNXj5koZ4hgeMK+cu6IjgeGW8fEyhITKM4VaJOATVV6ptYdh1H
TuJT+Pr5dZ19s61ePc+8bvk41IMdVgl3Dh820HSeaWufauhpsC9psjfpf4aT6/WIsHwCWYAajff0
Tw5VKMSVPHFkL0fwPfOMToNBUpdAj9e500SfrSIQE8TXa7ZM1Eu+aGUrLkLrsopxjdq2quxu1blI
L95OFTTNSSm0pSyO2rX9f/Hk/q6lP0eudvdceo5JC0/tInZ1+3DOC5mtSgvkZKSuIrPaSjjCehSx
HRMyVJ5TDfd09Q9Ce8WZMzWl/wZxLYQ20YwW3/kjkOdA0JP8Crhh4v8TAbkV7/+2M16XuJI9W9EN
yI/ysQfsChLt8SMTtea+eJlHjkMu4UITrX06Jlu73LkvqJcUp/lTqdwJnTSM1C843OGr2LkJyPiG
CSE4g3Fz3eM+kzyZaXi0WOYH4zxRwRR4Ijgv3IpCPD5PTDrjzljpdpso1TMmkxX2FrUdcSiuJrGt
Baw8H1KfRgKpsndfsRvbbwNAHgDlLElqrFe7R9jnrxIk/6UYZLPTFW9Qd6EXUhG5lSEe1ck4ZY2b
zqwtGaXD0OChVzHQS/N3BsbUInbkzVcrbY3YtbacGpP7x/VzOGmhcZh0Oz8eWbkrD0r4WfAK2ucX
RVFbQyiLALL9B41rUJSErGk4qzIXjWC/ve0bHmiEi6jXpvjFRmTizB2S+wpNeS0bPy8IP5ki/w1g
ga/x/+fzYPxcM1GCNxFzl1LW7BOmD0roOrV0O11xfXLTo9P9YNkIDpY0oQvcyJFjRmsHMiS21+7h
hJlct7rgGhXHGjE6ilusq95ThO2KTVhMPuSrRotlM+/OboT7/yJmuqFzIjjZL7WBAu+5iBKH5Ace
R9l574aFXy1tGXGuRjZ9owLgitufBV5VyqqQv5kZ/ETBw9x9UCFDecNx90hsw5xa41qnuQdJrpF1
ykXwzL+oTAoIHvPAmgMv3Y4FPWn2JqcPSmkNMV9sJya1eqpbslQzX+uop11f+wHO3bIJKA5YsQTN
Ix1jkFuIEmfkWehyC6FD+EyUIlzUyngcg8mFUl/cXiptkM/JJC3HZoj9Qu1XFw/kUTMr9sXj6UV+
hCpEA5z9RXMMIAVMxKrdRsHPqW4MW4MQj7Q5Ey3cBgtbfd+FKzG5O3XCKsQOm2SImJlIV+d3VMF0
WcAd16NUC9YVtjdTZPRUmrHAMcUPywWomGAkjeOHM1GLZnu5YPXN54rAwmI4/H3pms42lFUbwuUO
wiaFbyX1D79FkvAgRsfHSd4VbPZdCvXOmW+3iGLbYq9lCOA+VUdanonZfh5fjK4tdiB2EC31AE/2
zjqJijLrZdbmtZiGUMvB1FngGA+tcHcMXfOtLfP+Ci0/wYHiu3tezXgClF7KSdJ7k/EB8uDMghM7
L8vLlFjanc/Omc0MwDzMh4Bp1fvw9ZeHwAulKaM6i7POrqvqJj9fd9D9VErkwOU2SDfC+vd1mcTa
ga3Sqza99TIkP7gk+OqpQcBGZhBHBWfkUUVfC4ULGmVrtmGWbVc4XrDVYBAnH/6QNJA77TrKPUbZ
OrMlpkzdj/Po9XEJS6HCA9MuEiukuYOvygzucJU4yE9J32nPh/G26FDZsylvATjcpk4zU+sB1G1L
nuXVZ5u/UGOLfwEmJCEpKBl3fn2mHKDS/Rt5sYTO6egQw7qe1D3HbbC5QFZKTSelMb9Qsn8VsANF
jF18RFy9+7VXUE98ABGMee3X8fql2GwzXQGoYAdyFxxcCJ7/4ua370c9rZhUL5EdYSkSOGoznLZE
cHEfXGy8BJ2gNCLBPFGF4XKq4uaZ2kfCsB6rdn+xFN1b0biXH+fMH1lxEU38ywflBld7uH6RonX9
4aI/IlJkRgNF16Z6pXewBae00327ADlpRv4d9+DBqVG08su+NpjqZxS2FnkkCAbk6IMIRQidg3tY
hlQKLd447nUW1LcC/NTkvCEQiUwdSIaVYh5zkoYuJFJU/ExvadvG+BtzSAd2PK2Whjtw7I4nNcfR
tNuxebFRsBUL5cWRivj0UlVwLufNd7bgofQaJa+SGWOmfrW/ifelB3srrtHh185coBNO5Q+Pcwr8
FgN9JF1SbR2DVXOq3se/Y0BUrQp0cqSfhz//JKPemwq5gAdDPsUcOqY7hxnA4q0GHnERiBUFU+p+
/fV0oGhU6NAONDyj7zo5OuaWxgPQziLS+aO1kCmF0WYHaztmfZqGWk/4U++B911/9nqpe95IzymX
3rgjNaOLRPHxAW3gZNRCqh32bhLbXiH6SLw+HWVZgIyBzhTWqGvpqZVtol3a/HP5CA8b3dW5h1vt
+u1QuMe7oBMV/oRXhwBGZeezIrYkkVKeK2u5s2svg7tt1aOQcWGu1txzrLLJ2y1l8t942cRbjSo3
1xzUuv3aKY4Nbj+5peuie0WBPjp/LJfmn27FZ+iqs/SaOBol0Y+y1tt+13c9MgqLKb9Hl/xy3vSC
sQgXnwTo/HOAl9BbknRLPwnElCsHoXBkZKBG0taG5rW/Xa6KSe+KpanoyyeAXAc8rNgXJLAcDp02
+6STSRBh7TQsMYUUsVQz/b6qqLErGMOcYb1IRJOtDCC/+xEbyT+wAuUv+XWsnndpsGrCAmRDR1x7
Up28UwWvNqpwfb9dK1V63AwDH1jidrtVczdAxSjdDRa3ql5LWZZNVkgfse3EQW29jOifH2zmIUx4
bVOcPUuXXhGXgJkPKghZ5Q8+JbE9xcHij3wF2FBNrQVkL8u6BLZEqAGKuYm7Y60xmbvgrWoqj58V
zbaKbpO20dsKSbeU1aZoamUOAUYAbw4Pz2mO/BFALxvBRovYoqvR+uxhxg585vAY3ToTEkdaho1l
4p0h/C8FfluhhIW9EjO+jY8vXF4V9Qa94Zxs/n500jP0xXFzG0YXKy39tYB9BMM3dSvfynJcO0fv
4hEkTk9elm==