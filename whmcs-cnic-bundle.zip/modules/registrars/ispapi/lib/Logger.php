<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvVCwjfQcUyT8mL/+Taps4qBVki6iMhskFH7lhughFkOdIDIxUQUJbfi3Rvk/tI7dmHi24+7
bFAVc+sByr4CCr4+JGySVqNfiFD4V4aOI9XrOrwjV82XhxsS4BqMQSmz4RY8S0SjDkpnFnCDYRTI
PhPMlZuir8J+n6/w7EPuVV4MkPk9Ylc/Bfr69z9pM8kWa5Ej9ABC5i8lmhXO4Ht0zvh1R3YN/hxf
qjPlDD2Gx4Gbttv8XfYKAumWoLTxCasZaNkm8KfzvT9yD39gwpBCSAKL+RguQ/ojEGKYCkBGbFq7
GLjd6k2k7BWxfxStyjyRofu6TYFFXPs1/2MIU0uTrn1N4eVWEPNJCHvLe732ioOcBtCUE5CeCmD2
h2VPdJ9yxD84GgC3n0FvKBxeAvIncHSseNOe+m89obBhHboO1OnmBUVCBcJwZnz4QNFN3S8A2883
XM1TRYZninLyWeQkH/Fqh9Zl0BgRNn1yW1/yzEna5qMXZu4J1tDrSbCP532iUPbzS5oVNt2gfIeM
+WCz1n6NaJhCeOJzJWI5Qfej7/zWKQYmVL/+JyU3CfMSPX+cUiVzFm683W9oSgosScsindfSRG1l
+9en8nxm15V7/EO6weDOQf6cN/loJ4edjr52FS4K6LD04DehLrZqMsEbmO/935lhUlWcUZDcnZdH
tF2B94PgXge+PdFG3ycjasuEunCrfW4SlGSrD72VIjcO1RPA1Yi+8/Wlox4BLrUy0+HLGgnnmd/X
82ZgGXgnSWvko8jaGgVUfuKAD7+Tzl1LUetmT0jasgCxeOgqkhkvtp99asp+5i/ogHO/4mkX4D/7
uRAFV7rUJY/E/calZOFIR7SoHWTO81BDMuln2U0+UCiObv9YJ5ebm0oi/HcVrBqPJn+r2V9wj0ND
lcqVac5jT2hIjfsyU6cHC2BbzsDTmCvVyKzqlrhA+atrzPdWE305Y6R10uStfu3g5+rgUVOzKE6Z
ZmumHdfsAkaCu2XXgaBBcGjv4pPi+9WBq54VVaSfxV2Drpba0Tzry1MELf1xrWhqWXTvgb75lQBX
SLEfRnq4RM4IXH6cmj6ZR0Pxff5lAcRjU7/exy6Z/fF40CwU9/PTBwwDjoytbB4LsMjtkOXu1ftZ
ZUNOJSP/dnnk/hQhUu+kcTBoiBDZEtVFUIkv9YOXCKxkCdbxNplUW+9xv0ciepAJlxB0sQEp2lWv
9hbvkjJHHHFxCMlvRfqDUCSScWcGf/XaQQ7Ad7d2hqMfskUY2hK4QSdoXKVMAuwmxCseV2hvDnri
h4UW/vVccHECma/pGmJ5WLX3fPtNAAiOkD5sZb0UWZ4Ot3f7Lep2itvoKGWAIt9EKhN7lf4oN0ht
qx7KdrPaVBM0d9XlHLURgHgSoUtpeIPKpQ0+k36dH/dqGYvB7+6+VqEW8l1o9w04N7adPQaR6+9c
zMN2kwOu8N+NTCZZHSdzOb63PvbOc8vHHu/3NgMmkmBWgLJkBbsPgCHtONMCQtYpe7HKwgHU6tyY
zuAHxDVcalgsWL2fmMECEUE7S2As7LVYe5lb2r/Ccka4Jv3knhpu8z6GbY0R0y9zJks9sVj7Qeld
yMnORkZD/5UOj10bfy95mheYQqGK6PDMihzgcKhh9y9Qj41727tSp3Vy/aB5m4nFTXYLWDBfuqS9
9SX1vwW7vyWNMDRTGsDbRpt/UFtdu4zX/sOSBTeJyG7yYvqYNs0tf+s4xcC06Mv8p8InwocpKLQU
0Qag9HRo+AsrHoS88O0ktp4IjvLa+ZxnCez342WDMYdWsLH7vYKv/Zi8+loQR1VdxUqHB3WlyXnn
ly4c0Nf3k1jrJycufH3rEOCch6o4Hqi5nh3f4EkH5jEie2VIhiIfzl13Xr9YqDqahd2Akr+F8mUe
GC2R/+vTx72UVt1ZT6hQGbPMDrL7urzK8s1aiHEOWxeuxuvjb/O1z/jazuz+SitRTT2i+Or9tVDy
KqUjkR1L053xFu7etsbclKfy6tiTeT7UAO2J7JeHyiPIXhc+znttx3xMdMeu7yWZ0oL4j4Z/lbyG
1n320EGamPSU1+/H/E6Vb6MCVGSJpT6C+01ba9fDJ100wTvEvmapnVJXElkxt/vCNWTi9YNmdMYf
BtJPtUezvg+H5lsTidaWtcwrCMFBfhwY24gEKCG9UdYdsLZ4wl1++K1dX2C+dmkGhJYam2vPb7Iz
99q5AlLHuO4WVuOG3eXIHNJdL7jYn5InSYeWNbCXsKuGgYZAttL9biDPSYLk22/4FIyc9/k0UF9t
TKY/2D+80QE6ldKsCaMSTG5DoaruYwqQpQATYVmqOPzymIzbe1hYVQRlwR5ydT9hwIS0ppKEARCz
sl6ljD9z6FMJctKZUetBEy2sgIyXQaUeJGTqxx8z1TN0ZRvNFPbLt3Xl1J+Z8FnynPKNE50LtMnb
y8r32tYDvvBK2Tq5+MAJtMgsy2p9nCfURdr+jv1x6ibEa9WHv78nssMNcHsv/RBNWmw/lMeh13yW
lubxnbVyznTWiqDoCJC/H4mN1pl2ZzeEZ3gxYqPH2MuvBvWera1D9xTDKPoa/WqAf8hiPofue9BC
Lla03rCmliwAaltjZJ+F9BnzETAmotvU+O8VJ+mY2SbGLpFTvGFf9wReBLcpo88/Y+OVZ2aii6G2
sqYT+8Xi3KLNRCnLO+QyxIq0R6W/bszAgrNn45u0ZIKKPzoOGKEzbebZelUx0zi/t8ykQXnVxOUd
qNWO/oX3sx0kG/jgUsBj59Vn0i/6k8JIBy25kFnmzFd0gkltZ1WckWcb4h2ebH6gq982wOzYPdUN
dzIrYebYak2+ffKXoSkMV3TQKSpm3SaFKEgKGo57p4hpVt1c0QEIuZIhRV5DxyyB67f+Sk7BvoQR
qedVIx73r3U0y9iZn1Dx9EOtCcYky0YaT8OT8aQp7oD1GHdmy0kIWmptCVQ9UN0/m/FrkWSDOl2E
r46V9C+WdUscT8Pcau0nRYYG2OVy/vImjljxkb+fCgbHyYe5ryP8T0ZKVnCnYHk+4Yhww/AaSuna
wPSfWG3dTwmt99LDRnaWESeSbRUbk8D+G+865mt130J/beAg1DnOWyr5Bg6njXFW27dV5QLyyo0e
RVufiWmO9d8F1fcL0qJucX6OqvHKnVZKtluPC+yXwIb4NtSN+jhNI7YNxaFwCN8JMp4hqssL9npw
+nPGadkUkhHAO7DHh23m0lipziOgyYI5JOvrLhTkhiG9bde/yeb7pVU3EGDgP+iLMXvQL0PcWPD0
ZPolKflhLcbauBIAJxNk+4HjcSMJqr/Rz2IJzi8m3YizxfhmG+Zb6EB1/zIuNId6Kb9J2zS+He2J
/S7gSj/GAtkAHgn1j1BbrWZaMYE4GU3Iom5jzG1eNmrex8x2o797T2WF9maF1GtL8bomNHRfjuyF
I7yN2KgYdgr2dkYs3g6ST4QA07I6erv9OdxhO8+Kr9MUk32AwaRTUXwE0tYwOig1iJuVBQf9Yk4O
+5n4w1KxHWN4xv/GYruIyC/TgssvKubGMhG4h73Mse/sb4kz6uvcNmiBne8QSIwYzEdzG+1QkzJR
9ejxApQKQeTyd0ZSwAWtRi+JcLmGN+FpxnCI8YXNOIEQBbKLPtAqxQ+MrhqWoBouTNvrk5ve40fX
Uny5lQBhoaX8EktCXMW3avmmxibHRw28Ufr+dwODqZHQqfCx1pUAh5Rwqol+P51CDaAK14dneo/m
OUhhb+JFgAnkaRocreX0793KO0piJHQBSWgLGSrViRaSgKuNpKbZpV1xd7KrMtnx0naId2tW9KET
eSY97ceSJbzaxj26BcCqZ45Rsj3Wmv18yQgSKVO8gz70zvs5CLKKUKveo67vuR/ToGcJ5wcAEj46
+42MbftVyLOUSATaYTzJ97h2guRRFr9bLNQ3I5cLCvOT1ZwrBuny0rhXreCqVi4KAemLgmwcIpkn
5zSvAVllrTS/oZEecXW2rYSjHdIz3He8uZ0YeizIpWp7/0IL+98gNzMS9k8G4BT+hHXPnP91Udlk
9G2ikzwsYIEGeNA6jzUN7YanR+/6d1rheusLdgp03XIu+8A0hHRU/XGfsAagKa2cL/Q0q1TeLumC
cpNT2d4N2qXue1HFZcRCNgx0Ur8IJX4xfOKkEI0GpDMcox3ljwk2barl6D1f0CHjP4Chx+fhlTT4
Itcb+wgGD7wFTgg4iqFh0XxojBCxJEVlgRBwB8p0ZFbMl9IM2XjJTEJin56HHrWIghBDV/ZYR/o1
pJ1IR14BvVcAAGWbSOrP3GB9UWcy8J5POfeOvmXODroiMzQ35N+UDzgCa1uYcB092xFjoIvt