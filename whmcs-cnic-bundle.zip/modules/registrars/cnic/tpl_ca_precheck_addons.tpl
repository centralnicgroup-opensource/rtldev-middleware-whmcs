<script type="text/javascript">
    $(document).ready(function() {
        let domains = {$domainAddons};
        domains.forEach(function(domain) {
            for (let addon in domain) {
                if (!domain.hasOwnProperty(addon)) continue;
                let value = domain[addon];
                if (value === 1) {
                    let eL = $("input[name='" + addon + "'][type='checkbox']");
                    if (eL && !eL.prop('checked')) {
                        eL.click();
                    }
                }
            }
        });
    })
</script>