<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as DB;
use WHMCS\Carbon;
use WHMCS\Domain\Registrar\Domain;
use WHMCS\Domain\TopLevel\ImportItem;
use WHMCS\Domains\DomainLookup\ResultsList;
use WHMCS\Domains\DomainLookup\SearchResult;
use WHMCS\Module\Registrar\CNIC\Commands\AddDomain;
use WHMCS\Module\Registrar\CNIC\Commands\CheckDomains;
use WHMCS\Module\Registrar\CNIC\Commands\CheckDomainTransfer;
use WHMCS\Module\Registrar\CNIC\Commands\DeleteDomain;
use WHMCS\Module\Registrar\CNIC\Commands\GetNameSuggestion;
use WHMCS\Module\Registrar\CNIC\Commands\ModifyDomain;
use WHMCS\Module\Registrar\CNIC\Commands\PushDomain;
use WHMCS\Module\Registrar\CNIC\Commands\QueryZoneList;
use WHMCS\Module\Registrar\CNIC\Commands\RenewDomain;
use WHMCS\Module\Registrar\CNIC\Commands\ResendNotification;
use WHMCS\Module\Registrar\CNIC\Commands\RestoreDomain;
use WHMCS\Module\Registrar\CNIC\Commands\SetAuthCode;
use WHMCS\Module\Registrar\CNIC\Commands\SetDomainRenewalMode;
use WHMCS\Module\Registrar\CNIC\Commands\StartSession;
use WHMCS\Module\Registrar\CNIC\Commands\StatusAccount;
use WHMCS\Module\Registrar\CNIC\Commands\StatusContact;
use WHMCS\Module\Registrar\CNIC\Commands\StatusDomain;
use WHMCS\Module\Registrar\CNIC\Commands\StatusDomainTransfer;
use WHMCS\Module\Registrar\CNIC\Commands\TradeDomain;
use WHMCS\Module\Registrar\CNIC\Commands\TransferDomain;
use WHMCS\Module\Registrar\CNIC\Features\Contact;
use WHMCS\Module\Registrar\CNIC\Features\DNSZone;
use WHMCS\Module\Registrar\CNIC\Features\MailFwd;
use WHMCS\Module\Registrar\CNIC\Features\Nameserver;
use WHMCS\Module\Registrar\CNIC\Helpers\Order;
use WHMCS\Module\Registrar\CNIC\Helpers\Pricing;
use WHMCS\Module\Registrar\CNIC\Helpers\ZoneInfo;
use WHMCS\Module\Registrar\CNIC\Migrator;

require_once implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]);

/**
 * @param array<string, mixed> $params
 * @return array<string, mixed>
 */
function cnic_getConfigArray(array $params): array
{
    $msgUpdate = '';
    $msgMigrate = '';
    $msgRegister = "Don't have an CentralNic Reseller account yet? Contact us here: <a target=\"_blank\" href=\"https://www.centralnicreseller.com/\">www.centralnicreseller.com</a>";
    $meta = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . "whmcs.json"), true);

    static $dbChecked = false;

    if (isset($params['Username'])) {
        if (!$dbChecked) {
            ZoneInfo::initDb();
            $dbChecked = true;
        }
        if (@$_GET['migrate']) {
            Migrator::migrate($params);
        }
        if (!$params['Username'] && Migrator::canBeMigrated()) {
            $msgMigrate .= "<br /><a href='configregistrars.php?migrate=true&amp;saved=true#cnic' class='btn btn-sm btn-primary' title='Click here to automatically migrate domains and TLD prices over from deprecated/built-in modules!'>Migrate from legacy module</a>";
        }
        $updateStatus = cnic_getVersionCheck();
        switch ($updateStatus) {
            case -1:
                $msgUpdate = '<br /><i class="fas fa-times-circle"></i> Unable to check for updates';
                break;
            case 1:
                $msgUpdate = '<br /><i class="fas fa-exclamation-circle"></i> Update available! ';
                $msgUpdate .= '<a class="btn btn-default btn-sm" href="https://github.com/centralnicgroup-opensource/rtldev-middleware-whmcs/raw/main/whmcs-cnic-bundle.zip" target="_blank"><i class="fab fa-github"></i> Get it on GitHub</a>';
                break;
            default:
                $msgUpdate = '<br /><i class="fas fa-check-circle"></i> You are up to date!';
        }
    }

    $system = $params["TestMode"] === "on" ? "OT&E" : "LIVE";
    $host = parse_url(\WHMCS\Config\Setting::getValue("SystemURL"), PHP_URL_HOST);
    $ip = gethostbyname($host);

    $cmd = new StartSession($params);
    if (!$cmd->wasSuccessful()) {
        $url = "https://www.centralnicreseller.com/en/contact"; // $meta["_priv"]["UrlFaqAuthError"];
        $authDescription = (<<<HTML
            <div class="alert alert-danger" style="font-size:medium;margin-bottom:0px;">
                <h2>Connecting to the {$system} Environment failed. <small>({$cmd->getErrors()})</small></h2>
                <p><a style="text-decoration:underline;" href="{$url}" target="_blank" class="alert-link">Contact us</a> if you need help. <b>Your Server IP Address</b>: {$ip}</p>
            </div>
HTML
        );
    } else {
        $authDescription = (<<<HTML
            <div class="alert alert-success" style="font-size:medium;margin-bottom:0px;">
                <h2>Connection to the {$system} Environment established.</h2><b>Your Server IP Address</b>: {$ip}
            </div>
HTML
        );
    }

    return [
        'FriendlyName' => [
            'Type' => 'System',
            "Value" => "\0 " . preg_replace('/v([.\d]*)/i', 'v' . CNIC_VERSION, $meta["description"]["name"])
        ],
        'Description' => [
            'Type' => 'System',
            'Value' => $msgRegister . $msgUpdate . $msgMigrate,
        ],
        'Username' => [
            'Type' => 'text',
            'Size' => '25',
            'Description' => 'Enter your CentralNic Reseller Username',
        ],
        'Password' => [
            'Type' => 'password',
            'Size' => '25',
            'Description' => 'Enter your CentralNic Reseller Password',
        ],
        'DefaultTTL' => [
            'FriendlyName' => 'Default TTL',
            'Type' => 'text',
            'Size' => '10',
            'Default' => '28800',
            'Description' => 'Default TTL value in seconds for DNS records'
        ],
        "TransferLock" => [
            "FriendlyName" => "Automatic Transfer Lock",
            "Type" => "yesno",
            "Default" => true,
            "Description" => "Automatically locks a Domain after Registration or Transfer"
        ],
        "NSUpdTransfer" => [
            "FriendlyName" => "Automatic NS Update on Transfer",
            "Type" => "yesno",
            "Default" => true,
            "Description" => "Automatically update the domain's nameservers after successful transfer to the ones submitted with the order.<br/>NOTE: By default WHMCS suggests your configured Defaultnameservers in the configuration step of the shopping cart."
        ],
        "TRANSFERCARTPRECHECK" => [
            "FriendlyName" => "Transfer Checkout Pre-Checks",
            "Type" => "yesno",
            "Description" => "Validate Domain Transfers on Shopping Cart Checkout. This will block the checkout until all Transfer pre-checks succeed. e.g. valid eppcode, unlocked domain etc."
        ],
        "AutoDNSManagement" => [
            "FriendlyName" => "Enable DNS Management",
            "Type" => "yesno",
            "Default" => true,
            "Description" => "Enable DNS Management on TLD pricing sync"
        ],
        "AutoEmailForwarding" => [
            "FriendlyName" => "Enable Email Forwarding",
            "Type" => "yesno",
            "Default" => true,
            "Description" => "Enable Email Forwarding on TLD pricing sync"
        ],
        "AutoIDProtection" => [
            "FriendlyName" => "Enable ID Protection",
            "Type" => "yesno",
            "Default" => true,
            "Description" => "Enable ID Protection on TLD pricing sync for compatible TLDs"
        ],
        "SUSPENDONEXPIRATION" => [
            "FriendlyName" => "Suspend after Expiration",
            "Type" => "yesno",
            "Description" => "Automatically suspend (clientHold) Domains after the expiration date has passed and automatically unsuspend again after Renewal."
        ],
        'RenewProtection' => [
            'FriendlyName' => 'Renewal Protection',
            'Type' => 'yesno',
            "Default" => false,
            'Description' => 'Skips renewal when domain expiration date is already ahead of the new due date'
        ],
        'DeleteMode' => [
            'FriendlyName' => 'Domain deletion mode',
            'Type' => 'dropdown',
            'Options' => ['ImmediateIfPossible', 'AutoDeleteOnExpiry'],
            'Default' => 'ImmediateIfPossible',
        ],
        'DNSSEC' => [
            'FriendlyName' => 'Allow DNSSEC',
            'Type' => 'yesno',
            "Default" => false,
            'Description' => 'Enables DNSSEC configuration in the client area'
        ],
        'DailyCron' => [
            'FriendlyName' => 'Daily Cron',
            'Type' => 'yesno',
            "Default" => false,
            'Description' => 'Makes some daily consistency checks and sends an e-mail report'
        ],
        'TestMode' => [
            'Type' => 'yesno',
            'Description' => 'Tick to enable OT&amp;E',
        ],
        'TestPassword' => [
            'Type' => 'password',
            'Size' => '25',
            'Description' => 'Enter your CentralNic Reseller OT&amp;E Password',
        ],
        "ProxyServer" => [
            "FriendlyName" => "Proxy Server",
            "Type" => "text",
            "Description" => "HTTP(S) Proxy Server (Optional)"
        ],
        "AutoEnableIDProtection" => [
            "FriendlyName" => "Precheck ID Protection",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the ID protection addon on shopping cart level."
        ],
        "AutoEnableDNSManagement" => [
            "FriendlyName" => "Precheck DNS Management",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the DNS Management addon on shopping cart level."
        ],
        "AutoEnableEmailForwarding" => [
            "FriendlyName" => "Precheck Email Forwarding",
            "Type" => "yesno",
            "Description" => "Automatically pre-check the Email Forwarding addon on shopping cart level."
        ],
        "KeyDnsNameservers" => [
            "FriendlyName" => "KeyDNS Nameservers",
            "Type" => "text",
            "Description" => "Comma-separated list of Nameservers to use for domains with DNS Management. Leave empty to use defaults: ns1.dnsres.net, ns2.dnsres.net, ns3.dnsres.net"
        ],
        "" => [
            "Type" => "system",
            "Description" => $authDescription
        ]
    ];
}

/**
 * @param array<string, mixed> $params
 *
 * NOTE: fallbacks to GetNameservers and GetRegistrarLock, find details there!
 *
 * @return WHMCS\Domain\Registrar\Domain
 * @see https://developers.whmcs.com/domain-registrars/domain-information/
 * @see https://classdocs.whmcs.com/8.7/WHMCS/Domain/Registrar/Domain.html
 * @throws Exception
 */
function cnic_GetDomainInformation(array $params)
{
    $domain = new Domain();
    $domain->setDomain($params["sld"] . "." . $params["tld"]);
    try {
        $domainStatus = new StatusDomain($params);
    } catch (Exception $ex) {
        try {
            $transferStatus = new StatusDomainTransfer($params);
            $domain->setNameservers([]);
            return $domain;
        } catch (Exception $ex) {
            throw new Exception("Not found in the registrar system.");
        }
    }

    $domain->setDomain($domainStatus->domainName);
    $domain->setIsIrtpEnabled(true);
    $domain->setNameservers($domainStatus->nameServers);
    $domain->setTransferLock($domainStatus->transferLock);
    $domain->setExpiryDate(Carbon::createFromFormat("Y-m-d H:i:s", $domainStatus->expirationDate));

    //check contact status
    try {
        $contactStatus = new StatusContact($params, $domainStatus->ownerContact);
        $domain->setRegistrantEmailAddress($contactStatus->email);
        if ($contactStatus->verificationRequested && !$contactStatus->verified) {
            $domain->setDomainContactChangePending(true);
        }
    } catch (Exception $ex) {
        // we suffer in silence...
    }

    if ($domainStatus->timeToSuspension) {
        $domain->setPendingSuspension(true);
        $domain->setDomainContactChangeExpiryDate(Carbon::createFromFormat("Y-m-d H:i:s", $domainStatus->timeToSuspension));
    }
    $domain->setIrtpVerificationTriggerFields([
        "Registrant" => [
            "First Name",
            "Last Name",
            "Organization Name",
            "Email",
        ]
    ]);

    // email forwarding
    try {
        $forwarding = new MailFwd($params);
        $domain->setEmailForwardingStatus(!empty($forwarding->values));
    } catch (Exception $ex) {
        $domain->setEmailForwardingStatus(false);
    }

    // dns management
    try {
        $dnsManagement = new DNSZone($params);
        $domain->setDnsManagementStatus($dnsManagement->exists());
    } catch (Exception $ex) {
        $domain->setDnsManagementStatus(false);
    }

    // id protection
    $domain->setIdProtectionStatus($domainStatus->idProtection);

    // set custom data
    $domain->registrarData = [
        "isPremium" => (int) $domainStatus->isPremium,
        "isTrusteeUsed" => $domainStatus->isTrusteeUsed,
        "registrantTaxId" => $domainStatus->vatId,
        "createdDate" => $domainStatus->creationDate
        //"domainfields" => ... TODO
    ];

    return $domain;
}

/**
 * Resend contact verification e-mail to owner
 * @param array<string, mixed> $params
 * @return array<string, mixed>
 */
function cnic_ResendIRTPVerificationEmail(array $params): array
{
    try {
        $verify = new ResendNotification($params);
        $verify->executeContactVerification();
        return ["success" => true];
    } catch (Exception $ex) {
        return ["error" => $ex->getMessage()];
    }
}

/**
 * Register a domain.
 *
 * Attempt to register a domain with the domain registrar.
 *
 * This is triggered when the following events occur:
 * * Payment received for a domain registration order
 * * When a pending domain registration order is accepted
 * * Upon manual request by an admin user
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @throws Exception
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_RegisterDomain(array $params): array
{
    $params = injectDomainObjectIfNecessary($params);
    $register = new AddDomain($params);
    try {
        $register->execute();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Initiate domain transfer.
 *
 * Attempt to create a domain transfer request for a given domain.
 *
 * This is triggered when the following events occur:
 * * Payment received for a domain transfer order
 * * When a pending domain transfer order is accepted
 * * Upon manual request by an admin user
 *
 * @param array<string, mixed> $params common module parameters
 * @param bool $skipcontacts skip dealing with contact data (migrator retry)
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_TransferDomain(array $params, bool $skipcontacts = false): array
{
    try {
        // Domain transfer pre-check (apparently only for com/net/jobs/org/bin/info/name/mobi)
        // (Lukas Grund, 2023-03)
        $domain = $params["sld"] . "." . $params["tld"];
        if (preg_match("/\.(com|net|jobs|org|bin|info|name|mobi)$/i", $domain)) {
            $check = new CheckDomainTransfer($params);
            $check->execute();
            if (!$check->wasSuccessful()) {
                return ["error" => $check->getErrors()];
            }
        }

        $transfer = new TransferDomain($params, $skipcontacts);
        $transfer->request();
        if (!empty($transfer->getErrors())) {
            return ["error" => $transfer->getErrors()];
        }
        return ["success" => true];
    } catch (Exception $ex) {
        return ["error" => $ex->getMessage()];
    }
}

/**
 * Renew a domain.
 *
 * Attempt to renew/extend a domain for a given number of years.
 *
 * This is triggered when the following events occur:
 * * Payment received for a domain renewal order
 * * When a pending domain renewal order is accepted
 * * Upon manual request by an admin user
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_RenewDomain(array $params): array
{
    // --- Domain Restore -----------------------------------------------------------
    // Additional Information that may be useful in future:
    // ------------------------------------------------------------------------------
    // Premium Domains:
    // X-FEE-AMOUNT not necessary, no registry provider is driving with premium
    // restore costs up to now.
    // ------------------------------------------------------------------------------
    // GetZoneInfo
    // -> property[is restore possible][0] = 1
    // -> property[rrp supports restore][0] = 1
    // ------------------------------------------------------------------------------
    // QueryZoneList
    // -> 'RESTORE_INCLUDE_RENEW' => $restoreRenew->{lc($zone)} || 0,
    // -> 'TRANSFER_NOT_INCLUDE_RENEW' => $transferRenew->{lc($zone)} || 0,
    // -> 'TRANSFER_RESETS_EXPIRATIONDATE' => $transferReset->{lc($zone)} || 0,
    // -> 'TRADE_RESETS_EXPIRATIONDATE' => $tradeReset->{lc($zone)} || 0,
    // ------------------------------------------------------------------------------
    if (isset($params["isInRedemptionGracePeriod"]) && $params["isInRedemptionGracePeriod"]) {
        try {
            $restore = new RestoreDomain($params);
            $restore->execute();
            return ['success' => true];
        } catch (Exception $ex) {
            return ['error' => $ex->getMessage()];
        }
        // future: continue with renewal below based on renewal period difference
        // if restore is not including renewal or the renewal period is different to the one
        // here in WHMCS that's why the above api info might be useful
    }

    try {
        $renew = new RenewDomain($params);
        $renew->execute();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Fetch current nameservers.
 *
 * This function should return an array of nameservers for a given domain.
 * NOTE: This function is invoked in case GetDomainInformation throws an exception Or returns no nameservers
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_GetNameservers(array $params): array
{
    try {
        $domain = new StatusDomain($params);
        return $domain->nameServers;
    } catch (Exception $ex) {
        return [];
    }
}

/**
 * Save nameserver changes.
 *
 * This function should submit a change of nameservers request to the
 * domain registrar.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_SaveNameservers(array $params): array
{
    try {
        $domain = new ModifyDomain($params);
        $domain->setNameServers();
        $domain->execute();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Get the current WHOIS Contact Information.
 *
 * Should return a multi-level array of the contacts and name/address
 * fields that be modified.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_GetContactDetails(array $params): array
{
    try {
        $domain = new StatusDomain($params);

        $contacts['Registrant'] = Contact::getContactInfo($domain->ownerContact, $params);

        if (\WHMCS\Config\Setting::getValue('RegistrarAdminUseClientDetails')) {
            if ($domain->adminContact) {
                $contacts['Admin'] = Contact::getContactInfo($domain->adminContact, $params);
            }
            if ($domain->billingContact) {
                $contacts['Billing'] = Contact::getContactInfo($domain->billingContact, $params);
            }
            if ($domain->techContact) {
                $contacts['Tech'] = Contact::getContactInfo($domain->techContact, $params);
            }
        }

        return $contacts;
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Update the WHOIS Contact Information for a given domain.
 *
 * Called when a change of WHOIS Information is requested within WHMCS.
 * Receives an array matching the format provided via the `GetContactDetails`
 * method with the values from the users input.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @throws Exception
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_SaveContactDetails(array $params): array
{
    $values = [];

    $modifyDomain = new ModifyDomain($params);
    $zoneInfo = ZoneInfo::get($params);

    $modifyDomain->setOwnerContact(Contact::mapFormContact($params['contactdetails']['Registrant']));
    if (\WHMCS\Config\Setting::getValue('RegistrarAdminUseClientDetails')) {
        $modifyDomain->setAdminContact(Contact::mapFormContact($params['contactdetails']['Admin']));
        $modifyDomain->setBillingContact(Contact::mapFormContact($params['contactdetails']['Billing']));
        $modifyDomain->setTechContact(Contact::mapFormContact($params['contactdetails']['Tech']));
    }

    try {
        if (count($modifyDomain->api->args) > 1 && $zoneInfo->needs_trade && isset($modifyDomain->api->args['ownercontact0firstname'])) {
            $contact = array_filter($modifyDomain->api->args, function ($key) {
                return strncmp(strtolower($key), "ownercontact0", 13) === 0;
            }, ARRAY_FILTER_USE_KEY);
            $tradeDomain = new TradeDomain($params, $contact);
            $tradeDomain->execute();
            foreach (array_keys($contact) as $key) {
                unset($modifyDomain->api->args[$key]);
            }
        }
        $modifyDomain->execute();
    } catch (Exception $ex) {
        $values['error'] = $ex->getMessage();
    }

    return $values;
}

/**
 * Check Domain Availability.
 *
 * Determine if a domain or group of domains are available for
 * registration or transfer.
 *
 * @param array<string, mixed> $params common module parameters
 * @return ResultsList<SearchResult> An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 * @throws Exception Upon domain availability check failure.
 * @see \WHMCS\Domains\DomainLookup\ResultsList
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @see \WHMCS\Domains\DomainLookup\SearchResult
 */
function cnic_CheckAvailability(array $params)
{
    $premiumEnabled = (bool)$params["premiumEnabled"];
    $tldsToInclude = $params["tldsToInclude"];
    $results = new ResultsList();

    foreach (array_chunk($tldsToInclude, 32) as $tlds) {
        $checkDomains = new CheckDomains($params, $tlds);
        try {
            $checkDomains->execute();
            // Loop over List of SearchResults
            foreach ($checkDomains->getResults() as $i => $sr) {
                switch (substr($checkDomains->api->properties["DOMAINCHECK"][$i], 0, 3)) {
                    case 210:
                        $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                        if (
                            $premiumEnabled
                            && isset($checkDomains->api->properties["X-FEE-CLASS"][$i])
                            && $checkDomains->api->properties["X-FEE-CLASS"][$i] === "premium"
                            && empty($checkDomains->api->properties["X-FEE-LAUNCHPHASE"][$i])
                            && !empty($checkDomains->api->properties["X-FEE-CURRENCY"][$i])
                            && !empty($checkDomains->api->properties["X-FEE-AMOUNT"][$i])
                        ) {
                            $sr->setPremiumDomain(true);
                            $sr->setPremiumCostPricing([
                                "CurrencyCode" => $checkDomains->api->properties["X-FEE-CURRENCY"][$i],
                                "register" => $checkDomains->api->properties["X-FEE-AMOUNT"][$i],
                                "renew" => $checkDomains->api->properties["X-FEE-AMOUNT"][$i]
                                // todo: what about application fee?
                            ]);
                        }
                        break;
                    case 211:
                        $sr->setStatus($sr::STATUS_REGISTERED);
                        break;
                    default:
                        $sr->setStatus($sr::STATUS_TLD_NOT_SUPPORTED);
                }
                $results->append($sr);
            }
        } catch (Exception $ex) {
            foreach ($checkDomains->getResults() as $i => $sr) {
                $results->append($sr);
            }
        }
    }
    return $results;
}

/**
 * Get Domain Suggestions.
 *
 * Provide domain suggestions based on the domain lookup term provided.
 *
 * @param array<string, mixed> $params common module parameters
 * @return ResultsList<SearchResult> An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 * @throws Exception Upon domain suggestions check failure.
 * @see \WHMCS\Domains\DomainLookup\ResultsList
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @see https://kb.centralnicreseller.com/api/name-suggestion
 * @see \WHMCS\Domains\DomainLookup\SearchResult
 */
function cnic_GetDomainSuggestions(array $params)
{
    $results = new ResultsList();
    try {
        $getNameSuggestion = new GetNameSuggestion($params);
        $getNameSuggestion->execute();
        foreach ($getNameSuggestion->api->properties["NAME"] as $idx => $domain) {
            $d = explode('.', $domain, 2);
            if (preg_match("/^available$/i", $getNameSuggestion->api->properties["AVAILABILITY"][$idx])) {
                $sr = new SearchResult($d[0], $d[1]);
                $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                $results->append($sr);
            }
            // TODO: availability "unknown" otherwise ... we could check the availability of these items
        }
    } catch (Exception $ex) {
    }
    return $results;
}

/**
 * Get registrar lock status.
 *
 * Also known as Domain Lock or Transfer Lock status.
 * NOTE: Not invoked for domain transfers
 *
 * @param array<string, mixed> $params common module parameters
 * @return string|array<string, string> Lock status or error message
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_GetRegistrarLock(array $params)
{
    try {
        $domain = new StatusDomain($params);
        return $domain->transferLock ? "locked" : "unlocked";
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Set registrar lock status.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_SaveRegistrarLock(array $params): array
{
    try {
        $domain = new ModifyDomain($params);
        $domain->setRegistrarLock();
        $domain->execute();
        return ['success' => 'success'];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Get DNS Records for DNS Host Record Management.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed> DNS Host Records
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_GetDNS(array $params): array
{
    try {
        $dns = new DNSZone($params);
        return $dns->get();
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Update DNS Host Records.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_SaveDNS(array $params): array
{
    try {
        $dns = new DNSZone($params);
        $dns->save();
        return [];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Get Email Forwardings
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_GetEmailForwarding(array $params): array
{
    try {
        $emailFwd = new MailFwd($params);
        return $emailFwd->values;
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Save Email Forwarding
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_SaveEmailForwarding(array $params): array
{
    try {
        $emailFwd = new MailFwd($params);
        $emailFwd->update();
        return [];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Enable/Disable ID Protection.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_IDProtectToggle(array $params): array
{
    try {
        $domain = new ModifyDomain($params);
        $domain->setWhoisPrivacy();
        $domain->execute();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Request EEP Code.
 *
 * Supports both displaying the EPP Code directly to a user or indicating
 * that the EPP Code will be emailed to the registrant.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_GetEPPCode(array $params): array
{
    try {
        $authCode = null;
        if (in_array($params["tld"], ["de", "be", "no", "eu"])) {
            try {
                $auth = new SetAuthCode($params);
                $authCode = $auth->getAuthCode();
            } catch (Exception $ex) {
                // We suffer in silence
            }
        }
        if (!$authCode) {
            $status = new StatusDomain($params);
            $authCode = $status->authCode;
        }

        if ($authCode) {
            return ['eppcode' => $authCode];
        } else {
            return ['error' => "No Auth Info code found!"];
        }
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Release a Domain.
 *
 * This feature currently works for .DE, .UK domains and .AT domains.
 *
 * TARGET    Where to push the domain
 * .DE target: TRANSIT (push domain back to registry)
 * .AT target: REGISTRY (push domain back to registry)
 * .UK target: EXAMPLE-TAG-HOLDER (new IPS TAG) DETAGGED (push domain back to registry)
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_ReleaseDomain(array $params): array
{
    try {
        $release = new PushDomain($params);
        $release->execute();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Delete Domain.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_RequestDelete(array $params): array
{
    if ($params["DeleteMode"] == "ImmediateIfPossible") {
        try {
            $delete = new DeleteDomain($params);
            $delete->execute();
            return ['success' => true];
        } catch (Exception $ex) {
            // We fallback to setting renewal mode
        }
    }

    try {
        $renewalMode = new SetDomainRenewalMode($params);
        $renewalMode->setAutoDelete();
        $renewalMode->execute();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Register a Nameserver.
 *
 * Adds a child nameserver for the given domain name.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_RegisterNameserver(array $params): array
{
    try {
        $ns = new Nameserver($params);
        $ns->add();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Modify a Nameserver.
 *
 * Modifies the IP of a child nameserver.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_ModifyNameserver(array $params): array
{
    try {
        $ns = new Nameserver($params);
        $ns->modify();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Delete a Nameserver.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_DeleteNameserver(array $params): array
{
    try {
        $ns = new Nameserver($params);
        $ns->delete();
        return ['success' => true];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Sync Domain Status & Expiration Date.
 *
 * Domain syncing is intended to ensure domain status and expiry date
 * changes made directly at the domain registrar are synced to WHMCS.
 * It is called periodically for a domain.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_Sync(array $params): array
{
    try {
        $domain = new StatusDomain($params);
        // TODO set admin/tech/billing contacts if necessary
        if ($params["SUSPENDONEXPIRATION"] === "on" && $domain->isExpired && !$domain->isSuspended) {
            $modify = new ModifyDomain($params);
            $modify->suspend()->execute();
            localAPI("LogActivity", ["description" => "[CentralNicReseller] Domain Suspension succeeded."]);
        }
        return [
            'active' => $domain->isActive,
            'expired' => $domain->isExpired,
            'expirydate' => Carbon::createFromFormat('Y-m-d H:i:s', $domain->expirationDate)->toDateString()
        ];
    } catch (Exception $ex) {
        return ['error' => $ex->getMessage()];
    }
}

/**
 * Incoming Domain Transfer Sync.
 *
 * Check status of incoming domain transfers and notify end-user upon
 * completion. This function is called daily for incoming domains.
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed>
 * @throws Exception
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic_TransferSync(array $params): array
{
    try {
        $domain = new StatusDomain($params);
    } catch (Exception $ex) {
        try {
            $transfer = new StatusDomainTransfer($params);
            if ($transfer->hasFailed()) {
                return [
                    "failed" => true,
                    "reason" => $transfer->getLog()
                ];
            }
            return []; // still pending, don't return completed as false
        } catch (Exception $ex) {
            return ["error" => "StatusDomainTransfer: " . $ex->getMessage()];
        }
        // we returned already here
    }

    // case: StatusDomain succeeded - Transfer completed
    $values = [
        "completed" => true,
        "expirydate" => Carbon::createFromFormat('Y-m-d H:i:s', $domain->expirationDate)->toDateString()
    ];

    $zoneInfo = ZoneInfo::get($params);
    if (!$zoneInfo->renews_on_transfer) {
        $values['nextduedate'] = $values['expirydate'];
        $values['nextinvoicedate'] = $values['expirydate'];
    }

    $modifyDomain = new ModifyDomain($params);
    $modifyDomain->setRegistrarLock();

    // Get order
    $order = new Order($modifyDomain->domainName);

    // Set nameservers
    if ($params["NSUpdTransfer"] == "on" && $order->nameServers) {
        $existingNameservers = $domain->nameServers;
        sort($existingNameservers);
        $orderNameservers = $order->nameServers;
        sort($orderNameservers);
        $diffNameservers = array_udiff($orderNameservers, $existingNameservers, "strcasecmp");
        if (count($diffNameservers) > 0) {
            $i = 1;
            foreach ($orderNameservers as $nameserver) {
                if (!$nameserver) {
                    continue;
                }
                $modifyDomain->params["ns" . $i++] = $nameserver;
            }
            $modifyDomain->setNameServers();
        }
    }

    // Set owner contact if missing
    if (!$domain->ownerContact) {
        $owner_contact = $order->getContact();
        if ($owner_contact) {
            if (is_object($owner_contact)) {
                $owner_contact = get_object_vars($owner_contact);
            }
            try {
                $modifyDomain->setOwnerContact(Contact::mapOwnerContact($owner_contact));
            } catch (Exception $ex) {
                //TODO use module logging instead
                localAPI('LogActivity', ['description' => "[CentralNicReseller] getOrCreateOwnerContact on TransferSync failed: {$ex->getMessage()}"]);
            }
        }
    }

    // Set admin/billing/tech contacts
    if (!\WHMCS\Config\Setting::getValue('RegistrarAdminUseClientDetails')) {
        $contact = Contact::getContactFromSettings();
        try {
            $modifyDomain->setAdminContact($contact);
            $modifyDomain->setBillingContact($contact);
            $modifyDomain->setTechContact($contact);
        } catch (Exception $ex) {
            //TODO use module logging instead
            localAPI('LogActivity', ['description' => "[CentralNicReseller] getOrCreateContact on TransferSync failed: {$ex->getMessage()}"]);
        }
    }

    // Update domain
    try {
        $modifyDomain->execute();
    } catch (Exception $ex) {
        //TODO use module logging instead
        localAPI('LogActivity', ['description' => "[CentralNicReseller] ModifyDomain on TransferSync failed: {$ex->getMessage()}"]);
    }

    return $values;
}

/**
 * DNSSEC Management
 *
 * @param array<string, mixed> $params common module parameters
 * @return array<string, mixed> an array with a template name
 */
function cnic_dnssec(array $params): array
{
    $error = null;
    $dsData = [];
    $keyData = [];

    try {
        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["DNSSEC"])) {
            $modifyDomain = new ModifyDomain($params);
            $modifyDomain->setDnssecRecords($_POST["DNSSEC"]);
            if (count($modifyDomain->api->args) <= 1) {
                $modifyDomain->setDnssecDelete();
            }
            $modifyDomain->execute();
        }

        $statusDomain = new StatusDomain($params);

        $dsdata_rrp = (isset($statusDomain->api->properties["DNSSECDSDATA"])) ? $statusDomain->api->properties["DNSSECDSDATA"] : [];
        $keydata_rrp = (isset($statusDomain->api->properties["DNSSEC"])) ? $statusDomain->api->properties["DNSSEC"] : [];

        foreach ($dsdata_rrp as $ds) {
            $split = preg_split('/\s+/', $ds);
            if ($split === false) {
                continue;
            }
            list($keytag, $alg, $digesttype, $digest) = $split;
            $dsData[] = ["keytag" => $keytag, "alg" => $alg, "digesttype" => $digesttype, "digest" => $digest];
        }
        foreach ($keydata_rrp as $key) {
            $split = preg_split('/\s+/', $key);
            if ($split === false) {
                continue;
            }
            list($flags, $protocol, $alg, $pubkey) = $split;
            $keyData[] = ["flags" => $flags, "protocol" => $protocol, "alg" => $alg, "pubkey" => $pubkey];
        }
    } catch (Exception $ex) {
        $error = $ex->getMessage();
    }

    return [
        "templatefile" => "dnssec",
        "vars" => [
            "flagOptions" => [
                256 => "Zone Signing Key",
                257 => "Key Signing Key"
            ],
            "algOptions" => [
                8 => "RSA/SHA256",
                10 => "RSA/SHA512",
                12 => "GOST R 34.10-2001",
                13 => "ECDSA/SHA-256",
                14 => "ECDSA/SHA-384",
                15 => "Ed25519",
                16 => "Ed448"
            ],
            "digestOptions" => [
                2 => "SHA-256",
                3 => "GOST R 34.11-94",
                4 => "SHA-384"
            ],
            "dsdata" => $dsData,
            "ksdata" => $keyData,
            "successful" => ($_SERVER["REQUEST_METHOD"] === "POST" && $error == null),
            "error" => $error
        ]
    ];
}

/**
 * @param array<string, mixed> $params
 * @return array<string, string>|ResultsList<ImportItem>
 * @throws Exception
 */
function cnic_GetTldPricing(array $params)
{
    // black list some zones
    $zoneregex = "/^(nameemail|nuidn|itregional|.*\_prem[0-9]+)$/i";

    // fetch currencies
    // fyi: GetCurrencies is not including if a currency is the default one
    $defaultCurrency = DB::table('tblcurrencies')->where('default', 1)->value('code');
    $systemCurrencies = localAPI('GetCurrencies', [])['currencies']['currency'];

    try {
        $zoneList = new QueryZoneList($params);
        $zoneList->execute();
    } catch (Exception $ex) {
        return ["error" => "QueryZoneList - " . $ex->getMessage()];
    }

    $results = new ResultsList();
    foreach ($zoneList->api->properties["ZONE"] as $id => $zone) {
        if (
            !$zoneList->api->properties["ACTIVE"][$id]
            || $zoneList->api->properties["PERIODTYPE"][$id] !== "YEAR"
            || (float) $zoneList->api->properties["ANNUAL"][$id] <= 0.00
            || (bool) preg_match($zoneregex, $zone)
            // Those are not real TLDs but the API returns them for the below reasons
            // .nu idns e.g. omvärlden.nu (so <idn>.nu vs <ascii>.nu)
            // nameemail -> https://wiki.hexonet.net/wiki/NAME#.NAME_Email_Forwardings
        ) {
            continue;
        }

        // Determine actual zones and underlying TLDs
        $tlds = explode(",", $zoneList->api->properties["3RDS"][$id]);
        $tlds = array_map("trim", $tlds);
        $tlds = preg_grep("/^[0-9a-z.-]+$/i", $tlds);
        if (empty($tlds)) {
            continue; // not happening based on OT&E data from user qmtest
        }

        // fetch additional zone data
        try {
            $zoneInfo = ZoneInfo::get($params, $zone);
        } catch (Exception $ex) {
            continue; // let's ignore this for now...
        }

        // pricing
        $currency = $zoneList->api->properties["CURRENCY"][$id];
        $setupFee = (float) $zoneList->api->properties["SETUP"][$id];
        $annualFee = (float) $zoneList->api->properties["ANNUAL"][$id];
        $transferFee = (float) $zoneList->api->properties["TRANSFER"][$id];
        $redemptionFee = (float) $zoneList->api->properties["RESTORE"][$id];
        // just the additional costs are of interest for WHMCS
        // renewal is included, but already part of the invoice
        if ($redemptionFee > 0) {
            $redemptionFee -= $annualFee;
        };
        // convert prices if currency is not configured based API-side Exchange Rates
        if (!in_array($currency, array_column($systemCurrencies, 'code'))) {
            try {
                $setupFee = Pricing::convertPrice($params, $setupFee, $currency, $defaultCurrency);
                $annualFee = Pricing::convertPrice($params, $annualFee, $currency, $defaultCurrency);
                $transferFee = Pricing::convertPrice($params, $transferFee, $currency, $defaultCurrency);
                $redemptionFee = Pricing::convertPrice($params, $redemptionFee, $currency, $defaultCurrency);
                $currency = $defaultCurrency;
            } catch (Exception $ex) {
                continue; // currency blocked - so skip this tld
            }
        }

        // IDN Conversion; WHMCS expects IDN TLDs returned in IDN, not puncycode
        $idns = $zoneList->api->client->IDNConvert($tlds);
        $idns = array_map(function ($row) {
            if ($row["IDN"][0] === ".") {
                return strtolower($row["IDN"]);
            }
            return "." . strtolower($row["IDN"]);
        }, $idns);

        foreach ($idns as $idn) {
            // logActivity($idn . ": to import");
            // identify registration terms
            preg_match_all("/(?:(\d+)y)+/", $zoneInfo->periods, $matches);
            $years = $matches[1];
            // Workaround for stupid WHMCS logic since they introduced the pricing import feature ...
            // (multiplying period with price is ending in per term higher pricing if we consider setup fee)
            if ($setupFee > 0) {
                $years = [$years[0]];
            }

            $item = (new ImportItem())
                ->setExtension($idn)
                ->setYears($years)
                ->setRegisterPrice($setupFee + $annualFee)
                ->setRenewPrice($annualFee)
                ->setTransferPrice($transferFee)
                ->setCurrency($currency)
                ->setEppRequired($zoneInfo->epp_required);

            if (is_numeric($zoneInfo->grace_days)) {
                // there's no extra fee for renewals in grace period
                // customers pay the regular renewal price and no extra fee
                $item->setGraceFeeDays($zoneInfo->grace_days)
                    ->setGraceFeePrice(0.00);
            }
            if (is_numeric($zoneInfo->redemption_days)) {
                $item->setRedemptionFeeDays($zoneInfo->redemption_days);
                $item->setRedemptionFeePrice($redemptionFee);
            }

            $results->append($item);
        }
    }

    Pricing::syncFeatures($params);

    return $results;
}

/**
 * Resend the Transfer Approval Email
 * @param array<string, mixed> $params common module parameters
 * @return array<string, string> process result
 */
function cnic_ResendTransferApproval(array $params)
{
    try {
        $cmd = new ResendNotification($params);
        $cmd->executeDomainTransfer();

        $msg = "Transfer Approval Mail successfully resent";
        logActivity("$cmd->domainName: $msg");
        return ["message" => $msg];
    } catch (Exception $ex) {
        $msg = "Failed resending the Transfer Approval Mail ({$ex->getMessage()})";
        logActivity("$cmd->domainName: $msg");
        return ["error" => $msg];
    }
}

/**
 * Cancel the Domain Transfer
 * @param array<string, mixed> $params common module parameters
 * @return array<string, string> process result
 */
function cnic_CancelDomainTransfer(array $params)
{
    try {
        $cmd = new TransferDomain($params);
        $cmd->cancel();

        $msg = "Transfer successfully cancelled";
        logActivity("$cmd->domainName: $msg");
        return ["message" => $msg];
    } catch (Exception $ex) {
        $msg = "Failed to cancel the Transfer Request. ({$ex->getMessage()})";
        logActivity("$cmd->domainName: $msg");
        return ["error" => $msg];
    }
}

/**
 * Client Area Custom Button Array.
 *
 * Allows you to define additional actions your module supports.
 *
 * @param array<string, mixed> $params
 * @return array<string, mixed>
 */
function cnic_ClientAreaCustomButtonArray(array $params): array
{
    if ($params['DNSSEC'] == 'on') {
        return ["DNSSEC Management" => "dnssec"];
    }
    return [];
}

/**
 * Provide custom buttons for domains in admin area
 * @param array $params common module parameters
 * @return array
 */
function cnic_AdminCustomButtonArray(array $params): array
{
    // load registrar module
    $registrar = new \WHMCS\Module\Registrar();
    if (
        ($params["registrar"] !== "cnic")
        || !$registrar->load($params["registrar"])
    ) {
        return [];
    }

    // load domain details
    $domain = new \WHMCS\Domains();
    $params = $domain->getDomainsDatabyID($params["domainid"]);

    // Special Transfer related Buttons
    if ($params["status"] === "Pending Transfer") {
        return [
            "Resend Transfer Approval Email" => "ResendTransferApproval",
            "Cancel Domain Transfer" => "CancelDomainTransfer"
        ];
    }

    if ((bool)preg_match("/^(Pending|Cancelled|Expired$)/", $params["status"])) { //TODO
        return [];
    }

    // Return Buttons for manual suspension / unsuspension
    $params = array_merge($params, $registrar->getSettings());
    try {
        $domain = new StatusDomain($params);
        if ($domain->isSuspended) {
            return [
                "Unsuspend" => "unsuspend"
            ];
        }
        return [
            "Suspend" => "suspend"
        ];
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Client Area Allowed Functions.
 *
 * Only the functions defined within this function or the Client Area
 * Custom Button Array can be invoked by client level users.
 *
 * @param array<string, mixed> $params
 * @return array<string, mixed>
 */
function cnic_ClientAreaAllowedFunctions(array $params): array
{
    if ($params['DNSSEC'] == 'on') {
        return ["DNSSEC Management" => "dnssec"];
    }
    return [];
}

/**
 * Client Area Output.
 *
 * This function renders output to the domain details interface within
 * the client area. The return should be the HTML to be output.
 *
 * @return string|null HTML Output
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 *
 */
//function cnic_ClientArea(): ?string
//{
//    return null;
//}

/**
 * Return Zone Configuration / Feature data
 * @param array<string, mixed> $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return object|null
 */
function cnic_GetZoneFeatures(array $params): ?object
{
    return ZoneInfo::getForMigrator($params);
}

/**
 * Returns customer account details such as amount, currency, deposit etc.
 *
 * @return array<string, mixed>
 */
function cnic_getAccountDetails(): array
{
    try {
        $statusAccount = new StatusAccount([]);
        return [
            "success" => true,
            "amount" => $statusAccount->api->properties["AMOUNT"][0],
            "currency" => $statusAccount->api->properties["CURRENCY"][0]
        ];
    } catch (Exception $e) {
        return [
            "success" => false
        ];
    }
}

/**
 * Get Host Objects / GR per Domain
 * @param array $params registrar settings, plus hook vars
 * @return array<int, string>
 */
function cnic_getHostsForDomain(array $params): array
{
    try {
        $r = new StatusDomain($params, true);
        return $r->hosts;
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Return Result of Transfer Precheck
 *
 * @param array $params registrar settings plus hook data
 * @return array
 */
function cnic_precheckTransfer(array $params): array
{
    // Domain transfer pre-check (apparently only for com/net/jobs/org/bin/info/name/mobi)
    $error = false;
    try {
        $check = new CheckDomainTransfer($params);
        $check->execute();
        if (!$check->wasSuccessful()) {
            $error = $check->getErrors();
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
    if ($error) {
        return [
            "error" => $error
        ];
    }
    return [
        "success" => true
    ];
}

/**
 * Suspend the domain name
 * @param array $params common module parameters
 * @return array<string, string> process result
 */
function cnic_suspend(array $params): array
{
    try {
        $domain = new ModifyDomain($params);
        $domain->suspend()->execute();
        localAPI("LogActivity", ["description" => "[CentralNicReseller] Domain Suspension succeeded."]);
        return ["message" => "Successfully suspended."];
    } catch (Exception $e) {
        localAPI("LogActivity", ["description" => "[CentralNicReseller] Domain Suspension failed: {$e->getMessage()}"]);
        return ["error" => "Suspension failed. ({$e->getMessage()})"];
    }
}

/**
 * Unsuspend the domain name
 * @param array $params common module parameters
 * @return array<string, string> process result
 */
function cnic_unsuspend(array $params): array
{
    try {
        $domain = new ModifyDomain($params);
        $domain->unsuspend()->execute();
        localAPI("LogActivity", ["description" => "[CentralNicReseller] Domain Unsuspension succeeded."]);
        return ["message" => "Successfully unsuspended."];
    } catch (Exception $e) {
        localAPI("LogActivity", ["description" => "[CentralNicReseller] Domain Unsuspension failed: {$e->getMessage()}"]);
        return ["error" => "Unsuspension failed. ({$e->getMessage()})"];
    }
}
