<script type="text/javascript">
    $(document).ready(function () {
        ["{$fieldsToHide}"].forEach(function (fieldName) {
            const input = $('[name="' + fieldName + '"]');
            if (input.length) {
                input.attr('type', 'hidden').closest('.form-group.row').hide();
            }
        });
    });
</script>