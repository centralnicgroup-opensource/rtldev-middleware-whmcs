<?php //ICB0 81:0 72:c09                                                      ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu2gKgH6SQUB7nt7Xq+m1g4SzOCQLEWXp8Yu9so2uFpE8NLtRqOwg+tjya/wQ6SHCtN8dSw1
djhlYxuT9yZLj8tcRw7ECL8u/zDv5mxTKKeiq1+dCKZu3jHojIKLRww5Wy6A8+QbUZkHOhv1kcGq
3f9KTr3rAmGcAM2SC6A5lrM6c2KQsSeGwVM2fXGIv7H1YNpEMuUge+kMK3A9TQ/8MvBhakOhs9ew
hod3vsF7IsFlACQSUIsKWk8GzrITi0Ik1w7UuecpGqK7n2tJYD+kNV0B2k9fvukovfj0j3UBMq0V
XKLVMHCeUMPJ9pws/rd3kaket9tVndBsgUTZXBE2IvCC4mMuFod/aFeEWFrRgfFtTe6wy6TlLHJN
6edhGXCi5Jbr0yp37n6Oy1jC/TDCycW/SzhplC/ifDIu6uOrdpi6fUGH2A01i8IgLoJ9dcQjyHUe
xRzMZTlYei1EAn2FdlL/pyjkpF3macNhrqlHpe+1qSrOtrgWEJfjWcCwe7GxCVu8lxiGdFmLSZSt
kTDSSXAk5PNK0c1QHPRa8zXzK1/869uGYye+v48HfY9BvGwgTNFAgSoMii61Bqn9CIiI6sVy8w4K
orK9J6Eg7AlOhgta1QXXmEpWkCNjPfwB4no36B2G3ygn20sVCnIeC7s3QRjNWCmmSCsGTRidyfvu
Gt/bZBjDjbxN6Yzkl4sUPq9ukfIdEV8ZPdlqwUTZPwiHetOOuHIFRSYcx9Xi+jek2WaREc64VAEi
JUP+2yut9is/M5n/LayeElqekdM+cjPbwa8uh/ZGaMBls/cCGWs11OMs6hIYFbO1tA3za9pzZJZm
p71NpWwh0EcOYo6fCV9YO3vKDxlIIxLOgG3Kt5K==
HR+cPoz7Q7I1b51yNFdzLpfS2obNXZBMfEV1cucuP6smPOZeoyhZ2WJIjnTHa2nMg4ZrENH+JE1b
mINILr2S9Of3EdHIfKJ4I5Ovj9fLNvbIuHO1BhcHgNMhHqcmDVV8RHIH50+VcljxQn9iaKvKIu75
KpY20QgqTv3FS3wj12In1Ne94DrmCLVXIuyOowiPYH0ccLD+NC90/YgZ775tXZYiB0JAapeMy0Yy
qG7O2txKTEHh4sRpRO+IxHy8mnb0wYSz7bYiXFG33n3+Qe+d7+rbPutlIt5Vm+xqULY7Be8g2i1r
ckTS/u31Pcq03Pd+I2NaV7Nm5aerOnTVybwi93K+hQoCgePlTWX8CkDKEXddQB5tY6GZbLKr33yZ
8B4/dmwiS4iGEnESd4krlONzh4h0tqKVuKeL91yV7vgY7Qe1sHWSnYZmlx8OLl3hfRE04vE5HuWj
TwYYvGLtAvXg9+wVyVAyIWxFOLCGY2k4HDhRzZsF8HsKEIrS2+YkJxmlTpreHaoF01Ynw+yryDme
eqF10SI+qxVEYL7A13int2PAW0bU2NcuPwk2VYYm5looG4vzqrMHYXgS4B5BlOyQ6IuTBo0mplox
X8cDZEHQsnPrLEyEcEQQ+KSatpd5gm5r3A1sEDsmVIsUrYS0qGQ05GSZB4vR4nDsyqQcgjjHrFf7
gMeDSOeGI/YH5fiEOEckr/Wa+9uFSlVS/w7OC1ZT+TzJFTXM/zLbKOw354zfVpY80fKJ3FSBX1Cs
GEJlduKxlJ+KrUAUmncNyFZFtCR+Rwgk0zOtbbGQUWPM+7eSGCpuaOMwLN1+L9S8s55IwY26YUgq
/W7cZaZ5OWM4JzB9BQNZzgtFxukdLCSwbW==