<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpcXvlhJYDlzgXPpsJ0mB/L7jUqTkOtoVy5kudA//bFTbwJUbrpMtZ7bO3Vhmb+kAArietQh
m+f2HLNj6y9JirDo/1A/tysNbxknEy5K+mMaXTvkG3kIhPBJk4hiAJPref/HkxDmo2qfVwyLuksr
7wBXQb4aYq+2XiqgBGCdS6p74S1ETl2/Hs+hIKt1gVxaxFD5JiC7VTnbElELRahrMZDh/ARJ7Dgs
dmm9l7WrID4hphJ+FHDK6t0sfTZEY7q3r3LE7XeUUmb9gXTe+Dq8aRDcFbvFRvFpS3JXwrjBN6Uj
vxfbVlPWTbw6NDZ6bniITdvqYSX088knOaPBcYRR+YRojvLKVur4hdjnorK2LhfEZf4di0I+rWnM
o8lnAFTBCu9FlrzdBtyo1vDoKtBB9ekmWq+S6xtUTKsLgC58aHXhojXDd8thpGNcBNNeKFXyS/Ut
PzcFsDT+5u9gtosz+T5J3TqT47VKHXFWAJI5hBkHleXfS8J+ZpemQGd2ushiFrpwXRgRBgwOI4wS
lnLSMOF8vIBTr73O10k//63mBORMHh6OJ+WCPrZ30+m8MlRnK29XZlSrXOwsCNV0FdhbI34Q/WGQ
ptnCAphI7FBzzu9p62jBt51JVOqM4pgUjse8PRMb0qiI400LdzSh8+ALX4c8ILN0M+kEKFGr26D5
P74hKwdrcLhZAtywlsGbMg5R8bN3CjsbAUG2kWEMTx9jAMyMZl0MbaU/lcTKF/HCUAaGzcbwp8CD
KouIkt9Rl97kvXegAW3nSzJThxVJGOBVurDZv6pfFjDZt/OspEjIkHoci7sAwQUolHiRKm4HAV09
hr/UbGwAeolgOmNqxNS4ukBSTo51QSDVohx1pkgI