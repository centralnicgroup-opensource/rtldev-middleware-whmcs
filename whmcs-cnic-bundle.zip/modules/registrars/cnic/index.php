<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzRynM23HZvNMajGGpUCVc5ip8AOlS4HVPMuHJXnT9rKDlJk15HSo9UHXrmFUnfoXtoak01c
SfLgqQ9HGwIbXhh7YhZOdsF9iVZJaQOLU1NYueqZ/SMugJr7JehWV7sc4dxbFsw46A9oBDW4Bijx
4iyYV6vtYyeP9Jytkod7sbrg8bznwbytiMhvpq84VAk7NAOsYShL1GkirMvQuP5sLUuDrp2m1dEP
A1nrkgLzX4uIkNQRxdqJWemfPMQZ8cVDGDeRPr7xiogPqoBwarRZit/zaindCR6CP9zYCL8fAwmX
2ATNdggQJqRRJ/xPUtmoU1/MwYi6EGmh2srfH9Ux81urqK2C0HWAiXNAiYG5ShQWHOQQfyb3hlEv
R9Aggyo0vD1lnPXx9f57vH3v1JNC36irXN4qv8mbXYhN5Cg2b+gjMKTDiCFT8uX5enbuzUSYIg4z
/iAo13tpA9jkUvICa30a2rAN63lz4DPWUtHtgWI4JIf7YJvJfnqnSThOqCPYT1bDbxqAO9ODq0D8
mOGhPaKmImvsM2t8kf3m1Vvz04h4QuXu4ocm+0VMjrIGVqbQvXXEteWZKuvnlsOpgxLa/yvjDDk9
TgVxrXFpuQkCXfJfDdTQ7pR3HkcKBFFtO17yjDlzhn+ApW8anc+qoEL3dD6K99pXzTMvOVitoCEv
b20YJCJqbWPCsXoVrZuIWcacE/HTec8SPsxKnRElwL2cm9Mi0E1TCNjtK+ss/WuovWUhTkjCHz/M
9HolHRKK4+1qUDIN4d5St9Or3oIKXhPY5I9+vyk+wgZrzQvoj6XDFkhXrKvSu89uIoKECpD/hzwp
HeTDahun0yO/pOUzImep477Pf7HEMlX9TGp1Ffj6kF3Gnsa=