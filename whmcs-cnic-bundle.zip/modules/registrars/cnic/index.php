<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq6Q0JenOVezp2sK6PKYy2JU7xDfQG+jsVuDlb/+QxU6dVtcGVJnaUAaRap+msgQohsvPopf
gUn4CEqMDSS7MQB5+gsbi3rqlJzYaLBCT7bYATpIPegOaYC2XuxuqPtoweGzjSvud8w6TAqk36zn
YFBArT8QWbyFu9gcTT1Ov+EVKTFSq7fXxC/CzMVs6x0Bx+rasLYgAuDnQyECtWwGEz4/Pu+q4cBa
Kh2aUC3NYL5KUELaTKfIZWiDoVmnVAp+3BMhGH1RRMkoRUV7yFk11RNR5+SsnNEC75AhA7lJSqeb
6Iqx1oL/BSm3huFSxtMCvq1nChJAP2KjIaPzlZfPrCEyRl6YLQaz+Kxo1wuVy+lBdH5i56gPdavV
WSJ9XZNvReBRIxvtJw81y3SL22fbvwVGJveuyAaUn0EJfyxYCGd4krjm851CDIqquDUNTEtMhmQi
qbgV6FL7CDjGI8oaqj58b3ViFeNuNLRXXUydaDSQ5rxCVo+viN0DGCUFx00mSwdj4+UlqRhf/XxB
cjZ9NXqmUgK3CuOo49ak0NJLGJJ7COUOk0Z37WBKy9OU/ATmgxc3gKSqW6Di5BLgmwsB1vrVBXEy
tNA2YlIHv13r6PhhOXMFkMzrZcHh51ehTlkX2RaH+qsQas2Hlg0mry4cHPwkh2zyo/VDuoQs+Ez8
gEGTLzTVnjzc8iAzyEfzXejqzVaOO77wgpGH/S26lswsTEzjfhyRreJyLOdayFjydMdYsKptQu8N
n5aob+Qvt/YFkVzac097iruuUjh6OfK4UgfF78zGLW84OYuxJKf28jnmfWWvpsEPY7MHZm+RHAMV
4VT6PscrJ0UVDvdJSzh2MIAADrJl3sWVtGjnOWuAhRA1r+u1