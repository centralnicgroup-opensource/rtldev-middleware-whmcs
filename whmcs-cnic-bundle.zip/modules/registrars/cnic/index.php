<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrDSUOG/fq6inklifnwq2liwfS5rKJVCCfgu85Qd+D1I4aeKZaEam4TAIT4NaFb8tm2dZb9J
bS/B3WXd7aIgw1Yvcfa7JnlCHbWR4emreeR+gY7lToXtN3w3A+2zl5NUNb8aSKXovJsWOYZuuWUW
9KankXBBK8bezWtivhD+sZ3TqH2/b8T2HbC06vZfd0VU2EZ8YwW3T/ABmFl7PQZ3jQLSvy+tyhU+
YBxHyBHm7Ulb41S0bdd1PmIMggv26lFmgiuLFHgssC1YTuRUSO5ryYqJAd5fgJ7TKCCQ77Q70IqY
QCSsItKHczohYVNhHeviOUpqB1sW54/wsAcxoSbpJvDkSoRYIveIj3dr0d6FaFgEAK+rFpb2nVGN
1naiJpPyxejKE0x8UlyG2pUapqKFtPRLOhFWU0DsGdeekrApeaHQ7cSN2RvaXMjmsTDwDln+CreJ
QiyV1N6lNzOmz3Fpt0uYt6gT4l8KXFXINlMFrFQ8X3itXhldacGRBYsbK/QSJbz8Hae5nxx82IMI
NkiNxkbd7Zkjymq9lXnpD6rfir6IIp7ggU+VgLUUP3QCWBTQxPpW4HuTEpIZ7LnHQ8C0shmv+p7u
Arq9dAmPLuYdZZrnpI//qxI68mogXYOgMcoPwWbLtoggM6YUV3K6O/4fTjGq0ROG5zcAC3E3S30A
MP065hbppS3lakbtoUV59Yg0+95s95P16uKCo7Gb5Dgj4qoCfDAFBbZZB4f93JDwVxAJOZ2km7cl
hzvcWJW3kXFv06DEtO21BEzC00dCqwWBbEylu7XB9ivTpkwnxcQuRgUEkRPpjHI7BPznjFf+wPdr
7LbcC2C2OY9UZ8nRwJNf3na5JadL1akttiDcUG==