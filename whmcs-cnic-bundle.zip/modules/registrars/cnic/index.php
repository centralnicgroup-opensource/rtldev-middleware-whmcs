<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv6PH3D7OBq47YxH44X+ed7oOLyKD/yHg9wumdxxORRjKjlb+hKcaT0S7ZNadsNRrjbhfkFf
EwHjJwyaj4KK/PTA6FC+jsUKGEkphtIUZSZc91ucJBomeQge40J4vYHtiHc/Ql1penB1uFvcbcDD
3uJibwNF8CHqdqT7d9S/4Ufq8Zv019Zlf9W36RUqFhsxVx7SY9RYDlUfYZQyg46Wj+tQHvLYu2d+
GY+0pJXfIHolyXKwCUEEuWWQJlyAyBo0J0DSgu3L3W3OXwtmeEhzGSlm2RniHuoD9i+Z8olObURW
8uSOc4eF8PFnhqXXzmCXK4u4l+WQcDA7ZnfUxKzWpU0NF+N2ngpnYdvrblr/uwoRxIFkv7nnx4ba
yGkLllMWGY2FbGqVsH6+vjsRayHvadVe75Owv+7JcD89Kxg9ehlg1Fymk6u74MnWGZSIA2g6Bto8
vlaImbNvFsULQCLprlWpin+hmXAtqrECrccZFKlpFpGLbElxSmvJfK2ZcAvy3akkbW3O4VH8N1m6
VGeRd9TW8pSdB+/CbFVTfY+7y3qG/lUaj7U/Ld6JBICZcTQxHoxrw03PW4maCorNMvewD5VbjCD6
Pfor5mUUfraQiC8zgTGIj2MTxMLnOycmc58N4RRjbMCIGq+28NDSys6Uhi/IY6medriedThBfrgj
hhyl8yzGB6TPTwC/Dp76yuigwBkum+McnJM4Hep5x6hzlO+W8zwYmuLww/xMYuFYR2PXxA1Pbf4m
1MQ4YpqGzpWWqKkRTk0R8TI0BVjVPkYQ5/gzXdfigg+aGEn1dxRQ7Yy3A5Xj4XxV2KiiwaiN2EQV
urWtHxV7y0l662AtE5aBdDWzDec6ff+abC6LGPUajTJ5yG==