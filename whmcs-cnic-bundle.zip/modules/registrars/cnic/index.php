<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuZO+rX38y2V6czkUyQvc+R20skYYJlPpiU1qnT8jh9d1yCwDlFVmhny8aUqX6rRNEni0Hxk
LZ/y5sSBFq7hwfQk9XdyO8VhjdC9V2FvaeDBLl26rAV0CCXtZCcYOx/UIQDEIz4/O1bUiZ3E3Uxc
8f0kdekPbGj3y7gszDJdcYglinjZq4QBfo/aAOm5BERYnbv4pWxSEbu3qQ/JipQdgBLabWR/wYtL
hINekVdMbX1APP7Qcyn6eXXHYh7HP56PuJX+CepIR0DWzI2v+PfX+UHitz+/R/bwqJgfsyJsEqei
fr778UovOb2BHJ5Tc0musfpxvz9T+m0UKgGMuHk2kUN6+5GBrl9nBRRugmX9CmTxYoIJdsWuQ/+h
UH6KHpaCJ83Cn2VAilFNZqiRUO89hU6tevKMpadjH73OYH6PTxR07t6dsyHrUoYi2GaKOSKkDHIg
t45e7bhQXqTVPbgXtu+jlVvql3vMVIOVQ3j/KCwLOIwyQ65H6lSwoQbQEvMtFUh3ITqiZSSq7FkQ
DPlNxenzKVydeSSVoevA8CQ9bS2GfsiK0Thh3VmjjFhMVCtoJpHSY44deC92dd2UFZhKx0n+Bk05
xX7zNloPKmxDRJgTEu4TA1AAM0CJUtVUXS28j5KWQ92iFLfpdYeNfDbpqVA/5DtbO79mVwS5KzbK
reQXSeRggIulrBUrvNlsw18wWXJvlYSE8qc6PCo9FG8vssnysZXWV50JZP7R9Xh49wSZLu6vSvNi
4M03PTeBcLXsZ55EJwI4E8X5iw3OlTtd3SXgmB2Qx2SOs/apYfoYE38bhIHRLJho5HsKO6Tm5/F6
tE1Heow9A999VTi8CKCdeN8wpZjHV1KditJAeHS=