<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoo39GYyRfulkJImAsNcTfsgpbvX1IU0/eAuTSU4Y5IwnBFzJWvCj04zsMxsOk9lH6dHohmZ
eRAMtTXnKPg5hOIHbbHi/6zlWCXryu1EWX0055bONecNk9CTlzTP3rnOSbbI0zP0emA3ljT0R9hb
T0E9yX06v9dBTgLfyjun8QtWPDSabDAF5imrn6Q28b+3ksqFLW+MZ1THpW4WjpyCVETrzLhCofj+
xD3PL5jy7L173wh7IuW6huNQ9KQwFdsA2UjDNazPctGn2vxb75HMiM0PiI9bxxwF9in7+y/2KRO6
dITS/vheAyGLvSMaTre5ZgOlNYece0o3Et5hYD4cVuzRqhC2b30qv57NN5WPTRQBRlppIjSgjuW6
9J0Z8LrRuf+y0zXNkgHrD8jmBP1JvYqb/PmsJit/nwJO3SkQpJvID8//y7bNI1aM2S6oE0CY6UAf
D7Fjhz0QTfHv82mWDr4LWHG4QPPPSfNCPZPPQxffU7t2QYBv7t/XdgCwO5mkampzLzkV263PztLr
a7EDPQSz/UCvEBJT90w+42y0RgK1oxG5uBZHNZy8fc6iEydY5Y1o62CA2jm3H5PKuS/zo7jlOPMT
IB7gGyP1JjcBTnKEflqxvdrHb64MRrDxNK1Z2jginNjdlZh6f0RPfGPn3OQRyOO6t4YxQGuwhh3d
/UiWG3LNynt2whvuN2xi67j47ghXh3UHZXCfmi/AGe5inXFBHmdcIR/vdSghCmumBFizITIv183q
f4VlLig/Znlbss9iif+9PRpVyyU4n9jJDpRNlnc2TseiLvaIAR9MWDWx/ntQxGqmqokppwhSreIc
Y3M9p3yoCD++lJ+5yXVKscwj8yx4PiEX5in7WW==