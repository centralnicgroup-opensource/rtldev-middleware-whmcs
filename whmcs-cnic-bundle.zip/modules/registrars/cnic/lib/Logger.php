<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmnI/VEVySN4PfneqCNsEYu/Hx/3tYMhWB+u93IkpDXBnRCuWmbyiidqJzmsO4q8bUTuqAuX
teH56qEsDCFhqN1QEmulcaKIt7cIKxQjUlWhiP3/nV4RYa/VKifFURrrDsZ4RNcmN/Uqop+xskl/
r0cTedVvcIuN5x5ayPKrZ/yA2sha821Blanxv+jo4pAYP7v0oPpDVdpX+3LaS+dsjZOo6/7xC06z
g+wtpVCOFy/TzWDUeHF1o7PbTScHW+9qL+zQhLmNTQBmEO+CXpAnqZy6G3LmYiW/QFNNFkjD4Sv7
/MTB4L4uIrwTFZVsAgF/PdqUQY70YnvnxQ12qFdtMhNTEMu8BX2tuxHi03Yz1N6++PoqcxveyGEU
WrfVoAv/B0goLAgVfdQrRNqPl0XXWmgrAA/PsHKqrUfg70kErFinQ5q0W0h8dpap5Q0xfbzE+YmP
/aWoEPt+AWpsum1NL4wveLt5PnbCNPQAkNIfNpX6t2SRVdvUgSk0lVhT3Z4LsTzwOMofNd2I6wPI
sweSvApF9p3sAkt4cZemide/2CnqepzUr9uUvMSAgDP8fc+x8HaYD6WOEoJXT213u84Dmh34IEb7
q6h9tFTUqxZ7bSjoOxfLUiG5wOodQD4/Yhp7FWzM05FOhdp/H2FQX0QsIpxhMNUWB5gGAahK/VJF
Db7shxBhsSOG98UMLKRCHSLFd5WPPbiR1jRFk2o5YgUyrHJHYFQliZ3TIJN69ZLUCxWR50Co9nzo
w+2KSgFax+pBsT3SQzG9GLbEp8prdsYAUcLoHm2mt46b9YYaWPkOO53f+SqQ/uDLgJba51yv8246
/jVCylDsRL0z2Z+qUrtVj9oqoVHE1l63ImouMGneLsGPc/WJazLrKl2uRbcLk6+TGTMop94w9Z7Z
QSpXcsbzIQ8guf725+J2qCEAO34v2pNe/DVVAIwRye9sjkHcZTGuEpOge7TSewH94ul7ZdljCqXn
dvNkztOA9tWvdoS654VDBzAhrVum8khaYbZcQuKRphsppVaxGkqal+prpv6K5m/JhzqhmVte4fJO
mpEI+X1s/3wFj6CnvDgz1UHgWVE7D6AhSAT8U/o2oXmuAID/1+sKzYW1xMmuLY5muVyuMqHRU0+0
u6dQ1/7HdDTcr/aqnD67KYs6eSAJ7EodMAH8B7dDXDYYw7A9vW1fLWtfH0xYThAnj+P/S9+wtusS
447T0CORIdNaMECsHGKpp5GbYQuAJ9I3xbOiUuxHAWjlAOlPwvyr70krYBn9IsaQwTx6S5eCHUil
LrUIniQkiLpvWm3PrD6Zxuvop6CfMeNVV3/VlXvSZjzeTcRFjIiaWtpLIn7wLY7CcVx1K+Jz0Eox
mLOaKcYD1OQNScz3wBa1eXa3D1viNgLefhH0rg7FzGUP/T3gLShyUmSOlcYbMbnKZaR0hIUqjZ3c
/CuWctkCniFekUJFNh3dni1ElU+mURTuyKMw9VsDsUxW7Gub2PWtn8UPAMRHhDnm6jDLKNmd06zE
X0XWUxZrmP8bKuXpBgG/Un7nLO/+z1S6diLsWRNftgjCQWkCT+y04QQ6JJJfN0/lXsbOdn8iuqyM
NoPbea9uC93f1DBaWb80xhN5BeT7LcmEPS002pN4b5fdg2BHe7Bd9ycnAhlFW22AsE8zShlVJ3xt
vtYqL/XZXAitstqsxKmQVi4A48sfE5U8an+0qkoW6+oWJHbfoNvQFY2CvexcVRSKeVwaKIuQHSw0
kj3gqK5fJOKkvLgY8QS150gxRDh1Sdn0kAKUd93jxSX3MEpccGtpSwlRWN6+igc++CYfmeg2gvv+
xJHoqZa4ORmJTUAF6KKoV5f4nB1EgVHYHAYDWoFeN2Sj+jXTozU6r1jO/h3PtJ8iohcKBaNQkomO
djTZJhbKd9bYSHkKPUufee/dkLmqOucgQO0G44txSFuuwm/2fwDjhD5PiTDpsbD+CP8QKC3n1C7Y
xTgTzKChoHbQCQSvZlObtYazs5vIMKtn9sqqqh/IAQikwaqEnhnjKA1rS4BiuotItHPxYdtf7ljB
uG2eQeJd14e4DQwz9cVo9XTAR+pXg0W6P5ykL9nkFweVZXdr3DWLlMxjaiPEhEJL+oMqY4+nUMer
awvVyEmlx+ANiZ9zKFQ3KJIturFoh14uKPs8KLDKKS/4j1EJH/k+c4iLgJ5H2SPoKG2EP9r3MK72
Eb3Ubia3Wopa4HC13gVPtCwYfOZinuzGo2c3fGO+X7lQLLUAq6TsceBoUeEj6Ucqq0RqQJPxD7G2
/UOS4A2BqOPbwBNXaoMdIGGRvEo8D2m8LyPDuuQGfCHf5USd+9cz4psUmdJwrsSi38E1nN20QIP+
+kgO1/QP3pHbOpkhvwAzD/PViCJ5UsAn7/yrItELv9Un6F/qhs6ES/oR+rh2BxfmRQnEPMQBzezI
gvhvpO/j3io2tOG4b17+T/d7HBpBpvqYfOrmY/QlHlVvnrp1oqfLVg+t6k2sFmP7JgOD4MRPSNXV
2gXnEaz1Xn/irDns200GNYYGIYGTg2OYCsfAOH/7s4JQ0D9YPgHIaUD80p2RhiP3SFWIQbF/cS9i
k056rddsSrX3jjRc1xYB+JhdycyTXlNH/ECq2OYMehxf769OegdNe6+Ti+0tFKTqn2VHXld7Wr8G
HbSG/5OFFdTCnq6bQKPGLFiZ2kcrivol2or6O0ORRWsEXEI+4rMGPrDOl16Flr2jmG6NUP9BP8TY
SJ34K412gUWM4tl9uGoATCSv8fulFajuTwpk6sskH9Hh09W+qCH2zR8PEjXx1ISBeRbkdz1O+0PE
bXIUhFDZEtDqC4s1W5huE1fQt6k0HfteucgCCTldv4kGBoUFN62FmIwBwGQQkp9sDP7UHVkwlbZK
7IrGEf/xdTksqYG31uoyeUZQ7q0W+VTZJxyoXdCHYS/y2ZrhVeJ9V342nxhmJ0p4DuyGNDINcLkS
eIvCLicTN1Rn+IvigX5MDE6qpvwEH7lEz5gsighOUd5aykfw+EPvuC3fdvUQIDWDmVG+3oFxMWZ8
rV+ysILQ0aiB9fnvUs8nk9iBIHdqox3oWrJh8Gpjl11kzKNxtfwbPhnqbH4pfB8K0PkvihBLHSxi
4eV2imjEeBbN+C8jyb8ZfIDIhVCD1Zz0W6QApefWst+Uid+e1Mc2zAvhctOTYuNbiwFJJg64s+WR
VnR31eHQI7B7vU3gixAlxSoT17OqKEja9MDkhUdPP44Ucr77gC6rDF0mpMkqZvCI33JO6DxOmhFj
iqj5/JNeiw9HZfmgKqV8+GTcaL/XiahJCxSepzc+R1RltyuwTlBHP8q/uxlmKYgBzFhZKBAclyAD
2iEafBkDB9CuRGHazGRkJiTCwhG4kMOiwAFXZ8K/AeE4dku618uslicOBcW=