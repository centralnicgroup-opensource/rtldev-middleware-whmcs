<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+18y5h26CcTcuPbUPHmsYFEQamPs9ezOwIuOa3LZB/v1vEfBXnVEcHTwHI+l8EWcCMxPlxj
i1TDFf0SzvVdH4ldoPfYrnD1AXVC1wPLmZAco7F8SwrehGnMD/9SECGu3OjSe7/2KuJpMZ4pTbuW
GmMpitbz7YC6Ys6/QlUi1wYwtFwO2F3Rlb+N+bCEmAA85KNHlA3PiE6mYM/Ltjg0eLgulgQl5OOB
woAA60USEloC2dt+4ZH/0e5Ivh1CwFck90C0NazPctGn2vxb75HMiM0PiJLe/ESajWEWhxippzRc
YITt/twVb6PfMNqsTOauaKqn5POVn6tPzTCoCsYsIChlny7NQzuUU46KFI3GXINJXIUOcA3JFcwv
a5YCH9SE8ahTUH7BKleEp/BaNz0lGsSU3pxdaJu9yLZ7XG29/JK8NIBRlr+3/hx0io3ygFxuV6Xn
nWZl8Jux0UaghcB5yjqG39cmpAO9Srtih7ZRbYxBvTFqVKa9nuccM36QYdAUaB7ZrmzQb5G//IC+
5VgdH/jqaLXpr06QxgQDa28uY4l+iJ8f7gGPZVP0AW3QeKyhxAcF8EOR9QQJkbLNKfamdc0ULvrh
K8SQLwjs29OGZH0Q8Ax5PRAa7Ru/tQGmYi38qpcWGNd/wAMwHYNZQL46JGd3xGThisBm+zhOc/0h
xxjE/FKQrxBpvErtoM/92JG84LFFB+KHUCRZXbaWdLOPzAkAQHKuETtNRcyBsw51SbuMHaBEmRC1
XF2viWsASyP7vsI1r9NekTjNKVlSy5DZrYWp9k9sQc7S9b7Nup1oH8/uumYq49LzN8/KGdI+yQo6
Q6YZZGDFf6b0kNfKpkxkxil/md8C/UMCV3Xs6HfT+xRgm+AC+zEL9nK7lS4nT09/p/f2PV6sJVoR
mUG/Me38a5TVCtugdonrlQz2TOIjstr8JuCYebd5YNuZ1KrX5eMTwK6X0wwQUhX7sp9jADiADaVL
AxGjSg59oo9EvkXHM+xutGJfe6M0LZI7OtrN7UV/8I0C9PmgcaJnkfYQ9meLD2vVVFS6waYbXGdo
yO7dIoXjJ45h4xmwrQy9ZR500Ghu1s6hGAylpERHGcL2J+n2h+f8LeL8YkdaBumDJDitwIGI7Hq/
CMlyEQLcpgBP6HERGTLuZwmjHZXpPxcHfeuTqvff8gAAWTGkSvPwqzLeW3sPR+OeIjiiWPA+B5tn
1greE94L2EEJL099it9c2/LDugXPXiKFvl6Ld4DNLbdIB8hj9W2zQGBK3CmRTcxLAMhtoE1+FYO+
FqdmIofEU1ssffjJsmvutL8zBXqZp8g5IGJy0guAKrIgkm1Fx/ROwQ6bTxt2J60alQieg/uhzBhu
1gqc9dwjVKOD490YFJPcGU3UFiMa8QkmUA5nKgBt287lX/bGYFs8bQAPr/6hbDMga7zb41iIIXsH
VXU8KNCnDpST1KfROvUXgI6+EYdhUrKbbPjKkjcF1wxcxRIvk+ECujIUyqJSQNL4hoBimGP2evSt
iI5O2EwziVxsD8PPNUp01M1R31DgDr8iMjF1LFtWfnGXuVsEkVu8aRSMA1dhDztwocyaR6xis96L
nMOoRF6/xVlFKhKBD4XfNXKqXVioHX/M3bQdL/AP6FaQx2LSW7/0xYok7x/+C0yEZwSF3/EMZXMv
rqi8GHQUJgMJeY3/6ODbbi5S4m3t4g7qDYKHgVq3jwouUakgFhF4qqoS/FINioNR4PVj+kgim9p6
Snr44IyMFznCLdZuUhh4DCWF2JUhG3FUH/eVWbGXsg5rRgIXWgwFZVfLCX6UgHnpQIyUl+BFGqQa
q3823RI/IVlO40/6lPI7D8V4fS6UX8zxUhLi72M1idzhIJNn+IKK3e0Ki+geTGcEW5nhU+T4thoE
KooPoWT6z2/zY2EjGvO/LOhjByOn1qy8IVlCV8jpmUsoReSO7HkkYPpt47MFgU3N1V7040B0nTmL
j23Wqb6qG55mZsJqegkiAwlfVsqBQVdZtEQTAJMvwqgVUBePT2daEV/rwJHdqmOQWLLm8T/jO120
blRsYpq0svD/6d06pv4VPkTI9vzw3xFr0zIDwtfRZn4jmgCqLrXYn8SEi+l84YCcEfKhg8WLQPxr
lFOOBjPknlB+xQ/E9UnpCzVtmItFmpsXl9yTlQMKq8bvkSQhWoijAK+QASfTJ+tZU8p0XtjpmZfZ
qfMtM1cax2QStCTrYZuvXjyVgGrq1LgraZ3Nm17Z13YQLlxCtqBEqvvMTsRuxCU5refP1acW2oxH
NdtrTdXfDW+RJU5iAZjW6LZg2DgMiICz2gqA1ZbyqjC+XxaK6Orsu+qzUuZgeAVnFL3SjWFjpxQL
H1/f2i6pIEX1S50X/wZbiHU0sqTLdSpo/6VBoOgKwKThh80jBFNOQE/ufqG58GcaFmktNv/cqJ3p
dxzbDCtfs9y4k1DdoXzkjiiBdXft5hW0iQ+LUAqdVncE6Vonx4YCdxHn92wbAUBKNYviGGKVY1ja
tPVSPxwG/pCgIyphhXZAubpxNM1o/L6BKZ3j5UqMrvMu8M02es9tgb8QDffq9sdsmKttt+2IOzr7
Zuj3Wln2/crWFVjmiHauvH0LJtEuwqmAu5P/u/qLhdZ2rjhLC4nVm+nHlVpQc/JU0ltMfXsdUWE9
LCfwc4C5knbXCWA/uQjEZyeHMtyoFXI+XRaPj7MqMvlizE01tp5+HdR/ORiNwqDLe5EXcIqhZYCz
kzjXAh+8yN2D37LRuw3g3aaBrrKj7JrlI7yJimIKO55H3GtAG/kx/bbW+hMm0Mr5vNL/ta2ssbnt
LcrxOybKegN3WGx8qgq0yCoTV75Qowf2EyH35MMFguRHSTogDn692o4M2p5RZZIf/Wm7k0X4xO1H
Sgd/l/DnVF4UKoaZ73q5tSggzJcYz1Ay2aMPJF3rSczYpqX8ogoGVahTQo8iTxk5Q0LfrGxUpTse
eoZvso9A51Ty07ipHAG+KbcCs3hdf2xSvKX86XX86cgdHfaWlIseaxYZPSLdqJLzopHhijxBYrJ+
cu/ovJxKDBvCaaYG3EvySUoVZevQ3Ew95PLwtayHWgBOaxdZmR1eIsQtqFuvEDzmSYEcnpVPLzCu
vVp2GE0x4pRzbXm773/y2jaXxzsY6PBzy5VD3m3mDfBdZtbEf/pZKKbIpb8XEIJaSfl0ml0Wg976
hZglW++44bNTywP5rJF7EFLIeLsvGeDzHsG3ClGAk0KCiSWIq17CsPL+giy7VJ3Fs8vkd4UNbZO9
PeIIHiBE13BQiurD27zAS2AUtyOR2vmpxc+UGjV+jDIccpkNMZWzefJOcN9EQyDLk3YCgqtjklrw
v8tSM6U9cbkticWDxVO8EXMr3ubBwyE0eDf+JvW=