<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpG4OqMqnrThGShsPZ8hi6RSyC15euC/QwgumXq0V7qRtRAQHgty0BXiHWKCy7ygSAQFMtdM
PJVcR1eveylVXjFHaOQoLAAiRNXeVyjWoKJ+/fLeyil+7bQNd5RLJbF0pgkj4vSI2F4zt0y4C1ze
D4e4/uQDCYBW5x62q8fJqaeHk4b61vnG9DYWJPDn93L3KVhE0LeaylkeCuuKAkTBTA35e4Pt8aJo
wK1zhgH+1md9rM19xaNEd7u+W8Ps264krsvHgjBlBs8+zPno1ert3qkNOqfbUdf6V+dvk2kYYtG1
usSV/x5V9rDwqPR//HwtSVaglr2Q3SkJJV2K3A6i/vd33ZLNusMwJIb92UmBQvy2s8uPxFK3ImV1
eAT7aIrjMtYfQQT8g0m0cDBCTb12eJl48xE94K2Mj2KdWThgMHAlSffDmxEWvSht8+irer8XHWg5
T796WQiLPrtX4oPWAz+EFq9+sl+PQfp+yky5PHzTIvmKX3JJLnDHP7K25E3mHAr7WUqmCfoP4y1o
RAkP89gyuiIjfry8Eh5+iqcJY1N70j54VpjWR8CGYnNKW0L6JGD8c1T21S4oVHnueSEXaAA21Bv2
0WEaMSt4eIHjd6Xme3cDa6pnBGsj6hE62sBqJJtIRdh/cFJOunVWQKWoT/jq0eymnM/feEfWrTKo
cnp+sZG4eW2ySop4TcnbazbteKd0A8oXFLHwQ5GWgjqEMypXZb0kjlPG+Nab1iAtXyj09jx6Ef2G
l4wW8WFg5VaY3a+2eYI/DwK0jupGD//0ydcwixpoQfZyf5tyWvIYQ5KpIIHcK76+uCyDX5+2Hr5H
UqcTB5l2uEX6NmnNQGM/4qrJM7Y7XJJtzhJhYIRF+g0QzntDpIY04d9nUiRZdKGIcoCzCbB3wfq1
gkjIbHhyCSYoZnd0dFk/xvGigJ4T0nj3N3zD9+CtDc25wtOi85/5zVLOpB5CgPNu+DNE4d4bUkuh
ucaL1MEJ7tPBi4yaQfKFMvUI9B5pwE3JUYbhZtBmY7uHH6lWtLlVFdGwxh7jOyg54+I8hTN33FcO
0JE6TIDzjsf3KRP3AQYLcGof4BOjmBdvvki35Gn078EOS8Im7V49HUqSFIZ/r/w5sMUREf31Dltf
Puj9raS+A82xUhQFAiBDr6Xm4sr977HqQjGHHYYCMmZq98KEr0FWgtnpaTfOIpZd1SwLi3EeeyWA
lsTOLK1xG6pv/ocBFwzJ96e7rrQwtcfFSy8AmTFifx9DJ2dWlIaaGo5iKIFNoqRAW54NHZJUF/rr
FgwHwE40oIm0C4asDGXuZx2PbleLWfnBq8hEsdIcUxeCxnihFW3hUhXhuk2AeUezqV1hqdqsJa+8
LmUmJklqSLR74ZsSoOj2V4hVerTEoDqbGeKWbkllMWvKipJNhHKLghm3YqanmDQ3jaFBDh9C+IVj
vs6vZ4CimGCkxcLBB6OZ48Cizv74NXvrKUe+l521s3xIdoRXJibdrHx5SDiY8jlda1cJwvLJ8Z7P
8t44EcT7sAYgou98LfGfOC3H0hjmi5ZccXUyKkcAStUwmUs5mZWUnN2IVWYtw2hgnTQKyj5R0+6H
MTeWYVklh2oX/IaPKNNRXQ5kYHNTdEhZ/GhNWGg9JEc84DJ+RdO0U5xm3i0j/96M+Hf5X7fqu1Xl
SwxNa7A9VkP7pr7/OYTBlYm2/0vBAl/0sty+HIPdVKaFQSyOyPfrz6sbfXSO+xgo74hSoSUA7wTS
9sAs2Wgy/QUfrmX6Wer2FjJnuN4k68EFPNaNvIpucfhRFrAxl/Pnjidy/m4QoddgzXu1hbYNQivP
ho6OE7ELzCup3ICf68WxBg+qIGyB5Oz12Bv6Rd47sdmHm5fcHbFk2A1zOry3e9USID3EsSxM+KwS
KYLv+yueiDwaz8T9z/GI8qSB3aEf4/GpptqiVnX9A8eCEnucB6I2Arxkqtn/AkypMTwpT359yH0P
mNUU6o2i4/Rc4ciF2OH+nRsLOhezclc/nJNpgEj74RkTu2RI3zVhEVzHIRHI/A+4gNt9q1UsVVQq
Oa5IO8jyn7zNHoRCYybHv3ArACghpzioPMhlHW9ZltTjk4JHkO5lb+YV8ms03v54qgoTwL18B3VA
sxm4FhGCrJ207Hq2Dbx8yIh5YGFkRXTEWpUglKZgeHyLNRtdR4qOgEUvMi+R1ITMIUSAaTgtOdM4
PJSgIZ7Qnk87+xWKaSa4PGPl0bDR9qLZfU2yWQBLQUs+YGEQLOlJGvb95QQ499uwZOl9mqc6K40e
uqGbybFiouK2hOdM8b0LY3XJW8fvsbhQUBwgyhQgt8wrMi58sH3KzOlb7BhPNrw4dyQ0U8U+8AjA
w8z3/uoVjF3kPI0jpeXU2FecoyQZQPYyfjvezyeH3LSrJmNpQnOpgJZIC925d9kkRA/drbHgk0iA
TAP8tDc42GQG7MVssWihpBINb2HjWR8k8cnIE33HffOgl/F9YhV72bZHjroPN3COPowxBEv7uOmo
R5ChA8gagba8Cdo4EIINLuI7LRpenC7hFoOikeSGgodNLvXbfjaD7YHJSPkF0niI59lzQR1nwhdH
hkUl9ihJbxE+yqJLBprQf+Pivd4CD/DX37KqfdFazkfMpqtrI/jk2OezbfjI3YHfZMa2C7XoZSl+
/O47RTDaKdOPyEPO1TNPj5OGz0iSx8thHJwNSzRUKGJ46bpbO7ipEjE5a2CUfcLcKdwwvhjouHIx
reJmlPzdTeREaQFaCbo5wrE4Wn0zuCOFA/vCZ2nB0NGrll2kSDYQ5VsuhHj6A6wvB4tqZ16P1NeT
fW/S3ctKwDFIGCtX/mtZrd91uPQiB/RmoB4ziwuTcJkLjN0KCBXUTWnCwtUwvGr4SYFbZiiza7PY
aXEHfxDw56XxICyAeOozqfX9hqepmD+rKu2TBhL5yti+0NVKNJDapgn3IVb8RVsJXRSxQ/rJYo2d
hMxurFZ5/MPwUUleXuR+VA8R+VN+9Ws7cJQ+tDTrAyPR+Dd8Ly/M/KPjwSi7oZVAIF4boXkxldth
DL2nHx58RovGFhnMb0h8WLAv0Cc/j+gOITa1mlAvjhcxO4xUspSgNrX1agkcqHiCbFhHLTR0tEd2
+UksbgQi7uK4yUGD2zxd1mnqfwpqmBkrL20o0AIfPgw9oPCesVI8tcKqp/b6berRbyxI/QD+xT6I
L1Y6HQW4xwfonod4pyJyN5berJJfv4WWLEG9rP8ARq/Kyj93tx+KKgi9ikwpkTFgdfwaEApiVJct
1zinK6KmX8S6IA6+sX3emks5L99Ih8FmKfwK/MiQeKwSu1HcY6IKrNUgYdU8WaNzISA0armiynPe
VRyXKwdbeqj7CX6w5o4sH4friyVwcDAS8Fi3MgizCcYawTFvqVPbRfoh9ehdZW==