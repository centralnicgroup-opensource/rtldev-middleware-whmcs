<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/SYaUKLfcdAuEm4nfRydgTSoSccOnmEIP2u1SturoKiDyEQ8KnuIG7UgqfviAqG5Vmcc0Fo
iWAycm/hZrzuWD2hE9i8gxzlugp6ct4Pmddf/W+8jqFKHEOcAGiJCKYq41blYisFhcbT0o7BlIVI
9HQwO6ZVnYk4IkEL/t+6ONdG98R2Mi4Jlq2Z1pj5rxVgh6bKfUoIlGO/TfZyKjIW4KsFY3MQwfHu
z1nqJ/s3qvmHEsbQmNmwj0klI2IEx8Qrow5xHCJbVPVNPnWIKKGpvUxVHezfIvBh+KUhYEOhha6D
cAWH38QUbhsgV6AkDKRUnf4GSnr9v84nsN9qr4vXkixlSKpuoaMvac8ldmRMEeTxN9DHATGYKxh0
KUAPq9aAaEUYcOsMPfT/WPTCjfjfaesaGPtI75sryFdxvrG/6of6jmxpv+J1HZOVOF3t2krpy4jB
fqTzxW/SIT1U6OUo/2k7xVIRS4PWT3AEZkxKSeR6wYKctXVch51p/K9pVUt31V/hivVIMj3RQ1ap
gnvVBh90sJ3zZIA+tpRuz1iOMgWOYs9C2ymDwuPo7cx/OBzhZB09cpMqkS0ZzzR83Rgs6mOEZdl2
jwDv9Babs17ie9BpBETBOgZU+Tbq2soEVUl7uximMo1z2oAY+rYSAZthTd9AoGfTOWVgz0CArcnh
ajGi3kOesKELoRQCuHKJqDue8BreOa494+64G1xQPNH+wTEwxCRBWvz4IOa0N+RKU5hObuVOUsE4
vCx/tFvf4FlS8y6D6CkAT24TBhmCiVTHdggJstr2THY3aI6x1sClVaLBQ8c9PnrDHTKMtVacYofv
djwNROxjE05J4vjcOOlLE7vt35CO4mjMcCSbObYAwReSh2eI3w/F7FYQsXV7vGOCyG5R0qB7NbPI
Av6oYCHJMwT9QtMGx/iQRfnKf4sGZDi2csMX9enrjmc3+qEH05t5EkW0mQdxKMFVOk51Mk0dZzzq
FohHlyb5e5AugQ72HKQ9/mRJlV+wOtatg1v7zWqjx04VkNaXmigWC9BuVNYAIgfOUYgTiZiArcjt
m8Alw8kssgp62v0WcyhdvsHArsPR4LamzXoYXGfbkCe99agQgNHG8Jg7hLUBfn2HAfjuIw22Ds6f
Emi85f0MKjegqZb6cjZ4i7QmfcjCssiFBYEUNZeBKsx9atUNZGlAi76cigJCZS2MenMlP/fuDn8m
ReG/yi/LHBbUwaERAeWvwYXhJ7Jc7R6rAb5Kof34PU3h8BsLqdoMlkBTJre4nQVBPRx7jZVH2hoA
Ba331CEghqj4qxvwkr54CEO91a1t7E6kCRaICOenwd739hA1/QiA+z96Rw5F/upP5lzyVW1HpYWD
JjTkwilmgHELfedws1l4+9jT2Algj+MQQC+hVna1zj+CLol4S7RHvhDVbxj2XygBLVxOkqoUoXsp
L0T1lpRt0cxTVnKECp3K6Jq1ZgLpHdk8EBUt+kMmnVDD507ApklkPfwX8z32iEqk8Q47dIMBZYr0
z777bfW5fPXsP3foRskX3UJNitCC2qtuoUgXrNFnRoLaY/4hoqGdy3qAkKwfDFB12npFuUVR2Cpx
dEOSakLcSROoqT8wKufomOuLShK2RWrIVqIuxycYOYF2eZdCLmpkRWVb7OUGTb+1xcv0lPa3715C
eE7OxjvYq8LFkE1oWSoswHJFn8b6MCPyfFn9sb7DrM4B2w18DHGOthPM4iQhdW6HCd/xXJy7oncV
PO0nE5VY3SGWgj8CSq7/RfYnHqFVO/KzSaKIVdK12BuhoJun1MqhZ4B4wHkPVR5t3WpMKcRW8Sv2
MEopnqiDzLruvSi64giWeJBKGqT/2z7am7plr4uT4iJLg4VbJxlfXUT123Nuy8VDcqLqvUzslzL9
2btHl9Ri3W/kehXSiW3YuUxfLKPPm847ZtM1VFr4vk9Zl5ji6ycu9K9lmx+VPuVPAJSV0bHpb6C0
Bz/oly9X9PM/hvAviPZ1cHuXXHxwYJYh5a6FTiU1Y6rouLH6275OutYhBWGWBBFID1FYT2Pq4ZSC
RYorGzfPzPqIhjsHb3aPw+V9eY0jPHaPygb3sUHyy8l+vAkZS3DeVgfjgDe71f0uofSs5dLVbBWa
T75nH0QyHxs8HaBWVJkGqXCL5JElLh+SCVKreOZAp1GZ8YvvO1rJey0T9o3loBvuGVI6Mc+AWYxN
tp2mmqR8jkUrGkxebbwMcuIOLAbwgko+ePLyAqaS2NkGkECz6QzHoMpHYIL2I7+KBFZOZUOJXdqJ
Dhi7z59fGQYc+k3GcBh5D4lZOPNvRF43nrjpSKNHRai9Oqti+yZ3BekfJJBX9qaws73AACOFpym0
4n0eimkY4TMyhETKJYqcKJymksb9WR9MKy0s7gnSTfNranJ1nW31Ed7SDZPwfGxkZrDVLHRyc8xf
O4ZyoYR7LFu60S9LAF/Dl6JdTW0JD9L3BQmlxVQyxpqnJ0rPyoRUT0Smn6iHjEMNgwvmbWaK9CsE
ySPJikBrgw3x3gR/f9rAg0xsvk7I1yxnqzBQDmqiAoYfyvGA2LGlOOJvvgabPL3/2n/Ib/Rpee69
y8duxKMPTBjytlO2g6U05bghTDohIVUBXfaYhMsw4jspOmLQIy68KNZ+V+Ci7fUu03UbXQ+k/C6M
xhh0BwAqFnU9X00n+Ui2uV95byHwANDucbC6CEJcmkyUYSg4O2NmjE2UTcw0xDREz6IW0KxgjpqL
TDLjOp3go9MR2uAkL4j7+NjNWsbxiqV5On2aVZQd1z4EXsfieV3tFZ3PUrQQAR9I5dyJ+gvN4qNE
OettIHIGEONEmMTYDH5L6cuMgiWwJzZgjlkWE3K7WSXtypV3Hn7jO6NDrRFWvLaRYfBlELIBOk/M
9wvZkIDs8OGJ0j7dQ+wvNzuUOpQ+To3EXx707XfkrOdAnmZX2XGI/h0Pph42D9NClN28YBI1g0aH
4NwbinDBW0uiMQpF7AE7zCwS/7EgOFUwN29KFVFoz7R4Kg2Fo11FVceRRnfUq9Iaz8h6QdjNaZN4
ItHMaBby+GRIU8ppaAit5BsQlV99peu98knh6hobSr2L3MOjFu1DQhUNsr+Wrpxv/n7sBS7qARZT
9lmZXtaaJTwe8UqXBokcO+comUKsPCKW6x7OIofitzolxgqNxi92DkiNRzYkTn3BpO11JkjMWpXX
c0DAgSnpstboORVAKupA+gX/4z5vJR4pnH3EzWqQbLjIAdda3idqUoQA3krupRS83AWH2f+/2Hfu
czp69hry2anBM5M6btiZQ0POjRC7ZKwo6uaVFaGngnmSgRj57QpSrtwO0nIHtj0RNW5y7qrDoqAp
URvpjPguSaoQ7nB9wly9+mf9A4oHwO6mp+YQUeXKzWUiSt4g56P84vwZ50zSRorJdeO1Nds3/jlP
8pUgye//Lg0=