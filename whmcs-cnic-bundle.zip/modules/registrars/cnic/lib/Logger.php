<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsl/UcMFRcrUeNSnyAocwlqTJ8bgcItQZ9susEx/xX4K0pZKw2KqAFZjnDsQ5Pu1RlY78oNs
jdjrdb4Ar/VOQXXO90kcJlU+nGC6tYKOU0guXGTGNsyTP2wamq09HuyauYdQvUMw40soWff12WSx
r8YyWQxa+MfSwGyZzn91OxSSEJFKLCVuilseu2dBJSrzR6TECvqMoDF/xaysucm9Js7W2PiYZeBM
+psO6KQUYZ/uvKg28NoNDnVC/579QKhU+HD+gu3L3W3OXwtmeEhzGSlm2LDgrdjXcOv58xeuk0OX
4SSO1KZqfrnLcDSb+VBcVnTIpfIdqfJXUeWrvyRsoNFVba6pbkwJ7adL8g7qcUtpNwa6AGjmjqz4
wooCngSFBIUPnsyGIW63hV4aLDRrCdCeYCGT/Z152Ly9B3da8+NFKFX2ICl2LCzYfoY3LTiEcI3y
0mRh20Avm4s1dFMyblZhWJU+4h/oW5D3/ta+zxXbxp07q4ci2Lba9NBwWMnNteYSTlJx6+uPw+nz
5Ui+SOpir9cGpzwafaP3/1pOztfIPPeftuYvzBPerVyP1Nc4HkQE4CI//I+Oil1CVAx4Z8QqT5T8
8LbQfMTs7Hlx3gylpSTw6XPetHi0m6WXKcqMTtzJ1GdKac5gbKOTGtJO2sBv/4nJYWvTsJ8ppDdL
91fK3VYLHZlTIPyYaqdLsbjb0QrA6JK/bPbTMW7aVlPm4eVJEPYfWaEhd+Qr/yTbhZWgIo1hvDfg
9fC1J00offnMphtBJ4CkeceGV+fJ3kWfM3imZ85UQfHr8JHU46FE8hIY2WO4XdFqhavZWIrWswDV
XVxeUn3ryLIS4XjpwEv9wjvpbBQxk2mVwe0L8zGUr4o7WXR/HtneAzmD2tloUluUuPee3z4OArci
9/4X9633tKFa6geqfLlXeLsTTrb8nurvdvYvZ+7rKiZ4NerJgpzLtcyEjmdmuF0xDBhQK7AH69p2
zg1mtoGLQp3bAV/f/GZW9Q8QOs5cUMvEm163WU5OlYFEq/eGE82Hu1EA0U0n1g1BUbXbDJW4nIJs
YHYTiBi1h1/gL1fhTDukk1ZFma3bXuuI0TP+EW3ml/FoZ94nfSBrbQmKfN63XQ0WCCnqKcF0qozr
72XvdJgzli4ikf/inhws1Ek5bqMsj3RbgMIveSt4NcE2Xx2YevT+Kg1V37ukIhpqRcwHYTLJe5si
Ry81hgyE/043peDKBI6MNDFUYFnveGwMjwm+CuU3kPZAaQGezhqVGD3AK1q+CotIvpfhy7AkXT8L
6Z0+lZHByqQpVK/sva7or4VOLrnP7cYRldluX2oqVo4fqJX43xei9u0LyY+WWL8ibYrnW8LAmKsl
sSGD9/ihScX8VBwicDkRIlVu8BD7suoo2ghcToXBJ92oyFfAx+PwUBWvrC+4BKHKfeAPNNaAMfTl
dHLKJUCisrd4hRDLk/YwGxReda4GGI+D/oSl2gAQumIcBoDkZReeDj87cYpljK2t2mWKNYlBg64f
A5CnprrfRD/rnYglnHzG5cfoimbF9Es6waZSLMDItMUjnj0dNruDx2GoMgOjQRhjFg+8KXG0g2PP
3LMlcCmqRodQ+0xwj8yTg1WLPwztiqbfM8eVQGlXs7O951S6kIy208b+81ovs4ioRUQ1P2XizoNg
h8+Yf+C0cy7r/hpFebuPW9b50mCiYm2EK9aQvJNHZN+M6ajYyZdlto5cTdnn6bu/7i+oA06jJUy4
4AKAevAquuI5NHasPErDhdKMwV+gGEbi6Fy0eZJk+c7Qnk3Y2BcDpTr7oj3PzNpKgkMU1Zlz+0j4
xIHrdgmc+uqxya6dXo7D9BB+Rkf80/CUtLYEJwiE52um5zhEpXtSrwL+mGo+nnXs2IIRHO1jH0oj
mNq+Svgne8dcolE4a0XZhcdjQFYkma9cgyhhPDB73+lRhn9KgGllUX3+TdurlRRohbm7MltMZN4Q
GP3JoqB26wMOBUooC7FWdYo75CLHVDzrlny5CdeEPPtSV3WXtjehx+wYY75vgYRaPDhXkoT/OqN8
7/yUb225UZC1wPOzuESWrAtdI3VjM6hnEvE0khCW3j1BNTEIXzq2GxvdDhkguW9XJsbXg9L3mJSn
k9UHlOZYeLlgYrmGokO9gtTC/mL0cxbVMJuhRff+TsWWYKhx9vCU7Qa7VpkJrTZ6uihbFvYcRqAn
2zxeU/nghql2lPMt3GUKyFc8JpChrdB+FoxkPggvn3bRoLX3OabfcRHnf6obM9qNvbovW5ysylO4
9dcW4ZjpDkOBcnu+wMYhzjZi+4IhlFTyHdJnvDNYIpKQnkholSH2uioWZA/qRUye35tsp4JSEcV+
uUsVNAW/di0no+a2WMQT+1KJKZ8nP6GJZvl7wojRSCKhnzfk3zotQO+zm52RLCzUw2bewxYGxdfp
lc2GTizvw43EKD3y3jwPisfTLym5u4xH4armJ8EvoHEKEzxXk7lT9sDRM8QtMoKjfLB6zfGdBhzg
f22ttUZrD9eCwIAC5TE/1cO/ZImT8In8CvWKV7sR8GPU+AIdY/dmMbPybPPS/LIvO3zYDJgG88a9
RzTXESFFeNTSmMmmXaG4x5WHvciRe9hakrpcxk5HRbA/YYHW+oNwxWPcgrfUAJeA4lnytndiGWGE
nFaV++ig2DskR2sKM8PII2yFM+dSyypJOD2H/tImk9eDnla82CnTqN7kIqbSUd07IfCW35QGZVbY
NgHDziI30d//FolQtSsgDv2Q2Wsx1FTJEi9qJjs4aGTDLkVAWk9Pko/UXvd4RKJe1ac4219puRAw
6gSTW0uvfAbCyWzr06xZrhgHTYs4gPLuyG9EUNFJ7GCYxkeXhg0rh+ovJMlZTdDXqNg23zMXnsFH
4nURUYJL4FC2G+7ufIwuo+EhoZgCpxKo+V/wQSGN8F6Zpm+VDMqxfkr8PtpPxKsvEiBJ9TmkMoJi
DvB4NjcPQfQz4/4/eDTk5DdtAVHowoARqBHiBIr/ZilcFJI9V9zBubZ/s2X9ZT7vviCpTw4BsaBC
YB846bsubcgOUDLfLp39nYhNK2GmgPBP5goZTnF8OYcYrBxnEXJBsIdshrgl2DRRspxYoQL8dMV1
z9fwUzlK8JI2P5G6EiV0jkuCL5DEzo7elcMnsN4brW/B9WyRfhoihYK7JS+KTxGd1EacqKhOWElG
ZvzQ8MCXbRi9y0tmgysrLQPCcpvefAk2Oth6tl3WxJ74pTQxLXOZdnJAcxtPkHfj7VQpst0Q67/K
kSl8kkQph4PcJESvSVxlAk/7ug3fyKmHsv0ISO9GjWjZk3vlY4WvGKykXctjDo+47EM23Uh0t+N8
zy2IDUTfkyN0lEWbu5d26AKP9j7JXHnP78d4+KKuj0fjFb2MHVzZyFPMR7fO2DYzOavAu1UYdvSK
V0==