<?php

namespace WHMCS\Module\Registrar\CNIC;

use CNIC\HEXONET\Response;
use CNIC\LoggerInterface;

class Logger implements LoggerInterface
{
    /**
     * output/log given data
     */
    public function log(string $post, Response $r, string $error = null): void
    {
        if (!function_exists("logModuleCall")) {
            return;
        }

        $cmd = $r->getCommand();
        $trace = cnic_backtraceFn();
        $action = $trace["fnName"] ?? $cmd["COMMAND"];

        logModuleCall(
            "cnic",
            $action,
            $r->getCommandPlain() . "\n" . $post,
            ($error ? $error . "\n\n" : "") . $r->getPlain(),
            "",
            hideDataFromLog($cmd, $post)
        );
    }
}
