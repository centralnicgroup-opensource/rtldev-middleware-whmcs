<?php

namespace WHMCS\Module\Registrar\CNIC;

use CNIC\HEXONET\Response;
use CNIC\LoggerInterface;

class Logger implements LoggerInterface
{
    /**
     * output/log given data
     */
    public function log(string $post, Response $r, string $error = null): void
    {
        if (!function_exists("logModuleCall")) {
            return;
        }

        $cmd = $r->getCommand();
        $action = $cmd["COMMAND"];
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS | DEBUG_BACKTRACE_PROVIDE_OBJECT);
        do {
            $t = array_shift($trace);
            if ($t !== null && preg_match("/^cnic_(.+)$/i", $t["function"], $m) && $m[1] !== "call") {
                $action = $m[1];
            }
        } while (!empty($trace));

        logModuleCall(
            "cnic",
            $action,
            $r->getCommandPlain() . "\n" . $post,
            ($error ? $error . "\n\n" : "") . $r->getPlain()
        );
    }
}
