<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrBxCpKcQOWwFpMc5WQYWPBPGl2gLi9VfgYurweVUvyUGwJy+XHKeLERT3FaTbGUHxR+xbDu
kagqyea2tFXOj5Jk1z0XFGge5klsxU7hEC5f2KgHuQR1/0Xc6qD/czxhOEnHz9gMsBwCSo1tVm43
3iSXbORWijPSCMUDsXTgwkzLIVq6L8jqhLqrsU6ESGTvJrn8Xl8vVV7fqTAvwgNur1wjqDScZgwk
81VbMwlBt6HRyzUqyTW4hS7fOfaap1+qpn7CFHgssC1YTuRUSO5ryYqJAgLl0kpt77UyNhxdFKr2
nsOS/wgNWgtS3idO22Doa8DWH2S42fRgeIl7icR9JTeN79gjt+dHgi5iBbB/Kbca83uGZP3e5Gdo
thyeDiOBUBzMoznUdF0Xq/xyBBe9T5x9vKhDVDvnVn33KWPylwwE5EnrixDoMtUlL4a5UbLe3+H1
4uTDg4gfiW1jKC05jJ0TgaJDO2E1HqrASFHOJnGVHfsLYtQbLbnISwDjA+Eizyy9kA6Ch923CWNo
6/ZqjQ5jEboDXIFUo7LpeDv05OGNX8ErnVrVmI5FJxXt6i+pVnKNejmtiyTCrT6hSH1aHepuHqIB
bBsKxHepyip5XZ4BnXSNHgycDAWHgVc+gP3sbrho2NB/iwGnrzfTlzIMHrr9Fein8Roo5jvATi0R
ZEqUQuCMVUjIOzYM9cyWjWSV+/6vXc22t5vteV+L4udj3JXmm6PzfwyWwc6Fh7lAX/uSYAyCsIFv
YUnpMmFqwD27dOfAGN7Kc3NwMe2tctIm6d1jyvcQtNSvEpwlLyz3tNrLfM075zURJT883LCYxCOn
KoLX2H5h9miPRUz+/OpLxhHulVSZ2e13EG9PGxeIOGk1jIOnTapuTECqdLUXckAT7btHuRdtCt6P
0wmNPZtklELVpuED17B8gTe8p0T1xN+42MU836x9KZE+wo3KH189lLroat4F+E4cEvzYiD+0XS9s
u2YLOtXSwnLGFghYK50a5yxumNsFJhQ443DXgSdRRQIKEQfvuiKn6YMrYkrjn0P8QhvUvp2kdyNr
zQXwMlhyQD9ewStURyL6CPUKsHmAYCWK0+XqQB09mYRSWxwUg/LPr/WYTy/oCnVbkJg5uTNrkkR5
/8xQa1uX3zg3pxk3s3Pgi6YFgLQQRxkLfkqN5npLbe05w1u1C1qPIG0QSy3EEoV25aBV+fK0xVAp
iT6+LQBvh+ln/9knOxjdvZ593k4tvxXfMyO6ffB8EgqSHr4eCXGZRwTHkukaj8W1hUn53hEWLkfg
OsPXIzRjg9POAHiYBrEzilC71TNPCiWOSuAvQPRstK+feHQHWUurs2W9GNc/zycx2i/k3r+CD22+
8zfC6O/z4K2eyKn/z1h6350wEshqZcGCxFP7P5JYVXMIEyNwyfJJI9z1yVyBRMfks4pVH+F9sA/B
/MQbDoK4cXzLawaNMebMo6IVndx2eG2BhLIg3RtqYCCIHYoGw4PW/bb0dR1OK/c4jAXBg55YQsA4
qkGJicoDopwV4wDeRcSMHnuBUadHoOfvEZuEEDzn0pdnYIuvkqjdS4DbPJ5u3cLNtM3rGApv1X6Y
b6t0NYBMYmmBneJjS6y8g/pwSO9Z/NT0N9BVJ9KuFYQDRpekDFfSdnKUehej3fUE8xeKUSD+wEpJ
O/ODfVWVJsZajqHugGl//8thLjMWl05nYDc7SeS2zZGXFT+3+IlXa9GUgaQcdnlg0f2yjszeBP/9
dkDqUPqG9n0j/Op7onicL38K66M555ydqYFtfAPy1p9MbIDwbTQz5TOqjXsPEe4hCZ73zfrB0jiI
IYgbNcQMzMlzJfkG4PP8FnuvwvEyLynzNvZgg6EnebGKUbXEwQHgsQqvTV5Jfnzh61VPuLsvwTH0
xhSK1ZWLxlKUk1eOcbntmDY0nCPjDo+Mh0nBANTHpyud81k7QMNMSV4YqYy0Q/e4XGJ+QbQIrrnw
K7OohFCklh5FxNqiZmXwFbwSf2iGne2o7T9JyiJabbheCQPpILVsZ+Ll4/zf20MXGeHuH8ViWs9h
MC9+mp8T+ohkISG6zaoISPcnYUXpa/2uKGxPmtgk5vnFHP3RpiIl3yXUvaL3tZF9KwLSNyDbIrKA
MvqLfSdpwaME/rkvjcSFHjUDCxBWTT5iR5WdsvVyP+AIS2c4j8C1jvQM5Z3lrUAlM8kFI2i3pOLa
kKMfQKKhTrHrTiSeM7/4dQf3lpwqILemlcpYZw3QvLV2zXzMZqXknKx7DQElCeZnEslXKmZLRjUv
XF20WFcSfl8PMToghBOEyvDpgZKe+K8ziD58ji1jLF3gv08QPzszrqPGHpOVHlNEtLzQpCz0P0Rj
jqpsgUALAmfPTJUHvZqS1ZRiTIDtgvnQM/ZicqH+UVUOcIFmmD5/qxGwDJQg8J+k6OC3Q061WrtX
/zJExSmbqv1pqQiXmPi6I7Pd8DiPB1V44xfbDBWz1lVNm5JIDNx1U+pyMgJyITIFcOg7lZFTcrC/
Z7hHNol7WrSjpItoVzfiTh0TXmDqqipNrIdN0sD4YKjvyY+dnMP5gmjIojOeNG9j20xceEO6+J96
60nE7q2p/4p9RhuVhaQolBzjJmzXQzLu+aHUn5OVnjOmmk9OktaQZ5TcS7reiBkI6vTMPAOny1t7
CAORLM/ZqyGHvkHiBle8awLJfRiBSIpAvtjaSMYZovv6b8Go11QDpvoSJBvqa0R/DyF3rgCLO7iH
7KEcxAjFAw2Obj2Dlsr1o10sDhn2dx4vquSA9kN1YrMAyN8lzlc+t/zZSCcHBwIIaY17ul201uTI
nNiufvEsw+oFilvO4wEXdVccn/kU61HRYw9q28NSUzSWZ8xAbcaCalkCKY50gNv/NPItbQyIpCzr
Y3vF7M695QVV83erFL5Wz96pSvzA55zODQ8mO8Pn/1nQHybEEtpBPA7rhIZNR2wDChtkGLv8NKmZ
0+k/jx8BWiAUrzXzlyfwEQzi6mfkh1L8n5t+dYZPbvyh7R5ZA7dDOyzvxYl9EN2JTlPgalqx9qnG
bvg8oT0TWEjLxcTT3ZA6jd6SSFOHUo5SsQ//BUpGmbqb1ig5XlICY7fW71cCEMsNuPl5p7noFS5Y
KA7WOAHHL+mYSkOfGCCmY/lNCMDynana5RvJDV2If2zlzEUnXVMsjeudo9Ag8N8LL0kJ8BPxqLca
mBcZUiGRyYz9vzO3Hm0CpEbjJnyJA9DRyKYNC0jlN8SDmOFwd/hIg8cXls2dwsY1lhGDJamExMia
aeIkPmebbgfYX4hdxCricOjcpeKnS+xYkNf3EgVZj1urOEHbdaFDDevQfwPRL7R+8wq5t6wFVsOL
Iyn/xcPNhDWwokTnxoRhh8l7h2aHeYaCMw9e4ZTOfolWkSie8hgcXuQOsm==