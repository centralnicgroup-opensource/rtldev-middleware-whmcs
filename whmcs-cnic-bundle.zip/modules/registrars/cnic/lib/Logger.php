<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuywGPiPhhdSvFJKkAezdotBetHQEPavBAsuQZRNjmscxhUTI4oVis+8lVYgdyNDZwEgSiXp
Eh6h6cJvQa4fRhC4zzdjUq0vw/8t80DXziDQKNvfppNA+cG0JDrbzZvk149S4PZkzeoa3PUXnAsY
PwWozbNP9GXSMq324oDwmTkyNbifm2AJ19892uQGsR+gAIfa9daTn/YNAqpfH+vplc5I1XvdZBFm
a7I+Ovarp00hDAICeeLzvuPUvITmxdCKT2xQ43QPeGRaHq3h8KcuIEYSSjLeISqtbhOeF7QMeKY1
x+SqtEbsZnmIkiCbOilEQmkvg4YXoWnL0MsopLH7JbKxlHnn6VD1k4BKIh3HS4YQzKr4idvf85W5
4XJKglgRfZ+dLuqZoc5xHaFe01tSLFuq7Gk2Gp+xVZJqjY4oWUa2lYlTVQlhl939ClSZEsyln0vI
3ReevD/CVeK8lzr8M/1slod6L7WkTAr7tEORNeMsJJFqh09O6VUaVb7H0hjJuKGW6fU4S6Mtd9aI
JAc66r4eEYdtImFitMntLClDBZxTi43JwUn6wRDeIyPYlRloG6Iso5lvL1Wx26PuATY8gBAKNrmY
ramrOwG2H9esgbLcAX2Y8pJbsnHDjOjxBWBYb8a3tH9JCcad2LpktvhKD+j0Kk9mLFFMW9yJ5e5l
ZR7+18ZRB9WJpa66R35foUJvYNTnr+s5tNcwQvAiEd7v75sGzclbERTQxn/s+9xGWEUQGNXxbnZl
SD3WKGFLSDMVqa7FKMIjAuagysCIawpvlzEa0cdvBDp8QnIKxh097Fg9f3hKxyiFSpI7bbuslEGW
KA9R2UvNPYiaLMrdGGvSbN1RxIJPRX9p1zQ8O/KX6AVL9AG5eJ3Lh4EYatzSLyVayemjKi7VxM53
DEiD/6aOL8ILzeQrV6JTLJRc6TpQssCcjlMY+afZSQD8St62tltQbeQ+il79L5du2EPxD4tXe3Ji
ApYigQk73wV4SVyNjspRKw3KGkjaHWYG20CGiG7dre3XteepvH/t/g4q+fNFytXt6sT8u+ytCo1g
lkHrUygA7wJubAWGJrlHKRX68AQnAu9x32/CVJVFDaMuBWY+/jVtWz+raOf6s3SHRHAzopPCiE2j
xY33tRgXcieDgJRTIG0PoY/w6BJaKMg9+pwqG9nw+kwEZ1HoEeiId2BF6amv3sC7+gTMePPNuvmQ
McrLgAF/fjxdVrH1OAXFO2T0w//OZXL8/AODyQ4nh9LF5QDnOO4wzuzATRrbxFugIKfo30zufMkW
2ZaPLOOHhW9Hze1Uije44jitq1ldjRPRIbAyDqLnsmrNyh84eMGP/ymi7S4DX0RiWyNhb/1NLNJE
2q9+Ks3OfCN7UnRswU4uC6U+ep795qRssKwtRXCMWqiWPx/KIjjk5LkaTNolwkoC4o+0y4LptM7H
M9PaECVQWNBO+h5ENWz81TMbK7/c9XvthYsAVLwNq0HiaBKtrsKog01eWW1YN04lJWOqD5497VX1
qGuCkZyLQw3pVpKUuF2+loF26bhPcVwRnMmA513UaBckYyrk56eEv53X0Nr3MRK4HX0xdOnrrOXW
Hk55uj4zkTM52trgAgfuCYwmpXGDw4hlTAXy3tkvGGrYL0uKsI9VG405xxNw0v3V0fpBsRAwQDS/
/DkEC9KPnrr4Ppd/ETg46GCBGd1gq5F+kyHQeIBxjO0zyRZkYLYfRWOdJ2vl+lToYOpEsSx8ScQq
9NZPsrqblWeWTK3u/4d86EjbocyczZeXXCOIEg8IEU5qP9bcI2PPuHEJ23a+zzU8yYoCrF7I/evA
VHzPMyf6O/4as1d9cII6oTCYGBcBLQHzdjZDJRFWe6ob/wXjsECH+1yWvkZWRvJK82/SsgACPP33
SGWDDIfmLd4Y5wVHO7/ZdRFwLbOSYvlz6oosizPyWuxYajzH2YkqS4D+cOCLSN+iEJVtTlDHro9i
E6z6+PUyAXOuvZr31Ix++Q3NevqsPf1e0btxrlyKGJF9uoWFVWqcHVa5tu6hiY6pMolApgpJJBKO
v6KGnWjWB6c3Mjv1C9bxYL5qqGe8/ZCXiNVTzlGqhFVtIs2hfxoSFwYQG21y6hanufTHQ/3RoF8X
eL4OwiJUn+1NHT/uHzB5uotQ2Dv94NC29kimqIBfM4VlfaYhVzVyKh9XMf0RrQJD9Il2mTfhHjhY
edV5OyhXR8fN8NQyLMq1XTPoX6skJnYfZSm1JWZUf8mJu2dgRo+RWsQk909DpMs752uNUWVoMWun
Upye5l5fVMz0803nVEEsJtcszV6C5uDzwIfQ4SEmuclWL6iSwtytEVVNNZLMUeI9qWEqi8H5UsvB
P5R7MWU5T705sFPqVs9FANWqio5gc0fvv0peVFthzO4TVm3S/Vq3CKLVxianxX0ZxoMuKHs7M2Iz
Z/fxBP+kfSiRd2zxpbtuuPLV/d9PSeA4ZTauzEr/802kYaEVbihn0rbBONMzXB5+49lP1bS5U/mT
LJR9cGngg0NxS12Pvo8f9hTVslTkYk3+X4VMCjQiyWstbmgDZAf5ztZ9qFLczXwqRTXPM7p1rWQ5
bsVBmzOAuf+YONCENjYC6LXinjhJl2AhlHU6cdS9d6Cm+JNopOV4bqbPHLxB4l7TJPusjWvIBp6p
evRZEO3gO4WDBdVf3rMaWKU9UFnW4Jw3T4NA9SS+FNCsorN3Dg099rtjLba1HT/JaNS79Bi4PqJ/
M2iRswx9qxXiwMtnTtuwaYY7pDHdO8jB7TG8f2cluGX+cxDIXAkyCyfU3ngEwyJk2lCTIN/4+Hza
+RFfZClhlxh3BiFhu7Yc0ejrTkB6BKMzAHk4IZlVfG83SpF99rLfu7BXqcTIZ0NULC1jEYJ6FweI
Kl/EQnd/+HsOrohsYHW8bJbc64LS7vZaU73iE2wWzxndm+DMQkHjxsc9Lk5P5kEii96c62G0+tCp
mIL9ndH4L6G3HHH5MtxBES9m1P4zq4w0xIQHRU3emu4VxlkdN7pupMqB7tTir5IM0R/vYc7L+JdF
ZatHW7I6Y5c4me+QuE57A05wiB2BrNZmU5vh0mLKvuUO/uF+2+QDiV/aaky1O2eOlUrmCVmZaiXc
2n4ugl0fSOpkjVqrXyv3Kh1QFq8Vzz6x1WouPoDtwRh8aVjjMYDlDQfi3cJUwbZK5Q2+DmNILO0E
PnVQOsYhJnHk+VAqaAx1sTsA0sxE03ljhpUco4TlpT9TOUqlw8vhHJ0Fyk62VKzsCOHWT0R76w5u
auj46PgJvzeB9rA9sTo+v6wnXp3FLZuZglGpy3KFtvX1CJG/24Jy29BeVFDu+Uq2QMHFYSC8RtVS
UcfMWvN2P0SqnwE33W9fcc16AJ+3SroVqdnG8uurIWv+10OoZ7wgLQVBV9es