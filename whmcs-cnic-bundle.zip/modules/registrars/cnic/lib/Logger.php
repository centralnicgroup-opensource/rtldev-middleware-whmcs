<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzK3FdWsmO9/pyshMyTeY8JckAO/NOItNT15HXIg073K/8kW6L44uTXWGCtRI6Z9KlHwwAOx
cghhseF6xWSYflnp+6NjjV7CTCOCxEXt1dk91PFCq0NcgOR3/lDu+qUgkN9uq1OmHaGlj7z7O9mm
JIp398/71sh5Y0s6qKe4iiLIffIX4Q0FsX54JuoqEe/HNuVWosgg2qo9YtfcpZC2HD/KtYrnuOTG
mz1sEZAIjuwafE5w8qBZaQL5ClJtyht+cLIdj6TH+xCgcTCY+fDMuxD//PATSPkiX67KWprC61lC
yLUeQFiU4kTxitULcjEXYrZbPE+Z2CJIMkAfXvyJVHvmZxCobJCBqWB9m0iYfeVUab4OVVdf6INi
Xw13ec7wGJhy2LjtSZ6h+yqt6JGwNSMhSWL5pZUfbQrVdSaa5asgbHjM4lHXp7kc2GmToLF+y2yL
dnKubJx84kfQcp1XelEQnJrQkoDjsGJC0C/T1BkiA6zrn8kQ1b+ZDSKR5GPUHgW0U3+p6WkxL4T/
EXdt9zsrL6SJrPt+fHXfd74robVaUZkmpveZO19VjPxwnexzLFh7BWYWdcwI/rIHTlyWnnJ+OIHT
RcZt6HgohJxpWb589ANg14bczKiTCT3hEPdx+8ZPOmDTffDuLpdcDFJX97BL/gZBK1CDG3fWA0Fn
0HwhbdFo6ZWsCzRVJj+LNBgzk28dWdaFRffbEENFQ9/CX7csRHhV1GvkptA3rb1pq6H4KBR8ybyP
HhR2PrpgFwwMN9WbLGHgDkfJbHyBelogqk1x/Y+hMAY5f+cL22nOxUUesMhgrl1GG9dn18hAZouC
IvKuzQ+WO1kNLgtpji3vo95VRyYoVGAWkT+bLHhs2Q0gxAwIf7XhOX8EG61xJ886z74DD/Sc+l5B
/KAkvOFoaEVwyCRYzvelDQrPv6vvuXebQt+kjNq16D9tNVNG4lpnh8a/Ua74gBVs0hpF6dJbPAlt
AHuZRpwaM8pfCf2IcZ//r+Aa7b8ftUSODsngUVcVThZJ9gLhxsY6J03JIIiOojYR2XB0xrsUnwsK
Giu2VXWNdBv2K6rngj5srxRA7Wn2p9BrBwTil29rtYflA9i27yIn5M1ItnnyPTpsUwv3vatxOQQU
Qn5y7VdQ+nTPmGY8SrbkBoy6adzTLMFgXVsTiKqNxaw6hfiTNBv5on9HdXwlygooNE8PWS8hUdoH
DfreCsldskXdAEPriOhPDcBmnHEqNQ7pKdfFD3XrIN1RP2VTkroueDRHrMQjJvNCEbhGIQeeATf4
mNBrkYt5Rm4DW4YqFzDAIeu9csXICP+lZVP7EV4Gm4OOJacrsTQcmzy2TVyXcu/iOtFR5u4DFfoQ
Bj5Tpmdv9qfVMrVO+0+2QXyTGf6B4v8c3B4FXojGkxGMqdIguw0p6aoFoWF83G5U8iOjETs6tdfx
ZYC+fPbRLvb3rXdoihtvEW4XO5MmV82j569iZOBfv45HRXRo73XdEw6ShuLsfOD1ORLpGDyhZvia
GKgPnx/wdA9gYCtE+hVUhYWZcRFUkaF5plPZgq0xYkH3TpRGm3G5lVyP+grLLGrZnERa/bQhOMTd
jssi2L1OwGKoP3TW1WbmUQPoI/MLFjQWfFig2ZKTyuy9OCKkyWF6v9+48MmLvBqtyyrrpddidJg3
dBRNZ1AV3PxIOaxvdgOr6dOKdox21d4Qy6geaCnu6ZMFQhNP9RkfI6pTbTm4QYXqz0Ull/vfLblB
ZNd3hYlb6TMbmnu0Ay162Zxc+XYiTUoT2NVbA53atstSEjsneWu5nuT8J6ktLburk3OR6fUnUmUg
vBbaxUcw6kqh6piU4o04AOrP/mRr4hSvAP9jzmiupi4TaZAiiqM4unfZNsbw8YzAVT8ftE+kv2PK
kXix+NguJ24ogv2Wwd2Uq1aAxAzbOcGYRFKeC6vkfHf8aAIdlmzCUEk891USwSfXcaMk3q7AZLrT
cQUWqHWt6knyuPvlhr0b3aIDj1OxbqWT9c1dcW0N5KKUmw9E6TYzS2eGjMeRvBPWFue4Xrp/Dogi
05HVowQG69NGVWVm6K7K1p1IjI9xo9l7aKCEsDNZV0o+/5gidVbY9uUUnIs4VTVrWmIqgVCqIFZQ
ztskMoH8X4STl80IWtKVqXaTFM7acrVE4SuoC7WS89kof5xerhXy4YS/9cLbr4vVGUl3PbV1dp2+
TkwMisx/MbFmWIhR75/2SzPWi0Dy024SeoJoZ2akcd6Uh7oZ+q68mfmvuA//B1WZbsB7Nk5A/X4M
WHUpNTqjaSZ0ReCmdPQnDYxlHwdq0GLVrSRaGaTks7fwkCPyFGYIv+39YKHhmSebweRxOrUxq+fs
rlju7/4vP2dMGon59HQ+1WIs2K/lwPG3TF/mtuizZHdlradIiEooT0amVOZaYnK+4/SaWT+aI0Mq
E32K+Lf5iBMK05H4yBZTJdQMmUpMlGG+5EEOFTCLI+flucvAH/lHRHWcnmm/wPuFZpSVD7KFN2wH
jnXj+BsUoM0o6lpFvBfdzv6AnaBdB1x1D8EJv82rvUWiD8F6/Q118TgwlFBp56E+G7yQSUAAFL9h
Z2DR/iO4Inz1z6CAjM58oPq1NXWOaMBUD2CY9P19Ut2GQICX5upj6ubaKYYs5t9BB3cBUkogUofM
QYytdaMXaYGOlHdFxeZMetjINhMGR0phpC+8nQSRG0ziuFo7m747rL09B3A0GYwSLHECmtyH/z/j
IguBkOzRMWXVTksC4ZvclePJh2c3qLzcaDqqqKf7Q0cS6uugcQWxmFL3rT5BZav4adqJ1OKs5e/i
H0Wn+f5/9EmoZ+YREYFq+lftKcH2I1f2szY+vL0hmCQIo9s4TpMY15M0D7FlFpcOHyN48leKuo+b
yNNSuMq5GL+xfBAGl0DYU/azPQmF7S8tpGM8NHNXomjk4IWSRENIzRuuOxUC0GPkCvyOF/W/6aWh
/m0HOi7giGrzfNr0fhWGeXvMBUfgaSFWPMmmYx/B89pFqiuG2LdQUxU/a7qqpQaP4iHf9u9HnyOc
5UvjxdYno0w6Db34KwurSkn1D9BJae1WUNYSixu6Lxp3boVJFa2hEeSAk7LLieoqQFvk7O+9fy1C
3Q5pi8Ij0u9amBqxBBmApFH5gZGFvBQ6E1eJj7SuP8NcnFnUFXghUW+5JL2lcpR86U6WLWosgJ5t
T6K4J3d+5UvWy7GQ/7ms3WxDUEH4jPYS/7/9GRgPl9ysWqNcMb+ZukNMtI/NwJkof32Bf4TjQVmm
LbciBnQiZPn+UTNyc7n5CRqnFUMoQZRGiXx/QPhopyGgzWwIymi0VfJOq/kktQ4f9He+IK3kELdi
hX2yvJ1TMRQ5mLChU89VqLyPgvFGWk6VrS+ecKK/9oOoQEBkf10oYcwQFIAa9KEIHxMcYfn8Wxei
SsN1