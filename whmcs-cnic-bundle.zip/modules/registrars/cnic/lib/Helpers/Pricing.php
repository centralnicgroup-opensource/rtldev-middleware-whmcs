<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqjjvhLM+zgwBwTpblC2Iam6DsCFSBdhaDU2O7WeAz4nal9l1QoWj3TVQjGTIWWS8h3SN+Qz
QgUHtOM9TkmH6a2gQVhATPpD4RI+5yipbkhTtW6n0EZyWGVZ0cLhUBK2ETBt+F/83d5oSC4NexIL
imqnzCx3L9dm82g8lyuTLpuXlFYoVoXZ+65ZvAvDH05IUfldV0gqVuI9ACoL1x8rNZ3xX8rIYnrt
wXAaaAs3oRt1+jYbBKJqCf65nfB/w0goDz/lD0M+N5EDoKg9JE/Ip5cP3c6SR9vig+JL4rpYxPBP
H/Y6UXK5RF2/rP/acoCQCkcoTrpTblq0hQsQ+HwaoRS0vTfmSDBUvZWbbYyutr60+5bYDMa0h9d8
AEDhGfWt3fmAg2RSawxFepKW9/Wi72pgf26aCdV3ivVhoqWnmvimbAvUlk8n/JV3bdMmEKerkFiF
oDv9nPbHpqp3sqZPAWNj5J/G/5HWxBMRn24EulXAPXQchJYTtbi+f4rnVPTIptCeuuAkf4NRxFZD
MVX/vshvxoyYcUtrsB3Zu4sLHIbE10QURpqzBtWvqYpgLwIeTRXDVWu64rKoVJdQ9qtTG2FYkbOB
yR8cdMG/3P8Ie40n/ZH2+qE16jhMHYtG1I7miN1y/vtMIWPsIGdkXfPe/uzLi+IjROMX927932A8
UvarMh60mSioqrDOMeh9BFt8knPYc5PkxaKW5tb98/m5947ToaOvnUBoCDcqb4jTpSQw2PxMCHxQ
2a6A+CDVBFyhOWlkt46sSsAt4ny/Gp2RRrj4XajZQ03qIdTg2PJYnQW3gwMuQdmVHsxjszcah4b3
Mlk/f89EFuRU78zrLy+irDmrLN5Oa18M4VitQHTv7pqOfD2RPznl7+czpRMGXsuVW5siia/ewMLJ
tstXi6NOxUXJKuJyR12o1BpNKtO1RV0XNd4r7RcebpKG1DiXXwBTLhi8Pg4q2hn/IGYH6X6Gq9Lw
D3hU1qocIsLjt+0AsbWrBwN6EB7Qlay5fQ+XdXasbcJRS3bFUzl30le3wMMLvrUQRq1o6hIUFjbo
WHbzJ5qNDhDCWukOlqXklswX37+a4jPtjchvGquIKZKR6C8z15lTcGbW9A2QfKVlkKzdbq23uPIm
nNFs7cMWODK6AkDNWZ9C2iFMH7SqW6w9rmID1yaMOwJ873xFHQJLVvWEYsl8SbnVL+2/LSzGBCSl
djgaJdZj0Szf6+w8q2STPrlogXHn6DSc69gE4OI9aFBx4lUEcOCJ6c9CHgY7MHaxW211oMU05aW6
5tJ6ErNxltAtOofIjNElExCN5+hK65R/5XOhB+xAa9iYV/z6vGIx+TuWySoiSI94ONuk0KmMyDti
a7e06cF7VwEGs4enWSStxlDwnGXV8qBU2iN+/pHz/5MLKK1q6YG0+Xmrt9EJPSIhP2qlpYibUlWE
Mzp17vYPTIIRB/qQ12paP0CIwAVe5jP5s/6DKgUXn2eArMR4YBEA5vF2WmoUHd59yS03qAvVMXW5
zeAygAUnplpFwpVHDzN453zq5S5y7XtjWT36/I5/6plVFkZNx7dzXG/cUcHQqF7dBQFHsU9HrYAF
7Gfc27iUn5WZYxzTSkJyek06GE1KVPFTnOiB8i0WAD+T+SJ8N/oV1XFQT4DQoMAtYwEna8vNOhin
hQC+fVRbppztd9QLRWumjI2L8h1Lv7iKveL077y9N/hWXnTyhIIfdrjeNiAgYEucbDsM+s7Q6jGR
vMq/vkGWHlvRG5OgnaQXohpR7lRErcM8aCnepF0eqmI6aLwZaCrA8Ttq/4Cf9Md8yEt3zHX/58zp
YTjpynAkJNZ/OEld619dbW5sY2smj4M8G60Q1vCO4ogysI7J+FYl8iqSfHtbubdBnguXnSw0lnjx
XsvbvueV2PTVKnfu3l72OOWRuhhW/h8hMMIjY3iNOTzs628DklbQUtqE0+zQx3+D+CpYU8mVBUbG
FSLlVvTyan9GZEzMSYwCpOr+RdSsXLHNOf2E1S3PmpdtpmR4tWHEgGQk4cWtDpg9zLq2Zx0sVKxz
YqLD3NtPT7b1JjlXJ57qokf5mhgX4PDFQUwS9LP9dwKYILSMmsyDcO2WSmDzbatJpYDDAe/dkPaT
60eql7nF/WT3q0mkiDiNCsAEXc7mUO84WJxkznGK8aKXj3eGCe3iR1R0fFAgQ6DGZwcuUpGEML42
8DlhW8zDKyJY6VtwYwhf4qxSvI7vmdMy7jf6noWaixcqLB35cKYLk2Yu8KNUTBmTPKtYWUYAfDIn
9CdRD133cQRkdJfqb0iX0QMtMwNrCzTDU3vQ8snmRMreEdpdrPJbKUIcuJ1sEguhdmIH1g/xxjfs
WyYEk30ZQdKUo94N+y+jlROj0Vw5HVezA0neb4UMgjxjGBlFjzRxAiT57UPQ7Lts6wCa+luaKcOV
qdLZdrS16EumUb+lLRmbXUGLC//0/3QELTkLhd0FutRctG0NKmu57riWG633cH5CWEkGa4UHdLkd
qQtO2np6e+/hR6I9FvLE3ws5n4APUe42CN8Fj8/RvZ2uthR9ovEHcB36QGA2rjvBhYvCbq46u77I
ZgbNaxfSOBAeT/5Aj8zyvaZL1PX6fXSu3wUNf+YwRioCWq1sgPY3PRH7HAMFchIM0n0kDboKdb8M
Ucph7e59nBodOc/a6eLbEtXwgiaqEeKB6fZsHCwfx+UsJmZxOQqESuRXgDjKEQwVt/GK5x+jwp5j
8g/++wrRIHZlQCKbs0s1cKO+nrAVBtWq1yZvdlUc42Ds8Zj9EkpdN7/7r/jf/LzN6d1QWEjMAlIZ
8AOUAs6PmyfrPd1+IGBcd0yOg/keTeQ2yqB5dfXPt+lv2cyIkndlcPKYqTa5UPkKcoj6Jo+VVun6
XbNd1rtgQyQiY3cKWUaQHOSqkAVrzno34Xf7Wscut2fTHoxil7xyB5rPKr3I+xF1cLoG/Q+MxpSN
+/oRVx1Oty8facCdNvmmn2SBx49FcIfSlHNTQeFIKLQFK+3EMycZz5P8hpy9+yf0yLmQDC9KAPIB
8bPtfiD0RbtLbEST8SZ/AVfVCFDqWhiCWuOxqleQKGpyk9G2tL833wec+SElDvTq9J/f7xgOtfaF
7ihm2xESqdd1I05gtCxUMTH07mFBiQxc5qLtEBvg8+7FWiFSfzCRV7pGCo/rFdcjeCIC0eUD5cpB
n4NXfgTHBPRL9trC38JT85A3U3k8e4YuLu0DwKyLAHwS4JNJkuPSzpUquYZAbakb2COAEeku7uGS
KwIrdxNQRNmS+Xabi2Ft3Q+gwSzgKRLuNRA2iBlpC+e8eXbpaFDj98epl77Sji3DLE8tnPhNu4E5
AjN7E3WD7GOVgp6VHtj4YmTOCYOpQBWsaGmu5LsQ9xX0604h5Nk9udEudK+H1dCQeEhOlsFs50g3
SmlvEYH6XO7XRmr8BchuM0bszVNOtSu0Vn0b/+26fiM4joxpZVdEh6TPKXhzbUK9yOsjLs/s/R/L
nz4GTyh51KgU1MwO9QdLgWsNB/RqxFfcvtM5+ycwAHY3oov+Bbzs/7y9C/OuV9PRaoUj1dVsLWF8
5CXmGXF/QGUXgU8nReB9a+tuJX9ghSml/dbUlswZl+6ksbvQ3Fu9vrWemt6zSRIdKP3Mn1Wdts/I
0BqhlCbN7fJUJE1CwKRUGTf3O22XfiT6dgIBNMVHdffnUqAPPomt7rQ4fZ1zrAjY02Gbt2B7LpwU
Ojg+BE6XJNNWNZ2tXaNH96Au/rYy6bv254jAkpJIXBGHsGvf+5vjDambr5x/E8rAdyB3BMHiibSz
xhwlrtxlBel0fKWKE2AFEtgr3lxz4FZg9VxTu0L2Jmi4ctBemp+ivVRflovB2BKin81Oh7u4piZv
02aqBvVm0S6lcRnEJboxet2wNcKedHgeOSIjwA/uHJLL0xhtAwSmMfmfx737Cy/1tCnCm5mFscE1
SOtiCDuesAi3r31hu4xTL97bJ7cPZkgLXcaOS0DBh30XgeDpdOxFuyVVHGbMeEPWsd9+rUqeShT+
NC+GxgcD9Y6P4TPHq/Y/GEkKeREh0hYv7OfKterhDNy9TTs1VXEmj0aUp2aq2bCivwhN30qq6pZK
yx9vuvSrAjLwe7kXdlH5qe9IYAGx6fxl6SUI40iKTlyY9rTyZqg5nD5NQZ+Lf9sBHR0/eJlT01rw
qaBOIR74sVRfcf90YtazAo0XIZBwEEgHEBQRZYrTgqUne/81vOiRETliNhfI9ixUnu/CoH7r1VFa
FehMTQo44L+g5yiZuIuDACCkiFISiIJBz+fWyFB9DdhRuPGHxrVRmHV0/dXQrp3xkBVHMXlFQLj8
uWPVvSe4bAnQMbLZ51OGemNPyqi/ybp1iF2vLwLkkCOs/1RhSO/b35Ncurj9knMd4X0XxL9WLZj6
wsauU/DPDHQWOPfcYlClX+bKzuj5R58Bw2NUKMVhAU0tfZ9Wi9AW7WatKqA50wNzbMMwJK1GDxFE
r5asqlO988UGxSg6/0cBszO9VBJxrRnooT70sHK/OgR7WES1N8vY0j3JxGF44Nzco5Y7dlE5XrCg
eSpL4PP8PTNyUD2UlzJ0ZRuanIwMM8Ta4lbQ+pzaXwDXSwmmRgHcEUfhvQ8xMGSvrpyj2001JGzB
iW7v2jyd3YgogWJrmUbqVwccnn3gI8A5iV23FgZpQymfYUDeJoFJtbw94ZYh1zT7iNntJRN/mZLD
foxHaJaj5ZeDqpeZN0ryJ48juMgbG4lXsza4SXV3pAnqxn1X7/oFptgvywzNVtGo