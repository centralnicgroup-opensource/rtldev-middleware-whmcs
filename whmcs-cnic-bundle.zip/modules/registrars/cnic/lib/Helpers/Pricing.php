<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnhgMHg2VQ9TMo3CEK2ZkCt0tvCUllRHRhwuRv8UIBPHaZUrxGx4H041ktOefttC+KJKDuv2
DG0HJFJ+slmH9LCjYXhgHAyRHnzsUbJvStVJU+mUZcR9ObF2wO9wzWYmOuv3HYUJdkR3vWdrQnpB
WqvMqiI9MYnAcb7O8lAw6rasErE8YbsBxvpvHD76vCdUS0Sla80L9mLYREKdtpYnmrpPZtWaXoIZ
DfY3k2GuSKItVKPcS918Xlz3UcGqeuhwq8gaVx3TJcoLmpISkowBr9pBQPPe49/uKMrpdmv5wai1
bqOUoKQuVk9MFVf2NAmpRlDFzzc30pdJh1wASZxaFziPIwfc7uCSyRasdhRyTWsLdWxdRQL68FSj
b42gJmBVS8NrxEsIca/Ur+D55be4eNgJjENwXrw5JHMAFZv++Xvc8DGWbg5Fgbn96lN+SWzoDBOd
o1n9o0GYoVEra3V+SFcMxArWcnTfVUcoVsf60epU8cXLHlgeqsFn4SDpB/j0sAZSZABa1QAR6GBX
rO06MZYONG7dZcX4TzZKEfeZGpaPErA9o6Fq1A5xsLWjPPwv4pKJUzh+Ca9qEvqLTwVavA4n/MTU
CN/68Imgspj68+Gu3wPgU4BmJ2eNuPhJidvu5BZjyYmqqIM6anyefl6gyEw4UsJuBPmfJjBebpy5
/m9rdir/gVw0/pynafvOX/QxBfkCOC6ui1n3x91JkrU5ATb5n9i2zV/i5I51tsaOuNuo/HTrDQA1
7ww7sEyuda84B2iHJicSAI5iydiSdEhpbI0ZC2lSEeieDgdlKr5toslDzegf3grKbhy9rnfJs065
m3Dud3jdAq3JMqiRvSIc9kbWd47D7o2nfwfk8QFKs6JPRlzw69ruKi9oHRxeYrhMRnU+GgVx1V48
e9U8CNi+EcIqfIfT7uBAOxW+1GgNXHLH88dWTwBp/rwTYhUEnGxyg1v7xZOXY6VsSoWJTXXwOn5j
wOHX0z5+wn+ATxrgUj4sGmo6uV00+0BKKJR3Zv4hvEpqR6X1UZZn6psKgUbifVecjSZfyJS/q2gU
Vq0rl2Rtcy7TVpYmu8x5zF/n/ZJXOr2L5QIvDHBbaSRg0ueZ6cRzQQ2VXOUwD72FiYa0dvfQpV1u
lgOOHbeD3yeuXeWFd/idBc3InxWrxQeEnlktTLQSU3RYwsC5Nt0wiRHtzzDEh+4g+rBV6LT3E24u
aFT0JLOR/EyvPF/jwZ8n/vBqEUk1/PaBdRTBBGMNX0j1IaGeLKUMIzegzFgUO5R5t5PgA7qV8XhL
HKqP55X9GpSCALtDoHZl4LE61F4n2ebQSnZprmRrgG5TUENzs6PydBbN/qJEKnfACymCU9y+gIWo
nrY3K4aY9PnxtmeHtdLxdPiYlG2jb9Hv8YyKU8i2I9By61ZxBixnOEuHrpBPTgKYN0xfKQsXBabT
lBUcNf+thSXx6ZNY4Zg0piGWxGnKZR6urvmf2N40FxiWyK2q5gBolPXgiXYpICcbCApAfVNBvswC
liVqo4BsRI7hHjs0uUZV9m1/wWHG2KlcYVRvj3UprxAi5+gorp0E4yyfaf20u0jjwsft+cRwCvy7
WSRPDOv14VXtNEndE4LdD5jvY7gg4PogJcwzRBhHtfAgB6PHfGaEG4YLAWj1VnKK+Fm4iQDlKA4d
Go844TyEypJSq8JEV2x/cqzdxkGDQcMAhLtd7y05m+wAVQxeBZgztMjFqWAdkOTY4kjI049zKgA4
x7X41mSjhdYWB0DGZqRRqyhpBWQzPdBiWj4UKVPluJw1UrAsd1KQ2JEHj2OiW/z88+Au4w9M7amv
75S3xZX7B/MzUe0vQBg38hket9bYA7FZblazQ+BHFMz1vkAAOizW+pb4WRBKGcz/RgE2XrjsaTXU
U1tErAkppCNxzcHbr6hCZY3PEfaZ4WilJmoUIpIsN6Ej2BJRLg2FHNXQbO1kXDUQEYlCU0h6CCA+
u61WwPT/HkAPQWBlOENZJuJGGolUA4ISoRIN6A/55ZgMSp6MUDP7drLADl/GIo3bjnHrHq3a6h3w
p+NV/sR2J+TQp1WwBAHMwWxd/CZuuiLkDmcXkONo2qSI8Ip7lfcgk0MW5J8U7buUJa8xZ5Ix1hYg
HoGQ86A0PjQ7yRpY9VtO8aeuZ5WcoE1yGu9NB7uj3yvK1OKP+A05Qpb13K0dW40tj0EAxLoU+jWI
EzYPoJgDUSS81YSj54A/hey5yoL2wb3LY1Lnl0aV+RQHstaBYYzwbej6Xd+eD+4a+ZxfKSVeDNza
i5zFp1dMBQUBsa5Nuy8U+VE+IjD1esTyI0FcUK2wys6C0vPJ3TIWMY8t0hw8ysGTAOFmSQdvMxHM
P544zx09dNGx48dt9uahnfKHlklJktz7kW96oSFK1A0mfnkK79nwZSziPSyDlAF5iv34VpxQ+/te
YIhJlB3ZAVxFpfqiNtibmQJaYlctJXVRaJzkcZTvK6hNdTzNEU35Jhswjo5Q5mzBufOYBEmX4kH2
VE3a0iodSDvChqm+WptGEauiGHZAZO2BH9jImxgyLEhNBTl6SP8LqWxVGjK9ZK+7sLgU7NjgqMne
XITbc+pk6EdPumx7zkZ90JzeucPbacPHwOBLOHrIBTgOCpY3NMr5GHLOy8kHHJWA7gBLHVAUHwyE
8I9YBw8Ll/QqwGO06uesDd7/aaraG3M3KqKhlElOchdRGGWl1tM2ImrrcyGe2ax/bt82P0tO0E11
Jw9achRSjHagMakKS2idWvXI48PNGYjXdUFJ4yXj7d7l0EwurfoFFOSf1709BWZvz4esMVPg1MBn
vQbHbaK9abktU2+cOP6eZ9nrsfX4c2ExIOr3PNh4VG3Xfk/iQCfp/9i1/LpUXa6vtOyIQ9vwKwrz
w8gnrFplHK481XkAfNEx4RjL7/ImIFC+0O+Yojft2gEfJSwSUMzy3mGI4TZkMyiFBwUFLTJvBbZR
7UN7jiveCGorXYnZZX2hcLEL36JwNqahQcJWQ5M3OMzMEOTNH7K4hifjxoeGqXEDXyqUbgijiU1i
qt6229pw1JH7KpqoU2vomNcXVF+gltkGY/ItomfUOuWKue603scYrBJUyasSdH6yvLhPKxUEwRHn
5xbYyGvv1qGRCEw+092uVoC3UhK7ATnThuDarUVahy7iz5tyJlXeUYoUZ1Fi0YQlv+N7MiVrWebN
2VBTq2I4GDOdem+xkpQhjYoltGWUjZGtgaAfw7u5ERkvV1eTgPUX357xWtxtMOcCwOszrZi7TR68
TNQ7m7nWCY+3Sp3smFgD4OleIZ1z0XwvFaavXezYIXRk2NWHPyZ7bHaYYhAxKnv/un06ggJ7r0qf
Z+qiC87b6REHjxWVDsq1NOpovS/2z4olvHYJSDzAIMxxsmNF8albf6y3ihpxlKff3h3pcfqXWsck
ZS06iOFbYHjJy94eTtQmJtlOO8Afxqz+TTUWczD27hh0YxbojCdn0ApxsbH75TeQn0Qi6J935RPV
jE5lAi8rdSv9sTTS+7h/SP7q5jMZ5bLJNT/JUXvZn+0a0TvnTJvv0fWiXs2K5YSA1adglIx6v4xN
ATa1MqCDuJ9wwXzKjE2uXgqRez1MPxbQc7gK2cVOvf6G6dNkerGlqG7wJyiDtZAEm9ODSaLQScon
PqIetFmPxXl2GNTsI62zUj4rA5GxSCTvabmSjdsdYsyKpBwfLvhcWRnYzHKUCZOMONcMFu3Jnyxm
BZktoMnZ730MfIyLlBQdIJSxIrUy3oV/ZHRTqSEmbl5TY0lNBsczS8MyEzzEA7c10ECoRQ1zYc6I
evCaS8+Dk1VXCtU36F6akmBvtBNn/TVuCxI+WlCbgaRrZVgGx9723R6dyKjX+YiwB9psvUp8axZc
aMOu1vsqKxUFprT+ChWmkAhbQpz0+tIvtND01kHe3onl0xkoE3O56NTy89pntimmNpG/3EDyIhmd
okc3L2/6GgiTdw8dlClSYo9F2/dshacZuB5xrIL7gLjnnH/ALrJNLvXylQb7GPlNETX+zsFo3Nie
+3ABwCOa0YJyDlmkcJ0NwVZnh3wJGcEwSXLPHmWtmZJG/Dbc+tzUYuiPQWoQAziiti3S9vkjmw9n
jXleKgjdoEQdq92WHMHEHYrQsiN7pXkpzcqpmBABEIQ539rFscExKp6a5/ccxzldV3ClXjPCDElq
wQxZShDuQB+BdgFpn6WwT8/n7eofiGQ3xHrMJP21YCCl9VkZ+5XUXSBSzArDbS2RTqlYvci3pBX6
y7E72Ve0gEN4xBtfgvk4OviQ8F8CGN5PsGsFZOJaoWxpjVelgeSfIcChEQ5hIgK3jiYWdA7S0OMI
n26iJaimAIeDDV4oOiqieltZ+Q3whzzvS49LnyMqXvgNzB6RXFDwUFV304PDKqux4oe4sxBHUO1b
yNJv6Z+gbMuSRQJw5u7KW45kMiixHIqoGkuks6aUpi4Vf6YE0OT3mYkGHcqgoYyc0FUWSEQlT40X
EBEgNa03iebqNJriUzR59JCkJlXts2YfSlNHsrP8tzwrWiAbeij0aCXJPvDACExSzcQfMaJ0AVLh
v79YTIOKT+a0iiAo/aGASFAEH2Hoqu2iBgqJX+GlNVSM01DD9wBry6Py8NEliDqLaTBbi4hQV7LB
/hRqyowX5OD0PTLgrAYEf3b765QNZBAWJFl5x8oyxwMm3VnkcPMhb+MKKkptNu79ngR7LQdVDWkW
AdVPykxrzv5YenUNtmpikRLhToZj