<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPquBiwlIwWUCgxWcY5YgPzH1Obt0D15zfxIuWSXVbkyFXfiL4ec3YhXm7N5IYZfQq2mg8Rq1
gCvCWh00aZEHHoFLNZkO8M6gh4GAJNJgMsHygfhURX37lJdkekaSZSgkE9fnPrexLyEcq7lCn2ty
0Y+/nkU0B7p3BP6f2kaTjmHxZQPmJ8zfhmrjbKE72TdCGA99dZbt8fBh5EtHk1yN9J4AE0MGs1Jl
apOKkZkLk1q/lIb6tn3cJZAwn+LBXWNCsHEEiVziFXhP3NoA6aoR1ZAhpS1XSBuvi5xKqoRlGWwo
IuXCch14X9Ocrp0Z76wqtlwLSdXNBYgHTB4xvmqT+YcYiaIMqvYw6BMTki7U5K1AyWdGYWkyiZPu
TVFICkX0SH/Y67AUPY40sNTB17qkD7BNBD6wMXNjEPiZOF7xDECgVjgT2TuvQNieeNOZB6Abwjdl
7KzafrXBkew/gKsZrlLhYkapFZ6xq+OhFwAGKCWgLVEd7+MbZzF8ZlvLsMsCfq0OvLimu6R+VQwH
+LYe/ReDqMIKWtErRTgHW5zwI/aM2Gvb7ck27TD8Togqnn5F53cjWpzHG/fub3IjygY6+G1/EGdT
y7ZP77GczvHU6D+HQ9RP2NkS9bFe7GVkuIn+vD3o/T8I9XIgI6qVaGgLaFObSmSUbWpxhG0v8CbU
w0L7sKNnPQpsAiemEuteC7CQQMSNwhLdps+n/5jCxuk1fLLeJkBaHXYg8lVi+RvLvdjp4+AQdX3+
uYa1IrMIOi9CwiZ+NZwK3yaHYQDLH3O60uRFtRG+1VdWSxUH9A5vKSrcrckjoCwiV3L5aEJQEj6j
O4TgQKmQNB/IlWWcJiUCJQ3La41pQqkGHcCsYCslsGrZ2CH/Z+ifEjdFCwoJ/BiklBMSThKcdt4H
GAxWbPobip1tBRgCB8ygc6+tbNkoS7QJ7PpWQ+wkRhNza8XggptSX5IJDNrpFisXrAiGrlop7MD7
nh34z9zOrFn2SVWm0ai+VXklmpNhvu3N9qW2bby74H9xjoWFmnc8Th2ttO6UpGfYSmBCqxpdK0Ef
lCLlllpsqmwLKakVF+LFiuHrRlTZ+XhCn/2X7Zbw3Wg6TVmYuch99asoSe9EC1phc5Gwkxq0N9bg
lW8UhCJb8kHhzxIWRAaYFGM7TyNO/TDwbv9/qmmQemoAtGzAXLn/vbNu9NDOv2h0bO7P2GIYas3h
ShNyoX6GukY/Z+MOB2eWxTYLlbzQc9u5K6Yjyr7NSTcyIfxLgkXN8DO7LkMX6bHNqRpQwKAFq3ur
y19nYg9U3EOS6VTGCpwUAqTud5LdiuQVvIDk7zvS2fwh2EJMpH8488lAfLs70is4oQFmzv0iXhBn
Z7QLyQLiq8rYp2TqEE90TZaG2wcF/FzZ/PpcsPWrCwkahTyiItsC7ruVGb+ilLVcXiZ63+EolahF
jWEnUlovM+KlUy9hrK7FOGPskZVDI3NwpJVjAJj3VVM4Jhd7Rom75Lww1ImOApb+EYQIIdFSpP4u
ktV6nFkg4fBicplEuWNZ+A/4Z3uSNuQvTjnEYr8WYa3/7TGrYw/jsnuLxSnAfO3oE06pgGe2Y1Yh
dYjncAZ0Pj1ag+fnT3Y7+3Y9BFRpW6LcgxXNqRPRpYxg7/Lir4TzKgCsI2j8cQr5+ME4IE/R+zvH
9lM2d1Cx6F3nhAIcxRRAHp/PPdm6BM26JXe8V+m6kcV/9hRfSX9udW4uOIDnnj92UdlBy7zfBjPl
38sbf8vCnLneQ7NuXtEymSTkEgRowXudHjo33JWRxhVzEFJyyaOEbDNVv06Qc5PHW7s941IpUHbE
ywklpalnkRk2oTRw++5t5jnLKpwAURYmqcMCi8Kaujh/ICphyXjML8r3DXNAXs+DMgvh/6XTSDO2
0zjYkXC08dQJCRdWpQq59pJr7XOlnUYPQRd9UasHkpdQ925abVQ0JRTC8Z7fiI3xUqn+7ny/iXm4
6fkdTJSKobJpk5BaVH3pHFz/THtLes6EEEtP4wpa1u2J+uHceeGHCnV0RWaMQF+pRQFiIIDzMYDy
Civ1Qd8rUZjcab46fE+CmY6+GVqQgBt2WU3wxNtgU+Izufe8L/xD/7/8Fl2g6d9twfI2LCYlXk1w
vLPsazeNi/B9hf7iU8eVVhBlxuFZioSYpxAalaY5fhTXMXmLCYXJEPA67ZbZJRrWJaQ0AK8wsjku
oniHPnIrrDQvXG==