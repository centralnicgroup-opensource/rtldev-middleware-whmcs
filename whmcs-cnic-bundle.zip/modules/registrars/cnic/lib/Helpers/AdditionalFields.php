<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/N3eVHT8Xhx670qrpIHqZ3ZSwhh6qq8rD8d5/ClJoxJPokneN9IbBcKsD787tHASEIvwa++
qwv/l5kRxqRK0MIgyYuF/UQ0/KsmWAVdQ0xgP/CmjIlWGxoNV05FgRdHzpOj5Dnf9nAUzg5AaCNE
kC9yvXMRtY4+16WCMBs4MxLPSaw/80f99hlgCan41jRuXenn2s8AFZUzD/7mAqXPFjIn6XVXxaUG
wbkvrOK6xxzIEpqHO9DQRZhgKGB1kHXlz4GizIwUhy9LrGofFGIgAFG//w7FljOXR2vNT1Lb7VmA
hRSGE9x806W12miPn2N7sk/9bMgY8rlu9ORWYLZiPRSrVjM/ZX0ZOtrw6byo/HTJXHT5BY+d7AFt
lVP5kIAMTFH68toeyeuSN/SkYkobaC16+Ha0VBrJ3W+SlT5BqCoVFeH31lNNtBrKgMlH4QRAyu1z
JfRTC3IwrM3g3hO3n/bL4hVYtsZ7jq6lBd0imUZXiiFRuTjfRvq9WdTmbfzL6VbOCqGEVDBK63vx
2AWFDMXfgnLmTxzCkgJmQqxaZnXbhW1XuaxmPjloAWW+iUvpXB9MGuojlMQK7iWJ80jH4OVHeHoY
PEnC1xOWVvqSm61lc+i0qDhfcoJHLn+h5YCQ8tBWV6OabOpbIq4X/r9nPoZl5eedeaEWU5JzUOXO
yXYzWLzSMmA44bQ4OpgYkM0px21CbGNb4jyzXMwTX8ingop9U08jpwHDKkH1hF07jZFhIDd+yuLV
lZebnm5+kSrV/g2cDOHOdzQ2GhmY2JelL01XLu5/goFEVboY4eGeejDREUZ3k2zvmQkfC9S8zS7Q
r/WnJXCzwCTFODDVtVjgnFwZPygttVr9KS5HKOwf/E6YNEuvAxjntpA4XL4QGLR5Ni4MT7j5vtuh
rOgRIokg7baiIuSMii3kaC1mMJ9u/EjpArAY8tSPTVHCj0SxkZl8Qc0Qw2JY9ViCJ61g3/6v34lq
/SYUxJ0UEddwdKeQkC+YO4Bs3+F3e+daA7btTpI94uYQUZ7NM9cAeG3anD49qxVgnZVGgsp4KL1k
r0ZOurO5oUT5e2ndUWEiN+R6dvi4b1jGkO/A1TeqU663ErLDVHv/WT2NMZWf3LM1d8qa1YzYa3+q
h+1hftdNHbqGjVhzLWeYMGG/bPD++rO4t+fEHrbmwTm9w3vXzC1k4Zxz6x89XD0i+qPVxvAqBjzD
aOTyNJEWkiXJBTsCyww0pge45wnDN2woivsX50iP+Za76jXtdnhmvNuTYJ5eW9FQNpRF5p8asc+8
vgo5vfvMkTOV72HM33CsmmgTrWQNVtRa/eVLsSAjLnZ6rr7b8ZxGnRIv7/+t+BZggaEfjrubtNQD
62fsEK1e4Riv5TGc3UrFLzFxj4wOWqXCw6C3jnNwCzWUkUrgYmJ0vCDBM+4Y5S553oLpsefiQfCR
zqP/Q6K4EnfGRUmHdtEjNDv0XwE22cOSf/Rx+Y0489vMzxgk/yNkaSls9Ic7QBfKhprC5WJyRo5R
XZFx9zMqclo+M5vpteDQtzJ/yCu7Ryww+CkqiI0Y+TtAtrfufvNZkvNVzHbwUtlJcCl/vlg7WRZe
KgHg67yP0bFtLYOOYoKhOkSaO2yH+oj2HNeccFt7fHHQYN9Ow1OPrZk4OxtToBvqhO8V1O3w3ZX8
duNuXLLi40Ae1z4GKe9QEkhJt/7ItvyQvv+aXGQl28zC6Qxat+7CROw0W+KrHHy3zpuhcj8zLpJn
4+Lu2BgGZCoJT5BsdFqV/Q+Q54F4YoNiI0XUz91LKZ7j4xsduWnJvlkBlT/BovT33R1n5SWhs5Ot
mVJH1//7ssjcj9CvN3EhgYWRQgU9H9gV+EjlTtsfHKqWPdvr4mkXsVvewajeuxtzL4/rBFt4k3wl
9rhmdvFm7ghedbtriVhuKT/yb1LTYUTB4yWXN4dQw/8nIh7wmzNPGCXFKe0DbZXPIB1IKVdHEtgX
XRVcmaNO3RNe78++5TtaYJV9XZ3Aqf8NjLkgeXOAOwONV+G4Ee0N+jzQZgi8JbSvhanAXupCCadA
M2fryJ5RljMRgPE/zMfoalgTMlx5MdTb/mo8D9O3EFJVDsxpuNO5n3EoCW4iDv6pb+PQEv28+6hU
C0jDRx+Mgc59guBg3ig1p6mnJHRc1HrgkPRf/LgOHATOjaQs9sUJxjCiZirDH+u7+C/xigi1iCh8
4ia=