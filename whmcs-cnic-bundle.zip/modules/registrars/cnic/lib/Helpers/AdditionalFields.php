<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy82KeY7xAQlNh77gz0CVPf3pgGLBV7R8PUuPY4qqPe9XXNoN5rXk6louvPN0HiYzO9ucv39
iOzJnWfz9h79Fum4XOU5xjOXx9Uw/zWaOoOzDgk9T/H82iEZOgO6poNq5etNepzA9nWEXkuReTjb
oRkzt+bXKYHbK78Gq93Ujle8fDS2u2wQkgjh+Z0Hom6TmH4lUChMZbpkUlpUHrJuk52nBjb1ucYD
rETqVCxaZlQsFnWD5iXBHOHoShdyUOO9CnGdHN4kOM5PifqpQfusWHk/dgrfbnwn3Jk8sTfNqu+7
68Wz//QH+LE0RTucEdQIIYXBiL5H0KM2GY0vgXAMoWdcu8tHw6lsKlOe2ELHen40W1t4B4sPkoBB
gNwKH/XTlnh6t77tDQ1dQMnfWUHTyfAKJGOZ/wD70aMP1mMEXc82LIgs3yztjy/7iWVaPb9WdCz4
4aN9xGBJAoMC8CrxiiQnhpSo66Xw4tdwVGQXDQgSnvWoBa+ZovdWwgpn3m3YPEEg2Hb05YAAfELf
T9+SECnSmhoJYQgNFdq3c3eG7hkB7P7eqasUQ+IE6y5XhEAaCrT6N8LQEgBeWPFcCVn0ikUOztiY
hNmm2n8HdcRv25Efp//AJ/niM0eZpU48furh9pjCaGwwlyXK+qgkIH8XtO8VAKE3PgncqDoaRpXk
Z7V4Xh4ZlAzOklhP2aJpgkvEKuN/1Q2g2HZzfZGAYFORyKlKbH1jcXQjVD5PevW4rF2MHitfGr6B
uShxVGC7cbiY/P7ihrxLv1kzH1SQm81ufp9E5d3l9DanuOKJicDzmRDFQOje5L0th8SlOdve/K0L
VuUg9yvqcdRMPDraabB6M+2Hklmctc2qTPP4i0hAI1VP8UiIxf5V2o1Ks/ry45LCZlDuHAkYYai5
+XvIzOjKSQRdVPKG9MJ9d4jZJP7cTxXF3O71c7ax7BPWa7CthhuvKD7TpH2st87hIMEGti7E+n5J
prn98mTM1VyDDhuSG59ELHu7avzeLoyrnok/jNgo4QgvqZBWT2wvfgRisw5EYujZcoU/gdQB08TI
stEdz90eeOrSToCrIaFXpEzE7FKE+8lFEqBoomQXdpx8N8n0OerLSLnwr2wIPB1swusFPC5u+Wi3
vtevmyW5COWIP8PJGXUd2WGdpB5l+a70rfhmYQ+XJMFZFHKIs5QpK7oFjIM9SO6lfFVH3tem/Osl
zT5Pi4WcL5GNYbKT+bZTqjJ7IVlfFfGoGRolQIa9vho1oGsC+PIXWUF8uYaDpoduKNZfoInaxfok
9/BgzTZSq6V+5CRNh4wCpRx9n6Pz9sAKmQg2/0HCBompEjP2R/cNbdCa0ncOaK4rb/0aJsbz9soK
uHMAmUQTI6ebTi7iEA13/rqjpj7OKmOO/fIgbWKuRsaSNkYWPFnl9SHyY3Ujdx6gdGyw+AqcBohg
n2BV1sQKF+zQQHnRRozuKpyLWTCpc5XymBNnNLq8NBdPbuBUTZI1ek+tDskzcXjAwULb0JX5f10E
GIQwA4qGWAb/JMMLwXah7LNoeBHsPmCHJVhaZUnYpBCUbgehMbzC4fhFElckSx8dI5gq5qPj2iyO
cRr3E/gPvh4ZlUfPbSaxQX7OX4D+QkUiz9NVZIthCdAlcTXU6+fEwCXFY/+77nbiZeY1RHUPYgBB
gdKJDSQ4J1nwoJHCVriOfw/5L3Pz1F8+6C8sJA0eyRk2K8crn7XYcnD6B1BYzLm5htb1KnTQb8iF
Aw7ggyfoRRtxjoUDx3VrSKAeJSB53yEL7evgib3kXknJOFgVXpl/ifTRiFYwgcOkzTchsOoGoN3R
R+tm+XJjrJYWIOOZ2Nnwuinq+bc5jeet5iypGbevi7EwL8O18Olhub3CrH274FJfJvIM5uGgIXJb
ylmdOObaUmV+ceNu9KmSePFV8LXzhDhKG2pOb7kQBpgm6lQQQErlWbX7KAB5RLvCxWLY9j43Bb8b
bFb9/9iYStH3p5APujwTwOYuUSGS5pN7cyIO8z+r/azAKbbpSPn9WFATrCy7SUp1tuKwTIlstiDe
6U3bYvthEZ/qizVFubAANixhgFdHtxRWv/sAhnDg8stRv/Xp+Q74bKzs4klYBAmlrjIeJyr3n7tJ
YE+rvPOL3GIwIw+SZTbKDLpkxUwIUlnGc9V97QXcXpY6m+Yf4eoAMTKMaRCMu6RDOJuiIEbjW1+x
Wo9RYSDiLll27B4WjP/Ke5a=