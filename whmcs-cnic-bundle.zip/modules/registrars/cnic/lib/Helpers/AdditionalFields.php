<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsUciR7pYGg6YXKaai91I5V/Ex8Qs85/FxUuiaY582zV9ZQ8OB74fHIZJ0p3KlrhBIB67XyP
8koPiMLPy+TCeoIQjGkdOtD2EBr9h10PuWZUyGTw+pA31GtHu/6tiMBtX+DnleaGO131jD+C+3zy
5EnGwqDzOJeTkXFDbGA5OGZiPtLNEsKV1LZGHlMspj0/1HTaUbKXvAKOoWfd71w3lH3VJUX0IAwc
E5/cED49d69wA4GpTrjTWArcVDr67nac9HbvKFHTFJwo43LofB0Qo/2Mm+jVUbNHkBqTeabI68Dz
fYSHz1RA+kB1OHGFOHozte2b1OJ8oPG4SbjaPSyibaEBOvwziv3AyAZ06toELO7/p8ZTcu/HN3+6
IfCBRfSvQUaiCqsz1uFVm+ajxMo0k8lprkHcYLSIoYfBd0nMdDc4KW6AZ71B6JCt5hCBjigXJpg6
S/xPB68Vbm2FDhT2KB5H53lXemYvRpZ+R9A/YsmBQeZgvS8iCHnrcYFnt/yLuhbBzoBw4rStJL0X
wL8BYiH5Uyb2C1fOrA3lmiBOVjhMxMiK8JtXuVXuHyAPdLpSx0020/ock1njS+/ZfMRor0G1LbMk
P2cD5ycBHwvFd6vvo3ZEdnRONQsHIu9B7mbvIJhMQ+D8UuHy/qupIjCMqMzHsh19Njglgb8mdpsg
E5lTTC5jAKIoQe7QBIEHCDf0l/qrF+Q01Fm9lrTYXEP3GvOm/8ke70LIe99PadmeLToAYWFQLAnI
KkXry8CNO1Bliccdh+rGFd1+/fTS5gpiFKHF3MeQ9F0F3NqPmzIt/tgV6jM3CJ9AVVAfEH7l+9Un
gXAdyTFWJpV9AsC54FnAB6EX/0SxYm2iyz5ia/SOlz9zSQyhy4oKj5YdaINU7Sk/AcK6hg+X3h0K
otwKTX1slmr4fmQ3HGG2ZdImQLxOaaelXljyxgNFe/ipOwehlI6tyNxetSFCeTpDqim6KUp2gca4
YoRrun4+I4SY3/eD73w3oN9NfrVXIUUcSvYnY8QtgDSJKkts4i/dNM6m08SmVDnf/G7vp88zNpbg
VuoUYYg9mlzYrZ/5J2xu3ZQgHy8t0RXylHVX0XR2L9l7kUZNVyQbfacaflhQJyOQmsydGHH6OXx/
FcJ21+z9hMhYF+x6dfqAlRH5CU6+JmW+uYH2G5ynlBM5Te2TM3iCcReXAETdBpbxRdq6JMPHPV+2
DXHFQo2fmpcRKny5Oz+4+JB/28b9P4dh5ygd4ENdegjEU8f+a+GAEegnH4DfJosLYhHCn7Vi6pXL
QPI+ppUsuuDb3LMr3iirc3EQ1sRfI8jTixBaxcszSrzG3hYGS5PES/zRW91YtjIl6vm6mcWDbjN7
5KMsnbUQmFmKTZNqgnjSSPPPfnQWywa/B8WG9945WuEaDBu+hy8gGBefgQEyw5jxXv/B3lJgIDBs
tUr0foRlphJHmPyCPT+dLBfAl3ZYAq1Y/FxCbj5UCksIdXqaNsenv+1tbSi4nS3649P7NnU2YiQf
U+8AuuLnDhlojas3krOBxo7b9izB1e7jfdemMgiAhKzdXMsgchj/CVJODOfwlMpWkaFNJe1ddauV
MIia7AzGfd+jiGkESQy+m7ClRSIORmDDvp2cHWzdoXN78g00aEc+Mi/dYWwxnNpI9fOwhH/0gO5R
9o8oB+FCEz03Nj16CngVaWcD8CCRSLFDTrTjZBbHFtUh+h+dA0YnzYB6Lop5WVcD/UtjHJ4HEjlm
IaBgV/uBQeR9LCk4arP6rv39c7Z6zpSBEZ0YUuI7xkU+PY5Tlu74kjScAlTJ7MGpLfOVNAFHbHPW
BJhhVj8pCIIZOkHy8NYq43Co2OL7nvirtY4CXny1Z/lrR91pLceXfkFQQFofk+PL7MTFH2PvxnGE
Czu6esq3qVYyDxNtRRoQVIf3+S+j2HWviNWQqfvhMDafEILHxSYnZ2jBuzWDqJw2gbOB0ojVtSbJ
JaUterA0/zse3TDpzwbrSKQZ72je1abZjQbbMe5r81JITz502NsJ23Ppz6LxtYpoDaBfnwJTO+kG
LTljkHaMjS3THX1vL8kMX9eXCXAo+ptH9NRdPrTds3KE0uNODkSgsSQXw0c9gDouMhFcTkiWo6up
HMcMWtgfLA8Pj/u2nTsq9pJehD3Kyfw4xpLQmCMCJ1VscmFUSo7mU0m4rXTslriZZmEr3JiukbQy
yr8=