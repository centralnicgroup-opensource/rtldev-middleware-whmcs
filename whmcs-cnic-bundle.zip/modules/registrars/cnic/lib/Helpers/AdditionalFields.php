<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/Stb7D57cr448G1K2qx+hmp8OIdVKnjYeIukpPr3VQxmMaZz6pYvfq2TbR2woGa7kq3T4Ya
xrpsLcxC7kXO83Bf7yVv7oobvHYJ8ccA4bDYajnISoziVomS0fubmxgCKve76jk/XAzGofyd9zlr
3HvVH69YTYuJ420dCSux/z5PAq+Aynk1nt8GkLn0l/8eO857b1hW23RiDAYhUuP98OmNEG8Xro9U
2WoAqovkZW59SUZgQ9Sp0+o+QjKXHatjlSE238PGOQjJKu8SAFAUjXXANNXSgA5gHWU59ELg4HXt
TWSG/oVdYaAR3clO/wV01Swq5lzhuwl57L2SSK4uwqAvl231/xrhI8P9KJRewDfI/vtANWT9TGxV
Aiz8AZjWCAB3B8FG7xi50shMsBI5Mgfiq7jpwlOSz/RoMyhuGz5vrPfIhH7gKA+pMgCiLGMUfern
y6Sxb4Bi0Uli6O8BHWsUV1p4zjiPlsEBD4ZEq9tywhl4c3Qa4DogImuvz6A19uU4xwgTPI9GY4+W
/G05gcwRtieoNonTxB60DYDu3fSzpJLesu8PR7Nlnng1qyfVKOVAqtDORTnHpHbyaK/etRQIPWVF
GIsO0mzr493gL5MAY7TkET03WRg4G3PeYZDxEXhUk29x4MU84A5Xue0UyFHHe6aPB8vUYyzG8Ivg
muAnDlP39ib9QA9W7/vMoFdKToczdaU8cXUEtqlnU+8s5dGxX/mW2HDG4xxy7PV5rtl+EmpZcou2
sr6+RDj1trzEHYZUbstdKbUcIWa65rRtXXfPgD6T/wJu/IJZbuYvyupJWdPtWntVGiOmONRtiADB
qnukjF0210ph4rXQwjIGw1tqSl1yItkKIeij3+NHeUoqgpaYPR/oqi2NGE45WLoPwgSGWEu09XFn
8S7UVeF5VqbRyRMGqzEShVMfMvU3Ua5KRO0Ld2MFNjSgdyHe7TY03eBbW/mrbDv5xHxku54L4hCs
kXi/zs097ZrGSqe2VWcJiV5AXOIvqMjzdBZnXBTf2o1bm35oQ62mJMAXb+Jh5vBo7JCfN/yhgKLH
jvoDhnWA9MZsxq36dY0/mRhi5YyNfOfLk/HNdUW/jwOGMcKpnCkprJ2NoIvg/7YA9qBLideTC6V8
adWzh+eLUf7hugbdd+GnjuFK8G1+gwub5qUzn6vUpDFqUPCw2mqH1hXIxW9GsJaD1YZXc3hTiTBz
UhU0mpGkSXNTh/D4403XB29dsGVtjOhbjVBM5uCU7IgCYYyoQjGIwHvTpb1Mgl3aPrPpmCkiBAd1
KCm0rl7rDKfH5kj+WD+ihjUsnMTZP0kIv2g4b5a1O+RiVIB7O7ymX8xRuD0i8UNkb3GCMnNn/vXM
lr4HYMiLXXvWNV5WiPJE5suCeDB4OXy3jG0edmCBAJ/sWIfiVkpujzxlBidnV8OKfRAYgRET7JRv
fFZODbyYUJHYQfRX0C/L/csqJaJzPKqHwq+z4YEDzte6aEINuK7x8aBr+baO7M2ZGZhY7NoUpcit
g91W5Nfx9xPnRTJ3K22Yjm6ThCdV5WdzykiNkkTEY1XVO5bYFW1mYgL4e/VmYMa2rx+sVh4Cg0eT
PDuN1fmwu+BQhmHJhjo6UczWHEC/JQIDHFnDRlMR9GmbgvQzT0bRS8VBnTOPlr/UlnLg8vIsh7Ej
FsR0NsM6eyz9d1vFgnpbMn6JycgPKnTEFxAnjVE+gGqW9mfD0iyzSnngqWIY88L6gbT7tx0/rftS
v52IBC9ar42zgK1QDQOHCC9fFxvRGZB5AIbU65h93aCmP20pdz+3iA6ZgbGc9aDG1NJZJFnSxsvP
RjlgqUIULiNEpOgWziT+vZPzim18gwaoKAjd4vljqMCjp4aO1tBYZrBoji14po3UGgGERT/REkr1
Hb5QEa/8P1xpfXmG6OB3dWqVnUUOvhXhhcD9+0Rytqwdl61An7aC1HL01HMtWN+csCgX5b6TmChH
Z7NZhyA1UGomLw3rVK097Pml8nbpZKjs+tpwlRFmT9F4PMADJ8Z8nzNq7CM/FbAhnlamyb2XiSt9
CjHEp+sh5gustSEVRSYSMcC492sl+hKL6CulDKhA4/oN4/3UTbOHv+2ttkcCnGur38PKnziD0FAb
AfvWxkBvpxyx93SlVL7WdlqHAV034r2EvDZKXc6KPxizVrZh82LotUo1Ba3n+H85JzMWtAmPG8lG
gPNpiBx9BGm=