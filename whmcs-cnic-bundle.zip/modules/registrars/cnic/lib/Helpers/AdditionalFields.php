<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwiBUZEqrLu5GRZl4EMcAJQhaWjJeQRYpCUMExyFynVyX0+f9utMC87hvYJABfDufWohl1JT
6t8Gd+rxbO8spAQkn8+P7Dcl+6dnNjeEiEam2MUviCLpIFPa9lmejnUAIzwSDvnruPPxXDiWFwwv
L7aV9OB7QQhU2U9nWx2MvXNAvZR2WDjenwRgMtD4GkrrnAl195Iy7iOVB8OfO7XtPWmiC/n+62dU
7H3hOhAf2GyriY6NQoQH4D3FUNGGiZZPYXZDp7+mtKvibSCqdBikYzISosbkQhQCas9qzP8Xd0kB
SPY8NmOtIME/iwAV52TbboUoR8AQtW7Gkl0Lc8NvkxQiKSmt3L+qlLt9jZZZlfQV2PsnzMnaAZRh
hzWAHa01LczPNb/Rg4yO06sinN/FQE+8y/een18UAnQKFbBY8cKEqtM8kxMmbRpWBAYFMD97OYzd
TbM7VdcIthCOwV1R0cRxPE4ZBwkmocIVXgYrauBVKMwoZp99nG5vPuqZFKKKyyHXvt05m61Rkq/1
XlO0fxpQ718+Q6bPvLxl+tj2Tn+4GOlKs4B8ixZicgDQ9Sk4ZwGLfm5lWn5vZbY95YDH2229uR3p
DWqbM747NfvdTNBSBAVPqjG5bErUGBgltez67INIz9vX5FCmWOLq/qiPIisFS66KHLW8wJBOLRa5
5d8+u4+O5gKznMLM8cUjuy0F/TVhnTRq4kq75OgGng/vMwmHSCZ2Txpp+UTXI8PbZGMHZDOSHsqA
NvL4KLs0cY7ALxuarmfMLfCa6SIKG/BqFgbxpxfunzQNSlqD+TgYdRG3mYCUnrs5Oq4NEAxqIlKV
1iuZ5gKKv0KcMnrVl4izTd7J1AyfuLgpLhZQOVfYvBkMO8r5lkOF71z5TvlUeHZnrQz0zpRccboe
dimWiX79KHUQ8i2jXfsOh1verdgeisapLMWvOYDfNdUC+LKUbSXaypgz/QDepjxgXI8+DMgPZbLl
SYoVq1tXBAiOIqZ/decXBdWZ6GsbOUOnloRNd1ddsvmB+CpBpCLjD6/eaR30JwYlsdOaffsXcgA9
JM+DldpeSA3clIWAFUU2aMbHk1q9Z4Wn1jlmWaQ7Ir0jLpkRiXaZTZOPBGm45j+JCFNt1RS5t2+N
zlo13PB7BcPjHnQhTtDswWfQD9FMUeySIGUyUaV8FtEAl+MJhR5ISp/s+lhzbeOSXJIr0mdu81vZ
XS+nMcmE0lPs03CTY8Xu3I9sM2EV8IBp0SzZt8DxlM7BzA0X4djoYdwkvlaYvXvR0wqvRoSi22hy
PzUiSUxGwjO7XT/c/veBi+e1aAv50M1OWAdS3lvDUZDARbH5z0VyAEpQThBlnTqrkLfGu7a3lnrd
AE4pVbSlFLl+4swGuSFH+PmbxgA28gxhx3Ch70Pb2B5pBwWKy0G4b/IjFNxN3/aOkoz7EAf37uzU
66gB4q9h8GMX/sVxea6IkBKKTL5j9n5V56rZSJuYUhbHcmvCpEQjW2ylThYsvpl6bKcGmZDVCsdF
Lgmo9ukDQf3jMqNBR5w/KGCra3iQ+NoUnTs5qJlcAkVC0z7V3FOj1cuibCm3+ElCn3GxlAFO5uIE
7vQKAfII3nwJnuW3JPrHjlsYj6AOLwnJ9tmAv4hSzx7FgozAVsrxvHw4H0Jq10h4NeZn3XBz5US6
OhBVYoFdSlnV7qbtHMLiWmEmmkVXH2cIlc7+webkzicm/7TYfIqabYJ5WzcavcB7QKpX8/tUxWu1
3flcxHnYD/BUxlS2vksan9R+bCXQB1t3CBVXYViVeEaLzEsfC0fvuXdxOkF2cEihr/Zd5MSiEQIX
Q3UXVz2OTGTVJmrSSS6dmNI8kt7fhIjvzym11oUqVtuiZ0qxUwdW7YuHHxHrc2lebeF14TNst8uB
Druay5uTNMG2N40EsRgd9/cB0w+u3/9SBUc6uorPIx3zaDzPuO85oQ0M15AieE3bOpB+tUj4Iy/8
0iRA5f0bfl5GZGOmv7S4cCLyw0tXz/GCyIREPPeJghPptgKGU0RgAigsdF2Eda8A/P0JV5sitvzz
DeAA6sk4pizW71HveYJ1qg7EnxJNFi4gw2ZBz4mCyGfhIGcP+1YXsDfk1hVfT25/axZu6mEKnpu6
4d1IqFlvFH4YT0SUV0obAPZ259ln+DZjAsW9VFZziH3CrzuQ7CKX/NGco/7wrQL1+9kSTfXe6RBS
lojN