<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrH8g7hUbn1zf/izMLYwCgf4CagWvfMi1O+uhSuS83DlxpLB2VOXJhxsuggCg7BcEPP1lQ3S
YENyUxOis3XBJi6ydRX2BMF0aD6Pqq6rNv7Diqk72M6cJIRmJMIcl0kPaYjCU/KE3/JZ6HrBD8xH
QfX9kAkyVnW5HyJLUxcfd4fTjdoPGsaQ/SS9N77JWKDSYGd1MNdg2OTuDgbBKtcGr/tol2nzfqwk
eJt8mKZ9SlAAm+YJo7jaw4c1iJDfQ4TizH4JxZxcDrKHnBWZAa8J2NHJAsreG+T0+CYsSG5TFNnD
koS7/v6wfl+OAg21MF9MZrBUQrvUj8AYDFKNsPuBonuINkh3C866kfUmPX14ri/1q5rnI6Yv3Z7y
kXRZUKDwugT+PM2tp1pafYIyZkFfDHyr4ZqxKyIkhpG70qKQquEoyVnjGjbC9KZJ8MD8e+Yol6ar
JFs1xFex3tgyxWupaEX3euvcuLPY75isHB8jYHp3eXlBcOH53DP8aYVPMu+lME5WXBNGXAgW9ier
5W+J17zytZLHCukBBHhk4mL9YmkHi+yCRedh5UadD30d7xseLb2bcm32XBBuEYrz0x5GnjPZSVWH
OVbv+kvNTjUGGmrvJBZNxT64hB5HYFuZbaQOyc18J2d/EatUQyJouoik8/R/V795Q5K7WKrwuLRy
4MLQxp6Koxrwd4N7+ULw3a74Sdij1gjHaA6Wrv4pb/NBAzW+Ohnzg+JGL9Vd0kp1t1v/2jx44uF8
+icnC/FfGq/CZTr2r2CqNgwS1XK6eFWazHQpZn+jQHVrhjpDyv2uvNdnQTrjYCS4k8JxDfj79q0n
AAJrI5KNHqtTeB2fnoDBAV76dZ/C8UpYNoKdG8Qh0t6S8lc0X2dchKWeOADxjcG/z0azEUy+wG+Z
/76liGdsbPsVO7aD59t/ReHEypG7Hb5Qdr3MsW+bryiM/8x773kHrw3lpLS08Su70hd3ASsMU/ml
xNyKCF+9rJg8UHhuoV5X2aVgIyC+lGuhKGHPizoQ6BuldzN62yqcPXmakrM2s3/0HHiCacapgEFT
9Nzeu8WB/HT3+r3FraU9fP0Zumi6g1IiWdq1iLSbPKPTUpkSuTunqM9z1XSSU1vd3RSsZj7TfakY
gdryO5TosZbitV/8K+TIx4Mkno7TZuFHp5PoR+K/SADEWfeQk1+nOIBcNsFuaQ9fw2s4i4ZpMAeQ
i8IhIbT4fwo/K2tVZocqHOclfOEG6w+Q68CTdP+uNDjJsN8GZjD1evykXK9fXWV9tbLieebaKvT0
3rdfxxQS0LjWNW7QY+ilN3SDc6lWx/IFVMmktspRAmCqf1wWwpddafVMi8t+MWjDwS9hDv+Qork8
jVHJpSxnMMoPJCiYf1cF20YFwVCugGsxL4+A5AyUtwNAlHwT7PJsD/6XfZapdXWSaMEjQEgZ/oqx
2DO4GZqCEtX4aQpwoxtEgoAtL9ZgeILJ9JzNRWFxlqGq1HiWbnB/0HVWRdBlOgzSYPvtwcqhS/2u
uic4yV6TKZYiaQyk/PIcFQ7SvYj6vS7J1IoFb94rMkFISdqTepcjAvpsXyEc25EbDzP6oI7SjL1x
CURSrnj3i9t31DaV6NDVdonBjcEDQXfNuifcA+wNXj7BSqJKE5pZmtVP71sVNBZzXa24GMgDTUkl
ZIbCIlg37NLBTCjXVDOTZ3Dk3hgzYzpKvI0wvS/vjC5KEBUy0Q6ZaZbgwQ4+UEglAmHPnh6iZRH7
M9HZOJElX7i8DUS96eMqAkVgjx3Knmh/IpWDbKqzR5KdP0xY3PBjme3gTg2o4DMOZWr/29rr7zW2
VXW1qyXwMDkIYQyACAUvjHv1ImL9MQ87fdestBRrVp0pPz3IVnIjUDixM5BJboBZPsRJrLiBvN2s
zHlHg0mHJHmrEG58P81L1Dw2oy9555Fo1ft0HaO4otzNCVqch9rWJcx+jFkNb/v/cV0E8Vi3XJG8
wJSujA+BuJ+6FeVOLsn68lIc6AyH94LT6gf6b/esVlfr0ojWyf5Gqg7xPtOEeMCpS7uT7+jlBq/i
Znvjqqj+1zKJociVvjrT+LIZA1/V3URtPfQsCJVBQ3dtjohqX8uJ+pMlu+tvVCsalv3McG+iofOj
zJrRfbO2RM5SVBO+CyZa7AOMwfnX31IRqKEEpfyfjuTohpszncnupQQObAKJ50m7eKQzlGm=