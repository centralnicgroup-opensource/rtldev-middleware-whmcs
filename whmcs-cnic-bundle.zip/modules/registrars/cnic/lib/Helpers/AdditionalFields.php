<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/oHmsIVVpXBPY9MHv1DLEuh7zYSbGs9/eYu+LRF/Sn9tHrf80XqYLm0/PuPAYlhPGu+dJfV
f5GgPlhcbNRfp+AGviR6OlQP605OCYkXaxoZeYI76ayeHMsJtAfC821crr26jv0R0Wv/8cQrKLY1
TAh2l1X2BIcJ/ebwAofIS4PgZ/RmmDl3c1V/Rc7ak4HoUTn66XjTh+E1saWwKlFrUW1xzvqJYXpy
88lsnVrTgEqBRFSXCzwWDkYrhYm4YgoEUQ3S1RvSKut9IebCxzBCMPaEOV9dYI2g0UfI4GaCsXa8
XaXDnLc3kifchDJWhkNEP4FBdxGb4Vv3adn6mX2qL46h4u31X7UT8n6tTkJ7k3TLfheQhVRdzEFJ
hgJeO3VeIFyVv8yLDv6vfyPJQI2ZIWsNRhUtu4XTwetmEwQIvWLiCH7z9nBk3+zPnSRLxZ2aWEzj
vWTcjHteLXC/eyAUk5owh87hKgwrV2/2aKKkgcAxPJlI6ji6l9NtnFTO7nWbg2PIGFvxpYR9pW2Z
IHfYrA0ZPTgkrmzcRxanNltEt8/bv5iZvhLcoOojZRKuEIKnjjj7vCg3M8osoAjSY+L6XrfrRb98
kpRblHTtqFleTZ0WXO/dPfTUum+aBTnL8q9AhHiK2kAqdL9x9GfYJ3W6E1tZRUx3t3YNeWVH/bL1
c5v5AXqZsngtqHgOWHyiel0/CbjsdltKnE1s8jHziaYAkDmR+egGL9D+IN9aI+RTyA1saGQszYQK
DzSsW416DMwy2D825Moru+GI5XObU3QpAShzSAPJHJ4xS49F2fdoAkZvUIleafWiWxIwN7jQ/Flu
UbaIcaEgCcESnT140n5QLJtCH3qZiXN7rM874+ds9U0S/KuE+HpE0nOHKdHbQVtJSTTqDhdwQ47C
Tgzfx2L5EpkCWRddkh9Bnw4glz+vcxrps+yvt5EktnPfts6gl24zMOxGOlkt5Cdv6p/S6tP+td/X
Qj74EZiSRU3DIWCUhcYA1prpCo5Oln8Za8SE+IIGVLTe6uX6P/LTxXcWmKODa0i2x3iFNfZOYedM
NJC2ILBiprCVKiwrZZXMz1meJGM/v17vk4eMUSCJ/dC/cdQ7C11LSuhU/sfjT6cXIocROo0Pj0hQ
ze3kXJuJJ4C7CD8uMjme16yN19qm0u84cdr/oDRcWRXVWF8lghA07ocGFwgxynz+QqP4ErkaeFe8
yvgFGkBQIlu2KDOtVkE0P67H1cLrZE7m6dXUybtB88m7m/+ZhhvPC30+sNC2sMk8a/r5EgzE+rmv
QWPiU5yGhA6JIlFRdoj8CHYZonOTLXRiVa/UdA++Yr8VQG9huqGJWsb014riWdOzLqQO+gfvSFIu
NbyOSi4sElSc5o3qiI/3ocmdLFZVKs8GpDCLlAqR5UIsCBAaSSM7bUvC9do6w68oxrT9kwa715mo
jTOqEwKV01FgBi8xzjoloPNZakxKtPsrOmSnfv1kf+eOWpWIURx+abCCVh9zjXkuDU5eAeRCpyZG
N49gi0K+gWAxkZxwcLa2biIAhtkOIK1tYUZEmrW8pmt1zQ/+eRxlSHE36c831gjM68iOYCumVOax
rmLIGBo7ksht6X/3PawEvMhpGJ52eIoP91kFvzg8R8c+ySckBptj8jHL6a+IYdibn7Qt0D7ZcAxY
HPN/uUKIom2B2STDQetKDOX6O9PsG1punUwGLbNvqe/b2VClQ7NbtXLc/Ae96F0L9nJwMnWuwLHR
TrsdV9ugWxPWyLDXQBrqvZzxEij0384go4LQqInAsk8tIteA4uXpS4wk/7BPO0cF0OZHnWw+1gO3
PvR0NMSnbZB/9MInn7Ou7Oc1jsxdoWvSqpcri/2+D485urxHGLAnCRX10Pr2xn5EugpIYfcdFi/Q
VpI3+tfzBAeV4sTS3T/Je090fbzbRrodob7o+HJ1phzvVG5d/Y4QWU1TxL4NssVG23uzlI4wiuBw
tm+oEy3v6h3oFj7YVvJsIEZ5yT7YWSOx+CHF8Ve+CplxJmHgkG9Zo8NjHrC9jkkULMy6bLv41Ojb
dn+m0dkwzAtVKqvmgVGNNP07Odyt/lTluhnHhNGFFG2Zi5bGw6OV1UC5KasnSSJASdOHiYR0zaW4
NwVwclht3D08j2TFlyZQkTyAz+9IlQhpcjeh52gdRju8GtNzIYr7u1XGsiqu7F1yN279RNRg0C6m
EANLcKLG+5wGrewxrG2h8yOqBm==