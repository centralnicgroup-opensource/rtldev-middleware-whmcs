<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvDDwSTmaD7e3VvyvCdvRu90cB4ALZSL2ecuVuHEhLvo0sPT6hnVu/hTYOS6w9foLsrBQ8+v
5vhBNb0HWusLB+BJ/cC3RooeWn/WdJjKdLpHrvt1aHk1KFpahRF0l0RxzedZD5t1zQjhP6z0Zyat
ELS6gdrqLbGb5qE7Brh8p9XeZzJUrE08hcQG/OD61vUEkFHC8YvaGFhKbPj+OAc9U/hGx1OCM69k
3T4ixy5zbvgKSCVZai8v8TFBIup3Q9eFsWbtxIqRXP/lhvZxOR6zLnCA7aziPCfruR9aPW5kD4W1
oIOY4XLuX8+jasP9uAU0N6F7c7AGn88QM+pj2HEDiVD2pkwZJtvq7dT14uwZzpT+HyhVY6/Ozwex
TijbhfGwrY+fLmsEi7yHDto6wRDIa9xFHcif1DRXqdZk6L5X90F/aLxLm0TR6funSXJR+fP4p9/P
Drjo1XoXGo03px/Ook8GSJasXA0pL3yd0ChluPLYQIuKgD60tbhHh7+nRAOkPhojL8L/BpFCSAL3
XPuIqB4wKXoduhDXhZiZURjEhSRyCS4FgXD0E/qcoPfh4/VP3MKCwjWBfWNg/3syAhrpvH3ZydzO
YnjrZczEp0Cuy/62BnV5TVqrQNuj2ROo/hCkYnNzZxOfdLCRoCIrCVHdPAaO0KoakOkLts6n9JIt
KnOhEMb7ayK9BWVFiK4JXlvSvFncgEjOeMFQ3JF9EbVeLTfZEERc8trRR+kMz2x+PX3Xy6+Fa129
tKaaiXtW0RI5dJvUL4+ijuHK9z0rFIOrCTw7rpxhmiC2VArKy47oYTWvZyUafChpVDIKVUK2UHPw
DLSsbrWJeVi38Iv462v24c+jgYShBjAcr4JdzhrRclTzPoIhTXqIb8+KV5DF1CHTdWiC4x+p+MDA
IE0jvJ0dO2bp59aWofR4GT00gSyFT8P0ut1YDHWAJRpnU2WBVuZdK70UdKg0Z0rZttdOSlNHUkRX
3z/E/hyr26q6oNJi7rrf42PBN8sdS7FtHoSDbYr84R2bIq69GBvKfMlcJoRY0I8s7zTDnDaef93y
2KWJ+aQdebPv7pT86leS1PSFLDOSK6QGfdlMaMXEJDR+SiCi98qSyjnCTO4ZeG1Dc3+8rYOln2u9
bZWBl0BiHPehobEnh09lk7k9NLsFMtum5K6ysvLN4CqqO6dgu/BBYbs0M1KaDvUyxHlnAE1nZ+nj
de+RXlEA7UFBJVRycI3b9Ffj2l6QDczRGQuW1gNGi8rZJUfssfrDyqXu8y7NRgXZ9xLNrCpet1H/
ugzlR2jreyZZp6lmd/jxdzDvFv4kZrKhc/HwuxeoqZB+CSREE9ftne6LuI6FGBMP7XrbrvbCqbOo
jkOrUoJgWnqCEpEz+4VyZOD7xvw51+kKsIJqlgCDRR5e95kuVaTcF+q7dLnxVtv4AgAaMjOF4WXt
ONMNNz4PijQiyqgpVvOvRbS9D+jDTtCpR7HpfwtIrxl/FYNhC9VrkefJBWuIx4C4M/Omu/ZIrHeA
oOlyVqsUScDSKnmhOU0Zs28L7vVbCRPK6+ufRL6fqOHAl2dPIwnFzBLgZkTyHo7aP8GuCjq5vAco
/DM53RjxpjVDbf3Ez0ROSuKax6iO/IP58snbmFQRi/2FmGAq32N2XQim4ILNn7USNsWEQAUJLJyg
+Rs2a90l5NDgACK473tLls/k9U6zxK2wNk6U77N/aFwo5ASG7tT/5K4BlTZYvUJUImwVp1jTBc7t
7LIVJdt3RAUIL20tl9L3igXoVay7KGOMdLwzb/x4m2VAwW2V4QrxPtgiLMjakkyAY8f0fWRphoLv
8lRl93AeqZIafeJDHzs5kJKsoTEIDBGt0/JiO4roPoB+MnjtIPLfya+k/nIOLnBkkXLCUPaICb5V
MzCQXpKtousLYFCzKqxvA9s5Cu7U88vvfZ7tYmoFpXuSEK4JxEsuB2Sg5Cyn6N6qet1j/NRDaAza
p8cIrZhKHtt2isHhgjRmMHFlJlqHNxgtJgaxt3GkfYzKWU00QIY9uJbuIcRXJUtB8sIuMyAcH8Wv
RHIbVOQqKyxPMdWxMIahCpwczk+vmutWS26c7BRMZR/n2uc36fOsTjF1MPH8KZrybzL73UtOFTAk
/RgG5bizILiZbgfTdHrSa2G6SCpXU2GtUy9WjLw7H5ppNn7G7NcOAU/EHLKb/zlC4atKW1MI7RwQ
u5U9LDMvD16nSBb8klRY