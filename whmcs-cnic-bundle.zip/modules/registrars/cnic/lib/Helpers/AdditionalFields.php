<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqYA8I/OLPe0fJcq3Dy8NZrh0jV0MAXOjxMubcI1bFA6pjzB3IxvEU7fNbW95unURXbnXRjn
6AwiR3hi0IP6CH1HpvzPMaHuCRj5GALxNsxZ0+2TeNGF7FJ9LOBWOWsfN7Q6gWE2pHOZL7V3Q4i3
TJARA2mA1KpNy/kJ+U1Sn7HDUNefN8a6VoAzbdh7unv2bOflGi2wWbfv8K4DrGFX6VWfJxrxuNry
GCkz/E4bz0WV4fSVsO2xROCcr86EJY4UUnarDt5f5wdvA8aDlh2A6HoKbCXUcoVfxoUcQOLUAP32
SSXM/wNkebUQIRMy2BvcfSYwpjo2q6Fp5iM4htzpAUhUG6aIHl0WirySEwinKxaPKKrUDAsFs4/8
hEtFutfSD0ICeEzcop6b3YqSCIgMGCNi+LwDP/cCPmspEUWF/+RD0Dc9anZigDsmDdu/NZeEI7IE
C7BeBNx+5dPos5DsiSvPAldQSIuo1YyQOAdAiXZfulsw+TyA9B4nWkYWUiCczuPmO2HWqRd4Z4pn
hUD2riGNnyAPJyl8XrO59SQj7aCdYItW67eFtKzXeAa1UR2l2i7R31JIjk/smRLvyo8OKH97YTr7
Pe6YPBxqB9cwP5kAOM2TXjrYklSH+DNKQ4SOxSI0mWje6E59fMm1ihU8UFK5+J4/fPvb7I57xtu5
jnE1ZexnMrhtQkoRf8q2RFX4bS1T+cHIOuctHKoLk9b2ntmqkkqEtDyEulFtckCKRdSF1nEHQl+P
s4a9FIK5miJ5KY34rxKVSUaJq50X3bEBcmnde6+LNAK6WSs+1LQWiuK9tVNVLq2Vi3KL0L9PZZ8X
+czaa9Ien3hZMpc+QKMxuxKc2wgucKXkrRrL8Yb1/WXXnJysbazTnbwTilClwKiaW8tjgidINBH1
eieAHXsD1oH2iPDS/gmwUOoZ6ox4WnsClvmXyplFsz6uvVqLqiSJ5BKZA39B191UBjYBKvzCN5A3
Tf2u1A8L3rFaALQQGjSxnp3vj+QSvcHdM4Q/wP4l8hxfsGzK53rt1tr9qrx0EpXqhojzJbjccwNW
i1KnXo/Ss+7QY58CWcK+5/wi9LrnLD2Oa6I/6p0aRuE11QsYCV1KU8as4gZ9j0BIW0DCLbxccwOD
ZSYRvk7gXWm/67W66vlalx26Rjy40GZRwb3MG2+SC9UMYlsY7KsWFTq5ALU95Ic1Gv+NzAjQO08u
6LbCCTsdUiOLFb8Gdo3XdmsNA0UYer/x5gO6ZCMeWxeN9uhmDusfpKgBo8b5jymeKNzAKMekWrlO
4MPte0yAKg86BPmcotNXnG26jjEyg+BadEpDOip76B/owJMEc6CcMsCMp0Htsuv1zuvHSK7q8mi3
T1/z3sQRB/Q2r+3JnfqX/dTZtb+8XTfeWnx9qk7m/GOTCInBK4jpu2mt6riCANLjkOZ51gFmge23
+jYd56IEH/U+7xaLcjIOV07lyv6aCh0rKNSFVtZvvVXJJm8CQ2tnaVyif+8Jmd00J6/gxIPR8Kgg
z18OtvznLSqV/BoQIiR1fM6BI52wtfuIPCOrlzJCwnVnVAuYOiYqZe8Y1+dHGakcoI5wBqI920Ai
d0t/wd2Yw8TKcJxvQBKPhF65svOSIp8MdFFgJBLIY48ToP0Xy1/LWtYHDaF9TIsojbo5mYTvdEhC
45R59Qybit+75tKGhDiOhKUeAsUL9hCTNam38i4O8nk5d+ibXPWPiD4mgCbZWBNatX8GjSDPk5Lr
VhNC/M9xG2X5dB3UjpsPnz4iNP+F7SpF8SVb5fE/Vi1zXwQoOSbvYCH4Dmy80/CZkX4IVE0VuoV+
ryGL/CzO1LwU04aOTKiDWfEcIG0qzhPwQ9cvcFpVxfD31GBLcRb8WXQFWwNvDP+E/teV/dd1Bxj7
l0GWqwPu2/bBaSpxlCLNXsjWLhiM2AVGMhKWRIX2UBw82S4mQwzKKtL99zR0Bu4zgY0rzUKbFNH8
ma4Cr2D6MswV8I0pZeLdVw3z8VsD0QKiId9xnWuW86cIdv05wsLnTwEqQKpgYQA3OKIW10qCUcEm
QwbDMYjmGMOBaP6T7+S6ekBDLCMJeaCO2PJ1HSMHYDw3ZWRWrDzOGWUaH20/AWjCfiXbSTi323TY
PRb1/85/6Ywt011WYK1vYSbxP8HzRke1+SRzEzLIrUWUtQDL+CQlBbgtaPwB54ctaWRNxw2ce+Mp
xf4=