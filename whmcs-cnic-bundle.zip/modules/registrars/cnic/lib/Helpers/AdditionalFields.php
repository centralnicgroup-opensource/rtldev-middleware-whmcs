<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrMVJfchPhFUiYpRkjtXu0Dx6YgdcN0qylr59Wg/Hftk63yoC2hMFcgupoZQ4+EFbTHMVpgJ
KX0J7l5XgWVcJRPvJwUqrT8UcMedm3ZTfAsQLS7xNbLc/Filzah6Jn0fqIyIQ2zzKypCXT8qQItP
s++R3gVAuyBiBXSwYCH28BmQOdstzAb3pbAjd0YA24RQtTaz1I3uwMUfMhO+hfmYhh2mwf4WCogK
ZJuaSV0n7D6ynh9lEGm1VbrfqmAkCQ3x1UNES9VFDzOdJqGe9uqLj944fQudcUTeii9ichgJuhiW
CcVHSgXF0KsFLdyX0LR0bZf/9y08JgatUuMQk1VjHTMckRejCPnl0AAxro5Qdre+1l9BA+pOwfxG
28kYZq2+jaLvwpkbwrBTwCQHSZXOOX/iw8f3f89T0MHAloEvDw9Wu9wD4aydMt2XOP6EX8QCVYtN
XAsAVenP+oqmGCklmyB2eDYfbV77Uq8nJAnlvlY06EWbCDNrwNg5KqyoCE75XzNWdAgBWUM/iAL1
dM8+5z0FUwQlkVKZ3F3FcGSPxVVRu2fC+dlPY0yhI6yOmBryukhQ6bysuxkSn6IZ6wbRaEX1Pitc
pD0qyD1Yv4v3h5TjhS+UAcEvjwok1XxEeIECuEsk2NTHWsR2BJblMk6LZnLO8G2FhQLDrACgQL90
PyGllHHb0ZXAc8NqZYZC3yurGLjd1gsU/5DdcV+ezfmo3SsUzV3/DiSlYCHCoi8TLtLh/+pUzUfZ
EzhZj2SGQYOdwXtzFyA7TDLjyKU/n03tbwbX1Ml3u5/zCKW3hDEZorkNzrrfFGVaG18jGl/RiKQz
MvHyThNBTzOJnCutpevxyBAR2pU0M7jlLAzCk5KXUBfvXmOlXkyU/Mw44adY8wirkH11u7AHJFbm
b2l7rFLuoki5Fo2017TW14X4o5tfbwKHpBFsBKiXMMKbMMlJXFMwdxRGIHSQCeyhkxCZ1pVL9tKC
Ef1Ff27W/N8EvxdQCKG2aA66QfzHJklz8dUB8NgqY2KdI9TeAlPtCLWPLHARvo0jnyU9dJl0Dc6G
a9sIfYnm4V3FOZ9XFJVkZ80OhweBJMOtPfLDECsg3QQpTh1YtqVTPxxkoaIDxpDSSm6zXvQrlz4z
8yfcawpHA3Mt7/Ti6F3E+NnLGub1KawGwfR4Ms6YlFh0PvHYoap5YLrnh8VxTq5GUUBncEI92/rc
JXYYX+u9WJKRy5pQUEjcSI2bBekvo0GFNTbpac67GpYjbnbfxFJCU1zTLUMfL+FSdLCoTxO8Iuzh
bjtGdAi9KK0XZaQEvgbt0X5gizL84PEUlb/Z3wP6ZZfq4x7ck9UQljeq6HBP+OIIW8RE8RTB/mus
pIUjJMrnB5WCQgNLZolNEBla+LONBLgDY9WdTJwBAGt2O5hdtW46R8+u0sZRkH4tU3NRryPouDhI
lFy+y1VNk4FUg97mWSXeb1zFZrOmbIUnlXPLFqYnnsjgM8C0GWiY9Yq/7OmrHKJBPYFYlnzkPlys
jTIVV2pRzIL0GAAgeSAQ7NCL7gqWad9UGF4OiuK1lVfXd4ksrjOAicTFT8LvAvhgRX5tcyIu5RrZ
q8sutYLlL3hjpPZmAfAg8OWqkYpxlR9NVhTwAcmJGXO3BXGimUYF88+6scJqFKmp4i6Sogzv0QOv
mYZWu+OvY0AX6Eca6jDavIQ0kV6DTIqqEtt/9czTtgM0zQtTJUkdfYxMYBnA+yejJNatBAxuovUX
78l1lky4aF8o0q5CGBCcw16HPjAkfLFLCr8scJv/AlrCw8CSkaBWIK59G1zxU/QPm/+OCstHP0qe
aN9sAXiqDdaYKk+1STi56HTXG9wBgK6cj6DVKb3t1iWw5GOSO7c4D/HqPqNmPoFpEhAiXsD+rbgl
Rkv1bVm75x4fYI4EeNswkN72pPP5y7mXv2/MX9lMJ15gbUmrAlAJnFLvhi8mM9SI/KiDMs5hS3XS
HeZUI20Wa/+twNW4ki5K1jPx41VaquO0GAATZFqfLcJlqAbJYcankc7G2zxF5pHDTBFnOPzq5mhH
+WNG1+7/fj7EbnPDRMfqk26K3kjuLktBjTmlROJwozKHE/9JNGEVaRUN1IZQDq0FgE1ZfvCrz121
T3OEKybIfiCBE7nMZwHvHosVGgyr5RvehHd6WLmNcuVDman/7DcjTWDT2/vhV6uTg6EIdSaVHLdd
RVlK8lZdvvADlWC2VscxoCHvrG==