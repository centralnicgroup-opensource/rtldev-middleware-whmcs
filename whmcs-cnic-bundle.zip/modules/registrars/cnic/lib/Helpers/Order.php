<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwRdK0oqPQaZGIZ5BsXpquStlLizbioFnloTZMYp9hxAdP4fSfaKHm1LyWneTunkUzr9/uFd
K8bst+IDGKgYCq6f/Ey88LCqK2rLG6avzJQQ0BMprO4N+S2Zlj57K6zM+skl9/PtntYElNk3KYG4
uBA1caXzuOpA7CLr9d71mv1xFxLxKZC3pLmijuaWBAaJxefceKwB8RF50E3c9v24XofJoR/DsOcm
sSv5dqXBI6j7AU1pWr5S7uKQNqULdphwTRNruGM+N5EDoKg9JE/Ip5cP3c7LQ9bIFfDsvYo21KlP
XtYdQHb3W+KIuBxYgLNfMFH8rPEq3fYYxRDCEC2SYPXs9lFaDtICPF34zPiVv/PCZFtG6X9fdmQN
Rmibu+atkxhCIpU3HZUxbkWL5vZE/wYpNy1YnM4ZkZvd4LlHNKppv+nnbVPDfeEK+4DVWi/imb6z
z9TOQSdwIB4ts+FaydxjUgHQufd0q9+GUhv2y13VxE/+AU6p81tsUWK64TJdlDSRDREr3AUyVS6D
FnPeEwHUH5Kbd4Nm9e9t3diRQFjvtrMy3izZhBCUXtuKGPyBwtiKrXAWb7dwc5go+2S9mTUMn1Jn
xRW3fh4fmKvC3WxgAx6HmQCcn6XVnHWcR2nClJHkfokY2r52/u1Wg75VFofeLhuWgP07+PAwTwdS
SqA/2ZhHVIi9dpdMFhgtGc5k046/wS/B0e87w6b9CeQ9lHJFixvE9XxNqAYa39+o+v/nOx+887qC
hbL/+uUh996nMqrlrS+NLkYntS4E5uyuunsA4FjENE2R07npNgwwQ85AB1bbd3VCJDSxujy7jUTI
YJdMeBBm5EGqhXaIkk/RmdCDJXgC/FcFTeOVqJtBYldmJSLOQHBmKgLzvziKQeivSPk/s3Chn3Zf
b+IObEXNUV0oXSms5NmtD4+Gc/5FiW47lkQKNHgKq9NaiBI8YTupLZSN1VEDMmQOec9vSOANq78H
XU451g+amdH18acbDAp42Lx/6wi5qj0SKQr+RuO8cHemUDDQjGpFmG970jxZFWSAL8paPjKMbE74
vZ2HcMsAxtPN7EXWSVpvh3yMYnkPVZBXH2W1YD+fjOtYlzBrSG9Vj4XOe/2UaB89ywbooj5hagR2
8Bb27oFY1QgmHqMdz8ddtSgmwV5ZXXaY4B5mDyhguWOd4MhMcOKiWVFRaQlh+OCmPoClVPcG3YfS
Vi9kbFjNmCML7hEmQJsKK9HyY4qqaW8H2QuirK9agoQVPyAdNpD0BfOnpWyXydjpIT/gKlP85NMr
Pra61/fAycDrJ8umpAHxPxrQPSAVCckZ0zCZtwIrwZxsLJEpHxKJ70CVyLO3CaLgeQ0lnxeQMk5a
Evp+G2IBraJyGNqKk5NmR9aVV8wpE9oMyQanVIo+Ak9dpwTrUgxcBulbzrZbzpALAqb0XnBhq4HA
672Iv66vmiis8xDnK7isuqlXGFHn7khHC+0cGNwWTwmCFl7bMfpNgY0aBx7KD4iHKCH8qLvF4vXz
JQOS+5+VrEL7N5zt0eEjNG9wvRG3TmkOnDTaB13dPVi6zkX1KGifQh6U1FwXoTJ0mRnIArb9TyRJ
C/xiILaA3mp4eZfTM2QNh13hLe5PrPhw0lMum84BegyR5F8xx0jBD+Lf60coi8bsdY55YeUs1opQ
afFrL4uCsSsV1wL1YUnZ0HIm+cbr/ti1FWb3RhssqgNIJPVBiuhAd/gmf3g07mvTwbAYnGb+Kf3M
LJzhUo0AOt7Lro3DNPni4WBXjby4qnIBpejfV+QB+la4V1RyKpW46i0xrowTO29NEqpcc1nEVHh/
Rt6qwEWZkfDa4MSbh53xM3YPnGUUfrM+77oTzxf/q8QWzrQ8k20ZGtzGk9YBc55yXGfdBGUwTprK
TfU9zhC8OpB/inBYHng8vB1lpJ9H+U1dTs3sGlzK7ObQ9wKch/yHWYivZInC5dShsOly5A0MiiRP
Z9oJXTpeimDSSV501DN4g/YFJqkBgXRCeV+2kVYvLgW3fBGweRweClMDnKEgY3/iYXa55TDlDEEP
XGo/XVWnff1gMKJte5edeIMBN9x3FyROQYc4OZX437/VvPCsc3FsxNR0xhSkoBQxKdBWojpIA+HB
MXTy3mn69TBoSCTNCKz+Df7x1HDApDaOLG19w//yG1eX49dDj0SHvc9fNRookEEUnAylgImoXYH9
TkvnSH0F5OOOaru2W0krt5gH7PbtOwkyxx7M92aJ8Q/Rw9Z0cCGlrItzX4Q/fgaxaqcp/rpM/ObN
KTMupDVvZ/jFWWQQlOE4g8AOuf+x72QC5cyvJdQkfMVEfZlyJws5ls529hBOmMp/pNjIZOOuz5Ba
LuZ1+WxIaPSi+2atE8e25UWucR90Wl6rlP2hVJO6SpMTP8goTOS0Y5hVwhISrBW9VCQMoekJm518
+gNgqeWZI6X4hE42sviLLLZuUR+/W3tGY4QT+09EzuRG9fOaT/2sdbyI94FxVZ4DkzJI3yRbnHy0
8PhDK6WC+tQbcr9IpLPHIhdd1dveiRlALOmx6UpAlV9OC+RAxzbuenWRCCnheXlKSLKNWiic5FKv
9OxbpHV4afwa6KfytCW/1phjXcfVHPBashc7l/PDXUGmqG0ZuND68y5PiXdTOY8VTIxuaQzF4h1j
sJCnZ3GEaHqhNXapp4xx6MbvW2VJ9acMeyXhoeSK9iYVQ9zNUnxB4fOcBrHNuuB32RuuEHtuHJyv
lQ3XCoNFSIN4NUf3TTPRj+xF3nJAaMmNWEOSA+RH1RHmjOKP/gFyCJGIG8eIrhlkMtiJM2eMJRx6
MIsLN2cK681GnpTOYKgEal2GsPCH1wdMT6ABuf+h4UUqEwx/RhthJffYKvIK/uVayYVQeSrZdrO9
b4ASm6ClTZ+9z3AzY+QnoOFNAeaZJWTSu7RYSnqY3oQXR1vOlzVEo1lUfHpYUPpbsvCktsB+2Z/+
VoSfCaiue73CG47q85GCmHYNh3xEimBrPHto/XEyKgPMopPEYithMAtEvYl3QEtms3I04I/qblgx
2qj8po2FwUAsxCZ8AS4WP+3pO9V1QqijjJf4V+AAbP4wuV1CJvDOQoeT4KOWIpeaFPPwyEhrUdD0
fZjvXxM52+qPhQEZu3OewNrXiEc6xGHaN9kgQ+nSoe85oN7yoO9xRf5AD1NfteoM0FU2jp9s9E/+
itg9I1QOoIftoxFaT6qJWGk1RoiscZPtO5t5C1LKpAbRJsEccx+n9KuOxx2yPrpKs5BcyxhVpjyM
5jAiob+jpxV5/uJiJL8/4uEyZBWmwR8bofjHFSgSdoJPAmhLw/qixV5uztpDVPurHhKEra//Q54D
fkiMalDNWyLMZDsiI9L6dyPQmP1as26mehhCCBsh5LtduOT1fZuVZVyN9iNH7T0jinOcx5Ap0ddZ
5f192mgsazdizQwT31x/EnWS3c7+J48QELcflun31U9pivB6PUuuMh7oIGPLkP36ldUCt396NqmF
6l3IS91daHdl8lWxm6GqtVWTYnXAfUhybG1b+8ZCXNE+V2CgL0+sqj2Mjx+YP6o2SBicxvEUbTS0
Ugv0q8uG