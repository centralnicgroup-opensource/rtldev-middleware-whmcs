<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+YPJpzsIBGm3rRQ7C1nCeW8DSGWqqTIryoDg2akNxhtbUzF4rjA35m29S7XUFltIH40K+Jy
djUqJLAXDOz9TbUMNoKjTbRxwRwAsbbYcT60vhoOJvoJ0S33MRoWJ1M1q6x/8OsqleU7yTwsFk4O
XjmBRKyJJLLLII3bjo7lTrJKrFlhEUoIEFtmlucQE4bGv5jefyQmQVvXkybpasVm/UdZUPGvnSiM
foeYl1dCmGQFkmKO8lulpkii/70ua9PqQsF8Imo6K66hKrE272ZodhOOIbr8QtZ+sN6pt3c+RMdO
5lD710pSMfauZltWZV6RvU64aa/oFY+HTSFsRtBE8MbeBIH1vtcZMeQaFkBo+KP/MdLosYG7rNZ/
KYCTHRX+ibMeTdifnAOiBdFdWfuowzBmIdjIK670uXfIa8XnbxS+8Wa70M1zP/qTfsLYt0y3C3Hv
cPNqaOTelBTCPfcKHAzBsy60/rEQjsn4UD59eWFChT/D8YGLr2UazYg2cRF9RiymNcHv6ZaedGRj
AtBuZfp6Dc7dTh4TyRBzYBet5y69PmR0Xq+/xDgqJeOpByq1IFEFx4wbhqn/QhUUb1SV7rHGsrTO
yjzqKwCxWs5VC6B5LoJENX50LAhhZ4SNfTLnrGJbPkLk7B5DsnjKgziI/XlvVdWSTP0FnrinvXpu
HPpoUz2PMXcOPDaYYE4kk4nZiZNEmh2gqaGBbXAzWeZaCiqGBcvKpye8MJ2QBHRVdYa6o2O6sLhh
dtEDN7z95gjTgLaBWuPtdphyTczN/SsRIPsaO/QZaTllwp5Tj90qIGcGdcgvuD5cv3i9ajmPZbSH
IidNcku/WmxcKSOR5eaN/oCDvHBgUsjL+U8l1ETysg/kcLu5FPxNVVQgPL+IhQDVejgYjJwoSDWO
w8QylhI3djcd4fyG03ij+suqfTfDffwvwrTLe8s43YCv+XXsvoGNxF026jYYuNd4QgbPowNxbcR0
K8qVmU3JkyRt9KeRJk99YJB4eQ+Dgwxp/MhNIbxYsn1vjZ5tgzYyYbLmOFqWhM9hy5WmwIfedULM
vSRe4bhUP4QU6MkRvNwWhlPXoJsPyf+VrTmNc1bVxai2oiztANsGysfTXKIdWMdwByaqqkIQcpGg
um06SFN1Rjmxf/ZaELMFISYvwZ+p5rRagf1L9OAD3RZsg3Cwvlz0xcF6AEcG2FkWpiNb9q38KLDJ
91pZ33540ntRaWPDXsiDS802OEYooK4i88dWSJzZSD4is83If7oh1ZVvSa1Xzs8hM1LWDKW1CC+G
TCcUZ1FhPK+NQycOsuYEb4JyUHROHQk8/cIDIZYoVTMKjrTGgUEr0u7orr29D09S6PIo5glcO59G
GBDq+QJfb3V5LlXePupAITJidjfklhHiPkL+3ocmtJ1MtxWpnhw7QxlO4+LswQvCE2bLJkCtI2Dl
wcq/WXjU+OSeEHZG45z+IsqIjw3IMgUHqRYe3xaa/lnHTEVkmtfEfMLaxdTqvSelQjA9WDNMRpAW
4Z1oauyUOK33dRQnKMyD0XAg8+mSysV+lTbV+cNNereByZ1cpc2H11lMW9ZTRKt9FgjW4m6MDcHG
oi99fUYxHDFyj+lJz0xLw7dlq/i1eNFHWdnPU1RJc0l7A8HE/sabvIM/9jT9k2E/g/e2p3iap+O0
pjLdvKMGVvT/7zerk35lnwQn6IGsgDfBvBbcaYKXhJK8xH2Fq7+pKnNzqT6oCfnO/h0pOVTdzbjG
reSPISXQD7EFz5UC1M4cDHd0Mm91eZ5S5fuBNtseZYtOFuQlcxH3GeLjXLm3LzWXDgm/RaLNvImc
wwy8U+0gsalh6GSp8pH3RiWQ+R5hbveYkzXQRZxS3oomhm8GOvECVBOmv5xmyyx2xWR/teaYPTwO
GV5X5sM9yWgvnj6EC6yqHuvlkqTnvwzpaY27Ypf1KCg3Ncu2jPNJ8xcyPga8xAPJHEqYJsOQgQXK
KcMWeFQOvH/AbJqP80UfgGxmm8jo4Sq1Sejj6mexLG9xw4UaWSuHcxzr3+/QMHHxjt3c3ZfzkePW
4HWGXReITsbKlXMU5wRpxI028fXMR+wOHnXYo843ZgkL5ZVU2Txu0dMsDp9KbnVvaQ4wT3IODDLH
ch+1EEIuCZUsTLPS8Xb2dXG01BL5lbb28xl0YtaqL3yJq7Zlqa9Ox18vBkQDtKJt81fnTXFeU/fj
hMQpydKFTc3rjPT3y5asRoXgneCY5eKtjpbxgEVo9MyUKk5YI345xXE+bA6lzW0sLPESmkV0SAlQ
MuIHhw7INSozW8NTyicLSCcHj259x6dBk2JLXi0fHRm+2KzVz+pMXLBAcmbaAFxdmXMb/fHVAnCX
E4GkTM2wVWZxFRDpRHtuUKverXoAHulydS9KvQMoGnAnK//xaj5C4x+Ipo1ClWKSvnFTH+7GZgn+
rC1dep19D0PGsS6onSGp+qRLs/Babssv+W2g20YdcOqFK7Yxn8WG08BoDAqj0+FpwkxgY190Yern
BeKqzk2SZ7X2UhR6oJIE5BXrfy3De2HUsAPxaoib0Nx0h6ePL0c/BuiB5f3kgpU73hwdoYOfRc54
CbtJ9QpYJl08XAKLHaxnfw93qleZp9qGZ4Ld9o0kG39x7hndIvRsNwH2p4HOs7BQWwc4BaI7Z9Q2
ZZcFfoN/JnRDjSg8PtWZ3nK+ILvz2EhKLJ6kwjF89B5grc0gOS/qq8cmQ8lAxCppEhYK51z5n+2E
gJPcMOywFnzI0L1JifbdR9zgUR/PPGefIemaPrS7YfSROtOZGyzJ5D0sk5HhVvJ5QTSYVkN/6EHp
xfjEfM035bl3rc97Vfgr9x+lB/SpZEcqDU4TojyKHK7KleL4j/rZq2fGxKJU5YhQZe52NsCRnGiw
vbUBiJSmZtKfmQIFYP5Myzu93TrtGA6TztpTWSCbsPGWOr1G3Lg32NqeNC+pplUy+P8pAUwiXMcE
Z+G0NZSh8KLIRprvE88Om17+8kqIKsgcRNQRoSIscs0LdADnzx0macc4zeZwqhck8+FtIftO5SvU
JgEHLtrZnKrx7h8DQcL6c7k2Qqgk/kH9cgGCnjnYytF47qS8bX3/wt1pH9VoAc0oinwGsWgzgIIe
iT+Z8DAKw1YM1HVfMuII2/YMKoMRfq7aBKKxnKGjRjcfSmkzsQvtwnXofRUwcfP2lYUAE17bWgDq
QGpW8EoofzOjgKV94wdTuVeSzHNwkbd2z53DdHOtC4+inlNT6B/F1OgAd2FmdlvUTG/r703NNdYS
WiQyzbxBAp1TwHLxThie/rxWtdm3jXou1/9uRuqH04/jvikb4ImTJybZsB+IJZREB6qgOvOHJ9Rg
JBenO+rhyxcC/LOeVD4cuYF9sgkfOxnGiHZghKzPov/FBtYa45GZPbuSc48V0gyVXdFVbDm74cpM
fuY/EeZ0IzmHRMZEboXJHS35TwFf1E/SFqbe+1hDybQF368hEZvXpKYayGQ410Uiy+BgOUHyR12Z
YpPz3fo/Rb5+hovBrMxZRtIeGUCGHd/1UCuASNUU6deq+FcddXfQrsVQ2XRQ7tE0SY+tYmVhRrLA
wwKsmoSl