<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/yQpRCpTfm810y29X2fikoxi1TT1BR4n+Apeg+5j45EQv9NHupsfd9J2P4BpPIe3BTDfk7B
iJ9y4Sz615xbvtJhA4f+ZuCX94jm1HpMhC1y6aUlh8yu/rRsvtIPbM9ox95YeUjooG/ecze58WTc
MJh6CKJnJp4/kag+nxx/++cO9vHMzo3jaTxKIz74PCNzo9Olu3Tka1cICn/8aIhd30bIjNm982Rg
dekuIMZiar4tRGXpb+24QOazg+qiVibdteDXppVM9qz4A2UD5RId1AMk9va7QDyeBIQzuA/xNsGd
0NWdElyG+KCkiaGbSNG7AZkZXorYmtbkg4caIbbwT8yegRtc03x5Iim6lxa5dXOXKcvMbzpM+xdM
UO9KtaFJCD/jhSKxgCQpPx4J+0l5RT6Q58OS5S4+CJZ0aq99I5JtNMU2aBGK3NtOpz0FoOt+dUuR
BMb8zwQfdH2nCGSLruIEL+C0R60iJhLNRquiw4TDp1huAhvLN0zOxBAj0TRATdp5cj+x3lFiwQHR
jztV5OkWwPfc/6ma+vzec53/kF7ckkqs+koPkfMBcQ7zGgpXzKsMGV0EYpkg8cHXckkzxEkxUQCt
lDd23pk2IoNB+I2acSRVUJa19MyKGtpperU+13WeBDTBLUxl413vr+hmfxcJ59YwGHtdMaJLwwMB
Ete+3Z9kkgSp5+g6clZjMGipjTLM7eCrRsrynn02zxC7/oQ4UOpwhkjc1gMSPDCL0+6nvQKGuGW6
n75OZ7+BE5wflV3vWKIdT4c1pKGvSL1VhvD4b/4RpOpPe/jlC+3pmf3PXCTxeLZHufm9Q2gUvUk8
ykhGpXFVJGyQXlBGDN6YatciqJ77d4DkddIP6w/KfOoIx4z+9dDvufZDAQG9D1wwih1Dpss4eUft
0qac760+To4YagDAgElKWf1t276lqFuxbFiL8lYw8Xbx/G6DkfBFl4dgyXsoTnnq9ctwdV/4d3Wl
JIcDD9dgGmvuy2CEj3MguBxJbDpvfqJlJnWlaGx8BEezGtwfWoXsDAWYudtsWJHFR5pQNneqfN0N
nNxvWSbe2+3gZqHruc/3fzPcWPCiCSQKk9bUUMGrSZF9lO40YpL5aAm5JGchxwM88CDGzw3WD7Co
nEGKykkRKy3taNOL5r5UZY8sXhvGoWH0xSqGFVokLlhU+v+4ybJCT4sZ7uJtGudUWmXbxNVnSj2y
l93sfsqA0+fa8IajIFotGKEPXHofS3MXmNy64eFucW66sRtlWh2MJIwLDaXOope/WljuiDq2zdHk
KHSb+4dS8tA7KL5UIhxfaJ4pr2TaXno+rFLJ1CLl/uLw2tKFW5hkL4CdmFMUTzE4+BeE7G2qbWK9
JZdzgOqxO8gI792o/8ZtENAyvMirAUUnvz4F8Ui4U+uoXwAA9UaVrPMqtxsUoVTTuyoUb4nwP3df
YpCbhcE38OswLnzG4GWpV4R+wgFMJxi6i+mrswyNd6gXm+fVeKJC9xUAMupwB9T5+QqzGXo6at1G
Q5PfljsSnagvEl2AgBW18n6v3dXHEwb6kk+wfx3WDhpxaBdnoMqx56YQ64bMbwPl3rMTxfoC6w5L
7eWFbIm9grR3kqwRg+MKAY35bF3Ad112p1rtEa7G/4ZcHjgxIRZa3OfP7udZ0gsHI/b3H01G1IwZ
yV3gUxX3BqTxp0vaxJJVhzPOPyojy3qb9yQaTtGKNtaLL5pCWi5vivYBxPJX6h/GOPGZf3rWcQz2
qpMaC2CnIXqJCeKoVPED6+EpLay9UMAXuI8qtLjxIjSkFWXcAA9b4Nfd1nLiLYgi24pnf4iYbwaH
wlKQJXlTbIIOpnPOJCWkZCpgnfPQel2BV8+488uESYAvoRsB/mVTI5ye6VDvG6T+lHD0bdxb+F+i
zvng6rKfxTwRd9FSbLEMNwNIVjRwTg/BkQQe+FO1tM/y3czNNlzaTLJNBvP4BZulNpwFNWlKT2b1
dfcIeERZeH5GN7jWA57flVJGPZhFbmgYPno62jJ7zjTM7m25m+rC6I2Cn8w9IiDRvZtUR5d/0sh7
G099Dt3akKYjM5PkyC/tdUm72yHCDJlsxn8eTYkweqc6VkcBTOjVWAPEtvzpbmCRoJvlPGce1Czm
lkBAlA+ErO3NGF862d2zts3tZE3n7eY2hV/Eus6SuUbo1d4uJyP3XctbDSllfLlG9dtA56GZYWF5
A/he5FqAv74klwOo3Yjl+e+TGYmFgJzS3N+ADyc8yBSSeNBz5TXviE1vvdU/8CY+H9ui/DmHFXPx
7MOUZM4WiUoYwjZn+Bz+EI4shFb2LKfmqfwXjs/7FIC+vkqs6tapxYgf92xVXnVIfNsoYdjh61dN
lAoxbxsx9TPOMLtZw1lT4HqzlqAOXKEEKTavlS5gRxpm2ap3pKP/UJ3gRf5pAK2VpyfCMuGYVff1
oFAZHWEMgSJPqvddsh0C4XObcyxwnRZHfsgaAZth7zxBO5oozm4Tiod3FG98o5HwmWkeM0xi3nl6
A87rE6sOPDarjlTIYl2rXdRPQlX2+84ABFVbadabieR9lPQjnfYYBwmVhNnocylzg7ZAoCKs5MUo
XaGn+vfq9Yk5DDagAQMFH1bAjdmgJTUfY/tqsd8zKd5fnsGjWTmOoyIyHZEthyWkU4hjRGKzxi3e
9Wj1vS88j8yYgDGTTta/aN1D9Lg61LLptIz1kRy1v78MhNPVRDztV1KiY9O9VyhwkN9HrmElrMz0
lW1inpuaVrgku7uSZe+q0h7FUw+iV+irx7felQ1LMBc1rBCrqKXMLb7vE+J/X7n/A5H/hjbOHNir
QaSUojfgmMYCdPiY/zYTFf1QUdh0Q+tB4tLUcujk72C3wwTdU+YdVBiilXYDwvtZNOcCCUZ7xp3f
66d+fgiU+xrRWW+xfgpsbE+ydktECw3A556/BG3O/H1AjIlmTelpb4nharo2fiFtnuVZXoijz42f
s3DnaW1AMpxvNltyzRo5xCVJAQA0WaX0Uk6HxH9uNU1puysKU+I4gHRIrKUjzfRUy/sZiqyusqce
q0Ui1HD51JROhH+U1k2NWHTIeGiaJlnUkZww1PpgJKeDiPUKd/j2XNcRLG6P5ue9L2aSUGgKJlUR
XVv6BtLr/7pCFo3EOIajt0AtotEbXfv7n7IXZw0g09ls0vH+BiTd03/OBiy6HRC7smHoaKQvFw7D
2whCudyk+vSIZ4lGljusmhvMl+wk9nD2BUzA0z6ZB2m68ICKQ24gXdP2XZKANNErX1s9DyOZBE8s
shKlOl3zNSjUgRqOsyEOFIkBWbg4MhvqtBS0vb/PbzNPeP0BtFCO0VslgDujzd58Nsw40PMdNOCM
EerWGqE7v4+mvjAp8ChG3GcOWiOfXKk3ldCg3t2fPuHCS2CQ71blMU9T8Wh7AD+3HJIJmGWSNGxR
v7JVOwtKAQba6MXMSVRY7JJnhUCO1+j1qzfNCjAaLqQHTLXZLMtRol2v5lIAMrIFY9GPs6PogU+5
z7Noo4vWSSpjZa04qIPPKLoH0qGSVxyUMQqJAxaiR1MFbc3ZUb3c07yIEFa+ze4o15fJOcXT3r61
0A+tpsXn