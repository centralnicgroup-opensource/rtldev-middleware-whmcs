<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs+T6gJ/9Kp/Ouk6Ke+7JoZQ5FLarnkKzV6QtlXCFV2Jm1hoZvPCYxOfP9dnAC3BOiwRKTtm
a+BQqkKglUWrKpW/nG1ecxpLOZ7tODQnOOqooB36OBbCmblaM2/B77UINCi7usfZ7VJI725Maovl
mKyRCz9EIqNuZlpDUnIIv+9Rtj6R3O6CGB3DawAF9WQsM/mpdd+W/aZlMQYdeKTbIHZOUKW8zizx
r1JTzBMcs4MpenltB8aTAXetkNfass+COPhiwJTnQHUf+IY93RwmYXaSb9HsRv9IM1OQausgOnfG
ii8cQFzmOnlruEO5AZyNYzB5pRxma+vjFxJMHd1H7DkvVXOe3v/8AXQKpRliPuBh7IclczrxWfmv
vcNqkZxpDIBLDbaQDy9xQdcCxastG/3fOH0rxNESMcIJxYFMkiUszYwJrlND0RynidlZ8r2zq9y/
+/hWxp0hqazMhiQDxLaplpxjalmep+BpL0NuyjjdGwr+FJGLQEfauF+6Yo0rw5h6IAMWED1V8dli
Nx3TXh4NAzvWjYg0qCZXxWkeGNOaZAplGof8/370xSiJBDBIs/8lbeJ+lWC84uvT1MGC4exCXVei
t+PnTt2td6BYL5pW3yxAjtJUuz90K3h36U9Y9o0Y4w93/z/WACOgoV69GalBGRbSkCnJ/dWTa1Pi
7SgoqGCMADs3eE2RFUTAhNNTvBvTi21WyoQqMl51uhLsKirdizNxoSPMD8vt0m7iLctR8GzoXthY
p10FhYmGnmKtaJCgUClr91hNrIUuRTNA+ON/sGMKrYJ3Sr6SaU5NPD7qr30j4z+aJ8UwHDhm2yPm
X7P5reTEEA3EsTAeeASxXhnoIr3SB+XInLEe7BHcaGTXLoSpgO8Li0xEbWzwlgXvYBT2DXOoPtKA
vmJvZvP0pWJTJGQQLCcYAzs1bAjZldZE+KuDTrlk0smwbdQbJS57ayeKxn9bvU2nxj/LHblSQ53E
s0ebIt5rCDZoIMyAroU/wosryp+btSGaGqKSRZYOyoNARCq7j0Y+27/a7L52Ct9rcO++ZGatWBMg
nCssjKyTnC2HI6eUVYtvK3yAwyGKo8APMpSeyy3IbDJ03ZJ28APuLxn5KCKIICMLpZIiYqVOz2TI
Kdb83AgG0w2TaUXQYPJ5CXorJ+xEUNvN71ACum8ShV3Gt0u4xLAOJHN9yxuvs5XGZa3Lba+Caewn
G4+24zbiOjnCiKcQkieag0mxILbi9q6yJhMBOUfY/6slAr/3NhWSglqKHRPoScbQk1OrPza5KxHF
pu7yER0agKBV8e9tkbnLMuId+JSbI0dXW7EyfFx845fBPBIESZRDRENIe4Mar3cQ4YRR7V+BCE/e
K5VzxxYzZPWIX+EW3TdjzvryLsAynHAQ27TeP4YcmMGwkcUIcs8MzNrQe7I+GVUqeC7/Bxou7SFC
oxz2pOAdHOW2998OyRIT4I/pSyBjxhSxUPEATDTh1P8J2BkzVKkdBsd5RKuN965nyTM/29s7bDtH
DFsBJE/ONK2KGm0Nhbw7qwW0ASC2kQSTQAToWK+pFkLp6Nd9NMvK0vz/cg4AxI56kDYCygKB40QY
oeMaEbCmEOLTQH+Sd5AZyfu9Lsk2Ohv//lbFRKmLXQfHA422O0Rg4i0zN2uKYrhM96FSz8tbyeV6
tFaWXAB/dcGWo4nYRVR8DRWO/xjlhipEeZ6qvz6cD5eaHtfwrO0cBjKa2aPH3sVkGPjk+7Vsqhlr
lAZ+3xE0On1AFakp3zTa0bGnn/XZ4kUYYedfqCaXXmoNmeifKC55JMC4bB0173RGzGn935HznAHV
P40sB5U9CHd71G+/R1LjW+kndXNW2sQ9v45x6URjNkZjE4ZrDGVvJGGldsRrV5qkJHjTixnt/WX8
kEid3nYQ05mOdN7RUKTNuRVJBl6/bH5PN/zVmT/4bDBUt+Q+jD7gzi6EEFU642p4nnGKt9fxkEPm
nRgsKP26x1vngiq9xziZq/c4N2+ZSLj7wO8zJ3Wb4XHPW4+WCAZU/jL3d80kVKG3SktwX4zTJNqP
TdkGlLRLA9i3qQHRpFUlS8AhCOMIhX2pzDzT9VM7GFjZBsznL2PJRA4qeT8+6ijshGKHt8Eirfom
SrEUAcBhay7rUAc1jSBozq70dRmqhKIPIpvdNn8Pw2Zog4nLCo12w1/cu4UWQwFzHpZMQVL50s1q
0y/lNAS6v6G5lZB7PIkfyqwp9mE35M0c2dVb3mgvv9ReqQNf+Ik7J5e1w9tkpfadLAySKjJ/GEDc
2/zwlYnUu20Z15dRKkjcgkAinak25WSiu07SRQ3Zf6YDjPbqPT2JRMyI5dA8W9TYOLk4uo86vKmX
/t9viiW4hY4PGnGnWK5ydhSfy5wdrIzBFV/P7JPobO9yiU/Cmnz943dNVy8K4uug4RBb1+ztBTQr
+81pW6D0T96IL6ibifeFqcbl13cvKo26fh7l56YUqbRoSdqSa1gxqK/QLqOgpLhmh7rOi2Jk0S2k
DIgWHRmxjYSfgoFLg48e2EdczGWr3tAf06LctxFoqYqWynvUapGudFzTt1Hx61nGaATMf7A+1I0f
g4ieNHSXkdOXW+j56oGYA1KGp+f4/gPL6DFYh1WfK5PtmF22pQx5cAIxVded0Ulw+uioMtfbaOJu
Z0PXPn4aqWEwjQP6aBpvYWJpUt41g28koTsqDakpIrEmfxWuplWoNsN9XJrmn8hpGVntkAuOS4ev
qEglBtRToKPCvF2ueoj8VFbgEWBcxvf00ZW8UW4Sdo++OaldYdnadz84L8C1cgZ6R82An0E/hpKM
vBLMV7sqLrrQBGBF0DxucOhlPeIYhtQ46FZCGAgBJ8kDvz7VtHkboyzGcEQwjTK8RCO4W0oODGEE
XtO8GkZYRCClv8S57sxrmMH/SUxPBFslar25Q6vtUhA881DDm7wve/HX9HU2mFGTTDHSuhoiXn+3
xG9NCC8+ufBCjXTYlYKT72pu5yPcWI+JItSMrKSo/NPinHSwvyVTxI7RqCf0JA4hSLLoAxJ9lhL8
wFM4G41uIm/TKWe9HYHn5Yox0opjB2A3NVxcB1wE/klbPEN8ufPScPjmRrTLJG0SKmqOlkG2Ecxe
EmNzZ/9maQmAVa0amwGNkATfLz2h9HyU4MiAbSKApK/6zwgDW38nAF4uRLMgN3TBe6joiLzFoT7V
CtRbd7ydQvO6tx7Mn+bzi/gShf2/bO3sY1K5edyAyfqcLHDt+M3HZa8H7XrWMoEkG2rSioaN06th
ivvXEN1XRmRYZqRi2SDdH7SpiS/mdsHF5CaRqIMFzKIgTIU39b7opHlGp6EnEvG/XYSZEAITddwO
WGn6Ia6dd9zJRGdG1i4LZfFtGmcAFPGN35XAkKyJqBf8QKDc37mBTXh4AVgUdwMFKpGE7vU+YjZ9
UT95E6o1H79WpnNClBs8QfJiGzFEZ6xcAEdGU2E97GPBkB9wMsIwKl+r2E+fdelYvQPvGM/Nq3Vk
5rrJ7K2kN291pd23uelC8nR7rtETBul1Tkw2ikR3swYnJ/9yKw1JN9arfB+mgfmzE4aVtKP3Es2v
Wxytem==