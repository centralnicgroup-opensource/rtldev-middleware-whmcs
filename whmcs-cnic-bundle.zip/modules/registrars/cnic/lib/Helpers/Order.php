<?php

namespace WHMCS\Module\Registrar\CNIC\Helpers;

use Exception;
use Illuminate\Database\Capsule\Manager as DB;

class Order
{
    public $userId;
    public $contactId;
    /**
     * @var array<string>
     */
    public $nameServers;

    public static function get(string $domain) {
        try {
            return new self($domain);
        } catch (Exception $e) {
            return null;
        }
    }

    public function __construct(string $domain)
    {
        $order = DB::table('tblorders as o')
            ->join('tbldomains as d', 'd.orderid', '=', 'o.id')
            ->where('d.domain', $domain)
            ->select('o.userid', 'o.contactid', 'o.nameservers')
            ->orderBy('o.id', 'DESC')
            ->first();

        if ($order === null) {
            // otherwise we would struggle at later point of time with related DB queries IMHO
            throw new Exception("No order found!");
        }

        $order = get_object_vars($order);
        $this->userId = $order["userid"];
        $this->contactId = $order["contactid"];
        $nameServers = trim($order["nameservers"]);
        $nameServersArray = $nameServers ? explode(",", $nameServers) : [];
        $this->nameServers = $nameServersArray;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Model|\Illuminate\Database\Query\Builder|object|null
     */
    public function getContact()
    {
        return DB::table($this->contactId ? 'tblcontacts' : 'tblclients')
            ->where('id', $this->contactId ?: $this->userId)
            ->select(
                'firstname',
                'lastname',
                'address1',
                'address2',
                'city',
                'state',
                'country',
                'postcode',
                'phonenumber',
                'email',
                'companyname'
            )
            ->first();
    }
}
