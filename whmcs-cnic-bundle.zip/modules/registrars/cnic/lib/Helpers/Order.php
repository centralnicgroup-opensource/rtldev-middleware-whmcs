<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwRbW0wpPtaXIYeLBSugOpZEr8wMXsb1FPgufiOleDFKDFrKb4oSqMJPfci4oTSGYLWOTj6H
eyWemLReswosdeIc9vyXoKpjgde+qLEOzASeKRZVzorBX194pkgQQ0uP7sNjBnMTXy8Vbnk/QFIq
syAjHeYrtN6tlG7YULGTPT55t/Bzyt6RH5woziKBnyyV0fC4C9rD8obQ6vcvfhtaFNsRbcAUEf3+
CN6t5ph3u6d7+v9jzbISfasRfeo20Z44JSPMiVziFXhP3NoA6aoR1ZAhpMLgDbpVyiug/m27kCu1
ZSWj/nTiDWDRLcGELhAXO+PuWPy5CNSq2dwoe/Bcxo2BvqpIth0dzSSPhC9xd+18pH2S8Ig91kAF
dHXbyCdPCkGaCZbEwZImo4L+HTtxmGAYd2N8jjFJX8Mr27vpQe6OCBnwJM3ol00CYjLT0FoXmSBq
P+x05UdXzQhAs6pJK/nEoqUqxKH9j2gBKyk8nthx4EfMZfk+w3BfEAyAr7+22PT7bIhZ6IM2kpXc
P8OjyoItSQL7sbzwhdkpu/cq8WuNsFKJm7XgjUPZIkqoWOiLBHB7yXw8z4ApIs52eiIJn+qYd5Bm
bP3yaz/az70Fr7ZmgyodANxlvr0jfyiaHkq8GSuMO7R/a9GRMYs5BHuGpXehKqcosQeMxBMo5Afp
vjSV0sj96tlQVRLOgh3FkxJcWSou1mQNco92nKYBuEM1lNOXrvDJb3hKNakY6GsudF9DW86fibqS
ycoJ02nTdOcIjlVhPybvpiSYxY9uV/iakO6oHWwsXO8TD8pCklWSXLpn+H3wrF7j851W8L0jvi80
v83ySU/S+BMXpaRPi1CFrinyrxS/6c6p3kfJBvVdvzklonoGYk5EGik8qHvuUrvmJigKYLlJZFHG
qNl1XWLN3rURjsnE/zUPbQbE/fRlPIqeRJQK8vJjygAsZfLnnK95c2olltz4n8IN58+7K20Rl3Wq
LUbdCq5hAhmQ4a6qvStCpT5iLyswXDO6jK090Y7GNzBir67TeRmnZazgUXrbaTuu/0j+WLlYLl+4
FRRsT4apxK4TOcY2JPEp4tUkyD9IdR9/9cqE666eNwKvloSxHe5ow7C97jBCUHhNmurM29xKH4E7
ktpm2J9tKsQh3sBacXQt5/2X+jE0oJGSSySMnqTumOeaavqvr05QTh8rJbkClSAU2z9a/Q6T7YjP
3dEgvpabyNmPOJFml6W9fCoMf7iU0PDgPWXp5Zv/BNIDX8QXNJh435SKhjJAW8JQJmmL74S70Y1C
l3JFUlwDNRRrbN9fZNqhUESIAqKsORwdtdvPg1ZzSWaqR7V24+FfdPWq0TPRDoL+gfe6uINwr/O6
bL7z/LBK4+gRo8DTyubEN5H0rZ4A/yauJl1AjIMyk0+Gi3SW6oEaRn9b1xcRQKGN7kk/m7dvgLOI
2bS9q6G4PmhdePlHIh645L6lPBbCu2ndPTkMSLTbmJMc55ILLJQXyLO/Ejbzb2LcY2D21tZ+nR/C
yxpsIcNkls5Nl9/MbCgq4mGU8QUlyfYc6ut526LA9+kJ5K5xnuKfO2YutKK0ICr0MJw2RAo4SXoc
fBx52992mVg9spbQeH//UMXZl3utU9ecROCINd1m54KjWbFFZCX2ztbjTRxd7GCEhvK/HCDrqEnS
Hj/YZd4A5mMC4pFEq5y2xNEiBW2lPXF/UDKf0CK/6nVfspQmb4dPKClHRSysqTjZWyvcI8l2Vu8I
UYdjIVbnxEndeFK0XBT2G1La187LUZ3XihXp9DYOgKdtpkcHsl/Sf2ryYLksEBbXYcixoWboM8A4
JPE0042SGrXeG++4QPD0Ft2eOrOEGsf9liCjcXta+LZrnptPTe4Hn3HDxEZgUTGkgUehGgh51885
rjhA6RY/+hU+cZ6VCOAOksP3x8a3f3jeAkUXjqw2ByRMNEpPed0I1kPgpPwEjhfMzMjdnoOWNIQw
QAvL4bjuvihjsjXdmfy5IyoK0zfvp66PQoXTSBfSnu3+Ped3LQCxt8IRHHz2h9zxGEn5MnTupKMC
wGl0/sNd4B769NNBIm+bHxPK2PipLRSHJ8bwXUgLsmGNRAFSIivjMXjOigVRtWcP7JjogVsER6da
IgzeYS/kS6uBpscYDVcMUQdKbBrNEQjGkEoUQEBhyj6njDO0pdmM0bUgFwza38AoLjbnkch7Mlia
ByUze4nDr3U7y+7ZHC/KfPLKKQpk2quFQHq/q7flL40h7694FmixSiDA7wYGkpY8pZAkLGkCwz2z
e7VY1cr/YNSaBQxwxxS9S99byLn+K7CUMdFSquovSWIaMsMLQKeloVTxQbKSgSEQh2FkyBz2Mu53
iWtW4ngPou7/0KrNFUaU8SC65bpaZqggWFTIuvTF/wmIT0KrfRTGfE8dkrpxr6oAZoNYUNy9h3UE
ml7Q7V7VQjnsldvtMjl0HijzBHOL+0iN8i+c68MNVYG/8C/y5lDzXXaB1lv90cOHWi+ldoWVjHiP
Cyrirw9YVBroPHM9nRLYrM6D55tnTyniB71U6z6u1S2ITzevSdhm28w83uzjR1dwubM2aaJb4wr3
RmmbmUWjNiUaDMNG0NScTdKUs4rAIVjWdRdodXZ7g8TDhLEMjD8tshCoCuP1UPXtvogMlub1ae2P
Dj0Z8896u1VuExQSb5cRX4akTWd+Fk2VjHMeNGtyTjkC2VhDw4Blu/MHWJzKrHrsAi5S4eiv1UpM
Bpt/pxTzU2J8GTuITARXGIALFgE5f0uFGdjTaq8ghbswStlmi7xTYQoIPfj3M/6s4D8Bunwuij1n
gn9pqAa7IbgCyzxEzlDqX+oGrIkt+E3aZ2ztGiOe1q/1IIn+VNt8J647e9bFle/vN4AJhx0Ujxdh
N7DbL1tQM/tTdeIOxOgTOtqDIemmEadCN0BI34LzRuznVAEpeiCVd5qKLTFPLMRobttEsSRAj1Sl
9F3E9OStR0MmlgSwsZF4YRYzUqPsybTLLBFMFKjaNl9lvIt45s/6Q/pxf59ox7JkFP325XQMrqFn
RVvKPMgOY8qr80Bc5x7Uj2STagFGTPq3r31YEJRj4l+X94AAF+kbZUFGUZ1zyKhq+sgNJdni0uCZ
fRXNhM5+0vJweY6ZOdmZ+9bkEzPTseZP4/HpBY5LxuAhBm5pP4kMyrMF42IrpSshx9sWecyU0BMX
6YW7+J0V2QibA6TzdNGG+W19EVhPObph/4umdp5eDUqT0nxIXbnPPM83WriA+5Pwbj5oxejLPhoO
i+IgAyOoS11XCbwGT1DrTrDaD+0LY7+oECNFJMuKShBUxHjD5j3weqclKyjm2hMeIlZK5EMhBE6F
m8o9eYFNzBjCOO0fwseWruppM7NXbPtouEOIFXooukksltVOoS4shzn78Z4ljprepOwycj+UCEiT
c2v7Q1kRnJKjqLPM2hoanqhZVDWYDzCpfFmDPshBfTE1CVC1U9Vwdl3W7sxH7/JZftQRUB+1o5+F
WLhXeRBIkmv/W8fSbGD7l+M2OYazK7oadVsCq7g/EENpboMLqW8ChRvsiZ1HtknMk7qNhtJAShO=