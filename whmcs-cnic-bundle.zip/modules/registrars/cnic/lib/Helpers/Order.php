<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoF2XLcWWNwUlGqGUh4Hd11FURqCD9zJcAUurdyBLESq2RZ20xNXiaUjduB+1PiigGemPn3Y
QGimLJ13B2uLbVXjNDHMQ/+TwYpBtA8gS6xYlU5GlSLwIaGLfqcXSbRyfUoMPXYyN+/mD8q1QQOT
PdZ1olD2bYWzKXRYmg1zDN4OM9EEwUQb6e1BC/x5Z4xxo75I5hearwPvBfIbu6oOA3Vp+LXozfMj
AtQIxcWwEXDHdhUeC+lAH/TSCIHOKpazN2+wxIqRXP/lhvZxOR6zLnCA7WDcZtc+kzq2+gLJw0XX
laPLdd/5KxjL7c9YivJHmZRkwRBfj9TxrvqoWxBRbd1GorFjdtaN5GySC1vxLRuFWgWDzVDO4fJ4
TijvElQFR8rJWBqUbnrE4ySwwdL+3vY+tyL+9qLgcYR/soFqOvDob8seP5bN+1aYUO6oFzV6Cfx+
OKlkffEukMNW4s2CLffbWsl23iKYAbq2jNC79oSc44/pAC436lVBmU+S+/MxL1LrbRPzCVqBMj8n
L03zlMJxPmZ9IyBbR48akcJIFuj6LyxOVpEPWD33gTDBnTPZL2u1WVXk7qwTzqikDMT253bGDL9j
zPrlUCj5cOZNKs3FBXlNtgZf92s3wRYfDuDnWmTXrfBJd+5W2M//NsJG2MBg8w0zqtHKrquMwfSM
eSByC/WljWX2tNxYwigCwlWDAN5IT09CE1qLPvFY3UgefDxlGkRiEn8v7o7aqbsNFmtmbfWEOmvW
5iNDyYFhFftv+Ew5yQo3wrHcxe6Tao51Fk2AihCO7KTUECrEYtnSmk7t26lbQBElbnZ4mleQM1Yy
R9b4r680YuTuejpA8Q5abKCicnjwD1dCfV2azUGv4TFMazlmrCDovovIGXDj4WkmnB2cmlDQYu0v
MCvq6zWAk/lVjwV2lZEQDI4PqQp9AzbtTHhbUg4cTwO1JI3oIe8LBJcZIcwuWTsjByO63Qk6zO/j
L90vZZvKpYNkFK6GM4tNJ+Paw+PAyCv2wMrTsoJuxlzOEWLOp1FoJ2gR64T/bDXxHkWHzQ4cpuzz
DPtjItBao/XG4RVfL0wIEDnFYPtDRHsLeJJzizCKqBXYjUJ+SAILmC31YPWgQ2UShR+pAuraNvzh
tWJkmqjPhIGcimpE1UOHKyL7BpsvCsYMmv47Q+Iqxh+YNbHGiqmmHWkWwHCH/Xo7/vaSx2PbTjnG
OCqMb/xFs8581qpAXab46Rg3HSsY412Lp6prifUAhU8xdspsk1lBMXWhZ8niTtHg7LeBRgs5bbY7
r1HK5afncEJIWaS9zqyJ/NPChacmCn6ZYx6f7ALWOal2E15wztcf1E7HhK5x67q+fUu9Br41Fbx2
cOrD7yfQoixvi5DKHvkI3EQRDnEVprMyuZ9lNOu5MWMRzhIvle9fL7JyFvfPJ+gdJso7Q//O3ufK
WU/jDLTW1H7cvJzo2Zu/Ejtj0LdQX0EmJMR5pAsAsm1ZFYCJceS/Wh2r9HEt8x/pUMO36Mgw4rho
pumRmyPnJeQHZOaTKufMnJEN2g0n3ocGoSXhNTURObatSzrI69mG1o0dASIYZgs+w9nPeJCxZxwQ
oDOsvqS/yB9hWlQ5BY1NNUbokxc0UoSiXii911jdb6CKPdwd4vOKylXxH/X/snwcTV22Wyz0S4kR
qSH0KhKJlsqJRYspv3XkYwmdw7F569TbUIXxn5NQoVaURXq494UD+Tfm2fg9+SNKKJbnrgmPpw+L
toEW5hxbkrUWl5nQEODXBSa7WSDh9zPHNpJYh2Z8YmEuIzjoYYGeK3Wh2C/+x7MinSTQxFCgo6Se
KQnKnFQnxQhUqgMgWBj2sys2pw2+TsI36gyeGMxeg85tFp9tvyefLDp4YTk2aJZVc9gRVoR3Pf4q
XJr/o3x4GqMXsWc7LXbqBoR5ylqeeAus5ofKVfqJaGdDgvm2G78mt5Md1GwjYygJYaqvUMFj2Zk9
FOKXDDMmfDSMoQgVNbdl2Eq5Z88vWtYJcNq8W2easdjAR8zrBrdS0cdzRSx/o19AWRCx5Fz/SgXB
hMQybxglWwk30xAzx1ZybRIJCU1OYsnnIonFj5axsoSLHZSSiZbPFz2kG1zuwnIVU4ksdXn2ciNQ
6L16Psnv1dmx8EyKB89Kh0smFh9dZ6HYfTnrw1ERmBOn3utqIMe5fpersmzC1wRvpCk24gmU9ZCC
ICrgFGo6IrdJgwhd+jOGFrtdaUhKtpGnCAueD2eB7bwFjghbPUfHfQ2srYBAN0Dp19u1+dCwNouT
ydlwTXeYfKz9aLx56FruotTvtbwpgIvJuaXDLdGCkWUXstaiJCEPLSOgGwbt2AUypl8IWGIyGe1k
OZ6A1Pa+ib3Aty6YZCMqxsJnice7oKvVrDMK5T/AgTTolbzALPSOc5R96kfO1QaQRwDtuIN/YrZH
yGkwiottxTsO7yqj2O6YQksAfLRa56jNVH94tz9icmYgBMEwny52DdoIvC3Vn9Je4Z3nEWi650fK
HvWGWzk3vRlD4ybKxAy6e3arBGYHsRSHidBufzcVNuIMci08XDsKEUthkfuAJySccyAWvEzTtZuD
MyRKm/F3jjrENkbKIPFXkjFrU6mOSr3d9ME5DmIrXXqB7S+DrluGbf3n0DlPAUucPQ5sUY2nHsGa
sw3y05B4rBGDdr1sAj2SVvcPSO8Icgs1ujrh1N1434qDJU7xc19uhMAdWqMG0xWWdq1Sj97mu1qs
4yqh8jzevdBrr48mDwV0cSCzqO2GB9kIUTzfwWJK3aKk0kXslW5bkWznOOLjavH0oG/UCpOqdQTf
o9LQZYp1ND12/a0HJjwocbxOCLfGJQM+P+BwPzP1LcbQCKYS8RK/P9vLswypnHBkwWnxhY8H2W8q
gfwIkEJq3syw6LMUGvUfYiYqz2sBRMqdnWxfpJOczKp5LzazoKfMjmyRO3OUnHaiWkyL63u8VVPw
GH3C0jLECqqQAODBclIHSmETqiJfV0zqh2B2HslF7W83rS7IuxtuoURYkjRSAWXJRpkNpa9v3Rkr
utSY6YsrkcNSN3YTi4mV9tsscv9YjVsvY2r1/uO3OFzJfZCAIsXs9LFOrsvpyhIbfEuUwpGWazat
+UlUkSsqA2/GzthXPqC7Yjxt5sDMBKwX9o4JpESHNLQZCU6AzofkHQVSdZzm1JFPowge9tr3DjHY
X+h4Jvv69NdtKdkaBLeMCrTl/Fbm2K0B7thu+I5P0jWXlL0QGOjDXEhkA2WewBvWiCeXbUwosSuq
gCbw5f6nTRu+R8AsmcXacBkHpP0tVSrr1P1CVn+d/DJkGYXo9cp3gQvd8Lns+DpM4b12D+Wfzr7w
LNYEHWSS0LFq4fw+yVg6G7ZaLkadqpcKrCAVtoeRkwleRgMerkjiGjpEIrIg+u5C/lQt6XOVxgPL
HNq6P4aWY4W5FarrI7hKIZJbEa+8TMOf2qd11PWH5eHlvUmGp6MPdrQmXlNlUTK0gjZLHde2wBNH
ouvUyq+PAxuohCGwoQUNAl6u4cpVdt1soUFBVlWx5ucebUgbbJ0NM8sfSGlG67g6l7KEqciiliMR
VxQroAvJXf6mZx+58m==