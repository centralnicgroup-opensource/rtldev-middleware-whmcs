<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq5wHkBOwRhLfRNJmUpdySScjxxvQxbGrjTxeLsN3z8Um5bY/sRFBMCODxD+OGyOUaKXz9HI
/i/fuyPkN/hSLeQR88C2YbvJGgfBGvekYqnO1tX4XXpcrnFBwl0kignnwD0Gcz368qVrciYvFYyV
9K10lLVDTBiAQ13XpFK93RItegrJd0ukGJKSqe/5QzwCxFYI7eKpWJjL5dltkRQewAaJGO3bfWDP
geutNd7i+SflzOwNA/ZEq23aypXzoqHwkaMqJi9LrGofFGIgAFG//w7Flfm1rhzmhCampJPN2bDk
9j1dpoPyaCrWTsjIIu+QmiQTZ7wj4HHzqnmr+v1j/5qbGObBLLnXsRU9eXQJBj3qXYwwgS/xqzOa
PKqt/uPJKvP4yfPNXz/RML/YC489CtCOpsE05LlYAaNxt856k3kis6icPiJf0aXCFYPRhleQIqc0
B4I9yNJ4k7hcgB+Zzr/+Pu0YC8+YuDHG5LEgUc57DH41DAPhFvmsFMx52M8QoaMm+n6Ksepl1Ibv
Q3OTilxT5tW3hVajwJrZqioJdX+65J1j8yO+Yv5ScDusSCP6bmYfO14QEY61H6UyaxsC1R73ws6V
dHwXmudyTpB5mml5V/lo3vOf0MljV8Z4VwyIWZERRlSsmPkAjpCxM/4ODkR9nBQybCcy9HJslALG
6qrB4TEmb6NJxpX9woJktqrhLPxY5rvqfzu0oAE2HJf1C1OIbl5/2YqD0MIDCr/2DCCmMvbIj+56
BQRzqNiMznPjW3NQlCQNy7XZ5QO1+SCetSdNw6KN9OSQLTrmdbadxpXD6wgLGuYrwy4HYWQchk/k
0wTqvxcuMpCAw0xGFvuW5yJYwfbLjT0wbE4WfxZNSn1W/UdwXN10UHO5bjALLBKQrOyEIpCSj6/u
XXVUebgKiR4+JDbWhFIiMnOU3mNBcJYy5Vx/RXYmdljxmfAqksyNJEpuxxSTZ9DwJ3abTouoJxDq
N+81v6HAbFrQwxoc4Cq13pUa1hT+0EVloMlIoSOH086e4U+ZI/OvHca638VAzuo4mcPkKJshz/35
Mg0CZuXpePwr/Yz/6LGkUYCR+ZBndM56s9dcKH1/K+s/OtTWt6AMyqNYtwi+FUj5TxpKH4mgNcen
1al7jyZvwzrfHsD4NR5s1tDdcwBp+/RkQBC5zTYPb5C7kTBJggxkB5jqgEHtk6P8jKKWWToANND1
6o2M37qcO852zdEZO2p2OQ5p0w6n3vkMskEeNigiEqpE3+DOhcW1kJXHgubjsmDQoToRo3eIKFJa
fZ1X9LA1QZ3kR4agiMKXFL/L6AbYGvBuDp8NHpIN09oidyyXVKp/4DnAXT7IHHq5UQ6jngMToMFR
EP2/NhGqxXSP+5yWJzsCBo4hfHdfT++tL5/Tipt1BgN+V6mVBerxgnl9Bp1diWfU/accyzcIBC7I
nNycELbR67wyT99pWvyqnsKez+kzISho31CQfysDwIW+wnJw1RUQvKtqB6D7i55hFmyTuc6OiNac
MrxVQ90U1mCkhL+se+HM0Ub/2TQiQ43L/qVFDptRMXutcddBbs8pkXeuqPs/KXJ6WWplNsOSXNF0
mVKJBATCxfQd0HpwZYsqC5ZI7uynFwTZw+keQBzLIU7Dp9+jYDQOtDkaxhInXD5iWoji7UhdJKiE
H8PYiieFklp5WetZxvwb9PYAWBTUdwxqN44QT7Y/LTB/SioAw8pEiPbnOgRhGbowydrbuaOrV1C5
Ta6ViTxPurtI12BjFb9CYoJnj8HabRh8NqkOJqHajmprC9pj8BthJipEwgTXRVSRk3+gwFob9rMy
wCrav/9G0FWoV4E3I1xbg6Xr/fbW5Vxv0RGX31md7I8DKi3bKxJuiJO93UdJTrZPrzmn1kHIxhqW
cylETuml1nKsNaOxf6CD9pd+YIQy/iU00By6s1Gv8+cPz3/O91aMTnbeu8dFslcVS8F35PJtKi1T
DIDc2uHa6nA23SC0n31x1/8sl9j4pioaIQoEzTpyZGMAWAFgRlciV1RSyFXBYfkV3A1GzmYK4Uz+
/pgRR8QbVqq9vZIIYrjNVmYYCffU6oUh/i64W1ymRAEpdEDWKWPK40bFvtTsNwpvYxNj/0bGW4S9
LVwyg28m+xfNzjOMSp0Qe/+oH7/8OoMvqEKFpIOebEq3ZDSLe8qFZve+dEWDtpAW82DgxDlGgkJh
e7dLfqINO9nwqF+6lakBDyLYp9XfoMLSGQ2rx8KcGk8VCNZx47lCU6Uj7Gccl3DFkLmbmmCArq+1
Q/AQ/kY+OylrO4+CojEJ0uKhlskr1HD9g9v+VZVRtNReQk+45DCIwMCul7F3cr3Wp3dFE/vgSHpD
FjwvUB7j20/MdJX+I+NLClK9rJwCAmhidasB+3e6/Fy6LnricZ8wV71Yd8+tIFgNKNV+4AnUbKiF
c3h5wYY2+PejDE3d79atGVe53wpWmXmPMisWocsfWFtNWQuC8N4oiVoCFXqsGXy4Z79qEOslL2qF
+rbQMcX9+Mc1B9G01mjFXDeReSE0nm5v3NjYkJZsb6Km3e4usWf16o1ieZ6zDBXrJicQ27DxDqU1
EEyTZqy+xaREZPI/bpKc0hfaeh7pekQ4LtHCOul2pMZ7fSkunQRm+N/r8SWXFtlkOQoqB7pSeZB5
PW4wMYeuOtdQv8HV6+tbf56AuBQ6WdvggUFv/khdQpWdtfXU0c+OmsZGYNhOVdmGjwEqkHBIjQPK
SyOrSv8F4/zEhVqHYioP/R5zuz8C8MW1e1aqcyqcfgX4xOkvyk621/HTSyM5O3kupUQ4+JMJIIvU
DUE7sEC42C6grBkcLUpt4IMx93R+IeHwNBpnVrkVN211n+rPrNEDg/XqKwGGULSTaYntSjyL3cow
aN6FxuR5OlvhYLDJoucfAn9BYwbkgCaxsW0Ap01/pAJ+4Agen3l4dohSffsMb1Wmj63Er2H7cXTW
aZ4HjcAMaLPHRSP7fddDG4z8JIldxBcpwvzYQsy4ef9LbwZQk3jB0LA85i3BCgzxr7HrOJ/U3aiv
6kggJZQNDujsowC8ZuOFhwQDso91Z4JQKxw0YtYtr77BVlH93LWr87fHHxLYJX3+AMc97mVnTao9
TnvjHty0uRFf1yeAGPvQsGy+D3OQteU8D0k/amGJH52yvDOcY292IiLBGjoF4mYABqxofLJercPD
1p/AOmI3kZ2NTVF+jvTokkNHE0BAewzy3MKQh/uOgj1+XudsPBSbo71OikQRK2ftzPKGqM5jHrJh
MFYQaOC7xBp+feFNRveUlbGZKk9fA3LD/ki+p4qj0PrvBgsJp99Tt/KMIZc9JVREMNVsQ9ginJjd
J5r1t47zvbQutG5VpBvXvCkKfmUvJSu0Eg7cIMw5E99NqONxIR2jxyku6WMmv0ibHmHRX0cMQ1mi
SLQwBZt8hD3VB35eLqEeNiP+10jQPxMiWGiD3WAvJZsKHIR+w1kkHf0hV+oUuRHi9EtYxt7TXV1r
HcPzPdrRY39CUOrYWik65Sk7LVboggxxhrdoa2pfaAEDAjnfxRLEhwpHcCC17bk/PbpIhFauJCUP
bTMtKyPCDm==