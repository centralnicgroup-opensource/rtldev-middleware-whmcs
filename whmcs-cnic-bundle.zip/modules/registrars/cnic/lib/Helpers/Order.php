<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/e3Aw5nng+M3Co+WX+t0H6dzFHtqb3eYV6OSbZvmstXXLzL6qmlJxPiBBiE0idZXo+bwILM
7+DnRtOe7RMeidr80EASHgaGSL2T36BloE3j0o9RafciEtdAg710SWTehV8ozEHpTUOwSzMnncQf
Bqv77bTdSvelXQlvAnFSUUHzs0kKIt8AZSdGT0MevSFKp4mrt9r3jndKWoNSv/fnZV23L4ZnT/fW
CPYMEIn7lUpSonY17nmuwCqDFx6GE3xzry9bf4LnBc5XMRATCsgUDe4RlvuAQhu2nEo0VFLVZHHF
XtZ8RxfKtbxwiZlynXKr7z/i3rRNIkOvSGDw5NJxw+UUG5sDcn3vpTiGmn/sLRiTYD90yke9v28f
GmnGflIt6x8hBbo4t2fgn1KqAetL1P5i2gCIALaCiDZ18GNb2Bh9XJMbCbNqToxXxVZNcltfBCyR
L+IEoSPL4Berr9wY2w/FgWgi4IO4bK1z/Pvds/gsjx97YK/jbFOPLfZeY+mYF/UP8SK75xB998bS
5JC7sWtblbSA47/VgQWRuKDb77QF+sH45NBN9i2JmJrEt1nMYbwgE3dKyBGdZevJB+SjsMBF/Xeg
vs+g0oDerf96q4wp3fAeho6m59ExLvfa9LrqZt7Jm79UCb5jMSgHGHlQj7s+7qVAwo0ecM/0TFD3
V9vQ5q672BrnhXYtT0xmLN7LwcE4CnRGCC4BED+PD4e2/V3QFfkJFtwjr+3aBI+LRTy+iuzB/vpX
vYXFPidto+sauV4sZJyPfVF4Od62SdwYJg6zbv2R+f/S/sbpglrqvxg6/HGlvabUBdFpuo6Yg2L0
7Iq7SzKM66C/iB2loJBkheK5wh4HP/xOgm+QO6U50erecJ19JZ1CVFKZYCKGsF8XICbiStVaxFFK
jWk1Dm2QQc/lP/Fe+ermi7EBeY5mmcBLjIq7gFpbEOZaUCnyBe3YbZRfnV4eI0tcs+pcRGXbPPuY
fugKDetlFrKR/at/xMHdpVmOyHWTXFAbMUzZTGJATOB97AjjE3GAhVc9xNvV3HebCTx6irJUxRpw
zRTl1eMM9qB9BB0eONSRpLrWXzz24e2cpsnOT95VAO15Up2fd/VZVOw8Be+C1H6nBc7okJhMMSaN
27OqrIYg1nYSH9sUSCbTmQEgbG17dxDWLw6ty9vzhL5f1++WH4Rh8XhpizrwQdeJM8eibKOFK5Yi
9sx4uMPLNQ53uW88SkP1l0TU0HNPCREn0Fe6qH0KiVCroMZfg6T/0R8gbLeRx4JuC9NzXfs/Sj2H
k/Mi//PPZ0t2U5x88vfgS8gAj4Orq6mnZ4V7QWgzpxSLTG790NOA8rpRlXDlKRdog2Ka5teCr2Kw
7qGsR88ZhgwTbnxUNhSBicKbdyS8Gqsu5zFL/YLaMaMO9/Xb+N9PW4Ac+MweHxeVFPM0ai33eAPG
N2LAdB7mzFiXFqCKWxlvR/C8bOENOOVKNQUVh0W3do1tLCVjBI5uv1uwefSjKrNTbklfbVwxQASZ
cCqHt3SirhvohAXERJLib4KPl8ZcknI0AVe9Gif2pvbFXMSd6tMsELf6f7buSIhhQ8QTh9mGQCfu
JonPbdEEXZ+f32xqTNSR0rjED+ixx4UMyOUYcKI68cDZ+P7aZXExh1RF4Oc10m4QTq3xPILyC4I/
IwzTb+4xcowixgpnFxdga8uO/xtAVVLA2MXtggUP9zNy2/EJnkNe3MkA1gToKkTDXdBxTevZHjBp
SBKbu2cLaekgWWStzNp2+cKHferMJDuSnrpeYpEy6hXTZKoc+DgetS8WJyR593P5ehhweGHnCkmU
VmwU/JQbeKFKiBuMLoQ4shk4Bjf2u37OHb4E210zp76JXsai+WV79RsDr0moVfQ2B7FNxYe0XNjm
UABe6aupSDqQclpuID7Iq1KRUd8RuenXihFJo/9yZP2mev3hYlgAvrKSzQJLVckkd9uQiTEegyqB
5aw2fu9lsGvd7c1bB2vXEM7CjH2h8uZS87YQUew5TruiCmqAMw7SpT87kOXaYMEe6w4uxERCP828
CU4iMqkpaBJGw13FbLxD4m4c1jmPS4o3Yyek0A3J/a0X4eDRV90O9RXaFUKOpcAEX95ALeZEgIOc
WK4wUflttSN3hJVgizubgo6MHB9pxg/GU2RwBJ3+d+GSOuUreeYRQ/bN4pvuhqVmsrtgCM8S2Kgc
tK1cQbl+Lefu08kkdEMsY45xp7pOz2WVSKSMmPwoZrRKcQe0oDe20yIlLasOWq1tLiEHpezr6OcN
NpFN1zwx2uj6idr5I1q3AsTlftmo6S7+OcTBnVIghjN841NV4tDbhLz+v7m+Pf1FToDQR12RHkA/
dk1Exrx40OqrW/8o0vF22t2YLhcUN8NPgiC4qeuHyGCl4LhgAqBwVdY7hr7Oyji+iJsgDPVh1rcD
V3khHKxhyzmo/Cqko2NZ2PcnjyK2VyGp+3NxPFokCi6h/3cTlSEpjd3wXtVsv8CulTY3E4StFrtK
xvT5xs70gjnCxo+ahJXDjz0Kr844q3UCJUCkcdf3rXdkC12vO+AXUF9Bd4ycUVEWr7ZdV3MyATU4
JJF2G1e1omU5kYVBRmJBa03op50lST0/KGLB9x5f84Mi9Q67wjDWTVDS1eJPR07Kz23ircJtflvh
WxXKN/bXJvlXIhaRMT3Wuxn1dQFoUnsZIXPkGYw9oT0CBSx3b20Fex20oMjKLK+eaiZ6ZxD9/m7B
GjwiJrWciFeUJdJDIFTFCpgBJieHmM5SDC7/ax7KOuLaDe3Y4LKFoZ64B/oEfnaDw6mnsU77Lmic
WclYK2g5wUvYTXJ+mUqdAAlkb6HVhTa5xofJ8QVuYTCFH1gYsFhOrdXEitHamVc04pM4M6GsO89V
Zlv5mFw5qD9QORtVlL7KEYBQqaN57yvOadVMiqwruP260s0GC8AY6sTSM7BoNnFg4WphECANv9WC
l3rEsPOKXaK22eqfxzeWTewND15jVKsIP4/mNK7kebtbuVMkZ+FG1dObBaE+HUskJZN45ElxGAfg
vobDnLuDwru/82UJ1yWiFp/2fFM70pTHWZ3/TLRgEqmzdhdLRh5lq//KZYHWRdkToJFJUFLVTv7Z
xUqKdkfulkF6B8DBD3YmgtsPhwO5GIjzeMiHBxMdwyFaprAuxW6jXPOExwosPpFfm5T229/p/tFy
c2yn0w42JU9yWrAU42XK6bsnIGiJvhSDJoblhOJSQJJFUJRIGjrlg6Szr7OMfCXQ46zsi9jVzD6r
RaYy43YSIHO4ojxNNVs4MySETJyAHXoF1m56kNBw6m+ke6l90q9ZtJfphvtQIJU+3h0TviMNxx1y
HxqbxTBUq5/3fljThGkWdIcqfw6QfZuAXCyfXXbudWDq3mvVuKYe7p6eeBVDCtDLG5XHfpYLCMAU
JabMGOkqy99/+Y98bmxDVOMIw26ABAqCPZGpy61GrxGzBgBAu72ydkOQX47cvdAAjpUU8eCvpiTb
liT8HetVXqmf0A2/pwk8GRk0jvPwiqoi0pa6+7j+XWD6vtKvJtjtFx///hjVlm==