<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvCumRfZgpczUlTKcRBnVI20h8iGjrelRluQZPaIBWE4y+HxEGpKEeHwTDTrLiH1czFfQCY1
dLDXdAUjhDeAZVCmzRDCYxOPVtKWpRBz2ZYTy4RmYUx/acYyE1DqOKlj/iJVQBTd3xo2nIZm6Qel
QnASNqqTXcuLAiyEk8OaBumgG10m65/v5K806JynOZRp9sqJFKlkxMISUCHRBkTXuB9bFd51V1fE
kNccTi67+ErCb2B5+1PeHhSH7+BrxQxU/x813Uu+vZTL4SIu8of24mbqKokMPKcWX9MZq4bb2DWy
RKc8L1d5d+nFu5vFGpy9nq4Rai6MgrSYNtlXOaT9b0K5vOCXle7UoZ26jPmlZimiOJ/u7NImSwps
ykLVn7nzBwbtj2v/ABop3/TXsv40m9FfA817tpOmWxpGUVvmmmTNHyRL0wmFa3vqOKRr2f/Wxxo2
uBUwYY8up6rmEbFbSrXZ4N/bLAiaUaJ/3EjgcGW5rl7dkeW2zDGh1sR/Ub+s51NeLrHVks9QmJDu
mwNN1aU645809wPTvkNp570xPbKw6ogUE8UkW9+3J5cBlyjHwp89wf05FyvP+qbIRKL8j2L5uo8I
csJN2wtKqDQyXX2uTGmuiA/xTi/xGtRDa14hxI5jrX3J9G045FabPYo7l4VpXXz0MWMZfHDDhOWj
X5eJwcbPRHP6mu+ejsVVOOVK86iXet5I+1Wn0tSWnadpmTt+qlqkMx6H9UKFBGUD8NLh2VSBEewH
vai0ieJ8OjIx04JT2oRcrTGgWDNKr11s0/gh/IYPp7hWzZwK9jqxPMg8/wz+XLf72PoG7FDCr+SW
6ik5eU+v/QyGk6ox2d8wiocKZOU8LVz/qMGz/2M9rmhXhtLDQq8O6SB89e0mWIn+NqjW+dsAmSrO
JTGXrsJzkrGnEfijrOgvE7mmdcg/0JK+8YEVr4P7KNmk9bRQ0boSDvA6XjpybbpY4K3qGQQhZi9G
H7mQTOF9KoSDHpLLHiWQ098prc6Yf1+IjdZgtwm/mq4lcgfT85EpJiDBIwKT37+79GDiZ8Uh/2Nw
4UkHL/DRTKOA0YNaKylpUVLng1aYPuuaXf50+OXKNTzALSlfhbpPfvKiEwbBJS8eAiBT8CjjERCY
lAhtL5AJXmOo/Ixx+oyNijPrSqMZudawV+i2SSWdA5S1wSfVg6ovqUp415ysrt3z7GXR88vlXEEA
cPG9z2qloUomqdTGo+id0Ce8rZ2JDv/77Xf3GMCVTAWLrmKIh3k7H2WRvp7CxzVW8KO+OfEN0k3f
4ci019j7OcdFFqz7zVNXBR1jXpVxSfoT1le4r4/72lVNleBSJ8DHYWGr6gwxuL/2E1B2QivkWSVS
MGmC0+ibYkovWsBELROjzEeRsJ3CNyIP/pegM+N3LnXqeFQythr/iLf0k3bSGXxONkVXtiY47TuM
rIxF0mSw4lqHwiHk1iEkUixQMUse3Z7a/8hbI5CsVkRUzzT5+Z0tWtBVc0ThfCOp8YD952U48YMS
CRiiuFMOA9gF4aAeicflrUVZHAZ1n8iAq30eweyb+22zakqElXydj/lLD4437nYQ0GbGgnFS9xZm
T9aRW6khY3ZQUIDnDMCC6MogAmFhVHfTJNWJlVi3Tn3wKOS4P7VisIWmK//bm8VTstBHja7PSSQy
XAwS9Q8DieyZxgf2Z60GRFWxrZ8G0V4fzE3ySktJpESdlaOcMLbKuPCjXDplnPsKMss9g/hfEMiC
Jtu2Z6SuzzgrRNGEZgZYjhuxJbmzgIHLumXuP0zV+BQ0YdesYiUyl8gjfsQRYhA7wXtWQdtv8WYZ
jVj+lfbeKz7geYg1gz/CDu1eqfgLf5n+ULITE5kr/8NqQY5eyOKF73yO0vHHRmzcd13Op8FXH0Ks
L2P67DIrOHLrtTBF7B4bNgetLDDlEiGIsKbTWH9NsvfEwEGB0SbKn/iqJVINrL7qgJrbihdD/w9e
p8391iwRI6aeI5SkRoqhkdYxzg0xFU9VYCVhTaoAtlD0kxmjQkO4HAxRIGv7ajvOZPCq9/vOkcT8
UE9ZzhYKl/MxUEiPOtbKifPhx6RuFepSm3VOnvbnvKQ7ANg41Mdakb2ys89Tqmi3QZCqtFC9ddTu
BOuXsLMIxzzbvOaZVSEL4IVbIYTjemIxcJ+x3n4eQemOZDyQsfmZUwLYCHeSkUYq6B8nkH7iRXo3
qvzcuIcSSdZqnOaN5R2dzjtOC0OT5msmRjGvrjULyYLEMHOpoBqOL1eG+32uk2MemIsNxVrULMn3
FY7w28yokeur1t+PREoSw1pubm7u2Zfpf9racObLjnD6faaQoXkPllN0W1rNo1JXhD0GM0LGJB0W
B8Vw4NFFtnJ1tZwzBxIxYAVxvzcOk0+ZTBH89lhvAPzGS6SiX5oTFUcmSVYJCQEWIvwPOFp9mCkp
dsDwQHp0jIkoZyvlatC+bREWrjXsxrErNnf2jHpbGlV221nYQh5S4i+Ea96sntHQtoE5gSPUc4vD
Y1JMKBEgIWlNly9bkutaTpFzYO3pY40SbRcZpwP6IeOIlYPHiWAjFu6bstOAkKjQ2S0cqXAfc8Rj
VOZp/udpVklNQp7d8woJtuy8I0BGG8ZgG5ZbBkhNrHMY3VpftaTU1HIObeifEvQiYYm8PCTH1ZCY
f5jY7usNsDLdpJSVUk7Aaw1uwVcNeAwyYUu80OuRpAMImlGc4T1eFcmLh2TGU2keXOAH9luOplTU
2/ySSfipeoQeR9NmTuwBB727zFaXBKMxnIuT3XLBoEXko9S5kqIpPxTYFmvWeCbyNnrffP33LEfc
5rY3iU6W3CVEpG1bY8T9InW1yOJDIfx17PrtTRr+k+j19v90UsQ/ZjUU8mZkIdPLsWG0QStH6eBP
Mf2ujausAd4VIbetGiu/q8Q2LZwzxV63wT8r3LGRcUZOFnUUkx4qIvdPtnSMoYB7wvIt87o/h4Ht
mRYm13WrPGM0j6eF1JLacuyhb7cNYKh2ZDn8mD6j9oWG0EmUETUfGKk3KiuYwMblO0O/7dUJFWpc
JM7jPpc1JBm3i1Ay+quNIbopnZRtaq37YTHlQluAPrJ9Cs0sWy1GwqpJiTCb2WsJYqBcuIChNMwW
rFl0btSCHa8pedNnweY7MNciq83rniUid5sawenwWh9eJ/1ahmmR1t0gCZe/y0ZCRO/j0sLRGQ8E
CQeKZUqRR61BO0F6AP064+rcRkQAPrvvIplrMm3WcnZNjGi0uWjIe9oPqdOqXVQTPdxLaJWsrRf0
DYP8Yc+rFLz/zwWFp5SgxQb8xLdDDnKo5JqGeMbKqykrYU5Tk/3K9dmLHDAoqTRcKPCtP15Hkvf4
KNkVyegMx4pvoVZc7BgtmsIAA+Z2XudIHRCRDAkdM9x/6XrJECRc3LZY/lMVTcvMiGLK35R8FyYh
8rM+mAVro75eoGb/jQYYw0g56DRhwv1F1vTNsW+izwINeqcq5T3gXp7Z7IkUiOHPGyTPmRf/w3DH
wK9BESS10CtnOT5cvGjWEc8Si0Ekuq4oSh4lgRurwnDVcsYHNtMT0qrzatL9SO8EWx51vIIIrn+/
fRAZUW==