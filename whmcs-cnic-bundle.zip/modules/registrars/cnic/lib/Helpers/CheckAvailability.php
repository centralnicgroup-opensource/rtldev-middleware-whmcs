<?php

namespace WHMCS\Module\Registrar\CNIC\Helpers;

use WHMCS\Module\Registrar\CNIC\Commands\CheckDomains;
use WHMCS\Domains\DomainLookup\ResultsList;
use Exception;

class CheckAvailability
{
    protected $params = [];
    protected $domains = [];
    protected $tlds = [];
    protected $premiumEnabled = false;
    protected $results;

    public function __construct(array $params)
    {
        $this->params = $params;
        $this->domains = $params["domains"] ?? [];
        $this->tlds = $params["tldsToInclude"] ?? [];
        $this->premiumEnabled = (bool) $params["premiumEnabled"] ?? false;
        $this->results = new ResultsList();
    }

    public function checkDomains()
    {
        if (!empty($this->domains)) {
            return $this->execute();
        }

        foreach (array_chunk($this->tlds, 32) as $tlds) {
            $this->execute($tlds);
        }

        return $this->results;
    }

    protected function execute($tlds = [])
    {
        $checkDomains = new CheckDomains($this->params, $tlds);
        try {
            $checkDomains->execute();
            // Loop over List of SearchResults
            foreach ($checkDomains->getResults() as $i => $sr) {
                switch (substr($checkDomains->api->properties["DOMAINCHECK"][$i], 0, 3)) {
                    case 210:
                        $status = $sr::STATUS_NOT_REGISTERED;
                        break;
                    case 211:
                        $status =  $sr::STATUS_REGISTERED;
                        break;
                    default:
                        $status = $sr::STATUS_TLD_NOT_SUPPORTED;
                        break;
                }
                // WORKAROUND RSRBE-16968: https://centralnic.atlassian.net/browse/RSRBE-16968
                // Check if the request is coming from aftermarket section to check availability then append the data until afttermarket data is part of checkdomains
                if (isset($_REQUEST["aftermarket"]) && isset($_REQUEST["domain"]) && $_REQUEST["aftermarket"] === "on") {
                    $sr->setPremiumDomain(true);
                    $sr->setPremiumCostPricing(["register" => $_REQUEST["registerPrice"], "CurrencyCode" => $_REQUEST["currencyCode"]]);
                    cnic_aftermarketDomains($_REQUEST["domain"], true);
                    $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                    $this->results->append($sr);
                    continue;
                }

                // it is unknown how cnr api uses reserved domain statuses, tmp workaround
                if (
                    stripos($checkDomains->api->properties["DOMAINCHECK"][$i], 'reserved')
                    || stripos($checkDomains->api->properties["DOMAINCHECK"][$i], 'block')
                ) {
                    $status = $sr::STATUS_RESERVED;
                }

                $sr->setStatus($status);

                if ($status === $sr::STATUS_TLD_NOT_SUPPORTED) {
                    $this->results->append($sr);
                    continue;
                }

                // premium domains
                if (
                    $this->premiumEnabled
                    && isset($checkDomains->api->properties["X-FEE-CLASS"][$i])
                    && $checkDomains->api->properties["X-FEE-CLASS"][$i] === "premium"
                    && empty($checkDomains->api->properties["X-FEE-LAUNCHPHASE"][$i])
                    && !empty($checkDomains->api->properties["X-FEE-CURRENCY"][$i])
                    && !empty($checkDomains->api->properties["X-FEE-AMOUNT"][$i])
                ) {
                    $currency = \WHMCS\Billing\Currency::where("code", $checkDomains->api->properties["X-FEE-CURRENCY"][$i])->first();
                    if (!$currency) {
                        $sr->errorMissingCurrency = $checkDomains->api->properties["X-FEE-CURRENCY"][$i];
                        throw new Exception("Missing required currency configuration for: " . $checkDomains->api->properties["X-FEE-CURRENCY"][$i]);
                    }
                    $sr->setPremiumDomain(true);
                    $sr->setPremiumCostPricing([
                        "CurrencyCode" => $checkDomains->api->properties["X-FEE-CURRENCY"][$i],
                        ($status === $sr::STATUS_REGISTERED ? "transfer" : "register") => $checkDomains->api->properties["X-FEE-AMOUNT"][$i],
                        "renew" => $checkDomains->api->properties["X-FEE-AMOUNT"][$i]
                    ]);
                }
                $this->results->append($sr);
            }
        } catch (\Exception $ex) {
            foreach ($checkDomains->getResults() as $i => $sr) {
                $this->results->append($sr);
            }
        }
        return $this->results;
    }
}
