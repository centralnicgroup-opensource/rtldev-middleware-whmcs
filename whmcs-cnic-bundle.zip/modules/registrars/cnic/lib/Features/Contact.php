<?php

namespace WHMCS\Module\Registrar\CNIC\Features;

use Exception;
use WHMCS\Module\Registrar\CNIC\Commands\StatusContact;

class Contact
{
    /**
     * @param string $contactHandle
     * @param array<string, mixed> $params
     * @return array<string, mixed>
     */
    public static function getContactInfo(string $contactHandle, array $params): array
    {
        try {
            $contact = new StatusContact($params, $contactHandle);
            return [
                "First Name" => $contact->api->properties["FIRSTNAME"][0],
                "Last Name" => $contact->api->properties["LASTNAME"][0],
                "Company Name" => $contact->api->properties["ORGANIZATION"][0],
                "Address" => $contact->api->properties["STREET"][0],
                "Address 2" => @$contact->api->properties["STREET"][1],
                "City" => $contact->api->properties["CITY"][0],
                "State" => $contact->api->properties["STATE"][0],
                "Postcode" => $contact->api->properties["ZIP"][0],
                "Country" => $contact->api->properties["COUNTRY"][0],
                "Phone" => $contact->api->properties["PHONE"][0],
                "Fax" => @$contact->api->properties["FAX"][0],
                "Email" => $contact->api->properties["EMAIL"][0]
            ];
        } catch (Exception $ex) {
            return [
                "First Name" => "",
                "Last Name" => "",
                "Company Name" => "",
                "Address" => "",
                "Address 2" => "",
                "City" => "",
                "State" => "",
                "Postcode" => "",
                "Country" => "",
                "Phone" => "",
                "Fax" => "",
                "Email" => ""
            ];
        }
    }

    /**
     * @return array
     */
    public static function getContactFromSettings(): array
    {
        if (!function_exists("convertStateToCode")) {
            require implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "clientfunctions.php"]);
        }
        $contact = [
            "firstname" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminFirstName"), ENT_QUOTES),
            "lastname" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminLastName"), ENT_QUOTES),
            "street" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminAddress1"), ENT_QUOTES),
            "city" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminCity"), ENT_QUOTES),
            "state" => html_entity_decode(convertStateToCode(
                \WHMCS\Config\Setting::getValue("RegistrarAdminStateProvince"),
                \WHMCS\Config\Setting::getValue("RegistrarAdminCountry")
            ), ENT_QUOTES),
            "zip" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminPostalCode"), ENT_QUOTES),
            "country" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminCountry"), ENT_QUOTES),
            "phone" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminPhone"), ENT_QUOTES),
            "email" => html_entity_decode(\WHMCS\Config\Setting::getValue("RegistrarAdminEmailAddress"), ENT_QUOTES)
        ];
        $companyName = \WHMCS\Config\Setting::getValue("RegistrarAdminCompanyName");
        if ($companyName) {
            $contact['organization'] = $companyName;
        }
        $street2 = \WHMCS\Config\Setting::getValue("RegistrarAdminAddress2");
        if (strlen($street2)) {
            $contact["street"] .= " , " . html_entity_decode($street2, ENT_QUOTES);
        }
        return $contact;
    }

    /**
     * @param array $contact
     * @param string $prefix
     * @return array
     */
    public static function prefixContact(array $contact, string $prefix): array
    {
        if (!$prefix) {
            return $contact;
        }
        foreach ($contact as $k => $v) {
            $contact[$prefix . "contact0" . $k] = $v;
            unset($contact[$k]);
        }
        return $contact;
    }

    /**
     * @param array $contactDetails
     * @return array
     */
    public static function mapFormContact(array $contactDetails): array
    {
        return [
            "firstname" => trim($contactDetails['First Name']),
            "lastname" => trim($contactDetails['Last Name']),
            "organization" => trim($contactDetails['Company Name']),
            "street" => trim($contactDetails['Address']),
            "city" => trim($contactDetails['City']),
            "state" => trim($contactDetails['State']),
            "country" => trim($contactDetails['Country']),
            "zip" => trim($contactDetails['Postcode']),
            "phone" => trim($contactDetails['Phone']),
            "fax" => trim($contactDetails['Fax']),
            "email" => trim($contactDetails['Email'])
        ];
    }

    /**
     * @param array<string, mixed> $params
     * @param string $type
     * @param string $prefix
     * @return array<string, mixed>
     */
    private static function mapContact(array $params, string $type = '', string $prefix = ''): array
    {
        // @ see https://developers.whmcs.com/domain-registrars/module-parameters/
        // admincountry (admin/tech/billing) vs countrycode (registrant)
        // migrator is keeping it to "countrycode" for both
        // let us try both ways, maybe whmcs docs are not reflecting the truth...
        if (isset($params[$prefix . 'countrycode'])) {
            $country = trim($params[$prefix . 'countrycode']);
        } else {
            $country = trim($params[$prefix . 'country']);
        }
        $ownerContact = [
            "firstname" => trim($params[$prefix . 'firstname']),
            "lastname" => trim($params[$prefix . 'lastname']),
            "email" => trim($params[$prefix . 'email']),
            "street0" => trim($params[$prefix . 'address1']),
            "street1" => trim($params[$prefix . 'address2']),
            "city" => trim($params[$prefix . 'city']),
            "state" => trim($params[$prefix . 'state']),
            "zip" => trim($params[$prefix . 'postcode']),
            "country" => $country,
            "phone" => trim($params[$prefix . 'fullphonenumber']),
            "new" => 0,
            "preverify" => 1,
            "autodelete" => 1
        ];
        if ($params[$prefix . 'companyname']) {
            $ownerContact["organization"] = trim($params[$prefix . 'companyname']);
        }
        return self::prefixContact($ownerContact, $type);
    }

    /**
     * @param array<string, mixed> $params
     * @return array<string, mixed>
     */
    public static function mapOwnerContact(array $params): array
    {
        return self::mapContact($params, 'owner', '');
    }

    /**
     * @param array<string, mixed> $params
     * @param bool $prefix
     * @return array<string, mixed>
     */
    public static function mapAdminContact(array $params, bool $prefix = true): array
    {
        return self::mapContact($params, 'admin', $prefix ? 'admin' : '');
    }

    /**
     * @param array<string, mixed> $params
     * @param bool $prefix
     * @return array<string, mixed>
     */
    public static function mapTechContact(array $params, bool $prefix = true): array
    {
        return self::mapContact($params, 'tech', $prefix ? 'admin' : '');
    }

    /**
     * @param array<string, mixed> $params
     * @param bool $prefix
     * @return array<string, mixed>
     */
    public static function mapBillingContact(array $params, bool $prefix = true): array
    {
        return self::mapContact($params, 'billing', $prefix ? 'admin' : '');
    }
}
