<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtj0taQV0oDfPevBPIxc5MpvamdCCZBmox2u+fB4TLhoWkohG08RjPldJqT94s9Yry1meeCD
u7Ji/hyBtrb/n7BBHarC12i0V/4nG012aCM2ypvRCaFoCr0dRPaAHfKtRQ+0q002s4lm3FuRy85O
gQHhRNajIvgkw4GD5Z+cbOq7iQ6S3jXjMa7rMoluNgTXMZwhOqfaxET238nDKGom1sY5dOiO1fFp
aEMs0qO5QIDT+zTQDIQFc42UtpvIMYMxXZIWxIqRXP/lhvZxOR6zLnCA7abXMRhEvZ0YDRBhTqXX
bsTZZl1jP6iMh4aTXq88kCiQSKYXfgLVUEQKqXIo8rQqdf/RBQUJ6QcOpClAG7bwn1HFR4EOThkz
ncCYart4WkdRFT4+w83mod1YY/hunFQFNtaEs+HmfVt5FrJGjTFMkrt6LfRSKeWWrtUUYpziGNIM
Iya6UHEJvXPOtY+m7lbt+bshQ8Ukty27f+NaE+fEkeM3vmPmHG4rAjaORXqi4r9rfF5SysfwhtvZ
38ub5aXLkBZ3ouOqOLIjNMMeh9gu9LniOz1sN3yE2kCVDpAMY8vs0VK8nCdYCB8VRj61KQkHjA7m
4+ZJHQn7aIRVAmtdnau1tZd9HYrYgkQqqE8lBBexwD5LFqd6ThGe+I909bp2kxQs0zo0z09V06cP
3dRjwMcbWP+I/GmLg21rvBaP/ioh3KXQDUfADVnUPXG3f+MCI8FQeQPDOXTBsJHMVHBCjtgX1j6y
wOqYWbYWtf1Bw8UOgD2DjYeMxOz9mhhfVR8fjX31ifqgh2UjwS78MWv62vpY7uHwKEcCdCOxl4bt
9pGaxQzRFP2sKOH6sM5WabuuPW5ti54hAcJnydPikPhdxdlE6Zq4zREVa2moucD7ZXFoSqVo9uyE
vEKgYnyCYPPg8UdSt9eW06ra1hXAVPK9S5yt9mPFqnqN6KM1saQIbLfAG8fIVHOPMz1n7GhzYN2j
OJLFdNsMifCd1Dx3Hdhqzl6Q/KVpNK3nuvPbXQxTDD+TlJ4rC38eBsmUShYSkbOh4LzduxYvZ/M6
h1MTxizw3JvAkyGJWiKcqFeSmiBjaQk+U5REl8UWOMFws9UCrasNJoM8X6Ob9L0pGtxvJXZXpoCt
LlDiieAfd8bN0ewf1ei9eKg/V7mpQ8QFIOCfEtxiwM/INEQto4l8WZ+TEi80TOA8Wg3BK9Qs419x
i2dXsNFC+0AQnFjxAkjJs3W1YVkqtT3PGWziVUMruGOG/ISbwzOFYS3fMseZgkRv6o5XuypaP7a/
tXn7ylm3KcymbY8WzpNoDsGhio2ScfYODCUqJzJqZc60esD+WuzJA0JyDucB4rhWBhm/O1zwyglv
xz5xYXITDtK3HrKrK+kV+NWFOq5GkEzbaWgekBTXQK9/xavWXtXPMyzpouCBdoluyn9JeaUmtnA8
U6+aQlQNQwO/MoiO9qSlzuva+Py4NNoJQ0waDzJi7Yoz/iJbuLIIpNt/DVamWdf1TEptbCOvavtx
FodlXJOko0Jcf4R0oyR1Sy5MHMnjNXIwNq41xA3wPMh27Fsd2hIL8yqjpQGFMiRVnU5cFGAD6I7k
TUeezMeYPGuw1cDn0oyq4Uae2T5ZmrBGMdQiN/+18wr97+3x6SgEwbFfjdN9gNgNgUYfwc/ucr8w
4e5Z0U4rMd3DGI3VUfquiqGmctjFAeI//uZblOGa00T8nMhepNOitvL/VDIXxVDcV5Z8JnvjGrQa
RuuM8x3A48/oL7jzKWMP/qZD4iowx0R5SGSYR0+riEFVkP1Cea6UuoYJdIVoyLRIVplA45iS23BP
L5W8z8fwo/11sqHeFTtxo8FDRBSM3jVCoqsPBWIsY0BSpL23BF5gOoZEG4r0fyNqHWB7hoOTv2o4
DhquJCkoP0tuADo2sSZyNS21UeoKBHKRb/8Bo1GwVl7fANptfY5/BVkA1Wv8dtsRDA/NbHud7yrw
Y7VhoynzUbHf1plhuPZZKIt0LUO9T/ux1CQcf5M7ztCSm4AmBertcBRrFnMmWRjHTZTGyjYhxhAQ
TnpAX5l/TSn+5xtjQ6IFUvpg2Bh3Q2StrB6LiDdL9pKI6Xg+qOM+Y3a2mjmxc6sup0VrS36NqQrv
m+cHYwnO8XiAVWQnz0T9wr8lgb4Nd2xff7ky0TEBM5EUfoNaqiiWJRtdRhsVrOrFqqDZPumURJ/X
qZIvUF4RyAoX6hteDJYGQmpRH3HsITBtcDftzQnhCIVOIaYaw5raNN4tZ7KWVr3wPH9qykMi3a30
Z2YpFzg2ML3q+5/6v5jkwRpFN73fOM8vwPH3eXC1Ig5QlhbNUEqaw1uZYxfgUWKAS33w5wHOnOc4
SYIOZHVfhgQ4z5tVH0Ib15Vb3q3zEbqWRsX0ND97+XLLQ0frWHSWYnrDWd/gY2L1z6Wtb7bn8HLf
Nf17O1fv+/b7O+6SaWmOIdABGxveoMsLiK/utf4mZ1IsJXHkzbcdwcsyNkS+/Z7BvvH5nGej/pr2
sjdA6+OhqpGMKeVuVmT4oEJ9mV7oEhMM24JXGhxwU5q9W4IiRokNm2OrBEWBZytEyUT4KTExUS/1
y1+6q7AtEwukW6H2Ib0dQjoQI0DtRFMeq0aW0gDOSRTZuiDIGqI+eMY5WTEDeB5qINrtjifgKV4k
WinOe1K0TY6nbM4o6myxZsSIGPXH3AsD4uMK81g8cRsnGlU0rcOlP5n1VW2/2JFfZpCMBQkGJpAO
3ROLnhKkZYwJns/+IWWPdiucZ4ymf2Mnme+deiY/5Am5QJTfurc8/CLqoo8muZGcSC3GeupiH0z3
Jkzp7eyrz8V3MKUgP3IkAmdD5TnPK/6jVMSOxXh8pJaSlnd7BPTqxEJDimQRq1jm8MZK0589elOF
SMIxTpMkPTc/blG68ZR7ST0Jznh+nPIo7qKNClP0OqYC5zoCuvEKqsR1B/ta/UWpaPLcXhZKcxtD
dFRPAM8zlk1Dxo6MMonqJ4SNSUq5ihomtQR6mtmRubnhunvJGEEYL+fgi98QQLwa3YZAkZfISGy9
l9W25S/DFUtSBPPSO3iDrjyDDiJD0X57RA8K4YRscUAPehX/vMjuwddwASESH/LUj7fj6sNWD6II
u2jhZUfV3g7+EQX5+43Tx5IcGSswWjsfwl0EaP5C1s8FRPzvUDzVthsIXM1CsNVJ1r3jOKHh+0uJ
4bm6UcZiaXcP0vn98Vzydq0w9NanQDEcB/N8UMd0NgKVhv+CU+AO2PxLnDdHzJjWFtueby0EeIGf
siTS9gPEyHZ4ande8wNW/hVVAYtdxtnLpif/GBUCo1lcoMhXw6TWYobAezsV/GmQVzkD5gtw5Y81
hYbikivqy5eJjn9MDQqg1xuxYoff1aWVwuP8z/sPlTWwPcLxjSPZcGWsrxeST9ZT3WJt4UwlfEs8
p6O=