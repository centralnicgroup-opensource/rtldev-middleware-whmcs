<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq9TuT+33jeGMfDq/D/mEeBHZEm/bI1LTD8LlndyfuYC4qOv4mGK3jXgymqt3XswcA8HEHoJ
oB0UoJkOuN3BGE+AZRg9yzI2YhEvWcyORgaYpCN12UnaJOmgWYu5zz+SYjacuYBcHWS3zrYMblAR
cIyt1Wq1ZIovKwSGMsnw0Pfi4dMlb2CgulYg4T4QIeYv1luabtJuw0XZZhx0ZgMslMR0v9LedkJD
QHvPXJxNsd/Io/aFsHtq6kpHMeBq9uJe2Yz8FWo6K66hKrE272ZodhOOIbtSPhs7OjTPH4BHJ8mO
1zW74dCAUihkS4mfJJ7DlBbZ+DEDqsjRj6I2UvOd0IjK8vYLFPYsfwy7jQEbi4guwPcz/HE5APnH
abG+QqF31y7rpwc4VRIALSIXRXKCSAfPozCzpLRl8j0ReZSgxOLUuDCzSpqHr4BVZt+0pUHpJbv9
bMCkfdHGag9GONP3pQ874i8GumlSiAhIg3CJP38NwvF7z53asFrAf+oBpPOX57Uqnf6P5jpm9rrn
39SxJcVWg1u9sVViOV8lBc2B4knFViyNDPC4rnZ4A4qYvXueJbie8eC9c2P08KeO2bUG/0Wf9H95
OZ0tFydK3eEqm6NBBXH9xoXIn9oVB+2oXjqUIhH/6j7n+5LsBy0F/mGroL+XsLgNSIMxhlWsvvVQ
GGjlwlxj7kKZUmELDXIeWFUk/zoBR5E1pQ9zqAPTw92LhW0Zjc9wgZCCJibSzCJsYaCr9oTFhgd1
e9Q75JNm47/6K5bxGYatBgOaX4slXz/2dAoiJfUOhPW0DMlM2DqK+ssLggOgS2hFL9cSVEzSt94G
MvTY8+NjleVw5GuXmP3d7lbtVrK/WZPn2qDPyvNt26qUUmtZTVygM8z5Mae5sx7C0OJgkY0fFszh
5xrzDQ/kQlNx7paQkaaXIPS/v8MT5ZWga7iL4qzivTGS3mR+ZUZPVy3Jn/uIHNfGOixirhxZUOSb
zpBFgDwIYFPl9bH2U49HbyCGIneUmjFGa3RhUaBrmr8AQ9I9J9eWMVzgBrqvXQqLq+6rVH4Eq6ou
TCfgm4xewojmrjp97pdWZDqAYRNTb5SvTWNkB3YEHTSEQ//uEMKYy3kifjya36TRy1CiYIICrdmJ
WMuhXyXedUQs/Hhnta9iKDD1zfJ97uBjTTWaAFjJQz279OLPdY3+if8uu/WLxpjtf3SxyVDxL9DC
e5q95VeFg9wL31iaNBIuAwxhk7z7PdoKWXobfscPvdOxflZxX3ahZs12UfCA7I5eS1w/f9w2uv9+
LYyJKo1Jb7pxGcZwJlYyFloPA8oyYfEXlIE70xsD2ZA/+SLq0HEK/IW8S68YS5VQJi5N/xpf1MBj
1u5bzBiDT0Z65mpqRXsI/I7ztnYJeHhvxcAooSLFN4bcBniN/O0ZW2szCWlHcvJObyPXcM7wSwWC
80dCRhgEg/oinUIxIBhotgL/GS5scyl9JhWgtAY5P4SLLUzbgS6ekgHXAVIdfPR3gWowT5GnkhuI
IlR6wDW3DllD7ThejyiFKYa8NaqvpoTNOMBaJ904w4BlJlC0vde5SWGeqEoBtaorP2kirvW4yble
igspa6qrLfMPyJ8R/vYR1ySNNMmRcIdHDoSASwUJ0UdfnODTB4Srpz5sub9oTJqrjq4DeQ+IgQAy
e8hg2GY8RgpnR2+XEfj3R+rTBijoRmR/QBnolPZNJIJRcPe/5kUMTYCmPBFocDkhCbsRw4+GuEs+
eW5X9nSDcmHwbq5dyZ2NxIvOPYBANJv2ocUSamGirYFxSJPE9kSfwOXTEq0a4MYwIuPi7riAzwWB
uLTgtV86qQWzaI9LQNZv9XD4pnb+E0oH8FUa4986o+hLx/8P+aGLrFSX3IJsZNjOVZPmfwtRD6nj
nFxE6ktBUYtvigpQ6heeS4HU6uFT8Fkba0Rh5JcvrK9Sh/YRjP4dQUJZ6y/bt3wk1321xmiX/NyE
S3QmM8l88CE6mcj89d4KmnMi8EejncOOvloUVn2YljL1hmSX+C2P4sdoOW0rqGURFH5yRlzCfhHl
OnAig4XoAh7HYe5L1MlnRuA3IYtwnFK1XToaoe0G0eZeNSeG01OdHBN7/SeuG3GP47TSVN/4wGEQ
qIAIJITTkBgXLi36r2H6g4BHD/yGuY2Kouwey5Puk9fUQtrmHjiwU4c/HFzRx2up2zrewaV2l31b
yOZm0o9Mh/7jN9Ob2Y49Z+ly5jLjWEtVvMo70+AMfwzPwx3TWOXpbkt7a3S9kuswD0mbGBbOw3je
mi69STv83Fzf/6uwj8EAbQRliZATuVOEf2lvOSfSXepC6Q6jU0MN+SxyiyfLMq4nv89GAooqIEii
i0wcp7DofzaQAt2oznWJO0XHqcHPJQS4/wa9KnkYS0Ft4+VnariRwELnPVInT0AdFhHHi4AT3udA
dlrbohzw/crKTxuvuLMh3nSajOLUJX/MATelvQK8vkBRXodEQZWzYMcg3Yw14T/wO4f04e8h2N3q
psCwnaLY6vB/cY9LE7HJwf3RLdcZIgxAWG0eAb9zIFmtkbD5qM1YFMh56kvvmlUof7/l6hDE/JAX
DAELHevraBXju156QCRGCSysBktq1RyP384Tn4tOGNbqBbyZ2omajYYptywMk/IP9Gdne5GFzzEV
Y0qNwGOJ1lv7N2JnqlhbnZ6K+DT1PtnbQCfoA2IZ18HAGgsZy3wwdNufNI/CzN9VYYxhM5aBzMIG
fsQRk5ftfxEPqtZpdnku5NiraZMpLy9zmzS8SvncvV7Ji0hvwF0jVfy0QMoarKqL2c2vZIKrGuDy
+xDPHzsU+DPLskJqRGj1Zzicrs5G4Z51e6X5OFGaYR7uRkUq1WOFcBDs2olbTmsJHtzIf9T3EJVj
UmQV3HesCJu5YmQP3nlcI9Sapg+UQsgXmj90AnQvBJzAnUEMTOuMpll/cQQNIUs1lHPLPj5JnXwp
xE4fit+tWc6OU4orPmgtznZHk/kXD9aQt+7jMTu0VQ43SQA37xVg2xnBeg9ZKOzFIwR31llR6jxe
68KqT/e0XBSzJwSN3wsZn1N91uhoYSP7FvPVUWcbWWLcOlWkr62QZaLbHhouE8Y/oJAPaNGLWK9l
Si8wpdbp1Lxo4D4bgRmo/WgbgJ5LfbTA5t+oxUEIufemfCKPHL6VGHVSUjKsvDO8iPkPOfrE1xN4
d5GC6wpw4kaxyMzy7ujIh7jcL2/VJbUVu67KZMA5z5kAYdcKqOLlTbl1878Q2RYOKh5k6IbzJJCx
HOBg2V7LHuWpj6zHUbXd+niqI0FWiRI87qGzrPu9nBa2taQqUdl9JCdmAQlhn5ZRqCzeptcQmQL9
KXl92zg7y+LlHgpa8/x9fJdhKlaKpNsu0SNAMdXI8TJqyR8YqXpRROHysKR3pbICVl/MsCOqXzgm
j+23rLO=