<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmW6V4sInKHZQyZfRWWFUVdTpNs94uTgpP+upcXjtQqRVbgEButdN2I5XzT0htnSRKz+ZB5N
cu2JL50VUjwstxL3twatyYBa7WCU7rDssV8IsU5Z17EfgoNE2qJ+hhpheQsMyb5t84nwvQ7EJCMd
L4N/+sEXdk6YhTtDFakkizDriaCBCXydg2OrTt7N7KEPw8AxXh8sb8JdvynGcnHZ8pUftjtQnYgr
Yywl0xCS6T6hmUFbqTMzvAl35jbmWg40IGH5xZxcDrKHnBWZAa8J2NHJAnbhqbfoxRYEulsU3Nnz
wWT9/+qPbwCvJa8H9xZ8sasq1gxDwnlZ0D5DUbj0mWGcZUmb4e79ZJrrvZbNnpi5C+s9WwZB4Mzk
kNOpn8Vxs5ftuLPwOw9uKBsFTTrj1Lxw4ROUL6AdWzlNy4oQkE5TnOYrysgoTE2SBkPKGBObxXcW
WqGV5EjbdASeuCj6qPPZpxDg5IMrgYJ49yG4pQrt/gPWMuOMUCTURliuzo6cTOnTw0l5vqfSAT9L
/yFFAGe5CV79zBDPkwuKHz2jEXtk8PQqvqFtwyRiG3VHQ0Qbn87/c+V2K3MqjmMXRxlOhFBKlS2S
q1XLRf21iRUhondQITRBu8dg9iTV5PNRQ3vE1jF6RcB/tABmDWxaUe2liUJ5gt9h6H1qFlkLDuBp
6vAfevL733Y0lQIDG2S2CoCbtVKpV9jUIJ+PlBxS6XvFQUZWvo3tT6lMWhUcFWLbbwtDYtij07vD
WQSdu9xh4DXUlDzu2ihiR08m/1S5H6VRHLvRi391Wh7exmB8y45yW3INBYccNxF2BNCxdL6tzo1N
scq3+Bs4yFVqqs319qrpG2xGtCNkUQ2Bg2Dan1totn4FLzdGBkVjdxpz/VzHEH9FLaEcJopO5hvg
7dunpadrBKZOOaSTV0nuRL7DDa2Ssc0TKZMW1DvxYL5cryfccHahXEggbugJ30i5Xcqbn+UJyZeG
NtJr0//SpolhNKPWKsy4mcwf/FbNvzLuftem9QcUpWP3MjwqhvoXGU0O7JLgMY50BK0qW/sYovrD
MWWvQYvB8XPFFqr0sZd9zriiua4n/2uR8T8btF49YnydR19WtQBrMQ5TWJkI5/ROK5zxdIrEjRxH
8hB+ta07hUN2FsQ+b0IC2SSjL1mdUz5NwwSTN24IcBBWom/o59Y80GSjmkYdklqzA+dvBRCEb8eE
cczgrXgWDmkaM8Mo2ZTvuioUq45y6jZIstECUNwMuPhewn4mxbpOTwrJALFyhHq4+iXdcER/n9ac
vrHf5ZztmRpOEFlngcCo5zYhhwGZZnFZTWkANv0IxDSLBzHf9wumYtJ4vAxOqwLkoJwEc1LwxgBE
vehU4HCWmefdHsxg+hD+wCEr0SZbPutwbT0BlDtQM2RdBuO92xpkAVuR8hmSp/C18IXxme5k7D2R
qtDq8DwpSxMofmb9WAz3kEqmING7Z1ajUU43RBZX9rLxRYkKBIPupUbTXx1hB7oLC5E9Lq+BDx/X
NaLKf1zzFNcElI4ChEv1GhVPr2NoWDDQDY6Buk7sXoQSu5on1XXcL5TxUMwojoeHwnClMk6Dpgw3
56Ezf+ko/11BWst8ich67+l7mrO1+Tsu7csXEP7z8w150G2XldMPG4fdUnqFYsCm4ZR2DLfRCzYs
alZlj5RQ3mAXfc/USjWlfhwVgL7uzXrrSRLPzITz4MAxs0cQOan1O2JtsfH4IRtJLu/nEYXju4//
MMtaORO0gLNjvrJcQ+deASX+O0X4D5cbzcZ935lVxQ1m3JO8ttoGvgCvOFMPbW3npPv1JZZiqtb7
VYLSQeOIYZfZ0qWi4nq11j55Y9kqofze4cKw7eXaMnTqC9iEs7I7KX1DVTnYqBh8Hldp1Gs5pML2
ybm0QLUS2qx98Pz0Lcn12rOS/3O1Yr00mp84MMUgCuMSR/E6D6Ep7zxfYRM+FuwMwTbrG40G/gYw
slUEbZA+ZzPs8EyPiVJrUp+zInokHRmS8WihYpTP+vRpLkmHeELTP2twOlzqAbMUejh10mB1idC4
JGyTIm5odbiI8WVCm5lNoIm83sGi4SrpJ2pOEsbPM2dOxLkzh2umym+ZBIUi/LQ+nhdGoLisrbJd
mVHs4emOsZzp+PIlvDj0ATsmPFkWxs8oGtvdEV1pyMR1yxmIbwF9vN+HrIjDpMSP3KVHRJ0I5+QQ
iqWtnnP9M1kLWaxwbYGrfgsRfuX4ZTa14pyZGSfAgGdFavGKaHMrgKCxI9Bks0ZTYv+7hyv9tYtf
aav10S2rfMl4+aePT+x5Xby5HQxdIqXkHXiH9D/YdWF6AMrhJ66mhLdGLvkfnwyATpdtrWTnZ4YE
IVxDAvpoWJ4URFVYiqv0/p9MqOGnxWEeVGC5SQgHHtsoSwlHdqUGePk7kx+rkwWVIORN8LX4wUsT
IDI1yfZ5ozBJaqOETSjm8Q5IHUxFqkxnCpy/re7yeR5d8mCIvWHsIIwbVj3urZgL5NlUkDSntl20
d7dz48iWDmf5Ki1Popk0FV0pYo6WfBxJijpDwWTyF+lq6Y5mBjFjNFjhomKNH9C0W+e6USAnqsU2
inr3OHCfmozDVk+kibcTlZILiPThHF40uVq97sNRmpzc+ym2e6LqFYMFNY0bfsoHjhPfdWVlr6Tz
asGnsiVMESGbNPXGOieQonx/XaZXwKIbk5r7NAicXxzkEgCpJI55B8OgQ4v8ch8KfGIxS2WXaXaf
FQe4M14O6Z+SGVdw/ujhay6ndSRd1IINxelBZMoDj+7g8+u9Vw0P2R6BtfYjlGFoWESGadTJC8bm
I29FZYmWQEMsI5CbIe/LBsfzBZTStPQotXBWmAIMX9FhOa2rPzZeQnEW420RxHbLCEPLXOCP2aRb
xGBtHg3ectLrHJgkIZJXJ11Lgxl1gbGTwaMrhRIwubE+H/JANVlaivJeIWYDG7gbfHBagLYQW6rm
JQI+N4MJ8qjUWe1CXtIsZtvDj8m9QHmKV2oDZiiOR4fTIHAJHktSjyUcH11GJn2uycCkpdI+ZeLg
I7wtOldt4H+ZefRQ6sE3X0xFTDq0CIbDKNvk9b/ciO1gfnRg12t7dLRBiyJlOH0Msm0XQZJ72vwm
1t/gXi9fUv5R7j2gncJn+Wz5vTmcYargV0aE65HWl8la2bxPeEtokIhv6tb+WJ9Ch5waX9elKQZ3
ZxSIMEUu3BB5tY/CkKiFFz87B1gzrUasjjkEGwP1WC80a9nTeFCXY+Q65dWbf1thywVhE0GfgOu9
mbopKRrZvPb3QLppjku+TwE0akf9gY86ITUW7i/zCe4RdKl+hjaovIpPEhb7+saNGzJlMhqNHODd
Mh8s9TjsNOrSUHVPpLTg/uVZPIq6v3ANVBA1+Cv1gM1V3qmqCoowQGPa4DsfBJIJeyTzBm4=