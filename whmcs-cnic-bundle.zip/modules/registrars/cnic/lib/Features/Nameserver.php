<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw9bW0wavtWXiQiLBKmoJjgJHkMJk2G1BDXCQOQGVV/FcMEO2ouggMVcD6e5S3ia2JT67v7r
kM/8l1W8UyU/+2HkoBdnkYgGJ/vVtVlZcAN6VJDXmsWGHV/PewDgLuV6QTRDTOSREurhOLZHkOtm
kwOUE8K+8ApEh/dKqJYS0k3Hb6Kv5ToyiO/bsRZJxY4tsM0WJiQb8RZ/VywcmiB8Hzl1JqBZLdFe
ik+Ejkn911jZteRgQeyGdH3QDFEIbd6whyU+1WM+N5EDoKg9JE/Ip5cP3c4aRuI0lHYRIGxMHoOP
YBVdMHB3keQyw68CBz3bEzQ36FxRiUkPIW0SZZ5zjbN/Lf/jsw1LGnXw2V1t9JDgDW9sz3+BI836
J2UgqZLU2T9qdjoWE1WOTna5O5dEaTG0X644bDWHIwLHMI/we1p85XMCgK+dUQ+csVXUGqaGU8IF
7f4HuOgM7BRsuvNa2vMk/SVFWPjhbOR8MQ5K+D5nTvh/FsvWENpvR05K23xaP88plqNGRuWCijlI
FSC7t/cwrnPWQ++99bwySFi/+jO0RIT81yZqVVuv2bdHd3LlaeFW0iYZDToyCX313opLbjpBQkQZ
ZSf58w3nPHM5K6b5FbXhyC1ua9IUNfngLzrOJ1D9YzZZiuYt0VhfOj9nGeOz3llhzLOa/SNxekfR
uSc2zIaU9hRwUaSD1nfyn6QWqkBRi/aRHZLuZ8/R3zRgGmq13wpGId6k5mEGwRh8rgzw997aMLcY
bj+OhgMO3bKkK6ucTaLyVuUteqdUSW9KdyOOGTslpCge9TXjION6vFonnwLVeMO0TjTijC7BkNHP
iLe7vago0mgjkRIYOiFWk6uedpCjZ08cuZzlI7oWS9aYK6AZ3sshlsg7XS7lppdP1VgoTZ3eb2el
7EXhtYd3E5IGu33pMr0kfwXu75f261g4BnsUPW+sbtwJdSOi8394wptOsmgK6ZNgfpRMMfZvKRhm
4hJyQcZ9HXiWO+GIRNbUdC8ibYsQk9I1WDKALefguZ5rKcU/HTopUBve5WcUUf6U1tHn3+rYSP7e
889OIBj6a4UD3Vy4XRj2ITX/mP/PDeixmPqFgAoDXDchBHwX1QFvG+GXs/sC+E1cSdYjwTCNJrVx
iOBoMZkYWoZdQO3ubF/Y59l2HnC7RECgTTKcOJXu2/kOG5kSAPtTe1TkMfx2zlL3Mfildr3TFhgv
vGkQnuqGTcILMJ0sdnuPQ7+CUUdlY8OmCQv+vkcuxF0ooJ7373+IWhZpxxsQAaSmL1s1dBxTOo/1
OJUWvOdA1AOFixx2x6F8Cj29+1oQamUT2CcU1kO896zy2/CfUxi/g2tpLZisKUFd28XvISIM50cK
TO0Yy+mXNRaQi6OLQXb5DGiw2Fk2QJIbJKZ+fu/4MNLvC0+oGBgyhneHaRs1/3s9lxa+FewfxfBM
tai5cmCmkB/6A2gReHkH2qd+/PSUyqWfkRZQ1L6GMvKZdTWvjnfSUYQRMJLztVIHY6C6PiBFNmF/
ZJ8IdXAVvsDOKVtQvf680ybfsR8sSDdh6SnmQqcWr74cJYF4wG5FUKeMs8oUC81WxPuPqKD2OOF5
DuIQZUs6C+35Hml1qkflI/DjVlyZYUebEa/r30UxmnAsf4Hj7+85WIQBX1oGokM4TFFX1qfnGkpJ
aXTdJbJ6wSIFsvAOD/ZmC1f7vgzb36qvQIv96T+4pRssnTm6Zaur60HmLvac+6uUTvCe5x+95cro
8wWafyeoOEMLpEKmy8MA3PkVZMSBL5JtLLb/v8DHbGJtO1/W/QL1zf0zpiQzu9Qaf4jvJ4oYdlhQ
R9c87HBFyIB3D1YCZ081G2WVGOcBlEAGKJhsj4/SXyLoZYKASpPOkB+oV9eiD+5RhnwMTygW/X5+
ZSSS1+GzbmJB83QSidH8v2ocBLM4SCN4xgMeHRasvJvME5qfUl1Y3jumM4VLvn4JpDa5l9oRuMfj
XedBlmTazuL/8uhSI/LNinfRSwPV4xAhfMc9JkEYbBX38UnR67FHNiGksXXKoU7WsFxAL9hnpS53
lpUoE4k3B6w+ArfM/AeEp/ESdSTCZob8vhp7zoXIlwavE5A0OSlUks0aipycTklxn5xkC6t2j5+m
GCGibTuNhnZZ2SBFtANMm55rJF+H8OH8QktYDTIsNc2S2Xc8eQ3Tk8+QHWceSwqXvEKEkNwV3YJo
zv8Z+rEf0UsD1djWvIEa+qdgLf+Tz4GWWHnNNiy7Q1cVwFQ7JXATDyI1+p2fReWm43tTyZGVN6+C
U0Iu/6FYqrkCVAJNJ/ssMZ1YkwHd3d74mBZ0bu91Y5JyuLtVzbOvoVApC63FHMjHYhUpslhvENmt
ZqyLO8ftfLQLQvBxvihcxNMUt4HLQmC0s4JGkqLmYf9Ha/QFu4+KT+3lKVzrc8NMlIUajTD+z8Kj
eVt4S7/DBqN77q5RtsmDVCYNkIani2PnTEX5W2YET4weCfkaVL4NFnez0DjKjsfdra/CZWuGlwjD
rXfRqGao8j+kk3LJuzXVQpblsfJ/3CHR0VM7viRqfkUhr3T5NBfvsDTj5Jvzg7oWTAuDNomabZRK
5zor0hmJhoWRekhyU+sqAM27q1K2TtBYs7OBay3R0um2V8uX0oekH41J5iQbGyFRWk1YO2O312nE
ZNrVciKJ98UtY7WnN2Caj4Fev7EBBZdW1/dC5Fww7zik2QQqCZvToC0T0Tj+wmQl8mEwkNKAKR/s
oYDN7zOg6UDYNXC1eQSAjk68EdU4YtXnJpP9C0jI1KOXlrUIW/cPcmzIFr8sDMzRBY/CCDgwLVuF
8Otvyh6pvlr28VTAGwWoI2/Dgq5/acaNXitNHQw8gUc2Xcq6tMnDvwQBOc3QH+GzTwn5hrBZ4Rqt
tbRbagHzu8qd4swVoGbfePI8ae8/xvYFf8PYUlyGUTElmEZpsqfxMGhdvskj4O+HSm2NpYiVDUcy
8PU1FoypyM1IThC22jRCDVj9eBfVvkY3dfNCYaaOI8V7zH4JeE0NrpigjmFOZTt2pgwLeZXKHGKN
LMDZtdGpBnRHu9xMYZNJJh2ywmB+1z8kpOVtfks+iADtNH5xjHoLUXR9+cvux2O8V05i5TNHA626
rnhenj3mKc0t0X1HkTA2/nvvubuwW4GQllu0LLB5mbkShYBczcOZ0pxOMuNE/lJNByG0nqNrBrlQ
YhHARWyZSNOjI7LtMt5SP4RQM2vXYu86lxDlruH4NmeWrxmRQzyDQBiCUcsh/QJcZk0aMVqvZV73
eNJFJt0gtBfGBVZs8PEklD9xo97abW1M5A+TP2iOsrjd7I/L+iPuek0wf2CSqPklbjxMR57xBcKf
LZxQm/b3rjyTmcdFyQ/BQsgriWJU/D/AjdYVKCuxmXB5G4bAW0Di8Fy+cq3wOCLnyR7wz2exnnyN
qoDMzTbxEB8Hb0wh