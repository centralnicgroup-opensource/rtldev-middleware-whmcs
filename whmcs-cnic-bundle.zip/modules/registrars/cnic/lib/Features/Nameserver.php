<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuQwfeNwBXkgWtGpfjC0L8hvjiOnn4PlfECMkoPiQX3jKRK5AeCM3zkTfg4x8tPMgyGdnHmS
jtQXDiQb/3iqiD41qWoIOdy/XOzOdK8vU8mezHuoH7hBcpFbzW3+Ig/4IHR2VxMsrgn1+aecucFZ
09/T2EEniQWE7DtZFvV0HEsPGDRxI4yWIT2eirySvL0OCQRpjwTG0DGjPPaW7/4trHAx3mDGGjHz
aos03F5MYRqIpBLyH052eaupN/TSwglZsnwypbjh/ZTnQHUf+IY93RwmYXaSb9JrPvV2mCn50J82
ocsG0XhdM/yTOPZe2UjX3RTFHs/yUin0TC12Ic0xpHvBtg+x8YlaiFJOex3Ixl6TdXNrXUtzp+uQ
x2A9OYuq7mUIgaN6LWLG0cVM5t+EO3zfoHmanBXQfGTBffelP2bP98/ZunFnPt7P6fnfKKwe2v3P
WYqh+JwrIklOu7r6+wffUrMYRNg0VkL+47zTHKVW47rYVvirLG2AVmNch40QwYuSMHx0r8ddRQk+
IdNo+h9azOzz3c3f986hLJqtHE1btfMtqNxWT4Gt5gcUJcoOS02nSXDc1kRJz4Lp5QqJsfUB5AkI
43e+CyJQZ9XWyd5IPsWJV9DYAEBf7iPQUNfiG8ysTAzxOTKc/mSAlRbMw8Duid1KqESv1uio5MlZ
NeDxivPy0qyxe0J6q0wojMdfNnmKJOFbBgm1tvhd70jZmzijy8oh4X3tTQnsJcsGApGRsffuHtbC
I3yDTC5LtWYYxcWpPXkD/LTxTGvC+xQ90QuC35gzV6CNdjmaB08VXNHEKIFkYoOoHEUVIUatv2/j
cOsksZNH02RLghtTlcR9PililrIIuSNyoNyK3YUs98v8jd5HZbXlp+8MvFZWFde4JNZlgHjcBhCw
QYQJYFxClENPUtrqu9Vk5zAtB4Po3Nlk7gHmjEtmZvpZEpUbDp0ASMSxEsF5pwdiCEubIv1rW4qX
xXPGBH9NUmc8YUjQLOWYgArNSpDFhjaFNOqohrTe2+hJPhkK5Uz1myfHh4q/Ibc3LErzuayUHHqp
M3S7d1XWyPxlSgG1o0sPeCNfVgR1ZfRfNqDL1Wplg8DxYFAd6Cvz75/ecb1i45DoaBhm48x4g/nT
n1EHcUw3Zl5rc/qO/DOWnTdIPfWVI/ewMEzBIfGHyuctJHWduwYVtyml1/09T/S3G0arcysTFt1/
HuoDwaK45EP778MUEZbVCn9lcLlBjKF84vQQY0sGbUYILWpyGucE3Ua/IXzNj1o3uSrJQsxBe0zQ
WV4OvtJidVlmmueDNh+Q2oSU87THlAWXWEYn8YGng6fhKMRH5Dj1B7z+yDarvWfROF/jGyjf78Dr
/2qHCg4npN1GIqw2Rz6opkI8QsCBV8M6GfHBv3tVS5jKHj8lvPfpK4QfwH9qZrlsa7cbffaP8ndp
+2zktRocw0TvxFGuo8VprzssshIjAHzau1hhMtnFAXdx3Bk2G9Eu5y/uPezzmJdLKv3vZrPJRvEY
7X+Zx6RNV5lvvOSLRfydxEz4FJ2mkywcIdLYpngPeArFMRHtNT0Fz0u1G0e/vS3ihVf2Tg2Y9v2d
CwzasJI+XNGYHC+/CU7GzANIN5OTeyjSmw8kGifU4hJughh9sN0pYvU8k2t3/HpXZAcadwLHqOkr
3J+YsN8arFAGTxnvOTRKSWP/ZUuCX5ybcwqB52+5v2slus6myS658RzZCFVH14O+iHgazZ22vOXE
vJGS0HxtvCojt8hg5Ti4jLPiTGBRose6BQmdCoua5AUkYO3DnZE3gWD2LL0H4tFZjEYrg0Khw2pu
WHbU3IpzYHjCNWB+RQkYm0yMntN+kTrR3+iwrwhPiLTK8wVygJOSZOpj1Xsq5MxB9YEjVVTUfO+k
4AB8/RFOLk+vfgozMy53OOOE05mP1UE2TZxZuwHerEpV8bc88adO1Dm/mQzOnaslTaRbsaKHf1tF
wBLfkHOVV/LIX1af9srcXogHkfZRVjun9f8z6+64YKIKktGv+iNwgN2VrzSG3TXnf4NZC2sWs3aJ
QSKpwnx2HIelIR/MomJGeswgYfb/TbF0xHjVLBAdAX7XdUfqRb6qHhOYvCSagksbfn3m3aQjEB5i
ysZYAc5L7BZbpFwdJbnz91wpYbM0xI0kAP0gX/8OiPRoBmK13ov//v1+k/8Y7eHrdPPf9vSNPyU2
rHyOXVuIeXmr7wTRgKSlySetbM7ooRa5aREhnrC7/hQecW4UZM4JfB0dL30fPl7zlA9wuiTjskwY
kbssb171Hvde/0gM6TznRxmOA+XaMBYcnY3/a/YCjsUb/WS/P+rufsY4yPQkX8NX9V0Eal0gZQUD
7heh/No8HtASEvKVQmM+BpMWQVNhC3jR73hTB5mtlch9SIrGOT49UXKrduUylvQku2uA3CGJYUYq
nhYHxYtPfctnObHOWFUeKrhAUznbKTEHkn4TXLuCtGEW1gD6K+ZTtzWda6KtLWTAU7ZUfbLtDgsH
GdTj3roJVssm4HDSyzSrUGPDYzJpP1YLmZax6Eutie6pBgA+CrRgZtPljxLZ7SG9DrKXqHKDrf3B
qDVL72dfvir3vsMpLcSnbTBESZNc6JFsYaJKH7x6ilhzwrHW44NnCjSp7/GeGLjA0Ko8m3Ou6vV0
IKNZ2A1ln7a4EkdRsXrsJepoRf9iyVZaV9eTCHQ00J/x4RIqHCZjDV2fV3PEgTBH/3J4NAf2VYr9
MfkL5sHyn9Lx4VhPUaGD/pVYzii5cj5o3+NWjwNa/8HVWw+Pfy8QgW3Hdg7pqvtSyEf0NZJjEITW
L+d6Xf/UuhDeUe9/cEXEC4uHaCMHCr28f9OpQ1Yjd6IYaCT8oM4tyo8ZT+zoBdI/54r4DPtoASX5
aB2Co6QpBfe+sCjQTTMaMz7G7sepdZIJYSoPF+LuX86b0KXYWzzt6AIYwi04mptvZ9wL0CJ/sd0G
La7OpKxNukFc5W9C/gBwPk5htw19y/OClyBiqlu+B96kMF4G/adwH6x7jmeIV74qKdMGR1MGNLNA
azXhzqApIqKt3x6p3pB1BFKSa4UnviNGEUC/3/CVvIqCkS99cV98kd7OJI7BU/0zZJf23oOxgtuz
zpbyaRqKFVrOvTGxVbPMHO02z5v0sLcNXL/lomZW7diKIJ07L2lgxswooYi4XWO6tmXpSdmVBjkh
ZoXXiZI5+UoWkkx3C0m5IJ8iqB2DWWG/KvceagFwsXRqfoFkKtQ5R2HwMpc+XHtVEVzP6xBCr/HN
s3zmabQOuod/nDIVdrqw+ezfkriaMET7bg1hz5w3DfM4MWe5sfUl2bdZSmnZjKpGtS3idyr/LQUp
+F+RP1kdQH6BlbFmU3zvAtCpq9Y1zKypkcvnnBw922rWLmfCa5z93rdxmhABZqca9ta6hDpZJ8fO
e5w3A6aQk/2avZjzecJI5ieWLm5gjN+JgjW=