<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPum2jtxSnWjncSmYNMm5sXsZMdxl36+Z6CmUp94B0ohwvYSOJDdGDvkhJvbvRnrbYTtQhNKq
peqEtbamAxRqFbHEmT10WIKT6R9HVrRqBn1DEZ0CnOJj3096XCPv6ftGwdtPsTstJou0bAdXdGzo
7hXoWXSBaDsXACs+rKOYU0gP4Z+T6HnqJABngxCroMnKeI61mfu/sUm9JMyO134Q8hFy7HIw7nfB
RfY2rdk1qEUU0D/KjQUx79wjC+fYXqfXhYzi6AF2LTKCgJq4gYZqF/+XpxxMEMFyX44rnREV3xRX
47ZjnqarjwWO62JmQ4prWA+jWLG5zgGn6/ACrvsj9bbT59X3+a0zH2xOZb41u9HlZCdPlcoPWno7
3Pk9/oz1arvzys5PL06OnGZCxGBN0FbUYP20kM77Vg5rDggrZf5UjfvtsBVD3YGp1JB4Szz7IjTz
9AYjGyJYM4rPOs/mIswFZKzyGFwH7o/kgckapY1UsDd/iiM8UJf+xx56KgrW0G1pFTarHP3kV6Wi
KLhUeRMzT7a+5UjJzsCNYn84uXW2tMmJnrb7j2qG267L6xmAmdjQUfBIYotgA7ganv59WoDgdof9
RTjgIgbkfsPZZapmWvrztcihX8y4DZwFcJw6ZuyQ70hXdi1UFpz/c4S1CV/8bUU59RiCJTfgwNSX
q3R862+sYRJR0gf3iJhdKJTDJFSe/YmU6iLRd8LK+buXX7q0CnbKKebqXuES7y092S1BlTW80zRW
WAvyjlxHDhee+aR8IH6T0Sqw/s5ovfnMcTHmuCx3F/DvtFnbkky9GxywLEBbH/ZGQh7UUv065TNS
2ghjuY7HLNm1WVh5m9h7XbRcGd8mj9T3hLwopaTCv68ica2iQaO5IMgpcvotNvf8H2Wh8BnXLK8R
pLtAZBLN7nLZ+FujVBt6W+e8Io0kp+qrq8uJW7SoEjeVBuBI3WTqoydxwfgz5CNaaIjcKrbabyqk
Rbekk497hga7+v37q3unJ+4TWFTmuax97WC993NJLuqnP0RtbeulT3rbjOiPPDOnsc2OAHuGjG6P
MV8W6dx3TBBOsfCUMHQvRyAtoLAlliymmbQBQdul7xNBFnAqnDoHyLes43NrlnHwiNLnK/NSnu5G
rnStXz+GNVE7Oumg4LxNHEIIaVxYAMXiCPr28mO6e6fxFObOddxtcjjgU51l8KXMUNhlQY3XTq7s
PA6Ux9iOLVhwf8DvzDfSHXEfxzZPPMTLhWPXHYEE9JIH5oRVBHcdxwcXXb9ao7Da9o8FRpgfnDVe
DrOhPkMuohwpClvzOVRdbcnuZglKT9hLg+iH70lbcLf2+1v1+RZv8tMhcrOzRzDnjqmEL4tdhHGr
4IHyFY1iKn6CUtKth0kyLFbVzoWUHwQrYoF4yj5d4LetLQIFqCkUdAwV9l4nIc9iVb2ZgItQ2L8r
m0xpILwb2wr4YvN63xZmuaYsazqiN54FvDNOQGeI4RX6CHDMZCEu1ohh9CsCw+T3NyTLkl8TDCyI
T6xCyA3e6crfvZYqjzP2p4BiFpIZVIMtaHK3SopaFq4WSE9dEWzObLEHprUz1XivoGPoQQB2+Ei8
CtiO5WU5gRVhc98d2rOaXjTGc0kuRIYCxa2u6u4wfFwUSCqHxtso20PvSS63cOoCxgoXc+XtpWsA
I8pvYMs0H7MJ+ghAc3x1cl+DrUxLvTE3QUoZ1QCBBQKTaBIbvyAlnVQfNT7QbKQTlW6G9MezqXBF
YWBtkhs6RxTTCDV9nn5yhbI1NPK8pPaneN83LrjbspMmalv3LCmlbqss77wLFb/dzjyVSJqfeUAj
/Ftg6H8eR3K3E9lsrNKvU9t4NHfc2ABXPkKeZC6tMdRELY2c9ENw7OUDCm86DOkkmf+/CD1rLfx8
R3cX7J/lwJSY/mPmFH110jHMGKKrXH5EMsviosNkU2wXddavHfzirpDQTOhf06cVEWjSGpDbaE/t
scLLeOxo301fkFJJt2BTOId/zBDFUFphQyq2ued6TteMGbIGjM0AzQ2kKJDO4dJZ0wxp8fkQhh/q
I1Ck/z0S7nbx6CzSqoWm6EnvX2mP8OT3mPPpIlSTwg+px6P19g7AU1/+B+tc5ZuAicTZvVoskUm9
8qk8RWVUPBnll079wK9I6DcXZgLspBelZmdROkf/a7xjkKT2HkXkyCR8m52gFTy11oH6LPDiBZKK
awUyX6uzyZ9zaKpoWGalXNzcxWGtcyIrZSyK/mFb6suP+hlCmiInNAPJTsV43x03jN110hVG4r2t
vPZ8CAHpzkkMtwKRaVsT02uRxitaZyJqd3cfGLph46WrXkqpsMc/U0Mq2nDO9wNv/I9pWKH6SngW
8UvoEmGjpjsB7fzrFaTcedHtRqPAD4sGrHiNwhiUMZgw8tqlJ0tnSN4jtd27169rG1BtdbJgGCv7
Wt1YRejdt4hwQ9zvTBJUsi21pgdyG0deso1h9ZJZB8hR7N1YKtMmLhIrD2uI4ohnJbzZA6oZUaut
Ce3imZCekG5KodJX07LqAa8XrvVei8CFZZ8tkyy8Fctd9Ek7afrbII5O329JWAtlI3KHgWALNtHR
6/o41SgqeKs21tnmOxA2knJ9ZwPIh5R0aG0eN1ZF3Mo7Zl9tsirlDte97vvQ6efbcimzH1Pzhirl
PrjIaNW/HcFFTpj9oe9L/lBHxLE51nAyS9LmR10mgPGuP9SiiauVwulCdMqc8SLi/rEcjpEI2+Ta
pmdUqgo0EFzbUwLbbtyqTF3lLkdsnTBzpaCEKbA0udGAIyacSZ7+ifSGyNQqLfJvlglWfwlwVfuW
9J2qBDzRQfS9ypj7HjKzmB8xVDSxJFpklBlPVni+mhD7y5kE7k5py/jC8A7tlHzCXjFpdD7p9is6
zV/e4IeEiCXPLSD8giQDP2g05N8wpW1z1KM16yXH3wcOONmZl6zbJKFLMRyTlOGlC7y/8Pl0Y4TT
ySkQZQpWZoVgHXutQLNly35BvgQLaeRdC+2c6byf78dAskdIT3PG5ioV5RVaY9Xqjc/yBAsrzxis
+LbSCfLaPygLvWtwGv4P5B6aomRb7SnAQyXjkHfmFnDnfmfSzk8aUjKCrpJBba4hDeGbUOuLNw/+
sTfSHpB+DzxOwpkWKx0O4RtxRTV0Ca+6n25pI30Nzeo4QUBjQGl0gUoIhKUK0FQn+mS6gC54XI6N
ZmTn4UXxOtVNYvnAJF7QuV3N6lbEz2G5Ng+Hp6d6FSBoAv3DK2/7Wll8Z9YZMu6kt6gMiQqYYhaS
fOaWLaNbQD9UsMdBNhA+3co1sCnv5hXzxLbAk7pElgZJzWxcDQGTiCndRhgzcpubeUN9EWI9PETx
Tra7mRk79Bu/jfDiyeZLHqpcKtmN1MiwYRw7owdj6+QHFY0K10Rr9t+nsBa/xA6Zc8PalN6qIvnv
2mDTJmkus7wc/W==