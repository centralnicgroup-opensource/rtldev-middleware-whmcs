<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPymb44WSf+XlsUk5QrGF7bZYkhbYn9Uz4TnIcvc4+clnU9OoyytObevWhRxLLHS784tjUvgy
BB9V/N2v08Kj9UkTRd+m2/NUQLTkFH/7FJDUGoX9FhPSVgqTjV8VlcZTZkdLSIwfxuPUCTVKsQfb
NwP8vG3VBPQWJX0sljtFQI8sKP4lSLb7Oq0jK6EJyTOIBN0hmB0qcsy4FhJnImSYXQq6KS2XoUf6
vMWliSHeJY+yTy2TMjNxyUmmZt29B2GAorYg6r3qNJq+iX0rSgIm6ilmbiDPQ7dPL1rf+royDMs3
ZKxd4A3ad9Rpd3yjCm43im2H5538NUOK1OTE1gFLV6FMfdrlvld2SUVrD+qJiXlu05BH0M5gn5F+
ND4WDSthIftg482nuxK7RybdGeWMFwJS+I65tI57tRXaYv6rTePWXwufjLossiZOg8x3fYIXf1a0
RCkLmIcn5P2g6/W/gWNmWhqw0O2WAD0NCnB3X3CeCdpLlBRf7YyqB9LriWihG6kaHsxKa2HaNd0R
NgRRnmLlj1B6OA4vbBwDVyp70aCazw/ubcoQtIo5fQ+y8cpIBbkfez1/jSegMlAKqhloU/iPWkvR
ij/BIw3HeIuYxZjxw7rHWNTQ0dD5qkbuCxiIb+1YJp+6Thi6Bx+sodeST7vCTC60Jb5TcH/ne3Ph
5ORXQYuYCR7n25lfk2rfBnj3grRsORP+JwpoXlCbiNmVrI2bJfjo/ShKuH8UtYHWy/INAgOCuKsi
AUcnhmhce8ICZ26RUEftZFIda9ZJMntxhok2s7ZhUjABzcyQgl2xVa2hCCtkfaqJL4wvEF1kDEg3
ht36XSLV4bjw4vClsuRU/xjRQGMbLJEw4diBkXZSsh+MMSnXBDCC8DfFVpsSqulak1d0H/lTkNKY
9Zv8TCRNPFLRJevcO3Ijcb+691WfViZtSBIG3R05wcYrn+I+NuLy2HrwHVHJyQSeL7KSmsp2JTyl
NYkxgTJYokd2EzWi60CEZvE7mlHi+qL8dVVjwBc3FI7mbdA+99BlCO8cO1+fMNljnEJOa+EpsbT0
UtxmUR0zFcrKU5ZNCNPplW3WEcECsaxf9EJBZyqofUV0O7Yh1pS27cJGJ5GqfIc7VIKPqvr2+BAH
c/Ebn7BEnYwAAbfrzjqLbVkD7U+qIBc8UQWHikuSNA6rP62WtjLByoIll2MTuR4nQ+q20vqgRD0+
ribND0ElFkQcNoHJE6VMpFDalXZ2g3LmimRu1RZEbzKa5My7GN2YPdKOfPYQlbBV0i+DMHoV4XFL
RKEOg/O8yiiuLktnwRxOLY6TlJ4li51r5fw+gy6j9OVM1YQlb+wVjwK7mtmz40wuofD/F/mwkL8A
5ml5lP1lNF2H+S/ETdUvqFmuY+jbMnWjV/FyQuy5V9XfTG0SvyNt2tq3VwP8ic538eo77UqodZ4Q
GKpq1zaifSvUhpWR4YR0afCMXFABcT4tSxWFDWVLpK0sI0XCtVIWqXwZdMnrJP8jwlU9T/BAjlOq
UPNow2yLKHQ3Pbv4GQ1KNbR/jG5zkmqxJ7zybwOzkIxJTgu9bnbWflqBfbbhNf60eyaLlUweeRrj
lypmtNUwLWlgB4sUUVLk2xs0IsxXuWXICHvI74/5fqLzyYJZPBtvDv2RtWoDFT/5stAJYPalHJJJ
9A78WuwriztcQOZH4TNG6w84f24zY8mFxmr0SNWPjuvhfL5s5kkMXOZgxpraCtpHI63SSgehMud3
QGGCTndEeK63EoZLqsqicDL0JfWwTKC7TZ6IYTSsSME5xD4+fJ0uAa6Hu3SLHThuPoIC4eETod7n
5ofAtlRYOjIP547ygC3/TbAjAjd5R0xudJRyORz5gr3vWGWJQeuhQ0rMd5+TB0bsccWoQ7nirhdC
sMVREdEh+SANvDw4RLX2E6HKOo3se6h1xrdGPM8RAFROzC4OXCdlDx4CccB6KAeYqWxc5oZfflwd
vX08edtUKK/fbZOARyQTzlIrcbSHuw8jyRoh/ixALpZ26SMmWH5SMUOJuGA+1JZOaNtpOco0gJ0T
vaow3IMtwyrLDLCwlJwqqQlvSDNg9/ZLWKACHLDpQD6YJ2mlMLKthNORUjA1RXzD8V+Eb0la6fz/
sTl77yo6pX6vvGfdRkXE/cJLlqfh1FK1Al0Obx8hfQaOHS4kfDdSnInYwClE4vwoUsAEnZd6Taqq
3JzcbGHBDbbTxsoCXbz+/1xARiEu/vLdccso1rem4pjFRfqxw5184edxoPCspXptKfqPkc3FZsi/
/y7QkDTF62FC8+eWh6Z+PfBm+WgDd/sTqy9T5PhMNHCSKBRCwyq+OKJDZVPNlsX2oMP8o4AlOsDz
E1cEecLXYX993PC3jDzO1gYST9WGfZCu5QOdTc2pNuf/D1Y/QqYIjXFgmVwXHJHPjolWGnSpJiB6
Xl+ZKYg4IwfYJEOcfIMsjX5cKM7NYf+KCQnQPYkKsnlEMU0U2gXi5uREgGk9Kgd0am/K6PyMgtFm
BWBuKXlTfR+rEIYMOXHUUXTJgjh2LinCOWqWgOxJrop9fsgy7T1FHB0FaU97s41au8j6I2cEbpXZ
zdWlA3P/MuaEtgl5EZ0aB2FyBQEpC7ibnI8dLHNDtqjSGLkQIx8U6pSuWeTxqe1owUzTDvGWA2SM
wj6bVylEgv8I64YcQOb5+4MhcBEqRuxWaa/jYnuHwH8R6SHazWw8pY8NTll5ISCQ63BWXKDHivwN
lVbpBsu33/GMO2l96Bts4RGBlUeOLx8DhQM+E4UznEN83OverIoGaRMnFVkbd+tMwHb8IxJC6QF6
8DtLilnbosyte+mC1seggMmqpXoeqGGQkLKFD3XqmJjX0H6fwp5eBi0nDvwImthrmvPOOPvfb6q5
in0zScjy1X5d4/FEoPbizout3pC9w0u/Wb8ThorSEvLEgv3GgeMj8NRWXKnpu7j3CRQKOi6uXphb
j1V9egtWIXOfvxLSssiDiXQXLjcGNNV0vGjmqcjvfK8R9sYqMwjocObp+AL8zaOl7HnLgSWULK6a
1c5RqJZ5uHrl2VuMshnGthiXKkHCR75ExpdoKd06DQGHApr7NT/GJq48MWiXs5l5Xwg16HRimE4l
R4OxU4JemwAm/XOH8zFvC+c5jz2FOVPs9cc3dgCe4Db2RVsHtPEi614pLKlp4IU0Lmr/7wqZU7z5
invnbZNyPD+yE1N+UV3Wcz7CZQzEOpAahQpczS13zC5Tqo/wOgKmi3ygegZgZDJN4AZd5GAM7Mr0
ZAE5V9y9+vMEnwOcZqBtogCkPO+cEpHnAb4o+X9d4RRIMfcxgXm/w8aC+KMYm1YLMvg/nbFnQVom
bEwOG0MgV3fbhHUbSAIVAw1whV43VnrH2SFsTAIEBV0dkQHFYRcY3MEPylq8Gmjkp++RuDF751CC
B67qOJIsGOPIRG==