<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsWglODdlWMqVkGee21MM9g1tLIMylZU6yjBJrOQQLazJvdJePxZ4KK/MFqlXQIISL5cGHDm
YBFQrHJflF0dg+lQFVn1CMVygCq+/14o68AwSzgiH/H1//QXIUs50YrFkDs4b4Zix4Yv+QZ3ZeUp
BcfcWrKUqunHcmDmssOJ2LwhM1esfhRVwHxQEDDm7DiMQRad8bgViOCAgJgoRIoGyC6NmlNVg8yc
FQjiR7X5cGon8odpwxJvOi8aP5IGxo7q2ph2GTAn/sm+6jaDV8eQJ9i6CglD4sk5/IMlvTr58H2W
3d8G9rt/JCfbJqfPdRgc8kagx2sogpIYQigD34JVflh0rq5PZihfNMjzoVUpmi0XO7ZJWaUJwJgx
XhzSeCz4q40hpZNl4ygNCmDZ+wxMrQ/knU3AQbHlt6noqARfRruvFW8Ejp9Pj2/DwqM+RJ1xk3W9
tAX5XW5eMs5Ba92JW1wFD+NYspU0pYPZArjqJ07+9ec7wLcR7VvzxKpNdn6ndwoLt7bJAlknODGw
6elNwFzMQWxVaIBLm/bzrJ/wskO0eK4oI5JsYpyNTDBXe4IIEMnWSGKCjp5Obbb6KheV4qIq2oUg
QSlw38Y3u6FCWP05QMlLefOACC2iawrQ09asb8ZZ3RE83F+xcdNsmPU0cheN+omskZedTcPW4fV6
dlj7mDUN82qpbingRltIdKt4C/OXj7ks91HGWjUzgyDGGEoHukXbK8Tw5nMbiZb0z8AdxElDjOKB
Z2kLr8J9dsJ8VAu0wQ+jrWDTTLkLCQuRK0nzy8dq50nX8wzMH9PTXdg/e5pCSClRP2S1FlRvtD+t
2ScP7Rn9hUp3EmszmjYs+GtKvvxElL+2LFoxN+eLinFOhgdq74P5A4X1Q6ye8aa61/MFgpDs8GD0
NmLFZTXJmCxf5lig/eLkIjQ7neyMKuulNS8Fj0avgSqUIPshCNfy5q9r9kufsIF7zACqvJcOyH5i
ptwfcdWH0ak/aLTTVepXNCwF05n99S4Y4DJixYdD+xKa7oImlIqg4Z/gnLh3TZUT4G6T0t4A4wt6
bPB7Z8cvvw7JBPvglqt5MqFB1Tb0unNamGTpDskSYp6PIRlKgDw169YuKb0OQS+mP5KxCazvlJaW
o5vkghxQmbaLy38AikIYplTRqZSjQlmuDPqdGtrWSpxCzR5vlBEtqOJ/MSEBZLhkPIeMpYtpHuRN
NWp9lyHAdCBmgQdbfvuWs+CI9Qc5Xaa6j/OTltZy82/UB4FKswrp7rmc1bXC2De66J+3werIY+5U
UZISG6OvcZef1vmNqTyaI+gAWIw7NPaPUjofw4f68P94edAsWhZy4pV/5dyNipfAyAmP0FZJolJq
/q3ZlU3zwuBk5irsV8FfvcVrD/wEkOVDMQSmaOYMxU22Q/f1o+KruLPur2LqXlpi9zplB5NfC52j
expDkK9s0rU6WIT1s2JwcwjAUUfZ8L0GUgcz8XAFcY2d+rfUWpwBzIcGrlCC2aaxrM0YiYpuD/EX
diBlmScIsGsdqbyfCtB34Qfv4pSeqIKfpRRu+96e6LoGPFzVkc6hOuyMq/2TZZd2ppxuln2O48R6
8OwIN+CE5hju/2pGCNafR3ytqZkp5PN0o7WH6HyRtYhJh5Gi2mj1k9WZvXCEZXPylcXSsxwy3x8P
QywsaAOVEUUjA15L0l/VTPq/WnhP4ZDWx16aeq/VmlkHVCBU4w/ky1aJ/b4WE2tzlUqzU7CP1YsI
ei1od2Z6iurW0dS0rLbqtcDRmyxxCNlYf+R+t0s7LgXCfzQ1ZN5THVgJ5VG5rUcIyLSjWqvwEaSW
s7zrRryff1aFOL/Hm2NiXQzA4QJVbGOt80y5NBLh7ia8r5sD7iTvC2tDTF7P6ngOJ6QnU90tqSPV
bKAHqUtpn76VjhNlj3YOlskFJqauGQeZ6d6UfDf43oS8KhOacB8LqXgTKKc/vpX1fONvWaDA2mS1
adbjrSsm5kLmW1PgGBLqcSwwZYQJQwh6h18kEXlM31/J/1Wjnz16u0as9Muf3ezuBpy2uSANG5OA
xHVQuRyanvlZ8g0WIImGv4vb41VO5e2MM1nRM2fK4Vr4bDtCkpYFszzJ+/3Efrc+fUUDdYlYYqXE
9VbqlIj5Q32I04uCZkBMdPgNbzuddQ+72rSjUAf7n02pS+gGzssAQO6M5iYiz91oWTrhAUennM2G
MheYXvmPU7tDo1oQqR/QnTYgkfu9SecEc9CuJWMzZ22vVdchP6lpfBpYSLgN4IS6Aipm3azUIX+C
dCC3A6bq2OF07yhaNJcbltbwcSGpSQj5p0BT6Z1ist+Im0DaQYXEeHMVXcaqta54/vPqa5hpw0Pq
4nvUXUBnLr8a69VGBS543tv/g3RAZ4kR73kvRSn2IdqhA27Q5s1gNSrLUA9f5WOm1pu+65inU5Mz
AwL+QWe4fNAAHFy9xfhRCkmgWxqacliukiKdcqrQist0/Wn7sU4An0f3wS74nnu1pswzXJ4ZOiyk
fRg2nad1U8UQl4usD+L/J/vSSa1ZalzBTsZ3mWQibPCZl0thv6noonTFyr3WZDjduJgiUOI+MicU
DjkQ1cJfI7DCDZ0P9eejjY0NqyPLp5wH6tVEt2CpYW2ynLLMXMCPxH/CNpBUyKiH0VTyDPO5WWKG
CscZcxQT9bozlKzQBj5DI5q4yXpV+jhS32Tfe8h9j7y+3ddQzg9wqMVipoCz2rLzK/qXVbahpILg
R99/P6Q/TtbmM6nt9rt9vFzupYoWja8HfxQNQglLagCS1aDIkcKeAPd8OWj6GVKo/6LAwOvvCeBW
PiSLg9Ng7/dFoV9EbyptD0T5bVlMn8UsqQHpJLiGVj1c6r7XONvkRWl0Gsa6u8+2Ikiqok/DE407
PCIqJQe47uYGYpMKKOD6O7SWCBWDBTv8m6G7XXFcyXMDsPqzz9nBjLFXe9CE2ebE/7lJ+Dy4o3LH
VGRZSHCuJyrqt2dOYpxT1Bnccd3wEA2qXbeTj2FU2Tfx8zlEjPpt+eakDHAxhSmTYNHWt+nGx8MO
WvMo9j/vCg64J+27I0+qJlcFpaow52iHdigNWavM6BAQV88TUhnX2v0ulfE2awxtIJuTNNbnAYVw
4IS7V3bxUNJ0Z8Lev4hnNlmPC/RsVd0QfNaID0GcypWA0P+BbhTbXgEgJFtc9v7P2rxF1/DWNNe3
IrGoUIygBjphbU5ZG+Gvd7z7VeKEnQuaCDfP0jA8R35eK/BiOlWoTvYYO4PwdTgAlDSD6MXVFM5Q
Ytjdf0ivlxkZdJXh0yaK4XbqBWhwos052NidUSeAcqQTZ2kCivoWc0SEIUfi06p7IspJb+ZtStuQ
hQOGbdRRwmwWzbirt6WDq1vV6Y0XNL7ue9IoTj8g2kP5VV44msQQ9e+C1vaKMdoVzi1nWm7qUa/w
0KgWP7SaMW==