<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwTmaW6dq6Oslhu78gXdiHk02mEOPWLfRPsuAgMjFgRHZC7f0vtWuZRzIZ7HsvQI/juShL9S
ASIKK86foeWlIJL2LhVxPBBIpgZUTSmSyAWA07aqy4N4DB8zY8ZZoiv/uz9RxSyHAfJI2VUaCtfm
ngoOX7fffJIdUqrwUBjPSArUgwFT9+D1XJ0n9NcZ8kZURthPVaLRpxl9uzKpNJafBral+nW+L6de
Q9ydhv+0rZ+J12fJSv0H8uJR7ybcaxiZUK+pHN4kOM5PifqpQfusWHk/dXvez/Qm8oh5g1lDKe+7
AmWTNmabJtcygic3BlrhMKZLUTjEdH8zMvP6Cl9vMv3qJOwBMh7+2HtU85qDQ2PODx/LWUiR0gKs
BVJ1MRlHWya53RE6faGdl6lSvK/fg33CQwbAbXYRImu676TIg0lad+EXdQmEd/usjh2hSxJdtndK
QrT5DlGtSM1SvJZPkxKEEZQQEceZiimzX/sQPpWzIXweTiRmOPHa6bwW+EzydVg/+XVg+AMDxLh8
fWsztBN4jlPFCnqeHUyxK2cxapja4nnKpsqEXV1H4qF0mLI/KFyK9yM3mN1z1vW0oqVG1mArZOTK
LskpjHrs/wKnAnTNJ7Vj9LLlFM/Q6SD00iwkCSHTu5nXYoN/bi8IlMEsDDaQdIcoLdDdlHKufEiB
7pGVUKw1oK0bSSP5PmqZVoEEg0TxsxBO6/G8NW9ZYcKaOTi73KojiA3dJtYwHI4Cef4i+2QMGbBc
eN0f1YaM3lG6fdeDEoNBmUFOUfKMdLlObX6tb5PGFaDTAsFPJk0p36KEywtIZkeg4xAzdPcAi4mL
1DXEvgCYdeU0WtVQpSqpY/e5DnV+ngSm/TgE/jY8Xp3eCTM9uhRFu69o3/qEVSNu7ArKb4brlQnD
YIlCQQaS3vmiyOXMnPUOZhx2DzHwFkPITy3bNCShyIk3yJiotO0GjCxeFjdESN5/ztICg2Heh7sL
km+RvsBlGcHynGZS1SKlygE7+/JA8SJQDtoEdMw7+MCA/wNXvxA/OEQQ8k5wsVTqCzxZYR0nS/aD
9V3EbFbxLXTH+Fdl0SYUj/4WH6dZOPV5ueMnOuhnIlZQX9YfkQGLDboLPh2lCExCpdA+Wd8kS3tO
TGwVdS6+FK5FDEwOqasDAq3pL0hVkqkECOd6vMiRud+T4wkqq1H2I2N/AvhhkN6Q7l9/VLmAPPEv
147wCAaA5/Bjp0s+rs7G76hn4UMLdMvMgWbSSb5GfXG+AuE1Nq7/akKlRJD/J7TwLrMKiDgEx0qf
l0ILa+ogFVdBbu2Bwog/2Jt12C4lmOvcQkK+gbFa4V2jDaoQ0//1yyraXVTc1RdunS2dT++DSRgY
n/vH8pZlXPb2/wOlE7bIrkEVPpgaJ1W6UZiQVFlhjndTby1dQTBYM506qXAQ5qqQiRK9wRvufN3L
BvzEusc8uYcDP6efip1x+1Bu5vn7bo1mXYm+KBQWE+f3eDlc1Iadxfx5c/JRHjrJZwgy4HDGVxy7
Crch+4g4Q4v77SK2n0y0T4gQmVORy+rAMXVDOAyRTgCe/F1cS+p4UM76Xj7c4sGUnZfl/R4jGWSu
+tjRUP3T9118xnWrGhDEMqGS8iFtt+YEuZ0nobK/QXxW5nBCaT8ApRQxihHwxC6R2IknBIFo0PtL
y8NliRu/4QF724R/if7S7jlCIbrXmveCuDIb5s2W/RqmU2sJy1a+hgqWliXG8+o4gTLMfakVDgmA
1dGfNuFLxsYhwztlVUDulQMRDVMEaY7eeGbqUc5HPKQCyn/huXtmwC+cg9gXYIt2S35GCLb6jJdO
DPL9LvtW5qe4Opy1VnwOupXI2pVxYh3wL2ZN3owUflU9a/PBZlsmKoFtf1r03l0Thqt5dIJjTpQH
UB5+h2uoyz2MAc0zuIzwHeSBK6ywTrj0t9VFS5A9cgjCgFTBsNbsWaL/DGNQ6EmrFxV3oeZc+o41
gW9WinVyxVLS0BnAw6f2rtU+xwBwLzx2nl1Vk+opRbKn2KAyAqq79cjYxVh4GPhe3s+yb9q+UvMV
Tto6ZwIspTm9CEpYGZkO3zChqdbL+jrqcpzB34bPPSDmTwAuMB7zuIVFgQCeBiRWtqhhCU0ENc87
Zsg7vAyrArH5e2xm84T6Y2IGtHriuz85w70zTh3w6xeM+/CbZdxM0AmkHbdB+xABhBvW4jH3GeCv
44EIV3v/me04yCA97GDdvCAs929q4FAZ4WXt+lMfE3uCR9i0Nca6fdXlthJiLcchmxHyQ0VuFHx4
6tgUwdGfUE3CAUwQ/z6MS4Ib0avfFbHExfUmZiABZeE+KxaCV/hTbQTyczYmjARHFe8H4daqL79X
yM/VbEVqNsjQfNN/c5VG7cHxtWA5h07hiIqObgeC/urbL0TUFUvbXCPJT95oBKQ/dMNGHOhJ/nQI
1oAuRqXXHZecsjgHJJOaX0lKDOtgq/4Df4Pn8wpcOAUQiVtyzdGKxW6WmNvNx98pSaqb4pBDGFSg
xec+ffATPE+Je2ulLAmkcB+ffo3tJsIVS55NEzzEn1rXq4/VuLlME+xyg0Vf01PtgFoZmMACypRN
hQgqQ3uwT91yCX+DvimtXfju+LuXpssXTIZ7flWDbp2TuiuzmSzm1mPvrYcvCV9NHwGEMvXlvFAz
jzMF5qvZy3joowF4T+xKkenANy51HVF9z0H+1+XPFrVvQQdfGPMq6stIzSCn8QKfyfsdtWwjgS3M
EbGH1akWolp0MXczASVygs1El0IKgNNjOseRG5ibshht9GU2rv73mLyMWsC9ZCg7VDo/KnXuw9LL
6PlcZ7S10rHRqxFBw5n2te5mBkr5KOL8WlHHKWHwtk/AMOiEsfSxOoLJPNy+uWyYo9OexkxPy7cq
TXbDHoU2W+x2lDEdpSNNg4XrG0/WjstSUxG2SMT8CrbvQb9hdL+HKdi1vne1mAZwtMIKmx6mHq5r
yJ7fJogHgMSu5uu1G3WwVQPp1USZ8pVP3nWTEH038kDWdHFDi8Egx8GZEzl919R/A2ckoLURKMgK
jIu+tqrro1JXcRgPK3cJaFDjD+oa6Hz6BYaIvD7JdnvxLl7ABRJ3m4deqfa6jqBPrTzwdUha00Xb
Talz04USXJOnYJNizrLZ7/As7zJehJfdvpqEYL/P0DYqns0A0stV4P75oRonf3C12yhyn7WChA8k
n6k2lcIP74QeGf3q9JkJ6ToxKPD11lSMBiQTofrEb6J6tP+7N7JK9GWQ6alZyH7g9ZBbHDopb4bM
1t9jBfVFBu1xflSsdt7t8VTppCiPq8wvUYSTwPAeXneswOTZgN9Uj9eFfHKsvi1kpTtYjbbz4Xhn
u3AO55/dQakpZbwhOlmjoBlt4ly0RDqgWUvqzjNZQ2UisR0I0tWJo5nBNlXMooeObaef1f3i3lij
KwHxbZAk