<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxScU6dJka1FgkZjIh4U063F3EAD62nJ5xQuZfLv6rkN/9IjLYp0SHPn9nUJN5TbvnIatBSe
odhfcdgNxNxYnmJDqOzHuuf9eLwxIFwtGQGTdn4znEgKEtdJeRhL/Hy7ToP6ec+Nr8PO44UE62M8
9Q1PLJEnwdvK3gjhmWZYzI85+TdFn1rEpKQawkZs+PgKulbQ3DZkxAZl9bl1636YvF3ZOIKGlnXj
QOQ9Sx93iA/pyivvMaW+2K/3/FAsOAZOgYXjVx3TJcoLmpISkowBr9pBQMLkr1MxEu2k0iBUo8kn
tMPnkyChGRu26PAp1rz8FHx1yPKjBIcmLH6JzjDk2DEZn33EOrunI/l/JcYimByJnh9Oho6zFwCS
GKJDnFRNkIjlOvyStcu4laXVNmPji7kjX1fHMmgAQWfdOACjtU5p2cEaOxc+4B93MqnjYIbD0BT2
vlO6M6J1RzpJLSoXLvzuk2kZ2EMxd40tp7XTrtMtxRoJd/XIScyEHlMGNeJtCaqsTUlIQLe957Hk
hitDSlMaGN2zodC5/iat9dOXzIUH9r93HCWIub1cZ7eLQyNxBpvux9dB3TTYNPjPlvp1ZZ+Jspq9
VV18xIfXYHcMC7lVX1CtlY+vN2g5VhH1d/uioe9QPu3P+5vXe2LSR1M/RL2mzKq/G6SlCh2z2Rk5
nZ8QX1rvumZ+9dZEZc6ulJ5NDKh5q6fjqMGRtjJF4ZM8PmVBnj2KcmDiL4gvKuli6HE/vyE9Yfok
PBDjyg0drK6OPZqWAo0Wehhl2PvzH4aqeE+9UsYWoKv7luWHB7UIyMqp6y3f/XO3wFPh8DgMc0Lt
Z+glgrvaxmF76R8VS2P3YOKe6v4zTwRWjPfguDHkSeBWkIiRsKhvXAf4KooyQdII5AaVH/GIIWe4
Npqt6kRv15C3DT9S23fJ1SC7+TmvP3qw4DuPzHNnkwiDI4faXCHzD/e4TbdY0JkAr7Hvl2A40KPQ
+3+r9psrPlo7lL12I//CUHPNQpJhFkf23rtXaCq0iIuaR7PstASFkoCCqLpiJveLASrhE1BuqCNH
CFh7vPRsq012ow3gQDJVZwtQlDuiYb+CMZQkve1YgJ7vaDUrGTpWlj3L7guu8TVJvussugiUkPI3
DV3HS13AN7z7WgfEvtEAwNxbz7cV7em1tvrbGRlpgQpeqyt0QF4gzzoN3Ps3CTE134TroXy9OLZb
jVGH5woGsSr5K2JkWgaupU2WauoKlDWsmguXHj6BcI/SU3ONGnuqRUlcl087nnH5muP9yquuOuiC
xIJzco8IhJ9dZMgQt0Q6WHscUFraNG08LudBQ0lMBYdR5CENlBIuTIHEwn04erBqSXYOn6OxTWWS
sW7iAG3E996CT9pVQoo/qQwtr8a8auZchwvv8sp045GB4O8zZWi1Ge1UHrzRZL1x7NCn+uTU1ZbO
s8K7L+wK3YSX+4lQtKE7wjDbmoGtImUxXRFXEcJC6bqrkxmnyNAHHrY0B2CUZWfEmoAF1SCtL+tf
WfbAIfjurS3quSJt9Spr3RV7Ov9kzbBgMdvB4xgMEAiI66EWt4L4uRPghvqSAYdsMct3SdCCqjJO
oBWIYGvJTLzJ1xc3dgxhJO5Kd1LUs9TwBwVh5jcayksSXJI6zgs1cMQNoCeJShhqTFQEv74J7fj1
GhYgtL53XHuu5TbycTxRld7Zex4P/k4D+7cmmSkRM37Dpn/9IefvBkr/TtmMen2bHOknn4V14gwi
BOtvVbkLAu5tyyyXqXX2j7G0ksvvLjmLwH12BNjaPFACHWQ58C1P9psvEj+JNqPXo7CtCpLIqYdJ
EpsRTg7gyqPjqZGq2ly7rWA9RqThzTdwul673huwYGKMhDAKU/ej70EXfZfSVRL42N8vHXdgp6Sl
aEgXmAuuJiKExQQus5oYhhNLSb49OyDb5eX7MURDgoSi6KIQohpmf6LFJzvFlOhRzNuzWblbu73L
hxKSLT+qTid0GO0jCtJm8kAHb2KRN0HLhx6dIiL5nsk+CXyKzrZqdqIZ4rokx0mkInTHStXKc2Bd
+zk7HU1ygs0MzRnZxl5WQejuA2TicYeQyQilXglf5GZQ+pc6Wruuu7PuxA8kxtNiPqAM88rzyAk8
zwE8qN+/POBF7Lh6N2cImd+UcBU1TFiUkKnCxjdci7Li6Oe7trXIi4NdhFkRMjXuU9rfSn7YkF3W
eCxI1At3zPTFmjIXs/ULrJr4VcOVruKDjVYDAAXVazj9blGxuDOFuVE0Pw78MWvq6DuinyQ24Vo7
OG96+4Z0V9MP4c7bJ7YabaIz/M477OKZs2vh+RBniUE9f7Dv1nDNvob1JzqeYIWQHUf13BMiTwqC
snb0xHB/MgiH9EL7JiRIvu3wh905Z9DKn61z/tep67huoac8guc0r0WGhf2PG0LKSRVQ9QvHQudI
CuFwqrLAyVg5UDivWc4fwmyObycaM6QQ0kISsw+2gWkNJE6y/CDbg2A1tX6qB4BRyfMkn5oPykgw
jUqG19dAgzrHLBwV9WtqyZ+AjTzUrZbLaOQ4WvjiGS0hAeYSc0XtR+ZFJG+/oarH4gGO6k+8L8tv
kxPZdTs/Dz0wwnNS3NwAHD9aWWyAeNqs1OnTuc5B+uOjMEV1OD+S4oczigrKKzzrMYJm5Iok/jIH
WN6BtGreR60sD3UJtdQNB3A2lYAPs7P8lNBAtfKcxri6a9IvD/HtbGETc6n724IzaGUYoD3RTdUN
oQ+fTt5uuHvaDTi78kudg9ngBKIM/gilXMHfVVJq0tYQB0fAuVEC2CjmDLE37OkCQMKxiuKYZt7T
5MF5fatONez8nzXiULK3wXLyBHQ0J2iJXlJgY2mlVk09AyQlG6PrVQ+Rknk2KSZac0hR4zHY8whM
H1Qi9MIx3BD5s56wuUPyPfPiqfmETD3AM37AFotQZ7cSJ+P819UhC6SR3LmiCqBtlP9U6Z//GQ0D
IgreNNdvrovPkNeCopWwG3vTTyHdp/TWVqQ0FMOIvarcHOE+mZcosZUHLacc3DgDiYi/TE8dQvdE
k7uYswoX895SS821g6nGvH/jMWaab1Ui9HEqFG7NISjU4Paa3xCl/IVpGclFI2t7VVoXkrSxYpZh
ZxCIduTwBvNpNo5pfvTkzVqFNb3T3ebEAb7rpmnzbpxTKgLBIL5WDqz1xK/fx6FEC6NwwPFikEGX
5cuxFWnRPcX048zHiXl/60tn5A5NY+jgTjvYg7VgrDFws+nTuLLzjtl7NxSVYnvSLYkWo26xHcNU
C7G44tXUYabBljim79zI/YNkwdJOa25phojvlGtSz4DIz47K1eIhWQsbJSo2jJcSL0DNY2Sl6HUH
QeBVFV9gW8awAYj/VyRVO+cHnKFfSQfW6j/SPwp9SzrnOrvyjUMf6gDOwcfi3o4k1gDKU27Aeak1
O1u=