<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuWBu3l+sTZ/tuV5THXu2B/Y0gtZPfvpfjkp1gI8j5XV8EJt8nXCYp4FzgcB5I7jtp2qMon5
J3PBUooLWem4g+YGAVut8pbPBD7b18ja9MgsHVxfhuOuZxasZkjQC83JyCnjUHzhEgjdGQ+ti0e4
YBBnprwLEQLJtCCVXnbxm17rfO5jBNu5LIvNSGGqLoEnoLefLRURsSUgYzpq2kCuf+iuiHKc7RoN
NIFpk03jfEWZ0A+8nWqe2xAu+15z4U3ok9r4ppVM9qz4A2UD5RI01AMk9vdHPI0mitJfxzttFz1d
KO+eIHZysTpC/ckL//FF/hVodblJOJQr4IkEk0A9AKRcrph3ggAndRvkXZ1vKNvzNRHDqeEVmIh0
KTeBenWLR6p7HUz0ivT27o3BKxmYg/3aMpFSD3QEOeIsKi6wL8GQZXSeLel5OoZnD2ocqkUFXA2s
5eNiGxxr6aO4ADRJzococ0CVqDNCtbDyl4VPTbFWE1T22DnPNYzoOV+mNouJ+nWoHu/Nt2S6hvp/
YbpnSMWqbghbSlWj0580G0RRIs1rFf5we0dI4rwSUCAuC/eorn6aNBsH39/nCbjrzDq0egXv1/qg
TVcQE/g+PW4xLXK8OQ19SlTYKZ84N9zNZeIGkxon+ov2xMapQwBHi4YAkMICXq/iQFFFRqjkN+bQ
CXv0WKb6xQTjySo7YvxgOpdnmAPnpgfqE9iu8avQ3L54Y2NUrOPl0jiULtIpBQE+iQF5Rbev0dOe
dwPwgt44PsUlIRY+stFnCyrE3y/ziIhFLvZLWFEUatOR1lLbZ3y339jPJok+UIR1l+LulOkEp/V9
3AuEYlBa2SgWY6J93lQCllpD1tCf2qyStQQA9j5XZtnA9p4QjQaMbIdyJPWcCrcU9RQDOm/bOgTt
Wys/FqJTzTzix8+g3T70HOgVRJZhC0HppOBxB0Qc5fmcDc3OyuXxDgmhM0ZPhVa+4igxARQv+beQ
3aUvQSUaeYOlIf7kaizL0FkXZ39k18DrJ0h5ShIlH8lfTMF84v+Ur4JS6zJuTMjVSE+2216cvq7X
7yDV9cws0qvF3w3sYkytHkhXWx/GZizMXARbuquXrcntPuj+s6x78RUzThzif1vmGJiieBM9y96T
bemdawetB/R+4oT3fkSUNfMIgYUG5TnLYNZWTi2kYKA4Dodd7QWH79M9uh9wkdYidM0w1lrdLKqJ
2dplfQRyp3Yd0C/FYmcvFQtwk0bccvtIi2MwuQWUgYeuz1D/3kcHeOZP9NgqLBwkrnQXGj+DKUFb
kL6Fv/Tdqc5I5ULrhermlzDDAFBHRgpyL024+XuFiCBJa/I6pfd9PkR6M1a2PR6i05dBQFz4YQMA
LPZjFarQEP0uRuF0RUDnAlO92m1CNo0MXqPMmUDmvSzoJOhKE7xJRUNh1weAC7DPSaFERX6vKY7q
wFZtCFRE6YctzyyJz3dYcIoVIJR2zRqO4gYtGibEE7P0t7mE3+oyDLVnZxBhOUSSmkLDYseQBYw1
HS8/P0OVqHXJqdsaMeXqNWluBXu/tcM/eN80KHjy1R01nNHxcf7YmOnJHV/5QFns+C/dwZ45PZEM
tTQ9lNlFZXpxDxTrcQ1jttHvJLfxze+znlOp6DhvM179aDKm54knpGkNxvDpN1z9DYZoxSlyGchx
sKkIGPOgKii2i0yeI6lOA9UZxTBoggDn/shyszygffDK2ia+6VLw4SLlHxkBE/faxKseCAdnKlle
ItruqgjSmMyFVo48VvuLCnWz8yGcVR4WonO4k8/UNAPpey0Mv14G1f6bU0Bfjyg+syfxHWxrRwBG
H2D4keC0jTIGtYvk8/Zh7HDbZbc/zy+S6v+LQz2+9p3aHc9t4Kj4VGUKE0NU+joveHuj2XqmkDp2
KdddhXe5rQB7Ft1qAf4oM79sxAHUnc61PkDMkjCBU05/U33uRVq2tzD8hrAO3Q1LFzlxuu3JjgxD
bVM7ixQL7qxygUNzUr1J0UPVIYdWZ2zXzuWUkv/DfIbT46BR3wICkhXGK0bBnH02jJwu4JZ7AVab
d7298wZxCt5Cf7eIbQ6fukC7fesU7LPajkK17isjCaKgWIHRqyMi26cdzH6H1adUE1eAg8Fc4mJP
1AA9YgmTRe+anQjWI9GPpz/oCIViV6HL62G1uX3biBIBog9a51rKtLQ1Ne52mFj+qKJOb/a3WFQk
xCvcvmEb5Xp2u7gdKkLGyo7gzyiUOFMUXUuEymriWAqhpFsSvebNQwB1J57ghIsH/WnJftkcuvjR
0R4/XTj3RPTP5oVCg957smIKrmRZnKIzO9X17ZVQ+G+lYK+XMDRe+Mm0Qx4raw7ggWgqQ8+0hzUV
+kk7jDG97cwVqnddNCRu9JgNfoJWQvv3p5m/JntKXynPju1K1mVevYX3+C8P/+n9ZvCGHD2QIt8G
ouymEnRmo3Z7vPIM4ranBOjHOaJh0AzUQUswcybEojvOybZCFsWi4RKk3p5JIIvrlt9X4TmINAAL
Fb+vfUT7qAAtXfzaMgKGkE2n1CyDuaoxiM0zgOexIkLeN1lI+9Zb2CSY0ooQqNqliPdiFt4HjIwg
fePHKayG0T6LhCQAmaU0ZUcLMyb7yHNcR7N3mc0Ek6VzfPUVQLIHVKJaQ+kxb4DnooPgcdDPewBA
4d6caMSnH8h8QHY3NL01qaGbFehWVYDiocfLhwu0qQ4/Sl5XqKTo1TgvjVp+pdRezzfxrwbnZrcx
i0+0mWGSIW/Rbd72DSBBmw6fT5d/X3t+/bnv8w4/N3PsnOwol0/BThpUtY1032ZEZ09oJtvwqdVQ
ycVPAX45PjAqU2QxzdTVo0iWJRN/kTdtd1fD7eYJ+2FbwxL9J+MJAqq0sfm0ybxmMkO1wAbg+wn4
ueq6Ausvjk0nii71XrnIFLnT5/cmzUoFUQvIy4ryz12Yb2kVZBve4Pbo9An5vz8/xFl1L7EZniAc
VDpZi9A4dmr/ZL9BVSE/nMHkWdq65Q9Vz2SB6199DOHLlHzlFwL6UCHa7QGUgvM4J0PZFTGFbyfc
5wAaRrpaLuMaBv03aaaC78cafGGYS6emaYY/TqfuWFUB7o07i4dw8l15CtyMInF8D080CIr2PA68
5WH6DjFURgBLhfyt2+YObkjTJz0ZV02FUITp1MlVbxTZszcKZoAEWyTJhnxKvwl6Ei0515UeFm0o
50VlaM3wVRDWKh1wL0UFixpMmkyeNZ8syfPjpdhcYWEAPlRxSQwAaX6BAbXuPcoLD6slpOHgQPRu
c07hMYYSR4kGev5ZJH0UvzRxxyh/gcPkUrL3FTsB7h0KH4x/onmoDpHDo8gItrIq8DuQAHkGVKg8
Jk6+mizggWVJV94zTiT8IJFyy09QFRtETggVX4Mc3tHQ46mQxmJ4EoKxcP/LRm2FOjIiBNafwr3g
l5O1gORGjALpqag0WVeWsB5AGWAlWw99ca7W