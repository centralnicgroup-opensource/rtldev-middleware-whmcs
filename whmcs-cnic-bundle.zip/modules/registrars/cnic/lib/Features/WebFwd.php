<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvpukl0aR1/7CJ8lquJ/vJy6v6MWInEiWQouWgXQVDr194OUd5P+LQJ/wlQuD2jLwXJjW8Dx
LGyHRZOGOu2n4huD8B70hMYHkH8pUxFRhGo+Qjs5LbyEFWtWiemPlh2VKw3qi3xZhjotQCrwoUZz
bNvWca4dKKTyaYhiXs1N5r+eERP1omvh9FQsXo+qiJZo3cBDm3yjsBVG5WMPR1IawB3adeI4ka8E
dIkgWdfaERgcY0GBN4xbMJ2YvVFKAvKFCJXx38PGOQjJKu8SAFAUjXXANP5b9TOqRCrXMMjvTjWM
sgWk/qwv8J7YwZl7sZs0PagncOQKtdRgkZFuh6AhI0Yd9AwHGzEIkWUPD+WVHjLGshV4c/ifwQf/
iXyB2t+AV2nizplkP71w2vPRlYUMgCqW7QNCRQnPW5bgUK13NByP9BytplVqUm9bmFINUv4ElGtG
BaPgW+2K5fDKZCYrBm1xMKn2XG9gyvGQbV6GPq7n1y0zIrMW84BeSftMHXFvGbBIbKDr/mC4SuyC
90DnInoEuloQcH+leHkn7Vg8nHMTwrZhlDmgarPBLeyaW+dWD3xCtXiJ/v04h+/xPVL53FxdCTf2
1k9crdQkt5i1ueIyLDx8tuQiVZXUg7VIoLqJp4J5pn7E0RtjJdqZBxOsD7euWTR0wIua/GuvBlgw
Zpy1gOZ0//l1eDcuhpAiPawdTS478mKdviby29vsUSec8apqM9zaUvyg5SiQq/2mFw6KmaCxU4oy
KO4oKpzptBFBjcsW2bqBiE7ewTq3wsRv+1kPJjyrbV6oCc5bpyIi0lDEcjLof95MSuFK8DP0a7Mo
KoRutgiZBcjJW2MzY6W3YTlFZg417dnsTEXZWzP72YF1Pc8eiuZ7JPfX/VfuQlAgRI7cQdbXbQ0K
HneZCISjDYFLFgMHgYSmaT/v4FnKyhv/mAWxpBTiT2zx8nl2W7xVnNFp6vavIfudlX7BIuQRjrT7
lsWKoO994lyFkd22o8jA9uTMRldGSb7CLTGi/BApPqjN56BUJnF1vcEEiPPlOJtzkso+IStwr7Ro
+A/Bi+7HCqsqLznrZU0+RO+LBEzKXJO8JIAnhFnk6qjioLrQ8i5YdAmQXLvA+QW4tLAhKknN+i76
HTJCHU4vKCX7xUPtteE3m8sNjYA6wGJE6lxddX0ViS6FLTSvWXO9z4qzsobbb7iVyQAL2nm2/TD3
0EeTp0AmE1hlqQw/GWnRyqILPyS259kWiz7q2IGosFwcsCj3AwFXHf1OnMkpBLB1lk1HO4EiZent
eMgYbuo0uRtHfTf/zGBvk2ZQZTuznjRvUWw5JKqlPlC6pUrV/zvJtuWLcishRFLOIAehJac3OQ+k
wNLqw7p0wG61vLVSVha6ah1l0OdQXnnxtlEsesS40pYVX5qwk9teBVf08fUoFNnqfR0Mt3DZINwU
tiiLnYojaH4nws5K5iSJP3gOtEJ55vJwTNHXkK6oO711CWEZSl9QarxcdKyx7JLsaYbsGuAyFQxv
KEOwjRS4PwT3uWp8rw6FoPmrWU3Eu6kqpynFWA2erMcKWhHGtVDk8ASO1K+ut3NGr8pHUnUrrNsa
93RTHw+CutJmdDovVHkkmZCXSy44dWcL6Qx0CV2dSCizkZgzpvwHCkE7GWLHc1B+H8GYAnXICSZW
iwmR5kGkUa9E9HuMBgKaRLbn3sDnYydjqfeiJF4KyVJ5Unl2BKEhWZjOI82MwMp/AAEGrWeNBF85
wdCMAWxJomVKh9Mmwkx0v/+rjeLr7lbieqRuk3krWbSDiECB3tlHKLxrFzQSevJaEsbNVM4eoicX
zW6qvKH/cs1CiNELagU6Kzm7aXTd61Mms9D52JGLDRAwvhpXBJdHcuRFL9bzoyT/EjIpRlTl0u73
tIgPOzjYvejtMPDqj69mZOchOorhIW1Un+gpbMcOMwGZOh3rxC8GTDnmuGQY/nihGVjQ1D4eTMak
hxq0oTtOSP83m5pkSiArVekeafYp+dA+ZFF7DhLWgp+p0+UKN+NOHeR4lh5Ql5mkt96QTMUbQxqM
JXW7CYy9QNHeqRzPnk78XrevLsK8AeC0l6P+QyE902OOxoTAb4l0qh3QOeK+E21NuRc5/4nOnQvE
5tzX7pVG5FH0e49wWX2Cvb7PxKFWZQYauZdrfhURake6/P1CyHNKddILtYEB9beIf3IIJRWwRFzZ
pg+MhePKL7W5rZUbUqvBhPR9jLmAuk0zsUs6Gbaxbsw01VBjo1XnLZrlltuqgABjoCZvpG8sCuwj
FMiu2blIN3clfnGLEfEYGKvZaIJjJ0JgBEB/s74dH0SKiTdSyCR5zHxjsK2JKZlcTlgaqVKvz94N
/4cIwClgh5gWaBJdXe0Z/n8WVr/wgiUWivLJ3jvhLt5Kr3bHB5nL+AhwJducXawDEDWSdN4KV7SG
MphcZo3f5xJwiS1LedofDv0H+FgZWxuRxsXuE7Eub5d6+zh8EUUENpDp0do/pneM/BtRN5SAhxOI
XIDOpg/Z5StoZu3XHDX05irHAVe3eAOxdT9Ki5wuy+pnMbRiM/UAm5Jxggm6JCNTpFsKdOYbPXOc
4bhKQSgmGVv7zrIvGLEeE5yCr11mu7sMvOkI6c20Rj9X7ogdjZ+v9bV2woHcqOY7WgbOX1j6xsgh
8r2MqzjX8d6enShZG2Vc9TqfGuzuS8icMw7dldoAIS5aRQi3EDPbDulJlZd/B8Eo5kwLtzpMyIQy
J9XOT99bdeKngYDt9DKUDUH5gV4s9YhlwUH0wJysyQpLQaCOw0xd4DZnKuie4TglL1BxSzWKaWwi
KbCE0H4eMtMxCcRpY+WfIjI8WkMCjq62yaw39+4cK/iCRw2uvMOkIp2th9//fummECoLW2JwgGi7
iNbg7a5CivqJpzx7jeqGcA4Gt5ROWet8nM6f/bUv5PAIVRfM59xnaOsQTXa57M0vmMyYYGKoM9Qi
hPGclJMuUSBk4dDVzL8U2bQe+lK3MpdVy0AF5SLGqlwO05FTtlyt/3PXaaEs8HS52coQ6jFQ8RSa
5yzugIweAnLa4Rk2pbH6KIOumUpFDdSUV9Ln6tjuMUwODS6hdae+JMa3z+PgmySdDkXxKHzJ5963
Li66nrb/BIMmqM8K5WNvevAuAeJ6QkS8MpfaThB9V9g8WvvJi6tObGn8B0431w4GxYoZBT4NUcJ1
pR2GAN739J0NcsXv9rGmO0H7OSPQAgEm3QnWMuALtU/8pusB66xIfdCW4ACHeNPupLvssLTik/cc
9CGFG7gilpeFBj2v+dDlIEPXI9SD3TlTIPRGu2GP7AXdNq41A6l9gqtQTzdH47wNe0bPjx4HLcRz
NhTao3rHRnpO4jpZzvn+tKuPZIGmLfRkbX9d5eH9QeyuGfrerbDabbZ/AK9Dq/UWkVfc4/FAXTD+
j09GQhhGdaUe976QmuI6e23hPpWCf22wgrlh5HIohMz4ZaNdOSkV5ekBTwm+eK0BH9XvZ+M1kjwU
PzBqthODM6xlQjyQ4o0995azGdFglF7JbKmXd2QxQ875vjRzwr0ZZgLBuMeSaDPkzJXE8GjmRenj
IcCVCbCDdeuMoSAFBjs0K/sAVszz1lJQ0JBrWNSnYgvcT6i6J0UinAHXHcmYeOTPfs/0XXra6xmf
ic6pAIs5RaDxuhdYH9IwWJkbrL17KZSW8BYLdohJ6ooEJpHrijskzZY7+3ALwQ/2P2K3EWYQUnK9
+R+UOOjWZX5BBZDlbQqjujbaTarCnP9tJMOcrrX7fWMgIO1n+1GpkU2BkLaK0muPCa2qGYAoH1rS
HTN+EisjrqU6Noi93G437/7hqQ6NYn0m5IUF+IG5jGE1OAtK4JFP7EM7Qgm9QP11ChYlOd15+oD0
T2W+DWyOMI8GM8hBgfZR3tAQVWqX3mpJZmEqebHcWExGayA96ugwNY2/JtARDWYlHrxQKVu98yo/
jRJ316cRDBFr8rbz2XXDNa+C2TKnvv1KqmHCSszdnUj7AUIFkgbBPfs7jNhmkaM5eduMUMMxsh8w
l+3/jdLmMMlV1xK74VykISVBSup7Bapk913rEqeZyxBJrvvWd0SEXvbt89ZlLvHPZ18svArYLOL+
h3chXKR6D+OkC6Ga/iaKf9tTo/mHlQq1rvAx6RPhIRtXfuxyaM8jljRiWg2pIchzuKXdNmJH79Jv
vYl/NQ/p9QjpJfgtjcj8vLHceguTAbomowvJjIYdet26ip5S9SphxJL06pGrARXXbhtG3zBGAxqL
PTjTslU18vV9GYA69Kft9ayrWP/Uu1Aq4oCN0QbRw5MMTyG7jRtI1YNwskHItv4bu4nEsesNrjNk
l+hNkB7IpEH07dfOKmq2yyOLQxij2Kofrd+9CWnkOZHKyxdj02nYxQfEKvWGO6Yz27oAsn965n2X
myx38RSSsCtKvPUMI1Yp89kmz0YxoyvjmYOGgh185KkP2FRvAs9eeAuFvk+LTJehZF8YaP5hLePK
Hqo6h14aP6VugrVcxsRl0L6+JI+LUqPmacwFY5ZHpUny8pJEoON05ZPtRBwUZ2aByMl4IClwJcy3
IBRKDzVmndjAkMIdAW3EVThe4E4Pzrc7ijRVgtqd2EGhqjAihlDTiuJGcocqqSnyaTRB09rTfcLg
lLWwwozdnE43LNLkVvvkbUbPMnCMyr5cYdjNKS6gW64AOW==