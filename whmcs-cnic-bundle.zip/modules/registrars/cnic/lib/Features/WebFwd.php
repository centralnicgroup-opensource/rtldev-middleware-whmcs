<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxq+UFzPLwv0yIxqxTn74gGZg0DIDTl24VcprJkqmI6jEQsC0wn6VjkubPmxvi/GsjN36SJA
KCzxtsn2KXgydEmKEwVdOtHN83YNJy54k5TwfPMvlABfEbuH2JVLRPyO8D1TGxQIium8s83rWkQF
U/JojwG2PtUIJFN2ET5R5AQvr20+aKssPsQlC+KEJDUAgNqtDYAn6GGb+xFc44+vQo5+rP2S05Ga
+QL7kjlj202MdLckuFlxfgxiD9/J/HQ2E83MppVM9qz4A2UD5RIf1AMk9vaZR82MhY3O1SccauPd
0Gh7Tl+hzw8rLF84MFLVv0zbLCW3q2lVdKFeqbvtzVkMVYvzZoYgKJUaopTxg7ChvbHduoBYJ1X8
SwZeSf1zSebxlzX2VS/zSXn0Q12Vrs6ILyvWgj+vFgsOf+FaCLDxU0OtJcYRZqZAHDpyS/+XvKPa
toe/FJa+JIyHmDrCnee6eEqXQfGQD31ErTX7xql/f9m4PMCFjj4zThjlzMbhm3jyfW1EChTqHSav
uabDsTXFvWQGZcpskZ9VqEb62W7Wyf3kYSpGWcjqU2bZkHX0cmbx1TB5q6+rXlcaZM/5aAH30xg7
RriO45H0LEXzMm83kGBOVftvz6jp0g9Zo2JSKrzXa1r6/jL2m+IJhbgkJAwpwWdtgj+SGkA5RjAe
PujEM+CQsVRD9efyKngWEh7hPoOiLRpdGneP46x9/lodlCQAzlbfxr8o23zesJjytViWLfO1MnNh
3VoMImhqSN034Ne1gHYsC9E9HXW0Dnq0FL1LDDkdXQaZ0yuDa4+Zu9jSqEFh+0SL9HnBZcFLV+rQ
HHvIW+sR/cjjwAs1aeoXVRugVHW53D+pt9Xaap0eqnaYy97lOWJfkSXgyhjab4Z9ibkfWzDwm0UB
8nTz1MVkzgPuOOqPrwU4hM/2lgLhxOEbcZ0acJ0JBJ71ivSPf/VHgQuSLwedz115pZeeQrY9V4Al
BIdeXkub/vL1pv3qDWjtD4lXZh0HQct5lJThbc/bWvWEKxOFkW8h9YBCSDYIcxXgJEldPIi9iDWh
rTkpKUj9AaSTmG3EfVw7+sgIDJMMgxKwcMagUIMgAgrE0cGhgPUDc7t1Np4TU01iep5woXY5AG38
01HNcNA/pQ1JqMceKLWqERe9OEnz1c/BSSdnY7TIt/FLJ7gntuj+3MIoJbtnCYQ2Ln/wSoVRcTsq
uA/KD7k0L4u1JadORgzw3N09kXh9zs5mhTN/iOeVMaSkqu6s+YSm5nogsO379x4nCf/VS3g64DYa
yvf6qeoXpG//r+7AtgKvKsNcTAQBRY0FC2TvzImfqfHFAbp/LGJjbk/3f1LYqcMNRqybW199W07r
MYUQfHisOXyrbehDEHg0sWZUyTuItFcW/SlK7A3GrrzQi6jDoQzGKtzUOLWmdWYv03hts/B6Ilv/
giuuBwEVy7eN2vFNd8AG0yFopcLjtMp0pJKO2cdR57MOLqcKwYoRW6FSQQ+HGPTldXdcO4eaftev
sNDsKZE/EickA+HqTvkf0/IV0wnrSUnuOVdxixrQ1xXoQH3kmgTS8mPv92+sX4J4gcKruowZWkJf
d+DC+oq6cQFErsfzcKZgl/no/7nrV2twHs8YfF7RjyaAQMT/DPpgutBgeFAJklLkdDYHFMzyTwAv
ljE0s3Gm0F/uW8OOgycKo7BiK8YBvD0q8ReKaKbUfEhcFHcioBku4XJZTMmJiqcoY6EVwfWj8ABB
mJ8WeC+gmRM9VXHt/0RCW38QO9jdU9R2td9R0b+IlMzHm7gejreWLWPfMmdXs42XWx5l9eyoepLI
6vXv5hZZ9o1vKZU72as4oDrKDF9u27uZe8/QZPqQet7e+RTHCYY+YAVj8skQhNj+IiL+55mod23b
PPdCE0xGjA5naPrzYEQE94qs/8W+1t1txxbg5O6RN7tnIcI1gMgl+4z0uHKpoL9eHFuduVlcBuVx
FT8Ca4yZdrA1w8lZBIf8H2uSK3GkbMpohmOkD441B+dN+k8dcGz/SMRhjEYQptqDDph+4O1ULv2D
xnlFA4/Sl/foxC7FUzC2VvqiBQNqJeO1rHqJV/kzdv9glSRBJ8+VG2CzlFwXZaQiuvOJ9ka2DCxN
SehrlGlvP7F9NY0UfAfUCZSL3/nJ+02nQdS2k6PYoVE8JrvndzYM5eKc9ud9a3i0EKGAUWpWe0ZD
5DOoOUWx9JtkcR9kW+gq9YhJNOUYUMLB1ZjG0qOg19S42A3KMPZEu6enyGCaY1bjHmlE8ahrmQkz
oTnshqdMfMgh5FQxQHtwRJugyl6GNB1mBz6VitESiwKeST0XOXatO/zo50VzB2bGeLYyJa4cw/11
ZaRbtVe85xvjj2iGaE5vn5a6QsJjeS+MMRhu6ekXSEu1+AHHxp12aCb5FlAA/qv5voiR3TD15n9V
X21/FQDk6RKKv/+VXIIjx+J5j2vn8d6ok8lDaIEwt//W7JvwJ1cxBIgWvraUGPDBVQzTJOUMXmY4
RzV2Uaw6bIq/JbkR17uwQIhrp4qBwy4mKiOmkB1Nc/+95NWEgqZZSweoQkB5BbOcv7pni/Lue1F8
7iOjSQ1bN6/gLIMFxOJA+vnTg/Q1ZdG0CN6KW5q4qHJ1/Yf0S2zrEUW0txJls2PdhKmRRYOUquYA
PGYRmhsoiBUvqyhA/MHm5Zdp8KxPLS0qOU9keYVCPV2ThNLk/EZQTCcwOFzU2fK1DNJN1PnWovys
iANbkLqOfthM/bbDhsLztGvCkjozFiTknCTSBSI8svTVYVQ8CSkdr+1xwdbo6ELMvClwuHldrSkB
xE7oavWw12baxxwPkyl7Z3u/pf1RLqSlNooiDc6p2GmixLNcRDzfhbiH7pUjywE75+G8L2VkZpC3
o2WOkYYrtvLiV+x6wiVOtTT5BQ/jo08wemYGpDNGm4tAuY9DZV72xAN7n+G076D7UK0hjElnNky9
/lZyBoGIWWBorzqP2eJmUnv1lO9E7RjqK8dRMknUJMJZ7zE4/9Bl8gkQfuMt+TFSRfAMKKIjwVw9
wUK/zhQEd8shUMUkhvv2/pKb0jiTRkP3BGCaS4geAGlj6ydCG/Lcfboqg4+jCddXSfSNPpi4vlVv
tl6ywGb8kR9zu2cTSkTfYqfXJCoKeyZWW+zhpVuDjvltixbWUoKCFHYcpqKGNdOTFW99ZqdkQ0sR
la58iKPH6WWL8DcGZKfq0yN5LhgeVwh1vWr8fY/j7SWuYcoY+JvkZ/IVb7IOEYMVIS0M8dFLYyNt
8iX16VdpNKDwk21hyGdrIuHlAUbpETeX44V9Ojp+bN9e5Dpz8IERKsC1SbcQpEkFnwNTFOCEgBhG
MwzEq/Vk9/IWdyxaKGVpelnb71J0oqw7qU3+wnaZjPab5BARThIOYxoHVJ7/VktwnpORpbLXpf5s
wCwvavyX/LiIO/+FBrvQmYNaDilwl2SAbmK+ohHM7JldJyAEn1Y0XGT5PWjJbloptJHb0GJBOPdX
XZR2mJTWkbZe9h+tAL3iJ6mOfCDxmM64afNODtd3wWQ4csHp6uABSBJP0lJmtyCq74nYsp4cTolz
iWco+8CeRdL4afNhA6NuhbCSSmVJ3I1LbQLuxtRAerPvHV9FtXhvHAKABzpniQdiJBE7znBGgs+B
L3wKZqhs2AjNFWXYLTRIjd0EWlbL0G4LubmuQmd4iUEzHoj84ezwDswJsHyOdzNZoaj1GichBXUE
vUzUJSn0JguDRoF6LyDNFlzlZL5YJGAYBKj3DcZqq/xcYrk1Z4OYPtrZ7yeWTEnsmB31zJSzUz6b
Mg+pnYY41CPsm3G0qE/ghUPtScQgGNBRp36OESVbNS5fxc73LXNd41oc8AP3ftJ8dP/Z6o6V8WMg
UPygoQ1w/Oi0Af58y4w1tTP0ucXFdAI7Oop+Y2QfK33FDHeL3agkghVasOURTq9HjHROQfLCiO17
BUL8NGWm8MAgoU2Bh3Tn/5baoSWrCT+GN6mHzIpQ5acl5cdpSnt+vVE9wb8LFdZItl8m7MktepM+
tViT0P+y9CEAQUlWjnzQ5ZH7a18PWa2EqLXVYoq3os/n008QFIAhdVTaELTYhbfY7amraxVSirGx
ZCBVeb5JrWSwJKGwTf7bvgCBAL0Z1MGbUYE+4ZIG5SfAav8jXk9yJjN202LqI2Ap4DOpWXHM3cho
2/OQ139lg7pFhW/PUJsp5/YtZgUcdT2aAskUcAN0F+TW53j0yDnrohK8J5lzUX/zWuXPb9r9m4zu
fkhf5GOqkv4LeWtQ6yTJs97fBvZR2/A9jhVri4ZuuHzrx90aGzcw1WDs0l1VJn9UGO81O52WbXSP
EX3dfGb9pRskvK7OO+EvKP3PJoApUgYQudO/MPa/zgi7FyxAUE9xJQS/YoMpt+hcEGN6yVBl1XKG
DFUPZnaeJyCRJNDbV0mimucQDKfNWhNRzxBeDeJY0KulsSvP5YPAQPHJNHvZ+WYkSalyiErdPlNv
dpLVKhJDV5Ao0e7mIgQ02Bv/RAlWLxnItbrG4PegKR0DHGXIcsKKtArEkNtVXy1tcK+mYlj4FKpG
QPUxIsnzp+rWrkhJSsHjXrB/t8e0CJNAi51FzLgaMIzG/nUNN1Cfpvc6fQHsj7+4H+m71z6GsD6f
k6+m/5YtVW==