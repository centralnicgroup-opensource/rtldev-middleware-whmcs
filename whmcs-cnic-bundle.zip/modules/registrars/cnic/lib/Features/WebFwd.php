<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyqjKnxwkwTHW+V6FIhqQmtGAzmroFFd5kzhbIH1cLpOXc/v8ioaWiaR+z2XPHapDUeUlsXu
3nM9o/eGyJLhSdcXzWPDXcDdpwowlApXlsFxdD8K/O97lRMRZhBzY4n2XENgfIB1yqpGBtSfAvyR
u3H+CAzhXvaj5vUNemZTo2Op3XmtsDAAJDGdlKPi+TZgQkDK5JB/aHLvELgoYfkL2mhEJ5thQXph
Z76akkJ7+9HNdo9IeTr3YMfy2lJGD6xEnn1LOUu+vZTL4SIu8of24mbqKolIQj/9OVwVNKpb+uay
7MS7Rrpf5AN+yM3q0qWJr2z0W8pR43l2hEduSE20R605Z9litBcT9V6PYOdOd8i1jdquogBphrnm
vh6fSZjstREpJwTgq7EG0MRoaHL0dyrrxJv+8LsDeoHxluhXYpwZr8+wE4/zjQK7rPOfD0dZwmGU
jCncZHt2MDUxBsKEfls/nvg9U09SJuuomN/RqBsWsFAlFul4y1vMb4R5NI6FBNknQZSEDNNwV9CR
SJyqhIFjHe6Uc9CjKhmkAoN4lb3OhWLhxoxucVxcVsgCCUJITCx6Wrgt7E2wg0YaYii8opDQI6wt
NgTaw3e/380PNtIQuIj0euAKPOgaaURLWCG178IGJ3PkXGCDJZL9+y7dR3AjS46wBO6IgsuVmrM+
ZPy7BUneJCul//WTxu8siSWXj3/JFSGhn80HktGkExfavWAHMjxouLyOn3lhtkInN83+/YT9ZqJq
1L75td2SDs5z/lPqhFu04r9O7o/CdoCL/PsE7piM9Yil2xmzdLHcXKrhi9IvIVf1h8zvlnvYm1IO
MeUp5Sdx4PJIUXECGGQ9102RpThP0bmTJ/BxB8OGp4YW3mervxSsWr2YzJqdxB8XkuoR2qpTgN8o
IkxuodGmVusoPhzjpvVhoZITUspeOvblirydP7gyapjv146eOCcW9DBv2JGE7qSHb16auEiVgpvL
Qq2u+koQYJrh0wmdmamrERD40kkKKKsXcWoqBpG9WeGMtuywj4rxzOGx3aZAs0Xidf1iudDecgko
smIZjecT0yX21bICwK4dZt0JLYyJ5eIXtSk8Kecq20QPltQ+g3LY+lu6OBvNoiOtdDPIAiQ+WTLn
AZbGc5qrNUbdJkRrUUGL5Ry+kA3M7Wjfrzfy4byOBlqFtOdnG02zYUzRCf5pC7QHxEOVWZw2K++V
OD6XlQTClWJfIlJkbUXbsryRhwRyfOt1+8PC5Jd/Mv7UvyeroHrUadjdOvBU/BVNx42ofS6Hxpq3
0ohJix7HoG9ppzz7zVdXNxT0w6Zwdxm9I9D8/S285z5pfLyT3Pz7K4kFIQEQ0OTkeH2g5HHi79rw
e6iiCBxxUGGx0xQyUIwHrvKj9UfUc4mjDuJk6GoRgHi6ZvgiNk+bVd2/uEJf8ze5eWxEA/TP6Vd5
G2Gou1VqCpyS0WY0toz8KqUYC+XDW7EFa0Im9dR67RG6GGYRIdb10l8GGfclhfHrtJ68eDNlvVes
QKi/7n96N7Abs4/pR+XiT9sXNLFRL/r/5kCbNo8RvsPyKmREEhUKH6g1bff+TQM/3SgyoI3N3Dwt
8HSMgPp2fI+qP4O1Ao58S7IYl9yc35sHJtKeVsgaUJiaAocVI0JV810hKl+22J9nHSBvtqe5oTna
FyFb2l8oDmQYVT3EECok9LDvmxex3H7r5zWf/sBKFGR5bpS9hN8/FdYBkAvkd8FCSd1zGfHv36FP
L4tAxUNnn164HZ8E9e4soFMJWVmFBd7fYJSVglAuEb2kZIJr4K3WgM78vmPvm0uf0aaubY2/L/u5
LzX9yfzJWrqknNArhwzdjFdrmFvjD5RSOivh0i7AFI+VTnzMgdf368tlglxmCcgSBvODVL13PITt
X+aMlxAfajr3w15/wO0S3eQ+KYoy8bkRRC4NAhcAcGOKnJRvfqTpa8WtRE9K/I67reG5eUgaG9OS
WUq3YtxlkDPjymfMeww1Z/dpi8zgnM+rbMhs6NgEBb5t25zxTPUyW7IROLpotmPb9rwGc9ljpYiN
NmdUZxv1mQDSlB32ptL8/EVpTj8D5cQBRtKb5rlTvNoSOkLkl5ijHqZB93F8KF+tYG/8KJkhMeP1
Bi3++G4Kv9K2RmrM03qI3p3rXEMc0GmQZm0/iuhpyUXa6lLczIu0EQzXdaTHySmJ9S6AdMSC9wNu
urpTz8knfj1ERqiqXidRraqqyBbKVRAPulGGht5oyEXmSG+V/H5jJ9QYZ7qoQfrm/r1xWIkaL1zU
aqQcGzEXDDnlxQ7/O/HDaeLifNE2yhwOedeoQ4z/N4Q1mIOKtU16tWGBVI1MiJ3MksdvHNCJiGJQ
GtAtiDWIc8LgIAjWw7/m3NPie4fnQ6gTKhZ0X6fL9uhXg4K/Gp+Zgtv4Ld+Khb0FM9GhkYOcvsSO
rf7D/xNakUutYfLHaIdo+L43kvI08NdnijCjSzktjF0gYZx4WV2pjAYdimI38tQn1o5iT4gH+33I
gFgHXeAgAXRqZWoEm6AjJfd+7CEKME+k5a19A1qDf6zp5WX9MNh9TG/f8Fa/xK2/Qz92kHcf9dlV
4Hnevg88kPXC1PQVCyj8Xi6vfI5Hvk3ec2OSI2ZqFws4xItuv9x4NLyTXeing/T08zsgva26+fi+
G8/EutvOqPUoLY4RJXKIxnTd9hUESAQNXf69NtmmO1YnINb11SRoph7nLRZznBWpkHX+wkj3bbi6
3JhFsr+bNdJEyMALZDiBO1nXYA27JE0L/y/TeNVGcrgyWOivYKHokk6jyMZ1brxoUJP8pFcEAJIh
zYYzBcpxIRKWwJjgnCqVP4tY8YaHdWMqzDTDOOMRIc7UXKFfg6ftH/0KNTmftB53BHohpAygluiO
TPw+6hSdi45S6mxqjgLB6fNW3XwF+iKBnThFzXagU9S1xutjtTsjZ1ydjYoXheh8GlPKagW/EZ+I
zutOaB4AwMECJBK4w5tPf47pWEnsg1p1Ix+kWrWSih281d77DMhsKLHe3AmxFjKwM3ZNs6S0Q5kp
2FY11pz6yLzxgwsdDzoraw2UpVc1lSNfat1LjmutxFSiH9Wfx2ubqdaxFzHafch/PK5TzdF59U0f
Nvj8GCJx/x1Intkhmf7ks0CHgUxZQ5utVgwKJ+j9iu5DUrFwMGh4koL5Fb5BmbGHnLT7BKcH51yq
CU2+QsK2+yc1PurGzZGKVDJ8e6TuKTzKEvkZ1kpBdw2WRUThvLSUT+Ny/6gxYyzcdJ0jjcybfILL
DzzSKAX9zfmR23fbh//MZXtidp6q5E9+qVzdREZqkC2MhzRWnjbtTjRuvFgpoLYPX+fm1pCLbDZM
eg0DsfQYgq2U5oA5hiAElQFxQZTqUJD5ang8mjzD+W//P12t7mADRfXNSJrk/5/NML/GoNLtYeC1
MbKae2gOfwbKJFV54Q7FdRPx2LHIdBBt9l5X+wE1c4LH/PWPHIis98jTUmJdHVIRcHx5eROY4oUx
O/3KjvWL2GH3ePlQy5BHusjo2wUqwo2jglsQYYlNQHiCTWd2wGUAu1CVU42NVFM9Nccgk74CTWW1
CJqE6u4imbn2PrHeKtBFj7i8wS6Mt1CElAlOqb1xRZ8srEINrCNjcFCFnmJRc0XKC664ZeZrwRNd
ZY02HBKfo+M6/RkA9HcqHfUQweAwHCKfyAiLRLXa19dZeHzYSICq5qjVu/CS3QUBrL5r1bVEUAbF
7tLfz90/Rd+qyAvdjJk+d1LAwm3fhv74a6UbTT+kQ4YquzbyGw+l7UPn30rgdbCdu9WgJH8r7y+k
WxBFIzcVOMSlgfXhDzl2EcmC4q+q3N/E76R4n/Q6Ni5IGtIfAwhFcM8qYoLc9FCD9GSrDhO3ZsNK
0GuZFcDsh1wfpZKbTD6VYayZiUS+IefIDc5plTSkERvl+Gqzo2R6scxk8tZSSzgMlgMQlR+Kq/iX
AAXPfZ8SCN/6+uHoce7WXcXxEqglRPO1cv201TGunI5tdj5ALy/2RDOkh/xEf/7PjW+YfFE7eI+7
VtV0wi4IqWVmnpxgmZT/UhngEUeTJe+JruggV79xGNs9U1Fj8zcsssoLNbRVihTg+nknj1ULv75c
n3cZNnQtuJubKR89W1CSSuO19BONZjKboXqJ9Dgu32nWYbvfoEQev8kS22sdJvqZHushUD0vWqoq
YwAYoQ/TChDIy0fJMBGMzJ7ICXCJFWsZQ1jbLRKRB8tEHUUEsgJGdqiUvhfS4yJJe1lLXi42wx97
n+A40w++YS4Q5viQnRFK8ZDoXbZS2bWiFILF1AgkinQ0OlVE019T99SRITTy5ZUsYcQMDUdr2NKB
yfFDvT0niNvRMWXlmtsk+uAG/0k7rJ9TePjWfY3lBHHJeFDls9UIY6y1R9qqt774CWXi5zm5TxeQ
yYeBhWj97U8GUVVZjAu8wFAwH3AgNyMnWwQxgZJ7lUhB7MpCyvYuM4TecnjIkUChd4nKlyZEtg8U
UhRb54wPk2Hke/xKylWHXKOBTgkviM7jKTIDCOsOsnqFZAbHyDeMAvhdLzjDR8TjvRgwi31D04rw
y9GNpiqXUPQ+3CdePXVA66P/gyGczChhtbAKbn1LG3y/jEzXNnPvnkQxmid8ws9VMrP/xCI6yoYi
mekugZ4RfDVE9ejHauHwErr6SwXFLe50zDaanoEGTG+KsJCAsZLMTr/DU8LyIi3OKQEtM08QBZwb
lBW0RI3k