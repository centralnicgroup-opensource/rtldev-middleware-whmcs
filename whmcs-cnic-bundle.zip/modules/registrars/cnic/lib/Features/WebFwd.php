<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqEZSx0u9KYunMdca/1HCgtzwZ2IIiNAvhgu7nvZrE5S1aeKaSEG9EhZzB0hFQ7URA+eJk9g
TaUa7AD743UOsJUHGrKE+SOxVHPuU+7k0ngZoA7FC/lEb0EyDD+LwGjUV7TYyb4ZgDCHc8v6SYf7
BEz8Hf6iURAdtxOwcj7WUIdPgiAAcYXw39JlvG6wAHaNVyzBQJP4NoyiTGsIb2NMHpjacFJ0bSJz
BBmQoCVGoJ1TgTpyfQOmYQ5D2UBMEphhJShO1RvSKut9IebCxzBCMPaEOHHh63tW1onsggJtlTcN
huTyk9TobyVZZqkNN3I+pH1dJ5JIPn8PwT3i6hKISaRL9Oa8GnBNClI3z23Z82UsXzwGq3WPiAXR
DtVoxcIpIcLox/5tH6hu84H0n+Bl1uJIPnCm2/1z65F4nBsS8NTyRoHeFiqEKpxuPkvg61ismAvN
H2RPJCJgjXqzCX7SSX0JAQyZs6IF82FsuBIt9Nmdn3MZvSsWhJRXwmaLMAvqL0VruQ5i6bzmjUCW
SzJOGNkHZHV688QOOJVx6yISOKqzgnrRh+TIlNN1Ib/TYireJ4aZiZ/EoeOXgabYDl6c67O5e0gh
EuE3Itx1mVcUK9hOo+lU3QA422Ueziv7jOtCTmWktUF2ImPnDM4gkuE/MVNC8ViGufSWTV4CznLf
roqNB+kTgiVZpPxuM/5/KKH3zEVAH6mJWVfxrCL1EORdl/IDesUNR6c7ng0nZ58Wi1vTs/C1GcdD
io+tt2O7s1PJl2wFrvVoek0cncQZvwTeNvmV7w3YRTTIaF2GM4UPFMtFj5bzKmpojvcvByiMxgOv
3YT9vLcrNEz20NkrkLe73V9ClANC5Hvb6feQED0oX5vV1gKWoy/8Dvt5GQKYfh1vr04l0W6emN7w
Kbb3ohaJ1rAF4M4YkUcKT7tLKf+NEoluOqg68rJ8nf1+bO6yBhzjl1nF5X5WDvah+N6AVNK+BmTK
GFUhns7QsCtH2gwDHV/Tg9AouomL4kUfkgTlwxM0IzKj9XvExuF4RZJCyBXR/XfFu4oCigcKq02s
O+E0CvMivWdg+4JKcsGxFKma/x9mKHEEOo34fgmTeG4T3Mp/zWnT+4LGdfYDXEWzG7XOlYbvfW/U
MQXRtL6yUqfAPmph6LMiXlgIyB/JDql/OKGRZIaWRVMXBmGDXNAr0HXGaz3Q9iN9iaufTJcKf5HB
A3S4PXgfatOl5/TQ15vDk+QYHiwsc1EmIRAsz3Jhf6Z5GOG3dbyQNVF+AIHV0vyS2FRuxsWxQc+G
tCFedI/o5Xz9TmfZNn2ceByAwAwyJPxBEM9OAGcE1KDkHJW/eedHTkmsrPrZ37S9vlA+MtbNca0X
2zwCIqWUpxt5Gf52Ly3VxRT2AEuXg4SR1svHpegS7T1VXv0P5PgJDWfQjgu4L/ArAQtbwxBEymvv
nsf6dQTX0eV/GfCgLuj6TqXQOSaVi+VUFlqMWJ+I+FZCuR3RJxM4VukZDjq7xXO5YQPHeQzJyKl9
0chRgsYlJCEcd49y5W9fzMaE4ALOskOqtaRshDYaL2Zu47lTw6U6Bq2MumLBtBGjCiEPP8JFN4Lb
FGvu2joZbfFjHEZPgBVYAhyzQqwATldYNMQ6bfOnK2aeyQr5SM9J6yceTqH9lHB6BsIROh0rINPq
KEHSzVrYBSv2UegFTlBH8KR/bmKFgNRWQnp7VOnpJf9+a4IGRfE81cLBeRP1lOu1qjjqMtUrOa2C
Vt/9UwB1xwMjQ+PU2sAq/XJw8PeSRR+3aScQXK+G+xv575vdL4BBIeNIZBh9CvxwizdLW5dfSaRo
PO0lD6xFElK84m/TlwIRQpw1FIb4JDbjgmGxRyHw5jKGCFkGCN+A70A3jwPKh47fnb3JaLmVY3M0
scB0Q0hx15Pq5sx608TY5OvVaU/dSYzO1jvLjkipFR9cZD2c7+OoU235RsHD3jirbJaExjbY3plb
VQ64V42LCw0l+0/Q8FDrWR2oggcUmEaQhKTWdZB5wBbPfuFzK7j6TVVYczA71l+6pElp4guP+a/T
4jg1NeA6UhSMDLQFfECbmTBjfPM/xfVjpsAV+Hq3FrJG88c/q6L3WDO0Sc4Jo4VbfXal/tpQxrrs
lbClOt6FeyhY33sFVWBBRmbNeJ62Sr5uILNuIBqnHeQu12BZBTpfwP8F6OyW0mgyndp2rGASJaz/
T0eva6Dagw/MWjQPODoIqIn74EN7srdM0NXBnKXOXsE0MWrG5Gf4D6t9b0oIVF3n+nVI2WhnCSxP
6M3C5ce0EHfpp8T/ejnCvTIG/Ig3qpj3FaMuqdrVc3Y0J1yq8VjAAhLWvFQ274cN4krW8p8cN/QU
WyBYJjotgsKCEGFg5sL2QXjS/wqbhrGd2MNvvCqCDwoDWpY8MjWW8Z/Pjd3ZmnXb6gt7y9NCwtqX
i1SCZGOZzx+dwX9/aDXTDeNc8i3YrDPJvMt0dPs94foRxvss6lAawiXuoIb6n4vVYh5IM45Tv55a
7zh1rHq43zyf1+8FmuMJFWDJe0EPLrPlfTVIqM2u2IWLVoOquk66+w+AfeMxBKdFfdaHsmJYR0eD
Z2ovaSHt5PtX73Gxush1QmRqzhFyOPhZ4Fs70/hqpDtRvgGA79SUeHHmdjKZhmWEMA5/t9aVqrPr
7hWOig0sQby5uwnRwP/Y9NNnPNk/XsTGeohsAiN41qHu/B+tw5f0dwtcmzXhgqF/4uDpD2KP2e4d
uTgNLjwCPRPq7lNKoQKFNbGAY+9YBib8nF7P4HXxr8gsLIC218qp6C7P9j6/v8BeMXVhqkpvH3VH
fnd+DdQGvAKDGGuJtPonw7I1yyFx5wwre+ODeN3tNGglgGoOHP1UK1puYNp5g4tScaz8QuAgkC+V
Mo3jNKcMzTlR4BtJ7yNb1Qaaq6zVk0k+VqR6fsFmzCxW30woX30dErfPU8Cfoqg/EXGcJwrmyA16
ViTSIaeTFIVO7mVcDhNfqDOdjxz8qhvZdDeSTn0fCamUPYIlOOkoXrC197dWZgVcFhg4mcP2ABMI
scw5oEu1DpPvaMPSgmZXMFfr7/+opOX7f13a1A8C77bLHsAd9jOf4oRclijLD/BK3GttHbIPOCej
eBgYQgDmfhCDxpvjUnkc893+kSQMLtlwvelwz+bGs+5tJm6+hU+MYfuW15d8xXZUM9Fu+HGxk41x
RmmQAuZDkIyCD90O29/jM1yS9LEdBXo2Ns+HPWOpV8r/AiwCMK5B8E4oho+LG/5FHqFExW5CMQXO
LdmUY069aHAOvgnYz+26z5scLQ7e1NzB4z19LqubRHlifaSNb2peZzBLIaGUatbMVHG4TkLvc+Ym
RBYxwoGmdv8COlJl44qHEx/s/lHZFo1i3b6GdGshm8PMLsF5HATeo7vPxU00sJPNi9kESdU039SU
wgdExLuFC/Fe+F0qcVXyuntJ5sff+LGrKxZ3ufCT6SSjChQcHTIJoi/rFSATFdwtTq1QPsIg3lIC
a/yIQBoqPQv+lthmj/PqG6xeFfyDd09KR0sL77rbOw3snxPA72V3lLVr6JRjSWU1lsCGOXYaYfEB
kWmzWurWa/rN6eEWCOwI8bn1pVbpH40WQApL5JK7h8wio9llZfJWGdGDBxIXZU1M/tmkguahbn0q
JjXcsC3+0uZC5bxq08LUos545fTQ25Lycz36U8ps/p7xLn4dsLccNsfcx7iJQU6U1R3xeiExIfsA
yRpZba35pQagFzGMmrFVnb0YatDHgZt/LDN4TqrCNJtOFQru4KV9/pRaluFXRo00xUrFhvf6esv6
oFVJPlHlncMXKM5JYJLyZPjEI7+x/HdlNsduS7NokDcscKIFIJZjwR/ljCoq1LeLWova9ixZrJvR
66YHCP7Soxe/DKfx9HkDtwChQhpGOBGrlA/Ir6vp3CkcYN5sDPKIx117K6UgLW5oUIVoInuA3FDA
tKBv8Fg0g82YxQFsnndoN9VKEblsRpwksPX36eb7su2sTS84GbzJCLT7ZLB1Yl3QA8/trejDz32C
Fy4g9ecpocBY/eg5VSCNSYUnun7fi4QtsaGRDRE1JrH3zhxvRQQQQyGVrOiukQ0JT57jB/+vicXy
HTPEK1vgYt7eJscGDhWOWDIjqbhRrEkJ67WeSbIRmCeKSZkPK4WudiEcuK0rR9JTN62N5fh7gzw0
8aWIGIyQDbPNLSrcLUFfu0ePaV618SYRHD6obSqcYKPR6dhrX/jN8yX9c5lfav6cRBnLDkW830mh
jfphlC1p6NDoiyijapzv3pie18yzSzgSwmHsFY9NDW8j8GvJTdTOdtD2rjo9H3Gd2qvwH04bnS6w
d/SJv8h5j0sI/HDwc5a5O4/t0I+YxHWAhz0OvlUeJfSxqeG4aOy03KW9tDcErdKKAiZNTQB4QccQ
1R9tJ9l3t6HVdfTYO2/7yXmzcaqRBLv2UefaXrTWMtV00TUoZ8p7OqChjdrD7Nv2LoUwV9e+A3ra
Qa7zzDQqZWlA3oSDCC1fnt/JLbxhdYgIsL94T6lss4xOAirZlJNj11mEjGU9ob4A/1+shwudkoW2
cFZ9s5I9Na2p1/BGCvEj2ioAbsuCz4n0QSfYCHLqmairWjeq5an9ph7OP2l1O9PmTJFx7omaWJHC
nwgr+pyrH0==