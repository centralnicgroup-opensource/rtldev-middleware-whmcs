<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtSAIWtbqauZyC3VBhUUudg4giWr3yXsHiSNS2NaZgNjayA5+duvKWWnGLIk/+lq/Mgne0jp
47X5+r3lBEDPSuJmUQBu0N6PH9JUQD9LiFnhhXwVfsZOSpLcEjBSRU92xz1OU2DdNo92x37+0GEi
zAPmr5gjx+GMyln0RVCgN76P+obFDRL8M5A3jFLYsDP+5EAdTFsPGMHoj/ry97LiNg1N7ftfm4qV
aIbPdf/t3ieZA4d2o29VKhG8KWGZGUJ4C6csk4LnBc5XMRATCsgUDe4RlvvhQq/psJQrsyzJFbTF
rrkdAlzUhl7f+pt4MBQ7NgnEBP96LG5eTYlKx/QBiTFH58QgTFMeYTU1UzHRXotBJbqrFSkBokiN
tllf1qKcO4yJhKLdFXo9VS2B2TrH/qYTQ7bUwP7wGOirpj3SmTm32bRDcl0X66ku3otmZDpj1TNB
LEky5WWzlHRlSiQU23ema7Se/1MWmDQ9KC6x8INm24UrbQU4hwX6aqnG7K1uB9vH18QTqhzJpnF8
I4XVUFzw3NrJfUxAtoeA7HX35gJLvLGQ/494kc6tl/H+GpucpuxhqW1tle41Zdqi68QMCxTTxnN5
sYeNC355KNn7+AChauFWzSRl2xJmdwCf8Ij+++d9fSgQt2t+EbjZ4wdeol1+FfG81YHdV6daHo6o
pc6uIlwjU/PwDYCuOuQF/+HhgnBL8IxsFW3M27ALASIiVPoOl8VEfZdLe4rhsgWTvpzTcgybjVJi
+662qOYyofXjQlWpT2fjDk/QNEPzE7Jl683ZWQdHDL9BYIlr8Kcze5FR/phc6Y69YuTIg0/eXfb4
G796h4V+kn6JueBPT1H1KWjFIjebTiDiy18EyBtYxJi4230bW3khplHUS5hBZWaKN3bZlQ5MSlJM
+Obt7bYldLZJCT5kCcYB9CVCQm1sMHMxYAZFCF+2C6e8hO4gpQzSDnHIdbQe7y4t23yME+SjjIWR
NqyhdcvaAluQ3INPPh9FXBpk9RN4zXqFdJbzlfbehVsHsZDRGTnOktGxC7lXNguN/eHRNTJfw9z8
lZcwnvVqqgPbjs1JKt7anZDxdufySYpec9O2sBEvEuTFdVjrLyoGmXAO75iiIMe7Dbfpyr2zMjGI
+0yc8cQ8AuICoHs7L+Cp72PX8zc2kEhmx2aV8hGLwuK8YdYeE18OP6J0myoFUB7FVXqzrBTtdR3N
a3xQKYmWmAiT+44FMF8cxumeyDLqk4vPajb4fcqS3ydguZ6iOATnPmxUvYC3t5wnhLH3l8qjSAjC
eWJLQVsAZz5Usw6LtyexkslzDghZYNpWwX7PMOIA0FfUb0mMhch/PDBqqFqzHQJEq2msXBqvjOU5
JPkxkC6HH9tZqD0VN0BHQfwHgyrI/BuU4xsJ7c1hpL14DR5wSAMG8O4NdnIHgznRmWT7PhtWUm9Q
xrevILZwfgKRHDOqXn7PqpxjZRqZuSSsQhfBBWasvX1dS5CcCCxmnAStxyJI8r22SomwPju8cFmr
SkDfcFgvsg3tqFgO2bZU8B203oLSbTRgzi2Lj9GlfD2/BBTHfGPyTklsPNRO1ErEAcc9DOdHh7Gf
LIYDhu7kGnZcVIz2+I3V6v1ivwjdkypETCKb5qQUGuPWt0H9VhB8vSV/CKBuA4XPnfTXFsrd7Z/h
brOpQ8JMzuIKQl+PhnGAOegkKc/nD+/cjlOE/nuHoilr2nRQUWCBst238gZriatPxAoyTVcDpPW/
NVRQODV9LVM6QKUj6VNIrn8dg21pyeUcUPk5Lgni2SIcoCBuXmeCITE+Thip6ePSA3OtyauZnhiz
lg3OIo2MARxZ0ukKFIyVX2/6Dlkb9n86CE3BAwzxqHv5Z4Ye5P5Ck4KpQMiEoBSWgDbzKgLbcr+6
mbRUYxSp6Uxrta4VwOdJcghMsrbMirXIx7jai9HRtjWCbsoYo9tALX8WZ/mgx+3ZPlxUDOh03O9z
SCMPBqd0Y0nFsak0Ul13V9VO/8o92KEP2TRzazJW431XlNxnFpX4/qNM+LePVjxkfo9DZMXqvCSd
+eKrHbu01wE257P8TVKbDFevU03mNQUjuFjnfRzRniZErslwrfwOWn4YbMmCHTAcqf+ONfo/scoP
FUbEWVl0ihP1GBPEVyFY9geopHjRf8V+cnObSMq5xlS1Oj+eqHiLIuf5ueT7xvX7QIrgrsnIP5gB
VhKRFIfIb6jrn9S8fft4eS5zZquiuxhy/r6wRlid2l1/WtokVhS3wrAxluiIkkDon7hhkpLHNRrD
esNLRObF+fH31cqlSmmSU705SHDCJ1ZA4qzMMi6UEHyrLZYkSxl43fY7UQtIpNfHPhNAPP040hZ/
ZBVCAFXrCcUpRsF/am+pndv/ukWz9HowqqXanReXlop3W1LWKO6EkH4WiGtOZPVnwifJqkN+PnnM
oYozWCGEIanaxKO5tNP0YG/uihhirON7QFrGaoRJrWki9BtKq1CRl1m6BRChek5T87bx1sXrrQfb
fR2B7itrVJJ6fsoaoQlil9cJvy+kbJVM38Zt9snmfFy58tg16g7pAznMI1BPEJjB/qv/IqgHA9Uy
yry8QbVFXPwV9z6p/jvNMIY1Qu8pBoAI3k6Es3CZSVEeCJ7vPje7rDttvGlp7ix/RjIqZvTBi3fh
3dgmfxHzypfnqjuJP+zsE9FHEI6lhS2VSbTgMypiA/IMXNT/wAXqCFzHGewmeMQXrapV7KIbOlPM
5vt3xOXjQG20b6XTn8qQcI7ZrHjiM/Pn62rMxxpvC3Ealg8FQq4XMuaUf16AbHwdDbhJtJ6CcTFC
3U+O2A+mtnZXHoSdOfSbs6zc2r9dxUjLBQNDBa5Oh8JpQAuNVebvrLPqzEehQND4LNLA6+4LTiiL
bIv0JLuXnZBvmv64gYeEDJlvrZYvsfCKNrW2pZlbz1xNir1FG9fbQnnUVdlOqe39UBhxjdpIZMKw
YLgF3VhcA+RvCVL+V8xgUyzcHtDzKjxK5exspXtTzVoM3BPowp9bvrcWUFjSGExg5rfrQoFlflsX
NiCb4D2jSn3D6qfE/tUvJab32u8NVSXIxNLufqsakSNarWft+mdNbS5Buhu4bP+pd2vkEK0KBgVa
niBewVZARwuH3nRHhHdp/9j9Xs+Dmcu4aiSn/gAj9e2FzRanXMcKXQhXZP3X/IOQT2ipK7+OoCkb
v9bUPD7F0xcLlIILTuCid0DWul6+WC2Lp6hcN2i12WfhsLQ3X0L8YsHjvVr8Z7P10/JZZec3QysQ
bxEu+JFx4FHJLXsOoasC4N6DwpF+QuEoOoiWdfouOLx/3uBCyjoQTHaH1v05KM0qaJJvwHZhZDJJ
X0nUzrc9k/+1tfVfhCnEy7D+Iexay2oZobT76285j2R47ycrt0oOOYcEmJCKSf5LCpeeURNmEyTN
e7B3mLb3CwYWLdtltTtf9lifqepMqTb/+xJM3sWexggQVwHSQ1fHALD5UqJGq1VKNsPhdGd+TxOT
456oa1yhS7PZIZPef+cRQSrL1TMuv+QstSfIp9gggfuEsxLZ/zSwkyUmNuB9QKh/6DoI7qs/kIth
l541fno9cWLu6xbcVebV4d0SzGP71dxLw48VhX0uNbZC4TZRJFhww7Vjt9XQjqa4llb4Uth12RWo
st2agkTg8vF5a2ADCLqakVG9jGM+8PzT8uyrQaSgdpczJV1RaXJyE1Yc2E4XYiZl7kILLdwH2npw
7j8LP9yvgbTRvWLqkvgmBlzsE43v6T+Jqz78rHi3yfgPzx4VWOdkt7M5UkYiXvgaBEt0ulL9mq0k
WJVf5S+CFzJZusx2HGt5MEl0aQAGyTpjzfNT2VNBUcHYlejFii/QcXhFrM+2r/eEy3tys05rTHUL
ojxltBFeqfbJXYyZGkFIWGgNzcKdKMNshjSkuhhn9tUXj1rn122fjfCd7Sx1/Ve0ETUmrli+IuP8
EYY+R25GPT1Bpbr7hjwbm/huoXImQyyF3v4V9cr0vcNFySchdQ3AYwReXiDXxHZUPj5H+tcG64re
1ACVH7a4fVCBhYA+dkQ2yLplyGq/rCKTqheVzOMw1kFKzNVzk7rrcbDmyZC//xvfGn2cJ7kIsHE+
Dl66NVkHuvWn5JYvWqrujOphVr8TgHX2a19vS3Murn1YdFiIyK8KDg0NLY9NP0zkR9U7iUGkeRcj
vyhJgqgpQVJLANysUNknjZ+DS9neuzNeIwf5hN9jkvcoJxAewvmq7TTdj/rhnxIk/EX+cYLIZEVn
51SbD8JUQNpVwSVxropS9TqZs1m+J/IJ0EHtbUDoe/njMTet6AnxjjKqp/5gtk8hdVXupMNN0hxC
maq66qfgES8tpkQJPs7W+5mMwusDOleGWP1K4hZyxhjKzt/AhlwbHBVaah7D/4LxqqA6hNy40c5Z
jSfQ/yWGVV7IfOHeyscd0b+SSeKL+zD3y4pKXuj3ejf7y9VXEDLYNmUOUmyCi39iqz/+eLvaOjKP
eGffzSHuDVcUqvEgpI1H5YXf/4h1nIC4z+yUhBMnlcRhL/UhUiVOmDgl0A1leacLXs8sBFdJ2C71
ViDte76uV2c1mqHf6ncx8vXbKRhFiAHV+XXGgXAGEnlnvZ+pXqRevUyJAuVoqP9ckH3UVPoayDgO
xZDHf7ME544=