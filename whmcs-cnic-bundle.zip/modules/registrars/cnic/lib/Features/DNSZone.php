<?php

namespace WHMCS\Module\Registrar\CNIC\Features;

use Exception;
use WHMCS\Module\Registrar\CNIC\Commands\CommandBase;
use WHMCS\Module\Registrar\CNIC\Commands\ModifyDomain;

class DNSZone extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["DNSZONE"] = $this->domainName; // don't fix: not ending with "." !
    }

    /**
     * @throws Exception
     */
    private function getStatus(): void
    {
        $this->api->call("CheckDNSZone");
    }

    /**
     * @return bool
     * @throws Exception
     */
    public function exists(): bool
    {
        $this->getStatus();
        return $this->api->response["CODE"] != 210;
    }

    /**
     * @return array<array<string, mixed>>
     * @throws Exception
     */
    public function get(): array
    {
        if (!$this->exists()) {
            $this->init();
        }
        $this->api->args["ORDERBY"] = "type";
        $this->api->args["WIDE"] = 1;
        $this->api->call("QueryDNSZoneRRList");

        $web = new WebFwd($this->params);
        $values = [];
        for ($i = 0; $i < $this->api->properties['COUNT'][0]; $i++) {
            $name = $this->api->properties['NAME'][$i];
            $type = $this->api->properties['TYPE'][$i];
            $content = $this->api->properties['CONTENT'][$i];
            $priority = $this->api->properties['PRIO'][$i];
            $ttl = $this->api->properties['TTL'][$i];

            if ($this->api->properties['LOCKED'][$i] == 1) {
                $fwd = $web->get($name);
                if ($fwd) {
                    $values[] = $fwd;
                }
                continue;
            }
            if ($type == 'MX') {
                if ($content == $priority) {
                    continue;
                }
                if (substr($content, 0, strlen($priority)) === $priority) {
                    $content = substr($content, strlen($priority) + 1);
                }
            }

            $values[] = [
                'hostname' => $name,
                'type' => $type,
                'address' => $content,
                'priority' => $priority,
                'ttl' => $ttl
            ];
        }

        return $values;
    }

    /**
     * @throws Exception
     */
    public function init(): void
    {
        $this->api->call("AddDNSZone");
    }

    /**
     * @throws Exception
     */
    public function save(): void
    {
        if (!$this->exists()) {
            $this->init();
        }

        $fwd = new WebFwd($this->params);

        // Determine records to delete
        $i = 0;
        $records = $this->get();
        $this->api->args = ["DNSZONE" => $this->domainName];
        foreach ($records as $record) {
            if (in_array($record["type"], ["URL", "FRAME"])) {
                $fwd->del($record["hostname"]);
                continue;
            }
            $values = [
                $record["hostname"],
                $record["ttl"],
                'IN',
                $record["type"],
                $record["address"]
            ];
            if ($record["type"] == 'NS') {
                unset($values[2]);
            }
            $this->api->args["DELRR" . $i++] = implode(' ', $values);
        }

        // Determine records to add
        $zone = [];
        foreach ($this->params['dnsrecords'] as $recIdx => $record) {
            $ttl = $_POST["dnsrecordttl"][$recIdx] ?? $this->params['DefaultTTL'] ?? "28800";
            if (!is_numeric($ttl)) {
                $ttl = "28800";
            }
            if (!$record['address']) {
                continue;
            }
            if (!$record['hostname'] || $record['hostname'] == $this->domainName) {
                $record['hostname'] = "@";
            }

            switch ($record['type']) {
                case "URL":
                case "FRAME":
                    $fwd->add($record['hostname'], $record['address'], $record['type'] == "URL");
                    break;
                case "MXE":
                    $address = $record["address"];
                    $mxpref = is_numeric($record["priority"]) ? $record["priority"] : "100";
                    if (preg_match("/^([0-9]+) (.*)$/", $record["address"], $m)) {
                        $mxpref = $m[1];
                        $address = $m[2];
                    }
                    if (preg_match("/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/", $address, $m)) {
                        $mxe_host = "mxe-host-for-ip-$m[1]-$m[2]-$m[3]-$m[4]";
                        $ip = $m[1] . "." . $m[2] . "." . $m[3] . "." . $m[4];
                        $zone[] = sprintf("%s %s IN MX %s %s", $record['hostname'], $ttl, $mxpref, $mxe_host);
                        $zone[] = sprintf("%s IN A %s", $mxe_host, $ip);
                    } else {
                        $zone[] = sprintf("%s %s IN MX %s %s", $record['hostname'], $ttl, $mxpref, $address);
                    }
                    break;
                case "MX":
                case "SRV":
                    $zone[] = sprintf("%s %s IN %s %s %s", $record['hostname'], $ttl, $record['type'], $record['priority'], $record['address']);
                    break;
                case "NS":
                    $zone[] = sprintf("%s %s %s %s", $record['hostname'], $ttl, $record['type'], $record['address']);
                    break;
                default:
                    $zone[] = sprintf("%s %s IN %s %s", $record['hostname'], $ttl, $record['type'], $record['address']);
            }
        }
        $i = 0;
        foreach ($zone as $record) {
            $this->api->args["ADDRR" . $i++] = $record;
        }

        $this->api->call("ModifyDNSZone");
    }
}
