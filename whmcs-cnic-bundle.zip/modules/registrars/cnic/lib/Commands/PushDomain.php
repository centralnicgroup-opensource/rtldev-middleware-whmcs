<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy99Qb+9bswHLFh/VNniH3xRhP8HxgsXo/qCVaDtYsTHcakMAYe+lgjGuQyT4XU0LMicJKpV
rl1G7ifLtusw4u5QAY0PHrwXrU0iJjw2S+lqyLo0PRlY6XPTe4n1i3XraGmnzzTOar3M3sQUtyRX
HcKcMn1QrrZxo9kLgR04eraQ3p/8muRoTvgqWnFaz+aDQJlvykVgndPuiOZ+ZZzdz8Jt4bX7YrBP
3DZ65k3J2iRtqeuQoyHN2FguYT3d4nx219CdFSRVXwSEvEPZ8/0h+ouhyRvJRLKFxW8VDqC018gF
8XX8Mb6EkRCJ9O6DDgRo7LIkMAT/pmQgAo4/fa4bfQJls5HZP3cir7LqwuNGxR+BWT3e397H+wy7
b/+vOh56lWztq8Ct9j47ogPj8xccVZJ/OhM28EgQHroAC1pjXOnp4MKByPScnOQp1wYFalR/Mu5t
RPFubUMZVyE7u9GQ3L5IdRBVSDGqgqCS98rlN0lACStuwbvKAHB5zDib6lXgSZyWlTKjXuRUBd3w
3S7hPJBtPcGUlRDLnV9urmHBgmJNRS1EuAtQ4kuOI0vz+Kzbhh2OSgpbovlHCXHqaoqzk+ZYN21E
d81m8W5i7pFmSinKWtLW0dN/wOWDY+Qy0mSCC+i7+lCojywUr8iwCc0gfD1hsk7GRCxeRgAjSp/P
3RfMZLB8HqkCpwC0iBesSNUXzV+jJZDGyKQiEEjydxSacbqxWu/dOOkxIcdjA6qOdja+k0j9d8y/
r/L6sS16RYJ3tRuwfSHnHHbmRxRwc1jpk/28q0jqsMf/mTqtanrRnh6mpcIEc1J9dAkZmwCjErX7
YkTE+kfKLF7axxyzChHYLDgRMu6sOtJIBH/QpCJen2eIK8G5ucly+ObpXblkjTs18Fyd4osvctjh
I9v8NUENZfNgYq7OvRhg0xS+TCiumOs88nyNg8AmdQtbQHobNBR/ne1u2MbZsswS0PVTACHYj5LQ
i4XP6Ic5VmmDRaAyXXYbv1d/AABDCpZF6XeO97OK07PJyRHCd2geZxDXdhoVu9R9xc5GqOtUbRo6
LnDFloBtLCA6G5BsaA5vt4qUO/JunHJAMLLygIRDVO52MNqK8DyQUmi2MIIGZcAxjpfuC3Tt00CP
eHCtmnM87GtiUOdGkNway4Ev1DI6OosVDz9oiRkYAa0PpqqZ4U2Dncwzo6kWfLcbtXHIIrLWNTpL
hbWo3zDsvSygLRzW7HWQo1vnmyIpG9+e97DlJpemG0/Iad63JVUuW9oCIXjVpBdCYwnOKIF+Hy9X
Z2rP1mIo9/55LDFYw70+axcQ/OVYs6nGvG13/SXUKUEeXJDnPA46H4en2JUl7FzqMzAlnm2TRnrs
TM9P0xzhTDBO6GrL/hw2yLkECmMHUPt6r69ESYjrBxv4kc5irn9TQoZqo0TmjsNVjrNruHwtuCog
eu134f5PRsbq8dyXRc6WRDemvsVFyesb41bMEWuJahE1SHWY5h0WvwR8+F+oBErGrAPHW8hUP+Fb
uySW2Tf0+14xqjmQLX1cGTMBTWUFT9PNI8PkHHG7RLogHwEyJ8t3kPueKk0SiqE/bl5i+TTrGP3S
UCF+2XpYBKyZ+LhuHJPnORCVsTqmnO7VD5M6wCWREP8/lF+TJopEN0vZ1+0XV85rVn6vh+G33qlQ
nuMGgBVFNJgy3kFSU276QIaKOXiluXbTjOLnTaIWFgimVTcesFZaG32U5U6dGdl0i1Jl8y0LynVO
M8ZV8T9Lryo6HOQ/2y6296hB+Ay+mZ05ePjteNDY/3hK4vqGQlaawc2XaIXJ8VlJLJIcgYOxk13x
ZDmwb1z8dET5WlPkaZfOeK/ylB227M+XfeFJqhQJBy9JtxHjoaHfhi8pwAuMSBndfBp/Os22esLb
bq+NzhyAKcCuAFpBhulFAFBS2buMucp342qeW0zi1s2GkzGWKhvy9MRtr59orOvjlPovifjlNZUg
BKGNnf+IMX3jNtmMcWUpaehEqGQyLMd1CUi3ogx/ScaTpqiIhmdkZ8JDbINKNJilKIgAy8PlJIj2
S5v0xZJ6rVA3JVCKR/bB8pgVpJxjrlCbdHdbGovOC3zsKmgj1JuFbwA8Jfx/4hLHTi6DQvaZ7wWA
0HuBSVYmGoz17/dzksaww+lD74N9oiHBi0iPBBFQNQfOCOWQWcoVG3bKMLF2WNaKkuSD6YdIFjsi
j5iPvUtLz90hP3g+xz/rPDgGgqlDdra=