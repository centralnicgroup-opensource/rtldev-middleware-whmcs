<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPurJrSnAiYtZ4+10xonV3gHeYP8nGVjaYyGpW7WqXT4mwo33GBitCMmO9VozQrlvWIyhUeKX
632CZ7wJjade/DzS802x8FMvQ98qycQDoa0eq7anTjAoAjCNiJHoyLh8spSx6s468oGEshLNP7Mu
3oI4/2fgnpL41HG+kz7g8UTWa+jEvsB+dRHGhNPYHVYEfaDlKw8mfOGgw31MgyzTinSgLply2d4+
Q7O51JiX93tAAjvW2BnUd0lgXljvQwUNT74KuVCCXb1XgrDJWXmeyfws64fTHMAGdBQtibILyuX1
63Sgw2Y94qrLd23X2rwsND45nMb3i97S0EdmORpw/oyUGYwEl8k35b0uV6MuxIp2hNFCWCAeLfVd
17bYYqPCUVLd3xssrDsdgSxTtzJdpVroYTfs68VN3XChxQfZEOB1wKOGs1MBaOOYKSpyACNDHJyt
wpWZmPT0DVlOpoN2Lon5Xd2eZiRh/c1HZAeIMIk8TJL7atX4UfMxsykOvEJPapS2406UK4Q5GvH1
La8qMQPgfGzjDLvnBj3Ls1+sRrUiqQrUdOvKHsO6cBE6bBRdeaA8/Vr1XkYVH5ULzZGjCQIbV6Wu
5Pfe1zFeQ7x1C7BXj4kD3amza3a6/P/w6fn2nqFgwro/mQT6YWyaA//ICHtH76URdHnPZ3BegPHs
R2tGhHHOIeS4z+IlGXYbXNPDrAdH5IZrT+LpSnNtaott7KW2Gz8tMueISltdaeDgOgKF2jY+Z5l+
StIZ/78U+rFiSZiRyXCLT9WwFWgHf40lIcg77Hwcv0CJjS0G5PNtDLFx9nicBTCvW9qvQ2bbMZwc
bUZmp5b6cxHt8V9lc/zpX/+A5uVqSrUDsBrOAx6V05x0xeAutGO7k1GwZo/5vknce5EeClChCLL+
ahYGhoTWNADqYzZNfK82w8XgxzVS00dq8s4gjPF2+kfKlHUaWzjNUaCFXDwygyjBZIXbZXLWFh1f
srPqs5NnfO54QJW4Ag3OTZ+halZKsgB0Vp2yd0VDXqX92Gn6jKymMBqUzXJFhKCrqNLv0yXNruJd
Pa4dK0mMXcFmYBIkjNuPj+tSktetfQ8bpx1RCXpEvg+aZda9KOlJwIbrWjnezE9vdPg5wMdJoMxT
K9GJEcUmqOO538PR318+SzST7c60PvXpZM4xS3YjKvICmd1/6N57qSNh3jJMxHH6LiEBp7V+GFjb
FNqZXIbLe3YzvBitfR7oyRLcApCNGFh6p+fBB+CFiUtRoK7hHV+D7jfSQq2xkylvmKOvau/mQXUl
yObbLNqUiJX0LEAYmKtzQkllgKkXYIuoH0QK0gejPk9aTXsOGBSC9P6A+wikgq8SPrjlAEPZWFz6
pbt/SoHnamRtkMMn8hEpaV6mU3bGb+qZ2Vet8D1nItCjn7hN4rdrZLR2DkthfG6bzIsZE1k3yWz1
JPXqW73JStsrn47RAyE3RRvPSKYBG9zEBNyhG7P4MPGKIrNCGXXmg9YDbu4l+JIocnHQZuigcQpT
rNCumFzwRdUpC+gEJzp1Epzw/gZi/bPMAR2drd+R0zDJ/nkAmIGuTMQ3k9oNBsCVfmgzT4n+2Vrv
2GzSEvxXte9nD9x6dmBZE7Sp1HEoX/QSk8Rl/RnIpS93RwFWnEk6tnjNEBvzi+J/IIRT6vqA87S5
X7gWTjmOJJlACgKDv18HpFsRqAOTzmDWQ/+K48yJ7VpWsfF7Wqh6f9fdrYNMzC7QxWnXIrGhBxBu
SzkZTvnbD5/mU3G/GCpSSsCpNmme4QALPyAjd5vUTo5ZPs7wxwB414t2maaNwWw3RjbDoFIR9RFz
I7xGJD4TAMTI1rRaPHkBjsOkSTIODk/bLL2sbZPhDo12fEQotfIH63+ocNbakNCR7h5mKwYImvgX
SaYfvLT4C0CR3WZfW6PYO/tps9WP5WXHUYEckeFMhzW73Rcw+A3LirRLBh/5jzMratlvJN5/IL5w
S7A410epX83FZIzkw7fzWNV7ErAeDIYPohlaiwatFhn6AsrFkgmp0V9Rt81qi9wjNKn4AUChO8wk
rcglKn7AvYMdfzWsM07KBTZfP598ef2E3kkN8uHBItqqHAp413G2OJe9iLk5yzDcEVDpdUBRExJE
+XUFczqAMjmF+j2CHDURdIjdYJivwU/Nrj347E5Hdb8+amGxNOi23XeJKZxivB+W0XccO6Mjqfya
qcWg/5b+MHNrWwFznY1f