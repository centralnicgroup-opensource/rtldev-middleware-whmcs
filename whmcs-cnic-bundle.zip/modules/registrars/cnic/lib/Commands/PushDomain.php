<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmMAPzNTLLmRc3dozaGxnDpdVwnJbTq/aOwuw/hVDAiR6FOUJebXLXqAQLymnvNRJUX77xlb
4I0GKvSCUiMM6yVgNTo832Ma4nIUdQ0QvHgeURImh50JJFR6LBbdph2oc+yhYp5ZhsPgJKlqXndm
udhRdt8FGLI57lJLe03CebYGgVkegK94Eljin+tbzzz8UU0x7tpN2LhisUzfk/eW0ihaUZC6vKGF
fMZhf9g4tpNAtwr+LGzUxKehRabXD+fjwUGn4LZ16OUBPrHyK4fycPXPj+zgtFSt5THTy/Rb5NkD
/eO//wC+D7pq3U2n4ZDtlfi58UzBzZ56Pqn4AmO6PfJoEzTLtJIjZnoHzOk+MKw51QbjIZYO+Lf9
yjknBMGeduAExFLCl51OcaGkaPSkreWQnCFsDsS0I1H5jpWW5Ha6dN4F1yKYHnHC2NWowOlB+yeF
ChmXQu/Sa9Y7GnNKr4BiyDkUPZBlzHV8rcHbvXaTOP9wSXxhL3d9DRIcKSPNqJX5+aCwQqalAWnz
HLT7jVzep6zrbGM9tKlsXcoykOqJoqmoQcLe8sMddqv1jjzn1mzCZ86W09SgAwN3I7f7jElPUWHt
DNKtjFTPwwDszGqlIkXINf4jIuaEu1jDzVgJQv7SMNg/YrN5S/cctfstq2WN4JvVSDx9Ydx+TYuf
iwiMa5L6s6DMQKogUio/HfXGKtER/2ztbkkazCXn7bBM3DEjfk2psI/JvDEq6syGEzR25ZGH7qeI
p2Yo3n7lribPPs6uTj6hYv34azRyoU5XyRcLu3ct4UGmO14ibNL3mMXt9SmQTezq/QsNasv812At
2S9yUW7yDtAm5umUr1mN1nT6e9e0+nyZzsMnV625D8UtzEihIa5nkJaxU28OpXzBNuOWRMQQEom/
KbxTjMXzQFO3yce22IqnRXlw4rOTWFyLZxRC7xsKWTDnEoHyMy3Ofa1PasD6RyUZcBalNEmNwM6K
nwba93dLBH+txRQilzqDLQFs3Y8xPGjrnhJPrNZosQ0HvVClffG8ZOmrP7zg9OQOvqGgw0988ki3
upIYLjV28+LrzDBaiJ9NBRuD5fg9p5ocsxfZ2GxjcmtPiFHh/Oxl96T7MEn6BYXOJA6vEHprgLo1
TxCVu4H/lbw/K9iYDcbhtih2ZrVTVSg/EDtI3TkLdprwo5e+SpaCHdFEzWYIWhLOb+a6m5voRQf8
Qw5yAP6Z11wbltuopJjLRrZ1H9Df2AjetmcYAGVqmJ83d6Ju9MgTYMgqwA9vA2R+PWRKzIqSiduw
78vKZfwn6tCzRK3MthX8kAAKX2HXK2HUJgqUGiIeuPeV3cOAMnRA/M1YZakB684gkA5jq4M1vgG+
DIN259BVZbKWFHZqutazjsuLILBE5eedXaRQr2eIQ4dbrbbzq8MhdxBWdHY7fxvJlVNd5LMUcXny
1oYDAYVlHLGRwJlYZJQXqCXlwGLYH2wiwFvOa+54y68SxwyF3ZNbpEeqhjQBpc58Hw1Cw5+nxoWn
gIl84OBf85LSS/rd3Zs2PdnmpHOkWmyqh7ms8qytJZdTpWk1nBt6Ifw0390dpRY2CdDV7YpBjMzw
72gFZcOR7jjO1UPzwd2CMFBJbSVfg1F4+QIc2vuhHbCWPe/fnLzUg7YcO9nNA6S3ZJxPYgCQteRX
HFY08JxEhgC4MxyhGhqZKLt/xjmV17nGmcUfFvPU4ah9W4YtMXkv56l+73eQ8Ey3pOpZ6vzmB/j6
GqhWWzUoK775oZ00Njp+M7Xc/C2cGhAOjuEvmpk89Qn8vVBlGDvydF5Z9mW4djT0ZKJwXUrcGQW+
hQiIUffo3nooXQyM+3EeDZGoIHrwEiTDacVD9HYoUENZlLxu74Zi5b2VdET34cBtSGa0wKMkKyhs
6I6O21TE40X+qgguV2k1c5jT84ijpa4hzaKQzXwV2dFTG6Z20QeUuQPTYojVTsBsbJAmZk4fUxbq
DbVNFt49GoBgKVDHSK1ybaq/fxDxhWZ0gwag5PiQx5qWyS/OhrR0at9BVHsLKXQ0v8u5IAzND95n
6JcNfKtiMglmNg54abCI58Lt0BN9y2atvbEHhDgqc2TsRkjbaa1jLtQQ23rZ0OKXsrmtsgRfGoG5
yjH56FUXWxN18ABwrpWVCFi8LTv/h15I0Ga/XVZRqb5gD8icrmtmqC4KXqMk+q/nsA5t4STBurSA
7GYeVuyzV2yfjknMjhWihLil