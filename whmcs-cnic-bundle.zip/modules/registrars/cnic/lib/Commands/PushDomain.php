<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzKQnhCWvJg4FQbJa2hYPIs+g9dntw7fCEbCAgR5bUxqrOM4Blwi/I8pn7z9Va9Hu5VbEZeZ
mjVoDtXPAV5zDHfa7igvw9MJpCeb3kpTzmK3qTm058Ycd/LSy18PptKFDTejkcovXifEd2wRx5B9
h4MmMNkOIZzxKbTk4wofAGuwJvPmhEjrM0vx8vv6IoXU4ypjNw6t419kp53/OLFIikdkFiVUbHRV
XkoRHImAlfDhHFmo72XCi1n7Ga7Igp04nA6b8IrGz5qzFh8GDNAai1hBy9R31scMKv36MkOBKeia
W+t5PqN/Vy5MN6+E7dk1nA31h5qVh3ZdL3kMcRyuLDWZ8KedkvGYiQ91kLN2+VJpZJ9VjTmU0rUt
/RQnjYdT6i1/k3sNuUFvZc5ecaMwrjqqkMziOshXEEMXKUsojrB+LyqVXZOXTmv+9XJwM1kk1NMN
xFCezAoPC9QI/KEbf3Ktu4uR0ja8EMIbtCLBT8P322PWxe+QI4wiHhBgTHqqZd1ekw0/RhCuSfne
oMLg8lJ5IBid0wbBouf+IGCG4fw+/wBh04xJC9hQsBX+jOYNnRJjUGRo8nSC/EuvX1x2NZVZNfI6
cv89Goev6EBxqxU3XWP+XVX1mtlQCyWB2KN3NV4aS5mmJmN+Usg8LO/ADdiFX+o3th/pN3sGcnYv
3HErGJX6NKZkFpqerRWC+HKZqEAGkkrB+uyLZP54whC1N1SjQYhII2LAJlRsRf2VcQcS3G7m+PY/
269+2s3/Eqehmosc+OMgvs8zsoZlzHU5O1uSWztt76hJIGiN13gAXoQfsL45jgMjLzQxAN6MsZjz
v7fhH1A6PwxyP+3h3vCzyU29HTtaELlmMp4B9g7oDdIed9NXW/udIYkANQTHKgVachcveNlVAlC/
JFaCXdFtu2+bKXZQAIFFv1JkSK9rprBu3jZl5x8ahNnCnhWSTT4NNkBzxnf9L4QZesFkoSWm+fhY
UFoUaynQbnWoG65cBPfOijl4Lm/inR8nXGh+zcGQNp4MbS5nFySxIat4t9lUbRYyBRb6l0A5vgwR
78PQ4j7BpgB1RdavqBrHoYJJLdXk6aOX+As/i/UyqQymRxip0eIZsiJiQIxJ4brmmf47eQox48E7
fsatnZN+PwaThu+VruODrsji0AAKyVoetZqj6E7tjNfu8CrYezn+i8bwYlJL5MI/xNLGIsXCWDAE
rt8VV4BcpEDN+R+/MhU6yQMsiDPSvDcfKupnCh0lYSwa6GufAuTb5AujwY3he+Jx8rWwnLTilu+H
P53Di++wGpa2dRMVb3WT7DKYgpj6I2iTK2z3ABsSf8O7gnCQ636mjumvoNN/hsPZd6/35kmsl1Fl
dNDbBqc+mVtSfHD0rEwEkyd81HS4WwZ1pGESzBu84vmJptFhu/uxniHYIee74ghHjP7JRykhr4Oo
RVUQkP8Posx9KQh8v0vAi0wPkeXwdbXe9QlDN4z9ZSj6XzBfE/XJG/Wj5bLgA6JsHl3SkP8DLuYC
MbM6xckoXgTKXHIwzASmWPHolKU3S/rjRRHgL7eruP5l24TsN4Vfqsm+gikf65zJIErh9pqEIh99
MCCYw0W0AuqIkQb98MAhhhoT7zIsQUXHk3diUV6v85pcn/JtWRddhHuITvwXwFwKldPRykIuYQbE
UA9eA13Nunk3PYqeVUSk9/ydGxOCdLqln/3S9zI++jmhO0r3PHG3s1dvyea+2U5q28hOxZ8beGEU
QnJkia/dGJXRcfzI8HAcwN/guNzu/iQHJ2lf2gMUwCArgvuPrw6R3oQ0xxpPWu4xGvvtA2EZHFn+
E0FI0SU03i3F4Z6XI1BC34nYH2l5s10n6Pvl8Qe1bGWuOasbHG5U48M5MKifT0rDaLK4Kt6J8LYq
nLALPvxiNCZffXg1epTNM6DQAyymzVOuK9F6hfb+3+PThMhFg7+BOizzXNmoB0IgHZSnJECf2WoZ
vYOz9h/pJ5jui8L4zPA/IO146zCNEPgPeTh2fTY/6ltmtX/S32T+3hxpc7qLVKSHBj84pkyBnt7T
z517HoODIjjjd0TAc6liKo1Vp6W2Lr203S7Rk1yNOHbxb+P3+mFz/RJh0G0t4ae3p7OUPKVezSu7
cUUmr1ABL5BBRcD2qdax02ePvcv8kpS+pWfYPUmi8AdMqIgl3pDQe85Fo0dzEmw+M7zYVamHLgrN
eZV0k9G=