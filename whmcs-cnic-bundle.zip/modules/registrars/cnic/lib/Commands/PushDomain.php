<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPptI+Z/RFTymec5l711uqiERLegpm0/boDKSND65kR03ew4YiHBAJDp+H/DpENiMcWKf84nq
kl9CrRtgkc4oZJB2wmXuNfvBNvHJCrUxPTo2J6mA9IeP3L1K8NxP562zvUSFOneH+/BBbbAXoxVa
USde5LU1nzcrxt1eHLiXiiELiMYH7gfE4E6h9+OkS5qoALXJ5tbtNBMI6ynC8s5FDKF/ngAd7Krz
oHFRpBB3WqdnsWxePEJ+UHVSg2Nq7RH5VZDZCMeO/1oYEz/3yaX3qzFtv6tzIsgPYL79xxt9ObT9
6UZ59cSLvZgXxHhBtWixyZ3m6kSh/N98zMFrXmaLOhpzKQKHvgIBC+YqgwNkbzli72PuoTQSxfXJ
/WzLhObx+hFqi1sjv/quhEUw0eZA+d9Xfo5Ujj8d5y88AZ7sQHK8Zf157k+i5p2yS7ZDf6XWBptb
SOxrDyYey51WXbYrdoHYbULjXlLIO/kuc8Rg2p6fkja6or84733FXKic3nWEhsQgcEt/gxy3GKi0
0UrxJp3/QDUScBD6Tdf8luPN/Q8r0uc7o/l2vVNOOnpgrc/QkHWNEYKkK56X6OAeiEbAzcNC7cjX
GVJ13n/YP+YTMEiV25vjw/7mAs0YPLWEBEJoFrPHUuzKB4u2/FBSBlzauQLWhKMna8uiR4coPBy+
ReqRzlXi5f9sYTzfj8tY5SGK5iESpVgeteEAdHUMJAmtWjN2GIFRk16Ojzn2vrcaH61jGnyuQbc9
M+Qtt+N3+GN4ATh/eivVykpALomSCyjs7hAoVwIAI2/cAyxnXza7T7uR5zCeCFc6+ot1W4YrEJKr
vmnPZOERuNeu8P+UN/eexo6IUPQKH4JwdfyARzVAHXUhAC4qAWHmGCHuugzOYZsdBhj2OvS+zOQd
0cqVjzS2tcCZZP3PKOMKjO9FmxMB+P/hDMBQ8IOno8Luji8jkIEwTWSDx2u1bc4eZBN2XmppLHSb
TtAkNAsg+I32zAHA/rxL3zvvWqTAVxYc9t1ZjmNWtFkqzOB2g95Ya6k3oTxCeWb/ucMgCg7XjeM8
GjGwYbe8KTQ+Pd4SVRrVAVqWH8s5tlDI8uGOs/TQRAueOpFekCQo6x4TcFsJEJkkKsulNae9P3+N
ZfMJEPM67tkjgRxBUkGBDuB53e2tI80qmQWlKW09TcJis7xZhJVXgew41H0kBYEYdE2tUge9wL9O
ZVWLiDLSiIbI1ZM3knH+H+qzuyZn+dWOkdkabu35zsifQ7PvsKLbyLZhsY5JXeiustEGfs8TwI2V
vBVEIVel8hxMeZIo6PQktQbB3qLoPuxGbl4PgxxWVW7fxHVmvXv96r0JNL4Azs3LHQlcuGYyIPim
MwG9kP1dOz2/+WGTtmy6dftnABwBI9+nbnCB4+b7+AmoIoXgqTCnuUsoroL5XKOKYN/t/uiGLGGs
1XGkfuto945Z/gcn4tE4fGpX16xesUOOqPjHYDirjyeluWgdGd73sHLHXUTly6CEZWcbauGl5xZq
++PWkdeWX/lNSZ5qIbHo7Co3LR6M9eoU4Rm6FI0I6dUu9r0YqSSoMztEP7waRlYCMKoFfYeWg3KX
wQrhrYQgoBumkyE3wMuzxzz5OEChN8iqPfTIJf21y+MTDUGYA6z9ePZAaVALWm436cbHm17n4WMj
9909ogWIabxHfXYTpPowHnZIIkl2gsdjTfw6EN6VtV9d3DqClXM9bwl8pJAyo6Uy1fbVRXx2bePz
4zD4q+0BFg5tUPngkjc1PhsXnZJL54tk0vsW8y8xwhX+Dwzn/X987aBOkFIOPTrom+faAI90jSqs
mao738L5rqodC6czr2/sljKF5FSmUHOd/CudUxlqx2YQ2muM7oxN3iV3CUyK1c4nVX9IzM3Q5B9E
nTY2ovZU3bkuL3rUFuwNYW0EbOtWZuHh9o/mmlrIABF3s++BHKbraDQBe9/BNMUQnW5MdWoG3k5s
bud6aoWvhnp5QddisFevPTdtgPU/EPDP+d+XYkbh4nAAuydi+1Bi1oZbWSUVvdSGWGiwJOV5xrkl
uazxbvbEDMBikUbwXjI9yPVJOTOvDI2/rvG4vOehCyMcWwK4WkZtg0ofB23pwKOVoAXjDnqpS0oR
pTpatNa0dyNMfWjW55agcgz22v11+95lz9Dg3b8rWXiZ8YVP3ijdR02Ncvv2QAgsmwgSo4Zf30ZI
f+zRzIy5V3TlXoQfuj3ZdG==