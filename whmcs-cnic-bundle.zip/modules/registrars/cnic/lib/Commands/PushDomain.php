<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqOayb3U2yTdfvTdSnyim6A83drbVdzZUyGqdCcDXa/Gve1KVwqvxjDFdd3SuYpWuUCfmCZ6
TLUEuRhTWRKK8vIsUiT6LcRsel4GYn92Wlb4X/zUa+hspz8z2WCcW6T00BYHw3rKHPeTb5DdQODK
SJIUwpMtPe1wgwcCWjRm6a/ZK2j1jdl7lAHIVycS7Z7aR400RRAFFX2KxuAliSOmZmS5dNpaHDmq
NA9YqohERmME2uP9eHKeyJDjiiKsWw8J515JQbt2LTKCgJq4gYZqF/+XpxxMEMdmw3C28OvMYiBp
41WTPpFQ6EnWcyjM3ckOB/CENECklZVwPLXkLT5q/eE7SP4QBrgMtLsSJWaENgl9Vj3ohOceEEo+
4jLkt4Yr7xP3/HELb6OgMPKA2EPoMXOv7xpP4lzE6q4Yb/5EjOGoTI7+1wa00TcRu5iNZIa6SnrA
/P+MztfAyxHvDDNsuFmRs78ELqNY3DonzDew3qwF+zRgPwkzh/i6D2CcoEjH6pZPGTJCkblUmuRK
lWZk4YmQICa+vCZ6/UwghAQswvdeOIfolGjDJ71CueFkDWUZDDmBG2BY1lLxlqOnHlcfDC2Jmqea
b2YUFX6J9lU7XuP2RTfd2Y1d7aM4K41F1QmsfSx29KYG/73238StShxrrQ1SRH7NtNyjKP2+oIU0
SFg3tMDfyDCRxzaJ5NMFXps2QD9MgIjECj/U55FTPjB7k+C0sCwPAmYEcumTimccgZhhZZDWftUj
469w5kQAwPsVcWeDe3MQQCeqdqOZ4NlQrlS5/8sJmmw7RaMKsB1iQyrwO6Cqe5RBtBJp/wl3Hm34
4SUCEtX68CvHNimOq32QL4ExymbRR5G3/znBGZM1xCQgT8tQcMb+Vdx/z4YXglfOwmMiX+YODkIu
yYAy0EJkw0anFvt49kpRzS/ysPYEDnfMhKFQq8/+3hYkIlnp2xzrb62bmO18Kq4C69U+PnNzlqzc
gkaapenKOmnnUSa2bJNm0OHU/rRZu5bhZyCZxnLQIsl3AImQVCevXsP9+Uulc6tq82qB7tUxWs+U
oZ9jz+mjs32+wheB4+FL73S6oSBqNaBdV9TfFG8iI4maipEF8IOtImp8l2EOy+LD080KRYGXabXE
wPVq/3z+uAxMEt5g5cy+CUNkWkMs6rdR55JZKKcFzddXVhStD6XC93KuhI9Ph3s2TiQ/b2RtOQrS
u6RNN/AGBzPMIiF4KM1OIQ8FUFCvKlw1NjW4EjoxdOi83WuAe5ZUwhVQaEVYk+uJbR3pwIKk0uAL
ulP8IanIEaPJuY90bY7V134j5zBgXEoMosPaBxt6B8Q5GoHUKQooRdwmCsVMsZ7/T8mzM4u+iMa5
Tp/OC2UQgx0/E0ISSjJVRPEmt7//swefDBVMKRX8d3FNw246IuD0pR1uQJyEo8ygEim/Xpez925r
Eog2ysUa6FvuwXMGnebKpDmUH8NM5TW47AY1H5Ic5ttje46sXH/GC3Haab9GO2zvdiEvQ9dRcWpK
9AnkgCzdSVGl8r+lFWYi6IXV9jN6l4UYtomVB5n7c9bvmO+1qWOJqULeoM0qmehg2LDOGz+qQUbq
KaaJpVcU26gdV+IqgjSnAqn0kDxiRngIzq1paWIcjHz9RgO4CpDscO3IJnPzI5eat9PMR+MFpldq
bLT78PYjUGIf1pP9znsQ1fdCGmaWr3fbU7e5j0M3GaNm5dF+Ube3QTuQcMsU6dSU056Q7SIoOUQa
vr47dG4GuCkRDRad8ZslSHPYSdAzmhRqoFcbWquLLybcpat9Z6ROArIR/AOW7QCl35baHPYgU16I
IFq9VJlEWysm4t5xGjz31qJAYObNp5r7V8TxQI9HfjDQJ27Ndfe0W0UPlEphle/rLEH1Iz6aU5Ar
+wBe9aKsp6LTKP/oQ4zKPZEGvPfVCrXyZKU3SuUMr+iTxsuobfIMdM1hS0s/lFRcykWFwID89dOd
ydNyqhTpO0l/BZbC2DTPQv37hl5CVVQrdBbW3lGnIV5TZB7Ysn5lCbnVa8HKXUfW1EQOwJjfIYRN
wLV4T0KNjLtL0cs94aYq4OTfperHJP76+E7bcj+lGU+3oQDF3Gv54u6H3PrjtihvqQHMdWOcxb4O
YP3xehY7b1e65OpVTU6HYSStBpgq+aaLQrXR+DIFQCsqihlU7m3F7WrhJYnfm3eNl4pmMyD2jwIt
unLaCDAPr2UAh1F0KDe=