<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+R/erliV0EWmtcFpiy5389vk3GXho/bkiC3zk0qtn1TpAgTXK7e6ATAzJLDObYShgDUDnrJ
aIyvh1JOyKJaJDC7Be4GXNGXJZXU5QOmJFDrEjxS8NL3LhzNKcGJ3zCLvwPDBSAQ4W6zU+omlkUm
yugz6G8X33akrwx5qIlloARklxyTC/ZHJoiU4mRbsAdADm+w3FalCxiPsaIVPstxoscdo4CWb4ur
RWEItb34GHQVl63Gd8oxQXl0sP3xsI1LWitck85O+cwyECSWxOCY2wa8ffCo4sZy5f2oTdOwi7JD
Yi4hg7/1G4QKUA6d51mnuWIIJUZDJsDQEmMumM16vxVZ2zgj4yySZvRskIJV3M7pk5z11gnL7hoO
7HxU0Z44+BUotDIgiqJklePEw/0ia2XCaqPBsMj+UgJgVzea9TmB2RwyikYBkCOhABOnm79ZdKgU
uB6Aw5y1SARkkhn6fJMA0UxXIRan854Dj2MVm4gMWPwi0kuKbaCqMCHdD0WJQqSMpZsKFwDS3YcA
VcV71sVxmm6cnc01ieC3TlBwGCPb7lZWENz2e9+kQpqbwRwvcceAxWdRvU2oFjDW4HcFNQZ85M9g
kq/9gahyePhls4BA+YzBXiJN1JNHg3k15TuTtV2o/v+3Ay+oM/+sPj/VdEfinm6YbtlOsDmd2wdR
Ax8LkZ5+aW8WUUFNNpLui7Bo0SrIfvRo1L+0OD+6jBsHzNMQGpil9UBHqKE4OpY6XBbg3niViLHH
AzTllG2nVnJE4YetiVtIZAf9MXsOWeekm80T4DAhpMU4dJf7pKESKZHBms3A1AYAPSyb/6o7iJeY
acS3vUO2G3LidAHnwh7YS4Gb/o1tdZh+9vcmM7aIqPpWiOeJIigAsOsAH1A1PNnCdkLd881ToeZj
1lrpP5bXyQ8VMriLk7Qhv3tozLkAMqsQnnGodnywnmQSOJlmyY4PPrfk5XXaNPd0B4ImSkj/B1e9
65qn90zTgyPK3cgOkXGR5OWNA+vbuCrhb6OCy7K8BpHchP+l6AHl4a4zilVgzo7e6V8mHI05Av2N
tERNKGAr9znNRgFWr8qGfsAjIlEjBrI6tdWUTUpR+dFZPF2xsqs/LQQXKPFoDgkRWby8x4lw2Zyh
MwxptnB5a9WuPvcUJM98sdemaRKbBz7IWt6okGIp3nQxAEnj8y0B1Li9R9ji+4TF0AzGVYzr+GMG
fnDIJs4NP0JgWkZDOb78B9GxJDQ/yjEnrBRyz4wLe1rtkv98IGz5KGSeIW0ipgHEbg65Ci/3pUV0
P0Habp5mhDRyYsox+Y+4kYYqFWdsUunM6t4RSP2MRkps8/KW1ZxYbL2pcvtXISZ4QLPo0wNR0R19
xKlNCenvwWzDUA/NOSD0T6wfIY4Qjyupt1U9fOBCl2qYLIi+/QakqCDwQWixHgV0J70YzHH1Qxto
zaIbTjnU8k06sYhry34tBjzhGIiLoJrnSaKCFmvbHdrIgnWog0bcR3UZpSAKWn3CMBvfcLRaA04r
E/TzB6OI9p+P8kNKSulVInUEtIesis0/xz2N/aTFLWGMBJQG6O1qGX+fzOw3uxdQ26IGmcSCpkbN
dx4koC0AMo+hXmHcFWtyvd1ZhVTN+EPgq0zL0AVqv0cxbjYYH263gywNq74zTd4LyuD4EW6YOFlx
3Uod7164iF86WijQvSTcHsjE0KI2puRPDzxL1n8KPyochXy0eukLCOrh3DVHfquxBP109mqU0Ail
l2mFLFSrx4lk3ZCwYjbGJoe2xbb0tXRMB9bhfM8aV87t9xG0J/zR7Qe6ABI1wOuA8qycT6OdYRHt
RDnJY1QT0QuG56mXRDH4wYYaKF1rHK4PO2g+eWn1adkoguufLxk99/lqyCnicXep5h6RH9iMrEtm
Ulp1i2+5xScMyOfMYfbWWHkyLn3+YQeg/gaSw37VGEtYEIKwuahsLIGKrDPWdR/DWkdIYFI02vwQ
VrI2S1Lbl2xlqyvoxpA3ov/987AGeD5uyxkDdMCTENosEm3kS64Ac2nGsGI7dWO57g8mY4HwKP0n
yMHNM+ulXh6Woaub6Dkym0maRKECs4nVIBKrx3FfyR54yyF3MZYQbAGEKcErvTW3ew/bNz2z39bl
Z+hFTIdwId+QPahnx5pzZXy+vWT779fGV2gKlw8jz/W+w6urZWLZ6T5RBrQLhfmb+dUYMAJR9t04
7CsJrowyAZCF52saJBJEOG==