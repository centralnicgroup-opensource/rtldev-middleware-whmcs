<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuNsLrXCMQoV2KN2Uv6/02IIzhCK8SyNM/StHvnZ3ro0azwHBdP7gAvfp48SdsPwU7fJnZ+d
jd+AfPoOZnrJJQSuLurNtOYqHt2a6A5Nn78ozh606bddCO+ylQk/pblTChdLsGRx1So03RypUeps
EURxsu7/uTtEeKS/f3dEoPK5ZUQ74A06YWF47/DE+kECgd+lBv9OAkm2+G6t/4O/OCQwmmBIg9K4
WeWpl7fpPaRFIPqECn0KbY8k0j5YQ1b3R7wOS0vuwW2FAIcOyaxrHkcg39k8PwHWPCqLw4X3YQ1c
mRU7VrA9Dx4ljyAkAwWcCUeUB1Pzzv+Zu9yVtxuvWh4eeodU0Ll5Lf1E0AX5nxReKoy3axvlCNcL
PgtK0iY8pWAy8DHIcoauRe0dJcw/K2oGQvcdGIz+d+qIMYHgjKpA8S5PCWapuz9j9O9BqmCfRRam
GezdyZNWQDacFOVSkfu4WoIBdJe2KmXBNdKd742o+h2UFOT/SFcb/gtVLzquxuMmtVPX1WoARIRo
CwqEDpgmRi910f9WLr7WLr1YYYuh3pZRmXLprpePwGmdib1vy8n8KFtJAy/Jmw15Dc5z8ezEefNX
PffIZLpHBFcNA5kDA44VtClqgCHeGEXSSoCMqjKx0xJaCmM/008k/r2XpOX8eaKFlSLmgDzlLvRO
BK3AtUVt+SO+4XQA77NoPaR5liMhPpbhGn8FyeQJZaIWw2wA8PlUpZRtyTsMKa1jn25/MX9QUM5D
I5Sp3E+8jBOWQq/EhrHfqSPJ+W9fYcCE45vmzgTn0rVdG7X1O955JJ5N61tJ/soTcsPZxDmchmYw
ZjFnMpbQf6I76U0QbpVsmSsVG0EThJDDu1fjQR2DOMhZL6OL7AUoX+3fXvV6ueB2QdVlPdp5T/YS
qAezhUlqbeuLgf4M8B/1IBQMlnS0nO8ShMWNgH+UAENII/8BiYSvQMV0YcpxQBThIPOmSAKwCqnn
qkuUGgNZfOVbKoGC1r2TLd6aKkCNumnpXFHIK82bQOjOWBG4jXcYNx3QPXJcm2SKCZRaeZs+NUeX
SH8gsR0tZheI0wiWik1gJ9HilTy7CEW6BVE7B6md6GXd0o0OYHxC7TQ0Sq2DPU1PI9KiahezNPaC
VWT72oCLcmLbmp3HQoYKfbAHi/NEBQvWukgAPqGhh9zk6BTR/FDLdqgxy13esUociLpfnhYxgIk3
Cyp0KQh61i1lkGGsysNxaf/13tQs7GxJ3nUVrioWkJFzN9tsT1StcY1LoujZDRSgDdUGnjc6yUie
zbCa3vGV4okxwSY8+iGWyJwrdX21hObTbxT9EyN9Ld83SLNTVdvj0d2hWZ7vwMnLWDs+RgzXQp+c
rzfLZnpjgm82b8X2xdMwlo387f9ZFpyHCqT/+ngAHGxn+6ZsZdZhy7cRU6F08HuwnCv7yEcHLf4Y
3VCVIvQVbbRn2e4Ur53I4HgbFb+3sh8OdJ3L1FWOJIabR2IEzbCIDcsDhZJ1jimaqwbY0I5Yvbch
w9S1R4qQnctxhGAOLnP2pO7i3w3mbqgu3VDrqstL5l5H5sGnkaM9QwZ0iUAFoOjbUX89Y+asWMUZ
ZYKsJ/zuWQRHdy3prNmab9FkiIJDAl+zA2ObKar7px+ErizrJ0ZuhUmVBARMcA5n44RyzudAgUpg
//pb8zDjJeHzm6OC+QjB/Bhp6nllE5eoXKv4ATs7Ok2segg9RWw0XvzyPRA6DZzoObhChdt6cCqe
IbIcJKlQ7BuDchukX01D6FXnu3ROnrw5cU/plyLpbFnsZX1oCNhZousm9J+Qhyr5/mkZB9rGCRhp
YtySRBP0HBFMazJqBmCDWcfIDLNbVKrhbBFxWYip8MeQ+OpjWOAVvNyta6TrGPoJkaY5O5CJFc8G
VkJptlUz1x/N84XHslsJNPECRMWv/VcYuR/BgDoIfVNg8yS8nCvRvaTgfy7UV2nek1CHpP/ZXXR4
Hq8b9u/nT6JNrVIC3h/tz6RTTyOHJ+Cn4xIfyKMZQKGVzmmg7V4+OgcwkGN2R89oql74Y8bI1Aer
BoLz5iAg16sZa71UAl5WheAK8D360zLsUw2v0ichXXgern5NYZFhuBeJbfyHrq1MVI5cohDcDjNH
wTDv7lgPrDE6OA6rVuzjiKU5+PJPJIN6SuWR5G7Ty/E95yvaVOdYKiP2+UGeDyVdvP3jEYkS72/f
mMC7XJON7Nxr+5S/YHZIkdbXAEkfS/GTc4UUM/LmJoLYhAqtNmgCj13J6lG=