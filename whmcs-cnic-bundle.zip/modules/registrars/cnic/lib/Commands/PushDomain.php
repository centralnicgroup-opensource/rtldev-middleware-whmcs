<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqgTDVi8O8xyrIwWs0fwhp5+eiWxrhxq7zDiI9wmJ2G+OLmqgt3zBOijLNrzLEDx3wPcMYHk
EVWi1dMb1a4nchbOq7Fgg5GosY9lll4MbC50kXPTFSK6XVxP31QGbN2HIhR/bCx4R/zv3X7+yj8/
4t2qbqoiG71/0OcQizSk4GXY+3XpKLexYql5cGQYwc5WS3dpVZCGxum6nYN7A9FcWb9GH1XgpTda
0a14AemiCUtkJiwRAeW5ViMbX4cP6ZEfmTJxMcbX2x9KEJJqeKQBACJ5XtfoPE/2gph2Ll20u+UE
1qcd8/z6+cstX6cKjK6x4tLg4M3NtJJDB6PFh9q6TP+nKW2TZNboQhtoBPioLXfKs10h/AzHA4ec
Jfo1xeKPatYTuEMS6wnyHL2UZSu1Mxo+1Nx8r11xjgAOvctIoBM4mLq2Rr6OXVEssmUb1sPLzAv5
LIBVEAnH9KMewzSDg6cwe6e2oWlwdgygbGqn+wLr1T2wd5u08ST9aefET0x9G02dVVqVndDsgm9/
l+BoX2AQihMbBmx3gAiwJPJ7sXxrbbNXrJqjUmLxyT+XUHHZ4bt/E8yxMsUGCPHcUk7ZSMPVKnEU
wByL3YbdMdYpx8k27wiQLRqx8STwS92UqjWX4Rs7GJrXOQBWg3ea/Lj7nq+nTehni4YJ2FLNT/TB
NBSeE1oh/lrfuoiIbcC/LgaM0gLruwHZ3OWTBDrZsaIjtBZ2v7UdJrjmWEIqXbsxTWk63hwo82HB
8qdhaY+mzduNKmduTVqk02213Ib5px2pRcjFjfabpQMf+gFTRFXmOqWZhMDFTP4nT7VhWJOvtdim
sQQ9e1TBeKiwJH7iGOOJtZUZm+95TBBvNf3iMdEWOv6eYRDMLnlromUJC4nJQx9RiZY0972BAYdS
k0IyRDppa6OivOHfpUPyEdLAvFEfnmb4wOyMWjPj6r9Nsl7goU77f6T+y3WbFOYRTcws6+zSoiHn
OM7R9tKA/8wdPqx/ZQKbct1onn2NCWEWbvG/3sG/2AlxXx87gyWJUW8+5AhTKYNWLpAFs/Et7ez1
ryf9sVyuxTAeNZtVquaS/CoGoNoPo0v5bVr3/w6O4Sga6DeXxlEOVO+zGzL7g3dp7ONth4Hjot+t
2wQyiu7gv/9zMVVZukp3XuQ5a2usg6/v/L9ss/rvne9jEUU2t59C464ul6iwVI2TMtBkNl/dTvtL
XTHnFVQOgZ2KzdMU6HZ5qE9nScgolTmsDvpujtOa+U0vuvb74q0qGrQkWbNTky94m0q1SXg3aggB
SXjNdn8dAiLRrqxj+ByU/d5h1f4bqzes5euwdl6EjolTU7vR8rkh40rMgECjNMla4+EX1RNmaDPe
EvwYr5BcOdvodINWHjYSiBRxEwMp3oqmbwTP1lluS+r7zjKx4auWTlbkD2dvWiCnrdA6gUNTTZJE
PNBtRW6BZcP4jBD1Rgl0Vpu9u2P0eBqzNfXWxlkAk4AJCN2XosgJS1n0koWBbwbqGdu7j251xVgc
kdwbg3uPYjXiFutoppGFvz+cCWvumuJ72aA57T4cLUY/gB4nLx5q8lwQfkOulGUOaxSFsXyxXv/4
6QSKmHutPFtuQKqvq39y4HM2oxd3EIUb+XkAjgQRw7MkyjuDfgu6u8zAuVlDIRjNRm3tNLepimp7
1McaCjHq+v8k216mDlSFyVhu/2t/k4qgIrn6xKxh3aecQasC89CGGQF26D1xtpGQu2PKvjS6oc0J
KIh9MPylL7ixvIX9IxUjO433jiTZS1E132UTywhtfYqwrf5K0mDxvjzJrmmML3RMJPygH/fKbcZL
/Os4ZD4RHSmVhrdmwfZCbnxnhe35LtjjnUVy7fKYZPcE3q+q7OAXpVzhbi1CuWix+S69iY7bf+LD
fe3zvjAsGuv4OMz/C5BJms16rXeNORt4jVClrgQyXoxljUNZH6Pu15rLBtZkjXU0fHCL0ANuT6Qs
vDF9PaoCUbbVw7K9vjBgCGCuiOg6LTlJEfzHGAMvPjPm2oF6esnj7bmKLstv59W+MOCwTGTwuDBL
VIZcKq6OHC7siB23MItXghi6b4cNU+ogxg1s0kzGMvoax3Hj5Srm1ZYyjbQuvCfViZsQSrsSU+Jw
4mtUkdkLhzCDjL3gPle+GwypyqIg6xinVPClz28nccg2mCTGcr1w8MopptUnRtVF2QwF0dwPRxKN
bCk0R904G9Ep6A7/5DBFfG==