<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+wJYacQVGzkOo0VQXuw6SsO9bY7ejA9a9Yupp59qn4s39rOUznbD9fpJp7+dA+3Gmy1yfNE
BCYTMQZUtTCOSk478voNdimLROSOtFlSpFjpoHIzwNkovsdnt7CvzMZcEHUBAMV08gyHfoaRikFe
Pa7hcDhVd2TqMuQ074NjwfFDHRk6CpOANr3Mb/5ogNQuPfByygWPQQw+GUaWa0ytVr2T29Wh2SoS
pj4sZAGijWEu9hEi9ovZHnb454Zc1GJn15TlxIqRXP/lhvZxOR6zLnCA7hrcwWB6XD8LChmf8aXX
FeWYBxzGaHy50D/ApzsmTS1HT6crgxNDxsgxJD77upOGBrJEztoYUb/h+Uo+eKSsuy8YWlCVc+63
vfTpuB9tmQBNquv8/elv9LDl+Ozm0YyCVjLXKj4QUH2CAuXtuu0hP0b1ePsUWisYUNgzcULHzAEI
DYuis64dTPrwD5zO2T6kDplhcVDkx8g5q69wETQkvrQm6mMy3QZqigNKbucdaNU+3UHJhvvoNxUq
D3y5MmbaFcieled2mhxMMLjs3GbFE363Fge5tk9F9JcVB1h4Ab4kdy4eCpxUMyh3BrhTWzG5DNWq
McuYtUxhgGN702o6WWVy1xx72Cb2aKasx05CukZ/Ez9vdvHfzr5RPghHlOajZMiTliEAAkhJs2no
ULHZMtl4kT9zWSCLkxrJOErPYbEVUYTl4oY4B1BaNVOsBESNWiYsDtOCPTiuppKkCHGnO74M4mCP
kCv8n+a6vIUa76YpK8TnvP5+0e/y0/XWkVxnrSVCOACqbwJuIjgRgeKZBL6BeROhW/XNVl8qucJ5
2EH3wzKCQbjCfUDrOgpfTi4iF+TeeTaHIvRwgEfb8kS1HhkCjw1D62856eYSnFrtPKohbu/CnYL8
DfzR/JFrL812Tu0CvzC+wMknpFg62xoGh/oqQkX+UZ+alJ/3pwf/AGfWxkZjgjnNbeBvR1EYI6Fs
+Mak27WZU6jCXLIxwqWv4V/wwRUDd0us9qGDIJNRrgJCzq9492OGqzNrEX2v3LtMnQdRqEo59x+2
g01pIcSuCRfikOxHoHZ5g0bJtscf4b7PksLY7sGAr9LX8LHWs52CuCIHBHIn3ZBUoSOjjMpBAccD
UdU81WX2wylYiTyKM2XmWIAuEEc89hqec9SP4gsU42smw6P9yAkL3k5PXiElOANIdeg9j6JKoKsc
X514piA3mI/rwS9W6BVLzpiVdr9TQcYKBbj5s3vipmKmy46/aZsdBMR8NUj2ovhmcObDPfPl1o51
GCSUca6DKUXPy3Zk1J4+LyM1/tk2cVTwlPbS4knN8IwWey/Z/v73T2qa0Le93gwmxrS2byj+ViN5
NINbYMj12cqRCzoVOsWvbrQ1atzff1+EEDYYNQUj7EzpH2hx0GpNZ/1VWSSBW+xA8SzzQplw0lcL
XMpBlUqjszN6Er4viB5cwVu2y3VsDDrugUYOicUcajpfQGRGzsi++Qk/yXtuxeAmVIeLniPpSums
Ew03akrzMzwDHEc2d+mFBYdu6BIActhBLP98DpClApjotKMOsywG6U+tq1y3UoStGPrpUGXSfBED
JACXvgUFIM1CRRJM9KQHjJM70DW8iVCRuGq7zXR4OtKL22YvkneDJP1+1HWWFjCmarpOeOrhdGml
+90xhvT4Yh0YOyRZddNLr7XTP8qKz/aNPoFXLmS7gY69RL7MUuSS4AChgeyQqjQxERbFVJE4QC4I
+E6y4NBtnOMlc8GjxA1t5QlsVCMiiVRVYKY8wxPHTGZ9dV+NciPGdCyV8ffXMGODjQ1+8l9JkwM1
dJKhdFNfZZgF8dmWhqwFqNRGyfWHtpy98u99aLGzOtf03SkLXZV5ZxPDtN21ZRZSYNruz1/YKOwO
qXEd4kt/xmXoIIMOsw4GFmodtuwjiqQbO3xDNWMr0MqBa09AAoa2cYeoPXG5pjYSJOiGBCW6K50W
JbjRFNPXrVFp45Efaj8q/YW6GmS9kNwAwHqdtKE3odTq7jlbJJvLMbbH+pXwRIqAqvcnOogO3+8B
Rq0P4D11YFXBCNhzILU83HpsRPuES/QOKKPPuQcjKAJQHemvvIZG4VuEwjWsiGOZXXutUGMrvAGA
tC4hxnCLu5u4LdnNVzob+mSjFtw/A1E8Xo25a9fq08gsKKmNP34mkdf9Ije1M6FDtFNUJwPsM1Cb
J0HdnYTZtiL5v7S8RTCaT0kUZP7/N0QBsORjAQEbYic9lG==