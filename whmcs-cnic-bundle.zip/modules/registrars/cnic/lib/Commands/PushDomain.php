<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsYptNJmaYPxZG18L+G7/bpvNbgUqgbzGC+R33qJ1Cjf77zuAwfIrIP5xGIOW/peZFYZha6T
jICOBNYxRnjq/lqZix9aXnjS5waMX+6Lgdsj9eNrwSJdxJPinjEgAbM047YySWGPvZbeiMBRgPqN
lgZEh7D5XEl0ZWjuvJCKuO+j/TVuwRIB7cntwIfDIpjwB7l6V3rQJYUz3pbuRJ3Ejkuk4dSrgvP0
PwK5RDOonGg6gcmCYT6/73AMSXu6mau78noJRh7/R3uQsGryYXfCcmOogysIPPYjrOG3jQQj/VKE
aXLd8FydE59isZZZNrvgaE+E6lYuePb6R8u2fVwyL5Tdr8RXn+sOKnb2bz6dGuREIvjBoqtST0k4
ID6LdSmOMQmOx6/qXVMjNur3OjsZLbK9XXQmwVseQQ1kpwO/UVpfX3J/omhCUZXB45elXsGcLrcS
MocnQB/ovp2lsaZ9Uav/i2AEEY2tlnYUEulSMBm/BV4Ow9/KzU18ofDeCryEIeQHDiekkRCtlmcS
XtjBXp84YgTr9qDtONIbqGoTmguH4fj2T1rUjOhU28mfzetkk4AoP68sbbRLVXvJh/3PV3hzY+JW
zOifrqxyQ8cGo8BMIBdDnDdvuJlG+efB/VampYfQjSD7/rd2GT0BZpC/QFeVWS4wqGlX4evYa8Kj
PqZSzzo5XKHOHV/ObUxnJ+NzN+zL3ssPIUY5yt1lxSxLuuHHLSvw3gaaQB9DHoe3Z+Q0tJjkGg1Z
C0Jbbcs7G5RQwqgAAjXBVQiaO+a50qqjWKDS/Fukg3vWM66SwrTXEHwvdM5Xa8U+uOlsuo5RW5OB
PKZAFI5LD2uFuNglaXgoWJg7BdUy5if8U8oZkLJdc7RFuapjfxHjDUyLxxgD7pLfQdwLkGRJ1VjY
DNy9MhiIUyFvGCcjaecwdsS64mu6b5pWIFsERlZRae/asN2IPDBjkuA4gAdPHsC8mXoc69AKdJ7f
mqo413EmHmIruKSddsA8EVDTe6bY7hRsLOPR2dswXQvp5Ly//WWSYcVEzw27s4dYcxTOle0+pPri
O8Py3H91j/XxZ6OFzFjS1P8SmF/JIEk2fddR/EkKe/oLvrck4gsqeDDZzH3+Ej7lSJ2gZf3CjIP9
4OonnYWRR0S79bqQTp6WVhgC+WgHJFduH7/2CPJWH49JtTs7ESqfXVJ32VHxYOUqELmET+EhPwb9
QltgEW5WLWFFuqUJA31EwlvaEBTqGOQoBjMCfL0h5zCFPhDFkrXbTN914FlO4rpoy/xqEPAyuxB1
mgP7yF5qfGQQzWEwq6IWHgq5YlObQCdqstVzZDzmf1akQb/I6//z5Ftq1QcfOa+gn8el7gxfJsk/
FnuuQqjZEmPkFcP/hb7MTCLSsiTcd2uv7AmasdM/MLc2olpbzo4/7C4lFt+0VoZ/wcynuz16cDJp
WtozFhnbZwu1I69ecvl0e7I3+BA+pOUbSLCHtwD3K8Tz7N/39nFhUkOFWo8WGMcyctZpcDZpAiR8
mQ3FOvTwt7w+ESz7KMX2z1O7JLy1nCzNmR2yXNUbXvG6iRL7NvQ3u6MYABVOPbchGWwHFpVMdM9x
dAGKDJ9NiqQJG/CoRdro0iow0n/6Gv1B0Dvx/AlTqKaIGLpfhmKMPp4HvV44eNgifGgoyLlBzEAU
WhuljA/D7b0euHpgb2GU9Uzwo9eell3e/zZH9pNMHRP3UAV0mGsclfWorCgE03j6J76JfQUbB0Xg
lLjxJbJmfmqMLDbMygM4BGu9CqXAvMZWEpLZK4TVr3Yt4KWtImQlussiQtmPZUjWql9QMSdXl6iv
UWD2QQcL9DSDP49m5wRJNQ1FCkZzuVhLTmO8W6kGSCvTUBMBjMksWE6Y+rM1aY2COeu47C68yJ3r
fDMc12HdTKtiMYGWqFdDj54TIHZ5rlUaZVsoI0+GpbyWAGHbMjV5eePFyYXGJhNGNlg8W/3kQWYa
Z9W4JcN6J8YL91tngBQ5qONA+LH6EXopmtfqHM2pOEDCVyFtUcKY2JA6xgEzSmfi6sT9NylZ+R/2
gfMdKFGKPGo4awlBoMG9KGeg2hxWggvboJXJaE81YxJ94507cTY0aryYuWIMM85Vh9ahCQhBIVlj
XZG1wdtChe2gDNH+rB2o+38XX0HbBTk1axfXUQJWRuRsEdw9gRjflPueMukLIAvTsjEXNBnHOKLx
myjz4z2jPzPjCm==