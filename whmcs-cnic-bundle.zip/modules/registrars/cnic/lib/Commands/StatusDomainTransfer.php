<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/Iq2mjP5F0i97gUA65Lh6ekFtDgGzb4bBkuWVms2WKsHOD5W09HfsV/HPHvN8+0AsBUBJRf
i2H71bJaukRX4wnYIWbyavkg6cK8BDytXhNXxPfmpgSsw+JjLqwVxTq4Eegq2ZuBR0ozJHb1aK5/
WwCZCCLjBdoRWXvqtJd+Dr4Yvnn1w1LYiL2xrdwiGJ98Q1W/pZinDX8MbTpfTTIYcVPAi6cYkE7t
031vKyYv3d/Go4dIIY6u6OY13W26JN1pd9Ps38PGOQjJKu8SAFAUjXXANH9VAFyqhDQHiC4ul1Zd
agTJ/rwZgb9vP6Eo5UZ5tRCNysFsmVWnrCjGVM71Qgoumml5sX9F4XCz+6p0hHMcUTxoO7fdWnzK
kRRK0iP+BtYpkTpUK4e+8q/0foN7PAIGZGZflMNKZQiW7fGSbymq32F8JxSRYvCRJT6bM819dLyu
p5j2KitUpNn9X1FVRcYsfu19pTOHJEDNA+SFgBcy9E+7SKpxu1yxEF3duroNABucgq3d18F8k2OC
sl0wzymrkYw0Ngpb3VfBYqg2p9iMBBSI2m8b/qswUM3IUspw+FooWBFYddBioGVUO+I2Bv2ije7p
FT0CR8IbzoByODtW963i8/q6UyR52qHQ5NYZpMWeIdE0gO2Wn9en4OYflfnVASRK0u7P6xIJlCRM
vqghRbTCPB2Qti8V+tLDK9aJSGFopq2ksagbUShu/QDTD9T9ogOpGd3kQSjb+Y7a0NyTyAX84Eaz
ET6uJtYHlEEkCEaifEf20rAMlBMxOGNE9eJ+AIo4RhXxCCcSgdfvqW7LIENbn3sJ5r9+SiGLqwlV
GV6+yUDFk4pIqQmz3WgLWz8syuUsKpvJIc41NQXrsrZj8phrT9p6G4EEQIAYObzKkeRH90nQsDTu
4XFnxu0V0CLL1T+IZMCJnLTbZFfghx+y1tHNpcwSsvEU8T2b+dc2OmfF8NSN1SD0zAH3jFpU1vWk
qa7zFzdJUV+sdxe1Jpco686gxxJwnYxklVYmNjQ4Qjk/fvKigkwfjJsXWWCfgrztLHGpMil16s5P
pKLj7gz8iUGLppPqSZVi9fMm5MCAx1rtGXm9SK3hXe8whAISDnhJBVGsKFltN3uEWRlv3CXymL66
rOb1fgUJpWsaPJEF9qJvM2LvdsXtDrwNo1EjFHOMA7maWMNpTB6k4xuk7GQ4CSgm25IuNauuFWjT
8vn5WurANnwlnc52VTzd6MvV5tjBbN2hsvAPep23enff6F+CWydyFz5H/LKBesLO6nIDdFnhCS67
BCpft/86s5C5KB8CcmYq89ocMNa41hKO82E/wqnKMOEgi3KhPJSYUTgxj2FNO4zFH856MTz5etI0
c7rYsBSgQi9LJ+SJk1DLizQSKWY8Hce8W9MbFGQPTLgCPgx7ZAMReSydN7rxNMTrW9872VOGEuQy
IGyuHaUo0osHdrK16SbU4joPYXw6PU2oYoqXcGio9hwAZQBY8N95o2v5fTbJuR386EQwS6qdtVKn
gtvDfiZr7eIh8/BobRbfJ1NswmwNshYZ4NQf1hE8X3wo9KvJTfbZB6TjuFlsTiipbvqtrSogdmmS
Tm3J+S82dmutXFNF7sEnGhc9eVTM8K3G9FGFMbexf5yFV6ksS/dTCI4q6nVSiPNsEjmmNWxA8HXp
zjYmJO3bU3S9nJK3dXNCbGDW++dsTCic/Jyd2H8km7cFy7gP57pgmBS12bFHpOv56GWeXXJlZzod
10nOUa5EmUhapbegmzylCtmvvSSTVaoYT0e8n1nt9qcXNJbc+3Q8jtfh0eFuEdpE1WypZ8wHGEfa
+7yX0jpKHXvJ2bjo+U9VORXdbynPMzLj637TjkuaR3AOCw0oJiOZlmV9IYQLPCWdU30euBF1DaE1
iXF/OznLXK2u8+teQ5gWwFLc0Ze0ITe+MWfTHjLc7rfpMYRzlYFj0qhKv7ZkRXD9Pq+C6cdQ/hq5
eY940a4DBQyYQnphSGAIccDTQtEBOZyajm6VzktHEO3DZEAXgIUIwNNiFHgnfuTm+bi8FSdHnC9E
J3kRGtSFXyK+g4qbuvr10+IsvNEIhgSZhTxHo6b3+XyPT4vDyeLXK+o30S1PyhYKl2EKffGwYz4O
OtSwr5KgYusKAggHpfWCzH4sQpPCNyneyJhYAKsipp6iZAnbY2pk+DinDUX058sdT6dWs7L5eWjo
FSo0ilI+0jpW4CChdWoQrGZYnWASV1NAgGE1IPtF/M8Pnm+wQU9pthd8z/k6g4hV3iqibAxDY3hq
+cTw+jEUk5wngM2FRZ+5hiWIltODquvLK2Itg9vaS9YIIBu/0hKKcp1xfuBWH40NlNQIo9DBIhre
cEVYsbBzubSXk/CviVy8n7rH3+bAsVuXK1tte7mOSxF61P6pA7M29A/4QGrEjRa268KKG01qsWTQ
63My3twZK18AdhMzQGmTZXcOBnee2qsD963W4a+Euh1Ej72ImLbACxsJ1FYn21madEBjiUqt1Omh
jxLzI0XIK1QLVpeFGOToBToxmix1C339ivJpeTKiKkCHMUnjCaaKslA8LXLvthw/eELe0/dBp6hJ
IjDQZ9PPXTVI1nYXDj6+Ao1s3VxUtZ/4mQ+XYCn45P0LT/rjNcroyRDNyPgna/JVHgO7yztA+w5z
kGGQn9eacVUFNNoXaf1FpD1iSiPWfjASijx7JH6z2L6gGBsT7SCo8STtiKKVpXwn5+O/0It/rrI2
TslIb/U/EgN3DM7YYHhbiDN+RMOta+fCZHaFd/giTVofOmBnNZu3Oln9R9WrrtTvwAcKzKGnf/LG
nSktKl4KVwGgovklvvz3Y/YsuAhpTzDmtYfXOYr4YGTg4DuiklX64Jjq624oekkPWJKDgJzCD2bN
PXmHjMHoTCGw6ZA8jyZ6qxNHs3PdrB/vXIDn7SbrDa9im9aSZisSXOYn9youoCQJDFAKqYdWboX4
+TumPw7owQ+ZNUWth1V3nmObAU0C3Lt+8tZNmTdVYgC2/eKHvqeXzfstXkQ9G/ASh1TsubAlyM+r
l2nvzyO+pTeFq+k566cZmeRgJYCngaFXGajX8N9gcuLnbZdEcuhI6OcKdQ1sFRWh0iKJSLhm1/gw
49ZohxfZTivQsPShu0C1P9GPp6asT3FQH8UUGyyzBH4mxeL0+VWvDkPB6kktRYc9AG==