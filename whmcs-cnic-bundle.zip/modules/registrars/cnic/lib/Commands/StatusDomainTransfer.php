<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmpRwOaDYTAko1LyglkWdrC5Mg3FxFZpXD+pemgugg9PnTsn6JJU7EQuQQOsgjp5EU0md4hF
1uzvNrKQnFdcLUID5RnWCIkRfFIOkFVk68EfdWzaxMYylaa2KYQ3RgxpoEC5wNKaKkoWpU2t6fm/
/Uca2M6fPildA6Z7PKbbHecmViEFjEIIGsZTvYapxAULGbEfHdTPx0DtLonYzTBetF1qNb2agYkC
oJNX0LMXez4gAOJC42OKm7QHuVDpGNHrKZJvppVM9qz4A2UD5RII1AMk9vbLRrlyAUaIDUry/fzd
SH/7FV/3Vd2paXJk8H+jxGkbL7Ri5FG6M6AjMsikw6G/GdBlZiNuhXAtMvBm0Um2aMS+sAPl8G8m
5vXSzLMEYmbC69SbD0FbDHTOXyKG/TZfk3X/CEk0tf4lHZGvGKeHWcK5uxUtxjautJySNxDT7OdS
nk3INAQhUnZc/xmYUUVDuytg3XIUgChIY1eLu7IWoanQbbhTTDUXcLCl5bt279POAXyYW4OUDnii
78UpeJXoEXRqR5TO9yE68nUskR3B7tEu3d88oLTEeOUBBLy3HluJ3EUaKklRvXnU4cTyoMWjgdy6
GJadni/WJ6MAeAItxpfuyEojXDy5UkiE3v4fw4mzV0q/9g0Hvl8MCLLJnAqRro3aszyYvsRYNeJG
Kb+ircCAaw9Gx/2WmNK4dxzaQHOkXr+vOaJwBanQBCa3APcSf7JexFCejwuC8zGYgCbTfAzWfvNk
IKY4wmCmzISXWLuQDHprLwnMIZF1/lb4AtCt5WUy4TG5/ToK8vEtsPY7Hi2TgkWfr4UtA6IKVGyV
mqnnIX4rLQBDiOJOJsvsbIsdwJ2TmwOhzUo61w6YW8hXdtP/mUawKNzDfZwM3OXSJUrexpxl1lUj
sXITYw1ahsWVYUqJR+NTjURvozSnYzHypGu/wW4xDEVFoDSf/u9a/IdtyNxVue5oBAoqOkAYQkmV
vscBY0oS7t42MdsJRFu/1WdpbHV+ECjMIm5d+dDWKd8fzdSNZplY1pG5Wbm1Hb35Ai4sEqLHcbPl
qwYaCh61toNtcMy0XhLw4vnaV6ybKwF4y5GLqUvuieShK3+Okay6LY/vYKzazne1+ZFusSLvK6Eq
RA2/D1zfrZyzDAsBnqLD6XRMedfrLmwA0hGQ0mINytdf+IipwUt1KgVVW2sDdPDa9A0lAH6KFW2l
iRLqBku20MqrRr25PxzoPeswkj/dQZGEFYrLSeJgD28A58VU4JcFMMwEzVW4nSo8NJ1oiLBCSRqp
UMv2Qap0tPk6b0yd8+UcuwZAxEBF+b9jcsFwOBovq+NzGB0RdUGBSEHIBf7QQxmiM//sheYAMr5f
HjhacQ/gRFIcTeyS/NK0P5es9qZqL7DklVjMbR57cbMaiWhhs/M1pktFDTIggBWpSGHBwaAcK9WO
L7LZ6BhxTXo4j2phjgcMjQZyvf6O2Iw/JFUMqe+FyDHNHEBJDgSvjmVcVII+Dcs/TRGX1etWQPKl
Of17lOgyzRdyOf4nsIm8Gilncp12euX9pXEUswvpsK4eqGUvpvicN/2mLQaNeG5ZD6SAI9dvAOUA
kj5f7faVig2/QovRvIACVTTWD4uYSKWwlW1iBl7EhGtrRv+m9FHiieQS1IqQzRwrZ3BXMXr4VgZJ
jYu9GSoX4yrNMO9qEEqqHpFc734e/r1KixJCXN6i6b8l8U/tzvw2FUGOIwRgml382xxnX/sglGp3
Q/gsw8fabYDInR7Wn4stoOhcteRnZT3qv+5t5iCerxQgVBJNZMGBV4GwILwiFjoutrCsEG4GWCGz
XSFxcpVtaGGgvadDRD7tceuQcG2l4oLc7PdwSoJ4w3Xk/2z4C4xi5hpPtyZvqOafm95JNUMjtqZK
/NQhFvOluandGTwcuTjiDJZkMKD8/0bed0UVBzYww6RYPpuXSFZf9ywFomD4yNKiQF6PlT+a7Iec
JUBa1Tl2C1QFraUvnBgAjAx4jihY/GGdWwrGVWD6p0X+lUVc3rrlNYUQVsevqDEqim4wHXXaOiE+
EgKWUo3Reo6Eu300c0Se7+TCGjX58+xfCmCHDQEBgTVrkegt+UPgiShKdeen2cjWicwchu7g3mXN
zOXYHHipue/G2BlmJ1sVJTvGwW7ne2NFEQLhJCtjPSxkga2hGZ31umNkMm2G/oA7hHqZbcEGVaXZ
nAC6Yy+nCObAKNU5nX33t/H4gkBaGV05sVkbxBj6h+8Ab0RddCwURzbhflUUvRG6txF3HCyLECuV
gfdDcUbskoXTZCAHvb05Fj8Xl8WIf4joVU3XCf+XdqSt1wOC9fen5zHyxFAenDLYZn11/atyFwJ2
LSLG6oB4Cz6RGUDWyrNXuFzEThRKswcDQHAnHwaTxRx7vlh2OIOW8Y74ZJPlMrkCTYTBe/fxpDxP
lDVZWOyM52iSDcV2YmXiXLloAH7Oz25Cj+sudWGfWyu2FxExAZ9MxOiMS9T7odrR+415kNK8la/s
4SleR7zXy18THTuVffudyy94mPPYK91ZNNiVctxZ5597h7AKPBbVmJu++gkQYFZ1PBUGC/3wJBV8
SG8CxZDCrpzJvsOt6iEnShx48yH8VZVvhLsXXqmRLUx2BwXLJ5ih5tl1uqgd9lp+4+1DH41L45Dm
nRrTohe0AeZXi9beos85x2HcOcETnwnzEa5RyfUct9rkzD4jE87Bs4vfGT7BliynQHMESA29u0sX
LWDY/uSZfiHyyjOGbiP/isX6AEDEclYWq/Bjy5xA695qA2KmPfNcyj1Be0h8k+tYCQ3437WEgHk6
kPHCGyHJAxaHt452n5SPN2SaAZLPs3vXg7wtfDf/ve4/x6JC0atrjjeL/K/Tbs8nCZv/cXUUIpTy
NK0VUrGhHhbF5tYZ++xebSPOW/Wkf/HXbsEuDO/5ra7qcQIwwG0DJjW99fbuHwDd30R+2wdmtpi0
cSegWr4JODhaQw2iDyuTZkx+wD7FYZTe20aE0EzcsXXc1CZJE/db8oQUhRYWx5fm4Gdf3EmF9Q0x
XPNZT26MEoBszrrGH9gFkCsSPkEEDju1yk5R0Bt0bHPRA1pB2NNBWjAgZL24qEMWsGMzDGqFHZXq
wJLrJDObaZE+ZG3dAmbAkC+heXkui0OFRlkZwci+RYejluKXuFIt1tuP5b0AKfFbmE0doK3QKyqZ
+KH8itXvhrZbjAuGH1YT