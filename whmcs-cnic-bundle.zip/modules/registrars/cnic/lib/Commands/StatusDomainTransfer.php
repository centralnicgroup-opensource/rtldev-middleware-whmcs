<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+1IFtTGzeDuBPogL93IrfTbVUnF73TU6yCYOkdGaXQA5wV/SWD5A2qIsuS0xXYXxcGfZBJu
/X1IprW/PBULqcpVfXYp0LdKGjwCKpP3U4QjZIKDe/jPBRwvY25//LFQFWQEr0DxgqDMT8iNP4hU
OTSqEoQ4zll1fBtFn1PlEVlAKgr0IetHDm+vHsQOHuFgB2C+iLhGUc5JERLfpcuMJ7G2RMSpG2wl
5rvnjmujtH9inIUIGMzllWnKgWi59GcT/FwdCGM+N5EDoKg9JE/Ip5cP3c7eOS6E3zX/eb5Mk7qP
ICa8NF/9/ParugtLtcjY32GSdTiQTqMVlrricDWheFweoG+MAlqvE8MkxiREMvIVtynYkYG3/mBH
EsW9jagXGtUX58HG0RWUrtbAtQmPHnarp+lBfX5Sws0nkqK0H9MB9HrsrtQjYFNbJMxWAYYu4ohN
cvCZ1JLnyfvbimH8UBq7uUhtKYZfkDyGGzU4T13d1017LOp68Oa61oE2NSKz+7kMab54Q7eb/t4P
xbnQuYgw6cpkQYxRz5HOFyAnP6jWnfWeay8YMXOSWfooqs86YzR0r9k1fWCzXrr4Rnz2T+2fHXX7
OMHZDgh1rn2cpI7XekbntbGtrp9bcPAnqrIZdFHWfAeeEL8oihUUMxq6NzDeY2kvgVXPpzJqW50i
Jj2MVuNQM2azgwb++oe0z7zLGc8tJGkFunSNKxFhtIBBaOZB8CMOTPIyahh//zu/BI4alKOOW9ji
9hRfUH4JTRP/RyA1NtpfxjXXMQmIuPsjBIOO52mfx4KQbOSZ91toh5EuJ38AMP1+SOp8FQF09/qd
5nF/jOfYN+rmkaFLrFDm5QrXvMWFxxQurRhpAbxJPxtC5oJ+ogrykEjQzLwIi8LImORTekpHe3Kh
akz1KeKEGzY3Ss5LHYFbM4OFEgC7iEiuNX5M6pUwx1Dp+01DJxJsXSSi5MXIRvKC04waPTnsLrhv
l5CmCBzLnr5F7Kw8XpR2s24s86c6wSGT5ja4bEGTrJiIBP1qnFH1QKyWjLf0DnjNTXPnc6YNGlwi
kgunbC94efsht8jzc0+4n5znSE3uZeU3uIZ5Fn7rz94TUgzDXPSSmXKFj+HizLWf/3tPO8ymg9Ah
+zBYGw+HpSY8lvTbx52579v3QLkxLEAN18uMi9rpYd1e1hIColf4+TPGtjG5OYmiuj/JxmVXx/XH
ttZJq+yQeDIrIfQdoM3Hd57C5/mYZC7Hw5pLvP0Yi5pg7Ks1flYnnwKZaea0ekL37LeVqfkXnaCI
+mhyizd4jtP8EUHfHTx6XTfNo8NNFMsF8ZTA4ylazvuSUqJxXobZTIE061fkRGdug61vxFdjfhL4
bMOKes+PotGl8kcNRJH3ZGT6JPNFJjG2pSwoPXSL2SD4e4C3TDtLlSz7SFbQAHDV1qVreUZZoLwP
T3/znkMMS2muy8v1MhFMkIS+dG1hR9tlQuVxq2sKpojAgARc6Oc1MS4cGmMnwrVrOSw5eU30Hjqf
WMBCLM/DtWjVnhU3EdNsVaRXp2zWg9vl0oeeNw4KvtjavOr7MhIOsdEudSfIOV7LPhE/htSl8xBv
vtnLZQoZ5SXi+8Pl6HEcERjaydZmsvDF8KYPoOv6KbHcfxx9rlpMU8sQnyQTJ1Pu8KndRtsOLuu1
0bNFwk3eWOv1PmPGCBKofDn3HEY96s9JvfqLbX2DzsvbXo9qu3tKmyHPC+x6rK60ppPAmbFCfXQ/
ww5oXR4EdStBjPyS/RFNRE+eC4GRZ6zLihGLAwieWznRkjfRU8aHRcB9REQ0yCVVdhbjoqcBdoVh
12FooTQ1nX+imIQaxPv5H6tGpJQf0EfsAM4f0vutsjb7dhZO0A5O3IbAH1bet5uQOICvWXuVCkPu
vZyw+HCL0OoBvAoWi1vfHxNS7KO3W2mrCbsNOnQxn6w9POb144RsMlGZRRPqg3cz5jJz3cuRRX54
9hdqEUTFQsrc8h6o0/NTCYt+msLcWVQmxVWPGAWKkVS8Yar7ME+kdI6xdUZ/fE98uWx/fZXafrJE
s7NtXVMLahdTu3lF/9SZFWGYlM506MsnXQkGg0iK5N6Fr1ZiOXEcE3uZfA/JzKsYCVYsn2WZTQCD
dddEjp7kmAtxhxfzBDs3xo6ry9LEXckSpiI3zcIXYwdfIEWLPbogpeV3zcMTg8y8/5j7RH4sYp0L
UKU5svUohHdd33FgLfid8qEpgTzJi6uT/ZNW9uWlt7kKu5WfhEzOCbGSgbwyA2ULI+785fKp4qHU
busH2sHZ25iz6znjFz8QylVqmdaKHGFehgakxb6Gi7258lVVImpB5ShnPyZqhqHuIy5cdf8mI9BW
pnouyyU5hkd92OIlJXpMQ2iZTWpmOoB4gEcLLHCvb47skZFzpJKruiqb4o0ZTVwXOYNwHYCZBQeN
WurTtBqP9Bjy3WAStonDOanQ3f82FdcoEN6f299efXzyLFjdhBb+7aQXkzasPrWlqRuc3fK669ZN
C/AjhsDkvpfK8EkJ5Tp6oswueJLny6dFSmsshpAycD+DHgO6es+7quPdQ0aLYOJZORXNds6cG5XQ
KEoo+KGo/QJVhg0PYt+q/bJHBJ3fpvvknZLNkRtTaRjXsgqKpQ+o/emexaw1EZubg/135l+BtNtN
uiaUrH9L2KHDaYLWN0f93iwIgD2zG4D0sGfTReb7qlxP9igI3I1c6SJ/zQ+xA5nBhPDPSxq0/rh/
u3z7rj53sr69l+vkxCXnXpsLL0OhOv1m4vbt8un01oIGHw2pCajmEOJ7zJc83kkxHEReiIvqJhSL
NlHi0HKHoTCl5i5bNsyh97/QxhZA5QcS6Bj12VSQaltm0NwsyDIbf8/iyaAx2M/E5p7z6EL/saqI
US5+kyb1LsPlMgKI8BCGEh2/DXBPxxh4TU7pZmx4keK2o5BtXstO544FhTH3LajrhDqJEvW2yJK+
7J82fdMvfijGoCFmaTC1v1CU0XNfrP/gEmbNjmcbjHhyBluvU6gPHSu5tduRqtU1LCOaxOcCASIA
ovtHcY7t3cLysuevfTZ+BCPBT/6jnzVvZ7Wj5kSVBVYn2KE1v7EgAVKuoBeG8l2LbPO09NU8GuDh
ZLNMghqgcvj30cL3fz8Ac95l7hXy6k1Snnx6Kz13VvQKeIsH/Xpn22IEuXwJpBWxOhifEFs/