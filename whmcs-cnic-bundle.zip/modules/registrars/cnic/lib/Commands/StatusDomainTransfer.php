<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnazaDiLhsWSuFC5+8qpzElpzac+pNMXNvYuY2NU4qUe8AIQhdIWiFIY0xsRkEiM8ebkXJhx
rT7Y4oIIk9D5e+a4qjccQKr8lLbVHtjDdI/UI9W6ooGc7QGaaSRvIpHEaLomOuFhGOmn2RsnMnlt
D+Zcb9l0Se1vdCecoKO1VChkcrW1vo0wHRK9WzQqBYrOpy0hpwv6FW3PTA+ZpanHTtlK2M6y3chH
gMD/2s20KX5J5gTmWCbsT9PrELObRYwTzC+/nj+7fmxavcCZy2lxBYlnlfPfralt9KS2LX2bq8/o
OGWf/yw5oO5bb1cphBMED0AYXwSaGozCcz+s0W7Lr8ZnMzbAdUzdRHrv5DkpDrCUC2htjOm/MtzI
WJMP1RO+MfkGvf+eUTwLQeCtZpHMOWd/vwjNlbjB+uUHUQNoDTAEh2jkhBTcPv/5mnC6nGoin2r1
k74Bk5VwK9+/QkEPnXSGvjOgw+71/n1/8YSbbvv0WLcQgc4/COUBNvN0BvPBBl8+kxwiPCRByfdw
kj9e84rtyEccXiP3X5b4ocPl7ECMvd8HRLsejsp0aqBNU2+HQqIKUFPr+Il+zUgMw/SxJKjM1SJt
2/d5AqjgrVbNZsjFSg4zrYlJxvKUsVkWbGvC1xCAc70S93q33iDvrbFxEGvfiXAxny7vm+IMgKaI
zu7Cb91kP4brjGx49HYUqng0v3e1f+CdTS7ul3/e/uNX9TYXzK8UTLgFVvEMWwbi7WsPgbLSbX0k
odI0Q7js+4AiZyMCDLFMZbFekS8CtJc4XBz9cFfiBVzqyA9ookCQW6KRbHCi+hYGYfBYSDTmsMJM
+KL9bFn3e2L3B15qN1q02M7CXrMRpRxIP7VEvm5ciRDnOVIUjKLjUkt4CWAeUhQJxop34RgAhXKD
MHI45QO8dE58HewqfL/2YgnOHb//E4Y7Rx+aSIW970pO8sqKIkNHJo+kFHMm5n3qRlezBL2abosO
jEbOsFCnBLLTImvW7TAWunVfWrCeqAMxvuk/2Au0fE/OEUVwEhc9RpZq03fF7j+PBk6wTNWaqxBE
rK9xmJ7cjsYv9l5GTfW1XBKUwMH/kMCh51L+eFFRRWLk94iF5V0rLg39+KOMJCmcQlpae6PdXQsR
k3jEoc15WBjUMH627ie9c06j3zwbi/+Pnv8NrfcWKzyPEhHm2plvpHJ/8YZRf53sSkD7vFAJpZWQ
Q9MfyrwCOJ72AEdgkEaBTzlpSVoW6c3n+gW46MgErH68Ocv1dEb+chI1a1WFntkTdSYp+zZaHo4N
JIF09rbK3Sc3OjpWChFCjtHHOYYJE6fWO/M1E40Lx82MnTMfbPwVDRHcdsWnMbpjzlKfRYU9kS8x
yK0J8Mg82wPuX74dBjPw1mdGg5xglNJe8CJYtHS5tXZ5i5RybncAfTcC0UhzSSg7rAng2RLe1fGB
BLOcG/sXvBlmrdI+aJcRssz8jQ5aGf7FBwIZfw/FZFwO8I9Kyh4+Ib0272FG3pRrXVccZ1jD8JhY
J/FC9jn982PxLl58Haeo8GJ26Ao1CZRkWFPiJ31PptZaxPtRBO2r+N38RJ4icu+jHp2+fituXBa9
wmk53BzidMneb0vwP+oJbf3yGVcT7Qv3L30KGqKOYmbsHTHzvcULzEfO0Fa4sWVpiEV4IUPi8hDW
WJDngwSfaBAdQEl55bdCwP623mt/qd1v9hhgxg3HeTzMd8iUOfWlbRcMGBmpYuL9rASVl5Eoh8e7
otqcHURWIUYKBlWxu84YpWJInzTwTHapzVryw8m66AYiGldX6SDZ1I20DkM6ByDL+pHpsSNDqRFU
YDPGZw2r+A8YOESfvbqC/rndh7I9CbJYTgIp8YJLjvW9DMotaZLRq87gaep8EspYwVJ5pJ1Y3mw5
xJsYR+wlvnDth51yYfhm/He8t9IUf4kK9/JKPIf0lrT6BeLWyyvz2VpgUbLgL51HCMuf0TP0uEPO
Wre00Uwe/XlHujnB9kalrbzLMOso+IvJ/ftwJFy8R84HHJOP2Ljz5GxqN2tBTkUcQIQLw/H+uTtW
kolqUH1eGrSAMaVcBZur4gxcrgnntGxLAibf/2hpR8cGBoyWkJvqRmyYitzTozvflwcnwra4m0Bx
k4VpEJcPkAp6a74fqAS6cEw6HYC14JB0XuzwVwZuMNMDDagdal3agm+wwM5A9g0NbiC6EOrYQ6//
sFGAMc+22dk2NviuJ/lJ6vOiLhekjwz9XtYPtQuCqNE6LRR/aA8Fo3lazPBmvydwNcqX+CmURc/N
9waTSIBaapSc4UkwyR67ZCRYg/rLKWUfPfF5YdQWC/1l6nMakS0ad2rFlV6qM/sP3eUfliCnB+Qt
pXQ+okImuzida6dLTYyLh4SPP1JvrXh8LHDOlEzOrAU6McREa48rnFcYfH+vron/R5qOa/pZIqVZ
5nhOULPOnyPem027ONdUHJaNbfsg462/7cxH5cx5vuRzCrVZ4kjut0dSoFo4nyUw4VLCkX5OukHp
ifXfPhLatWLCus73ZPz3Orbw22ZmuoMP1fGL0QO36koOyRsh5NMzN+pM+1jzkdxBskYPuy+6tyLh
hi89iwk2qH+8HXIOs5bx6ECbi2Ya86a/zCykDqd60XUZrhwsiWnVzCzo1fRBc2uDGg8Y1p4w4kht
C+eqbIy6t0kSbPawekuk9/viLzf5aHNANL4MhthX9vaUI2JoaRLJzgg9Yt3sNDDX3VW2f1aG1Xc1
XpzJDv8b+PLj8Dg6EJOegpNa8D6f7hLAba88XGCNankY+sWlP0F1PdZ2n/jc9B1iiOC1uVNj9ShC
cBA+YaTFYe9smGCnngMRZxlFiBjspTTLKk96LWQV30GUtD3+CPaxM5O58SQaBXPwmq2/a+LX/ork
AOJBiTOAX2KuXet6gaTAuboqPIs7Su+c2041y5bOFfrQQDpSErJls3U1lw5NyaCYG7k41JyRjbW/
oMdIYkDiSO5W8K9yCEa7E6Vl7SPaqaV1NPfpAsi+27UDfWSgODDbNNBQk2F6iVOl3t0reeIf1MsD
gRSdoeIcD+cfysbIIS1BnK/Bp/Hm52pSR5NvxDoHcFLq1V7zfys40WvwNvneYYZ1a6gSjnY2vu8B
OqDlAjlAN5FQB9smlVDekVqKelMyMA1xdu3M+4pHLJuIKQJYiCRWQlA7Pa6yoGS/0CvEr0p72B5P
xK3eepv2WZfYYdOEfoPB0Bm=