<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzKYTGzLfaqX8EpWBEfyg5BoX6jt3BUkblHdwebdeWIk/tE6MIF+eQeGVKb5WnPARxCEnHW+
1D3VBOTIzj8Ou/0iR4DddgW0YTxsbHuE6kqKIUZUxBvcMMw+dMjvgxBdejA/vRMoWe9NXRQ45hHR
7E94c6na8Itsys8gPf/9VIK1/QXGeHdhzIpvOkN+cN/BV1KErGVr6ezMlhg8wBAKTdxY78nGIDGM
ypeHRMYqD+bBEGriy4G9xaqECn182/CwPsyNcb3qNJq+iX0rSgIm6ilmbiF1Q00VkZdDqE+LXUg3
3NidGlzSVRIQ8Utvsr/nybt7Ak3hS+8fb55/hA57MgLUszfxbLx30wNBtXP4TzZjP/DMhLzQChW+
/TlzvlGgVVk7TB0NHnjOZ+9gX3yoNOuzUClRkwbkTWAq5vkF5I3REbGQJZ+awZ7iOxwe0OKRn2OQ
59LboqNnL46a49cp1aToxpKxMSNSk1Vc1V4nqBbPSX/bYHYenCZj+xvaGU3tlo4txGzd7HgKOdMg
6xWuVr8zirL/NkLq0LJ5wDLWmIMv0WQyrl4vq1wWKfZUYNVGrfNe9h6ld0ZpOZWuH+L0rdQbZh8S
+jjYOvI2kqCKygm1PL6ECXLRIrQ+zHQ19GNckJ2+9pTK/nZov/t153KHj9rKN6naJHaZS7sX1wVL
th1o4V/eGvKqrd15PDI2X07tOz9jVtUAc35AXtAiCIYsvuDHTpUPwsf3DYPrXOler+BizEorLRAR
ZZAhj4kFr88B3r4AHfFqahnSgnlzzUGda0Rui2RYssy2YO0M/lgs4hrEODd6JG+e1fuSyBgGVJg5
MAaVpRz0kwymRXfoXEQsrnmWqMZFjnzE8AKmuxzZUbKetbzP/ysgJEpWN6pN9Ex0aHXsJAEs9tZp
5iPNHvG58QUwK530kydmcTpdLaib0y1jplW3+Ab+t74Ec89Q0/dDDbEgAxecvZ6zMY3CuYQM2CmC
G/joO7p/0k1BmvzjbN2pwkTkJWMMu6cf29lTZztg3oRO0fDfgVeCLs7WG61Ux6RKAH1GryFBpjWS
fvzQRpaDUxIgQNQ2budeO8mUrilfBUZhZ0v+TXIWBJxjVBcL/n6o4NiNfUWXVrbxyh5nw5jU3UZU
vq+mlrApsNfM1C2X1AoQylG69NJOGg/cPQYpxpslC4PimEOtxL1A0Rii2IUS2LIIK+IANuASwor4
j3JmQ17CHsBSFtVCr0ibFTo31BwlDjRW6W0E9zKY5GXe4BD3r11/j4nx836whdeRG+X7RFQ+YwbG
+ZXX11ymYO8F1wB6o4LLnYWtjoYlA20pt+rgfkfDUk+O8j1f3H1lZlDTeVlInUjyrNangxdrrq2z
MO3Txw2lPoegYai22j7uikmq85deTUkjwIeenjPtMxKhEC7Kscik1qXPr1jekjxiD/Jt+e8ewM6G
mb24/A1t3IjDdlzirxKolk6bRG/ZoL31fkRu0RBqjMCIWcdt6UaCsvUTIYZQQLU6vatckBD2zUkd
fwTzxZDgWOis7RK1SrWFN4/KOPHzSYhuMYiJ7KGqPYa8jvGb3vEUq1XuPEPsaaxXpzWlTrUOlgO0
X8TqvqPds5+F99nWXi79WZORBfdx3+y1mVN4VI2xiJsiIlwkW25/lqH1dv9UOLs4PTMCNXw9iZJK
ZyfOC7Q6nxABz2qq3/7AySgRxH+AH5J8QFNYThH9UlqvhgxeRjxd6rwEcTb4ulyxyD8PSFR5rifF
XqzGtL6M0utl0Q75iG79nS2YxCRwASQ9zdaQJXDS5aBCyICAksrTqkrOwgQazoevZtMW+ukr2L+4
VlCLOzEX+YFSvo5yFww8HjiignCR8LbGUXsBtQwZ3Az7DrDI6Vpaun+yHdMowNP64VFIQIBFO3Ev
L8LKS6+afGM9XpwLY6CR9x1UqXCezPlFqfF6mIJphdQwkV4YPAZC0DQZn71Qx5sNk/RzKcUA9gf4
au7s0YV+infRgdS5sYZ/iWB95QQFfrBkzDmwmQTogIovGFwAp9+Xgl1wto5lCGYdjzWNEPsrHaAO
mmq8X7IbewaogsBOq/t3/Al5m7+uKV238szRfzSv3cVNm014MxAFq3q9EWwytYxuqSmIdUTPmrWt
hZtDPlurr7+4gAHTv36/m0I+xY4tSMW3JA1zRm191+FwkGQEH+cmo0Di/1jpgDN2iZfMFMt37dl4
5s28ThcliyQv+sdOP2du0nn2KviQu/GcEbQm+KKSV6MAachf05sEkoL5aKV4OrrvahcUMILDQ07M
m4UAa/G26gi6zWrOBGi3U6Ql5IUE25RBykqbhp1S4CWzAuV+H3IxgaTP3psTUgZziQIilRfW0LpI
zmO4Dg9PEHg/bc2zxCaLSQX2QVYMlr0x8rqK8BXJeaHiyGZzHGq+95817sTB1EpSlmVYUcJABmyt
kGGO4Pvl6xcgHEySf5eptSB8t/w/uzNtfxOY0Tk26tWiuuOh166k1RYwN0vLrss3iFyVpQ9asu/b
pGvi4VZ0+NCbUbRkSKuTCwvPGOUOl22LnbvgTjFUm5ts5To6e2uOwGmN2lcEQICUHw6IVHZZ1zce
D7KKgvJDQx+2SSMt/6ePWsyW9PjY4Yal5o0PmCftmZBJpxByspQM3d6gsmi0c1ZATk+FXf6rMzX7
RHxykxe8S1LcUxGeoii/dtBr/FWap5oTwRlPGn5PR0Dcbd3J6buYXuiYutj6pKBIpdfHAAS56V+Z
oe8GQ7/WIsSAYhNLX2nUCbuUwLFt6fUfwUAq8YQ4c35lCzgndUqjBVTshagifbwWBk4v/OhQsipP
lEEPQHmAzacLsAmhaTmayZBTnG4cgk++drDbYyN+w4IhqLkY7GhQo44RcgCY44yiksYFa44j4NFD
8r9HGwpGJ1BtFecPa9xjZN1I2ood3xjO34HF2smGaeGv9VH6uf6x2T79zQe2T4gscGbNTNlYQ5ha
rY9VBJOS4l1BlIt05sAPW7q+VnIAHnSOReuev32qi7YnLu2bU2yBeUgndeIPUO5wc6ro3o0QDnNi
1fysW8aTVtMp08pz7F6HNzS5OrYwezgThIiJvAbhnv6OyWD92gRY6xuKxsVUJJHIygIxifIHnVrf
0zLKRvPYHgvflAku1cKRoFzSq9hPQXiY677HMngICr08qH9rjX8jHgOmHBYfMy1UDafd2rZLWCE5
dPpvI8gOf4RxM/n5/pLzkwKQGxo+