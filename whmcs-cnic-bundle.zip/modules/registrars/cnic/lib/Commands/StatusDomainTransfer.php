<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw9tFa2Vr89tPhchOsW4FfjQ49dcC8jhi/0TupXtmxdXxIQo7gz4JenZ99E3SkC35s9fwRcX
tbgfck6nOtbrmL0WHAfO0b0kujcpIdvDIvyIPADkbXFALHadcDzE+L7sHSoStL4nBVR9hr1N+fV0
q7m+iDtpUlOQ2KWCWJbg+wQ1FlifNOItuj7doCzez3ZOTn79UrknKZOYoQSFl5DyFp5JgcMPlvpl
E/pqtyNHw4cEZBE5HP8ReyrjeYAN43ybgWgmxh7/R3uQsGryYXfCcmOogyqsQrekXX9BsZZVTKSE
ql96UF/kfQ4dyZ/FCE93nLbki6JdbYleR6dJapAvKAbKaNbJJJe3zENEs6WgPwrVXNN2eOUxf9GD
7f1zhO1adJjJqE5rJYj7jsfgo8fqKjjaG3tVmBCWcwO47rwMM/1YeY1CiRVLShqGy4m8xAf21qte
sbdwZvGpijx/h6sL9m+bAL3weGQiKAZRgBrVPofh9x4fNjOhzTR4Gom25azRR04HX67jc8TzJ7S9
5lidhr/MlZJqGFDCTSpAczUOcbEuLUHWk7hYBPsUBVh2iBoaYcQWxEeb0rG86jx1DHKtmdI2nrCf
L1P8nQfKFYxBEcvK7sh+DuT9cuqXRuJKoGd60T2v1U071BeFCMg7126K6pD+gPIZSg15PhGrsUjf
Sqt7cE+Cyw5mXXnCbDKlA9l+QRAidOLFylvu5WOm8VwbRnq8TMrAzsf0s1c1El6ue2r53wFCFHKV
Ej8504kXM8ObG6m1I5Dw2vt33z7AsDnbWCeX/blMo/WKksZ0KJRg3qzAzqQyUMtDZvXV6ZtAEFII
Kr+LQeQsnge+Wq2uEYPSyXRe984OU6MUHpEoBTo2zFxIRWkINmSYphJM/bup+sr6oAhmqpPHnFT2
d2Y5scWdeNjNA1ihp2ajYvl+Mc0gkghTA+d75i8RbzVqn/Sg85+lQguwdD+BxJs+THRIlFrZz6ld
hpsS36yXUfz+6dVVJbxTMicOtoYjSDWzay/eM7EeDzm2694ZOpveedkKy3YlAX1leP3yERGCMUpr
p9zyDUaTljuCldtBRXQV4mDMXgv2YR5SCDk9n53zNCu2+SyGM3Zi9c05bdU5eVDoHskEh+oAjVS+
gkznMul9iipHyVYCEaqJ/afLJ+Qtn4eEdpxp28EoufEN8ZDFn1X6ohGtGb1Vmw6unelL3oNjkzAe
NIIuthUjbOQ/z4LmJPlM0fmv2APyTRV1zssaRnQcVsEoZe3yW1kvEz6l6GiehW3U7qaiznFpaHS7
KsZkOfFuzvTA01zPjm//OXtkh34Hd9UIOEHQcQB9UyNwrmsGeTHfs77x3IPROOWh59cFmpZ7ulhV
5XjhVVbUUZDK5r+V1EA4hWNRCx+uP2kK4uqP9jWC6Mz2M1Imtm+NWDec11PLg0KMl73K4Nyttgwc
AA5Dr2Uiwj6L/NI1maPi6cVxZPOTvZGAKy4IRQQse4FDHiUo4F8baLJYetJQoO0ugDytq/9in/8Q
Mlxbx5kCPYKg1XvI2e07egJ5+6DB4zGLk8240EHRezgIyNjxIM3P7u34lodpvOa0AjCmpFbGdnlX
6arsTMr4zXlr58O5yPkH7vv7FujD77T/3LH9nCt6c853dxMHQii/aUHhHKYoMwqUOGQwh2TLtV9n
V9/dP3sCFf6OPhjW4B+3VYT2HafKrTEUjwyER+1QCLd/fnB2sFSsveBsoay8n9IWRej6CyoErZGO
lVcyE7dhziEU2UZ8SPXuH/2cEyy5A2E/0bl0E5Jumgc2p4wu3aonwb/tPBYks/gX0F0YQINUjaAz
k0xAH/796wqSHuCMzyAWNpWN634qaDq/bhYFhr6i4mJUb+EldnFQIYpAd+AUK1BBQG4NYe7M6Mcx
eO6HQnfEMadYYWsimjHwxAc+8pbCIqyhJOuJuuauT9NQ/4NczST6hNcTQ4zDG59He+dxAnR6764R
tJ0AOK9IGii4u4Q59B2x6YwIu2m7pCbPEy38LGFEhl1FFQnjxZCemDNmmL+HT8MVPY//I+riZawd
7rLBkFnoUBwaps7X/ACqL1iITIi5KCxY49hSPSYnfncvugRAmn1RZbmcpAW2kFENP2OWNphbTnJP
VPtx49smnbIggQQGvpU5y0hZcKHwUnpORFHbkkT3gdPdiE/uB4wzyCMTs2oMGkQgAUdDAWvOY62G
VYpgo5EESAhOZOQPy6M+2UUOT4+CINLG7ABrEtTYfzaECzxrQ3WNEqDtyWLJpF5pyGy5aGRlqZtu
uqfmU4hhfwd9C8ys/4s95CQj+UoxKuRdZLzK6xM1XECGk2Uq5LTBIO/mN81pk0eMkqRMFVm4825l
hkhxKm5zL6ha4Vw/4Ij0xZhiauUrBV/JShMzPdN23LOYR402XRmNNCP04SNpitBziqmcH27pkP0a
VF8qE1948Ui5Rk+k84EpOuh4crV/1pKZb7PLrxPICpaXm1Id2p94AIC/zQtToRGmduMOiKG1wwol
HSIFu/y0+BIOnxJiE0w/gz5AlXnuEfVj13fjB8jpzCX+W8jrSplVi5niQTQv0DklvxH6tTVVf9TI
BqlyotIKKOtJlZ4JxfmgRUHOypDTW1GqcfLGwFDPyGnG/I+8w6IdgQzK9wtA6+T5m+uUqcy5FlDB
cArfP45KvQSgumIyBKRNhw+6OMvAPqOnAepVwKe3qZRYhNNWuaFeRoemnlel35an200XeD2rQADJ
qLEjeNhnbH39yLTnIXcWQP5NhCrXFdoM95Q2vkVh79iqnG8IzxQ7Rrc14Vrp8QoBdPPaYMffGdDX
HnMc4TTbGFD7Xw//RpG7oMnZJddxJ6KKtSOg4+CNvL4ZrM5dhbaImGwAeq7fOFndR8eUHQ4qm+j8
zDSszfktlliHMHZsrT9cFx9m7LRXUC1q4h1lozC+SRq9lJEX21W/lUw121aCCcn19acRFlMx23Al
sNidCINTA8lV9dJS1PNwfvH9P1oKlfzd9b+W7pgQ3S3KjPQHrByjru2p6FiimgtTZtmfKkk7en8V
pFfPWRiuTOglYGGkhZOxqrA2kEv5RW7/q6C9zWbjA25Glk8UNEbn4LoKBUZCUmbGOCtXfurTu47b
NaEsERVEgatjD7Na/GFq2ROl/klJ9uNIcpkpnabM2Qpu6X2jQ0QBL+kqVAuNzyRZRUT91drR4aIf
kZPgx0==