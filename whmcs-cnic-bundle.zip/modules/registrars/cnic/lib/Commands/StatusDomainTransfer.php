<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzJCi2PMd0a9Bm8b1Kf/HJvfI83TOFzEzU166rs7V2drxRjuz8JivG4j4MfT4VitaLramg/b
UBeruK71w5SZRI9QlR5IIjwS9B7WKsWHzf0IBgG2QMO/VlUOb0SMIB4VmgnnkGn2P4X8Nm2Ah/w6
+i79gyXDuqD+6HMN+9rgSPTiAhMEwY3Nroe0Hz/enlR1ZkaHFXJLTKy8ofhvFkkYeQFkk89RpfWe
eoajYrbG8hfbnyM6wLg+CQ7zis+QaivuOuHBMaLnBc5XMRATCsgUDe4RlvxrPuOU6rOj9B252EYF
5p6eVF+qdGyZz4kagfeG3/bMeguo9IFriw8g3bgRhqrWBSqXudKcWjvUoUnnDpOj+pXYwvJix07T
dMr2aiNIO1s8mpBg98qWfFl0W6Zflyq1sqtz1/l2RBPVPZFBEao39+URWH7xhuNfMEzUKSi72Duj
aTVBVLbfAlAtURwX1gjjVdCpzoD1w1/Y7SFXA+6H/PIXSUlwpblPTL92piJlFogISHpyzzPNA09R
IjAyE8NVCsPhsSbd2cEQ+PIs71b/0bS0swVoecmXpgHNlxlrm6MFxKShcctBZ+aWecbOEf6V0zxD
xX+/fyV2PGbWs9E98i9R3Y9UwcIinrlbAAkqyebdKb9p+Btq7zu1GTRToToZtTYvNjixmZ6mK+Fw
aPLcaOwiB/bqtSCvAJgwRz/ui8MGlzMTZLIcr4Fw5gaWIEVccOEkHi17L/Dr3p8faS72mE7lz46t
hsmJGkHTqGQZ4sjM9s7J9ZXDZBljmF6+P62B60S83KvU3ZdiN0RzRMxjGTzioyfXkFVjxz8OzEeS
rU+YEdv09uZccJEsPKSkl3h4JUsozInnh7ioCjpyWn1QmvGl3LnNVuMh1KWG9oF9s4YQToBWw7eV
7uL76TaIiOyehwOZWDtuy6+ynXRqxI7W5rYOovqehBDgEQ8/o4GLDNzQO5nRLjXITJbAioHjazi4
1XxLYhOWDYR+WwiQOalKiWlU0Ustfe+WGlARY6TqVOMB/d+28BxIksFyUmPl+ZyzR4kBE/MgMKxh
A4k1Aw3OdysLf5jhr1BP+dLBRHvpldI7GytndO84XgUT9RYCwksd9MJdMA/5E90Q/oPuSXmfLRMQ
fmCR2zXhLh2Q/xRHBruhwdlzgHt/K3SGii9eCLkma0n2RVo3kn5dC3690EDzIvNB0j+FtFnJ0q+W
xpqjMCKnedbzLNLTOTOXyD1MTpL6htyrslGay13oP2/kjuw9hRt2KIg8T8/D2V0iQEyfyOepIl37
1yeDbNRs/132OW9vX1aiLyjuGHVt55Um5xSUZPqEbRyzixg6QMp/2AYAmrWWhVYw2Ltjwp7mYgbE
tIHIA0OruR7lQ1NbR94ei0wFHAWLv0cWoioxnzY81ckwJ/FjnYxUhIgtRsN30zeFN+T8ljhwx3xu
qHNPY7ESYVRrLYe/bOWQ8pvv4ckPzHU9jexs/QgHZd2GdjeicaYbgc6UW0zFkZ5g7OXgYrOZ5K+Y
qWpqihkO/WjRm9K4wKCQfVO2bYUvstCMso1eugWep021CwBXTgdgnYTLsJ+7Oef44A+l+tj/sjhx
nmvvnenN7j9jPxISyJMXgJL8MZEMQjFf8JG2Fb3OXE2BN4fiHeNroVGhA5VH4kVX1xhLiqKiGqi7
n+tn7da73+19LZD6+tr3zMY4URoG5IF9Ea3CpDU7XQhgf6/eMPUIWA4bKm64XBUKpmAFfdwL9RBf
e97NgMwMY1BBB9HYXU9SG3xzzUjtbjtwa+DRgavFijt2POed+NzMg2+e4NYZ8Vh0Z/A3duY964Jp
AVL3uv+PbBTYHLrM3mbMa+DwVPPzrdFjQMutZVx3DLAIjQ+um88bh6o8Yr3bHleT2SgHCa7gltLx
ZjB2Bk7p3rzwgJhl19R6V/OhJYs1szyOkCi0DDWrIg7TqREEImdOec7BXjE5NBD+hDKja8Ey86/E
t91JMmIQMSYpgxm9zf7y5Btms5sEnzXGf0vqK1ByjAjLVwdpkIEZaM4DO37lg1hYWDnO1NSEeNjZ
tif1okWA053xdTZ8hly5hK2BBaqTzD8hsCiD0oyRiDJyksU1HhGJ/a0eNUa7hVmSywR3wjHk+8Ji
TcrqKbP++ICCes2lkyQjQZNm4VyUsFaIGesVBu7ziVG92ztAhjXzJHfxBChmHeBfRhLzLZ4qigkm
g+pVkcZf4m3OSvpuDp3JeH8ATJPi1WIQbuIxvAMmWJw/eiJjOPdO940qKgC+9teCrA0p6sjDukop
VlmcQUHTWNn1zM7wOyGghBZocODefpEG+shs6UL2kFP3RL0LI+sY27v+kJsF0oKSJrrt9wJ5rCOb
H74tHdLhwfzQ5aiPwazhcXQNg0CFL/zXVh3kxbZmHljsbtimWv5zxr2WVsJTS46MhVJHVSwKA20W
5NL8001EjanV/CEXogEyBrnt36rj+ubIJaK7Bo9Nw4TQYAe52eHh81iam5IPaunPfQkt6ZzSeH6x
N5jzT/rcoH+4iOnPbf8Yk9+PugzMJeflcDe1AmGaJ7EQZE1EQY+wP+WdGjYYwnEf8luDQ7pOt6GV
ea2Jrm+F/JHsBdfPpt7rM5SQ7H8sx31PUu1YFVRzzLlPQLLGJ4jBUEK0pIywMjJg9Zk3EupQbcL1
ayJtPzYtfKkIJdhDmNYprZBV3mBicmLpyIm272mouUAu6z71tNnlj/KWv+RMDa1R8Cku6wADcPIH
DQSLZwTmngzkjJ9D1vGC+GLBfCqrXdPIdMHlNAAOI11f5OChAb+e62sb+EbAeGqGiPN1ubuDvxhN
4bdc+yyM7vhZQvlj5LkLHW0j+RVM6ljmY71hj7jts3JXHYscKZv/ikeJED4GlDOtfP806addM4Eu
dbKw0kARdhBlsobBFch9d75bvEOnQyZZy3TRxVz8HvCg8oH96HmMHv/LcWMRjqGYoZg0wN6w+XVm
RhPSkGJZ8CMPXQrQyIG5YfFSCZ4W3RceYeGbM3cw7hlem6wdnP3f0ltxLr9vd/HZDSREsfUKSytm
+bHurRW2IMi5XArSrWsTz2jGa32P3VGXfG9gnLL/1byrzT5nXP+tM2ic2QZ5HIXsQFwToxBDNBdp
k7pJMRMcacwAiXHhsinwjSCFq+wCPCMLry4Cc2mY97/ZkzY4Vh2WCBflyFMcRMHJsz+9d8vDmrQZ
0OaZacmRCW80tQD+KJKT