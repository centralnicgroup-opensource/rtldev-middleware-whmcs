<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu38nik5cpliK0PJwFbcn9GGh0yvUx33R8kurcjY91FOWxi7/pZSD39Z/Hq0R+DdPFOT9Gy3
Xmewb27cu9FdIzXZ3Ka/WrptTFAWDnlOx5wqfNkund/uRtc8rn8b0AbElRzCGALSfY84pvNRD6dH
DuuogdJfqzEfHPqFPdldfbNGiOp1wEG2tpw7PUy0N/h9Jy8Z92zenMaEGmIJyU19l9Z1fswbspT9
wkSWHHB2rl/8kPCCtpqFuYYMDLDMhbhGH0oxmbNL3Aaz1Aeez3//eS++rivgCegEAij6/eCrcH1O
g8X6vAV1wSFiB2PhJwzPQFlz6X/sg0QhmW3bFcaQYHthPp5UieIfTxeJ/kOBuXYfLW1HVD67FLFf
OsnrEflRLgVrJJDPtOcsBctORPTQtyWIbyACUzOiXmeNVJSxBNUS9jcB/bL7YfsS1kEugwkiaMkH
Zv/qkljyccCQkuEMQo8jyf4c0hYMRsMNDzHuFIOLEssYFPzBT1ssJT1bw+NvQZWwTdtR6CWx/21b
uXQ0VNim6h5MgTpjuvs/YHD/7YJv92rCpJjpkq43qz1kmCEE+oYII3PySsXaAr57h+yAG5SHnJGN
cJ/JfOPRBHfo5Z3qSeRRWeQJCtJnNjg5hmUogIVnI18Dh7WZUwINxIKm7K7FfrSNAIkTPxFlxrxT
sMpRxYPD+ZgzJv0HJTIOQbFRG7Dkfl9xFfF3R/dSw2DI6XDvMvky3U6ApKtuyAFDizb49SbUT2PV
lU03hkDMdAKA8nbZ2m+nmY9PRzjTI5J+RCCmiQjpMi0qA60F34boDPgMGnrojTk2DM/cr9pmjowA
gPvOR92Hit23c2FHxwrD5L1m/NfGrxssrnOPUaa52rTejsoJ+j3NtkmKqXk8eud7bj+KcTkDY5Tl
PJSnv5DZ0/4F35Avh8iYH64ftEkWTfCeahVDiSROKEf0cjzMrUBe/oSGQaDekWx0VU/r7BY8pTp5
wQlEvUGd6ivbEn7MJo1ioMK9S1PGI0yu0FHKq9kRTCu9bghj19+kUqqBfQ5FLy6LU/4XkkWza1sR
MVsjPiiLII94yc25jtLJvvpKsirhaVxAiZaUtoMxiyPXkrZZ3rdfBp3U1bDKIWW+B8R5jLXljXTi
wVoiCnrukyyiA8V09fhRhS/YeiLkGL7VgbN+pNnaigogQ5IkESjt+ceLY/VpSNsSbVVaOk0pMFTl
aT65UcrQwVa1pMRXO546RmgmTuX0DMtluOMI0PFK4mtUrLbUZYkrvHPcaBA1XnWB/kLDbxQv76+H
O/jrNQYwcFBQgvJGG1vTyjgVPm24k1K3Xxc9kCXyCrm0rQcNKpB6Ry/yGAq3/mVj9NuRnF5diY3R
LlMYNhsdOOoUvNpwifQSLHeULPKMnh7U3ehBWxZL4/ZJsdzxCjC3zKH70RAHdasB9YlL7UnzqjC9
or+pyD080tpFrjHyKYCEzVQNj0eS4q26re856MYa3pWJlUlmllNFyWloIvbqRH1T8bTGYpgotVDv
yfmMBOPeaT2oFkZa2e5Rr7jY9hNzhHIhkuZ7GU1B0wFmMGQnjh1WlOL9FIqcq7tbymS1izSSYbyC
N8S2E0rKZpICsT+/zxYWm2G5bQxBLE20+xwMCphtwWTVrEwL5QhfTF8XmGvG+cOemycdYVV9+BuO
4iFb2AhHwqKGMqr2qgYxesZ/V5rRf+VP12VF1C58JTwGTcK6r3TCqKdijXiNKqlom0PXnt2K6n3Y
KwILrVXKfuPTD4g0mEcIT6AsfIZI0Z3jlxSLTHoadeu3pG4aY16aT77M3PkpPwR1VpqeZ4vl+b78
jUbPTP9hPfjDn4M6iw44N9DKWktmzm4pUGR0o3V7Zhh2ZNmhkOctq6rHlobOSZenN5uoUHQIcplC
SgAC2Ed7E3beKQ+gWUdy8fU0EWmTeArf/ZArKdgu0yEG6hx4icEbat6j7ywOAsCiNWV20HHyDTC0
cj5wJlEFJr+JaKthtQzV4xLxjMBN+yU8i5Blm9GXDXTSpk/gn5/2UDf57fthCVySHqnxRLhFBaob
Gb77spPW25BozW7RM3LKu31eiCEpygPF1CPPuUBhzLqxbudNgVRejQSo0a3E8xtExUNRQfoxyFig
//pMrAF25BrzI0FqKVwmqBoHjBMftPgthgX/EgapXFqXXqUrOBdFUR8VWJXkaAlMbthW0p0f+ZAB
GmqRjb0UXR9Ec3qQkiex4tsGR4+Ij1AdgQY7yFRV9XqnLX7h0c2AIpa1+eFEG2/gGaKAypCbtOgT
0t//wz5kGibwaAOMzp01Y+rvK5YDwXJYgImuoiqk3wN05rF8qwIiOMuAog99KsGepO5GWgomNtlP
9JUu3XyZaa+y90K01EDzshP8/up5WOA+CSh5VDdGESmjmsNYA1/uq1cVuyJGC9ccKx+DSywIkvty
qLrLdOTLbAIRSi/WQQ/ywAjd7xL70uhSkRs8XpY+PxsUX6pKbyYgIYFSEoK9IB0C3p1rnfE4Og5U
rFbWkO/yhTqKemgb8VaZtpjHNqd20+CE60v0MExXfQTWwNPimRvZDmYQ7YCJ6BcKJZXdd+ia/bnM
oeCplCJm+dB6rk1sY7RE7wZpslA0usF6pEYecs8OBNZi36RbOgjrXXmAbBBKTsas1HlHrF9mRg9m
/28mXEosuK0ESEj9VR/rvgJqzcczOMjPyaDIhQ0snh5sOQSVupKzvRo8RSP8Noh/P6w0+LMkV1ad
vqh3xxkOyPQql5lHQQH886Aoj+GpVrwTCeE2WUcGasDA4Q+EZ0Y7RkSlydxstZtAs+grYLMUMIOV
iXn+N5oL+uaO0ehH3h84MiqSjBBv3r/CFwcv49QrzLRcNDbA4l2IdV1cTrbqApqPDSkjwR1OYxUn
NR+tBtemzG9nkoHwqaDAi0QmVJcy5pWM6svCY6f/dtnohbWbD3/8OzbgcYpK//FDR2H6tWzUxN9z
HDgNTmy8DKg+B/YU90tH9uJObVWUUXTUy3EbI/TpGP6dyUVTD0kz5hDS9085GeFxMI8TKKkJoogr
HYiB5Z+5X0jQg7NXuck1bhpzAr5DWdPL1Fev8ikOi+UZBbhu/QOaCAyNMqRjmhcpr4iGzf4bz0z3
oOC5zH1MMoJZ2jU+1D6/xMmh8VD058S3ysSMqfYgqkANiM63P/IzVzL6uwUqoKPkbW==