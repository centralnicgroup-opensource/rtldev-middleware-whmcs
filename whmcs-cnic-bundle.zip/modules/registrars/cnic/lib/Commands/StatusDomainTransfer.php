<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwT/VEASx4JMMR7fmUgh4CLmbkzZeOrgol07hTn0hLKG/FjFijiMJT6POjFUirUdYmhzdnYH
PHxOMGL0n9+9jw/F8X+JNitwZTBcX5xb4cS4EcgpfA4oyVv2+4epAkXZBvMu377ckf4G+fZ3SWLW
2xr4AQbWjOri5eqk0ONoCilrLvqqrRJCQoHzQhxIALwAPUYZK9r6Cq811meldzqII6cDXlpo6GbB
+/fxgZu2PV//IYOkk+FBnXmK/2gUy/AQROnn5xljBHk5d++lcFjXiRrN4meURsqJChupNOSwFOxU
I44aI3J/xiPTHlL9gv/fWQE2OJvGiWVMm+iooknJ+lA+KOPGAlIxZT06177LCegXgYMvnQZ1uKvK
0evwItUpAS27kNgA7Rdm3w+OAIodU2wVMfymXz/BUPRsLlotpPfr06v8Y+MsinkSBcotgA9fPPCR
BAA6BApf/XNbCrXAaow3ku1DUi5/QxpBadk4FSTwyEe3pCZp+B/Fym2So53H9u3mWh1TcCqQ3YoW
VkloOm7EIMDYxIJwYdP7XJV/y8UYVbtPWqUuYEZSZSe91NfX1xsTQ2LxyiQ4K72gqo2LxJO1VcCY
iJsRj8u17+2OHfwDMEsh5c5yscONtTdFlIo4McJXknm0A3H5ftszac21mFwVB13dDUP4mLWeq7c/
rZitJYwoyymH8lNvgsy9StDR7uQo2PfwtPuWJgU8YAaSoceLugo3q/1mhwkKw/Rap44LKlgxH5pY
Cc7UBZ/iyYCO2npN7l/VFyGti7/lefa8vSRwGCb80JvHYkPYVtfkZtAi+u74k8eZZNkhFbXYqvK8
TKhvy2L8TQIJvFgGdVLKx+fJ0YvXLOMaVWzmM8z/8sjMjPBTlfKjqUQ7ZsnpAy+aCFWtgNWrKb0J
x2tOfFOG14vItDkjuOwspM/0bmlqwRw9D03Ag0gFaNSMhgBZ4WdBA+SkVm7AjjGEo0AeUeX8zQ7+
Q4mzc95Kwb06jn1it+Ha6BJvfSAzVTn0BPWYA50u3yoxqmRIh1YtfkI4qOQgZO8Iyc2UqXDTP1wl
d0gPPnf5W52JyfuCZbbFJv6iINpUo1rwasQtWrXJG2i+ITVMgSjsOMSvz/KGcxkrsHwV0SyFeQ7R
BuCYleRyzaf03ztQATPQPFkJmWqRELhXRQ7+qOXklgOOnoNRFfcWcOVa4NeMbtUv2yCKKGTdj3/r
xyRLde5BOxJMvmszDBc/VVz3nbNKbOPW2XUEYmOoLa5aq/3V0IuWd3X+5pMesUuCaOh7U2yCvbGE
pX4sT5ts/1iJgpWLRJeDzYJ/yQHAQlYycAF06HUOvm+iZOP52F+w4ZantnrBjMKh27/mSfscIr+I
L8eVAQ/3Mt5dwKLH0wPv0mnz2RI4un7LgnOSed8P8kvhxFguz3JgY6hdpRedh246roYMYQzs/kQf
aClM2j6gdRqDiqxQMVLYN1ni8PmFQNluZZTaBhy1TOWL1fWWV4ZFHrRUGi9acjxJXKO7LVaWXoXh
Zl6xf5laRfhc5DEAJvS5CVLdvH+NxglFe+564kBpRorjg1SzImfSwjG4KXpN12nLXWSOsploIqBt
4W3E8lZXlCukdWpd5lZi1lV/kT9l8ctViM8YGruPpLwYRCcxHt8m5j2FEVnJbF/vuHV1tIPtU6Iw
veDC8D/fGSECzf+AQepjyrWCVrLkP+yU2Cc/08nMDB9qzlZdQWc9VxjHkxRE01LW9khFYMEJey+Z
QqtwA3xty7VV7rCrxkthy3yVbIVnlMc5fDw8IDjoLLqGrvlOH+WeuVvr7EKWwO2VdpSHgLKO9xy5
PFeCTlb5C6i9spN9LuPuiNWUQkF0t+5CQ4EX1ntmvKmB0ePsLmT3za/tj0KjKSST3I7brQHTNigp
D+i8qoCF/y/2d0C7anulSL+HYGCpyZ+pR7o5/uXlrnD51LMIYUgjnbscXtXbPt7YNs16s4za6vtm
DZ8uenc+0uBS7+B0swIrjmcFC0zJN4yThLQGPlaSC13XnPMjfP8QNgibZeUyRSDMeSrj/zwzJ7R5
6Lg/uuyxt5X0gRv4CSGMvgJmKRQ/xRXfO0W62jqsDvWPV8A/Yq1adHpulO5owJPBjY1fUhKtpmum
aO3mRF8lLLpTUGnXNti3uTZJ4R1JFyO0HlKUDQHN5gAT6X0diOhYLP9Mp6eq43Y+D2SQqeEXl8iN
SkPdxKlUhqj36kjvP284QfhTnTZHT13OT3VUnlhCXJQOFa6HLhfHspaESqht4ckcuyP/m9w+j+2K
0K2AVcrGs+O6dYA7Ry6wArpUvq/FaJ8hrTTdRtDekJORuzODrjQ9PYS6noEtv2Mw2I2mxkv6vk3a
PKNLYt0guZXUhE7NJEZvoB3oEPvzd56UtVHhSpYhG4MoFZ230fef+bZ2TT1ZhjwTlKVnV2N3qA1v
UN8GMPoTnTtofi284S45W9eilEuNzi6J4fkdg5g5/YQSgB9KH/qRAKOxiDjLmpvp/whAuKABqw9U
IHt6Qcpe26B5oYpPN4KsYtIJUr9lJ9K7nYhTueoWN9/agt3z4Cqzjz6XGBC4fS6s+9fo/iX0zaUe
fKLw7pb9G9itSOYHjovWcJx0ARu4/HfllYa7ZmQf+7a5y8aUw16h+5T4vlpz216IznmpxrewBsa0
dMTpqxwlUMBYA+i6wC+AskplGfPKUTwVLOuapCW8/WNJT6jNQnCHw3hLrmc9o2fiGqYTK1jBLrfx
OHvovK/Rm+Tu+1itRss4fAFaimEF7KsdgSoo840H8Td+LXLWdqnh3KNP3z5hGCkQIDangI4945sj
Sz7Y0l7JMmsAi1bXvZKaXy0WhptUWYOcqE8xy7r1Fv2N0WsawX34e2IX0LdLnRwt6QAiCnhz9aHx
yep0gm3/ccaIqybLgBjdb0mz5PYzM/bBeUMYFRdGCOaeguyUjnL3uNkQA8LMYk8wiKLPxQ0xSlQ3
1tPnJP5qdGjZvpgeaX8lQGrcxmg2Nqyg97vzwXgTOgDUHscN3Hy4OKj/LOcL69xLnvBwf2rxRZzB
lAcDxC9nVMgJg7mXWQQa1I7dO5QPzzcVMoGaTWjz70FXjBi/Ob0XxSUYhF8IfbqJ0vfPxgYEmNyU
w2ITtIqu279OExno/Ps9Y3OxM3GmkAZS8pf0c1z7iEu834w69qTzXLOw7IFRj8o+te4OwKL5kstk
YsvUWlIoUpiZW0==