<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+epX+fGaNlDBVqIoGpz++Hp0G2T4PMZ7Rku8HSkPVo3FrMRWQDPZPeMu1gv3P2JkQ8HbMi7
TrK6ATgmhsBr+crKTnLsA4dg72Ql/lZWR1+l9G0R6JSk5r8AVPVeNQDq8fkHqjRfxkA2nkWJ5qmp
xMKvUNfDAJjCVlC28ksYcNRYt41rEgDXJj1f8t2eBK19/s5oxrSIrk+AIFt2UL0ERLGZ1wDNSRwH
lF3FFP7e6p1OuhdRNgEm2TeCDHSjGjqWVtb+Vx3TJcoLmpISkowBr9pBQUPaYIKEZlCpu4OZsukH
7sWKb+TjNrhJzoqVtkzofOQkY/0uMb0OhCf1pCG+XXYUSgnPabCMvLt2pFigNvythHL3QPhQ6xUA
v35hvstiK2rCbfLBkpBkABeIBIPNPFrjQ7IZ+tJNSsvvPVT7m7rQs+67dKfh0D8P+XHxYwEIpf46
LOA2zfrjgwlZ3HlNQbKbcOgL4EfpPoMYU0jNUDDgqXvnsvGlhzGtdvIKbsDdCu3VJrHKbLbru1EX
aV8Zr5LoTIWvHBfXhyOTd+0YQ7tWQ256srXopP3Xhf8qtGp571T1e4OhvHpvzMMIMDaRCl5JBqVH
n2jzt2kMzJDe0L7LS+clIBjcDsO/AqlPvbYBXKT2zSrmlc2tRq6kmXCpUz1O9eGXQ6dT3ATvhWM4
5bPOMwWYajF8qYktlhpGetB3V6KFbmrI0Rzz+yXSam7uWZ4UzRXn+50WclyAM5MEUfQHs7ZaYG8P
DBCrjbFp6rzVbzC/JoMaGU+JAMUZjcpduvOXAFtPY4ZEdLvXIBxc5zVzwWz0ZvFTFmfnT2FYi8Dh
g/76oI3CboZDzCMLY65T88sIaZDgmuX9+wLgD0LapBmkL+Y+ablByWdYWpHNYUTdWECrHmtPT8DE
2X00rttYXHaMry9PGgmTLl/CJ7gcYyNOmehzig0GUnHyURNI7YD1zK1t6HiXA0vYCtQK6vrYJFHJ
CtopJe/BqlFpR1THA1Z0XbeBvIYlP2jGSSVFHJJsxuh/7enk0EVgUIm2Cz+bQpcWRQHntC0/JKVw
10q+srBy37+nY6TLjFQZ9OTM4JHqoaaKBBBTA20afBe6NyUX5bcUdLcOY2bNyacpBFH5WZAnaV4w
58rSuisLQ+4QNxONHSrfSeX79UGLjmgDI44oK4tv9Ng3ZLHPxS/KRltofsWoLtCplUKxLIrNh/kz
7HMx9sIRj7rYOabGqM7C4WBjgpRpjfJ16sFNA2upNoJff8+rvj++0A78ce/SLh1VWX1wdRymjj8i
zqB7RSdQDJb9x0xARgenzJPswYV6MglV5vWzERpgsTkO0VOhRMsJrt83s1cAI4eUiPcobZWJA1ij
2rqsZsK+HLadfAdjQgZSFo9s8ZGF54jTZWFF/2f1RQWJAR4f/QoO8Fb+8zNGAsGzeMGrojaIt/sD
Fi1EG6SxogYby0qVIbZcSgkPUj1jgE3qIzJh+j6NEbl47yKNtJ8L5IV01UrgVoQtMwD+hrCg8e4Y
DApoV64tMvIbp8fqZ/9kLQfaHnbDdT5fbR3K+90ck8uR3QF91gFMaakWM5rH1CRJ1q+LV13LRjOi
83GoKoYZtA4PRYBrcvdMzOR68Vd/Va7PcYxkLQY04uE4V2O80CuIghBQwQa1Kk25K/C5Tz7M9qJ+
kpZFX45kIHtmEQSVGVncLJ3/007wrciTDSM9kWBWfVsgBjlonz6uVIJAl+zq/7yaXwh7rUzNMKjU
3vKLfHCvRGAieOm4N6eDrQT0rfN0ryS7d1A6glCz+Pc3Zf4kIgPxzBRsqJTX5P9PmTPrhMYu29ns
7LdO7couf9aYfrREQNtlYihlKrJ/jxV6/87EAhGIb8rRG/BQSKzQt0puv1eoBYvFhOHVkhQBeA+M
VJaIR2X5VDrdujWXOQ8wgadKH3T9VRCElVLGaZHwNDxUPAJVo+/Z7YLzZzyQQoht+mgzFf2aOtVE
k1kDeYywDMF0gdKX+54GEVnqPKdOvMoVlK0DNUHpT/hNPs82cXg41zhc5AvFIXiZjrTdq78dY/iT
/wT3ys5ugODM+zNlekk9KzkAK7/ZLd/ehiHDmuULBEgHFg+0mwONcO14SDSLYQ7Z2XF7SxmpzFh+
RdAs4/HFPTcTwgYi+2MAbtaaprHjZBTjBrGMfvYXjsswbYu5Ypzi76zJc+IOb63duzOuujR5iyEp
Vv18CtefkpwlSuS9mSpffTgBDCAO6pFvYJO9xxwqsuyWaqOhWfLvNUwLOEVfZG9rPZu3XtQfHpOu
zkrAjX43eDSXIx5yd7t3b3iYx9z4yzKoQ+XyOWSnV8DghixGNZ9L9np18u+rvgTQu6iEzT7yLwdB
80Dkc6aLiFwgRXhQSjLkkqmxqBKx54Y9f2zAP9f8WNW8uA4/rJsfrXFZcnqNwkz7uEzP/LKhhEiv
cJ39jI0RNFTKkb71JDvF/fkO12WtIKX3UKVYcERTNFOaDpDpwLGaSbv9g18UkiTFb0Q86A/8293e
WjAQT+NaSgq4ouDC3tiJ1Bd7bTg8QoYemAiYhCUnyPcvMsThnerVPIBT0K5k59jh3N+G1h71b3Y7
8aEHXeoH9LHTKJAtRbYEtdFEf7gHz1i5NxwXt6TvlFEhKPf5yaJ5UFGD+xZZ69QHuUVXMisG1PTG
Yd5owiIxCmwrsr+c5JCDudh94hit+6VIolzVDBgWlZ8S31Uki7j2dXkw0cZHPQhrDryEFG7/ndJ5
SJERikOdC6Re0Ds+wEMMuhXGlm6j5MBZZWSaEsJvV2u8FJE8m1Fq8R+bg4FhBu3SxxxAgyuj0sq4
0oLMgJdAI36i74lPvNDMLB1zu4RuEGM5tJkxD+qtimaThl97LRHU1S+GJ/ibTwxC7mIBoTEeDFWo
eyduuzZwclXScHcm6NsuAF0t6gFcqc2mCZqKSI+YP1IdQS9vXV2zrgNBu30wGyBX6x+O43GGPAnr
turciav/NnzMXM3/Afamv2FibsX6yITpBRSW/69QHhoG9AETMNqBgFThkT2+oXd71Led1cg1Cr7n
O9iwctSzza3UkhEp1oDLYgyE2dasxwuBEKyQ5TNdRmtcMCgfM3qR7XR4IR0ng4UiyPaHLa9sm5t2
Fz0+397AVjUOJS+W3cuj+/Hu9Ssu8Ldb8TMZEpQjl+9jjLkJnB3cs41DckucTJ0McQma0mWMpRhC
CROB