<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzwR0SX5IFhl45QKwygwU+waUZGkCXBU6wYujgMooX61JUOnTrpdIWY/svxqdRlcOi/UocXA
amDMAPKEmt9HfoIit5IPCKkjMIly0fuhbQe3iFCOMP7Zpdpjh+9k5eZNDbuwjEbRY27mn1VyyeXy
b6P+KUENAdM7iMy9Q99ha7cgQiI2pacvY38gRj+tO2uaLAgPZz+fXurpDfwHUyy4/RUL/md7j6Uo
yO/UpmY3WfTRIOygdEmF5bMQyER/QmMoPvLoxZxcDrKHnBWZAa8J2NHJAw5ha68vaSl3mZlubtnT
p0T/lAyW80fsgMiBK456koLekUJTG96E2iNwqSehJESm7Ya2ZPd2naUlk+mcp9ZuoG97sZaTyPvl
4OiOfNWVaZ/K97axAtkVJLvjAkWhIsC3+qPkWbdlLfVvv2LQlVdffJZ7kvFGVNO3nE3yUaduZ11D
SK2MCOCwkp0qTCTkO7j+yZPtNvadPZCOkpSnJd/OVjD6PSjJS+6+X75huHRloG6ZpXxYdAtfIuLT
vePOgECFysnjQ8mF8FQzu7TbtyPednfRGbrJ4s7IMclHek5ryvsC9V86UNnh/9KEMyOCTMZUSdcA
6egiEhnwsk9XIoOUUxFqklfPqpObLAvAs/w0VwdVULIrOdH0u0C7sEQC7rAMp+1YlLJYOqZ0ZRym
hI/Ur5nmw5OIssKmbxXiKartkDUbf9kh2KpU2nzuviO6OZtBnvR+zmYTt9IVDHGFXhN1SGK8zefO
P9/JqLLf/TToz9KS1dCEfrZA0FLOIo51BZlUC0ML/ZcG3gV81HZnUE5cfvzJpy9AvI+2uWCtvdz6
GN1p4kdDqHD8hlv8HUJvMP159/V8G3Cx77HwtoQfa0XBO+fCAqkqr9DZg+pmN9M1LGfgiCyJrUGK
Xrs8rcHGjatHJeTGPCjDXhGxDRr/H/425sI2A2UD6AmX6MV+2nNWM1nGV4uzwOrICwL+CAF17ais
7MuHnV43bk8h12Bj7ZgVA/yjLEOoT3AtpoY8DfYfWFYlO6gqJwV3VmGveS1Qy5wnGxjg/EMH1Crz
Icen6Bla9PdXMfKDbf2DkIHT3KVulDGemhdqp+yXtuCOCr3o5IbtPeePBS9CYsc6Rgq4OBBlN9ZE
L8nzABfCY2sLSzt0psOC9dPO02j0K0bori54mGx5oCEqVp3tdwRVj5BANOKidpx+flNX4Tgy3Gp8
IeYXae3xku+j0dZbinsBBjprRXSbQBTswENq1iPvDl23fa1kVa0s6L5By/EzroTdKBqSJScZqYNL
SeUrPuuAm2dFRcuEAqMFCoU/8IP8Hak0m0A/jNyY6DDeXXZNS/AEf0D1Jv5B/s6NHY3+eGldyROI
SzJYB3rX2Wp66W330ay/aC6tG01dBejYiARPCtwxD9iMqjtGlHMsfsUT1f7qylOlDMe3Nr13uM0V
OMtW5gEVxMlamyzORb0dFaOCunMq4DHEOTw+ez9Eiij5ZiUbUK7Nr34E0WxMCRrjyeQsNKvSru3+
tJiUkItNf9VVw6DzSSSkIi6i/x1KomLib1m3V2opEJN+eOyu17T/nE2WZacyLiMgaJqNLshJb/6J
179uASazV+n5N5uqUQqWxNlakj45Nx9Z15TiGsdbMdvW/UGYTOJmbjYGHNRdlHDEnGsCdu91sY4N
zlNSloiFhPpgwJXF5wWgwHmIiKG22Y0/DD8QV2jn+wOE7iFGd9ygx41JxjOhwFwY20ghzSqez5U3
L+PCOcgBm2l9yDiPIsVzTI6sYWhM7rkRTNQzyXxj7I2AtK1MfALMyDEK1wbCkEQ0Bn1r5n/z+Vul
tSJv3PsnvaKB31NHGOy+4+D+Bb2sbLan7AeIK8lA5fb1gDJxutDr0pU6Pf3z5duW761pTvRSrid8
JnwOQ1VxVyPHXyYGboQe5T9NJ911W1jog9SVPR9lIH/g/uwQkpfZe3RAPDv5dWiKUqtMbhZhHB6T
LS95TfLrgmgc6PlqCyIGIalgAMD/dvF0nhAQw6+bmfyOVF/vgAc7hcj2uPUP+Ho3T6lyDXmKAHwr
8+K21upx+a/2UuEt3uSCtGzHVXTXvjInP0sdivS5BkKGYj2+A7luC18jvZje+KgH3u7kEI1U4nfv
XOek/WUn9lDphoO2Yy686wxe/TOhTCvy+oGIZDwk6oumRztkay+ioL8H3vIyTfCSmWEBpgFoTZ5h
8nJNL5bGrMJVSkn0ETAkl8bHE4enqpwH2mXtQGYz9asuEd5of9pBeAg9QpKi/qZYN0aEfJ1M55hJ
rnaQreMAsRZewhk3EJvgbBegUeFaXW6lgFZfIfq0G+WlbejJ+EBve5K4V2qL5J/RpJLVJVMTiiDB
Yclz0+RyR+d09x6Pp5yKKsuti2GwocGFxGNE9E00TJ+ZejaBGvE8ZP+Rx7w/+TZVWig6iHtK+A8b
5aOPHymdf13iibVzS/GcC7qTH1hAfP/a7vZhUt+u+Ql1SFa0MmOkXgO3T7DWAs9Jmd+mDFEvg5xD
jQ7pp5cBQhDbIq8rWuDvGUcTe5oBeBD9fD4LcV/PiFqJrlo5tMGl+d78QmZ2d5hZMnNVE4gpm9mI
N67CMnvnETylUVO98+lONdI++xwEPCDwGO2smq/KkFrscjgEcSCKz8qZrF/sA5HezMsTd9hGeEAu
cispH98gC3tnuuieU23yBROPasWq/yb6PuQQkONGv9tP48+k8H7+fzoRk/ubaLLLhYy8pI6InWXB
2twfrEDZNLZGjkDqBYqCz4Vfkarj8aIvqMvDrrw1kKwcdGQ/PYojplBcQHe6JF272d8SDRrvSAbV
tAeRCn/qzRIF6XZLvMGaAzyijZAkxeu=