<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/8+ZNGchtLxF/COLzdwucaSLx7ZKwg25RUuwXGc6rzEhMLZQEN8lT+1GYcd2yxLOqZ1Lbmg
/2O2n3Bps7CWX4hIhgaLBPFCxczdb9/zscQrrY2GwdHTtnNkyOCwKxX9eFcR+SM4VaGqu4YWvhEA
MDpC9otaz8fQA3Cb5fMe3dl6VtHWR7sNsNPqWjZMb048JSuOIp5NPA+2377vkextGe+8KErTBiUn
A/u57Tl76VADkBSbcq+weyhiymZ8Q9Y+Ucs4QM4BibGvDFIXHeienCM7Ui1iC+wH4G3/gLUPZOv7
vkScBfO2XzZKZ9TLm1nnnYXiq/fWHBfn4HXHPS+OmNgxOIoIyXQ7vH85iLW5yngFlxE66IlGABqX
CFkDXpNEc8gAESB4SqdrLaFO3dN2b2vkTwHh6ar+biN4+j2aZDIiCpC8mbMi7C6+NrWcSPIGNACd
AYqOU6HFtkgb11zX9aFoxk/VYAzks/hDSI5qLdrNhEx9OWctRBZPSMdgQwROFiGQ6Ifw9p/G+Brt
xBMqoWQGPCiTn8joniWWZ70qeNxRlR8StpiHX1JVYE+IzkDOEO8dTyFYC9VhEZaByCXdCGR5c++6
4T3uZ916CqO+0kZli2uXBDdwtu2uXszcaKYxDdHzjO74Cqjo6bSKReOA/EKwSZNW283RLJAow9FB
2lLeOMVY25uWZwZauzUOMsUuy/HQrO1ccSKzy2A5mkSj2kMmdVVcyx5gMwnszwyUb92Dmquv93Gw
rhEOfSWhIrCbvK7LwTP5GJ9Zi0z4zo1njFwr8izkIH3WePbEY/9GZBo1GFfEdxEj1fqGzjDXoQ86
/4y7mgHLf6Zt/qrRmor/SgfSM/RWGqHERwm5tUxTc+alq+P3G+HbFsFrrunFwwd6AWpDGqtEWazn
S0WhNcKTIVlaX1pHK1JsGqgKhe57v/cZdaGx1xcbVl4/OVYqjgz5f2qlSCZkWFK4U7ApVb9OpS8M
eKlxBvuWEzoV0Rjm9P0kmZTPVh1hcgFWfHElrvjnEagkgxe8NaqILQTC+LOT75XJ2lASdSswbcVz
FrZfWOfHJGZRoXXJIDj8PD8qxfKMujEhj2/VbAu9lOwiGRow5fUc06PxGSBV88bOF+rlHkXpscOA
Nwma/VoxP8MlotjT61j3kX18+OKVyGhhPn4i0yjYpF8hmBnOffE042uNegA4ffBxB7PhXlZr/O8q
rEw4/H+dYzHljKE/T26wRs0fXvQOLZdEKkRaWHuzGpKOQgxH7/+4ESpyLgRcvDGl3lRtPCZKsuzl
3+1KT1zlRml0BR4jYGOYG9g4E/z3i6//4isxMMIXtUJt7L9MKFpL2uLB/r9BxRX8Q2eW7zXqAzdz
iWTOXBYIsGscPNf8NacObzUtuOs/cHXZtcVKG5nu3zHJ+/jb7ARz8/0amEEOp2nI5lCgkjMVudO9
ki7Z8EGPmYOwggYYifvmjyShx++YqyLlvpq3sJRUJjKmu8/Dd/TNjzocdAewj9FLe+ttEW+k2CFs
/zha/liW+AomvvYT8VqU2D7qCLXzfr6ZIRnPslw6qC2g82F1A75MUi5eocxQT4owGlWoQ/e1k6T4
7gaYRORahCWYTDu8WiI3MDBSAJGG2vqeC8F4fHWnOORNdR0nRgFkiN6QpGj9nLmfBUx3MU6Bw8x0
FHLhgFnGpD62Nu3BimF/i/uMG0Dyr2wtDEFx/Q82Wfi0sBgsDLRW9WPCx99sAAfaw7yO4k74sDNC
2gvKMKr3OHdLOXJqOB1RWGSOWaXdnAVxu69TxMgrgNSx8Y4qf5t8scmJKBnbD+GHms5hQ2LYBt65
fOT0wQChb/IcODNIhh//3JMwzGesED1/s9AX8Z/KEuUQ3iKFJD+/heA4CkMh2gB+6HKxuvv1kcBC
ODticG6oZ1Sbhvi2f06eaYCda/LAITtdejSFDs3LTI3qjhg07F++t0imtP1AhB5M4vhiQz2IOBT7
mWqPz1DG0sRt3JG74wY5h1Y8OsT0pqLZj8S5lJBwkENwnKfGvY2rh0Os6F+Q+4KIJU1lrcQXP6OQ
9OCXL2pvaUajrXgLtUauuuneVO/Lb+AYEF9vLMEdOkZmXRgkduwIXz0wWDCUKllI8nUlPDZVYgHW
elNXYQdfirc088vBG2I3lX5+pFh6p/lZuJaHfvBzQ0vsfmrwesd7g+EB84hz8xLuEFZ/qa0qDO0C
LPAPy4nk6zstaloKwDKsxgFdMy2BqS/+oOwQGSfptL66H2ongaZN1oYBhk34v6i2rOcKrP7/zn5v
Z8NM5iR7IhxryfzxGMHhvSgz2Ksnz7yL97HqdAlIQGapIok/xLclHHpkVDfvb+6zX7n6fJ3SLF9m
HRAqBFrhkWZXohThGwL0Zf1NgCna7y/G/QytmD30i/K6flZByb7I/6mvpqdxN6n3lq07BFmfBUip
K4eTv0mpV0EXpN6X0ZX1CJU17IxJSVhvqzk7u5yAj05fIVWnPIiqCiKvv8jsdrHYBFV2Ne9wMzGe
R/K85PQf0KAlgClaAoSCZ5C67pHZoqDGh06i8KQl0S1SqFATKJvGSLZ90Hk056bQcAR32FgZvX/G
jyMMmcVyovq8uhSvmZ0Q/n3DrjeIKIzRvz2jDR8gMMjrJi7WJtKQk7TEbWT3XNmr/BnHXzsUNVnp
CxfPU4+plblipBAq2UatScsFkp3tvbxAYHzf5M9H22Fa7YVKmWSGgzBcD5K5aN7hXY1KteIHfYcC
Ia4TKff7EBERWq9lhfJEeLYhBqoIsKk4KP1ERZMcHz6jQrj2z/W2tprbz6XznQZbSOerx6RxvIq1
GF1tMHopOAZ6q6NZG4gxQBxUTe69gAlIOVW=