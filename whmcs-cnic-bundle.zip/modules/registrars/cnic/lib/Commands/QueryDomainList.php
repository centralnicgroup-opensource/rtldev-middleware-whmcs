<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrOjoaZwiivlW+1VQqrMwJP1ReAy/6fMmxUuS4x0K1J7pQv7r2oQ5OxjfnOG73W4imtqBrnT
tWks+w53MnFxLtpswv4tiV8j1Oaapyf77D7Jt6vs9ruatv60L4nqI/yj5XgTz7BYH7efeMdhAWdH
Csx0I4GnFIBa+GE/PDohhJlmnq9Vj2JqGya9+4RMs3awaAJrlv7CxMlKEsjqAGYSengU34slkZu2
oTJEIQkYwUp2kOU/Xbqd9CoxpDvzOt6FAcsWMFfkl3Z78Es38Wkf2AQJCgffZbHsFKYv83/Gz8eX
6WWW1hMlj6jHeO0OAVWR9xMfYzsuVBO6XW0M0uI5ziOHsExndz+S28Js28hKTeLFJBRpzC8kFt4G
GULacLDiq1qARrQRDENG26swAXWgGq35NSrgDDlUH7kxHGnbhj7hgQytia4wE/zXXejSbtfy2K0B
AwLFXILmDkU2HGtiyIxTiSBtRyqhlj3XszBSEqu5erTexBE0J1r2T6xj3SOYuCrQufux3o9+hrTx
ZhF7JAB4QLUr+mLAVwE73aqtJDe9s0LxmvYOatgZVmVjoaZuBF/mp0mq88ePAtYV2xYDtirZZED6
9P7k0yzCoWbmxvJmnAy46i0wffRGtr7c2+clfzRGGIqqeMoU0VVQmZCo71sLQW/VsFW6UxlYVCOc
3f/v1BM3OGubyy8XKtDFgysQM/Za7Itj4rSYvNMJDyK/0MWJyZFb1HgUZa07fkm13mKgl2gO9vhi
5cLo/O9jlsBj3uWSOCL27Xbti3zjOdthL34ifhN3IsgJreWRY1lTVmo57RQKcQz1kWb6ZIeq4r9p
NzDl8xLCe7N7BkXJROLTqltGMsYgYoQCTa01nu38Ervc/muLgg+bl/TBeALSClyv/JJ7BuRtxkIf
iuFDaasp/lc4ECV7wpNwbVdcc2wUFM2e1HgNNcGsNApi6qNBUkbDewel4Rh566jTYzrp/zlGc/Rb
TQMeaHkQvJ82LLFzAQ+ple9ifVE4nOqwPbeXw/fhQx4beqjNBcLsxxB2fk9aGRj3LbsoyTPFt2PF
Sqt8w4IiYcod0fZLMSXrlS4UlwDIYXtbunuU4OgdmFA3GAT/tdUbOMZcxX9Uylk9+czlb9TPmI7s
jT0WPf9m2l1o7sZlBmbG2J2JxatZXSZnJuyWAH3zLY8WVaqmgHjE/QcQqhivC3WaakG5MxwU7T3y
27PMBnem493OK297tEwGkcrHYLPvJyLF/gxvN9G3QWrGxehXHR+yn/AA/nnwPhvlFgJN6x+19zgD
gr/tltkl8gf7du3z+jrSP2Z74fofXhclLesFLNPglPNIqAD96meKJmvVPV0Tweccxsu57P1rTcJz
kZC1inv4hPVbQdCP+/WavFDoGCf0FVNsm11BcIHoX6h2bsuAY/JBCp4JKXXlfyN6fxpAc5b6vOm3
a1X/Hpt8HEUbenlH/uX3Lu8uvrD9zlkRlkOvtYHb80RVXggy5QqCJ+9Cu722Qnc3sWNK6K/6rPrR
3BeaVZq1mIgJSCPiBe85j9ZOcks1osK72w0WsC0CYtomK2qiH9eP3BcDvp6/v6WUXxB4dXKoGp2I
vL4aOkHwmHHSWs7jwgk0V0X7QrgO/+v4+5XwBxTaqLeMmABsDUyD8oLdO+edI+kD04em4PtwFHI2
QWL0LHyBAgTRin5te6GptrC5c2jneaMSARCfjbaGLNURhpMy2PXo81GaIG7wEPkkVvUa87p42vBm
PXSzeNuCT199ei7WDjZHjpcJnLfSx/hFUKCvTw72HTKw1JBUxIzQc5DhxJAc9zbw8/hF5d54nKpr
y1qVWQIBoNRUYauPfp/DdikLxC+BKpED/vfCtyQZn6aL8/Hht/J0AsXs8VdouS+q/eGB7op0grT4
oerTPYJcX8vNbGfmkysKGqW8CsF0SiZJChT0w68MHZ31tKoJfCa/2w5Q82hTUowk9rpTPEXNO4Eb
wf+k9bY9RSNPi6jjmKfA+nT5dA3Y2X0rFruHk1QxQ7BTbaaZmyN/BmxsoUyA64aojkvH0FyDzB/d
Fp7lJf6mCJDI/FSJTec5iBOqzMRBY2mPlir4U5dtkoABEVL5hKxAMTMzi27QsvvIFLNaj7RegaA4
efKzJ9IXiCsO1pk0JxJPny6nJJZ5xp5OCV1OqSS3KcFIj9gvg8/pEEejcjUhXuDkJBkZ5C++OaLZ
psyuZhAIkcpPbudvbehiu4Ew9b9t6SSzCz3piCNk9vpdcunRD128sQ4WgEbqE9yvcWHK4bqz8Yz6
vKJjBSHG6i+PwyFW6e810W6aerl062SQFcTTp/qzskY7sQSl/fHUCRCG1r8wzJulpmnB14FNtSMH
cCT7ddfpkPIbv92GiIcSEThT/RCXD2SI/+pjtZeBB7VoesaF3bpFiGvWvhFjXpQQz444ajIGWbeZ
Zfzl9zC53HvhT2r3Vy9EytH8zqVm6HYypDE+QdCDuiP7rigZE1dSM+NQAezL/lyT8y1zlOvwRK49
haOp7t1q9FjLq4B1Bvh2ClcIPIHzYedaiaU8nMeei5UvrDOYuTgLeOEpxNNrcFoSZzJ5bXa98903
Y4lG+i9sGKekeTx0GCH9pxTWgbrawUB5yOuzzscYp/NEivHNLBZVG9clsK5q8kfa+WBu+gb2ORMl
YgYaXvQHvPW/dZ238YAhGWCNvTOR+MQqMrkXeS1FewrxJi3g6B1j+NAkf0og+y7Ch8Ehxsf9zYP/
lb8WAO0ZOnB1AHFz/YUmwCfLg7BSRj/TvXYfLgHmbyx38bjjze1osto611pp5xTEOFmQQ84qcnBY
PVMndzUqIBuJSRphUwqPkNza