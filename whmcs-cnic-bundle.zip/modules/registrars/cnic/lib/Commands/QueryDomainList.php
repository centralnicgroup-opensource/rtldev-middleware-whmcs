<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo58pWZW6JCl/OLRAoszohOZ9agEqZs669Uu8mF3twIM/EiTNMvGW1tTCYsh5ct6MY5sObBF
FkMuj01xGar57G6DzEDRJ7pR3DGr8HhCaSFhE0LsIgwlVaWjqN26o6olt10GvtYyizFHQXtSGuwt
2NhWhOI5LhmsiHJM1PQkJJDRcC3V5IqD8am0aHcGjFo0RKYuU6wtzBpMKkRO6lV5sX/kMmMoJi++
GMudcuC6QJU46PYV6+vI6f9IfCdSl1AHk16P1RvSKut9IebCxzBCMPaEOHDapbYFddLR/6f2UXb8
Q4WB4/GuXSuV4azECiu7vq2tn9ww8YIB0ZdhEBupxJdz5JFC1rNUHpdT/Pn21BVjwSR5Vu9QOhCV
/2RTIw5U2jSzlN+jFvUsM0RBricm+bKOsXI4WSbqrzrEoge9RN0aJzEdf+wjrP9LWoJFRgYadudx
rxOC9qTu70tK0hj+nLIT4N6eGBaP4oOCUpDh8qPxUzuzAODL06D3NmyigBvHZgTYuRH4zcP7OD0H
27Mgot4XoXj7zUclc1zfXuzUxBhovv9qYXHkAVlEso4UzmWQWxtVnBMKHPJSvwRfUOW4+lpynkn9
ZRAqvpxdmsEYUycdAxXYOXQpeyyJs+mzODjK86psFp1SMYJ/TUrCr6CaAhPNkEFQ+14Hbyr6nNvz
aQiwwPq8pS+Uzkvb50j+ipxs6UAYPMcmzKmAVV/DqHlWzS3/Kqx5GLB7EfWmWBYifMT0iB5RmA8i
x2izrKt95xVqwlUr1aEHlLwsSR4ZkkYov+3AGd6/KLUMuKM5FktiiLJqeC+bbeul8ggsGmCfrhHb
iBgMCR426Yeqvrt/rC+wJQdrvCb+KjBOsG0XRaMuUss4e31jDaV4ZOYFSjC+f5uhmdGEeILzdgol
H5Z3Q3CqCkqMMXsNsSbCW9SJtnpRBHKdzjdXkkAzAPndBkni+ehUGYyO/AyGN/uZG/6rq+O098OD
lFElBrJ2NCPn9YwN09Z5Khy9vdjQG7HRz22lkJsjna0o5WH4fR07N6dBt0gY1FJOjfuP7bHFbYW1
txjvw8Wu3u9c9ejU7DN0pzn3qD60ZuErU5p7o+FAQZHJk5IDMMEij9WHmSJzmPzuWaROr0diDiFQ
aX9BlxK/us/b34I9UaE8nWFB7KHYBiyHsrLN+GurByrhHcTD73qADLTyRnhQI6jmInVexNmG1rFU
u+b7ytJOlqJZs81KowHvqKyV/yxNzg6jKxL/PUqeTGAAJ22SFWmuiCafqpOLjRqv4HLokTMpyUN8
UFJ7243k20ottg8HsAUEAtSDwFzisDgMtkCSUbYtDHiesgxbOmKA/q0WRn92LsrGiVcY5x1cQ1aj
/T8raKAPEkBB1Vbo8/n7zbWMr0cypc0zCe7/2JhVAe8h6GgkiX3+Uh5VmyG8H9dTvS+puufzB+Y/
4suEnX8zYxtmVeyCn3zXhLB37DZtdF1OmXXZ1cLxX+0JlI/UEu+NueN2KPs/Hlk8/IAMHo2a/stt
xYPh2DV4OoYEFKXs7q6P3aIUZIvPnyI02JDXToXx6XDjrFAqKJRYLp8oyuvU4diwUJE7mStMCdh3
BtKhyOOiRkaFW2lcWuLgZkjdvtGoZ7tamnkwop2TQ4Tr+0I4fIYVp3C25rE42Gt4awPMJQzA4Q0u
Gwhrtl4/2QCDadV/aUt5DqP0lcT/T/k/YLq8iEVmxFxczyNi/vnuimz4oN1EetcwJCG6xB7tOO3D
sYEXfA0hEMXRr/jC5+qotJW15LMeJrQrKiOVwgHwqYBcMKo6k6yPG5UWh79eyU/xXvfpzgn1QN/A
j/YChwRKaxPMO0quL7z2ZPP7Y+GMWjYp2vS30bexdr+46DWny6vyT408vuSv6As4CQG4B+AbS0c9
ijB5DfJ1GVewuNFbEOBVfOMFXkoCfZ9QiVFCwQMd5gCzf33NgFH42FTppX/oIGVuws8iD/S5u3G5
JJwDP1aM4Qyjo1W++of4Abb/g/QPhZ8Q2CpVWY1kdBIc218U9+wbHl+F3g0hsZa/PyZT4JTJCrNU
kQIy7XT7hGg/x2u+E8t2Aq4knHWiFhF3djLnsDJBL67kmJbwWBKkMHvP/dPZWdYsXGqIveY7+SOt
T1y9G540B4ZXg6OJtvbJrY7xcL3or2OOnsg9s6jiaAc+CH4en3OM6BM+ApX1f2OnUmFgirw37w/U
GlYDJZxjEvtKXdbgwPyfo95rfe1xfv8vkRtchR5Uv6UDZrEvFUZdLmZ5pWazKOUjTk6UJ9jMk+vx
oaUPydtRgw0uxf8f802OFGDNxcZuV2BdM2Nt6NSm4f7kQ/shkW+WhGB7ck/iLEGpMnpQ0kFk5mDn
1za+fTKEdAHXU8DZ6Lg370esA5bwlwoHGegSIXQ/zNKVGBFVhiM3LbTUWol5LR64N9ZqZ0LqmFt4
dB5ZTD0vQMMrD1C1HD+j/dVSfHGBfuXQoqU5tGIWKeXWPResTV7CSASiukJD4X1c+qZ7PTvfCEsi
50tR1inEH9WoeT9a+iDbX80t2n2+d9Tu3HHKwfo+y66rdM0kgi0PMqoTMJ1b0usx775eVE+TOzY2
0xDSlJrrPhpl0arAq/cPEK6eN1KJNgM6DOFsBPDIrzSZd5t71MIadklr02jRicxpwRQQXwZrxDzJ
Avf7/qmG/VQEmw/keAkYsOzyLoita7sIf3PrKio2INbtfAT6lNWh+PBRuYPouLboE0n3jCXg/eym
Wrxi7knoeV/eqU7d+lQae/eOeRaZlxeqHkr20PS6XMpTS4WaFikHpTfM3RlC1Ljtj5ZCRIR67sY/
CaB9XADnixgp