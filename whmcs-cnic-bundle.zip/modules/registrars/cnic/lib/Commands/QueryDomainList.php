<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxaQCzMIoeSQQzUczZ1njLFvq+8CIDOLAxYuaoDdumAF/2EXZ5bVg1xVg7GvHSTr1VRdOOdj
Rfipk7k7ebyprQHIS/IZ9GFNvZGuW3a2I5WYqKjGgOFQ3vNcGwJ9EWS81DSqE6kbGWKlrvAU7eot
Wm6cSstCi3jO5Vxh56z0S2vIexgPUL0kQmQ0grTw6q3rJoyhNuF3PgVCN/S3ZyYhtrlMj7tP8Ezz
kdCWagV/IHU8jlnWo2PSHHfBfrBDYkRBrF983dZg08yfAPZoJlL6wQeCctHc2nE4YMhO1DTY/MOH
I8SaM922MV+O1gDtQw7O8PmClspHzysLXVHnAH+yBHXL38BZKrhFruTQohsjjItcbnzM8IcqZpYj
PiIEhtXo2whUAemKhlEvbzw0RuIw6TnPfpY8osCr/peYTiI4+dMcM1pjW4ZTCO7tfwXwcH5UXvRu
b/WYNY4n8+w/JJvhljVKbz2A0XitG7/qnCDp9qlJnFEmRDwnpyQhOnVXAf8FLills1Q9U90TyL85
paYJI+RhoRj1dMBVBEMvL7HLnwr8wIKe5zFsoVB3Kr82cK/X9rhvZjFvWAy5Ea4ka/g/Wh3WRXkP
qrRHzTnrUCqGShqkQTu+z//cR8hmyPiO1UrG/QuPbaBTa3qqWcW8UeMnbcFiAezWt6801TO9CTTX
aGvyCrCwhhj2WMLzmRVb82SEw5cwbjsT7licMDtnYvsfVSfGgAz8JYVH5+L20MfDpZkTsEViaTvd
o3qRsZDnLaD58Z8aRDUSk2DNbYSdp+TeIjKOic2783Bs8vmw2RrCq1a0OMLKn4cMJPnYL/eQBdtg
R/osAU1DBEQJWy7MsMQLAuJS7EBfZl2MN6d1VfArgzVZeCJAy2aUXq8wORTmsW5a8cN56WzVxpw8
aZD21jP7W6KJybIdiblG3KzQAYSUYIwXBTy0MkDXf3eMALER7qC5qQXIO5NcnfS7napXxVnAyrGk
9ugTp9bMHqbgHHsFOcJMMWAKQrsKLpkm20tsbBgCMRWS6+QeR1u9guNl0k58VHQXWJHJtaY5hRk+
ZlnRTtchOZu7fuToDTTCbkbi+pWQ9fVoddROcTBqLEVOa8AB4fK7aefR/Q2jJLrWabbho6Lu75dV
/crPxse4OcbFGt26vq3MU9xzD2VSdzqHKFhMDDNuyudFeD8UrWJYwhJv9cTg3RB9BRmJGYQ8v50R
S7StN1m1rUMvign/e4asZKbzHbXeV0eoLJWbDbAbWySF+a5eWUbUk4vnIGilXJigePA32T0ZyExy
wMmrjWRthRhjqQKu7Hxn2f24I52fxkymSKb5uf+fUyHpLVF2pgJLsJzR/vUbiR881xjF80Z27s8k
68AO56mo2x2a0VAgKR0SOmlbFa9fu1KehqmFbsGKb8daEnnkPqdp7A8emfKNxCcvTO+71GngYOeh
6EP/nRPubOlbdOMhvoChCjwfksAEGCFd7k6G/K5Yp9IHQZzKNSjH4Yj6Ne7//I5RxyShwYlYd2B6
BLMHPn04cjHvIFHOoaTMV7Z85tvNTqK17CSJ5JkeUCLyyatOt+dVLo6PghQdg6lwIt1XcP9M/bmc
tyLsyjiL/cvVQTufPxvSEnEN+/aqZklHMglRg2AGV92VSGcdCi8el8L11QVVMfIJVhxQpgzyUEdL
sNxFz4X1ZL24unA0/s//5zuuJPkRORKhjqzAHLp4wnMCcvVeoMo/1p7drBHMuZqW9AfsBO2Xu4qw
rZsVTxda6egecBP5rYiK2AeDZxcTGV40cV51YSBCApI3OoZ24VVMgpWkWSUdUHyp2TXff4AqqozB
J8RA4UyKYhC63rI2ap8UCwwOS0qcGC/nBWIbjYYbOhj4YNT7VMQ57dPd+za3FwJECYhg7Y4K4QSE
SQqpIyFUlgQ1qVKVvb4wUD0Lk1pu4EDM61aDuFHLbfnAO/B89uHpwDCusbJZCoaks1Vgf6oxLLh2
wgoTNbDvzEO+uc/j9Th/xCsTNTi6VlixpT9vVZWfFOLojBbYE5T20LclUnDSKJ3TnDjg1aos816v
RwwmK3tYcsTq9x8Ur+IAgorvirEsI/fTMFFS7/ErN0OQ2Qcr653EcJ7kQiAcb1I0W9JXJCCrG6dC
Mg+GNRxZ1Ecb4Ukz1M5yM4fImoXfQ5Lel/IQC5gzwgCk8I1oo8XEV2NCy8lw4zLHyb7mDkD0GhsF
W32cDAq3MyGVlPKhA5TbuSKp51D0PCzCCdn9EuLjsrwZ5m338ees4QRca6o2+fL1BknU3iwaADU7
wcKLm+rpKEKlSbLvubyPZQq7PyVFRq2AOtfMSup02Dwei+VjT+HI+xyWlFjuUe/Pq0y2R6QUelzB
1/saGOKS3FGT0VslJx3TJasdkwSRND9FsjQet7P6mRhyyCdvMx4Xall6dtYBD1BfuCnlY31u1nhW
/4CphABk7ZTKIqCueE7LPcVdRtwULvzyYqLc2Xuh+zURcY3OLPl1amm3s0N905sDwOsYV/ZoZQ81
cyqGeXyvuTKDAp7U5T8ZuZHRWj+zmkCFAmIkP6QLyGWzzosoC5p0ZJDYZgZtrI7PxMeOeIXU5a82
VXl+kf/UZj806cgKlGj3MUIa+dvhm2vySEcDVQlKrqdL0p9gy4BwTWU/mXEjIXPmtnly2aZwI0e1
Qb8nDWRQoV8ThDz8WfoK4eXEFfrTdVy0VjQZHBv193wHx4MxuEhfGiPz0rmq21IPHyE+f2LLNvQM
dJc+qrxfzAoZfBrtDFaHU5wMvxnrlym2v/W6H5p3hrd9t7J/CjUbq36nYMHx5zpjK/C3Kfddr0Qh
qaermxvxBUXGvx5IyrSq1j3NWU2pPyul9h5OkADL