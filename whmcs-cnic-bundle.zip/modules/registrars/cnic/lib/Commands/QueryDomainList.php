<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+upvsKcaDjAF/voHeBrTgsF4gZD0/6FIxEu/uYzoRst47+thOSQjlGt22n75/h8PpzxJFEx
fsT3gzen1WL0Igjiksstsno7YXYg8YR2J7Wj7J99B/cQSq1WSwFKf3W2/m4DnGzu7Lho+QjeHZyu
28qORqaOP1O5FsgbjXFcJXn5GC1sw4+2NsZGNm63uvXeV4IE9Iz9Y31vb+v/AJb5gwsJllRjzpEv
29fUjpKB2IfC6doYL9mMKS2KYC6L8Lulv5yniVziFXhP3NoA6aoR1ZAhpOTVJVDzUpyZqcUW8WwI
tyTPuZ5SpJTdtbN8RX9Kb2vQrI2zX5dp6MF2iLVryRke/Rau5RGM1hjTEi2QIyE7cTrXwVQJPh1t
FnIJU+xfwLBMMZzdsbQNAfCIPNxHWei/7L1jnm4KADZ5n2nLkxFqhh2q6oVdit+p9SQk275RiOSg
bOjDPE6waBk0GvWHPEM2EWRcvclpeIaWq9WPgRU4QOmJoBMrDCiaerMb5j1v1U241TGGMhsL78hW
nLyMY++81Y3eucE0/PPwId0uMJ5M6XCgujgXgLcR6IvaKqgiP5bXN2UtiO22U5ViIpNfzAy9Eph8
mQUPsNOSiQoPZwt4hiaNnSekDnj1UqSszCCsVRouHORfNYwvZ6ZvjwClVWE25Y51o3juvpL/GuVJ
ApVpiAGSJbllgeRIQCyBHFl4+sHme8eUsFwi72x/cmmWjyLGWTwDm4VsytIiqpM0GlOf5HpY1F6U
4wj/Tv3K08WkKq5b1Axw8vYevETYttGfD79raAPXNz+HyF1vFH0Qrv3py+gWmTzsNhcVK5UIIXCr
ZkRYlc8tUOGRTB9ztdEWkb+kGGsEMA1jexRFjFm7XnNvY1X1WhueJ9T3K+lxIMXw7BYEvXui1hBn
dXSh1ImbVcRrkW0TK89PReTLeuySA5hoSPa6sGaH91xtUBvGhA7mDL+UXWKOhqTgsqGUsaK271lg
T9zn8pBM/PiCljGjT+BskZ2PSQ80amN9j9OMVVi7UniRZzPcSranRbf/Wy0538dM77ZC/g7Cme6/
KXxjGFpUWkffGv9tp3efwf9U86KISqgO3gVGMymUsEnXwLPDDTtaZflEsXHk7QrN8/KSkA0tUbuM
PoXqUxykYFK6soQm5a/0b17bOEH491zFDikW4PNXXoPmKWLsYNUtnHwRhkleVVxnRZ78ptENJp/R
kzeVGsuC9Vh9XCu1N/TBUnfNQSBP/sHQpRAofQ+0vdOMYljK1kLPy9L0Sa0AUnniOd/MPxdPlfh4
ibS2XeJNaD82v9Pfbtva7CEVmSowjmOuh+tUSEkAtyV4nnC99DVDwy48IQ0uNnT8vW53K4o8uqkS
4AquQq5roqOwBcjOpj0i/gKFK647YELKD/Q2CJDciKnvwNB1LDPLPwqouHMSfUjNSb5zXm1PswD8
IfEiJJXlO687PhcQY6WTJCugR5wrXONL6pdic7C1cIAphpSI2d2mhR9JhQPXubhobNOY4HTNTuAw
LLuSLgqsWgfkrEDWZ/PWZ+aGClJR7fqDXpdIQ7s9nbLM/TCJeBUO3W90xrY6sjLjBUN9E5cTIiJY
1rkCM3kTyqlYiwvspB2pjme7m27GiX0Kk35qEuiQMtN2If9nKAvb9+o3EbIsG+ael3CQIWanrdia
Qym0ffFV6AyQCXVdgO4dC0MWidczx1//Yksvu1oP+DeJ94QYXXPBQuUwBIzMldPomjUIlLyWh2sx
B07m811r0056RWzTkVfXZfJX1RdtqIh5nNfCrxZXmyM2hMOfJxeV76CwUpRosIpDdA/wzFE5elfv
hZG3uxW32ebA7wxdogHJAPbRzvzMYpK3OHG5Y1mapRA716RVN+upXTvZMW1iJdKwWLKH8PTL0gy6
VKzBGoY7T6GpGjsyJd3g6SZirnPmH7+zmyzisJab3JjiG+XN4ZlVNwUj/le79w5g0HDB8pZPPgS3
guYIqcS1vnIao7MwpwnbASnP3QCM8DcXZOTY6oYFXvfKRKqfOB9mJJJI3fpxG3UNbnjxS6xk/Xpw
b5RquitXi5tMeTZLlL3HxNT66Ie7LHBphDmxxwPWeqTmVtJez517ihVQXRoJyfIfv/5y/B7/KnEn
ayP+uidz9Y9QC+6DXN3/0TWLWeR2oM0LjdS0klfy5VrdE0ZxIiiQtfTgxKo/cAjNpv0iPP2l1NNk
Uvd3ySP02uqxY8iYXli+K8oJvcT2Er4o4leh7vIzvIc0fdR160Qmxtq6d6xEXVXIjhLK2n8TiwLI
/vuEPE4pPYYDQaw9THBgtayFrlA/5ZUSYa/nlmsl+3H78p3WtcQ17vd/WAJ49W3ef5jVTqNW07U/
7sTGM/gfAVBxUGEfFqpjZU7GH9f3i00FtHe7XKdEnJypAWxtxIzzL/3DgaW49Ty58gwY3qFUjrHw
nfqNyYIdHZbu7s9oxdqpvJbTxt2+VwgRsq/V2j5Nmxsfq+rtgrxY6pciyLOAauejYYCP4kMOzydZ
6ndJyt/NSC151ZgGobEzvvfSxatzmnFwsUmb1yBDG/Pb9fexjKPlMnf7fa2hYmQ7C1fvWAZ1UQZR
VFqc8RKvruMbVgcxRODM8XBCTbeQeBAPrNexPkX5CrHRZqSh07Q55cchdwaB3j9grn0zMdtEWYto
wL2GcPAE8ctEdYR0OtxkckZHqAOOSlKA+jOGrJIdK1iY8aMZzxZRj4l/FMTTa9JuofBAcxo5InHy
pbf76WYZ/UAtAydZkmTAqNOELTjFNfuzMQ0OWADdLPODlR+wwURt3IpAueK5Glh99PwLMF3rP2OT
M7A4oFxEwSDh/GJHH1lOAH6j2QbONW==