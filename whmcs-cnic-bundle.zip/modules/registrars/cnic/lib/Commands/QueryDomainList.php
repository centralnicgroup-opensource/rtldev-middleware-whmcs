<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+234bHGGEURBKw7T+lVI+NA7NiM64ik9RwuHYzqfN5/DGvpnUdy5q0U6I57BxgVch+W/617
2dhZYi6fmU/nF/W23R/FbKBF23gHgSnr+CPDczf49lbStMRwYIdbg4ata8V9x8IYqTma4zK0v2l2
zD3aHT0BqhrtdqoJIeprWHI11rz+UHgTovSvTLEuC2/QfTS85O37UsdGnVFkWaSxT3x8PXjfAJEo
n+p/kVFb7iz4eDXJ12iB8Lneep3PLSJGzfhaxIqRXP/lhvZxOR6zLnCA7dnhufnX4suAELkQ2qXX
lWSetZ6Nz9yM5iFtGCE/90Z00sx3+0K20ZMnQrEmMAuzM9SM7sVVwOaQ++nSl7tmKzI/H4voXzLU
IUJv5EEV8qN0Wc/+ja/SlF6ojlnOKC6NQKHoUPeMoM78Z3AKRTbdz4lG3hMFdB8aoF32pKxwbTm5
zIcWa8kSrx2bkYm69liWpTUHAYFwv7QlqNxxHaXohEHiVhgck4Tk1mm2U8KYe7VlAYV/qGAoyScI
98eQgvVOvUH+kbrQMrEqTRaKKf0NL3r1mxj/rT3kVs6tCMQMy/mvcigIr/czApz8BCWD+iT0reY2
2I3Y/+BjP40D+sON1ONpEtBMJV1nlM4aHKhtoTkJjcfrG5OCJImfSnvMqQ2W8T4jblaej0n7dU5M
zp/XAIK+JOhuVUa8ZCIfHCkgmfDS6mPZeSUugxECsnzMLWOKBHeXcpgWO1G4XV2yc8ZuJsb3CYrF
lcZZpFbIb+VhoK1CcDniFRcsrmDuXsJc8UA41+yBJERc4mythS5FjgByclIGzqG5d2z3gCCg5HcE
foGtWu4HDUJgr9RKL6Fbg5uUJt07GZHyRZzriizf/iSvrQEFdpe23YWQfDAWXFxwFz+/cYhS3PQj
4t3XK8ZLKpsU0zlt3EdILld/+Hz4Kws4o8eAU1mIyFVuZmzQhVxFY0w01LNuddRDLq0hTOlGo5Ve
qvuO93xjMLFnlzp3OWLt62CtP88xJFdTxL4OQs+y6t5PwmmOHWuI/c12yIDP3OIDyTeIC/BbItRO
VArBDltpdqt1FkNKp03+jNddLADGU5bk1SAN02cQ6iamc3/wZ2kZFWUUDeSxN9JL2LWM0L4sdp5b
smMKppYMbqZZoHQF+xIL8LIwmeUrCg3Z47D9QDtbvlbwm1UbaStE9lOc5eiqT5YkGTVwcNPzgi6M
En0mYpYD93lWNZJ5nSFYdlQ6nA3DXcsnd/ydXZ32uG2oc04JyUOK6Ug4ZFUf6NP51kvX9g+CdOzf
a5vxm0uKHbnMzQTqrhjAigITamVumReY/HiTcFjUFJcSCPTAMnXFobE+I3Hx/qBne8qoekhbTNoq
Bjq9YX00XyhCU+CGBGK1YK5vVL/d6hnHmwtrK6zvWN74mde4OGasa8ZhH1/wDgfXEQvZoLxIloXb
/CRqIXOx9hjPGTvyzSXbxmnHXxMh0TB4nijOMr9PDK9Wn0revr0UAl/AQHbfLdh64FCRCUqgfcI5
5n90Kj6tXiSDP6BOdP5/hPvZvzK+CK8d3ICNyva5uLBZBQM24Tfy14JjVYmkjho8TAYCAZEEK5Xu
4E2Bnmc8xP8T7y/2OBYb+W8AVwVLkoCC3Tkg2URqd/S59DkH3Y4RAP295rXban5sT2JurOOOvkWt
0zDe/qQUU7RcUJGH5jLuDWd/tFoBuBRLCj7P8ZiqRK6DCSa9qf4w2KaWEgc7r51LfvQaJgqw8DPL
gf3EhYopS38OyFndNQjcI1X3FsD2cO2OFzhLECGCPqIXIPINt2gWbUcYRx32pVdz9fT57YOJb8J8
TsWdmAvJ/bGnfYvK/DA+amGS9wo1cTZbCBF080TIi4dz1OCSe/T3xjuzHDgSypbsdXSqPlGPxh4E
a3hCkidq68MymsWJzhjTP9444XBy6pqAdIsHRfCzlI6pJB8jp2dGMQJtbz/X3onR0NjIlzTgVApb
w8LazSO83bpujmebtE5ewbxtzTJVR6DCEstMWPjx1FcfVBWUBzO1IzC8jay07A4eAaLIwUVGlE/g
pfaOfklSJN54cfEwRMxDpxn4vsFS12Uy1fhYCGO4GOBkaWIhuYr0/FEmxYfEx29tb4dVGavabed2
rdmumepiNGDQFHfRnJ3pCTG+sGo+9jxFzPvtl8vTtAO/jFAGb93Jh5XZyPRPndBvW2z3O1JveCg4
L5vjmoMXVLYI7GRaSfaiMzxo+kUD0qp8dykHI9pNshAQ/lBJxPoX55t5lOm24o3pTnW6zpDTZKJN
Bv5MRYiUrSRjH0E3jRzzyOLyHFAzMRSTmEYZMo7DszzdWtdXwkraCVwlcFeDlDiCG2iJ+h4cglSn
DUZ06G6T/jU3tvWUOfZATGegMnCp/qySxgoyaWOSwh0lDCR9nUHxOUnAPpsLXkzQf7aKRH83/YRZ
CPcS7157cGkcxPgdeRHxWle+JtqJXk/HUrKBpc9f+pbupRQsDuS9TVXVySF2iDjT2jDcsMtWeNr/
3c+YalXLOHFWtGCEhSJvcnO7yhK+b1hFyvb1V1tuvGzTYm5pNDsSoyR9vGfDXhPuwhyX3zGLSvDk
b912HkOH0t60TIl+M5Zj3WjZ8QQwSPfyfE90pXZ4jxr75oJKbKY+QnPIr7fONN6viMbyrsGY/QQV
z9KcrPBwBlq7vpU5i93T6s9jtvZ8srOMShY+YAZN30fmVg9c0esxsLJJuyQJ/f+jLWDKcQGfNrjp
VA0K1IT1sgztLGRtjrnR7ghqxEVs2B7J5tMGik0oHEsFU45KhilWigNRlmw1fhK2pxpVvmZ/Osad
mtSEOdeg2lv3fhaFgDR3ihqUIjzKeYB1++u=