<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoA6tWFWHoCq/KjB86qNmF4FXcbffTKlyfUuGDQMC8tMZ7pca3xvEQ9XsD6zsOdW+AwLnAKI
2TAL04orrCKurDnrFpGgtrp+x6E9sKkIf1y+4F8F+8Ykp4BL50B1P+aAKbRcjW4fSE2zHkgrBAee
jlEwoyOlg+8QJLCCY05+pff2360/ajqTS7pT6L1drZMfjwGi3OtNr+uUbWoeVuwgJLKnUViTMFEM
kTa7WDs8k/z71E4ewx5ZJ7bvsp0iQkpmvI4b38PGOQjJKu8SAFAUjXXANVXf6wJLJJjLIThs71Wt
iISk/nxsWRrdjdbjBWU29Bv755qfXbrs6T+j2+JSjhy9iK875EdgAStRLDifWqzKzbmsP3yjvRe+
URANUTgyf3NUlRFv6b9gInttW8EhHSfmc+k7Q/ae9zWYVXEU7GaeVKBR981O8w/yLVD/cxntBuyX
VDI4srL3TaQCoimleXhmHEiBXqM57/e8+kxIffOxR08bxpueXYMxZb3/nWXA3AqB9z1X8sLRBisE
itjklO0o3KnXv0n3eRfRpP1vsAlvDnxRVwMOKPSnTkbOM8VlNtUKyTUWILwousYuNFFmynXZKnVb
XpJNdhRq9G1CL+ScO8gHQAW8DBQztFObp9w5jHtflLUZ/JVXNKrdRnVeIuVTwentBZx2iBHHrl5k
tzP7L5h0WgYJxvSi63+pH5RjRwto0BxGLsDnRJ/hGbminb5M9YnLGowrowgjabD+Yc4AHWTkMN06
/iNnON1SQ4UEyHsOqHNDCfr4dk2cYke++KjnmoeLqYDFo7mm0xCpidyvYHrLBGMzzi8YiFDUacCt
4Yf2oBONMzYaPYC+2tX9yBEJDWlX2H9RW9TMELjqZlJeCO+C/C/tmB/lr5MIAKOKS4FKNMecDQ/M
HbRkg89mvTIHf6k94mF3HFjd/v1Ieht/v1C6aKicVaHCJcg7ftWbcC+P8U08j2fAGJuUV7ZD7AS0
naCihwmPR7t21cPP/FVe1dNPZL76Qi3zm1uKrnHbgKRM7Apy0Jw4QCtQyHm8M+a8tinoZrYa5qlJ
NoPab/JvDz2KUEfqrGRSeisq5QkLMBsh+EP5O15oKe8jO/L84f6dqbV7uDB9G0XjkSxW1ZhzIHVe
hXtRAIn7mKupymq1By5IDX+65OmoB87lnzpzc306+t5LYg/AcFYw76nhd7ahMCoXBrCMka1G25Ou
4XG+hflqVXw2jxDDxi60YisMUVI5jRQXHPbqoNC1TJM1KkUUK1zTVYxKhqcUWogFtjUypSwe+57x
ynIm5YMySO2RK0dBhvZhGIOekoJ3pOyo/CfI6YZcpjAQMbLQg6Dt3vh6kdLeSFoSs7TrJ1J1r9VL
Vr8+FpUyxhdEyLbchsIaG8v/y2Go1u6N6ztBGIpFX3s17aU8T8EOE+KdpD18iVX26pLet03WuLL9
wp3kwscnBDhrER6bf+aaLbhxKOstudc5pG7bdojRd4UcpymYA6MLLszVj7Ay5VT4yOpBp0iCLUks
qZfNCXZgCA2h/jlftNvDIoumPD1MxUAr4GC+DDeYQTRvD8FWdsQuXD+Yr+WkPfCh3/+zxaVRmjZp
BR/f9Akj8y7liuG5Fauz+PeZ/7YJD13PgZNnT88uDcNjKBiG9Ge4nrVXaDQnWM0xolKxexL31ogO
WH7obmsqfAz7KRFhV3U8QXZ/rDq6RZhFPUmOPvOEACn1zeMeeL2sY8tFdSpjxRKeCLuu3pe+QrPE
8+xf/o8O+NwLt5KJEx7MyVyOi23uSNK1hUNajJR2gz9bkyCU5Q4poEjwvlcu90+tu/ZgM3fNUe9u
z6EeD96++QPd9JHK/YQtGqnOiFd98i1LoJO5hLyiJcx38nJzpkg9Xa5IYfkJ8TKDtiD1Pl7Scq9D
Q0JwZRxpscUHaggL9Ub/AZSLDcHWFNfYJ6S6ekL5bnbLOV/ktiun6I+cvaLF4C5HriUPp5U4iuje
v7oUB77CKVk+joAQVOZTuCXy5FvZ3OjvOfwMXV4LQf+gR1Qk3GR0O5gRbAI0DCQqRPFmbaxmoUyk
6Ix/hJ3kEZfovtni0X1N8t4WbEZ628CEIATalRHR/c6lUoFAXFZTqocQcS36JHSbbpWF98dWxgen
xtCH0/OKVSc3CJtkmmkIVuJY7bEEjnruneq92GUZ6LYOylGIUmMFkCEgVjvtvsk7ygEuXEgMTcg7
IKDXZDHI3Ob3yyUyMKCvdZyGYtclQwTzU3aC+FJMa0Qqfp9pJDJ5sVdJU8Bmo345snvogSKzkAH4
h0vYXFe7YiNe89HLZHZKr0kK9d8uGnB+txh4u6FqmAAskLEnXSW1t7A08yehocP7XZ3+DQeX2V1W
Hmup6OAV3tyJ48YHB/4zYi7Ak8LqweQ5//5BVTuZLhRHgM2jngqLHZdnpE0RPuQnCa77y+ToV8rx
cC9axgiCCdhbkEp3PozbBCPf5vDXNcpIxMBq7E0PVxUf5l20Uc+OSK6IUpzYtqw72PhjcVDWRKVA
ue1YzTjQYC3PGedV2UFXwB+sfchOXVBVtbJJMP2i8nAfHrEcj0emWRAWiQ/fmuVYj2gcqdqHUv51
16pkuVexI0YNPYWQJ/3jz2vQYaSueYsiqjk7DP4ir77MaKAdbEBLdZNKDpyYGs1Z9FzoyMmIPZBG
aUjJLmOqO9oSdLEbqcw2THo9wEv/jQWSLXBw5fH9J1HBamiTpoUIqgKcTduEQ0/YeHJNrGC/yIBA
rCEJqc128RFa6hrWYgm16/tZTMhDe5SETgbkSm1bmw9q7aaFuqaceARbQ3aRWjCc9cH6gzDjtG7J
5S58hT+rSPa=