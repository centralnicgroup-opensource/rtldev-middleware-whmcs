<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+9DuISc4je8Fu1q10Ev+GLktqUab0juyeAu1PXxgA826Rg3LJ1jreza7YCC4tkOLwNC94pB
Jwe9GUIEWS7FFR7tvZ/8cfmwGXKr9UdFZarJ0p1nn+sgLVAOFgxn+QPBo0hadCmE5n5FlEUhLdBX
swt/QlcwctWFKFBgKyZpJcOm+PFUbL6hEDVbprjfLqRbekKGEobgqqXagvvkx9rGOmlpo8MqUVvi
6DB0Atbmd78VZyc+YvpTWUjPPfkBb4LF84h5nj+7fmxavcCZy2lxBYlnlZTiDvoP8galWNqx5O/2
3oTkDPfc37gTaxhdBzcWixa4X/qYWLqq+rXw6LEvmLZ4+sfogJYv2tU94lrG0DOnCfNlMjaprVZm
ZZGioTdPCs1qiq65/pv9KqMXvSlgdhsHG8P3wFSaDsvRXsdHNgVXsqorNOMYvIFrwItvJUeYdbh0
nfkctKg8xZ/qswuqAvvbMkavQwVGfpPO6cokBMaD4R8HWcbESL/P0aXkqDimuu02bIfd2dgf/6ne
aR8LQnNvpReXkfuVKKbkJe+3Kx+HuwySfOVrra7is7xBGy4vC6DoboMyA2Pmz3xPYO2J6GgeQ6jj
MYMW4qbJr8il31ot/VM2CS/u6iv97GIJDmnbc9CFfPfxpsEtuGh6jxjskBmbDoTNPTbJgbbIyT9u
j5AXWD3bWuIY8MdJTTVx6XMCjHWsRG20QqGTiLd9cZ1VmeoNbzxNd9L4/N0COlUU17tU9F+3mr3/
25ksFshmwfaNUdWSinLs4huDamGkcxpwvFloWLOcHVrTjiWs4Ho9kqv6soUbLgjRQLZ+efRkk+YR
19ylt1ER7j72BS5m8/VapLvJIh03i38Uo6YTbeh77y5964n7hxbx8Z4cmCltteFkWvXAHxua9fze
zB05D79cmxVztodSKgW7C7dRMWoIf7vW5bBwRd8iNKALcgga3qa++yd3q+SET3/NY3kGekfdsAsj
ZTYiCtX+NtND2WFo2GcAHnhxFHfNXtfvwvwoppHHbTWkMzN4CV+fqOsQ/XcRsWI4wEB9Gs0D32XE
DgdsM11hErm9AKFWGdqa2L+fO9xV0wFqpyB17i4gfJt8Dg/OFOL9+8wCVLVErBpR9HXPt29GLuym
c8VKWDUl8sLlLHFa2C/eQ6q/jqsSqK5Aw7GvIW8ZJ6UHIwrD/W5p9sgAwq0+Nkc/NqjLgqTm468+
yJglceZChNuMEwEK36xtul3MFpE2TEFFJ84xKSY3G3fm06/yQ+TCzxDvQl7+BoIkEwCj09qUvHI9
yQuKPGcHYZgJIjXwVan8fXfrINVRLCyEUNIXBYF3l8M1H1PhhHVUQQf4/wigXKrs848NIkznPZcC
zIBJKu8cRYna0npPtHdpuz2zjrbvy2VHGhe16rpwtxETA60uHVp8UcP4wkZy8l0leMmORUM447EV
PWaHq2DNmR3AmlXWmFCc36jCrqAR4CbF/ey6Y90ekmm/8Ffzb2a7qBKrMqpNMox6IGKR1ZgpPV+f
pz5jKoR/i39hccU3YA4cP/wO/QVfAl9KTr2NiIqCfY3xP1FYSJPbW2JLOGyKIsMOT7Uw+qZIxyHe
YaJe6R7/qyFIerUXCO3Lu3MICyeGmdjcDdhB6chh5oCjXmB5WbqZdh6CgamvHQxp2nZQVZI6thsy
hiLNPoR5mj2ZgzVw7sZ/UFBy3CU7u9+sx54X2+pJwp6nSmKAIZBg5f9QsYxYhQAw9/FusneW+Io+
CGfKNlEFR9eXI+Nu/5Haz2++wlcVooRYd5AHKbkdHGsro2hvuMx2Uelt3Orzx6EUv6hJGeDNNTl5
4Z15Q1soWnYBZDj19bfVcZvOKAN0Y+rTCL+4SvkOpN6bxCNjChmDUb9TUkiTpcCbbbeFVAo0qnpM
IhmkcDN4Z37lQ8YMX/0SFqjm6mM4zKMy171a9EwljlZG1nXXiyqGp9XOfsp02Ae8oWzMhQhfyBdM
j7POu7jhbpfzHX7MqRwPS0BaRXVUaWWB5k58X7IFCBH5C99vabh9JYJh9m5UX+Tqp4WUrUBj9g/d
WZ3jUbKCy2FmK66VmzPUXB8ZnAFAQSqrU77dXFI4LPO+hs8p1t7kRu47dCFVSUx45wFg9IF1itkZ
6YVcgQo1iF/l0Zl//m7f9vtHeko88jn1Up6sjR1NaBpZ4p1fHPBRzFKHwt/KeR50D25wuDhEdkKh
mR+YIbEFWv2fIQicjH+3ej4+zSkTBtYL05HbgN/kSWB9dyeQbz3eLSAleBlW8UAvlOemzdoQ7TZR
3No/Y+43TWXT6L/jtUPglSaOSL31jQgGm9HTTJ1yV51nKcSJjCmM96buGYfYsdwW0ZKPbpLUJf70
5vzdSh2wWG4FvCJKQ9RHRDZkmynmX3CHSGwxxihRBCpfdfUGEEsXkV9TaKAKwZra6VsD5NtQXTTl
wL/FUCUkFUsFazk7/dAOISZIseg2UtUpoPWt2naTc6S/UW+UcImUU3Csnw3qplyk2i5e56oUK2jZ
LNVB2MSl/bu5ofPvAWrh2m7hbIh2X8uimhelS/hfeJbYNXDOIG/KSv2WINe/1TVp4Db8DF386kkZ
MdWiNLbkwsFW0aTX/VBwKW2bVc+GwlrazyPH8/5VsAxb4F85ZKXI/K/6UN1qjhlMQlbrs28e0Hib
XAGkYEssZbuMp0V2Z/S/Soq6rqcQd8gExQ96ieFyx7MZ+8qwURj9dGCtd/Sz3sQfQlcmi3H1saT3
wDX3vzH+ETvKJvnw8INPDkYD5zwk5P08vapuYjczuIHgLtmHfVFZsPAkStsBPDQHBgXYiw8JyYH3
yKldgyYbqRSlq0==