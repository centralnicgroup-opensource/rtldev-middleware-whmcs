<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs9a8GkavPaiiQcqA5wDHScAuDBsTSE8cRwuCFX9JyvIygauwrrQWS8ZHswKflJsWEUhAW5o
MvlPOFUeXLShKmFKg10PP69vRS29kxx45CgUz/pXxEuqo+1Grw7iOqmKXyNQjIyAuUl7p9Kkzhpe
B1xA6/RpfD6rsenu6iPb9Vq1TfhYabQ/BZlH/xs67MdEJIDK+jC40DU6R2w6AJa5sH1f8Jrn7EoQ
ZiRou2yMFOZoN227SBjc1cbZu02lVU27BVokKFHTFJwo43LofB0Qo/2MmnnlEV9U7VsiNnL8weFz
j4Xi/xGt2dzcouHH0WIZsvCd+UMCFczbTX1ntct6MZjgySE0i2D6Tcg3IU8JP00hr9gZp2wA9P20
EowfUORthFvingRtMTgcwQ4cvWZiSmaZmBows0brvUiBRAlnjVZZol7znGiTas99HVyPZtaQVJ96
amxzjixcK2eVffyl0hsIIgDhAaCG0lIC6w8kcOYJk7MJjm/5Ac7J8n0j16ACxdD85zWzhcX/QC14
CDmaLw0Ceos2jLsfJ3Cba6CaLYsxUWTRdhgV1DPBfk9ZqO07DqPKcM+AsIaDMm75IiqWr+ETY/gA
T6b33FJczXXM1q1bCb0KpnSV8Kvac3C+qPSYIPt3NJ4zez1GZ5SF8E97IZ65SSHWKkh+BG3FXAaj
4PvXxQKjACpFZrtNwezfKz0kZBfJQgc5695U76oG3TzPhHP9dv4OGsSrhkLpKVfntM3jUnb4DfCO
wtl+9owkKiPQyJ+WvZ9cwCqZ9/UQOnX15esDSBLi6VN9iT/g8sOBDaq0TFBYuLC5Hhfej1QZ1RgS
9ILmnP9A+PU+n15PSt0MdrIU8VeZPX9rSvMAL8YkWtq3MN5u/Ft5aqKkpihkCfxABa3VxhIeNulx
t82uNDyQ46CtckuZZLtmCqYFDB2OjXNR6Ihr7QuNlH8HIIYwWdVccDvB3RqPf6zevvwkrlwA4Opo
mWGQSYf89lWJ4qxURvisAvRUUVBXPpRAFOPi6yXsk2V/nl9T6XB5Lc1BkOH99Zlts6oE0EFEsYPL
jWTNUzws/jHKNIGW1UppuPJEXGzl6yLIKz93FpcCHI6JNZYm5U0wChl6/FqjeV3k/nT5uIUBxtA5
EC+PcTxOETh2e4/l2rALkG1EREJ8jEDHPu184LxGkqevpnPswWWPt0NrXXLvHSXzcCoGDhe8lzkb
g2VxWjgxn+k7QAqTD77SE20PjTo8ERt6Hx5hQM4DxWwBfd5HU2UcjqcZ4G4o35gAIwrK2smfMFQ8
esqDElBdZ1JuSVN84Z4zT1zlgkewwnbzIwDZVuBN2ZBGAx8LQ5/EmqeR2nJRf3+rfKiAMrQrcmix
WzhB1c/6RK7hlyCauBfvHBVC9CRx0rv8HpVpxiKBuP1/bgTV6rLggVbkUZlaxpNrM5FQ2snWasbw
J7CzsqgFmaqm4bm5SWccKJ0thUg3/SjFtl0YK+aT10Gjc6dXa8qWXnFVdvFrFVbu9e257HrrQuQA
Yckhywz7ibjkbs6fjvXV6a9lcvuZRpsh8E7irH4qa2mzzm3a6AmLAO2zYN3IjBvmD/WwBKsk0VZt
xq7xI0yBGYpUel7FlcncBWL+r25bQifJMyRkeGozX5lV9aEvI6Wt7ryIbwGceQYRTr0X/U1u9k/D
da2ZVIO23M7fxAPUfN52p6Nicr3/5UJKQkg5pDFzo+CHgGjS9uo3lwxUXzF672Ra7ya6SDheiE23
sbCE2KSTvYebWSeigGsT/N5atjuMQlAxypi2tDt+QJbGAIUYN+1nsfeWKqAubV1p6NNcvU8bueLJ
vmEjje+z34kTr0wbd1VCa2MgfnIrGRJaxxc6bqE345ebMOT1sMBj5NfUqSwRUUhdlsMS2wMaQzVC
WO2i4Bgnm1Q+OdCB6FNuTAgA+jxYRvXDIf7MN6vEplTrXrdKSjBL3OgdUq77sbA8ppU4DvdjW+jb
di0p3pKubAoTEXj+IuX0PCSlw7EFl8pTmotfBJD+Sd+0LSl9o5wHeqmhbbZl8CPd1K0f/JF/Fujn
hHO6MZKi71Tamn4rIKKBqiZnvJk9YdHwZwJ+FqPIscthr9iWgO7kZuPhv3jQOl8kPJZtBjUJ24Sm
XLTaPBRgBMlEfRBt8+Y5pp0dAGJjRkLHuNYUB7iu17qRz9z+PMEVFzBU8ZUopDkptAv2D0TG4BqT
qiig5feDx+r+SIhWhs8NpWTMKERGGXn+cdw5Ikcb1ORULtUyxY09ya1eMWlY2LA4ktnPHWZO8+gm
+9nbitabstVQ1mh2oPysgsscQv7l+bNOM+9UU1QiUMEoby9LLQrExh6UERMQ85LT3/HljgsdJjVr
Vjil7ec8dNZeO1nrNcioHkuCQPiv8sPk1y1t/qyhyW7AhUJ2Z+xBDHGWtL5XZRJbbrTNr+GaNYa9
zMLiVQ1boAeRvfcahIZFsHsJlRPddhHCLhRyxxbGqPG/rkHewrt8fUb3xyckutQNO/+cbcmjd/n1
GJOoVluxIkvSqzS0yr78m9ZYdSJNx5XpEySr2PS39LzLMGSU6RWAD85WSYKGSGn5ad+kGvTP/Enu
jTXL4wIuaHMo7AGzrQpfdC8NIEFEJXlxnpKctflxIIWszpl28yGt7ihd7qe+ojitYzaOuZVBsORk
4boNx52zcCzy7F/LhI1f7g9xgfDezmtjJT6qeBBTcurfuyLWmCzUa1XJWs0Ek3zQWBZiVRnVGrj8
ki+eES9AEFjaLSFWHUyOSIsC/InyFP03l6UaTjRTBSCAcYbwTKhAl+CGIMdH0PTySKw7vDVW4uNP
5Ya9Bns86rZK9mPeZ93SfX+gxQm=