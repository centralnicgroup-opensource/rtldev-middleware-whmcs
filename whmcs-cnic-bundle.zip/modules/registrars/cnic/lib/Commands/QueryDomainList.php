<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;

/**
 * @see https://kb.centralnicreseller.com/api/api-command/QueryDomainList
 */
class QueryDomainList extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["WIDE"] = 1;
        $this->api->args["ORDER"] = "ASC";
        $this->api->args["ORDERBY"] = "DOMAIN";
    }

    /**
     * @return void
     * @throws Exception
     */
    public function execute(): void
    {
        parent::executeGetAllPages();
    }

    /**
     * @param int $limit
     * @return $this
     */
    public function setLimit(int $limit = 1000): QueryDomainList
    {
        $this->api->args["LIMIT"] = $limit;
        return $this;
    }

    /**
     * @param string $limit
     * @return QueryDomainList
     */
    public function setDomain(string $domain): QueryDomainList
    {
        $this->api->args["DOMAIN"] = $domain;
        return $this;
    }
}
