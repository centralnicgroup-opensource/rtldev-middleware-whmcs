<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmM6V440HqLttKlfOkgd8nVSZyGTAE98KCae7ed8FWBGV0+gO8eEzv+vfjtCLT99bU9YLcsO
la/rVnVy/7QRQ6wEWUiZYxx4agKOD+Oq9s5ALH8+Dhbb4Fkdi0lb5oZBzLVuEynkt3ILQqsRz1Tc
ZSX9nQAvjcgZnuTCHbJB7ffxQfzpKu7+P0TAAwpP2r1cYFyWxc99OQfzWnxEaFOVU7GMk9D9bKn1
NcRY3x5HEB0byUVWTLvKSzdo711ZGbbULtxr9qZ2LTKCgJq4gYZqF/+XpxxME6Wg5aLX2r1ospYd
46ZN1pXrjSDpsg/ejzlz460a8wGYALuqNOpAg+3pfswX4EMyUBGjV4qoENC+0MTFMgo8bYTctIa9
/Ctm3vMuVtOWW5M6/EgADDXqO6IboQWj/xNe4IXd1BuUpL+Hhv3FKtEQD/L7n36hjuVZsm0ab6hc
X+Ndg+1MDrd3c1iDYIxqU3UHMZAqTeXc+VRQTlZJmMew8CNJW6BMoZg8Fo7sc7RMkz9eRaXdbnFA
Gl5Wx9TYiqJWwD7cZIHh7VefsZ+9seu1Isi3Qwfari2GkutGy+smdEDWBm9p8WU13byqS2KiN41j
u7RllFsByc26lknAOPzF0Na6uFOtXkeQiDY/fu2zGUd0h2OIK7PFDoQwt34t9QWHOClw8z7PenDy
88uPqDkN8fekyGeAWckAc4l12R0QyxIfjh8LoFKMhObm4T6mKoN9A8I278Z93W1CBKFLLbrBn2bO
sy0MVv/EmeQbT/xCYViAV4esD2JhOvxDxvMzdrjrDr0aMb0VNa2kVCh2a3TwPvYC7LwK4ch3l3LA
gnwxoHZWPrJmLAqzmr6oMyO9T1o61pyIk0YwllMFdHklIDEAuM0iSXfYQFMquddiYEwoCzYMHd7Q
yXQqIQ9rVN4nPr+W+DOH3oZfd6QM8urXR8g1oNtmQtfvRbkQPWuWgutlMlyUhvXy3ZIuePt7ffoY
GpL2iglMq6ETcCjrtY98LYy/UF5JQ8gAuKat3+a2iKGE8QkDAGq5INya4is63Z725HjTe6TkaBDH
ZS5e7tcAkZ4UwfrX7ot95UENsO1XKlumkxbm5t1gXEg0inLkILBnKVySgl9oYEvyg2+BVGYnsfpq
GiV9m5D2+Opi2jqDiB/12i/7t7gVIBHXDXDBoC/T7u72/nnYwHEfU3CkCFuDGXR9wfoxeKUuTHXY
6RJ9yf9iEKXSoXnNRCRZkB1gqvz96e84aOUz7RqDx951Rczg8YCgrCNEwlFy8STaLFnbfjKXWa8g
iIMCO2+MBeiYe1FXdFqTePLAZS1vcYdR+slKa21TAtdRvCpqdKKp+T1F7FGJXrh/zlVP/SaXAzx9
9Z2wuN4RZ0zmu6O00XhSAGzFA2pp62Ylfhf2m5s7MGDBpN+fMqXqleXZe/LFVGtzbnHweNZo2Z3K
zRV5L4ZvC9XNmq44glkrA9aT0WjCdJD6sj0K2l6gIUDJ5bU4t4hlaj3G1jke0ugLw8W6V+HIl1+6
gYedfzXej+rTR+YW1PAmCHR9tyfkMeDLDP/ixc+hYdL2bc8uCFt0HmzOyRyU/smO/f7BCzeLC81M
IhmmeXGKYTiP8QuH2Ej6FUZbHmRgspXpqW2k7ERIuf/jOYPap6fIAhXBuWHYLMaPkebUz6En3nTS
tTGvbA6QccA5JLCNaeB2Mz47JF+mVqdsZAOO8UH+CF/NjnMeNySiYLgJxKxTvQcYQgHSediPHD6t
tU4WM5gJxJfdN5fDIRGJ/ZweVuKXbbkG4BqPG3QgJX/0dg1O5lXC+HlfexkSoEbHks6etVc3ZbwP
3/7qBAuIfoD706gRntuZf16g+QIQO+/Rgcnbw/pBEjxJiQQrucWdH8Qlp051ON36quJ66d63PQKc
831mOdBUOD9q9bpqobUX8M9WkiyKucrLMDQTJHtYHHH33puurnMCJUU9ru2qYo5bcFmHDE3jtkz1
ROoPb5CM/wvRm3wRUFc6+ujWV1jJhNFS87ULdONj/hV5kr2ZGDQ1qyvelkHbKtmS/rYWEm9z+TRo
D5U22fS6T1JgnTGNgtc6trZjiI/paqcuVlXC2Jfz5Jw8H6n9A1r9bIEvnXfQfgtDXCMnV4jZJjxO
obV3Q65R6809MOvM6hVOICPj09T9X7v3i9Z7maT7z3qlrwUElSImSpFcSthM1PSd6UixXjNEIGTH
OGAoOHacDqdpLxqDRhx0CP5GHwHKFcBs6LxUu2JZxk1DpG6uCLDEw9esCxTXZN1EWXrgG4lFRCJn
QC0uVIC3g+2W+9o5+FB7QKM58bx6ItyStavrT1/iridR687AEY0VyzkQTLwnUEJgyJapZDrT7bQQ
/tpZa48rNMVcmjdr1p7Mw3jY4cv/x2U9Bg4/x3HDeVtblLdNyzogn084h6UG2CzW0SclBovX2TCk
X5XcUO/BrElgiGpSwM1E13lEcT5T6CeaStJyeJNbsuiYacyQ2EXL45ZLCYhYTbQt5samKHQEQem5
x9TU6qEEc5Fjtz1IFgrCUfaAFJv0MhGigmIAj8EwSVJHe8uhLLsIMLIlURGzeCbpXy8AnI8X6jV9
WRkRcWEX4wWWA9uQC8WEAKi8J0gH9FMTintv+qOYezbk7Z/BJ6IvCqCCqiF8DLRcpkPihn6X1BKn
8ASCP0R7HFsWU84zyHKlZ8gLZ3WXTok39zJor+POPVESuaDYm/F7sLaqPZ3KtSHDEYqlsQdxGq8p
N28Npb1zYHMtAkQ/A+5xdFacXQDoyE8uBRirJdlbf2m6QsFzVcM7YvpCb9z63/Kh+Yt0bDaL3PqL
qgE5pwKPXfkZTAhg7G==