<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;
//use WHMCS\Module\Registrar\CNIC\Helpers\ZoneInfo;

/**
 * @see https://wiki.rrpproxy.net/api/api-command/RestoreDomain
 */
class RestoreDomain extends CommandBase
{
    /**
     * @var ZoneInfo
     */
    //private $zoneInfo;

    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        //$this->zoneInfo = ZoneInfo::get($params);
        $this->api->args["DOMAIN"] = $this->domainName;
        // TODO: check about
        // -> see cnic_RenewDomain
        // a) is a renewal included?
        // b) does it match the renewal period requested by whmcs?
        // c) if not is the renewal term left supported for renewal?
        // d) the above may require executing a renewal explicitely
        // e) logging the details to activity log -> worth it
    }
}
