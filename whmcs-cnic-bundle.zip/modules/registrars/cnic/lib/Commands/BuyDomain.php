<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;
use WHMCS\Module\Registrar\CNIC\Features\Contact;
use WHMCS\Module\Registrar\CNIC\Helpers\Pricing;
use Illuminate\Database\Capsule\Manager as DB;

/**
 * @see https://kb.centralnicreseller.com/api/api-command/BuyDomain
 */
class BuyDomain extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);
        $this->api->args["DOMAIN"] = $this->params["domain"];
        $this->api->args["PROVIDER"] = "Sedo";
        // find or create contact handle
        $this->api->args["CONTACT"]  = $this->getContact();
        // convert domain price to user's account currency
        $this->api->args["BID"] = number_format(ceil($this->params["premiumCost"] * 100) / 100, 2, ".", "");
    }

    /**
     * Create/fetch contact handle from CNR reseller account
     *
     * @return string
     */
    protected function getContact(): string
    {
        $addContactData = [];
        foreach (Contact::mapOwnerContact($this->params) as $oldKey => $value) {
            $newKey = str_replace('ownercontact0', '', $oldKey);
            $addContactData[$newKey] = $value;
        }
        $addContact = new AddContact(array_merge($this->params, ["CONTACT" => $addContactData]));
        $addContact->execute();
        return $addContact->api->properties["CONTACT"][0];
    }

    /**
     * Convert domain price to user's account currency
     *
     * @return float
     */
    protected function convertPriceToAccountCurrency(): float
    {
        $domainCurrency = DB::table("tblcurrencies")->where("id", $this->params["currency"])->value("code");
        $accountDetails = cnic_getAccountDetails();
        return Pricing::convertPrice($this->params, $this->params["premiumCost"], $domainCurrency, $accountDetails["currency"]);
    }
}
