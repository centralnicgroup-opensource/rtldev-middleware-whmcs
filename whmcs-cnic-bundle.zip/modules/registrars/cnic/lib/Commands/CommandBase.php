<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm6KoaR0CSzfdLrVPTIQ0OsF32RVKcHGT8supbysNX1S6JO/8eL9ZL/FsUsRIZbATLLhhDJe
DAoJPLt9egSWpBlsGO53pJJGYxR4oM1OBhME+YrFU8cCFIov9CH9JCtdnPXvEnKwPnCMbzTfDsTr
77NE5K4EoavUmJvPMNzE/cEd+wmCyV0KkzGzcJCp+iTolOpYeIdc93gtyeFpbfZaA55zo3hMYrd1
BMb2tj+WN8XUDzmzB4YHRMStGdJVMtoqrYKjmbNL3Aaz1Aeez3//eS++rbLdYuktgNU3IUYQyn28
0ITp/uqWSzoizvvuW4C81RQj/wRhkcVLWUmPzfzg8THZuexOl8f9x0DUneP3JZgJiQW1eX7NzPwb
VDmo4fsh+oPBjP+Qggwi5gT7UZZYnKvfG2WAkvDIyStqjLL6Ih94CR0EuWNDYQ7w3RdKLBQcmSg6
KJ6PYrXn5lMnvoKTN9GfgkgsoqChvHY249kXS3bltRijMq7AJ6i4HsoLSbHd+LWzdi93//GYn6kT
F+khONWG583b7OOGn3V9OQeOZ/FNmegfE5HtYE3YzXkRAA4eCpVD/CTsNw5Niz4sCbKV3bsllcqq
QHQJZrWsQBjucU/Fzx6M6FO7kTLHBHW3S+1zDn1szmiVx6DKJJMVQ8NodoMtve6CR0eUqcP50xGM
iIRr6ukM3Okp1GZG5l7oOSRIfeLlGjOsRAuMy+CpBoM9Dr0/fuk37B23D0ntNOht7MEnQYUuG4I9
c47Of6XQNkvkt1LpDOrDum2lkP9kT+N9OFxXdSvxNy7F78C1vsil2cqMrLaBOIJVDtwNo5TR8ziI
lyXzaoRWCROSiPlPd53AZXkwpgyQm6CJsAMntDZqfe0sekFmQN9KIO0hA1LM3ib7Z4a3B9Z8W+P7
rmgwuTwrpf1172IiyR55GBaLrsQKd22J3Tzbia8plm4sGdUHzduGeHkWbIU7wl1TjWhIZsgZaHtM
pDKSGAWdAcxi958WvVw/tPzT82N/ynBGvf/3q8+z8yQ+roJ82e+vt4XC6j7QloEIt4n/+gR2cb1q
/VSqkU9lK9CRMM+k4NAMM7c4Ysn8n7+BX7APe8+aEqRy8nV6XFmbhDjmWqVRr01I2EvEFHbZiiOs
UmWhLut0Fe4Ii29TqjCYvgQ4h5tZ6U5vG9JzUeMfudgLHLTGII5WOATDvip+GsL9mNY8YHgwba/+
xeJgzqwPT9xC/YUmPMagnZYsnFRvQJIeDNQl5+Z/4pQ4wVJUObVoi4uxhY4wXkEnNC+WywKVy2QB
sCcHddpA4yocWE9I6Ul3hcJhKjBMResBQ0LqoBzTr6DiVXbUXfvtm4Gg/vy9YokDCd67+hzG25zQ
YEkkBtlNZYWAtR6MTdNOenfmyJMNEaRp/5c0Dg/CT2/vylDVlM+bYIOvMrmPDZMHTQCBa9vRnwLJ
uWdfK7dYTvNU6bgLVz95yRPkEcqNEHSkm6z/FkybPKodWIA3WW8zsIOBUb5xlwguYmFIONgtvt8m
vWKqgCJP/kL+vzG3ktYQ1vSM5tlEFjuDmnDBn6E2sM5/feeQbYEPZa8LGefWwZlGctwRJrKP278p
q6xC9tVfiZPk8mx6AXsSXbfVwM1V2xsrJpzwBIj18e8rke8epsEt12MutYchcMuE4PKW9YSpX2iI
vw5JEPABeq5i/24uUIB/I3dMKKFd/ijDVPwz/N2TTljJ4hnPapM/Z/fdrqZSyo6JpQ2BCt0Gf+DM
7eQJqfQuII73yqB2MJ+3aZA4w8yrviqdVEv/6OSi/dcxL/6N1swSXOlcjgkRsS9+QaP7ufq0GiCO
H7T5ofwWn/8Pn3sRTGAJGfP/SR39w8dtHQZX6gFPUO/3ag8x0OoGh9dwNtDyFPBod+gw8HQMcbH4
ydduprdeu47kxviWejnoMx2tu6rqiK7OE9Ul66j7ZyoI8Cz7RkhTtQDjRnqh+/A7XQ7RYTpIk7Tt
OiO8qLkZsREf0qDAjYCDnFBdYrkoPegfad/JxVKH6Q4GRsLUS/40MD9k7u4XKp8/DwNmrVoXOwSh
S4mDUQqTixZsPxtkIVJTrAlW+NVqj/n9TciETsDf3d44Zh6EApaNOjKsXnaESlt46n8Rk97IPxXt
EFR3+fdqeE+mWeWsHxuUTV7Uh3O3thdtK7MNzi12FXUW7daC3iDKgQLQinSoPn+Sj2YrW8AiIE5r
EzYVrtnTOeV95w8PJD1qmyxu6K0vUo4a2MAtHmooJ2e33NbcPcDfzz2sat8Vb9a3VXyY1Ofw5dUi
YY/6KtNOACYhL7rd1hHb3uw3jAyUE35BgmetkpM/DwyZcWCzG+HX93zsd91v7tlMwUFchHu6YWBr
jIWimU+lk3U0JB9X8XaUiMX09m1dlsIWcWrCQwYd7aWJxEwdPUYWlkztVdeY8OuXNh0wwy4lgv6l
dfyKwO5VsaJFTPLQVafgq2CWTQ53D1YwL83QKptHKp7vleG6UaIOwDeWmlVA3PlyFxQanvkVQPd6
FS4ZuE6Eu3fqVBZ/2sSOiNj93HSu7fvBHg4lQSKAoI9Lv2USJjYSTpVQMyrKJnYTTmxNa24Cl+Wa
l9l1bNqLp1Ix704/PvoG5mt4RHoy9x0tFOkNQfYO3C5K7cWRfFLvBHEOXzvN9hBOI6bey2znhhmr
gp1KFm+3JOtrflvj8kKSuMKSWLEbOw2u1G5PbxLR61LG6DSxbDBQyb6p46ZUe1oQPJr5BiZCo1fW
UySzlfOucmUSYsV36F/rtpYy1GfCJItc4e5sAqRYDaCKPevqWvelydUU5NCS+z1uYrXwj7+N0jIB
x8YhXcxzn43d14wy+Y7y8RFpGw9M4QEWCWwZBvgFUETl5eShMshocW4YdZWRQgBviWOXYB8ZRKrM
dBOZ5xfZNyGzm4e3s3KlgtsZUEwMhe+ObywAjRdGX7x/2jYZmidWwVQiVgNLuuKgIuWSmHx1IY30
wTG3WMrY1CLiICpECdcKo2Nn6LEej1fRM53FjLgVGm2MosxD8yeVICOXuy8lAgtXav88cfd0UYnZ
pRa9RxsCnibp1P7LtbDv4WiAf98L/MohZ2L6UOd1UF+bhY98i8zQspujDBpQN5ZYMXMPvAycbNMe
tY0DRbvLNhRN8vInyssKQpt58hlzIUIzOpSLIlr5/fmz15VPy4AoM1LEbF5GxV7NEtWCzrVq8Tfg
CLInHf40LLgn7NUZdFdYsYzZqHpAED+mAameLSp7q5zu+hcRevfTvPNGHIqM3IBF9H9e/DACV2f6
JYWhUDcDQ7+twMlh/d0qGHysl4OiicsSJRHfztjhLZJ6ZYsopwhDLXUWAjZET+2Zu9eOi41tILlm
URzrDtVTDALTwLiYxYXsspaPng2LkOKLU2g+Tt3AtCGXw9VMetHPoOIhvYmrJMDgyz1cjcRuhwD1
0Yrn853tLk0JuoPdgtVXBUAHp+35HOtyo8IpPFuJP48H4bG4aJHDQm9U/2MrxKHCtap9Bwm7riLu
KuJfkdYWSnsZPRHMM0sNq5tjikuFPO01D2StlGrTTyjrpC4btu/8ogERoYq0+8zedHU7ehpnN0KU
w0pfcClqaR7DuO1ND/KcIRQKfw+iJ6ulZhgWrOpToJsQZNHYIW6dQVv21/xtQAHOz/WQSM4RINJy
svXBc7/8iWYiGh99wgqt+8z/RjEiIlYJrMnCoP1nrxxDBb++mF24NBEjCdIccM4HTNHwiNPlWdGS
9qeDqsIQl+jdL+3ZH55ikwld/dnl7/Cwej6V3vgPV5mP1HEeb3Icgbx/OTp1Pw5kf+eQF+MulhPb
oWNJXvacgB1IJ2V42qcJixMLkxtxmyPJZlTWHY9NzDoPgulAirBL3pUlspxBcchmYbMPNhlKj9ra
8sbDEEjRkaOk41R3OhSI1/ZmgZSYbYFlmSaTVq/EAVjrD8Dso3zTWrb4FOWg33WEiiyl4dIx/oA8
XEVxu2zj8+Ow0HqDTjg2Bc1+KwyMysIXvPJFDZ7aSjtU4EWVG0RfoW24vKSTJCnTAMQs+iGREYKe
DntV5NIkYUsXwy36Mn8Gx0eOnmQTnWPfaOfhuUfrl3ge+sYasMGuCB/QFxJUVGRitAcDPV38Vqg0
V62CNG3A+1FvLZ+HPbXbo0v6gF5j9Y4XN4+VlzTg98zfOGRhf1f+4mor6UTtscofEtMsi1v/QmT7
+J5U3JaXm48keg78cTLoJMkuSAficeVNn4qldmxL78FoEqSuKypAaKfmm1mkXkPU4BPozxlOi24O
4zfHm6ozBYsjGiXf/oK=