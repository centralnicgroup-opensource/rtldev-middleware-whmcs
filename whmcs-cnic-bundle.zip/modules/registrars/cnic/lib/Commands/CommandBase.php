<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuWJmgAIjpQLQzfNWUNm6Kcu4l2MYUzz/hUuTac5Se/n9iqr0xl3k7ZVoUAiZdu8oFe/L9XM
Ek5sTjRZulwSmhR//W79UhpPSYZfZyuFP5aJm50CTv/mQHIeGePhEZ++Qu1CrgmKow5itS4BirmS
w/j3ejceUStv/c6G4OHxjbgLAX0JteO15c4QYnZlB6pO+N6t12jXWIYgp2VPb0b6+Lbfq8jyj6sr
rLyA0EvMy+6ZanMUruIdlmVjttcoTIQLBuvh3dZg08yfAPZoJlL6wQeCcxnkNXom8U1QCDF7MMO1
kgXdbCEkwf4uUDyG1r36rxG2yHakAss+MA0lZ66G+LtBu3L0laKRb6O7a4QNxIfTxGBzi2C8pjyh
GnYsIHnBTSRFA5CVepjYvPkI8BuCdn4RL00AJ2p8TC9pwxcvuqnNzt/VMVGnecudhLQdQ14mM9PW
c6qhxo0BkQEblAaLlLMVCBKDh6J/9LXLh75PaTHa5WdMVHpgjmE7BJjg7R1GyiNy60YJ8Hs4rHr0
C1gvZhR1ByMdeO5DKVBkYkpZZcOWrK3mxWlvkKaxh2ai7dCD+hMMLvTLGGamvRL9eGgz7zVDINqU
bTg1oCgE0Y07qlNVSRhhV91V9pHyU+sbzQ3AfVQDHIxM3s//LTSCZBoJ1n+Im9yvQqYkzwqbGgmZ
FHkMTxeL1VSYAnk9ndPv/oCLofScCe+Zqf6anp+1OBLOER/BwatI/yPfb/H5LeE6VrTFG0qH12m3
ztIpREpcDSiq0FhFL7oSEgNDcBzSXgP0oSpRq7Ug5HJAqfiKlCatZOui70HR0xuJsfUzdM9Rnf5y
0FXLjJiMezwCROuF1ja6AGMi4kcpQ5ipXn8LM3hLfxsXmKb5zq6eIB22vixUJEwCeC02Ei9FrBPh
RIqJ1ALGUgq4tQbTUvqYNYu5KfG+qia6I5HbRPwUzyu8ebYun0ipN1RuXtRmcl0idsBLmFCqJ6Cc
h6LM5KSkGFy/wKsgjjFyYtYnCWQ1SiLHtH/4CTUYTjPE4RrzHfKYOmD482bp3UsxQug+pZBfU4Y2
lOG38CISJgyImO5hP91SwVycGI1Hadhbe1zrB7Ve85zp1cdiqYx0Rt0Y53AjnaqSp9hUKuUXrWEE
SMN/FlKrT8bhn6aETet/6TcI5EcT3YR7+rEZq60p95n8hvoPaIBGcgxWr6nym/iK45lyviTEq78U
yG09XIlar2j+DO/IFydodoXrKsDL+5hU0cz8Gcqn3CfZeq1kHShPhrmuJa7ZDfzOXyyQV4XWqRKs
yBP6sTF4riaXAfY9Qam3o8plXWjtO7KzBCZZTJg3yPZIAMaI1mDZvo9Y5L2IZKy2xnoFPLMzORk1
FboZEP3TNqmjJyXTDzWqWn6U1LaruW/GqGqC/zJTSRJoCQkzx7U86y3D3coZuY15MxYyxZInvCgD
+TGM5eBkcTEDjKftPVOgJ+8F6hmsV3H7MdHJ2KQdCVhZ7CnvFHO66scmktantJiMpxsQLw/ucLF+
diWNqv2MQ89Uwuktti5aJbCPprbv6If/cRn8W7PJa0UFz0epEjmPQhrIb5RmoK4FB1OeidOAq8Ie
TIoboU7oxVkBS4dLcDgVbH8dDh6AoC5EV0V/+pAPr8sdMV7jwlbNfEu0Va3Rrwoaz2puPYaxEcUl
Zcj97c2MyLgxz9cJ/sfzfKJMHwCbjytudztTFmIcnI2HlhTB7orVeCFtzF+clJx9LYgeGkymnKMc
CR2g0iZgqts8MoDANvxE50G1Hv307MqruFde/nROJtaM/M14x4176s0gqdMwf56MeuSAoF3Xy69t
boNCDRFaLJ/EkBhDWVr5FH47qzBoo+0sHeX+M4J0m6khVrHfuwgVbp5u//kQNHdgvi198gb9qvSC
/8w7DzrR4RfN7kj7rSYgXjbDLbiIB/miDMzVQG8tfAvs43gKXqmdm7eGt7DBe0TrJFn0QQrCyY0O
pcmDmeHNUIX0vnMbGUELeRTprumwO+mUu4VNWD3NOg96ANxVAgBLs1oUvcGzwwLAO477UwrDCan0
AYkFguMtKHakZdxgTevEwpK2BafSNdl3QQVyz/Qe8NSu5AB87suls/NsvpFu2KnISUOY+z7EqW6h
2e2G1uuhNcQcnXBqPXew2sXm3eRG1BApXfoh64Ry6nErmV13ammz7e7eezBdpOs2lyI4Dt3njP6L
Fe9B/BdKG+tzN3zTSsQ3tIa/hVVY7qo42HAN1gUEni/nYbd9zfQY2MA2IASAnPECHUyH1edPGIAk
BwN+K3JS8CCVgsRILnSDWWus36iLlBH4oXS9abX4eQZBXwa6BYcYg7GhAzJoxkqquQf+7FnguJ/k
Zie1+mCYSNusaQV0+OcJZabKERBJbmY1QYOZHu89YMquQUjjCx6SNPZcLNCRYkd3bFlfpjGtVHLq
0B6DmJ6dJjguoQJ0JF9eFtFxprIHiWddtMJSjg2vFVUoRut7jgRk2nZQWrr7jwFvuUZOOlNQOmL9
Ijb65TjICCvXXrFiGJqkiMd8OfY2iy1v98U8QLK8jNFBuAIIVxsaZxhoQhNcZluGB8cIdnpERexd
oXC1QTTQxXFTYWLopnbVhPRhp7XoCooVEuGfznRdq2S9JxXgVCyASDSj2C1qVChb4ZvzHkE1R3FV
C5yG9M74u2GtA9uZyaGQV5ckAbXnCbZYRh+NBcwdCWmxXEIrYPYAGprg2mNtKJf+mHsOR6zpTy2n
GKrzazKe2lTZHX3VD1KPaMwf2cGA4W2E5CvGy+dd+1Zf1VcMAyBchDbWfNhq1oaVfc06+iGoAzlk
gZJCD7vm3LZct575PXlU5r0ebWKEeoAs2zXfI7ojaOl/4SG2+qq8BNV1mKGAactCWvr0ui0zVqXi
4H9KhEygf2zbtS3BZ82Dza21D+7mmPHxz1L/DXa2M5Zo6vRrNp4LIy1/WHMsEk8szQk99396402S
jETsgWlszZ6q1raeNcHUZf3PLT1Wuq2TwPr/Ek4rzA/RbUVK92kr5t4JPEC8qMSkLDSL5bZNoCoE
l5K24x4GfUkDJGfUcE812ou45hC2PeT2ChaLYpHNxx2+PjiOtj93eTDJLQxuDYoSLJcFfoOsJX0w
+eEVoKMYrGei1bpHHBQr1ssewv5zfqIru1fODVtOxFQ1m2DMX4Esm7BGIQ7flocYfSh2OWNjP/GM
M2wfVyQ5X6uhvnCh1e/fI1QcqBTO6vaWsMCuUNqTRtvJ5+uDUm0Paupls60Xi3Tsi+sxWCIN/KLw
OwBWsgRie3JcZ1jauzicZC2CVU2SdVv886bjhjoSAAD6mWtjALlFS3EM3A+KX3ZqsoxqhFg66Yto
Uk/Ngt+WADM9cg5BfMkKU9cL18hwnWJF1Wc6fcOZguo3CP8r4SWABfDzzlrFm+R6HsIn/GsFwKlr
rJJoaCpKQ3zN/ygeEYFHDJZvakmUZDuha9mqgGT8IDwehBuKZO+J8rHD3rYaxiRQ8DbL+Bcpg3FW
7Bg/VLOvXMojcovf4Pz2arwqfybFQcOEQL8JdMXkxc9eai6nwqY6o12ov17Y/A7lVhWL0vehM7DL
kAquu5mF91umdiG6ecyEh65BhudbZsGCHun3Cun1vwO1Nnn+b8LCjo6v1yms+lgV4GLEKH2eu/L8
JAZSrPGlEggQfzJho/H7OEpxilYRiGVmii0qnfDsIcXrHOa+eCdQqWLPyli3mfg8efEWyTFRMNwR
fBA6+cSzqWJTeCuMb9/wMRyDXyLC9cgSgwIEN4Lrjl2rLEZXRmrQmtgCuDE66i68c/FLiuJandKf
GgO6Th1F09S5CNGjEO5Hc7EDT6mpaKnQVeq2Fq1J8A7bwTQRgNzYHE1DmQETqFFslJQGKnrCdm7a
fJQ51ptuFSpuygniyUKgZNrRf4YiGPaSSVdevFSsusQOnrehAigXqUHxa2D06OdPxpwZWfd1JMg8
udluu3dkjDUdcAFcX+c8CZzmjleNjdyDTNGP9sPS6CPprIPNZCEbapamg8RprprwIJgIgXuza30x
PnyJIHD99FRFTBOMELm+WfQJgIKuOcrJDNk3Mcz74diYkjQUgwFkZtgRM+9bcNznTdMMNw01vxpd
kh449f5QzTnNAzavCNEM6ts6zOtyLxyKJbd8X5HtbKph2sdWIP+1Yi0ElOSkfYMGO1D2vIzWMEXh
CTbATB86j4tdtykdjKkT4kgxZbwgiUABlRF1jxlZxE0VD+jawYeGj7MP7NmaJI0lu4TKYFLbFinW
xDURHcVj5S65+RN7kMMAh5V8mOO=