<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyjB3Y+67/C0NuAR3FL0x7Qwho4qcMjodvYuRmhZAf+oUT0ICnxnlMwp2TDQbRNYE2IE1VPL
wIsNemQmWoCoZn608X7eF/5LhzsWQS6qaU/Z6NCoS2HpKx/+RA/ELhtq0ZHyfyYsforbinGbobTQ
HfjU14SafaGc/Es7G8HTv7nBVqFvWGl3xgkS7QQQWbMzBrMkTphXh9px5EeUaU3uqcWfWHWlzAbK
ejPWzLzLk7K3oSi5gyM5ir72OG/MLdmbhhrN4LZ16OUBPrHyK4fycPXPjondqnjR+LgQQsxgAtkT
yCOc/mPCnw7luD3lwQA1HvJjGGTCFOStGgHvvUlfnHTpJMuBrgSlIZDRyn2ZndTGVSTUJIZNTt3i
kRi6cM0MfCCs48Z/rK++c9xlr7NIDp6ieYj0eMiIoQh1nvtpxzGW8QibdaxrHArRMXUVE019I4TZ
+frGgsP0NHjtqF17VoqILakkDyA6BAklLX3r0o/ghV4ELz/jZNwG3N+42BRROHJXLb5cLGc3nuZx
JzOcNWf4wXKg449BtO8Z0VSXhsbZ/MN01iwkWSrXaTJSdb8gO/LoRYl+n+jajglhY71jJB+xjn7k
yI8KedTXwH/rOPWADAemEqJcDzidrMMhtGmc9LMNPXxXFR3FionacAe45+iCa/Q7it4CJHzS/CFp
WEe6jTf1TzXV/HKa6CoHc03ugQuf930SItkyoD/4dTGZK/p8ytyNFVzUEIOikRENNzmmXpZcAbRq
RpvhCKZaDsjniptXK1T8+rdB9d9s3XH/qpGt6zIjAKYlohq9A31rcxJPXIBZFr19MctvXEBdxijb
RlZM5MKeqN2KE0353Ion0bwH8RRVKKhCfrCPyuJ38tPNSrfrIDVCH0X1AC9hr59XB0hMMFiG+gqs
1IsjbOfD9TzE7xhdGMgQ/N1MZrjzZRL+1HtjbElkdXeG7Kc2cW2hQyboj7IFK06b6Z7vEkSfl4lK
VMd7TAsZDxWj7FJ+tl4Vj05pgL1H1M4C95Rswd8HU72+cVw6JcKIXICB7V6VW877i75noXH5aGbV
lV+pEJtFfZ5WvMqe91u9pnq5ZNG0XMoa26JTCwbL1bXt9/9lnuaHHaUtRRwfoPS0c7Lb9Eme8L6Z
z3i0dkp5UyMbfnxAoqmX6rZK6D6T4o83h7uUWUUJ/OiA1P0fUNopbnrnNWHAV8/QwRWHErgUfc3C
Dwjk2QecP7V1RwiqWMhvua08+QPfbz5HHdmnPxpp8k07sCa+PuJG0g247o52Y2uT3iG12OW8Ji+r
QXy/j+1CLSyAZsN1yDo1V01xb7Okdx+2JNe2uZLb3WYcVIY79ZG8AiTs+sf4cRjXfhcG8IMCG9q8
MVF+c5dahYEmg7i0CkKhB8fBklib4CWCKOZxJIqK9+I6mnVYTepNHu531kLZx1tWdBt2IZwOBCHe
vWeDwH2idP2ktD+ROgMLkqcD4Z2c/Dcx2/hWlYUE5Qx1Pur1+RJtqloBAB4cjHp3xieYA70YZHL5
vfCAEWZigdNkv3tqG2MlUNNNUZy2arN7gn1SnxyXEKNFo9MD8vC1fXMf5r8CGwMSjtzvnNy6Xdp6
Nza8Wzm185N+l+9k7w0n6eVGa22rfsClTUGx8kredsvHyPaiaafiQLhGkbCXRw0f6XuuYcEUNJXZ
ycogUU8mRCgcW3eHOpSNCrB/+IjUCQAnuaKFYhCMBPlPOrPIe9ENByjxDbF9YS53IVf+5atDU1B5
xcItWyMWEBbHTZaLm8qR1RQZ5Sw0KMQedXvkuXq6oG3Dz0Iq4sWKGgFb+ZGL0KQtPpAkV6BbkHBE
qxv0tO8MESeCCfyh+6pa1kC/hK2FlibHrgw729bdO/7D9mh/3C6dHrsMoEO6jYSB0NnFkgr5NCt6
TPvaPMXu2Hf80kvNpFwWjZ+IjL0A0je3/25LbizqfmFME3Hf8hasvz+Xi00XjTeI90Jq9uMF3I9h
bJ6s+nVQaW6x+cNTNzlZM4GwrwPU/ah4XIvm3c4FNXp7E6yHkieoh1bFe/OVCVyNoBHag87LQXZP
86+O8b6TATNx/Ee7/5f4hdXidJOWZdPcrFeKcumd5MBWSrSZqSjpIzaUFZiMkSZEyUfml9iQYNSh
26nUrG7nsWGdyc+rTeJWojLPBeCW4uU/3xS4X4jKThGgiorcGwoWQVGJfin43O91fbgEqTupGxMK
nvrX6cbgbqnaATM+2dcZwben7VYaa9Rh8fJZX5fFD0lCA7SONhPgDAh6s6rgfI9r4GOiIXe4Itgf
HyQ5oUva69/kH4URRq7BLoI1JjysiSkaqlXKwQjKE3LOrUZ5Pd4lvIJJBdzELe6rQOrNTjPumy2r
NhVyPvmhoKdo1ptPhyBooWuXjmeNFLqVQ2qEbQUxVGA2VmyPSu20CGfggA8B062RNstSWkmekA7t
3kOfV5JAPxxxVAESI/Z4E3v3KGYlcG/yN/RupnVYeKbnheoGyf6B4yLzKiyAcQPSijif+zVZBOLM
Ccaj81WCjNyWlsUjPN7kMIFHsX+Y5dD0fE9T6VCgr7O2PRKs+yvxuaboHJG5pRYcQ5IdKfa0Hcs7
X7SfBeymOc9zkHUHKUIOrLRY2j22DB7CR2FUcUO4K850BYfcgg4OEbAJA0UHpAmsvHqkOkCWgnoj
QpPJnZD0JDJvtuTP2dD86v6Wi7EEKJ4S+YSY3ChjbkBdkwL0ubmD3bfp7Bzrvl5T4I3p5a7/m+KI
0Yh0uyPPH10ES7dzNXkJMpUsY4zRiJENoL3ivKh9slnprmfwlkkEK3FV1BLWhSjllBnd0fZiUasV
TkrfolpCnnEDZi9NACmoBg7mP8q8R/YJFJhijzMmwyG37e5L7BuBsXNzan+am+4jOIyeG99iGtWP
uNcXyLGoITPcFIxZ5haJ61VC7iU4gYqBgriRxnHhVaf8JAa5AViqBTcPEPd4YS1NfqfMsljMQ58Z
HP8B7PQf6xfJQyo1utfPyRLJcLoUSwnHjpZEX7vExtLS5NJpxy15+zPGkoeS1bq3tDof/SOKo5hV
tyTu+Kq2+1VFZtLJAGCKlg6tXuiNKOs9Avq0ZTSpVR2H3ocdiP/CcDImxaPK9nSRNwbxRg5rcR/R
BclrJERU7LV86dTYGTG/jD9fNZRxoOIr8Jh4iJAfU0FK4XnhD/hI310DDQ054tRv+H32KGtAak1T
z4Xy6jFx04BQqhQC06xC3r4O+99VbsnzGa2ip7qCI3Y9rZrwuASvYF34qYExQ+b+2RrHRLItkQIu
jAfmCzfh/7pLfjgAYmGnOQIFP8XwvTO7PU7bJ5TNaWiUBp8UO5BshGsZh+VS2vo9zG0gLJiHEIas
/ABxFbS19NCk8Y3haO8I4jYe2Sen2km4Ms212Y+PMz6kRu+NHf6cQI03JQwttBxGf27YS6/1ZOPu
zR/m4dM+FSWIVDILyN6VJa5pbtSztrQ1YomKnvgHT6A1s6Vp9yJtmXTG00lLRDN6vINc5PlAL86w
OQWjFiP6zRg+Ae5RLiQoX7ObegvpHvyIEKU2IMjlpQBmlLKqbukN9ZgZlQthJuaaJQlRkS53gbSm
fw/zzLumwINc2GkWZlThAkGbx6pqaCp1Fx3mgl1wC2GHBjkFE1P6fyu+R0TelimrdI2VwAfu3aqE
WAzS7u3HamvY8frz/cvzP4m3hBAMUPOVYqtYOfBB3NOB+rtzjwIEH/lPsvFCn4xVhEYmH4ldjK+s
0BW21d5nmaki8u4KVs1UNiWqc6n42RvpigszicG1GruQ+JLBQyHYiLzRgwuq4ya98MC1qEVKCNrp
booUf0t0G3CncKjNWZKSDmlr5+nS0Y9a/DWEK62RLUqRmndZZSAVlw7RhmIx00UU2F0qL5PBXBzg
iWYIeBIOuBMzyu1ppqIKRM3CAFpb9EFMR8R3HlvIaVCwqEPtdMw+uYlAgneAckxO4zq0hUAr6Acs
NO9ssEaThkYN2q8r2Dkb+NZe3GgFsCF3fUlcgNGCJvE3jC8AuPuGJq9m4a/zccjJ/YoHn2X5ZMkb
athSzaIREmyVHMw4SkucSZrMfCI9IkQEnhCeZPyM8r5zQFa49IwoQYESsm9JTq3ITn8jgjh4Wprc
wR+lUsbnTpzkCtY2941TvSQDzKTsQ0OHjF6p/T1zjJJO6ycoLUoyWGcwURrQNNW3IT+7VXTdVRyj
85qDQ2kwdeXrVYWEL+UUrTueJttGtO6O2SvKFpHV1jU154bzuytWKUtoVsu2XpiBZAhN0YPOhTaN
IBgw1Y5/YEtZE2E8Gaz8HZI+LfasvG==