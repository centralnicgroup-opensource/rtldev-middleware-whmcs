<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzmYvXmgfzfJC+jpFrlEtKt+fmB4Ci6P2TWEusAzzAWASvnzxWsg3dcqgS1/AArdNh+LiWA0
vqLP8xCNYP2EM2sKHbMyUbSiOti7ajz09n0ewCpxLs2i74Hyw+Rwhq5ACmPlgYrgDH5EeySM99bl
5sZqeyuVu9nf2SoRBEYiRHVo3z5sQsbQdaSInbl7yiArbnsK4Qt9qv3XSZdfFWPBk3AKsTlV27EH
XCf9G8FDDH5XtNf1ShEE77czcsb/SS+ccAQSGi0ecS5h5/SQ9v2j2HIeQ9bfPbQA0piGepezz7WN
zuL74/z6DyLOoSyMS+C4xvOVqH49EO8pwd8uijctRdVfb4O3xujXg2O9HIdecMXFXWGoZzuZW0pv
q0Hn8vF8Q5zzbCIQu3rcCIj9g2L408QMU73mn+MLU2syh6ebX4l0SJ4KfL0cfF2ufWujDUyxnsFa
3C3anxbOWzpJQsE2hUTGBGU3NodxzjKOgSyVV7FWEA+Zx7A1awfAIt42q+QmQKXXG/zyQ7Adro0g
gRyBEiLWJowKrE6q7WA7QQrKGo5Un7p6xB/AmangMudMSRHHlQamrr5uiOBXx32ey7lmuqLIZULW
mM/K7ou7iDwuYxBpdLw7YXQ990IAMt25yUryfuPOOeeF///lO2QAwurxqbM1lmq/UFaOMwcfiRci
olPfu2NIyWRMx2AiDWQlaLC8HlG9PK7KuABikH2S8xNnbzcbGpsc740aXNRAbrLkr3icNLj0YxRr
3ROfmdsAjdQPkAo2IVgWu94RIGEsQm1f7CdJlv9/fiaq/2PqSuxv1yeAr2qWQwWm4wybCdU6S6A3
7LZVtDPmRB+A0c09/qZKQIuC2trnzqyumg6DSve/zAQd6zCxhbixEg1DP2Ucd0DWhJNKvQ2B7fY/
DzWU+RrvaXUz3x0AEapfO83V2fGEIhjlC+sL2IiKiOi0qRBBpLKXGJjq/X1MKKyEZi5YsGm8GdE6
fU5qhIPUKFiB79rCJ5R0EMWqeU26zAh6+Nak7tk14B5UoTB2wvdxKMcLKg/UIpgB7HmaboD4aGph
OQLA9krHl3k9Po+cKmfpEINnavaVCLWi3IQTAmqgK7lF5/mWp3btGjwHx8RJ6A2byQta0H5BQEWp
0G1E0YT9132XwEJWdBqR2YkgfYgght69xCKjszatnmzTxLQ/EufHe5kyD26cdD9dplwLhnUU9h1a
ZbnvOBW0Bhc5Vhywaz9MZIf4z8MGsUvfZfanTxPNpG0ftpR1FX8F6XqlbyW6qzH9DsyPwompHcn0
yGsm0W+uqWHm049i4A/olgLae8266T0/Kou8Df198ty73eUoJ/+At3xqSRJP5XGUcKaDL5xkT+cB
N7hK8xfA+WuUqs5peoQ+lq5ebtWs/u01W26Eonz1dQlG1WMucpq22MWgPjjjdPJ8+aR820eoZ3rf
tSanBYW0+DnQ5et2mfZxqavy0rPmrDpQf8+7D6JALIIQbv3NawKAZ9F080I+GnvE5jyZeTToCHkm
l5V9B8SxJsBu237xxEYkTxl5vc3O3EM4c23mlvU6RjRVDIt1p2CI4wJPgwewYu6x0tswfIBqGcnq
FO4CBlNeCK4eBS8PhMOTL7r18tBvEu+H7YvsXnkCf8orJcwAFlvSZGbthPX2ITJ0WRyfvUG7KgTo
bbIFvmns6qM0450HozbrXRXxXpaVWsFolQie4coGx5VibKIUZkoEUfMCXM961nUyTF+FloVXo/ZX
dYXOJXryRCcA1OH35Ljs9NO5RJlGyZQiOwFwLBW2aSXvKDEq1qsa9LWTomDR7/vvc2uQo1UynKvo
YF/GqyU7q/vsKwxRUtFIp1EWvslMEcB6oNVB3oanUnAl7jbEEeW7ndF+ZMX4h9O41k4ng55ua8+k
ivFt7p3cYuqoQVzkaQ90lmASBmG7aMb0E11jJqBqyVWKCKlitYqtgCyA9axDH4OPV+8GnCUB2h9q
V3j5LiiJqBDpL9zi3UFE6fgIFygsM0tIYoawOcfSJyXZ4qVBo5RsRz4ZBexX27TLzGHMp81pH/f+
mXszZ8SVFu+3vzIaw2Ul/TsEpo3rCu+43ObyPVGG9Mc3PnjcLkKj2cYepqM9WCAKefVFnvnfvmcg
0xZfyY6OaritcXKVZe1g+RJLXpLSa69VQuUQljUtIim6v92AuGF3jxPjstizpJYrEX6N678H6wC+
7MAjtea0LNjo7xEUxMQALydFUK9nGHxzcneRQM48e64OpEaZfO908guoZJGS83lNP08dfcZDzGJz
ZtIR0O3H0DicOao47rwqtVwEYXtw+A2z6Yr5S+0mWziWd0zjKoKC3n+01FoN34cCinD6FdVfOSLc
RsJ+8J6NlC32QHBOziOnzFpTR1jpw9QpUKJGmouEWkORgDVYqz+L/mGAywQAQdRfi1yv6yw1GLVK
dlBHfhvclzlJCNZQ7GGHvToBQyaXotaJVW+3/dGGgekhat0B0ZuXWFhDEjA7uTOJ2O1T6UsDlOpi
Ic99RIqjLn5SbzTRNl514vD9GRp209k/K1lAvPL30L9tdClLmwMd2n4SCABpJzUKaJHa11EGcnPl
Nsp9pnE640J4xbNO0XptPX7uHPZx/vBEUiszVntFxvXh9luTRaMW+05josdaZyCXwORCGHNgulRi
6PbMB0I5LTfwGvIzSUy8Tz7r0cpeiR5N0H6a/F4xEnS1e8uXTkRU3qzGUk37ayPJjM/nzoKLU8CK
wsP1JTCzzz0s9TQAXlGXr7A8aCx/1ZO7PLJEJUqVKPOaklLkGF9pmvTtbEvDR5kJeK0v8fItp6tU
KYSPujWh39uNmZyx5GIMbqSXt+Tpy92qBnfgbItLlilKCzzMktK4cpxcv0wSO2N76mDLLj1faWcz
jx4gRDYPylEZn5/+6XDJWfWv4LCuCJvPRjfjsmhGzIafUgTxYtXxCr0gJdk2Ma8LJrNi1gmJF+ts
IG9lk8FRcJKS5lRDOwGZ9CcuTKaMiWobYjFdnk3piSi4xMQrg37UmA2PUWvlX97GT2V1hTkfLvor
0GnPl6fOFQLouqSWzhBqgS7gpFVC4GL62jhhEYnY+fHS/v0jL2jSpEbKpAXKEXIO6xkWDkzJssj0
mO6cpTVRHg+HZPxBuMrq4C7dIrNRDQLkWsLyjc89ZfWMyN6pjwHUfoF9Kc2wdC/XmzTC96l4EK7q
NVUHFjapBSZ4PCeNcQSNmmmZUS/fdLzJVXjZAVlfkJ2R/vvcFT7yPY6iBvQDg9NN+5npBmHxOLbd
45qHwON3mUtJwErgpf0Nq+a+7j4WegDtpuazlgkHGdVN2B2pte2LFwvf1vKM4Lh5yYRZEF+2q7FU
HdPeDukDbLfmD1MkcDOVypkilqdItcUP2aueK2D9trCTHLC9BGAYO/mDPP3ywJU1LdkpLCcfPSa4
TnyiLc7/yHg+5y8O830/6o9hZelayyb7/ZMqiwhVszlouwIFMvjmh45vO5xgBf5GbyQLB21g0QdZ
EVdIw+nu/okYvyds5WLeeRYZ0rRjueP57zK9VUzOqJKS29rYiJerOG1I0u5parkqqktkE8uECqoy
8clkQiL1EKLS/BfZRTsECrjlE0ahtUDHs5kOSzexm/euO1YcUb6zl43+E6o0y3hk9KCxtVMBIbcy
EL9wyEqfexObFQCrFUEQ27hNoM3eQN9nAln6z/w/Y4HKZ5VlENgeigt8hZiUzC3iXBXmI2eUNcg3
kRHWZHwYT/CYK4TQMUPhFV9rfcz1XvKaZ5fIwPkCdjS34VyEl2AJXaV2IhNkHH+/MD0QW2n6cJJD
Fu4zmW4kZMU2cbBWzerGhRDbsOwO1OhT7biCRErZxURfV5wzcX/il7Wl5XqkPtTHVEyxfuXrLF1z
ne6f+hzZI3TrVToG7+mRYKVrtoFKGOYeTpG1yg6a2UjpTirQfr+j6SGNwIjl9aVfusmzNRk5gIAT
Xrd9Xoaj6ItZkcAJlWTlOqcFELXF+DA0zA9jyUr//1h9IKt0g0Crk1Zxh3/ZWLEchIHFtC+z11gR
LQ7eLnNz5Ihigt1DerwziBWMdaKM5jGRCXDpInP+UPwo+2A/K65Aj/re1oQ8kzndLcY5K4oLLN49
G58xxbWVOyS8kdkzESzwj1cVkqk0HOmZOTQ5vqkOzZ304osccAYjLYnLdtLmxlAgPb/yG56iuUfx
iEYaZBv7B6skoTyoRRSOKQ/0x1KD8hpxDef6EUTsalnilr53QiPX+HvdXB2m/aATGAcAfZeF