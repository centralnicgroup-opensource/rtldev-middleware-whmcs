<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtaRM2CVpA0KvjBD0EhjzZae4LTS8+4czOwuls+uxIssrqwMIRuwS2BE7yOa+3WnKeaDz2Wl
cTOLotx4G3/YYIHIvpLSa+8iUrm0uueRQN3cbPS0jwsvGt0o7I9aGODozHNr+6MnLLDgrvHbnn2n
Rt/plxFypvcwkt3D6PtVjsULMixUQmQbGrC0MLv4yWfPO1JZAoyURSUWXBzmpvZHfDNegHr/Dpii
HHDnbH9bGzGk+BVgs44+63Dz1teW08fi4ccSxIqRXP/lhvZxOR6zLnCA7k1ax3x9gc4JWqZBtKXH
PIXK/ntLkBhRfCjddeTSsT/ygnUUEYp7PJfEjNMmvp5C3waI2S2k0yMGFhJKxOuWiBd3gUQIa8yj
5HV+hrnkIdj2uOapkv7OzRK+bVKnXsH8R0TPQ/SphWPqNXJ1vPOZIOTr+CLbQm5wKb/BAr3DDY2i
EBU3InjUz4iK/kW2KhkQwTjAHC8nC8bwdAJpxAFXfiUuJlk/ftZYMC/KFQY9LGfeoICNZMm2w2T7
09reA2DyyLiYSfInOMevdkRdgbwVVm5pTEar2Ec14dG6Kn/rVS0vyP0eli0+Atq4+f+6gODfeay1
RlQu39VIFI/AIuETRdcaUNnm3UpY7QqzoOUoRV1heqB/IoMwmCfLt/zBbun/yMfwwyxEx2pZXIKb
g+k3OxLwuOEww6z7lRYmG2Mxxi/pWyrQECIrexPXyVp0jPpbVcGxDglWMDHJ/8qrhW30IxI/mqN+
mfj5JaGDRc+2ZuNk/pL8P3qIdvg2eOtIbjB6OhcWe9u2ZeESs7CbP2GQQNrgvP8+OLV0Ghhfr2nf
9y+Ubzky9OqJfQXm+m4oEBvJL7tqk+eYRhx5+bAvDVktoXdCqZkkMWtTdTh5iKYA6UvmW754NUNT
6JehabKwhjzCQZSZEN8Hfa8NO3XY514fpf1S/JuW+ZdAZJBHGpFXHJT8dOploaAvNosRyfsSB37T
HBCAInjvcRmXp1y7JdfqtX6YA0gfVvL2/q9m4hJdWswBGZTZKJ0bAOxH3z5TGp4eDn1GCiy5MJqO
/frVOzEDSINwyofiuuVEUpL4gasoXPYEdbXQgPt1bNzESNMH0m+jBkLxS+KTnUjLa8Ne7mB1OUQi
StQNljqSNJB6JgCFl4s3s2H6lMJzbyqzVmBi8CKSA/j36jW8PIgzwj9BPG/W4313Hl1mFUuG5ezK
+4Tl89lF7bDRpBmaXSrG2I3nQkxzidJQTNT4KcJ6rHzsmx7Z6WZw9mKV2z4Zo556PrUxRJvuPuST
hZ6/sG4BdQbd6rHP2l1/Hh/a3+mhPhb6E3kwYIYpllfO1z4LkgOB/sgMB5oJpRd1weh9JlOR47vx
PnoWlHhQPTOvAza4S2Na+OhzVpxyjBE0ZZclQl2NYvST4Oj16Hp1AWrrrGCUXw5Ew0xwAntyCmHe
zUOj+BVHqhiCvdm2R5FyVsHt9ZadXB5fxSRqEBrPr1xH4RUrbnGQIFTnPvZvoFxdNp/Cr9N/oEbI
Udj2Q/Th3fxpj8BJ9s0D6GvE+dibSyOaAIcDj7z4X6+xQagNKK6J6ax3WdqGBVynS2hw3a66CLr4
6ar5g9yfR26Ixd1ygXtEM6V8ySbjaggh6XrrYH/2jsJKThXmiDGDnCiboybidckm/kEVkQiC4qhh
loLD1edePOXXM6h/gCoR9SPZj2N1sZvs8RrAA/7OsMnAf7Y9/MHwwQIUWGUGgNoeHfxj3RYOSwKB
t0S1NaJtoZ7wjjNNnrlbJNd4AD916c4Uh9NO7WD9T6sAeunfU7Nga+xpWjdmW+Qx/s0vzZUTUkZY
3XefrmqtJvObNDX92PNwZVtf8gveYcf6V7SZ4is+y+7foSGZGeCmmc1DixrsnGT4xN4qo2j8VvkS
M8XlZFyVqv+h321tdM0BgN2kO1fSOW/ARSVkqElNEMXTr+om01BDX3h0oYGEkzZsaxWIXj+PpEO4
KR6b+/5WqH5WkufsNt4Ldx0PgCOe3Nej1/gTxyr6WcRTtuY8iMcCTqIka6OWU+HrgPeDtSvijXm4
+7QghQw2CbyioPVwY1i1/JVOWYe1qIY0v+DGnSb+x0OnD2KYAZCmhoEb0HJwZpN+AEIjgfVjCgcK
+aKIMOVT2T/2B5wNx7RHP+8DzZ2JXkJgUnMMQQ0uDL+HeZ44X0HbHy6xcyL8/tV1GywcuiptUexY
AJUehn+R7hT6KzsTARXOMJtmoDIM4k/y7/hVGfw5zYNvGyP5qVvkbPYZFs5w5fhQMUiShAjZNx1l
YutOd30P+NtkWhX28+tBRzA+iyWlvUjkOFSoqifLlWAOjYoBCq+d0GefKRYuKQZLcpVx6wNTaWzR
44MqDv89uc7bekFgh355bO0q/mEVfYeYwGI6T0xIf4c5SDjFz8PAbhwjyT+/aVcbQ71FUZgt++fd
C7HoayR0GQETEdPGiwhr63WjQEUXbFdB1EZJQR4lWSf2pqhTFghXef3qLSrZNzRb4gC1suNMFogX
a/NmbxuoNYiq3dPtobAi1y87+8YZb9KBo8t2MFeiq6diWu71jMwzY2KOdW0kyq8Et+NZZ1eXt6pV
t6rolDbFNQCBeClsSxRh9vmObOMt/fzn6ms0uSUg7n+19O/Hj35kwHq6r9Mxn02FhLAVSY8XJRGH
FpvgLfU6acAJb1xfO5MFSZ22/6A6CqSsjqz9YhFv4VrdYKuab5dLSOXfPsq9PqIrUUN9iKNsmamM
ndu9VWcqinWORQdXFfKv3rITylBplE2ufCnl7f3ycMnXIRw6LHb8g0FSPrGZpuLLKFcn9jZuRfSw
Wdr/hvYTgtGB2A7R8PILm4ELqxXIgR50rWTxLGEZJWC2VaeK3jTQ0xd76aKdmHrqqXp/EP8QeLFd
67Y5KC6HsNRctNbHRoVhcvseS8u2Bj7A01Q70SbrsuV4KHM1ROkK31ctJ9/+Du3xwAwHd7nbmBfP
wuIFCKc+jCFICYns2cPWyeCtmb3Dy6i/t661d0K4w5/R+nVoNXDqAXfL2KW6xRXL71ui75Xxg5qI
i+K8S8qBY45r7tjW89p9ko2l5BenRQM41pPoVQbEQrIM4Dw11OkWZgb1x+bBRDfFQ2YDcYRvDVmu
DaZq358pdKu8iYHVpHQwjAIAqKVEf+ARVi3qW5L3ih+gYqZE0xC+qGc2hISxToI/7pN3T5DUGmsU
KgcFum9pXEeSN7k67xQd0OE25fTrdGBautmOykQ23ahsQ2D35vYjgQepCEaoIs1K5nRSTXBWn5Wz
qc36GGMzQgSLY3AMESsIHKMDH7uzhyFYP5OncBeNYV+WwoQy1IAwqFzbsr90BvGvW00af/TCOTgh
HnuXe0jl4P8pZ/LOzUbM9JdSuAXmUyHTnfxQ0Hlr+na1PyKIiqDangyxOQT1Jj7RDu8D0/OG3tPf
4gf8slGQl3RDJUNCaL3SGNi3uebXSkoAUYfUTp/rUKTB1n0Rr3OwfFHT2FcIMenwcwq33XwefYot
dWqp+XVlrVmq4m6FiEH2GS3eC6juv5OoDmFXAIhWL98W4kQOYbYcxUiKV+I6ii11bBJMnbJSb+BF
NnUp5KWbIC/AomJqW6GvtLbMZx0L8yP3uwW/qDQFcBRo5MGCU3WBH/bZMq9CEboe61KGmXKTIR0u
IMbi8Mdk/V4iNFFBtbMU+BsPIFAfjlajRqpJRkrAFfyNmsHPutPOtrsjYrJHdkQ+W7JUbgQ+Scc2
xfVKTNyKouVi3dMxV/GmvL7xH9JHNwlzkkzVKzRpHXi8FPkct5XU+HoRy5X7zwjNb8C4D/I+NCb4
M1wi4ObqcYTt/Oq8tEErdEDjoerEiqQWHMxQxwsJA4ENFTHZsU56DO9l20S8/lwMyt36IIEVQnbc
09kOwoTswCSoySkwVlea6lrbc7NqOv4hckMMjT01WuFR81asAcGXCxjjtbxiMX6JnW/UQP1iFIBU
xy4+HFN56KalKyIee0aCzcTB7ddieRBtE1ByZRRBUMO5BZKU520MlP+YYGxRx1daN/dpRiIbAxgA
F+o8xhAAi64XDuSdFJVGsdJHKgCltZigsrq5TZqLI0l0qnhHblSw5bkemJei9k6WqMIjrygmo0Il
Ql1obvvYcEWY9p8mTcmvLhdnJKY6CJhdvYZxuy98PbT931XEdOAUg8Jt3QPltbbBwv7S7fNfG8rM
yveBsClqT72VIKoWRYX7vUQZR2Lqe2ZDnS94XBpwYqKbcFuagFzX7jPPNcywaW0aDLl3Ox2lOLnB
s+EmVXYgL6AbKCf3Bm==