<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzymE7IAb81xK/cjLw4JeacHLHPGAbhDI9AuDwqW919YJcwyMzPIz7f/litQkgADiO6bXY3w
RkDxMM094CO/ZkDQk9UDezkMNZ1+PCeNFYidtQ9WmsGAyMXXJR8hv1U08egRsh6xD+Q748okFdn6
Bd3YwO6vMXYS7fFu5/6fsXqWAJPFZnLXD6plAdmC85CzD3WPDoCqVSxG11QuvlGt+croDMr1WHfQ
7p6Z2j9mIItOs7pytEkgm8gIz3we7hL2D+nWQM4BibGvDFIXHeienCM7UlbYo0sVUO6f9cbGP8x7
rgSK/yYaoXXhpskxDfpA3dFwQFFORR+PytqeGFXXc97t6cP7y7/fN2nHczMrAf+chpy9hGkECXwx
E0wqBnzEC/UxroAR1JIUiN2Ic6zR/6a8coYze2SJWsDbboxfGiqbuLKm3Fsb5AFCY9j92zO+naLt
S/c9KzuGDE8SyN0jCol3HsIuz0wj8TFPkybqnVtMhRk4dse8c2Yt3tOlXwn+AWr9w7wy0cCLuQWs
Z7AyKXCBq0NIefDB6xPFt7LQHDvYHLlJzQo2nqJ8y0xF9DuZ6dfm1USZikAo8/K6IP/lYV/f7/KD
UiTwwCnnX9duYJBFpeRWoTezgP4AOb76WoEw6QHyq4pX75iUKTyAAFU70DuRzvVLcCWLYZiUaLL7
avr6RHeKivAPlkxq1S8cLks61B+G2ti4m/ybRidi2btu+Ii+F+q0dO1vWoqWZFbwvCdsheE/xdsB
aivB2gKRMT3DbgyW28LY6MF1kQ+nH4NkzHqTseb0VjJqueWLPUJP+I/4hc6YG+X9g3TRNd/j+GVi
2nET42kbz+221V7Au+CU0i8SDPD93rdJ7lZpTVe6Ao2c/1TxVoVbH6gxz4vd7iAcNW5XfkkTJI6k
gjvKnn9AjHKxbu7cPZRsNMKErHeLrccjcuOtzVu3ZECi6bAAak3fQV4Ug1PLggBXkOeHdbpWpITB
XNB7Z6nn0K2HK6gswbt8HFvkUXoHbRDe6uic8ZRPWGJRwgbqetK3GXUOCmJKYyqlQlJo6TXRa58J
rl7ZvezFvdsrUO/TIggG8KmOTN1Yh78SZPMBniWDAvvrm9Foqw/sEZSBlMq6ZLmCJmdQjhDWCEQA
DSdC61YOA2h7x6zddyh1rdHsII+XSmPliNYFPswkXfGqo4XKgQvSkh5NHZYkHWMM4dVV2oc7hhgj
UWIJ+avkfLSGgzuF3DQK+VkedoP/8rAA0byzWsy5Krr8DbcSgZ0MouN2BiwvAkkiL7VGr0r2u64j
Xk6U21c8cEpPvY+ct+yQKSfOaMNo6+PcNLvEIMbayf/rTGfpSI3EaheY+ixnUGvhyPNRI6VwaSHu
9ChjO9c3JBB38w1KBa7ieT2bVEbkaVRukJKJosZEgl+Gja/NZroLfwdpY60ovZMw2VZc25Iw6LrD
VidDa5grYd+8Z+Vo4eS9NMjYAB26C51lsINHrn3L4Iw58mQQBRGiQB0OaVI3PrJMbhK3jsahTbWs
nVffjn4AuZR3H1qRRDTXBzrGzkN4P4cJV31lNplObBvNrCm2EEMlYiyG00jrgFrws5w3eEJ/pxNt
H+JfaepTNOCqHHO/VkECZ7PNFMMCvOlltM7yAWKzYdDTtUTSWcPyoNsKz8zXABbfvv5Uomj5S7cJ
SInG1nDSD1e9v0uCrVQHhEX5Xp66EKHz/+wKA6hzAfpvnJ63RLWPK8H17gu5PI2gwQc/yObmHazh
0Db3S/fJE3PPoVyPjglCBW7FHZQ9uX/FE4mIijIC/q3MIzlDLtHd0arS40Nt4xbjDwrjhHEImsv6
0rhA+oIg/I2N1+c9OOuD1rLlrWmps3vfZrMe3ge8LTyHEvCtzG4bRS9XceLDdsGWED2Jkf582rdW
EU8uOGDmbFwxLxuahcXgXLY1WstGAhxlC2UPlQ9ykR/0z/0NyYQBYWlcdoiPKZ7C3B2V024dZ5U9
sLTKqy9oa3Mqcq8xtBNujbhRgP+zricjxm+x3XeHrFxnNhM7wn9lhgSd9n/jReEMeBvS5IZ/Ypus
pMqDsrLa5kd0xNjHksWn0l/sDCc8VMq0rqoGx16NcZXBMM+F7m4XqvU7ld3WS+atWoYU98Q0ayWU
ju4EYqq6HATTXPuVyKKKCiKFnOcYUsbcEO12mNAx3HZOOD/K3IITZKPYHKvfwiXcCtge8MwNnuig
k1vWaHqokCU1poTP6DnU0Udm3DeYx7hx/P1ehfy1hu1YoYdUnxbguTT69wVVuV6OJeIy3ADpJoGS
mhPZ6bXsifI68+qMpnvGy4a+5Z/7e1O2VlvV8PYnyqrOgK8XNAn/6rOwfkWuKlahESp1YnbO2W4j
3W4mzwNlQ7KWDHnFC6p63je+Zo+a7AuqPl/Z44v29CDxHdHo9tgvgBQJXLx9NOa/3IwO3ztgZmZ+
8dLGaOorRkiH1Ys5KnlNifLQdND+wG1034ZepeTHBThpflbVUOjZz/KHQXXfEzDM9VH5hnQ5rcA1
9TENsKhD70W2NlEhBTFM8VSA9L4El/iztz1meU0Qds5c7uLFpv/sRYsk3OyPue3BkqpoYiBRuf4W
uc+KJcuBtURngeEBHbc8hUKRKa4TW+jpD1dGeOA0QWpo1yi2hGgxK0DlOTEycJDuNY5rFPeC4mxi
HWjm2qqnHPH22l3wF/XmBFvB4aAqOvH6bbEK2tvHYjFkLuXPKm/myClrjJb3naYW3JVq300o8BFY
gRjDS9AQrKDhk69CLCPCmednVC9j7RCIhrzz4hR/aXGqtepkTGlmZEhc/hhLb6mYrqW2AeLBlrzm
N5Z7mEpeDBsEBdqMhRamoAWe9PugS3ZW+gQiBEzmk4CB+jrBQqL0Myr5IvojjzkhaZvGHtg/89NJ
y8N6XeGBDwiGdc2UgkfI7/sCkzaGDjkQ/e9AlirNz4V8Zp+FZt++0+4htmr2ZMQ5LBeqKTbwQgEa
j2WwzLaNAHUrAmcuJDI6BLRgjTu0NQ/YVV8XoJisNbz+dTPKQDNJH7anQ5r1WF3L3fevzpICe2c+
lHWsuFRvr0OfTZlyEcIKL3Bk2/k+Ri7qyPE3PHySa99ssRV7muzzN2r9/D4T7nHYJ+TXl30z+GEo
lfzU20JfRtzrY1W7tPxSXh5GNqXOs7riAzhADFfykG0TpoQsT91WCMqEcRCGvOwvk0uqS/vwoqgF
53JqMN66yW/XdvL3GzbE+mBYoEaN0hzEWVWrDP2mXaASrhkjHUEegfxm5cIKP70oga4Tcj7k81k+
pEArFUoeZAq+vFgVulg9QmOFyV/mTb8B3mdPr3FhqhHOa0eXm+3oW8So1r1ySI0T34ZpQoAMBQao
XDhPR6hl3K5q1XOoPK5aK+67CX7KYKmauJ5z+vQ8kaLFxO8Nywr6l6of9pDSClnsp87z19ADypg1
cAvMHaaU3pB8drukah/uY8vVP2RWZwn+/avtyd9ZRVYrqweNyZVrjdi24vZvy5aBy8/P/sn0g9Wn
g8+O4Cmtn7HgB/w/Ir81ouyNSl2ZSCWqwWCiq2aBP+z0SJaB2CLLsQObM0ce4in8nilirF76k8dt
rbs6K1uR4OPuf0gFfH4uShbNTgOK06FFMWjMZZk9n6Q/NjaFs5ZXKjx7EW2ezXn3EZ+ewHhHR+vk
yoatUYZarJbskN+MfFxrH9iLkY2S09BAokH8qniZ4UyS800gxw/h81j1IlJnZA/zOUW/SRAR5lFO
/bouA31k4yaWll4GBOv5II7KRuLc7NqYPUi9kbrBO0q97zmgZc9wD2CzMXnoalmweoLhSb68fr2K
2+bBDhKCHP4QM8WvC32FI4e9LtBSFhen2NrrUuvbrP32BFYQ6sPdZm8JyQVzn0kwtB4eEaVGO3Dd
JljKJicqrWTBRWWqfHP9f+W/Khq2gJ9wr46iOdaB21OjFHownbVwNB9A+9L4Ozh5YO6H5YvCleUj
arNnK2cE5hlr2pWhxuks6m3PpzVQLoSkzukJreQk4nAGgb7+i6mxMPXCpS9ylmDrUXoJsMqkqW0a
qrOdPn3ZmHBmTb56oDjNRyCDM0niIsHhZn/JAA9jKGbeLq3lBCcdkicW08rKBY06BP25TOZmvWid
YGUpirauAx/plpBXb3rp7t7y0Qr5iGDfl1X8ufJf2hHTYIPOiRErBaTbYm/YsbpuNbyk5skig6JE
D/SLZjQxr57GSfIVW+UghcVua8BeJB7+yp+K6uyDjwO4pVY0h9Tb9YlXz8TBU9PQdlr9D/UExtQg
ToNqSoQvHkDaufUzoJgRWpSO1gm4pZM+vRSrjgAc