<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzAoQ06m5b4tJNlz8WzZtx2uN4s+ehEPv9+udiAJOP6ZFjYKO1dXSNPmvlc6Ugj/k6+eiTdc
FvVQrfml6AS4IMYgHOiJyDg9DET7QLWllWnvmrvT9Vu3kbgCklm8YX95I1sDciSlR9AJK/QOqQtl
mixsc2Vpyjew5fAWoSbpQIJsR/trUInerkF2zT2Pefm2Gpr1tJaZG/vBY5VUxSg5hxH7TKjOu/N6
fbFuiwjz1CY9ITNB6pLuJHV2ofwm3hC0P9qUKFHTFJwo43LofB0Qo/2Mmv1lgIAoYKDyjNe40eEj
vWOD/q4QjxneE6vpL40P+9Rum1x+dAQVbo9DeuoIPIeTaYxIJgaVHkGeNl9HuC5wQuYCg+aDELMx
H1+zkx1mAp7r6dz86OGltU1o78ZAZkRK5j0fi2kLukF9IT/ZifWr+OiLqq11ClMHv7aLr8Zz9ga2
DhZHVrup2YZXNYbJfL6bDBU9mcl/nu4W0D6Ry9u/yqRhMwIUNyGiYj+xZ8eWbpN0xVi+bDj5gxKZ
8m9by1z2iDX8VLJkowFlP24VjhtENVlzV7t7e0DwkMq9u3zvs2TXwVY7C0WFBuyjSv5aCtuswtGi
pP5PMW0DR7uYuc6auF/EdgcIht/XwGdfIXzXHOezQ6LoKjTC+mZKxrxS56NQMjOGd05AXxMH01cL
rwd27Rx5uc9GHxLv7ZIVP8FHWkASVqAsOfGPqwu7tGynAjCUD+IF/7+Pqxqc4vBU45suFOGgvya4
dTFoeyAP72gqQk1n1i40JCxj37Rto5YsSWADO6liWoiRXNSMZ3+3Ffha/bhMktlTGsUGtIiphrf/
IGXfPoUIPnhuckSGSKFI4Xu9wXPsfykuyxooKCggzb2MacMa5sV7NEEgrX7i9CPqrJcNKMb43DuZ
CjgwyE9QzowBSDPdoA4RKFe0siw249kRSntUc09gF/svmIlAz8MbeCxIKTMhRlQL9BxVHjTNAorB
VYqsfZaDPDcT2YpBYG61ZwvX5vFDxzSiQjapahH1BuBW8fWmgnrzwJUDYGUMYEhE9y9VdUgH+6aK
NPzw6wqm6LERjYGHFu0YcCjWbhVbcn0eOygLzKUAnD7YG1dfOz1dALfF8ZCwveLccqpHvbwQB7nK
poMgT7y/7vIge7QH9bsjvg1aAL2lI21kniGWxRQ8s/+WHW3e4hIgM0NQ9i/y1SVExin/Q51ZIdKb
wsJTrPKva9X+EpgC1Pzt/6GsV7zYXab+sO/qyuT2uQUMc2O8X46UUnCumSO75e0g7ywy8H1QX6bz
9HS/ofDtxB6zU3zTdRjD2C4u/wzEqtDLZBlyj4Vv1LuPA2TIaPHhfDyAw4BLXUP3PlbcXUT2vdr9
78XnwD1EzDj2CygvLyx8XVQO3YmzrnSHqIQNJFAb7mqRiJ1kDzXkqjZJMsf+PZrzYJCIPLRSPjVk
QjwmHThELw5Keyl2zMvy2+43tM3vl9AcA7FIaDpZWlOdFHFxWx1R1RIHuspQ31hdIrhzIb6YSS1B
8Fi8+eU/HmyIWFD77BlcJhdF75DRD04cIfj5h411cubgYo84MX/U2VDC9da//dtOMgAsjG/Uup3T
j4CrgLVCRkW3MBRlKW0rQwv17IGzWEjqL+jr+wMn/7bHIYaHfi6HXeUhzsFtVZNXCg0I/+rXRYN6
DrrG1v8ctZL2zLyOro7CPl6BX6lAgXNxikTcj/ZeJfImrIEWFH3YsQH8zwF9XE18xBHhUr2m8iop
gkYzgAXB+4W3vx+DbxxzDgR7vFE8a6MBb4kmUqJH+l6UUPaMy5CTrFALOAzjrtL4U/UdHanTYlaM
qHTk4OGlxZICWN81cY6RjI1j7jwbHWhN1dy1Ti4pYUD7K4yr/0nUBBFYKVChjfYDiGGgUgAifkKa
rozbxJ9kRWlVeFhg+EbQH4CnKooRY9p4m0JNUDD6Ygn2j0amV5oDKZ5xmFXKgFMnWMr2ChIsT2MJ
i7n0dI0pS53X5FJ1bSySZcRR0+B4e8gueOI1CGTGKic/EnqMZoDNMEgVwTvT97AuwwS6KPkKEQ1S
ovaSohxHjMWQzLuTdTs+w7+Cr8UuTk4+kht3YAODxjRMfz0c8FSO14nypHqIDssgoAUU/h8Hx62u
62zoXURKnDs37VujUy5g+xK1AzFl5K7U+UBK9Sh1fV7M68+cgpYjJvOV5hwayts4gnKi5dxkxNsb
O+3/mH5lKNS3+6+3hffQOswFD22785YfBQmzaINxygybi0Co6lkLba5VV4jDuU0s+jHcuPj/kBbT
67FqoyiO43KhinMMsW3TfgUOGgOVJlaECNSNmKbRV/EiRPPUsKWBjxsE1bPAgELDD28t1KwBG659
ldnHf2MptB4aePDGrSVv64jiFOtDJymX/so/jsJypqLSR9aHMkgT3CNFSNBBpCDP+JKt2w/vlXTg
44NxrZ2p9w3U5l5hA3ivrkVnS+UoJJBy9RBbkgVBrWcTEkryMD3aYrkI3dSS/YXZWiu6CAnoTBVH
8DqtLAFBrfntWUw5/+F/us/5Koe+3IfUS6lUg6V9s/h0Rxu0FSj+REsuCaWT7d+1IwdVGMEiI71h
StUS0TB02ZTngunPdlxOl/0tQzWlc2rtP8GdwTVEmiIx8CGdfmoJ/0G/VGZondqkfn0JMsDxgE11
p83azF6pox6YM6/X3eSQa2mL20Z2etLLHerI189MEvh9+IFvOIerwKSrA5FKG2aOGcJtxG1HbX+P
SbOoixA1noUpx/0IHNMSAP5orqFYseyieusRVPcTWmqqHpiljy0F+K2Oq3Ls+GtvWs5UEabVhNP8
MKrk20IY4wSE+aEGybFK17JpfL+ZW109hQU3MtjA5T6ol+XlP4uzbZvgPcsCCB9nwJWpuU+20pL7
icpUh5D0OfiCpNLq0BStEuqkmB1z/HT+cso6Z4afDjowea1tO2NwmEhQ0uLyYfHYKu350F2WwEHd
KI0s234W8DQw2NRku9Ns/0e+bbwxGTfN3QOTGgpsEAKt4W6fUuYgLsNooQrkQ5BQ9gz8RU57pT1+
/59ipFU2vqj3/Sz2PtPiLCUZqMwzV7Cof3zPB/zRlPXbvW353J2iwrMOUfHWB8zCHVkwhTgWFTkN
t1veN8jqE/hTH4B14Ti9++lvDn9SIu4mQFhOB/hSJrm6wHVqWt+6SX0gWwN2BxTwUd9h/0nPkVd8
h6Y2mQcEfpB4AlfrsIhgil6ZvTlYdcAdducha/sSKEw/1TQ3YCVhxTxupoWOowgZM0D7zMieMxTl
Kp7+/27sx24CxFZcGf4+Dwec+BmnBM2RDg8DAn32AsHiVa4P12QYQa6+pLpHy9kUUcuR7ej5amxa
HJi5u5ynHomGeRTeTvbQ89IboZeXBSbcWIUXA74A1/68rQxjOmA4bw0SfLV8HNYw2qVp1Udnyera
/mqrThUO/ZK9ZPsHS75r+ABLuWFdA13S52CHzcaGYxTQGCyHlkcruFYAIkZew2skgPL0WHqgKmTI
BII8h1f3bkqztQBVAqr3pEXMqrWU5HLrVk+83d4zGCXHIGuwEU33sLtEiqqAZSQEOFPCTUrLI8PE
6DaITUFUMJzDrIJxoqDDsSBw8hVcxWnWdpa6Qjoas3w8Q9PIgTUsF/tA+MqQKJsbx0FdMl6TyS+t
0fY4z+Z5sHoVgGklV4MHoclMZLh2QVXTkt2LlT3K3YrNAjx0XQdtwDCRkAdg9s1XAc6aK59GlJ9d
szH1BK42s+Pk1dh4EBCYxNTDphnMDYmN6TV8s7v9zq7NTBzmQBDSakQMZoQ7IUnimbEo2k/IFptN
6KVQv6Ng25YQQ/aORkTpqF3SvPlNU0shpdoHO/TsC3bWgaCIKjREFf3NW8NUqvxXNbv6zZYXyZ8U
bDn2z5kd0Q/uLedJViUcNIrh7M/uloU9/t3vFeA7CUg2hUchviOCjIWEqatuR6wtpI8usSMJFZul
X3hja1RGU6jLDfL38T0/P7C0JOp/PPyU7s3TA6JtdWrPLehWYlEoJQitICxChhMt9KMRGASDEuqs
GEQcJaoWAhHIGZsv3veqhKMpZH6syqWM9Ikpktt5XnvYXVrc9gNYeFPwA4f/5zx6lG96h4/VmXi+
IhjBawLK7t9CdItASukziOZpMkZe4I4eHPL6sQCcxT6AqFQlX9TnrJ04nEqkCsLmbXAkquWQ/L8i
jpslPal26l96P+s5hCaKv/cxDc+V3Tap9K23oQogwtfoME+0z9f2p3Bahz+Njyq/exOBqX7/u6hK
AmzoDNmBPyIkCk3TBG==