<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzQ5yEeIHSdDwqbboI6OAE2iqlo7Nd+e8k80YxVgZOP8YpWNUZ985Or2l6FjVA4cARFfJ8zf
20YcOl3vmQRgpe1BnkdTBN2tYojtOv9ceIZ4In59R5f3j1w6u+T1tB0u9qEBQp7zVBv0VwSjMb5B
Mbss9isV+jiuykRksnmz/MPSS91wsC5S32VWUNVhHIGN9JDFwym3+JdBHt5z7/fRhqVefWtVNsE+
mRHuJK/iIBD0p9ibaI2LOo6+glwnAdJ7AsY2dS9LrGofFGIgAFG//w7FljOkRAZwKPwe77KYhbKG
g4geQuvfEPhu3vAkmjmlHgrA8eLfPnNRSKiahBqn61vxOTtEXY+tU//NlfxrPXGRk7L0y3XtvWqN
1/N4c/oEx/7x4kmaL6t8X/vXxhhFhUcyqy7eWEY2XM1Cx1lZWYHPQHMs8fnqyvWIK7fo8Qng5Wrk
Cy/AnBX26mGmjL5nxyV95eJNsD/INa82na8Uh+HTUflIYxi3SAOYkt0Lhi3JR/OhUxzMITg+dQTm
y/8jhd3NL5kMm6a/5WObeVJslSLUP3yCAGjMBLfXA+aCsyDtjHFaccsku2x43LRzATdPDTkgtZPr
TOcYdIYVvynTPMvN//dIwL6qG2zGiwoQbfRo5k+NjSsPaLjZ/rhi2sen+0Z3FbjSDxWc/pIb1jfA
cilgG2MjmIRjv1Gzp9+vegV5mnX7/l7VuiMQUig2EbDf9Dh/WIWfWQGjfbReb6RzBitbszpUxKCE
QJgY1leak0aEJJVmprpO6TNvRTjEGCXnCfs4MkGueuyvCS8lRb59tBCvalEQ5Q1K+Kl41hrNfbMU
C4CKOw3IokPTP8XhKzKzbldGyplq4YXbYUeP6nngrGuIrcGe/hj04rJ0E1fmEo1hsUEb3sR184/q
Rwtyg/KaTZ6Xk37wG22CnQ9tcC1x+gUOC5YesjdJN6TdGP6zAsBTdopbdHitUQxGutVbqAlmQTue
nOIk5cjIg2DUmEkvIySUj9AiXJbciiVIDIPkS0YstUscDH9TpbbcPRVDP7XxdbKl6NM9nmJTuilx
ssHKtLT6TpU/ORErywzJ238KE4FGiQfaPqhO1mzAP39dr+/T5mvr7sR26YuNO8ENNg0iWJlqaXTD
1+EN2jFJpTQVuKVJjrJF2pHNNXBLdQm30HcDBDXmtNxdBR06zPPw8Ir+rzO0WAZIjaJatIKxR2bq
zi/9hiAae0jTKvZ+8GzAXmduTC+zgUwW8clXfo1A2oJe+qYq/JtS9tiBlO3VN8aJ/VPeFxjDdVhl
1WWzDQ4ndNqrX0TGdaOvu6fgtYI8JGo2iS2WIyy4z/eoNW2JWeylMN7RAnyiBM3t8K3v44vw6jB5
hyWfs4Q+QpZrbbGk2f9VfIyEBlYTGf8MR/XYRolTO38blgoK/zYIIwsFsGIZ1FXMzLFw/DXT12He
ucpr18zE3sBb6J1vY3/W+B3AEgzsFLOqD5QtWTgGEk+SxuoWWPnnCfbK449Iql0L3UUBMKXv9Z4G
8bbd9vJ+fa5kiycJaqaKxP0As/yhgzNt1CAC7a/XOFGC6mf7jtD9Z6pnNJ7edCRyhjhPvrQGcLHA
bQUuX0+SLS/5SVDKT7daSEnpVN6SwXHLKcPS5+Yf5Axxz2lM7Ev74DIdJaTETqu9qpxD9MX9Sz58
8iSiV8NfbYdvaBnX8oL+79Kd/yCBhB+DyUU1Qt8j7L+eIoOg1eSnia3p39diqHGB5d7w3XbAJutg
fsNsFP/devWNYrk42/RB9QabW0ToHfxS0Mb/NIbG/T8q08orlPdIx2fdyfQU1uyzvkDVj42VNko2
Q0raeMmpcZ5HTVcIz0AVJIxGzbzt3AWU+cVbQ+I0yeWjzeKQ1UD4RhK3A3gx04Mqaw8jECnRbTD2
06pQYy1JU7Vt4VOS9c/Su3WvZi9LaZ4otxVT6RzkRKvD/AfmDVZjKKBuvayrIIq1ass8Vo1wMnLP
pmDGe6pqq05kVPFox1ktAvqmFttbR3WwPpK3VHKmjnyfUgg25yhUT6Kc2YClnbBLcL/lU3OpbRr+
9BWEMoH4vYZn+7XdezOZxi5cMhadVtT/Ku17qh+jlgpYVPTX13kW8e9aToKRkM/muHkrMTXdPxBg
EzTRAPdalqnsCy9Y7Dw5Vx91EultALG071xdo3dBFRaQ2HKM6seLyStrK769dxLHCpYvf64Nkuld
zx0bXhsz8rwYN/kx5dTjvUM6+zec7G3luH4WWO5gFYI+DKFo3mipBbBM0aADxaIWo+JEZWtzCj1T
hGPjJS4nCkNY76gmdPZaie25ctGAYR3HQDy/WFPZZdjbafmQAVYOVgAEGVp7hIjgG/8QtTt+uN8O
cEaXJVCeiIiQoLM2q11Ps+Bmi6vkFTdA4BLvH2EXUk2xEDIQkYWMA2lGpjlk/hHUkyN8lDEBbE7l
lwrLKf08Bnr6patB5r0rKRiDKCPH8HGfcX0sweIhxXO1ATNKGFqx7gx9vC7VZV5s7ZOaL3ILYoR2
wH14kMnB6cS1cRWaQzDHOON2s/T+KHZJLYAGzearKMxJT7GPy8JmaBdjeRAxIGilQa5V/+LsgUTT
Anrkr6wTELqiC1Bi+jJxtiSN6T3ac+GMOdNCCtGeZAQ3K4v/g1VGzuJ36/zR1fZ2NndkRCVJR+bo
6VEI4TAAxVCO6lqTdUOl9GAA8ey4aX8c1Wvjal2b3T1YU/uO7YwMiPs/ReFe3Y0Ii+hAxXWI8BRz
ayib7xnJDTqg9lB4vLgPmP04BzMbE4qpmU8MpTBYkxQQ2vS=