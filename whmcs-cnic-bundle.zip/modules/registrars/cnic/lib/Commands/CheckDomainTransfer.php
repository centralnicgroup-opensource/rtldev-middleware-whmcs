<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnNGIEPPTh7991pTnIrS84SHte1QwktCw/GrvQxitLctZdEngAMHTbhp4JKh7/lvY6jNfrBK
LjP+tIyw7NWIbeTb5bN0c+0AzODxdr+qtj+UWa7LbNb38s5danO3c17CCqqINbohJ5RW7JwmaAMA
PMdoIO4qklpCwwy/3yqF8fE94st/NDVW4B+AmDUyBfwJw64thqMHOImGsdYRafwDPaf0U8NvuYp3
mpDEFlKGOmFY38s4kiN1y2ohiCQsjA2ZrrmkzrZwRhmuno3jWo8BgGYcapA+QrRIU4iYAGGboeoA
yRI88lzjyAbOtpBxW0dSZwT/1+MtLRfnaB515x3H/mNqMsbdmMeQEJuvNA/kGyxavBoAIPdO/OuE
M+P+vh9fpQ3ME4e7iBwk40Rb1rbwMqGwp37b7bmiLkJMo1AYZTBe6UY42vK4uLFCcNA6Pvp0qFn9
lhUR6ExZ7sjXMhlnzAfbmW7IR6A3boDvNTlZN83lJ+7feqTjqwdpe4rHH0j4OzpRDOUCqmgPlyNC
Jn/TIGMiS4oOoPJU2yDbRXFtzpPu3k2iV52+ZQ1dmOwnu3H9SIdc1gku4K5VIOhof5cMvfMIIx41
VaxdmyAbKTGBBkoZKpGOEcvPHLNBKxsr9mWvRYMgfDyEZMmNk1Yz+QxeljA3av5ECxlGjpE1C8KA
OD2CBZE4wQ7XjMrmwOvTc1CqcwSwwwVaiSdJNPlNu1Vb9QNVeDc+pS/s7Lt+21+grpHsB/zYNstb
oKiBdDwJIGvWKc1vlFa85GsaHjXcGsv7zElZkGk4W1i5s10XprgEDEGRxksZJZvxZRX51DCVaIBB
wDPlr8vj3t4hMX7sbHm5QIsfntk33FxrLLQDVvME1ewKyFv2l9A0DpJxKeYfSdAZEiWefM1S1Zyd
zy4l2umx5KKdw2JD92xiSKwTcpgLp9lhxESTTP1fYx8JmhV66/rCwcFxfr5jeP+227lo54OaYgPE
WuDbkQpRfJAch2paSO1nZlPQVyiq3/h3/iUoj7hZG2hvnNW3cb1FOQmnf2MrgPEOt9uKP4N65UwY
dI25IdxR8bAdE8tYNVfHGpRqJ5pmugElAybf30yPuzSQuxxZOVRr8NEgsUu4zr5PPiW20iNb3hmx
2hfKS5psL1WE2dJfsipR3WBYaI2hOF22shtM9mJo7f80liF2B0wwB8MzovSGDb+07jv45MHJ/+7k
cFav5vAH0rXURQXRkC0qNbjVrM9KTdynxNk+OuJQFMHjLOCAotiDfVnu26zbY27BbYEtLB0YjkoY
KapehdBL01wrznde1pyG6mJbzZHEODi7LSN5g++8UHNH2Lg+y4g9EWub03ASk0ml+PK2wusCy9gN
Tl2STh7x8F099NtNVW66dnzuztgrmWzl5GzXe2DE39Eijz+fFwIpFuQzd6h/J05EfBlSI2MKza3k
wAV03YxshMKE4AyH3Pv/QLVsakwsblUoGRpAUd8CLMM/xwC5dnRLpro0+ztUGhn0rmweYE9q7yMo
coWxT/Uo+zRC1nnpCSQRE8ImUfpHRaSZjmAtb6w4oVpIzxxmpF6Ko6jaX/5IOqSeqejNU8/DN4eh
S6DtO5mS90Caev7HpQ91QdFYouWsIHtI2QeVSHDZAXwlp5PEgER1bXdegH7GAwByE7eQOZewpZfI
ygB6WbXFpd2zVBGoXZ05cilu5P1iGs4TrfIii7jVUbiZTqUGGSyqJRxxJgD14A82rokUZeKvmXjH
2p8AusdBljYG9ctOplJ9spxdzUmqTHaYp54NzZX+iCrgdVEtR90AzwskLz6h99dQXUxFsIFMfAaB
AhGdSOUgB6ijLjKRermatKMiuJU1EsSIyOyjvs9TsEFq+GbcXYOL6WKB6qptt4qcL1ruhEdA8i+5
YcvabFwfkaB/DY/gE1QJYxIHoHs6qh8ZfCurDK79Gd/BUFAx7vN7MGflh/yLD5TKRfCYVKWD69wB
du0d0rKzyyX7g8960lcEQgbfg0VW8jVpSDSMTuXwflIDv5/ajyR99AUHlu3amtH0aRHX8CtYI+jm
ij8oZpvKopTQ/xDjtFoUU4zt5ECgQKEnWQ/z21zVlDv368qS+5uIirQTfu0XCuRshtqloliYm9J5
IhxLLcLhp5App7I3XNm3El2bkt13eLZuOhmgTYw0Th6HhE4Os7B1cI0t9781oTmxBlMk4c6igfLg
ap09aa0F79joPdThoXe8tsDMVdwTjqFCSkTZ+BHTeSRI61paZ1JVIxb9Uoq1S1Rp7sQP4u43QUD/
vjk2tnoHIwQPHx0kHX3VPadePC3BdmruZcXD5HbT4RMQS/Q2qGls3WW73rw0NEiBhHgjX9cfBx6Y
iWLLrjbR7Nqq5G+mFrniccqYiSJrCFzhdTv3HJDKQI/tG+XrkGAH4X7TaxiOkYBMUhnhA3fcYVE7
gi17LEbl++m1Qq69zg6UbXvKYuAeXbjsuMFzsQ2mDq6b1WYzrbyFXyN3wTmoj3xO+uuNTLWpsbyC
XnneBMcvBntaHFgTH3lcxTwHr974JkXQkrqwaji5XNcbSDONlXXBWZdyid+hLDomXTgSyXXkb6q+
OUPgPEFMAW3HuF/nGxw5/LzKQNpe1ImnajnL8RBpzVhOZWCDUoMxSfLYKw9J5wd3QVzRcjnIOCUX
vBssbY5lj5/OyeRMi7tyBsCmsDFdKK1ZCLs8vxIgIsUqFub9M+Cn6TqQoDLJWxXhskLaByc2XmMN
81T019fnRJTlB2PNvgkIN6hky4eKdbIxO76k5OgHGUDhAkgXbUVdvgmYgLohSSe=