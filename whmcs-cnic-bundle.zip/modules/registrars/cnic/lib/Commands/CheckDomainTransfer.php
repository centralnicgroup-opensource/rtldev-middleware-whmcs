<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp6pqu1q4oYt0Nz6em75FrFN53J3OYehBiScCvjq+NkowGWtNJXBrL1W5klVJteR5bwCuEKP
95gFUTF1qv3MA/FzVijk6IKQTYe2+w6jTayOcqGC21OO30d0nDsAOs/UBbXezoDlnXT6PAw5qivm
9DNKw68WcNdhomubF+oO60BXXvAadBesNs0HOOmjk3aagZd59SykV+AtjSbHrF3KshHnXVh2rN9V
ovxzgsU8d+tGhgp8hBx4pFX2wHKrdb9JLBKISQUn/sm+6jaDV8eQJ9i6CglDv6SN0rywDE2jHj7V
3X8xvrl/BXAOtxcPOxVYGNd68SebRygHoC1uPCQtWl3WIPSsT/oJRPAyqWq4yn2cdFoe50RFlTly
e+pY3DpfeqX+lw5WhPNDNwfG7QUtzIFdVeEi4WvQpteUOfnr2OU8ldAvUzrFTGDYTwX7R4GZfIth
ajjjzS06EL2R8wfe6I1pRKTUJKsb6zRkd/ETVL4qR4B6e2sTUCfoGZNYCRLSj+3cAF6g0tMhJB30
aWEw71na14HxWoutySsQwcuWIPfqfBSIWqPy8nvkDj/1jKClU9NvB0zDQSfTYBaD4+TbPIjEp68P
GvJ3LAi6b8NheT54N6/ViRF0uJvYeV7B5wMx5/n6DuPaTl+xl//nb85xIHXKwySVQZtp+cP7XyL6
z53Fb4SN8U5Fakg/LgkJsrU75tsmrtsGot3T8YsATMSqDPrLNOyXj0Ix6+Z+wKTQ3mfSonwRE+6P
UEoz0Pm0EaeiLvBVs8jmK//UbCO4BYFWBLSQGn0gTll5M46E7PLTuXi4gbQwOGGM9jGOeKmIMGqJ
I4V3uIgfXgTOt/x2j5Iv7Gjb8DXOnZ+T+LnhaNzJIcq268qRO7RomKD609qJDOsj6fXO+R80JDvG
gj+vBws7Epcw2Xi8uQ95YmYCyby4JS4/Dz50XPEtVsu1hCoS4G/WP7Kmy68fGGK9RKZ9o033Jbpx
RXP2wWjSZCkVCFr6LZ7X5PwW6rLh3H8O+2LJ+jHnNlNc1pW8Fvfl/Z3zgZVzJ8d0IzCfwd4gJnp0
XjHnI2CeQ/d+Zq5yezyNrtfPK9j/jKAFISJa8h/AIPswHiDItm8DhQn89g9UMS6ummUnnhC3LP4X
afmJw5Wg+9dE53c6OlLwwEkAFxvRWhhURUZTdGI9B0KqdBzKSZyUY7QYYe6eMAWH11h6R+1RXLTV
dqbfq6nMKUVZnBUJkzlB4rcEWJVfQBGdPEV2Yp/mgK/5HA75uduKhDoTcVPmchnht9HhLR0N673Q
jLQNmvv+oqyNgM2wC3w2hvASwffnniHFQ0jYdL0WKmcSLxjOtWqUdJgTHDAob/H9ZYrJwjd0XNy8
UD/xL/Y0NguKt42IZMTyFp5brY1IPjtGRMDKBh631HcuqNrdqC79bNEhJGzOxkdZ3GA1qPDHxE+9
nCALxdHXVcPqK3MwkCxb9ZKwIeUHpPopRA0bwTf1CSnED1dcIaWUZEgnYxFtVof1hQkYmvsciiMG
rRrXb1x3RJMWG97Nv1tHyI4mTxN421enY/KzjhdzvQLg+F7y4xBohqHs9CivwXeIcaHKXlbXeNMI
h0vEkT4LU0IwzTppLjr53pJw17HAXrNSmC6MgyHJ3lAT7bLYzW+kfPrsMHcaIxumLJsWnVB77Xsm
RgCEV0hicWGRQl1E34vz7VzS4QHIoXeolSbr9Rp/JgH7e/ZK+8f115+fJuzb2T2yX/q29AJYsnTD
75kT/jark0kYGV3RwJTeFSronpGwNl55njtEceBBDaBcedSGQpN8TeLE0v27x3r1pM0IULV+bAaB
lQ/zcFv/6yo5mHI3NxWvSejhCWl+Splz620OySIT2DjMi1AhU4hqarC+5Wnx89YwyJAb7Ni8YDD+
UhIfPnxyjz1uzb70zldamzJhJiHDVBBfRC5IqDBVb3qvpGw++EnzvUacso+vMYmIvX7NV9NAGKVd
HpRCY1pegZJyO7ToUmalJl6oSw1/DegNaPAyWA+NqNyGldDeRdS7EkFFE7X1JYtSIhsZsKrQQjon
YHX8DOnOvZBMVGFVwgDXhoUcUWnKbCDN+u/fTLOkP2x6U+3e2NRYYXBwxlDv+bO6YFYQwj+ezaFg
Uw77bYU6HfNcH87TRB256zf4fphkCOTVGiiVBOVUSRfJre3wFLP+nCACT/Q0Az0ZOMn+ID75eUlE
A6e6bOTue9wA0ixpNQLRQwYXjLlfrgM3cM9XJrXw+Z21UHfl2yRPiD2tyVYnvdP2fQU46wKtlfAK
QdZyPcGN9YyG+7phEwJEZSh9sVA1Z59dnk5wGgyAsszECNDj5+Nv74QmrGug/u5Zrf/HtsnxuR+h
ww+hScijIYFC+pcwtDXQWEt4YswRrPubx9KJ/Nyr0IWoyb9Cp6UuEUK3PA5UV7nMTHQhP6QjSspf
eM7yNX3LNX/N3dalBLtNnH6mTOZfLoxiEPjgKMB/b8DO+KMzVdsQ5Yt+v7dNVR/Mjk+0ji/e2OBy
lUjawLyElhiW0xxxHhgH82CVP3K+GwIBNpCuAD6XjpPm4yruREAZJEwSlkQKyzjMSGgGBiMGhaNe
9QYXLiUEJq9ZiuRhZNBHDxYJybYtLv7ynKkHGd6MgJatov9HfE+4te4ceTtKCYX8N2gxS/8cCjY1
npHY5dWE1u3Up70Obsi8V3hZ9GQ84kJoy81omXYL9lElXu7F3X0E6a0hLl70sGG1lzZpL2sxvWQu
52KwjWh7cSFWRTifSaxgyI3wccAkZO4QNux822ixyc0FjleOZB+BzsoWJAztx0==