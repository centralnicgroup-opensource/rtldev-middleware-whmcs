<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmmMYjahj0uUCjeV+gYcMlZYQVK2vUeMZf6uewMELvHSgwBUNHdbMCbqKygcxPavPVYRY7Zs
v85KASIVrmOR6jFxtF8IVUR4kw2fYFTRDHq5jXlfsHbozcgNGXmzizp6m4tRLtOXOedY/kK+gFqA
RwU3e/24qZRBAK96sgCcxC1AHzZGwTBZZfSh+LR8Zv252FiLnXQo/o4Z4hpVNfejIr933WUPWX5B
ai/8w6XUR4Wo/lG9aQz8ppWx9tl4hMiWFyLCnj+7fmxavcCZy2lxBYlnlZ1lvOclYO5XrIewFO+2
6uSR/uqgp/JWAM0DDzgaiDat25FSTtMKkdJUQTOfLblyQuTiafljY/+9NKiiwrsLKm4vFvJJpcJs
sEsrx4nC7yDW5kZDHo3i72dAnLRD0UGcqmSEEK34//qdKRRDcdx0QAIjT2bpJqOMtYKqUDzYxPax
ydd62XcOxg7DjnPQa75wJXZmDkAIf5CS3QRingbGS0VYmom9yI+kUbi4L/nnZuSOcGxxQmF6ZAcl
OIopGKpBM5eKzrgiH1VHtffFeUePvJws6yWVH6EQiLw/+LZb+PRExUIENiK4VqMsD824obTMQx51
KDKSC7nUA8mOg53vnETSIN0HhYHYJVxKQ0xYH0oOm6B/yHg9Eapr5obydmFMvQCIgManAdLmRNfJ
SZJR8U1Yq8VBLU02TVajZjq4J/v08fn0VnTKftBJj3PbRpGmhRW1jJOoCEjR0Riw7uhHm0PWZ8sv
bW/GLckDOB1nfrmnXrtI/CTaOX3UCotEh0Zm6+C2Fp321e8LTDv61Zv0t7DQlCRrn2H+EFv/X776
D64FS4sxbl/T9AP3HQWjAmO5+M2fnAcAzKHFRw7U03um/uUKsQ1XjM4ejWmmmJGA4+364qJ5ozuz
UliaPSobvIHXGyZ2kQsnVElqC46aPh35iNftOF/B5C8KjSH7ucjXhkOALUwDkgju8jhLOHmA+bKU
vcZUJITcLXPHmmioGajZ+927AfMFphzhW5XX4Ob9xDJYh1a4dvBaFY5W7BYDhWtNAke4+SixtfrL
KSrbLSUfMsgHVKDrGX1uPwtlFo9QuKyM01C/6eNNI7ieglfrBPTeEzozadWmRwP1htkkuA4A3T8h
OBUKg0iq/8iuDRkDO6HREdWDMOiDu6e5y0RZg4NYc6VKvPxySpHfi6mMR8fi1USk1Umj5dEbi3rT
jFA5Oq/AmqSnQV1KPib384bn2LXbDVVVwiXwuVgJzQosxg6TC5XEJ8mlGPY/HQ1uYTNQJw3eb3XN
TdT3eO3ZzgnPBpBayGnOsGcDDTYu6NG6WUVxlrlJrQ/plg93/+n/enfXJo9L7axPW4YCaQe7ZRFV
O9kuyDokh3/H1QIryp6jPu+uE5Cb1J/KtlRHE6QVaZiXjR4ve8WjN0gYSM240Uh87Fvz09gpI2qn
uPUmfccHWUPHXXCJy7xot7yGofyA2NxYCHUfpR/3WWqHWzNo9BW8tnYAzDvtUgI2IRumHU1+ZW4o
GTauCHE7tg51Nta9Q7iLIzbMKeM54driuO2uN2xyWpt42k+Jsw33APPu/7Jcs5DEqL3nGkVJMTVG
Tonxqp8MjjfRPVigkQedcawuQQptoKzCzZ1BMbt46VapbNXEEYt+uz2g8Z555nZyk1OCoXdNk3BU
OHAS7jBadHA/tyVxZdK7IKFH6EFCxl3+XwBS8QdnlNbcQZY6LhWcwW9SmmeFQ0w26s2ht2beUJg/
Iozd3JgDoGFbW8Ftbo4n0XPcujVkobXy06xJNiGJHlM5KnKanM6c0bm51RwMgBO82lGDhL3hBDrZ
Kgt/iMBqBgyGPZcvzrvI70Q/I9s/5LbcFk7Gy++F8R1IhvNqepl31piecfxfdLsCVyxmZuLhuG6l
XJjdEnBjz6MO1dIRZZOgzu8SXzbMuQjIyHcSCjgIQ7a/tCX0+MOIWly+Fx7TSmguN1ewetqEYkok
py3v8OAo+5ELZ0N7Yo+g0Oyoq+siiMq3Bo+m4nLKO1qgWTEF97QD0FygXZQD31VdyUj/E9IdOZQp
8rtG51OnB284vmPubJ/fbYIood42irhSgi225b+Mb9cRIlFHJ8V1btHa59YfqsRA6xKJrW95rjlR
/Y71BBIyxIthB9gSSiQ0Vsfcfcq3M5nsROStwisa9CcJMyTocGFHP056ODXKMHjeLvo+gkbHKQoQ
NmCJBn2odRQRiP5ADP4CswrGypMny2w1CDt3ACdypcX8k6fWDMD7aj6lXbm0d3yU4WKq/1yxCyJW
YF1mB82gZk+Lq7bRkXum7rYXjvTCVdfhwzQFhXS10P6A0RlSXZ/Uq8d544ZeWfpAZoH0Oc+JSkhv
BqErbZJHYJs10eviKWjW/z2ShCRuhQcpztu9TqvXd/lbUgHMXCYbYPs5HYmtve21o7yzNg2Alf1w
P9Sm4FvENukHdQyjCFboM2evApi0EqtFOLDAjwnEEz5naMI0QpkCOcaXzKvyghJ2PFL4YvYmxkSe
G0O8l0DQONHmRU66znfFSqvyYHGcYdqN95W1XgjYOwszFLvR7bRBcvDbzml52CpvIgEdga05KnJm
oDzPLnweQx/6KTf6fjSJRZXMvZ3W0wX/zkeYdBwhehFP+L4DUvYCAinfA75CNHS+F/7MATju79Jx
UoAiMIS6TDEHX/1Pd4IYWmOw1txxDY2WAaRHTG0djiD/pRfWjiwGu1zweiNgV6ya/AMwEWVLqGsZ
wC36WDugNKH5XZ6sKTtoiao0sTLUq3lBnRiDlB6Dq8q=