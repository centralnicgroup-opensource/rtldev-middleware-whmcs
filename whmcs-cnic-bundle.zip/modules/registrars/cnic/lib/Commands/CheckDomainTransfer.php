<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu39C5gdcOcTlWMbUSkVBhXKSRR2olEvgQcuPSLN8GRgo0MaHST1ilzuwBvv65r06TAwv1KN
gcVvBXgtp87pNKVhgDV4QDUjR9a1EomUSQxrHIQ478R3lj5hA8UioLreI3gdR8qfSZUEL0sFUoH7
c32T57FSYbHcPVO1dX0QuT3dfO0EjXyuAPUqwFbczZ1s9UaCZrv+kZIoXl+nRzqYa5NsBFvs83RV
ev1dlzL+EsefG6pEghHXYsBa8W4L3PQEKXfAKFHTFJwo43LofB0Qo/2Mm/5dYn6OXjNVNdTUseDT
BETOC1WmXr3cLKKMyALc/yiZeQwprfBuDmSYoVuOuEfBssCA1xk+8n82Kkm4vkODTFaNn9YQRivH
EHHGqQ7EOpvLUAJBvz7KohbjW21GJrDs/LheckX/k4XmbIdOzg2YneBBUivXz+JjgTlrCm7Em7nN
UOuJisQb3lrFyQH+gJ2A4rdTyJBwRin/wlvmr+5l/1+UKSh/iSwMMEAPRvuvqZxGqgiHHkBaHtso
jkvA7B+H8UuD1Wh2KDrC2cW4XBEkmExRYwfbStWnSoi1c84c1KPe3d3mXpG//slndIrEmXU2Td9n
Z0D+wrOY4gFp8bZsWEZSPqH+lXvTcqy//jhe+amCNHk12Hp/mWZBaoRnxcx8p/Lo0nZsIeC/V674
T2zA1uY3wFEAl1JlbLMpQl7lhB3lD634Oxr39R8gX5d27UPvkQpt7TWdheY9CTNxnupVablrGKBX
xEHgRlOH7wiHRSGlaOrsYPDU0J8iUlqYQsaEoIhKUaz7DrCxdh7OEusPAk5S6Kd3dnw4xv1RkQmR
GwCxq/Y/JgGAHPpwppxd3GQsVPjt3A/42Ysad19dV6yMfDAyVFronEWNW0Uw4HAaW/0Slah2OHaI
J25+7iYsL6QqgwBmyvbKBcDMnS+0IjOGjWvRvTsEoW8bkj/D8SBtisraAs57VvHh23CaePaVyDe0
w/VJhXeFUACrOwI10DhmsWYBimZ8Xi2nYgR3dMv90JNGnGU+0D4oN/nPZP8ESDEnBXeUhdue8/4X
SZ3WfdiPpYllubQRqvVIiEu/xj3OtwDvSSl/kiV+FUFk786GXtzBcXUijMfdfOm4ulNP2K6Fi+Sw
vyUxJ0gymkyc4GqlbnyML8CVmS3zBmLT06Ns/2qg6YO1KkkDiAh60bLnqqKxRO+2vRQhujjpWOVF
c7z6MuYwt7UPYeSRd5Kjm9vUC1VGIW24pObw2Hh0024hwEprPjBZPcRFvH/C91yuat5oUiBLbjHf
E4+XtVLTt9B2zvyY+UPWT82KOSSIG3ez8S+N5tX7r8xrTiR96ga4/ojYmBlM/0Mo4FzCFwdD2845
1rnUQ9fmf8q43wsSFJcQOd84mvTv47THoW3oC7nj3AjUeSPwsS1jYk1sX1UZa/kwBfiE+/OByMjM
ekAjmU6NUwJsaU0+LOq74BTzg+hPb17U72dIe6wOtKLTRkM65bySsvWaFfIqh7iNHT9gW46pCdnT
p7vJAu4XbWmU2G5JotyJ3Y6R7Dl0lGg6Ve6U0zrzEZ9TVYS3zZMJ2QBJvP6zQLS3p2AmTmxrjo5t
8aPBkXTVylqfaeJVvDpzDbKlUCtMULo0O7Rxrg+h46mKzM6Z2z2KqUJT3WGQ/lJ2YeBQ6F7W1PHc
w7h6etf9M1n+C4F/ZT3IrLa5lsuOCgBaiPPi9kwJf9HdYczPBt4SU5EwYeukwBSLQuupCSKLCXHD
aU6DMpBFiZs6O7GjdlsD3X2i81N+bCdLh0mX/F2l+JbuVYVeeTsvu7p6gVp4y6ADu25xIdthhhDD
vRjuz9DBRapG3wvz3R56w4QRd+vz6VXg4McOxEulBVz7JF99dLUxboKYAyk92GT1Y3ZEur+zVIRL
crNIgm+WrRd3nv+BCLB3oqE/fQd+oFdDSU+ddQ9kQJi9zoFam+Eo7fiKncE6wnn1tnbSTQJvPjWt
ftf/TvM28e96ABh2nemniNH35rm/+fWrhoGOkFg+Nf8n9mIh9Q9R2okCQBsCP1INWDfaGSeiBqVw
tFPGuCBLunUmTpLJMDtFX4vDqXJEXTh3kff/YvKjqygmVYEPwjkNekH3jMTpdtQC6zkH1swioxH6
si84Ho24o3/ifSKexr/cSe/6XhtjPsZToYu8wvPBOK683/TY4BTA4GagK8xk6b/Oab2BGv/sWRri
xDlDT2rOzyMdakhXA3VgNFHKXAj81PMWYNDFDzqGhPjLgvffazT4PiOYXawrAeGAfyEWdw0E1MzX
O3E5Thrd82+f6wlQNxt2zc1f11kyThIlu6ZcN8xnoYKtgAKNwyKeu8h/hKf5yeD0Mrd5hD08LTWS
tKyK5ADhNO1DrkDr3bz829ja7v/wIsHbY6zczbx1PoBKzA/pRJ6T2QXp2GN6cSX55e7AqoNhuZcl
9y8N+DZNfjaki6kjLgq5RjHEwnx9SG8rPSSShT/FX7wjQLDZ+Lf7MnPMueimQt5apNgR9VYG5PxU
O/RbPj/Nm3GlzgJ3fpkU9vyi+MCRAK+/lhFbm4A++Hc1Kb0qbKCmrMjNgyh1z0t//YBcZ4kGVrkk
vXlbXe39VaAxZAuHmd4Ii7Rh2pXiZBGJTMHBI+rE/ZZeyoCqttKjDsQby1jQAm2qnxRK4q/Jf7XO
xnCnOOYIRxalyZ8kcWnv1EGjrmyQEJR1Nnbu+6QtCGIYzYVHhoZMCM7BaVl6/mqaKn4QO4Ao637I
xXqGEOUDamPH8144L8GaYRv4D6oVAHkwLlgBln6d1CG=