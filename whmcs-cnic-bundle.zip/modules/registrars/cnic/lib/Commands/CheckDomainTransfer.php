<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuzvWKsywNbYkRKKRbzCd7UncHlSrl+58ibKDFNYa+1ICXDG5Sj0sykxxzkTUbq8onK1TUhq
eBdpdBmk21+aDyWl0/yBhm3B1uzewYHzdLUIqS4ffPhnhYXrzs3r9GWdReOrmd84jTxfSK2yv5JP
qG3y0SUYOE3w46/dzNcT3WUeahPEogn+MFe8AIKIysI0eUC6BGbmTYknE/LqpzHNqRPrtiD/AUGe
LFUsq1frYTCKc+80Xj+RiUtx06+b9Wr86NJIzM7J7gppYEhJ9G9xXWTad9nBMdjjDny7YVp5BQsE
nHX88uXpMP2o7SddyAqoAVt4xin3oG2LK4oV4nU5YspMzq5j6IZn1y9Oc4og3Rvx53CDceDlNGWe
nkdGdrRA1FkZSEr7B1KZq1skkbEbJP9ZRvGbQ+CoasmCZl5glIqKapig9lJbZvLwz4/pvJUGkTvC
V33sPLfz0dqJHwqX9zBj2ifwpsQq9oMWYfLUVjiv5tuRgX8o1bcL2FAKeiM+w+qtm2mjajfVX7Bc
0MvZP+fm+apiJIQIeGpgKs0fykDHBJw8drgd7y69cVFqJ2I10H1Bzqs97Snp6/zHI4RAEIRiWyxR
p2gH/L77US2gg4IZiKF5nzFzZALKjwv1G0TmC9usB24RbCx16FuL1Kt/IAG16ebsxM7sOH1tzZqu
OIFOYW7bY6r7y5a4Di/FSSWWdPIKHBEgzACKU23KUPIARVXHK2+CazVo8fK/i2zmA1vtKfyWP7b+
gWSrxE7JngaEEhiCCtPypDrWeJqRHYItxaknN9ZjTTvfBdB36CdAOcSCnnlJLWpwlmIN+XTkLyog
TmPHqzZDtT3DQhw+6EeOZC+8v0mPWOWYS7eA5j9kWHQB/6lwC3ETEZRn/hHEuWD14xFNv4fhIJBe
YbBdwcX7IHjL/Pz6ASI/+SZbtj1mqcN5K1AM7LBnS2R2UpSlx+V/iLIsh1UdzuBT8OR3b6C7hgr/
T8N1IM7C4fbrHpU08Vzl9q6fs/NfXGCC7hcNnXylM3ggvpium/dTzWpHlT1SDZ1/M3SxDvVdPlm5
EWv4YZYCRzaTM0ei7duFK/hxdhTb8uImPJDOBpOPAF8fxo6ONhe5ExgFvZi4vyeICqVFxaIMWL+S
54PGmbh4bX9FZBXFiL85FaIX1H/dPvG0NjU7HDpqeCM9jCKi/51+X3NS6HTSGlEdq0z8TeCVZnL+
hjuIitJRosN1RefgRAz/McUFvGjUqbCIjI1VSNhdZF0ifRleeBRJIz5LjZb7u9GG6q4crZgwRhII
xMl3nN22DIq3uC/YN4iS+lDSDymOvk7BrhaIwRae99wWIlFjJ4X/i1WUKe6YQNeXOJ9JcglPUGho
9Fruob+AMLvw3PnmvEL+xx+CesaZOELrZtTxDELKaH/iCwwAL4BB2XDLUBT8TBfcnyVKpJH74IGV
kAOhoUS3wvZMzjcUeWaRDY9jD+Mc+icA3ZaKDta1UmFK2TFb9z366IqOYKqca3ZTLxy8lCllbZ72
UBKnHtBVC+hOvVgJEOF/d6ffr8Ks+0Q32xflAhb2FsKWKtbWYn+oCyDjYfflpMasel5ZRQrpDAfd
2M0nprrineF/RzhfxDtgV6mFe0WpnhgHjH1s4kqR2Ln8aTHHZIGBxJG96T4RVToPOd7GYz89mDVL
XUoHbSDPcqmps5vzFiniOfVRVH7/GpYFL0gDW1OUM5Jf2cguFHBxT6gJqGhNhunnlsbxEEJPk+uu
MIT2SDps8pIqw6keLYMpdQYH9JQpjWVeCSXnVvVbPSK2xAexE9sMhY4fakkvfbK9GzafUU21tB6f
vZqjpahjoVO45UJeYVTaQICeqLOjodMFKmTcnyhgG08lGKWj87+eSzwehoxeoJ7h46EiILjrsd0p
3umRswkS0aVYmph9CIat4AGF/oynM5peY+xXuLe51h8WZT6tp/oJhHvNUQZkuvfRjiMgooHH0UE8
DqiR4Cd5jrsKRtHrMrddoJ9KUs16vsCDW+Ph8sRuVre3TX+ChYq/dq/pbHWeNc/kLiO+iM5lsk4w
81Ei/wdj7NIR8/SAZCTn8bDFRAWkRCHbyauj+uFP1hPf/ky0MYgK0+M5IcFeVhKz7ZQCfUDI/TkY
IEvs4B3T1DZrcv+tZDDMMLHC+OaXS9aBVooPH9b2f3yik8hEexlYpTJnqb4UKgY+QL05jS18TcLG
VJtTazP43gxRPSncYwME+Wt+RMqUAXt12gjuZRFenchqCKc4xxOgBcvoOaGGTsU3JuyZHfJ0pjHe
XxyCjchgrk3qpojjfAF1QM6LQjsMKIiY0BHb0EEpFvNF0ueFfxqp0RN2UX0STZ6LH+wIWMqdl7xr
58jQVHLYdF1DGww74jjHdmd5K9T7eCAyuOirbPZ8z7nPnNM7Ao9fZFE2iYO8TWw+OXfg2PknPXGr
SOLsghf/hvjIaDP5CPtiDRMRqZCetxzMCmirwSNobUdoeb4NqdF3ELdALaRGlXjLywvrnLr8Ii04
dPzTJKwVpK0cIrPUJUkU7zlF9EUfs05aXcnldrNwbeIBl5HLpmtRzEAHWNm74GWimmIrW8ipIcEY
Dg/o4zI4bOjKQTtqnNZdFnDQDeDmO7UYuJrcXy+KNN043L/7ks8GMd36nfUVHAYB6A3HWTDJ/grR
5iSKOHT6bwBqUkvmzWE/2nRmDeBXZ5Gca/4HivWWLT5jsKFymbkWXQYjB52Rv/iMg3TkOLD0pJje
71qWAnW6SYBEg82a5mXZqrmtZCXreP5i2/g86gt3sVI8kJwxL8z+2G==