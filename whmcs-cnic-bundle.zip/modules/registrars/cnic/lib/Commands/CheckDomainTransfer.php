<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+rLdyljzMFiw9aAwE8deAm2GQidRYIBI/0kfbFgsbM+AsfvgPmgRxxVXc/vRaCBzVZ3sv7b
5WTAwN106tmtUuFTdGt6vNkOOg2975MC778ksoNv8yXurDKXiDLRHbXB7kyznT4iB/pNdL7as4Ne
P73PQHwzBHPQQonIhG1dhCM1zFwwLZ4VjSM++0SGAx5v8ss9Uc1x6EyF2xF+8AKUJdd3fotmw81J
jh7qnKJrFxI2eIHh+0tnSRVZnlsTPxMvCFbSqS0ecS5h5/SQ9v2j2HIeQ9cURSFBPwonfnfLBI8N
ryd84WM2bR4a/P9L2VbrnRA3JOgXg7UYgZBteclhX/T/TGi5Qfr1r1gA3UYRKC2q0W5t35AogeTj
tqGTMNUF4PJgcaK5RLjElMxNAZ2ujZZIusiYEcKgEaS4k7ViAT7LQVO9FhiwN3ginCwAKNhuohKP
ou2bzAvJk3emZTuM4mU41I0oD6oEo5sFJM+9UGmga8DYBzTFXWhqDx6fS6EGeWuYHxcyareUgvB4
BgR9GFUsoEmNIQYc5isI4rDH0W85Xxor0no34mZZ5iAcj3c6sWVfNj9D/Er3o1C7SGLuXSBVUwWX
DOoHb5tA7rsscCr00xmAqMJSCFFJCeod9aR8ppLHoDVVKgfn//QOTIeX+FKav4thJqcBwWmSSeIT
3x6uva3iFQwunOjEVUQ1kuZsJ6/PJj7Wtqid1fpo6tsx2Tc+IV9rTyJ539M5suhQBximIRGvdKSz
xe+MNhV//OLoEh720AdnKvZOHZjSNwC4bLIbB5DAGtUXBcha4B9wDpvATN0GAX4OPWe8lvANhQPx
aHRwwNhVPrwuC4xf2EGHjWHn4cfJBYLohGH5jsp+VB/wxVjLhr1R9LX+KmWYQdkB0J6b8y2if7M5
Rmog8EQHKocQkCIKmQ+UcYmqkI0PxUhEiSGvEWH4DKpoT102ZDQyM9yhCTcg/XLgQzy3pKmdN/yD
r8O1C8wm9KJ/i4EeUgPqSXGCNmIjXRIiN6GrgWTOK3idBztyIHGobQywyHyqrLfQmIHCy2NWA711
zzAkqGVajmdOdVnT5+JVf+dzFdqTB5AqnEBPwmXBseNTyKeiIZHkoLtOwmITU9ecrVn+4GrsHXQ6
ctMhHAiN8LgOYbU3OGsJ45ygjWkgTvZzsJ4UTTtKzR+TYsgdRZRsn7BlyJ/HHBJk1AQnSeveDPG0
5JcPWRSDEd29BeFNZ3YPhW9YXDqwWC0px2PB3Gu+8jai2kwtvzUctWK+sy0nYa61SNnb15DHtQhL
T4V5GNLkOt6HTMn2SnPiX31NkwQwPbo7N5a4+BE4RfkFYq8lOVz51+oUlIjD9TdxDkxfARVv+2Io
zsDJKoGJC7RZbj8kmVw1AyXSZOwPBW3udTa9Z5Bq4w7cTUzrHcH06W+faLWx2VpOpAf8JDeZ6iHU
9nTHn8lvQe4mY11GH8IyThxUqrxM8jGeujsaQftmqnh8SBC8VgWtTymG+zEZBie7f+PRlzYZOwVD
b1e6nbvA8HnBmIo0u8ctJ5PdKmyU76KuarQ1q5ru35ShmVrboGWDfqDAlJEUgejWHqTPZnYyFauE
Dh3PgEUuDQaDCeISwrD952iq5WD1v0rksOPxsfDSN6vJUBiwy8TFaGbCXLodPUU95bogujNQHx0n
kf9hI+/hLH55Tx562S03py8ANEjd5WP6R5cJGmQTteNjBfbU53bQ307PRkSwY0vKPL+mX3QecOeY
ciIQgkf3UFKXzuB+zsK8POBkWmd1FUXrkiQQQMHDd+k7NWB9tKOf/gWfMmFiRGaTZpALEB9itoAq
KcFTLAii6UgTI+H83khIXJ01XqXBh0VD4ZFodYP5eCKBo0VD7AYaDTmBtz4nLIYk7hsl+c/tAO+Q
LYOa3SJMR2rZqurUIZNbb1FQqEJO5TDi02OD58eO9TY7TYlILIZvSsyjSBHln97+m9lnUfKCBTQu
zNGk2aqoIsa+AhbbP4hZxBNGDFrkZNRTi8AnS4CPn7DzA0G/iOuov7Yh+ymYtgRm+BFqra+041bY
cRzbkNSrQsg7+8Nim5xAP6t/3ri5ojwIBu00RnU9QLya/wBgK7SjsgPiwP6tM3JlUVd+bubSiSx9
wJVOz7BY+dOSli08rGKDM+iEcGcclRQVrMire7IoIOnXcvU/nDF5ccVxNVOWt7XYQAvE3sbGAenu
qvbBrFmbQVVgXHWsZVs0aIestD2ALOo9wx2gVVGISUJ2vk8DNPPE9TEVc8XVKvDUG7rg2mp2VX6o
kjQ8ewfiGbjHMux8yDa/PABj4TgsSdK+fUkhW1C2iSbiOpaRI3Qp7cciXrulIIm7pENYgoEGx0RO
W2BrAzejmGzuv/gymcCpUuB8ue4xjAf1LYizcQXEFL8450uwPji8LW/NrQQ5kl2OiwvYYJxIIecN
CgbCQ6zDYPc7hgE+Qd+Vnfg1Dm81rl0kVMz+aZKOVA7/+oUZlNVpZb7u7e1o+9SDsK8QNsEwISOT
a4fnhSNjWbbBxA9T7FBx1S8HRxfZhg23IH6JxxE2aiDOcmOMVCk2SNv8m/QQvhiSE1aQs9UmA8dl
HV6NmdPs8ENh4g+ThOt9mFEXyE4+7Ju2LGYZSijbZuWNR3v7hFhQJEUWMsI3EAlytnEHodHY2jo9
dgkGivF3gHpj4bLnjQvi35g7WG6+MaoVgZdPez43zUvzvnPElXv1oXLcfkMly91+7h5rNPVFSjy6
qISFs5gfxI9qj6/2boMl/0faQ5YbyxEbYF8v