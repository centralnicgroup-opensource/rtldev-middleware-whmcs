<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtvstEcEroJELxf9oW6/WNvwOKV+BTb59SzOI6vnonY4SwKHnmVKpjdINp5LnnGLEQ438k2P
BjlPDMFEb8odfUMAWNCiBPe/W6ulZ9N2levv8bszpL5TxSbAYZK1NpziXV46u0SCfPnXlqWqhkmb
nPhenxPVcm23pMob54jwuP1tGqZrMDdmQC/zXV0NzLlW0GrIby1I7kgZbsw3fRKCUBBDyd7HRDyt
79wZ8b/iFKG/NoRIbWSi7Q8N6G/vdvapX3hptWvuwW2FAIcOyaxrHkcg39jjQ3+ZRhqV5qDa0ezc
CVS7KmS43H9BgfPjaxzYi5njZtmgED8viusnUxq5TXi42Ae4mM8nE0knogqFQqFuglb/MeAbq9li
/bscfih0PKx+nU0mBwyCtwMwsLz3omr+bsTVzzBzKo4QoU803/3y0eRxg7+VmqDh3S/U5pjmlIPA
dXcL3yh9AA8N1L73h/W9wMgaV8oKScin1jHvpLeD0Ilx4hpdjGMyTr9ugpMOMkmd+MJ3XyRCmYxn
fRNpPTbKzbzTYBlwpitXs3SO03NGWZudHh60ILOh2u2lyMd/OKhlDCH3Z4H/eZ+pw2UJ+NeT1n1g
a6MeQ3Y5ZTo0fP3wupSPDNHOSgdvAGP1v7H0iMUkzvA2YGji6ZGZYVbh+NaiqYyfuMl3mN7skCXI
8g/TcQqBamF4cczVKGIR9oKdlIhqIp5rFKKAbyulnzIhTH2Ff+8pjXJdlFc7WOIROkyTFv9Rwbu3
xw6RMHnZYH3ZPITsMcOc02JQVVIgGR40wTYrp8JsMGdeGo3NEy+iskA0Puz0aB9rOZKVtqpF4vqJ
xh+VldR3WxPfTR+Bfc056dGwL4rh5vRPR6Bs9zqokjVQ+aGPwLXFeDLjN5KeihfqvDanlWsN5OdB
QwYZdKWH8miJQtybdN/VhphoVAgOzDH+HpZATd9xKLEWxFvUE1YxrFUlt4oMJgbKL4xKY2GPqAam
cho9CkK7v5/r+dO4Uq3+fRdgqzk0AiZ7YH2ozCMe2o1wA57sBdyhz336anP5irzUNFVQyKScE8Br
e+NSKds1ENzoaH3Mu/Rj2Mh9xWaWMAge0tCqCfxsLM0hZgKHu2Z5CbSsWDSMP/BQvqRi3uIDg1+4
qe1YdDZ7T/ZehrS5cAwJTljeEqK1+Rj8IDT80b6McevZxqnLK6O7lxn/+zdcJkm+s8QiY28FYeEE
Zo18e26qKScId0o4jRXRfqW4JlgYcQ+ShNrx5Vbidl05HfmdCrY/ttooBZKnRHt6Px1hu+dwwFx8
smLbFQVUbLtwiwMFTEBgwYV/rEWscvEib3xR7kkmFL5fB2PzmO0o7gA0x6ijfoITKhRprTW8RptL
93zrt5bcpGo/CBft/0nHqunYno3FkpGXGWLEqoqvziiYY/PWONfHyZc01DmFflneXSDhyuJrdLst
zhCfH3LoMolu+dGNa3BaX11B9js9Ygc6RFV92FUci6M4n80cBII77LOg9fXC/t+nCwm9bWc/9gKk
DzOVyDWId9Qa0BKt/e1OW6Zhzh+0e2bVhwmO7IlsjSxwOPD5f7PmhlckJON9BD4FwEpkw0yZ5mMN
NKCM9h1zpDh8D5IrjdONudlNvSimHDDz2EThhi8bbwAS9R63epCbRFzaLI7EMQ/08ScrWOoOz3fu
ernvamk9m0O8lQkVhgPx1v66sG86M5vlYo62GzQqE2tUErtgS4avnahBYvZIj8bydT/YFbVycFb/
2sJstBhbmh/NomtPqRD4+iL5Vgb7ixPZoo7/iCxiV+E6CvbCKtZ6aDv4n3bR1NdkeRAHVclbZFZb
ShUQ5gRXZdgzqDrMjwSUj2na9sdNIRXVyLBeWEtVsPyCZfNeRTU6xikxPPCcy66hTaUyjE4G4eFz
KwwAj3s28T/PLv8FaRa6wnoMLDtYcpgn10Jg/dBFaEofcmNHQbIW1ryUmeQuIukHdXjHlhuL+HY9
8Lh7qKqtR9Q5m5Y+9uDfWmS7ABNdNNrH1O5gjyCNV/Wx3rGoKH13KvN+ccrSEj50O9Z50GsK2rJN
RwzG/toXeNlii6ROEn1YOAZYDGG2PSAytQMtubWYM68WhPkmleiEeAK574eMVNjujEW6uU6GZVyg
VL6IHhUk9aUeLxaKEpatt1YAKmwi7wnHMKzjz8wXchVR2B/AM46lcjsspm1nSXqE1v7TceFq9IpR
wLitYr8nYsXcxIVr482hxkIxc3fIiosRDPcm7RF2+riA2ijmJzzm3fpVZq2649CL408+f8vZGLjs
kmFvRFtc8QdOBK7895xeH7W9uLJD0stBf5cyyJ8cP2QJ50ZFZOFEWQ9EBGOKR3UwzJVgIFeCH670
gJRpLA+AuxeVvgVFLfJNTebFwPTxgWzaXusfoxJ9sJ3Qd59vB8Ha5Gg750H3TPTEFWTAO8RF3jrx
iJ/NBrYkh7KC0VtoIxqLuvd2perrtBTQ9Zv9EHggAFllkyx3UirOIeGSeeR17+M2Mvt8nuB84BT/
TimHpBXCqNzVLs7IIRE1TkcU1yCmQUpPBtKQPY8CdZRzdUXAlw+nllUCugacayiMA/hEo8lQHqJZ
ZVf4kqSBq51JWrg7BWb4chW/jAAbi8N6n19cCRMUg4lWA3CT11bCP/aox8A+VytJicHREOukoMa1
1PwtjvOBXQf0PjA/v+/jrxNx0b0BPOAGsJWaifrt4qD/Rlo5tbCxsvvyTKNQe8iiZ9tjNwIRR+ub
e78m88fFSJL95fTGLz2vpCt6YnRmgNvqczdByhwdWiJYjPNWhq8Tb3ZhDLXr7mZhpzl/WRvPIRh8
6LHokxrYkb6o