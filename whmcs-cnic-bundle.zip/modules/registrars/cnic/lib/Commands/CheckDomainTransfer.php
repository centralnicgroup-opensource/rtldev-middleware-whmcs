<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxbtugIRrzQBOhftXuORjgyqfID6jmhOiTGDd4wepVFZ/ZxuCcxaiSqHuBiDllGRnD6BKJ76
nDtK6Zg+cEjJrZ5FvOkaOHXr1SItsmpBOOT05h5tzUHk3YOOMXNWo/d9qVvSdnpKkhJhjwD8yM3q
4KQrQuyoZ6+c5UqChKv50+fh0itHzRnYDXn59OCnMyImQc9+CO3rhFekVRv5DC5X2sDXxs2/VrS2
gAp220S7WUD/dQXUx1AIHrBkaj01ehMy54XpCe3jBHk5d++lcFjXiRrN4meUeMqzfKnnVkWeuE14
IF5mg0f7h9hPFqP5Ce6sm/qlgsEK3x/MnPTW+NpojA7RGg40nr/P2lsnJ5AUCOysDkqn/qN7Camn
c+Jhp7m7xdoGP01evIRuZ9GlyDoAMWYStPE3uDVQMExvust4L38F1dRGNzZfXq3MgLfMahU/md6+
Ec+lYJRnIJ27b2UjLFxoN4B1jsGdK4aRNtil2+r5RT746YYD+0JKdl/779PbLE+V0wxXZd882nTI
Y4GTroLV+2KH46jzRJVanFA90M4c4TS3F+EljYFIRaIosxD4oEcC6UsVBq/TGJs4cqfTzYKGCPNc
U6rBi8ntwI0VY2jJ6kqpCu1uI9yITJS2WG0bBB91x4HMkMGoPCrb3gnVBNOaTvl/f0k1TLwKnPlx
nqZy3ImqxqpU+DtmcqOm759pcAxcRYT0cF8VI3rs768V/SrRzeTg1rvNDcLx815XZv7r5M1ipe9o
/v1XYXfWWgG9EZ/xwlk9PUDb9KgUT2wTnA6s7QMJ0X8gSYVyqMPX2CcDImAJU31NCeinGfrjd8Td
iOSI7+SL8fkUkXJPCAw1g4qq2/eMhvspjH92ERBuCpESUUmsfOvdM8ejZdXWKY5TsDSnzlZW1VpH
w3zuNIBdN1Y0VoQrYPJB0OkmzNF/I87BeklQKYDRuOA4RcO9JR4TZ1ud90LoR3JdHm9Ld5f/PYzE
9JVmtIdwRw4wEQFnW5yVj8ffSb7NrSLsAW41YGnWXiqx1MOI1aD9vVxeTkOo240owijCzdAZhAX3
wrRAfj9Gu3HVe/bN/H/muQ+zBQdZoJlBXQ57OnFhMsaKpJu3flZ/w4qxX4HsY20Zp4f5KB2xBb59
2i5nmBEmKEsXgSuXnOfC1AiPn20dQVqT1iRMmWePr/HN+veUuAykuHt9xEzgY6JyA6P5EMP5ABI8
T6ZRf2nqSnDSPP3pAkLAP3G18Ru/Gwryfv+N9ag6EKdJMSrpbsT2JYGbhZii825gHEfD8IuHucTb
oO0FBRDSOKXU9FqBbH4QWDigOcG53rbckk6oX07IO/OvpZ106xDqQnO1IKpU4mwxc4p6ddZ46ll/
iStL+Q9eEUFOxliFvI5eHT/eldkdz7n4e+4H/Ps4JY6Ot7Igx3OO12aWJvkGlssTWZPcYtVfaBtY
rkFf4C0IOlDI9HtqLQktfyHqFtmkNuM8tT7vYST6GqRwQlhSISjwJMSMPnRHHMe6eKiW8CwQ/RZK
QZ1v9J56nmqieUjaxsjp0Kf+6Evlaa3AGflCcNJ20PjA7n5KxH7WHaJmfGKtfYCxbYpFcF5/VNCm
tL7e1hOfnuw9G4Di+9fK926M0mqZQTuvmAqRDh4+/Z2OI0u0bV7afJuS3dfdXLdbOnN7Z7OVlDQ9
bbv2rC4sDR//wGPyN3zI26x/XVKbQ8qkfhaZemcWX5rCgiB6O7J0MWCnBhpM7QaSrxuNdNNhzcsV
khCBUTrkIL9oOSPOLrF6Z+4MfeTNpBNXL8hFMQCnCWL1R69UqH+A2ckNMH/n4Gcww8QYMS/9GYKX
h9KnY7uqGW/9mrMmBJg8Be1ZA+oOoxBJxGtmxSlOZNOs8bCz1/N1tHlbo5deYlGRkbQ83ZrnK0WK
ClDchesHO++qWqoEN546pWtDc31XK/pdL6Ql5o/MFjvRdR9e0cgsQ1HRoAXNYcFz+Aljt7josrHq
90HW4R5bC/+O0x/h4DenkgaWVmkzjmCjldBFkFtfhmld2obMVFYO7O75DLBPrEQ6ahRbcy1HiNHL
wzdrH6OFMPIlAQKLpQZS7R3WcIsxbAFYQ1SskRmYQWlR6yN0ZqqbU8pDZpc4uUabSIl6Y5dozi+B
pnAqMsGXAFMaApB1iCJmg93OHk+gP5ZNpUvGI8e8qbDyjjqIo1BGxEW8kJ5mWKKgG3d9LE4S9j4p
Gp/TkKCeybHpOLN5NSVPBw3LiA++tweM2ogMcKLsO5Gzuri7nXZnzHpLZEHp3kMs9RNYhazrZleC
9md3GP6HR4tOOvZ9wxY/1ojri1oDx3ZW0+7J8YEzWqyB6nZWIlMZVqh57iMT3OtxpD2etA8K5XoB
/r3V1yAO755zt4rxGudCQVlQAllIEs2hlUqrcsEIGVyO1P7+48BE7W6vLRYfmVbIGzFsg2k+T5gW
pQERrWZVdld9bQ1mkyNFXzWnR3BWBzE0KJb7GKtgwNJ96vKv2W3T+HP7qkSZecPjhNX2lS8HfKQD
C8H5xpjdQF8g8UtsbXMxyL7MhPnqSPL3LnNez37r6shRJj7M2Yd8rtbzotoX/KynAN8LDp1ijCbO
m9oliwo3m1yXu6MNePYOehEvqJ4o/f+svdby2sdd/KdzmEjNwh8X60SWdqjdGwH+LqZRnz4H2MpV
zaGHDRWM4opzdT9uaNULrrUgvZPJFxeIxgyB4T8rkz3IjamWePMy27zYFvvG7yBHJu8zJlp+mw67
Lri6ZUVxBbKa0W6MWhryC9pYGkgELe8tCdmM7nDZ74Yha/dtwGuVeqOcsBnnfC31BPg+RmDHHJAJ
ASY8/aOF6AqKdEx+