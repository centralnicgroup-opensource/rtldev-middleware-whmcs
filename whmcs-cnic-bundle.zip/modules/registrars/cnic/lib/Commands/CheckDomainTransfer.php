<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzB3q6FcWobK/s0FHK2I/GaTUzLcDP9ilya7UkL9Y4AiBhcmXbgQkCh/IMCQPK+POpQiGfll
p/YSZyZ3fefFqWix728ilhshtjEQGfJ72p453BG0Vsrix/bnYxAUVnMSpIWQgZYd3n2o5LpJrHYw
HsC4i+24PiNku84axstGykvYIesLU2aXpa5OGlCCSrbJX0GNUwkJ52ChLDgl1Iad5fHISDNP2E/u
kp2qb1gjGaVJi53pE9Jty14utXwtojXtLD2rqMbX2x9KEJJqeKQBACJ5XtecQ2HP7vkqJhlbKpUE
1zz6H/ylEeJfYJOjZMRrEZZH/16paiW7jbs4fjTvGg1wtmJ5+tmUENarT9cmwAqN7KaUZVEW85LT
m5y/5STt7Pkw0I8JZ7xXSIhbpP45jFFpRUwZLdFMHBpvAg098kgAMHy6BBxv5VlAHu+aUGRxaGc5
tUgZG81AH5qRj+ivq2OwOzW/W2BJ66g+LqngGvEFHMQIZLYBzjnopalhe/O2gRcdp7BlEW9AoRpC
T1LUpDuzAQWQQ32OFvFItHQ6RwuTsWjluw5Abpk3qhxcIzxwLy44R7ZbyopcQqiDXEIekJ6gdBD9
zj7Tn9s5NPXuFIrsgrgoXS2CCgkTphTKWaC5pS7hWIrg6osmBVvfgmwNf+P0SH8zWs+Zkll80P6C
sSpeaOgZ4kCGGUhbr0pdXGbDZKN5jU0/KUARlJum7KYbEJcRCht6YV3tKxHOeaS9NE1Tqh93O2bV
LkdwX1Z96wsYOO18tZc4IUG2ZynGAZbsukaPchUhOgbGYWC7WzgxaR3zHywkEIf03j+Wr/1/9ZKJ
f/gryAViRE6jNsFvGKf5/lA9mVRS77vQh7nOVIC2CFNEZ2L/IoA4LlxpO01hWQelP1thbuPV70cu
VXxhkhmeoH9goUU6+vXdBBcfoVVZjF1Ud/En2L7RWyscEU1TDy3eq2FYSnhFKADNs8qo4Uz1HS8T
eXsEtamguJ//+B3oXbIgaQVof5leIfiJdvqHnpeZuR1FOsx+KRJoESXNnV1jzHLNH77ii3+CBpOu
QJXYPsItb9FwUvOxHZuwixXoU4gZcVgS8ot/codigHorHUPmPoJ9lXyLrtKKE0MfueGzleAw5KBj
YrcQV1fSEwolT/B+wmVAnQohrd6JGzRRBwlIZNmKZbBVzOXB7nK9TOxIpP67X9ahx5eZyNeg8Z+N
aa26GvBBI72D9YUB7pEcJ4gPw1d2S1y2vVIaznTuI+DPUpk1dqM42ZZGjFcVKyIDUfHn82a/wp2v
cGm1zVBqzYJcO8th6gFJstUG4Cf7LkKOMLw8R3FYEVmmbPqv4UTNnOoFLr2v8dQfU5dMUpLxvkZD
FilX3bpKbEVvFQUMCuwL5RXPBvL38VqDi8mT37JvEHbf70N6jxFVswIkPxjrVdXVLh/a2KNh6nCY
+8QKCGIRN50TQ1iPCHThEZjFEjcmD/BBcpiz7E946VT2Zf8LhumdpuYnxKQOc8G1g4OiDPDylRMy
6q3gw0NxjCSlmyf/p3bPZP05LZ5JIWwNNlTTwdnhEX8L18P5NcmfNg8RCMOGh+j9xwe0gw5dDeOt
AhdBD77+h3Nk87cYg6Hk2issFjbKXhvQnfJ5YTFaRM2RRU71yRRr21kHBb4NY2xjlgtUWwrhqG3C
Xk1m19JRUhIMk05yJjX+ZhrU70xmD7xhMetWqXLPBxgJQIqLapHyEEq2FvOLeGM8e5DlijhUhLSo
Wg8LBB1zhZ11i8c+j0kdbm6OdtDjEuTjf+K+XBFpzOsr99pC7x2ZYdN3HWh8vK8mSm7jsCu/b7nd
tQtZBjg+sNQHQZx/RhPagcJglNRJEEeQk2kAbVOz4+dDYXRC/v/WS4Ops8QgN7ngLtFwE2LVJWUg
9u0xzoBCztY/4i91W4G3hrekiqHjFZWXzJdu9QA1gyu51opv76LyEHFpl+wNOvfCm+b9rpjyPt7w
NZAtOM3ZmOECtWSNb5IqpIEgdEsn1RSGsij9GqfLTN2Mr+/q8y1FMhwANcl9wKY1mLeAk5jaZFME
oCFPKVg0rKJTE7eLJYO2Of/gcix3rLJBpy6rx4e5yo9LuWWYyqXp3P00VkqvXjSf/gtMlXN6dYGV
axT49xPBKfqeMYfe73EnJJKCVnm3NEfL+2lZcAnpwr92XIB+EdZTL2GPuTC/BLAgSCFVMrs+End3
dNI3HR2UnOpwjSqb4rvLhgjDhcoqsX7uMLY9BmcBxr2bvzAiSHIn+ReZCaalp68dBvcNBGk7jmx5
boSime4gl++AUggoTKvmEqLrYqzQDJg3pLy6aAltFxTI7WcPokUm3u7bklEoSpWosI2PUaDTqJlr
LGYorOsiftFYu4IJey/RTzpW9LXJP2Bnk+pYsrTiWJxb04AmEA1GSCkCHjE7LvlAqZK9GD1P+JyH
FluxTxBujypcny6qOn9uJx840smUJNujlIzSDOO00OX7wrM3VfB64wcK3ZLJI+KJnxAJXJy+1QA7
bCSVddX9L9m55SbxScRzENDksh4VV39cMcwg/fu6ycoxyMHecCGHO+g/ZucP/4D+TFoOMDm7bOLb
Oui1AwHl1enUqyzPNBNfP12OjCXAGfaT3eYpgvL3r8TitOc1DqiuPYtTeZc2fqM1Mzw/kayzS8Ep
AYuLd/UKEJXX5UvoBl6VgqQjKagd/PRXJrqXUK2Dq84l4gsRk95VaqKcasLieBGn1T5WbaCm/nGB
9OlbuSAcrBT7jTK/byEnkCRXAwODwW57nFxpqGbI4mAkRNRS9NYBXXq4mIz1AhV4exp1