<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs8tW0sSbdWYMViLBYcbH/Jxaaz8BI5T/CKq0r87vyypdfeCrOHYC5WOU8x036O68c12ED3/
eQzCOJHKsNUKH/oi2WcTUdVKoqkVjGZgIhA3FVkhPkZAv2JKPKlSSTsA//noakNj3ykTuRkLeh3t
VLJahGU1nSjBDwRz3dIy9TmNT+0Ac3Lcfm7mSBhaSMqm0I0X/v6m+DC2xSPHuzLLlrPYRW5l2VRz
PIcz2Vj/YMCnBovMsRCdEzyArA4ulvjGoBtI/15OmHc7YsTKV51AV9cOMRVfQLteo8d+yjQBfS9x
xINeS249JDbOrcR4ii1dBq15dEPesqq9uDZxNWPHpaeBHLYIREwGNMRTq/QljvRNlj5hYAmz/cKN
5K32QtioqpZTUC1QlxXaoQiKYu05HNvYcNvfrZ2LWpAlg8RJd8cAVs61HT+SqoH0SlCPz22DxVYI
M6Z51RKtpBQIyMyuWFlu2e39gsDi7zOUuNAza3wClle9Kx+F4PQ9dbwFZ0AjKQqwhqVReb7bX0oH
yp5HKjEFBF35os+5VvKBIfCm4IIiVQBfNdrZZ/06Uw6+uYasfcFOIls6vK+5xR0fAK1LyUJPkdac
rm4ve9r1RR3T8tF5YvzgVmSqKMvOWszpjuqsx1RDtfyLQvDQ/zn2u46SvggJ2Qceu+Dnf8iF30We
+puHtbqn1IKD971gyJ6eH9c0zLZJCUxMtmPi0TiJV36L/O0Gj2qh0V/9XW/+So7eVhA8rvvKx0/Q
kvOuGjILv03WGWqUtr6bd7pujL0YemHSlYqcLAvfnfWq1cWUHbuF8CVPhheeHmJ778td/JcbQHVb
WnvqhH0bgsRbH0m63wHhrpaVNGEc72wOwgucScv/QrUILEdV7ebA1kl0VBb1iHq9UBqOmD5E74gD
tY+mlj+PoXei226aHaf/YXi+/0nUPqEvRJOJ7r01bwfhgPFhOggmNCAltoV9uaF76Cuw/dK8jR57
IFr7ohgSg5PE/s84vmUpugbAmw6ibdgjx0qjIjslGzsodMK7G1MkCCCZehB+serG31uVGQ/e438Y
sXqxSv6KxFS3StNRWD3gsFkhRdJ0twMQezrZHTA0bh9Yi3vo3tCVX1r6+SX9bY9i8KE4beexy2C4
sjH+9f4S15iUzSzYVgc/Ht8DSOqBQGYa23BHx7muvqiEIJVVLS0qA0RMIONX2XqK7qKjfv+1P03W
KTVNhnsC7lxQrST0RwDZ05pdMIaPlHJxXv6NPV0/4UtjwpFiMx7T2l0bPM4CYnclpUvxd5/umSSg
aS7YJytZkSyQuDUbq7/umF6qegipl8Iy7pGQmy8G7Y14dHQW3Iq5MW8J39fETFobKv/95UK78CYm
blZZZRweCZjplXr+n089ZsILb9rWrDHYWRUl8HuLqbprxpWIXBHHL4z9bR7T6BhHNPScx8f7PXKm
9Rfbxhy2L+B58BLvqgmQcRLvz1BamW6zsZyXk7njPaJZjVg/VgZ2DsDgznlM00V/hMIPhiV3XKzh
Hovu3MB5wTuc11bU7sjP+dP7WdO4oeDfkf4A/SVRviD6EMshzKrxjni8tuGuDCxCX8QtCyCPf0Ku
eJYhwxkc6ey5GyMvroLyqGQ0GaZNJhtA0rKE99BPRiIkVTTJ+Jtk8rZWie/q3hUCJze9KSPUUFt7
XXPSSTfI2bm2CPEJcreX/mzQtk3KMZ2qXmEGTyvr1J/G45tdaZvVEinEDZxCZgu4YVk/BfbJ76Qp
0G9VcQIPHftlJ0KvK0FkSx6HeC3a36ZkQulZ250YQXjCh7dt9nKf41SFZqO1w3D8iYj3f7OLXYX+
0B9JiMAzrUnWYfio4BmHookB42PG7Ad0JMzBt7goQqT1dQ/xGWs1Ltwuak4HnCiKGnsE+mT+m4Rb
dLzfbG3DwxnpdL/5t4FEaCeqxDjZGui95RFFbXfpWDh9uEKaWcFBwcodjQGvMpM6DRzJpjSR0n01
RG2qk4Nt1JjrCHflenaKANirFWG3vbMGhS/NmzQwmU+EMgVM04jghvunbsuX2nTrnZyCp0W8d0KO
xVxEuGHfDGutwhODd10EG2BiRus1ZY0qtQKapfcnWvNmAMF8l67Bm4IbDMzFOkkAYgtbftSPRR9w
jep9Z9RsZnZ8LOnJogOB33C9gClM+0wD+Zkvy803JQ4J0+ANlsLWUGJlcSNga8WZWAmv3apiH+o7
w61g8Xt4iINOBF9J2gj4gfnWVO6jRwGc4b4XSkgNm4HPKRmFXftA4yG9lEuYEgWVqhFdIp/aYXGg
U3U2aXooBy++HoXuoI2Vu1gHAhyC8IW/piXukZWJGL/6UEpd0Ci+3Ia5ZLMD1Q2vLDAIg388V4gg
MMCsVquC7xKnaO7ByTiXA/R5TF+HVufN4u8XEbZo7C0z0r3yCzKngZiqfQzpUwtPV7w8pQ8sDKkq
JXtOXeRdyc6G49NGuqTcndcGyGQk6LIjsI1Hr54TCJ2amTyfGTfhQ5kh/PZg39mHzabjc5O+1B65
PBtX5TukOnY8z41otWKh0dzCWFHTBYT0gL5n/c3pKpKftszLJ0X5t/HQd8up1uFPOGmvtoZavCtm
IBVnrvaguTQv9Zb4ZsvvPMgCsQ7bDDQM6dTZ6qRw9GdhCwjM7d9Rq5C4R4paZbopNv+2gOjEpaWh
lP+taA4ng70xOOU+qLv9Z0xcw8AgDSMGqRBEIsEvK2RPz7CV85EPEqzQeeopyXGHA8W8RQmqIbuk
Fminf/x9CvtGQMPiNZ+OhiAiGLIYsGBUo/65RNz/VCk/YdzRAG==