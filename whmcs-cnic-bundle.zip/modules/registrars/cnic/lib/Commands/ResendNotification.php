<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxSa/beJkiATwkXhUG13PlbvCsF2OKMDxg6ugTFqnWUHNbQvAZN9ZpBUCc8ncwms+CCZ6QJ1
k3xzAAdb2+rz/fRQRtHCgTRLi+QiRaYl+e5B6NfqwgJpvyesYlyUMrkkteeGBMcZC8uqo3YdagOO
zwi6g12hAmNlvp1jm8eJj1eRI2Hi/4XNOtK3X/9TIkMImO0sihJDV4L+731UQxNiRlCKovvVBDch
QI21W2dwatgWzgLBBDxk5Q9FAa8Yf2BZ5Gss38PGOQjJKu8SAFAUjXXANLTffcNizJbk312Wc1Z7
kYXy/sqgeQGIHRmJqmKZkO58JXMx63DtMruo20qmDCkelj3ivfiA40dQ44xOoAm+Dd+MpP63I3xP
jtwsdJsCZor6OnY5shzopgY2FjxptPc7NU/zOlbUjNY2yX+yhWuasehMPmLbxfgja33sFyYVEl/I
Y18WtMNO6EubTlkpJwjlTiZs5NLWVNYzWXBzkfn6rTmzaJ0v7yTRMFZZR2phk/llB4cV9IxrVIfZ
XGxQ9L1ZuwSq9uicFlYFOrWp2bh1Nd38xlLgljsuYcbjWNpUqo7PJ62AK4O4RuTwUvhIylrq2+cx
BIXZgOA3hBBx7SrH+wPEAP+w5C0oGrOqB4BWnq9nP3d/Wv7NcV8a4+U7GdntUDrTkgMq0Dfv7r+J
feJ8XcAdOKKqj0B1Ya9/f0aLu2cb6P1RnEgj2DBDnVVOyvXDYeyDO2zzAZC5ErX5+tBfH53FA3Uu
SIPaUbMWsuERDhs8jmR3cOrxA7amzPzimJjhlc1EL/siVfJttpU9D9OV9Bue0QsmWbhAI06W1/Kb
sr+g01Hjtch7fFND6B3D+RtfECjdDuhpS1wBVQN9pQjA+HcVJvR97xLF/Xh4w07vjUFBhZtA4i0Z
6Np/KhZ7WBrDtHtcSmG2DSqKorkvtqjj8H2b6x6pZVAVwq2R3QOLIgSI5SUK+6mdcU9cAcoCgCBi
NPJ+HaoxJIHKbsmxtUps5iHmOE7gs/9+C0hnQ47UJHbedSDr+CGrBcYAsziG9E/yQ6rB6djqyNGK
c5fvLm454jxBR/IFdTTqeneCOQtSCHMqXjbgJ9Dt73JkGxw5XIaSgcVfZwlRmLz75HXThieui/J+
8SMkRS9SxsaLP4JhlvX2B+kMxRSqAEixGmBU9ef5jOie750s98H8nEMTQLbZ3FsAdK1b4axK5YnW
1EyBwBIfuOrvuC0A1DMHaUBPZjB1oS197dUuKfqnlK/Q9xgVgD+YIchs40HioJTkGX20o6pHHXnm
WB5+ielALOsPEFvg0CE5MgYeWI7adiKV9adltjJO2yp9ftkupJD86+kJFJLNEPjlQ/B88/dnMcKE
MqgsFOS9rc3gJeYu1P0XaKM7xTg4mTPwLD7o72JHewh1dQPl725OFfJxwTTWnUql2RR8KQuU60xD
sRELVh4Ucztu4AysRzBDO/Oe/5ae9U/KXCmQAbYHCLEXCbvHdwt/dPzXQVN/PQWuzMvjyCK6vrg/
0UWYdd+dLwm2l1pyU/N6TMv0cl3xpG9YRuOFCUC32R22mqgYfgwcFkgLp7s5gqvIyH6GxvxM0lp5
tzBSdgmwUbJWlQPTMPdidt+AIhMd8y4FHMqfLrtaC/UJESU8dryNch6sHLVbKeylxET9/dt+zTUd
OG7aqwPEr62S5Buk8OCbZHed8ybyzBswHslvm6pt8E0vy+Oa3InrVlTNwUq1ZCC+9qPq9IAWY+53
cX4krzC+1Hwvj5oiIcR9O0n9/vlD67nl6+JFITj7QVEwsLvTtPaNHXU79C0VHM7NQLD1aAF3kkfI
mPTjcuFECtwBPnJKiwOdaYEERno2u+MkknP/Z2VubkhhbdQKM2+S8yO32MfL9f0zby0k9z3z1A1i
grvCtH4m+isbvi1Djzli0Gg3O5YjlJ8SsMHZsngvOFTQLoSgcrjIiYMhEFUMlXhSjQZ5c/nvuHBB
GlZKIlghtYM2O4f3XliYPqFmBGWLdJdZgi+NbfA7/G/q+/6yhNDDhZFD7zbFeE++4WFaAPAIBGLA
OMv9XKXAdpRP2qnEk08vkGRVp2YnXALN/EijEr1HSumArLLuP2Hl598PVSNjyrr+lPLAcsrWYS6Y
iuhDen3UHc+wrXcO9YOPHYY5rX19MrsJypXQaEN6eq4ZNu6eXGSstQul+HXWffqA51tN1NDQN4Wz
tPIbQomULdGLVStwKIh3JRM0I+dVTOjuzb2SR7oVEldkkmVUnv3RXDjs28RczqQk2l4Dbf0cN00q
+UfI2vTymn1OMzfEcDjNBMNHlFPqrJApoe0U03ZMjubnLYMbMNFUaaKbn4csK5vIv2pepno5WJdS
8TwrcTf82picCecsIhrv0q3WG4rH2aji9uwWu5rGty7QO2sJpt10CF1RhjRe1AySiuZ4tZd2HhEc
5WbMuTXJjv+Y+2PHzL2hifpVJP2Geos0D5c72SoD3cgXDsYl8fFz6SIFZ+ZosrEGhUtop1UwpJqB
L5C4/tsZP4Nk+FZ0mQ9/AJvoSlvZw9gn1pXkKS9L9SXw3jL1YqhXa3KHToE29640tpIEyc09p+2D
6S9IqDTHuFqL6LpBQT36YCdtm9lXAliMpfkRNJ0eLET0QGENlnah4BaGUvHRIwOSjGLsMJS=