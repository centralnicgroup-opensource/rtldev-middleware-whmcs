<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpwW2Jl39lB/bPfid1YemRGSVvEQy71VCzM86l75+XXCl6V1Qg3aMfMymKXcUVPUnywnvcko
P6+hrztsZVo51hev7iZ7MJbjv0aV5ZSjPMOpWlkVL10SIEWMRmc6dOWuzXvrYqQYR8q3MizHIESG
/Is9VQ/H00EYSbttncjJ7MaBhHI0Q951BmR4rMyTCdUA3N67tOHYHIttGjG2A5DLMjmCGRWl101J
hBQHdoMTG16fcQOWNpaCOsMa8PVrpU3hHNMAAaLnBc5XMRATCsgUDe4Rlvv7OZNoZIQpd6hP4RAF
bzJ6AlykQ9kDku4uOkslXyOW0jfliA3GCv+CZ3SA2Ddvy8e88B/q/qbtoKtr5lPiwMMBicvws5e4
3jB2jfyw7b6GOpKs+SCQv+mTOb4cLrk6qSyxFwX+f6Yx9Q2z7DLxGw0BXWZSoU5r36ocNJC5ntz3
jVoY/Xw4V4ZVXcXfVLV5WOuTKCHXQFyNZUfRP1cL/qhK220nDFqAJRrHyOj1MssXPOZms5ESFX2C
UE70nlBEiq4Ugj32PxdCtJzIlgyXL7QZ0cn5jpt9Kb07c0DOntDcl/2oT1mzfH/Dq1mcmaPH93Tn
+/mNDXZhfMe3UNUUMy6N1qHkFQVujOMsqqBQdDkTXQfc/palw8Os4tb5z0RGwrhu5YuBzlGopHaf
4PZuBEttBqpyPjBTasd1b7RYa82F59sVTZZKCeTlLRaJxVU0D9LwUht5G53Jem+V8Y58Xp4Um15C
kShpSyphTpMATopAdwRbScUyLmcoVmR6jSwy4vdzcyrmqXPlmKWm8a+AmzQM/o+eiU/5C/NcC2qw
nVI2LDH69hMYOLdv8foOzB9CO8hTE6nNRQQf2kciifLzD/z47Q6sy50IyRShgXlfGh0xuv8mXCkv
gV09j7r2pC26cIpVbQeNfALzfY4/n7nKCbgeksx+BiJvwXCfuCqZbXAVXVEXkRpyX2YjfuNVKWXz
foUHwHQ4QC58CUieKOefxhrpQYfdRCFKDd9/ayDXP7y4JouE1kHImGM7Z2+MW73dYvVEyxTGos/U
a+yczXr3lehqGqmRxW40r60GYm/3aMT4xdd+oUXtll9OU8zRO+7VY1WZmA5h+ieIU6qK2h+R3olx
1wfIczEUknjG2PctHZAa7bwlUHb6eOvQbfnZUkL4aS+OI9GOL54FLSLnPJNa5+/PMJ5Wa1OV8c7S
ZW5eC79QUHxIlaaNv6WTE/aV7cZaH0j8YLdgSCCZ4yueCQTqoONJiRcCnNZCnn7GK80tkzKfUZ+r
x6ZjrXVOUCnzEScrDaWDhNW9sBlvL0iZIXPW+2HDlrYSiVuxKGM+2DysxP4iC/bEQmddkUV0X50f
HAqUmD94XJjvHtQarCtI7LeR+mxExkDycbijMj4ZAy3wgc1L2vzRhpECyqiDV0W2iGewbYmDn5ks
f/DpHm+WIl8Nq1wDJ50g8gjazrBE3nc7kHPmnlFmJj18fY8OoXjbQKSzgcafAlh80rFTn6V+aWdN
msdBegoJ/93t7pquCx9fyeCYtxTfHLSW4tlHd3D0nBwU54BSpkaopCx8WNtH8kq7eynzCzv/PagZ
oghstTyg0zO8fLdVoGZMDL2dQQ+AjcQm+mRJBChUCOSthfs2HcAiAwkhGjoNZ6yb3jbzp8YBETDh
EItQrWMaeMPeU34j8MNHUqPpZjonzAhd/iA9v97MSpzvgr1drZVl4ZjIcbnwIOr09zqD91XcI36n
4Fg8y6Mi6NLwbBi/Xwhv3r51nWbtWZWcmjA4lUo8bSSQXzsGeGEmHZbYzrrOk9vQIj63kI7oq8wM
Bt9Jue208YxQKiZsgWWIhie2Zr2jsvrzDx2UkpJwXQPJ7OjTLS1/j6Q2fw7R9Ww21ti1B7lbbqD0
r9tVvEHjBZD0vvqALYeq8Rewkoqkj4BuzJiHDuaeBjydaDMHOsbhSSoEZnvmG7LMaiY3EWA9VNzL
XQJ+Yp2Rw3HV0lWhL4vvPhDZY19yxV/0u5hXDkZvMAr53qgoFkVV0s8LRJTAxg8R9ZQHZjzBtNlr
4pgdWSAZX8EQ8bO4iXyC7XxBrAVg4U/sBvKiruyH5urYId3o1GVAR1jbx+TbIWKTJJh5kE0zXHxn
3RlfaTcNIrYqJJe1q+K8uA9FsBLwYIBkNbQhBYKb2G+mGRr81neYYNPgcDy0SRFwU5hO0Xu3mVDv
J2WNOJ9cFL+C/UJeOFSBq+yK+MxZyy3le1RATLx6cpNSAn17SqEhRhdHyEweTaIZxiM5e2V6LkNQ
WsVNl7A9a81Oe4D2jUQ6AAI8ZWHzRhmXpvnGc5ZZSCpxAsONGZ2elZMktDdRRsFeGvedm41QDn9y
8nJ3r94QDwnJGYfebdcg8FgXLRv5ovfHs7tatIfn5889ivRLlGXsyFdojm5Lo8iCiKYPESFf8fCb
VBuXcfBfefNUBlWdtM5r9yF62ukkrqbaXIEfrW9SRD7QmCIvio3VOGyGTIk4nq1Bia5OjpDNxDbX
ZYSgYYM69FbC2pKkdgh0MzgTOH2NMNhH+rqvqCOP5wxZHeZoU9PQOVPqwCmw8SkxJWA3D2e8llWK
6BnNxOLMG+qGmZ6DWe58VQF6SDU4dR86QfZPfdvBs3xldpLolOH7gSDYlXe=