<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwNxtFT/QoNu1ZT9rB9qPDvorBp5mmMu8UrvLwPfRXzKMoFHLV31fM2ycr1qaOYPlnzzqwK5
gHM6xGl7frOYHfkMDARjAp6BkDNwZ1I4kbqDwVZqqJ/WLsPE+iN1L5vkyXytlvwaEINgsYt+EcPl
9yTzez9jstlXbthLXDZbNc0lPrKPgYuHV6LUZU2StG4tjWben/u9DzcIwbLrm4fQZpIA+i72qac+
FSltApjK4kYm6c8YoECaAj/WYubsOavYCIXENq7kFkOtLH74k2CgGXC9T5ChzMgmdNYEX1fPeDSh
V8s8nnrEJk9xOXQzeR7gqPSICiX+hRTrBU3O5YjMB95+WrFhHAcHUDkpPgaOGOhNRAjYu2aKZIXb
BMwWxT/eaM5gLQIwlnrRYd9OFhrbYhTCxTAddL4+Vjdw8Df9tF9mCAD4OL4n64jJ3+VTx5ibngPK
NcEaNnbrqFs3uJB/LCZOS8oLn7SHR3qv/ax4SxRKxibDOUnQghudBuozC8fTkQx6THjKpFa2O7ji
iHbJ5Nj72I70Bar0kx0bqhZXd6TgqS15z9HvjmPlfLgrvk5qWxl7vi15n9xSDZ5RZIIUG6dcY22c
AQV3UsmJPaQHbAn03HJJElwZNSwuiF3pefTqtHJYETIEL8LxC36AG/yeCmIBxUsLclyvD3wCsKvG
AwmwqW5IhVyH6nFXkfMdK9tlkZq/gnagCiwi6f4htxRoKQeTtRzMHAXoEQSjTIlkH9gjbi1DcwTY
Ch34noc9qww5nVbpU5f+rZKPn56/rVtq94lLuMLz1ho+AMyHQ7G0p8i8GTjW6Dlghpq9fpilCOfy
qMMSCAw69/JsfDK4y2dEalzUlTXXt6XhA7z6j2SEWwK99x5fRjFOTRU01BjgoQdp9LvOGAndYl6n
dlrSv/zOZjCt+unTeFbirZVqpIfgV7jH+V58WtO5UckhETm1m07q2cfT608ad3iR33Uk0X2uJoEM
BaLbVDDY8Oy4KSal/zI+EwT+Xt3dqZvai+OIeH47MCeVFs004hkRZShgtMIV49qlaaP2ghPINVKF
U1kx9O2vueANQLpbJ7tiKWKhSWr9hsXCBihgPpTbHO3gGlXgV8Pd/oUZUzSjf0c5PWvuWzKOUmWU
YlaSeGX4VocHAA8GmKuZHQ9SdsJdes7MmB+sb50WLARELre/UCDnxcG/BekDn27zO7SoNzOLy+B/
2We5MgPvfSqlAoAWSU8KP2lV4Thdq4b/CQktQl0hD7AhNuf7lJPxm47dtiZhNBIsegyOO8CI/5n8
IShTHIBVIhvCYUHaz5Ll0Gm8CN0dLM+S23LjU44z7CxYJ+99H4qVe5aFtV3Irb8Pf8B8E4bC6BeV
cKfYxwvsShDfE114NhQO6zLwlDWi/p8fePB2cNAVAFFHqnHa5ndfRrzWyMiBV7RLXXzoBIHVI5dv
vAs1Ssi2aYDIMTiGnmwpPCczODm2XG9OcTdp4X/lvvLfzTZERo1Na7MMiRp4oO5Xz2J+3A5tzjwO
8sfNSefnx0vcvwObLaJD5pwgWJMC9KWafKuG96KissIouIAfnQVeMRDjJRWS3XCIzCeoZGFLtm39
SceChDsAW4/Qm8cz8Kwr6NL+Klj72MtnAG5s3EZTpiHbVwNOqkMi+519EqgfcfBjFKCq84p7XEpa
OsHAn73E2NEQ3Zs1dwAy2l+AGpfQurG2oCO1LyYf6X1QIwefJ38SDUUG/s+sqKBeujACH1Gl9zSC
M0TOyRFdGkYuzo04gjtrqxWBTlH5gfY5DpE87XxrPw1mAtl1MIiglSI9RrOMPnWcO3NVT0VfwJ5Z
d7k0+71XSI2nUxy/0JUU/xRbFqxjrSW95N3k9bRoIrEXq+qP/qOkUp3RTyDZOllYs/RkVVPg5x9d
4NFlEY+RAdbD3FjMQ4XqhD+he7pgcitvz5Ytc6ZP08GaRcdcoTe/q4rKwe1hfeqUpFppGRGbebcp
bKbD1vCCSvErRGrRNcQQQTv44tVuli0t7PtyKYFuAPo3Y6RVopK7+xZPQZ81/zF+EM0rgID2OwrI
CSFdbrVj5fuFTaN6qlLVEsCNIXm2ISP6wcHjVXhiZd84OqgjjWwqy5t8xisheLKtS8paZbyS2tZK
cf2Qnwr8smNuZpziP3UVYnDroBNy3YeGnMJegR7qHqqMw+aHXnR+wa/c8pcIJ4uTsjeS7i+ekHli
xRALj3wvr9x+jiONTx3JmnL0Sk3a5rR1NUTswr+fJlvYxzrjuYoO/KfV3ZADuNh+DAbwALDUI3Zc
h+u3AnfWXDLYDpwthaErPoCRDtSDf4jgZ0Qcpha+mh4sMuU40lQdIoPi0FV1a7DWxz5Yk/TfLQYJ
kwQu/L56N0p7fBag7tuRQ4b3sbeDRQLoojZ82vfaOy4V5dCFylVvCcbnJLsJ5YjiPrPwyVlQlJN8
qm6vLzDGHF+jFhXWmQDTOyOgB3zggpdZG0G7dudQ07UWhu/Afg9rUggzMBWAD6wKYIfhy/+NjOxB
mdbbosndU9dtaJwiby2CK9etgsOznQSRfDz76rDdcEE5xjefhnlUDaXGEydJdoIWeF5wivK/7FEB
D1EeDtHkeVZF30cq6FcfVN3wDCrKh38663dbuBBgPcfVo+g0u83/U07CkCHafLW=