<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPph/w/6WnQB9bv3mP8Db84X5/I8lhtWF3R2uGQweFHgLeBkN9fyX3unwTbZp1huHCAaRMFXA
evO3n6qLQcGWaQX7UjrzpW/YwmH/tE9hOgLrwvzKzGOKwX3rE6H5VErFGen3u7w28jWemYGgAMpC
mto/tSq8SyW5JcwXGUlsUiT9X/fTWAQ6IeybTLre3eS+zY0pwr3lEtv/UEmLoB0J7+uXPgCv8nkm
Zq1uHCvc94gtUPgXP6mXV6xv/0dmB5qnDRmLMFfkl3Z78Es38Wkf2AQJCZ9al4CxP6i9jwWysee1
PuSj/sRsQCmlwCGzYzwBvcjLKeuJ2qAGGUGeh2U/IIthCPzss+ORgjaJkmP1BfqJ8wN3r06Vxi+X
rDGZy7+NNteV0F7fuxYkipT+Ko1tPgDZjd5md5LFcLuCSxQBH5Mm5jqmg97s7Edu7IPU37SJiCT5
lRNmzRGxh2YXBV6XKiewXkF/rgJ4TFDezFsyPFEpLy1tMnKe7mzFA6b9hXuztE7isGMpP5JJb9G1
KrFtREm0dzcZRBTZ0XpsfY8dT1ar+i0hHxl6V59VPUQnclTH3Gmm+dKZQsn3vujQoko3ThczrS9L
f7hhoMveIyRnvrFsXWFB8C3YPtZu9Y8rtDPietc2H21NODdmcrOM8jPW+yqpx5B7oNH6NXeP56M0
1lapC4xAryzjwYbgYa+X+syaaesZ2nXM/kRmIRsUTJGc5aL2skYfj6aJqwbXGyu7TvKIyzw89ZCT
uwIyBq2NW7Lufzr342xav1qI8cWYKdkpDtBW/tQ/+vIPp37VTOwonKC1YgSEfrRGymntJdtIGIH1
Uwtw3q5XVu0p7dlNO5rMu4m061ip/SRgbqiUHJgtV96hdpORR50EKC9iOqI75M5BCBUDv7rjuNRK
Ba5Uh/5AD3RtMtgL2NY6yGE83Y+ntSPHqZGn/GFXSoc0qjGenORWVmHr5uQuB4rv0hS/w+3Qik9t
TmDgI5tm9/yRTV/KndSi7KKHssY9fi0OfaEjp6RRkanFGTe27MvqWn83uw0RCssgqKI/79wO5wz4
ZcEvX7pukKD1dPxf7sToitpeNQ3gqWZLafXq6gd/WIso0hNEf6eJ15Uhxe1Elwh+Y6Wp/RpBEtfN
+1kN6pMzD3icb2wKiT45S9jEn1+yIijHXLAjk2k+D4ZXRxypBCKwOu7D8pTzmTAtwKboxfOGhuc/
RWlPMTmlGD6jmfLU+WQd5T3Ki5Cc8xX/E1wop01QjTW59XTSNvecV6YAJyiIZqdAGadgXtKdjwf8
rb/00m4ezAfzgRPW/Cqr/P+vLWhdjOY+t8RFGP4KVLygTjfAbQxtsrQqO4DzrJhA9UOeNbpqn/TS
kdqOslCeKGXwbrSmqGXU9zqo+aT0PRYyCrlemd5JJSXmrz2HjgRO4PwW/Lsro3S12ZarZ8IXVaAe
bQtfNBq0B2KKS7T42QcHrCK73Gegr0+AW1TJnhAacIFJRN7zx5sbVQPfQRLOIg3e4BMUN/h0HvRq
Z+KHlJSsbRbCWzKloTA6YYbB14V6qfsBKW5aJr53C9F/xmhaYjxHa4xngeKhxRAXJbGWL61HCqgC
vYxurvz1zbduJDraBuo2HSUuLXFD75q1jrXXYPFWsQAz48zS+Kg5t37S660mqjQkgJXFYDC8tNDn
SNnjK7yFQ8Kkw9DghnzCG7Afkp8YwU8IfksbQ1UM0H9fps4SYvxSIC++urIN7a0RPZXURsylfHcs
KB056aHi3mFbV3RgT64ZogEAwpj3TMUC7Fw23ZbA9KpmiPzQRx9AdHzPyH4Ibsumh0xINK0b9tPd
pg0MCHaYahQEGM62QgW8Ckl5b0Z6Wsv2U0G2NtTOZP/JWHucs38jT1Zo94fw8q7hHrpj8Ei4comr
z49RK5QnoNavs+K7GvEVgI0ZCjCdLKAYiTDOrtccrACejE7iPvnz4hpHt1Ip5v6O97ggq93lxNYa
bdjU9cMUVpLhW5T6nPzwbIwwXVzXT8KjHzarcVA+MlyI/EmuBdcqIqLDMSAs0/z47dC0/zYFH4vL
uMjx1q5RYWiLyRIFAV+KwoyqmFclc60GthIfHpu484xxXTdEEDYmSnI8RMrV5IQj4ls9aC0oj/2P
r3DGUJ4BTBCH3dCz9ueDbfUvZ+f8egH6YnL5l5VI4iXbhj1t0aRzSygSWcXCIHbDcoqDCISnAhrv
6y+hbrL1yt0zBhtVfI/cJTQZTbOY6kA2hRRAL9JY4nzNst6wesQ++BABlkMqjKFeVdyMrqN0UdeF
plpVaeAmASIgtJ4/FgrmkcOsQ7gmo/26DkFWq6G/ZCRzYPawGCP5+ofZ46diTWpDgNLhswmGEypZ
LdC3WmY+Z5o3s6o2pLajMifxI+2vChls/fcxPekda9TvXmrWYIVOgviPlbSuGgsUh0SfehHYPiGl
gR7N94WHvAZWzrhf/2d8qPa5XJJeAX5A/gvRlqgsso5iWLGHDPk0O6hsgD+ojNnIyFv0fmAYZlBK
HEg0QG6grbBOCx/mumVzY9aRzk5zcto12Nfkd588WakKk1hgDmHQihTkp3AbD6DBCh45/U6DPLOq
oG5MMVS/2rQ+Xuh2y7icxIieOVx/tyy6ATGqQYuIBcYJlknOgxK=