<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo+uqmtDBYWYY7H6BW9zrQZ5CdjDZLDSyEiD41YwPvUJBpLxRUXqKDicsOfARVY1gBrkHboX
HkFuxA57ht3mXTI2ixGeLq40di9zTfXCZogRWtFBgr4qGgSm+RSz309muL8cqnbbhc+rRNcamoHI
iGEFLuFXbT76pgI1ywXuXUI+JG6Xl1bcNikjvtUOBn6dPK5QMu4NdeMcj091pboPp8/F+ijb5gFQ
sjTwhsqOYudEfUJ8JJUyOdOmcuM1tzBuVnSGAu72LTKCgJq4gYZqF/+XpxxMjsjqRGWAlsKG9MDU
41Y51m+z+wAwEiEDHb/L6Arl/C16WBpmiPCj3vSFXF8csdIFt2CVAB6zTMKoQMJLIdgtugIzaHkc
2CZAwa3s/1qbwW1A1jeq/8ujPSNN+4HVga0wnb4gBwmjTwnQpAp3JIBHnficmIS7dUfGyYifdbMz
GYeQHhUg4Y1/hSDwtla28FLdrdKIeln2irM747JMXbzf/WPb7fnkOHkENul9J/Kzu1+2HsQVwhVk
rjNcZ0asiEbn10IloXeQx6sfw3crFy8AZzy8GIXzEIiJeCN/VrS+zvquvuGxGG9IkvFasLD1oIuH
IN+aKhcMr+2myvFm3zE2Q2jIW5YZO5aFf1C3ZsHH2AjJSz53JmD84WsFIm+zjKlTbfkgrn2Spc/g
gE6sPiF3rjse96fgZz+9gSYhM8q3Vm3FQih2mpHx8BeimpZyMtidbyqUcusgWWPYQo2WrMyBxdqk
MnjMJn+unkkZ7qkvtvnAyzk1bFrwWFw2ZjqCJf6lYsZc9vSBy82vQqnwvdDV3QVZGKvSKJbDGmAN
dmJlD09kDlusCWb0UQZ26S8Oopk8m9d/PlpV8W5qswb/4wvn+KrA72URjzFDID9tU3EQ9cVIrQY+
kiKL0WnLZr0GFK53lWhpavUVFx+tT7IxQ/3eXJ5lvUGq/xX8/Gg4+58fGa5umN5eh8CrO4D3kOJ6
cHe8kRImSBIQjyvS26GU/vS9cewMuilUP0OHZ4WUYj2CHT0INS6l4WksJSLtA2JWBpP4FaHRaaFC
3vRusl1rufH5M/+a1dSZYl4BGQN50cccfJLtYBhgbXzCcIXNUNv8mxAzCxe3FP1DlEY26X2TvP02
V5k3BWJMdeA/aW+8gOWSeBHJHTeOmMqljycIPXyMuIZwJLLGV7Wi39xisVjYQn21yDd4cp3I1HvN
O0k2L2NztwKojXw8Fhp7gI1kvK+y3M0txr7MXHv0wLnFMVLQtuZsij2zgYO/4Jd60kuBybCebptY
zUHffELkZZJn247leqgJtbKSI6ix2rxIFmDuRIwKmH0Yfq5E8eLkAfUxG86wSDuXhjsRna5MNrHx
rsr+JIymXdNn+g4gT/76B0BJA3ASmaFXUyUZVwWEkBiOabOExYFHsTbY9zE2AuXDvhAjYFu8/5eK
CvNQg7WW3qWTLJC8IpG+lKtGH5bAOVb2n7bAD1ziGbQoAaJ2JOHKAc9QGCoQSt21J/kKoDErPyII
6l2JIeS2Lp6u73/nAQXzwatRnQ7bjIldv+f84I9KzndBHgR0Rj07SRs5yYFpc2z0tPcUP8E5RMUl
iS/ljagoxwLKArUZ0ymzc5jqdJIhAoBKcId9bImkaojCbGvGAILf1FQGucGOmYqdLFG2B3FfkP50
//8l3Z5stGelKnuLXEP21WenLVd+dYR/PMcbDEHH5c4jkIOeep3POAeftyyXLWHHVgl5T1JFDphM
sKgr9X8TFhYQJ8/621v10anl/L6wt/Z1OyK8qL+AhVr26TqgZl4AznnMlYeHzjjXYOxDuEpfBmco
HORatbevQd2NxmmYUHtPOyUB0yOG3fxs9dpJibbBniDgU4BjLnmwiJOt1HVzYfzGROSZtQfrk/z2
dgLL73/JHZkVi0GIHCU/0/IundBgj7nEpbcY8wG4Grgx2jXKmejeHzx8gWBHjy8dSYRffaBM32Zc
6Xg52qAVQjPe3pAmjlO3EdOl0WumljkkjnLJRX5940A3uAXQzTC8eFVwJ6UriX4UrIcLFty1gNps
Ib+wibxmAaQV2EgzwYi+P6TJyJv1Cih3K5p2uUN1VROgQ+r+KisF8v85ZhhAc/FCRHeGpC+YfJFq
yh70HD4KA8erN1rBrN6bQS2P4EmAtsZkMDPnHlWAb6Fa1F37+eeAy0jN7jZv5amOpdc9VpwgrSzH
iSxJALY2hhdxdyiXV/OXDNHrxBDhqvPRJGmiLlcSu8f1LCXinnpNJ/NJD1UP1f/SqSiRtTNTpZ9I
ua6vW7JVhx8pglqAOcwapQKI+jTc8a+0jcKU2HcyoXZyWaQdDqjZZeFjMTF1KAo1MHxtsS6ms1Lg
iXMXmIgrT3YhZFspN7lUrFjG7almUvRO72XWjQCj07fYu9aAfzIIOB1qqMr9DTlOhV7Pb1j5BoiY
fxFQYM7A9x3aH+q8S2phOVP6sIlIhorUi2Wi1GAimKvEfI6N1FPvYglP4le2jRL8l6/Koxy7vby7
j94gE9ftESQ++07VDKbd3/SZ5asleSySrT4a/OFphC2I5w49D96SrSCluZbxXLm6CnwFKvLX3AlY
f8K5M/1sp9gUcav16bYBMzgdSQb1YzDxVfvqw4/KZfR320nS5vIbn5MeGG==