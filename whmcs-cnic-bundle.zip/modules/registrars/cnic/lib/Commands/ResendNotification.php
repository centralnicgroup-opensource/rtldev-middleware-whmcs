<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnUniTEl4Ghajdqay8RSFdEwXwASoYJfHEnH6XUCYB2Eqturr9JlTjERq1/YkhVSap3e4mMh
VjGtzTOON3605w75L4ftAjibH0jbQWpXUnIaN+y4y17cSgPin15SmRoo6h3U7tL3cv7pooU5icQq
DNp3b/dJVsHy2PyLduTIDsN0ZlRLpexotD/DY07q/jJ1mZg9VpL7dGYzq6pvC3cI+uOkwA8DCARX
y2MN4H/FaUAlccjMN/+ZlI7uLfUvZTNKTkB5qEqj6uMVxw+O+s6nlLSJ2Xv5SRycnJ5n4oXnAwj8
aNPdVNnBdQMuc7cOueH1TQHnvRPcltAPDik4VzFDuITbNlNZl3OkPCby5DDquwVZ9rxSog8A/HDH
tGSjjzED2jDWLtQi/hGhDoCHsAL3j0RZM0RPSikutygvi9vrujv7WpVs84ZDiDLN8K1keg+KIVWN
AanN/xHJn8WewIBmjwEcdLmrJdk5Pp4fRpPom+nHmDh+PsNgA/n6/JYuuswlyQJ1jKW7VSo8akN7
bjcogXFcfQEk6K5XD6PfX+LPLAFWbp6zCRPnr/9AtpTnkOC7OH6k0vNFCnAdqQJs0RcXmAblOkV8
ABFW7A2Jxt0WNuE/fI7oUZ5Iz4M49b+O/AGwZc/buuaWe+dE0I1Kkajl/nYzjN4p7UYThJeF003J
IlFqvuJlexAouPgw7OP/8Ex5T5As5mQdVO3IAbILwjNDvxyx79oQHytTlu4V/blaekH6bPzxqPHU
heI/GM3W+ZqZw8MwaEqlJR61QUhbD7EDbWQj16Qsd+HX7QLsezR7mN75whx2wDVSGiurkf9c/3GW
hq23TYpWN8LAX4ZkI4ix2Mq07AYoMkkRT3ai5yvcM1C3d9+/xXnlc7Ofg1gPSpS776fdZuijtDeW
+xFzvgUKra5fhDSCvuDi9jMQ7PwQ3wdi8IJ0WYgcu9aSg+lK0B/aT3hN4WgcXCWNFoP9WKxo0/Al
cGWzDDA9cBZoQNujZ4GMMmEoYAE4sPgnw62vxxhTqJaE2SbsxOIz6NUvFxb5tDq1eTERKLTEdZwI
KIGx0tGIWQKv5HJQLunQlVdPLBpfBWetPeRqbP0WqnKE32oOraFH6+8SupNxUyB/hXkPYiaVsoz0
79tkoO4hs2m1sIHeEHQxPtl7aZgrlkAMtcf1LQxOkcMW0KZo3SdBLuH55vbulfdL2GU2eecKKomG
YOWhQ2L1l4M6GNlHpmAqiEc9a2SQDjg9r0AiG2TZa1JnRXOeoVC9RMaU5yCDsPEgpcppMr677HXN
lKgvkryKq6bBV4ak0Uy4mC0LgQvlBNpsbds/EJ0RXOLtxQrZBjdmQLxde/ozyqXVa0kW9lyZdBmo
kRkcRqyxVJ8r4XJzIBfWyF7W3fr+fhVSf0Iw9Kf+ORT2DcrNC3b+phYcPLOboy6x5GJaged+24mW
/aAj9B0okM8BL68OvtDJJxhxXzA80NrG24773M9o3IrBWBI31jv1Vbo8ITPSzpjoblD9Fg2weYUu
Lo0OpfosapiE65GICiDFMfasZG8f2DOVhscB4cWBfrL4SDv9raPs/bycD5WmCW7g2Qrk2SxwEGn7
zemdC/i+uwijZegTphN/6IGYR8OilzAcNZIZIIVPq+E+KWBncptqhH3hpwZHUqnz3OJnsP7eowmW
gxwpfdLKxJwXvk2Uoz41SIr8+PUEtBzX6uBtZNcI+byv12XmnY6GeldICRkjhA3csgdiNu41OUEx
tWUyAEUZ7RAwIxm6wU5Q1Y2hwOrdx70fCFlGA0ky2twb63NdOGIESr7VVzWXohwkBu1G7Iz66ORh
wjnmeWOWytqf/D0qNKVQwImUdWoPe++5/WGUiEdyAwdGZvH7s8UIQgMFh/G3EWhXmdYB2DV9cPzh
q5K0itW52tLlVKtkEB7v2OdmH+FlvUmK56HsP/XfTU8csFAQHGJaPTDsmhFzaX80lYQ1HBOt1SwK
OoeGezsT4VE7g6Mup7dYg13pHxFvRfJpnSt0v1XctxjKOz3JHsiJyd7P6p7Ve2gtUSMYCYHdubY9
nesYP6+aPdxSUGVGl5J124qwny184PkSc8TcTIfLvxwDhGERIGuVrZUnuX75v7k5njwDECcjpsEA
VU7EB8RTiLUH2A3A2OlQQc2fEi2lK6/TD677xhLj2H5NB7IHQEJI6B2WwxoIKuvHqRC7latVs/8H
1keA+1r0CvGcMKzleAIiHtB9Ca293XEOHX9r23AIuYypksMwsRN5ymQMxGuXTqjlU1idv8qOXquq
BGKX0pXwYNEB7LNR3ygan5NfZB5afcDeN39Zb57k7TqcSm5seKyYkLkOdUO/S8E9DLEh9oiW9Myd
FugFLGk2qPD2Rh/VBsun2lexzPmOSVjAo7pqiFE4URS2TghfvmjHZAkpSw1bqVaOqKMQaMkwZ5o+
CDwA1x2NO5DTiJ3Khek/kEp5ir0UkfRkdVdKNCPkHy5DEniWmjb3k7IUdFP7E3ldTBGDCAFzpeAH
q3TD4r+0anPEo82NyGpv9f7BPpYAywW2qP5xy1/Lxwh8Uux8FOEXbTkjFK7KnjG/r+j2A/PGb2wm
cDXQuRErzga3PRMHQcOn3VS2U5rgzVUnE8nueUsG4n+FMsJbvmEIBQfPITMahtHFBW==