<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+UC9yoxNPpZGa2oxnwmDzzervO0e3iAei0/4PyLr/vIRmCB3wGKR+EE1lHtOr89IhP0phi4
sT9DY7QRCMM6cAXxtbCfz3bLDCM6pBuALAtTJsXvDC4gNZFGedXWwuN814SdoOcBmEZuDkBh2bx8
LG/HGfWLamKR5maaI+8gAz1Yf4lYWzDn7JT/4rIho/UJrBt+hI5SRDIBp+srWCkh3VokNmRG/zZp
B8/8d7JmRpwDUIw7dxq53gscgM4FLI+Y11MfHb3qNJq+iX0rSgIm6ilmbiDoPzI0lmpUdbJtEqs3
xIH7QV/qnuk7dD5Gvw3ylFohRXiOp3BNltGBj4Dt1RRW+4dH1BaHQu0cPpUiy974xctf7hirAPTp
Npgi3Yf5wT6FafOAKomKS8Kc2tPIEGxcNGbzOBrMPwUxivmsF+ByMGUBZgQPYP4neOkm4gytrS7t
0bU7t47ip8pytUiNzQ6G1G6BcvSEsTV+hT5TqWaHl7nWzESgZl9FJkppYnQ8ZIkfgTnsO6GC2MCv
Dd6G7c20847eosCWQ/IVt8o6LnpqyzvjwghF5npfiAIilyTf4qAZhtRmqfXqKb9FPqADQuWFSoPI
kirPJarMKfeSdRLALuj16cVbCbHWNRrk+zFdmrebJnb8tJa5FRZm7V1gYoU8rIFK9fdiNxPh3Clc
QdLN66SZ6QRkcXZ2xpSimojY4aaMYQ2+ioQZsz5BljWd+QaofsF8A7+mWDUAM6WMNEBpbbS4AArb
Nwqn3nAvpoDvY60oFflZdnUG8pIWTqo+5aYfeRwcVu21cplppTi0fzsqR+EgOjTy5E9dxbRtwsN4
jBKExDWsSyLgxjHbzKEvSueO+MwgbzG76YPLDx6381zNHw3HmQMaaqwiu3CzPN6H4XCcwGxmsxfQ
3UVqiCWkfzt+yJ2+GIYXD4o8an7AGhJWwhonYE0Y5hULK8L9/UTGfVce5eKwnaavNTOuYxw2QHGA
fgqTPMzyMzRAUnS4PhrMHPTcBayupu+Z45VdWjFeocKjrxp0TBB6bbjVMeELDLvdgGhYfYl9B0R5
BE825TkV+bvfEyBH2+fFgQbwFeMqMzo6xXpQEOTriOgyPZLtzE9opeUMZgzmgciUXjw4jEjNkmVq
sukzpkarzPYbilFcbFaXny8dz6jRD97ppSB5+prjv54UwYpqcyziUeDPs7Xm4Q2s8eRr5mq5a2qz
tB2cWmEdylJPU9j6n4KYSqQOzCnrGSNNeuCE9EYuiGOCg5B9QTCknzbRs7YoKsQ9bo3K/+9ELm2p
3rOk5jD4Oafay3xZBbKWL9AxA2vYrSQU4BFgN8EnM3s5KPJSCMukdAonWljVVFz+IYNmH7A2obrF
xIj6Us8LaQOooxNdC1r+gUZgdLJDzoHardWY/bCCn02BPQRRYO3e/5SXBqucLuNTWBVhcjatSdF+
UkjGbdENt4WdE5CU0I7XCoyNJLQY4TUPsTSOKMyM8mK2Wz4aPZdedkmGavkv4DsQoDJV/+QuKLjw
XvRDPNp/AyWTkcJMFU6bV2eJgxEjrKMcif0ULYXWZpWmmCra8Xf4nbig8CRht58B6RuuaQgbtnCg
RCIe6fZeBlugzfthE/jZT2JFsQRjGL5TDLTns91naotlten/kiJkELCw5txJxvp4LmDRxUI6shzV
IqUHfzdZFt1ya+XIfp/CYm8F/tAhgOhBRzv+bW4FBucDNca2Edt3TvJDE1gb9w8tcarMjuHulwh2
7cxHxR642vXGDZ2gCiUbjar3LI6zfVc1ptxj8a3zXR+2Ce4fPSLei1BOTBEr+RmaNwq/hsurvGSp
RzFr2svLimNEpMfuPoJo3CcjDEFBzuT7iUuebCX3gYkDhAvu/3wKVIYDKGSMs2JabDDLJu+cENHs
g3l1PMy+/aqXfOtkI3djLKrgwR9PKBBQHOQ5VSLExE9UKOz+mMp9ljEBLaKUO0iIGffqUNRRn/iq
oYhAuKN9NowasYfKXE7nGJGfuGdPo1hawP9u0d00uysE0gt0DEFrzYZzlXmE2HDddrpOVlENz8P5
apZ4QCi8z2YVjn7ysE3SYoFMbSfWDeXOIMDC1VBqi1wsIENG08KS0jriJ5Vr8eScJHMepjshROyc
n7rEJrTuyy0OlRHdqFdVEr4FabVKH23lLnlRsaF1YMnNGCnfc9EIQPTUDPdh/j0MvQqTcnrFgaFl
tz0iu9G9hZ/AfhBUN4GI3vSpWI0eKLxY7jNhgHIjBVB36AZ4ZN5wae92lbXhEaLK/pT0CdaO+kAk
///d5TfzAjXn7SytALxnpBYalC68ej+1OfSdfc7H84Ht9eh9qfH9vaCn/0CFbsBlzO20OF4jxosu
LrdJ8rRw9GrEq1kMMPyEcH0SzIAGT9Dj8B2ZFinP0H8Q/ANb3yXbbzNUBzxswESNeBetPWl2xbXg
96GkYEoVg8qnvqwQr8MJFvf6vTJUQAyeWVJAEwtxsebYr/hsNEfccfqi7uWmy/Lxf7czAnbt5gAz
0G+j72j31XRMonz6x4D7i0yhN66ZwhRfjiUbNRJLT/YHZcowB7ISk1JVVw3ZuOq8Q1O2mi+n6QgK
4WKb8KgoYvTTVkYL318I3tkHfyPqKUcCsOiruN2fIJ5CuU27aBbKLgjlUPtD