<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzulIIpulx43XUFS3qKXprrw+44QyxUNDQUumE9uwKNXAYYrYiJnePP13N/qgU2bxQKw4UIA
Zr4G2w8mpg4Nz50mI23NXSlnsZu/RUXcmK/gUjM9E3bwfJHjA/9ngtkaUfRtp08d1/g9pbEyOPGz
U+B9dEToSCBJlXNqlAdT3RmmL2498RYwSVhHZUs91KzkwH+6bRm13uJxJpb/tGmXwN+56JD+7uAm
H4ktsehobY8eQ8gJfJRsgsajssdSiIreGF481RvSKut9IebCxzBCMPaEOV1h6N9yTwpTkf4maHau
3ISMX3VJZWGKRGVkEB3NbMLIGOr4MzTUX+1X5GZPyNVNVZWsySiUYCA53kLol/oY+6VtJwV0FK+M
dpQ0oAy882PzWWsroAG2fYuSIZgX+7UcHEtUiXPevNatLTbecO1HB7eMZETqRsE82anC0clqWRTR
zSBAARvItiMH7iGLk9Cn1ac/uCr6d9RHK7hl6pVLU13L7nJdXsfJSI7EcGElCgAtKW0XYgpEuGlz
AOy3Lz25JBvPVzaw8CvvuO8Rm2//KLwZ6DHW9LNc1CjiWJfhgwJSnSH0q02CVP7Z5EijX8anEICD
QKLwWWBSug4uxzFlgVYSy8Omq3BF486ed7NnhR3DGUErsnR/VHcPYaKHzhwqZ5F1j5K0jCfFkxfz
tBCbsYTQljxr+ySlz6I26T4Vpi+wVNz3sHavnkKOjJOsFoVdPoCWBI2qnEwDTIWxc5FAaaUnhUlz
CL8v+pIIjJgduanz5tstL5zieKnXShOFq3uSdLjR0lKBj6ZjGf7TdCJ9bNplJdl4ejOJykew3SDP
YUhi7Kz2yfoTpjZOBJsq/4YH2EPArwvrTGxdapygzeCRr0dWB/YNmktA6//l6sOUC/FB4yYbpjPR
RP4x1O8VQnhcTtUGM2essfgIlmZQcjBZxyi6HrYr6OrWeqVaTILI7dErp0PSOvFeJ4qC+xfKWs8d
ubbY88Qp18g6wjYTdEHMIx8wtWDgCJeO+t7UfnuW2UmdtOqBUxmVdOyYqLWYrLihDm1CI4DlhGMt
/9rdC4I3m2VcARGzrenDfectR0tztgYTL4S0jNOIWvCQRI+K65O+WeRRhW55Dg8uGecNkJDqekYj
5s4Dc4Gw678hUulPqKbm5so/i7ll2r/dBeFxl+9jFIw4XdGU/gnzoIjqil1zA9F/nAoccIY/BhjB
bQcggw6aFgRIbBSz65nWsIRtKbkQbARrw/bV2tWbDBtSoY8TPPt+U2mWMlJWqG+qq3JceJMXfHLS
DXoKp1vFVKc2BGSPbo9dsZR59TjirKazGktGrfZFPmzijC02fMETmdheyzOlzI4H/u42BHQdowYa
Ho5oqiypG5awkL3v05RPrUzb/49qhnIAYvTKjnmmG6b71APdxNp0L6LkR7s071a7Zf2dGK3q0iST
C9Pcq8MPrsdrCK6D79F9G4UWxLd2m3R2rKgck8637aavdeAiZWSTB/kbnB3m5/HZJgDMzlvWEjgA
xtSblw7GbDyv+QiaiAQunFo9AafEaxnkSNFaJIw1Ign+s3aBLVDe+MN9+b8vIn36VTFOKK/URCn/
1tDmlIUUC7iOf03yyC5NMukwryVUau9d/2xcz5VPFZZeZ+tGLnBL2O3qnR091B1fkC627oBSjKXD
6eYb7FvE3orH4vmP33x2nc9lT0zEbLxAIdgE0Bfq4br7pTVvLKKqiGNiDIhirquqOQ5nbTnQoJfz
RS+c3BHhOJJYw9einPd3zRXVg2VZKBf8sWyFIY46KfU8wVfdEBEN5lxgZunIejCCF/Hy80TLzSwH
pfEddmXy0hSCILN0utJMByao6cqkc+LqFcv93nW1T6u51L7eMinLwcYEX2PPjA3+HahDINAK2vbB
2kxu8DN22gFVeu9I3HSjq0EvhhqE11dCI8QkdTt/P4hZFPSjirxCOGC9tJCYTOlw+AElrLgC3yu6
XttRZqqm/OjamjhDMozdYQaMQ7g8GW/LjW+VshiKa1XWYkFIqv9vI0rz7c7MLLNgXv4/DKD3UeIJ
hXitzkCkfABfKWz4j6d9Nha9grtvMsqMWHrJefwsp4MsoySsTYrjw1n99fi3If5umM9/ijFVId5i
B47C3nVADXYigi5R/gHra1QXeQkmyrDLmknb1fjNWT//H8ODlobzJV60D8AC0bNWHYaA8SLOM71Z
ax2p8t2Y9THKZAfJDa24qrEQPYrwMHclYV1xZ8okEi+P7K30nUJI2zRAsuD4LCWc8X9irvukJy5A
uWoVwwLj0LSRCPx7arOFl/trPW3z4ICHTm6hMNjIRswQS4rNa6V9b4ugmBL6barMnIsY8319vo1k
8SWiBQnbiDBUhzRuYeNpRo1ExcTXFKLKG4P/frCQic20NZdjMk0ekl0nx72wsopM7DRUAjFs7GjR
DwqkVpkT0V9yPXgevLZoe4CD+eDakANpgXfaDdZSMKbPCBEwe5aEVdmbvFMZj7Dtj3EgNyfjHroa
EuribHkNPy8HcbBPDzbFy/dxaZ0rP+5qO715oAAiCUaPEkOxAFVkwyz1n5t5r1cc3i6hnQtjiGuQ
2WBl0Awknyz1bqtwOQwdXs73D5WhMizSNnnxfbpWKhlwysyOuK6QYq48O17VWf+w1x+ydsEmzG==