<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoLGxvrXzjFIV9nwla6D4F3HdPBvGr32RjOoIu6Fngbt+Pp3SiHskkfMZ+FbgIv6XeIo4KKE
wjcYx+IATG5luqUtQiVURv5VTV7Xl7U2XRxpGTsJx2k3vcIpdQtpVRi0S26NJ7AqfPNvI1LCaCol
oha2wWChi4M8LLRNK8bpw0yTBT87Qi9llYFPSnqPniO85uolCK6WpFPLzYdQnvpT3lLL6kijgWTp
irp+HuuTKEHHPPXz6pk7Yqyntvc2bYCsiVOQ+0vuwW2FAIcOyaxrHkcg39j5Rz0se66sM6wRO4vc
KSzdQWRGJynHP6oA63duMaufhGPz9Ph7nhuTs+jXcZw+k4F9HV8RR0ynm1+h7jN5Hr0gLVJ76a15
X1O8wOrHv9JX1I7OQ5woVDGnpMahs7pvw9ORGMZ0kZwe3AChk1fxG75t6xZL8qWjRQRAwNLWXe35
Wxxlhmbt0AzpHCY03ImL1SpUxMw6i0ivoLfyh/nHR1Et8kKg1qrVV7Zx9I1WRnucIzcLUHndNLH0
r4iixjhc3ruOKWZeGsGUtt+Mogbr9uNFiedTPRDUWKN0koyzfqJzjfPDGiy8E3YhuGYd5nzj7YSG
Xy+z0qryVmiNtHOENeamSPDmSFrcGF4kj5VJSLqV0sDDbTGaMs+kyiUDMMtoAdrZQIxkwy2Mot+l
oL0H+u3Azca03/tS3opjsPhb9FrALgcZaGBaEvc/H6GhaIjuQznrQDlJclyU+lf2VIlsWEKI9T2z
xeP4rOf/ISJnfmk9UP24lZEZAuqRh7V97YlmGeFcRL1lq6TJ5zEIfhV1AP7t3taiPZAEObINWcPQ
mVjUxRQBbPS1bg4Lpv8MP2rfXj3c7ArdTFSPFcO5Q6oKPL6jvWAti742o9IAFK2yyvYx+dHu8RmD
czB31lf6Cn1SoE/Oprtig+pATvCe8ds2XZSrQ0JKsrasQCUSsZGpzkJvXznfSD687I4if3AGcY8a
6JRCNpZ1yUnD2tN/Xez3JWFhpYyCGlS9GUeLmlz9dtNUX6YY+U2vH73Jp12YviVYQ7PyeDtfgLtM
8/KeZbIR3C7Vd3eY571NYTPiWB4GMC8xt5b6SQ15OJ7PvOAUsQHnZD42x7Ofmjj4vN42A4AA1/rv
1n5brVOxH6tbyaBe2qOjXTN1Bjqz7f4NicFRFMTAR2Pfk8oy1IyCQNg9ZZEUrjOaunDln3ZsJ+nZ
vcFfCRq3zuEOAwIrzpD2/m8orCzrPgT8RudqffM+RcBPKbGOgnyVl4XXtj3ycbFx8ObDAARPCgSQ
cc+QAhq6dOkJqJKsT+bxutwp7LBGU6jrDCLoDzrrQfRezdDKqpQ2RV+op2cHmz8364MB+LdegvN8
S1PU0aGjsaZWRVbFa7H7V5gA34uFm1NWOCemBmvyQaOvwCN5GM2SyZMXifhE6tUiLvi3tZgFB7Cs
otqYhFBvRrYcCwD0FZvPpZJ8U4Q5p5+0kWLdjNReO5KIKU+2DYsx4lD0fiPmZrqHKfV1LSHu3LZE
Rp18jQz7GvIz6J0gVrC1kUIlgmH+N59OnOWPu09QV3+ctBOjTIIYugU5/weHIufEdqC1sJsIFVRY
mMK7UevgYytkihBZ133+bP8A21p38yH/1HYvcGq/LlPt6EN0sDEUGi7hbsh1pGiiE1LynnE8PCn7
WB5W2sUFvp3MA+1y9oOFaOAAuiF/E5CDvdeZrlNMvQcnQ10OHDpBLtNiA7wG+W6OiqhudvmV0Wgf
S2MGFV1dZmvKWaOcELKgZ2N5DlBXr7jNbDb2b5AarDHjYnbILFvtT44nyo1ySLu50FuGZ+diCrHh
CClNllV2ztPAvmU1quPeBM8tLeqg8Uzv7pv6E+njdPmmsEVYD06SjlZVxpyUysAX4UsIcxK1EZ7j
UFXUV6b2GkEQ5PIC4LqfhaWePPWpZOpKZTmIIXNlm0Tok7/ysxKdVcChFg9bb/KfeZdfw66YjVhF
+us/HYyAnE++0utzt111Lb9gzLKuCie62EfnpwXlFnaVpi1lFMtM9+i4ACUUBcHhlt5zDaC4cADj
zeFKUpKTMaSOnt+bNTK0y+nA8orDcvuRlEh8PXJ8YY533+O+QUlKwu9PuLTPdPILgEZ5+k0a6Uz5
Dvlv8pXNSDuxbJXgY9mGw90mYURhkvk6c0NAS7Z+29ujS64FGqoM3kUa9ycC6C4S8fmENSqLCtxX
UoDZhOC3NrQvXoQcq8YncUFqVl4I+VfJUvR2xFgvo80znoejB6cHqYpoYfAidU8ajk9lq6/40EDH
0mj4ztbqm2w1ngX6vkR9Jvn61fKc3KE9d8eB1PTbiTyjPxhmtfyMHpHZVvw2MSpVKRR8Aq5R21Iu
EobXzDDy+EC8Rojd49S+quvOfAGS18/X5IySrit6SX3OuIXjCSGNcJfpNPqzr5OBax4phEyFlpth
53jItaZk5+HrQiGkCZkA5cwPL/wmzgeNB57BVYBcJcKmfCq095rohUWBMkOZsqEz9tIWqjPus9qG
KD+ZkgCLsF+8GCc6EJrzC86bCLB2dnCFi1b+WYorddgGWRDixrfpypFCETQqmWVGd0aeAGmTJ6wY
MERJOtvPE6s2qhJuRsEe5ezUlIIpKZ97J3xjp/iLkP9hKqN7Uto5hbbzXFsP0ZlKPNHmQwJq9wd3
O048imTflKfXyrW=