<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;

class ResendNotification extends CommandBase
{
    /**
     * @return void
     * @throws Exception
     */
    public function executeContactVerification(): void
    {
        $this->api->args["TYPE"] = "CONTACTVERIFICATION";
        $domain = cnic_GetDomainInformation($this->params);
        $this->api->args["OBJECT"] = (string)$domain->getRegistrantEmailAddress();
        parent::execute();
    }

    /**
     * @return void
     * @throws Exception
     */
    public function executeDomainTransfer(): void
    {
        $this->api->args["TYPE"] = "DOMAINTRANSFER";
        $this->api->args["OBJECT"] = $this->domainName;
        parent::execute();
    }
}
