<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/FXxeVQOTEeeorxf74SkOA9uCdDNTv7aPou9ClvtGNMLPxvTJOqhN2hnHWr+2BPPckQZXJx
h0aj/mGhN/C2f4UnX9av9JMkhffR64yB3Bdy6dQc4z5+3EaX1J4zSLnB6JIyEnVen6z0uy+fXILK
fgcGLbK6gOUTBsc/3AirABcNf648prGTbYTniz2VCcWQWyUUBao6HvFMfn43b0Ja/XtuwFUKDuyC
A2mvdHumnRXnxAXciVKfZX8/S3V2iPEeoR26iVziFXhP3NoA6aoR1ZAhpUna1FQCe/RgfDpllGv2
wuSS7+Hw1PB4vjxNlgTPz3Sux4TMC/s7ZYzuJNpwti3F9ZES21pVy0ch7N7Om2nF8WhVUVLZyw3n
jQVStriq7PMgXRkKxYsAutC1+728KedE0tVSKYNnPTSaElDirMsLP4lApTPcY1gJkv/l1uHYAMpH
eY9NH6cuKPNPkoXCe/PN2oRp/HwWhUtYutNRY7NBVns8EzTXPxlD/7u+Rl2uAyGCWMUNGXDbLGPR
Gxp53MD31ji3fSfSVQbOG8y/UsZFWy1zOkE1Fv1h40ktac7h7x+RQ/rpoZzDT/21+A23V7eP1BK/
gHAUasdGIG2HaPTzEYq1FHoL4k/vr/NgxL2p632J2o1rSpSm9+vPdYm4uqna4Z4QfOP0KLKq9uPy
5sGkTwRa2YU5XwEbL5uceIVesZf1eKq3FUgzbqy4onfqm5IWzsMvSnmgaA3fvDtKUw4aLjfoRlFp
iC8/oiJq4fjie+q66lyUi+zOwQlXjKVdg4HMEsnsGLi1N6g9LHm+WhYB3PDJQut+zKdwjhYVbgBK
BPxcp4bIuwHM22HnCWTjvjZzMTOE0Yjbriu4bHUJAb65ZKllNkrs99cHww0oY+ykylyA88bka4E3
3c6FBlG6xF9etmDfpWrV4UF7QXRb4AEGXkqzfAW5PlZQxRk4M+CptqPUAemD58N7v7Ocp15YIvZb
9vZZWX7yX85u0facFwoFYT9b8q10idXhKLqUyo8gYh/sExZONKqW7elAMkJRq3t9NZPabF0Z0KVi
zAzDN/Poqv4XIFykmIn29vtBv40l8Wo6W78jCX/JgPhAX7g1AFX9vQUd81gQNGlk9Ye0uiokella
4jMl5ewwdL9dHx1qJE1aTqCnJSWMl72OnANrISDD/naoeX22yN59WRNwjPaIetW60xpp3HmmBrhN
Jcr4x5XAc0gt24zcpFprduOdKgsrY9N6gD3+ZSlmLvjgqiOBNR93S2rBkjGrCs9tOsdmLzlmgRr+
V4whSzoje3uph9O38gHDPuMU5frd0k7f1Fi3kNwEDnCY81rad9md8vDIvDazk1zUlc8JV5P0ro2k
p0Ma18VV5rpGUAnHe+QzkITE/afWvo5mt3AM7fxSqdfC1w5I5t3EBz8CukKGsIiQn4jC9nLJdbQL
7GT6/Wde4Mh44R4SUthdQLl+uK40eFsD7D2aVemFqKvcyLofc4S6mpB91YLsUKh8Ml4gumwJhHAZ
A0AjKyhgdBVxDo48/SmYbwNrgKuCt8vNOnVAy9og6hf4SEr43z4v/yp+MxqSiavoFk3w/ToCwBc3
kgFTUpWYoHtgoxcI/l5NB8R8lUXmVo+TOcEFU/dTqRRsssVgwSUPlPZY2ICXtoafPnUTBED0GUOr
rrCGK2pFwo5j85PptWh9yc6ECZXHgqgVySqalq1CiWNNxwA6bww9Z6JweX3itngUvS/POpDt0F9i
veO7XN/yS00Rt/c2dJZDzAzBjinkQUS/FYKKNw8X+eczSB2bEIZlplnFml49QuLD1YYlQhnsejWt
zUOS3p2RvqzDIXFybaeUOOMfPWkjrFeXyemPk3yJwgg+SxGOtRD5yj9EJIrQbz77qh5fgaNlNt8d
J/zCpqFJEcpDprbKodihNmDoG6ft1+dbfUEd2oRtrOHIGyhQfybFCKCmS9+aYB30at6971XLmX34
q6Iu++GwCDEUzu6w7UJKWhweB5R6SOCiUYGp4+gSzjoyPgQAqaXaFJNDXueWQknNxLlqtibR3Qb9
g3sCjM0U+5Sd3AZloB7SyfI90kYNXY4vpBY0k6Vwdm8LitK3ZMgCJsSESHnNTo0PSoVvyVXP90T/
Zk8ZMGQwTvjBat1x1b87CSqpJSHWuHnf7VZYIxc//Tc5Yd7iHBUUBYgetsXJ+hBLmGmbuM8FjPsm
eIr/psXNzn0e6g+AyvuTa+sU4vNQm+9p5YSDdmv7eQ3pHa7ssctcBltEMmTF+uI4XbAY54PqZLrr
LJurk3CLOy6qn67kF/Pi0giM5dfQSCphO7ieYIVy+nIzW8kq/Kzpo39hSyf+C4jCcAzIb51JimjI
haq7dLL/BEDozyDR7ZPPYP/1uMOZSV7P8hsJ51GhaIywvz/6bfZhWvwXrmog8pM1iCNAqCQjvCq1
I7qK8nwrsWp384QMIxQutrblGBEQFyrA2fDk1Pb32Ic2DhcgRjfhMhnShIuBlJvBeX3RsIvn51ms
0JNDUEaSSc4H+bZ2yiOGsdch9E4L0+6+Fv6boLFQYJAvTi2yU64gokHPiCyTm9t592DUIm43LlRZ
G9M0p2QBVaSolzTMUfUTTMSaR3kOMT2OChyCjdFjk++QaoyBs+KJsxK146tKqoC0d+0oFTabzICU
JZY/36vOmW==