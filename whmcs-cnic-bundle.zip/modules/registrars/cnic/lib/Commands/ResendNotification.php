<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+c0OohOHbWEfKps2NdDq6sxHn7OAuSzY/1rFymk1gC6xKp9+Rv7r2Ar9kx46MPF9GD/AfxU
IhignjJktwRD0Gv7xIP00SsxGeImkbhY5eFIEpJsa+1NnBrtdi7wYgtOk2Ds3P/VClfyDS6qi/1v
QukIHCp9+saw+q4voRwBjRVHYW9d247rzI2e+vqee8xEdqBHLDMjBPySE8GlpHrD6N2D+5jN8ryI
bM0kuZQpEURvKCj5NEPdM6AlDLzR35MH289HTCRVXwSEvEPZ8/0h+ouhyRw3QpAgYTkk+WGuQi+F
afqdFWihaUyu0bO9/YuppPv14/DH/U9RqTTVcBetPqCfJP17LbtwTP50t3/KO13asDxjA0zGTLub
QNQeUwsTmk7APhcwMPILUFGp0w3Qti/n1mduyIvaSXVV73HZ6ZZ+KhJERwb05kzt74TE9+gyaSTO
/TORroydJqLZ2IdDr1uSM08biME1atBV6FJ6Q33Am9noLjulLDwPKClXKmrDdfAZ0owbD93nKb1W
JrLlEandRxwPlheHufLC5A+WTc+H3R6wPCbEcfzJ+7tIgFUbqe8taG9H2WL2fUGFmmqfUNNyQrZN
pM/xD6EXMJyq2sUzoN6373+8sn7qVRszR78dx9jqJRmfLGCzArqa60DLTcg6aote3TZ+ksWJs/Nt
6ljVQB8HBCWmlq30kZQ2Az3BIk5gHVUTyrLON0/cPt1yp4STRmc8G40AVCpmJzVnzktZolUpuvip
CdM3uNHxkOuMe0z5WCLkwCgmLbWVrg+5ObsKd430800c0QveFRfsKXzQYWKmU2/uTJBlyVzanqLt
QvKeQdfuOstPCyB0gGoNJ2vcmUKOchd3+7g1AMAdN/W5lib+42HzWdx6bV+Pe3HSY4y5WH3GHL+H
WdiCtuHBbdxaniq0/ieuk5Ox+XVRcMq4Ihz4TrVMNrS5uOC6BUjJkru2oLS2jTr1V0PAEFjf9exs
RHF6cvH833W2kzN6a3dOoWnid+vL+U61ZPcXokSpC1uCIc0VfJUjorxbARJlimwyoR49mKjAmFXU
PQB8wWfRbokyS6ZATfjWR7v/snyKTvDfy9/bsbuX96EjsCwLDC00kQEmeTX1S0tiP0gR29OaQJT2
PRwSXiSIt0S88eStOMOo2iw2bWp2vr30zSfG315FzAmxrl894OCt5cM5aszyBv009UkhOXTJIYu/
U2R2TZtN1PCwwdaX424TTQo8yyjH0S6QtWKVJnUZzLoSNKeTintaul5Htxgbiiq6U+ojBAg5xM5D
S+OYcPT49ZRrdxRS+DS9NUcv7bZSNxMauWFVbUSxVpNAnFNnz/6174oFnaa3HadCz++7ME3be3ho
McJePcXEzHDEwHye3Mx0R9SNePyxMqgGmy2xqKCv9akifLAxRGtxSrm317r9nigl/drfLQDkXY/e
MttrsZ+CXX4A7aPBpFPYOMW5uGisGzvTgEPD5S4pSeb/ukPtkOk4WOfW6fQ59Q0xZpHoE9oHfXex
LNDGtRmc8vZqdmpH2EFBl1ahPmduhLdXE+E7yISctOHQl1GUWzsQLdDkmK4j4bozR9hR8+IJUCd8
WMjsN1sbRErkJRrq9XskgbrqByBRpVXi9yiair3/XR390SoYvxmWYq4BBqFEv5bNIBX+0AZvRBRW
FkgsWNurYlxDSVk9/B4pnhKFg8zKnSiO7w6cVSd/4UWA8yfTtGGW0az/7PmeI77hmbJo4GAK3CMO
cZ213HdWKlK5Aq5bmShIcfPxvn3KoNFOG3BS8RmYGakoBT40moPE/lT5Q9ccALeHcP+Q52lYGgk/
4m4v4Wk09vZIuPywAk2VBCOjHWX6lWlkSeifjyPZ7W263zU/xUFuW05kEbqimWAqlD/o/cJL9dmY
rqEOTygj7yLIYZAGN6MDXDzza4PdNVfHF/iN88UXVatqAi88EYeCRt6zjuB9xYqfmOF9593A2pCm
8nF837SAYg7EJ9nZ4rG9Jn01FwER4ATWylFpqaFkg2IoTwaMy+UQCl5vIj4FrtytK/EdbvtkEjcr
/1z1Swa/8ggd2Om4+EuhTStErJip09KoYdzTs205JgaszAyeQrpEOtW4WMRCvNHloAt5hOeseJV5
THm35jZl0mbaaMgVxdozs+QdxhRz0TTo/P0lkN2hRP5BARLkodXmfh2sSJ50w0+z7aaoiaD1HCxA
sYP2hHlDi2Uv9QtkgeHC7pV3ABS6eiHM1pcewZaukGBGbp6fgi4b4RIZxlfgwbriowbi1dE76R9Q
Bwd4TkQGVU0LFL/sph44PacswdXbn1uEUJg3kpdbKyNGhpClBllOOK6zNTMAcB1I10C7U6hL0U64
ZQfM8iba6s3azU6ntydtzS+gBi1F8khZHFycHNG2Fjqx2waZ7w0B2ttnKmni1FV2EY45WnPbwD9C
eTtq+OXiycDenETHYbLwwAXOoBopyuoleqWmw4gyul4IGobHN9Dyzz7vnLJl4he5YP2nfe/PXH7h
WLR/oP4vbmGjBYbR4xRTO2IDyewJQdhTcz7TS9xuN2u8cXKv4oUbMUPlv+cFifEG5nzYAeha3P+k
Hg0fQ/j7XQNdbUD9K2ZGS8PO5IGtPUpjuhv9e0PjisqnYvyK6Y8HaWNsFtJxnFcKtCMCtaL4Cu6f
uTh2FZczitLbt0K=