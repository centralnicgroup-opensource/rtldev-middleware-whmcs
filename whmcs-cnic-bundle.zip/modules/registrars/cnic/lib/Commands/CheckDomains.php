<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsiUqzLDpoSQ2DD6ziD3PwxpXDL2d2hr0hwuwJvMIHMH/StYdgQDguRG+K1vAmIVorWsK08T
zTsDc/tj648dN4ulEdaGIIWlnnaoli8eto5dKgqQAMy7SIqUaA0NOcB1rKFrJCN/Kxv8d9nfHk1d
numJ3oPTxkWNXr+qg0/46PdDqKWOsN036lN0+p5yr6AZ9H4H0Bi9rb6G08Q06doaLyI95jgoGH3s
XF9BdIrgfLrrEGOjB4yFKZUWJsReQCpTomVpKFHTFJwo43LofB0Qo/2MmqHY81M2lFyGkKoWTOFj
WoXT//u6icl/Psd9kYyNH7/Nfkdo7eJkrJMYl96u4qinev33rmIwlgG0QhUHRhsTvRDgkNArU3dQ
2zWCyrXu0F+9tXSIoxzPlml0SMsapUGZo/BwwW97NnXhleeavtp5zr+0oVzKJ76tJ2xCE6+wp67m
pdi83GvDAZqS1FW1a03uAqiBN6ZZKv/AodaFYJEf6MNPabut3upt72i/TuZrIw/UpiUOVXolWjSx
mMrqHpvJDCz1f5p7vSklg7FPMFROl4iTg4YphAQ6sb8fU97l15Wuy6UK9QgpV4MdDsPZJ9KAYgSX
kgsu8OQZVn4vXw34ifgG/YHliv49ZhJoYpC0O5fIO4N/YrArShWNVLlUgej1eaoU7cdvzcWm/Wzj
PTHk1o685fd1TdQQGCBoL51RL/iESv0zzfY+tAS6mtDJnP8Kc3h+jw0HJBhOraTnTorURccJZkS+
691KGZ86TMNe5v8JG9/MVF6kA7E8lrua7LHqW+Rql87Joi7QSG/U1+k59KRQQcFacaq+qI+6QL0j
v7dwFrWnckp8kJIoRgtjd/skv9bbrj8UxAUU9MBoLC0FCux9OcUKKmOwyV4XODaBqlo2FOHb+sX3
SBBvpD25PEtpNlAHq8Zhu78uCI0W98WDKhCxZ0Yi2BBFNGbr22WO1QquklDizP+PM+WpPHQjfoh3
k45LMF+wvpEe71vMIL7/aP4Ohvg5+ZCZIElsHvtIeB6R0B6B7GfIercE9z2KO/Wo0Za+p3DDgIxK
wxhEneePb8Vp28I8EcwGHTGTIIsQvEp7zk+rttDAf2cRExUKFPcHpVytZ3amVymLBdKKubGR81X9
Ftc77FIU+qViTS6TG7YsgG+Vos3URtIgmxTXlh90vIP9MsfdRMaDEBhrcMFkMUCA8WlCVyOMZRK6
3QjgcnpCLjeIsDXRoCo9TGjnR+W1RphzKW5o4DMqob7Xlih6iK5lPR5QWmzjRSeSETsQqe9aNTpM
OD8WrmHLBF0F8xyixWMeB12eXD5MCpRbIFKv3LJ0XtmQ5uk3D5cBr1F+TZ3NsMD6G/cytWnwdntJ
cj0wL9SidPmADUjZmBJ2TNstDNoCFxuaMPiu33AEtU1mGpO5ZKQXpBjmgKhlQtT4ydo9t9sIUoH/
zXvW8CFF1/3vqwMavzJu6SZTdSAj4WZVEa7Q/AzsC9hhKvAZoE3MpbXKTbWU6JE4Q+cNYLYRo2St
Uq1gxiMh0PvKzbUePTJLBq4iRjpSYWB47lwSd/X9mWMfYtj/VGuYxzLw21PO1mkh4bjcbOjnWgFX
yHTJ2bUCy6fnK2+t5xrawcQrL1Y+RuLBmBgqhLKPh0ISzbpZwncLKYFALzHhx9fvjKKR+eb0mctd
XTs0YUYw/VzX+b+AJzwc4P9O5o3Wzr/SlZBMEmCnWP+nz7oWvcNf8RGoui4m7UcC4G9HibmUgKNH
QJvGSX91YAwZNsQ3POLeFbsJjHbvCy1bnx5q9KgzlWZVQzYCifNyz46dHWNx+Y5oqCVR2Ld0GgYC
+xkKszNn8NE/9aY5JO1J6YbZfJAFvmsC+yGzyJPvLzbd/Rf0dq1cT2LW0tXUrfCKD7/eYD0ZI27y
cSNsuedcpIsrt0Gg7+2lnDvVhnqShsRABJGVAUAq+Ndty22XDMwk5fsJf1gCQlcBgjsQGwBqanul
s9zSeqeMpmc7tTctVpGVG32mRtEuNhrvEmUko8kyIOET+7efaxujiAvmMlyNq9xQrPVmHncOsGUw
bP4966bKJRYzuY7H3Vi46cz9BQec/c4RRAymsYeA4t4KSIQ2x+tjHxo3c5zKvS/zA29td3xTCRSf
LE55/lFv/6m1maLzRDjpPxRyco+3iNRU8Lgpl+t2jaYrjq9Npa95DeqeHhuTUFPE0Ngpda27atAs
OwBb0vNhy/TT35pgLzLa2Wts1Ljr4oGfGwMso33Qh2qNqmlcYQAW6avEsFmBMYzh35M0rqN38ujO
hln4iND7GSzNbodTG8ztz3fEBA1Uzr/xFs64gjReBLFIiladXlkRt5I8ECwLjLGiI1GQCdprzg5v
BKvV5GCTyuJzkA9zQefjwWOWNx+IQzPTpFlyH/72yuJbPOnl81rJ23hE1rnrka0cOj49etqoydiA
Es/EBJF6WofMVIixsfyxUyj8nCztf/Rq6X2qTvGzisHntbRcw/KHGRVqM5eNYqu7KHnefUt7XtvE
i7Pe3sQa5SC+z8ICeeAzCM9aUSQRHsVQy53Dcn+6M/iGl7bRUmK2RUgoYecqYK7C+FgtviBWUC9Z
k841nA+r3ZZ4yGXVBxcRfUYUuhYem/R2zEwnNxn+1xqqEr9sSmGbwvj53rE9/lyfW+J5KPAaLkuQ
/o/a8NH92DltecHkRnOlZBsAl9FijOrlOXJb7yyM0iylwvfS5UAoCNYyUMtWjWGFD27o7BuAHtew
gZDwpAWwX68IFy7bDLq+/ggqGIx/D+VyE2H94BXmFgp8Hl0KRcU755RdtlxjSlieCdz5wmbA82Ci
a/CDL9uNVGROoiUstJRwOv8WSwiJ4OkyZ97Y97zdbDE5VchoL+5MbUVRp1WMDNOtFwTSL1KU52VY
AahC1EJlraT9lD9y7NI3HJSPLvRcizFT4V0uyiEH22LRrFrhsud9gBVjTxqIVk/xV8ynjGuU5zaV
g3wEHCf16FVyh8t/tomqM7/nm0/fW1i0ZCIdBbH0m7Y8sbT1Qt2v7jZEIWX6MwQs5lqH13ZRG5N7
+uz0Frn2CarMUdsY1Yf9APzExFMrIGykoW==