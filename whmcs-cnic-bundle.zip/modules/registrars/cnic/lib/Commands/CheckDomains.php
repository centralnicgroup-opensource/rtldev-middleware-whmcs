<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqn9Z2YE6NKFLuGP2yS4pGTQwiq+4I7pW+HZqoq/5wwMBcI1VDLzxgxp2O9GTT+SGTFAjxny
+7WF1+5a03zuM8Yv7WirK2jfa38NRoi1PnPtRM7FiikPGQgC1pVW8oxQRFkUJeOjvN9mJy5XWIBg
sKbCnfaT8Q1sBAB5KQJBxZ9lIhdm16uoR2U89lyWMt9Iooav0TUrs0G81I4pGMsyxIfoiQkZCMUP
bskzjmpChVjAYB4XTqmvXswz0Yo3e0TUDzjfbdxjBHk5d++lcFjXiRrN4meUiL+xH1WoE2+RtNp1
IB6g1qZHWv9RgNKMtQLryj/q1p4QJEgaz0uIHWLxUclBuO3A4PoBVw+y4tAjiyXhik9UP+y3Rvsu
hn9SXhLijmQmW8UpEFLwMiCA1RsXo2UF2p8fxYRP1Zg6vKSvGfqa5ex32Hiz22AB7iJnxwO8lYH2
3Vq41lQBMA24zZPbQTYOVFn4Gob02Rdz6/5xcBMAa+RxOMdndaafxbz1GGudHzmDIKe11y5ho9og
xRO04/JBgzcGG+Ed1/vHJSpf5ln1qVVRvldVfBlp/lNINQUXJEDrML3h7wg8/p4jYjAuPIzHSKqe
IHnu/VwFPKwwxTeVZHZN/mKvojRtjvog8zI/kY/UNayzfn0pT/+IfbVp9xFJMa75apORcaxV4jrU
S5QyCcRSWtW7aGiYWk5SjH2FrEF0HJj/PsWEHGbSlGxn4Iu8fnuCMW90r9DyV9pKXpHetk3vGLn4
sgCgO0lPQ0Hu50KhqxUzxJ0m+5n8gdOY+Io/+77jDSHGsxJMW4T8TlsKuupKM1hyerH+cyGxckrU
WAV0s9SWvnZwZCxoqpLk0fphaoFvoZWOVqu5qVbqSPtTIiAAXs+BupK0QpkYq4KNjd00Yx3JZbNc
tR9d4bntJRySC4J0d66aNUuuiHjUOwRHAYhBXai92kMJycsJKiK2QGRUqeMFrK+ZMJvUGmWLhwIP
EUekChSjMjGp/vuvczLSA5+oICFjdkIjptZy5BoErI+cjLsqbkC++gWR3ytmeynyQBU0LFd6uya+
gGrS0B1P4oo1HC2WBw4cow5GDmxtQne+32Qs8oedjz9bMLonWCUXr9zgwjlwzsCiiXA3GewZD6gL
//jjCvksqKhLksHK/woQ8l1Pp8MKb5jLGl2R/p37+f5KLm+mHYBaOaFuSnw478LcCHRQnkX5yscf
Na6vOUmKKTj7yXrhitdyOTmzpJ+ulyI3P07qjhKuJTc7/hsg2lKuMNYLZfQ2iGmSzvDbOnMMIOOP
oRs1oqlla87K+alwsdUzSo53MJ1sy+ICmqE0XFSM84ER/RP1MNUhjp/txA7DCUvZKF21fyu4iO4m
OcAgFKcUozkS8qGsbTnloeoGGq5NEAA5qwFxBqr6Wu4v5yq5vEGL40+2UrK+fkHAIAj5clymmpu1
dTvcm2SD4jtBfp1ASDl0tpA+3d5WyF3E5YLhKivCjdkf/5NDMIQBHa4lHQaG+y5AJQUUwWq8y0Hg
f41OO+RoLjlSTwuuGhY0cWn9/xpZHDbgMrgyjMUP3f7BX1BQZDtybneOKwwsOSCKvmvhPVY5G9Fa
BZilBXmWpd3CjiEU94QrDok3CGwmY24oTQs4dYymE9B5DEn4mgDTE2/+Y0k9C/MHTNPthkeJuZye
WYjuV6vRHzdSPefVK/+KKtobMSgM+npx7kcXdqo9YpREf64gj238u+uDkjebqDV2zjwxoGdG4+DE
6hDjMYmO+3c4N6YrrvCAeJw9yPOVSHaGfFH3mX9k83lUGHYtDmabTjgyCcdk9E384zSoFSejSo9n
kOd3HLPMQle1VhJSeg41NXjmvvdVtMQ7qobpmWAQChd/jtTuw2bkbkq+zcizxeKYlEvVAwKL3T7D
vFdznvogIL/ZpEA4IFRjc+aNZO1IjCKlDQqaXe2f7gsErikTCVXf/fqmbCyeiQUClMrg2gHRGuv7
fKgvb9hnxmLQzU3axmBPSX/UPFLT5XDzBNAlzqZbrqrvKgVrlXAXcs509CpiNwgTeAkPJ1NygqyG
16tbZS6jHaRBT4aSwXJNfsMC0j9cTO00QpBYQQI2DChBzeEAt0TXnUXq23yKT7YxW72MeXwF6OUZ
FM+kE+jF6OX95tBQSW082+8DmekGSQTfiyMuXV+bjU8pcjzKfKmcOzMuQbk9EwWYi3zCJvH1KRVb
vTmhy4XxfDLmu+2kPoshpSm8bIZpFbu+Jhzf3VqK0OQroifL/mr8r+JA3hXZgBxTpN35x2GHDG5t
+jw8953QbcBYQSsMA6N0UtYlSznjpYSoZsIQdaNWwPeijpIYnyF0l41Osrttfc1kkGeqRpBA/5vb
NFezL5Hd5YzdDeYCN3xXZSmtW37/pWRzY7uSrdQRxnQ5c3iVWc4nHEr0AR8i2CAhxUIiW7xkLdJB
GbVcNmTWlW00qMC7IYiLlLNVe+6WQJFUrUHz7ud24oV4b2NFnoE19P3N2fVqquprUnlFfl3zyMdB
NhWEaN6qXAfuPz3tw/GC0QhuS/rQFykFBmY+DZ/R6DTasDLReT8p0agk8/20mbh0rBQ4pXdHDerm
uycH5hTXPLRhLurfqY6rg3vNO9Rofq12cQKSZgmjZE9xlFaYj6CHhf4GOtWxKUTgx5ml5wFEKfDa
Fp2sZgGVzhcnruXrhUpPMQuFp18ahFbLdT+hjQvo5594V8cOVhVtRajwk6/npxJO8mzrTgyRJqJI
PgQFPC1rNt+3p0RlDUJJK5v/1cAXQuxVB3hBoBrEYqvUfVoeuUCvNtQzDwMvwGLAjqYQXdsyPysf
Ag+FUAPezPoAYwlFEB2MXAfCVo6a4k69BpqFWQ6TXK4JhtgRg6+HmRGF9Pz4qwP/k3cHGodMShqv
83kspvlM4DoG1E+BSkYfLHIweU5klX3g77wJqblYolmucK5qvhGHQtnpOI+V6PJZY4amEQfTmJC9
MGJGBE9rmlTi9u1fcpAKKgXl2nmBTo75n65GWTjdx51aQadXRM9+lt4++0LaPRntKiVKmmbYEJ7k
G/nJxlPD00+2KBnavnEN2ZjSQSdTGQDM0z3QyRNU7jtM