<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr0Z9MAsevrLJ+wmGOJg+T0E3+6yyQgLVUoCmK4MajCLrHlSkVBbHK0pIRsyO+2X6pzBozvO
dMKUy4uAxXpDnX27D5EqFxKzGm7PGtvV3iwp3cUpPGuEd8+Zzt5ueMpemJDXxOlruZSIwLPYO0dV
bKhV+e3L1XYX53S1OeciCwstFvk4qfys3F0blY8W3QdlAyuIj9jxS+EFqa/b/6I1xV5w7jZ5Ji63
AtXf8ACUgCYQMVF+WcyOCqHWBbB0S9m0Z05GdHwiyuZgqoK2UuO7P9oSIreoQ1q8xa8wrYZwGcGO
Q6YdFOqPAaY989FQxmJnHhsgzuho3Xj4y3PxrJKnGULV+3Uz4HXUBlw7m3jhqu0K0BUS6mclXMTz
j3xArplOLdEJr+QpOUugCYrYzLe6SnvXnvC9tQFg9gXwAEeK4kgvOIvlCrWdSh9s/tKruRfsEvN4
jLwjlDiNnPkhZOm7M92kQ1mWS9ExhrdIEsxAod4Cd3ATN49ngd6TRKHZASvTu+vG/qgMim0vGDHW
mvPyvF3xg51TT+wsp3NlTI+PlK+yOIzqTXjznS2OkXBLCklaWT7JDVZ2jJ1k121r3aoNMB4BtBed
kJ/ajcIv2IF2R/J10yHELyIWfGjOp43eq9vDjjswKyXDhJyrAdw43bCMctSI6iS5RGpTvczuPjCY
N9MiUV4E2YdskwmamJLqzPF6XxHZa9MC7h0Rn5oUxmrIu9KWTmrr5uL0716ocDX5Jzynrt1mLiVS
OW5Rlx7YquBgKHEd08rzqIPmJh828JYFZM2oLxvYSJbH7ojTeHaTu7aX+IYeVcHV22cj+AgluUJS
9fJCyc/oesYoDuZDKbuWFWDXpzx7+Ix0udmtxBnIFP2uKjfCg36/wVJPSP2R/QWIDWf/xztbbRyY
/GN5EAFSz+n3t0X4wMQcz2MhYc32haKUiERNKy+YUfxl3oCeiOxf6+BH2Q0PfpLfEkXXZ62BecZQ
Y9xqn37xRpLBONnh36iSHnhRxUPSMgQ9Am1BRdN/z1G7I0eLfgvplTY3rOjUOUAZCqLTV+gJDj0s
NS9r1W/uBwVNJC/TDgbDu50wIbXO7yzHxJskywMabuXHSLoTwRPSgYeEbFaAIeI8syX3Jd6G3K0e
Y2NrICPCAiHQrzusr4pGzwi8mm3PfRiianqUFeLP+ecmlRDPxc6WhKO4DlBzRNhJrtFO+enYXzaZ
BxzDY4GHwldJxy73buNh9ZdDZspgdKikfVleEtI+UZM2ttKvAomc2MDvS5wXbsirorIK+/2kHlui
lm+QrZrchn5hMxemvpvlW1ZDL1XDvGlzRcnW4x2PY2+0QZXODuEWTufcojQ30U6oMo3Hp6Zw6x3y
AJZGqDlOqOsl7XYlyFyBgZALHIJatSsOf/rP3/Jpivft1THkqOft/ZACAIeh+3vayP3oC8bC9fW5
22ru4c9wo2FmboFIbPTp7SQxBGH5GRvaQlOACqLb9DyVZHUNs+9JX4S+mhgKeOUE7OQ9+5Y6LYzH
ns+gsFi8uwiqsiA2NEMdjXa3l9dCirdVcv1vxMYHe1eUPqPTu0WijqNVXf85aPxdMWDi9EPVrwWg
f/B4FnVGquJUbUgXDcUB6M5Kui8NyHrT3E8YMQ3lZsUfp7yGGoGSKTWwlX61kMCQ4Y3OsCXsAakL
UZOhPJ/SXAvLCel1lvEsEcg3XoK2fGvi/+0N9ThlvRykEteJO7mSqyuYOzyH8aNPpgnX80iF/cty
InQ4SvkLfc1Cf8tDHF2HeCJ/AP++rqekvoQvcb2uIISJVT/WlLIjfwxqoFL6W/7NSjjjerOqsC8o
My7ZmJ6N31tAl4S9Q3c3UcdApHjNP88bFSIdwvGb9BgNWbAdKrwOh1iDl6Q8Ma7nwXBtkq8JS6I4
qae3GuTQ4RyuSKi9Rs/5Ax0DzL+fUbkQMIKserk73FYzURvfcIKLzq8vuu31g07aR34EQLy/6vvB
c/MECxGbEZFMV356mEzplYEaDNiRUauedF2/p0V0oXzUZTcsUFVOwRcRxSWi6NrhuS4Peph/ppHt
Jotxd5wmecRjjsnWvQEwsjtoJ4oq7oxuD7mN2SUJsTv7XK5qjIT89Eokbx1P2hU5Pe1xZ5YWmarq
iX8J4Omx0WslZpSuI0E5AJrws4rNAHbOmYmIIJ2eGSY5PGFMGlf9kgwACeXvgeZlNDkKRC3KDpKW
s6qSSASflZJ3pbP9sruJSmBKe5Mph09raaHGLXMJwdOkazBys+wL84HbDtFew4gATmCFSYnyl5il
C8aTjGzqImqUlMfGhLNyVvjWGy67FSOwUSDPbqmT09kIR+/XDc7JJVKbuCIF+8WtUxwz1IN+diDC
rb4nYbapfiAQ1pFoMekrslaYsq4DWuqUGFyUIw5n/nXPep6KcKe/CDxjx9iLFjlWgod1HWLqi37m
THzbuF2cBzmzY3lZi1msUaxuZGFXAUCehCZunozkVWFMjN6/FsYVlGhYXrXO0yuxGmG+hFPQn4U0
NrKLKTEo3z5Bdf2XM11A0DJEmuZjfq/M9+3fLNvWB6JtYvwjnLqnVx8KUon3/Hrv6SqojhgyPJ5i
DrrpO0jcCvMus2d43dthrNnjYxcI6JY3egryMTCw0/s3PWFzkNIVSfHbLeDvvqVI1YFkJrnduK/f
07Oi9n4Ta5rMYRcJWYlg5DUvIPOsnkZ2cffP/TFhth7iZrd9pwc9icWsR/b0PsGeMxjdu+rmqDsw
oewYoiXfyuC7Xv8UOb2aZHGN0sgIn79iKbzdZzDa9HZVmgWqX9qbQCUS3G4fpZ19ZUDChGLkcPa4
Az1XMDhrCT31kO8DcJOg5j7NYH7vgEL93rdsASiaSaCbwvjcLPV1TeTNLmpTAD4l+Jg1qDVK8d/B
8e2q2Hz9UHlePGxMFsPIRdl2WfGmEUc+8J6dv01O2H6e7m/Z2m0YIkViCP93mujLD73ARrpRBIYt
zI8g/vgV8+w6YUlJV2ExOo4TcoEA1BpANiFuwM/yjYSZVCQG0ne1SvfBVYMHlIid+5uMOPSg/DCi
9wRotx1yXHgz9xCVq7mO9+fI+/Kf1KjVeahyKAm=