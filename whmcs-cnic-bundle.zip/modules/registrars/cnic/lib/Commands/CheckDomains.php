<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzqLsFK2oY3wszXDrgvTri30e7HKTxZX1Tb+DkrnWwWv8+TE3aWcyULog+hGlslRdngf6XeY
yBMO3I6i+3T1wqQBii8eecJAl55QK1/QsU9neU7pEBWqvNMxkNPvdAnaNcflj47JDpfcQM2cw9ys
is5taxsGilNPpKgkdgrusbgylmo4FNrOeriBs7J9DiUYsP1LHWvow2q3k3d5bITlnpGo8284LKt4
dR7H6n0ELyU0bDHIzUtn56dJL1q4s5xDfpFcDn5OmHc7YsTKV51AV9cOMRU2RAZk4mMH1X8voAvx
/MK82XARtCPb6eiaXluO33D5jjUxWwUAvGJLy6MF0/pCBcqVkmldvBT6hF8wqyR0IUIPeKH/Kkbp
nWCn69sPUi8bJiDuO1oPj3xPf/TkzgDwr8kkl2SYOch3dkPDfA+PAR2cCRC6gTvF9FCeJPV3nMVG
S/XJ2CV/Z6WNfx60XPAUAUb+nXVOEFtiuTitxsMtmCVJBKRfOu5BxUzsIVp/Uo1Cgk7nhgwPT2aM
Eh8LbN91qdwCbGrpFdfXWHJXHHvcT4xpqsKRMFbg+T/w3LESlEBAbHZ0N66+DNv3dhJgmcc0tcgW
VVZnbeRy6Srx7YxKX5Sv5gryESCo+nYTyGu3FSSTKZwB6m88IxOP3bVeNSEFXRA02jol8Y66cSyg
d25lOeiVE+hviwN4ruNPs3TxNvhdZzY1x4ZTSTEKWXRYETRBZt7QGhKcEMwaGKlDJEYd2c5Zduye
GLv7C84ocoD8fuZLb4hDSxXAZQB+gDDFofWWvNRuN3570UrBfAepV0Up/o0YIt92shskXS1mBaFf
Eu7GWdApFIQsBmdx1sdZonAnXtztAg1I4PABVMweAvwT3pt/hFwwEPon0ugkGbDZCklAjKfm1WXy
xSvh4rbk4sn6V87wCYatmAYAzF4+wunlbJOgHB6cKhJJ+k4fXUHuBXOAy4Y3hduljRPm6qfzZmdY
PTxOB94v3edrJkacSW0p+dqL7+s5fJeZXQiJxvF6eVqCrZMGQ740dOiIhv8FrNIKdnf5PZVQkNIX
1ovOBL8+spDsvYDUsisbTDOOeL8Bm7btqd+cl8o56beZbxu0gisWRcGEOX1gBokYwNp2zPWDVvYD
4uhRSiLIbT0RvtL2vTOaxs8ja2sBRSiznm9UQjfpK17Qujs7JlbNTseRusgbyhldbImTl3lKx1xB
KjZTEIQpBWMEjt3HnamaQeJ0/7Al8bs1f0xSrn/H0bgzD8TQmmVZLqa0Mx0CxsIIT2evV++LHdwy
Q57+SOHIxU8cW2yuPiHktklA4IHdjDNl7NlR1KzkGgjJLN7dvin8Fk0X7C3xs3f0HrVxNlybMnlL
Q/fAUzBgFeO5bwPV4cHOs+iTKshnFZ59wlGnpd7JHZ5YltMSDsq1/8zbkKKd/xUdi5DghBFEr0sk
L7G2smpR5unXGv6YzjYxGJTKIUOtJP9qVokWJQ7I4I44aP+6wpqzXpDKyqoOQtaXFPeYgJw/vbTD
0RmbyAdJUMTayTc2lw2PBNI47afa9LMWIuXZ8/hluCCOiFmpktCLhTDqgHF6TFCi54MR1vShFfyI
wvI29eImYI5QY9siUXhRq0mULRe6IATt0l+tbxXPnPLmpszRRJcbVDpbHq6KOrGFSEJ751yORywK
oP372PZBqHeA2ANiNHmMlD7DhLrbtar80Hg8O42sR2CI1zkJ7nJ51g/T1Q9d0KOZqNYfi7draq03
IwN9jgUy1U5kutDdpxnEDPRDKEqlvANxW/duvCZE+LlBObHOJENPEJspptNxWtyZZn2PEzjEwouk
ZvD44/6z0eHxAlYbJ6Ji55TsAlZz7hog275ZFvBfD1rEVbsB/SkRL8/LqY1NTcMMqEeAiSCTH+rW
1BXY50IRIrRS1MVbrX/zsry6OwnrBuC4ODhS+RIHmFhT+p+TVhIx5TM0Nr96mulYjHMGs96HaJU9
draCuo9O5eDqWTwxMvsZHVR5rTnik2pDhiBy/wD9qZ2XlR0mI9Vo3NrWFwWF5UECaJBADpCWOuT5
E5gQodfN4rMYh0w4ZdRybBXQ3uYiPGLjW5mK/IjCzDw0xHEbw8CnwwqJ+UsRA6AJ2rZ5GmAG0j0B
+tzTQdWUYZw3UG5dPjAQe750o9+tEBkR2at8uuencK18Y/JJUhv8/q6BsNqwLstRT48sIlmcTLgv
X7WQorfaX+Kbss+4/m/ZZqAINmy/amzj5XzVB8t9LRX7S+eKQp7PNxQMqveYE6HQ/AZkMvbe2iYU
7rfbtYhYAnakbvG1wAhummnUTFQwe8hKb0zkGebc2ZZmRLaX4+jDVuiz31ZY4aXv95joABkKm6wC
PEkyMdsu6+B+gF9L15Yt/ixg+UbfiyPJ+2rhMK8mSReW035g2Z4d+qcAp9jP2aJgygYPfj3VDGl4
rxRdAVE/38V1D7BRkfKbN4iJqJIDZm87D7ECW9TupNs2QtCxA+/o9UrfaEXrQ4rPe/k+vM8mtP8R
FHAZVLa6i14zBZO1UKWwcqrFkHsZ+Z7DeApU29n80Wh6LZZolwu8WzgNrQxlDJZcayqMUApGbTft
fSeIrWIBwQkY8DDvCnDQMXqptKk7tNEACwjcSg11N+2ksRW6spHn74TyrmokAD3sgPKf6Cc8Pdsc
RvWQsdSn3ex7+5L4XQBs4b5it1OTR4j58R441ItEAC4BXR+w9G+hki4bjgib94qeWiNITw+st2+F
41wxFww4RJTZ/tUj6GYzMxrGc/GYK4gu13ADwoS4tB5t361DXr8FH/ivPZWn2oxhrQTsaKevyvnq
n9CBgGdSaAW+xR/HCPDbKJBPOF763raTQ25ZABBXR/aHv2kuCzvwOVZsjUNrHLvL4s6ki8tDK3CJ
iiH1KPCIcKPSnD9uv3FpUPsbNBPa6vEKurtwA8i9gXhYn9oxFvFGZCN7K5iOQJt+QT4ddscxGlTA
jsZhs3qroQl0A5hXgRurIKso1ur3abKxG6cZqeySz5l9962qP+MOMusFUjcdwu6jrKW5MP5HY8qg
b99yUgLxPv3l2idX0dvzePFyU2/Y15py18IxHHXsOZ72Zz+2Osi7kDNaBCWkJx6B3Fyj9G==