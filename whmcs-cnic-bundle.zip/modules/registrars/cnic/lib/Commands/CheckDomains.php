<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzyN8PMcj9dQlzgqjfWKu1TrEdF90vh/U82uPZI1EJfsNalom2TR0hZd8bTgR43A3N6lYNw+
tmxAHYCNrsslEvkWmijBjskKmH9Yhu6uQjd3MiiZvkpSgK/ulp1gV7cGXZU3HIjzZ3vaNj4WJBpp
xY95s6IGo24DaszHf/u/NCvg/+HDIRcO7/ykY3Q7++woSn+zCy+ljbtEG2529DOpiQEIVT/Syyef
asN+wtfzdDX/on+VsOfCrlJ6AugxJxZJFddXQM4BibGvDFIXHeienCM7Ub1kigMktVmEb9INXOvt
s4Pkg/hZRz5PgHRRfz3ue2JgV6rUlAbjGVZ7L1fIcRVmoZhIQJKPu2JEexo/0MHHyUl6jwtdw21T
Hs+Qlm27/KvADJhpqpLhznemrgLUkz32Cd9gyuJZcCVOWoLY1AdzK7nNMXVQZBaH3H+1dNN9vKQA
ldekP6iQ64Uuo/ebTMjvaO/SUyIbvB+QhBebemTwZKhN2ZSCna8r8lm7ujsksDy6EACF/mnSdyTY
RGbcV8wUKKiJREfIdc7cfF3j2R42Ardhj6K9ahjTq3kATZcrZcbYf+O9eazgdPfg/j7N3rEUHDjo
7qPhazJ9ufSIw3jNrhEXOxHnYE4/vFHKV9cHlWS7VmUxivwTqGd/awSj3yVqBpReOcIj9uR9M/cq
wFwa04sgMyEQQfU6hQ7o++G0TA1Cb3zWf2PDdYGZ79OTg9+L3GBlwYiTcft6W4NpgnxRDki8LBKQ
VBIbdE3cQFOpMNKd2CJZ3zexNnzHFtxjuDI/shlppj19gc/bO15g+D2kdOn0Fh2I5uZiC1wvTqst
Hl1UMc9p00b4Z+5qXerfQk6zRiU9U88UzNWwKRBDJPLCS2GkKM7UGyXChv1xy8JxjkHeR+JEZqPY
VGsXpvTto2DAZIQaZr3f+bHhrslez6RIoXk1y94ri8afh8bpiCJr9diekT6kp80WpheiOGfJ8ht3
mTg1D+lNRL69HV+wQGWHpzLHrAk7+o8X3NKZNngX6RIw7YEw1LY6EHOfHBuQmqk2q2dcyFgJ1Nhu
HYLNujcfP4vExC21uR3OSTjW623kYTYvSTH0PaMqea4Fe0VQ6g8lqGHYWzEE5/bWkB52G/oxO5pH
IyWGs3P6htX3eEin/eTnN6VCNA6D77U1V0udMnFsL/UivcleOat1mgzpXk3g7f85kjblAOl72leE
Oa27KTeJokApwbZoCgmSGbnyOu85ydqKFi6rskmmf3jo4LuLvcFLoMwPKKMlECbzAMlvFMMCJYil
mGhG6mDyrvk3WRPaSkFQ12wsxrCsVrYkKlYM+hcu4oC5FVNfAWeR//tFCmf7fnWRUtt/XEOHTmGZ
62ftfyT1z6Xvb6NWnSnMVUSqoD2Biw8RuxtE5kwuID5SdJMFjHC+BbXmBAx96IUwqDyoixF0Kp4m
BpazfInTHC/2//rLwZyW1GF97lbrajz2pIYFszMw8rx8YSWbaDXrEeCwhWGZJlRoN1AXpntl+suB
Np5XWH4RC3CGHMu2U8a8gsvqkB6/07QJX/+VBSxogx3wibXNTRCn7/OuEC8785uSPhrT53bkS1hl
8P95fV3e3cN58OZ54UnceMUhCc2dRyy9WnLHdrdCTt9Gc/6nrcgTGREcyhJtVMQm7b1StD2jFvwT
O51t9zyTXnGrbrax4lRMzSpBqJymawXYVO9EGvQVLAlGYwyeCeCLEJqYps5AufBQmEtZT/dAiC0b
DUIGqA1hxkLC2w1lCoKa0J24mad23mRQT9i4JlYfGZZAGO/12pObvUTGEjBTyaixnuf8w6iKQiKZ
3FLZnlmz95Oh9CwnezAXxmNZuX3BmcyUJULkLgiOiXmiunBVexqzEjSMcAQ9Fakv5jILvRIZ6pDm
amCcFXPP1YzTq8j1nN3BYCKaiVN+Zu1x+pWfvc2VSMTYCu5f90MvAE7RwpYrE4LyZCNnPzcj4air
Hq+IO3RA2jqgfVoFZVMJX4EkgLm74/7/kDiPdjT+plSkqnUUG6f5yyPS0YXJ/+CBZ+5pGGRRN9OA
MCpBOEclUBWjbVWb1QaEOHASedtClNP1uDJNMUhEgHYgnMgSeCPLNQ9TqfcKpbwJvQjVSTiKBG/r
YxtgVLGA6Y8zcEf4tE6ih6w/z06OZF6om9lPAtr4vgqk06kH49rQvrKhpUYmLkFBLIWf5oIukKHR
u6XKgxHTyZN0qKQ4xN07fWNtXJ/0SQX2x0KGckKgE1Jkio7gNWd/J0mHGqep5zAAGvgakI5ARJMN
42X6DaaouvSqAnBUardX7Ho82N3DdxSAXRB6WlfIPnwF+rdJhvuFywuNyRFU2psHA/oouL5w8kq/
9QvWorDE2P/zcuxhwQu+5pV/4LuS/TZ14VemuKz4tDQVfDkxxRCUM0l4FqiF00FpcZxHg+6fNgN2
IU3JwMViEpN+ibnRENnvtBJzziwqKVk33f6l0wWHRy7maAlzz9KQNZ3a++czeNvq8RyAZuDOXBCi
rxyw/L1tHY8D7CVRi2wqrgULCSs5OL5hUFB1kARyOuAl6Vc+W4a6wl2/X0MXtlyEdcH5/ubBgaIU
NHniGBCxWmFbjcsE1X06Dt0DXGfCEoReq4/ePxEkkKrUkgDKmhsUceU0W6VdNCo3U5hsrP4mdmjv
BWcHkVk7sMiaSSK3k9sohXJtP1KYKDwc46lQ5RrOaLOu5L6p0uyUZpJpSp+G1//1tXqVeRm1px6I
pyA2DTgZoiuxBvqaJslw7XDdEdksUuXCjE+il6moPHjq/Oh5+xWVewi6yANXfhjKnGAAR7mj84pb
+2uZLZzxHwpBB/zFUJky+06iZaOzaJQzvEqW8sDd7NIbGtMAyeeftE0xEn7xpSpK2Kr8TtmuPp12
1t2l9UKOPr1vq7HX0D2B8PHd0sj2CIZheBpOWkZjeHLelK+G5pxGnD9xbq/pJ+A6vCHbZld1Ab9k
3aJ1H7S7oIypmmarrvxNdyBTi/IRuphB7MR9mtBuNWMNy3yp4diuyp0NZG7zLe41oJO0suSi0Xjm
Pz5n9i/1X74rm8509YmcZVbO0YEDjJKFiIy=