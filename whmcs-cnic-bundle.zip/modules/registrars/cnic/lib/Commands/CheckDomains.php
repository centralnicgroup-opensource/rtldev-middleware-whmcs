<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxl8cD2lcM7djWKDys9VWcs3v0fnMQ6L5SqQGUUKTT7Ai1+unWZPeYduZVba4hAgsWU1x4AI
dSevGgx9I9RRoJgGtytQ8wxlzO3rOR43L6HQHhNd5OAcOvvVh/615CgJNxxWfjpZktlfxNyqIAPH
o5hum5kNjs/x0mG/pgF191KSISR+Y9I9Z5Mnn25pzPT3rCuDR8OXiDhDksG6Fwk4LVXQta+fcSJg
kRl0qYYXirMuhAXCCxmB5sbUhMW5AOomKSfR4C9LrGofFGIgAFG//w7FljOJSdxyKea9GLNqW0CG
+7j7CG7saLOzcn69X2I31LjTlbjtKvr5+v/EEd3oqpK+wMe9ajOFNIuiRD0iP6GOmX46bLZLaJ9T
baWxFVtZIjCbn9yFLT6z6RtqehihbsRbCPyAZbxz1nOQdFTI4FrA2OYvuQnrqSjCa+gFrJcIymNE
CXz9wpAsUCakHW80YecXjSExAM3kOkEnULX0Ka4qXYtIRjnQXGeQ3IYGdv0r/ZMla9mBdNaZMW4E
QZuGC1dA5VhVJ6LwiLV+qx1KvTMGeuX1abpsk1puNFF9ZR1NAjtQns/DQpYiBLz4HIgRwIQCZMhx
HwN0afKEm5KGfJ44NVBoSxa5wj7O8N10GufUdhXJ58F8ImPL/avcV719sAofOJAOJqsG15OORuHq
0/VYE8XbbziL0U6xp66PMnvc4eOXVNbTW78OnughdnGPDrv3Lu1hQebr5iZ9hnav/j1FmVu8IPWn
xTf27Klptfc8y5loM1WRcqyUcbimvcs1Dd8NnEN5apgg5ycYLXACymjKU5slfnjdnMy4f6aXupia
a7rORQuDVHRTCC39pbd4MhtwTlHL4PcpDnxcg09WZsYnkXS3nB6+mTzlsglrJm+l8VpzKUunE+RH
hFstjpuE9d+D5jiMjD8E3FIk/XzAjX0itqroRXa05eb5FYQj/QfmSPfbAI5lcXPIcqOR/xorpNNC
3W5a4w0xaQTX2PZaYCqtycO32djNXhHfW8FfoKp+SeXKmM1QQ0YDT8DHSFPqXpjUxXfc592FkJEg
lq5vx9ewC979ElQvbdkEknDu69F8fBS3RLNfXzbBAQ1nUcg6idobSLbZHcsaNBtiy3UhT5NwrpDA
C8Wl03G0ZjNCDfco5NtW41lAYU1QjLqJNSYtDU40B/KLLcOHNr6AYGfRUf2wkCSsBipWlIbK9X01
zcanVh7a5l7kCWB8JzVqQ5jUlUGPzzzYSof/s/Mso/9d6j/rDXPlWqOoKliYgAAwCdvjj33sxrgm
f/JPOc1bbDGSfBDZ3fNO7OmeMUn/miB7YQMfNTxU2qUQxPsjDDlptkCi5bznoTWrFLIN94Za6bAO
+YcdsE8K37cDLD6pR0+wzzoj2CXkoXAE3ALXClQiLKhkI+yKefOjzHnt/EvUN9uldpHQJtji4ZEM
IBaeoOk7L0e+XNg4q7ubHKLHVorsWyLOYj8gL1scUKjPY3/ceO4e7TKO3HUeqeTsHoH7q9w2UrZf
uWwoV64ny8ZpWE3uQ3vs1igbvIxUE8aXtzmgTz6ACS6GL7GZOTPzbNKaK3w9cKX91yfhkPTUpxz+
JIj1AOxQBaiN89hXFu8Q6+L53wjvS3DBJUHqZ3v/coKdDqov97mziWqjplambvo458hC5bkkVNyh
uHt6J+eDfgmjHrU71uqrBL7xxiG5a6QGiZqsjtCJe8Kk/wO5rfJ8gyMEAzFGWfc5atM0Je6/L2n4
z0JCNnyfRz6dxpvmxpuBt6c3qR/SnwUtjuUNlyINJVLCMD97avzb6tSF0ELu6fG9FlNYFMOhqcNx
Kjf6kH71PL4h+qjMJ5yedwxaJxOp8jhq3Fa3fj5mXXlMT6P63+Yjyazwftk7w93o7U2qn5ALwnHe
Py7lPGSSksMMoExysUXOWv4R9Yi4mkxDSP4Jj31cC4ZKOUZDl4/TixSw86yBQcoc8FwYXqYp+NzQ
vvqtX+8i4nOA8TY6us3lXUWYVBLPbtqRoK15X7QilPhFtt8AiS5FewXcgdZ9Or99Ng/k2hCgb8vq
Lmh5w4p/UpNWJubWc+D9usG4SVAxy3ZVtaxZp5/y5WSKCh3mr49FNxm3EzFkKOtAmQNv458aaTcB
ROcsd7PHMMpKhMCpOHrfW57LN0HSUVO2Luk2Bzhir6Sw0SEL+s9uz3kPv+P1GrQ7SGsHFVXWtPde
dsGwwJq+KM6fpYhwFZ7v2z330ZSbBKHFjDlu+r7m6KXsOWOz31WLKcONJTkFnvTqP7kMWGtHrA5s
t/UB6I9W4jwUVzX6SHOHI4QW8jyV4+pgzwS2HQvA/eL7ZqVgar465C14ZYMEQLWUvisGakQMiza7
IDRAWoDZvSLL85UgWfbxw4h8jzby1SJZia5g1GyfKRIqLZGUPgu6oKGVOR40cvvy4vWf6TAvec2T
pBLzlSEJN82E9IJ/teJVTDXQFlDhawm5YTf10Zh/bbmJTyi6Wso8H0gYqHpAmLETHQYUTAYXMK4B
UT/RD6PUSdIClX4H66Fti363XDnvd0eGmi+Z1OFtsAfPc4GBMcNmbclJZYi3Ayv/R8Vqk4bEGxVE
8c03dRMsabEllEkP6DNqb9YAwDIPfyg+fRLAkskuolgSBQ/J9viFa+uFKZOzJ6hlEm+vSY4+G33f
hB4Sm7RwuEY8a43/bLzqoCIZFR1+0f7Q+ECZq5iSrb5BOHyMgQ4Dj3GIHCfdjrSOVvhGos/MiGXp
JXXdJvI72EFmJTSUg5vaLkweL7LCfXDIgtLVlgH7FnrCbiVHqKJHOKN7nUF01dL3hB+HUnWNmQoW
FgkSKbb5yeCnhJ9exDC6YXFJafWSdS8sFOHqdxnLXNEHEgmJkxAcQA61w8PPPFIE4F48sW/M8XBd
i+o/tzTqp2B7fWQDINsTO0nzQjUfmNuesaEGWiPOU5k9ASpNn4rIAef5RRL2oDWaNuMVCs3Ztj+w
ubbQjMZqg/C0UvvSBbM2Wqlbc/phwtpCABn+DK5Wm3fqQYquWIBlvd4CrcQU66aFMNH2IV5BlaCK
OZ3ViULVdaoIyL7l0vuagnbWtmhnkH+5BkUqZiELdvdosEwwq6L27nLCfSW21/u=