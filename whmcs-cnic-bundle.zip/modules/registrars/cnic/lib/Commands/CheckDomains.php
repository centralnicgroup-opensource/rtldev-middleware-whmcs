<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxEho3VJE34ugcPT51aHwFWuRQE/ihkyX8suc5ddyi/P4FXi+WoIpjxjqxLsjbDhjlfDt1xg
LfWm1GIdQYpRE+H6kgQyCRCaGejO6QL3ElRvF/ktvu1/rl747WdbzQTqTFeJssjOjkk6pKYBZDV1
aUwqTJiZIebk4VxMPELsW8A5qEttBWf7t4auS/chX0dJRt7uR8CoEQPhRu1lqgl4ZkG2zKypXH8D
SV/mReIrTCmtq/Uurt24HsmslhGwinTOXBUPiVziFXhP3NoA6aoR1ZAhpS1m/rvjbSr9sCTT5WvI
UESrBlsCMQQitS6KL7ksidNtEOrFqn60fG7b2jRZcvyr/1Gxaqt+DQvdWQ2AY/Hxe9+LQH0n5Ndi
kfO0LbL7MTfsSPouC/k8S8auYEwO5WcNlaWmrZXPlFv8ujpnsbk3a34EhdSBH93q0PvNO+qJEDSn
oSa7J8nFryFRdoY5Isze8dcGnwBQ0+PR9WFMGO/rizMdNRqD51AE0VDS22PLA4hhs5NTNz7fGLQl
0W+OnnO9233kOYPijShJ4UTlvSV/Wrrc7u/aaoEAZ8ihsxil1G3hMt0xYPXPVMNfXCVD33SMbi3x
7kef9cjQuLO7z6CqY+7xr6VftsZ9A1vw6QoLm/g1Sf5bIctWQ5UukJ26Op2rex8hEFFcEAOfgXqG
2UVEGixFhz+kI/CvdQoOsNd/EtRj3WvfxatHNAQnAPDoPTgp1QfDR1KKNTlHmuyM3lEMSfhm3t+H
fnG2awZ+CMFX7U9nYm84xxLRpFXKj1SgJbRNzzTKJ1M1M+fCs2bOkQlod2ZYWT46GHqWHOqiK+R2
ARbfhr/wWkMjH6O/v0ThGzG5DyO3zE7CQoPwvlCUFtTcFh/qS8JzmEcn+c8xRAZOdvePkfUTLqPQ
p8MeOyZ8d3P3+lSODaj7SRRPvBkXo2Fxp5zBsPNpZOK09+N+Je6kNmcJCKrfEOi+NNXTzeAq91hq
u0JzYLXHwUZ8wgTE0V/+oVSHft1NkO/eeRxFzfC+G6mHfiyXBSJ6x8oQUmZQpWa2lZwFgXiV3Fq3
rXY7J0EqA3vu8+dXKekxtGVlfO7nCmslvEiBDoFxJkSMGVI5LW5ld1CY4+/BXG3F0k2HxHM/Va0x
2z5D4SOlTsk//ZdqsKq6eOigd9qAcyIq/YPjkcqngkpoucc4GxBvJh2XcI6Ovf1HmjPpuhQ358RL
c4KXuQ0Jw/z55VVzlKwmYTM/ld8n1oTP25Jv6NPgeEfB0O9MSkc6RnMZDyrkBTsDw5I3wrjwrQCz
gk8WFWsDDlhz8/FM74CGM647YYa3TMU77BHTTtqkySY2EkL3/LzXdW1TI86SJaPpL5tuI5WYFjXE
+lQoW9BSOjqQHYsqL7k6NnIQi/Xur2f/NTdK/Cg5XQmgnPv4su92jsQ/qTpPG3q1ZYNJFMqTRJwr
svrhJxPAV/X/kjIJLeXD5cefOwH86cGhVDZx04eTGlwAjgEEEquERFMMEjpPbODR/N7cqsQ7K7AB
KMYA+GD/+gvsrdiJwCf5vWVIdAcJ4hc0lOWcq4EbdaPLRnpYqzmahohApllqu/95CaM9UreoBSn4
H/4aDAEDnqwBYEaSAGJOS4Yqtm/DWNWGawJTGi+Od9lTOq4ha5Im9XZT5ajFGm29v8dBT95NDGXr
5Sc+A9Jgy+zLZqZXAouQnZt/NtCtAqbM+h8sD1JnqopesQqXEhI2MtJF9TnRGSfQkfQ2GaYwBnET
W8Y+mhcJyfgF55fLuvfqJvMPJJQO6lWVmKNEo7wRYdEga59PxMrE5VvZCuzte5wkoY1jVQKmJKZv
KlAwXn+flE+qgsFxg5lCmA079g3HebPpgLRagoW6nlziqIBvOXdtQVx6HmNGasWAPu1EZ6J12rah
Ttcj8gobYhv+T3+k0Tw1Mn0jOGmSvg+OFOvwoDMozzJVlERaglY84RxfhSL2vk8z/GMYP4w7Rbn5
+mv2HbFJzRMhJM/GU0G0vvEuNx977EV8EwwCycXy3VPgIVzAfaAgcTB3+2gq5VzKPDO3Ejgk0P9W
JCAsLLb8ULMjjdH4IIxovv0V5eQPhsl/3OoMMroovbUbJ/Z67tJ+d6Iho6PJzuiU9Y/EVmMrGJco
JgE1DJZ4Pa+Vc6bVfk2qYfh6WT0fmJHBtgku+wr8ZJ5MRfNXdj+hSSll4LXm274uVzwoZnE3oxuw
yG7LhAMrUjO6+mfLGWKxvyjMyNSEMqxWsOhhgWgL5+t28MxO92ovza7qU5S/gJVigl1e4n0LGcYO
7w40y1cpJOv+uCMdIx+UGcQknbfzp/u/cIa3bFQDAIl97cGNV2gWlXYviOT42nTwkmBmSoTb93+2
d+/L8iEMelkvp7rObdB7P6mm/+5q5LnJZp8Er2DWsOlMheL7zGgSUVUcaB1C8yhtEO2Zl5SMzGiF
8H73ZfflluENQANDWbmjrGW+Urur8+DWtjSRtpIH6FyGdLyBVlCxyxzKUJA6GntjSxDkgPTr4BRG
NaIkvguiQxR17kdosznjPzaj//FWxh9g9CwVHWm9S08snzEdl9vCp+wcKHTNYPMiTlSuCgfypnJW
jgCYAKGXoSXm1w0vH0PJORaVM8ZDjvH7KYQy4vo16yD4AXrAJvQaWnmGHsIlzc7icmWJWRczbkXb
9tyz9ESWT5zUvgvCPQRxsafVY6ChgVbqDwHyTN2maYXQQx3fQzbfukvKCgZ0NbIralhuurBVrVEw
E6fMHtBNwZuB61FHVyAp27WFcy8zxihPH065H6zl/5QvtRdt5z4UdXQAr7JXTn/HCzaq9fEh47Ox
oNfwX9O7Ipgd9hr0iGJByz9kEbqQP/envyUIPuo/KPbAFKppOHOjSYEQCI2GUAnideoIFLxRayj4
jAXgNVF7aGNYYDd8M/NldJ7A/0SXgKRs177P6kqxA+Yz4c5zHZ44ZUKBGciWA4sPiVD6N09+h6XO
+PIqGKcruHqb58bEx0UzMq3J2xAuOf5iO9JqxLeW5+KLNYmmihCbLI80MfvJKqy+RuctfJ10Rl5w
1lxtgG9pYmpOYPWG8HrNYFMtJSK2TWV8YZSo9fO0geWI08m=