<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use WHMCS\Domains\DomainLookup\SearchResult;

class CheckDomains extends CommandBase
{
    /**
     * @var array<SearchResult>
     */
    private $searchResults = [];

    /**
     * @param array<string, mixed> $params
     * @param array<string> $tlds
     * @throws \Exception
     */
    public function __construct(array $params, array $tlds)
    {
        parent::__construct($params);

        $premiumDomainsEnabled = (bool) $params["premiumEnabled"];

        if ($params["isIdnDomain"] && !empty($params["punyCodeSearchTerm"])) {
            $searchTerm = strtolower($params["punyCodeSearchTerm"]);
        } else {
            $searchTerm = strtolower($params["searchTerm"]);
        }

        foreach ($tlds as $i => $tld) {
            $this->api->args["DOMAIN" . $i] = $searchTerm . $tld;
            if ($premiumDomainsEnabled) {
                $this->api->args["x-fee-command" . $i] = "create";
                $this->api->args["x-fee-domain" . $i] = $this->api->args["DOMAIN" . $i];
                $this->api->args["x-fee-period" . $i] = $params["regperiod"] ?: 1;
                $this->api->args["x-fee-periodtype" . $i] = "YEAR";
            }
            $this->searchResults[$i] = new SearchResult($searchTerm, $tld);
        }
    }

    /**
     * @return SearchResult[]
     */
    public function getResults(): array
    {
        return $this->searchResults;
    }
}
