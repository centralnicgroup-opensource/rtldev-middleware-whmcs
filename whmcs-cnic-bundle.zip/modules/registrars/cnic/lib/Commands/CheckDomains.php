<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn/WPMbtOLvF3YtmIcpfvchMNL4NZyCXVVe2Eu+VjQqqWwNgmMsSGf4PJ+dKYBesWG1DZm+w
zirSZOlUe9ZnePdNOO3Ss8oxxB3H2Q9DHhTAwVv9l+d1vkxRMgKigYhoVkS+8nz6qxboUc3UnwUU
jWPn+4+1LPQSyP9TDlY8bVOoavB/vUpXkY6Av1GhL8o853gAcsTx4lBBkYVek7+wdM1bHLbkntAi
m6o68mb8yBGaCTZOvc7ycpEiBvF2j8nU6urTw0vuwW2FAIcOyaxrHkcg39jnSMCRNkKSfefaC4Xc
KHPd1a84svoMkq9Q72IaLrnmeSbI1JDPG9tiOV8xhGJkmcSrzxoqK+XY33NRr3IfhR1igjnVIaAV
J0Y+MSJ3ywc7D9hWPG66Sri18vjLLvT/xYbbDbGWqdSFjYAE/y+yNj9iL99wswdOgoCW2y3YP5uF
bRPaK52U4Pg4CMOH1eztoxJmpUnkQM80BPHzGS2eBIbv/blIP1M4tThejX2W4tv9uTyscKWYwevA
n0kRj+dwVCMYOb63MrNF7oIwfV+4bWkz6UvKyuql+WI3tI+oNUP4hiPgiHGaLAU/L+hXOgT3yLgu
ZOw2byTE8azmh9cvG8ZYwEJwfRwC2h87jP/M+97nw75pqFbaaYbs9tX26BM7M33WGgnSYxMhYd1u
IH0x8buLKpbK/89GH6O+dqFNScz2+Tz/2Psjvd91u4NTSiDCxV85AKw/ywCtvbrb8boeKGicezwg
j1bwJMW4Xo6rIU9LTSM5SPzVUgzoY9hoziXSlTOtzJTUHNz9rZiuQkOlR9GcdSBt2ptecrrmOLXG
Xbg4Do4fHnXVgD/QJBe4v+jr0P5lC4LEscfPiJKciZWGWTdXQI2Lf6V2xWPwndQ1bpLL0IXnrlHe
O6g6py6GflsLweTijq6Xt1Qr5KURWGKCCK5LIEZJp6uR3pkPhzUWPc3BOR3thmzqzCbN7zYQrxn5
+bUnQjqH4uyB4pYBvMDnfJJ83VdCMnHjqZF67DLeEzZw9pUVHQ+L1FDhCabC2nsT2C4s+5XJif1k
vhNqW8zlZxPfxn2EbDO4wlmf94VaHjFoL3E4fgbT4c57ZjFxFOLSJDG2iVO0g5LuPSgBpwmElIGZ
0CKqwoBAKY2Ykd2u64AVAmeKd9I4H95qKF+b6LZSR3CSZGLVfXkk8piEL4i4WX8mCo+lifQVP5+0
9lHGCcOry0BKl+9KmemCfoIb7QipRDq02zsNJXtCixPidJyEmQpf6TakuqFa4V5ekZMM/Cx/GW4J
rYDDymV0rZDZXFkuY0y28CIZqYMh2h5TO8/BgHDVf4GSmoCBRBldwF810xo7EGb4kHBSZZNW8/zS
FUsy/D+UpOdFFYa32XW+3NoXEcYbHwHzYslrn+WQHmvhyl31Gz9yodYZPyXYYutuV4HkN4/Qj/A1
dG/s2Q8uzFu6aaVvlLt3ckoMcdd5umaaDSJhy8mmVltVgm95Ll1SpfYso5Bu5sx/sIul+3Rvf5Vb
gqm4My8m031nst/7sBxJj1EXlYtvx89nJTbRBM34DPSdZLt6bN4BgPfbrX1Z8BnzM/9EAZfKlGAa
zzBJxsjTeo4qjgDQ/FuIBm6nWwWPreg6XQGI9H2jAMr0TOImCqjKTrqWrKB0G4gquv2F8sPHLt25
vTNuds/uAqw6hcGuCAE89CN0eDaAaNgT/7mZx1nkqjrJFT3erwfaIS/z4DXyYRTdiPOqGqr2v1kV
GjQNBPjmk0+bKM7dPXSY3tHn23Hf+o4ukjeZxhdp2Fy0/JLmgbh2NYqzUohEI/jKErgsgr1Xx+9q
VX2drJ+49X+K3zTVDtvIkMzfMZuj0VZEXxhYz9rDSchfcB+aae6sp1Z+bL8xAUosgqdGdsFamyl3
IG/xuJV+X1PsnI/wEXiVB1zhnryxpGBXORhXvAP0y4I5UPXoE9eQnffQ7u6vLAm0v/6XvgvYovIr
SnOoXUX3SWI8WA7D+DG8z2aowvbDrrKDgs4ZJb9/lKb3ZncaWz4l4kX4wbFDyKDMXxkXoIcQLd7B
kWl/oWD6ON6iQ9lWbnFdaz6BcMb/lNdw/aRPIC8/dpAO+KTzaVwtITvTN5Dp7QIZgMVeC2iCmBkL
hvDtB8h7SIjNvylCkwBUFSjM1vRD0RdqJqTNXZgSR6BE5lreWiCpfLwCaGhaj1fnAFb821Fzrvis
dqC+XY7lcjsSV1MQmgghqA4LrO3W08uEs9SPNf+UDRXokGn+efKCoI+eNKyRUS9m4B+j/SkLjehJ
3+z2RDJsRiMhnHS4032QPF017I0U23j23w4xWzk149kBKba5WJlOktvUNBqhjAWfvUpviYN3sUjX
iNW2Hm1+7hBGEiQvpS0PTxYUlPg+Yr/k2NOBUDLZQ3ruXs08cGkzVFeKqkRqpwPK+QCOfODPCjiO
gVI7NvaY2DZObiehd+8Z0GM6KohD4QrOyj4PSbebokJruAqdY3qqmV0LY2DH6jtS5/Hank4jKa3U
en2uvU+CBSjKoUxHyRJsziSJfc1DRHfFcqYHMoOg1f3VL9/j28akDQY9DmeNaawizTAZ9Et0xiG+
gGSRkY5Rp88qwjig0+pGIvL2oSoFOOjtMT/uhiPXVP5EByu0NUCHUlMmDYGxm+Ftn544UCPz3FR8
XGoiPI+gRPCnCRuDy7mRjdyupUFBMTT5swp38K2g+EuLSRtNLdPag/ypFtX8Md6mO0TGEs/Rw65k
cKU63aaxZmOOK4JiU8c49miAjDAbO5rLUHMWruA8q82Ng5ft7aff+qs98uUXj+IptPExMb3zGl86
Mz848S+1JLeWt/Q034x77stMOXL41T35VNfYDCBu3caS7OBQBdwfdalCvvHubRVJRi7xGyoqrucs
VtgZXYzgmmJTwgenI+CHiufkhZqmNjICrWfDe6EkOTHwJDe2csufRp9B1UfA+w8JReVo1pSBgbyR
qvJm/smXQ5LatLIQseduAYhQuDAJnCr6/uWPHa4+xFuzndXWtSu4a1jxPdT4n8ePoUSqAobsSi4R
xjYQO0mEI21pzJPeZpSilCoelhnRodA1H8m5sKrAz27FDI3qWKeAWy5APHTu7wZtWQLQ4oC6