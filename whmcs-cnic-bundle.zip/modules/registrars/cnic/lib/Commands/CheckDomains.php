<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr7LJkooTRF3InZRpx+jEV3fEuTUPCuNZ9+uk+EFoEd+MeGozXUEvER+SBRnfL75BCMXwnd7
jATkuSu/1uJ2upNGttXRp7fBnLRLY1+Hf5Sk0HTyhzQkl7SMjSSzg62Pwz7de141TQKUH/+GcRf1
kC4c51kQN9Xunh4MXOLUiD4SJiEfEzPioZVjw5ynUNzNZYTUz0KiMIBKNWSG/3xCyiE4t9OUzwSl
J1glABQcm/+Vl9treVBBt38IHednQDSlC5ECMFfkl3Z78Es38Wkf2AQJCeLmdpJklnjp+sVRrOhH
iKSZ/+4xxWojscDh5Y7agPCZFwkA34hFE11on5A08NN010tqRr25iKKH8eVZIcNjRwIh+qC8Tfgk
OKjCIYi7TXDDp//Wq1JqoxEzjoE9MBgOukDzQxiJdN8u+Q3C78lYQckeeAusff+GXYWoiKagtgId
hUTiG7Za/Wd4GwHfxqwLEHBjMDjGbdRwRMNlBhlT3gqlCGlKyy5pxhr1C9uDaKYuXtDbgcPN4Dv5
5dOGcZV8WV5HPR3ADJcM75BYYqAck2t9pSzWa0X640EoGZUmnPf4t7IaEPHtz35hhymn5mnzrkAb
Z37D4YxUdD0v/OKWWMcjMmco1mm1qD4ul8xV4CYj617//xgCTNxcgb5sxCkMCDhVAcA4nthHZBfy
yVE3td/tvKpmEH0qDrUWnML2t9ZSv9aMZAKqfY1w4OQHCubZRy+Ck3AAEWoNmRj/pvPQPBZy9DAt
/4v4l1Icoot/Yjl3w6aUs6M0/PXYBbQO3VzPodzhaubBk13D0r0lPSIpB3OZzHHkm5rL/UTyuV6O
1rswl9X+KlTwRFwNS9bMkLcIPlDr2gGoxVuPHX+TmvLFCA/sGNLIKfGl2spuFm4mOOTVHmMEHmZA
5yJXQNEmQz05ZjwnidedIUSBYqvZ5lQgYU3/e7w+ClLDzDzRHUeUbeQXdISx9XLq1tlZUec+8TT4
49uQJ1nHBYgyRqI0YiiXThWWW4NySmahg2FtCP/PDuA+ZEvbMKVaRbgvPx5OQsZMPt2C2FFzQPk4
DMdyxQj2ubEtIZbMexxoUIVYiCtxbOKTA5dZWqGNxmmcGegPEKuWdpb3a4c+hOU3iDbpw/baGf+Q
o0YGdMfpgbFahWKoXRDMY6HFsN/kX0NTGEXd4R4aeZljZ0iYJczoxPtVOoNKUI9aLZ2wH3++BDMx
jkbkUPiJZUhopYCeNEjLNzPPmubDV1ev7LJXqWOvT2s0CfX1HSBCUhvp6yRvMjoL5I58Nyhn7uEo
aeB/8q0IA+idaIVTi/t967dIvLYBE93sm2Cl9xQr7EGYJ1WeWqizElj3XpcmO+hm+d2kwcjRFcez
TuYV8pQONvkUFxpew1cx7H+aFcA5lpvhTvTQfPnAwKuXFGbKS5jNq7UT0Gl4iR8HVLK79wIax7Ad
4ygAp0r7AkLrBnFlH/nPiJXCtQtKrldbIG+E7meJY15VZszLZWkhbRTE0KYu2sig7Hu/m7R7mWhS
GMbiYGeax8AXyi799tW0pdp9qBUYh9s+vtwUhcCNAEbSIjHJjBvF4+pUjaVhos3csKLi/4xO4S2K
5aAer9FQP6XduTb7obfedxY6+9Y5RcbnDIQDTOf1k1qkhhhyVqLkcehS+AQDeUwSMf/KcAx/96rh
jZSIvuqggCmBu0/LQtbqd02Qt3d9xh/vAylCDw0c/g5N9421a1YsOCUGT2SF6VoL0xQ6H/ip4CuI
m+d4IXYILBXG0dISSDMBuGJq0r2f1H9OXiGfGrx0g9lcWfsuW/vCojlufiUJy812W/DbBc+d0dd7
Pz91cQBkQGSnabHqhtktt7sPJKDLsUj1ycujjjghMUiCtXIoEiU4LYhKdU8efwEGtTVu4AHIAI6F
PwXx9/2GfEthyxdtOMkBLGhw+OPE6egSeQiYuGSx5UYai6lpfxfFVBEvcMnQPFJEq8Ch3pICiUD+
ipwyklFymFMol1oLcuce6X+ZwaFNxC2ChgyeXWfxHCWracjIjuOqr3XxaOGQAHYXSZ2owXJ1Ghda
aPiAJNoKLRouWWIkty/uAOCaIr1NMrGMRgJMV9ue4YoYt6huteKOsjQI82o/U4xZBLz3H1oMhaXY
a1D5N3EVD7DhconA2aBJEsDGf8E4CT6eX+W6FOsLrcCVGKPD+rAgEjmhwmFhk2w4bE2luYHwYewB
O/JUS53/v1dNIlJ0AGmO6deNEhV3aYi6bfudlyQpOY+VymByyiBQqWch0QoZKJix8h5BEu959Gjw
pX8uZirQorM4v1dS6KuOYSS9BTYV/gtW5CBDPnhKJoXvHVGtiLO0DFcZjjf96r6f2J6wNvE5GKl5
nDKHRrJtZDcCaN0Exwt5fRpvQOVT2lbHoF92/zmMUUz1kXWGs2oYC2avYkPjj5ASyP4tD3C92G8k
djT6ylFJ4AeDMVYXOrFMBZKgYg1FAoXO9M7hMf+yI/qYMz2cb+7J4pufkciAWBXetRe0GaQ4T4SW
CkGT7GWj0AKWK62fosWXV3x5eBrSMneJXuoXpeodmHrY87ieNHC3w/+s0P5w6+HoJf6cAPqTeh3v
stZiGcziUeJDMAJ2Evr3Fx+x77bVkcOqf9ywQ9ezvcIB1b7OPKCTtGQwN8oLOxVFYEgCejVobS4x
t3ymdNBoWWSINQIwG7/V2BE2k6PbcDnTMErQPSu8o+oFzs1ZrxtFC0PXkl3FE5UlZjSryj7n06ek
QaDucawUPoWI7mEzxVsLoonZctBM44D/jAiSnqbd8bTY8OMmndh/hZGGHhKESeflIS8/YWeW7CPz
cHIObvr11JyWCJ1ES10aomqS+mfOa256wrYYEOUgPEFAo6VT+BQnr8wk41IH6tv1ub5laBWHNxd+
oWpqZFNp37rzGBNyopMvUwA2ce77Qo2EUMxx4N3jqDnJ/PdMYAKsbYAEb0axUHSM4H6EYs71ANiO
xnNkzoWxue2/D6k0evqIq1iufm/uVLhF7S4L1xwsI/vkZiRUqS/+/NwSViNk3e77wlQ4FkDlQJ5q
36Um/hsY8cXrt1WDDOeosudKNWS2k7nnqpfhjMO7jTq=