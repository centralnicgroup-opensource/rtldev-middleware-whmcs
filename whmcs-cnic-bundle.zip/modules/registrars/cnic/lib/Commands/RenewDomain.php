<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtkFeHmIHnfJwqiqF+Phjr4r+UOYGPcPK9QuUxss0cDZniOLYmYZfGID+5PNphD/Wjhy3H9w
moGr3RMmqqDd7D2+vKdksvlslouRnU/w75gllP8g7v+ulqoZVBzMyh5EuqYevUVyhx31Ge9+R0y4
GtkeEKI1wNz2nZaTlWgq5779zM4QN+BK/TQCJRdyftwbPsdH3ry9yttUpnatmiUF4fG8awu8El/X
I2joiC8quV4tRJb/TIBUvxecjaBHy8LMqDvqxZxcDrKHnBWZAa8J2NHJAxXgjnacTYwOlaWTl7mD
1sX+LGP67r9KYSkxs5h0CgaaswG1sTvZU/GlGpOHm2YkHBJGwx0cThicvWffMZGYCPUmnXXhDGdn
4I1rbhArsTwi3UTgTP8H4OkmGSnagRoxTYqvogmbgbUUQoQfoAmLxc14hOYH/BPR0ZZvFk9lg3DB
MRj+eVq45fIlG1PR3yPDzH1BEleai7VDLGstV1SUcvrQtwMWpXCRjoyZ7fEZdXBjbk+3dPS66PmL
Y9zhgBd+ANVTEOB1tomiVEMQ503cWvCjT4SxKzFB47shhyhhbwjFuBKZsHNXX78myL8gX8ykhc/v
EYJeKPgpUUzwNSFx5m7bSMbBk4njf5yIN1djms80eIUuoM3/Ou9vr26CnByAlxg7bxnSXEck29bi
3RhT2JHqpkzedarisBd5MewLaF98DgMD4GiMYjBx2MyzwkK1FtC5LH03U0xrCharYcvo9LTIcaos
apu+EGiwItNDqtyrZpYsMAnKpLATQY1zTBc8gMl9z5XqTc7Zc1ISV4D0w2CaTlIhggQ3Y0CL5not
S+P4HN2RZxsGn8b6qzOLrRbHRjX0BO7buVSSguZH0mEfqV5BcX921Nm+J/IeTUcTtPuT4VU2ulRa
m7VVE4jivHjQtuH0pT6lOGJUhazYkj70WEY0qktUZat9Flyo6KaWkJeJ8oQovLURLO0oizhoKJ7X
SeL+kQ4c9F/8J/tm9ZViOAmSgaHATqZw325tqmnC+kNSPygbwYZapv54cGuaFrI4RE51h39lYyIa
/SVS1aUC/RiTR78TbkrGMWzaIzzYSLaM0Bvy1EHckjeJCPEUEKNgdtWE/It6vgBDqUjvCUesTACq
meUK+qdACMHDXj5FeTWrsB2O1gGMow20atqkqE9JW0mYlc5cU3i9Zu+VkTFOBaD820qba0hPFxQq
pz2oaQBQJ0DWQksJCbCCVZcb5pH8xEkB8DX6m+eTbe9m8IbTKCyYu0XNDLVP2CtE1LHPLfXWVN+o
J5731VjhpF/pGmAvirxWGllpOEW4xnLOP4Jxjep/wzaG6UXZFKw5XkxEjvpmHi88eUNH7Svt65l6
dC32GmavA8VDshlg1Kh6RSVrbHUuSA38Ci2DzaTPR5MbselnHPw2tWk3n32tAXsixWRGDlXAczOh
Ymo6elz3WPzZNGG0FPQC6Eb4tbyCGCFqOqUR/6iBjPF5jFeCZZrEq4KmRDOz2WohkkXGZjepU84/
Ed8nVt78+ifJfNW7sFV38MeHIvpmDr+TXd0g5WENwxcgH3E2WkveN6Q2X3It3VLKGkWLGOpdzlzX
A/g1StPR4ud1SBt1/QUTpk9cVG6ofvXLAgvkABSZFPCI0w2IAeFlhr5jcPTsmUmeWShu6A4ZC77S
a9WI0HsI8Ny7kGFb+m4V0MZBDm5qjWbtlTj0f+XliC9tiNLtpaA8BT4FA2SbLGl0Hevntz6ZwaLg
Iyhc9sraCME/6mpwdlkojN9jmU9Ag19/Mb8xXs+t7hHk6nX0dBEJKrqj8uMimTAkrrlO8pD4vL5W
IzLHAsi0HTVmdSzpSIuowcYXTMzM5wrAUTRL9F1dADhrGRzljY5c+HdEtGyhhjS31gK6o2PNERQT
EyREdxDErsP76yd5grg0q2ttYHVQzB1OcxWfAx4u8OXgowlK0YdXUBZk396CFHQllqw8HY8pLoRC
14j0Twz5k9/PrgINOviBOgUA1JSxh3y9PFn65Dh756RSpEKuU7+qZWzJJt7/T2Rb6LHxDbMmk6uV
kSGfnvmwE8A76l3UC5QCYAknVnevWOESqL8gryan/Ccv/9bOVaJ6X9xymq+F/+aSdCZRNYA/WFw3
AH5SQ+PSDNYuxx0IUkKHoGAWsDwPGGwgoM1NQ2NhzEg3X7K67vHhaP50nrDRumuUcuAbO3/5Wp2Q
sfCD3pL+c65xajQL3tFAPBHdyn9beva95yrExY+vR49WFawE7ue1z2zRhDWYqwpH4jRRbB/Ns0tJ
4R+Zg9AajVbmnGJB0ZsamePQEv5XLM1mk+knPMLZx0b5igOQkfnZO5d7avLUaMHryJcohYxCQFPN
ACVi/vpYIHSB0NUHITt3OAUboTNYL/eG//bqCgzqVBv923RF3kXygpz3oq3c4+fARrCPealgl9x6
RZJMKx1bFISlgGNJpf+gacW2eXVmaeblLCmJ27AlQr0bRRMRu/c53HWj0KkqZOq8bY7kFxzGmn3G
3Ylz1fh4B1HSkz83t9fRoaeUtnz0Ggs/iAyGcTlFVieEmOH+vqrK2vk0gdwIQhMGSUPsphmXQ2tx
9TphJe2MS5DiLvQ5oZMYXsgYOAGY2PJrYFQ/rUj/gm4P5e/XXvmsUlWXAb/8d5xN+gdeRxiIjjj1
vzYfRiovJ3STjNceLMbFDjrWvQyC9/Gr9klyEuIAGp6Um0vAV7EepvpdQaap7O3pirvTBH3/4hje
R8/KKiVhtrJUOIfnEJFQteYyBPu/fjv6dRB4h9pOWmZ67FhQlwM1MmYzvMoJ1x/z2iI/gFx/t7MQ
W/6RbbCvsa1fK39MvNBZ39Zq14Mu9128fAiCUe6P3WLg+eZ++4UlC3IL1DuHQhOh/ium2V2GlS4J
ABXqLYHGh+LZq/9TRS02Jyye1fxjat4/dDycAAJiEgKhhX2oLjgUdeRgqP86x02QfaA3ymCvjOP3
EYmEVi/a+Xhl2cA2r60X7Bton9W0Q8Fdi7eDEkS5Nu/OUXHoZLivqILRgwDoDSvYYDiSXgJFwVeK
8Rn2jrxmNdPTLHhk0Ujna58gNnDk60gsUr+tp1Xkgcodn/6uQJtUUTkdIMl6xcTuKO1pldkpIFOG
kZrQNED+qrYvA2G/+3cYprgZ5zY4ktNsevVmVBmt+RJx/F9vD/G/sFsPWlhRKArfuWVQ1iNEqqKC
oKBcDo21h9igIvzKsJ2vfIo819oK80y+cXlaMVOE4T7I066xfv8RPBih3/zx3F+YiDVbhvsrea66
dE+uSH9441Oa+jC3IijMJWxFnjtcZQi+3b6AHJGdfyEYrLfuR+FA9/sP8NaYkLZrKQZ3cRG3nUx6
2mSiM2iHWIBgRItN4s5iRufCBu3spquzVnm527aFOLIVGfzJUlr8YGysSlV21ObB34EFT/j2ZGKf
YqZXgr4XTu46x8iJ9qNmqdLm4n+EOBZ9kzdqht7PLf0P6C5aMjwOAEVMkvX5lllj5XJgjTWr8gZj
En3RR/I50UAdm851VWN8K3QUt5Z8Hjhoe+W49E71beKF42BDnbJmvgXz64B6lMEolb7zW+bIGXno
/NqGU8P25rsymddw917U+z27ZkZ8vVfwYq29VrLpbkf0JJdLJ2+r9hhYT44UxB3E5aluIBI5CySr
o8HGMTzVc4rs9TDdu0x25BwpfYgBVfoM3EpPxK2GWwHTGapVWttbzTunHlOEYW7VOJ0Ha3dxPaQQ
7e7yYHQ+Q5mez+a9GObQkGCfclNFz88A1CUsnQdyN5Xtts/5n8Sa3qt99qTL5BiBI2ghDj/kyP5X
Bfsuqzv9QZiEJVl9i2H49ziB7p1jZyGmRTrSPwmh49KWaIuOg52fejcFrvBXuFEzDtdF8go+K4ct
U6L0WaDhuMCgw0gjwHeWINgQbtWtfxEgn8fwZe2XuQ/mqwuq+PcO1Zg7wgxuksjNCTGBfmI03TsG
RkELvzX3ZY1cnXc9V7UTowdaAr4rDoUkI8kuy3KFevCFlVyVU+oirjYT+WyzOsQ/Yd5Nlys6JAJF
nNIGklK0V9wsJIyU5yL/V2YL4a/JeihulI75J2G4f0nyXvaHTRim+0IUvuPZYNkNlyvmlMuvb7NK
4IGem0Ic8Ty7fGkaxKAeyhc8ZmdaJ9kOypCEFSjlmsOTDHOJMpMdwgiMdijW6kHCDdqnV+UajtiM
odA/WieftHjDEr3FHIG6SV+3wGFBOoFmyLJ4WO/3iwNPfgwb5m+sVhnq0uK68Bb9PgFzPKStLIRp
Fe/Sf3GUtoVrfR4QP3qfzqTmzU8meb+FH4i5KPBQAm0sv9xF+DlSgdHNQsVLjmfywF6z1GOLcOfT
PcynW7UlMw4riWyzC3I7L2U/ob+UBiRhv6JkVMJN2XVB5Yt7y2L3mGPkqHt6MbKGA17Baq9ILRAA
z2moWI1f7q3iGlEXC56s3xv4HGevmn4GirExmLrjqoL9IVXUrxOC/w7Sux0/fDA9B/o1Jrf2YEqn
25Xn/qNcH6G/oTwrcECneebkTl1dMV7VFp7fVBU0ZHEJcBeuug3ZDwLEacdtITb/RjEw5wouGFta
AfIBN1CYcPiZjJXT+hAf6+PZxZO3ACsG4zxZDnsUujubKWt44qVt6/EfvK9tITmNMXUwtqLb9SYa
J85nuoxIYdjB2w/eWjY3KHoTvBUFyX7qoTl4LBZdds1XNOTrgqIJLMHtouOV1HxgkIeX2CDPcC3q
4Z2i68hl9b1Y9yxoJUa43GrJQhXwYbLMaZa1d/ywK4Zh+9Aor+wPsyOwBFNkeOUepN0Ltc1eL+4m
YySA8coO57yrJ6vG+tcHjS1FXVTJdGRNLumuaLN1hr8AzjX1V/KcS4NGgyo5+APSo9+ZVH2qDew1
JsuiLu3iuGm5AnyUfTECUwYl/MkDOJF3D65LVoVg+ecUemgE0X+kmXRFwtMmFWt693JJ/X33xmEQ
I8b61Yvi1e7SItuKIoP0BYJ8haIpeqHrrA+q9UbjIrT7KmWiwObk4hiEdrnncAMylQ1+tsDJq0iY
y/RJvQTwQJGdBzDPs8FPKk0beeN5jFeZ/TRGJUqMcQarFvzl6D859bfAUWmgPd/80Tp0KoG3cA5k
WUD6TYkog5kY5VO2iTGf5CmMCM93iLQMeeD6fcp24yuGDc57cVOk19vLOdQDZzE/rSLjR4iL3DSF
qAfNyzBWuFxZsueFBUTdI9g+XBp87Ktuy1lTvXlF/TwFLB3F0Ybep3+gtoz0e8w4kXdaX4tuOpI5
kGqp9+nDjBwKdnI2qDtEkejkIfV89OcklhUbPZeXCGbSKL/PhLZ4wgUSvV3skaRtjgbC5Lq=