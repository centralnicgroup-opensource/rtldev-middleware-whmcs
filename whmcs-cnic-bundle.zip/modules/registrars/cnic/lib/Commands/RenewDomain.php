<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu6c0OT8/xZwg1LYbAGHVtGgw01JQFKvzzQICCqO/Gg52IMJufVnsxathn3T3xxkcLVjMeoG
7qTlK6dTXnalo6J3b0P7gV5zRgNrA23VDaZS6dffsEBtnOZT3ogA56+EU/3zlhR4m7Jiz/LVj6Xq
7eLQbKbl58TRgJ+c5Rp3bYpgaEZ5LQ4wOgd1CPOk9xUeqRaH9mRAd5l5DQVywS9T0e2YYY4gUNB5
4BFURhom9KvseM8VCKSaEO/PMfRbQFg9FtObAWM+N5EDoKg9JE/Ip5cP3c6LQXRabHNMoEXrCmyP
gBM7CFyV/lIhIHpBDKe8FuI1KBw4K9PBJkWEMMuTTfD0i5u/S3ys2C8l2pDtrfwqLxNo0FDhz05A
WNkezZ4F0+2oiYsjMzYFNCybRrEJk+FBYI8GWXGpQVVntaNXCN8t8N/GX0adfSbzLaOqQlmKxdHe
0/59NR2jvo+GNAVe8WLyGDPBrhzHdX3a6Cc7bIvWBYNfEX2TiCNWgqdTrsjK9Ps7gvBgK7PZ3s6s
QzUPJBg60Yb4xJQ2+YKglYQZJnU0qufhSxOvzXmg0aCdaoRD/B8pnBzyXaL4T0QauWfENtPgyGuj
8STLPudYCAxnT108EY8U8kvsMKlgy1HBYJG8Kg3EH3GD//+v2Vz2yApvD8kN7G6whNz37fB2xfNi
usrW/4qX3832m8hk65Flo1y9rZBinR2oTwHBkfeTJ4SNm6d2wyzhGy+nLu0G955dI1lxDOej5wwt
axnpIf5Bn8Uj6z08NzpORi72QS0Bu5sCpRXQ5Z3Rt4uVsnRxdoVnvjJklhPOu5YMdOQNkvPv7Q1c
gggKm6JdT+hyiEYc9+7NZeM8MPgDWWs2VbEEi+a2ocFWshcKRj+BH8ls+mUuBI+edUcShqXKyP2c
NZWN4MrJ0M7DHZtifDB8NxlKwh6jwOMCGGpvFcfKdhjvJPc+SuS3EikxTN1ZwB/1wuORmjAa4OgO
y82d6tx/jE2asCAyLd5JKTaKKZKSnh593V0EshbWVTua4Y8b7Ii+1iLH50yaaFXpMfqOfvlA9HFt
tDq8eKYKblNuXwcMPU59tvk3ZMRxUxUOvsfvBP006nbvp9fl10ovEkdNn+S3TZ9KEK8c4gucsvwq
zXmgvV22pLhad6Qj8p2IJ589QqY1pAO5smGToe7KuJ0I3wIInwTTAuMTmykU8MBqtRouWy0NbzIZ
z6IyFwRlwzf0KfSF2ZYaOLKxcNAJYmYWdAxi0xw8M6Sfw9QIZqLFydSwnnOv1Ouijs+8muHpl48R
bqkyo8TrYPtKNzHwy19C7hjsqXo7sVG82OOrdDFrQpaAGF+QZ45TfqjvxDxVvCri6Nj/p55f87Tf
dPvmWY5egvHtwTEtJhzT2mlQVH4K301RL0yzdFxZ+9yi+mtm2LsXLgTTpUFgzyeKQA2DgxgzV5D8
qqK3etKepYAeUpqpcmKABCgVBTo6wIm6TS5TxYO/xzFSUi2JPSqvB74eEl5L53Yfj5l6gNRtfupt
a6oTVZSgRChhIGlobSV37cRt7UBM5wZ07oJXLN1A4/gq8ILs711MdHA9GU9AmesPVTRAzE1eSfOU
oVu9jBwa5FwVBplaVLzxOhHQLG+P+vvANGcTH4Jc2/gku96EJdCoMIGifGVcVk6TTK2FCsry18YX
IgVXdk5Y9dxuJKCNvtNLj9Q1Av83oPQ6OaTMrqt7RVTaNwo6qvs1YQQV+/DfWjGi6U3KOKvgVNrq
6RMBw0vnS4k8ByC4NZkr8O2ClJbDa6uzoKvZZXbzWQ1lOHsMK2ZGXX7Tw1NiBraKbwH23J15xh3H
afhgEU54rDdW5q3PNsUamfEj9ntUO1BRDE1zO2ki9GDBUsNT3O4leTsP0WTmHpOznHWCKeS1QMpT
gFVwCgmI9Q7nkEXbu7Ul92+9rHpSJv+SDC+VlYklPqAaeHO60sDTKfun51zQWLNQ/32NJk6FTSO5
r/U2lwNrOUwAHNF9a99nHFeXuID/Q/1YpKaKKqsOPOnEAuNOhMpGBr8JqdF/smIimkKfAbSWBT5u
cYHv6D+4UZA7cIrGegeUbNpDX9RmJiCsZZzU4Q36+uU2PL3H3s0IXmMZaRSUKEgHzBIX9SP6Aekq
LTeTyUEVhvRqOcsO5CqfatVygaKOrHxrdrcV1xdZwDtkIUU+VstAgWPQR1wOOVoAOsLBU+j7iRVS
UkdxloCLANIk1HCsUttJeIIn2D2WADFnMnvm7rA7H2A9FyIKyOHTsiXDsDZI7udDesmLMely0BeL
+5XBPz6ZAIqe48zieR/90LJfzLQRpzQIPoy74mm8FkFLqC7ASOUwM20+AtCZcXgTphsEiZGFDw6l
b/aXnIuVKMDqZZRyUj8g4VzgunpSvdsYrVHT9g0F9vAbU6yYaPb6yBJY3qDI0dgVj69kpIaJzfG6
1jHGtFDWdW3moZ1R6/JsVzzHvyKW3xItGPf7a1K4Q0M9exY72K+2JXb0POVrm9PB7QVvJhNQtpys
hDfJqTMIduotVycKFyFnC5ZzExl/xexc1HFdMBXgYrnMWG8En3hbXuJKP05phdby0ko+k2YNAPfB
yykoPViHS8SwANMsazFAePVvjdQ0Mjol7xTXAm8sGCo1UJ/hE1NjAEUmoaZLjr5XVFKkIOPYLAlS
e195bRWwN/KE8gl05+Avh74ZMvD1eR1VNtXpK0wbZBOEk1LWVo6MqlnDSmL5sEaclPLjdMcftiJJ
s6Hn5aEtY4wp+nnjWaYQCBZpTYHtY46lRmciioWFCmLVwD3LTSHvSzt9f7QSkfO47Y78sM1wFdu8
/eYjAvbRfiQ1BQa8+GAtyesV4g5uEm7fv8QXTtivWB0npAtc5RL+72DE+alX9bN2+697220eJ/At
LFJQYZeSLfqPYMfgacFdj27xuRV2wjLBqxUeEXq27GhAklxQ9UVDvDW9jSRf4v8biUzcBTENEZLa
Tdx89qFa4gBuHZzv6uSmRjRCI1v6Od5s69Lr1QxRYr+B1uLXBYRkQBgzPy8qC01bgU7h63JqCBh9
28PvTYfjG/LMppbaySaCEtuweo9BDeBlBTsUZF7Oq4RiKr916msFsmj33qHqCnzrBWLRHeUlueDR
5xbpUdK1SGVWgAW/7jApmj1Ngn8z4ZDDdmKAgLVwoApjgEuB6V4IWciOitZNVJtXbq39SPnMpubp
s8Net3qN5UVtmoKtcxW7pCtPW3aM5uc1XdK6Bc2gpclEoQloud/OsL3lQ5xrHa8hNbV2Vl5dDXPK
z+DskcHvOmBHm2GpBeqPgCSS/Ed/pwHgLv4Z4Mz2ByvYGpTZKoNQRzb+J0q7b4bgpbbetDK0UFOP
lsW9ulVSe3qPwwUxRg5YsWI+ENAfbdhiD8VQzLbpeG2/+hWMtAY9My3ntwhpz9raVW/UH9gVLBIZ
aM6LjyuWersQSHozUOuwG12Ec++06P620z+yuCMVSxuQc8q7Kyrb2VxeTxFDHcqBSwPzv2waCos6
c+ZQypULBGXvg2JQ+2m2iCePIdLgl5JDUErnBthDVojCVNw7Y4fbXLqvQv7WW2mcvg3QYPEb8Tfx
J/W65SrxQWw95LbnrM2/doffQ4i1z2i3oMc0UXajVKWRlfJiX5OePBNCsD1c9ATL99+LDkdZ+rdZ
EHlZztIQskbC9bYlxvEsjjZZIF1Np3Hws7C2/wzqAIcpnO9zOw6iuSPHIevg+awzbas4CL91KtVl
67vNvELvNZ0fLZaDuqMxmOCzbF1lehfcN4LRMOwcCzPoOo5e829VbhPOg5CnlWra9AoTRRUfj49k
SAmlXDizXxs02WqcfZyASzgWl53O2FIyYiZ9UNMnQicOW6ii6zvQcobyHy3kx8IfQXg6X+ouTXCj
oFNVcrHgfUFPnV75v1NUVVC62jBnQNlLa1rVfLyt0Z03nQgI995tm/HakjeKvvxE3NAj4g/pb/Ns
cKoTCYJBGLDSHsrY25N0RxSJNQzOs9I/XGN8D2n+S0F93eYrSNqCNYVzv2Wdx2uPpX1o20ElYTiu
WNcaMjrWE3XagG1uHLdR/ttwgG/vk6ErCJ7mXfLs3btjvm7A6TSG4pkB0AhgCCxCKM/Uf0LAEgfn
ztJ/PYOXaEIPb8qODvkPT2Ov6Jxz+rtWRIVmfjBBgNoOW1NxMElHiIcHXcakpgBTHWL6peEeZddC
nQif2jBe4oF4Xzs+tOlV7zcVbTNaQjMfIzxLSW5fY3tZdR5yTs+ZDn2RqVfGkeOS2Jd3wD33STHD
2QHpKDtBDZ/ZM83dm3usXnAC1unW2cVZiVbx5si0L45Txu4R1YmY++ZZf66mnwf/FvKkm+VERkOi
VLdJKMSxTy5rJCBKGIkjD6J9Hf1TWTKmfdKDjKSvPIC8y3l+0uB9S9R1WiTZtJXr3OKe+CITCaxR
V9gxX1ZGZFbS5yOFBsKjycUyUvyBZSzGWFSMzMx5AXnCxRivdU2HnOnQEbUrNMR1TnPzu+bygHye
YqV8YkyzoShIGa/pyXDbJjBV41li++7oKMdNnrSo/lkfSmimNRFzXA82oCCKTQd+jQq1Vw+BVNO7
5to+ncmELE1Y+jwdfe66D5gysCQ/B8/wtJaabQZ7jni8qgeDQTm4iOHslHziQNIE5QcXZypPEyAe
hA83hoSPWb8D/JdXgTEvwklIzPiB633ldhBkdwg/XCmKl7SDwXF2zYs+6r7m6cSOEenAdWwmnWmi
4eqQVLPysD9lLVbHTG9w759ooGi09tdEre4gNNzSnevuKycPmvs/3XZxrPRykkSjOPi0ZZkvc1cw
trQgebZtd61w/xFnVviDVur6bAdULMOnLSh3U/O4bg1KHpeDe2Jmfp0lkS4QODlj28+QVzf2X55c
YarCDeSPG5/UZQ2yAPyLQMqOeURKmU+BkHHRHML9vqtSCOFFbJdmFMnl5DX1jYguSjzJ9D3KBweW
gu412UgK4L8YbqQ4KX9FSknPGMIZi7gL0RpmiNSRY+Ml5EGvTLmaY7GBuWVQCbzzouL+iHU5vcbh
2qVkFuWA/PsWi+kH+mSpzx+k+Un0VLbqjzTdfMMb/WyXfUAiQ+ZSfqCJQoSGip3nRy/H27tY8+F+
J7+jN9W4andsQqLxhbmCXA7JKy1tQwuKgD7rrGLclovkbMJuCnW9QaEKJzoOFerNcAXQQhuqvNIU
XIi02Fzx9XACQTAi7hgNB9CIpD7wPoByIsR2ohMxVd0HSPSal3ED1Fb/kMiPmcFsTNnQGdmA4P8m
GYR9EPsFRaAs0GKfY9zUG6Xs9bDl+16uH4DQs8QXeImu7GEdeCpBYxMPjSAo0qTMO0==