<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqPe3dVg/l9uywIRLDtMNHKSvk9VjGq0DvcujGZXiO0HmDYhJbowwYVMkfeDcgaOiljjKZ2K
5m/p/iodoyhM37jQeJY934Wetg7j9nWRqzBJBBmxSrMQxai5BLB2RDm8D1M7IjyaYQY9ZJG/JBsZ
XpfBg4halr2QV4mgaIEpIqv5kSquMf9BeBLu3X6GAPh5ihYHxn6lA4rGPYkifueUZfYWd2v6omEG
PC3Dgytx/eiBxK/97+63LZ59ypl0i2cDzThl38PGOQjJKu8SAFAUjXXANPnd+bkozB4Lat6/O1Y7
OqSu4CuFvTIRrKbumCnWLkoy4hsOa1vt31iE2ZliYrp+oY3fdGR1QtBg1/iUcqjveiYymp3XUAEI
q4Cri+wDWINIpV45dWJVsDFGuaAB7U8KoqW70cDoyifDhEe9IyagSH5dQ61ol9USzoY1kezs2O4F
gAcrLik97VM4yDlOIX54PlxLJXizX97ET6Fl/pAUUsnsc0ZK0gzx89h8Ozjhp/TyZ/NeUVzkXRbF
rrCF3BETMpjdGIPZxnTjP9DMPrycKIlZeShNIMHhtoEIFbCJHyosSluTZ1jt1qOsxDql1m7iVIsm
TS+LH4oOJz3CzbZeRkXwuQbwv3ldYPz7ZbaF2+3blHIimgkmGdXbwDYFWcKC5Ewg8+aCX4zFwVL2
w/csrydZTsyEL9Cn6R0c+3WUO4wpcKaRzaEeDNMQuz/kvtQIBAuUwbDoqOrVaf/etliwWQlSTqjE
gMG6KrwLrYAH2CirAdQIHorYc4SCzXK8+MEOYpgPME3Ka/j7dw4txV12YmrGfDg7PyeRwHF7TghC
I1Zj9KIIAb+rMZsoQ0ps9YGTc4TXBvdsH8H9d+DkLh2PEOLDW7BikAMdI6b++Lr3tbta0StAbyny
942DQTqTcPZR/2qTnqnnADpbeVnzOR15py+XE2n7JOaOlWFwiCDY4HYKkO4Nv1RXaWA34X9gvBLw
qwSs+/Oa2eydV+4sUUOcaZQPV3cFKs198Sn4toFIOWTLe436ohHCMABtZhdIOS5jSJQL/G+MKWFB
DvzajhgmPsMxaO/jyUblCmrfSz2w7otP7juvk9leKP8bFxrX6zvSopd/h+Yw0EQvrWYsnex6/TSM
tZ1lRENl3avNDD/x///L5Y9+k9ENM7gtSNiUriPHrdG8y1xfZuWcZvcAmB1ZSrkpiJyStUuI2plB
FOSQib5cB5VgSC1v4sX+G636hQ0vlzueOobb8xLIz9Qeg469ZV4Eh7Om2kZz8nszIsjypgy/AWHl
jbOZZ40D9lO8DnEEJzyi0fbzFGpOPBTdOk6nmG6vckITnqOBNR6q5zH7j3X2qVvh5NklPxGTv5z7
18IGHwVmmyq7/71MrujSLEcHGMYXKlFzOsrFEnnjzolx2NsLtOixLJdDtUA9wERbW93DoBLabbjY
do6FC8O4uobmJxttcNLYx19H7F4RRhJy/gP+lsagQ6437zz/OWm6Tek9CgtjnTf0m3021P9+gtS+
0rmhQGgSute5UvyvBS1qDViDSGG6rhCgjew5VRJGv5xLTgTx18/vyaBRNDmpzWA5HnDLfeH6G74E
4/4V8pTOE1efC1rB89jSX4yiTT/snKuEyHxNucLx9Zj7QbU9y9AJySh7ZsnPjvAr/V8xihWbsLRT
aD3BxOI66xRCsEjkceTb47YoLJ3u40p/A04CGUhHIASiVLr/3zAkc3Ueq5Tp6wWZmDO4BoWqr23Y
s0XC6SltDX3xSp9JMfXx5AVvrFV7FbE8/pzhyOmM1JWdMuMVGh3KkePxZz14QiP47s91flQ+NdfM
5Fi81DkUSvLdNJ8ip4v8Lzu/ugy9HUjW8bZff9GLGKUk7ZxpCTABI/I2vUj4deV/dF7f3SleLpJi
XajhXIoxZ/24WGdYJuhBePjanWwIu+dzBGX11Zxivm0omMww29K+NpUMffZ9FHCvJGhX1bhQlno+
zWdenaPzoQack5gtxc66NFqX09ZhOgL4KCCilSSf3Uwb/CuuUYHpePosVohAIo+kX5++OKtTYB97
kWa+RQoEeXDXxqrwzyYWODRD/733fJXsxImN9VhAQ5o9CDWU3wQ8PyJuYbcdpiZpStdU+vrMoS6D
OTcyggJmpPw2o5UfgJTxFe4t4A8mPkw/7wZGekKi5lhJLp9ilE/0VP6cboGLP+7MZ3BafihURKgR
/D0941Rl0tnzMZxVjjf82gTP4Jc9uaCrAGXe8PCCRnxSf8U1jVvWS73IIK3XLFkhUNdFAW54hItZ
JLL6lmxU/skisavXV/dq3aSAuDOSZdLl+vFBSF/bwCfRHAZGVDcOgF97Fsx6KUpbL1RC+YYbL+uK
6PhUrN9B+kpgykwGcKGEXLPd5Nua77NdLqUalFmQf0K/4F/YRmjRkSuw/7JQhnxUhSGb94Or+Kah
alGqtSA8WgU7sSE/isstM1YWzSHVr7Hb0DomHbyTwFxfCoqAfcOQKp2Iydkrj4DM6mN7sdXe0mfH
lTfzz2oKFQUDo/QfwtISrzdD58irq9OhBirKq8lgs7m3ouVoqSpPWrm0TKkMgMQ8iKJuODVObOh6
mdobUjSYyJJbUmlMvJha4RUkTBa+iF+6l09mBtm=