<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzQC1r1lKlndTa2ISo54Oq/m5gSdw9OfilueG+Utn9pYpA+zXm8brxewUwdM+hR0uNh+46eN
ta/si5u9QOsOKR8s5fwFX8L6FZdPzInc77k8Hdc98YTW4b2x5VB8KUsNu61oJa7WBGRYFpzHPrT4
w+OscSIHFw/PsmKKSl+Buh5Pks1LqWaY5QXiFYafrbl77tlycJepfDrE1uwSYiT777c6o8Dyun9M
5dA9DC/YnEONZaKWMr04rQrtdZ6GixugBakVW+qj6uMVxw+O+s6nlLSJ2XvcPWSmCDaCf32YuBP8
OQs8VH3s0v4LGK2jVN/B1M0rxNWfdK8vxYu4SapiGMEQ5oo1952MMf3yzpAbit4pLkVMObiEFnT2
dAjxB8/2olcMhWAdcAvRc8BjOEXuwudvFRiWZljR4dy7RttZAmTaFMIHfnhuDcsuINFBA+vSifnw
5gwMcIdjaOU0/mN02Nuciu6kLpti3eFrgD7KnIj5HBtwXeOHtry89y+oTSpY/qUozUecvM4zDdUH
y7F97wHg0M8h4OjT3Ibz0YGz/K2Wz5oXiu4AzY1L19g3W+ynHpVTc0o3bt7BOOiHtmSJYhNWNkyL
r9D/ZDuMTJ2+Zdci+Dqsax+bW9kRDgRmmtT2vg4H7gn8X9qkfCFnMYcxeprWBX2/WTQoa5n6ZgNW
3yDMbTXDTTiNgdgFVYAuvAtyQgrxOBo7RLx1EktKJK73G4OPX+FfsB0V6aZx5Qc81K0bhSuS9ELr
jr+rrhUer6uYpTImvlQWzMbxwyv3O8MMZG00bDQnbBb44foVtA7EN9IbjtdH/fEDAdu/r9leYeyu
PeanEWK02X/M290sJTU0ajvJ9lO7zDL2KGWNU2QGZkicMamKVmvbhJLcTTcU+ORy3GBSU8CDulUe
Q1dZ2h9IqUZLUBumK3WBvDfvUzKSHEbQxS1zoi9MpMVgMAoq/BAY7b3IHwnWdZLOkfrLr4Rh+ngi
OkEXOhZ+xk/FjNjVZYd3lH+mrF2DqcfI6TM2Nf03l2odN5DyYDLD4HQh18+emstredWEGpDGgKLI
0few4XIacv2O8hZiJpKzTS3oTE5JutwQSrlfNdPHRz4qS8zjybVZycuwmrDm7vpumSsRjHAVXiQt
Y/W0xhyVfoeWxK69q0Q6Kx6zwwnr1y38tPYLvd8AQ/BphK1c8DOiS4cOy5gHf9Lmvkj3eJCSwMgp
azhW+wU+Upys1JcKjRz/lHTCvK+1MPKEGr3YexxkHR5bCzwq9GosH9KvmFTbldQVgCEUvWprlxSr
GwwDhniMxidV7qSDhS7e6JyWmAoGLQIriE1c7XLCPRy5p1olhQvhf9VtVOfh/xz+rrOxhBCVeL8x
4T3O++jLNHezRLu0gkwjXOaGMo0DTJXyJkkrqjy9C0Fq24aGsdCQUYxt62oH2MHEgaybsS4tU/KG
BFO+dfs7gHFw5uht9V5A8kG7wi5hsqzexk7fkY4ADsZ8VhBZv0JN+bdhxbZkAP/qsBOB1ULvO1Um
BMMCtjksttLs34kTjtGwIGCsaQIrKC5OSKQagFVuOFiSKLr1XibDIicte5nVQxUPgzY1itRGAPAA
M/g1n5J6Ss0AUMo8LhpNaPILLodRUccpSIMqMu2iHYWVu0g+HLMfEzFnYSz52D/PaMTcHOilPe23
QNko3vTWDmbqnVXajRSHMQAN1Zi5YMs5uhH1U9w+MpMn1o0TbDXaIqT42MuzIypiIa++9a93CH5j
EavsJHSxWNeSMo6ri+4W4XSd7u9biLLW5SzlCe0jSdSayZiTDsAP26zrMBIj8zehdSeS8rKgsW+3
i8pjGHgQvDWKhaBR++Q88BV/dHu0xmQb5jWA0fTd+gBPJu7538OHnQt6+5DRaWVwPc5tmFahHJ0T
PsJmoluHWiUAAaQEz0IKTlKtCa8vGHUXV36ATag2ezFW4m+18W6mYsJNGpLOz69baNsgor+AVJIy
emZAIzLhZgPnBUSGSiRel3ch4GPeL+2DFIydIZOCrwk1Fa6pP9GKbPdpXmGqQyFTnlFu98TBAdf+
Lat/yyEcJjTZg4Dt/YRzXlgJJYzLUVEvR3W55KQB3eoD/3NDIzs/nbwnGXLnrGihENKU10+SzHU3
0LOdgr2Q6466NvIUK9KmGfbcybB3UC78uHosFvie4YOIE99e/hRFP9bFgGRRK6PW4ln0HB8vGrZU
w2LxhWNqlEAii2idL7mQqDF5opV8+KfOQgXcmwS01eTSzDpAnSmHgKndVftGOUVOpG3rC0wM978b
R2M5MSq7O/wRsWUlXTQlhFQSBU3feeT1LSYRKGzWZtdZoYGb5lEgPpggfDR0L0/dKrtHtB6ZktiA
lGZM1wnQX55R1oGc3JIomr878BZe9X536N2O3rSpRR1iXoSum/ff6q9607Dgqwmt7rs2Z5toYbO0
p3KegcypY+Ddm2qeOhFMj8msK6mO0yq5zh5ohJ8BV2xQml+C1hL7Lc6HRCkz8RVTbvV0Ki+Gip9A
JGpoxLM+Lu0/rSQxynDBJPTt8U+77La99Bj1Ql7V31sc1rXD7822QdaoqSg+KmEuYKl5s+DyxNe6
Ivt6jNm2hJGkZba8kmyWrGj3d1lbnp7gPbazDT3VfCYtHHMVdOtOKG5Rk/+iMOyE