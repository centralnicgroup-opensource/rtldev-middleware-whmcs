<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/yfouF/DB2QUF1D1nRSwxAWy99CwJVV2CfPX4FV77EC8aXx5pDOZbYMkR0/K/acBD8upbcu
8Oi2lmi2Oa9sLHe8+WU63Pm3FO1D3mYQATNxvaCUGdOFZ26VGzgvL8JhdE4MWar6UGRgf6+Vqclm
+WsnbuMtNblomOXPr5pOyU2I8MzVAAvE2o7aGPNEcKDS7Rv8SqzyxGcqxAi0aBrnVe5gtSPG4LM2
VtPiW8xQWyBYqHXMwNPQe80dEFYEVWZUTZyw9h7/R3uQsGryYXfCcmOogysCP3UYXvZGoMehEs4E
qXreQGMNK885hubd89HFi/SsLRL/EcsKxG+bzqb2Gcx0gN49lAO+5cRqjTUDMoafms/LwpR3XFjV
JBNCOBJRPwsa4rt6ePi68s/d68vAk1tWoZ3fh6P6zpwwaVXtksLlng0NWD1z9iH0tLyoIq2s7XfS
iRKVNtgKhw4BY91w9KhMkaXYfaCNfhG9X6T/JIGap+IVlQjCynB6bZilnnCmP4VBW5yBNjD6W5sU
ZFfJP96YyUo/UnV5KObHiAWDyBNBct0xbBv0riSr1mbXdDrdfvG0PGgEu462AVLeDNMty7Tmq6ah
TsbSJ5+Y5RzWCFVFKVw4r95KVRoZ0ZDvpAZGwh0ttwkBmLG5mFitmMn//u8ra2QDTEnAKVfSuFpB
cwJoTSl49ZIaMIG/Lgz2V/Df4pvVGcOkwnIhYr7YHg4xPyjy5ahjBm81+CwZq8kd72nSTEGJYh88
tEN9Ct2dWeBy4esi/Zz1evpVH8/9pFS+kR4Az5G7XC4ilyWHd52cGFpvKXl3a9DeDUjcTaPrEc9m
ojVuciZUM/9KpYHbhmj77qYRPy7MCQIboIHRo9b4YyLgE3Z5phciPozErjGGh1+HFJAL1D2S8UUM
5PtKYncPkgdVbZVqDfFsSzFB1uSTswFoZdUIkFORucjC7LC2xAfjvGF0H960ueVncDGBmxEgexcY
W8vzTC4oB48sPVSGGdl/V3LuDFzSGGlaPi/gdFnWnOzgrKMqMZjFvbjJr7aRw2xEcFtJv4Dso0yN
urAfqy9FkRJQjlDe47RTWCInJzktexYdMbfkNL+5BTU9boPWT2xRAFwjaH2YJT69ouwtzeIB9WLI
nh3Wtb9cV1jOrmhm6NZEjyzOXildAuoG95BxoaalePxaJxTnY4yIjOm9Rkv451dE6ZXPAnTaScNd
ommTfi8koYCC7Y17Qtgeg7/1RMYmD7hn6BMKfjFrueVMfdhLFQYEnRBjR0r/SHIxcAperhQK9eQE
fuNKuYL6VoEFdo9AnCimAzWDZvAc9UfjkXp+i+Vrz1vZtZZgFfUHTvUBa+W9/cW7OwRX3W1bMKJy
gOKpJAqhYVCGSqfKk6HqD/m+BYkGCAh87RMKUqZdif7RgMX6c98OeHns4KEQr40N6G4AyfKVjRel
VwuHDoHjWiRMhnWA7rjF8Mr54MTOBW6Wf2otriOSTZTToBejleF0kEiR6OHtreE0TEq8xTzBZzuj
rMNA4EMsv1cPcRQPd4TPP9rjWLSQxchvASQS3tZS3WHMktp9vsPLY9C0gyGrNWW1AdEmts3ym7s/
i4QyNyc0b+Vv8ySCVMuv9DBt24eaBNDOxCAD6uq0qDqEhAqPQ3MqSGJWcCJA5u41x4N4WoO0Gt4D
8Xc3HzN5a+WMxV+oyx7OGnRyo5xJTWf+ra6re8HmQ8hPH+F4oi6AWyu4iD5C3371HMU40F2pz6MT
+fBPYJ8OTCoss6FLQClqQggc1Cyvzi+RLH2XWqdnk6RodBqPUaaPe17Px42UnK8dNDPh50yTDg3w
OxQLBCzqwIFwY5yUSRNRKH2wETzSFmHuAlXHZ7jUGeuJNtVcOBDxgnR+ojGG/GeXYgbEXDd+3Bu2
d47GWKoDwhGrxZArhbfIYwHAcWJ1qdGMNwn1eMcUhk3flRA7AY6HWzv0ernGYkQuX91NDywhpMOq
ym21du1BezYkFzny6VOwFmOFBhFnXyR1WZGkrYB0Q4dFEcWH2260/CXttwMgsbG6A6D6b19cunfh
eFD1Fn5ZymymIlemexTS4c90WAeJZ/d+x0IJ1oKPO40uZJ161O1Vr0SAPfQpqjRjZFSuc99vdME0
cXWT1bWHwySaACaQep3w7fdrTjHh7ils8tMLAkg/q1vzaRSPVjd694VR8qF0FkR3kPvK9Zjk30ai
MxpNwozq0xD1AM6/o3+2q7choPv/poDmun6/5Ec6ncXgnc6KLd9DVvDnWiY3XQ8dTodK6RXSYPoN
9r5U4vflSZFiDwtnmaP3wChOAbDuBa5V5C6Ij56vKRz51SDdPZzm5SJ83Ue9bp0ws0klkPOGNSOF
CR4qiPhS6HtFjQA7BjrJxA8qXzmVp8YX5brLqD/8Ilp1kIfADC91HUuRRqdpE9oZy51nxKoB7txy
+zBkKTuabmj5r+0zAjv97l4q4bnXCRkxCsG4ctUrUurv+/DHexrBA9iDaKMgym+FxjeDtJvzzfrm
1b2HlwgtXD4M4n3jzHf0mcatQVPQnk1sJJ8KkpaA+OsoQUAceKrmfG8j2ug+SjWPH03ra6S2T/Iz
mrApjlZyfCQZRbq9G8HKSmSmPsTz21dFSR1bN+g+