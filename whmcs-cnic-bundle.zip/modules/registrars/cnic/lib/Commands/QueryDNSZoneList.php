<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+3GAhI1SQ+xN1o/bqJpPKjcUJfs1YbAjAguDrgGuVbjx7+y+zt8JgXn9x0ReGY/72KPM00z
D8Gv0FDnO2Z2qxDmGPOL+mcGgdgjNGLxPhuqa1bJqYMWXCU2E/wEon58Ilc+3yCaSlDG6obx/4PS
FrzzUdltUuk0qGPX59gQukqzHaYTVzZ61UqFdCtv3OXGnbY0uuulAQURKSnelybVUCR7W2acVZkV
3ba9amTtTDJLJEDeKf3d4zBIu9cYZR26IWFQ1RvSKut9IebCxzBCMPaEOPLcME3i+GS7kJ6R61du
BgTe//6iXOUEL0g3ml5RjLfzSCgFFrXMGMNi1Cw4az8nPk+CMfWmWkr6L5ltcJS3zz/ev2b2UL3Z
bQ9zRcECmh/dmlxoUphhoLxA+mkbpv+OmbC0oEJNuL2t1FY3hmgZt4ZQ/8quSMuNftWoiJGrh+IJ
e5srEp7s5vJ2nZOqeB6oyu5kok/+QUeUo8Yqg3+Tk7rvOUGSFRz9JdG+b5gqgF/BxITn+py88Xvq
zuwG4rgZPZ/2XI+oeiSVyOH5WlGtxkQ2Rm0Zx60sn7I9EgmloVU0q64ashBcC2eI9akOFZPZhcVE
lwFI7ns8fbjdMY8ZoZBlcudmZ3qJkAm5NCmWfO+B8YB/iZevHob5CvbbQpd1bigAYwJFgNdZy6Y/
M2F5YsyIAWiFJaI8X+yn0JyFBITg/WlSpdJTr+A3YQoGzwezbjFk6OctTwSQAZwgBfAKSChDf5JB
GzTUASlpatEPIZvFqQ4rSlJTCPXF/8nhjDXr0cz6CliJiz1U2VxtWkzSsByQC00+vi5yUqowq4ty
7Zbm9oTR7n709bpfGtaR8ZS/Fgvmc1Mq5lhAq/h7Dpd4NJWk8zQMxR0OheTwGew75zEb0OJhNDgy
XFQwrSvIMTYKrwj7COqdBNii6JSixzYaxGZi24FJJT7EFPbsvXzEs9o/1+BhuFYnaL0zoagYGhnX
1kLPSJDUHuvL/i7NWLuPObbOa/sqMsAeoLsgQiBrChbHVNLcMCyf/I67+09gZ1OKGJUwOHk+sM2H
xHKJfjUCg6K9ZGXsXiHnFWkwXPTOvfLNVMgqyy3IKt3YvPFneKX0B1CaiIZHuB5nSjogHMLIulVv
huRk6oqjjWM9Puuq/cC9VIjTYo9SlONB7hqDriKSxkSLki99Wm3nqp6WbGLPhlxgZQwXEiGqpvWO
Ggom5ogfFz7CCmqG05hBXsBpdL9jJDNuABLrtATcy+OGSEutyRALDaZ07u3B2E8WoK/DRa7anGZN
ftEgXoYzlv3YMtAYs6cJZIb5lM4cp2J/Ks5OAlE6pDE3Qq1qzEWSi+uP/+vUdq6Sw0rxIANFEMje
TXXV4BKnSDFyU0HwMfkIbs04xRgAoB8J88NMewqeStnjKT4YzxrZEcqbzj8Fq0IFfAjA1eUYvgP3
7PqWa29jLOOGFgrcsY01qwO6NbmqXGDXU9HCrG09sewuHtiMALCBEtXw4JAnLfAP8MYpnkg/trHZ
11AzcY5jeptZqlWEd8rvQvmR2qPvl+A+8zn3wNz4QimLM/1BrWM4/kDfj6bM8dwe6YXqVb/hiTDZ
zfwABGUPGVvP4s9c5t3Nt5upKIWnP0o6h4lkpPJzXhEdEDmrYo39pZeM8RW/rQiqsx5su2hfyl1F
k7NG60n8d5EfzRhk9r3M2VEdvvYnuSUATaQl77IiSYxY/dpayX1uoCVQUkOMpngH1um46NezKTk5
v1qWaMJvKpfIIZLU+hGwqfdtctPkZEZNLAxfenCCPCQdo4Q0xNarytNlALLqy6JddP5qRv7Jbo53
Boprx7NFJcMMB8RhDaOHOFbrtH/GScBqywPyqMBjggyW1eVqTYWJsVKDSLx4Mffceu19Wididu5P
J5QSN8+/zc47FrgKm925d5pBrPE+WLuucP/AlObiQB88BUSwUVn++79jsKRjonkQim9MP/hcFtij
ov1tRWpfyID+MYW+1l3+LPcEwKWRLXGOxLXRDLu802pjfm2tw6QgaBoTU/S2OgxlGeJC6I44kJAZ
QuRVshShCSQO2PqiGX4TldpQFG++0mgRTiCQmZffL+SFIC699y7Xc97XCpyDo5p902ipeqwb5M3A
o4UEHhDOv64VrdWdOxOtYFs4Ll/fWGXtleDTiUckD3lJNlIAw5ZYtyBPduZzl7ZOswEJfsNrWun+
fpbOB0DgS5vNHKg2MZrwQc1jfkf3/phln6rJAjuZufTURYGkMeVIAvoBPW/Fce3zKBUQhMk+ot+U
VBVMornGjWkaJEKXiAOUOeq4rslduG3dOT1SdIkhQRihA636gUNMFeQ9eIiCeX9CXDRadntT4ex/
E/ExKGnzQhwiiMrYQ0Bol4sFKtz2DevnFXW1M33G25BNMAmig+Axd4v3/DmZQs3m/ZtKt1xeNmni
MebCS//e8/0LeI338U0oM87lWc3MfAY96NVsb5NAaP5wN+ipGKZl7YEYcT0Au9fPhkoH/pXKf9iH
emiX5/198N9SIHn3AVdjt/bSVxYMkz5mfZ1RCrnU61wVaP36Eg86SA+DAtc1k734AgsIwyflDR2l
atN53gaw8FZnuSapUT8IjArcZ5G=