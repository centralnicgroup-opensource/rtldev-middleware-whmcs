<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/HVBaY23fDlMvExQtdjhw6YqbJTvvbMOBoum21u06aF1Ieoj9VlLMuhius3fNEaaBmXdyYv
sNjJPr1a7PqhWI3+nt8+JB1miVUcShaF9KjbjUt4yenfhUIlQsdrI+4EtXSZJOBGVELWaJCK/Ycg
6+QCqlmqwrjheoQIIwR9elrR/BEkeUkvbzDfGqBisTw6gJYIEgDP7L0q2DOiE84gzn3w17Dtc6Nm
O6nVyx5nupZ5tXuYto7AzJt2ef227ydAUbJQnj+7fmxavcCZy2lxBYlnllzpRitbTV2kYtSkVe+o
HEWtUWuMCImOitCNRWKIPMNtw22D4hOVUOi5PvzeCCBWczD40BfrphnKH+0uRc75s9or/UVDPBvq
Vx+lvZqRreTK7+i3WvzfUOuMScJXHelqdLuCN2QVvW2v0nSEbVvKQ2A3GuD+zktEiUFTlp4r597E
gAVXNTCs9ilPDo/DrtjKXCXvHPI2VS6IIqkZsX7Bth9acOfh/wRK1sxdHWNwNTMX5V/KdBMsaQRD
6o6GyJHQ3yetmeRvuFoVRBblFhV48tuZhLYiN76o5ghYn4mC8edtWR2COFDmfdRuUaBO3Kki049m
vdBTvgUjyLxrHM2Xm3xjrf4HpVKQ6RYiLI19VgwzjOdimmKsfR9MsxsHYaLuvlF4U+ChqHIiqjlZ
n9IIosoV95pPntNUs6tMBn/9s5y+bCOGB2kuD8f2xj8KXJenGKLTQrTw3bvXFfkFKYrq5XXMzuhz
MtKQfYHXUuWoKXdWcpFyjdynap1UY9sj7UH0viE/OvEjWbDmic5z6SDXlD63aKS3XX3t3czhFqSV
S8fzbUensrK+iFbSYKuKbEV6Dy0sf3d3kc67lu5S7qWDlMkCVHR87K12HOWXHO4//WnGQ2AWLISE
ldQDRi1YwWlOQi8PE8TZSMzPBG7gJoe+cfjbrTiDCitK++XkJeO6z7jumYgo2Mty619PrZCksABh
tRMFUe3j0/TtdrlvD1qcLpBMokphytBLJQDE0lXVKYBVYiB6sToKtj0xb9HyNE6H8UyZXZPkWgCV
51uhOrwesaJmzs0iFKo1gzy5jKpkjWhlCj/f4j6neCA7+BZzb5kLWixW6qoX9F4tGIAnxHFp4Lz3
ofIKNwX1rjV1R6j2tQmi991cTm8EdmuC6XJ65i2q1Z9PcbkXuCE4AKjCAeYYBZgezB5SUvj85X2X
p8rWiIV/2GnHXpbXBVJuWOJEpP+qk6VL0tTusE66bYwz+NIMrCF8/nIsY6XS/n7qKt5K2zqsdIGZ
JzsJEhTKbuGMH4JyRl3zkZ/BboPRPNQfqNhplPIMNlrYDG2+zmpi6pqfOOy+/+C+Z+Yu4vrhicbb
oVwvKr3gCFZi8Luk9t4j0ciY7edRQQCg0sDUMkUMEkzYmC9jxh4L5c7BZkMGUMM1zrWKHiXB3qDi
OxPwyYppPp2ANF1QbdYUV9fNc+3sN7gV9KII599OQ0d4E3zjQRth7I7fODBugk3JlfYdI+z+rizq
iaUz2yshRiBTlUBvJB+vaEn9umgkK8wbTN5ogJfXC/7NlwFDyLYoR4uRri6Yu158I5OmTP89ky4h
zTw3WZKDGOvRMBuGnhXym2GfCv6QzDVhGvRyolAcWzNw8+u+8tHK1B31XiA+Po8eNoht6NM+m9qq
2rY3yriJj8IhS1oOclaUnNVN5rqeuKhn5nQrjp4tyo/SWMniJrwfCvXDHOncUEv/5FJ4Tu+k+Chu
jHBa0dAtiTIWZ5gikLT3stgW950B0mSTJCfDMwOmRBwcGmpSnQfHqoPi4Wl/mcVir9O9PUowJeN/
RRKGhFxaVDXoMjH7jH9SWK95nDrZdcd/2/nn+RQCIeHVsbyOqDun4/4qNt0sz0kiLHHQDAEHSuP0
46Oda1grs6QetS6n0gCQNtW73On0+j42W2FFQ+nZMkdbPEKNLIkbouK7iWaisNELKH/zgL9qj68k
Fx+l26QN0M0ZO0Ks+3z882zPo8qW94W2EKxGw44lW3MXNhv2D7sjbZaiF+g0UKO3KJhDFI3yR1D9
8YYTStlMq2MaSpSjfqwwjVtCq6WMMu/TEuIWU9rCPTxi64BGM0gFtnXzIp7tQwKnglSPSXy2mDPK
r1Ih6QiG3xqE1Wro+bCjzkfCJe/2nXl9qqaPTwhAStFNs71kRGCiem1B4OKHKUm8UWnQMJhLwMb2
stPXWSiDtiYVcDu7rtmifbadw5IaOn4+Sj6A3sDbG170SY5chYhkEirLJE4Vj1vuwSfUyQ8LlmRu
JLY00N1+st6hdIJ98q2OJnvnE1SXsSacN5yO1QaHB6GDpocKiR80Wr3+vKhiy7YXOgcv0tq/Um7Q
CkbNx9FEGXFQh7ttL6+CBrFqegKl0x2sdDL8JuZjhBMAdcKM6hLvzsip4CdcGHX7zJRA5007eSrF
+nRSp6ILuSse3LY6PusVygju3AbEWIFB0e9thrq/K0TjPHpcdZGjgMLY/SvicK7EWCk8PmPQUP3c
gFE85e3+JjrPuk3gWJxe2YufwSCPl7JbmFGuefZNpTJkQ3C8rOXDk4cKe18GveGHgUk56hTTejJU
OHg3f6z4WLru0Rc0fyjuMDVJoEm/vQOeoXSbtyJ8lqLTD+8=