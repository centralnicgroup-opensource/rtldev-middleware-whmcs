<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrgHBbZhCPEVybsxUyebXg5CNznw9TfwPk8v7Yi2MSPTKzyHvgC38efi5QDbEGrZrVosnN7/
gS9OT23PmWhVvDWCddMBIHyVTwf//Eb/xtSFs++gwG+cWwUFji6hHNuf4cKHLJ2URaTJ8bsi9jNx
8ZRIV4MMxi9pWMP3x1DYsnYkd7FQKTw5YxETBlA4AFMyQ45GmC432W9nl3KxCO9kpTmM0FHF/Ier
WMnW/O9kCrKcQobZxkz/gF2RGYn5CClbnaE72bjO+cwyECSWxOCY2wa8ffCoE6UAYiXJiV+cPwZk
YY61fsao8wuHLAKPlUCb3LbVe5d4BWwNVOV4euF2pax4B4cJ0LG1Nbg6e8hkARnILhbJXYKVwUM9
OZ1Spv2ZsvP53Z6N75TwI+fSR2H8gznc3WuUA6ZINNzHeQxnNX0mOfN9JcxuBOF/MagiSf3/3DE/
0mSm1YHwGYgLS73DQqMFtJXo57QcsYhqenaaCqyiXjAsFRnW05gG2G8qW1r4kea8bISQonDNS/Vw
JWXlxEu1OsO0x4MPyDNCJ2KRJlenvcA2RylVfUl8t4PauM9DOuA58Jh1u6hzA1VGxQd/4LP+9QaZ
ix+ftut8DUDxlH/NndgVEHM9rortsxthr55LUUXGEHNMu3QSRholQiwnKWZxIDR4z2VaWvBnAVOx
Tb2F+k3KWJi6/gZBQtwt06TP9Soe6L5cXC0VEb58/hOwhZfvGzDCr78hXe3amKgrrVFOsRcQKLFi
BcmFBq3CsF7MT8ICbcL6SNi6RtVC4w26RY/Kb+FbjoLpUPCpP3tT+eCiVft9GfbVaf6gX9fhKolv
2rXkG7u/VKQzngHqRbB9SWJtROn+zHa4OcBsl9oLrUVMxk7iAZ2T4XDqWKzzakDh68gDzmK5PYtx
idxHYxgxFOMmdHoY1G70nN++yTBKHWXO5cOp1W+kxFUv6nnjhntc0h1g1vPEDE4M59Ixfm3Pl/pX
fQNlM5N/E9w1ucRwl5I7Rz8Z2A/pXSFbyJPlWw8ZvgOfzSKWS+XcywPEbXMj6NUxlufXvToqcYza
VKRgp27mZxLV3Wo3Qh67u2vU9p/kSGKr8i9fnGomgAC85n30h3Ezg8z93lXIIsQI0jXrf/PPgRVk
Xi2JI6+/UG5Wd03eWGdnKwQ0OCrQE0CHXat3otbcRfJphJ8UJ2nHmhUmwVfTVTUSDTuR6Yff3xy1
nzUUNhhkNtrdZgvUQOA99xXMaUdieUMhFRnbw4eNUrhkh1uIMA4OfD9HrROZRAtLMY8kYHDSNQ95
M0Rypvq5+WfRxscT0n5tzHtsT91FAtW6LZWFKl6bpan+WzGq3+KYj1QB4BV2ZMLLlMIgb0F/gdhn
hvjNQnMKn5shOOdjJ80g1xT3ayi6bPyAUbHBUs39FGSRFiclUeonyEVVkSBQVdqGebALgIIY2F/i
O3zX+LvJ7k614GnX3YeIUe8YXsf3ghHow+kVM2oP0Q/LJe1S3kFbn8HUo+Ti6Epa+BPmkarBYgkf
MXy7DUABjBk/Xzourgws0+n+p4oEi7yJvhKN3pxa3j7YlFG1xNukuJ9XBjsUv63qGMDEGQ8kGBtc
sbMLY43oDKIVPuBmRIdOqj5EpHTRsNeJfEByPqaMS7RyHtE+owbE/SdBNPiXhvb6Z5t5knGiJJVi
uderD94BPuLe1sdwhE7nGrIdwusUpK/iFfJ8FpAUR5QAjIDCXlTaVzKNS+Uhat2fXQg5J655Zzgb
LfFGcC9Lq9nnD87m+R5S6JQYajmPKwoA6Im5xMU48rbZFnYzgYpREy991JtYVsSdPDhH5gYgYdF0
ZQaCDIlE9WCAS7rrVTg08wikdGsove00FIQpgSdQoxUFie6r2vRH0oo/hpfpG0nlnj1HW/pDGyS4
/ckmdffSQkTInLIaz6ZIV47rN8tj1lulmAURVaDFzMUvWWQS4xqkPMDrnhtHZL07vy5hTeyMG0Ed
DZHu9IAh1Zxl6PVZZ2gcFQXc8DWCMGw3Hymhnv+Ogy6Py84RX+Mob4v2DxImmwOWK9J9esmKSX43
+LZjINBhBoLyt6F1oD2vHdXN3sSQ/LAH3KB7hRHQlGow6nQW5u39CUauvGt7RIM8eiUgDcK7LMI2
biUUp08QaMeS/8Phr/B5g1vjemZ4Nyt9Pglm+70fh4tzP6INHiuiEDHPVN+1G5lQvJ7I1FrDSVKi
guJYOtrzKVvOLvPIrBxulEkVT+rUwdLkjtnvlYRzEkE65Thi0hwrOxh+OjV5M/7f1qEQYfIjPwLK
5IGXJhVjQpZEroMwQaGMQHGSnN5H/TOrLmmUb0YqCOHV/dkqEBaVj8eKtfYHFG1r8aWlXX1Oe4h6
4nfKbQP/khVJQa1aMPBBtaS2cJg+dOCR30LxQKzGPn8qH3AvxZYLTikP2mnCg5RdXZ6QG54WCsEy
Gm9UnxCLzUh5PDxtWIO0Fne7GtcOy3LxTg3Hrv8O6tNZcVBfYte4GVk8fMjYeeVNHmhAQtaGs30X
ZDnrh86KVD1oDGOwPCbXW/UGWjK0yFQLU3ABrXk49FzQquz+3ltyszefv+jxLvrLGESl5n6vOuuP
S7L4Hreu5pDkszDeC4oqzRHlNPDjsB/lqPWB7lB9NNndGdsvOLqdQG==