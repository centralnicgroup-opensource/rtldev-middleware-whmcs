<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrLZAqVYuwze+w++P3TQlMIihe5Iv4FCH/EB89a9teEYuP2YeZxzScRam3jLGxXxwZxuiGPv
yCmOAZY4XM6z88iUcedsiDapj2HYLONOURViHjRARfbFqao8ipPyxmWlGaUrFzwHhuOYz/6y0yjG
uCa7bfkIegCgWg0UlgQX+haz+rbj8CST5xvzlbye4yr9t/wGBGCg3Esj2+k0TD186x7zmyW+Qhui
S4YUZQ3YEATNlF5siiWXmDLvizk6+KOZX57gZsbX2x9KEJJqeKQBACJ5XthoRcHMjQfb5cF6l2UE
Px57VXwixvciez1GvnNjolrtcrgDcHtnKvyhAzP8LrKlZ9cUXJrwqBRbmBM4E7gKL+HrXYLqFxJO
r5g8Q01YQ6/FlVhpno/pU2gRD3YrzpDafJH9A07hZq4pYIcw2CqjUOCoMlWTJ5MPNaEX7u4Vyj00
kjoH71wsm48MxRIzXKEZtEZVbudETwgXOcZnJFl2T9q/RK0Huf7MHanpVPz58FATEnnb8MWpiDFR
S6KHOQS+mtaG05HUFs3DiKfOjOg/aAG91Av+7CsvZfFBygUjUhOYFO5oxuEgayrAdb/hD0fwM/xy
yLY5bST03Bcbh8Oi1iMLzdY8GuKRW3uF6MRvb7Ve7IePjaGaRvz+FXsMYWxk/8oRTkAxVjsxrQRQ
GBg31jPVVxblYqcASdIJJQoVt49B1l7RnxUAYKJMlqkqlqUi7TwR/Yip7Rt+ddmhmEirH2v/2yoU
X9a6IpQR7UkFwNIZqRCRR5VQBTgalQNIa2PPWTA5WtZlY1p6uKzmt1zv6h+9PMv+Z5168j9QzG/F
IbegJYcVIKNBtydYdXhVQuSULIUQsC5FjgwuMRS5Lc0F1cDH+Mlmp+WbyPjk8jWR6TI/dNzIU/jJ
a3wvr2x6b6Vu73NQ1a5b5cNSshZSyfizc6TTb2dci1yIRPDPQcG4YyJJJ0WAs/etSKc4wiDqyWb/
cBy78f4SdEZ0eN5At08eD6UnyT+T3YkA+MyWEIKcva53DQewCvwoflemxbl2tC1APVBX+miAW8AC
4zP+mHkZEt57mG/mYPQ2HEJlpXucqpDJ95HLUZLrniHV+666G7tOcK4EZ18qubqGZRM7/gPDmLmG
ZGvPtUeFoBZqQK1Y+WpXg6P0i67hYpRXW19rwbhtI9WT0tJaqBhCJGGNUE6zqaDeqWBoiFWFkTXT
g0NJQky/sw5ejOoCZRIrE/bwcL8myZGqKEEQEYzdaO0s3dfb0uftizi3S6XpriREybwEuboenQtm
ToCgeRUtzA5icSZ/rWVoRe8SGWTvBN2z9KC7l6m4eH2dS0sUBRUs9/jtsLT2VPhqJ9A4K9hfmf6T
Wt+xQ//gfSgN/2UVwDqPJMYlv/rUNlshVgss2A/S5Po/D7JtKmou2BsUN+vvaplzmOwU0hk2o6po
GlHhPRGrI6b1iFgKObo8WnhjvL8Bg5xAyDQBaHQvV114H94RhsJrIW/RYbRU07M5wNMcAYVWxf2S
gRKKrqamlDJDYn16QPhKyXJ5dunWQaZbp84ldX/UdIqKP5hX5mKFsM3QsVAy38rvsw6ujqHbWXku
rqpk/h0gC9zpQZGbi9hOOqLBsN7yjVLhjFeO9tnXzVk+6lTopz7OXW5SZlyUogSnEM6VS4j9Rq0C
OKT0EYBQzyMvFTsJIbqrPXYA3QDD/ymfnw7t1w5ty2BgVaV9OKTfDyQJXmg1y8lRCXvEm4dO9mUg
L8S2nzKCN7afNDMPXtRhfj2HWXR9DN1AxSCxXrciom9irohvcPyBvoca+O7pXv27c6mIAEQladLz
pS09T4g6YQo0xGqj5nO7aTxDi7gOYnNIGlmF9JxvOeCatSo15vmBiT5/6y0XVvQubWL9PA1rKSQH
rL0ZFY02exraD06+9nVTtnPOKqfCvNjWlR2LiKQIRnmFQtdQKjR8Jago1HMqP9gP4uAHUvOZBU66
lhGP+FW4efYyWPiCM+nTyHP6UL9bjq4r6EohdihHHs54O2FrIHRFZvm5/U3E5dfPZWp/eyVhJlrH
75+sA0hcbeI7oe057YGFp3YzQ5vnFv1Nw1TsUZ8nGfupwSGN27cSSCSuD8WqjdaNcTAcNl/4jxhi
mVJcK2PKMn/tJyxJz+WK8xgJUnlmVnJXjh5TGxO+wKm2qUFL7tNCEi7G9k8vxl7EchIWMgmksT+Q
ximZ1WyCTKD+Jb6mYsnjXCr/iEJp3vU2qmcvAtq9+pru/ftw9Tj5b9EI3UMS/e63w/UlUL0Gn3SE
o6RigNdTAkP01Zj+wygRv4/9UYVV6SA4KbzpW5mYJcrwoWPKIyaAkcEo9qzl80GMx7dNb8vwbAPu
irs7OgAmnaZ0phJOWuwObDHzXH37Uh7o+pRyeKQ7KqUgRGFaux5yswx8QXK3IeazqB/4M0V1DBrK
kkM8+fAwCo3ROSRR1i32vKYlx/UUGGltHBRKFPFXvyqEDDUCbGkZ3f52eM+RlKHV2EiXj06Zem0g
6rh6XaG0aDcD+ESb/1pzLQCRm7JlCRgokinNY3qv802GQqE0KwpLfOvwX2EQ4mrjex2b2SLUc/ke
b3grMwIYQKQ/zR/D5zjwe8fUkmtThG4XPkfXdWwW4d05fG==