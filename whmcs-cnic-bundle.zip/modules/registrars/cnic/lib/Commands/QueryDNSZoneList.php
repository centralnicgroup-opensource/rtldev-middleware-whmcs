<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt5foguC+Sw1oQLVZVFlAxtIP5+8nVsbKfMufl04QUJLL2oHGIsdFkoGG3jRnXN8giXWJA5M
hF5v1QFB5YYoxQOKTW1YIvE0wgyEgdAvdXHuJ/FSdjkXcl/asXkh9j9TO9lkjp8RnIMV4oXCXcJ2
EnrFOgFIvLchKtlUpFNaKHSvW4nW4k/CObtwS6CH9Sg3375ioHf36S9Ot17dJEafTPYCJ2qms4Se
sIuUuztrROJ7X1j2ogtG2vvqjioU7Qd20219KFHTFJwo43LofB0Qo/2MmyHgoMsb9Ri4ih8lw8CT
BiT6/qwme/FAMVoray1aVx1ioqYJypCUmXam+QZ//79HiW+dIcd2FnJ5WrIsmdfXW7M4K1cIKhCk
gGsRrVhskXrgcTUIPiJb68djt2DKdy06rq62AsaxS4eSSGN/TxfpNhrZwRSRO9kVYmJdBpUmX00I
5jpuk+CQYZTN7Lx6rCn5/MjFfpuvwt+DU5IshDmAzE7EvC6O5NXjbqwk2uZAHaw7jxqlXVeMkRbW
vvhT9Iuxcfyunqq1eZVDde0eUP2d4ordQOW2DAFpPbvRAe4CAWNSfdCIx6GTc5VVe4dopX6VPWFw
+DAnCwzLLAYDKl248kroXC2TX1wj3pww5aOE0etbKopA9rbpRT8cQZ7m5oWAFQRpG3H2HGqcK7Sl
8A6vtOEQtkRsPtTaJ8yLYl3te1A3uo5eC/HP/aYXMGmHnJ0cL8uZppDeYna5VkaULbGuJalKsMDk
yx4ETMx+g2bEXIHrWqz9Z8gyneUVbGxF62740d2x+V/JxmWjhTkXSYOx/1KPjwI+vrufwVCFA0sZ
UOxZShZirVFic4hue0sb7B2Kr30ndrM8gP73xlgaDQjjX4ObYzdlYGzC5AGUQJOn9chGesh8VZJV
KToeCecjiOp2G3HjNpzZiRYhU59ZXD1vjCKA9Uqn3OtnsnqCLd7/evTMbtCxeaG75EYEM9rIE4Qr
Y60Yjum9Ux/SxDH+QjZjSnTnivOS7nKlc0J8z5rOBN4uxxtLE3lq9bIj3rxBjPyxjqOZSbGTB2DB
m98R0TkxQXa9N1gjGsH5bGuEp1Co9pcpTrntVlIKBoj5ohaV5yRq7iYzqyu+QfBwN54NCh8G0V1D
reICYtsdk9Lm1kOLuL8JSrhJVaKvEgyfhck+6lw/QZFVh/PcjzvKU4QXVI6C2njUgZDUfWgVG/Lm
AHdKdqBCazQ4I1Zp/jVe4L2ym3aln/hqv31D0viK5ZytWkAt9ze6fFmp99U3H2JDwcc1tgbM+WZ2
8r/9fAO3HYbq5Hj4WRpDP1PqHNSGh2jhKLhRcEsEiz91WMRQVgH4/t9TOmi7KypLFnB/RtDseQRP
DMqh4ey3pBDyG5LuV+TpSw3lBtH0UARBThJvGYlTnZNN+2RXOviOZhAAGepnaujX/S6milu2YrJ1
QT1Vvcb121V1y++LQzkQtmHLmKceCgScrmML8tT70IJdTGKWNvsIxEF6YBqm4N6iy15Nvyo8ZX2X
bRQ63zYToztAsx3Atf6ynKedpD61IXxM/Zf4fkWjr7gh0h1FIWwZgiG/a+VHNwYHfQVo8AyZmjag
/vuU3S3qJfH8c1wmq0nf6sTJ5ZTJoA6REUVpGmHY+uvqv5AGtt4e+PuLVIhsnAdIc0Ko1HajALbl
/ws2HPqaqetita8VuH6QrlJApm0Q02A58+BkWD3crUjCoYpRZv98s1faJu8YP2y42i7PID4/9vVT
B//Tw16gvPxvE7Vn9i965GzjfUJa4j0URs5ehqjoyrJsaV39Y8GOHXbOkkRAKgfEfr9GxsieHtTD
hqDYR5B9ZLN4XiWGF+yfP7buGY/iAuAJpPyoxnomoRiInbnlRWKKM3jkfMmmpN3mJ/h2HuW4xknZ
kLEHY//qLtmS3xurf7+89SvP/9343rLOe2oLznaUsU1Xx73CnQHyevlSt+T5mZjgfdEqdmh7w9ec
taNy7UwTPQPr3oFw7LLUNO0DeXv912CB4t+6PQqTPJA9r4NUYrZJ5Q89+WedJhTVbXKb0BjP7X3y
2Pvo0nKvaXiYJLgYmzZntJNS/iNYshcggZy4Brx4W3s4TFMdr1eSBv4bLfn4/eh1SL2JGasP7z3C
fgDJZLE4QSzqrU8TZwpN66Sr7FMmqXawiavDwrk92OCvukP8bRfQ/oZn3JVSt9iROjOL9ytW7FUT
hRVQxAFatsiK/D3blE54qkmZIaaFzxuN9ENqQBU6PILnDVm2Wb3h+4e7GnEs9wNBSXSNL6uKN6FC
uRs/vAF7b4uDpIhsW2rNGpSu2Cc405ok/WJF/hZ0BQjlBgJrFT7ZYAk/kVQ4P3i7uQO0as3SXMbD
UVcKxS42WvZ8KVZcw0/mtGFNsrzQlom5wIbi0HsCebwTiJd3pKBXa0JrlthOWeGjlvwOYz++ks97
3FiImluAkr06aowbzX0sHMcXWQTmlpQl7QP3L4kuBOLz/1vv+18ZE4SFEHe+vyUCNkSCBWYY+ESX
NaysXPCanBN3/UZDg0io2aMf9hiN6avVWUr9PBniGUJjWGGARFpPEsHjCF/DU7vUgpGOeW6Jb5Qh
+7UCZmQ74pETER8CUI3/juhACgdfKcA/