<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu43H2CgmxmKCy/H0BSuFtFsa5yjjG5oNwAu4knc1LJ5UBu3nFKFVMbcBC41/lq9yWKcZTKq
+jQjuCzkg6wVSHZdNmUPDz+3YqetzQDC1PLmHiSdGwyzZmUCZzPSbShRfcFFSfAKyNdLCrQeJMTx
Jo6wsmF8UyhUtMXoK2OXcaAQKZ0mnWY7DFVpWSNfrRdeFxqVEQNOjzXw+AlPrekXcBaZCqwvXzuf
UDPZBV5loWwiiykWiHgphIjRbs/+P+0w7o1RmbNL3Aaz1Aeez3//eS++rYDhxODnTqfkG8iL5n3e
hcTNz1yzVcw/kYzPfvBpHaaeQY1+ym25eUiDZtttYeTmbBxbmgUxIiWdiLSmNFKjx3wKwEx1hBeU
9l+pzkk4Fw2uPvzVsqqSuaSG8exBdKKRr1SRvKePyI2WNsqBZkFB5muZGAFiJltCnY6fDLw807EI
2q1agxsRqfkZXJSM9tK6rsj7T2+cwLWEkk1iDjUSlN8m08sKbpiVU3+J4Yj/t7vWOXGC9KLMLM/f
gU3vGNE7hwglOEgONPM1G/9wI0bDVHmo3k1q/B0tANfPRzf14WVnuOxYvx4N8X7Kc8/KuihRTWwk
e6i73Fkws1INL0zWExMu8XsBYzANvtGACdR9dZVyIfRf15yQ79oLyW+2HWOmHk98xciFlBRBK2hN
hqm1oYoVRm/aWWudEgYWjvmliaNtsNc7GZJSI601X0y1K3Q4qXQzcmliBsKhhPaNxM4M5r0WApQ4
fHNMhLNlzuCvkGMWe4Tcmeqiy3OQ3pxyIBDlJpzGqob5P2krmmSdO14Nn/Ud0vouWbNwd6WZwPfd
bh4Gwylk6BogkvSpAlCG8A06BKdmTOpjdyQVB2ewZaTPgYsIXxvNv1AT9d6JfxLPznlhGvFzHO1F
pyT9gJCVutxNJ4oLu7hWgkJ01jhzeoyucjqmjp2TlC51/DOoHyNy5jgbkuJk1n5UazZTCjQ7CUAl
4v2PZw54sD0ALmEUwZENBnJx3L+01sOYJ+Uxt3lMz0Q0SA6bRF1JnAHagymrf2+eBDB6U36PBDwD
5m32YikPdJ5Q0lJ2vLn6lvaMj1gkUdoxMK43vBA985sbvHSabYoKIn0ZNpgcD3VSzOBO9PpELAl+
XEDWDPErA0fVEGmLsb0pi5HVdbTpk6ntqChkIwQP9+JEfpjEO8x9Ks90ZWGd5ZzbJuCVeDIDmHdN
OyZy41mzNicfdWgNn6VlfDHijPxKmfHE5a9CXpj8fE3ytIhXjISITJ+nmWxqVMhz6qm1Uqq12yfH
GCpWl4Tw4nEg2hZwTLgBo/kPOgmGYvqzlCMa+oSqt+SYLNTjPxTAjqux5szI1prrzqs8//WmRNbO
2JaJAIkBb++Fczi9vn5YMVhsu6sIWGzl86dpP1lQEXed+ZIoXhmh3P2jTR4KUKUTNkb4mHRm52rC
biB58uZ+BADd0kYOVjc+YaAshIfwTzFxio7yxlwPM0c/7V4142wY01a370sIUOosRQwn58JVXHVY
cDY6jbaxfWjYFNSUotWm9QHw91xjG4NjwkYOPOXmuZ0RTGZok1BDaURpfaV6S/aMoPSvc3ygwF5b
gpTyLw/2P5djbtCsag5pkaOGbW0rQvLyJyUaqrL4mCtd3I3UEY57o8MKqEeu6B+3Aj2K9rClMSq4
lBKR6bRP3VfDXaW3+0op6ae6xITFsYDKYjC2f8yjogQFC8VBo8voa1kfNssY7nmuENC/BP1vMhj/
3ATH+OioK2cCxSVBmFSAk17rzUkxbu1C+pPX3zKrSCYHVRAmOCPKSLlkQ09e/2P56sEUUx+ENsUV
fRaJbEt0secAQVkjdxaq/Nbuk+LBl+Z0qGl5RSA52TRfb12XnTNacIFV6cd7xqvvf1Qs8C8fOyQZ
08JliuZCP9iY/oP28TPXL8GDE0VsWY1CBnkPxAFKOnMMAPxFhM2BnRadB5GadgVpkVmChziCdogT
X1FvBMImkQ4RFKmDG4qpZ0jO7FFjmbJgNfJSQGLOh7n85vs+ul1iArd6ShnHkNkOYMO6ztjOOX6D
7WenMDE3ktw/AFEBdYeQwEnbIDOOYcxgUldFlxFUVvhh5fTh6NsclBBxn3qkrT+G/aJRGmLPKSV1
P5FqwAScbOwucDs2AZG1kOWkFlrNKjCCUhzVmKlKmIncpvq4k/DIM8mafA0edb86sJbFo7elRrRE
ItYEJXCVP5WSIPrMPGrSWCgiIfYGk2MRTO+pb4S0X4/z7InNKabzL/z5qbcdNnkwPcouoqMgSivJ
aIZomJPxD4ztVCAZ0qmO0AWoWC+kEYaMcua5eB8MIyc0fxkpg454iRvA0dkEqCEzuct4WtmguTM+
ARFtgPKNcY0AgjvfIdE0KNhjlHMQD2aB2a0gj9XFP2z+iKiTJsA4dzZtJo0zudBxJZGvQu7UqSRD
NwxiGuIncbXyBalc6aUHgbubZRgDBqZx89ywSdVD6CHrXg6hN69bBwCDHz6th8YjqR2K57lBucjY
GxATfZDCJjTSDKibjfLsg89AR+5UAkhCemalrWbldBIFq8mMqBqn+6BSxFoT1Cxh+ZSFfgckz8JT
4S78OocZcYW2HVqH62nifeyekANYJFG4ag8NJ72j