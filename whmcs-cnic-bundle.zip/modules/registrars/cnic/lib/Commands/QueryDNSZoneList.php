<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr4kpkVil3B8wU9Rn04YEC5pYH6nNAT16S21yEhBEQTpKzCb6Pb82EMDEyt3QrCrBD36TyFa
jL2cjceHLQLoAoZ1136K+PR3ba9bX2RfrQ+VHOlV7KnZRJgZ8PEkRO8RHLAmYk5HcQNu+5e3oQ5Z
fVluq+234om91y41ph041FiToRb+a4UDtqAvVENer6BKkuhgxQYLbMpcvC10d3QKgZfGin9tncNd
Gu8PrmafglvEm5sK7MUtWJLpBdzyGqiJbc3sCH5OmHc7YsTKV51AV9cOMRTgQWVKmnlQ2YeeimHx
hGTd2k+a3LTzxt8TCqDvfwjZYUWtue/iEqwrTWGPyG29HRXd+VYLhnW2e9Fxm2053pqXJv7ujFjC
C04myT7tfh/7D2G/1YVdht4qtYUPEJwxpYr4yqGxqbywMc99kwwuFZNYODmHaw+aiwZECmUUuzk/
lQIX5KxD76W5PNu0NeexBoIv/SM3dghD5suEuzugHDkwIR7VjMEB+ODeIuWZQUDWzTrPa6cpGn2J
mzAfwTd8IcoJVeLPTGMEvD3Eo3uirDpwHD0AzlWK9jP3cteZz0gbvB5+H4luQ3qNpTzogdmOTqXK
Ihlz/By4up9PbBEOGkotY8gsMGzKAwQgYXEtqJBWuORBOJyZyjSfpL6Ap4WaiOriCDa7c7xWR44X
PO9OwIis2oYnR1ZGxOqHwUlsXxaqJuipwKXyIUvgI4lcgA58nyD7/kb9ygRPQfcosw6sKT9ELEWl
6R5KT8U4iGjiS3cCYIYTGe5zAGtqq6acrH4BonDBvLMcY1aiE1rXTeVVPOf97LMr7FvS3Y2hC4Q7
8HfcUIOXa2BiUpq9voGC6G6f/92XId4ukMjufNo5cPU0RPVD53Hc+hw8tLY2Uu4ZvRnyFsiS97ux
xQMiMuiGcWrKBDEBss8awESPj7o6kogDLAuzdd3gqlt5saajI6pMGeQAU4JjTLNWSoOuWzz239sV
jgVqGxpjHfrl2nZ/EbSpZkFImX8joROYtSyXCp6HcCMOZ+NgjmRtJJ2o6xf7ByF8X00VyEfnMxRy
m4m/Von1e6yDhlAeHtgNBCocy+YDVVIZhyOX019ro+BAIk9Li9KTr3QO1/wu4k9uynbQ9FdkZX8m
2bFGu5nQ4OLUbo9viAMDY3f6y5vZ9dMGo8OAMMrcfKcdgAuOn5vN84iF9/ccCY0aYqzByCWVVF9V
c0sgBbTznECus37tkEu2G360kxUtUDdsQ91p/GYKdIiobH+NX3uO0sITQpYTuR5/bph5jKcbBr+a
v44HO2SBzDeXP4B7rC+DSDm/WtjiOLfEk1j8yVF8Cuyt6MSbAWhGFNa5m4zm48BY1fvVTXAaOK1M
VlCdrOovRBidmRCbC8xJ6cnAvBg0+XP9fP2gnxYL7UaoSF3ypeQJUaTT9xGExRoj/Pf4L3ZTE4Oj
cKupYQq5WB6LZfihhj1smCvqhPBR0eRVdtr/VpFuop4ApCR+tFXr6m3uxXF3Cj93dKDcXTHyLFca
Br6uXtE3uGSu4o1WmX1wxXoiywbHMh2n8zajzUMjcUvKovxcoWxBWOjQin/i0Cq/fTpmAk/ozXsZ
rvT2s1L0GIiTrTf4VyVyunO9PmdG8ZwTKOyTapsX/zg4azYWp+oiGHjmje40Cg5JPvq1UgmabUmx
KdZNc6JmJ2ZxnpD6dX5UV5HV5g/itHZ09Gkqnsf9rMbHCTwWABDr2jQ9N3XbdBktI8qforvukQC8
lEi7iKLtlSmwB4BO2VPCqW95ZnfhzM8LYG9k6XtD0V4JOCfwiCuUYz4pNXSFT744QOj3dx1m7pth
oi3IKSrO1doOLjl0dG6MiaedoEoQEig+rlUU0bY2t7/WHdrnpxuOqiKglstRYvqDtxYTvACvldSo
KO4TDYoJ5GorJiBxRn4p8j4QmUp/Rxv1Y1ot4E8VWWzwjwgHtu3UjKS5k/mDH45N/zTFvvMoYJQc
nklVwu4RLKy3vBPcf7EOogrhiaJDoPkFGE4L789iswoy3mxX1Pyc+SnbjmPm7Jl/GWy0sB3GjEVa
TKm9qi7gwiKS5CZUFiK3C5Ies+U86o87R0oFQ9ccjPJXSAmMYhhyxDoFTxxBYb6edUOQgc5qBGno
vQgkOLE4Srkw5JhOayV2DbL+AGdM9cEwVG5ssGHR47GByPY8yhnbAW/j7OWwBZwziFJWnR1/69bS
SJufFMXWpfjeMKK3PMoBtMLbdGOOP+h/hexpTMPyzpddkCENnGzbUku/qewQLsGQCGckii/VdnDr
1lDMMyTUf3ZRlM2+tpJxflY7YGURRVF366IOBJ4zs8XvkaMW/1CzV5Wqp+8vYOrN0+VOETo49UD9
6Ma8IOY7wEnf7fX4OEP0fgJDTITCRkQqJ+aA9+lQ3Dmu5nH9jKqkm7waCWBy1CqhK5+1ZF44lCxH
1gQLw7f/ggfT7qTlc5fPKdT92iCiFLlKYlnlca4I8HCaCeC3Rmj0v53s9n3BGg562Z2du/DM6yJK
9KkVfcEx/0gIZ7wOC9UPIYnArvzKIp16jSMRjKJmWpSeDF+ud3ZE0rmsD7+4yXRHbQPC+3cZp6pN
1fCraL6a+UG3EJkMSycb/fmz1h4+LFmB