<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoOxsR5k6YA6TuXCacmDIzyQqhp7+11HTw6uEkYslNMLjtRWTpWg6NB66g3Zi8LXOy9zMSAh
fOzOSacOsGhrD5s1K0kbTDY3eTTfYxiRviXcmq3HeGhRsL0AuvIBzinMSNGCHOGBNeQ7uInrBnQm
mckmbFY/KnlZ60lPS0TEvhwZvhgm1iDzNwK6a+qV5XEacd/SzdHIstYh7amYI7gOpkLWPl29Lk6n
xpJ5IwpbYYJmrjd0BRkqLjqwwVpOkYs3SWjGQM4BibGvDFIXHeienCM7UXjieEy3mHH/gcur4OvN
ywU0XIV+xQLAgdRvI14zC21bEcm1b8GCNMa7IZvM8QlHmh83r9v2beP0/+Hhru6/CEk+L0B4hCid
D82yUnOJKvBdKOPkc8le+aWCZ84omqgFkF9QkYwnY5w6hzNwGS+FQyaus9WWquFaSoNelKzHY/6f
9SRXf3Jx3pxB7n/7JeSTAILwC9L39K9gKFAHSaIoZ9jWreytaRwaPEEMS7i3HZ08yOzEAflBBm+i
Q2r8ImCKHk4g9KwG4LbtVV0tde8sJA88AttjdY8zZM/us9POYYYP9SH9skwhrvg+WRzP3Wtl/a9o
FuwcP1le91LVuMOxp4+0JZ/3RZOWtcS18hhpY+uETDOzYz61KmjuvjKwBI91IyoPchQJrNh3esAS
gliVftXUf2ianbjUgRAwsVcwhKI0ScwJ7fs35TRPJ7dQlWcGeKBF+rk2ex2UcKrQP9HQgtBq1wbN
pu7j6O2Epeo5wjGpjTzwaTn5VnBmkYQSPRthNd2MHAsXZglc797t3ZUGtcN8TbWb50EtAPxTM0u0
lFMTHcb5QotK9IAPdbwK5+n/doagwD33/8cGNYP3TmDwBTzTKc90kZ+TRbCY8M8DWIwkMiwU7l7d
A79GkjJjIB7vjHOi5Z7TIuRCYGqxBRQhCMzx6FkuUOnpmJtrntLvX3/E1yxbAnGd6c74DVhpkA/4
CqO7RfXGg7fBR1kQaLOsXALA61V24sgvZeFxRhsGx9bTnexDglzJxAfS2c//ACtHfw88kCb1pzYX
9Mof8Rt1pCxc/rfzJHPVbuUQkDBiuIm+Y53D3ggvBgp79dq0vfsPhEIEpNVxMq1/8WGUjF1qQzDx
IaNLCvCv5SW0TGVGuXH4LfVG28wcBANZZ5MqNFREe55s5JqZdJDwIhO6YIyzE5bgmo18rPkv1sIQ
TvSUqHq4cawBjglHhUTDxh71NnmWUymufJEUvR4nWgQGrZEEm8bILtAyXlP2eToLkfqrrwvVVlRb
ZY2dSwiGsB1tLkYX0I0mnXyj5Od3r/YZX9ksZtbsN7BwMaYoGiZGj/NkUaaIVFjxJUYyqFrprsbw
VlGUo5egwU3npCfnVhP8Sz/nNjncQb1E6p2tSzt77tOoVFiBvrlDJioDReZX+6RmnRUbwQGkQODO
k5H8caiAjLAkgZcXXUxZNirzJW2p1KDTrOdBCkWELGF6tMOhVpLBfBV1rWein1VnVk48gfJwuhbC
p8EV7jChLGeBASn1IwzBQxo6bvkrMdQu4/mDyp3L8y+xXSNpyWHJdlR45lGidicCeHew+O6A11do
c44nt8R/4XttbPwvirNsldDKW3bexW5/86LdpeFeqj0CcVJx29ubOLfTyRqClLNnfqWmRhTQGgst
FerhAKR383ek8dygsbssgrq4I9BUsbCa3VQElalP8aqbFxe/y/o/sxbYdObVrNKkZiPtiqV7nbzp
qbPrWkt566E31rAQDh7k7F/5PHZF0mDKIqg8x3/t16gPtOJO9qa6x5jlm53er/yXDqsOxNNtGLUZ
gGtP+OmVYK4Ww3em6g30xSH6aD6if8YUW+eeSh9KB82VRy5cn52j0OQV4bgpaGGxtuLsUYs5XuGK
R80j4vfhxBWBoMGjZLgP0m4oPKjYTosxl4x8THj6cRjLRpc9uUdQc2qDLgaSKm3UkhwXZMcJkuZE
YMIcdESN49dE/Nd19y7T0+Jp+PiK4yNWmrCTXAhpSFk/UeXhYtgfqEV6Jzh/eubc28vR2dtERYTU
RxvazRORFlSO3hmUoM+lJW8BvJ7WcHCUJ8hjBYPoJjOvwtuslLP7KmAIQVh9ogWDztwTHu+iccGG
8YIko+7apM7E7jLdfjgUli9FFVHQHkdj9Fy9Xb3JXXUhLPogbdJxNDnjdpq1cwqc6xHNzLhuDKf0
bhGcSRDtaWxLTmTa6fbmYC0NyugKb+9yIUZVDTOJzZr9gNY+uv/Fvj3xc0tY5Wc7pSwprdEEJOy1
dsxox/0K31vHpdI68X6SWPqXhGvDShL+RF1u/lK4WfIZ4Fh+VG==