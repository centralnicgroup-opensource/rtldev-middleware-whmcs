<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoSQv7TWvTnuVQbnL5BVx6ZyFvXm3ZNuGe6uJ5z/5edlIHoCLuqSN4trcQmbDbcKsvF4wAen
MHTxdr2ICw+unbtQxQn2IWliU2rUnF3vHsbBrvDM8S3fJ9wnokhGIGFGlVlnyNHO7+y+Cb3t5/7n
95dmNqnumaejvut7IvnqAP4u4cfQ+KijWP03ALgyQbhiXvK6xoBWtaH8ph4DyPnPqKnQ16WD918Q
AdMn33/0S/YguzKiCF8RGQDH1q0rD7iJDfGWKFHTFJwo43LofB0Qo/2Mm+fb2OkPhf8f9BxxAeFT
f0Sd/p0axI/iRBzXK9dCUShGhlV0HvJYbSCDgCq2+joI8MCurYjjh8bIKX11YY5CMcHShjXB14Wz
C/I+H/QT20ibEQ9Nmo0U7Dw4a4Du4kJJ5VFA+Enk8cTkd9PzafRhzCii4SR0ipu2idUiQhQfph2L
ylDXOUEE6AlhHYEByQwulS7BiBNQ5KPv+0zTAvplE5duMcEPTRR2wZKM7o2vRP6jqkYvvdvEUVnp
siQCQeCVobBwro4uBNn8spSMqoOdWJ30j9885U0ux2VeMOb0+EyVjRB8LtJJH9PLUWzGZ4wb/RLf
N2X3HKvR6h4KvoWkR3lD0R3vYx64KtGkcY1qkNWkLZQnXpDWfIZFYFPkT6E1FYTig9Ef8WzeDhg8
+enWOYQ//+dUEg80YDB2KOePXad9ZfvdRJ+OPqAba120mtoJNMppHWCw6mXebPyT2d+/4R3zjpgu
liDrqXs8j2lXapY8hJy41s9L8jnF5QdUnDvWcUzwQodNfCLjZm5JY1SipZy80393yGzBeC8lUJeX
Ss6wLNN8+Y99mH+P65wG0fxebJVeO9J8XvvnIUPT8PaRCP0LwNrQblqTJOwTHRhfz5ZUNmfNKu7Y
WudTy7y6Mqf5pCg+rRlBuj1MlO0u5M49WKofR8ZvnnBXvSA+OX5axMExw7rTqEunI7oelgMObhfi
gTjStxfyT//Yib8tbthF8whAaYXEDsZ6vPCMvtn8RSqbZ1TULHAl0ufSoyf9NFolyCAphIkQDat8
ZHXE8uTNgc8CHQeVgCwwwYgakD12y9xskOV0kBKIUtMFliUO+IQj92RG6641hnHxCP7oxsREZW3T
FTWOs4+B2D1GqJX+Ty2MB4wjtECOXODQ84/P99QKzHcd4DeUc/GTc9sXEWLYaXpSeK/qBDpI2bdQ
0ljMt9HL/hrFt9COWjgPlo1KdG1Oyapo1IoCjTvLOvyBL073z7gprwH8V75aB2HhUdBdBgjweM+C
eGlsC2YwlGZrpfGihlwyo16PK1eMWCdri/SACh7xPQ16LzvC/sWMxADHHh7ato2chmz068IXTOct
olJTdpvpBmOlnNX/AFmXqlIYoxWWHNdofJFkzJ1LX1xnwjhtpTehBXEzh7sllj8FIU6etv8+GIft
BmTpONJfvKExjgrWOgbJZ7iqxofxAlCEUgqLCs6laQlUsglmqmBom3Qhy6654wNynvRFchiu1a90
49uRiagmdKQPDgBWQ5ZUdyhfIqB4M1ckCeItEQdBMHIuUN8WMWcg/KJEwQyZMo8lV41QihcqKrsa
IeqBkWeWlic7lNAcwX71gQ2gk7zn8Vcxa2lb6x25PxKQsPUsvBPHGZNJTMHphjoJkbqwOosu/9s3
lnEzHaFied8Sl8xxM0GmtgwgZQ5cyROcMh/mz+6QsgRonjuY5P8H3k9ZCUNFvQ9NT5Ulh1esmEb8
InXL2eFPP0eVasJ6uew9gfwLcR/AC1kJddDv5pazSGOmnJRSsNnTBJgCeChuR7qlZETjLvRigFSh
tKhhY03fsnsS1GFaguE+1nfAEJDq13tZceMZm9wA8PS+4UDml6iDHlcb8uFooNA1ZUOxQDlJt2Nt
TF0c/6/YFKk6NXGl0rUwFG2yOL2VB9ww6YWX8k08wbM5SuNqQsyK1geayzCk1vHgX7ziUjZ6doV2
U+uXaKxE7Yckq1JtLZG+a7t3ooGtvF+qryK/OO8gfR9CccPNKYn75cRmuwtXuPQb6YfiA7yX2d4e
V2k595RqHsX0Z0mZLRfNaV7FHfpKSJVwulMCDhM0PKYJd1SaZlJLTYU2tZLFO7TSneQNN/+Hag/y
K8WWs3ATZbuNjohrmXNyQJ04QezjssiIJ1LiPWwMisLcEt2GWiM4a9G1dCYrurKgsiB5+SeZJdiD
f0x5IhI/AYIcqsUVhynbq76nGD6M9gikH4qwZyw57WQhEosLoW8c1rPtGw2L1ZeRDOE09xGqg0Qw
8Tt8nE6jWKcIimF07wZq8SDh38/slYFkJ+0=