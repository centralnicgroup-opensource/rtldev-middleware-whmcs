<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw6lKblWTgUS/Hp7U3IXVCvjxxfdyByKgAIusZOQkZE6ZcklmaVajuI0+ZqIvEJIw6w9ViOB
sy4IVL0qls2vGCH+acmGwll4SKMQHFe7a7pGTod9PiCWGroFyo9odA/hx3ISUK0Ev2AhMhV+lKOL
QSsytYTSRXPEKsdFoY9EFnRHl2YOyki9hY1K8gWKwnVyqONK6NbybYt6l1ZVowj4zv1GFfIjvjzO
EWeKbkTHeRKsUx0Rm3IZpDD1TIA3DSNbW5Uw38PGOQjJKu8SAFAUjXXANV9huZv4m7LAWF/05XWt
YsSG/qhXDkmNwb2LdZu1ml5xzoRjIZgN8YOJ12qNhdN11VvTfmcrWeIJJZKpeG9qcEPXJqWBS2gt
t9FNaLUZZmI7LaCppg36OEyGvrerfjUEhVY3ksEHJlUwGJWXQJyAyqp0XYwhuQ2OWk/7XS3nxuNe
78aRpDj4L4MxZRXSwqrW/iz7AOI8+EdwOV/bmDg2evJPeBORGOi1qTw1ESoq9eSYz4FAEkpbxMgg
C8gm/iBUaALaFqCcIt+FtLvT34kTV20oyRrkuK/v0FhLs9TlFcWANohqaKCdMap94End0u+aliqp
D6SRHwpxm5mnE/9/XYJpKEwXFx7o1EoPY7IASEN4p7p/HMV4nJaGhtH7SDi6wG2ngq0RyB+rukOd
bc/xJeUqjITsta7xyxWWKZPwP6c9LTVtkMU/3Vc4kSTyB75abvTuj27NrLBQDkLbwR51xChQ7Zva
/9jRgznxLcv8nCqtFwvz/UsZPNpCqpfXRP1xVJcLx5C3XjqqsF/+sGogGOB9S6uDj8dbSN/X7mro
4dlCrTORSc6eKCdNg/8wD2/wffXNBZsDR2cHB8qhc/e/OmzCvfUWoGLPY4Vj7rRvNpGv+HNzPEG+
MIFcixuIYGqQ2gMLSB3QQb9Kq2gFojtGSCRCmtr/UzTmkwvHdUyp2iW2a+FyUqMREqJ9gW9p51Ss
5ctkNMWV6eYV/oCu5PReS4EKChZ3eHxn4dV47VI/l2v/N08G3hy+CiYheEBtHctm1NP+bu6XxiMO
E9MWstwWNY0WA1AzQqZwfnqjO49UrJM0hMzmJ807X0FZ/giILSkxd0sYfaJ9w3vK91gaqvte6POF
TezGdVo/8JdKaMfgs/546nqlbI+OL9+NwAvt/2nFf1tJbbieqxG3KglXCOaKk39hzFdd11jRXJKC
jgISqhzybYbFUUDSvwK2Nx5yoMRM+Evz2IO6Tw5i63ei5WtiZIPO+qUxn24Bd+ya3OyQ6YjhGuXz
3Yaaf8Bn8fE7zCyEZRHfK8gMX5zfdfwQ2ePlzDI6K2k0QdL+YUZJK+vAkYq/8N2qDfJWEzyKp3PC
In3mfedK4zM8JNDZ8E9HCaEAsv41Sk+22xN3udlITq6sIlsd/5UnCP7bBdiV5iJLKy+SQbgqpw6t
NFfd1kw25BIlQLjj89SowFx9rARTfaVZr5GHCzXZR0R6mrwwDhMTNjmgsjsGvVEiMIcwNxs2zt+r
USm1dhXrTHQbxiiQjZvYp3+EXavFPMRuYwUpKZF86j1TSq7A+LXmn/Dszkj029TEe3QQsacsEFU2
bMN3rWDgKicMRcw0jJe36l2idME1oGw4Ori5YXBr+oHaeLE6owSPPzIYPnMn8P7D/GMxU9b9zFs/
HlkCo5JjPBVLtm3SFg+J57o9V0/gb48/hF7jZKzr1LdBfcbZxJt0bQRACN8t1+wpKzm9gxdzQW1S
nSI2leBma9wMfNY+ntVB0GYXOIsTRftlUjf/oNLC2/Re2Ou3oktGEDGH4arA2BC/VSWntqc6ypJ8
KE0jjcaL1Of94UWiKpL0C+pBRRrXXknTQ38f4FzqQB2UKIMxX2z7dg32kv8iovWOn1VkO8taKDmC
UVMAfQvSSLodR4wgEWiY415tpGJfZAAOcXgmkqYsM2+YIROohUPYzvm3lgmqOYbhwxeGEVa3l7Bl
gMV9nO2JAoBXXytMQtZg28LrlPtr2BvbCHYY/aDOgXv5K4l0UH416NT6KYhtWGfRWHFcNmIHxHR8
A98bGuUal8ueln+TzXZ17qS0b4Q29Bx/+SbqAz+IjbsTgzTkYsda4zj2IZ3M8OwMjFnJdfAjRQom
ZrcmynJ14LxEbDCATI6Y3XjRxd3KzrB0G3GquyBa/XZwHmpzOrCz/DtIWvOP5+MHb4il7t6yzUc9
9k35TmH/U8M97oS7V0X382k2dIaCjhmzNzMCovceRGbKfvpyWhdFzKkiWrHQAW+Xn2GOWHDGUYlg
uvHcRnhwaLoho/bsaNYMp0gQWwQSz5LG