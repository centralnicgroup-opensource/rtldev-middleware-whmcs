<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwh66BZjAU6/w7MDcyqOJJ2R4MrfHi/s7SOCol+y91EXTjg10hJNXQjYV3d5/ShPJUscWKN2
j/b4mMja/gA1ZV6rsBD34QGOIYB+eFKEzPiQCRNO/u2dcuTD7ydjDEr51y7m2ixGB8SglMdHhIFg
rrZ3XSvGl0D7TlgsOVvhJIixHp/UbVK7GxBeAswXAWnLOYLFDvco+14v1uS6U1OH4vRnQhxuXQEu
rQR5Ct+E1SJU1vUj/ecXKSHcthDtCf6zB42S6ku+vZTL4SIu8of24mbqKokYQrVPKCJAyjcfe2Dy
RNi88JMlSZ1mfSIQn8ll3z8eGTzrumhaZXdbaeo25SEQOSoXcPhnd4TYFxD0cF79BmKrVPhwVmnr
p844NmDe1p+VKYF5dWlMf0ktSYO6g+ssUpEMTALQpzEj0LIUyAWrRVZkvHeKfK9CEwdJn1Wtgkp6
dYagLVy6OKgPqLoFX1fPP2xaLsXJ595/wVfupQCKc6XY7pBADloGYmm9TQff5QPOcNadDgvykl5f
yk1cftaixICGKx/lp8dBVi4B8tObyTzyh8D3hD70eT+cg4azrIZ+M/ShKLi/jHQmX6BSjqwmsL4D
EuHo5l+i6hK98P4rTiRMVqtSBswq3+EXDk6CxyYnu8KUerwKqKiY/qlcbs1u2UxkEPNWj/y6zzXb
vRgLlXvqKFaMHPT7tGcwKlNhgt7sYAVED9wL1WfgRmjP9LkRoHmNOjSgfcWw9RAqYIdp2u9LBxCD
5eAdxkMDhDky3oTyBCvqXFwsb6n0e0I38S6foG6uxhuQb1bsHswfgrGHYV8I5yvFYi0kTqn4i1Uv
E2ReHSC5mK8YIRHzcJbBAkyIfa/xp3ue11OGEYvcUGRuBy7au7S5PCEJvvANWr73SvVD5jVsXHMF
bdIqbE6WW6a7epTubJu3CpTK2NHIL7nIoW2c5iB5WdJ/siFcpFHU3mIKAJyR20O4TvYJX2oR6mwr
71O2Pmv6kk0RJYqAWecjsrgNh0+vtuqcILZYhplgl5U/XksXmjgoZP2Co7E+IGlrPKPvBB8mfC/T
39dYD8JTfdkzoe+K5OkwSR3AUIFacZk9DuOwXAzbIHq9teTNwCRJFRS/d49NkJVlFwefEay0i3Kk
YUSz1tjSIqBSLhsToJkJfe11IfGVYe/6pili65hbtJH4nfjc3BQMG8zMZAY9o8XVcPmpzoXIvlYj
OuIqArFXw/F0zbhok8P/odYA9UZdDupSSUKiJOzQGRUWe56MD9LtoJAT3VzVf+leXIeGjUIEngR5
pLcmiWAUIR1gCSO1Ez+oJ1Ns4IaUrNcMHahR1fK2WHeHgCirC6amK4k4UEdft2yLHNPNLotOEZ7m
YnillTw1tARXxNaQBfy9qJZ+9BFO+b7xM2puaKy8nrRDAd4ZvUK32OQxNqIuoQaVh6sEp6w2Hz6w
DDAvgOUm6EVzuRFKGLR8MggKGODaa4xzqcMumFoSo4n/7KsNrCPJxhc4d/Q2JG/goKq4bJP2XIT5
Y4uXL69yg7Xhy66F28kALe8KnDeObk1uOu2cUW7OUv+Kna4ulaMy+uDFznyrx7/7K/FEdfaxyQO+
/N3HiLHQkT4unWC06cYrKXMnu1utdCGVOf05iclvm543A1xV0hzQuCyYj7sV27W8AgUGxydKARA4
fkblL+GBspHlXQFIDDMmIT/3EgefAZHIJOMWXwd2xPrpjFQHLOapbpNJWaupl4cPTsq363z1W+3g
fmrl9erOFtFyLvckI+HNH8avWOCIdumV2Jj5wHm6Ah7Gph+q9mfZw7Iz65t0ac9GiTQciUVxEX8d
eLBj2vs4T72krx3R6k7yzA+dutx+jxoaq6FILEiDH8NZw2aU35+pQkxxknxZaWg/yYXKkhzvwLNe
kD6RtBhXcTe0kHvTWMqllapC3F/IEN97Rw/OzvkTbaYMno41ZpA/XQxAQc125yDrr4MzdcvUI5cY
l+PJSgISu90A9VWEwKLpMe6d3lJRi0cQbnvFVy0xpLAgX1sOfL4CrQwzelT0/6wSJvcLHn8HcLi3
pvoKcvehqVF3n+L74hkrlueq7q9k7i9aN1AQpHAqq+JP6QLtl7NEHq5XN8BF3nDlzgPrJl+4WLSu
Q+NihCfdXxbM//CsBcl2VGdy0gBUG+60VjPeV6XXjDLXhGHtqVHBU0ZG+FyIbaY/niZjIR8OOyM0
PDVGN6cgawqB+LuOpm7ZuxUqljLmqQxVNa4xNG4z8kSIHgOYMOm0INbxidshwfEtniSB+orZKARt
iqV7JXgEKhzXyzCcv12voPRxjy8z0/SrrkaDkKudwC5HTM3835y3GFBA2AqbiQa0zdm=