<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtK6GneZwRTTEhNMETTuNmJTlUuFLjjW6TGSpxsTlbQbGudoa7j3nG+MlfWuh0aOaEATRcJB
8QQRIv0JGI/klZLPHWRB0Iz/SZAwlw4Ia66/W+DJvw9ByzMvMqtHWaAmG2u4I0NliOTuWo+pt2Jz
kCTJQF6F75Obrf73IvlcceeFbFHCAbU5HD9lzYLJp/eTvsmQGm1tpkFUzA9ztV0dtX2KlCHW3zrB
tPPHZtW4aDLgCW3gOWTrBzB5tlNzOJjhqNR8AbZwRhmuno3jWo8BgGYcapA9QSiJXWWtxumGXmMA
aIOdPFzxd5zJQmCKpBnQ90uOuxZnc6AvemcRcgkfC21X3cwWMFR5y/wLJoiRb4V9etOZ5e5is8Ot
Hhm5V08bAJXiilR/P1z2zmZ1+hPZmR1hLYywof696X44ApAhnnSvCe3Wa1L1e4j7E8SBVCcFmLEA
2QlCPWIQvGFQSfIsV+W7IkbX4YjRx/rm3htft26+KMZ2r9jQr/mhuOAOO4s9jK1R93lhao5wmF7x
GaLNY1qinNJKj8JGzHfARATn5BE+3vkd0/WYt7zEmveQuqA+N9fhEa+/3xTYtH/AOu9OC4X/TTOj
gFWKQMW5mhNR9s15YzsRpFxUzF36cB49M4tIylIkaritxNSnqN3sdNoW4Ex7UqXyvV7OGWxpm55X
1/8AFcFlptEnlkbADFkVHzgkjhJoaG3tW2kRTYnGaAvkPqIEnO643tY6hny06oHyH2UUVyzOQ+WG
RKQMI3kMvK7e15n5Rlr4XcpYiPV2JnYMjA3k3Qht5EZ5Vfp3FdwIemK/B2j9hz5PmUFEoKt0Zo5i
Qn+8rlwTxBhDXtX2Rx3j1xkBH4APvjmAkpX9ia23k7sKg3qXpPJSNDcfSt/1U9hB/HHjCDpy9Rtt
pYu+yUh0SoPV99vHtQxqWKAaC4YiUsbBNeEW05kid7qWxxGYM8j7VLZJ99U9MH65NK4G2SF+oUzj
yFcdgaT1A4F/EJVkPRa6Pz/mcYo3DE+FEg05e0oTXG+zuzje3CG7x+ToeD69R8ySb3366+//uYuq
anAtK7BIn5bSzwGOz9WLosEsVlWdX69nx+45ppiZtwp7QqWCKCds0cGVtcs4ogdN+UZXSb5mPV7q
kkVNMXlsFfZLoo3y/f4jLb50HdHVsig4pNtzn/wW0bcQPPCiaf8vxYr4zgViSU1HNHC6cRwZUREi
UJvO5y6zZFeWUBirtekWNnP58EZCvawXgXEAVgc7QPDMDNVx6svcklIbo9/7k9QujNdt0pqMDdGQ
3nxls62omegdlXNVbZjPvgo4w0X0Mc/jbPzu/xrV/xcyK9isS0VwQBuia9RmaAS6UD1iIzsuhmbT
QtXVa5YXAssw79HbjFvmAqqKghUX6oDUMI4HB39YPtpX9kro1kAtrbC9t05XwYkFMka5N1uTEhly
rPGTika3nMzxV4UHH0HFk0YMqrhki/PsONoMFgD3vLZLd32B8wlbe49C7SnZf+iHkIng5EUmCOQo
81oQZYha4WLmZsV/UbCOwJAgx0vjaoRPHlfWAMyPWFnNOLKn30+yCknha183qI8jyv4oOaGYlfCu
ClkaW0CXNhPHcqbPkXk4NxspbcNJClznwmEEJHtwvnEH0+p152UioBcIMBwHrZu01X/vmAEnhrsd
ga52g1RWOrAooLHtI4PLMzLMGyeqEEh+Vphlymo07BycQLzR1ZqlfV89omlqedHXSfOg45qm0KXM
i39TA2mKRNIZpcsDRJS61Yitq+kOGs1H5SgtBmEMc4oGoHNzocjvosF6i+yE3QamDaFloA6UARNv
1HddUDNeeHO0CLIE37d9+WK6NRTplzUmQMVq9Eb7JMLEKytOydud8+pxg/XmzPbOgzMFQDC56++U
+lP6GeJ7/JV/1Jl0cFYRdXv8q0NVsTlWcl+qSwkj4V5cMDXIZX59xNXoZJ6a9By2Xa5Q67rZVUYc
uNpBd3CAZ1HBAYcjfSd5sQhiY+Q3KVjJYh2V85CNCfX9Ht9ZRenjJc4buwmgaeo76pI02oeH4176
2cQXfWDuebm9kGBtxiYADsPaAKa+NlUBMi5vgSIp4BZ+ANG4tgxPAZi1awejzUZt7imXzZjXp+Aq
j/NsknwBjCbopCrK7I/JjIOQt+T2vjxsMfePhGAECYYfWPxCHLXdryV2ak7BsSFLhIG+HUZAS7QX
7e59DOP+DbEZtIVrDicV8uOg5FiwbJXNonhCYVm/LvNXn8/3FOur+wUODro2nNLdu/sXBumKONIu
4shcTCnaNEl1qLr9GWIoZ36ESfAjR1jN3CxhcLgGDwB9iwoezKb0