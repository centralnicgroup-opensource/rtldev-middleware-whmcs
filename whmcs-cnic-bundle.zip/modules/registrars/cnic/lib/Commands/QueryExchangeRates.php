<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq8HetTm/1Tu3Q8sL6eVXMUs1AXG3y5ywesuaxgjDB4gpNpqX3eHaGqlHFtXYoNJR2VNJb2e
QyWB48TW0PQNa0D7DoSh7tNwqJl/110i3q17/aAxd4lIVZlQychk0hNx+qXztb2D7vCUjVQ9efTP
V10h9h3Ok9wtjhqej/PSMYJgBZCuuEJnAmxp5gKX3eXjhT7sQ0dfGD/ShrxwDkPToA4Ln0tr4xyQ
qKsSvOwFSkuMbw5vpqCYUL0X5zuK8AsVG42biVziFXhP3NoA6aoR1ZAhpH1ap9fYydEpC5aDCGx2
h4Tg2BXbLw871LMPYXjNzYMKow1aQEgr/HFkysJGyE+RTomRPyRGtACVsoEH63dZ18ePirM2AaKj
phZu+w2wVb+EUIpkfo91p4wiQPcCBJrdwaQCRMzclCEw5b2LdJQILh0CC/3Uns5JOGGQGDY27BJI
eekUxb3xyNha8LqvTRXAQVliKhL+rpH8EreBtcyp/Y5NCESGcJc6njBafxxgXuvQzc//wjYRmSFN
qOF9G/FfCw20iksGl1T1AAGBYO3HZYQxk7/iIomZIqskWtZ0/P+ygJegSNLgPIQgZ5XDRsZyNlRc
uQZKu0OKaNGji9yG2JzxE/KRW4V3Iur3OvGX2kH07I1do6N/i4Hi0XLyUYUgy5+UkIcnJ7i0KDO8
81AtFQ8rlII68GWVIRBnSz/heRuAjpK5zQ+512iYOxZKv3gA8EAvdDrLmkr9yqS9R1BcLKQ6yAAE
UfGIbM3o/71GPs0+5YrCz++LCdJm3XJEcxOSjaPEbsUSgZs+onotVvFAPxtEec7dmDtgJ7YF2Rpl
PmZzs+KMYP7fzMKGyuv3zMWpPDQJNln3qrGt9qJH592Jhiw+ucRX9+rfNunBPYGZ6CdAV0VECa9+
fHUkgNNKpTBMNH928zBOc0CRtHPWDbqnNfK9Km5dc96pm77XuFM3Ddj98Ts1g+0b4tS4lA8SefiE
R0uf1kJfNwjSSW17FhcagfWZZ41HDZBQGTkK4sxmpd390ZslPZ4oKk9L+EYHSogD3EFjPuuEeS4L
Ph9rR2sjFV1SmtYm2JyEgUOpOxGN363j7QEROH15xtO6dl/n2+wOwV4ZFoelKlaLKC6aqHzCrbEi
mWlmYcrgwFsF9pHQ7szUJ0yFIFthmjiJ3DvtOeNZy1M+uEqv4P63E8dKYtKUkKVL3eU3fFWOpNei
U33Rtn6qAWEVxLvJtoajaQkSFYQH251nlxlnJ3cY9Yu/U0Lnz/nZDB0/IFYCUoD91rEX++2/FLuN
Qp2vMuqBEEYNWt4XbGbntJx8kCzbjGpeO+XJ4ddGvTgzp3rVAhHr/rboxtyWDfnj7RIPWT3jSp7N
h9az0I1f+Zi31sGSQfKYpraUBxAVBGTr7fTU3ODJ1IqKgvYGesIR+pZ5BsBrX5YSrt1gxfhRxnJJ
qJ5uogKnitnCzge8niIhr9gfmKl3T49hDtebHDPx1oeI0aamnxc/eB4ur4/5aPKb3LMvGYjg9EIS
bO6NS5PCWI3buAWSrNivJ7W7lxkuiiSS0c27bukUs9O7+5FSGLrEJEGAoMk33IBTYz86bFgcu4p2
8D0SSxmYTTSs/G63FGrmLWoPcyeq0jHphojfVoA0mXtmHDMHXPuBytIUYxkTc76DHEcHBbBd3/db
K6wMr3ezFsIQc6E0HTGM6dQzXmldFlj7hL9rSkKnAtimcYwnn+57EIbH7d/luChMKXgUqdz/UbG0
4EfpSx57nzqPDk7P6HOxzwZaNjo4YLeJj4GBfwRM4uxG7S43v9qngIj7raiuCUm8gHL0xq2Xa0Pi
gitk2vCoGIZmSpDMFUYOn0Ub3bXwAiNRbnk3KNzgR+lLytg8Mh6FA9G3LshK3MB6A0bZUd7iaowv
cKyaBTBgMbwmWEZD7Q/f31WrnGMsiEmqGCLk5gw6fC8aq37Mr4QeHChl11QoOTLo5LlPglGf4eQ4
IQLwswRlAOmGYXja1EigPR6ne9ZW1v+2MHFMOn7UD+yMXdk8aWLKXZuxAQiAIjVRE+VmJ8wVijn+
AKL/YJa4fP5spEX6CbbzBHS9HV+hAy2LH1UXHyy7zJ3xQXfN3ZU+ItedYT0BsQnZ5IowscjriUwJ
KLS7Zp5CXSbfp51wjbpLtsEJz/PmgWgk524d+EmhylVbrDhYlB2Jody1lfUjs6jTQJ3Nd8sh4aO9
t3Icc+Q0DIHIFrrcutqNXv52x73ip0xjfPanOhTLktmkk5F2/k0ziT4cgKAvxCzQ/WLxyh4XcEVp
WETh0ldRZ9+hJHaRnLne075YU0XSk5QEuqCMUJ5JdVix0hY8v7JU