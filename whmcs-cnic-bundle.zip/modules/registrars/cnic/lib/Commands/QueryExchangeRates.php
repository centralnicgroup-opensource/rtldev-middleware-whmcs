<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuVqc7mTMs5ps4SDNoinr69RaV/SSIHCxBcuPgZWGjITTSvU/jxMKulQ3CCp9toP5Re8d/II
5fdktWc1bjDJU9IouN8UD8hGMxsSI2/uSx20y4fasVthI9sOav5Huzb5bP+6/X+k6mZV8Id/35fw
x4uG5nP6GJcANVesP4dZ3iWjxfzurZ7HJUVWiEtIEK+5OnwAfD31S5YB37FnNcZ49f2tcfVkwNlQ
UH5nHJU3XgQWm9hAxA0QRPmCO0FqlKz6cb+P1RvSKut9IebCxzBCMPaEOPHiDZAdVvqttSC3gXce
GeTKdpEDn760v5vJMAUwPr62vG+5EQ270fBGUpqAKSJToY6JXwvcEPycjGh8Wq1i22jHn6HqKeEO
5rV5aWA7xdjqwW0RCXLY6kscMsh0zylAVjxc96JWtDuSdanGS07CphxmDed6MVYeWz2h7Tb+Vx3G
EwVTU2BuyB0kNfVF26KzL5cYjZDvXw/drib/0nSBdlbeZMcqR6Fel5upiybAanuOUfJeU5//HdU9
gOzEUhVD26kien1tV/u/T7IEocND5Plty5GwewmOfHVYQia5x6Fv58n626pZOBjNuqBxg4cjZB4Q
sYzkStW+T/XiLAZ1rlvTMTIVssBBedtLoZTS3MaUAPBkEnx/VPNK6VA4uTPST1dnRCyHgM9qG85s
l4G4Q8sAHm1IgKCamwjwuHA0rBXqzJePgKrLhRinl+gvq39yfd9MfG6Hy3wfqGqCyci2vSkx/8+k
AYrMZgF3K8FTPmQG440PH3DzsFserIzwrW5iCG1aWBKUlmqc4nQcG87vLaygaJGqnHolckpBrP7S
SNLtv0j7ET+HQFPSEJAEu2fwPvwOgVeTNBHNFV/pzjGB/ciCuh/4ZNpa5DyGYKhYG4nQUTKgvlO9
G1d//R413GFDRBjDVC1MotoRSyO1nAsJBY4tEyazjiEiTzT98PlebiBvVtdFxbknP/QnGcHbUY2n
Di+fSCFs8oVNj4auJIHzM0G2zEs6S6QV65IA8H8HhYh4ePi4cNqJ0UYrXOJ0SJg3pK/N6WKLjXQa
LNfHvHr50HdZAOhnRRCJke4/rvSlb1jhXrBfYAKa1hpIT2KPXApwXi3BhQur79OCRj550eJbzsBP
c9SaoB8R/bm7D8xmEfNrssiGESXKiH1QvrbxCHHC5dDgGZrHC2yTyWGnUXOz+aK+FpzsngRjhi5F
w31vpm8ApEnPv2o4+w9bCBGmh9T3nHj2znCex7IqC/HgOPKhswB+jDesrDvJIRKCkQQ7d323bYx1
9tzI1dyCwkyiR9tWWTDhKbhNH39A3ItPDP2aE33X6f1WarS0lxrw/ot/nIDn20VPyOp5l5bNEXIf
M0ss5XNJQmLVU2vdqI2MbO9eUFEaCRdeKgikOVvOxmjrk1IFvzJUl91SLlTfIHzWxK6FUN0qdZGH
2GWKPHylg1dH7Uc2t5yWZmRvkpr34Eg6GBz6j1vyZWUbB8yLHfXeHho687ydM2rsSsrj5dd9FR43
x+PTrZQpa/krTXspdkGmLb8lURcfrVi9985M5cqSPOcp79zwsc9f4Gp2l1ZY1fT7LLLZ/+yor2Fb
M3MG+/C/eCX0g17UW9Zuxxx9Q0N0+79YLv+VRiheRnIKyzWTcmbRtii8FPvxpzVJyoVGHpFtvY9Q
8uD9r7BjzoLodcN/JsmQcwP8ZDj9pMUxmrJpvfTDsJNfpT3m47Rcp3jcLW2qVtoSMbfQJj+2OrFJ
y0tAu0gBJuPw7GTJBlaoL3uSNocLXTXsqLR+desgssovRFXmacvX6jpzAdRDQzse5f3KFzFQRm2d
nCbzVxKmf17Ol3aTaQWebbA8TTrbS/D34hgpuCmVjWthn4iFWevlr1LPorX2NHrLTyigTtbqqeyV
wHUeAl5NbdwERIMaXlrCppTGHrTtG9KRG6rT5nL30dGDzE0IiAblFOjbtNFqBa1RgNJUJD3C4ekE
vkkc0oYCnepjOX7D0eInPHXzt8ut0JMmszjT+NY+1E7hdwJzbaJjUir9fZvIB7HsLUTqHFKO8Yh7
N5ucfBwAYjIh0gfw8IuTKnccn9GAkxY2+gweGmjxzbVqsiz2YhUIfqUNB7+77Ntir1GFg3NB8a5u
T6nEaczlkbBDxzdowNjV0flJxtYFM9u5KEZ3V5tbj/zMIjA5qzXjFY9C+ghIanbr7Y/sXBF3KHAO
IQVKxJ54JFFPDGTFPmzD+70HFpOGuTb3TaottGv1tvqdMNLVMzMkvwvG+u+86I5ANF2jCuTC9vK4
ydhv9nTX3mdruyLQXh0eXiGzfTVXcXS=