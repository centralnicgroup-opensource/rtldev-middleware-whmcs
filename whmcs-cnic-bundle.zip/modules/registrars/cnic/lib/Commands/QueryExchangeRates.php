<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwHRcb4GkdvcxUWFSlPjxqVJgY/zJ+LFAREuR6UVVcfcYVjgvm8Py2f5kB4k/IRMYOaWukLA
hFjwi97INnFo9T0YnWTag07fkp+aiAjunxcbyaVArzXqeDv7AtpQCCOUKVAOKRZMEVpVVPHdcuqF
sTFzNLZK4whYndPHntFwUUlC+j9paURxhapXIZ5NrmgIg0vkP6v7H71Kq+L7h85mdq3UBDpabaaQ
DCvNHAUzd1yiJnqLTlxOGLbewJA4VBmB+EOd3dZg08yfAPZoJlL6wQeCcv5mZt3pqFUo+BKC3sOX
jKX3/s6gMc8CAW7tkyVH5xdtqLbOd4I/5H99zVcQT/w/1ExHC1GgdkvtnTmGjO5cy21Ny4xLwRK5
OTYF45oNQ/ttVj0T5lIhWpi6JvojgCTIGWaxPXbqb2mjpZyCqCnV2q/awxX+PtFk2cw1wbBY9ywd
QyDKU97UX4gFsC0YmXQlTiDjUUKbfjchiLStLFrlCRCt9c3Zp683nyJv+SQaXAuXsG6n+vMeIC8n
02Vjx94cOVvvLteMf6hw/ZXrwm/SjRGT90lqvb0+a9pw4Jks164XJkkzMubQx0L4Sx2ZbGc2yeUR
JR9b4HatNwAsSWMg51dtU68fxrpwL+bRpQdWYbvS6JyShH8lZGSXU1odRu3x2DgXMxPg60jDsIWx
CJu19PzfM+8BI2zBkmBUe+q5qO66i1LuCDxsIfy7go7WKINyKB7RNHr1ZpW6IDn7eSWppF9YwsZO
ctVyYOvdlgwOlfs6UvW9XZVUCIY10SyzDul99vTXxlmmjKUdQSEzKritWZsQceEm4tvPEN+KngS+
pbem6GnHJObqtt6U7sP+jBr0BXJRol+pB+jdYOUHncv6aHsaCFGOqZeRgIUGWS/VOhn0+lzGQnOX
qyqd/ZTCm8t5VHZE7oN3YzRI1cPLYFW+bWcNBN+7s056lqo+SSLaM+bVCzLxS8aQ9DusWVeB9pLZ
u9cop+Qk2EtcCmzZxS7uxMZv3cr8s0aQsmNfTDQK8WVmdje/tFJGWecbcXx32Y35Yfe1Tem3Mv7E
uSRDL2PxDZEPoOehiSbV6x1v04A3sn+EAJDSNjDXk5xD/OhfKy9WEntqpBsORqSIJmYcBA/fGUY7
Kjilf19Ulmi/o8eNaDDCgdrebBwdz40Qjjpw8ejArmWWWTHHBE13mJ3TW0YpCgTMlWkuyHAUbEbp
M50HVL5WPegQ68z/NMja0G3uhOLa9bDBfy+artU4Q50aSVgnfmN3/G/HemOaPEUvB1JdomI+0ZH8
EFRrP/2QjU7sFdy0b068ios8NpiHWYrZYW4+yVf2oGjwZmZiwimGLDgZhHGWb5xgpcExlmbQHiox
SSaaPJaZiawe6gGJCTh1KSzmLmuD67BE6gZf4+XBZXacjNqPAxbjc/QrREyl9TNL3gM4jtbzMb0+
sdOReIDnAFKiXf1BDXHZPsYv/UOnPOBBusc2VnchhiNYRfO0EfMajM/uLdfCOQv7K85jS7BW+P6q
u5rMjhClm9i4v02RhA+GQilxVmtB3gM/vE1ALn3rk2Ey6/OLM+PQHaBY+mh+UIUeUFo0ciflfaX6
TBAn7lPKX7ukfdWrzMXvTnHGUgHQxBnHSw4Lqz1dL9J2MAZrCaQ+1sPd+WoE9T2yRVhun0TLD4ha
SFpROQk97jyRjlidmb0scHWqAg7vIdRacmPyk8rMzlvluG/owwxQ5YJPRIQ78Ixtb9c8xM/vKE+g
9E4QGMa9Lzbeo0AymfWnOIjjdzxK8DAxB/3r7wtE6LKQw/gRoMQIYtJybD732vK7WO6J67pgEWs3
GD4+WNulBO3sJFj8BvSmbO7kwSpzx1a6lg3O9Fnbbcs9aiXjcRLW4PFTB5YqPMCueIdkt8zZ4t0F
0ZsDKu/ISgHVNf0BNOuAXBQD3BKNh+ukOBWsSi6dGA/6zq90/8AskoGdGtk7LWcPv6YZfzfBY4mp
ghwjfNRRENZvy1k16URVlzDdUaEXwAk5QbvkcJwMeuePULp3TkTBaR9nQPp7uOFPM82VcDTISnHW
+47Nw5ymVQz63hecbt306P5Hl9CO12krv8xEv9e7qtbumdh90i6XOcWu3CjIiHBHHRCjhWBivKGi
zM4pZCMHxpdYXBXScA7maxyZLvMwB2PntQj8HnSf3p7+F/khGBwfBGoD3SOgH8JYCOJXDTxnK8FK
Ed+90LBeDR9H05rtxe/rXF36fF8FOCme5QR5x9zrXiJkmkBTA1aIqKzC6XCuKDrw0QG6ntp+JjZQ
hlvcy/oszzHcvhVKWZ3If23OgNOYRxcSeB4L8QbmTBOLmT7BIjdntT5qG9wAvoxA8hGzf1W0R0S=