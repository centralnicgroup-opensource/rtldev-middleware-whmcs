<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm2Padc+PsT+Hoe7MlWXu7vQXzu6v4jkQz0rQ7+QSJtLxWWMAAyC3iHDMts7EFIQ2QaMby+u
lPCVBlbg7glc3HLcYxI3Fr49vvbvTB82srY7EqhGlukElpQkgiiiBg+R09N3ytHpeXAiQKPZtaBF
QBVC6W+fMt3bQNXH5A6lOVKLqcspqu9bS/PkRVXGx056eqMnHsTlrtIL+3XtTZNkFyrBD1I0UrZD
e3KT8iViuOKWbDKenJeCE0yZM6OdWgeM4A6LMAIGAUqj6uMVxw+O+s6nlLSJ2XwkPEzNbpBSL8Sg
Bmf8uLfd3a3P3BYVfDmMhYLEBqdijSlR3gvM1AUU+uFuEhQS1acRPI0t2wrtCZboVsAtqEbV8GF4
B2BtrfxVhDUIWm/L8xTaZa5AchTzUDaVPxBeorra4VM8CNzE9TkKbsOuI5HpHX2ELUjk5lG3ldZZ
CN9hBvRNeDt5wIzg/qQMiGKbHf8XweiKhSLv5gBhlLLSHNzIJhgnToa46KZw+DqRMBREDw2hfRDJ
4zaczY+CZD1vUoGaNqpmOLa2Oq7ev0lwP1e+cwYheWSFLfXakzZBmYVhWDnQXBrJuKC5c41UqgOO
XkQAsc0Zxio/doRgn2gqJyLlugIiUiWtUAHOaFg8pvmdZBGmdcBPy0ba/pbdsKR40HOVMclPP+l6
bx9z/4e5BJVD9PXsbYnFXqC3ifdHWmcx977vu6/hIZu4ub9S2G9gerCs7IA7Z401RCg7YHHDbFz2
95oCfpbEKhPBKo47sG6mH0fmoiUAduaJDvXUALXpEH3EYIZ29WzUFmDi0hzxaf1axuZJYVivMwEJ
7ToD4SkJ8T3b6jS5D1AhEu75h3GYplIW0EGOPk5zKChtCVTxPuBTfN2KyCXGxyTpgSnIBt8oMLoj
9h1sto56FaJiy+HzH0RpnAHg3aWDqfqej0n4zxaSlQE3l1vwSi8oLFEJjFI5APeaMiSZNRaMmnIv
FRptnwHrDJL7qzPxhabCtXw7nKHURZtgTJgmLYzfN0nuDSMFMsWxNRPm8/tiGB7ZJ13QMFNfLV+e
JWEPMeOYx19G46O95y9YJ+d//UsTpbhk4FKiOs2E1ZtFwea3OtoP3dUew0K5dqSo6NMxAsRHthZk
U5anxNqnz17fTr1Zk8Q8rj2+Cu0G30l6xDhIFHJFdiw4nJ5kSS9raWC6U381AnXBBpC4VE79n9lc
Qlz5eJ5c/2ohy1zl+sTMXM/lUxtfEaqsfe5g8hwRCfnq2AJsxSjTf9xUOzYRC2dHW/mLDGTzauet
wlBsXxcp8SxdfuhBX+uHTwgLQ0SfCJQw0d07nOwtOxb/9SH6Hu9/ebFfWLGI9EY3AFzPMJqmQ+1E
SmfofFgkEU9oNrQKetojGkjRplrUzAMS32LCVNecr1H4exILSeJLP8fV6uieYK7NRfoVTOkOW2sv
9h8eiQoNhU4smSmVIsnT6YExsB87ufTKrTr+tWBn/muxPHpP8/TKOiZnlT++5yjf8noEbKMYRLYz
Xe+maO+H4gQN4RVqR9XNjKJ9zawcE07fjzwwoiAqoR6GsaCjSjVkLDbWZFuEJ/GSlPd7RgkJw7DB
YxO6TC6YcNEw5JCmJexVeuBaY7amBkCcQ02Y0XTojpB0rtRYPUtnxpaJrvYf/0mUPC5I5qQMYwof
QY1kEdm773aPEnhv14zNK58waZiYRQouHa6ZseC81lOnn3/yUZrsXR96kLwu+4HgdTmlt1jxOpwo
nHHPrgflqTb21UPvIuVOeVA9mBUdTe35O+qP0nPqX87LZqv5XtgaipkqPry8QSi9WHosiF83FGC2
qFBGYzxOvp0KVsXZrg32OH62JLwE+LC2eXUGcj8LxYXXDMiN4oxHKhIp+VXUhvxRM7+ABDCR9Eun
dGPWapQEt+xzEjLZSbLxwxblGYs+hvqRkVCVPQbwZbPgOf8hhb8K6aAW3GGUYm9VjPwjFh/LRSjI
J3lTt29KgGS0QkL/vsZ8YwTN+K7BP5+RDkUF+bIfXLaU8NjcBnk18hyg1KW8QNR6DPuDVG8NLYXL
lVpiuzlU0dh56uZIX8c/hGC5uwzNzuUsPrqTjxrQWO5Qj++mkJ24Sw/Lq2bsJddFQRA/csOqx5yd
7MBNBRkg34y3wviaXwuv8GHmUi2LBAk8qDZog8ZaC7px338wJAztFTmQW41f3TDqrvs4I19JT2We
uz0lAIwOpXuJV+0eKptrYv2uNpH3DjDstIx2uuX/1qS+eEN3EhCdHav7AS8QJSF1HxDQj7g/ybER
4bnGQrk6he0lSZw5vyM/xmJSHeBhKV76/SkPPiKm/aJbbY5AVTVH3UiDjcpchCq=