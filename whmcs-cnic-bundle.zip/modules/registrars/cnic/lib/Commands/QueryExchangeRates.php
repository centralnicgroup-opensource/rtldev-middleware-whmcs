<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/mgps+ZzJD0kfbQJ8tqD6UMLp6Zca+z8VrddHfMrYOG/WhIzEXJlMMfNTzw7Qd6lKJvJGy0
dgwIQ0ihqSsVl3ev/QFFyXSPAMuj74AoCYlzmkJwuyf2rBdadkTsGtyE0KaHmrq4RLFzB4WUDi2X
S25GzwYo4t1AG4zEfRaZRh8erx5G12XbFoWd8E6O8l+eJIblzQc7lVl82vt4TaBG2qAOhWxKPfq0
SG5QTRv0y7iK4f9c169CMs2VTrm0TmWiH14fdiRVXwSEvEPZ8/0h+ouhyRwEO/ckFeGAU+buUnEF
0fQ7D/ydcqGeL7oM5f4+9m08mulm0bko2o5BwP4W4qdyEwXwJS1B0aGwxov89M6GCOKuLtxNlwzD
Pl2QfgeTD58XMbkHRk1cR9nJknxwQl8qFZCRAApVl94+IWt2tR00m48XpPQQrxujRztrWrC1ik9R
bkTUIeJbxQxnqXAhZAvjJyWONeVKpHebxJhhmXiXuXtJMCofMY9wzvj/m+Lwzz7ne0zxFTV8IZA6
ojPM6nBGTHokXCD2e3VtG8yFl2LhoVdabQqitDrqPdpL472jw8gdy7ciwolf0gD/dyX+NPaEWjgb
BnGZf/hdgtPmGzsxuhBt4xbbbVu/KdQk5smMRSdzLZW04c1QZb5RE+Jv6pHEPEJjUJDt98122kpH
pmCGRHCc3ABRtzzeNAjrnkqj7GfftPaTOqftlkw/IgrHXYqWGcYOz5aONCrOhHy2c0hN7sxxkFD0
VhrZFi7eYuDeW0J5pknfxrRxLzwQeAO9YFZeEtu7WOMdfsNRwlO+l60AEs8b7aNFRr4hsxL5rLFL
xE3p8f4iOEEN9n1qxlW2mHA7jtYJZodcNhDMV1OYc5Li4h4g43I4tcvpreMxP4BpdylErhkCeUBi
7t4lNCXeV+hhV4G1ZwmXpKrvUHTqUe9NFaiidsGTjhIAGMeq3B5S6nRdFLf1pUJ4YFB2uGHbKGq6
sQy524BJeHT3ASjSrJ3PFMgsCDfIuGsjHTNCOgmiDHkYZ/xjgDt3QZ5gHfv1Cs/PliA7ddSLexNU
OYUyDnZtbEbRIBCiEVk1VETg6PSv6xkOynDjgslfTBmTdK5Wo2k2nvnL6xHYuBWBZ6z0j0ghyEDb
1a/7WyqBJI0rixG20NWUnsNv+r08lW3YqIAnk5JH1dzUhU88UVgbTkq9XsYSi5wh3F9cY7YPn7qu
U7MbYB9YUeQFYNiI8FrIgh7ywKFRwYkrhDMflIgcqNXc9Z8pOlpX1TZlup5IAbN2OrRXdtHnh5Iy
4xnookIvgI4ELscHx+PrTEPc+sJypUotJ7wWTvKLvVSlmKDIHnvmA1Wz0L69W3C9AJYKUGRx7ft2
0b3iaZsDZZM8QtuVBjt+5lZNN+tmExcnkVzs4H1nrWtHK3jXbh0Zd19FYfwN2iQjWXdsJd4J0HzN
3d43IOu0BXGq0o5Kym9bixqo69hqYAop23GWlukCfrvaMi8nZhJbu3ralxxfkp041hhuADmX+eHr
KhJLauJ3g6VW3u5WqBEckShuuu069+EGNeqmATh+eteb+4HBAfQmAfbuTlGOzSa201mz8XDmbEct
tBRO2IapYBZdvOwVEkhUlQj1ajnU6l/nQ8jR4mqXnzhHFmRayXjOP3lDT8OIvjqloCOhXV6JEjKw
kgiCMxYbh5K1ltLNHkkE8bK4FnY8fLxlKo/c8DmBlzO6cnoGbk7Y4ExGIhmhpjMEoW5bHGIO96xy
8tSWjSbdilnlL9yJMdEuKcI5wpaWoYoWdOG4AKFeI7ZBAyyKHeWjsfVNfnSJ3RU6+PdBvOZFY9/z
geJEQxuh4l6AUE+xTq0mtrp0LHmHuDlNub1C/zmncLbu0SoCeGF0YJDwUtZYVVpLuw1C7NqZiOKQ
VFVn33IJcuqEQmTBvb1FSMIGSVBDn/eqwxNQvCbQK7tiPCmtNtF4qH9xDcmgVVY3ktWFGSK/tkok
EPK1jvZy4bxwGVZnCbT4BBY/c2Y/SOdT9HMHMBMLUmVBY1EOMyyVT7cx9FQ+Fzb3/God64GADths
96Jmp/FLSuGS5scZqbN9qywF8N0eGdCRuO4tIiUI8nNI6GM9KDR/zJgpuzTvlU27l3CvOYOmdjcM
Wl1kjY+IWkcagFYE+yUXsNhCpJADWmCwuNlyXrYx9t4oQQKYQ+EzY5WWt4DTsNaOjLCYMvE5uXLO
s3gNmt9SY2ojdKobdDsEoaJGg6jKGMnkvYjARDWq3stX/yJ2Mvr5jsgo0lRUyTRMXYhdgSPjo67p
Bp3b+W2qyLVcc35IZ01DeNAOAAfDxsGsdwMxFai64BKbynKFfRknNiAcv/YzTG==