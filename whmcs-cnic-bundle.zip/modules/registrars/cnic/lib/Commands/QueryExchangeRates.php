<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwq3e5/euXYGzR0rVEXUd+9hXiK0kr6RBicaZMxabrwAnwzEStNl82O24/evNH6pkq/scRwh
K1AZPusKwvOzOwn5lPpmBffdRNh2ASAb9ddttFQLd+93vpFRVBaDzguu029UA8MiB7gtnRj/Joz5
ZuVSFHQgBtt5uqCYkFzizv9SETvp8TdvuV87zi3mQsBdeXPUa6MRbzgV9K8oGDaGw9Kv/1L3oLp1
tDyfbU2r6n2IdrUB4VXcTcNtyt7Nwpss4xz9EC9LrGofFGIgAFG//w7FljQvRrSCiMg4S132TU8G
E778T/+NkteI9aL4z2L/qEWSLQacCwG/7cMPJ9+bOF6g08x0O5sWV3ENAmvbqKEOGOl9zOnPyX1K
Ey8rvsmIzt5ImOepoCu+II3cwWGs5Sb9r3KN6mrj4ivNZasxS8B37hFVGZBh9R1lx9kGWoeisRq9
3YMHfDKe24Nks+IG18Ns15zH6qpV9mb1LHvvhYzyN+6qvVwGCxSnybcJ/zfQJrT8B1obESuzeNqP
gIPACXQa+cCgJiFHBnejIukYdmmTG9MwAPzeYsrx/IQJ4qzur2QYpwfdS4SJOeSS3TcsRzA8GUQB
ChfNgXbDPbSIX0oMbFo3jPFf5Ie2OG4+f5mEvsWRaiHEf8so+wEaESotu05SkqbQPBSfocyCfcxt
LRHMkLtYzlXvvG+Pa73OdiADN2tQ0AKzgrF6YR0bLClbb81E1Q5RED6SGxbeooko2pB0qDe52qxv
zvwAFNdCg0tc11Rg+6w67XL9p9yM2wEm54z2JpyqA79jkZSE045RfyaXENloSY3qP6FvSDbGbBi6
QHI6HOasqnFNIXt8Jrag5rauC8AQ74nNYPfcZYyfMX0xCWm1hE2dVpLxg6OdC86FEufF9nnRLSbk
6PmJpu9YrM5QbNyAHbeHyohdkFQ7u8B/8ZUmZmxe0wQ+YWHdgYXU/BKcg4I8K3+A+PiwhC6DoOJe
jFFKRQLoDoHeU0gCvPYSlSySOXhYEYklakT7xGf8H1llsA2NjJCteK2wIe0/n/NSFXHJpdAwCePx
nlmnZAFOPwqOrWxpwaqJr3NVzTJzNRs4c7BcdOFOATIDDvU89Ll19tyV7M+FNEy/IxWlzQfo25E4
PJQMbq+uJCuYCaM9temwKQ+bvvU3xnOYM5LhZGnSFnbe+EO16HFo8+VUxl7O6FsMG/yILtPjuY5R
4Zx3JNY6EUiKTNpqG4YbXFnWMGR/Ej6PU26APD5IWqKgHuT0sRZ0/DD9iYNC43XfzJXm3iMbNOgb
PCH1gPvG9q3fyQYDisOGZqhWEhvCpgwnzwnNt7TvPEnSBxZ3OaTLUVzQA5/SHsxQybqwPWViwzck
kHEtg13W4Y7RYFGdArPxXjLAbKZTK+6jmXr5uBpPZcANoc3OJ4rrEuU8Qx67zOinEC3UIrd2QJX2
5iWX7MeVrefZBnTMslNd29f1owhlkk52OQNxC2vW7kdbuuHHWuUA4Kfkin39dZzwUtFFsyPs7KUu
J3g02kKXvIHW4caEUlSuJoivL6i+b3lP1WvIiBbx2gJkws191AXA3YHsKY9papa5S0euS0yqEsoW
QwrQRttHve4VZn/6n758XI5DRco5EkYweoVjDef42CCOnxh9gtK4axHjhrknZmcJ7enqN1r4JHQn
oI9I1T59sSLIJYOmDx70vj1ZEJXF2Aq0Rp7W7qwou7cFoFdX3P06jneRk9lyaoJ14raKMJTKYnHT
hCSYxeVXIpCDp5QGvpskaJjXX6eaT5Ork2S7kx7JqSFh6lfkav4AGLxvGPixWtsDy3NtmcSPlYG0
ftz8PI/iwNU428hNqbnqTK3+kULjXKf9ptTGzlhTGGGtba5/WBPRaL/Jxok/Zz/gH8QbhxaHcYFB
CFR1Ld+1uqyePg5trTM1dS1ni1u292NLu5hfqryAhP1oLq9DULhsc6CWftdQHhqkClqdIz2zNSeM
VIZg6kAgDE9k4yoiZe0ryIKDdQDa60oQ6ffEqTMO3J1YlS/uWOgB9sG6FaqNcIdBh4Qp6yaYnVLl
/3fETafFMNTxhZXofP3bKc8puq1F26uKi5SsUBODw3cXkQJc7A2NpvUm1A4UHwLSJ4Hg38w22wv5
DULwAA57WpdQ3HvuLWTmj7HaQk59Qwb9UtphJ4HH7UCEvLv7+isZfjP0O0hW1bpUl2Hx6FVtDLh0
vkN8B6P97ySxZRmF28E65GUb73eYGst0kUnNNF/I/RDFZ/oo2I2vXtgBuP4NvPM/xIe3oPY7sme+
sBpTbVbohacNUMhak60DEbba2/iVtdosryeoD0==