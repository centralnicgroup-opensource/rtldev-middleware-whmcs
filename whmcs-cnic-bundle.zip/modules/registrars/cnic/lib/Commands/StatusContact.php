<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtj8sYJO6JyBfOLF1tNyTawadGkz9A4x8vguq+yKvKjA46MLKe+qd68ECpOdTXeJVSRbCkaY
o85gmVhUyoBntFyzDqWNId+zCjmsSy0ifgGXknbswSN6iZUyEcyC9lr52S/vcPxSgfe/1txCQuSi
7I0YXthdMnjUM62NgPbWho8WpTgYcALNN0goV14K1ydsjK/aQa8fp6FQiyeY2HHTJCHYtVLa19JT
HqxU7/dmf7ofZcroj2pKgLzzcj6EPmIAB/QQiVziFXhP3NoA6aoR1ZAhpRfaq+M/mry6llK7JGuI
sCTnD5hD6egpkGm2pR60XXkIR9PxSnsmfu+6TlvpGJeYQh55pAlCnHhU8GUJ0kiuM9z0MTVgcysH
KJC4qTsfsfFKUSMIG9t1NbXrm3LJ1kszxX1NL95vbyLgq1dn3sUTN9LLbyU3yEkn2fla3DdiRg9g
BlGganFCM5/ZPAPKS+UUaq5OpdNAC7qbnJQ0X+wE5c4rVfvUK8EZgQkBmEPtkBfETG9ECmqBnvJU
/mjI1+ocPAM+D5AfKOSn5tBPxW7R+OBJrWuYW1URxufm/uDpiA59n2CplxlOMk4kPtyg96pHJ5LQ
+D2YVbcFz5pSM4/jxFMKM46KdUHEcj0w9ctbvbn7+/pyFmVRG4l/Nbre9L94pRJHpjyEyJ8sSNiB
pWMs7JuCurCzxditUILG35FtW4pyW+9Aj/XEEzwX9G4Ph5L5JAqx+OBuW5LBHYcmpsd22O+0lVA/
I0kH/+I6J+ZQWLqcLdG11q5+itvWajrSn/dE7/EEiQeroa5TA6r/3aW9/oliFW9W81G6XE9hLtq5
1NalxbWHrActvQwLZ2vMipW8jgGDfolIVxY1Av6R5iFuKwXJ7+sz7U1mrxrwNRGbhbpqPwRU1Fox
kQHjPGJE8yZgCeAlTW2dyef9s2eEAWiMs4ym3zUHpO/D2bG26vBUUvFGLU2FYeBbYRNwDSsKvIxp
ua96i38Ui49KNNMOkbfi6eWoP+rk0UPZgHAMPrPao+gBHW4h19TjxMTpMKKsbWRQP4QU85k6/bMm
Tr7kbhbfdikPJrOT9BGCPPlVmOTkUBfUDQ8Jq23PpOTZaMf3lkfkCmSe9VkruXWsG0g8CxS5cv0L
s9Gai9As3B/HuBc/36wTg4SxCtRZVwh17S4z7O8o8vikj4M9jK9/yN0UdFQt0n73a5vtY6T0DZAt
HtzHptIRdn+pr7M8yoJacESC1S27ZMPDeXmRKYpRlBD8r6wGXUUct3AqQEORjby9w5dOHC0Yn0Rm
GtHHzfTwAdcMDdvQ0/RpmonOzPvZVwH2R9AnwKc2DBAsWa9eq/m3D8NToy9W/orhKjB59fRMjORY
v+xaMa+AV3cNY0zjzhjOr4OJLIW+/HFdlAJdECu1zOA2wCtQ0qEyzYcdYHg7DviilLqG8WIH0l9t
jjQpuABd8co3Ib4n656bdM7LdNxZypd35AJ7EXhA3k6BnaW3uzEKoFVWucC4cOz4z21ud8xIEvju
RQ4twmNv2n1+9ujY8GVsq+H61NlrBn6WVQ++spaTVlAvgXNfstPLmV1K/sRoK8ogqKxoNsZ/OMF5
ndicEhflbXqu7jl10QyP0wt0CmU0dLTZEwajIHDgnK4HXNIIiV2jE4P2G6VXUr8rKkHk/wzoB7tY
78bPyW8UNs1YU4tzgFPFqm1L3RtsXTsr9CzpZegU1eiPxvMMbsqpwmGz+s4ZeMLztOIsj9EXaf7p
ATXrGKhJYwOQ++sTwumiKlcYlWfob/5DLfRKL3xn94cmG9aFxw7C6LzHT6rBpu146s2mflXZpRDf
s6iwVSVfv4RMRJuizWlwneV0bpB+JLe57KQUtWaEo1khVNqGChQNhopuuLD4CyXCd/qNXbExGBu4
mIVQMkv2mJT9Pp+KwPCCJ7msE0YX+Qt0XPGAHHWai1QRo2uYTgeRKGvZKmmwCTuO96MvlgDYwsbr
nN+xOEfPAOONjt1MQuxi9oNeT+Wrio2ZBVpdLIufaJ4U5nGjEj0NvDL5ycbbBiUrNtxYhfR1CV/t
eduJ+GjJN2n8W0xWN5OiVa55KsxZLsQ9HStczQzkTt39uEEcTgWx8+5XA88fg6Yj2ghomEx/Cx4r
iQz2ZOfHo5Z+lOOccUEfMx70f2JKf+w32hcqwNDn0DiTIrBfWgjRziApeH1qNixJPMipN06OPCSi
ySyhVb32eiHluzapZAdjl7WnfbGTM3WpN5GGjRLiXRqD4k62UE7AIHCoIrieK6QB6LtzjGt+gB7L
zU69MgiuStkQ5EOfoKkrBsO9DTh66aJvnwstCQ91quKVAgdEOBbuRyh6RE079p4UOu3A4n0Gy3wA
DSvhBsYJTpDd3ldd6dwsBteQl74CYeDtdn9UctzNa6L7wPDuQRlv0nknaIUsFHx9gU5O7FzOa5T6
4FMZFG9Q/AOJjyhRHuWvnJJSxcHtpBzJBjkD5yui5OEUvSORhYMTtKTV4ncsRLPmA9KGshLrDqbk
oTgd2l1gbuKB8rrdKY8iwxI2n01qDOUJZRsKHkI4+JE0rDZeRwLFkEAbonuNjQbnNgyr8Qpt7jAA
X3+Pe+jH3brumrizda0nOy6ZYM9MxQHaeH6pWjGQH/zVZLqSBFmKawSjEJFMyvtJDC3WNfPf0OwD
9rSSnZPNnlNh7Y41PDrCG6iAgiaZMkMVGlbgSYsF0nClxcB7FeX7bo2IrGK2pn328yN+Jh254jyP
fOVuSpPb5kRhbAPfWkVd6SdejazW60A1rI/2Cx8PDteqFrd4PWcQi5xRrl7dNNLgNTNMpAkSFXpB
nqUaYw6B4m==