<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmGGZSW3iNNlsjqOwzIs1dXgOQ45w4dB6hcuzjex/jlpDgIyL3uwdk+6EOsg+iAXrHz3q/JU
m9G/PhatioCZSmJZPV9UK8K1FPYtDzFGL9JSFW7CBhKvQt4ESyuhI0prYkuMsnUQSJCkbWN1ObD2
6Qt/kF2bddVk8VMgQuxScbqgmeCRjDmJNSd22Ufwtmiijilcs4jy2ia/r8PR76V8Jp5JG2DwX289
7iyjk3tGwgRs1abJpaV8DMNAoesMhHU9mLrjHN4kOM5PifqpQfusWHk/dgnexuOHiHd0ur7lM8zd
zEOkFYHlAi+htqO4Rxh0EzFH6HB8ihoZcm3yaQv9y8/ixMGOjRPxpS1N/x/yV+7vWIAFmOKQq29s
MqKlGbYvU5b0ZimhmFyMLp0dnQRHrjCA5eceRM3FMeOh6l5jxv2cFLXoXGVgb81A55UB8KR0tqLE
mgnjzU8zpwm28zOXjAhngjIREu/alWZOVYeM0++fNtfLHmCvPUyFb37sLd1I1fLGEVozsra2ndzX
s07t3llWY/di94JkjU9ECsjpGPGtqorADJS+uCnB7aoNaIz9BqdzqiMAQRBK/DWc/eS4V6R4azgk
NO83zsR1kU4ZSijjqddRSjcM9N6qBfBm7V9ooCqzSQ6xdN1pmwTVs94Nrxo6AImQ+Gw78MSBZsQe
hmY/tMQdqapGv97baaV5Y9rYphIbZHRIv7eV3ikSaDjuCWKT8u6mgvUn9g+Hj9df3mM/p0Z0FceT
8Muzmt7Bj7lL0dIPlQ4BZKtRdC8Xfm6tUmLJyjEHqurtgdCqgv2AO8j6GtD5eiGWizm8cj6/9Uty
tOdbqxz8dvU/4wI4JxYaSZ7i6qetnz5nf3QEPXrBJTKzKsW8eOssHQXVZ1R82B1A56oq341B0YDe
DM6ytCJyUndPmNpyLXpphwfugQF4thiwqEL2spq6tmf+Jl4T0+qK+Ci7ue1GFrm9HVqbk0QbrPno
EstO6lXUVTuZPvC5MkN5NKHtVVtDXTf8WsbmWBlyaUVEJ9YnEhNtVCscnbtg9Jjw7Q+2RIcZsvbh
hseGsM0E7kVIYsAUPOQUSoN1cfsGM0TcjHiNJaq7iS6uLIaD0Z/aavNvp2AjKEx7Fng3xLXqpjpH
kv3+XkF2RLugSUt4EvzMEU941b8KP4oLbDEpHGTmXz40t1YUZgA9NCYUigg7+tHh3CfWcBd05V0m
6wHP4mHgsaGfs8o2EMb7KMYUwVm5zKSiqwWLfqlBNNUIoNU0bf5rsWwRItW4o8SbBGVpvRmifbEb
RU4eQ5hGcUpBI1XCej6JypRxEtOTNMsXvkeHqhkEoKotOR7ClwOE6SjLhl8oApgXt5FTkhT5HZ3T
C8C5ngEwKS0TifN4UDWPdBDGrS+lYxodsnEPuXk8Da3nPyF7blT+hapSvQbf9bQwdK6laReFyUpz
gFLU6B5l9ybKSbs/f0Skj//GVkB4J/33CsvEQjc5j5OtORfrKVM0/riSRGcQHQU81UDmgUquIs6a
pnGl3JhvNf0ZbCMuaiowIv7V6+7V+DNrQJ6MfBqbEFwmHsosHxPGAd9PBmHwUfM2Lb2rGEFWXO2x
8H9VgjWenMYVElBDvEw+gcPGssoYsYd1jEoJFyuzqNlHqySdO7Qjpif1g02G8IUV2V8HTYLGqOX2
DX8704/xpY5cCsg1w88KVIfpIuflOXOBcNOi6zQ5Yj8v2mG84BTmPYA9V0sBJDhV86yTRcqbQASz
kEhhE9nzpvn5wFs5dFhZufhWIpV2DkhHYnFGC/qL0dRPlEaQ/LQPEZdG7N4cqdRRGVETGFDvnhQb
Iopn6P1ubuaCt9BLFZ0Eu4KKfOe0P8ipCfp5Mdhh1SPTyMi75k8acn0WpYdvKXZJICkpPjcGceau
DKF3zlMGplXsYWJNq0xE+MfXhLbCHpCLBzQLmu+/k7uYHm6H2WeiMpct8fz38DfIgYkYE9ByB3Mn
0hX83Vo7nnZX8b3vpTQmb1z1Azf1Zvnb4T8Z7L59J3ruCSN/nAgFBIMsMwqRPYa/W15u/k6LDkmH
Dn6Ju0LZLdZicBCY+/E60cv6Lwvkl4XOEYyLhF9YBAeGjYsVGglZGP16CnPSodQtZbhuHuq4wNoj
CdcWZVyPU3+SI+UdeuxuZ4CMtKsietEb6PSYBr8Fh7Jo4jL9bVLlAYA6m91Dxckg3FL6OWD3cHyl
kAzzhEUjf5wBxxBJ+zO6oM+vko6Q0KlXPML3zkTmgrose4fOmV3dgFLfMPVzbgyvStBd9QsbYKAb
4jNQRoRK4qDhFp0cPSUcttdjaydVnWYlzHilj9axQgjHe9wuaRpeTHtMN70Qirs9EGnGSDh7H2hq
UQj7rqqEU2rKPoT+pDUkOzd5M/7eL7t0aKw3MA3JrEZQExnpGuckKoyQfixdOUXjq5CwQM9B88G6
p5bl6xH3THWexQT7dyxKIy8eLTNbTt1bZ61qNTJsPe8dVbBm/LKcVrzqQ2I3KOVeNsf7EAocvxfx
BYUq9rIFB0FjSi/Kost94uhJfE71o5Xdh6QqHXIvQAVfZvG4K7NIR3APifhlDYZ8YHbxYLjBxlB2
HyevO/Ra9+jcPGVN0ah1qO3OUZxVb901MUwxQRB0HWA3cGJGzLw493HcJWG+1AEcLknRE6ZWKcHX
8h6bx/J94dZ2MseU+40JLAsRxrcXqTWB3rzGBAOe4hw+tw0RxXi4R3EG+3CBIqYGuKnv/1+Z+sCb
ElUVNOFK82VMBwvrv47HHmuHu/ncyP+49E+Sc0CZRNs/CSwdK4eOYlnBJd54Mv7ceCDqpiD1bnNU
Mp+eph5YoG==