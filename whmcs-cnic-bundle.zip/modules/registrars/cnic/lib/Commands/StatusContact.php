<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+IC3vWzNVJVE46QkwG3e40TTDNLY3rUBkDPHW4LgtpLnj70K4fnI556TZFOxMmnGYOCmfiA
IfTP1+HHz0CS2b4wFwyrgwYzCHlXzcaDp6DskoO7ltndehDKhYAjsM8/0SDPaIrm2Q4aTbeatC1k
w3kIjphAMHd0XYOEe1xIWJQeiXW4YHTi0SQGOnEWmYUKSbEDdudvtjSoi9nVaW2axqPJ9bb6Ro5r
Mfxu/Rfgsd5f4vvbmlKEgzY7IFgUb+fxCPaU2CytrYTFH2WdZHMqlWIbhYUP8s4r/mu6H4FA3N0x
Pu6UA5SLc6x4Uq/zvwyHIzU2CYDnNm9J24NQb+9PwLmvzhX82WguH17NcqyEEJFVFwfJ5jMtJOoH
4om5XES42dyFUQjdNT+Nt8CeEdK3IBsM5Atcr9JAznNKoZSV/oWbZKWzhByRkO1mFpV5L7xAcXTY
wH3/DqrJVel6SF0i89aOfRvT8dLoxeJfG/ft5iZCx/6tM/pu0cdlUdu7jT5IwNf1ACXI8+YlP9KX
gaufG7oP5eHVV38TIbGjfE1GAu3ak3jE4QMJ5CHr9WKrSUfvLKTJXk8jPEXcnmmUxS3r74SpENdn
KxIDs2mete+Cn+Bi/mSpil5hd16OE9N2nYPBwyu5hxKBoT7WLcjmprMtM/MeD+dyl010+4kiFGxb
ApYB83Zin8UFCyvMW4jNWwMtR/RJRoK5HDzWKW61ZLv+d/ylxsp1p8frXxr8HssctTr8k9QPdFNg
su4BMfiDm2pJqcEP3C6gDMHtPycMTzk7vIvBv5uGGvObBPDa+rZxG1OHaXVEfOT4c3ZeBfANiOF0
QvgKqxMr1JAPBaL6QBgXuLag58tv1GTAk5lDcLeNBBw6WZKeWZW9pCsKav9lKbbbPAuZTdBSFwNP
9+zduJf+n0ElV3/EPKWC9wbGZ2NdJ6IlWKKa7pkjeOgt38WmhPkQ8GJ5NVZ79CNQMERpW5bruTBP
Qv51tuDXghf9RgCAOp5HK+dox+dVr1+xfYACAsYucgwHPJPL73lQ503ysVRkYqux7Dwiofp20ruX
sh1FccBACUWELzy6H7KoVOlTanBPxturPAK9jD02MCVQuhYEk6Qsx5Zwxop2Us9XIDFHaXACMOhU
59lusj1KehdBXyY3LY4EJf3Kb/pLLrHGlZIBT3sUZ4oxIj4zxS1lFr1a/2ReNm3ZRn3S5n2L5Jji
0Z4L4ZfR7pPd8Qg/KjXfiInZOhi7eebbqCaGEI6GS9M/HXWWQk/iKhWuTdCR4uFdYE4B1m+y41dt
MjsZNPmFbvlab5y4Cqmm8LZW7hV/RC9XY7YlaJkXzhvUt6MmPqTasEm4HYp/Yhl3UFyM8/3mwNQr
pmE++yifygXWy4FzI8gEAm7qRdQ8JRFRi4TbQyYlB7bC25Cx83zZ5tb0nOHk/bA/02ROsSZPbSF2
MREUaTl49tuL3iFP07DVnnLsk6OTZQpc9eqFusdpsJstnhbEnlYk9VfgyFtZWEKpiC4EW/3Pd61b
RDhAi/s97ndrfe3fWJAAgrvtgejxd8jFIJIiMSZXtUgn0vf3a1Q4JkvPqW8bhs65LREdEpbePy8r
iPEExCBFbljQscb025rDydszkVdjuu/a4dHKxPEl0Sf8+BNeOhibMSA3MlFdOOB9lh2eXZJckYIp
QZfeD2oX61D+LqRY8hyrRquqqV/LQWY0EIxLb8SpJDjiikBh6Q2isHqkNnYbFHXZph6kq3PthB+E
RDVxYKIyVj+CDQWrl8TNfw4zik5P1K6U5iJxCjqDED1bd0mrPE2FKafQCHhg7NB6WLdhhHPYzCLd
KmZbjeIPJ/sZZttHID6/YzUHeRWbPJTmHxc0qkyXMZx/AjOAXzi8oErP0LN4hWycGgiJfE+0XVIN
+H2eIEVonxwrtrEr3UzA5GDuYeXwKVwlEaAYkZCch1UcKzXxnGAWsFHlzWeJdS4RGURj6GIWUcp3
gxA5LuDVaaqkKpkm2NJfwca8eHtr0LTJdhT7ds4JT1zT0+EblI1Xq2kwqZhkNPeE2mDFudrWiipF
Tr9tLmDbW3XP96lHRn1zU6hwK/bufLvfylaBsiN+ZN3VNZfcULRpUHbedEmWwl1az2BXhmt9NRkI
XqLwf7yRsjY08GKHRdTsbKca8KknvVNUGeZAhRInxhamAXhW7MdOsd3mBOVpMGxv3rrESyRsIuV9
ddlRryiGv2/laLZAgqkbNEvrUiZ/MLdLPsowwrw5VON1H8FCTgQjBeg50sYav3zrxgZlbN7EzfSI
ISB2Yk20XY9CfDhRrbvn5yMl2yKi8Q1PL/hJ9n4YUfpy0/8TkFiH2eOM4iL4H/maeiSidPTzyGZh
N75hTjL7gxn8m4BejmGuvtDQpNNKGEjp1b9G0I//E6xj6Z6TukIR70QJNPjNoHXh2n2y4DFFK4Uc
bG+NW1qBGkefweNpUJj8/ZDEw0efSosFLCXxtJQcTSeFiCTmgQZxfL9Y4oj7JNR/vwp61ZMeYpYE
Ol+9IxgsPt0B8MuHsPAxo3Vhnn7TbMqI9Jv88AW+x3GYXkqWCMQqu/fmO76aUt2ITneH9bGA0sdc
YzWn8SA5sXTHAhlwA3v2t3EhM7pMRptd80V+6pLzuULzqCi3lUvPdOZd5Cm41XvMCMh0GuV2jTUT
kJ1pSlBAiDyYiDiotw3gVIciCnH/car1fwaDTbb0dMhBKDFAdW/wxKmbGin7zClDFq4Q7NR1pzOx
OKOuOHRJBJBK7MJdXgDHnz2x+F7UDEX6Hpyt1mgSJD6qtq0X3ceUBTb87ow1SLcGo1VDgbMvpjqb
gn46v1cAcT5avwYDmL7+jw+m98W=