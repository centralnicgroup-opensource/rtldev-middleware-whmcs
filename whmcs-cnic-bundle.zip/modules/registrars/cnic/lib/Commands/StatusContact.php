<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrB97QpDdkQ3Y0I8Zve21zyNRoqIA6wTEECGJJcLiahGIB0rJRptlCgI8yexc7XEzQYmT964
Zw2690nIuLsvLRwj5sVuMtAcTbRrYz9cAE9C8+ndZ2TDEC3yh9T8IuB6Hu4RTV2XqgsuQ+ffoQ/3
x2IK2Kr7CMoN/lh0GeXw9ltQNUh0pzb0PWw8L/reGpSgpMpj8g5dWDbCpx34lv3bOvf3Trwdtrmn
WQW8LZ+I9gCxWFb0RUd9TaReHo9OFraTX/ErgsiCXb1XgrDJWXmeyfws64fTAce4ME5kN9G/KpWA
65TPvoDlEV+TVptXOVZNtuEbNR/q67XF/bXEv4FZZnkcVYn+ZhkEOz0SU/l3hvyhG5wM/+MtnsdI
SzyLzrOj0N9rjVsX0mhJg3NCtVFw6gCvrVMfOOqRSKwzmV+11yH1vPKtEVhZx7cjsnvhmTlton89
wN/iWvXA8kxGiqo7h4NK5aQ/dZi52/7tQv3jv06FyJtM5RW3hHCvx7UA7Y9iq59lICiA0on+aCxp
fv93jsnfYNWk4D/Hyr0NG4sTD80HuiYlSqc8yhccop0lo9tS9QFiAzsHswBtJLBa+RaZ0kbx1f6E
dcbFJuqf8860SGWAYwczHkvirwVivogXm85C5FfDAGtHE6Aj6wFeRwAlYGn1TI80ujT/xVvPZTdt
5yhEy2H8Gadt5cUfbuQ2y6fs2bOzS6AWMd++JHxl1y5QTl5VXfygu2FkTR0zBmfAUGB31UX05ad4
/P5MgGKOKsEImzIrdFTTLFdssyqZuKfnAjJ+K3OFFhEorgZbr8NqGyd9MAj6KpPS+yn36+mGletF
rmrni8Ozmat5Y3tepUcdItc3aNJw56Z1cHZR0TvOyLUFon1RYKq2ZtPFdUEGu9A74H2xPUeMEIGM
r2hd3MD8TQwpWrfjh49znKoyZo340G7v2u1/ZSFSiNK34hqf4kNHaqJebigWBhRbi/Qzqf25LkPS
JRDVMEjnc2seEF68093ASp4us6x6ccf2LdyoyPAQE/9wADzRzZjTTGOFDf1LFchWkcoi2D1f9knB
tDndsiMIV1Joa/me9Hw43pCd3e/q/1NgTeI6AjkXZWgozDP1A6hEbsOLz8pzZTMERzA85rYdxb9D
fIeGtvfKuoH4KWPq0m2TgJIh+bZOAhlgE9ymLbbqhECkw1P6iN86n1BAlDHY1t4QEFnnCwXyhVuE
XWi+/m14GVrR66ovv9Yhogw4cf65V1/yfH3eyBJAymyCzfRbL7lHHIM6Fb5/ux+7e9rUn4DOjkXl
whHRCritQQgOXg6hX/cSi13oirezhO9b0Hq6n/VPpnOpI8DrXcwxuNCsDwpETH0dX90jP5Q7Rfm6
YI+dI2qYX58AYEomPpdpHCvkCygRKG7ES/azbAh17aOSDZCk55If22YBf1DtvJci5G1d7qb4rY0Z
/p5pl06B35WYxmYVVh4YbwSjoQamucvZpbCusI2/vi9OLnj5Z+2DhXejZSPaeffYSSnpghD6bJ+b
7IBziSzoQZWsiWsI9ijYruBgj7ULdx7PRr9m19Vscer0RDSoL59v45mcDj8ooxN+GDJg2EhfDGx+
mX0odnu0/uiZ4jQGisfOrGoeHPDT9YUm4PzY5abRUZMydIIJr+TZb84i+cCEbZzFnmG1tqlNiih7
3nP82N2tfyp61gHanbNc9F/Ao8D/wOvnQ5+m/2GeyjCNDa9fvRn8Cxu4q87MN/a5WVQ4xZBX0uyZ
c3EXnZ+R34MwTtuBKuImAH3U7oByLQ0G6TjyNrPFzeKMYN0snNNistmfXKR0wBudvx+yGi5CtPdH
GoODnZhjeZPIWDvIQB8b/9uz5hqFbBgD+XePtRI0RyrKHGJK0Ug1sdJQoBXtwzysGY7cNl8+VIG8
/O0Pb7nD0qSptx5y/v1a+Ec44H6hfZKmf23sXEmKBhDyU1iUY0CUolW8O4YKJJ8wOPNfDYUSZZKX
9EsddK+pudWWpiwArZu5vwW4aitB1n3HSmGG0sytUQ6/H7Mwowpum5V8SS41MTZwtXHb7RNm4dEu
I0fU2x+GG/+JbPBpZvbFuCzjjfDwC339mQiToYFYYRAPbmK7QzxEAdCP0yzEl+ISj7llC017Iuhy
t0kRJTw2IpZS3HMfxMxbKDQjE3fbXyZEoPOC5zRMix2BfhERL2U1H7vMH4DEGHcK+QdqPOz7t/OS
RyUXXKHIVZ1a4m4ajC3L+oFXr6ydc6VM5cj8t/m70l17zJsCQ3NplM5PsjCeRFsUvAkMB579GxYy
6aiRjAdr6hf2GA/2w08e0N9+jdbhaZPmnw6GCtoHmyksxU/49LL8mcviJzNpch0q3T8zbQnIskm6
dtqxZT8hvlQFbzBdcxHA5BcV/omtd1hUv/uTtI4mIXuY+aCt7dZ0zm6rYMfw6TxxQyg8jius8uAP
xi0LgyqoKIBw5fTyOE2Gn7PsunZ/3sK1HYNdr3ExMa8MhO1Mgt3Fe6M+VEZeYqTq2Bzf05NBvZ5j
Dc1K3+Y7Yt0/G7IFqvo64gx8LFaSuKKrZq18UX8MCou29JULCtpGR7u74G4HWSCwu+7EPQNPedJg
TBmb0QitN+Km4Uu2Y70cYI6EG3RUomlZ/zAWpW9TRgfTnNvPpAqG23/MldD628ocWh3NzeTCHvHJ
M0hSjxbQV82LKE2L1x6Rku2pRmdiEmPo684F1rUTVTmDHBFrqazQc11F+8JlT2NXbjrqBezTge5L
AfFpUNUP6gsncGWpZo6VMIIN4Xy0kIs0QSCRbtmAyALi8oHsQgZWJjnTDui73Lpg3/4QaNRYsWLL
/wKM7496i3YY/FO=