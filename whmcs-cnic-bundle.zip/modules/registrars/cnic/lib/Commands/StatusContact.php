<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmYkxdy8FzDmrMDxNANPU3giY3r3EzThivIuW+WLYGMvUPBMo8lnVPKNj0aFVO754Bw6CeI0
QMtYHEgidyl8sucX0wdeIMvItAO6LDqAqJbXCHXP9WXa++ByLP/5qiRY6CTxAjrJs0+sO742GqkJ
BYSukxPpUYS7s/iY2s8zcVmdgnGgbIzSA48lraDChSl/j6daOqQRFxqqg13eQp3rXo2ak1DyAvDO
7fhduoxoC7RzVKXxYbVR+48sc4B1tl2IiT76KFHTFJwo43LofB0Qo/2Mmx5ezjvHcufSdy9lHOCD
rYSFEKEqhDt2qMt6P+ovgyJegD7aiPPpqGQX8MNB5RRa3duk9sJwHb7VkKJg7zobsrVWNGbVbtNA
y7K+Bu+WLcXy5fXQCXNCiGH7Fz9SA4StoHu8TomSo9ZAevLW2Lx+4EKTwxc7gb/K76918t1jRwri
oHPBNSXFqQolhSvos0G+Dw/yrrW+M6JE18bprHVG4qXF1VBvgJsvH/pbdchL6gGBG+FslrKUWPQy
2boQr2iWkfTxvquWUtPLjuq3kRC+a2DN+/5G8456RyW0UvwgBmZPbRenBoU+bWkhXwEZU7le/PVo
/XP/RLwi/7fSWk9XfHTEYGkSeyyXRDiPFxjWYcyPR6qor4azoZ5XRqjbkcgmIaeO4OBdU5NPxIHW
oLx2lT9L8eI6cltzhLK4NHkLiZgo+7P/a1LXEIQMmi9Yb32C3B1zOWw0UDU2xYQrwuQ1EMmB/oEb
xwZNVYq8fhljbKVvqRTVgVWdPx2Fvv4C09s+ewR5QtXKkOnNlZUEyJXfntzu0OH4HltfwC+XRybZ
7kP5kAzGwjhKPxNd4klHCY3q/EgUSkHUQMwuohEuVM3NBjW72D/UZhmu8FJlwXt1PttPRrQJ7SEe
xvTcyr3j1v/JhGOTmTn2e9taSa/UzYwwpzT8TH8AVGTejhgV2j7UqTg+BzBG2I5Gb0MPdD6Qxqzv
fvbYv92je1Ut04ljPivyaVohWwDmRcs9MPEgAEyw+HPSwjUT7g67US+9gTx3YvSnH45E4P7kY1iR
eL094IJt8hhrB/1u98W6jnzsRX9pfmOvjDeQsBNGNtVo3s86ztArsr9AavjYEa+XT4mbLTgvh33E
9cxsDb2+DbFQ7rbOfskgAX9FL9Nf2yDUZEmSZ4H19NXZwLyfHcVpxv4gyTK4BnwjtzBaaZqZMhRg
ubP3KewvuH257Sof5zy+tDJ4nv0a0EObEO53PhX+di879TnAEoKf3WpRIra6Mxe3n8RD9J0Syc9c
+Wg1ccqB5HVZo04vcH/UcY8mXJNFCz2VmqZKRlBR3fBl1mMNtqejPWBNhIrDPD2ITkRLempodLes
EfO//H8KvV+COxqmz+6uOzlug1k9+eoME537/eN4HEVwsxpY8BIMFOMCyGCpf6Z4qVqaf4Ys74EN
QTcITiMaXywJ6smjt9/DlFsZzp4mad676/yDYRsOkgoDJJDRQGrpFzhOPyQyNWSUoFCsRnCTI0WS
77gNwZDVZMw2BXKHH1vjgGP631ZDLrROPy1CZdSnwoBVAFYCYgfi8qAwuJymcLjp46ptGRMj5Ytu
WE7Qjf9HCTfoudIfNvDaU1ifoSwBLtdJa9NQ89ilfD+uR6J9qN5hP2c9HfwOLcuPkjxU5Xp9xa1T
e55EKrjBN9/Als+7Uf4c+exBHmWY8nv6WsZs8dh/lR4SD4j+aZ0PSFcMXKuLzSRrgPM3AIA7X6F1
vCSk+vuAJ0vKzI4E7kGere6ig5tZYadN4fIhhya6orUqHlzdI/RkBsi4EPMXDofj5q5uWY2J5xuz
GNEkcCJ84tcZ21imOK4H/JOSIDcVP8t+tRzL2x+o+O45w21MFaLFQF+g1GQRKOcTog+wNGLFs97m
zN++Lu2Jxiqgb0exV3IBQ9eknp2VJ8qKO+a+VsoV5gYaY1qGXtIc8hSFU7RMkPTl7qOLal06FQZ+
mPmdH6BP0viCcaFfUHd+PTw1VfK7Qno4eUT6MQUY3e7pOb5I68pa3j7wZ5NsT20YD0kq4YiiNFP4
Kwo49MN+F+onMwIIspx59qz8X8hoe1jdVseWbPn3TOK75fV4axSfZzUu5HYoYvmH+ODQ2O8AmYZQ
+zfgr2zUp8WTHhi0EPtNyV4UgmXx9QH+WQlg6EYWL7KVuflbZNDFBjyby7Epv8TE7IqqouSEJ4im
c1QQjR36UtpWOpx0YAbzMTEy6cTF4jC98RLARKKPCTAX+kNbiLh1JWs+zX5HDqaULVkhqEU93i8r
LZrtarmUKian2aG66881jA8uVtnzLGWd9K9X4+zRDeH8NbTIBEQnLuX2bdSXoHd+gTtjeVzVVQNA
GtFOyzMXhM5kmLUMoPbMtIPSrVTwsH/loVF4furnLXvwJUHLyW5PDPvqsh3alVTNwdGBx5Yi5lZt
d39X0Gs70u7D9S3YysHY/Uxw41ta3Cl+CwVEt+qsw6GY3Qr7Pb3H9nRhG/T+gb/VeJdW5A4qchnV
QXAMR0gFUI2m168qmjXq5IlGkPYXgokMMeJufouq0THiOv3oKYOXZC2J3zkbMTy87RFpwugy4hRT
qgCpIYUwNQKdBFzqIo+H8i52/11fV6NUqk/XDT370UJv08RkwfQ33GevKWYedSyNJLkVK4r6x/GB
E5+vbvLb9/jlPJADs7EKYUsXLsXXNGfqSc5dJ4yID9ZUjYjAvZ2bOQzKmRE9YUNqr7SL5r6DG/Jt
xu2l/CWNeoRl9s4oqb+dHzICiek0ntAYsqXUc0OSPTheNcHjFPDL7//LBvtGPgjts2jshzr+vRHN
B1yNgQoiPwJFs0==