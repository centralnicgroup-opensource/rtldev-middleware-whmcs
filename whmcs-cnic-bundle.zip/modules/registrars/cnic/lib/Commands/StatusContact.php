<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzQtL3WH5wq/x7l16xnb5ad+DJ8S0OuIFjyCwW0E3hCTRYJbDxstbQiKyXXQr79QDt+WyD52
2H0jajq9YcfqbArQ/9A6sna525D8XILYVMEkN2DYa/lX86Pm+BXD1PY5VusdUKmmQ7qlLMKk9HPi
HhMVlIH/Izo8ZNsbhVgRjpISXw+a9mnGXoiNZL9lH0TwhvCpppNA0tYO6PoxpK7nJ5LGU1akgJEB
E5ui82oWG93KvW7z1r7fse90ERBNm4HjH9F3ot+mtKvibSCqdBikYzISoscNNqqKKiJw+Q8/SbQB
4VD74b9MCACu3wQzNgoICWVF3Imjn8BFFXufzadJL6DhNeM4jKZyc8O4Nw3a5rG9jweQdSJZKsxI
/IROfGi7SQR98oYuspxs/2bsexWRHrxBdRiiv5QOadubh9v74ytr2XTJETCTjNY7xtEafOw0RK8D
FOiOY0MkGBOnKY56QpRrM0qNmPwXCn5gYRahA67p54zdoGdWWTc3FIC2z7nPob3dt0FV6F3kOUTr
PoVHZ8FhqndgZcY9S3YgntdBJnFIw532bKk4NLbKvnPB4RY7O9/VkeiA62ApS3uo4DbjuQiRVLNc
FcHqwnm4nkwrXa8Xfks6yIiuzqwD+ERgCohhdxwFM4LIM6Ol/riDzqZuMR0FO6Kac7WH1ZNfhASu
oTTMZ7Gw7HtGwA/5Y1etiBa1BLJ3C/Ex5svMmMzghB6+gYyQwLeuwIz8iQymFVrqH83bntdY8Z8o
POzZQdK1LBs4pLJJ0oj6TMZOXPP6+ZxgkoLsIKFg1Yhwx9T/xx3xTzt8BUNxcU0+RseAGADlUkuL
EyD6f/PsGwKM/6j6dQRI8098MIijCTsIHC09JolE7bouinM5c4E99GQJD194Aoj4rtWnuznAWHbT
Km9WLH69gjnBsmhif2DLR6O3h7KJflWU3UMHa+0/TnFlEq8qxJ5GAZcaktyzk+HqhDM9j0bDhe0d
lyzrszPPZb//La1JtXjN+12RxUi/++TviBl3EbXIsq+mD+UeUDWtGHk+8Fkova7gCb1rKCqlAS/3
nbrhwtS0X7EXdqbXVlHMofHnLZIvn7657muhpyWKJ3itUebbU1LGudoPvvQvPs0viAb6zkvo/YSn
zCtkT1MiG/FgTj/KAMyA1zcGbMJ1WxmwmnRZoPKvQs2M5lmhxEV2ZYj7JbU8eqpWNVOj/9+8ia4v
W2PFIjITFWVrchEas3b63+SWNMTFod6drrrK26L5/3jsMK0aKqP1synGdqgJYJqb3XG5KL37e9+9
u7n2Zl9osQ5aU3JrBezGnP1Ev4G+S9/g+gNDqlQStVCNXSDiTIVxhq5Wr86S0MUbpiBtUNHGiSSd
DAUdJc62YuBrxwJb/kl54b3xMlYLwb/NnJQA2BZpqlbGqsFnaH0dp0mNe4B815q1pBeaDrFlML2n
GyZTlivyd9wbnhQ0qgOI2KoxBYQVOtAeUwaR47aD/dvwh8AmKyikrsmbHaWg229F3JOO/nAsWLe3
gEpousQSfcC5oMpSYYWQOkPQCDdcyBdkRT6ZSzDEWQdeMQuKJj4ezDCPDZNiS4xYmHQ5ZgY6XkDQ
Zoeb5K+VlXoh0Qxct0KEhU1guLik17d2ZJ21o69HV7ycsyQD5lN2b0bcCaRKwv+dXLyU5WzFgFlL
V7Jl0h4Ysl0YgS1g/s5owTEuIh0Zxm39naWeDftK2hNH1TnpAHXIoQrn6aA/vivxE1vOUvJ+Er7u
6+B87Us2vMMO01Qykm4OAlfWraQ3EpXV1lnJrL+ggVGVahrAQsq/r19DoPs8v125fKzMzkViJKTC
SQxnBQeBNzToy0mJXNum30G5VWwh1x93l01FECrehgBnRhWT1Z5x1/sdCzKB0vX/Og42YuRGLmzC
9PviOwOr3mhV8ODgM/lXuKQNA0vNV3T7yahkEN1oqIwL5Wnun6//bLchgvVrYus3N0IZDSMgW/Xt
+T9KFu+/SdH8VvLZtopKV9QO492Xiyp/YeMPcZ3uM3KRfILy9btH5bd/GhRQff0xOlEtE7XG68+r
jCeNRCLL+QGDl9z9NdKr8qz4cPBcRdIkP7Lu5t1AH3WibXTISB9hkiv6GoOTXdcBgaSfLHLFqbxF
jFopqHs3ZV5nMjisbcjlpV/Y0/7z+9znbTaZ/6rS0PkkGs+fNj2q2ybYH5G+9jVzqpIpMtqVLbxw
7z2QyzpipQTWK8xBLEPZ44yQk51hetZ/AgM+y+5yD4C2ZktWeeohW8Q8iWhkdVa9czZfTNKl3yoN
JMX6yfwIWX1Gd2ktlupaXufj7UJH4u55G9iExJq/vQCS//3hrx7SsuLkDn54MerX0b/hY3LjCtZs
w+kGmY0ZNjNIeFWZCV+c0Ybvvhv4NtcjRE2m+PiUhCmI8VYIBU7qOsepk+8O49995z9i5OzM1+/1
37174jBeYQsXyQaeMqItZAAvx3f0PkfqgsRUyzAmgmxo3unCjKB7UlKXrs5myKcD8ujyBtOhRhC5
LmNG9XuNXpF+z1zr63xb5cnyZbQcFeDeClIy9URkfnS+vtHq0dVl6KfyKHxP5qUASJU5rBLEQSA7
AubWRDC6VZVRm2dE0JFBdBUrTthZsC4J9lucxpLP5/ZzEsOnjEJFBq760OgAulKWl5i6Er3ZdfKY
BKq/qG5umZ36S05NJCghk5p9RJk4i8Z6UXp5mxTZ4kcH9RFe8/hntKOgBHpTsmYo6pRYLxFmiN4M
AW7GM9q2Mi/84Tq7xFnjwGzEChI50rxIgaECjXZzcxYJaMek