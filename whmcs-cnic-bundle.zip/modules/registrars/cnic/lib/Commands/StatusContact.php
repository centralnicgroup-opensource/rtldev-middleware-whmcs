<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxvMo2pEz303bvfT3nGHwEEX9jkM6qNDz/Q7dC8S2taIChybhfqhsqzvQ2TL7S3cJLw7RDzt
Xfc/vvaovdmc3qPQObpCUKtVfy1stT5ZyjVM9/Rw5LDmrQ2A97Gd+hVOOSLFRJX7irZFIWWlslYx
JY8rMimjva6OgYlBHGNeunGdr5mtuftaIPPBHv6wxB6aaBD5GV95rG9f6glQLXj2frxfW32mMUA6
6qNfVX2BnN0hZhk78YiZkZ3VGrRxAKWEG0vOp+qj6uMVxw+O+s6nlLSJ2XwTP+MgaX7kMQlhyor8
8H38UV+9KViAm6LsUsEypy/fUS3rc9/a34J/YhnBUdlB6afOjpZQgQwP2BT5VHgqC9hj+tscEs5B
nhoxV3bIpN/p4iOBK4n3sA+iR91EwXWdlCpDB9g9WtI4sBSWv91d6ZH/sNiOwHe5Srxxfg1n+/wv
pMGAM29kZ79oZpbycIWoWx4DbNphFlXZPxSjuwMdVr6Y9c51zRyYxJkM3VW+q2NxMbitHPxmjfq8
Z7qoZ4xVnlmCNdXxxDed249KdsCJgA9hFTpP4xn4bzSFGzH6FeDMevmVUGLDh01IZE9vtBcj1cAq
lDOVGKhfLeO8UGDrxl4PUc54k9wTV17kauBQ1DzUxnv4EFOMABtZhawFXX9+oGiRzfpBLwChH6KW
Itv250VBufwGBKIn8dTieC0DBUoloLv8Ia4mqBHZAtzMXFqKnflZrkYBMaphH17lVM0QgTYsZ3FI
ElrYGpX1uLYpLHOodBuK+ZqJFg/pKY9N/ded7DUOZA4rPxjdPoCbv8zv5Dq46eHIpNW9qQ93VF5Q
UlMd0GowCIv16zQix5khXGW7gHb6obhljXlrOPLwWBsVaQAATe35AHPDkaQ56vENRHQSgEp1ADnM
Ajg9SvmCWAVh5Ms4+BZ515DFMrjKoXXsvyWG5k9CqZ3TwAQ7IG+mDUZauOK20zW/ldg1pAxPM7rz
tvZCSBd3S6l/L2JaunO/Z7XbuuXucw1Z2j5f0c4Dm+2z93VWU54GVPwkcUfNK5dQp0BURLohUf9E
sIkAIWOU4Yv0TUiIe3aG2n/mlhGvJ3XDg8y3Q87AGEnZORYD+BbUY6MGEJdYgK6EWeFSlZ7Ada62
/PY5rbeTs6FiSV+OqBqXi+89igO6MBgP/Xrees0rJ1tvWt7b/XADyKhrgacrtqwk3hzfxMORrLix
vRi710fUiv/RgYlYbq0B3GZhMyb2aqvVe/gTHTv44pR+JIu7GR+CjjvIxVUUckuSfKUkA5FN6Vne
gufj/pgON6ECGOeh4ZbRKsQ1kGhqTl99GT9qgKhQ8UZaSPHuGwmtbNRlDkTgSnPDKV5Xn8Oh0GY2
FUy9VN5O1F8driM/ik79D/TznrsAVLGQvbpyyYSClEqzu5gzqcxq9NMMMkjW0yOio5a98i8iiXXH
uqMeCIJ5c8AdGES7zmjsj81ybL1rW0NYoE7NgaUuu8hpDW33XEz9O0gZ4aEG0pSL+KHFqSsnjsVZ
dRUFqGeaWvV7RQfrEMr7M4PZRJdzVfY88Bhmxst9SWAAGrUMWLHpWxLQKjLVpM08+JPY8BGS3tXj
f1W9zGSs2fsKoUwnz70OSDqEAzrKpF8N3CP+HmF2bkROj4CNa7o08QkBObY02Vs1mGsVYgM4fGGu
HKT+fo0NhCo1NVSnJmkXaVPd/f2+1eM2sjalZRJWPbLt3XGV/9/hfqpdhjRu1dDo29vUNaPKFU8B
Q1sWrshdOd5PvAP/Qk0wwB1zRg4eJj6SISMccgU1YPoS3jcHi3ekzjQAF/pWRNR+M6wWJ3BZsldv
cjewoKq86bHBDFyie21JeU9J9FylyvokIpcB6vhi4u3TpBmcbSZWOyi42g8bPZIu5zABiKAwtqXO
H9ZjvX4jkflgKyPmjEBtJtG4sWiDXXzh0Je11JvavRnTd/JWEEUxDmoYpIgdD+0FrHFLuAwJqOxE
2QBeCcsKkPU9Gg8vbtsroxVBVYSGkPVsXyzcSSqOzoccmdZqSIkGFq6JV0ghVXl/6rQqn6yRk8Ls
S9G6Ly131gkyD4ejWPVDzW2n6y7sNhTm1PEdX1+mVozOb0r9Zwlms/LuK75Xb8O1xPLIEPB1PomT
Ja/LGIpOKCTHiRDnBpQLmAzRnx9tlbsC5Tck7zket5OS4+neiVOU0nhZGea/3eKlelwEX49MNILF
ruH81pTEL8LJw576RourWE3bt668/7H6jGXbed4gUKnzRy4wtUYFY3ARN6dd8yNhAETepZqNC+db
hF9Or16HsGZ6ObOgRoJ7N7JSWbFjPQikMUunrRUBOQx7iGYac3vNoY22FwYxq+ClcYk7BA945EIx
XVtX8o8wVLMxsU8h7U1F7eeXPnqvsfMatUBEbKzBldvsXGWtAbLmnv6BQZEPl2+6VeV0NU7vzI72
HnMStcB7JUwHToJXBLTapvsntxyJkBysp9o4BlTJeTa4hr+lrikRyfiYKEGf4tjQCYJ2dXN8TIAG
1IvXhv0uPqWauPvrCdkHRxyvvqVCIS+M0WlV9S5pYxlGB77Mu7iLJV/sp0vt7plp+l0/bXMG+TWA
PauU+VYEeLO7nzsMCBpVMDriJlqR9FYpw+zvpG98abbQln8Snb2t31x8qmlVWa45n+gxicMzyCgW
b8naCobq+qJv4hdGmYZFYMD0fITBr/4YRW/4pyXNfl6M4WjMD7dTOADQwl3F9cH3bbiDDmdSayf6
V7QaQ3Im1Z+dhT/BdW/NviwZJQMg5yicPsuNK5VePbyLd2CsTf8amyz7jMJMO5cjeZEdPA8wCG==