<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnhaYN8vPN95n2aSKJtU52Og+FAmeMTvei1CRF98UpWSbylX1eWvLAcRfktMEcC9gFom27A1
I+xWFltMAa3bBP/dI6+nJEgTa91p6EVUb9QYQfgS2DptI5qUkKvacEEF8bW5HAIr7UipgOQZB0AU
/UIr5Z3n5UFq0GY/9sTJsh43TJVgE9gVQKbAvui2V6ZORtYsY4bp3lkDm7OOy0kAULn9IQvPtwnl
V8uh2oxX5ttx95CV2oKD6UuNS2y0BpVp8Y8VE/dYxZxcDrKHnBWZAa8J2NHJAvvYHN/7HVIeNyV9
ZNmzXSXs/+DIczzcz3c+5xoaz0j0tOM7ViowRMHQ2HFXwe9sCLLUO3VK2rtrv/u7faVKSAELR46X
NnG1viaKOZIsfF34aGI1AHRUB2b88neA2AaP3zJqlWqWcsVrzkJ1fii6+UTc4VFjHLEZpJHVhMtq
fPEbewpiMAYsf1C2nSb3xiZbluhFvZ6nYgNlLLrehy7R3wz2/gsmDDoW+Spl5iaKN6jqz6S7N7jm
v4/lXe13RZ5SfuKIPmhz3CyF3EYeUhkerqhkeRwdGK2MaLQoDQqeOAiRG0/qJ6lPqe7h1IVZskCj
iszZ8/pyulakHzT6OYjdppE8sXY4aPV3e67LSyr2EOoJa7RYLUIZ1ET2nXusQ9AeiPyug0HvCBv8
pfFe853OEfQpmdizMxYu6b/K6sDqi6xC8g2eoHChBQVh04+jnFA2G4C2ssdV9hTUv/m7Ghn11f94
bIHbLSK8idt4tfylBkr+bvV5sujH3XqHXbdpOz1egYCviVjWQxm9A6isvXydnRJnIRKEgjCCnort
W3OIXvEKn08UdTXGI5wcvUuXJd+v9CqmgqJ6ettfsX/hAetq7gnz94qWva+wiXgYv4YruvQY8No3
hUSonHW7W0+V7+5kExlBaoUyzI7Iw00eMf6FzIuWSy4XfPOt81nQwde/lWftTgxHtWRgGbeH73M5
W6HvYOSK5TFYI7OfwgL7IY+5EfyoyJ8GV1TQFOib6ZdCU3NJFGXamldU37q5OObPaOoXLfiNO5tL
ep1qxkdhYkVnyOSPcu8/nM5j5ARc3BxBHtgTj8XKV+1fbuHegwcbgvgqxYZ0z6E0HjalOSz/JxF5
qnX5gPW8s+FfGeNsDliZYB1EY2bYrHVU/ZhVHz0npic15fVd6L5k5KCESo12Vg1uBxFv/yqQ4uS9
rWuTlswvttPLH3igs0Bn7BjFfO1jKjpPfPgslTgqci2cJ0KIZleQ9WAxTdGSJKKAaVcqiQqBRpEP
G6ZtZRD7szp1Dztt2Iphe2GvJHH9+OIRIxCWC0eKpEgUe3FY+olktbSq/tF5Pb9+CyI6rGmFxXxS
br3h1i/pBXYC68l7LFBQaBivqLz+bk0hSwKgQHT9/37rdiKMbplvXFcM7FY5fZqgIktqACAvP+Gw
xz8D9gQ7ozAWqxqsQZaL30NWnYGM6zBhhg0sI/RUGc+apMEiPFIKvxjyjCfaJBThSC33Rj2R5Rvs
QpAiZwwb3re4VSJL5M8r76CZxWb0fKuQteirIr7GAzQEIVqY9K79dbGR5a/5VgSOn1r0dCVHsA36
4AzBnNMl8FALBGP6l0lUkjHYvNHnNLQ/jb62wgm8Tfrqeu9hCz/DoJdb7HXAXeM+BEPHTLJo3GLA
zeTH/wtDXigP6pFms7x/D4jMSsz4c4ciagr35IJcUbNfWnchuf8lCAoUNkVsJ23jQxekRE5FqgSz
qkelEnvb9OvNr9K8Tm5x/fmrAtCDaQD9r/aV6BQfQOd/43RaR9EpSJk6Co3zxQSV+5gPhhm3RDUP
LDXKibxTFoyRlhKB7j+21mzui+hqbGqTwkvfGoROrP/JJmgMLKOs3s/20UrIN7rPOtih3Kx7ttLH
+PXdeI0TPLvIIUuTVP3a4HSFtLlI/wLE7G7kj9Ok4fMWrZS0kFT2XqniDWboI+gnMFpvwJWa9tYX
eiiFff6tiUKmCedWq38erVCHdhcoM6WgELJsgR/pJrUjQadczFrevHzELoMEfrx3KKrUJAFKn02K
7esMtVZESn7c4nBHCEP+hIml2YHXELL6bt8IJe+Ca9m8QQcBqnFb5wM33CthQS1liN1gp8/cp7+O
gSHUfLXnr8LHwe97KAfcrjWQ9pKO/KlowxaRa/gorBqPr4vlXzKq4oMeKVWrC1xmHv90GH9kr0sh
YC3QvkJs1dDwQTjxD8U1Ht1tPBMqKh4LdqOikTCHthhH0A9kZkWRLbILD3NBBwRuUKfZsJBIopKt
FK9WWcPhvu3qPNPzGEtTNgGVUP5BMkLyAmazCOVefhJNxMul8wPREqlvTsaWYckBuAEJ3/JiDNhV
436drCMmcxbpcNoZOEqnjOiRME7Pk+46oHyRy/hB/15NwUO+6cdz5g0ZgvvHCxN6OAl45WlgjF56
v5pLD5nWaEjfVVOvUK81hDcFZAZHEBzG3xZGVmlt6BQUfMyGEq5dfyTOgaVoagub/Xv2NnE3nxEc
X0b81zyixxZsVJinMGG+WHtysP8+dYzBwCxnSZdL7kuZrCn7MlPDTNTCopqwLd2AppIgEG3rOEYS
Eg6+/pGgFOZ/oTWgcJY1WEqfcTl/W0vYc17xAORtLBTpeiNdVJQ10SHjlI07XdXvbxDNhYKrkeO6
M3MXRgIV7/YRwlyEsmbvOG9M1MNSkCfoEf8Wb0A/JdMSiQTNX5m9yxerS2M1TuzgT/9D7HmWWHyx
bVQdI3szExLzmbAPEC/lnR8LMYOferBZttC+P1LEqNaL2kKwTruQo0Tc1qxqe2Yuw2M2EtFyo363
rz2b2QSwL0==