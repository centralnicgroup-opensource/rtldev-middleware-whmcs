<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoPjzOv//SsX1g5WhNccv0vXSHTDhV0YEAIuST8em4HVf4vCQut81INoq+Lfs5R9J+T3bO7Q
fU12svxUW2G6mk2zvXzn8bUFo4bMDLUDnBFTcuZnOVLX6UAvnISOV/Mld3yWYno4ooe4MbP2xtFk
PtI+3/a97OoFI0A/17Q+6Z+9zj8RHAoKOKXnIPRPuUH1W+3LDvXwo3KhS0bZOPpogy/BGRgcaDCN
SQw5F/4IvJcZ+hrBoyG8qFRIOrTU+pu6IUQTmbNL3Aaz1Aeez3//eS++raLjlAVkkhiPOB/JE138
vWTT/ubbk28mAPQEwwOdQfgC3pJ+wtPUZ7vqGtisrcFPtJvi1kZFbLgtgK+sXSDtOyjeaDvPHwmv
IO3LSxjBeclCBoHGe0kDQp1WbgBuNnv5UNB3hts28r/a8Q0GJSzLI5phyOlQilAruMTRhZ2jz+ZH
yxjwLo2he34Epybnl/4NVQuVo86fhv9MDW5qgeGdwUGbBPXwkcXwovBFzBsBzT2OuMk4lr0wpwsy
VNrvvZ+RHqR3NQv9QC9Aqb+gvWieYmqYPjl8SvEWcHY/hhhKMuNoCOQoOmpBwi38u23MMeN7qDic
JKiZL6rxUQVpSOe/qORXorA1ZBLib+U/ICcyplMBYbMSmzacvZ/0ClwhOKiONqXNHhzqAE+o1I/U
2t5pygU4Bady9Qcz+MPhwNrhxj+y+ZyIByYeU7BewCUiTfKssP9RwQU2aLUaar2IwQ0rizJBphrg
6ZSVwq7x6FJ2jeDvOv/P17mkj96wC3EOmx3e6UjmcjGiUsbye5vk+1lId9rib0RZ0kc0YcWQMq1n
dclVuXIfV5YKfuC2DxBeHni6bP8xOd0elou6nrZMtat/j/bnkvdAYcad6RgfVK/0AhfiyiURkcQP
HTrudXWolNa0BFLHYWLC3EMeb5lbC3G3JhPFm8jMBedOFWlZ2QWd0Kgl/uHoLzJl2DOAb80T+H6v
wKP+3cIQ1H8EXJ2ZJ9G/LXDQLplKyBxi5xM5Zt3YJjpfqGbtk1zhvRVvcalDky9Yt0JYMYZkqBzR
3hnYZlkWi1/MbPN6KbTgTY+vioX4xvvHNQbNkmq7zkLIno+0jDumAtieHSAM2yPoTujCy9vSNY81
Ofy14XzU7TLcWr4voUZ/sJfFSzYUZC8JM6OEknBBh2KWEIrTz2rDVMlhbM6gntujBAp+Z0ilvrDV
GqdnE82fkXr3aPtnOiE3B/ZevQmfBXlK70l+lELOjOpWueK+bMIrnYRpP6DjIHBDqDjzhxald8sS
DSww3qCA3CYjN8LZUnmiqA2B4oCnmfh2kZFAav35KGckuXpZW0nm3bj44suwTaXlj9o4LcCudCV3
TGzR8JE4V3D2k2wfpO7rcPlFx+okDclHLx4rpmD6ho63kTrjKW+/E03XParzKjU1X+P+VDRWX/la
2gEk79Bxa6o0AbuwVdB3axdzaxC9g5KaltiKhXZqBS9hkxbC1PJUAgAnc/qvMFzSEq2t7+kpuVMn
Gns0eS02V4HQf6fzAhw99NjHdG7NdgBNEtrJp2Bss/cgrxj4hc99iWV1PR4XsTfiNz8UJqTH7RzW
VcG/KTyCjVKan5+hiEFJNUILS7Kacz03VcoYIUmtRBxQrFcW/WCzNWz3oSE/IneZkkIsGWOamGq2
7V6S2pHK+JVJdW/HIc6iM5bLQL078u2XED3GlP0oMVSd3YfiarQda55EhIeZKPBG4fZIIro8S31C
eJfn2hh1yEgysAcxG9SnO9H33PcTlTO4MqbNLbDmgYq4WMIn/lKmDmS3v0Rv0RuuyQrHujv3g66M
+ikvyy4q7jHvBjYBENLQcIUjH/lM20wQpTeTEMQXlZ2M4hHuM4s2mXtSraw0TAm+3/bYyTzNo904
dB/rIwCHt8k9gWdfbRBP7NEPp61fT0gkUSkgJbKvBlSxx50p1/pDsAZDimtgXpwRVmgyRaVu5680
7opkNA8R45ty9AGgmDQ6+l2iGoc9veWEetAmcSOPE6cTQhpgTDI9QhAoQW2cKfBn9PWcUFz0SzOU
BUHex990Uz8TdbI5ZR2JiA6gdYlpbT5SZLvy/FJHY81Vsd/HEH4cUNslSEnIdNbv9dWTCOSVheu3
V0WD2nM2S9AjjN/RTzyXHNRvvGeZzSjdEQtgll9YBbY/nxICY5A/mxxPriaUrrbadn5lKNEWG+6L
asGvzUDaXBfOy27KhCs6YjpGxJWUjLXFXv2HeGm87Bl3ISqPXFvuC5bs7HdmZJk/Ue/puI4H4E6s
OpDo+b3Aq+h2xY+ttuLFtATUT7xB+POG/LSlZkLOpUlm6BURRpSE/QX15FeXWvzrAfyHCfd/4HkC
VDLs9wMX0vMA7r2ua4nl+MusWZRBlT1rs4AufpAD2aGzNYlVrDGY2URBoPGgk/eD8A2jjocdr9/b
2PZ1Q9Wmge4xdX+SvZFSbHvVRYZRYG8BQPhDJCG9oawQiyglsFCbYbORfbeEgAoLc8G8UT6xAjIL
xfu7UXI+pwWp4hTWDRRpNlfaaTgBvCkpyg7gvZBhshxOVUar6Gw1nFcsmQyffEM5jF3nW1xyvprq
h41VHevfj6ar1Elo456sj08HdOdS7Fo9Z+RAvJrSNgh8sKBtpQTLJ2LHsYo0YS00RNcqez9kWN0q
mcGkPiFB5PaP/2r279L12YR/Juf45Sh4buEzpFo6wPtyig4+lIAWUIZzPc7inOvBxgJs3AJq42aJ
CTxEjRZoTFeiP2zYAP4ZquuoAOcFAWXIvbDEYmXIa8g661PokzqRXcUhdngu+o5nROJ1TUqVUiwV
fYMzaX8=