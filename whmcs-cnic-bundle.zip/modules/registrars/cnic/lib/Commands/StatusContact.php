<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvdIyAQhSCc9iXvbXRAsU3t6aKCn1NFaeVeXybnMt2bCX/DN3UR5m8vqYVQ5LW+mj20Oqrsr
CpR9+XKXZfOJkLxk4VkrFO9JA8Dx1G6U9N5qVNvZPqsIEVLVmiWUy9cYBWYpC3JlTQ7Blw1a3nKN
HznRXfsbUTWDuZaiOWtwAMxeXaWb3Xjgk4CIqv8QDocKukThXLk3RJPlfFrpd7k84PkvfBHIAepa
RcND6U3vkJY47vVrE1bLZovYOM7uqwAR0e7PqCRVXwSEvEPZ8/0h+ouhyRvXQ9GPBVNF0L0tYJcF
CZAdABMJWLqDCCb+Hbd0MF8spTfeUesd5TuaVA5ycw6j3YBD8bD/eVYqi18lH78Mx0r/wdEi3YPH
SSGCFZt+vhNNr/6MZNYCwHMK01vdT1MWavS/nIYNOCOFXtDj4YypG1Ha1sj40HMIywb/2I3YpFzV
/jtMJyf07W9rZzXtbTJb3XMruqv6S7RyVZd1uCfp4TDnC8Gn+w5VTXYZoGkfqd4jzFdIaVii8y3q
gobfuR2a/Hg4OBqjzlIBY4fXIP+sEA0p8/DtPwZv3TPACdZcLzlU2NDes/6dk5CvVbecomeXrSXU
0yVNUYkqDooEz/XOKyMkpOczm8S8mOA0QpeEv4T2b165j0SnJLkdxn4oJBgYYkp9/QKYefpO54+Y
6hfqUI8lphAnrf35wouE4s4tXEetV8Qr3bkz7Gh/vvLXhGqWuz3PMrIEPGa2le6zhiA2cjuQCJ1F
aQiViUYemxV3mg3qNn33BZBdAG7H4GXI7e56/XWnhm/HBtWWIqXU/+d+1LAQBLZK+QTV7gaVxRSz
ewOANxA6dOA06W6JjSGRti//2SUa6fdipN/ehn7/5qGNOWRljChKD/rrScOs8tpLzCTsSwaVZ+fH
6FQck201WWBJwgzei7/cfJCYBv+A7wIRBm/i/l4oJES4RTpT0uH/79DCS8UryBKi0LIsVtu4JGZB
ESKgmr7+PgTDRLx/oCy3OUa1wZXf5F/U3xNH3Nr6eYgc6wnBv4UqVf2ykTSkduo/eotDNGtxKPZs
Qw6Tl6DlYGe3stszYlUeO5j1IaWXEpHPdSjfAsznzpKVVI8Gndl2ge6mGxS2oapgdY3XM4ZbODxD
PiLt5X2dI8w0HlIbkAmcR6jzgGt0za8f0xM3NOhj45bpHA99+6wVWIYl0T7vHb+eWX+xQV8RCbp1
BfTLMOuM5Im8mfnZcAi57ELwvHHa9yshiDYuYBPWoEb2kM2bVgbSZcyDQISncCn/D3c95Qv01QSk
71eBA/vi1AMy+yJp1r1lbVqt0lU9rohUKqY7ha55SmHrogG5+8tpKecbI/5HPUyWrN6zEZ2KjEQM
ct1k0w17ohKhfs2tPCdJFlWqhOKk1wHSCBNMeKrIFmqrv//xyJU71TNH7idUeymjjwmeuuQxLTIt
2DXg2kp0hgpvTwlrwLkcidc/DxKWpSsfrx51+eVwqUpo8Q3wHuLCE5sly66dhi2gIELVzDThpWYd
eEZ3dtr8CP8dOtKoCdhzSJlCH+vZ2qt1Z4SnQd+Nq+Bpz7dEgraZDB/BnLt9MnUcOzXooAGNkUai
E9qnz96vUbH3yZ3qxN+zVzdHSk8IWAVKGjrNSpYv1nrBGHTSa7reSK9RbK8PzIBSd0FDiQ1BLfbG
apNIOa9ZGywlY5ttJvmW/t5+yEgb7Cq8Zg0toSj5LEAXS7ZYfSO1SVeht9zNgzBI5FKYP0NGTDLw
11Sj4NLuhTXYQajW0sAezpGu82vYTN9g9c9YXNfckeB1wXXQaOZWGFzTnz1NV7nVhITdE9jFfaYS
3l8IN8c4afpNbauisw1UvNPaQHXC0Owl9c5R5sX5AFQgkI5b5EbzXKyaZ3OrVlRTUe4eGDCuUTLi
jp/5BuiVXMIAAD/Mq57aJeIbHuyQ0rpaT/h+ThJ0Dfci5FIe+rfVKcQCbc4FdPyltnQV4MOUKQnA
xogpqq2zWDJCZXmWgq0fUbZ8uwBuFVy/4qV/SHVLSbOrgxH6Xjs2JZVArsuY1txji5KulhtTeaot
JXYky3wCvo7OTB3mnHbn5qhzSr5CiOwYNjopJjNdwPkl9/2g7QP5Myy0qVn7Ny4FnWVjAwtd0yZg
HaRY2DNlWo6wSW5/ofqsO8dcdT7DdITPRonckQQwKcVadTHGp3tafSMlw4CDh8CpEfTh1vBakTDC
j7RjMUrkC9qF00v2HgHkbN8W+WCCBHw1N86OlFBTe7hSa/pcJHicsUf9S1WocltCH/a7QaKEMm3X
UZB3xdLzmvrv3dfoVOHnQt/xRhf0Yy98ndZE915m2B/B2A/tMSq3j6dxayJE+Qo4w/dlp3PaQ5Ah
1kilkYHu3+rGINR4TId7WK0zOhEfHZbsLBKSJtmbqHNt4Jj6MI/zdXPL7FJzlk2zZmYZSDdluXg4
OOFGOGMqB4ajuf69Uk3xYdCIS8dWbNkSipDaP6g1LAMWAHAx2dqdl++UpYLSOVACp2Dke/GB6GVD
z6wXua5zTa5yCLDn9tiAqEirPEHuqhuwfCKipX44LguIe6sB5bodjElFu6Qu+bLuvPdlrcEJviu6
cZ9FVKhVxAE6MGxQ+iPnS9Iu0iv5osUb9hx0Tu97MqjzTt2XfEpVc7AdVY2hg5E1aZNFsqJ3kdGb
MvuQQH3lL5rku0FOqevMQjuZK6ziWkOiT/B90YvNbvsy1QVtZQGUNaZXZfl6dDebX1egDG8szODo
Y8avkugbMACdsAIXH36ghHLPYL3+kQNmyma7RdD0ntJRDT5YAYweambZE1i2JDKUib+dwQW=