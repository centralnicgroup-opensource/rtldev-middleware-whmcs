<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwJLZvtxTNJIWXaQll0x2zhAhTkxoMXBCRQutxnlQX8X/mCvhSU/CRtYIhicigvAJ8AFSRLV
yFc0rLYhczwx29/FqW16a/rSM9PnNxboKHu2Qe7X3DIYjaUWw4nIM3hL9ofxCSuxrIiLvRH0b89g
SX4CrLXvkP45g+g2wae6sLgIb0G53OEqRSpK5Ab6rP6NkMaWRxvsX0hI91jyL64Po/9JKqj6Udaa
Om5ciSpOgi6BazUt1bacV61CmVKzO/IsdU/s1RvSKut9IebCxzBCMPaEOUDfVPeHjYJROlFdhHa8
gwXE/+mBfuZFZmw4RYbZ2SU51RnjXohAjD9X/678fbwNlN6KTJPg6ohdLxwh6l2X2rDxJKraDXbg
6ZMkqisc8Z3nj7YOsE2HJVy6+Aw28moGKAx5A7Jbt/s5jfomvsJTRBfNq5KdRjVpztQY0795AYij
VwRXKqFr3TxVNOUvlim2ZN0Q+nixfoYa8fnqUIgaQrRSlHBoevVAcBQEHGGRisSa4iAAlUH9mTA8
pBEwaiic2J+k1ArsIr5NWja+K4OFYsr2mcu9BZ0tAWI7ZuGM1FgzTSrHFxaOy+SSIt7B7yNJOYWD
S4twJkRyzxPhej79qtqTd8X0ahcHeBr5xaNplPnxorl/QEwVJxFTOzOJOA7t0r5ziDa/lNXn3ycF
Lp6p0uVQOoKQ7HUD7UID/e96iBsRibq0uZC3bO4sMA9UCN5x45XRvQItKi//j9nJxHtWq0GVxv31
fb7tso52FQvRZtzjQJF/IF2kT8yJ0Wzry3q5qQnWqp88O5OsGOatpALY0SNIzHiUN6uQDkbN7CwD
B2S04b3RGMASBxF7Z4VIaXez1mhCtSLWTQTE9xBYE2wCLH56oLNyag3MX8xsY/9yT3UpLdNHz3+F
uycBGOw8SoXR+QAV3xcGnSkk68qWTv84me06gpASIXUefm2KUami4XpMyUAsjPBqpknD5KJxcNwb
sNU7Mtm+RVUnJ8oXu6g/tva7/q9P4zeklnDkpy70EaEZbFjeHSzIFXV8NxAm/vf6jHcGN68r96M9
CQJfIeBVBFRvXMFYAAaRdkfsUNwjH2xW4NH7sz71y9HqkHZO11Nidw6QphmYa5CBWciSoh2EAsqk
Ix3asVP4DYMf5J82+EQfcnLYWEIXuu/FXTJav18fWAyPH7tIMGeLsu8V2Qi4VC5u/N/Bw5iI4vYo
g2c81F6ndXO5VLeMrjSYlBk43p4eOO/oDnR6xsU2OVmenrtDrJxwdXmiYoJ7ic63XLo5FTIRoTCZ
M3PKD8f7QJBjGNnWxP/rS+pj88A6ODIFyEh3yBXkxcilWcWP0PHdRQHzp+Qf1mjC35p42tBKDWpL
3K8eDQXXSQfwzEX9Nd8TD5K9siwWACL+SkzBRE0jjYCI6MKPS4LukQRmHZFztuTBR8BKI31oHwkR
v0yK3A1T2oKuyHXKmRkVDOeQMEXo1F/Pn3VGBHj/q0Uk2D67NmkHQjToNZIVyDD3RgYB8aAGtfGW
p8F3x8BPfEcaURci99y0dxJMmhdedfSRCh/3L1VapoGie1338zuVEM7OEdVTlQ5u3Aqnzi8gMnlF
q8LWv8jietA8e3BXbMaixzgy5m1o85sbn1cNr1q43EhabtqGVrSb2d2JvIJAtdfvTnIi+6w7xWdz
wHCqknl12kCriNrUP6ihPBzc/ibhmb4rw4m3KLe+QSZmRYrYjymvlzjDqZkLi6DhW9sIoSHVnu95
OOi4N6P0xh0KF/3l4Uj/5c6MyPKrYedymzaGT2nNCIx/8PqLVPE1pFZ1yBxYcvN9H9/Vy0SfVK3M
WjpfSbrBmvnuzgCDRtda5CcL0w43elDFGbjxiV/3IBXMlp12Wb4PJ97RTmW8BlUb21USwXzi/zHA
TMeGeiFMO36B1F5yMEZPT6ZGJ1c3eaZ6X+6gSA5VL4XrvlqJuvixYdeSvx0SxOAw/uqw7aJme6nk
ukADrHzWhHWuekWsBPar6aSWuFu0UNNQXUPM8iPiutcMmjF+AMPcoUbjEE405NEXTSGTqCga6B6H
hlpaiaLu18TP+0nmDrrgk55MweUxDgb7yQujvSoioRs694SFBs/X84IX9qr9GAj4NbDJ6Z7aqZed
DQUWD19YCkvcp7ZFQFIKfx1UePP3vbup3qGXvx3fkTWkWwcyPpc39XfyLUrWYUil2s8rkHklgmK2
/Lk8PIijGjGvvaBzJGxF/aPu3xQE4srXk4Ps3LkzZsaVtv5OxDxxZGkxv88snXttDVgjc4ZNwLas
Si9GwAhRCxSHdPJImtoKuDf5bQ9GEeklWhi4RaCsGk5cJ7/fgDRnydrYqdsrfGQcloJZObeRR8lM
KZz+SrkXjFrpbUKX5+ZWUL5WnpcNDEax/wIHUlCF8p/SP6Z+dwJbNfqCMU5W7uxwoy/IooIc5UMl
z0fPaiy/UmkhdxwR8K0TEJsgrRVOJInC46TnbjLSrEYI7qdCoNd6VuzKwe5JmDnuHaSSr6DqvsN6
LNGl0rDl3gnZdc3XoBaKZsKAsja48j/pUKx5PTFxTKPG9JytGOXKdYQaierSwy5vnPersMHiFXmJ
uQ+RdFJxYzWLl//hJHoVwBqS8YFHl/9LE2F1fNJKOMZGVo3rtOuNi6CE34D930tI+GK+MTMJJmnV
JXeAUt3b+QDTT9UrcfXxX/NFGQgmBcz0PpVQ9fK7ibp/fiygO8NfGlqB4MEmRNUpoI7q8Iq3IeAA
ZOvhBzJzg/EL9KVldt0YMf6dBG+ee3rth9xPWroywTw+7aJRrsx8sExnbzhCBtln5EjzkDsg3dm=