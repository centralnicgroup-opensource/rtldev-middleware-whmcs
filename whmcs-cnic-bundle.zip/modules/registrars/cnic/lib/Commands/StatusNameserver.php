<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;

class StatusNameserver extends CommandBase
{
    /**
     * @var string
     */
    public $hostname;
    /**
     * @var array<string>
     */
    public $ips = [];

    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);
        $this->hostname = $params["hostname"];
        $this->api->args["NAMESERVER"] = $this->hostname;

        $this->execute();

        if (!empty($this->api->properties["IPADDRESS"])) {
            $this->ips = $this->api->properties["IPADDRESS"];
        }
    }

    /**
     * @return bool
     */
    public function hasFailed(): bool
    {
        return $this->status == "failed";
    }

    /**
     * @return string
     */
    public function getLog(): string
    {
        return implode("\n", $this->transferLog);
    }
}
