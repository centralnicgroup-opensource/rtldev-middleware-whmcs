<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;

/**
 * @see https://kb.centralnicreseller.com/api/api-command/QueryForeignTransferList
 */
class QueryForeignTransferList extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);
        $this->api->args["DOMAIN"] = $this->domainName;
    }
}
