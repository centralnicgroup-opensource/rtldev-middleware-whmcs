<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzQFcYbtNtyE3aCF2a2cHGdpr1KxRcAXllOuYL8dYDBBwU4SckIsZHqamibyHFMyfyiUFWnx
xxohP6fI4vZbaFxyn/XNqSBCynm9fAQjM6TsVyoWVn+O1wbfC16kTAplpyP1O9psjKWqxct6OX6z
0OfMENECJ3ZT/JA1bO1p3xnOdgHIg8zF29OxdQKPwXku8I6O2MluAIikqMY7nHgXPeSpme6R5XOV
iWgJhAwZ/3UhAFI0GN37FeYfqAaAU2mD1/9GBaLnBc5XMRATCsgUDe4RlvuQPUmLHx90uo3YdK6F
Xys6VgIx01gyElnd4ZTNt2a1XXmKv72FW8rHMw92iUa6DiUFYrqAuttw4/xaesbsh/aDLkhS92Jq
dKYhW2QqP9jmyK4qjT2qDrasZh8Eh2otzYsDKRdijSbi5tt8Qiie3iJ27VuVdYQTf6py8GT9ngd4
83vqXVMe+i5CnGjj2+QT2K9ERObxrohjePhPbkNfh3jHl8dg9US+eZXGsY7jtSlvTrmSV2Xezfw9
Ibh4lCSCwsv7XDxIrIrBm+U37NDq/wPq/JjGR28B6foVxDthUTz4wN9iyfnmZ9RGoXMaPj1pk47e
Vkb1/7hyVOK7Y64//OdpzJiCuZi1ZrlP3U6S6+I+Zk0Y/KP4/oK1BWQ0AWjdJTfNbCewlEBmqRFX
oYHy91/26KvhzyJt5cVZKFvL4nvIfIvvMCHIWlVLr+Egp9LDzp44eT0XTivZdOtn9/5SvWyC+6dC
VzILdXn95+lzIzhrfYX8M3T5zpFmW7FV8/Ot+6fyyBqvgRNPwyNxpU6+Qx6Oda9djkarRMlGQ/26
Rm1KynH6iSETYMfxORr59fvZ4f5mHX6J3kV6ZYrC0HaK8vy0oCMAV43klOz7usNUBdvHN3LY+PcV
9y35he8ZvOEY7CadEUOubX9dCpAAmoRXpfMDKvn/BQ2yQUtH3/7Lfuib6l9rzIWqkF+lNZ3KdG6G
IinA4JL7YK8Yn4Dhpxtnbh5yv4/jshBmRBMTBtGCxQyuOhLuEa4neln9gO8z6mVj+ZNF536gcnP1
rFojRYNdEyiG5s60f2pAfpJ+uVIE2qPOeZ4l+gvgfSPjzjb9iXT9QylgjDvj1+8U3V45ae0+79Bv
BCngv65pcUFEoFxznKcbS6sD+0sqzBldwbGju1V8T/doZo7lc9wWi9cjG2Nweom4DHlZ5B0ZlttN
Exmk5wnATjABilS9lnhUBtM/TrJ7hvR+2AzQmORc5yW+w/GHe+oI2hfMZFdeDW38aXeCFpFbyes5
apltcBKotBu4klY3PnxQ+IN/wTqUJC6O7OLAr13Y7RYIIULMhFuJ0ycIE3Qehsp83nAkoO3ynmEJ
LeQagIl4v9dO/IeEGGUWXysEce9wr7ziXhO6f6nXbf2Hrz+eLAhkeEIOCXurJnUN/UGNpIbHBPTZ
hWaUD2gOlMf+BjmhsTc4em3y1kLPtZHkDrKFfDHzg8QFgq0EjnV4fxwUQJkIzrZ1FrR+G37aZLs8
sJ9a1S15bjnYUVBo16xIpSEw8EgWpxmsVD2fZLnVhjl8SoTFEhkDdIBT81Nh1RMUtM2z4P6xs7PT
jKIGg2VWSPiCUur2MygTVgk8k3aAdhoajdrYUgUMrzRLC3q5n82n5s8BS1tVZ+dLVVZaepdxDNLg
YW+rl+g/ZBNKSG9fAUpFgW17yynSVkBdYVBYFtOYlU19I6Ov73cEnSeiYgVJbtDa/3tzPjB2ah1m
ZFF/pHUSPI3OeltoQU0SRaB/x1UlCX4i0PzpdfHz+hIcGb+maNuMDX57dhqD5/jQz87oNsvgmCAm
xlwbYbucZVEpPpXVWM3YYho1JFLB1MXrU46I+jfY1L7sNfp3M81uoqc86+NspNdC1i2bHFW+flMJ
x4CYIsTnTejpLgzqX8079rujLNi1Lvc7tFrSb9t4FnzmxV0XaJDdUKt/nWc4aian/UMVM6bFUii7
eyybTjO8ngGhcBUkgZ9FLox7W8p39BRno3+HwnVaKWryUMFpHuHAo4ekjmVJo2aXrOZ8PWR/k4qZ
hn3qFdbCwscsGY2Jo4SKBK50Yv30W/OM+8lsANj6A50CZvxwUiCO1V7+gxOgH4wcZ7h0LHeiM3w0
mVAVX3eC1exvzCcYBn6HkiqMlU2P9IhdqJtdoxZ7W9ZZYrM/6bSk5UOf4FPCM1Og+3xh4NPmOvbK
UGZ/G+lYInfeVdn/rRcuff3gENGXp53Dlu/CuUv2t6RxcLG5JUMxfM/zJePVZfdf1HksgZ7oZpuD
b5GcLfqWUSLgc8syuKYU/RBOFnPzOJtGa+OLq4D/9/2h231j4NPYnduLbGc73RO5URZoMo2nCk6A
cGxUEJfXWXEJZI46/wSf9+3sIz3NdCU+2KGmTU9VXW672EwvYO8TlFeP090Et7i87/hh2GI08cAZ
dArfIY4VYhPveHutSP1Kje1Gf4x2yXiXw9mTvO12QBkd6qM3XxRYHQYp