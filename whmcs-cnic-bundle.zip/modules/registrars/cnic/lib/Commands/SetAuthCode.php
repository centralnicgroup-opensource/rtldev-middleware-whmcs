<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxiEWYDet7OKTS8N00MbX6XJh13G8mVWsR2udNaE5c/hZ0m7/UA5p3Kj/y4TptGvQ9JE2FjV
0AJZ/ljn7/n16UX966GmtQpJMi6c5vuwBZ279o2qbElc6s+mGD5f2bdSkbEQTyjQKTVuMkQTluTA
07dgLPQab60rY1ObplSFI427qIAfiKvm8GqjVmOCAyOEQF1IFoR/4OyWVczUdrh1d5POMvVmkY1f
Sl4SV9pVLE9YW8BeuYI/vG/n3cIOKE0Totb8KFHTFJwo43LofB0Qo/2Mmu5aWl6kl8LefyzzquFz
koSbi5/vEtsCOarRM6bm5/hz5dcTLeV4cOJg32kERhRwzRXUXO7DNfZuP1FITvV5hAOjoUMFqpat
8ksGmx/0PAN9Mj8GR2gXZoj8SGxKwphUi753hq5bta6AgdshJ/c7LXUNgg32oZfD3h3ZSdIJPGKn
g+AdRIdDuLkSnTjtyUWM7PYRQtbPLMsFGWZocy1lSAXt7tYYQyQf/SeCbsSGr0vQe6CQ9UXTLbCM
tAqYkPGUv9c2XP4iENiTs/wRApMxmo39yT2U+EYatYt6NuW71CvR4FFDe5s7w4MyehGfC0AjRnzk
fBM0xYEtIZQAqILiXup5VXHqBig1s57ClXnc4MWKglQhvdsvoqOHTWMA+txVU6QUNeLe6Fpoy0A6
vt/YBHmTmaBBJ9L5vFJSEjjGTGQEREd8B5O/mSn8y/1SyHdmi/YK3dEwHZrnNjcxKu+REvskbjfD
g/UBPzhF5VMZ0kXehnTH1sSFg/mGfm/8PmarZxb985/9A1UyPmMTtHlAZmjo81BRqSTZCclVtZ+I
OmOdvdRJ97d+0HSa0qRF7d8QxRB3rA2N5pcxZcesa9dDz/UdD1GWYNWmYey1SPdSAkZ1U4R88vix
CuwZEfPUB5/lVRMboaIhvUNzrLBPhUlIYah93f9tnW0J62BH6qhRRuOLR6c9tfUYOTZvpmz8WQst
PP+tUGfHEbNqkZDwQo4SI12Lvrsn6pHMwKyitV53Zm3KY2rtMzRiCc63DZzrng7ocIywAQgXpo7K
MwCJqGDkQsKZ0GH4KlDmv9QCwbIXo7q21qIEj7takBNtkZC6CVt4tWQZZUi2DyHUjSeXFs24Cpkn
vIQM1UQHZNz2G2lcOgENAs+Igo0l+yndoZ4TIhIweYnCT03u4rpAEwNdEACdpB4/6zQCui8x3NgE
SW7H9eGVFcdz9Af6IT7/Rod1kYyv7cVpo7Riqk0wHyDzyWASc5/ZJkGxe9g1Vydrqen3WZhs/NrI
QgS9tYAr+81CTAPOPqTlI+JPykWdVzPdxnUqW6V0og3aOvX2GvVMsINqguZiITt7kqHg/mArKJCx
QCKiGEIN06AD+O/4XXofLBSzpoZckncorZfBQaKt17+/tdUdHnoHWr3QrlsBp5wg44U0tpLMSjTM
S+i5DSgYey+7oqRW3f44v84fW/uWDUKYaCboueS19wQfYBtsI3yftwwn9FG8I4EIYfL0CuFsR9u0
gWB7WPg7S3JQJzYBDGhkic6tn96nTTzqRZQ/0laxzuEjZA55FMdqbhApwWjc8zg9EPEaAngodPYK
J3zVamowvTw9w7Tn23N1vzrOFXFWqIP46YpxtlXW4Y00g/07xa6BVFIeZujQta8uSKhH1QpzdEzg
xjyPdNID9vP73icEw7+aTwnGShs4vNSXOCGKjGsEACLqx7Qx1rOXNkPP7GBPKWi2zulpzeo2mFoH
bx0BgGt0e4D34m7JqTSX5p5OSz0nJfwqw8l9uGRWtTiEjHL06eHi2al5tUk/2vdBcEsgu7sh8RJO
jVIfWAMk9JSohza13lSXz1Q56PYIFXm0t3khwtMGh8WvxWbr4RetLmN4zNKVdGixeYKOcWNuxXTv
cneKMv7s+WBPeoDwOSmxdatESa7eo2WHILWzckv26R0osNT7hc7uhOvvsa1yVjc6wTFisGiWQNsV
r/QBuWKpL+0hpZHbWIPkG4lD5YwR/uQ1GD6VTUGTSwbkr9Y9xYOVbuvlW+tGcqGbdKObJAD90DwZ
10JYGRMvX4iK2ooV9vpKLw8KUwsUb2CD72Yty/nUqBN1YSFTCh7ADUym/+U6og9v+QQ3UZUDGazQ
ioKB1o71S9MbofHIujWISWqEJfRzhN7EmIkAlwPCO98LdGH+fxagF+DyslY6W2fZy9e8Qb+tz6IL
pRikX9jUwN6li+mNPQ/a2kEG7R6RZQ27Kc+c0xq/8PBMZqj6DjFqVxdQsx0AjbyJu0ZvkhPdHqtZ
bLXYiWJNg3NCyyVlstocpxb0MWgRZxb3l5nP87Cpnbz5HuPEFp/NppDPsr3kRdvcXqjiIX0DnEtl
4THdvnOjA8MhDonJkqEumh0UXGHbZwV+9co9DNfnhjzd0ti5WGdZawES/j5aEXpmpPt7iLyphPS1
H9JIBB3+iuZfAChShYsrkeRDasJYWC9/1UR9/j24I40gpmIcuC1CEJ9AKm4nEmArW3brPW==