<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx59bKgU66vjPuK0QO5K95nYfqb4/g4HDOku+RGVvhwov96D4fsbJTQZzXQJfTkFu101/V9k
uhoBy1LGvv5wqkUIfFr5NBpcnSz+0PsuYjQgyuWgEwkkZO7EE+6dEwtQpcgXciTcdhsQjyJ5qlT2
ie7YBUf1fqy2OujG9kP0GRY6o3qELWOPqN51BKd97WBAkynQbPlG5oFMt6pYhLGkMYctOZF8CTDn
b1KwMYAylVx3MHm7Pk5lde36cwtLeFA8KKzVnj+7fmxavcCZy2lxBYlnljHl+L4GhgpazT5iY8zI
4cXT0sKRAfrGUgT/AGa1gzPwLNwFItALgc/ustSueEmQNStEYse4OUf8pn9MmZZHAH3vGxXT0Isv
zWLKRrcFB5anOmHqiFCZU0+bCYr7q+DOTG5tA2nt6YsDQNsz9cZwgDde3oJq/u2OOVAsFpMPtO/4
Qnt8mV2tiw4wKfF26I/gyywnefN2QsKlJANu/qHYQhhbDXRspFl/4lthSRmCwpLOxDv8RshnNFjp
+Z8f8c6Snfe82bD1kcMv9bzVHEmJFs07N78zeMUUcSsehm8tNmoDuwFZ3eQD3rx80+xHXa79eNeO
exGzii5illKUYiXc19cMAXdR52X4WrLBYh6s12CFeJKBMTRuLMR/4Q+U9T7O5ai36T/u3vUHOfw1
IePYEIvXS9SHyNXKkVf8FXi6ERlA9NJbpESCcIb6w/vrtV2uZQWwEyHXP5zo//1RJd4vmTE7og13
KPRsTE44ptNIkrGtA4Rus0OL4UlBMJ42D09pMIWgKoUGZnU5Llc//M8d0qst6XY+S4yiAnOTP/y2
oPxIZloH1Lu3UOvNLjlhuwEjyQ4ZoPqqzj3EwR5MqCb3Pz5B2e9HeWkcO52AvpS8L2J9cbNfogkn
YAfgaqs2NGJIgvsc6NRGBpKFSyQd3ERTcQeB3PHBMsnt/5mMKS3DvDcoxh3eRkDh817KY9XNXYkR
Cn1xcwM2Lx9qFIGOZbExRSlhuIbrYxUWSWLSKlPLZuI+ZliEp1ncWHK4LjjKVdsTmpFQuy3ZmCsR
gr4xZofqwyt+18r6DiZBXKD9ROEY5vdWcdSkOOmnuh0oJPDYLYxXOTzoZ48onhLTirC0tTFK4kyT
zog8EjJ3qKelWjmkZy9O59Otvkbj4t4BuY66cIPJ+Ypq+XjH3PRU0vuLCStWuLRSej/FoPIlZ7m+
xEDBVSi9sHqJ3ZBHbAIAgYEoXRHFQVbtJqVrcNtaZgHEev8CfN7jP93NwTFbtx5wDhrjIv5DJmMI
af3D47atjIeSasWtPMLrsILrjtwdkWeXrFiF/NIs0OcJdGIKlSLVEIDP6xjB4PNSIPOTbgSKZXx4
bpMomPbgRDSBRkW4mPaRDy1dfnq1iLvxSY4c3PFKOlyTnnrHh/xNVFWltyG8TkQ6DBlqmu4z3xqe
GfKc4v8tVNnNHIo5CZT+ScbJRCYCTllrKozzikMs/y+jlqGnIG09S8+ifuqg9Wn+G2LVj03fRcBl
0xy8jzvYVyr/Ij9fftAXxo/jhkJJFewHMqAKZEW501jpbAcjDJxQSR/gDaB6j+wW8ZRaMegzSJyQ
kZ+DpcxdZ5IYAPwcXJhqZ3ztQ9T+f5au3fu4eYXaJeV1fbfXWdwNlMKYvjhRN2uXyDKsqzXy5d8K
xAg1hbDa3jZnYdc7eLAHRof8+ZaQgEuGb2mxGpO4dKerBXTvv6heLcjaV0CpkEUPi4wQ9N3sTNor
D4ZPtWUvVVziI2qDl54BbV4abhUrrjkmiV0NTUHE2rkBZ5cekV205iFS3otSSENXfCfPshTgtOPz
zfcar4J7B6z3QtMNAbs8PtwffAbxWP77krY+AisdAQZhxjy1/iV4PeTj1vRxTQEEYN7EieDikL3K
nsRG3iPwSeMsbgYldjcv6veYJIwET+EDisXQZeXcvOsOxuwA0KbE7beWE7N0EZ5ZQ7Ao20DhZ0KG
/KzWkyDKE8d81KCu2qr7HuerUGbW7o3yxaTjJ7/HcbtOzlZQR2LJ55DVYADve8p4W0ivAVk+F/xB
CF19hNWkGwrPRm3531OFqbHnWXGZ4bzgse6fYwaaJSvMuzPmlUxWK/sLUdgzNH31J3RUkaGnujSA
gb/IYLo9r/zNnVx2JyFXVjUx1jt29Y8P/OaPwCp9VgdGHec7M7WQFLZNZLcAceya6agq1w8m9Fl4
G0s0Yc7LyFFO48d6gxgL1xDIDU1YiHgkYzmMGQpIy24cTRGro5bSTlhThJvud9LNfbR6SBnOV1BQ
svKobr7vWLeiaFCKwxzkpb/KfhyViCmnfZNwuugGQcBcC67BY4PJuIlkNoPru71pAx9kU2k4Bk1N
0Pv5kML+CQq0D/q//I5imFK3nhMwNzj+tfzsL4DH05pP2LO+XAVxUn0m0b7Dx9KO0cThJwCbu3Ap
vVOdJW8b2UKsljvWkHKdvCHWgbzISmZNk7dAbnOXJl01a8FMEgSgk9KbzxG=