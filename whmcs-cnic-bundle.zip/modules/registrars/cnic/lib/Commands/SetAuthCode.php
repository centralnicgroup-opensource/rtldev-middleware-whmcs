<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw4jIRHflR6xTE7SbqGa9LwlO/JGf1cN2yyfkzT6EvSqr0dJDXye7WhokKr39lxKWM1jtsz8
PfROhIdaOvVsvu8WRFBYJy9j4aLayU0iRxOpDeITIOT3XLQ9FMqgEYgM/Zu+xfAs+B3GCcBk+vj1
PIjDJtLpbVdo60rfoKPMND/FSJaVxx5Y24mZlMNJk/A3UxjXB7o6Ffm2Rsefs8TdtNCOaOauVH4W
DNvUkK4Pkl7xHCzw9sO8UzHAeEzOjukvkJNTbIaEUEe0ZoafcF9EzKRfgWoRuMVgahfXSohjxTqR
Pf7Jg2M8CNX0n3CpeWCwOZACX3B8SkgDh6IdtwppcVUlgpJlPiMXtCGUpSw+lBtbHNGvVMnJokuG
6MAJQu3QtomvuNSu3MqIZCwA71NJY9V8aQKUSOn5Fcgs2TApifHrbCyYbZqW4jGbYzxydSqVYI4c
kFy1Yammv4ZgcwyKM8dchelLLA25j9gNpIjQxOLFVtQUyuXflpvwrwsr2X5n5J+5m3xwVP2raQTm
1I8aVClUphCixJSSfAtY93u4+gPKvAWHaVr4PaeS3Xru5JDU2lvUlyA+1RQKvftcC7kK9xMWxf38
jvZFqpRIUBsPlBbKHASQA9y+bW4mu0bdWvc2YerDjDFlKgJDSRoSRjA5eMlbPJih/t1We34C203L
mGBSZgGhYvgUgGSVzKjw5zqcnrceWTWZPb5aBzQ6FpsndRh98m5LiY0wENcMPlb/9VZX4qVVVdFI
0e8vrXVMuf2kwZ5hI2coWJF3Km0NyQS14FtYNDeFp4QzbBJ/ZNlYGtulx93b4n3WLf54s05ZxaQU
pCXjxp7wVD/MBo9V8vMmiW+Oya0uoIw9yjHx5vQFwbwlnOe0n0nvtDWSZ6TIT4kfhmxscuWRyP4V
8GYfgUTlXYs2ne4EPZbbchD+up6ExqfP9Bvm8EsV3vEeKeT1EubzY60vMOYHKi9jHd3eOoAu9ZEx
y8/CmTvX7TZIvK44Imr0ML3arei0H+QQmoRBqPrODR8Fyca74WkQmur8EEFvwxZNIidUO6dO0gzx
Doa1jNy+sRr5ZaNpop+9VjBjf3Jk62wWZyD3z3LW8lmOiMrqJC6TTbb7Rem7OetRWCXIfNASGI1x
9WTCM4VKsoi0FbouCysxagSs+l+PLFTE54tW4HRcnAEr3xD1BaCA0AffamEShOnURunPLw3QuD27
WCiWckEG6M5r3yRVnqUb3BMu8JHVwXvb4gKFMkgefkDFZuYi3H+bncpmu2cPoUytqEyezWYIgA2r
8VyTRMwEfgw2/1xoIs3bB/8Td23sr+iAlHNkDalV9bvYy0HRtGxbsyhovZXdDo4SxPP1n5RWi3lm
E+oyu354RML26sEPN7HI4/hh4O6x52tz7pxhvhK68F6dqaXkJ2wS4Q/P8jBEeyLZVufigH5jmo0J
9aeSIkhIcV/MJW+KBWcqMioXrUGB77KqySti1q5xNZxPkG3a2urk1zR58rD8KX6npeVpukLQ2bfo
g3jLJLugKhOuBtTWrLHSih2o/tuOLJMzG/QEVGLgCQ/GW7PxEgm54xzFwBQVwf6Zo++IxhiF6pY7
QGjCcASETVrLGY0OAsoDR4g+jKIJny9XMqfsleMz3QHcEC1ALJw9QQ5D/xvkG3yT2uLLZVAAhAgJ
86/YGY1lGhLo7UsZFaBiDpjQxYvtooK/2V+8ojoOkuPClCQScyK3IRO64YB5Ch/WgK3L+ld1Ac1l
luPsWDBs/Dedh4HJcHVLslmXpqc2LOaRmtglSLd8KJ2+vE/8hFgfJ/WgxDihTEGXoSSRnejVu/7+
6zrQiiYzbXTnXKpkBOLR75J5G2219+Ii0AZ2pKkf4STKjMf9YKewYF/52MhTotsngNwEzI7+fnmE
jlaxC5Lb0JHQicBAoCcNGCXmH/bRfovbp0vnXaaGIy1Mi3tTfFkKxD6G52kvu8gpj0XOWRqn16B/
XmaTwEt6edwtYBc8xG8a0dsjGjAhxPMPgDn5bx+KY0jSPLCBNY8kiAZmLF9WWmaHX4fZqW4q/JNF
tOHxcJBeXjSx8fOUmhUYOFOanE5L1L9eP/mlvXccccVukVhwG0y2iVUr210X19KDpC//lr4/7Vwl
kVqFxOxheFxjVkEfaw955nDxcL7OR7NjO7QfJp7Q00zsj7qNJyxA6pMQYo/XOvRaUPuWV4rk6J3Y
BAIZfzoR5q3WNhGRA0JuHFUoZNdbqqLheOVau69zQevWVSeMfcEBLqeu5mmAaAE5tlbUTWzKdaFs
NsV/tnjWx5wyiCi11HgjOQCUP+aAglUr5tr5zBdcRxxCIyBDveZ7URCJ+2ZMx2yjM9zYL7KREIf8
QCIOLV1g72Qc3HjJBv11fbiZYDDXlPUKA4C1ZWDGcTvvCSem5itVvnNxLJSdfLdI8YemEN83GHKj
g6AeXb+fe7JRvnuqDBF82fF2Nt86gPLR8fvSOGAE8nivXu0ObOSbDSmQYltO3MRT79THY8wwDYyW
nm==