<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwty+QTkOiA8Tp1iX1a1P3/uw/xRVUmB/g6uAl6N+dMR+bmH+yx8ZacPBDXU0D3b1GZ7wilr
wuyUDvwOshzAFb522splrkrnedESUDk02xF7I9PGsAKntHyapsmQA4f6j/c6BZ1fFufi6xmxcLMX
/PdD/a9KOM+58ncdTXDQe55wMi7GOqUAeXHaX+5xqxlIbdWaX9G6UFJhMJJ1wkIwJNxbww+xtpRL
S5Qxzs6j4F9jKdlKz97pMvH++FJMN0p0CGe1mbNL3Aaz1Aeez3//eS++rZ1nOTCvBw/3OsHtEH08
zYOV7Q6R1jsTdnvfl/OngcMj2Byr4ZaDgMrY0F1wXKk2d+Gc6SX6P4YQXw8gkT9N+o0O85nEIy4A
WPuC6Rs6a7XG8fMNj2QvTpYLbHEq2k8gA5XPvSMcl6xAYBrnH9NpHWWcrr7KYkwm6bJYQBK8lV4L
z+dBJQg96r6A+XbjlYVXg1zIyc7sTxIf8TJ4s4Z3oWwOSGbsVqkodx+iR/s6fqlgimrRG5EHVJRh
EpCjjXpVSzUGUdaBuxIOQ7pNRPkSWpTgcolcSq/qEe1J1ndbfyODaFGBQQl2uv4r2RwjM60MpOcY
4SR1/GHtpRPTkLAyzO1qtVEUduD+PxmvR3+jlRp+zHTIL1I/WjgY7Gh/1KkzKwSvGfnAlJz4J4G2
tBmM9/JQ/0Q2+SLsI2NCowqLvjeKe9x36ktd7njcZ/G10m2/ob+XhfvdPEaQTn+vbOUcxDOXYv1N
/dLyWNvIY7EUoVl54eD23wtoKQl+KJvwy7Mm41g5f2XlaoD6ZGcxmpba38T1tTFAsA7zZf75W7H/
YKejalA6BZdLn/fXAk7pe8fYfqlX1+j712nRWFVgCsIX8vgaSfAL/ipAAxsxbSZwlV1gDU/S8ulH
ALD7TdsX9ux6t6/f+Bgji9Y+/IBWFUjrZl3LbpQNiaq/Y5hzCJCo2XgQML+MTERygInhGk6vWmqB
vsijdCoPx0KURdGjKqlH6djr7iEYL2hYk8XSJuw2mMG5ojjdPlpLjq4gOo9ngt9UZBASVhl1/R/0
5qqCs9AXIQ0Q3zvm3v94394dZUzxEo8tfhYSb0+aH5cJjokSCXNFQMDJVVmSjhqqKL8RmdHXviCG
gI67l/yfJGtrCRjH1DxL8F8kg3ktvJ917uQoZ4ZqFJyKIHI/NTn6xSX+vyVqyyvb7r3VT78QtQTv
WRGbk932vj9AHmTRIZ5g6H6cD+KFi+uSVsGminJHsBeHJymcR3zMmVbn9mm0pRJ/eyHs2+PUQZ1t
ZyJK6Ne/UARMfulKLvKr/GIpQC2NY/4l5hdOBWEZehGpzQo+/alxNomVAy4QcqOcjfC/4uz4HDdl
AIlSTANkxNLXiKHXJSe01iYS5eVhe287Kz3W6561K6UnrxXnce+QES2u9NlbzyhgpEYV0sm2FgcW
xDlFxuwp/LP01NHaavzETYs3wo7IrdAkuLNdtc8NeL+kGRtarV+wSOleO+wzpTIjsUfaK3BC+RB0
J5DWMCmwnlc/te7b5wQorQotKItzEIXShMNmRtUHQ++++J9PW//Un4uFdH4n3BRcVZqwxlHYd2np
A8GbXe5yICKm3+uKL4ARlE0/hqWaFX5X9bQjdmj1rWV/Q8qdGjBZu8q/JcGWxLzA9CbHxCRG6TIf
/ZDUBAw1wfpYw1Tg1Z7jBhhBe6sFQHToEktudQVapSmL3F42jX1xylfY87eIyHpBwuyxK57utfjg
tnnCyCvKe9HhzNiMqKEkWs0tG/14rQ3MdoJnBbTgdApR9isqZaHXsO+WQ3boCb/g+oaurZ6oXgMf
TtT42/giU5RCCxJO/HLd74NuuHwW6x34buC/WmAQq4aNiuZZf08KZgFOFPT98/8jY+hfs1VBJ/+h
Wequw6WJl8ewmcewkxETc5KN5MkMYlj+yQ+PL+w9Uwx8YwVJAtCu+++BYxJ2jRh3tD8KwqcJ82EN
wyE9xCwOfN2+ysZeWXadKweOb7w90t2O+wc4PiHXo+HmwIYe/Htq2WM+MrQmdz5H2AOu1wO9o3ew
5GRyao3wzcALx6duCKk2ZF76lV7cEVSx5VD6Yhjc2+LIX4Koj52xNVC7GUJCIyD4+/tewlL8tzIW
aVneqO1/Vs92EHn6+rokd/fuBmOjtOV0eb7pHV3n7GXKY2S/Lsr5QHdjIfRkNOWjSx7nk9J214rL
wX5APfPLDNeh2lUs0ypUyPtyLTVpJ1sXU5zV6aiILY9CXDpz/BwL1zDEffVCTAhd7Hj+8ac3QNIY
NfZSc1DOo3a+k6+ubIpWrNuqkzfg0r4VJs4XuA/MlHU4m+AgDqEGXFSxDu30dQom+ipQRE/0IpML
3oqW5KGGa07CykurEIcugEdJ/L87GrC0QGi5WsKFzgmQEY78vTRCqt1IFZfLzbhEc2O61v35Dz8F
xYt3HYGKvPL088AcVlbUcoZy8ZkE8ilwy87NECX+TKcUj06tMq1dp0==