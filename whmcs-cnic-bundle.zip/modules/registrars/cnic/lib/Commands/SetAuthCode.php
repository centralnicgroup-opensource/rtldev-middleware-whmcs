<?php //ICB0 72:0                                                             ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsER0YM8PVSALIYN1hGHTAyPQoIcVYd1nA2uQVUbNb24Lco2ZmHuLVi5ziCThhvk5XSnu+2C
5p7UZ9BQCsiKsoyrlzM/LHVRamFepvfT0unHIUPYlxpGt+r+cBYO6cdEsxftyNUOG1fgI35UVWuc
yhZUpWbnlVkvyTYlMQmMHdYho0/9/57Z4kdvmBAhrHvpEYn+n3rBY8RLASBsMulQGnu1Gtwtnul/
0Ba5ZLmISzEmTtOV+PrJoIgB/7uV8rXCw5hJ/9Gmd3xfwBkKmN1mk9ZkYj9h/wR0i2HwbyYkf7VI
KsSF/oJYVoi6AVP2NfFfhS1ZvqebUM8LDaVRwp6flFgVwfQ7rPY2DMTT2iSTu8LMw5wfedutjGrE
YHjph+kbQLeYTVbPSEPHXLNX+VS7X1/QbbwBnsgJDPG5e099eTWFsmPRcThYqtWacqSDkD0I91PB
XBA9FVyBJCPfsIsj39rqta56WCwdhpQIzI4gtt+JLfs8yBKJJPDhcv1jU6rp97qwCUfpqPB2z5T1
FnU4TXHe+j4S0VQouUiWaQVUrGRr+ZzRfB6WCnKnvYsIzRWHS5v7t/FKKgibo9+8YnfPjfpvyTTg
riixOKRnhpbtizvqOa7HN9JCgv66l/9WtP+5cDcp17F/3aFUH/5lXmp538msG53eqQxB7Qg5EXQO
Te5ykYVgIbEaL1vtaPxdmviDSeVwBsA4tVf6t57c5wDkIByXjB4j0+oQZcHcleo93ootvOHpNmS9
YhIg4vVPJ/jkolopeLtX2bSD1sJEGiwMINa6tbyQ+q46eqQ0nZJUz+Bw7Wka4bMon0czUIG2gXP8
KK1nHQf9JBP/q6uTTKWWZD70vyN+es6LD/UE5H09gL/TwmUztoOa7EwWkPCQl+T8ULx7xi+vOZaA
GhKYHz//4JdjbOJPZXOAYqfGAWaa2udUTZClGyFatkFYhFOPz3y/0WwtVNBlhtdiWqwuH3csawmk
Krfv0F+t8GD8PmbDTCZU0//qiTmYiRAqp4DQ3Q9Z7RGJpaaqu0PNJGFFlWpD61fhFXncuntQohea
LRnOwfoy7U3kEVA+sUejTBG46AzpSAETMxFkCNUgUJDvLavuv6chCz8+z3G4gz2J4rABk+CWZ0QZ
HzTAEbV6ULPmkNo3fk2b9P6VIFFbXT02Zx+wGeRW0pzpuEj2Slj4fA8icnTdV0cUJ9Pbx/SabnGW
IH4tjKRwAI0jEyESAK3H4cyEJefK8Z8fMDE1D6ObC56X2ImrlkBdvyj+Qv7j9GtHJkEDtXO4S2VC
s/jYM+Kwsw0HfPIwUJLgTfKRVBukTVdns7e+6Gqha4jY0yJGtuAOKBMNfwtRM1+8ED7/KmsBoj0a
j2puxtG4CzaIHUBqremzU1gsVnmYx7rRDvp1LYstuG2M/FSC0II4q644vXOIE8PDR5ny93wmTW03
kTuDT2ra8YYz0WRDtP+vh9mOsGoxkW7OhOtiTNd08o2ksZkRB73RNcWkdTwZ/41eAwBAccICijQZ
QZl5OKfdwelfwthr0LXxr7360pPMedvqGeMggi0cICmlYovo+oG6LZHdTGcuK//Gba/wa70JHKtu
C9i90AeEjVZBrq42UTMaj1+vCLCnc2MAtE0z2AguEXJZZY35omnLFcpn3X61LXNnkZTlnkYnP+Nn
nlxxa8nssUPKXrI5rjARlt9sCpYN8cgOGLMpXCkXLro8FcZ1Ix1bDVpLflvNpJ+LSWv4+qPB481p
V+dLMdCNLxJQ/jAjTEYVCuYsAwrBwdi1y1BxZcsWRNaarxRiy+Svfpex8WvWCFsAYurBwzJE4mh1
v0NGbFJ75K+oWCPD3j1VYUxLK5ubmh30H0K2t0f5lvHX97bLJTmz26xR1QEa/wt4ZtUpvz+/EXeX
Z7nG0dipY+PCbIsS3hFZK5+o+TUaB2vf7Ck7E1gxoj35w9tRus3jEF0YyNWclT6m00a5nZ0Ajz0K
t69Hm6CENPtI+iQEZ/iTYEK6UGMQjozePkEks3gitB4OjKpQAjr+oo0V2V/UTKd6XomshPUyMzRG
mubjYYW9MsxhB8YznXLBNkj65/fNluxMk4D7+SD11QkwBU9kgjvgL7p9TEtIca9pRsajsMn6izss
75Y9kkVHLvLlSWE6o6/8FhakXO24VeaFjifvnaxmw/Fun1JTNIiHhIt7EKMxwx6xlhQiK4uCdzSi
2UOvz8xcgGDC0tn/CO+gpbMftaqzb5slArbfA4ZbWAWDi7HXuu1kStQ1f163r/9mvK3QD7O2Hytc
1d8bx10O0nKmiNs67MGzCwc3LyD8kjKmR5avgeKr3F1y+j1IvM2+20l+LXy1R+rWyDyP3IQRGDxA
HD/peI7lQBqFoaSIDaqpEnxY58xIqL2oNxVbo3uJaMVV7eEqQXbVSEo8yGHYnM81T/6HUTT2n2tB
QrFAodyWev7EGy+vPpEoSMg8lmKXCR4=