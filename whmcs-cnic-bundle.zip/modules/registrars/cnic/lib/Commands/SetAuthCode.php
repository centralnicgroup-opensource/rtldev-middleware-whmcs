<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpKD3X8NtV8bxi6RCSBouSTi9jClGVXOWR+uG6BXChOWoJ+4/VHDsPT+iNfDjHJssGMRrtFl
LuaJxUDMrFtwyi6aG8zhHv/9+ktIUSDTtAUXIgYchN8cDPxgRj7VzFfgZ0rMa80ro/xM6yyUflwv
DSKwxSAxKQbAfKMdRR7hLb823qf0k5eRDGj7G7rniu5sUmSIV3SRfLR2hUUV+VjGsjV5QelJ9U17
WzmM7lNgLIjz6Bn/XC/Uvs+CKug+txcP7TZd38PGOQjJKu8SAFAUjXXANSTmyuwVw5QggTj+p1YN
HoS0/o2mIM8IRdv+U143XiuELf50wqPh7meXsvBQClMFYQrNMwNPvcbK5EuYMSnQ6336jbCNdckB
tuTvnRuDAPXnN64kQolC8he+G+S3nAdix3qawuHqo70kzlkzkW5H+B/k0mh95EKZya96/annQFJP
WyC+xBJvynzYWJ/15jApSKnqMVqzkWiWocFoGgRlBvnFO63op0q6MLhY5tBM4GVDDDCiof9lOINn
koWQxbl7toGm6x4FxZB3zQSNiPgofBE6ZLISUoufbQGzMQr0og92KbZytGNBncCPhvK2UwJnhjjQ
Gsy98Vm7A3Pawi6L26aeCXc7rp/rxa/7Cb2qRan85r/NJwWIYqSqszhqE+ZJP0zPXJEBWdT2pBZh
66F/ngc7dnIC6F/u7yPwqmHeYILKGyzILCzmEwbb+4Dohd0lL4Qy4zrOWD77Na0mqlkWShjr2L3Y
Co4OGqYq9833rDOzky4P0ZO9pZ7/eDhKZBacRGVx/UPtf3jC3zo+hwXfSBcivd2zqH1bDJND3cvs
DfOzJFSGsb64qsjm7V3ewhlBg+fs+EJKmbaSCxqi4ySNBG6rnmvGbAqR7aA5ol5naiJ/wLRnOBok
vJ8N6e50AwdU6PwolwiFEIghJCwVx5Od9HnFenwC3Fi+OEN8bGKRCAUvFyE83m/iNtcuovr/L/Ei
g8USfuko2a9jy2owYkn4+6eHg6bzkWPVEtraKI6d6xfdmjD+HsKeidYKUH75C4U5yW8MfU2MuJ/p
VZki9UJa0fsiqEYtM1NXHK6A2tj3XX6QlEB5BcByBCQYKnkfJUAV71g1NrOhj/8mzqhv//8x9LIW
ugHSWX8e7frFP0i2sLKTsz0GJN+UURCLiL5C/Wuk/vi5KpKcWH2GGUZICndRqHQ07PxsL1KNnkW2
ldni7jqwHrOoqUlm28jX/NvqlUULJ8spwbzRMxaa9vEGHK9RsxRxAVkXRv0SmmFdHq4CCJ6X+KBN
StadbklZ9KjdjyNKteCNrAa95K7oa2Ag2gtcG9BAl+kP4vSz3eNYtI14BybIf25j4XkuwsKPJNnI
N0BBLTyUdY1VzXUEKgS9Zp/zxp4OlVa0T+NGx3tGNYpnTT1rQgYPEaOTy8hkGTqTvptrRKdkLUbe
JrT37c7M+exZBN9QXIYmiteXOtQKISocJ0AY8vB0Nlq1tjLKlN7PUNsomPl17Q2xk+K5FUZZ3NeZ
gLCHzrTAU2zk7WrquEtlCYuFWrXwU9qxwf6fxak47kq/PFsQN98FaaK88301l0vLm/6ODGrEAEKL
Q7ewJD4Ej0caZOx6h+TMrN0nY7qQEPy7RANeelDPKAieDDWgA3IxBYKv9+gUIu9+p5y4o8J76alG
Hue+BSEhIAxaxfiRVZKYx0Z7M3JdFbCgv17dbPH8pJsY7nFmlKGWc3vnh5dTpz+aRPJKTufFDJ1s
1faNk+noea5saxeeNCdNy0j+B+uE6ip4LnYDcXRJUFfjDmNUqBZVgO567Tme8/4DGXDP2G7UuSFq
QjSuWsv9xurHon/MV6wMMA73zOQJK1gDhAlY9ASuLS9O4ZXSA+lQC6QAOSY1uCuwY8X59htnw3aW
dSofUoP05PDQQvNL+pJX1Ai7wrvWVEeAcWXEu40srZ3zXPPIK8wplfb+sbY7Afc/qL/+eWiNqV73
Sma+rx75TOeCluu8S4g2Ma0ofCgmwUq2t0Aw3XBIgeG6gYnuP5o8J3tKqjla8iABFJ+JGQwXghjV
5XOGJl+wp5ERfIOIkQDQ2adN+tgHqc0wGHJFXnkVPsDYN8Jdll2lXw1NTlpGbidYLHNF96nLjX9a
dAvhIcK/b5bDxDrwsMI2dpwoFlyuei15PgYjy1Jh0eZY/7rouLHmHAdtOjB6EvtAYRzMCGW3UYKC
yh2jeYBgDLTq3h6WuD1nFo2r/Fo9i8puttwJDJB86WI82qNNgMCtXw+19E3s3YMLWrw8oFHDmFF5
bY/8nDAPekG0Ym8nfljxNVxAQXNnW7aUbI9Y129Ep7TUyh6qD8N6HUUOXwPdOlb+at4cN17s8oEW
OJ1XlOuo0ZeiTY8+/ZY63J2ZeiHIpqIesYePzvS4fqzQEz3iIBcoE23KvpcSZlYImv3GsQ15p4ks
HhNYgKfYfg4b1EIXh1QEy18prYA5Mobn5IVUhW9hKoriFKwdlESUTXq=