<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+XsbkipsMhCoiK3o557cxsxV5d9y/ebE9Iuks8gRZg328tLQGrUVdUp6OfkXEnbnExxtgYv
sZZ79HutBxQ70n0foUGj2Dhvkuds8DzYh4TS1Su8tZQ/NKnT5R+BnJvI43J5+q+FQKyPfd2johD3
8ekio56lmjKhBXo5c8Yq8AXmG9RpkeYmS0tqIKXJ4AmVGRYFZ3JG5byi8Gz4dFHFuSlNXyv+0sms
59HkRAnXkkxhJByxWFMwp3Zau8eSb9tHBAkF1RvSKut9IebCxzBCMPaEORzfPWMC/lQ7q3NG0Hbu
fQSF/uap0MLydTuwkCmIcVQgoFsxqtEix/Am+NtQzXbTSytlDfqx43Ln+4Gc3ff4lYX8n7sHDYhF
KRtuX/ALSAWWsEf0TDnLijQcmVmCpHcogvtGudy45yvswWEno86S5fdrMzCVciSYNC6Jyq5Z6FzG
KHSqnIDaMfdzUnJSD0Hzl5pRBG0s9tvx47NzKVUUh2xZr+HR8O7l5PcEdBhPp/A7w3TORJDANgVx
zca5axVTatXUiGg+8a1A1YEHpWRFHcXaQ0cfQ3+cRrYM38gIbkZDwSy/n6CoKUZclN1QiiBeFhY9
DjDd+I2vBd5zEOdsqEeQTpEigwS/pblUdgmuRYKrsoR/QNp30oknF+kv/Y66SyN1iCI6ejMQL+aj
hcZf5CTwnwaFxjaeHCsnaqE/nAVUp5/qQlTiB6HTS+0CHk+CscdYIfg7jWpBxcgh8SRtGTR8ZNuv
Hb6s3sS6RtvO3k0zX9qqvnS89SOqhHO45Z1NJHyKUQS1Ru2BVS2RxB+K+V1dWP/wBgcNdq4JK36g
aU3ykxInwmIgwOhehn+rhyuwwl+VVCBeSkurVZbPhV2Rdg5Kk78oHDngW7Y3Etr/ral0vu3EzFvQ
UuyS9HGNzZFHDSvOAuhMzKoCdTIguVw5ayAhkA+pH6WiVuFqpzew21CjLihbP250cxsug5lmjYYE
qjq+FI1eiCvfzKx+J39R/IGw0GAdIhNf4qcuHMUYmLouOMR0uvqq076h2UZKdTdUrhyaL5OX0vlD
nSFETCksyqx+Z9YwZ1khAlWH9iiRbcCO4vvGm4+Yab+exFwITNNfn5lJ0MkS1qaowJNSlrjA7jSO
C341RAlN7r5gKLlJzFyAC5fGfe9tjwvHcixKOHQgEE+HNrNFp8ckhO3PLsoDrCRv/8OhljDy3NKh
NRPmvLZTisgstRsXlZ28QehEbUuculcHQnpixRcsJfMWz4uUHL/KcF26of0IU/T11BNhs8ckmpKW
oev+8sjnLFpBuOgGhSx66N8OsiK6BWUSbUCMl1mqmel21T+Jk4HvGRrCuvrYWaz7KFgqrVur2gHG
VX/3XzWHLQkvlfvU1d8i8LPZAtUTI4MA8B6+khCKzFjS04mGOaS/hHqU8NvAJXvHcMvulKYBLfhd
+uggn0pR5/dMux2BCzKEdZYDPJvgDCr/qx5fRYgQrfAtxr3Tbl/kCJlOBnroJEWKU+iONFr/6Lup
j8zot1Xq4XTF7MrFA6+HuL66VN9Sjp6ShTXkuUpYfQkE+JfWH+6DR4Ii0u5CHGi2Vg9IcFbthOa4
bbjwGNNuNxpMmQkjXNr1eMj7BOyEppADb+xlSRlwwgYqiH3HTWpnwAJJVjZyPhDJrcy6bM8uGnHx
/MKhsIhxqKdFDL16WLl4XzltHpgi+YR8Yw7cND/SpfyECH4dP81p7sJ/RK4cf5R9oGN807NBcKMl
Sjx7R0WJofzMhsPCGDgPHPSljMFyVlG4ri6fe8MOzZYiz9npO9vZ/6jBfs1LdsUoJ7yLYncUXkjO
VYajNJWvzr5yiMWhozxf+NBwUL9ezbhWn4Q5asM8FtKmVKcpGF16OIRK2DA7rVmDbFtt0NJFUYxr
yeGtiH0IATgDl7WNHehYKb5Tue87WbYBTanxn6NdzVSt9zroeCWpJvjfLpfpSJWls1I9EgAPmyX3
uUAOlNa8QDrmu34L1Qe1mBmKW6V+7zWz8givlqQH+mLk+zK7GQa6iFakTip0EjPZpPnfDr1L2w/L
wWwSjx4V2MdOmOPJdnuAnmO4rrkVqw8tv4JQVyjHkAusjgQ4tM9QEQ7KoSS1DdXRSlAKu7cwnz8K
dI8hXLIcmksYm6DELho+rBf3rrmWpr3Q6/ucXuBC6yZn0KroBm8c92kQRG5z7RwTJV37xtYyS7dA
5KxYYPezTPIUw9/yUk79FUScAxwckduSjw+GiiOHN7NlZ2rTHhb7KHCiBRcOKf9nWjEcu3hspfFg
T7cYkC5/roEjr7MAdLojRrRiAwsQwrjyN9YO+Q6yYwOOcYeYA0MYJqaNbuOzxqwB6bZM9iC9928x
X4zavRKV22EK1LruP+PkuHiVELX5Ey7QmP2wDK5zjStV+DOgseVdGxEy28IQlHe6nJ570gaKHX7Z
mcV3oVn0Ds91NnrDzxkFuilzd6GQcEbwI06QgTv15gG=