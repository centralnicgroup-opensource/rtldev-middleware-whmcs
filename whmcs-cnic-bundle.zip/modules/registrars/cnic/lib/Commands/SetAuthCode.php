<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzeldpzFlsCm5kCA7Bbq0LdABpRiq3DctlkbYbryJuv4xbWRqSgW3ahXKF1CRukDdm/HBPyq
9AdUkfIjiyV+L8MAtFEftEx+ZQ/HRa0Tr+OsnDlUXIZKm6/0bKJYPkmVwTtTm6e5lNEbt6tIbZO6
W7uayuh7Y0j2IRDIiY51tob/OUkVIFIVohkv34bnKaqnl4fi8DKcq2fw7TTx1f9d16te86QCkAzW
lckKmeinYaiJCuxhe0hlvwYPYaibbpKcjX98sB7/R3uQsGryYXfCcmOogyqvQm6jbj9YX5rNPm0E
Gfd84Y5JcvzW1a7+ADzrgBGefuqpQ5bPvmH1L5PpBl4vs5cBmoYIo63TPiE4X7keIOKirZue+/rE
Jwr5PVZhzZ+HTRnbwRyHVyW8TSohPDwfKBznFRH7znceuXRuEmjnfVIhLXJIvVdQ+E2/HLB5FrUg
ShoxYh5eR+kChqy8e3VRYmsRL3aJjBjfEb0V8tOCZujW44Wb/stqmADv0ZRdlf73uDTB81jW1Flc
Byp+4ogDhw4uxYNsZBcjKNiESWWVPmZUPpwZYvQW1dXmZJ4VXoaihMJdvu3jxs77998/ITmDyOVG
BsiaUdJQcDaRtiojVALDH/gYMYlVrr3dO23CjA8UJoQPKfz+/nM396+9g4qYIam1jq8aadTt1luK
PDAnt52Dhc1AsDawHL9T+9jb+H596fr4lDWG2Y8DTFa20pKryAsmFg6qQeX2CdnkIYCBv0xc1V3D
R4vOtgDbMGag6sAKUUsJZdcWdTgivPdYYtw+UI/q41MezPwDhccJb0+aimXK7ADH1yeMGABF6S4j
0K8XINhdgmwWBY38xqyrSXExtEKDjDqgOTsxi1w5HdQZ/GWlgbHfIRbSj2dpp2PNrsmm2F9ZUzoN
vg4cr2EG4AeQJjZt/kqltFSplquuFYVAPju0lFsLMJf9XgUtwoyCbINARZHhgBlSv5n3SgcohxHO
Np8YbRlacHfE5TqEm4j3KsXTcA/blDzzcglpyD7qLl1pESC7xB31IL6OJsd0gaxweRI5NnptUOnl
fCZoSusMqaxoSMrmGYl4yzkscZxxe47/QBGuM2n+ckTLiBtmnmIODCwfoT5MlDvSrR9m0obLWujx
WTCqzRtQbSGxWh9bPsukqn5NR489msCc/BjDdA2PHUaH8ZhmbQJ1xpAWUDtL9CZwfjwCsNa4Yycd
6RRJp+50byCqnOu2Cq1APE2TkzqVUYaso5H5f33PzUnvPUFug7LqH1COOwRyuMUFoTukB/OaA8c+
AApk0QSn0xqGWIJqvI4kClZv/Em84Oyix6PlkfJf/jEPO+Um6g4v4YBpQ/uGHe20OX7R7raWgBJr
p4f8NhyE5QUkFqo938NtvkJyaeWJFbVGONw52dW9ig3TXhpeOZOZEq0k3sUKUpxPPaial1kKqSYZ
z8Qa02DnRKvWxN0nfVPB/C/XYPJZZ0c9VnFjawDqdNNrTqr4kq/xk7xPYceIW15jA2k+qIMSyS1q
mwf2ZipfmoAX8F0ozRS2XwXJHH67VxaGgwwh5yHZj4Nmbl3zDWmTQ7VKxG4cFKY6iJ8ZNjRGybat
GuQge/pY3fJVR01G5qna9FO7CLGslmvARQIR2YW6jeFi2aJ0N+OQYFyO55wCu+vdvOE57m2ESJqF
v9tlMM2BZRKZ4VR319IcTDb6E8mm3VSacWF+VOxNg2e9IhHqKgP4w/RgpqMG84T/hsFJxSDpa03s
H8GbE1S5QqnBujAZYPKsQQlyXgL17aueArcgfWyWZsN3KgGoh1m7ZJc2E3HaQrzeuP7ipe4e3gTJ
ksJt59rXMp31qD1ONzzxEeAcWOIxL0ajrumOpxU/nmoODq3NwGCmZ7Lo0HcM6Id84oZya+KvqdGk
dt4tSMLsYvKZK98Mofc5ZpiUXLJvo7ZtkQFT+OTOHqTEp77R+mweUa4Y6AUikizi5E/nKOuidyw+
1oquO+io3mTD7b3gYw+YWjOiQfmVEEUmvQFySKR+ccr4WC7VYH6uMxhFsK/m7V8zPcIM6LDbnrEi
PEbPsr2bEoKIZQW0l3ce/IfmO4GIC1VO2tbDAVrM16b4aGW8/5zy1sW3gC7NyhOpw9J4atagfmYK
Rrm/dpDmzcc8wii5/LWTfG6mCwTFf4oRfE94G1Cke9zBe5peOapkeqoJVbSPnqv1C/QLhU9P0h8E
b6MRpbom2yY+EFHRjvTjAdytLPDkocNw5dumuSAwEJYK17zMpX+BlwpWLPUpiQDv+C7Sgci395sL
4o18M9D63zzoATIK2GInNxXZvFWIt4TIoOR2nHoA4tR6tOOf8H37U4K6g+vZ8RZJKtSmssVtZ9v2
FyxSDsPM3vXDxfFeVdoZ0V9lOlUVlfX7YHHbldjQ7JiqGWk6WBWY9OEzjVvmKzdGzEmz229vl85x
EYLrWraKPlPVAGngSg2SG6ZNuufd3cuwf61IBAR8mDaIhPrCEGj4zeyW38JSDpkxlRXsAALq