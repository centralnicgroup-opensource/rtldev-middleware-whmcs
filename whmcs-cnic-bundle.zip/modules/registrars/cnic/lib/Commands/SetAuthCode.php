<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvRjjGEDV0uqI24W82kUN2681YWWKdsnrhEuVV2T/mDz84emqnMVCWKeRXobIVTLKpMtOwNW
8DiujprID/A3/k1OX4cCMPTUb9D6+lEjB2q8wgwZ4hJA/VoV2DBEEQTVuznptAWwbDmnkbdpsalX
bRIVJPXsSQwaiDlLXsqoQkkqxcP/7ROpkw2qB6p4TwVTCPw1Xs/ryTE05GhkKeuggXNaY7l3HSMV
1QHj5qwycYXxpsEvarcmwq1axwNSPP29piuZxIqRXP/lhvZxOR6zLnCA7W1iPg/sRKJwWv1hrqXH
PWWug73dr2yz8r4xsGntpQMXblVeiFf8ZmYAElHN2nL8j9BC+qiLCwS7FrmrXYf9gg1IvgY4z7oz
RvPWiazu0BUh2fV9xbuVkMP85Z5AdgfPnmeqNata5gBqKK7FgTmzNbHsSMaiGbGqD7R3LcvwraWR
D2bnC0tentPAWgRUyJA6WI3CiK06Bso966IM0YuwiTtF0Uo0VyEZHguksM2mouWG/SvzsjWr5nHd
yfZ9U5Oh6lEjXj6GXxojRDUbLZLJ4QFVci/yqfMhVkZatqbApg4a/Sj/oktq0X7kbCr34iSXPxAB
ty5ovp4ZnTh4ynUD8Nv93SeWd1DJjasahfEMNRLnm9ZrNLiGa24j9zKKdXf+Iv5EZbdjJflM66nf
j/Cp0gTqT8qHZAmYERPPgvOgsit52JAZXFRhKjjrUft+utUh8Ji+ZmXOi1G2B2SB2ZYe7cIBlHZP
FKigaT/kCLFsGv2G9YaLdO9oRORWB6ebeSS4QM+4AdC9/I+s0N4uvT/XuTmUkstbS5oO4dU1+32z
M++vDUOU31rN653AWESp3JeQCXg0yQ2mS+DBr9X3ytPFPgY+mGMAmy9wHtTWVeVDUfD/yLu/MQ0m
BKqmVdDKcdEaV/qBVSSCA9VaiafGCH1DW98obZXpiyZYypvQaHVrwujKIevPpQzouTNgE7WgDoTi
xC9AIvGKCVGxP+EACV+UbC9QOR+WO+FO8eza3/JcdyHVa/1UT0YxwcRP/74sBRiNu/v0oJjRTykB
8pK9psXCSZ71UKzq7QkgXzt1I7abfhIniGdtfMBrQZlTlqBBWmMWFJqsl5BqMBjb9z35toLOa3gx
nUSQ4gOE7Q34hRHvDEnXfxRAPCARDsPEQyZI1zvuSbDzFWbLMsiNSrWasg+SGZrcW3qJWzOvzflR
lQtBCaX6tHGKmGzyjHIwC8hU1GjTDFHa2HXHGyS1QI4vGXjgSuPTv6yRBWpxb5EWO7pa9/ymtw5v
GwR9sqO/IfCq3cmb/W61v36bVbTKoWRN35QXBgnzWSdnwvfxFbtNjhb6UqtopIDUKXHbTWKnWsyD
1bUzEWxn7Fi+gc1FKBEWKd0ERECodv+cP5DhTD4oAHOAtZJV0d/QfbBNudQwhiZ5dLd+NLl894O9
mCT5ITmBK7w9AZ3mHP0ZZnEd97RzG9Pg0xw+h9+hB/CVOIonNsiIHRbfLm1vdg0myxtjOOPSQOFr
qCWlZop4IAfXbnjJzp8R0YsrQH+wiIvKr9Ttj8DYP5EgETH3kL3HDA+89C06uUrU1Rt3G+PMaL/z
NaIFivtR1DQIfXsAzUAdBe33eI+Rldqw8fnD+W+eRMvLMpH+Hr/qqxDlwMGJxoEvBJc9wjKEBQcJ
cr6jmN4kfPxzNLrdIAhe76V/V98brHONxiMgAysQHk37oRcUXOYR6Fyu3l4WvdcIugDhRopImFpn
zMaDNqX5FLl00QKSmTqGCou3vT0Z8HljqTsNDbj/QZZ2X63zjAehUxeXTNYdczV51T29o9xWqz8E
J3ZmrhXV6QrHZwkJYle98LD/BzHu8/yVhgL76EUl7klBnk81DfT3QR4OJVCNb/iwfOAG7DQyyaX9
jn0UMqAo6H1q3XGg3tP3MYPX7uknJKwuKC3TmkCj519nHeHgUc0aEixaBnYR9jxPaEfELPa3d8i+
wGfijrc3MO2+ktZVVJwuymY8hgeqOQYOT/lmNM7rk3FQoqxfQJD5rkEmWv/Z1l/olpfPM1jwCywg
tqFZP/Zn3BNdHL8TL2v8qUxgGctN64qDLuQL+WR1hvi5oxqZFx49YRG6QX1deFiXzMcpLRQ6C/cI
4n+85j+LeI3uwDTDizPoY9cAGsH11sQF05arx2MXwbCsacmzlmRAfz83Mvm1SiQ316pvc+1DL5eH
h9uap+k3mHcJH2+0m4z93fkMD/+L8akIZUNVhiT/Zxx6N0/BgEGLpSPRKwe+9gXtJ9wyLmLJVPWw
8g+BskEbiO6hN1w1juZjFr6DQvU5wHXkH51aA0nBW9FTpFBEw0DwPqgcxdgx9rvbKGdccT5wJOE7
prIBHB6dbIJsMtFUNoG9FcHiHQooG/MkJ9ztUpRP8nmmFuAJsurrvUc5eagGhICMq9/C/v8ARFjd
jr0jJBpPMn9VwzJZWrMDTbtHjI3wOyql8QlXUAJMnwS/6nvX