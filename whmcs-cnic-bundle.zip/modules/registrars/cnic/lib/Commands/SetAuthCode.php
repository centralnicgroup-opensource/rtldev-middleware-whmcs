<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr2R0ZVnI/SuZ5UN51nndQ4qo5WdWGDoVO+ufORGvDG3PQJqwjB+O4KwOrP2QSxnsvzR7lnB
zuife9DcmizCxfP8/rhkNl56DUbVgSsTi3DMtQCPsMIT4rln5rLTiN0GbI9hexp1pi3VlEiwQ+c5
LpQ0ROt+ZZexkG/8K5IShK6IJ+F1PEI0zRYXmFrL2UejWL0q3OI6LBL5rg3tzPLQJs2dCnJCrF/A
CLk26jXyVXJXYhcEISFmpnSIpC+L9DXaGmR5MFfkl3Z78Es38Wkf2AQJCfXjy5/cchlSWxi4yug1
f0WrTr6/U3YfT9FBoyxcSKd9MmT+ikUqAYfu1rHlt+LlV4vR/raNJNm8BumdlnhWh0odsB1Fcqsq
ULF4OCQdVg5XI+l+kEtijYsJ/gSdom0/cf6ibrju8TtM1O3T76sCKc2Hjq/PtZCF8/mfxhQXff2B
3nwMBfddM80tbTvrXnsqT/QriVZWFucafqEdBWY2YBht4pHiwV1Nkl5ox1r4Dbjvv3Bo+vvr7J+p
iNvxQMLxNCCcnjuJ0quMJ+ww387UFktR5+tFFXQ5kbiin3v9SlChQ/QpCKS9uOxiUMVIEpQrcjpj
UluXvcEflqGNUmZVEKUjZEoV9hnwQbEuHZM4K1V6Gshlltt/AZG9z7HxbLoROmiLuTyipKFSzTrw
rbZZV8c3Ihr9x7UP/se9IJxblFoOATNsYFHk1OhAagV5TimwMv0b48rCdlb2hLjfPat+vg5lalXW
WfWUQIECNMU4/DdF3qLB8prweavNrw1fPwx/7DIq4ntxW9DqcdXfpzvBA94rjRzg8os2beA2jVw/
nqyZ+ancPer94cfnDvnpfq5TTFzL0tCeu3rYzralOqwukhfFCYvN8QGq6f7qB1QATBuC8+T0FOBS
39NnCeKq7MVfyvQ7ZkEXHLCDJ6edTwPtcudyaDbkWtHBkJz2px2oQbTpCvI4vV57a/jBp36XHWaT
R//BcXghP4J3k+J2CEPrQOwhyCNdKVqC7/Ooa4IJ3ZhT2ChL5J6ranNZeM5tlbmx8d+f4LdZVGqZ
cqjx2WjbVJ22PvLBGrvcVPM7TeGVNdhUspPX4ArdlHFSoWUZWxOYoZ/O1SDLf4UruskesetmGLke
ggK3xME0UA+0HSahnhjxtW37btLSYIhloM+FiY4ntw7uNwjMXA6JlWuB6ZJk7c8TFzDFed1uymBY
ZJx56zDloDU9Kymzq1M1BLX21cDQC4+SE/FRsHgLYfvA2Zy5B5oO85tJaPUbwI0kcVVecPl9k7hj
P7s1bzc8yrvxJO1ggBj4mEOneeZ7msRHwCopHvqJPf/GvHH1Rt9tVATZD7qoh/hWyIls1+f56m8N
VFi293JE63BiuBJKpg70S9Z1GM48lvef1lukIJ/ypRk8UABsU8Y3e7Xe49hyJ6JsnCO4Lji0Uedr
0S4Sy1TtiCki77iRXLQ0EtXHfQ8ehCSHZXru/v7mOXQNEPyr9xzWmed+TWkVzsIG/pqRyPxkKgVn
BcY63kf3m+VUgI9E6yT3pNsNvITW7uk9fZvBZvBlTWEOcqHXXQPJmOlhQUAzEtHKnBcbXAHify6Z
zYDGbFg6C9g5TVjN4ODsJf8pnEejsLV3c4hT+xwC3JyJp95CDJj4nBx3X8480yZA8YhwjL5d7xe1
N0WmlTu5qsyUDn+gBW/rs7HqrGeVCEt81plAnY0ryk5gKwTCv60PgDj4+jXhFo91JPK8M8eC8T/e
rRrIATwtH5N7V08HnGwfHmCamQs2YQVEner0l+UXErnhV5oouLFnUZ852oCk+Q9etwYe4258iM+x
TZrDpUHmh40n1xLy/7Shnf4xcP1/f6NUvb+Ao4M1CFuQ9z2D7nnB5tN4eEcgYvxaZ+jyrLa1gb6H
iH6f2HSDOictXlPYMF1xBY48KvG/RmxLRK/Q1BJvLkC1NEkAqi0D+/YrjgSB6BSITCh7HmB1zajK
RlxtuTTS3MSXQ3eUuekXpDCbDTP+ABpqKO8OganH7SO2P5bj5fEV08ZvcDLn2WR1QCtmE+EDBbrX
CxWiQ9p24L4tNxIOeQ2KaDD+ZeRSdxpEgiSlaeH89C+hhxXOSCqOYC3c5dAfxDgGAxftx+GUIgYo
uVc6SEmr1w3/5+7atMYqoR1iXIPw65oQIxfy2ScMRqvtC5BhEejdcDPXOtOFyXZpQOy3e/VzGDec
/Pp2/LZi+IjxzGxCTrrZnodm7uAdgkyT+jnrkLA9h5d8xrp4NQTBG9iGIfVWJjwE9x1UQDjL3I0B
xVAnkWTxXp9fiL1GyPpOfiMpXKYsFL9cFnGP+6LI+ygpKZ7u8lpJWInzAO807s/fbgHnNvi671ix
qyTOqAQ5KZC7PjDigkNHmQCvvEVG4o2Guj17FS/4Z+20icfDjcWDRKAACrAMK5Z5jlMXcDv+wArd
+pD7nMLOz5MnLHTnr+3xoulmwMRd3i4HHJHIA6h8z3kjOJM1/r0=