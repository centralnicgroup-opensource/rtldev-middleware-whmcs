<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvR/Fr8YhaQd5RTCnm4kH8RjUD5Sm8VDOAEuM600fdncTu8lzMCVol57OiOROm8tpdrJpvJe
rAFr7Rfaz4DBrBWS7t2mdsDb13QvHQvdA/X1cKeKkJDx+0hf/FsJzDesjNrwTp4LvfskzWcZihfl
XRQjM8mDPaZGvO030BzIi+3qcIsNJ/XNxhnUHpjrocr5WRVO2tBfqYELLFsSL7aAU1mW/fS5v8Du
wfHRqjJjNMse5hFyD86BB3bWTUS1Mi0PXGmnxZxcDrKHnBWZAa8J2NHJAsvdr9rM2cJZAtpzAtoj
5qXYfv7EX0ZN+fetZOC7TgZR1N0wtYDh4N2oJE+a0i8DgM+2zjt8gWxAPoNSM13A7AyVFNj2Wa70
t9FRyaNcumVaoYjKkRe5+9AoqDvyDkzklpM87dWk8mPoem3gkOM62fG2Oi/AxseTgr/4YMCUyyPW
p7uW/D5Qw02Cu6w/pjbGY9YRMq/FP1DLZgSPYxGcgvAGJyVZzcV1DT4E99gyVVOEBk7Uk+VH5LrM
WarELze24gOlkbt0jpEnat+/Xi1P8sau1ZeP5a36FI4+74l7Kw5YG7W7VP15nNbSU5TTMaXTywJW
unVabb4zQHg0v8hAJsdAsuXat3BMH7eDD5SH9Fd45B2u+ZNxMvoKw7/m7xrLQB83OIh/qm+mjI2+
pxo7pRNH5pk5W63olv8IHSjdJTp24UlHDvOOxMbcVhlHDulavojm4sutPG92TMTK0VytZ+T5lB8b
qA11OBP2UF5K7hHiH4B2VIWbY1WW2ryuzEeOQgVG14FiWHo7T/v0B+l1WuNyGjTNE9uN+5ZbEJGa
tXZQtAkIqpHGKYal7N1jRgBLa396KV9xZD357R4p0x3W55jeLeZql/eVFN9xVyYxIu4/87vcGtsh
/BMAVthHWzNtjGy7gwA7r7iJddg5FtCCStRzjOD8+nyJFdqfb5RopfxIHFLywtof/+9eRCZoXwgQ
WiALasC32suuOVyzdu8gID9ldyLrtYu9qhCsORbjDFfMO5pbb4a8qKFYOY1oz64woeRzLVpE0EI7
ArJNSTXdYY/KfTVhKBTswODV7CM3sUgJB5MtwrxJ/TbpEQIVurAP8ZVgMtmRFfDo+AH+ZPsmM19G
uIEhldYS6QaAAH0NSVxhosS83th3IXGUFU8eec1+ZNlLAN1xEAIVsN6aGqQheiRmaREBe4uo0g4p
9SHZ5Nh7P9EPmk3aflyEr5tPAq3xsr/Nr1uq9SdUsgXFaWo5yuGMl4Ro8+vFCYTZo3CkoRKIB2t2
8ktQe9MM+JA5mv/u+Gxawl8aL9obqVNgT/EPTcMj7vnuRf0Lq2a4/zQ4Sm5jG9mrqux+vw6C5EWW
bA2Dwx93s2oln2vTvK6OhDAtcjqzvB0AmxpkLT4ujaGjyWA6IpvWjg2vk7UdVcbLrnLmKUq7ZgMw
GY4dwBcf8L/BcWsPUxcRfUPu9FB5XM9arHxZ/HqOB/RpPlFwTw3q/EfLIJSqBx6pZvw+tmaklUNp
0S6ZGXiSGwdF4IyOgztWDhJIDOL4EsYT9AhSgUnq65mPFvNu0LsatLajkAVa74OkWnG4/wsjPCwQ
IiieVq3yuD1sJcqxHxu4uxpT3sZbwsEZyo5jj4hHGrM9iriF6ZgCrjpGw5zdngm5Yc7Nte/uY97P
6E0AF+jbync+JGcNFH7CfgWc56hXJAFz9Gidh6FtYic0jCSS3l9MQYGcd/z5BSeVe/0uCKz/BOlM
ehqT48sFNxkXDtfJHcUBYIu7BS0PSJMyHaxkvyMtcGZVGFQ+JPpFaCAA622cWOj46JgrSeKEBCUp
4YgxngE0Pp64V6SUlfJR8NrT4YqZH1lvsX/0fDEUiSpdFgsMbOZzLnS9gGtam3WiNebILMV5AC09
EExVr5xZ6xJm+BbdNqk+XFVQ1Q40ETSIBclTdjexmT6xCnM0bBNIKJ2ZJyPUCkJWuW6Odbq8eAVT
VI3hIFWWK05EjdBTfsvQJm4Il9guYP1jsKtjuDfZDIgsb7Qu19M1KK9YKl+BG4vb4Ey916cHSNxw
Xh/FBQLAD+nkyDNDsMS7JahTTodePJB9Wz6BxjEQxhS0Nfkm7U+3qJYxDLDsIgU+ME6ly9FNcwr7
/vSGgHOn0xpaKcu6tr0hBOT4wg3mJ/+SEV7pDx86w+EpqUBB2corvW/5KU2L2XO52iLcc17lKO70
LRUIIExcI3cKzgHjWpQ/TvYZ/f27VdXUidbkH7PXQikG3FxQTeA2Tzec4DLhUD5ez2GbhOcmmjib
htnPLUqExp80tnkWaL37nj5lk4kNUlhtfCfgBy9v2Sje3jN/FkYnP7c0CUdseGvlezJDI70e/nEU
hTDg7uS/aKs/2Cs+H8zOHrY+y+LoGN3Eaur8/b5+zwQa8LMKlij56zdjUGkSB9MFupNrgoRug4AG
rLo1Zs6d9k1Cj7AiFrPVGLmuo+s/XeluTV/k32Jph6OzkcW=