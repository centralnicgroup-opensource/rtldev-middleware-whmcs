<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyStF+p36OJ3ceMgpu16LB4NHQJzZv6TD96uixiA84zqbzBdI305nkBbrjbQ9DeTJVSu/AsT
fjGKC0FeUR0CCqXrDgstAZzMeKgWnGo0fGbxwa760wSrUom01HoGz/5SGtteaGFXeqb6ws9nEl1H
BLlsDtmecEFKnI8iWipFUrKh1sZTuLyjbbGAVx39IY40mQvMElYJCwD7Y1P7S0yXS2zixZbMn2dX
tCEufjAUca5NJ57fbZTNzyooTyn3PyJCm++6mbNL3Aaz1Aeez3//eS++rdHeKdTnHQHH5O1uYH28
1qTe2hdMZ/QaH5a3hTQ8Rr5zwOMCVKnqLa86xFCESIDkKT56DKSGUNoZhXzPstOUMGw0B4qaoftl
1HAuV/IEddDWqUlGRuvYrIRLTPtsNEzRhH+T5gcffGDZnSYI6hzC9ckQAsv7ceo+eXYbN/cKiFV3
RjXqku3Sh26NQQ2Rl5KwgHGru2dDlqpVZ9b4sj+HWmjsse4BoG9pp6Htb3TIjtbep+nu04Gb0DJr
x7OklpR8aoCdvg7nJDEk5UQSDR33mTB8+iUJz7ZcFS84wS3uu2AXXisBRzlzECEKJ742NyRkf6G+
2426iw4/wiceEE0aiJ0S/0fXHOxvvp0HfAgE2pK6ZAsMPOC68o4D7iO7JCv5jspoquUjiO6CNzDo
Qw3ZNFEIfdDwi9+YNz6lm4zG9lL90C/oQR5I2Q0/blHu6v031iPHvOS4S291J19LWl8sieJHHvZA
yy8Y+H3LszivT9rh7lHWtn7IiN6anZkMoOGv4dmSfLizoH8pTPcjTLE3xk01AVownOBgM2wwsLgy
v/8aLbX2yfN/0vrIrZv4LUR7eIcVUAet+jZx1453qtEvssiVyLutjH1vHo8rlZzcn4BW3a23IsC1
5FLvjP7yfS5JIzqO+2Hv11t5hy+x008u5hN70VND8K9dBVwTOBzNdtrC7RednA+g3PlsLen/xxYd
S59xZxzdjr5CI6Vxm5SJOL2z0svsb0Cdd39OI+ta9a/u4fiNsTeHloyupLqpF/JyN8dVC321Fozu
H4DuTiVyy/f+DoQIyaLU1cjXYTguPod67NqQ1heuH6bE2Ttm8hOXQ85MTqcW68kuVe1xepDKAUrO
Ywlxj6NBU0w8VHCGFpyaTaSnwy+2gqNhmvr2B/FOPSE/f5+/f9HDCmsJnduxLabCmVGX453fLtCk
SqIXbpLE64YURICRwxOpfFduMZRPUhedyGoy9qa28OvwCqk/eUKEkkd1JPqVTTJIEvYS2UNIm7Ve
UdhzwY1A44ITs+FVttFJwNfpLo2c8df3bI53QZhFR6Qf8tdb0k18oHLgTODW7788JDhh75e6/zfu
xLOGagK3uwubJVhSvNrJWjqolD7hHCHdKbqQEmuaQQMlGgb6w1KFOqnQ3A7U0cKSHS/ebzOag8Ux
EfLaU2utuCMzxggGsbtwazKivfb+KdZK7Jr3atp2zZ0iNEgNIXA6U7XermtjsR10yJ/n4yLovAia
5uftou69k6kkTRqPmg83GbHGUNG2UzIJp90m/VArCpDMmA/jCGUzfIZ8VKQmZGgYfn6Lr+s1t1lk
jPtqYc1kVfT/GsQrTMfjdQ7aFa2Fi6p5/zgGmPs1c5iYbGVMi1psXU9EQfYxX9mAe1gm5mQ6qjWm
JT6B4KpaN+PpI53MwUv17WJ4AUeFq2UAq331DomOK5HeQ5ud1Fc5HxLYAlKTPn38a2dCq+nV+uEL
C621wjkPAEBZ+uqYabtqS/fZj9mizk85O5A8FjyFLnN83QhUEZIq5SRN5YLNIYcVJw052fDEEiDy
NRo3hBtH58xiOhZHy6RZL9O9hG24AUWH2fyip0a57dP4XCX1dm2mgGx4kYZoqgPMHYEVUcjV50KV
eBZ1CFzRTCZURJfwnQRWjDZnh+axWed/TNCky3UWScQY5BIwV8k+Zm+C470EaeM7Exr6QN3a