<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw/LXJFgEtu4ysSG439sMWr6FsiUXFXp+EOfLO7OuLOZnyRZqNz8cJZjb2P4DuyD+BEwdUAR
XxUaaadgrxCPvZYQ+1JZBJqvWde8QJC2hlKaRlE9qJALJlEIf/goPdcd/girezbPCWrN0oGtIR0L
wDG4pgrWBLAEkYLSppYIquMLHxYoK4pFZLKhJf+X6gqDPu6TDF7AJwa23Ei3OUAMIGq4s3vpse4W
Si8aq32KghGdJObKnQ04w6HSnkU0FNrQ0xIu/XaHMC4PXujdL7nGIdoPc5ctQ6PtRdFhS4bEk7W3
Uvtsvpx/KVhRzW1kO6CbnAjEzQ4ceUCsuRZHNRIHnfPVrx7b3482CD5ZXgIFO10/4llZGpHfcyRY
idaHDNmX2/bGC4obQ2xk5gq1uQNhr8DBfL6ttsRIPWhLn+jG0lsH5eEdmMNKGxHEPXZ3hBxN0kQ8
+bpl4IiZBKANXwRWWo7BubiSUt2hkM8WzY7hAwxhO7osQBm2GqeCtD2NElH31h5+FpMnlh0hOPNJ
PRfSIb61BxGouqcON45r9S+aeRLCdh6nRba/3Bm6ft9NU2giXp8gfbkBZ3qhEuFjoZlqm3KhMofo
OW+HX/g0LTjkp6WiQ5W/oU5Btrynp+SZq+0vIJtKtqZhC/zfCeVdOOSGKuauFhN2lJFb3XUc7X6z
vzXdClyZvAXHMJ7zThBQG3wwj1Yz9Yngpia602m6JdSgVVrtLfQdetyMSVuY7mvJO+9QOEiZOccf
6cfyarI5TsiZr76SothhmRxWqtRfEc13BDyn7m/Gzv/DEPVV/C8FJE9kZsee1fXYIRCclB5r6yk0
tgGdX0lxYRWBjNG+npf1rr5vZKj94rgOyBWctsH46xc2u2yX8kxBghDYelgPUuX+llDRd01gSBcr
QsePtWusfU6AvNsEP5GYivvCtNgFO55dAHGwKQTTRTtEST87cW0BCSRqV5IqvbpFdIVkgiA9aRNd
xGO4aNCaeATGQISK8UEVIvaeQxd59iaWYgEZUSviqPsYukdMEL5rkF4AGtzuR5MrqeAsDh/zHKlf
gHNlvstGnRg91Xb6Uj0WmOT01g4T8KTFHx/lw1ijWFqIBNn57QBjSL2pyoPaqhw12P/sqUbw5KSx
rWYPWfa/lOMD/riSebnFyuEw/NuRHmORZoo8FTD5BmmvDYXIsctOREdezTKxSQ3N63k1tNs4qMiK
30durTHbQSISHd8OxwE6kF8cJJcBIHX9WtBc9k75ZzAKvPSbKgtSjosc+lLDu/6zxf8U/GSXihsz
o2SZNDCmMg/gmMPmQ06mgs6IKzq2bKnDfMPgXe6wy5PDRO6hWco5SHW5iR/+CgsObIhMPwBbo+Y1
YN3FGh6bGWdPjYc7OnyqBajb70Lkd0K9bu+ITSzmVVRAz2JDs7JDyWi85tkO90BnFPHg487BVlAW
yiwEhD9MFWA13EsDRUyUOw7gZJ8XaGjBT/oKYnMf5qA5GGp6lGJsr2J+QwRcT2IYISVrNnKZ5bnC
lExwSyI5Y/EnCF1mI6HX3npHn/2rK8koDqgaGG7azYWx8gn4bHOxrdZw35hlJhZd55nabNrfS2pZ
HUIf8/xtMNYXOd0or6vUW3DnK+cqvj26RUzdnHF0kRJFuiffIufP8YAQR4gVR+uzKcUgyoSffN0g
CZWoEchjMKKHqfuP0F0SwaFpHyU0igobnDOK3v/BLrdhVtv2trYACt8AUrDY3vHIFTWv9VNaQut1
hvs0bN9FJaUDU1sRhsguqsK+curVH2NfpWglgVBrEjk6wIyMpDCNgtspBg1qfZaduW6NnZz/Dv2e
eFnmmCbD16/LvFA0tfhb+dLqwV7ERQtouiEoyGkze+jMciWXEE6KFZdN55ohtxV61D/j+n5M4cHB
tH+Lj2E+XD6jjmFbEWjALxIL48m9tcI196ZkHeUxYGxcaIz9F/BznwDpofBCy5bBj8jl4VO=