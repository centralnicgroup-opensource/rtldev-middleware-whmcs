<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnY1VaoWRqDalJFhRtI4HJ+4aphkGFhbs/APLFZtOe4AsoXwPvHIYe7x2SWjZ9LGWfrp358s
2bt94UuF3weKFOha3Ir6FUZptvtLt2hGWfszUgWMEW6fZkskduS+jJeSIy9rCrGoEfepvdoqPfge
lVbuMxdGRMMSDNFQblypmTfUzS1CTBBUX6bsR894JLdZZm2n4Cywg8F/L/2rmeHgpAF0VIPCKOYJ
Ov3GgUMSkTwed9hoZnu1TY8WvbMcX5E9cxYACb3qNJq+iX0rSgIm6ilmbiF+Q+hkqYCla7WfOtA3
xKMdF/yaXww5GQiZYrDZOW6tphmbE41H2D49DDYJvQdonBsMg9WB6rgXZJOVQMD7pdP4AHrJCl8Y
7/3+/lPcMzzaTyGNDU6jA9FHXeiL06PnGWyl+nDFmBRuf8ib9bZEJdTWjbgGXoZvYjwFP6X1+zS/
jvvon2doPhz8K3viLBsQMWvkbRm48At7cqjlDhFbQsVoBszk0HHd1dDo+S7kqrONVzjV7o65AnY3
jS17l/MsOnBaU6II7GNg6BvYbefhKmtrsxsc8HIdAgHPOMxioHPZCxsbB1fOYpcWvy6t8jkGmh5W
8mRy8hz8MhQxTuzURK8tvOtsglQrOJba5nOd+361ImTH6IHcmO/mUUCngBX8jeOsw2Sv02vLyYFW
oYAHKG9qDciXZoCg17hH1e/rRzDj/OA+Mzd4DJ2WMQV+eDWumLq5fUo4Hfr/iBwBTURtTXeuKnTc
brfFlI4xzYDy6ft3SJ0U4LpeCSkoeuw0vGuxMgcRisqKVDC8K4UCK7J+xp4bySR33k6Kh8ujD0DY
/2z9/wMnMWs2M6W6rCVQUm9qYDeOQON9GH49S5tfVaBuKj/BABvL166StzPCUdaNsdXwx8W+cDVv
HkJVl5fV5MrQ2gPE2CHVY1ovbByIYcIjTz37Qq85hdoLNKwCckzmyT+irjtHwJ0FDnD0ycNdtHGn
pKQyesjm94HV6YBHqazMBBGNj5Zrnml7ge1L6jqHbw7hgUmWMZwTa+cUkMED0fT6MKK/UOwH7LWA
BML8itVEa8BtwfWFCfniwLPddHSBPDyGfeJoYjU6IBPv3vclB14DcQVopA2FRIcet0Oa3datHyIM
RsOOpPO0se4+8w710dhk7n25oJWRsChpUN0jB8qcGbf6dZ9dQxiY5A86lxrY0LSO8X8LnZ9NUrFO
siiInkDczJY/rjggpXT55+RlphtI3xAj+cIIYMHs8MTejQNcksyvHdn+Z7o1B6UNiqHs6yv1w0Op
AUcloEJcJ9gZj3eHx9KgaXe5mqlk6qvmUqILO7qxVmJ6HxdI7uPId68sMebVIF/DZxN6vzjR6pGL
suYY3b58JRj+i+2ozjig9B7BE/dFJWiAy0RLU6EcYHTBa0UcQKDgx1Hqu4zQBFBidVcU3WjkIzqS
UB0dMAFEsIm2RydZnT6x73ZeN4cmxBG7mRxRvvBl1f+4uNMtJq3L+IO+ZN4zWnuPwhcADPdq0tW3
yelI/ge7u0qjWfPxvwVDBUGbBonTYbitDTJw3uSLcs6wH3WTvAw2VyzUDnVbi4UcvLLC7YvtrAx9
NrvvpjfJFumdbyTd4x/cILiK6qTbvo/yUk3k3OC+fcMdXtfIZRjTT+8d+XhIFeFn+NQQQkUSbBr1
uy1KaidniUItaQpg5y8BJMmsmP/ZIdB9h5cOytuKc8h0viCiz/pR3RRouMjfUL8VNDDsvWJzmBuD
eioukBQX2I4SwHeDVEYL0k7euJilMMThzEPBrwi2eB4iZZQoFG8sSJFDT0KCo2GODZWXjJD8dbwy
yA84tQEVr/A2EdKmLN21MBeOlQQ2INw4PrWHYrw2BpxKrjJQNJQD3WPF4+NpKFr2hfDKIsjU6Ls4
OWLxHzn5TkJTnx+lWR5nclaOXSHa3vQF1WeLlSLqzyevmuF6pRz4hWUv1bioT0==