<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPySVENsGu85oRQsiNjo2reEbdC4lYECkpxEus+OsEKMmxOSVTtHoNHavtCOWww/7FlH2HKPj
GW9tYu5muaukh9Vbr4JY9fp86uhVSNH5cCSZG8VdDFur0vAfoZggCMX2VL4tMyzMv6QHZ+77NA7L
kLmBk+06ALPiFzUKgb7uUzenoLXuPCKs9ZSV0v03j9/694UoYNKjNFLBse4jfvh2syk910UKFSuC
G413ppeKCE1I7w3C2rC85etZ1hUPRA/CUXLK38PGOQjJKu8SAFAUjXXANNPaDPjuiLK3nezyzHXN
2cT02K6LNCBsAd1Adu1mUFMvqREFi7dUGO3KhagYEe23d8lhXseCNGs/Xnrbp51iBOV+gc0kZawH
/G610Y8OkOzNEToVSscuHmSb8ulnFjSNN5mhGvzIa2w4hGVcCN6uedGf9kTK6BA2lpjqLHxwP3Jo
ODUqqaUfM8NLQQY81jn0b60nRZdgkmoG/c8UWlqIAZJHbXKsV6/hPZSFT/QhoIeUw72S9UHpY7/3
cjH2zf2aB9V09W2geJI7URVSswwTyMzHovLD88I3gnhUfvZpqMmhYSNOuvxmj+YJrXEh+DgpahvR
cTvMx0aVMo05/SqcM8npoE0uc5rB9won5Vj6RxD8VlWZR2/HqS4+xAnwYIZ6t4TBH488TiHWXMy0
bfHjrzqXUOljLnBMhc3HEx/gnieaNHIdJNKBIKdOH500tnVU0lY7GAzd/CIgIpzuj8bkMVY79IK6
JsVr+liBNGU7wrUliiG7ldptYeYp0XgZTybvSTNm6of+/pC+eWM5GGwiLHXFTZ6oqWe+MwBMN+de
LeT/DMymnaa1KC/vL4ronlC0ZL3VkOidaU/YnenMqclV3sZi0IetcYVkXRbdL49LU9+xJrPK5FQr
MMSMXTWQnAX/a/+4qlqXBIUFSJej4j5pC7Q1Cq0psBAAhqbPA/PJa4exYM8/g6LOssb23Mddtu8Z
VAPTXKJH4clqVly+NhmnVE/K6W4Q56FGL2oAkR+s7H9HQxPxKRFKxEDbr2DLLgwN49ye91o1a1/6
tdQL4le4B8TvOeB/f4SoY1OQ6J1FgagGWiRKCcPqS+O2TmtUtygQAmnvCKiKjuKNlWid2bkz8a5a
yyMGmW7vh3bejTVcKE5p7XCKk1WdFY+jtAiSheoWV5h2oXQq9TVb5uhUhmrHluwIw1pzwcbub1HA
mg51KmkKGw86IXEnVuMNhMPZZTybUsJptEjxnIqpiNo/pGIG3Zjm4Yy7AqIcKtk/vPoqbjXyZ5fw
K3yEG2vX4mxQXpgDZv7JdashmIbB453UGf/vjOXBRKyKG6/dhF9d/tIBi3+UJAmjiCtWrvXzXCee
Xd9eOA8A4Yf1VY7aHCpJzxKDVNBUOehiISwjyiv5CxRW24LUeny2yZYQJfDmqc0TmYS/P8jVQ+oQ
9+QYssnVSlo1/C2J7EekxrROWctFlI3cVRE8YzzpG4JdE2D25rcDzUr0HO+DZ8rVM/nS+esi8e7o
waEdMuknR6pyrEqnmAr5panWInGNW4FJ7AaIeAwjmz52Avevfff4tQj3OU3UNvA64H1PDuN/XuPA
REgnQs98tXnpzKgBRJCxtCRXg7s+k1IDkpgQKVijjA2qioZcIxS9gsxSbntou7B0tp6JrCzKAUjP
vNmdZ/8HoZICDK31q/l1EBocxbPMNG5kWG9JTg/pkuglsKDOT6MKFw1yQ8ICyBSte6ZBpQZnW3Ts
OW5yoqIWngP7JxmsMxM/QO7GdBVZKLrKrHxgTZQ3LWiBnf+mk0nkeO6fluX68ttxzSZoc03axTTl
oKdgR1bASI0v1znBPJlZj2H4YzWXDpkvdb1uFQ22P1mvIUHggruDlwJO9pjGv99/KDcmQ7Wo/Vdi
bWi7u0Hr4xR03+OCFrieIpg3jRcBt0wiLVhe0GTmRsptNRJQNlpb