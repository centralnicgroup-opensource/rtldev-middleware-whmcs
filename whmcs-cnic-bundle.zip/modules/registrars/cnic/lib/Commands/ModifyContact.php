<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzh9Gnd55xXUa7lMEjxLQ/0B1onwufTlrQAu0vAG4V7aDiVFlXCmZPqQKCx2WYY0SDUHG1OP
cvdOBLPBbimxdEmVvSFsPFvMIb1vwml7PQgKEgLQh0m9whv08vBLTh0CxqDO3X6vG7vURJum7zfp
gX6E42f1z+CXR4aNJVb6oT2wlEEzmVO4fIpfeQMiiiiPacwv9FkxMBXuoLvb1aOdOCAybUBDqf8U
Ns1Ew5XLIqNsmHjqR7fkGyTmmqOKV9/A7/N9QM4BibGvDFIXHeienCM7UhTekqymStMgLAHnFevt
p4Sz3l+pYhhnwVYMBCXITHVOdGeAG0lRV+X4dArk7e9zB/Z/5xM0nuoY/TSJnMdNvlixSQljsrDl
ziIvGzVUY7Wr3CJ8RdP3TtUqilGa46mUtNd4h1AAgWolfYIbl7MOapjL51jKOWaLBSNbGj29su46
ijcqNt0tPSbxm2wP4Lq3rYewaxQqHiOenfsj2t5HVFQWVHhVeDCzST9YYNMzP7esL0PAjUuki8+w
CODhr6JqvL1u1KNNv8QhyRfhrE6Minjnl6TUumn3dgJj0VrfHt3DcHHRhkQlXAp5Vn+64ZhJWLjW
ZwCF9EyopgiGdjvafxp0+2aHRA8j+2DPhqC+5QxwCQ7+XcNRKamOBMPTotZtCd86zMmv07OfLLyh
uxzYYZYjZ0G2e/z5pIUZpYByJqw8fgu33KDWgtAw83cMgQZbT5PswhEveeEnk1jvkOJWjdGYXegU
ZwRA7fOHpA2wQk/0LGVgwmrz7IeIT8bmCVHTvCLJOsSutKN29GCYFd1jmBu+PmbMKYW51Wmn1cC7
2OXr63e0qGsbpdaCbG76PhwbI6DCwMZ9JjdU44Kw3IjNAXk1c9LRWTV8Oqr7yegGIu+pHLFHHL0J
2a62gdq5XLyZcGETq2ax2CB25j9HTIgZT+vjbMMxOxCoHI8pZjGdGNS08lJagP//SrAGE2XYtjEH
co/wZy/MXScD7HgU8MiDCHCE0NTVi+1vNeNplyrMtTkG0/7oHpWeh9FHv8PocPzjfgzNWfBwTqQ1
raJSf09XUW5KfBQ/Lgs2W8D5yII/FNR9s2ysOtVbj1Ia5Xb1zcDr/9vzkzPBin7nC677FUfN2fD2
MsmayMaJfGnN2fqf2rQWSnGHFaSsFXFAZBB1L9j0yXBDOu5ZJbMqhAhT20jO+Z/5BStYxuqYQb23
Qvp6sDCjP/lEMDehwj28I/3ZBxe670ZH3eL95Wp4d/aLIxQfotsVJLVDuUN8b7vrnGT6MDv3+EPT
iccO4P6AQPM3RKZfDPXbavp5CNoS6RJ6bgGQBGN7948i5bBrG0X1faKQ071HaXemHPSMWbZNs5V6
MIaaso92s4PGpUxo5Af+8hjG9QGBQu31q4oGNMb8r9OOk6Q103kZm2cJ3wrAATyb0DpOgt+maEyf
2iu7QGSdHbWmn2TiFhymjbxpBrBXGmUCB+tEHghMTkNqg8pZA8sSk82QG4F2Lkqeb5XSoBRyvgA5
T4PPd4rJcpzxjp0lDXAk/XluLQ/F7Gj7grYzivUD/g90WI+l3Tud0opvax3+2faDj962fd2hAcr3
tOeRyykBLkirgA/RAZW7A1ZOjnn19o+4ByXg4N3JlzWoB0EYGGLksEQO/L0RMC3r2RvHk4UGSmZK
JTDteC2SQDtyXyhL1tgCa3uQ2r9zhI2g9oDzzyrlKsTc1ytJh09wBkW7ueGCbSg9RCnaFjJmqrEJ
ltGfqfsKVKUm/lmbTfMKIN4wgAzHuLuMvKO2fbw6DJw80cKOwZdLZZ6/a1gtSLkrJdmt0rruWaK5
Ml88fVmkcmwMpvJ82dOegei9xbvsan008m2MnLlBc0+zTulDmqOnkX9UfkBU9JPyJKRhrQO7iFmV
23rgW8v2EvPlX6FIAa9pkopEfONokPjI1/S++V+yTMzVX3FbrBylayJymL/KmI4HXwTAd5xlQn2D
1q9khCemyGADjlrTAn4=