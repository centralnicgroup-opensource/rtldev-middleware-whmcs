<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpkZzT6QZCxcOn5Wyefa6JvK8++gpFdROkecM2BokwjTFSco48zWKGSrS83wSW5IvzIMwRDM
WCWZi47KNkd9EgkhaVRSC79SkTTl6a0fpVgbQubLtPO9sOUu1uR1K1n0vJhggvofpjU6CIgKd0Pl
PEzv4Ev5RdKEJ/xv4DDEYu14eeWk83ZYL+Fg0U48cVqSs19kzSORMQrh9zaO/OqL6jPN4X3YSQ8e
kIzbpmbln3fTf1QFWO1jze/58PWdilE+1bn9AbZwRhmuno3jWo8BgGYcapABQL1f87O3boT9u5cA
0VHcVIOV0rffP9nRHortdDZPkukODLLwkLBHuUgC8sK3OjdoakZAWYKCBftKLxJwa7LoTAL6PxT+
aZF9ks0Sx4xRGo9hDA629fn3RiuSnVtH/tE7Ay8MzHxKNrPvJavMVhzdVaN5/DO/jSJtu5XhoyJi
9YeqsjQmDh7Bd8Fa3AH4VxtnEOIXxaxAMqSKdIDaLLD1db/npjWJZGbLNa1T4aBNo1XaMG95m8dl
xPhaBc3Wy2cI0frpLE2ZUNqho2+chOaMDB3y2dRUCWHNCtaMtD+CEJdAmNU2RjMl4wZ7o9qeRIEN
4JqZw+VvX7AXZuF0jtKEZfRd4A80nadez7+CLnU+FOhZXy9sNY0xLYxe/5zbITsjDULXGhJqPhiY
t0Y6mHOq2+H5FmThl7hmBwwFbCkgVvZEKynZHEg6CHWUMFwQ5IsHfpDUc41HorQl9OOs8tzdSMOz
2EplT3HWyfjjOm3Qcv8RTbQr/TIxQC7jCHyGfW3yXCJxKt0FtCPmR+yk9p51C1BuTALCt92F4+IN
zaSMnpi9W2DlESn5ViEsV6q1/5gKDOL6Iqo940VM5aazOV75rrO2BB/OqBm8sGRHoYZYTct44cZH
IFI0/MGzcse91HYOMtsN7BIUkfsRnMqe0pClzDjV4Ssy9LBe3WZVTKxQVITXmX1iouEj0ttZblW0
o+4XylWFN8sVMWCi/BwQb7O4mHBiLJR/GHgi9yi+uraHHb2BGRBXnQ9v0yoIrGSOWFPt/S+wBUQQ
asTw1lROwLEZMaSL3xT4M1r8WJAlReHcHBcdN/bbP8Bkl5w5JDKctUH8q29n+Q/SEIkKkKm2UX+9
nLu9wXF6oO/T52WmgAOrSIk792qnn++0BjkKA5+E1X/+HZtoXpyM6ADAMfJnTat2roX1KjiVriMb
5+d87vrpdfYW8XJifkhUGxf6srGIK41yS69oe3AIvEPHtYSfRFaN3l+plLPGEU8uzCdxg0gxsJH8
go0fGx7d42Y3O47ljLY0qQXqYNVMMvm0BM5+++OghXlGrS4gdMsK0hpVi+o4hh0sCgYnDQ+BQefo
gn9LnK5k17CcvHEuMikz7q9v1ba3Sr/1ed5BfBTc5+k+OWV6BerVjOiArXBQlSBfnk9Yc5ahygRC
5HaL+x7178hxrHDU3a5UmHLLBivbu9lbE5KVPrvwp/DFOHFeMpCx+nWjLnMyYUcPG7UXpUHN8wqg
U7ho7fkzReQSds5CnMC/JHacAeIkDO4RWaLyWHawnXxM2qA4zIje/SaiuAsOXhrfI/O5fsHTnHVO
bKWeJsDHgKOiEbtw7bkmDKGVZ+1zj4/5SBEflrB+HPYZ8wwDKxnmebNcrCrrL09vYwMEjSi66kqF
GCyVYpGhg2+DtrzRUqqYH7qcY5REaUtY+lvGLLrj75GmP54LxDaaZ/6GKe0Oj4fUfNjwvPG0RnQd
aGu06D0CLs0V99+Zp0jrwPTDnM4EQAn6vcOAIo8bMOtnjU6d0sg2mclSh6640r6SdUbZBu5gGGsG
0NPggm1pHItzl35E95tNiyGkUH1cUJRkYfetXDoRjptII8v2AoL5eq64xPWOxkJ7LDOQNoLnCDla
oPTBW01kzosuxmIbeSIkZApDql4wKDGjVnmUdYOlNYn6OK1cE4OxjQZNcDIQDPVeMZtCbQAKMhIv
