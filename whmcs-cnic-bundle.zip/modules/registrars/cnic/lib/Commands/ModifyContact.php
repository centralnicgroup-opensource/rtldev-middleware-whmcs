<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/y/iDk0sfmWjwC2JgFJhtez+156EFpPwTC73xmkEUsCPfwm2Kv6jAjEdH09ZyAJIt3L1CHm
i5SDJXhLzU0NSkFu0RKOBtlCB89DzGrFBrcjGzcpXmqTX1Q0rUtQ7A//ikuGxw/Qf11+WPciR15v
uJwFaVh7cgZqn8LR55rUT/Ma0OXmqWEvcOUyuzvPfvucBtW7rq+jA90Y5GApByJ98GqWpXJfT5gH
ziiBYtnhDPAnH0lQQ+eMZN9rgR4M7JjTzT72LGvuwW2FAIcOyaxrHkcg39jTQAtR6vm3I8lW4iPc
WRHeRr5BsU/qmmSoczO7/uwgNsbx8nLtTWt404sgryK6gH0z/JONQMZH6vk3QzMi0WmCFXW6j4BV
ZB6AUDfVQONlyT+lmK0YzDS9ht8pEdBNdpDyaRMFrbPcX1pceDwl9/0BWADoBzp2pAddkzH29xkS
sZD4yiDY1gPGVcca7V1GlbtfvW1TKfRHOuzDXLc+hCphS/ettn7xwQSr3UBIbqzbyvf5aRgVpYhT
DLFsZa93OfOtFqZd9Hbl/6kEs7UnbWvSHfD5JuDOLgpHTBGOl4X4ugLzbz+FHz+2tWD0A7j88D4W
Q4wpKYJUm6Bcq7UVZhKgqDNYE7XV+1pk/KazHnJvoJjjZzT8/MC1iLwzwXSH+nfvzVlV2/yV3vhP
xxfRjQXJ6V0pX8gA7VubhPyBPk5ChbsBtRBSXwqKAk3Bbc9FTG8kSQmab9abGE9iEKM8KFOddWPX
DFgMFtMotuz6NPA/qGoL/GWcCDlRz3Fv7VEJ4bss1+cwijLEb+dq+mlEfZ3HI5yCbXRmNd9B0DKN
I0i+VWUW85yONHoLMAX+iT04VpAE3p/jVCxuDWq7oBe8EgKrbQFBv6e5CIPezu7+GKscsuO2hFIc
0xsLunU2AXtMTtH124flcMAv6J4Jd+5AdBYJNkYFGpaSdFaQwXBSoiLIW0Y12qlXjIuzOhQK7iGK
UcdrDJXRVfd0pmRlYW2i3N7ZZGbkNAa8zR8qKqho7krHeF4Nl+buDtDf94b+sYKRldd6qvVD4sJ5
4e+xt02F9kzta2GwsSeJKJG1guW4uQGHn91amnTCRUVM8iZ/l9DSkEn5XygfvtEiOJyBal/v7VMB
jXD5UmS+gRXpETlUj8JaIu6l/TJGXn9peYX7PKtbZiVT5a8qFxIatyxqIcs57O62e6/rUawcg/ga
H+dZOGlWGUDbLQwLQoePtO39SbA1MqQm+XX+QRmbX1KGSxVn0xkA5kCDtorxF/ETwMRAw4U4I/4c
6E3KqcMFwWkESDdX0BXwDtgxarlUen/TLLr1bE7ro7QKsKFirS1yAsflx1uUMB/6tsYN1HrlIVjm
XTwrbmSpBiOlodNRick5t72P94vX3OIZXG8baAVOOf82yIm9csaq2wEn7B3FM4t4YNTSaLOFBgsM
jIL7HEwxwPK4xuhK/L04nEtz0M42apyk6yaXvp73uP5qfS7JEjd5P6AyqMQjgqBX4KiXDVVNProF
l1e1w/ovtGegMCw8JPcAkPcvs6c1UiWcHsMkagSP0fivj2rgMHr1rCme+lsdBmUv78KaolyE6vfj
ZoLD67Pz6eH1QfYB2pzsKeiOUvKRr/DSfil54hYTRQsotWizoKWTZi/CK8u47UGhSBI0vOlQ0bJi
E6+mCzKl6fx6RMhQubjYmCKxNhuUq31JB1XNQ95rvucmFvtxvumZ8Kw808YVHe9srw/WYUpoIgq5
IMKcTApTzUaWo4HEOyv6Zks9e/cOcs6wTxNmSrfckoOVGMR81X/xXV0d+wPt2SIShO08EhafQPk+
W9iIGcGYRD0IdMS5MGQfn62eaBT+3cQr4H9vrCO8XaeJdc5yli0tovf5UfihuMiCcKV3pLW4SlxX
pr4zuNTUJv+uqsoj95jSrcViuu4F5LVHVeq3IX68Vm2YpzorMtoJTLLyVI0cf32QYqZSXgukj52i
8esijMqcQ0==