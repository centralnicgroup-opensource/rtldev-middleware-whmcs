<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPneIlAIp/GIBIg0fXo6kla1jO5Hq798kyjqx5OmhzFdy0XVIvJdyPUQspRWulV6vmUukPdY6
DNjfENIM+7k2XfDS2helkPYuVAZerEkcHaqhGUVWl5V/NJAHopweqTLcU4fW51ctFKt8QkqVYhTv
x+MEoHXTzj44L2Ojb9HaKObip5N31zfJOg3XS2m+hujyT2qr0ZiuYgj2Sch+czAop/3g38Cmj4Nh
G3SJAmZXRGY8aU4AV8WUe5FQyY/eqRNUdc/Y3m8UhFE8wjCb0dk61sISd4jQgMgI6N8KX4cTRiyn
69ZcfrWa47hH5vZ4TKaMqUmKOy0XsS9EaStxfF6MQ3EEjy4SZKNCKEs8c5ioG3NFA7AEVAJbNj0/
IKtHg9FRTMslMwS8ZQV8FTlkZkhSrpSBmrOnJwt2/4dLmh5sNDNrZcvJvVvI6qZZk/r43YkIXaG8
IZRgu8dNBAM4k6gGCOYUSo1xHlktFvf69XDqG2aUephEI3hRpDqXSmJwlA3bV2PSBOlsIeswpuLM
BGpoYpbR2bSMtgfI6zFRHSCWnJYrNnUeo21vrxOVUPwG5fK3gdqJnRL/yrsUmiRqfMNwwWtDn9vu
hjVscmuo5Gyu9/5oXgo+crxBLOLPQ5fVAwnpbguNSzmiIEzpsw6Dxrfy0myoJg7XWbrLRiVZZllX
P3I3ptS4dYVac9Tg1SCqH934XHC0TnfaGpRMdM9/kJ8LYn14EjTC//npbIelGDzQXn+4j7NNntwp
UyVVa4Lb57AfbF9VBZ12oT4J5gA87mWv4I5C2MoVW9OirXyh+YM3szBWls6m/0JRkDusBylhrAlu
7/7gty8I7nIx0Z6achuDWoSLGDyYm2KcJjz0gJsTz7hRdpJ8WQkz5SP6ruHaj7BDLFGum3ciyaDA
SAB+D132P/oPnb0u4LNAYClkHJRlUOhsyWgjPhep3mhRMxwJ3Ng5rJCByg2Ho0g4P+Xd9IIJkZOQ
K2cIVLnWgA4v2OEGoxWd7LGYjK5zE5hFLAK/HYKNOvTNJr66VnCi+LyI4Z8ks6ckNbEFCt1kjEsC
viMZ1OqK4b99faq9wYJRerJ59LMFqYolB81hfbNqi5UVHooKlGjOezMV+msPgqgRQ1GwACmMVK9a
eiSASwhMyZVag5LgVc0EpnRbC4mFpMYOJIuX0eZ74T18hlGcuS4qIEgldloUro/yY7sjD7X8eQer
jyXm0lZ8+F4wmmGID6utummeJafsjeRLUKZUo8GmkS35ArsY0WDI6T0I0RmFgq4aZVmFRUHCDndT
duV9tGvX76A49lvDMZWQ8Tl/UyWF0X/ef63LZGuh7hmOUt0gducNZs1GdfEEySTWvB+q+twp/Tnz
kYf4OHeWvNAThspm0Ax5xnJ67lXOs2RK/YC65hUEvd66yY7XHTgQaoJU9BZeIlUppH875ziTs9pF
koOGO1ciTJCMhOlklcdelnt3EhiAtQ+DcYPOTcSeWBJs07v8O+H46Je/MHBKN/DoyI06YXPwsZjf
I/YCximQCIPMRAgvesXA4aGGj60JUddPM3rqB4r5aznkT1GIif9VNBB90ECGe7BETbNgnbjJI6nd
tofK0Aimh0sAGNcmFHKTgegnYrRlyWFc1BVLS48ttAT2WrwsDHXsGYG4bTlbbtBP6bwz5IxLnj36
bjQnoTSZyOcgY7KMp2UtTHXmdPuZVNlhwMxyYGXkeDzrAt2RIS7dG9dBy8yVowfrzP9PHmVj4r1E
oiL4df/237TN9Q/xRzAcNdqcNE8urDgLcr9bTRBbDWH0Hip8/iFDvtHm32UGjK3RDc5cgNKL1x2B
CHtwloH1uvKY+11+8R1vzY0myGMdG6drzBu7HFu1Ntx1OsY899FwEF6L/7ZqdSnNB15yL0CDosXB
Yx6Q8xGw99Q3CAY+JrhKbI1KHVa6SpOJGXSTodCc+42O+n0IHidIKCljHVh+y3Fmmq5U9Im0HohP
FI9klanWcde=