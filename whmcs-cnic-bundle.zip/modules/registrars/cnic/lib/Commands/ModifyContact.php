<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/lv+2dOHy4EfKjj2jkrRd+7Wa2+4+Robj2N4gEt8w9rlGFjZsyV7ENipayQmKEUdxlgkW4S
gwsofabPKZJDLxOgxSsT3yCfLKMaxZC2+AtIjeBQUAXBdFbdP5W3YxUkoP4WUo8hOaWN00BhJzBl
237pgpwVD7id5CDdUPCB+gsK1mIx0b3sLeccL1jZYucOoSWuDkDS2nYHeBDAlADwfmfCdbIjfFx+
Cnc/HAPmEul5WQ0WefZ+y5PSHW/tVkknmTCzXCRVXwSEvEPZ8/0h+ouhyRvAQ+9Zju66cB5C3nMF
CgLdP1njrvHxqkTTV3h+W+RBpi+uYDexlMltLdhZGdJlXFy+ueCMWBujZy2zPdjkbXnVliIcDucf
fkcdxFkeCaIYeV0cJp5C71CI5MA4Ra5ooqdEV7yhloLhJGnAkiZG/7eMq0eby4ZbUwdF5bOQAYxB
n92gPvRgMAniV9DJjd9SKcojXhYManfi+5lwuLUuCUuOyEPCbo8E+kVKZVHT/nciRNavzUZNKnPm
1Xe68MUE77pPn4ZBzRndjJx4gCWcYOcX4a3O+xN6KRSIiDTwYjL4QupI2iG3FPRzamXTTuUnboSI
a2IT/fM95UOfFODaG28/UGneSkbz/FNdd4g9MznUTGi1EO4ZXiIHHanWKjJAlEQ+pbrJwZd0mHZg
GHUTaD/PnoYbGevGXtgwaCz+HibKBeF7PP0cgRANBXkec+jm9q7Wg1q6E2q42umAsYA5t4/xGIfq
jwFZmG44/jBNWn60OluqmcJ564klwF7Y7N4u6Ewcmpl1mmky9V8M22l1Ws//fpkt8Ww8EeDJiZLq
Ws5kU5Aw6kydrJ/7v2x1OFBrPH5HatrxNZejPhzICpbj+/rOBcAuyeI/X0ysu4o8+TOrJOfivfJ0
YY4IWD9Ls3Ljqd2dk5CTl9D2RcuODrMZ+jE/z4JBbpFD8T25d/s25bkt9mvL+VQrcqG3jymKLB0u
batDcaWff71ThHR/NcQ8tOebv59X/HXul3V2pJ2xT+3x+8oWrvVHCnohflNZ0DpaZ2kNHI/CiWJO
snVHkwV7xK6hoTQJzBIed177WM3xjf8+vsdFJ5qNdjC6+O1kUj+SwbqggShs5iAGD/PPFexaHcD/
+76k0iQU3lx1uVHug3WddYrKSPCxzV9vWJMooKP55qJWYFjncoCtNThoHLhLgCHbqEICLf3dKMVG
Z2Xel6sywXgFrzKRXP9ovxSpQUDy1jw9e5GImNeCpUovTP31L9JcfndbkyMGA/7hsXibuwSANntu
ObmGUoGMYYdCTXmNK9tFubxZRb3W0TVyMj3/wHHtW9wld5ZdK+s4UENL1X2SsSLMucqkVeiWMshZ
kayt3p1lp5TFINVhYoOJ1nD04lnYBbJenBmFPtroGcpm8LVGW/r+NOByOx5VkildAwiPg6Ive8Xi
W4AeMHNHfX11gxuqHpOJAE26finzo0plua8fcdml2jQJ/6RDmU6Oaq2DmdbLKjRMCjat/96FwiZF
jjqm2Iwp5lm75TdCFP5ijXm3Jbs0CvzgnJr52h6iPm20z3ts5biLD3fyBTi4q0YegCqiw/x2H4hQ
s0nT/qwZqDzpavO0KAJDvu7dfs7FdKm5oaoLLgfFORX/ZUKNl30J4YYdc0n56IWI66580LXrzmu8
NFEffZdSUNUsWiwVL8T1oRMKZsBIpD35z1N/ZD0E+HXiv2iJoBMcjs8SgCruZew9/fLjH+dMZ9aC
VCDn8iILrYZCZ0UyU2DA7+EXx5uC2eSA2AD3aexDJ/Li+ABcgPit2m2xurk1MAvoXd9GGQ/nfWFN
eZfAKGbuaKl7ByN8hSluue1W97yK5V/5PxdzdD+Z/VO8i/V4/tP0he+2d/u6bG6hjuCJ4Kx9DrxG
4DuBWlp5gdP5iHk+jAsxB/eXIQsqdabwYVDxoIZa3VBr1FMtW45c84VBxc6/5BXhVSzs