<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+gaJtIaYBHxiHRQLqg5NWQ8mPuUTuAEX/sNI6xYKvdeyncdTbyu6yYmjxiRSTnddWkmsGEY
WKI9ha3qEWOXCJAdmueOd0A0hshYr2hga6Dvl+inKK8JJgcMqfINJhZssS+sGeTkz8B3aRlXXQzk
z2Na9129ZCdbs1bixzPAT+vtz4XtsjiLskjTZIx9fLZc/IHUbno+TZM1rb5VKMry6mrgyTIWLX6n
xw08tKWKhyxMNvmWbRYkJkLRmUcpUddMU98eEh7/R3uQsGryYXfCcmOogyqERggj26hKdhtOC2mE
CaW89/z7QSPurfxGV9ZcO++vmaI1DjfSfgn1W+UEBYOAbpefy5fmrH7V9QzMmtqbAVhigClS9E1J
UMXcy57nAnYqhRBOb+jvLE91DYOgyQSkWFnQ9dlXT9sQaUdGML+AOwGclNG2AsvEmRCXzQGVAQSE
2/5WMDSvdznRfEor/4NTjf3pyiLyIz9l4LQoBIpyKzOO3cZBMsdqTjubZNEXtv1GxNwKlXVurOzY
2APPgvCSjfQh4ko1OCzciJP5WRekEpxXjWBoFTmf4mHP5u4tpKQ8xZNZXBeWVZ2ln3tDjawyjpB7
VJAQOJOL9mUW868Emst2DYwWtREc7ir3c6z6tiwYfcbtma+L/pL60cFkNhJuTsI9SUA2WJuw9ANB
DkGRdu2Zx+JlFqciX09CLl86aMD2Q2LjAaRms1q/kPXkmdfMCqy/8gk2yHA5RP18hGwo/f5INDTv
1Mdl5fbG/b7xO7oxJEBHrFkXfN4Tb3RbMt6aFYsb8Wywqs4FegcKv1QQ1E+44hYq1yGJu+zm21mh
Isw0nl2EaN2gyIsL6K5OPjihdHGhLw0d//9i3JeOs5MQ7RZMwon2/sQZXfbaJHopvlfn5ashZ0Ta
bp8cEsf1ggA00BUGAn4NdW5jLLUKurdE87IEvdT8Lj0EK1MRZf5sokgpdO0f7ezLySWGQGhPJHwu
gxmu6xWzJW6fGlrsDVIE4W/PFcax0JSMNYEKW1oyJoZcOkHw5xQAvc0tyIus5XAbOMFIdU50jt5h
k3reBgPApYEEvj6HIpPxzDYWko9cJpKMb0Wxpd+vcSA2vTsThKLqlOs6R98bAJt/im1Bc9hwpzDU
pBdks+ao2DbWaJDH7GEFabIYgmphP8WKkaXD1Smw48V8zs46A1Gxlg48ccVHJBvhapL+naS51S8S
ody+xkLbq5munT3VO9WreQJFFYVh/3iXNq3hhxMtDQ7OluZLR/lQZG1fywrUOeqM8R0GV8BsWMCQ
MiDNrKjjvDPeqzaiavaC1dU21srYeAnSjljc71QNLx/rO5ilWcvW0J1njX5Jr9+piyT5ZxMjVpEa
7b6J7bhhVVQSdunY4Mwc3xXG6XB94i4beUaOaxEGquD7oJbymBEH3N6PPiivsrPIYgL3Ajhuxvrb
h9/N4XbOSDcAJJ0sAr3COb97P0XJov0tOjedm63FpUckYenfRGr53AlwsIcW+zOTYXSSa3YNZFFP
vuymq2eoFwWz7zZBWzPL/r46N0Jeb5mGww3rg7yo829M3STdNDouOYRPfpSZEiVWCjybncCUaOad
I0ngFTbRVMxzBTN6xIUSSRV0/8UWcKd4Oocs3ReiyJlb9Lo5k+HRDhqmc/U0qrxdZPnN+9Ls/+jJ
zm/UKHrApzzmGO1Dj4nn1ZimrYtPWDZyRZK+jtlWMqBkmCNyc/kweIiHq0qeoP7JESbWeefH88NH
mxbrw4f/Yy9qcni/cA+xWRgpJCUGJQds5AwbLAq0BqjP1nla76MxX4jsdMkBu9aHa/1Pur2iYTnE
hu9T9reK3FwNoWHC7vsZ389AXrqdyDXppaQ2+IHc8DBF2lUxFbELOAeTMef5cPwC0bBOC6Ns2P7T
ptCQ9no19VEMdDe4lhc6EDErYNdBHjkEJ8SjaeygGahLsCTDxoQLwc0E1DNVaIi1vcj5gwDaXJy=