<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrkzsKa7BI9ktd5CQhG6BC147GR3Z3iEEOQuOFE4qgh1mjUoWt6z65d7tebUWSoLcRk5QMXd
wAiUHmJPDTOBf30LhlHmmYA9p9F+eXVnblfwJ/Etndbjt8KLeqYLNe2zkrdA2M/tchmxoixe//8Z
pBgozx0uoTMCfbf4asOQw5RUCmXmppw3nXN7e+wlPY7oETykGbJv/JMgDpEJhpgM7Nz/lZkzFt9x
9PdkZR8/t7I+ep8BQj3JGmiIdRI5NZa0w99KKFHTFJwo43LofB0Qo/2MmtTifDFshCvccowZ6eCD
/QTJFIs5epeb9CUVqUXR4hIRqJzQ9ElzTIIg0qtwzDMEuVJo3wM8biEwneIj26Qkh36EfEVXt8aJ
9GezY+WCcHoJcsCWlVerfe0QD8Hk701waMDg8sTjdL4oEew1rG2Fr57pxlE3Zo6WtEAJ8zHaw4qP
Ctrg8BKd18luf51jjudfXvbID0GEt2xXgNXhKKuGFj/G9o830O29oW+MglJwa4Wp5aHVp+ghRSrL
TEvttBHz6oFUqi3c0rkqvmezJ8+1BLwfhEUavTdJPRssnQj7qFIHuFPRgtX17sCwRqrEkYJ+T/KP
xguSAFyuHdc7FMXF35Z002OPW8RCvDhAWn6VSKOfyNwbwyL8b4phQtXVhapB3R1sYWQqMQL/qJ3/
rWIT+vNXX0KXL8jMSuB22/8lbZUeLe7mgqGIfw5kotRE1ju95yaxBZDc272xNbq4aHHWC7BW7s60
DnTXunvpfjr20rd3wQ2b6nzFCC0iWx/WxzrqVA4xKQ4XG4ENtFK5P5folL6lsdD62Kjc9PyLq5oH
ztHfrpkiUpRwiMWJjyo4jGDsetdaCjwXIxcvxTPnDrmGViaBi2VrhQ8iW0Qlb1FhuGagn0aP97YL
jsC0bdije2p81TVSpThHLFujppycgKwhVRQCikT5GVOtC3LTTkugTmDEipM7h8mOGnF/bDGH46S2
+cKDMyMHPoEmSXifN0fq1x1Kl31PdR//dEKh8noljeUEqD9BgMZsTXSUTm/66FIkpT9yk1uQdfg0
TCZZ1x8lYsrkcMfLYY0B26vhonVatTemK9u7dIC0tq6xl6TxWzOGPlqLEXyYQs0MMvnD5TkgHbzk
GqrOBiK62PlTTl8KBDD4efIpaBLaFTtsq3bSP6QR8Z44ccTc3oYUMjqwgPm1hPQmLTuD4W3i5MUw
qx8YivxZYFyTOBdS52Li23+z4HdXB/un53gH8imuAqfkhSjb0IC//rwrSTGPv7otJ8xcSXYr7H5w
SLVwmt3hgyNTvshM0mEqQAjeKHgISG0MZ7bLecOLfR5Kq3uaS2YkZVqq+pZ60e1hImRSuE159Qew
/ybegslJ6VJL6UPeKmxk30AqmlLqqd8c2CPUJCcqT8WeaQN8QxfNHcGlR6LcwRiEKiDp0F/6d1Ql
N95sBPZNr9Sw+cQVTLNFpDsW2xcYjV/hAJ72kkT0B/mWD0vRNoopBMz1GhkSaKiWn4ONoVD2ThAa
113vHwL+tFM2gVeAzQ1GSWRXQ+o3BUhjRSOn5tpVFj4uB4wNniIPNUHHCKYUQVdMWMngaCbrEHp/
TSB6la/IZQGmCdCcGE0p37xb95zn9XirL0FD3xpPwNIsG8Fwm+vZJphbAdAcBqCPeS10TsBothFo
boX0xhfYKHanphMCa96heNMXbwoc+MHpROqeqm5hRNSBv9kIgTn3UqyIiAOSlDMk1TsCkimxrdwW
l9O19HQL6Jd+sUBPJB/oaDRo6Il+nzx/e6tElRAM0rZBTmNsetBNw2aFAk3WQoKf3f2dBwdyGB01
zlESWS+mPAyBvyNGj/5wpPsT094HlEY19HG1JTHxJnToOVMetVTn3Yl2lSHyI5gCqNTLNSM4Ju/0
T7dyp91sW87KznG6XJM5AOZoSMhchEAF06dc3GPaCtMjWhMfib0wyXubiUDnRH1/9yJhUUbIxl8T
Sz4X382A3WG3yQ7IQctPefuYpO+beB4YamjKBNDl76dd0v6aBgKPMuKkAC46rGtr532JBFa2u9+R
e5h/fF5Gs5dKCWRPpmdQfzIIXdiwCOnwppl6h5g/qiNAavXk9AMyrF0S12w6yNrrJETf0dFTLTo0
VRruh+yx6mgSp+h251NQe0oNn3/mtvkkNRsIulxO852QLft427icX34x0ZPbHZf8kOrrgfIx5zu0
L82TQKc0WiteAewlIBJmH4WFRfCO+WKYfLrQrZrQxzfIlmFqvB28kO2vJajL/0uPg9imddDk9m5L
fecFhCPYc3l4mZUYDpADn4jXFGu6hCtimzIgFZyEagCYHr4w3o1KXtW0G1FF0d0nXW268768nPWf
ScMnpbFxWeH5O1Gg/pAW/JQnHpqdOIltytUSEY8ne/UkVPOX6btCI/PfIESbXL0q9BT0OIfBCr/W
huG1Nly4uWwK2uCQoX+0BbSrIW/QLoXovrXF0VP6CefBWOflOSYvdA/F0tY56tx3oB9azkzRcR5n
ucsRrbkTjOELB5Wd+1KH9UxU7tqQe97vpZvMaOOYP6ctIt/AvUPqC/LvoH3Ml34szyKv4r5+iIcT
5iYBdtggi4IzcKJPhm==