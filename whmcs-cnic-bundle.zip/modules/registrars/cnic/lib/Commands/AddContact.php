<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+oBg7PbMn5vS4SzLGV+xrsoiHkikhcmUBcuJlh97vG/SzHZStGIg2mJPls3ZbY1d6SzFpDu
w7m7JO4Jwr3r8oONI0Ftvu7mdlQapF2XvFYCyJ8CcsLniT4cX+CGMTLfd9hg7EsshuHmNIG1YLX0
Qf7RumSTrm3a1VcwmwKsxd/74m+CX2iECzsn2j8OBkPOj3aHekM2ta62qY4dWNv5xswlsvimEJvs
ByFh9WeRfvC4vqFv32AFNZCTpKJZMUNVXmRX3dZg08yfAPZoJlL6wQeCcnbdI2u6TaEQSqR84sO1
HgWL/rmjMS07+9ODQ++1QnLa5qh16E3NM0ycu0uCCc/8baTIysdQnh8sdmNfQt4VILbn7PNA/2K4
ynP6M/4BxpqaOCRiz3J8x9yHVkTKK2hJPtugl1mdkZGUNKDqyhNkxQOzArd03fm93wpquiDr2S6j
dc6lhLpbfx59kciBAgYn3rBxW5NYCfkFpvb13xNdRS2FDK8KfLFaDCsIgygAlHXfSxfvNIti7S1e
to09I4BbsPKi1UMxFnm4fLU0TmddzTwnKtkJML4rwtVsb8Bv3QHydQ4sw4s5oT2weIJzimcWNnwr
6oUB0mGmEqvJEBe/LaxZPzu/CfyAQjreE+Qs/xwUV3Z/ARY6w6n9rTK2UUybTVZJpx5KVXHEYmS2
Mv3H0xMYK0VOl/38kLH4qt7SzOKbfIze3PoZlCYa4h5GyBaf0nX/ADdUXM32GRT0VnAS9/FVpan8
QDntPyUP8PEnCNTkQtUiSDP/JQXBT6SHNANDa6f1+K6dmUJ79XGCaOMkwDLpQy/JOahYnY+CbzNm
uUQrcZr3VsU/lQZ/TIV7kPMfXOQNDKweEhBazUBkACwTjn4ppXp1E26fugszAyUiO25BC8ut74HE
J3F22R1c+Ku+infn6B7X0KdBnjx44OgdCMZoF+nW2d474Jl53DXaTel9i+W8neomxlMlaeoN4eMP
g0+IPRgezt55pEigm+aQL/rI8e5t5fWU894wHKqSHJE6WFnUUKQcizF4OURZYbacifcfar4PCDSS
MvwKCzJzyVICHOX2alLs0ESdXyA96WYAUy2qxweruFY5Sxb38HIczrYSk/Nym3Wfm0RvYscIFfPn
g0eibTKnRVmoZgNASG+gzfYZSWDV8ng41dBHpnbh0nol5wjAkxbNiU5JfnFUBy43wUttuZXs5GRT
Rk/pLcA7LENry7TffKcZzR9SyyU5oNT4gzfN+45FSc1oVvmccnRumGpzNNdJNdhpy30t/zow72pC
l9DeuN2UZrYlzaXID7Ngc8OdUUcv0/euudh1O/HMzrIFSsLL/ptqJ1jsyQ6EkY0KfsnU6a7uL+Un
l3YfIyXD2MR3CmX37Etrb4EMYRrGlNCF9KLnP2bi3UvVcJiIKOlwqL0q8YDnIBE2YFRZmwr3g8BK
g5j8LpkpIdBbrNFPiSM6Tmgp4TrgBZ9fUA7vgGn6p9tXZhA+8nkRh9kwhz1VowKxkU5XtaezZ8bv
Y4RZnxJ24x3HlNRpmbv8Uf1WSXeCiVdnRxlyWixp9O13daNlUgcCjuO0IMyAHMDxhuugaH4WGkTA
Ysjoyi5W8Soe6NIF1ZjhEXsBd6dg56Wk9u2HfCqpQ1VJLNAwtuOteDySMa4DrM8OTS4vt+kG4N5K
un8i1WhklYYTQVtuLwvIweOD8j9T+oWDAT8F8QTQvt78gfWgGq2bWrN9WTNa2f7WlG/X3hRBaMj6
gD+J6x7/JB/Hll1kKFdX4BxkgX3LSJZ3JLJmITD7AKf0WTW8YNtNk07B4ucKjHlIsI/72pePzYDA
6slcUax8oe7SvqiXyYK1lCCp5HCPmRspZKeDnX8miWhJk47FhsebU9EKldHf16Khcwe65uXbVrD0
ybHJ+PozS8WX9XJLoCFPX7fM1tGHS7s80AVp6UEzQ4P033VDQRve49s/g2G8OEu7PH4mhAQ+RxYc
a9onmrYnskDYnOx/IgM8aZB4m1oZ4zArJf+CMmtf4ixGaIbQM0KRua5O9l+UUTijSx3PW/jh4Mpe
W9CKxt46eNf0O72pPNKxoq4Gqv1TlRMvFlfMfXwE0CbTeKnBxmeRNCVs4geJvXnOen4fCUgIu0Vo
Wp4BSHTixtBjGiwrJQHHx+ifoQqIyWGSlcTubMoUtSm6eKPUICrEfTYIXa1zTTXQ/EubImbJbgDm
M75N6nlVRYHYn8cpkYUK9SjBY0CXG9rA+ceUHQcG7qlm3FPa7uVewoMaf3JrZEpTqZvl+rHmHJRE
FLDVGb2Jf1xS7+TMyzYq5gRkgQzlB8XKNz3eJlxF6hTjP4wRfbZ0+6zZd2gWx9j9jzdvitZYI49z
lvcaN7TzWNrrd3IuNBe+bNRs/kqpmjomxX15i8AR26Xj6+SMv3JWSrAm0JFwd8Y29AgpAGKCnxkH
4qOjG2RMYAQytD9D/uS+li6gRHSJfkr6hUGri4GehroEJT0hOEk5K79uxNNhzJ52PhS74aEhSvUn
5qXni05isJf06w7p4O4gXWONV5Jt7D6ETCCHtRpJqp/Ifu7pCCr5zKN6EZ5WRDD5ZsAkee9JNBy=