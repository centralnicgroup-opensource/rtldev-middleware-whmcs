<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvW91LvwsVsH0yMGVPYQ/GcuR1g5sdz9IhEuHgl2CSXloFI0Fr7nt70G4aI/TcuOe/EUgZ8r
3Jzgmq5AbaVHnRbSnsGiJVxxkFTEO74eTgELGZChi6Fjlsg7F/VgN6VHP/4s19zRX9XnKbIa/6xx
/uPsrUINfjIpxtrTtg2fvQcnDpA8H9163E/1qGR3Y1tPB18eze9j8KLZ3e+ifDoYjtdoQeFzM01g
wWrCPDbv5CQ2oSx4Bt5dcwsGsudcpsT540vXm2YPmMiNznedaAq95AXecULhaCe4WeUioA0cw1U7
XcWDLgM+YmCDZCqaUpGsBCHwdbXzVl02/v6wfqBSwV9O6CSNSPa1kZffMm+3TMbfyDGwJjVDL3yN
ymtkQVTnmLZBMbqTuBuHQ9l8607s2I0/QmBgY/AMNoaPZUSlg6R27KMsvX23+W1MgjWVSM5vnQuR
lLfz4vcuz6vUDXBLgsyahuWUEIMuPNP5Plw8dVCZ1VHKbT9P9WvobL01TkiYIYjn8+rKrhD3kXr5
cdgoQVfzFfCiqqQdS2A6m2c3LJe3szECjwpN7tqNVkOSwQWgkujZfyuODqokzQCYSfxqI8W0flN0
i8J5262a/4ied7WLCatkgnAZPZq7smqXoFI0GWAR94YTYpGdjmTC9QpCdkcuYpBneMP6lWSHEDXa
dwvPdDb3Y43I/+c6cQ6RoLrNb7X48nrETsDCaAASDbZc1kUlZsz3t/Q8Jw6SZLib4X873ZT9TBNO
X2m9JI/lliqCSU5lgR7WD5s6YX5SeGPXzR2radUZT1CQD3JjB3GFK6A0T+95a/3/2HQdovKtG40s
uzT8v5adfwJNmmG/7DBCMos1dKP6mdeCYH50PHG++nXyL7aLZqbq5y8v6XGiTGDzjzqKuOAV4AOt
uW1Exq/snXiIuDACo7hLzYMpGGlZBkRG2GTrjCN7TKjinG5vCmwQnUGg81w8kMgdK2mTJyoUt8QB
LUo/rTVHMDsNdRGdmKqxSl/mwLv9hdLo7ljIYi+ezR4ucmK51GwQR0EDrn38EolF6NBaL/+S7SYJ
n/KbIo9yf7t4sWTcniHcR4GPihEi1iU0vOiln22g+ptMY6ufVPx7aZTfR91a3/yANQgbW6yaa+sQ
tgw77rIO0cnkeTwvm+iAi1+bxMjUNaz3/EeHFG5/zCrfnPm8mVI/O/IM1B4Xsd5uMVjJFnStgbD0
NsXqWpJCseTotfbMExIFy9IxOrP7tLb5FMur899WSNzqGdwyLoecas9gLZfsSEpF6rZQn2lACCVb
EQ3yLf0gjp7Vtv8kB78hFiXVozdIY4qviH/EbaoG1wHEyMMIXoZFG9ZkRTzCG3575nAL/haJxDHJ
/g5Z1eoIYmoMsvcKyiq7K8jInnKT3bRsphggsr+IrPQOVrNgxRiW8UTv2lqABacB7q+4dRsCcJE+
13gbeqWpDl2ZI8/i9tn0QbSeeI3UUOlo5dqE92OUeFMx/uAW4G8HM3O54nSG4tMOKUfGqnmIq/ig
c9y5wP0gn5erZTC85v5QQUwQb0EZRGvvtSvZzNeJk2kvnj6ZioiR+0u9fs5bw6+3dhii42TKFWmQ
yK6MovaYf4p7Iwab3t5sP8Igxggo4QKLhdrOMIX+HZ10iJ7S5lN7v4nHlk3qmpvL2uHELNyi/aFu
BSjlUL+QQgOq0f+vNEd4Y31SbKl8mjlLWkHvOMB7nGosqhCmtUEhpW4niAmbtF8NPTd4J52BOcrU
e/be7/qDjobL0u+4BQGlLGRAgSjoC7yVJ01ux5FqIS1e4ENEKL3AtlbGY8uehGarVgTT60h+XHEG
ceDkUhGsmSdwwx3BymyPv3SdlX86RSA0VNna1PR7E4eYeM91RTs09LFSRyq3o7XzE3iPZbHtx7BQ
XMaNSUfyiYcLhIQfUlVwb6HKQn+tyrsnckVTQt0aBwALDnI6zLvcPQj9tUEsVKPHnqIBEdasPykD
SKQug/ARP/CY1TMrB9IFPqgLdYMYlXvJ1PcKSMZtRuYOMUidQZEX5GTP22VpO1z5m6kWKl/SjLPY
HwG961AaGAqF/SGRQ6+yURdR/HHUwYk7LOmwseVNkwj25xfJJTZ7xUCxqor5mVTptzWqazjWh/La
S7QOiO/af/qxrxvtOBcG4qWsn34jzzELLFo7kRBFD+N/DM3CM7q0f/9SBt4pv5EB+X6zVah3lbo9
wus1Mc5GNH/cUHH5YH38ow6aZ8aArLn9vPZbfXD3QnJi0aeq+988OJrDR2J/mK30ZiwishSEZqZt
MQooqMAddXURs8y4MNaU293QTqVuFtJuZesd6I89VFm7Ri9xxfaxV+2v9fmTZ2dZ2ZFtldj3+5Ex
009W6ckJYwJVV5V9MuXG17uwyXZSsH5QDphq6i2F8TqTLfOMfmZm0czm0R7hY6LVLG/hrJb51mR0
pXceeXrU3WtDCN9v97N7VHAOSl2I51kQNm59jSXX+LmFeH9PUiNM3/FMR7eAfTuUlJznaSdaFSrn
ScyeGVsIckYswHrZUeAB0fmBQP1+HlDVwbOw1UmFig+nBUX9c0ARC9Y03xG2C5Kg