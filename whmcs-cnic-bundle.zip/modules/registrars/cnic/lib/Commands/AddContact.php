<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrOzKOmnhQcZpF74hzeSwvyfdbIhgeiOhEE8Y4s1kbxp0WkBxrpU/znfaxso8tSUbKhyw962
FetTKBTNVFC4p5UzbSsSEtToR+ojvG3Zt84AitMc8CgKTJZGns7JZtQDSHwAp+MkYNWVzRnHzw9H
HHbO21tTpxgfBK6jfd6EVwqlnkdahv21e7oGS1m5ZTmGPsEfd5hcFRFs2Ug9qNqojpPRRR4ld5Ou
IakLqhdjX2KB5khLYxP44lQSxHohQJci40oB+bZwRhmuno3jWo8BgGYcap9JRfmf9dmPKNT+rGEA
8MEdEqzkZleiR9ReG1gncRwmr86SY495Q2MtOI8DI2icaLjc5cVLM3FUpXzSsphcjcfmOabYSjnU
hjVhytZ+tuaoGNL12hc1zSpcI+iktdIVJGyaczqKdHQPv3KHeLkCFvIabtWse7RgdDuBtusWANYI
MxNmgPqPqvzpoiT7eESCQV17fwZniFSdoUhhlR76AYpwP2zu1SOj7Wge4Z3xCkxYUpKWsFR6+1Vh
TIusB9R8Nr2Q4+FElS+JjTDx/bBuDH8n2daZagk9kAE2GPzDKOWFwKJjx4lelf4PtvLzZcXvyyef
PVqW85BAIfu+lQMOrU4jgRkKh3KHEAWtQp6GS/6hrgmaaAJjXRLs7LCHgzen2tWESdP15oMMhhHb
i891Vvr3MCC+ZXpebkCsuM++oayUHuIIljBw6SjTmWxXh/WPf5wdlCnGjKSoi8Il3vubfwOJ/xmx
+f0JUsnYsKbXw4Pfiq7aFsv0mKmMR+Ahiakl/fPT+wKMnq37lPA2Wt3oAiBDB1uPgILDEMYyAiYs
N7DwFhHwzAuQTF2YkihkzcJ0xlsXY8+YXw4a4eEMbbQiKNL+aZjo+3Dfah20r+kooT5evZshgNwD
AW6DDPG81wYI1uo7R/EbpBQeVEvUuepJ2XkUWZIs6nsPgHFKjfL1hpOhPetvf9tqADPlVZlodWh/
lwBfVw7h9MibePvgKaJ/jLjPbv34SmvM1eRM2oyBSYQJlt4C90vrhtJKpNJokkpK458ZUZILrE9t
i+i1gZ8tkAEOwDRiO5IJQiKRdGQvXG49YIEBLyYaa9C9TUlT3hF2LZC3vaThyTSNlIsMkg7Bi4vI
Z8nEa3rxCSnXl8hYOxjJTr1nRTGe13R2nh9m25JEA2TJioNV3EDolQSfilq4l/teud0GJqifpgNQ
x26LYNpfU+qQjpyO5CiCpjcTs1Bmpja4N/OIrsuMP9TE26NmROMudoGRL2v5v2EbL+QAEZYTvwTf
U6qPt1zh/fTjt4oq+lRzfZMuyrLUWP/wCNzElAKfJ6taO+gpBFArCXa1EVzE02jrhxiaD8gfJ6hm
X+hOhgCgjn1I1IalijdWp09iG+QvYClVWcIl6N4rK3JPeEU9y310L0MqEng6QTQDl8xOWxkLZGCM
NQpfE3DWdfqYcwYM0mnmtMEuhV9sGw0cS8Gm1QJzKyEiKWFLonTvOBfgZGPrRwMLuhK3GE5QJ+oI
YN2mRrQ/mK2FVct2vYrWklGTfTa9IXwnQt2anhsVJnwGjK3+ZbR/8hRHA6kgyw0jqaBAYia/2FUt
DYIGDMpwv5rCu8TGlKduTU3Jw19NaKWCgKMWTyAfpzkAhspuMiwhsp9fqIVF7Sg5etZC1PbT0ZCf
Ih2nUQ5UUWMQpzUb9Ojf7N/WTwntCgBO5eYzPez+r5Oeyk4KBAi/CxVv1qu+YKOduNxp7OiAqGa7
/EaDYbvpIYtMxflIvUYOSVvVl3bdAhmY5i+ECmfB1k0u5K1fR5SlJIJT6kiDthZI8KWK2JyJzgbw
C8Wn6CHLk6AOUTT6EK1bN9KCsF6E+oWuShyAs6dyQMdqZfZFiu5REwz+1+J8gXUBcybvkwY38Rit
xZ/tg5fGktqLGGeiduxGG16xBtvI7OpTg0FFdWHNTqUc40VvggtwSA2V2l1DK3uAgNe/zYc3m1Oa
1qw62AM6tI4M8gjag1Pyh2Ox6q9WJwQmqR8CyBt07VtzWqOjnGgIFK3aBPgwCHp/oLPECSLSsNsh
RSWmE/sVAnv0wSKSEUzPgIDpR/83NQ24loHno4Cwwi0mxzgY8FNU+A/VAzBL+DBj8pztqZr4/voV
9Z9cuuIdnbjpR801hGqkfZMKD/N+BjmfgsT6njHYXjoLaxAlRXwaoDz8Ow/dQMlDSbzypsMGoN4t
ZD4DSbK0QBmhdlp9Kg9RXE5fNlKiFQ3himNpxkgMSlndsHBKVYWIFKHVmLol0vRE39/VPdmmAzlA
rnBCb0uIQJ9FnNCtV/J47zLeSzIZfKCi8MVs7SWIHaRpjfDMcliVQY5dcEqe+gzXFWSM3cabfF0T
X+qq+ZDVseg0jxEZ/LlOyGkkHeYByd46/0pdqwvU6JKedZhmLkrTzVW3UsdDxphSYezvUtuJQclU
+Ta3vvr0C++8mbb5JdJUbUCjj05xoYEC682rMHgWtTkDPIkiknYPiXWK0QS9cP5em9D5Uv0UowEo
CJFZ/bUIZJ1fBo0jniJ311WfyAQ7Wzt/ujktTjxvRI6bCvLydqB/Yq4Zk4vLHoq=