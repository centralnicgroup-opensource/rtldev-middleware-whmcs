<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/XgMHP1+A5P7ARCDTgRd1ESGauwH5O92esuIC42Ad0vVfExAcjMdSUR+vdpUD/22ebwLK99
bjhi3rJhqq6cp9dXOHiG3mhOwAQLZn+2ybe/H20cdscEoMdSxbGSXXFSRMSdSQWgdv8UhYMDhzR+
e0658BblpcEOrd9M9Dvwf7902Sv1mJKKbo69lRBKGrbcziKmTzZkzjwOek04PvPRlCpuLksVdpPa
jnKxahbGDInAJIFvKvotB3r+JZTV6+pP0Mxfnj+7fmxavcCZy2lxBYlnllLdCk6zMCwsFJWEhe/o
U6Tn/m/cqfEKMkYxnY2dlj+SEt9r15hM4pzcGLjqAm9Z04gnGQsotg3ZB4nFLcqOE1Vbghlgr8Qb
Ksw3GDQFge2sEX04LJN+WQv3kC9R7OKvDHh53wtsfRgu/jkvxhF5AknZjByhaLfGS9S/eHX92Wg0
+GWjbpMGkxPFfweQAo09f62dVPf35D1HpFaKmxfYKl1b2FHsk9Z6SfVmKjyLNJaFKju7o5ba76Rd
mzYSVN9URDrguzcNU/pJ6ylis0bcvgKoFzylxXW8WWigcm8c5MALEGPAhbMqwRn4SBwfvf3VdGEk
L6MDHpIMBj/O9Z2Zp6X5Daept4okMDjorAH1b5v9EcRZu3SOCUK6XRekjuYnV8UZhCq7e0qvRhmV
NyNKKlAhAQPYJ2biCyj7tO3VABSQHQZyg5fV+8SBIUlN8o9o+ccNvWEwBiwFr5xmzxRM5t6oIMgL
xLEYBiFme3+6cUQvtjHZ/SiCJzyP1X0EXYBKj4an+BB+OUBxAVbz583NtTowt8a4Y92GpLxZlRy7
/WKvJgEwtjVcQwKR7r5TNhXs4htc6Z9uPiJbXcnqRG3p0GpyBxdt3wORKeDYEvzhtGX3M0VWtdGJ
yEDxr+AWNN5eR3uL3dd1g9arhUhyhMP4jmAcYOzBWJc6IrWRxHxum4AOgjSYjf21fMHEGUYS+4HP
bvK1fC2oTFzhpABrCoVsS7dJnKdn9/4R8S2lIJz4xBLxrAB9ZI2hqUz+dc7PyxUO/L+Wr6PywMEs
Wh6heHIK9S7+1b7vyM+bloVB2deFDzul4N6UzkmfiyCOZe2/TaVMKgElITPvEgVvK7pkIotgBVSz
oGxCQacDWbsaheYcGqPBVWKqYOOuBTEVKFCKwdlSR/yRmXq1/xtd5ac8+pInsblfSyo+W6JuibAJ
tRgwEeKZfCKO7P5qigbEb4iIcTj7YlSr8tviTbwszzOdZknBrBy/RcMD1DuL5cH8wwgcyEWmqedL
YgGCMdEq6VAoC8fSNBLjpAgMsAal7f8qLUf0tqiUN5Nl5buvs1PG/AkGOg5X7lzpuRa3wOYf2ISl
KZtDq2Xaeyh6kgQ/UFt24f2aGS++oC86nT0i3k+rk+gOdyu9PCdszEuctfo2NeR+lpwtuObNZ72/
J91AXtlQ8dPX0LzXbula9X1vA7I1XF1zSqAuZicg2jsJOUaJehNj+ssrPALHVYjeava+sDkppWgD
vI83IoMma4c+p4k4J8ZsNbA+V9A+sk6q5+PhRulX2Xc+NXH48r9RxEsRerGkxtlgQQw2mgu0fNNH
r/QtxxBsPviGjwdwMI4I8GYRfG0lY8UdfvbSSIQ0i/bkvzxPjvX5l4odBWjzLpGwaCPgwx6N0Bew
9/LOrwLKeHllj73/HLpdkb3UwHxRWBZU1mbLZVyKndhIVA4u2pAJoJQRfgIIOSV0awngNVeM7ywP
c7Y1odQ+XPnc5FtjhzU0j2LFCs9vJNWzKSTn2Bjm7K7IqPn0cRJF3bQiKmfjp3cSyDmaWWIBe5Tn
C/u4a6nGIiFU3bXTdq5eRSRrtnU0yD5gKvrUhO6200VOs6iv0WZTs6H358y9m2N61ZLVMv4HlRce
99tv9iAWDRuHlOK/jSVhKL3FEg/Xg6qd6OrvwuoNragfjRb/cWRVlXDWjRohE6dKq/ZSG8np+MxR
vxSIIrq56LYqNEUW5oTHvpcREL6oTG2m5wmCyAAuD9BttqnAC8bxVl+JBwBdl+UYHhS3QLpVVW0V
zmTXIJsmieqMI7mHB3EtNdTfOWTKNLrQPHbjddbi6VofyyNzjPqO6/Ar9C/0prb1z2+Ml7SM4bwM
HpaJ3DoevQPqc4+b2lmlZHoeeRQaNvcN68voac9YHgHmu3vR8Y4qWbbYHCE54GMZLko8xSzfaozb
U2LDevzjgvFMqWvTA5A+uvGkSt91APIZYJ066TZJxtdaca3A39TQWS8oidw3EBQvcSyY/BZYmaht
0QsyVCzkX+rfPwNviWOkWR4YuUNtSw4ml2WVVDjUuyMbHtjR3z91fmXOdVXxvLUgnMAgNHzwfgj2
VxhuHxcBjt9S3I1UXUOCaIolggftOLqQjVbCrlPFoAIp6IYV+zSEqruOVjibcX/C3PM3yNAylov6
mWbwWyj9sEjLkEJxwn+xCKRJNqg/IE6ig2zl/7+EKSUH68zJycaO1uKEvUlzEbwF+hwss19xgB2z
E6yoXssOWJXU9YIH+ApjdJ5pc5J6paSdAr3TXLeSHXEjl5cx/W==