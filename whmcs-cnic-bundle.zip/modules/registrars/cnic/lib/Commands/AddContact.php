<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpgzKixKBQVXeN77xNIgN7BS7feNmzKTd/E7Q0AOPHEDrF+wwXN1yPDQT5K4tiVx2ywi8QPd
jPeVHhAH8SmwqhMRk05kyXyKXWm8T/gBGEkm2lNPNXrQRZBx1fKIozn9V/zk9YDRBl+S9ARrEFkk
CCbPbJMX3gSYncUOWDO/cXCxcz2sNFR4/4LayHe8LySEJX7e6weaMz65bos8kTowb47IWZ17pANd
U8PJJ2fPTI4uzsdeDg84Y0I6+qGNO3gInMjsfS9LrGofFGIgAFG//w7FljP9QWJMTCykkTgwFAOG
IC578//6/6nl6NtQpte7I74eLVEGg0xZv3/toJIdpRB4Gbg7GrishkSVfiQ9tltsvcTj/g0j0gvs
7tr5+HmiEMty9BjyDoQQ7AhZ6Kov6wo5U8wEpt0Flj2bapf2/979OrnhgpgiP/qmHfZmiGHm/ZIl
uqkDdJw1IKgENd8Op428r7vqLXzapgZB1QcZyoxz3MYtSftXyE9UsiM3R9W6ZmdUbPMDoa2Tzy1P
GvBYJkWj3g9oOREgBQrDBLudfokEZi8dOzpKEq0+4ugPohxC/ycGtC0LTP0JajPxEYw1u3jH4pPr
7r6dgcd79P4gljWTvxJCM2DU3bbGfdDO/eKqkyj3441OzlAUG9/o+mo2sqbDVQje+KW6ixp3nG3M
u+ZSCypeEFQ47Y2TdNs2JO1peeqsQKQ8csrSVmn1oQVizlA7WRXOE+7bveL0tXVXush+T9d+BEcE
Xam4TU7qLRjihVcQMYOCtbBjdHCKAX3L4quq+Mxx7wv0VCp/E/9RsGI7U1yYS6NuEWtQYWGmRi7p
tfKCxVqQMyYu1EqiL+2auRnCpS5TtDYYQ9RBl9XFXcGfBtXcQjVb16dAuQu6fY/49BjZ8ax2c/Pz
VP3Mvt/8zFu6BmqKrZGOkvjx1HHtXKYTdkSw1b4EYfTiLZIVKAuj8Noy0yscj5Scvy48QPYYEmX5
M2TuevJoHLbGL3PKB0KJaY9nC8/ewZzdrb8l8isQdvoz9oMrKFJCzoddD2Dh8oyn5cSg1kk8zUa9
dAgls7G+WlP2lRFfE+3pxZYSje10eCXmCQouW9y/9MsPO1Gzd0jlcghJFg2K9LkYO8v5PD0+s3QG
DLI8OIsNAa4kCA+3larWyP4OjhJBNCmoffMfmi2LfqQbqoGMwdEONvHBHN3yd35rupzkbCMQUevX
W9VPhx0DBPu4RZGU84s8OUvK9bLax3IynBuXgvb+jiiz2/5CyUy8eLRNoSAJOMwW9PnpbWdn+rmQ
uzcwguID2f8sGFiGHyj+sMI31qCZmiJga0/UzGoPrhRL0J+LJJlCeabNCYK5e443TUs7nyTXGFf6
ppBol6Pflzmpp/5pIk9/kLrfvsOk/12cafaI4VVsBjMHIwGXIROZ0zuBpiktaae1GE7Ud0IlMTJd
wT1TijO1WUUfO93AY1BwPyXtttb7dA6cIrS2MoJcBKDbDYwRFeZodaXCIVE2TVlJmQm29Qw/bNg1
Iq26ycXeH65lr9WkOCqxEfAorwamWH7YsK9bQAaLj1ItGvuHufwV5+woxMxwj7KxFOW3df1CL6DL
t/mB23RAVTVLQpcZmoobwBBAZlHYyLiGsFgZaJEJUYsOQCV4Vd1DMXpsTDxWJVT37irVt64iAexA
8fu45FW5PtojO0ZPTi+h62sIiHw7zaHE/tucIy8EYO2nlOlpbniqAvMVP2IxXPQhX5wFNVA418xF
rJ92H21caIaze2QTp4W0YpLHiiVAAPmD1iVsCxB3VekAmfSCteB5DG9e9s2YXXkF+hnprx9iaL9j
2r29Df/F02uDVXWUv6l0toYe6Db9xv3BgyHR4imPDQ5nuzxj66VaYQX6DydxmO4ifD/PuS0nq8FP
xszdW9PTYr7sjTwAUhwgTYCmbm2zXVm2LAe8dHerSIXauXCeL8jGr77UmSpE8JHw1Kfexv8UoNye
EOH7uZqAFMAucxQQbCR8VnHQmSZNboR+7nhTA63ldKbuV9xNFRT/asTglbkM44+TyDsMoN7/FUWz
oc4Ykf5IvOJxzlIdEOKdW4iVwrZpuzQaI6eV3xDq3IHMcYYVLV4dJ/YPKjc5Onc1OC1PzmZ0hkpe
ZTaJIBQMOxwfR+QSYo9JjwYvV57QsuomrH6CjRTfpmgFJ25XZtl0rhUuagblqjLjJLIMcFAa+B/h
Omf6TbnlpYYolZh3cCvbd/RAcWu/+P5J2qC+6tcUPWONljmYBqmKQVC4S5k0zBPfSS/0hY4mwJ3g
h0sRDc2sgIH/UIMjGt4dCSitToqNI/7wmjsYkYe9xv+/dXxfDON4R4RB+3P0/puhhhyRCrJWSgIq
a+TQyzfnkAPA5Fq5aFJBGjIR7j12kU+dSOF7r5KDBmra3SplxwvIeAw8zp9vFHvNSuWZbcxLaRvO
c660+Bnz56fXSh9QJXOlvTGkA5Be3JJ9WYfQVqq63GFqym9If4Fx7S0Y39Gk3DU2l5X8G+WGJWYv
E/7whaKnZFYd7UVyccbwHqZv2Nf2R9vgt/lSzwQyZ02ttF9jKa629VrhBhANLLp1