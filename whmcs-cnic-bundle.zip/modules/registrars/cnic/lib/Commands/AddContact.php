<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtNUzIaoZCuEon9W2ZZS+b2QIoNYyiqXKg2uO8393qfoMVX5tb0lvraoRB2RcwBMmSR7V43d
jGCpBx+UJVgp6NtvWmk8H8aJY0dvofx9PNRnEKVeQ7MwdpMQyUUzozBclvsm8+waAvqse9IRKw0C
0STjO03/9oyQJfHlkovbqbzCkJZfnp9q/CRjiBvHdr3D1gS5ojgSwVEXGXidC6pR8bUll+Hf/Ubf
FZU3e30aqlpwPkEMQmKWhJMVuAmeVsDwwMl5xIqRXP/lhvZxOR6zLnCA7f1j2XHso3Hi89CSI4Y1
aqXc140AQYM6KnpJA5PsIhzrjOW6T4pKSuu92vpYV3kTWuzd6QZVH4C6R5Q9NujzPHUrhYyNw0Hj
X/YbXrwGd9WPBBMeHTFvf7D3KBSsl8s/fabx2KIdaj5ucu9n/X5vRTRY1J7mNs7fzg50zLrjuGtq
Met0GHUi9QDwMM7ipwU3ySQ4VUpO9f2gISu1ZKCWEX1c80butXHEoJP3ihceNp20v1qXDTU8H1s4
QiECi3JSvVdfo4DmOl3En0e3sYZJXm8haZXpuDVsbyqb8G2H62IwVlJ8J2zINMaj0q9ZZvmx3IPB
eF4s+zJn1XG4Du/4ls4Zzej1yF3qg9RKQxyWumU20bRdq+PwNGxV7PUSxJiahsnMpUIuZKOCrgD5
2NMl41/Vb40n9h7+d6WzGTxWn4V4fN/HyQO+Gc09V1SxB7zxbwRvV/3g6OKiKz/HduSwuAOIS/2V
NhOTwAg7Ei9YwAGoFw/HgWyulGIUSGV+X1uUlnR9ljETjOdkXop7q4EnZiXsVbssq7JmfqgCzPQK
hvKLeMs+R6O8jCA23Ld0x5IyIMK0XkcLRFZZYe3+jEvP/hkDY1PS0eDZH0NmMFYUQNW0mKZWPNBw
ouOD0+7gEEmF9lkp/tF6MR7NSz1g+oBbAg0lJNf8harZ7OxZH1/gjJxbBvU44XkoZSopbnmSEvMQ
wItb06p+A3OJ5HLH1ZtaDRq92FXp9RLHoETwIK0NJAG8dFedTntma+nCbumJTVa0vGvDry0t0AI7
NO01zNSY2/JqQ4Ghlcy3nUwJXZDKmPEHdNumdAFv0iV1QaekAYo6lO92+Q6/My8Mc8AvtJT/8enr
P5pJ8ikdy3K9YfFz7wB2YmUnR3C3nn8SWdTm4Pqtcck7ZAp+UxRwzfXytEd3AzIOYDvxICipoxKO
1Ld2n6CtQt5KcTgRR/QkLmCVBcvtWLt9athLS7PsmPDFiKPVaqolAbaWn6bRSGJGFUbNrYKw9FY7
Ygge4wRk6MIwTFq3Yn574iEkxv9EAx7WVGJsb8PJtp/+VwiwNSOfgiwl6n87806WYzFkZtNM6Sj9
m3PgKoWKyn4zzfzYUe82uye2OXfVXrWJUaoczLCQCJtVCgA5ins2qP2vz2tmZs/ilDI/Y4ZCOLBi
OoLQCvpWMIsD3F19qtJ0o6u70/mw09rqJDrlxxOIV5YbfW3jtVtiBHw10qNWaPEXoE4ssMNc3uKb
/UPkmTzqUCs0N/JTIZqplEU5GZXFyNNhG/7RB2hE2c9/axGgHIFlOYjkSgxKZssar4ig0deBxVpD
OIw1lQaO1j6QqCocc67B1mAK0AXGUl8LumdJx4d2+J8NQCWiZTqoQ1Zeusdu5avNY8fIS1qDlJR/
ydhT+Dm2T+Z91JySmAO3GhlmtV91T5+03NnuQlm5tudeMD7CtnuzlLsaGf/QILSmrxr9orN6nI3B
SFHrzScGCQS90sKJ+gXtNKsCTRc7AkLEoQ7UjeLyM2rI6cGKMirAmmzQXoUAzl7Mn4z5ZeJUZkZQ
bEZZcUBvpxuBlMFB4cGKVqFBSOhzb2GQRQJhb1wGNFsad9nVJrSxqxPbcvcuWMfdZ5Gejm6vsenh
v7YLMrN9pZDNNDm+VQtCcIL9sd3/b24dO8MuviJCiAkA1UomWOkLqNxahe23w73pVX6VzzpAJa9B
FHIVGoqsjPv0OnLlY9tEWI2K9sHY/5s5qmA5u1iL3VP8hKLaDpADq4p1vA9sIE4ndQ1ShSb9KjON
ITUFTFy4NFNLpn+Z0Bsyu7QOeGaOOYpazCqwXAJ9cRLkVNjMulozqIs0l8Y8cI45FUUAFvDNCxa1
v58lmpQa2DMtqQ6dIiNXnUyhOV1PMIQS2m5CgXrIKX+JSXrpOc+DkaXOLV1r1Z3ivzankKa/TuOu
LvpAyEicGHoJPKy2lys1ZUhidDGIQsL4BusJ3YZqvM7hiXMDOtM7hfSDa75CzIOe1yS+MrMTl+7V
NaCDgqLPMfyCkorYtCImPnHgrGHO6DBi6aREnntTq7aRmag46rT17SYZXw+iGBsyc86QUzt3caKO
lC4nbqIWV/zMj+c319jaOvQmuGfDjglv9O8O+C4kqU5YDcEjhePxtWG0gDoQ/LzDl9grSyfHINcK
qxRQNg+paNZUWSD6rBYyfbaC9DNju5AOVP4DXxd1pe9m1oPnEi6JCAdR97eBlX+FQaaBcc5DwQAr
nKHPkWDuHV7f9jtQwgQwOOVNDJ83v6N8FsQ23LV2RPoe7KtXdSf9CmPhG5mkvkVHXdt+I47yBKVU
3OD/myWDtsjsAiIM1QEFNZGY