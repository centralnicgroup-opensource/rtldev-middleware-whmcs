<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpHTvylQ3Tpiev5ow1mskwfEy8yEXQKa5fIuigIHOeEj8oISymFO1Xgyyp8xVQZp/n32fGxu
Z3KKi8zCPYIXj82jbmV+3hfI1qCBuVS7qrC04EdXykLPt4/RPk/oRmhFjN8cZryGUzbuMF3Ld/oI
8WuKqm1kyh3kuGFSkS1EDp/vCYEU7H9T+56dK/YwTPntYfBQKoqn+L6xPGV8N7kb20qTmRX8T7Bz
Ve/xCI6hi4/DqTjL/RDQ8MogoRYnV05vNOiviVziFXhP3NoA6aoR1ZAhpUzfuF/iK+Mzk8e9E0vo
RATELjNhKig/HwBQa1vLNbura4koYiEenqS+pKL6dy8Inw4Ga+hKUiPMHrlD16+ISphwmcfQGTN5
xmryMF6QL8Ir4sFF7Jw9tJlOpfCqUfqeijaUExjfbEX1Zizog3/03BUTw7+bMxGh2da++W/bUBWx
GrOrr5c5alOCUtZ7lqFo0ad84q/P6xd9KhU/Q359o9fmqJznn4Sz9an10fs/nNgUCZ86yEvuj03d
A6Z9pIqkAuws1YyELqaNoY9WmvfeUh0lQKZ5u9P6JwzUFTDxxfqPHG+16uzmX8OUKLh+/vrzkTrs
6J6haN0EMcnn8YPRykVyIqz8LqKcoM4xdBVsSMVDFz+pn1t/AYw+tFbbhaWgkjrykeCD2/wRE2VP
MGAE7jXTEcvtEUZjpjU461fntJO9VB35SxNt6VPNdPx1KohqyFlfdvysdKd9XfFwbatqwfAe4wyd
1m9g4fqMROWByzfpDoVP4apaZjNw3wY90kCBjOw9GiRqJcqtkjv2xMDg8GCIeF4E/pt0jDg7pzVA
oTpluOrwhQ0RcOwmM1mTYMLFAY85c1vgIo2HTxyzA4kSa7yp3ynW0J7WdwBrwUI32li+yWWeWHlx
vYI8Uoj8xWBxj6RVIDyN0L0xdIuMRx5AzqBhgAinrNYcfj58ENOe5uhR5jW6EKd+TqgyWIAXIQp9
biT3yCGXHbvJAiLKl37X2I1M8XlZZqFu+hxIqznU/F3aEm7wz6g5qaN8WnsmJyex9A+WTdWLD+m4
nFP5+O1fbf7SYpXKtNuA8A7jj9LKCxHN6LSG0bjm2RrfkNxzOZTu2bFaJpI3Xdf0eEeL0XhqttEf
YSGNKAZRI1LPP2rTDMZW1/oS/5cnppvZf/LtE/MC0pxxPowwTjKfiu/vLwf5Z5Air7ipA8Z/JXzr
3yPnjxoDnxqpQFvpT2BHGPUfbT9HHGrkyOQdI2HItonWtWdruZyARdtCqNEia/ZUuri0VrpTyCa8
WYT0B9aauGLMy3JssRCrfNeCCdAW4PG2dWOYkKGuIFbkYV/2/qP4OFlU4HAkwpcMoQa/Y3bsiM9G
qYmYd9ENr2erQhG+Ek5LEd0sH+9Gqs5ZT0PXlKTQCAhpUHvPgMrQJwiXO9Obp9t01T28G1vEc0/y
L4FshmJVsmu6R0SOY8RM5aUOgDS7OuHgCYG2pnNfPPyC/0RCdaGX3e0KQB7BSnkKrTPffOFFM6SF
IrDhGWAIK6jvNvYw+aqT35vfWH7OAvIFG9QrQlueI8UITfmJV1TfmtMjKSy3PNRYJce5fxJy6C4f
X9PriVPWM4KQ5K/7xEmpsYKCWkAuwLfFsOY34oY0p/rEWoGLsJfI/ChxGCU83n5EFMWi3D8zWH26
5KeeawGn407+1yVDZh/6YXN/q+eSchXi2Eaz9YDyTKCppVXNoW5YxLCNw1oLcJjr/VUHThoC9e1l
6OP25xvPqwf9z8s/alZWuUXtltzBoWNtbz5ruUlas6hILG0LSOOk3vChGwZWu6pfeweXvjSh9+cz
FyXG73Ukvc06vl4UsE7iz5pSNsgXjC8ab9uzxJIU5yLw20WA+5AesVpikeW2hshm+FV5ktWa63yv
tAPyDNdoGj3XX++i4iIIsADtmEOg9ckcaaNo/gYkfVOWvl/vfdtdNaGlQuSTLdmGrpHCBfe+dUtR
2AYYBKETUfxiEAtOaUL7M9zW15vficVbGoJbY2xI9e9oCQ9NltIyEwepb6GkHsKM8a/nnkaddu37
qvrv5BR5sYUJH6pUf1Kuk9f1Kpw1sx7KqWCESSig2iLCxrNkAu09RGyirmswnLQ7GM7AfF88Ssw1
ZJyRUPMd7tA7ebUxl1MuWRsYuur53wxOd2MMa1sqgZ/tw8TPTvcT5TTA92ix+aiPTLnuzCySVte3
trJ9Xwid3TI0zx+AnTL2GNtLlwlyqmsdziCUuvkH0sGLLm+UPjrO0ecHur532M2t+DpgDPD3tFQY
rw6vaPJ8q+JThxSgIa6wXSQwIWPxgPAdP85R92mshyIulhdlcOJq8rOBCSW5AxwezO+OIINAShwn
8Ha/WKBhqnUdq3cyh3tlgG/tXAmbYqWMh0fdn3UHOoDcihEowxV1yUCwakZfW0s+u+cUjsM52YHt
gExSKoxbItxZ7v2oI0fA6eOAuAZ2I/h1UDTuUWLROFuPbqAQ/yR2STk5J25imU+Wgi85fu0JUfko
2mqQxZVFj4ABTCKtCcRJo/Aw0V01d7AOUDdctLScvYp6xLzT8L/owlCC2cI4zPQa1qx76m==