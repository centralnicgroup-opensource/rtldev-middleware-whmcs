<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoZMc4QyT65fkHeDPUsQN+euQYh+OQXoBxYuuTjaeCgXoWXw10ktHdZ0Rvtn1/ikRQgjQ0f7
DcqaWU02v6haCwSsPHn9SOCAhTrpbSWqPV6BVvbqqMz5pTnPeey+ykJR3OKeM80P1VI4ZFdppLfG
PXP2YmgGv3+OcvS7MqjIktYJ7dwgqNtWC7WRu7XGUMl6vUnfq28guAbdqeS6IVS9khBwD8yBFvmz
FukWdgxxQuoWdjcxVYV8Bj5SCosmaIDhww76QM4BibGvDFIXHeienCM7UgreNEev+k7S8QfGLOx7
bYSkPtB3o1ws+kDGtQX9ItHMUSCgQTnGDj8kBkWEslWZBrShmoLNzhhMcXjn6Ms1xpyOSe2rZh03
H30sHeDptP5rZrlBo9rh3hBC9QmEVRqH3Q28uGes/rFas/SLo1jJiLnWjbAWK5Om81YEoKgNzLV0
UmlkxYMmFN+gv7f7EE63ucNrH3wcYtAhVy8Q/QYBmD4eJot49gfYOVfgarYpEdHy8vVY92s/6H3f
0Yr7ksIvKP81sxuBgmo2TGoUHNHJiVUxQdq499rF0LXJFU5QroBAW8tctUF9PJaQ3wkDt6Blcw68
0LjVwXc6fgahVFiPTjtjV9vRLtZv4EKYHFdACekeHFTrvMpLTUfl28YV+CcQENTsrELv7i1zka/b
IrFpx9NqvGkJ1G3P4R7L/Vr6v/iCwtjnXE5JB5cy0RgX9OGpvWxN1CcM/F6UYcLtD5zDvHijq/kL
SnktXqFzbaqfgfjbe7QKaRM+bO3uY1Pq7BVJFJAt8QtWUjF+qs5oTkRj9oURPckG/AnCgffqCbTF
XLCDLHtdeaVZVAyOYCPOh/GNCGd2RbU8U/Kbo94knUMgSBWSiOyKQsUBikjrFK3OXrTgZPkH3xOg
QcWRn5zVESi5ysx7fOV+HX3LJ9i5Z4jdAUf5Clpl5HElDKl2NuGB8oZr5+dGTyQWps/W/iQDAny5
426tkgHqlB4oHgWbdTHipmLBTch8QOBIYm4dzDWepuGXZmVBcFKSODpoi92tDKbsNoOvzgbwy41Z
vMcLfit6wep5sBz6E7ihWz+q5f+aVSarvcXJcSbUE5A/NyjNXdprQNH9ZKioVmiMHgs4lf1kY41i
byiVP+onB+83QEsJaQPAuUST36mRPNggMw9kua2ZGuTFJx/JBrNLSSZvZvrshw/Fgz4EZSgWnYfW
GfXtBi2HQF26GLf7RWr1geuT/FV4v95U6KLIhGC6OrWQyCdoJbZMl9rFHeeFKAPJCkgUR6gyqNQR
ZvjkjnCPGYDFoWrohZ5xnNGoFHFBkG1nN0gQ4bGErLnzXvRKn09aWGm9nFeB/smTcRwz3vIJcIt5
zbgCejTkPSmuz9LqKYq1r52ZC0qpHJfyZYfiH2l6yl+YQe79HTdItVoLvgwx5+GYngLN3mjE1LIZ
VnQ2ISv5tDx1yk/2TDABlJFwohdi8Vx7Qprw/I6iW0KtdZDQ41yaJENmgyzOrB1KQGNUk/6c8mtR
0gp6fN05UH6GD3Mu2PhUvpHpUhBcoSOJ64Lg9DJDoLnzfighC41rb3Uw0lHQpIDtYGhMeXOD335w
iJyz4qtv+GO/3w9xjJ3FvrPvQ2o5Cp2cFyvJFpfAvr+o+iZjoe0V21RhlJJsDLH/kEXZaYTC+uIG
ieuzbdSxWOy8FGE9Kb8vBLN/3NB/N+6gQCdflyY2Ta2iAr1nosXlqRcf0FmqWsVQ64WXOUZ64JaX
ODXP6azLQjDrrEbd00p/STl2yZL59NQG8RLiMxXy0qLGDk5j2KkRXhFhBqIwrfBuIZvpvciOlOGk
EUoYGssN/GQTx5+TZgH7OT8kMzK5YYb2EsFOqnqRbb/9qVltNPx/FSoMbuB+Q1ZrM3cwWlGAuFCl
bk0RazFlvmx7Zn44jxOwCsjuYtLQ53FWe/10aLXZVXh3M3AaAFuz68Ylnk+IgmZrJexSuP6Rbd82
GhsSL1oVs0YeNWKrBWzQBQKCvuBebDiWuspGdEpfmcqA7g4szIDGP4ekNpMh4lz0HnP3FG0/MUY/
tCV//xCSK/hR5eS08oKeEh2o8Oq9GBcl4SEGZyzHBk/4ltfqHOSkl82bZwYdIQhfU0Jdj9fOtLo7
kqDKLRLWBZjgGVsAOSq/j/lgZSwvN8bXlgeaS2XMlZaHsQqRAtrpK5DMp3VjfiuXHGJsKTQkrwss
gjiGLgnTMdj7z8BYSnv9vQjEmbDODTim14Qkcub0IMHxLzJB8pGmDDV5dRKPNmPL0CQREhZO/GRD
y14JtV+4efv3igCC0r9xnY8sBFYZs3ABjQjHEweS8AlnAE7lJPWFbuQxY53ywGvpAG+0MTZthRGC
M/AjTIc2p6+RS8FNrhHPUMuHOrbTGGwxVt3JLeNVo00b0hlqE9G1Y+pP5NWIuonQN+fDyDndX6Pt
KlRzxW2CprTQqkyMER6M8Ip1cKhx083CI7DdaL1NtENqociDM6iFE3fMr/WbZoLEBFeIrr5540J6
5Kdqyf507YqABlunGaWSserANYEHIaquEg1MRgb31mPPAjV1UwN+y3x8WVq5ehMLl9bAveUjr4YC
rm==