<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvlpM/vwKw3n0p/EtIin4/cS3f4Be0j5z+EAn6OI5aRP61p4RjoGpKBjytRCJ5o+nRWdN7SL
fCl5cYITl7jNO79uOtLqeWqizdq/SswFiM/W2Sr64kIdCtdb5CFovgbQ6i2WUW2J0CBSRWzrtAlg
NrGVR+3neekG6CXddocGAWYp8epKoi8LefrzFxVCDv7pvoraGym1aSVn64eOCZgMZosB8PtVj2tw
QZrq9k1Nb4iL0LtTnMKj5byJ+ZYiGQj7qt7kSXwiyuZgqoK2UuO7P9oSIrf7PnMkE6xLl8DcsJmO
6CW6Dly9BHNt/Z0Je9kwLJhEd7Nbod5xqjikLmaA+Wgbzr4gn+EVIVkzvmhAD/bs+WfUbSAHMsmK
9C0zqSpzbVbNTznQIV6b+eJzp99Qj4fsclzBoF3JHEveqeCbmrtdc9fbx4ig96E9WR++Yh1d5rYX
NP6cTOIfB1RCD6+bjpLz5x6tLm3saY5p6KAw7lmOW7Zllf5O+MeTS40psdlCiI0TJLEZDlL4664j
zeudPxORr8bACasxMbe9dcFh7JRqdgbTkmV06o5FRRZSg+fTRtuGHlAtztzyFIf7mHlx3BrgUg2l
vAmtLxWKcIhhS2SXh9qTNlIWm+E8MFbakdE3uzBsY0fAcD0SGduims5UXM3RUYKq0fCcWRl2UR8A
wD/XYF4ROh3ekMHSg7RtXT2RabSkyo53yZ3UFiFNeAo3LP/M7wBDiHpkQV0HG7+suo5M4W1fVNCx
IGGvXZaBtztqB16rTji0O+aC+/yL2MT9/tf+VPFcQC3xmcAwlFRvDmCjWRsIGIWMntCNyYZBCGf5
nvBiraLai9NveCkb4GglYle3PkEclW95moDESY/NV4SJSukO4LUZW/cpTF7aU7ERhy12I8JcyTyI
j5HFzHXGsSDJr54bfPJ17WF31t7+dBX0b6RtQcZyQ/r/ogPnnjSKtZwg7lK4pJwzGHUAj3At5Yoo
crEttmdYVWd/Bjx1C8bx6q8TPz0Voqp5Uij0nnlndiyagm8fr9w5vgNGB1pHG0QV90WQlk60HTQ5
wtKJByUN8AK2dmQuoEK4WN37sHgBkRHoxno+MrNhQkw4yJ/ZAE8UI3z8K90oECCcDjIApSqvPjrh
u1neswEYcA395B2S5r1V5922GZ4iZ4tpHkcUfiQxuTVujytG1JcsDYc9puyjdajko100XiBUtZSN
wWdc7wJa9FSb3kUmyyT90ktTpzjgj2dC5t1SoqhGJGObi2JiD3gwedMPIyooPi5x8jYzK9PvymvT
szxrbUDkjRTg4UGScc7tlBPrK81zwnaxuimtMmoC2nc0sYWE7mPDsOwA8MEV5r7udNhhCWKVH4/c
ZFsflk57M6vbzmVO2pKBIKvDZ6qdBXy05GkFnUsWYVWbEU5fr884Nd8VMnQ2wwNoWfpgxi6Wb7gQ
VJHXbh+RrqFVumWwaNgN/KTFKCh4IgwH5mCF2YGHiBwXJaLz5P77NMB1ksMJ+WsQRiLXk4e+s3Hk
i7VUIOw1vDECfGKKkjyUHlCFdlbpHWts1UusBcWdX5MQfK3jPB49mYlOViR/OoE7gX7DNiupvlw0
gvEpv9xzKNsj6gaXGXnQ9nFGFx0DQzliPX9rsurx8Lp8+3MzteLSSaUz+syiNE4vu2n/Fd///WAO
C7+oBfFfWw1iCG8GU7BPhzfWRjNoz0TL4FXcFnyGg6B6c/xX5hzlFgT6sUxHHazLSIdDINVIX3uM
juYmH6/QClsr3+gsLovRMFDjJUFv0Lzd8Sxmyp1Fvu92KkRo/+Pq1iP4rwNcHgKCQN5vZj0s0SVn
qRS9ALbHqNjsr45G4GT5+4MqAf2/6YHZQVf4zZy0nYa881hRZX8u2EXyMRBnRqlq24MdgCgZxekc
2mwQJc5Xzj3gj1PaTnA6crrqlOJ2wdsfMsvoxizqYxNxXRXM52vEVutajQSxN9JN8WVF9ExApGAb
bDSlPHnbiEzbwQFKMJJBVo7REErlD17p+t6jV3srswz8dKbszJwYQm6sA1l3eKCpxrYopcXl9SKm
qCc4UdSx0BFY9e/JwxLzHW6Lx0yo3wAi2h2xbzi22M92zEPr8/fyfFiOWvGUoxntQ3q1hOv9g7K9
po0b7h6PvZEehgIqRJOgdzUf+Mj67LgEzVYk2vQ5hQ3oLkME4j1uokAlvPed4TzgK91VEfICZMaO
jm6SDW0LPbowIvyKmADxwzMgoiKfnc/fpSbpPjFCPCh+lrs5Iiyfuo1bjTbtiqr4sa5FIZvpeF5L
U18By8Oh2GC+NYUCTbwGDztXZyxjGlg1ftTjysGgEUXhj3wnrahGBfJy5otoor/6VNOJam8PUqSA
Fjad4wMu12jMs+JBkAP65seLv+eXE8Vm1RGzXiMBudYH3zJ/PXc6OWhsS++vZMszkBv9r/JFKnuO
Tw3cOMAfM+plWNQQ+VLHMCNULnjb5U3IRZ+uDHE+UZb6G/T+Yq4MDEArD/cxNMukUi2FLO38y2Ob
8Gqoh2deFgiY5LeSTv2ehxZtI7jG7c+02PS3O5eDuUB3dIScMgUV2XM6x/kzz58gGG==