<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPszvg6xywH11+RKzJKgZQZXpFanQ+1NcASzpi6zW/UN7v4B4QIR/kmeqX6XXJYhl64N+9al/
WnT9b1h2YvrTDl2qc92OKKwKfz1C0THNOvzo5Y8hBFSGvmBq/Wv/OWgAf0lsBy/w4xwN+PXS1fTF
Djq3T04VLMgygL2iBxA172LX+nc1jvevSy665yXGIBL4vCGdWgxf9ggH//ANyVHOjBf8d11ZqBmF
9rQLaHLgN2QKCBNHmmG6cQ1Bwz7gnueH9gkudn5OmHc7YsTKV51AV9cOMRUAPZUZr6svqWOTCKnx
7Kv8WdKF9zzN8y4Vf+A5HrogQL1aPKu1Hhwoqtn1R5j+PsZ9/QnBgY1l+UnpQOz2IDOoBAlqT/bu
j6FKwSQxoylyTP5RgRC1CdT4n73yE00qPRLbAKUZJxWtgxX3CMbwoWgYKRzeg6muVatTC8hDvlQ6
hdknKMtr+7A5HhA5CyPP5AnH5xfIlhra4wCplCe7b0mxRPq/YpCNCDpOtdyQECuIh0fNk3tRApzl
FO4TYVNWV3Tfx6u/AZe9v92O9vOK4ZkurxMah4eKT8hfJhy8qP6rkleTOspAoUYc9qmjCe98RJ7L
6yJYuiDgU2NSZHVlsgZYexD574PVp+aa0uU2AJqGxztmn4rBMV/ihKhHo5u2L+CRNvfDu+oq01y2
Qp2f7M2XEyaND/KW98MB0ISDAOTkFPRQyPnre3ia89pxTdVAGqAhEoV209WTsGnET6i6LaoZSBaH
uA2kGM745k66YE3MzwDv8SawWGOV5NRxLxzj2ht+lficYFim5pjvSUEdWhtn3TAGeg3Md02gkH8K
IIbc6GyaeiZItcg0quxMox19/J4jFbCZQ5IOr7XiGB2remCk0hOxOqARtFvhJ0M/w2JP9bO9+PE2
Rh3qq+SONHJOzFhiSg0NxNetfH/gQpkjKYzcWqHfXC4pTA3I6kWb1Nmrth5JN9/SbtevmNVUGWQo
lpkmH6zQ33a1/z+5FUBdVYvb6U9XE3kcy24vd1GPAbwcSwsUXfHgrUYQQdT8nmDil75tUUjJK91Y
oan0Xy+BlGg7tdn/oWXSQTPZmsTlDIvpoCfSuNkOA5+7rvIEMukhRdQaOZgzv6IyZnceLiEatXG+
rkBisf15fhiMHJZurfIQLkw0OAHt165RrM0/FoM32rFULu7Hvu45XVY+idlMi6BiXlMX2V244zVP
bzDDHFmG2m5go9I0GtB6Na3LbUa1NInXOxUiyONfivG9ijt1axnjOF0P9lZVMoNymKHX6Ww8QjxE
OFKLqwbxayNzfJtw3TAAjI8eeM6hY6Y35CeFG5G6fr2zz/5h0Xh/MB7nga3/TmC+dqVDIoJIzBs2
+DEAy2/60R/cdbdaLz06AsXkBEdCm1EEfXVcEP+fUhLxjrban3FCPkYy/gW80i5akkNGBCvXr6tO
zK5DoPHR4mnvr8SHfRZnETzDeCopAl51BL2B8OX+wc2OyD9uv8353DwjkFRttMbxir9wu3R32K5P
78vL2DD1OYTOeirmUJ4DTGXsAXWPTr5N5gjlB1sYfjz5in/i1Q5KCi5xwADtBIf1foVqtG8A4xsP
4fPpCUzVtHbLp4kiXsH0cLtot+PMd8KvhltjjQJd24xuPioeHxMxJOvFXENAIEb8bVPFuym0tj7c
P3xLcx267/epAV+/zqnrBAzY7XETv+4aC4mInYwTuZ7ziZ6mUizS6eUygiSrOHQgvaUIp+G9Pb14
XX+2FpYW7s8zTbTQvQ3m1KIXH0vf0VYaDDCx45XrhVPusUbfxlv+034ncSuhIjXROf48RDrSjfB8
phJH+FEiKmTKxKVxkmgoib8Lvpxa3pTXMqH/fM4gy5e6LS0ianpUlbhWwBOV8G1gIsTioCX3betS
24SiA+SdiRdrOBz2HNe/wMj5UnVacPbaI30wiAn7UV4qyfY4wxV0I1ipCYE+NwseXZw2nF5+ER4q
AiDgg/bUZLXrjiLxCiVmKqOFJHpZp+PCWLyniIyhoRIhNL1FwRaI6gY7V5KHdwKoOwGcmFtHNHHN
C7+0vmjjehsjac94EjQdxpjkQCLJIY7BmlVohHo5UfaVk9DHShnQ/E24P8igCesx4/UYStpVHfNf
EAIF1deXR+zjkurFteQ4dI5mxzj//85qq6giR2gc85s1TZtPu0huHqNVPXEER6VoRA+VPUK7VwhW
YvbyiX8IN9+KybsdZWfcH2LYlH7PkyXE+HFkuxQGYhCl2iIF/qO20sWSUVQjQQvjrPoK35NzANq0
UD4HKO5HzDf5nKngwXiQPO4F8JZzmWLCCJaKPanF8fdHzIMHd0zOH29RDzkVfEqB+WUpEzO24bhn
CRqR6ujF5OFQkx20seKJrsnwltABxWUyMY44JjLJLl8k1Pd5+J+Ty7sz3j9X04nMJiD2yrIx1LSS
ezFW+nU31aF9RWMcLZTsgmL1zt5C/jDuYwzAIk+rfaI/h3+h+P+rz+FjtCHzio2jEY99xMmkb6sE
Pc+pAecUzQ1ANZR9VHf0T72PM+zzU6BB2JXDiWODIuR9h2FgDmM68+AXaAI5zgypIkZx