<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;

class StartSession extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     */
    public function __construct(array $params)
    {
        try {
            parent::__construct($params);
            $this->api->args["LOGIN"] = $params["Username"];
            $this->api->args["PASSWORD"] = $params["TestMode"] === "on" ? $params["TestPassword"] : $params["Password"];
            $this->execute();
        } catch (Exception $e) {
            // We catch this as this is used for configuration validation only
        }
    }
}
