<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyC7/Dg5wCGTKBLf+Vw3qoKIj6MEgyd5MjD6s97cuLq8jaD7MuJ7S8azEHpn44gGlEC1GHFA
RUG/zewR95MxdT4uEQE9waroKsFjUozAIpSIOQjfKRjWTrV2x8FBX5RFbv9nHrZDcn8VfO+5hF7f
KNYKBZcd3fgCq+z5p44gKjoZnwvBytIJhDCaCy4qHrpSRPorDVZAT8EOdt5wkrPq9iEuxfQpLEt9
cc+8tiZqRXkYTc4a9nRUalK7MMK7EnVyzR9Gcy9LrGofFGIgAFG//w7FljPwRfoh8fvyGak/NwWG
EEu74agJ17eZANxM4QwUMdPvlVsLM4XELU7Ynm80laY2AhWYVVXsh6YrWaIKpe8nIX+SskYOXK7T
JyRXB0HXq2ohr3jvVr8vln4ZDGIHAfB/HxGzwm5flP75p1LCnn+j49Go2IfE2CktazfMPqIemBuV
q400aHmjeTVV4bM3wR/9QHY90HgLZp9BN96FITRP0R/Be1gI9k62TRwOZbq2cBUwv/MguLqDsURI
dHTk99BftUt2fZbOkinr5AogxRX81mnl/LQfrc84nULIMO510TR7o8IrIW+28ww/CiTvfuYPiTXu
qIFsVAhug0Nm+MPm7jWsK01ewrjX1qBXEHrdm4sKlo1BqU8s/qlDa/wsv1mC3ulsWNyrxRUCpThh
RY3uG3bMgmvln3KWYN2p+R5gJBZQsQebq4nSbn+GpUoi4WLLB8489unjg5Uvt8vdc6X+tIBluDF6
VaY4B94F8/+SNkCuCG9RSUCPE0LQMGFLc4gDdOmn1OWwRcO1oXqHK3CJ7ljF7jJzyeykjMOSXmmJ
tovw4F+34QfmU1DGXxjSx5Lis+jQH/CPME45jGoZFfa9DskBmQiFP3Bo0o+k2uWi5ZRPW1+y+3ra
XV6nOkp+3ps5hfu3MDtB8KfwXnWzB/EzfmAsE9n4BYLrPEpKdyhpw69AVkrFwHb4Fax2+OUR7TF4
VWE8Qf0T6qHb/HW9J9ZOH4FR9iDnRe5lvW8ttVEhvJ2/+hP2S92AK78/wrAIpBy/RgnJvgOARBDb
RB7Hg6PUw93Yp0qme8tJNivyUHUB+xKbS/j+KPo+ocGHHiuNMGFdGqWNKdDpYgBCCUCpGRA4iszj
JSIZXPlGgDCez8YCjCFGtje/CmUHtYHDJD6vL1kbwK4018xSB4f+/FutLZW2WMc2UuPYbAqNU687
mFCSB0jrY8gCmYNiW/6a486UqruO/BvmGuB7cDZbw3RYlGE133yZxXLHQS9781uUZFzD+eyb4IiA
5OLEH6Mc9dibrEVE1j92Domqgus2Zo3HIBWN8A/qbo9gyWRyMUrrK1FICMaM9JzQ4mHD8vME5XeI
qLuQ4VuLGRe127HCFJqPjW7CplzKcxHQT0QG6VQ4sYTFZWeXK+eSVvKAIPYCKHvqoctMBGBc0J4x
xCsftto9I80aSgFUizWq8PC7BukegCeGTEgTkiO+yi+dTLAHCp5YHfrF0rwyfUW367a3Dc4PnRHe
tjIG5f5En03bR2+9dblsrVSKuUvrjF6Vm1pu35ZD3oljzKuewDRKCEF3NkcThAyMTEcSQ/TRXbfX
OG7nBryF/TaTNXdmtx3ap2uUG1RpHY+HYa4olLyV8lyR88TYk6kSKkIQ0xVWp1FHtVa+M2DpylpW
JEYMRrbW1KEnGdxrbE0/hdW5HD5PaCIFOcLd752No2Cdc4kVSRTZLKX0t48voemlyjtmKEJYUl9M
5Ix8kz7DjyCibf9Vls+KsDpMoLjkAC1lyAoXQ7s86fFdOrKwzaX/3HhJ7X/GJrfuJ+52HOJa5Y8r
kIEtvMue9UQREmeKnbW7bPhKNUkjzBENf9Rv0XmgCkosRDw2pSKxUDnxGObBlwA9EyCdwwUUG7iK
