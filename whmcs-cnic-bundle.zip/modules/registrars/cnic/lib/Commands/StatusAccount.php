<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+VNcbniEN+JQMKFVr6wTxZoMP0PU01opFb2Evlk7tZnZQVAiHd6pT7dlhvVAc9x4rNzD+vs
Qc4vyrAaxD/B3H50h98SBiWUB0jDNAyJXFP5SF9a+7D48FoM+kPKwLtUzyMfJtvtjfKPFIRX1j3b
RLEo8ZdLHZ+NyRlyxDoUIOX1Zvs7avmVd2Q3mYJ0luHHCkwFShff4jDmk8+ls7CLN9lE3jVtBedC
XlD/PzlD5bVon3cfuSWHheZzffw35wNa/raOS1D/iDrER9N3D9oxBelKdCjfFN4TNDcmLOdMPYGK
Ym76nnG51zpvsJAKPritETIhMkteguH9W/uCD7CiwWjuSzNeyjLQJF+EtR3i8IhFAj4QszPrhB9r
VJJ6rmMMUGf0q9hfnvjvFS6GlM4ZJYhiOYt/Ki550W9/sfOlIqm9tKijGpxfjKq1wpgKDSdV5Tot
FwuZW6THt5e9QOg+lJlfCruWkC+/q+LzC67vx0Fhl5wQVbmG2CPuK1iJ+cwVN8buS7UkMHbg5G2X
9dt7hu4NVakOQtx7Tktwrm9rGUxJMgArlo57VqaV7gysyl+tHllpjZaFjX37LB8RLNNM6ZbF81WT
P095ozMFcet0IbTD564hDQHvSnakKuIWlSSFnswzb5+Lx+9xyHTl3//rfL2+JxYG4ijNMTw7B54e
eTGPWLlAC+2aVjRfWsERqmVrNB1tJ062vyLmznwTptBYYmzXrduSwt1t/U/7scxXe7mNHvbc6nLH
PujHRmuEA2NCYDseip5HdMVZCKiGjB8iwQk1t1eO0+0GQRRvn1AP3rDdvXOU7DA1inEE8B++p2d4
KdIvW07dGxh+mElsrkl8p02wFbUavlp4HBlPxYHaU4iq86C5NZXoT7F0uCQZ2lObW4x/V5GH5AXG
96zEt+YBItCP23Qo75PF2An+ioHXy68SspSWDZzcN/DbpMMHCCNrlu4ptovCq4nN2J5NJk1s8gBA
Z2TxTTQUTgEpMOPyLzwes+HOSVjTd7DMQCMnJi4NrZ1iHsMmEVQzZKyJyXAhr0jAMXthfSWVHQHp
WkiJLvpukWd8+lHiWPoGFgEuRCGLN2ysxOBs8a6eCJt7n3yq38jKqhKkZfouKLcjw6JiwN26yEcg
x+gCAn9I7zOJuGWQsC3Ua+JoGTKFVf/Jdvk8Lk7i43qOOhuIJh32fRY5432USkaGoLCWgRqmyQ66
QtPOdnKN16wzs3GNxgBqwrNxeV9SbP6a8atMmtghSkuSrqpLgD3wekwJBRHPXvgrlX7ZvAi23YTK
vgtBr/TlybQNK1s/3N2uH0VmN5SCcd4EN9iFMpbrDOkezfN6YMvbkOB1md+hu1V/IxlBn1jIhf1o
TH6TbV1wAkl+y6CltuGBWepuwlKMWqfYDynU8pKriFrUSCtyAgNHg/IH+2G5w47DMdhk7JaQ48tB
mxGokfBzP4PQxFQRbGXYXv0W1GgGDHze5xDNp3RqbTViJwxmJRkVP1idQmUsPllMDJD0jvRq8N8x
qgoC4A1u7Fw3FGa67hiQkqTa5VQgFNk6XevCGEG+LlidisHRl/i/AiX+9dWo5Bza8jwhu+ZFB6v/
DHz252LnjZbv/Jh0XWEFS9NT/Kpg19Jr7EwzC7bXWphHTbN2TWDomb4kaWLQnI22mjdKw7x0694l
A0AKdVc2dju4aH774qcioTkJB2rPGS9aW30wUL1qpJfGK/4fqUbZNhstop4Lt+eqN9IItcdlexzN
KgUGuH6IEUAC1ceiLebojnI2FzWogcIcVtLzeACUvaAbhCPb5c7MMXOJnlV9srC63Npz9wdc5XoA
Uq0qZz4QGuLgUUhm5YWVy2bC+evRELUpcQtOQsSZC4YvBIraaMsVjV59+Hy9wnePzIgLcHvu7Q4b
JaEE