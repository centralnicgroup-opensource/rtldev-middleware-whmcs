<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzC7AJMTw94wMBMy5cRUwT2YLW4A+DFPSCLDqhm3LrB6oMHOJMaIWZrsYBKAxtB/DYhYfCW7
5f0EljY/OLUIRGX8qXXMquXz6YMvNURKyhdkZHwnDUS5DmHmRodfvwg/dBjXowb+uHhuGVqr6/tS
L4uunNKrmEJm4drmAdpM7T4/X2tB6MaXvjSRHoKYWQXp6p0fqrcFTk1HNb4mKvmWmcfo2Ic4CVFW
IVd9doZU0Lbc8B8G2HCd9bHFzXMMV4PEr3uxOYkn/sm+6jaDV8eQJ9i6CglD1MDU7RQ4kCAf8JZ+
3g8X9ncZbKAC6JUD35kez+38qfBOGNRrm+Id2vdxoIZtKlRO0jNxb4EE10/x5xZD+8ZWE3Zohxwe
rMefUhXOrwWSaQy8bEa/UT4IiWmGxOCOzf/SCnmF1afZ7Bx9BpCauNbi/eRHqY1rRv/5IDR9AJe0
pgzCLMvX6FocSXP5xGXSdh9WAuhC6PUWe+tAcG/m7v31pSyMLgVmjkwsJIdYXTSCKb5LlooT6Pbs
2rkaTC5Vhzzz5+W0XpTgBV7suQXbkQMlDcGdcs0d7Sfp/CoT60Gjjd2dKhL8j2SvglIppiKnuRX/
+pKot5697ISzHsO0atui9w4Rr9pkVdHcon4UjT43FT0mDFRZN2oLeLhHFmmWtZD5fCZiaDgRPsIF
AMaaOtA45Fg/IRoOE/yryBvQZLZ8nCFTUPo9EWPVY+/VsXIQzM7BnqhW/AR1ofSeJXwJUcpaVrjR
7aWQg0pGByGKZQY934cvpy/VzffupduEDVNXsWeMG8ciJ8GedYb6HRRf6rvfqj9lFOyze+KFTZiN
v+G75rQITnWpohKW151d6QxcAW1f3+YOk63QbPcB7Qak+VzOAa6cakycImUVIP/LV5k8epTb3Bbc
gX+3ofz5i5rcgpWadScpyK8Jqq6Ga16cbVtvRn4IgVOhqCYDQU/tPI8rfsRHl9wNJWVvfSkbomqJ
hUelR9W6oLm/ET+FEpqZFHuHf3CZn6r7Zzr19vmJPD7XMhN6iF+BRD4AuyHd9jHNfBRCfJ6kJOis
y/cdECrabduQUth2wYKqIbdNV1k32sV1n8nR4FGHTYdeL1RIIv6PaEdaB8mYWNJIlsoZMusZ6rse
ehFRI0TcrhecovWz3a2ylesDmeqnQKDRwYITcNv+juTLORvD1EV5doj28SGNanOoa4WQc6Cq0Wux
brhTrGevptpwdnOKnJvINQS9jPXSeKzptWqECu5awtmEJEjY8jDA4ioqQ69oDfCmoFhuall3vHGb
3V/DPSuQjcSPylvQrHz/WoqQd1FOIhFJi91Fu2T0AkjqNWY3gr4DP7/SGmtZ9Nt/CoGl634XSic6
GU0w6mW3zmjdyYxcmJk4wE9c/wCVn44CO7J0Hco1BvECsoYSwM/5wqTRbJrh0dn2aLY3n3AxPWvD
mbT5ViEr4vUDnV7AsAY1IRrCoddF3dV26r23QRQSROVD2W0cgrdE42bA52eWi8sLCM+5sMGCROM6
4xvourOwyMluZ7CLAjQV0SG8UXGol5xLOE1mxVH9fF/S4wyebATeJU47DbdvdR+OsO+cMm0xEkg6
UEvu1EqgEAKm6MFx87ukflwFCe/M3VoH77EnZq8JdfQLHZRe5OTNjreYpeEXqw5OFb9Qk4qIW6am
ztZqmyGhcFVUInsnKRr0t+y1J9gU1ML6LEnk4d13FHqaVPPPKcnvM6cfcI7zK+96vN/TA45/c4Cw
ikMCXPrzfeh3HTB0nnS0i72Mp1j7zUHy9H856Ke+UqbUm2hTRBVsGXnpykMVhyYVD9UUb4cwMDCk
69ZV+2qM+EQdc8elfSf/zGT+WK8eS5MXagReh1qfFjUIywVuYtA62n2F1XupZ1krun5EeAvxkqVQ
/hklkBj8ByS=