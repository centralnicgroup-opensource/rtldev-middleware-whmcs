<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsHgeZNaoXOwyTWt5Xlu31AJgbmUxqFvqyjGXaIdj0kGK1+AjeLl0s7laTeS+Lqxd4HuE3+m
sE6VZeVFw+pWLZI+0oZ3bUPCurhWbn7xSLlHEXiE3PlMuTZd/iDGvIIKyrUP37pGDJWjp7AePqxL
fZXPtdX99tPXKF532mTZLzdNuRfAXvSzTwel6g73PLK/fgIgEqsx78k5g21/oPtvd+j23Xb7uP+K
mivahmFR3Kbs8rOwWBqZaZdarsaof8TpbSxgMEqj6uMVxw+O+s6nlLSJ2XwwQLG6/TNgvU9SMvX8
WT8c8nigyAULggMu0bhDRQJnN5kusnE73go6cgNEm8k3y5pZqmzSAgd3E4OzQ8CxA2x+vaTEVyOk
T2wJtaj7trjZxO5Pn6oWtCZhhy2LtoHTutireQV136xzS3f4bkb7v1CpLrfxdTCp7KMH/l9uZ70F
2u7+Ar1xn5jNTFThhK0f0AB2vEMBeH67FyLLEYxewzjxMMFEXepH12ixzVJ6YTXI9goWuvLbhpE0
W5ihCfZceyZnx3+ilEaT3Vmf/uurkMOtGJVZA22ToAbV5PdAmIvNobtiW8tqvxFrh+KkFZ9MprbQ
TXR401onh7np2vTk0jhqwo5ryL5ARGVUUdT3W8Rly5Byqx0v/qCdy6yHEorTWBhCo/7Br8qxTv+s
sfJgXGthPkUpfs9KjQ2dlI34+OSAFcJjbufI1xQi9UTbSmZaRX7ivonGWYzY4S3ffNc9LWHJvyKD
vQgO7lOeBVq6l+4Ja0TG55smmQYKH1o/SrUkyyh8YLg+DO9dJY5XPdyinIkv85nmzL+vfPtBoC+F
k+ASjCelfIwEZEFcZSZR2eorp/KnpvIyEFkTzGaHNnRXt0RPciRrgxjkL74bvo6LFi3z2L1HCQvv
pYDSQdIqWTf43QowIPhVkdEAAAc6G6nev+1FvW/zjtra355Vw1BgLg9bsPGT7da3h+uXYSrH+MuT
6T94jT97OWF/uhTEufGo596y5hT4nMqZ17l5tCNoirammVVWbp+Ojc0HNyTVgnThk3VoGOYKG6Hq
zBc48+QTuLPn/vE+kx/qmwmAXYDI8sxJqMk+mhQo1j99NkmBdlCQIN/kGlDDFMY8iwXxA9bOb2e1
Vmhl3/6F+p4dkbfHWLypWYxEMPU+2P+UZQf5bP9HVt2PeVDhrsh5GmY6gfmfM/Z8TRu7jEm8D2lB
lcHMeR4SiFtEFSc+E7Kmm2A7cOBVL3unRbh/LaDkUKPqgv2Vz90p+tDoUL8k9SyrwvoQjRT81dqB
yL9THCXDHUMAy9jb0gMWt2YPb9U++e03Qgo0oahxVyCMCcqYFGp7tBy3p41pY9pM1+YT/2Zo4d10
CDLPLTpW5ST5deXXhuMkF/9b5uWdNTE8JjLEt9Ict+8zQL1BQDX4vU1TTzo2lVeNKT6Qd86yzCS9
p0C3NxOhUnx7InKvN/geMNxSy6ttmtUETXGl3CVDGWrBSyzhpohJPtY0AY2PwCQeKJdVrxlpWjob
Y7BPt5uTZyZkM8BmLUvA9/4h8Plh6qCtmaVseoHOIRNHJMeMUp34+4wCMaG0lATsGsxrpPNObxSz
DXxK4l74Yu8CnYn3Qac5fRJJJKhYrmjjt7hFmfsY/KZD6ejIlAv3dhHSFJtdpQUCma8raqpRIA2h
vVImPjjsMdPJpPjLbmkghOil5EYOVfjHOlgy0Ax+MunH78VBHWPMPsmdU0e72tcpqHIrsXv+uEoW
rUURBvg6yOsATrFzCU8dKCkzBomG6ikeiB+DScxz1zAG7/pYKqXlFWWL+2DeEbeTAau6/YcYHd8b
4jNMdNrmFWY1zA5AyR+lpWfD64XBSaqOYgmF1YeXYTeBEQjhAb19UhVytpGqkN35+42hEbuGEG==