<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv44uqLrwDTg0BPsPjMsg6TTpnUsSs0fqTEpwM1ifG/WJqFgIibot/8YpJeeEGjYz/KwYWOl
ixj6xiRtqPSTc651dJycsL9fsQxSP3zghditbj5WcKpxbCNUIe/iFWhntS76mBpYQhO/5lMRZMH0
eFD0SpQScBd1hE41K2W+X90EmwHT/60sxwDA3IXsBe05AwWckYiBwWz3Ny2odVjzz/Rzn1mK68mE
ji35VNQU3+l1i7UdJCbqCcABmDUigTRLiOARppVM9qz4A2UD5RIm1AMk9vbIRRJOZCtttM8oCODd
8HWeTbbJa3lj7XiVtitLoiJelXUYb1FxPkiDSRFD5HWYm/ft+tAZiiaI/FUicJCXtLREp0EvsuLI
u7Ng6Wo2pGJaOFMC5KR+osUKDfbbVqfw9y1nrPH4USQ53CubdvQMHQK7l55w5jRuEnrQzt/1eYdP
8A2oH0PxkZd+6UWM6E7Ylq//sfVuqJMMAP98pQWnPT+phaIY0sDem5e9B3rjijYkaAqYlgrhr2nr
vjJ2hv+P3tWXJvr1gC3up/DUB97VlkQIHVwirE5ha9RAajllPXD4qQ1/Rj/udAyS5PJvmzD+tEnt
IVKLlFPAQa0S87gYDgRkcw6TEbOJapKX4n5sLOUTlybrr14D/xYKS1gXYAYlhXA05Q+FDX2xVM6I
QV05KzSwhIrkkrpoV10mn99gJ9QRWyYvRVLMzBjjisIxWyiNwarw1QUkrRFFnQxkcBpy8mohqC51
2tlFzqXqQxKMzr2BERlDPr5KDyZ9CZHvBGvN7VMzBVhrK6XaQIj4dcIiAwRKaRWuWxKocsdub92x
TuKe3nNqMS55cnNPe1oZ4x1q5edUABNtxC+PKEzsjFgrvRgcvyA5VScvE+F9nnVYxKoM7KM2shg8
uP0JSd79UwI3sPLY1EcZPEe7kn5fOpX8CYdWBmemL/Inct/qldsixZCNcbb3RZ0MFaM5g/lu923v
KU+NspvaBc2rWiMqJbCCePjGNP+J+D/Xr+R2QPzsz/hToBlnBRU38/fSDyGOVcZ33co6Rh24XHGW
mBSwp3kWCAfhSmNVlIrqQVJVTOk3vZjF/UAmaA4LTSfwGzYOCyaVjw7cTuGddV5TnsJa8pFy5vWB
JmmWffKdG3CxqjMmSbDTfhOlDCC1M3VtpMrnuSrdfoGkT3ZQ4VA4HJ37m6wO27RvIEH6yOakZvah
YZFehTIjXi75QSxf+gd3S5gFd82+0aaJZSSpd/roVH4GOoW4tSYLa0x5LavgnrEzBViKvPXQcW67
0zeLWqZg47q3zhP7cKIsK/qHmBKZpPOuyhSbNxrwxV1+lLb+zmseD9IObHa691f3vc7S81Nq5c13
JFlN6Mq4uNcJz2PP7jJ2fdhovCVgd3Tu2GcKkvP92vYUEFpP6Wb5fP4FiQm67B5byE6Odbyg2MAS
d/uq5Hzji77BHJE2v5eQUQcIao0+6UV6So/+rA4ctYU9ky4ZD4EAaS8B0bDh6Ak2kouxdAu8pf5k
l+0HDyvAxuMp2/Nst/MK4+z4b4HpQe6i4UiR+1DMJSyvkCSnxFQGa9X9dTWxakwFU6Y4bre3NbsC
KsNGKC3re/7aKknZ1QmpicqGub1RW2j/0IkZ0NQyevNDAZie2wZEn4ZBdCUnGq3eRvt+kQHDHX+4
HuCQP5R9V60jjqLM7RfR6G/qoitU+mjJ1eN30m8qdzoWy5/jBZFjT5sROKc6KoQGWLgO1gWRWNJQ
fiMA9ZL495BeSmRsgTS+Rp6f+kKGDHMO6bdcfTsIXIsNc/9CYsnNqSmO1VlyrAI91/DF4pO8wu5F
e7b9yoClbn9YyXeK2pHeRDUFaqdxazA0SwKwBZWjlkSqFQzoiskd8+Z7O3W1a2WuSluV0m+7bPOB
+RXmRECLIQglQM2f1W==