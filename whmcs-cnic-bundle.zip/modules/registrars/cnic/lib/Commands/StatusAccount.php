<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxTxKW9PnQOr9Cd78OK5c/nsIsymV249SvouVeFhhq/MaiBSztYLvKOUJBO56/CEexUJFUse
bCMDRZlz1Bsw4w9/vEXz5jkJCykNZVg5sYVvJYfB2VHTflv7r2lykgbDlCZWewm1uIq8B4cFCnQ0
PU7EdkWqSxoUGY9ne7TKcllNocx0ppsKnlEoL0tyRZIuB9Fv1IMWAINzlodR8Pe4wvzm40e5Jdw5
YkgrUFKbT0YfuH6FJ+Vfy8OBkQqm/tRmN+OLKFHTFJwo43LofB0Qo/2MmtPiIv8Az/iik/J3kOFT
KMTLPFaTrwOaYKqvCq8kysY06h8kOelSqlI1laWqHj8bI1FYaCteA0tr9gSnu8DEtvOd8lhimZBE
zWW3UpICCZtwKhluOqlWsDczY3Ea29gnugJ+rv1DBXOOvIUADjZL0ETTzOT7jOELUnkQefM3GUno
xVRNPViH6tg4al7jP41VDgTVs6ij5E5OVFwv7Ci4ZXXRN9nin7+umpgbRMLs8NoHwA+asZ+Uiz3h
4u5VFU4hmE/qQpB7NErXca0NYqnb+s3fVJ8nj8f5py6Odu5vHIObhMPFAQxnWLp75Qybyox8xGLo
7/Z8z1LkWlciPbEtE07W0F12Rjz0fDFbbbtCtAuC9VZhc44jRfosg+EFcHHR7JY3eaCjSr8xTtSU
0X41Zih/vh5tcZkHN68cS3XsUtIxAUZ5WHCrqJ22FoO7ZCZbLrGv2CbHrT3G0DdMr20k2yd82pXw
Cr/a82BrlS+lyYSxKgiULTBVFw2KWjL/yBA6StIwcLsG4f/FFlJ3X2N34Z1EAZPN+RNUSmiuwroU
d2J79StxcDgpXDVuhuEtAJ2UDkcpeKF6tPVpH3UQYLvcVmXGDm18IsttqJ8UNsyk77Uedo/afDBK
Elg04ulF+MxdgzGrc29/YsGA+WSnNQdVrpda0UjRREHpObSYXtoezOKzMJ4v6qIm0GbdUyRE0gTf
SVxvdErH7DDWT2bS/iYWDQj4Zy+1ucL8gOuXFUJ/rZIWoMAh04pBVA7MfD9bGcNxXywK8fJBKBHZ
u5auZkK1iNtCRV9jExUh9NKWkRrqWnU2yPNiJMmXL82VMqwwf9E5cbbg7mVJZWPK7UeXc65aDIKe
Y1/n/i/wUlgD9lhvQ456tbiHNFCkDxFHcvUU7qe+4XSLeBtolwZj3591l+nN4o4A2VuRp3PZM34r
t6QpK/u++RCubF8nV6k6k1p6c/2zsmhnMiCdK0Gg87F0LgNRT72qyb/UCmUJ+RMFJP5HeTw5eRSI
aYZ9ban7E7UG6M8WoyzLm4ygAwl0HZI0Kvga28wInjTZ6V71cShp60rcpHro/phB/y0nRbXizd2Z
JW7Jh2EFxKYvjZAN2GTvpWhCNKQWDOI8xNsUkR7LEAtTo1gRw7sK46Ff20mFCOSk6cyPN7wUStHc
fBXMNTIkdsDUpZJfRiuvjG8z106Y9BUhiiXp6DKlfGVhZvwI7atkz6QHPL3XYlVfdfhhgZtKRtEZ
TO/bUegO78qSxInFpSWcu+xjKf2bVffChAlLN68o30ciSSCqOyk1IHAzHF9CExFTex5VGMx8VX5m
Nx+pPCi23K8QYaRM1mcCYlT7dNeMj4dxuzweC0Pf/b/pHFLJVFiHL9kl8z1gcDSLh7iHY/fYgPYx
IFFL96gWxSjTiSIz3JzjtrOfpml49JSi9JgQfUppO2mxATC5uj7oNrwXGrF+gLWHfRvIGU8oKBGa
2I6MNcTdQWjX+oBkswhfBgNpoURjKwmOyDAkANM9ooJ0WVY9gx0pDT6U210kqQO9DGCA5SdrJ/sA
idzqvQFcTkKwAnMOQ4XVBle/oZk5SUy1Ylfq8XbUn6Gc4zDlO511BKoUowhWdiWhEjrmgx2dKnsg
