<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxwrIB27ch67NWVTaqHwUP5PWUtpCL1LqBAuxIW+Z2cvnbP9KdESA8p+llijkzW7jpNnIvR3
2BbdJd8rn/65UAQ+lL0/l1dZxc7CHwldwHXrUeUWR2j2o8zZmgDvb19lsbTe98zBAOcgiyysrmLg
xAldsBrf+YC24CeaE3+APZEUy6OA5Qzxx2jq4wBIO/LGVXVX2ccoIZyuFxXtqmiYAAaHk2AtTobI
ZpMcGowa3eku6WfOgyen+uGUyE+jTHD+g08W38PGOQjJKu8SAFAUjXXANTLaJ/QEQ2/vCprDNXW7
FmXU/pqpfPqAuQwHTwAdr39ewDlt2VcW4WTPfp0ugTgcVlAiKr33SmQ12T2tJaIhJZJRS47d1ACb
xcn7JAf87eMXdnazNEO6UTPddfqSuYcHbOKGLnH0cG6qwxDfEhxFDSoSLvLfESYV3WFFgHgCYXsW
HUr4NLh6KysD5XfzaHR3RsQjgpAZ+fynUebBYvxVFXM/Yv4f6DyKQANa7dIYCjo6CIdjzOx+UNFo
WSJO0Nl39STvBOYf6+nM7qejVQnjdijIJpGr3ueC7iuFElXmag8v2XOJBciPiL5LBCTQ6pk10qZ4
88Mk4QGUua/xdnBIhNdWUzteASU8iG0GwYOZAtHkTpV/6uWoM4ZYTrMnNBfgzDUvjlvzjAvMp5rq
TDCZD41PHaamzjbJR4KV6U04v6BsKlz7pceXZ99HgBpHHe5GOYKLv/B+ZrqjgYvjmq+NIKba8tZv
viu0cdD8yb+uOxhNxYaqzvTH9NcUTgxf4jUt9+fQPACJ6YZUEs1RvT+jfw08WevSHR4ovp04avD8
djRhahdZVOGfcwWAqz0nNNAde+YFEwfkOAQ6NYni5ZEylTHj0hmlmk9e5+cvpkzQwJw7FgSDYP07
92Jw+uqcLl/icaCH1J8Yjt5CStowNgczc3G2ko5BkPFmsUX4itXULtag4Uox/uoIRTFx66CP63Ts
WJCFOF/gYSbUcwmYHJ3cXx7kQWVUtA82t76tyP6/fn/wIr1hH1sgtTYnYHTVUBboPAywCjMb2Csm
AlIaI0Ulx6ubywrI90nFV59UDTpBSfhhXyPBpopI48LWygos01WhuzivssUaRnaDz8EPmcIV5msG
34VHw132Ru1x7S15J3LQ5wwMIubb1W+7dZdtmZzQFLNBCxMt050RPXd2GAbRbMZac+f4T9hnxAwY
lMYJrINsLx8fvWOT0Kilxei+Q0dIr2vguJx1g2OcCPwKZXYzD7KRlygKfLtCaJ1unT/WRWQhuAqV
7Q+YikCKlH4XyGa5HDX7Cwud6TRXRx70yGy0JFrCLGSS/v7jUQXgIMe2R4RW0yHSTrTN6WogKhU9
gyYk2Aau7INsB9+ikZjdAYl6AGNStn+HMxQLNJwBfK2F+s7PoiaSek47x+YDsRmxl0K0UHZyOF8O
+C2U7l7N2bZTxJKlm0dlZQ4J2s0EQ+jMyPj6g65Mae88sxJFii24RoQH9iNkCry9MuJTydT2XZiB
+KBy9BbLm2im1BPPYuzLwG6A5sTLQT54GRlv7GVMY/5rJuScgqlSvOJHsahjAZLfZqNgxQ5UQPjl
M0UpzFjAuxt/e2LRzCD9C8ZxO5eqXtBSqPUh0ME3J30NXiHWL1BZPAfqJhVry/BEpgi45POExkYm
OdgVObIHwU6RrhgJ3tvbIOvjc9KWoF8ufRTCxckQMPRFgqUk71FlHKMbGt8s1MFaVQzA8qGhOonj
n9YkjT+XTeLz5aAHlZHpZQrc/2W6IuSWrkGOCQrDHRDoU1fPdlV8wOxZ7yZXGcvumGG0jGHKTl7n
4MBxZjyxiRujrYTNdn1lkYfcqnhRJaKAWddUf7LFumSGveb5aBXAFPR9