<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvx515X+A/sV1tUHUsda0biJMv7VPlkyQlvl4iKxUEtpAXgX6tzNu7EbXaxl3XUnGS8Wul/+
5yJdvMedbRl7YU0NdtrsblZsh/AwPw7oZ0fP/ksTpX528ONy0cg/N3UxSh8kQyJGFIb76hvaz4qw
FGTvh1mI4X94KcyOAqjwYkXm41a/igR9hS3hh4WlkLkxKRSzDVp+CFJhTz4BluKiNA7DTRxs8y/S
zdtpweVJ7gRaZkJhODXgE+Ms3n69+HHlhE+uY0M+N5EDoKg9JE/Ip5cP3c4GRidb+mm0pNq7YAOP
6268E/+O2fZN90latobkMN3Tw7y0WRESG9OjsA354sF858u60dzJqTBFPN7lcDAlGEpWq7ZyFcdj
qi2wAsJS/MyBuwYIh/tRC0quJRgr/bjqgefWmqMMiU65uRVcMvgxIzdlifRGo7m1F/I7oKPUciUD
mWFsuH9id67vfOCR4MTKQ9f9g680dkBzUzQREP6Of1Wl+iI/8NKIA1yHEWYc0cohE3YTuSlqxZa4
i3Awrvg0dtBabpI9yJgOmmG4bzYHAreNIsAZhRZ3DqlSEgIzugXrneCssVtsMIwEjLiZA+uzZrSo
5Dzl9oC6bvb9l3EiEsloSTQu+uQhc8MslrYmCDAv5u86/rC9ApdjlHVBR1MrC3gcfv/ISkWxvQ9J
Q/5LrH5WQo/81g6Z7ACu9jEJ2WO0OrKBzCN4a8cyCj1dIstypTZyn7ADRbhCLYbGrx377NbVtBa+
isylC5ajIdWCVCkOAihqrSHTL7SBmM5x3Nw5VetSaL5Fp3BE6m442pD+CvhThlKpPRr6S8x1Jspa
xy2q6FVZVFyHrvF8T9S1KYQ+noOfnspS3i6mG5Klx9jB5tRpgbc98flUUfb2Bcv7gs6lCaDgsoLO
owSoV5G1bt5UrHA32mI4E8iXIMSafhdDaMc8jXVR6Ny9FudgkqHUBCRpPsdfzubUrJfgp2H6c717
+XhiU0y/9VSPf7vyxl3LdE2tkdHn9wy/vynEPcW1nuxytlkLKNxOFbIcqrrv648Fh9wrRs+LE8z2
Vfrke/vncfoV0wSTZnm7lvx1FPMkWGMz5JE74gNQUbqboEkXRn7rDFK6roOAO/45t5KVfvmY2V7e
CgZKZCi9QPC/ASARni8z5HDL6cyfi/V9v2wUFk9QUYJ3Jt5X3Zf8hCLtH+gTnJaTxck5omiPYr8u
v0z65XZf9dUc/3JaucDpiN6JEXGuT36L2YuBI+lBDoU1Lqe5NcWQIidkbmJBO1+3xU0q0d04bbTI
pzcUkl5m9rGBrjJUuyPYjrrib1ZbPATnHj8r+6UJ6dpMqfyt1CfJ3Phm9Izj4arLVxXrluzYv4gs
OKwNwboe0m6CMzY53W6Ie4PbLVfyK3UZPqtwtOABqCk5hv7LDq8t4DAhOuCZAF6k6RE3PW0k3xpN
GKpcEfb/6StA4JUeruzp3G39GyP95cHFLnym+8j93c9VsvNZVLGz8aL2AtGdkXziAt+5XeJtmUsy
tER/BiE/M4jNYVBuvlUk2qlsxPIY5G25U/4RgKlzAlAdQ4iRZQNVnkeKG/qOyU6x4AXvpWkIKfok
MtwfjuVvAWonU/fEX28XD3YDC7PZlBjUVomf3fNpyY6BEnpzdDEzIPnHpwNfrgOfp6nnBx5LckX1
UPyn7ndAJoWjV4KIavXC0vuEVheS3tYlPv7gz5apXVojOqFxOYqWAjTAhtKaZZb4j/OER+DQbmjB
iB9kvzZSofDB+1eCQDuk/Ec0BZ7dPkajZ7S947vO+a5/mf3Rv77TUZOp+sHCjFrk0/JELv7hN5nr
AKum5JP0jNDeBYc1A4Js8lF3HMjptdL54tnbd6ne/nNHxanyFRY7ynGXMNHMORNNH995