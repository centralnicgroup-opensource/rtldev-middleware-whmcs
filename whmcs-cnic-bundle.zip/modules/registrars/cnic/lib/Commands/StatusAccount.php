<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv8Qxfrw+jBI0wXxlWzZn9di51/KG4oP9RQuV/8ZXRTz93KZgSrixf01QWOQELTfS/DMoPJw
TVwKg28GJhBuYiAo9qcxzEnaxthPlg3OT89ePJKM6TidY0uuWHI1rBTLh0Zba1jd2x1jhbg/76a7
jSOV/4AVSSqCoUPG9TE1swVSe8gaoJPOcIRk1nXVTwgfzJhz6QXRR/5jS2eOXNnXxK7DTq7vS9KQ
WBpKVWy0WBIjeKNF9w0w7PcT5mKgYs+REfQ5nj+7fmxavcCZy2lxBYlnllfeVA3YWP33IvzNaOyI
F0TYymQBJ563iPLEhcyQPU7bD1u6Y9jBaEiIAZIbqg6wClNaFyPT4UwfYs4kW3A/UWozGYE0Llmu
pjQIjrIv16xs/XOK+5t0pxPCjtWALTqSLT4NLuam6wikxMr6TzUy6dfDkxmNIusp8/oWdELbdeoN
TEJ9eWBegu8v9pXJyY9WYKTHT/Fao4TGvGCJ7zS0cQOg7h9TqbPbv2GxsMAgxuTjuAqt4P30FUVS
I812xGaiIMY7G8MGvgSkpZv/fwOxIobL5oMJJKJSgMbiUuLm/xgQ37jui8l0nJDauBZotpixYnQ0
A7RT9ldfkHenL70GgGS790rckuBUQGku64Nxl68DDqo/g5Z/vab3BXWF5LyTYWcgwkpMl6Kuxuef
Ns9AcVnrT2M/ezSKtvNvC3fsQQYbQY6T6cjfK2xq6seo16XrGJw43VBMAzsduV60AluPTtR+UIQs
btc3UAOuHW+vEypTthJbu/K1ygfS0jhHhEXODbSg+kbrCOTuhyHlGstuERSTYvfhbqywGPvfYSsS
+vCNXV9+vbmTjeFr98gkCSK57g5RhLnolQIN2lzh6Lacwvz6P9NvxLjyn9IUsw3M4DdTGsWtk0cL
en6mi8ZC0KB7trJFAr5ayjnmjmqiEqdSVqkEwEkCxpaRKtYvr0EskGUQoCc9iLNOmVAtsw0sQJgf
PWQqe1xyFVzyXR3VTs1PqPVmxi011EgoCjYpIKjR2i2fwSsycc9mG4gVUuA0bg3KGG6cGeq9zScj
aq6nAMkBknd5yiOwDClvfeScALwr9X70oWp/8ddR7JiSLkaUQvBpNnDMpuxWGeP5hdHbRZJ7Y8Kp
UZbBKD38ot7TJq3Nl18c9V4hMN7/HENuYg6x+RwpWxNfUxGTwC95JAMEJj6MO7U9VLZQDZQ34Szw
52hcly2mkQnfznA7XVXJNVKbwDiXsmzOQvWwZI9CAWCt+5bC85Rb/lpRqgcd1E+00CIJKNbAOP1E
Or6DK6Ae6CT0yg2ctT7gzrgQ8ooX5YXaqMIyyB4oZ7rpzrGlRlnan1WfdgaIZrVdZiStGEk4fFx3
LeoqQ3lKBX1c82d/cshuUPgb1+PJShDZZkgOWa3VRJxKkbe9zRRGrbri4yRnHbYkKl+oFSF1/ixw
Gq0iIL/A+VlN3oXIdPulhD85iobjru7N1SYCXM8Y/PYAZyDtaECmVDeEWxuKwMb1YnkvANVB3biZ
lrL05XmeN1Eb/EmOA/WzElRuc/VNbcnhbGZ5SNGJaAFAgxx9pjggp8/Xn7R4FP8lIHAV9sKhpPwV
z+ruk1X5NUwLDlhzq3wQeDI9LjB9Mzx2z2kh5GqHx1Cmdb7wabEG8KaiYxQa2j36IB7JJruj0plu
YCiY1QNqbBkVo4iivkm9RCHwmP+SzbKmo5X0/AI4Is3FXoN2dVl+4OD9iFOOkQNKebe6J4R04G6B
orri/FWOl8vgFOuZlnU9CWK9erOoCYKSufKM4t+92X5PTKSkYRLMXoPbcEzMOA1P1nIg3Ahwju4/
X0qW8wFpJmUmSDSWIXD31I6Uc+sKeRZ/AvjYAF7M9jVsfMBlhmoABOFzFiautAvlE6FfKK5BeXvN
ISm=