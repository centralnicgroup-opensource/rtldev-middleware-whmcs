<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+BQSSLhEahhScZavf0Yxu8AQxRqPimkEis0rBVK6OdKeaw03J4OYGwljzWQ4LADuNJhPKg5
eVKrORFOX482bk4ISWWMnVLZ5Ed57MJy0DJxQwS3Ue8/0xw7ig91BPfoDdOdLzPif8O5WPd4o2xw
iAouAdE61rzfhGFRymwuNry6aDF1qPEs4FXlclOUCjZx0IrVZHNPKQhl4T+bDsBuVTFRnhr2Gi92
hCNvGymIxFae0p5yfIDZODRMwpG4dTlBf8RWd+u+vZTL4SIu8of24mbqKoj4Qk2JpgDN6u7IOBjy
dSW7AuBYWYkv1ve2Ye7+V7qZqT5hvdHG/kUVu7u/zfeeqovREM+Ox7IZl0LTMbF3fj3f7j5+fRpW
Xk6K77sHCeE8h4s4nOpAqZKN3ziVvc8cdvgg15+scX80gY8PYu2iSQi3QuMMpN6ySupFze5fP0Xu
1SkyJ6KXIAC/YKWVMDvdcImngsgLY+aQVAPLpuNuBgTQS5jOG0iz00jzrlwkb/obD0UdbEUlfpeH
JDY38QneLFvoxd4c/Zu17hpmCHDfMxcl7D4xg6oBOiH6+fh7OC+elMBToW2Wq/R9U+bcwXRSnaS8
qy94mVRwDjunZQNRWwFq8vwmlku6mjoAlBGdGOzTAEWV5YmL/qBY5cIVcMwZmUgDA3a+KmGoq9Oa
50BT+i/60YKaYm/2nFZucRNLsuuJlfMO9syOBnTrqDMSTyTxXBzDX3iVQMne4zm44SMjnJRFp9+9
bTD0py8WiBt6tR7H5I5zQ0sacLJbYL0f+V+3d3UdXx0aXa4FO/E/UlV4v2wIYmzR+nJpcNDBC1Yv
xVAm+UYhtnJ0to3zkAaHj6yx9dgY8DfMFwC/91IpPbqUGSrWAHj7TQG7g5WOv7YoEBcu/lGQSU3b
xTfL31CA0tAb94mYGksva8AoDcemuU4mqcztG1xAX4sla2/A9JJqpHcbIES/T3Vh4Gf9kNAKLian
RB9RfZvBaIJxs3lWpqWiNcEF8eVdSGSeuFxxPAmNSUMAzijfTwpQp4GXbvj9LnAtPPl/ML7ZrBSO
ah77N8omNl3mHBk4OurC19SI/F8n9/vSUELE0y4Cc830/7/lDWxGTzI0AhCSO9v3iCGCy1xW8Uvb
188eQm0cJkT9Fdh14zVHYLeDmUk+imWGW0j60DJT7Ffc2djtgJEtti4Qy7UXH9I2klyhRMkNheoc
fbtyo4tEqafP/4EFZSuF0ab80Hg6qA5Va5WxJezfUmtKSX+ly0mcM0MpMOjAP4SAqBbz8qUcBjHv
MBavjedjDTKA5ogoWnm/aOZVkUwfdo3bn5XiH7pECmM4kPUv008CItB/ottLxnrlZzthVDU0AJY9
nn4dAP4vbSpaRIZLH/W/sUiI/Cdm62tX/amv9mp08LrriNdEf9PPxP9IoxDRDBJt8HIFH5g0CdhO
AMkC20ANHKkqPn/Y+dzJN/Nx4HCPpHadr8SN0u80sJt2M7nHwN/WkXBVrNB2r+kz8Yc68Lep3NpO
IA3wDxNcWiWlqLo4bxBGjd7g58SrotB0XmRPuAGTkIMUkbq7bsEop9LfJ7HnVz4+xNcbUnsPuK92
OqMDFV7IJwwJCtWaTOWrkmKrcJQ46lleCymhHa/WS966oBnsDuG2YQg3LAt8pszvwUEFvB7+MWO7
0Di9LXrD0b89Tfg5IPda1ke89Cg81BXYwRnZQxVy0/CejZ1H9ZYLvLkbLRl5oSw7JinJg/46Tcyt
CvAz+CAssSNZahU65TsIcMI3Fm5uDLUpYbzkfJPoFsL/QWl+Xbad6WzppkW7d8xy/ofHzmgKylho
zTqhnoTAf2IRD9kXvlnzPW3+o7hQbUW94QabZA/O/9MfWyh+DimOgowwYuxNo+7Jw8cakiAYAbOl
dW==