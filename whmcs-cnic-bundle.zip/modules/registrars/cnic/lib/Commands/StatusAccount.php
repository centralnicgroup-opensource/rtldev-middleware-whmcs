<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyqJcdMt/7vwJg4FLgm06df+ZzQwfVQHNF1AbDDXlBEAp6N9GVa3PhMGgFDemxKY3tIDCpNT
JILfSTI06BbMhCQ13T18WV9qRVrsMRveEghI1E57MP5zr5Ogs2PXw/54wfEhtLUkRJdJaPIYlMK3
iotjJRH6wmpw6dDrXNko/Ai0VN6vWtT8IrUR6aUMu2b1yapiauoPGpsR29ELvGuqqV/eToVvMk75
bPUSvOR8JcdPcZF1UAFdnhICYjyJvRTAMMSTz4LnBc5XMRATCsgUDe4RlvvPRf/RceWTxwniMiYF
Hrt8MXVDp7QE1bvKDYyjfXvqt8wGRDlgndYLj9h6AJ9Rgz/JbfKBEqqfOineb0XT5SFLmZ6ARJDR
K9hJNfvqpXsQoiErw33BxlWW3ZxCpF3wTOdNKN8PQ4hiAyPepVLEaAwmHQQTEj4DsFAglAKnJ5PL
I4w5yeAKxuirXJUlCVZi4QCd4R2JS6SeSQ2NCee16QP4sDWhFzTaDzgA659J8Lgn8mD8jexCYy2N
PyPk3BAYl+kcU7buCMFUy710IBIAFYBFBF+WxxUHfbL1uftEcTY8QPH6QOmTjIsBaSGg8jy06SyB
KPiOlcLAZU7ZBtK/N/+J++wcEo8XNp9czIFkafRt3wuY7bFqjU5vVIaq+3WjsTKumrsLOuJI5gcc
7cVa2ga3k3U5A8UtxCIm7M77N/q1pHjfvx00Cqwg7GZFIoMLwZdXrmUkRboCLNT1ajcWJB2Ymj/n
EGYJPvTeV/vK6tzhhXWA3Poop5aKvqg4q8W52z7fgBQVxLy9L1JAVugXS8HBdIJ9ilMW9dbVc2wm
THWhiHdG/2js8XePsujLlPFHWp/5b2Gxp71z6ZKJ6aiIyAsrJofAJ41m+BEbly6b3/+lGwwmKinC
o1GFpS3STeEVpP9Kohb/mjDYLjyrmKma+vwUJG3O9xYq/M1AhoUe0DSOPzWk4Dmz/TWKcCwCzwzP
DTb+r+fGb6uN1aVsUCn8ha19IkFXINRralJe9ntMyR0CUOHJA6V/VFPwOEsNOvZlaVEAI9VOcUpR
q/si7Mw2WadGJsZjmnS58z0hTP8veYADLUUceKvGsF8a2O3CCgFY9b4micrFCMEFziGGzeiC7ipt
6rfwPY+j/K0L1m7HG8ncPX/aoktWUcQ5XdPT46yqEdK1BAncatBhssp/OViUU3fBIjGzl4ozo6SH
bM8AANe6ZVWtcXS1byInDbVdZELFmijEfFKg4EOdmfNEXV1vXl468OjCVcicep9y3H9XeAmcAmFV
toycHGiZADS7uf5va48mFQi/Um+NMLrfs8zQFQMGaaeS4JjiV3AldzOIEyQ/Qs7ZLyoRGdUtm/aJ
xx2o+MPCwZNoZEg22rxjb9LZYKthBxwiKj/fnWM1DHxA6Bdjh0n2PdvuqHXTqPuM59tC6Vs2G0ro
7+/FEOogIub4mTgJauwEEshsC1ShGtSxIFLh5R0f5xi1WZ/UKGlucMqADLoKtfffRjj1W8lTl4+1
B8ACROUo+7b+g0I9fvtzTUAVlsCAcfPxNo7TUns/7jifqJufttI+Lj9M+XiRKUnN3J9BuGM1xiB4
EhR7fnf2J4vQi6b1MoViqOY6juko3INlSU8r6VUybcgqT2i29stgKc039xVtERfxTKh9dCOFJe2G
37zN7zPbwtv7ZKbP1c0ErCc4HAzHpmhpU0KdcfId6RkB+SWA8VBOqHetObUvmmg4cOesMBATM2q4
CniITqTpCc0ZqBwaBKN9qHNBp86d1sGxLfJL1+r1Hb7k9FVqn7oRIJbDrTdw86QYoKldg58Px3d/
QBUAddeFJZlJMbjMjlrNFIq4yza/2yxPHI72k2ywK4UWz3aJbTiiWCuhsodHTXN9M0cs6MyntiGc
QhZB4C25Ni75h/+k9Kwzi0==