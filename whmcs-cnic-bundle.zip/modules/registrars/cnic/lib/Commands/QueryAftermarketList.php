<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

class QueryAftermarketList extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws \Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["KEYWORD"] = $params["searchTerm"] ?? "";
        $this->api->args["LISTINGTYPE"] = "buy_now";
        $this->api->args["PROVIDER"] = "Sedo";
        if (isset($params["limit"])) {
            $this->api->args["LIMIT"] = $params["limit"];
        } else {
            $this->api->args["LIMIT"] = 100;
        }
    }
}
