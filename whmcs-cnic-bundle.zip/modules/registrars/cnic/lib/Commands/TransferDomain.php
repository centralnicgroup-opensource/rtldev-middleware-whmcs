<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqXVQYD+z6uL1vh/001rWKvqz/Q+/j5yXukuVkXi/EJbuWZXwJExaWc1x82V2Q7qfbvT4ou4
VvElsvNg81egnUQwEBWsuIBSkis6tr6NzAFOOsvldWKbPEp3KP1LkdtOMI6Sz7X/4G9xcMtao/AV
fyqdolhUVR1Su+ZyjwpzfvC2lub9qBTe4NwzquSnXtUbi9t70LdRQyVz0PEcUc3iRC0AjRQg3kBh
jgacz4XiFkVyLwZVLMZjpF6yDmKevt+cB8mDVx3TJcoLmpISkowBr9pBQQ9q4A9C7lYIoEJLwei1
lGTh/sLUpAXEP+9ifMKlTdKWzK4xhiiSYK0L+MGU42Tiy/rNR2Jv6ZM3IiCeCouVTNxXxi18EPOQ
gGt+1DsRFwLP8LF4TLMVyxGEMQYMY8CQmPE/2KpQ0L3JTE7EPS9kW5ywnC1Gj6MuNSE0cnSCE3/F
NO7ITtING2+h3lgyeHXAvAjmZH3iVTh3PGFsJBw29374uYOWuPvHSP1oTPoS7aTFMLisT73MK+kZ
19Zt84wr7byU9D0sJsBZNJjfUEYJzfUUVCu9c6FzrxWc4GeTLsO04svG9NHqEQe4oANcL2SWAb7b
8mis6+mQpsY3OO8CPfZ+KpgUf8AeSokRWZWYVDN3dIfyvMAy1skgOEgVv5FdO/vjPBBnqcoQcYcW
K6yu4Tnx5C4j35k9kFgOSc9e2E+kPjMPnPlzHAcTT//04hDdQzwk85Yer5WggPf8a/4zU6/hQcC2
GQ644N5c+yJdfraU/+QD4r2Wiv7arf7Ly9wPrGAiaJZKAAYiW2tOhpxz9ehtA89ix/lgaH3MsSjB
x3GTwprestx27ZqrqiCk8YFHQtdfZb99EoIirYbEpFZu9CHTw0YXZ+ZSXbBu8g+SxAyX9ee2SOI3
HPFvIKNMGCSBjW9L97gCftctH6e/NfW7KIRMHuALNxiwfkq2NhMW3X6CyOzL8LftjwCAVya7a4na
Q2pT8NGfVV+giRVkBb8xA06wqC4RTsVIFnPtKo68wMUH75U0yYJ8hBbACv4m8wFh2429wVZ+fDTL
pW/m3p2v7jl6sDoLznBXCecYJOvxlnq2YrpVEJuA2gdTXMTXgndS6vF0aZzGsCzgMmWjYCsXa5nF
UfGq1cLA2LR74xWXvVhd6Gdi4ZcziFz0jlhypnwmpI6Jk1P3AiD+R1oZjTPtgh2IQF3s6SubGNhG
LqqxEI9WRlO0rA77cO7PAIe4bOjfjgQbh20FOF6UUVW08nEniSLO+X5sQYL6IdGZKgfxhTF/8eMl
j9SGbDDjXqbN8kb9RjmPiZE0iJfqLeVrcl72kY4HuyFJhIzVCiOghZ721zV54dG1DbS2AiTjAUv0
XG9QaucFixO36g8qCUUklz2gADZiHWwEKHU86lJ2dtnbl1+cgoMBGySaC2mAYFTQuaLyt/nDWtn+
m7O0fIBvZhmrgWcwhQTsGmMxOdefkZ179BdksCBha4GCB6QaRMtu9HpWlMifKHCnk4tSRGur3mSc
Nrpjl3XqUCZ9P0s3gV9K1JGRQvLHqPPmrx0wj05OYDLYDbkDQdNR4jqikb2fYJKU7p0x+buR7Ssz
bIsLIjZykW/l+g+Dzzxy5k/Q2zrV6lHxmYzINtvdWS3MfyQQe5helnoDpLOC/6/GkRjjXNLg3yyJ
OiGohK+DS3h3hz7WLs3/X6Gz5TKt2qifh+UsB/0TvFmNkygRY3zGIzZMCO+q9iOCB37JW9rjcWWV
ZY6cP7iW06et1te4DyA3dL1Z7i2ymvzsxTT0mbAj8bkqydD2PLE2ptRJbDq748HtHW+Yzx/aDvi0
NZYyTnw82fL1TMu4KGvsBtIP+CcMPHkO98HLFPlp8/TIXuT21dD2O4+RoeOw/xemVQVZEOFqG+41
xkaLvl2zuEQJjE+v4uimHrlz9vYSntNltvcONVak4IO32NVCNRm+Lh8uv3l+nzaAoN+pbqbLGEYL
8saAYlslsfSh8IWJGFjnN+HSoI9EChOTsnHOSOjly6C13HxFc/QamnfcJF+T2QeNKoHeVEWNV349
tTn9qyI6lKrODnhrROq3PBdajshiH6Hx9JE84P5j9qT8aAZwcciVeMOMsKlzrP7ukmYWNhuez4lu
BQ8sMfGJVCiYdTZRY5PkPYfDfylJvNivtdnIDUPu8c58Y1dTO06RAZRkUjTszCX0mX2uhKceWX1k
tKlOu2XeC6LW4Zh8OdUe1yHSrS4GSL5vQWEzRH26t/hXQl2jmqphUALfaJy+8WDkdaIgrrzl7pUX
cBkHuFgGP/vRK3HryN3fT4eEvE6ajwjRfKaAp2xLUFB8rE0ecHj590JRyvu38KD8RtwmqNRFYMxS
g/5PCYwX91lQ+t7mOlbIgfo2b8c/WupnWUEjteDd2YF2AQkcyIaza/SCQF44bjtog/KEN1Ey7Tq9
Nva0nYes1l4qvRZpYEu3P6CqRNxCemifLCdKIeLUiCN+GpTVnlaW1WbuN2qKvSPUtZWMW+KJnyQD
UB+32wMAB2SjwtVIq445xSd8GN61snvhaBs6U929grN+LgGQrdLMpVfI5IwXZz0oNjVVekuompbK
v8IlqwE84ntysj6NcB9Eag9o1ZTT8AoGrP9ETKsYiNMOhDOEMYstE3Ruf/mOXO6JWMAtyeO4dP6D
tzRCioueS7zX8UYkubD7VodTwj/rWSfUSBxnCwQbcI7Gv9iTPZ/+zrtzHNAcYBLjMsp/CJS0XqmJ
EbNMxI9zNJvWT2jprQto6ORKZw+/+GCrggRfOJJXndwgMZhkXs26Uob8n72xzeB8UlA2C/ZlO50h
OCkzw619KoRTtWTuUS2oc68Cn30j50xuUhT94tikDlll/o8mWmknyhBH18KsXLcEKLLbCDuGa0Qe
WxLw/f954tqm1J92mQFW3ca4fNnOlkO9msemStJtTVsZsFjuyPxkaOJIgPNSRqoCFW54nwU/qj5y
D8NDanCV75GCjUxqaKauvP2viT4cOHSm+i3ZJaOlQ6JJsWygfR9oWacuQ4ZH+Jl3m+F+RIJIBZt7
3b2uQVsJt9fT4lYEgiLADhoubwtz0iOZdo445Tv1q9JbNBQ0fwGnzrDmEct4ttI4UGincFtzsSmE
emd4/IgDgsf/uUmvGFUbzECMAAh1vuSBfnrpUg4gQzH+OCDFvdShTJD5pNS/LAncCEOIsf2TG2z8
3ujvQ16/JpPJlkgMwSGnmp5y8qspo4sYSk5m6Y2l467+hgPP/Jhuy1dF0FVTbL5aCiaJQND0y8x7
IG0YamHcOvZJrKyCCNSGe1YSBGKhBm11+ufHkrzk2/vUbXhg5YYCrsn6igJAntzCzOE2nJC7kjlb
tf6ynfFqTJ1vUHn00CdJcnGwVphw6WQigBusrHSgZR9R60uPaBPH+0g4H2A0Opfq+Z7jP7aH1A1/
/ojmwnPYbs+uixVqURDvJqXEy1nc6tguwTbxXvb5bUzyBFEyXDo5EwPIMcxEZkvxkmViG+U57RP1
AX1TIFCV/e+Owp43EgtvU+EtFJvnGyZ7jReoeLOTd6TN2AW1xAqOZtEDj7ZsGc6lBezyRvax1kqe
kV8mk4VFOCzG4bLK05KUFxfRDxeByRj5PERPajYZqX5hc7iLDZ1648FAgzhnWFeKan4E6Ztw8B7U
mCn8wVbBAngZq/MvdXth8TH8v1AUtSiqp/RVHbTy2aCI02owhK6Nk/OV8ZKg6Ki/y3eQdSYz7GkP
s3sW2s8DHMjueUY/hbubqrAKHEiuC09kvFs23XR/d7+nyiSJuxQY1ekh8UjzrCPDULcwVhZobm0I
iTqlT8VOjuzULP7Qp8fcPt5aPkqs9uZTnJ0k/ArmAh+gBq1ZG2F9RaJU6Hvt7dywU3V6yU6go6Jl
xl6upFE6eipEU2ljXPuhgkz2ZuP1hKyrtOZtW32WAModerqcsN9K0B/8GrvOaWc/zvaAZhq7Yh2B
UGtG/TZ8R/8x1wDp2cPo7gULJQvuYT69We+sxF4aRAuh9ptxVttIGTnQ7i4cW1C6w1qjOs9FZItX
7Lta1cYNfSlB87+xg0HT0DhAJty+NYtrxTff5Q+EfvKOFUKG8b7wkohmbd6G6BfcbuvxevhL3dbe
232XpLGrNSCWoOZmqZSzP6TcpWOAsmu86A3SZhZdARkfhC07wZvdbyO5BazomOYzz2Q8fHiKd3JD
Ya6QWyuB0VaOVm4kWQIA3KQRlc5xv1eiAL1rCLWf783lArbe4uy8fFWlSZ1CQnqX2apViqqtFyYL
ZcobNDXWLEk45J6ggNfZBQwtNdoxncNjpTQV7b1f9AoRYcCg1rnOPmr/lyhdDWdGnMtqnsP7Z1M5
2d+kvYxMjZW8S+QoxKQCWjzRkLP75S9j9UDz8BNOWMKKFHN5VQJ4+xzUf6vmAU6PjvQvJnJzHaWE
hlE9dAQu6IomC1XhCs+SPV+3VN4uq7qm5J3/axOO8D1b7TEVUYekmZva4q1T7jW7Nbv1qX177sj3
0BHaveslpxDK9M39x6soVWvxaOeaWUCA8LQduPDQLYMxpQ7xwa0aviZw02XNBOXKgboeuEVufwKK
4Ymry4Z4l/IPKDZbleR46ZFDhXziNGVuz9DZZ5LYt+PfI129I/fPqPTdEHOeKqGGNm9lIsRUv/+7
zuLrC2F6cFSAAHLpbDREVAujJHkcecIIElEEH7f+d/SC3ZQFtwmg2JPx8SZ2djQX8CnCgEQEzFr3
PuJ31ndQZXo672axzy90+mjPPCrBkqN8YZIcSXq10nHDt4/pTiM4kzOvoO2KduJlJG9dZsdF5y7H
VqyPhrjpcExAkLuEl2qbAd2K2f0IBL8NQq95uQbnPl4KtZ5tCZDybe1f/xGBfK24afwwMWU6h+rG
M8NnXF53qtg7xkUopgOJx1Brkd+KSmouQx+/oUPXxuk7U4slDSWcNsZG/lLMzyIPydFq35LTGPDB
/cX5pVAFABjiJWOxvb7zCpCkSrtlTWPczkccTW4kHRtEKwUm2Aep3ZwQvt7TtburwnYOwpDo9uhk
hiyTTqrUEuJHrwMhITi5I/nMZ8rXpiUB/GeEJrxMtpMIe4WLRpqnRoBjH0DBJ7OTUeWOM36hKYe1
0NF4ULy1goJ10dIk50bijcugOhL04Eltjo5j93Cz2TJuoJIuLqBtWbFWxyCzBKqlkNsieaPHlSmP
LdlHTcnFbRPNxGJFvmCOZhtxMUiK06mQkOx2kiQs9daMQqZsUVlJHUaTMU1dv9xmD1L7P0UzGSZ3
eL68Rg35E0cBlj4a/GnkR7B5EjOz4Q6HNn7EydyQuZjoJhTK3qYaAHDTxx5mLSAp9hqHbILg6kAb
SLAW1mdK86UxzWq+jyjb/A14N4wjLQKhAjI+xp8QVUtn6mzgo4web2ryN+ETEGyQY+XeD2b5eT4/
8GF0EgmtZmLH0yA7P97yI45PJA+4q42VaX+GYEynex9FQev+kdTY6QkZ9Xwo2xM7Xyz7b/ZgGe5f
MszxvELf3noxOBRrr3SYFt8xxNguV9fPOcnucSDm8WtkNOkdW1dcpN9BVjyUshP8gNebrjTnXZVu
OMxfGDRVOZejGc0SHCs3ETIVU1ou0QsQn6QNugg2cLYfVQaCEfQPuT0n0Q9OTar45w2U8HdgIaGO
jDT5QWTbOA7AIUur3KKh8td+Lot4ChZBVUDZiVEaRME/Z8yFCPWru3q8ebjrWKs3Uv6a4nWEt4jS
J9mLYhxapSqA8NIzQ7E2sDMNliWuq8hRQ1QwUcAvhyfEnW==