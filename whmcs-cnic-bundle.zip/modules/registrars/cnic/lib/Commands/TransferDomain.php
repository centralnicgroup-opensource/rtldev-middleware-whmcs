<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;
use WHMCS\Module\Registrar\CNIC\Features\Contact;
use WHMCS\Module\Registrar\CNIC\Helpers\AdditionalFields;
use WHMCS\Module\Registrar\CNIC\Helpers\ZoneInfo;
use WHMCS\Module\Registrar\CNIC\Models\ZoneModel;

class TransferDomain extends CommandBase
{
    /**
     * @var ZoneModel
     */
    private $zoneInfo;

    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params, $skipcontacts = false)
    {
        parent::__construct($params);

        $this->zoneInfo = ZoneInfo::get($params);

        $this->api->args["DOMAIN"] = $this->domainName;
    }

    /**
     * Request the transfer
     * @return void
     * @throws Exception
     */
    public function request(): void
    {
        $this->api->args["ACTION"] = "REQUEST";
        if ($this->zoneInfo->renews_on_transfer) {
            $this->api->args["PERIOD"] = $this->params["regperiod"];
        }
        if ($this->params["eppcode"]) {
            $this->api->args["AUTH"] = $this->params["eppcode"];
        }
        //        Disabled as for example .it does not like this
        //        if ($this->zoneInfo->needs_trade) {
        //            $this->api->args["ACCEPT-TRADE"] = 1;
        //        }
        if ($this->zoneInfo->supports_transferlock) {
            $this->api->args["TRANSFERLOCK"] = (int) ($this->params["TransferLock"] === "on");
        }

        // enforce the automatic transfer type detectiong and processing
        // types: external, usertransfer
        $this->api->args["FORCEREQUEST"] = 1;

        // Handle nameservers
        foreach ($this->params as $key => $n) {
            if (preg_match("/^ns([0-9]+)$/", $key, $m)) {
                $i = (int)$m[1] - 1;
                $this->api->args["NAMESERVER" . $i] = $n;
            }
        }

        // Handle contacts
        // TODO: take $isAfnicTLD from zoneinfo
        $isAfnic = preg_match("/\.(fr|pm|re|tf|wf|yt)$/i", $this->domainName);
        $isAu = preg_match("/\.au$/i", $this->domainName);
        $isCaUs = preg_match("/\.(ca|us)$/i", $this->domainName);
        if (
            !$skipcontacts && (
            $isAfnic || $isAu || (!$isCaUs && !$this->zoneInfo->needs_trade)
        )) {
            $contactId = Contact::getOrCreateOwnerContact($this->params, $this->params);
            if (!$isAfnic) {
                $this->api->args["OWNERCONTACT0"] = $contactId;
                $this->api->args["BILLINGCONTACT0"] = $contactId;
            }
            $this->api->args["ADMINCONTACT0"] = $contactId;
            $this->api->args["TECHCONTACT0"] = $contactId;
        }

        // .uk transfer requests (they need to be pushed later on)
        // see https://kb.centralnicreseller.com/domains/tlds/co.uk
        // see https://centralnicgroup-public.github.io/rtldev-middleware-documentation/docs/hexonet/faqs/whmcs-ispapi-registrar/#33-uk-registrarips-tag-support-in-whmcs
        if (preg_match("/\.uk$/i", $this->domainName)) {
            $this->api->args["action"] = "request";
        }

        // Handle additional fields
        $fields = new AdditionalFields($this->params);
        foreach ($fields->fields as $key => $val) {
            $this->api->args[$key] = $val;
        }
        // remove additional fields that are not supported for transfers
        if (preg_match("/\.(ca|ro)$/i", $this->domainName)) {
            unset($this->api->args["X-CA-DISCLOSE"]);
        } elseif (preg_match("/\.ngo$/i", $this->domainName)) {
            unset($this->api->args["X-NGO-ACCEPT-REGISTRATION-TAC"]);
        } elseif (preg_match("/\.dev$/i", $this->domainName)) {
            unset($this->api->args["X-ACCEPT-SSL-REQUIREMENT"]);
        } elseif (preg_match("/\.se$/i", $this->domainName)) {
            unset(
                $this->api->args["X-NICSE-IDNUMBER"],
                $this->api->args["X-NICSE-VATID"]
            );
        }

        // Handle premium domain
        if ($this->params['premiumEnabled'] && $this->params['premiumCost']) {
            $this->api->args['X-FEE-AMOUNT'] = $this->params['premiumCost'];
        }
        parent::execute();
    }

    /**
     * Cancel the transfer
     * @return void
     * @throws Exception
     */
    public function cancel()
    {
        $this->api->args["ACTION"] = "CANCEL";
        parent::execute();
    }
}
