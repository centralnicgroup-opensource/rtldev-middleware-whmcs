<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsI1w0o2GD4ZMqrzByg84kht6gVrhIreJO6ueCm9Grcp3/ko0F/scfYQft1YfjWPQUYq6eeA
Q7PmPms7JMyNJL5XtF4Ep04gY+vxAK5jn9xM8+GHILXWfJ0Xm1Dn/vmBfLT46ukIhfeQzNEP6vf3
azFabTtc0nQ/wB8Kapzbjue7uDeeuwoYbJd4dSRV9HtT1lyn/yZd8my16fQYiq/miLEGv01wrpyG
G3JEFV0ZTOl32SH9MWi/klRtnigQ6PmiqAAhHN4kOM5PifqpQfusWHk/dYrc8VyVEoklECNVluy7
CETM/r1skW+RTVSlhT7I6jL0h5eVEflhQ4OLRtYYYpOAmab5XoauJnxy21mCcKTA7ERmyRGN4t5F
T4i23cPLqWVzXgxU3OLrmkVE2LGskL619mFXZCZyOS5K43XaSzOAXylWTODzB9OCnR4l9S+vmCQJ
BfBWAC2af3D7esK1TgbGKMVVbY43+YugA2Qh3sg9S8lx6tzVQll9ucrKcDvSgKZ5IT1/c1bmMGAa
nP6Gjm5iXPsEFgFUWKFH0PZD3QWbQIDFH2k2Jggi2/DF/76keeX6RFHpUsIgG/+fS/kZwh5D5d0s
X2XnPBFIl3U2LqZtFSw6HtNwgldgzBuvkuIkK/CQ3bIAbSb7KaNJzh9NiXY8UDFaghRTP1fJE0XC
a88N2sIkWi60fxGQkMH9Guvjqg/rylUBz2AGmm15qzplvqmXb02tfE2SqDjYHoff0/NPrKu0iSLR
zn09oDb8ZD/YvNpT4TbG03X3wqDUihLKdOirVTCJtahSgkAqKGtKBHHuwYeMfcqSA22RWIkg/ba8
bBqrO7HiBzpbrb7LYdHE9jpY+cY430IflhftjvwOSmq+avEigQHdxkvWZ/mhA+7tR3erVxH7sbUl
ruF1pfThC+nKMJ6nluK3uK53oAdyJ/BgJeJJTzrQygcCifV6yOgd/7XoxvL4CXDl7PGvUu+GxrhK
Hz2AzYGJCN8N8DD5uVOwCFbMcvoBIe+vODMAXRZmXXUxv5gWCP4Za+vi+c6PWBlPYIEFfWpQ/6NK
SdqMCi6oerjP4TZlg6FuHRRVV+o65o+A6Enj0U03WlgCiEKcKHBXkf3+oFtZl0Km6xrXjB2OCB2A
H3Z/33tAXGLHruOLFGoCDFzI6ovTfC+ZaEME5MqVfbJpJer60Tnkst8gABcWujaLPyZ3O6mbNHn0
abBuC4/JhitfW4ozfrv4roZDp2z58PctelI5/rCLPkpPE54vAxsEakC+hJ2tSWM87hf2WAmtAno5
axWiWFLz1c4hFpfPjlaRxcr9DP5xT7NL+idY8UfIHUCNdtEZfB8sv8v2A/Tn0avhsLkX8wqlY3OA
xn51HNgKmOAj1gm9JHyZrf4eNbVrQU3bxO0WnsI24mC1ouEMNMWKP/+1J5CIBlyp40uox+QkM8iJ
blcLJX0iZH+ZqR3bp0PDUCig8AQptzfDnVgsxfgOKQgQaGaqbY8x17tQFWfHaeQYr6XsRzKfIGyV
2/W9IMsB9Ufufn8aETsFQm2pJ16Ml/F3QnpD79qkN6XSWTyn9RIyen7ZJNNcSQFIyLam0vG1h3l6
gTWYvicoGtM9k9vJrxcujMmHVmuTp7YAv65QcrUYSBoLZ7BnJuTZ3GLnLRiT5jKiPgOA3Vd973aU
muM91Kj3qvUqdA2yvUit5hVIX08kp3V/yge9cn48Gy3Us5d4+uK+8OS8FeWs8fyGDKGgpqOZSfkr
7+tsj1uFTpsm3LjZ4OztsMNvi+D61dnNiPXYuSmGUaVrk7yGSx7oNIRFtkf6ppT53za3dU1oVhlv
txSkGVOKRWpvmQXsvof78aSubv9bRllslZF6t40z5n7y7sW2ziNHN/heiEQ5gUI3X8ZVM+erumFf
pxwOB7QCgHwGP+hy1yFBFgPUncf/79CgDNVM/9V3kiTQun8iPb1efuQb67EPkC/8APJRe+YLvxm+
Y8i9wjDRZgnrl7ffvNhA5Z0zxIDBPZk+wKuHSqcDg7EoYkx4qfapPis+v5p5iUW2v7Vt5BFhh+0Z
mXZ01QtOeuK7/Tym9PKTJtj0oP4mGeDqMIhDzTMLnj3veY/ElDlUED6/hn/DpEAE8wwpkz8+urj9
E5wEHfoSq5lP2Ups3iNDYgBddui+QqKJLoN00OXh486B9BPE2YFI2lBFxAH6Mf6K5Ref9N5LtTyR
1O++L9SAas150yPkpiyNySA8BDxdT8CP95VtH4R6IgFx3DPiiCi0NChK1KOE3NI5gqcX49iAuysW
ic/DfPHN54k1j1RJOcEF5FWvD52hJWkghoVAHAtlMQIwhv66NeimvSHMaapirpZRNhxTKObdP8qe
p5hKvy+lT0W4zJH6O4VzFtOUG+vjDhQyRfL0dgUfcFsGA6xPjz3NKIH5BAtHJPegEqDGka3CqnWl
nsGdS/H5XwumGuRTeDy3T8PFp9T9HyxTmTgUcUYhG5Y5e/nrklOLGz5RvGG1E9nAh2u1A+qCUQv1
0vhAE/hqBJO2n1LiLrtBxvDIuOkw4x7pNTmOlkpvPaUOiYj5RjCszm7jBEgnMwQ57N5RmeUNqPak
z2R7CnlGGB0kK93Xfu2LWCbNOF6CkK4R7EiFNHFANp3NeZ2WSBOnben0ybwjqrfHR5SLMtkqtFST
jBV2v45APy2iqOSCxtWnBUWKrq1jsRdpGlBezUvxkWoep/HULv570BOISX+oW7v9HUY0dXHc4IgP
fsqPQaZsnMJgN6++m+mLVBw0BZBy2xCGI/x4hhyKecut