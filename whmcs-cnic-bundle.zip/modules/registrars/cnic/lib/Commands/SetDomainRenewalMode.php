<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwbH1qZPyVjlf9sIQsGZDk9I9v+01smmEQguU2QxG83RtzDoulrVeDfCRiwVWU15sPGiIq1C
mh2AC1LdKrEBFY3QhklF9XlslJ8Mfbs+N1AMuqZAhlhQ9T7uAE/XzyXUxol/CUvfCucEluP3djQV
/JdRvZPsUfAuhKlQ84HVZgByA1VwNLYMqWVydS/g/5xo/TGIstNNDX4KoZ1vTphN27vxwxGj25fM
bG6CEuj8K7M+7541VKAMfH8VFpVAoq1O5ZQK38PGOQjJKu8SAFAUjXXANVve1J+2qsjonJB9jnXd
CsXuLpbp+E0FqjdpbzfbuXqqGKBQ86d6RoIYANrRVBajrS34FIjQWvBOHD18t8nlExFmnvGjRoFF
h8NmWZBer2iw0T7WHNCFyPnodG6zVsUWW7Nn7nKjzsLY4vXJOAVKRaKPTB1P9ydqWdau0MeMjdr6
E50C/8qEo6tOTx88TVW3pRRyr/fLow54O5huXQmGRhD2p937i2i5ohDnBtphmVxUxFexn/xp6dGn
oqiT/TNlqoXvgHjgOy22+FPSwen7WcvHc5YNLlaSudDC/Yz1Y8NM5MQsAaESocyHsCW8l5w8O4EB
B7yjWwPCxvbNnk8fRTSIKcdUWuU7tnNr+4cCzoMSSP20Fa//RWP+DqJDwv/EM5fBYlaW9SuqkmTB
MDI8h3Pne0b9Nh+Cn98XT81uKgTEvo/F/tIuEfdHVNqQlE73ft4SsVFN5A7ffybY6lUQlgq/E9F8
/9RQ3Y6lNoT45Gk5kvH64X9mP2oJcj5pCykYaLVpqeAtRLFzfPFUKpqQvG3v38PoW0urYyQWcKDZ
1zqYu0zSoSBbDyuW9TJQU7KcorBAZywSgxy5aMNqiA85PvPRIhQ/MeUqK6K3mlhdPMCSYUhyEdaK
eYyhVyg9jXNOJv38RTiVXz9BQtt6/Q7yxnmOF/MclpSnwA2IkGK+q7NPbsv4pZ8/3dtSRvc+vNIc
5GAUY8lN2Sde3S1Fje4sx14B8bL55PCwG5GOFwKJ0i21lWpXb2O+duIpZW1v6TvuUqMGgRc9Q1mx
9EI0sJd/lbMMpGcOgSHbmE8qFUm4MWd6rsHxBw94tcB+iVFKwWvouiSk7VLJMMRdcLCFI13i8Rvq
N1owsRo8uErvg/PnVMcNnCxsKs/vzFEcjXeAdtSC/9CTCweNfblXj9EWbo2lCBgbA+UDPwnlOaW1
wfMEXjgv7u/2vqqsOUvnLW8h2VT60Ytpdhp06rdLkRHdU4NWBkE9yoer4kFinVmWjFLWSEqlQIhT
yf8HbaHWtIei2mSFTaoXqODE+LwwHuqdEQvQrwR/C73oL+GKIBHCwDgNcdghS1GClYgwCkehTBqF
YlfUZ2mqxk05rXvieAB0DG4NkddbusoaPWb7CKejFut1sgT8uNBG9heWG1fU+vDaue+HuT11UpJQ
cvVHMiUVuuok12OYfZG8HtnjSQakoBNJTNecdKVgrEuLvvXmOHxoYPpWSWHkIRSTxYwyTWeQ8Pmc
41WFObPaDu7IxGWEJLAfxpR22gi6MdonFfp60CGpZB5qTCB3A2oQuHOcG8Fv7G5mq5+61hWAqil/
/3aM1oG0lvZ600wJLNl/Xx7OjWHfUgupMB4bIj5xVbGFSolbn/xoFclwRAECWKmMpJZLBMjkBrGL
msHNaMk2xjXiE8YvwmYJqN/yAjjcv8obxPFTQCNCrK8FSxxkDq/V4u+u/kCs4rT8sTOkE5+axt2x
J18NgknTbCkstX+BfeG+ccgDLUp4TH5fvrkAku50b5uU29EjEHDi1sWk/lP9adjVU0LpOJG3Kp55
FiQyGqolA7QYKcCatLMz+uK/mSeVqD+48bemHFiL+tCMSN/OKXcZd9hdWEqTqPy/Y1L4Qm8gY6XC
kUnfHPY2QS5m2tFyMxae5DB62Q0XBazCYosuAbpqz0PUKc4vzb3/w9X2slqGPn2c0uxXJbMZfZ1C
PsmtLiaMIHaok1JCTYObfta8tFIeJs2+8ar+3H+2RclFJOEMXwj8M01CU6lm1LRUXHBjSCotomVG
m3sEownXtLnvrveeonqoUnQB60X8XxOAFrtfmFoYRvrO1swIZBoRewGs6P+JNueeBjmNb0Yn8AQ4
5w3by2H+ITw11F7J7tmocrX2ouNqUv9HUNYKnLdi9edfC6BT+bWHWcrY+/aLW79Lxni/BEzbmfTp
6apNQDrFnCYBwIJm9belqg6zam50oxvQRlhbMeMIKDBQaELYeZTSmCFuLB/fa4+Zp5iu4L0xXjEm
muaDL+0a9Hmkui8VWl2oe4cwO9ruo+x5HQLJ42h4k5kp2zpDzB5kux24OR8rJQdCITXxSh24G9i7
KnNxo6BCawEkTp+9BOKgdsC3Kv8Kl4HHdZk8bpK9j+aKzeIkXRnm6Rj/md8cnjb9cqv2V5REEjam
qCvsA2pLdue8R7NWE+cOl4yEODOB/aFod1FRhYY4Z1Fr0n5PbZfyUfB+BKX/wUoEAmfupIsaaTdh
vq6yu7cbK8aJMRUbXceRGQ4G3OgrhAZE48jZtSRgOdTpGoK4gxLYUJNoXyrBd1sln7FYGAXAxKSa
MMRUvMWsj4BehY2XaJaw5zFH17Conlniu15aqaJifb4PD7+Y9cFJca9FI5BbIaTMo2fhFRUg7Yxs
t9nfNFNNVxFGaZ4KTmympdmZxp7IBIkTLgxDOCkhB0VZ1F72/lMYkMfe/9WjfpIiJmQ0vfg5nNOk
zoSBzmbxKxWUnohK2HQwqOuQsW==