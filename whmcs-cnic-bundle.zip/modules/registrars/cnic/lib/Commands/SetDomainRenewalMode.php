<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu2mZQV+5dQ8XtmOX6djldvJChSRJpTBQQcun57BAXcW7+OWr29C21rseSBN3QGJh1W7q3K5
q9FZyxMIdlV8MIGfQAioKszUyTS/T+fABCSS1DE0iTKsz06vFP7DTQLg3mOsl06Sag6LIFePDmHM
ceU0dG6SJ4WfR1J4NKgsJQDhvb1CtXHDuZV13gkbEPQ17byLJfQ5XoklMQ9+yuOTPUPlW2V34pIf
5E6y99LceBSlhhk5gs0x3C0lKnb12pTwhPZW1RvSKut9IebCxzBCMPaEOMTWA1Q12F0vSYDg6Xau
xsOPGZr/meIKCn8VR0eGk+ArmE+ttvfSxZ+h7fTtsHU8AbPbuzv/NYUv2aAPOn3VaQpV3/ZeRO3k
LPlMjIuZrKQTgJ19bvbIJMe+xW0UynsX3XBANwY8PGLt4z5h/x7oLHbzZP08tRXmZZZU/48oN69d
YPitnAe5WnjFAUpa7MALIXGakwm74LdU33ZPeSdxadAowEUDFwLLrP9wt/OXNAngwnM83nXsPkXU
0GfErXWfqXicZPG0KLZ9G72jzzcXL/UUb9iL15QBhI2fncZSr8ppyrSZb7uDbYvPWh5JwONLKa7k
SMXwprxwn+iDh87E5//feohWaEV5QbSCY7xJxhQACUij1XWer2pJGBFYj1CfvVQcPzyHW+2fnN7M
7gEoBsJ4X14nGtDi5wsmOK74vzEOpkXO0zEohUtwLbXvnBg5gqQ9+DAbLdcM7CKZPiQTQBjz9Y+c
l+7lHUqswyqcaowRwv8PBJAiXkX8bMiwTmZ0l7BGIqrdY9rAtBMZbvDqkgPYKzE1T6gsie+l2LxJ
ljNZRYZq9LaD8vPvXy1JRYk4pa6ldP4bsq2/Ij4amzWPpODK+klpRqOo1vTIyKeQE5YfbGhthW7Y
r/ztyVyGMcPdfcPO2c5xKOdA8ao2SOnYTHrbxigh7GR2t+WfdFvpzRwa9nV5ex1WqE0n2pJKVvMX
IGq7dFnhj9vqk32g6Dy3LVygnr4fPXHgQNOYX9qJnOyXWWY7jDzUemXcG8lEhl8aK0Hl6r3oG01z
DwYvwxwBqIq9bcEgIBbjdwom7rSf9XeMmkQix1/ef+IaW71nfyecLMT7KHzcsVl6GQoFinEZLBOk
emsM2SqFc2b1NfKayvl+Dq3vcLFBdPH91pD+GAnz3xr/zz2Y8G0mwAfWoPKVcvd8p3kiQ0UPh6fG
JgRYKCNxRd62II/hWdAPQH8rg8BTeIgpmaHYyC+s7ctbrFu/uGHRUas77iiPxSS2P4ghbn2PQyVP
mBBvPgTkVGJfDw3dvvA0Heu5Ym/c9t6jFWhJo1iGSLZP+C+4/abloaAR9AKIE2KCH/HUm2OpeMW2
rurRZYr1Yb/DXj7xi9zFqZPu36XINteY5SdU8nToHOwsgwXyag+HGX0fUtvTaerfnWpfy4l9QKT2
rl+B4JD9AM9UvKZ1ZfafBehmNX0YPuFpl6yMywrCifG09TaThiy0iBwHBZ+wJEHqL3FtQGHoxhpA
9QoXnMUVJl1W19ND+uYf+wFCiIjB0Ky4VBBx//YOdUnB1p9/nFcsZc8hYz1ftCeEaAt3OZ6oiDE1
KA87qwojOOHv/U3Al51orfNnzeDsFIPOYw5CdfBqxtK1TjL+UjAa48cjUVs0M/FtuLm/YsF4t73o
UnZjWW60J7t2V5ZSyZFvOyWqoKmhZPqhPYYqsA+VG330d4FL8JDxdOzI0l/QLTamsUxJ4kkMrFsd
5tiFO9SjjOnwTWaf2HcTYHsYy1kM3m4acy+VWWTjnKvz22/xq+hQL+FEWMVUHHReE1QnN3u8s+y/
mndvWSzoPX6wygeqnrZ1blQK+nN5OWr08/i8m1mXznOxkd4PtqYeg4Tk7VBRYeQplJkm8W4qpoIm
PFBYhf9vWalUzYUEynqszMFy/TkzkBNePJeBd19fi12iYPXJH7hZ68a2um+LmxklEABbn98F03s2
feqTpG+JsuVeh93uE1bJh/uEFeRMvnNDEEnMwTd2Npe7ZTbZ8O8RG7fiVtmXP6Dpp9xMGX5y8OGU
fyGCV3CG6hCcH36rmpXIbvhAKtMqCIlqPI9sO1SMjITuT0E0SuyZ0lkPnloPqAk/KBj63A5t1koS
NpiZzho1BOPLSQPZdQ4Kb8vqH8Tbg18tk91j7hIFtJtDp6wh7ZwRqWEdOqoWiGLi4lsCYCD6p/ZK
bsI5bfcFj2WCWRXd3/srYqvKHnfieKrJ7vnzqunRMWhQmH5c5eOMn13+2dMpGnAxN8Fz/SmhsCcy
uDcnpai471yDRxEFLYPwAittoQJlljbUgq/FbwQYS3fK5e1+YL55rxb4GIZAxbvAqmXlpQkPY/Sh
x953JyQ+f1gl0pv2zHzf5Jk0QvBXs3ELz3MpYkpX566WbMrXOfCQ/p3nfOR8Iz8/ODtq9hqkYsMD
nBQnR/DJpGBuab9j7SUBs5yrTMMKIV2IYqd7P2vRZ2iTqAv2Ylh7S5vl1skvGjRONhbo1xlILrmM
HqLhESaWg9/P696qIgfOrg8WRsQmbhGLbqhJnTHiaKY3Ydv8rjglbL+SSVctElF2vD7kw2NlKHys
6dPSkanhK/GzkY/djPrePRu716luUHHOK4j5ZSadbYPWT5fGaOV3GwtzxbENmbA+3LhkP25KPE//
xnSb0SU6oHCETX65bdSfrqx0pviU2iJQMz0IqpfwRZqWzcXwtOEEb0LqFkb5Acnlm1seNiOPKdCT
UPMjQ0gpzZyljI48Rb4XkDyorZ2pr9Pue0==