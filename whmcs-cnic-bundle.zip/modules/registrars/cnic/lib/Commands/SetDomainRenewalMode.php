<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy0IObSri5QPmDxtTBERchTqpVg7JsOi6SjeXpGnbT/+5VKfSC1qO+5Uf+R07zx9PV8qH9XV
OP4tv5NKBoiNntylIcNvFUxVTGV92AAeglTXn4U1W2CcnBHLBevEssuIENXVHuZ5JGIao60IXrC2
zKazodOQ+Mno3wU8kuEUiYkLUqMYJpBCRJPdHMERR2FVDiPmNVh6rtFwnFtAJdqqyvKP5GRlhzUf
4fjG9JXtIeGMAaHYPyjjyPUsOdp/ookr3ILJvt+mtKvibSCqdBikYzISosc3QH7uQP5Fn3pvpA+B
eO2d5V+xX6rgO/MRHFQx61CWeoSRMGXNoZ8/fuTJXBo6CI9MSMQY78uidSiow91lGxoQPLrtZh/6
6MgTKblj/BVGr9gSnPcrTuB32nI0m0z5ZgxXGdEWI+DHRNBaqs5RN2YsDysAWS8iTH90p3sLJqki
EZsVG5rixbX2y0HUiflNPeZM7bvIi6OMua0SyAqzr2ZOeI4ZoIQdraqOCw9eBCohrihVBhXpdOlE
t/+0xRAB9zAQeGREimiSp0v6G3ws0cku4jtEZLhjQz2TACUaEoN6mac6hSvmJ9/RXd/rtVLWKlBM
zgJrTDuEi8kzB6NjIpI7bc4VaLaDPJjoPbxIGWK+mX9fj9rhn2k5gilAMBV8/D95mca9htTj2rO+
Bqi1PRZA+ENsPkEDbXyd8smlhFMx4FLsCp9l3eihrTC+RkzLopfdq2pWk45v/NSwV8CF28/3lKLd
IlE+Au4Be5v3uGdwCbj+RSn8xwitWUgLEjST9qZQM9DyJXJ3Hs1dHhAaNmWxnzOkOR36rz1e8K7X
zj57kUmdNd3oKXPWoTK21IMUSvLLPHdEiQPmNzMxklhbxgAtClzRWjDQcud0CqhbKI6USm++pVUC
8+E7PDBPVa7PIBDxtVE+OHSCFfXUsJcNPOwr/LBDSyP4q2Jmc1RP+09oBTkxBfzo85qkt+rY6l8T
mtnsTXaBYW0AHbqVWLZpiot6ue378gqU08bHbaQNeQcldS/d61vB5hGchaLpdLxsy/nUSDx6NloE
lM6y18L4bMI4WsqIsD2DzLwA+5iIcmFSW+xuGRlP4JylH8yu4L8CdLPsobRXbgPm/9dqfsuIYg/h
sT9paxt1RUfV6fyQUMWXqK+D0JkYdqwdnwv9oVlMIuCUnS7JgLqTK3ItRTkkiW5C3OzvW/ZUst5T
CGF5T8g1vshQcm02HOoU8e+m8brTle8X/O9A6IGE210vpB/5V4oUf+sq3RCFrDVXaqXjcO+yAXPH
YIi3kniIg2QPsaaXcswrOEILJsS4AujgAZeeaBGe0zF80rDU6uyDf6rwfIxqVtVp/BNdwlviZ4Ty
rEs6FbO73HYt90PwKsPkAQAomw28TiiM2zvLX4dr5pinbweBE//Vtw1yHG5mPFpxBFKZmWD3CmC7
YiQJDwNh0H7nonib2lpaNgUwfgsOVti6QHcyNiJC0i3QbsaHmJV2390zCnvHe4ragaAAeP/n2OUF
cunOc5X5qPsMxgIWKfmk0+P/KmGC+vUHTnJjvyo4+oZ9deIfYDM+idEyqMRXsk950hjkUb8/nbJH
hI8tG0akMMKrCbIfTL49pZ/FMzi8GFUKX52G098wN96+W+ievcjQGn5dnkpwAPl2nuIkL/WVkNh4
Wf0kJ5BDKnS6nANFRzvh1ZwnuIuhExdJvcsqnJ6/XQbJmQ141MCbkZqcWdvwfTfXaIp+/GPAQlfY
K/GsozTrZwKnxzw5IE89iRbK9h8q/UPJFm7hdu5jLoNnQ2v3GMM+ckrFkLTWqOkIvZR9XDWgrJv/
BrFPKb/vFkaJzm9EiKj84Kd3hOY16djYksnOmiMHpQCP7hnanEI17OlDs0J+VUeW7AJ0OYHJ9P1w
NvqUBet4BMhK+Tk/aXl8Pgq93Y7RQsmH8IpxBzmvR1ebKysVzrsKBjEaXDEWer0Z84iQPUX64KWu
rqUXJArEQHm2RovM8hipszaUulrC/7JH6wVmgvHPamjafF8edaj026e09h1r8s/y16f2L1hgG44z
5Lp23ZbdQ2a5ntOjVfKgwmXsK3KZZeqD5Ipix01LsdqcPrgTN3jbX6ql/gntcSYwNkCKbVVbtOcS
BTpyq931Ajj+hrbvRnkvOOJJMWbfw0qW8s51tmv3wcnaZu6FY9La0g71foFsSWBMeAP5u8Uz1bWg
1sqxC+FYuMNQ72bScGUD5YN+lgMLSdkGGnCrQLSmSMFBx/dua9q4wtQau+snQAPx9lvQmntl5P/1
8yXIsuqkNHeiX9S+sdduEKWZeR0QZKNFTMsu+gk3wS6QxBBVYqdtRztsdFLkcd1N9851KxtvIpFV
D0n0fEFJZnqaU9jOah7/WRn88SwpNu6JMmox6KFMiO8nMNWFCZNgO7P7kMFMx11MxoLJxb3/TYT6
mZhi4KdumOM2TSQ/yBkBEu6mj7gSybPQkoOsSTjturobs2+ifR+GSTBf5pOSwItPgS9fpYMJzWg3
ZWXUKmGp1PpWQAh/ENFriDFIlfXJ0RhPEtbvai6ymP9BFVlKikfvzW6PRNWOgh51fDq0WIbPSnZ+
n2W8Ocx53HR1Rucac60qRO1dRySrvqCwAoq0LKFpjIsO6U/ozSkwK0+xyqym64eQV8OZGvl9L4sB
9qCQ+4pBhS3cNRBcuUcGC1cgrXqmcSsAV2oAB2fQDc9mbNkSZuwV98ZThyg9pgbGkvJ6nE0DQdkS
BO7k5ILlG4RGQKO33D/AJkYIh+iZ/cHb5RpDZZ1j