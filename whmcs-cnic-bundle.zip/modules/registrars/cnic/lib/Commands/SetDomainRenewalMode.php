<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm+VerT3JnYO6bCsT8U5SW/byv6JturOzUC3gUxbuKkpMU5Vu65ZuyRY9cky2XC0kFwdbRlK
QUZDqeny4gzMZ9j7pVaXPrYb0x1wYNIcJ3YBm4Ft+09zmVeFz/cBkTk7x//xGn2zVMrUSwIzQ1Sz
yYZqMIKgKGNYMCpCOnOpcWW6bmUVC1ak/8yRXnvZHxUt6wk6QdJ1NF/8TfoykQmUEADqwf3jESYe
Th+LRwNRfp/ZZjZa2/0WjUW7ZVFJl1uALSM/ebHGz5qzFh8GDNAai1hBy9R3C6/jC7d657iNWg7d
WzrHg5f8jjY47d/+UmBxDuUIKiOTLXIJ8rQ08ArEoFXcJxfKf1ESudtRGQZ5VhLLPX2UD9rLAjYN
3pB8BX2vKMGAo5wTIvKf4zWjXtbAcXGtDmEsWaCw1TzY22J+PWIZWz6O/6TeGw2IPdA0NAzYZmjs
9TVtISiC2UsY/fJg9Fv9Yhs9MvbAGFwNkNr+WgbOw4pietI2oftqQm9m6PXAp/DuImD/XnYKRUwu
YB0ezaOJxjtKZxiZEWNVpacZO6F3+h0jza9Bf+w4MVfY9aqZgsHH8tjK7dU5fj0BusvPOm7eqY50
meezRPrxPgYZIqdt4yLePlx0U6klxzA2VLTZxvU016bgbgBq+GiKI/+ze7O6xs5ZD/Du7DaMm7B1
KtZs+YXYLHm1xd0+POIPOQk0f8pvBBa5fMZMeGlYHUUO9Ja+QSvzkqT2orJEayM4YOrOx1OCAx0V
h38DWWpyYmucWsOWQP0jpR75uOrvJM0Klpf4mLBi84XlTU20SmAc6RHdzxUuWx4KMMp5WslYQTWe
+t0cC9WoLFyiCg48+pCxOyX9MSWFxjxqShAbTUsyvHV+E/+YFuJNVD4+aOwxKp4Hn6lElb+6cipy
DQvZiBAoA50gMyu8Fv5uDCFzC1lcKhicBau3hUd7HEQeWWWEr4161PoazvUpX9y043HX8vzZGChJ
ezanuNrNzzH5N883P+MSr/o+by2ja1naueUP9m5MQ9kgvmgwW9mw5mOGDn3+6OmoFQBgmlO8WAZP
Pa1LBmFapwSMlc2B9NNW04SZFuaYDmc0mc7HTYjdVwQVTXnxAyYrFWckLF1Ol2Y169reAgLka8UP
6vk3NaENiqXYbV5F1KgHAjtTqpxXkZsVR17Vf7PIN9rnuDJdaMSGcN2TzrlfRx/GhxhGK2BWlwHR
JjSmGSlCKFlnOKxSgdd3QZa4AN4OPkLLHf7wQN7CYTYJct73jp/6MvDur8bs4ZFVLNh2PJ48HbD2
/LVQH7sbEgp/wR+T3mcCH1qitdccO0oX4ZFdRyki5FoioeLVN9R2ZtNWtL3/fKCGZO/iywgI8AKb
r38Yee3lciw9opH+0y7UYn1Sfx4BAaJvGW9xUAsQR+mnxpYaQncHHESaRTHwac8Aokqxa23NkgqV
vz5a8JeYH4iMkPsktAasMxvT4SVFGPd9513Y/AEOupdtl2PKMgSmE7hygC5GN23lgUx4Ef7RMI0N
2oEO4K3XvBmRRS43mjlLS7Gb04uQrUcA4dyqdIOHDi9bTeHnuF+vwx6LnMVfUQJNUpFoYL1N+hvu
NHy7yB1GcBUsTLg292sUgfGbDdS33hBHa/f5vmwUh84sRLKkEe2VQBo5+N0KoWZI9mEUuc/4snRh
gqBrwr5UGPCcfxy1NIUl0FzB7XdlVgpyhV5aYu2yuKG0j+M6CsNW3oyICNOYuqe0f4d54K/NBeLm
B5Xjys615Yg3O7Gg6ahlRBM1evHMNAtH38sN7Fo84p2E4FKvxTpoGsgoppEbtCDrSZe5BaPJvrev
22Xs84MjBqtjb3anoefmO/ot8kvY/KeuvaPAAY79yVe5k4BsNIVLa/AkIvghlQWBn8PWuH+hsn8F
wc1Co68V9klaLM8GrYa5ApUVM0I/+Y7ltomFifRjHNNHgTNDz6Z1M3D9WZ+chPgT0lg8qLMfDs+A
SwxYjsLCy573mSYEkpV6BtcvLZFj82gDOUKXifskG+DrPkeSK2COgOZ2DwD0/x8UHGNedplPNa+R
0VL1OQElvTHPOcQ/sNXesXLxeg+FPNf4ddkMQBjxZ3senbFGQQqiRcfzpNOoZTAfUFFQUkRsGLp9
IT2fSaIz985QA7MSBKEzwanGr26npe6GXTfz8IPrMZkLn735PrLaBj9Uy0x2m3RlvN0v0CsZjq28
GV4VRR9d17l5rDWJswSMjGP3hG0OMFQ4HAnoI95/7bkm5E/UVmzFIqe8tJcWMi7axajUiJ14bhoN
HmSasCLnds7INoOsDLiNzz9Ud6aqEolt1ZY+SwejCSEUDq6vVPCdT3D6cjEMIDcMXk9APPSWqRNS
u+hrjc7g7ZbpEGpiDyH0NZ7/x0eBHVKiES7P9IJZvgA2lvwPTexZMUE5ibbYwh4PW1V6t1/kE+K+
ZNlB194PLRt+sSo+D7jo5lMO8q8pMqlV0pCQSJW9ax1aRwV4g9H+zZ8L1QH6s81pliZQX/4L/7rO
+1xnJNv7bBE2ogB/ctl2uSIJEr/pnEcbMhy74CO/r9y/sGDe169CCNJiSRbJE9RzA9Pro9ok9YHG
3dh9U/uTLAeksnCh5IOeOFxTYT/QYR2Pr8AzTT1VicYZXt8FLJ9xaQK3//9EeFYIpT6b3wLN4RwS
6FKEiI5vYbPLxVHxy36EDkjHklCgIMdcxbX3fEnVtV99coKXC/uWqKo9emqzIX0cxfpaz4RTznSM
ppwQFYNohzc9NUC=