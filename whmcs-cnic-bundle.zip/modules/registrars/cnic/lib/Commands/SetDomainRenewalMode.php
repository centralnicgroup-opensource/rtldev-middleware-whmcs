<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo1HuenMyTQZBvrth/THdLGf1BKg/xM7Ff6uXy030FqN0BEXd42EI5XQkpPcnhnfCsrmA1il
yEyMO1ckNx07FZlq7d40M8fZqkw3R+gGtGWLbhXOX7kaoOHdWhPPl68MNPA3woW875aQVPPT2uEy
rGhhg+9Qv5Hj33qlFTJGSape44Q06nTE9ReEo05iHuFS+QIR+Cqq3LeZx2aLP0cFZcUALliLYIHN
e1KEhBVLnbV4NJeDMgUKGz3nAPe5ta4pOAqpu4sTqNpq5Humc56s5GZ/uczWwHLgsuqQe2Hab6TH
AyWz/qolq+KwM1zQdRQU38nc+ENOTfONhnZRUqGQJKHHALLiEQmIs+vDDPutm6+10K49g7qvwluo
Wxbq1HipeiroYTOLjqTHRpvPAg1bcnadnhpjJ50RPTooj56DdM7uejlQhuVG+mRk+SPrgnQkoD5G
NwkEuNdOCMMjIxFgU/qR+NbsFV3xSXteGKEiVrZLfnyDCe9UEOrwk6Gdx/5Lplsu9/XFVT2I3Mcy
zM9DiY4+i5PCwYP1gj1rIWNdMPEQPxvzWYwdWxMNlv9DPMBg6SU/BRVfXP6PI0M2bd6yD/MiBJzh
ArCOneR1ROnqLNRInWKeWAt4JAiLVpNjXYxFfdekUd//BBn7h5h7CmcRIiBi+k8tQIvAgoEOeXm0
YDHFLoFr9IEWj4/YgSsSEzela8Rn1mjU13srqoG20kicubM5eP2Ouowv05kIKAwcSel+EYy3G2CD
fOGlOtJ9aSIu3ZKQ8A65lWsnXvBBjK1xxcnetyKaPww7+9SEmVpws55wAWeOMPBAfaZx6ZfKa1fr
nxOfFxlgLqQgKHL0IhiPFspI3+NIe6ZqHow7PFFzzleYepiUPKVXHLRf+mm/SAkSlk9ZnK3Hx/Yu
+/a/8FVj+Ajpi5CJKEbmqFiQEaQricjOmRbqhAvshKutUEza228tDyFqcO2CWxo6B2IiEtG0S+r1
v4UZUiKodAfppiSdhxhKJ1rRJ+3LPkGXRm04EPuKvAYDFjj2XUymo3H9r0us8kiZKfRp10e0qJVd
L/IyZtIvPYRA4CGcvp7Ah7SaV6qgP/jjEdoIZE91RHpkJ/OqB6CuNOhHFfJY+pk4WYNKRq9/DGaI
93Ab+ifbKT4VgsXNY6OHa8Drh15eInR1kenJb9Hgytnqjzs62edtSoPy/aOtS20tz1EWRBhdZxSu
FSQT2h4InhqPfdMQ9BfcJnSfR/U3hWNqpEQkWPi5MfgzNpchV/xgQ+d3Zi0ZA7M1A6X+nrmVcZCV
gYAuEr1exeUcm7L9SLhOW3TxduwMCSxAcyqfEkkVnZV32/0SEZT6TaYkRiKbNngGqys33vF9/JXS
r04rlNvf4Pdlb5fe8Rc/+FrkNK3AQCGZUScPgOD2ymSwFH4l/n+SdMF4d3vjPGhdaYmcBYhOsknc
+sOJ4LXDJ52pwquTgCZQxzOpgJb1PeA7o8DY6ALJv5inoqowUoHDNEmlYL/QXMsBhWEGBNjTlwqS
QJxgAqIL4Yr9bQ/PKt2wFJ9qUEvN6fNVSRoBW2Rm23BGSB6VJkhZdZsqOhgG+G7uHLYLkjWx5W26
WhAZY1TG8B6sK9FpavbY7Ti+5bZp3BvOJ3ZEj7xm90PPvGWpwxcIOoXIE92DFcjcAUQRU5bPuXtR
1oZ1nCsTCWbXMJN/XDA2+dv4dzulsXN2j0e+9P4KlEGpNVjgBFb4/jlVuH6Q8GuOWI3psEIwn2MJ
j9ABz32Y2KgltA6zLJt40fq0A7lAVFrzqjspnTKko9DpgLWtOVa9nrjNFk4btuony7bPy3CXiwWJ
ZieW1qMhODEz/i6Ckaux6n2824BfOnioK7b1qp4s+WgpvaV8oqr/tox5C5Nq0dMD27OQ1jBTuoEs
ry6f5Qjcu/PG0ovGzLaXBnxEZGmWHtYSw3Tm1+JTTP/sTEL+00ZKgBhZd4fNERpzWAex0sg+XNBQ
mm4qe0OLt8Cl5Cs8N7R/uk3gJGZHKk9/TTY5UwdrbTx3vH/+Cugm4VzE+hFqsKmE6ktbLT+9DUcu
5qQE71IV6oFukoJ39/PF0oPhbxMNuu9760OMEubTjC1ztgGrR+lYzplCr2j4Fk9oQhkG30ydVcC4
9CKPeQnj3DRXs1ihHQ4T2CcBHLAM3SdAKW+clfr0p/vq8IL31EOQpUJF4OZd2WHzkRxEuK5vjoAU
w2JfwBuUr/KWW/zxgP5WpQ5L2KVqXaaba5dbrOiqb9+fMxwG2zwgTA8ZoN4l1fIoOlxuN4gMcAXV
hadDnJl6WvKnw6IfW01zhnKNHkqJ+3v0MpxxnA2AlWcX7sf921Ix80M6SotBpWV2lkQ2LnbNTarH
oz8pSDieB63uHa9V5OIzxLOEzalpxOvvbhu3Lue4jXR009+o2u65g1yu+Y705V+qBE+s5+0uUodn
sl02bjmzyO+d8Kc9W5aFEyK7Z10MZHK1O/B1WB3PUV2Tkiro+O4GF+hlNaFOvlxNtiXh1Pj0skCD
21VrC3QwNcp7YFIJSQBymCnCvrqECdXwW2Nt56YyfCV09KY3+9DmRLNc1nPHZiCn81z7xJUB5qfL
R+CWbrBxoSXRZewL1iHTsR4Q/fnEkegO3mbLtzmhpYLTYoLkqPcmbFXU9uQqJq5AFPpXgkJz/p+Z
J+Om/4ROxiuvrqOWbhgI33FJjL25o/XVTFigOeeEAn4px3R0bze6DZr7vl1ixnfBWXGT/aUQVyEF
dydtABE1cFMd2dIaWOddzMYW/Q+Nvrs/D9JZTW==