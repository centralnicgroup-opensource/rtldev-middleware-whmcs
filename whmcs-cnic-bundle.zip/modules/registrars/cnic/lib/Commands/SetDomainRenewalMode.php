<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuJAe4Bvc1brX0OrORXw05hse9r1Hx8U8zD93GsAI3vJJd2inyfJuVmUrZgklsn3oFbvUc0b
NdzhPDUSsF92ROD6YyS8ms7wDs/LDkA6MjbbB+8qMaZmZkVSfWNZ6NjL2cvrTvHkE/RvZLMSUWAI
unqQhHvz+E2/OfnXvzn9Hv9x2KMiQsq5LJBRpmDgEKAcQHkemPEOeeE5VdZys0MbRKCsy9frlE2c
DQyIu5DWIYljDYs+4hB2W/3snv9y6UGw51ptqB7/R3uQsGryYXfCcmOogyq0QFRagWaQjQMMNK4E
4l67SoXlj0VjE1YoMwvpR6udc6hSfz6L4A8HJVso8BxndrHqM4Eg6EBW6AqUanmvrcszFeJiexy5
kdNhlbCjfdFvNthpIq/gnG20D5so6Hfp4FaJaM2uPlseXwfOq0rKr4YRDqHlbvitcLBTfuOr/SPm
0pAxjjG7hoUrO9TiQVgyu3U7/xrUaFFLUB4TP/gsFdhLvZ8MIOHNb34DRYa7l4dhnwK85CUv3xqb
OQP86xZHkpfqEhkti7CSeGQjNWNIc55LO9IZuBzbUe6QPBz80ymojT7sKRkISkdEszmVv87jhY7R
WDYNy48N7Ckq632JJ7iiNFhAuPT+fiEx1vP4BamMieeSI4XdcBi2Vo3hg5SNRTbp7HOkO0oseNha
bZtbDOvj22hhxNPRUJwlvmh4k93qwJTESHQn6sDsWwjPipSGjBy3HdMO6jhqoxj8EICbGBBkYULF
IjK6b8NYPS+phRpcFZb2SjAxClKxNYX1YOmUYyOhvA0Jed+r92mPxA6WffMVE/jIeSxhiun47C9w
rbHuaDxejwWP8G1LdCKHFK7gX/m40IA4iHqvUaZLs5vlso79Muh7qo+vOXElGtYF7NzJDlk2HU8l
KYUKmQE87v3FLoo6hHTGzvv+rNih314Xkt06dVezAjgDdpcAuhRmhY2L7nr5rU6NeAPDmbPZpQ72
pmFqvlfFTBDojUchoMUDPat/4WRr5FCv1IUrxYY32eSLluLt2XWFTSM0i2PD0AhTM/fqZ38roHNW
pA8AV7O+Zx11HduVsdImi52OjHdpA5rqhb5om32AijYaMrqNiO7EsjcxS0/sW0jHk2Lqvm3XPpxR
GyE0kxNvjRQ7jjsrGAPPVrnRrtikoDejh4rO6zousQH62QYY6htaAXem2POM2HkNOjzQr+qcPRfF
+oMDpmBVM8tyZmz58/X9QtJTBzQqbTvtwi5HS8kje/Z/Q98/NdspvKEc4ySr0zuEYUxwjUrTwroQ
jMcXVd6PHS3A66fzJhs0kSJRQI5Z7kK8wNkK77SfLNMGy4w9dksNOmr+AMuDGnDqR6PJzqTXIVvJ
y7kkn1i5u8SDWvTzw+nps/yzkn2T5vBAFQmRZFFqMUHvu3E12wrBHOHZ235D2feF+W4LUf9KOCTi
C/zdUEvXjmGPxPCzhM697+gtluizReAHFWgv5/U03V/2Of6n/epxY4AQWEgGMaJ6husUVRXWZ6/f
s/lCLDg1a780jvT51XBIEMSRSy4Oz2htfdV2oNR2gUU+rKj1hXyp3ndWRwAO2WBR56b0RvoZW2ic
WwfA9MX0D0mUclHBuZ2dTpJJ4FsCCuhG4wVQLBXAqkUVkeLcrPOBOsE3RJgHWZESf37gw3LQf/vr
qTbDo2QR1NqsqsmJEIBFn7QiN95I/q3nGPo+yIdfp4zsO+VW6sgq2WOkzViH1+jxRltWrNsk2m5I
Mcix8EIcX9lFfdA0J5PleEoh10eLrEKjQKJdEq1ZQfbMgLMiSBoJ/2Y6DG0q/pKVsHmt+XhfhJrY
57RLxGHgcpwS5CftuENamLWG46fDHnnhU5p19YtFnnb4LEO55xp7ddHHz+kQ72scEBfGD95/52Hf
sajXgNrEklj5eaJP5gstEbv9BD9D1cgqNpOGbmOx0O3DwDLTC9Eq54BLeTXb/BN6njnVADQ+atmC
Sg9Vs/0zQatgbsJ4+SjhBDFTPm49Kai2jv9Jk4Z9EaY28/dHgArXPiPz43tYu3rdr2VCahDEAEZX
HMTDwwF31RVxEG9fLCVo3IriwT0irsxhBDg5S9k5f77y8A5CcM46+wUXwQQdt3j3fenw7te88VZA
4cF6YrlGgYKE+hxhE7FBy3yiSEveTHK4TsgmUvNj+++wjhngseHXSte+GNzWftluLoGYOag8y7Go
P9xV5Mqsnmf1fJQPLiXDxKMldM5PtFcqGXOETd8UvrZmIYrpMalMULba+dIxBkDBf/AefUbYSop3
OJWmOieWf1GZvhNfe1YDpMW6PhaCQn0XOM7qXyez27Clsj35E9n3dPD9AVZWQXOJwCJOOrvBvfW4
8PBLGZEGChN8hwWwefMoBW0bogqopIJvtRJDFJaV+/5FlHBLfVWa1C/YYuCHjIj3PnG18qo0mKut
c9MTlxplEEi7fo050OmW9G1Li8M8Jy2b2WZr4cwT4Mh5wzYQR9NOY2GmVMkk2azxTL/Q1SaeFR1W
PrVNtQtZKFBrQPyrIf09ttCwIjzD9RjI3uSSAZ1S2S8Avu474oKd/9XDRETgf4egL594IW0uzUmW
+5QsXHrNEX+d00Osy6CMZi1XC5iwNnMdcHsNFeNyOuZkG7UgMwai8wihfXt/y0wu7Fb9MzTUIIup
Y6k+bT8m0MwkNj0zrBkqezNB69M/VLewa21fkdmYJwK81kfKTqetEAugwhuJfA5c7vlDk+VtWnku
meSR5Lna8ZK+7yb3xNnEcFSokvhRvGGx2g95Xt7h