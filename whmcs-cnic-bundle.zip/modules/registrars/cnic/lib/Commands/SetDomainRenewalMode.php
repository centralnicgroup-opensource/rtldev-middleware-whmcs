<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzi7xm4VnzCsvijw8fBwdKKeRYgONmTkE/cUVAqeClq9eFBI8pVB07zbhlIT4BLGJ+qFIEVx
MUmlDMe3lyzM3ir5PAfZ8YBmk1SW0hvOP8A6nSoRWXJTBvLichDTWtwx2hZlKG9Wgrmg/IzZJBnh
8nU11lbO3wnp3Npp0sa+Jx6QGeYQt4IxuNAMofrwWxwv4FlTuQLAWpLcZcwvQU7eW20QXzRjEP+A
86aY8KcdIKT4Pq5Jkwtiy2k06Pm8nj3Sn2RDZiRVXwSEvEPZ8/0h+ouhyRwhPyVgGdpBnL4nl7AF
iWQeEsDDBmfQlUwI9+4RTq4cDAtC1RR5B2ugg9woaUH7TMZS7t6m+tD1niS/yY8+X4OScG7JQdtk
NUVZAuFQ0FcIHIF6c3cssQf5+Y2nJ8uw5UkgxjqQVIcemhfTy9yhyJ8K/t1j9YYR+ogR74sGC8FV
MXS9GpXOAVN8v7ZUSNdMQKvGARWg3C1gdUqsVnZJB30cE8B/oRS7r7UtyCUEXZz4m+KL1YH9DEsf
UAu+7NqEo2ZxknXCwQRSPGsjDi54RGNMqqBoSHDEZaCkBABhlbk7p4cN9WIjyMQJhYtvM0Z+p4xY
ay/Jwl9XZgWAxkWHbo5bGhgD4qpfXOx8jlpy6YqDGcYCakLe7zbrTk3sm+RagfpWJibrSNiY8SQ3
z7+S3Fu2PlB14QU8NmLWMQiJMJ38yX+KD3UutF+mab2cdfqqmBXy8kSLHAWcwNuU3s1nYOCovSFh
vlcDTHN+3qUaLyMZFsN9nWVmzHNRg8oCzKzFcu381nK0L7BuuxUL0+K4GFCtfT2QunsQnU7BXVjL
VkxIn/E+xOfWtIZweDKZgV/tu0b+rAqPWi4G2tqM0Y7oBWHgEu3LY+qxxQOp5EpzCD9QFoN+tit1
zvOtt/qBHcZVMyYu6MNJJCk7+PHXUlSX1UrCP1DDJT+sx0HPWb+2EEtL7FN+rwuNokwGwZY2c7IO
dl60ovOv8iLpJfid3bjt5QYedxIXc/FfdJwdoUxshUMWPvS8JwzeQ8yCoSPkSj0spyZhi0ALnIVZ
ekSj1ljvcg3/0+un+yfHW0/O2yuSTYlaBuaskSTYe9IdATbAK5rh4yurgRTp3ljnUCxCtZ7PXD+6
lXse1HFg5gTel0szfxiVhrNqC+QRxNo7sMkVAGHWWYx0jUEENRq3ISxbOA2BFP3oSjMlx8/MH6L0
pQlDBUd+v/cXOQHs4PQlvmZAJ1KgkLcXTkRpwolXMEN6y2iglajdALb8MEeMOGH7/vzR8F2uN5UK
dfbDbVA9UaU2a6EMj3PFFVhxmGnYRSQmhPWJ2jprEZcIrzYSdk04VLOOMKp5A/gxvS5rktSiKG8L
WHWWzCyffbnfwXdhXq9WPpTk9Jv1/6TNrjQwYZFuRuVcUFQPRC4wnaX4cHnb05ysOeMh6cYnUje0
vGz00Bl2YKKaEH6WEwyS4022fgwsOJbGemjplLIUClirW7ZMaLFdtj/qxmA41XYKKYti8r+TImY2
UQKc5haSnlyjieaE3KVZekAHVkik/61M9mGcOdNpaaLP86vjpcTV2PZXNAB8rmNbpJvjH1KcUPf0
nKX2mAeMAz6mQXFJUAMhhSqDY+vxbuAXXXthSTOPi3sDHyXr+Je4sh2E+CdhYI4TbJPAm9go7xnf
T1jOcaDPWdIuv1BrYyCj129Hmkfq6pwVhvCWpBHSjTaWUtLq3l5W/GpqLOnYR6GYIfGZP7dnXs3m
NWe15iUr+mXh7Jx8wADpozUPA/kyxWZ1A+aqwaIEBySg3YV9xCHJk91Eg7+jN9l0I019U2ofjx6C
7IstEMxYxeUttPnujEg1ssOR/xV7G2Xcuuv7/uzdKjuBztqJJODjT6rPF+Ldnz7fwvkZ5yB+ABn3
LxuAX7X38wramBCWrIaDYf2atJkjrQ/SLi2YXku/Ms+PA8wSDkigvVZ6W+LPHVKHJokjREoEZ4Py
i6pmmgM8AjQYrOdoJhnKn405R1HduFuDzUrJpnbANJ3TnjZYxuWsrBLBRDQ7MqeUH7emtqVMSwOf
x115ebzvyW1Tb2Tc7BLK684NENjkTMNBvDQHCciKf/MgsP/QC4sD83EUSvJbeTjFC8Do8AP3sNBT
ZEP4uxYbLw/LQtuc72tQa2egkN48P1K6ti6Bb0LkI3sx4yzz1/uNDXPLYD7qUftAARanGx+KQWlY
NB2AHrukJ+iMa0P9r+fa80BuNuZs3li5MArZSALZqmXzvAlyyl/hJ4VvnhSa/WuU3pfJKgzvso6Z
idHY/IWUrUhjRRL08lMRd8UR/m7Tn2x8z9iGhRULStPw/1BZf49FiFF7jX3Re3C9OhhRl51kef0M
hLcS092J4NET169eTlImbsbBYvhEZ38FSoTewWDLEwhDLV/E39gYQXViog3B036wWjAmBzXTbzFz
Ps/eHcSiheo9z2soIJKGBg6nT5lgQouhu5TRAGuc1PSv3NbbTDVKPETl9Q/BsCsYcEJqyUOBoUIS
Rr4xqPsav8CXpSY3MxaEJdwpISF79HphwQo/GM7hKNL29g3KESDGqPVdC/cXqsKsCrqT3NaWHZEk
LCojV6pXAVChDgx+qsUo3rSIn3bQuAL+vWLjIk92XvTV8sD4yL5pEynndVMLjAYNLQX2RvIOwg+t
jyZrYaM1mDwyDSru3OoehkPIECSIjx8PuipM8/H8BK7gU1qPk/Fc5s110bxIpYja5doRBo1QEO2A
/iX9049h5s0eY8DXW3YOYNAMxif0pdn4MN996wyNkMoi46C=