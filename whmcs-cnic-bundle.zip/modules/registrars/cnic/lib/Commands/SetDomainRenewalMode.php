<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvcOWI3BJdeNabGK0r5C1gUXy2GXD1tJNiKPbrsCelQsLRI74Z+HNyAnF+AJBY1fCtYqqUHG
sSbdmBwwVkWU7lC/QwdmaKKAyEgCaPCsBs412iG9poi7m7EQQ9Iy/QWZdRfb9y86SwdaFTH2pyJt
w1ffxWgg51IwIbaPXcULS8X4JbOJhPYHJO7g2fuSeWy2FQvsLI9xbdiipFR/V+lTmIrQm+kEYnnP
eCEjZtWOW4PFcBtoPIn6K+A3lFIAJt4HzwLfwDd2LTKCgJq4gYZqF/+XpxxM+6X67dKVaCcRz5sg
4EZmHdyxDLJdGVgoxQg20btxyX9X6UO5kpHSuwSv9FGLrOSj09RU7N8rDiCUufocfUqLE5077zm/
eLUBr+OcFoQVLGt3GhCD2kiLC2o3iCJlXTkmJFl/ZGftOiKpIctyUtVWncBy6ljdb8mLtxb0MRcq
sQrJKTxD9apCX7ZfU5uDvW1A385piUaHYFEOGGjkeK1Ce5sS200WTpev4cdaDKxIeMNd9Ehi/a6o
FTbJ0fE0NzwVvNr4JisJgJU32DvPPKSz4kRZ/P/9GXJ0aSLMBj07OT6ElAiYfwgJc2/4DWkcwaWV
lJS1o/RXmWGWLMJ/VU3G79LASkN/Pm6v7nNmO9RvF/yvz/lyV5k84m6f9eR7XdpgHgdnslm55gjP
IgVo9eoQSOjOEu7QIIKJgxW4Rbprky1VBfTi9Cv9k6sukCdJrWFXhu2EGAEXUQ/x3DDVVvrBdHxN
ZpcYFQwAjqVM+zFfh2qTd9G7eoP4Ltt4kp/OX7UJjFavVBJn5FdlSGAsIsj2NzgjhsKtt6RkHfMq
09t5KBG/nCPFFUz9iDT93qjr1z63sNxvVvrQrYCEkpiti2Pgc52E/WczN/GrrWVgjh03cke+yQX+
TwgEVPM3WKtWEC/WXPkgG/kAjk9tpe4oC9EM91s/1ZavfaJCa490nHpPT3a7S53ZAUUv4E0Cx/nt
/aIV2/ISfP6sCF88bnZ/VSVYs21HSdcg+K2QG6UdtP3vuH1K7mCl7kWv0W8nI5yXXmuV4AMeIjaj
s83cMG0/UvPUQ4br9B2kYmeKcF8E7Q6k+8GmiLAF4UrfN+kpHZhmc5sC2PE4sQHS2l7pRa4Iybip
nQxDkr5sRttTFfAzsYrfOmRzoev+O8FUAp2A+c/mZ3wAGKoUwP+6YkCQv6pCXs3U61w8n4vdx8ck
hObR91UYzFFJ/rGmyXatZXMJ2NvsnkNaUkVQkF8dlogiGtPmBL+PkAd0sMNTKfKckc/AelrUQHG3
GV4NiQ94IZlMT3Te1+2G3+DT9L7lw03r97EIJTLiUccUm4NRNKZVUkLW2NB/lQR1HvZ9M8qwREVH
Rlssub0Pk3YqbxleFkoIl5N/MiYFNgrqTxM83XXptr2syhNoqeBpRwRh7mGwGw8wwLoFj6gPhj+M
Qooe+kmqNZg+gKQuX4ADwJHyCQjrTBWe/5QzR2B+kgmE6a9Ku/JXMxM1bNuM5sDQBqMlNpuzoM91
e9NSCk94a4Iik6qz2aF4qhn8/enldKZHys9XBkII80RmLyXFopGC+DSm6HKD94KnK9nT9jx6PE0G
Gte11SFOZI1vmhQKe9QdDpK8gFbW7d2U9M737BiGKbFAav4j3n3YgRvQ6dqhcwGeXdxO+FXiIcuf
EJdify1zrQlv4kz252rwO/yQrWE2jskjS2F/1wSdwwvHZ6vgfI+S7DbTyY36SNnD2bjyitZkWivz
3LhUcoJuAi49VHCYJgPDLfAm7iJKtum4MlpPkwNK342KtNij9DLFlK0PQl27qe0HarXo16qN0meQ
YMV7dEP/z3aLPQNlLTVhO3siWsg6xCi5/mYTJsY+dfnnxYZRlk8AqCCn1aGZQphGJzL9KGVUgW1F
I/k9yA5qAtH9oAJZJ26WWBKWk45p6mNjIhkT8NdF9eFmBMk123Krn3VGuBfoN1nAShrVIBcwX0CZ
If0wqVHGGEFNxFg+I6/JHibA7r0BPFwzN2Ril3/ojmeX7DDiB0tn9ama010Y+BVkZUDftnOO0dA6
LjKDxphp9V5o3QfevP7wiGlbjKqsl4TIyEGClOpgZqK9Yowhu0m2EtBXL71j9yR0CTck0qH5dgrM
uQx3u3BLKHYsht/V7Lm3RraW3AwN3N2zGDqj2bGCGlaGi76CmXPt2zj9bcugUCE4v5/aebcOboOu
jgFbGcJOdtJHSXRdDnWbeF3hu041lhDpYD6rUmvy8Tv6fj0wApYL3y6YR3wzlTbPrJFDCo/AxL8B
5jRgwwkwTevnRs40gGAR7IAPfLslWQvF1zlBIXN0rtbLEp1OXl+Wo1f3BpTv4AQOanlXtH+8r+YM
y9EEXVBjv1F1WfCd1ix5kUpKPsEVNY4Gwv0tB8MrRzO+JBuBF/nwa7+tN3104S8epmINrVpxIUZh
NwwTMezTaO2cJepOGZlsgxLIU6IpGnPG6OjulP05aQ4V8KUxoaS6Y6+JklUD4OoYbEEisNc+LYwe
dqV6T4j26IL33PNQzkKX5FDG8tHrC1OMHxX3FdercADOc+mpus1tlskidPLeveIVNmjm78BnQ9QS
23Y53kxyKxgXWsCs6pAyET9usnN3s44DI8xgag2FP1FaU2PBne3GP9QWAqFDLbS4LgTlnSncOYxS
x3xfGKO4KBhgY/Bic4eszTWX4TgLBV3keA282AAc/ISBqhTeaUgxqPASJ9A25i2X8PdllcYFSH69
jvOQNXzFunhFDEuBhmvuJh5za0v2