<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+O3o/CHmy/4xCzUq3r8qAf7HVvbkpB2GkSf5bpNEPuxhiFXmysCVrl/AoBckUbhrQSBh3N9
CCtX9FeuYHivkXqVBEQ3Zaj8xmjlFmDzFZSZy7Z2bE12ywsaGfR3CSkDYCJBDPTAp0R+PjRi+2aN
qEjpPNAtuw3OjBYEahuKtNi98O/ZqorSQuW/bxHlCyGA24IsDTVaEQFGZ6quMee0ZHEh2/zIIbVt
7k3jlNdOBIrFZKOQ9IaXj+Zmxi0mq4MFr+a10Eqj6uMVxw+O+s6nlLSJ2XwBRDCqDRYJ0EDmnt98
uOxdR/zgd7PESa9qEej2rg5MSO1n0HLljl8XlZUYrP8ciW7whj109dEwlhN9vDZ792tcS8S5UrDG
EGLiIHGA07PPCYmNOzoHHjHxCKww40BPDBq1LIZbWP0iyt1Ln6LNJkZzufMWComNBT/NNrO88K75
SRT5f9hJj+5i38tamRCeUrefyVAwk6rCp6PFEBKf1GLf29XUDaYlHPM1AyMAdpvFQh+/CfvakEd/
NCv0d3RNMynu3G+dGlKJQxADOuzOd0RMk6gjx89RPI2YSPBlAgwTcclIALUnvAHuwQn91h5lNmxG
jFH3BhTY/EfAiHMwijrP7Ow9FXr3T5+aUfAfMxMIJDKIb8S0otEDcyJ0crl2uCalRwXMA6DbIDQU
2rLgwvVtsgB9aHIwhW8J1vIMYGhbg0KsCfkhgwzZags09Y5i5x2voAF1pfSg5fRXqHcSZkSSa5XL
voP0DEsgWBhTrMSwHdUIdQMBa2qxrJ8wWzOD8l8VbTEleJDc7LviKiiiiqUWwgDIjjc92Rtph51W
DcV7Tm4QniAuEGcIbLTg9lxDzBxlGIn39U8q4CWHmph8MsOJD9urthJcxnsHBfsWMMn0El4nZo+9
PeGK/Ga4qozoUr8pIL2BWTM2TkOBvjaJb+7IWIwVl5I3Ft6spa2A/HUXup/Nzy1pfYKtkVEm4bVg
pZrVM3fxuqN/sOdTobP+xLk/kNUZh2iOmFcvunqWNN/tFTKIsDeSGtutx8B9oP4QBSpiA7jNAbFs
9pVPUHffC/Aj+01r5Bz9Vz+3dhQdA8T0T+1hSQfp31vHpuxYYooJ2QcAuTSvRMpKx9+7YPVQXXpm
OT6BU6mGM+boYOB5KZkJBgqFnGYYSC1jzv3eXXMgq2QqrGxvq9YPTyq5i4DflLG32MWaGmjXG5ID
fawmFoIPlGQpI2del2d5GNoJgutZOoeG9i3tIG7/YfKq1f6sUdbpEaHVzQs5c6Nqyr1pcyfS0tka
VI8qcxw4W7a4AZkXJh63OQ6byT+B2kdfX6l8HbcQpkau0Moc5IMS1PskPuwhDqZ43VxJJy2T0QYd
tgoK6wUN5ZlzII6Ha7XpahsVbRifsHR238xzZ4K52tWY69Ip4Eb9SusXpGnoLRuVQ5Ko2/KVc1RR
cseC2+FqlqumPTtf9TVcCREGocBGO8396m/8n0bmSuWrOuNyN6CfPB7hZhDeEDJXAzq49uuH4KkG
zKKcU4nJKXK4awv1Faa10hBaHzINU2jdFcMqoS0n4P1aL2gA0P1RHta1Z9/U3vh8PIFjHDwsac4W
8dK59CLHW6VR8AprilApIf0HVUuLelnb9hNfA/ZaMTOKSdoHI3EJAAbAPDkM6xFCcJ4anc7me/7q
G8NlIY2dVoyMhVPt/sVQoSoCJ8hcrFlhjE07b8euc4erMh22+E4ztSrKvieFObgFHhxuEMUYoBVR
huGbE6WeFtEzMTccHhVRrrd6nkP4Ux7abd9tq4jqKLvXenkX6sIR+MD9bHSNHjXEIrAEcz3u3qpx
H3TxgGFuIopShYOKwkow5e2/6d1Q/H8MARS5hgr3khztsHVjkfDOW0WnLWn8/riVoEyaESrHlw1F
IgfGTcejBC9t5wfe+VCYbL1KC9kruAGxQBZP9l5saVRW2LsHvrfr9zEFRAF9m8QFounKhu5q/C31
IVDunr6cA3D8g5kFv/9HpfAnQuDDgTSeAopxUBegSvUvY9Cd+3DwGo6wEh/OtdMMfqN7kSejlUPm
2ECzvHH5S+7MXLOfG9GmLFgcWKemCY3vKJHG3lHHVoB4xjxdnC1K3mLicvINUZQQfV9Pxw8knvat
aAkmBeDHkRZe8M6QvUgc7T9F3bdUPEaIpSr5SBOn/sqd8cdrxqiO1pDPcprFVCb+7UIZdXpAjlbz
ciLXgAREgxrDaN09pEEx8xiwQV0AWWVdwOvDPIdbX2mqDLuVmN/zZYGxcF5/bmlznUOR6EVSp9c6
WHrFHAGowudVgP909+s/8MKmZ0hZk8e/jd7ZEyInUL8YlRncs93DpS3Qv1o+yjO+1PpkJP75EPsM
JneBATxaxWzpSNhZ43W08Kt9FsFIG+OQEVSWR4dKaw2lDYiMUwdcbR74OnVsWL14A6Nmm4BKoeAU
2PqEcemH/K6EKkk7TyusWwcv0VqMtKx3yKsJ3KMyWfYJbs4W984k9LPEU5kaXRBdtu7h7es1gn5a
X4wO79tLmcjuKfB0K5LDqnGvtnqaXCWnmVTvlCvmKXI435NOJU8BEHQsN4Bk+L7AkrlhgdzzNKm4
px9Icnur/96WWjb9feMyIXobAqitPJuI41kRQvXZMhrAhASd5CpC0POEhsnmYe8uFT+v6cthEhpK
sgbNK+4FQNKn2cIbeupDX45HLDC1m12LAl/gkdnjM4tTnAd3TYro6bckuC/KJ6eidxnQSkyq4VKZ
USBaDcTnu2hQWnMGc52SedsDHfq=