<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxZs0qkaLFXiiJgMQ6PbV1kOALetYFHiuhQuAX2/Wh4hf4jjlEIShO/pO+9elceJ5VQNKRVg
QQuTQLA4+zBn4HrM7s1HH7IHVN2qBPQRUFb9KKix5fjvGCwEZOlYB+LfRVgDW0lrtpuPOhk+nT+c
5zkQ/E1UyFjAieY0++tYl8bupr2QP+Q/84g7hjmFWpaSHwhQyx15WcSLT+hf4qtbxqOMrVVbzK75
iJfFq6JBCBEhj1v2IYXKWEOncz4E9FxULx6zxZxcDrKHnBWZAa8J2NHJAnjjbrXnXS7R5QGSJ7pj
xCSe/+mrFHbqC79+SJfJKTeV5J8kZgy4qyPM/J57PcJu6+C+LdEeW0aG7xJrpT0GoLtuPPrSz9CZ
RQgUxRfQK2dyuQ1kHx2mv5htitNq+VhNZtp4lYcAfrma0LLdIzvj9TxGCLiBvPHYlURNf3cmsbiN
JI/rRNykX8BZSvqfD4jo0LRQwYZxfssG4fs1CnKpxQSqJdyLNxVAR0c1q1gKKbhAZpiJZjdQxRM/
XXWc1WEt7oOpGm0cENPzLkUnN5JJ2Rsvp62nqmJ4zuWoV+CTXf40AdoY6NCuGvypPNyP5GWczDAL
hZ/oYRXZIW6u+P+0AIiCncmvktyEMpAmaIH9uhCem6B/HS9WXwInnghQ34EOIvWeK6BnEnnh6QE3
tzZFo60oOemoHMoIFU1C6Jht/mEBgvE+iiBswaqo0Zf3ixK9cAoRf7NB848vsjH4n/FoP+Mgq97e
UPj69wlvrMYf0AQYuzf3Ebc+pdXkWlXMB8m62qNm8m3Rs8xilVJFDLZFygWntlwdYBpkrC7CMKJf
mknQbh9kqSudAu4Ap51nDXD75pK3KTSK3I0oJTuC1W0Rybm/tg/0hRyOYPUAdty/Pk3/2S1GccEQ
Y4P6GsFffA5XNdLA3IHqfZQAwvlJkEXEqxB73ouNlA68XFZ10+U1sOBXg5rhxUs6OM20RZZBJM6v
oiok4lyiRtvKwE7BCvA+fFCudxDNvkAUxDQnsb2atmbVcMYF8ksSpKwLHW3UgKlzD9k0Fgb8gz/C
jDGWpOYFTXRZkNIjV8yx3XRjzEq4QtYcS2Gz5G0wlf9jDj4wz9SnFtJ9ifijUsOsSejPQzZDyC89
OWSUDe+vD20haIuBmL3qHBQWoPj6Sir2gXhkG8Yi6vs5c9I0oRs4ryO6a8Rsxy747cOOWXvuPTsX
mekJvl5YC2kZ1mzoOsiqgbxTXl3nolEA60URFuVcCNf4v3Ca2msngLzCwFaQ6T1XKsYRas02GSSz
X0Mn4GWXs5CcRkMSPdMqRQCgnMxsnZFlV/IljG0i2s5TUG52KRbmkuKzMBU+IjlGeNV+srRD1g4p
WaC86LC1f+LUBUuY/IvkcEFinsKevGAx6JKG5kPRrvwiuC1RE4DKCLBH6e7l1rKCQwVHW/euM02C
3BM9cLGpTZ+rzoOZDnd+MIdZqCv+JNNBHOSGbRTiKccs59DD5g6HJjUTXso5qKPI0WYP4Br3ErPs
ibGAGXX4T4XGaMlj5He9CCf5v1ONj53loNjj5PcI3SfBbmdWFiPMUXBApV+HsvKWzjdMPP3NnpRR
QtIN77x+L7A6NfgMpfKifqYr11hNCsWWYBHY9he5/cecuHYwxjnUwM3aIIxZhABFcSkfLr++JoHV
eV+TL7WmNpWF6eEd/U03FSI7r7hhZDHpcDPANm3T/PPm5NW5kJa3wFSf+ciH3q/yo/pGC7pOFqzb
PoEwvgR6pCjyC2/dxBH1ICRp22bhkmdyDwObAuoroJvDBlQ4rasYCY3hUplO/94gkp8AebrnB1Ga
AQp6cj7bQXCHYZzOZoxZCBQnHrjBJuJipzEVyg4nNf69vDVqRIVdPRh4qLT0qM0PLSsrm5HmAabc
yuRkyKe/hgsmAPDUS31myMa4xmILQAA6SsyM9F2ZI0LwHowgDmZZlbla0exWHo7DGyhfqLHaT7JG
wyecH8Jcf7Yo0lzsz2EICJsf3or1UralXQJZbtsPg+9bjOTuMQ0UV1lq2/ymG+IKtxv7vH261SZp
JKun+YLZUBav/U5mcK/S4KRQTxV8H2t9ZyCpgihfNSCzCOm3mgVnf4mi3ymU+yG0ZM5JO5wvaBCI
FU8USn8l8pbFO5xX1tZYqpRKQYjaIiQWERcAme2cSCokxIbOCsCV/0sWFMHJoW2GYqTMo33CKg6u
KC1Y0H3yGEI+PVhMMZtSgYKKgXCfzbRz+f4qqAyaJbgd3Q2kX+/oAgLLumWCXVaVLcPsuffFuLmC
ytWoMjqqNyY/NWQGqzljh6u1rIkLgmAOOmYO/YGC8+AP7jm5iXLrhCFn91rwZr7YSNDNKPgG785t
lVE6cFIZW/nlPd8fcMaIwx34VYWLQbuapGcClNU4snFDNGSKJ5UGuGLEIzFSZY3/Rfs35+0aO3SH
tPzQ8nZhhrPgWp4UrZ8kn4b+h3CNkJ75rLAe/Zdy/t/FCYmhSNveMTQ6DmPUoqzJAjBdbfNeUv9S
PkHY/AB3Gk84VUjJQuRvub8idcaOExn1KpQMSF9g++hq0/wxgEw0DJUE+S74aTCU/gNNxPijcavR
QjPnQpFIvDPuk1GowcIkR4z0graPidogzKiCIU+Ge4nnZ7nJUCUE4DGHMVWfEhVwQuJ1lz5QX+KF
gDoVIlRoxdWd27DDOsYtoNZl45ed/1UI70mJv3w0H4uS1aUF8T/y8JIxKC26D1SROPYhlJG5y21q
YjWjmxl780OGkj1lx13qvDkYgKIEXvq=