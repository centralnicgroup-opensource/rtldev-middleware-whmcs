<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;

class SetDomainRenewalMode extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["DOMAIN"] = $this->domainName;
    }

    /**
     * @return $this
     */
    public function setDefault(): SetDomainRenewalMode
    {
        $this->api->args["RENEWALMODE"] = "DEFAULT";
        return $this;
    }

    /**
     * @return $this
     */
    public function setRenewOnce(): SetDomainRenewalMode
    {
        $this->api->args["RENEWALMODE"] = "RENEWONCE";
        return $this;
    }

    /**
     * @return $this
     */
    public function setAutoDelete(): SetDomainRenewalMode
    {
        $this->api->args["RENEWALMODE"] = "AUTODELETE";
        return $this;
    }

    /**
     * @return $this
     */
    public function setAutoExpire(): SetDomainRenewalMode
    {
        $this->api->args["RENEWALMODE"] = "AUTOEXPIRE";
        return $this;
    }
}
