<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPojhfiBijHhrwTapuSKkd0KP+rQ/PAmuqPku10qDQsEHreZpCBQUTOM7nTNjE74QC0AwoVrB
1uinEFCMNHG8dGolKfltlmz4sEALhF7VM5BaTIcmVDL5jMVAO7eIrzKQmfrZwnVijy3Suquf1pMT
vXGdkdxD/mdZCLoslLrh3seMUk8lr/eiUz5J2OmO5DHCAzj/xybGGdYlEVgxojj8OAPdEVFZYoL5
Ig+EpN7GgsM3t60JVnRSDc3o9kGmY0Qx5b2zxZxcDrKHnBWZAa8J2NHJApveo4QHQINqIgFeXtoD
6WSIe0XgtheimolAee+dhUoKw6IN5WaPKp3ryNe0SAjAKDN3q7hHv6BzfHdwItK9zr4JFzOqUbjJ
7bVvgbiniXOLsc48z6GME6ufpUPwyfn3Oryf4kasmEt+Y+8bCgnA+hffhsa0kkM1TOaDpGJrm1UC
JYLTrBqX3Cd3aXaNvYRTVGUjM19O02O0zJSF3PJ5r9/rHJQqZDKR1IGWqW3zdhYl6IoItGbUqf89
sn9oqrx7BuiIugyJ5jL9SJVwDN3Eq+TQNVz6eAz684dr2+sNRTlBOw8fK2VdI/amGuS8EBfBcKeC
WytxW9Pqz5fwilxsHYUwUf4bNFrD10FUaj708J6NdgbY8IjtcYe8nbPf+buQ5ZYVeH5DoFwMOgfa
HRasUUyCOtou42p7kABrGaekGMF6FZIHACioe8nD41z/eaErok36dwlaNRjKD787hA18dTuIk/tm
6PZFlYgpIAikcu+1+MPhDgpHlsS56IUcZ1LI4C4ssRnt3UFdYAmetiUBfIWHdliQFTytRt+4iczu
oI917DY8Rr9r0GminsFHxSWK3Lc+rRfXnRfN99AbDZEHcn7rYxraVmaajxcGfMZUer2hvUyLKKzU
94ErPcCY25UVL4OcnyiuWF2fIMXnC0izM2xCo59cXLVaQQECou8M5AH68lS0Q2WlYgasqtgMllcQ
9rITQBhXAmhMSytQPYrnJy/LU1nMoY8/u//F8ACrY4wghshs47YJ8CLDSEEpUNA9gTzm5OIYPRiz
TAI6orJHc0bHQP4VRxK5CuX1zf2KzWhsyfo4AluIVHKXL2jCVdlJCH3YZ02MQxiE6b01NUPti22I
yrfXWpwJHCXc9zcULwOgJSXcVDIkEay/ikoCi7CVI1cLZJuC4KOlbaxcXWSwjyMybe1oXNKpNoZk
00tfpz53axjYm40oZPBgZU/zefNuZCdJ7QhGZkBCJu2u4K6+QI/Iyi1fgNt8+5tpLbbkjdzUn+sM
h1avSvN+YLmzYLBXlTN1LPPqIS1MBRkhbS+796Nb59i/9rxhsurgVd08gEG7//L48au7yHMFGbQ+
pnmVKkiM1+uF+fClypLJ9YLhk2Xm1c6gWhbRBFha0VN7KokNjQLF0gPzINALRsDm39T4qNQvYvwQ
X8HE/o8h145e1aB+ctCcUByxRhZQvH08ZnhLMkQco4Si4huCmhPG0TLTuMWfkXE8ZVUwCm9EoRbg
W5l2z3MBp7QQpqIb+qfmIzOdKhrvoZN5uPeXZR4EcVu8XBz9WyarHRrRax25/R1+b8FCc3d3p/02
Pkrv7bBuo7R+XWE2YShmuCQbyF9DLmxNrOSOLJL1k10aDJ+b3jLkorBBdtkx7Vry3zAOrZEe3TMY
g0Wnou9xbQgl0ZAbx/c3PoHZnbc9HSbr490jIlE/25g1vBNvOlGkmRE/l0u2iqkx8gPtEgONvD5C
4YCi31RrTm4Qz+8toz47a2Xzq7HRt2tcfwm6sQicrO/EJOCZ9PYVVMD5Hwy5b7/dwMLXzYNfZtS7
FrX3j6Wi0g4=