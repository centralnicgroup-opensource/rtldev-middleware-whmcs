<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsLiIFBPiB35fDxTqSC4hv1iZwl1fau5DxUuVNn/y0u2JSxJRamY4u/vQqi15bwx9hrm8Acq
J0xWh11Y3CkEtxPGA+mP21F5E1J784AWpunrTbMEIX4wsR2+s6q1GGHcr3LbhzDW+/L3W8ybymSa
QPMb8vMkXC8JxGVR93UrqlVmHGkhgSHZzAg9VGczZ8+bl+SFPOMODk0CEyAbHzdBfhv4eYxo3FOX
pfYUld14hseBLvc1p7uklyhrT9+TfXKV3zUzMFfkl3Z78Es38Wkf2AQJCbzeiUmrSNzYPcJFUOg1
wYOKAUwQt7crlIcFGc259cFPR8WsYWQWsvcb+VouNiJNR7EV43dZUFyf7BmFb7PyDUHERA2Zt6Ul
LZkqf0zIlH0tHZ6yh2Q5BAX56/E2u1W3OKIBWA+nhQPgGpCF0+LLI+4zBNe/d2q2HweCCWWcpGn4
J0acU3N6k3+pD+vk3bIFv0s31Vr9ZYgkPd52O4rLWKpKR46cljd/xBaO+0OWSwV/RgdXw9T9fbMM
xgsZ87YFWlSMLpHx2uyKwV3n02cvWIDpFb9WhTbTzaz8l+DON8qzEZRNDvte9ExXrLN47UNoppgy
yuybB9D/RmF49txHb3bJmWPyzFE9Dg6ia3fBtnzf1XuxkiurzL8FZ6ED/ZFCsYDJBkN9XxTqTocL
AqnMQuUyeMtrOPGfMaR8ec+7RDQies6tFiZHEcU3r6mjuKJD83bqwPcASmBB15S2uVRIV330/Tsb
dMjQ6hqAlBj5AQdQsrzy2OWSH+6HzLKFLXW9XHpkHUDwFLYN8JwvQy8Qm1gxEM2rV0VzBZKS5LQr
OmCkZbbKxICXBOFhW+rUSNd1uzHZTBYmEZR6JTn4UhmeQ5s2lXp4xns7hoFN8ibRG4XMI6pH1X1L
P9bWBwhKLe0lstrd0R5pD01Hd9OucJDWrSnooZqbPyIucm/tKP95nqu4jkTC8GP97rueFeC4Prg7
BgpyxzXpcFQc8PK9IoYpHaA0BNtDCK9SJNU2z50SIRLNdfdBtpiziZDkiQFr+O5e6D9iloVHvPUO
5Nn+Ew5pHjt4JjmUHAjPBTPGOYUxJgOwLcI6WNGxydCq97HCiLz9WjWWY2wri1aEPuXW0w7YBLv7
EeuTDK36xstT85Bd/aztpLL0jx//W+Z4D52RUMhskkuC0UwCUZr/Kru1BQdyM7TIcOrIGv6JoFHN
B3hck0sGhc7u8PaB5lmZ8F9wXTJUbb4qGzKODu2Cm3czXPZgzvIldOCcUI0YXfFp/NEnLr494Tk+
WQQyfPEqgHq0BW2sWyZErXT3N4rrGuIY9VPrSXtbMXSu3QrFDYj7Jdh898JQycHf9BYilvTU1Fue
gPz8DC9Q9rIFhp4PJoYfiCLDIogcyjDJnBB+u/RuAvQrpoQNeffd3hbmc2X/IyFKH2hGRZH26k+O
6I84CtrTu+Z6EsG3seOVWCiMycK2qBT699rhuEAjoyqAB6RQlHpP09AjR9GfYC/+gK0xflK3MBTe
jlys71tJJ+kY1jJ5I+z0TCeGdiiOWDEGip0xHofPLgkDk6TYtYLSK1Wn5cYHn8WhStV/9qIQJTiK
JW5zzBYMinaT3M3iygtm1DRSFzCxmQIJRMPvbcOuud/XNV1j9VRJRMsMRbbOvTf1Z/3krP6BvRdd
OIFDOQmo1zOTfL/QfCcbVRS9FtDhn053z6bTGIW7aPYudoESvKx2cEiMK1MINBbDYQQ1cvKWfA/C
9CgUKN/gJYaD9G7QinSWYuOOnY1RRYRSuVtg5PfSeCYTIcYBiM3uA8vzGJ6cyHRc3N4xcH2CsX/Y
r/VMtUQwe1ye8ny=