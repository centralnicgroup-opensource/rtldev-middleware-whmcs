<?php //ICB0 72:0                                                             ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPufS2A+5e/20KEwTZFD/29OMmM5i3frkz86uenEzrRASTFHqpB1XwG9uvkM+vvU50nL03FeT
wQjxGx35DXPH2XyhbZKWOELIhxxdwQevZP0T4nW04LwXoLjYN7N2PnyugVaaWBNKpyCu7nRNFtLZ
35H1mzupZJUE6iRQJWVcYhHroU50+mXrC8aIUqyhmeAqFUw7JwyqzOpMcUcbDTDY4NPfXFuqrC+C
gShs5PqwGPT8TsuNLMyNg7EsoUSTQ0byGxzk/9Gmd3xfwBkKmN1mk9ZkYbPfJWXcmR8wso/XNtTo
NoXh/+vohFfYpXRwtYw0AEf2GIsRQrYqJmDdzVusqsXUE5TeOjjOwYy3jLM5+GOmnlBNTzc74n/U
nd5zkr92QsELpc4SheIiNNIfYGk2ZzYs0QV+zwtthHaSeKofY/emCviV8xVwD7n+M6MdtPVzZkoL
QARLehu3yrOCx7abGoQy4nXlViIxflK7mTNWpPEMOzv1ze/oumwC/h86RCi7USIiNXvY4ovL4PIS
HLPo9YTgyc7jd0hjo58nR952nvmpLZrVInJHHA/NCGFQ2HpU7+1/SYorGf7m5PIosuqKe7vn9i6d
u6DMtY6+3aBjBJGXjfeskXfPVUhtsHHOPquJ4qfPYJR/19eHz/Ssg4m3ewwYnq5NDCxbOJuCUdcY
ZFWC0qBFISD5Sdvb8G9b7Nt0W95bepFvBihOxKeUv6aquBDssPfqUluDlFb3MJfX8k5zANG3+nYj
X9bBJ/jVyPAJOKKZFND8twoJVZQ4fMpPEyA9sYYYW/vX/oypvw7gr+29j0arK9YF/m+RhWZWMqcL
9vvh4L+ii9u5c1m7jKqNww0PbuhgnSdU5ZBSOCccwHW20lKQeWEbJAK41G+rbpl4DjgjNxmVDYZu
7Y9xdQ1sxE8tecGcYZDOEgjqZsveHVch0jCJYUyNyHJNgrAoNV7LZDt3U1To3BFiAJ+4xPLpyrOZ
YUelGzA50FXfmJDfjNcxS1IcEKi6rMT6IZ1CbLslz78aW4sud+lAyRVFWZQNWHj5kD3aeDMUrXuD
bXHUQf7Fn9tH9a1CH3yxSIRLkG35HrOrxTe2AD6H+2zfw9PQXD1l/MQIZm9lMyPFu3f1JYNEWhuf
eq0oUXHsT1Kg8Bk4tA+aFfoUYzS75NKO/Sys59FiXXV/0F5r6MBpcgX3QX8DJ9V/v5GSowA8dEpS
xf09msBu3yT5D7ZMAMgdyoQLz9J8EnHpMMlFrMrPySRruQMiB0nt3DelU+Y3YK0i6/v4RoHhvZsy
TdYYUwuY32IYZT3pIL0JikPvhI1bh1urMJe44V4MSgJrwBj+wux+Cx3DAexCzObDSbJgtUwYVvq0
j4RUGtUx0Rib7uujYkc5z0gm303MPIkJhMrWbuALQFsaY3gET6qkaD3V9ND1pD0pTSUg6N6igruG
lBmGXfXQZZxgniiG1vFw0FEnMlDnTpY/2UsX9jtTrbqD+wb8Tlq55j//I13R/p9jiTJ+vsphbRWF
9CU9bM7gfVphneBNZGy+6Ce96C53fp9ysndiX6WidAVm94dGEsB5QvCV8DGCNRxs0ImRqrzWnn1x
II6A/YJ6xiuumv5SuWZYcNPi+nPCHhUS4EFyPr4TtHHIRfehE0wnmaZf5V6UDIyJ7mONQzYo9W3K
erApdYTi4MdbW79Sf5JyGYEWJ8TCkyep1eFygbjmf2PqoDmHh16Cog6Za9EnRWLvjIzEhiIuSy0x
bPRfICMG17r57O9cbFttbsjR15lAjqvXHga7LazUPW75qsZcvXv+IRviOtT8oQUqSYqBsW==