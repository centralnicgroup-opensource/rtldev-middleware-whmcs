<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxktlEHXcGNBV0Kfnu/h8TCq5BIgR2PtUB2uGjgUXgEU48DMxl+m49adnq5daSUeyPpHcXK1
dVoiiQEEBKgXnY/L04lux0h/hqqGJfODFgQPukII6vvQMHm3JYPczGRag5mcvq0oktVEdYdgq5VI
KjlVUuoDR+8TxzmTFI+zY7PDcKL7QNT5FtXvmIUKMXdYVbif6S1Kwl1g4w5XORds6p1NkJB7TvbQ
4jIZgiLH7WbB03+Uq3M/qeNW1hYlD5b4H9iT38PGOQjJKu8SAFAUjXXANMfbmfrIPz0hVPizgXYN
f0SQ/ymCSuicfy5DU5Eg+IQ+qO8AEUixY/N/pKugU/JiuUlscl9FhKX0yj1GsYXimuOtOBCNzkMj
DyOwPA6RbEu3xh/g1swe+Om46SVsUT5jGi2Kr5RsnNKmCrMuEz4JxUfgv1DExmQwOmN/wz2MCfF3
WVRbryCmITBgiRYiCjSzKzpCoIew9Mw+DBUiaAKkrET4qciHnRkizCwdg92lovaoe9ygy1lDKOBb
wcWltws3Vl/fQ/QsFt5EywLfm70a2yAesLcX1N+Sj2XfrjkfpEY+St+nPwTxJpbpbcJoRkx2BMwk
pUUQsjMVA/Wo8DgHxOu5Jc1FB1LSl0moohkSnPQUfo//6C347MACHfy1NYSvzk6cVDaj211HxesB
4BfiRaTcPDkQL/AsFUU2Y+wgmcK/laCTNEfFZJuLKcMDtrjddX+oysLp1Q5srGZ7n7upVYlcVBCj
s+V5Q9wae0YF3sVVSaGcpQ79JVjWOOH1q/wdGJHXkrwsQz7Es8qLfkcWOP1zXKjk5NjFN8Z06p5Z
XEhSU6CT7I+zMmWnSGg6bkT2BhUOEWQJieo8qrDxwgm3NjtXYzYDNi3Y1/NeTRo+5Sdg+PITiE19
usa9Hs+jWiN4AZ5aMDJRsYw61NK2ET3kXKfGgjyeOZAnOnB8DR0d+w05LfnquhlcHETUQyEp3R6C
Vzfz931RdGtTrncyU3aYHhXAZhXgMKMi6MA+ea1M+Eo7oNCGjjdDC9WmabkgulFzZsYAnq64iX5h
yfKOGlgCquZP1qpVnEBb+Brl94c8HqmSEGDqqpTd7SDXcMlq2lqZrmoy9CzK5r97s8ca3Or0o5pJ
2oN2+OlR3MbgzRG/UeCoaiULynFVQNZ9GVZ0PZDZGZdlFbGjD2iSUMArASqQ48lbZ8+HtbrY0/kj
eZHT0ydEN68pk8YtJQcluv1DVcDWVIH+1y2V2tf/FzYbX5z7R48Jgh2f82Zz4zk7QbeoCowr+MEH
rGPwI0VpYo+xgBHVk/N27OXkKjFIBKXxnaPljSd6qGQnImpeLyWu16w7IdkOWLGk69E+3774fofJ
4kTxhGDI6vn4CqKjOId7C1tLTfGVCQiuOcQsB5LkFcvWCXlZp9Hp2Cj4UsWWSN7PKR8w7E9q8B3R
a2tvD+DHXdemDMkRfRxKyCvvnDNwt9M/3ey8js9ttHlnhryT1TWXE7L6Y8P7b5ijiBzySsQRD5jv
bERBoTKUVRqwspMw/kUXRNVylTHGRP3CEp6fb1pCbVilZKQUC7Z6426o+Ld3UjB5ci4+Ni38hXh1
QfqROAAm6rZ1d5QXHHvpBYUwE3FZLmiRUN798TnQxg+CtQT3gfvmD0dAysaOBt8/CzlV86vgtwd3
kz5Q7lFsixpCf4jpwoa2WcP7gyoYOVKF5xkdNWk749QtehjJkhLNPUVR/uT3/OVqjHzQAeo8eSVx
fkYfsYsj6QQfG7FpZrejoCMf4wSwoG3KLCJ9FH6bQEY652uLCRu8ZTB/rCAaDF23nNhYgAcuIGhQ
lIL8x2m=