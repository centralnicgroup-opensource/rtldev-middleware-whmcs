<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsVcOEAiJbdMgLJrmO6n8oPulAGRZ2fEpxkudSE5KkkbxhOG4zEJqeZN4hCj02MWTBE1GIoN
fWOQceqkgoQgCS1q3qS7zL1kyy9QJN6WsUzHgGke1/djl0tq29QPf1kcKDwuUQ8V7uSIFYIygqCn
vZXtDonRABIsVymrUNfVs2DxsMldCmwiL9uXd5eIJROf8cxcjaJQmbDThzRkli6AaWq8PY5cKBei
inF1e7HJLK7ToG7TmHlN6gls0JFPDSmpUoKXmbNL3Aaz1Aeez3//eS++rl1b8PJKN3youb+t9n0e
k+SwPaUSl4IwGyLeNyvtMWjxRlvd6h6gb1u5l4/YaRdmuT1337JSARGf5xLsRuDV0KajurcBMYZx
c4+TSn67ftUDGqA5os9Z1QUgL/9hk9tcPjxRx+w2ljXx70Lz+38JHQmCoU7yjVCOf9gyIPZyMmN5
VXGQHcJf9yEyePXLzNS3Mx77wT28MzfcFQ+pzIhdFSRTPjLpkLMfEiSKoQ/9BLvyJ0NMp+peUUUV
uRcvbPMo1OHaaOpWYA2KsMIWbzAwyKtdWgt4+gIjytPIVWClrCDpQ/Mtp0w9hZuRojneTKYVMEsu
YFjfkN1SgYaqfRhReW7F4Ln6zk+Qf/wGYl6l32wXTR9aaZ7+9sBmivMfjow2vHK+RvU5L4nddN2S
ZAkAbMyILwiCPH6tdYa8UYxBmlXSTMPGkdcfBUUPBTU74aflovABhxApdI41+/iooNRfQfPjoEu7
ETetQDqft2Uz9n+LeVJJUpP8xvjlRx4dIXMTo9GY6Pp0dsUgtE228UmiVWMDm4WYjifoT+7ONPww
nLbmkeGEjtSu5cUVQfJz/uIP0Qm2SQ9l1tZZNwKh8qQkpIV1izvYNiI27MiXcMKgnBMSUzw9/JVG
hLvGAgvIrN8CeMDW47KGQ6AElNBuCY5isqEOC6P/wB6lXySxFnmS1hyzKOrXcOlfSmCh/9sL+0ls
CNLwyewHoch/DjsuPADXqJs38CND2LGmj7Thciip3VA3w8x/ybkMcQW6pk21aYuHBrwk8bgBsnX+
GGWH3OHCRWgy5xFXUpLBUNUThiU9Gz0rGHjymCVYNrY/FTsT2Fnu2E+fNhZAKGFcqi8NOzMls+g5
FrUQ0CS5iEcQEaljoWG/td198LEa0lH/aJlmWJM3WsO/l7Li0AJBfuKidDIGRXC4sbnqx52NcOeS
I82kbmklSPV2XPtGfVvm+H9F0ayEEJwuza5wgjPPKw1sfzw0c9vDbtiCsnfYO8xKsj881yG2TUYC
wz9VgbiinNt9qP8mJwqJCyCevPtE1i6DaxrlblEOz5ZCpyqJH09hD8GcT/ogwdoUTuhhwKeMI+Ap
HWJirkycI7X3pr0vuSDDZX5hbmqowxvMxxj5fKl944uKHxF05gm15aQgEYMtC/Ph82I8tedpx8AD
CVii9HRJC/9ZNuPbWuaow+M/p6dwR4scgU95aKoJzGE6Qs+VKkDiLJuj5iPl5wLvs0qAG3qTOIEl
E2zdCEbsD4zRbkB712HjUkDYKZXlaG9Nt/NgpMZWvu3F5vZ9LQXfqqz1xaHbz8LOEfs1LLWp9USb
DIuYwQJgaSEEM3OfE6pP/ocQ3xh62SReQJEZzWgF71yTQ6pFJeVH8Eop08uO9GhZYDjS7ZGaOLx7
CRr61XzG97xAN6bkN4BeRJbAYHergYPo4QLDWKKOvzMcbr9Aob0G6U6aPwRzhZzLgbnbeARm2iaE
EiUNp9WBBLtDag+/k1di4rY3YjXMLRg/nAajuKaNnCxNbqQl5+NSNQtKkbvO73cakjWrxmi=