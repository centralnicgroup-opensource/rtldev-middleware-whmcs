<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw0EJuUVqREePhpQfFDIP2FSoeHFMHEoZjGOkdSt/hMRQTl36869yy9HQhvBmgKRcCctaP/H
DwxmvdKcVfD7wsQ0UBrl5P2Nm7/CkUzkV42etQlBBz9F74oufIvfVnWJsJTRP1PXY0A7+d8V2dCr
L6Vyw409363v5bNjs5Hi3GpZFlcSpsu8szznReC9ZD5XSt//3uym4OsOgbJL8Bbf3EOgM5jCAVbm
LaJhkAXRbn3kk17b0fdhNA9PFmrRfNhj3ov9Ur3qNJq+iX0rSgIm6ilmbiFtQ94cR7whX5TIfvc3
ZQD87ovuMgi7cIPVbHQvTILnDwGdGvce4nWkyosQFt73Cnq4Z/CY2deG6DSj+3yISxb3dtHj7YVd
i0G2a8mcgNgp6XbJTmdIlTCRoNYWKLJN2X/aRetlSB5x4tuS/zY0TWAycAvX5ydnGc1k6Bq0t6ms
aaohx0c5UpD2/MvaZLTU93PIOFxrYM0EyxvHI/pV6CV/eVuq0CM5tdbrWA+cABnfTSU05PD1PuiW
gDscIA1lihERm0b1eugHWUxJxcUG4ujn1eUNJ+Ou1KaxJ2xAvp3eL1Qn/WqBOPgCQaTyDUMOIWLt
p/urRhumbVcawy34V94r2QXLbs1dj2J5m76kD5NxSTDfJIs4tAKO//PteDQ24UnHpb1xKci+o5Ma
3Xr+pMYpOf54vQstImp0oDMtI5nmlsWnmRD63O320FedYpESjR1rwfnrVWu1JvSqUonbkFwQYiae
sSvFurTWqDkuAXVOYVnjNron/YjneKn8ebxR9A84gxEeB6GLr0F8eugySy1VvraE2i3ScnR5Uj76
gWwYhplkRmmEI0pg5D0V9ILia/4mOY7t9tDUi6oH7nalyZuN3nT50w2kflVlnej/J7NyqNfIeg7e
tLOmCK1YveknEvzaqzk81aPtJ4hzgVjtfqJd2dtqaug/Zuq0vbGsE7yKfUZ9VFYsOxVwmNz0qlb1
hUd6JwjyRHZdRnwJ/fOJy3WigkHbiuQVZ5sx6eiCrVtNmuZ0GeyB4J6ot+8Km0C8vp4Vi19DXCQ5
QYj2klXFHN3Jq1aj2+JhtP3ZhdVI8eolsn2PQF7ynORSUZJbSxpQQr+kOdM4GAV9MM8RAnH7ZGqU
evWf8m2Je952z+Y7k2mmy+bha4u+JxamNVfJEOdFvjPwZxg31rUNTVaDoqYMdbmTQnqszYBxpadu
H9VGv/C2Eje9L6vTJhKUAFyhM6OeXOHwFMsYIvPZOQuhtx7q+gh9erJ4M/G/uSZrCaDCIF6UurrF
Sc764jZLHQT5tw/7HxH7rZK2T7HQ+ifvNzeTj5qSARp8FWpwJMttwv1w7pstfelQ2DIjlwwbYLae
qL3zIksUlZO6xVvDkQ4RTEjMjf5zESmqDihF1XO0gM66kv5Xj0EPFR+olGMVXBmndoWimRaT5fsg
nS+pgAhJ7E+wNLz/LwOfw76tanRXE4XYujOJNV2sgqzQUltF/4QUMFnQWDZgvSPYJxRvGtwQOsKs
gX9FnM2V0SEY6MbBQuxnQBEMojoYGYklCry8Ea4MpFkPCGCYCZ1ZHyCuubUMbtqWqD93/puxHDJh
FS9bCPTo5TCNMDcleb2q5HX7SZh/RGuNSiNEI8fkoAh0+Hk/ukYjoth/687CLR1mKVtQrm7Rgk56
Ijh55HFFSPm4cAWgXzqjn2jiNiP9LrnVQUkoFq70hKPAW943OAzf2aDEHBCUIkvXPm5I/VbBbsln
RNNhkds7jjq+L3ZmkWlQYazHWtdN8QE5wst00ukD5js85QCgECrB0FjdrnHTUTzCkf8AOX2L/4gw
CJLAvG==