<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq331DNrBVqQW76HzXL3qdBUsO/Gxf1nHf6unY9VGYdaX9An17D5lGPSjBHWr5bBz0wpk4bW
1bsWMSsbw2q9v9g5hOl5qpHl2KAdVTrEJRJvKt4clJJjQO8Ln8xLipDzP7YhPzQ6Otx08f9Pze0s
4RaAzI7+qcVoMKIlsx4B2llsUVH63ZSrPBvhWcbzBIyIGxuORi+/ApHqx79L4CDrJzGQIFGiYG6m
iKg62uWMB+B16DHYDF9NaUebzVDQGkJJSzjxQM4BibGvDFIXHeienCM7UbPesQo1tyd7ayrcDeud
YQTZ/nOr+v8QxSaO7dqi+wBRrPmaNCMbckc7P3rdoc/9Z19QriXve9zHmS0/TS+KxzxAtFmolEM0
0UeCmF6atiwqocNp++p4ADc2Vj71ZLeHoJtWBfWM1pqgSo0SzOP5vzw0FWoA3YRmgzzsrRolD3rS
t35G3YHP43+G21EImh3tuqXfa1f9jffZtIyJ0tI6FG3RS8mox3cB9gGPlNUXBSd9ZrdhQybdzRQL
zm2HttDO2uxrlJK7BzapyWPwOAaFFjEGTnRLd3GjCieVF/p0Yu51ZXP8P8wOpDoz2yzPlucQFkaq
0yIjmB39RWJqHCT4pXU37r59rkeOjACB4Ipo9bn4WmNNTdX5On8u6dWRgRt/NLU4bjuVP5BI4aDZ
d9A1nN/IEaJ4bUfGy6g4a4pERy3dfFn0txOT+M+n0z1YREzznnuC9Cbr5QjcFRFoOdft4PxRFbvv
qlN9ZP9mrqSrzyyPZtQLkviWtd/SfgnODT449L4QmTFAsURjofboer9REItVmxm3E1r8HA7Cqpti
tRBGDi4DdVuI8W3VGYSLxrDBeRVwBsZQK+6BT3sIs3SY919EdUueOBEk9ils8Fv7XqG3yKMyCr/B
KuJVRmn/1AqJ+H43KYoan/oNxf65pMedBceJJCeW0wjOmR1IWOKC2Kpwnji2mNI6WB2+iqx92zco
hTT8fUTw0Fz5LGWqv2by2f7QY/x10ZZbX3TmKkS367Rd0I2JJecNgKeXJU+lSv5lPC1iwpSb+WrH
X1/nGXWxNYNxBzPVtBgCGSqxvxyYMQohVnlDFGO5//9FcCj31FD7wBnTRnyVckvyw2ORT2vwKRbd
DjJZCHvzZoni7Mlpwz7h1lO7MfDRVV3sbsKgdIIBkAhSgpl0Pc5xXvF+HC9F7D3AhuJOO3VlZjK+
u0Cu9ySsLh/qb80xN+OpHt2E0cET08EAWgsZvBuwDcnP0NJwUe6SEMh+7WGvgUygnFruxp1cp0Hw
3WA0LzypQc4oLitWKapVjp3HY+qb3tzLJbOoQyFMnAlcAgqHS3dX5rJgJTregCXBx0tQl/vwYcsP
e42jqlPTty0mxDl3o0BD5T8BAvVMQdR0PMT0/SMPN77GMdQOEbvOX3WmikFqPyIeuys3blmuZc7J
tcd0nJAq9rFFZLIDN1P1sQimVEjCckttDUnCEPjR18T8sfgH71ygZ7CPZj3byprJ/GRaN5ceO3Op
qOII8D/tOods5lan6/7V9Or6orOrleLBdvyLOpyddCco3uDXD3fYqVwYzepRRm86j1eCrU4Ttv+0
tYGiX1buYQ65LmW9oXaP7DnQknPWrtB0/8FfsKCbR337/wVOpFKqRof/t9O9kwZHn0NcqyWiEk9P
Nm2wEFfdylc++/dTbdGenNbOkcBqaCYZVLe8RnOda2VSetQakrFvRHjRcpR/vz+xFscJTi1US9JW
8ZjOBuDrbra928dy4u8h3Ppub1vdpg3gpWRrrUCuPfMqH30523xkB01bXzOSP6kS4mUDxNudV5E/
epk7nBGR/ySxB0==