<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrXwZ635sdHNaCWPGxzQZsZ0kTLaQfMUivQuNAWFfwRUiEo8ukE3K51Kg9UOrwk5jgC3ySpq
YEOnQFFLPy/K6JAeqVyc2G9wS36VL3UPOW3imbyXiftA1LX1u4KcCNbw7BX/ehtcaOavUetMmYsZ
1rCVQA3lwAOF5l0zA+qB7whOiNf+0Fegj61VcBa1gaCb2x+P7Fps5SK+SQTdZa+fLF4IvvD8YPPh
+3VU44j2KZ99l7n9u1fRqHiDnoy31x4o18dm3dZg08yfAPZoJlL6wQeCcxvdIFdMXiZ+Qu46RMR1
wOP4/vRsHNyXf0uwmlaHZ++oy5NxyPYaofYJ4+MdTpcAoSeVokkiT+tAeDQvjPPlq4WZRkmAX68W
+eSTYU6dOvkuoFFDuslujZedwLCCwoLIH0K0SCRpvYbdwWE9CkSuP02CbSzDMOaQEWJLBQAlgss1
qbJjea6g4lWVtIP+bA/0CIwyeP7T8rtI/okXf7I2fUITJfsmKxyqyEuozFwni1y/aSFiMeu36ehq
abk+k58AN1IbzRfjyv5SqvePTizvUxbO2bWs5ayMZK9QLpC6PEsmCU0H754X8h2ay9uGilMBUlzs
S0okhU2pTdqTBibcYN1Bmid1IyERi4eBwXtrTQWeWpeXyAFoEASjiBqo6peLS7ZiPhjdesBS7V3/
0U+gaB9Ia9p8cXf+tPfkJ2UOKeTBNaG8VgjNaU59VTlNSLaO7lwZHAf1rKTKTrqSgA66B/okJY1d
0WffuiYcq8wU1kAaB40iO6RHdrcyU7CAB+WDtwR9+IbsNqGKdTSsSX0Qux+d/1i1QC1xqSBv+afo
pgnUPWitb4WYRNoN1e79ztzIlwo3Js3/9ZPhwIRT5yN2T2rkMFVlhZy17YZ9jH7qlWT3LtYzmxFE
VZJqW1Rq5o0tWw/KZLibgFSazzR+aIrm/vqvtRLuwex/sgKMKZ7/xi2On/pKOP0OrR+G6LCmZ0t/
9B17kay0LwTd3jL6zeYNUyYj1u9fVNVYExMP2N3bZZPRLGXsJnmdZx6XmeDqKrOkMFlojfer4WTB
6AzBlQXUCc4IdBikOX+dK/9skM/2LreUmydvfKcs4hUKGR+sFxQuO4hF7mQy51WXP/G+BAEDcgTj
H7aRgJ5DAGaRq7Y0CbJl9rxfmGW6SZqTcnMUXnJdXH+xghSKPbhZmohn/qLsb2uNdQCkUdwT1/m8
M+tEhzTxJJ/F9S6Psj6DOG+NXodsvgAmipI3OdylJ0jX9U4c55KhzHMZjUb2UEPXRbTxJR8dNWWN
hjOKwuHMthpoLbo6OggD+6CN8cbNDLGCjdE/6Pg9tp/r3TOvR6+xppHl/m9/eUa9JQBKTg5sdYGn
8gfKP+PwZWU+qyB5TzVTqWhY5y3eLXvtLfX0kAJJEDBXAYcHq1JC4Yfrps2soSTI3Mab5XdPFv1L
LqfobDAgDR2phqoV70MlyfnT6muN4/P3bYnT3USqX75qRVZjiAZDMpQRHv7Sm5dHhDpKfjskW4hy
zoaMcbvNae30jlZavz5Mh8T4I9sBllDXJ8H1N0uPgsfjNcD7ScSpfCUC5i7NgmQdd3V4jEqbutMr
coo9Pajzx6er2m7UzFveZeubmeqEwCVbyiGUfFSiAwRN253W6k9ZoKKF1UCcfdiUZFR+gQWJtSIR
mc5kQXUtgRIDncY3b6rhlh/RSN8YJ+mhSkZXi+32ji6bAmSFDJ4DI3VcQzE0GNrKSfFIObC6ph6K
+3JRi6zBskJQDYfFRPdftEjc+tFImltq9j9iS0Ca4sqC1KOzlC4FzQjADbV1/JibuHX2MVQCnEFw
JQDuojwjQnwuMq2ulG==