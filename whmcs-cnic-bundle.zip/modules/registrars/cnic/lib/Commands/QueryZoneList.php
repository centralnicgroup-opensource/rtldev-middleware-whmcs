<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsH1S/lNhqVzhlFcs1m47rmp6+s16yfCWkLsYMtBt4JgXhZ6FoTlSGLG1rC2mvJQ425lCnX8
wP+aryxpGVBwvVB8m+zgXg2FHh79A4xXhsfPsx7vKw1426TRTt1FCeuLTxK59QaqtnRjQqckyNiK
a8snl1nUcs/exuJwaYD1RIviv2RFpNZ3z7msBWg1WsyYaRP1oH/DaL+jR53ip90tS83/KGseaYAO
Ypg7LN8HVkWnyLRb19E3TcpbdTkilPK9RnxqjmM+N5EDoKg9JE/Ip5cP3c6iQoN+QCJ4HsVtCwmP
EB8e3V+wzv1OZP6hCz+C3hxn8OI2K9yUHPSDpnyZoNZAN4n6Kr7ADCVJOBs01rF0M+FK5prsrBmo
H35uCC6x/sNA+GAQugWlDvtk8NnTkhjrnVUb+zYbHl/JaeJn6StcdR8szhVWymXjxNio4VggV8G4
pi5OV/dfHRzVM74vqUkY7PtsNoAeAeYT1hPk/QN7XW6jy7Yj3gAvZlvxwNxUSIFmQMwdEaMvsS68
oOP+vWwGzh3Yb8C3Q7TwG7PEVnP4Vby3kyMlOA3W7k/hecIErbbg1C1MKI5lM4Vqk9NPNVFGnQMs
SnwgP9AmSCvwBOf5/7xK1olABxSsjKYoa+xWwIwEfPXQApg5f8WvC5TK2PG0omZ5NrlbqD4YJsQT
psJ3RE+57fR4VpE1GsGFdlJ+G4YQx3Lt+qT/gSNan9l/oGH1JMEJf6IljAfWUg7HO2KBVRgegT7b
shx+JqsrHVEF4cKn5k6dwAlpFdDSboP+6aD63BPqiq+PlcRRqWWoQ9KIaTCvPTyWn+TB4T772mF3
A8XUpOU5ZcdnHJe2YzEIPa+jPA0av+CsAzoLXkwL/m5RTZfD38UIU+V6N5/CRgr84cNUjH6iuo4h
IWzAqgkFyqzc7N91S0YpQ4FyZE6MCisSTgZ6XeQgrT/K+hE2sm+JJyp87Y3D/3rfzNELIYqcQNW6
uRV8BSdoWHOup3Ox8VgF4kc1R7E4ovez3B3RAb9+cvXbRqXJAPceDq9Ojt7CfvDlDr8RBW87YPvm
DL3q33I6PnPBWYrvG5oMRrd3YuL7a69VN8M2hHfgkURIvYad+jTT27NrWo+qK7vh/9owhjdCPJ1C
KRf7PsRIVInoYZcGS45am8BHd+SAu02B/vxVX1Qy3qb7QIjDuZczGQ3v87HUffoDYVFIajhkr7Xj
mStD8fQVn0F43jpKpPUjXg3MATP4fJR1kio/Mpb+qHM5hBqDTZVs1vruzgWLFyaH+zvIQpZxBGKD
pw5s2lXi1n/3+AITIwvSjtENg5W3tUQK7NHRa1kVdHf2saeQL5f+IkdG0lzO6fJqf3+xaD8Ejxgf
otxyNjmbp/6veaA6NiAZPmxhff8FmmqmiPOHPXaoiPPo06f0jjoubbP+yZgj3jxthQhwMDeNtutN
WQkPQZA8WDbfj/YVzF8mn4ETdnJdu9ywcDNbO8dg64UWqtiagFGPbL4BqAIpNDnEKhsBrOSMn+uR
T09MNU41BlCogWEPBRyIHxGS/De54sQiwpCVluB99mrdtqBSqe16ZZ2eJOiAt07N0nBkfuBlwaeR
nnCicETGnT07uvSg6/bqk2mH0EOCamskseZh26vHNZZosTqNvsb80D+h+sXRdHeEcJ3s9fEn2wNW
mCUHsXZZyYDDZ9EOEIz2NOkKKCM/1t99+1VjhA+gGbyQpMWGp15WW294wOwIjHBDKz7CkZ/2S+sb
8EWccfowelrmVaWlk49Dth3/3e3AM0HyUzl01rqZLsmGiBGXycj5G8pp65l2mvCTC7h+ZwptGU6h
