<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnY42e82Q8+rspQVeMR/9bLHdqJB9kXfoQIuHK9upS0/52q8DGptE2R7+WkrQUi5htha5vgD
OGDmSc9bkLtpeI7y2kJOkK4nBCH0kdLvrdu0v10FTmnKJ8Lkl8kOY+bVjagPcaT1tzVqjdmJfleq
S/Qy1BxEW94mHNVtaZwHFZ0FBoebMlnY0HOBQjU8ySv+T3O/D613dhU05JbWlIeXCwRMY8PhEfSw
jMQsUhLOiW+e0ngRc1QldC8fz2eTbtokC9Icnj+7fmxavcCZy2lxBYlnlZ5ZH6rgGYh96iSANOzY
dQWQ/ojyPdWNK7ri0+GBHJW6yzKARDoVqyfiU+ZYQXHsPrigOauo9OyS6OCvz+t73tSb4ssnmW4P
E3ufy9ko/MR71UKL9pQsqcQzGApTWHsuKwJtNOkSt/IkALvit8S96kYwwE01WSGX9H1waEEtQkmF
qDGx225Q0+tIpim4YBT63IxwcZ6E8YLHF/cjT9OxqHjl3IskTbyVesrbEzynQvaJpDKP2RfH+ukM
aHkjerKmUSc0zdU1WmLDVd1pMNkuSeD830+wUhmVVJ1uiX+r5u6vh/76e1wqmXXIN0DZsgeGUnDC
GRAyuNQ5NpRuNp5+yI4st5i0BY7U0t8fVDLsGiPQsGx/lAC73XcuHqxu2q7SX6eOnvc8WdwMvxVL
gLCxfDlCnWrPkVetmzPh1jvxATFq0wOaAY9TJ8TI7Mpa4hctR5+anGrArhaXdoVEW4HhhOMq7LQo
t9iZhDZCoTvaWPfgoxn5wHzbnCNnHNpDhrjBu23dXNyHUpNxVtE+SKEze1krni4cpdPkwJU2GiMp
5tbB20xnC7uSrD8gJDu3mmLNWD/PeabeWNSN/lf65gK5vju6bWUMMFY4WA7qx9a9kxM6louQgPeA
8HVBgoDVH7x8mTXIxHU9jYc8RJyC3ymzHHl7/3yoCS5YNfhDPHlbBFHE1HG+ttCLrls4hgndp9aF
gTVxScVi7gOr8uJ2Yh3onpc642YoVYr4Qa4gJ2qO3TN5tlbMb6XPVdnyH3wyN6xGcNkuOcEKkhSh
0vu4rlBBBDPiCG83KoVRWHUkWQXcAXr/IfMensA8+rMxDPwF1H23MA/BtTvkIP/UOxxcajm2btKJ
HqmpwIrier1Fx668teLR5ZrU8hvClQQ4bpjhNXvd7fEvAJLNWFIr0Zib1PcAB5bVpTG030F3fmBj
yYuO2E8U9b34jRwBFvIj3W9mlG7HLxceyH2kll34rdGJojREp1fTXM9yhizBDJ5tlQa/vunXORND
t2mmFZVOlDQrRt/qrBv8Fu84Qb2rzN02/j9HdUEIlYSro1HdJ9ezXZwCAoKLL+1ZvUeC4T7PAfL0
tYTIZQ9wqi3tJPSOSdxURjCzy8cXEVfCYYlgla7fhK+DHC16fsJS74YNyuP3jXmA+S/bHJFCFTs7
IW6o7DQ8dzPGjlDw1y7KY5gvx6X157RLyQlCHmaceP+1zNnCCdSCNCoOSdJucy11YaaF/km+mmmB
y/2g+JR/VSzWbMthIbbLxIsc6oXDVko+b6QQA2el++0U5CSBkyYqfh1PCRzQTkMeEANawrg375/H
73WFJJLW3KUyRHyAD3UGPsitBX/2jp7dt9HR+mJCOK6365VRevUR7PKC4y/jHLIR/Uwx0ccvJVnX
O7xHUuoacL8mQNS/dtgEB+PN9X4pQyG18Yq3Rnr86euL2JucXiSc1uZYKJ9h6J1YeX3duifbXKJW
B0Ima6jBrrBgd7WdYs1ZSBuNbnW86HHUNuaTwLYLII0VkUU1pz4HKqJotBJbj0k8KN0Am5sErz0U
MexFaAeM8YHZ