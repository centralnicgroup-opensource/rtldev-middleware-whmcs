<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyV5HVXvAxx/9WHtqDkDkAZvyKbpAXc+WFfRJqxX2K07JTbl1XwjiIxW/pEneM6SDo0NxqjZ
xxN7e5kQXwpTit2op1Nxwm8z6a6RbrNJx5271J8Xt3HVFHuCj5vCdgWdGWB0pwm5aTNU2gB1/Fmu
x1lzoEMmI8vSFG6YG1t+Zk7DZx5cGvqgV6fAk0Y2+L3VkrjpJ14Olu+gA4qiVfrA8VbEKnKHXqbu
UQ9qTgi+Bh4nvy9jof7XCfRKMKU09Wa5MaEd+x7/R3uQsGryYXfCcmOogyqvPeYxCH1Iz3+TGvqE
OZ177BIIWuqzLTq/Csx2HEaKlEn2uqiu7ipve2zTzwDprmFbv33ZohYWAs1jvXN0eb0h8nfH1bJG
oMNyh6phBg83U4OIu6BPomFj9bn68HfIWnAcXoWNBi0DxXnVUXYm7TnODOxua9rJs9G6GKjbEacy
tuWCkl/IdCTSl1IlPSnYMFM38w64Ktg9806B2fHTJtRhO2wOC+X/l3UgXVZv/r2liCfDGVT00lH5
zPtMbZ3KhB1kGtbYKyUSGH9AHvFqOYNw03vbYgd4g/icQ7oSEvPROJ43qHBUvkexN75oBNncoXJD
U5tPpK3zkPXPJpJPe9fiUzc2M6b+vRpItXa4v7OZ4y1o7858tb8x9cEDLkBO5MASN35aFXJiGS0U
iWqQXPopwqfU87N3Zdxco2YEizM9ymxjNTeLddmJQ+huRpO/vvFCjFss/nHIDxVSp3YfxBVuXUFD
jcutCI+6DJI5xH1n5uVmHarPMdwE6pWDdTwL2EpNPQA3ELr/oyPs4DDTV2qqDiY3D0cC17WBmxDC
PPQDDFES6KMLWTONasdGE4AHjHGGcEBouwqJjMYGtdyHrhj8MhysgJGWd1GoyX5MQAbhSbuMZEaw
XOuUtXkWZ4aBD0OuIK9m5ipOhZTIrY4WlKZG5vWDtuWTEI3W+hImwACxLqAemJ+V6sh0u2MDwnul
+EeLdBB8pEZp4r+OOWWTVkTmoilnjZCeWt/8HzgWglM7/C8IvM9C6xE1SE20aooqK7KaaI2m/D3Z
RLtT9JCTbM1MGIgbrD3NPHlN1NRf7Bc2a0gQg/CnBkV/UCbAtjR1k4J/cVBy9DIcPzOrxf8iLrwu
NuRoQBDsTVL/2efbharunY3A5YRFYqazCOFRs4y9HPFudzGqMiDMEoV+AYq+OY4xJT3VUsLcdvDh
IYDy9KFBN6Vwga3VyK1gTG8NzlmeISkJ4ASFsV0VCMMI3kFj/JYdjK57/hs1LZQEQL4AUYa2+RDR
+J5hM0TFUWUfbwkxW7Ahk2T9UKzL27sv9WGrtpb3rA/5HEIAOxI6AoRJEqz5dvlkrvsq9QkzdM+k
NnmUYtjHY4RHf4HJGl5lLTfLc6sFhLWx1oA6lMnQox77AR+xO+8c0sG5Mp7H/axZvVrK1GMj1RtX
+mXPrRc1+bRxcyrEhxsnlP+S7/oUGHZCNRVTDFKICL0cLScvVwXyULeAVEpX4/5btioyVwY7G7ZY
sThcnXj05yULxhQsnbRhNBUTppEKkT8tsg3wKwCDWVEABoib3XSIfP8PseSc5ms/FQ+Q3/lI+IzH
BPga/5m+5+JPtRYjTfP1kVKvMwqAx5ae1USvjz6QHSHd4nGv9npAr66E9VLTKtgteD27Yd8dSk17
U9Z3FVrule+4LwNbf8b8Pz4POoAcjpfnZUCfAnpE1wmK29uz0rYuHxwFJJJtEt6sI+aE7E+SDCLc
JsUGCyBf9GZ8UEVwIl5rLGUtlSrvfvJJHCzBc7lqVziEp2dyymjm3bgoSfrYtQQXAYDbBHY7mfTD
MlCSuQffDHrC