<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/Oii/Kfy0VwD9ucrcW4na2IFxbv8SSzx8MuLka4i+7DlK7mqdWEcKHJ8B3vRFcwivWTDJdH
1KCC/MwN/3f1oEWK21S7zkWJaoOSI3btuCqoKnmgwxW7grYsBYEzLE7SSP7GcgLikAk6wY6dL4j5
RkZEr3FkGdkZL1zBn4TuaDx3uGvrIlnHOtjAIxcpEGh5OKhne1GG3OmHltskkTAAs5ZzNLn7RskH
avdBkYMwdCvEomwr1eGYhC/Hwq+YXJjgQEKExIqRXP/lhvZxOR6zLnCA7Y9fv7arbNoEzZxSHqZn
0mXF/yQwddkw4/SvMLj1oup/1d+marttlDpY6em1LU+2vIR3mBJUksdRAjkoDpWQ3235Wh6zT+of
5gZnOBJ09XOxR8EQpzLThbnnao3SOdOSEdJGMizg9ggHIfI5KxIGlmLC82PHN1+sEHMvw5Qowscj
0Y2znYW+45MsXgbp+xuWBmkQCrKGt9qMu/9HMQtAY/v2ExAYOfscaNeQQiP5M9kwDkGLoTqB8Dak
9CNAYcYLoj5D2cpd0nMal2IlFT8lyAkCmNlvkYnuZiooUzQ6phzQYUhBW8zRwEiUGE20+LkTfONh
MX1XVhTSUpOmUSloUaCkyxSmZR/3cA4/N1D5WBq/HZGvPgRl7iZ9AnntSBij4UQQRBWTmFLVSQ6/
N7taNgQwjTo0FKwm3fnkYugKUzbUy2tpOA0uPYyjZstNb1qonLcQk6k/8s9mjTR+v4UImB5yb4T8
u0hq6/RYx+rh3DF8k2f9mdyEf3swGK6wui52K87PsGKD6+Kib4c0yxFq6RVw9t4vgn/P8ArvKQAm
zIOGRuMGNYLCg9eOpmt7jHc9nfo9PIWRrf7LcdPjZDfhHD2LC2T4bcIYZAuT2UpLo7hLJs3iRtll
0yMFDKNStkf8/i61vpOcU5IdI6TUx3xE1uLdU2ZevfIm3w2zmZ2TTkacwp0s2WGfYnGlN9BSrFd+
/PsiT7PMIOxZHnc/4lKx/B6jFp2SMQktwmEsjjNEbVn7XP75O5/coGUBgh2bd/YIArgA8x/u6DOs
hBPmiZwAUORLEBd/pBcpbDEH7XBR2J//dqbc9OnTdClOd3hntpUmUgcj4za8aBLL0eLdqxGjpJTP
zDu62ma/s9flSPVGxlYGKxRJpftKuJMoubQe935owtUqiPDpYU5pOwpHhsUES2bQSR8BIk6dOUxY
NyQtGuHu+pfThBw6VgQt4wJ5cZVOWHyXHmFEbwpT4SAuOeG+JcJ/UO3P7cBUeFN5Gptg0gTIETd8
H34AXjuzSx0SKVHZffaSJSuvTcGgsLir29CeOWpI8sheYfuZke78Ic5XQ0T7gj5ZdvdI0J4FnZbr
wPFFztxUdBSCUvORxu5HE46V1bqmQZTNyDakA5iYA6LsJJPm275tN7CpOBKqsQdkew6ge82dFcx2
N6jn/oJcaN2AwOufJtC4FpwZhWtbg/GK5Po8pF5DJA0fWOP1bb1V3AtdHfhvVz3DBp5LCgxhukoZ
uH1UkCB0tOi61J6871kmpxhVuLC8K3T50aSxQZ58mNauCvh0DP2ENyAnoW0dc3IXc4JToVL+CvXd
PEJjqobn8oizyUK9kLVJ95PXmMnk6+Gwas+o+Zi7CuG/yvXs/M92EWhZP0HMHsBmiH6cIt2moQlY
2dcWgy9Uo8SKxrTQElobnXPZDNIqvd5l0UNdePk85dKhS7jPu4o4X+/StMFFIMK0Vti5guXSMNsU
2yW0Yy+g6MKhpZzhMnVU1+QlSHkVTutUGXe/+JRqdQOuRlh1m+f5vzRb+VtkYcbrBnQUt/lDW4gL
L8sNhW54sla=