<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

class GetNameSuggestion extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws \Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["NAME"] = $params['searchTerm'];
        $this->api->args["SHOW-UNAVAILABLE"] = 0;
    }
}
