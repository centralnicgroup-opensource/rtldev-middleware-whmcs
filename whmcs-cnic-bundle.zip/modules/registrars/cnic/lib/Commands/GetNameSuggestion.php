<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+0KFzbE+uCU5wUg+XIH2753bUqj88htnzk6R65Sb4bcjFCXq84nc4vShTjQu55V+wTvLQ/v
jBjbydIXkgdiALVQpyvbm+56yvNZFnjVEjFEJi9r4Cms4Y4VEAN60Hod/vysmvf+SAFLthZTygaG
VwGgY5/ji4clPn/GjOTmr8NVwKWFBZkSuwPbixA8z/MjaRuZVkt/gDu0K3cqUXVDprQJCJf2ZUEl
J5cOgmdn/3EbJObGIdjI8LJAv1gjmFRGrIjG6B7/R3uQsGryYXfCcmOogyrHR/xFzlLYoQtIIyqE
qW67H0TVTVZFAC/IXC1BfHnC4TLsyXp8IR1r46suDjfpe0B5uOuqtUKx7C0XGaoZEcsk2tJXeEhP
nftdS4vfZKC0udM9y4K3uUyH68HciUONbjqFnj5v/dlcDg/guUa5lmQLQQgnfGW3YkxKcotJsUHT
7XjWI3iYg0qCXNBNnAjzKSnfoV9BKl4nkbVujS34g42uhQRBuefhGrhz45q+9edYzEPt1oJicgjD
zJW3gAU67Wo46ekoTL5CSBRxv1Y4Jc2zISqdU2r2Xv6QgzvFvZaFxUD5HPBASk1qAuDaK4s0ED3d
48+eGdgM444Vi7xxFMV/B5xr6DeRxOeM7p0uGy/pqPxuaFQMhNanDTZHVKCYoNoMlXlt9ENaEze7
nRNRjVwtlNkDdmokTuDdhp0cNH5zzS2zNsEgj/7C9uHNJ2b2aUmfoQtusy9Ofom5wRM+B1a0LkB7
kj1T1uVwo0kszDV0w9cdYpTXCFjJFhzO8YhOPzOsiscY7HoTPSWBzZNUBsnDDOzVnt8/o0RMvjQ9
/ewFyzNzfTZd6l9dCyDZfdFPzxsxdzGKSJzGoBZgyf/67WP0xlkre4VpfpfGWjVzp4mK32EjDCww
lMrSiqftQMxL8F/Uuf2NMTa0tSUHQKCoJgGaOnv9kIFjTt3T838Yjkyj0SLrXJqPjPWTYZ8TkfXk
1lK7hQlkOhlwVIbMepN0IEXdIY/PEztGuQf2RS/XPNctBnWe/JrwLShq3VvxpyPoc56RZqFFIajB
Z6T999HzUYNak59uZyG9UNujZjeq+CFSSXBVCFlJjC73GPVxWbfdVl1C7xCSzQcVpPlNor/eiGhg
vy28cOd3rQ2ly543Ss0l7M6ROK/LDOYI4Juu8BLiFQHiN2YwjyVrPXknbNyMMzukXOSqSgQiZqH5
NdItM7u6ZQ2BKSwC6Dy32+lzGwZ7PwYNLygjTDJm1ScSmrg+bQX0FeRF6ADJPtDYo9F0scWfyUd7
7mQO6uIXaJc9ZO5/aDh0d0//wlS/qUYT+gnNAiZoQON5OPJE0YnMeOs/ymA/HFyE3PZxkYuC+0JF
Z2fSD4Iuxggs3FvnUuJiyclpVEdEr/HhYNU0yQWY3zQ49JA0tfebcG/vYnh7IuhJUysEYEIQhuQ3
j6sjetEJSRo0amGdTBHQGa6UTENMvaGjPE2yaGi8i/z73WuK045SlOE4ECKB19GWJ96CDDBd4syA
RleBqD9BK3iq/yHbv760iLtL1PAX0WjBSdcw6yagK0IGyP2e57tGCcjgudopYIrwss9KQOlFuv5B
flNlu1/dat9MEerF9XHxLkftgU0sftY+KuaMVnGjtAuxPKR0znKDTx2SEAi+jN5t0be0wQitDGIB
u/m8Ra69yoJRdKspxbZcFzOH9jsfg9wv+VRumOtbK44rQZ0q0owrzioy6Z+vtn5on/+N/8WbR4Sz
aRWZkoL7/bEQ5RKp2gPQ9xtKJUic8t7NhVSDBaxzru+0HV1xGHkTP+Bzh873w85CrbfylWsI9Z4H
XSmneWeSXLIpi/cL8qI+w8JLd83WqzlcpF+J/AH6VswRJzxiQcDyzOYHqRaGOoCSqqZmWXnSehwm
cbXYXc/GXyW2UtfjSp+DkK+h/A8o6ZwzR4K7uYlHwLlP8utv1xrXtjjaH0bLqhq5ht+EYyG5h3NO
3m00fwxQWAF2TLuLT7NT5U5Ytxw3E5qSCLbM57lMvu6LV/J9Q3JafBEu7JAbL6YbaqnFTMDeqYXB
KeoK+EkAINZKSvQrUKvMW2H6RWFBzp6lzeuD/8nVgGdxzBFD6rpMLl1URqIpgU9OjxDtPtOM4Ccv
O3QMl2u6bLo8CheJDPoV8DTT2kefSjl3s8awzqkjxdf5Bqxn87n5DYBQ7BkwyDDWKG==