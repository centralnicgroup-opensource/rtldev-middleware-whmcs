<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzgMDjD6UOla7oMZy5Da76cOJJwI+NAnA/5S3zNEGzz+UsClr/jTiOHjVhXjahTtsugz1JYk
NFqTvPdAutMfJ7netiWQZcYEMCNRb03fKBU5TEawGxeTh6r9LkwF52X3YRC6XCZYiIF9TkzDH7mp
k8tPakH5CRhf20NjkGgokViPhb90XCkd6+qMx2P5Eh4V50+cIL0siG08M69RjX71+sl2paV4Nm5o
AO0BLI69SPfBDioTaHu3szlGs3giZQMjbAnPWljO+cwyECSWxOCY2wa8ffCoHMag+0b64+4c25et
Ye6wvqP4nJWkjhpIsjnaf881Jnv46k+02NbUvAlUwtOn+LlJkdlJYTHm79En0M4k/sHgIDDmP+pk
xaBBTAPVUJFCTM3OPfteI+Q6AbvgWKert/bgtuUAX7QsQNiMpmu1uYyEHaar9VRT2Yw4XyzM8/W8
jTORAnF/8VUYmRlqtlJWHBuT0XrmZKvSWD00/7bN7UuVbLNU+8eZfs6j/O+P4qjr3GVAKM2UTxyM
gyNcdRfl4WNRXHULcPwuA4/j4GgWCC5G+tBCKix2a9ZNAvbURp7OkyGgKdBcdFhrGOWJ++IqaQMl
+3v7KiKVCqcoXojQtBaB3S4bzt9CQ/Ua+6DhzBgLxJ3BgWZ1W7Rf4V+LZwdsmYToarK3bOuSE7Sz
wdLPICKZvO09KF5HdCIHhAts2k/sAOUNWX6BhvS1tnOPCKU5CiwuVc8Mg4QdTAZVC5nscByhtlH8
6j3ew7EGZrSunv9/g/byhHPdZ9vPORRmxmhVeRJe0x3tQc0go+1uVtOTBaIKL/Km/hNhCOH2+NYF
rt8kbE76peN+l4dOj0bplz/CdqBCYM5UX3emvWDIEHnYE02ytlgSGX3PpSl1eqb3WtH3B2xzOli1
OW5udKr/a/OMIoTjUwWwlH6v0zEcAjAyysLro0S00fnZ5U/mgCvNymDWlgrv6/49qc+d3ToJ3rmO
vp1s5L6aJkR3iITak9oWOBBkqXBPtgwsRqpYbwAeTwCr/83uBHobYiqkkvEzD1TqDi19B6d2/eMy
7acTYynQ33BXkf+j3PKp3AWcut0t2LMkzTibeWZrEP/PtUKkySd3pcCavVg0ulKUYwueGanoFZhu
JEUV51able+sz4msjrkRyeaCZgauB5PTNtvoYiwn/tPX5b35hYFlLgIMJBdeNcGmRT1HdaFndhTz
6bT+S5DAILfa2CgbTfhHncLdFaiZMl05vOw48pH69Kna1EHSDgheX+9eEoFsLH8wwAFi5xWbOvDA
90bQncOE03uc86ldQibX7q0BgNGv9mvO9AjYkW9Ut4U/yeUbMkJ/9CGsyLt/Px2VDFbs2m9tBRfI
NbgcFHJTWLJICJDxqi1C1UYe+XlAZjImwDuOCuWjQBJ+Fti21jo0ZAsBL9EGC8oOw0pA70TsRedD
me4e3Ll1UNdYe3OhHVh6jwkAiwPpm+Pk+a4XdRekCXz7wTqVJtlEuslQY5MkbmF81DPn1fSJPmEd
hRlhZgvKOMNzp1VtxwR7I8cHY1Utn8ueQDlO4LoL4ufEvHdWmlKl4OG7xrPnjEN8ke6C1S9jwek0
ojIcJ1ZQ8CRZ4azhv7o8DUsKGt5scD7FVKe8wphHL3q3bMBhBrvX4aENRbj3+R4AQC5Djw/Wwqlv
/kbjOrb4w3DQvqCImgf/8sYllipaDH1WZREIuWZ1MR/NEfIAPsAK+qic+ZxC/o/MVnim/I0QYYH8
IOPTmSQWNeWsYcwrLflExtrrYYnx5ApqZTif4h3z6+RAijS3rXFyioBs1NVlgsrpNPUGFSBAwRUd
tCGY7WoGM8FW79PCCZc/U9mXYE//HdvNC5NrtFTozg2LfTAkUhWqsKo5/jDUClQu69gJXs5iVvJE
kJsC4qXQIGagigCPC3Hy+TxT5FAAyIAx9Y3JspLtc97LFZQ04NurUF7GLI0b7hZLUOQUfqZgg/7d
4Q0VxHjZOOrN0ouiQYYTzq6NNmHN+aASUAQA0iYRSw1mHd3dy54eaM1Z1EnoEieuNsrAYVPRNQ06
5yUvlEqs0y+4wDxzvrev7OKzOvnc6naAH0H3zl6ERclT3pKvYIBW3huLr3Ty/yLOymlBIEz5EZKM
/QSHi8KtZ6q8woSF0JGoN0EmUynj4qea1/obRT4Sl9sv7Eq=