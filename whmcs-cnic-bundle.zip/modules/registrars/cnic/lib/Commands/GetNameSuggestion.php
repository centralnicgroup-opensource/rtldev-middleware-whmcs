<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq1ZDO7nmessZD2WealbxbslOXbTV5vyHCW5kyqBl0BWKHHsV40eIKa5m/yVZaXNPGMYd5dR
zXoJeie5o7zeGo4EfTTNw+b/jABK+0aqsi+GQphcKvGegF0otmjZ5fuPRijl1xNW5ynbIOImkBd7
a6k+1gXWFd0hqMnOk77lmXHEADZrPPD8EVYVRxk+okN06qKXUFohAcpYtklpJebSprrwtt5AIXZ/
8OCw/IE8zLmWi61FhUNgk1Ubn+fLLzeEB0GZQO0UhFE8wjCb0dk61sISd4jQEceM6Ne3AjBBgojY
66ZLvcJ/6owcjE0zX9b29zaTlof0+1homl8j3/zCWiSlDAcXMj9OrWVNMhrT7Oo7L88nB0r2kc7X
WEeMq7xZBscetOLsIgmFmK+TsLvLWbom/k4a5ixraDn7soRMlehd7SJxV1DOQwlVPvhHQvIU8pfA
PwbQD1+neDOiL0C9EfVW62sADPholYc3DClVeBDTubBvVkBts7fyY491LS08jpJf5XXPtvrEsjPJ
LgazI/2aaXae4mhzwxyzm7ua6KKAkA9uZAa55+ELHhtcIFmF9vsp1uegBnNb8FcnGxdtoXF44t22
gbcg2j5/OVhx4XUPxWRRFLyUvk25/nYkcGqvWf1msGJr6/+atIG3YzfwAv41DSLhnnWBobEWQOTz
IKpUVWlRi3awCHy2uVpe8qtWFqm8HXuqqTl/CLsXVhqddt4lCZZaZ59cTteokVm6RxM7Y4XroVh5
vZx98MRQK9m74rbXqMjVezFZVd2SKwjh7XXg/whpuBcnHNq7Zp52+qeiJ+NuyHLsrYLnMv2lmJ9T
RYkfe6Pp8eD/vUgwW86PSbnCKroDDW5eBHJDJcFFNPR3QXBKINMvgBwUMibBpUqs0lIQ2lbAFfGM
x9rOREwJ5z3QmASuPRljIDT6H3SAew29hrswqy0FxVZZ04UgXmUk57LnwNYqemty2mQYeoMDS+je
3GMOiu0L/pFieBrzxN/8NbIfShaB+1IEqrB6UB88iUV4K/8ZPyR9AGqSOCWCO8vER/Xyhe7nE29B
julkFzVv1I4Jk+cpgFMdoQlr1ItaY7vTxCOX9d4iE27fISa/sRlWm8xsgiq6johLBTm/QaVl7hUC
g2OJgsVkp5o9xyY1Dqv4kbGvoeg9BfKz16Qk+ao2MG3YkQHBIVbOgoaZTpZ0jPU90LVkPsBjksQg
SlRSU5wjRzS+HsDJBTf9UfXl5OAktT5eeo3ZzBuidRMJwWK3+2UNUs5hDMe2kuPAPAalTXqzT+vr
vWVmfU6ekhfM2Z8gJpf7QsUVk+GuvtLRQkpToTAq0jdEb3ZE1Ka4jv84me/X7gWm9z5rBuG3VdP0
JN9H8H+BNmDFiXnkcDVzU7Ew7e3GDpZkfm/zBnd87ToWAw2uKn/WuQYfa/hPI8JttHtojFaWE5ia
97D4GXf43HTQede4Ky06YfNKyszF5szJJ3LjjPg/TyImQJMQWb2NVyIRuKtOq4SV1sB1yvoIQPNo
96W/6xyREw4vHAKGgueDyUyjnT20iRc76RXxqcE187hyoAXuRvOJ+r5yfioJRz2ALDYsq+9T9ujC
uSG9Za3KPR6PgXwAH9MOLWqmgA9d46AQ84EPnk9n/pWxeOe78uzDhWeREnzndHnJEmsX1tS3paAW
LxD4RtwSYLGq4BaOt0A8fGFQRztwb/skJzKEBXyq0Q+qsTV4e9wtrEPp1tWuXA4SQJqVGXPm+C5z
PYwkuXnF3BNJYHlqLXcLV1Vs1IzUcv4Xbku2jQfiZjNkTHxMfc51cYtuj8kzWzS2nP2NyJPfiwJa
21p1eehv4sLSPsakVSV5ho0wQYmKsUr/6o7X89dAcHqPEhQo9LqAy5fFhM+TUNaOwFwmI9xIIspU
pUDiLRuuv1rdZocGwqRZ0pcCLx5naSjkV91CLaMoi4+HI6BKqop2EOQ3xLw/zkjG597aJ892tAS5
QMP8ZSI1xBQoBWhDvBiqs9xEDT+OCcNFGD3vmXjCUCgXeFTCV4VXwc5NNBuRlwHfmUkMIcVpXuE6
Nx2DBmY4Q75qEnn+I5gOjGd1rZxcd9e0jYq9DyYsMnEwboqd5AcS2C/wvQM0ROD1DvjGMpeDOjxj
2qflxOmZPrXvRMhiYjnYgewB5NZTlkoh+NK=