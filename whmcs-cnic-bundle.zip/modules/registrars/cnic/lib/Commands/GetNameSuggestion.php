<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnj/oAS0nZ28tSnTXCbgD4nc3vL+GP3C+8wu6cdWkmCKzWLfwgkCPBakzqO5OAvm+VDMVgao
QptpJm2SnrezBQMWieRvCCeMjewY6y+yep6TN0jO27yFWQFRNA+wrGjBDrfg0R+TMvyd5dANRtGu
Y/q6bYXX2IkNhSEekpZac5jMYMCLucZB4D7END6D7oKJqJOzW3CHZ7NfKRll6JIk768U/EVtuPzz
yUZgEP93NT9/iJlJqxfOVuIwjVlpNP4xFZhjKFHTFJwo43LofB0Qo/2MmnnenVK0RMDQ2pavyuCz
ZcT0V43cvNzTZRgRv+Z/hnSP6jUc6MKWsWQnz5Mjrrx84gqtxL/HD4hRMd0T1S9Tkl0cfvdwhuQy
72Z3QVgdZtNfHnRlwVHJvf6Y8volHBlERV+GM44FNEY+ZPVcHs6ViD/CUm1c/n3t5zWgTfEK6wwg
aBOFSMsBu+cjgg0bYZE0z4I2EYfNDw5MzgT5cDsN063ECyFIu623ZT7VzmekHf79mKB7NEbUERvE
QgPxn5sD/ZBBj1SICeA75c9/ucgRFI+6KPZU7mSYiLZC5167uTHj4xQHfUsPvhcSYVt81mpDhN7x
2tM7PM/ttC0McqRbfaSl/7nWUU7c3KqxHn10nD+KZ7YWisQwxeMb9SCX2I4/94oU2SyScD5ykmuM
l0V25M63GBtVpUClbQq0ce+ByjRkdl8tCbrK7CmLoL/0exFPi7xbuxC7FNx5mFwrDXDLRvjP3/fA
amfLQ4u7I2owfgYzeFvMyzTxh/rfj8n1y2RyEO0dUaGIe+lm5sknFJNuP3wXUTA1PiwLU6KtBj2q
/qdQVpunpweqNCa88jsjeyE0kY4mr7bDWTqaWdIqhy5SNao1XjjMhdgKSqibmzuYn8RzXk5h3H4D
Dol/dzQokUqoxqcBSoOsTfZY7fVtWo27Qj2HL+Nz6GxygY5JXkZFGlXatMkTK0YXCCHTxuCpcHD9
Ibj3PKJms8kQJET1BlyVdEDc1uu13k/9dSA8uzt9X6wjfskqZBVyHIhfONYl2oMD6UcIunP9O4Op
M4BSYo7z58TDrLdEJ7SuVMk0vYBC+Cv1fcS9lWKOSJ/a1A23aYglxyMKDiLk4GOtXe2CUG3NTzox
YGFxGb/UfkEFoYukjvXMzkSzihRvddtVzga4T0yQ3B0TCeyhFLh7OYHpGDkaXYve8+14pIecNF5Z
xOHk+CFN+StcvVNYtXJ9ZSI5nPCqd1c0tJ0X4s93CjAdnmodPvRtjj5qrhv5fAqNbsohPQnETEFn
gkxNiK5HFSUmtI/06i5nV4t2nBBaq/TUG3ZOclywg5I5OOUPBa6d51jF/5h3hTM6s8yJABzEdKzB
/TCXNKEX0Kn71+JOCyBfhxOogXc7z71ycuceMxYUIxf3v4zS+huo5DlyN2F0UIRN4yu3PG7kgtAu
Q9iBAZ20c7xak37T2vCd+fH+NCK4XMy9OO5g8hYOtR6vU0obp+WZR4Tc/eJWqI9tBtPo+JbVrt5B
5ZZoBcOjJEqNnKbX/k7nIgNk7TLrk3JtU6e5hFhTfp5HYlEOdp9KtLNNp0eu3t72AVTyCwQJMoy1
2kiB8rJQAQZ+NszruNoK6pQKvTU5RAPQoK1Tn0oiwjjsPdVa2yfrpCmQCtMQO5UWPrWneFi85/ji
KrQzdqk6yxWRWOzzT0A1gKx/YFFGeKWIb+Y8lMMljWiE3zpB6Dxjb/8DiIoo5zK8RzJ+kry0DkOu
Audpsg6qR4Dt/U7yO68KdjYXdbE18j2nH52apRh8VqQjSyzaeYL2+Ad5X+GvgAQn1nUmnKN3tC0X
HMueKWBULR0HEbp/yzLEXiRUO7v/vc6mHxwhsckjphuwAU6G9vkGDA3QcSQ5AqzvbCgEDo2BymHX
C6vzlifmwhRxiu6dSy+oQfakDc6nGOZYuVoK11II6kV/uD1oj9AgvGbtXnCOnsTBRMsgNM56kqTE
sncDOoZ1cGwVp6wtGMzc0n+hBb/zfztJGwCCVGIfmG7r+6D0PkAhU6R4CJ5GL5ue4RDYWArsPYNz
K2lmt8yrOiBQ9gL8jr3HrapluqTc6JdCI1UpbmblSwAGmtCQMVpCXSRwhwFgikzXve/sPk4ibRMa
5ru3nqJwoI09njOk+CnsPBSA5A0xKf3RRQkZlqpEjuO=