<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+mxxYz66jC07uXx3Cna2eb42WfTtJaUAS4CeT/fCPtws7kslOwZrHg659EZrjIjTpWS+tFQ
D4Sqzf+7YS/bCKiG7iGfmbBOPO9z3mNc0HXu1cy0AtoWCIHGbhlc4utnqtpEp29NbaCgop7oLAI2
PlxYyGAkYgMUeYqNfzXAXdkq520o0AvjpYdw7O2pQdqGDMyatYR8Mse3qBHy9XSD+enSCG8Noo6L
iLXiP5uQ5u08nWQC7TzQ84koBz/LwSCW+q8FPi70nj+7fmxavcCZy2lxBYlnlYbZnGmYSjLzZRXi
b8z2WiXS86DSxaDcLj5jztCzd/MOATtLx/ILq0UeRG6XP5msQBeMd5O59tQOkVyCDSJBdq0DJR1M
uYl4WAGIEQHLUA0xpgqHbxchzAQztLOeuuKd3uXj74dME3fwEQ3Kd7G35eH/JkCCDRUmh/M62a9c
0V8bgJkIvRBCKjW5SYVPtlw5R0HML20SmarXCg6QeI8dGUbFBtDqUiZaTB42uNSRtdu0U6uIO8zE
HxE8KE3Mw7X4aTBiWllQEKc2B7vxYlovCdDSTYrhCijYw2qhq3AcFWb15/K+6hFoTnrfZvLjBRCc
BbS/0LLVkkTxocS7YPlSqp3ku4DK89xjEGVlfUuG3l3zISrGZvWvbkAPK6p//4SUyebQ5sWlHbHz
yNjsT9CD3UQyH+nYeBr9kaDG1Pku+C2UT1a8kPHt3EGYSLPquIBib4kNhwM6dURI5cTPPgRb+vhF
9w9dvma0wid5ABI8o87dqwvbaydPNniNyqC+ar1v0n/k6jc9bDDml5kV7iBO2dx6oxggsiIwsDsl
83Jsh2CX1TTdz84IcCtZdaKJJ+7z4jY70/CseSSl/GnNGNHZmDo1whI71whducmNn22i6EO6tDp8
7rscuOO7/sjYQhIe+TGJXUmC9yzONsIPFsvSI/kGo9RJhoyNZiRnhmo63KgMkI1DogoJ+36LvyL9
fOAD0ueuR30IkV0qFTHmTV/v/lcJ4+/0sViOo3dWfBv4FT+O3+KjrI92tPQ243949GBN3m+Ni2Nr
LaarKp+tPdSqk2BMAsyxSCVIYjlWOlPyXuybfT0F/ZCukuLWfbN8jeRhAChGWKRfojkmGw3qxLWW
Lby/nRkfiBA7zcF0Yx1kWZ1DrOtRB56t56nnx1QmnVvh+fAstHEhs2uLDJ1RtrqdsFGec+EDTbFT
xIw5HkHAAYqxUzGkot1Zn5XHCYocfavW32vtH6MjBUDR5IvXtVGMly4cIKIVpDReK3Lfz/qZk4HR
sMyA0jnd8fY4Hj01FPVF5sw3oCr0mXKKadkn1Q8B3WJT/TvhiH44PM3Q+Su02V60WZlxGEJzne2S
7/K/0e3+e8BwKKNXOgvE9VfcrvhwDILUx5T3IfAYQbiNb21re+TxhySNjKyd/ZsZEMS87StpUGqj
ZzcShPgrBcrIr9mj9p6ZCHGxyl8e9YQ625uoNOF/aDxEYMgYyuAnOt6zjOAOuo87U1hNhEB28hHj
wgM3j6VHxmg3Mm8+n2VnTuj0mjfo44M1BjkiA8A/vCUVQJLmXwFXtD7xNMGDt4llnZ3GMwxUJ8O6
Yl/NMHOofYZsdcQ3GNnWPEbuyhAUyPIHN594c04DGwDilXZ4zBxybpJe9CbZaC4f49KLDz+GEiXW
h5aJ8EZgTr++WTEuE7qLO/AnD2gjbJZiso+7DRTVQNtw0BEqjxJIYt3phOoy4Cs3cyMMjWp1szGz
pZKAqWcDOaZBwmo++xYUrWN1GPWvKJTxNjdTLN3lLd6Dgrwu3J9RXJg5W/VC8i+x41co2qibgu+l
PNz+Iorc73ryRfvtmgUFJNy5deMA62aUYVkwQXEMM50LytysR4mvIeC9HGJY2VMKyPSRYhQZo5+u
JlINGQgvW5FAHvCBELgRP7aaSXYENqIAO08asyPTMhmZnvYx0E/Sae5vUOKpTpWFnrmeYjMzwztF
dMDJn+2WWfHLBE84RTwFfRfYNR928e2xUogETosEm0UvVfdcjeK6wupM7DI1fnGwykc10UywJMhq
kKNfnMaTc6JCYQ416keh8HZpBOcGhXODclTJWHA4SHyiSd5/1ed3s7gbXCjpQKk5wB8pnEly5pwb
/x/CY/3FgOvmHi4vroaXrs0jwVASzq8QMiNwuw0bT5whiJNeFT6ELTRy9xhdLnB+gwt6Rrq=