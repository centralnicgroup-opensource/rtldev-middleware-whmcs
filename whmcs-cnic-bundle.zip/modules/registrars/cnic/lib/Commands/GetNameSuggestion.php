<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsf0xnp8hzDJbVDwFzZ/XN2mQ2+KlBuWB+m60mAC+XGYp06aposJJu9U5cxU4a3AHHmHi4/c
i/utMKJSsMFdj65ytXDa/H5IyQaaU9jfUci5RJM1WGTJtJ8RhvzFQKtMf+1gp1/RvumIsPlmzNtD
C5WO5PcrSIxRJD7087MsYYhSfKjEV/gGmNF6SXh80KRErw2HIr0Ghl8FliJRSwcqPoh0qwqaOLEX
Tp+kZJGhvCM7ywPvbeAT9khsuWWvuVxGjymFX8H5QM4BibGvDFIXHeienCM7UlzbQpTLk0dJP3he
JuvtkKO8/xJtZ+3mKA58h2o8cezl9tItK9iSA7p4H3BjbAAawphOA0y+0yMrJU4oNCV1COCp7sDL
0Ke9aprbmUVWenbM7wVR0f8E4qtMlMaDCR+8Hoe4j03JVZrAZ/DmeyRMRPJSqgwEd4474nxW3RPF
Ry0We5c4QwF492gsgwVqWY7tCF2H1NEhpzwyyUPRepXs52DpbMBMrXMiCvR4kRmAVZrw5lD/OpkK
1wm3sTOnjCSYB+9CiewYGQPDkkuTevrBHxklQoMNJD8GCZTknogfrfiA315k8q0Jr9ywlen8r1Py
xdavuUy3JxrLH4aIFpDQjRGg6/HgPqu2R7NSApzJnhfFZWJE0UkNdSNpZvDo4vNQ+swVtrIiQHus
EbzOzS7yoKyr7z1WVpEQUPJ2kz095cRmtepYL7lNHDorcG7zUQcpRLe2laAyVTMnlJ/3wqDz+R2g
KG/N0VB0nXmEdMSthSu4SFjTeaGVe/uqicduwT3DTDfJOmach6mvxilsdJaZd+BCl3aQqaKXBAaJ
DlgzR04NBMpoMNlhfd+evn+hc4pqzhmb0sWTAQerG4rv/73wWJs5U71LPYAlgBfV4aKzBz66++kJ
baTgx0icwKucOLHlO0M4FYqmtDlYpVBhhS4t8eWdn44zduKVDhOccdg9jxZzRagCdUl6Yx6n8665
Gf02PuP7B0+DET3YqQi74exVU7wE6yWazoTv6J2wmp5ER8WzEybycIp6R/yYuaLFztZnYbuaw51n
TCLSHFaW16SstpdCYl6GI04Nyyo2ShIkEBAAvHOzMwLedBgD23wnDmuxnbd7baAVvpSDW+B/qDIz
O+qiGC6BLPJyqiBbe9y2Rk2y9R51uxYKa9/URqccD3RJXMWZVbFzKP6+fR8A3eCN6D3GZPS0j4wN
EWRdvFgUb2yUCP1Rd9JjKTHPTKzv3Kgvdw9myr4CwuWxv0ChvhnJFa8RUvQ4Qth4cRWIBWwW7zEe
cMSjcL0LUcNPcmhPmuH/9i8PV/uAoXQOlvrVPXiI26k3MkYdzwR5CaCfLOssmQAdIq76yiHh2a9I
9ku21uCs6zUQVzhnTIHfpG7km4o98u9eiKH0e6phv6YVnSBZVHS3uAmkXMfNWdZlnsjMXe64yeA3
ASRYRWc0MFSt6s5hS1k992Uf3kkuIlqOz/5uPb4SOSrIfhh8cmB02YmRNoJAwdF040K0i4NGtcS6
iGJT7UFLEtb89CPtumgeSaGCBosJ9CCPTBvywxCe+JgMBJb3QtNNkTVnn88pvjPg7DFzWoeEnIQR
1xXXFlPOXHa49VtvWLqNkVwIVRYXNZKwY5ZLPAyICe1vFKDIT7AMZZ36dWgYQt7cxpAYxjGRdKjx
L+LoEEB1A0m6eL269Lcr/ZLeoHrOyCbQ76BG/QEtGNgbh8IoDy/X5pTCI8/fhWCGmMgFe2v061kW
bVkFGqFHdwHipXYWMTcZ6WGCWNVRD5LzilnFXnq4YpwMcI/Gn/a5rth/AsoYBkLOIXv9i/DVt7Hy
s9DTvTMytCgLGtzWwLjd+s/dnjuiqtwFJoDZvPSijzX045vgZKoXEN2dP+88AEy5FTE1+wAWh87V
UCaIDmsrw9QlnrJT1xWO8Li81XiafrsuGw9jEzYnpbFoC51deEJYYLtbqZ1ZwQN/AIszdu0gDUvL
EJlSp5bgXE8bWNd1cmKptEC72JTqdcvZPdVhSbUBL+Cg8wIPQ7KpYSSiN9XsuJ7wXlHMO66/UK7x
giy1EOsp0UYy9WDirMO4ha2dCYkuGh6G8YpJOIinaofJZN/9fbjyL+QAOjJaRzg7o/UppOGSf9OU
kJ+ZYTIgv6TWHCv5eC1WT51bmTTVjqw9NbgcpNcrNs2IX/FUfTMl9X4=