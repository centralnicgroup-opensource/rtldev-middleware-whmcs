<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn09yUOVrCd9vhfanKiMfh4B0sfnxqwkkkaY2Eqz4TAIlajtg9VyNRojaTna4ElfqA/l9gVE
5fExyI21BvUL+elnupvB1QCO7BKD95DBNQGCE341yqzNe1PqGtLCEm05/3RNOGrDjY+FgGGWYqBm
Na2yGGED11Ux4WW3IKTpawLFwq7DSJtUizbdqhzDQ4DbeDJWXXGXifSwdqF+A5Rt4GlBdhFboxGT
G22KEVs1LLRHGzy2JU78x8EAZd7t++je/iKpbn5OmHc7YsTKV51AV9cOMRVrPS54PgUgiiFnDazx
pQA7SKXVh18ZieukmDfIHY1D+Slbvjz21bYNP4lq0y0c8vlA2VE8VEc58Du7QscFlFxqZ3KbHooc
1XlNeIM1TcPzy9JF7pID8j44Tk+HdnKqVGPDNEW/W06SDhSABXg5sZ2ueGxflMSncDqA/k+ar1L+
Udz5ls1N4+ICDcf3gaTtXbGc3fMeS87xAYFEHXGATcDqxt6rS4Yu6alG5oN/p77yOK9UIiZhmIB9
EgLOZ+M5uwseflIMSDxF1FiP7eUIMrkfLIL3rnby4HiGhy5aGl2ZkyR9VwSWe4Z2cDwdpTuXcXia
V4YCe8a3Okm6m7G0YxwOjttUKx3WHchiyiprqxi/rX8MFtHmo/1VwmPqEYWIDoJAVoyoyhSfNUDc
+aTVWAnJI9Q9yEAbva8gWUn1+A8epNDjRgolRFB0QUwnNagrWLbzOzemwrpJ6cilIBypZZGDgXoz
ocrCWdGWUdHTPyMU53uIi97uxfgsZBYkAYY4ui2qad85+BasETC7azUvLkohaEuzxObGsfhAnjYu
qoP2MbIeTLHSN0VvI6/IxUAkfkcSAPDKMEz3PxVK1COzT0ep5t2/RfSPp56kui9fa2I5Hw49hJNC
lPbbX1oj8H2DKRarNyMh82lIOGCkNKDT2Yb3tKDjPNXUaVG3qnam/Gx/pMtQVfcVSoOJKeRZw9gx
5J7AOv5TNgazIUGcGs4u3MxE1PymZs2DwcWf32PRMI+FgiFJ0Zwyhy5iG13dpQq6YN5PjBqCn8mX
KGU3zvo83M0QXIRF4JU1TKp6CZ5h0V14gGUpzAnRZ6RqgwYxUdn6yba/xUOD2gv1//UPyk8Y1nTj
ThnD7JhwWIGIOg8KyUnkruVo8XOmV9D5HXJfywiEWbbdjgTWE5oNR7nr5+S7nIvwgmJ4R5cwWPp4
Sabr7/CtjtGeaNUW+PRtkNBFoS5wYLUBZO6Z3lRRV6JuGxe8iBHvxkJ7/nY6n9KCITIj7jNA+mHd
ugTGy1FyuvYUMgR8/FgDDd5vXAE1Jdu6rPKUXSbkVqRskRBk7nLOrGd63jSW00l+LQbPRPDFTtXS
Se1I17noLMeEbUdthxmccTpp4EBmNr8mlA8Ll0VhLgN/DcLvQdOvBtv3rx6w+bb0od0WApKGScHU
ybabT28ULO/NTZXT4XY58dIfSHjSpgcxFTlOHFG5sYtz7Tb/4kBZXwDeaCMhZHqz6yXhXfELgEha
SRPeOwXidWT++1BEfpIKX0Oz7Y/ndb1iGIS2PB/arQqADquWBbmQZkqSPqMa+7Ucfvrp0LTyy7yl
k7NgXV6gNnKToxg7Xcy2AaS0M8rD96wM+xYMqfklv0vOPmOP64VnTJuXTYoZX6mfTHJxtcPdzYcS
tGH6sUbNDKH9RY3IBaW3HRMDbOLOtbQ/liWj/pkpFOL49vXF7MRsAG7HD0Z5IaOPgWZX8OnbDPX5
JZFrjXqTji70xqLapkfm6QfwKpE8yXhXadhWjve2EJeNlrycR+cx9JxUNJEECisnTNN5bji250Xl
n532A//b9F1OnL7k1cTbPZcdoXftcz39uu5kDu+nYLhWRyyAR0Fwm/7f1X/hCC4eKoXoTpiglkvB
i65/bD0WRDVf3sRiKRK05zxi+EkRpXXYT/Z4FKK1grqI8KMZPPiXOAF+wMHRfpOJx78029fWk2/r
NJ682duX41XsZBs4jltMB3fWNhfpVavu9YMYZgxDl/B0C9eOpSbO6H0rR8R3ULA0R0B56VIbjbna
t/Jki2rE8PCZGS1DEyYimeG6Cad9/jY70rp6PDTiL24kIarFcZqSsTcE8sSddLWw5OIfn0f/jb1N
dhmUHdtFv57QYVqvRKf7c/v1bVN5jebqEP7TJzyVCb7QB91IQopyiQsl2hiAg+1X