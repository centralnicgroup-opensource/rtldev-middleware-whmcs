<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

class GetNameSuggestion extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws \Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["NAME"] = $params['searchTerm'];
        $this->api->args["TYPE"] = "SUGGEST";
        if (isset($params['locationBasedResults']) && $params['locationBasedResults']) {
            $this->api->args["IPADDRESS"] = \App::getRemoteIp();
        }
        if (isset($params["suggestionSettings"]["tld"])) {
            $this->api->args["TLD0"] = $params["suggestionSettings"]["tld"];
        }
        $this->api->args["SHOW-UNAVAILABLE"] = (int) $params["showUnavailable"] ?? 0;
    }
}
