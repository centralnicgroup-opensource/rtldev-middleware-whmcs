<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpzFtG4wbYKsm/n88aJ71JkLobTQWngwqhkuidQ0tcOuOmUv096nASu0lEpNiW1GQXmeBFxv
bU/wbWSvzNgPg6reqhr+hToJ2Ye0jJYt2Ta3Mwk0tNIE6Lx6IwzTT6QIk+h77n11jCEYiPf/UzLI
7SpNLTbETvW+Bdh7nBoS9as0IBIKKvN1kWTmEi0+DIiu8fUNUdit5s+wJQILv7+Qqj3kPctRaIH3
x8RF6c1Ixn+OewHjBJAwI1MOPD9QkhE4VtDembNL3Aaz1Aeez3//eS++rWzetHcQFzgj4LvyfX38
8wWbsI+zR0ygxVb/JfkeyJur+r0ze3AAH7F76cMRP1i7IZGXzHXU8c70PRopQg8PE9MSy68Hz3Wq
0AU1ANSlmjLTv6AVz4sAZP2zBRvfJD6AvdL2EfEilHf9IR3//dd3HgHBx4v1ZmBxtyasnteaR3Ui
sb0E9fc1dbimjy0TTywF/m6DEdR7BEldADiV0o9dwuobgQktxTL9LGCf4y4U2jlU+NJMzRIjDzS1
u9lb13ByThTTwB/8Kc8HTtlInjouG3SKfzg6dCGCpcWJyX0wNv4ofVJnNjzS6jkYjsY5/qOb1Hvi
GHgY+RW7egyDi/ctsuzXeZsDMDX4O6DPWVCSW6KmgLdHuYUKXJ9WTrSk8ukpBdimNZl3CLGeY6Lh
78AL8pR1usjVKp0PLLJScMzyD9TuvAwtPq0zyQu6f5n6AILOtmbaxoOCqzcHhFyuf9lVb+xFnCj5
IxYcpNBr7AzLzJkFguwMFrLVhXEspbZzsNl1QU6hy8ILA/xktZqCUus8wv/fESbMfsrNiZdErib+
qc7sA9IQPQV+/lYbxeTS6ohNOgd6zKnxgeEIgBrcCaEdLbsxm57ufrtMObP9DCDhnloKQtGstI66
APERgmC/lDqbtDf5qCdAUS4NJcWiuQFvUrx7qxYH/nCfIC1UGoZ+j01LhX06vR51fYz6MXSHes0D
IN0YjfHEFg2XKHQ1II9GkMVAjSUmkR+1kN/5VSBwERQRnbgQ5gvmvjnmpXKc0WgdYS4hPMMv5IxK
KtoArcKU/6omg76lTYL2DWTtoo0LVR3IUJANo8JscUAij8Hhxl699WrnCVFKvcrKlpruO5ExqQqN
PcjnWOI1J5zHYSViQNTGZY3FSfZIRYM6aNxAXmx1e+ols3Xjlw5/Yr9+TZWtAMPiqd4WwkvoM1Hl
hNIzsHxtoBTdeuH+MT/oqYXafR3qgq0/ezcZB0h/2Ucwf5j6Qw0QVKsh0JAp85MCAYluX/uVoHnE
J16ecJWOP0KHuk/dp55brt5gyZV8DRkzOt2BMoP4N6XYva3khAT3D6lc/BrfyFb7eXNQNKJB4sJ+
wWF7ix67JqQpiXbJXg/95DZOLVWUtMYDJD5x/+PB1Riww16ca837VN7tkoJnYl0/KtqJ1JcXP4dK
FsRbKkJ1ALEJaCiJd2fgIp2hQDhJeGrgDGtZ4n/aZYqUEbOxf+0/YMd98K+A5GbznMOZCzOa5yph
MWSfY2kAeZDTlHHP8jzyvNy8LrEeNjyzIHKs4oXqdCjoI+Umyf06YuTw05pnmYMKw1ys/e5UtPxf
4bPRZzGSBFPPnLnRm8ojoSuVerLC/eCdDQtmoL1J2IeLu3UgV4r3Z4PtdZVeb+Iq1fMdO8hLKZE7
Q8WehabXGQUIBuAi1FyMtiTi1Ur2/GuWJK4xwP6mOftFfXIFNW+Vv7UW8emsjch8FX44N1ZH1sQE
MaNUgWLuvoTiAjykLJTXFm2V3H3PXC/u+QWfvqnSoK6cLZWp390Pfse2aD7Fyg/Cp2ONKXdyPrQO
0vdMn71f6pUSHj8P7bA5DMp5HHzI/to5siLD98KA8yhfb8jufoUrA6uU1qFElunJYI4fTt9mbtgD
VeqKVoiI+cqG+J+N/21BMk0KnwZifUlttf8kCAvFBiw4kHScuqGuF+oP68fCVjFlitj96gsE7ksR
Ua5ndjENfXbVltdett2VTlg1WC2NMv/5HFru6etXBLweu9XXYik/02jc0c/LtCfMWNkRBo1H55Oe
BuYjWmaGOOldz6J5LD3MqA9XyWNERtaLsaGMAfCLxHuaFTGNr/PjWgT8rSyGetRwI5XdrFkqY3+Y
QEZlBnvLure7XlHpSwNnsryLGG76GzmWIgL/6PJn1WLS4onaZhnbixgy