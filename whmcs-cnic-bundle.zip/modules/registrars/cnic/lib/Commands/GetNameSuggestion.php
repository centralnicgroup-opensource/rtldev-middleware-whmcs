<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz4nWsPM77X9Bu8MHK/s0TG9vavXV7yTmznNeu0ITDalkxCVxzc8Dyh2emh6FKpQ8Y7gm4r5
0dFlnEBpqjQZI2gSyHCH7p9qQa3AFUJrRZCk/hfgoYcw7KgHSRoTkXB4eCJltI+8prFmtCD6wYhQ
wZvqas10a3/OggWBlzZLLn3XsQ9xeumEFf/20cb+dWOuZ4lkz4qoo1tq1aSbv5fzejK064VCQmbK
mz/EyBQ8HbxGM9duBDqmYpMiKe34UwiRulIOg0vuwW2FAIcOyaxrHkcg39iEQskTsRA0SoLB4Prc
0S/6H9TZ/0RcGT9eCcow0KoPbhjbTwAZnS1ys1eYD3MBcUBZqTk2Ak8IobL6+KMeXbzFPaARSxCq
BiAfmU0fxgsLw3T6elI+AiUvZ58itMSTdrhBRigjo+0x+wfv4HG3WOxUr5Iey4sD8cLfEDj3DZcq
5DsGaIwrbGzffwbeCSlzAC93U9yGgJWkcKPLPCtQPZRR+nnAaDPQSIiqXDuOPoGnTe5i0aUiad4A
pqt3J2IcVBsMzUyl2nYBmQeOjpCzYS2eyIHdqBMXDqwliIAnn/V65yk9vslbKna3GozFQzqqefNg
lVnV+sBVd7tmnh0br/ef2tmsGLTiRSzg8wu8BH/ldOIX8xL6/y0Bxzm2HCTi0xpMx9JJt/Zx0Xdn
agPh3ZUAFkKRgLjKuv46mBB4H3zxHX8UTU8nafKu167l/mqIBQwR/PHemDGPEHaIp6uP25f0ufDy
0vxLtZh77rHXU+lrHKWEVOGQ7nslZxMUCaCxvVPRitun66OD8fgk/ZhNywbGiwcVORPg2inhVcol
RhWe75HlgNkQKM9UyA0ln7Vb0jJiliMS7qf2uP/LdAArYKuf4L6sJMzFpMdjATsy/mr2iKsWtFJI
DRr5C4GkejEdBKbyhQwBRaOv752BatY9oL89DXpeUxwi55jqZTn9nFCKkvreX7aCaxT5iYPPVTSk
bwx5TA0tK5eBxUgTX5VXbe+1rM6Q+WrhRVpKMpjphvnimXBXdmQU/fxzN/YaL6NpfYVzbG5ffHod
Gfu2UrPAAiCEyfChlVHWqmj5wTL1MHa73pSz+B2rDbi1OPn3kjUa1wecq4ip6C+DPCNvAqZl+2Y5
jCD0wuUuEK3hdZsK8c1kPkMDZ0Y7WhXMBwnt0dqGs/unM58o9K3yM98GGsf8d5GipH6D/ORhArnm
hRHQLw2Tj1WmxWySMnFxfnfgQol2RFsYCRFO8L7wsw/SwHWcAIxG6pJsxj9fwDOlTyJBwkqX6en7
M1vUl7sQHgqtkRekIbfIehqrOdNZ24cUtC2nf1jeBrduw/sROjtT4kfl8p0EX6v/30fcd4wS8web
PW2owntZfpLVDaKoA1QH9fSYbB0jk+D7usTZFSL9pGE5tcQ3DJgS5cyCvjjpJjzLv//L9kCJPZUI
vWcfn3cwbRJAN7iqfJyMiGpM08MK20m7ixHgUjMwHCpaU1a2MaYovslVOagaUPypeCoq1IzVnzoU
7ZZ7GuhZ54NT6zJDNHgrAAw7dWgp82ucLoJuRe5gLqAJcapQg9hYOsZktJCBlHJdEIWaH+mpLSLM
I7CCLoFQZTbooaIgJAHoZ2PaiGfJFu7XcW5NCKp9KYyUGQZZC/Kzs/5pMVIcdg/PkfTJ2ID+w7NA
TuZ25VgajVSqGJL0ixhYSCU2Xv4bgem655L2L78abmgXHDNcdHPEF/3b+xcq2flOWMMuFTyD/1cK
FVIXnIXAHaXEOeqAuvndVltSfpjicSgvDIDDcqPftceBDAt0H9AxPBLID9hXSHbuH0+o29C/Ez0e
OSSH53leguLX3HtyinBV6DJt6gCgVNJ6S7shhOjUgAZPJt49TTZTQ7DGArWfMSdrAkPNY5QkOKR4
R1eqoQdctZvr30bghvLHMSgZVcx8XHCKL4oVHPMacdsqFtCXyeJXSJWehZjMoChl6U/gfOzFq5Sd
bNI28SeHVKRKsa/KimudAPNUlC0p4MtMDUWUoRzM8mRouBpCWlVRSs+7BTBl/czvWNJld3XgiErc
KDIjdr4mgvTjLCfd+rMmrRWq4nv5Jj8cS5F/a3GIUZB/iU9S+Q6V76OOT4geDe/u/1YKMdjK+5uq
/3imgqAAsiPXXvwr44wi0i1XxQ7yBBWHN9mtvBrH6x5Q8AEm1Y52lELhym6LBgenirj2