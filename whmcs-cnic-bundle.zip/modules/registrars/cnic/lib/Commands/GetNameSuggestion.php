<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPucjh2HlS1KBTXuv1wFd8Ud/EFX0kRwGqjwY1/hYYyOc+RgUO4M43sgOUkzFmw78DXBdbQlx
1bofMmJJ08i79fBf4HnnYEBjIuFk6bAGlD1PN5z48KGo54seeOau1Hj+11brq/14ZjEH9g7vJ6Wm
IND9BcfajCrTW4FZ7JinV43tB/J2+EIWGNXiHmRxFGz2cZJ4AebUMSkanytoUJXGoccQBPCTde7C
cPpGT6k4R2V35Vy+zC6JNxXSTrLFWXKNob4FEGo6K66hKrE272ZodhOOIbr3Ose6qg5krwg13kGO
LpU7BF+WtMNtBb/CUmscRQAV2NpH8SI8VxJ1MhetJAqp/MScRCNXVYaFoRfiiZO+SlpyY20rCE8h
6GUIVFDQXOSCp3gZO7KS6rB9ymqR9P1oNpcJoTKsB7DTLM+UCLAn5qkLUu8P5W1lhVXly+REceuo
iq6vmzwECyFnV4FFOSwswbLb4/XmD54AgYyUhM7tqkQBIsb4HfPlkxPgLB4l1uqU0BwdFIAb7atu
uYUTDY4zf6kmpf4/7Gr4zGW2hinM8PFU9n/XWoKgTWbaDm2UDavEvl4iWUXTm4pKNsYNDnAC7T/Q
vethWZxYg3/wV/ELgSjpC2zClGPjR2+bvkL2lddjXLPjvqeRJLcrtYh5etbjZRakrdIMu41NrcdV
vjS0KdgGvpYo+tmkKebkZ5H3si6rfMvVIO5ALLY8Nzp86RREwCg9+OzcdynhIyh/0sPviYqV5Klz
f7yqQcTPM23SE1cm6yZeay67tsYhfzhae8p7LkOg2ZxWTq2NpvN6mASatjZ21T/cDWtXrZLNEA82
n+RvFW4IHk0+uZeR7VaWIzi8l60u10RaCZigDF2uQQ1ZT5Z6HkT9lVy5cC8cK5MI0rN4ACkuoAZF
1aznXrazpfTG8xpjq8KsI7iUgQUJqi8i4AYx2HhVXQbNP1nmo8r9RnU9g4hPjGt21yMkjd8Z3l7u
TmwMcxjsspR/+P7XO3K/HuXWWw4R3Xf3tHvlvvNWzDdLNZjHSitUXU7khfKJPAmoH4uhcr46pb9E
AyZuCi0Ud3zDS6CigGIGjwNQSEcC6enLsENX1gsCCtgFm2+VJQ1OV8jHOo0tgxJa9njynECI9z5f
2mIOzHGU/NUHo9bMEsVPqOA6Lcx+EKS8CV+xwri1Eg9McbK8JF36hBNvsr+oAS9KrcBG/bhWsO2q
qhLEeDAFbUDZw1P9OW7LJOVl7KMxwCOZR/mksPfdiUYAJlp3AyvIIzY9fBFeW6Z/AtoahaC7sPOs
BEfckJFDjwATfJ1QzQLh0KLEQc0MtyHmOJiWKCohjOpya3Rk7Gf3YeMVvlB5EhKYdJyDNpJDCt75
fCxNTx2ETKFJ3odg0nn5UA2a8ENE45j6MIVjRA/5OLevIGvvEviISWN5jTaA6lKJJo4JcNkr4VZy
7ww63OrgrfiWWW3TWyeEurpDRCDGCRNBryDiXTU8bnGZZI83HQGUSMEoB9UHZxMwLxL3onBvhFGi
iN8EtiMfsHwHPoZq7Y81Cs4X3PMQgh+hg7/v7timX7Qjc39NfnjF6c4Z5A42jJh0keFEOKuzev+4
U5oX8FH88sV0uXVCPNz9ITY5KNAittlACLVCHEdRMd6FOvsj5OD6j/KZ7wyvUT7a/NgWz2VcniI5
3e6xVOzfA1E3zlYBo9XqXOa8EdFv1f3p5rYLXVovnCAjhGW3bjUloI3YY9SmnCxk8Qm8pnoFoJba
QJhnktIifX3d7/bionAZZxQTaD+8TYnjL5qEC3U4iC4u25xxJ1GBE+NjJdIuGLZfTBbJdsBLbQwB
4PJXeCelj3gANIw0apuTaTCvugNvqXpe5qymKefhbhGC/VFDOTYNWL1a3WFbtcDqgE/mSYY4ZHmO
jcWBKMvDrLqrntATXJhingE5B8mO7rO78afmFHkYa+rS4EzNIp5hVyQPGhAbXE63ajFexxBdNGAu
2gko01TlDbSRCBwiqoFWpdrr/yXpnFdSAp5d6lP8LX9Hu7vBylsvgQKJ0lrMphV/ubEyt4nS67Ch
nZHlZ9vZGmgx9dHyHVON7nsR+givo0ZeZL/2sYatkjz5NFbK0Cr4wMulwVky8NVQhbKHUIaZKIc8
dp2Qe4xsnFMrMM+ojtor1TLxZIzXFkBM7MCsSuJIH8YC09q0g1kr+Z8=