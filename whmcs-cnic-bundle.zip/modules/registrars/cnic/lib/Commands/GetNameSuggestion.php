<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuv6PZ1XgLeuVFNp4snJ6CxWMW+46TqOh9AubAaEAVgfhvNIsBqMR4A9Am2Z9Y/IUPJNuLox
4it3hyoKZLN/QihKPZtS2M4StHvcB+SefnxE3WbCA4oPDI6WfFc7/ZJccujkxg41R4NBrdMTLb94
MmWUKCNMUQT9MUbu3n62QoqjbQo/OmsTzGmZ9BrTBjQFc5/F9fKoTTHhjvvmFc8K3L2qwFblT8s8
AC8lYNx8g27BjU3MKMZJGsGf2EStMV2Xcyh5xIqRXP/lhvZxOR6zLnCA7lLbLREdsQekr6i3R4X1
24U1Om6XFmtDxtrtPzTIUihP3D7Zc4sM0MKHdxA7M6SJJ74sP2fYKFPrz8YE7bbSXiRbIPKDjSSh
EAEBkMWZDKB/TwHh7T1DffSuvGBVGm32z54ckjunS0YNANRm9g02pGP6ByiBwNBFHjmkxby0oSjN
em5/eIFiCJU+2mpMBnXnQJfBgiYFVAgFV7d4wn9g8V5cxWvDbEQL7q9cfF8MLd2yAHp1hcI1rGLS
as2wtpU4nzK9MVZz5LRKZo5O4isuHE2SB7DVCEED74QWqmtFqkcy1NbtoSnGH3Y+Ntr7cLw99i5Q
ovFEd8FHbjY4rSpRhZPsKIc7H43edEAPrzo0YmRZHDUXcjmbDkRu5Dr1XjV22wHYFY7QQemCmd3M
WAl5oWYf0zvdZPeVKE/n6D1pHIfNNnKl02iN/JtR3558mOM+DCXB9LlP6p69sJqZeAp4jxk/Hauo
GXzZfrs1CJdlgFQ977dq5giLd4NtS1CPPzItOiVYizzX6ivfiSvParSHAwtWq2tiZiFaj+ad+CHm
KJ7/P+OVh4W2zrGqahV7MzXiCm8Os4XBL6uIjglNxlCmxkPFBQzHPuwryh7VND5kJv3sbNWGg0T+
1j7NI1q/jOAW27hK0txttwnS7G04qkebjwkQsFeFzrTri9J4JZkvprSrkPNoiMgqs6kBR0xS/Gyg
unovPxWbd40o+Kx/8FDPbNaKerDn/viOmSLMloXTHT0j7hAaBm3XCllNxCB1OOxtx1xMQe3l0kSl
HIlWGC79fgnut17P8kzzrkPf3eMHa4VLSpLRgzFqtRmhd2weMGH7THaBGhj8qmLnAu4oGZL8yr0i
PM4c3tUf3fqjApUNbxbJUWwpNiyaE9BScPB2XdkYMhN0LaYm4acn9SP0qUvE+7USSzYKJynQ4xAA
r0aIfoDmw5PW3eT6l7jrbxudLJxVJuJO2atwvEK2sAd2DayTdXQQfcp5fieKvTL+NsojuTrccCGS
Ri7elfV1qWFNl4zyfLJyGl+j0E931yhkaQc18b8CYDQD4sBDxlyZLnTiINixvDRVqw0KkIHG/49Q
jzQ7j0dWrvUuAwYmKc0hxmQdLMjIPq32VShhrPWC7BE7gFDESytu89QKaMLYWKDu32h1p3JPWxiT
f0s/WXP1ivuIw0R8k/r0ekBDd1wWI9/BN/fKcJDTVNzJp3/8+9niHPf7hmipgIowNwAP3ZcfxxnD
MCQnEbY/OqaTOI6nqjsIxtUsFJxDW3VJBlml2K7dz7t7KsOfnzpeHUBLUlDERH5Sqe9ooqdaCZ/y
aNWFyVTEc6+B8WW+dOfEzWitw9fvB4HYvYulHJFbpXXiB9CHpUC9KKpPG5W6Z6q2BJtHQiUxh8f7
fYM8zmF+3+o0exwc8YtJ5wGqJ4leQ6JNjxg8sVDcOBxyO1533+6Ys14E9CiJrWx4Tt/LvJikNRIb
VHG8BsxZhPU3z4kw6PWORiLfLDboDS84ME7gQI8H9QLUoxi8sPAKPb96UY+TfwSqHw0S9VKviaBf
aYdHzX9MeHlXTThFXUVKvYEMT7RJY1IvT/84dhCoAnqJrNt6FJRK/4FCi10OQtKc1MlVWyKrrP90
GYuavAkpCP/bKK7MTIfxig1LEKlqQkCZfTMEWxPft6HPMWZKVTlSYjfBR+OsebmWWiL/1I5B+mN0
dwOz1PFwkVgldSbPC6NTJ9q2Ay4TQWQvGHCiBGyBZ7UYJTRpUg/2RKAVihjYZl1PYxf4h/GpsHth
WIg2ztvYDz3usoKolvDEMGKNzaAmtBtsrgOipps/vJzphVD2oAv5N4FeIVKMsZZOw2HSSgYXaDxp
hZxgcCk8cEK2FoSZXM8CpMbYDtaHHvmFkNLw5mB0Zi2/0hYdkzZwdJkQbxHGIKksKS7fsG==