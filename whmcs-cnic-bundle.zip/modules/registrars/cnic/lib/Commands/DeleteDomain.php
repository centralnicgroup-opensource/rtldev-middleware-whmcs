<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/upwe6X7U+sl85/ec56a4FqVr477zSVkBYuEGlPj0DT9qlMhsCabku4M+5kuA9vM8sUdzaa
BlackobUFVX2ZfEJkbCMombEpe5kL3t076jJms20ubhKMtctG/rwGGkLLKOX6vEX4NkZbwI4SUli
bkLb7wWMqAIQ+AGzkgvFLvwmE3Dk1Yr7ZfF1Cw+I6V8IeT29Z8MAHoFFwP5eTwrscKHkkvD9aJDz
z5Tka4TwwTQmAYahN1RMkx4DRyKbgdxXZA0Y4LZ16OUBPrHyK4fycPXPjsfcPhCuqIxGExfi97iD
eqTt/uDiKhCm8RIaeM9g63WJAZFDjxDk2pegTky8y2jvAo6YUfQufIkMq1G/kXzzsefLh3JuHQ4V
kAZsm1I3RGy4GjecC/8QSDGT/MGHu47bwIaQG2xvREn7fjbizlyZg+ZKirKO7o7JFHhv6uf8sQom
erwyjHYoCud5z3WjjK/+9V2UgXFhoUnv3PfUDNi52hpua6KAvP0Um/JqmwRNSY1UdXVhNt7fuuGG
GhXn0PQvmcSEP65EgHnBmOqi42KhSWBH3TpzQKmkaLJeEGhfKX+K1jm00zNdmugEDJbnwao2MGNR
WgD0FRh1Oy+H5HHRVsdBKKQzsNSplNIS1ykQ37l7htni/13yczSVJMnkugMewJfgNPYmPw+xlZrN
TpepV7ZiK44WrHtsyde+lgoFBVWCUbRqXTJRSJUEOhdBdszgCxCYBWpIDoF7vj749NFAVxUjtKik
YPlhyrQf+Ql0SvAjMgYBv+4GD7hod9O1p0+TdEjiabD4iH7PNzrZXB4J3aSB+aWvFiJWuHG3Rvh3
9sN9rowTdpO3hU5a5SFXr3/ZH2WFf0c5ZPViSt77OKJG8GNzq3dT6k2Am1zetym6Q9mc/zFhV2Os
Sdq254Vu0M0dOpc++5ctPxiQP7wmVA34VHhrGHrse6XqPTHAQKOwX6n/qsKDxLGHxGzHvFvy9Erf
Qg/7ukHq2A9DnNkRbC5gYZwVXxIRIz+5aS34uYFR8nr28qjXpfVIg0WnUlUWRE4GdOmT9rfq5wsz
d3QJkqAeAqGfU/jYTCKp3xgcT90WOBkoaxD+BCk7T6kb3a9CGhtxZuur4H7pG7zjU2dZI0mOAPGo
As+D6RRmkLZaVEJ6JEyfJ0knbl0Ybd4KjunT+MgGNNwnnYfJIywRqIjAOhs8hJ0BrvW0Yf7qOqE8
PZ9S2wjbmNMOyL7IBrDouCRWt6Jc68Z3UVz55FxMIUv/qJy3u9o61sq9iMm23EUUeBMwM87tALuK
EGU7mcLbzdX6pMKMBEuDWM+HdzzT0BbQoZ1XXpObXqOcnUmKrsyc//7LiiqIT5320XX3+q0QAvRy
gu+nxgeIO2VWrNkkfnhnIcP0ILZjf5ws7cPJKBSRrOkXJicelPlF4c9WLYz75kNB2wYCSL57yBWD
HiCR4TXIvONcV55lMTCdzbWtpt+lp6Y+YNxUv0SdGadwjC+9bRLT+Yn7vkAALUyarE6ugISWKtKH
jdxVPH2cuyLdnCHKQ+VrzEPgsax72PKRM94IJbFoCCZjf0fhfPbMfQpA4LaniZXggLTkYAxBiXpG
rxydXywbvvMxJvWC5bpF+ir0gAz9kMdhLNWAgi6gW7OBaMnXoIKZ+F3SIRweLRMRsHGqKwzSly13
QU1b3zkQ0efjJ1RfvHNYjbwOb0atnCCHBBn6EWGPOlU80Az4Tz9W6P5a1nDKAi+Nya3HTjCgcsGM
FamOmqItwrKJNHJrj8/L0tIUBMXaBDAKIlIps1gKS+R3sZxDbjYo9LREAezgkAQ6c7FhIz72K2Vm
wn0Omt/EwEGWL+88L7yKh9VHaclQ6PGgbJkDeobnWvdeKrTlAGTlU7Tlabgf3EqPXFKohQEesMeZ
lw+b8i+24AAhcJ2bZJyJbzCqe6HTt7UY604ib+XSfd82RjymWFLdjMYvRPpsjNb/uRaA1W4clVUl
CY+rvmeYcMbHcS+KHfa0KAk/EtDGU0==