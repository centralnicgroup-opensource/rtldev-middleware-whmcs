<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpOvQw6m1b2NJOl+WZK2ltlWDQPN7wjCnTAPeNnWL8m2dds8yn1qHU4NUycVbes8gD0coAq9
I5SMdUNGAi+gy7QUqzLS+7pJYL0IQjcyA2XAVsgKjc2ft1j4LUTctgjX6zPinSiPPklEn6erR4aB
9lklXtLFXFo7ejUv5W23RC8z77hZ2Vw4zqSgo15kuDvL1JRUpHRXb59pCFJxTdS6f60cHdCk9xvd
LBP34df/WITwNXODlHuZHBFsDIw+bz5/UucHPnwiyuZgqoK2UuO7P9oSIrgHPdzYwXelmPUvVo0O
+2o79/+4NHQFmq+4o6sNcqBTM9ATNAmScWSp+Tgp5HPLxaNTdt1ZSAf2xDNnITspp2x8Eh4w7qnO
46dY6MrHUPK20wZtmPi8Xhfh6AGFIUeN1xez0GhSzn/b8IeR/RleEo5n1opMHjIbbTTsjrILgsxH
EzOWRYcJ4hDGa0vDoMJ8KEwoJ0DPZ6Ajh3avd9vL3mSniAnBCGW93HLkZuwBdeSgkxqsZHpDxYYK
42Ugp/uuFyByoWKbkCk77RY03YRXAhb5vxMt5413wRvoBchoB3VQDuU7T7bh/vi8W4OkSeSaLTMG
eGLPGkJ/J9UNubqhe7msfqsTiX1YwH2Lrzz/nDA2KJ5T/oYNGcE20P+ge2N0Aj5wnBzDI+nggcEl
LFQfx81ntXlC1bSFFRO66zkMwy0DdZW9fTnM64o/J6kpVlD703335K1rYM4MlUipvHBuhEqpSGUN
cBQcZdJnmZKnL28UL4cLO8i8I41LWN2rTK+R3Kr4O3ykY3lrQV8ZuO3zvHKYtKCpqSeL2MygL2ZO
XSRJabEBDA4mLLCXVtmfXPtSoRai+WVtZWAjddlPtdArexgc+4OZumA4wP85gapFqrpQhc+l11Mm
mOY4ZSVrvgkawUfFaZO3yihjoLmFRfrYKuiiphj4pW8Xchl+tQPhWy4OjxtQasstJ6eu2GX4FgV8
YDPl64WcVGCuYipf4vcnhbYlAEkuEUTdiLrqpRlCi0NfJWGxI6lwCuUN4Z28PsHL9joRCcihXMdu
owPrfO0KhCJwqVwJ1T6t3nF4k9CbHLskldQvUjEKp9NCxCfmwlauwEeITeeZ0zB4ov8/w4Rfvtr9
+xKkrTo9vk+A9DAP6Zcv8U4pheI1A0k2Hxzr3M2LSnESxeYu7Ko/gJHJMG9FlXd5OSfegHNhtKQP
K0dnwoYGnrQ/3KjwdW5h/NXF+A6f6NMDr3cI9XrkZaCatSJ50vMTY8iVJhZkr5WVnmTaZTU5z16R
dMGGAL2zZSxjqzNhgnRG78yewPr6KiNC/9gwjgU+Vu5SmtD7dkbvXFq9I6kLQPKSoMi55mgSHBTE
fT8NkmxgQvCkRCjKbvs96wgkGBvz3x+2d54CMHm6A5Cui7iWjp4ZmU2oOwpVtV36qdCJtqcxtojN
5rS6Os6TBosXIqgJ2oXfpqpfQSecVUDLoyX2AATYcYdwj9GlBbZ0PcA7p9k6C5GQvj+44t5MR2FS
AVTsxUXKvzSjB2My2wdPI5dRQ05k+PLQNOdEGWGzIwN7Wff+PFhAWClaFGxjEV3gw9hB6k/YQuSx
CmB8di96tXMVBoKWUW2CLknEdiBqRkIlIp6AwyGbAZMOClLsPqEHYKUpM/36nCqALVwdDb36twy8
raqDhjPFYIzJ0sYud8fkhqpLb3RQFgPZBe4+JeHjyfT3dAJ8E8/KY6h/eLvSMcGmlz/iWhJIxRN6
Ci9/w8D7Yosc2wCGOC+3Y4Upfr+VQmGl7dQFPkmjItTCwqdEgFdMRO0hVXZHT2N1+i0iGnjLlaIg
Duh5bocEDfOSdrOzYSgKtuqWWAAbR5yEjxgGYoPLTEm8mx/t/H/ebcDVnfRStJGDHvqlUbZfXq5W
9c8ZFZAeSs8EP2D6MPZW3WABxdiQXt7VA+L298GrYfFCFIGDqCDaPocPLoHVgItZwRIbretzY5BQ
vkamEI+vBueanuZoO4M3UtW/JM2ZeICg4oA/0NDWWW==