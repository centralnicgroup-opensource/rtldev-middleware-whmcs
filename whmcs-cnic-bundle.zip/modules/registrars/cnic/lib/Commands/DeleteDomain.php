<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpLbwmgtokyjJjT+AQiYb5yEgwZ4tkp+CyLVMxpbP/NSdoxXPwkVGxFQWuzC8HJBi81Cwf2K
E7SBV4HCJ0/0kKCp/dGJnrW5bQ7Dg/cp+RGcdcBvIzzeXOYg7VarANjQViW4tPWKSuRoV+u1K5Dx
5TxVQNIrS+yr9r2MM6XJdFQ8RRFQX4JCpeGQ7X46ZRBTHvocXKKqTHo/5L8YTwhu6RUKWS2HJtHV
s7rUC9SXqA5xcXT/SHKi8/ucsFACMmEdrrpNw5ZwRhmuno3jWo8BgGYcapArQQ3gt9djv+bedlkA
mIRd5K1zLrK8DwvDDq0ctMXPMpfk3pWDopIyUpCjZGLo0gy4BNFxmAFRGgMBmxbyn9O3i8QcnwuP
taL0Mv7haH6c6KQTbNHmladcW3fiQn578Qhob0gquL7kwjdIi17HUF1Y/kqDopyNtVQk4S8xb+Ke
33f12X6RgYgWaySkLkg8o2jAVwLVlPEwiGjDUOOrl0C300SWZk2xroqBJO+gAYSXsmgZ4rKcjHTN
FahTfveW6pA2b7rhvqq3FlElGxf3dbkA2zxrHYgoUcgG6HF+GZ5sp9X05L5QV8MX9VSV3a73svrI
tmfikzDk7tyB5mf0Fkt5k6CGmvubcWIlpzk0N8lAEC2DO3qxBiiTSvZyylRqw+MMQe4k4bUe+IsW
L7Qm27a6LHPacwfH/pZEWS3+dINKeCpnl6wRJoiIb+mevlUWaBzN7zWhsWQWvkDuYwmrAolE5I3x
L3cKHBnp7gXWPB0kMVi89ozjbuLWPNJAVJ0GmJ2A/0YLqEmXiFgLjn14vKy+d5FxOpapHnjVW8Gl
bSVpP/OOrA7m6RpxU6AiW2Lh7Qop3S3ShmP/TxkUqCrz9Wq6LzdG3qyLgjyIRLfD0ODKncUGsorC
xOP8KhLl/vF0Of1ibFlC+QYhJO+D7MGU0h0aSNSkDURBpVHd6MZeIlixzP9Vw4LwYIh0jfCeJUPv
petxmWHgfnMTU49qiuSjSXcsWmuzaHnm+LjwVgUFY1Cc/LruP5OfEPH+IHixl1R1Uw87rlcCcHuz
vyJ//yBmttkVjzxpnACcz2Q2a91Hs2P648xg1i6kBRM6fIGuldZKe9aeoG0TpB/vcM0fr0X+tKSp
N26h2KBchOXTMk7gTv7oCrrLJ23Bd43X8fk70ouoDdOlN2TRWbgygUNVkkuVeloILaSh8Dl7Oduc
JBRvJ+CnamiRlyiJq4Q2CoL5gRuR3zwBleMk6dsw/oBCJkNETpL0Nqyicnm3C74CjXHcPuZfdyEv
vjRB+cBk/M7BP8zQ4ll7H3kWW2VlD25+JM6Od0uF8GeKolzvju3SnGeiYNy0Baudw92NCSRkOsr5
MXMI3wU/S7FytiH5BgWsoJel2rUJaP0HBisDOrAkAAeQ3fE5lz/R+00XB8m4K5lJQ5LAHu5eQt7q
3nWEojmYi6JlJwlxCjmJNu8JIfOL5sUo1NxS6hAc7cpkJJfHesa/gji+dJ+Tx9NKRYndtsuMRbIh
99LhnkWoHOZmB78SwCkk8uS1VBGiDxpxNe8Hv6RZPcNG1ZZpCSwQV19opTT3+6lb5OkA9lMC1SmM
hXrMxJIFAUIg0EBjpT5TI4rzcqT5byMH9XCuicKC7i7C7QrKXq1ygJJyFhF1sRNrm3G1T+5v4kPU
k9ZpzBav60hUI2bymJOgwCW+Q1oS9dKf94b1uZgXfB7+Y2OXHuG8f0Q9OQ3rs5kRskzIOF6AIKMb
cMcVUiF6gq0MqDsWyg1qkrLct4tfFUb8GPlBxCOW1PHeFyKkzoGNw1Ry98b6SQFjmst3rbvfQ9G/
jq+aDTppOeYgczK4QGdAgk+fTIdON5aNYwA44j8Fj11TKBGWWXlnrKBstn7O4wb3jR/kE7/gSURQ
D0OlXGJcO0kO2RP54zbfewtz9o62qniJq/5Ng48zWM2JoiHbA+5sMc1q16Sw3fy53Pcy5dEi2tON
TMvYDCu73e273dFOJ6kSRrCop5vsIu8FA+Uu6cD2e0==