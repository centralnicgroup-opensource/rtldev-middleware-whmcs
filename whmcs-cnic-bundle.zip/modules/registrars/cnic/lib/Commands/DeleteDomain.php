<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtxw2GXTMl8l64YSA/gvJeWPfR4v1OPNvSbm2udYQ/XnPlte29rNdruC6CvX4pN/T+gRtbvt
oBhwk81LOMdLHTZhWvy7tZhCQZeQO9qbMp05Zbz07e6hrHDfM+YRCxChlMn3t6A1pndmq04sitdf
sCqPkzpjzjRtC/SQ0PWo7J4sRWAqy47O8S6EfEGLWya4CC4Gwx1FgZOqT3YZB//4Dg9Wb37O6e8q
YGmt+MNfTLpaeaUf/xlFmWajWHMIDtm6pvuSXz3jBHk5d++lcFjXiRrN4meUCcXeKbXGBk16l5+g
IF5zY4fwAkMUAVnQ6fwEtOrQTPrLjpJ/sGfryydV4Is/hSzi4c0a9SHnw7gFL1oI0EYlrvqz09e7
bzKVhb0A2LCKV8t7spaenD9w6LGnKCh0SlqfhK68vUI8IS5gH2KGHBqdLwycJBX2WZBfERRldlvX
8ak9npeYLUUR8w2gTucA7WfdLRwKl2VPC+sGsO6hojoUzt/SqDxkFsWwC66dfAsWjmA4+AF12zgU
09iu6GWAZqY3X9U6rObwvDsdnyfVR/4jRfOlojiMxkMO2hfU8TBkcSkssl8QIgNiIAYig19crBv6
UQRNwZVTIufTJHDncEaYtsOn+fHG2xPszPplaKVuZLSX0iXGWSz01NyixiHgBoEzEQH1Qtxq3rSw
W9MUHpjSnwnVqsO5aTFkCzzB6SYfmaDAsO/TTANeV6e5evzBZ2xWjoY07wyS6AQ3U09KkS9OVxdI
bEUl+0UohkKHjOHyWSrmpU7BDTpYchCnp4K+r1BKDpqpYSfaqFGbcBGOCq49iyPp7raFGYCF8azj
uhNqLxqSEoWu5APaG9CH07mRXUFcTG0xXnAVD+i8XHqVOi9C5ak30cjqGbzt5rsKJnX/qwTnQhO5
JmzVzE9FikHcSYi9X0Ln40GG/Fxs8JsK9omrAg01D3a8+8B/ldrkZQHCyzEY7tXfBoRf9rC5dgpM
6uMvA+pyEHUum0Cmk+gAhERRUON2TbH/my2ivaK2+qKsCRixlZKFS8OIlWzKDitWa/bD9NhDfhbk
+PulrgojAludsRXz9y8CA8KImSl0UPD1EY2ELxdj3cfPUZYZqpB0sR3xT89j2Dtk/T0UqLjXRR+A
EdoOrYrhZKAVqV7K06GhpspMXNIENeWP2lHqAih71Ww5XATGOxXs2wYv+O8YCzO5L8nN1P4nvN2z
J18+Az/XjuPGcfVroLpWuwh8vU0WmEptSDXdQR+j4A27GDmZJnGv+gwRLSOcfqPntv/XFZibVNCB
5Z/0zw54pCALXzTYSTk7x+t63FA9XE/tdrr0OvejP/LQCD/tSBRW+TmVjnVF8p5H5vOPbMS1K3GD
3JGkBnLSa6DAfEUp1vImIAo413jfLWrsmC7Fu6I89bclM575rTk6YHSHAB2yD1DPnj52bLLm9dPT
RN7aKkTU6+XjV2qN2cpZRk5DtK0EKWIA6hb2goE7csFNBVHrfhaZn8AxeONo+9Jtw+7A9MUAVLsc
nh1aP02hjsEQ65KjqJQ07GSQ/xtOu2CDPOmMvjz6z/JEABhSChg8LfrNLgrq1c4cLEONSqGuHI5y
CSK3B16WIhhN6ALQa0sJRoaOYED10Ls1xNe9C8a49JAXvjI3can+E4xOZECncX5BKF8FhH8u6c1l
3vcv/mZhdYcWJXNn2uW1ta+2KaiOuFnPfaEN/WQ5NVpBG+Bm4a3i2+ZCtN5kObho2Z203HdwGrJi
MINAR9tygZkkHxS81XXdx8dOJTuF4pUvYCMdwMZfmZeKdumXQcX3hRjgu4jG8J4MS6a3LzBYQ9XI
0ounOuGX2T6vAWHmiP2RFl5usGs2vrFa+kDsy1RoV5lkVyszMj9DHeziOiCM+FiOFbpj1VJHyjTw
Glkss3+MPfQtAiKcVopbJseKPsw+UMDO+igLTQOAYrjv0+Schu1On/JU5eLFyEj8qGKjFIDgaBTj
meubjg5zIybXX9fmM0ccmrUm2cx+ZiMj2YyUnYrwDiqNrb1AC7O4+rdZRJuWi55sinK=