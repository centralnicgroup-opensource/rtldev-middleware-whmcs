<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPry0zuz0xCkW7R9Yh1NEq8J/v8nwAH8TmxkuqTRfXlilZzX5txQbyMGfHMBioqarxhtDAt0i
bOmeFO6vKlT1ZLBJ14GKHpGRnqM/qK9aBrm1xadW9Ts4tXZsa2dK91BdMWFzpuG0yBjpi7he+yjr
C8Q2fyEhplN7jEBKCQk71gBixgjRjGKiJqaDZXU53irW19IAUDDWHXIqqjJnZ553hyN5II3MUNuk
IP0GwguvXP3vs26XQtC+GyMlyWwFL04/dcEXmbNL3Aaz1Aeez3//eS++rWrj28MO9fWXZUPdLn38
z+PTyCOmcLV/+fqiI5X2b5JU0ddwgw7XkzbWDlhcDK+phslrw/rvfXUuBhWcuycOk0FU6w1059JI
W8kbc61senz6+Shqv+GQkRjToAtK940YvZwmbYiv0+wfd4vGBI0G0OT6JZBmlS7s3luNa5UIdFQc
eeVFdQA/Bl7Lu+4Wvs2d7/+LUMIoui4tFn92VgSMFpErMSmc2cQS68fpcLMPf/dD545waco6EQNq
JbIr7m3i4TN73uHdf9KPwOilE7tJMHiCiQTdTerLsNedmrIiUZwtxmjFTyYgotDud4+Pcjdm56Mz
WFUbDbIYk3lv7n0DMRHdVPtV6mwe6ZW7pMhLLkIJhRHONLx/WZe0N1Nv0FJ0oVjAwenrXa5ljluk
0N8IPGK3opgYTmsyCK90pm18RtuHJuc5tIvbMysMDK+XFvLv5UaBIcE3/PowyHT0mm/k1nvH4uDA
zL/oVNC4Hx+7+IQwKgthuIPPBWqpIej2wAI7HANDOjFyZnEuCUwQJMaQnIH8TonoSUaEFhe6EMLB
9YxbaoA7xch1GX715IeAjWibaI4lgmnlyYnY+qMv4b9UK58BRVMH2u6PWF03LSwUzpVu0MZNZLWa
Z+s8jwFUmCpRpqczCWrNmwrUBQU8//0F9t4DyT5mEDg931X7J5wwYEP/ARVLVS8jLWsEbDgTyael
jlMEKAxnUHm7HzKoCAZB+s9sb+pSz/1OL2ZEQ0aKFHRCAvamcULYuXVWuCUpNnO4juksqWjebJSi
VQRo8OT50RFNPW84KtVwMXhutH4f3Qv+M60Jxjz8Wab1HFYes+KFQJ4oHe+fQHSv2osa0XC8huH3
+O9tQ8cr8dIX39D+/cUF1IISwLF14dX2FMNY29WOboFKtCzgl8n6K6StgIw2OXzkfAdm0IQdHVQq
j5K+c+Cf9Pk3bd0i3Lsyf2yZtUbe/I3RngiPrQoRj4QV4GlTYOIvlkwCROwiGWjHGqDgYg9zFO7Y
NZ0NnjYbZ8TY/r1ICWkAfPoXnEx0Bzzt0cpywa02Kdde+LzKpGHfJ2J2pmrVqla3CNl5Rg08pH5Y
7OeerK2R878lZfeYYGMY8lR/WvJGmTg58Emek8bJXAU8BlMpgvGggtiJptt4tKtg75BGGoqxWUlo
M7A9IYIiEE1YLWrYXhAzlYwqCMwJ37tKQTLPTWtajeOijRodzvT31aeWl6geEzHMB64wYQN5AEFv
/nU9uSxX4IgHhYxfulJ/qSW7fSNgmJB6b11xoR4NyvjoDjfJCY1aiaTyf+MVye6TSajXD5YZwOWH
ZeQe53tgv5d6FVCzoKajtCRRZo4FhMD3i2SUNI19gyuxCvEd3UPk5KiTQ4hV168UxQdDWO6aThsQ
tn5/nZd308I27mL+xmmdcalZRz8Jvu0fW8mhmKS5HxtaTMK8mYqJI8iCfXLXlvnzycWk9qHCQSMc
Pno1m3bswUZNzEPQlDk1UcnF7UfLexNdivjW9OLfAPTFdm0Wvn3J3LCKzzqJi7pKaVAukddZF+Ps
EMF7uE7DoCw08oiRB5rq5FyW3EK8Z5YTajxcuShJRqxyEsPeFq1Fmfvvi26vW7DE1NBDgbkoAtgA
dDKCgwki6wK5BDeahx79oPe8/4hkzTmPmDZ23J8E445fsRreM/sO/lpuvuDZfkQdNN7Hh61eMus/
rLU0MrasJPM2Y8JENKDLktoZSM+LHW==