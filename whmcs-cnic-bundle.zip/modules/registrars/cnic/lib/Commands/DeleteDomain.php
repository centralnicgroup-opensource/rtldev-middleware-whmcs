<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPywU2vVmPl3OZIoUj4ZvvS/SXH8qX0BwozHNVM0LCG7aGu6tGzb813+MvvURKbFAADqv3ypf
Uinn7Ui0SjfSyIl4xI2XWwHdod2gif9ye7KG7yOqrQgZM6ULQ35g1CQGkSHaId9ii3NerZJF39ZA
rct5fs0wJ9pYDaC51AV8ZQ+ZsCahdqAszkFe1m5JfLru1M0syjafMHeMIBSosP1Nq3AN2U/XIzB9
ST09aXfi29UwTo91+nJkXbuFK2TMmGkqEZlCFWvuwW2FAIcOyaxrHkcg39ibQBQkg9Gk8jojz35c
aKvd8eaCQzQ0SOG47+scI3C9szBeMLeeCHMQ30v8mXnn+y99pesQxLBkVJhtoj3s3BTDSZDcHPrK
kHauahNVsP/QSmmwXkodGDu1sPDLNwOvHxynZLg/AeN4+s9dB/+2lbUAU021RoefMnRvhMOWhoTI
/xEyWR784M0RLLQBhBdWAbm514iGEpd87uyISO9qGtKP1jubQhLHcbq1vWw3f9HJKW+M6VmH5etL
33rJHqeCAhyvNCD12rUU2LW+YX9QkS1sT2trC1sMn30WAbs/DOud4iJlsedN9kr+nXPB0bDK6Kwn
fFBgKGtKVQXeXMpatEum0CI84jpJN365ogcw1dsjsEwWYpDKJc1sBj6IZl9tLNSUmH7a0hbnugrO
YU6n2BuUxRJli7bT9/SFk8TW6FLLwSmlyE5tUILb2hbt5Ua15rjr9v7cQdC7VJhXNp5wN0rhf4AD
4fJ9Hd5CQ4FzKpUlVw+MBNfmZWk0ZoxvDngYZ4IDtOtVJ4j64QALoGRLby6DzdE+R2nDvQngmmoV
0UMr6/wPt7DDJ01u143GIqm8vfsadsVkIhOfnWc5bdreOGyEALe1Tx+3cOKCdW5uBU+HCttDB+X0
irxOL8RqAJwLG1qNjMEvvB9x8EKoqB1nkS1d4Cm84bDm2mkdjFnx4VPvBjCVjg8ec0NPiuhiLLWT
a+gcuT83LFgbGL3y2dR/J8WNUaxchb0kEu+S17sj9b0OzEzuI1G8t3Ck0dviUU7ow3zvAO066r1h
N00T+Dh/YyXyJ48lq4i8kuNhCgkeRhxq4N29LO7dXcPUyxKrKjHgXn9bkvvT8Au4sydwhR8feEk3
unNIUqZQrH5JlbsQTCI84Gxs7nLq8gJcRTe3+kDlJCK84hjM+z6YyM3h5lpkYMZqWViBt0rGLhx6
vz78SWYw1tFxqtvtn7BwJ4Qg+wVM4hlpHQt9dpHVicruVRuqs0E67Zw2pfB/pJU1DMeN9qrFwazB
oT8DhDCcchK0tXbTTjG6ScTezLK94gjCEWza26eUd7uj6WK1PFJOQjgU9MuslhxspNK/ooB+8C0E
MVdaQptZh/hfhSBvD15t3ubDvZX24qX9Nmd4CjGZL9O8qnc14WB6KXX8tWxazg8Axevn/AVEMBwr
xajiDEDA87MJKCBLmr6pFeqhcDkTJ3u/umbr8XBpNuYgV899U60l9OLpFf3+MZuiphjxc7fkLq6e
amiJa+aKi3c+lHcjIPVRIbXiFi60EmmrQB+hU31FYdb+acyrZxQs7NYNBFuh3j2rTuvcGTCaCGFt
0xu1x2NrYLlXwM8DfcSGTIg6WoeJex9qrZrezkK3M7D5cEnMzOxxwSmQ2SWt6LfLTWBw//i33O3o
UfG03gsI/9ti8JcdsaWgfSySxcvmY3+iCgzHp88OKWhkfsacy2PUO6TiQpA8lFur4hDmIv2ReB+S
tSVhP/25WBp5rHoGSgYcfCtKDJNVySHvy9whaU/vcXoS3wylEnOt57CeM24gvQFj/WgXc+r4EWf7
WRmcLu2xXdHTi7aZbqYEK+Rzy8sdTFC0WXCCbwyJRrKN1865gcw+CQkCuUzE24QsWVTc6SIUKcr0
sz9xQGHM/M6ZrWy9e3GEH+C/8Kxbjk4IQdDSiwJYxgSoa17CSXGPzdZCNvfUcW0ohgZUZWN8yAfR
AMW2Jt4zu3iomLlt0jh5lRMDfHWWJDiCWbpkNIIXTsHQ7W==