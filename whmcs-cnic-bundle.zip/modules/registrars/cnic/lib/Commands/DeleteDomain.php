<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmthwMotDD93JbbyJ/X2Ub1nH86/bZu3OieoUXSGDw3QrHbywoVBPnzh4+ZruDsoSlqHr6yv
Zi/9dAlHpQw2MQsrWHJMcbyCUFun9D6NXIclH+TspdN8APls6HZ3ETxyUTiQLj0zOQTCDk+ZtCZ/
ZKlPgXOrGQKT0tg/qj4pOWP4+64S/9CGh8LcVFpUw0CvNrvs9+svoVQSitcSxjIbzfRKWUFYpX82
m0gdEi+bbILEwh5D3KU9oRcQ/GLv8bYeylMbgb3qNJq+iX0rSgIm6ilmbiDPRpT3Co5Jt2lh/rU3
JMn7HmWNORA35k8gIeTmFOAMcJkQH9DCQXGKq/iM25T59ZVg3SKTw5NVQJBOzoyJqp+7yWgs2GOz
Cspi6uIozh5QLiENrYJXJfuvE+AHTtDHr8zlA2FF9vNTp3K4Ruis0MopLoTUJ65cSavawbg0PBdq
WktJMhESq1mfpdEo7YP0Ky/QEZDFmEELSsXFeBra+QTMdVy7KkolWXLp6dFjCEyPCumVqKTQXkhs
rl/RCRckhBc43ZabMwGRKxSa9E970Q9QL5BoDK7O6fn83NRZmB3simEadUn3ipQzaVf9U+XO6cf0
SH87oKM7cWuWXvYkz+bh3qSTfk7g5C0x6RC8qse3NowcTNU/WY+78gqN/sQPp8Ez5fL+sA+GwfF6
zWHMWllVN71ZZ4+gEdAg6gG+fj45pQVR6eqjVAs3DPqbd7l5pYicNX7lQzp+n9Qm4/ZKxbv9B4Lt
1yoLdGd1yTcLl05imFPcpa/6hb2uCEnhyKO+a80FiRjMI5EN8UyW7s1J1H63PYozXtYlAXXOsgXb
+iei1Z4x7bGTXq+7D/PInW+TemN2oUOTzhtCDa3ZsnPE4oB4L/iAnau2hdtSHVv8weodLLDh1NIH
tgoK9C6Zh1qEtTPsKcQr6wOkVofCtKb2GIO5IKsPsm2zf0jWz2ONhdQce/G4yRbm1ELj7Y3X6tej
rRlgVlNiytfUYy+kLLv3rWBav52G6uRQAbUMCv8I46iahS7iOSpX0szNoDVZNWqZnzONywpLa2Ll
IsYtvWgNyuYvuftughj5gqRJIT17QOk9Wvw5Hxjr0uJKP5zqA3NoVwBPl5/qS2J0f9YasK/nwKQz
zXWhKoJMkT6aGqKH25OIE9yg8xs+GBmaK+x4/Pr+P3eEJSj+YagJD5Lkuqi4zND9HYgmR+UZAqiO
yzzvCR7Yg7TTsIRaXznt55FcY6MyCia3/5vSIAQrAIBmjaseFHnal0seO/ZMlA9VrjuvuIEGql37
fmQy+JHe6W5O+/yVYAYVOGtqC3WoX150wVspQLPXdIAeEcsaaoRAlUNJvFe74l+BPuAzs/Mnwmpy
lhiM9I5oszSX5kJqdA4xrtiubkttGfTyoBApnWQHw2xxvvV8UtIuveTgMjNBcPfnCwN7vahuFTQz
/jAKgGHZsGHFzf4uiSOIPGRyYx+wzd131hrzFkA4rI5etQ2lqhfH8XZgYtD9f1SiMPan25Z5yIfb
wYmh+GJkfG5xtXtFuxOkqxdf67+xTNo2I1rgL3TPCL74K9g2hRWKCP8RSa3VUTuO8rMtDcPbOuEt
K9cRKOxN0C2xZjhTFMZkh4kLPtMRqpsjXrFcce5F1yQ9DUS+kcwflX1QWO6+Tqm5KWU4uvLGsDym
DWb4IhZhXXCdoIhfp/MocNrfu++0IxTAtPcFtW/jxOwK85rhT9StB7GAEdZh4BsN4nQ2ephces+f
VkrBWIQb+U+IvbuYEIpQ8gE8TOp8AETIKUucLBFedKnNDM7UCT+f5heLCVTuxYX037N/g4M1Mn+p
7j3WiTe115oLOnaqX83eRHuN72Bz3fZqyUTZOmLG1jDYG5WqxvrDfcMoESGmeEvwo0dZuKqXyIK7
AW+JWvNRqSXgrCebfC+hys62oA1a/j4wZoOttuKNC7X03ZicQUvlaD2cWiosKIysDBgMNTQM4DA6
Lf9jjHGvLfymYafTxg/EiI3yh/9sUEO=