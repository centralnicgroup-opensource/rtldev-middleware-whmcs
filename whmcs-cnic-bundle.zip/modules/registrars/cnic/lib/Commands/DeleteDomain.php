<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtWX1f5r3/kc09EJihU6lpC1W9o4woVfXBYuMFHei/089kPg3yTqib2OlN2T7Yzs9sNOuRhf
mXFmpekcri4RZZ+nqsBc7Mp96Du/2y20w1ZqC8o7cm07bvFw6tzOeSSW8w2EbjOipZFlYWWljQDt
WHKw2h6QzXqjScZuJ/KuIyrRuIFW4CQZpl2pCSbdsj0ztG+d0n9vAcvAyftQJjOHZ593t1D4eUTn
qG3R6ttv11GN/o2jVj1eXbegDhCK4yLDH/+xiVziFXhP3NoA6aoR1ZAhpK9du96XQdArv2sHH0xY
7sXWkJxGlePyuYqAmrlfObjkpBFTLLjLRi4rRYGdLVt6OEc8BMt87StZ9I/hrYfREa1UBM3WBUD+
q/q4DAVpdLcmxADAtJEVVLZKjgQaEE2o8xQHfVNikCoT1PxunZIDpIRCfAoAjqrl82XAZLeHks9C
jMoxwGn+IRFhq24Tmp/rCxIhJyNxsQDWEYlNckYdrO/C3agN6NnqOJFmKz8aFG0gdT9OUWxKihOu
ZYoHBL18nCeY7tWGm6d2noB1WBi3HRRb6io6gRxnh1JzY3iUK6oeQMIsTrhpKqpXeuN4b/3O9OqP
50WpmIFz/GK9ao0b9dQQ09o8ANLT9R3CojpXdWLAUgRZ2ZF/Ukko1CXHJhUbwAOeV7tjB4pnCXko
QSsYdW8s5aT1Eezu+JqEF/T5Jjvh3koJba4voXA8+PXKQfFm5S/0QoqmUpY5e8bLV2Hk/JAXr3Is
QIcNy+fdorvKJOL2XqOZYV84PDORlD2ohL8AKjs7tINWgQwvZ+q0dfXbm4YE/SgCgL5SCHt/fAV8
rOViQqw0ivtt7E3VZT07c/qwCcJ9G6Sp5b/Kbmq5tBSWgl0r+ny0fXLHMP+RRaobfrC4PTv+NaL0
mYE9/hg41rXwCf+Q6s8+Qvjr163E/9YKi84uBcKWNJZiTngD6AxguawmbOMMCoo5Wr4oTnP53AS9
4EJ2tp/bEQ4fg9SLAX+/de0DYh4r/B501jstJoDW6IDpMYF6NwHkCqbLS9SvLcH1IlKgyBEIvmQo
MsV8xh/3ShBheXsqiN8R9UhrNaPiXhqEVvbgS0iclCB8i0VKWXwLO5L0K2kbYmQzMxZaVcea6YsO
YeWBJNLY07ZjN+xaJrZiU/WpsAeR0GNaX7N2wYRi9hsOocywXRYBEEwo5feBV2xhVgGwPHjPa9bd
ULtucKJxIQpGaLA4AgtYD8G9rW4Vtvy+rpUzl2ky437qxx7S0OUAoq8rmlarOHnqUnwl8sOahDgL
8q0oEryHNFMT7yi82v7MciLp6+lLByuIRXwD4/lFvDp9xydU3MmKmKjv4dPVySRzbV8fiL3hTK2W
cvk3rGObdlGjWKXLsMuxDDHQ5qmxz/Kxh93gjxcrGmudOYuQYE8bRCmFKgv774TPPzQ1tkSmC9Zi
14kxOcg0/wjWziiMSHJHvKeuLd/Sl+kzItLDZmwxVutFAMkrsw6UG0Nb3KbMgMyRemom3R6XrqzU
Bawnr+z1pPXVh2giecHqvJekUfgEj1OU6IF9/K4Wyrefhhz4GRL9pB5ZwkfgMQ3RDJWXg8eL4GuS
qbLb1DkKYXuPWngnFkgKAfGc4M/R1BiioaSd3KgyftEvfPvn4oDvQSnXhZssnMkwRvt/M8QjZ8+n
unBQP6rQ7wnSNa0eMvl3eGUrKPmS8xdYqAC0QS4J1FFK29yNkPr6RgNqM/XviNfsmalUdlfUkLMi
hvVuRMXpqo+37EcVAEDCaj2/V4BPPRSEqZk4d1LwcmDApOYgNWS6YeXVUhK/8X3ZNo52+2DDfPXE
yX5AMi+DOwrkPNq5jL0ntUItAMKCukgRfv+LDdjb+pzt2mZGwT+ut6jt4GaDXR7n+18huIimypYw
eHiNc+19SdQBWK33GySt5hoRxN66QvlEwIIv9eU8PZJr01hGVQgu9sFk76hpCsnO8NdkbS7RijfM
QCCPJiIhk2QMysvWfl+t1rGml8DxUwXJHim4f6fnQq4=