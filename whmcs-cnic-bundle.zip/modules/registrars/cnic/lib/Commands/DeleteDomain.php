<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPowHD0MUVeqgPoEX9bgj/etlTCwSTl30rUUBTzVU7rBUsiT1uU5BqtvgOwgOzSN7XA0ruX3L
XJlX+waFUC3aAsjxVa+YFTwdPLlKmXx+flzm+AcWy2wGE3zFPlr3T8UyOubCrWWsUE6xG8Obj0ul
SHRrqYb0NPZE2eJxmdrun7VC4L/vui/nTzgQbGv22YNlHSiWXIKnkRKPQuEZH8OKldGe8WE/R9ai
vsANWms4pakJ2M+X7SzXIu/fBS/+AZLf2yR510o6K66hKrE272ZodhOOIbsPQXMuAFLxH305QCuO
LsueGcymyrpCRzQVvQNV/D26+oUymv/urUJVXnIAE1aVnuDs8B3TLzb+9Uub8g5HvA7oWkpi/MGu
3CmL5/e/9tld+IkaRyvcD3dSiD0zKz13mUnkep3hHXxzwDb3RoZDrHnHrp6HU80/kO6StkWD2SDn
KgI2BooFblf7iRG0dVJ/V9beQ3EWpeG6MHwMiOBdiDlzbaKr0luVLDgYreyKH43s80Wjxz9Pq7GN
HXYPVXhRvXRWkACEuOU+25InGe3L9k0Q9sqEBG6b62cnaZ8hsLrQWVQ7NmGE8JqaGGcQmV1Ty6sx
m4ePa/5bgrOFFWOR3I3DoSRfdAx7QDWpIjL6X4pZm/kU+ODT2GaHkxyVz9q3b9rI6lK8RwvWeZdj
1t+FlZjE7atUZYqz3wRHN9Wt75QPIB6ABdAgTXsQJnonjtYfh/pV/1gL+6IiaHI2glsk6TXs28HV
YtLbUHtxcbWVB7GxZk39puojkbiqrH39aB2zz/ekDBADwS1TL/S/j+ZOfIZO0KhaN7qdheXcisew
p23tMF7OmIz//KOogA+Dt/GQ9eCR/CPrMKLfR0/xL0q45S+WWNC2EIVCVOHCiX66OAQ1u/9wrpM5
eJ4k+VD3sA8PNPXHQHrO+2ZB+TFy/49NKzHAHoJcZz2D4MZDsU0JbmwnDFcCg/+D+zlVO9ufPZTO
NAFtKK3j69LvmsR/Pqc7YVL1P2gD+zEcSS0BSilDgr+UJq7YRGsPz+Aqh4j0D75M+l9oU1Yo1I+o
6T8PqcTfStc/1LmBTCCUkEAIXpbSAY+YA1x/fTVQVvv+dgtyFLTpotKrnMZDgQnr9+fr6n2x8wFh
clUlzyE/KBrNOzQvjD8NpPr2atKSF/XcXT0kjK6E3+2m9/bpfO6WfyySzT3qVz8lvu8rdaEfVjgr
eFy8+NYwDGtRlCcuvsX9cOz1BzjjcSj6P9xWT+dHc/E3Sc9X+VTClbe7TlEZjv7dG7Ft9j6F2HeZ
AeLwYjttAF6qdODcYhf0k8dPLUQyqdT5OyvkxEZ0SFKtr15RkxjP1V/J5Y3Jnu1f5olRb+6QmWvU
1JOn8YoO+CAHUZwPEZa+tzpaNTSOYOkAtU3Uml9d2vKxSAOx1/7L6TCWli6MCRe/5Dx0iN7BdKsq
yHcqzAFxuV16ePYAIDp6zGKhIidoft2u5vsvKet0gvGKL9s3lH31mtH5pjgOB4xBSlqB08bBPS48
Zd70KOFPDVv1luy7574TRRJdaOB9tNCNzzi6ZsihWJywLv9EigM+Y2tuWH5ooIChFQ9DMYBXdSSj
5P/PYNblAWx7FV9UL0SuZcsdQJVGZoBCqRn0xNb8O23/XcPQuPLcfF0lbIy4/cXy7lTVZT1CH9LX
/ptHmjpb4l9iXJ4cunsdCGI88HoywgR32hPtXsiWHupSlkZOvsfV1mScnx6Tfhna7oDNXho1hccL
qEhjJ+eWPQYuhAnuVDoz2j7tkRTzm4N+EheCJ2AysJ2+z0Y0XcJXDKvaPCYGaUyk6eIQVxF0vMnL
mlT+smnNSRa/SauZFfzHBA9qoE+nIaO2U7QrjeN5XifUQ36PuCsGGRZY4IBOlLiRoOxc0UX2KWya
msIdB5aMSGkX75RMy7Wufit3mU1kkgZPXv5rq4zuxKQydFUglgq99by1BHTxikOtWX2/ZQvBfzjs
3bBkstVl0md9FjNMkdsDsUm=