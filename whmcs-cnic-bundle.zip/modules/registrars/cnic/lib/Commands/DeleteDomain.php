<?php //ICB0 72:0                                                             ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy+npRd6dpQ+dmDOcWbnnfyo1SP6ecfnBkDxKl7FIlij5r8c5GMFIhYqzXv5ltmamJPpEK8W
+4YnIaVDq6awvMpmKgjTGKfom6NLGFBl6mpQjMNSpU2z5oH3w71fOpiXPwTK4eUyhc6Y6FgnKnQj
eGRLfTlFerLDTG9kFU08rmzaFRghI92/SKT3CrOLDedac0du69IgqYOXtxhc8KmaCEExwCCzwIZK
oxHDAf8vIMJ01C6stklhbR9lw9b3a8SLx6Xh6wZyb32SFkdekvJ1S72ucEwAfsgN2MNUVIF30Ejg
TtBL1aKWvUfga0L3jbj7MmpkKW5rYLIVXu2yoOB0cJkWQZclJ3w5NY7UlCAGH5tzoHwg9t2uVF88
Lg8utxsOBPEKb7wW97zIrDJdd3CFdYUeZyTLoLhk+gnOiYY+G0vImlC6KE7gyhuWM10TFa0BoY/d
TMF1wAm084OIVgz+/JvpNKC0Mcvp95vOx/S8LTvhzVtjmYzxQiEKbo2c75Lprguxnc3LnFrrpilp
q83/GLoU4r5tZNb4gZOcOfh4rIvE9Ie3X9XkWDq5RoDDxDxHv8c5SF9mLUkMdckY3faZW2KYhnqF
eGLoHA7Y9P4A+QnNEkN6IPKXEHHgl4h/trLTZ8uT3bxKIaoPQrJ8S3/NlbKX2oBf5gUWCINcO64Q
EndH9D8S4frvUIXz6PALBQVtTQB8lLkQirlrlzzgIm5cJoTn3LfF8cPF8nR4vz2/iHeAos47kF80
pB/NOwOBaEoBjnkgnTq5RMYCrYmD35SUIzb3BC14mQSIR1Fn1Fs+iMejwtk06xt9PWDhCvXT4lDh
NGYDr6O+n5F3DOLVwuSLoc4mQyLU9Hr2uLZJjowdmdu+Yr8XUmuCclaU1SNiPdX+oL2ivIdrKQxG
jXVOE/eK+/MVyv/kv+OZM+IrLmaX1SafD9zFB7dupD0V/XNKLm/W+0WreBsjWQsMwCUejzB7b+xw
qvv1FTBB5CI8FwTzmQ6nktw0o+O/VurfQ1hUt+kBeRWvILzUuXFLh9cwM/1fQZH4HGSNDzejM7gW
1oETdE6wiMGQPCBZ2vE32SRTcw4aA69MsDxnc5JSAYvA/zIoAq7sERlbGFUnGS55bH5TyHkCS3Rz
6H7eVNCdYlZyHPGark0hJ+piGsitbXvvYyDvVZAajZ0P4eo08+0tILO+V4+f5hoZ9ou06tdjXKtI
HnmlR49GhZT4kKBEXsZ0SquGTKj+06YoG7oiG7E2UVoShSkTvGazWYi2vMxTWGCQMIuloJjmkLPB
u8MBgkm3Ilbx1UxuZ+5/wYYVhu9b04LHlr4Uu8uqUnvjGifwqkl8zNP5sJZ/ttAhl+DYIZbTCVcv
0HEKdBNDkv8qTA7S3bc2piK+ScI2UcY9CrlZ9Xkq95PLtsQ5e3GMxanSbeWBWJP0DE9UyVyD8QMM
LGAiBdMejAcqwHb1ZPUtiFhG8RuthrvN1PA45tgsSCDUL60ALdeWTapwJ3YG+U0E53+lTpUNzmJk
OOYmycNuk6W7JucBPvfjYpDMhF8cj6BsKQle7DTAVt4JBlY2Lj99sRIeH7t1AimNP8jZaGH1YpBs
LT3Du8rK6gXAMVGBdVBxnWO+VOxwtYUuG7nZrag7AK6wJRl6KaVPlSZ6Kqm9JQfymrKZR8lDj3/v
1IscG2yWBQLaEH2LxKVCSE4AC871C4tImAwLOcV/dcBbAUzdyt+PtXlZer4Sqr5cmU6Po22RiIcA
FTjbDqfsNfpxJw+QU8t23qvItr6rRb92LvbKn21eUaBWQXdI9r9SRABlU3KSvz6gZ/y6YunvJtND
nvCb/78qtSyRDne8cvFIbx7jBqP8Wbi0VaQ0tEXdavwsGMfDOLr6nPqcE8BZNRJx/EKNhkeP7j3W
3y60cHTPdxamMp8JNgXlnUiZOvBUwSHJcGfFWlcIjGNOL0dxTYzPeJDJk9NgB90Pu+r9FxXXWkFm
kYeV4oL4H4RV6ePXFS6xbchUum==