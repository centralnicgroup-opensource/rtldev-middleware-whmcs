<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoO6Cxo0wOUpNRIcd+Xbap4PHC2cCuaS8ASx//nM+RjLxl3ABrBa6p8ZtAw6zHlEo5znEeD6
qwD5LsBwzTc9k1TxIrtUYPJ3UFtWt4P64/na5xVb/TRE0N/JG05OQ1VsNkWwHf0u6nJ9enLGvuQD
k30JOCFGeem6GEEaiBtwqV9ADVaCEG+xcNPUBCC4EWQUX4EPdv2nTvMT2TYJEeJxaQeCZO5h/tBR
fAxqNMkoNSqfvnxKMEoP+ajBlO9CsVeIsaF1NdcnDyRVXwSEvEPZ8/0h+ouhyRx4S6p9Km+lDywS
fE+FmXVdOqY8lvkDObfrM5XGLhszosk4g2qRrJHWZhk+WVwzWshJtTjTYhwzqAJPMpHPbjCGb9i5
FHc8dM53LjOrF+gbgBV2s0oRf9B3M+M3YIEswDYLaQG5Xb5Hm28MvtwrldlnsMT+4nVtcagCqiMK
sXTIYwgTZtUAkvmArmSSb2AlN/sDLyf23FRzbBoHOBWjo3guqbToNwZZ+oMm19EwSGYFfnGqHJga
KAx5qZhZRfagMNtH+XCKH3Px512QfEjrAMJwd4YKOBnPKvcFhjgOPsnxm+ZBgakboOZqJO/1f/1w
XJ+pYWVT1meQidw+SDqH/d9eoSBLy2CYHXYaGRFxwXzVOYYqzu9J/r28O0AgvZTUQ57bQ5QCCRAM
Lm2CzZsdaO3wPIbXDvUZQmdZ8nAgItjvT1wZ7YIZqLBE2x6IMlcSg8hmUhejC8ODS1LLU9JO2Neh
JpkXikiekJdmvUnyJwCqqzMY9IDpxP0uXYjpm1lCqEeVALoCcO7crc/RhQ6yl5q1o/16qVTboGFB
4AwIxWXc58wWX0TDfK1fVWFPrHmnnDIpoZa4rE5VZyK1RgxmE25NRKrXSxtbv3jW9hkA0KXAj5IT
9VjqBrVsJmPxbKpiPH0++jhjlAWuL558Z+e358LIGLJMuZAYW29sYPYWULZFOCe4MzDCd3cNp/xy
2L7xKZga9SD+LYx/OB/NoU5QFf4cxInRiVo7S7OjJoH5SU8KULqcZWxw2Hrp5MAIQAuVc3ZCnGpu
XyxkjnZJeQL0bE8/mZSfRVhuB4ElNVQvYXjHbIntv6Vp4XCCcS3PTYBB87d2gvNrsB31kt4wtWun
pfA3SFUQs0A2+MIF9z+HZaVuIJMLt/569CvWBodxgA2+MWP3G3es6zkaC6FT8e3Ysd2ecjHI19QQ
Rc8ikI8Qmdy4BFYauu5kOncLyFH6umjgeALA+Mp8mph6AEs6cA1uvB//18WligSNSlIgCF5tEkgH
Nz7F8+wjtoJDRHbjjlFVuX3SGGHkWDtc3JJUZaq9tIyaP0vDYtxO30KNwQTlo8nK4ld/Ub7sxXHq
0Lr1xCeEkN30v+uNjsOflmWsUqFv1C6iNGQYvYvylLY1CNW+jMylzBY/acwWLLHpHbprpy40IUuz
gDrWDodEe07Fx0Vl07nN/RjuZOt7o3dnEc1XJ01kWlq0pMERurb7xVu6tu9VLEN4xrOQ4IQ/8daL
en/NAxsCilkyzEos488tRqCoykZ0nPul+Z5mTn04iMCDriYnUNa/Ys5rCDlGzyJRGkuvp84YyPU6
+u8BbAY5nywGfOKtzGltvuYoh0FBwpPAUKtBWXdWV4fGuOzFPmvds5mDFa8VD3v6qLx9FNNQTRhA
HH2enCSEqHlkToumA2H/tHErZ3ZySelGQ87T/riTfLQA5zLCX3+JlzxD+oa7m9Br34/iwVmvtIVm
gRI6XDhwqNWwmWsJ/DbZo5bNepcF6AZv2X5qcL7IlWyqGxbdt5UwYBzvqfSj/Vb7bSAhui3i3hFQ
agdvJhsL4/pACKbfXJtYE+2VvkD89XIx5DR3uLAMLa4oXpH6ZyqL3crbfQwZUEZ6m/UKKYtvnK6R
dSo1CKxA8jRm6xIvcQ2omMnbDlLrui8g+sIPXQ3NW2dwmm3dcNdzIQIMYQCWpwBuU1CenYmkxrQ4
jr3Ru8SwZnRsdyWw3VnC6ZVR5WI+NVYausMWwOwtzW==