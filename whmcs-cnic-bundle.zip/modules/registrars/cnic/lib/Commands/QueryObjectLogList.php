<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

class QueryObjectLogList extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     */
    public function __construct(array $params, $additionalParams = [])
    {
        parent::__construct($params);

        $this->api->args = array_merge(
            $this->api->args,
            [
                "OBJECTID" => $this->domainName,
                "OBJECTCLASS" => "DOMAIN",
                "ORDERBY" => "LOGDATE",
                "ORDER" => "DESC"
            ],
            $additionalParams
        );
    }
}
