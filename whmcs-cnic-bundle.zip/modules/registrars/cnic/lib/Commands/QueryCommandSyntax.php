<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

/**
 * @see https://kb.centralnicreseller.com/api/api-command/QueryCommandSyntax
 */
class QueryCommandSyntax extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $this->api->args["CLASS"] = strtoupper(str_replace(".", "", $params["tld"]));

        switch ($params["type"]) {
            case "modify":
            case "trade":
            case "transfer":
                $this->api->args["COMMANDNAME"] = ucfirst($params["type"]) . "Domain";
                break;
            default:
                $this->api->args["COMMANDNAME"] = "AddDomain";
                break;
        }
    }

    /**
     * Execute API Request in case no valid data cache entry
     * is available
     * @return void
     * @throws Exception
     */
    public function execute(): void
    {
        // Transient Data Cache Key
        $transientDataKey = implode("_", [
            "cnr",
            strtolower($this->api->args["CLASS"]),
            "fields",
            strtolower($this->params["type"]) // we could also use $this->api->args["COMMANDNAME"]
        ]);

        // Get Transient Data Cache Instance
        $td = \WHMCS\TransientData::getInstance();

        // Lookup for existing data entry
        $entry = $td->retrieve($transientDataKey);
        if ($entry) {
            // data existed, reuse
            $this->api->properties = json_decode($entry, true);
            $this->setSuccess();
        } else {
            // add data (TTL = 4h) to cache if API Call succeeded
            parent::execute();
            if ($this->wasSuccessful()) {
                $td->store($transientDataKey, json_encode($this->api->properties), 14400); // 4h
            }
        }
    }
}
