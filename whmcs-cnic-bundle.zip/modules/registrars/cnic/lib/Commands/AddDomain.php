<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzR8xMGvdDPBn09uHw21nxdyHQP9b52UFe2uApRe5UMDho1nKKnLhW7ZgOq/AoQZyVzUf7Wb
+zPSK7lsLFdLqmsNCj0xTiCuSkoX8DWi04FrURKpj2v3r4RcMQfq967e2XqiY/0kpzZweqQD5fng
TGjaROsXuo5hx6fkFs1BA54oppHnWmehCJ2ZTyJkQcmJe7/7zFAWuMgP0FB08ylVRtgtD9nDuX/a
A8N7azsae61flmKMAdtjvag4jeJBUmQcRrlaMFfkl3Z78Es38Wkf2AQJCZHfVhzYGDpPMobXXOgX
hAWsAVPUiApXwsH9obRPoI4f6COQjOz8gOSe7+HvL84DjmhJNU7aS0TYJOi+bfjqoZJGV70lPLms
18BGvYZwCVht5nuL6fvgE3c1dhfe8wV4lf3qGhC1ELo3dPmRNR7k1RYXfiZ+J/Nlo+Wdj2I9Xzel
Y/2sh+hW+MbUtbM0oYI++SUSje9ns2EDyHfjxq//C3+5XbgtXcpVntfp0OxigFo833wrqE7KB5OU
A07UsmWLs6FKE+7NRm8QzM7hSqmVfRwk4BdbMh3DgLZ4SNZ4sc2cSJ6UkoaSsbLrC0lkzmMAHFTK
57O+7Q3WVOw82aLIMW/9r9NQIg8tUwAKwIWAlP6sMELtHsFoJt3/kb/7fVcCdJI7zXOpR4kPCOKQ
tiTC0SqluIlYHRgmwjcNEv1cYZl1M/Wjlc/4Z9Ex5LqUs8/+DTh8Fbp835hGfi003gH29+LIHuzs
lp2w3Pfd9HrtHgoKEHetCW+XHneU97ScK+E+XnM0mhHEfIZHrrA/VGnuDGvoO8CPKOR/hPQet0Dw
/gUUaNcJttQE+5ntfTOU39NO6SmLEGAyCkeDpLMOtypMpfx31rLIxbE3QmDe12eK45a+SQCvBB3C
1isIB5xrTPmUMGAC4EsL4oGq/Ngn9EQbbk/bHeC04w+TGMb0g2/9QV1ki4PCGx3cxqbvnHyVpUQF
BefAo8gxyLBKPV/iHUFtjxkIuWc8AOuJ7LGFQpKHo+Zor3Q0+PoBTzvbiS4ttI4B5cSlXQg/AWQV
/3SB1E+8vc/MOJa8iU1I2DLaEN2Z+/iqkdEbZvKM4JxuD79Hr62uFSfhAaK0WIjEM5riSXGlHKXw
Buvs167kghSk7KTIHP3VJwoixPvKoxbmKsuJC3tSKbe1qNigTQUG6mSX2FHY8zkpAkXdYkIDK9ye
SuumehF5dS4HXw9argLXVtW/Enn7mrnLUVmRc44YdxyiFsfuZeKc3pBKfbDghDh4WhiUe7xYxIYf
8dolWg+4MJLdbn2LO8IvzmnntTz8g33oR7zSP1/ysfHquhz7wMSn/yQ86XfgPicc61OS9B7V7G4x
pf33+mfTi45XpRYKMxW0D5sP8Um1EFjSxzfTaFdMGE5gGEsQDDm2hp0q3zAZoBlp0O0OVcqhXHDv
bvPWYGjBHiS0Ogz6tjuOG8dOR3xb7WOuztXCQsa89zG5RWhejb4CL97uKsKhUV49Tk4heBI2nCeZ
DDQcosakXFnVgDdyAOwJFaHeOXSXKAs6V4LJZ5xbuCfc4rGKIzPQHBaQBU3er+03JVo4Td7i7nd5
Q2OLyhIYcqKQdFKj4rGLGIECajpgxh9Wo7LhxiuzLbrOTnzCw3ZApWTXFK5VU5uqXEG2W70m8Q42
8HwpXD3RZk0Kun8YGyCPtjO9EGCUHxndBYxoniSBwzsz86daQAZr5oOTpdqMt985JLtX8wng78Sa
IeoxeENzWBO2bRER9vEQFv62qwj/eN4HP8eElOE1QlpXO/rgG5M2TZzzrO0Ki6bw+8e12K/4TpZz
QOstMx3jdI/7ubXXwINvFOcn3TaLMLIj6/N0gfYD671+mv2NuV4Gge7ARvX/1CjDseBWLhqQ5jFH
k8FzO4kQwJjbyvGIHAUtP/YpjrxLhHsypfZ3oQ1WMn0Zx8ebOnCjNTEFVUEyUmLadKHqbVMwKUCM
tOGCFIAtgccteeXRbPMWgaQ+k97feRfsHr/W52QvsaHX/DBOhNb/qLMdKc8fEVzIkkDTf5ekLtni
C85nn8FRqj2Lo3ALJ1v4v3VnUoj/gg2dvFf7p7wBrpJdfzlvYsn7NziziMBkW+5omHLcHWk9BFp4
27aIOsY6kfwCoGDtrQkfeh0570GdAeJYiFC+qe1AXa8zkpaGmyFFKLBIfkeaLpMthh8ZEjX810h7
qfPSQHGIyMfWFwKqZg7hubZrkjlMcAKwyqgx+4xJQQ+ihOSLmMKStA1Q5ioTOEgaVARxruYpTLYC
ebjhGmpNp++TGcEE9C0tnH+wmzUWtHPEkk7oyWbjNZRDb2s1Q6OE42N2l5BAjfv95cRz4juUNUbv
KZ1w63wSjTjMtc4G0Y6DdjLhg58mxXoBGwHYZu+p32FWcehiYdLkpG0I42it/ygzF/MYgAdaVmTn
BJkUiXiPlRdx/opbTPehZ90ECjoXSjANzrRbhX6XpqAo0uQ6arcLNi4s0Qic3T3XhvEJ73dOxmha
ecHC1nv0YHz6HfYfJoVfIf3QGG4X6zPOHxOGiN41P5sMqHm6ahg+nlaVC1c6gShRfK92KAPxO6GT
EhkrBW/+qGIB3br7dEF2e8i94rQMo6pO69+47q6NI+JvYIK8tPgupUVwNihR26BaQPYyGRIZKiJj
2FvbEuT/s+lFasfOWFlsxafD9g+I/uJa/HywMXoaAC+uqcnoj4eOuZ3UB7KzXNEOAJ7/QpDIkAFr
E7tI+uRUBNnOFaNbdHYSPAA+gmzzUpSr/tnHBZaEfea16tCeO7HdTI9BVmCCxjzMHzGP93scbLUn
cIzw1tIX1ashyoNz/GMk8te8tjAscP3GQkt9g9qtGMvMQu2EZNYD6KFdDFobLNW9EtVxsAEz0bY/
pe1/871GumysS0YE6sPGdc10NfYQi+1ZrGLQ36clkFzp2HChOaxv/dNA6rJsR917zhkHdJGXQIEe
VtFWnSA2IcE3Yb3R0/UckbSSTeZz4/fTu9QFg+4567QiXJqmeYSf/F5eAmK2brki6LcPQ6L/JnB3
msTXf2hd6KKM0WTIGJbIrNf8QoH5MTaeXPr49UAFAtFWQMDq8QwDR7lVuHLu14J+Y52zmHImXcWO
2WsuiQkvMZJioWxx3wxx7nFS20z6DbLlLpvg0h6QeGdKraqpuJepisisE+sVanqmMHyJpRcqESbW
hlPXRG2oA26S3WbMXJv1iovEsMCPl8sgJ1r2/ZkB8JlwSQDsb9jW/Y5dUKIfh7i3+T0PUOjbCSGQ
A1RfLOjBmlw3Y0n00GS+I1KwvyCBp2E4OsZPvRea+Tm/PI/PGSyv5QuAVFPpNZVdvm5Qd6+DTajG
mgiZdE2Do0JsmgPMcU5U9Ne2W/ffM529h60QuenTf8gC6lwCzQHw9Tep0D/oQVrBk+c/4oyS99GL
jd6xig8BZqk/+ZJNCLXe6YIUI/SuwpENvGrPas64H05wWfo02KBJd3RAO4PE4lFeunXHFZSTm1ma
kMDvP3ce6aL8/Oy5pCCUUXcU60ChwQXslXoebz2EOVXiNxLPC/0nEmZQHOEpbTw9y25g95ae1HgY
IYx/82B9H4Nnn9Rr+jvZs1cWy8Ws1qeD8aesJPZPmhau51darAacXhjLRXOd5Loh6HVYQ/WClgqO
FfMmQi7Qi4a2y//DR8TKFyVkoGUvNysDQ/Ai2jeGescHY8Ttr9UJySmPHu5v0YmGmnNxnSXlzHS3
PEaPKPtZsTZt+1OBUF8m1Gp1LajH0cDO9IBpHAj/c72ck37/tT1aXnwgCun8S+vGHcWPruzU8ojx
KPfJZ/ScHr3OVYN+NWTTYTAG5YaLtS9OeFN8EQZCCMl21II7lp9nXBeHa3YEnOUvbtjZSX7FRhF+
8WZ6cVz3RkW99Si4ySJe0XZlUqNM/IpO6tkeBSMaNzY3VZ5eq/p3ivDXADjvDaBZcIJyX6y6yKfq
1A73bXuLRennny1dDAX9qb5Qhlllza9gBfVH0PCwcSpjTJePswRXTA/QQ+VxrVjZw87WOYqJLMJj
Jw0ikWvO5xxw7J4GlxTdWUkDZsvZC8ttqiqCXSfNZIdlaKyo+3+46PYNrGHM8CDngkgtdX0h9fga
3hmScjzlLBiGwpb3OaPh2NUV3SFgu4ze/YBerHjFJOOxMH7zNKOPx3LPvGpnbokr9RXDaiIkxdnx
l176yBnEU/PqcaSfH4P+EoKVcia0rlSOZQV9jKK9N/wbujqDOeqvBMvjks9gheWq50DTNzFMehpc
wg1kCl3qFzc3HVdI0Idj3rCbdXJhb3+81F8X1XISRUuntzPOSHWxPTwo0Oexoz8b/g2bIaYwyeR4
COW4rdMxpPOAYp0OiOAWinwjmXXyu2bnb6WE0WdaZdr0GC0WS539OGvurkmzdjk7k+xWwaDw9U6e
txibNDB5ASPVLta7Zq8iwxEvkPLfwZJDCqWD3rYt5ugrlPrqMT04Wurbzh8PMQWEPpG0ouWVANrE
Pz70NCM+pa3TSUaJwSqjGs8LQsAZeNeC3/1NDqTTBaC9mnN3n4NiWaYJpqF0Q1uk/HET6vNsV9/e
WMjWATjlKSyG8iowGr/17aishvLIoh2mcmepnmBK5UGnf088zW5EiFAdO9CpIjAXZZ1F71QvWA3v
l7nInodQU6XCMZOPZVYM2SzMzpjqte3Z41EvT7OKava8SjcNqbD2s7p1QBfs9vAh/4P0EGmFbxS1
p9Nnz+muC1pl+STeO0bSGRxN8xUwWVQzMGtU+Nr+ycxdnG5nUDQTYRBkTyeOcrMzGB9jxIBBPnzv
wh0Q2Bi/QFQl