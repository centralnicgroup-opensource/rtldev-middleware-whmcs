<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

use Exception;
use WHMCS\Module\Registrar\CNIC\Features\Contact;
use WHMCS\Module\Registrar\CNIC\AdditionalFields;
use WHMCS\Module\Registrar\CNIC\Helpers\ZoneInfo;

class AddDomain extends CommandBase
{
    /**
     * @param array<string, mixed> $params
     * @throws Exception
     */
    public function __construct(array $params)
    {
        parent::__construct($params);

        $zone = ZoneInfo::get($params);

        $this->api->args["DOMAIN"] = $this->domainName;
        $this->api->args["PERIOD"] = $params["regperiod"];
        if ($zone->supports_transferlock) {
            $this->api->args["TRANSFERLOCK"] = (int) ($params["TransferLock"] === "on");
        }

        // additional fields handling, keep it in front of contact data
        AdditionalFields::addToCommand($params, $this->api->args);

        // add contact data
        $this->api->args = array_merge(
            $this->api->args,
            Contact::mapOwnerContact($params),
            Contact::mapAdminContact($params),
            Contact::mapTechContact($params),
            Contact::mapBillingContact($params)
        );

        // Handle nameservers
        for ($i = 1; $i <= 5; $i++) {
            if (empty($params["ns$i"])) {
                break;
            }
            $this->api->args["NAMESERVER" . ($i - 1)] = $params["ns$i"];
        }

        // Handle Whois Privacy / ID Protection
        if ($params["idprotection"] && !$this->api->params["TestMode"]) {
            $this->api->args["X-WHOISPRIVACY"] = 1;
        }

        // Handle premium domain
        if ($params["premiumEnabled"] && $params["premiumCost"]) {
            $this->api->args["X-FEE-AMOUNT"] = $params["premiumCost"];
        }
    }
}
