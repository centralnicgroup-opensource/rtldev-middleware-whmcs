<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq0+vlTX0TluV8rpr9QlE29YRzYC8lDNMOkuwPtZMIB3f91sMnY3+43+Cdcg1nmaJx+gpCa6
pxZh5KajDRX0bbDQiMK4OkczbYAjUn7VbkrfgAAsRsV6rPz/Fxek7s15OMptv2QgM24qhMLAs4hl
hBLqr6nQ5zKJfIQeLZDiTFNbqYU9Nzo8DL2LwmtrfxTMtVDNCuKls0eTL2MTWxmYZZj7GULZa8N3
Aqx3+s6rxkXjmw9IsbDOpdlMmtAwZmhNDV3NmbNL3Aaz1Aeez3//eS++rjbiOHRzKeMN6G7oR12O
foTp/mQqjftTCB6OfLHwgc2RsaNIVLNkQDE9d0IruoosM1wM5h5ZQZ6ikrR7cOhIjwlYgiuNd4oB
TRpauEiiM8YkahXs/GDxu/WulW817IVXvgY82UqaPF7ChXJ9hXvi+34pn17rtWg5U+KPnzmdpeR0
62zhpPIiy1Avga+D35eRkmvosv2Gl35fj1zikgWi1gtCmSlguQ+BDz4ctO4QCkAOO0bYdzIfE1Az
GCiMc4o57V4Qx+3yMK3t7ZY0TW5yGbFsl+JUfrADKm5Id9Zk0Y1ajg+I7/Ei0pjuroeAHF8OjZPd
z/39WIybqqV7USqcrdpuYPUQui8aYEgNea9EqW+PFra4wo2wvfb+R88n3G7qg8OLFnHZtL9HjEGp
fJSckMQV/rwS4FJYGEFpdZjZzNZLb4AtIiLSLke2pU4NA+Dhc+dY2bRcNbuAwthlxzf/4+K1d1QK
yV6rHsvPG7TSb4YSEbArCK7x5zDuYFLXWz9pEJhSlsdQUw00nrzI81jYLe3wOenBbgBeU804rN3e
Z3HZTybjx6YF8pgK+sq71IRFtmMLzGpIbgwq1sFsPKGEexSMqEcqWY0Y4yO8i+JtpPYDJ3cd6mtd
kXIZcyi5YreM3ZleBdRiKKQqdeOVB/P2nDZgOa95ez21/gCVsCpPS93ZNUc55jZDU24BQiIvJv/Z
IZt5xWxlxgirMlyKzw5Lc3KnoHPFV6sMCF8o7b9+o/EB/qHUExaveQRx67uttzW77hnvJNLZiylj
bvZTufvVNdS3QgcU0KWZlPcTZ9KgCmABgMHSYfkfL6kkSbBO7vO03t/rPTJ1OgKRGRBUgDVi713j
c/OmqXh9bBMlhUHiCBxTYQcZqSOdVasA6iXZcM57XTF4ZwJ07vGR3Np4/xCejfDguj8LW9cAdt29
pyd2jFBENsSdy84N/m90imbDfeMWQlnnGUz1A3MYlhUK61OCXWtGtLORsWuvpyD9EAgWIxP67LYv
Hu7bJ3DlcMMlQaeag+iI81eCGGrqzRgWrix3DK0ULNkt2hXSnTbqC/zfh1NUOjUwzx7t4GIfbqgK
3UAknGCS8p5kRjbX6H2U+zNEDKt8OM1jN8GbYpepxDQ3Z9IaNJ2Da642nQVhe1/MeszuUcwhBAsi
o/y2SAypsp5++5riRMXvmC3wWYg+Eel8s+upsykT5KAQWiFlEoW7hkRbZqS4xKkGNPeu8QcguJiL
nnBlifsdg1jD1OCuyP5Fu/VriIHdixpzU6Lp1XNJ2FBS3ZTCI8a4cLNgB8eCbjGDGnGxfErn4ByV
kvAoUd311ZagLw/EGQ4G8gtJw/ELcuwO+mWPw+Ay5NYp1rKh9olW07CTHrb7tooVZR2i4GkMcolL
7PJa87IPI/fD/+CNI0KPAqA5oUy8W7kccCKizw+Ld0DDLtSdXbhx36OQmA7T1vZqBE7bgbNuap+v
frUqrJ1VwpVri/87gXJak+XEA00cEgUz2nQ0h8G/w+K5tRisWZNT662hG0Eb4+Gu2HdlnQRGYsQ+
DyreqM8qF+aLSPtuyoZkEUIfpPBI2+xwTJ2/Rj8HTSX/cPCdSeASOLhX/xNIykwxB9H3f1pCr+YR
6BFEaFk9RNqHDdWUyb1lAJFEzRmScQIvd6UsV3//qP/bQh2JN+Um9ON4yA+eqYKt+qz0O18g2Cap
MF8YI+UJu0jFHFOS407+mRw1x0KUJBn/Lb+RvxZXxxn6/e6xe0R/28gDTCSK755+bov01/yABGDp
PLOBbUIYWBCdAI1Tymehw23+MFDc3fggpvDAnMQHDfwiQVT3P+YU96aF+h1mdea0toeZ6Cxs7Htu
SYHGmNgBpUMxDxpFqI1LAaFvgg/9n0PC9b9/w6bg7AImuh3tKhj+5pC7//ENyEFRx5aNyGnSYz67
pVKYpiGHS9IgxfqAjzjLjABV50dRntqWXGn5grACWMEP1NioGfJlOIqZfDKbpEfnxPHRJ/q8gq+N
ZzxhxZHxnp/tOElhFo8eqtli7+ST61U1dAQC8d6BNIet8qGsvZ0AI6bY6zRwCVIxOkd8CqOeam5D
uUFVzxjsTfVb1dc1pQa6o+iR7jwiBSG28RNdLtl0gqsXuaGw9nnjzbeU9jJ9UJeNI1cmeM0zufGM
qA3f9SkC