<?php

namespace WHMCS\Module\Registrar\CNIC\Commands;

class TradeDomain extends CommandBase
{
    /**
     * @param array $params
     * @param array $contact
     * @throws \Exception
     */
    public function __construct(array $params, array $contact)
    {
        parent::__construct($params);

        $this->api->args["DOMAIN"] = $this->domainName;
        $this->api->args = array_merge($this->api->args, $contact);
        if ($params['tld'] == "swiss") {
            $this->api->args['X-SWISS-UID'] = $params['additionalfields']['UID'];
        }
    }
}
