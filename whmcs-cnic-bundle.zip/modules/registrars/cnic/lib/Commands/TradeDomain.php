<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpSghxLtzHEw3fawbfi/2Xs8jbXf2OHjJj0Dntzya/L8YsH+3azXbV4tVyXC2CXKsUJhnmJa
lY0DgMbKQ+GLTGzQsQLWkPcupzqNil+0FKxxOJEvqu9L3GPf+cQ/ydKGejDjvpXGTWO8sxtnR2/4
O4ugwBX3WKgh7i5j+/BmumRsDqjujgEWa1Md2LIQu9BPkmgUBpsVL1BKpHZkGieMdqqir3UOVZ3a
0BkH4Ye87JHo6XXjJb5aNpwRML8PAZsKx8H2LDZFDzOdJqGe9uqLjBC4fQudcM5ZizcpXHOElkAm
MMVXgoWCejzLxLDjG0mqdqIf+uYOe4tbDFpXzegOSfraSPNtxB5f7MIlOG6QqJ/MSomcWz7Mk8UQ
HnpBP8OZLN8SGsZpn1E+DK0MpHRIpN1GetrqBHxX9YDllZNgqfUr1F49r2qBf4hkUC9S7Wtc4iug
b2VNN6+1Te8ddRaUaXes3nr2hcfUiHl19PdktvOsZCoFVrngN4sNrSv/qiOzDyT9lbM3LH6D4umL
HbolsSBMzsyhM1cSQhETZ57MpNctQGmCMyFkIs1WNnuh44F9WTJKnQAFib9plRuJtCeJ/8cGXMWY
WZJV5uOEHWQXWKsa6qQH2cXoknKiCHtTlUettgRchZU7+h8Xbmwco/pJaH0FtrmeUDR5vJJGEHoJ
la5aQJN0epQdvqoO/b5mS9+Sgn/IUgAlxyxMS02CWig8wI22UPuqmLJRbYF4b4pg5/El74HySwPO
nnPjPzjGBzLyeu5kKHKEG5jAKL5F2sbWVgk4YUoiyugG2lbcJHWDyLgfmxX6gT/jSCM03kWpDGy5
kryXP5MQVp3SeFXIMXlAwGbNdg9DkAQ991N2WodWi5c9COxfC5YsEwMoAcP43KdylwfMtqgznNrf
R6R7d4yYzXXzUXje3qI/eInlVavktD0Hf3xzbp01aP+Xi9xSzo3aVNwRy1fG5q2hY5dgUMi8k/0+
HRqVcIYro7O7A7G4FpsorHG6Q2T6iPqnB5ch2bng353Cg1/vnr9ytKq1tw5OR3WgKne22nWLTFnc
3pL3kDEI7YqcTedc+UcwZs9LdsulmGxrUjgrNYYB9mzsV/inQStxy2YM1JZdnn52RR728UmQZDBK
B5p6p9DT+WEMdbgbSX3PbJJTVx8SLz5HzptyJ4GFzDNUnnpQhr5EpUfW/7LpXcyVgb4TYvpPg1mS
FmKheBciFPQB3GkrX62VCUziC+9nu8qGHH3WljMxHyqSHS6oyL0A3Pho4PAvtWyCZMckFnSYOC7H
Fk8UzwyE0RzOSsjcb4a+LjQmNMsUXklOqWklHB4++wscIffZsRPTehuh76GC/rVU8cMAFue76UHw
R8zgmsD92HRNmeWxMGcShrvNEGEzWU9zA6xdKpOJ6LFosfpV+VYCNJPiTl+299SATiS/jCJVwK5u
kDKKGsqYvhKMEJY4/qVsbsOBIo8CzlAYvz3s45txzfutYNXSHfoMtf/SzfWq5L2WuZgMP6MjEJ4j
nPVFKX/xbGeT4I2551YIte7eDuS5pA8zAUt0U8L3NOtgOYjHNx9cE1tB1nqo6RvEqjcleEdimT7m
R6Q9r/X+LaXFaLZotU4s7YjVAlP7cr6zdbJE8I7hzJs7TYdnjrB9pO/v/EXiVc1K9I+vFp6Ju5Kg
ieqzxsZ2BMtT8cvACon0Q6mqdBWhzR63Q+AYwrUIvZa8iQuHw+AIcF0ZsbZwg30FAXZibKZMma3G
cTjkOGh40IagLf+Vaeon2Wxitapp8XapaBDmGJivB8eBc0ilkiXOOmJjmTdp5VMR0OwXX1LPvkN5
R9H3Xyy558TnPnBe5wz7wT4b5XGgfnKwd2WJE6NvKJq7FX5jS7XtgXL4LYrcz1aRIHLltBiFnXlN
DAv4jSZP6n3KBfSnYdea6RBY8K1q7z5vusQFzv1Iw/Vr1zalxT4oEV6rRzdOecF3gIZFJR2fgW5o
C8L3eOGZYX+ZGlXVk0Vok1ex/cKXR+vgqIPhW5iqEs6PlejHi1Xoc65yPJ9us/wGH30aoave5JBb
feEQqKVCRweklUjOYh4nCl+8RhHRS4mUc3kJ7RiDPBfHS6EVqJjFvbiBngV5dygcBhrzplyI93WU
4FYqVS78Q+c85Db3rX3W5/TNfYxgaJCcC6lNIfuKQ43c0AY6tq1rrmF3XeQEyskMaYwa5gliG68P
No/RxVA6FmFGFmyEZwjjjbk4mGDQQDpybBZ+mFVSk3bN7XsL7ooiuaNJUgRNGaJqd74b3i8t+AbM
BHeNR+Z+mms9avmdHbwDtKj2/6Z+5gSzabf0haYCy0aqTrD0l7Kg3y+DxG+Vymp/z/KZ5oGtCUcx
Vn2coYLCNtNPNA5NEWiMHzkHrkXbpuQXtBycGIq9Z0sFx32KELN4nb4ryT1Kzdu6Ab7sJThWBVRO
0NhcgXUkKwTzBkswHPh9vQ+leGlkSm==