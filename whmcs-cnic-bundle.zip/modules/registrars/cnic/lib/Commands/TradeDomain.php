<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPykUXDFhONtayYqHy1Kh7DwaT/bABK9hAVIFbvZOT7X0ap9rRNbkUztri36qUO+FEArD5NvD
lY4Z39jr4ztyZbNeAMwCbMo7Y4T/8e7U5TI5jiVvq768Gqj5onZTO4OqOQx9fqqeQxBXpMXwc05B
7qxMCYxHfBFPMOS5M4CEgGoy4HkxKpPQ7i6P1c4G2rfMyITovgiRt0JR4k9V7hYvjH8oFeE0uX/k
yKMPABFLikL+m1Yzde+fJp1LgDBf+h5g5n2act+mtKvibSCqdBikYzISosd0PsdCxOA2Hk7c5RAB
KUWd2F/mhFyGa1/umFiag4Xk1Ab/MfFO6MGfapKfqFi+BIfaWOVY9K9U4HVxzPrWUkO5Oiii9N+/
QcN2doS1crlymLm8U9KjvB3+1aOG/3GpDnSJDd8nNYL1XpI03XYQRm+Sd4I8UFAVgW02J6O+37jE
pHBNNfWmEnnpBx0AbbIcddUj50Nu9d3be6ZZwNGgGs2b+q9WWnQ90MJgFy1Kqhuly3A7GBJ65p20
xjKAX4KAy2XQWQeNnDsuRPw9UJRvzn28G2SAEjvgjeKlx6GIzXByknMx5OhvMh1qYXAp4avm19lt
GxoyBsKkWvbnRhbGiDQY22jH+KZfa+Bt+AHX+MbGAluso/uB352aCINaGQiPYrKaSce9O2XXD3lJ
HXKml2QOo3WI9WZwBtNDUjG/UTrHXosIURM0pZWLezX93myzyIkhVNhgCZJ4916YyHuhHr0OCccU
c7sN4K34dN2F10u+phFH3ktFfs2WRtOZ9y2Hy5BfIQa9vio87FvLI5DEQapcrYOFkhJD/3s2k2Ah
HAx8C3ugiTGs5mytB87nHSMVe95lAnDafdeibTaxURqDIqSx3ImUo4ynARX3ujcyHPjiDloYBGIh
PwQ1AcESUrSMbjGHA3jOdueGJiU472BmxBt5ZtCbTmgW3gwURQJvpb1KyiGNE64Rs+Za8OkHNbCA
LOTRtej9+di4OIOkDfpx9YfZ0HYzk/bwhR580W23I1V9vfzR+aZt/knPBGhBDoo2SLUy5NC47yf/
uuQA183qKozGjfQ3a+cjFGHiPX85fo9Jzw9bKLDDxoR6SD8I/IFMRyCB1KRSraEcTLbVvGLD57A/
7I9e4rjIDwCMrjhWEv5vkFtvZHwZZWIa8LDCZFiJguexWAMD2IHV9RyAk5e7uLKAbzg/Hd26x/qg
JxUXEPWqVQQehntii7UhIm3i1eJUNa/A6CCVylnbBck/xmuM13IAsgiKekiANVFatNajg9kGEHzC
+9iYQfzegZ2mjo0OvBOZDaf2y4rM7ZHHGssZDVEaUts2sRVrsDGqfvXSvetn19LsEIpqBNKVcc3f
kLpRu2aAW6gU4RjNZ9o0hyvcQSP2RiIMaLvMEp/yG4Ihbyyn9mjKKMp6GWfZBhqg60EE1PR5LvtM
LHEQk73k1UELJ4yLFP7iIOjHR2ng3Boi/Qa8QnkQVftEPkDu0HeDgoos+h4sOPcmaxRvk68hulaa
8QeXh6KLhhWmxZdUuq+/XaqkyfmDtUB63eJgFsakjmq2ypjneDS7NkjqI4hfI8spLqCsdT7MpbIJ
XrBhedMW58UiyC5dDWVSPiqGOOszFcVGTQKlFQ64HJGwOFQ+Ji9w07z29Ta0LevmAZ2HMrkRZzfQ
Nd2CcjDcrQQFHBFDD53opRsXwXrmETo2ExQXIGQjdqHob2/zWz9rd5klvXPpZfarbwkw3HHx0uaX
pNHM9VjC2l3Id+/oYpQZYC+n/uTakf1hBSL69usnsSBylig23ZEDZuRf6RgbSVrMsQalNVj6QThq
0w7IKxBOl/oNgVQeezQVRKMWUwy0Kghdthh1BY5dY/d3Ueq3EX1IvVBzy3fE4bdMhNOTeRHXLdRF
tVKpnHxszngRcaHFaTQkE00jO6C6UDU2DaD/sW1kuB33cYmpDRLtu9qCxCQNvUfxILPw1f/DEhu9
TNdrcbmWsCfieLJeXHO1YvuHlsUJpUM0xvAu0yG+kp+MWdFs1YMoB07JdKndkvLY6Cm1jsagaaKk
xeQ5uz+5eIXMjkK/RV62cH7s/rJtH8wT+eSvis0/MduMgcctb2ltYHefjp+Dg13Szwi8fwGxKKq4
Lh1NMgzYqt3S1XtrMtCq8o+rRycJOH3/KVoBuJUr5kUDfI1yVAtyDpehii1+6+P4ICbaeuPO0p/H
v3NoOQE3k7UbsZJ+3BMQzVugMaQCxe07eGGdYlvZLclQrb+uAJ80exoY1/Tz2rQia+VRLqMky7yL
p3u7dX6L0PNWfP7bSdFHlZaVDZ+DCmvCpByikAFE19+cnLE+wvt8a/IKNujeeDidkSskc8yLd8dp
Eno6spfC55TV42R1c9CrZeIqAf73nhGHV40zK3yEBH/kJetlwrdSH5+6SRlY/f8lk8M+GCfPVVW1
gwQ/gs9LfQq3syq=