<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzGQoPO4vJ7PqQbSjLF+ANlUs2VDTkDQlvkuVNPDeEhr7uZrhQ3/oPo6no5kJt5yEGQqcMsr
QMObj99fyUy3v/ulJw7Zy1z6f5golJFDnY3fNXBg4goCmuJfC4ZJy6msf4jbo6db4gPe1pg3vSX+
SEf1NRjDRfWN3l5XlHjQ/1xjnqkAz1JM2tkViaxgip8Kq0yIzAQQ2pYfau/tPeVDO6pMT5poxzt4
qPlB0KAV1Q3Gnj3udIt4W9B3wm0cd2ChT6jUKFHTFJwo43LofB0Qo/2MmmXmVXgkpUgulLe+78Cz
tMTE5e4I5kJu0LPH2mOLoCGhn7x5AH3hl7EE22Rel95Q5NDuRB8GDxibfg71kGWhx6qakfi9/wNR
g3eu0T3yxQ3v11DzxbYP4N+S0XZuURRFGjdRHzY+Wg2NsPTw1ndaCUbXCRJaS6KeW7+I1PpzT0vH
oy3fS9oM/ldtdTYYaRGlL2rhaxJA6ZQxr6NZqZ2qND0IcgIW11dLcJLh5f+rZYC8SR2Tk1RPJX4X
lBdZl61Z/oCRRiOuvoZXgGKR/08vFjMUChMbWfmT+upfdBQf1rAi/1if3Kz34VYXI6Bl1zMGhI1Y
tUHs0wGq4sdMw1VDAgCQG1wyPda7Q6XCN2jFz1w+WeBMjWGmItSealNuY9ZchwAG1jCacTd0kBGz
VwRKc9A7eqYtp8nwa9hV1MBmOC771ignYkrIX5unpWso7micr2EpGX/J0tElu9fPKkVKTrlycXT2
IcZEncLqsv7ycfl14j6du8U48VaN9lgOlZvuTb35E0Sd8WFfW3taDaeGjXtVcplynggLVcLUlVRu
3UkvKmyd++FZ82IRplOJq88wDAbqKTkBjnKGjVA+1ZxsOCkvYSJJLjjOJCfZdjqf4d5/uMi1Dh43
Lm2sNCBOulzprRcD1Sa361ekYVka2nok+SCSmiiUCxxf8tJZUsfHOBZqKfNP5BUgq105neWihBqd
wDm8YjmoOrei2V+Q5e6Zx4fhD48kIaR5eNNooZKzBhwoXVBSkkjhJz4H/syt0JHyCc/zbljJJl00
lXyHH7qoZtuaujq5aqKCWN3O+ebsZwOdiAAO5Zx7HNR6IuPLoadjvwHoJu2SkX19iCNMGEsk7kH9
k2hQfXEMS1JZB6fx4fQoCaE4XKy8cGvC8lFCkE6OLmu0fqoPVWbc8/V3nDjqOMWbhAmHVdUDIMQ/
LouHBqXL2SUho8S4Th2ysue8m+rXMX6ZZS/HE7gtNwi4uPRuhMP7XOYCRbvVRngrdSPWW5AQ4wNA
W/q4Um+uus+FMdeaHvsAzWt9qvlaDF2VWTaxoiCgMZ3gfQnOY8Da/sYzHBJEKl9d/Fhh2wpxy/aO
hMOiM73wi91wFSSdZCHK0l5xwgxpny5USi75K7cbHeq1tc2/n6t1nvDqMjmLZSK5rfgyw6HfSV4Y
yfHRXpDX6Rsyu/8Y4Q+BqNGxs7Ek/ZbFUqx3nb3bIPhYolzMqQfSS6xCkJ9edp9h8cFG7Mqn63ca
UtmgOnuWclnHlF8LeqimJaQt3xx8aLY0gCDftWpu2ynsrub0+3rYip8PVoeQX8IsnQeuYRmFCzGq
guE0E/+pbhjBlD+jVbxDceMUzevBofvU7Eh53KzWUEYvURAyBWt/cdy2Uwb0z710rZ2IE63R4+AR
kklupv+1MPjR0sB/wY1EqgPis9vHg08itPXcbxsPwC0j//NAlPTVl0tK1ViWoaEUy4+XIORPvA2H
S5egza7MWFdhGc1n58NXrN6WpX1hPhdODd6MJ13HkULztSTWMyceItv2q82P/S9y9x6PVB9xf44T
M7RntVKgA+wZrvjFgIZg6X6a/yUujQ0I5/kTjYB5BWTZv5MI2VpF+UHei2LvSG5deM4fVNe4ttdC
pUsP1u0Wq8Pph4eFzjdrHz7lxTRb0kMN3cwkg1o4CaUM02tvcHpYptstndoIyPjtMOZByp1uODqe
OGl0EZMBhPEnG+3tfoi54zHUgwmraG2b8+L0T75kt3xbZacHKGwL0vFb1mnuIHwiX0tlKgvWIlb3
yd26rv9qKvscdY9DOiFNeZYqLeGD+TxM1n4VT5TmUTjAwsOZnHzNXD35s5krITKDGxGh5Xex5eke
Ra9lYIhz/KLORq3okZIys08WvsZonZwgfYclMQ/N96aTWQOkS0ZT8XWQJ3adZoRbX9fDb1GgLPEX
saugyh6BbwnbYsr9ss4azXc3928z6V3AXeOEEkEKC+HOpCs7bcYOFwHMMV6ue7Hmw1X5EH9hiuGb
o068Gj/GczvtYYNL8yRw96nVW5vqEjLbFeBEHYq4w+emwvZR7X6B7pselZRWcG0l4Wdkf8tEJcDd
gX1ZvOWVoyC62+YiGaBMHW0P8BwAfVZpUyAMe6Pq3DIIZV9pi0cfwty24+j5SlXYkj5XfaaY6Si=