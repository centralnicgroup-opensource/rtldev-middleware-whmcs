<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyKRYdhW+Wvz/QWVMSSHLST92y8BguHu/eQuVMQdf+S4OCKNkTvIdrRb9r3ZOxzHborqktCt
Rrwyjr4RR/9W/Lx9V/JxgBxvgqZT0KyOJMNu8tDC1o4pz9QhLNgEJbXdJ83I+o9siwwoONrTvH+F
SXnvlHVIy/qkuiUsO0PuVy3tUenZY2XLJ7IBh4dHZGC0rLFPFMhpUDHwRKL2i5+U3k3ml0RoA0x6
ViW9USspgay1bueYz5Q35AVbY5OlGaZCSgIIxIqRXP/lhvZxOR6zLnCA7kTf73bVlkK540djFKYn
ceXXOG/Et3SgBoNDOWTWZcPlaTRKHZ0v5ryKQvxQllxOwrCFEa+JPYa++1KryHjkTyrWfQKNB3W9
sY8OxQa6CHglDxIh67AX4roghRCY8mIBOLILWlMQD/SsjodCb0c5ek+v9Tg10L2TFPpwb5mAgVmC
1nYyC2RxN8weraJUX0koHss9YtzBQtqBdvYLLhAcxvC5jgEZpoY7V4vboEjY6V5xKL7M1cdUm7DN
xwUXG2CFGrLQPrdgmIovVx/aZPCfzsuGNzvO4/n2G7LvAKW9mYw4wN//jQoZvMpYLoiEX66O691o
jLVKjuVQs63gziCcYQFPo4eolQdWBXJfQ8oEnFyx12psd609qq7xDza1XHtOW9aWGFTW8ZTocqL5
LyMid3U1wmpIPGz25u+99X7zhWnNGqQSB+YZirGhsjzeBJAEHErssCTPFI6hwo3NruEysNAGOAQ0
SnAqBWVUEBoR2Wkwkcm9R1Eq8K2UQOiYJIQHjVMqCXZhE4QIaRn5kxlYjJXyJZStnrq9cBmvUpg0
6RujW4beDKE+MZ1VZMl+GQd9vYlMFmFgCL4dLADxtXiGjrEhLxLsVUg5JYu0Gt/hB8XGqNVQLNAL
Rx9uUnO//8u+fIj5c9l5Jc1cIonQXSZdhZkCrbHy8qlW4FVGg/YPEvMCh3S/U56oY4+ASt3rx79V
cUPawZ0Kz3/QA+YgGdim58HbB5vGZ2X6EVymq1jEo/q6WW1l/6ycS3wAgYMOiE49YcjHEkLU1BJB
lt8L0uavo+5ahQ5zpPszA+lGrpirTH0k14xjJjTaXEatPE5s9WqFbfu5QVvWxiuWtVCzTxnXlXnt
GaUNxhOUE7Sd8OSjk2Di+hkFbC5FrWw2fKSR983Ju7KgHBJy2BxoGz2uTg9xl+WK5XQwWBVnXrTz
PyGmBqIsN3uTv29Q7hVrDIoVMC0PqVeFphmMWuqPiFcKcAt7prjdr0q48UT69eV5cOogJ3vqCQPM
dowkHHh0encsUadqRHLdtG6k3Gqe28RoZzeNAbn49w8u1qgglN4oILxTkHNNlw0wBpkqXvr8Dv+l
4nb5YHpaAaEOAQvlFmxOjuxhv9wwy1hY3KvQNRmAD1A6c0D2b5s3caqHQca3cdzWkXPY8fZqpLOY
er7/fBp7WjIV4qLUx3yB2CzCK9j1vyG6O7PtqoGLTddYCZixc0IY8XInx5priNNaHksjkWV2VAh+
+lqwsOsRjlm7Dj0dpJPhvvIHKuTgfq4zCVPEw9wjeIvQB9gH5bba+rnf7HQjPRRMxzrLIQQLLbYT
KRt5edA9EJtV2b9CxrXYLGuhflXslFSmJn/GaSGi3/P4ag+k06yLulqnPp0urQPFyuURNAoc8nwZ
V6TMzAk0Fs2p/r4IKv1YWOdPHrNSXdg5tnZ/gDi636w9okMIXE+eMgMB9EviqAncCeADtjzqDq3f
CZtds/4AFShq3erZq7Xy9BelJMBjzEI2WusTzirpdIB5+C+KWPgQwNA0rZq54lzZbezJp+XP2EZl
VL/6K7cDdART4X0ws0GUlHVDUC1WjaszduXppbz4kBW8sfJIYkmcNlPO2gv7tMu7SYewRTje+auF
+lfJGye7+lzUtT0rnezi2ALyl9fWFZNx+FEcvaGNGTbvylOXNMyUL+Qb72+C3eHwSJ4RX0wxc3MP
KPhheUDrOtDqR8+GMJuvnZf2KsZ3Ztjk/ML0eT3N20CuHw+pUUF5gsRoXa0BzEetnrFaJ0AcElyQ
iMLJrhwjz/NpQqaLSrOqSkfYIuGEPNNpEjwJfkF9vG8zyIY8YlkLKcub7XDSJLcJhTSoCw5oT5GW
T2lL4capGcpbC78B1Wosu7YBNj3DrvYmsEL1zPEfqyOt5Re/3nwJ118PUGSrM25rTzffpBb5NsYn
tushkCBj6jhT9bB5hj3W1u/ECTYKa96LftxF9wF+aDjUuUjWqxF2U0ZpE3SFziVnX2o3rPPm1sAY
Ri7ncAN7b5pLZDrsSdfYubAebmf59QXP9KBU3wvzskd3Dp93btDonj9Gsgn25T2hwxnqET66CO0D
tQXS+cZGdynYuW86ydLDqtTGThGia6JalJem8iVPC8V2UTPQQU7ik7DvhUhafZPwsf9bESNhPQ83
wfUhIkwgM1CI3G==