<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxyDe0R/9D0OAOQ+DIM9+P/aNAo+Ue1udB+unfIvjzyTBvb6O4BxEjRfnH5qsA5/Jq3A/nT6
SsaYRpZWv9/icioO4hql9RsmSq54UmJpWPFROzTBpg8aDgOsVTtuWS1WK4c47MXJYc510ztXJctD
2RxhbqH0OjubzcRG47ggC9pbjLNDSIGC+2Onjc6xWp9bhZSzNbUwfFrHfAsbI1QwjCdN/RxxWSTI
WngQvIUR//7oP6/+4GvQmSUjDMTe0VOSM2m8nj+7fmxavcCZy2lxBYlnliLiugpBjhc2GS24R8+Y
sETKVpN/ClqM52aulbiaLFXk+s9GeC7eydLBoMtx7B4ARwVzOwDTGVEm8WCp5zEB9K+HeCB6yghh
p6f3zgCoDLvS1xqkKyCU0mbUVhLbBJQVf+g0rUsXJzRmOYPQuBUiFo4p70Gv7Al32ItJI5uK8EBE
VsN8rq7yQ20okNq7o1Jc9uoKxbD/s/o1+1/cRQrFKE9qOBcokgYscefQU0m5zLwKG8XZKtXFBXag
vmDWhMLKG/CXeNFlUwdQdC99Bl3RvhkRomTCP9GKur+Yx3Gr3R8f/rHiGExNvoafAH2mzVq1N/Oo
/2PSIZrXsCDIIIwGQzQpJR+0fVNaMqauM8bkIDxu/713ibTZMecKJxF8wgU9Hj1BP9iDfVscejYa
AmNEqNFPyXn7S9H4gXvgPgaf7CIhMVYp6WtlU1DgHXxbYTFdtPgOXeFl335qJJKerVSPmO++WFyg
mc8s+619louACISxVJKzl09/zJrwbr0+curHMuAOkJJ8T8eHcgI82jCliY2FCNYMcy+z5MiPc9ql
4T8EWPnlfrpnPF1RqRoYCgnd7B7mFQeIIumArJ+U/89bMmsFd51Pechuga8RKGjxwnr64LEmNktx
+FDKkVYd+I/IiwmXGUplhiC1fWgtYsBjIquXJtSm+gOW42GION1PXmJVgYm51BSIl/KVuIDJMNS5
CCUybf2qFT/UF/zT9vZKyOQ355d+aNsd8agiwaMi6hAxX7U1+ZMiKQaoAxMs0lpiB7HBqbh5T/2q
CERfOLsq+MKkMcF2m9ypJH527JhsLZClukJs71ocbbrPU+fmGDeWgwyd2Pbk//+bHg9w8Vet9n+3
UqxhM1A4UXvPo+1nEtjcPVtGn69kuZKnJuWfntq47RQqymkeBz0ShQZGcDAUb5G3oLEx/JdN6z2M
+ybTWxAcyIyPo9Ytdjy2vWY9fJxEe/41sIO9fIFIUYRSw5uDwSB3qm6rMripUz6EHmQSFqruPWpE
5xzFSf4ooxYAtKKbvcbDknrJiZx9S+Id4qfwg2kYFcGHg3gyxu91tuTjofBX5lcXLSmHmKYdp8U+
RbjMouaYNTS4uhQGfykwl+b2YKGR/JXcRjkcpBoGlGtGvw1HuakKY/KkyKGAyEZQAHIgWjMgFf7y
3o7NEPme62bTJgUBda4mTQvgImswmAsEZ3S1OKP0UDIQWfec5QBLz5LSUNSWwra3GehfOjzA63qB
6HNxF+jW3q8JhWMfPxMQGNKzdNrhhkLgakdSfNHP3leloJk6mGKbTL6T1zmQL6IM2uT/zRA2zAnU
DpLnOGVKmolQPx1VsB1cqRQPpphBTA1wChq8/yYcW/QbXoQ1cJ8VvKYANiunqFdfPQ7vohUPmp+m
XKrbxmX5xmjJon/J4p97pmlOYwXmTiIPNIOI3YxNCDqSImsiwGiuMffqrvAGaPqL8cS2X1SNv8RQ
JB0oPRziYvKUcbBeX6vlFVl9fW9XcsaNAJ04dY6IEJstDwAF0XU71pwrfZPDJ2KWmwJYLR9Ucknm
y7HlfQg8nZQrxNIn4rFf7USdJaweCXJ6wxd451W6UMyH2qL2qHrp++ZZAhAadOKzbHHM79tZXbz1
h1Q18UHynzqtaZYh7auUCcxsz9Dsx8YSTnhtFgY5xVlqOp0qZVFhr1fnPwL2Ga9MLUz2/3NWOagl
PcP/DTMkvLzt4JKgRkBM8qvfyd1SMTrrZ6YDLzEenpe07CsavXHD4PheKZ9kTlzLzKvFbfHVsvgD
RzjdQmglJutrjLfXkjtX2SyjdNNar/SIPeE13SGgZwqPgRebFxg4m44aXrHnCJd5A0LARu7eELtK
p9nnxIH+StMCc70pKfvR/+VyPOFbty2wrZMUN2z3yIijAuZW4QFk9wHTmuzIUQjZZTFz1mmJG0U0
+z8K9AdmQDkgnsN0Mlm9SLVJRJWmP3ZXDLU6x+9A7hRyzBIT4dRlCQl4HPw2iulZcRyi/xzPdP/v
xAcXCcULCp0ANaidSzFY5ztunGSJFqa8uSsXjJM98pPtkawZ1SAikwEpvZRjPzPVIBd5HwCN5Hu5
3qpmpgJdvKnIvy0eNKTjc7jgB5rG8Aya7Q7EYEFBnXSzembmWXYGfvgKCHBAU8v2ExXFDK18xGhS
tfhCvkqEjYOMWYm=