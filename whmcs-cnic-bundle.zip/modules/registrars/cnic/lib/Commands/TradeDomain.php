<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPowWABv2Zv6n6nEzdKeWqCDUxfvIgTjvLgUuCKh6kCygTc0tsWL209wArzchTUFW6PoPozW7
QnDhTL7HWpG3EdcMh5Q4ENVnIaHjWDlWi7WtmVkf/OsxBVua3PxruqdtnT9dRh68XqzBi29hrpPy
+0F+72WEod+0XFrpkD/sPVwfH75wi0+n3AaIXwHzz1PzRitwMgDK/VIzy+BtB4YpglWDQ0JR8Bec
6AlFCcFRR+5ITiI30tvCdcOnOcsqR8RdI14ciVziFXhP3NoA6aoR1ZAhpKThAwP4z0IYRAob1GvY
t2PKe4aZ7NZCxEODPIauXeLgIk6NC7dHQchSUp8WhzCeYfS+dLMfBapMnxZvEea90AT/RrO0D8LT
CYmvjNX7b+crEy76XZQJJumeRB1GaTGpyuKjaGzS1TIj4vaFVTqcQ+U73Lt8y9BUUUCbXBUetpq3
ShOIqgJFEtzxePxwbiQmzFjTzwLUt/WCMpHz1q2DNUCLWAUSiMOFdZdO61hO/Qh398AKrsucTeso
R0vhF+otlsiSiN0FHyvGGL5/DkUALM1oWNFs+YevrTi1iKEEIsityXxR8clisefw1P+S3h1cV0Mh
ITbY2tQxvcw+X18SPEbTubV/tQTSjH5l4zUiK7C0SlfpGXM/gsp2xuB+RopjhgpIC5+zWyWHP2oo
gKxIjSB0/Zz/GDnRrugOV5ARHE3xVeDe7njJL+2JTIuQcgTdw8kUw2Exiw3QoGrZtn8AE9NWCXLs
Yu1ZT9PTx7uBKmdRsBim4wzv2pNSDRngZrvpWTXASfGoXYiAZVH/8GB1H2Lgk6SW/5DQI1jX6YAx
3BhxoaGPyFrLtLvYq4ACrojFdpPFIzubECigk+5xR18vcbvj6wGlGEBeRKEnyeGGG0s4fqRlAa7G
9JKOEPkCwqix4MbnsOCT8nFhWuwYBz/xxBJ7RJA+yBqJDj+HQiQrwegfQgg3NRjGqukoJPe4HpUu
WCNpVox+wC0MmzrH0LDW/vcBe9IG751d7LUySiv5LrS3T/3Ar2kJVOJog7CjuY0gnI+ZehTsqecU
MRXbmBbca0rFE9FfKzqaIH0rZZ/wXYGedr+VSMz/isi1k0whutoXm5Dfpd5GcPF5E1Mwm1/AQ5Kp
BXJTZ/MinQYmUO/kVkq+q7AcyayAKg2iSEhTHWvdqowaOhe1+vLcI1B+RchZchfFmrUl8xwKi2ui
y5kLjb9wzgXF4a4/g/egQtRIceNLmHqmD5Ahk3/4WDZOP7xzhZxPgNPUjTwjisLDKyWtmSEcJM9o
X1hacunIsYVnjWLSBG8DmYjJa/clMg6kBlXB8AYV0GxnIcwuQBCg/52PErJ/sDXLxyJkTs5k8UHT
98ZmaBvkXkmC8aARd/NEVBFgu8PfTc0wTSMfKIpSJDUDaspJ5lR2KOrhtcUm9xpI3bNGlbCnXznP
UAf5XQm2huy1HgvrqhHGox1/UQyRhj3ddY8bCKY1Xubr5jnSnpLaKSoNNDEmP+yXuKXJ8tK7tpjx
Fu4GtNxgfPM07uiLcprfutRjFlmL8QiJWurYpid3QaFTyEDCcFmtt+PZ65pC+ET8biB9MfdyIsh+
AX0aSgltPYxmzdSQTKLSn39T16z12Z4DqCK6r5IW3n5DCI3yDN1Gfgyn75d7PG3KIgu7do9Eoq/s
JYQQr5n9WG4SOto0wiUERhyr36B9EA7cqu3UjCtCNW0UsvIuozmBtuWWszNiqaz+21zXO1cferg6
UP6S/sQig485b5x3CrWGOz7XYAmtF+p28fLxOn2tW8twYb9nHVv+cASeqgKhYFJTruTTl489hh1W
LIMB+SOLnXnyqhSfoldlWtuiWOAw7vx5GNCfAiC9a/zF0y2DaDUPqFu6HQj3j+tehuR3d+bq64fV
0r/qwFc7cdyB9eUvPr0vjZN8/6sm3eT0BrsMMahXXF5OTYH7C8ugMYKMZ5MivlUIsO6eeNZINO5e
C1Z5a1j9jKGmcRdorWbz+FygbWFyci0b6OvtLwdn6DLkJ46ElsKGyL2YpsUsxMTY1hu6/+PaZ3Vd
zgZgHP4GpamnIM+mqpAlCs20OoJFfqRPImRmzYqmnD5ZjlktxCDB7zEtHvY+dJs/Sg6wJXy4Fb3q
tWp9Os056L64bovdVtsvSud0zqPQu5YXFj23d8GgyOEBaaqrS4Gd4rr2Ov7AJLG8lCGHzsI9tv6s
EAUSQhxXYjaPWQ8E0qL5crtrvinCq+3ie3JX5Lb9gVa9HRm8gWTGpDruDhmbkfNweOU1wLyqWpkw
ubxCDjJZtCrPggBE2umqnovGlEPAK5ZliA6r0XkaLUTFmjl18xDTZ1nI31zeZBqLTpBQRGX4We8g
iHhUnUxQwkeig3BmIhsFtAxTxhwa7oyho3fCtE67c9AVirSDnGKo3ljQuE+RmUNy+kyv1sMSAwOx
uwS/0cyvbTze5BE19ZiT