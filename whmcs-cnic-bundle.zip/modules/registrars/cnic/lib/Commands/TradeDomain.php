<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrcjGKQ6SxffNnxKPSeuYwdJWSMAyj3rmVoKkEcN6fPKaxqS4GVbzrGNMfzhJLsnXxj83a0R
aLTV1oT5jH9JM0B49t2Ir/kJ4xamLLofB51QwBKm7Y0IErFKL/SEVwSlEXkwDY/UwsBTyWyDVjiA
lVdG9FoMWEFOY1zd8xxASLpnyCeBXiXHifdE0GmxCiG3nbq4KVHiIsywAnaJhtSut/cF56W/I15d
wCFLhXjzLeiZeeVr0QxW8QK8KdcP5a7mDCfvHmo6K66hKrE272ZodhOOIbtlOG2jHEVkolecLJ4O
5x07U/+wU8tp1xiltQVv2nkr+AeomgfdFyeYM9eYEiBHYKGbQP0d4FhjeBx8gvwLW3/whMqwxj5+
o+yqH9KDQmhXUVr4oxULiKf81V2HHh8kLSRZSNCo3mk90xq43RJ845OHMob/ZL8nOHBivP22Lhcy
nkGHWFXCmbSk/S/VsleCOiAZpa7KmMmrEAHmZNzIK7KgcRA4kms9+xaXRw/W7Ts6T4rZCT7vDlr5
vH9fQHgfN0DHbxpKWBSgS7CRTNsf498+WyoafVvrcArjv4Gf2D00y4NcldjYQEsgPznF8MuFUcoR
HFPomXX4od1lK2FsLtR+7weHetAMteRYscXkHhO7XrSQ/mDwTVnnPcMDcfa/mmfBlOc6DeyJ84AF
TOm/dG/ZNwsvnkHgrQBtNWJAMsed4L0YzsMoYfn2+Fe63UKf2F3wskOseIj+B8m9NiBq2xT5XRO4
6LBMJka97eFkHj+SBNC/vL3+iKI2Y3ll/rJWrPm3PySp5iZlrY9tJtt7foeETxLArlhweP2g/k4w
b696boJqOiGHIwrDHEqaqXngkOWwhsY1NvgrGRswTyej8JKWW0huS6wfWDeIp7o3wwBkoGlilteJ
0Fgp0iEpv+1n91OxUMn0joc28lQiS5ePWNDEW6izOZV/LSWXzGV1IRD/QH8LnHK6MrUOolZxkh07
Poo2C32TkQbxQk/aVUBo6IdmvjsI5qSw1Nk972JbOhNIVl6NoayOe9ZO+1caFkVLUtHPiS6Rn2Wd
5hcMhNVeuiSJlMjiSi8Q16HguM/lGScfBbyK+pRMwMqq+rawWtXdx5hb/K0MaEg8m7wptineEJ74
Di4JaJk7rKeYUSzoXDh/Tuvdit81QQIMEXC4GuQrovTpYTCRsV2aEoOckYzV5RHLXP2w1M4xqYr3
2peiBcZR04bGC17XG32INqk1iBzKfYRIr9VOmKx+W62fDNNnjZbQFuOEro4pW0n3DTqvg439jzi1
dMOXRwt7+PZn8B9+A0mUPHjgkBwl3Sr+mwKcSRwX3nPEmDK3BVyoXHRBGvJmzlOapJYaqh+DR9L4
fthaiGXLtj3cgFj6Y6GY30izmqkTi49T0s5WmIpANLp23Xk07w/DoRieiOYJjERbmHBBWuwUMJsz
Pq5Pgf4/O/1alyUK/Ib6t31RAmGXDPaZEDtZlBp7xflAm4Zwfez/AQ5qc1lko5ATH2Y1JNHWsZu6
apeH94trsLf7h3/HAgbm1ROHNp7a4tPZm2nlHkjdj/uaf1E82qQR5BWZPlmnWCeWi4+8Me57d27Y
MQYhd+Aa6Rag8AVLjIBh8b1SnYg0Z/tkT2TjxPU6m+F1i6QifFJzTgxh5iDkR/22/PrtgeWKXWtC
6vraMoV36Ovb/r4zhivK8DgwMRUhxGWTcip9Pc1AMRS8DZ9Zb9q6GplZjYSZhhI3iogUBSafedMD
KBr2ntijxKC6/aPXdRWbycPCttesYfu1/jMf7GnxNLZNPZ8YI7ChKUU4W0AYkk/hAuNPe9RmFZNM
paOfdAuakXQYyONVLtXFId6v6uv5UY3fZVuo6TvByAc8kLYbn/OcBEPy6XixcOF5va1nWmKTCsnV
8FYVVQUlFRHz6wEGG53f5pSzLvuCCLtU5hw80/hfbGtVXXHFYvDZtbg9N5YzI4ZzwVbyQ8Cl6Evw
9c9HpQnMrSGPMrmtBIMG9Nq9PRYQjR/Cj6KFlXV1DYN5vkVV8JZ/An8AeP5/dAzk3xRyx8KlV+0q
YxbZqEB4Af3iYrFbYsJpVAHW3wwvpjmShupv//p4K7VaMJg6hTEZccwT/I9UrKkOEhcN2tvguwBZ
FYTmoArsux+0zT+4Au/dueV4w0CF6wiAe1I1lpjaJ0CYZWDuUiVdAa6EkKZfn2+YfSUQJQVfNERm
br6yiYJgQ2zIBVnZu5uIhtsRGC5FiKHBHnvWptaLSWX7euCiO6loPDtjcF4eIanJBjbc14NxNY6i
Q6+4kZJ/ypsdSfFtfKZND7XdSe5Rt/h3e9r30W8ug06M79RUCJ96og6CRdohewP3Kulm8II9yXbB
/9aDJ7ULJ4EeQ2NMBG0Y2wVBPQg7R0EXyWKWVXYgRLeHDuh0mKyMsrJPB3GHzdgshTOGzhC=