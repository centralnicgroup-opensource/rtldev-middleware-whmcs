<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPne0I2mjxx03ABFT3qKb646+Zwwi3Zg72e+uo0gQpZ/5+AQPtNiuGf0YfWKJGdpPMgP/edRj
vVVmUQeGSMePkDFbJygnLCKhGNme1WIHXMkB7Js5XL7GVJZd+1BEn5ksVJNXexcwDsU7/eQOMjVE
i+BIVky9sbJq0sJvDaT/PYVVEtQZDWlvM2GxtNl4zP9BSaTcJA4VyBTGHhzlI0PXfAD19CIeXmYk
/tzipp26p+IjSf+3VXFMWQ0UMr9fy+D9EArUHN4kOM5PifqpQfusWHk/de5cjxCaXU3NQ0Mcre+d
hcOxLc3M9oaulTCc7GcSixMoi2xJLFmZX/1wdF3skXOcX9JM0fk02M1/plWC6kgtD6ch+ri9K6YO
XZN35td51luFjUa3celMcqMW/7E1u9LzBY61kWMT6PZ8cszLgCC+qOz2X/0nN7vhHoK10MoC4dYh
/nh9OYoyByuxGyiYiUhh/Ts+ZBn5PL19rFAO46vz+/QQo5uuUAiRJBd8DCOgjwNW2+NeLVdSuGzF
lay+9vbjyU3u0OmkdWV/cj6EsJX1ogRWVLwgo/HSoTX9U+womfRVkxwaaw/r1D0wa9jaoxobSvmt
q0Ihna8mM1m7lpJk9gw1XH0Z+C7OjSaGMpKiN1zRMJ7aBo53GQ9VQ476dyETBgocdLnnZtr6k2rg
vzEKXx3XSsHXizN/w+RbNV8YAVsQ+FGfFNB55xZLlQss+Hz9h2X1E4Dwtt8JRu7eGsoxhONgeO+5
6j8laZbTeuY1D6Rbhbc3+o3yCEo5RbczQ9nvSS3VX2ng4ruNX5hVxtKbnETT1hjIuL49H+LbqG6c
8BgCqD+W2szimdDMYxYY46x/MJipbl55WyrMljYxzUJcP0pGBtexFHURhJ+3xbfEhdXPVL3AurJE
lSDPjrgSmdAkbIjlyyL8vb6YeZ2WSJHkFHLR2J04RoaRW016EwJzjwDazzIH5k9R+jfR0yOdGN/Z
4LDaXN7tXlo6zrbAI2Hh/WM7U+Quglo/HXkGgWZnQVuO+Fj96dBQABid1KxnY6wDoxM8v5SKvpeg
M7Muu/nYa38pf0q0sUo7n9wNDMd5s9Cl6FuIIO3/zRYlBuUUd8aX1UF3Qu3O58um0j1L7pqUx2pt
79qW7OHnQG8ir4r7E/wEG7btY4OdaPcI4oLhb0itCOYwsvSzf7IT5tQmCf8TenMWUBlc6SrTJU1X
VkxAei1IeJSOMpkhxqNd04yay1fePbfxnLNzsW9cPYfILm7R7MDPhqJdKupY1wACJRkPXQPvaUD8
HEf1I9KdJOJ6YLfUm+qH+2vfLbHFiLqVbTC1H9ecSPsFDn0c6087ggq7WluqUIrS/z+mEKHic8Cs
0JuI9L0ErhpLe4OKyF3F2YFExgaHMS1Cdwu0IzFykhTrEPmPovB7FaDPbbN2LJlVaptcDodvwIjr
TOR8w0BvhJrYtWol7hpCypkF6xtES6MHFNz9raTqEUuVYTKNOqFDtUy8xln71/lqGMgWNt8veVhh
bouJY1L2yEg7Vl44xJrbkUDR+yRtcG7N9P5PMXlJebRTYpMfeqLwshiYSnHSYS9Udmk7QO3IuNLk
TuybYpqHtbuIkTCtt2PKnGwX1fxPrjE3l7+JAzmkPYlAJ0XM5ghWweh3pPzn9aVVWxm9n5OMV9xh
lcYN+XaMXy53mqvdkfM1TqXBvL3Nz5AmRmI9MJv57ziHUxkYt38dm8xWMFhWFWa8YLL1ZccDOQvi
tJ5p0ijoKlQFJM1bbsyg6vBLrhhCpK8vj2WktZ64Y/bt1CtcXQBsfQqtt9EEgPI239bkk+WDe9kQ
HpUgONcThNwnIlZjeDkg5ZfqGMF/1+kKZSZ3FIAvtaqjrl69OVZ0xS2b4YtgA34btiMV1ankGZKd
el+6/epjAo4eA5YxYKozjTx+0/XVSBL+K2eWe1t+55MFBRLb5RHWCPlLmIdTWfJ1LResBEiKjJI4
W+1jr2pTmfAGSMGdEL+NuL05Cu4p6xqJmsGI+LNl5Gd5u3tiHEPaENxDRRsjw4RQHvYb25xVQzjX
A+U868CGR3rklwCdE9iqZw9bfkUdxhJKulrVjUflIAoQ0399Gzuax5uV+lqjVBX9oo+M69DbTxX3
CNkAqpQUGBk9GsNbE5dCnYpCvj2RyqPIEf5EayWmfGpKY19/ChMFMnGofe9TPUcX5bcBR39D/Rzs
HwH1wqfM1oYMtfRn26mOquk9MFl9C6ywslCaVMv7dqSGRHV/GUPKpT6UTk2LZ4xUoLYnTgQYJbJM
B6K6oT1ATeSz6YYNbA7zyJkonNikXmBo7XgoU1gr3WJPwDrSBLHdGhmieTBmJCh6hBzfNYtK5pCM
/ZIJDaLjaNY23I0GNiOmMGqxZLIesQNa9eH6+29i9GdgaYIDjys0HJjEwECY/NYiHwajUD+/hED4
9t4SRc2eWJyZN9Im3I0ANW==