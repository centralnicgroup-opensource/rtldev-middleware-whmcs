<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqLJb+6QlMlMO+02mhHW3O0+HUu3AgUDY+XiFbfm0mh4FZHNdwJBMXwtxkmBQIzJSB9Cqtps
FWjBxm6nPwLeHCJqNyFLNIFtc1gepyp9bSW5W4K1t1J1svO+ZnPHSJ0qVcVK3PExKjEGlsrgjeJs
O+9iS1KORMFKw98naVlHLmo5p2Txi758ealqnY3TTzAiCTfllGz9O+MPKhX9v7nlP2ZUro7HTnts
VsiYydxWDki1TLJZLNcqb49wd/CwtAtuJcxCIEu+vZTL4SIu8of24mbqKokfQ0vATBxO9RlZA7by
tNk83y2mN3LCQgW1HYOzu6LTX+k8cVd6Q+nZFbrbA19WELqimnlcqhq48/lDAeSsTiLV/kKnbr0b
lOXa7IJPBDFp5hGlmy7NR5HcQE6n0HrrXflpJ9eQO0/XxpFX1u7n7B1yjUGxKOpCbzOKRS1MzFmg
WIFaJO5b2Fef9aNxeNyl51O0txaGXUD2d7K7x/idCid/3KbSPEa69Wo+cEhFL0p45NAIWt+x/9GY
Nn8OhH0bdlMwc5m7oF79rUeiw/nv/+beMYoFs1eYEfYuoeZSKhSLdCd6sY8751cckacM63KomCXy
7OLJWkQqOffSFniqZpX5DkrKDbltmMfPFVt9OW7MGk6N05gr7IqFTGT7RuKH3RWCM4Xr8M5A4r1D
ihCQdUT2YoneLiIxKFTWb9BKKPDmbUWaCqinLZtAjrAZPBSH5kIfFwsIjVWfmIvTOOowDDb4L/xz
dVtjLvEmgmQq0QGk3Sff7NyVXf4wmH/E6UQOD18wZFycwfeUR+xA+R2UjO/dNpJ1biMFbTsuaJvm
fXhqrTFPuNeF73WZoxUqNGvCBwtOAUcaBx55mcdwoQlFsI8pZtlD/df4dsjy1uWY4brVgKIS+dmZ
T5T7QkAMmq8Tm/VuFm1z+R9GLmooJMuuJe74sxRcTHGvXMESp6meoKpyChvesLwHITNor6Y/HkDY
lpk8THJ+BUrMyVP/E2c9+WEKpYSbsKF/TJPBwksND0yBzCDyu3c/aUtR6NXW01FuY16ehgRqYikJ
dAnbNRFLyxOkGdxrDJCHE0SQxzRhx++3YJshZ5Mkwlm3iXO0KJPn0IITmPsGhywXI/c7ZxFm5sRC
zrnA+X70MLIWvh5koqMb477YZpMnM5d18E+IZuERUWqE0QcNASN4ZPMiw3bPP8FxlrdzdsZMvZCi
B1DQH4G8xaZvBluFVUqPl79LUpDtWOgDO3NVTkTKfHzTbcoU6Gzv0wip3S061er24xHRXWBUxJ8i
hFPOzdBQqBX0uTMpX0YWySaJuJSQS/Yy0TYid4wMX27ZtyxSH4irx9O8Q9GLdjPArQtDKF/rq1D1
HtRZGksVjG2l5lw/D4qHjGfIEJSRWvapvGsB9vyWSTVMCsTVVeoHlsWuSgZY2tVAmGZXclAyCFh6
Xj0Iq2xH9n1rI3Xm+SdisFUGuQ0C5xb044HSXcf2krqNi4Omn5uYDpss1vVX1QgS3v8Bb46PEIvl
3EwPu87jbiyCq3YwEP5mfJal07aPyz5UxwME3lEy7AXJ81bA3ix3wUz4AwA/gnavzz5z0nzsDB8q
axATx0YL2XIoHWWw3P2qMHbiHyiDh82Ty0wX4RqrfqEVBdTKXFb+ltLmgJD2hB1nKwQMtDs48vZx
WReu9kkJd0Xb6t0eNvqBKTlZ+z6olpjXaaqdRmjIZ79upmsCMtxkSGeW4vN876N8c+jMD3LEt6ZS
/5TEVjWd7HZu5hiejG7bWC30zKHZze0mrkR3pmg3JuW3x+X9hh6KRpuCyi0BirNlEAHTAIkN1eob
Fg1JPDLdD7kUYexTUHY0DiJBDintS1wSPHitBWGABfSaq+wMpsn5aagjKV1yI/MuCmaYFpVEVDIc
WOWd4bmrKJP137dt8JSknTti1BoRT8Ue40wnFhrQdiyiPcyBNfUe2P00TqeVYQujOFPQtlFinqAU
//bNRSMpYBa/QVO9O5dFqJKro+JTWXxsfrKdrtulZM6C2O2HCtUgyDQYf0MmXOtRVDKowF7yOehy
kwWwRqV/yJhAv78v7YjzA5U2Ok2kESmb1Oteextdur5Om1gqPaK1APCYlZMudCqe9PZwHUku76hM
C/y17JRBi4Dg+7armataS8tnncp0wbcyNPNVKrWJQNi//9ThLm03q7IbAJjb7kSmMqk/I2WXGlRB
V1CH2IyPU8lwddNC4hdTlUOIvTiNmzlVm90+2QVBk3lDgNRG0lS7y1d78iZq5SaC+B+BZQKOYFS2
oXYfPJcN2r7yup0xNO1qAshEeQzrScjVpUfoeV1evjnglw+heJlxncP0Qn+TI3gqQuZB8nAoYmeg
fJG9w/yPiCrMYTBgQ/eFBwfT13iptaUnRA9SQrk1NqO9MXuUCgHvkGsIpm7PGQkCrIl24SWYeb8G
cC7SIERe9kgQr1mBgEAQHegHdm2IFUEvpXb67W==