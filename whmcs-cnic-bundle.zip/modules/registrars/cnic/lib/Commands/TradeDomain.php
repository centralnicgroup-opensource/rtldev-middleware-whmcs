<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqouKJknXgh/fqmBn1WdLcqlV7kSvDQr/VDOZ8nAFtwJe6fb0OYSDlNjyq9+q2arAGU4Fmvw
BrWharkyiFHyvOwrBromeY0bhNcQJ90ZJpD41gs9uIf+PpFAPkO6hBE56NGhBy2y6/MI0h9brWKi
sO2xJfDVf6ZBUWENkHhLc9Wr7lSbir5mGc8IGHectxGbBavX+4YHsSnMgBs13fqfdQIxXoHcJk9F
hT1/kaYeSmeT9s6iFrEtmTI9YBq0VOK9203hNGM+N5EDoKg9JE/Ip5cP3c5lOh8mfHTSHCs1RAWP
Y9rd3/+CfeMu/atMrM1sgetLX7EGfbzIG9/fUCbbtDC6yUBmh4m9U5lKsFO77jJMLkGTwnAfbAkQ
Iyd1Ls+sDKbOJ0guIvxNeeFjbfMPgyLJJbNE3tFcQFV3X+xDDJSh6mb7Cvx6T8NI4+CpR59K31oQ
29IO/GDRFe87ODKZfFW4CqAviNPHXc7BHGE0M6fJC2vPVNJuabsxUoQlQ4k0rvG8CPO9QfAl99/d
2jYxip0TzVI3bHez1LnVLjMvgwfuJJC2Q+Sh/oD4OzL7M5Ili/By5UawRgcL9pqGMctkTT7fzww0
MMgDjTGCh74iuh3XnyeVhityJe098aUFKZzE0O5VQ1Hkgdfc4P8PjB7mU3a5hbvs1OWmADGCVPQi
JiVs/rRz0DqEaiLrx/JuW9qL8vCYsoABJHHjk/3msHGT8XJoLyTwRcmwdDSjRXf6aVEqACEiVH15
rPM9VlCGlSigY2rK/govc82ftnLYUntn3zctAAFkG8RiDGucTufwr9QlCs8WbMxtJZRazF7zhTm3
XCZ3abdW80E0EwP5zzgWxC8IJPWJO6NaqMpfwbRPUxFyZkyS2MTcIR+f5aQUJ9nm2agG/Kd+p0Bx
ZaBLjla5hpjjskVJ1fPT8L2wEcnHJUki9jarvxrl99X8lSvB4fVncDCBGiqFIWjD8jh0HsrRHwGS
Tam2PuWJKonQeNp/Cy5jpXNb7mqHy+vwkLCNu5vsCCAajGfJ30YtNMMMoEgCsj77/0NUo/w0lsiS
NBj8qZhWNwiZWZt0tAudpCmPCHj5so2W72VR6xM8/Uss9M4jS/M2Kc5K6d0Gdf0TglnoIHRkWZFn
gc7O0qZyN5cllKqMOHeYW/6++u8AwP1widWfcP93Ib+wt1EP399cxzPycus8w5/5LEOcupy9f1Ih
FMOWHuAZrHNneARuz6ClyC+TIrh5hxr/7+THUJgixKNr5vM1Eajx4fffoQpK/rKeJxBuy5P0AAJy
C4EMIANYMi2WaH+QoXGeGhMSjyciTBeRMAslHUC10puSvFQiibLKEF+z0qTX7RwGw34pIjAvM402
gfeRUCatjZFARq0SlPnbhQX2Fv1ENNpsEa24wKaTH1KRpC3F37Cc2hVVGxc9R+UlI8wA6qS7jypc
MzxwCADZ0O3nlt7J4wOk85XpQ5Flwc6NG4knGEKSrUUSQz0WI7T/WFSo6+j+OBoXVcO9IOmCEMMM
73SX9ggybwGlXSiMmTYRbc6wv4rjJN/+bW5tdJgcYmXqr9GAW81R7gGK4Cb098QmwqMrAcdm2u8S
Z3z++3Stgtd5sGQe/u7k1iDMsqXZ3OsaKJrjaF0RM7717uvyy36VQ1H8kjNKjHEII6rPG0NtvZbm
aEdu4dlQ5ApenWmq/sTPB5RVfaP1r6nMLdbzFXNn811OWW+/zFQVIyds1coe/1oyUyyjyeY+NsGL
yEKZOtjRm4nFmtoVB2YUBKzKABbXAMabhlaDO7vySmsHNzeer5MuAhU+HoBSMuW1dsnwDw3UqPm6
5THzn/F7i6yXgS28AwCjzmDhAWPpVShwZVFWcNGVFIyVK5rsIdyQ0hiLb2d+KT1G0vuIwiMfdztV
u71auJ6n/4vMzZ0PjcngZxZG1pjEHJ/2th7EQkyMf391mL6T+NCnJt8EpCyH2AFFcqNWsdjpeJHB
C/gYtfURtrEOrz3eGACU76rPrOIDSsaDRxtLieQ3+CkHOY8/5i2Ax7SKmZMswxk9IMcxPuNnpI6W
iwjDusINu2dgZ9f+EICNwtdD3pG/yPjtlnN4maSUp3EPiXkNyDhtakTP78OpWUJOW7xGnoy9RuOS
F/Sfb+a4yspZTAeCjBTXpI+gfzXmIuKHw6dqQSH3D5sE3wGmHUlLcKvDokj42Hzbss/CeVfAEarO
7bQG0ysFFzBJ8MOQj3HZnfmYdrQnjyjoM9LlDiJ8MqFOgtKL24KfT5CUUBnd9/whrCPjqbyaA3Ss
hiBFBMxeKCd7ROE5+PQ533Njf9kqpXGdEO3GI+wx7Tb3QvkuT+gJzm/2p/wQcz9XIQOjV8fIAoBx
XbW7C14DU5XppqOwvKrKFIN9gCSPvZk21kp6MDn8y0zJlvXFq/YsunsRmjv5tgM4OYgI9WHGlgCJ
WgO=