<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cProZZL5SZNPc6H4OSWSDVCNqUomqApgyl/kWFq5gEziQ3/i2ZvdV+ANS9CwdMDZ0ZpDjV1wj
nzS9mbj15K8XhPHCjNPcLpheZqGMfPmiUGr6y7k++zbK9dImqifR10SDQpwQEQwuOueDsjYpNH9r
tcjd8XtABMBOvdDHd1/70FPdURZpJ90IZ9laFZsm3iQi+GEfFvql4nBpVod12uW5MGUwLtPthobf
0YvW8K1bM3O7mKN09AaYAUa6LBSN8PoFg54THyRVXwSEvEPZ8/0h+ouhyRvRNmx5HlPiX0hSlFkF
qihc7tk7frRJuRAlAHFuaM8LtBEGjzhIq/RjCh/wNqzJk/49Zj/TktvTaVL/H43L99WrOAl48qy2
u28JxBMWC1iOIfrXpUIE6TcF+sHw7qPwEtDWd28bVH2e4GDrZmaDqXfbMv2ekGkGgw3V2uX5t6u3
5vccNAyKt4tqxiWWElsVg0M3h5Rw6HXeCfXdqeRF+rPCQPke4tKl5uTBsp4EWXrpb+wXG6kdeS8F
eYa8dP/ZMkN/NbekVryZfCg7taouUNOFR1RxUWvf2FJUElemZ3gBl1yUr4kSIBEy2NDDvrVB6FqR
ZlyZLtgbwZtZ+Aw3PheJFLloEMiwbr9Kdpf9EjNlpll3CBqeeYFJgtEG+kfa8gVqMyP4RhHCsphD
eeVoPffg8QTHko7FheqWuZZomztzezNxUTZJZLyZxSfTiW2t4ivH7c3Hsq9cc+CrIi1xfhps4L+s
N4KO92cR5fDUCKHsY/VjsRpeQ0HaqKKn5LVCQTzWknjoAF2oUosqdjuvP+67yeAprh5FnHf+Hujn
Pv20ZZDObhVHd6MyzhCUVMPw6Qp7zYl2x3hrWeZFFrojjU6SLBf/NoA+SM5i3jmSz5G0rIdThlrw
7YCTAtRj3mamKHuzTBoi5E7UsnhWDJJuGgqjK5LdRFdQttH8j0CnxUs8BwlSbtgQTrWWqIGelJTJ
3EnfgXpDrIpiaMV7lLiDWrx1rUmeJEeY/ccfjG3V1o4RDfGtZXfU5nt8m9DySBzTIyuBTAbZZ/ZZ
vSGx1lwP/zTjEHOSezjte6dg7Bk3tJtAo2uXPYNNdhQGR5tR35KWNPHOmnd3tHsVJyRkCNWw5f5N
bGSs13LRtHUQUaMEt/ZLltalMAY0bv+KWc01kI2o7evn2zoJzbuHWLHaLD/U3RYzbi6jBPtx1a+n
QhqO5i8mSuBlQcrIaWkCm1WgZC45HvPXSQx1yuODvcyPg6Etmqulu8SpUJV4dsZhadb6agxaNSir
Uurvfxde1YPIlQNk/K3A1P9GXLibDx19dV9thMWnzDb875lQ9x8iO/EjMF+zHU51B32qqZToKxWa
la/xgJPLOVJRnMw89Y7dO8YeXazEsVxxDqy6LXjPqS7IZfSt4mGOlFQn26il/txtuaK+3n7BT8zH
Eq5Tre7dKIAcQosKDqPx12ggSKwF5Ai7kBTQhUQ6clPBHeidvN0JFd0YN17ggsWLezout/uLQPJZ
lL8XgKGKAriNHXrFckQIBOu93H6P6dNWM9nv/PVLZcuXc0pipArcvhndimxdZHlsU2N6MVMhKEpa
bP6v7+ORN1W9GgR1gp82rBPMuDUZBdrKu0+Glj6+wgoG2IQUyxypXEW40+zpsI3f0tvvbAo0X4CT
iLKQ4tCqMQardPJUBAWDgRfzcIZs6sRJvnhzMtQXBorwhYLgu2esrZbRwEzvqjaXiAr0WnGmdxTt
uWlnn4j4dOt13hCcOjk1dhZmpdbaT9SutpvwftDeEzIEVT6PRgMfyoHivdV0lkT+v2c6M4RBz4CZ
/St+1lttC1PVZDqwB1rQQ9z7355oO8hYOG7KHCUfTVtYwFuh/fkpTqbZL6lo2+h3dWGbEgsNLRd2
x/dG7bjUHZJTXLF4Hm+DpoqtPiwAyzUTgITpy63enjHyGxQ3FwbYX+1ZBh3TZmQWUIInwjP4SnUr
DgdA9AEl8PuilWLTi02zggNEUGpb