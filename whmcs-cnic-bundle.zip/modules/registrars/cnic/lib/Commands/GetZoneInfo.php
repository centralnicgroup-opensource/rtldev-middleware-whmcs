<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqdfz5egDysTCrjXUQYxQwVtMQBVTbop4z8WTAMcs+GdmYW302OP9sbIMS7N6uY9sQg8z6jh
1iWvhbs+byrUqLvkocCJDVNxBR+axC38fT4jQTQHbBQFB1DqKXKX0KERYY3iKSkvESPGaG7u6KLl
FYP19BI4PEsEgwwIDlYNaVrqFhi3IAxeIwpk9Byqp4zMSLaEpwCuw+c1pdZk3mlkHPCgxThiSHCO
qcko2x5BjeAhNuzD5oaJjGXbyak/kiyeuZJ/fH5OmHc7YsTKV51AV9cOMRTOQDYKczKt4p2vZMnx
/SXdGdKIZgvHJYnZKS6Rv1gc8B4Y2LaQXuchFRXhtBWqfF7zncQE0ogMx9VMM9QF3H60fYG/LhCs
P1f07CQw4CapbU3keyV+V1F77zNJ5TU8eco35/pNGkaIhtdQYWcQ0vkceae0jvRT8tSnQYn7TltN
6/itJoou8Yg2/0I9kWt7zFQUIThpzDCXseau9S4tEO5wU2KiND1y+A4QxHGERzVOz9yJA+F5miX8
nRTc1Qg/HNYMElFnD/5rYeknV6AtHp74BgNPP4hP99ZjoIccUKIKy2VyJ7BmhEqaw17mjm5LIWgl
gfeKODGU2s52RbOmNNKLtYobgMLsxIGsqhFEPk7myXHDnniUftH3jGeg5tJEDa2Whz+ilZjZxwWJ
+HzmcT7ZaHwqDxqJvRICYkUlOzaLfcwvFwMHzxJimH3Yy+ReESbRYjb3mLJQGqOWcxJlxJbbYYrC
xGt2mjkHvcHvfHT1vmi+GUOiYtU0fm+zv35Hz0AhernQ36d3Aosn0PSO7KQj3b8OwjBpTztr6J31
v8PtnaDo9vlqKNJvXWCi9M+0S4mVaWs3eLhQAChsBCsAdbqjLwc5qvHKtnwpQj+QLdTnWdsX0Wbv
q9H/UBhtB9phW4jlWrdXGiL30EwRqz7AK7UUIFjZMybfHlQVcuXEmBdTw56rBS1zBE5OtvZjbk1U
aiiv38MCj//N9cN/48VMmUlyI0NxpuWoxbB5D5IM1Dd4L7cmERCPp+TQ1iJNxtfUbhshZhjRSRAm
PU+ry3CuZRQvqoqVsxx6/uDIHfUEbODTqndqGQ+VzntXTNLC8ucEKWQOMZgi3TX6Ckd1kyXATZaf
3x6tNx076N2Rx8xOfgzZhHKSJbM/cB8kK/PHxFdQQRsOV+Qm5n3S1H74NJhLcq7mtNOG9VYwDYwH
5lJo3vU4FQYu2SHt0dRsY9ac9kkScjyte4sJjRcKd03XYB7O6lyEhvYksuOw6nVgBY+16s+EhGFM
KWOLkg6jN6o/H6L6AXLA6uwNsDn68QHfry6b7bQpxHVlDW33UW5vIPTL0G7V9uI2q6HOjDyD/OLQ
CQFEwZa+doszwMlGwWYi4DxVKz9I9mUe1cvRI79exMSqtijppJyrS9pz++azXe0uYelOIl8JSZqm
5D1xg+UROJsm588SdUN8QlVIbowzmrcm/wFcPOW+e+Ruo360OyUxPFYskXk0MIq44iIosPvvgSYO
fypwB+fvX6vKjTUK69VmCtPEsHT8YG5fAZ3xVjzEIzPudkbmiryRjbON7Y2nvWuCpROC3Yy10zjn
kCAA9LUjNQnaV8a6FmllGAs6I7kjq0xjkP+5RJ2YWqbkAu/hhuUKzUHxoe3+q0LEwZlfB4LXLY8c
V2Uahn9ZGG2NfVRPHgULk/iFNZ8kBjk2jj6A57Z1HkxRjGXD1aqiVkjYyqFTz+Pwz4S1pMGIDzcr
x/0o8vVplyNafqIEyGkr+zmuBk3N7hlNz3vN7WVYeh8BHNIBZJWQuoVCvOGDfxYSVDBqFxXo8+wO
2JOcflwj0oQrDH5zWJhXYTTmGXyeSnG8h6yTxUgPkdrz6X2fQ327ay0ExJj44ibGk4MKoJwASuq7
5c8j7oXBc3eq+UYNiKA4Bnv9tpcCROwuIWSsrxIaRJRp3JCKzI1yi3ffGITxTmonWxi2tORChp+U
gCMEyk/GILOW/dfxbr+GsK7YVCBFNdcLrRxRWmzL