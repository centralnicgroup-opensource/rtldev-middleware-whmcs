<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPum8qtS3r2Tushf6L7acdnF/QaobZ/qLUvIue2jOh6RJYIHtZ6njYR7Fd4VZnxy01e5nCOfs
LRmrzAh30U5/vPOltGcIDwQ4X1jrtSqiiVE0y7a9yk+WiQ3xEYm6GjVbXXPjWs0wQqjnyLP78z1j
c7SjZfY0BbhjNQZoqrcCIFZVY1tmO1MFSTkV0a/abQ7wJZND6vgNrnatJvGrACOnas8dJCJrnjCi
vaYfOuBH9X5AiyJje7ym4iAuOUd/JkBPHtAP38PGOQjJKu8SAFAUjXXANN1fpfh4ogpGIpMfznWd
zcPx/sDZAPgJyp/4qt64OJO5oT3hiym9+yZ8+4rDJ36sBz4hvQFKjE4zK7KjWetztPAU8QxOFxdW
31NXmXmL7aQYNi2JOV9EmWDKkrqYHvD6qkwQCMuR5L8vkdR0FO730ITMq1lAIbylZdkyD7XRvHGn
higIwt9oO0zfNotUSlDHrGZOPOBV0i7B4vh74q0LJAr0BsWmboAzAKMOr+7wEfbagqHWVehO6EBw
D6lR8zfavwSYtzEUW3GHaC1Yb9hiVBlS4HVxt5rsCRTM9Uo9UnoET4wuUrdKTe7CbGstyEwjiXgV
+MTIRQtR6TsRrbvxQFZ04djOq2JultUTNWxCv9cErN7/x8j1rdznaXS4899QFGllsWjw/sMw8Whh
rfPhylm7ozJawvbnlprhjfGdLZ6OKwmgSQuDJgW89W8WrL3TnkRWc0Qu+T6GOdSil/U6gN/8/bTc
TfLKRlMXNWZ+QLJVHBGHVLB2smKOiO3P5hTjd8SB/cVUyL0sL4yzv0md1FHKpCgBnTA7L08Bh6wL
MsLvnY+0AFzVMEQJPMitLxzC6KAnpXZp93rWTyUB9t10DqMxklRu6fVY0Ceflrlr/m3uQsuazxAk
hNGFPa9U0Pzp2FqGYQcpPRyGAlPlJmmpAJaSbS/uWSb1wmUz6p+viBFnTRrHrMgKd8aRD6fFoQQg
apPtGi6KlWnOty70XYvkPp02f2ShkMTWwtYmKxAUxiz+c0cwtQEpe4ECTQIgQ5Xy4lZfagERPsVu
L4aamp8MOHoQO08ufiWN0XPblQI4/9qVCEsCOjKwmnMa5ypWl4jTzTBSAagT/FJZSVbWuiSsEsXN
Ds6siALud/g9sMvvDJRM5XeFFyB1rsPNXO14rCRDogOCsjmLXwvbLQEWCQl3oNEei2gktP2+17DG
WvaG6kjiAmpOX76NOOYWhIxIu4aOPOVGoN+sWiinFIKQ/IrkYkDJIAaX/mUXtJcPkN7yJiB+bG/G
KuiXzURO4EZwky40pU4PAdVjM4JO7wWw+BWfyXmJKeMN+sTv/tfpbHlFUj6D9/MwAQDcW7N/Z8Ze
BygZOnNWivVERQ4a3oEtdnQITgzH6u0MzRfnso0tM/4R5qPCNdEraZtSEyK9L9+4RpJ9uaggPK1s
G5xVNprUySCpPhslBqpDrSryFhnoZw6jTI81Qbj+wKiuVXpGzfmHWdYK2pdAYc/dXXAsAT3h8g+V
4bCpuvWUnnTdwMN76Vs0AnYxZ60cS0u1AUy8zzg64FwkaV7FaNCw2m4ADAKSle2NqdNx0xS3SXIr
GXZfZhrFokNhdT91+AMYhXsGZ9u7RN86VwwTrzP/Ra1IejsOoGgTvosM8R9UqaxTJuBKxptZK42P
t7T0v3So0mxOLNbRMAM23W2HZ54YiAkx/ykA+nH+upuw7Fqb6E2HhtnVsW7q0Xza7e6R6mGKZdNN
2Lf+t7OVWto8Gdh1RRiD+oCHmDpd2zJFjgIYZqUqcFPjpjDJELK67ATdnx70zKABKcB/PyULUn/Y
+iCc07jwa3wEl9xb/lKX3vY3T9O0vslXuSC1f8KdRJEbbMtagxhsfKM7knO+IEgjRoD8XPoTscgf
nDZEg7wI615/DrmuxPoRaqold4BKR62UuwsNOmYffM0An/RPK2emNbYu5Yf2qCdi09g36PGugnjr
NHG=