<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpH9z11ybymdUVjXC/AvXGkHCaJtTONo9hougnyxHj0TnpUBcQYK1lx3xbn/w0h0ITizVXI+
j2Ya1RgXDZMkwv+p7W4KQHcgItyxbM+AlmefgP/eirTkSY+fViArvOXHvPYkyeFsFHh8h9I/2mjp
ejSFDqbvg5edUf2QdbGc68YVp54WDpxANYHw/n+r4lnB2EMlu2KoY2iZ+FseUIGiZkO6EDRkKQq+
wpXhgs6Tf7p+96iPrRdlO6NwjMUIH04mGfUTQM4BibGvDFIXHeienCM7UY1cTrqOHnI+cApQNevt
3IWY/qzxv1OfbYavPkxOuaz8Ilsu71559+i8+GJFtfYbzVr4TwXg9gvBH6uaZYjPH3w+GVl3eJck
/x+yFPuQxqldOOWWQqegyY/sz5PsL7EQQi2j4pLrYeZp6rMUVT18/H1QmLtapgeO6kefwg/L/AyS
Of+cYr91sodMpK3oEzzVKsRX9My+CBvINV9jv67LWSMjkNc0ryLqU8aTZ31yqCRXN1bqlbxKhrKV
SHuM8lGiORblwoB1Y9yxYKS4ngkNBdlxKSX/2CQ7WTM6NRqIvkLkdLE9TKY23ChYfrnDbd7gtSra
r96zvAbusMOtUjp1jd0fdyGuRog/jGNSj59+u+cZV0l/NFq7tQ5ncyRxL2iO8wxDEAjpJx4XOOFW
CmFgOmIoQvXJQ3PK5OGsdYvuiP0RKxosvWKNBgrdlEwtdEATPWvRe6Ixx9yTeu618NFCiMgidzt+
AG6sejaBWBvqThjwXab6PM+x24XqugXMxtMsGXShvcfo0gT3lTnidEkwYhhDj2Jry12Eh7HN1Huf
X5XeIV26M7y/OmrptUsnjqGKGD/o3JzcAeuedxtAr5EgXneWxtFOUJrCUhCSBxVW5Vju62EmqhKO
shfEahfHrr7jhSyfjiahS/Q9x4JAebD8LeSaHhTU8jwvGdreT0KZgfhOD8FMCA4e+3aXP8l88PHc
bZiL4l/4MNFP0x7udSjwYv7hOiFDPRJCv8TBGJsi+dsE9ZwRIqWb8DPLY2TWDD2NSo4DbBkR/41/
amrAN/FVOXymlVS1sqjeLinKnergooSDLBQv+Vqzt0yEbgdoeIhawr4KanRfj3jVCvhTnuBiypU8
hHAOnS+qMgykDBiLI0OeZ/y9YkkZCvMXm6egrRvOdSxSKhR11ORts6pNeympCvX2+9eJ4+ZrIb5w
N5watE/uE2x0rpBVqPEssCVlKePS0IQNeSRaowt3R5DVuKztFZSZg4K+LMlWG4LF5Oh8XfC0j3Ju
vqRhzlPo8e5PPnbSEkPny3lIN9mTqsc9rIvAyqpWnuuEIouheR4F99hlxJXFBcF8rG+LLW2fpk72
WhPIUQz0PMFXhRUihFg2R2o3P0gjjL4cka47y5+75B96Ycl2gNq/nv0FWH3L+zCJZN39G8waLL5y
dasMXAfZflQOzptgdqF39xtJ8urzStdQHzRN1aJUj1+d3T+/ddYJ1D07q9H/Wf5BGi2OI4ELMS4k
CfxZzr1TuXFOiy2T8vmbFTqhWc2NNRoLtbrXX8CNhLRP85USf/mohQcxROZ6+49ZPY/yixrdvi4e
RfSqDdxq+h2mK7zg9wam2ipAS+E5CaZkqk7m/4Rci0TrfubTAdOZlrn2wmUFuFczPD/8KGZshhCo
+IXMR1K4rla1uKlWty8Dix90xDSJJ4/nS/8DDIZ1R1hHr5iatbbxBI10Wb9u+nm/1sja0B76fwVP
jB/IHP2aXTrtT0IaNkXwokkyf3q/9cj82TdoB7zZjGjPgdxEui09mRJKxZ0k58c1c1aIXcdluMWI
9T3/PQ28hXPCLfPqszs2IdD7w9EwqHps0S1AdmpcSDCHln2citqXzQb2jQpACt043GApmLjwxJGR
vBjonBk7dke2VH2Kp0g9IIsXyCK9/Pzx6FGrzBevh30DnHL4NYxDhGXCgOwlgTEAUVneQUwmYgrT
MS0JQN9LMgguAeDUzW==