<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmGpN9E87AMaLO79iDRHLq7eNkXVZBgSp9ouhOr9YmkO9NX0l5Hc9eRdDHl0NmEHLq0S8XLA
YKi8GqhnCFNP3nEle4SM/q/oixhXaw8Ar434+jjnZDgleCNRSfJ1XD+sAtac1pbviEK6WZcjpV1O
Z3YzGiv0AxChW1OZFNtpBMW6bYHCs9FtIiHmXdyJKXTkDfEOmKUmybb6bcCXepXGVQfSLVveky2f
WvoRtOgQXKAgmRPgkRazvZswqgE6Q9ZB66jSmbNL3Aaz1Aeez3//eS++rXbf/ZxifKgSfn70qX3u
/wTB0g2uYs2IO14ij2T6WMNYRvrUACAIm0Ru5mMzLQMdE4RB6ESTYL2FvADnMTGcC7CC1GOcFOkH
B3s99Nhc1oswzmrZxX1DW5cTxoCQJGW9C165zEJLIKzHKuUVhchF5rEA84t9i/IuFvQntP9r+9Bh
hq6FVohsMk/czeN3AdkEuRRl4SxgqrIX8rNnZefI0gG2oEILJ+rOv43f1t672WokHTM2IUU5JcOj
lWTu+Gd0yNob01fnRkFv7sT5zRekOZuzc/wTnY94voZStV0NTfiRIiF3HuPrZcOeUTzBOT6g4rKN
BrjLhvSNwaGTBO5MwegjoP/f5bUyyoP5WOviwDav0ncJJcBF+ry+1Jvh/mT/qeeJb2sH/Yd8taBZ
Up5VwAqcASXLOtu5qAMXGCfoxO2A47Sss+k9/95zxkhoxX9geEdu+vj6CMrg77seqxNrQEMNyk0S
GEfetyeCsUyn6qPDBShgqz9GfVbnEhoIOyWtbdD9CtbB/VHpQx1GxLzod27ME0u4lDWlvei7Vln/
fxlYPmy646tG+Tn8EyirxsEc58++5Ouzd5WSDsegy01zzmAgFWVr3ctBCi4NIHLdzBBZfERi/Pcg
+a+LtmNzpj57vZHhtXlYeQmmlkKpZ5XpUNHHH0mTq4KmW184xWYkjouei6u7mQuWY2GNOldg3wqR
1PF8oqZCnR62mIx5JmV/dBVSs/sXIqm7+pc1aD52LNgb9qTvhYMU3OzkgbrJ4UvbMTYmahnfI/nq
nZe2nn+objbFIBIIyu225wjH9SIlTg5FG+Ftcj7v3U+ECDt5nmNIYLDAvU3mbp+AUfKKrPXoBaLm
3KaHKNBD6mTHDypXZaryZC1qmCdpnTw8U8sZ0LSg5FfGXYVc0in5Q20jNu7fsMEiRWa28OrX4dL6
pRVs/6UznIoqxlq1YhPghg0ZehZTccCLNw82NICSwo9V/C8nT6Zr24TZt25C6vibIi5r2tRQBilW
hyquBJwZO8eLUYlGpxnWSteaIdKK43g+4dIhVj4/oA5ZNmigrN6DwXJWCF+1ddXa3zvP+QAWY9QN
XAvlQouvDH6zT8mt+dcPUkmKLdn+My1VOO8qrUozEyWAKruPrTpQAxle7g3C50DjO9oq52H0dRu+
FYDi6mBT39dss0qKmGF8M+vJYF7vl1Y8bi+mkBqYkQCJ3skmOq5yHILSKmkU4MCdUYB1UvnYiLmO
0EgeJan/Zq19sMS7WVBSlKAJNQjcvlA0TQMeR0Ltp1ylvlW0afiSWNRtdjdm3eYUEzeRa02Wr378
f8MnmITGiKb5vZ1eS62GNrLgNmm8opF0kI7850Z6KEhxlHhhP5mo2WvcFmTrvDjooD1CrRDwlGPL
D/Doxy6LhN0D3eVJQL9Ts6n1dBpqPfiX225lsSSRMJO0tVYGiQ2oUUUzwQLl4taNkndSXQBd+iBe
CaIZNzMG8yhCsObiOtl7X58n82f4SS6x+TvhI4YQoeaoGT3V79L0GRIDbrzxnagmcCWxcdPAxS4o
ukEXQ9gyyiAEDcQUqA1CDlQPjIb0cVwKY1q7BDPeX5HYZrW+PMooIyEf5IfHP1qhjsK0vuymyXet
CS2BVKiVdnWJ9QMDzM5DcflsgiqGEzgyIKRYwBwSi8Nw73x0Xz506WFxp+Au6aUuwgvT+DRTl1aP
UxYXKAHqRRPL