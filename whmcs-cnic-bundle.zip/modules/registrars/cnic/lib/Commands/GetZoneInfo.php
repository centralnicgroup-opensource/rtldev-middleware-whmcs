<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw/nb6yVNsr0vaC1J378aqbrhpfRLEh6JzudkgZ0V0jIEow+AkZ2clA8bA/w2bl8h2s4Wdox
a299KTa1M0VUtWeDkf0ArJARnpUKswHlLmHq+ajncQ0ozQWC8OncQUNj2C2xPapcMueI69VbDaQS
YvqvCTnPOn4Vmcb48QAGqv7yXWLIvOSjt314yywa3N+9lbDlGraEO3ak+8SvmQKNcYpCDX8+Sa24
iWaar174ztaKGLma0W5VnSBBTjR0OxKfaCbEqLZwRhmuno3jWo8BgGYcap82OtYc6wPtOdGrw++A
iIH8Eb4FPE8QLnI6rbaAeylearA6yvPtXUxUgOl2L2NfoVtg1wQ3S7eExdIagJPxHf9vb7tPDQxB
2O8Oqpe+5KdZSU584TJD9opbcNILxfRQHBsrsN2QHZwjcrazn+XQRRTWZK0GcaueCFJjYDpF9OsQ
I7JyXY44wLhATX0uwy/kPMdTYLr1Jk/S36xDKeePKAKONXj6+y2EMKOKPP7EIji3IJyrtJDB4Fl5
DvtnNFlk5HGxVz10Ugoov0VgLcK5b1Sik6DOOVfeJi0xgGfhloUl/ScTjWtDW2V1xTibwSMoTIOG
lDCpstIBkzqog6JhN2T0UQqhnAXGqAGK6dQVJqpK8NsB+9yHX752cD5F/A9lbvikjq6nRzvqPJda
F/GTYxIjWtQdCmLcbDOvyRU5gJ2qFSVzooB/YZu7jYbEMpKXWVklvp9hktDx7hX1GYKfz4PRKWuO
Ztlhmvao29AT44hcuhZ5iIDY0XliGhj1qSzqNCW5tbNetjyPM3BrDNDFz8fYbX60EiLwceW/Of4r
4dgV22YgX/zExMgN91kOkv33rK/QwjjGSCpUMA/LoSClJZzzMQ7uGCLuWgMZQlzba2H0eRUPKs4l
+w2pVg8LkLpdtk91L1sIXDVboD3cdD7twtlHgYw8FcoDShlTX7b1IzJ9iFh2KhFejacugi+a14HR
Yklv//eHde3ABdM2vsRpzQZHDcgok+B3HUFqmtZ4cWwbNn8sgoCoIKYL0D/LhAN5CB8pHjR0oZjj
Jv7ZSx1RvgECUNGaLhzkqq+eg2H88DT7NYqXAWDzANJ/TDalu5k4ha7e+7lS+t+i37TFKzuReQXI
kVzVXAam29wC2+80SufyhGxDyyvE+2T2hDivFfLmOrM++N2a5lLoRj8CVQvEA3xi7ftwkFz1Xrx3
fdMIh3y31SGFLZiu9s3XM/BarPihJhJmtE4N2r3yML41bzJgfUStOI22KkoNPCPl9ziPocDmwUZa
gkt5Wt1h9aF0ffFfr5tpg1HSsvipD/T02ivl287ZvO0fjNykA7Yxr9LPf0lNN/zCBSspPIdOUK9u
P66+GYfRB5dz5sehRqKsPOHd36yv88UlANwdGCBkKU6ATFR3NRxhg2yXnQcoV+sHYvc73fL1eNo4
qRLnyKO1XvBTqp1WdOH4/OutBm/yXSgDSkIn57KrSHijgZ39tzf+Ii4U7vKE0rhZZjf9qMYe6yMq
WbRcpBwkiaQTZ8/eI+CU6Ws5d+Dl5icHg232LFRbQrNON7v4iEQx86CpV9aJ1xpS18wkKkFQ1r1o
8TW5IaepHDbkDPNGxwdmvGxyRxri7Abrbpt1QDGh5OzUwZx0qIp6t1pCWf6kFLzsGRCYvXhSzyj5
zeeZW/ZQ03FcONo3AcXtsYXGMhj2rZYuAzjbVpRy95GDfcdr6SuVprGPqY6O4cJx9Z5TmcPR8YtT
v1sV7P3bv9ekPJ5sKsEdLdK9DMRjY1bElQRT8B9EchPeFxos5lPCAG1YI0l3x2czxvKQaf1bMdzR
K99LFoRaU8n9Xy4BkV3YTwyla1KuqdeD2ZExQJkymkAnfdx6xe39vpagNwfOwv8wxZQy79toJDQb
NC2PjRHiGdY+aIjiJdT9YGAHmOabSiVP1ZHJVvmHQLgMJG1v10+ygNYCAdBUHGfkSbuzr8dMJJ34
Iix3dSUls+1+SLnRiPH/ESy=