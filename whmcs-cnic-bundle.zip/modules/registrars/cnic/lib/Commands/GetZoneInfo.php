<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo6U3FENOVN4RYoPq0aYLWrDD7ZxcO7BQxcuKjDZZPNWXVxcIG+IiRVcN8PRofmD2Wm9sizJ
dNLwMWvuMMos2tUC3Vtj1MItgMA+m/jVenrOSPGwZdKEBrvnk4YREYhtR+5+uCnq01AoO2+ngnrZ
/D6KidLfN0mXwryj7REnHiZuOqx0zrMpeBx8Nws98DrSZ8DCBSG88SWjj+Lqdkf1i+QM42kBVKO6
PglzdAKW+qSqlk5778g48fn19h50jT0xpnRDiVziFXhP3NoA6aoR1ZAhpR9c2xBrAp1m26L/rmvo
4mTp6+cVeUeqJMtkja23lzcd0Wypezafxbi2I6okLvF30+E0K/btKKVSv3uIuvSL8/z3yYlxfdOc
fu0iKah+LgM3v2n0TgOBxwh8HzE5bpKPjZ5RWTA+ei9XXbbmLfgj94RXXfFMUaxTOXB1SRBO3aEd
S0yHWLSCaqdPmFCMgj+iIh7KIXkSsqz71PFRPVw4J9Rfd8eVgdLrKZwLSjXY7uBZc5zmKWMi8Wnn
CQ9A95s1zPY6Rd2IA0u1x4PX+xsZ4mNxwwW2SsBFiEgOkSkDnECLnXP8MrtbIV8ArDoSm4liAt50
Lx4OhVNSjeqOZU3SZ9+14jAfyyR1IROsGZI/pPkRNAbsb07/UiKFdFxhb1uKC7FJp80t+gzqryvT
JhF9oFd+M9NeoXTrgHTtJa+N/nZiXtOcUiH40b5R2VPYTSnq4gwYCupEkEtTOooB8RivLssdnbhe
jdCHHEQT2oec9Ti6QDcZMvt/QT6HzeoOqpUyZg1X9RRY0ZlMcaxOYWyg3mBLwC0gA4in+TMi7lHf
2VWvVQgd++8OXRIxtWNP0LCO/oUyzzJt36JID5k5Y4ytPnVPX5Q/Ow37Y2i3fMh13CyfQ7YehdFD
etRrhVu4iMZei9MZ6JYlUJNBicCCUgmnqSNk1a9Fci/J+tUzEdFHaX00L4pPJ/GKTaj/s7mqZkt/
urj5XGdAMVzWG6ehXaQKnnYsWpxK5tov+uELb1ig8lb8ikIlP0I9d8bNVui5ivIGLJi77wi0D38F
aKd/MPASyPO+v27ve4AMxBsol3CUuml7+D8PVORQ1sIoqd9iocRiSPcSB++wdj5fqYYz6zXV/GSh
zAGIxv3wKPD0SFQEWCxV54mMx16bJE6JrsDL4qAKMg90hb78oL3Bw5nV5kal+pqp4DVzKXvAJCn6
pOOQaNXdgxHujXw/SaG8DBCwfQph+j63avZcmFdhuLe+60h7uzqFOf6XpgiL7/G/C7a/lyeEh6sf
9zEC4+SFEECcfpLAIzOxTGNkuVyum4O1RH+SaRAeZv4B5T9w/rliSoHfdf/ZmVmJjBWz6lgsaxbc
sKNqRNlQ0ihXd3UfK6ukGIlUWTIwkP97SUO9TUM9kPc9t0IgZE0ABLWFVaOrXDlT4tIXOyH4zL6P
85oWpwzWa/gLtdtoFNCtTyfqrMlDv4ncIi8wlpYLbrJKvGK9Rh9g7WIcWzx1Rqlc/aunJbRidECb
toy0ds6pPT2DhIeuCqw0AkuSYTNcVpb7Yr7sYtn4+Da6Ylx88zcCqwK7rNWFC1OhsgzeUKjBhIQO
jUzk6VEMZZLECwupNJiIMyJdqLOGe0eFAuyaKNATJZVsCV5d4t5BiRC520uv3k7pE4q8nFFweozo
KTT6PaTAyG/XYuFq+Fl7upNFM+N9Hrso8wETT6vTbpYIuZX56PC+/MZFaCd284RVdU5KVmq5B3tZ
62XipmDZeO5wAoNJxvXxwEyb+qPfX0Nx0SMO2G6eMDQqEBYqz3ASMuHCPVTIxb5/u/MxjjCcPtmw
IMIgOeCrmpPY4V1FOPCB701gcXlEUM9w5KyvPpZRqRk3ifq2NvcvhNmHhRqBONOVw7TEROLWPQ4N
1mTVt3dNCcCdQpkUWnX94m9Pp+nhIy1YHzwCRJGJ1LQlSJk13cWb9PzKs+oPZAkD3dDjT5z7Hayd
Tl1voPzSiI9pMWS=