<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqtdKUPrIQh905N4nKxbDhQlgewCawcAKgEuqC3rqJldPywX60HTuEYeurqYc8vG+YHWMuId
j91P/jLGu2o6Ue+zIodDSuAukKNEqdCMRVOTD1KfEGqH+WpCR5yHPD6z4/zIj4dYCnlue+Q+6J9k
dcsPR8pnC8KqSluzZ6cSa6pL3dldEVg3UOxhn4n+V5aP66YRyT0BWstUJhzLx1E3QGmZkO7uhmUa
4pwcosSeiNibsJvr/+8U3SA8KtAgZNihkDgC3dZg08yfAPZoJlL6wQeCc/fg1L0nY8ilIciJAMOn
GaSF/mH6i6vZrYYYoDQqAMtL/J2JVNgju/im3Axd1vwmjRLgI4ItUAFyeNMc6JjOYIq5YndQWXvW
ZPjG4/d6LfhrWdBqR/MUNhj1O/VaXFGc6mFBdEUL8BSSNsBpeU1cWStUgD+HOWDXNdHdEmqs6YHA
qleLaL8X6U6Ep1lVlaJtRlxfYhDtBsdDTpHSg4ck/r54rY4X4krxtrTWjHtTaBeSHCf8vOd7+R/H
XvZ0ItvgdEpNpNF+cv2BKd9OTuRe6QfzfUmkHg6LUa4xD0nVB7fBWr/Irunk5j82GYnS/9YUYM8a
I38TpSMzqxE1r5esv0S6rI7e6VBnChceqU2YoCSIK4AVysDcJ6FSSr8J0m5+5CMk8/OwTglKlwqL
qJBiaFstzy7J5bfdxDxKGS83xnMoHn4V/wwQKOdzckBzkvqtSDsKw2N3Kg7bn+clukn1arCFzb3+
IqYtx9F+YOZd3qr3AwkGbtF3etQdZ1Lr3pcyqxMQmzndCAL97PJOpbGf/B7m90xGVeRb1enWjRW+
4puV3seejEmvkV7WAotlvlYo8mHVWfLON/L+rCFTEhOKDt/UkObXZ0pb2QKqSL7ZhrunmTVcLi7c
lxiFNcfTwu/lqhGhFuLTva96UanNSAACHyk+anPEExQ0FPS97MLdLZf3NNJDGQslmvTNXE9gxsui
4P4ioU2t9V0q0xxtxU2xEXN3eqh8fSV/iPdYVbm3DOWIXVB8viWFWl2m4OjLV4OZRuu12HJD5U3y
md4utv9J+b5VL8P13m+NiP1s1mFzNDDYBl3P067VS+nbhgVaf3B/4f7iewfcNll2pYteDm3WKCXO
LfdJBnXRX9s6LGF3OuDLowOCZl+flfQhEGdAssXsMT/8BhOjgj4tBGlRmDTZPrK+S23JykPKCVV4
SNdZynF1Eh41SD1MeqqW9E6nCt/Bgwj6xVopk9oARUwQDisU9xk1siiQptETBnZw6wDUziGB3cRV
e4fEfbe+91HZWNDgtD3Y2qxpj225CGWEmrGINHrsyot55X/Qd3DD/ygIgA3zn+QRBho8cw4t6Okw
aZ35PWKmSlF/Q3q5UnTYKp0uMj2j/QuUuLe4mRX8PqQJSU3Fp+T98gZ/VhUXjclsRUAyjROevzIJ
eMUaY8ozEqXIIjCZ3SprcY1vwz0FXCfy2/6cBKVhMRlGNLI7jkAJRxVA6Rs9wZGoGbuqaa2snEVc
Q+V2Iy0/m7HmtTuJIeGlw4OHRA0bbRJcSY2m5krYbHAlXrkwh6UdxCJKNU+vuDUf9oboENPSSo07
jNi+2pGFMpR6SGfqzZ2e863xeVSfemk+XGdAwrzYlJ2E/S+C+Eu/fO6ngBCWUshsQpvUnzkm03sc
qoqzG2YrTVUuzbQxNtGZ+wInn3GsIpbv7HOm0CYzTVHPbZHqafJdOFszOd3ItnyufhAZVwRESrvw
3Q/cVmtAT/igKC/FGgMryc9iVeodJcIwKSA7Q1+kDifAxDJsI2JtnRPGrf8Ou8XeVaS40IbfD2Yt
3x8nL5R7hhkRAXeKd29p6CCL+mP52Ml/elv+vMWlAjWrjbxyGCNkifGMFgPlo1I95Ji9XsCJ4Hai
679P2NGgja/Hcjhaknjp/QnhlPFr69s7Z1AI7vOHD2obPBFhu1w7Hf+M59KJgvHqkYePsaKXGi5V
q1o5Cn5xdJzq7XHwQaCOmbcjixGaXfoV