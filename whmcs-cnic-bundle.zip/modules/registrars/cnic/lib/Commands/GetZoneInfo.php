<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw+3IeCQRK+rup7VeBnzM3/88K33gVNvVkCA768M3gCImyqKyA2jwgD/ZbIAvEI45zI55y1+
i5bA0fzx2shbBFjEW3S9Hd/IVjOdNztCFk+nURakUp4Y0EpBz45q39Nz1Hv7XtF3k+DlodEpdK9o
0NSq5ZS5tj6AnXz/oE9yE/kukjh9CZCRUgV0mYWio41/qimSgUpjv/is3/9ofEnjoX0RZOK5vSsz
eyU6ZyehiaiHoAg3gQMm8DihpB0WoalA3doJOkqj6uMVxw+O+s6nlLSJ2XuDRCHRKtXwWgQjCrL8
KQHeQFy8L+ngH/LsT5RZrbAhE7r8bBMIWS6Ly+c+en7MTnOHL71erkJVpvSQ6u7QBlvRYwxbOGC8
wY8VGqIi3Gt7vhmwhiUkYbU6gJEaVaJCHYTB0RqsFNWQTHuLTigqHDUb2JGhRK6DrfIIHqOIVgwR
exeU2BAy75Yb4J0xzVDZJRHgekZaN/GeALRBpbUr2mXSoELZ5EM7R51beZE7FSgx//v1zGS9bEKl
YbuAXUukYKHQsrtZaIAY9ytgsSDdrAJmLSutwlk0sxsznVDHXJfGYtVkOo2XgpZ1yh68RaLBt8rq
W2lVsdX0DCrSlf7DKTSD5Glj9dTSxBPeRUmNrCLkOEne//kReKe17uqRnTpm7SzbIDjp9o0bO2wT
3xeZGbMIN7msdYxbERu9KleSRmiX1hbCv3tMRB4LgzZRkAN2cg2YDWcX9G1ROzmZfTWpdq90aKcp
hlA4VXR6Gk6XAKRgej/LBprUR1vGlVMmtiHYNf88wWpFj0b5GC5qXrbAtzEm0rrUDuJaCFTY8Sv2
6KGxMaTKdNbsWVygMAZ1sZqbS7CcpqwQGgM/lEZdrCJLSAXGY4shCJMFkfd5WP9k4VNksIOV/pcQ
7Ti+Psjv8NiOhBzL4NypnDlApqUpNbIv+SYnZtBNKda+QcB6X8x3kVz1Qa8GuO9ScfQj/Ia6vFud
7YudeX5b550dBqI4y9RGV47oHrcdzg2nPm9y4O3X9HJHVssLlIuwWTeKdd+hufjlTUZAON5y8jiE
Fd3Xwd5Zsl52GGxNqF3GKiE8epY9hBN5vgrX3SZbdGvyqoB0es8PNJJQkWNdX1171vcHK22Par2e
z02UtsMLm3LvRYTsf/LcyzPSIuet64ZVTN+zWTclaeuQdJJViUlQH7ywIDqrczYrXm2Hkk4Y12fT
SnPm/MuLM9buNcIM7D8K/d4cv8txPq/M787b99MsV5Z4rciVnHTn2qPCurz24t+di3Eox1S5lUri
l6z/ebAPEGCZB0ST+jbpPCy0eYlE4hvAyAiZGS71UXoeM/LaDF/KRpuJ08wEAjs6PFaWmjAq8KGT
/O691tAWUdveokkID0l/nVXCylj0f5m8mnddfjC6upLapwfUexsbAjIHg8A6oqAA2NlrNOQCtGsj
XZwR7ZVUWSjGqv9R+tD7/3TO178EXMi4PkDRTv4py1+ran7+fCXOlRkJCajtlkSOKBD3K52fwUjf
Mk8ramhdC7u1B6VoHtdZ0S/8M6tHvCw/aEgy4D5/OxYDunnp8LyiPGCIhiOmXF0lmqpxH5YZlFZV
h0ElAuvWzObp9/NoB1e5HRJaRO7+4BEGbkDLPfMMaS7ygJY2/Gyl1jF9u5uuJI1V+Z71tvqvwh3W
cxS5KDUFz+n5uUYfLVHKymA8NcnO0/Z3OlYTRosO+s//kCUtjegFyGoDb0lVXmavQ/DJq+u6ovzW
SCrAFWc9hyfif9YFqso3ptzSPQ88eeJmRphfAGZ+aSE0Eo/uiXdy6lS9v7GhvhmDJvwZ4qNyn8GO
cO5qj2oYv+q3l2FMM6iCu5+8PCaMaCG8xukb0102cEjyObhvgFM9ADP8pJS1bNoQXk6Xt5W2bL9X
TyogmFpM71rw91M27Q+Rt0/q4cXeIE9yMpQsufqFCslUdKiNHrLOL0uZAEAH86to02NaoGBQjzxj
57osRwDj2B9JUElC