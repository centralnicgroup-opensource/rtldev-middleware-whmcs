<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsdVCXTQ8OTO8ssdD9Bn31FKi+houzY7hkbuiGN8c2I9/Bdxb54QRO9FnkTk65sbhyn8y8gd
dOlOMS9LbF2G7VezlBZ/xS0kMF+lx1KE3O74+Z0deM3cfzQC8irJ1D2hC+2zuVrsiCa2B+C0z2RL
xfcAtJYeLvkF2xwo6N4RhDtqTYIKY5kTSFr8T8PWmbkO18OuiZzVFgcV0PW4N8KGpgzv4DP5x9O+
ppbgs3iMR1OvJSmXXe37i9GTHKRckieRZGtg3r3qNJq+iX0rSgIm6ilmbiE2RBoCjNf1AZS/AsA3
7TS7G/+w2kWIrdBe8feCa+RJ96vTrU73p+m04PGWCKit5JEkkc32OS0WNRSPzQDa4fHYE+0zN89y
G4WCGXRduodCZCU6bPo6u1po2FvYnpWXf+RmafX7wboOMWmVaIYL4ivsbN28W1q1p+TZeeLARMJ7
qboN7AzOezEw4VGAH/TEdVJ0dSusavJ8JfBcforDk0fslIxiPVD5rAgqmrPg+xdtgeDKgEQFF+Wz
Ru3TqaZqCMSHobGvRPt8r2O8LHXwOSnOk3Z9pbfRnNIajtfGdOStP68L4mNDje3C5RT9ufkrOkv9
O9HrpCcxigfE3xtEIZwYM4mSD/uorsr/1LXMlmRSJ2PaWmMrqa9RC2s1YWsgKkW5CNSKZQnNZJxS
gLFkHLatZ6Ua5LBBH8lcbgh+ULd274uUtJdE4w6GA72jXMDYXGlSs0WVA1yJM1D7fdRyQ/otauk7
iufO2vCK+6054OrWMDJybzy+MDyWJmjbSTM3+3waadvAQbU7RfOji71ZHJ3s2b/A5+Bcn7jRUoSw
OKdpIuJ6y6o4YIdntHmruPfwXT0rcFljowFqRXaCnK4OB7/Jz5y8AMuDGWkBBE7hW8yw7GK4dmVa
/vAvNOOvDA4zjLiTHx560o4M5vRcSByfEYzhgHRcaEEkBw0dk8hpJ5n05mRFxfWdiI9ioH4E/LXB
NHSjtu2WvHN/Ia8Tf2bseN5jB5qTNakvXKQChsaDV08gWpErD+C4/neAnx5wJ+CW3vJzzG5ZKdPu
IOiPD391qbazpcXLWX27XMkZ4UiCOFb324Xeys+DoQHrhF/dtN/r/MA12zdVUEp94qOKOaGBiWUL
PEQuJOSX9xty9a2SXLEWykec29LvuuLjcsH/eqfVzL9XuWsetXzAiNx/l/HHJtJu9/1UNQ7+jmGQ
CLRbYNAD2PmcJ7pVGfxGe9OPJJiArPxPyss6ca7h+7Drerpdeoz2j1qx2CsCIaCuvc6VUFu3foDR
xlvQzLB4to4RacUcutVbGKZTHhJ+wDUk3szbBBihAsTPzjm5Ipg0tNaTyK1YbJwINsPRG0cXn+E2
PxBh1oDXR+bCN/UZJjIiKmuF0KU3zAEJc5xV6Mux49B6xytz9OSYY/e3n0F6c0Yv8jBxq47rzFzs
XgoX43bfUXIB7g5w/bJsl4dOUohChuhGD2c8NlIVlxELlRI+1gKgz9vjGo7OguYZf/UppbH3YKNY
chlVrmfGGdcATCh3S77/aKw/TwWfshQulvnxJQ1vXa/FKZyqJKO4OUOt5IyVNaeOzFSa7YuaLqUa
+umYDPSCyO7wL/mR51kY8vDiXzGoBPiL5XTmmeyl/dwGWA7cRzI1+AShUNb0mKHAsFGF+7Ba01yO
w5SqNJ7/jYhTk+nJIi3Mj2HEZcwmG5W3ITNMN6HhJw6BPhqdxuZGzHd2qIJBh+hT1uH+BbvVHze9
0qKSzpu7zRjqO6FE/lJey2FbAWd9NrEqQ30C6IxnaymUUxqJIIueTYgARYqlib43+bT+FT07ts2r
dsAsDqKDpP2oTrdW/SFaxa556tEkCuQENehteWZvHjBDvBdQg5ncCDQV9iTeRaP9EjaFYXu35LWS
zlccqwKRN4UzpDasBeV9l8OjqaVFct67MM07HscpHNt5n4k3wJP3/FkLvvxH4HEk6/dZZvaUlsLN
rZLpu2KsKhdMimreMxa=