<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmdv7B2uHkM7HKk9ambJ5Ag9vN4NlbyZygwusLn+n8fCeuZNnD+pcxReAGCX2JtuPIf70Gdz
BGl2Gn0Lo3FMXH/HtmCBFjcBHi01Wy8fFYofMIeKasGqwAcYyk441duE7/Zn/533KniXQClEh6/u
UL9P9N3+2ZXC/C+uw4F/8JIA12tGwAvhI3PCll+Qgvh+EtVssXRPOXKoPLjU3mT+GP3xT9xABkor
dafu8r97kJzB261l0VSjP7wDx73SzFLt8K0s7gppYEhJ9G9xXWTad9nBMfzZomHxKPXCLxdmy1Y8
EsWG4kSF/wsByIRmuaMyh0JUE8FnN9068wgM5IbmQEcr/v0eqSGOEG7Ynwft8z39FQPEa9TsWVB2
T9ljq7saPu17LKC70ryr+rHfsT/YjJAF9vhB9ztrzaugHV7MA4fYRQi2EGZFBBQcwpaEVmRay+/M
M+Xm49K4bkG7oAUiJ8WZNMgFEWHqotQmBhI2e74caerKpaJo13dXc+IIOKaPEJbtAXvYt0PlIsWR
1sudUnGPD6uKvhQiqWCOcYmtVRkTmg25sOC4Va6qW+XSOxvvZqq8pyZf+X8OSAC8nrqUA2bz4fzE
EC2wCBRiqK/c4/acGP/TjxaZn4x/Fot63yVdILR6XiOtDymgmpddfAHWM3bYHhTBYKbTf3AvYBnI
C+aYBP+RrWx6QNOtmj7S1n93syvUMKCORrevqmz9yRP3b438FK2teSo2oI78dpeG27pydq2cK92L
THD3y7WVoED9YrrgRcpCV1Ivu85B4+2nte/irAsQ/iOvQRFPxkkAA0DRPAuU2qPlm6R+ULM/BrgK
emz51NXk+0aqL+3AwKVpq2FV/K3KVCIx9MTCz2B2drbTZiaaUNI2znH8u1MoQSLFpq/iEcfYlfXT
Q5J3IqDCd81cA+xFED0CDYUntbZPm6/gTxhRm83ns0Cp6wnYTxLyB/dXcVr65rkWYdD3eYuTjjCG
7uZk+cBrgzcs9t5DF/y6R2qOfcMt3q1E7oCW9Ga67h6bVZtIZVLE0Ruso5F/730JWkAvUpW02yAW
1rIbvQxT1ovU2nu5oWFjK0I0UbWMW3OgWQcNMhs66FTtqwNrlcXmmUhMTp+fMghyPna3v5dnDjQW
ptOI/FJ16Qp6xbwt50Nw+3VOd+Wpoc3MtRuw2NgzPC5mwyuKgTQ8Ehe99iWL9Xo5GjO2kiZrZ2kf
m823jRFWNaAjbhqSeRwAy9M7Ue2lkBNmkQlrojnrozQzIcM/rvpNyXBe6DlzfSxHc0291LiByt2b
eaeZrvBVB6QMwrP5nzSbYeGw3z5tNIJLJvCSq2y5PQpCp10kMsOkUGOJ7Lr0aVR9cenjol2mkliH
p04Pl4W/3aDc8qbCxMjNanTLuKabfgDC+2Zt+eijak2vrU8R2kmseysmD5fdLvcwll81yyB9PFF7
tsF8GV1Jvi1mRlECuO9Wfi/ue2MSODy3Aih2+2lI4GWz6FN+OP9s1HLMpMFv7BZaLF3NxKY2Xzo1
lqd/98AWvyUd/JU1DftJ21tgzgBK/Kll1F3xkJ6WMdvpkQXP03MvylibdROCBiqT5tW4ZdEKLbdr
tgv+xJGEB8jXNZ3oyAPsBZSqFMKHs9rYCvcc1uxO4aatDgXpZUY+YX4f7G9nJguUSxDn/hvwI9Hq
ywfbxiLWnvy94oy6Pd9df2alKv3W06rXOM4LXzcD+DrIICc8D00ouAhqQh4b0FPVYYRTzJfzyCis
DwERmOy7mtU9x4McR5hQ/ECsDdOcysLakt3TJ0GjA0pYrvpRTl8itnUYagjM+RUlHlkPY0WN1iap
CKz9hmS23i1th1QpnA/hvpeDx7TQzzEq7AfAyucn8InmhSYxiTe/i4oHQLHR0M9tGtQ6Bbi44QcW
NisqpNxyeBx58kJvSMf0bcnixBNlPFUCRvFGNspzrEM0LkHw4AFyxAmPOz9rbjFPlWh8wwFnLWaF
r2exrKwzYAMZUfxs