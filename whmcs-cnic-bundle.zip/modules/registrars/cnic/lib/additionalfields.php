<?php

//.br
$additionaldomainfields[".com.br"][] = [
    "Name" => "X-BR-REGISTER-NUMBER",
    "DisplayName" => "Tax Identification Number (CPF or CNPJ) <sup style=\"cursor:help;\" title=\"The CPF is the fnancial identity number provided by the Brazilian Government for every Brazilian citizen in order to charge taxes and financial matters. The CNPJ is the same as the CPF but it works for companies.\">what's this?</sup>",
    "Type" => "text",
    "Size" => "20",
    "Required" => true
];
$additionaldomainfields[".abc.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".belem.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".blog.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".emp.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".esp.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".far.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".floripa.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".ind.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".jampa.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".macapa.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".net.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".org.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".poa.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".recife.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".rio.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".sjc.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".tur.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".tv.br"] = $additionaldomainfields[".com.br"];
$additionaldomainfields[".vix.br"] = $additionaldomainfields[".com.br"];
//.ro
$additionaldomainfields[".ro"][] = [
    "Name" => "CNPFiscalCode",
    "Required" => true
];
$additionaldomainfields[".arts.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".co.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".com.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".firm.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".info.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".nom.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".nt.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".org.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".rec.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".ro.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".store.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".tm.ro"] = $additionaldomainfields[".ro"];
$additionaldomainfields[".www.ro"] = $additionaldomainfields[".ro"];

//.hu
$additionaldomainfields[".hu"][] = [
    "Name" => "Accept Trustee Service",
    "LangVar" => "hutldtac",
    "Type" => "tickbox",
    "Description" => "Required if owner not in the EU"
];
$additionaldomainfields[".hu"][] = [
    "Name" => "ID Card or Passport Number",
    "LangVar" => "hutldpassport",
    "Type" => "text",
    "Default" => "",
    "Description" => "Required for organisations and natural persons"
];
$additionaldomainfields[".hu"][] = [
    "Name" => "VAT Number",
    "LangVar" => "hutldtaxid",
    "Type" => "text",
    "Size" => "20",
    "Default" => "",
    "Description" => "Required for organisations"
];

//.pt
$additionaldomainfields[".pt"][] = [
    "Name" => "Owner Identification",
    "LangVar" => "pttldownerid",
    "Type" => "text",
    "Size" => "20",
    "Default" => "",
    "Description" => "Fiscal ID (VAT number) of the person or company that you are trying to register without the country code"
];
$additionaldomainfields[".pt"][] = [
    "Name" => "Tech Identification",
    "LangVar" => "pttldtechid",
    "Type" => "text",
    "Size" => "20",
    "Default" => "",
    "Description" => "Fiscal ID (VAT number) of the person or company that you are inserting as tech-contact without the country code"
];

//.cn
$additionaldomainfields[".cn"][] = [
    "Name" => "Owner Type",
    "LangVar" => "cntldownertype",
    "Type" => "dropdown",
    "Options" => "Enterprise,Individual",
    "Default" => "Individual",
    "Description" => "Legal type of registrant"
];
$additionaldomainfields[".cn"][] = [
    "Name" => "ID Number",
    "LangVar" => "cntldidnum",
    "Type" => "text",
    "Size" => "20",
    "Default" => "",
    "Required" => true
];
$additionaldomainfields[".cn"][] = [
    "Name" => "ID Type",
    "LangVar" => "cntldidtype",
    "Type" => "dropdown",
    "Options" => "Beijing School for Children of Foreign Embassy Staff in China Permit,Business License,Certificate for Uniform Social Credit Code,Exit-Entry Permit for Travelling to and from Hong Kong and Macao,Foreign Permanent Resident ID Card,Fund Legal Person Registration Certificate,ID,Judicial Expertise License,Medical Institution Practicing License,Military Code Designation,Military Paid External Service License,Notary Organization Practicing License,Officer’s identity card,Organization Code Certificate,Others,Others-Certificate for Uniform Social Credit Code,Overseas Organization Certificate,Passport,Practicing License of Law Firm,Private Non-Enterprise Entity Registration Certificate,Private School Permit,Public Institution Legal Person Certificate,Registration Certificate of Foreign Cultural Center in China,Religion Activity Site Registration Certificate,Residence permit for Hong Kong and Macao residents,Residence permit for Taiwan residents,Resident Representative Office of Tourism Departments of Foreign Government Approval Registration Certificate,Resident Representative Offices of Foreign Enterprises Registration Form,Social Organization Legal Person Registration Certificate,Social Service Agency Registration Certificate,Travel passes for Taiwan Residents to Enter or Leave the Mainland",
    "Default" => "Passport"
];

$additionaldomainfields[".cat"][] = [
    "Name" => "Intended Use",
    "LangVar" => "intendeduse",
    "Type" => "text",
    "Required" => true
];

$additionaldomainfields[".eus"][] = [
    "Name" => "Intended Use",
    "LangVar" => "intendeduse",
    "Type" => "text",
    "Required" => true
];

// .ES
// vars for reuse
$selectLegalTypeES = [
    "1|Individual",
    "39|Economic Interest Grouping",
    "47|Association",
    "59|Sports Association",
    "68|Professional Association",
    "124|Savings Bank",
    "150|Community Property",
    "152|Community of Owners",
    "164|Order or Religious Institution",
    "181|Consulate",
    "197|Public Law Association",
    "203|Embassy",
    "229|Local Authority",
    "269|Sports Federation",
    "286|Foundation",
    "365|Mutual Insurance Company",
    "434|Regional Government Body",
    "436|Central Government Body",
    "439|Political Party",
    "476|Trade Union",
    "510|Farm Partnership",
    "524|Public Limited Company",
    "554|Civil Society",
    "560|General Partnership",
    "562|General and Limited Partnership",
    "566|Cooperative",
    "608|Worker-owned Company",
    "612|Limited Company",
    "713|Spanish Office",
    "717|Temporary Alliance of Enterprises",
    "744|Worker-owned Limited Company",
    "745|Regional Public Entity",
    "746|National Public Entity",
    "747|Local Public Entity",
    "877|Others",
    "878|Designation of Origin Supervisory Council",
    "879|Entity Managing Natural Areas"
];
$selectFormTypeES = [
    "0|Other (for contacts outside Spain)",
    "1|DNI/NIF (for spanish contacts)",
    "3|NIE (ID number for foreigners in Spain)"
];

// owner-c
$additionaldomainfields[".es"][] = [
    "Name" => "Legal Form",
    "LangVar" => "estldlegalform",
    "Type" => "dropdown",
    "Required" => true,
    "Options" => implode(",", $selectLegalTypeES),
    "Default" => $selectLegalTypeES[0],
];
$additionaldomainfields[".es"][] = [
    "Name" => "ID Form Type",
    "LangVar" => "estldidformtype",
    "Type" => "dropdown",
    "Options" => implode(",", $selectFormTypeES),
    "Default" => $selectFormTypeES[0],
    "Description" => "Note: Regarding Option \"NIE\": composed of a letter at the beginning (usually X or Y), 7 numbers and a final letter, not hyphenated)",
    "Required" => true
];
$additionaldomainfields[".es"][] = [
    "Name" => "ID Form Number",
    "LangVar" => "estldidformnum",
    "Type" => "text",
    "Size" => "30",
    "Default" => "",
    "Required" => true
];

// admin-c
$additionaldomainfields[".es"][] = [
    "Name" => "Admin Legal Form",
    "LangVar" => "estldlegalformadmin",
    "Type" => "dropdown",
    "Required" => true,
    "Options" => implode(",", $selectLegalTypeES),
    "Default" => $selectLegalTypeES[0],
];
$additionaldomainfields[".es"][] = [
    "Name" => "Admin ID Form Type",
    "LangVar" => "estldidformtypeadmin",
    "Type" => "dropdown",
    "Options" => implode(",", $selectFormTypeES),
    "Default" => $selectFormTypeES[0],
    "Description" => "Note: Regarding Option \"NIE\": composed of a letter at the beginning (usually X or Y), 7 numbers and a final letter, not hyphenated)",
    "Required" => true
];
$additionaldomainfields[".es"][] = [
    "Name" => "Admin ID Form Number",
    "LangVar" => "estldidformnumadmin",
    "Type" => "text",
    "Size" => "30",
    "Default" => "",
    "Required" => true
];

// tech-c
$additionaldomainfields[".es"][] = [
    "Name" => "Tech Legal Form",
    "LangVar" => "estldlegalformtech",
    "Type" => "dropdown",
    "Required" => true,
    "Options" => implode(",", $selectLegalTypeES),
    "Default" => $selectLegalTypeES[0],
];
$additionaldomainfields[".es"][] = [
    "Name" => "Tech ID Form Type",
    "LangVar" => "estldidformtypetech",
    "Type" => "dropdown",
    "Options" => implode(",", $selectFormTypeES),
    "Default" => $selectFormTypeES[0],
    "Description" => "Note: Regarding Option \"NIE\": composed of a letter at the beginning (usually X or Y), 7 numbers and a final letter, not hyphenated)",
    "Required" => true
];
$additionaldomainfields[".es"][] = [
    "Name" => "Tech ID Form Number",
    "LangVar" => "estldidformnumtech",
    "Type" => "text",
    "Size" => "30",
    "Default" => "",
    "Required" => true
];

// billing-c
$additionaldomainfields[".es"][] = [
    "Name" => "Billing Legal Form",
    "LangVar" => "estldlegalformbilling",
    "Type" => "dropdown",
    "Required" => true,
    "Options" => implode(",", $selectLegalTypeES),
    "Default" => $selectLegalTypeES[0],
];
$additionaldomainfields[".es"][] = [
    "Name" => "Billing ID Form Type",
    "LangVar" => "estldidformtypebilling",
    "Type" => "dropdown",
    "Options" => implode(",", $selectFormTypeES),
    "Default" => $selectFormTypeES[0],
    "Description" => "Note: Regarding Option \"NIE\": composed of a letter at the beginning (usually X or Y), 7 numbers and a final letter, not hyphenated)",
    "Required" => true
];
$additionaldomainfields[".es"][] = [
    "Name" => "Billing ID Form Number",
    "LangVar" => "estldidformnumbilling",
    "Type" => "text",
    "Size" => "30",
    "Default" => "",
    "Required" => true
];

// TODO:
// * Legal Type for Admin/Tech/Billing has to be 1|Individual ?
