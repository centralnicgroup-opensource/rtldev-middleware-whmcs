<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwA9dffEMsFT5qSBkPSAh1bxyxyognUMKBkut0/WlkxUbaUaLdFyKBuVzXsAT3UA3ZtdkPO/
MImAKj4NXbDroAcO0W63+VZTPY/4VbWKq8vGMU3Ojxgo5n0Rd6YFLLguizeBkCySlM6WBMl9WaFa
4KHa+emGXQtkQDEBXLRUCLp1tUD8Lf2jG655rr70XC3zECssxFRZwqPw3BYhBjdWQz1ke873b7hO
V4AxQXVfrmzgxlZf25m8ywBxA+c6VfBipTV/gu3L3W3OXwtmeEhzGSlm2JXnhaTu0E9ioi8ETGOX
8QWL0S2LM0lz6VJKuOAnuJwFwYOGPohwN4zlXpYgpcxw2Ci0R5h5IpQDsbnkqyZEYBWC22XvDrX7
xrLDQDyrCYSt3nq9sg2XYQfPQYtikkbI1p2lQVg3CeiBeub+aQIL1RTQX/RtoBzRZmeINgjofIAZ
UUeI7XOwb0jYu81gxt0FUHjXJg+ZpBY04WaOGJIx8fbNRjqv4t5n11NE9ps2H0zQ/oIduvfPA4a1
LO7ElRFDXm8ssV2e9RLPQVnxWPt6I9x5UUGwM6Uy5bKJiBiuNXiXWrrFttZHJGU/JawuPKK+MtUs
GZhp2d2Oa5449aBOdI966ypO+Klrgkh9t7V8rtq3cePXPHwzWSX2ji86y2IuGfZa/yxq3Ap87C8M
FfnTk+UfN6Pr37lfc6aS9FkDiMCaDpiigfgYrUEw9CzfLF1ZrooFCByf4+yEz7L4au9ljxN0n/b4
5mW6W1TfIQUhWbOHe2V2kGSl5oKW1MKCxeWEQQZ9Feh5w14IvNkPDvqNQA5QJKTwNN9mwyikWnrB
8qwSTOpMLTE9kNTz+UXtprM86xoDRufAQwovrFlZGlroy7AXi4K/ljLGr4wNeU1e+AnuUiRvda5Z
GHlcr7dKcBmGOZOCVUDr09XrPi+wp3ac7s3OazloTAGwYYo4eD9gIkPviBf5KREwYe2fNo39CHDf
Yuh5Uw+/hAk8P0tWLIjhqdceeUwdCAwQX5XxbGRZMKjAKoWxhg8DPnhHeimbmzuBYuIruSpseM5c
7opUIJCeu26PnImwnU1c1OUmg5VpOmQaGayHl1/gOuQmmSRUot7u5TJ7EAhkzfN5KqtYv4grM64G
BoXJ5WdkVr3zielU+UPgdITFqwxu8fNV/nz6wZhBPvGJde3lsbuwDJJbeh/4OqzhIGY4QNdwotXQ
wrVky2Z2cyLjMx1UC2fVjpYon5Ci3ZYWcXXvqlmmQ1+ukLTZUQuBaJXdm9VdJXVEzaBQTNvzNkkt
Xc9OldNxFNIQskj9UnAmZ8nhZ3vqr57gPSz9fKyJKU7DHHOXJUjvjxHbPFXMHe+xnK/wJDbj3F+1
sV31xfrMg6h1Oi+/V0QUT3x/3zSQUOLD+gleQUv+mQSqmx3vfPSO5lbGLGJhUXEZmoMkRMHSZ/8j
st6MgrzuerKi333bN05cmAsBJJAS7SKaemrZIEJRHYpORDpwkz1K4LhphKXeoXdZ0D15a9zLOuCo
QHZOu0FATZrLHjKnsANkXOtBwgng7f/1ty6RtfiwiA+n2jkMXFsaGoz42UGkXSu9thGXbneuH6fp
fF5qf9FjzMZRI6uMdwL1FyINf7BXagQoRkIhGJ3QR4QYvZZESRV9wIyAAi9BoxbEtmJk06WNOXYt
bBWjUbbvErkLhFa/1yBRT8D5/sji6pJ/MPZoLROA62xn5ZsYB1dOy1N9yQgIQjkzVAFERJDplInL
xynFoUhBmvn3PTvwEzqa9S57f7wCrSga67ZwUN7QcKcINfqZahAgNnKetzFOjtxEW1UHpDU7y707
MZbLPWy2RZGU5w4AvQfVvFyGpvH8wPeYwIvAuina79vdhfi93aokY85GyuxkE0xe/ma+US+EqHmO
jllEALuNlHgNkYL/sDl+zSb0cS/8941M/Kg04i9StIujXUSguefu1qRg3kpo5TyZwwaaLNeqWXLf
iP84o7zBThHLb2/qRa0j7+xvyeRIwcf6nltTAKndU8RRcRqiCVAg3BLshGJNkGd21wqg9sxq1gLW
jpBkbf8O82yZ63SkKJxHNde0MQeG8fKJ+GoudMbNuWqdHj+ocLyq5wLAYKTJGgowtNiLR+Xhxp+W
+5xAjHwemhx1BxSaNFMUL8Wmr6DO16SpP1vemv9s6mG+i+wjn+wIfYEnMZHNo5tguOSs3P3lHp0V
OpWdJnKhFkJdN1zrJEiEK6uGJw9WBgHKJy60JoVl2oUfEfWE04ZBosLOd3HeaeN7vTmV3qmajPtn
hYg78ZWjyiryBfF3xowtIDtJE0PzkH7qbtVGe5hUdF8uN3iIQHpUWjMqNZf2VtqH0g2AsAi78gBb
pPm1FzvLnvdzIgBl8+9RLJ22s/XLm2yiRwa8Sq7Br2ghPiTcebmiwaHIHg3LTy3PbytolMSDRvcy
rfysLempRC/8a7qNM7U8n2/8rL6bN/HWiPbWHIOTnt6Sg09t9BHhOFFKtkTe5YFu/yz/YCLza8tp
AGpBQivVVwQmT4ScexMgVH8LUkz2ExvvwY6SpdI8yt6BBP30gV7FWsQOac8FN/8fxl8uI9n8eVy3
REgOnUTlcwSHT+JdBBbLv1vP16sisdd7gZsJMg8WYJMNHhhYb+Z5thtRS805qjN1zKF3aBstyjlI
ERVNaoCcwW9TKgXrtwrxSTvjkCOSWnr0ebFOlzHmxR9kUZ/VmQH1ueHBB2Khfs36dMUDEic1kJfa
UbCY/c9tXLG/qby35elqpDh2aOKfiUS0qVYpHoREOAp32xsbU9CX8jmo+HyRzE3qx0rAdZclfuix
ftAf7ouaCDaKoLqxx/5Gy1jt8dVdyI9tVmbx0R9LI+rCch7qJexknhA6ar6YxBvBTVQLmujbe56W
I2pWutccg/IWXb30YRXrj33onyyttWQ3D8ozLJ9J75sosfDIHLD3/29eLi7lSA8hYtgPmMCmupxB
HY2MzPClBL2N/3G7J8WiemPwvwq2VxKsCvOPJ5xv0+QQWmQejF0xT0RtVMlNNIzsZMhenOWZlGF8
7A3IKUri2N1KLDc11R2GqWQJJ4ZmbzBSBTPlOHGdXOVU1fzRhiiMWRDlJASQ6hg6yDVQDhkl43u3
ohIoHlDSTwTAsne5AC/JSHKCAdEkqP2P3NZ1MAOFtHEVV+LQyId9s1xDpyUjk+vGou1tqck5dBtI
K2DJ4Rm7rixkV6b5YZY02By/hpZbkSFQSaUEJw3R1vJpoejEQr/bGP++rRwLWy3+gxUVS0UaU20+
SYEM/z1Dq+Xhd0t9bq9Yj0eNVifoQJMrFsWM80==