<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmW+DFpmeeppZV2XtuVy+QMYxvdBmjOK1xgujaLQAEXBoB0YzljFTX7NmMsU1hbeg5IWT7yj
dejD2FR+g17ra9hTS+0oJP0bBhnO84ouV6zG5dfn7QZ8aurrujUSERgvxUd+BEtgXpUEU8Z9TJ1o
hRq7cellxkU1hg1vOf71pbKPVOSFg3OLH9qwl5wOJxDziKkesO0kB8uA/JLybo11RKwLgrmpazhj
TKnkt6W80MDDxKCS3Q5+d+WwEKwvm+0AoOy+43QPeGRaHq3h8KcuIEYSSbvidm38ftbV+6Hyq4Y1
waSI/yKNAceCuEyTCJO4zU5SwKNfuwFJnXo0DskoZR7F9nuRkCIgO9zSjSuxusPw5haUMO7ylmqH
BtNvKj+Ku2VAj1obem7u16rgqBuhDoA0RChSY8TWINNtFX5ksTyHx8+UDta+3ycPyjPT5KUC6bWI
WSlSbUNq1e21c2/G1wCFveCtMpbRjTvA2j2QMIX4B0DS467pgscoe6x86wmtcA6KJ8MXEwrxBRpH
PAzDs49fXSViB1amzcZIL18SRUw4B6U0MvS4fmkZJhS0wMQSGkYraKR5U5IVJ8aP2STApZNFtPVV
c1m2231d42+xpNtSTeg582V4Mwh02YNVG7/8fzZ9WqVfUhzvU6w75gHvLvwpDsXSHntNPmkW1wXJ
B6F6kGS2NKn/i4s9f0/NuQxXy14nV64XaBjXRgME5Hwfsa8lq94OPeZFOyzG4iLWZnXb/0Gz7gEm
T2xY44OgeucEnKWpbZOD/jIHmQ9slZwnugnRIqcxqdZxw0JhU8OBHIU9dPKUKvHp5y2k622bM64o
o6ASRhNFNXS9pvueJPMVCgMoT3v8H3sDn5P9CQniauzSNoitgOQSWErwJEWExoez8VSZauPsOBhU
cPrBxEETW4WdjfBmpKZPvWiZ387zB9H4xGtQ/w6AI5/3CD3XZc67I2aLrm5QHfBgxRczAYnnD1s8
1I7JmnCX8l+qdBV7PCW5yAJjnVCa/ND2LxJVKywmGBaUQwUyW1e64KHwmb3k3ZP5KgsKwN8TR8ZE
YFFLjq53cewT3gd6nYXp0eeGfsUkNymajjU1cC6Dzf9wvuVfYuw1D1X3v72HGIiNyFWGRYANAHtu
ZIMND8hNonuh45R2OWp4vnzkfsSoP7T8iyKrgQ3XvfPaIYAlSGVuvL7rxJ501Ha19Bqg+BRLWKAr
j12G87V87YF9yUWKpemEPox5a3uM2UMtsiFHWYTsdx8TExX//zta9wsTRi6jby2VpKrHI1d7qhoK
5XGFbrijestQ0FBjTS/MXjnxhGbvxAYCKLaXmGPfSY2pJmyR7T34HQcoI18T9liFoDlM3MFEjTbs
J4wdwU4QWn+zcsnDEMW8pCMrVDH9DQ3Yy7OhPFhkTTiNWyKw5PJPgYcreIwmS8BGUXlBmeQQPd+s
hDoeW62kyJ9uJp37aOt7AAVlmR0QLovMmWSOfksDDuOrKFBUgSRGeDQUGES0ZzB/A429LeBSZ/0h
0yIF9nLFC+wZkeWQUuXMeaSjdzolrVOMZW7E9FMW03Zs8akUQT75PhX0ZXCo1Y5Cd/vhpq4/vT2U
YSCNJcr65OQI9WNalxnV4MIHWqMoxcy3lCy9rDLrRU7FxJt0njqRbTzzV5HRjt/6nOecUhjmyI3Q
1u8WMNE6a0fwFW6jKZsGkhl8I66eBg0YIY+Jwf+lc8bB39Bmia3oC2+YcvFiWqJeUKesmtpEf1dD
mN77Tf4lTiR6+ehuKVfKkh4fYZbtM821ZP9D9s7J0awIXbVaP2mSB2b9+I0jabnh6hOOBmInVNPx
LcejmYEAAm8FDizdBOPAwKIvEABEdV4kXB7desgRQ6VA0dLdWpAONPI7yOcEdTmz7VQgZavpyZ+Q
m6vQL0TfgB8SPQEXnrrrWYJrCQxHdOS8KCt3j+vnZd9/bTJ6KJgVaLBCujUU0Ly0zsFN5L7yvXSn
G+dnXa1G6X1tRKv2kiTwt9sZW/lxkagivLeLKURDSgk9OzjCc58MPdNihRI7vVJj0Vzee9FEZUhe
5/M98zNIBMkswPD14SAlgBUjLk4mJjc9++ZRu26Ok/8qv6Nh6pIZ8vrLbUpg3pRM/OC2RDxcfCBr
7WeZZ8A/OSm7cbDG+zmWwim3mKeoyFTneHz76Jd612rpAmrCa6juUat1HKCrMQW3/JNee2vSLLUL
Fy4saMIhRPx8eH7L8Wwc2BoTUPnrGcaoOxhd21eMNhtr4YonbqH3p90qbgoL6Em15+cTEYLLbihN
uH5OHEbM/5wuR/jNp3Ym/xxLARV6nDwfs7XsUdzLxkIMvMqn3TCTxdvemu4tmuMswC9MmeYTQxtr
A1PY9odbAcrVZD0ps1MDc2pfJPnw//4smtTLDXC5nmTTPnAM8uR92BgNvd6lidBXWK3bBoKlXzTN
uMRns9xjSFplIXQQKgI1HsAHHfspz1z6mH6mERMhrSUqQPkMvuQDSvU/Zabq5FJrxWeuAN3skr7h
tIYtzvi7BGATJktZsL46m0/KdvlOsmpDMRmD4WZ/k5VubORys5Pzgslu58jVnJKAIbLc88jXYcC0
WqQFclUGTGwrM9R4erEBZpxyDgXj1gzEp0uFjRBearfG4u6XkvD3SDTGiaWLyODcrCQ1nCM0fCLl
FMYfYLZ/yB2Z6PBkNUdt/UpQRsvuxC36ZvyFea3ezKZ57bhIGf/bduDZ1wQooevfLcx/hLHVaN8f
sqDDQ5YK6kUV57sMKBSEaacREXxov9KqpAAAoM1hXX5P+mu2TDVYL4Vp78Zs13EvKoZz6hGma3wU
cLdb5iOgFefkOCaDVzDQiqUU9Y694ECzQaGSZK1exCI8WJvofT19xXRdThjCqybtwynnes0+p3gt
p+21nC5qytlEoi8Pe/pTP5DgkwDHcZJaFtKoQElXobc6pnQpYek/V0Lpihd3e6MhQ4oMcQ44B/HA
z6jD0frRs36lPuu5DpiNBVyYiC9ef/jxZ4zWiO3RCRM9NwnTu42oVbFKcikMMmePyaPvtOn9UvxF
CcjhAU8I2A9nHLdeIsMC6a169F3uQYSnH5cF7YOA1QMeMiVqOFpKcg9AdAPD+Sxmuu3yJ8vsX7d5
34FlXI2AUG1mOM6inzMZVTQoFi9k9+FXPmZ8hTPvaooYZQOMGLfJJY1xUllbzlULtaI/AxDWHW+N
kfYx9L25KpPqXgasr8vLA4Fe/gYKiS51XFwAMFpAAP7lfgwH+k4ShaqUGgfUwcVAry3sCxkfN5Mo
Pxf9nWc4Yhq4OMr1