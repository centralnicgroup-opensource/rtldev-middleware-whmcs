<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtqDZtmxttDpmiCQNpRbOAN1Tmy1PUOWkULw7+u84cdf/lpv8sdG4O9OOhQckRgjmkKlDcIV
8/ob0pVRZA8Ihr/LgbYUXeZMtYln7OQtoI/pgZ8NWQFzX0eM0bTHfcPNtP4bJJIg4YMmvlu1FM6n
MpQEgxfRVxRdrURTx9oO5WadMIgakTyMubHjTE3SExzF2n6+rZElFLN9VjQQG231B6NMMRBOiVMJ
4R6+v3PRPn/2EYKYwvpLDT3otOuh0JJmkvF3R5vFMPjqCGkUvHnKLh5W6R6pQGaPnvKCEoBOeINM
LYb8EV/mXfJWwyb+M4eT7ODTBPaJqUUQfmurLLUtdh2Q1D6PTnpV9dsPzrYkYkyGiFa8miuDCiNu
5umKd1QnDpH1cRzKDvWskYq7DuBRZZjTCTVVS5YKCHQGl9YAVttz5Chk9epFbG4hsXDOKbuz0dP8
8Wcl53TFaLx1ZmQ//PxHyEkwg65NwkwJA5Jec6xy5OzwIkwXGUy8Ro47ORgM/GpvKastkh+WZ6yo
dfdbR3TC8F4aC/0QKDv9qA/rB0huXfCii8Urosg6838GzU/fXrMtCA0cncWS4fpxQU5zibzZPO+f
X4XwTBj99aZ7H0AAm/hPvDR1zWwOWC1KwzF9cmdmAVSJOmSZCrxF5lcS2VNL+Whs5BGrjytcOOYg
gNm17R3148IIoNGMJVg9DGw9/YDu5LGIQfZzrO/mG/JkUjawopQZoVvL+00ZOmuCgfVPuLgnY60M
++VycwFUYsYKdp5D5JiskAnNp9FnJvjAZXMf2JiIenLD3bDUoN1EOjTUD0va72KqnOSkaYWOdpV0
uDeQwZF6H5MEMRAunJ0ObaajvS0SIIz8YYq83KuR/ZhO1HG1RfCujwsz3avNnOIetpPEyc/mepeN
4YXKBbwM81ZO6DU2fhvTU2xXwfvYyP9ha1p0DPhXVASsuHjfBcbdk6htt9bAAIUIEhCQI983bPp7
sHbSv4yxRNv4rrwbeYVU3XUhdzVEzWcSapE8Vh0gP8N3DoC1wFJ0kzJiOM/eX8oaoUMfUFcQKW89
n/CNFsjJyM7SHxt1KAw2qi4EyEMUJJ0pYzOgqXXnZfLQqYskgtvgZFv9eUZn17Klqm/kPFzy3GL3
hmlasmXgVW0fM8rK9OIPdZXXa0DbXWipJy4m+wE1iZTGNC1cmLoYyea8fvPdgOCCCA4eRMSv9Rmo
QOBFQo3ZBIWTI2OVUMyE4Ge0p0cOyt09fwfZ1afHyCDUtrWBpAMDKEhLvmuH1cg6HxO0Goeenie0
+6DKIOaA7EerUJ259q4ty1yVX88qzQdWIF8jkp3SVBHFTvH89WTtNXRrRp+mwTa8MY7ebyfpeoxk
sfqpS6SLw9MVt2DG0aqlb8VdLk+h+SDBDJP02eoB8Sn5dO1zrIYpbUpDrUAgbWv3JfkFbKEICCXj
fJsEzzOX6LSi6AJORTCcBAQWAkBHZONqO1PWK/mDId+Er/gBHFP+Ith1mPUDKSOEf7qpIZs6LDNp
AGUBPBVXvHtdqFcLQgh3OOKmuBXvQrszD5R5YlfyTU4h0jugvL+Xs4vll6ptXdS3e8nndJ6ccm4L
LpMI4945uuUqNGg6EnMCgiWhUldlEHRg1tNlx323m20i9xALWJltxJzjmrdogpNYjBCju4kizg88
oGi7xMht6mXh6AuaCiuB1E/NWNr+gNd4T7KOzT8g414PANzp5cviv8PgFHB4rPpjos4Je5jh4G2W
ZsDuuJ9l9/RkKdisQ/JVxqiGCGcr8v5gvNhQS9NYtty14JLc5IOitycN06km5D6l0eGPN81+JWqz
6GDs/NViLoAoLFQTwhRiLCMhzDMOGpwP2zMeGb116KOIpjpmrlRO6o3MUDj9Nzut/4JokYEidXwG
CwfuaHMGUxkSOCYuQs9QDbFBmaMU9tDLL/i71AfkOOpAPpDYpmly/k8MrR27mI12GSlkf7+Al8XR
9h23gymeGqFgFnpeIY5EP2GEGL123padqdzW2sT2gcrIX1exvxFygg9/l0FgaS2uLKgHNKp/Nru2
N3U2/3xS86/HxW7ov5Wx6UXNp1mnJp4ji1JmYCPnbvPD8BUo3GnyVuDyrlStiehK+Wuv+/7CfI2I
vDN3Ig0XfDEmRekN7gATun9Zom3BDLzBTvam4MMHqSsvMTfuPIkQ6sIz0YWRI92creo1CBMGtn3d
YRgkQerjmDDcCt9CB5v98RiXAetJEntL2OB7C/Qp6ATpI8nmMi+vFtUhfvqRJmMYgsCpMKfAJU67
gjrG8PJ0QkD+kytlZG5J42NCv4BYGpSM5RdWYgtGxwAE4gQnI3gD91+UIFA1brk4x1h9MQSqccl5
4uX+Q97dyl2kwoLVSb/hAPIn94oJuPYSUyGIy/YG9QJ9rpedYMf5hbxaLiMq1WxMLbTPH115pUTw
T1b8eo6Pj4N4URWjsPeoLSpFsmt6Yp2MfFYHmgXk6THETSmQkS/ObXSqGzOwm9LUSMF1x5VBj/3x
meRzfSBpi8hRvqdC/hiUjR+CLv9F1+MyrYXFRA2Kwp+TQwKh3fCevRqkCUW1IiZk46M4fNylixoY
7RZYLQ/soZHue86DkGyEc959nD6xSm4IBtzRBGJYT6ef2enoVI2u/B7tKIpqy/Y72kfqcwrUEjIU
XXKoSnVn9Ep4ZNlJQj/FLr1mgeVmme5SCNn49q2x9wc/iETvPx113kuAU8OiGXEyTr3ebjiEg7uW
uYDjuErODYdu7rGSHJHbK6CFs90ujOFTj55/rdVMrw4bv4fY4te4jJy+0/ULMZNny25KCmOMK2Mk
Z1VcMkVlaROWHXEfOUMcW5wLbSF6Erelfk0PdMwJbb2A5IfKIWi/1ywGRTWplaeHtMWSvKphHgWa
hcqJ2ap2LIulNXRqwrKu6SlmSZAmKUQW+jb9i9Jw3TWkDdcjBnFwVINvbGiDZFXYtjkcY2yhmRQc
EVzB/rtcR8K22cFh5ndvvFBFfkIQMnDVqHvTNOfBm4Q3mE0hwirGMIAvjbXggGBl7r9m5AQ1LhM0
bdmSCgBDy1QEpz82lEqKIT770OAk6ivUfuLGDmj0+toNN/K4ninYfBj9fQ6ulMLekSHa5Ti9sQQ4
Al8zIBxZm11o0iJ9iMFXN34uPfKfB4lA9tlkScGzMyXFSN4UD6DzXhqwh/kh7egWYTdPRYPeygYR
aVNZ1lWHiyx4YWBP1MHC90Lc7F7Fo8jXzkM0YofWAusN17I/8wv3SrQ6r85KVXyskgGYogB/j/Pc
uHWS/HGCWOMr6ZY9MBgxGyhO