<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/weLVcAEwx+KsR0sdhX1ryU/i2m/15tXvgu+N42q15lAT2hQOvAH4RBxRvITv0gTwyqQS2e
pRndVhZa4+GYGTMWKVe+8QOdu2Y4r0qCrnyNT5Bx2UBGWd6a2y9CHGbd6flV8ozfTjGZ6AwLpxDg
OaEcShkhtMF5ZOHfHQjyWdKGz09vfoRPB0QlssshNbl+sEU8GWajnbK/Qk9s6OhwRdDBc+xlk9fg
c/YGDMC3B+sn0x7sSg9sNy3219dyazc1n1dyhLmNTQBmEO+CXpAnqZy6G4HhAvyOhW98YHjPOSwN
auTy9Dypug8GETri4pM8MJKzHFXt0jP+BLdp64embxQWaLTaIGVofPn9OqQpBzhCqXbtHjy14ZK6
CXUqhzzNbyGnumtBtr09IV3FOXlnXYOay217wzukcBVT5f/3ocfGw8rtA4Nb9m+XImJ0tKrtBMef
WsmBaugc6NIv8Wd4eIfeonXH7ctAXz23xeEyUjbIxGNLpcP5RUQEYgeIaLErQo0ptdGO7AzFS7LF
+HAo2Sk8b9DBBXKYaFKLH+/6xr5qklEY77fLsoQnaFgy0v5+l7apuN4R+zH08eEHAld6ajX5XG04
7edW/lqs1fIOViRSWTVgO201qJ845daQWXsN6Rj6c8NU6zoQMKr6DLvILO2V/Jb2g+Bo7wF9asVi
cFyVnnthRot7ruCURj2LQasQhh/jTG9r9kWVunRNkSb4S59M72HyGtE29QOUJUqxXs0ai8tQ7RZP
N3+d7ITTTqbNCLrrEfVCKrlx0I0clTRLe2xsIrm4RudGyBPrInYarIAHKKWIgDXJYRZOOyutjfkY
7HiJ/91WbhktuHL/DmRlwnz7wFBWuKPa+PTukvy+enI1irX/+U0aY7NUHMjv+ZONf3vRDD4UvtrB
TfCNYfzuQYmafH5l+AqrQVZmKWITtCahKBmr0IEJkrrJgzDPbzODP+13uYwxVgEnj5G9nB7bl9XH
vKCiBPnqh00rQw9bFV/jUDF9Yo7CybUA232YKHGlySzNVYb9THiVd/+IzT6IihHeKZSmtp81GgTF
pWbM39pb5SF6ULSXor7KroppBAHUC39SqejhIpya4ku8XNFNdsQ47AtzJhYir12oSOaIcGiOk6ny
wo/jG4tVWPlBk4d/33iMhhXWbh1bACCnmJYyWxVDao92lKKTbzdWRsYUiD22tT+9bupU7EFfGGZm
wCGq5mCVHFH29rQZD7jbQLAUWWkyflH+qeMFJmoV3OrXbAuU0YgGO/2wxZASkaOmte/G8kWKDYT/
ViqGWzQjYLpH7Rr/slgIi3qPftOnfQgGBW7zIA1EidztdPhZTanofN1VlBZO7qiWbeTR7YmzFPMk
5Ty8bBmYFqFTpjPDnM16M9tUG9g4ZLmhxHlnQ1mxN1O1Hfdokh3qfAufeKKNXyZKG2E+cJxE+9u+
kT5QLjtNwJFL2o6JdE0bmS6t6BgARfcbHXFjPaC6KgRuSqACpQO/QUOKS5e7Gsfv3Y7Kb54vzDES
qgg/A/mwZnThOBlx08BeHZevGpEVZGGDWLhh3G9PgSTkrCxtSZWVyGSqOtqxLX7DqMR8p1T5jw1D
da3kdtfXGc0/7iU00bpQQLFyUbMdqJtiFjY5IIXCYIzVy1NNBZIwt0+FyRhKRzRfyVUjywuRnDlq
8VNZYiRBcGdTWSx5ro+du66ILxEzxJ7GB1YvE7jMtZuB6gE/rBpccnc28Bh2whhIu9tItGXDMnAy
P0X0DPjQvKp8YeMPwWwbkAv/0ZrHtxRafNfBvlMZ8lgQnqSlIDfhqJZ8RcFBg5EBaAtHS9tzOv3+
C7GtxhUoQJYQsgXkovFmqOEyS+8cC1MmaPp/ePbflHg57a2WJt2c8HpLwUtbrphCFVw1FJCl0tzT
wKfw4eF6bKijYXGU7c68FgRf2sGt0R7sLpC2YUBiJ8vFz8ZCJFRlrw8BcjAJ3sqxAQ5h/QzvLo48
fVkXbEvFYAMFcMRwimWcx8Bc/Xj6UFBq2YJXmSlZphN2h26LrJdynQ34uHPiDck3Wcvu0TPq4kdF
m7MDgHN8WF9R5PmW/f9CUfIAPMeE7PeOcnUWXW6RZOzIRn9OayBgcQeHvAKYecnIpfPVDKfgDYpa
pmwW1g0RCG7A4tvZVijDilU4LDMgJNd3xqKp376CzO5tSNRjdtslXRoJxDqqin/sBHEgID4L1e84
OrP5UrFQBHPyFInkXN0b0HY5vtf/NbzkY9qa1pIH0y4JJc0H2A5GUo4TG/cNAqjw9+DnbRB1oVde
lvPqLmH1TJQ/4lAQy4C++zdgVYsq8/fyHfhouEtUpSATMlUVMQK6+U7vKN8L6Mn6CnbUmx4FCsl1
ncHiKo3PfekSv6nfDAkyLxKzDVZtL+B5I7gk6vB8ik0JHmMZIYyLv7h6Saw/zcCnx5US9ABQygpK
1gs3YsGUe85OuqfdUQX7foF0/sUHaYl4ZE1oR+cS5198DrAJaIYM5agAaM+gu6tR5pGwfGVbXhzD
nj90IA881DWj/TLyvuh209KKOExhC5Q8uqlb44d3GX986yCAp9fpnZWTovHrZmFqdTFGPtnq8cUe
WfNekpsBolIFrxRHc0XbgcUTs2FU/nksLVf1UuKf1rl6U8MFb2aASHmQ6YZ2T4TdcOzn3bYschAc
J2XJ4u7/ZIOkTs1GzrEeY0WzxRLGsYg5dK6tOMa4pSHg3R6aWx/PY3IGgK+Ia/iMFUjFlFfzPFne
//FELwseKCn/8OfBnSWUrbYyHFU+uctXfdbpInG7CSaQQCJkdCAh//ZLB0T9D2IaEsX5cDT150p7
MspctCdkmn071YKgk5UdZPFsh9DD0Hrm6QMeT3ivHG+42+UE/FlNMoC+hLJ1Em0X9XOcaOGNpGLC
trtgeNRtWELe5ZTSDY06WmbW5MKwFv6080WTGwmhrJk3lzo1lXzq+3wnmU9Mf08Qp6zOWSTDhKYm
tOOX9fcD9mVmtGcboBU56fR+nbWei5ldbSVAqybx2faf6N+7lzvXagTC8baYQzPtkjgY2VVBBd/+
2EjKOBCqI/xBcijl9q661aQwwuDj9kExEZemmBVyThhskCAGOtKbK48wEtz6slTU2O+9ID4fFULg
IMrjodPw8wmS1MQKcgGGFuK0DlszH9GhsE7iNbz4bB8RGW+qIHyDxzbsZnONcdmiKrpg5uz9W86e
N6rdcv2fKn9bM4CBU1pYST55dLebTrGV1XL+7xof/4rH8AxUigpM6MlMELetR0fuHec8q7oOufp9
HUqZGI3pH5KF7B09tKeN01oQZDOA2P35WI3mUhbNQwOLJjR2