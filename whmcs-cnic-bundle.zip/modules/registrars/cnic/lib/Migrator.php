<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvL3EWr50PyY48slBgU7iDaYDGyUvnbWRyjuBo7c+JCTO4GjfEGwqyU/O8hW9uB8QFKGeaxg
LJ5j/M/6s1AfTdObBzRvQhURQEVfG4oqzqni1uOWZGrOXSS9LKnDrHvxaltFa0ZKMbgygmQhC0gc
OjRMlESn3RniKYDXfwVRG4LvcUkAWnf9XOenB0YL229giaRsjpzdDe9APgjjpjX6BnEPzTRfAO8Z
sDXowMdHwAWBGHvJiHgRdLG9f3vzFMdMt9DzZQhIxozYFlMSSWQDTmzBbsFrOrt1tafSWz53/X1q
CHYeD1dcGxfC71dkHqat+NxqN6kUlyX5TjqsMtfqb7O0vGYbsjzyo1LaRZ/st86QD2kIzbztqkzL
oBMt+gAKvm2RpTHf9m8nWaL5LHKZ0CvRdT0FgzfTYHEYKMzTlKp/4NbPOQ+rgJlHHwV93cSoKcK0
jzdWY3JShpUu7wXw6Jk1GpFVFkNcelksjW9YbzMPtxt+DOvPE7ybgFfS/tm2KW5zwfY93dcauuOq
abK7kpgSpx1BbuASV5+GWUbd2c5Y9P3pISDMMgaC1+VC7VBKru2PvxdK7fskREI6TX4vknVQ5JgL
J1idV76kkbVgXcHHfHVZOdBz3Bierjb6yKqBWleCbuA5s44oV+tE0yuRbUyCszacr8CA93wNnqSL
XlWlYi8CU6IoX3bi8phv7wHtBgX6um9QmqcvOynLbTrQdCnO1mMbVdJU22TC8MLt5z6VcVCQJO8K
o47CO0utIQbzizJmJR+JgljyfsrHXBjZXUzSCo8bCQknK+VVOXo91JW5oW+XR1SQm5IIvnX88PmA
S99OqdXv3eV7MLTcN+MNurAm3LZMsRC3Tmxdbm5WRFeRIqaj5dTsaE39VOQlR82pi8x6Q5oId1V+
2Fazt949KHHJk6Rhc0KvDk8MLGqYqRCoCSpFll1/y7+j/10pg/GgXxLTm1QjEqu8DAuiSlcLJ7cU
9uhf2oyU88GBkNJaxph65s9pzbYirhGIZPHt8jsk2YHtcJA+80vxoqP/97IE9gykwru0I5x79YcP
HMZWQaejd44w+r4jTtzwXA8FsSeN09cvrXXQGfT4vnBBrBGwKjVfC6JOnRFDO96TFOofoPVIlqLF
yv40FumtzbRO576E+ADoPRGDbQrGB8SXt2PVwFhPjXs6mXX9qwBIxIErzQkgAAbxI09S8anJD06Z
uDaL4Nn4MeHtG5MGNHF1SCXIpgcqDWIatbTiI3x1K+3Syv4QzfGmt3zocW87E00a158VQUkftBUy
AGg5nx8gRnB6rJ78q2NbClZeD4W4LcfnoggGnSzrVihr5YxGZ5ib4CiiyhRB1/+A3CNLMKdNv3HP
edJgWZFTACGIgc5ujYEE0g8IWYbUEojlBgLkcsuneQBRHkKLa2ndJLSGawhNRXpCqtK/OWVPLLV3
fP/oAWTAhy92bdDz5LhQidEpGS2w+wuPMVDRufssC43nqtrjClLp6PHl4jCXc6lPUWG04Syfj4i8
gXFRajQoWi01L/uZGVn64z8bjGWVzeTRa1yfZWdjsmyPbTO3NtO71XEW2fZgIFh1hszOB1LKlDdV
YoZIpzaBwVZjsOG4Ll4qyVe4AxvcFhCi9TmEa2PTse9irCin6Is8+C1G7W2wL4jYtcUEBBUzvF5H
WwHIjqjuTqwhg4Ke+B+VnZTy//sUGj00MSepz/tQ+VUElPQ7xv1jz6Qd9XptYSf5zDnwUEWAMAAe
Ns/ZEGAAyU/sWxDF8awYLq2iINWOgxDgHc46zNRB+u/+ggepz5YQETee/kfrcmJ4URhAbB0jAAgA
wI8wMW29n8/yHHLLLQC0gAlUN8pE5BGzsgS//G258+XGE9VcR/EEAwQ6PIryJF9tSU6JKVMfaZzS
GoGlrE71OVdrwQx9vWDzB9WVMCTRwwG4WTrOwln13voBtzZa74QflaPfdqbAtstSp6jPyg/PWtmB
Q8U/4JQ3SCtyRscMwIFCCGLsrYtGUPFz8F54E14r5un2glJLfGLtFOM8R9qAi52UKMmP/08OmogN
6dXLi90Wu94dQFC0UvJzDrD1QhHkqmGNW8DW8Byqpg/wlCL/1jYznhUQtWC2xU0X8JgxheU4/i3P
/X7x5XP/ztwYWpqmN2Ji/uWXpv9izuYEd+j4CQ4hNbxsaUUczsoFJT8u0GFFd0iSzashxJy+xhRu
15pltXzAMNU6gEzx1AtbJTdxnxvOKjcOGXZUByLUHZV5/RAGSMaFldZrcthf+88oiMApPTNhYHzT
K344sb247T+LiLU2w7Y7w/ce/uoZEm99rKiIpPv6Pl32zCTgPARIo3a92C2nZNKhWxOfBJPRs8cO
wRhHr/+tfhVpo1eYdUq+1eIZZNpMdsC11JtkubBfBX2iJScC2x7IW6owG/DnBxeQb0hkBXIidRtk
vvrL30Ov8lRHryZoMP1c6LtrUrrdfAtrq4Je+aPBXSm0mU1fks47evl6tbSP8EaDxFbyxhGWfsG5
voIVa+Ot/Kzj9AEtdnJnIqA/9E3NfbT9+nHvwC+wSpkmuoEcdbC8m7+Ty/MQln8N7chaPqgPtrPH
ilzPyfyedZWZc/R+hBmlsk3UL1fC03khmiDxckGKzn/qrAAgxYHu9llAe+OeEpZUD0cjuf41+doT
4DTnavdiLoiUMMDGEndKAgVn6mFfurqrmkDu5N/HpE/2gAmUR+Ek80DorfYzag/nHwdUd+tVISfN
/+ppoyz3cEJnPF33tgqHUsRdLprmy38mdqGLilrUMv133wrLW6zbtcC8vNg9pmS/kV0lfxU4ynIE
AH1EaM5jsQISS+tLTH72Peu8Dgc6cysOoSHd2yxDpWnuQR9vKXziHcZ8JSJb9a5YzKo4MpkGTK5v
MLGYfXLj2KPth6INxhFHU6jK+z4pzxY8696t62jKDaSDm4lYDra0W+WHfyscLslF3HbBG19svyWv
lwWE5OsKJwSG+8S1tSCPaJtVpt3qK7xlyzOgFwQsMxe/UOF6iVPivjY7HeFmqk4CNc7Qet89FSX9
uy8jTOrC1bUfI/y6/A1/N4H4O7B7QPNci70/e6UVhnnYmEFrACkeB5Eh/MBmkLKRbnzQCMvuvG9+
BSUHC4kYaCvipd41T48DrJl73DoG+LgAEif1RqIFpHuZeD68d0LMOgObsHyLuGoj5IWUYTUOL+1G
+cz9gvN30DYnKQsygrpW44VCv3kq3PZidm8JtpMfjMIc+PU2MqJzz7vsaW5r/qJU78aDii0Qj4tF
E1b57TW/7d0zTOOreCLy+lHwhCrZUx0=