<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrwWw8SJ8D6ewcvzf6otZyH5HD+9mYYBclY9RuciMZrSQ8vf6AvtdfX5i2X+ZMCjEzpqH88z
5HY/Dv9PSTVbyUCGKNcTDdN6Qw9Sy9gdZo2P0oVP4E1knzZsomWv/tg+ApPoZLsM2UJ5aGVS2YxF
42O2spIQ+sYN00u5QjC161wJaaRvozwtJrnVqwazlex2MqpfJoQ5UosvHinLh0z79kcbLfgxBZF4
qn5ZFLTJGcoRTPzyuguPA5tmKxWDc93M4suofFK/cQ9+BasLC4HmKEQIKNCfPI7tthk7ODX2ikCw
xTs7BjMA/+d3j8ICkIj4AJaEodP//iwhRj9XNtSmF/LoeCLWlwrXVpJPZfn16okXNDsce2NGlYYI
97Eon/KxndUxvl2yV4txco6aq6tunA1Z8Y+I6XngvM+ICWLSrcBIA57E49xHj2ETB30re/E7GyPq
XBiAd390mcOpNETJEgt37Sq9bkMwOFmG7hIb2vFb8JSvBltqNYeNYwwY0k99zJjwl2MwYPSHa984
kl9sLPYTQfvXyJKL/vdDteoMexejPfHA2/3bvEV2q11YuupPQurA8NoDMZiSsJMElsCfRT1vBdDN
OiaIJESNkDNP25weGVovIkFlMAbIWHfi7lNdu8W7Us5QSazf/wVDN52zIIGabfJWoaInIMjAzWys
urh890U2nWooToF2HQJPcNLzHRLeBqoEqbNvASe7Dq8zZi7mcuYxD5QD0XWxRqvJUf6dOTp1hyRt
IQChuyFYra1w9CaHjyUH8X+RvwDAebmIKFesiFa5Y6RemS9QWasjIGvLbWe0zF1H97zn8KjA5F1b
BOh0Kh6+1QkL0q5qWOUjeQTBFm4scX8UmYBQTQkUxNUh0j6uINsXkOWX9FsRaTwn/YUfxV3bIqO+
cn1DIw2G5B6ebQdgavc8znvaRbUz5wMVPnJ3l411Nezc9WTsGrMpQ7lesNmT2xEfh5PUSVf810xO
hV6MauynjbqxcT+YCvva5FOJxxkz1wxxLsnRoDF6zXyz2XZ+AnqqI0gtyntMboPaiBhaUtWrXQZ8
/gET7pvRUXFDBvrT0KoTQ7325wcRv4HjIFQeB6YnhMBoXLsy90e2Z60/OfXwG0UHh3HNWdtsoCz4
F+jJfbtJRyabtd+//uGD2boWVUZVRAGBdUsKoQ1ftGNO6+z0GvAVgTKJee0ktvG02YmUHSPsgTgj
qSkDFYF3HoVCykwKCnGeud77LItbCdXIODBXqXnZwHD20oCDI3yjx8Fgy/YDZ3zSwYqdnagR4GYD
5hYc/P6c9ZXrGGXrl8VUnnqwuTaH4gb5sNOzNxO/xPZQEOA/efEtEojye04SfHesdRsj4XDZLmp6
Qy/jtMuISb9Oa7OBvq8RG/GheT+czz3y3ze3a6sPBcqhJsKhQK/iWwwGhuni97Op1DpD+vNbzCV6
bcM+YyQMhcsHwEeJORKHdcUw/98S4+UAXI/tyCIN6fOwZmFIuD2EGkVUEl75bL8rGJyDjTm0hdI/
Zbj6e87jfSFlb/oHShSSgz4ktbPQd1UNZkg7zW5OUGESo3iWJKQlWJBuj8i2L2Db4nugLBEqN3+O
59w+3z4XBD2q9U+RZLCdFY3guYuzHRBK0iW0JgKBxMU4/mce3A5Lf0EbX9DTCFkq5h3AAAWga+OB
5TyUHF/xjAdyklkjt/m7LhJiNflc0mB//MtnxTBLio7w6meE0mkGbtQG9ePkBNWnk1aluV4lQo9t
4DFL3Jf/st9Q0Du4/2CPVR8ld1pN0j8ARN0Z0GE5Nz+6+Nez/+b0NILUO9U+54GTef16Yddi3kRp
KcxEDUKROg1syY3fKrKSzOWgX5Sje1tI3NcOvf/5SFatpcW/JMwRwI1vIDWOtgvy2E+5ofBy7Luv
GmSDIY/DMkceEElKTnPf5wFIjRT72ettqP9Pg4Ny4mp1ozXhZhQWPYd84TrX8kbOKkzh09/7gbip
nsf+/2jBTOO7lB+6f0g7RYC8aUkuCH0eBBATp8mg2ccinR4YtcWK9VvxAPvVXks1x9WTMHNaGZ1e
EPp1wnrRdek9Hlso/P17WlAPhdNfHCOrT6pHHsUfs7KDUGgiSFJUNKzyD08u8XyMZ9NGvCz1jhON
RU8xs7Xd2OCMCjWgozgMNoBdWp1jHYJObRjxgNYacQKmr6zJJUE2RdNNpgYoEDfHzGGJcL+bDMFO
PYHEeDIYfA7dHO6k7g1omQYkHiUj6b07VR1Yj/L0y5ZvvONE4H9QoAmqgYPDVFO3pWJRqgSEKCFM
LbEnHl3R2y87Ilo8tSGxrfr0pzgfToHJMZjeYoYbZmD3Xv3aHiw1fBQdhXZ8J2ZeUYDdW9jZIdWb
mFZZ9WAOBo5nAX29DnhEzcIT2SPZvbTI0IPx2m4RYYhsbFmAxHSecnyCGBPLDEb6z7ZnKGnqVPIz
7ZFkoYxk9ugFXb2EJ5SjOFZw8BiVmZGMwOIsgkb/t73P8Rr0y0m7pzek+rSRS31plm+CmrUotNzu
NX2gJJihxzb3NL5Ymq754zg0gHA1cGcEp0IO0KsYCzRq35jmCMtJmanPebe4G211b8eAQwHYQNHe
7FrULR9+QnPFYnvPvxzd9974h3zK4tewjQTBwCf5NShHXLSjpJjEEXzh+v+2ZejRoHMFAe1g2QEt
mwPwkfVp7+oePGdZnSnT+FCVPd7lGvqoGQeeWF2OyBSxa9f9R8VzJGjXkngUftIgQudm5K2Wjkaa
c+iGlHh/kr5yya676vNSU0SdAsJtRLXu4w6vh06B8cgnPGBvvIwNXb7+yf+4/Y+ZZcOLeZdQFGh3
VcJ5eW/Nszq6dxMuMEJl51aKtXHtMffFAsQSdyjnEzZzjvUd0/tJ/8lmMWbxe7Y3pDuOBozXk8Gu
ASOFNVo3l9b5V9RY907J3ktJTytC0IN+XGv5pHQsp4IHMVYU3B43zoXjaxl6fDykmLkkmnU1/icD
HvhJnu8+fRdL0VLoLPrrlATc6ypk7Qjw1Lfsy5uYWp0Q79+LXY8NVH+gkwD4p7KAAp9WjHjEX2kZ
+RBJYQQEzgjpn6w0b3CeyNVBGmxOjU8W5yQgTnPfi36G77cl6YIZCF12gyKW5X3P8rMQePcaVoFC
1pcYD8py+PbtK/b+sS+titWOW2KPvn2GNi7dBlMxCGSKqWxhKlBh3+b0DiKW6YtKc66o1EHmC5Zm
czJcSY3pDvppWSmOSyUqohO+fSp06MrObV9r3pAd+8EVNxDVfZrK84WBd2178PYm2eeWYg0qc2mS
fQIcpS8h13H213aFaus3v/7mYTsMgRNdJgtv