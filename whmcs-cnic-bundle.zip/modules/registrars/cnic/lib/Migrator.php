<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtMNTQaqDKwFmLdWYWv7jI5wyWVZ1O4wJv+uD6ofTs++PBZdezIfBMre3VECJBtqIKkfAhFS
MpdENbgWdBqooS0d9wM96R3bmSitrSOcNUl+JFuGr6UMkx5Gleo0JqCO+xrE7tW4TfC9Ldib8qHc
toyMN6CntTFb3CqjoeA3LZdWR5s7+bJG8YTK+AwJmYYObVaCUqOHcD8zSIRJAqXWU2SQbY3YSmgF
liqRMOwRjffj4DIhH+HJi/zGFdhoijzXK7WnHCJbVPVNPnWIKKGpvUxVHY9dKPsnKZPthj2+a45D
mWW20Ks2M5Nz6ILpfwYQyg/g1Z07Mvb1NQrrXrgxw0jLM8jIhhjPuJBExQr36XPtyAVNMRPHrWcx
nI0U5BhH1UZOMVbGDqmM6BNTw8KXyOq43toDU0+R4GLcHMY/GsAXnkJJTMqFGBWxnLLDVciwNpML
L8qwZxnmmC7/n0Jts4CPv5bN7mv6diiQX7J5UWVBQzfbH2q/zjUQIVR6/kgeshwp7EFqpH5auBTz
QXNbK4Tg4ZQb0+jt7u44R6scriOKY/arz0UNCarzYzcKCuCkNK8453BZIZ697/yJw67jl1xJjE44
qe+mMaF/bCYxUCKjckn04KOdXUgjxY1OXv0Vk8GlMrLKXY9wfptLPLt5FuqseLmKBvjQbMWR+YWP
CaPpyip1WQP4WC1SiDctBw3Iv6Of77tRZcAVfJDx1HwC1TIlsVm3okT04RRIa2ub71M9TmJdJad2
wFnDEH2ETVAxzZPt4kjIsjMps8ANMFMSOsAX+GAVxqRWzp05BaW+g3LxUD+2w0LJ0TGYXLLUmD/A
X/3aF+T6xHtkxyh5a0owfUD1KYm+t8Nixo3EoHXWxMsfBV57v6TiEcz7KJ7rEgbxBfs1NoR8H7Vm
wcBuyrlQBWl/UxpJHPh/YHw5CMWDE94IN2n2ec7WS6OvGeZq82BvSrrkTKn4U7DJ4rW6zBZVThdN
18eL72w6jAmxr2RKP0UWSV+joYLLdOWDJk5BDO3RSqoZg1liIDt1ewOi2iRQakfCHhE/c8ZhVYcT
GEtUGjM6keSEGd4tNJgegmXeQPJ5oelcABU3im+3JDWEHYu80UAgCosdQET5bvbLk4ZJhCqLTdHP
fnNFDXjoKdmLDLVx4zRpVKb1WpMuGaqgJa+dY1QR2lUXlFL8xciec1aNkliHcFeAZhQg3rObCTlV
1f1ge8f55ZQsKgmDego/8YI9CcM924LZUcCICIWUoDsIEn4ZrA/D/IhtwSQSNBVbttGEuhyb9LGK
sziDNC9d39G/CnMQzc7yu6k7K4SlKPQ2c/VO01j49UA1mU4x3p4jsSqYeoe8/v0ZQcu9GaEjij7q
IwF6mB5fngPkK5gahoT6LJZO/snILIDzQcgQ5iskyVNgNoL/uD96oxJFKPNCMfB8tEozlSerEtns
YBcPbK9/UQmzAI+6t2HtmMCjPZvNH7cUtLQaVKUMzJNGPnheTP39bK5dVhQT06jZqiQ+GFRT6H7V
Ts+MV8u0uZfelvBF0mbDPpj6mXMLDF3EvD5dcANEyPezTs0RmputEJ8XPsBvpX+iZb5F0G13q1Ux
c89lcziGruzdVXC/xGXKZELhd5syayXahmw/1PxL3pNMomVRAItKZZrLo1osAOSn6uIaxAlpnb7m
OiUiVXvFeeNFYw6uJQ42Eoov0c6KW+1mNOoNTbBbOxqOp3eApvl6dCn93tDxUkJaHOS3amek9hR7
V+8mEc5ZOzU4FsAN602q0yDIWJZHRbh5KIB+PRYJAOSUZaCbq9QCHWqFFjuQEZBWPcL9zHvufYtl
qkmICxCtxQ5WrKEMB1RaB+9TwzqW6j4arU95HFlCGj+BQC2hW+cr9e2J7s2zr46XZqyxuVvDNY20
QDnAmA1P7cBJBB6Coi2Ruv3sDayK1+p+NIHVPfBJQcwC8tGeG2sPCY+wEUzF914XB4qVosUxqTcH
SY5B5tpCsyfDErwmTTtDyAyxv9HQUXoz9mo4/FuMT0FUwl1wMuDNZvf6R2ScxG1D888K2FyXQKj2
fHmkRwIH5jMHe8sCwFZNaoJbq8kvwCtWWwJ3LuBIpogkwFkkWetWfcl3wHWVRTjxQFvub+6Hxtlp
zKToi7VlMQVz1fo5sRbdDIvw5iV2TyZh3J/ViWCXbjVpg6x3rYv9jpPT1NejNR6Uf2nzSNcqbQRk
c2nj7ENQ48J+s4A/sGfAuHWhQjJ7uyvBv1OnGlkuG3rzGcsv0hxWVIn6gEPVFSS85ahuMFqfVMA4
36rWfBjD2oHNixJV+Z511BGB4PPKvpq3thdVJxlGRSBHQg62ilzxUZKPno2KFeMsEbxHGdamhWKS
wXPWGLWCIPZnlbbEHYoxh0HgDUHVEqCNKWJBluPAOp/ku9e4gKeaDOMgMCGJlqgYGheQKQ7tCJBY
yUa3TPrudJwG9fTfmCZNK62mRzHnIdTdVFHRyiytxzNFhbVwOedpt9SdkPFq0y26lzYNNMqzGKIi
lHUdbvIjFVdKbBt9TTVqS534liS419O4kq/zNu+YyRwph0LwgIzmX3TkiByPfyqLtd5nrWRiPacL
6Otj5MxEpeWI3UO/gYhj/F+UccS4dbXzGJqZO3Wpnl4vbleKiab0ccR65I2TRaDyL4j2vmS7z+tv
Z3ImWcFHGAUJ0ViQOJEc2L/R0K9rjVJ4whYfVmn52Blb/+3zwVb2rGLBJsxv3BMJSinmT1nY643t
lcR/I2W5CP7ipeyptTE2MG60gbDm2xc17BwnPTuVie5B5gN4LN4UWyZfVsKYraRpY+hW/EKUdzkM
2I/n6FNSJ83gWn10OcOSvbMv7LIMx14zUbOF2nMko9jDe636P+OYwVJ5El7m1EUZgn9gOtos4B39
v1keiSgudvpH0T6tayEpV4KCIjyPCTwa4i1qTGUGvXSJU+PolPBNnf+qtVwti5X3xf/qawprzWVx
G0ZhIWujDOjtCmonlfDsNh7sffNDZ/V4TuIC0GwQWJ8a/z24jqEOyv1NNHTs7uKjf6S4OBEAJaOI
fo+ROhAPrHH/KmU/6NsxZeW2Cfa/mhaKOeVOl+j05pLdKmzK2h8OA9GRr+fDFr6/IEID07MGLxrD
4HV1Gc8lOcl1xVXRzIVUSlNVdpNt0D3QVg5TzfVyEn02kXCgqQ8cnJyPKsMo94vMcvCEL8cgQtO6
6WoQf34U1neHJd4GW3wEpVDmsRT0zrcm4fY8OdabVCaQ+6jbtMxBLM26Ud3jFXoZ9wNBuh/MwEBW
21knzkfuLlZjr7UQWzMIA8jR4lMcYg1dL4KU