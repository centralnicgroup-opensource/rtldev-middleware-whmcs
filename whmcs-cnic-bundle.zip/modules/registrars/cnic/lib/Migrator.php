<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt/882iAc9aCqmQr2AmOy2rSfsSLBm3SVkqR+H5JAEirL6D5MfIq2Hp+cNBxHoZey7gZ0m7W
f9pHtjZA9f7Ni9VUC2/Vgtm02WpVKrOHRGc0goeHiX3DGQM+CQJmQ6rfaP7rzzJv4guMbo/eYac+
RmDG8rt5+K9ufkRczfdmaw4Ne2X5GtwA4EA766UZp/XHEiyezq2GcgzIbmVxwfQeqfYyfRo79xYH
117/3gDeVtPAoh+KK84eP11fgulrJnDnLWoXxsTH+xCgcTCY+fDMuxD//P96QPpirmScChDQa47C
KMFd2yzEN4DU5yQMiR5gOctH/bx78CY4S6Xq4jvOyz1XdwbDCW4kbITliHtRRNbv+qZsVn5mBUFb
s6a/Y1PTp4pNfm5akn0Km9Sflsv7pnKx6m869PTUjHCEQ5jtrCwUck3D1Vw15EiT+DrPFmqOH+3e
3WJc8XccDCRRz3xzxxn4DyiUq3kugyKjXeAUU7RTGndwRQzsqLnhmQBgbQTYFhybIQKXoPUVkEaX
Z1efHiNUojPUP83jlzIL3T15w5UEO6Uzm8CxXZXF9FWD7H+1/KJI5TwB3Hul/K+4HsFOhmrSTrtc
pqtzGS+y3b5NMW1LsNRo6I7gLG0YqW8SLjirkKGg9VDIALyY0nDp68Aw2bATW8nNcllFfjU74WVT
2/c+2wby2mGj4AZ8Bi4N8ewxk88tj4/nMTUvtZvK9oLJYpjIGl6XM/MAwsdk2rBjeP6n+mvA8ESI
UqvM3mna/C7p/61EYjO12bOLE95QPVKWc2A1o1yn657XIdT63rT+n5ztvVXfSQBWNz1MZ5T4gyH1
3hQWtWEVRKEwQd+InOvpZQSYf+Mz39/S4sitBKgkyN0daBW3/e6Ivag2tZPbT1E4zV7aA+2dfjrP
vlANdYC0jRwxFpf0oR7BkT8Uw7ameJ4ub/o01HdGoUKD3eCLUTETJuD9G63ratGoOEdBS8DJlMUV
PfTfHmFXoBBJLMBrqei66C7XnMvEqagmCdBdohAcx6WPzda3Dh5n5VHi73x65jBZx4JBYzLxvvKK
tZYkTfrkJm6EGjS9IIgBRij93vJwJFIteaLa0/9kxruVdzJ5qYlR8lt+ZZ54i0Aivep8vZ3v9P2F
Yqy6WvZqtPuzhhMqGiYKauSN7wdPwM7SqTg8kjtUHp0vP9YOKbWoI2zd9pWQdl6SUf21bvtt8VtC
wm+k4UaGQgXYRoo/k5fACCWj6wwRgUFCLCUsTFt9eaB1mDstHDbg8pKuWv1dDvL2NIDXO5vqq0ur
PaEx3JYW8nAa32eRnS49PBBJ0gDWRf9Rbs/8mT1dyTm7f9gJD6aXs8T6VkbBMgZijnhbGFytJ1Ck
6rQKXsrLTMmsKrqoJtaJ/CNjXTafSs9szrOtpJqbaUpyO2ICe2YolaD0wrVOhY9+r972+T2RokZ1
j5J4oBe4f+JR3TCfdUb/I3ClxDqLT93+DXiV4wQwNU4S8vnVtNIV38COldQcgkn7Ej0daK+ljyjo
U7/sBIo3Vi/bOkpgFeERoT4lpePh8xNohRF6QZ3Vx49hJ8C/R3J1mf1tAynfeXfQwE61YxntZOAB
Ya2Bqpa3qeSki8Y/tQHTXZ8La0AtK9U14Ru3gIRPQZbXWZscd201U6J4cfz/uFBNcISUVfqe96mu
uuMRzlxLQHPSUBmkaN2l7hHqrs0uk3X1/+tpVzj10h1H53huboQs3bC3TgxL8VlazdnxyUhMgjHx
vHdYXZfvlnItc/7TUSxXfmcmWL1DjZO0gM2ER4WtDvtRl6gWUwOrCSvMQzIxPgmoQx8pFviFA7j2
3c+VfHazk5IBy7yofTGKYtTZkBlZUj+w275gd3ddmL3sm65B092SJobLTUw/nDYjx1W/EtPGdto8
CaaZfl0x3bF/4FtAZcQC2Q4zZVL4OJ1hVVJ+eXqTs1tC0JBx5gyEuPblfM69XOt5K4FCr/b9n8oy
rj+lMua6XtvJ6GK7f3u5RozKFRk4s4YBaJ5Vf93W2b3Xjb0IRHwvk6aPAPDVOWrDxC1Er3t/cbvK
WkLsWDr9u3Ck+j2/927ls7hEMbgNkbIMlPQpM+J9C/uMu9TlJ/n2xXi0fAkS5H4Vr76X0eqEaQul
jY/y0BEEo/qpXN2XLKg5lAJCh8DzcVI55pTcYuye/+RDGSfrXeNMGWo/BdSdoI2I8b2fGCGTMTB/
XJrpFrR3NJMYCXVqzkULsH5IsLzEsJsQJVLO1oV65Ij9+CLB4zW8JIzy//sRI5LE8vf3sKGtsOPQ
ea63SrI0Rz5nbRHwx9KCyWTpmuWjdP+mgrxDlStJMZvyB2Bj9Ww9y7ynJNLBZYLVGhPws1/Y1522
pps5Odp/q+qDzXeourUCnEMobmUqgYiH5r9QdN7dO6VpjsattAnGdTR9GDML1/J5YhgZHSHZm5ix
z7+Q/AN3qOXMWKnN3HxEdbstpdGIDoBd/5qZULuCG2y2JellK6m6574ZaU5sqbFxQtzpbw8l0opX
ve/qEfTdJq/mwyhnVLTdLyypvfRDUBr0HklpZbFZeLD1gR1M4S4EVHPdNltloLLrlSppsVXdjTQW
v3KjLgcdg5BDDL5hRp+oTUwvZ+63JB2tf/5+yAepuwKTW4iOVyOA0RZR5wLNRR6WXCuAn3XB3JUs
FWNcv2idx09KpBq9JSJ0yMAosfcpp7F+wkfM8S46QdTz5gQKpVbYcYxCcfDd40njQpUClF0gdNEW
BW+dzdagcp6/ROb4vv2xOllFx8r4RW/4Agxr01x6zBRoNufTxok8y0v/rpOn4sqQd0rI0t+wucON
GkKx4RfBrNOhE2FzbKHoCz7Sye27QVfYwb1u9OcKe1FpwL/bV4jERjEb29d0+RNJFwzCkJ/4+ckB
lrlG2QBu1PvfY4TetjhYje5D4Tr4OOVEGPMOw4LIubmEteaxTDUb9vNnfL8QDI5HYcuCOwj7LaE3
JUQIrNrR8GHytbezRt2AgtCmVEiMmaEDjBxkF+nwEPPNCM29lxfupxAD8rn4U433+zE6g17G5E0J
M10ckRPNvwt6MmE7QIMgs9FF3UKnrkmtui50kKK6LBzf6B6guaHmUCXiI5wcj6gnfYYz+9a41Qgq
jrV/Us3HeafnB6aPgveunYEyCtA+g3Xg289ncItVvonn4e+JjxF+DKcEN6jpucmtrMhgmY0Z+wpq
MiHrjSzddnr2a3QoBt8jHjnbFjyzIAb/H6/4SFSMBxelrU9bJuGpI2vlqdXK13MW3xyRyq7/8FW2
Lt+nwHBBSQeURye+XGsHR61yRXCq2gOS1B03n/4kiRLXBQ8=