<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuxGlgaWS0EEFHuhYaUrcNlc8QHJZ8NUb8Yui7JpFQz0gfCvrd4JYkmevFpCUCN4/9mlwEgB
YImbt1YV9PM0gb0G2+tYvZjY61+FfhZE9SZgRkIcCoa0fPp+IUKZ0Haq8SFKAeR6ey1HRr2ZZ93Q
OiRX2j4umSzlK1d6q9Tn2LrPspRMgCIS8gwA5SG0JThdSmONBm575OV8LCXf0qYS001tGNb41I5l
UDLqqCG3OCnbsnz6ZtgZWVs5mpYRZrdG5/0JFHgssC1YTuRUSO5ryYqJAdHc6uWj6gGkqiDhpKr2
xmSekAGiKuOOGVI0NG5UWd7tnlHSByyl0gbg+YqTW3an+REhhLEAFnqKh8W27s2Wwbs3/PKPweCa
rOLAIAN5LRG0TMSFzUDWyu1lX06GH5mJ1damLGxPUW0tKhVY8PvbeBU5mHjCtBbSKmhd5T8E0CXE
trKbeTFdb2ZDXapqDjnhvnsBMgg2erUF8cAUi6bNT2PyUh5L2oBTCunlxvS0y3bfdVWGGqmqjJuv
zoEblmQDKAFQr+81pMpJLbg8mIn61XZ/jHzfuvvvsof9WdX0X9ON6EHICA0BTxf6CkHNynU47Nyq
qrDIAK0Sg5CJVzHEmTEAVRHtaKEuNe1dcGv7CmfDACx1pHZ/OfyXTyXec4RHcUw98Ad/r88LToF/
T1imwA7W1f05QFQzSK7Xm4ucdwsF5L60wnzQVs6U1OGKQDNoAHs5Ywe07jpcOC9F8Uwv8DWEIAEu
2jDPn4EA7o5FVJOsZSVCe1B4gnhMl2IKzTY83npRaYKJlTYpSeNxTO3Ngxn/aoisMeXuYfp1jGZK
cP/iZD2deiBa9rw2gPhj8aIxa80vBOSgylnsDFR2mLYA3W4jXryej4M33dZEWSnNZ9+I9Ac1+RL4
KGLutERj0oLSuQLyP55U8QstwA6R93XwRui4gMryiUU1uQBnhN9HmcTRfamxfLU7VJ6oybPHpaK1
AXD8q7WECLT/3r2ilwNFq5ujZoGG1XoUFLjRbVxRSYZ0AHRBWU+ugqHyrL6k2hnd5lPV6GFNuCwP
OOA6Y8fjFPMBRN0GqxoibspBGEiX5puEbd0ByuvJ3KFCqlk5X22H/bSCrkhiInhzm2xr7lutbw0f
cc4Y91AxPLPImOTsYF+pSj7gZnLRynYTXzq8KLW5PN1gCn6uZ0cg+ZIPSdOw3egjjd5YHhrRT+cA
9K5MEPeGG5o0VfEeoXs8u8xL11pyBkVZJm6drdZwm5urCC0ZXHGR30qoYeDWpwgKAx2TZd8HcbhG
CgE6L1d4goWhupdDBVcMjwELrSHB8/uDc5VctJthL5dhj0uC/pRb23vO/xouvqqHCwnkhLE8xXYM
8DjNdAXqYmNdVlcqBqvKnWphEyZM//dsEwSv9f6wy++92qa/7m3JKorkXW4BAND/q8piEJrtwkA1
wB0tGpUnP+otoovzDc3gxB4tZ9h+ciTfLL1sVr7vXQ46clDs4KhFVaDdctXC3zT5uPj9N5qPEf7x
K6XzMWQZ4hrNNMap1E7hdr4i8mu0jwHAbgRxgvFl+fjj+iPRSsVlSrKllUX9VheXV8lAJJK+6Pr4
Hni60IbtS6m4HVzkc0SvrXs6TmurL9vq2hCul4tifBWt73BckeNMIUHPZyKg3ZRbwxMd9IWXO/H9
lnwXekrcAhT+9wClDL1eXZTgouo4RcntqTA3Ze09ZOYXRVZ98w759Ny/sKM+5L1+w4Ge96HKigLo
n+WJZgkHaf1vgxEwaiWvaFDXgPD21kHoIkvObhgUjULbv2MWACwHxg7j/6P4wIfVnxxlN5fmX4U+
bOlixNwGSZIMuPsBiTAW6Vb4PeSlwLOnVQJl3WMVhJ7QfRZgrg7VLKhF4ykKKWxfoGNmERSfenJS
HpKEl098VDX3KwNlNNTMUWBxySAjEyCeI9LekmenWqR5kwKrWoATmCsK0WjZBE+584fomH0lTQRQ
y1et7UyvPm+3kOGF66kej//6k0DSqhwKdeo5BCCxBVwhIlp/5cou7NTgeDNC4XiUzXcs80/T3mo3
LXj+47xaMz36JFxiR7PY+iwIyoBZ6J8QCrbu0Db647/sKywzUyu+04GejisBHYIhZTgYrpdQOEVB
84fgAIGlc4buNLx3+jTvKCrMRSSajQLYSg6NaaXtd7EVpR+ybjtfWYyaMRgAW33TCQTO1Edi8UZc
Sgi9DIpVz3altttG0KPAzFN2IKZMHY2lQBTnb1KUD4epXRo0fP5ztGx4OhT88c2lj9nfLR1ROPjV
C/12ATufFb65v0SqquX2akyPE4djU5C4vtSLRZKJL4osIKp5Jxb5Hb8t1isIK9JBdhy+TxTjyAJo
dTMgQEEAN719n6/rv7kifeE2JXqq0lI+b4zJ/09/yudQglaCzj+8Pgglh033PpFMQ2qSd51kxGZf
EjcPdtrFii/iI7uX+KHEUxXXNrLpWtxSnV2qVHgecZbxlCCWNkIvXj4iRUyM1COY+KCiceXEuXtr
jKJFFoFWkM69zYt1OKY8wVnMQLEBRVjm4pBFvYeDqhL9p4UcR8cgTtKSjK3Id485ZEdrM6SGDE9d
xpl40uscdC7oL9CWDW4e7FP0p4JdqMClYO4ocufkABFnOzkGj4djd5F+WhO9EaGY3ezQuik01znA
4Dt43696my2zXMJdo4ZYT5Srp+xNahUu+kiTbv0Bd1UVA9pbHCoyj0c8HE/lnQc62EXLpHqMUnqw
0B9BB7+HxJrp+QbvgzgqDwm52Psn9A7GQBaVh/maQbGiyk03wj+D0bsMs9EbS7Gdm8C0/Aeb5aFS
IUZF0q/JxsUEjhs3X9T5MYDG3v/b9GB4NWccegK1hXTr8MyRt3FcZRu8qkwECd7iLTZdZx5D/BeL
0BAi64+cgJElqvw8ygDe2xQN5OfyHgidLA0TrfJqQ8XEiImjr77IZ+GEcoLxDXqwPkxGH7l7EOkO
D0wuVB+ex5wov6DoB8IfA4P2GJ/bNMo/RAzgcAMAknDW+jtDVicb+WFHy4Id/V6msdQ8CeEAFScd
YEOT0oPZ67BDxpO03F1tH0ImIq5fV7uThxV4TisQAplv4QY8kTKxOI+w2AxqWdElkq3N2wp7HjP9
DmfHHb/R28tv6YPd/Q5rC9wkWDT/9lJkjjZy0hUbC0TgGOjRKLfAhwMb7U5DjnFPXVhsuLu1319G
vk+PgkVS+BvykmS9hFaje5irPtKCy2ADl0x6hmrFLC3LZlg4jUiAvtirkc1amL9fs6OL0JdY/CUf
CZRtZoRn4d6/iCsaickH5sO7deSKTtjQ2wxeKInq