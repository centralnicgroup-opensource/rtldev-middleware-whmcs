<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/NdY3DgPN44SoaT45c52vsex5v/lX6ZlxIunS6VG4FW9IbHU61Jj1QmXVHyv6buk5k+A6WE
CY9q6zbKBmFBiZOFmcQth0UB8qPH8CKJdc3f84Vvt+Al7fmAuWbHB+RnH0sJ5XFMSp+aXTVbVZhP
6I1hbz/nd6DvNcsUTky8OQN4fnw/Jqnx/aN/jDqkAjsojqDAQU+ihQBF13C6bliDZM+GJKG4pjCB
SCJUo93cMPrQTts+l8o3RDkCW1kWQKAYK+o7u08rschs7159idl4hwtDl/+jPvO2VmUTBE2SDjTd
X6WP//93zFk2w4cI2BfRJFcMGy+mVl5DUjr3KElUcc/nq/DlQrB3McTwr0LtClU7qaaL6mx2WXSr
wTBgyzqAUNJIqCBDXxk61BBmiRzBoOUOWNobbHHd2oV6rTOQIqUzO9+OFjMGpxzy79fERN7S+laJ
75ajn/Y0oKD6coeZxEIM7ZlNpOENriIy13F55PDUk/N0OEGBlP7VEwrKVaiLAdr4IxsumAI1UsGh
UtAxiGfZ5dUGd6Zjvxw1P1+XXKRyPp6uIfUEMiNC3YeYO8tx636sZ6xyFh9QVcrzgOiIG+kQwt0q
J+khBHJybYSE6LLF8XD9GVs2aDSJ2/BVxy5wDWfSoWbdV58k72h5mKaVLUUf9bEkKGEjCBQdxFcH
O7tMBDeLOwzegKZ3r6ExOp24t1Vr4X8QOx4LEhpTDBVZzvz8XHrks6BDUqtGsAcSLayHllSeB6sX
sVY4dvhBEjFsqArX3Hqnu+E2zWQfp8cIQILjwyDOaJq8At/OmNJtCm9n/ho+YURwinQ+CZYVdBQr
xtrk3+6oYUv96igDLX1dzlHPz8t7CYomYgWCqsgiGG7YgJYjYJqWLfsWfl8A6FD7i8OrLOoZxlKx
jRcett7us30fTEJWBvBiHTEtbnY9j3172p2ZnL6gtIWQxZCKJIf4k5cF9tVIs+LKmAZNk0hQnQVN
XMCLHRDDbIVs+qvfMVzrnv7g9/VnQ7yMdxuSY3EyhymgNxQ2e63Haf4u3wac5xfMMHTVwZPKAUxb
h9Fo7suQ5PzIC78fDalRh4vtQBHcm1vgVw2vrLy6bSvFBtXi5hij+nDzaUPINTY8fVPbCnwUnlff
HnFaw5xskRdBNjCItBcx4xsoP6HPLaTWeH3wtFabDlZ7rG5x5R4cnZClhHU73AV5fGF8gaSWGD/Q
lM80CBE2iExlHd9QJk4LhZUvDgPvI8mpU14DUf7FUsnGRkC8y2Sko1Qnc+yLL7dAyjt9ovOm5TyJ
fHKpXpNW35ggoOOCxdUPifbQCUpHyaG+zg+ds1jXmqdThGjIDsD5g4Wchl8+9O3o0fLPTzHh2uGN
J7I9DuYSXUurYyr/mFSt1Mn6XVownj12EU+M8Q4foliONU7A/GwpBJszNgbSEjTWykHCRf6Fj+KF
rRg4tX+AY14hO2nIRp6D7yys6AavOvMnkvmz1Bv2kIWgxzru1geHS37zEPg2veeNjnP4wT8jbTLG
6gFQbVbP1vTy7ICQvNRwRnhqeJk5HuIFHAWTY0gG4KhpDXROscl+CK5GygwCw8OuFr23dlQmLahv
iHKkHmHRcvAx8XQl48T70RSfnjgW72TGq+0Es/8MGp0ibxXdFntQN8sxXyROkh53e1XptvoaVe7N
zb4kY1+RsXAqIfzZZXEwoqgCYbjzzhL53rJYzbJnFUGeOz4wKsZI4hW8wowwxVv2Vz0qqCdeh1pm
zekDvbX+C6/FUdT5OhbNXlLIU/aO2IhmSXEA41KcKlPEjHy8yrcmzDZzdbv+3Ft8nH38WdeuEJNs
kVuz1CP/mmJEWqS0S+ptBXk9w6fLO1JsRfkLzlXGXJVpCn4aqAUeRmjU3HoAm0iKU/wNZVaaVgbC
yAdbRTkTb44lxUMBn2bTiZiNe/ZqX1e3tvn370aadhh4NL0YNwUXPsz6rZe0z3QXXAh/7kR++RTM
m6GNbI66PAtDvs0tiv5scLNDezaqGlw+txo/PDyuvs2lkKh0lC8T/1pFLmQxAIYYykvV2eiv+fmG
3aDFGPgRZ98i6Wx0GJ3UWTPQMZtfiJ5cTrPB7RDzbg6/EDPYfdcgQzE8jkymeyVOvhwB1tQ68t89
Wd4nRwnpmWggLEhzxfK5ehTFHz2sjgRNa5dp/b5BVIXAWY8zBzoHQzrGu23/+cTCM8MCvCWkvbDs
K5NPtyG1I/gARqfmsufqgECAyULQYkvjSxDPjb2FLOxtfDH0QKCJwDfCGv62YMY1mDzRuAGiG2Ss
cjo0QNjziWgvnElkDBFWyM39YFe99sNLfr9ECnu4wNg7mmRH2VDEp0BSKuIUC/4mVq0SzRATQmpq
sKxD65Rw6j1ki4a6LxpTsN3EN2dvwEvgSn8H/utyBoeQPLybHQmXXunzNuIndR5CsSMCAVTHSQiJ
7G/smmz3LuRmkn/lcoeSamrfd13c5r1nR5U7l2uqie0z5VaW5s2dFV7WNgsW44TumRA58wJYfJlQ
rBCn0Ok5X8dRTcqld5P7rlX0QtNoXd41gFVR3K5ftJq9TLV5SybJvQ2jNm0Zt9zle7a/9saw5/4u
Eham5E9DuFp080zx5UaY+3rdf/A04G28awx5GwV3MQ+taytyQabbr4qo10grf9vGJ76IZP84tp1W
JpWBbS1P5sAqAXvGDd8mz7QoJlU9GF+yYoXFFNBSAXckdnw8GbwZocZBrtXGt1YmmhMMCd9zyZt/
XemRxPC+ltuZFcUiLww33Z4tCMmD6h2TGzEtNDkWOLHmW4dEvll7UTfjjUyC3OhnLzOLwFaZL+pv
+JQDoWylYkoE/D5R/ANO/zeTgXfZAH8hBnz50N0V0avgAp8DRs9/nivm4cFnZo20iOe6ZXxjPXlX
gVYTDpbpjKMKc/348wbVJmfD45LSxjM3WJPKcAxmUAEPGArOSMuiIUp5MsJWAoLcvfS++dJisaTw
oR5g4orfLWkfT6ELZa6bwRS6MSPrXYNltDWBTsBhcB7vG/56LJEUD11b7h+jlThaLJzOANgHYZU9
RxGzm5qUTO9Oh2yFu3NvZd3sfp19K8XQ46dDBvAXPYi+clG6ZSTYHaReuooWaSmTaUHlJ13MUGME
4UTRnd8ldi8Ps5xwnB2pVS/PeAKbZ1DDpXBnByl+06s2eS/tkssw17MoSEN3G0qsCCxQsOhX1txU
TnreD4pdSCRukW4XtrD0zj6PHe+WZuogJl/yTDa8+5TfT1eb2J+PMyeBQwyaLTZOFdWiY0HebB7k
jovMQQxyMwsN