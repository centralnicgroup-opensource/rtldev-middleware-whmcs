<?php

namespace WHMCS\Module\Registrar\CNIC;

use Illuminate\Database\Capsule\Manager as DB;

class Migrator
{
    /** @var array<string> */
    private static $oldModules = ['centralnic', 'rrpproxy', 'keysystems'];
    /** @var string */
    private static $newModule = 'cnic';

    /**
     * Migrates module config and domains from the CentralNic, KeySystems or WHMCS stock RRPproxy module to this one
     * @param array<string, mixed> $params
     * @return void
     */
    public static function migrate($params): void
    {
        if (!self::canBeMigrated()) {
            return;
        }
        DB::table('tblregistrars')->where('registrar', self::$newModule)->delete();
        $tables = [
            'tblregistrars' => 'registrar',
            'tbldomains' => 'registrar',
            'tbldomainpricing' => 'autoreg'
        ];
        foreach ($tables as $table => $col) {
            DB::table($table)
                ->whereIn($col, self::$oldModules)
                ->update([$col => self::$newModule]);
        }

        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
        $reloadLink = $protocol . "://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]?saved=true#cnic";
        header("Location: $reloadLink");
    }

    /**
     * Checks if we can migrate from an older module
     * @return bool
     */
    public static function canBeMigrated(): bool
    {
        return DB::table('tblregistrars')
                ->whereIn('registrar', self::$oldModules)
                ->exists();
    }
}
