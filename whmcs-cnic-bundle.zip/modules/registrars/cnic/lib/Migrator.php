<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPry5tfe3noBTsijBkNZHBOXxVfmSzBHW+fouKVQDrWIKHZSspbru/VUSyucZNa2xwkWVDKB7
+fAaHseqIuox1wYYzcH7euRMGRxWFVeicFCn0fE5M4zNpIU4qRMeV5kHzFuQjFv8pYbROWcmINig
zTP+VaSash/tCV0RrnnBYd7hHHQy7c17FwZr0fPvaiK87pwgvL2F/g6dmKWp5hYjzspgFSmJhpEh
oIJVy4P8K34m714W3K3g3gO/dW2X8HcdMYdkZD9i0s3r8Bdvcc7vv6pVtr5hMM785hKtyc3ueamN
0GSC//VCQSdr0a/Gr+Pp38z8azJdivOh+eYTKdoJKtnst4Yj+0AIjVZ0r7aFE59yv8zkyCfnKJK3
765ry57BjhbaQArecByjGTwWWzPcuk2iYnXCklqkO6l/OfmLD0OlaaU9p9859Tz301cVrKC6YqxC
XOe5WoKVmpju71t1YseE3cZaJCza4dfDUI0pZfL+aib6VR4tA3dwFfwl+BUvN0IywBXV1zso8ARs
0AGoR2GTt2M+irHYWBuXSdFPTWvUaHs2lxI2klFDfkGHAFmH7NsEPZaZpXuDoPZG4pxIn/cj7/n4
yYjhXEBbTiZnCZPL4MeYSfyRIQArewOcA7rp5b3WNnZ/gyGtnBLFSdvjuHuXkFQAhA13gF/ZDLBK
JMLdsauRr0UQBEEj/lpkKvMxYCNzbeKSGBBM2t6AfslmhJcRciovIWIP2XjukLNrKe1jwCyiEZkq
Z0KGBQJ0mFJK7O/ByFXY/AZvLYS+PYeuxFq2ydQePGrZ0HTwlDRXfHZEkSHtXKqCKVzt5r4N+pT2
Pk2MCczJUerH+UsGlLZidy/5qOG+cIgr03X8gIBfApNnZY0uegzD1v5z3SRb5NONZduA+QbQk8/e
KaVYt5eVjDZc38vriggpx26Sxal5jEtHCfMhaaLeLfqdYzz6d1e1h01UjqaIP75TreJ5ZPsi8mUt
qnE9SVzuYlE20/BiA+t9bBEqM+/DOPLlZcU6uV5ZhaEijBOCgRWQ2wgOHbwXILe7LSoV3wXs/hHJ
YLjvPlZ//x9k+2m9907cx9w1QCK93jetNixg21T3d3aGdOqp8UiDUq+suI9N9QzviomtaEMdmwsr
wtTZ4hoYFtpmxzAK9AmObrpk8s4p7Xu7IUe21rxDxJTtcCrQbXMkTRsH5fDnZPSQWUZzf3DzkC8+
wU3UKDI3RD5MjKlXEm/K95QeHkO/KHcZJttAH7v402Q3OhzkP+NAXYFAQNE1Uu0hEa8m0Z8ItkAD
jSMBAjO8lfUts30av6Hd4pIoW4VQfDlElGVu47azFiWn/nBmHEoSE5J4KEDtqjbZbMGJYaFve6+C
E35ojVoaRX2rVDMl+ScQzH0ifpMsaEPVxL+PWXj1tYD1wbRlZnYaSBoEaFLdjT51gt1gDbLrp/sd
DAVrizZNpnDvvW6urBOjSb98EYs/0Vg73pBPFfs0ZAAKXpNgpXPBTiL4uL8Aq5yk0I5s69F7DeFf
dxGGi9yMUOakj6ygDWCiyZIrhunRWunjNNUTqKO0scV2Fc7RswN0Ilpt56UXXBU6BAD816JLSRO5
x4Bg0oWUpceUQnJ9A6MStdG3VKWd+U/A0E7gxNXRd3zbgypKapib8SLwRVAN6mN90HmjUR3PxzbP
WRv8BnN83X+2kjBdENSSB9e3zBYpb/QWcqdLglOAE+uF4tqv9GtttJXiM3ZPna6fwHxnhDYaQyKi
3khXTp8VIfND93wkQV4U9LbNT+OgI5wHf9QmnJcpA362EGQo29/ulV8GFs1y5neNFXilKnD0auKx
B2c0EEnMSih6K1RtIOlPtbrWU49IRwuTBxq8/vOWP+zSAxdsfOZLKUl6d3kiagGPc97sY4B2Z1IH
GOIfY5he6zX5tybKfbDZZnd80TRFLabH0QvEOyuFwHHN1kMLXMCsgd7vGvB/RhOvAq/LPffXpDBZ
oWJ+vVL5x4hr6/trtHYlVP7V0wKNO0x5aLuLhpI/Jlw5YyqVIZPblyB0vrqGYEFmpSBtRPrSdtiM
6wzsRHPZsV553CC/TACKfuPNCSUIkrDlb7xqnyDmLJSvCRwASHN8NCN5/D1pyFn3qC2+r0gyYvTy
LvJHY5UizNHpzju0ke1WwZgzEqoXLTMVMJjHRBDqg9a05Rx+t5Jzopx/c3bJkIxvhfqJy8CPbvaO
zf7N+NZfE79+hIDOZddSuvRRXIpbqbpK8hnye2PzLpVCIRFfjuKYYyLYjmu8mfKXt+3vTuPKWgEr
DYoS3R5PVdCfYMfwGdSfnwTtAHsSVZ217SuZ2Gbm/RhuEznAZ6s4UxHGL5fbtqjfuBirR8YTb1pY
doaGjJIj7Z7GndH0/sltjrpn+SF1C0ae06RN0aU2s+ICn2rosYEira+TVQcgyFJiEkrN5n9OXCaM
kqXF0QZVhe2lNThQAZ4cSegPFunnOR1BMoMUYXqGc2TMR1eNNWHABir9y4jbXLm4Xj6gojpo5FZ8
lyuiaLJwqtLTXEotAER9e7OYt27YyPau0ABRLyvIBTbqOxIdygOHE920ZIbuynobxZeA9G+wa8C1
z8jl+fzCpz+d+u7bSFXj6IIzeolkd8m7Rk2S90mgDnqDAWVmSEGwjHX2ZBNasRMJeylg2VdU2oAJ
UbeT+r/gI6lkrxtPNadNEvjbFGuqhgJKBMvpoiGFBwW3Xr/km2UVaoN/VCEtNTZRPGg5FlvQIuJa
JcY46BejSdlpuXvqIzL0B2RgVGMBYWpcJPhtquNOtgGAajxYuly5lCS+y2+B5cp/PFJLCrHef3x6
anUIa9WUaVi4sxHXDFc0PbBvEkz51sRlIAigUUNQWj5LON7XHi1IZsP9FGFXWABq1R2jmmnmZQNv
O0wDPT/uAjO54Cn3jP3HkBMIVaGOm5AMYU7xevQP88sby4jLLpfUJB1qA9W7P+ypaNWoLcOMhZZq
VVNvoOTfuS05v12F3NOQPSBFX9w7+VfUpxD1EsiqNc6JxpR06zi1kQgj9O53unzHyLunV3kv0KBd
ieyYs/lpk0GOrB6U25sx9Ero4sRtP5Z5q3aj5ktY6yYTMc2rw3utxfTeMXB9YoA/FHmjqW+vpdlr
fJwnRUP6o2d2qiEo15tkPpu7yqYHdcBA/lZPkRXJclSlViZkLGjcGC1so6e+HCxRvOo8lsL3JcqA
DxVwnmLFTOxsVAmISfQiAm3G81DKXF40otl2kXahGt2FEEJ2GaY19iHD+OI4QGwnxltalacFB3Ym
KSupCxC6hB3ZOXq1