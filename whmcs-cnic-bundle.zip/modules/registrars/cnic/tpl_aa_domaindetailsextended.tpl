<div class="row">
    <div class="col-md-3 text-center" style="margin-top:40px">
        <label for="cnic_setDomainRenewalMode" class="checkbox-inline">
        <select name="cnic_setDomainRenewalMode" id="cnic_setDomainRenewalMode" class="form-select form-control">
            <option value="DEFAULT"{if $currentRenewalMode === "DEFAULT"} selected="selected"{/if}>DEFAULT</option>
            <option value="AUTOEXPIRE"{if $currentRenewalMode === "AUTOEXPIRE"} selected="selected"{/if}>AUTO EXPIRE</option>
            <option value="AUTODELETE"{if $currentRenewalMode === "AUTODELETE"} selected="selected"{/if}>AUTO DELETE</option>
            <option value="AUTORENEW"{if $currentRenewalMode === "AUTORENEW"} selected="selected"{/if}>AUTO RENEW (Not recommended)</option>
            <option value="RENEWONCE"{if $currentRenewalMode === "RENEWONCE"} selected="selected"{/if}>RENEW ONCE</option>
        </select>
            <input type="hidden"
                name="cnic_currentDomainRenewalMode"
                value="{$currentRenewalMode}"
            />
        </label>
    </div>
    <div class="col-md-8">
        <p class="small">
            <strong>Failure Date ({$failureDate})</strong>: This is the date when a domain deletion or transfer is processed by the domain's respective registry. <br />
            <strong>For domains set to Renewal Mode DEFAULT</strong>: This corresponds to the Default Renewal Mode Setting for Domains in your CentralNic Reseller Account. <br />
            <strong>For domains set to Renewal Mode AUTOEXPIRE</strong>: Domain is deleted at the end of the RegistrationPeriod (on FailureDate), or is pushed to the registry for self management if the respective registry offers such functionality. <br />
            <strong>For domains set to Renewal Mode AUTODELETE</strong>: Domain is deleted at the end of the RegistrationPeriod (on FailureDate). <br />
            <strong>For domains set to Renewal Mode AUTORENEW</strong>: When the RegistrationPeriod for a domain expires, the domain is automatically renewed (on FinalizationDate) and the RegistrationPeriod is extended by the length of the RenewalPeriod for a particular domain (normally 1 year, some TLDs like .co.UK is 2 years). <br />
            <strong>For domains set to Renewal Mode RENEWONCE</strong>: If you have successfully submitted a renewal, the renewal mode will show as RENEWONCE. This means the renewal has been accepted by the domain registrar but has not yet been submitted to the registry provider. During this time, no further renewal requests will be accepted. Once the renewal is processed and confirmed, the domain will revert to its previous renewal mode. <br />
            <span style="text-decoration: underline;"><strong>CAUTION</strong>: Avoid using AUTORENEW setting alongside WHMCS's auto renewal mode to prevent conflicts with their automatic renewal process. Also, we recommend not touching the domain renewal mode except you know what you're doing!</span>
        </p>
    </div>
</div>