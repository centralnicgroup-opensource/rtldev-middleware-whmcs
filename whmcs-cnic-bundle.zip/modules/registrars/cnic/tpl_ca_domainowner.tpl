{*
    "Domain Owner" page of the cnic registrar modules, see cnic_domainowner: the owner's email verification and a
    pending owner change. Plain Bootstrap markup of its own, so it looks alike within every client area theme.
*}
<div class="card cnr-domainowner">
    <div class="card-body">
        <h3 class="card-title">{$pagetitle}</h3>

        {if $result}
            <div class="alert alert-{$result.type}" role="alert">{$result.message}</div>
        {/if}

        {if $error}
            <div class="alert alert-danger" role="alert">{$error}</div>
        {elseif $notatregistrar}
            <div class="alert alert-info" role="alert">{$texts.notatregistrar}</div>
        {elseif $notice}
            <div class="alert alert-{$notice.type}" role="alert" style="text-align:left">
                <strong>{$notice.title}</strong><br/>
                {$notice.description}
            </div>
            {* the forms of the resend buttons in the notice, see cnic_getResendButton *}
            {$resendforms}
        {else}
            <div class="alert alert-success" role="alert">{$texts.allfine}</div>
        {/if}

        {if $owners}
            <h4 style="margin-top:20px">{$texts.data}</h4>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th scope="col"></th>
                            {foreach $owners as $label => $owner}
                                <th scope="col">{$label}</th>
                            {/foreach}
                        </tr>
                    </thead>
                    <tbody>
                        {foreach $fieldlabels as $field => $fieldlabel}
                            <tr>
                                <th scope="row">{$fieldlabel}</th>
                                {foreach $owners as $owner}
                                    {* data-contact-field: the field shown, e.g. for tools redacting personal data *}
                                    <td data-contact-field="{$field}">
                                        {if !$owner@first && isset($changedfields[$field])}
                                            <strong>{$owner[$field]|default:""|escape}</strong>
                                        {else}
                                            {$owner[$field]|default:""|escape}
                                        {/if}
                                    </td>
                                {/foreach}
                            </tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>
            {if count($owners) > 1}
                <p class="text-muted"><small>{$texts.requestednote}</small></p>
            {/if}
        {/if}
    </div>
</div>
