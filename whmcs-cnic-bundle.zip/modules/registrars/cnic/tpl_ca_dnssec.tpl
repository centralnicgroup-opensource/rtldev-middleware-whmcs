{assign "ttlheadlinekey" "domainDnsSec.ttl"}
{assign "ttlheadline" Lang::trans($ttlheadlinekey)}
{if $ttlheadline === $ttlheadlinekey} {assign "ttlheadline" "TTL"} {/if}

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="card-title mb-0">
                {Lang::trans("domainDnsSec.management")}
                {if $disabled}
                    <span class="label label-default ml-2">{Lang::trans("disabled")}</span>
                {else}
                    <span class="label label-success ml-2">{Lang::trans("enabled")}</span>
                {/if}
            </h3>
        </div>

        {if $successful}
            <div class="alert alert-success alert-dismissible fade show p-4" role="alert"
                style="border-left: 5px solid #28a745; background-color: #e9f7ef;">
                <div class="d-flex align-items-center">
                    <div>
                        <span style="font-size: 14px;">
                            {* 
                 Show a success message based on the following conditions:
                 - If all of these are true:
                   • DNSSEC prefill was requested
                   • DNSSEC is enabled
                   • Key Nameservers are configured
                   then show the automatic update success message.
                 - Otherwise, show the generic "changes saved" message.
                *}
                            {if !$disabled && $keyDnsActive && $prefillRequested}
                                {$_lang::trans("dnssecautomaticupdatesuccessmsg")}
                            {else}
                                {Lang::trans("changessavedsuccessfully")}
                            {/if}
                        </span>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"
                    style="position: absolute; top: 10px; right: 10px;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        {/if}

        {if $error}
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert">
                    <span aria-hidden="true">&times;</span>
                </button>
                {$error}
            </div>
        {/if}

        <div class="alert alert-warning alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
            </button>
            <i class="fas fa-exclamation-triangle mr-2"></i>
            {Lang::trans("domainDnsSec.warning")}
        </div>

        <div class="alert alert-info" style="border-left: 5px solid #17a2b8; background-color: #e8f4f8;">
            <div class="d-flex align-items-start">
                <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
                <div class="flex-grow-1">
                    <a data-toggle="collapse" href="#aboutDnssecInfo" role="button" aria-expanded="false"
                        aria-controls="aboutDnssecInfo" class="dnssec-about-toggle text-info font-weight-bold"
                        style="text-decoration:none;">
                        About DNSSEC &amp; DS Records
                        <i class="fas fa-chevron-down ml-1 small dnssec-about-chevron"></i>
                    </a>
                    <div class="collapse mt-2" id="aboutDnssecInfo">
                        <p class="mb-1 mt-1">
                            DNSSEC protects your domain from DNS spoofing and cache poisoning attacks by cryptographically
                            signing DNS responses. Activating DNSSEC is a two-step process:
                        </p>
                        <ol class="mb-1 pl-3">
                            <li><strong>Sign the DNS zone</strong> &mdash; done in the <em>DNS Management</em> tab, which generates ZSK/KSK keys and produces the DS records below.</li>
                            <li><strong>Publish DS records at the registrar</strong> &mdash; done on this page, which tells the parent zone to trust your signed zone.</li>
                        </ol>
                        {if $keyDnsActive && $available_dnszone_dnnssec_data}
                            <div class="mt-2">
                                <i class="fas fa-bolt text-info mr-1"></i>
                                <strong>Tip:</strong> Use the auto-import button below to pull DS records directly from your DNS zone &mdash; no manual entry needed.
                            </div>
                        {/if}
                        <div class="text-muted small mt-2">
                            <i class="fas fa-clock mr-1"></i> DNSSEC changes may take up to <b>24&ndash;48 hours</b> to propagate across the internet.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {if $keyDnsActive && $available_dnszone_dnnssec_data}
            <form action="" method="post" id="importFromDnsZone">
                <input type="hidden" name="prefill" value="1" />
                <input type="hidden" name="action" value="domaindetails" />
                <input type="hidden" name="modop" value="custom" />
                <input type="hidden" name="a" value="dnssec" />
                <input type="hidden" name="domainid" value="{$domainid}" />
                <div class="form-group">
                    <button class="btn btn-info btn-sm btn-block mb-2">
                        <i class="fas fa-{if $disabled}shield-alt{else}sync-alt{/if} mr-1"></i>
                        {if $disabled}{$_lang::trans("dnssecautoenable")}{else}{$_lang::trans("dnssecsyncrecords")}{/if}
                    </button>
                </div>
            </form>
        {/if}

        <form method="POST" action="" class="form-horizontal" id="dnsSecForm">
            <input type="hidden" name="action" value="domaindetails" />
            <input type="hidden" name="modop" value="custom" />
            <input type="hidden" name="a" value="dnssec" />
            <input type="hidden" name="domainid" value="{$domainid}" />

            <div class="text-muted small mb-3">
                <i class="fas fa-info-circle mr-1"></i> {$_lang::trans("dnsseckskonlynote")}
            </div>

            {if $supports_ds_data}
                <div class="section">
                    <h4 class="section-heading">
                        <i class="fas fa-key"></i> {Lang::trans("domainDnsSec.dsRecords")}
                    </h4>
                    <div class="table-container">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    {if $supportsTTL}
                                        <th class="text-center" width="100">
                                            <i class="fas fa-clock" data-toggle="tooltip" title="{$ttlheadline}"></i>
                                        </th>
                                    {/if}
                                    <th width="120">{Lang::trans("domainDnsSec.keyTag")}</th>
                                    <th width="220">{Lang::trans("domainDnsSec.algorithm")}</th>
                                    <th width="180">{Lang::trans("domainDnsSec.digestType")}</th>
                                    <th>{Lang::trans("domainDnsSec.digest")}</th>
                                </tr>
                            </thead>
                            <tbody class="ds-records">
                                {foreach item=ds from=$secdnsds name=secdnsds}
                                    <tr>
                                        {if $supportsTTL}
                                            <td>
                                                <div class="input-group">
                                                    <input class="form-control" type="text"
                                                        name="SECDNS-DS[{$smarty.foreach.secdnsds.index}][ttl]" value="{$ds.ttl}">
                                                </div>
                                            </td>
                                        {/if}
                                        <td>
                                            <div class="input-group">
                                                <input class="form-control" type="text"
                                                    name="SECDNS-DS[{$smarty.foreach.secdnsds.index}][keytag]"
                                                    value="{$ds.keytag}">
                                            </div>
                                        </td>
                                        <td>
                                            <select name="SECDNS-DS[{$smarty.foreach.secdnsds.index}][alg]"
                                                class="form-control">
                                                {foreach $algOptions as $val => $name}
                                                    {if $val eq ""}
                                                        <option value="{$val}">{$name}</option>
                                                    {else}
                                                        <option value="{$val}" {if $val eq $ds.alg} selected{/if}>[{$val}]
                                                            {$name}
                                                        </option>
                                                    {/if}
                                                {/foreach}
                                            </select>
                                        </td>
                                        <td>
                                            <select name="SECDNS-DS[{$smarty.foreach.secdnsds.index}][digesttype]"
                                                class="form-control">
                                                {foreach $digestOptions as $val => $name}
                                                    {if $val eq ""}
                                                        <option value="{$val}">{$name}</option>
                                                    {else}
                                                        <option value="{$val}" {if $val eq $ds.digesttype} selected{/if}>
                                                            [{$val}]
                                                            {$name}</option>
                                                    {/if}
                                                {/foreach}
                                            </select>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input class="form-control" type="text"
                                                    name="SECDNS-DS[{$smarty.foreach.secdnsds.index}][digest]"
                                                    value="{$ds.digest}">
                                                <div class="input-group-append">
                                                    <button type="button" class="btn btn-outline-secondary dnssec-copy-input"
                                                        tabindex="-1" title="{$_lang::trans("dnsseccopy")}"><i class="fas fa-copy"></i></button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                {/foreach}
                                {if !$secdnsds}
                                <tr>
                                    {if $supportsTTL}
                                        <td>
                                            <div class="input-group">
                                                <input class="form-control" type="text"
                                                    name="SECDNS-DS[{$smarty.foreach.secdnsds.index+1}][ttl]" value="86400"
                                                    placeholder="86400">
                                            </div>
                                        </td>
                                    {/if}
                                    <td>
                                        <div class="input-group">
                                            <input class="form-control" type="text"
                                                name="SECDNS-DS[{$smarty.foreach.secdnsds.index+1}][keytag]" value="">
                                        </div>
                                    </td>
                                    <td>
                                        <select name="SECDNS-DS[{$smarty.foreach.secdnsds.index+1}][alg]"
                                            class="form-control">
                                            {foreach $algOptions as $val => $name}
                                                {if $val eq ""}
                                                    <option value="{$val}">{$name}</option>
                                                {else}
                                                    <option value="{$val}">[{$val}] {$name}</option>
                                                {/if}
                                            {/foreach}
                                        </select>
                                    </td>
                                    <td>
                                        <select name="SECDNS-DS[{$smarty.foreach.secdnsds.index+1}][digesttype]"
                                            class="form-control">
                                            {foreach $digestOptions as $val => $name}
                                                {if $val eq ""}
                                                    <option value="{$val}">{$name}</option>
                                                {else}
                                                    <option value="{$val}">[{$val}] {$name}</option>
                                                {/if}
                                            {/foreach}
                                        </select>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <input class="form-control" type="text"
                                                name="SECDNS-DS[{$smarty.foreach.secdnsds.index+1}][digest]" value="">
                                        </div>
                                    </td>
                                </tr>
                                {/if}
                            </tbody>
                        </table>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-secondary add-record">
                        <i class="fas fa-plus"></i> {$_lang::trans("dnssecaddnewdskey")}
                    </button>
                </div>
            {/if}

            {if $supports_key_data}
                <div class="section">
                    <h4 class="section-heading">
                        <i class="fas fa-key"></i> {Lang::trans("domainDnsSec.keyRecords")}
                    </h4>
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        {if $supportsTTL}<th style="width:100px;">{$ttlheadline}</th>{/if}
                                        <th style="width:250px;">{Lang::trans("domainDnsSec.flags")}</th>
                                        <th style="width:250px;">{Lang::trans("domainDnsSec.algorithm")}</th>
                                        <th>{Lang::trans("domainDnsSec.publicKey")}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {foreach item=key from=$secdnskey name=secdnskey}
                                        <tr>
                                            {if $supportsTTL}
                                                <td>
                                                    <div class="input-group">
                                                        <input class="form-control" type="text"
                                                            name="SECDNS-KEY[{$smarty.foreach.secdnskey.index}][ttl]"
                                                            value="{$key.ttl}">
                                                    </div>
                                                </td>
                                            {/if}
                                            <td>
                                                <select name="SECDNS-KEY[{$smarty.foreach.secdnskey.index}][flags]"
                                                    class="form-control">
                                                    {foreach $flagOptions as $val => $name}
                                                        {if $val eq ""}
                                                            <option value="{$val}">{$name}</option>
                                                        {else}
                                                            <option value="{$val}" {if $val eq $key.flags} selected{/if}>
                                                                [{$val}]
                                                                {$name}</option>
                                                        {/if}
                                                    {/foreach}
                                                </select>
                                            </td>
                                            <td>
                                                <input name="SECDNS-KEY[{$smarty.foreach.secdnskey.index}][protocol]"
                                                    type="hidden" value="{if $key.protocol}{$key.protocol}{else}3{/if}" />
                                                <select name="SECDNS-KEY[{$smarty.foreach.secdnskey.index}][alg]"
                                                    class="form-control">
                                                    {foreach $algOptions as $val => $name}
                                                        {if $val eq ""}
                                                            <option value="{$val}">{$name}</option>
                                                        {else}
                                                            <option value="{$val}" {if $val eq $key.alg} selected{/if}>[{$val}]
                                                                {$name}
                                                            </option>
                                                        {/if}
                                                    {/foreach}
                                                </select>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <input class="form-control" type="text"
                                                        name="SECDNS-KEY[{$smarty.foreach.secdnskey.index}][pubkey]"
                                                        value="{$key.pubkey}">
                                                    <div class="input-group-append">
                                                        <button type="button" class="btn btn-outline-secondary dnssec-copy-input"
                                                            tabindex="-1" title="{$_lang::trans("dnsseccopy")}"><i class="fas fa-copy"></i></button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    {/foreach}
                                    {if !$secdnskey}
                                    <tr>
                                        {if $supportsTTL}
                                            <td>
                                                <div class="input-group">
                                                    <input class="form-control" type="text"
                                                        name="SECDNS-KEY[{$smarty.foreach.secdnskey.index+1}][ttl]"
                                                        value="86400" placeholder="86400">
                                                </div>
                                            </td>
                                        {/if}
                                        <td>
                                            <select name="SECDNS-KEY[{$smarty.foreach.secdnskey.index+1}][flags]"
                                                class="form-control">
                                                {foreach $flagOptions as $val => $name}
                                                    {if $val eq ""}
                                                        <option value="{$val}">{$name}</option>
                                                    {else}
                                                        <option value="{$val}">[{$val}] {$name}</option>
                                                    {/if}
                                                {/foreach}
                                            </select>
                                        </td>
                                        <td>
                                            <input name="SECDNS-KEY[{$smarty.foreach.secdnskey.index+1}][protocol]"
                                                type="hidden" value="3" />
                                            <select name="SECDNS-KEY[{$smarty.foreach.secdnskey.index+1}][alg]"
                                                class="form-control">
                                                {foreach $algOptions as $val => $name}
                                                    {if $val eq ""}
                                                        <option value="{$val}">{$name}</option>
                                                    {else}
                                                        <option value="{$val}">[{$val}] {$name}</option>
                                                    {/if}
                                                {/foreach}
                                            </select>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input class="form-control" type="text"
                                                    name="SECDNS-KEY[{$smarty.foreach.secdnskey.index+1}][pubkey]" value="">
                                                <span class="input-group-addon">*</span>
                                            </div>
                                        </td>
                                    </tr>
                                    {/if}
                                </tbody>
                            </table>
                        </div>
                        <p class="help-block">* = {Lang::trans("domainDnsSec.publicKeyNoSpace")}</p>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-secondary add-record mt-2">
                        <i class="fas fa-plus"></i> {$_lang::trans("dnssecaddnewkeyrecord")}
                    </button>
                </div>
            {/if}

            <div class="form-actions text-center">
                <div class="pull-right">
                    <button type="submit" name="saveChanges" class="btn btn-primary" value="save">
                        <i class="fas fa-save"></i> {Lang::trans('clientareasavechanges')}
                    </button>
                    {if !$disabled}
                        <button type="button" class="btn btn-danger" onclick="confirmDisable()">
                            <i class="fas fa-power-off"></i> {Lang::trans('disable')}
                        </button>
                    {/if}
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade dnssec-modal" id="modalDisableDNSSEC" tabindex="-1" role="dialog"
    aria-labelledby="modalDisableDNSSECLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header dnssec-modal-header">
                <h4 class="modal-title dnssec-modal-title" id="modalDisableDNSSECLabel">
                    {Lang::trans("domainDnsSec.management")}</h4>
                <button type="button" class="close dnssec-modal-close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body dnssec-modal-body">
                <div class="alert alert-warning" style="margin-bottom:0;">
                    {$_lang::trans("dnssecconfirmdisable")}
                </div>
            </div>
            <div class="modal-footer dnssec-modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                    <i class="fas fa-times"></i> {$_lang::trans("dnssecmodalcancel")}
                </button>
                <button type="button" class="btn btn-danger" name="disableDnssec" id="btnConfirmDisable">
                    <i class="fas fa-power-off"></i> {$_lang::trans("dnssecmodaldisable")}
                </button>
            </div>
        </div>
    </div>
</div>

<style>
    .section {
        margin-bottom: 1.5rem;
    }

    .section-heading {
        font-size: 1.05rem;
        font-weight: 600;
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
        border-bottom: 1px solid #e9ecef;
    }

    .section-heading .fas {
        color: #6c757d;
        margin-right: 0.4rem;
    }

    .dnssec-about-chevron {
        transition: transform 0.2s ease;
    }

    .dnssec-about-toggle[aria-expanded="true"] .dnssec-about-chevron {
        transform: rotate(180deg);
    }

    .dnssec-modal-title {
        text-align: left !important;
        width: 100%;
        display: block;
        margin-right: 40px;
        /* space for close button */
    }

    .dnssec-modal-close {
        position: absolute;
        right: 15px;
        top: 15px;
        z-index: 10;
    }

    .dnssec-modal-header {
        position: relative;
        padding-right: 40px;
        /* space for close button */
    }

    .dnssec-modal-footer {
        text-align: right !important;
    }
</style>

<script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();

        // Add record button — clone the last row, clear it, and assign a fresh unique
        // index so multiple added rows don't collide with each other on submit.
        var dnssecAddCounter = 1000;
        $('.add-record').click(function() {
            var section = $(this).closest('.section');
            var newRow = section.find('tbody tr:last').clone();
            var idx = dnssecAddCounter++;
            newRow.find('input, select').each(function() {
                var name = $(this).attr('name');
                if (name) {
                    $(this).attr('name', name.replace(/\[\d+\]/, '[' + idx + ']'));
                }
            });
            newRow.find('input[type="text"]').val('');
            newRow.find('select').prop('selectedIndex', 0);
            section.find('tbody').append(newRow);
        });

        // Copy a DS digest / public key value to the clipboard
        $(document).on('click', '.dnssec-copy-input', function() {
            var btn = $(this);
            var input = btn.closest('.input-group').find('input.form-control').first();
            var icon = btn.find('i');
            var done = function() {
                icon.removeClass('fa-copy').addClass('fa-check text-success');
                setTimeout(function() {
                    icon.removeClass('fa-check text-success').addClass('fa-copy');
                }, 1500);
            };
            if (navigator.clipboard) {
                navigator.clipboard.writeText(input.val()).then(done);
            } else {
                input[0].select();
                document.execCommand('copy');
                done();
            }
        });

        // Handle disable button click
        $('[onclick="confirmDisable()"]').removeAttr('onclick').click(function(e) {
            e.preventDefault();
            $('#modalDisableDNSSEC').modal('show');
        });

        // Handle modal confirm button
        $('#btnConfirmDisable').click(function() {
            $('#modalDisableDNSSEC').modal('hide');
            $('<input>').attr({
                type: 'hidden',
                name: 'disableDnssec',
                value: 'on'
            }).appendTo('#dnsSecForm');
            $('#dnsSecForm').submit();
        });

    });
</script>