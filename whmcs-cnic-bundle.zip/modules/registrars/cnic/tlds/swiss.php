<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnwccGsZYs8YkXSCBXXWOxMqh/pvmNqsbyQ7AUgMF/xl+l/IpFC4+i3MIZwJ/ZtjAdgcnDOM
Ch19EF6wvhBaN42cad7M7T9xTPSSM4XrSGUFLJX6yCEfg3g8QBsROq0wxDMEfBnUwA3I/Ofbt0Hv
Wmqc9tr9PlZvZhWtD8uO8Lduf/QdbViI+yWh1uEvwYDASrnl9gvjsGaMvxfb7UdnbhDOdJ2iOHQx
j+Hznt6M0GjuIQpoWsH53U97KW1sOovLogi7HC0ecS5h5/SQ9v2j2HIeQ9dkQieR4cE8+lkqt/BN
rbRdAFz6R7uww6GIxNJSWLTTa6EGoJ+G4fZnvDJ8vyfMRouBNygopK4xw5px/OX36dD2OsW07pdw
52/BIZKKMg/m4E8B2mnOEP3ECG8Z95NJnKRqX64A1X+rm/g05eqDQGJCuhof7fGmkStcDvvffUhW
6f8Jkw1Ql9FF7tRolWMb2qcnQ/UVeNYbCNK6HVXBoLOdNWqDG3wKYFL7QXXql4pkERYaJT+kQL9N
ghAn7cbaadqCxFRrFNmbyI0EdFqqQ8psuWDUSOGspOha4w1wtSYHcvoH382FcRWnFpFgpgOEL+QC
RgHYfCxX2e6RR5fVewQax4AKo3PyZnWTL22avzDWVWPuajYup0CEEd2kXpJJVphIuzY7YIvqHtXH
E84b7VKlykrNJ3cif2R4y1367FGnZByQmT9/6T72A3Sr81D3j5UwmFyPIN0OeYXeO5O3ZYhBbODA
XllU6yBUnOvzurxbBKuZbL89x432cYDNh/2pSXq0DR1rlPXpCTEMxjW/vWoCrwAd3b3e0QgQsMkS
ORdbOIH1Rkiwc6ikR96viykEWP46swYt9j1q0aqR9ZyhpoQQhkzDSmeLVJ49Eocx2K+8RIAOGeT6
upXeyI+2UbB39T231Zjg3AERX/TcsikQMkObBDhplit85dxU2hTqSGtFTSTKrn8ATFh4E/n50o7s
Gz+fVfnuUtJ/0xOFs4+kRLA78BrQrlyCaahICDzfXxYtyIQ0yhKskjq9ajBzvjy2vxVBkaznEQRA
4HUlPb5sj86XZr2wWwNtlKEXJgXhDnvPZANglvVOrMV/kaMDTMd5H7D4+cHV3AZysSZnz5g9a7gC
QBgA751HdW944M2LJ3rszC97JoYGcms+wcjKQegOcFjIyYyL89OkCzzEB/+LsAyZ7koc+ujnD+id
M2tRbOFnmUA2kjyUEmAd3Z7kjSi9wG++w5s5pn1v9Vl1TBjGAhPMPTzZxXSnIJSDDZSXH7ZErATr
Vub+bEJ50uuYdQczcRiFwA3Pb8S6s1wP1aYlYYHM2k7GPe5HTtNxQW7CIKsK7d+GmBRZNnmAk2Wk
/NUBB00rMP+XTvn8l2sfeyknCIllzDrZ1GE40U5BIwJpc372sn1doyCpKaK5Mzjrzi7SK5qkr9gu
3G3TPGI3A/A6hZWZBIKtM1gCAlawUyzLkyAUU6p6XHrB/d3p35YOS9oN+re2b8cQI31B2ue5RPW1
danHdY0HCjcSVHJ6SCj+i4TIOmA9X79ehwi+ACQ1gc4iLtPfgw5RugtKnWxhyrDRkbmBLDAzzDEh
rN1r2zQE6W8SYPsFhTRTqLK=