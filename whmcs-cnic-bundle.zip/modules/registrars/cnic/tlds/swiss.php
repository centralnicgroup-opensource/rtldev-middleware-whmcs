<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqoo/ojTI9/4aXK3QdvdUYt47uTtpQP74P6uWBAzk4ndQ8HrcO4dtZ9JiLBzo17XuaAdmIs+
Vjb97hRLreYUguclkT9cemHoNrdRjyJni3kw1TP5sRy+idjF10GDqT1nO1KNkIBddsn3IxvhXvDn
C9b0ZkiRpUdd8Thk1Y1sPg/Dzb9Riw4nw/H5ZOPwVFth7xGKQP9Gbynl36WdRhRidS8esOGSxBbd
kG2dX8XerKzAdlfqwzd5Cr/HkbJaPXTieAvLSjssbBeja4egBIOQXBJ+E21iCqxQ5sBoRedgVqAj
+EOW5md/1DHjVnoysalpL3y+D3aUVCz3eYNGWE08Xxp9TWdvPVEm2Dv/HLPS5BiB2QJqFbi96fiO
63Hd4L+x7i+LmH5lPcVGgwYNqzlCVuwzHqid7Pbve8SPUHzPZqRGx9FOeGxFs7V9xaErA2jqSyku
Ic5OqTHi1wIb4sumej3J461h2y23cl0b0X8UTV7l0ZWAAUjgMmH0HcOYaxdVy53+t4oew8YRIWwa
vNRskCi5SZhjm5gUuufL9b2Um+tyx+fptLJGu1lrZrjvg+gb2bvpPlEYpIJY0BPH9o/nKxeAzzdM
pfaoz5oI+9C1kCoaeKYrTm+CKNGFAn1zt6+3E323t40ANIN7XsXh04uoRqhjVCQLpJEQhu0rhkUh
KpJ+PExm+sCssj5PmL63ubAH6WQE0CBVlPl4dRd+qv/xTnAEupi1z9lc84xvnZqsty4q2ZP1gvNS
IgfqQNKFVv+KOToYmSVkDMWKUaCHG4vmKBPu2iq397Ebqy6WQiHv66pVvcV/ySzgpJazmKG0/0dS
8Vo9tkcRdTc0o5Dx7+3QGMRLICuvJf5Yckxkib3Nl+2oTEC7pDcT/lU4ngEnUpSJkg9WH5AoYrFU
h8zKMxEVZrIKkUgZfrqzjnB+bB/nYvwGsVTL4RWlZzzoXinnortroKRQalJ0IkoILm6TY+SB7yQa
/UFNy3FGGjidh9SvgssG2PYgfVfeDFzGBsRWPJdkkBa603qFlDwgFxhNS9yHYD252LmOy22eJWJr
lC3LzokrGCb6ANL1MVIGW79hIYtofrU7Q0Oj/EnufQvZdzl5eNYDexcORNfGS0xXTxP7niO+OmIw
ygBpy/0lpvRv+q3Shlnqxzy9QAMIxFPSN/F2zZeGR6cBpa5ztegzdSQ0XCJjz9bNTODGCCGv9765
KNB+bxjHdJb/BjOnBuSvh5YZJOY5r1PsvpNWJ2hbxGhVe5Xwt47pPKS803c75awEkKVngU33UvXO
+XeeOnYwcBET0LNPAHdE8NF3gc6VPrKc6GUdyKOYuKhTq41fjU6MDFtRjiZNzaH1bcvGoOV8Epd/
1w1BGb+S1VPyD+YfZkM2BcZPeuAfBlRyFiHgDnhNsehtcC48PJbKzFOkIzezlRW8o0ArjNOC82Z1
ae8pSAl7kAZqVHBQPBv+OFoZ6QXuCEtiyA4rBc2niwoAwLt3ekitPjkdBrBBjVCtp9zEnu18bpA1
INsol94EhfyiCCP21sHR4s1q0KzijQG/9VWjJ27wzAByJkW7ATb3PS/XWKyJJMw/RkY8/uRQEyw1
faRsyTfGuRr6FKOPmDccbWUhl/KkPZRURxhD1gPU