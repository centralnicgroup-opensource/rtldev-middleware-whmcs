<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrrUQkNWesxB/U//GyQGdiBXesnw6o8PDkrpEzIozLnuYgibvZEmYpg5BsgVovNbwKnZlcu7
+GUVCBhMMlf2+q4fOIUVjp0Xh4686vD00MKLQNAMsYa5r1qrzU4PooUnnIMIXgA8qt5m7Ay3PnCl
JWT5x2H+AkVhspisKIb5x9UqXcoEtSc6nk29fOT4tCexqjt+aeUqFWIl1OKqhkRkqZTb5RDgwa7o
DxEqlVTGzt7nGt6f0cAvSAGNqf9l15OZ0NCvYRoE9jJyXH2E2790wT8S1n6R1ch/yY+jYVjHnc9g
IS4WHtXpm2vqWxm458sNQf95iWOVJ241MYFWfqzDqRhucd/6WZ/8tLBsW1IsTTc5WGviQ9IJRzQ3
YI985zrUyxsn+PPApm2Z63vB6Tv86m2E+CqQbOr/gUdD0rYs+AetWqRT+uo+yle1RglGqNe965aU
GXiwYHUBO9Zd3uknLeDeGhLYI/dC2rsWuzEPgxrbTBlvjy9HEuhbo4YcVOJoE2EhnudU14UwCiDL
r8e1aX89vv1E1Ms2156uD3H72TGSTPpJ9YSoR2yJNr9BbCLu7egNA/dNUylc+Z1lmN1etorh2MPI
P0fchCl+IzTb/nQeFipZutksbwf+fEyQqAptbHcdHq7RzDJJV1mvImR97WFW04Gfv2wsplXMOC29
Q7iROTTwGRCud3P8ugcTbNQ1TfAC0lcefXj58HU2l3K3oypvNnD2lP9N1/0hhj9pKOSHD8jaWn6U
5IfPftPa+oIu9pCPbPnLtSdogGdP69wG5eQE8FIf7GMUupxwOJyNJ0Z3yT4LtUi0ZLye2iOBETKB
B4jKSe92GQYaTcopl/ac7jXOlCB5EJKjRlkVayvMu5cHa16hJ+TdwgPwUkdJ0xQwf22XXsho2Uia
WHfEnQ8twifhRNJ4povHycA9EWRT3WzfNWc1Dt6UFyfKmFSTKUx+YWPTkqjiYUT/WkXp3t7m7gg4
e1kNvt0kFaJlT/rIP8ygubqJkC7AfHS4TTwcKR7VjomIsfuX23VjNli/aaO5wWAbv2iUzT3VPzWn
Eh7GkqWXlMKAcqaiK8HQGVpKkbpcZzIGjldQgg7uji5se/K7o6pZptArDN504V9clGtG/T9JkFUI
f2+QtUPUmuNRZ8aa6hM2mSr3Fo60QPFIwdKucB/dM3LkP39S436I05k7c4BJ+UZxQSO/BuepRR1h
IVnVF/Ojgy4f/tMgHqGAfNKRdbt1FZU8V1MMppMVVOKXBHO5zN3So5yXkgcvDNp2KlBvu+1ofWqn
VaKemuR6kUPICWA1OhtbGb9XI3v7TJ9X08P2KTdHtyWIWB75PLNDVoVBObF7a+MtwawX/GntJO7o
SAwYGpggfCMg5WuXGwZjwIvfOdSSDc7yupMiPy0NS1OoYjEq9fIgL7nADXh0dInBBFHKeqBQKyb4
JDj1E7XchJ+NZU/687I5q++IJSpF68c4oYJAxTgx4kXmz9M8jH/ixkkDp56odjdznX3ba6Pvob/v
OEZaifeH050O7QIfkcXv9I5LXjXHVTB+veVQsdsGLAas8lCUCUtds4kvJDaRtBGwfVEAhv+BBAzs
sZCJm6ds8Dek7yGDRhW3WgPew+mb