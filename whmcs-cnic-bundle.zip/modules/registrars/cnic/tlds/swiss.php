<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrGPJT7f+hNczAZOyh1B4uCXvz2FihkSCyjlkIQJDznoTUJHpMRT7/89yHyRsmIK/cFhLmVC
rS+sG/38fg4CfkR5nep1FTY+kXdmqN3fYi2UZEM2RhUcNwCQRsa33y5WElakvgkUhaeZHndh54Mr
0XlRWg/ikrctmyKYazRG8Zq3/cLz/duNpb55i4ZXUlkVhKxo515jxxr9inybMENXaELusV4Ki2ro
6eYa57V/IwjPWCW8igawUvBvJW0LEUFa8sSxspcUmGR5TtnuCaEknTiC+jttST/o7M+U7fdXLphF
9ohd5NZwVDcqHIaDRn+vuJkSO5+lgT4bMIlE6vAcUK31ojqq9ZtgBoUm9L1drYZ1qIwFsfq4uTcP
zjdhka6uFQf4ML/lLsAQSAQLdIB1/GStAICowya9vwhbWy/O72jpcAuHO1bfWjw9vhDL/1SUUBaR
eFThERD809b0TTgLjZ669gpfj8NGeo1DjPqfhcgofCm/1FbK9d+t2fPOr8abdRw2U2GneCXPLKdS
SxGQet/C0rchs1erjFSKS2C5HkVAHDYdKLSNTs3XuWG8jw9x5gv+m88KX8txOuitpTzZYIgJQYIG
5KcFZ+HpGEGEXrRp/4guCFq+g9kGu7jsPf70tH+1jl43zRmA/w1FwwolhWmJ5MU1F/GshncTt3vG
ScZsYYVE0DbuDC7dnEw2N1VZ0CRUW0X9T5GNUyZNLZaM/OVkX0XRMkB52MZXXheLDYfKQlg7gfal
Bzf7JtDT5GxXxCE676x9281ur6/8CTd1oGhBuyJeaikpCR6+wNzDbNWt5Ew3P3v0O6Xf1DUbZfr1
JR/+9ftYBBIzleFHwGvFTt68xvrNO56jHhKjymX+lipC0BI0M/z0g/PZO+1ZWymVxCHEf/+BE5W+
LG02Za0N0FrimxKW6Qko4nxJVns306eWFs4UUmvI2FaAljPNVrpHfJz6mAwjTfvePxOU6owP7EWn
MMnLKvNAsobs18EFwah/yzbjRL3Xb99roiCQ5GkMhJ60EyA56d8Shv0agbDR1zhuY25vFvHsyq8T
4aYSKJzeMJeK7krVb2JZFUX8FMKP38qvAY7KBI/51V2c6P+ohbHR72W9B2CfombasHQDzoGznjrt
pcgDa6SioeyuScthr8azGKcupnZzw4avljcADU6sZm4s5KBMEmeYi/NKcl+7ogWV04RYQIJ1K3Yn
zHQIZlWJA/gbu4wE76rig7ZcWteGp2ncGGg340cy+oLYWMj+FYwzXsFZoZ+Quhi7iV3LJWt/0htg
mXX2vsm3UXwjPSF2vhua/e4gqOlofbXGIrTtylD+FWgmt9Wz30gMPNXYCiYA0NzF10nsZSVjXKAS
l5eVKFSUeX8V4A8IGEUuwxazX+M/P/XmaMR3QD04ZHrR/QV2tUujoMZiEQxlLSqKMMHVCctbqCCz
duWtLUZx2APhQvZkAt+4+YXKbPSBYy+3bwCAuGzXYDv6RWD/tEfNtyyrEBwXs9lK1sdeFxbCb3uj
WkAYldXlhAT74nmh1u6uRb+Kf5WLC3sAh5oAI6bJTQlbL3ZRC314xNNqSGwfDl/Cr8NLI/7JjmOQ
4lOdCR46UlqaLE86QLI7xBI7tfaX