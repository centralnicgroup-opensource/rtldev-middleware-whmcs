<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyXiuTV6iTaOdzrqzBNPP+DGpC8L/lfK5jaAIxO2Uwzfoo2B3yLOsXlHvsfowDu7t3lasl7d
fSgt54+F+aKFfVuLRkeSwnaPs9h7hgvjJccDticpidUUxS1kBeHdPbJlENtDe22j7JC34PnNBr1w
n/9/zyPlMkHB/i0ktqCVhz0nPOCvMTYKcIou4I5SrbsBZpzWjbIUH/K0l0aoE658NuzZCfFJ3L9k
wopSxPoWwkgThfSYKUGX8rcE1GpOqUk0yyv22A9TcBlKA6H8ahe357dMXSM94/PkTOZTZmMhKQ0S
L4uIocOcDa1WXmJPsBPyHHNVMlry4F+n1/O/B6vXr1ckLsa4fg2Dc7/0lVPAcU/T0IQWI06HkhYZ
k8YXxOOWCiWC3qN9iYwrXaOBijA+33fORv8Lk/SsjtiWvrCqqhdrLv3EDVbKKzWaFRFfeJ9/L9LK
dX/4YNY9ir3JlyatcZra6dom9FsSdGzLC5cXjA4OvmFeCzsG4hBunz43V0/lL4hb3/eP/R8tYemH
Y/o6bJ374SEi3w/cNHDMMYFRopMoQ/9i8svvewtjQlsffURzTVO3QzLfPZTqKs6IKeI95U5cuI3b
27OJ9s29dS+kEZd7OQMcmlQfg1T1OHoqyLwIUSWkI1vcP+GCPW/FR0wYXNzsU9Gqu6xjdUXrX3E4
dFrOaQuT5MaFvFYynNj9i+TIVABqSYml8TLmnyL9YU7jMw1lfQLWzBoXJoOjOQOslOIfuAa13hAX
7S9FSbsk83jJb6CTWN+25fNNtMmAruqzGa5nfmvlhlo2dmAwwcqRXOWgtdXREkKcCIRRKGB7zcmd
hTQwQr0HzX6MaEU4dwfyxAZYyU/BN33OoN8mvcYyOlEPgDs7gUEMd51iWnJRj7FqXxgNiK6mu0q4
2vd5vLkHmnEV0dKPV6Hr7j+8ZoPYB+qkODrBDwv6pRiJGO1vZaeP/QWjaEBzK9GYiYgRLYWmXrec
6Wl+EL3uaJ8P5vggFLVG1B5wHKjxR2t3wrEG+K9HHmzarIFkgpT/azJkzbOrFSdNPnOB/S181jLS
R9HYxo7q7tJwbOmuCk9AjZAvZDgrRn0Ntv+7joF7RXoGmBn9Vcvk6EckfL2TyWEdMMN6XIaLXVgW
wURvwdR9m1Mgujh9DmZC3dQtvT+sapbxusNqxYRi7JG2Xbsqd2OU5Nlnsk19IHFcfzRkjF/+2RDg
FfpeIgK9n1EJ3GJDMjBuJCEkVzjY5gZ4kaJF6ipg7zhd871SFtlXcsVkv2QWoREfZkl8pA3wuAb7
PxF8Sgh2sLkhJZD+LOkjQ59Yjy5Pue6Hm7ODmzWVQw4FS67f1JKFoyc83QjjNfc6UNd5Y6QLlFtK
fzG6uhP8SXLPgQ4RxbZvEKOAOhdYuZ9eLMLab7CXCzyxHUeKLwhNxr4T6ESCRlt0u+BOpwrcKzr3
hod1x6u5yvCu7iOvWl78V/Uu8vH4iQo1tIcDE44CkfPfktrNLuS5n1wQWSvd9n+oCw7MGXyAbqPp
lUKoAzx7pdmAAxfMUv/VPSRk3eOjCJDRlukQ58UyS3JESC+fqimsE2VPEf14jYAuWe4PLoumA0j5
QBXI2Fpxd7/TapEy0X6qL+rwhaEV6H/6EiyeeldqW08=