<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuWBZD89r7JbrBePyOUE8VWFq051kznvXeEuepd97zRh6rJJqy06nZ520qzvDYfxru4RPMzC
uNsw7gpkBxcTGkU2Td6qOLVpAVkaeIpI8jr34zIbjlRI8uZBeiXwBdm1FHCFt42ALtSCtpQyakg1
0P0fd4VvWC4v1JBPs2ZP/bgPx5KfR8gtWpBZEC6JUWRbU779zwLrFQLMBjVeJLOsXSQe7NzXLkOH
61XbxZK5pYIF07nAgDpadTuE2wf0HaLlhaI/zJ+PedukJPKmH71Gvf9HS/TcXcU9fpG1GdlMwZeT
VcPM3WBpzcQ8yruQzu4c+Rdnbee0BXKXNHVj+NmNNYRt9cqdlDtqXFD/eNLtyt+1uT9h/xZTsz+m
BWzay61BgSP/mJ+0p6Z1WzNmbJSFoDDOS4UXPmu40B+GiveE3L3gBXeFAC15B6rNoOMXOn8BS7mr
6NKhpXVJdi/eFZ+1pTTRd64sgQycu2IgEfOJ1HdDhELTOAryx2VxWXumuaCGpUF5Kkz9MF1iGjb4
9zqBZV2WgCFdfZbedXBegqJr5gYURa4Gz3TfDWaB7OU8Lu+qlbjXhaYB7lYNRG8N08KWwYkE7rMd
lmUg4CwhW1+DryA8P33L7Mdk6nkODAHwzB3MAfMoc0LzJDTw/7B/el3OYCW6MLscNO66rpO9a3Gc
nPTViFMEiavHCbCt30teP7bzsVUjdAv8Dm29oxpyGyWusLkF0l2oVcRyn0YklFZsVJ2bxnI9ZJP5
PbNglClEbDdFuSoF2ipBLzvN5pYaQZS/qNOs5/V1NSxNeFNQfXxOKb7yjdgWwrvq1gDspUIaYQ2i
J3JvZ1VU/AxtEgtM0kKPhzWkxpHaYf32g4zwOqvAYJsr7ndWqqOmZ5euDq2hV7vwzCvGrKtDA2am
NESFuuSl0WGfMl3ZwvxLhi/uXMHwVbbuVSLxFPW70skqbGAcHOgKXsqp8LLb1zXoQegUbmueHBU+
W/LGFgL/+C5uBaaimCw6U6X6jWF9O/QjWB83E8kV9wJBRRIQzFI2Y4UCaqKZoItr+Z2DU2OojwKG
qlkPAihzFKOjl8TM44/cBLpQbIoiEVe/7Lz3Zde9jJ4DtbN+inw9iUJXJeYdmktB5cXGbu3z0k4r
Ccj5s7rtnqpnLcrKt2k5uqRAAFsQep1NIJF3T95mvZHoN7qid1j1hIfXptKxukzxfjK1KcpZTgHb
TNzoMwHRw/8e3LSYFsZtmzR5ve1buYB9yqJqebE8bJ/kgzJov5tEeGUFJSJfyXEqBW2s/thjZCR2
/Ec3In4zxfUikYRR5g06S+W7URFIHDPJQZxcNOP9O/86uAjxc8Td5kPWR4wopqi5hHs4fAxtSo1v
UL1k7F1ITnB060e6GV2sHXVRRPBFWexYylbGnNGwUPIp8QqxuOJt4FunMiYngX1PMmAus08Mt++x
yxWBv1v1p0jt4cEtQdZ9IUra9+yxR9uIhs9Fjtid54zN2aKk083tRbsXlnsan49phnzRZ5OmW8Hr
sqJTtB3CAK2y1xBxSZ6uHOzpJ6TZ6A7wNogvhGU26edQy+JCOjwiIH6W1R2+uDPBEtFbjWwSM/83
W00eiJH1kGjW24pEc1Q+r5WcuSkvN+yzSG==