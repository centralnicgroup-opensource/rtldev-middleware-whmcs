<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+TXFkEopOBKIz2hmCFhI4Zzb3EvjdZGiwEuCn6Iq35hPS4sTZKsnK0aZoYgSZ/V5wQpI//d
hwzck2mZEmjORVhKD4hfYTkFyRjBmLUAmi9SCTozRlhK6uxlFf2k1GThhXlqE+cLNBKDONEmfXdT
cXsCo+SYbiRzEbzP/K/cbf/RrL9XsCbMsvcXdMMzgYs2/zzDhmJkdm9GdW6ZZz6CdI5cE9BI8sPw
AFsug2grGB3oru9+Bc/QDjR/JEGCqpNRfwmKI8rG6HoI3gSU9NxHfA0EL8vkeCjrMwxSSwcZl7NH
c2Ok/zLUg1I0od/mucsF3U6YTaarkjs+ghcIbrtpUx93QYvihT/GfuhWqdoTh0lIO0osEWTmgmqk
P9g4f42mVlm3A4Z0EFLnpeQJjqO6UKT2pY4SeFD465lDX701gGfktdyWMZ5hZEKACDlxrdyb/WEe
zr6+sb9znkIisShUcXxFDiSMkFww/mGZyHbPQnQlbIrda57iWMuTUOkbWfOuW4xpg6BGcJ+AVPSt
cAdVOBl96t3Y4PeLZAk/7a0gLYmcVSNIzXg3sNQRsoAo3fYbN2y/a4YMSjnDBhLFIJwcB2lUewvN
JJGUvREP1XaGFxA59G4MqISLw0+km4au76FEig0Q0cp/VloBkfRCmjyxMnO/3fRrAsOdZwiYw7hg
dFkUs+VEe/z919jdHZBL+2HqYVOWOLsCWmmI1+FoptoJj12YRspxnRuXy2XRySMhkx9OvNOmPSvQ
QUnzh1digJWZlPVWBGngP9jFSLQiSOd6dSau6RMT7olrUcA3mxCYcAg1+qibE+cGZ8h6lYJGIkDk
6n1HM+/9WcdQy9vj0AiTeotESINHq25YiuCvNUztvc6p6hVqsa9S4DQJIHe/kj8fbe5ye9sduC9H
ZvADglIRaExaYr+tlXTu4g/VYmQHFTFKxK8a/VnWyZLCWneRkSAaSe7Xcy/BZMmum5/JSPv61D/7
iJtZBv5Uh/9iV/4V7DtHhQS1eao03YB/0WFF3s9U7P1N0xoYBgoH8AnGJ13vlv5KCyrxtqFmZyjT
+sdQwj7l2RTi5gGvpyxyCoES8nfsKpt9ifgPMW5pcjP2Z+07eBdSjGD3nGBt8Sp6fo7HOB5XlnF8
fTYKObo5I3ZI3Nwg32ia34Qq3e+HtIXFif7c2aU5GBZHLF1IZyjjRMpVM0ASXOTFR0fzb32nq8Ci
amqRi4YrZ1DEFsuhwj/YmuE1E9yvYCKNeY97DnKPodI6/4m7FseBObDw/WCNNUIDSqIX9KUw0wzq
4/NEM3fW79GJvZrNJB8m2m2MfpjW2AzfeWtZth2FuDoq3zviJYBiUjcydjb9hbxmHU1qX7EppItv
bWujTBzbBRSCqLykU1DpZ3gPIAVbJ81JBFZ/sDB5Hi8bV+oScsajEl0XGBPsOAfv1Iyc68ECyEXb
h8pbAto4TqkojJG+vNDd3iciGt3Mx4T8tngMkEz+dKdnpt/d9mLkXztUoTl4vH/sxcYlOqFfQev/
Pry8qWy8AX9RO1arcZwmE+9z2jZ9dzX6ojOrersR5nwjrUorO5Z2tgKReTklEDW0Xzad6N6Ccgug
LffedPM6S4cRDCNwYwCngF3fZNG=