<?php

$extensions['class'] = "SWISS-GOLIVE";
$extensions['X-INTENDED-USE'] = $params["additionalfields"]['Intended Use'];
$extensions['X-SWISS-UID'] = $params["additionalfields"]['UID'];
$domainApplication = true;
