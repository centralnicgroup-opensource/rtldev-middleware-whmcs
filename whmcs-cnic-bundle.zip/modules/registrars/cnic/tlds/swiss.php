<?php

$extensions["class"] = "SWISS-GOLIVE";
$extensions["X-INTENDED-USE"] = $params["additionalfields"]["Core Intended Use"];
$extensions["X-SWISS-UID"] = $params["additionalfields"]["Registrant Enterprise ID"];
$domainApplication = true;
