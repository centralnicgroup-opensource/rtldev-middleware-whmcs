<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzSaMf1k2R+dTvNFinZH4cYa76rhqRbM09wuRwAZ7VmNV6Y75RA3B9hsjX0IZDFe+L/ajCAe
6VbWmuHqo5W7f7WGtDSzNmvfQRZh272boGPPSU8H6/4aEqY9sOgoOjLeSFFdKFqlTlwmb8/ZxKs4
soDm2UjqPZDQpVCs0J6QixpALZ1dCmusoBBwkPXyuAMyw81QQMfULMln3+AM7BeNTQXgo/H8Iwx2
9fMbSNed61aY8mhpnoZCaPTu4UPMzt5mP2lOIdtbqdmqCchhCinmfHNvkc1gLjtWSJvBCIhhsWUX
d0OZ/lk78JJQbz58EuwJ3EZot/rI9YAv2zYiyUuHxahh7gG+a3ESlia95neq7D9aM2LmEK+XyGpE
3ed/ESYMbQmP8IahRkVZVqrsjlwqwU4nLFH+YqP7QCs2WjO08cAEIh0TsFjB1is9Mzg2DMo2DgFy
EcLfiPHKoyTj+XsfvNRPRjtEf//ZMjpD6nrq07RnmNGIQE0CqPoYxKlabIisIrNrg4OuA1mxSOyQ
E3gl3sLJ1R2YFMeNkNc0NxNV5rSFdHZb48/QYKVCXsdiHTMAfIVCs47cZRCfHbsZSye3VBri4Dj0
xT91sCY00huUMtL8IZh8AYLPkOogj3NrIkHW/0JZWmqnl4/vtqRvGXfQ+cBE6is1hxoEDOe+l0Ka
eaWlSDnc5o03A03+iOHeMPaVk9RPlkbXFGi106pRutaLkyZOYOcCOD8paX0TR+WXMvqPmeeX++km
vM3rt0Fn85IStLANnmBQMvFRscDNYQfsndF5V3F4ZOaJEYhpfLHRpwDxsc01dLKlI72dx/STF/a2
UsXcLJt433aZuDC+u5frxRxky4QUSE5uNPbG2mBNhFoBxR1IrNSHxatsst0oCgFpFIfhaLD1GjG+
TEW6cy99dW1Xwufj5EDJ1aBFyVG7dulrEdbRKl7FT18BPbHEsYvFfaSwJKjkp0o7Xyk5BzdHRtlJ
GBg4YZMzCHeZOPW0BGRdxTMdpUPc/q4nHYVwHSWWxMh2bbf+Ga6qoGPUVhgQbotR4FpnqRhCysOr
Dg8hAnSBz7l5dOvb9RDp8U4Pvc6G4/QBnFq3phrYVsHItoLQxAPPJxDWh08Tpw5NQxsAXBMt8gBK
OQYvSJrPhXFNfZAQL5Ka3idPhXP2mRxPlRC9ictbhDVD6lb2Xptu9sfmP+ej+Z9xZ7yail5dAFBo
zsCjsjzqHpGatVZA0jfplaaue4spQhzOcQWbjEmZwU6OOtZZ4ni3w6tHohMwI6mYbOSxDkwzfnBt
BVSH3dL9VHnbcxEvZePQMVoMhISXw1rT29OrqG21S6mG+4UFNMi4H3ImWflbTneqK0gYJsHp3zDZ
aF24JiB8pmtlIqkiuWhKfGyfaQ7KiNZoddnU7a06KIq+eTSRX94sapGDGCiJRfzsm2sDbqurPb4H
MOiANkaSleykquVHI56py1abXcgPmFIC4X4HHTotA/P3I2VXu5SL4swdtI4Bz60fCX4JJcZ2aa9t
TrEocEqJqyGtlyQ5m/Q8pDyuyKFPc+BHYQ+1MS79oP9J+Hkz9ZVeEBw6/AsP1adfuDAhASqI7mRL
/d4A6d9bqFbQaKVnLOpQRRASv/oW