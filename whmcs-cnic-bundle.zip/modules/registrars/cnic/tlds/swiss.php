<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqPoXGGPttqhvCCG9+KTIuA1ZjnoVOLCCf2u6ykJCHDiaJVs+YRdajaPt3l4egIpgrNGrBLi
Mo3gfenNLPq7aRmwIQo/fTOw7Bj+gxkpOJFC7Ay4NRRn0eby0bXy2NUyOEIB03WTnFKbKw+MxgsF
5WLlIg4jlH8mgoRbojCWAnd4yoSPB+5VbkFU11nMw/cKJ6xg/6Zg/cW4n2Y8HoNgrqXPfvs0/bi2
bA98LaG9wpc1WcWM9/lofF/ZStRZ9VGtaKHp7gppYEhJ9G9xXWTad9nBMXfd3ZfGErClZg0yuzW7
qkLu/wExTt6/29akdj3B7uRtja2klZ822yaHfaQCW4UxM9qAIYimxTqzFqGByuKJOoV2fGp2ORzI
V5a0s7knfc1GyELIbGoSRzgR1uN72VO+X3yFOBhEtyr7Xk9zVJXt6ZiCS2rWkeKfB3ugKQ3EN02g
sifr9vxdSK0/87+fSsHevmhWhgRbkayiXwcgSUHtsVEr30IB+TK0XOqmNU2QOJL/6gq2tAJXz/hc
jXpanLLbTltTdhH71YuKU+i2QrUpuuIOcxbTX5Vd28vShDsRKtBQLMg4I6MZRAT/Q09E9VO8qvoN
Ftuo801k/QlomvhtZI8H+AyUocnt+/+8lAb3p2VXFoYMTWlu9ZHEDbqHWWYt6t/ORtoX6ldJpj36
bQqJlCa65sn1bkVP6WUbzV4v+OvQn56XuPJX0pDWI3yzZdaZYu3t3SBC+q8huGB67VxkNnrD45My
HEYekGZzvl/AQI0jo2YMMNTrK2gfXhq7w8qSJTNY2EKxRm/MveBrWViJJvyfOrBaj2+YpTKQeDUe
5Ki7ax5wiBSZG5BLYBXhQ72z+lvrZrKo0T3IZhU9YZPXbKPLKTLcrbRxGB0Ysi6wDwlZX4nVLosd
vEqGo2yoYe3XDg2/wznm42SBM8JOORbJXFcFXw8bjCEecpww5uEdAbz8o85DJR4oQ5KiAkEWNgf1
zwg5bJDFPs9AE/MaEat1sGADi0Z0kTGL75mdBLqOsYD+mKgLQk/cfwXm9tZJApz8YmyGHKqCAxsq
P3NiKtcV7EN1HMpNMhZ1886eN4lt1fjd4KWY9mRnHHM80Kjf94x39cL415lPbnoAPOTmQfoV68qw
jE6FoAaGkAGQLBgZErC7WDxl12WuFQPyxD+ZcEXUuZ2UI7Dtbe27JMOlTZ5/g3z177+shaX5sU/j
4Fvle6YHpd1BUqJK8tequS55pn69hwwxs2UTeZGl6FAFwuCcHeyYcHRoK9rLBizqjYvr7QDYq2tD
bTgaGu2EIAQRfSUoR0pFZv8X5QYoQ38DiWBDaw5r32m/+/1ukYf4fzLluMGAHqEPaoQvabcDkkvK
s9j5H6PrNpz4OX+3VGsUzCtdm2KAS4tPflKSkBYjVw9/thXAFKT8SDnzznJfTzBdXCQrzTk8zuXk
bsmDtcHno96ojSSaMQ2/oGqEb1HO799fc4IPGZ+VHM+2BOR40u5FBdtA9V7KwJXBff5zl1xpX0vX
5qf6+H6fAmHeAGbZfcArmf9jJvuVXv2d+x3Cb965Dfejiu0/X1nw7mTY2JE/d7+u0URmlqYBYSUz
Z5UT2k31JjlrGUAQwjAZD+69iG==