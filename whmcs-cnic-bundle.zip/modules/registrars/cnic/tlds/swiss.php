<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtrf6TC2ok7aszYCyFzxa3UWYOxr7e5U2xcu2XfTQ9F/h+FBIkwlP9OKMu71ues//iyz/KSU
lGSnLqTDUe4sRPFu9Abpz9CLtgpYXJaIWt6zA1NNC8q4t36FXxJSet7pnPRxeOOHT6E199+ch+Ml
6B6pSs5L6Rpnr5Hn0dhIliFpgROIHaIdXwqH6hkAPUzmTMFdpLOzHY/AAIhLuw3NUu0jRPEpzqqJ
+vTjNbimTXwYHL/oBo3IrcmDY09gFtM2GWmbAzyM9OqV3uQwVOh17D/d/8bg9AaxI8AyDekxB4rt
LgS+GqNkH2JfgLQLIta3BPQNGcgU22CwWqjtGDSKdPc2FwYL5MATABbc8FaYcHmtY2p0Rvo2feRZ
KFG503/wpv0VCgDxp7sU9YsxFVbIu/gxDjpoh5F+iWa+r1EAFRjwii5kUve9hBJfzEb4QdCQgKYT
/jDq38+W1fzP7q9Bh6+mSmImy4mgbjiN/v5LL8cmUo7UrvxbxH3wTXnNp90me1pLknvIKpSv1lAz
GACLWz3iMPhtFoa1DrXyhwEln11XmCfdIy2q+E4cZpgLmhZMaZ9NAPjLnHK2FVdPwtpJInM2I8cn
hTI8sEpzmBS1UfOWTRXCKRDginuWEi0RN6OgDvnbDG4zLXJ3iFX9b1JAu9q8AoWbHvQ0Z3ykVF+2
QdRiEBOhoG0qElOmekUNpr2F3/eA/okVqZUH4N1inW0Gjz0OURm5gFW+fl3GHDWzUNA0xf4VorhY
Lsj/zmvHfXAbDfwwiEy+xUBVqpEIPOT6AQM+fKpbqhGJzvnDqagtwGzh89pIWmceQAb5hAXmJqor
hi5hCsbyaLB5h/B4umVW92I+oWm2qWvSlbZg01wvJgnEpCa5GUBA/nR3mTsz+XhjJdTAkNzoD6z9
Mz3/b4bKEqfRzcGNiCWC57TFRvPgcSTJVYruNEE7hAz4fk4N556EV5XEmQM8rk6me9x7K9O5fTCX
vkS5SUufFIwLJV/x3x5qbMbnGz33+W4qVPSaLLkxLDlhfV1r8by86XVAyytaNRu3VxNbOTede88p
lABQpTfWcX/HMbv+0iEkoHyYJSSalpYHHz1G02JaK8hIIS3vKcJEdaKZ9R5mZIPJukN47rrMT1JP
kS5VUJZhtQrpnmTGCbJ53tOWR0UHuwzuM7//9sUG14sfzFHcsqL/4aRhJzYI9F/qbEHs9U+3l45D
gsw96nhIiGpENO4ijU9wwuU5dvHFL9mhXVPe0E0GnyRtYE2eFW8aUCCVHzNK7Yz16/5sQ1MGc7Jx
RKO+E4nAa3NkfilN/Cuktn96NhnRI28N+U1Kptghnaij2cpOTvPPnfP9aipFbIg7pnzRVzRu+Epw
cUYF+M+NnRfvirod8D42YFf3n2Eo60Cg0XeJxRCu0bxBLre1myHhWw88fAbQ3X/YhgLXfg3Yb3Pn
oKT2XPqJk/mcgW6+H7K6+BmdtCejfKWTCdJk98y/Hd58Uh47Ndgik+pV43cC2cqXn5TDUotgbhyM
EB9icHmC+LJR3QuVBQNcXzkI9JfK9JCYsDZu93jQbuj8L5la0/x4loxlrmcobYMK8OFsJ82OBmJm
zknjj7jl3wTsYwsSuqhS