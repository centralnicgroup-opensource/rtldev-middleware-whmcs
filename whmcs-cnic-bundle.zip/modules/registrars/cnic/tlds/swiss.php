<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmyAMLQArg6PKxlCTSEN6xJZh1DkG2WAAQ6umxpNvwJLnTL9z2SMFfP2jRAOvIJgkBthQhIu
Tx6rNcUfmqvS7De8ElPg8Riqzbd+ItSSbeB6eZRwv0Vqye/XvsBO0JA6L2IjmFeojH1Ai5COdozD
yMVt2E9kfVVQjwrfCLhZOzfB1OyFiRqLoYPoaNxSvHrJnivzX6f2pij8o8liQ75v94bJbTVMdTKD
jYZV3aJG98sNZUzX4c+9OwNADM8oLk/Rfe526dpVV5iY+qGEdJ7xGhOwLRninQs16NsN1K9abCsH
g+OESQbxoZXHa0x05xVGKxpwvp7Rp03W2jfiY0jWUIVLCRI2AGMcZNExmoIc29+zCINkbpA8zebn
m2Zimf9CkMXZ8c8iliMxerT++hq747L0QUnEr0gjh0N8Kf9VJSPGVMhP0xp5umYhg1no8kjsQu+p
kmTIZWaDZHkH0cwrSFdaIOmGCPb7LIWrua/diEoVoPJZtfRXpyVaAL0LP/mV1HvMAzq4P27y5A7V
uyJQCDa9mZJdsqtXk97IVqe1XtG6CcP1XdJ2LBIObANWpkeS3g4ZOwKgCIl9MTJ2P97Vus1YD3PN
VO0ctso286GuYHo9pbr3T76Kb/eVodYVj7+hGbFnti1ckMv7sOZoSaYAz/oG1j3qirXeZamB7FMx
A414Ze8hilWdmfm9t6ZZGOEuizL8byAB81iKq1RDj0tpUzWIUu4n4J7zp9A4HlE2MXYEhtQtebQf
158cqIKZO2atvnngBCryJKth5pGHVTsg+fjLjiuz1/P/9gwPeOFKPAPVHXNXjMbe7vVxgVeca1Yn
DVRIdkN8h+H2eFLCv15FraV/dIk9EuDmJT4Dhqc4xRuF8M3X5Cbu2TLb5tgfYcUAzRi8XFi0Uj4U
4GsrDky5OfMcdzygWwVxLcsXTxwPyx5q30cKg5v4dXj2q16kXIr8q5uV1jxfCOphsvoLsp7zrvSK
pfe0LRZbpfoS9VzGVfQthSiGyZxCBtbw1dVmwkMkSpE8xmaFNRRyEti3qMDN2yqO+GqPG1FAc8jm
2qZIBIRofikwLrUtfH8o5kplAfFC52xrBJx+vKrM6U+A7N3HOUUbEotRU8sb0b01uBWU5DsNnTSa
XYz40tvzZwdsvzd8rcBxfD54IYcu2EoR8O/VMKiB8yVTOutW04DcwTXTpOy/+0Mqv7u3OJaPMigu
hifUNQ/yFvj6C0WIJqXDxTPg3t9mCcm7EUmBGn+/nh0nz+Ud1xw234+Ewc5vTEdl3D2CB2T7cgWV
FHKVq1VcumyQzWrB/OeEDGRZpSXJpEunuVWhNuSTcCzR5z7Nbl8HQE4qPIFutTxMrRCtLR7Cn6dO
Mpuc6e2ZvAuR934ULI3sYmhp+GcpZUYeocLotXdHnD0AMRszBRurDjV/9kHUUK/1D5xaKfR62Xv8
fOfqNwixXMa0YZ8RyM2hv6B7hw0tlXNUk6+1aTqnaHyPG8cC4n6UB3upvubaSJG1DzAuox5pLBsp
O6VkCuV1HUw+TnqKEulE07bywUbVX9fbVZrEZ3+OZ/M/RYj934Dm15QPfWiWvZrM3NPJStxfMiGq
2t9pooZ5x5ucI+n80JGu9j5GbcgumkDTP0==