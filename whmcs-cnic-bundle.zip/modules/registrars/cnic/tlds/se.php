<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsWFr+VcqIl8/qMzGiI8vTFQFVa34KQNGkQlH5t9CQzONd5slj3U/soG9Ut4zareYF3FX4xH
avPZ6rHRSVRc5RaSfUjgCSx3BsTEm3K9BJFzYXMiNGg4ysic/dzQAfu9GAuUMBPM+asFKtY3tryu
21M9a4cK06v2XerPijVOCHaMqRmMqUMDAjzS1avlvWHWbXvMSpflxdjthsWMcK53WSAxWsRWuqA/
YGToVgazKtX8jjsk15AunN/ahBkdfj3Cu0Vvl8ucrFo54908Sa3fqXm74Pl8QPx3u0UwJdfkhCj9
qKQ6GwI3QXJg/YSgycqoxF1FHHUMec3cIx4Z6Y4sXjA0OxQfnIBJTU6swCDFQujS+kHyZEMT3hAp
cKXVqCyUPjQyAYmScrUwZNNi9cxd6aPNzIc1cuf3V+0scOlS9R67fWTgcwE8B3l9BBji65GRazcM
pLzb317mfvlMaGx5szl3YJ+y6dvxSD59L7gEsBlzsUdzsmNkRP3ERW9ToAKwg+OqYxnwzBNlT8F7
1bhmMgZKKI3zFZ8tv2xNC+q7tvw4CaiEuPVu271KZf6wDS8JcQViz3SGf2jCw1vIbhUaH+UvYrdM
C+x3V4Q4doghhNEY+I0BZxPMqaDxLJrR+r2B53kIN4laBFOERJNcuMFrGYEU8yoioNM7W5JRwGpv
NjinJaxKGC0b8jMm/MJK4OpTT7QH2cMw1sJqcdSaZTLkVa6f/QBFTA/99Q1Z3Ffqo6ABrXQPGAs0
BQb9on7WtWx2ttyjgm0xS//qgJgbk3NlbcGKLb75eQIEmIQAQiN08DZvVwlq/7p+EkIMzUtORl0B
QNAR4SGMf/immhHXz5WEFcOlbAlQnBAgFKFydjoFAiDd2tyEy97b97I26Y0VKBoeAlqAuoq5X9Jj
7hdS8CJ4rN00OWRDT0zcgqhbbsaudmlJ6p4dTaYFyAvTvPKmVJcqivG7LAI0tMIlacQvN9erecIs
RWslXjms1glgL/VVfmZ/+MnM5o0QJBY2icOup9V1v810cPPzmkKuRM47Ga64RA7v/1SQARxqhuQG
TDCdv2Yzwlq9NDLvjBN0my1/fip2Lj2E+UBQTDfpPYpvwa0cgQ8l4vkaO4uhS5rdwWIQxYYYlsEX
4XgtO1kRJfPBTu0Fzrg3/U4+Q/RuIVlxoL1FF/u7t89P7ccJP1EZ4+RlGxM0heGxfvMNnUA1A6ko
FUusi5qrMyz3gRrkiRW88mMKrZkbyej9hdE/FmLuY2FKSCtDEyHBVgdLTaMYwiSC5V+s4nV4nEB+
fJRsASIJA01zLS7sWZRI2mN5+HF07qQ5AGc9TYBqhJu6EYyO9/u2u/gi0JrK+7NnADub/V2W0Myw
lSW+yxoGkiU68mWGhK8IUCK/jpfDq+S35EKLrrNIKO275SFsqbiYEgBFh+FZpoxXWRWN1y5PzAh9
hNANHnMXrZu+rJ6iSQ/ITPg82h5/YVFPjrC+tSNwpFbH4XPvBxHWZ9zSnH+Bin3IY6Jl7+XpwaUj
Liy00I8byHsDhvaGup8aB7Z+JNLAk8cdfy1X/BBCpSp6/sHvLcOII/y0fdciNfsTFVIpyyWVzfYm
Dy7L3qD26SgCWzSOvGUBYeLCBMtKRbc6OPukgAEte6cfaQzz8f9buQPquTHKXM0Hj6FqeHgLhWeN
Nww4vHHBZiXS/EnQMBxg2C8NFfLRRimuDl+SXSpGbe4PnACNXtF/RnjDylFAUynDrXs+8dhgeOYh
M9Q6T7iEuVV96r8bsjPkrMH+l314vvZMKqyE9g6TdzsjRntus9rSjXZojbbKJDiINhGWWNJgwYTp
QAiTjshB+OXoa4KHMlrMm5NlsT/REaVEyC+0cVUJSwtAHBB1OIoye4KUKLh1yOH+eADdlcG=