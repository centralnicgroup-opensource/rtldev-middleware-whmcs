<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtl/lrswmW2clPkEo9c9s7kW6X4+gvqd1eAudFpI2/t0VxOUiHK6PjNo4wtDxCPGfXw58J2S
V5w3ZSqWkSV9cufRwz60RRP6k7DxhFXqcDoGwPuWP22gVeDLFRJNZXpXvPBdEzLTFgTffWAqw9x7
rrAEGX+OvaK5iGjV9Ynk3wUMJRKtgljVBO4PZvS99lL+6qsB7iBGOz6COln0PJLRsKMGlovvbHXq
vfHnM3Tzu5jMxs/oFkLLyrD0+yIGES9/jHUccBlKA6H8ahe357dMXSM94z1hFtIM+gLDaAl/Y4vY
1UTc/nsrUqY8o8c8YqJcex5+xBuGq2b1OD+9+Gbo3cXfatPqaJMrJ76GESRy8jJSvqHVxo8l7yAU
X6tjR/52lGymCByE9zqimvO38nh9AijLg3U52WhAZ7oyks4WDUmEbcFds8I1w8GczgdPiLIyt5Tr
DGMjNZHrJg3ah6GL05vC4HJBlj2szKP+1JX8+THR88bvNxaurhr4O+XbotiY88PLD6MG7kfzCbCr
OFB0SRYwZ60a+XlQ8TNmkaqkiRDaAJaRPXhJK+QEUJd+8v+AxLo124HaH4ueDsdQ2uCAmCf4dKgc
LWhV/uBWCeC/Z69mt+LInqtOmnUjUBZ2wqmbDIDa24p/gQyMUOPIyMbssPzqw4rBBPa1aPs83OeW
8jbejMFtH7ITuUK101lnEPw7V3tOGBfunzE8KZLwaj1kDc6WHtZHxZCSunHIYxY5rzp3VTnvv2nr
M1d2XdSNLRm3JwjtUpMV0dA/83MO1SVwX8DpeEYrxnuKRvCRCm0jxCTwKPEP7ScaXMh7xPfpdFZu
YQAELu+hrv+csnHjMNmW4j7LB4I0qmPjw9SuQYs7Mef09pa02RmvFv6pNcu8wcWb3hrmqOiF1o5R
Nunt39VDdisuUCRoT63bM7en9G3X0o4fBhVcoNqxxvU1TKJEj+lauG5DGOPzp7JBy2BQ0emxhVR+
lmR+DZ3mOvbFVwkD2jxobMCU0mf857Yu/rpplzMnkRzn91jxXTQti2tzwK0Bn+uTip/b62QMRc4P
ywXzAS52sT7xTouIhi2MflTCmP7pHMcZP86e5xHVgV3YQOyafJIbDD9ZzvzgDb49mXn+HJxOP/PZ
96ew5Rvj+LFSPsZ8SrXWjyEpugzuJO3ippcq/UeXGpIa1NeH2laQn5b50lXL6SA6x73XcicLIig3
7/UyE8RzuCj9n36BFyyd0RpVlu8IqEnuW9FLqJ+dmYZJoC3twSCaJybnuYMtz7RggDXHsSWnEEDa
c8k47Fy78KJZPDChlGkAUWKVvTkPp4UhyZUr/ixlI2+Jqh/ig0X+/maIBJLEisVaOEqWUoZKijoE
ai8EnX6+8tnkUVal65Gf1nQZNxFLYM4ndVLv0sgHDaXriezbibaUY7BmahBc5jicoaPXO5sXeUDG
3Rqit7HDMKk+JCvH5SVI/PqJiGBXSWFDcFNgZDAomioVOc8RMnAoLQ91VQp1BlUwOJzhlNrl3+gg
MIpjqs6iRP6Yi1d/b4b7tQxySrlpYZtwRyHHrYZhrj00PAF5A94ktL6oNpfyyrzT3rrPSbeTr36s
qePGJRBHLgJvaHSZ0fi7SKzZL9qEAR1Fkoo2FGEXRBZN3ChO8F0l5VkbKE4hG71gleyLaoSdqxnf
eOIbFfEAgXuthKHNwcn3ErPxvD1/U39LabfU3F1RYJxiny1s9eV2Io73o7mFkFAppqXVj/LGSOAn
vBivaq66jrYnQ9Jw2JF/IT0JvsA4R8j3JpsKKN14Z1fnpVLeri/Rr97bX1ryCET+rDfcFWiJ6Egi
SNNRzpPfxsi7kH1mtq9D8NPsb4Hx7XP8ar05MdsnZaYzoSB0mQxeIlBo