<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+RcA1r+Jf5I1rIzFiExJh/It9oPxQxwqusu0oPrmm4pKytZwzTKly510+ZuIYi28y6Q/toP
XaxMMNP/vS8IYnQegzUM3GHKsZDdXniQqf+dg568qytXO+yNeeJadxXJk8RJp7uS9I/Fk5UNKX4z
Sa18jOItrh4MPI0r+s7XBKea5E2uKZXybpVDQveSDcN74UGkNC5jRif+NIHr/0NAAU2W2ZDzyOtN
2dkJPrcsjOqSC0RVU+6n5Hxni5cgm4ONK+UnEPx11iLtV7WoGwx5smpwtO5fK3z7bRbu09V9vy+N
9OO7/s8wpyzwHNYLDtIZ9AtARghNH/RkbS/+ioRAAJ5a78XG2nwEPEusC4CR0dVFDhi0XBLP/rEx
TBZV3dQvxdpjXjhHL4obM28zYLMiI7siSICx5cVMLJ6r5Wy3WvyUxUW1PIyhTxTvztSZSPAWJ5o2
xO5+C8aiXrnECJCLSkE9UHSGPZTo4HS+WjDkiogZNKwAoEmAUa2pBCtX1CoMY36nc1oFiDshD6vJ
6y9SLUWfIfo1sFEx3UW2evkjqzLJbHT57wGiTyiNvcBf0bhlYhREmT3Rkd0eGIBnxI8miyiiW5FC
jTOmB4+irnukxXHeQgNv5NdH5yCAXpA4XnnzfGMUq3K9m9OuJnO4YImHbVX2Hr1rqVIHz2x3Blmc
97OSK8l8mP2Ig/5Mb79iau7FK3I+ylDW8yAiRTGMva+JZbQvxn2jt1IXnCaZPpwVXfOc9h5SRRtP
CowlWkTihHJp01EcHREh/rFn0ZgFnio93yQHkpjuWU6Cw+8CoI/75IHIzJtDmzcXgUHaUY+XtQgC
b7MwyEKdd9kEWAIhJmMOzryrObbR+CslfkYVPOOQLhWLwz8mi+PXyrOZH1tWo8897mCpa4KHIydP
y73LYDg+gEyameieuV3zkovBeUnW8biQjgheZudu5Q5lZR9UMjoYbF3LgxQ3e/ZcgJaZHsuAbVIZ
xmZLBilvSkYE230Odoz5uqC8PA7bVXxEIGUWBWAS0tzqABuWrIHJx+Cl+ORyb7B/2C46T54+r/gW
ILU8zc3EdJ0ZRuYr9OSYQRoMx6t54ojAbfN7J6n3fgUh/ghUfrLw5BO9nnv4i7ql7KZfXk0uRDMA
jg5t2jqHftJMtboFu+0w6WYIzb2XQoDI955xDXpp98+p4Wx5JcA2V7dO1S767ftW8GC18n3CSs+Y
6cCz1OVRl/H4kJluPJiVqPKi5YyeAO33IBcsoH5f39nVw4mNzIWmr6p9UmmWflWHSdMv3rdxfsfh
m6o13gUI7y+zL3uRtKY5bkpXTvrjCJULK0SYoMJZ2Efq5p88fDWt5gjD/r7Kr3wG7N4JdWyo+dYZ
LPNxoqXyta7zte7CIrunCXCFjFB+SMZwEjkSMT260rpxSugzjjVOPHFgmkzc9w8oIo55Y+HNdEX/
OoY/Qbyr8PWkonQdjjPstBDpz2qkqFAEYyMpZMdc5/tH6N+FVvsLo5xFAoW0Pfq9B8VK/92NPjTj
QETT9P4jk8KlhF4Ljpy1itVjJPTel+bW4CFeZzHGJT19lBVMLxeqmGJo5GyiLmB0rYleEzDaV2Jz
BO0dZwmqhWSqHvgD/1OBG0FEkwN/A6qUMT8cBpATDUolJCBMKQO2NFg9tvyPYwJSa1o528Ah8+Au
sSS/JjwjQC1yqH27was9Tzh0R8q8DzXgvtLU/BvduVACfrTQQRGX4i6yygTJDIb/q2VFq1hM7qKp
4jTW5TDtQIMa9zvx098HDhKCxf+6Vdioq+cJ6vhwMqdV8dcP1fRoZxTXsD0BGinDFXRl6/b/XHeB
2vNQ9e2hXECla+Ai1k+UHsKvGXjS42jKiagFeK2V1gaVR4BBzlczuK9gi0==