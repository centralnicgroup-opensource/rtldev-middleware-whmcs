<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/bJ5BIGlEoxRU61bwjoKZOf9LTj+hFME/LihmlKSaLcQmq35UdAS0hGfLakIidKUIScn66N
Untf/P52ZrTIQDdgLQw9rpNpqz1qbrUWCDiGU7pbiS+CfGcSDDV+2EOH0ttreVlJRmwnRIXBTPLE
YG59hTl5sKBZ/hkkPYN4QjNWGWAe3K7odKibPMnYK/HT63/XKOnNyfYIozrzORSHi8SgazNoz03l
3XxnEXw3TtS11I8nPEJtznt4tAneTEoNxEjJBNBTjfIwBP1AAYqc6eIq/ZWBR6mHbspcxuk7YJv2
dUP6KJ1SOha27TbisDwgDQnIcs1jDga2xmhUlDfQD18PIqgH9CsxN3XxqMxNISlhRcR+KhEH0bAY
tFj/1mecJNzZnJeqYjrj4neawFXDUVzaxlDh907PGUX2zFaJ2IkaV2GLhTbRb52o4KKDaUXiYSfN
V1ashwYWHBfopNa4sE5qo5SdRF/n7vDI3mig/xWtK7Wfp04icGhzuSmFYgiZXMfpoQjV8M8Z//l/
1xYDm37re+fFBlyJeC+wqtt/oULoSUlnCtH1SExRZ2CoqrRNH2WihVz1ma6vvXyCaf9JArly8YLi
a9meYdcG0C+Qn5kCYgfxdYF7+Dp0STIb4Sd6yqhLLIcGCe7A11jQCyOZQnXtETci9G3WfG+mcUYp
z3RHNJ1Hm2jjie/KJ4iJW0UXLkLpiWUXXA9OctuNDWSwlfej0Ilwj0MNvyV1raeAgPE5NCcKc1JA
loxKrXkwSRnnQ+ALl16WWoIoIjZI92tFWIiwdo8sZfuMVE/LEuao15AGax+ptBftvwgGibK8e7bA
Df/Rz/DkciJfC48QG93q1tSkXDT/th8hDKWqpfIjVfoQEWL0XHiGLT2LZp6sIiqofwgpVsSz/Vge
Zb8mNoOkQVZt9UZqOgPbZAGr229crBJ7qDKiqUCjERmPilnD+vyzFmgkIp5FUIIUO5BMY0V+X29k
hCH2lObMAGKrDzFY7dn0ith/Bg1y6IKs5tbcJLkM2BVqXyxFzosfI8Jib7t2i24jVS/xySO2yewr
0sYhYDbXnFtHA89g9Sh52D0QS30DhY6gzgxNN61NtPEvjVNMbRAq/EUSjWQXSXo5S0t4HYjteOlj
+79Gb7aEUBuq4qCw83LfNsY9cbUau3OOK7jpHEyPf3RYIxvJix5+XPr7nuaFDzu/0gIvoX4VKOny
fTVnmOqqTTM8itQhM1eeVum2L22Ipqm3Fu4UJFGu1uT2AsjrqkzEta/Ha94neqjArXfwawvdyebG
NUqmLTSDiIOnudqmnTu11zQdkY7xscvW31rMSnwmnw9jx9dLBfDA0y3+J0vYJ6wtESm/5uE3oTYD
mmQljJWN5XEJj3LecH0R+4hT5lvn9+9ccpOxM7pt52/O5uYsjIbOLaJex7u9JDEMnOelBq7FxiEd
vtw80tI7wkAOB+ZlvAi6dS4dReXy30UKpvEMvCxuUTzCvKRbszuxhXGr4epkFYqdUQCq45QRA07/
Q3sVcQoc3Zu/zJSFBq6wCVUcZq01E2SXJSPjiNbjdKctG9kUuaLYfr2WstdmEX6xgeO4CdF0NLc9
HmQmn2VGU26nhE0h8V0b8HVvqzO+avo6YvYQg8S7LnzQ/2cnzqfhNrhAsnHaKdyd/HtN92od4n8q
rPv03WM+CA1UA0K/qzPscmhdkir4R3PyYgsSDxAbOYzALRnmeJK4LLtNGuwYhwo9kE5z+YKVj8/v
YwfTWDI6HmKk8VsxZUd/vs6W1sBwaedcbbkx8VfC+A8jaeN0XNHU2BV1nHczLI+PMiF4dviCImWk
TOfQL9lXe37Np02Pd+f3zc+XOWkiezmBO/Cms0te8OZL3DNnsih2Mt2OJSpWbAwQvBRtHYxs