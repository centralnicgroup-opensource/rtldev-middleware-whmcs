<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnko/NFraiP4W01eKENtm6iMU+iEpd585VSJ2e+6nMggHs332QvSVC2dNyRfeDuIksbnSO4o
A0JP6MqQctAcbs36hf7+gha0gDXqrvBt+96z7TwiQvj54a8mRXXsdzFAp464bCCETA+aqheMtRcj
ILfZWMFiPc1vJbnzmTfmG0zlUkn6sKBQxI4cU0W9b+FDC9Q3ba1jwrwhXpE9uz+HIRIV/U8QO3bc
1T4TbTnuCF1bTGGsQotj/O3am7ylPovQMP8zKvx0A9d1QnVt6YUGhGaKg6YPMsh8AZFMjnEUEhX8
ruRpHJ//gt0FRS1bjbMt5+KrEspIeM1qEokfcDJWxlGKeJ0u3x4KMPv7r7+RjgGmnd7/s0fgPLB5
2zn9jmugU/PFMDO6qk4ZPFOBOt/EWepFgngQaEEJf2aiMdN85YSF9W96LwpEJAFmaLP/QpsfdCO9
QbLwK9rz/N/IPyKA4640TfYvhM+kN9xVZwwgGxrFgDF8Reacum4VZhX/pGgO0f8218cwZMZG2EdM
GoOhl5RKbPkNeyswm5n3uJISMJWU2IJO52VPdBhw9bJ3Dd4aP1/I33tYt13I22mYyO0o/Sx6ptTm
R9a9WGuiCdPxVyVBN/gaxCcF6XS/seTAlLxxmJxnEjfKVOrV/WE05jCJrQpCw5KC8VK43mnBmQYN
EvYKSokVqDkY5js5VfNOW1ljO4yM+RKYymuwsQvyGUhKZ0mvJ/3QQrW7+oDIjZLIUe/r9FB097YR
zAQggaQ4x8yb9iJp+h7sFuNkbJMcwNMgtmNo0vql/0g7e+OEP1V3P0/H2RaFGgc3NOmeMbN8M92M
qDa5UH+T7bTnq0/Tdee42vRVDRz7xsptkVjx0yUPU9jqjo0HIUdCcyTgEJPzqPoJ7G1xzfWhrkfh
U+euxZcduyEk6hrC+qVU32nJX7bzgFhvBqBtqWlO6ZbdM0hvXyFONJKL13l66dWHDNneWXsIuaON
y2ztHkxSdT0mSSRrtGajcTJgyUMcDIiQ3SPB8Bp5W3NSxfoUaWSmKvzsOnjJRx0nEaN4pua2aH4A
fr159aH0MdpZyfoe8KGGuICUkuz5gHoNfhDJObhnpbi7pkOQWLnXfrdFZ1TWkmN4oH5qJAgm89lQ
CJdHT65UMQ8wa2nMZRZyvyECbWd9Qw5NKaDpiv85zBB2prsEGezLC1i7HjwdTrMJb8xFWkfNIzT9
DRyFeALZ86zh6CqGiQZzRXLedaqYTHo561fzwtrIjBvC/uk+pTR+Ty15dcPfpjI5nXSwZEUbiBR/
lYYDIjEVdcth2pdlKu1wSivI6YUNYjdY7KZvd0vNOyve0VUacPam0rmjDYyq+mIVzpzsLbtXt54E
ws7OHV4GFWryOiSnIjGIIUD/khXSVHJdeRdw66RSdDjsVbb8m9/0TXptrPFZ3RPss+y6w+GOj9Kp
YqT8aIes0OXiXfHOfHYOEmqH2jpB9cWIBaevkBM7U2pp0r7babQZwWxN9GxLUqe82v5RXCdXqYaq
BwNMIA1S7LiNHzhn1mkTKnS1xz0O+Qgqr5D+DsdlXNN1OkR7mGlAhK2lJU+AFvR15bAaFqCr2Zvd
b/9SyT58foug7ZIZ/MrcWAlu+aOLLxlo09NEmfGpcnuQcqscxYKbqL+yZI21A832AJI51+SkOCYO
gXbdMChez+h8Yn/7rmqDyBcATOee4FAZ6W+LbunzViBO0k1A464bwAruqaZti8rAglRn6W4Khj6X
95a4zjyrIBGLz8vn8KTun5uDlux4bycyRuKVDHjMxYGm12Z3YiPDi4Dh+wNcJjUQqcgUGhL4Q8kA
Hl1FMGTiggAuPojE9Q6S2OvLLLINMh90gpaYvpvZDkeZOX3SpiTom1FoW76gBK2bZ0==