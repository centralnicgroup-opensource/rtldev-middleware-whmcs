<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpGgj5qA2WsIqvWXVayLVkd8lwNZLbOeIVubJ9wE/kA7yYrm3kM4GAy5ODOXI6CJ98ow2sDf
+B2vhwlI8hiMazvC7GIuGKI4KBQOwF7JgqRKu1hshCqj+3WN9tYhJcBH3YYQUqc7hC16ihVaZy9p
vtlxIgg7MVy/uC3svo0+tvVc9DAeXioEWsTOPrsE/wb5+SYhqLkZfjdTEoM6CtyVhX9NdaZtm16W
RyKEI9gYYy7fuGx62rVCaPzcSbImcp4RqYsXj/OUhFE8wjCb0dk61sISd4jQ8ctXXGHONouIvq1M
sFVWvd7/1lQrMAGnLU6B+anrk10PPiTOCtpm+isGifln3kKqCzqaBAG/FU+Z9070rIIyoDHesFqH
puSCQ8cZ866TesAUpIRIPHdjBuEVFVfkpxv5Iottc512qi/PZ+xYxZgWTRc6k7QNUdzZ99Hbcroi
rGDwkurqjSw8VS+uIfsedwLcvvzaKZhUx2nZ9EgRLfbpsonNPp1e+hbSowoZJDj68jWOgXWDBJHI
mSYYQZc0AUXB6FHrElNwfDkr00Z4QQTOmXClhsWsGS8WoRRl42Ub7+E0SesM6ovSAU8R75eB/7gU
MbwRy+Rg64xwEI15sAoj74LwsaQDI5nNw5zaex5A4L7rJl+2K/Ymc+0j9wU51GO9tkEUFJJeIhaP
tCQkdBz0xxUcQ7r1wnWbDRo1eje0RkMn9nqlmRCur+BKhohcDaH7KeB9cv6cyVNLLsznjzGvY3A6
RDkK6hNl6S2b3wA5/RgcPny+KhRJ4nznKPett7n9QUitFdqKDx6QW77rgWoicKw4Hf0EZUVjFfnu
W0R90+CA6lkoPzz/CEo2zgn5xMlJRYj4xy5Kzfi66f8lysOhMq/xoHC9gGawi4l6e4JkU89Cw8VZ
fP2Oe6Qfg10d52lVClBxfehblpuNnoj3eSjcQ9wBp85S6AVZFmguV/Wiuk3yazlSh7Q37SSzmE3q
cHL/VB0Q/toc2hBZrxFpR+dkQzws5/daxVoR6ygrbngNTFtok5mnKIK15R7gCiXL21y3tDiVHQ2H
w/MUgA+KiXse6hl0bWqS7b8XwcRsYqydVFaO7QEdauQsY1t7r+HgFGFij3Mx0/kODNn8Tz4qnX+3
PJzgfOGwlU1L2sGMlthEQNk6Pi2ZcVoGQ31cYyAqDo+rwzHOoDFnctAMr/oBvheLDONuEtKH4tT7
iW1xPK1O+rDb2bWgvyCIgPCQ7SScrftZ4SSiEC8p9YNJflazwHKg5yU4dLo6oTj+e/iijc/nHd2p
5pVyV4SUEqEcKFRNtO4bDaRixFuuifMz3DBNmJ4n6PIXVMZ70fypJeDsJydaFiv7+C92NFMNKjbM
UQJoSYPiSAkonoLryUAQZTFHA/TYzLjZQyLutBH/HIwOLZKFzaMUWZOi2x/PB0faTeeDRaPrD+vZ
z7tq98PtvuX2vPEJGBJ0GI6X7MJfBbDPNKwndM0g3AkNOueZ5ykxLYXCtZtfEc/r8ziQGtmP60jl
2UruUHk5AgfYFTp7uzeEKOEC/Ie3mZ7irvbM6GFjR7SDntI4deQckKISsMynfQnPJHVfX0Oxq/CR
uin8fOJs+8Y35ZVTpAdyasfz4F/75/iPBSQdT6wl45pfDS/w7TR71LRroLGrkKzv9b+p+aUrXHpB
HS1YAyrI5iHDD8ViPRsFLmnTXjdzn6nXV3jwshmCCkZ+yDMalIOcLGxxL6D2gmIRA2wtMe4FONtZ
w2tNAMtTU3/dd86iw5nFXeYxfcEOwI0u8+34LSFyahClvel4tE9IWEV6jaCwHcdCiA3AK13ES+hz
4eMSTh3mILbjaJYkabyrq7f18eHpLg40KZy2DeLXP16zAb8NSW==