<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnfGbmlYl6ii++82A1eo0BceVnt6lHbnzl9vAYXr72f+nTkUX1izWv7Q6qLk4E3RZ04xFr7L
uliLTThwqITn4ehnQvTJHtGxbaadrIqcqjvWDuHJAH62OFb/V97ut248HpxNkYiPvvO398iu7wRe
NphGDK7PFUNWwWN9mPsiS/PhnnrwkyYNQdE9BNDJ5nd5QWE/mBi+fs/LInwOVgnD9AiLhZ1am+/V
spaeFHXQHVOM3ScNv2g5vFqLCouOLej+DFJ9KqYDK1aSaWwd7YL+qQIW3bHvOPwcQPL+ygDgJYnr
yL96CaMKpgcm1dyrQQ0L5IvWZqthMoieY6trJ9XhYNKmKlzNNitfZSLu5acDHzzzFmaQXqkZUllS
o8DGD27wAhEqpzLFRnv3IE2Itp95Und/y67ns/g8+4hREkd9nf+k8oMO7RO/y2TiockBKffFrUDO
klgK8hi40k6iA5l3odxJ9moCTPbonRyw14wpStMGW9GQaartLH7vJEIZD1pWTTbKBgnsctih3MWk
eeX5xDf22+7jvyQToEZOaIv32Wj21+ZHrYJTgjq9yR3HQUIPcWE0A7G1qapL9Jkw/D6HPcZ63TY9
Y+wvNOsGN++NCaSTd893hBLov8EBvp6dTu1yZUwvTeH4DZ8bPmdF/+fUB6uu2tkLZlVRtEF06tIP
/IJIkGJgG9ffwbITB11KbX0IfudO70gEx+XZOMO5dYStPlHMeDFuTsmi29HuaWpJFo7SCrcNtvvp
asUjnlkyzCBmEb2Hzpre8eFvZ2Vc4HfHJMhQSdvod3/J4dQ9llbI5D5Frcba6lHdhbbnDH+TfbFN
Vw1tYE3Tx7SrVAxS6f5tB9ru2h8kBPVB36kvCUxmze0pZT61EsrLANNxirsrIoWSmtuL3nC0DFT7
4aKUtx/pJulil60EyS7T+KgXzEWQ3Wnt/VtS7jOohz6wVg9UB1MuTFmOqjj4InIXVClH1pBKNJct
RAwbFbelaY5N9NHyqlLzJhHmrLh/zhl/VTOvqN4hbG84l65BMhSeM6B/kD2hwlSilmeJD0FVui+I
PWepxbn5GYABNfXJX9f9Hu/HgtdP+l6LTCp4ryxcTUTN9Yo/GYr6q4G+62XZLTkQm4xK0MfrC/qu
RG0qqPf9lNvqGQvALca6PPlwy0kI/sP8OKe2SbNmSIGhpNmqY0xc8kRLUvnJPPW5KYaAbKvDcZ6a
z4JBFzZZD8qp7mQuvd4DkVmUd8HSFjykKNNUnoK1+Zjxvih8BM1rYTh6G7fPzPyqDVVpEvOEmSbv
w26smjRKHJOmhecgqj33dWhSE12BG/rE9u38mrx26K5HVaQZm5+HPE1QJnZlnEWbNHFErPPC+mCn
UM6mo77rtPmTfOhPdRKuwxEf0Z06tBFKKYQzZ1X4W+mIQNAz2h19IYdUEfvudbIY1A7rNF7szQWM
ng4At29wjNPrV9Ih5HNPzmxLfGwuTsdDo1WJ/JC5PEGbvt5jH9okDvZtDBooncHBqFB/MZJqEaEJ
dSJvAVgAt0ufoG9vN+B1Z/1Npk1+9pC+Brcb4IkcQ+TXz3CbJHLwKLj8mcyj/ES0NrKZvKvPknuw
PKY4t+3itMWwzcGSYvbwFe0DSEY5Icdw68Dgd6a4vv9m+JMEaDl9nh/U0TVpcce4uN2TapBP7G9g
ld1NgvpVfOADOubs8nTkV1UAyligCpaPYe4Tgv7Xzb7djsEUSYoe24VbHqC8oV5QE/qOoxAe7skN
VHsBk8gtLJZWo8Um+XCvFL2DONWaA4sX70xcngXHLXDXP8r8a7Zw2o9fXXErOBKsI0sh/9zU+a4d
j4s5er/UOPtBR+Jop8aOO/N7TU+hoSHqukbVwYM5ZuAAiiot5pGCO81b6XMmCKe+CwFLKB1O