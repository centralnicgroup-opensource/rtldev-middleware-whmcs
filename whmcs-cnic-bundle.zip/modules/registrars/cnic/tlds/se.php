<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPspQSZVkEaSvzsZd524ABTgjmbsUTciUXecuFhUMyrSR2sbx8Shsk4azl73uSikFfExtpgjt
By7ZjyZfHitHv1fgvlQteGiWd5fBdtWLSXixC0dbgNeP8Q6kyZyx7bG9+Wza0dr1pZy0J0YJIl4Z
d1mjBPM1BjVAj9JU9t5OWHAtrJwrSVCE+0CLaKsnChdvqDB8iRK2KUxyuRhzpKygENKEoYZqyJKw
hwx1510Xl1ze4pIoQI17dr6rg82e+cG7cMNMAzyM9OqV3uQwVOh17D/d/1fdNitfYynXhIsItaqd
+mLM0fnIbc2PO9jW7/evUbi5RB/8UhQQVzOqEqQ+E3g01cMPqtuCGT3YdLHPIWQsbo9gUPgdQqtD
jFZ0hyQ12cbpxmFbIvnjohPsJYmPl1KjA0UjSCKHXtdjKL99A6xQKSzcDAJGhEtFwpkDMuZoqxka
dn6dorWjET3GEfpidM0JN6j4R/Vjj4nCs0CgXy16q74ENhgSk5P0vv27ZCXt7vvamjVPJ417rKa5
aC4S68hdLFn03I0OvqF/Aebu9KdVsiyvvOEbd9c62sp6VgG2CrLdOW4w2ujg2Yig6cxVaMDRcf7h
iJtmlBYFObLj34pCmdGQ5Hd1TmQD2kJjMstiruEKPvIQrJ83EdJVsHji9JVleRfx9aXZpDfbVE6z
W6CqeDK/hMV1hJ3gfrWaUCljTXWUydKpxfWCDlxl23zJYG0Sb5u/oBF/iPnu3JhA9tGBiQsOIS8x
P0dSn6OFngc9QbCplr7yPHn/kEKxlvY60qlQr/L8OwRvusFFNCffw9fRSZN5DIOL818m66LQVQDB
chveT5Itj8zxt0iESEqgJGb/NGVifkQ7O+XE/7SLAxMDI5Icne8K1fAl0LGqM1kfWyp/uvmUehgz
DiDCsSAZzX4za3kGef3zvQtV/q9MoXvYU7+wX8/qyuC6fyCxl5tFSi50PYpHeDbkaVdR57Xt8uHP
Jr8Nyyzs1bk0vPe+kCKhQ7xYJLVDGqCh33W06/jTXlTHxdxsYZT+zRzTDn2MFclwsrIESEy7SgZq
9NqABb9qs5LUMlrO1yLB3QpsLr7MCS/OG0Bqq5K4MYRER8wcvTlUqaeQzh68RckKXcxYWJT6J5bs
3hhCH++eYsDBbgj0uMzAcLcXJjSUJgWI9MkPEoJOAIe+LUPWJK6FC8wFwfIUxEEc6W/q9zN5o7Ju
Ky9wZWZqqWVsRl+SCiWlkekx0GZJlUlfSZIyFMY54u0i+S1lmbsTCGy1K4qlwFh/kK76OQfcIuBF
ZHQQ0lIZuw2Be2Tho3Jq0cGuRgsatIjKAJdQQ126ORSsd9fU7r+m4plpGWkxvpV/WAXposqKC/Pd
IUOVcj8hiuKABn4m68sYZr2fRLvl7GnwlGPQV7sdqdcD8V06gaJQJ6cnjWAj7wUB2olGmf+DLo12
ArwG18IPFzKCj1u53g6pJbzATxg9bB/Uy/ZDROXg28VvUuMUHEn06pRGeXIX/AWYlHBPpf/Vw4u8
kNLGapcuKN8Nt400E+Owq7HbvMnaT2MPgC0p2GWHjN+sDL5bSc1k8vwHn6jILwpWQ+ILFtXytqBC
lpNo0CUypWQ4RQ8ahHpSgOANkAjT9N9VuX4iqH/ljFer1dK19Ea5ujnWbbokhEB0LHjuSW4sP7Ig
fTVLtOEFVFlcOABrjfLHflA43OhWtf7bDxJ/+pep5Oielirf2h+gA0svTLx7JbONEotEsjDxYynS
7gQf3Ft6K2m5Q/Q92aOF5ls7CZbWtPeqN+YjxN/QqGQzZeHjfJydyZaFBssSl/lvdDV7ogMrQaZf
oGtdVxMavoZ1iPHcblDfn8KDKvmRaSCXN8ztbgn+SYunkeJddy41AlHXdc+tPaO750==