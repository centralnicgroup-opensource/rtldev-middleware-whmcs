<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwCXS1Ob3qbQC9FbDJftrPUPCYC2esx4Xe+uqAaPMexQVtqgVo6TfY+/LIoCbamkaOGu0YJ/
hGolsp9Y2Ril1McUZBacpEdjQZvtsPVHv0/08n173vIieZsCmUGFU3+Xg3ctEUzYwOqtx5Dv8l1j
n8YDdIIf3kQybbgCdXuiH7ydh5R3KkkmOfTZHG0MiIndiULRwl9QZrO1Sc5lGDLeNyHmGbpMp3yt
4Ujoc78GrYGUbz+mpdkg/AJPJDm8z/gtR8fFzJ+PedukJPKmH71Gvf9HSvDarFfTC56Cp/+A83fT
UsTb70YHblYj9hAvXpJdwB1eSQaT38bE+HJUA6X1mVY5UNBYvLhQqGVdbyjYlToWi//CbgLtu2uz
6y9sUnnZjfb98iWYmoT0nIsSHhHTMusmKVSnP3MP4Ahu/4IQdfJUsXgcVrRRLYGx8vl+HOqv/u/b
vQ9JX//cV7r93uQiaVOfgcr0vdZ8Xg/PvPJS0a7vcNtXy6t4+pMQuGD8QIiReiJRWe5T96IjT4z2
feJPpcIbYeOXXQC4d2kKKjYU2ilpVEZcMSUb6cjNfIgVBJTspqv3un0++b0Dv/Taqmckxmyr+D0Q
/VB/t7qmql1Lyk2q3PPoR1D2zG3habWESRB8rthrLCk3ZM1UBEcPZlpsP+8uqo31SYA1hG9oQFqF
DqphH3wgd8WQXYNO5VBZkuNnhaTWdMQQPWJwVQy42uBkzm8EJw8wdCrvg+tRLAeZU5sY0T9Td7GR
d32wavB7O7tUfUYM/hXX1O3l2w1ToxfoLwtMgSCZNdHhtFbWlhcXcro7ZXV5C05AH23rL6h/BQwx
CXHm2UO2s+Nt6hz334ox0dsGsdntCKNslsjPZkDn3j2ezLqzKHW7Tzkja+svl9eF1hyhuDFVtM66
pLqYPngWxnebZIzyle0KV4gb00HWMWtYeiK8wGNjzhy0gbfQ5xfDAdM7/HVLCbHVGvAsPSfjkzYo
APwHhOFxSxTpJdi93ShauJYhXWdS+uOKxkGc818r0Yxg73Y6fVr6KwAI1c+r5BLAfDkujlR5TRvD
mjlAaE+qyPpN3pRCbi5M48j06OBSqAn/UzSC4ariks7585AflDDtcOLHyEZk5tUNzRd8cYSxfCh3
VEWg6GJQfksS47iDfPVuOqNcImwEAWw3RiiAdxyahEXIYHRqMMlEQc05ilttWFm0Z5dWsi/GM82o
9mEFf5D/goeNC5RtxoiCkoWrYZSJ10ywfdVHcxZm/8YeFqw5KZ3ueJY6MJ87CRhQFlZOL+qA3Vp5
BCZDtbcEhjCprXgWIb3LoLFqssA0phIFDB7sP2ndWwCwMfbQ0TOkl3K5w6CJramlbtq2VUzat/ET
O6KCVvH2HHGndL7S1MSLBQkBNSF177pnhBcDtLIBEwNRxwaV13g662PVX822CvSsHgb0+RF6FiJr
0NRSjZLDedBTKcy1zRnPtTOq5HMJruIyiYyhLfnhTjhWF+5w/CE+QJB4v9mqjXYOkHhCReiPPmA9
paP7MaM6iysja6jrh5ezmQenFM1r275xxY6NiGs2g+sVwA33Oxqq2p6ZXTryIJI3fI0P74dmhN9J
7N/01yi/v+LdPTCt9va0FOBOZE3gS0UdPs9NzfZtH/GnlPeDvOx3aL0GDvLeQxE5bZGMGUoGN0WH
JYhmYzfwZA44+inMyFdXgH5I5X1pwTh3IKeE5ld2hZQs2D+qenjVcUtrb8x75w+DsuiRWvp4b49W
MDWevhCcBnlnjsbNjPHL+NThDFqnWmqRhUk63+b6EvxnDFwEto7TtCQqxf4lMJihBQuQc72w0qjX
agVgA14M2EKjAZyCaTNLymzKKJKXIqodmK7cfs8KEYJbI0uISy+ufLCB/yKU4B2HRH81NQh7LmBZ
