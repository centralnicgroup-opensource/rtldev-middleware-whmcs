<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr6bgDmnYn4Jp1Sz/m9sDExuUly65Fop4yWEuHkswt5KZwPQvrhGixhe5iSMg5JlJ5QRkdRA
bbJBV53bvT93Hs/DDvCTyC6JzlsmuX3ZutkznGAfMHqcC/tIhbnUM+qi1p8/v8avXtJpgiWRp3Ik
z0kCAkWEsfgZmK6tMZcPIxrzsvy9FelMQlrtD+IPq3Uo1Ioys7seY0w6hwTDtOmTMb+YjZCiEwp3
RsewIe1M3dtMnOlms/VaiYcHqDNe9ymweLpcxigD6dpVV5iY+qGEdJ7xGhOwLKfmf054Uv+TFVEZ
sysHAmSQuYsNhRLIvO46beN3tvkVZqk6R+wnAqwrIw2SRfYhBsAFrXjVZyv3ApWXRFmiOYeDuWrf
g0Cg3vnjHjWZ/cZrbmepQdN9TyrvLkfidUFaqcLTlVOjzQzt7hutRGOL5v1zHjFTgIJ7Y4wn/fXm
dEjwf7sXWMs9V3dXqWV/49zKOLNEOzd0bMmYn7L9skkY5BwFaPLu9JLEPNg4uCu8nfL2Av4hS78d
DhwnEKclCMq6PBTrq77xGQA6gS/wyGkTA8XOlHGvxbiuYaVkd39vtOm1c3B+BJdhhkF8WZNLK0Ci
Kly2nLIQzcGSMxuFaYZ4GwK/sBDuSrb3xKKtEOohvbyze4qKgtrUOc65vBaW6ApB4CghaXZJD/L/
NLblIBVhy+4O9c7xy8HooJA5FzJLHoJbRSLqbaeFkT2TQjPldsaZtpS8+absoOZP4LPvO8ZB73yB
yxAXMbvOlmdx2xY9+beuVNobV9qXAA3WCVgEj6CYQD48JCG8Gs51i4QdVLAK5TlBkTKrRbdHVCF0
K7geI86sDeARXPpjXsFGvagq9KtzRIqAaE6nJztTIZZNjNEIP3sj6sktv1AlaaIjPfEO2FvX4O22
6BARdmDD3urXEGLyOSBjRk8gFWzRObi5KY9NkTGNKSxGJj4d6aLUM6wOCzRQKBryDHEa1n5wN8Cj
Va/GnJyCcKjukKo1HVzLsUWK7eYvrrXmFic19uZ3jZ85QmBx4d9dSRXZ4heIE9G97dKs5oYic7n7
paqvgTXHae3v5j6j+pgZtFEZPcILmPW6e2M53tQQKRBX6D9Lj6B8Ck7dtj4mwLMKl8zahbU3OmPo
byO3bHr+NfAxka5oSuLvrrt6M6+Bjqr52KQ+sf7q/M3dn1fJb96G/NZI5INJ090uC5U5tiltiwgu
9MapeIzHDxLscShvhE3kx4hn5pcGaMQit201FrEmTc4j6+wtWCGK6tVAXf1ErYc7ttA7sfNcxPCx
MRwe9bl2cCI1Abuu2blTGACUCWAu4zH1C3r/y40+o4nLYTRCrs9PLKzsY8va93T7lrfPFztUE5gk
zuZshWm6bdM2iomFYe1sYSr42wrnw9zcTbGJ/8MMHcTE2awibdINvgDSGDe0eOLAaAwBGjOhV5xX
gqYnpptkou7nAZCjco8GxwO1d+FahQuVHU4TPzQShLAKA8qKZUTbAcnz2qhXbwo70DC2duC2Hm7N
r2Q3eFnhvVMM+1fsjtjBYj0xw0DLyawNVEv55cZ2rhaU6KLMjBbHs7+rC+81BWr/fjtthNoVom/Q
BovUkqPEjzEnNei+2JuJIKxLLmvnhGzmLxFLJ7cT477GuBEPP47cnFS9Douny8O/YKLrz6K40ddM
6TpFsjw5tYCEfvIhHGudvszL4qCrBuE30pDGBV8Es4BnbfGCjxecR5wZKP0DmZfL9B5hqH2fQxv1
Y4z4cdFYZBTlYJr+RwOo6PpMJvJuLMbgUmFlrStKjry4g4zGCETNzP/kxTL25e/GRp53IpeZ+gNC
ZX4WofXR/QVsVLVXHrmucqxHbP9cKkaO/OxLBM/PBK9R+VRITslpJyGjhEW/Kzy=