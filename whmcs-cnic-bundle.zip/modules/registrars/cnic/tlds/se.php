<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtwOaMWNP6fFxYe4Ix0INp53b+PYIFVcdzb6XMZ3c/amRgRseD8HQsvnvBsP/SgRi9ELFjMR
5F3GfniFJXptQGBa4Pd2dEGQr1klvGxZBq4L0XrIQ1q3Zebog1LaeoKrJlaAKrzJ5UEGhGy4pPHc
0XZqMpAz5oEp1Mo3OPgm5oD49c/iy2eU+IgVLZr/ON6ghXvQFiupadoin4AH3Y3dSPm+cGGe5jrC
3qRuJBhVGEoo+ZldcBFOIQQMcN7dQB6aD0397f1AVUNIV3GoQkiop72b5Vcw6cJqUh7+i2tmjGZQ
1o5W1pN/JRHV6IBtXX05FIb1Z5cvtxqILmj59eS5RsDP6tZBEUoZ1xxyX5RKMMlhkv8UTfqqMxQk
OFtYH9EwiunDLc652+S0CJHVeLYXEajpGNXEcoE1KE8xoPChj5u3j5qoex3xUQCh1p+tHJhwfDQa
sX3qjzj2N2OP+9tDdF9cYAaWoMCdQVumbFlNgyCAm1P+rZGqIqV7OexOnxcZoSPz742Eu0qsMpEV
2WTZ4JE1N/9BJXlD5f9OyWp2u66qp9FJcvS4Xx8jNVxjEJ9K1BSivMIImZTKU0quX2ThoHPSHgxb
O9/fzFSDeJF7iSjLbx7BOR2Rpnj94UDMOSrALi5CFL27N2QqnsPJUtBcpHc2Y8zDBUf9K83wm60x
8A0TFeUoSAhKqXZFyY/u3foFLxAFjKx6pDTc5q50Brrfo0dRA0YegbVPVRACmKrMjPb+vtV1z1et
MwYchclm5Tb+sIg/8tMK2nY6hZ/JAItu7ulPx5qgDNK0HhPSrqIeOkkZ7KB9V9J9Oh6YLq5Z9+sa
KGuslWtj6AnAbAqSK4hj50TrACVBzWSOD66QZPJQxtpmNEVTehEAjRVmBGonbDMHJ/awko5Y/wfS
/Bgy/+Sty9nYsOiSM1rjl0L/mDVO4f/J5tqtbyLa9Nj6Efk5FqkLC4LIiWK/h6fPsseIOCvSOjKF
+BsvBkG0tarEbfDqBrH7KAh4avIvlwsd7ImZK5tG359Sv9f+N9i4Hqs3vVA4Szkg4KerPXYVaHGh
qcrub7KkQOktgp2sT4Jc4B3B7Hj00wF8RcaAv2cTtkPQj1Ys/DQceQSzReTNMkFuonp5KqPePdwb
PEbMxPcwQCMp3JvPR8QAuJOFYaAYiyXUu0h7qu6OK3+8tmwEqtHQ2xv22gEAAUgHGw7tpMAc5uxn
Jbc8A0y627YFuQqgMIl95CkoU/GNTSQbhn/WB/PHzx5aa2e6mMgdov/hpr90pt1ENq4uicPHI9Hu
+eDFUvuPyun1J+hlKj1r560g2gn5h/wvQ6wJ8gwQTu92IOuSQWlD2Gxe5sXA7Ejqqn9tUPLYCZy3
8ov0G/8DW5lvtXc1CTqqrFJPJf0ksdK9pWU9V6AOd9PiUkANXLinPDJNcP1vJa49wNfgjFSTZ+et
OhY+zzXGjK+soA9VzaKla2w7y4t51VObc3w9aPsQoEf2MT82w7gwbI86/reQMzVDrBUy7plW8qsI
7cs77wU65uXrdDXRI5mT8y4TZ7N4ZEVXRtzOJXzmjwe63IDl1Idg7Ryr19PwRPRtPXG983CrW/PM
y/Fs0sAReIqA7uRG7xQNeIUTNsaF/3X9216OYmARh0B7Y3xJPpxSBkA9L4TDwfQJ2XKqpSAXkeKi
Ht7F4zvGVp+sO7CD6KIPhcllfnLnwjAJ1erp7fL5UwG9J9DOyBBnhS/+snLJKNcuNZG4Y6UmbU+0
ExAry/1VmjtqSijqTp23/VtwwjTPN+8NnDA8cNhTokptFitnQvpumjWMFmYoraghToKXWr4AFXPw
T3/1WjlskjPf/zJJRXr+DH6q5HnKcbJpRATy9VMzktdsapgv4HuN3O6XRuM+7wgbepd5RO+pEaOr
+0==