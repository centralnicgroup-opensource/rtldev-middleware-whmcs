<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPutIjFljT0tyw1eXs5yBQ9YvkrpjZJ+YnP+um+QtwucUYBo023cS3ircP2AAmGN+uHBAYb3x
vwLzOvF1J2Z2o5CO+fohHT3Pnzy6SFnuhvZaXGPREji18uDBycRrBIIK/33XP48E2WWBw8pg7tOF
awXXFGvUKTgBGzEwbHvwkbil5d1yG++xlmDZyAsUoSs1nM9JA7vakiuwFJLnEuZdKiYzvH5RmMgK
rhzYroZgOLUsCOWMFzNZYDY2w2tstZa50MJDAzyM9OqV3uQwVOh17D/d/99iMU2m4zrM2Kjc5Ktd
AuTX/r1fBa9YKL3Ux0DBTgVMHgaKo0B3AHwyCoSYEGwCzPJKbbcx9WkfBIlGlvotn6HhCPk7v6Rk
kXZf5DJ0veHZyvOHStemOXviZGb4tb0t+uaM9yVU5L3lid1WoIxMIxvPs304PO9+iTHZVadAStUZ
TnGTBe8sTzVhWUZUdsrPSB4cq0r4+wjpqdNwAggnhVGtSMK4I+q6313XUXXoTU4h3WYDQ6W9b5I2
M+K6SdP2Ec+Rph7HeghPfproNNq5YAcFVfTz3NK8ub2XXHK+sqMxip+iqZiaQgfkjuHZ90vUTMJI
EDImukMv989y8qZ1SaKeXTvnKxUdIXKP4zWoUCMtatpmYj0lP+TeRRgu3a9esq3xw6uLm4gtz8PU
SnpFIlkLqOrkr1cIrXbli91Wzzfmzeeu/1kh1qPR+CrwJqmI0pjC0n36nER+tmtPA8OEZ5KcNBQl
oM3z4CNofgH1uXh7WJzBViWLXHTkGhNUHe/BTCkVOcQ2eFjW7Kh8m0Y4NHD9waKbx4ifCVaXHMxa
5HQhtz23n9mqPYlxmI19AFFhQbG6wlAGzKjgfZe5O8YD7x0mjuqOFY5AHvBpxfmxI4Ba1s4MpoP1
UdKBm41fyaOCAv0fVsrsZAApK28gvwL6EsPdbVSpvL5i8skHrkzLTqAbfSJKd1TU3Wx07HTBKphV
JfRZiXvMUc9E2QPsLzmP5o91hoUyM0amkQNbtBVow5ibHyhtNEvFkch1P6rM4ox99LoPv1VvkcUX
oE/RUzvfaI7FrBRdT/fbZworg57BsKBEsdrtnZQlptg2A1lxebrKNR+ddxzasuNhU9fO6vpXLfCS
Yjhr1l+t7FUZbGkxIo4dChSfVaMOS30fpTs6zWmRXt+wHHW+4HPWoFt3wsggE3lujOWx+YohbND4
2FTOg7afmScJGCGUi8pRxQhI9+30TODJyBOvNRo8B26B60ruJSd+8IgSLRHpH3q29KoEht3D+iZk
HqUAhiD19S6Ieo2OH8CJSTSr0rsP5EsPoTbXT2NeDyltO29V5BWa/o4HctT88z4Et4AUsY9nVzs5
pibNs7r33fC3frwv3SZvDCvdI9E3nm/1doDf+G+0Uv/BOCKr5Az4/xRfZaqE11mvMqvwGObXJ16m
G0K3Mb5dc+ylHI2doq9NSqtX17dAQ2mhECfx5wDj9psu01Fi1GRRT+iTWxq3OaWrpu/2EMTqrkeB
0TwAD8tr6e9D7CC9AaguJeofoYVTcyyEuOtixpGucsOD1EeOzgWgLiI2uweLOjXflOhqIwheFJOm
Vi1eBw/yb1e5wnuZSmTAAwXH4B4Z1sa8SnO2Gy/Maee0/2oe9hb9Qy/grWI3X4BHPy+7NjwCYumM
7ywjJfuuIK7dDmtXQzbk1NzHkBCmDBHFVpjgNZXj3EPS92q10mbb549FnGgmhgI5yg52gQg2X735
zxfBsmtzwH8sxG4zDvgX9lX8h8MK5FI4yd9OKtMhieuljTO5JZ7fNIVGGEdRcrX4vZ3LB+VoymBQ
kEPWjVr9/CWp40MI75WpAMGf2JhA72YJmVDwAU/B7XluJzEmhTHKXF+SLSD4bZEhCoCj2q7BLrVG
V4qcxlG74olN7uxRpcKe8hequWhBodZUxGmIOPGsLwneXDPdsKbiMyeRvj775Pa50+9KkDy20K9A
eoSW5I1pMmOjZQPZ3o35sH6C+/NzLfujMdzNHuEK1GsLWeVqClmfVgdkdCBe5PtENGO8dtJIzj/2
rB+wNKGplbMIEz4cm2lkpiQu2wfs1b+mEz9KJBJr77K8Elkd5wZOYZJrdwbKR9SeNHA9LZsQPNjJ
cfyZ0yDn1x+xTpVJZUTj0uAnO4hZho9CzE7tUJ90blOqoFL89+As+IWT12Nn9mvAz7wghp1iLPSo
jq9XAHLUNftLdDD+Q/CYqL3kOS2FFuftHhYSZ5DkPX50bHHvOGiB27Beq8dyZFS1l+HXa42/tg/A
wNhWfR1SjMz2pJwIHcFC8f3pBEm/f2PfkH9xn8eTjQVR1Zktbj0ub2bEIwA2KQkr51O/CYjfl/OO
6z9XocJUvAPQjjxipwvpXc0ol9XjyWziPBY0MgdyLdswBwD1t9mXk2DmBfuO+b+iV10Id9ne5cPh
PzjRKdM6MADg89lr8jT7nky+bcnQagjCvA522CRo7t+VWQ9uHH9WUMkfAmKpXDr1LthEyXKrqHOA
fomuii7dINJE5vaJhkE6VRapmBMXkzfD5DZ9/mjvGgWFPAuAnNiAjpC747IHuTEpBDR4v54MWxPk
hPg7hkN3QxZgu5RheGENgO7PiAnewO5hDTdAXLbyPYS/y7nie+S9elMNCl+rifFnkh7BkB00PyVL
w4RhdY8DtFmj8ITt/WTfWNXfd0klJUDuLfmoTj8oNJVr9xkIZSKs38ybo7UP5v16orZXJdN/psLL
8qzzg2fJ4wTuq4668gV9vG+e5kapHjihZQyxAYXEvYLjhDg9mMlj+lNfAR/sMEL7EqCwyfmbpXVV
UCbrk5QP2V6ybUCSFN1uwc7zkiSOmpOixnEh+H1QAzuItJ5tgw9smc3llpRkBiFq29g5ZX6FJH1C
TzrOuc1MFsVMarysp1D8qMN+hPRJ1RsWOgz4fM9UtnaAzP7myIXMYOyY0oXy4qf0AObEKZsMzLLc
AQ5L4nhfsEhy9Zu3KZixT8h2S2cJB4oolRSB8LSxoY+8Y0KgIPa+dl3b0toThP2FDq9gP4B/ftOU
QXT2W2Z9tamf+rxkhHx6lMPCgYsnAEhJ8l/TU1G6GoIe6uSmBxb+5kvoeKy9+eL81nmkIAc8JwPc
dJwaMUwUaI4aEHshO8mpjj28cPQ06UPBrw2hQmlAQ9O7nZea17tY5BSO7qbLh5npKFSgMPxiVK4E
ZYVAjQ1fV1yqVFdREH8SSP7taXF4J/3+xsFmZBBTSbvCk4mrJMrxueC1IJiuMwXkSWOT1Uv9/PM4
WjL6UEZ/mehEnp4r9Zr9IDzMWDQ51tnhSfxQ+qWfHTYbVTyYa6X/d9I5EL80xdDi9jzebUYUdyXR
MaUw4KZ1CRrIHqt7t6bzYqv2pXq/h2mQ1PoOn33x6v/VFQf8TQMuEirHEqqLaUryju2q0QuTIUDk
bgsYlHQQ1hlrrDACceTe+mRqTJfWUSwT363KvaT85e3Y7agCkmMaiUqgvp80UkYBEMlBMGjXueRN
HCWKQM6DByMSOGOWg9QTQqaHa+XCDPJ5lxriqZv8xaUjmi6924AZkNau9VKSRQBXPJ+d7JlrmoB1
0MchoGIvVKZSjQ48bvS0KGabkV+DZ7Z2XwH+EVRS+6MEHLrHiMezmuu3htWBeHr4EOAczwBLVcJV
T24JfyMWTvPF1uwjdi5clFhaaDv7lhoe7Zk1SXEDPLSGITBcg3ruPwoyVSsO8p1wfeQ3l5CLNw8l
FqoARoIvFnhuXHOGBD0aN2kPlNJPGvM3YgZYFJz/LJaHWUXeEPILOBO28GUMzIk0GUAPvdf8jKdz
9Vns+NcSWxnuD/nVsSTemWY/a9/FzmJu17ymlKDt4iEqSbyaXRyT+NLwduOBKFYCJRd+9eM28Bfl
IEUxuKZj6kSmiRDUcfeMNRVewp+uQTlrqJYhEp9wUBT3ayq5p/TURinMRFJ+c9mBfR4needseawY
OhC/ZcIfC/qmNNwbUc09EZPvHzKNTniRLLQoNTcEFHs4X85rCRKfwYS9lLj9gJ5rYNBs0POz1oxT
2BdJdV1BJL/N3R3dCRaZ7o44xTbrKlQ40xgytv5Ywj9A2aTcQNHjXTVTqTHrfLHW688=