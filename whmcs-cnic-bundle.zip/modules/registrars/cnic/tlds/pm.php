<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmR7oYv7Wyy17WzV3QRAHihd6VtqCO/yzvwuxo9nu79BaR/pfTolcm34/9XiNJjTiPnEPPqn
dCzDSC91YkiYUnW6MpSLXAWASLmhjf+s90SCXKHJpRL8xsiow1I2QTDNj1x+ss5d2w6XJXIpLQPh
xtq/LSytwmbPxQ6wLHZJ0WfdtLECm+AJjNGHVhc1Zp1ZkBGrBxl9/esN7WNkyjXLidWGtG/YN4n2
BN8Eb3qOzviM+hk9as/U5QxsgaHZB+VIwc40m2YPmMiNznedaAq95AXecUrcHiEbPOvj3BSYxTUs
gGS4/oM3b+DUaaOukuTYk/F2U/iEbPxL1m/ZWExeqXkFFeeXTiB3ZSLp472FcZjCBa+tz0SLDeCp
wj7VDClgsfnmeahXjAetVMAwIn47TKfnoGzj/ZPPyh12GysVVEseJVg/a4G4H23wSaBdEHDhQZ2/
RvJgccNY/G5hg7HFY6AmXq0Fq3sSfz8oUAomM0yj1xAIr/h0dJH7gt6qCBkYYEq+Jaw5ROdwzH0N
0IJdZqIHCFY+/x+QgsnNoBadG/hYZjgB73Zi20AVNmHtCojrytRJKNFbDCxWqwO51UgeMK/JVzw7
eCuM0yd4l2T7Ws/t9BR4nTTXrAGo2/d1Q6vbmhwVa4d/9lKmx5vIcWUdtiFaw4REtayukDothgv1
nghEGbMnTSvZ58XbI3SueQ+e/DUYqgWPB65sllZ2QEh9tp97ezTbtDKB3N9H2YEVtTSD6vUywYAJ
q1iIIfWoEnzsn6MqFexM6YTtus/VYl2q2QyKkv4H81i5PYmWXAnOeELl13GFUGLdR8d9dXK3pW6T
ZaR/CQoanxIsaCTQkVEz4BeJmBm6cq8jZD1X2PRHsNZiFWpeXvreRngK2zWN0BvCNvAZsXDKluJj
Y8LPykZxrsJCVkGGzPPryOp7fzKiL4GBZdikyobP52Ux2Uzs3LcsZ+HV6AK8TjnT30mo7Rztzlmn
EpflM3Al4QT1YM7OuAmjbGK5WnRWIpaM7pvD8CmqZKdHZwpqnnY9YcH4dqbTR8yC3QkmuSJ0yfXQ
5JVDsrKgP+P3ClMMMXUIrxXlUHu7LpiuoMxAZ3hq5cPNZs71RVh/PSbBksb3WptxW2cb8MqnLixk
bIL832Tvq/zR4dT2Re4h8uYM10P+hlNObIU4b5Y0/O1PSgOqDoqb+lGvFw/by8qdMLiqoJEBmg4b
JvzEh9UoO9PFNKLfPKa6Wp9Xd88oQc9lnokbw/j2/wIdAkVE0HoyoTj/luUjvCbBB7cIe3CCA7yQ
PslqsQbL9APDCTgWZxkdWUhVKDfYKi5gZ5LcAQAVGyYaRf1S6oS5krjKfNecYJ/FkVVpCw64mmbI
6QB3tIFThXIumJRRxAX0ibtEDoJhtK1ilQyctzK05IetIKhrQZLQyCRCviHvvtmBishsBYeE7bnF
40bccWgPoV+V6bHEJK9LksBTxtP+DUaPsEO0aK5k5QIktv20ysutCptIanOeZ9eZFu2Zh0nPdzT7
C27JvP30MOIF7vo0XdbNDL6OzWSvJt2BBYf/SVlMPfYuvD6jEPwWd/uku4avFkQDVmhNrHxBgZ60
m23OjoCm1jbjk5AObxLXFu1tf9ijQbgYOoE2czyiIdqFjFeOe6OoQgRX4bH3KMSo0wZjBxaeE/1k
92MjZOmWukvLxUEhhQPphw3vCjXDY3hILKG7GkH/VcSW9xA3xZXiVvxgqPCfP652dXMAIlAv81l+
v3U1Gm9Z1XdQFuIDzMboDSS3BeMZt6V27VQzOb7QPDp2AweX0pXblZhNS8F/bWiLOBVwFGF0eVI7
iYVmALLqGECOJSegW5TeXQBcAImnuPuj/Z5m51EdmxehSHvmsy/RCmi97B4I5qh5DbZAWdlyiWvW
qpz39Nygp40MCq9eAJzQNhDH6JkcQRaXcrIEWXA6Vb+6hpsoxO1fRzC8cKZ/HnN4le9lARjQmU9z
z21xlwsNcgiXBDKl28FqvY1XkDG5XKzx6jii8rNiNcXc7gsOe1sE4YkKhbkYsn8Qk+InaIAuKl/G
mYsLTDzjf6qZU5D3GXLFfnDkOVTxzs3WJwEwlfVKvtxOAjBdzFzPYUJGS2zNvC6otnq+xLUP/NXX
McJIh2b6I6GPAubkCxKd/n13f4ZGwrw7E15byE4C3e5wX1J3Ut8EWcaFHjhNZfbfm1Rj2AYJT5Dj
mcUhRpUlhOmasWc0hi5ukSFK1QfpbNp58PDGb+MO+RgLzixBy8QYdC7gmK27J2CsS6VEyGo7IF6M
aVfDvqDiLVM05n80S306vsXabRpWFMSih4+6QoaIaMLhV077wfe5lrIx8VSjTlr/waMAkYdh0sSz
qi+dgIBhI0cEIPTEAUzLHTX2KVjSXah1fpenHRSle68foZGdUl2MZmjO6HGbJJ3USi0iAKIjYlhH
+ESzuucqu8/zp4QNK/hZERgWyA3GX+a9Ax3EjJGdnHswA0X48Ojk+f4Q2hdlNCnVDecTDAoX8CDz
KoZ2EoDnEZ0ktTkqGQH2izvunP1UT4bJUOkyTMRmMdGPzfgHjzmn+Q3eHubCvMN0vnd331LirK5U
PakxYKr5Dj/KTLkgUvXbmQ6rGZkQ2FeDzIu3BseIc3Ak77lntfEWo9RhlkLme2ml69BEPKrfrFom
KLyoqeEyMUnaHQ+kU3kRhmoS6JyrqaPLHFzk4N4sT1cEtItF67rd9mK/YjOQPLKC9lfxqDVyQwpD
faMwj5wR2305dEL9StpNhGyHo2OAUKo+Oii4RqUXQ3qHecz47RQAUaFAYGz/G8tieChv5p9BUuiH
9k2kDStMxAo80yqaALFQ6i3FUPteLGxOjsSDLIRfD+fHhT2QWdebvRdhoy1OAl+r5F+A5rDW5SN6
EYx46ak8zUvZMM0Oul+TNxsVjFP1rU6ecnhgKtG3Mp9ZLOicQWWx2DsPn1188453Xj27wHvOISZF
b+6guJ3vIkr4sJICsOUMG9O1XQTJH9Hipaav3EYs6EkpUwN7SaprzvoLwBbt9OPH0mm6bzm9BuZ8
1Wn5+uVTBBvZg6CEbXdnXpyE7zrB0YcC9ee/eG/JK/xTKq+ZBEVCgj25vrvzrMO16EFTNScvQReh
TFIfsTkXnyDwyw8NvktJHuCVzA4g9u8rNObzX/5LRQBTySPCttxOBTeb2n1jyCF+Dx8Ui7/TfpAD
azSU2KsRtusEK+o+8fupHAMJClT/Xs2ExBmskM1rd9/sELO+Pgz5I+wZKTgqQcYBneXqcRPo26lF
jkiHyD4LTSzCCtB9GBNAPT+dRmTx0gRay2wXifE73OVSWefryLzJ6rjxpxXfKapcdYLfBqUxCio5
DZfBrk0Y0MoCuMcRcl+5LPL3hH+bzLXQIg6L8VnfhwF/wNEUj/HfWhUgWUvXxKvZmkevdpE3h8oh
UXHk0XiMK11HVaS60/GIleOJIajwcvQh+mOlUTa8Fk2TzGoHkuJsufRErMvGyle7iwRIh/4FRKtF
dh5SWrs96gmqHRNRkL1wjEPZRBwdlRN0viscKUSUos3l7G+zJqIA9dCreCrVqbTiBMb1JPbTeYox
ZL4P3iPHWw5M8GvaOFYjNEhG2JgTPXH5zozVLfUoSkeO2qoJXloJ/rbv1Ke3HYKot7kTeaCQEkC6
g+bmhHxyaoobS9A+rg36bzHag6MjbhO2RYNnhPcITwKAXFET1/8EPKkGvmP7ISnYuKSqI+9wABpE
Axv7FwHHFfxSQ/xfuskxyoW7fWE4lJP82WwnacCiysUzvNXbN0ekU0ab1igI/PIOq4FPiUwQqFHR
2hUYaJHD7F3V6a+HVG368c3k01JMMqkUL47mxOplfY77kA7Oy1L96DZTup/VZCvb4pliTsskyCp6
kVNfNsHnNf2uxfLTxM6lGohTf8X5tIYPSF8M+IIs9Rz2WFNEkXKPL4L/n/tqwsxRG6rjl5J8HJDQ
R1LY2Ny6l1MZ8P6UmHrBXTjbPtlyz0KCoK6XRY8ppOczIbOzrj7uwL6kGnbxPbGtJ1W8NNnBWKYc
pNgcXt9z8gLOnpXvy1/rDM3F8BcMxuqI4mIUAvhABv3wMzuW6dN3xyDxNmMlKlVcKv/yTWCDM9UX
Tu6OkW==