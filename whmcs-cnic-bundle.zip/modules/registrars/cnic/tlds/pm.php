<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxL8GHxL4hfHe83KFUy8HP+liwGollzWThIus0zfsldWHi9aDVj+/7xVa5yrkoTrbMA2/raN
67CdAbpyP1/tcx3K5DQ7fJWibgKF6Q2gt0OEqUoJWgARMGrANGjRL84uJ5tEZjy3sQEO0j+Eqy7S
Uqr8IBuAILrD8U+eG8FDICnOZwIuX3VF+tcsKIu4G5oVM9N1mxk74kwKtak6CmeFbiGbWCzaczXI
0FO08+u0WAJUpnEwb0O+SY8ggHEvwgx8VB0A6dpVV5iY+qGEdJ7xGhOwLNPcNKg2jGL9mdUylCq1
+iOG2xBuHbC4Ls4CxtLFa4mwynOto9hdA/bNOuuRUonsUmI5JYb+1X75iEkyxN9hQS4UCat6VOn0
jkBWeGkrBrRFUn9JA/3S8XwY5O//sWE3Wh4DRy+OBUn1bj7VpoZPV4VB0GKSIp8zbV+fRucHx8lR
CQShllXHv5qVg3YctavcCQVA4fOjaRl+bEZzqFlVB6wzQdgvKiAHgr1CoIA136ehG0FrD0Nb61hH
PbuivG0KzTeS1R+EaOlVHuXcROtcnbIW4R0twcrxkHQJ4pV1ND7OBHsVts2XzcqD8gxLKQg9KZiP
lLCQeMUfsI+N/fIev+h5E/i785C22c3uNs8M5e7HdXRcPZRXlXmLICP6H5+M12AQwEYpQBar2E71
DBvjT8NYna1CfNiVbCu/kqf5PQ0SYs20OM+NY9iKKfW07b5mbtepHLDRHqdry1XfgStbfpvVyfTR
SIAdhbTIZxSTkBNceTwUrldiJrFlbV0Q00QsMN5fJiO1lPhvuAxGrkNPnrw3xbO3TD2uIH3pqTg/
ZvYGD0tXh8J4CKTXQfTzBoGNyjA8ARs0Yukw0OtOCXcuDfelpUGBXj5wqMOu603TlSG0OzKr3Ys7
4teBw8PXBq63lPR2zsgI7J6jiIy7D3rLrO3ioVNv4felbeK77K9Ry2N0ddHnh9NlaK1q7DsCK35v
uP63M7clcvyW9JfIK2q36svToRvcWGhcfr9gGsGN+N+9hn4BRwsJgUYpVKoRo8xxWMog0RJmJd27
StFZh7IX6X6hv1uJXS5qn5d7mwkA7y21Zb2upVljZg7f6WmS3p4RLq/E1+mCLUq/qUtarQzej8yo
6hlljnJqCD+6qphhgGpyj/1j/+6aCkcW0LS/BScUhTsMvT3Vyvk2NILfYub7Qjb6Gw2i/gVnt7vw
Su9n3zNLyD0vKmECJ3F9sAXP5Olqp31qQftXZOpf/sLGsyk47AhOjITMs8KGT+rTWvj1KXJyCUgg
dD11/zdADECZQta+64GZD/5OjwntqCM2oxPymnUScuipVIDBtenaJni9FYAiYmLF3NcC3n70mTL3
u0JeMvwHAuXD6woQZPWwPHiJURpMeR+PEkXL2yc8Qs7l/GmLeVBnI31BxaZgcol3YUDo2+8sxbCm
DMs4mypOaXyIFcvDBKU6h11lkZwRUp71eu3aHQxfrzzcNgaW/KTZUzpYbsV+1GHJGUNSe0ipmu3Y
xKc3sAljpgC3KfsORQIGadblTMIV+osX7mI+KslcyMZfBJ47FdqWHFylqE4hC8WxMiw73OWW+oN0
Eur9qL6w9K9DwUvgrw617wwQnucmFxLJjMJxjAr7D057YO33f4UeVfneWiIHaMYEet95/4v330rP
dIpkNfHqVOUOjOCFKkcRv2ttD+crdo4s83cLCXGMlbJsD1yUijG5sm9mgNp4FwbUXg10yBWaG0j2
hIRz4gNcm4wz0mOuokDyng3izWDUWG47Q8/kkg/NooEHolXvb+DmMx7weSW7+nUmnNbFy/QgQuW4
9D4ReJMMY+w6x4G4CyxneB/mMXJufdVbmdcJWVbMRxJFKDUSfw5eh+46vTv+Q6x5pjnS5MBVQ22C
jakIE0LF4soOxHobtTlbXzvhNmX8PGQR9mv32lT67MCmN6wqujVas05i8K0vmNUZFSuaovF6bzHl
8Qu5DSTLXi7VCV3XdPMAiptOkRYONB4Eam4mYpjd+bUT6O7p+w87NGt2HWJN7h7Oar0UJAcx5Gny
83i/d9s2cYg8TJW4erLdtafaHV40GqVxOor2c+byhbaaR4KLQZC91WYFnF3g3rBnCi8nPGgxRt4j
lZM3ypW17PWc5i8DwmhuWcivbHNRfIZiqu4o+YSciFRg6ZzWuRxHDCzJ23bMNmsSrBqdLlDmmsED
tENh+APMp4hvh/73T9cP2CB5J4K3oQhgFL8F7ARdXJtLLOMLIfEcdKad4Pfd3+aZWPkGiDfi9h2G
6/vR97GUJLfN1rIxhNlrW8iwhRQKmqMyPqXzWd/jP7W7w2yXqcBbObe2h+muxmEQQblnIy9wDeJc
minAi+Ahd5GwisczhZKBSolN5F8kZ4n8AZrBVkVnGbjvOd/HiSe5GEppMO2dWoBy0sFzBVPXkyHL
aRhiPEiVXuSBfJvB/qR4qKhdAe156aav3ntNK0SnNrrqg8bwrkp4uBUjYlhiu/J7TMtTQnyP3flq
ZsNNqFTidR8ziMoeOGAiKcLDsAX7iwyD6w7Z7KR3VqJq5Hdi0z0DPZfJxjB6QsWt+1wdLRsaKujL
QhLzdZCafxW6P/HuiV7qz5rJpdFYA7ptI36Q9DDjBoy+ncvDS791ch44J/Pbufs+JTrenyICXj5o
SsB//G+Q1O02aRliRrEG8+AVKbqj3wwkNJ6r7cIhHR/Hj06cKaaiIhDHc5diWIvXPFA/MP0WtSgp
BGOtk7ixc8EeA2Ljmz9shIwKe+a+8vSzg003aJ2bDvgOnmhEn4F4pu8uoLMKSAZYY44VHo2cb2aG
EN1DdJTM7yY6kECWL5YNRL94gAfF6uQIH+pMq6Bvdk1vYUhmhNlBkidrjdeeqH1T3y+kcZqZy01x
oFTiporDSL4ndobO3ewdg1seToBajs1Af9aGcDCmWd8j7db6J+Q1CTEzPVxqjCydYhzA4xIX1JLI
kHLoaNHkezPaFMKKvbCETblx4alGNv3Ll/64ikZufRXxAdtudi3REa1Y45NAxUZTQ4PAg4o1XXJb
rGZyqz1eHTyPixUJD+jtRU9xGW6HFK8JZ7Q/pZGeV2mJvbownlR5p9HWBS9xVIPET1McMjRMkumV
EIsgzvbFjOcdDeNEV1wX2r+MeoE4Uu6yGv61JJHK45WRYNcccmTiS6lNWZ9mIQU/jtj0LZWpUUTQ
LBe1zE/JchNzytykhc2mQEjeI3xyeGiHCmHmB0gKf3WcUbyU3Tp/sn8bKBApHWa/0VXkZjTVYjYS
OZTLMDDQfgoUA01By8PCe7J1sg4gPx46gk5IX0wD0mwXjseqKhCXWgO3z3yJJ7ZopYN5bjSxiCAA
2daEvk/MOpVwovyaTWDEHm+vtgJLlJDyDTPAOcll1pZXG1Ou3ZM8ixJsU2uNjmHl3CMpqTdLHq1V
RrIyGg3OTiPN8I4HY9PXE2UA90NV8cme6nYiZ7G9Nurti7sbObjQ/5nKQjXDBBVkNkQc/sL4Bc3m
tD3Het0T7OnQUeoXwU6UPneCTzb5WooweTKHrOwyAK0jouosGsHg5rs1GYJV7ZU61TJlDw+4GaAK
FpbVSDkp2aVY6faljGXDALEp5hxPL2ycLe94kAJkS3cKf5rV/4wkRZytkJZ5lr22xp1SYa0hIuV4
phqG19IJ+soYkwFrE8Klmmu+K94Irj8smJBbuG8NbRLhZdP8N9hB1KdgFGqaqOEeJ5xlNEnLZ0vE
YJP4z7dj7mgrXdgs00yPggiXQ2UqcW8aSkxho+ljkV6LkgxRMRXHrLslbbSFCF1uoiyg1tqjM/4N
PkOMB55Ll0+4d5Eg6/VVXjrSnyOZNGIHvAjfnsf40t2x+FXFKABckPnWGiBYgPqjHP+GeKO38C03
azelU1jkz3VQERD7A+7/7sG/pviWm/HT/Yi/WXRKtluxx+eOY12/E30L+F8H6fVwtSxLfh6vJ7Jl
CPKEEm/f4gUaczSt3NKZ472V1afpAHXoIs3iJ0j2IBcrvnhSncTmA64p9wYji6lGfui45Hg956C3
T6pUD+TsWzSFyNZka4nzeWr2zsjk2p+pKlGPUxyeGadTFM4nZ6mHwh1D+eu4tLVCJwE9dB+HnQNR
GgbwvREFUhze