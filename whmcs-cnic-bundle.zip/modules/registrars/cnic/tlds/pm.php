<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+QP//Lmuqs5H/fHgLDLXiAqzlMzqmHdI96ur9mDqtnoo9Zia552RvDS0xXZavdN5jCkCBik
l1vx2SPJVs9kFIxP//TEELlRR+J5AM8By3dKNdZkLGkVXraOoO/pWODxEsZcI5DNnUd3sq7Bj9ha
J31WzjHO+3OQJhl4VvcYtvaMC53g/yYs3qSLyyy7wgq3W1Hbs4Yt5E4a3AGRIgkaGSCl+tFPOdb4
fkXGVYKkgCD5ZuxwPGbDsGiYrW7R6a9nAasEcBlKA6H8ahe357dMXSM94v5g/x/ZHCQY5Wv/pawI
qiOuWGnpUgG1aD/dHRhUgq/Ol0Lwcn7L1o0F70sB1InRWrALucfTpeYp29gatZ1Xh12aqXbTQx0E
1gMnE3dHk6/wFKN1WBiXrrMxqnEBYbdV8LZanYqKHwcliQQvOXo7fdVwFZSr4AeC68up4UPqpu0a
QAXlCVOXDrExvmTy1V18E5aKq9YjD4hkj0XiDBuMxIJ7QXnhvXR97LAjuaYIR4D0YDUNQY3d/A58
bCnwCu2JtXElFuJ4AdQdghMxyWr73e5TM/nFwnN6rAp7qVzJXtfidfI6438ql5eWS2OGEqQZJCyj
24Cwpm43WNgwLjQr2CEajKb9Lvfr6A5qqrtfqjTelX8fTNxt/rHglmKI/SdhMpruJfzux0Zxy94+
vltFP8i8h83ojG005+6FGd7iQMO8LM0UIGNRgaCLRlSxqt4Y92hbvUmEqofW79KtgPs1hCS7iWek
CbfF5uHp/dHSqnoeU/AALCFFS0S3+qRujmgv/vaWnvGsXpOP9uhkS/mWRkyt9MD3yj9ESCbPIQ6M
u2rBLIHC0KPfjc6GkpVkwO7B5Pdg2MkKSp/6xEo+tkxiSKvmeUpq6j3mBZgrpfTINMJORhkUPZ5r
i0m3VyOD6eTNytFPsQEdizBSudI42V76LaB4BRSOFjht1ZTZtUHZCbn19liCkuEEmH9v05vLIT0j
15kDyQXTbBJV1tcGvBfHO3ytwHdPfFhkgYh3n/23smzTTykcJ16B+zBATOynnZUF7Emfcrrr1Rr4
7601MBeKR0zE/8awRAf5eP/qALuByckhhZVh5L3cy4xXIymgyrjfM7+ME8WtkikJ2epAyQLfVapa
ECN6t03AInMW6W8V6bdEUKZbaOO4fZtAcEl97rn1Ba7XOcKzq74+G1z9YXKbRASfSCg+9nfhbyGc
YVP7QAbwYL8rAi6r8qUzEH8aNzSxmx9gRdzwEloB8zknJInbBwkuQMUgzvAz0YS0u35iRXqMPTsf
dtHC79jwHImIr/m1trekahsmI7GlLxhcBpL9fVs1hnQfOPbu8QWJOBHYoJ17hFkmZZQtEWtpstxx
X25NohpweIyFcfS7yVwUtGb34zW5+FDnawau5cXWfD5/mc1cNpgyTaBcZqjmc6cAqgBghGMd5+6C
deASJRhjVYvz6DU8YM083+asUSXC9IxPBC9GfTvUfMJjnQHLp1x9QwoMI8qKfHMY15FzLOVHGoPN
MPGWYIqUJK1IA63gA4gDwH43+D9zi3fTNvsjGcc0aXHxndhUqp3Nj2v7B3vM1TIo3LUP1grm2G96
e+AB0TzJFGehqvHqu8gPUs5VrFRJlhcCAt5XcD/DB/TcAhEpGqk9gDQzEKZ/Tm7qoOR3yWRlVcHu
DE4v+FjyEsn5W178hmRBcsjeryIBRIDW7J0c/nPMyCj6eE+xdkcqwz7b5tYSz54viOVUClAq5gCd
CCaQPaLRnAXMUUpePz5a+ljV+ZTuQFOMRWXB+RAtltECwXtog/JuOa+3x4poGqMxSkDhtkys5Ahl
L7sUMLb8mrxsiNN95xCCC/bYVog1OeTAW3jgAj4ZrKr/bg6IFREWNvEzCwqnu1PDWEvZRIOHl1kV
l0HTYK5PHDtiuupWfinsK1L2amjbb6T16TfXXPcUeFiz1HQfpRjauqunr+d1hi34yeP4jIMaKhRA
v19JoI363gQpiB4vvg2z7EsfAT+7Qea6qptUGCKXkxOCiF4O2wPdQoEek/V9fzKK3L9jHlPb4ZxC
BqcO9kJmCHeXQ/raYbTZ1RUR/hbsBV0nQQ5dxZ90cT3MoxM3cXflBrzAv2p6sMkbohPeoXOnGvxW
jPVDDe9wgAEBnJwQLFu8MMm3Im8W8j/f4+nV3xvRhXrX1ynZNi1aIyzJqB2EFhzUCZjGYny6144/
A9h/r7wceFmqrL5eL1m3JcW8ddLpJxoRpAoZ7aU6Zsquvrnjj99iD2KP/zazN04kb7cZpi5/RB6j
Em3XFVqCb82B0i2sjtpD0znDdpjKhYKSwLpzMkd2gYgKdi9bCaHmEJQNWkcQB90aXYaQPlh5dLKs
va/mUZRWbg5L2K3BjZ0VLeqD314gkrgfr6ZaeIshFHMLzYzN/l/QI7Lfj+GSzIF+MFbW0hMTBGVf
TnW/6IOkSWp3s20eXbZPwvYmEVSelmdtWICU3iUCxjR2yWALvPATj8iczxINBs5iT+qoQRF8ZWm0
cbCN8FTirnz9Lf/Z1Kz/xv48yQi+VO0p6/7xojXz/6KRwxqou0laqWwfwaDJBuCGuUpp65ifgyxd
zwbG/34n2f6cEfDZLRGRpj5pmQ6YJ6Jf/vmHr96/kIGJhe7JLoY2KP7x2dcF5A+EJPhYQtUBZ+8k
bdvH+/ozVrvYAhzmHRL3AbAAJFCEEtbShwXXGv1ik2CIQaS8EgE/R7PEHi8i2RZjauHP7J2KbDy8
RJff2yS+puHRThLd/PuO3OHgT2r1OHSas/8VjdJeDr+47Fz/oVPH3nUdHxvlWxIy0GOQkrv2CMdu
uR/7//Te9WRvdR+lkNboe10bYnyDbIG29gv5B3I0kmPr+DoVjoN9I4fkJlON5x0j2Dx9PBfH2pxg
YKlszWJp6UWsgDQ7G8FBYxMXmX1svJLCswpUgQXudAYVvw6ZjYm77qQWKNIQJ1HVES+BVhi1tKxN
kL/TIBIaGkH/sr6Rtx/ikqrR1hd28lIIxBgu/f/w6Q8AJAQcUrfS8g6pS9vWN2/sX9kqvs7SJXyV
8q6XsQEZIRZQibR5avwFoObVMiauPrEKQZ0T+M4+CBhJaNRwl7a+YCfPn63k+UJBU21f5bzAgGbb
jxb2i3L6e+q7cCuB0MNJQnuqKVle+vy2V5ORs5lE89WWNfXNcVCumB2Ip/2P33R05qv+t6g21RIV
i7I93e6ZqouOffJGeEMacu7YpZdaZ/cd3eIuhmHDtaPWa5fKBff9gOlNJg9J+P6Wq7bexawHHfRk
6pDVaI8bSTXmaRBoLyLKkm7UANmTNg0PK4bfm+uLvsVndjVuPZObkhk5+lAQ466xFGARvHlb+2nC
ShUj5jaWtCOfwO+jDnoSmw88o9/FtvIX6GV6O5Y3xpdji/x4dS/SI9FGddP3AQU2/vAw8WFy/psN
Hcj4yToGz8p427OmS6Um1eYH2nMSGpJKRbP4oldk0DrugNvn3+HBQRwed++4OmgV6KqcrwqVjZWq
N+mzTWTaNKTEZw8f1Wg+pcnSowxQrefaNGvWn7J42PgNj7Tm2fI4RTKAcscNYpzD0O82zK2TIhFP
+UiMa79CbvGKJuqvGtTb0fFpw6+H311z8M24iafSYElWrxcbT1ZEVphfoG9OzTGwjoh42Tj0QP3A
3CrfsqtOYstAZ4ywuXwQIr4Tl/eMeBM21/YGk6lLa1mlYUViiKXMX8otYYKeILgLHSuHclGArBFN
PrUs72SbDuYlTMbiFGICI1npg0+TMH1YslXNL1RmcRZKmzjQoD91vrVPs/LEh1J12S3ozkWEGCQB
mRYetiJynuIsc1EwQEtsTwQllNxIwTXVhYCduW5zTpalA9OTGbpSXXW//aDIOGuuaSiPZHCr0jl9
k6/WJD17/pZAhDJZ9LXxapxLB/1OhVzB6XE148n+B0Bk+W3T7kE7NFXJZjYk+lKrLtB7+lv9juhi
OAEweNj8N89OUym51eZtVE6zGCKBiW3zBVnJ/nas5Sg5lly2LZl0y7jMNrHsssIEns4wqE+EBWTb
rquEyVySSSw2MZuFy3tgn3kgxHK8giNQaclglwDk2D6Q9Trfcic2Ccqjvzzjk4s6azP30QnVWl38
