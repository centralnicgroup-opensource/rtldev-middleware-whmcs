<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm2UwpERIz04ObP+41HAXdKhqf9jaWXu1TKHTk+HceM0bkTRHuTHSKkxg+w/fZA+uSUIvAJo
QNreOicMylZufk9n3YgMP2BC9+a9fGPqI5gMtBsBsLSL4+Q+is73scuP6IvKGkds7mBb0H12QY6E
IT0z6Uoyx2twfQnv3pVHg5J+R8VPdZVXxlcBe2Y42P4liDDks1CHIWLrLNvBPUnKIhldZ8P+Ec7p
VLTUCUI3do0Lyox4OtazgMpVvMgABW7WHuGWaJcUmGR5TtnuCaEknTiC+jsuQ0vE5W3et+C/XIxF
LmD7BV+m79CFCh4kNmPF1Pg9tuVsKb/8VKjX9cBCSo3g/wEK4DIoY79KgDTQG4pb9jz0X0wvDmgL
84XrhkQIPC6Dp9J9ilQ1pSq/p8sQ8jXI4WBZhVNRbdRPbvsAU5BCDfZsa2Z9dViVrowbaupQYyHo
iwpPEsj5wu8dJVQGGh7MvRN1Xovdqo3NsTeNzxwYr1XvgLm8B3WV9QBzR0vck8kfQuWZKqJj5Qa1
8mZO5HlGg8f16j01bj31BsJjMswOdK/zYf8cnyG9keZ03rudXKjj8erow3KZL11Zyw44bwU0SPiF
AYEBVqBJNhS2t3ZxCsotFWfn4dU6xCQEnB5RB0WEwRiP/ncm/7Wz7IJK1rlY++Zh26C9MwAtT8t+
RCdybkBTP1b6XATEsryZOY8he54JFiACEpewHRVrdBpl8GHaw5swMklicZFWvvlO6nJ/wqD8Ibus
kAv57XyKpDtHEi9Q7I4dz+B6R+CifV4WrGQIXm7PWyWNUtDjsTslalkvU2EiPRXsuHlma4XoG9pl
RBVZ+yjm1Kf3UyLozuq2fKkVm/j2oE/mMwXqDTnsquDQlc62ytR8XEwu1AH7bRvX2zozvvtYlNN1
GPmHQKv9qTNkhxGJlCSOfUnQTxhTxpfAYCrbJto9pCswWefN4qPbTrkwRzb1kBVR7dSP/+WCmMnA
l6F5lq8+ScjHcCYVLrnG7tjh0lvOkf9juRbk1MwHB1WwMuVBxuar/fv9iKTGldC8GsIc12UxsGKj
JRuAGDy0RRq/fc629pN0K8UFDCm4CTmEAKJIoMeItqDXgCyGolf0om1NJ//3e+5cK+y6duz2qCBf
WeuEWSPgGkcZQlBTCEks73Sgz+1ud241tYWlEWQL3Gz2PQZHbo4Q9VXFtPXG+VZUc8XvZC0jbYMG
lMgUcnKKJjL4h14X1QJx1QkUFhDU+ziQ5pgihvny9/nJlVpAgSInTa446eTHYakt4YmKBzVhqVo2
rX4Y5xcFmoSwshY40CiHjTUXptUqS8zVAD1kEps128NP+YsAMF+WE+xht5BIkQ4ebDzMoGlLwYfv
yDV8exPuzyO10ihXZ2gCknnl7Wiu83TbJCD30A/e5ah0END8H90YzTqODcuSESwh9onBlAro9zmJ
ixqv9dFupi40Cj731jmACU8cuun0k2CHAEieb+0sKJi4OpV5J8FV4DIIZA+6dp6Wz3V+1Wr57Ta2
/dnc+5AqgDKcXjIxgZLgULM6VqDSWh0zCjTnIs2VhTUSRrck2JFEHOp/6xD1fJvPnheAz7zSib6S
Z5iqMuVl174dOZ4mbCwXQ1r0/Hz8GAW60TQ2yc42FTj9zI2uEIVsfX/SDDJge59UfJG/aEpnsrHN
NXZqyweuhCHILkDPr5EP7mYc8LXudC2NuaQQ5DrSCHDbnx8bpBexaw7exO7jJyOakwwyaA6quAgd
rakmTJG8edQk4B469C96tsBMLvGY2PSIwOpI9jiw4SvsaUjCsN1FafuPNXGCA8YuwhvJdmzzcicX
L6XPuY8mMJJ9Re0ARQcmNRu7LY1xecWurkv06GQFkh2OtzUYDnsCOOQnnT3ZJt6vQyw/gRogf3k8
vtBLymgmPyxA8PlW1MmAb5z0PniAFIwPj3j77XEUUgWESi8t7nsAfRpUsu4GlYTk5YT6iJCo0d7Q
ke4u26TzA4KGkW31nKpAusbe3MP+XGkBIKhWSO7+xetwBJAcV1Xxa1ERDbu1RI8P2YKVWgOB8lBU
xH3oZuJAA8m59nUVgLPB/uBPHXNJWg5wToBhpNlNw7ToUq8+8YOu4Go6an4C/hOqBf1Ku48FlLRx
aLHQmZBKHnvyjdw92qsNBcJKdZiGMPuguQ37zTFZnBI1L/CihxQfJnOJCyoBHwCZZF1CIeHi75nT
yAVFHYSLxPnK7dVS3wtErAQpkaPHJlLUGqCwC2+v+hasjWxIA+PSdy7q01fdY5KUkOMmyssOMklD
hY9+cn5ETBZVq2hRQ8ZdINsB9VhizHbRE8zJPRevUOF4mjZdHoyxOas48lnEDJuYvBD5HE9wzCGQ
fmtijR4HXXVRwwYHPN8rKCtXuFWQfXTp7+YBELv4qGu0fS3qS/F4Z/fdipzlJaLL9xVzpQbcd6xj
OC6HuCQl6JBCYOHUnQYaV9zdX2a+kmhfQYkWlulDVmOPjiWVTKsC/eQ6dXWcCZQQObHDw3uPTduW
n0SG1nB9xn86cL9heBLRl4u1IctmOuScQinykrIjvZj6vYRPL1rkm6FA1q8cPcLihKKPI01h7uMh
QKXjyElLC9T78syDJJ/RgY4rWOjALuS9rTsitGFt6uM5q44V4Y2trhxiC/jEM4Nv76I86JFJ0JUj
hJKT4hW72p1CHYEcJv5BKh7IsbBtfjqBa9vDl5m/2SqCzJSIsvsUu3tdyHOvwgM3KNLynvbhfHp5
aQKD/okRvK1qQEgz9KBKQDtvatMsM4fKH+LmnRlDgDby2mv2JwhfCywzgWyCJvibDsssBgGa7owX
zk8MM2ue6ay4BuZPCSqXDtrOL6OzIMTs0AmKOiBvwXUnWiga3gdkEhYk0sV6rI5yV8wdQd3D3hUA
2zv6jE22AFxsDlhkeRdYTMyuDXqfAkBCaC0+xzsMc6gWy+W+DFlV9UuiNynuGHITKX9y9pQLtuDO
ZOiatEPih+WvOf4w0O8Sn1HDAM6NMRGJSnuksMEghrvD+siFnjHZ6t7P+ml6ftZb6lmQD77fDU3J
6hnTQnq57+ON7YyQLHbol+nnxmQ4MQxN5zVWSbCDYKx/54iSGbmrmRcRkhmGp2/tB2578QRDR+Ul
CeANV99cXq4h/iZNjdndL88x9vF/MG72b8AEjIk0b8c/ELnHBs1Wftf69ijlhzepzJ4Baxe19HIV
igNl3Sq1uv8q20v0X0CK9Dyb+s7IoTO3DBcrEbCzy4TLDEZwDHUnhzsIAk5po+uujJKPMby7pCzx
L+1nTc6Vk4+rL1Z0bmZ36YWKw3bNTHLgGDq/esbjB/W3u/PA3NPesmK/X6h5/TURGrU4p082xUxV
JTFhPNyIn1zIY+g1YIwq5UWnjSv9OaQvQxt8ZEYnC6NXGnSd6eiFJ2PrGE0uiuoOn9K9Yixxqgdp
3+Rs3xftGdASgVGt1xbUn5NPzUiZ2MXr1NOo59N14LP8yBnRDBM0XCtHD2UvaedSqKKCCtsiD5Ze
18sT2M+//3BKRgMP0XCTdBm2cFqq9ekOTuqWuFQHta4RNE9zRPpRIfDh7Kj78enkl/CpJywn7z0Q
ShgWWDMsHOqTbjc+gquPfGBctegoAbVOtnPvfrI6Ym7S37UvBV8ozCE1dWJjksVn0oZV5Q6PZ1EA
wz+lIiARKcppTrejp7Pw+LuB/E+FCKv4D2RCGi828y4wqZZnU2gu50MujyiAf7zdAEDo1FxrBWoM
swZeCkp3hWfZSz+EwHWSIYx09BfmE9mxO5CWhY6UQSikf2j8BfeD42okdMNNizbLaZLxyTQE4voD
33/XEDsWzg2WEDd/L5yLQA8T+rpyIxbn7LA8v16xQDNbSYbiPVxp07XOhXrfuRzVAnu2LX+0BhAi
eHm1EXjIKihEYqOF8RV68XejTi1fKGSigSdZ8rb1PfNpCcDhNUseat6BnmNU2CU1qkbqQcXceqbv
cb0QBPjzi0bJZdwu7brvDm/NskyPNcT1X22v17z0eFa87tTaY71e5PieVp4h9a555PqPg6tfBxqq
4B+UKaOhdN3VYjY4QPvF2PcQURgGq4pHLf7/5xw9ECkWty57P71QMj48vt52Kx6xN5d9