<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrgxPOLHBrwhB7FmflzswC+yYkRAT2URnCvm9AFOjLtUok+IeDhwURpUYhd/beJP8+IYdX9q
S+MQOLnA8hO8QQWs+F+UfMd3/sDPLUukPeSe2tG9BGS63830fDBVsYHZswdaP8z+eSb0k9WL5Bts
t8MCeHjERx1MAuRNr/3BLp4SFGcC1GjLcMnTOPP7R+N/pKWmdOC+MICZbetLMvXNivjj8YeT4keX
ogvxaoYyhF3U2XGbA0h0Bvo1BIQkJbcPukEf0VK/cQ9+BasLC4HmKEQIKNDWQZFIPsq0VTDmsZWw
lJT8KTfJWf40QhqhatKHaKfPZccBPEzwHTjpJ/q2KCyasaANE8eBPZ4ObZgNZeEurBGogueH0DMr
4sdEfSRbvWdKs6kQg6ZExdUMTdGf3AGDrWl/q9fL5pdfY2TpJJ9H0MbPvCvvjl0qKneETMzUL8lK
gJrhMLK0t99uLxgb+oR2j0QGbC2Y5jNhtvodyjwhKl+CVhA2SyLFPezAVYF5x7RUPimc88SWAuOU
gvUf3tLdyiUk2y02yJf/gkmVujdtPPHSHrMGMWVi7JBHJX3fRnU0Gr8Nzuqt6yKZ+iKizP5s6oGB
NdDIhosoZ5wIb6AjFrqOlaIW/w9E7oHmbre/oiSFbYDQChC+/qspe/TD9Qc9OPmd4xHFp6hIasKm
LTutcBV/GOWFGb/1meTGB8F0GD7Q/2YcZHdraUq3g3x/Wkt+yCpADuRom/bMvpR694f5pvqDLtMT
xXSJox90Et3TWYwtGZy3pRsXGBGo0WJmN2FoPvsE4a9sMba61PNwvl1THWDBUIdvvQBGBYk6+o0Q
9OyhzPfi1mnztN90Oy+IY7BjXVODTX2CxGfaQHsq15vyjWWqrzcQP84NcLarVUy4oX0mWiu5wEjk
xzM8T6yu57jaTRztg5EZA6mj6vzkG/WPIZ5eONJ9eiCHGtEtsftN43F5fyEueuHmnXnRCoMJ+tFp
Mcx+RapvBdR/zQgime8wnErMvyNP9C8JSBJd3margFcPH5+LXpkQhfC0H8V4mnaNfPfi1KL4iT8p
WyAiyahIyszB5N95cKXc0vmI3eXqrwieMGfbLMtiLFZsIk0VGz0kBc3abuhO5ESVXXZl7jcbSyWb
TDexErJQOKcyMrShuddbNx2DPWVlX54+IwzYu3uUQq/H33HzHtr6vCfm/UdpkRWe8w3Jqg/YUasK
09RSj/7tDXWYNYwMxr5gBUB9qVMVtyNZFo6nat5oEcS/bVQsYAvgG+oPy2jOz/2TLHox1HoI7yOw
bGGiSxO4kpdZMagwUTBYKicWt6610AY9/IAFse7h+SJX86zlC16cV1K1ZaLU4PdvdfUXNBAFy90w
8Uqr1H+5Ug32UwPZEvSF6mdI3EJLcmSBvha20snNXZVlV/EaK4f7LlrfOgdM5Z4m1+M0bKanVh1/
vMDgsKPd8OWxGt9S5T14BhWp3HtE2+va4/FJhGAPRwqXO0JbAvMcuj/Pr0tlrj22h9WnR40YrkrN
X6HQ7KB3+TkLnl4iq5GI50vgYhnxTwOBikc75UJZkREnyaaQhmDXHjaugxNRbdcSw63c9Q+qyFjs
6DDeDnpeQu2jRpQ9bCVkjo6BL+Zs3XPwxFj34FJW7cDF66mQ1adjkkGmUQMKFZ/RslZPR5+W9w2o
p9jtYe7oir9N9WGW/nlWdvYgSOh+u5W7bArtHBDy2XopAj6j0y4xkujM/TVXBp1MMmxW13DxjoF1
GBvqkYnoiugQykhg6xvUA4Yj0J+1lF7li82Mmmt0DSx7bBzP6aQFAWhqeobuc2/0nRp5TPzVT8or
jbBs/ZC29Z+jTMxwszJv7tC47rUotMn8rN/FzMxtp0If63Z465n4NyTq4UVZqfdI3oELAnwgK5qQ
TlvYjdoViL8sVCL01IOUFljSwLLgPhvAeeM5uon6TRg/oayo8Je3vg5N5/cnyO86un25WWMlZmeq
sU2+01In+4LrJBDCXq2DJ1uHyG8T702tmyX94j+jCfJuY2yzq5WzV7nZRorFptbxQBJcQ7V8dsPY
iv2Rx4JrFY5H5R4MbfT8Mo0vqMtEMRBADIB0nHPByl9Y5xhjuxEBkPp/jvZRmXjkAORe+pfIdM0c
7uXJSa/I2i4pqJ6tcqPOeuWK2lZzXEuSO9CcdFeFcx+nhj3uU3WwOs0/EQFjc+PFxqtUAnvdeM4M
6jzemjDHQGyjKs8xmTOqgScujODnWOypzyZl59so5YaTLFK4B7Cr9mNLm8o8iDwjre0bXEKKlFOE
gdSQGU+lSdBXhN55DNyH3wZzh2zLNgSvUfflf5Tody7I8i61dUmD4umI1aQq/4vcMRBfVwmZe41o
xBmZ7+Ucjxc/i6CWMAYuJKzFUTqJ07G574fLtaU4KHpdSmjfvDtA8u4wil/vDPYBc41uGee1AKnL
800UIvaOUdV/lnjbTnbKmig2tqVwsQXqkPFeB+ATcrKc56R+kcfJZJehhn82279ANOdmRe/qtUjD
Ro4U9YWmwPrzx8D9gc2iGvp1z0sXaCLU64GeUL8QHR/LtigVRsUIs6PLx/8kT/pCe+TdJOfmt6tb
JbBMkxtz4YaTbZxpfk845ui3nFgln5KfFP9xdGJ6YfOh0FQ7tqS8RJETKhiCujB45tDm8O157ehX
GNl9FbOUo5IhwKxXvqTNc2k7rIiokRFb4Dxxy7gNn2BGRJYUTZbifPMfmThFKoa+dJGsUea/iUCC
BBJaBMQeJZF4gRx+6uOMXldqpugm8X8CJKSPS04bLEJTJpjhUlRcL1dOXpLT7QPe9k8XYM3utHN1
UKlsD181yW7jg/OR7rlSbTylYVIstDLdozh9SKyp/XOkS7y2lmgmg3KRAcfs+VLrCa2tlmCWI1nT
yRnqe4dr9myDTS02Y/411LKzDdRVLgmA2RESrdlspWhlNMoULrDXuAOqCAZfMC3LJPbhNFvpuZbJ
VzyRJMHfpqnffBsQK+ahss7QXS+zw90QHtr97eNokWeKWt18wG+BdID2dztkJ+jb2D07u9GLspdX
qgH1GyM72paaq6PB5xUZ+UOBURY2xoJ/hozDsjI4ubzlbenY9Po8N5Hj8hct0xB2xGd/1G8NIi1V
yDrThmotlJZPTnsgulv9owwRPfytN7VaHxbTtQBIYl7yP2hFyuZp3ixj/PeMcxamTWMRj6xHcoUA
w72LQ/SZg+H0K5487oXhDRBz4ETdsI+rHOw9KObANNMXsDCMKFy5BeYGYhLEbBPyGksmVrtJw7WJ
ISq3xf+sDREQRw2BJ4BGkbz5PHpx7vRFbbYIAqNyA2SF8V7e8Sm1APy0P1GdrqEvAcxCWep8EAUw
0yXgNoqKY8ZaAJOam5Qr8modoBrcOEQbOM9j7HAvjCuYIrRLfUWqupFUm+tTrm36+N+89//x4xIb
Arvlg3fZ5sMQrCrDZszd3usHDhvyE6QjZqMJ1L7Z7GemjURKQraAcxo13urVNruQWvEZsSfUrwER
bYEtHTcZw2lDd+lS9+316FzfYN0iIRqqLPiqcDCDTi+Q+7H5zcwGr9+RZzE+zK1ht7GYfVBsDrE0
T9/DWZNuo2lKlVwYk9CaZ72NyrX2Ol+gXw0FcJ07OYBQxcZpxWVxyQtiUPTe1cNxyFZUdH+DR2Uq
12yHJWHaLYQvJlbbDBfLSQ0AHAGsDZN6yucTxxsGZenGZDDQQsCjICytQw9rlHZ7DM2HJjUJMPHE
cUm2wK9uyxbanc3m200G+HRxbx+T/10svHA/w2asO6/KWkVtk6VbfVdolyDL1Ia0OZ2f9hNCVlqK
rJaee77rp1W+XNzamWuC5KO6MSRTv+K6s6DvLgyLgAAlmxNWpjOpvnfeMmnNN6QitORB5eB1RMi4
dfcuyjlQa+Z9GWjd7tME+qeZaSHek+EfdfhCcYhntImKhk2awJrGyEyL2wGgb+J+xslAWmW63SoT
Zn2kqljB9LkPaAD1bGFTBo4HAc08UWQs3KVW93cRkLoSvlrIxPbWnTyWPOMnZe85IVAtm4bgteSQ
VY69OHCVCiyvCuMkHtgodqe7KllT3IiFrrA/ktN420==