<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/ualEF7fWJKdkmfmFv7SwtqGUhbLHaskC+lnG9ax8JpKRUJ2tbsEic52P7rwECC2Xo2bicu
928KM0eXWLnART7FOsJCCXtSrR4HmFonIAqO0Vx4yEEITAKrsmtIjni4kPMD4EMZ22CWpROoGDpF
FneeqksKeeZ/OWw1g+F+cAUPTWZ6PvLoUYtGrXBqt544kBIAmAeA+LrN8WCznqFw7qmMTk+7Raqs
S0YWf4j0orZkh0UkZwFhy4Q43qFH2orL3oXTl8ucrFo54B48Sa3fqXm74PlYQBzFE9x6w5hlnhD9
eJfe2EIb4E1F02jVVliD+XNF80/K4yfbQrrKXRpxLjgOfb9PcNAjhqODaIW6KM4X9EYK61ljPF+1
5oJkswh6GjlbRG4T7Azxs7/xaX7i0sgtvZz7FjDYC1jNZuy5JdSQ+yIylEWCkL4zmsbhHq7C0SPv
4SqFidhp6v6Ci3ytlR2EM6G9wCqTcEfwAkrFZRK40FnKcsa99L+e/LxITigApeQBcR/oXNsKh4tg
gYoX4DFu//7as2xJkNPVgZ9CCG77KWuhxnNkQCx8K4p4bDrTtUosBWBB67En2zRjhWFndNXXHrtG
7XqcBeM8mM0Q4P4QJaRoJI2IJ8FZ307aNtTQPh+ExEWfNCeWgiUoOQxlKFnBu9V2k2jbbY5znmFa
LrraGz7CO+Q+6t5RpZF+ybGGYomos+eWrO64PBu2jOMRULM+/cb1qS8YgucKu6vOm7t8BNmVhp6F
YP/gJ1Dt3xOblysDswjqaQGFBAuOEoHcPM5UA9iiLLk/XBC7OE2m0MX+JmOAl7AtMXFoVW9Lrlqa
heq3fNTAqOmzkxfdcql4gHMXJLw6CZvn9ZwFrvJzHXkmvnizW2DML3XXJOpCABUXBf5JNSnv1QtQ
D5XMqs5gGOXm8a38557/Gas2yoJjuUEgW+dUu8gN/G39TFkO/CHdhyjy4jTuPXaG4D1+i1AiihHX
8ckamMBw3atFQXF/dVyZZ+b9qP7vsvjK/Zkfgzu8MK8M8MD+/gim+sX0xEHE3ezwP4MIgvTbl7J0
JwZGZaq8Of/u/KTWINkeFII2TEKMfqxkbANdqo9vbROqAsuzmwwigb0DGu81qiK2iOXjwNHGvb4M
pJrRWtfz+ow076Cvpqtr2U1y4bcE2kw6swD+PQdV2BcjZeXn/PbtfXnptU1LX+MgOpRub9I7CcJg
shZugbaHRCTsGZvcPSZUIggqxs6J/zFIYB9iKl/hk769UCOTO0ZD3H/q7C5ZcxSSsRuVRnGiWwDT
b0vSPEDgUBYxZraVNmDM2qeE6ahxORYXGzdAQ5mpswNOQ2XAljBqR/zbEZFmJ/yJcCmKHiIbNxfO
7PQBO/WrAmkPxVDfV4hNsHxtQWg4PTTF9nTHLWIcOvFjZm8aHi2eTExYkFkZ66FopJyp9yC8XHYS
621tD88Ygf14JwyOPwFWm281WREWixNUZqlaeSQWnP8wUoGaxw8MUYTSo5s+5V+IYkYMzDEh+LnJ
WfnEpTj9tbGelqMWZBVyn5thD3SZLViK5fYTMTnngyVN4+tb1tLycdW53rV9jCIezjPJOpTPlS06
syS53uw9ICufRMLXMMF9x46c8QH/CDavDf0IFckt5EYVRBKCE5GNo8F1Yi14SNybApCYPFAtUHes
Rj7h5CGltbZQGheMXOD7HroV7MU/ten6dpGHcR609nXjIy1uCr5HbFXKB0ENakWIwKpKa/YanXZD
t8Gx509vWJWXCjIJV1ldwJjJ1nL/ww23UOJ82BybMQvX0uHHI2so9kR1BZD8G1Hb2Op9E282ycBC
jMOw1M4tN735HBz9YnOTVidhe+y6sZrpuaMHFum8O4+MFcfVJzhVEgDGs8zkjw3odOD2+pN9K4TO
G7E2btHbfoWHor7Tv7z8iNofWs3rlHiPAcObzL9i9zcz98VmrRBNi2Zga0FjI9dXFjI+XbuATQJm
amb2HqzH9f8nSDaYylajkLMABMqPH3LngkYV51qPEMNm+5d15eSJC/UUbV14QtwPk5W2unkeSeuM
ZwnOSK0nee8ZLUdl9GMnUGDSj50scPTE7Jl27Pj6rnS1Q86qrFujZgr+3OTosbccyxbJhJB5xwt3
FipN5O6I4378MqjDWQIHyaJcSW1zVD0oZg6bPJtu9TZdCFxEJIYNz6iLh4PZdMOtA+jdj8yZscfy
8Fx7kAjFQ+l86zqbfNatg2GznbB+Z8qWVt5OEQJsdefwPOT/NsBbg0CKleqYlTN+JatsZ0ld+o7/
3S9mmWPjdIMDjF2xoqOPMdYScxozlLrkrCpstyTMGfECPWBnLhLrLTbbrcwNTSXsDE+ewogF3LyP
KC80YkPPdB3itZQ+rDcOIs50dqvUQV+tcpW4hNjc9dqg4Y9yPY+2DOhy7uWZd4A7O3+mQ7IiMIss
5cO1163boyiiQ8ekMT+pRS1VkZYyovGoHV13S3wBl0McaPa/xmEpaACJFTNgT/jGOuxO1d18czhR
nEBKvt3zztIeVZKkmY0Ed+cMoW/bNBKuulaep9qX9plqz9E5ADwU4BGZcxdHYGeEaTjk0fCo344x
6bpZgIf0o2mH59D7xAW8Eu7Tj9ZgJlmfM2YJ00PSYUCg0v4a5v8aNMghunoucnJjGhoBDv2yq0fA
sWhCipbh2DeTNwM+xdqf4aYDacSH8ETJlRVj9TATfW+4L51pjcKiY9HOzqtYqKkc1mW/8D/z6cMZ
62u4CsZfXqqnuunbqDDPbj2hKW30I3Ok0pxedy41Kk6j07q57gqlS82ybpHUIeccU057ZmnBj1Zz
0IqobAeH90gK1bYEuYFAp4C4s5TfEHcuU6vvfHeL9EOKzamu4CtyoVcM4ePnwuggRHfZkg4kyH21
CIec1bf6DNwrcmT2X8jjHAah4SdfryIdr5TwpmL+4P3kVaEoumf9p8cAto1an/+MbFZA59rzNF3x
kdJGPS1x3L53eLQRq5PPkjvTUT8erEcY0jDSqr6ny7WxtP3pBrlOsacMQepQdN2KWMkCddSg2ZBW
+iSsBKCJV9JBO+KVTIqYpKT7WjjDTNWaEFEJWwqLUaml3WZJYw1ys6zh8aJWc5qL/olGAW3L6TLy
+56CqoCjA6J0SWpTQDyHatFJ1HHSi5ECrGR884IAifA9x6NO6IlfuEaQ5RfV221ZHFcoLrQHWItL
+NI7eckz5FsyvWHWnxB4Vi9D32Qp5g+atbtu/OozNWlVuCU6VEyK98YI432HpZ7+7rjnP8qf2CuU
4rsRyaVxJERDj1zgur1RgVRVUgp/JaBA6E0NORq+7s7CJmU8qMq73OR4cNiITdxxO9XaIVS2bSLM
tCdZ3CpWmPHaWQADmj+aphNOEmvXYLlY3aE4JgYsyMEBwYImxwTgwwMkzP14wyvdmszrL+H0ZsM6
CK46CpxPE2263Kf2Uu4aJhEmQ3DzbWUdsXVP6ggF8I/WwB7MDnmA5ldWCrW2YcvYqt7VETVyjRlF
k8QOCVHBnPuNXDg8CtOu2lRENV4EuCiXMAvJ2esTTYxzOywKATsRQtiBOcHFC8JZMKeHDZ+22g/+
pTozuMP/g/fPicpDRwT7fMKgfAbgbbSm0qg31v3SSO5B02QdhEDyiDPbjzSOAC1ri/Nz3L+GDQ5w
AAvlHItRYDQ9wtcnjYP08DdVQ7kM83lKOwAJjn7DO+IH+U6iZ4VtvgI0rROXhu/fMWvO/ksBeAPn
KOGpUv57/gDkDgFVhO3Ccw9tIXzx8OMcn8r4NYtl9AWAk4IOS41c32KF11CoRPKHu/e8jsQrZWCz
LWsuPZfrKDuRxbyxuaRrPIvctfb1RFeqBCB9u+9XGJDgrbxpGPLVl8IyrMO0X62z14YTeytQMdBt
FmuUU6C4y+qHX63arMjNxuuux3NlkhHUwwSlTSiL8GwGyO3Ffvfyg++WkME0x2WEr8zw4swRZD96
e/A//c27FwLmFig9ZbDApJF0sOXMUSW4fAWGWuNzUh2UIAHIq0bOffJnIyme4QhJroy6HaTUP7tG
pzEU9Op6Eq1gipPUqQjFS9JQWGY3J3FTKdRI6YH2wzoD/bBTzn0jyX35khMVXfDck7zrUnS=