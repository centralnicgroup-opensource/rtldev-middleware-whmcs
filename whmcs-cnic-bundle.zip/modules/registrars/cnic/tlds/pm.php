<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoBti0IqKWahGJyb9vgl0gVBXxTaXFQrKUQ1lzryit3l28DxVBXFkx2B/S8W6/RRg04fuFy5
DKh7cGeqSZGn4YviIAs9HcfeEPzOP6ucai4VbPV7yFAZrgJzPMTA4knrRQPs00XVQdmRfoAAVUwW
VJRSOQxM3WIVzUhDEQHOpyAi+5QcV7hoCYxAybuPS5p/tsGbeu79VBs7tcjggZRYANr08PKALyPH
2TTbBztycwSEUTO7XsHmzu8Q860uW90dujYdYKYDK1aSaWwd7YL+qQIW3bIPPX3qnRCV6Ttp+sTr
8I4eNhqj4BDwatEJ4rvEk4L1f237fueMeWVL5WL9I2O8XHory8Wi/OT4hkv8FeWNQliJM4KIveXA
Yddj/SrqJV3hVTV1UrNW0q3JxR77fRh8pFJmiiphntu3fyOXJQhGifwDZIMreAAYQTbsiKrJC6v5
Z/RuCQ+HcMpTatJt2ctFIj9n5R0EpWMQBpuVspyAJkyvMUrnwH+fFTRy4Uydtgdj9m1l8MFcZOJT
7JrFdA9q4llIDV/2oBxRLr622fO/m3IU6or149nivtPhje52tFxKQJbpmhVQAT5vbp7Wu0XXErhE
oLTWRGGiFz2xoai1qc5beDbCgfEWdNrxCX1sVT4HweBid48vczEjZfL+SXJPXM4BOoMqltgcsrjp
51EwcbAB9epJFntOaqk09VaCKZ0/S4HlCVOQeD9kYG3lUr3uNZca7wiVGq5tRKRB+hKS0bvZ1JNv
nnJwLem35WALiV034irHq2MmoN/XvofhomYmb7jrz4I0wLAN1SrGJ+tFqYvAi27PYEfnMDTzd7Dq
1yzgFvpy6Uq5OZh1JY25yEEvt1dRcP4gOqaXQ0W+XxsTqDfVLVetlLiIzAMrCKYkJLrWxfiFICPE
vRL6Wt1i2ADpvcjrKuKsUPasmYknMwQ7yYCvdaqK5QhRNYv9+V8/i8YG8VycOaVmbs3mHnkLRLMx
nrPbD8piK2hepZEdCU8ufTzQxdaFOwq91rrmN8lS5RBT9vcZ4nOBEudSOdCT+Ll0o2OrOXArGIFO
MOtU+Cem5Wi6aoXlMgOpJWVEp3PYwAJuhPMo24HN5A4fojCwrxqxbbKz6efaYM1n049yvCGjK5yO
lmVabfRpe8G/Ar4n/xR1E5R/La9oXx6hQpH/B1yQLRJg0gKmyrw54eGzINeKX5i69QM+BdnXZw57
0KHXwxAohVAJ741NLXeu+oiHStVTiplg3vCP44nB5L1CAgp4zpqYC+7nyeoNqb4ijyiJEc8USKmM
JkRVKeXqRZhB8eZZcu7yGzk0QdmC49md+FGqQ4uQYfVWFwUQHVUVjFUkAXOHtLTyV7L5fcZYN0j2
xbNJZcBFMwpoYX9jwDTg0RYGmMn7/SW6LivrI0RARC/0l7Zeao8tExQH5qlBle1C9ecDMvqOhVcf
G+5/OFvx1KHt25JNCGWHammq06OgZTQMDtMZAJLtUJbAW5hF5KXAVF5K/E2tbhBYe74b/VN80bhg
JLWrX+UcIf4dft/sTGpGJoDi89twf+0SJ+6bnUpcc6jFkF+TEqNbvwGQeulfkWFB/npIUttVf7yn
85juslrLb2qDGv2kV9lawi2MbjDtPvpLIDXsIuNP09FukCGkBX6yBd9Wsuc+QF3ra91tAtP0VG+L
9BjYn7z2ODORzFHcECqwiNe0/+3lpAq58bRtbSgHCAMN6RyWQfKX7/ohW3rVjLvrymGfYNNkNsB9
yMJnMqFXaSyxGSMHe1+xMJUKkf64YzJtJW7qERm8L+ts0sgkw41+tU4sy8GagmBtO8SAm3VgnpjP
9oTQgcDVN+EheEBfJ5HpSLw4lgIMJw3psP5crXyr8EQ/fexYM3Zj4NLdYabb37wRHypWwOeSx1ff
5GIEto03WCuWRcqCyTOREQ63sCOeinA8z+n23ZIBctLPNwBaz/xM5aHDfUNLf82FRVwygNbsKjMp
HREx6Mnl5KS2+yBRzolBxetf65jpRVLNkvdZOpYrFwsPZSlNtnW+eyDEEM49DXsYHIA43yT4/3QH
jjmICBjSsKvoxLBWy0p5NqUWPbhDYbUJfLuYiIH4U83DG9e5JddCwdAdrTgq4yuRrU6IKzjDSFiw
1UmcYE0svYqMNfI1U8FfX6PWLPUoRxb5HI68NrOPdCsy0+XpNq56AsmYwp5F5VWje4F4RT3O/Wsw
ZYMXbta9cg2FIVenEVssHSC1tYBPH00C1cpawZhV2PmdPNsmHZWPdLurN1NJMbj675utqwZ8Qf3t
CKxFLGZAXtM5nQWrOLYC32faqpTGRJLqX1AoScZ3ZUTbkRwCfVPdIOOwRDZQPstJCBHsViusWUEQ
C4nFWa48z6W4I8+giJ02N7YbLFeOTxEYoLBIrGn6g+IMStvUOVoRcGUFZ4GEqeLJtVK4hRn0f5Hd
N+72HMH6W/nDXq4LDz1u8uo6ojrn29HLhuT/qRzbKrR50n28SFN7N3C/1I7BYEHG8x3lCbwyidiT
iaJ8fSPy8I3pQ0GkINFgrcRDjCUv2dTkRDdQI9lPfHRNMLdNb1UDbB1+5/3jTbDeqrCXcomF/5/u
zC6wQpH8hJ/zBdjvJUi8Tax3A/ZtI03O1sTPZH3gUfVAHZ37E/WzwTRk/+DVmmkaFQtHrtIvhs4a
KQ2wwrM6lcAQoG4ilpLjK2B++V7G2W/G4Uk65aGQc1ePi1D7O/fD9lp0bK6E08A/RdVuvINmd1H9
ghBUZFUludto2MZtOetSCUwwjJKNp1lJzexDn4DJ5U0r10GXod1ZPRTOuz67qjjbkIWptb0qDxQh
g0wxde1R7H6rbuyLvSDcFJs0OV1qYVbGg5Dj3FSijUS4jdWpsV5d6Kqm0uWdvVvG3Wo/IVCLyY3O
i6GjTdLsgZOJyYxbc+ITqrKpxHtw/gqQdQKz/3TWIEBYLrJtDShNZDDei7dQ8J/C6wd5mn9WCt2G
YVH2ACFh9DS9gsPYjw/mRi6FaU5Cq1oIyeDddGHJDeaor1rSPHUdsg+R0qU2lGahUCMUE2mQCi6s
zWDpOnzJt3c7q1sg6esh0w5+Wepf3o/VaN+7zny/qX1BX51cSa+fMoSta28HTTe+NsY0Um7EPNJu
EKsT9irj3hlNDF/pXlZCtXZB56H6YJJY3FtZ+ITSJ88fjG0a3cr+ltFijnS7quSA0d5ocVN4I/Jf
3+jrPVolgNgpVCpexS7kvDvcY4gnHKGJa8H12SUcuoKsCgkmje4LCOwnBgKiCm9LyrsHVGgmhYNm
EvL9gLwUR+4HQ3yiz+4CKJJHsxB+pUVmyradA6wadNRUEqt2+v5uphK+tyjg4fbfKc1UceMpUXuu
1RfQ853k/Z5+Uj8nxfAgiUUQydUxjYcMxgqm/KWfE/cX8RSL56Mqyt0vdPXRnL3jvrV84r016Bkf
8NETvrwzr/te31hHFLXMm2nFVF+oEsOdlT5dPdbX8xpRLLB4ICmRYiR8W9b0omm/oVq6/Wv4AsNZ
pY9uJbCPRZvOeJESL987VzHZc6A9kLKSNqmvlVeUdiAxfXWF6HSOW2Ja/CSWdVS/fiPIWRFQfzW+
jrzT9ZdbYs4T9z5hcsYYvgIxA7ZV/WrEtQ7YY+C06GL2mbqEmuuMAhHTdO3iBzFKOwag3UdR9HEz
lXWn21La85RB19OnJ7MBeLLAE+/bhs9LnfGT4+Bepkz4XqQ1+Wdk+NdTN23mOWLs4ovRdZ3GcZHe
XLqtOysNv77ZkWIIjeo7gFOtvb2VOmj/UmZ6iWyYPuZBGQeINThMvoCilbLpBq4m/mQz+xH0UjhR
2cAlTzZRwtMYLPJQDOnNwX6aW3+RtLTmkb3jCH/DQ8/MAd2zaxCjDW3lHS7CZya9AeKMviqVxHc6
8OCJYI9aeKAIE02hyK3stnugLe1zBVd/UuGl2gmHeiGhNg0AW8rx2eCbbUEQsetv5rvG0P6xa+vX
GiEcryABywf8Sab8H+kgEW2W5WSsm7lIeJS0dkzGmKjdFbVE29gReQso3LjzQntgBg3XUGYIQvKQ
u8/f+llfgAG13Rj21WYSv3soNI3PDNpochiwlrHCY9Xb8ZqabL6orCLyvgQzCRKVYXXfcGkeUaRJ
JwLHVPFA