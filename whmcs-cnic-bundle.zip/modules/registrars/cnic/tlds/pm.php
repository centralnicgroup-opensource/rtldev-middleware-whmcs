<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrSRE1Kepu1QDTEjDdcoyVB0I8w05y3Fwf6ujTxcMlSPbEVaZCrCZVKUTtLe6cLpyrznYyFt
q7/N3PVqnOPf4ozLL4PnjlfAFVI5CqbEzcAScwkOjNlPDPSafR5Srmw+MNmbAU+mOiBja8ci5Nlb
Xui8y562f6NGkzw660PjhqsxNSwZ2d5UwY9hBZjBSjXo3hvXp1PGt3agdc4axc0RN6vzYKWf8O1y
rJcqxygYKITxfyNoR/SXxcPivrcXhvSg8CePSjssbBeja4egBIOQXBJ+EAvgMZiur+dr8p1rXq9z
VkSe87UHg33oDQj6HAQDLvnLKmAq7VTRo7SD/dsUbQmTxT8fY8HLJySkoPyJ0y3II3A8Hvra8y83
PqFe9Zkr2y1XQMP7WiaLDLfxVCzG4EC3DoWeuNorDzlNfN98/k/4NuPijvblcEPSwd5yNC6+Bl87
uMtNGycLwsQ2zBNCHbTyzdGx6QkChfX0h2arOG0g3Yj29vql2E1ra77IlXFI/1O2rxg4IqfUBQs3
c2YVawPynMJtjKa6a6VuN/XWIJ01X12FiSgz60l7svD6eY60k5n5hPhzkR/bBZjgXbCE8IrBiwP3
jiNnm8mDLjz6v6WBM/2BrfmaHmC/k3GM5uQXAGl3Hyvyd9kZdHBi9Zh6zK6liWP7sTzu7GrdRnwW
VJiBWdFRURl4stDE2VhFAiGPeJblmSeRvshjH3ARN9LedFjItcs1JWTEPTuQJtQAstzzkCxvMYZC
Jko3P6T7CslxVVVYwSI1fFiD7TTlSGcUEHUM+VkbMXODl3AQz98dSYib/0wAXG0aoPpBJ2VRuEEG
VP+8GyB/UBldkiSA3CpS80iM0OFu091ZAB6TQoGgPsIrASoKwFVKidotWz+VhX4DiZlQhadVNevm
R422skxl1dDCHLhecajlEEVPLO09CT5lnW/HSqqwKZNfDbV3zW663tTSdnwwCQYHOcPPMGw48EcG
b4qdpTodSyYUj3fhDClMQ5uQ9Tu+j70zBWjXf2zEuG/XcBnFKhqdmPAMU+TuHjZ8xazNur9Nhr/P
T/fbU8li9627y8gBPNPoxQBKtWE4JyReypHrsi5UHD/N0o9FdzTGhTDuVJ2C0U5DtwtZruTXY642
e7coKAXZGzcT28rrpIaZWofYgxpjcgHy+DidFikQyIhaPdoblrnFW1O041Q9YpFh2aVWXjGdE5/9
QiLdgkZILS3jADhGASEKKBEe+B0h0wF3AVzambq7hh4Q1bHbwaxg2AcgfLPNAGHWugcbXn9e/bBL
3ofIrQ/5e5uK0VmUJ/Ug/8buK0jZRVUNnyKXZSbvzKrqqOgtVjXQ2yjc6MONsWiLVbil+KPsiUHE
0+MSeSlWL4VaC4czC9YOPEDuC3FCmKdJaKigo4Muf85jm/53ttaDmFT91I0+PZ+qXu+QR1Vs4Hwd
4gZnXV5aRFl0E3kP10OnwcCGnyGzIAVvJ9DMPE3NnFq5ueSKwPeURpVSwzpkM01T+9FqILZATHAB
0/l68vKnDu1JQvOxeOHqtRyCM2zxyCxE41WjzNjnNJWCE1RyVVI65EKQ+VzQHZ6DTgqEsUarqSH/
PHe2Gfe/IZ+ZCy+3JCwmT+lp5k+CDFaH1tmuvGHTmnhKFLz6DQNopaUS5R2o8a4NvQnTE3YTCNlR
UaZcPlS1uDqWFNA5jAcqS2sgzmDtlNl/B3jmI9MfcIeaFHtpkmHqKru/UwEZ5/BrFcmqJE9aR6dO
B7SvWKXqD+ZUwqPYqGmMlrR6yZKPPg2dYVHof3ShvZ7XBSyxavIbdF6wzJRotwgLGRl+7PTm2oPF
Z65G3+pG6u0QlX30VFp2DEWqOXLfekN8/RxFc/5dWQQB7tA5QT8u41GDjxjHHikK+Bj58xkjkPz3
YF6ofidOASHGsmsxljcap3SMYM4pWGWR+gDZ9u7RHzBdYG59C6tgafTAgAQwjBTB4fNM5qYighCL
YRTnV1wtbi3kWs/lHyFlqZ2NEVCH0uA5OA7Ac6MKjWAh9jlDgCEdxyt8eOyYTKeSCvosAXcbtGeR
0wnduJGeqLu6WosmPmchCdyPty3zYXXavKwf9zn8B1aiG/cYBP+KawZ/l1AFccTG6UFdPs7fCuAr
2R2mXYQOVoKe0flevdly16kvb7eh0Gs68mJMzzuvBo5A6wddD3Wh+mciKD77Jrs9zbSaihHqRZWE
CuYjZftK4n7zQbOEYiKlKIrvQEPfNYtSt/xiCh7waM+aEJ4c8n5EAOt/wNFj7jUXUirfsCNEvRvt
06EAdekDgVSSPOD89iXOB20Ix9M8joLAh3QGMw14/eSSjyoDEhk2LN4NGHyBUamWzjggSeAjuNbY
yR+VjYTzN66JRru16nD15NiS+FUm8yQGtFqe/t1bbKS1e1B5UzpwLGus52nPn+oTXPCPTx2cBSsm
18M4TUCbilcfQswByDdoh9bvj8B/QSOvIugIKTZJxmopL9xUjnKINq5iKuawZmcGhK6eWm3gZSU3
Rdzaxo23FjhOyXCE/WmrmvBEpC5o5myC4o63yDlyL6CioAcwdKwGqyhQJEmeZ7yduLJkz9jTPY1f
oQqkarMby9dgWBAvGh6/DSfBB1X+lmbBheu4WGnCPyV/woIW5BNZfXqziU1uuhQnilYy3tWGreQM
DbbmaJIWyzjLDQlysHhYiDhuyQxAMUirYJ0gtflgUjwLT6NzLaZGX4zw0sPzykPAcNtR4V0VBXR/
R0BZAzyAZrlPmFTR8Pbon5SKX52OD9sMDLQHmYO1ra0dArGRQHvHjAyXs9IuqyE2XxfhfsL1w8QL
WP7iTxemFYLN1rEGxMcmyoTZnDkygdWYcV3ME5xnWdfGM8Zu6hyTdavPgwMua0G7CsAGj23RNzBX
nZ0hs2NcJRn+9OBf1OPm4zmfQcL15Kdox3OxXWlrTCl+iiGV6A5szRU0W4S5zvCjM95WX4mwHE5Y
S7euZgOpja5HcPg82ZM4rF3rOYPswLjmzDw27WCYKgxWGeQFdUDRUF4zlzDr0Pj3FKTB3IqmNYJB
97vSkG0f4BJnVSbboUcI2cxn9i6ZCyLPl0Vg5/+Lt0Hjk1b2+vqE28mMUmTqiQKBXUGVlx+0EF62
eQ3R9/8pL1HRd2hUvtsfUrwMpTzIaBdSY4umMUU/iVrn53K70IaajDSI9A4btWF3MeqmrNuRuv+6
9VitI8KXqAU0jy22XaQhCEC4vUOagE3IFKiVUKQzPoVhBJvRChqKfsWcoAbhKXqFKq/neCeXVypJ
TJuLV32NXhNlLDbreyZakzsWgxhM+2AY4W+Ya7Bd0sePpHoAfPc9BehzgkQWMwJ0LEsWzrOjCfkY
tj/cefg2chxWGDbua5pmjNRBkz6sdE5i4pP2v2eXxTL6sXzHoGg+AOre0BcwpTV7Zu5TX4fJNU13
/pHZlJNZlWgigNk7ihtIMC8Gc0KG3Mn5iBVPG3QCFw3DISR9yWN2C3/tYlP2N+p3SI1jES/ogPER
dUEYDp4dsvQE/FuoC0GhfJGRG858QJPUmQhO1OOvME1Rrx/1rp6XQHT/Ov+v4WHFt14Hn80oceAc
aD2R7ZyIpXr8DtfERvMvC1d2SyTm2M6s7EqdZY9OUtGdWpbGLzJrxEFKR16ulm6INEpCDe+szrH+
KsUvaQOwdliHZaPPxTtLJp4aS1MZw/ITp+HvujYvDBiPQ/uznwudm/tofjClDNTreyQHqKWz7TW1
KR0jbiJH9xAtaWVttH8bzIkm1xvDPC0ipgSXfbG6ehVBiU6ibCiwDWQlMFGJtf/hKN2zPToJRLQd
cVxYHKMbuIGzOA7iDnrMsJtupABTh2+wikyTf8rtja5VREUOy9g05aII1ths2C2nY5WzodL7J/BD
XGnINie+8Z7NXuJJnl11NdEkDOoLKiZzlB6hsSvdgBVUroPv8DU8ij+K38/e+gXm6MZ5n9RMVGmn
e9HbHjmYOeNHrKQTHdTORu9yUCJNVzK6Xxi36VSUbLah0WGHnaeG/kVAS6a9Set/v97SnJvUUMX+
0FESBLD7aL8FBC11DD4lUoxqWU9qThGBtIaDCYtj2/y2wK+Q6cJj/oLVCv/3pRkmYZ7p