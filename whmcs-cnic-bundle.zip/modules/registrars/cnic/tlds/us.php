<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtLNKlmkzgRpDvp7tqXrqMQxt5+uv0f51C8RXmtMMZ31R6u5NP1D2VguBOHuG2yLeAW7gI9M
YPmbJB8eVqsK8vt7FQTmN5tTf0VRR4bprV3uphFLRej6+gJmeUtozcjh2twkDVc8O30aRxg16Wg0
NVPAdYBAQxry/zApSuRgUTW+Ljk1E81VrevJPGnrheUwXkZEkf9n+48vKuwCGkbmMkg8Ui/MJY0j
O7R3cPO1aGt/j+lydroXlNsn/swQbQFuLwGAmaYDK1aSaWwd7YL+qQIW3bGvR1c2Vkc7yDlcobbr
KGG70GhsBDaz1K+XjMIAWJLW705NxeuAEKIse+snIXBbYgQhSA91w4bbfuRJxNY02cCJb++JNV02
3nzFthvelzJhkkCOJ8ExTNVql4eGYTVh3dsJUBVIoKqjrFKS2bKrhWfP7gJHHm1C1D6bNpqklNrm
IJw/V9wa4uht3dzpGGeKBYbOx5YVupfI47cqkw3dqUtsqgZNFPNrUGtfNpb3KjHnAte0YZzvNGVa
Ov+4MAszpdQq5OyZnVdzxeDMTWn4yvNtNakvXjGtGqo+tmppC11qk5aL4Lfm5R0/+nldVqRjDJOd
ZmrnLlLz/dexaT0R/TLUiZT53c0bO34qvl5bf+jiU9kYCVmdxVeRH7mEOgm5JEVIIXf28o5iDyF/
VEB/clKP7cjut0rd50K3X1gXvNwD+x2N88QmgSbCqsf6CJHm3hO29cozxFT5KehKcWiRl03tq6xK
PV0oZSIlviQ5wsMRb/FNkU8VNTsp0xVBlzfn9HMdNRQHS6rJrGBWvOUj/8pRhLlOMv8ZeHgBb1UF
GGS1cjwlIZHhWG2gzDuwJC3YQT+ICAh9RHWi+KPe55vcYZ+pnNngQk82yM+O1kNMgXBVnJXy3wCK
7forclru0JcNC+8ElXjK0amwO1u5rJS3YOZ+w9DKkWIr+R4wrDveLR4jwKBsKVbQj+xC6j25VbOC
N6PQfwB2BtiQfrO+beS52Qug7lCHVNCxZIup3XQ5zuHDaqitaYK2y4U3+yb1zcnTkrwVdFU2bJGV
sQPWASmzy/1IEG/cvHl061tPh8T1ZcjsZmQq0JeAknJ5gfoJB89fhAnks3MrcXHyLer/aPaB/yef
ZTYsBzt4ueY3DTwKzbKQjAnrcoJKHOrCpgYgR3j3ufJDl3qfW//m8fKvsTBb6Bj4/1Nvn8GA4UAe
3pX4ar8Va7c2lE8OXUyzna2DmC+mTpvYJABUS3ZPVc+WjCCTXgAIAalMMN5ZqaK2b+uQVyaObkun
ExeRQzlp0j6HjoJXK4Rsx7Jn8saR1+C09aN9fkbnYvxV5LoWsbkCMx+UR7OcTGNxS4KfVZO9R3HV
aZR27VyKEeQ2l6/tfgQDwXo+VQSpgiEahr7RwRiqUjL5wyXJgmH7Q356jocOww7H2c2qbkN9c0Kx
pL2kksJwVLZ9JBi/WTx5X/KZ3P+NED3OH4NOuNAEzojpTAinDV2mZjQCmZFM07h7OyDC0ZbORoUq
dOLcSTeKX9qcC4v5Bc59d0EkMfx9W2tvLTsUKCNfagIaHoDAyW2wGjJ47pMutZkuEkFjDElOKOgb
UHbrdCry9BpxL2inVYh9Tjp9mgzqo0mZrn8QaveJqQcYA6BqosAyI+st07xnuIDygfuziXsDUGZR
bqKhL5bvEhAeDwPlUbHr54qCarZnVVlZA8q/WGzB8rnm//SfC3yOg2dvqvp0e8fXGjQ7rQf6krPn
DBzpwajmToSjMZ86s4K2C2pBQo3/EUvugbnO+ksqQKmRv/dSVE8ouMXmRklh+kQklUqZTRD85Sd/
0oiaJxN99Rg1HxUUS+ag2HmTzDOSkLg917VRnMrA+cxZX/BT5XOZvdX4GOuwLnDWhI+EB37LCW15
+nmoKUkNnRVWPPjWnFxZR7dUKjpeqj+Q5F/3BsiI6t4aSXn3KzsIIr5eOfb+6P/q3cuR15IIW0Er
70DUomr1iQux0un8QzCMPKKIGEVtl6KzkM8PPyVWNXHSdULhKJFqehCn13GxSlNErKoKeBuay2aC
Tr1dwWOXxqXPvMhoWR3e22I5Ce9ESWJ+uHSLLId7CsewONiSumozXXnhtG9zDl2CGkoVCNsW2fkn
m/ctpfkRQwHNMhrjlN+G3KrnUQYT3lfRJITSihqO0D6je7vIFxHSw+fyFNu5ErC0nSgfYdDrQTlo
dba4TY7Ga0qCMbl2xwPdf5ueAbBhuvQMN9QFZ0iIXeMr6nMA5NgaIeIM0ALx86CGmxgZ9pFcUPui
Z4lp1+NAQPjpDt89TO0sjKQIedJF/XfLYXg1MsQnMS4G7N5Pk+13fWHx5v/ODTlTvbM8vPVYoTEX
OF+BhUeb9+7yLRtA8yxTQBiG88D6Z/o03rLQLQGAFRQoO8UPEV+bzqZfCUoolCqL5p8InkbQogci
0XMlY+8vdCX7pxUhcvrrm6HX3VqrB/q4JgKZ8wF9VrTky0cGQm+EDh04l5AoolUv9q80VGFx6Xyu
5NdmrlhNOm788XENCWe6EfvAZMzQPBU39dYp6i0kvNCjSO1ndii4GPIRICZ99rw0D3Ja5CRwe9bw
XzYgUrE9eh7Rs95X2MG4VMPh878EncW7quHSlJwKpqPDBIj4lO57lpK2Avj5N/3W2ZIENbYjUH/+
8IavJmWgheCMRdwch0yvCLrMDXaLY9Q5ujULJYc83e75eTGw4RxwbOXuk/1oJ66BRnsOyYR1q2sL
V/x4H/PLybXQ/yVWOd3SWVqgX97dElr2H2f5HUZ3PwQ0LLb/xbkBqKVE9CvPPGJbIyosJyJMSJ29
X8LcRTmQ4QtVR6hqjrhOXIpMXQYQC+MA1hwsyrY03Wp5FbCd6DJqHEqxkEKicarWr6Bb54GYL32Q
CexoWc9GI2sxA5wphIDMjwcxvcFoc3RZ8/YlPJ8U67EwNe8DdeCWnyT3fhijlFXjH9CLxS3fgdgF
Oqaj2zFzEctqHhXk2GRqJG4dBnoTk6L3s1gus2VUYFGcV5Ge2lA0Zr9HRnWBScU/FJ04c93D0gJF
W9LcMJRv659SLL1BOCyadmviMYb7K0bK43carYMNlKkNlcYwjJSh1jivGgSNlRNxbgNY/JQAtuDI
YAGxr5v7nGOMvprXHBqB0AvcvoFWE+i08vTPBq6YTLRuREnHHx7y21ckWGpkq/VmKGLhP9fb7hA3
HVpdpqKmwUGxUp/ukEvjTjP82BYDu6qftJzjq1AaXtyOu431euyib2mOa6zitGjNYciFixyIdlnS
apEXK0cjOIKN5nFjUeUBJW/monV79LNmxx05TpKVVL9mADltsjAlrOZEdR0gXBSRdiAyLOJV7V4V
fZZQEQ8YjrPXek7lfFfQb6Ijg28ZP6BkGwV7SM8TQ/UY7pdvhdPWr0p5SFF9Ytt6P8OX3RVaFpGx
coBvRMCYnIvd2K4SyDSP0mfGAY78uVfFWM18mSVTpmpNbQepu+U+CLtekDPlKaVCqfK8tc7ukSpG
LVCETwhu3utNmQtQtEFvPudlBa3XKgja3KYSSy+5yXu8H4C6loQW98kAY6+kawBrN97GNgZRRazT
ozIbgltjxq3T95grHo5LMuHltagMCTjpTbVe8LuhAc+JIg2vf+9t2jAtlUJkOgL3pulde0SIvU+k
wxjNZcXU/Xj3I1mXrNYwB3xecF4io9noLpzNe5B5XewFSphKtCxHcBzy+hB8m/le0yrD3pGOY2A0
8N7bc62P08DppX2QCe8nRm0YjcUJNK3ZqP2VpNMHgCS1w33j7s3wvArM5NUTXV+LPV+5R3fwA9Vm
PTZHC5t8uD6VLp6yzsKW70NERxPXdjyUS1ilccHhY5nTgh0ggxFHN+m+iEPx8P9kndVfx4eWqvvp
fhDcdD2c8k48jRYK0MJFcb5OU/tgosGsvT/7WuBYDmc+Unka/hjTHr41Gv9BCmAnuNHJM+lbo3l2
japft4WDq45m1q+Bl4sY54LJLkyGoEOZKUWnEiuTAuN54j7zTYDEPbV/NseCiNS+5mDJFQmaHKiD
9sBCW2fzQCTGQQ0ge0aGxKaRlfTxahgu8Y53aidwsU9mapDPIu0ZJRRYjVJOIFCN2NqMrOvLGVDO
2C/Po+zimyxticOvY/jIaiJjmSC8pKCUJksJG7780ZtLFGfzlwrJWPLmklkENlzgtRjkHG8RHCNJ
B86bE1lAAThi3fZscT+RT1/bM03mBeTxM2110HSrpWDruVQPOXjchYKHiUez/IwnVxjOqvxS/gsg
gdO4Se3vNP6plXq3jiwY7dhQ9ZCarVM2zzugi5XjcFchNsCF8PbXrcUySjtbQ0RNscb3bQGeA/Rp
x9A9tLjaGGHmgrkLdyu2BV8Ea4Mi1wXFosjKEHDjQ/MrP8692IMfsJEAwRC7i24HORBjx0i55q+8
ncynOpIn8dEr3hQIUYC+lcX9C2JOLYdqxb7yZrMEPaqFmuIsrUdq8F+Qqzp8po/nZHLGNt3/BJCe
T6oPMXhj/kApg803PA48ZcHV1cwmqenYnfub3s273Bq2RnSvUlvWwVa5QN7nxkOPzsXcoOe7x1QC
tm8qmLmYidX5FYfW+r/QOF1Gt1UsFf+IvO1akfPyroi4YK79eCDgRF0ldhEZPmKZHTlYg/s4/6Xy
CEn1UYSHqHLdL4QPSuKgk7ys0Kk3m2cBh9x6oDYM/Pxtyp+IMyK07j8slXa6RW2datv7Oi84NaI7
WKnfpGlivhqRdxiXaWObDph3Rd3IxwZN24TFceAoaaWvPAGQBg8aSt7pwmGiYKRdiOg2rXbv7eKg
Hwzfn8dPdd/O5EIQ3ZWfJAgceiOhwbf8IyLv+KpYli1GN5ZNp6r5r1aBfzBQ+uKkby8Ly12NYAnh
O3QPw5MxUee8lOxH30mJcoOIh/iUTXQIKMxSdY6gT4qN2bfbrViJSxzszBOlntRaeZOQf5u/NgRZ
Of7VdZ2sYQiX66X4awM7+PdZL4GT9dCbrkA9h+TF1f7GlQqTFSj+c0VFoQpP9XfPT3CHHyiGrmSi
amSNapqXATC0M5YL4xLlBL4HN9Vh8adUTf9XTdlTU3H1TOGuUeFjdjJZiArE2e2hDSrYixeEtnuo
