<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt6ssVb242B+6tvCshVC/NzlwSV/V393uSXKFtvanl9b0US4yRzKw3h/mQAnrQ1fbjYe1DHY
yJ+laUCnP0i7H3AgAjvVWs5wZVPw+bTnD/Zdlbbi9l6T1FFbX3+XvpCIv4udOQM5OABF9WiHzYCK
icFkKTklbv9VH+HW1fo03BBmRlJY77MKkp0dQsJI01WQlnzFoxIjZNvyafMrOLpX90fpdJle+L2f
ICXCa6o/fX/Jo555AScau3EbxM5FWoVBdLtTbaYDK1aSaWwd7YL+qQIW3bJ1Qmk2dnWXDojM4Orr
iRCeJqUZ0rlN3cYSGfqJ2nrqs3jGQIuU5Bl2wd34QFCP5iuTZ4rxZ8NT2iFEJr1AzFVODIWnTHh3
jKE4gFq6I+wRxMdI9g+Vp1Johuy00hS+0IU5uFNN9zL5D0rPBuKW+Vdy8SPUJIMet2eilAxT/y7w
P+d1PrsP9ICsQrOq0iziQmGeZabObXBaSPkm/XbtTFVt2qnCV1gocO7Q4UWjeEIXCyvi3azt0kxl
8X0ZVd13HQHPKpKijyOmJr0IItPeaGflV+H+e9MtKHxMzkvDFuI7iOQ3UXVcIhc4qZeHVamPISKZ
T6GGZePldFue7ElzthAhgGZTM+SOmQWmvYmKqq0QxJOAZ8nJcjAh8Z+JnkQVcsmW9a+2bTmDoGCG
QGI/hKlTu/oN5kT0u73OOlb+BgZgL6+DctLq5J4oQz+PZW1GuBgVhIxhSxm0aWeJcuySEXkeimZB
3Y2a2Oi/eSZUvspMc/U3vv+sjDotgzhtu4rfMDslJWjK81pmZpVIbK2QSvMw0rX3igppQvX6znNX
lEyw6BUvAnic8ThmV1N2exgSkGYJZteu8jI59qRyMWk0/X7T361oCDKVv8FW452tBlDt/Ug+OtNO
Da8rWYHYiY2tbDy3ClWo6dhPmWTzBP6Qp34hUDaT2w+WBj2t5+MrWNvG1MXCYEYg34jcPDphW2zD
gD1sVXRB0WvOZ/15woF/BZQR/XBNUsRZoKfcIGBWaYP2oWy9mZ2k2PkiRHceEwsY4z1NcupumwAH
Rf2l7Te8mHw1LTy43W0ADnL/QCVCTNYN/FY4LjlkYZGVVhlHNwzpqO7aHqDtjD4JFsZCkCuwMGhk
1P2v1zSGh4C0c/aro/saYnJ+eMHKdqltUQzOG7Ll2AOnZjAnItxwuh+Nxfv/Ix/9ZrDBHj3VWLsN
awJVwsoNaBVJNpxd+2Z9rTklxa0PP5aEr7aa3PUuTgsQL8/Q8VzfWOGBdZe5YjZ6UyLS9Pp5ZAV4
6WBYsFWZcSFkD3qVzh6VUKYPE+uqWhzJ54P0A9Ds7I7VZfxHKe1Vt088USRN8A8r/aB/JC52Hrzj
OqOp2dLb2o2LD05AUMbqp0AGX7PAd2qEJrspmMaj/6c605+V+OZl7R/dBHtGbqzEz11xluq9GaRi
j2/UGlEd14R0ZzZuMPQIsJ8FDBF2qN/iOsQLuhFvvxZmDgVMZEqXKOdlSVm2vC2sLkgyTo3o3Yxr
rQmo7gZfgZyLULdSSoSgP5SZ+2SrhrW4TeihFR5aLfhi2YpkbC35GxNYRY0de8Coh5iaBQxIzEtJ
A6OR6WzMa9zoZMIqTGQPZoCu3Hd6tH23Ak8Mt81nWt1LdFyvr2LFC1cGSAe/cOoKGYT7fQrej5w4
g2Z5BvKSEwv3pqX2wSoRs34QiWc/P6t9jh6+gRcTXubhNOhnoxd4hEhiv1aEIVQUuc4PJmo2AGwb
NOmcX4S5C9qxq5Jm5/zrcVTZR4KIC363Pk/HjTa6tnlxC2fJRAD6WOpgPfbdbnH4ag+9q3VLUdhE
pO3SKQFrjoJDA0SVjHpJ+0IwnKJMtIFkZnbJT2aPw+++4yH96wPPMyP+Gc4bA8UaSAxN92qKmgIJ
1Wn3cx4QOhldgSFed9cuP63+B5i4q5SEagkQ/3u5gnUeDYgUDr83O0kzaj1pGeivG+PFbiLUeoO5
7GaxyN+yRqLs927ha8Ex0phAxS0gzkOPVV4qU5vmcEst/bWX/d6TTUIjWZZvpAhS7GiL41vPpmd/
5QU1DUiV3iM9roNfLH+prWzOr5Gpwq2BjpxFIvzUkCkDeBjIo5KGew0Y/vCxktLsb1W6L+dMuVg9
CESZzFumY4WPHJdPrbPoumetRuPLreBgAYAVHeRcTvm6QEHyLdl68ADrquxbglLHTvGRg+nlxLvA
p8/Qf3erHXKBvVSPCjB555hrYp6dVcGgPlYXsu540WOg88PyQR8cYKgCLXVPKrq/e0U0a/qaLw3L
mlO9ntrY+7IU9YtlHeZ8akujIr08wrdQy/rNhQpWiOAmIuGYckbLJCQEMMHMfxQgX8vn3ue3KL6O
BC6DLlIGZORn/6VUmHgkaFOTSUeV98bZp9+4OAB97WZaeFgF5MxUXZQwU4oFdSCQ+Z/1wOMc/J9U
mxACoKCg9XO72FJ/CM5cSBckRh2M8ujtp8DQ+Sv5EPhr+eLVDNEeyxGNXPzWgkqNCRsXPecF+Ekx
TdZPKahHcPXBmeT6oeylMdahFn9lNTEI6xF+PKn9xXXVjRuXAgFkSKbNuXVNxi75in5xfD9sm43K
SBCsJxC6zGw9LGUQjyZ4JKKMWxM0m5rS3H6nBc+tBN+7al8Ry0zGA2sTgfgO0HUwhNsf+B9EleMt
/xk3J9YMeqijuyMCtbu8p4285yz0lSNcM0ibnH2flUjpnli/QobTgtc2nSbpiaowVL/Adv9bC0w6
5Y5wSyoav1JeduNfj3fVpFII9MR1jMMt7n1hEKC4Wpc0+k0tV0cipikrXH6x6C/exNVWc8Lb6DbH
PkjbYn8Oob2v5I/YkItQkZ0JX6KEydReo6zJQgs9d6mna571cpZ6ci8z7sJnXn9KidjYlsIq+rrT
faKGKRgQ5t2BEScdEO+Tk/mwBEdI4zd3GjS6S3POrWDy/tbSmxdUjfZtso+votEl/TVjGSo5Hi4n
H3Vg7bco4qyviIp1VUi6OwIizt1ddK9TOMKG0dnLD7BtiPE+QYs7wdCBoycNDkBrROTqdg8/hqQH
1XpswMyuhzfm+WoZ80LPDpshkkg1k28gkMPRhGONSDNkTtx/9+aOvUGfyNDAjkNQbAMYhjumvyMt
T7fvpLqOX224Ymxg6O2l6i2POvKvz0GQxMyuLPTcqXV+NyEGIzQlGE1agX4dM7KFzv7M4NT38pjJ
PFOouYRf/4Eab26C1KrjlFyHATJ7hhS3wE3wsE93OU/THCf4GSMViv/YUlDanEt5TXoQf7sDQmYT
G6PH3zBGnq9bpbw32Y4TJjZ/96bNfIDzfNAzvClju0lBoRwSwBT9h7IxQ80IWncyN0SaKuvJyrp3
B96gCluW/W2IcjehhlmnT3r+uLaOIqjbchhYRhKLXBvFvOUyJReoJZE17gNFl9p3YbzxjrEon/cA
iYIS6JOB5V217OTvsQtVmM9cw+VzaW41/f+e1jF4cgx275NDMRGRnKk57tGl8xcJEizcOu8NCxBJ
yxSLALMjNsnpy0jvTXAxq+yasIMo5TmXmxZXstH/SDcAExOqzdBjqzpv58S4W4D4bEOaacrh6wQj
C/foJscSG6+iNqzIVqD8CWPwO1Sgq8CWsAmfushJAvVUBt7uAFP/PDCqbhhLkyNg7Jdmo+57xu4X
vuPh9yjciVjlXrXb4WnQ3hf5m/yTHXs8SGCQOHIJ9Uxs4+OFZ+h/KfxATv+BkWoJT32KQH8YD96d
qR0YoKQFn1NIaDQOr8/lyRKTLzgLpGyEh3ENTRg+qeEBsDgz57rXB1jVt6XJ2lQaYIsF1vYKw9a9
dcGQZ76xsS/SKKbpCK0Etu8ZpOdk5Tm0A30BWLPJlHacG5Bw+UL6LJ6I8jZEHgk5Asxk+y7u8UCl
ngcTFRL5teqDqo3JXwu7XsZrmwncY70HwEI9EHJFUY+Rb3P1Fgzbe5a9VWJZqwiSrFJzHz2SVRb4
sPJBtwvkZClro4bLGR9nTr6efbBMYT72pjsIcgboSBVQnvqiGgY46OLih7/OpGOd9/8wWs+1RWRc
RlqpYqQX8rBqlrm1CrNYrcnS6qISmRFoPKLFp0tX3oBYro6XEfbzsC7HweoJQgfC0Rz0YmUL