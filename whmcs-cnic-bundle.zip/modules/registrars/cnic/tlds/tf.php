<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+HsYd3Yq0v7+xuVKwvxHzW8d5ZTwhI4RRguMBOElANs6G8bzjPgMSVRO6dTDRW3BUhscznb
L5MkNm0pUNPA5G0bIUOUfS/zu/8TQVp9/mt/enjEiPjOuGSt2JHAsLZxz5SK0IMD8M+07TTzRAJv
9h1NczUJGBC4SDPNXSo/ik9Tg7FBjHFyV63miGDFKiwyMu1Z3Q4x7W+tL3/SJXr09whZ8r8wLP+E
Ze92DVamFh2ikxzW/tV2GlKk5QIwllDGSPk7SjssbBeja4egBIOQXBJ+ECnef/ODSN81Z7o5Oa8D
hkSQWbPV217OcJRfGj0t2v9QOxtnbLCeg8jxuegO+JVmvfjmCRmar8n/VALd3PZmsMKI++tWWLh+
MtuYp3qivgxUQC5ZClQHqe+pOSX/oZ6yEiftQ2OX1U/zSMh6oj/jZru8gHsszDcweB7pnL6iFrGO
zBfLVt5ev1ZXowBmqcXEMunwwXIQ+oej1Cp+mZldnYqE0HJquLBA2Hzjpu53LPL5SWBNWSSLGy6p
foWzoNteBm7xvZ+cYluvJg6jBJA2j4YvsueE1iAFdAJo6IeCCT9IEbbHy8vluVeIc/Nf2ZhUInd8
JY+J43KEDsIr3x3BEzjgTK3Lt+nm0ggALZByinY+pv1oShkhhrbLaA3qt3hc0CcmqZ2WD4erDQE9
OdrT8jucwWuDM9rQDYTmC8wBnuGbRIZRSA//i5DfkO/+lR3fnf6qb4yHxXy4LVxQoDaBybIbZ9aT
aNstEbnFFKdRDPdqKGlDRMQCd4V///3FKf63JfqRl0CkXfQMFJdtAYc9zIRjjqDgBMO+W//OGn/Q
Y3wyLjfamSmOstb8ey7dgTvelAkrGrwni0M3IVTYtgv5Qo+6xVbi51cT5W7TMO6e348zloqlXuDG
x4MSEjLMDJYJoAFaTEv69aEwbAaL34usDl8Zvaw/Z9qfRxF2txk7u9OQ4PwtEJM44j3hJkajoctr
uNDciCv37U/7d7hmIPGC9ly+VROtRqD17gC2dArXzNA+fjUJeu4FmbQtC3hAgb447KVwEDHncRaE
lRGaqc00ra1q0IG+QDmL7FX0VF+RBgFLR3Ec1Kr5H6jqLKTAsGwxWY6Q/r+Th5tKTvr27XF5LhF5
p2Ine1HOXQdJYryNBz1wV3yCNI+ywm9x+7wiSiyN9ZMS0HzSq6jHqtssMO6VqpAEBGmcEPdQikAe
HNhOVnErDHZ1G1dJ+uSpJa/BbB8xKXQo1ltJalkfaRfHPFeDw7vpfDvf3RSN51mJSYCUgeXaaT22
ifOnnFOid8ds4n7HdTiwgI+JTvFSY75/Lgz7quUAVEfgoYg3JQfejb4cfbrE3K9zvnb2xftr4A/x
pY2EJJu6W+K4lo+4dZzA5U/79t+1TZZVpUkbYsUrHZyQwOGLeOe2O6I96SGX1CtTwI44vF4H1QF/
QtQu0XG4fjHeZvrnYLENuqN5yh2/RJTQA/uvWQdtctt4wNos0ndwLmjOQcXbQ5ERypfpLISmS5XG
1lpYGXcQy/YZtPlI3QV6gvUBePlA+LctVrsjW9OIRreZqynsYtTRkTPJPBz+aFJCGfgtjJXgrGPT
PsXOkwjTb5z53hW6hZycN7JNpN4UuIoS2sYneSh1eYg/k2pQYYLfiptDZwMubzFUVKbuqoHxuWUe
2xjy6N8zLwRStFuje2M3MY31P/0/mx/BR5L/p5py6+T/0czXpIlo72kGr5Oz7Ox15M3BLTpLp4c9
adW6yw63elQPYfIGo5lA15lZUW1oiwgCXUYG5225zS8wWSdy6zYbJCqqXAiwUojpjtII7rkHvlTt
B3wcEFEXHQvWwrUVjqNOqVrTa2FYrHjmyYhTL4YKp+OSOhF7H26SvHItd3j3gU66FuZ3ascETxKC
KpKUYBVHqqmABkcF/5Va8cRdcyS/SQ92xuaCx0Z/eP9QndLSRMaxI8vxIrQ2iUC6l6ut9ck5HLxh
XBmU8Fo4kg9TRG3fA5QlccRlqUmkIItA3Cywji4fX9mJJd8qliC5c/d7MSMGkw8h99N49n9Md0uX
0f3TPV/pcgn3dQrevvyuvooGz8JHOI6ak3jCGpu1ZgFxNaU24Ak17ErNchNAphiQdHCaV1RhCUZR
TUZ7HVY+6s4HhIqFeUGuXNQ9tkN6/mv2dlOGjy7904q4V/vJqwFGOGepv1lRKUKH2xOrxmjpDU1d
kO2O4GvOQjc35BelVYJlYxSWAdVqWGTXokUvCewDhn2Fx65ynJu+/UP3XxXfYXRkcNFjMr/NKLtq
43Zze1R1CiDdUieEIwEYz+wNW06vIz0hPs1qQBK1NvWvj049WxXlbbYqxh3O73b2FJNeEuTSgtwx
2F3kiO1f0Rr/6KeXtqYEgLnkEjvObTtiVhzGNUyLOnL4/m+rhUOtyy9OHZ7cK23d57Izrr1lh8Si
lBQuQRYES4xZvXxuhbACLwM5DF75Y981/yAx5uHdeAhDet3A5/h2KtKqZ4xlYjb+6H6fsdMCmFoS
FWK4GK7OSchXHZjWaThAWeD+YIcc0wAbJvY+GysD4+qbo8eqUklpYA75arZbI+Bdw4Jdb4Rbkigm
Kw0RL9RuqbxxGyJPt1G1itsQJle8MDj7rhYvez4Z4REqbcVJes95ng+isGECoePBZfXa22Tw1Os4
QMZjmDKcj1P4JZC/x8I7dHXfNCfGWnRqdnMbgvcmnVxo/Zxqj772Oh07Cu01Z7kSoD1S5GslxJCE
SakvL58YLWCUlSTxS/iDtBoC/osFFnPLt/1jjp29eN4uwyRuRt8xp98U3TnQZqh81+pl3lk++sPC
tsdyv/gwYwtwGSSjU+iBWGvAgpGh+ZsyJY+XAYC51Hc+6Cp9j7AhmrEXOcx2nHPNiajYmf9utUll
LTODg7rSE2ZmWaqG+5Br9pxzFvIoYNPZMVFBTteVSz6R6zFHD+NNnKnfWji7di+x0blpneUKXC2B
Frv4NjhodHZD5IEc+yUH0Jl9gQ1iX5titbSNcVrQUbxbzzkwrYy77r3k2tgfeDuZmqkOYvkzjiku
0Ypb8ZbvbihlQxsXNxdMse9Io8nsRBnnL52cgs+5QwZywcBgQOXaIsOsYmVVW/CL+H9ZT3sfAXSO
PyJC6IiVecN+6WLjDAIy4GSAekgXHDs5mS8S1waarHT8IKy9hQv5pWQ958DAuoyjN1gYmPaOmn1i
VILVdFWg5/GnlUEKa1+4MSEDS4Z/7aRe420KR58XLt/qivO2zekzl0QNcTzkOJ65CozuExFnbEjC
8lVTYMPsTe3ZaHpxmdro4NqEvgt18/6y3uOd/zuPaVTUk1uz8dE6ZDZ/aa3smQo9VuGJhObTG3l/
lQW+OeqANKYa0m+Lr64hw3NWCU+T0ge53M961bB0N/l/WM7yQTyXt3OaTM9VFPQlA6i7g12PaWSJ
XuAuA0RVHn+Bqenb3PQQQ/L40jGMBV/ap8g5jZRnFwFxfrLWRnNFLkTQncDxgvL0kt4uNygUVIGH
Z3wxtRAKayqxoFrC3xhxeJuIUn17Pxzp4zZ7i+Lhn8boIC6i/DCfBP4unLxcpZDrxeJd17uj7C4E
6+auqRlqq0NHWKZat0EOKLIszgYZc5eX9qNDd+8X5f0HlNmYxNqkkAnlwIAhuqEoM4zsNntynBTQ
kHM5j0tDtXwOhSCb+Vpq0MOGXAGa8rvx7T5aSe+pN0cAp7HiEqp17S1er90d/bVfHmUIDhPaR7GV
5LkqStz6YWOjIM3xdZWClTGwxjJN1PO6skBFtLVUzcqnWp174NWm7mkWq4DeyHl+DwuRWVuRcGsf
ucpOv3F2Sw7hyimAKlGf0OT5M3InpMIWQ/jp1RVQ/y7f0aTZOR6s7wawBwvzvYym3el9DsdaIp+q
bHb5xMLGCpaBGryRHjLbx6TQgjBHOXOh1ApFEYxi8i8j/ew3srH+b6SXh5wu5Ne/5VlYhrpS4wPH
t7kelO0IR1ElOw0VYrQEY09JSkdc8eSA5Dwsge8RVfGzJQbWMYI1qhfD0rMrkuBBc2baytZPm70G
cqBcUDcA+u0q3xuBWomZn1xh6ogv4AX59FjjeWM+XgyA3xItotykXNdLBHNJt8rRNCkohNcDw/W=