<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzY3M2/IHw40gqlD31VQuGBMJPKXUQsOM+iD2tcEqrSCnO4VEmjkckbHgvFkCXNUzYaWA+sO
Rv3pkNlugJ2ANKNN+vwh/2jhb2PmVDeqkYO/PlRshRooGm3tB8xnPilRvaWuZdjyg+YofXIEl0Ry
4AzRC17KuP+EkUPjyqzrkOkK3z6hDeC3+Mx0bf5WZHV2frSlp8E9MLrm4yZPeeNHLUBN26of/vGZ
uAVIeHOP82l8M80N0gjwn51UZegBo4kfvAljBRoyZYRK/8KGlGXoGEdI70SHcozjnNG/Tjqt71NE
Gabnu4SDlKU43DhwQ56B84pMajHBbgX10gQgIkDGGfeOj7gFDch49z3BwyOT9SF8pBKVbf51AaAM
WKJHQWF9g2ZNo0szRaamBB6IoDczVcea+UP4199pHjNQdyyfpPGZar7ou0yh0QcX7V5L9c8XsJ4k
P/0wNrqN/0Xa0Sn/u6QvbGYyyrGGOq0UcUPPhdL/6ZrExwiaCB/IiJ9aK9bJahX2bW7JcKKh1Bqr
Y1K75DvVvGdOGC7oxKcJs+BkgHy4BpdqRerq4a76duoRfrU5gB6wTQiurz/VwNMTJVhxMRMGz1vj
YijcG2TU+4x7OvO04SehkvWbQasagll45tgVQzwO0BzSpB2XU2V/MnVonn8e5aXYKS+lraVhr4nE
7oVXbnYKMwBZvx90RGQqCMVuV0AqipM24RvwQQtBlGY+DqmifEDCN04Pv57U8UqndXUEs/docPal
nYBE0Jx6JwNcEfG6ifpzO5b7EodwlDtGIGfeluv11OVwJrrmiWWh/2YgMidCaVsN45a2k2RzoUi2
NAJmIuTbfUhXXXbodGQScGHtgKgNgpBikft9wDm+aNq1oyWvHniVigWZpnW8CFczMMeDMEF9od9E
ObH1BdPapfeWkmg69MxkvuDXPB/7qbkwRMWt7xV82MzenwaN/LwfvmZ6Zjf1bmxjq20SaaQYOJPT
wLgaod3+TVE23/zmod0nyOpYSe58FOT+odLN5nkV3IpzjXRKxFzA6Lzk+AdqxIkDhe3lGcbpQK/V
V55sIQzWgTXHgrprwvFKqeZpfKhXHqyu/y5HQXE8dSuJvZ/iQ61sG9OcP2AwEXoxqs8qwA5OEu4q
05HU/7hSOOdz+t09RRtN6yBb1nvtdkwyyBHhn0/cBbkwwhFzVdKhLWJpDUhmSsHfyeRkrhbTgr6d
tHdN6ZSw7SD65p0PaHqZuoV0dvG2PX6yU/7OmSd3GvS27dQsL/CWkNzEBCv8BliTUQUrzpUVJTS4
KWmPJYI04Ir/hs4MBC60Ryj+bW3eG9HCWB6Iwu6hDugN98N2lPv2/+c/B/4Zz2Al1HndaKHzBktS
4SmJLAsNGBuzGAk5yqC2fyiEuv884hPcxO/3JQ7Q91Wu0iUJJ6xj0vtOU+a4oKsEQHK6BAqSn3/e
5IYv4EdGhyC9ttC5mHOQnDUgX4ZaU/PPhKGRaqFHyXkTcjiZbz+u/KGBxMu1DB61R0TEAuryi71b
DaDNasDgDbvyLu2kg4zWooIabos8q32e2ZTEy5vhs/OaobTAMF+MoMHstMEhsJi0uN2MAf7MiQ11
xIIfFpASTbd0NWMcojrZtD4extLv0415U4RpXWGMq/vmfzR8DzI2Ci4o9WmdrjBlByi0MASHDPGq
+GSjy20FpQai5dFU8gKVzLEAULB8ROczkUhbFeY9+O3Zr+wnsIUd377ddD6ZNLr+GGP4U7X6neJB
LkI9Y/8xDtvtcVVvWTKSJPpjqwwOR8s8STDMR2IKjhjB3BlwGkQEb3gu104zgrrgo27Cc5etAzcF
xWpyz1nJWz7D8MTquhggjRi3FfeNvXjs3swfmvqZ8t0vefwQwIbtSjUwp3HIVSjhhUCvXDAPdaYk
2majpLzA6S7M5dfbAKA7W1VunuY7mDFhfApAOsGTaNn0sBHI8dE4Mf3scd01x7Y2qAUg+xYz3Yb7
DbXIrxgGavXB8D7BgjhDqlAjrElJQyxNfhYEXCo6xqPXfYCMttW/4bELBFzb+whCoO9WAjvSUZem
ukKXfVGFOCUo7G5zUp84cVP7hqgOhQ1xjzzVXNxIyxpmQiNWgorbFHD3ra+KcsQh/1m87f5r8X7V
DQk3tzxK4ii/dWAl1f/fEyXEsu2iapgB8Mg/QMnp0HNV8UptvydbnIKD7deoLGIzMLDuux4Amquc
5h9qiISzxN0h5oAMgwr/yKi/4YhJFeGxH9FeSd7FrcEaD0DLiohCfugWHj8ZuvwN/wkgJrRIJOIJ
LPJVBhBl/yTMITwJ+WAT+mZCSfd662BQCREVlyBm/Dngq2Aty40/6wZthwEo3DX4eaR3W8dGCQc9
pXzYfoskivI5UKrm36WM/vfjtS8r901h0z1GbT0kenYSHqSq1cjL2TlGeKZ21nuso9k/mzL7pcn0
7s3rfGfbWEgHY/NasJbM4PiQoA3kv3JmsLKd9k83x7hOVYUaUYtxWYHYCPhsiHxBIDH2IQENKw9t
L0NOJUAkT+iS/oT2avqrywEn+LDa9b349RrErNA4ueRGyt3hxGea+wCGtuQQKYpT5gIUFb3OfE7x
M1J1Lum+2/4KAcgJxQRjOLUTdOpgpbVBj9iPYsPJafdp7qZFRt9sJBsawvaALrv+dyNziLd0cK+J
Y8dZNbyGhJJaMMZdXwibgiurw/6UPa0hM+owMVxTCQqcoDS6z1o2rpI8WtR/i4gGr4rme37lyO1a
RNG5iNP/b90QTBTLV1c0WBNEheMkgkxOt4HxNvDzl5T8H/FkoD/3n8q/7SDq09mM7/iOMk0/GBVD
fEXb8qNoOos0dVSJ3OOSvoOLzySdHF75rnDCt/IoNbNTDeZbku/VFMWgzQBEUUFsC1Z1JRI5WImt
1rJPzJIwW+xZLcgLLrVC4VL0GrzjhpRaka9v87Gh24M5DgrThb5iFS/qv+EqQLwIfRmQCQY9obdJ
2si4BGp9GZ25NCgj4UdjN43n8LBA49Psca0KJZzCns9oN17tlCv3hxKdB/r+eGkTLZ+Nf2M4+X0c
6K6Ggpf5OyvkCVXUjXXaIYJ9M7XYkjJX9L2lnw9RfhhqAysoffVBTYOt6vMLnUWovgYSm7wALJiU
UDFcuN3vA943uX5ESMBMFpjsHX3jtzzVtXs21bqbcriuknEgB/S5DeyJjETQYtK6y6NrcaiImS41
RdDhMAJ70qY8t1OLQnTO/aUvtTzAyY2wTsz1rR9PET+dj5PNnXhHW8YOAtc+885RcNCEulNuyL90
wiM0DzAcThfF2i2sktRDYxi8kaloNMmPKDJ/LrUfP+vfd3YOfi9XZKrJEsKfCCNcXTj0unGLrr96
vL9CWCRUG9NkuDJqka1WfUBTsql2V3qTU41UnkDeWQYu7raCThLK0i1a9Ycuf9D79msT+GpXKtsI
g5yivgM4Lavp7ruNuUvGzcICGuhBOJ/yhDwxrg/HZz+zPa91IsApL7DJwGzF7Uti8/vKxSD4bzf0
EZIcxHIc6t4t+9ItttnrHnF61CjT6vbig9HjOwSNEqFBqVFkbGSw5DDWosJPw1R3GvZiwfGRXrI4
Gkq6PkBLmdy0Mn5g+DvEOU+NA2hte1nqgxEMKfKDHh+sfalKMQzZbGrgRiria4h0Rb9xMLTRR8hm
6S0T9xwH97wcpeogd6kpsw8c7tnka52fE7SFQxGjKzg5FqffJQv1qky6m7BTbc1VJ2UmZBCD7APs
YXC7nX6DUjcVzOX/V0HFTXwxbSrwcLzxk354qP51ToGi3c8+uZAbj454YGjvOgmfGLuj7+aLvlOF
IcIBVI9ajND4n0UBsBNqbLzEuvdg+oEzHdJiFN/priRYQa0YR7rtJz9Y37FQMvoxgzRINMuIH4NP
E6xzcfejLWhu/IjUen7BSgL+zvwB/SnIShLzDIGxNAJuWFTyt7sEizhE2ODepIlIcPMqzZ9crDlL
snwRmoaj4pUrh1acO21iHpTlFJ6Yqp3yA8+Pqmdd2GFbeTX50lAVucd1kFoCJxYnqOAiri/57bRo
AvtP+mP1lmcxXC5U4XR2XGqzm+hshT35smnr2u11jx9nZD0A