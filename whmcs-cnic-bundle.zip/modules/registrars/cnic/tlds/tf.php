<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnsN9y1kCvptTr+ou/tL303UIZZqH177Axcu2/4Ggp6arO1rgNU8ok3z1W8f+S9LqfsXpKSw
aR+mwCD6Vf5NyhPBPfTpMBl7kqEeu5D8NC0ln0fcENrtaIdNqqs4dVAWUNWY7kjxwUahxkPMtnuv
I7Xw75/sdX8HKLWfuMx0CrU8w9Gaa4djKUK6x3NGSoHMHVTtyHxwjxVpVRs/CbPgcHe2pN1/5jyH
plHVs8LOWYMLQOJBYOsZl6Y8zcA3EF9MjGGf6dpVV5iY+qGEdJ7xGhOwLGThsDhWIKBf2xQDKysn
KqTy/wButMW/RHE4YPMO4+b2mHA1Eu89YcJfyPKxy12WJ3fxjY+jH1dh4ibMGd5zzxN6AACUBF5n
mDI3hHATBkdjLfJ/yJPBQ1y5PK4nU0BJtPQilK2tmfQf2rAI75hnEQ4RH9xBCsfUjpuc1od7eurB
ZonBfyLe0IaduT/vzdmg6wAvsQlvoJTEqt9gynXKl/WwYlWOwroaV0JK7zdrprEs3yeLnludM6Mx
dwiYyw6lt7AcaGeFf0P31+fNadOW3GBYFtY9xcq7P5PM7KHdf1GZIePaoDI30PXIqTrHPlTOcUbH
pzYQveXbEZz2iWapOjpa0ProZT9ZqUA7SiY91fHbdruJZc6FiGdrE2NvyH9dIw5My3BLevvHTXFE
aVX1KvWYS8ziXBJ3mbR8/p+4biSuXgP+7I2uV9JDsgegvEJzp9mGaHTvw5unmevQ9h7kRC/sTxW1
Gzls/QbL4jwwHRS0Y6N03hk9EPKZxEPW+Sr/iKZ4TGUPg+DdtJG+WR9x8CTCosm8t2iVmVyaXoVS
rTOeg9edCTH5N55rg6LdQSKLlbLAQFn/igIsPWtdvGZRiKqqusbouFZRc7O/K4q6dnhVfJijJQmk
FZxJNwm+s5BgfKd2UH4E1dvoOzWRYJPrgkinhq3Glt7E45Cmdfp8NwuXqR5Iwu1vzYP0+9yFlVDk
TJDQs13d+nd8MzwoA/+faBgP/eu+58C5B+jsqxtf8FIRpSqjA8woJeYqJnl2I5Bl+uOQ017WsZXp
8XC/XZ4OwyFxFabzQL++k5Rj9un0VpJqbioSUMAhCkjBBcL7U2mHRCqenTTxO1KqJkFU+ENIuFG1
Z2fIQ6TIGRDtMeuIk78jqs8W9uTG07l5DGj2xL44XXV6kmOUbVJCuB2+YzIcs1VV6ueSPQnkPCJK
56Tmqprv9J/WyCj/DtYixLHhkMvvnV5UcvyhmnftaNxW7CtpZMyIvt3D+OY0zJ2TfON4wfC+JOuL
Zthf5lVR2YgXlXZ6lMRst3rjqKLre8Vz6+VJhJq1Y9cu2ouakQNtaFSu1PaJ7Uycc9rn+QgrFeTr
UphElFFRLkZ2zyV96qU6hc+EGaTWmokevD6dDCddW4G2NLHk2ErYWSWqCiKZGvNuCnmUNnOHrrKp
sNXGnGex+2M94vIp9sG+tEqjJPM3HKSr8znnA2vzKGsZSspqaMTSdDG8eIK02Ba7jd/vbSQIcNOl
lVtKifkNut9KlU30He+Wyn8/wva6NOwR35BxKnx9BE8R6dx1f+DiJI97laRxCzWPDXvMHx6/nweD
E/ZMkmD5QhIopk1//UFnHYOS9wB1Oa61oQqV9D/XExQoW777kdB6FgF+9yXMibgEMqELNgOwrHO9
1Ft9ldHSdgwGMgzpyLPataGcg5gV6zDM1cbA8dyKZu/q1guVvLY7TFLyeUuqHjGvL88E/xGbZNE4
66lOdbQyrOYORjtgRMUAcbcpO7SjNQUJvZA42a0adkUXNXdf+6TlpOpiuw7dO3s2IyMAN8TyHJSH
pJtdrm8Qri9pN3Zr7e7STvOuWlQP5twokBKAZc2Zci2YHYZcKfcBysnk2lsbPzyFwQ0zpVoDYur1
uWf4is1oeFZsLMEM0WaOr0cmdZDjh4M7RxW+L6633nM2XneDzBQrbLY9HWjK6AqSt/lT1p1fGaxo
wzLxYS55im+L4SOYbbzvAY1i8CJOLCiP1Kjf18paj8FOq1UdbY3YDFucv+IQkIVqD/zrtSZ3t+T6
lCARV3Y17qZDOTmcc6lFltbOYuYN9q8W2zSYtpLQNyROQtpGbMyilCQILBp5daMKJjBBOk5Cs5FD
gVJOdHDDwcF6wpwED52Lc9pCIrbEyKXAheD8fSv88X5WMh9GxU5e5SvNqOLWXPJJazFUP/KMNdT7
DpBrp/zEC6KvvUa6rfseKctEWnEVVLwocjZPbqBeYTjyqqZ/thSeeN6zfOLCimYt+MaMGni/6qX/
inNs0B1xlSVdLp/TNDLyJCsU1Prxgy79pU6gPB5fUar8NYL0q3JetIit8jnOqgTeQ19KtVtiGIcM
tO/bAdPff18eHy0AZr826HUFBU0H/tX42O7wweROTBFbC6HDJp5RfaCGWoex5OfM4iCRiwWU/SvK
dw7LrR6q7fK7ebM/KDIT60liU1ZcX/eUQnE6/kmnsHQKkgLwLU2Ubgagc9y7wal92PeZOlJsxp5Y
plVqR/NccB590aShioNaf/ZjcL2bWjUvHcoUuhjM3paxoNfDQpNYqt8nKYGFWalJj0LpYYcqhxiQ
6ZNh+OlCSB88VpNJRF9Ee4SGc+B89a7aKobTakhUGEi9cbMVpDAPclUMjKk0onMVZcyWtJUz+kts
iBP4Gjjp/mDfEG322KqbHTyPn0cAj+tv11FVAxrXbQlxeWPbAhW/QmusYtWh2IG131WYk2gx8zlD
mYXScmdGWcQODvBlgC+Rjyx42Cja/TjMY6o8EPYwSA+MqVgGl8DIg7/2eHrm2QGKca0X9hC4+Iqx
5sJTOzYpg1h8yljhntwnstvpfHqxL1ulW+u5Yz4N3UvMu/25OU0jtxsYb10YxtsuhVre6fVoYeCE
8iPHeNf4j19zmzDNJ2G0NVpspe3juEFjvukEbA95nkEVE3u2DzNN68s+/IstKWCHEhETAbn9GXbQ
HXQyS7BhypC4GRaWtyY775ekrXWfE8BeXMfwZp/TCG8NtdhNa7bHB2IIssFCd+qclX43PYR2GDpo
VbOvH6833Ao6vNwQ7xlPizinH1gus9WglYYk4OhJuk9iyFuLu/KzVIG0b2YcOEx4QxTU5xNNqHsu
/5JaqPqWDqMXSowZuVBBurS8Dr50Qj2iozKQAyXLNyfssccEckozw4wlHJ3mEZMEaZHx1JT67tat
w26FL8t5Ut2WXUtEfSfOrf3/n0lavDv8PFRh9PAyQPH2lRHSOwKMaxeh90cUY/uDI38+3OgHJbfq
1iVwX0mZx9vdckKYSW2h78BjIyvuUY9ymKpYQTWbnbNytpLM9NxxcYjx0MtN/YXWRfjLio0BD9la
CFMsGEU90yRdQOiSQna+Zc/+fdRtzz9m5/NhFxmdAKNKvscbo7Keu4MOtJSx8Z8fAWW+YKcxBV0g
g2OM/+4VeDmKViWXvV3ifqk6A1XvDhGtTDLwhfD3V6uWbDvL7rJtuebVt/NoU2DSJywhnm5+M6/0
9FVsew057XhOt4t7Zslocde0rlLITNPI6s0gnTmpa2YOgiZi6WeIkpchRelFQx5yGzNxfG2S0KtW
mWGACPSC867pTU+TNuYY9gDoZw3bdonytVeP2y9cz8dsLog30FNWe3cwPs7oqFoDOIZT27TgnhUU
PzZWqqGYOo1ZOEdeIeAsooz73WQPinbgza6cFMW02/01l5+M07rMMgPenrADgPTJAEYAPRF98zr2
5C07hlIhTIhSWO6MAoLAPnfjcCs6++iPphsmtS7TJ590U6Q4Nh1hqfQ0Z5YP3hpLSXsoGU5T5ttt
o99Furekq0Dp/08oQcl6rmaApnwRKWbfqm1VfJFbOjHCRlOqLyo0rfBrHQNFZCY15bnGHr0eqZVy
khuIWJuvWob/IcBdwQHUFL2sNFdxyAxrM1yVurDdjjeIPq/TclLzFPsGuqQrkVHLNnkz2Gen5+dE
+34z6aTM/q/XTSf/t3XmE6sBuoB16lXIk6wTUpBqNaxoOdpDkqcQJRNHPc94BlCq4EXPQCwMjTbd
W7Rl8tYw73Vtc5XAbITHRY6EznkS50UPGsud8XxJJUIc1twfwq6vVun7TG==