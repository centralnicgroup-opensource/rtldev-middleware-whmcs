<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt/uNUTaOgR8SJ38nDgSRwzudKDrCpPsJlLKusholqLIySRnQPVAX0NUHeejNcjt8TJXgHHN
0Edsq/wVqQBYOCddcAdSzGd43s9dfdsp0AM9FNjsyHHxpGAQPrjieSU/UYv27SVXACcA9T6pSqQd
X6DFePXf+5kveWqx6gb8+lDO1K6/6nvXfi9sUZ/4eYf2ZX8+VPU7DpcvSpvhmF2CIW1SoJQjdfze
VGyV7ZHYxF8xY+XYVh9PleY2+WZqGgKNMAIuSAk0rGu0s8UjyA3g/K7By0aARHigIsC3YCTgNi46
yPyc2qUezJy80w0fX08lW8bQ5LSsYhYGOX53QHMKHhwyMCP4LrLwtXsDnF3j9gvJLCOuiXBEJGHX
oNQ6v2zwXEXHcNRTAS+qmDYzMOjxKBU9PiIq1Zcoh3+QRJtB256f67ZgehpBAEVjy+2ohirlC/B6
utHbuLpjnuslxCUrA9EW97xrO93NVSdsPUuHhw224GX3LMFJMKhlUu5WzP2SYuwQDmeU/TItDLv+
JQQ30+4LWlWLCXunIlZKTMj+Oe18D0mvcYeOglx+eCqJSYPied/Pev9by1k5d0dUuFtQracwVQFv
WbdIeL6EgvFA7bTpVO2+bbl3qb7biLJJVMLVHVSfJlilGNGJ/sfS54bQaQlyVR12zB7Cyk3bfvVh
8x0bXTe3iXXWI2jhBd5Dsit/OzzGUVNTWEns2gqUGCEecNe1GTlpVE74/SroqUH2iC0SwJ0rCwbQ
VS8RW5qzW5wnQm3VBWGPlqqPfd8zRtuPVjWivwlEUE0D7r6UVrqGNrkrpPt4NUr6XhRi9x2KV9Y5
cgTIcRlQly0P/xGU/cABTWagbgU2LAcGVhqYlodO7zYa17DWFzHsm9eH0shPzOoutL7v7tPYqLb1
Vxg99ZU9QaqXG+jlJUV0CvCNxUxqaChF2z8NS3N96eaWb1Y/egBNvVvdeyT0g4D1w3ca8HY1fDO5
0i2mKUzI/qV/+iVf2rZHktkoQjaMKi48b3xq3mmrFPE0JADKfO7Ipvk7NG6zWko1UY3fEZNDnxgn
qBOVywP1oc9dXxFBSRtKhh3Y4cxeq5AFc2W1R7O+q3Ql01IkxqEJflQuAhGMNhA8QDWCh2hdC9sB
MY6IPkV4w7WASdIzhpxXtEvjK48tr9h2X0sEa5XrN1GAv1O2WeSC6RnU0bCdxqlcdPnANDL2ahmW
EpDk9bQq3SCfrulmJ6PJd8MdujJipwB3zwZarzQor1zl9BcxBmZTjQWWiTPufbmQX6qPO6l9xBbr
trnikznXm+FMYCLzfIFCxZwP8bVzakWmggtpvvmdva388dip29MyxwOTa111+z8TsgnKj6FxoonY
5HL3ziKb7+VcuX9WZ+CRj2dJ2gr1MwkWMfWMhhW+Sx3WmYGlkZyO7bL6GcNs4BGtoswLAo703gz0
smQZfYF3UN/86kZTrzngYq0R7fEniYSlVVccqNdjQnvhvGn/0UURLj5aBdjzpoFqzqaARoH3gdhA
0ZhwXRvJh6/hCgBQi53zYeZY5M76Gpl7KcZxDIwqAWkj2Y3cEoOhAGxTrCThm1EUXeFEd617VJsi
mH4QqPk+80tTrPwrfwmjRh/wRIQX4tp4OEvGdozs+w6+bbye8zVuxVdQJqhUw5JyEgHnBhL66MBa
EjojbK9o1mZf2Ci7820t/zaxAPONH/ddjO7zeLpRhCo/65nqNTjQlbGt0qYIxRVF2KIKHekjad3R
vXdouPB1FzmQPEQwu2fDFoNFMT1i30BNMU7uL0c4uAfblzhSElK8W29hx/61fXDIxAVDhx/59a24
X7uIC3L54NNATEKjLRBuC2rhlFMF/GnQ+xYItksqDRhhJQ3nWOkr0CtnMqyGLbEe5iKkEKbTCZXH
L7ZBiiO7ZaLvYUpLjSDQrC9Cr+zpUZP7ldl+ITpzCkEC6d3lItniE+y2WD0onR5dDj7vPB58lAms
ZWmXSwpb6oUhFiqO31mRA1sMKYWpxq58/Lh+YCdDRKanmvHu8Y8UvoIaM1qG5anbaqVSnCXcnxnq
5shAR9qqP+wonRdo/ks2YL7m+iF1I25Yu8PeBBGdE3KZDcIG9DUfS3vRah8Ci43BLEWrK+mLzGDD
R8tx4zIbrFWRJwcu4o8T9WRrsOH9K5xJRTtL2McwlapnxBo8Yb4k6hPpu+foaQuVAiEf9DmpGQxF
dK8/NHYJ5+s+0r/wbPr3VIg0FICQ/fluzSNs81/7iEf7MqSCqd+k9QyD5K/1LJTVQXrVFx7s1J/P
GqvwBYniBgqZGRkdkQ+l40w8cpS2pvhtXaUufiAGwb69xzMIMv/ibJwTjai+FMIdZ+WpN2sv3pxU
FqJdIu/PXHLsidKB+k3X/wkt8QJJGe7GO1BfgjHleWKWn1HbMES7JYxgME13mW8iJCD9JVGdVU3B
Mf3Owz/HZ3MU6MKMTykMERyo5L8u0rKabe86wMBkPd2Op6hzLK6NvTcoN5Bupp4DQsecFIel8r8x
ofsKT6G22TJVyEjsNlJV96hxpqZArD4nl/vFg4ETl4ACXJUtG9JRuVpAbbjONmkkorMaxPDE7r76
Lk7L4IPRM4vxJkpBP84P7LfTOZuF5/8mJYsgI+1D4gkdmAG1XeW6qyOSk3hLAyXsZdTdodusY09h
BX4MGeRmDqMxYiaL5NkFJbyKsULD21+02wlZh7LBq5o/HSck2KkBQbPfXf2svHXMHbmNJ/82E8bD
k0rzDUQNCKmmmLV956LZ+lSR5bJTm+kBFKwfVv/f9WFdlb0RhE3nXUXGFnmck4GF33K3x1M7QmQr
NCEr43t2F/Cu73S1EnPDN4+NAJeYwuPTbqf9KIAhx1opwXEnnnIo4hM8mXfLWpXbE7C7ypDzqPf8
L8pHbtw9o6iP99H4wSnNZn4kYQgO95m+p+2tuoXSrW9kTplcAqmDW3L7fwWO1Xg4fc3pHxkoD4J3
qZDA1KkkMavSLgxs98eHO87zhIg8iCmex7rpV9IGtsnnWuYU6T1QORM3vM6BIgHOcCy1EDA9UJeI
B/VCrI0N2ypPcs22HqZ7l81Pec4ZEl5pJoudDGl/OW/aZVESQRfHvJi9Ezm85WPIuqfWI+vRfKgc
YBkRRh9OYubOs6JKB9OGPuCm1yselAf5PKlTTzL8A9MKZFafhI5OfXzNnS43ajrRdpuhYZsIP+ZG
ILt+Jl/zTTPRk92G1OU5mLwIXUG/X5E0Z2QyxUR0jT30ri1LIrXtQH80YZEo1jki4zG2QydcTY23
baDyAETQ/YfyCWU/5g6zA7l31tqDt7ewksy+ZLWOXwZgR67CuB+16pLTM3arTDLlxv7PGOjYNA0Z
LrAou4loqetQnehlbvDrIft2ww8WY88HZody08/NhsgyzCOYYqvk9VVYaxmxHzukchITNp5DUxem
HF/kmoHORemY1pf64pNsie1XV+GLw3RzSTyBXnek+iLlOJbUKD+9KuAzlCBkLstKQwkE72eJmMLK
8rSIAq4t/rZ8M9pGnGK/MiBdCmSPEgobRhbkIybNFy+XsU51oz4UMyJGsmgbDnoSFuNccwzVO2mQ
Ibjmt54Q+R2tbat547GObxvagzSBaxov79Hq2Qs1nxCz3cKdPlxcEV2vuBpt1EXn6RmKZRAi6jCc
OT47k233rbAGYF1Deetf8H3AMGtjhznEhd4voWtvkTOEdJiV59872/F2JH8YoGk8oIrwgRmjlcI9
HH6LQS+mMdPXykPUBwLll/LOLxAjjGs6fzU1FyXs/qt8MYLUg2Cz4jekxP2Yef0GXrBi5TkfBf6q
gdP3ysfD1e7+TZdvBovr8AXiCNLArnX/cSRtu/viJLP2qQ6nO99/QVuTBr0DNiLnSfNfqPfH4VF0
Jj/gCMihtJ6O5Y2GBdngr6nGpQN3XDnTt8YILj7ni7PgooaXCp9NA0PJUDTIpzKSprojotA6eM8o
IvyqSaE5nYJr1bdITiHiPdjpFJMzlQWHTScXGqM2rsI7jdlBkylCsMM2TW8mY/VjqwwCKF0HDt4g
KYnLqsQqnANPyCM0utTUkQ/p6nYU6+xU7sW+4igVaTZWO6iKl66PBcGHUR9O9pZ3J+2DuA9/jzWn
gGq6KsjcIePbjHsBw3K=