<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtG1nszenJj0TSbIJ6UXwxyM44DdSVlzllGINm3b+6kofkBCwi9l0WQlXws2jwK4mmmDbHU+
Y1Vf6V2F4xu5iLqr5X0cPbyh8Kyn+0FRGH6hL1Tnja4tumuGMbzmNpy9YNFVJCIP0pXWYbO3c3cX
zierOOd30P9GoVTn/h151sEoYogBYOC7VXro7s3FXFNehSouK/X5d1bEKPRvEKnxZefQeq3ySyK6
nW/jd2XbablcPnNY3tDiEtRgbcXQkngWgW4TkwrS5tMYy3cFZ8SoiT8/1a0wOO18iGntU7RssgBE
XwM5J/+ceVW1K3bfvIeEP0sBUJvvG1scUXtlQS7okwrAHBeGw6MF+ZyGTPmzN0ausC2B/N+864+3
k1QAtdCmQ8xQBkGZ0mpvvSzYaXUIUY6cc6pqdiZbm3IAazXTev6cwhAWDTvKbsbW2QTWmQnFDooy
iDv98Ax00iz1d2l13WytdQ3XYkubUpHwKboBXRtXYm6Ck5hUaF+4zMLDhu/SyRVWFMpVXxKvbvZu
5KjUK+bmaqdr5DmjeofSgKtSTtJ6OsPl0ZyfOcrAUhuCv1MweRgxRdrQt+o7y7mVn/OAzus9y6KX
XqnOw4wLq24K+3OuHn+vTQY1VOAAZnmCOR4nnbA+RWzvhwP2j5rddxW9PJA5XLSk/2Uwfj0u6T22
PkuL0hKTdm2lSgOFucGb6XTIbWfa9m/VQyndLfByiQPN5L0+fDuXWC6NfGarGWuxMSrPiHZJNmAn
jBZNjWnEoi3e53Et7uI0QFhesv+efWz8SLpYb8kRCLzCYdg0q+3mg+iD1KtxXYFkA5TyInlc9uWF
h2dn21cVrOqfo0kJ0dZIloXEASYQHbWE/xBCPa42GWmjspi7aHEPRtzFVWHDOBCICEvOKk+KQVBT
c4Jn2gYuyiXKmGwORvG/R+B9Bi6GeUuVz8k7TAq2UekUMpaYgECPIvizO8OGLcGDBm6FbmV5DpMn
NnU5rzaH83/nkHvuqtqiKC9i0ifTaUFwr0qQhBYM1EkzBl74lvut+L7mHZaRdkSgfGwLQLwKN0Jr
Gbf2An3YA5ZN11cvFVoTGs5yUKz1UmF+Cl0q65UuASunfrnU5gIccgS2w1KZ43bqaxEHWMTUt3eB
JKA4CNSacgux/KVptj14pOoNvGsp0NRHveoo01IGLQjDL5Nza91U3EmZ6+LKP7c8fnaF8649RDSh
U6onJm+DyzWaEiFSAiYFXQYXrhIz25ywUVeVEbY6XWBhkWoHJ3hEWJ/82E6NzkbI1wzRTpHzEYaf
x6DZ8V4UX/w2Ptk7dmbb/aKnJgXu59ylSmtccQFavGQPTascDS642N9uzIzQgLBuHzwzo6PM4uak
USmzgEc35qV6ek1cTLtzvPkfl7I6/EAyQj+s4fu8i2hgXMv0xRyLe0eqXBIktvpIZ1yatiYCFOfL
zcpZVHpf9pUxDsU704Gs2vgqp21BT5jU+et+eUXAQKf59n+7ZCjWVAw9z10qTJ6ZSoTT9QL4rIz7
QseaQ7LAru93WhvlOy7/1EPOXMr/Mr+R9b9/O7PrYsZw8Is4zNLCxP3hAbVgez4JSdiQ27DnKzS9
JNAgBYyY1M9uvd0PJfAjpy/omrl0bNi0m93GMaLmFrK0pqnrGiiH64tDzHQdA+l0LBrTiCp7tBvw
PEU6m8xvPMnKdwgvAVlyCcKm/wEJJUT6HFa2cXuSlAACbOa6NSiu3p8RbRZRjl/Txfq7DPhN8uGl
BLmjia5q4mYQPtDErCkvgJO8+MVR1mUgjlgqYOsDb4upKwA+9obouTOSJP5PfrmaA03M0VE6oUuS
GSPCnL+9VxzbALmhDwbn0ofS6SV/QKgZI3/b0VEm85ag5QoI6qlkAlQ8TXyLzlTLWP/S1ZbQmsLq
heao/cM7v8fpw1pixIShL4ggUzci5LH7wWh8i1nxvmifFws4ppyGvqu7i2d5FXXBq8s3J3PWuK/c
71QdB6RAYBw5hiS+/AmgJt24NyNdAacyMW3KCiEjb4FwZ3X35z28OG45U/k8K44pxT8Q8ha9McRQ
1EzOAJVivOtGTNVcxlgx2UKEIoGOda9GIYGBDREU/cFwZCxAbsN6r42uWSaIEcSNU9lhL2i+Qzgc
QjxpXu7s6LWSeOomB6czSc0KXc6EutQAu40jUMzo04ZcJY/W6go+XlKg+zS1bc7IUpv0DXT14jR1
MuhcXxmjbddBIigK1nMkD/xiFHxDXRCU1TcVtIqXsfqDO0ITyZsTYZI5kPu2P4sXzzzYPNY8bD++
XfxUV4z9G1Sveb//OhHETP8poL3E/5ucI8UPAVaUQpZBXGyre1n85pYE823tOma2nCuTSL56CH+y
5oVIs763+JZNsCQ43WHyHABx0d1yTxLCUZYbG/+Q3sBHnnQuw3GrqLcWd6kFDuyT3kEo1u1m+5cP
c+9BVVcmUaVHGcmWZRZLGXezl1u337qsR2tg9gm7wegVJQYAq8YRdRM02KCk1L8xYfcdc/WjGvLC
6TF1wlJDcn622nF7CFcDriiCvbEheiadJqrwvUBnzQDxXvxf8O9ySvbKhGbS03WCVoSNTX0cvimq
YUQaXGLQ1oEplbFt3SxePnCxqeFWCLeKmmzP/F3xakUMtrEti/3MO3fKpSn8UQIbl17T9iF5dewW
xoJMoQP9nrEcLSM6vIJHqco9mq5TryjHQmM6wy1+Hu0fLDBZIcyC6wMXWfE+TTiqnn0IicqrtNKx
5CCPMfos7DtqYwwquk6vxpXGBDOgczGa0iHzXEjmvt7X9bP1Utx3l9C/WZaiukrxmM8ClNcWBDuI
w0pALWFz/IWh6cUyqCK99VZ3mkf1psY7sIQVAOz2J1NZsu52z/V6C96ZIp9IvSy5MIAEaRRvXDUn
dXZnzXDRZxfl1UL5cLzw8HjaQU8TQaSYTWy8+JGQC7RII6RIE0rl301ZW/160hHykWj4utthLlnp
DhFweFRIr4pS3ym3eP5g7W3L0HDOmUprBzftNmpmRteQe72MYo2ok5fm4w40ohfRex7htYuHFruQ
A33SMsCUAOV2thgzWSztXCwst95J0vfXPdgvVcV8qNPsimx/q18hBaDcdx657a7wAXqRkV2gYnxk
hmSvy3dfGWrwqvrKGdBGdhMOJUaYGozmOnOF/y3BdmGAx/ybkEnL1yj/s5rpQvYuKBYIeF5zr1JZ
kJ63jkwOey7dJL2mhTnB++DljEijTQCHC7OA+vHeIMs+w+vyNFvljOnrTDFhPDxIfuVlIFHOG3lO
6B3iOYtPVboySVk9uqov9e5kugVv/93eE2gVM5S2OaFRaRnHFGzo/U5NcMwKsGaUfKWFtz30qbDB
9Ua2pP3hvS0AiYuRBNW1PiYrsZaSvd4/IPtfASRvUrrK1vFQa/980E7plrqSZF4VrGRC77iDmYBE
9WPRE7bE5P2pnG+BRAjcaI6/dUr7LqQJAbabaYxZFjsmRcI0XyDyaXL6/qMZkk7i272KZ9f+QjEA
ZejQWVLGqGCMeQmeG6KuoTpYpd7XgAlK+1sW4/TAuMBAqdY7G+ov/NMj9JKwZXjkVxFgzWUcHubz
LRkddmko3p4Kc/B9Z01mwEmhWjOG46uGiE+2W1t08YEKjKOMX+QL8Ib3tGonMRaCZx5G+wkKBWcR
fnU+C+ZSHMoHWupkqj8wLGsZKMc6I/tJ9FvNJwLyyZflV0aiRseuz+U8SzpQ9mrWgIbsJud04oeW
qDLUEzo0C3TtnRq2KpTxtYVITRoc2K9jGFrwbayZLeKY8zb8gvcEZlavY5LCQuw+YNodwY8+Rbl3
hBtjD+xmrK55jHymwPqWDiZHf0/XgkkDpMDJRulklkYRa2hKKJlCpBvgKV8NnISYFHOSpu1Z0imY
B8oLFSc+gWNO3Unw2SNDG5np/41BflrBpSUfVoNSciqaoqBnsE2H1hY33x6IvtD2+x04dEQsIkTk
Yk+kjnk/x8MPc7Tsf6cl/EdJ/dvjN7P6BPwxe8S5b8FybUC24th4A/Wu4RQ9W1I2o3w0d3PyNMJN
22o3CMElS/VFFd8szVUKgNX/X2NwFYYBRpLT8Yo5y2U6gnGopgGn2jcHpY1L2AU4NhHocvlzwEN8
9LLEpZwoIv3c+0NTEGRPTGq6CECtXFgle7605Wy=