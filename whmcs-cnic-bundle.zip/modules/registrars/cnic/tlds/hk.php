<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxYkB/ltE9JyZcQwsFycWcqLxsLJDodttfUuYH7yLpSV7Ai/3jc8Di6O7ac/eYbgWcj/7VUO
HnMN5qXgGt3qpYoUhKGjiujX6mi6GEjyKoZiCpgbLdwgfDryuyPD6d3JcO04i7lcaIr6y7Vg7uJp
rF1hYVzG2ZlUBtB/PAUD/NeISJFlfYxdHHFb62hIYkE2arzqxqbP3BcceDoFT/ruvZ72uTDMQ2Tp
TFZ47VfwFWjN20ucKTFuSC7V8J+hqjw/Z6o16dpVV5iY+qGEdJ7xGhOwLLrfabHvk1eSmPTxTyqH
WKT3Piw+nqco2LEM/wzrywdIPjccG/g+32NsCMMou6bz74nsx/RSHldrmlMeISSWChYXMogmEQHf
PP6VVg3BwHDIc6SGSMbSGRsT/UbhW+ImXTDh4EXdZNnmHjopfi2A932twArGCprY3uFaQKkd9Csk
t1TtcR3mMuVY/yBJPCHdjogD5f+EhOv/taXLt1wiL/qh81GaiAtOjyg4jDzMKVT5d2ETH/yzFPcm
ndr/jeKqf57wG1+XECU98bTCGEjwlWvUqDA3e9CJQNcXkNitvkZBg/SkERqu6AXcrP8x1x8Yn/r2
UpOXc0DXMPPR/W9OyCCr/4DGGYbMWIyD3q0IPrRiAokCj8raoXugpJR8HAIb2BpfWBQL8OD4jn6G
EKzNeXSh+hC5GFSfTdHRCBQCNem+QwlgdcGwKQoJNhv80wDSfQa5OwyrFlIFxbqq0p8ztEUh/pUw
6tCMD4kikvFPHu+swlhyogZMbbVs0xrAkPdeetD26uojC8f8s11c+ZVVkG7JVM+Aw34xC9hM489J
gI1+0P/uWYRwzbCawsrV/9EOB5rJGKf0TJVH0RacUZUq7iczLiiLhAG64nw5G1NJQfxHC1jUDez/
1TmWXlKCNw8Hk7jMZxqghNuu/f14jFg0WGrGhb6lFx9aR8VVZ45rbInvVXHsXTZxQ4KFDMQ4XvfA
T209pW1/OvkeFIsmT3/HDEZKj9xQsF9VMitbKKXPbt8tVRFgHz8mrmwnVhs4pg6w/K9+/zAVXWfF
fNewGMnF11wy24oyGxSec2ksLnxvPs5OueF9cpacOuqW6jcz/Z86L8d1tmzMLe5GMUn1cTdN3lFJ
RvTaTwtjMAbxzUA/EST4J13WDbDANj9QZ+B82BYMcVRb4D/VkZ5aP92Du5Ctjjig8gk7X5SVr1cM
4Svo+D3dXtOT0bSly0qG9yzuZ1qToOFmogRXJtD6V9wtDUC5SUeAGLMYLcY8kAS1uL7XpEbmevwV
lMOaKPjOMYMqiSNbb2V/CNI95R15b5a85fDhN9vYT6OQnQPrs+MU+r8k+4XrzRnxPsOAeLhda8Tj
rXPnnXXAIisHgPYo7jeGxqUbPHvepAJmLIoz7aWQSENGJIbuZvczXBmMJLxTO7ndiBuVUF0kh85S
KYYbbw7srvlJv4V6JUBCekE5qeK+X4QTIfh4tmTiBfbtBjn04DsRe9sWDvQojwd/4SdO4pGhO8AS
1qRx3UkATDFCm4JgByY43dbz1qCHCsM5ITbXl9NKu0RX/v/Z2BpCZZUUqRl1r9wSu+MepDasUl9D
mC+NlaTNCHOrLAX+auxBMcEZCPj30TRaPjnzWlBgte/h7zsTeuEXaQCfq/xcWieL+C7o/cQ1511N
mg/PMLp+/8lIRxeIw10xVA9fuSAbH+5IrCYmIN+Qz8ITny+4epK8vf7W8u6CaSmGS4ZjJhDWBlDr
gsI1eqvOBiTqcp4likI6hbkg2xI41Tm6z02IyMqkwLneNuhkpUQsy360nMY3UnUmSrIz7607N424
WaC9/T8luTcfviVjKJJahLIlAd4TcdGad7u888h7vSla72Fc38Xj3dys3nwbXnBlKJ4oSy72Z9Fx
/jc6LkaB7ML3iGak3hAiovF3CDxbTK2WCT6qgsk95oo2gRkBB1/tY0yY09PmIHPtpmjqYcoZMS9C
cH5Pkf5ECqZhaaStAj1vEqoueKAEbcJNSh5wo3JlAfI2UGBJKot7//nmaEFa0y6bn1hfR2pYt1N/
AamJx9oRBhrqlVBcPYeELq25Z2fMusc6oyQY9YNC6S089SiYAm0HmIvoldIZqIE6gqmsUf8anyTx
WPYQmAMffI/9p3CvS0zrusCZry8M4uBflIS81bibi/KdfzACMPNI7qGDhU8YFWl2fz0ekBEIQJhn
TRv0bJgZBDFkBsU2wnIj5q9giIbQI6obUMu04rPljVw+8R5wEiMJgvBSkhwYnLWKN53vV/6AipzF
cH0OEaZVImpsO5uco9Bbb8qoGE7x9BdOAfJGxhAei+5C29LHudOgnx2AIXSQSiCPlJeRlmL4J5C5
b5YzL+83Rk1NGv54jFFKdMuT8BAC+Zb7ojZz4qsratYOdd6UA6+Ajqq7xJblUTSRVL8j2djzGo7r
isBWDnP5811y/Z5pWiANGs4BYSxjiIY0dcvaYqQMt3C3cz7qU77dIbd0/3iEzl2Wf9EwGx4mEiDi
JUvfnFiYly2DAZc1juZsY3DwDNZjRp24WAqD1B6U7kDURRgdjWbz2GFsNt3sGgcS+qeWvPvPbjp4
/gpxNgXyHdcUJa03eDH1hMoGBO6JcnCRkVbeAopFnzoGeyd9Kh4X1EyvzRKkzy6mDOHK6UgrwAnV
dgqVqx0nd9mYqrvhgjGla1QJaC2qCaxm0TqingZoAT6TyCTU2/zl5AwFgAcTf0HGWYnsOMYVXzBh
jljTmrFvhVR5wX71LitYqpVF15KqNqG3r5IhaRSPZBJ5fJj9i+juuEMr/lrR9qRxuhOO2zJpU7dI
JfARFQX5noLe6NivFtLfwqRocOOf7Gqbi8u4pcQZJnMg2Teu/MJYbDxgSNUFDM+2qyWEYbSOvTAO
vXFct9KNMQj50WJzIbeD4AgC/QfUInonvV+VxgGObHPXT9ou9QeWAlL6OCvswcsJiBfWoAWiXnCD
cbJGNvnyLZuoGuOnxkZfd5xnf4FwoINW5InImfrPRJkcyNlrPiJ2PehCSOlpWrudV73XUg96URxw
aYAo+bdTH7KGf5+PopL2HdOMyaNgBify/T2Z1VMDNvr+b1+QrStX9rVK6aeVWJkL29AGp9JtG+BW
uv66Kiyhwc16wcsShVCNcXSoDmGMwGJc8y5rzcU479RB/GZqmer0DE5oiJDy/GTQsnlyqc1jor+C
dA311+qTs/N0tmIpnNa6JaEWy/bIfN2PAbRElCOejrRsfSg9IYWg3wQ20LDZDqWEVPWinai5CiRA
RDYJ1NY/EyoeMz9/ph37C/vAgf/aQsJiDCuBVsTtB+OMcIcDhSNrCtiPCfp5Pf79Q2+xj+2Qtp/1
qyL+mpZTTe5XSiWZBw5QUOodKpQkXKJwyHbSCUyI4EdmKcH7qrK+wbRvfcdIzDfBuFzzMCor5RJt
pTwlmw5kEIVJJJSwgiT8b4jN5DGBKp+QiIMavbMNePUqZ6wWtKixccgoiSIPMTi353RlSGwSRxgH
wqF/hIhIm66gZQL/U/2/CFSDmCrafledNEp0CFWqaonRsLS2Yn8clY9u9NmfJR3AExxFUaehosMw
mBiBfiJtgCFrPsVk/ZSgI2LruQW9p99kpdO/xyr030ZNxOfrxS7fVe2ATtFYgxuw3H+j+S7MDOkY
uer5QRMai0dwZOtzhIvkPQDavl8Prv+4H4kEisj8/04GLTBXWc7awzrU4o15LEHZWHJAJV3LqUkH
BK5vL7KFEx5Gq2sCN1ZBJGahowQ9yb8ojhybGBf2bWedic6SsmqNbeJggEaVIK1dG1kg83xVLq1h
6DqtefbyPrCL02adx+y47+5sdSAdtV77y2xMme/bkC/NFf9v9vKAmEBiTaowT15/g/oIquzs3h2F
ovgKMjAVh3jgr4KgvUHshDc/v+mxRYz/27FSdgP+Xwvd96PiPkyzgIGzBgcEiEHq4LpYpd+GhzAm
qvb1CidmxBDC66h+OKZ1YybkLB4nQK0A6w3ZwELqnOM0V2xhWe4m4DLvRVxDORtk34jiQB1dFfej
APlT8KfyWOL7cnOgYn8nH7DOxIWvUymoo1YRUZ4DCuZoNwu8vjePm50ix7pTw6mEy0NUhRMMxDFp
6xH6Hnyik4v8n6NYOsuG/aYakrT0g4i9jqbdZE9o2+tyjREvwrq=