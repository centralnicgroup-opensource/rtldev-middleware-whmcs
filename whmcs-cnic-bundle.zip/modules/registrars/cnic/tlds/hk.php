<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr4AbQcmtssEJS80YeWEX1Bk04WwsyJczewuB8mE4u02KbgZVzuwkd3ILbN8ooDh0jwK6Pod
NCVwsvZ/kr7ImxTfLwrOM78bxefFpwUwC3XDfbG9ZiOmpjkQgfTr/iUTuvK5W5WBX4ZkSTCKajfI
GOQ5+t2LVj5JKXkSi9da1yzGPrInAsUwPBNlCr80ChaNdDpvODd6ho7r539PMqAIhDpTInQ8kVED
L0BHbbuU5zA41Ihe8ljrIWZYC7NUtzft99NMI8rG6HoI3gSU9NxHfA0EL1LeWgRbL8zacXpv5NKn
IATMyyG5Iq6/qXLwxuOKsDHBLZqzWPTACaagZ9pb6q7vM15Lap93PdZCkwm9kEXxR3Drs6fYIiuS
Agn+CZ4qxIDsRU68wTGDuqZDo9BJV2AsTXcdl223p2lE9mQpvmH9fuxjjh5BUbtEr6Y5zX/+P3f5
h3aSFpvxZ3Z7I99Lwq2uAIWdLJC6RinXI+RFMGG8gJzqapYlGAy66k6qfDOmapjCeKZNPNGh5ggT
GDARN/ak4csyv3JZ54gk/IEDZfqQAXsXtHPTeoGD1hhBlHvDZQ7h7zuLc35YZtPX+7bWQXOjHdIC
AkbGeBb6rjz8/xX2nUFWD4X6jPP6U0ldRWrmw4K2ghqB7HZ//fcXWuGQsHyLI7gcgqGDhSsr4yL6
Li9rR89u4RTEXxCGT4Uq7QeAwbbofOeKkbv2OQiYUDNUyQ9j35SFW9nzjQFIW7FfnGzfnG9CQSeF
Z1DOW13NsB5OWCmF/sg6kE/n6Q2TMdALwGNqtaL0NKRZ1frsRQz9s9fsfWbzVp4GmF5f7FUV3zmj
w4JbP4W4VvsFRvvj9VCGrnnuRhOKTLPvAnjnVcjRepN0xmk6+6NvrYziE4jTOWD4UBPSRSSV2ia5
Ha+b8D7n3BQtwRO1AQN3qttP3ztd/42kzsVUrvVM3hpycGog4EEWcZMfWff+0rNjTU1OqVoDIXnc
D8d3b3++J/yb11fMX6meTpCkSzE6sxkHGnbZXSUCnf5l74wo6b0ZGa7BduNx+UXd21MrtdhMKJtO
rUAlAMh1RFu4l6nJkFAzApj4baCUr0MSTik9z03INfSzRnbzz07AGn/yZ7+TwhzFEvnqUU+zkNtq
L3LApa05uXdcBkbdShH/wvkWChPAwxkZ1txLuBmkKRNjIBzsRJDjaVkTfu1XlzThv6468vwfMODY
0amDlrh25DS4O3l5VD9etsSkUXYFFrF8Z9m9a5dcnnfsaD8s2UU1ls8sYezBe00TKlIpvyRT6rkh
Uf+be788X2JeqLRMyxOG37Gzj28UcOpeBPS8ol0FW903hDSo/xMaT4mDwvt8cQbCuqA//8httb8w
HewlKDluYg1bj6/suOyxtpTBCacPOUnCd5FCieVohKAeQNAkjgbyByZFfOi6KhbkgqPgqAW5yhMZ
fs38WPsigNSOUEWslV0zmgOiwP1wg/DtBkqsP/LOwveXEQxJEJzbCKQwhcbulNDCSv8xOvZegNof
/MgVzDbmZU5kRd9jN8BYW863PRUnROp7yt9QHMDjgmB8yCD96EDdBr+Jx9dCLTYmRekY9LSBcFQl
3ooDSU/TvyOkXVba5OEuADA652st9nqbmwHy6XjRTRhzzHA4RpRKelwDCUyT7CQdr+KZd+zMgTlz
SdqWh6Elk2IoyLknAqvo14xGrhcD+aB74skQ84+AIgs8AVG49KcrLIYrE/FrkGSdtd0Lzm98lLxi
FL7kBbOBuq3GP62bPv3t1cHSGAn21B1KO4tFAomhXKePxzRv8/6jpVYRiUgjm1f4824x8KGsBwBu
n44XC3FUePj9OYUGlclcGxw2lThP+SBQy3fKDg3NfwwVCl/0U00YcM0TzzFjDvaY7p1L4KFF5JJv
+3zpOnlblrRGUEIwboMk7OJU5qoqYDPb6LB1W/EKtNH1943dXwLJGDC7iuGVv0H7zZjMyTtKh3J9
2Lp9FYdAPk/Bc1TLQLrwWh1XnadBmo5T0nouyIPgJReMVqF3eODSTl+zvl2B9MsAGZ7QyVs5e9fZ
yj72N+UgZ1NyWKzSbdDP3E2Qh47xYQ4lEAQsMSznPus9ts6NrSpz8lUACi8TPsv4+qYx5WYEId/5
V256i8BMWB+ibbOdUiV4uC9zkZIzaxjfKmAy1waCk1IJLKXoFSjdCXXXXHIznJ6hiJyqQ1SnSw9P
Od+49idCmNGY4mTQz4vXozBuxezsI7AQIvkNzI4Zo0e13aITKCNvk9jJwGF0GIHVW6vnMWDZFyWo
DlHK9ydZkFDAflEWQwZh51oZdniNC1S1YYTjMzCjBtf9pmChDHnEpDe/Eu5LE8wFjM7PuOHijGAY
AInsnt6T8cAXQLTbbgMpj5cxQFgTg32A+lPgNjZg+mqBtvFZNuITvUNBfop08Bst3o2rCQOCkl+8
NOYDJt0zwcQt+abl4pveZin3/2S2VPUYkl4ApaAXpLkoKVZcSLoxYBGAtwB6m00JiLth2kpC2VU6
pB/C5EDKFSOxhbCXeVsPEfnd1kkcWtuGfCvH4J6SjBzXOU102fiRx3xdMRPYeDJcyeLuC6XaCRS9
ovOf+ucoGOAJBzteqvahuXhRn33tC6Sd+qgwqIX+lWj8YULQjfCQ6X49EQwZqQja6VxNxeQi/v6p
HmdyVF5gZABEzDkBrj948QEgFfZjWjq0+7vqo+fE7k0E4pzs8IEWt5THD1HGgmSN24AoOXLeU/da
v/YVTasHKNd9gP5O/qmnhWXJ/VfLRsdwYnEdYhvywqXR1R05R/cm57s+P61uccpei8vKL06plxJj
luV4hzdEkM83tKkKZrwkrfm0AnKSOAFZbn2w2ZjLGvDqIyaDqg825SbJ4FYegEvG7GT8aegFmcb4
ZSTQJ7nZhrRobWqE6QXyq91FtE1enBCgvZ9VoV1bDgnoD7lc4rSHHDfndC4X6bJP7D2DViJGmH6X
WOKCcTe2jzxDThP41nyJocvR8YuD1gdhIHCm72DXEg2l8x3/ztj0whaosbHB8aH8v9sV6vXQ939o
Et7Ud9/3VkQ/rm4NQGKJo8WTQlzvvljh28YxzxQyGIy4avrp6IjZZBYYu1tkxAc8D88BYqWJDfxw
dFdJj/3TR0q2Om/XS/8CS5vwwG/fhNd1Uwbdv8zFusCVAnEi7g++rETP+LxVz1LV236e8D0RRXOh
tUX2mQ83CzkDB9Or6+QAVzyUK/JTYll/cy/uAwcyz0Z951mCwKvNJvwinhFuGQr8XH4S4I4P4HXr
WAcdRRjKDhdin/In5zC43k1P+cIlSKGcdBaDd3lyPzdXLnF8bm+5TAcWbyN8hJQ/ygQsFMgFSMS/
7J9OcKBH41A1ZfpTYh3B511Vxr52v8kNraHLxzCh3sUl0blxGlryS2gBM0RMn0br/oVDdsCSYcZQ
aSQ3KAiPsr4sKxLxVOeKmQZT8Jb4oWuF60zP7KpHo991WYPLN2qXeNLC2i5zBoJlOkNVkhYpdI8l
9PppEg/2OgvGshlQKClj46I2h77SjP6wL5lwoOUooRofGCAJhhmSDGk+gakFAirCDG6fjdA+CG3Z
jj1HROeIdH7tf9KCzB3PIR0CotSUHFcGOyASEb2tuNYZlnb5n3br2s1we0SF79JdXqXHJ8NFB1I2
TmGlx1sJkM+DekYugs6k7ZTAY7tWnKyhg9nQvtBcqcVGIY9UdrjnRO4XkKAFTwjz41NG6GICPN8Q
8pWWbqp+tRf0/LxeixQVDrSRtpla53HPB6Ai96843U+6zLtKFajbOt5C3He+FLXr/yxn+UaOqSZk
n5G2lYxcy29eq7saIseiVq6oFwAMACo2JHPOIYg32vGAsu9Lg/IbSWmnCPKRDAXT7ShqnpwYwm4O
ICDzZy2zqpI1lD5Mtmg1i++2YqVdq8Lmi/cwTRhQnD/3zwTlfa3d2CwgFsCZoONMZ17ROtmq0sok
2FEvrTKPU/QuMK96tDVHCXXCqeBCYCSmy7SMjDrfPKVYRJUY68UU1hr7wOASAV1mLC+1GkwPWPs8
lNf7ug1maUt+dX/SSmF+BLfr7G+5ctDr6eCn33Eu6z0o+3JvBUu+5ZtXYH8j7a0gLP98FGfTA0LP
6qfB2QXxhis5e38=