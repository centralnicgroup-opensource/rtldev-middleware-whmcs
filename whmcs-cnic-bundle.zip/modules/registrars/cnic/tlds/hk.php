<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqn1ht6211H6MuawKlFIqvcWmiIsn/BdGf+u736Gr/LgcthVpfPPev+Qe0e1hYV74761uJ+d
uROrqLlGKwpY/rxNPsetql7+8EteS1bwGvRQAxjMJJjJ+tTZcqDFjtazzbdt2zCrR4+TEvQMSSQ9
AmK0xtRwueDBNBgxb1Pk43XUGpO4NYxHm7EQNf5c0kz9XKYoeFX92rv3qjI6DnJJGp4j+IqvBqBH
nFpl5jegSfYYNyG1vqFVvpWFdNHv7eFG2o6ESjssbBeja4egBIOQXBJ+E3Den9xCETPhc59K8q8T
BQSN/otJIVXjyewsxnQqvHkYpvB6zJYWro2SMdI9aNo7Ef1NVHwQkqb1OOqTwedth3UaIksGo4FO
Llnv2qPPcEvjQ5a8K5K8El1cr9Dl37gX+1g3bBI+mtjp3+KiVUIsyELu/E4rRdZkMmqw+4n4j3Ff
MFCmRz48xYL0nSwuP7MokpOU2xoFK7JbW/ekKJC3fAjya5hY1nAdqDCt6zoYOndVXd743OmsiD8l
rgkreSL7yd2XBR+fI/UWQRQiq56BAixZ0Q68oCDDslpnDKpPFHs7roXTlfzMq7tjyodxVwpJkqYT
HtyYIuSOFGeU1JavPE4BtylRn0LKDxZxlnMTIpAsAJ7/xVYRnbVgRuuKEJjBp8599QVGlDvv8OK+
fM5ABzbw3gDKgwb6TebRD7HQFPavmh4ne3F+VFqYVx9dNlHogas3hv9bpGEx6a5HDOdO0XpswhJN
i2jkwo7lADX9psTU4ScY0sj5c3foprKsMfNsgudczNfd4XNqCiSxi/euDUBp1OS7Pa0AG4epyE+W
KHxa2yOZ6+iwNPIz9nulpW9baFLS1E9UMQb9rLZ4FqciOYA7Bfj9mLpEBUsPj0W/5q5qu9HtDYbi
GvRt9Qn0yAo/+d7WayCfE8L39OYKYxwKavr+3AqZTmdHAwk+hhKnw0+lK0VGyELSwk4fz5MaezZ5
LB5mBVzMJsffQyrON1XjSusplKrd/UN7O0E/voXHCLEXYT8381SLx7ZXG+vM3dUJ/YobHHq9/kNN
8kp8iUkLEiY2kgNdcatCPcrNgRa/6uY4/Vcu3Y9S+jhPYNcxAu6CxqcL7oVf5j0ASZ94CP+JfhCe
R2oRze64PwrbqQmnONRtzm3/Si+toww5ECQLBW79Koyjvne7GGjkD6ollwQyTQ0R2v2xBstIzSej
tt40Afd9ICYJxQakJsndyvR4i/hupBkUyOA/NW25fOtDXS/b0AOjRbzDw6KQZBvaRc7sX5fKPj63
td+AJxV8PtiHXMG3pMElJPRjRkM4d/RiJQlSNI8m/ID7ryH3lhCKIBKtGFgGUw3/P4vv7radH+Zw
hXgsAdJiu8zWCW29CW6RAzJTk11RGooquCmt8ZSF9S1OHvnIC5cNa5imJ80h/+xLSnpY2cG28xsL
P7CLvIi4b3DgddJjdxnfD0gegoh2OYuMFMV91K2sKntmSyfh3eMQzBilGFxy7o9M9IBEvUXi8jrc
jrequFTuLi2BQhvj24RwMsvBfHCo5srPMeyknxwLfnCR59p/ly/EtiUqgDdnVBNf/AMh1i4bn3ce
R3aJm/zv9pdkjyPAodKC5xjP+iMtXwqt8Ak2dEEkZ+gnx4LG5XftCXu30SxMZ7dmvutRX4CHSgbR
b+OU1Ypq1xfy7Gh/Wh/yef/NrW/nOk/DRCM4m49E9e6z0yD0C9BRFcC3ycy03fa8wrlr1Lksg9Go
axGgV86HS5iKHqhlWOPyofrmjA+pA4L9KlWKbb0qc6icgjNrJVvAMbnT3dmMEA2es2tmXzVTcmGZ
mZ9DQgKW46tv5MKbLUYq3/OMCJBgVkj4sIbzGSVcznJV3y2pf6B0E9PkLCzU2Qr6nLW/dBPGQ899
J7ypup0tSelW10OUGQXlbznG8wnkxGatJzWYDWJNiNo1ic4/DSCq1FvdV6Z55zOFFwEsJyenQ5XW
wvN2LQ2AMDQq1kO4R4l/Wgr/oxIpPDvEQiJOlmPJiv61TZB5JIHCBx+Jp1wBtJdnd6CmlMbd/qcL
rjMrYxvSQINb9DxmjgEZfmI+pkRNUJgaUIcedE1C3Psf++hQJnko3i3j5Hp0f8FJQgEoV/zKBcNG
/GfGMSpdyGkXgllHXyQqcwy5MMcGu65uMrcmGXWAUzRrTM3TmewRFvvgBiqk86OQxRUC13qNfpi1
CEwtYGUdqLCbvVUjiKRROeX6LSG+KiuKDdSmB2TmNBTLrPdqv1WUWar5tXq52OnjUIEoBIs0EuBL
Dxg8ee+wAJzlThukkp9tmswV821ifOUTKiDtvYskmLavKoqwmXJ3a+8gOC2kERUllx5KYtyW05f+
1wpUq23SB3eqEIY6W18N/tl8tfnl8qkHnCG9RwVPiVb+L1acmCVzz5VdQLxKeTzio9AcCyGYD1JQ
iL86f4OuUOugz3qJS+9c9l6cULDFtVPpxMS7Rp8ZK2F60TChsm+agi54/2Bh7CcmC5eMzld33h9h
mtQ11nJU6MIvvpiIoVg4WAyBgbjUsadYysuWe+blJSfrZmF00Z5M3w0bZRiBaQcjqfpTaIk/Pdja
vOF9d+Z+XCCFQ3zusXtFUmRBKPc/hussI8agE1wtw1MN6hjZpvuH2yt35ARFx3uU3G5Ff5gH5L1p
DvXrS+MXtAwsIVWafGrEg0O56u5Qiu7Tw1MZM4zFSGa1ir4mIfrLWzKlKtxNLdntCtbPBxZRY8co
d9IO9BVEMKa+oo8tKX+NcF20N0e5YCUXkuWMA5FDSp/FV6p2hdHn8YHQtgW44f7cWVCLYv3Q2+FY
maPfMV6bIYc7b3MYu+jnB+VamV9LQhF24HwajFJnIILzLQlGsU+LRwJe4iZkr8lzaQPRZT4TFdOs
dNpAKcD0G94tXUy+1xVmCKprmUVa1er3ttpsBmSSC8dMUhO0/QjQZ3alX+AZTEQiVyF+tZS3HFDE
jJ2FdwQ/o71JFgLoVm2DdKpMyejA7R/LP3KeIdE5/N6Uqd0dAcZ6YdQlm2zrTblv3c70cAiAIPbS
UyAqlrf4acAcc+8gIBgwZPez2VyRHPJa09HVMZW2S89oTYZi/jVA/I34aazR8MfLPoa10GD5DEdz
5hBJXiibJGVJ7+wEevMvsQvHWS8aYlz3jH41YinTLOu+YE+UxOvmLm2RB8uFudy0Q7fPFrnGDVTp
BPXOgZL917S1ji6pw57QphGx31mmVLqASUuaAofHmkopbMOq0XawJmw7r2Tt2Y2VOJz28GcBLBSf
+og9baRubUjD+EIqlEB7a2JJcCohXUr3zEJ1cKMS3WWHcvV0Sp69CcgFoBKh6sppWWzkJ8MwYMxD
Z8XclWcPFJA0vUwGyn9DngATLVIcuzznATD184PQwkUC9skJg0Ml+coqNAL3lFzP/msXWtYe52T1
ETqq4aiYwSapqiCRoQ5umYyB08d23T0kGJd1QrF87dOX3builOLmpgZOS0GunrU/3BXKLwvaz6V8
Eo7WPzhIz2SDul/SRWCqlAvD6x33SY2KvjGBSGMxhFRpUKGh9bCT+fFdsag0+Z5VT5tkZMDqhb5c
WBht7zluTUBE5XN60gOCP1yYVhfhlcVm7uELmgq9TGT/lZL1bnh5bXe+MXVb+kHWxKdmgZ7+jrbu
2QNB+IrtiKqvn5YL3nxjG80kc6SOQI8XST8oV75E1yeBQM0Bgh+XEB0dkmgFLTM1vOwGpgH79YCX
g7ky5iSAIYazby2zszc/4mHMK9WGJVwj6AW+64nTQ+ladtQPAdtViOrf8egMNjWzG0lQfqncIGMk
a2IUUypXlyyAD2A6RQZjk2bJrHWsRtcvo2SPlfY1DLx5sctOl/2BSUK4fjH/SJdB1KpXsKauYMzY
n6jxhM0dtufwgvR1+hL9/rIycbwmC5JZD5Fe0JreEEHgQhL8qP6GK5KwRYHDnbxZ1H4w4cDofB+G
tBdLHWeHmiKS7UIbXI2RNceAfJDFVmARWHler1q+z7mYUG7/jalHuzsVRHe683EsQWbHy0pdxGJ0
H01m5G2iGZ8MjzH6V/jabjZ0g8KfeHBqvCQTi6dL83FjM1mNfCPaHKBgYTlov+cSVGK8K6+HuGeJ
Oj2jcNnaCG==