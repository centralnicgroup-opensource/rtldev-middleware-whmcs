<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyBUbOWvY6wln1O0gxXjxRgShsm4knV08AcuJsydig1cxyDELViwDAYCRxEcak7hwHIM/U73
L9s53/z5zO7VxhG6pvo6TErzfYvN2wzh3iI7ucdG9Pf6XtX9GTGTNS/IR5Wr06dWpGk7Lf2J7F0Y
kOo/q8uZq9acxt2rDG/codXycWd5XNIVsjeaNlDem6JdQb3gRA2dBa1pqY2sPjE13JFfDjAq2rNI
JtWN4HdymZWETDjT9Ql1U2dB+NzkHvT5vyxzcBlKA6H8ahe357dMXSM94p9ju/4a/D4GTSl4bqvI
rCKYI8x5Zvbv1CVFu3euxY0Qc566kIbatQ8NKTFnvdhp0Kc2x+Gw2QRaJ2Ves67apgAD2TUnNyeO
BvF+m5UoUrsSKWu14FD/Yo525eBFEBPEGZ1RVG4EEi4oMOGlLhRAarD2nb1O4O0WzPLosAKPf9L4
6xbBvnlDDRF9yuoOyim/1jxzXRkyo1Vp1waEnty/N/Jl+yqnndUsyJdLWHB7JGVX/c1Ibbtn87Qb
13L0Op/YKuZJfIRcJVbixwLwTMZ1n/TXZ+zpmum/TzrK0F2LVHWoVpXuwH7Iq7ERYCLgj+mgpmLQ
JNtPmkekLvdnB4hLEn5XdVU3EsYDAiwTywAZqztIlEQCG6P6ZQ6zgc6taHgu6QgdazzAQXsPRx+t
SfwzL94dJdnwVAcKzMrdtUWmAhnooGBuqRdnjJv+8rG+jp8eRGY/k84MIZR9yGtQyOQJUxXQHhcs
IaG+3U4VHWVefKAe9/UU2zmzb84lxLK5kXgK/XJPd3uAeWqFwKrl+QZRnqbb0okp9kcKyeyJrE7l
6kb08TxqtBDJlEoMTrXiwnSderz7jOBI3bto3xMNO7F/J7z3HM+zaJbNbu7Zc/B5luP3MBuzqhDH
ApHuUygXpIYmWRN1ZL9qpNuDllnrrXaIm256uLX5a2Ezy/AIjn1tz2Zxk1j6I6jyLT+iYqtK/ttp
y3bzXgrJEdlU0VzjMQAkN0onVJ3R1Jx2K/nf7g1xozQGQ5SDzjN5BKYDKacTQztM15Pz5UlD7rcu
VmNBa11Dlhx4tJCZXOOdYE12aZY9QEiAVUzz++ryfT8T8Qc/ASWeCNC6bGNJKg1PIYWSYmXJIWhf
Dqh/NRgfDKDZWXvCaxCrEHK72RsM10p+A2TRZruOcBDgW97b/1bE9aM9sZbfnZMNbFdokUFlGYGV
+JaNLobH7KMAJ0I/mkEQpugE8pUE61Z9xpRNl9sheqNgY0xIdNmJEaQDc7K3cXAcWJ08LKpV3Pkg
Lz94rkWUXOtEgjGm1e+OWadd6pGtXeSjfQ5PoNDWfEL/L9pyeRf7/m3cvcDb2YyiKQ5chvaS++SN
JcDmuumGBW761HmZwJ7hvIVTRa1vfu9LMKkoIwY8hgDBWp7mXjXriTsbpeeVjk5d7UelcKeFfKS/
iaT8mNmbdgYorNtKtTvZLnAOl1VU4fYxohCBmhBP/IBpm/tgHC8EGcHhFy0IL3MJfoaj0BpQTNR3
cGsxTrpy6/50TTxmcI9cjfHE7+BQUBx8CoprzsUCFh0zBIbWIkwonqilTWf9DEt3uPYCbFI8JKc2
AjYKW3S3Tssz6K9ILW82NtpVDZyR+mfOzoRiHqX8JPhi8blNrJRAaazkzHrqH762ShkpfTK4RMJd
Ye1d/bSve9+6T6B/+cuMXvW+3U7u1++Nmk4E6SMtUDsbM+ySkNdB8kyP8GiAhdM9m0phw8Qdp3zC
Pn+19yQU5rSNrYoY7HpDJMGqOH32mMRCZ50GGxkrhJlGbBR9YYw3RwgU+BGG1rkWG+JOKKgVyv9I
uITrt4ZaEiKk+ivv3sHGZIh+HETtGDrVC0cmcrQ6CIZtbFp4PmIYkqUa9qo39eSSSJGv8aEjcUrN
Wg6tJDiszuxl5j7gjr6XT2PUkb+6sYFrEK0UD8PV5IaMZUIOlxl5dOUo2KWzc8DFhb1plam4tX0w
B5gMisjq0XOfw2zHep+prs7dL+RUmkxZ2RwUeGDKepFYSp/Fb0Kv20P21i2l+6Q8I6tu/rT3mP35
unfPoKLvco+fZn85U3bp8695YA05CHuRElAbFO4MKGibCeGByPhPHhXkyTiNadKZatitAV2K2knD
Wq4SwjVDoc1B6wF1gcUHASjx6AtuHYatG2dt7dU+fW2PiDvmwHb2H66JPDgd/2paaugzvw+TIeDL
VMzlAis7N/mqHxH83px+A15x5p1Z1/fa6IeFTRtVKWATMYNYN25ejcGh5xdgaHNyuSvr6WY/Q5ku
kMIT9Jt4nbbuqPoC+HwgKsbOxsnVbLEzyJGlFM1XcODr7yWFqD8pjAv8COvExnkfnoy5JE2sUKeR
v9iBebHaOXsr8B5VUW0wfIaCANKKHZB33DXrP1c2ONLZtphGJFDGqqanhHUBY60a7E2NYFdsa9zX
uuaLgZUKHOycECrtBdTEXxSv7X3iXa83i+8/095DydSd9Dy/FgD50NsYPJCBtSqDwoRD9qvMbHsW
tx3WOOCBUX8V0Ky/b8H/2Nq/AHrvqwht7uiwNOaOVgfvjVRi2ywtgx5Lj8JC1aRSHi0vpao3Vy3b
lQaTe+YcJihYHPe/JaBaIG0CkfIiRrnhOgnpIAoa1S5y3xvAqRKW9sBSmafcVSJoIQBvfvNVtB9v
ZojhuD8QS/MXnhxHp/j3JYvu+/ibPGcEQoKM+G1x3pAGHsVujtqXB94EjCG6iOiFiHS40CuQ5vUB
HFf8go6Ulq27+fkkHjuv/tTgl9HXGsE3AtnnEkuk9RONuYr1I6RHrH5nHvo2iDMzAyH/UiRGV0kg
JHZ/tQe7v9P1gJMSzlDiqfur3+XwlwnmcSqbd6/szyijdMuRGwSGy9Pzh5uMVSRae9ISa+280s2N
oeGokz0atTj8WnD6BMlYXSGFDZ23GpGhX44ei5wiKFfYxal/qi+wKhHQkmPE7Q2+RmeWMqw0woVh
9TibWLApyOvlDJZHD96Cs/sq0xrurwK/96rnh7Fa5ixG7TTs5UrPxLvdsrXRW6W8Mn2wlJ9SNCW2
5mJEQ6kcpCANgQpwAnbm1XFYQoIzseNiHQd2ngD/NYQRl+gflYxAW9gCm0hGiER1c8TImzn0VdOR
nRS+iZRtzIR3NAFGlqrrMJXakXnMTvUGaLHszPPM3MlvRDKOH8OO2iXQy95mApjaxMvVR6C4XQWM
XWVQc7lFSxwy/LH8qPK4MEfartvU49lk6SWm9d2oJGL5e1ShzfeEl6q42QvEGwqV7rp2zjM2vEgm
/GZImkmqD7KB0U4B/f3XVhETdQzE6McoXGfELHe6pnVUMf/twSmGROK9bAE7Mx55iBnfZWDOLXxa
3RZEAlRrJTdXcen8VwC7yLKhxB4fA6n5qawlqpw43OyTkOiOc5C/676mkkDicD1NjkrFBgWtLOLa
/pt5b3PclZeaWsXXZzXh7mNNoRn5n8nDclM0q7UOPLXyGP6cZZsjvAXLWPeBpUv9bPYFmc64W/ws
/sn9ze9kxPcS1ziC8UFKXqv5SfXIZGUgSjPU+tHBBiLU0g0RFhGWxQyJPOv+xg69Ick/5Wp8naCg
DJ90jmJS5ZFohmwikRflKjUsBzta1JCWETMbVULAIMy+7LMrbTDMyvz6poIP/OaSmHsKrijOya+6
ppXeseBZMuep0aVxi3r4xqE9epde1YiigcdYdg4EO7u+jEyIy4mwL9nKgPgwOesrpU6UEl6enxt/
9yXEBPu3qM9MNJ5WlDmXkE4lqpD3etjFOv7Eqo4knjUBkjmjTkleOSsPZ2unHJu0jfcWQSg3VaZa
wz+fjHxt0benuH+O3l+/oJP+1u4z0ohRnzy35naR41XHTdNWjoPHWXlTsuXCWXOZ7Z7Iwxl3bhiA
IChJBp3v8kU3xoz6BIsBEOWS4xicwjbwAtyqkrncidmZqbhDVeljMRMNKlGwtwTqVt+wO3B50PFe
1dsAlic9Z0zIwyqEo69RnEfas1cYy4qIrez66bvI54cb1FLqiScvPwgqzezNmm18VFAI92fYytnf
ghmAKdR8onsHwFzhDd3wL5pnL+k86Wa99gb8ruBpbtPQN98YeS8EUU3aoFUr0FgJqXAloDHCkGfV
5s4pRZev4JrJUGR8aT/Jz8opEN/2G0==