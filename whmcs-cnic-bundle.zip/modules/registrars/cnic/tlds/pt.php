<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqYCnN7qK3v6WJvGKZlv+L1BRgqzneA5ugQuMX8D2aFAHF9Wcp+qBasG6XC3b9rtHJHQplhE
XsDSx0n/zFlITJiINqD2t+uw/QluhGBTv0Yy36pdStNtNTJTE6BdqSTwvgzosi+0K2+Dy1BVZ+mw
V8/ia2f9WUCrNYAw5YaokRRfaM6jsLrhi/nM8STy/0mtH6x4aQCzB1sFv8aKNpWBVmuaqfOCbZRt
w76BX+/23BGbvL0VwzIMT3awii4cRI+SaY4uIdtbqdmqCchhCinmfHNvkaPfyMmcooSsZ92DimTn
18OswRDKKLf1SfD3HrivkEqTp55DWZcHgKnP+zJgGpaWT1D4aewCiRZKfFxullYgdpl6/yTdoMHj
Ws29t3/cKjwQwiqD1+ufKm4m6FbMN9G5OKvzMt6C4bxBRcEB/vHYzdsF0LSIUjMAKlazNGNtP1Eb
sfQ4HlPZKYRt+rzzvnHO9aIPvo6vOEVKqoEYfb3qHxLwtVRkL9f9vGEkx7Rnc8E79jmBLghV11XD
/qxWa9Uq4LkkLwDpsKtjXs/fA9HiSAykmFkPaRmBccYe1wY+orkoZIt94sK43RlYmtjtIkuZv7sq
ogrT3yKu6KHTbkT55Hhyc+2iOUu99KsvZQEi28rj28Xgdt0pmvcxhGD34I69J71GW/h44rYJJBX8
mOqG7+8pg9DWCmAQdIBm5lliull/c8TYwDB6B4PUa2evo/XmJP1a5f1xkoOF30wrOim6aTX3cJZc
ViEORuTlZ6khPJRQqFX4qqtFYtHbrJI0nX+VNdtXftv1o7j6sdzHJn5ZEzbWEXhwbTwxDfcq3Y1G
qQids3GRuhHGarBdaF94zmSMU6X5DPbrX+MpSn7r/tCY1ST8hP2Sr8PIgwmeSbg7EMjHzeGk7n9Y
33dScfSn9XYtTho0DzbQH0jUrV8oVM8adCD4ZPfYnUZXzkzoUKjWf8HQAp2a4kvuz1yzYC3N2igl
D+f3/JDmLvzYDlzYzR4aUl0jmQQ1ZS2uGqbAcC9XeNaprBB2jYaTfdbcrHypBYAucv3eLHrkyCJt
/bCRTs+k3AmR3WYOBnNlD/Cli8LVqu3jk9qjTBiI+N+Zr8CKtCK4hvy+u/ieJjZcBPdn77bYJnhs
LRv6bQpD25bGwWr+9Vypt1ySNSu5VuZQHLvDE41H0bFzWZXEkRUZNKHRZuce84OpcxSZJDHYuwjy
UW/2u5B8SMDaDkHwdriFdbMV5YBLNSERnqcAdAfnGYaJieK2fH2FrOZvkbUlVfQwmB/G4BGnnIoR
um+ulwpjskB8VecalyyLqBLE1ma68Zry+yzQlrPjuBdyExyBLW96/salvfKZ2vp6IOhj+kcdg8ja
icop1FG+0PLCJYivo8vpCaWdVqAO+n/4D/44d2xkQ7l0zEEPmWVt0nz/kDZPSDWXc6Jws3qridWB
MMXXlMHjZtAsaanEErxgGWRKb3/X3SertZegYun64du0VqwhzXR5t7r34TAZMNIVGOqSWHvuuGi+
/zFTwgu81zyU7yBj9dv6VAV8eoz6fZahyd8FeicwlAx96vmA8m0bXhkbBnKgKeRClyHJlMhxgPe0
M/HNgdamTDRlESB0GQP7DWS2PgwQFvzrUdfs1bu2JBC9mGy1Z9RnM1rTBInHOPhGIBypDLSWu3qw
Qdz53qguuhQlfp5aGNvrB9/orhyj5+wh5gRMDU295DG5THMR20Usdl26hG/56hV4u5B8HT5P76Ok
7B35JWy++YGbBCpxRj8jlUBfceAK5iBF9flbG6IQ0LSimihLygOF9zhn2TC1P2G+CeOooXXPORSI
BJut