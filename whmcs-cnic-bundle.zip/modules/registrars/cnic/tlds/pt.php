<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv/uNlY6HwF/U5zAozi4CoaelOHxyLNOnBIuk2B2vHvhqehFfeNB+6bLNK+SCkASK82/pEFO
9ldVUeoNrtXOuyvekfpLi+DhGtMqAvhw7JDrwe/4A9yftIRD2017u1JG/rCBnr91z7xlDviwStqi
Z8+2Ixo1FpbklJ/hcdLNyZz3ja3NKQeeB2Z7unGH8yMb/NRtGsJEkt9XOEuxOFLF5xT72MitkcdA
X+zMVYxYT2/vDTilcmZjb+cAILSIWXETgp5lcBlKA6H8ahe357dMXSM94y1i7ESsQHNCOdDMu4uY
AqO4mar83F5mCM4AdFp1noVl2Dib2WD2aw3E9GmgRgyUA0K9bOdtqEZYRWMzdfOTVmYZ5dEwKGCx
kFxIDcYXHa54bZTGtHN6f/+q4j9e3U1GOtnO5VFHxuv+juLLQs8FY5CSQnV9Ec9nOeOhbV0+LTG2
qxamvOSLWyKwtL09pH8CrVYvtO8QUMRuK5byCf0COXhYGOOPkqBEHLYlFNWFgvpiExZG5LtVup/m
MNXlO/9YJo0RFYQY2JHXnzUzV+5xVzsTj0rFXFiDEt15u0ybgIHLA5JQgpB7g9Z6hr4le/JgTUE2
3smtuki49ZYsRB91rVi3Iic2SXlrJC9Y5zmVc/6J4kU31m6qRSBCaFr3kWDFA4WffRU+mPYC5CVv
zLuufG3RCWaDmgV2apuP/8INkwY5TURBVNrgvj2y6H0213tGRvwVJlIvKhYWFUMx2mZDGnzhKVIn
jL7NqRP6UjZV9w0xWClPvc5xovRR/rmbvSHtRHFl/I8BpRlSmwDWL8lB65PfxZ7GezpziZ+N7dy3
/nqIbSUGEkBO3Q1pPFmBNXb5llny5cVkOr/w+iyXAGXHhBhxISFfDi5jTUV+qroaKngo510Wh1ej
PghidesbQJilQkhylr0kqdc7TSApTQyxN48eNpLkxTasCvum8xJhiG+1ZNZduJE9Q7wUnJ60dPlg
FNAWADfhwzKG87q115Z/8OFTCfv6IgeT8Qr1yFS250y8tXsft1kAUeyLIQq0VfDJRoveg6tbP7Ra
EzjM4VXFK43ta29jEWy+H00jn6KKVDY3SYow+wNGOwnDV2TpqtQ/b2kwN62bWVXr1M6y9nTn+HCM
SLkPx1UGgIyqkl7RSiRhcBMCL0sfdkMb8I30M6c/mAj897lB1mFLMPp6nPlbZVYNlrKbWOb1z9oC
uU/oY3JML4acsrOB5eRgb4WJEg00jjE0KZceFSH9smrE5ik0/tYUx7HZCN791V3pKo71iBKwjA+W
2ofqdt3Y0nwTm4gg/gbaTur4iLMHGIa7aH8jGXpnnNnO6sj4ogpJX92K1/zAUw2JLM4VwVJAs6Lm
x3syxjKa38rvSz10NdzftEK6MeBlUAuEAHp9NyEJGRht+X1Djr2gNL0B6cnjzrYuk4bA6eGOE3yU
oANct8NfiXmjGLhb67QVJtHxPOTL0XCVv2i9ThB1LoW5/jr57G4qOBUD3UVFuzQGWkkCuCsgoaGL
yQ9FWtGQsKU1u2MtorV6aD4lpdUvMKrBJ2ixt9NktFJAdvuIQUBVL5NrdsKDuLIt95ycMNNbe311
LKIdyMmHJz+ogP46Q4rB9DsbS9H1knuOzcXcgKBD9mFK65Mne89Mk2Q61gM8/GeSEl9LwEK/yZvQ
LY5hEHDgXS9CAGg1ksvlAjdgZAgJ2M4pS99EbIJgBlvfUmB9yJPykeyMw1H7GIVOzOteLC1Fb55R
yeyI8ZYThqr4otiSY1JjGe5v+/0fng8AhBIP4buONkKErSr/WNvJu3e1G3kAPnDm+DfnwDxTOxHw
sPQzjAVFBV/37m==