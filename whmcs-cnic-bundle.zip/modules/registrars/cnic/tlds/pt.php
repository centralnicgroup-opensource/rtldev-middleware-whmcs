<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+7jAaP2Cwzf6r+/PLm+a0YWr42Bz5wmIA6ug3+BE2FuZH0oFIZDCuudRoePXlgPeFAQg6U1
mZDgLBqXWkdCcIE7THLec/f29hgLDrqV5A7IrzEeMZ3b8cMPQHfwzSuEZKKlvBmOI5bWswOiQ10O
51VL4zZ18+msKXDV18fzupq/zcHjEfn2X9kb7QqKyW3IgMxHQd7ae4+1vp51yQyo1JyCe1tLRiKQ
kdH26P1yxu/G024vBQchSXeZq8e08K5M9YCpSjssbBeja4egBIOQXBJ+E1jUbCZOx9OfFsawpKBj
amPF/wGCIGX7Ov2ziaMO0QIEd2keieKQ9A62iF4vx4tmNaD7ANQCcUTgbOkYRY9xGqfyWoQ+vex/
uCbSUps8iqa8yKM0iYU20Dlx/HfRnz/qPIsVMTFRtPSpcHqjEHz9L/wkPKOEu1j232RxSjiYTNX/
La82d5TXqmQFCoKl7u35LPp0YllTmVDaluCNBb1kpTR+earIOIF3WYlz/r/PFId+rgHClKcgaclj
qc0VGRCep2v+IxRk+KD4Ez/Tbify8CqkknEC2JxuVVDqZF7iYI2X9dCLYgNo7CJ5iOA6Xy4P013L
uo1OOEZk5NY2tSHI0TDyfuPdVeEdctd7Lz1yp1uH36yTbV6G+qrnGvJd1VxmcLAUJcQB/dWt/7OK
MsqAhlYFtcyG4b4XjYeZK8eeUzaO2+FfK8/w5uSYQFPnVVoMNdXISS9fcj+yAD0BI8J5T9t8XXWn
lbL3mc6smnZP4grZisjR3CR/wlDg91JAjAzF31iMhfbSU7Ld8VREvMPuNjnI6RlOaF8Pafrx16qk
ujGkPP5oWt8t+rulvmMiEq4jw9zTXS7yS7HKgm49KG08d8qUElcDruq2Yhgkjynm95cNTrGqde9H
7YHy5AH0ZpTdn8ih3UcKoEmHwSi8giADgrPKBjckuWFt5GhO2u+qV/MRr8AKPlcjDfJE4XFnd/po
EDYJhpUN6MIstAZ0sjowFdTFZi7FI6JZJ9LZtPpF2ai22xv2cyLPKK2XTU1rvo0gfdkJgGV1QqK/
EhenDo9SbCiobdK9piG52o39ehs7WMu8tF2umyspM7FW7AWOndj8m1kgDTAFfxN6pRjgb5CT+wkP
y0ae78Fi0oJxf5QxeUPJSLN/NAofl9xvVuT6fjrTY2Krlw9v23fCFyR1PA5QItMqssoaGfdI8VMd
3wvw6OWgB1l1L2yjtWdVLhalRUHm1JPwkDnoL6o9QalFVrS+YWbQCA+X7qLUh/jqe6yS9KulnHva
fjBJM/anmsXQqFfjMmu6wq60Rs1bd6rddEhq0p93pjkVil4v7I0DkGxGaqGdcZ08/pTaSHDz1/lo
bMxgrXuAltwPHe/yhsoQhv+depwOsGdlR0EVbj8clGfnRuUrfmOHYhiq/iy2AUcR2vUdweKexXiP
Rkk29vf5BHGH8H6wwi5FfnmQ16eJYQYCBf4gQxnqI9Cgp/6MdGcRhrpASrwHrKgxX7MQr5B7rbei
CDmlTeY65m6B3D4j++WcvXrfwUTGOCosCcYDCE8AME2/xYAHmv7djeMwogo/ilYtJqZ4+ElXR6YE
u/xgxxu+5f+HUMWe3+DWEYqUg6HqLUd/jfR7hhYIkZwyFVjzzxXztQT8+s9TB+tslgz/3xeX0VFS
lZNWxwXg6NX8Vu7DLTlNBCo9K0ituW25mgs2Qs53BxrW3HiDcNuv2EaHgQS8fc5nlpx5nTL4gPyq
1S3m3/HlsFsgHl9UG+dSspvvmijx4ot0fwhSijZbo9/pc+r38YxvFHcFoDlSMZOgTyzeeLkS+2f0
9Lm2hgBodFcv8Wg/Za36Gm==