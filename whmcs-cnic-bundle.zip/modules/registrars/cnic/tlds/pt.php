<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu5xghown2wpGya/d+RhXqLREpSpQtxbnCYBRxA8P1VHEUV4vfEKYsWD0ZFdZo428zSu+PdM
kmQGZD0SZhZ4T0t3F+EVw+h2u1ppvVao9m+IjDcwxHQLqLTISwOS6UpDCvM7yexgBNCH9CKTMdfF
BfSSkHJBlorFXM+lpUDnGdnkDVl3v8jXraEGV3HO82ub8ky2wGY4QykgeUQuO7FRAnX3t3THxv0i
K7hrcl2ZJb/y2i5scSkpYyXVSXaBGiL0rerQMXwiyuZgqoK2UuO7P9oSIrelQube7jXTutamAUZO
ntWcMSDdxkxUxKmKHeJQQKnp3zzmDyLjQ5Si1IH5v+CNrFMgpPorGO/OP4BpO4r+fKlVusgwYFUZ
5wEhjDc0jrzxwYJAytwO4hyYHzQoHH7Igumid1fzvzR4IcJgX/anomodrG9yUC+xiTNYosC9i6MI
3Qc8bWz48fIgdJZLAQyiMAmsUc5PuIWQcdF6gLTh/hhWc7dMJ9x6wAjgmymI6PW4IMtClc83Fs5y
4ORqI28VphK7O3aOO5bMbEX7N2ziSg+nejoHWSwPem4x6/IIz8yr7g7i6LMEzKWW4nfRpVn1YhnI
JGWv1gYNoEIbA/pVNfNZDApcMRKZeNh2S7fgDjB1YJEswaD//vLYVeTyt2iO2RDxuaY+Y/ozIZx2
CSKMaoE98ycAqPbusKmOB1GIUMMf2NVwIdIGneiNcHMqKC3lN5BplFXHEOSkPLXSSyMTP1b0jQG7
hmpTtfvPw1pzMtfGBbo8hK8aEtvfdGGtgkx6KopQfVDZgBh/n2+ZRofWkzbaTk6IaBtix8raQpe0
eVY1eYuLIOekr/fpI+VM6yBeNV5ymVJIDcu+HVlbmYIQyy6Ojdc+UISWm9Tkrmtc9JT7KeK6LpEF
RiPwFu57mv0lWeH5NLMvtaRaCymDKtIo3lSqfzES9yQ+qsrg/kgdx+Ht8jQJxE073vyLw6LrWvYS
B7hHpd/r42//fZd5WGkDHQQ2E2q8KhtoFN+ZVchHriq2hvEIh/wfi0DTUqhBeVVcDpGdmaWEcBma
n9iMUBqHhF0F/yRyazVk0BbYus1Bvl+KvnxXQ0ZoAWDnsi7I6jbM3zPAWsMsgCSIBk5+uhX5Ub2t
9s8AEVmtaP1aPNNdN/T6ysSvEDBa30tOLOnBzwXCuZ18nmMuzlbBxg1dn1ftfEthqFMhqTBUgFga
KWOEu/SlETzS/bavNuW3aio5VsePW+MAZGq9ujJcMlcbo9WbFVwtLy5UReH/NZFXbmy0XFsKkVJP
iMcpH8wui31AV6Gcu11OMO3nBCDrkIcbcCxeMXr6wwLkFUluQo/uQ5LJn+k9flFeAatiMUmPV/xd
zxMhgD5mnh6Yyfx+1f4GFQ4vcXLzbafNMGUT/uj+MA8rwmRaVbMLr27467eLFYIm5q8gE0djp6Jp
OuAZZEQi/Abxx2SMAJNOK7p86yBBfJWTnH5aGtZ4h4vxxhXlem/mS7Y3x2k7kvN1RVQLunbHkaPw
voQcR7pk5zS+wWZYP6d+B0+yzoSLLiguMe/I2tGSkMf9cGEc18N2W4JDTaDrwN1KSMQGKXrarozD
p1Ic9tQkZnnynlGmYno0tJS8GtmD6tAO/rq8z7R0qDAeLYkTD7CZTOIBOuT0hGiAuXVbIfkekjjI
pplT9g5G0TrgEQxMtsHV1XLuOh+C+dH7csTuHwJ+V7Sb6aWVFaWGuThjGbrUk0KGhXYGm0Apoaga
qskF9JUP76XyLG3lnroO8NdjOKr1IvM230zD0Dzpq5jptB7Umb713xyhE1QYyNFfzDRUS7BFqr6f
y7p0kaL6N4S=