<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyFDfoHD4nmB27yo1mmCB5i3MDNJm67LgVLP9xwsEEyTVQDte3QW5kQUad8JMRlgEGeW/yfp
ll2T+LinBP7300WVr7TpCZqEKbWzxnBPLd52MFvPjLys8/Y12TKPyym6yew+YiFU9MvR8n0NKuaD
H8Li31xhLNUjkAxpt9Diweh1P/xN0b8L8raC5Gpwpw474n5lTcoOWSSHILt+HCg1gWtQ+E8sqp48
eGVv3cNONYegPtmUT9Y97dEGLOGDGeLAqC4iVhoE9jJyXH242790wT8S1n6RAL/TXTSLfio5czJT
IR7r9Nl/tBn1QYglvEz9gUMsHcD8N3Sd3cINqkM/vCqYxhQ2u5q0b8IvEs9jP0xDcR/1SU8jH1z7
v+Qbb6IxfqlvmxRsdnJ0l+JLWAuBSQ8blUId/gAz4nVQhJzdqgnsf/qtC6UPRdh6VGVU+oSkJF9J
kAxrvCvpEql6KV+uNqbxp/KgeTgHvxeNGAJc/HFZL3url7aXudyXqK2q+pNIoYCG+PlaKGU0AfaO
c6l+/GaVI43umHUU1rB5c6mHvxwqmxMSpraKN8IQCxaxfQDotuN+VHUpo+ZnDmrBtTniqYpIa/cE
q/FELwg5g/w2OCz1bjr6y6QulP6WRGfrQo9SjQHlSJWCEVzQrFytaX36/Np1pLXh/dO6EwLi/h1x
pCL8D/AQAr3XYITIQ8xxitthjkwBLZQ44rn9+ksv6NyabFve51bP9529YboG4Q+nWDeG5Ynw0nz9
UCcIy1CnCAy0by51W3Z6hfXURoFUdcts8wpK6kbQjbgfQlcVK1kNPedZpAKUthiNqfStRTDFYKbN
efivv2fyqiTvBXck3hYW7YrRac/o2akKwUwW71QYMq0pcWD0jTLDX6eSwoyUjw0B71kr1lk340Qe
MtUpzxGJthVq+D7oQegf/CefKlg2RNqUkLUx3SQBH9hkyqmJaqTNvEQnd6CXgUf/1uUuOSYCwktm
81DtUFjxaAMx5UuEmbS+Gfxh4X8+U0cuFRY9Gxcc3HvbmCJrutEp8Iju0ah/H1/F0ksg23FsHpEK
w5xLZHnnpqCUE8U1mv/Lag4hEe2WSVip9WnT7ahcfbW7TKwxU2eVivHugJAo8k68Sgm9uIYnZv/V
MTAtIZDAtR7/U8c3uPrk0m9G61uI9JEdkaorL24uu2q2dkeSS9l/QcvoFg+Obw38BBwJWZW9WDli
jOISRTI20KyKfkNxDbITS4Wx+GNFTfVeim2PhyW0ynwAGeqqs0++eNm21cmM08PTYtklLDx8/hog
08uJLlRRkzWYGGpATC4VcYm0/RTfXDe6PPsU6SuUWcvjJFdvC5N/H05dFKfuzxz9xuwm6SIhEMhX
n6CGOpCkkm5CVl2EayK+z6kHmpNkT2/sg0SBfU3WZokJi0BGs0Ozw6ZtXPDfoqUYq8hSG+mKwkI1
IvTXJvUcm3rBwv1bqDGkU0zhLJQcESpvhp3KcfnZSiBYTZwhvwm9NkPdgyRapgL/xxY3IWs+49dx
eRLPEsyRwJAWP0i8mMVLcO5eJ5NTmje4FjMH4aa76Vmh+gWDJpzPefrATtso4KMXsLuaVZyeaa0R
vaPkGDC078Rw5yeZ5TDUTjEEwWXiuKNItiI+jzc0PpX7O5Y3nQd1SX8HQnCYuk2qe7jXGbh0ffEc
xjzHs55ryM7ZQsEtSUeQHcJRLqM/yfr/GI9CeTX7VLR+I9ZLyUbGgp6AxhUFRavQn92xGtOHOGkQ
YR7y/tcXhE99Ybnxi9Ac0amUrK/jFeVwRLCcVHAD/dCLTyznkdRHGoElImwc+8865zi+IR6bPJzF
qm==