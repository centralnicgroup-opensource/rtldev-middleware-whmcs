<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyagGN8l2hf5DfZKKOjdE+bHxNKJ4k1hUQcui/8OmemEi+QLWeqpcA3OA7e6pRsxVxYgO3lb
7HCNFgrAGusJPIJmvcS5tvxiGNVplQNZ+4tXWiYGEVSohTXGygJXQaR7uBLJI5lX+6hJFpi63IWV
HSXnM1U+RhHEWaCctduxnw9lBJuXt5gEnDM6eE/XoEgmS/3hN1NsM935wO2Q1orBYvwBvrZZ1cVO
JhbMn0vPf2kvzLEo1wYjwBh/TSyZx28aMLHG6dpVV5iY+qGEdJ7xGhOwLTPhb6e3FKP6CGvsvSs1
XmOj/zJUXHyMzeFlYh4b9TQq8GW4WQHvCxTdokZYlFngutrn+a9YqtxpE25Id2GWHEgYwgzMXvaZ
6syRq4OEdo5WESX0EaUMMdloFle69yOM/NAsDmHvhjyDBnlgWLFjRN8fm5ZeJeQycFL0iIZNmiKB
3iIQXBp2/DkRQg3rZ03Gt/jax5bja00crdZhvJB11qtSbDctmskPgt6oN2a79vSm0Bqtx0m21E+5
ed5w90ZQ82/qyfxZrTQciSstEjlra2k9d+eMMEl/u4ydR1Tx35n9aKqiNcZQzcMbQPTmpdcaxLxs
HZjvAvkLvU1KiQ/J+ly8OJV6tftR+X2PzHLPnhMHpYZ/O38OPYWO8gmOBXgCKP0HCttxW7fpWXvj
iOL6mV0jcf5ToBW9ITh3yuv1BY74QospG6rOJXL3hYOYAavPE1VXC66st1qwLlbpS1i5igogFUA7
Fb6tEzEIqy6X9Er0q9BPHo4jkPWzP/BqvxQWcvC0EA4xf2vlw2AyBS0DGbEs+tNxty1asQa6yznY
ol1X3k5WV2Njw/xolFrYIJ0AyRN/L8qG8fqgf9b4Y9SC4DbCnUdFLAgK/h7v+o8NpjZF9NPKnj60
UxxQeddM12mPX8biSeW9tMx+cnD/EGrbcz5146yZ9ba60ubRdAgDyvhTZfZmDhV9iqR2cXfdWMgk
/Mdl9L6VHjK6FIgVYoe1wjZLkSG3lfIXoMFSZgLOpn8Y1uT5DyXf+/qMs58eKHXQSHEGaqOw94nS
farwa2zMd0pT//gGzEMrJymTxXVd7JIxvLeqEZk5x5q9VvbINRim6/3ddKLYCWV2T8Q/7a8Mv5YE
jPNh8Zd4fqoOOukb0VlwIMZSB2SV9ln2mgHAEqhqaCPqGiooM3qMWkqN4h+ZZYoFwuC+2STI7xnk
kRGTzPVdEbtXEGb3QFVi3PN6OjYQgiXHSB6NfvLQihV2h8X6xSJSTXTkNEHiExyq4rsUIqrTOH60
aef/v0BnhkxjxYZOlLwXm8HIeEiIPWTdyKkpiOOPSh0Y9gM/vG0LVyBmLsuPJKgZMDuBJWlxTNlr
/cJy0clJ0iDvo0Ep9/nSLZazVO+u5fr9cGAhtznIursYNm4n0mmtzVreaGuGMN0JZBdLHd9lyWNx
usofOVC8vhJxcK4DiKP+kg+EPcKhxIZ43ot4syvrkSwfBS7ikXWzVLeYWeyDmg/fW8RzDyOoJpO4
kIEXP5ueoEVsZafgP5b7pO/gLy6hNpRtVRPXKlu4kdGZNdxJNHZL3p3VYC/gd8wiuUyAhHHmQJra
RISvEIDWzilN7/0z/K3cNAAT4bgzKV0QLfszkCJJdHjr6+Yy8REt/aZt4JtlHSFpa/ikbi5a6UrJ
bFaVoAc3H/Xv10Lbp9/zWz0r+YHbnaiG4sSWQOC3KCE3oFQ6DYeVFzJaAKmdwQzfxPH1T/p38Yg8
PEyJXBDYm2QhmPx7JvXNKUt28+J78p5SYXt90QN9bU3YTpEX6SsWaUvDXAAondWVQgKdsJAsv/7d
MLhum3ywiWA/qqA75m==