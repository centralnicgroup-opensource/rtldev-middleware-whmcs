<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/mUb1ihvcnSCgm1EBEGJXmfhMqbZeiNxgAuCXb1N7QY42u7QfoUikSMyz6ZaK9npLZEmrzM
7xM0pchcXgmLUnCgHa34a0Zb3Z7bWb3t0gQz8LUOqB5s9zdmcFTox+5wzwdSBzLpfcCcKpy2XXXI
b5iVb3Dy5R/LXC/ctGSUsa0tKOA0H+aEFpv1i4Zuy98lD1xpglXz4EX4VBvB9x5tpwlyVgc5TVXI
CVCPoWKE6Lq/iNxGH1sDlHhfLrhcw9jLOjZEI8rG6HoI3gSU9NxHfA0EL0vaylPY8V2WzTs3xNNn
2aS1/tEeBG3bEiJ00w4hYjqhM1mP2x8i/3X3RjoLrr1JZkehp7GzvfqYNURfWn4dS80vhurjvmnv
I54p5XIANNlzJmkylhM9bJMmewO4CtoT8Oq1bZwZAvmCBdpJDdXgM6uIdJPU4UFb4g94eRcVfxrH
1t3++NAFZHwdZexkcrPQBWLN2VIPv0UMZBLL4Lqiu8zOqcfnPO6KCv1qs8tqbeXW3bvz2fIMCYSD
ND2WJP1c4b8HXRifDC2lI/X3nWORWGrKVzEf8eNUok6tPeB+W8qPfYVFmsPfNUpO2FJmP/RneM1m
AlO4ezz73YKuZJCWUCVXz5vF9yBr2ibF9WZ3VlJYC3l/U5JpaE/imytzIsU1AIIGOH2RoSb3tvf9
DvUdBowX3hZZM8TafBXmcDnsy5QfCwhRqQ42C8uAOAzFuIbOagcI3GO4HegfdhYOB3HGsOn5JNkc
3qoVa1Hk/6mSDKsKsgWk7chv3XDyi5gIYguKlpsNkaODI4cS+PQmRWfc2bKOVVDSAuylTCjjU4vq
YypsbZbh3rst2kVUgPR1krqmVa5470eW7sAjTiHceEuKrK6GQXDrWzh6DIUXAkF7cwSoCM2ONFhI
v6jEk3eNEKErM/LQJiLGW7vUhGoXCqjgzrH/2E63Ng4u6uUFAYM3taVfwEqHP58VGJSphi5NS2s5
u3JVKIFe2Xjm9aFPcKsaTuqGWueRj2Kqx1bXaZgFT1gbDnudbkWWE96XGdeGTVdpdAYjH96s94AR
d2rk5Xhy8g1KstWllGwD8iPqUjLIMubzRt/MCua/O874g+CMrNyfMhf/HA6YE9WDE1t/e0r83+10
0ICcACBktr2kkMUDxLa72r0Ynj/rce1kQJv3kg1kMe7SSMYb7Go/RR92pCWXY3O+hM7eQeBlV5Cv
nMq4WkywznpqDo+LJOFNudKO2CtS2cdaXeG7df+QD2TInvqggvN3SYfV64kaDCmW1eM6iJNZuuo5
efWiDnlfoyTNy+4U94unPvBja5A0ntmHCvpfNWn7WXxusxBj15OJ+OmI/neSzX2ldJJfA2gv5L57
5L/aW4mDRjaecVqHXQiuJjMHDS229EiZJ6srBYeRPxp0SDDEjZBy3yK/KkaZnfrLHERZEvDboYwv
I6t+pxLVMVFj7mM4crIbsRpOzlBy7OSMTie89cH8dtiu+jK5Yd7efviR60HzhYAz3baZaRX0xSsN
UPuVDdy7XtQ6Ah7qiCtfLpcCW2tyfcQ1+WEewITp8AzT/e74Ew6yC4iDa4Z3+aE+hKz2KRGqudMf
gwiuOX8Me5GSw341DSp8Ub9IWxK54sN1P23v3gpHZrc5IIcrpvI7zi5W/HkE/xbbuYFgmzMbskAc
5VZ9QaBU9V0PN+lpDaDbM7P/ElrreZZZK2++Nd7isBGFH3TvXTVcNrepvo7h+VkFUaTvScaisn02
uaszVLfLvz1gcFMRURzvzhH08cHdtUA5skKn0xi1/tJA0ngCZs/7+GSWovxABtJ8jMCdJfkKXR9Z
pRwf3YCR2W==