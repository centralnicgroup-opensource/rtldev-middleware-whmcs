<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxyK0BA/+/Y5HgQLaJiEqU9thcItt9RNr9kuqyJzqrFkrLianQLLBOn+PxKMd23G2PQUlRuS
x5exTSQY//6y0z0G91sd3s6l4jUKViRdkJZYR6z4w1GXhJUEuYMdMKm7OsuxRd9ztOvjSvyIiI7R
nc+oHZP9YzX2/8GVynx4iRK83U4DLUrGcpCjaMl2SCua6GTZ/fBzzqEndCaVMDx1+CTztEj99g7a
GKBgh0urlDqU4jAdppia4us9VxYkR5bd2fBNAzyM9OqV3uQwVOh17D/d/3ziqBEcGrtWgNd+Oasd
bYO7mPmC0LTk9jG8JyEUbMyWAL3cv/+p27Ljqas2k61BlCxD0t4O0zmFUB10uDmJw1HZgMtTuCgu
p23QyJcb/zc7LXgHHULvNYnuTwYHSW5SRG1+bt6+jZTiiryaJZFowmW/2mUeOYd7BrUxxnVemYOY
+bUOkZ6zLMG9wBphxFKL4zvgoFvUXWzMV++VoIiiiifYXBLiE0KnlGd48qN1F/O5sP3tYCg+2Vbf
DIqkGYhtr9RIfbDzVBAKgksSNy7vBXf+RA67doqzT0QtdqPMxsFvTukDEW+cP1xHEDKMZpuTVwpT
UN5svkOqC1vo7iRSV2DBRuBBrzhalOln1lyu9A3G8I2L+o+ibDM+UB3m3SvQA8N4in7/8VvNCEEX
ji87gRJNE3e0WAml2lxst2qnY9JoRoQ5eWa4NXS+DBnUy9AFS4Z+mwoOidxXE4F3ruIGLKTwk8Dp
K00wp4N1JxErxeFTEH4gtgSGQUVQzATOYP+idt9cH83HiF2pgTdfwkw9brNzvGOgAq+zWQGgkRvo
x+hDWP2Qx/0lDlKZd4u11LUuVzqe5ZAZgw+PE3dLls9Q6y8uEu+pUb8r0c0SX/i8yNDV6IgVepJV
62BvM7kheiIPaB4RXsBDvOyreHsg1/+kvFP6Xt9RPa5o2YP8h9l76HF6Ctn1AoTjxGgSpBf/D/yG
AHDWtLA6WeMsRSsz0HKzv71JZ4zy6+kEeiQuY4oId3YRyQF9V8eI5uI3Dxk0EhAx8MmIBN3/u1WC
q2gOHC8OkfnABgDPURx10jQ6CWvg4CZ8HDINiL0JZS+ACidtsOW3d+lj7VH8voFt7HqYmhsIIcfi
Y0XDVEEIfNGw/v5vo+hjJ3hRjVx9LpCtMdiEbJPE/5DVc5sik1OeAGYnb/QOoFOqU0JlJ0QVAvcu
oaGcpGSrAtL87gdlC06OK4JRetrWtKO30Ge61f7Mv6Lf1fxZg6dHbAqNzzuUZVb88xpcZNbo72J1
nAJE/q9PuGVh/tK87cWb9BgaBBBdilx5DVDUY8O33Kp+X00vqlAR80zz1rG7q8bw8H39imNICbDp
1uvgyOwvUJTvlWo9iFcnMEYtUG3xTx+IC+PNuRaLTPl0Z8zt3soMaRUKy+RlVlmNM9St2P7ITlG6
sFcosIW37sYrsHOXg1TqIR5ynZ5duc9B9jRRkVIPUXeOI0LnmtiCceA6KasSVHnvHJRRvFhTdbJp
i7/PyiRalXyA/okvgjgsQCUE+oki9lAh+F4/bn/Ecm4ACzAafLGLBmtwXQOi8IUoERfUhDvXPa5T
XdgZZhCu1T8r8XpupCk0H/o3ol4hjgeTrCM77NmNJuXjyGdbYm6OKMgD/TF9oA7V9nXdUjoS0tKM
gCDN8We9yB4cFwxLYnU/c9WHn474SaS7IzmgFJt7qOSv75rxGedgBI1CQWmkpj/J7yo2X3ca57G9
PO7oysQUzvyMUrGKtnSmxpqb2xAOWXBKTX5QVXY0Hr1+nG0F82RQQhLSDNJC1IQKvY0cPavFT8oF
Fh9LBCTindErluka3GgYB3NbJG==