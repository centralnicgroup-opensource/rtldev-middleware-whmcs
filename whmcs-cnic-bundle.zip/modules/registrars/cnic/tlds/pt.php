<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy2an0uWY3qXFHPHBNh0H76t6shMQGDhgzARnmwTsm1q2bV98NHNAe/tSlv4MFI2RQA52VV2
GV7rIBooZmvF/yGpW7baLGZj7G65rB7pv4Dt+rxYICaTHbCHQGsgR9fvYNR4LDBMOryxz20kCuEX
1NUIjvcYXw+JwqTdQbd7FGsayH86u6cgENzksqree0yjZoUk0AZlyy+xQYMZYIqIK7k47guqyPNC
8ZjFBfcs/QoDOfAazcoX708kbuw8gohgVaM3bVK/cQ9+BasLC4HmKEQIKNC8PMoJ3XdU1tKEH7Ww
ZGpc7FzGgfRKMIVGfaEoNI2+wr7oofyBEenydI57b/BFFpWCWt0NDHgHMvDdI2xxfWU4lsCrygjW
p7egQ/e3JKsDh9tP5fBCL4iWIVnc141DluIeL5FI0HFZVD0qfoZkdK3iwkE4Bkhub0pmQl3numKv
Oysuec/td6gP2AdLeq4f+xNTX9HSEo0+hp8GTzWSC3u72opPZ8L44jX8cWfPi7Lyo+vj5KAd09LI
3/qL+ahZRRHw5BGPOT7LKvH0hIyPS8uxqmme2MChpPyMol825VTGIWqkrVeWANj9QQEemCeWyOC5
BQGAha0U6+s4WxKAKavOUKu0nH19l8OPh8r4skZeTQrhNVoII5GGbohgjn5eabwSXkxAKTsSQeXT
ueRaQLql8FBbSFSXZiFY20awmQqKo2PfHZVvOuev6+V33s41SrNbPF6invqjKSERWtKrwi3a6G3i
80nO656JDdpyopN0wuidSmviQG4S6bUWPgNsCizssvDB1LmuyRu6oS0P9NAt43ic3TyITxJ/7mCN
XQwNsdn/Ov8nrok4x3KD+GMtlW7vwUcUaK8LObATCGFWR3+xfpIbMlTo9Tc0OealEGYFn/ENXjqs
aZWi95zhiUkzXxZq6uMfVpLyjlcZc8NiIvMFX/E2jazK49WHSMBzfTvkWFb1aPKj+fCdY5lkmFUk
BsDYzahhX+pW/K4Ah3SHs7yqflFdEelRS+pZh4xPBlANPIdj56jHrPXCqenPLyr91oja8y4x1ats
+6TzdacromH3v4U76CNDdxoHYtsd0SEFirpzhqmsuQ31y1ohI3924mMSmQQq5Hl5othDRj6wldQ3
Mh1yyGqhhcUzIHPPFujN8zhwrF24P5ms62wU5haUV51pvPaHi3kx/HsHVtRG+10Q3ZAdTkUs0h+L
z/qfqfg54bGn8lGS8I2BGoubwks5y/i3zdSpR8P12LLfB6dgLy25egzeJtDw4d2E61RMwt/cMcNJ
0RiBJ/w0ts0abgCUkVuMey0sRY7udqMhfOBsUHSnchLnNTOlMEfcFJWV3yV/8lzPi6hYgB7UVU1s
omMrkM//qmPNGIFNJBt98m7iTcSkLBatGGvAx8wgQSnajaaoQReF+z2aAh5Ot0ASaHbnqHaxaVRW
1yxga0M9MSWzIttiDriH6167ViqPGH++ILmRtWx4jn5VH0YTY6s8TTqIf/b/tqPiHAi1U9O6li1n
Eaqk86AwHFooz0bZkdMjC7HBO941Wk5pJ821wJ1N0wYgGFdFwC1PaJbOa5tYFMpYKJc1UO1qSAji
TYQGbmcLex3GggaqElWtWAHRt+ELfRvV+TIG3Wz4nv8cwWaUCPymeTvf2fe8AG/t0vot+O6nGwlP
elXxPYCUkqxCiMCLMPO8TAeZ8ZZxbYWfGP5oO/9rxOcbU6e0S/SZdUjDPMJMCq++MMnEYK63b0P3
VrHXKSWN4Ml0N8aYGAS/u1Y1r12kWtztUQyQxmrw4sXWCdetenUgdpBZGQqZgcsnI3F4JHEtnwPs
IOTNbfXoCmVhshRs9+AO