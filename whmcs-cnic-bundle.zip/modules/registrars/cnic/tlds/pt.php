<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxZ2KWgrBQSjG737AIQlQ1Zq40XF7aD+K8Uu6z9DfSJtZjxWAM8nqGydYx9o7I3wHS1MCRvx
mn10DgbTwuNLX7OtEOWf+1jfNyFpIOi+YhxWadwA33v0PhuFVugDTWoA5aVny7hr4tIl+beMb0YQ
TZqv6OPURwFZrn4HHnoNNaSkjGsCBzhBwDrpDEmgdl/uTgVmN+IQrbckhvcTFKdDGOCHlAKaPApu
zu/+iITuWNtcEIQC4MxyiF2/OIgbr7zpUy0uEPx11iLtV7WoGwx5smpwtJrdq96gWgPd8F7MHCyt
VkS7CyHbGAphPLhHYeQ32w6qhS2mgoh/Q78qMDd6onvL5NnLG//u9xc2Eui4bfLnR1jdcz94A8SU
9M5WzETw+3cQ9EKDGjGPIu0EW++v8wazc2No2PrRv3CibzLyE2BJUr540cQDYmgtz4N/cw4eqHQD
mMfcpWXWvYTuoFhlSgCNiHc0ZAP5CWDEIwqBdeA00GRLoFUPCCfOps9LXOmdQO6yV5SYCpKW4iU9
4h4Vla97Y7WoSt5Q5B9prGs3EJS+7iXhadW/gL4+NhIenIe+IGmfdcjTRr0+oxefC1QGEq62P1SV
tTtJrazyNVGgI5YmSjdWUX55sL1L025RgW0fmRgdMln7rWwQ3G9xah8tNy08Qv3GLkyHkcSwaJ74
tbQy5zzhoTPDZgZfAXY9tSL/bOEUnRJLS1f/gJAx60rBd0MvxzLqdUQoAccPxeJaZJOBPPem4e7A
yTTAqSHI663GBdn5xuZztyGChBRxYWo0RfPNZc82qfxK33xhYB2FTj8p/gPVX0AEWbzbSx8knYe3
2OrQ10vV/dn5+TUp4VqFCdlI3mmPk3BU0wKbNQAgqNRqiPUsgOgeRXmClbshv3+jlqtXXoFX8RRX
+bz6R/b/MEzRzvaByte3DMCWGZMrDG5oYEqzfB+2eKAAhPGkHS4EJMHYwRw4apPIrWHZOF255L4F
9byaDn4TOQa13LVbcOdz0sveMlCX4OH+yVJ9yatcYvGbc8ErIZfIxyA1vZOKHHUrZKHdiDV110QL
X9xAR8j5I+uj4RWk6NXO9j9dyRgqF+mYKaTZn/5hWno2z8NZeiMCjkyqln+Bqut/yiO4ANmz2Bn3
lcrBv/CrotfxAwXwyeCJNY6mls7r9nWgCTH7ohVciGCqJ9Y8niJugoNZNewuyGbZOe2UUGnk3iG8
18rvrbKfJMPRgDYxm6pXrFo9OGr1niBhNIMRiTVtozk3yBUvk1kV7Hu3V+iha1bMw6wMKAie4F+X
9HomQxPemZtz96FJOivKScEIx+gnxCQY9HiEB7hptpzAUbdmx5HktJb+EJbyPoWnFlju/m5sR8p4
23s2eW10pff5gfkVD4dYknw3eYRobG23gWZlFr9m08d1LiSERNdurPwM4beko4nvvU158WJpCvaI
9tdbanRRVJ76nt+paccWSzGvwQcbGEU0DfOG5Dz+JRYFrP/aBkSsgK2Dlp+VUV6ewSuTGH3NjmWv
7m5/61MjN/+wLtFzrzjw9qu0n7Wa/G8tv9R2TzYqSc+H1mzCgSXMAWwlV6/fe45SlZR+G0zIhLmu
CS0Q/tWYos0YQa0ptEm0hQWnU9bYRtp7eBZoiQFEgsK2yXp21K8v3Hjd21yJAzsJni7AvXhhWfOB
3mtj9Rwnr5lT5MnbfR3Fv3W3fo3aNWSiHPA8YvF/ZupYe0vDvNfachIXq/3nYsNhoCyBprwbvs+N
Bd5NZP596mwpNO/7Un8tuqTm3fhpubzKTg+nn6/QMAodrU5k3j782Y5FYphoqLNB7a6hSQwq044X
lTMnbfC+lGSpZ/2cqwW9Bsd+