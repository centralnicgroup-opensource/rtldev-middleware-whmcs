<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvtIXZIRFNixOc0J5mTM6gFmBdHPSaO8xPIu1DIYpTR0eyWZdrG2nTVLEVlK7lAR04pSviel
KQThJxTaA5Evb3ged/baOjV1sCI7uLO9Rq1gvbkFyb76u4b1l/fNR0gc9VTB4Ko+T4PRFLQWwCTz
c1lcCShsOe3+yt+P4KEwTowt3ZczZ8gM5lMwD5HgJP0nyfXZrnTrJHkuIBelVdeMd1yTu3Y1PbkH
yW8qIFwqvEZzS0/X+U/jOQp4Wc8zWxcX9HC2m2YPmMiNznedaAq95AXecNbepqPM4an3JfEQaDT6
GITeZMmkh9Npfaytg7RwXscdiu/mZCvd5rPy3prALHgH5U0cuY1zvsvLQYM5OPFkMjwEXVJTkbbx
hbKfz6bQ334aS/EHDeNzu1nlpNEaQRFWNSbEjXH8UcClQ/Gmz99CvEzVTfyheOfH35Ao5SZDiFQJ
ukI2l7PJUCX4RPpzTebpKcQagW0gpAvESR8KfKzIrOXzPN4csdlmeaK6MtLmw2lo05Iv3pZoo6z4
dXueBuxbu8x/N+D0GWwCYGigLU8jSFlyDSiopdpygGCodW4Xati1AvM79lB/NpCwniXH/N0bvzky
7tXpHbkb3220TgiOFbRJXzgzD7A8wffUpJIBHhTas8VE130h0ytKCrnJDHrDz1Z6IcyPalORujrD
5AtBIrMWv6TOH5Y3jwQ6tPfYYGGcR93SD8qauCxKSvdoWUYZXRBugGR3IXKYjR0vTqR2datL3q9Z
HLRtVbxBxZGXtxvz7dKe6vS4HWb8wFllMAXQjnChG3RfUghFGbdFp6ZG7YQoTlh+z+C+TQkm3O2h
qBdzOLRsNCt+rLQNQ2mFAl+kGFDq6Z6dExsavlKkP4v2epDGdsQ1lnban+o4wNLY2KYUbC6KTND5
lgPzYYWiVCsYMvnLgfqJLCjZFo3s0xvX04ZewZVT8PhihGTdouSYe4E9Vq3aEKBbHIIN1LDdLHA9
tKYsmmQmpWS5vGvpIog4Envjh0N/0SMdpgtGrhsMuQ6ybeGgE6goWNK9hANzwI4xbxxm0TY5UiYB
mLJKgInz01emWHf1iyc1FnKu7uC3WmbLP7u/k1uDac4L2sMe/YocRLdLQAiB3SJkUmrrjt5eJx8A
NoElu4JC3aVa6I/N1UCEfPJyyPE6dCeH9FQ7fEIZWXCsE53ylsdoIORJKv7vWw2cEy4ZC+fMdMVj
tp9rSsIBmz6QBCmOKW4u+jW5KVNpXQ9T4nTUL1DDVNAIBocyiSndRP8EIdymfcUXLixdwDA/VXWb
9Mm4vlQxCi7ulm+w0MQopGFqn861AluZLKPjW8riAwFEimL9fdHghbnx8Zi1DuZ9FR0hSbCbsT5z
gM60xIca5+SY1QoW2/npYWuhJaCi9+2xrRzYj6GPbsDQ90Z34vHjA8DI1Bs1YdKdaTzkAC26gmgB
VK7D74Ogw20uBzpW2ZP28dtTurk/GY13kEyNBEzUbVzZdxIzjQIWCobdHAuoxwoA09wYjzMkXv87
22F9GEk0GgFlYJyQREixJ/laJvCp8XgN7/Pa5eyk2z2U+zWnRkKnPmXAL+nH9nrl60ogIUzJ7EOo
APx2/zZWMzNLY97SyamzBWImL5pbsS9ly8vjKjOopGZN7sNF2vgpuQKi14evlo0Jgdxed69P6rod
Pg4SR8QWPVmV2IrFPQVft6wOzzhWc35Yo90ilatDjTKfoq+nlqnd4qn1JQ0ke+cJgaRLtrT3oeF3
6QKjhz6WSAInAQKs6goSPN/F6h1+HgE3sWN6ZqB1A7czXN08t55E+uMr/562EiCbVjujkwScGMT8
xtzAPDt0gngjuorjAm==