<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsX8NJHk4gOxTu385tPALHVChZut4482Axku8mPaMNQnxHfzl0MOJkkUvTpQIBVzE/ntkG03
S3gRZj+lqR2+NPO1by5Sd8NOhx9KZDIm6jdxoXHSrZIi3XwIfD6LQyf8CU3UTpUwfL6BQ25ESuEf
IUEJMa53qprMa/1evv9EdIbOqpCS1VPs7xCEasYhahWQi+Vatw8zFjBGImHIVr/Z8GUCne68zSLI
x038aHxyFmTUgcGoBDvM5caD8cbzksARMZb3gu3L3W3OXwtmeEhzGSlm2OTcwuvPKd0Wc3wc7GRn
cwX/Rmdoh7Ofkluxah7EwO8tIaJ6Qz9zSzPN3pjI5QcyY+9+DEt4NrdIb8EaWbMsGGozW5vNose6
GeNS+1rPmYcv2yHjcJvSaqCRKGStqOOtJFcu05SYV9VO8rsiSnicRMD6duAF02sKGOq+Wgpjies0
29y0bG2104i/EXho0RAAXxmJUq4MbV6FY3lt//zvxh2fGRKiAjPkXT4V4uF4uj4ZW20vv/UXgqOg
uqCd8X7QkK2x8nlGHV9rYsivJVBcEtSmsN0hAtN4BmMCw19ySJjfExg8MrL1dq8XpKEclIaO3nTb
TyBdOdC5Nq7qN/MKnc8T6uIzmA8kyxGXxz4r62nkz65yb5vrGZy+S4wczvq9aq4afJfN7nDtHov8
1OWJrXpFohSlfFjpz2Ph1pQWwFcKqKIHL45t9QE6/+BMYgRWCA1M0rDhhS0hpE71hpkIl13adQ4L
mnIr9dYGONUmyiyVobguiHjbRx+mJD4KabDUvn6k/W/Te/Wuw14mN3KkW5wUhw9+As2VoVZrr5tg
nsPfudjcTTbnP9t8hSXdc2Jh4OR3FaI9iJCHCqMVDoMGXOyV4m1gcMTyJkF2VRAYo5Js0i9q9rtH
cJcyiRz9aSMhzeBO2zbWLNeQmh9ji73NrL0X+BjIqB5sOsN9Bhwohwqj5FSj+MEm959KQWJ7vOMO
4CVQL0oK8uEMwfqA8YDVHCxmk95nPwgnc8K7ESYrdyp991K5ekkGfPm5/PazGcJIEfPqgDqb3Ca1
xMp+zxeIiBUbUGTEcTRCfFT9V/t87mK/TLwtdm9JPEqlNoSo/wk1yP4jygOtm5njrkt9pfIGTEMh
Q4OLECMlgBI22p67vHwVSReu2iyIwwhb73h8dpK0Q3qY9irdBzFy9V5w1s9IMLosKjr9cGPNJSR5
OTe9jAy5QFrWbomAH1HhWe+J+3HL4iGiQZqNVrUjDVL/IsHqfToU90QEBi78UfgCW1ej3GxVmLdo
Kdmwc25L9f3IopHSio5zSREjMQiZ91TS8n7bIQZISRAkaPRIFOdW8xqjYoMwl+SgFKS2qOI7MHG7
HgIXJDIjD9JR8FGoiZQ3fUeSy+Fk0WA/qUsFFzSp2U8lSK/qSOuOejRF4hh0/0IjyofKRjDAFa7M
nF1TTmgV8UGDbQB99UwaIeOBFVVJvHfugClGGOmZJlvUYX5ifAIPNJ+IQXKuGvoewKCOscDJYRO7
Jj7dl/pwWOiug9sda1do+sWvDdEVhuAx0cuOeUpTC/ylKvVjl7i9qBl9FarOz4TdtREpnq4GhdAJ
tPE8UqFj8ot9AcyFHw0hogiSd5Hej57VGjvfhYatPWa4V2nVDBdpCtpQpK3qHheNSbtPnSS946ZD
Inuo5/bzR3xESUw0d9xf3NfS/JT6Qu7d9sb7CK82UOkig5KLiNautgp/j7XHuNAOhDoeniJ9Tkgb
GNvNWtEZfxUssWLvL98LtneKgWypoEOolsd0VbfjGm9jO/vtc8oH8vaZ2xj0OphFUoqwMRlhrjJV
xqcIg5psev37Xbv3279BvrcB1xH/g4jLFzCfpBDLeJbFSGuD9/JCwYtA5c7dm42OE4+6jn7499rL
xMirJvxq1mMVK3PiZef00CYp+pkrfFY3f7xqMzwP5HEp1K/RH169bTohgs1whLn0G0LnaGBDnwIt
hpCHRxR4L90MT40mb6AP13CWuU3CD2JD2pXPkJJt/9eItJa4TJ8REc5aVxjmKuHCHxePT0pJ5mY2
X4gkPlyojJbkBTWDPSt4LXRIn3lTyTQjJaqqTkIpUWD7DBtjQmPJ6S2fq+kVDiTVgJ1ZoZ0ovB+6
4IeWrQksTjqvgVoZllC/7iD2Yu7fIujEpeei2RAgNtCVY2+FVxE5o76dBhQ6HUp1f2CJocD02SaC
CAqpjPa0mJuGjGZGOZKP+Y0qXWXy8lzTp6EDJQTnmBHDr5dm+XxEPQYP0g2AXvgMTvvrz0G9VfAK
x7mAdv2xSAzqkbRMtERZDhxx3SImtuWHYQq1N21SEzaenxDLfc5ps4QlOwiN+1nxYTCHwx6eBqXM
lrNCDIOok2IfXVAsIH54iNi2weN+iuWTuJeMjiwR1kny//tJg5fTNAxbhUT//PL4HS+eh9ZRw+dr
FMOvK3Iam29m85Qep50Uj4xLtE//XATVorSuhFnB367aly9jS8iwTP2CAXi/4bu5mJFGZJDP57y1
IxAiLaKIj7Cr5Uo365OzPyj6av3OXUGeDjqul3ga+2+XU38Bfg7ayZzxaZKuk9beQqu7GsRGrnTo
Fk/wFHdjSQKzBNpGXpl39kFOWW+eQNhOrlOY5B1dLxEavWYn3gq/ZAI4CdzawmLTwUT5BI82k39Y
Te73iUyoOmL2o3Ik5o7oJFKvE9oo5ymifOqSjAC1PZbXgnyCyGrmWnX4MnL/Ym/6rQw5r84QGL6a
gpgUFq3/G8KpX3G2WH6iqj6YwvS0UQa5flpemWB37O8UybsFUd9oQLtKJJ8Eb6+w+AmJ5ngH0Spz
j3JmRCNEPxiq8rnSH52xwHsqO0zYvQoYtFgS2tXQ5zN9bSHmKzTepxIBvIONC+uRT6rxcVmBhuBl
fACfXCbBZJUSIRvQxRpggFHJNRTpz9p/ciFihVk9QagaOO2Uh58MYxWpQa9+fBCqXl9V9oXW5jcS
Zh+rIoMX3xHK/N/5Vm0z3d9e0djm7aliTc0D/2/jOQIoRBLLLbKWO3hRl8L3dJInIXZjKf2gJdHa
QhDuFcFfitue1SdXTqE5kMwCqGv8Wg9cb5gBMGKP3qnIQvcJnHxLoNIad/4tnyh1BxFa0G+thYyv
DqiX7Hia6u5VEmOkeZ33F/KoNX6sZsfuCFdgPx8euMcFG6VyXvxWiWvLY8vJcrqH9HGl3yRB/8So
41REu+P2Vl4kzSy146V5P4nKauOgWULsRLhFRZ+kxAbTTfY//3SMum4QpKvYswKzuZ/CgiXFYGIO
ngF2P7vlzqbltHP4KOwO5qwBD0837hK1Wa97ORRjW+Ew1mPCv2ejMAa+tZEZcCG7zpJlbNyxdaLY
RJvIxHnsVDjZtfrnuR6vOubhGR3b0tjq4QQL17qN55nckPIGDK3coj6H2wAVXW3AP0UA8Fn70LnQ
KQtaNegRMlEGyIqT/wdjOULzBLwvXs0ilJafgLo+sSoIncmRlRwQ/qN96bBPJziJr/iTazIz2Qan
kRRryN64XyvMKSkPmZcBZv0KUlSI8I/GTrT9I4hXGpUpiRz8si4k1Tk3MQtlAn62HCmaiUG+f284
MykzZ6v4LResc2gEUmx6tqGh7hhMDgPzXY/c/Lw0Fa3MpRusTo7KTWPBbz91J/SGKqUiyXicFgpm
P2UappjslMFRJ1+5skb01WSe/83iIuqWRw6B/04nbS2nIOGnFuCDStSb2MlXlT3PIRjUTDk5rjDO
ZmkJ8HpEuJPYXwm8zzG4sGOEBsCi3w+iS0TBT1tMImfVGnK0yamMQb1Fm7hLXve3SQIi9nL+iBSY
uCtw5tyVy4ir5rkGwpqrzRAN/tqi2ReXrheNyU9a/+QIPtrILEEMavIBjU+jQv8QZcBEPY8n3kip
MdO+fiWRp92bIveG/YYBN3BTENVvP5IhLjW6HCoIvk95MGX92Pz0nj6YlrAXcHbwAuZaqxSjniJG
bwn20HAb2V/i0ZlCELrG0ZclFu9nFI+JuLTX/YTNA4Pu0JdTe8gXla5yxNsYgQ2rHDjlQODFkcY5
lKwcnZlMPzn2BvTprzhKKeEwm4MGPc3+GertoS1Zw2K3aJ+BVs5a9Ap84Ii6osOsrkbokDLZ28i=