<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPny4whP9nkwv5Cn/bMnuEDmd+j5+gjP4hi+WIMj0LvbQhPsnYhbxsgjsGwPZ4PeIasa6nGEV
wjY5eUqmm4eE4oU8WURHZbZitLDmMo5/71r6WRpoVI4hHNLYcX6LojtjkNvq6qYakBHYlgSFOwmK
nsz+OkJzMXWHkV1IXc3pqQdu16VgIT51KbiU4J9eXUQeqDYzSD0ixiQcxe9bwRYotliQoXnsWNmZ
KfYAoho2gIkCYnQM2EC8yCaa5A4NE5ZUN19rynwiyuZgqoK2UuO7P9oSIrfDQqBlahMK5IQqtgFO
1pDe0kRg15hZtFHPSLtX/X8G5J1+pJkJzFioaCxjc3riahfX/CClBr5pe3cwAvyPEBwRNfT8eN/x
ZTFBC8KQz2V8pDK2P685XduxYai84EyaMcaeTj4B+SwtLOsEQsbnQ82qqyx0C3M6ukRrewpZXUWY
quloJjsWX8G8nCAaOjSO2UKcolUUzPxExtgTRCVCTFdrmeO5mHUbIFgdvmGEob0sKBWHcMcZ9uZA
qCDJylfhA0bIKKzRa3f8gRakN+Q8b0prXS6MC7TbN21K8iq9KE+YtT/UwYzwVV0q0q9w7AgZG4bx
nnlB6RIdLu8vI1XzGSgrIurAygKm5Rl1PwnXgk9zW09pu/OzrcBvE85p/IfIRW0XB1fsZCcpD3Bk
MVOe3H2hmLcEjk2n2JGL++FZclwhzblb91NS9oADTZwmt7LNJSmI2RB87gsYcN0rU6NWbQhTieAc
zudzleAVuraGQSRL46aRffVJWeohYjhsfnGwU0+Ev1cluJBN02Lqv4WJIJIqzo6DXlCJgR7nBQQN
PxAp1WhmfEpFjCWLtSvJYzjvjt5IZP4W62uY0VyQcDiuyXbrMzDZM3fAAgJtXjUwDewudPhjeD3P
i7PAgbVrl+g/u0nByqJuOz+Y09eXPPITY2eeNFGoZwqCjzbJeqL0AbblQ/yWp4jxcD3Efhta4Wc+
FWJzj7hG//CD5suISibj95k9jNi2ZJE4fA3rg0z0Zh15xFgRsu9PsytfpDlSehUF+FPIJ1FfvZac
GNYT7uMTLZ5jO26y/E1Lq0+ogxkC+35kvywULNvBLxwPU9DQwRNPYuHnkB3m1V79jA1a1AAwxFLS
7533BvmRjr9N5TuNl2ksrqrzbaohGytN6NTpGjd6jOm1AoCBqGXH4BQ3fQaB3OewnnyUJoqBC17M
rsr9q33QydwLDxlrjLyIMrQuha8FNULv5AAJHRyGdSYYK2RKInH9huarWBDZgVs3uupqJ3CbdHaI
hLNXPI914fKb/nA7gB3mkl3J80VV0jNx1NF/ShVbtuQ1hJy4DV7T+nKh8XxUCHzm+7qRLLWG8Ie4
LTnThDhBo31n23tLHMi3HcM2rtemeRELp0yaw0Y1As97ZVj7rtEdaJQNi9V8uYPJ1d0Hpk9sZOFe
3IUBouozYxfuL2fRckKQho55RkO/Uc1Z4KdhLy+YdF1Iv2yvbVWtHnt8i/NhgUVw0FC1f+/uyRnX
kmoGkktCrFoHMzvxEt+lKv0JPCvKT8gcRHtFlbU/nCvk4lU+isGj4JdzDaLZ17vkrM6GEiexjpYe
VNtm8t/ZlllhNTrcfCMx4yuNylaBsYjMLlOpeOMuyy2UPHmipnDo0n2nfYdhI/xBxnfGMf4YQXP7
MSBF3bo2vfr0jj2gTT69HgG4lUGAQcE7d8lWQV9ye0MmqxdPYD4t4p1MmRZykw3xHX4baKL9tTLi
bzUwFUTlueLkM0j1UP0Tl3gPndKc2h028mcCN2ga8pUbvo2OJK6W4rhhC3igVggPHjdZqq8EmD4/
juK6dPIqBUfg8on0g52Alae3w1HaYYDPaCivSey9rfXIJREAz8PSv9P0Jr9HodMbBfvVeDewtZId
fAz2R8GtGxGaOGxaJJsnwhGtQCOpeCT1bIHuQXzqH3+xxn0msqOGRMAZPq6LFQXiwNzTwEHv/DZs
rmbBl5xSEtvObe5ZRIOQm5rlD4C2aLj+0lMTiEOv+I3TnWIR2+1k57ACw7GbRV5Zdn1zpE4gQ6//
MA1N5L7sw+3jCROjlG+l8r/6OGxcIpY9jAzImI0UDEbRZp+yxApDkRsZyUJt7yLhiBIaJxDGyCra
30yzS0xQ2vUAw+ElhWRhAon4nETwTOFgHJYcSO0pSOQxABgE3D5MoWPeKo6BBqLSpTx5gtaoq778
ZaWHin5mZNfeNRs+VNg/6F/ERZ06hflmNtav61IO/khcbEtJxxrnM6VXFPz4F/pzXNj8hrdIz7Z/
27XsYYq4JzGbk+KS1xmIZnOuXBEnddF0muo9A/aL8DjDFmN4+exIIrk6Rj9rJ0QJ2/Zd0Abw0aEv
8/zdwgSuIk6ytwsLVBJG6RjDRJgIFKRIfLc0R0FnOhACDnGctahfbedPRUew/l1QSqRANVJQxCOv
ApYJ7mQ62yJLSE8m0JwBqhIKvp3K84VkDt4IjXkpo0zwJhhX3tntlIFqEuqgxy1cme1G30TerDNJ
kkBpeY+M3oyq2jH2gZjxS3PxhxyeBlTE0f0722zGbWgBklm0bUyCcSQ3DaZElQtmhu/b07T+C1bY
f6K7liHpKR6UufvsKcMYdrA3aWPNCBMS7hBNBiFRRG7dKs8toRTY71Pxicn9bcMjz/VIyUaP+Hd7
tfwKS+rJkUqx5bB/U5asRoNW00Bw1WR3evIvQavMszB+jc7/j+Xi2On/fYgcc5rlfXPg3z0cJNFZ
QJshYM97Dm28TRJbavMtFmI/ii0Wqvc4iXZy0r+a9MhROZe4FjpfnSyuAbmUrQeUIIIyf29EVXWj
qbSmsQ+78rMJ6c/gH3yYwrKF62fQpVhf3TDQz2EMRRlWcx3GbG8YYP4v0JccCTUtYGx8x8Qw4j/S
524/eIPhsma3CgA7mTeVE1ptCYmOOc4Zs5RLL2HfcgPBtfbs5EsJ2AKmPfm6oXtd1GMS7aHssmpY
HCv2z61xFHSfdUu3u5uwlkNZ41PBg4WjX4jLfszvQThnBdLXaBDjExEwbGrpCrR5l4zQAVA9RsUz
AZ162lNDfEiscIT2jGIchUfhJ6Ix9LAmdd1eoJZFJOmnECThpBO7+ZK5ZvuiXfYLjJ7vOY3s9CQF
b5BQ7hQgSnm0o7IPn32fhXF82bHPDmooBNLhMhCtiO+WOFRvIhPXMRSlXGsyS9veK2TTye/qLOCT
+e+ePDXqbvRbNYw6MPBbhk/7+euS3+0xsfMgkHOcSCOeqKVfj6mdUpPJ9RSLhiThJ8Ld3Ahh8LIz
VObKkpX9Pn2rMK7fVB1OcC5aIGdnsyD2rL5IJRBi+TS+QdQz+4EiDAab5CqkKQbHK477bKWpo/Qo
jPTCpEqxaOGV888ShyR5CxXE1njC6iBm1kyVcMrlQzqF9GmXGMNozUil1cxB3yhpZSTGyd+l36Mn
enRh0otMuzYfGzLfs9pSANQc8X6+/biZcDZ3AJ02uBiF18f7peXMi5Tyh+zTtvp6pfXLe1N+ZU5K
cWvRwd+aAqXoPcThVrZ13VFzd4hJR2bc5H6W1cM5I0UzXNAexbjRFjAacVemJcCmaz0ANcpI0G/M
ljPxA9B2PJAWMnP7Nc9kuBZoiLPmYTmL7sdsRnE3saMJH4f69/yibXhvC2gk/b00IH49sQHuz/AL
N2WVNiWaJu0wIE2yYTU2BGJg0+UfRsl04x/4JKTgDoF0pOWBC4ZP1eVyFSerpYX+/flMiC7oanja
CRLlgxCYtjZlXeqwOV9z6j5IbqIdTdr8ATaK+iylxKY4E97OfTuKAonEgtn0+/5xe350voXp13Ro
XcwJ8WKGnUuCFchdzB0A58RmwzIpFOMfUxpbDok6CTM8OpUOCV1+DJva7hx+wDR7Z8oItp29RhEi
a2hSoKpVF+jldPsrqLN7vNSbWsNdPClbKawZoqy3N+kCTKjjKCyRG8XpTTDc0oCEHdPR2gGLkLzR
tkTwQsuQcXlh8WWF+MTggEvx7YL2MuPEMfykDafjzdx1eJ3ai3b3A7OEeVWZuDgLuN3PoVKfDSmQ
BRaeVPriO6ds4VIULv9Z9wbckORD794iNetA6py2GCBRTiKRaB3BaODCxfjpH17AQU1gfixMxw7t
TGO/wZw+iuG/CGDyY9MlV8uR/0==