<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzkRDmRJJumfgbEY9MigUMAlGBma38gZawYus9b//nxMW52AzpLDZBufB/xp3iG3e2UB8b9c
w+SYKJumj1FaQWzJLTwIwX0DJRMLPLwLQbBVNGzREnIqBc2D2txTguuFYqPTprz1yeInmdpWIuin
UkPtvPtx2C8o/nOkc9uUboi55Pl81Q9d+RTvPVFuq48ZoZK6Ct/v7AY1aAp+racRfbfZn8xrzVlY
DcYV85+g/EtoPlm7dR9PkTdSIAU+zE4mnmKAzJ+PedukJPKmH71Gvf9HSmnfWxIqEdej2TQsIJgD
goX1LPvqG+Qmf9XEbbF1+FQjfw8b2WvPe0ddhqYN7FN6Hfjk14YT1ZkfF/NXfDlm9I0oTx5HdgHn
ukU4DrE56UMreBZ7l35RPQme3uinR9laOTC+04/57dM1K2AftvJBvMIussUXvRYipSzMwDjMzIlF
7Mt6u+VeZaeBLv3bsNaDPqdLYzJVWYansx9cjPQgpe2tCen0kDHN+YFU+rsIQ41GiBmEiUHD4Snq
5cWx9QCd5OsMk1SnrPEmHGVnACSM1Tq52aU0VNNvuUSTmVUjlQseB/FRv4E2YMX11DrjgjyjI9lf
+VjcT9EuUKpwds/+YGBg8mYggjIjGyrF47VXWFeeynq6/4CZWUxUVYsC0Hn56JMoQfesZNq7EVi4
2FqBQs5FbQq4ZHGAJFc3cKJRSHZeJ/5r2/ZA8L8xCb0P6j22wNPP0ioyJJbbZ+kPGJeFNirXX59X
xNgx6UqFuGyYGVfU7RRFsgpMA+5ebCvDU9HFU0D+sNlQP8I+uztGLlfDSyLHLWJ2w8P+LMYr/eD6
y+6/kKjPiehu+9UANrq+knnAMEkQBbO/rKfaPNGjKDAHrtu5BTsAdgmqUD+hTkOuuZX/KUFPs8HZ
pUpP4F3PjPHMBRwDF/lyMbXlJDtMllF2u+firDNuLylP5tnMwpU67Ab5CMCF9OUznZSaQHfTBD9k
3+vfP7tYTx/zHF/yRJznQ37EvybevSX8SlH3QIGGbtEXImyBS64PP8Exkw8vtqJfWffnR1JjrXBd
5/RXz1ccENryxYMru51Af8KNDFcHA+7bGiEbtwkL6z5vbZ521BHCzkxDiZJoXRgmjLwtrJw9yA7c
Aiua8TO6c/4+l5wTW/HsqdBRONErLS9/jjQEX/AlCm5EbJ2xAu27A8RHILKaY9PXDcbsdFmNcMkL
dOD/xO8WRup3j3LSLdwRcMgj1f5ZRNpZKs0SvQhxCSR6WeBT/qHmnSl4DNzUIISMzERE0uLfa1qF
cmgRsMSk52wLGQK1GCzVS2yaSxy9qwY5Xknm5OgNhdQ/E8FFeyyW/o6/hCFJ+XvuiSQrczSgTtvU
ijgYnVQBL8NFsC6qb9iDvheYYLxDuNERDgvN5dc4mZdp5qhLxFcoQdSOyOqrUS4gFHa6SittK52t
/myUGAw/m4DwgHiXuKTnnZzL7Z/FBnG+C+qQJiNlwqHeCGJP/6O7TErbwZWUOtimimvipUW7p1o6
ICYaIO35FrmFYHxZ58Q+H8bRXAClaSLZlQCsem2BAIYeo6HTPNYOu0Oroqa7LYI1moPCtH+Hf4D5
CyUDhHYmATQKIyEFw6aCHDyYAOrbbnTCm7g4n1Dt/01UzbxGntaOkRtvAwt+/jqPcVKrC0BJsZcu
iGhc0oA1tRhLv2wXvgn3OAnaTkUurk1nUbd2ZEfDxfbIQzpMjRyh9ApDGKedVetMfWSfEyHGFoG2
8VJLcFssiRYc09x66vhnfF27zywn6i80pXMeKywBuhCJArwJlXhql2Ql39kL760MPpvAyOvsg/KY
wVcsp0CS7C4fnXZOp6zcUPkpxXVDcNUdx2yFwKPdcAKWenypIVXGPL0fSLK1lO8eHUgquMejbgB2
FoYERN9TMQh9SL/GdOXMf+AMRj3tz1HGeK8t5/QF+4tHSrIV3vB1HBxYvSTe1ZxpwXvaaYrY36J7
U2wG98OuDjhNtzUdHrSe4CM4uDCAYievp3YIE/R6gyxiRpL6cpt+M22JUV/8g80fKOXxX/Ym875S
3wEkoIMTxYzWenc1XJYWnDJusiZzSJy0NUGMLtOEeJz/NGtp43rcaptigEQKxY2R0TfXrcPsLg2z
Q873PYta7p69pOsD2aXtPRtSsFiLicKIbdidz5HYwyl+0t22aPZAVKLI6HuvbsfVOvqB4XELSCVE
6TT3ikSe5jDxIwBJ6OXZ1yJg5VTia29xLxtfHgnXpoxNAprEADlt07U465vXbbIBjXcERSxWWDiG
079Di0dV8jiiczzFYOmzl43Wm6mZKwik1mbHeA9w9qO0JCLYIrTkWrM2UGEURs/iAKy6m9+kguaV
4+EhWUrxFfShWUxebQKFLaH2fFpAhGINu4krqOHbpBPV2Ly+ZYwS5HAaPuR7Lqtw9hSP3+bY2JOY
4TDO04D/xSaZKZ6j9+eBTAFGpV1fjp0Mm1sDpXnvjUfmK3LlAnC5lSgVDFC5ZtOug8kKlxugVjuv
w5KuISvRvcpoHOxjKUnPQiyAbzBbStDZngjsO8R3fNp334fjMMmVjbaS6QkACcYt2d0alFMEMZLH
9tTKStvhdtK4ak2Q1YxvxhXsIjNNH+Hvki1h/0J6shWDGmnWuWiqX5hKvoQzbfLwFz17g2ML7SNn
sRN6sdiKT4baj6RlAwbD0NUq1OuoDIpc7sg8+Di5DI/A6ActP4lU+klEvdzYrJBSzvjEnfIWDUZG
CjvYuJ5e0VDpqLWuHal/7p+CNvpJ/kx9jE84fIg3rwkzmip7JRVXFJdS06cBs0Gq5Ur8VrZrf+oT
PQsETAeloIjH1No55GWtScxtt/qGQCNuypfbSfdSfNWMY7z5wtIqUjbEbL9KmDyPY/MT2lW/jQks
jpWor1c0AIqbM3BRPYePJ40gK8LnEv0un5VBhmm305bn81aYFnueqopb90yPYfEiMu2EN+g1Xaby
ko0G6Sb1/I8TPJjNI0p5xFdQ/9/fw1M7qxcJEH5+c8YKJZGT91izwPBsAo94fETv9x0qbx7i5W8r
Neri7X25y7OVCkPc8ZZrV4ToDNnmFRF07L35MeG8Tsrof0qRysw9+HzMqgMT1MbVWtKZnuLginqB
fjKJBdhIkXEUzwZ/MEWGHRlwItp84igJBvagrPJar6vN/kAMw3JzhktXmiatQ5RNQy8iyuWAS1gE
/66eAvsNvhObcJ0HGiou5JW0jOlNDqmtEfcaBM9pOJ5Kq1CCNketmELQ/9eLJlpDKNiKBS1S4VBh
L7PGjTigmbj5xZukSQoQ7Iyh11jeH09dZs+oo1isdPsmV4kC9hGmlijVk3Z40Zx3NtBDiiRaWHQM
Jg9vET9O7AqP+JjAjoxOELMhuag1KskQrcSwqdHrUtkQ+lsNLopdms8v619Wzx3f2q9xlDv5PNeI
e35xD6X5P8sWPG4rs5dmeST8eeRuM1mwR8EHKawxeMIsU5LkFSnOBOCBjoA8kjd/7XI9dRncokap
zp87GgHE40T39Mzu83raxJXsGFcGch5dPYk5Z3hKkJVHmyhWd2ws246BXVL1UiAJE/TJRNKZ8EXA
yv23T00AqAj0zAbMsYpD09LtIBFTtRkmUkxzi3wqB3UukxU7lA156lvqApfETs5wnApzJ8BJG3hE
b7cr8rgenJvokHE4k5NNp/3/KaQbJvCaZYVZdK9punibJhoYVvP02FOArQfCUCEcVqAjSxk6WKSm
7aRZ6Fms7N+/u6qaI37wBxVmwLx1DTrEz7o5ghdMjWNazyf13gDDe4SfyHWB1UDQdYirDHVFT0KX
RJDhMxTWvm6dyiRGT3Vbiy44YavgxyIGBvJHHhJK9Kc9UTmFaxEjBEGMtLlZCYjsINXJv6dHuAtl
c/xib3clNCC5nYg6W2Ix3s779FUr9Sutgbbjp0DRZPGKdwF9mB3r6J5SmVqk/uF9Oh1VvS4m/nlI
RR0moEJm0B4it5YKMSAl3U2Ef+jru3xm+paRr3UwMdna3j777D9F8kCjta8gi0B9fTfASWb4KLS3
0PYK68W0z8tI7EnOuE92FqGkowzUMEy/8bdluobpSS3Nj9E0UiC=