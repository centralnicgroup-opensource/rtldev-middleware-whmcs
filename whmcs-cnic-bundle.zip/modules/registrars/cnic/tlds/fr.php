<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmcou2z25Da06tfr30f0l9taAGp0IBo+Qxkuv5SurHdPFPyd1Hq0+zHv6Iv7vc3KZRBZvrE3
thv/ySoZYfqMKhJZYxGL81alAxqGpakFxUYFnypgElVKig1BHIESf5f7ry3v9MLml0pccAtcn5Rs
piG27b7xeTiVV4+BXu04GLzRqr54OlfZNhL4pUGlXkf0/wvTqA/CIrq/icAVHamh+js3qHKTJLCN
SSSE14VHAs2139o1JclYWO3m2rrnbMKhEFaXAzyM9OqV3uQwVOh17D/d/C9dD/AMsjsST9qelKq7
LiTp7E0/V+s80lV+hcIDDng+EkEq9iKHBeURVjL6w5gJPWkDSY5qp1sOwb6CchU8arzbDK2vyhat
G0EETAJeFSRzhbJPGvirJLr5UPXlDscREOZTR+YnKHtCcRfXlc6v6SXADlJpXk0WgbLGLCzsjemh
JL6AIgpAivCY6e/8P4ujMftwrsNRYCyc2VwR5WHZm5bNDVQF28xpe/ER68RJ3opxXfaY2YX9+lam
zSQB5FOmYsW8L8XfXAnF91KiGRcrOC2ORSW60suaIJu9wq+6U2DYq5WbBKEiDqvxnwP0iXbeK5z8
Hm265RTFxfOW1J0tCXD31wbcgmd3OeO9GcvtMrIke+bPO9jsMXjJW0OCvUB6EbBOCS98OyCnDtWC
0vZgStXI/yE639RC4Ynip88Q3k2eKlpqmRjJHeX22S1tIrdWp06/J4bIqJrouIwMLdeUsnU+dquV
9DqjV1jLTG2ReZ4SxanYzHY26myTgfbOoaa63iv85ouUZ+eXtYUZv96T2mEAkZIBzI6An6Q/f5vp
wcGoCyhRfIvparCcL0khJp1hJy31JrC9EFpp87DI2o+S3Flx3+W9EV9zZ/+uuO1KCL0U8ILc4CmG
WaY/e43kgyA87DLLtzry4nSdWt5t4Ql9SllvLvfkSGq8C51OaMFrfrEenQcejmK7tLvtvIGt1FAU
VH+F4WE6ZFd26BaYTcA8EpkFNLCzDGhqrNfK7SAVCE1Bv6rXN5OPAmns9Gnz2qp/lXBMTwHeYEI0
t5Fkg9hPieohhfHtbBATpgenXYsA86ZOHZZhkqtKSOHc0JeRpSi5vdO/l0is9vt3AoYodbcZt60q
frJMbPZrCB3qvownsd2DXFuBgI/gbN8I9vdf0uFBLIXQYxqeIqvZMqxK9NxXEZdsEnMr+ssNUM9O
xoDw+hM1ehzTay8wejMR1GzI54BIUr2IDFoJ95hrB/HDT6s6UpWW4seO2+qbazFaZt0i3gVzBeZc
L3OprjmsMdBFc5vsCVVAp09DxaqgZ0VjZXk4v8L+rUsHEBjoAF2YjlUABgLI9ocWJJyzxaq6MqW7
2DAzBz548iNbXwaVZ8sFOP9Dbr5RNX1HGFQc7b6rpwSODMvvQJlUlnaQqY9b4kRRMucpYJMTlZPi
atJngNj2c+38Ia366fpQGZToRarLn68nLOIn3r7/iDHFlQ7KFz/Rxt26OV4oEKVgo5AfFdSxQXZW
crtT1/hb7JVSGE/eNSep0lNTHl0c0WdATcIgBKspZ7jmHT9lHD5HduzN7/cmu2AQ9XAkmnlaPsLu
zYlne8q7zFkqv8/kso1RsqoNobCjEl39yfItGoFBirF9jiVu5wS30gAx7rx+mbw9kRDwOjmiDGkI
wYR2NUPYgwKvayG/6oG4NvJLttjH/TNGIQHduCqPNT9apScnq1ivD9fuCFwDrbxcNmF+xn/1y5gt
yxsPRInJbWzC2iMvLzbtLw20iznmLdnMp/OabyTifPs98PIbIErYOVGMd6DQI1jyehmcFXRS1UDI
MF7OlGi+hrefsscA9eqWzII53sVyFSAJkwC8S7GFzwDBJ7Gp4uuzLbI9CNaFTm06rV8g7vMTBxYO
p99RnkqauBBQOqr+AiL5BCiPoMNkkUZ0u7p1fQoeucOOPGxhaWHaNvs7r9H4Ju4gSRkRGbn4fPfY
KBMSr8vUxaEzyMUW7/mneBUYl1M4YxC3krQqpRjvohjahOBjGoHR8Toud/+FNrvduWkaQlKWkrn0
ga2kIVvzAfvG5jONhZwMf1J8P3w4bZZ7Njvzi70UtNNEMxa+D3+6xAHnDOc4dNmiiERKrsZwYudR
A00rxQh6Glpx3RCeS08ZDpkLB7FnrztVoDGzmXPQWHwI1dlR8bXHVIEz51fzT10uYHfL4HDGLmmW
63BnGOzQE79JqMhjcq69yifUZjI43JO72PhzBwryMBbltsHyV+c3ffJyeDwpvAdACxQUdbyDQCwV
pk8CiJkL4mr2gMsHXHDgVaYjH1Y595qqMU82SqdeiLN5gqIIoODbpsbvS/WOhLdMubtHJFetKyTl
TqJj7V/kqo6V0nULmtZ8rFYYpl/ab8ZRDas6pJgF/MV2ek0//DALcE6uREgWLF+507sYbMMaptRu
+z4QfYnfBdKBDUakrrh+1SpQCjwbY64Iwnh2+QA/rfGmvszvXyCuMMi6FSHTaCJrnJK7PuEUIPYM
XtK4fNjc9Xxck0wip6pl5f0KLPGLkdQNuWVxFWLppdx/yTyN2pl8fIlFjZ+iS0xmeMzbKyJARfdQ
1ibVH6FG5ceT6DCgcEPRxH+ouVMbI82luuJei23Ai3fDnaEca3kbWHX595Wib+OupiUmo/i3Jwt5
xOiDYlOb9cy7EeOuJERDkTleZ584cWppAEkdzFZKrHV/2RpEgKzyuAFIgeNVd+jEbw0RTJHBpmYE
KsWhAf5xQu8McfFtawQP3yLG6WtT6xosj9fjovBpwA+xsp3jzCgFNpdYX4kWa4zkv0RoYZSL0tHJ
fgQxUbpXDOd6D5C9lrDge6plNhZJP3FtKEWOiDG/CmAf2dBIqKufW0srX13xbs7mvXd8CJRFrFHI
pz2tygwEkut9IiL2t+s3GnbsB+nFb00eO9MsQYoNvH//NBKKueKIwl+AQgiaoaawMMwXu96Hs0tX
1e8SdRhzRlQNNCfJY+VmOlG/x1MihKu/N3VDcUIg9lJyDFjWfv4T6W4lsXQJln/zTDtgSuEJ1IRc
Eb6TXPBQ68i7ZIPm45DGf2T7X0H/2C/f/jiGmcGma0hSXCemWIcwSTkyYCdNbvTh5KZySPxQh1Qo
jCN/qsL9f7iFd3CGZcK57z2fpsjW+YuPRRkFK0nOxX05wqQli+wQq1Bl7zfRfIjYZruFObd6f7OT
T0pzxaaZoKF9h8pYqWJK0Lu5oZHHxWHjC1/0dDm++sj/Zfe4fMTK/wZqoVXSYDeW4sJ/GihIbPkT
dBgEDawA6tBba04/IocQ7QvjpFnvNOq+C0nvyLMKcR1Ra+9URuw2tcuxQDt05VDdDHJScDaHk2fT
Bw1kh0JL130qY/h+hHG0IyqmOgMERSB41jeurVgrMv349onsQfI1gaSAt4GmKfRQVMr5cUIq3G91
Nnypk/mehBQXK9/o6rSqFxepYFif0aVDU0hqj9k8FXgf81btc24+zAhpuTqQD22yR/I8eMDLfGe8
jc1uMKuqza+3QEYKVNw4d7285OOC2OQulyArROdQFhttanoYtJtxMYcDPaGVId2ITfNeuJDDdpII
MNWAtGJmTX/7q7LIWvkU3pRorDfK4soFLOXH2somrS37euCUGWn5TvlaLC6BElwclWcV/P1k+l45
QrkTuwEPp4dQA5//HrkBgbVkZChFPpLYMWxHrydAS5hlZIiBH9MRqhrtJoDwuAPyjO19FtPQhtTW
cuEhb1E/LOzWcphR8Di6zlRNXGWg4CKwBC34esiR4pK/z5O9SXWBr3B8nRYAqtejE5iJs/S/mJih
6ucEIKrYmSEZVFtNyLN8vNf7lOAzq/9CeKZNJujm5CbMGyBfifLvpoKYiybQZUBd/UDtwRQIo1F3
Rld3U3tIx0D3I5x+Fmr2s5s9j8uZuboiOOzg4T1SRdyKacvzoFoRMIxKTgbqLUKRoPEDERMKpO04
zNaFn+crd09DU0DOkhl2coowDODE24zjuj+ochf4YLSKsIa+Xk5jyIdrlfZiK0fdStl9EBKW/aK5
WEywkt9txT5E6mqxbiKDVQd0qkXnsBXNFfGIKWRD7KtJQgdX2fQh0IufqmVi0wlInp1j6aAaQq2J
oD9CSes++OJg90==