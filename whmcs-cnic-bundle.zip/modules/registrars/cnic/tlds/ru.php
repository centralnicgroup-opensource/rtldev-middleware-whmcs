<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+NbcdiRUdzyuYWFM7kqpaGSpfz8ydZeFhwuwCXAypA+AN4urul6oME0ppQTqw/ueqjRyX4L
+74BIgt/aFuN7wjdEg5DtHw3sFxxkDUEjfZvKg9ETSjhys1AfXPYAGeS3TZLRCytjGXKMGkO+qR6
3mxhTJJ/EGdg+DiDKVPEzMoKq61sf0WmI66bdXRIY+G+M+YZe+mi3u+p3OESKz5juEUxuDcRs+P8
UdR3pVb+ICmZcstv14/3CwHr2C09uoDvMPBRzJ+PedukJPKmH71Gvf9HSqPknoYHgbYefos9rphj
Q6XQ/+Te+GpWdRZPhVris1+/Zn84uzwjXUw1yYrFOKESQo1CtDCo5nxcXgVId+PLDf8pOrUK5U0G
G/JpaurOOytBKnWkeXRd8oIe1UPx4ZVaEbF9nAqTBCERvcTsbDi+DtsMxl2SCvFXRqjO8kgFf+sG
a06CQAsILy+PWOzd82SxQN+aGj6COql7KBq1sCGeNtUoXlzmRmJr3AomWJI1cleuekAGip+Vvh6w
DewcZeQxi7JP4eJkk6rBQG5lOezWq8MAj86anQV7Yp3TBHirZcmPydJxN8vWk7LGGJai9csO7aB5
n9sD5RLGT8GHbcZu4SnZJmsN04bjIcRI6CN461Jf62K3eMO2XVy2+q9764rElotoYkh+dTJJmfPV
xTHLIsTk1CtNtPetJmoxSZLe6JLYIuag4W/H0en99shDkuUOQKNBBVzQsBV9O5q262kvD6S39yCi
LLTqwgIr40cQEEJfUWQHUaiHfb/dKLZ0xW1NXcUG/wif1f8gzKAC7OT8fOfhTjLIUv+ArkNhtk57
L8RlhNrE2/ft6Y9hGT1uerJnqaetsGaLOCuES+Q0v++Gl/BZS/N9DJuxYJVc6rcgwbdQv33Q1U7W
dRpKbq6EfvV8HzdP/Kb2CWBIg8AQ4Wbi6dpI0hVIV7bubhbxEe03N8BL45JDq/FoRhDJcx6oI4zd
T/NcehKPJHgpAmGAoYCF+xDAPq/392HdAW0BclaHnxmZP8tZVUIAT65Zs65XHkueK7RepJgcIi4W
7FNWa5QZ7GDROpY6CqkQA77N1vSMw4izpFb3bSr4wAVSVe4ExAuhc5ZNWPn+b7ZACDW5lVv2DEWJ
Q/WEM+3rQKzloSZHP0g8jHYrqEAyeRjKA7UN3Wr0LSLq5n3bNKHSXSR9Aebrjsn+giE3dscFfIiB
0ennwvbPKICo9bkMVMJ8gkUA1QxukqIHD6bfUxZHh66tHXiRa4grS0b52MI4kjHG9RiOphCWFOr8
tjpUtasCixGzbytuRLK9+7TpLS8iIoUnp8s+CO1bHK3wXP34sHTknyqcaRn4zDokrj8KYV4PShKj
4dSOFUqjzfzrGk8zYJ5/JwuAdeZLwu6k6HACmnpngh7MRikbnsH2kjZlU+nT8a5GhA+dfIImqouo
2p/zin/3Src4eg+KTtyezD/RuHnmAAjhzKrJDy9hI1pxa1PAq+59ILkofF2zcQFnXsPEHZhxebgF
pAIcO2Zl+rkGzFUMIINlr8CxeyQmMLYlWIVNAOpNEnVgWs2giErbVtx0j5OJ7ifwwRclQNFKrF04
n1XTQ4a+w6B8T52Em7qthsD6s/1POLL7x8D3gwXj5389f6nqXr67ionRtM5H0jlSFwiGOAYyDU5i
ktdyqFTBkeplW3GjdHHofG/xdJO890OEANe+DO3hZT6wClH9ELVZj9yv3un2lBPIvxkhWK1731HR
rWjkvxIVRL7Rh2JIkHRG9rbYMXXoqK7xV8SfMazTsBt8UMcdIGqzgfVyk8nmA1ZMhmRWD1W9iJCA
30yVU1OZ5uMmudrMI4ANbBqVXi45JfBT6oXUmmfACjUZCM2M6wKTLWKowRoi8thP6eM1/mlYEUjx
5d07XqFbeV+K+LZJZMJEKtwzoMK+Ghuo6WIXdGV3v8D3Uk/GFfD9PSPVvwpSzHNs75Attb2l2lIt
rlsKNlukkg3vRTYYzbItkmae2X0EiiCHGldJEmlNqO0C2MqqKbK1dqSw1MSIXqkC5lz7fOOrU8DR
CnI/qEtcGZvjczUMsdjUijVyZ9r62ECnvlWfACKNl7qI6McgAI60Kjsm1DEVFr1TD0NcTSe7y6S7
VNSLcFwd2rCEOzHhmolPj4KVGi+cTkmiWLe5ixyDf1ub8F5kCTcScHnKHSbL7rEho5+gf1Tz+xvj
QRxLnmV+Sik/1OVvm5W9O30zJKI0oVYV9wCfH2IVK5Q4YvxgWEo+kvw79fZeRWastootlGsIBvp7
7js3SMXRzzhlo5AtaFVLYVUBVvlaB4C4nDLRisA9vce5uA4vuJ7vaXIFrBoG5KCwjJ7OpmwW5rKp
EAz5Wn3Q2Fr3nsUJS1uHWoba/kHhpGC9x2W9u6gX4T1on2chsf53PyInSZ1PNmMavqwMUugaBUzV
hIWsrRYSMIgsNmR+OMq7AkQvER7E7eh1bt/BaWLuwUoylhWBbFfaaOuGymlwCUbg9g2v3pdgANe3
whrnQkyn/g56/D4ZB/zoWp+w/yMDenQIiUz++4p1xhD4GgEdkttPPi6yFnNuycneJw0BoNS/llQF
s0BzTmJcGsbfDwc7LUTE82ldxou3DIMUXi1Txna1zTpwXxogOcDiO6OW69d8NrcKxtUizZ9zasIB
Q14ncxgP1lnLk9qrfB5Zd4hUhyCtswTAlGaXD0L4dd+JVdVga2uKdmaF7Pe3uZ/cA7p5cXZeH3DJ
1RhWgMR9ofQxFoR+n9eqGNbPcgLc01syThX+rYHa+HIJ0nhIIbFTTbJ1gEX9GGv2eDlHnqGfyA67
priiFWQ84tbELRRrkB+xiW9yocMziPUDDNMx/Kd107t6TzchaLuiCEvSWGU0xwm4uGw3pioMZ8z2
Q6pKGWdoHNeBv/16vAmEAewuXK+WMjXA+64EuYqTLz74MA7crHhPMQo0MWAd0JjoatyV0MWZk9dj
T7NC0u14If+5vAmbpPdZtk28qOPTyDzJ/HlCTgI3X0evLMYQds7ADkyKEA013HTlJgnpFpqaPL9v
8fXlKHOS1ZMVsYhHY3BKN/PqXAn2IZy6aLxCV1CtNvpPIj4vX1eJLfYZaG6JTTbgisSBi6C=