<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq+iwIjeFT8CTM5y2CqlosN+kqEIWVXwF++U1+nPyjxWy9hyBN2qOpY+tx+lmtYu73xRnNXu
XQGBjawxLBVfPPXk5WXlK9uiCXytnfi2YzzZ0nTmJNmO0yOgkm1N/BU0VNYMtk8Ll8srgScwo7RU
E73Brj/SgqAucMkluE+RFQT39a/wWOr5mcaFnqRbK75ffPDOIIn5WUBnu8yYoXt4tcr83/o/6P5g
iO94p2bLPlQ5+ovyP8g2yGIr6OtX9MNqd4rIPafzvT9yD39gwpBCSAKL+RgjRVsIvm2HbOMFzNq7
uL1eUl+5r90UjWIxYsX4jMsGi6oZZdNddZyUOsFwEiyen4pPa3IZX0D0uQBK6e66X+FZSv/FqPFv
67VS+3YxKQJ0ek82kr1Et3CBNrXztWbtM1MLtqrgdN82t4Dg5JvPZgizj29uOqw6oEc8A5ZTv+dn
PrpIZ47IQhLvhAfBagflt7jhdUiSC/pPp6ReIAccLXGC3fHrtrZeVLfc50phQJfGN0NqTUz7MCRU
FWl5ArlNBTDUWCaWfBPO0pgn+kjsqqOLeSVNfiMZL7nJ+tANoAhx+7ZQVwct9vV+03THDZqB2N02
YjIu57AlIuWfIBk59GvL3biPBtV1yb+NrTiVfATCfSPl8lZeH7fCb/WDPF85OG7fWbCfgkE0O4yn
d1jX2sw8xEOIamQFU58Cu0E2/rM63cM3HF0JabPnpvLCKXbZYjWKsrj9erYMWwz8IGISbgvfcvfI
V3HLD5DkN9cYbwseiu/BaApHABSgxbny8qApDtqcJHabmvLyvy/pS0C6/wiVoTP3qDGZytxDsExU
a5gz+/WYlw7JipxjCngjjLesE+XL/0jXxjMc9uq4zQxLfJJXgLNs3Eu/fFbAfXYX4vizXmQFhm0M
7Sn+EJ7JKUUzOn/Gr64SoQ/ozCpo23COtlZZfcWsQEouAtFyA4I7bIRrny6nHIvMATEbDgy9lTam
NcsMgT597cwCH2BYVixTeOj0N/SacrcLq4ozeE2orpzdhb5dlS01rwaOjTHeN9Ck7nu+Xkz+rxhU
/AVwWV2zHUqm1kR8j193eVBxQfIuIJh8klqeHmAbJioRG/Gg1Dn6rg8P9VyZktjp49d/lvWqqQbi
XZXbaEOVMkCdPgivWkQAMXwm+erHGAZVp0eDtv5XNlRPhUlhfJqAy2pxT1TYFq5Ogo8vwEx42NP2
cDIHDU1NyaNw0Kkv63KuVOZl9cSWC2ROciPKj67hAYBLa57DDfoKeQIc3wlc5vmxtH+qJA0rdbpX
wmYO/qokFJTsmuA251nAQ7sype0xZhFFA1IRkL6SA91HqvCtjuZ/ZVsVNsX09u8DS212J/+nNZK3
wn82vSQon02gJ+hpzamxqtl0digpPnkQWDVNuQByW0RVGTJLY4hpbD90PQK3uCghh2oLROMlwiAq
uHqjn1SZW7Oiak1dAp9je0BKu84Cw9KAFp+k2sQVueumPP/sCsNtNJzyAA5SLrMiRlvxfh6Aon0D
uRHH9zx12fcJ2jtFZrRLjnieuKkyRhzVnYtAbynjpqMa/+qGtj4fYDm+m1f9JPCBvzgG7sXPke1G
Nzd9cqhym4IP6eRqSRAdxD8ccsTQAgNllvFyEZ1AMIPHrcK6nTDSvt7q4k0D/a+TJBa+CWS3tLO4
ckPAqiMnNlFa3wHLOrA5tulzZ1jrFGkPW4sCQRGwkHIQxB/rLjwVc1o2BXNoMcv4bh1NtsGVADhO
IxWeQ6+jIwNI1lQEPC1QwlcDisA+KULYSZgLUn0EpRF3HHPLppToZd6vUisGxNz7GC66zvFpTGon
RgmLIDj9GEEsEEqqDz7spGf2N2+dfwDuRSBK2BXd9/HOHYVto6zHkQr41//G2iSRpJcSWPJgNXyh
8TtGhNMVo1PXO/+5Q5r7k+sotES7IKdzjkzGD9M2qFOz3gZO214L8MI8b//N42bl1S7HvHp6bxOl
IBF3AHx+dMUJ2EO+9sxtPBEZ9ODNK6TUjds9P+HOP2HveIZ3dDnu9HBG0Hzew/MhkvP0MWYh8dpi
UTX46pi2THMRAWpygK8xqYOXCPRQnKUTx7gJ71tJtC3E1GE+l2gyQ5ihzSwMAlR+GclZMrTYSV5/
rk8/7TjaOUMAl9zLzRj7sfzNYvUztSPPWrC0MjBcj+JpFcvEw7ZxNIrFJNhobK0uWjrzdUqOlSX7
r8iJ5dgIa2MO5jD8Ww5EGCHe9tTN+W08cLtJ25xegnWc0Ly6AwRNC3xyNB7pse+2zhKJXlOG5ox2
IDgOB5X6BUv1HvajM4c6MoGUYfqKM6lSgECD3n6lELRJ/3OMIPjxa2linmnLNkqbofEIYdl9UBd0
4rgECGlvgncqKMY19DMHtONBOu8fTKL2sAcw1Bs4TQ1MD4HWFVyGsJJztmkZJOiqdgfWBfza3sc1
cIYCwt7m53qwv0tSG+GSZGxwKzwMSmCmniUkXhMCCNQ8A3bcYuw2OTZuQ1oPh8UcefkvesOWh7i3
NyQ9MWOCcoferzreyPnUR2NKGMiu/Gi2EXpMxGZBGDztr9iu/6aTmto4MnGrRXizYTousEhJRFdW
xiQ11odu/36LVGNouKM6QT4VrbL8wavM82ufbIWgyP4f/0dTAC60j5/fFjxIoViCwx/fw/ydpVwN
9IXCTXWXKh4F60+rApzJIT4AoBEP1QfPJxXnKYQt/3u8r+M3uS3Y61gTg/GB/a2QSkBPHC+X9y9r
onuzPfCiSOb491dbOKjOwEhveOthNxCoObMIBt+QQG58piJAndelzSxfVMILxuG4KThZDdfQ0K5Y
bYSeL17v6sabDsW25x+CGkaTW88pK4wnTSn8z8iMShbSbcCJKU7em8OcsXTGxiWd1yBHrhHfnhVC
yfvdmhkOfFbMeZRRS9AnBHxAxZWgZTjTVJi5oI1spKcT6meq2ykT4x+qPFCCoFmJQWJjQs85vWMR
Bsob6tMlcOeRL0Pz/6a23FMGft75XlSh4t1d8QJGdtn11eF7TsvvceeatNjcB5jzyz5J11tSilSo
BDJz6d/q8yjqJbGXJwyoQuY3P//rn+lqonZJ6T/n7pdM1N79dsIq35KHSoqxf3FlC2a0iud+4TDS
r7ky5I3bfG==