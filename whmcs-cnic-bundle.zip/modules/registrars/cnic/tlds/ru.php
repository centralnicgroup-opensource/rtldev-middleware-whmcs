<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxHiDzka/OiSiQ6Y+34cVPX5UYJXla+vn+PdkHifDk4ccTKPW10fzukccQrIbh9lfsSs4dGn
VuHRssMSd7JyORJ0EuqTSGWbtzIoWj8g3KJ3wI9xzW8V80vPjnT0X//bUrVvl5mEiFm76npaOB+Q
aKbCynJuWNgiVcKCIJV9G+eFNDyfwK/8FILm7DjZ8Tc7JsXHotyAMP/8/Mb0Us0sVJVKDANOPZ3e
0tDgRog/9b7/ePM9mTmG4lDYSZz408J51yI7aGHotRQKkYsGIYej9Xg4jFuuzsJn6I1S25NdtwgX
GWt0w0+2y6Owjw9aza4PWcoEl0vWWTYNjgHUqHkEH3rRJodw6ERzUkHOk75/I1a6moein2cT6oLy
ARm5jxqrDYW8SPIyEz+k3qJ6MFuCQPJNzSYjBh3C/1FBMfGLtHaZ16NlPoBXRaRYmkMAYRf3lq1b
L+7WW1gDtmydkdb5l0NKdmjDj6VGsuy0AtpWN75lrRuli2GXFGy0kAakHaKei4XVKVJ7E7fhaMw0
r7aJnGWAopO7kMmDnDcTnPpCUi7RD3rIIY82wcYvT0XiW5D4X/pGuXHQ22P85RjwsmChs2NJcyFW
XJM3Vbkqrp1gd4b0eW8lPUwBHxA1fx3DtPPGKWV7JqNn5LR99+BRhf6vOO9RtTIQIWacSZCgUn5g
J8KSbZipmaoQY74z+zkFY68PodlgLISA1KU+CkQpQniRioZPalHzvfbSkqDBY4VefPThSnNLQumI
Mb7YEUAw5ILJy62iDMGuUzu/m3UkU6lFk7fQMd0Gkge5Rin3fmPoo9/9fqVAMzu3AlUDxbnZBP2Y
yaNrxymXaWjst55OHnmPM0+NcE9GNYKFOnPKgHTdfJIoDIU6iiZzXAbKI7IZaNMLVYG0nTG2oNJV
4PCVwVFrDz8xGE4icyGehNCRFu5o7dsk15KBlcC0o7Hq4OMeX/KN77FZHiz6isD3s726QRcNeMTs
1M30Kc+8EylzISqZDzRZPNRnnJ+XZRypAmLFTHItIgl8ZLIcHo+5hNTfKStlz+8WvE+pivYKHjNu
Pv/u3UN5pzlh6O23x6Llp878sAu6IVHX7Htla4nZNMWGwIvwiptZ/m4LGtBvoYE1Z/+Gco7T4egH
HaI8dGxSXeNq+FHvBZf4Vldt1WKT30D7S8dlH9Al0cYAX0QTY3eSjmdzXrgZGyNl10dT2a0E1UGt
g1JeLdSBnTZYUrQJXHynL+2MMn274hBwrhRdVaGV67rpjgpmgw0xEGJBW4vwrjKpRqTna9BjTHN8
LP3ktfFQ2Sb417FmtD8thPSPeMTSOY0ZU//jsdAjgeYz/AIkrsgoWIZthMzaWGGZGnTU+psNwyVi
ZTz2NOMA5+J2JqdzD04Gasvv0KDsPBmE2pE4qb9Du1Z5OT+bOYR62xnVf87zdbqpnmrs5MtDLjR0
W01jjzgsFo/ZPEL1NG2J5vsEQQLDvQFZ0iMzuMr6qqOcroeSPholHFcHC+cxAGC/90wI+Gz9EQCr
uhjmGSDzL9ApmHTlHAK73oq3S6Sls3drgpfU8XmboceLaDgWDKOlGZYJ4zVPaKGia1vKixvaCO8W
ex6vdBom+ru0bJDk08/JGaFwS2h9tfvloVPNEt/zz/jpmKfD0BChz+se6CQg5sLYCucpsMscPFnP
Dq0RtGvzJE951zsCGknSlxCufhNJv6DWS7GbF/zQWgDzkqFJj/aKDZK+NpGwWIna7B3j/pk83lFD
f5spnZIcQx6pzLA9fStlBKq3wV7K7oOd1x0NbvmTuJ1aP9UA/F9oLYxxgSXDe4ewYSuJI9JTbs8j
Lgz1B4qioSZw2MxhBdOdvkhEuGfX6hZATQO4lrywURx/oSD3QIBfsY+UpfvleX54EeyXmPbYAxX7
09OhCBVQ6tBm/Rgh0fFW4XQIn0LRj6spV9k2O2LtZmFJK8rcqXkkQmuefpvkrImCWSpzNB9894sr
DdEMyQk4fg1J5dHpz8hWp/kGKaWKU6nH/6OexRf+Esw0+GkgqBfSgHBSUfKG2mI15xflQEINp2G5
/wi3UkWlPd5/hsqsyc0S8xIvQr3wsKIgz9fpapMLQi/dxx676cuN+k71Y3hAyoyJf+bzrjYfEpMc
DzDPxFpmLPswIdxPtTahcx+ZXEubeF1wU8SmMpFwpFV1+vi8xY3JTx5/85VbPICfbov8ZXiz/ym6
6PJSwtgO491+Km6+OprErsA3JCdY/2fPTbHr661ya0dk9b8dsTsAPIlb44YbJ3SvZtobg0VRpyJe
iNpDlnShM8BtyM99/zBooMErdnXr613Cs30WPur/QFEXXMuNKxepuXOmrvHwutC7S4UmBGvGQsgx
qjW9764FIWAOH2iglO721RYW22ZIrOlD++BE8IN/etldV8LDaKpx6QHwzth/pS/NgJvGY08cptbr
9BSVcS4L3ZZCN4lLIT5vwmXSfMhikL9FAW90JXjQ4i5vcES0spieT6lT7G+MoxFHZ6dQg4dU8+Yd
z3ijxfbax9pvcOEBECFHrfgZbIal+6CXBn0StPltIXOcQx3E+r2v6ynJ7dkZI9bUaWpvUDMtAykc
VxGzEqcZ5LIwAtYtC/4kiLQ353NvlKuv7DFJVbhTyIUw+EH5XBVhh2BZdhcgvyIB1V2lhDpWbaYz
/63KntYnSD5x/UupO2nGt1lA6tTA/4YC65061v8E9ktjgLAH2VxKX8nwxW2F3R7Fgvi1WdZ0Vzk6
Ll/t2QSD1U6DJe8+87E1xpd9GuQooxEinQsCY/QK1n0ufTXAiu+MLvyKwgfm06c4qbM9MlX8mo1R
H69pNUm1/kvVtm8kPcTBMrEaXk1xVtoCWDHNbYchTCa/mdkbAyPXGzMAQxo77S6P3OguxtvlQqI9
jA+BUagY8oZ+CRFGse2Ag9pa5FwZX0vx8ego3xFuA6uavXGup9rkWiO0vbhfEovk7Uzae9yv6q2t
Q/w00L+rxaFOemPLjIb963iSLCVuL+8aOzqgL4Ovr1k67cO0k4z28CdjUzjfkX8VVVOEsViPt0jG
R422qcA/xHqn5VoneskSPPzR5Rtkgnrlt4hYd2ex4yvv7TcAZCKNl/sMHHgwCzwT7+2kH0aaV0==