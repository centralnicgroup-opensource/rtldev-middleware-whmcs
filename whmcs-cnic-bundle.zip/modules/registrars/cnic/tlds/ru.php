<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtsPK6cwIQbEGrJ5IfcxOxGACmtvJaqpiAAuIM2eCvZ/Ll8rH4oDUT7vKWLHog6QpDPHgubD
b9moQUnj7AWR/FQDypUMzLHYJfescb8JmPhBms3GmjI4oYZMQ5X4ypFCDSUnh8LxlO6JSV9r4zHC
bIiieym5KEX0pwqLB1B++FUOkDKrcszq4Yu7o+T1LEQkxPkYjxpoxtAsQDPT84t2W670uinKPh5r
Pm9SGejqc/wl6+dLxreV8Ml+4YEI1OzjEvTlEPx11iLtV7WoGwx5smpwtH9jBgqSyG4GGA4Zqy+7
kMS4uwgr40O7jqwfx6VWj1GuZPrpcuxy24Dd4tRpJcDHYVvjFslT3HE8U50eYo3bRRMh47wF/vGC
gMg+bRZ9pGTPmVt4yO8UGQCrQK9ENL4lKpyKoIgTC5LW89b+bs5NWsMk0R7WlvcsM7wm7bkiabIY
LWQfuthnYVnDwpkJ3dYYeYdaD+ippFDmjvAqM90GzN6SBkJ4m/JNUk/K2NNzTef6PS5fdMs5zkVD
sRy7dlF7pGTqanQpeNBRnlDDDaHwq4usVIhpzs7ISK/ckpCWkiFsPNxQa5x7Wa52AFOsNdWdXkh1
1ryBXELu6ushva0uXjmwolwxIVIKD60X1buhhDyMdXsR6sB/BBQebtjfvSDGGM8DFWUxKK1kp//s
l/PD2ulkqeA83A85E6hsGRKSyfb77ud+8HjbEAFzv/oOy5mx8vAkN1AOmvGaA1sE9iCWfQQASNkA
H+hgRaZLfLZaVTf9m2sO7n2Y6CPo0YiOkFX+lbdxDVcR3r21LWps1XT02YNIIDjdytTDyP1MJvOO
VZXbQ1Z3UgRv+U7JTXfeHsWp9Fi1oiqWaPxVjHNAgsjiJEA6yQNWqhvhI02AyVn7BxOQYoB9d3Lb
1ReIeMq1K8h5CCUCgQm86o6BtimAcVpTDqiHjQGPpJAXRkwuzIaMAYDC8ldw7TXSTJ/voFskL9pa
R1T1Mcd48d8ZT0KPKo9RV6broQby6D9O47yXdCRq6Qflw2Hn7/zNSCavvdf0YZUzdH06RsPB/vKO
p/XWntJsS8V2WOUS8ofGluSSwDh7tbPQwUr8/HeXWOsNvSXo7igaLSw+/epJEbA7bEXZ77Ki/3OK
ZyUcEwN9Ue62mL5yxQN1myvj8t5NXjKgvi4/LMUr0NhqpkW9fgWu0goM1ICM0hb/6y2d5vFuBr0n
jjGq9lO/s33KvLLu492WpO34U4FO0k/q+i8uG9LtuIp/A1fT29Nrpa6Eq6RtMKTUydpajku22lNK
WUfumKqp8lydtNmzD2MWDOQwHXrt5v5b8WztubzqRuvaO0AyMVmFFkjgBOIgNZfxR/cue9lcfMlM
RvHAjWq+6WPWZ0enf5TEk83DP11cLe9IZG7kGb0ur8fB22XtM8C7ybW0D6ab/0NxQuX1GEOIYM4h
67z54u7wPtnRX8ZSUiLIGTqTY5G+O/fbGZBafF8Mf1+d7XULSJZCGvIIXXnLiWt/tPl7lDFxZONi
/1gaDwVnekQ/AJNLVNFUlTMAvSU5PTr4ncTCU2IK2YU00tqQtwaqRXDkYCXO83sITrI6pDmqgbRs
yvnpPgyJ39u6M4JGo2nzAvYGUcWwi6OIVrNuVDUjQU2HQz5izrPSjzl3UQ/xl750PkWuOGW6atkO
1xfqRtkCOSvFdNSFe1RFIB2tjUz32MY8JdII+WQzwgcCzuVneH7FwRbCGpf27M5kXWGEdM70QkC9
WnbXAmgJIborcfTuK3eDFgR8TPxhDzgJ+LBMfgVigoDZn1rc2+qnzQF5i9bdhP+am6OjnJ/zCOcC
6WrD9G4p/W/2mMVn/GpeOuSpQEi1oQKzHWlUI4ycvU1h68uPQK3NkhpC0T8GC8ZDGc1hwbFaUCH1
wONF6ryePb0PMSf45lK91dTGMde4Gwj5TsJxMXosQ4tFaaOGibuQKGAsxwgEWFnQj2UwAz8I/47O
HsaivCy02opuJYRd0phEn9F4tcILIkIo8Xt6CjLg4fI28tuLHMNEASXDhVKf4ajtHgxdrJXDg20A
REy6YpXho5sPbpqqVzKvw2yugB4mhjjoL0jM3wD3gYig3Z2HljyndXyb8hYf8BedZKZdfvabNBex
jYhVwm5V3rGpqVbhFsRPiMuReZtlohoIED2PwLs4nrTspknbLci5thpmmCNxhw+4bce1WoKARL5O
NE97XN19oOr6gn5j9/oGIswi2t5MuVtbpKHasmUVozfnyi8xOSsmbroS+QzTpK7cHCKIgSgWU39s
ZyP9l9p6356MszphopQqTNHhxIbxyeSkvX8r4XJNSGaIQT4d50LQyk1zrH7mSLQwK23UPnMhjKAq
IBnsyNJhTsHsU5wWQenTA0xkxQpjo8+hbJAIL7bwVeXQ4V+hT1W2mRb1WAuHBJgX5mkeCxaZTze1
oJ1tZ8Vsagsry/EUe40FzY2FKNwVQ7+8j8p0Y0nmSjEjUmo90OizgLVxaBY9JikfLn5fCdhYoEli
L9FrpaatqXOQnYBuBpLcBVrFCyU4XCmsrSVtwXKG/xxdaFCHiT8+Kd4JijQHt/vK5iWHCRJE+ZT4
CAHXHM+/LetoIKlP92PLSnp7ruEAPHVSqu2tIv+BileT7ePtxl4EKNpdOtSjMnQJbe2FxG42cs7Q
AX0COobkNwdCQkSKZOpSh+GVEniLcl6re1cGj57ylgRwvKQUuUraSoAkDoJmt7bl+uO9rekZ1EeK
T+2zHp0W/o3fNADSERpiFNY2kSavKoPbcQ8DImCmbh7uthIVp1bZiUlUL+dh3ebIGJ4HuqzGDHhu
yJVlrjCow4PBGPGnfDB+vR1K4cuJWfdf2bbcXbUuINNs2CHfZTQ44KOpp3HMJMvL6n140L+OfQyf
KdWgIWMq5re54fQTUm/Wqg/h9rju5PNBNqWwL4t/m0fb4HKAnLMPLWl7tlluQ/56Qwg4RQXo1kjk
3d2sS4d8zdp/EwmkUkQ0xDq6k+Q/31mVvGHR0sPitdXuOZEMP6S9VUNr+0dPnXvCs44XbRb/1Oax
Sg0IpG+5MBbEiWFbTj0py/bgFGeoHoqqlmjFmfBWFb0cDM4JFNHXm2k1UCrgMFNtrYBxe2LnrAii
2LBk