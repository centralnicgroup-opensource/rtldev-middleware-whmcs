<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvX3yFVV0Cdufevbr9Hnmv7IZjHUhZNDOB+uv85nta1NtayZNflQVA0TOpQ5JOmvVtvN4YTg
QitWDOzF0cbiH00G/B7hgmM2cNNdmbI4/Dz7Pf3MAVgN5TGL1dV2msb2TlLe7Bx7GnVTUgEEiPj6
E40r3FfilNZ+ey4cqeMhOu7znLcYhCgdEHl2sZXZnMC5H/sStdAamGJyfYeRExTVa84Dplgxe2C9
Bspn4Qiq0Ua2Pamgr6IwscTH7/qtkHEKdwbZcBlKA6H8ahe357dMXSM94rHg72748d6IQh6v7quY
02WL2onKFxiivZ8QvA/hbG2905NoGivBQTfXc2a3wsyOxo05Ym0Ye4nwgH+qwhrjk0PAVVYSKJ+s
a1mGJBYYREHkgRLj+fkBlMgbCOqcjOWYyv0MqCxL2goovLk8RCDhGBaLbvdTmoAZx4v0vUqoA6yo
Ov60y+1Uc+bwpQ2yL5aRp9nt+lF7m1N07H+35uUnZOtaCgvZy4IcEdNMneZIAkWf9n6G8eCGeMTx
GyNUgXO0LpGC3X7L+VM6wSjrU1V6beFM8hEpTRigj+XUDWg23sm9KVrmNgz4hA+N7FbuYpF6Mnm/
DaT2iFel+erntOTTjkgGjGA63aUBKTbCQQY7m+TNJakODVar0/qWN9MFGby5MazNOhFBf7ZjaPKh
PBvzEqYAyBc88WpMXzu1xg9VHnRlx2zyi59+UJ2XFy7hbNN2q3uoJxcRbFpa8fUyMkcA14tmlx30
Sexw8QImIk+BChXMDFWSm91M2OuWBTPSwuA47bi1TXKVm5FJh1jrN+/1702WxSOXnCXfrpOdNOhX
JlIMSyrPZNcs+EaFpUyUkqFGT7Ekz0C/eOpa9BGVCTXaJmXqms0JgwOqPuraTylwEs3gyC89gV7+
HVZ6thBydWbwFo4mpIbCsW0K13WOWhroGwjeCOrzf4wqw9FxxJ2IOX97+fgW3YT6pJ6bw7LrO8co
DRCTKffSgqAN4+eq9IFZnbN/QDeDl2tyPGuLIO9cdmAelM6FsM4etgOPVAOUKBiUPNk2Twi/N0br
Lfqc3ugeCJq6dUTKzoUlcQAttvt+bBGiLaPVveJPLEcOCBMPcJvmyuspoSkmsGuoNtsOfM5QJl6v
WViCYgH2YNXVzfv3TOhpGwpZ8gRfUIYZV9xH0+hzM4rfDlLZL76c2S4XBO/orcBvM1kYmS2YxqMd
ofSoUiGCxnV3ayq1wZwAGqJgxkyTGmX4PeXuW2arEttprGA3kcQSHVstxV+CPoCFRGRU+0vPWDBN
7EGH6QwzV7G4ZmApTnNHKNrnsQv9c4AYalLRZmALaWOWkDgW3CJrZyKU6KSZ4VpJT++60KID/lHJ
32kOca+nR/+cAEYX95pfDE6KkMvjk3JAC98BzZBbeR6QNcBHEvPqOjW5fwXkwBAwvsRLGamXJ65H
AfpTL0+iNLYOiHwT8KDM/9c5+uPlJi06pEiNLQdMcyqHMuH0j+lFPTD72q8uCesCl2pMT9kVBdEE
v0/TbRQuxl8ctvWQraSg20dBnY4i9sdYWZxJxKY1kQkPkBmxWCBvsK26RqnU9BpSxA8vz8MB5xDK
MCukFcJjKFJ1C4mKR10znAl5EzEoD+PLBg7XjXaIhtdnPd1yRTiFOWc3ODBszwB41pVfsKh5YYEx
+ste8Yh/TsMCvBAGGRcHdpS2Fo8x2B6pFKvNgr6fcqeDzd3hlnp84rf32v0DQIo97Sjpnld3mSXA
oC7mz4QpRl8/g1dj8UHv6wbnJ3AuqeJv2CAeYyOUK+btUSiNH0I2hTGPSmnYHA3UsJfLx/HMxg23
9zV0jLlvEmS4TFSi+DMQ+2evJyQ/zI98R0tqtF+MS/DgqbWZpm+BBOmvsLZNskpjHWOYWWexCXU6
fwMZZTZuj1WvQLvYr+NjLluO7nAi7gW1hs2E8OLUizOvNDeDAJz7CcMT+1zGq9pd17I9yGne6F43
UTjJxBKGvcXE38AUbLqoY3gxfACn0kkLgWCk3lM7DTVhXzRtasPlbDzx36HzID9JoNWRlNXgTNc8
Cf2TOvHYgJBkWGxgqvYVvKTtzikhlhjhd2vcNbtWFcdq9tya2Z0jmaUPeLczLPaeUp0TVFxLVlTL
qZcCzmvroSK4lXU90DZPPqI12pWSItjL1xggxccMrSAe4GL9uZYNwTwF6dMrBfZXHmMjAsSO/eUL
AnkSkl5GBOopktkCnSdx0hHRSxFbKgJ2WmfzdK6BSs9o5Hl/Z7VAkp8vV4AFfXWl0L5ltPrIfiWP
ax0U+rMJsCuTLD5cIHq9a6ZVob2cB4emxAnCQeecTM9noJ2J9NhnE/IrgUmuwy6+2D7ofiC3Tu9/
uhQ+ZbUiuAv96HUypnejpn9Xa/C9oN8YrUrJd+s0LwT5SV/Ilq5oO0w6PNW0YwOC6OcttLLgrLn3
bBNfhM7HuLtqUy0O3MaW7Oe9tGZagNbyl1P0DlzsgJW/+uvSp2Ed2TFXHQzVnqbDq27uBxWjisae
MaLEPBFwqA87qeF0qYtFtgIwP3JDpz9hIIkr3Amc6zUFVYSLdQ501MLxQnfhdRg34S6crgHtqIJs
X9aYmJx/+mUFXvvrar8VGJzfG4yirxzqxb3ekAbWtOY/OK/0yHy/LYla4TxsrGD7Eoo4FLCz1mQW
z0RKcVmFh80FpgR02kI0DHc1NPszq6x1RcQKGnS4q+RynwvbbWTfrEsEHYyERiulIaNM2ybdZMDU
f66kpaDg/yCJcsr8YuRduDIQFjRUwVMx8DEEvwdd8E7W3yjR2flZjuS3jShub1wOPzCZZSSTd2lR
BAtgCg3PIeZF77ZdMvhzO+nSirinCBFdZKEdGcFesxAEemaVmRsmLiQrzR3e86B4ULFdOu+8aTya
eNJeQmkx0ylfwYOWoVYYcaexSY3IhFIJwkEacBiW48Vp5RmC+QitSOasvfmdSywXAHh/m5TgQShL
6BlsaK3nALDxa5eKRbZNBd9N7Dhm0S5EnPYUmlFznD0iSR99Gfp2D1lyi/YHsPJ01E4XTvW37zuq
3CoDwPP/UjEz/ni9qCe0gVmIsBfXyfFMkOUG0ziEP6igz2iJxzre/FqK+M5IqRuz2ziCLQJN0A+z
9rSd