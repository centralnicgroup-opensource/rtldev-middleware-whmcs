<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqrO6cnl2Vy5GtQLZq+RuDRNHvug8RzvTR+uxATtka3F+qgs1Pn5lO2wQ7e6tHQZqGSx+NxS
H1K383SPZNFgKT2NvXQgZF/oGNzvomxWx0ZgHMbHesJVlkxqqkzgmXeHKRLmbGTBIlH9GuK7tB2K
odjdJ/FErbra0GD0IVWEgCBNvCVIMieNPMosxG4c/xKctnokb7R8iuiHSy2+gW+nMmj+4rbNuiEp
+QYSK2GWaaNWJKqLxdiA9XGKtitvcS/2T29w6dpVV5iY+qGEdJ7xGhOwLHbfHRh3urN5VP8sUStH
rEXuJvvaVFCf2uAtRxmgTovfwJNFFiPKQru/1Rqh/u8CseD+pHMEBGikGgLIjokxJgA2XjLTUBwH
icbJcu8tqa515yhvRqrO0Tsxj97/zSk6zR2O04bhJ8k2HT0V6gK2YK8NucJdh8ncs3/NUdAyv7t6
sy93lBvevLBTBEp1TLpD7ImEemt2g6Snh0NzgX9RwJaZu+wvozjiS58XXrmWZQQQnivcE6oqqJX8
Mr12RQCGHINr6IC1HOA3qWXGRRc/PRQ9h7D31h5V/U+bzTHFcVcuoSE1rh0nBNIyxgPP6iE2dw/I
Cl89h6M64C77h1qq35iSbaK3Ze4nTSX61Yafewzcsys/V7aBiJsmf8SzzVMHiwKSBS81fTP43jim
DHbvwKeMnisd7n1p9zVFWZr5r5l2odwnn8cZtXmcoht4kbn9ZRupFWxs1s3V1+WABJ0KB3zQthiQ
vjNlRvUp7Y0zK0vD96Mb7k52W5iObdW4wvJ44Wityj7hJlqADZ0ZoATv2nxEQ0xTuUh7pP9zO88s
iMf4yVbyY6MZPhBFIRKWDAFWV+yQyWhzidxO1hOWzBC/G4FjVZ+zcrV7kWYTPXihT/YQRflyGc4x
Ebq18TVLRafNCrXrJ8aSoEOsWbMSofUfS0MzXajSpXLGRPklLIBt0zWCDa6/VHwlAHZGBrVrPiTv
ctvgK0ZrnuV6r78hYtMW7YHH35Z5lZuI0uwfnTr1MVGcIiWhgQfluhDmfOQi/r5FcQL5B2EUp3fL
VklqVjr3DxtVUfQTo7B6CTCvjOxo8OOitLxbGq2svmlDFM/AtN28szvza4fMcq9Wjk+wIivWdLRn
3wMc/k8QAYiYwkMzq88xLKXKG0uVfN1dbh7n09esBOIs5hUemHk5ZevEHoMY0HvpHJBp2uxsz0UQ
7vkSsSy6vqmHOz7wIdgvRTBHLi37dJ5QnVQbfw8Rdfqv/52Rrh78CsNuUPui8+ZbRBdlVhm5ptLN
tdRXNs+2Mi1ATRHMhj/dB7yYsWTOsJW2qsepivL6dqGTICjHGQl89vAfVI+0fECz+6m4HE25AGgV
xokHrOIl+t7I9ifV3eJuhIJwYoA9LHBKKL5lffspNcl/eqoa8c2a9V5ycY4XJ6D+90Ib8uvJyDCf
ocfYZzWCX9HMa/p169gpfLHZ6PwtyTlqNUF5sYW9zg7QsnFNTcEF470Cfcr2ciu4gp/tGe/lu/Ns
qW0c8ewi/F+SQw1kfY6TzgeJnXZoTtBD1Q2mB09MGWkqWpDt2ZcvK3YFA9felGSQwOO1dPQnBxCR
IPm8CJl1TX/3tSQrWOFmhIlGDYkVHL7+P2A/8PNfcEaSqI/WcKuhRGYKUPRWHoOhhbKG42G5cY3S
MIb4R6sXw1yY7ys6HJzvUATQT9sWuNuAjy45I5//0wVrwLCA6pAgfm4DU3kwrZ2yzrxEzPx4dLL0
tKBLtFyEXgBKAdhdZwRf5BegBrBKHF6b45y4uzMbtpfFMV4G2RO4Wu0IMgPtCROZBRIECkl0PDMh
OhMfVz0Ij/UGSbd3ZSEggfa1y4PbdE8kCt/HU5WFU2pGDwH8z/9zKm0GRfjtgeA+GPribC4f6HVn
X57nWyIhQUcJhD2ykj2PxlJjKYCvSP0gSoK/de/6SbEIutMhLjyA9hezrt/hNnMQZXwQgHNs/Tbm
cRc2nYL/DOsp8jzTFPrzpyjuDIF4qcxCewUQIKfnwmqItNlhgkwKzHrELT6NLsPpt9/ObNNcmITd
Ih0lLUoorWNrCSq1CHEVIUqfG2FTpe2RgNe4xdUaHoz3hWcUMlgv2gBXYtZk36bl2NZacEvzjYxp
mZgS3NSniXpojscaAIXx4wqP2/f7MBcEc61PkWCJpYMN1K2lRhBWOkcBMhk1Y3HvYtaQBj7ycVt+
YmA2r4QN+Wn35r4wdS0ZuqZhWjiYS4mUuZ/St6puFlZ7xE7PZDBjv2WvBag0NBpq0HtlN1PWYDEC
8DILETQFeeg724wm6YIDM0IgsnNBGEyYSb689zudUZggpQTUWnctjGEdGKk7CvN7kNaPlYvulqQR
g35QUNLIbCX4KrCJ9swvJq0+I+/J7HCMR4jJ4C1+AD99/+hIvvHk/Z1AGrww8nTDVYOZrDbNaj7s
b05mfybWKpAwhbYuDT8BHwhzH+eUqEa2u/CUgj3lCRsLGtjPrnmBQ5oCZaqN4rPsfe0ZaXzUelSl
e5ZpmbdBGgM0nVgxm4yoRGhndciGPTyDoj2cPUSwpA9iQlkKCdHjmE4KVnEFoQNwO+HiGzwyPMQk
fJUODzyM62isdsJ+f/vr8YQ32RwHLWPQHkuJTsjD5shijPanvNrD0kJYozqTbZ+PPlMiS1hOou2E
e1e3uPR7yXvT0ra1mqsbbRcyA7LVVF/ndnTTj5eLhNs1Ap05hMlzSNVMfTa2dZBkfhitrMmBxOfa
K1Im3XGXLbx/m75ucMRK65E49p0Cq+yGMLxWLPMHuhMrk/Z4moz3bA1TjsBnUArAq2ELqXXt4aTy
sH1SOvr3njthhxMcrUBvM36W5LP9kFpk0r6w6TL99QbsnYfANoWDpCKTZvGS1o8bW6wZqRKZiMz6
eyFnkNlgfF8154s0XUYdkFV9k/7ubYoRjPguGTYkZlN61TwkMq892aGFKMIzoA63P/hpgnVh0zMq
najglncM4mtmnJA9b6kJs3tscMlIqhYaPUue96Wd1mAUfN/YC76oDvUGhJ3RX0MmnGlO88neMvsz
1YKAM6q3V8FaiXtQv1X+bLDvPErZkfa9eS4wKw/c1EWKskmcFQrm7XD00T5xSqTPABKujGrxFJBr
LksViASLTf4=