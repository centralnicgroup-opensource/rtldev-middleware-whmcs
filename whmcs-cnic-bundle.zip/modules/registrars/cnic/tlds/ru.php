<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvF05T3MWUxdhms0y+O7GZz2pFn9Jj/gBDsRvoC+nGAXw9EkIvhKWOd3yLVyL20b0Q0ml3re
9OEw5WPuTtlbWZxZKZK8Cg5xnfN8eQ4zc9pUx0FFn7GjFvEINoCiIMH+8kQBb9BhFtJbFSmmqzCk
4r0VQXLdKSy4yTTlmM+7jMThTAMl8oUgJbGA8nv/kTta3i294BR+9zUexSpUVMUxAMp3TjxX5us/
i7QXzMqgr0osDTVi19kW71xT0U/0RdHcXZMM5i0ecS5h5/SQ9v2j2HIeQ9bNQTM38tQIyx1BMwVN
5iNeV1QY5I0lGXfs20L4zdkan9yuO7GG4gzfd7qYwCKl6ufj2PMuWF09DCV72qXf28PDgRCegRoo
GYMbLV/wCYMIRePzOVfiBBIHTkCGTZVAImafLmFqmCcUKUVxalIrbIeWy+HYWkPh5rsfl9l61fnm
tlLyRkZyzJhT1OO0/bFF+Cl2Ypl7pH2gGcQff0lDC4tp2XmgyANcl7y5tukuP3JcmjjAzbJW3tZ1
GLAnVi1O8IdxrwxOtjmsfA/4eOcvGPgv6XtZirSRDx8rfnGDIq8o9mD+yg4Xsstz21SI/qohp0PK
6jlmydpx7XBg+plTjCo4L53dclroEMPaYcwIkqGHM1nb7LupmiiOfKsFwkWDWqsn2m+DoWcUIc08
zjhJ5hzXJh0XS1BFcUmN8guollVTUfrjKkEl3Y1sizDoG/dCiI3AOCPpiSF6upJ7+YIpnqIRstZc
cjLDHxocd/iQwV19TK5JawcxDZvDNHWtBNSHqdvl2kXhUYUqvWL6H0i4n0wlsYmTHwpVpl8m0d/h
w1qq1uF7rB0m9ON07+z6UmVfeyE9W6jGLfP3hxaKoeu3XSzaZVj+sw3tqdDXfLDLKM+/Y1Kilamc
XsUxapWKEv6s07iI8tqsDT4ad5Uha03xb344RLVmikozopx+WMzA8H58GUEiSI0H5iPOvQlneR2v
P0V4usshPVX+4m5sOk0zPPZtPK0IsD5+GPnYH1cCL4FGT2WnZNceDSIpr4z5ouZvzOnPokYabt+5
3L9qjUX1bU3d+sWLv2042CjhhU1i55QUwD/dsSaCmkdRHXaI4Mg+UAo90pS/qF+as89ZGmeKgOkq
nNmPnDjKWdCpzX155bjaD8sFWLKEw9klGA0rSAboNzHjTFbL7VW/1zy4spFs1aqm6B9YU7Qb4rpZ
y5lVjbGBHiSz62zKdvBav9kF0qO916GcyAQbzYNBp36vEkUDt5czdmHQ/4c9KkfbGF/XS1mHCgFs
ElNpV2xUgMGHIe9fLXwyRgjD7ERSwtKBOEz4Uz5VA3bcZpyN0sAZtpTn0zjq/yH7A4/YebmgR4Yi
O1SEqKC0wr68RnvQdwjXdhAuhsjBYAt2UqBz5YZW5hvcphbyZ/iU+76HAgj63VoOCxW66p5JfNRp
KQltsW/icfWlSgeKMKsCdZ4jAxTBxuwhXhlmMPPtkyFFq1Eca48doZ0UW+irrQQ4G0d7ZQcKaz0N
o4ae3qmG/Cc3K/U8OyUV7DxqApHRzUhMgA4vKq8CXH7ieEM26sRrcr1n8qjuw1eUTJHePX89HPNz
KWHce4Mne6/wrifqueFzCmbuImf2Un/woj2nv4SWKnDH1LwNhLBrWLnS6MKZtvpHmCaMrQL2JXpu
wVxaDiZYgfE+nK+25KXcSIOiTH0sfQPQAVt6wcRP+YRLY5jBTH3zTYubqWp7Jl9UJ5rxONwJP0/O
zNdhXqM6Vs6up0bH4PsKOrV0yvEntOqQphwXD7hH5goj4FpkrMpNpouh59sCvtaivOG6U+E9K6Pv
4sAwK1UVQSmLCsDIc4m1T7wZdR7vyfIwKeHJUzdyElBrkhynZCdKO5TXu/RDmIlRWzSHbrPWXLeH
khaxeGkM21MuYF/CHO2OoV/TGgGNlnmR/eBZOzAC2mvql/slPewIsmBresqQ2zpsDrxkUZfBAxbz
LziA08e17zSWMVzi5/lTLdqxNQd73e7s3XctRyNoSxzvQhgqapkEEtB+2gVw/t5YuLc0PLVxu3Ve
DX6VDJMlsbxtGnVue0wC9jN5LHUB9abXNCuUgczqEWxYSoBZ+6szk/ElmvixDouv8Nh9P4qW7yIU
9sPXwm4iW2XYGztEmClZJGK6sqcgynXLn9E5BLkdWbQfpBr9xPZklMPnmOlZjyoaiykSPZcZGEhe
RQTLsbAx3/yj89ixGuQQJG9Wlb7/V7UwuSDpNzHHxrS5rCDOSTLkQU+Fup9gb63vVNf82XxxnjoA
20Om7w3VwXA1Pe2BaZf2x3IHAYQ2/avrrnclCj7OeMxTTYs5Uq/FzBl3/VzGxDbQ/imN6LuhDfR+
5jzg7w6qQIj5K5FX8gmr3L+BnSb/UeE4L0a3/u7PeID5cUyw4IhnD+C38ZO5plK6MNAH3ku1XQ1V
DnHJhB4Zpll0Nqtu7QX/9nnyTtGiCeiBy7F8VsuwmWwIL4mJIB34ftSQf+61jAFjmgzavv2h9ioo
3BsOQ8cs7u3p081DY/Unk2twCPvezXF5f0DPOJ8xILYbD68N7vgfT+sXO6TuODEXEBEU2GQRf9li
G6sp3CdDqnslGLQQYg3eOMeJcK0/VEkyZJ+IXHegvd8cDLkvCj0WXRHNV9P/f/sEpiq/EGvDqX/U
1Wfobn77bMY36SpX7SUns2oNHl3lor2XZ5/svvNRih3qr0BfDrZ7Lyo2eu3rvVt3Uu08oFIlSY89
vIcRJ4GnkMYoWbfU31/w4Qzkjmojvcn8x9wnFNy/OFnhA9EDNFLe66py2LPvEa3SNay4qYax5dmn
tdnXg/+luBfiRAyBLafI69CxuaaIx/RLqB88y2YAijet0DbL25MKX23Jt6y21ZFTXet6yuagudp9
cxFRXiDShp44kWKa3Yc7jQiuFdAyCN9npx5Yonf+0N9AEWd/qlKZe+ifdNiUQA1hItOaNiNdP79X
uGZAfUIBahRtCGV8ieWp1FF6r8roBaKd6ykbQbQX2DyMVPMTwHz05gDZzIfep0wFEvYXiHUnZ8Uf
+U/Ooie1BS02/q1p7V9wDfGkQq3BiYSqj3TBuqiY4ofJrNRUGmteiYz2d+7IxRDb0SRlWyqp0WxU
el0Jn/C=