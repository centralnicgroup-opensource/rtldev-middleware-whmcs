<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz80QLmFmL6KrityVqU/YP1jIgfjlEWj5VwlvRiTM+gSdq81AwYuM/nvi3HdJUYxMcyHJG5u
CIXdKRXI17TSb0l6J8zTwtghz0rCifwMJr0bXtZwAhce5Ex49mxHVgQ5UDC3CL6kDw9zrdCttWSx
8Num332Ly2DNLXyIIuPcZkZsrUCmshlyX2DOStlYvqw1xIz8G0JqwTuAhjAVGu0V9S7q20q/64FL
falDcuZO0IP8mfwhO7VTo5zI3+kkPUrL/09cl8ucrFo54Am8Sa3fqXm74PkAPUh/r9SnsQYA/Db9
CSb8PvT9loZ6FO2meRActXLXVSIecT8iBnw7v0zI09Al+P2IrP6OMYoO92+ZViPRmWDQg7WQIJfs
/Z4UD8/xloDVtT4dTfRtfYJnixB0e2/qiTyBjbbQ+Yswh5XSe0xlY/niaEJFbSqsTEGs1exoifaV
ffJCuX5t5iVh3xLSfO6Z2JJX7avyC1H4i6vlpw7B/4blm0/iutXTPRXOX/ft0eEkb/iCP80+vk2R
lR+uRb3d8p24bR8Wk9p+TjfWcUYk6mnDJa6oKBWnDYg5qJx+S352tNy3DjbW3Ii57DecR3brN7Jn
X/HqBsvwT9zLcCqrtvFL4Iy5i9r7d6xpmZWr6ovmTlGftUSTyqruVaJxoxjazIbDMHt5hxEV4Y1V
u+xhKy4VtBY4OmjTCEcuAxWh1sJWj6M7kGcbiWHiVKbk47PSjaB/FpfJRgCf9j/72yMdqxFSf/R3
1lARDZ55h/MKaHLz4z7FuH4nylQfDKgtfqbIk0r6rBjBV8gEufIeozxwIR3hOv/0IbWpsvW91832
+fCMQMnzmoqNJojcL4wUyrNROebnANz16xjAcx0BgBp8Cja9L/qzaKeCnaFPcVw67ftJQtQLJc1Q
ZAAcDrEGAgwsJrBkoqhoJ64kPvZiP2PBxSSLjF3nE1ZTHDaCvFZQMcZCXythMo6JLJq0NCIKi3Co
72Qqq6JxEbgZ86Ewmau8v8AOcNHQmGQEPXls7yyYLZl0zAf9zMROCmEFya9TmnMcgVbJWycNzRrj
6WHtBR4QrJjEN9HCl4VZHSXmDwFgc1qzzDaorLeKHd05IF+j7tpQCz7mziVm2G55gSemzqVSPjpY
v/GFqFRobo2RzHX/gIlXQN/WsAOCREoNL7fGekU78CU64GZ9We+kq6xyoS9r0QnjQDbL8zaMxlaT
ZBQrJiRawZB6UukBlHPmRqiXD3PjS3/ycX0NG3V+95PR9OpUAenFmIhOPSA/J5s9mZNJksjNw2kX
27VyrSAMdWx8xTkVFnELl1Q7nj/WXFoB/Lmq0+oiORMaB3JJS0Z1jGBktKDA7PfbJ79+SgFSc1B/
/cAfhTADLunyAAx2OWRjZnK0h1tiq51u7PoE9nI+4ne4mI5DeS4t8KYwRNwt+Xw3LVKmXXkLwFz2
8nu3I/ZGUqbxlvjgZBpjFyZ+nGGe7AL0/a2KBANbRhSeACEksFIf5rPtNgZfyZO8tkVEMON0PKdv
Oe3j3vnswKWfdjfUbyXO4njPZVjI1YMkx7IeFT81dVelP8bluvADqfZ3fnqCJSVGonUqrVFMhLk4
pobnNTNIFaS2cfyJpcN6cuOKWASdS7Qk4EAseMub9jUD0JRYqGm9TxLl7UNavqgHv1qku9WJLU60
Sxsa4vomEF3SSFwg9NpJB4oQtxv6/z2ho7PyX46e4nyvXNbbzWYkSYSUsjS3NqIRKOCq2yvfVJAK
ypwUDtaFjbj9x+WXNsNW4UsFnftU5NzLvwI4gERlOCH8gyAnh2QcyhE2jRKAwcROmxZ7/gBE8wW8
4U57FxcHtWEkj052rQHyKhzR3lZ1Oag/xAA+YFIpenUFEZiXFjgCqRuqQyB8hMplmeKbntf922XB
1IdV8FrbJoWhQvuucLMbepiVAt8ZyQ+UJyLH/ghnapFtfnsqwopid68SYkPKGH7gRho7AW62YLdv
v5jE1wgxABw3AXjo6+f51XvV1dVqLLropysmTFS6PLpvEl4znwIP3/J1NhwV1jrhXKB/wWeMQxLz
jDJMncKaOId7zwDDFrKxm5rN/3Om5uX5DktsNOV/5oTXYDHPJSvAR8kT9mQ64YwQ1kV9MzoAfUs2
y5YeGJa8aKF/Ll6DgXJLHlz18DMkpgluMw/uFmAknxAe4PurC6aCvvEiOyovYTM/oa2WfHbEXJQ3
ESBTTcqMdB9N46j77GBNzkr1vxFjzK8RniqkKGkjrxFaQS+xvvs6SQiZEpr95VUwIqL6QaOdi8ty
l03m67geDAkPiYI6dUb9j3bV641OCRBO30VPUXtqyLK5AG9CxTexf4H6aLEYqhuJdGPi8y/toHDD
WG1YkRK6IafAtw+CMRHQ/4iUB/rdHF+l2RGDn8ivf/U/XhuzRYeCpPr5ydR7iXCPrvIK9gn1zNyW
EJszCKA4/jQR8VmgtzEDUMm9BikK2oS9QaXf74SQChPHb7zHLw9k5D9KeWdDGyaS9Y2i9F1l07LT
76E2sC+3tU3eAMsprjYmyhr68r3JyFhvDpxMGhJB7tHD66QJHFccVfheW4zRV5SksGL736IiN0pL
MSakmf2QUWXWinqbS7FI2dejWzTnpX5YPD2SlfoSxZELdpKhghXEAloWeNOi6u1+ohVZQvGBCUYa
cas4pqtgb2QHdj5m2mPZnrmZI4v7W58TtLeYTharVadztZl5OuoGzUGgukOmDkMpsqHwgDak6BU7
8YExuT6SdvDtXl+B82XKOvRF5RB9u1RFBY9bGZvs7eup+W3kspTHH6lYwb0gYKIRBR12IZKi4eXy
95tCiqMMGYLb2GhAK0daxNglL/sJ20tzDDRjtN98wmEojiRBHG8JWj5uMjYiHbfDDv0u+cO0s3TS
z7cE55TCJf0T+0ZJRKbmcnPBlhfi+WQsjwp9jeHtm93hoqZFi02bWVhyGY3nKk/W39eaCZ/pW8Ax
JcNiiNnG1Cix3lu3C/4I+mIoBHxwaDd92HYb7ZyarrYqCi8kfRUpRUpFBjE2dVXo0WQTFLDQGzZi
kuMIo1qMqqFsuxkykBqvuPGJD5mbVETJvENpu4iJ+4l8A+ky8c/gUu/0SQMKNhr3TgWh7Csq