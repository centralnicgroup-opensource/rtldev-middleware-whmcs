<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyQbEJOxEe8vmcYi5SdlKdWkoA5jFuKGcjKRqVwXKR3XI6JPHoYYqGA2jBdgwGAuTXO9f5kP
hvm3z423sLLQT/oHtDI5OWjI1xA9s48OYb/V1RfB54jdU3FaMBAVIfYbLfOgdkJR1GAsnQpAAxHG
NYJRfsAfz79pHL+0fESL4ewzQOmcT61AeuCvmbyvQ24jwzruBvi/yYrd01NJHxNCs3XkerfQV7wB
u7OlAoP7w6Z2cetSBLSnFmQhvnOQLs/nFN/zM1wiyuZgqoK2UuO7P9oSIrhgPEIB4gMN2S3Us3hO
jyXeAl/7UPfz+i4EcW6Gk1216G6IE+/TJFSCpdM2hpHLuaNr0AArdoklOzPHJUbSJSZgT6JbVFLM
zA9uXSBsCa6nA52TkwnK1pXh4HrK/wh2DI2m7AUXC5g9wL1Y1vhnLC7Z7LrcF+PxyXZRG1RJ9rxQ
JzoTxUCn2zDx6EqWX9BQxCdYmQVeZ18tjxiIrnIErv1Tkb4LakVMu6h5iVX2ysddNE/mqNnnt5n4
JQJAkxmlQB44awI7Lrlnkfug4mHQfVXNysSdPz953+eoIRsSRVsyvbEY4tLvM7UB90pVED8EDSnx
Eye9qFXG9DGC/cnwWoSw8PMJEYjGz1WNjye96FUbl1SdHjvTmia/PhZDwXJJpyKltg8X7dfEtBjJ
bOmSAcCbQVkdbNBZoR2mIv+bEEHVK6sjHCcfSmKKsnwkZPE0hk7iFgBQNKskVJc7qq6uFQTg7qHJ
JcLSwCWp71bVa8DA+P21DYqRoIeXfG2i8FmvD7NAxeTVza2jlC5pI1iduAOFhZhBc7wTWqxCLhnw
lgkRaQUm1PVOxoo9Ke5A3VBNy9thcEWg/D3macd4xiEUx9kkm9hgiau/nohWmlD5Kdqn6QyalD+i
gYwXRaf7OrCIxkCGpEpv0hGoVdblcgTWdlmUT+WvAow1Hf8KZXemvnYfErx+dpgCwkPQLckJbtrB
HRCJBT6j+6YUbMrADazz6zvJtedzP8toArUDRXjaPLF5RQH6kBWihOPlRVnoX+tbUK0nnSsYfOr8
J9QAHt9QmELT02sC2pz89PbSBFNRW+6cPJ3xjaQ0vHlvsMO5+6mbtJ8AvqA7irgHP6WrNquWGQ4/
Rs+Bj66p3miIXupV3AjA5lCm8dkB34GUXIywu/8WCnFfuRyZh/fbtrlcpzrVXopMM6lD0BI8XKTW
w8MLsTb9sCQitcziS5zDDXvc3gu1QeeXKMdKT/Hdn8YTBe8INrpFw3Hcw9/jL6q35sI8XIZrQjcY
YDnQbHbzSRWmFtlnIHCNN+LAzfKJYYJxdW6aleb7BnK8bF9Yw79i7ISB3/ZpabLs8Qln9tw55WM2
DKDVh6xh1Gii8axpEdx6svUl4nUkl+wTuLWq6YoJl+sk2w3d2EAzVUypWEi+Nhd4Ty5roz5aCDQA
MZKd8lqlPdSv1AIF9C7dy+9DORtx0PZaJIFn6fCZfmVdf5GIdsEcNlC7SdjDvYQKA+qVBanEaDAM
I7qmz8quLbvoe+8JbyodohAcQMakCMAQfIm2MHSvazp+25bvI5oMu/6+rGP4qOoHG8Mxa+WEdprN
YwIdGFh+/rMk/a92zMFuVufly0oP2O+TLJFtcbNOWd2izVL42O8cDd26FazFbayQ7o2uq8UFnEsz
lpDr07gf7SiXtrL9+cEabwSbX2W2zgnw4SiuiBUrAn6H/QGL/VU9GDBscZy0Rm4GkbK4/4ilatef
lm0Er3TYJQMVL9pBCpinoU77qumeru0Z5UxYDNxilMAmRpZbTydH6ftMkZykYzame1HOwYfxN8EF
w/FqBBekPep9/S1SA4pLvpHJNIB8MjoNTaRyTsdBB/hPwyNa3n9ybNJ21e1PKNqwE/ZBxiSGYi2i
f++xMoUvWOjDLw+GYkyIdlsK++QiGsTaa71rv9FpeyIWj4Z67xyvcmiaPTpoxKWXSOb99ALnEtCf
BOZtYeZNyhNgyIVHhXJDJYx8d9v61xFtHKFAO3QG7sYsqLaBQxDhaafPk8NK4zDSwQfU0BTDFR9w
oHJ/fD6t1B0WhreOYiooSGoBfypQcsXFdp4eZb10pD5WUKO/riu7PB+QcLuJ8H/gWWjHKgI+ekK0
WVqJu2ZmubQ+sBcOtUkqLR91YLW4umVeMqWkTj9XOjebx1ETUzdPbCEiIdeqnJAal793PsaafE1l
JWUaO1jeGr92mBvkgRU9+43B6a0RDLU2ahk5hcbZJ5p2WL8AoZAmb+m99lQTrE4nE+A55XrtPIaZ
ghZzVMTD8q/IXaKeRKTtTHBVH6OWChJPUJXjT7KBqQB+ArrLbSI2uOlJE3LHgu04gNduRYAf8L6S
r4+L+FiZcYrUTR3Phr8wJXEt8BzIHyY41AWwLs/3R/zmOWI3VwESqV4ZoI0FaL00hOnaG9yklJdQ
IOZrzBNPuSammzm6+h+7ZIrLzLTG98/8l0Mv+bDJh5XbYpkJ9YVeZ10uc9bfCXnQVJzBBPD9utW8
WsqfQmdjQKigROrEhVESqYE3opQUpxwLEVpPCVfu8sguR0sT8rPMW0iAyIEVU+sfOUWEkKU55tob
AWJFTAf4YuazpzaqBLpt/Pd8q7/YXY0ApOwYaohGmT4YhMXNdvy+wyNHPI1AqMnJtszh6VSEtCmR
LNGSbd3sAcBo8pa8/rwjKkfAlrwjIlXgI7Qa19nRHhScaiXiT+XKa0i+phjL3/GY3J3rwzLRIPQ7
R8Si/wEDAtJ1Z306v/QL9sQWWZ9eTYmzBeahv4evN8sWzHbd9KHt2zthcOcn2y9TpqNBA8DR3ez1
DknF3tINI7QO5pCgEpb2LrobfkFY2HLVlzt/qA4EGiYr9VyBTVCgAXudVqpR3hyOD9Z5yDLU+egU
qj/5rjhZvPHEHWLwe2ffdv/hpSe2UyO+sRYCsDlau5nJEhFzbZMijnYXDZ9HDaiYDqcIXUR4sxb0
qNJQKDb5RITmuQTNY2SKirIciPk4o8C72wC3Yt8Lg92RYniiUplQLloa1Rb2XahEvGT6Mf6Y0BGR
Vobc7RQ1kKq89FoL3b5myo8mrDdhmLM08KoIjIch1HGGV96w8eiF2TtVHi6n2iSqKAF13+UM