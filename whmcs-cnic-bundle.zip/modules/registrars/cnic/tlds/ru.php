<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrZw6+2EQk3NLpUEmo54qteobcEdOu2QtFedP1dXNfMP9dmuYINDIMx7ymF4KktnjyPg2vJU
FW6e3uQVJZYqOt0mqIV5WupPpq5KkUoOuHGsaadtaPCZDf/s8l3cRxeXVVXNNF0Kt5qcvcEfQFYd
kXEI47yrCU1izERqmCf8sGBzQVQBhSqDrm1uatApXHUsZrKkSO7OiBKkZmBEHEkNiAyCOFsZlBDp
Zqq1RCBfW/56pr95qxsxXJWcXmLrtezT5pEQ5FL8ZL0P798EfnubVj6ae0vK/ckzwEha3ba20DLf
TR79Y27/69C/qaQumibQ7/mzWmNbyxFaPoQheUwLMqeNeinemrH+yCtHhSvmZ61jCrD/EQbrY6up
gnPBc5+kzXTCMZL+/xf1cHDwBdLraidFoLZC+lyXk7reyCuHQ5vJS/dB5LMJY960V9pDUAf6LOPO
qvpn+vYAAzfO0Ov7RoXLULAct6nK3PKlWqlS3WTSwHcwmAshDmjOP194RAjZJVlUUfbctKoVHK+d
o9y5pda5JvssGmltn0PmpxvfKmy2nCi7+4u6nWKNBBtKZMNo7RmseP553ZfJisB9z42OrdDhtbS5
WewA+TiWXVKgAocnXrNkYPJwrXXaPN6JWzIvnVyv/8JOC//d7tInPEXTruvNNG37HaVj1oe+H1F3
qOYiVRPtimHKUYTWBzXv2Hk2yvsqgM4vLKVZDay6u5lPzUjhZ2OI7jiadRAYYGGozY9KwdNypxJZ
u/brKWGHAWlRADVMQRBscCk41h0/u8gRscpX5xyx5Q/0uG2q8TJeyCCuLyymOqVTGyJuEQNK02cK
N0lFipamhmvYdRaftm7N74oTf7x6pf5h7MAtyx2sbKfDzDJs4QO8/kz73QWJVAOV1kVVraYTrMH4
jJOE7edbs9QMDFsu5YzNwclb6lCWzEJwLRpR2XdJKhb9KSY3cg/c3rV5ZCTKPj2gCA8qyynlV6O0
N2H19GCGBSfb/X07AN+MEeLKuJgquIJxR8LZaFEUc9kMv0m+LsO0nNMIfT4VqNyuSYUh092GQ4k1
+jXZjCIZoEQdoFj0gAjKk8qQaHXLBVuJ+qO3rOpv9Z1Y78pqaQHv4XzlDr77RLiWEC2xGZev9cfH
MTZxaspafS/DVESMIeMZkyU8WmI5HX9ROUeNX2xSb/rAwdtageCV8HlrmnDgsFEQT5tWU/IXz8C+
8QR69t54EmGUilujBI1t+Y4SQ3QyExgEfaUaWvPKXnGJR39LHBPlrcues4lxHutkBcWv1ikM+Ypr
IyehpyTMwoRglVHjGbhJCIZ9WNONUPCTUn/V2E/pbd9pTD1l41JjkJ7/FvUSOiFfs7eiTBrXTyvC
0QYj3j1x3YA/ch7IFkIRzK2JL991wc0U1taJfCH9HmJiQxHFUYzNjkXZQo29KVO4jKQknUnnDVOX
kFdewkVoFxhrzR2S7Z6XlU7qtTcZrPfVjnHOAeY6lDPevfyWfc2FW+NhD7fW5bbFTUKLV2ZwfTvi
A5/pkv3U8gVFVWhrcJIOvjzjV0Z2AHpetFshefJ1v87jBuL44+4sDlHGG0iXoE7sNjsIT079/euq
ghShxbJci3asVPujRb//pHd/q2MZs/NYxmIQMdDIGgDcpIh7D8aFee9mXNfI8Jj3LdpG0OCNZCFh
qx45ZOfbyPi/TWGz7pzAOnHLE72dgs+HPrrfu+WIWz4JBJccpScACRIXsix3ou1jfx8szMzlIBoq
2DAL4EKRPaQebp60MB01JvzVYPgV2tLlmXi3VDSiblDuoDV8AMSh8dIk24h4X2owHqI84zYBcWfr
D8KY+TOLS/+2C+53xmU57xYja6YxSSTK7c7z6rqxdBTs5R6/cbRYs0/KzNZHyPMziz7wd2OE/AGo
BDy/Uc4Z9+ZSD6E0XyR3FItec+v4bJ0CJorgdvyZGv6WNB+D9NXckkMNMSlCKLt9A138w1Pukwsi
KZ+Pr6HUxvYYOuZEePeUqyENgqpKJtzCkPUb7D4JXNuh6oGAv7DL/OAU0x6op8fcDH9yZt0CjWTF
5UIAu3+zOlUH4KBIYXzc+usaOsS849dOJ6wwztZEcyogC9DjzhozlOyDEsosXeGxoVlAoKILHRhq
cB0b8mipq7Mhsi6YQ1X4ZBDMHadrOKdXtA7ejrWwRjbtU8hqbSHs1UAjrMi0/PLD8dQgzWxahG5R
vZaGFjdZ1HpfQP+rpt/QIRQu8t5KVDfWR8jHBHJaEOlelJEEO+HENC9t3/jwZHH2eeONCTfdBIw8
+htr3lwMA0CMiRV0EaSHcB6BHspojZKxNWtmUQEx894zwp2r6gjPciJehR+7jwlvFtx7i+FezrC2
gNM6X60XKfFYi49Z4tUs0dYopLSRYWlr8bC8YvMQEhlHj/RTg40xI8+xZlDFcbzx4KysY/HLfutB
AZNxcJCUTLHwXsfj526Ln8zkbEP7TZBobsXpPPaV6ZQM6SkuypHbOQjen2mbdOLFXKQNAx3nRehm
+HFknt1QgVS+h/UszsrlnMofXLbss+SUmQx2YCjU99SLaTV6LQmwwFkYJIHWW/1K5NldumpLbMTg
98/P+cAbCJgO8tV4IbYft0f996NF4hbNxM61kaF+R+Fgf1Crr4fmgLLCXYHsYdl1DwPKArBu2KP6
E1NhPRV+9Yn3r8y6jTelR9yt5WS8vLmPs50rwxw2KjcUIGT3ei0Veb6BeMq9P/RQEBMf36QkI23j
Vk/t0Jqw0ERfAnU6VPGUylk4oKpYYcaoVy0mjHCXEuZk8Hm+/4FvWye+M4K2lqk9krFiAxGmzAF7
9BZKazJGWJ5RSK9fjMTjZsxWO25W6zl4WB5fus3qQrMtueIOhuvKgJeDPiCC+2GgN6EZ0mAlA6a3
SvA4gPsw+K3oOO50tXYUV/qTaoqsWUAzqPJ2VUnEECL/437mIKUeFlKlY3ARBu9CiHUAahIx0qLF
m9/KSyL1mqcUcvnCJmWcBoZ7cnFRNP7bRFvdqQVkh+4MD4wyx+wtDhsf2HhZKUO1rxBreU2oCObu
9fNHEQkaAwBRbDYC1I1L0erK6YVNBliXSjIjx5rxJouMG3X43XZ5ZuiOD8LzKblJhwnphY4TwWe=