<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnNSZGvAZNOX4n4OBPtrjEAmhhRKxM1Sg+yUTazTWyx0FsSe/GiM1Y3k/qOJ2dSNG6wijp76
qj6mnHJefUPYWbQz5aUzC5hOQCXlfQBnex+4TtgQw+GUXSdPgnAQT+UsyGLQ1JxmrwN5IozPnrPR
q9J2NaP5vg64xpAOwyYwp36xShtWFMwnXvJ8hMwXgmjO9AXlCaXrJIZC6R9SZlFVH0w/vOLs986Z
kOrA+JqGpVVwkxIurarGWN2ooDe/GSva2YkWqyyhtnObZHyFXhfzYi4St+VyjMurAH1N9Pbiwt0m
JMUOQ6a/j/5GnDPSogN7jfuK9/pfWgNk4ZRBS5kfCrm9utwn2J+uytTyX1YdkNcqtrdStzLboEwG
L1Sgl97nZkcc4+OqYNbVlufsFd6fdufcogQvChvgcKEDCkGhksmGykWK2+CKc02AIPa0FQV9cbnJ
t9r0mhbgq8+d5pudlrZ5sRLRT29v/wSHikT5jHYbRr90d7wa9VEjSxLU9dDi9yYoSqQQct+S12p9
KY8r1rnNJshk6MV9IIjTGaX6r6EnpmNz6rRLW8rKk2xjojVADZ9i9+Qw1Q03e76ex3IGTxxUHG7U
nMj98Rfx2TAg25dohXDA2C1kfALyKR+yHIbV2zQyiEGWRVqxUArpgGT/X/kN3aImzhEqzCAjd3cY
+0aIbifZfI3JTaRlsj+JNK2VIPCLTbEAlVX7r29+c8fGhB3Z1AqTd7xordvCsiyGqQMKAe92Hbif
wwvtM9tcW3BImtIRHjRWCOf/5hA7YWIG9t1dN8YMMrR4D+TGHFt+W4fpQ6A+I6/VkJv+PwXHtN/T
elWmmcHaMAnqW0DACaxNVdtn6DAyEKZLwS4V7I7MHfI1oLWV+Bz8RvXUBL5e/wrx+Ybc0qRBHCXy
BRlrDjPfrGz2/AmPZy4k2FxAZ5ndp0b10Nz/UvF2YqBvOFeM58l/MBCNPNP1dX/XB4BWJtYVMSnP
s5BWol8jPSdLOqaUIHgjvgPCVl4znESnzYzNx/JdNmNe6mwlOxiGh9gUFYUyVnNt+f9W+uah6mKt
rwDK3dq5BdQs+KTqSL07pG8gZrv0qoMJDIGo8hYU6I5MFKDliFpPoUbNvY446fm7BkHXY3hIhqGD
EQ8J68Z7R3GkHS3bDq9JOt6VwOq0943DXOymhL7Jw8pM965w9TsNzwFEvzAsW1upKcKgdniIhvnI
IOj+9ms180XU6L7uH6MFililB1r+ibqwdLsU0GLLfmaSQijeWmcZ3vFaP0YW32UZdSJTyqmuWI5p
HicqXyZ9STYaHj+VmIoexdnn7qpxoXxYUkFUx35crdCMc2MJVni/GTqp4gr3zrLLXYscyTVvMLdt
46l9BHA6VpecLmdAE1tTZiZmROoHgk5SpNPqqSb9vVcik+tw4i2Zxx6WKeZQu55JpMLa414rWKEM
xDMh8B2kpj76ugZep1fGZx96vfKNCwb0ESrRFJQm95WDJLCqfZSY5PWL0GUmaP3Fsu09tWV1Wvwt
Jh/guDpl0zOMZ6SIV5HGslWxI7L1jxbcOZO0Fax1k8uqxUSGp0ip9Oqw1hXMU5re6JadC3LVirsS
RUC8vW2Iu07dCsLTwsQtgR5rK+eSuii+eAEcLhs0aqSFGORrBtH8yYBEzMhuuY+HAVWULOC94SHh
AIS70WlPs3t3ViOKuE/R0bCoOzLMBVzfjB3YK9bhTFmxn41HdHrO86ZSf00ugG3/Cl3c0wt+fde/
kxqELPEixnZlJFJMsSXEnopVbzRdInBzQpLdxuE2mYFeezlFLt+gBdDlXkrkoMqRkZ8uJLnjeQ29
B1SDFy/6GJ5ZTszOn47ev4aHQUp939PzD3eh2BGdsIscessHGry0zfdbzBQPJ2KAZuBS970pCv+k
1qQhpk0NmPyfKSr+/6NFML2txxJyzbIvxnBkt5AhDXpDElUsyAFbAVBBJvfHVzPmJVnYvNjy6dus
WgaC5qmhpS/u2eFC2Y+jD4gICAtzRbPb8D4xja02NPb89raXO+JfSHfmPRJONH7JbLva//0OOKAo
yA3Qp3JL8uOWlQUsI0aj7ROn6ZKA7Wv9g6bor/ArXfSKktZaWr5r62+bZKYSETHaPSM726lfc1DL
S59b+lXmJRaVjwBtIae732ai1HtGInC0RajZ3FwXtufDg3RqBjk0uMxPvOF2Rk7yKVuDQv/Hu0QH
npuQBUi1vM+ASk9V1QaFWsYMwJWMYmQkdYUOk8GbD3BACa7AyOfOrnKWJfIbko84UO6IxTLsMihr
E1ZON8TvzVr1p5bqu2g6q74zfFH7YT6+d+NyubsEJtxEXO4gD+4sIq0pvxyf2nUnn89aHYJHjXkj
Ct2WaJK9n8yrMlGMERzJF+80+MZjrLt+pBRp5+HT4duDKrcM3i1D6Auns/C78VSc9+JMkETucrzF
W/dH+Z7NPHHXUfJT3ULKHiMDNunrKyz6HEaFNzg/vw72KYdvzfTNY0ocMOXPBVXlV79ex2VPsaNy
GNzwfFjU6Q+PHp0YLsLhSLIBDy9eiBde/C5p3jYKk5OOdeI5/rLBzguhlqgrgHliLU8xabw4Dh7R
CA9yC9+KcFEn76Vb66UW/GCDZ0RcFu55WE6iUgf8dyYQLDonhWsY2crpcsi5cr+PPhWr1+sfht4F
lfRLD0XhwElQV0yi37qiOztgmqIMFZDiKHyB7k+S7eRDwsUjrmhpuMnwDxleEYa+7MwT+tKeQnlu
W2RDy/QWI/82tkZfZ24zfJFSMseTpFg6cRx9floS3xgpJx0zu9KtQ8gyIzivg5Y+3/7QRe3yi7bD
OkdBDjCZk5iKtxFdzAy4kYvc7ZMpBXWaiMNSAG4KlSeOarkHcNpAKIFEscqwaBDH0o6h+6mTeiQN
ePCbNmOPqHgNLtDPOTusKgxhoKIqMoTbNPf28FaYA69VbEa0C0PEJB/ZoW0JEvAAYSDnbMBZjdXL
2bx8loZ6jJQ82IXBcPGBZ+qpDLnnyJ9PdB0UMu3Ff4zaL8csS2QsIbJQctH/46K8OUjVkMqIekWl
J/v/SfcwZkOsPRreXZwcGjtmf9S/f2519xY3PZKLFW/GHTzwrY0itzPtjZSvbMcqJWUWaG==