<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnD4ScpQhaP4e/JdJvrKtQ6FIXqXl2FjTTmQT3B0gwcDT88LsCopLCdVQ6PCmmiiYXMeN1k+
dJ6vePpo2Lg4RiQoqWWcG9M0UObKOE15DwZHVZ8SABBDkYfO0ltht0+en9spt6NnSwtohI1E/qUv
M65Ji6yuIGJpSMwLw9c0Vqy74oFu/S5d9Q6AUOEmuyLxgVaJ5Rux6yo+I/iLFg0L08FZzTXdk/tV
HpCuYbjWWN3usZvy+OU7kP+u60XosbN1LwlvzZcUmGR5TtnuCaEknTiC+jtGRAuK77ClsDTfmC3F
XmQ6VhusCl2KxSfA2XwyvNP46/iF3wd0x6GHwIRxv9gj5/gQvQXock+Z4jQgnStYlaFBmf9dTA/F
g8d5tpO8Ye0n05hyDI0cLQcZMG6siWWJldKjYaiMm+VE7CJ4H216k8uklq1q6AdHhuU3OqnfZ2dO
a7wD5yFBwQKep7QR7y+t1Wh/RnG8l4GRduJ9VI3SVUkV4KYcJXGGdzINJUfohkT8Z0/NRBznviR9
3sqS/NNV59L5Auj3/aHS4EcXynUrZgmVdWSuG0TDhNNnWg89uAWZpv+6hOFHWEZ43m0rpSyo9jiY
tF5RNvJBgU57kyTLT5gvqtqrcRkAXk60NtU+W9NuYjFTQje3ExN3rhnSmEYw+48Nzvh4dj9/uI9i
eJa8JrfjL/mVagEC7lcww09Uj41QfXmMkh/yjAHqf9uNMoZ4s4l9WtzRB5Gf86CNmQ5ua26bICA1
NvsmvQ1T/VG4AS/2+LqmIMOah7ixOpZV8av0c/sDcsSNbcRdxyQ8Ji5nIs7H1EK85nhCuBRHZoa2
qn7XVhaHg9axcFQuyABi7H9NJuz6tv7HOJDowklex5SkZt+1C89FkZ+GsxaNJUnQwoINDcsU+jsH
oSMUdVXTccJf8c9xU3A9E4qUjspYvW1+7Ub+YnsaSN9NIfsK4w4NlwXskMP1r/Jw5tMe/TtGZr4H
P+FpvHU8hwD2gbWDXHIv9t+VyTl5aB0nQ5Wloc7F40awIc1u+8154Pv35vOG0SEPtqC+3N48Ffrl
Vlip5258z+t7LuF+FJudrfpYrTqokM27aRK2PE0if9dStJuxBKW70acYyZWXbYxhT7Nr5S5sGuz9
BjmzNWp4MpvD8UoHMPwEiYmcg6F/mX/lNf1SBrXNeRSIAV74QAiih7Svydjkno5ycufCzHO/IZgk
Z7kHjKJPCvx9Kz5pb4W7zyObpk6w+romc/WBlJUi4MTpoG==