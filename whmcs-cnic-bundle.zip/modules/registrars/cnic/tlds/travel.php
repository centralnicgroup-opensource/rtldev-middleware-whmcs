<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx51toDwhICK0/5A06DdTyKYRBSGHvYK5VsNgp/oxmAI9qGo2TexUAAqppsgJVXhpn6fJe0d
khj7TQtBcEBXmkwwiqGCS7qU3QJ5BBEk0h+jliNqfFl22o+EW5pnyC04GNqlSVzMGZknf0DNP1wk
tw/nsIchCKY6sZJLIMvmHy9hM4quiO02COem6PZfuEDfTf2+JoG0GkkylUtsUcSnj8/YuyrTYtFo
Q98wNPe48nYUuxSWnWsC7Z4sx/WO907etcRglXwiyuZgqoK2UuO7P9oSIrflQEJsoQW++5NeC7FO
Tr46QOg1SwzMylpcGqvVmWqn/o4agWvEX5K7TEsuDL2IdbMtIk0lEMnvotuzOezeOtGuBNAKlt/d
/Rh38jxw6YPbAHDznvlvYLDGnMbnSzyCX4L1v8VC0XnHEM6GhAjMyzHQF+L8zNU299WoAYjOqvvE
BFT6YM62iDfTGFLg8HBzyvXFZ3ChKdN/N7GO4/o9i0XqjPf8a/RbLKbT8GUlWpqbTWVeTZ7l/SnP
x4gIjPbQw2u5k1AE5l+8T+sm9aKJLp1JikFhQGJ9o+RjYIxUjLHHSbbBbUmr7SVzrxaSEjOqGUy/
JWXvGRpHQyO6pKb56hp1yYdjPgroIZ1t/+0+e18GKDZKDwPszvWQmF+chL1NzYjAlRCB/BOq60Jd
/HyGQACdnPx4eq9+ZmWXuIWntDljY6UWKKBUPWUfY5vhEl60+NS5o9v8AOLxq2biy5JaNdAJ36Sd
p29ynPl7zE8x+FNqAHh3x7JZCyU5iGX+Go2mlhBNT2+TLe6rhPfndBR5UR9yKnEgDL0FLSAtn2yh
onHUvmmUFlXIBvnMruhJ4Hcfw0Og967hB1tsKWJjDXyj2Q5NMaprayz+XbtaO1/RI3VY6iF4JLyW
OozS99f8uM0uJ+KDA4jPvxmBk6VRXYA+6/hFzV3gVe+HE6BHz5OfWPX+OYGPOUZ4GFFHCOwFczMM
GXm74IdInfu5sKSv3vlJG4GslPGX+hXwKdJoYrMSVr0n6407jbQtEQ2o/1pwmrQZxPl9BK6bjWPK
+9Rzwj346U4T0V6PXtP9VLV5lJ2OEyWAaYf71iL5fQWGzkfPJRxtsquz8LstRUX66T+jNNMTRCJM
lb5Q5W6yOs+awGfPAzehxRsxT10FrhifzijkGo5mMT4gcT0W1oY4o1j9tRJLJfve+8otYlOFgcPv
6O0NgneK3xnNOMZRTXB19QtJKxUO5ZQNWxmPeWrQj8a=