<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuxFTh8Z4qk6Ed/ZaT5J5CU/gU556ywurgkumrMJuLRXGrUEROeeYb3Q7OtUX8Q9QG5oAHsU
YoicYRRopfDvWF9h2xEK7edi22EyMq3A/RABXp68CNoqPCObEviG0ygMrRMwEqv4mF5QG0KkWdAk
pyKfsqEqRWu3za/tLDEdGfdOb+rp1uRrKvgvdEVa5k6sr8vvMVKFE53FdIB537Nv/49CeEVz6phu
FT27xw5yKmByGqFIsO8GchjPdJHvCbZEp94FSjssbBeja4egBIOQXBJ+E1XhkpIPo7B+01Joe4Bj
gGLI//3Qn6CP6C42fzsWzaxpBgggQrp/Ah1/nq6O81vDWT4GejnktYzhrD3XLnBBdoxUM/x6yuH3
0xIGjB52yveoyo2FoQDzrVk9LAy0S3cdvtKb3XLh9ON8scXOGyHBk0CMYm2kse5pZL1Wtye4qyxK
ZgIQIqU4uLrm+8m9DZ2SodIgrc/BLiauBxrDi1CuMFrLDBV4Z/ekMxXlX3aEaXtSURU36r+Z9c3G
kbP6I3rg+dGajdKe48OJh2szaFuk08cD4v2cG0bt5NQe4h7jg6a310e25/QVelVfjhNm0hncHLhI
f2r7rybRZKVAxtt32uuZi7XoqAQEyS3ne9zodiLJj7wyk1g3g/GsBsfioUh78ZHf62ZWS1xVKDNB
Kr21b6zzkxKphbxQcSMaH/HZ+lRzH4y3Ek19I9tVSLVKUaOcZQcmelaYuMmUV6YQ/6pU19dZXdNt
Cn9DTyy6Kfip+AXFSsdkp+4W9nb8NsMxrox/YUoGONehERGOlvIce8K0p3LkLkdyUJzP5qWRd7kl
V4066TUV/0I/57UzilKUhHjbNOIErlxzktklnLSUIZ+edk072BGnfk/bbt0csF+/pCIUrmD2mut2
5vNC1RZYCRHu87IuE1yo7SeS5jT2dwq/tgpQ1/WEcHfqdCVOy+jZ0jA/XS3swOwasob0WmfoN4cZ
Yq5Nq9eA7hpd44NMiNO83eI7KvF73fXjXF/ozb4KI1TBV2+JLO4bVlDenUdEnbD2lxdCJjLv3HrV
btHY7Eg0KutMjJ+o17NqD/dshA1znZHPmynyoCOCvdmzLKHLIkxA1yBUxBrOWF0N4qZAGb9+KAqV
/nHezuB3CjXOug5TE+IJ6BMQsU6q7xc9prXZO8gz27eFtsNB1PxhhLFUeymoKH2K8zvfFJUMyCHw
Wa+NnWw9vFsPJHPpO7sA2mz5Zslf5/PFtBNePvsi