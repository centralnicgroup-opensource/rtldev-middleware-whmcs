<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpAKXMh8VdvDbIGGIPQJJDjeYK+I/mwVqxku2p8W8DtQ6OCEf2bKdtIJi43nKkL1As3V2rPK
DpigICpD+M9NWzYTS5dzKrdyo+QxlNqX1UuhBVhRSMiH/G7uTAEg//4QOd+Gkl1crfg9RbpuHRE5
drAcQu/trT+K4bqqqjAvsyzI5dOVGs/fiUntxkVqheFyGMv9K33Zlvu7VD8CbiCX3tSmxxx7ooFJ
f+ktIS9ilR1P4qcYBeNfXp18P4T/ak1jbKXHzJ+PedukJPKmH71Gvf9HSrfiB2mxj0daL4EPRJhz
YaKF9fI/lm6yzh5Ai3JIleOvBSC+VVQEBQrBfWCE0gnNSQ+pOrB/GaxHZymf83yjEmUDkM6s0bDc
9Iy/Y7WTtKd4BfDfVru4wdtp2QI1YP4aKfJ8ba+6PvBKOPr34sMtHtllhBnPo3CIc8Q2H3+OWbyn
R2J8fJB93XyzeiQc9h7TaH5DHDxi32i41nak+wLGPQYXzWxfWs5kzpjZZ4+oogw9Vm+43oKWZ5bw
ahfcH7QnuQPam8WO/Tg04zvi5fPTL4oHOrnHnRM5hmCOPBs0OnCxqLFIGie2GZKuzauhDvQ2kRzy
WzbnAjGvicCmI/c/yX6ckrEEdns07XNlxaqFFV4ssz+7IuW2kGoM3p7E9D03iGRLmJ/cRMRWnwYJ
K3BbJMax2+yRwSL0vyw+7RDc/lgLTLlHYamfzQ2oE+Nu/xkaX+bW8mPH94v4afsvgMzzf8POJv9R
WIvvOG6KDrxCgC1CNQJa0UkM9ChHwDs2I2TY9LiV2mydHiEenmnM8cKtb6miMUbnxTvFxwmIaXos
E9rtzUXXVaFhlPQ3/K1h6jQs2llIM0oBYqx0ePnAXEPiYYf9XqEsSX6lQxifh/lI14QpbUol6/Pb
EbwiTrl+kxCNnQl1M/CgY8iTU2/c/WOxbH0QjFXbcasuXk8VAUil0yx8+2U/ENK+pQV01QyRUSAI
SlTaTxx+ROI8Lt09D4WwLXVaxigLDBn6/fsMf+nKEqaWDQBmg9OMAgSAxIcu2MXnIUib10A++kPi
O1IQD9jppetIG7EnS7yx/MrX4QtHnEJxMxmNHvni+uxlUx3UQ9rTnfU6UojNJp9ODytkHIfVG/XR
hGT51O+KRNFxAuBU27d75dHbNqkpJ3Npd/ENP9/A7HW5FIFIMJLGe0tGpgpFsw7RmjXaMLO7Y9d2
8p6Z03bCjId3lsMHwysYyqLnUjMpg8+W/yAoQ63ySG5Lj1A5yEbsoRxLOD4W