<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz79g76Q5156OtazKgGF+tZl4iKBP7QJUu+ud7TXhfoVRzUdERhB/BAup43dA9/93ARRptkW
As6iEFx1CQmcfJCuD7J42sMisWMlKElWhOZb4W7f+wR/OTFj1LxArMwrQiWCBRKzFnZeB/1OJLVX
N32Y96HStXYmqe0gsJ8+BqCZ9WLPlbzDPrhvADC3IvUtyXy09KLXFUoymgxyPk3bZopHtDpt4jdN
N/cqkJRrEZz0YJSeRlfffdoIdT89f194lin1IdtbqdmqCchhCinmfHNvkb9hVqj+2HZdLVqSDWV1
YKTv/tVV+IvuOmNjX6M2PpGPNBJF7YJq1L1FhT3NxBQ526ySEO02dA1N7IBkv3RuS9N45RGjE5Rg
nct81G7yHR/yUksFi/Kw4gT7mfReJIUsvTU5WxO0+ff3T+8D9UfALVCFook9+J4YW+saO4RXHXpj
CZkMVuRWNZSTzZfObU6cZF1GzXZKX+uXnZZXzWJUQf3R7tonO0UFUXr6hvNdjDDMQ4JlHlFM4/Pm
9/DV2g9BIVTKFg1k8gHNbxnqx+vKmlWUB2hdTj4oq5lsgVVSbuOQVp6q/y4iXZ+7Bk5k8YT7WIy+
KS0m6ndnUACCvEvHb+RPH4qPDHQ9mLR0R2uBj5aAX16aY8kr0594QDhJS/NXf43X80umIa7Tney6
2Q3luhP8O8Fdq3CANUUlOtV5Z5fp1JYVmSeHkwxnaBQCeWzMBlVm/GHBnJJ9P/IVemArBwKxtbpE
bD1AkD4hHubySYLEZAVP+ETUzEkYXIcsPYGMJQiELQB3+970feuJO7tizk9l3+TW0FX+wTuQCpD0
ID+mr5br/LOrxjLQ24RAFThKZAE+3AUEZVAH9ILQIllGmcNz50gZx15Yew6+JCdXNnIwXxDx5TNo
2bmxjJvOb83piZQQMR1q3UoNi+6UqZHHw0G/0P+KKYzEwWABvA6p/KK/oRZOGxHuW9+EEMr/YpJX
WqcPa1VXQMuzwnDlPmw5fB71NlllByNF+IS7RpLK/8kd6Kjx2EgkgPxDcGYBBeyGdfkWEi/J5M4H
1h+vVNN89bh4uylIwT8Njn6bqN6UMLCw3/6V1xuap1UVkncdnfMeazPlSt3cx1XcfCZE6SjKLCQA
T8nBMuczG4pZxHdAPVfrDvAgK2BVo0Iz1NTL1cMwQzXbf91AvYpQDT8RkiYuxYgC5rDsWUfG7JRY
mhIjJMRtrBSdsaC/rds3ZITi3t09BECxe4lKhOXf24i=