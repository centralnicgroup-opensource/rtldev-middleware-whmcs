<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoisEYlu69yCXOQl28BaHl8neJXsXncQagouXv4kSq1X6x5vKfkyLyExgiiE8pvsLBh1ooaa
SwpTvARleIeKHk8teG4kkxCpzuCcTTUIHZvrAfQAvJzgiwqHBBwgLamNYA+ZuYFC2bN7KhQpXc4l
7ZBCdsF5x41HU1x7pvNdVWX2gDj5LjgpbgCudohmzLI1dO8b7YiA22F9IJKW9v/pEWYUw1XpK5Dl
ZzoznRER/4noS/m40LDIb0WM3m2WWHlv9BN5cBlKA6H8ahe357dMXSM94xvXquwyjKm83WN7L4uY
DaOsIzgAobG3xdDJ7Xi3Nyjm7FamcSqnaclBk3Oe19cJ6nF2lQOfDiPA/2gvv1/YlMJmSZ7wALs+
U+MWHPzgT4XCorVH8hHWfkUG7aANDPQH0mXEpZ+32O86ReEfRM7OfhDkIB2pKVEBaJdtpw25h4bB
WTS953xvppFFYtC1GSm6jJDAU/EQbR1MSyEM0uuIi6p3lTkiS1ZjTql4Y85N/YofUzmS8VELH6PK
hBoEjuTdqOxIgs+EC82TyVJuUDxFZRXSIFk6sYrmJ1a+aLZLU/XXgcLnxASYxGkrd5MHOftvwcbc
mNw+ghGEBOyGuKRxEjPNTW5Cq68KJ8oGeFhZNQsvndPda2Ycp9RUjrX2oG18D8GdDCwNJU0UUpgF
fWUu4R7SorHnYXQfUk12E9D073fqR4rkAEJSelG6nurocqNGmQmMBKjx5pHRMi/Lz0gmcBztlAve
ozjmj+H7KJu1I9/q3Q7pqISNPp85FRS7LX7V0D8tzH4Yi/ql8+RL4XHNQA30iWAVcrlStoS7CFZh
YB3k+ixLunqjHfBfVnoNEPeVmFT9nIYlfyGUSlWpxiq5vgbfCUMKCQEI7rEaSP1xswQtsxLS4jWU
QeBQSo9u93TJqUqqjh3OpIOh10t/IZT7pEqq/AdXKnpHHFE/iSq9qDESxGjmZvvAqV2ImN0iQS42
16pK4cWNvpU9FIiuNZPIFxd4aqHrbE3ZLMPrHHNxQvyhwy7Aw+SHpOx8Fu5Zvdudr6lzvM1+jORx
oN9bU8vx8OKjiT5MMHedjzL5oMkmVVJ2iT//3rDd24DNzNVnE+nExD3rV5fTwhK87E3lVYH1l61j
jO7k/USsYF679kWtdLC+4Y6tH6KqsyQKA0QM+sR8ib4YSOAo66RgOR1yqnB4Jp5/DL/fQf88u55F
s/BBheAl00JwqMxPdHosTCAqugWejlwJSeY1PkThWg9VR8vj