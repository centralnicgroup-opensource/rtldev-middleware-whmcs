<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvO13U5JxVNMAh6OmZqk8zEIRAsh+oxrzfguhirhhgCBXyKF41GpYWIxZuDgqLTFbi/+XZr8
aznm91AWqw9vjj+Kcm/W2m488VH9zeWX8LfxeRZJRE4HdXQWE9Wc+5msrVnqClgX2mIlWMMNn0ju
AlYeFP6f4h4RlzzgEC25FwMvTpbAzTg/twdTTOVtJG+GCwl+brZ1Pq8KgG9YeNE1bygFACYZLDyW
8R26XnAMkQUtdt4duym5+O8cfu93nHH/hsvBI8rG6HoI3gSU9NxHfA0ELDndD+CAqQ3hm3XKttNX
kSLi/r7SmUX4YNyT+Gi8Jx1l4GUgIA6mB1qKfrhL6fjmEksU7KWcFzVJo0O9KOhaKbtzdjFnDs6j
Hsh5Evt8B6SNpN3UzMWrH2Q9C8KFvf2AMXfDZgKkJNfvf2wK4vE6DaFOlHjuqq29wEKKQKDQOQho
NCYOmI1aK1dpzJ+sUttskCmcpM0j2DH0jBSYR2NVyPS8aDtpixFtYPZ1Hg6MeFgoB2zoY84FOA70
daFQLsmq/RfL2CtxHxdxUsG40q3CQb2Sc+I9m98wbcHaboJgwRlrzmsEaZXezcKwV3XpV7Ovd80a
5T3jCMmcMP1glSGdV8mUyxoo8uH/kd6ImZkTQonRGtOi8J1DFdt7iuYePXlDaunyj0yZr3AhSPWd
i8/rFvjXzvhGCUnrY9EbyF0iGlAMhYhIRkrvQVoeYygo4bLoCxp0c1UvQxlBNKwSlVTeFnJKNcj/
MkuB529sLv7p5zOO4prvwPs7c1YbqP8t4PQHe1Pbqm9E0OGFHb0FL0rVctcR75uoQUnIEyyiDYdN
Rtr5GJy2W4gG8vBq9NPA2sXZMyCVrPjahKQ3s9aM4NGAEP4YVz3vh68FtSzzK28EJDzm5icS2Bp/
4sFSAmFNDujTnCMQ82xg+Vx86Ll/oZMqfp4JlFrlshUaauwW1pFuUaA+sJ/m1zd4vceRTdqk2BMp
4oCZymimTH0CTOUw0+v8Hw7G+i64hiM6bRnMCH/j1Ws9uds6W/k1I51vrOEXc7uuTXNmhwCDRpCO
HzM7gFr7CVgCQTn27kKPo1E/pUcMr3rsVbFIrnJQtSeJ6GFakAYWT866dYmdsDKWcf/92FSBEwYE
HLTh0z+USN/iqnrOnI8z62hV+BsQ5y0K76o5xKN12WPnfkH//h7EyA4QYvalg7Thkl72KWC7x+vl
yVaTqQP2capUipMjwWgNGXqeHPNySDMduD577gWpN4Ns