<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzurl0fe6GKjTOKfAJcaDueeNJAlh769iAQuN3X5VNLiNoljH9FmSHNYOnbGinR5w5mCzL2r
0LtfJ8uDZZiDvH8wU2u5KNECdJkpTAHP2CNn4e4sK1FBbvxz4X5kmIlAcCZUOkfCJX9A7wblzf4R
kghv6rJo+FVXosow+3Gzgux+6QTUX14qJdQRB6hPhNlvZUfv6Njetldh8Q2rb7z2GdNU1K6+185s
NcPAutWq98nOg3ZFYAPhakgDKGt2Dv6rZNGpAzyM9OqV3uQwVOh17D/d/8HZ/tDbKYor5U+WTart
G2TXIwS1Emgn4v3/4lU+tOwcg6jOXrTpEQi6eHMfXXWTfQSLAKs7rc+GaAUUO31izMD8lBNjFLbf
5dZJttr+fj/2lhbxnRhu/EvFqRse2e7p5nFSxz+x1zEVhxdpYLbEgtbV7e+zbmbXJQ8vufN6Pw5g
rZqqNiS8A7SA/Y6xMZLyODsMs5D5qcETtIzsB1x9j+QWBvJKVlDYV495CwPwIsrJhwaiGFxNfNak
rDYq1iuWfILzdQEUWIPS2ezybw4e1lv83osSTtyYagK8HLjrH/hBBA9UoDEuup5o3HHeUkRcBGyv
1psoSo5BVP+U4IERFHI3b2vgsryTsHxHIB85VNKfU0iNFz413pDlVaEzZVETJ3F/r1vHUNXSh0OU
ZJPJ6r2tWdRZAYoMmHxu/O4jOQLuaZalqjvAG46OFLzVr1DUlm9eYz+PM1Js2ziBap/1FK1ICh9n
bkIAFdMauW6DXJN+BPx9eh5/fbHSTJvCdFoJK7R7EUHxhpknlOshh+HQLm7HEuxSlkED7/hl/i+/
eA+D0ZWY+7fihutJoO+hqwPcOz4AkDZN+flfXcoQxlcGadq3AFzXLfMK59noKEQoHyXji4YqF+Nb
3Ydbl13FsBTrS2fY0Rf4IeO7IbcCj5L8a8KArqMejXfDJYGHfCqzXGq8/b21qQTUueOtOgFBaeUW
2QoyVw0XlUc0a8CGR1R6q1TlUqvtAjulgNd0kKC6dAdsAuSj7eVyyxlmBt0ifO8vZ2ZK8uFdKzIH
996+mpBaJMqvrHpVOuPNniO7XbteooQBljmaCDA7/wKb0VjjPGWhjQgRU1Hf/jj0PaZx/B+XtnTZ
BDIcmrAAcC8WhRL/p6HCT37ka0rvhi2svpu5MmxEcotaE7hrz9yPSybyewgow1wA9P8kp8i2gt2t
40zAdHeJasKQb62ussxziOMNQQi84KbidcaIYgMhbwFUpsulgSDYbUi=