<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnVVr9xV8otHfcz1lILPhEeumjkzsUfs3yQlPDN8oi/4BGSGZYTGgMqUyYRgwlOqiWcNwWHf
SIIce6U7xjyuUrOgY1zAZ+eQrEy9ldUHFuevxtquIO02sCal6SImqG2DXmEfS0YKyNytihso4+iE
xiKso2VG3p/TdWoyNxfim/ElBLsb8mnB0Xbtj/ATN97ygPjZ71E3eabd6K+XS3fR9XqmLYQcINDZ
09cAaPi7XAl4SIpe8BqBUrTfWQ9kdp2Jq/xBl8ucrFo54AK8Sa3fqXm74PlVPJB5MnQu34nwg/T9
WIocP6UJ4hoXNC8i6h4lbgRqg7B30UMBrUCpR5hRMkwlK2ECQVcn96v3UuvjRYB+fj4Lntsaf9jJ
deXuQ+1Ye/yc+21CODEwujtV3nHkLLpSqzEnajqIZRlk10bVuhdF0uef2lFjleTzjLCGX6meb/mr
VULVE/RQyPgIhimATH6Qr3aCQYxRwmOIzqnU2k8DdL5uZJyxRAdc5uBNTh+cP8e2wseGa5x7HikQ
vSKGTOR0mNI2lK2Elf0itkuToK2UNeko+G4t8yAgHpBOmCv+8kFM0nwOey3quJWM83snV/2uLUOw
VTRxZjDUcIpj9HM42KxbExfSSHXOSlqL3oFgN5V8HTylcDDwHgZTfD5tNk6fx2nj5oR1C9pj15CV
IgTrwQvVmJI7N+cGYYOs19hz2h/qypyZl9djzpeIVHnWEvpSjHv2WIHBMv+v8GfYbcgQxozsuL/7
SsimYQhMplVv8DjsLivxb1fPHoGKHqc1MfYLiIykPEzIZjQPE+l0ohjBH537ecVEzdfoT4dw+h1y
BsRdHVM9ErklpdjiuOWx4ekiFvFskmn+r9OsDPieOkse+tslXz1sHCNfEM1ktnB3T/iCUvJPGJIN
fe+9S44hcUvpIZd/WSt6fQ3ILdv4Vt6ZnMMaITx2vlGXMuVjfCLZdy5A6tweYlECz5sAeaLlPkve
ozcPGVuQmC6yyFvwJcSL4QSuzmwhOPWaMFb6RbHDiokLfvZIXvLkeNuk7pX/9g47HEfkqKSEMcrx
SLYIewcDaZ58CaIUQda6pcGgmYkxx68YZeh/wsVfaz1dqkpSJePCFdQj7T42GGbAqsVaiIzWALLV
fGIMJ0UUd0NSuE/X7dIiuzZmQiwvO66D/bBRP5K+rdiiI6r0s4M8zhMapP6pcywOTAz5OdezwQHR
HrHn1fb24oVvZLQUim0/VGQrlgsUfUXfnz803q5EgIjii+a=