<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr3WVbeJGaEUwb3hUSMMIGcJrdFZKPBP2UX8jLHA//2f9uhTXi84eXCrH3ZP0y5Xoi4Gj4Cs
Edvrw+pF6BSAs8AIDfT+C1yist9fPmG07joDEhEaIiM+muBwUK6np5/0LF/Sds/5MixpzfIWnUKS
9iJupFTTmWxgFJUtRX2vMlRwkyl3VFeUWYiaSgcM0Sv3lYSodfYqyaG+u48L7a8Y/AhCZbQO3XP5
H1Rc+5pI19oyLN4QDyeeatGpd/T8RXdutTuBKnfyttnR8lj43fqn+qAsEbKfQbQvN0ILHsy1qM/D
mTXb5F/lXh/BQHuddUmI8HHdaoLoV+oN8dbcexa7GEOZI1s1uQVjo6WDDx8P88+lrbIQlTuq5uHr
4UhmxjkdkWX5FJLUWul6/1ADCgPV7hvggnBAO5D5IXG4zc4ZTROof/1viR/yR5ZmQvoSKIrPnV3u
X9mPL98uz3XEN8h3Hva3LLZDblb1oDaRgufGFJU8xJzeVHdP2j8azYSx2X5tnBDKv47jbz64cYor
Ld0UirbWPhdWdImE6egxdgwp3LoiFxmuTh3OFX1CgF415IFR3RLAm7IlglC2rsNIHPBkdiy0mrsy
85WGpWZT59ZrdjVye/bd/BsIKP1rYpugo/XnnOyD1AiK/oFUn+vNvhnGLfTMyWOrt0QXcMG+Ra9i
QqGujDvV2HTCjFPlRODlz3dBckEs7agNLSEFj/8BC/rr/UE+RcC4aDGHEujSNgjG4XBkkWIQPyu8
4lB5V7aRV7IKorgmOYWmK1yp54Hd58QWCzBlEpr7q1uaBBHpgyzD0NGgDKKDHvwdgwSC1r+VDCS+
SxBkz1a2M1NZtEBOfH9v25Z7jiXtHT21bumUTPpyEF2S+xlrAgqvq9UWtNLJZZriLqc3OH4RcJ8v
HZwvsiTRXyNpak4TheIFyc5lT58CtH5Y672voe4J9q1KYInXSRjqx9VTE53bdQk29oDAOC5Zng0O
Tz9FxW+u2X+4NL0niDPejyiVuGNe6+F9sSndfC6X8XJUmkbaE1c/PLbhwthScGqcht5JSy/ei9kB
WXpA/qRPZ6KY8c6fpq4GCur+GhEO72cayWn92bXpr4LDPiQ6/ktdnma170r9+TgYHSv0EdHnakT+
KMt0BMTRruNzdRiO+Uxs9XtMl3sllrCF1N0RaJ6U2NIsg84vUXqvthpMUgMbGd9X0j+LuzleMj4S
IqYwlCRoY/UwkfZH11qr5g38Ug3bLbT5