<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnfNebDOiXPa9U0tSEfvMuqhKwrMVCs/Kfwuumouh2NnI1rPQ4Z7UTQpNbadyHh3eFlnA4Pd
poiSuat9uPK+4PgoAfBMrL+OvvKB1KWxqWXnIB6aFjaNZXso932oS+mekbtF5o82AzKZnnKzLaEx
q0Y1StQkM7W/kSLu92GmYV90gsU1qk3DLLWTDAqEEmbdYofPl+hEdXth/f+9ZA58rvGeQcvEDbZP
FwdvHt3MWFsAaxYCC6NBHfoG+nVE90PiKhiThLmNTQBmEO+CXpAnqZy6G8jZilDkJRTxIAbFzSud
pmLQV9lbaPp6h80T/ANHcoK3NNIHekVtbb0aI+e5GD/7U655Jqn0JRd5/+7BfHvyiWa/A/2TTjX6
S7qMYvb/3ltdZyo33FbzyB7UjDYBT+bS6j4hFKdv8EgScV87Ikf5eIfiXizzMdgGBESJTfWgFWfS
Zgna9izyDvU8J5HA0bwQB3yz21H2cpSCVqxByln294FY2H0HaVmzCyaQOMQOOw+a2+wm0fuQ1JWz
JQI5Uz8VUmUkVOAYP9gyZZLz2jC6bv/WLaHlWZBCvo/bDGuhM54auJ1YLB1lYU9TnFL962iXaJki
SD0XDv82Ubs435snoMDs8+OSPh/jGO8Ndz04KJIWNSZZ0f2r/p6GnhH22LfMitDWQBEDNlh/gJwi
iJh86OZLq1O4wph++HWjdd1dDt8GJZST6xdi/yEvWNJ9zUyiSp+CsQ6sCItBdgo1Y9wTZfafioMQ
burhp/MIVHnB/uHoSdqMT1/svpGwLYF97LD6taITutDNcAgLj+zkD9D6ACmDFUklx7QtqA9XUtlh
1trRgAAy8ipLmnPHaTeRBG/SEVztPdIfmJCkggcH+h3NvBYmCX7fIQZ/98rTzeHFbgLkpu95w9cz
WVX93Plr21Fh7zrULeTpzV27S/Q0oyVObSGEYBqpB6PYacImq73szlAZrLeVthaV8V8s7rIOF/zg
C8CKUitDoOGWxusbzjzMxQCPVoUM/OSvXQKoS0pX0G3x3TdZ1J+BokbQMBUUGjaeCyR5XrVea5WT
fbUdKHnCxG==