<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnKz0Rn91Fgp58gKdp3Af11AKoOVdkBf+82u5SxRooDt6O3ZUxYPkU/+/TBM9Qu/R+U28A7G
cwNvdY+n+RZqZp3rKh2Y/TwhUnGjBhH6vu0ns53TRxBJweoB/MPuWskmazrXY9iiwmdtDxwi7Pzm
fKlhpYMS/5m7aC/CnCRf0J6dVf/AV6JaAEEFiHK3w4mMLU1Y1Hr7yX4VTZ3SCF1U2F+2YaPb/CCi
GdjRhGZWBLZ5KnGhml5rn1nXQTfxggEFh79GAzyM9OqV3uQwVOh17D/d/8bk/QcZvyWK2rSJx4tt
emLzt2Lr+B90L9kEQqSA0xIM20FEv5dOJa72jMDHKSRhPJL9AxQwKhCkhQbGgP/00vcqruQxXCqM
7ljOjTsr6ynBMr1VpuIHUdPp6bICsB9/vgiCNDWC9f6ISmzeWiU0Wd0nSpEYwxv891WQC6kiiepa
PNsqYbmwZAAL91Wx0Tu/tf5dadqb2ZFpMUuEgMLzVTRoBaOTmYp29pWulcmdbBeVL8eeWdFFyMLZ
GXVBYmake38npFRV+dRPA1T0cPUlkihZDGt4G4As0fdcJSd4JghBmlv+rDmVXQIpPvMGgNwTxIeY
Xv1qODDxJN0mXj0UFL5inSiin5e5MJd4DrdMNwLxfKz2kYmN8l0BeWhsKQX9XhnMwLQEpkMFuIjp
isgCCcDJwTKm4UCb9oCV2JUAUBdtwgVrCgh3/vWSc1XxOcW5xTrxdhMDsa1pJdiE2UCuqO2bcFZi
XHPaxrShm9SpmL86n6D/llB79Q7+p52b8lZVK0Ud95I3fa9AnUge8zzn2/sTCJYXsFuJ0eidr3+A
2FlPl+cT20s5Mok44UWhMIXXtJHUAvC48cBgT8hvwBoWQYTHz63WVAbr0Lz7cLrnLQhtHmM2fpf8
2PHg3zc8PMlP7vffF/7c0F+Pslha5izN38k0/jBZA+DpeKyFDcPvykXeFSIQ1AcEEi9WDtPyjrob
+jTPHnnN0o0jHIX6ebJy9oX2OQZY0PH+whJ74YMgPvmX3ZWevw0dC3tBMD3f4jyEsFrX7D1Uh899
jFKJ33W=