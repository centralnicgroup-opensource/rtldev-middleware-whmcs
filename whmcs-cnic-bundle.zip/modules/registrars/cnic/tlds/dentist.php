<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoxvXPzNG7xGBauGlALfeAmTxQHvJMPQb+aE1dD6U9wpKShmSGWV/S6sgPenFwIhz4K1QO1J
CPea6imfsgu+7sKVL8D5GFEja52wEVTdqFEZlZeGlNSRv2CuSDGqRfBeY/cpfxJqEwPvSm+tDRQm
/4vLNJzxE+9PL+Dr909BCQMre9iQdrTTsyCLbOPkzBjwQY6UO49jOUDBbhktt+rSGuLHmFgloXhJ
rmmJZkwC3xh7MeRaRkxNy+o6aSoNYsuCFl8l5Qk0rGu0s8UjyA3g/K7By0bXRF4l1OtvfLVKUlO6
KNl6SviCmzpp29KfauC+TWAK3piC5jBZCOXIEx3bBGxsQuvwb9U75zBcybRObJ9PkSNcEnNLf+QY
UVyQh7Dlc0p2cBhU1pwHDZLpdXnvle1QPAlg7P2yvPMigvP4xbj+ySBmrH8beECOpUyzGAI9+qnd
141wUvMY6rzS6AjylFMr96xr4wkaaoY32UJg+Cnw04z9/oywkMZIZZRBr57A69FeK6EYsv9tjZBt
3qikWxhW4LGftsVR2jRZTpxlZADnW3KmtEsGBJ9x/M+KSSFELuN6IW6Ho4LpcbIDAWoGiMrPDFP/
+fg9vwOaJURzWbPjSsYAhSbAKNZkXKRUHsDnWWLkQAAYcFrrz9RQflq6EM+hWQkJiaAQLcHjEkPK
Prdf+syYttEtT8Yt+EAeGF/OdaOrMFkEXmFYP+BT7tkDH3B74ice+jZlODmK44X8bUjjYjODB4tQ
P72iyeIjUI6NrWx5m0lzCASINYrtJE6UY3cjb/id3WVpONLC+6HB+KG1Dv2vaOk6hHCdG6hprfvG
4+JGSYJxxA0DC3Kr7WL2stofoF+S2sunmsyXsGzcxi2C26Nq0s6yUiD0RoErfpRtLk7kpL1h2v9S
zMh9lNQ3TRQOxltRcli9Tii5YbnmJYcNBYdyN+5nyItjyVNEB5T79LWxNuro2I4pdar8YDMLlNmA
SdtmJIls2qA0pryU5/xKT/1EXsU8ZPTyUpbPdvnwRS+Pr62p8oa1bWzHd+4M2j3IDEj2cmGNkb+s
FnznrW==