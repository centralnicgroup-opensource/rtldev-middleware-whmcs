<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+oOKYCPOwSKv2/702ZM4P7aqqt+v9wHPu6uhGNYDnTRTKbSOZQU2HDI83Zvqcibhl1cN3/V
Y10oVoN8VslieAUpHuQZAoNagG/wxz1JVg1MOhwkBtUfFvL+lK00knzt5enBL5n3ZWRYZWl0rK1S
MxQzn8b+esYXYIBTVgmPbMzLe6Vc4Hhmo4V4Se7JU2ckYoAIewfkZI/UHCDLIyslpHZ8ZF9gLc0Z
lqwFch9JtJiwjgq1Zb9zBFaJeTIvngiZh4uX7gppYEhJ9G9xXWTad9nBMgvbduGrOfaGuGkGKjYd
NaS9/vvOEZ3R/KC1vEgOVg0DBfwGeEspJeELD4o3i7da/1yBtwA4JJK3mRYnaqdWLLLCWWCgydGN
mr/Fi8DZ9ySAlp60WpQCYGH3J96Sx5vBkwc6jnNLO+h01qGnqG7VZmmpEpFSmLIzFyAQl0OFCsA4
y23zLNsE9V9Yz8uKKshdwxhMBlDErxGs/+Ovq2DYyEcQ/iXlyL9NorV5OlC4K/2hrdCC3VFkD1zK
wAbDklorfmaD/5XYlWShZjw9DDgPckh/0wLbxTGIb9/klVG7ZzY5ICsuA6MvFzPyM691O3Bb3gS/
TrLDUOrV0oDPacPp05xpSMtPfGI+zkFb3w3eKUYUgrh3kLOfGcQJ7Ve0hlZeWrmqDK0WqjNXlCY8
GKWPhgEiD7FNQx5ReZDdLjoZ0JEsa9Yjr2M3mIR2GukVmiL6877BWlIHuGs+GDFUdqM2UPD/O1u0
0cgALMxukChPP4y4GCCzUUpEFtPQnDbGgnXry3xPq8WoQ/V9f20hI9EmoNHUznZcdX4LZ17LQUvU
iuFf4FHB/ZwSIrFYwvfEhI58wtV0Axeq8Q0Wfx24qlKF9olSScQ1Aoi5Zg7kHGhCsFkTGd3Mm7gr
cfaqEv62MG0W/wkUCPt9BwM+cln6Dnfjs13d/pz06EhKlMFnaZ/UksPGw7hoAWoHqt2iT2qEfAFY
M9w//r7kOYX9P8LVQ0Ic26NBTAXnS+7Nx99USmRVX30Rt4gONc+9mv6RE7I9ZpuDiyCSBgq=