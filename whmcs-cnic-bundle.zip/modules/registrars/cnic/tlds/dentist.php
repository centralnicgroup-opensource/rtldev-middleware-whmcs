<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv0GMA3S+w2NcQVDWzotaaMO9CyeDqKf5yXdWL6p/vPc87WlYKW2kluEU9OqUmiiEcNuVPXi
QnNJwySZyRGg8RcbFzDq8LsZICa0njIZB5yuqENI6+VbgGzEMcjGF/cK/tBOUlpERr5zdRHgu4Tq
w5ihhNkLrXgglKSZslJeIcslGgnGDpr5krt6NMVPZMQeqrngcWVXTkH45ksc53wwpiKqmHHPbuxf
tSc9B03HhHjuQVi/kGBqX7DmS5E8CiSlyJct11fyttnR8lj43fqn+qAsEbNiQH8o4dZaxIwqn8tD
yL87MtqSbv7wxl9Wmj1ar/QWVOMaEfouC0k4gkdoqbJFXCadIuO5NqpiWHn8pBU37j1XeIDh8epa
eMGCSLsO5eExTY/Ay7rjg+hSkQSc6d4q1HK7frXpy7epwNGqRVH8/qvSBwdIT3DOh2qbTrnOzT4X
dDCa9P0LCRM/wIMGV/305Pir3u6N1h7PIm1VlycbGjl6dVxla87+keoGuatBKC9RsE5xAEghGVkm
GOLndmMgZnt6zGxIQGIZAn74RTkFs5pBIwuNL+k0TJAnm5BGhQ2lX+4LzhITTPK/7dWcYqTmGYpu
lobdqtA/CRzWnKGvV1+t9MMq6SJEvojA1Q8QFvVDj/LupyLo/ylJXjtYbQHc4M1W+jarofsEIcz1
rQOMlOTWeX0hjtgKOyH/Pv5aGKJMjzih8PT178lyOQAnUAswE0MQr25w/NS8s5HiRV3Ah2ywpcIM
6RJQxQcZ+LqFm3wFcPKbZ6pNZkMwghZZ27LEw8HzzVZDHUry+VmuO6f4SnTlH8EZTvxLT4hwnehv
eSebXo7Gj8wgRdl1Hc8+fS1DMAkdtdIh9u8VArxoBUgRK/sG3UnJgjRI4cSKLkJlkD+PYi5xnr8U
aIy+ZyQP5TUxZ4nfT9s+fL1xPxd3EU5S+4b1iCHloHuVs1xUAaE9OGzWavG79Zy1VJyCUPaGnMal
YWwLoUBXOoWeY4FQ5JhUvOSTQry89/8Bj3P1l99FKQ9SjOfCBcOtJ/eBI/B3WLE51BhW7AEb