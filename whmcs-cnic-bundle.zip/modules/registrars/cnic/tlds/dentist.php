<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtzUTZsuf4epHUdZ7efql1/zZSelCsG3yyOWJx4gYdpzAcmP7aeaDDxoU6DpmbDCMA1WDNh3
FPFl1kB5AK7v/D8xSFE43Tv5+qXAfuxK9cJAreB9HHM+n5GwgjxNYI1Zj0zRayNia6tFg+O8Rpc+
3IosUPT1l3Y+Sg+9+k+XL8mnbsR9/twR9TcO3Bem/fSHmIEEwMGdW0CEX4EK/PjQw5QIum9hI32V
GVVPCNGYFqenlQ4YWS45XLxN00zo7Sb1sMLWqWrotRQKkYsGIYej9Xg4jFuuCcU8ezTlAINgqvrv
Gdt6nIK6aef8Z3jnXSWkNJILXgWCiVK3uMU/SJJyRP8XX+5jux+hd3MJSHuUcOnf41G0PL7Oa4Nk
0mOo11ywrIUDrWVQT1Md5sbkY0waGp488ttc8pKqkfCSi4l7c2/qYempBa3pdEEMfLPHHexRO2qP
DoPXFzO7xm5UL6yGmi0acqxSgCi7Uez8va9h+ahLB/WnPcOa0y1DHfv7FK20pq9iHvdc0U8k6J7x
2MTwVS9bPiguoBJ1/ct1Zl1/LnVha5sYwhFhaDIr3JYPU9rOK6lqE2CMpsrIGIIHcP+W8SvTn1JH
wnM6bn2v8ZhH24ykyPIGQqwjwhWH8Smz1XRxYO1abB6NUnyhxziMLWnG0lyRc3fWvPM7+6IF0dv6
Apwps+HaXakFxRU9wjFw0FEwQcBL5owvJlDioHMz2Zv4frge6USi2K/VK/RhWz1kdGWtJaTEOBvK
p9Yj56Vl04UKBpcBJAccvQn33lAO2hmpq1V5MOBYyzLC5Md0z4L2RTeMhImKRYU+EOi0X+CX0Li1
436XFe9ZFyjzd+QjFo/2o88p/ujUVJj+7Cb6qUuYJGxkt3+3CmTmAn+eMIiVTn7Y2PCKt/sZcKWR
CCEeq1MLzo/QpkTtBo9SjsqjYmaXBjK7h+RKvpBiptllEYb3NJCu8uh9FRPinMmKnWR1nHD+ouv5
8I3evZMN3kUFGIKgaCzX0dbuWQXZACzALw1Vr6FKizMuf/5bTSijf/kw1+TVlp6woLbvMsApNoMp
iubc+DYuDWm02W==