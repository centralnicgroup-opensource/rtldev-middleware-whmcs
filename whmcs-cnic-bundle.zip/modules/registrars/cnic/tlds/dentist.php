<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq3k1M2+DFvNHrcGGo2YMoIWswtap08PXQkuZgiEn3Zd11S2+unFQytfz/7gTq/AatUFzBlB
KRJjZJQmX0kKIwoPFRCXaymVTzgi1Y407Qampvpn9e0MJ+Jy2mijZRedO0EGdOU9zw17RfB1AUAG
hjL3o4p9Os8bx9lfcDjCGAgdT25a3MIpG1ptuoOXGIFNtSkWW8/J57aQg/arCBvTdywTjyDRsOz5
O/fAM1VXRReq6zupuoIhR+rwVMseArT/sSxQNazPctGn2vxb75HMiM0PiV9eCtr8et0GWiaV/TP6
BiPm/qcCr5DEXaDEldOHZnwB0zjz+5XskgoZLTyrBm8rv3LOVAXi0g28HtqrR6Zd02KjQSH2yQ6G
2X6QVbcxxxtxPsTOqgEVGLye9/mcnhwUAdillajjje5HPunTmEQ+cCJFQXSQXH/tDHuBIQshTI5c
m9BrDmq/ydl+bTN7P7iLFlfovsX85nM4bS3QoG5KDeMbQ7JBMW3whjhJRSOMiNoVHzX6KWN8P8cj
Z5Gk1XEtlOu/IsmLMA1/FeuH9XTJX+QifAPCFQAQplf8tJQlR9LwJ1O7SCeX4q6Vc25FhVwuVlDg
0CMOHuWNQI06SYzURFd4Qmk0ydKsVUY7lEr50lV3km+a3cl+S5d0X6j/2CKZU9NJ6xX0Luw1CAUd
LmYs380TxvtlECjnnW3B+yFkNiKBKIRsLLBTssuzRf0M2cro3HW/EhwxSRELwK+IYu7l9KrxivSr
T2ux5lvMvCav7BOCxwPmeAiJYjsnB/bnJALIb85s4ptZbtuQ6tSK4i2f/xhT6OoLoAos5ZPl97oZ
zwm+ZWlnGy5F2YwkjMKwmxipvsijit7htooFWZ5QQ723VqRH0K5imKlkbANtew6khkKiqhzNwfgS
7pkl7gDh2d3ywUDxCddKeVvTqbxtdXfTgsviIaAUzshqdDlK0L3HdwIqriCW4dhroMuBugr5sBxz
FmZ0ki1GLWjdztmXTgkm6SSKW9OvJHpIXRTHJXQ//IOtJHHdBR9pfYP/5+VX53ObElapkGqHdNC=