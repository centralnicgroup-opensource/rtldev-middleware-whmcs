<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+JvW4C3G7bqsauLOAKZn2pxLaWQC8OK0E1Gc+nFMEUZW+6i6O2eted1wB/17b3VYLsXwTyt
VklvFmtc1x4bD/fx4jtUZ8/uXLl9cMf8TMUHdzXV7hDXxzPPaNFnKKG2QPOnBzmkkL6WcskCP/wX
tx0cTztGNy2ItsrhZ7M8CJYk5fIQKhfJVr2HiTiETmpXbleXBxi+UoqCctH4PvJBLoroz17pCVOG
aW6jq2aCM38DpoNc4GsZlFDLdTbVEwKVcdhndfYxr2XaI9Aw0nHvreN5YHF/wsa6T/ps6QBWhSTE
yiScSye6T/LeOfQIxz8nRGJIifK2fwBZDVi3Zei0uNWn/jEeeVlD3w35AIO8Iuekdpc9MI9lQLrB
Id0J8IAyPzCAOWjIcmnNzWd/2HeiaGdfByCBZb+YzMMt8Cs5aithSsX8ZyW5P/xeqQ/VDmsYG6U+
C3ru6uJlol3Ug9WLY+kTCslqPRw4jE1F16P+/qr8yDCcV44bm3wp3l9jMw8cNdNbNOK/0lg7hi+l
l5ae5KjyPuzlOxrFJYvmjJcYh4OF58Vh168idHhq3KRNpQEwavCXD4MPEB3fUusz/Kz5fTThUU9u
NudW9uG1cs3AaJOmAwna49tOU7FbJv2I8kqkMXbppNNaQx4NgcW5RqsU6Vx4F/hFTr7KzhZy/hvQ
FdznK19EolmoLo6BQacaGmbFh1PGfn7hxf7kxPrdxQF7DREgM0KoAIDhKQ0JZ1q2JAuzCgxAtiSx
EFf/lPIgdXmKlDKPzLO4M/TnGwNSzcHA5r0LMEw0zz12YG02eYlXlVYvdutjXLqhZFGOg+Rf0z+Y
A/0PHemU4P61x32c8y7F0ZReg/ePPmw8+zYjFIomB5yW414QbxmL5xs+rZf+vtsJf7v2WnUfFIH+
1gIoJ73BbMiCEpLC0WQpVUmXrShoULjxi3BxzXcmUCq/ACVTjfsrY9vsJfmILi/PzM+GRMrP3QOX
rgsbCGL+tSfKryPGGW5d1IcgANGZJMFY5hhS4O50ZoV+2hdQr+bUQr8tahrxItr3Qe05ulnutbwn
2BOW4wQf