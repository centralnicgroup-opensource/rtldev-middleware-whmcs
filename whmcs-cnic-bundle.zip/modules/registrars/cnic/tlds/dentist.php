<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/8p+NRz7i9v+8HiLRO+WqCke/KDwMhnW9EuH8nHGcRkW/5DHZNM8cDuqY5JSLRexK3Qypu4
RydOj/2dR/ad/65C54gbHEXOc4r5LWCAv188hIfss4w4GMHlvLP6x9fqSJch2UvVBLareBBqdbHm
fWzu5HeL6EOB73cPzOY/Mlgnc3BoFYFxnLKUYJLgsA4gpMs1Yy5wVMffh8N/BDv7IEznci6WsKjD
NhKF226D99+YopU6aNPiDmj7cZ+i+FCUwgWrI8rG6HoI3gSU9NxHfA0EL21bwI9daGNRfZqNJtMH
akSwXNntgozSGcJcpFSAhnfhItOCTQC0qukbeYvIgAcXoTVyxKtgSDHCMuFYvl9j1a1EMg+z8w2A
oxrXHv2UIX+hKpP9HeahIXGEo/CsVajl1+r92sNAW+1MBUsSdgIDj71uJQjTATAmUON/iJIkOT4V
fP/vXamKja3mk4kBD0sUBGAfycq2s7kQs3XvCdedVf5bfThxrWqqFWnzkCGjRZdgtyfA4aiqQA8C
9fkFZ9TE2XWaALpBoFQSCEK/MZSLv9bI1iM32o5qNgIL3fnp10RBNgmutTKD/VFEd7cLZYIDVfwQ
Mqk45n+3nlSPieICxzs6lFZ1SQcB2q21WFLXiphcbLtV6ZXEbY/uS31BE9vvk7HyHdi/2uNrXiaq
6Tsh1wjyLAKdwODhE92j+3GBZgzMWWqbB6GKWBNh0sxRp1pglKj3gI+HYXlLHOoBZFm91rCHFRHk
cDSlCPnWrZt56ADw/MJnIdxaRaFR8YxnvhiprYsefCt+PN+jZWLptOE+GR0hoYlcBc9yMysF6s9+
kYqIjNX9PZ+JpDsCEYWgeMl0/d3hZFSaPtOqSWnnHy8tLWVG5hqClcq1EXTn4dNHtNxYzMh9CR+J
93JhG+uBAoap6sp6HSraC0HkCWh+SpeSQcyIgGB0Yhmlgjo70yyrUZg/B9F7o4A/rr70dVHPhcvc
rUDXrPKlZW9rNYRN5YkBE2VzUcQOUL1ZRSb60JYi/N6X8H3bSJH+YgYEm7E2bvwqLQwBss8z/7AE
h5GGJym=