<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwOYehhR2HUzefKtcHZwquJsWoHOw6eYnULByio4PHCqUyqfz3cAl32WmxB+pKYx7NGcf6Te
iUUWB3Lg9gRKMDleoa65yx/f9d7ISafAPrUEdNgS1O+ZS4zz2ooaYcotWHIszzagXcocmKLPDURG
2M19Lt9/5Mttzo8wMvVFpFyjpQAblLK7L6lycEUtMGT8j34lkU/pQJR01l/YgLNjJlMubOPrZsk4
3r6vFWitcp00qJyCj/veTblYAN3DdqchdUrpGlK/cQ9+BasLC4HmKEQIKNDcQmGtOTfMAnS8rCWw
pU55XsD5op/TaISZIWY+MZ5naYUKsUG3l0zf4/QDeyG0JY6fE8hLLRJeUuV8jfgRH6Uo/FPmIDeL
qEktHl8BjYovZD74HlrIjuIhTc2DssMcPR/GUc7t+P+2/A0CL9bq+oyWSHUajU6s7Al3Ib7iEXO8
LfmntnpuTb7BWR8rglBkMNpJY300wgyYxLwe5+PrqFN4wtvuxNaPfWpf4UHEy+Qcrecskj3Dx1gR
mqbX0ooQBMBveralK5iCOVP18Ul80LLnE5DAPax84kszMdnb5mQSXVb2CjDnuqWlRCuxz9aMfWbw
gwktWk5IfD5aG7TY7L7iE2y/Ac8pmOeX4PoVFnPXpqfzgNPADFzuBpC9pYpEQSBYHKbogmyc9r3a
pQPximVLEYAlSSc9YZsVRCEYK6JXklUd/8d4zL8KE4aVoWN9+nMm/a+R8aRAVhhTnA/2q2BWyQlz
M7piHgXKbW6xidbIY2rn4fCMzFEaWXKhqwQmrfQhIw/f9BPs1U17fq5ldYAA5YNHruwQUAIbs28O
/SLoh2S1Gta8cnTnIHV9X5e1DIWddOZWdmd+0aKdxBGsilQdPkpGgwtw7lPrY6GN6fl0dFQfe3q2
/bmZDz3yN4fHVnh3h41uMn9NZyJBDro1VqvLch7qG8bwaOCaiKZjyyRIFfGL3I+XRMDtMYF4IZT4
IT1ju/To+18bAYhMOJrCLfS9dwA9DnurDzcm8QADoIqkCWQFGcJKHMrzqHaTd6mIb5N1EgZ85QY/
