<?php

$extensions['X-ACCEPT-SSL-REQUIREMENT'] = $params["additionalfields"]['.APP SSL Agreement'] ? 1 : 0;
