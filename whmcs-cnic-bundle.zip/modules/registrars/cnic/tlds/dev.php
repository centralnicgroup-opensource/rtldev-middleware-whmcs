<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv3aC7jBJeby4bIbMDkB7LgGX3Wb6EBt8yQ4BxJJARDNNhoyp5Li8HR9PyaweuGL+e6MXxBe
hH7jzuYZf0gIMruqKocpqOOr+u0hWr+MxT1/iBLpMGzcrNmghhPRrLp4w5kufTpJsQhMxqeQIPKI
fzL4eCsYvo/oFiFJl9NBFkgp83/duLoEnL/h50KKLS5tBSIEiUGkd5XTlLwVB80Nb3EODgqRydVG
dp51u0sHB3ZvPb1fB63W6NgudCtQFjdZOfL/6Qk0rGu0s8UjyA3g/K7By0aMRc3iRjX8rLb2yTC6
mGy7MMF4EX5GJy5bZ3POHcjOYafzK/ggFvmB8/llNzwQnfm6nBBxJNLHEluTlS1j+7xMigGYfuJm
Iko0vDliDR5Sru/vUB3L8eh0a8kO6QAssbpR7CU2O9C0GZFYgzdEC89+rK7iAdAPZK+RL5ly/IVA
/u92CtpzD4em2g7A36fBcCjOAZ6PmILrGCDP35sHlL+IuepcxgRzswlXWOpe4Ht4OfW0FgIkrr+u
BbSw/IcizPJKz8GhRR5Xis6tlaFdsWjSHlWJDh3M7/fCFP0N9TsiVU6F/y7bQ7JWCgjSoBN0J841
goFxJZ6uRQB7WW3v1ZlVw4MfE+JPytpT3tFZw09bSxAM1fe97TTAhyqz3XXMDnodtQUnczOgk3DI
3UQH0pNfkiliYIqs3BxXiv6luj0ctXjOx9RMUzHz2x+nhsE7vL5fcGDd2001zSzWpuCwIkW1iPTz
NC9xxxc69bdFFgtImoYxWLNcHMlHHzlCPy13TWdDgX+T6bkZyolqWzaVLZ+AAE3PT24kvPNqRgZb
b7RTDiXLxSLsFwOc11gOVuCCufITAfre8SAZuvUm2Z43SSWEpbf6em3g4x6Q8edVdDwC7LMUXc46
XXCNMPgTbkmj04tKtZJhO84MCRR/J9kkZovjmB5A4covSuH7BTiOQb9+MNPxubQKWUpllrNhM8bv
tjgN088uv40oZna114Md83apa/hzkx7mJNCocNlotLGnDepke285g1rXv6yn9S8VliimNpyXO0K7
KGkL8ZzJA25b/yyb+MnUZDE9IJP0apFN/ZhEC7/DMo0Yj9YhLOlbqEdjTEzj51YhA8PxkTt9EMkN
vEu6MNsKMhl9REcduRYCEFluhJesxhSpuMFtq9sGwpGVDFOCDqQJ9wEmJiI+ovEeMObJjWbIjsc5
aOYJ9QMDo4ua/Jcf+ryq70==