<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv1rZafEsN9j5yKRQLTsHFXs+FE18TStaUg0J31SzhSqPlBY0Dq56nEqHFkoagM6u4kGyvpm
YbuwKv9HnnD9eBIWfqTW/VjdUxmTsN2Z46pQdeics+UtZxBqwSYxKv/QOrfA3g2a+lAq/OXx7j6Z
XLdGZLa+d1cQiR7Elw1bhB2q3agFxUro/m5FjfAGSBSAce9Y2fS6/lEsW7FN9HspyOy/5MFFKxpo
zn3fNQR/L/BYwckr04fqziQGRgFbu6IDSa+a4IRrFvcYVYvDbJ14S53cab5plNAqjvDpinjG1mCI
ElravtnbpidP8NTuPY4QIOuOCekjSIgARWA51cfL1xbaItwy3/xhCXWC8BlnNBPCNNZzbyrDcbwJ
v06EWOnBsFMyH4u5ZQ/hxVLwcTUt3gV5mYkCyEFcMqorqPV2JO5tAbWsfBANnB6ZanUSgs2PQ/fc
J71rM5zbDSfrJWFa24c3FgEfKN32pIJbNwOOaoKReblCn6QVqq/glhYpM4dcKmkai1wQVwUFNV4X
kGa6nNX8zBVEWh5yxNlAD9HcRkXB8x8klAdWtf34yJMSGC7HrYA9IpBoWRstx5xj821qzxnwnxnQ
Sp+yQxwUgMtmAeti8PkUc+YgsKQCdg/KFvGbkP3oVjFX1gUCAV+ayFPc3aykMrH7wDkbW09yWm9j
4mNBb+0sCw26Cpya1wdZJ8xiaO8rUYe5M5i/b5uGmi1vZjJVM954LnF8g1oS1lMENDNX2/tTBp0d
YGROvjDyCHy2u7/oNX1xWNqNWP/U1bXvunB8oSLy6+4Id8hj6rKakuRFsMuWmOO5xdrF60z5Hq8B
tWihhfMykUYrp+7Cbiqc+qxy3jdf/1jNoUlNyCNR1CbDEjbBp48PKhCTd/qfe3P9DZG3BVqddr0R
DR416pATrXn9+1KuT/mpBjdIpy8Oc8Y/pG4LRBNAQCJaDmqqghrvc+3bcjsSu+t7D6QxbIs+jCFs
omKMeCjtDNbhgRT7ZDIEEZQBmlVp3YLPQqNZIKL1zRLnW8405DjzKgwwCxqQxaBn3P6zN9X+Fi99
DOAGB1lLSSCLaHxMufQohKYcy9Opr8GRBVqLkYQYlu6lDj2wZMOwByD4t+5YlMtj+/TKb1aY0YAU
kTbFb5og6iwvoKaScjbeAW2hS6NBs0ZJ2M/bwVRzcUWXIiy/5Dn4HYVDAao5JSaBnoWg/rjxu/ED
bT7YDkJJSE6b7LzO70==