<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv8rlonr6GG308Kg3pQqhrxeYYY5RUg3VlzpbgNtA/gXRywmN2GORDrowuveezqEDnPOzz50
GWKeFl/UbBqWEry7oaO5thKmC1n1aZfnKObUAoLFM27J9Cjaq9fmvLThOyGfi0gtfUzzKYZ/vDsZ
bX+QON2GPNzFDJhm5SVkeykYHxk2G69fn/KIB993YSGMqtdhdS5CoqWvyNB3UfufPuTsfHc9UOKj
XlsLdjgExiaq7CwQZmC34ywwVEeKERYoBqrcFTL8ZL0P798EfnubVj6ae0vK76JDMttVXWqreBtp
TH59PngpouPC6z7/H2+FGYvadlofM2p5Abf5a61bNoKoaYFFQtcC0X2uTT1nE8lF2IixifXl4Q7D
AN4nLbMMQKwCMsEdAp0DVHOXoznwq0knmKEj6SCWFax568xYNl1d0/eTOLo3So1NkdliE0a6nTsY
/RSeUMwyg01mh3ME2c0nb4jKdu8htVr1osUhJUFrj6UZwGaBWqHrpNENPiokA5nqoa+R4Ap5YnNc
+1SXtja8iDFg4gkLNOkQxsTBRkYR4aVY5IERanZyBY8Ffm16axgySJ76TQMn5zbCuhVben01s5fP
GT6DdvNBhIBUiBB6+jH0ye30U0Dc6o0SIISkj1PTF+cuVPxmKFy9qciFxed6kXuZIOZkyfG3+m2x
5uwuMZBeir9wrRXYX6b4icy9Q/uU7NTxLXvumPueCbf9N1wySFPrvVm0YReJBpRMfaWKUieR1+TO
WtV20u3RGDHWicqfw9b/xmyQRowVBA7nTMWZGTa6LyyTWLsD/jDV0qwP52ihcknSbb9rrFzIxZl9
Q7B+vQ045StSZOJKQXvKKdjzTZZSe0O8iswcIuA5mMe9Ond/iKdCaoEJrz2m9bdthBqgSOc2a4PP
8X6viu1rMa/xTvtDLCeW43dNX5xn+kg3/3zkBfIHIi+B1SAWHUXGAhefw9ndbuW+BXDkD6NxCnre
bBLmx3dJU75aftJUJYHI2XTtpjrSrkdDhSK0T5kvq8SnjmukZr+VK2JVlb20KAsWSYlfq22BWz2b
/T/d27F62m7sD5tgs1Gg1yUviRMXJdMr7eFSnhsSuYEVPNS7459vTcpiOJ8olgCl+Epwua6fXu68
wq+HRT7yRRzl1AHrGHSHYEipLRGwXSNA5p/GwDgFjV6VdKIMkFKKfYJktfZgLoEnQB2D4rQG+0ya
GQeKp+wqiDzFdPm=