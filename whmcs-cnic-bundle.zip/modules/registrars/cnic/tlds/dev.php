<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoDRnS7NfptshkjGugcd3GOJFum+bVrYTv+u8dPdfaGt+U17lVdVfFjKvvTVxlj7wTnMIf1G
3GtDrA4QMPIS1XIdd3AaiChloGyXqlE2hO3barvAOctk5bw7CnFkSyhpM9xToADwz6uEtXeRVNrt
QmI+Akn/ZuZFXuJxvzcyusxo8mCdJ8MSHENMpkUYQQbJ5XMFShUCVsKKCEvnjiknerUbcMUmt43b
NvSOzWic4HnndUe+loKcP/xNhsrlTXE0LHTqNazPctGn2vxb75HMiM0PiVrh4KMyxqK4E9hSlDQM
9MOb/zidDeJTXKFC5CIWAVBWAfJIRBfYDZYQ76k0cc7GA21TnUix/qvueEJgdRJmAlIRiTl9dcZr
nqMKDM6+B+UR/HVeHjyqEVlIUtt8/k9nC1DpsnbKmq/BLnCkLU5Ii4TyPN2b0Chn3Z9czhA1MBNX
s8unajthI/7/v8KsHb7T4eBk/S7B9w3xM8Al2K0p+9tKQxWadtrumFsKvXCRalFXo7U2EIBol0Sd
M+z6uy1Eojx21H3oqNJKmokEYlgeSwy9/Va6U+GFoWq9fDuktK0AI7cw3Slsu7xbzg32M+/WGFhT
1W6aZhlneiSLZZUiDqXkhXm1tOk/sdAeSNaMkDE5YNF/u5juQtl0ZE0xQs11DoLumlhOMjNiwkVT
BL5z5WL0ZSvSlfRjXS3mlxBQb/FaIMhsezd8/R+CTCi+KwfmmYwCtZZG5XPyaZWTGcaE2RhOh8lB
PQtGNW7qyY/lfu3qwosxi1C8ZnJQLIddo7jtXJZQoQmZ2hmfx+MtC+La4xNJg7lhuEofWPFC6wWM
BBqK1WCowe4S2MZWZbrPB6jiWjSPJQY2WLByyxroalURZ2uZKlI/Ixn4HSKu5oO/Zm8domqV8OM1
FlFBjjDqgDOUb0JmgSqV78YoSAOiAhA0xDloaLjV0erYwGJTlO5T7Q51NHB8Ecw+NaL8aF2xnDpe
tjBnBrubbHjMeRsjq9cYkQ82y5ammYsGyy8L0SOYIyy0/aonV2sFUB3we3RlQZfwjvct344zlLig
oeaG22jhUp38zH4H12DrSj6dWVYgDFeiNgdR1ZZ3RIQsTbTRgjsGjhIiZ+XTHgbZLudu/FTAzlaC
obFW8L2Uphz1iRGpHUy+6wkfMO5OURb/0AaPGWd37Rj+jWOocshle7vQdFiRAkIYzvbLfUHm78k4
WhkqHMWXRW==