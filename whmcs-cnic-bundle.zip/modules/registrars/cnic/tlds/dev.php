<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqhWAmeCGf0joL2+AONdiOqhLx7u0raZjRUuXUceUx7mV740nC3XB6EZG6MZoFTY/nR6kXKH
OvX0iHcZl5Zt/HkKvvp590awDmk4JJ8kIP1DJi1R6QwaqaKe6YqSVJZFSkwcZghqmo3KEVQ0G3FB
de+XOSAkRiluyEpQ4t6oj6HHndsGNad1o37NbYF055yurAbITjflMGjRkfxhNTadMUAxRg8Jkonz
JC+3ZQ6PJ56UYo5f/huOvNnwzsFuy/h0ZDg57gppYEhJ9G9xXWTad9nBMi9hlrZ2m0Kd3CJHIDZ7
ciTw0vMb0PfWR5OilVi0ABt//4xzANDKXwhuKKggMS86b67HCdIMc/vKysB20M3yGDwKFkYbFIwg
vi59oj5GvZaC8Zx9/XglamxEP0CSAapGeTcc6xHX7iRHC9lBu0iZounw2QG9ag3ynj/HecHewtVF
hGY52upNBGa+8qlqi1dB3OkO/ELR5n+2ueqn2zr8HYduOS+JSMDNAGM1hTHvpD0NE+8bubErSlmb
pIOE6Ob/BqCSbI4JufwJC0bzri75MxJFJRh6i9KHog5VnKnpAupKPYtfhFiKDoan1NUtkJO7OD30
9Bgm/7xFGzRRizuTP1LeqcykZmNtjtjzslIHnprLCFKRIf9ql4HC67PJWeC9OgjrT8C2m2XhHXPr
A7QEbbzFVqLV8xi/qj5qUGvmKY8BI5qojXZCSpbzSPbc7UNtQrDlB7jLzfd9DjATEHY4L9Ol406V
TeJR7vsHEy86yD8HuOjl5frdVbV4GzW4Cf/B27QbVHdkwdXDlG8PYiXpW/fhT4oZdr8i5xqnSjpx
c8NS34W9XTJV0Ww/QY85h7OiwhvjqIpwEwPBfHvBtHzAi9HYW3r2Rb5g9jpCEmdaxj3WQjawu00H
hedvkrm373++8iw9dE4Ult/BlcrHRsaAww3vl/Meko5OTapo3oKCpKuiyZqs/Lk7dsqc5D+wyZNP
4HpJFZqWV5rWAU2S+kur7AQXWhbe2jATzNorvzp3lwaiOZF84GyU1SqGzNsUJEBlSIIHA++Oskl+
RfU7xGPclkZlKGBjeuXZ1BsKCS/3oAY5XwCs+EHK9Tgvmq430AO2Z/xDPUpJAiflx6mwmumW6ZZA
ygUXz4ppaG6hTFI5tZDczCdmmS55R9janSIAYq010n7QWZO9ECJf94XhZIcB3FsrHozRPka2frLL
RFVXqJzGIhcmZX+NePbKRQm=