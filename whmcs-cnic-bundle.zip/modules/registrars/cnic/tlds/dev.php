<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsp7WOqPAtgYv7SKhYiYlEHCppc6g1mu78gu9mCsS7wXn4hkRcXGods41Tr22BdzoAyjCqqR
oXDQR5twac26FrxHmDjd0I8LcrThyjojc2C26mAzmKeSI2A9vysddD1nZT57A2zpHjqJIxif9Qig
nRYpi5PMR3Omd1Y/Lqmzdwfv+vpJxlP77A7Iti6NVCgAM8vyfo7anP6jDLsWdxr9cfA3BtN88jeD
Mx1i11xmilLk8MYJuSea/EwMDpxHxSY7M+uaAzyM9OqV3uQwVOh17D/d/1rdOTbtIfdyobN6Bqqd
boKzbugz4P6Svr7u2Js9XY8ec18HV24Iaqol2xrTz+G6VhrZ5QvrRifcjMvuFL+6FyXm7rO7SaJc
P6kLE4LBA0m93YBSX4VROYvf6OXNMmR9/DRBOn5JKF2jcUCxBQ4Oj+torGNBmLzdsPNON5nN0ura
5u4mWF+S9kug6CbQSDRvw4Z+sqh0Uh3sytyirwK8gNb/j47i4IEtc/kT7nXdINTNRvDmFtAVxOgA
4nTI4qgaJqicS5M7Eyob5qlX+ZUgUWVzl6j1K+pbWsrZ/5YkfMhnutCokNvm9KPcM29PEcqkCVkz
fy1XOtQIJLIT+Zc44yT+OJQM480cjlozHo4ZoNBcoSHrCIhC2xlyfi14oRscGIeBBE3NgI9L7uvr
h4Guh2lMj6e5bvt1Rh9w802N65awpSl9vXPLo/Yq4RyBIDwQqDkWcF6xKR/kXjMV5ZEQH2Gvzz7x
IQ7255yeX5gnNhYMiTPLNVoUuGz0ziJmKOTlRZ4tPyhMJmlVUhlArdKjGmMgTPkVLzx3ydIMA8Bz
/EG9jLZP17ZFyPBykpZi3QoThrWSKf0LboPLYv5T1kDL2mg1AoYJ6eKazR0aur2JVWnNWAm89UsT
9YiBDQ/bLVXWOI+tYWq4ClhznU0uwibTUR8eTDpOLGeokblMh8/4uRsnPVBzzNsJOXf+KEFI12Ie
Sx6eKoFhRDIcRgMPmY9N0PdpnmniPKeivN+Lq8Su50IRSsLYjZyuTiEiV6rOe0mlom498iyb42aY
t4Si+xK1UHfmCRqfoZWLOix/gN5MRTLpouzG5+r6GUmK9xRX8HL9mSNLyhBG20Gcb7oeKqapPv2Y
w+69VtS7CXzz5n2SL9lj0Sf6aN2pg/M3qywCO5lZ/7YQiaFKZBLyhQ6WIFe/D/utZ+BYrXAiD/mR
R6DPhgozjr37Cm==