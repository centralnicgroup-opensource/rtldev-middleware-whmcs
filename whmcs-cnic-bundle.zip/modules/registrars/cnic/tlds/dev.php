<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuygC6j+z8XC1vgbI4egdx3sPv4n3c3N1VslzG+RVum0lNnlByh54uoamQmRHFF7PGMB8qY+
uMBgIFy585CKsuKDHG2qbfd38HbNEYsudpwUZD8+v5yJog0rmvhPuktVHWQKSMgqCo5jGrd9Udcp
VbMMgtF+MzujhNKr8JlfBrGlZ7/Zg1klUrd0v4oSh4dzPDNr8/DUQtAK/kVMOGkae3CFCXeoEWE7
HKaDpO5wiD1fGcDBy3aeP77CgD4ohg5drFW5l8ucrFo548G8Sa3fqXm74PibPUx7TOyMlf0TXxr9
4QY62B7VDU81KPHfxm7W1YoolS21fL5ExLyfhC6io2tUsivPGHvqmd9mQUETdrKHrb+6MFAmZFgL
UIAiN+QSj0kK3mPZeMWPnJErwgBQQM0GfYsHv/HBpUXF/o222WAQakJ9fU8LP13V5m8vYwgdbzSB
J1dhMGMr8ap+4Fm3EiT0lFZJdp6fVxLRaAbb4EywpXSdORptL+8aFH2ejIzgrIyd+U6NUFamMcyx
9QAyOIrStNV8BoQ81NXDzZ+315R7EIJBlzgj78AJYiEqmlRypQi5xuVVy2wxG0ATDsAGwUK1f0vH
mZxF1xhQs1zFuZZ9+KL44stqysSB3q1m4z+ZQfghzBH3RM46w4e7yubS7HR8Yllxcp1rAUDpbJus
hio4vWcSJ35clblC4t2pY6KdQAhzTraixDFL+gaxeChIeFa9HqJD4jAXoXm6YbQ0bIvGOHscN8GC
MUiXkboPp37j5/4NFieMCROmhX0kh1LYOpSuctzAPJeUkOOl0IrobJFhbIRTdbeVEkxwqP+Bl0Us
y64FvHp8q5D8R1r0V8f2LZTw+VlVEGiKCFCcERD296pfpFnS6HR0g49e/16PGEppgw+NbPaNlM7a
G+1Dbqc/iG6rdMTVNRr95BLRDY/+5eq6gD+Y1WzmPZLJZnlnuGzxM5o6VcWMcJ/dQDkvtIbZ5f0m
I7snPcx4pjTUpboaZPyBPMTpoOPc4zm/nVPKxaHnfHtFrvVq7uTxd+HTnqj5JcBSmi1md1csKKVt
Et4gbanDD2lCVIanxqv5EVwEAMDp/0COgDARw5Ix3e8YWVjPOVrigbSiqXzBQrLDqr1alZ4BzT3x
la/G94tOijWihfZZgIE4ClYnuEqjC8lMlmCTX0PYfftFIlHs93L965+tSpTC/sS8mdkkJXEka72H
uT1xSdItza+t70==