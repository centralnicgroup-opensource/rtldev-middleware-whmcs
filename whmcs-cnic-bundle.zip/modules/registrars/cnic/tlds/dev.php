<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoRxuRxTHzgnc4jqdVA4ZzyvHx1RShzUMvwu5spf52NVtrLtJgUXC+QJNVook08nUd4HfY5O
bFDeFSE+W2VtgqTGrRnHDatIj831hDIC2wLa+Bycp/CXi+QPzI8SCKa8ucmurrRrFo48vu7Xa8UI
8/A9sYg8z4IY1GuMdLVStAgU+MfcpF2P/x/GVg7G5MfkFSVVsiIBiFHMKPWq69TBc6bekEyZQKJl
54oLOziKw6tGlhrZtEZC7B0p1YckuNK6NsNjSjssbBeja4egBIOQXBJ+EDvkHLvJ5YQMgz53wKAT
UcOVGPzNr1Kl0Srxi2bS0yJJV2l8B2lDBto5Su+wbCvIBI+yhX2htANEvj1sJm3XVrfGkbZ3hUam
oW0Kks8kO3/L9NE/dyuGgIocNxaqZgSBWYQXkbOkFR0SODZMQopJ29OIZwbJcgAM37dyvGcjSlxD
e8Dm9bxHK6o5aoKG/yZllVa38l/tOPXg77aGiN1yk12TrpZqslmGnNNzE7cHCLbeKMf3yhHc27Ll
634I/9/RwpqCSIKERAp3wmTd1lwzB39b0BfOMhF6UYOt0WTAu/bBcxyE/ljBLzkRFoC1NDH0ifV3
WLs02CDrnOgChgFFpR2GDsCJ505ouIoJHU+kaV578kCz6ZWmerp8N/VBP8AZ+jp41fogddewRjMZ
2cf3kj2HDSWHdMHuYkjyCMMZnkUTxkZPagaius13sNktoIkP7cNJ35Ft9P5S5u0adF6DKTvhjnE+
tMoUglicv4tzCLW3LOppMBgc3rh5PG18DDctVhnPOXrG8AttSDHFrmO1AQUt+5ecxPAYyh/o5qla
lnJcDNAsOs65M4oAQcdG4pQaleFr6XOT4TtoNZ8ep64DliMxysG26SXzwRZ7B2XuXB1XIXGUDBjR
NQFiBltUmRXL9WcSPNqsbyugW+aatVc40vs4nEtvMYcmjMBq4PhsU3JRujc0/Tvs/Q7wyCXRQEUn
akq9/wxWRf5+B4YxKMKE+yAC2iW42YFMS0eiUyP2eI74ye5hEJw2JodeAoxJ3s2+YhnCst2FLg9u
H1pSfd0Pue10kgHjnXH+jkslfoY4VajptZT3DPfPZbA3+qNaljLCl3xgWz/2uAu8Rq5JglyvPTl3
b97hNqC+yBGv3oaTn1zykGu7HfLOaGMuuB5H0MnsSjGvYaufb5P2tg8325ZZwIg6FN0KyzTpCcA+
GuBEMAWQhMRLNb5TTbz3jYPQUhi=