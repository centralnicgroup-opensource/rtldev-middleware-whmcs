<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrloIL4ANB9cqqBSSbj5tNxVaPrJg/Fo0O2u2kVF353rdAMFi1CnkOxtEj02NnWjrJx9Mvd/
DUmCZvfVNN3pOR0k4dtWZRYkmJNTPHdafLRWSn8pdYCnKm7qeecZqLTdTfRgcPBmY1WQ5C77dV3x
4KZD/hnhhxwcMK9QmpNeXYgFzPQLNJMMCVEhBTTnuTCeuWFTwyl9Oz7vcGbMA9rxj6S5g+pa65QR
5d6OrWmHFWNwu2eoYA3clTN9kP+CIw+eQZsy6dpVV5iY+qGEdJ7xGhOwLVyMR24EBV/GZw7LLysn
6kP1v3VgelH0ckErjQeoO06lx6JR0nFdY3+1Eo+/467CO6uY6qDWrmd8Thhjr09MEXMxTyBhCTvQ
tvDMn4CmWPPMDsGDbU/kiV4kLTtbaceQh/cwq59Nb/Hm2ks8d+aMzH2LC6cURPk7aShnZF0i7M+O
560ekc7R8mQjiXtDrxF65u0jLKdBtj4dYzCub3BYHP1PpzpSp9vK8U2kE6OxpHQN9iUxuH6P40TR
LwQi5Lm2+CUb0wxymx58iaQgt0wbPRDg2He+9Pi5FbDSdpGKacxCRuvinWvhizdDJ6z5E8TWnhPh
cyX8nO5Gcr1b6VZ5nBE8lif2tmI8WtgeY8kFzfY9zYITtoCY/+1KIX9z83kpRbIaHLUQHUQQaYcU
wxYd26aRLb7TEkBIKDceW+inPy9BkNyBukKnr0FvOK6v3BtpyeBx11FylGaNzbe37imS06g8yWcT
Rdv4Xc9Hq6WFhD2KH4yCQzKb6Dw5whcBPxXZkJUmiyY9ZFFlq3VHE2hFFQcAhqtFv2/L6yInepAv
M8iR6YP0Zr/rtyvCHD4PbzzmIs9JHlAdjfU3irwCMA2wPO+1p0bMUhmNDWlpDeXWxslPw79T1ZFM
QDZLydDZhC/nLrwCYNqHbJahp7B4bLAy6y5XhDNluffLdA4YFsDHN3tB6EeWp/4MUlyRp+kWUKHN
lCqHdUmjOLgd5UvjbIw11TZ8MFudXBpX3pxxVrd6tl8JZdK9ENeoEWK+c/0CKAl5lrhR7ZCB02A0
Ui1aLFNW8vJqZdGVmCUXSHKm+0q4oaP9ct70UVVuJj6yvNgOyPDcZYvcq+PfwtvvVE4CwbVoMO9v
FM9Pmk/OiRE7RPtLdAC5lpMn4M2NhcwKfKcES/Q6qtfxPw+vH5Rkxhg2KlNN1YviRfO+JKakxzXC
8i9PdJsyD5qtxW==