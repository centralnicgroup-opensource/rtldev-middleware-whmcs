<?php

$idTypes = [
    "Australian Company Number (ACN)" => "ACN",
    "Australian Business Number (ABN)" => "ABN",
    "Trademark (TM)" => "TM",
    "ACT Business Number" => "ACT",
    "NSW Business Number" => "NSW",
    "NT Business Number" => "NT",
    "QLD Business Number" => "QLD",
    "SA Business Number" => "SA",
    "TAS Business Number" => "TAS",
    "VIC Business Number" => "VIC",
    "WA Business Number" => "WA",
    "Other - Used to record an Incorporated Association number" => "OTHER",
    "Business Registration Number" => "OTHER"
];

$extensions["X-AU-OWNER-ORGANIZATION"] = $params["additionalfields"]["Registrant Name"];
$extensions["X-AU-DOMAIN-IDTYPE"] = $idTypes[$params["additionalfields"]["Registrant ID Type"]] ?? $params["additionalfields"]["Registrant ID Type"];
$extensions["X-AU-DOMAIN-IDNUMBER"] = $params["additionalfields"]["Registrant ID"];

if ($params["additionalfields"]["Eligibility Name"]) {
    $extensions["X-AU-ELIGIBILITY-NAME"] = $params["additionalfields"]["Eligibility Name"];
}
$eligibilityIdType = $idTypes[$params["additionalfields"]["Eligibility ID Type"]] ?? null;
if ($eligibilityIdType) {
    $extensions["X-AU-ELIGIBILITY-IDTYPE"] = $eligibilityIdType;
}
if ($params["additionalfields"]["Eligibility ID"]) {
    $extensions["X-AU-ELIGIBILITY-IDNUMBER"] = $params["additionalfields"]["Eligibility ID"];
}
$eligibilityType = ucwords($params["additionalfields"]["Eligibility Type"], " /-");
$eligibilityType = str_replace([" ", "/", "-"], "", $eligibilityType);
$extensions["X-AU-DOMAIN-RELATIONTYPE"] = $eligibilityType;
$extensions["X-AU-DOMAIN-RELATION"] = $params["additionalfields"]["Eligibility Reason"][0] == "D" ? 1 : 2;
