<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoOdZCGjetJhAEyPvptYmYfKIgkocqPjav6urE1BC0Mind2cojxthwwwifiKjGH9vfQozA3S
j8nCKFkwhfaUIYtXnwi8TGPMzrX6se+7Pmj3ysfsZS2LHGvqg2z8xmJp1odIeYNwOKPbh8DTAHrP
g9i9p6pzLoPIYWK4+JLN9Q2P7ugv9scmNrKLIIaT91CzQ44NyMnuI69U7oePujXrVLmC7tYtgGpk
Pyhbf+WnjyT2kvsdup+07U8RubpCQkzChkvxI8rG6HoI3gSU9NxHfA0EL0raWzIwu2uxsLIcLNL1
9eT/20JL49CfDosfdm1xC6K8lPEKbMOPuuaz2BioTmN4/uZ6nLotUNGT1HecEBrzMsWC+n3dSqMO
qRdb4AcAt9i0ZG2Q08i0X02N09e0dm2O0880XW2808a0cG2700kIFgQPzHn/SsxcaTnH9Dr2/vjI
QkR+ZwfTmw7RVEfPHsq/HdnCAmESOhgxfX90g/cdl+YqzGJczPfpFUZIUgq+QIfbEaQVukzlqKOs
59vA2cgQbC9SEwCsJNobAN+xzpc0ICOAho8G/pZenmpCWk94f9Jdc1WZaPxKsxnq8ecavWAhUz5c
wtNzeOCHEXa8jtk27lYBncWal4wDof6TqkY+/rTptXXAIXmEbahleXtYCZ2UxPXO0u34iXYxTnF+
t1yaYkGpzXvlZIvSkgQQsQ8SbmHWG89Si2KwLMDtltS9VBrad8YUrg2K8zdHutgkDmYrJI8STMOJ
vPmz0ax6K/c0BR9Sn2LnNGRzLG44WGo21WfvLz+0yZUVRQEgVOEK7o/Q1VjFrRrhhvxQjcjoIl3p
ug+0vCWUmcTIHdulZfd6KsrGRCnv8vrZjQdw6Zr12oR4sB03DSQgLcfqJ9BW7/m8dAoM4Wfq+9WH
+UkShsSzw9BErJuGuvKBH8BAxNltizrZELYf6UdW0kEZrCyzRM76mwxcCbDNbseRgEucjhjcNLyp
BomiawpWpTdyuea2AemwRGdPdt1sbuf72hssMrEKvvB2Kd8dmLlOaqNbq/qz6yicQln6jJXJ6Om0
HCFtNEWagnIBcOcRVjIIeB60r7f/9nlSuMM/bi6Et3v0s3ePLrhsAsz1weh3lK63SA1oqp6H/fTB
1YyrAFunBK/j9lV/lsx+gm+8ayyfY7RNqvnlcV8K8kmrrcrhpmHQPnEBnXICDy11nXbs60dfiLtM
FqZKjv2YzVyWE+GjUbciB6Yf+ekvP0mm0acIO7tBsxO6KAT4oZt6z+uz4nvM+yRh8QZIO6xPlR3z
hs+747qzlialdpa8OGi7vKD0vPjsXQ+LgFnkZQ1iiaEMIQw2VeY4Nh/ZlUO2Tjsi0468SkF4n3rO
IhJokBnP+ZWLU1rpgtIslmWTbd1KvSOD2fl0oYwtvnl/A/+VGXvNZCzL+W3MJkW2w+dLa+riKRfT
wZIBfa2+TVDQd8hMvw+WR4qKy36KG0RDWvzX27Y5QBbnjyvecHviXmIxZdG2+weNGnx9ixnPX/T3
J/jX6pbbBbgz+I5dz9quH8lfe+xoBndpWDggRTTS/MmlfgP8CH16nlV9q4MJidudmHHYgSvamgW6
YYsXcES9OrgDxd0O+3DZDVKVMogifZeVnkWfj8ocn4ReobTqOCle37W1omLQu1kzyRPwSWT7USbK
foBHutdCWCZNdv8IfhyRf7u1XXandWiOPsF9yPtNqd0G/55hHlk3rg91FV+e/mbZuhT5Q9PxES89
qdPorJcyRA2n/TzF0z04XWQFk34TbYcbnkJhu8iQ33f7j/LoMHIMLYHKMIbDmdrfWhgaz8cvcOJZ
waNCHlgj2Zh4qwGk//lbvCqFWZJ4Bo9W9mSqptPh75iF7zc9pmsLOBqAMOahKqN1mW9RrA3Lyfi1
H0Jn0gGkKQheqTk3YbbIPPvugGXFGMMQCfudcHgR/LludSyGxC5w4WlXsJc2EaFopWnhiZHqtzlQ
YLiijIucfE0eamTi6P6AqWxsbF9F9qntB8q0r3M2tD7b2iN+sIFqW5ykRVOiJHIklyM3Be/Dt7BT
VGL+hCzKzmMLdm/7G+rKi63Zc+oxzHPH+5CBf2n7eANSVl6QELjsLsZ3ioZsytL6BP3UwznyfdFP
9llhNOipqV0b1JM187QcTmPAdYqopJhC/bEfE4sHAej0o95NVJUMGC3cyy52OPUAykeY3sBHnnxQ
uvrYsPzpjtq/FtG6L43fRzTvo2YdRRLfRj1Aj+b9YDkger463nVzH8FHrRviPSGhJQ8mRxbbhYeE
92Q139ud557tBtgKLO2H+6hN+QKtbCH8FYKqBKaW0H4HzCDCRIHyPo0kBYlYJsBCyG+dbzRFbVgc
UU3xDtW+UW0C8arIwjkBdWCMHewNlqox9/7sQ9zJY2Og1jrCjx3T7ugmPWYznyiPTPaThLaYvTGZ
1Uv84hpkCk9u4OUiG+EN+1MLWxUPlZLA785/cMAAtPb1EWW6ZFVPBwEZE9eNDDFpyFLZYtyMB/BD
eP3nakBabZfyCYF8tl4tyz/CzlfiNI5bp/LYco+RMGwHYxlAKuurgDhM/AQFj5YOvyDKE9XvdH2Q
sqROMR6fQVwzZUtuoWBJU0cx++427muwNNtBg+W79J0BFdnSsqG7TUcys/amoGIXdsAx42qrzTjl
Q0XcqXDkYgxmiHi1B/E7QYCXuIbjKRxyNCHKXtZWYh6Jz3bL3QPdtTiQrnLMGHpIHR+vcObGMDsV
qKyD6jkWqKfqeRnQLumXZZy61waZav/9BssUD/qdSl/Oypc6fcnzSDQqwSLyPD12nWpdmG9UcYfm
RMI5EyWTn0pXDFVxG1/2OGU+knUKW3fkfqFRKwKzV4mlUCHATrYoRFQekxWYXAcb5wr7k+k7ItJd
uXV++75GGh0HcIusxXf5Yf/11M2QhIs3iq93p0Ewh+cKxEtWHIMlMdMwHPzWekX6j9AiDRV5R/Qi
BouMfuUKazQ5QmyYcfpsMrIc3CPp9SBEUAsY/dOxdQjy8jBDnziIGNRRZwVGE3Jvjdg2Voyhy/TR
dH76I8RFQJMhTTBALLZgLplwuf1LBjOsCWZZYnV+R86gMumgn8HYsAmsH5fLQXUIJqQV0OGjK8Uc
mq8iQvTwahOE8vl/7vjseJYFmlsfcKbldPvBrBBrH1Ay4MRyXkXk2wwp6HIRXfm1K+rtylji1MWK
ds7SNsIButLi6U9V9FGAOY2+YvKGwXsoSm3U/g5ZCPTYGesjC1DKi2ZBD65PURgFiFpgbS8TZ2nH
ToIWEtj3ALU4uIWHwetyWhKPpP//5H6WtZzCvEvm+KZYIEeSlXVJ07JyGwM13bpY5BRDZ7U32K5P
EmaiTJItg+7LS3/LoK16raTJpY0WDAvQpO0NPc/tb8+McxZk7hIWIyYAnQthfVj+ans0OtOfCI7B
j3uu8u/OaTyj6su16WFA66VdThmSOGV/8g27ymQ3WxsfvVlZuLOuocvFgWugbNJDSrxpaHo+1/Ra
6og9E59SmZtIRt5d6J5ogCkpgYaxpK6DGUlw3f9fcBMPKp4YxPcMHI/6MjYXzMEu8lyYc1XlZzmi
8p4mxMaAIyWOxBQKuz6DI2ccbwqGZOYfxLhWnkkhRgOkv/ehAhraGB7DCHgHWCXoTrmpLgg9MsJB
zyoS9jXTJ932KOBGpVU4uKEH0CqmV649++xFyAsA+io6Ub2vlh+FHohIKQgXYyMeosp9OlUvrkv3
8Wkb3f6NipZSkic+MVDalxt9pbqXxVXiKs1FKWHimijWxWdDu7MwU3x9xtB2Yb9GLFS+05AjrOii
YDEY1Mwh3bbT45On5UfQxsyIIWYNRjylQFtbikzLXInNW0awnGFfm+5SDENyJLVMMpK1oDeJVjsi
LpAfMuIMI6n+E+vrPsrOYqg3Dk+vvkngDugzSPMINJFdgTGJdr+IqbKirhMaCroYNqX4Gf0vvNt4
kOI4Pt8Mwd1xis0iVPJePyDnvZOIRZ7pcIk4Ssnl3ADWm1lhryJdBUrO0nahtjcHvLb6P/KaD4TQ
lCHwP/PN9ARp/OIF/bDFmVkJ69UJco7xfnzTKrjRO+rXA2u6Jh0lIDeXsevCI4JqvfrbN3vtbIKn
UCxHDALbSa3LPOESR7htOp4vWvEzDvu1o0==