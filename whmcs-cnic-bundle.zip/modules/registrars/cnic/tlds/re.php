<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+l/iB21yAu8jetq9QBI1QtvtNx1YtKwTBIuOvXf74n6x4OMKXeV9DNILYYOUxPbDIkGEMz0
ZVs5L0NRDUYgYdX2oCqzb2STweiQf+mQUZWXiRZ8/qasNJFcl9UHm9VpKhmezfpyIlXFC/pm2rxY
rHYBeOj8NV9hvn+TYjZYwl3OFdtOkjOd3dKulJXLHWLsuRtvdD7tkKShFk4Q40vVvrHdFgdOiTmC
/dLNuZd7qj/RE2ZNTSaLgB6xHIP46HlPtO8VSjssbBeja4egBIOQXBJ+E1Hjl8JiNFVFsMQQlaAT
YYTqfgdoIpCvi5DbwI1xBMY89n+iBZBsqcorPSr1boB/W89wY3GY2smFERN3XPubLOwUJACUxhPM
w1wA65DhlHuXigN/RVQXoSIPKlt3IFgbvluuFZ+3ynqNhH3FqHIf9SD8uDo3E0Vc4EYHuN1hbydR
eylxA4OJyOtpP0Oc8H6jB5IdnDh5XFbLqmxrHzFHtUbSlUgzX//KFIU/aUlEIAvIlIxlo6/FwMoK
C7bOz1GqalMGuk5VZgNy259iYRF7WvwQRdhzXDE4bzq9UIRLXNm3Id/tu3rdIsbJlzOH6wS3vvRn
gVgK5h5+4u2WLbmpwkac35p/P0cts7FoZNNzZr8AQ7Zf1nx/4jhPh9qaE6CY9B7Da4tD6rC/jJ96
Byn8HkpFH5sPRbBGwRXwAjPklBSGKbe4rQO0zJ4Gc3XnV/ZKBwH+JaFtMQtrYl3eOxBX7BM/l+Td
/vr6SMRLc6t8pWG/QBwaAlGIiTMOeO5ZFOma20yJ2rovDGw0iwhludm0PsQPDVo3DtZ7x849mTeV
3/lwB8PQXH6W5vOf856SYw03zeW0WU8R7r1TotCmsuoP+wHlCuQO+GlhfGNVpvKir5LrNeHLbrzj
LOpI6tgs4gBzjr72A0U5sF0RV4h2e+u7i3wTYuofwhuNOtFp2VpiMbCC6oTycUGq8GiRD+6KgLTy
pElbb2LMRiRe2Pq85nFRI9LboOsFhlTuXaenG4m2Ld2PyQo0SImSNDG3ubO7yCCoOwVKBm+c53GY
5EPuFhcE0YBU+pa9SV5aKSPc8US0ExtE/HH/8f5fHbzIsKTCPmnzl7l+U7+Cvx5BSooub4RfOcXS
lzlhdCsjcegzIaoS0azS64EG48xSJG/fho7glVbryOgWN5pgkIsRX8Q06zRsdX+21Nakr8KmM9UQ
46Hl8lZSEyvGlI3S6bmQTZcLZ5ZmcQJfodbPihTJgWYSQ1sE8nKuxKe26ob4bjJ2ZWb7YODUTz5P
LDh3yCKthtXZKjycjeRqgS3qqDyQOtWS/eyQ7oOS1e7QN8fHsgui/qQEXP58kijKaHG7WiqtDsdo
cK4WyY/zw6ZEHUFyjd7J47NmoWLx9hcnBiobrrhMI7NQIia/NKrRzk/RQh0t3kIA7JKA59x/rJxn
Oyge5ZjDGMN9C4cV6Szp+bRrbUI0ozQBbBgAFkpAnSTplq9O7mYPJ17ATm+rDLbqwbFAtQYrvWb8
ME98hz0nMAoC0rMlPoy7Ntg8wPRUMgkbO1NyzdeEVoIY2VKZICWlgjWfTH+e//aYau9ssvjfN+4F
/clXNHvnuJwb5cwhajpA3+ivso87TKVlLgtRc70f3AJaaK+JhGwTQm7bODDS8VSIiJ97wA+sgOac
UOWOIq0rKDKkasx/+OguXt6HqMsDJW9FbKt6mzpdFz40kqUYTo4aowYC6FfyWKbLrRcoxGKtGX8E
ZpYQhv33MuzQhv66V41/dxlRvqasZlaqUVKZqcW5nGa4J8Q27ruQa22mGrieNy3c6GCtlxdaNqbP
5Euup9xITBtfbLATgzHEy+m7QKSTns7zkDscdsfIDOWRxr7BOeSNlN+sfMVJRJywLbpMxV5uIXMh
UM9CyTucB1+aTSCc5BAjJ9cyJWcRzYJeh3sKZMRSjfOoqhcNfkDunbdu/DIaX2QllH3DGR6OwMiZ
PYZHj077KL+JxxeWvmkH1gnRyR8FLYIrVSZQxc2S9ccBR/vpDoemJVy3/UJ4ZxmDnTu5k7Tgx/HL
+g47O+pifi0CrbvtIXYVqOy30BfIoAXU0tZu4olie4NjDqsBMrrRLpNBp1HCxnWGkeFf76rhlmvA
4H/D45CND4XNjPnDfqkkCeSHsjlAO+ZfBCw89UqIgAXy/MQZiLcoEJtb+nARoDfSvn0Ik2UXSihu
GpG48KmKcQqYJKVUVbl6k5UcEOmnYVe6eAxpC+TcM+lDlXtU2VBo2DsBck6FGnLtOIFkJ2bJCuW4
17A8kPCkB05astPZaJq78hLqI6idt6lWjyN09T35l7SK7C47G0kD36C2AoE1Me6Zfa0IX9qQrKYL
6jvx7PlzZ3PtpWj+DOe+UvhxgeZXG92uKbWZbNfhEbDTnjQ87gvlJdBW5KZu6rBbPHA6Mh5JO4Eh
YdOXoMCET7g5djq+LUMq2tRH1wSMT6WZ8rbJUwY6jQe5V7a8vp0qpjyh4EpEnKvW4MxyRh4iV+Nf
76YbB+dCqAPCGHGZQn9DH86NLE65zlgi7ri2cdvYZJgbP9RffZOUJJAUb6DpibXXq5CG5242aZye
es5g+hbMvEoPzfMPdT4C+Uy1qRB1raYXpX6jKuzpCtgHgFfvIl81xyrbnKSVDTI3fZLy77LuJeP/
slbwxIZ5noEntmhpDHMrJH4wnaPHOUUakakVdH3NB4nA8H2kUhExg5kxZaSt+n3/3r4Kpy1BeTxk
Pr8rgtRHQSY/RPESx8pAsqhVTJPFNxjAYN4w8MP/df7EyoAH9rgcCUugen1HGPGJ8LNWriTdUMSv
/g/RlCiFFHCvCyBUL+Ny5xC2Hmmn16ikX+R31GRes6gxwIVt3jM4y+UQumBxC/yjP+vmYdIpsl0v
TIwTEGO6JSR2eCnmIDw7D3xqaUeGWS8FDWcBtn6l60kI400/f5R/qyeaKkScY+WZ23a30slL+JZe
KWSBVw0rTTT7xNextZhVN6YEgPg0XNkrle/Sq5/OkgBSjfDCXQUiP4rWdpdlkD1VyNKHuU9wBYvq
DmQHECFX+b7vIXBMzprN2LuRMom4P+r975asT0GVpuzdXan8hM3SwfURJfKxixKCSNh4Q5N/UWLZ
SwQ+5brW69lwCzAjmG3ZGQdorIbkbdjE3GkPRvLKTig2QFNcJd3eK69ZAlwqp4AFx506lBMtfpvT
LCK8Ult5lWcdm2BtnLEiliJ2kNOpOFKk6zkanvz0/hh/iJ38MxPn6Qr6z4fjrPCcxO0LVFlJ23JP
J+Td2sAjNd5p2ncZ5baM4/CmGE+iM9kuXBFcJ0//JAn9GTiAiTiuhCFKnZwk5oZHQlwu4uVoEwlO
ABWgxEZdXXRbQk+F6C8/xL4790akxqmRhbulw2Ft6b0QC9HKSPOkNbYoC2lg708HjQ88u9kkg9bf
iEzU64ky92T7IR/mJw5DJOFbCBahRQZ9yDCMCUeIl0PYgG6fcc7X8obK5oaR5aPF7Oq61T47Zwg9
4aYQwzbvBkb4sgovuIdlGWW/BXkfqLbkaY2UK3VYlAdKNuWWk1NZAzY9hAPEmpkoT79SpMk8SSRh
jKKAj24b3NptXWw8ZHrnDyJkb2vgIYekuNuGowmtx3Kq3jfx4mkFLipCtyRgUYYzxnyJKfGx/+cy
3omxdPT5Sd7jhxPC1wL9zcUI/s53rWUzlwcY2GTzW5YnLd4cXsUdMAeH0w83K9ijYBTw7WZokbAB
+xeevM3Wnlwk1cLHJ280FdRmagx7ENDym0mFzvzVitdsDYilrPnOAD6GZFPJK9YIcKVcE2SmU17D
zjeoyzsJtBQi0y8faXsShXV7LEL6yk3Q0krVE2PqjIYF8Oivsw/bxwBWRx2iEEs0FjrcBNXeXE4C
Ew4wLXkT6jDvUgiaaq5E1hG/9V1GEOweQd1XW1xMOCpOqYROenfrUHHr44CwafT6cVpi5Ie9j6Kp
y+wph1B4kHPxOWpGT0kiG8PpKIyzFkUFTZKQrBUg+4pyGgZE/LLt+RDTYIci71mvN4hC7AEHD4Zv
A8Dc2P7Ye/D6Iwe4xNZ/nLeCqTGYZkfYYYvQ3drLbEWxlWE6Uqw6A53Kf4XpMh0=