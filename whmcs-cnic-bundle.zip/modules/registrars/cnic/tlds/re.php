<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmbz9qkJw9jiQhMoQ4F3suqArTKiQS32vV+lJilg1zrgSSeA+mW0Iuvn2yKLu6AEiPcTwcMg
oGWhX6eLl6YZ8PQ4jP5CACn2zDAsts2DflNQ8z23Y5wVa7YqDGPm1dB0dZz/XrccHb80uleTJMK1
66LgAVWchTzwthFFoH2zitrhPwaYiUekFZP41aPWANZU+VNadqbbcMDwEjBnolcELRRH/Tnj9fVY
QUk1Tfrt54+xTDugSEg00lWrg8mz9lAcdYyjl8ucrFo54848Sa3fqXm74PjQQrJJq6ssAbFcPrn9
eTc73//rhTDKCKQek9/7bOB6HtTXhgMN5blWRQKED657CRqvinqnfmnMnhKH8xgV5wwIEZgz/T/d
jN7JDytgWt41QtNWwxNte9D8SGpEPajU34gBZUg1p/lHHAztOoxEXhc+k6v3BVLQlDiPqsp2JNt7
D8iR8u8fOaFatuUQ+AjSDRi86GwLZDLabBrSSWE8LhPn/q95co+F1TeFj+LYDNtwSxMUUvwwnaAF
OFoJpFVi1V7bAYplaV/yDA49xFLoul0lUdFRS66DZa+FMuuTM8h/vm8IW6S5IDWgYuLTRNEeviqa
D6N5XpwwmI5u9s+LB1E9cFqMvRlIPTNpf6D5gmw5Cp1B/nEcnMCSPK5dgegCiVtGzyFkCDtiBo8b
FtW/QD+fl5y139lMRjNdRt5Z77wN4Oz3XCM5jbZJYnwHC+7RUEZFaZ92ZcNZWG5wCrnBbZJz3A4K
gMorznOcUWNLzosvVs7v9VSBVqAkC11b2q/n0M+JB9whSB6hv4PCTJ8mtFZzSHjhYjxTgXV6SBuT
dbaoucvv7T4fTW340MHpH+OSgALPp69EoUvGMNN1Xh9UYo2UBtgzNw+qX2Akzu5KTpNku+CJmP4v
dKVB/DKM7PdINgl4gy6GgAxryCKEHDJaQ+AVFdeOt5KEYxEO51ZVFQG7W0k+0RZn+lDOMzzrXgfg
CElVs5KYQ+HEMJvdUSuIy4YYwGbF8M/rB+6mHfCuU7aUOUrVoVfp+fLgCTnqQ98Xv91nML7mqKal
0aU2T+blq4JvczURWoQQtdJz82iLLcZz7vCLTmHCpMMl4MSKFLmBX+OAeccy6Mkla0r8SDTinRom
vLz3rWhbqeqnLiYZAI2WON+IQohxul7iAKYqLhjeSbP2ZCrq7ZyZBcuHvcQs0km3hsDL92J95mRE
vtFs/uJoUvTh9dQk+MTQ0PJV0jZFp9jk9rIg8nDkN8hJUHhUNedzB04xX6sAeB+w+8r9mrUMPOYR
RXpeY97q4hgFnosQ1UKiZKY5gpet4VLCtu48myVQxpjz5Acx3FyxuyeoiYp55BinlbKwG24q1nGT
7XqTjoVOos3pH4W75vNdTv16VAFK0NJ6NU0uMX4P+lCAcjr5qJzhsHPMrnf94E7CXAisp0+YUPHE
r3sTjp0GLKXiKRG2mrJxK0dZKmNlCmjHG5ZuWX124fv/fvb0c3Wf6bToSPU8f/Gnwm2o29DeHWbb
UX/urSfSM4rTPWyUsTktMyMJ3W9wdYpL7URpoAgjiDfBqXBecLk3GymaNI3WcUxCnUhOGU86gQsf
xqmQl89i6ROtb5qccRC8AMGFz1BIxaC1T7BKyhLnEpEoMoU6DjZnkgTHhlMwYcrW7CqSqnAlET5a
njzLuU5ZECzpdHy/JXspmtyHxO2sYyDXtgjiLQGsWC2rtrO9klITZfoSR4wZ3sNaryqGXOxY6xs/
hztatbQz48u+Ma2eqlxtihteaw0fC8aH0sUJd/zLg9gc5RhIv7Po9SFdMhBNxlQVSPZOFLnP7zy4
kH4tDsbnfsDmBl3RRqz0/B1Kub79dMO9gbKqiaIXY7u6wknLrhZqK1r37wCJ+UEEn/nF3u+JfNTX
jWwhrAUP0yriyC7JeId3ZwGRFwS0+20x5G+aRpqw67J8V97t2E1HaTOV6wMwmEONRcj8nKEjmZIV
MRfflFtUlYfUjtgvqzNJd0dkmt6V3zos5dj9PBnRLGor/UQ/s713wrL6UxGo/rMj26oEKVUNLX9i
zhY/SPNI8hOk2AM84qUZpgytBpdyG3ro946mCt85bHqtPyEUK0koc8u7nuCH4MEpJ1vpzOkM49Kc
0WHmegfyWg9oivpIBZUTMecWaoCAknGxTcCPI6g7AhMFddaKpZ0rlXjBI4r+YAnCZXgSU9bbvklo
owRc5N9AUWF85AoykpsabJ+ErvYONDatI3adUJ97pSbsYfBofROtfkoNEtMcTh0vTr3sihGBPMgg
dW/bGm5o8fglNNfkt3fXjGlXBaowRMYiBOh9gLXVqAa0H54MeSXavLwfPm8v0cOFKoPWAKf8qd79
X1B5sSMEQFafy6veM3vVvBD9LJIcp8v9vaDl05N9bXUVpthS7YLuPhEgUaHVSD6jyuMI4ZtS3SWi
OV/7//OX2jHrGh2EyNaebT46OPFL5EWRmpslj0DVCHIde/ANyVz024E2D/naBgSnRMRpsSgtqXYr
jIToJCl45mbdo0dnrPR1IDbbSYLrGiuxNBzLiIY0WVzllSb81zVxEkCYrNs0685y/RGBfuf3az5M
w/s6atHK9beG9yKJ8jvbL71HS8vqsRb92YjnwHZYo3ItXwdxcYHzT+AIv63+sYpm1uFydJDVxANV
/CjevZq8jlrQGYZhh00NvAooakEg+qiTi22+54jCIzqMbBi04+MAdZ4fuTCAWZB/G7tCfLqcc0Ph
RVLyd9+MYPKvV4MMUX2njKrhGaEbH1PSZ6IMyK77kUP0rurIaZH1JeT79N36835h9rDYPLXZKIeg
5v4EOJyoblh7K2AqAtOwvKyMsmspDgsWFeb3NUjtb1r8xLdmUVmXdhZ9kqyhhoaEUxLiO+kBG2nX
xiblG+dCOxHfxv+JplpXMWPdDB7gRPRbuTDr4SrnmyEx+lUZ2tRGWnmZPHsZAw2JRUeIyzSzR9d5
HyZOBgbNf3+hIhvLm2JvhFbdhvALujQ7Y5LuyK2jUxvJNz+r/8NsBepw22+WC+nGEktUvDzbR+BL
OAglKPAadezI6Zff6bhm1Nu4/p9SqJPiI5q2DYHPmk5U/o3/5LkORBtUM71YeQXiTRgclwCX/R3r
gY+a27BlVmverrqNvFG/hFOZVEE5+dYRTnxUhVu0t7ARK9s1nMvbSjowu2C567AyFp3R4HD/HREU
laRUGZjVpuiZTtpNDIqFjB49Glvp18HB+3OR4uC8xeM0o/DQh6aQ4YPdhHI1mduucJ5c3bpL0WqN
/7IBPb1Lhf1taUdN+/JP0EvwlpqGHax3OKMY1aswevD3RDzHJzrtQ+RAheQARpEEoEdyxL0+6blO
MzmeSv4sT3DHxkAaAUKJVDCYbzgbtNVNdLVHLBPk/QUKVIyUWyWGAz0c3PTy4HSkeFSt/OhPK0/D
ZJsuU6lMVH0NIUGRx6+MHV4erwjz2HR/dMnzxY8Xe7NAPIi5cxQr1dqt4bnywKe5pLsz8Ci5kD7K
/WtQ1p8I0qoUZFy6t/K0FN71a3IqmFUvJdWbeVwUqUWvqoYTPcEEP4vFyKQgardWoRwWFyVp7xPf
CYodByDH6m/nrBTe/UFAAYInJTo1ZvKivN8sA6vnQ4FJkKc2sdBbUL23+9BqWoQEeRLY6bOAq4of
MClz2rIhetgRUUN9vfLl4gXWsCRf7BZO/jN/LvcyxsGFAQ6HvG3c4ddtTwXXQW045ywTAvq4EvPY
tuf79nWtMmr5Rd5puttAOBJn9jFzy1yhzygsovnVQvRT4Ml274WWJT1pm2UQASs4rTXTD4126qHR
TeF9M2SkXs17+FgrPhSbA+lNohdWxLn7uLo8lLv7yKb7aWFLW0QeFT5+JeasDDygtNJD6s2yrnnC
z1D8WD12cajytpROQqpXFjCC+FH7uv0/XIGwDYvMA7Fi19QZeo41U9JP5JXBzstoZdjcV2S2srXI
y8fP0YJA/3BDguKSAQl52U8ckvzuA8NTzXphys7Ka20u6FGEzomJcgJygfaZv7S6yp13EF2HbKLG
CfE6mham5Chke6stO7wub7KC+nqW7IurGXXuk4vdlolJSSsG1nvN6QFrDDvYERcehuDDTG==