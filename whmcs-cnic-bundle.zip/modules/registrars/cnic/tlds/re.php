<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwsKkauCDXzXoLmlRUDsH0xbofPlvOZ45VLl2/nypVDm3+ELso6QbOwgN7sftGcEx+O0GKQ1
uAOmObqEHNMI8+/ek4/yu3MSYBNpfQ/jDVmAxnC6oAd92mU/7GopR5ZeHz1pTzIIATzPvwFQs7zy
y/aamDieQ5YXIcLEvPJUKW6g4jgsoD+9Ek4dgaWqEl6ebuE0Tze6a1YE7EKY1ePYuvGGtGnh5S2P
MT1dzCSjUti8D2zLh6jqKxf4AAX4ib8zCVHOSi0ecS5h5/SQ9v2j2HIeQ9bvQO4jycQbux/MOUVN
5W77KV+QLVlAbp7pUiTkj38NYZqBEXEVjSJaJEpyxwHkdtUamde/j7ifw8razGgGBdyYaCGIhvKL
/ScXWEuAqFi+PjKxU4iTVj6oISYcge1ExWHEAUUvZDs8kBaCJDXLXrTVGiydLitbkMQ7aD4Q+sL3
qEtoHXUulGD886+ud/tHilxRZ0LHHO+ynt3TGiFX94a+hNBcthAl7WeVeTiEQ0t8ZvdEFQbo8N1a
zqDLQtmSB/WTTpYMSJhd2Rxe2fz+gMJoE1yPNdKv1y1tXTwTZiW9y9yw6RXRX31U+IOQse8CJ24B
gSavV3fp+2IZqL4cRE++rVaUApSZrA3Ca+noiqCe3CSSW8KC2GigdpJJjnU0p4Oe3oLRTaeXrrrU
eXLfJWIy+5D5LtBAmwgb+9tKQzQuIzVw+rImwXz9L2A+tLqkySVnvdKd5Jgh7bH3zrqL7qmpCfDM
072G7Fu71IQ0utDriVptzGE9DcUnAWkxSoC1++ohhQkkIYXwkgfBpH7X/GGuYYRudEPpQu4/7xBI
SXeMKERx5bE5MVxD1PvLD//y2kGfw2k3+G83f3GbUanCkI0sSRG4ImiSbs64Oz4PlhdDGfonqeuX
gXef2GyDBxvG+AFbIPs3MGw9Dgls4MRrn4URJxyjLNP71+5zjJET4gPraN9JapjP4j7KV8l6Kp/V
WXrzPzULH8nLX2PaN/ukWBlUphU688QX5yPgzgdZnXySQEGx4JFB08sZfuwiTJfMR4v9I8D+x05C
JY1x8R7Y3yt4LDF99bJZYPrJyfnG4xMQiJq6SHxXpfgA7RGD/MLdFcMQVZMfDEizYhTVJU+K1eQ9
TvhmxT5go5KkCqejZgx7ZQytVnSmL5JbGnjhUcUSy4pZrNO7qpW0oVKKFnOtgPVoOBsoZx/gSUiq
9Q6mQNE0WYe0C/ACbneflrY8OulNFaSp6nN5+6B/fq8djtg0I+tAhyRpx4iByEuHDZSbHIOzn6v1
sBNymalXP2M/rZ2FYyurW/fMY7uGeLDrgIjfqPpkztYvg0NI+7DUkN6zOjP7PbCvY/27ocUx6Bd8
T+4OACLRI7Qae/ZwFV6nWllAoLGSHgKqjtKOKiZ50tkD6sUbvdFeof/KpW9xcFbKVXpQ6aUHr/oa
dsNeTyrZfN8BVtt9YmWuUw5h89arYXZiyhk1zjoMKZLn0K2EuPLdM58xCouTi7rmxcesOYlUngow
ej6YkhEPUhVafMAIVmeCjJeFR6ue0DSQyyz+s7w9s1rWN6pXTd7iZUnfuuEqSff6vm+iJ+Rdo+kv
rCMpKPrq5XeQFl8a+8xl8M470ESm2reczloN/dz8WYqd5MG1BUdmagEtBXJGcUaTiDXFrv3Cj8Vh
KXBLQ7tbLHrdOr3L9rhqfINFyJO0YiKTVee+8uwOxAfOWrJHA4kPte+YOVdl1bZ2GGYEy60nOAO3
pDqtJjP9AnDqH1trGrso0+gz2r4iX1AYR8DHnTmeSM1Cp6Z73Wt0KGUSYAk/N2XF3cM+eFLs1Uwu
lk1gDyps6AiEwURUJPUSaRPexT6YoUE91V1PvtVTOllFOLQJ+O7vWurm5Xucq823KdJAOdHHYvIr
A1639vMHi/vo+2awsBLFruRJPRW9m9D20amooRFJ8/Yce4PYOLsENbbxgjBdKUF/vjV7OFfE/DH7
bV3KmkF66wuUq53LjdoocxP/oUBNpc46Uo7IuiLF7N0oAktELAyqAJyRx1B/gE68JENkktreLmHm
1SYtUregzV8SIz/Kzvn6otFVBeliUFpGTkYtl7G2T+YCBCIW2MySkE/6Jv7a/ZhKnwu3ndyB8a9M
RPbYUL5Yn+2FCbx2lCo1nj/Zcjknu0bXMt1KUbaKKTUg/M6DCWi8bkNzKR2TanblxoMkxAyJFdUv
29hz7ahbXMl7VMuKMl7r0cgBFMkDJywFcLyYKK1vA/7hRt3jFrapMRx3XibbfjOp+X/SpGGD1ILJ
dOZAntqlMcMHL4xGNelOSNkfZlDupWrAPo/7p3D5w/IfPhvIJ/pjiXjo9shrcQPt9k0XXw0j5lFu
UHku9tzfEVSqvhb3BvMUosJg47IYww0n6aN4VQXMTHYZQlSf+pzsm96vZkIwrYOfgLDfxQ54ZJAL
EnbuBjodao0YqRoIs71TGQ/7Rl76tGsudq4Ohhd9eG6redhE3+miL/WqFZhyXrylLe1xklqYUUZ6
gu1TR7xw/LtlkQkOfr0F8TibzPSD7wM+RXqcgGBzShqBb4zx4XvyrdcZmM3lqv6R9N/G7XuC5Wn7
/qXnmnzyaLLvcSvaRKnHy4fHuFe/OaTvyxOJe2BvEqMn4i55/Crc35YhTCjcT0v3b7bGXIGBD9bu
T8WcT7POmnCBqulHkkX8bcC5KTSXNqQ4Ul+vPi5KwHazWwbQwGkKLXEYYTs8MGanXJZJP/0wPvK8
MVBJ49g9nd8r/tAoY4byo17FqUoLEaxuwRNpxLGIR4VNk595rtG8J9I7YEfLuirRZbjkGSOTyzOx
6wU9iU0LtoDS+2uB/fvpSMZAWg/iTsdN5EjXl2NZBZNih/NV0cp4ykNAo3LrVeGQHR9EdOsUKF88
nBhTReKHs5mTBYgVGMGAp1Q7raQSrDSv1jR6DQ/LjjiUybyZ24uW7sPa8N4GXpGIw4iZg+ddjDyY
ke51JgLmtL37d8/gR6Bi0qRN+8oR8vAti/W0egxehq7/YW0dL4Jvr5kdWsu1j1yeovyf175aetW+
31/hc7qznnzSII3xpRwKpuOb7eu7mpMGFgbQynf4zEixnto6r4N/Y3OscuJpUs/Ei1Y3k61p9xPE
noco/0oWYWjYClUrKNMhdXE4QXOEp2FHqxHaiOlP/QExv0WO0FkwAMo0VPvEGJBkLWpIsNd/BH/T
3Lmi82ZD2S58ZkYC80KlajGJpAfLsnRql4ByswMlJuPwmvfon+T6exeFtMczHA0nCA7KegBZrhKG
aAB0YSNRwG3eI8ThEDE2SSsIc1kwGSeZ0nTBncs8wGAXISlgN9OUbSO9pCvikPWvDhLIhwJp0jtA
+Y8mfq0K//PvOC31Dysk444DjA8Ka+TiCGjmkFKuisxXFsHsraxnEdYKwkjq0ny7bTrd45hye+wa
3uJG9diYwNoJRmPYot4vD5EFocduH57uYkzHq3eUVs9CsgVPec0Ovfei+D60uymU+rmUjctzMDZo
FRf6WXffNGvT5gCXDWtwa532MFGaZCoiySs0TFxUihSvbd9Whfl9E151hRPUSKg31XwArmzAx02f
rwz5Lli1auTQLLs197BGcs2QMFBMAqCbmMruHOyaICMOzgLaPcxBKUoEwU7Tr1NRdTHseZ3K7spW
IldAqcjDddfz0RCgGYE5GV40X+/HB2kEyDRUsqKUCN6E9hq/6KclTFtLo8OcgQ2YNIpyV+rLhtRJ
UFCU/YlbaFG9d1ufAmZEg3sKXOmQ32OzY5lnZCp+uxKinouPsPkGx8rRvJ+Morrq2ITJ8LbRPnEV
SmcO3l6frVycrU99vGV2/6cDa0h89RS2VY6N3rjhbsBfOGCHMBw5XpNVkBJWr+sZmQborMmhGsOw
UYXXEiK/pXhYnjBqerfhP7HzCXyAUfTsq6fXeU4Wf1S76XE+zQXG/H/BK7oTIlkommlcAuiEk0ec
IZx3iKBzqGhHavbG3Kh1cGlSRxjly0Z/i2tvwo+Lvr1lLml/Ju1GzXx6cv0TVK4mdTf0J7cv78A3
rVcq5kewLbes7f8Bsy91iN1XfThnTg5Wcj0GwkyJFMYFvlp2rBZ7Gy5IJi6aKfN9P0==