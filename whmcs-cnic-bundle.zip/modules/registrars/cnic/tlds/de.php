<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxfFeRHPgXcx9FWqbuV1kotTE+OGjuEeOBku0qlP9IvqD9KASoc1LV2e4UzstzJ0ZOzg3PO9
rzt1/uZqRzKsYw0KWidksdKCkNLKCbp3t+vAHXhKoqpZ4stDcZI5cgXxDUAotHcZ6iUEKpB6PE9g
bTNA2bZTsnPJl+WAPISiAudJvf6WGPybztJl3Yy8UIaKZKLP0/YAZeJzKoxpIHbkCsEov2UlvB9c
oWpqGjSIIPO+CsU92HhVhYeF6VjPun1DwImPAzyM9OqV3uQwVOh17D/d/7nd2lstO3wnjlasY4sd
dqKNuen7H9FAnNdst8gkLZF20+mxvybnOv9WPWr9Tmoy+qQsHs1DtEG++NXMhp0kIICOwic2eNoj
rfeBPzLzGznng2dtE/AGVaOF4RV3U6vILZjpVhuJkr55SKkDhipms0izbL7JfHiq4ECMLpLmIkxS
frGkyjCKeYrVjPAgDv/q6Sksu+pQni95AWZTlPeMUYNczLXWfkL4Nx7RVh+nJhBKmS6Gm0xTkegT
JLVq4BRLB7pJKmkJmGRY45qT0qU9kGCxOdCc0fuIRv2YV6aXbMZnKFS35LX3iki4sV3mDxA0PuKf
ezANsHKSVFYh3cwF6uNaFyX/oj2nJzKxnrjhk3Nj4NnQ2X0uI6ldI3POCYla4nX8eo9KjlIzHBcu
5qMBQ+HXXwJlUEV2QIV7Vx7W0YshMydxA5SOQYHXS1BaTsYGCJa2KqIPyN9H7GWRbIAPDVcaQatG
1NMqzyDR4d4RlnnkqhWj2MnZzACBtGRtKJwu9Z5zWOzc482Qeayoic43V81VnR3BNNJJvrNQQ6Xa
J0FgerwVqf9aX9zciFd5AQG=