<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsqa1PJb3/xRy9EGjsApeRGQuK6YIe2cnUOW9UXOQvJF0ZV3CPPPet/i7vK3XlSRo/3EE0Mo
z85PIVZt1fvHLk4eyxgGOrewXV4au45WKeB9G1feUcSo4nuWiG8Sz5AHbmH97wWHoleXuKKgI4DT
wUtZe8y/S0VB/1Xw7KqJWWsxDDm7PyHUa8eUqP1U39JmjFpJqNY+uvxEnUIfjSWjqz1brI0G08yv
CmOe1G4Gcs35wRBwLFfvcmisI43z1CcJ6Tvw6n9otRQKkYsGIYej9Xg4jFuuH6R1VbH/hctXIWSS
Ggt5HcdVqhBVl4HGpXBjP8IPbjrXTpAsYowUOGb2ait2oJKga5kvHq/YDb6ZFNtYmUP2SKZEoVO4
PSApVlEmglPQGL6bJVerf7Do5lDG8jpFLK+OZrvsPGkxUf4lc7iM7OXZbiDCXKSOfIJ486hGx99z
R5W8hFc4kr7cNlQXeu9s81rzFKZXA+QDIMBAhNRI442ESs4WkXJ/qxJxy3H61zydOKr29rGaLqI5
zMyN3Js/qVB6NYkO2qyplwWsz3BqA1PTQBBn6lCB1zJ8ONS+wQCowddRWnvLFoQM+B1ds4QGq3wH
0ubUTnylCr444sWYrn7mq/sgITzy85nn6E3nGI0v56zAM8exCMbyNxB13LORlYDFRFFGz0VRQ6g3
oCZki1B1k239GCM+Bd+7vmhLiQKVQ/I7NyrbValIBS9W49ztrK6cIvXpeqwIbpM60SerP42zYP8t
g9dJSXDcS/5uKiblfsjMOKAFvBxy6qrppE2nXU2HmImSwv5+9xmR3oan+tDEalAdbGrxquu/VzLD
qWQxg8n390T5yGKtN8sCf8l7qWC=