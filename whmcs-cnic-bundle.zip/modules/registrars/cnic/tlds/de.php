<?php //ICB0 81:0 72:c05                                                      ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpqerNW7yor/tfz0M/rJH6JSNWGh3w6h5DjRQWypzd2IPAJPxc2yM2lureTQNB/2S7bD3oTR
rNbV+TBDg254Kg8MYWhJIadHvH3TD/OLHQ285GIolRH7c16VsClIfGBBHccxflF0ZktReB4q1T5C
maI7zgkRcQnSwe24G8y59LIfwf22ix2KEDWXRl90USzAZHu17wcyw7oyudXQBtyIw+/5FU5DEHoJ
AHKqFYbGhSd8wI4TSUVmMNGfacOCnhTQcADz29ozeuuvkKESI2UgrcpiX0ZrQ2bcPm12BVII6lLn
duabKSj58JzA8bMP27DgN6Iw/wgfINRRlTVURYQK6kAQjaEA56lQBZ5EDtnWBKDzu/Dz1/av4F5J
kqFPmZXXdzWSEzFLmSAxTiba7vHEmdefRI67iUKdlnml7sEHNjl4Ba8CFzd3GE6BYtcaBER0vdeA
zY/nukAHgyw5pcN+rqTQERsy4jenZURsxDkbjAnqynUIgsbuqsdxSJbCSvDG3hMLM61ShCKmSXkU
uVLUNf8kBrQS/PzCQyry463HZJNFnxCWwM8sfzhd9ydyuFQQM96SFY9h16RayaOjux9uOQfd004K
yjqjaUGR15U3nrSxE7fViWLVdZbs43RpjmfeD2hpliYMd9/vhjyPQ4ZSCk3jf9L8uscX2fJ1s79J
qh+Nt4ZyfUPSj0PAn5oZ7a5Zy4Kv374Vj2UzI2PqPL85PEpM2z63WcIVfM3t4iKdT/WIpDFaeIWn
FS4+lO6GVFTKMKmzcY0DZBFCjIqagr5uusFY/1v9cHTU6PmlHS6WbYnz7QsIyQEN1svwN9ph5/HL
V0QUVL0E7bZtjPpK7wSVJB6O2S2bFj3GlG===
HR+cPv9IftiHfXjyxEmoMDMiFOgxCDuuZ8qJGzod6/W5Bv5oqSZVc3uPD9vF25bNAv9t25sqrWQw
kepjNjM2ZHCLAMPphaeuHRjQLwiWRnHIk2//BV/JhVjyujOOrqkbOJGEOKya/B1h+j8en3y/BNXR
sx630iHfg3rsRhyIHI5lsjRMPG3t6hIOPllU89RLaB63J8+zb/LanYF9hQPpXINsGGg5sfdVJh4J
P8EY7w/XDzJkwsxp9nJWUzIO3Bcs8aUB0Tkk4BB37Wn682uDVHsf5X5LczzBPZzLSGvh3Xpi8EaX
ngyb3V/Yjva5o2V0nx2S599abXvy5PLDbKRzs/jhk9H+HfpyAjGIpGn1pjJeAQ3kMSm1+eoO+sVX
0e+l7lnXp1ljdXMEU4QHnA5zvOqZPRnePVKUhqiYKN6dkI3q7LTMkKYTR8jOAw6DOV6BFnM3jo+r
9+bDAUGRv6dI93TMuPDqz4sLVlQ8IwXDVVLrf+I38kBbcbK1tfCUSyeC1fUnbNQwCEhD2zN2sSON
vKas1WBKvU6+8egF/6h1QrISLtoq0wlVUxRL22hyasC7ewCPadvC2RAzQ3ABnaJjDTvUr6xxY7uY
LaryU1ySqwavqFJ8d9OCbC6eFtzGZGaa8mo4+up6ESLcPmqm61dm4keRHX/Zx/K6YRsu2yWKzfY/
rWxOPieIjS+u9TK7E/2Q7MLytvNLH3c2rD1WO4HsZcf3MmUpjYcItAgWgei9uWp046E1hPF8cfmo
7iIyD4F3udpo9WOIKCgwb0Zy2yCE8kM6Bq8brHFHLTXlPh3qVXd2IMPP+f3ulWvrQhgrKdmhK3EW
x0K0hodloQQ2oXYJ