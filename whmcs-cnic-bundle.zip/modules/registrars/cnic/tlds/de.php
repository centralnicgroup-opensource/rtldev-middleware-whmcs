<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxvs+D1RtS3d8i5jyvZpe3HLG9OzHeIUnx2uETKXikg21+1mMnrsM/g4r2mzRRuFjUcA694I
2tUAalfmzKymyYlDDelvwyRDZy3/7MMLdchsWtx2kq77a+C21imYT/Z+vO/Ea8QReOqcuGTz/Wt5
Fa/UV1ascEe7XTP0vnVc9g2I7rI68/G26IfRlxmjbgasBwRAWYlNc5mbTPAuTF2R4Rty5vjNv7jk
IZ6d2xLopOrwaeKzjeKQuztF1oDCYsXiuE/Bgu3L3W3OXwtmeEhzGSlm2P1lGe0f0YkuHovOu0PX
D2SVhNy1wv5Vgt50DSpAUvWNGLrMx+g/96NTYkC5lYuaPkL6NHiQMg/eGHrvwm8Lc7E5AW5Xxv/5
7Pqn+966ot8x02znBLaKvyov0hWmJF94Hcx5Of40Cdv9YoOB7QzqKgDz1vsPo2jnqGS352tE8zxG
Msfxgrj/+GxYrplGQJ2Ie7cH6N9owMuKLyKtYU6jINYz8jy+C+jkFo4MRHU9PC062D/cKkivv3P8
USC33N85dxS6JdnPnq0zpCDTrpQv2ic4Ojbwq/NARH1xPm4WtclTttX1HnTMCWBb3a6MTd+fuV2t
SiVmUYv9EmMJQ5rRZXoC3VWuUxFyVAu4mE8wQxvrcuRkKmBtooesnGusgpzx+YQPG92rFOhUL9+m
xyyRElv48xZ3KXVz4XBmgMh0o5fY89B4LfcpPCzBn8J59g/wYXj0M6koAEi1STTcYt3kw6N98B53
BidTU+YKop3a+Lz1cy5XN68xmxg+u0oAUOVFVkkHazKrGTXZ4WFoYBpC9sA6xUXlS/I/kNhK1Ju5
Ek2QqSU19e4plAtpXHsg+iQqJW==