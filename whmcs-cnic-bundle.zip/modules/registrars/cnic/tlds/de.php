<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtcO3TRSO/OPcI+OzGXeUdDEuRBkvQo8U/slLLvWGB2EAAtCaphZ7VUzttwfbif2oV192jdd
H5AWBadB6LjxeuhH+LoEZV8WvKM/enlzkrhOUR3opPKPSxKT0HRbPCTT+PrR0g9vBNKOBqrVm35X
thsPE7w6awO41BijTbPzFiQNWUwf3p1Fdo62GYB7W4oc4U74cbBeTjyZsexDEeNOY5PDv+dGBQMW
95Iwf50sQf90qb1oo1fMgnXjYJapxHRoH21Kl8ucrFo549a8Sa3fqXm74PlyQV/mqOmcXUxLA+n9
uVP68MI8cXqiJ8XGxEGUPISb0bn+0tjkhfQyCqQtFffydVp+7CRNVGh2R1yXs9j4+zUJknrxrP8f
79zla2BWEoLOpcXiELZMlwx/8VSAY9YXEiZfBL7MskrgXkklUtjNkhpB85odEwAJWRndcc1OYY9H
u8k5beVf4BzMFf7ElWn62yP4TE1JVjcEjdzjsaidjLbaBAvaui7s0fX0SE/bnP9Jf9zzTtHJPs54
8zP53gHUJC3naTYPSUhjwVA0e36Q+KwhEZg6W7CLltKppdwQTMjr1nF3zJs2V2p2qlRkZJu8NKoS
SSSwRIBWeR0FMFe5j5Fvce08x17ht19ezWI1HVeHHyVnM08R4BmZr/QPohQYsL3J2bFVTwcR/NLy
6YcVubQeUZ9//+jCxqCuJlqcBKaCmKf2y5uGERV7LZ6GjKI6DPjAlbsJLcjSsGNPEfdwBYtV8Hjq
vQlhp5IlL/E8atHQsQMgMX17TymS+ADt00NKhbHp5tvGZ1/JmCtfbTJQVq6Sp4Ndza4oMv/0ilWH
HxdmJ3xng6nXOh/UpOhj