<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+jlVkHooaBC2zZhn+rTD51vHYcsXNiT+vEusbGelLZTskkmpjc2EufUBiCBDdAGOGJMwsru
mVUpUYyS5SMpp3B1meWNVuE7blOADGpSxgJa02hPB4eG2VZg+gaYjaDfnUJVghxYfJ+3EsFhIloV
Tzqe3yvW37ciqvp9mgQWfPenJ1U1hdLd8o0FYx6bXX6uqyvSXZlPMtP2AcUbwPzwOzXKdhI5PTs3
DTBqoeva4NmdDAtZsZ6Hy0B+uZZgKs69f4oJcBlKA6H8ahe357dMXSM94prk82LjJVqjBQQXRqxo
vsLHIpCs6SoY9AC6QilNTZxfWvAZX9EaknyZzY+z5dY4OxOMPPMiM/0xZ9MHvnT4MPLEBSlxmAQg
SZAgdStUJOt45rNY/6aBNWmf3Q3p1v4TDhERs9LietawsHuYnqrBa0tlIqZkK4ca+PnVfYepVM3h
vDJZXl27Qm6f4XejEZP360EhhTQzgVLCHB4LVlOiBgLeCQTKp6v5GR+GCY9THFIiQhyYDnbInuEX
FiCiO4CEINtBZDThNg6U4VwN6H97P1DJSQaxtYpe3TQmxAdQSa7bXg8FX8O4nYQkAJhxW3Va3v0c
2LG7c10E7U6Pd6JgL4a2grph1apCTpPavjwJlUwubRl3VWeT6RlZGAZpcQNzwe8jbiDKpdeYSk+b
Hju8E7jWsVsAxYHmRAv5yAokYSCz2SZ3bv/yn0EGUb2DV0iwBuxrmhJQumg9vx1yO9AsAnj1kADm
jmHmjqCPKvexielimem4pIMtwLTAPMmS47cl0XXvP7Q0QDpV7NZ768QvR8ywUqPVLkpO7NrWCtuw
kMBwmdxXYeUBuB3HnHU1