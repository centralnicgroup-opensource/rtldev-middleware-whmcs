<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzF8XZ8e4ti5DNyJ4P8cMEKorbyGDNF0TRUuI/3STUsLmMkSpRQR4KtwYF4Z1qjept6VMIeZ
Wsx8Ui0tfc0IbsVFjh4Om9mWVCDroRfDsjRqIHvTI8CZTU8r/TMedoDSwgcreiT+2b6yYmq0ujHD
SaNqC2Ixfs7jmGnJibmaFR7RUdu7ienmg4S0HVO1s8FA3OvGDRvEpQNrspRpFHpaVquM3Z2MIWs9
MSmBiLeNvf567mdqkQmeHnT7WquDoiTBn56UNazPctGn2vxb75HMiM0PiJ1Z3EaedOlDIpGrDzOs
/6K//roUyKdNGue8V92aN8bEjCP1Z0cVcJJpqZZekDJ2gbGBZNiZoqRow99tQJvzFIPw9vPOMCNS
25044QLCs1xHJvd+SPtH5CAo4oU9CMqXxSZWV3lktvzQfw+FHLDD+a/RyKmme1vRWYW5MLBkWSRT
caABsIxICg5y4v3bAkun8J3o1K834iy6tCPXnoHqeX0Gec/E0tr/lQn7ACm5A98wTU8YwfW7RMWb
k8WnzPFwteR74Lg741qbaZtqVAvltwQfE5YOrRZzb1PqNp+GmDJnhAc0dxJL9QfwA25XOzWYjhbQ
1G+tqbzxT7vMnVA5DxgVuya9O05oQmR4N/cbIFtlz7AExMJGZaB2RjnL1AmXuSykhB3OvfzruOmB
SlpD5CW0/KMkhFPESGfngQl11Leh6mZTHkHXTx2iX2UzBo7zfYGje3YodeSBhAFgFKcpT4RcMo8O
rdc1sPVnKVFpZfXHmGiMAMUz4+t2boJ7WuEOClpnRvzUFw+IXj9jTdDHTCWffGySu/ea+LS4ItwL
YqRaChVBo8Pn