<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvsTEqjdP81iVYgkQ0BlT8JnuDbcGYgXgBAuzwSj4GOWo9bH0TcHX9lHqOM0yQthQW8lTp4w
ei8O4cAxk8wjlHZAf+XvHqOuqdiHHtTfTmY9hzzDSSboD6J73FW2Hc5/m0FOOPxT1emJ22sMejxw
N79K4F05htI+Wo6shY6RqjPR6jmweYuYW7uClhLb1sGrzWN3oAEAANdjA6w055zwfuouAOGmNW8R
Kk0X8+he7BFT/BARW40Wrud7z5IGyRGOHRGAhLmNTQBmEO+CXpAnqZy6G6Pa3xZQuQaA/rzswiw7
q8KjNX+x5ZBkWZi9XW9ER2x0HxYCxu8AMCwiHvn5UU8EsAebHcQNcvcfpWrdqCKc1KHeVqNUmNgr
I9qSXjgXCknLaQHyI342ZTr5scUcoHjidEsGeL3soxuYjk6aVM6yGewDkNYWNfxgbP2dHQMBC7Or
ow5rlgIf/I8733DUNdNNhHaztMt9+kAKIx9D+RHEIxleS9jfU3M9KTL2k8TwbggPsEhBS0wiEkaT
P1CgM785PUpLmaYP6q16LFJyD3lJ+V/EUKbg2HsenHD3j8SJ/LfFW8XdQsIlmy+PJuNuU9/ax/HI
iPJ9sfEVXN2JoN54z3KZVYTcDT1VMh6W4WLYaCjeyqsOP0A5o6YfbbC/fkcGUC7l2h/rScqxoHiK
Bkxf5M+eHN6L9fuR4mjCfB1OdbVSNSp4xG/5jx3Qtc24rHum5c081TlndnDaw+5StiLN6Sf3AeS/
b8MFp5x8ttS07BTDhXnXYqbJ+33n8goqQBH5fxg9NM4i5tEmvQOc4lSvE/qRhS4WDH8MDE1IeOBC
4mSw8b5AxscRjMx9PDu=