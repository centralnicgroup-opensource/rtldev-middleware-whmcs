<?php

$extensions['X-AERO-ENS-AUTH-ID'] = $params["additionalfields"]['.AERO ID'];
$extensions['X-AERO-ENS-AUTH-KEY'] = $params["additionalfields"]['.AERO Key'];
