<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPot9jAIw50sBGtaXXukIazJrNMAFxdxKxDLxtRrcWUUwN4p7xL6gh1lIrTLtFp/Gx02a149p
Q84BWG/1HYt9BHes6iaY4nuubr/PMXKSKLnLjFjK68nmU4sGI8eZtn4xPEtM5fmU7vPj99hQEnTf
6s4C2he3cWKPhjZTtfFGzdSiDhFUAf6IEJAvpTiEgLtAKV+Bc/sAWJl3a071JLvCodftWSSGrBb6
MON88yidEjNink6yrBIb7jvf6MdtaURmLqzvi+02DTfgzXmHIR9xnA+jpR81lrDfJHqlx7pkfyQl
2zTdNmPzyAbSq/OA1rPUqBPw/CLKaIIykvv19hR1Cc/6NtLvPCw9Aku8NaOXjM6NcnLeGzYoEym6
E3Le67LVpaYfPFz9VKj1lA+aqcYPUKzOPoSKZbV6fySb2A2Y8BKpPysb3q28EXd+499fCWxvzXbQ
f4hJ9MTlq9hUAX6ah8YTxudRZxLQ0O92dmZRhJkYdwKxuKrO6vQ9I7wqPSi/4t8n8lEwAWBfjNzZ
vKblMQw9HmT3jM4zL7Zfmrw4J5hX+53RQTNEN4FEUE7Zx+Iz/BJwGfuBNRyC/e4pVnyVmcl7mHf/
4C1dnkogzphQkoZLG4xis7bWGvtCSWqhwQoec+BI+WVF8Us5ajq4kAPNmYgCtCgBzEZxCv6alHY0
LYrl8VOovqBvieTEidMFaD4kaphdyONtVu+M4LhaS5Uqxpig39t2wVP5Vg6vlWMlgcusjHCanavY
ZIzmkGHcCbXmBOYmYE9ADhwYPJwd89s3p9a2624Yj5pHAyZ4NqhZBWlP/av1Eqi5o8qU/dWrOKmt
9QQ282xHuktht9vClZ89FL9wED8BNWbuR5xpZgGB98y7X8a4k6xNRDNTSqysYlusW9yEtnE4CcL6
Dr4o7VL8Fg8ilgn42oboPxI3qB0aRpqeDI+VFc2ZuakXhle8UD9owhQ7jLJqjpMgQEjhXzafYS8o
Zl944og3r7c/H2f4gJZFRiTeIIBwmwLXBZzsVVm4GIDWa4hvFHtuK1w1sUNMUWlEYDHQPFw1A9oG
PkOOcyHrB8gAsz9L98qPB+Kjt4mLg370J0NRtjp4M8qPeEzfnk+0KpbQ9bF0ZpDRI8kQy7xuh3ye
jQfTt8RazL+nfjHc9J7lsMgFaCFf7PFjVrwDxtSvQu1/wR5MAes2jU6K4+9saIatIRblq3ylxkVh
pX4o0bE6SNZCmjVowt5EiCvsDkT355N5hfDdUSqM5o+KkTbkELV5Arz0G5+r5+FNi2Atc7b8ABUK
wDMP0d5vFKEFd8rPYMhZa18Jrlepl6RcFtSgUcwTBfojJQotqXoiW86O/G==