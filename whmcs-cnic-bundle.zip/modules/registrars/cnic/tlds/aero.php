<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz0PMO/QvQ6WewdCh47DmrZj4dJkgB3PcifvuiivdVT0kIi+hWIoUHB+SqpJukZXXroACX04
Bte2+eHLXQidyerNNsbbVLDzBF90SolEhKiT2rZDnQ5DwtpGHF1BuGU0bU9X1Z1idbEntV0+lGHy
727V2/8B6jJedUFG9G+lhp7cQjTugKqPYn40Yiknur+0ob6dlyeW7kpOKcOaU1TbrPAt+et++uMQ
UWOfuTYC7q/Lp6Wz94Iq7SNNMJWRxcUilQT7oogCqcm3OFKWkVcQOVdaRD/V4s+/KamopHkWqBhN
J7UjHap/SXbUSCJQyCM5pYztnBMpx3e7W5Z4QoYV29w5dDxCxMeQ4tvi/Z/FWu0JEJEopGCn4VM0
m4aWQSKMvyGLYMsRkPV+PKjEJkKMVC/y1wGlLOW9BaC/S+bDfNpEs5aqKqa8XZDLPGbk47CH60fi
TV/cWHAgtjoJ6djdLou6Nw1E5gMCPmq6vMERl15wp/+xRpPFDMEaxpWD/5CmuC5oe5mdpgU0/nZ+
FNyoyVb9PCGMxskxSW4sN9w9N4B07ZQFSIT12NArXMjQMtTt/N/n92GurDKNNB3vL3KaN05aFgrq
U/2uiA6zX9vscNOxHaBJwUgvOokim+m+xrDp1JKaJFhwMF/Y/8RTaKKFRDf0pXa9uSGURpkwgtwV
t6i1oOOwxSCs84llmcLzqPYHuHuFS46b8WCZrYvnYxm9hzNaouvOdcpZb2vfbZOCczMXTxf5cEFJ
+CfQ1PQYuog2frZYea1LxcsjSpGPzo4qzPXz2gQVCKSkm8qteHOzhP/X7zvpzLBFM2P/1OOe692K
R1jys3qexRxsXlXJeOuM/W3JqirYwwcOiUmxhp+M4l0JRDov6pGF4k4gK7Ss1RpQaDCse8uetMu3
YzDP5iOhg8ZYlmcBOAfwG41SH/Tl3ZK/erQzaZPvQzN8PpNVW+/MMi1/OO+Fdw/FQRI/TYexMfNQ
C87l9AG1XvXMNgAVo44KBco0IeL/8PfVnssAkdGMByLrivh73zdwFRaUHT76rzii/8khOH4NeUf0
ENdVG99uh7IE+yKNK4LyXbjniyimJnV+mAeCbvj0cYxiymOSsZfy5mQedSBxowqBheLQWq+egPjl
9gaKCjmCTN+R+cH6s5OuShAaYOUOXAjN4JyKpO7t9M4dxZ+XWfMJ/i1scFZIDho2wqAk0F7izdg2
rA0OE81XyltTaeRvS9b/nluvTLgNdDTCWOPtRjCXP7Tzrfyp+hGMt/rPbD2+tRT7IFWNtUktb2dU
CG3YCHRVhD3QGWqwMQZTXTac43tPVHYSMI+LLMWvfqgTlFsj6u4GH0==