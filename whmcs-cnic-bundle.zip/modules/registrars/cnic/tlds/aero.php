<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzPzGtobmRTpiCtMNmhGMHW07hf/X9mlOk02VXBPLBIun1E6AZTFwEtD+gDTC6Y2zYjihBYg
xb/wxZcYxeeVtd10SKeWrNiWz10L/q06o0NzzQ0WaMqVBC1JT1yK/mEIM5YCaMZrEpan4aO9qQ1Y
NfoY3hbW2pInqhxYWXmn4Y+OFzPttX0qscVk5+4fRDJAsBgvBzvHY4I5cfPwTCVBJhAX0P563EKp
/dUEciGll+qszZk2GnYIiqvp0ZC18pjMH9g7c56jN1Trel0vZuo7Ch7IFmP0BcKlCrq1i4crSACl
pcV79dGjn+cfTFCDTmCjwqnJLNkY2eWtVejuE3S0OGGjwYWrcOVZNXNEfOFK+/mc5C5hb81GiSmJ
UhVNIMkGQcOfuFLuC2e+yX+8qagNSdFIfAZAJPf7fVHkSQNUdZFPUpNOWPph1lLP00KMtiPuJNfp
++O9JyH6lCjguYvCDmfDMMdYljKC0V9k/xgIjiFZFMqzK+NPxoWC9ZzRnbw5T1kIbnvU8//8TRuo
7gBAO4Y3QnY9KWs9e6zg2SAHbCDPa5d9C5P2O9c+inHgYqanyY6VUtmkNHkfnKFIQcJSW6v6Dno8
b5gh8P3BM1zAf2pACP3zk1SvZ1Te5nQBYW0QMqN40/PY09EldwINAFybChVbeMLKKlT4OzcbyjAf
rCFEmI17Ix4mRaKd6dT8enp2HgiO89AfT7FJ7S6o0OIGgtYNPllAlYr5aGAA3jLQEVGFFVJ9ztl9
aQfNBRjdfKa+xKMsWxmVxSF7T9MB21LnIt/b7pzsKQS35R6wcEpgbG1r+QQNfJliLbUNph/nfqA+
yw+un+suV1aVnQ5Qc4WT5OmsVZx3VkQZQ/Z8qLlglfJv+DtU2wUA4W6FxuzLwTW1kgVA+SehV6JM
q7qGdp/ImNQ8DWvX0fd5BcvBJ+nQ1WBP8seb71lYSbBjL/EOYI5S98BaoUz3B1g9RoAJSjEyfH/7
XorykUcrO97XGTH76CE3jYAaXHTgb9FgdvHBih/RaClh3EJ+AeU+02BBy/PhXAyDxrsK4utk5yRk
VK5OZPfCgP7tTrWb4qNz/LoDWFKmZM/lUM9FbayeDarQWZ06EZk+KllYZx9O3QaLN0vMtTFGu7JP
Y/czqmRj4rIAxUqwn4tjGFDJ6K7wXuUMAoZKZFzkY1dP9fKwXQbKAAwVIx0MMve1ORcAh67kOZrh
PNq+6WWnE5jlQd79d2sM5cM0AQEj1sKVYVhI+z44In/E3/w8DvO2a0emrNltMHxOqv3bJ3BXCjnf
CExwPY0HmFRhVkBWundC8FO6qVGLGMR5WbGzNru7sDgqO6KHd6dDafAvWXuXeAMZWuPJ