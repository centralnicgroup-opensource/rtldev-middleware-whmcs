<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/0Hp13q/JGdWQ5PCvfToLBRYZGRrs3qe8MuO/1dEbrBsD/oP//4gpTqrtrRQ7hNcd73797H
Q9Yfv0aIp3dUHfXR+MdrPBa+Km0hi40h0dZuBL5xzW/JlGig7+ejTH/DwVNbDP0BbXEakjiJG7Vh
fsJLhvJ4DlrBvIShHZb63MS7Ew1s7aDkG8tZHR9Ma6kNsdK1Am/oGbFLsJG6VYVAZ2Xt42adbmEs
bgtOn4yS5NPdnk1RAQPqwe0nuZNGueCSUOBlzJ+PedukJPKmH71Gvf9HSznbU4RNCkgrP6SoTpgj
V2Pn/yc407hYwVKKNAUYJNKhm3rIgMO/HFWOSIxO6zkqQs8NLrLYBHpPsEwClcZtPP/5lTWs8kXW
oNpnhXLkFvfE0uWDN4slsEFb8H+VAAveSO8cyRmkQRU8J8DzeXgIrLyRiEO1eyaX6wDW4o3fM1uG
E4z18UsLaZajINOqCWsHtFWPf8bYGwvBHCRE8cc7UMmG+izGDdex6OoCprg3+HmC6mk9Z36CwpXU
nq0ckGgfiUCCKTxWnAZ7d7kFWgC4aGI3LnaSJsu+iR49Y+GecsTGFwEO8aN51lmZZQoYY3Zp4Al9
P6usEy7/t/BPveOE+7G4pqmPhdYVoDhukc8Bs3+bFY49gxByN9TLKwNAWUrYyvAOoLZGCn/BhpO2
yRrrZSTm05yE8LwVYIb3UVOepiFmURQe8QGPmwDmejf5vHNynMqaES+wyFRtC1f8C1z3IclEt7sm
doRpC3AOrSywJuXwcu2rBThR4NPVb3lO6xO2hRUMTbxBT94dlUvJJUaM5DpQHpVDn6V/1F7M6lYr
U+sxzyRidu0jr/DWYSgc9+v//lG0t+4iohwug8PTrxkE+n+wgfJAZ+vapaQ8DzH+RrjIfqT0XYS4
+Oah8A5VavfkDrrNewMEjofR6/Z3Z5LqN2+AM0VY5FeU0190PKIz/E0dTI/u04f99dHvnIdqxPJU
p6xljeAUKW4PHLWgzexsW/v1I4+DIA/PFgAnOd9fXOesE/xy4227Cn4exIOjc6Yi9HWVxYWceBaj
MPA2ERMZ05OEEd187Nm9bt8NOZk5grQ5CSfRgp1fZYS0JvSLXq35r4xtXNO6efQ72FBZPWj+BHG4
YZauNiINu/yZHzTU5k6N/9LtTLCuNRdjm9X7wUd0bTfX/yvCDrWlTI6rGhXg9m1QAUxZ3+J3WKC9
3kYbIhsacOwQiA2ZCJlIaKnrL7dnoMLm4+8dsC1M9d8pKRWr72Q5x+rx12aKs0UnIK5rbzYk+Xjn
8YZBl0Bk0qBgn99kAH6egY3UOr6LPGUbl9cdaBroFlwtgIzb9Q77UNaW