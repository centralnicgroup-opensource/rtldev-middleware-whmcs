<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsschbvTY1EH61OxVL1K5l4pfViDfYPBKAMuVeTbM5eswHThh0A5bBl9AX4rpCHQeBvbVxtu
ldjdwD4ENwwDMB/EOR1Eq9DJ/a6VqQhT3MmgTjP6eo/BwtlQQ/SUUZuEHMY/jeSxn2IK37PMKzDB
Shy89qftdZxoON5iithQoF/cduRvBRNRb0NgG2N3dVlEbUx/MaUMominTg9rBtsXMEMN5JBravYp
7IRmmBmn9g0fhNU37HDbugZU4YE2uPgZC2pRNazPctGn2vxb75HMiM0PiS9dOQAuFcV1zLDGcTOM
r4PP/w9JtOi/7Gly8Ufd/ZPC0JksMlwp2Fry4vpdZXSj2enxN9ZZrLNsIsc2N1FLhtwiU5dsNMdI
5mZ97qX3vVtMOX5hV6bAi1aa57F6o1C3DGofDHFrDM+a+sOtZl8fp4yAcRiEDKycBNo6LejHL01W
AHOtlBpeaNsb/J9u3vmk1SzH3oPed2WbiaHLRo9O0ra3mTff5pXTRJ9ZnwkNqbEvS4ZITaMBa9tT
4tSf+eUbvYBxT16KVpxyw5kME0TFjnjd/UJJmWCpBQWEcT7xSRgXVODgYZ20l002yuI0+wlA0/8h
qWKMQO+Io4fnUqoPdG9+CTdYuH/W/x+Zas8HWrePfMIF7ONFCq8NLxUK3V2UFHH/4bmMXxGCKe1y
UdjSrWtYtpRpdRFKXQOLkr6SnRxbhjUl9BAvckctCUe3/ndBIwDQyD5N7Y+JaIKmLxtI7hJZY3i+
YK8xhZWYSYMz0NYRzi1xgx77EeXSBEA2fzeU8w2QWIUi5ri8kKQwq0xHMgKKRnCMMVmVl0AwnnFi
xSjSdeE4N4SWt5aX3fP2groFXgqKQ9VoVzF8EPBmEHRL027LUkAxa1I7vLvEdEdaKGjip4SbhtMh
ayTtRaVafnotYo4VtoiA+dw/dm8Bh7ovaoRhFaO1nPZvsdGcVYXM/JH79i5+UXqVa81K+6qZuEeY
KSLVc+93dCt65ByFrfS50stS4uTcMxyvvap7DoHaNzzeEAFtbziY0yhr0okzc2SjCdUsXaRByTzO
spPZEjUnZtY32A6SIFtXcSe3UeF+Ypt1iqg66ZAgnPd+7ZtzIGnQEqffrWUFTopFQ0ZnZa2BTL8C
8D7gcE3M2maPuyu1QSF45LmeuZJ0Wj4Yqi94QLkLNQp1TiOr3d95GiEwmaE1OZwLAViMDQbeAPoK
MfQKvsOThgJFX8jI+631mGJ34stS8Xk5J+ka8C/FBPGcApSaaul3QWPUaUZW7XLjHNtgAFGAZyq8
Xuxb4uOD5giFSvhjizI5i+WF1bS2gSZnhcMb0FNJsj8SgPzmrkC=