<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPptEoqwq4p1XGNvURK8p1MslNogiphEiVz5uiUXdFLiZOzdVWHms2JIhSvGppkwwlwv/1lP7
5dT/A3/7WQzBYerXZifAIaHK70+GDExWUrMdU2WajYmu4PYOgHUCio1mSfxz9JiOUrISdbM55hCQ
Ivzd+XBvGdKrknHvkOk/B7BDWniFbTNy9OW/zdb7WWLF40wppIZUOaPU9lENHPpiRdc+jZAZHwKs
H3v21l3oO2JO+64Xj1qnQH1dHTu9lnPWVfgdhKndKVkpAfdJ8lgJLkEpV/sIGs9K5M5e4cDyjBzQ
p55AnqB/KsKtVKkV1rwbx71zdIYUGV+bOPrOMOBj/QC7DykcuNHjcRsqI8dahVPxZBeR3/5rUogL
CCecPqU5ws/4v+smggrlFV57oIugqgaikiidQAE9SGBEIoRjv4CsGcD8KaQgMgOOsGycuIOTeg/e
WaBbD8X03Oiptxz0tsvx+2j0KHWPubeNYsjRhNTYHR62rVHshE0FbQUMifW0zfi3PcdY/Iy6oNcs
CaTgeeAPpbPz9WmnfxGZKhV1GJi6CUjz2yQm4ySiwVqLGFw5ykgxpxi2niDS7dzOQAjVWjOJuIny
vyYpii8qvWvyE7fzlTgxQidEyZtNAmMVMCjbPJbXovOR4l+a/bBZinOxk/AZArYFc/h4RIM1GbXZ
w3BS7GyBFL3gT0i9j7cUHdO8Wxu2ZjoPonuPDDXKNb8eqyYGYPVuPvcAKjVg6NF2zlkJmCZZYUqo
KMG8xIEjcd/GmFmJ5ucbNvrUnGcWi/rp5xoMnPaqiQFEvkpbfDE42WZzR1ncYiOJf9E60GC+ipIj
cToVho2JMwKFK+Jw+0HTyt8/DO8dX4270GQq9GU+FbdJh2VXQWCJw6Zmxdb8oAvcUc2vWgz9blPG
CGaq+3dTvgq636wJIANnrIdo+tipFHM0kE4eKE1s93rck6+PgW5dg+FH1fpybiU6nIMCMlDSXJfv
bhM7PSL4zR4T4akWkMhyrpIiKgOirLiPidrTjCHfc2MYpNkODz39Ft25bZdRXadzz5uqiFVGkQhX
OebO9W0L7xN2D/ukCN9Km6QTbMjq49OWXxDhsekQEq+TRvmKJASEiq4w30SYA6W6xOk2n5s7PgpP
1wgLd0cuJ29qRc7jEA/TFvF0+bDMeLhOLc7J51v1iFWv482AjsG76UVmC2fP3AOsBtnNnqY7K2jz
RNXwT+xbfj7Z5F8kaFPU8kxmGC6rRI2xbd3wbvbDkxKO1QFlH+a/Lgd/fT2vo0HTcrkgtDuOlR/7
3NN7x9GOIMe7jMnjAgGZuCbTVKQy263HlNPzoOK=