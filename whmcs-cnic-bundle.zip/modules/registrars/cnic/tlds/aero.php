<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+BCQMNL5b9Be7pyHg0eHcy+0US4GxrthfQu81g/T71azMK57CL5BWs912QyyfBpM8a86uXY
o5fE37LKBHhnWa4ADtn8RKG6Bztw4mpUrkfkeyLrQr/o+SYkfrdKMYTEmnTL8gwPhvC4qm1Cuum/
wQf6mAe/Gopy+/yG7HEvuaoX7gN+TQYpRQLgjdfY/tTfeRL2VCsabGtCKZahmtXr7XRs9ZFGoLfz
4GiSQYnV6jS5uq8zP7GqA4rPskM+G9od7bGRI8rG6HoI3gSU9NxHfA0EL2DVrjrV2deje2jletLn
tiLI/yYfjaMyrSIkD8//O3PjRYTQJIrGK5qII/dr3G4uDag3bJhe/CEjG6FENub/+o1vlHkk8EtD
2hUfmhp0gec61CbTdpB1FyB/9/V+O8jph6oi6xM4AcZAJ5PF6sf9RM1uux+QOg8bbpdQ1SnrsFGO
kzQHVeyCSHtcLNhJRy75v+rai3foIwdv5epmUKGG3YUqWtBvkkAIgO1JIrlMdwpRuTxzY8p3USnX
kBHZRpYZwLMPTPG4LS+FXXKsPM3cwl5zZ9+rKHObKxaOBT1pn+GO3YSwf/OkBj9SvIrkbotZ6Jr1
GsBIqmvKS4jf0TJodN66fEGY7WC41X1+SN6lLuBG5W58RJc5um3nUC0w7kqJ3D+/OLJgDPBVm+Hs
S17EBFcCSoS2KdExHi8djAAOyoH89yWLMc+HyZPkVGOKHVuMv1zOIw80cm1/Vy11WQuxjiY3t6z2
vbna1PQ0K6x94RqGlbcWudo200LkdS+tZidXIJjty4FF2XbHBQ2NGjg+GaDG2VmiYOMDlrs4Jlfc
v3UrSKAr6TpOC8JyOwWr4btjIZuW+YdE3pxzU8eMcBqb1EPUYx913z91UrmPu3T6UQme7uOoJ0Ey
wq3tZTiGZoe/qDnaFbLSS7dNGIf82KiukwHoHtuEq30tyQDADUDKQql5TOloTSbwU10rkY0lvPY5
snw2tF8eDlc930RGxuGaIQtf8VhnnN5a1dwpiFT0H6MhgO/YYEJu/Al7KTYyrJjoCFH6hzuONYgM
1EMJoVi8Z2ed3f6QvP+Mk3iz492uMn2zCDDpdTBVOsFtbhjvgw8ZSHh0AoB75DR0W5GKyKX6xO7M
k8TA9t8ZgJyOL5QXg9gCUsG6JnOg8i8ONYHkTE9jUGZkXgkTMJd4OzvkvIsUGgImSMjfSTS8Ov0T
26v+p0W8plwizhD0pFPXEKygGP5UVF07JCsZid+lRkABm4vGpn6L/dVtdx91NV5CC+ThqLRG+tgL
CI6xijMIfZIaa3yt6uPqkdqc2VdTFsiEa7M+B8srZNSKMm==