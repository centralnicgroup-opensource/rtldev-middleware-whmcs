<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrYkeDbJS1aUAXur+gftNWJ3ZSqd5Mf1kUGMb4ndd0KZjeIRzz6txDowhMv+SKAjTk4WoYML
urTALmZP8sKogHV/wF8+lUOPmqzOmBrdPz6mMztU9xB8BXTotWFFTPxQyqjIO6XFYZxw8KxMzNbh
owxII30V6xiz8q9D4RTOwTOtYYOPrOqw9gtPqNGJDbikZnyXX7w9VBFJ6VmsvLg/Lb7LdvuiUe7p
BPWRulEbQLXZs3V9Mak1c1nRkiSuTpwcaako4Aa6HCJbVPVNPnWIKKGpvUxVHbHebSuF0DGZkU7g
Oq5D0APA/qYCgsd9+HD9i25vTMEmeTQBuWdtMUMZ8c1T8age9xxaBnL75n31ck44ST+mV5hTXQv+
ibYMiOmjXSCzjDqF4jwgHInMsVKo+797jssqoqc38q+9Cxde1E6kixzk3MKbewE4bo4hkjjVo4w2
cUtvtyhxezLyEGYo2HO7yCpZ0qJE+33y/w7U9hji4U8JPyNPEiWerD0jNsNfnIHeE1PtoTOENZ5r
/MG0X8MWgEsm1PNoTqN7xZfy9tP4nSbIewiD4IYGuZLKBFyLd2hoiFhQIDMiT/6MDOhZmRUCCBfS
RQU0G8Pt+Fbzi2/5vs6RC4szcLpgGUxfZQZ0hv3WUHpt33filWna8+GS74sJeEZKzGBkjRj6lsrw
BP0cEdzsk/K4YdenOsLMNoPdTOeVTkuwxnjSkpbHvE7M48XZ97KEK6A/O0eZJp34QLZ046lpeV9w
x6L0MwRfD1TT1bH1/zah3FYcnYzoGMpwC3a8xW+/ckLkac5t02idxfxUugP1MTkHMSgavdLA6hVe
qLyN/rbr4LAkzEvwXaMHy50Qh8vrh+LC5dIPNQdmw7Q/HZt3fz54scFbRkkl2WTV4gNW46QRf7Xf
x1IUxZHyXI57AVcGdLSNY15r+3X5IxfT3HgTAoE5puJq3a7vyd2vrjqV8kbiKABkhmmbycSWf4JX
O2TW4Z8Rcu8iSc/hNYJj5Bob7N8butxySz4ntYBjxkFwVuPUZHUHr+GZ/YdmZQ3orazNEw5Tg+51
cFVpRyurUbTe0XmXEReXql3I3VOVp2s5gEHPvVgVxh2+UUpn1V1Eo7zmwlGtkh7234lOAWOtt/Ym
zSdfXa3pyDcIjZs8nHN1MChW03hcwlYKYpbDZaFNFRHAlYK/dr9nRBqYC6mhFZWUrZGY62P00SeP
6kwaYMPeKopI7HS/BLKIBMoPkiipgHr+LYREC2q2pLtb6WSn4MRFkQlK6AyHP0YP+WRt2kgm50LF
YAW06dyDlouNuDXOhTr8m/swd2XVrRzS+RDz7M4LpgjwMh9TWZLe