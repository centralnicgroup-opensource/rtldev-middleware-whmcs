<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwXClSmwbWNZm/mexwQgbnXMPZ0QjzMTyRwuFj1uuaHIdkTDakkWHxjhnZb8lvzclOPbJlgR
UJNTe34EwhaXhWUJ7gqdDvgmAyQCzikpqy2VIBp9RTGrWB8Mlp0W0JWIa+fGyQh2s7ZRaI1ZICDW
iSMxoTvgcfKNI4lTrmdkDOv/jjA+y67Agssgo3r1ecNZUw9tU+9a+4Cr29AKmrWGw+bhbcmE2CAg
ukNI5s8TXl/giWyDYvQwbBSFqa7gY1DYGQphFHgssC1YTuRUSO5ryYqJAhflmB5iIN+FGAVNBat2
oCKZ/yl05bfteYMiN/ebgkQBcJF5J6bgsXSYX1wdLsniVzNqquJKlFn7RBOl5h9PaNFEoMZBFzAz
m96CGsEmNKXrTwGK1qSrW9WGfYJG3dgl0r0XtSCfzSDu0262JSSHoIm/nvabvaTp8QMScouWMKLa
WWOEGnArHIu66CsMP7EZcQgdEs23/DzR64M7yp326wggUC9IRpNLZftqrBMFqokq/EUz4JqBjiyD
MYFd1gmu/jG0a9Am7L/2u3RCnofc8Uspv19De8qbyrIEO//sSQHBKG1auxnbOwyLjtFtlt1yzovP
2YwZpBYHhI3F97jXz/+xs5D7HpK1rd8pP6S1lyQXfsqzyXvTcqbS0tqSoTYxJQ4qFhwtHJd3hsa9
uos25ngGp9oNsV2sK8uOxEIBS83eiV409i1rslN2uSd0uLeKVOsUFgVR8efpbTF+BtmUFrSTX28p
jbCjWLnR3p2M+TZkwkg7yn6egtzuBDwWznuqsMuSpm5NNHSe3eub3t4LChSRK/Tk2y2hpsil9BHV
HRy6O8R04UKJ2jFee7orcFwkAnxG1QhMPfCzQuPmW0XTPEKi9ti1+3k5Rh55l1KvqnF5ugQ1lucY
1udfkCHJ2dtKALazmhdWAnUykXw1sxWC98dh70yS6zTRzfRchTvxRXazxINtjPA7eOd3GP9Klfrb
gxhzaUnzEYjMDJDj3Cdilg4s//zjPEzZR5+KHJWjAaWSHLy6DKN2ZxxN3nbeYYXK19bIuVfoPrIa
KOe11lML/L125QR3G4sOzwQaCg5RTOOGNa5wzIJvB4cKagcIPHiiNkQ1MMgXxb9aNgrmCUnywpW8
OTvLXupuzyMATYGo9kq1gu17a1yENhgEeneDRJjA8a1Pa+snDa7Kn4wZ/8e3WksAnjF1qyMZLsxe
/g2QcaFOWknDv+g3g5Q2P9IASePumiYJLOh+YN4YuSeKa6xvyC9713WDVmi0a9GW4uktpauafj2e
q56EN3ybg/ot71MnIVZviy+CdbG6FTmwMsSITvHaHe2CZu4zZPcxKs+hXh4rVyC9