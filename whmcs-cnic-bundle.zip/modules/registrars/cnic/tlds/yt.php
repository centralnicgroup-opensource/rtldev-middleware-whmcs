<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPql+qfQAQoVPKpP7jOG82IjAM9eCjK6UnULIiIq4ZxcvRWT7uzBf52inA6w9GGaM2G7r9eEb
HhJbbZ7TZEc09wqrjgKNfVsdw67ezbWjnaMZw0j0dB0duvYSXfbJbJqI+ng7J7YaYFmMyJDBvEbS
ICwit8/ajuTrUuG8VlxXEyVsqeDe/q8bnGifoTilT9ulWkk5+eOsPMgMx31MYfGGzkS8nBqQ8YWl
vaHe8ZDhJZ4hO8tl3MFedPh195Q7Sjb1QiJ2pxoE9jJyXH2w2790wT8S1n6RQMWi2s8f4acf41w+
IS4TPr86FxFnLWbdaW8PYFjtohSVt7aQg4avhUV4tNolEoURxPHP7OPM8VPbMDHBzzvcDuNIE4yU
fFtaU/sso4wAZ1Yi2nCEG/cHcDq2AcDdolKtuQ7HsbofVv7Ad1MK9zG7q0H1kehGD1qhEP6eCrvX
oAo9ia99VA5O0SHXwkUVHE1aqp3cxh0Bm4r2SOXehuT8iYWF84IPrpiQWrWETG9lgkjkn2R53SEh
8/q/wdfAXYvdxBYR1GH4kNpGNudzz68dH9HA4lkkIb4DwyKoSaLGs2GNl6XD+PS9ktl0zdioB7mU
NChZPYUi3NZPx3Q6+wbBQJLVAZBQm84pTeo4JdiFl7iFzJEKyjREL0Fo3gy+J5eXicnXyil5lw15
thEl102bU+BNM+l03/5Bax+qmaGGECO3cZDzU+zPgWcju+sQDS8GZHHN/7ndM1RZsa+OcCJaUFLd
bs7vcg1/yGv8bepewdDpZcTIuV6p3fUCxoIatSolT5fdH3Qkj1mAnywYkNMjCYJWN+yld4TO6egk
xtV5Jd+tcNULD402XBQO9PUl9GRczf/tW6rRHuJv2gN5hrVD8RbD6+HFycdZWJ3vX7HGxTt1XBX9
N4nDawidFyul2PazjgVSuLRJ2p9DRAsL+7Z1C5s7DH+nVfEICyeagix2p0rpvHZtsXElZOIwVHmE
8lEW3/AFo7zk/bIqVjER6UNnNlWOyrdQWvDObxsd26xdHUZ5MJxTTziUjWtDh9vD6HRqV6xau9UO
GGRcwUZ/KmKw46MY4OqwrVuEM1zyDgBmx3ftP0919rQVYScKhIz1tSuDpwsnBfrGsG3sG2xw7x84
H4nMpa5JQrBSy5a6MHwecwIr6+SMbAHivcsacI6jWJPk4mlSDBi5I+zAHpP6akbSh1O+o507jw2y
dlBhI8+jP/r0GoK5Hjc94+BSrLQm8uj7jvs/09MMs3Zn8ZKZZYG9tpOwm8Oi+uWrVfgAwHOcmVn+
rKIfocM4XL6CcA/ys7it6QUjJ0e4LLBbIdrtzsCGzZDd19FnLPZ0I0jJBkU35Tfu5PUkMs6EJram
ibSrrmFvIuDTBnJnU/8kthYX//GLuig1SjdcCgzxriaF8e7osN+zVJRHVLyJvBICxrfExZ8p8TUp
o2peJhnRwAxqQYSiFIOeamgS33HXN0ght2zxZB+WTSPo/Os2NPqkzRgr9fTnax6Mo5EZnRA02RVj
SQ/y/2JEAyoeWZuTeb24FG8/CD5cP4rIf87CULBc+BUJ16Doxj6dt5EXQZ9TcKJTT97HMBAV04Hn
s7z+vyQu/yy8TqGSSSc+D5Dw68qB8xjB7uhr6ljkBMPIqxUffb0GUQ+WbXe0ffoNCTzI6Vk4cSPY
7Pj1xhVqVp2mKlrGQTPWZi0bjsnisW5dbfi41NfP5lhfyZlnDyxpNr9A8H7ljga4Fa54wTBv0e3X
wbRDA6NJtqVBJ8/wdkSSo1h73e0924oMpR6MzgLoAjbJd7L1/uImxDPMtJWj8U8DxbBmAGGfshpx
hvFim55FXpgxzDyrWqKMck9fDV44ajIlXn/D9Ink+5HNiFFqpPNLKkF8fiYTMi/4QjaL+QJBnPA/
nkcs/zIvQ4WVZH98+Dq3o7nt3lFJVtDI4V+VbDTNucGZhxiQwNiKb+XGPkHTJ7wWwwQIRERh8teo
nqUxfgT8v7+ieGsc9TJ1TjPgifq4hPSSbwXR5/phdxZ3D8TsQFGYIcAQcmukaedmWMhATl9KbcWJ
17BX2N0q/+4dqhitMnxkoqbak+rqAbHcSe/1PSOhaCDvzhg4XgT21BTlPC0GGGAlHRF5qDS6twCk
wD6UJfzSu6h1YXdbURxWBjf4XSHzKQb8fJDzMnqjlyh+hf7J65D4Vk936jnF/loWpHkC1EXbNL35
z0asb1GILli4M1AuuS65gaWCZoYBsZ2QpbCBjIZrsq0MK+mHhs+/tISff8o2J4a1IBva//DZuMRh
P51QxDNY+iKijc1IZ60MzGVGa4NtCDqqpvz5gm3VDWn4oc2mnOgUS2++NusYnm6eiyH7YY6qfoNz
93xDkAjpTrvnK7NWoHqBdZAteakXoqH8VnI4ZX04q00KHZsPdgoeoP4hR0l8L1iebb7pjxF6db4i
4JFouNbKssadJP/Eoe9PEN3ltBSvn7lAqS9Th1I+nVtHfBEygZ/RVrmjgyOT/fzLlo7O8b6eV1MY
BlDqRRJiktD/zgmMySeVNDAj1FcG6p2Dn2u7of3Px7MQnxU3kOkJ7pzqXx748bMXygTjEU0tOIWg
ZqwTrug20pu/CIAfv679LrGvdJOM1EZq9gkMuI9WBZTei1oxrB+rO5OrCAX8gO+0NwSVEXigI0SH
VFXbL7tAagcDTtCVmdmsnRaCh9HPfR/ajRelg4ESTAqIy8YCZEPOkOLcoibWDjPvaOU+KZR6WxdV
KUOJi2/SSDPFOyv/6XLU17fLXicaNAWjnDYh6f1V01WG3f2QLGxfTeHWRHsuMXwGjVjRPaenG5GJ
neaR8Qrd+FtGsL6v4TRDgNWM/fzq6k+0K6uPJbawR/ZzizOcfkD/u3kyT3vFjmixIMzUK/d1v6Qp
snTtkFF44A6QfbPFoI9lI1K3b27A9L+LThtPmj8MNp4BZJ4bND0Iuf3SfsNDGPDBpi3gyLROQYu+
e4rdmGfcSeN3HDdPGecjzySmbIX8RcVpmeAd374m8Cd9bXHFm8WHJT4cE7+KetIGvLbzFoKZUUwp
/GGEM3cP5K7fDUFfEejb310X9ieiSbHF1WaGu4qik1QqB+F783aL4CVLqwi6PsPNUspLJo7eo9/+
8IY1EgKeTpa2dv13Ek0PzNzaXTILCOYLWaDZR8b+ujOC5E1NaLLzRh9mHn56euj5MNG/CvqhogDv
/8TSf7+KglT2Uq5+MALyDuoEJrKTZj2HrItpM0quXnAFckc6yr2N/wJSQ9SgIVLEu3GVSuHg11Ny
c3xj9KHxzlO/KFoEBP0JzpICoG0HGEwgcY7UCRwC416oSFmLMyTlcoEZyFfk7qaTR/QLECLm/W0g
J/i0AIOf9q+8ExHoFpaLRWVjFhDgceqr2JqMoW9bfXUYWG7kwp304ab15ACg2UckFucTTlngUhKV
pS4xx6xBOsvpOkEVrwvd38zHrnl/NrcNIaLam39x6mPBDiaAJ1Jt/s1kmrbCs2uo3igOdSkSAHTW
G0+7olDpbRBheCJRXmO/gt6Qq8c2BwVf37/Kw7ONnqHIjpMzQ1Ni1583pJHBWtLHR5B3TkX1Kc4R
9vXt0RT/1H2zHpcPaRCrrh3UcD4d1cr/7qjs0Ei0J4bQhyAAD2PWQRk4mNaUcT/fi1OWPoap+71r
sj/++bKP9+1BcjlEjrsovD8SjWmizTuxusKO9At+mlkeOnYkwPNQgSYvtNJe7sk4WNBdJ+0vdvwz
brAQzpHuEEI0/thZ2baRHIHJhpEpOSITL0Vv6Ldj445ygRodKq8IjwfuOaKLrN0a0mv7f1ftRpWx
LvKYLP5JjODPIzYOkzjLGenw8rQWCPoGJ/ix2Yu6ebXG2zdcbYuIW1MEKHU13ubvpUVIEMwfKI3o
ti09dsmlPbB37aHnXHDQaVH3j93UMb1LXr804lGzQJbpsvwzSdc9X+Wi9IcvqOZAmeM8hIE8iyI1
63QEJHWjFQf3jdvk9dLYWUG595LPqFeouq3s4V0w374P3vU2FWoNkro3cpVRvCNZ1oDf37x/fgHa
oMQ4134j/95QryNGfwBPDpqE9kQMkzZbcJcLepbUs9GoXLn6m9gLVC9HIFTDP5tl5gLK8uZ8KFwh
W81AJm==