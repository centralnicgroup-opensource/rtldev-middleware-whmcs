<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmgXsu+M922WRsbEh9+4aHmL7AL0A+UebF0I1VDziZNk4j9a/KA0nuHNGZZcv1UHh7dUUnqY
Yb25YMM6dUn8OaKMXOf0E+DDbXwFmQMQhUTSAEJnQcdQ8/WMWbF5aFZCdmZuJcu4ATtyESIe4Uk9
TtJ1Okuwt4kTnQoKEI5f/Z+7saVHLHRlrDV3kaVsQZNFWOlXXRECFxTQYlJStu9gpha7+VeHGQHU
Wc9+rbcIzF948CrLdNwh1Y5CLoY8oKskVFwkO8766dpVV5iY+qGEdJ7xGhOwLVDj1JawKW8lRn+i
Kis1dsTi/oTxmhsT8uly0WKgIGxzvqIrQ2LzipeBg/jGyyTiGqjAZO87gKEpmnSD3pLQbhDj6+Yn
td9Eh+kNP7TSCOkQRv+41dhxI+rFixr44f+fJqYPMbJFLfq9gCaZyQ9IFsyYJbGXQDP8OKV/Ifrz
Lnyqqqoo6Vi1wg9BlUMwXhblipDscK7IfilY0lXg9mk3uxFIHA6dGDNJLWiw9d8mJ4cx28XHtiTJ
t2USfy6gsPBxmTQ6E0AGEEVjtInP/mymAfCscgOgiaa+pfVqIyaHAlL1Gus2kSYjzHB/dm14MbtX
czHSI1yLEKSAMmHwYjsHev0Mp6KbzgWNkWhDGmkDqQC9b7bxBKywx9dCiu+5qFX86lbmpg/vdZAv
j2N9IMV7aiSYJWskpG7mC+HvWzJsCENyK4lrbGaQ5iN4QLExjSwtEV1iN7gOnD0csGlpiMdO9LIW
6RRJyesQ9JJOMInAiAUSSlVq/Q/+2HJnyciQQVyi79EquPqc0PmzLxlN1wWocUr7WoP9OST05rNN
8fvrKUdPsrI+uiAErS7VejXPhEVijtruStrpNE+PZIZTh5Jhfmq+X/YmOM02kRbZQnGGdMAsDqWC
1q04Mk2K9PAQlb4n1rP+Ry72I17K4siqzehvvwAuo3Vpha516q8Cn7lSwiRWba6/nhEVCP1UdEV/
48Fy+kDtl0/RAw1jG1KplJs7NKkcZ8gibuwhmLsh7FnUtIvL7vKJtxCP/w9e+zOkL/MLUI4W4Sqx
ZubWAd8D8LphTlw/ZoUs0T7gqKMcuB5scY2xQrZ80JZ8XWdEdsCJD+dLeZqina0HfhJUC99zYdvq
odbdR7KuEjqqpSx2T8YEyieTE8W6LPP5P0oHJ6v963tdxMUEzIsnlwBCueu+tG3UwpLc3HoYygzm
YmqzNhVp29Bm0VdRrfCvvkRAK+Sa815KEXC0leOVH9KEdIfsIF7hgFB10To7X7LvbtnaoEIiCCAj
52HZnJFLyoNPQ082x5apxe6JfUFdrIaJ30/IsBZBhlARrML47kGPwQCMdMiFLWIKVlWl2x5ks4Uz
kw7ArslUmyz9Z1gJUtvNCyW7OBtSXM3nX3+qcXMYtKl1S3ykh5lfW9pbrT3pW4Q/HDcKu8dNhQqm
SQtkHStQjXwZA7ZZh8Qzr2dFHaJV7BnwYWUeBhleyN1r3B2vL9IMfSQQ967tvdGTIcCj0MPpXAjb
VsjuysNiM8qPGlRRiydzFTh/0nmC8FT5WvurBZQMANqkqhfDkkHjAnhI/A6+Y/k7XzG1spVhPWha
h3PT5lmIlIsaU+t4a2RkFlUzcnsI6vtvMG6GcMOlC6zK2CTSOFxpzzwl48z3SDdnCzOTnI0RMjVa
baNdl8zl/gB1Ixwm1XaJNZXTz2PFFYZ/xqGRlQdYflhxN3LbYcoeCQk0osSTpVxaSpz38Qalsj9q
OIQ/LPMle6K/MsFEBbS0BGTUClEle/4LItZNH5YKBf9V1zmPwuwsi8JFi/4lQD6cN+DG3vvPfsgh
fj73x5wyskN8VFQOD0rZ2r7koRLTod6ropN7MmeTyhAxa4NRxiUCB9oe0mTpLTi34mRHXesT7kLa
vbDOftKg45uTItYrpKvAWLNV1VINzeid2i57QrX76gVJFObbFynScqj9vtKHRznuKo5gTX6aBlTy
yNsP3AQ+QJH4hXZsstmW7xkgyoFmpRe10oJFGQociHP3J+kZCG2hWU8iOsBXvqcShsYOF/yjCoD7
q15CoRQu/6FaAOK7GANj1Boi0b4V/tINtqXk8JbduclptX5G1bwpXI4iCtXUSNumPe6usbV3AS+m
5cTzaM64z/dl8qCrEYbmVgg7PAZPQosLS1Ga94Ezs55zXd3Hhu9bYBhlsI3xBWNIhXtzZLccVJLy
HlYJHBnRpBna0CkuPlkis4IRBnVniuBFZslcBLaChpTHlStMRt2YIsjE5mLTvdc2XUxLnvdoqU/A
8rynGpHcBJO7zr+qVw/csn2o3D1XAmUxAMGdI9KreYX7NwpD0bImB9lEND1w3uBq0M+3J9WJVTy9
uKwyIIcbtgY4l8OYHPobVxN2uxIqD91M1OMejxPLbYc7AK/uJcsQ2aq9cqefvj2gINQKTb7MtQ1n
7eTVy3t4AZeMjdetJNwVvBVYpwClx3YJHquR5V4PJnmi/iZ4W5W+7YOM3rhP9nnZrhlWJ+dz7v8f
8voDUUpEJV4PZ7tfcBYLKmooEgQulJIRaiLs55d6mR124lbCjbRVvs03gmIxLQOYHfbqOWtwkYdA
ApeW2uPWLAzV3+Xve4PY2GIPjaSFyiV05D4++zBPkYQVmY7va06yYpK2/6Ncr5POGz62y/iAPTK6
XBhHRUs0xxR3KMJmZjzjvdSYmgezJnsUYRRpfnouL2ep1oA69dMTQHieMBcTUyyUrN1m/Cz0ohff
Ju7ohcYNoApfqBo8pRWFB2PEqPqUJx5ym9347XWk1i3/Qk4btXPI6FnT0X+wP5HVpyVIDu/4DNwx
D2gcR9g2PFNgowdoSCt6zneoGDBwTko9R0klEmPqeULDTdh9MKc3cDhwSGijvc+HcHLJi+e5OLeL
tTSu90TI4eUJGDKKVtxeVp/BxHi/fHqVFLUkmi32ZMT0JgB60NhK59R1p7OUqAmF0j+gA7n9aMts
bDDFwcftG7gN6Pg8WVjpwTt/V/d21Ga2BfPa8LeNFZUnXUmPEobknisf8Eomqp8DWQORtcN6IXr1
PnoNotT3WzNnIZ/emprvKPXazMYezOZRNF0i6C+UHbl/niF3kNO4GVpAiY9tHpx+zxD6HblcJ/X5
litc/g6WVboQob0zDqoIMVos/WFH6S+CxJehnSxkPlAwfR6wK/41rHlXRcFv6vxzEY9ZvVDuipyD
RxXzsTvlA+XBhe3ZVRbrBW5Be5cFteL3iGkS0o7tMLwVR17HRVI3/GrO/ywpqKScZzFtBTUvViRR
perpO7mYFMRH4MVPCUYfhCXyQT1aaVPUXyDUlv2Kho0sFoAmz59/uGIitcBpDhGIf1N+rw3HzBaN
3e0HmNluz3XRjwlxqB5Dmx0B4/XHFxRxkZ3SY5sXUxPJAgJd5ov0eyaukm6RAQrFCJgDzTa6i0L8
Y1Co5Hhdo/eJ32q692ubtDkoCS9qQeo9qhx4CMKoTPNzUkIbOefQECX6XCuWGL4lsPP/811kNECW
wrY6JQwMX+lta7LAFt2ZkOEpLdAGFRXloGL0pbIWwwyhOPO44Nux5/qnt6bTaR9trG6zuRlK6iuF
oMfc3ZqSbUXfFbPpfdNSm3u1WHseZX8sh0nEmH7xeN4OdWV3BB5BiYB2ZPN3OH/E4XxRjY5xHzw8
Eh6B4VCw2dNOsyQnlxrFaf7+5MhrN8tKGI1Wm9Kp4AAoLHdAChC0LcXWsHdGk97qStM+6FoJOw0C
4YMgp9LfehAM49OpNew5M2Wi2Cf/+vYWaKzcrHSvn6c4ZPPoTEbPg6/w2RF+NwlNiIEIT2Yhbczq
3JZjbE5OPMOrd4X0ViMjSzK2kXYIl2AEmr8m9LFIwoNduHy61I+l3bhqV0AtxTxJL+3+6sJtHJSf
CgDoGYirum9WPugZvMwAm2Vc4kg9GqaJ+mQ0QyKOXsCLYiBRr5t5ajea1qJLei297u64r01ffF2w
sh44YOmhtsAAJaoa2B4ALYxU30aVermKvPtsoO3DCaTY79SkawjBCFGuRHOZWIwmYksSYUWYiNPt
kVqQndkrJNFRL3kjQDWR10c/6DH5ILWAhUlrGzqZN4vyn2JfA6g010Lio2S/jVw8+X4=