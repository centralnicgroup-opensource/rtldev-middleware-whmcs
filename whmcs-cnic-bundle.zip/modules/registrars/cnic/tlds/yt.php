<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv34GA/lXhc0zWpLZ4HVz+uFHMdzOQ7nml6ARHI0s2b2c7XhAK/SwhsDyeIVklMz45DV4HZL
BYJfhJY77+e9eMQBosh41A8t/wTnDrBhnNmNgzu7Q1PEXEJrn7ZkjIZCfvR6IPUx+DcF1EZ+FrZu
bcTuC4JHQu4jrLeeNSShq4xCXRfEN+ctbewPO3itTwMdthFW1U5dVeivjSzR/Us6qUqVeu7IdIqm
mESZX1vqd7NpjjamkquonM7PBr3kduYutlwsgXwiyuZgqoK2UuO7P9oSIrgQSdo7wKFx2FxrRdpO
ruY7J2GRIxkGqovY4/9Br6Kfpwgd5w5pYAzm/V74c8BDSPJTAMqgLaACYaQXaBCGQUY3AsrP6RKQ
z5IA7AXQBtngYWZJygzSPkiKZSKQgv4QUU18CazeuzduLs9FI7Ht0sFjab+8Tdcd10JtwhbC68Z3
BshZ3NRezOK+aO5tfOgl/r+Xsu1BvHbVAu1ytvODfbuXkqRW5B4wX8y+FTrgxlMbhZdjrP/FuXt4
Q29kjD+RGM9ebMiz22dMayTIaBASyCqN/LQZUP2VM0Y6KIg6Hr4uXPildw6b3svk250KHFTTeZ6E
fkOckcDpT4OnLyaYI+jnMdN0CO7aktCLLIlumKBECLYWL9KeoZjdsGt2C+J8zXl2Cbh4H8UvfPW/
hLLiVycT9A2iOpJ/Eir/8H8pXiUVHG8/OMBLXvYr0D8djQd/+oLSuBJVIKt/U/YQdbAcciSvvad1
clmYupgFs5nQ5VyfI3fL/fWrIIrPtpARIJaCHeeK2okK045Nj1iOWAActswlNmY6ckhw2a6Ple3t
xHpXHGXmbDONHZyRyN3deHfx6s7MMTYT3FaEqy4o9HzxUGSRrHvpSX26ViPG26W+9vs1ChjWDsG6
tSDB6zA9fkvP9gdOKNmL9h0skyn2fat+B4HXScA7eoabN9jy2nPEGixYHLd/1MfJlTvbfsVpkoOw
YrfFfgH8R/L/xXb1ZY4uoUDP/Ko5L1M1WcVf15EntjXEzRFoDPTcxEoTAb98VDL+owS4RkWFlnHK
qvhDIfkiNAHdB7zPOrA1Xn76S6ZLuJH8R5mbU5ju3GYmbG6GPNtKNQ0dANMHLi/JoOcFhjCXiVtJ
N980BtlFNv1Eow6HOtIcxP4NtI5SQIHM36QhaTYQiBFJCNGghVlxxqvnyF86wwwlyVLNv4fJ/Fqr
R1D2htYQ1sPOTovBEJDMQs7APcbdaErKaqLeTtgc6cAhWmX4iYMZl8o2GpxX/PoIevD4yV/OGL3T
KU/wKw3TpfQ+pEKaLjMZR4SvAxmdpUkEwg+tL880S40u9SBlPb4Irq1Lq57iDV+rMuFwZC1jGw+E
CCEBvC6zC7/K1pgSk32MA1WemxLDn4TRIFt4DtBcjq2xatcsGZUMBak36qQ/eGRYGhSxIm/g3zyD
8qNbQY8B2OMVnOwTvNigwXkTyp4X419GigP6xX2i/hr+2NHZcffw5pKUULpE/MbNSVmX+5Rw5BED
DICUZ/Wl8FsIeG3EiUrzjom/YbJsD00fsiH4hADdMQB3ifEe7JBDPVoPjSsC2i80pf80/zHZGw8W
4OKZM3Sp4vMEQrWzVctN+Dbb9tEekNyrd/nceY6uNmhiOBQayeP6HMdGZRPBeScnuu+MjbcEmnFe
oyxqnEtGwwIojtkRQKQodZuT/+JfZkwwKQw66JlIPVSROs06HMEIphmto2xRSlbGJmcLQSsQp314
HGExfWMY3RkT0XgLiUxLCJqFK3l7ISMnZ2l0Dcp8u6KC+hw+JKsf21kxzgLtwh73PrpzLNHOx6ws
ZtekanQtOb1nnaAljDnYQvUhjKpjaW1GQXbcBBY6zCLqZFyYuN2QW4MMSuzl1kBJb0gYU94ldcdT
P3BDiRtyhGN7CAAsFiHEBknBXRb/dL7D4Hoa9Mz4lwJr4owO2ZAahFJ7ToOV8zaJIHq4N+dH2uQj
k6HSW9gBlOTrnGz2NmGGUT93IvixEqSZgktryERN8fGNsIsTIiQW/wa/PwxtMWJ7RgJ6nxgINuCO
J3/6qUFrUNjtKtAi8YnIslNog5lKlziFctyn2tSaqArz5Fvxy482oB/0Gjq8MmkqISU7ivqgWQ5Y
67Rtpc9zXMrdN93pnIffO9IuXRfie1c9uPQiTtLugkVo7896dQAdPaLxgDUXajgSyBW5spr41KDD
7x6u21grWQ7nY7Z139wp53Dk6cMheP2jpGlTyTL4ZjNtrXzyOpiBqqql95opvX6oqneNRLw4dHmn
FzdKiYEirs8bihI94DJlKNd7ceJ1EpTbRfFl198lIh+qNX9bRFqquYAaPFDz6Q9Ev4n3vQNY7nOS
Er2CbUDKuznc6Xiri77cSbT5dSlCJvo9H+u2JqtaC/rZEkRLL0DQbaOS+aaEjjc/EKIOKzvOket0
I/zqMM2uUDYhQBKG1/Pw7J2A5YIWL1l7AF3nrV6g9IHdBe/YeAAlh6ADg4T0XMecqJGCBXcvq/AL
idK8YTxC+nf2gLQsuO0w060YNQQym5ZejU45nEoq4dbetcWoYydnSHa1Qqw6mmD8d/pVj/L8Ycwk
vlqoLRyKyeMFXtmPChaVj4BoTi0UMD98FjBqJbPgushZn3IrUPp4K4Z4j4mzAoSgHEOf8VDtQpyK
22KKyLNmgAISo77zcPZ7qiROqLv5T/NWcu+srYZTcC6QztnFoh08sEIpUdtlfWnRXBc9bPZbHOnr
lMHif6jWAoi4pxuMnfDv7/+A1h2IE3LOzJLBoAb1CKiFHk9z+iq1QRQYN3gTbjTdtoLnm3LTWIOF
3/JoYU6HeAZrUd2xtfPIO8O3BLrGKLhTEvyGfuW5SAO5EZaZvoHPYOBu3zc5elhfvf/JHEdF2phM
afvFCSvxFj5wjhYOCRxp3+BLvhkjhcH/lq6LMJK3UeK6CiuZd1Try1jlut2bpKKVXL+QjY3W7/H+
aM1WVr33EBAL+O4LDgMlmXEo7fMIG44gLI8N1k91X9NZHGsz/aU8P2BZP+sNGNekpAzQhhWw48+6
Mnwu5wrKEKYnJCchEzNOwivBFdcevcUU2kboYcZTN0N/zPTCMm+VfnwYPlwbC6cGNaQwjy+qoCIk
odFZAZBdOMpU4ztqMVZ+qKdA+Zhif/eIwlyU2igE301W/pLDPvyJsyK9faAD2D9zLAt4L2FV4ttW
7GF4+1lBbZ5xVsbb1UB5835JQUdfR607tEblqtBar+ZAAERaVSUMs/quaNSKbqswneLe+Viha5Qx
lKznl6n1vNQz6UJusjHICtmjCczQMkhCBP1AxMdC3u2KTLcVydcGsgmAgXwvHqpAisZjUPaWjV3T
zgxtVSI8Urd4Z54RtxQOE1u6AjJcHX5MtcV2Z46wRRSPCFaLXP0jXQzGA26LiIDW00DjGYgL2hfF
KVIlVl+vLBzyet0xstb0uOcnpNeDrLwHOufeX5yZdej9j1otCsIuWPjamo659zO2Udrr8o0Vt7Dy
BM941XpuEjFvNaWeuHdA/SSfmVa5uJkMknrWV1LMU6pIkBlaDbclLmnd5jxqouOigBg5IyfCGfK2
BYbb8d67uqipReU6Uma2jO5/0KU+vg6AhpXILR6BVmMayH6IMQVRLEOfUmvzAgiG8sudMFIyuaXb
1jFRla/gcfWgacT11nqur9QqXzlIc+95h9jPk713IRpxTXT7RYCkfKhYnucfaQfJJNxhfwr9uuZw
+cC7t6R02NCrT5Wvyyxdp1Ncu1Tqi/3vAE5dX1qS84S9aihYamP6rkKnRTcrJtYHvvXVIvpAk/vb
8lCGcnHBH54fvhPSJQRxXYiqDeMl8LR1rjMBKatO5YU6bMJI8iI0KjBCKvScDtDBgrhiG9IcuC5V
o0RZpOUr1L64DNUEy6T0sampA8WVM2oUV/OWsRnB8o+fm9GsHpbP8MQrEyS2JDDtZ49vv4rSSPd1
s2PoPb8KGyiaYUzCGUst32TimyK1DrjPsAx7cccAA6KtyJdAA9S80NnwEDCfBl+VZXphIUGSM64s
29nlpkuTg9Jjilsn/vvnE2IuwJJhZFK+4IA+UWOXtRw9IkbNDQexSFwGjzU3Ce0=