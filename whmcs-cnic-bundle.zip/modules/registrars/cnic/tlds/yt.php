<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPol9Sh8edKU6DG7daMgKST+dVYEKpQxSpi0ThgeZzS1iN/9L+oq6DZP8nrg412Z0u5sEGKO+
S5BuVC5M03VxuJt7zAuSsY9gBu5S+xpsH6PRb0/MR8NV8gesce2MMHs8Ne3Ip9WG+yQMv6AsHuZZ
dNzEanHD125eN/Q4tMaRBTJAjeo/XESqgaZOC0ch3eXjzVNmIzh0Z1KMEYLIsXCQFhwQPRjrHEZN
YH1B7+NXRlJL7P+sfY2P7S1J9hnnTEhlEFzaQLYOkzGeP4YIkWCKUTQ5nOaJRsf2Mf/56khkLgIK
JcABA7h/GKPaCHxxXGEBhJGOnUwsEpk0zC/bq1qEWLVYPKf2WD6J1yjJvB6Oyube77XJRJHNOqDr
Z7qR+VGE3t/npp56ybdmxAbJjq8wF+NXeBQc/Nwk0Q83C+2cfmUPeE83Pn6vhnqNz3LhxE0C9YiE
+mtPo7b2U4UzsCyxqGuT4OAsmm3hgSbju5czbmvTlG62b6lJLarorqnBfDcaRMVHIEdrdeiUfU0Z
l5dsfbw/W053JDaOdt5ydJGbJFYYDk2SAKsWHh710rHjsJZ08Tpx0vnpRYw3h72goVBkHhmbX6n/
4sCEt9B16B+JM082mwV/2cpcLACux/baTcY9nUgU0XKD9Wyg6h+YTO1g+t/4NEOkOTY6ntJUTbws
qhBHDjDVQMFZ1v3ypCajn66FPbdjii/aoVUaRVUrgHLX9IT5AL1X1czZ57ebCdDPL0HeBYvsXaR3
uIAzqt/SCCtw0laKb35G88tP6O/XBTTKUdU11XPauJ1NDpbqTsDT6dtYFq+WD34O97HtJeMoKbDG
dMmhlTszKYEceYsamgH1G6Al9AGZShbOfeA7EqPFAauejiwGlkh0Bt28eyckNk43KpzU4ZyrkmCu
LC4e1epMBOgOBxvyv0ICvb3XI/BUFqa+HQ0sO24JrZsCBH1OPEqIQ+LINPb2tysxb0jr44hhN32p
CnHhX3TmX+lESzeL+hz3Y3ft0nP3hORLwLRTuq+WSLs1VfnE3yq5qQAIs2bBWS1re2VA1KlbYyg/
AQKSbjbP9rqPDGdDm0WRqzRyC0BsmnOUIvyoqSDIS1SNG0hbIWcJdVHykOM4CSa1XE2oZyndoomM
p9emQdIGPWdeuh+5WR8C3mjRez7eE8oFPkGlZaCmhcoZ3feGJNzstGY7hgyms0QeOcJY1SVdZA4n
qsT69c3ZVB6Sku/gJGPOVDmObhxG7avgk9/hWSJNkrimp43ZThmK05GYn0x00VwgWQwvGi8XXih1
4qZwGJQF0872Jn/Wkrrpv2aod3J2ChPL6DXJc6s8A4tYp9ELSH84GGnG+IBrLPBrHWelK/76rRaU
KW4loa6rTLdF+/bESNE0BEPnQjzHJiB4jKNU75ddeqLxDjj2wni0rCbdEOUYIeTeLaSgyB38wzbC
RV6W8WAyQKYOdUdaRhQiL+LjOkv+MnMoQe867mFDAUAJe12TXSlDVHlX9ZGkpXyjFed0X2e77edT
iZT/HDwB2G+JBq4/oXqFfQk4IIwhhQY0mfYGGy85dU0FAVaC24/FpJctUHD4ZRcaI05lcSM08EmE
dpXCBJkWwAzSqjjfy2dd1aq1jzbDPxAA15fafyK5BoHM1M6jmamVjG+bbvutaLDazIHnoWuDk0nh
wNcJwhE2wH89fMHvmmnLkQda8uEtj9YrXvvDBW8nVhhCKmeC7XfhK/LJ7HPGhP2QdmY9/YhAttKz
ODIPROljNH0dT1goG4OE26f98QYvAga7tasr/uNCrdQi6V0QDnzVx96iXFUuemWG2jfipoYAAemN
wo+lIPEPXpQnUEfvwnwjXHLapM+lir5NkoOiNN0HAgHJbfNHaeFrFaHT+rclJjq7e9NObczVVy6W
Qwqxp5lmR2jjrDh70ARlctaTfU8H6tvDLbTOKA2B8u7vsB59sNNK5QzykpVIJXoDeQ89TfvH6mJy
2eejc+HRCVkYrkS3HXWAgdtE2XFkZ8QswHcKLAYhYIPFx4sW2iGZ9vjT3v929wp39P0h4iSxvyCI
GRZOMHxUILUmL6/0aTYplxVps/jTYQ1eyJEeC0kC0VHlGDYmmRbnDOtlHifjUjHhkZulfD7VwgKp
RnBsb/6iAmW6aXTD9YqOwpSoB7zuykhIwjiQVyUN77iP4vH0Vgl09w75JDVWa+US+viBZOKnbiuM
j3gl+6Qs4Zt/EVPY1x9VY3CM8BmjTFZG5lvF/jZr0gggorUlcJO9egJuyLUgluVb+ZzGeIGWbSs9
Hsfb4bR3YOTjLpkM0N1dz7nKN5E9tUSLSOEPywU+UBUHfw8h33lMUAZNuJYJGGRO5cxrc5OGrH6G
yJPAFtm4AvSQqOlQoejLQ2A5vc76IpZnlHCY0aRfZ7ZvCJt/OioWD0Fiy8XW++7V0ZF+iQYwLStL
tS3cJ2LzxC5fu5IG66gchls0yYLrKY3o6dFw0QFEGUK91MU/yPRASdHpffQIu2JqSmNmuWIOTSVE
vfwe8Wm74VD0d8znHU4G9grsPAbarQqWWW/4sOpQSJDkX5ZyJnMhKTwmcf6iQvAH8MbrXvgenvTn
8jVg/UEKqYnlmOTIYOtiXb0N8EeXeyuXYOBC43aO3rc2Jkyf5necv8VwpkKXloSnexc/59TZuP7b
X4sX+YapKZskbC3b2tHulVAfMqSClGtHmf7PpUQ2ELkSKxDAZ0JUBLCbiN3+Nw7+9VdhBoQysWmu
wcS1xXv2I7dvQKEG6C2NWA8MbgDhDK95DQPwoPvt9o78RZLvfj3dCKVV9bgutyyOLMQho6Me+SQn
h+bVK8L+Zob6j79RU93AL7g0UtgnhhNrrqtx6SxUYlvszYr8HRs2Ac3XfVS6sgM3Mdf5esBMayHE
bjhBMkWDRxTTyOi7ia0bY5ntXTY7M8RZlYDMVErnuRuVT/tnNq8Oqh5a/sVKfRMdgQPcpc2VO51k
GJHWPtliaTOh1ObGN40EjFri054Y/CQpVVdD4tgeBfKEc6+3AMbSMpqxy/HaMU3iEizhmhYzTAd5
bA4o/Uqtsw7R61ckaLLIEIRI2O1vUxWf9b4K+yVaPqYh5wArZxiv9cPCbDUnkESaUkcwwNMnflrg
Fclyq6XlJZVJy6iM4WK7Z90Rtw/hcL1kjPQfB0nFDwp6ijiAQZ+Ny/j0PPYFT1Ro3xeOf+NGAc7D
urByALmwGMF8TM6qLD4r9FNQrZcCGZJlByYDCEKYAGftlEe/OVsjlXNKaL7RpLlpFTFLUSRXA/N4
LX0F6HjQOJxUPXg+j8ihi83KS8FcQbpcHEC8klv2LgpA1+9cezP69jfbBDled9G8NJh2ZxXr/MYI
/kbtqrlACJhiN4eqZEzG6VymBhhMABhRmog+wiN4sG/3YkEE8XWYaBQ2jZ/p60OjBh3Ze9NathHq
fSeuk1RJUs3cUlmDiWy6Y13/zb2eaC4ecQ8uH9DAcfym/FuE3kDd2B1z+KFakDF0mayv2STZ3hjO
ihrfRaiLv1x46ypu2j+m33UCaMks45gcEc0BztjIDzMvUhEO0Wrtw5Rw2PDurG158klvVX45IknN
88BhKwARUuqAaqpmUsHBZUWZ1apNJxguh6fAd0vWmPu0tzkB4ar3kU50XF2goVoJSIruZED0nwlk
KBM8Ynl7CD8egbiMABPt+hX+xbPUk2t5Fc3zx2zeZBLdygOi9g+PtcZuDwFsFrW5lPkJ0DT2quQe
q3/gnYV0Wwpn6GgWiQLaENedqL1a6jFO1yz8NtfmjhAJtLL92/tGt/8mEUQgGr4kho5D1BErkWcz
jFmR/S7DohRIeVNGxeNmKwEdFLKdf3J4Jj9hP5jffWjeI9slL+6j43CPbHByDy82rUV5Fmh0vHfD
cSxhgBfmqrgVx+8aU/g3bNUI/N5gZHjOFTe5pjvrNn3Tor3J/WKO6dioveNW8aQ6Pu460WWRUQP6
pPfuRtTiD+yDQcKF/929p/p0LpkvgRJ6ZwMtFdSoOBF/aq6IAyKIvA7QkE+9q/GJKvlhIx9y57sc
rWHnkMjROeSx0m9d0DDAU32dUeQMZFqCDbPtwiOsTpT8HcVVxbKsULs1SzzWw1aSW92r3ODnvm==