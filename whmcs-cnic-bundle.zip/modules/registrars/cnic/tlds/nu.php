<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxd8Fdjs5ODy3tchM8W7vK4YLnTE6wjZPfEufGt56DlzxMOX/v232+No42aWU1ajC4mZJ4bS
X8xwtAhKl48QfyoHBUAKarO0lLp9COMVHwH0caHqJiSXcApfUFtY9vSE+8oRBxs0JAXnMNU7x3Hf
7zHomZDSF/L8ReTWmLlIDgLhsrBSwDf7abEuRt22Lomjfx0JOmLv530jjAcZjmr0kmuD9zEUmInv
29XU/yN1s1W1XWfD/e0oIXcX8G0h4XXX081j7gppYEhJ9G9xXWTad9nBMgLVNs5nthAI/1l2OjZt
jOKmA4mXYeS2hl1ExrSRnzBDbMOfjJ8wiTWiXRAXKuvbXL9NbuCzXHByyF6GYb3Mhre9L9+nvTt5
GzvOUyU0FRa9i2CtD13XMTgY19W2klvCCvv2LdIGrSeAG4DvGgPNKenUj7hmLyCvDMmlJ51vOkDG
41dUeRa9+i82GCdCxX8z0Ji6uH/9EJjQKXXRw/Bp4FbcYJ1/FwdeiO6eOB/0E++3Xs9uAS1eSFqu
es3QKgnfKT9TK6sisVXqcnhw4R3CiRwcjWijYDk/KaoNFhrWHyLQOh7LiMQIhGjgvDfcVUpvc50S
ND7Jd3zhxOQtAShJrek2yrxBRiQttaWnyKRTfp5GFfoi3Xe6higTXXjLcYCYCsPKkDXUrJDf0Z7s
/WBP/k8Z7P1oLRTjc4FBN9LEPs+AM3f/waN5tqCjtOAomiArewvY28Br13UEu+dv7qR6L/x/3IFy
JFD53D7tAiYBqukl0JUsvJXr1plVraFR6v+//Rs6K9smAT9tRGiOLIgFX4TzZATOvzHLhbChecCr
mrX+kIONzUtwUbWqB6uPCs2BbGPb1QsACLoQIbV8VYEGw7mIwilMi7o4UyPNU80K547SZ0rHDNDK
vIb1I7u5Qh/gvv+2Uk/RFt3dvwteCmVDzYiesO2GhuDo26HLuEGKI9n8BNw+0f1g7pKuS+QOrVKn
pPVzELFQFT4CFROZuBDPCFyCXIcdplbl6P3vhuB8OT7H/g+yxegM50Ulsao2d6OHJfuWQFLyffr5
AKGThmTWNEWhYdyOyL8cbDSJELhV4y4FrYagfeqGDLQ3PZyTHuSNxGfHE+wuGU+cICLiXgD3djCM
f8ydmDK4R+z5Lmv9yf9WvIwM0WrVKfON2ctN8zHimrorwOmvkxTL7zKhEP4ATX23h1IaxyjLh/Iu
ijlZ9h7lOX+jrsBlnADGt5LicJidoBqozFD+1l8suOya/W9Dx9bEUcUpBCvIczAbP9VGOmtfspRS
RQhvjn+waLtkRabz/BxxhbYK7HycBYXC5jJuHC3wqVLVansXSNALB5INl70Yi6US3UzVnvKDAQl2
nPll8YLGmTnb4TymgCnNbnWYpNpmCbKMWDT6KYmHG1FJa6sylu8R1K4hUwVa2+w1KXeK0Ff60uOg
KnaR4dAgKtbe5gBeTdWEnG85piGr4kJk3sP3Oim6iixWE7Rfrr4lyKZE0oJnLG1NXiKTb+Iq+E22
3MVlvxNGEPITXTWbqhTyqn80IZLEKXDrnuG6Az1ZRLAL4aduH9mDUNjOeh4z3Pp0tUzalydOuVa=