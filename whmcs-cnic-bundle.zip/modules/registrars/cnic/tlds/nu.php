<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqT9V4RkgaHgz/ZfPNqXOhdVCcHtiTbP/Bcui2S3E8FfjECOywixaRzcumaXoeKw9iuJVGY6
IvF2JKsBFT3rc1qk/05T0Bf+VVJAm5jitFQM0IRprR9vpWNGqA9NLlT5XC/6cI/lqW+KboNapbsQ
TMgbRVmbypjJ2dWEh7UqhBUDVUG1FRczqqvnakSX8rimnFqg0xAwfD7laULF+fqb0Nor2xEBmWkE
eVqFtsnDx3XUGlul62VzaIY+/yHtuPpa80ffm2YPmMiNznedaAq95AXecMjijrLTJkloBlCHujVs
yKLdQNc/1ir+Ez0WmQ+sT69Yn6wX+TXht3SZEJj1ogbQ0aOsVknbVpufI1oX7jGrvKCiIDPiqZBs
oIJ5JzqQ5Kx6fsJ0U4DK9BFs5URfkZIH4SB4T+W4nsrSiJR8D8zKkp9BghjbxmYjSETzNeTjEPMh
najYbexPDDXJjgh37NXSclTut37Nl/uYGq5sMt3zYnuxdUn8E2HJHKTjk2AcEoqfVNTdBk/DxomB
/zwQQgxLcaQSU5b+WxJ5FaiiOxWIYhzgYp/24kY22qXZNuMSqyhya5dyYHSikx9PZPi3YKB5zG44
BpJ6zfZDrDHOUxOIdyOkGjDKD9fZpYR0vbI/uYmQSCWQTY75SapuxPduKA1JoPXPfYZFpGjDcbd9
NgePLfGczaOvIF20KUBhq5jHUvhd9kr8bcxulTxVRaumTrfAvvMQKOJmEmKN/P69FXvBTLHYcsSL
fyUl/Gsqbg/Riz8JZDCTvHDcUQRk3MNe1hWzXGLGoa3zdKcmCnf3fePs77LFmSZoBaDksDHvLd9P
SmxBWZ2Sb2jnSauhLmtljBYh086kAGM34U1VHCplRWGsqZqJbWupe5X4V47xUUTnwpucEYkKlKG1
C+S7Iw+1ONi5D4jsHQ6RLNGB6njKVD5vwLj5HZ6KuGKddr3juScrsWd8nmBG+RDt7a4E17PA1R0b
s6pzBzokQZstDbLocDUTELpRGyw/DXg+TL0LhfMyFJTuL4R+nJc8c8H6loQj0xNA/yJicSj+nDLX
fX8BG62j1gyd0JrXW/8oHuV+ucdnciZvQpHONr8dTKboUzcTMYwGZG/JmHdAqwfuYRLP/PbPVwAK
YRgzHIhdP+7sV4UTjQZDsMgAZh0lZwSYCr12Hr/05hMIXILI9/F3vTumrI6T6FpCQbuMNZqrdFGf
n+GKFKhIKFqRQmFEa+WffW68viErk7hznsbf1UWJLszLjIlcK6ZNG6iXE9ckiAiYREQn3dS+x8Fa
YTYIlM7VyKwlJOGdxE5H035n1MgnaKTFG8r6V8teEFrGftPMqO4rzpBawj0WqreB43WzQpWhlMle
7FrlfH1p+5wBvISHSmp8yrrY9CX6MTOOpYCx87Y7cogAsDlNQXnmFNErQqY/dWbJX5rFbZHRuKeX
Vtant9P7dbwJ7NQl1EnznNNlO4273vH7GJXC7FGUNdnKETU0WJuAPlVZOXKJFhizcbhHMzgADaW6
6nR1vClYJcFm7toUNF1Gmq9Um/FsDUV9US5IaOKfWcamc/4+U4p+ImJm9ckpFM1xl3soYn6HmfJq
l1ZN5tG=