<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPngfbQxJYcw1gXW0ZK0gvhEV6xoFt9OT7l0MwYhBDMetsXcsbEBt1e6BFvO/wE/Uf++4afDw
Y/bYApX5WhxwDKs2X/ZFYy92YsfkarjrM2fKfuc5VWC5qizIyADBtpPKEsTKRXYQ75p6bO7H9Dti
LzJcZJi0lUBY4TojfhLqdoo8ofrXC6ir9l7dheJ0+bR7sLY8BeGEKvuriuOvwAjoi9YIPEMXY+oT
imszSiS0c3qi/UZFJzxRlXmu1kcB9NPvp+CbAofotRQKkYsGIYej9Xg4jFuuxspETiY/48UR5wWT
GZr5fY11yN0USDQax0aukTC+p1DzUWxY185rGez0muT3nIPaHS1Z1DgNQwwB/AjEKhcCsPLMfgPp
tIqd14Wq3Brc0JgNWak0sKInViDJjaECxbi9Q4diFsYRbZ9rvh3PDREdfSWtxbVnQE1B6hz9ZLhb
rsWCY61+jPBzyC9IkrdXf3vPtQZdauGG9va992geOLcRRUxrkh5vul9dLUnfO2nbFnHt69KTQ2po
SCiAV8vQWd9IV1qUo3CnJW5GSEYvbN43L8s/YkIstOKKIVp9eEIOy3XvjgBkr8J/ee13idPL7cEF
QbylxoIiv0EXZFMoVdGInpKI3rNTxhRuX2qJ2yVT1iMqXhC6Be1j5F+uip6LPVPkHbaozblQfK6u
6bNDwl3buC8tZurhAqkTqKvJwcrf9LiTBeSX+4vAD7JUbH2gz66cFzzcm9iLj2117J+IuqgFYjT7
gulY2L7phIIcXAdWG/6zgsfPksXKoEMrXQ54+UvDXDWzIW+5wwzcGwzv6xwF6GkNf6+fRkuncyzP
yep/6L2UE9knD+JUMFHKuMfwBw6z9b4NfUYgn4VmvCHCaYPwzzglK3cWE8mMo4dBWNs9fEbxxF6B
GxnHzQcMs0j1BT6M5BkJC60S+74hQbD7J+40LlN3zMeaXtfIBArFk42Utcm1ZPukiuxuQKtpFODY
dQlx2MceROoXL9G1Eg03+A4GZKUSEdxGW+Ff1oZuTiDwr74+9/xkandXoWq6beFTxxhJutoKFKmC
e6T3dNXr5HFrtXaAg2+1+N34837pe37x8O4pezCBC0rIQ3tMvBawNE7cK04paqqa5QmT/reNaYz+
MIs6nMNKt5Lazp/fncu/pN43imDiOG0m9TU0+SpJI402yRLIv5544sAgLsLgdD9oYFA3HdMMzaMP
eAedoxkeg0CAQMQpqnvqxzoO6cWJomBs0N7wrO5bESCzbIu3XcRKLAUiz8e3TDlC5qRZ31lHD3zi
DD2//GDP2pNtgLqrNAZ3gBydVtMOJfVBXA4b0u8kWzBWXiYT4NPje+DPkWHKiHz8wdVxs1YKh+Us
r76QrR2H4TtwY4eVYGXQGK7bOA25Z544uOhVpJtEqz+39WoF/HZWtC3cbk1zUDo+aqP+2tWcGXDA
UhGi8TlsRS8hCdw29p/IX8m+GCqik3k+nTdT59v95HCnIftRizDJStvodQL3eNqQNI3g/Z9KRANZ
ZuLF8YoLt851nUXmV41cG7yNhITLoSO6cKgUM1SRgrZpYQJTWEuQ8B1YuwMUdpHC4nGFn68uVmi9
hodWYQm=