<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz+mRP2Qd5ROOm7uisZ11Dz+gFxGBPo6bQwuvQwx5LCxx9lf/YyXrd5QzDVvFrsnYKo3ZFLV
ip8ojlXixtxMeZzxs8bcjvudQQMFfl9BDOCpUdT/Tn9N6DfYPo/AO2O0NED94wlMrXBVMoSm2JuQ
T7jJYroHws8wuZbb99ED3+d01ShXEYd9+MdTd1ut1Ur+CoO7lG+cICyqErVeQtpXR/91w2ocRbSp
y+6CWI1b4Tyt1nQn8eEVaDeu3CcFYAd5d2xZAzyM9OqV3uQwVOh17D/d/0jfSWSbiw16FqmT44q7
4mTHi1XRsJXSJ/wduFim9b/dx5gfrqNzXxJEWVUx0fdvvTnR2NMKfPjeermV/NNTQxfVWyGhsePI
l/NlPjzy6Ug+LlpskbOAwTxBzmzmirmeEQN/FKAjO6do1a/eXHb+hdxyFitN/FChoZ2xr6OLuGdM
0dVs+yzZZwBiCGDN5rF2+z9SGQmq9mfcwnkfc2cUppC1sXQledk/8Eevbti7qfubZGC686dB9zvP
iO9SdTQvex7faHPdJW1Biucs9kA0OW82z4Umj0Sr5W8nZWf2jVM/69HjdyTIqAOAO38XRzv7EEa0
plDqW+lhjJWvwiV20nsWR75+cYoz82SRZN497necWwNermJ/HeEy+SAL5pEVu16kNBqm22zmJQHv
uSfo0f7j6CbhldWkTFThO5aE0nn3efQZLujI857k6YOrVja1LRbCVV8ITRjCcVZoP/mBrz27j+nc
WPFTDIa3IcWDSJ511SVLZwzN3Su0DelL++jktXHwsS2909FOOGZiBj0NpFQrCWaGqXTeIZyUphJI
B+cqa2SaGxCjeiJxFgnLtSZd3nF0T08q3xrVKk80JWb4e73+kOOEs9EUeq86EPTlA3M5N8Gb1ZXu
SyN1TXtRt1qYn7a62wYCdiYKyXCV0w5S+z3oVro5FP2SZwhmWvMkJXHQjvaosL5Qe1310RTrDojw
ZOzCeLwgPDaEdNsUygwdU1tWhOzvxz6BDcxRpGrlqDOJyeGmlphifIXwPhMnIRnK/jfeTj4oX9D9
ACN5+alkgygwUB9dd94V7SNUROlGVfqOfaTAY64saEF1AsZiGtnFp6RHNajqx+3xnJAqbAo/OCr5
5EgEaYqohybM2YMjg4fTbDosw1mMFov5IBIpq7xph0qnmKbOqn+V9fKWcLqhBS/WxEYUAx91NAav
eKZ//zee2ceIMerJ+X3IKfLYBJ7y5yUGHVwO3QNsIcJ/MafjGESFatHaLJtO//zdkzNtSOacX1fd
9IaHwkcUvoFOjT2Os8qBkEgU5kqTuq9hAam1BUyJUI9ShzgxVTjDQmNIKNZYhu8Co0Q7lAUYDNNi
1siTAnUKrRyiKwxL1PM7JTcVhEXV8j5pxnJkhi6DbfQdzuhqM8Es+QOAusqU0Mua+NGGsuIVvr1Y
klK3yskKJqHAvJ5vzv7bHBRQzgb/Bw5ZCh0aKdWSVt90ZRLZGGf5Xzvtc/MlCQl1QzQYs7Vw/hRa
CoGoJFXcwc7TqZg/gGdYpHkV6iogUsIIG+7OXVNyvbvJEBrW79ER/nsSOIojkNtY11S=