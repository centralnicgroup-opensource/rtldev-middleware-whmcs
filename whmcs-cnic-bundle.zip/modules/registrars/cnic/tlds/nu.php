<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/As9sYScfnFMGUoIom47FF5dvUU52SEHzeHsoN6CnS2xN6U47a71b8nD4VpOnmPaxAs8fJy
9KlNcCCpbIO5yMnnfy7a7DRr+yPc90rA7sqOXJHDmmx49KHElLWLyfsKK+UujsMF5yAEWUQGdAYb
vJ6GgqSkyCltKt11Sh94Q6vSEmGpCiKpmofNK4CbKfkVUe12RFuWGigjG5AqoOgQdKo/Q6HdqRQ0
bZ7Cj8Mx1UcRzCxHwXA5HJ1pramO1hkRsQu6GlXAVUNIV3GoQkiop72b5Vcw6MLsGKzelZs3+f5K
1y55HaIS84xRk91EOk0T4pTvCZMqHWK6DHiRQUdLGxgihUF8FT7wJxuWnqlVXiRslfkFyhkAR3tP
aPrbVqNse6KZ3iOZrUb/CMhnyAjiHAx715fMKSGQucTxKKhvDVx5cCn3IuC9xHEL2si9QTHN+cjh
ngT+A3Ftt1yLDj6pHPQJ6+kFrL0MED6gv41xAMWguGd6f1x0H4J8Uw7gf6/+A3zTX7nuOgBDBpSC
nU/7chYr1FsKC8GFnOd+mPjvI7gGWqi6a2Z7vWbryWr1rgtT0tW0OanPkDsafD+oJoHUvzuK6/sG
A0BG7oSC6+CYG3c/e+L+u1RrFV2wCg77tifMr6O6PHC84a3+DmpGh4toAR4XnPaX2bcNBLqTvnPo
GjH1L1fs81vIsDhby4+rQKh+lmIHAcrMr9EToneB1azhtnUhE7MhcLYQ3XDRxkW/clLNlu1BH+n9
bRZca/ztvOtjlW7JnsUj0Ji16p/LEQgLdgj48RFGP/2HXUVfHbNP5pRlOXHDDksQ9ZgHCxFYzW8m
JmgTixwabLesbR42qcGGPvkKillfqPDa06oJt8+Upvs3yiLnywi7fojFYcL1KxUHYptmb0xrZAGA
r6MFJz92cWJ3jO97CnoVNHGBnt5u32m4Ow12lX7wGw7GzGmuSb57QRbwtsMcspRjMC+oXKgi/74Q
4hyUMVjhwAPk0SghULokYO5wUbjB73iFPWR2cc7+ybTWu7a3Hvr92SMrgnTjXMrEnFkBdKQHKa8J
uuvWqrhDiWo3CR6fQOdec7ZQO4hTtzWD5KUk1NteKlk/+fG6oTPqpxq224Vsr6shq6nMJp956bwg
2UYppLhtkZPcgAOfuJ9kT6F+TCZnksJRzdUklXt5zV4Ix4JnFlwQb3WLbTGgiLwaFGm5Zn3iTitj
W1/MUw77Qjy4rFx2siwUIBJ9/QnfHD25p4/tz8OtRL0CFXCfD2O3ueY8VGARJ96AuFkzbtVC7a4h
3Shr2SYCKHsgRTVo/qfk/ES/HHaU4vHDZwa5voowg5ufS/b4cHDvfOHhXQoH6ZH2kvIszBfijpeG
Bvp/GBP2xcy0Zma9R+d3efebVPxRc5VmOe/lt2nuS+2TOsh9Kkcz7bTAeIUC5f+FtsV9WudaGO9G
+gd3TeMJcD9WkbOT4z44XZ0zfmOfGyFg83BU8hNO4kIUubDlAyKaMW4wTk21ArKJd/zAxIEYthyF
V7pGhE9Xd1iMM1jkC1EG90JkdPsJVEkYfgBVEMrLBe5WnZwTc3VUwMlLC6kfGO5yLtIpJ1RhxaKa
/qxOaCwdSAobv082