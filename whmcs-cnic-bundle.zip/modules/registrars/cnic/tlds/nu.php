<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxd3TQruB4w31NBWZf7AfZLFMofXW9oqNyHQ/GAXJv1FcsxXWOknawvNsQTDZnFTHCzQhHDl
+sgZZUs0b4d3Z5p53yf7UcTDQb0z4TWeSIQHvHiuweVF0hRB1ahW8JTNr11eREELeOYG+d5x24za
VRQu0zpcl5qqgdtI3fgbL0xlnTyshVO8h2mcdxvyTfl5+cNYFQvAYgggKL0tPpASCelcM8KR5mwQ
Lvqr57cA8k1F646tpYZY+xEGNydA171C6RYmJ9Yxr2XaI9Aw0nHvreN5YHCnPwjW20Cr9X29LarE
4eg62FyjaaS3v5C2H357X/+w8ptfnlCaw5oUOd1zJrcF1nadSLHei+QrCeASmKRrn1Fh2JY6rj2j
L4PdOruYoPhgItExsiYt0j1dhGQ+8ZhFJf2tfk6xiaQTCatAZhdXRWNtpp1RKeNlRzQtqCYhUpqx
79jNCIkvYlTNEorGjRNpUbuGOCffAh5Ck6z0LAuD4sHjhAjgHMaQsfAsDzTqnXBb5u2/i1xbspem
rjksR2ldhTMqNAkCm51GKd8liooCmDMkGrZLB86VsoN+SIouIKxUZ2hGUHsxevwurJCZMaV2jXtD
Crzl5kCNLz5+nBuNdPyZuqv1t+wkcp+Qy120eNZaqu0MPAY0iGcE/kbYAzlwzcTTJmk5ffIb5CNy
6f8AP7hZiYXbFd2UrjSxZ6LsGc6WKkBEZmqvzoGejSwIuqjXeHfWSbt1328AA4UFA5qF18HA+tzn
iGg4PHAZ8AkipwXZzR98l4ELZHQMpd4ZcVXaVl/wxOmA20rOSY7zr+aqPYJ7XkQ1VoPNmhQk+lz4
sg+Hb7vL+tQE8jgQABFo3gNlH40QV+Xi+1iDoH5qddThEHKVKOukVGJI62Z+UlhkYEptr61OchXT
SIaJpyUzbG7e/CY8cqfaadoyn2T8WphNH+//9+9VOk3AA9uvVI3WnjZTRkuOz3Z2eFHG3ljDZ/o9
+GN3zoeDec/oVO9YYmJ/49ZnGiod3UpeKOYxBdYgBu9Z/Vb1KL7IbDN4YAYcXZBGKnJPVdADa4zN
bPNCzuI8fT8DTQ5/EWdofUB0jiyk7fD6Jtt5ot/SQ80Fcnt51YZI/HdVZ1ggPhz3v/wXKNro3YgM
iTmUZZ1MQ+uthi9nO3ug5T5BEgU//aDvfYaAEMf40+jZAQKugWeHXuJbDlfaaU/JbTt7f9r6sTH/
THojkdHFHoK4D9joLvR+2od4/94POx4qoT9HbSdc/ch6JtIVJi6qI/Z4IsKLxV3/XUouVcwoebBp
2JrqmGYlCIJDFJ7aK911TTWOo3I9RiYPls+Q42soOWhGghxwsMd43RMT5gpuYQ+I6sRq4vs6P6T3
HnkgtqJwE5780ue6AsIBDnDnO277ifWwaMB46loY1lcFdKevcHOLP9+5bh2nplPAbNWicgCh3BIF
OG+WDYI3Hlboa0vi9B+4ZIcHOoSrZylYUdlEZZUuM4DPtu89CHrVnR3fmB/BIhwjg4s57EmcXN9n
IZL6f3ZSUq5RgYVPpVPpy64sGPMjJcHJP49HLiNVEcBFLcrZtQRGPgzs9pcqjbRWqEy=