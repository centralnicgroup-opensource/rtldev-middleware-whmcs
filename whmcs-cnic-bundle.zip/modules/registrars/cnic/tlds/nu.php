<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmPaEoNqoPyAWTMk1ZOqLxhU5s0EbbibZf2uX16Tt097KxB6L98+WkSQSGIk1zxi+B+kXlIT
skQ0tIeYP+u86YE14F40V5lcZ/jlOvH0mAaY+4wKP9yi2aGTqYoEbjD67fNr/efnoKkWXvaIgel/
6SC2J2AXy8t5+K/XoNzkL8T3kOhbyharWvrTnCndZgmx8dPf75PASk0pPxDoCU9JFHfZVDlRbIDq
qJiKL1Cmkia5fmjU/DGwfU1QomiZFwvjnXP+I8rG6HoI3gSU9NxHfA0ELDnZ7DAq7aQbiO3VC7Mn
msK+JuSAqvuAWrG61WA4tPQBOh2xnWFfhfs9wOtTghz9Zpr0Lv6NRTtfYTkTjGtf29Sp5dWH92Xa
6jSEUZ9Dzwg+Jd2i3hiOpGnzDLwe0tuPKI6Uy22lj+6cO/5bk5JLr4dhLLm6KPI7XHt4JiwH9j3/
81/66iTTdwsX+bkvs7zNtBLFcDSROCzq2TwWd6xftJGOzWKCrJituqUsydtt1yalETI/SI57+Pej
sHCEbt4UqsVQsQ57LpknlnpDQYubljbktPgoED1V1KKxchXXQKdzUwc1HT3KOVlnf1WtBeKYKNCH
rrUtjo6JXkLZkPsNdLKWPMTQ0B3ilU/6WieOAJ0G77EHzqzBNI3qK7QIjoV8UiAmNIuVy9yeH6dl
kX3T+D9gtv1ca8PbauwBPU2ezrUMFtuIjwwOrcORLq/T2uW8ptIr1TMgiom9q1yNLsQfH7FdZwH4
iz6VGx4s1i+hjuqJFk4Utb4P9dKPGque6B+eobchoVrmy/6mdv1XtfrJbDSfTMpSYVtOEdGESXjj
bFsXhuMx/z4iIZRIeUrXtol9G8+LcXK+4hOISW3FeVDSeDoJsNskA1kZdNADLbqubQ5gDWu6JcGh
GA5xpyaw6RCqeCBLaYtz7+wRst5+f+hpDTlioMJE9jsXoSkVOoqGCXP/0XfateAMIDFWjfo06WgR
vGa/1pYSVqcn1V+c0V0THF45+oy6gID4YamrMQOrS4KGOrnFc31rRm+0u8ZGo/8ddQ1O6GvCCyXN
NXXId8DUtoyC2rWdukMtRuLePlc31uKNA6s9WxDMtRADOEw7VzE3XAQEzoJ3heFxI+DcNgjlKLqo
6g7XqjrVnLAyp2jJeJbn/Ldq0o2FsQNnoDXf22dKj8RLBtJn9NAIBqaJcLNyN//f49rJ2BV7+fxM
zD/M9doy/dCGGOzlF+uPZRw3LAUuJ4DFuizY5uXPNjJej0mXZduXNitzpzBNLLy3/PjG1Qc0Ub1N
ySawsOkLPnAkj/IwswbXORQYx+ySDJj7TTXc8Xe9fOZAG/yr4LqcEYY000m7dBTwfqzJO9yLror5
FYldpEHCmVp/jLwu3lk/r/mgwektRDKsliS9AOXy4U5Gnp9ZKpZFwyo6c0nqYfHzw15IgaXN2s/N
Dd1bZYRc18/yLzqpH+RCw0wGTEQBgk8EUn43pPJCAqCfEQcL7nshaSqtndb5L3M+EBmSE7h3cXgK
BiCcVX5if0GdamwOKN1x7vmwHI/or2yNpijTj+91XVmmCtG8fAnurim5AmcBInwwozLOE0==