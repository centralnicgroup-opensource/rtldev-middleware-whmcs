<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPucp/JyedCOmDG9e79It+cIG5CiJ79yBEhIuOK31qylYd8wckFBmisyvn448rnHXttiws362
Gix2TWrEzqtuq6iGHDxCGewcCciaFsT98tk+zZOSwYvVdqhHo3FuD/wwn4M1xxICouT7fRKZ3i8t
dZymjEUxT4OFQhPVgTXm6/V5qtCqyMSlwM3qjOQkSYwajWr9/WMmNvrYcB+YGStZaU4ufbOh29lQ
WzNkWqbCsJ11+itKVaK4JCATrURR+Z0qFjq/zJ+PedukJPKmH71Gvf9HSo9iwI0rHzQ3CI2l/Jhj
kSOV/mOZMnIKUpDnBeTJ/q6vIdf9S6R4Qae6byGWgU29wVf7fwFOMTG+n8lx8NXVZwKYMQEHB9v2
XJGrNIpwdJXfs+5eUdPqucEfqaSZn452x6runr03c5t7T3EbzRuIERn+sKC7TTJCNsMXZ5eGK2+/
wUL6dstjbVHRhT7d1xK6qgpFOp1pvD4DzTVP2ZbLGufQ7CbfE++qyngrJrk8yv0nk0rLPVdP9wU0
A6qvq8QdMogMs1LcZ+IdWI3gTvwmlliqy95+HRk7Sr+Ie9s9h2Leyz9wc/v3OosbFv3yu3qfp5Gu
br0BHTmum/MN0uuK6dVDAbDrrPuOvBYuQGO+jH7dmbp/9ATGpOwgW1MqJGlWPQ+GDZlhK6MZBSbL
KAJWC5GNZNjn7LHk9JxOVIcawwBIVqEAMBfGy8gEcqEBkw0HaE7IjmWdvTwEjNVR+G1VUsjxUuFW
FWZ1hORUV3w8+6BH9AFvMf4fYWmv0IjVdx9dMbkkJGHTIv2RG8lOM4U/XoO7KtjYhEKPGnWbZz5L
5E9ZJm6PDLhNRmEHhzKnKvfgwvf0G/mhyDWbcXYMbUmCm+5rTxB0zOUx5U61zGTYOQsrHuHgXxH8
pMrBDkjUJhwRlpAb8Oy6X79KNRJlKto9HcKCHfBvjQ7HCQ6mvkz2VxbtsFdk+mU3WtbAder+3OPc
xue4Rw8HE90aY6JUfzxOsyjU3g+kflQ5QX8h3J4NxzvDdQ6+j25uifvT0QoiHhGS7RXWZFtdcFsF
mds4Fy8mG/xfW1kwvl713cj51UCtWUVwEIzmynlwbUX/hXNXXPK9k/mhbHGjZy2vCupiDLXB+rYh
i2mo1XEqDbYtP9EhAX85NRkzNVoJjU3CFKBS+oX9OX5Ik6LioT9XAc2hedgiWIM3d+W9ZugFd5zS
rnu27fmBNwCss/N0xmep47KND4+hAEEjjfhj3NmAMU5Ulp/yNg9k7eZq30A2SMvkZkX4zJNHfQ7q
vnAaG7Btr2F7c9cdMNgMZQM0azuRtnFb347iL19fFjsYXFy2ioLlGRUA6WW97sB9bLFWmqjG22uo
hywbqqP1/yimTCEc3oneaUPLlSTIoM2Uqu3ry0gXKPkU6wy7INBgn5O2/0lsrhUDz1dX/AKwXKQR
8YDlOuXM2yN6OHOk6vu5JLq7Wpllx7w1f6n9Kro7H6Cxd2p6I8WKpW036ES2Ufmkg+JtqAK58Eu4
zBoj5pQbHa6SbwCCu9h2cNgTTDOlwGJVrBd6ujDFamzJJ9Mik291vtRw12ZskVRQ9WW=