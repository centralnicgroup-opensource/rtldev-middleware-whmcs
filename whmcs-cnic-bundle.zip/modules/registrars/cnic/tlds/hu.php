<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyIU1YdKOViEeIsJ2j9w1W7N+sahDRfM6/6d4z3DO/yVw/Oj1DzVoHtSg8fRb/dB8gpcGRjy
Q1gD3aVcdU2gWySfHeTD1n3WFg5u82aEnrzdP7S+pXz0W3U9iZOKN4mj6kb2gHZB/wJj78zH9oyJ
RTNCSp8V/hKj1l+2oeGP474qjJ7K/r54WO4bROco5oZTJRT8ILkE/X6SdP0A8JfT/UUk8/XSAbTR
gXPWiEfW6WCaqLxWMhPJbq8cNDFtblH/wncx44YDK1aSaWwd7YL+qQIW3bJEO4NXXNe9Cm3dzJzr
eGPd6Zc5Ne/i91tGLVhZJO2maMDByiS7D8dFsUYcnbZc5Bid4NwtL5Lbx+pKFtisJ+28l7/dnfuB
EWdc1BoQNod5VIhlk9Lt9DyNdbbw7FZ0zJlh/8f5B9evRef1owtWd56MVHUee8aavKZJUHxdApDu
YHh7lf2whJbbIaxoe440VOxncU3lzzhgARD3uDom3vloEbKYpYaaiHPgPPnZbYmw/KlMB5joWLaV
xxHV5FUYGQ8RDkSwXLw/1ZZclCoAfTrdCrxPw3z7u81vAT4B5Fs9JGMEU9SBJjWdNeB9Op9/1d+l
zu/UoivJqgvUPxBRUXamwt2M9mNA2OfG++C5gIpgKLT8gQTRe3rsucN99kxcsyBWaRyH6XZMVzyT
m8zvcQuQnurk4m9hBreHcemkHpvrSxYDTwajlkM+CdFbOgoxubpQfmChZ9R7euFCm4AfIibPfG+n
NvhCW++EjffVQcQ5meC4UMHJGAHxWuH1qe86UJcdPC4KnSSKg4VSmxpZNmTzNdlJ4r24uESJHCyG
JX9MByRARVnAJ3SfjY1PvFti3CV7twNoYKURMMevvalU7O0fL4ftmhugx4RwbdcSXdAcp8QaHQDb
G16/HNbzkn5tp+koKAT7fzRrL9cIjbGIro2Kk8HWYjjK95yopHRFGnJbdzNbFw/k93Cw7U6b5QJv
uHhH2yvOmF9w/Efz1Yp/bxvSPba8ahfyY6jeIL2dWLpKKABXmzLwW5s1vcEyFwUqOS0mpdQVagQi
xxkjxoXmvuW/dGXm/h89OgD8nizhTQ+sgYVaPqBDvi5IgiP+ulBf73z/LikM7Eb6XvqzK3UyReYQ
wX8pGUEZYo10Ac+kuUUvAd2NSAIQUnLN1FtRaP8XOw/EiAk3LSyLnKQkDtzfaPpH6lSQwpNTN+O3
esCD5tgqjJCkrL5ifU44XnYUa8qLbAIU4EmbN+k04o249X6bKpwl+2Y08juMaBNkU/knEZRUkE7r
0y7LaJ5udrqerWP40sYDGG64LcZyX+zE1Lwg350mIuxoluCJIeQHZtPWKCCJiMOUu/37d6PojqoH
Fb8LGH1kuqxV/9nuGheHctYMnPfocUTRDG/YWNrOnsiDHcww6rbBr/3QZR8KtlvL4h4laJaKNlgu
PuYlaYq8ZgPVNlT5nqteCy4Q+iJ06ua9CwUSAHbulFITXW7uV/yqw9zSTy9FrGluI2zJteF7x55H
4ydhnxnsv3v1+sQXvVG8A23mnTQ/wWNnPO/5JY2K+0JD1AIvBkea9Kv626yhhVSKh6VuMPzgruIc
0aBHBuXvq38IHpAGkdKxM/dIvca8dleXnf/veQuZQhhBR0glV1na6U1WriQC35DSvucv9rpiUBzE
DZ2vuHCQwN771GKBWvkLnFr1/q7NHlkhVNkCCP8fSketjMvD3IbYMmwe3XIV9Cc5GHwYTnsLSAxr
J/oc9ul2HXkLeYSmpMSA1f7CU9+UFymDvrLFXaNh1I9vHnNE3xIpihiJ/GvWat1ANzofd7Yas1Y+
5B2gScKJg+JH6f9Le/e8Mhk+P+A/6x46Mz1sBoz8mmQEGUB7Uzuj4NXCHfoKyzl190SogT5LxM3k
pxkiNhWUAD5SXLAbfmXb1q6UyVXCtBA59gt/OhRfuqCZfBhz1diQ6+HnN7KQqylc224R5rCmiiWP
pZs7KZFaXzjuz5jFRhMjUoRwwljnSrNSgNVyiTDek95nRlwYpV0TukD6xhNz67B/40R1kZsZ0Kv3
eIEmwzF+W0g7ktK80WHonLWGpEkmfIhHkI8BSS6Q6qrGFh1SwVgs5iGu2GjpMtyaQec/SlHtiuYC
HWhLb9nRFmVcOcE6M4rAGalkT0Vb7jeqhMHlQK/ozM4IOBIwCy6TgV1tiHGb9/4ijgvuimpcOLez
Akb7WK9edRzx2n2FLPSdGYzSVviZk4alWstf4uqCyw5gaJ2o2cgL8nOVAHVK9Z7Jqc+XZmureT9R
5V8u5ngvzJXB+phG+aSkxv6tnZg9TOUwAgZKQ4rE7JeUjjTA30/hVpCpeOKE0yhKVGEe9dp2qeYE
bbWwV7Wtknrodi4s7zgo5s92TWfnUpN0ggYCtTN+kWuBTm8=