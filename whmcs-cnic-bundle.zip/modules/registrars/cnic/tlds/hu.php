<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvbwq2lrnIWCWCb520jKPYSSJTLJQKN5QlGqi34UqUNvcf6M7B4m8wzxxFXhHHZ94kEjV94t
QJzUBLC8cGQXHmKFrVgLzvjL9JD5jPkQy9U38eQIVttOpaJdV8flbB7Quvb8luS9vFUdme7+i2GP
IU+B81I8rztONXbnVx01KuM+nuxUurxfz5UZg8EmljJLLUWWvNjDdbzdXpRZNYS7iWURw+qTMaiD
8B51XBt69WkYI6MEDi7G2PbEtVqFu8dXAeXxc1fyttnR8lj43fqn+qAsEbLOQQD0EW3OPIJLanVD
mRR5H4VpgqlakP8Dh8xW7gTkaSsfB9uSp8QBUshDTmrswyrbhqwjdPI4WSost3hv9cwUnf3JNnfo
NmDfNSKznb3+cdeN3sLd2C3cdOJuTxUv6mCT8mh5J2PYSJVvecruAaYmGRkZM0H+g/xgUcghMmVJ
Fg/qBgnJEE5Ewl3lhONvX+mE53YMvci7JxgXzIORsMK4XVZhhv05a2XLFhjc1Q4f9iz/FpRJNEcp
FsVTFUEizwuJ6TcIX0CwfmxveBqk49BQOLtSYDkDOGQpT0G0ZKEZ66mOUgL09Dr7jvxhjekiZZMW
NmH0eTJ78pDmRiz6qBATEbIVfqPgCuk3keGF2WS5mUCYOyXM/vUW3I+X2hpUG5+9rsfNscD5PO+s
2DcX3L+KEZP1Zq4NcV2nCkJR2NwjzKANjmHVvvmJPXSEtH44KAvOL5w6tqDR8cxEd+xjcS42DdLn
t3xPQjb/NmWRAx48w5MKxY5CJ8Q5Z7/UVmT30BREbJ4n0n4T0X2R+PRooVZcZwjOnWrvn0fZG9kN
TjwIBnvJRxxUowdD9eA1e4qd2nuuL8Btu8VMmMfu7xzW7INMDE+fFRVx0Vlj2+fw52YxDp30esx1
FwNaCUQXJJe3S6gvGcSkVCukhqaozQA6aBeNGA+6FgC2nI/PLrLlwccvT58Xk6cjZkFjvjNeJZu6
mhkxbYmBIXN/UuscClHb5jpG26j4hE3iObaYpRem1kJinwvucVVWHfErrxdYd7fOzK0D8cmd+ydr
ymii+mUcnvITIOVCaxAqnSBVr/RdLwzbccbMzHmGvLRvzBliEJrUl5m46hMMC28SDZhygcXePAmZ
kXwF2cbczq/LZxMJU6i2FwnbRGNy++n4yjw4zc7NoXwKSRclrWafLM8WfT8p66pBRpuWtZsr8KNk
ORcBAlSZyVV8mkn8Sy4Lo0NBi31SLPlIccBJwHTLhkq9cXvLgYduU8NLxuj1k8nNK1fwT9tlCzuS
y3ss82un2TL3I9wwMiEoKCV4J3HUuRoCA/XRBYXMKpcXTmFa60beVNvJSsJrWWMOl6LcNEWq5Ldq
HyM0QDyVDx2IZjrOMTJZziPLv3ymgIy8bsOQIVqL/8StiAPgBq2545kZ6S03VNP7lUzQtsljFlS6
2oDiSTL1bgfEUHtf1FSvjUvGV0a1qt5ReGZxGj5bag4TVMfQgGxSXOuFZhuDFuImE00C4gTfbAcv
s7RVGPvZJCatFX5qpbG3enQ39qlBwxRmel41VSaaN3jslLCZ05Ak1FtfIpkYIwmMiXuS7LzksspO
U0EE6k4fWJ/L7lqFcKFeNSpwDDfwJq0+/nUbdRwPiDNzFTlPjDnRhW1uHdcDcyMuwIdUx83TcTTF
i4Rysn+E/I96LnBf7SGa/zTuCZhe+qIdbJNGRt8+aU889P+vtlZEzdcGtNXYj+L+YHyVpmLcS8XW
JfiY7XyODpjpfrNJO5I/MgbwvM3ui0NRIaqH4mN01p59Ej1OWAOdureui11x5SNxjNSIiV5r4KbC
GXhDCgLmwZZ/OCFbi0qIm3h1tcM9n3WWy1y+pDBLrt1xCr3mRCRhZazQ4jvbA+Helt4uS2FmtGpF
NMkHBy01zzCMO9xH9LPhhRvkVx4o2iPiTtEGZPcuXlkQ/s0w9RVOeKAXRZgG+bOz7g6SNEf8lcMa
/Thh3TwnSSwDrDAmnHkgi9ZZo1OAYvAEmlUL2CHW2t84FloaYbiv/LnfwIjmJ+2+/dEjB1qlG5ll
pHM9bnK0oi+ztpAlUAxK9aEH8c2uvmya3NCMmJbwbdgjLbO1j2Kn/8++MacNreSp0YCB6C9NtvjM
UHTomxstkaqQD+Y2Xyt0p5QQPT8nxkrf55icUIQowyI4ZJBnb3AoO8IBqOjwUHbZYVyjWmByomAO
2LHZKvqsX1p69Oj3mTI0cHvcT4+rx6BSSZMnbZSnTo14Sn25VFrDwCOngMD0GKuFHOo1xFWWZCJ2
rDymEShINkMEf6T1hzlhonq1G6Sqi7oCjG0oyUTTBEsjy0xDQS2dG8xgYWIVBe5VRw707ZIlfiXC
XedkHvzJQdmLfovd8yofK0gWEJktRGZe05YCzTjLTgYH18eN