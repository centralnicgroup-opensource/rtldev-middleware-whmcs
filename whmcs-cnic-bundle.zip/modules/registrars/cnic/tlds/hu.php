<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/WfK9plzAZJzfh5lxDzRlD0L+5UmY2YSPguLWJcnNsbq/8DHy7woW7YDlMw0Hry424Unq2i
6THjmctZFUO4SOjZ2NmEpltavWURIPQyKEc3dfwCWM86Ukhy9mpcH/1WUyaO3nOChCdEVzsIgSPN
Yk5l9OA+gRcVftLqxPL4YPhTHGfcEUw48er/KTm21+eNFn9bR73hlorZEoP/iC4JB/q72m74j+T0
acwHvEoFSdw96838MtKQEuRK2Dt6xn90wlkgcBlKA6H8ahe357dMXSM94u5hHieEEcpxdB0f3KwI
m0OnaoEBXHu2JdHpZvzZ3WIxtBQKEebm/hS6TdEq93rt5nfP4ajZmw5XnDEzAJ2vovmXhGp8rKFT
WvD1+9zelhE+W4dG3CUBblnc79Vmz9AT+Kxh9SfhZGpOSTbkpBcPvM8QRS0sKOvyHDj+3LLMMABt
woMphevzSRpmJ53SoXjI5+vKQh2X1sModUcWZc6AVF+G4XhFjv7ABGeUqaN2S/caxNC8ZRz4OCAB
rbR2eYpUgtKsK65qsA7zlkoVM72n4TXqjWJHgAC71SGVuiacqeulFk2VUE1pWJsnoQ4jz1y8ScMS
h7VT6bsFHsX4yFGc7XzvWsiWoJ8tFjEOjUg7inbQNbxNq3WghnaRLb9anSFSKAb1MqHkgAzzX3iI
CeFsRo8XiaNocIqeurd/kF7uoQoJioU7jJ5iBbZUe+UZsgdOlBnxggqiHU55oDlpargBGmi6cFkc
uVKECgX7jd7AE9nYRqWMmgMRqpKbUFtgC5+Q3xyJNBny8kb6NpA78YskdWMtTriFCENyUa9VNjnd
UVveq67eVHIZqO9F/45Y/ei/vlCAzioydzDgTLHBf/Lzpda51lErOM6i/I/jToJOXT6TGfxLTyFe
bdfz0YTRTuOxaLhKWloX7o5zkVjk9OTUe1unbST/KNS1Ij3iXD99HsldyTvufFTjTJbttmU7nf3N
FoAai3vCWmioaWi2NV/ZwNUH8dYsoYEBOwCr8or2vYTCk/5CuQmjMnO+9Hv1G8CXsxbCtDOD98iK
b5n95WypbR7CT8TkLbNHJ86dj7Kxuww0cUEuBNQiAxtLVd+8DCgm3Sk+rVPqEb5W5EVV3L3gNnJG
zNy5BGvIaotwNHUEMF2r/xSBnrP1KKqOurWiSuKg5h0j1MnRCo4v7CWw5tINZ8IQRXmUgH5OUmqU
DxZ1XPxl5QUg4Po27evQvJYQWqX47HD0v+33+htWy6gqmxNj3+8M4ienDDgzUNa7EkSp7TikRH4K
1B7t5yyhmIOpZ/tQ8uK7TtimHd0ktyWPUPY+kX7sX6qvv3Qvtp7ziWvellTCEsH0Js0RnWzET2v/
2+tR9eEnO3Nv6jBlzUkviJjmWmRwh+2yhjf6K29O2xm00KW/S9LlYQhORXBagGqFynUANMz1sfzz
iLskjTa4Os99obCv1UsxFyCSLh9hAlHKZIXQEw/0jWPWPH0JmZKVHQELztRr4xrvf6kriRIVgviw
TCnx2mtG60EFknPq4YNEZ/hMJpPRRWEVLQ2CX/Q2ai/VXwn1CzGUDq9pz6+iTgNcXxC4d6Wm9yEr
uiuWOT+8GdL0ZUTirQmF2Qb7vTLYpD4JqKxnWJtSQCGzsvPuX9+4+RomfRFZNsgQ04arMHDQCM2q
PEPLw53Fg6ju3FO2VxOrAnCGoBlpUuPrwmxTekN0oE3QbvFACEun1x8l8YZ2h4m1vEUFye7tXl+g
vdEsB6LsTAQNDvugHO9kkPYmaTRUMDlS6HHpkyZpAmAsKFC+GCwSQoWHlEj8Qx1m47wOBBI0Cc8r
h0X8RGryRIcl6SGzr8nW4xGLkVW2g7Sn3p20iZSXmFgXxkmMKIcIGdfjZBD/CFQp0bSQ5qA6YxbG
1fEeqC64Fxai01enM8nXaZ222SQiHCRBPgQCNMEiJ1yXRRkf41Qg6sjghq/gQ/edv4dmUK7bI6gc
eVtV8zU1a7FE3FY4SzalkjBW1PRWrlS1uzbkoA+HsmjG4us5c7w+mVY1zkQ5Ja16QEFb/hHteQAx
OSWcI64NEM398rhmMdvuxq5KARBgX5Si1X2t4+MirAw0Ar/s+aNqfgRkcpFXiNookpGJLZhMWxrx
LrqdILgj4zPvyeDjemQF8p2cqB0VCQ1Ttj+XM7XLYKiTX/rW31fyjsftS9XCK4cWrS6WN/ZaAAtv
lonam/EO8Hyjf3DMTMgR9+aTdQ0H8LGiZO39yeKNUJvL3T8FpXX/pg5thhmxkq9aV15VKgy/aCOz
lnxR4VzowePggRFzTA2/b1lpv3g3l7uhT4Vp4R1MHCz7bEEXrcJIPZN4jmzMBwTqduYIR1kB7HHr
1aK0bmR5VIrmEEtJ025fZ/Mx/cnFDtD43pyhWVsWQHFubfpXB3QsMRil2zsI