<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsycULUQ24APOvNiT1IcjTqlxIEk7SeMuU4HTg0hX4cCYZzfEstXuPZz7LkYfg2ZWRRATJC8
jNmHAyw7aueHZ6uPNHsmgA4YbBFkVEJAqv+CCBxvZ9Es8n38Zjz/xxEgH33/bD9urJw8cU3AEugN
IxX45m5iwQptbLu5fXnXRrquURfzW9fp7LyxnFZUvDTtymkWBX059/PN62K3ySjepBJKd2uaFRGc
rt+M4w9/dkk++wfpcXW3yhzk9YX/BjN9jQeDRNBTjfIwBP1AAYqc6eIq/ZYkQMZehnFtzBvKfaz2
VIGdR3+6l/P2YJR+gdTHY93Pcwq1+lX43GjdDuvmQ7eSeRddKsc3MgjMuFeMLq5Fn9Ey/nrJ0tHw
OO8KgS18308wCbECZYHEVnvfSx7FuR/pBxVMwXtxjyguN0al3Y7aR+eVpaXgqYuEp8fQHI7PQ/8S
fxcBY/sGvLeMMnFhqUV1ldZRqZLs44KPOgMytejOXT2QtYJlXBLh0hDnY/mg8NNUxOXeVpPNQwF6
wEb3ynTBodFpp3IIV7kqhRBltSuFLufGWr0fIlIUSAi+rKyJitR4zVrYCwvq5x77iEH6WWsoCxyG
EkPI15di2ZuPujmq+GoFXXkWzr8PbWVbcHjmznDapMFTvMouS3EL4wR8nOA77ly4DP6sSQ6rzyLM
9JSw+IFwGIXqelQHe1Rvo30MvipL/DDolrB5Ajl2dD9gMbkgomtNgMG8IuYdCYpROhDrXo2hdjQQ
UP8vWqTgHnADb9Oe7nWz9kqqdIHMGTB+uS36xEzGAa14gcvELkcX7DPzPXCNRGHY6mm8sGmia1Ah
+dZ/qwzGwDJu+jLCeawrlav/rDo18iquzV3TQ1bIEBQ4ggnuKmA+eP2ONv2WDxLXo3s7/1OGg+6v
C/Cz6V1EYpUpWNv0B9GcffjwWKbe0yNJVyROjkPN47+AOBf1fusXiy/uM0HTUF8vQAWsGbWi/ETr
T2CzoKVAGO+hwkz3gyLYCCeoNHQLdC5KkevCbJfKDVG6rz8tw8UjN2t4rbxOsIUna149TDcKFd/o
jogQ7ZOS7r0UjvHfBxzq7ptNcV4hd9utdIFAQnkYIHq6lyF1MGQDWbv1xq4KKUZga4UGdqhLnPBE
GA4OJNlXvtp4qhSfCUetdJQlTcHTXZcHDUhwCbElip34iNfYWU4Cvzy2WGSGS7i5s9KC1Jar60Qv
RQEMqM8CcO6o3U2XuDcZm9y5jQcIh7Fv2sQShXftZLXB963wpd5WisgmaBekD3+6TXCb0/g1v96W
hse+ctaj8XLxoRnQkJdsFhZ09Xsd2NzzBfh0SxLWNhyUnZQNIIRYIO14elbAiWkf4t7/I5q5Wof7
9HVPpAfbYPqc+sYRDlJtpXulpX3Eg7GM2QQ00FxmXaT/V2X1AbYbwRa/PpA4AiOx+Vxd3RyabmQ/
r36IMiTM0QzAmRNjST6Yjd42Dp20RdU4PEgdFaCzgfj8njow7i905EszCSZ8xKgBUvzWliDkrOli
vDNbtndf9JQCSk7ue8ibd+9jqCrWdNUCtOEMIGPvL4hPDDbcuNfu/sz79+fkP+TGd+McXEOWS4/2
1IYrvgqdoQNeqP0bGEdjQ2VlV19NAbn6eR6i/GV6KSorZDEmOfzB6zIavA6IRPSQDgfLNDDOH1R8
wyY86GLfwnH9m2ggD0r9zfFpoHGGCOwLPC33QiTajZlBXcYEWffcMBdiRDoplyhUPrFiwV9a7j3z
WT9MciPpWKHDO5E4PG2hzKvDm38PTAr2XD/5styeXDTNHeYfZG8j/PKaCMynddKfYfZbmjfrB+uk
ltVAQAQ317jcKsslAyljGa9Rc94Tq/vAL67uTWIkueOcoIqoaBL99r2e5Bvfp4RV0n+9aLWjSA4L
ZSUUALAcbDFne22EknnSFRUR6FwvDSY2ZUr3SEYYg6UsbM9Qu5Yi/HvWGY7/cwEsDkNCkVhO9h6a
MtO0+nbQS3932X5wbuXtpaYzR6Lgg0T3gVIXs/YADkD4JgAdNwiTTmkaEHKoGNaRrargFLu2/DPW
bzomoG3sawqjhD+oXOEh4fZmMQi4YD+rA/LwTIivf2Lb1ocGzceN3MmcVf6sLYCNpS5pQCBMOJ+Y
2vh2XTCKUG6/X1YWJfAqYs8RlU9Msi+Xgfb6AB4MzK6KZgxPlb9kPOTyQOhv60yj41AiTW6bwPYC
Hubf/UaAx/vT+8KFt8/BMH+kDe2McNz1GNwOf8xFUN5rlElbJFFGm+y/cIfs5AK/oI129kxKQH6t
O/nFVEkaWLM3Gz5wT87wqc+aJQgww3lTEXUGRN5TWGhdwUSSmXl38DLI7/VB0Keqj0DXGbmxVBWm
OWuzCn0cLDg3utQkOjPIXQHzGCYNseAc0m9PgWGCbnFQa8X5sn6cXfrfkYeMMlS=