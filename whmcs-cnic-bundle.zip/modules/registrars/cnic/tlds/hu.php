<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/NOxICU9zOKvsju09nHEspnM73wGSq6y8Mu9s1FjIdX8LmuAd8/WU5ly57bOllry3jsDQ6N
kFsH3uhYxSplbca/jmApgG5jIsXbex43ND5SHr/UbfnBpj70LIDBMYj7GQj6s60r0GcjZGEDeHKW
Xa8DLUcPq6oizzHohcs5SC2pA+BHuyVdMVWC0ifWAKFYVD4kMJJ4bk3pT8W39GR7zYsU5H+UZABu
preuGZRhJe/UOmVxemOpCWr/wlcxqFVuXUJX7gppYEhJ9G9xXWTad9nBMbLgvOghJLc8LGZ9XjYN
1GSYQqil6fesjcXTpMMCL70ko3x4PclQI+leQyQo80giYwpFiHVBSdpHg6kSFh2obKuDfYDteGQX
weWNjcE4OoCGeNQS9KiPxmbYuy3Cxy9VEoMKfz6UwcWgeylt63NLkItupaKRULniowIAnTgLWkf9
ao/Bwtb3W9jydLcT/Q8u6P4XflZDduWx2t37UC4NXmKlcYOz8c57GhvI3DedX+iRRLU3wyw90gu8
30udlTIe5WknmEXlRe+Ue4+OJPoLTpv+u9r0UlpAKtl2C4VXRVfNHjTtppN0jyuuhyDpMGTZ+w7P
GJUGCozYVwtNd1CcLlrAv4B7Z/ErIlnp7bbpsX/XuUXh6WjFdgMQrYCP7FW09cISFfw1DZrtHGfE
G9jTAuAoNeTCPmjOFTONKitTerSUsMfOttmohU7YdHWToRvAZI1oxKDD0WC7sB/5S8VErBdX9sIH
n8ik9M8UMcSOgsy8aqxcQNvy+ZrE1apNxYzyH/o6KSsH7s4hc+Pn0U7wmhyDXrkHqbRvra0AwW9X
LLmEwaaha+9spbmNX1lEb2EfSAO+VT0HMAOHpXrDP6wjUSJPUt/SQPWCWzRUA8MTLKoV9dvFrvQx
shZqa4xWHMObqD7uqpBjajEtRe9fpfSVirmvtspD9nH/XYhc1G1JnMTRx5sDirlshuLPvIGqbHKS
Of+kDcrM7IoJO/akKF/iyvreHosYdkxhwHA+YCn+aBfZ9pF86zk2/Bcktx7rsWfPBRkvzM31VMcW
epxDlyA6cxMd3E6ohhnLyvSchxtEEvI+Xpq/IkpxVWpyu5aN/nkScot90I90+lo6HOXryw7LWTKw
/+Ph3kv2X9zoKfKZkKZoNHcpR2dNNgA9THj6w4OtQseJ5Hnm5ngT+MuHJMdqA4Fe92mIlEyEPHdm
TYNaYxYwRgEVArr4rQTMi4MkuNGkCaJuKl/xkjEPT9RAy09rlE3JIqoxcCZm5unHpNrKh7wIHW5b
rN0K9/whFYb2EddsnGFO+1CLgT67GLvgVDoXbu0del1Q++01nuxEgVLo/wWKgjwhvLEY51amY58p
9PIXECOpULxp6/iEt+iux7eLxVzLvq6Wmct9THvRZyCWsN1elUl0W0iRYBUqQ38ivivJkuJxWxuA
c854C4pJmNaGLBYxslJy2UmiM5iztQtknr/IYutQAtGm84FCbDXJdAiJN39EMp3g9eoXcc1H1q1r
F+H/ySHcl5LoUZvLJLAekK6OtG16RftyRncvYDwf+j/xuBhRgCP+Vx4MCIXpWHOducYFB1e27QmB
LNFVrU6AYVzEmgCetBJSeFBi3kCF2/g7jLvx1KJgmfv/mOIT19LHg1AmELJ3Mtyr4xxxiT5nh5hk
1hBNMhqFRYje0KhoOoiaR6f17uEuJe2+l75+dj6JiMew2fSWsfc/eXZQOTyJHYnlBDlvY+CKsaZe
xOHCMlPbRsCD9R7hIeY/TbDC4/tfAryh+q8CmkdO1bQuyrS9b3S1VqnUuUJyc8Nj8lbG58cu+fc1
TiRXtqK4SBb82tOF94V/jysLZA1xJoPQrbwVbzZJvYMTwn64IkoWCF4103QEiNJbf3eCBPE+NWSc
RdOGhjm//4T7pa3fV5NLyyo212kxadB8dG01CWcwAfLJekGzlvp6fMcxg8pxlsTlCtptd6B7rbYi
pGzxWcv0E7nF9HbvHlE4HIrHunDACyHiAsbj6o+hufFVekh2pHcQ6nsyod4qGAClmIH2ZWlbzvs7
IuPLesMXgBIc/+OafeSNp8OmDwNTvhfT90zYarHIDUXFg2qDX9PM1XzhHzRz0DtHhyerx4xwtUND
X2L7Bl+EOoREm0y6XVG9xw1c3Ri6iAdXFlTUfS27255T4ImxsddE64qHYLYstDqRtf7+FJyRN7Oz
ImfFix6DiSDgmT3n37mh28XSq/qJf772cCgfwRQcNM7CFhrnItG5W1anMrjPgt8i/5y1U5QsnPrU
fruluhh8q/BT/pqfD7r9KWzK3NUIk2Szoy7eyUn6ENPhNt3/RlaN2SnOv6d2TgxD3dXPwBg/YiNe
yQPlDeFrdetDom33+C/JzmTEWH1o3LD9t82mwNH5LaEeAPIaJnQ//z0=