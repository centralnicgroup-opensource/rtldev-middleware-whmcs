<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtLgJTkUjBKSPzdO+7/SS7mjC8i7CKpcoSPFdcquFGcyQExl+8PGhdDLfOQNx3ZJdMXfTK78
0JsC0iFfxmzv4PsORo5ZEAXI+gzyCJyApahKhpjRfPSAhIJxWYHgTKqFGPbP+Mh/CwbHOf9ee3Ag
ZnjrGBfmNeXUqCgFCfh58J8JMpw3bNxwBoUevBOZPp5zdVO3Br6LLT+n93yp2K0PC6tm9hJ0c555
7klFyKjM656kDsUTLWkhlnQq+dBBXqIPc3jukolV5YMD7m+6kdsAmHpVv/o7P0fSFcKL9PBuUbjD
9rD6VNm2uZwJ5+oxqunR+jkSxGfA9xRDyM+kBj8KSadaS2Ahyp6nGNeTL2ownrQ8Ncs+MqEcnnFG
kpCVh7xFlfnyC6EDCRq26l8CJ9QH31exp5xJGu1BX87nbrEStKZIUxc3FUbNnvm2AdGHZQLeMD+m
xNjaCzLcTnt6MDAzRpuudP0SWiV34yOl0IJB5U982Oap+cjG8vm3/P/BKYCKm1Acuw8DKDkcRb00
6OBcMJOHoZIkTL3XK+9GflltLA4VXXnD2kKIoeEDa8jKVeIt4tEw57lf1CLWa9/KrKXr7lu67uuc
FivwaHUz6zihRHF7XivoHeBWLKPwwTyB5aOOHFKMuez+4j4zM7xfOCuukkQjfo4snkG3IzqMzZNZ
Bvhf83/bVCTLMEsmOXc6h3JGGnlWVZMetKRmm91yk7E10tlILsinpI4wPEwL1aPjw571iecxQfY9
O3CwJ5YmbER5wesT4WIMSp6EX3LeX9s1Pdp6wAjdnv3A57qJYizzYZOVk9TTrgZk8k5fiJY72tvt
uVNDfY7LTB4TvY/nzcWu4KvfIvlgM2B27TareHyGIms211ycPSUPekZNsNsmPDPduAP5sumX4jW8
NZwB6lA97XqPqP7XG/uXX9FGqstyOV3Dqyh6EPxykEx6p+wLkNpO285kCNPdBtzMjFqCX3uX3+eh
7fRu4yQQbc5QG7vLFMYJmrMfcswa2X8ZyVrPHByurQ5Ns+aFrtnLkjHyo0v5yVk/1IP99wLVT536
MhdPBrb4wnr4gri+LVUnqRuCVRVw413hndQv8fOxMANeWFYSGOXonIFHKao8QhE8tyqboOkX3bzi
t+it2u9qAXvL+b9VDfPo5GiqXrkjgd+PRVgHGmZKnORl2zhmuwpUVGNNr8Sozx3ZY701QplBP5vK
39Amo1RLgBthsMsdGs5us9ldLMYi4j+pMmb8XB/oIUHRHVtFqPBBxoZOWRxFCUbavDK/VNnV4SXO
Yl7nHneKj+HtVyGK3cDpItktZKZKLpU6loAxXRqlyRb9HnFiLKg5GP8g/Sts6//ZQM/ZnFhKGKI6
kFwX9FH/m0vqZhSm9XXEpyBrcPkwWiiCt9m8wQjUJcBLI8XGBPKThlsXwhRnYmCQu3WUeYfTwyHt
apruJqXgQqS7U1NDycYCnIJRhpqcc16UClXyJJ5+dNxI7Cpt1dQR+mgBId6rNWuYI/2UvRF8OD3j
eota7EmBB3LX5tExlw6bE1d2yCylyGWEgPC56uiZNQF/PBnQdtlWBh+yQ4sTzwDhkZN8/AgzGLin
M1xiC7YCVTwyuJWCTGrhBiKEih8IBoSO8bYyymF6ul5Sv8KUTKcrBoyKkgJE426f2nFZKeyUM5Hy
Qhrnb7vPsxqVdh5Lo7qSjUDA9azKThcmRvxTyxM7n3rqzUnyO0ZA+kXTiS1gCMJrd0hjXBFmZYoB
YYm0s7y4VXdaQasGVEeIOH4L7cJLysEBzmf2RJHRNGMd4ij1w5OriM1Thb51AC22DOLUontAWEli
WZvm8/PHRK5YDg7RxsmkycavbHkVm63NhuH8La1gqPSJ28SBjXQfzFffCePtplBX1VD7MJ/R1DEC
UvOVE4pvGIs0RSi08isdolDeehBkDFlZ0hNfYkR4LTn2NW550SwR4BAUL3NCWlcq8QykRq3RqIPx
pSzpNmBXQ4HT4VAkJVPnMYK0bHyvgyEUSE7qJYEhx/hP7M9fdH/G2OJCBvjYsSN+bMiDWeM2HCiK
AtS8qIL57ulLRV6dhCdM+AXR/vJR3h+7b2zzGND0hkpKKyO3oY9ZZFmPJXh4OtC6URz5OG9tI0uD
C6kw3lZ4aXgsP/NCMa3gYVhuK0zukdDPGXpemlPD3gp8D2aNluRGE5u2JdrujkCoG0KMdmfr4erd
13vhrD9DXFQYyTZ1l1rCJN2KRaTwz3hlesKuAgy7tuNmevkbZcVtEJv0pSZ86wXohjHAfVlvm2uS
AsndWLJL3yjgfVfTBvUOVaaKDJEceSzBiuTEg+QaaXSfNRuBshX6oMxthC1fZ+ynnDtO8b8HLZbs
zkYmb7J0rPxZZ74rfFUqyYyJ7O2QES2MS0hyWR6JvMf0Rd6vlIWIJuG=