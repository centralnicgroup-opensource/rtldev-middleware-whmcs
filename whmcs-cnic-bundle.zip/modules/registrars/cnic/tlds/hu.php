<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuSlbwhDzckDY9m2YH5Q29nXQBnN6PXScvou1bjqBUDxZ2FiM+Sk0s9Zy5D4tqIjlHZGlFT3
fiZc4gCZTveURYtF45TtKDW9joli+ApnBjXLTfPrWbVvEmr/OZFRTcsD0hBUmFDTMY5Qxmi4Dn5w
ICQhAxNooIJCHxJ8Lx6cn3c/DNMlzUx2bxbtqPCCXA5wNlhLFceSnL3Y1z+huFyhI9LRXoQW+0R2
ynk3TkeEFgsT10WA8eaN1D3kxeJpNfp6pI4fgu3L3W3OXwtmeEhzGSlm2K5gLxOzq3Lj1AAKE0Qn
akOrjXA7Ce+065DcuIBBil1BIqsaKvksU91nG1XgqumS/OS2kCOzvNEq+3Ib6NgsAJ4mwhEQeFuf
1UddgBzhwa0EyGJjhyBtQEVkJUwDA4KxJMJt6rK4kmDDO1sGIHpXIwJuv2/6te4fSt8SNqLk6AiX
iAdBxJIb8wzGCOF6HB20tcw6RoTvVd3l//zmqctAQ61Bsy+obcxSQRTpZjOVxAoDDB50S8RO3nmv
EU5z/AD5z09MJVGu39wUbIvgIBe0rEC9WSYK6GXeVBTpnKPx7FRQUU2If4uS1ja9bPI1MsD4hHUZ
omJDIN/OuVEAbrfHNBIuYUWv+fkGRHPdltAeZeU2QozJKXvJyFO0EjHcrDvaCm5bQs5WwZIEMvV2
NCnPym4g+Strd0caAbsaYdal2uMnO25IIYVz+49d9S2LV0MDaCbzSM9fOdK5EJLAZubjdkjYAIh6
C6edUYIUJNQhQgkeg2us4sNedJOpNKNdDS1b5VJ2Y5Gt3NRLhkZKlKk685a/sprphZjqlk3pLGSI
ucftXU87GorBAdOC3+eJdWPKLzqtps4n3ErFbPE6OdX3uUq/kWUPChLWTtFYwkPHeGEtrkJcIDyR
8X333gE212Nlvj4R3FBhsE6VNM+dRYPR7uD6ThPBllP3l+e7neL4etwF47IhCk8if7844VR0Xsnp
OVPoZ5rk4mVWEFzxxv6A0KBAWsyag/YoZq/FIXeEqKPlvctbXd/AkhA45JHpmOJ0oxktplXv2zop
Q6zqHuOYbx2Ih2sjTIHg1gkwgQOgdnCGDPT5UHU2mLk7NLjYc2a8X6q8dSGeM5mDPwKH66ozkA4f
9DT4kFHvf7Sjf4Fgr2xj2yABqpfH8HRCJ9SEu+h4TwRKjupnWIOUzRaWLSB1DNkg/c/XOWTohgyw
aUsSkDk8qo2w8yPIvhxP3W97HPL50UV1Nc0fb+Got7E1YWdVe76UqTPwmosiqSiLoUR2qLHiNE7m
l1FlG2D1Hcf8xPK+P0B/62XUVzIbXdUlN0FRX74jtme1E5hgW19z/xws9AGrCXEDrJ0FJ57WsI1j
CF6FVjKiZ5P2RyPRCR82MKU3MhEeCdOvuOeL5btKQvL2Ot6VCmiYoVjpizH350HTg4sphrmliKhc
5bBi3IQzeIeSa5Axm74UKjCvMFy/J7khpXXNbSvcWUaunM5D8PueVO/TLYGbrrpST+NziizcUGmP
1HDD3wrgFwJvVG/TNm92fvGg3uEURwzPbQAc6KECPK2iMiK8ah4j/LM1gmgc5b+tp3XIW9/0Po4g
KclO6uiuMX00NS7yLoGepwJWkVeX4cQN92q49KoQwZ4jhIiYa6tERFYhDBoL59g9KEeGuaobD0uB
6TGj1KjWTEMYwti2+QgREcMkhEzt0m1TG1NXeR9zaBszI+QODf8Xt96y0UP8A0zLJ6m7l3IJVxHg
+BtQcPViYtt92iH4aOvwyyB8klq5FeoqI+/vo2jKZc5w437D9DissF5VPbDDsVqv6OczPBd+88zp
bzBrHlwGrSmQDRbNkCBbSAeCoIkB0t/2ZnhZyNSTiio384Unb1hGOmJmLlbgM6CPgPjGXhuDJEhx
r9zaGHrCXRh5ivf8BnXxKdtLK0ruXS0UJMf7JtfWl2eWHLZjz3NausiR68sFpNdH6GYSav9RV2kc
+l5by2nOgN+VHMotQtnsW4LnJav9D8xxMisaRCi8jPpwgIRk2IDTIrBXNOfOU3IyL2C+oiDqoBmX
IJ8XGSlUF/2U95MTs8TLlE6Ic75PI0hN4kq+60mIGFgrNHfJ5iVppdmrc1qDCxBWGV8+WHHAws5k
atuONOv41u7VZsTqDXdpS76Iq8K2mShFYK6Ul1lVdm9afMmR7QNBDusnGtmaRY72VPWANE7xCZ1i
t97U4yt1VazhLbkwPtuCT7CqRCQzaNb5SuE/IdXI0Fao09M2XhIPP0wCRwqd3PSOuCnhOuxRUASq
k/Tv0UBqZ0rYIFAQQxAFomogMvQ2BH6cjb+VYoOTYFfJbBOiEyTYaT6NdAjeAdi5Ot6tHu75WyGK
6MQH9SXTTO0g4M6ZNFucxME2/TgjkktTpNGG3K3iOlV60+AYxOQbbW6ZeVfUH0==