<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsaQ3m5yvVCsUQcQ8gqv+O9Pd+31ArG0Tze0ahTDHh1k4Wt59GEJ8/g1fV3psAVXn3Vl4g51
qOzNsFg/plBmC1G2xgDl2bzlInPx61N5iV0sqBER+ZYjp7K4M94nX4THxzJlPnNRdut1CetxuK0b
Nt0sh/Zsgr8v7WmswfWOeGrZhkw8cGQeX6oTWs+8mT/jK3d9/0xGRJNLrxPSWc6r3Pznm04ULRZF
HOK3zYV3lQZOW4J4jCAmc0x094j5msxAwyXHMlK/cQ9+BasLC4HmKEQIKNDIQqiTgSQHs5l9cZiw
7Hl7Ed3xPFC5t1HWu8zkwR1g8NwFDsi920OBY4MmIqI5HlqwD8C1ZRxMMCLLeh5Wk6p9JsUJAdlR
BAlm5H01c2ubAGcKu8VRkX4+332Ft467Y/BIk5ptZyJZmZ88L/lG9WRJPU6ZovpsXtu5w0lzv19S
RSOXcj0E7BU68h0oJOJRYUMGO7C15oOB7rY5QZ2ZIPiS9EME5H467l9H+ojaaVaFQj6NHmGxIi0H
gfuzy9GqG6kzUWn0SKB2/7vRKz+ytfDY3ZKAQ8K3tSM2LnGNXTGiMLDg/v5XAGIDYFfpM0mMn6p6
cLfK4rrtUzTkMG+3vk6QXrSpCiYLBktgO3Jj1R4F33Bg1qnQ+FTX6ZCd5M0OtJdeUbH2XigooF3e
rWhpNWOpUeTvIkd4BopKuxaR+6NOzK/IOqtmd6dX41vJzxCT9R1MTPByLnW2NpBmMiWssNq3pHYg
XTtXjWeslL7oM16yK/RJmmSb4aCf6HuPsggVdsWiVa9RPQVo1h+/KkqKy3NW4O9AuLYI6vqCFXtx
fOiEKCxc7lJ+Q0CfC+foL7qGzE27tPdTGcK6spk6WY8Pte0laxyPpUGS3jak2ByVXpFS9mMPXbvQ
k6Ylvj6RUXwCy0r6hiiP6j1kb+ohIV/kpw1KZnq5ZKmb+9Yj2NbvGTM07KUh6HtOaIXq1ukrNh5I
xk3FnmefGBipyUN2+ngaq4T4ppQKQTsxAVX0+AJjyjL9yiyQaxMGx7dV35Ix+sRB1ejxvoVQ/cbY
bP40Gr0AbmKF6kzkg8wb42Fa8NYH67HxJaT7fdc7H5wwpLtuaRcs5jSYngCkW3enc4y6oynpvDby
+QoWpFnGZekokch3+jV4KRgsx2enc1e+Sf6F72LMX7WQG/Vp5GYxAxEElmSYeo063HsiYolCTXx4
63BOJ5D82bwxBAUWHVuLffIoa7PdtC7UUdVnFRdXlyBwELfUZjITZxqT/Nakm5kz54mWB0ab35WG
9JXrEvygyphynLUXc0m1Ha5tnlhvvWsyPJq/mpWVzzZ2suWr/zY3BwZAvoQB+cAWLYJmYuyNIdhW
KaDk39/Nfuk7XtC+29sUk0RIWRrkiIrMKNtCbvcMjp/QKYILm/FCXq2CaBnXGimDOv6mtLtEwebw
bwKcmTnDdASlHzOsn06k5oFex2YarJsIOW0sQCaoYtL+/8aUVTrPLZh16kA+mjvzQAdSXeFxUUdO
9OHfQ/h7uFjb4KLHO8ucNS3HCEb/xXxR6Nd0Y+3pZpWIafxGmBueJzNJhomHFRX+u0CMygAAXxiU
Ts34xRw0CY7FM7R+Ay1sDiwN9BQbezmm6h0QLkcblxhqHX0sSdrL9XTUPYIb/b4PDjGGjwEZfeHZ
bcUPGrEs0UL3YhqT9fIH7IvBfGBTlj0I/mBiiQ6CQ/vHmNKwxYAw2xKFazC+R86jrVGgv6OoxYPH
24/O77VnDuSWTwnOzVj8iDFFBwbgkx0zlMCZOhCXRNhPsAANKw7sQLg7YVQRp33ZGfknQT8YQCVd
aAMpNm9SftV2TLw9eio7/6jrCHlCtSKCubh4FkAqqGENkmKm9HSZUk/uby0ptYw4QHSbPtPbW/3b
W5PKWG/xsZHuHm8QI9Dess8DK95Dkn0Zaa/l9JvdHLyUDgreke4iek2QADUhr9iuVKEZK/+2eHvS
nAp6NNQqxTt9VaQ/h0qKZ4hvpJ09Rb4l49DJd5KapV38OXNf5Y2oggfnrmckzO2h2NZko2B/HL/o
qyCK26Zp/8pYtKgjn0wnTfVK4cnNi19k9ugPM7082DNAskb926TV5xvqictdXTVKj0zOp/E9+7Ks
pfLIc5SAI53MYLNmpRNsCL4exEVQ90aUQAv1JaCQeoqgBqQ3Wqqp1Kh1cWfw57HNHfuAGuFMbiu+
iaCTkZ9YQzj01DEFMxHKLHTOyp/d9lDNzEH3TBKfXHRxInlDJ+Z70mKW6pPyChD5NmCCZhFqMqs3
4a77RpSu599TYXVbBNqbv20vom10I3We2TTTl93kH8fbrjxQ16sJWHjTQXxN9V9Qxke4a9oQA8MZ
b67my7iQfleVtTBUI/lxRCdrVf6Fj/uCO0mnnCchKNhTCwLtiaMd+m07aG==