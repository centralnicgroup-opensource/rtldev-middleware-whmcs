<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsdWekfXJnVDV5CtoQLZzotzoKH+8uanazYMjrd7ZWYd7xHDI4Werz822nFmUbPXckb4LFvP
iqyzt9Jvt9Zppy6D8wqCUQHzP5ngralG7Z/xAHZEK0j2D8whFIF8+/tLQkWkM1x4tipgw62KQiG2
YAAiwmjgRm+Ww2o+kOkanBkMz+ewj0VxExl8SOErh3d5P+uBFu54Ty4KAniLDuphVXAP6MzkkyW9
VjFfE448RW6ua25s9r1pzMWTV1oUKLyXVDblYwrS5tMYy3cFZ8SoiT8/1a08QBM5w6JX9hwengxE
5tldBVyR3vQSfIqDO6uNZrpRhLEVUPXmJIyODcOK5E/jwbLtnHC68ixPolauhyVSVEsKdKeWiYIk
KtQiAPLzUdIh8qVTnHE125DSrwytl8xGqNUxNUymbCBqNg462AIT2Hgc6vy8y1hHzeg3bwIjjfHj
QrCHRdtY60lUaPYcX9SVSwQR52PO9YrjFGYqtR6K4mxZVPComAlBt8D4Fik89W8a1DHs7ifSgndB
80EY/Id+kfu28oswvRygTQnzDaIyikduWdzAcHr0ZBoIZIABAMq3wJvXM/U153FxmAR0d5zAq1lv
2ufRDp4INF2OrKxZ+DK+ucxwdePtUdVvX79o2U6X0AnQrSoMBDkX2Tjr5irLMQ2fAtpgDnJqRwNy
dAQWcPq4ADHZVofwXKlrH5JPigec6apFW6mcFQEFv6j4Xg+m4QLJJGUOcD5Ev2Yv5Hzl9b2LHLun
rBMaTT10PUgvhyFaAa1Y6FVRL6hcjxQ56Va3KIcLLK9+L70kZI1/RzYjz1xdcznlA7CAxNOjK/+n
lVXa7566LTXj2+31G1w5xhU2+xNLl3J53Ac/HAAWxzNtoVB2ffCE5CBZ4/vU9nfe+ZPcsH1KPx9o
omj4HWCCWrgwibdLl6PX43xxxvhqTYcIxbFm1YtpX6SbkERSPEGiiqIbE/McJSUhrZtVjn6mRD5C
dnDbuuhZsXJ/cP0eSopjKkHklQS3Ew4uZXU0+9zh2j5sVBVaRWcp2j1/R/jEQ1vbMT0tMUYQXVN3
oXyTk5JV95wfrqtkUyMCdIcIbv/ag6fsD8BxS9Z4Wj82WIOdfibut2gerAGT0O5DvEPQjkuQHABn
VeK9O95G21b/veHZHakS3zWTiRf2uOxQZzLC1Fkvr53LLH0HIRcC1JcfcODAlcgasutRpMTczB/F
y2gIKB8lBZwu3QqbmXJTq4TV7YBvPFjtQxmkwYTejVCCVODwyNynEgfZZ/+U5if3cRL9ygCTwEMW
pbvuxz0u84Elu7PUSVXqR9ChTuX5yCSa6PCU8Nt4aHmNalJmNhExnJ1P0YShQfoRbQR2ykVvO2Nh
+fCi5NjOOayUvHtM+iNknJX8Vbh4++oP2c30ceiwT6o0rjlUeNEVYkM+G0a8sq8KPQv3bA+2CjGb
TCKg01JlRyGE1+rA4MQ17kEUGZlsRQ25hzj13gGh6IZPbgfHEUBkYwThLnl6peS0rLOHZXe/EI4A
gHKu76L30kADL1agCiqc6lfSqxCVGzFT3YBWw685rlNaO4gqccYfzye8LrkFLPxkUajv63IL8AGS
+e79k9MB8neuMj9xX+ASGFMKhOHDXoFW18jfExpLy5oz7z0sWHjHvBENvVD7IFryHH8lWpCAV/Fc
CK/rOJ7uJLBOmg5huN3VlkjhtVex8438giH8z7+R6HBEQmAPHJOISARi+D6iUVYsKv3HO1NlykZq
naOwVEM5XGg5fo9b9FKl2oer/4i+2tih//YFd43rFy7rJIfFnKNFQVmxoWdB15ObO7UZvwQz8crP
lPKTXEe3dJLiwApfsBjLEAye2DCZreznXtsKVAkVqUSl1DDCyLKLrcBgpbygGQ2wDP86jNcPfgE5
CdnHBSsBoh9DJMQQytuddA8OhUaXIYZ++iwI1ViQkur18+GWbhdxZy/FpBVDYa4Wr2PLMMinVbeV
oDBfIl5yfvw4wOlhV1s1bWMQoeghSLv3VV4MJRVnUv5AObGksYPmfGXmla8Yi/QIbqY6pyLzNMgp
6R5XLVdhFOpX1TJ8iBtqIoM95I3BC8AcCBCW1z70W5d6uJZvOEQKHV6W2oRlCi2ftCZkA1x0m1L/
iRZYDTFPlKaGUoJsmzkzlfuSYdE0g1ihAxRGHJBDlVhdgq20CliuWlCgu4uDCbvWy3JZMRdGdnSu
MfysDnddI1GMaJL+3WYRHtxSgRBebDPbi7q683GjPfgNc9a9gRqSoX3UrPITi9v9d4KXgvheRkgR
gdXusb328n0igYb+DjOql0bn6zXH7siJjG7ai+tFI4lXJ93VI2YSifHxI4xclmNa9qax3HmvcZhH
5Nt5m2gGU0+OTFIzXE7BjY3Nn97TNGovn3SRSVe3aOBOIP+aMHMVnW==