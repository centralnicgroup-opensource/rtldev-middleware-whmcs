<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrZtdaIDMMDhI4GBPq1tE53eqaVZ/cSQg+zhWyJSnYMb+CtdgQNj7ZNVVzCFEuow2Z3wwe3Y
3RApzdqtEzkKx3FVnfr4pkmcx42IJNBuCP+nqRCErBEld1NHXWlT3iGji4FWJoyC/Z5HmQ400eIr
+AXJatyLDbVYUvlwhdCsD0lMdvAMomZD4AN1Engt+nr1ILIWFGALDfIIEokadvKN3Pwy6akx4h/l
9/haDs5t3NoqKOkq1I/57Kgwt0wqkf5VO819Mr/0A9d1QnVt6YUGhGaKg6YPi6YqcqVEY1hgTSEk
ruOuvaR/vvMDFX8i1ZRnStEP+xUMwdTUq38Qxt282eeBOHor38tBUhgKxuS0BFobMrwQJS9775Y4
r+Cv+770+k7E+6ugDWH/6EGIAYVobAkzvOXdCIoYd9vMl2Q/L6BHFONDc4jTtlI0wqw7l8XiDaYM
U+jx7Hg5Zk+TMEJHFlwmhy8QXYUWWjLD6Jchupr6xo410fd0pZiHqPSzmdSwY89v6FmxEAaj7LEy
lq8EybShxmCHU+KDUKE+EyZcEjprzlN0xRPSNTLMBdwXdZA57bjOGjK70VtfJ9vXGhqe3Gs7vSqH
cJvVMIbc1PFX9KLQtgTVCsEBadRj5b2+VeKgQ9a/qoooNCu12y1Ep5obqf7RO2eYsKC2QtTpdgCL
CmqZiPS69HhGkDPfCbhv6YTzlK/YEsJKkz71ZELsIxQElR9bRsvC5eqdy3JE1VW6/dGWH4EkJ/s9
E4iZLN9de1CuKP6awvVOSEh4mnNVFvZuJlmsYhrOJ/fFPf2rbFR8n4kBfBSgv842eJtlTK/SII6Z
y3PsmcsxIKUCMO1B00JQx93wIsCro6LA7rUm/GpclTu1q194dTuWbC85Nv608SFMfJ90RJ21nmZk
sD0n2lN4RO3Z2oKAMPmgS31MyrUE4tVb3cUc0dH0o/sgP8o9zaPpzk6m600JpOCosu+Wj1Jt2D6V
85vfyuVfQaGa/xztkXA95VeQYKTHjiF8sKEWLjQitKe7rEhyCvsNX3WAAq57IFbiGc+NA58ixaph
RSU1TZyukIxuGAMNCmUeg96/xtJviJjgvrKtYDGNiU5k2NV4k/2Z8SKtAV0GT7JfT4AMeuSSrMwE
hba34exoY1CG/AXvlo3fwOXx2LzqS0e8sSrlbTLWU9qg+bPB4kLRm4HwuwrqB7RHsYp3R3cRoS4v
LZfKn7jQuQSowpwCHZ+eN6R9L3TcwMYwWIfhMRmxNkrjGEhZxJa/SnOZ6GIEOqGhwgP4JgCMoZ5F
Dcjz+TQpEwDbqrCL8lynhRjq+xU1hCGv+Ne30XuIm3LPdm+gv44gRLAw/3JREqxu1hCbIbhE9kdl
RJIH5nN1q0FtBf/6sm+mO5edb516VewYWJ1TeoKLQkwWMPfOOxMIIdcj86x5KQ4skIyQaGFkkOM9
SnJohfRZXTgNrbeQpcR2yb1bIR4KpTuWVtCEnWxHMvMzQDgfSIIvz3rd+TU2hHFnR+CqGLg8vyHw
KKFcNzst0+bYEgBrrBZKg487h3S4HBxkiRoxQXw2KCfKNmK99lA1YIxG1SJD6CJ/itrMwEyVSpAp
Z1APDFUj4I0BKr3s5K8lTuu52osTKG0m5z0WiStqlwk/zZIkqTgoHhnNlIq3aqWay5/N9i7jdS+O
d+cgOUxEyigiy+W3Jpq1UnYmWeg2e67DJVBCV49OKcIoBpwYWs3au6wRt0/cQAy1jcP/nlAVL7SE
btPw5cnUdtAuRtl2CRqs3XEgxNQrYSDLtvMQRWAZk0xFmRzOfW/HPzn9QYLKR9HOCTKcSKcNhBhx
HqqeH5jeXjnif7/cdmY6MPSLC+V9JR5a81yrNSYLRSAi4ugHJ+Arv3Mprf+kpXL+h94DuScGkYFZ
y+AeRqGVqypNI2QbPNAF9pd7VzWlmq9PxP5tY8m/8+42e2YRX/UrBIpXe/eBz1c361eA0nZ85e7G
rBd9GLV04Y+0AIGjV1g9zi4E0zuMmxrAmjZ3VoDD51uHY4Hcfxt7cpKZzf7jrgTIHzvNUDtzhsOt
eLYHP1OkYGR82JYolFR/LHOaoFIuAZDkklo66VhVhn59TfbG4U+v/gbcdJ63cDVFWeKKIkuV0ene
i57XQs5jaYCkAFyNnE1pDW8J3cpLXYymwJ5mhPfGtWTBYwH4xM79o+NYC997Mhj55SYEf7kE+1+K
CztEVSQxQNi6zSZ1+DO7xRW91dX6hHLGhuVB7L+n0zzrTlE87PZaKEz6yNNKzyRDOCixYZ86+MOp
C8Jq1CG/La2tQkXn9XhrCDVYGXjGE9wJpHauInGqOIsuRNnHpA8gkV4vZZWp2/YAsoz61Dxjsmr4
IqhIHRSoURu+ab/nWy9Cv1p2AoNeqBc0yN0BO25I1xhc1gowNhkoSmVW0m==