<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpuC74mgq+HZCx+9Rrt/zNmOeTkk1QOV7uaxXtlp4CfiJuo/E9ZzdR8fdsNLXiqA8UCnTBK7
aNcMnZTzYXrTKQjifa94trhX3ahQJLZk2jOk4jLEEypu0RtlSd6ZI6dQFKCKxoccySPxyceMHsbj
h+CXn9liICRa37Y2Q2waBEMmnuo5Q8RXYyqXnxj//V9fCsq5evnTf/l6psKhqt78a1TpceAAZyq3
Qgq9T/WLGmQu08vPpRMeBQyzDE+XH49RQB4E88w+l8ucrFo54Ay8Sa3fqXm74PjoQT1Ni7Rz7+Dd
tzf9eIWcNg48N6Cntb5yqvPApU0rLQZeBD+Rd2XWuKSQQk2LIAlUYDkJZzTye2wjp4tliGp5+qQP
8kluppaB0pZzIHPZFoicbSKVSSjp+3cUo4CAxhgtONhlDcgiXAakLtGP6lFjeTIH+bTg/ftVQgnr
T+T/PAk8zoon8t+6ZhETGd5XkTTW6A/f6JBf0wD5xyJ8InZvosY1+QRE++LnSdA8lJ2gAWkKXvwR
Rr8NpdnhQI5Q/svO0IpoTLM/O0HueKiuMdsE8PPZTig6S9Z0ppcNva4NHJDaGKsZWHWFkxt78mxA
pf6NlNLC2u2JSSynESUHfIONITGgBKK0FRMYZt5Y2YAMQZeOGF9A5K9xEOKMUMcVqAPGZtpAO3Rw
LbZQvX+OjlNs5caxT6R/ANZYm6ubvpGeYupTG0vGpzGq52W313OYsWpUx9iK838QR2bKm4g0/V1Y
KgPBYxJmUz2PhrobNhLBHteKwYmU/0xoI4nj3bUWpZl+xAIGRLQyPu0IKPBRPHjRfRqWda3wvq7+
vAPbtByntvyg5pcxBHbhKOzej6C1mkg/J6/pWjKCcYa17NrIH1HtToYOHGQtMLF19X86+G8q7IyY
8rxyYTVtnqoDk1Vefa1C4mK4FRsZXq6DdctQfynsDqkR8waP9YFspaV55nOlyC2ffrKBLovXCUjh
K/VW5J4SLoC7ewHLAqR3Tp9gP1t/zz8fIXv7NkdAZn7om2WXXGlt9gRdN9CViB8PJptI7hNjbha3
kDe1xCBDLfiTPkOkdmiVA3TVZlh7L+lQlOVzeykwHYZKHuPt0E1peh1oZilWuYx+XvUWVaXMTD4k
twv0FkDSmcSQ6Yh9srcsRPk8GLueh7jmHFvgrTKCzaEtW1ifUXesgnnFMaZ95iBlu+dmDTYNcogN
y0kTfpGgMSSriUyjn6IEH5AbLlo21c5orMreASbRlY+3W996AOr3iCjOaAhCNgFRqqduUPTwIhax
S4KFeOiRuYc4/XHgqnTzt9eJp60rNPFHwO0EecpMqvexE62mTPMKskojn3CNOODz1I1zyo263H03
JLOSQg9Z2WcmfIcX+ut/ypzreozDdB7D78NWGDvN8W+fFxPTPQVRjBPUChY7kfMYCOETpEr0gVKV
MpRzJg0wPai13fWIvU9RDqxjCO1fZOYBkxLezrD9M8nUXIrtSgOJN3uha/COBEyJaqi2JphlqOpx
fSwNErXnNLLqxNbxbim+bnxuBDe6tEOcxn8cvbufujP7V2gMkOrOCX9G71JIrXPbQlZfnCfktLTJ
IiKrSsgQorFDh79bjPdR/0RMBu1TLYIZ29lcVoM5BJC06vOubuB5TElTx1fut8KtKsu36fx6HGma
iJ5lj/EXxLCT22mFDR7PJmDKW6bHJNmJKjZ7ZgCgOH/vgIfz0G6EK4NE45yL/9HQTgtAsQ5TjJ9i
Eq/T64KJjjG/Vh/aQ+YXwyRnzIQMYnR3Q4B2MXybQmjMJ9nZ4zneM6KGJ05ZcB5xf6AJ9bsdPpFh
lH6t+f6Od/2pJXojf0YHg2fclwNILmhJ3eCQmMAGhQsBAsylwuGokVZQHJJP2XRRloZexaTZcoxZ
OO74hZI9r/rwHpjkQ3tKsNMWAEGvo8RcN0PreBXHOq8Y0Su/IBMEkufBybsG9cIDTDxVGxow2ugc
xtigsOViKYhdwWvbn1D78rmaftUn6qvj6WVddXUvp+uLong8zzz6hFBR2+yXK3b1872TobO4bGMW
VWx/FqvFw0zmXEPJxMMC4MmSKqDoAS2vf74I1OY60E76VEIGgAawLSeKWowH0VmPwiHE3zmOi8U3
K0SI8/nz5W/y7l2TO8vavv1DfQ8DhxFPYz97QhRoLowI09oCXJt9vInFulRcNKkuEZtAfTljrobF
IzIEBW7u5bDCOrW86r3lntzx8r+w6jaTGLQuNJM8iNZVr1e2qiXmRrCNlgrlV9j+OByAGryuuq2h
Eo1xWqgkR0uZOlniUai/kO9utkWD8AstUupDezTI2xwF5enCl1wY6GBf3fRz+Elh4AjaNgy0EMXn
u59djgslQp4bXnKNkxvOcHnWMQCupTYKHABeMfvBM0kXsPZbODPpNVInhx3mzUxo