<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmPIa7z0kMXm7UK5N0orBOO9l+NgasK+AyYlZI2Txlt2++EZNDMgwrGKkfOaC/v/UWynwJPY
9OWrJrVeaFlnkejeWPsiOXR768RUWt/207/DMyKLYjm96FOk976ZTiOznVuXT/Lh0vBoWiGz4nxz
fYWmeVSkdEqN+vHXxm0p9JFFMFRMoChJidZNE6A9l9AdqcNOEHpCcTol2eFSUeELjBFy3QjF0FGV
Oe6MQK+LB3M+dpNhAwXPLqcuMLOEb8r808kBl8ucrFo54988Sa3fqXm74PjWQKD2E5v4KQywws99
WTM5LF+TFoEzEwyk/9+WFGbZT6oqVAxcMCPm/nZ7NGtAUiV5JFHZ8o9ItIcCeeur/On/3Psvwr7f
7WnGm4wAqbqgTM8rMzEI3sUcg75uoWv+d4x/GNFryN7PxClpPdGX7cqlV/7M6NHCU1dCm1J5t+kH
P5fD4Xn31gU5PNtRaDkpoty2N9Kfkon4unyj/NRrBUGIRfpG6RNJY5pKZKY3GMlJKWYLV0DI3iMo
9Z3/cXVckuYzPO6XjqXMYj+8Ril2dHUCZQ/wlGDSkSbLnzpBympCuqGTE4P3aB8V/OmorVlM5Uek
S8teFXPCENRb4xv9cqsda4eTPVAgHhuFyVLH1a62KCr7M9FKS6SzQ4UidX5Ube5Nsccqc3cbdXbJ
SE4W84kVsPuEwQWq7PpCcomcXEfR3YLjkZFybA57BGHvxi4XRyTgaNpvZ8Sg2IOME3uvLK8LqJaR
tEo6/72zojI7NH+c5Vy4XFnfqZ2ZcBgEsvwjXGvDo/G3/jrnqtVczNorLDP0p9/BvTQsLCpYr6dv
iJHQwMTUkaP3CaeEsUaaKbX4TKLYdvdUs39zYeqLxvw4WddxQ/2fHXkVQY1sbPsQh9obH2EIWvl7
O5YCdwhABKXiiFlm3dc1otpKfDl/6oaGaWNhAentf7FB3uIQcTNfGsT288Z5hODf6nBx3LS1SYO4
y1oYKW2Sn2KMQ96/HgtQ7VCVukZfdgeHI6GbgqajfxdO3ka+