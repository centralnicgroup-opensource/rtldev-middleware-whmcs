<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu3NRFNTCbNxc63vrlKqgaCbnw1YTeUNNfAupYowYIoIiiRJ2xQIDLY4Il7wgiWfjxb5a3h7
k+KoX5wzl3XhI5fPCJ5uMs0bcQfiXwYqmA+dqXCb/hIZg/ykrG9Qyzo5oGPI6Gc6pzEMd/QTCVOf
9RioQRZTaCSNE+nJN5AwRWzfSaBQ5wvZL7Z7E7OnbhvqeQBH7M707SF29j6iK1Q/h/K7AIwF4flR
nShfZui3cG25K9QtePB+bAMNVON5FPhQdk8PhLmNTQBmEO+CXpAnqZy6G0Hj9lhKjvxU8zvTHSwt
riLDkTtahf8OD90tnZkMtIDlj5vsuESMswcTolXA+bEsjbIaRNSb1GsyyI0WsAAjoso5FRv3YaQK
+kqPpqd01eO527+tQbfDrltCkSuH2MoR855+fwGLH5onycXeUFug+FFFV0uPie4HbSP4QpJVg+La
/JINDC9iuYkIG85TO6rVDBfEmTQshxgl5bychzv64A9twQ7pd1DWucs8x52xsRTwmpkIj3LG9Xsg
UkHLPlQouzlgVPMg1w6J9yU4ZRmpHM2jcdy/y3MHgv2F9+q2ryj/EPn/JSOOrsPK4R2eVTQ45tLo
XNfhrUDdS5bLgSgAM/mX/wPiH8M4dkrgAC+/pGqngw1HDLrmyd4s/eyrduYXMliNQSaWD0BoPEaU
cgRAKN4I+6//otoJdvE9pvuwBFaOb4BBoBL59Yez26Kwf1Nx/63qSR6/ZxzLW/Ar/g6JB9h13lGb
BgXnf7Ma5zj3c25FGlmx7vCU3vnNPoZES/1ExTCCMUfoQftpJOuxyg0cc/NX5Zy9ED5dddErQCk5
b+J2Rgo5pFW6GWOznPjJnY1lOkJpNZy0kyQDDdtyXuyeb9Dx7n9Qrq1cwJ8FTuaTjntquvfJ/jGD
EEUpTsEUE5I/nDkLuvKSJFvof2Ez4LTNN5AnJ9ywvWmnirxl3wfXp5JjKJJgVoYJsXxrI/gXtuWJ
al33EVkhZEyJJnNEJeVb4RSFgbK0rqPaoiFSGUa7OIccWHRg7W==