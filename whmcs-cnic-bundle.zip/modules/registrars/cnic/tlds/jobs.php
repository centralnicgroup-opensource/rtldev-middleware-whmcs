<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvvA6dZpaVv/YlsFMpDLggPV/hsF3TL54OkuQATHyCY+MRF6b8C7yhxwVZLsWonvwcSsGrge
qaPE2jFcbingkqbVYLJyRfGsMQvikxECUFYK3yp7DmkSmDg2J7COnfcXqILyEkfEenasmKCGX52+
kERVCOSKrj5D8+lTm5g/h8MrHpcR2fA7EAmrtdc4Kg3DL6IhUjfgiO9tq8HKwPi++RRzRb+cG6tN
4IEhQw0+rdIFnSXONADo+hWu0IL40LYhZ0wgSjssbBeja4egBIOQXBJ+E55iQSlJoTy/AdlDYK9T
YkSS/zBn9mNKdOe1tm5LAA/wb3iYcl+RyIvA7Hcf4jUyRDvLpcZ0l6vZZAFAifp/mXlRBYsDH1Of
y+M4sPWbXGRu0GYtu5R95INcJvmlLqVHcYmU5shjgGfIg3KpK+jLuS6awJKlnA48ukVfeoxU0Fkw
FmacamA6N9bi84wzjQA+K5eZTw/nbaw1C2V87MOrMPvW1v/d6853Aq+I/dnk5jllEtm+hzq7IyZx
c1/rli1xxGQFDyClZFGTo1aBd6hHcqym8+a9GsjekIeb3noaxdz9SnBR9bCF1m8NK3uxN8p2NNJ6
XaLV+S9UXHXAcJiClsJrT0H90/HDvX0PtxQ57/OftWW250E8ymm4N2JOOOnMGFSDN8i7FVFS9UWD
PNrvjl868yin08oFe1tk8OOYjiI4mlUSOrW9ELu9umV7rKZXXGJrJtqWPOrVCAmHwrOa4LI+zZPs
KgfmXay47aN3OMHLiFs0zFF8hmbf3VsKh3Lt7drfldQ7TmDqpMM14UhL4UniZh1Cl5F3rzYleSgN
EFINoQOGXv6Pq0JhZL1JhUSE/yXtA23I1FUFElva6AzQuMECdRDRChZ1eYnjMcx6j9p+MxKkh3Ga
vYVXmxBWXU18mUFUtSnZzpMcMaBF5S+yJ5h4YVSCtUyOVETsZjgoxlI5QGYlpoJiy1XoDZw7hg8K
X6DUXdusl6VgIHdVIMXItaLi4R1NDwnp+j0zZtY+I/+wFbN5g78A5Py=