<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzMi/yvfE7U5JiKRgKhlPM91/1260hmjNOMuPT7DEI//RQFTG8Ttw+EMY1m6Q0pn8LV+mL++
l9baBgG+uLavIp42jzzjheectBgfOfkDYGzfZKCORPqFP3Tv/GKaZgL/bnj/5vl0+u0KmvByAgzd
/UHJd0uwAXdoB96zfTHSKyTDp0wIOtTjuX+24yFAAkaNtcd3o1Nx7x8ffme/lssesk/eJzEl50vt
Ok8Ggb25M74ZJDYQbBRF6KVdIr/iJ1prxz94zJ+PedukJPKmH71Gvf9HSnneFHIMxPwolFW0opgT
VeSMaVVpB+bwr7RBZsBRa9LQUFBgyt3cfYVSmO6VPtETHKUgqTqk8gUrdvmRNxYPT6sGS0y7Xhcw
H7A7Vil21A7xXvEU5oLzfDMe+WfgQJtgvVJVjSrmHrNcg0+KEdanFs0YWQvNtOh0bw7urY5Gx1oX
P60NFZOoSH9eaQv8pg6Ypgzw2Ea1Op/m5LAGIu1rY5xBFjMMfGLjyb9c8CQN6M0ZW5LjWg0Rxqyg
q3M8Ac1AvrjygMjdywgDKEAoAdUIYF6OhNMHgX0hTxQdgYYIIMZmbAwlAR74URRtX4IRBbtphaqY
Bj08E5wBVK8SW2UxJmH4rLORvZiozhtD0JIW+T/9/28EJmsFHhWcNE5177IClLRPQrISRmlIGS9I
LEbZS+sAI1EuVlaaAXM78HT4ur4BNQ/9aw6yxjmOT2dl/+f76o4lUSDmBh1tyBpYescMiORLNNI4
kDtaQH8rFRy/zZVkU6Nh8btbOdj1z4tcB/hDCOkuNSTQJr/UmSX2qaUq4+cYNbJ6p6y7aHcWVx/+
H4+qHpc24d+D9n031aFca5jfQt33OMiccbPa+20NEsMUyrbwqAZeuvkdxOyhQ9uY6vU8GliEdUrc
HOVuMupS3xZ204DLTTwSnX+jpLV1MHbY90ShpnII81776I4TWAMBGI+CozIrgTos8wnFC0zTBIjN
aLmx4i2yNn2OZKC1UXa/zcrcbY8PuTtqQN/wLbNEDltVlz5IGxHGfHWF/opu