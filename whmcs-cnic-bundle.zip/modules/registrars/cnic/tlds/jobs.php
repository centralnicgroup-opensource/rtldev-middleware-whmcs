<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrv+SM8dnKbMFidaGO5lpsUsRq6lSrKwhRUuxZScTICse3kWSuoyB6sGuJrxLXICPtVez+Vi
CWUvSvirh7UsVC0ixtr0UYVosI2hwzeb3O87q67qxHjeEYumqPM98iSr5g0R4OdjuL/jIRIYgaSl
01zc4j05G1FtLxUkR3HqXSZnOZN9x46DVIWpNy5FV+Qt4Vz8x2FVhX/1hERSdNpLBBvjZjBZLtoN
JT+f1ungJn10LoTOOIvDkP1rgf6Tqg/AOzBHI8rG6HoI3gSU9NxHfA0EL1Pc+J5zl3PQ/q6SVdNX
QQTtShSeY9adwZRbA9CUm6jeAsCJmeoYe8AKIQSxxoLzJMH+tsDU+QwejALACxPxFyFI5ksEY8ie
fcWkEU2JjcyjgJvL6JtJGiMo3FDwU2IqyhSoHvDxvdCrDehffWjvmKyodX81sj9T0CBMPXP5xvD9
2eXuevTI13OKKHdng9qnp7lZ5EBIMknCHA0DhPah2QvRMpl0SRCnjGf4nAOtmSnm6NmuAQoxFsF3
tUMHXSE4g69LSCjK+l20wiwbQGAC3RgUtRgwehFoHOvyFITiUd78DOjcG2EUbGODWwXfp0z/yqRn
w1bUHt5yFbKpOB9mrf522zY5f4oU61wJveQ8FLZeSNCcM395w1t/hfuERqoJBa3A9yebcwv81gVk
uhPj7aKxYKOOLFHdktrsGG2tvqfZYzmQ8OVqsWCiyr31ylb+/+WYmdfrg3/PkWZWNFwdPnBSb8GS
fTnYCZqVsCYL/pZa/9qAQUMN5UnoAyXNgayvxm/hRk0br4/UrIKct4n0nWd2BtOST2PKYNNnghBS
5+91Nx0itL9MwSGpirYcP6GdSVJMJkfy4KG71adsODQBeoDgjOJAxZrYbcanxV3xC5VSEhEK7/hE
qE5qNvIUuRbiCMvLSTqSPq1N1YIJtCnY4t+llQmUekWtBIyHgrDs9Ixk6vv4xAvlH9ZcAdScAPxf
ZueCxloosLJiNHX1Zh+3wWAnw32tG0Op9qsmo4gjN5zhe/kxN0r89G==