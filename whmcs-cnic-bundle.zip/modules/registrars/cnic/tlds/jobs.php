<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPndtiEvwKWd10q0bpI0oO/qWSONB9N4OYOUujP2OfT2/6DoHcNIh9SjfudiOZs74uNynGpN4
pdYE+Uosj2x59JObc1VzUpHawEXJ1+hhLxosKONTDtQk+I1FcH+Lp9whnxiagvLe6AY+ShwMrAUm
8ZHNida2J9vgESZmRE/0H8eQG8VUefuIg6vBQAc+X/gS/EAWmCFrgoA8Q+sPcsdI6/wqC+dGZKE1
aPEUX2GF+eMic/fQzLEAvpHBvnWrZMO+rG1aAzyM9OqV3uQwVOh17D/d/BDkrYMXcQ9xpOrZUard
98Po/qHrBEJgbxcjPGRy8wbEUUNhPZg0ajnM4FH7txbiPZ4ZEWmFo3wrJ8dEvpxhP4Ms25iKVwEz
nOAzJMzW4Miw5DUNt8Q9X1WzklDa5MZLpjHiHx9dhOICEUtIpE5g/qs+LSz64MzLB6UhXeQKmLes
4FrS7fF8qp74QCF9/XM6im36lJPNRcxi9ydvSfOJ+VowpX1Nor440YMSEC6LbaQu7n0ptGFuRH0X
Jwz+MHB+1rwdaX8/2OpR4KVtvMKZyNCVHE+vlS6dRHzf3AheBxdP9jG7i2Qk3E3bRkPb7bG+r7EJ
+kIzYzL1v5KzTqOXk2hUFQ1HtupOVMgCmJaYVeYX1odXozefTjH9o+glmBHoB7P5A3F5NE3u/9R0
IUzv2eFCLMteU0CXJwr/TjWpq19e3rJDpYtDtlCTTamKhDIOVNAhzk6tc6Y+j4lQ5XUJGizNOSzx
izs38ytACLJAd1YrPYBpZ6P6PrN+qVDzbch4sICMo/OpyNzyQQ1ZVqOQchgVpT/FT+WpQjm//IfH
8xoDg3PYE79Xna23XVMu0EkcnCP81UWVEOJRu7XLkwEXSQ+z3cSgxW1ivtIi2h9buSDO+vkGT3FL
gNY2KpiCTolZKcKlxo+YmMc8tANDUz8+aqprfQcxYQyj7IKnk3l1dvc3XOJId6bOmvM7rkFg0aqI
oLrbM6b6PHQaH4JSqzbYjKfMeeMr2LcS60oJp7cIgjWJcLW=