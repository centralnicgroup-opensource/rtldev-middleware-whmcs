<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmEEL4f7LQrj7Zd1QSV5VKO1YERgsum5oAAuKVGCD8HmZoxJL6qgfl+mhwVT/P92UpWgl8tk
PItflCzfmUktiiwrntWHMZvcPqYnREWW33+0O3CnUWECHlErcOv87yiP2LEWTTagWE79dTCUa4hw
3r0T6AOfMTDWOV7Wuas88jZXzbjl6XwBubO4O5az5zLVWQGZz/l6fp2IBbcp2xjRKEAWBNRGl5b7
uxM0YXaJxU50KTI4dHZclzJqlBYxdSLet1av6dpVV5iY+qGEdJ7xGhOwLI1fE1wiaDIK1k7nmSsX
PKTmyXUmSPhWwAeaPUumBaTHPQ7RjmShjSl/ENQ+mPuJ0LlxGWEWfl0Agg1YDC9+i3uxeFm2ok/F
bL3ddoN9B5cB+s7YwSv29U0jVPR/kPahxxDSUFEzFKuYwLPELP/BvN27OHFv7+ldXfH2iQwPAdW7
ifnYP1nMGTKJQAX3QvMs8+OYDRkDHwckPedt+Sxg8rFQX/K2fOX7DuHLDjQZCgDqKBa8z4Dxz9M8
cHfozW3dng5Bxjkyfzrw7nFhiZrtNsQ/9e44pHkVijrMAbMq5b4QGrUDxmhRmPc+XPGTDpZs6/zX
OxHYfbKq8uaGMWvnxZ+qP90za2Ls319VII2SnLgtFTNJ3sp/EVjVnhNXHSwR31WcO1H6jbh1tjx0
+7ZYFP749guZaJcUA9vO+YtWwOnzrZrBwy1lfPAYuFq94VVrUiYpovTaHd8MZvu7xptdXJiC2R2F
NbNFfY/1lXzzm1x9iC0LBYvlf7tQYqLoVQRBTUrbt1IM5RB5PPPpvrzI8TA3T949jYnzgqW06VH9
oxVMMUFf40Y+eUSl2OVvHNe55c+RBpXKAMUhNeMdfgSjXSHj+9sdpo3o93CCqMDv0AkKayHgyzVH
NlhwOs/97mmoiBiX53auYe4TyVHjRtXoTO8WnKvnZoFENn+yNJwzaGRC6bMkl20rCszqaE5U7R0F
y2Ps/I0FS1LVDgOxJai8Wjp9JHkRiAA5Muo9gYYh50iRBG==