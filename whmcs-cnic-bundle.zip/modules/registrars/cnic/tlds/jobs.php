<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw4ZEwAX3e2Ll9IkWLl4SvQCjuGhzigl4iTO/eFRW0Ak0gkLMgHoEmEv12Q24a2LImJVuhfF
O6w+5gkK4JQtD2CJH0PC3BYBLR6SkAO9qgzj1S6qTUzKoZ4d1Kf0WTJPmhx8nO3pCemoPGUjY1C0
IE+xcgLVMe/RS6ciBm42ecv6doIOf9BLdpq3J98CbwoKMrL29/WeBy5OAaein2LTo8O5y6gQABT1
5bkqLSREnJlIErHB+D2EYpaq+1mkv9PM4ia5Xy0ecS5h5/SQ9v2j2HIeQ9cVOAoDp3uuOji/xIVN
Xk1bGl+omFYj65anTsd9jcjOes5fUCyfCP8IUZDSnMx/oCRBoRL+WN10hdvQrdjb4SihTpl8U6p3
WY5ERhHV+v4PSOUrzp3UQlE0v3K+v6K852n9tl8kzzZiNw1OjhM41Ks26tvpEDYTRUNl+kxHMbSV
XSQfbNM7zFylYVGfP5wNUXOtPNr3H6+nMhwyQnv3X6omBMDXgaj/AltWC4k8qX6ZGfUl1ZUOdN/5
0nJCWdT0ooNMC5IusICkYk65LHCuGIVo/daYkYq8nfJu5t5V2lDC4w6cROQEPtM0WAkfXq7/zp6q
RL40YdbPVODtSxmRpykmXE0gUXnEnLzQyYCAzFcHlVHtbnmQ9o+BYrr4Vs67t+bAMbQNAu4R3Aoe
GTj+uNDLrVxRWKX4nCq9ZqGWecvyd87fCaD+SsNguYiSW360YrdamMJMX/bjMO7r/ao1MPBgXIaD
8kudV1U/CD4uGmesZtPM4lIkM/vj39viSNNTigGomiISDCtovjelLlZ/sU9m75oFJ3EylXQoI5ZX
Ecci3Q1nAsEU+wHxPUINDLjduYZ5Zdx1RakMudHtYqcJ664sPaNm63NJyxWcqch3jcm9mOcHcS48
VzS0ozHkfdeBNJBXUQrim9TX58wJU1HjDlGOypfrGZs/bNKPK0jkzg8B+bF02wHXrGKVoMUHadAW
w57Quxi1cJOKW6ZmRQUSwvLGJ0fjnYmSo07YdrAzgWkONm==