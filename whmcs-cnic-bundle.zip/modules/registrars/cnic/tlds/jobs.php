<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvSg31VwyVHOWvsPDEQltGUUzzmds1OQV/f8PRRbtdKd6Q/SaCRYxAA/e73ccUmWaI52zdPe
SwsysJTK+fn4YvuSgAxjijWUndTPCcLAWnHt/iXa6wO0evCT+Jud86MIIUp/hs+80AYJZQz1rcwE
alL0HO4YAzDcjwPEdNbRTY6RsZ4aJl6WCYVFWC6UN/cu0xLNyLQjvi57+jK9fa3kvrvstkuNPv7r
48ZQwAPfBryVee8QRvcBcFNeKprIk0ucUPwbeXwiyuZgqoK2UuO7P9oSIrg7RiV4bWEVMsUTOKJO
nxC5Icvs26vK5/HhfaYhOmIqYw877+1M+hz5iPfuZ+lz/sEWy7DLhooeTzC/HReEOHD7oB4Qcdl6
LaX0wEFy7YDNvI5z7+9gZUEZOrCVseL1jInx/kML1Yog9HmlsyFJZSt5N1oLcEemeHjB2kmp0RVg
7efFGOc/YPqdY6sJXMaVNxyBQTeUJ+p0P1PAt+LEcA9qw7j98z9BKVkTsQK+aOFiac1ilYyXdaaq
FwnHIh97UmBZatZLlTY7ie6RtzoQC6ezGT3fhWNe7qY33EXlex38DeeszhSbVvgpB1sNw0rz3FEv
Q2T1LwaY+OFe9AC+wlQsekQf6K0YDffolNqIku65H0QnMMS//Oq60+Lun8RUAljBwoOr/urUL50e
w6D6bEqWPz4at/OjUaRYpqjcdKhqsBnMWVr7gHEhLvh1osw6quDl7ksvBdvc7tLjqMQqEZf3ptnR
9y+46Bxsu4V/sFgF7sleaIj3f1++HT88zDAGcRgXhdT2t8aXgpWzsL1kayi5NMYsuRgVxrgPKrLO
KPNTL7vHJry4tYkSa9M7z5TNQcykeMKDg9vSHa5PSzJMQP5l18XmLwYXsQnhuLJl354uOfeaPwSg
bJ1EFlLsaN7uf0mzwoootpeNJEwvXvc6TAcFhXIHSq0hyj2h89h8rYE8dWuZUPzcohJIJN0OOcyc
IgcdZzexcvrzke43qqSLYU5YTeylEU3MMDHOc7BAcdOoMXczl4iGclW=