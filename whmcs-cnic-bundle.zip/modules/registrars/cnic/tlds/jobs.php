<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+zfjzxki0iHzzuY/OpTw1HZO1u9Tkez7DyxHTMg7WiM9PSSd2QQZdIYUH2sFqOIIw/QsRQ/
xYV2vfDkpbGK76Ue4cBpQP0BdU/on/VjIAzFmCZ6VM+0VDDPNpNY6Y1O9HnBKfcGxTddoJGFDYce
j0Yrd0M4NzEMUhzX1/HqburgWRf4hXFcTkGqHnxjdbuZBCryeY+/lWqEqx69OOAOcPOVt0B+GyXG
tWZixPN+Jm3YI96euFNknX9jRBlupdvU34raj9Yxr2XaI9Aw0nHvreN5YHEfQglTqD6lc39Pcj5E
qey69lzZL+qzciojMbLq+Hm53P+okx1p3L78+qgWGc/TXyhaXUa9dZcinkDOBrZrjMAnH84qJ56D
Ro6sx5FkWbPPw1g2zE2p39569Fb+7mjQzasm8L+8jbkuRvv1lkFrIz9lQkim+hnQTjagj6KPXMJ7
J339HnLnTUNK3yF3HiKVRUa0+yJgHjxKpwBd+bKqQNKm4Gunc+JaBdhh6LapSBUmrqcwWd9simUj
YMRMk1ZWtcupqkkmJpQ3oob93k6nm5Xf6+933zn3MU2qhgDXAv9awlxauBHxHlrz4+SuC5uR0qmS
UDPRjZSmtZc3JVGCMJjz0bFOpxqYYWEKJLOz5hnW4QfsB/bOBqTG4p+NM+eWomxmLesAnKhLu9q7
ytGP/2whBeTYzpr3tcNdcB2v3j18e4HKbfyOp+5v0KQEADo8yAQjbV+PGU77ugJ9ho1LZZauPFo7
KL/okG1dcms7gzTIfIy/47apAKYgyVCpJ7EKV8BtNe/izvohmQaUGR9mPrhM1K4CVDZtJ5yoiGOn
GYJuG1oJwgOPCO+BN/g5CGUd2HsFZ2l1NVfS8atG4bO6O/B8wMics2AbCE2h1mCdEcjytMZLcQoC
3RfrJDXA/8kbdHM1qRMqHYTVz20cQmX8HfxyBvzoYwDRSILKfXtiCtFVN/AJYm4JtV32y3RhUmz8
51AheZebt4CNMFUsrV0DHOgjJ1hPtq3jc/QfQDDVzkkyp0qU2W==