<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtHs4Ck3r+ZiMhg5w7ltH5qf530eG/FGTk0voXRT16W7j9VlqzmSowlp9mC0zqt5NIw7ynMY
4xdDkJ+m0pD0SLVCkv1SXb7R82jJ7BHbXDXOhaasXNutL2aPajIg9o12Lbc/2bd1RXqdVGNmclUs
v8/UChs1yxI1TVrtFp2Ja5wuj7eT2iOaIcvPi8opb7MVBmTJlmr8fGfouGSSI97LgvyRFIy91Y9k
KcfmxzqBg5H9wTba7qhZCsSnm30Uw7UO3szGXaYDK1aSaWwd7YL+qQIW3bG5OEQtQu028ICdFp5r
uKTdTVyqg6/fNdAsWrzZdpuMusqjEd5E72tfDljBlPPnMqxYHeNUpL8M4hirzr4iw9UQyskq6icB
vD7ttpJ50UKJ7f0agGQj2b6bPibGdsTSHlMtYS5v8aa/w6d9+V/qWM3FK6iHpaKY96vfTrEAtmKY
1BDBniD7qzRLavx38KX4z0tY0880DWx/BqTphhTwsRlC3sVDHcX1aAvZ4sUP9g1BoyNu4ogs4sgk
rwrANtuNSJaGHuYiNdTPcm1MCNNFBA5aX0SbPHCJLIwLRch+U7pRy6K4SGWuO/1ON8/+UhJNlgDb
3ob1KSE5xdsaolbeq6VGhU6UUskStN7AwMb6KsDDS5KY/qX5cvthzdjRu53hzaQAtPTKsOA0R4uh
z+yOJLsuq/1wnLigfC0z5AEBeBSrVNHZT4SFxXNpmeJla6vbxnckMgC8TuXJxrteGvOkXBzBGRXu
+onyxVVnqAya6bvct7UBeJllb0fKkmARNS/35QJ0MF8hvhXx2hjqWl+YGdTTn1C2fNzIf0vGoc2o
ulAo+CM4uSC2cjO0PWAzT7E3yTjWW6j6+edEo3ktp9II8oi0o2NAfc9KbBBCYUwfLv0hRtNU5KE9
lQVpo+QVfBq7BO5Ipa9m90wUYzZsAaUMxJKqoT6CVrT3An/zPA12MXc7+ke4ZWbjaqTbHC7EkKEk
PoMpxJ3JVss7kZRh20k9kS8FbADOyh+vw/LsqjpZH5d9MpEEuDnpJ6oAf+cH5NqrsBQT78u3ZdF5
BnrqRckzaI2LzSXEtOHQ28Np5l4mHT+Fo2DsbX5fLf+ceQl20ODofy3OIqwJD5+QJb9CICpLnCsZ
B8bbodLJZxQYEOXcVvgQha11nTOXCbrJ0jsK4o/i3ECiGlswCIBBmM514B5AKnyYf53z+AL6KYxX
hCGL6tJ1l4G4GzWq9E8uarRacKPkgTZNbm9JUO8hLvePNXUfuvZUxoqk8jMOov3zCWaFSZ1Y1+3+
OgUIMdWXQ866/wwJIOHp1CgfO646Ra2IKy7kQ031Tcfs+xjMv9mVGh9p4VCMsk06xgcJMY6RbCjh
5CqA3SmBbrkYTNPxakdZflmHGD30KIn8LdB8b+d8O39Lg/ke+BBCnUq/40vzE7IJTcV/nVS6sEHl
xenXTaIPOauAvhfwjli026sHrm6H02EKre53VpPjEB8EW3sfNhytw++Imzd1Vzwv3mB3j+l74kac
sV1StF0n+YkJhPA4udn9cnyD/0i1AGd5fRSHaiTtvcWKalbqFLCJ55jGeYoZnUorWdSqJ2tieZg2
yk4arYaQjpZCrHp4snNr5EXdnSHER26vV3AIqc9XsSGppOPCCbm24duiGUpVrM2ajdj3cCEE7d12
ojIG+duk2+qzIDGovrXhSgOXiWVRBHgOt3u/bulnAMF3+RFFonYStIPmmLwyYy3pAB5DMniGdgpX
66xJhaJIKQfckZKunZaOPK2hHCYIibUyzCArDbbaCgti3QbR43xJMEv8mILSJflaGK55QyfzO7Ay
d3PLhWRQnGDS/YnmB15CPeirOuml9X000s9NXIcTdYBemBN3z5Y46Yu0/KXJi4r6LQI3FZfNEpIt
UAB9chSW40y9sbLvitwj0BygOyf1OEIwdwcU6Cm5iPgWNF7fOf6x3PQh5MqS4pZ17Yc8KJyXeaot
XJ0DBUdb0XaQlrRU2Du81IiYbgig6xSH8m89l4pFNqjh1ysX3/mJ3f5wzfjgDp2Tc4n7SqIMni7M
QIT8oTIc1cfJZ3943OKbZwKDQrg3EfKsyDwGBA25q9WxL0eL1znLBRdiFI87rWkNzgMPT41vgpTA
xlFB+ZkvJIlDlinzV9r9AbyobZUR1Ueo0jUzEjjlgzfyZUHOQUW9gYh0Z/XpHCyuKmQLjyrfMTu5
g9gifthtN8bngPPml+3vySaNAzpNEY3j0ua+1wm8K8cyLf3hQc6KPyJ5MDReW5l5Y1E9ORtmqD8Q
7yvohSMml4dsHN3P4rWofyIS9Ifq556R17GdRsqQD0uwcq2qe7py4ANZPeVknjrLY27oZ3hHjvZ+
HrfiC/JD9ZyxiG3/2GlHrh8BTIpU36tP2NFTPgmlGqNbw8jt0iatIozNr1mUUUEatnn80EQSK00a
quFL1ctKsxx7QHHRl0gA2sc6tmnEEet8xbgBRFIezy2ndGzlL51TBnwZ1p4i+ArHeFPwp59Ga8ee
+dXU/LcvgTMMawFaQDns5k1GZ3CtaKFsyegR5r99kJRlYlrIR4GeWLVXS0Mxosuj/s2EdvILi9Gu
FuF+5o71u7nzad0nGj44cVD2EeCEOhDMTP0bo2JPvuTLVpgBvPr9A4uxZo+1X36aQWfMP11AsO/V
CQVWQSRsx7tVstZER+cXaeF0+o0kvoHntjGW29JpbhPYAlT9ixW8uxm/peI2eyt8/P+M9k5fE8YJ
Gn0Ila6IFg3gqV1CzOVtBL6nzEk0EsflmUziqYG+LmQZd+/XJ9WffE71xlDHDMSkRnjqOvgilxQV
vvG=