<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr0H3m/xjlCWWjoQB7u4Dx0hWY6VeIy9ojHDOyWDN1Qqrd41VdlsGiZyPNhkJbU5A7VB0ILj
g7jGyg1wOtaPNZrSV08hAqAtYGoTQXStyRGLc9Jz9Nn/7j+jH5+SN/TqfFxPMWj/gSh8OOno21Oq
i8oS44n4+I/nfPfdwbAbXdPoXl59qIQdkSI8uAIF9TlJpXmzUtk9Z7kP3yPErhpQiFhgrOmDFKWg
DObip++V6Xa2r8sjyP354kYD8mYD25OZHNt34BoE9jJyXH2U2790wT8S1n6RDMLXOm2oJwFUnVP/
IK4KHtX5IojEkypOBkmQ/K5ua0Bx1xvSZkhSTkty7FoRDwtLP8DzgOe3VPPwQFqk8T74R+dOrHBn
Z67H0O9GUcdghyXx2uXwDJHmc7iQXJYbBCXEHxTGJoVNwDQ08cTWKvfi0H6bHXHfgdurHsRG2vyp
SUf5RbBRgBnvu4edfBSManfSs49hv5vprqNO/l4zhPoHlfhMxGqlD12mGZMS8z1EHapol0hpYTC7
dT+jPeco6DFXjZxVHBxle0jWQpdG+laoDcez1aFDvX/lUimLbRbvR6gQlMWpFUlOGsDO3XEkQhTr
7jNFdpQDD6oHSN2ZjDTFB5wrNA5habQBvDI7CPv84gpQ0THCBPaG9F+K4Idn95pT0F/LJlgofeMO
y+4I8lIJLs5hXOe+upXLH9wDZjqguFbi6ynnAL100/+TH9hY7T47l62M90luYCmfa7F5/btJCUtw
/qAIufbuS9MYbIJ46Ddcb+jw27dMhD1dcPRe59YTUmI0Ho7LRqZ5/5ob3QXsvvgCllFACtgFenN6
PQ5eMwu4PL78A/f5o/XFcq7GuvwX0Vul/vsWS+3US89ZwKkalzPaLH5Mc27hYDEG2U0mUdVohBqq
i1oARIK4WAZRPUZKl5sOYEoY9p7uTKBZDps67l/83zvlLhuory/aYe/2rYOwmdhTQVaY/F+Zi4P0
qXb6/s/gLuYt6P1qNXeOOShqd7tzSlrM+yjMfjwj9G27UeqJSlE39QflSZT2lmVEJxmLoRfQM8Gg
KqzpiUNLTxl4gPCF1IsXslF8ooZHv5Td4ENH6pygTdkYyloRGkhdZeACHSTvctAVURUKsL6Wfziz
7h5dXA92/aqsgZdbvbEGkTgZMkLElvNj4Qkwb9ek6lK8WNld89DDyOXpLK5P8aiB+cC6o0wRpUEY
amXACJKE1SJ+iZZ/iUIhG9t8Mxe5byRS5bnUl7gP0IMBPtJMipsfC1f+MUqQ/ZgmloQ0sXL8fYqv
FndrccT25dpNsHxvg/HO08ICRWKpIFHg2I8n2j4gQIno5dXwEC42mukjaIGAuK9pEuopDn67zSHx
AOZZcpcSFRuk1J6YflfBzPWL1cxhuoDWo2AwQuc9B22duuQy1M4WzFv5n+aTbSqddr8GflpBzlfA
cNyCg/IMgYtJXHParTqt5PydwmWvzv6fMn9EHfUXP+3NwAe1LAxmkdz+3hN5S+DKIx/XFinP8MuL
EjOiU2aD82B8lOU2v8T1Vjjex303ysU6YLTzQ/8sfZXC8Md/XgAY01rImaWHw2U63YWSUfZyM1pm
HmEhbM/BQOfbaHBBrXW8y0ZRWAoMr6QQRnNC5czEqsdVbsUunXCQV0/2dubMhzn9xF2RPFK5uVaI
R2EJZB3RvBrZlILVS2QnOcmgx45b7cAUi5c6X+dVbc+iNF3LA7V/zMnMheY6wNIOErA4PiMavP9S
h9vwg3ywbRkMmoFoa/e1+xdP2kvPDaEbzB1Zr6x9MyoOJBETY1ZCZFDpwo3KWbgHLZfFvr8QyY1g
umIhnBdrcvv5QaBEOuRcn59er6x857kCG+kPk1ZtC66JDorYPDNN7sd5G4TB3i5dU+2XvAkilL5g
RSv5u+PaMehHGgmcDI4mgYhpW9oAP1uHH8li9sIzEoWu6wxbt8+jZzUU3WD78gD4zTlzbqk4buuO
LrRwvf4jXQK31OHLUCLStiXsHXLTy5WaFXNL7q4aKYQGxYRZGpND/8eFPDgGXWDtp6RvWzNy0wmB
uHCk/v0OGu/ueQKNkOQBxAcy9wb+jbE4ktLcxU0nKojhX+RSZM4TfFJrWnJKhUCkmUgHttbSGUQp
TeThm8x0MbewPZegN9oh99n8KDkCIm8CrEyzBzUsFG71ktgbQx+rGKMhn6pYNNOBEB+9RLy6jTsA
3Az3wBbRMsmA8Z9JvlalB4ASdC959bCI3SV4W694Od6Pi6O54xBiIHncbqcP888l2cepbGYmWYP+
YZYvNsis0v1urTWEWjwnchCIEuhi7ySmgHTXfMBGtWHk/yJb1Dufx/iQzIkCNdMdFnv4R2+7uh/L
/Qzi3X/IacQDkLaTf7yaLpz+tTItZvu2CRAnzuG4BJqoUbYQWJLn9T2LmCPeKMSgDcSp19IEp6A6
9Ei0a/fRoClPKnbexlZxwFrjUqZWWSdczJ2TDM5JEMQbC1hSNYhXT2Z9ghutS2uru5zyBlEGR5uY
1HfD0N3oekJUg7E/1bs/GTKarYoURFDsvjcuh5z6S91915Ne/je+hO1fNLB7SzwiFY2KszMUy8o1
+GjOVJKDrbh4WG3+lVghM4Q/RpyMGX1mQc2vsdhB8MB/UNWzCPRNPpf5PrA4CLj9Gaz0K/FF/x5n
0Z1FC1RmCmStLDLufTPE/s0EpZTJnUmUpFrZ3yz6dA8GMejQMHyz+UtaLtP6JxhO9JCL8GLXyd3I
dEb78HF2dZlOT5s84n3zkf/8XBpoH5Vp8KG0K7ctawHb9TzDKdpYwmTq2xrsI9+gG+HnDGfBjNAq
zu2wRUFrqFjKmR7Ud7kj5RPcBW==