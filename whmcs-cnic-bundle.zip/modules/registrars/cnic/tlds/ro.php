<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxr3Y9d80t7UbOyTke0a6Nh3PhO48nz6SAQuyqtZ5C+WClZUybuslLzigmpXP11bymku5TXu
YdSblY5Ar6pYpO1DCv8iZH/ypr4wuffj6bxORyEyv1GuqxnrGXtm9zwo/PMU4UKlnTn1/JJvmRmQ
rfzJOJM5r2BarYmZQ2TeILwLvG9ZyEDAr1eiVwCHLspEMtzfOOQ1RVvNGdzMox6qICBUFMxcTQ1C
PzD+XGCPrm44jke3ag+ozJhWtdE6NnZIlxqjm2YPmMiNznedaAq95AXecU1eTLreSsILspUQkjT6
UMPhYaYcKpzDjwbFsYYsaGf+qK13kekAqy+SUazs2M++SjSAGfz4S/2uiKW5n+XGjKWgkysNPUCY
Xbg2rwHPFODd1YsJ+yPX1JdYqA19jXh06BZ5+Bx+y7bFssSY1CxfREh2/OkQYfa0uEzT58Y4clUi
PPXaGhytj9BmEguD2gjsRbjofYiLc/s39jqRk8lyN7JNMwy9lUvtVcmm6JHTGMdLVsxY2riKuDAf
Oousi5JPmmHWA+BGmMwynbf0q/FCIjdhkshb2mJMxs+ydyamM3TQ2ygHxQ3HuNHr0jKqWb6mKSta
aSfQgq2P+xb1rqP21TanJbL2QEGCT3c2d/5hONvnf41GwNWku8PtYh016TlS3VTt1XRHgEH/D05v
3oqvW1ugFwKaqVocX+7cTkUSFVvn1+99EPZGGj2DIq2SkRec3ZQCcgislsB15kXEFzzy/ogE6qNL
j8J9/wG4VKM0o+CUoC//BoJcP0b2ZLm/bwF08cqIFqh1orFVZOliaLs4XYUQW/LMGNMSv9kXm/Hj
W1fvDRuDHZf49h2qzXq5AC4XnBiW4xfTu5LTa0Xq/T6ED/mrm/u2qRnGW/AMV/UrRJOqbmAcCOgk
02PXdHdy4/kL5Wuj7x5t5aseQnhfDmATj8S5eRm+SV/afR0CGywTuGlhSLQKhfE7VDeYiReO45Uv
pLb0o0TMHYE/C/+Kiux6FJ3rToAfN54FRExYaK1MZgXYDCj5s2/F/ONeqYpNnLsJuIDWr5wDOvSK
dGt1diJGVLp2Pu86bryO56K1p56Bgnk62ptapDeT71PuRSz0tifCJjulH2vRUTjepnHWYayhyQmT
rYt6ZTGWDvQV6r/pMGnYHF9eNbixGNRHREE35Y9PTrFSjMwF8HA8Woq4dSiw0FkGgwR0XsCzyuQh
hEqO3j6m7/YYsK1SdEv6m8EB9BKvHvIK6OqP84RDAXp445+Sljijrbz3BuP+OVuhaI+P6xki+uet
8N2EO+rgy4CeuiAG+oLazAXgFrwp/XseMC8RCVqMJOddC8Pc/RT4e9QQgbSY6Vg+nURb1J4FWsVl
p4AnH3/AFOL90f1ew9OFrnDZosynPGSnfU9ZiggpNZ/LDGBRAinHw3r4TkVoP8rYqbmEPP0bxDVF
+2qihKmrsu8W5zWavOqNwf9OEhfFZ67F26vomtSbv7b78Q0VwtSqDrfZib/ZG8qnssj8iDuO4V0f
j3dJcPsJ5gCIe6EaDdkrV/Vwo1+O2ZdUyreRA2Y411fUmYMXpAfHioeL26ba0lni2lslgO+caEtf
Klw9k8sN7IxhP0whHGEb3nBQ6c3QZg88DdAPp1AentLv6hRy4EFI1zVwVrHofMh1pYuzwgAnpEQu
2RiCmAwjc87K3YjEj3iE/3QK6OW5Jr9Wdr1R0B2RzItm+B096EAfWjCT9pqA+TJzILzqsT2miAI5
eklI4anhX4Em2yVQp2hnMTDKZ8AI3bIN35PKbmgadVyvDGAhKKbef9aigR6nc6qm5z/xQmErKP9/
/lerKbjalAEgf7acFdBFJsrymcCzWdj18vtrRYWn55hpvk8SP2Dk1n57P3+/9QOn2ZYVShhLdI8Z
rd7HlJX44zDJ3aqunuHldxm4fyGKDTVGJx2fQxQukXYTghTGkJfvNX2XLeeO499mv8KwnMtWL8S1
vpNeeJvsrYdciHGhXvflY2sJZ1m68QfC4YHWiawstEbJnJY25aflI+ES9vL9TBKUIyzaYzEUEdpV
16BnA2zH50dIfB29LGWjgHFkvV6w1XV9P7IW4fAhEM5ipPmXSn68lZjozTXbkGAA4dYjTOM9EOTg
8PF9qZhR90SeSaiOgh0ZDeP2gtLEsRfufbwFToGTKxvwSBTu6Ffu18+jrrnKsussQv04h5gE3TQA
V/Mb0UtBYo39lC5rv3c8sqg2YLXvYPGhE/Bq92ih5Rt+6z2HudX9aRQ41HmBdjORz4LLCd3V4zzP
bASEIL8l7t0cUeH9eKwITzx1CJE/Sl8RDU11m26JnsP7EqcUBR6IfdUBMkWek48mUFPhZEgi+uoX
i0vtOSqROvj0VHsF7NvBQyPI0m9d/pjo+0dWTJTBT3lSqZrxJAQ3z48Sikpj4CyjSYQyLzfrbXLt
O+IyrsT46diZ9Q2O+ad9756R/XTJSZ+50WLo62VIw91hc0++xH9dfndm2F0XGvyQ5K5t5yKtYRXA
P7Mvn981Qqpa+iIYk6Ev6HUVqx87yE/AO9trzdVjyE9M+xIEiNWflWrENx33Jq+20kYqTr+9p3tc
z1bhn0eplgSgG7YA33sMzbS7WeANQMy5/c6DGnX6K5K8/R+6DxEOLG4dDd1m4on4Q7zTjADCxLwT
byYhYXlXPokTrCXD8cZCZkiinZcJL+bv41kRFeXmHVo3StEH1XsRkJxb5wT/fw7etLSJtvURAL9X
UFEdMuIv9TWnOs56WvSv923ML84QN8gJM4ne9xhj/h7t6vBCR5Y1iDtd37JC0jHTcxW5Yxcn