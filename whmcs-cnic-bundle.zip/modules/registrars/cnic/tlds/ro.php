<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxlAtUVEc2R8bmP8n3RkFtv4N1CeyyiEBQAu5g8RuqQYOuePU6Eark7nogC8H6C4TOU9Hs/o
ldofKsIuU07zjcQHCub16GcJBejpVXYSDuk9BbXQ5dAhfw1AKwd+FaYOVNMcVN+sBCxhnoXovKnp
91sOdDz1hE0FiWbvuhcaVMLYeY9nDDdMQu+9eWtm5jswjORsgAiakixddqkuxQZrt53s8AYfZnlA
s+WPcd8hTAFhy+eOQpvM0nV6nqAlShWS+uYLzJ+PedukJPKmH71Gvf9HSy9gC3tFQkwUfFeslJgj
6oS2vdZLoZTqR8i//IYbwlExv991Zhz/9Coox3hjnmFXI4JXz1KpjF2Jk0VGtQostD7nDvBPUwDf
CvPSO7BB8plA49k9Zoq+JQ53b03UsPuuovPHgHhfJZcY+r/Hhf2pD8SioS7wkzCGI9DvhjxK/Pdm
zyjkRklF5ipLLYtTq7gNESkDl4gKHIWIxMQ5CPrI8YBvhOMBDfdv59N8uQpTT/lR/+kUhHia6b7+
+hShARE82A2EyAjZipMFLmREPuX2EJO0KTbI5cuiN2WielToFyxRk2SgKwy/mDpYWc6gyHjwjU/C
su+cnotmWWWX64COzHe9vVDaTcBuDlaIziDBmCsOpTCrTNt/id/gHtYUQ1/HrzkPCVait0rGansM
QSjs9v1SqFEkbqZbYDpszEsiqLZL1/t62+999MlsYP08t2Fv2csnIPxpRTGgKU4trnUF4rV3tS4Z
B56GOSDAbLuC+/iaFzFjIQjpzRlGbq/mv7CS3V5qfFlHqp50FUUgdWjvIhntvFttx3ca3sH/JEYo
V7FWbN5IEttfWn3RnfdfYOfO9L7fJXPOgdEvGzzVCaahmFYEmD3XvcwiBvjKzrCEMnUveQAlmY5T
KDtfR3upYbBAPCzs6pZTDX9omXzGAdbRIYbvHfkOPutvFsvsPuMvp6KAZr1TtasDn9kP0vcgtgyI
VvotgV7C3FzG2kpdNRlzMMPFYGtn+p7TZDPYm+uNeI/98lz18aqWZdlpUtdGHEaZ3fztYjmtpicV
iFmvjGnVpZl8u8E6swS5ygPvh0vQj/B2G6i55XrFSOt6d0hA1kkeJBNttFcAQvWk/UEMzoI1RFk1
hcGcQ8GTbdHXqYN0cOv8YsxVkQQDLgGlK4ceiBJGciH/LmBPxFoPqmOgV8XXsNukkQwVjrFmEwBr
JB81pyL2q6WqfFefqEbNGR/f1059h3d6FMxM6NUmyUHarOV6gPYibxGaO0atpKmBRrm0gfcym+aJ
vCPt9WfOIPwSI3FTfYOmtbJAua06CpUaA0ht5HuFGnWNQl9N/vULO1bTTU1XULAA5k04J4N9l2nP
9NibUZQHUBQ/KLe09wj/d3V734ru8b5jWQxnu5YCjzKhMNe/go0AUCdOGk2Sx5FTd/6smxhx7f5F
Oarqx/UPJfzlhY8U/lBkWIlowDTJnqeV1xZb6HHyA+Zc65n7mRNG1LgPIT6Nha94RL5SMAYVCUjk
B4DbphKh3a0mMBQJhg3DFWcfzD+q82xSI9OOuHeVwE40Nek9cvidBkKboVd9gK+b/ONdC5tSD0BE
IiH+cjj1pCF/NiEyOMohqEOznAURZYeKVtDbT8YVv9u8P7pd9hy/LqpJU9ZhgkGkNRTdTZS7ONX5
akJsbbEeWt/flNoBKwnTAFGOUMfjnXknZe18967OhFgHVwzhZWsc5ZkZUSpyclRWBCG4VAKTud16
CNvR50ark7r8srDukPogsFCi2O/DHZXj1aW9gdh2R5EZbthuf6h8Ci0GEahubdzEzPGD17HR+ehh
bocPOwvFspxI3PV37UdzpRdRfoyatlsXoaKvb1ZP9xE07zfCbKD83mnC32ldqySZV70oeWP2w1gS
u10Ap1VJxWJSh3HrnNaYrgIUwpJbr3IfLK4wYDbs2uYlr/xmShK+4ZZGLKD1hrgw+9zNkLMEsSIz
Bvix7X3o7k5Y0uVXRdUVwJyLqyCUz0WHNpccllFEaBNIRsMVAKJrHpHxzzwcr13KEnQ7u7Vw2Tux
6Kh+hFAgSHf/BgqzZ3LNVWMoNqUkAP9U9ZO7bgBzizA9Ik5OXzvWRH96iE34BuCp5WL/i9hdptxH
La/n2z9j7glslBrDe+MqoCHD3ICw0ZlS3YeWIEHyR5zJhK2tf0ICgFTG12UdV4N8moG2FuLy1Tb4
BJDl2YaMlBYpf3kxTXuPqO39Mw9ikgsHzOiX2HWH0b/PgbM0R6vSoWOMukO3qtIJosGz+5fiUd8h
kEXcCMjdlvs5smFviTAyditP3QDOhqCG82jJ8CpRaJaQIvK91qS3su7gGIwRIBIxf/pVSuf5cCv9
w6Uz9i8syqMDIQhI7kjJhaCKGXO4dR9exYbfqog3Hkr3xTGElb/1XaPbvh2Plhv5lN6WykjMuyVQ
O0uiRvScpDN875mE8VrvKQ9A//BZXR7Yf/WmxvI5PBpxWEjNYati8rnVmxNc4NgV2GaCH7FbkEvj
M4KUBIRKQORxyoNVMVAmYFA2B+I5K9V3cJDcK/KdBWW1mDYacklIGMPmKkqtMyzVkf7HFktWVbSV
dt1vGOZN4rB4qQbLsUE5CnZL3HCqNf2ANJ6Rvj8CrPbD8LU2uZ6lYIg67d+dSN8mX3riyWb5mnI9
774Njdv7ikm6gfL+482kgKYbZthxoiSc0PXTeHICTD2Ubw/FyU6szt/xbjdE9qbjZ04psh7bWSvq
PmLsbjaxLh00pRWnZ8fJLwsZWAHOl+gfNZLk78Ff1Kk71FD0SHANYFRVL619jO+vxL8=