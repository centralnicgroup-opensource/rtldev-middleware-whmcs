<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmOiT3zQiamn8+3X72IhrofwwZQBoYiYpBUu2Jwu7BEz8TEMJqcj6GD/M2+I8EQbe9+nINNr
UjsOMVS2J5jy49h55j3ie9SulrzvUU/K9lviIM6sTjZ8RkL667P33+NrNsvuNcDkKt2iOwmjA4Jw
YeJEERituNolcJ2MZQZRayD69qmSH8MgrxvzsHIvecuZePqAfGcdURsQWwYsDR+E+mFD95me+o1c
S1qkrfJZuSornYwOXR7O8a7MT+A7dFncm0EfEPx11iLtV7WoGwx5smpwtR5fOWtmtkBa4KQDGi/N
q8Ko/xVFN55V7FBhqOE3gI2Hd2LIwUxplsgJuvoH/GFNm+JikuO4AlTeLNbOaqa0w4e8z8wUlsV3
BCpPKb3HkJvkiMiLYGAzNvOSVIksgQvbjpA2wlQfdRNEGy9+yM6QIoUJwD+7atgapcTpktfeQC4w
gOTNOplV8GJ1X0zq4Ew7dgVJZIUdBu1XNNbg0bUaeL7K0PBleJ/nPrdES9vrr7hKpPlplVfC4qcI
JMcuj7yPz4LCsJUEThl6DfWpb2EW6IdryF4XhhSULeElHh98BU8Aq7qD4lhyzFIKLKvQgBER8kHl
5Ja6lQNnrPKwp1NoTx/7U+Nc8SMdTbJNXfa+D/xfI2B/WjgUQRevrf3KWUQLB0+/p4OOSh8gz5EY
JONP/uiJvFISYIf+v0n80N/CM+nITKLYO/6ULFQI9U1NHk4RQ0dbEgmtcXNxVMPek++tuXtd900h
FRMEC2ntfRRwhb1+8q3YWNivVLBtn5naxFa9aGaRBMPM2HFaMmbpSJ1hKLdJXubHL+wP8ytrRsgT
5CCVtdwyNFR+hfPu3rtWBFzPV2ff46g/VW8akekkg2JzNaq/fs0f6Cio2GFZyZus0tUc9ZicB8pt
QvkbfSutO+XJIxg9YWYkWiVm4GDpM+1kVOv4W7VcA6Hzco1irrgrHPBAwoiz5n6DZvszGFFtsqpV
OnlQGwNZ+6fPIrRzFRS/Ww0o6Bi5UjI+NZWOo1N2Ee5cp086VAjHuHA0jg0/fpGokUIouDjYG+5S
kGZqmk6dDPmnRkNNeyPxhmzkKrXV2es0sfQWkUZbNyNAe4vrLt0epFZLJX6mffvrGZxe7aJSk+y3
xPagBigTN/WrHWW2ycMQ5jo2eyzI16D9raVDmdJtRlkxE6oum6xgcjLBeSi/Mwe/1UjKP8CJZyg3
ic9P1pteIyZFxwggR5F5EtwjGXU0hDpXTn/u1oGXQzmp/xkHIGehtSvoqx6B5Ywh1PnQX8kzIiua
SEFGCtQwd8jld653xWW6L3KmCDZc7jCNGfaorvpj49Vy97fm4slJ0p+mZgPesSHGh26Vui+i6sYG
+LiZsKMwLemqkPd3uOJrdhmLyyxA+KrSzkfC/l6RTbtMgbdB2M+RiYh7MR8C+gQMOH3MU0rzPDVd
nIxCixS5duBfuqvHIkjHIyAam1op/u9ufjnwr6hJ/nF7Dwhvxhuw2LyjgwVIRZjF9Xx8O5CflATU
wMLxxS/NBThbQlvdvNEXjcZXCEy0ISupI/YW/ylUO6icZymxlsMRzwDK/UYbXZV71mSPo7HQGvyQ
nVQ3ev28igKKGCCOilBFm/QcMVqMGulDBYumqkzB8CQvATteO7txbXIuRcUl1uYbH5J39guZ3RGh
MB0HCQxaFujqIXTUSmR/hgPfvo0+7Da4h3rV4yt0CcgjyUl+17tgzX81K82+frzMKLEoZM83Lfe6
uRASvNkwkVxZnLB24r22tAbzLzGdDUSorJVkCo/e157kQL1nSK5sLSO9jG8Tm8d82mDBSZIbsVuA
WFwIdX5ydLo9RRMTwyPQmn120TmA2y6cUusHzudoUoqTaH49fmV4Lvc/U8snULlcOVmI/rkz8cGp
I+obwObros9KO2j9+FGNCJQEiZhinPMYK15RKZuKAzq4uapKISus5LU1Svp/Rjtkavmc5uswEF1m
OP/Heh/VPrFx60VXz97w2mrUmJKg6fRGPlJqRNrqvgcFyg3rE1IK5fMQdJie/ay4zcr5vvtHING3
I4x5DgNChDJbCsD56DSCEgckoUS+lPb/3dUrBNfTNOdrRyFFLvkZqaacS8kriUw3+SYE4GibUMI5
N49wrJvV8AwLttZ5bAAfdgSXwYoqwgq4j79apIV48sQsfmxLuydpFmpU2fi7b0F+uetVDIzDhxBe
1cfXVeS6MgNBQdKBZ7usEeDKddPO0VtYHkhA8fvrXKDqvA2doI+JOcJUmT6N+Lg/0lkwV+Z21S6T
ojquzgbBKpiqBhh76l2uj1y7VAEuTei9M+Y3AK7HHiqYy21GNzOCJxAwh6mmmSoXr8svNO6wTtzc
pfUtLsmSUnujvF70+GIyHeIJ1Fym/BfkNsDFY//MSRn0zzxln9ei3x7zsYviBmpg1TBJ+ECZmUP4
EIafxwJd96Z5PVd23Q0GD7/hLfAe5Qa9zovwBy4nyb76BFnVUTERUdgNGmRZmGiUOkz5I9L+x35+
2tGnZc1Y/2f6lSYJ/mPZBvProKxSBbaRYVwrHmn+bQUjbEQ6jprtmgSFm5Kq4gc4FunpnPaR+A9I
fSNShTzTBGxmlgoQ53NS8VEMlvrS94O2ZK8kWRpO4A0uT+l3ZK8jnuvR5NBMrgSnpa1eT31hf+Pp
3TuXndjnOQZokXSWkY/BWiaYXQXhJpkXA+fotUg9uzfgPAxUoM1+GXFPpWQTFoC21I1JEvlFXQar
pBjqsYdU/Objd4ZY9JTQoJPEjx7kS0ui5HY2DcHSYw5vTK7jpc9tFLfh91um8UQm34Yl8F1Ng4Ay
9ui=