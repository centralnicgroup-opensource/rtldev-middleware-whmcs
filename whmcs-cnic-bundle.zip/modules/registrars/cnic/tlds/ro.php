<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqVBAw6Hcf2MR0U+Wb+u3siT2gULwl2nBi51wACPrahiLVlG2Nttl8d7LyPQXXWaJbkT2EYb
twKpAj3qxtXnDWAS/Q6oT8vJrSTspofUGYZFtWoZ5RwapgSuV4cxTa49isv5WA7dgB4+6LCQkWgl
evarDgcfScG0aMhn3R3usbI3KGLwfkIM2iPlpqsukRTWN892tKBJQg3Q7ZFDj/4t0xeU1gknLfHF
GSi+xxd4tEtbcDuqzmEgSoke+oNoNLYrb0jo/XfyttnR8lj43fqn+qAsEbM1QyQNRu5eV+xfAlVD
mGm6MDENZb+ofMqY9HUp+FjcLORvtAraNuHLKNOB+nKijRj4CdME0LGf2mHiKBkvqmwOWCKevp4A
66yz25kKzT0GttzyFw6Ub7xITnvYcD0KB6lmnsJMSUrpHBE7eiLR4FS1EBriCYNFeFHemKRONJZU
CIZthoOWCVNQ2AEafIal/l/6fU3g5Uvb+7w3ckoC2CGk/skF/rz7016693dUjAaNCSWXBFvZTO2S
bMUcuEUzY6PGf99RWDMl4g7ekcsOZZMzi1sqtmGqwk/5bRNvMqCcBThXbOQ0cBetAzoAmS6h9RqY
w7O+L0knrPsG4OUadXz3w+ePcQYq6ns6ucLHdgH3AmW1Rnm2/xJ9MhobSCwuqQr7h/AoljbmZVuP
KNgDfC+Ej3A1SltWM6GDl5cfE4kOWfXD1wOzrhiPEM2UUZyp8iBUvSIN1mMGDAXwhhxyOt0/geOs
AYo29mRRUuhDxXNFEPPHNkxh0hAD6CsH8jsZsBPNqGWc5zXkYDlr4esz3SAxTyUqpaOr2rU8wewT
aniFvsiCWQCl2+vgNzkcYP5reL2DtkSShZ/SjLDFiGVe7y4UNBzrx18WlCk+Ck6wHKyVR3M190xC
dYN+qQy02w3Q5vGrUDPY0nmOvJUeP6mzs/E1sRG0vMmr+B+pghg0ewHPhsFY1xEYM+ccGhX4DlNy
Tkf32Q6e/tP2oe6S1+9wW5oADXLdG7rZSGMM3i12ePDPflTUf0rFqKDqpUKaWM/YBL0lS7D6xc5t
8Q8kdwVLuS1bQOJE1i9Mogw5bd9DO2jrVWZPzMZe379TdGpDULE1klI0hlbN/tBXcho4lJPtGUNQ
ECI/TMBZCxJFT0rBH0HIzgxArqNjptYsh6cNVR/9I+wYQD8byHmL+yYuCzW3Zwu3vDuDURa8jw1h
OeI5G8rOHLit1uxNlKbTBgXEH8kJQ/ZS1y7DNKThgVIpn5ybz8B6wp4ZA33kYajrRqKnZidjdmFd
fvvNOaxrqTxfA01X6wjxBVQZ4O+vaD8F892P5/+c4JZNgTUGjI9Fmu9+O87JBIzTQMeKN8YFXVqa
D6XT1UTb/ktYIHE60xE27oeiqRQ2x6Vz6OvUGih9o1GQ/znDlz+eDeaUAL2O5EXyz/OcUBs4uI0v
LKqqpOsvNSRcQS0ug2BsyMuJxS5kkXuNJ1uzaRjGZYXEBJ9X5/drylDzRN/gMcJa/ADv/Zx14a62
Uf20kW5z3cxjgG+yb5CSFQqJkJNDqceBib9VcY84DwsxBj81joELIX6H8SsqyCUcYKa20/k5NwKd
gpST/XStKO5G7pfVIJ4l3FueiN6QZd0P5ep9COSSazh45mnut8XD+7dDiD0Yq1/nAhiXu4byRDvd
hFYzEihAobq9dmHKCJvf66OQ/+YzYb+jOHPBHQmv0qSq/o+SUhKFzM2M8O94We448rGK6bfMyn4/
v37JOWdTDgFBvgeAI4cDbdvi6HtWeld418HRBHhLAFxF+Yi/sCgMjrx8hI93Blp/HFZ15UJKE+Ey
HNgT0X/ZsmQaTmQcdZadLU9oGWrlFvna/dsiI+FINhq6KjrHE9Lu+UDTrpcomjFYu09AcQtXgTki
9+Y5/B/5L7r82CPlhSLPlNdEziux2P/3nvrg0RDzTetwzbmZ5S1l5/GWEuAqKUxkn9PuDFaf4dSG
Fd0oFgigAFn4IiFPJrMBYlPRLFuT1ibtxVLF73czYDqYhUmvijKhJu452s70h1qTyU1K+Ji/i0b+
mJN6RbwJICvltNvPrrUo2Q76KPsTXmRX6gRyX3vN4s7razn7NTz1ZZAiAP+Sh6rzUVxyEdY+2Lyb
ZFR5tJVlBeJYSyN7u88T8zmhHDYlmNxVILnVeIiIyhN5WBkNQEs/e6ZNH13jNYiohh9xqPYC0vxr
cGxuUrmBNGvEdIImk0fdi/LQmFH4ifAxiMJIySsNQ3Mm3hSOnzLMaMaZJ6Lo1EqmQo6KdODZTeGY
PBkLEYnpnWdM2I3zK8UO+7fMOmEYK7iOnn0m+JsNsSuaAaRuTKioM+tRdTbyIjniWp6m9VVuxiOA
X32MacQVKw4bdHnhuNz0KQASDvl2UFzL9T6uubxcp2ALoKs2P85XtW7g6XB3kuUiA3BhYA62pD4g
UB4XDc6uom1TqZqoUDqnzgVgGbKJns5Cnt7b8KS9fbj1zQ9O7Klz7PKDa8GMUZzyF+7QxYGm8zjL
4tsc463LyCN7YA90GOGdY42eojvkgHWR6nyixVuGbAJXy4B8fqtmuFrrpi+QP8LnkpO7u5ScP+4v
TdTWUG/710elydfZg2cz0O5LCiYTng4oBehcqfyKdj0TD/Oc7h6Fnp214OyMmX042gdEDJTs3/vi
Ll/9flvK8GSdjSUjWcBBDUVLw077Yj9/b1CjDKvYgExxfvXvFWApTzZSlT5yycSAxbfRDVfMYWoZ
KmuJImbpuZlwNKccW3zmesbsr0LyiT5fMZka+xB5CfDvuEKHwbnkus6upX8V37FNkmAa3jS=