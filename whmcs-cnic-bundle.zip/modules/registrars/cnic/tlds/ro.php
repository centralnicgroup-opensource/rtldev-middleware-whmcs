<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzlIhvJeS1JRzHuwjnm7UJuINVwLqytI/ybdZun8DqPylPUNq1ccwBfjQHXvOxy+V5m0kOnV
p61djkWGUcwTmv2b8I9QXMWcNc7SDPS0nE/HzDp7BgVpwbONikrsc3uI3vAgqc1SqjmmH/5yArKP
C0g5VMclXscxxq5mccjh/5pCugbGo9sonLbkmWFXH30SRI38kmZJORY+HVsB2s4rvbEtjfxb5rme
pWPpItPS4kYkhdE6q+nFoDgnD6sQLR7WizCGmvYxr2XaI9Aw0nHvreN5YHEGRFzmBhCN6FKnChzE
KXHdAlzMb+dddwlWcq9Ke/msFjz2oKwcD/V1H9PQptqLB5sPTlcln8ZrwDMmA9fs3ry44phyCxPl
wtFTmBfPFHAjQsUX1w6ziJlfYf+/RH6DcdU1ertwevpLMClfaena54sFG6Jee/n0wyF8KH0J+iku
HNjnCdRZbcPwHNRE0/zSg0hmMUOnOOW34jV7yZyTZUTjW3rJ4rPI5EtopwBgIgA2TL51wpFlkQwg
XpZOUfjANw0LOfCCtEsc2XMCcHRx4/phL4IB4T6r/EkQ711d2Yuoph9Mb86G61PTsMFDrGPOygmg
NEZruEby6LKsMxXi+XwiXJBaaPrQISZvi8KrkOFZ6pqLl+MOZPQqcNu/8Sj/3rWf3YZCAQMm+9C2
+8DXMXmTJ2fIEHcPaK7TSzkM89ZwUlFRMRhjGIbTm3WNGMdio77s/py9HjvGVvgUkdOfgW/U9vHu
DOmlPKkjfp9fT6Jp2jKnwirlrRrq+mZkJ5OK1WaNcbSJyywW2Va2RojGKAL+rlcX0dXiNmuO8z4F
UNfArbWsb3rulMue+bgG/cLTB2ILP/ajAI0rKjWL0h5Dpq2l7wxF4fiuaG2+cmMrX6s6CjPabH4J
5r5YhDEztIKwTY6OM1HkoY/XYIuO1Q05az0U9oc/CozH186rkPxqxd6yTSSlVsTxxfI37qliTMOt
okCEuFIUdpCGb5h//RsMbzwRNvgTn3/yaMe2+exEcTCjZeFJwhiwI5uN45DfkohRM8djClZ7WSWx
qG3+0b0ayrbm3GVUvleRjdFLhMqLGf4aBuGvbr7YPDE0x7/HdNLpIe55+//ULiWnQHTZcIsESiTT
h0z7eUXkqUYHJ6HOqndfrE7rsueGxKp0ZyJvztE+cqKRE5WkGTMLNUqehHjZMkfoLsFlEKNfyEV7
lIJA4DQzJ8fsqxqnet876b/GSM+fTBXODXt2URF5gq4HO8fAdGy9H4acjS/9Tv2i9VI4wgpCWzTQ
UIkV58nO/F2Kgnqsfd6DLcvq1KO8SGsMm9FycLX2tDami1rqSQsSNlzqJucFRnoF9n6Z1yPDqOIO
VLa63pZHU1co8wDdVwlG9A6OEwf8JWQAC9pCd51OfLEsm8gaj3AK7of8zJ5kApHBTRWPiuXIhgHL
of1i/Q/CUXHepC7YzUYCAW4LjzGVC6NT2HoA0UC05Hqoc6B9nEmaGQoUtGiZROjXxzeBxy0nzYQc
Zlx7rdl40NUqe+LtXuPXAlYt6SO4eXg8iBPlxEzIxTi+xN3t40pwCK8psiAmpTuwzb4/Hx2BoKTi
75g2p+x/78MG7Z82aAYcf8QYSOf/2xNCkeTR2ABYig8usc5pwws4AjKYdM6/W6QAT1iNRDsMK0RI
BklNNfjHtYL2yE9NybSjGbFi99Q9x+GuOPEKgtj9EAWqSsjVtW4RpsppkFbjbg8MuzRxdbgfYSRN
ZqoYFNPV9ZvXyLp1co7FgMnFwtOkdwybgw1UlVfqUSv/0p613dFoiD1WOxAfvTcm0yuShXERqssY
gcIrOHvyT1gqc6qj2QasOCpTPs2ecNkTYpvoJ/faMX6uaLOABdK3JguvbJGNSnpyrdPIBKTFVXfk
zlwXXCmQtjEj1rD4M/2WojtN+WTfHpTLUFhxfrqmxsvYGxELMrrPL4idrbXYktdltnv8JTsEvrVc
vOPkeweUS0/lPjoly8NZmVVnydvrJIjMR3Wpbqup3CCvzNDGZWnj8W2RP0x/Oj4gpAZnlcMBo943
E1kYEhxFRAP09MTYXQzN0nkKMXo/dC0NR9A0e7CScKKf8Az5wdRS6G+1HPHJR+E3VvIbciT1aKiS
2/3o4vziSRdfpr5E9dlj0lzHb0XOmAJAbWExztZNkrVO5BSojsRgg46S40qD4vUya5nE2yEN8sEP
NZH7BIdyb8uoxHeUR/P5THfWCQch+0cMz9aF9rkQP94e7xKN9m/e+CEmGEObT4wSCzinEBVOLyuM
0RkubQQ/D+0di+t7OdikG4lBqIO+2jKOPvohybhLxIYU55FMhsLBAhOe1O56qzRtl27J/Ho0vDlW
YLH7CZErWRsXW6785DmvPFyQ7aCcnQSMMRbgchcnwu2JbQgoKqwp1N6hRz9u7TIVXaZm0krtE88N
907rBXmpgVLkS3dw3WZay1DxQALT9cgbmEQkvOgyPp7zV+st/8DZg/1dhbq1Ay3kIyevZr6wnqpm
S+RzC5TcQ5S5D95aRhB9mNXNA95rEqGvEa4IFiknKXVtFvrXdms4qFdpQyWm7YeKmY84wyULNoQz
zpy5LDdlVZQ5pWYG4v5XOe5CN7bQ54BcONxAVVv+Zx0FMvFR5s5odnOnYdpSdHEqxWEVSKIGmOBU
NC3LfD+yItuTxbfUpBIu+SkhrCKUMv30rBsfHPlH96VDJ7Ec2vPdsj1iqdyzDdmtT48p9+muccZB
8TbGwilL8ZiGYNZ1CS1FyB2iHrnedKFB4ee2Wn2oHLbS7+z/ZDK0OERoNgJYd6q5