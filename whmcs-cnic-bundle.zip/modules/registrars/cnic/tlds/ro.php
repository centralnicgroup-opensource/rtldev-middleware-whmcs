<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvwKDKIYIevhkrYWPwIvv8A4uTVslPfI/+4EjMEsAODX9iGp2atJYr3r6LwHm7RgoS1uUAJq
A/ztyqMpvT7Wy/5yuIwcZzL1k9bO0XyP6L0Fxhec0QmfAykhkRI2R1NJL0oRC6rQMQHlCDZNbHrA
iYlSmf7Y9kMOh+QY3yD1v2V47YUgAKO9gnffM+WK9uw7psRDIyqpzs4aLBU2Q0qZIx8e+A31Cwol
9U7WFNNyoeBUV3dV184SrHRlQz+ACKSYY6gJ6hyUhFE8wjCb0dk61sISd4jQGMlnB8aHbEvcAZIQ
sCUBPdPOG+eo9fFpKC88AcuQ50zzbfnmC3CTZJsrwHJO+s6IneYlGDYfhEeiQzOiCnxxVGQOCU92
1Spg5nZkFSTTkDHyI8LG52+MExCheujarxfJgwx7Pj160Hrk89RO7ri0eS6dkMk9A6piH+sLkEkY
+PPZ3wmMYKvG6cAbBg/A9n1bFJAOHCr7qmTYnOxDxbh/MJ1UeIyI7q0bV4EIOmoRSrWRdcZZpzxH
ViIHgSqTHrE7T2iKgIZ5GS5kdqXZIgG2O6zQ4eur+t89UKYPu/uoxFVq/j1KeMaIHaNspirbksw5
D+JaOm1fVdLpQzZVgQBAeFiso6nvwo2gYvZQCoEnUiJFhsk3ojKVKw6314JQXmpkZFPk/q4E9XWQ
m/tjbmmjhUDuEfhSvb1vptmGvSN+cwHT9y42Gj3AMc3WCcTQcbzjvXU15An7rHjvJytOa9ZFDFtZ
oOrJmBzj7DIoWrLugPq1tUOwKXJkWSzioAlYrxYUJ/QuFReaAqL6uo8197079oIbbVjdMyGzKhm+
oMlhSY/5pHHiqcXbKG/dEmYdJaJ5UfoL1b+XyCFgBPCpNLtJYDFkpD3Ylm6Pk3QEikT3lDXBu2sm
khcLcL5VAOffZhIrSyt/RomYl13a/k4aM/U5Lw561nWobm8YAouOc5h0B71S571FPQpBHYG9yYMY
9h/2f3EMgbINy8KBR8Xkn9ivj7J421UTlkxgW0PkKa4WeSA6u0J6pt6titbi+d8w1AhWG9u+KRiS
vxoOS3Igcl9ixzN1yQ5F/hKfnRCt01iSe6i6NpPwm+D7tEphMLJLBkZuXmvX8XkfJFJO6A5GkG44
ZmIWryklDL/018TqGIovp89Kl3ca7wv2PFa1Hkl9xca8j2WtmGmEtujbJPatMs1w7NBVewFYQaNM
ptmfrA9gPGF1ujVu6RHGydZ3Shxb6vv5paOJP6v5Y1vGal08fMtwYdIEOaCwSxy3jXaZg1M3mez+
rINSdduVSAK2GuNY8S3Xx2vrFW8Frj8BHBsBo5oFzIBk/MSu5esY/YsHMzAqgap/z+u+si2pGwJs
d8mkPynFhq/GEggauAchLxgML3G0kn2L7bJVi+HZngMVRj48/GuxW42oi/sIvXSe8skkO4BSVOxX
cJR2AQ1Y36aQuhi52PgLaeItz+uzAiU6lS3ISXlniCsb98FMk+bFhFH9kzsnWgu8V+0Ui0IFh3h1
Mza0PwVRminVKWB8FZHDZge1Twp7JznVnsJcMKatFmA9hIR5EN1/1tXHAjeT6uW9CiQeRDCXv2BT
ncIqxIjd0tKBHox5fjrK2EAX61/bT6txVocXL2Ghpe6wBVUUEWWthdiGvjTMQAPhc/6Daah2VUt8
ddzM2PrfBAGMtc174vyHXBAxNlz1/gloJkxJo4nOiXwjLPGOy1bAR0Cd5zwnjR1T7e3mZ/d+HBXT
D0VpzeVGk+Xk/FbO0EeDGS9eiKFvl5+miNcuyYRpbwNp7A4TrZd9ugY+7wuAQtC4956nV/RC54xP
Z8LLbAaxWg0sQubFTNrKDtEsBPNAFGrUmcGCuIoCz2C2zYyW/OjYyRVR5qusTxRfz/uLLxcOKPuj
wIFmj69wK6FzsVzm92wPNkn3lc5vH9Odp7wP1sBnOps4xSiDVuZg95R5ryIPMyq7YfrcaHTlIUpG
76DAKHLAiyXI3T7CrhSZKtPafnJSNLmJNsKalMhTMMrhO1KWTiFTip6mVUDIjq8Uw0AOViAJq+UQ
xxFd18wRGQ3weHTCG8uf78tovH83juurXmtAWK2Rj3FEzdg3H6zQ5ts84c0vzzOAITz8tKpxqxlw
S+ZktXSsVsIhoPOf9hBpGUKnAAt9SqrDKBmU0CZCe2l6wiasXCeY8nAtfg5rEsspXz/aFJtEOhho
2c8Cjx+l2WVgj8jVRVNaROtu9Df0gQNAe7Mq2ZqNHwzi/NTSLCNF9U0g9LD7njy5JRh3A8LqwQXx
iiPG29ZEgTDkK+PxhuZ+CoY/t0rxo0Viw5jJA3vRrf2Ns3JM6T4AJtHSmAKapqWI8j1U6kIUB38M
ZCeKXtBcy9clJzAyVDl2Knh1Rj2+aqgCkCMXCiAc6EfzvKUANW+9BzV5qJcu25SiULq5TiGACxEZ
Gc6tPZLVrlHv+mLmt60IGt6JQc8tgaBsSJ0m2/R6NN+RarZhEZggfGilSiAb+tPttAg9mIjcLfKH
zph4NFPo84/d0mYAmIg+Re3S3S1OPM9AU5MlD/LpIrwUGoJ0sX4pQvgNE5BHPy8ERpUAG0DoxCbW
yd1HxNcmmfGN2H76eU4aVIy+2F3XACpOl0Mfry1Mu97mIV/tYp6feA1g3Buppq++VQy0t+cjsxm8
DUndkIVd5kHUndC/FOJngCuo43fNbC80NM2RSBjF4Db0yxcli8rPvDkUGy8aj73by5XUyEJ6OZS9
IgHWdizVGo74EQj+iR3X7xQB5JS1BLrIDxDPUJbsnSU2VDRHkGna2CFlFh6WRAsXBcg1gZJwjV6h
aeu=