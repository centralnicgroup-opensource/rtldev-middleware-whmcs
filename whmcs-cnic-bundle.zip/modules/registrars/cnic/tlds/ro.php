<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmjxY8HIwt2hAxSTforIFiq3j+Lru/8z2SWPglbx1mQ6QXRuq3dTFtpLWpJzfLSCU/PkX+XA
EA1R4GDFgOsFWyFB91eoxPQz36+vy7ndFO4cQw1aoX8Hvdw6H1SNERWdYnrCFw5FQq5cDZLBGSMt
EC618JgPVLbGZRQYv7rNq0AYK/Qsy1/26iUABaZ0ACdmW1qxFRiwv9vAZMh93FiqU6fJVogO9eUu
Sgo80pvZWsdxwu/oDyU6XqPI7oUM7Gv1l+k/LffAVUNIV3GoQkiop72b5VcwmMDy210eN+bgwtGu
1u5BnnJ4vTt301eVgkKc2c2tNwuGy4ZpmF/pCNy4jZgnolXs3GLrcfq84YrzD34/7gHKlhiN5Z6A
sN98X2rMgPWkMj/WGimLrIg2uP59xh8fYHpzPjdvuF/hgBonnbAEdoTilSye8ursTBtykJYyBxsH
Jh68rI2QZxXPuzV2JFXdy4yeXE2i0uI+Ca4sQcJHkPQSwYVoPQvMp4ZhnsM9R6/kKiROVdO0rHur
4KaOMeHMwRn9K/hhSfYdoCFq9CdCMR3bh+TMeNBL2PJEUZfKJPTo/OGH13MgGN08P05P7M2B3e/2
JT3wKKdG+zO7Q5PXZ8wFCuGe6LKEfJPfEpkd8xNPLVoFhhc47eVSNy3TjnIIJ4i4yqkm9KgKH5WQ
EorCIWlGXZipub8ZWS+AZp9WBtMIjafHEmn+8YJ8GhKhpES0yK1AGCWosoGOgECPTdaU4EEoAUpC
pHkPkjLDkIw5p+thl7t4223DfbTZ34daONdb1yhoT+awKI4KSMIXSX3Nsevx5uvdkCCKUKGsqNW3
Tc+Ulq42ZE+1VmrqWc1j9QHXvxjKSO3xYYUrVHHJ5MiUwf4WO93qmPsA8nNMJYhZVzdia3z6NXSC
2vdFaR+2LpwvlTBr3JzJXstJHKaaC/61sANhZBq8A/43wQw1Nh8mmlKQ3RJVUcyW6iAtY6Fmy6jk
jJOQkVtc6D930+VvpkOhvXSPF+xcGkz5wlbdHvwsROuinEYqRUb5nnh5AwnI3W6uXWOi0y8oAd+Q
9JstMG6IlrDJu1iLlMv8FVZD+/roC2HtcphdQn9MJQNi/+5Sm5R6fQoP+kjCPZblbu0YbZ6yJu3/
OlgcQyi3RL0ZTkLdW1vWCxa9Bbcly7GhqPkwEzXldGDhUGatz9Ro0GbJCiMOFmcTGSQf5P8sJC09
t3AfctrF+lKGQK8sGVEZrd5B3CSZYluQH14WMbhKTjbNFXlQSSZqJt3zb6IoHYC2DseNA2Ki8J6l
BsjS1oNbyQ6WmWg0Hj818HgLYtPB6E9rouANvEF3Wg4R/N2tkFiVaAv5OVZiI63sOVJCmeFBxXdb
6Nq9fj+wYBS3Hk8a80O6n04O1/ehBa3sO2x+dcfbqsqgByaG4Q5eZUOPOBQTcjcaE8nLo4pd/NhJ
d3B/JNz4QSh71FCwiFMDJsRHZRTxUc+vtrBv8ihdqcrbHi0IIHs25/kf+WyV6/1YbTv+IZdUxmhR
S3Dq5O8iA7Edu/Fej4mXnERDNliSaDbhk/Ej4NACmlhRwuCF8zjp4T8Y5vH8y1I8ARuNElOO43Ae
n2hasc8RSyhjqmFuTXTuOO7DnvCrB02TUpALSelMakDhvb9kMzgGKEW4SYE44fywI28eUvnkDoqN
yf+KwDIZH6+2W4162E8Q9OyAvRtcMEL8buaKj2RxgPfCH8WO6sAPFyfo7W5OyXuKRAcfaHDGn1Wh
mULCgUGmEwls7owGmy49k41KuWdF3GmVXd2GCMh8FqMCn4/A+RQLYP0hJlBdm5AMBZDAl68/gSDG
Y2XE7DOtEOfTxQzJwjz8WLGJXkY1trilY/uzoIpzUNbje9X1a8LC440vhJ0ZXkXSHtKdwGM/DuB9
Ch/d3zqv6hmadU9IP7xpYMVRKeOnA/7TY0Vm56l8RP/jKrlkFTje7z/rFoLQ18GS5FqCpyA0l0SR
KajB1DcmhXwXxA95TV4irC8U88ZQWBiHcF0F6SDz1EdrWUHTtjvUBxkN8WZ08CTT8O/jAcOt/tbz
1Hs3kgp8QIzt2SYeQP46VYit441wuC0WdzIJI2taLvFS8TXPyfi29QgSEiXzh0+F2w2LIxAXuAJ/
33uBIXhZpuWkPo0r4D9PAQww6hvzyrNx9hq00wrNItlP+kv2rf98rEp8alqiz4FobdU+1QhjpBm6
65KJLyXNmpPU190ofmfV9I/X+38NepQZ2DQ1LAOt8FTd6IOze6hsTM07Eq8RSixxjl/D24IMMa98
eMzDLRU+O4k5AM4JCduc/rum7xGDscK8kpOoSfJwL3Rfo9sUQNGCxMaqYqax9HgoHepBM1/DmHqp
dIo8OZ/h5IX+4icMp+V/xbVrKYsMAua5H32IOWS8+SMZfc2GaGSqZOicOx4sJ0zj7UXr3gnhdNjW
4PlPnfUcxZv/oXRZFIB6dKVJyu8gWnF1A0Hy3PDNG5s+G014lCqmRWP455kJH5Bu2kn56lwcmcE/
glpytpf6P8icm5+0fysxFRzvpQs1fXSBaT2bd6prUGr8y5nPeR1SJ8JJUqNidvWl6P7v18016UcD
1JEGeo1iungxHAvoFcEr2NkN5exHsL5J1Yq9QLwMY5icFq8W3igdVtJEBkO6dtsSw/rga+txbqnE
KWaRt9AB9oVja1+wPpWdmx6eOlO6wJ0TkhGiUArDNs5NdMJE9S8RYbvUVTRwrkWRzGT4uGDdmmjr
1pTFDf/2s2etexQd0UPBy2y15wxFTjD5CMvIsLWLWkYhu/zE2AuuXdENyqD1TGUkesmO89STNIeL
fWI4m0a=