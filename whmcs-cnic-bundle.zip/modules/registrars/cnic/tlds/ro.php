<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpEtFpLB5uGw4dkg5ePnjRjUBIihi5z9+jCtyj/xn+agzWjxRfynCWT5aYFcP0kLDkQF0TI+
UzbjSWjkv1jfAsBukkOB14xzVmWGv2FG0F6DqRY0nJKjAhbE7egU3mSM3udNlO5spM0FjRoNu2PG
1z6JrUSZolTsu2qBoLztkX5qPzfBQq35jfK9t43I3Oyn1rlCJVN32XwCUYLuKOY1eLASlGtfxElt
Cg1OBgDtPLcLkVEPSUZi/cVSyNUv6J1BTMC6a7BTjfIwBP1AAYqc6eIq/ZX6PN7TEGWV/EBEfO92
BVT5Un0NCzlBQ5j8G/8ny+AALagdcsDAb1R0g17IVvxxsen3vkF/IHJEY7WtGiab8WHmcwJSWJkW
OGIwQ6zU36DVpeeZp3qlu4x4Sj+CaDAxrWtUU41dDYMF642cHmg4jUavw68DPbAYRkLvZLjbzrZj
7/ceWYctEyH2jRXn142Zyx4HU3PysBd5JD/Zyl8zCzJs5j8Ug940iANMTV7RbU51ltMtqpX/tiaW
ncMAgavPXFd4Ng9lEXF8CpBAXhB9ox6dte9vMvWYgLT5ZG9O4IBaCCpIjoDC5qJZRiKTkY4TSXET
XlDMUQtL18Q+l5yUSqjh6xjfmpleL4ClnAB7s/XNCoX5o+1d+KPqoBKvElG5oLsSM1Y1xXtCrYSO
YjtVGeJ2gSeq8Jk9Ir8/uZjCy7ykds+WlYIn/Vz9oZ5QViNvGZ7cVTDjtwUSKlyB2E6do91AHfZx
OfmOKbzyhaDulpUqH7MeQHW/NBOiVWWpwdjXpknLopfssMBFrafiIZbSfSwwYaFZMvg6KuhNB9Sx
5QvgJqC9QJywPDpShcRToobxldOwwyNKoLZMzbuqRq7KFULJBL+CUqe9VtKJ5ifFPB57mZLOn1+l
wEKvUPRO7s3z28rBbDX3DaYQyOFV5VRdgxsI5QSK036KOoe5MLTGX1xKRUHpxHLMuImvMzA6wjc2
QgRJWdEQufR+RA+rTcTXfVyMo6THdzsJmDLjk4eZPyCdDEfk+9JeeUFBklNjHVYVM+HyxF6QsHoM
GxMX2Gp4obpsNM5k8lWC3/19Sf6qqdNhlR8qCUJryHUuP/IqRpK+NK/FNJHNzxOwL5gNJ4WvPOS+
KJ3uCQmmQWHx3Kmgg94/OgdkAqlJkVzOlBFU75mNC5F0aybjvBaHTkQ+EhUcqXQ4CDwHG7DiWGjb
RDGaPyLzWFl6sIrJw5dnjle3X5T95M4/deDxayCZPc25Pfqjervx4klLBIMmPQ1lOGK/3LhYOOAv
HZdcZVPOk0TBbahWNzFynUTLjLAIG07AeMm1Kl7UGOmXsjofj6US0hcwrbVNC+s+HAUgvez5cTR/
JkcvShbaFVCV8uTrb9NaioMloaEoaR/KLsd8Z4Nt5j9ULH09WPa9BxLNsqbDREVZyHrX3OIi6luo
Ig2iOwPZT3Ze1ccWwY/P0QeuKHg21XfSbAf2qEjQRYFgNDKSwQtJ8nHE4dT/Vps6gesF3EWKFxDw
ZudqX/y8MZLx5GUzs2pScrqnXX8fmkT14oQs2AdSvN5ykEp2IenURkny7v/oe8Jc8LV2GE1ORVBr
VUL2WnsOSzy38X9/QF/zJNF3Ya+pDOkhiA/5UBW1KdZiE8UH8zBEmlCEpC1nOjJHS9NtrUqc6Waw
M1U5OMEORvQ8qt3MqtsgSUEBZ8jCWoS5/qaAcAxItizJRH0IkiFZCWqf5CraAaig//lIwl57e2kr
WcnnHIGbvytDDWJ2Wq4P2j8cViR8uZ2jEDsnWtATWeHTRkMH6dUH3g+AhRW7qcVuzFHRGgj9WFN5
jVVjDDmaJlObhej3hc9w8azoXjDalqEZWXQ/fPCgoffATJAeQifpaM3ZeeW5LfdCXBAFZ9dV09u0
sqPkeo6PUFR4JbIXzeF0XUM9qIoFO0gdzooWYB2sdl0IqAx2pfVxxxh7fESWPrKXijYswNstTstd
1Pfys7pi63FEY7V3zgqxwZdtRLWiUjz1J5qLe4iRCzo8XCFwajtI4zB8l2GuuSXNVUduzoJ/A4th
rMm3T1m36WzDXDjP/aOxVokFkKu8/m8At7mV/hGnYgCssrFY0YsBDHBUkBLQIhzYyB0TWJT3Q5rC
g+p126oqDNWWrBRLoojHuTyor3HpRubrO/fp7dL6E4I3FZPTFYv+8UAzovi6ZT/u3VsD1qZ9nU1X
BPiGvEZdiCYXpLrXyK11BA5rx3FEapZalJcIcVQy1M/YL2E+8kXoCgQGcK5WWft6CsNKN4hNS+/H
EnYrqUcpyxOXVq4f4WWCt3+JP8KU4e+EwCSznSqtJQqLB0y/pd1IH2cA4XAz6LxJyCULhPsFaJrv
y6ZnQ41q2Et3ugBezw8GPUNSRXZngYHTU2RcKfUA/GFA1UPGXZ26879aE/eRrK37xr2hSUOKRADv
kdQJGmMbivZoAv0SigXEo1G+bSB8R5zW8Z4t52naEj4RInoQwQJbqUtf0yhgrRV3lQmhI0dLgJNk
zvUGEJbCYUuz7ByznCHRBs9guzLAQvLrrcnqKQZCwSIF1T+2cErVsnr4NTidhNxsYLjAaejO2zW3
DU82WRXt+NCi9yCliSLVeEL8ptM4w2aTLLKhrnpVaBPe5CKZsveo8PUBf3P7j+VB80pYrbQso1ME
AA2KHS0S4cvvIn8CS3bm1pUk7cOFz1dhR0qOGiGeqdhxWunMs0JpD/cbU0alkqNV8jm/N3z1Gvzh
3FPWDd5L2C7+NUl7PmhsIvcSf2lKdwZDyF0uoqyb0wTfmUQXAdITO/2p8OO6lbL/FHgFPCfB/Fyo
UwKFjwhr