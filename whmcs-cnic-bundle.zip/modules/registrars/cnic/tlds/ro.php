<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpzMK893zAYr6fh5eMXSQiDK/PtHBGsYDDv7Mc+aXFq/CZgu49FhOgKh6m3euvFl6zlqDmt1
vDe7895C4XmnGfQRV+ZkRFYvfYwItbCILwq8CaC9KKz2M58Gseo969w7bnAzS2QU9hRSB/TzvwTq
nIlHEDKFXxNHqGW1eoD+WstsVBS5QPgVqo2AVwtVDUf6v5lj6MM1iT73EyJtd6exqRmckqSPbZOX
2Aw+xyAsWjH+VYdHzJUKcZ/7XNJvkgHpe3/UEIlV5YMD7m+6kdsAmHpVv/oeQUAnPLDqCYwTx9PD
LzB6OJjsWkExfKzPe+L58DuOqfwkYmIQQA1JnDfxWUNhSyp0JHZT9NxWeRyRp+gy5Ta3CJZuWsUt
hjgEWFUZr85GK33GxE9O97GrHZkj0ryQSTJ8NTUIjS4oL5XUAmmUDhdbisfVPnh2bDg8k8nfle9B
5SMGCs+IZ8YIplCbDrhIbj/4trGOaGLYJ+aPern031WjPbUPXic/+xcqFGfJeG+XFow+baSTNg+P
/KjKINlOzMkNinnGc6aJejFScrYMyGaoufvvYzQAm3LVRWZ+Ug7l1ItYtYaGis5UXlFbkkGIA0A+
TL5HXtz1yNZKO8MxUihM2lT+J5ynrXnYASiZrxOokPVSuz/6ggbqKyNZwyLCEoP1t78IBiQePuly
QqXmdZ+rTy2tkDMzHhslx+dg4LdVE38pe5DHBvflpm5P5NVNhqVm95ngrWjX61hjf+zbemVAJpQB
TqSd9CccmnsFb0LO8XNR9YCPPB/TJ33R5l8/nj1X4RYdNWPO91kwX34u1jtokvkOMna37XVwcSyZ
X8k8ODhz1+Y7wjyiQ3ZOIeXSZKI9vGoVVYrjbAXPtK3K3VGXrohFHu4SMpZApz+knNzgDGL5PKsU
r0brn+1xeEnfpb8h4gxo2OnFkjneik+/xDTxjhZHnmaSq3An1mZofJ4mNa83peRHVu82jwlqIj84
QWGtup5QKPdq5wgucAF3brhW23Z/7k1mA1n34gepC68pZrFxL6Mo4knQMF3wM+ESm7PZrrkAeFhS
CaVrSoZ5/II8Je82caTyZDeo1z0FkNrnb0OWNs7NUQ4h15gb2/SFSLz/Ml8F9IKNSmcblFMVdVel
mD5DCYxznlhR8u0huuBaYCGRLrKqH0qzDmiiKupaAw5Qe+dqvwOJJ9SlOKyI4mBvfUDMGQntQiDV
uQxn7vOaq/yG9HCunh8W4urtMqNdR/RzbFZ2w9nnfQB0J+5oVEDLxeOf47OF0roTPKMXBl6KgRlR
dfdhtZ018uxhM2yt8CFIdsyt0TfSa6hW2zD6S3IAjm0RvXTd8xwnLeyDgk8sky2I01ZxiQRLsRRT
pEjq4XmLQiEuw4gp47P6KV+0K5ik6pazfCvkvOfWJKGiqliMuR/tHf7ha6u9Q53KLaZeITSGCbPX
GsbgbzmVLC6g/flTGhTJAdEC35Q1AUyOKtxR6lxVogKniVv7MCrg4z9nFTvFmRxwRDr7lGmeSCXC
+FhAb0DdlETYcrc4eEHkFhaKAB9Acoj6WAKfuTYi0qwC2+dFmHUmH8LUNlM+B+Igl2zkdBkQiCxJ
voUZad8DvmuRq5sW0f/BmLUxJmmxArvCunEdZyqjSqMlBlrwCKlKeufcTMco060KfdJZERZREO+X
35WoSPWplwDuyswiJYdkxyBbWhFl4fT69PGT/zGplHBFRW9hYP9oiDOOvxUXIbPewJe47MeIHNwc
aGYOzsacl0cG8o57oz3rVANfv9wtu4U8qk/kXaRY2j3FZozgShGSiyGxYOkPcfAIfaPZ7eDvVNgj
y4yj4TWzNTvFnDWuZIB6VzLkHWGRNgvw3i2yaC9J7qJq4WSIuuJ2+JwKHvQ61H3FjsH8GmP+RzVz
QJNrSOKsYUCub5lJp7w0qbOBc665PX0O+xHzAr7chb7lVpXoIAiCvPeck4ADZ6P8ZnizI3j74ODL
lVOiyy9XT0sdZitf7FP8tQEHBbKRRoTxYgEMs3QmWYL1LBPVc6pq0yS7tleqyjxklzJ2ZsQ3UJh/
4LQqzSydoDXEuEm50WT/GA1zBMKjY1zSJcHWWimZdGsId0pfRTVIJtTCKv+/BCG4gaWSFOrswkjH
1c86MmQoNNNCcaEIkT1LUUmWpTyn8XZAOqu3nIcBDcZhIUxUs//EWa/6qgxBXw0SDc/vT/R29pCQ
MuKd/qrueK4+dx9OkRixR5eg9z29LE2c6w2jnM6hlk2qKPPTwXPkA/8OOw7xPP8vh/xlW8pKxkAW
NbpzjMtAKI8gTiMWRHdudxktjso0pNkulE8sWLKs6bHwWk4n7jZQOozotKIpbE8ZzgiEv4UDbn0H
RrO/wolD1xlMpX9CC3kadXIt+ftUZp3bYUE0QVzCrrEKhiKj62DNWgDf2jJriExMRUDgAbs+s9fL
4mHsjfImgGxwTSbsWFmoV0FA0vY3A2ivMeZG2VcqTng+xxPa4ycJfAi5GWyYrA5wj1XxK4C8iNH0
WA6RwttkSm7X0OXz7RqUdxCLFxhAwra8Eq+8HygzXk5BgHnFCT2pIxwHwY2kTfvDNBW945B9saHe
8tkLaAVScuRxKIppBYkfsfBEuFpbR/D7KvLSUerbXEVHH+y1dk7tVLKf5m12ZeE7AlI5ka0At24B
6UJf/530qTIXJBrKIvu+qH30qhK5DM8Nt4d3aahn2w9QZ90j/j6lSflAepeCVEn4JFnGlrJlqPvS
DRqEaQ+ZFZ/eGjRNfS0oPhoNCdcq+Q83yW+h5p/1wbMn2KUTjsqduI84Bf40lDjnAZjhNg9PkpMc
sye=