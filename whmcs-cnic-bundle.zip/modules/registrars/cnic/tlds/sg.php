<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+aIROrY/LMZUw7uhZPoppYzm+s9vn1W+RcugBrfOD8Ox/tcQuFHG2Fp7y/TgZOfTvZnKqNA
0n7lqOHKjIBmQojfMNQhbbTLVaXEIs43bF9mZIjyeB5Nz/cswhn2lfC0+esKdvWN3MuC+qlgaTpQ
4ue06e4+cxv/9nqoMa65eYyPtrpIRA8QY/YLE0vuzPuBasozS0aZrHMPiwhAyNHxONgSsEl/pzf5
T1nbhvGVn3RNQdn9V+31X1ehCqcDyGFgSUu8SjssbBeja4egBIOQXBJ+E31hNvdnE/49x3xVgqAj
vGS6/vmKrn9kpBDix4VD1h1KUdUrfM/KvnqtKYEIgkRCmCVwTQzIiEYQYTe8T1EFpcakjxPzoctT
3iyQU9a0OudzvBiq/zgnj4QDJPVE7P05esQ2fcvH2JHgv/ufru87AOQVnFqPsPFOQBK/P+S/4395
+JHrUtYnMUypVYMGe/uxBJqmKPFlU6Tegw9InlmhRKFZY1vkBhodRhFA4/MmH0dAikKscrO0Cfzr
K+ikxVwoE4qjzfYPEBzxvthT9dmCRqrNo4w63NBTSgNmgXmAVJxu01EsOcmP1a6bg/fztG7eNbK7
NQfRDGea70BNmeE9dRlrOKNzxYUyB1Sw60kV1j7S5sV7uecODhXp6mQHMHboZzHuzcvyAlD+/7KT
YbYS0XO1ddcI6KaZdYsmH4zF4TRq1vZjYOd15lODjkZv31qOcFG2Pz5a/7LjfH4WA6OnXnMynLCI
JdhGN6YS0FhKvzPxUknkT1XhugyuSNt1APoeoczDEV3RiaxbKnjoNOYhUt9R0X37gq/xJt7+7MoA
bR+Q0b4HD216puXBlbqKY/mBf3sBE/Oa8hyYTaFArTqxVy403v4hRdWhgfpz9uiWj6Nw37Nk0526
Xalu2uTfJpU3+3vsbHi2uhdPa0g01xJnaPvJIHHnOpWsorI+OzET3yzSQfQfV1/XvSruyBJk1dXY
f2wEKcQ7T/yagO5Izxg3+Z2CbhbdvCcRxkn8bin8TiDuseAdohqu3UGDcsLel4oMdAnkJH6Fiemm
wNr/iqNYkzCHdL5R941to9Mycq533FX7J8iKpYdM3sBDd+dxTzFaQUxL7sy3plM6KY10LhSksEAz
LvR6oNMMLLxBgPbZExCgQw8jUerej4EYzW3u8/yL24vmfwHT1OBxTiP/USX9OFw1hEo3qaKYvxCF
krf62RPY+H9EJRX9VcGWNwkiQf03nZdyHaSvy8zlcseOCGPYMzzlgZyWHdxwI8ul9l1O+ztHu+0g
QXXnEButRstxE5oP/Eb4OkjkkVJtjOrPEMtRyqXmljeRhN8LaGhGVyOm9nZvGy866Uk0JGDLhue4
WJT94Fl2QmHx2PYLDjawGYruqMQSUnmiKJhdqZyhcS9OxoSEbf+Apb7eSxS77KEQ6P67atbUszZ0
tW3zEPIkdPHo4cT55XZlRDavu3W10GDK6rTIH/XJC/UuYzFfHT8DZ35efXxHMCWIFIF6PPKVmuVq
vTrWL871Ws0ppxwLGsnjoNFHm7+uiqriDHtVOcZUC9J3q9uENdSHb6O9wSzPRXRdp/ioE0HNJpHh
79m9C8uCq+SDFJAxG+x6Yybz+0IVlmPqyRtIENX3JqOTfG9DNgMM9buReQXcPpMvwHeOCjVPLDjh
2Tlox26Msur5q3d/sVpfAJaWz1CrTOpMJBYazPk7k5vL0/6BD6tMCcAOrAzV7xBcT2ncHwb5Q0/M
Fsb5rX+gQeKTSW3qoteVpagAFPeYRxHEKYNx65KOKMAJUmEyRgIuqn0n754ZE3xVBUeocJjFU48i
0NIpyUhBeDIXpYHsgGPQd1+KreAsfGttvX7CSyj76pwJD+rP1HhMKGPA4PQ3IUn96Bp2/je3hBwU
eBan+olKXMteBNUkARC2rTAimZ+H0E9W0d+Nt89MzBPIcA++WxvJbKYFXLwX0zWMYR9W0AGU/hYK
VyYb+d+CgcaUGUgLQ9jeTc1thrVkhylUGiuV3WrX+cNLKLz3S6Di1fWC8RMB62FOjN8DlvGV+5EQ
PbFC9KzB+8B+hE8HtaUR+2NKcdXBnr1sk00IHwQSSIUmkotGfGRJ8iGwvisp0dsKWzogE8eXvsQM
Lhs5ppusXJZSjXEIJi2XYhSGCFRThzIDRiW3Wn8RvufO0dRxajx4Zh+AKrwO4DVvkpMR4P32IAby
//GPyTzSrQYw+pwKD3G4k6NFNraD2w8tmvrS