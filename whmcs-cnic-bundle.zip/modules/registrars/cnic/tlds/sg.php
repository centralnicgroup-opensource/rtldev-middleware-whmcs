<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPym7YOEmwN6qJRGSe0jq+umSzsvHbRzCJOAuXnlvCQp8e3q2KwYB+lGubBbE+ggWvNvDjITc
bnh8IRJuR0Oz8ywe8fRegbK1e/8W2KLbDmmuLueFzCewfK8hxtma7AkNUt4Ug5NJy7LiSWfc7Yap
qDYlNKAVlozhqw6NQJ+l3BwFBP2SOcE0D+JxCcvQFuJCS2/VJVSkTflbQw/7kmPBwm7NHbn3JExs
Q14YFi+B3xv5yoMW+1CWxYlX9/tNiQWMApQW6dpVV5iY+qGEdJ7xGhOwLLPbI63BrG3r9sZvhit1
yyPY60eK21KlFLfldZYieyP4g93GXvGDWEGmXu9BEsJVbaZxoZW03JjkB4jS53J5JlXcgt8wk92B
9Y/ap3irif6c7q1/prurZGIYx9KM4UNPIuy+gNP+1CaKcdveOJrjsM87Z6K+AKfewK9RV4qsiJIp
Is7i6jGXoWWK/HI+sJJ3ysxZcqKkTNmV4/bD/L+IAwZkxxDDgJrwGCogB6+KZAFyq/q4IZS1V58O
XES1hfhlUmeUZWYL2r3Bh8c63d64t2fKxMr2bl4IqlXELY8OQyJ4Kaadach8aUk2KCOkP/Rr50v4
rG4WLQgktd1XtACrgB9K/Aa0nWJEbOCjzux7AWkjMDFpsIFCChd8vMd/QjgFU5Q1QOtWETCKHfjO
tTw8fM8/invKbroPW7baaWH98estAGp1GmpfoE2ck5DRRvNDigCzp0fjXuwq8wVGMj8+Qry98W42
TKL+zBIS/uLZ5p0G1yfWSMWYJgPnRHQmOQxftufH48uApuDXGNXe+0Ry33bgrhVKllSCEoqhuvEF
uepOy5OlHdDhRAHbKrwSJxmgrKiPsHczM3+tapJE7DINI0SDECGb66HQ/buktJilxEj+yv0SAP8b
x1QDjQppxtAmJHMrLfc8jRXmZ4gyiwUKSp8dlIuCb+hVIRE/s63L+xQsf5w8J7PH3HAQhfwZt8Vu
exgyXa4/iYpboQRS7MXxnQ0n4Q2c9xLerpGmyslNxrgerI+XfCB/+o41YP8bADVh67Qwpy+N2/Tn
qiY4iLcgvKpjoo158AmT3t8U5dRf7RTniVHQKfa5Too8iNzX4GvBCOJBb+lkhaG/+zwJv4uJpWXI
yqRtUftj5fQuIsGkBFtdSKECVB45hah5hK73lpGJicqhaikAUdjVc5UKwb5saBMBGnmE+Kvn/nXY
r5SghAqNmV53xXYtyGYwYmMXtd0aeCWkZFJ6ti6SWihjv31ohL6akAVsps7VQ8jLikOrBBWVSI3u
mIXmkBhTes8QlZ+UdxxNy9dT69Qz0GMOkVKONv157sJVZi4WvAwSY77g/ZeJfhzaeSkmTOPb7cS1
Fik6MUlNpBMmEeC76E5h1ULpiTxGvkraanejMUC2ItIwepXr+pcdcnieZjer9hL2CHZyXZjRyJv2
DIAGJGkY+HK5NcDKd1IxWml1/IDDUv04Cn4x0hqnAgUcuoF1TS8OYjYMtPFKYEiGaadOCWpJV51p
mIH7njrFNOkxIxaCPTl0Z9A4td5K2So73/0bz3fl/JQoV6Khhfd3ksIJhoPGuojRnqvZYubtkJav
O3JENakxFsrUu1oGwI9nc5TDfm91ZzgtClUcsch0DjlAl2XB6Yj76sEPBfYuiQ4eUqnwzxeM4Xax
S73NRf5kbTv+9tM6Rbq7edeX14NAKq50KugmFHtzEQtv1T1rHCKzEKOYORBj2d7uICummZWxtjPT
2Uw4L+enfdivnb67x+/PrGT2ja8Ae+Xo6+q1C6oqru6I60W2mDfaS1bVM9XIRRK+fflCUbGEuBKx
GSD6RvM/gA7RTqjYCmQYTytZnnpO6qs3c/j5EmIHSeV2Ynap6pzZPPCUJmyEgummEEbRH4ikxqlu
plz75uK4MYazMS22v/AmDoF4zI4caZiETNOtGnAM17aEUXITVqeh8r0aP3skxT97cyw8WMzncexY
QNfMJtsyuiRaWeUfcE1nfDl8SJPSTNlToqfQuMlhgFMIvLaYgIWAU88YJeGz60JBUqKVDmFQqJQF
Afcq6W5lFxYH4OfBWNHGHyrkVdH9HTSYYQcAMHMm8fqN6xCsonj3Eo3FkWhPSQqfjxZ+dEUoVigg
g9dIJgEaI+Z1Id9AY9b+H/fqM/uByOFQXtlCfp3e3zOKbPgf14tDHveC+OC9dBy/xkl3ZOKogM7i
vOxVWju6RPMqdZjbCi4OMXPtdt1drCLO/Qtr8HHNYe0ptkXlqhGTAOsqDSWrrG==