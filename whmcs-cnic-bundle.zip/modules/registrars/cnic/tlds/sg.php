<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxwKe7aZUnb+EYSrMWm6DiwIlgdLB366rE2HhU3I7ydoRGbf7vatOF13gZz24YAZaDBg7RNU
KcJaXkfFx00v/1qqsyjGmjHxux3+XT8ap+qsLMPESA2Z2ceT2FVgbZGQWy4qV3SWOgx4ps9eybjD
a3SwQjd0xndlrUGkAqeBq9nhOJEd7iz7B+PtXDS3+5Gf1WXtYBofIRqwHQC01pL+2eyv49cVY9Iv
wVpxnRicLGig6nmCje9grKSWgxGDNZIbNE0gSy0ecS5h5/SQ9v2j2HIeQ9btOsnHz27VWRee9+hN
9eeeHhoEEf+l5Ym0h+jG5okzv/fP2ypwI3EnvbNh+GGQJMJtjPWU7keWcmvboQeaesupCYN38KM4
M7rw9K10914FW8F8B+2hEwrVcm27q/ZAOitmfWG0ER82S7utqKMoNCqgOOuclRvUQLn+BFeDD6Zb
pCWvenXVF+z54J0Ymf+sDF+T7lhfgONU9PyG9uAkCkZ7HBTCqQSVlsguRrxShZdbTbB1E2CxqRIa
OTKifjisAL01l2OM2ScOUyLAxN3TSuRzNItn4TSZSB5ztlWPQgWmvvnLvsGmEuk6oR++bibnclMP
sQsOXgiNJgacnG2gZcATMMmIq9o1U5zwzEccGsRSN7fyS9l1Z5nu0MK3Y94PWmCun8q1Gwxf3GFf
HaU7rjPqM5o+6m2Z9Dvc/3b/M1dPiF+GBHOAPlJEyUrXVhlIOb1mkWd2UZBF81Nqehqs0ikA9HKu
Z6+ECVCpEacUwse+KF8pBxRokaZNUYWe6kafxHGJ7U3z2BTCpx7EXQHXpP9fU9csfDlZ7ruBbM/R
uLKc5c/GS5c337fs8BziYotKie3mM8wmB29EnRFnAy1aPT7cUdrKCBOoiDMCkApVPebmDt1G9aM+
mFbn44BDiVrvzXK2YtpdLOE17ZgJex6iKpQQGrLWB3l4IGcwxnkFJpbefat4GySAyKY7RuyDlzbW
Q8roeu72ihpcnWsRtD/S/Id/6rA9dGFc2pqfgzqXHO7+QmqVJfLVzI9pmHhHMi4T7ZyiiH/LlPwy
j6Nbnr3FIwMAjKh1nGdcnwC/Q5/LMuRH309m4Ur2/ak2OaL7GBYggjJw9+PUMdnERb9huQf7xxgf
/6DnYnK0k55AXtFDD8zhd99oqW7IfwHNSvn9GEOsFIDENSrlnVLOgJuYyysG358fj+hnm/RurJz4
x2BI2iWvYQbEWqgKm/2uPzxN+j7VJdd/l47uuCJrHkEIViZG2ie4vObg7CmgtlxJK/1n8N0dcCO3
EAgbUSxm1qaebCKL8JuNDngXdGCGi+XWKTDE7PNk//GeW2kKbDwRphJIZd/CNFzov0hld2Cqm+tS
v00IoTqZVPKl6M21lBmLkbgsDb02wIcBM1avzKwZWKjOhn88RSuz3Zx7+AlFrPi5VZdVxFanbtAS
M9MuBy1Gqqm7DMwD2alyHYzKA3TFanL4C0S1Rxe0XeIi54WeScmir05gLC8/TSZsHmHg0ai7kuMY
ml2zVoc3cavJFkpvgB+9vb6iAckit2pgRqQdwE3NlT274zHI+d5pPs3UDqwUe6uFuU2p/QTpQpzz
FZ2PmDoBbQTwQJgD/7AK0YCqI8A0/exz7WK4JHiqGGgnm+k2GJXrU3qth+/tNz3lCOXB7+wTo3QM
hMP1OKP6UzNp+4ERkJgrC7Ln7/xHTTEOROhtdqVA8rIcaaJZf5+cqfifGOgimdrT0UAHS7K5MxHS
mG+LkcpP2d0Uo98N4xPBu0QRdredh/9Y8nfBvptYmptsyd/Balqu3jIGDYlD9py9CTv3lFIHQRJ+
FZagap1vudUO/cYKs9LWBR4qfGSV9zZQQTsklj+3a0pbJGD2Y1m6/Iohu8tw92Zr4/PAseLU/Exs
HNUx3XuvuLWECLwETPnyEdFNb26LKrQfOKhg7B9GzWSH/5EXXl8GUxXiv6XgPoS8/fga8jkVTdCF
s2H7szseGZxN+qk1Y6306jVJ9H39C3hJ1RQt0mP1IOCL+irKuNe17ngszgApOfdB5B7OBNsPXYYf
OafSywoeykKvMt5BsVHoGJ4RWOrM2C+xkbKpeARq0pkQrM9IpHgbXfWKHvAYcSAEgVO1e0N5hVWK
1TWlm9ntflSD00b63gNxf+jyM9hS7wXjEXHVYz4JCzqdCTDVSfTjT6WbiMnHodw2eyhJvbVYTYOh
SyT976McT6/zR5g87WfBnDRqmlkFMS045anGNxeAQ7U3rSOeh/7Gsuy=