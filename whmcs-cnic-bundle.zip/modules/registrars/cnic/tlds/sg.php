<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnAVazJ4PcWRaIm6zmzwo2ScoSQ8dDhGUyCh2BvMGZwNU8twIvbwvFSIan5m+yyOBGXEh+fE
LfTzhVGKVyFyQEE1yoi4C8+C/IhAYPxzAAI25n2EqVXRnZTq+fRAt1B4lLfwbrMGXm844hwYcqDD
RpkwaK38PGMBNPIFeE3JMxPTtKW53WxKf22tBWUDiY3EKKz/j0wNb91hpoeL2cne2tjlD4mgeZDq
S9wHPrawGS21bVYnGSFENby957YlzG9WwPo1ipcUmGR5TtnuCaEknTiC+jqCPaJ8d1h5ujxKdU7F
brA8PVzFjfK/tcac1dbcEfu3GipJ0w3gw2o7uD4uvUkzw9UWzf0abdfGlrnMleIzsXGfwqYxxqfn
yFoxqJNVGZQLG13XcYbKf445UYTuNboMFGI2GahHEcfa2N0Vnb93/ibOvSM2ap2dOwbaIGFJoIoV
ZbO8DYcYVaEwrYiKUcMOGpVc+nEOVy5OB7J4Eg3SAiHEpqY4aOHBmGK0gYyLUCEXoqdNxfJ6Z4qe
ru7tIAerI4tPDruS2o5XapxV1hbscWGRxitiN99+kE3zeAC1IylX2wKblAYjQ/WCJXkAwq0wXf/k
AurLzLChW6SukuNg1R+Yh2IbgLY4R//CQKUVN2xEix8W2WpOQhEgCXxEEcI0NGWW07u1pnIiUAfq
avd+fUZvDKXeLLMOdrz42oPCMhQUpHA8zptJGrcebGE7vvnYPi900ZaA7l4c8VToQi2dvbdJG+HA
ydNrbMYciHV+nVbUww6b68kDZxh07w+DBoizeZgXs4JHV5FujpT5ib8kFWvsv2Rxfm2fAjC/q8JO
nn7zjNbD7hc8JkJ2fvgjowPx37mnXRPnEfJQylr6hDXcsQWwTwTmhjwwuXdmJGbgHaX/P4cfamXk
8yaHL8rjpX/48LwXhEbvNu8aCAXFKZMiqn41Nc/GtQSGsZEjFlDrPJJxy5ajpx9uGjxbI4Q+w9ur
wqWTXgzyDOf9164vWVuNCL2kmKnURPlsnWAx0ZrV9Q46LeIxWjdxzGhwjyBr97Gp8Gt5nm+QXMDs
IGpCDXLD1dtjuZAdmNiH9mvpuJS4Ezsl5hInWLigsVnJ0PEWBJGUrOqZVpJU00QysIc8ZKR8lP69
NpMT4RwFJDBUrFfMcGre1nYDhvRptB4TlqxOypueWk8mtaSFqpilaDys5sCZAKANEQ7qkWUsW9zC
1MTtwZzl/KPuMZKWOFy3KsrT/roREEN7FxG9JyTuRpUkHiZrgvZIrbpqWHlhtM66uFtl5NIUnqTU
hc5Gi2hgb/PguP+M7nQYhUzNwJxhdEoPkq4ZRvSV0ZE88dpyXr1hPtib4BoWgYNoMl/DxNnyJ7DH
ODos4tAq4cRNzdUE/dbKFiHsgcvtThqRRaHN9Nu7Bmaxu+XIYFuillmKZLyrvnG13jn33OiDBw1L
2Fw6AaLLz61PtxlSvOf+Ysj9Ey1CZXfGAoLAvd32ZRYxyEJaxjxg/6IUi8jLlTNo5HWYnt1Nus/b
Pa/41JBCANsYxvadBily0FrIu1DI8HwR5fwrr9rY8sfzqfjn/ayZ+W2hmBHRRDoD1FsRTI/RkMdm
1xOKyKkidvdycXAFIPI2VaxMeGkWERW9HhjDC/+TFS3EbyR9PhqUHCEdVGLOIO0VR6pjMp1F1LJ/
rVMhTFDLzjDfepxkG9kTBa30BM52IQ+8B1QGjw/+Te8eg/jEk7GSPGQV7WSJlzzJgXr0BWl4fi6c
UuepNYY+LVgzbd/15tVNYHaXl3xfBZwdn7XrSGMeBoptKmlABzQ2Q7KQiVhBdijyaiO1PsbeUmTX
wh7tWEoyAIF8qGELYaoQL9LDUdO+kHUPMJTXElx5XutNo2h0nmnCQgfORz8vk16fWdBYX30ifUAM
xMeOfD7l0CHuNt9suWRiALeVR5J7yPWZj9w0vonJB+Tj4OyweRCYt4rPkOQR0r0z+8o6HzrDrwQJ
rrqifYrKTWecaGG233ss+0lRHiEozhczKQCCD1yp3Fs6pHmBwUIFX0gC37bJkWWElzwLOA+GsHsP
MYE//tLO2JyNuhmIVTCrnkTwQP7Mttcw0YItEGkTltfX3GQ/EAnKixEhllD2fjaRS5GiYneW2zYW
vstNK7u5bUKXgTs9Pne+axeYrgB9/JAcntnj0rRUb16GbKoFuHo/7+lT94KpaLvtpeBiIJU4Umc0
MFw71KwJQ+FGofriWRMC4rnl8ssiCH/eBqOAKKeINFU3E1tMPauQeRlAW1W=