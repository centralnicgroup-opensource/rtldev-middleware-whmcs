<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpKFNYYyrg8FkRpB2v8atzcE0Zb3kICS6j9cXAodAQRoNEKterBcVSKxvWs1kXEAcH+nQ2gv
QolKmpWXaM8fy9dgbSh3rsxCTylT9dchlgODp4vrAKjmK93FQdjv0jsevEg0XBBe92quppGaL7Xy
GxRkgJOtTQsHjuM3a6CcDTRYgr6iWyyDsa67nA3875xnmkGBiucVeR+VIG0SV0SIx30M6Ju9Q6wi
0Arg1ab/qTPD29ZZFO0pOJzRmLsLMkN5ey9xFKYDK1aSaWwd7YL+qQIW3bJZP4hjRn0ViIHUeUnr
qPM82V/lYB0o8lqo26pDDUzXY9vI3GnyEWKpYsoSoGHzwCdiO0zt4SFajOO5T8JMhPUPqU1SFMKl
RPXw7t9Pd7YaSNmccxeC06kl8Ovmo1v8BN5BBgwDQtKluh48+P/1gygSy+0iw/Alt0RjTJJ5jvRD
TiQmeGrKkr9zHWXv58Ib+g90rHrJjrSNAumFWVtMfXbZDWVynScApJ1aXOutTDn9v2RW+Ss8jOrp
JHiSpgMZ/nKkP3GNYsvXFSiu88DWRZbjbl6oq0lZAHBx3tK2V3veDTYuK+PS7O37Uuvs1Lka5f+u
3R9yD+JQW345jPtl0R36TDurbrLaYk7OXAYtoO8vDw1lQ8/iFdekLztZm5Kh8+BlGTpJbR99uMfF
rONpVgGHaLVRlv3M7sJ9BBLEfbDalBDI5rGbpslY3OBEQBVf9aaqOggDgb0fCp5fPMu/pvPPnQse
HOx/DQLRK3+jbl09TSRsahz58S1f7S25ZqX74QvTcerg7tzqAur6x3dmzcc9XxnZX1sfu3Qv2Mgq
UzPgOKnv3pFU+Bt/ov7z2mbXzlVUyBcsTYmVOCyBjM8HZeoD9DVQPwNc7Y4qgpVK82YjhpMPIfqx
2YYwoVZJAyi05RWC5Kk1QRx+9a4BOx968N/KqcgMkm3A7mpq7/cGCYM+3bsJPXuBh/er5lXOHmQb
yn6s/U+WUzDBZ23WQWNJ7xMi3qVw5NVwuht2O8PDD7920UoUD/QDdneEPtFYRLYW+TDw9lTCO7Ja
I3ys3bAHnorM2MXnILoLlcyfd/5YYWWhdK+txb1utGtemvDvZEhqWja/8/RmGlsGdbkx5rWSMjMS
R6XlmZxoXez9L/LbbeXhaE1Wo3d9yQ8H6gyrh2pJSonrY4obSkd7n5xY1fKv1Gu9k1JO+F5iVC2s
XyKZjH3PHTEktrLMD/8iXsJfKg5MmklZTor+q1GLfHFXdlg5tJ82SF+rl6Zc5/JKL/ptMAQEurXu
+pV2+M/9dfI0SI0U7yu6Pfc8d3BMIXoSlDbBjBasKeubEhedNgJyKf4aAl+QnQ7yYb13psGl4EJ8
h5MTfFCN6mchVudyLmiIVTYZH40ezjkcAgt2x1atJLj3+nu6we+2QhA8dHU/2HKr6a1Zbf3YPqcA
oSRbch0aXWhhOWoND11h4G2SqlW11W+geXg6QKKEvzo9WABWWv8F1mhreI9ZB4Yjl03+Bawa112C
Pxw3Y3fL9UQyA8ZPp8IaNi6yqPlKea2W3xTslNqWP56PjUdQG8tD6j+dr9/7W8IULc9EWqapimJU
QHGndNOMj9aeBhtAqaVe+qyarEJvhu9dez6B7EX79saxyrEH9cDk6BPxZ1TZpueRukAwdXia1fQO
uBX7Li1GH4Tw94QQUAv+qMz1wCDY70cVpXXEkbVnz/wrXVx5g0jx76NSdfawZtq0qYholH+y5Cyz
DCOaIHWm0XI35x0+cGjleFYovq/jB+pirao2ld9Z/DsNhtPFVkRYPFfOLkz0g97b1SIddBiz/SdA
QX5/DKZWyEe80Pd9c67pO5zcWnAna3VDNUZLnSGncZ9HzL2kt5EVDpMZsvs/jN8GfDrnS459+i5p
6LbGe3tMCPfbw/6MwI3dxqgsuIHriAyzSXKHMrVGky6rt+cCnoTkwdilM0M4ocwPJQeK//fTdeSf
BNcZ5o1CZsfteUTausnrGgFLYKDm5v5pD9JuRpy+lLnZbonztSw8cQyt5gD1fbbZEkANKvUw2JHy
dJuL/AlUu159z4L72rTDiDQxTxDEEj7T1j2eDpvEo0r+KrT8yws8iFyz+rr2YgDZiiwGBt6RqqZI
S60e1SvwTty1yLXgT6aiWK0AuKENkb7+dLof34ZnaMQQcVn16OQVIfouskljVOk0lzf8UuOq7wZw
Jr9MsQo1t6GUny4DplmROb2s1xvgP43zexkgGUOe/17wAx6nu8Gxg/hQu5K=