<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPscUFuyEOOIWrosghFP73czDtMdz6ICUmvguP+Kxe1HWEjNMJk/TK0PF5CFSodPzCelM4ScG
obKba03b9phghsRo/cWPp3hpYW+1AMYo8gCFo0561/1905+Uj5O331KiALwD6hFJFgdS1JgNIuX2
35KD3IlDzML4jxjmhdubP9jFyoAp8kKYZGvEBbUAQC/muGOBSgnlyy3lDweQ3eNCa2SLVa6RBACM
UPLEifAKsgH21lsJg+aQHTjkO5F+RWD1G99IcBlKA6H8ahe357dMXSM94/nVIzev9TRfRb8Yz4vo
qAPrWJsiDLRNaFNuy9zeV6tafvkPRkrvk8TT4A9wk/MCTn76/I7Ejy0MOJKNUo8x9NC88YEbraWF
RSV4Z/XRwC8tgVUdu7K/2panTAEfSXmrah2cUddBWv4VAbKlgtn4wHJ4ZRw3CKwZ3UooGUIcs+5k
nmdS5AxkBmX1qg6T225WgUpTHPLWAtrpy8dogbCxkGCfIwXidOjpqv4D0H8u26imYtyj6anvakvu
wdJR/IigoktAwho6HP+Rx9G4ke4V2anWHmVI7NKBIebOP088DRPzNhsQl8LUHtiPqy72+9BEs8GP
2DuA4a5FVlAB5qwIg5KO75tn7F8WZUPJv5vtUOfFwnfsrocChDP11xI265AMtP0+Cp5nVvcd82Sh
pel3wfI0ESc4b8jLcAcsC31/1WbCqh9MAp9+GqydKDRWgAXvHlZvizt26XZMlTg4lMsspmwDzE4R
iPJDs/RcR8MJ7QUxuK1Kzfwob/ZyRCnIcM0bNFULJ1YgzbRfldNg+aWBi93Ng8H7ig6KGrB+UbZF
YQr1HpY9UYnoX8Snpe6MqHLHRLo8nRf7Bo7ytCqt/PQ6ghrbl7wlHdlVccu1nUzeiOpdXWEtKUFX
QVYAebH7XxDxcS1WP4dBnDZzx18RYuesgrM5wEpABiHU07D4DcpUrl6jH/geQwYFFiKidiYlyQEn
6GPveWQ/jtvoW2WzDCN3rmEUNGmtnr9EMGMdrZyxrnnmCeJRkrpxlhLxaR6YvicrDieIrEpgN5Dz
xwexct0rMuQT5515NupT/tM4zkcC4krnV9LcJ9q4yvUCwydL3Nqc1ghqJTTND0CHW/gzI0580PbI
EOpFLD6fjI/xWKCGywAAfhCd9++bjzJOaAaMFu87tv93oYhxUirN/XoRDtRVSLRK+OXpef02AfnA
izAxgPa8IpILLNTukDsN3UUYvOxIsH3Z8pZxMRUOcB8J9vQF6KE6uEYmy6zNwQAc+jAE1ZhpfCqA
ce7qWc4EDsQiW4NoSkWfY8/SoKzGrFfmkeAbW0pE8n0Fdn3aCBb9xJudYjY18J4N4/yNgVZT8VTd
XYzjDBPE1M72f5x+sF8qGVG5Ra0IOkCJmnbiuZsbk6kwA3x1OsOmLgDURuNZTmbN7HoD4hiJcIv3
2UuHTtWNXX0B+N/fA2phv7Q0s3QQfeNu7bgPnTPwvYukKAWJpJqjrXNQEYu8mFhGDg+myesM2y+s
rBZB9SpEZbsszRjV3AyIwskkxbqEprDaIg+jJF4rw8Z3pDuSREPpkaHV9JN+uTBIKuv27ovrmE7m
XDwIMpyQgDm4apFlh74TJa9N5qUTeOXXhNOQRCr2NZRflAUnX/5Eblg2hzZ3qoG/p6/3U8vQuXCM
amGLAF/c3SuWtbiEV5RvdmzdH98J5fJagIu0KoECEjqSnIPiOmApL1NVRusJ8X8i62Lw+ZDdK6J+
iykp7xAZc1/ko1gRTyG6ybR7CBAjpWJGwD736GqJiAGjQjMIgKjdviJax4n2OBA9L/XBorXRIxqK
XJPQnwWupMAak2hd8Nc3RQFGYvtnUW8FnXrnPwr5RxZED/E3+ZIybimR/0KNO012f5XmNBf/z4qd
I8hYnNhYyTZ8G9o+/Jh3khTSddGkB/atKl1KEeis9bEKsolZ5NPh3FLDAL6iNtQ3u4FjpPld6wl2
4FVF6r3SjaF2D+zox6c/s+TAyi1IcQP/0tqzQgWshOHwdTI50d5OHGcqNxXIp/4eLyL/aahCOyUN
U0QPHcqQ3fvyVR5DKXkcJqZUrF4U3XtRzon3CiIPWC3KOXQ/705FpsQGO9I60Q0d6RTpC62g9B/e
kPRdBvGagBWJeUjxZj1olybHD7VNvlLefm31Pu3Vh74a0lYINwJQ1hvZa3TkRDHEafC6hc+w0myK
ky1HIVzXsqKG7vlJczVX741ABbQTEOk0VaCfDwmJUn2cj+HvTuxpGkRjk87Y3yu=