<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsUDWkOIK7V9wpuNnOlnQu0U0VuiIPvQgTT3olg7wQaH6cyprtyMOOPvmw/DoTj3L2ftBUtG
74LeVVV2fsbl44LpA8XztJHAjlQeZ3e7i/ywuiWo3DsMblpzc93qckyKr4bXJN2aUzNQ3AZ8ADOq
KlMtOz+wNuwnVcd5KHqxz7keNPDHwJYGTusxtq1BwNi1ftGqGwk+LLwyr3L/ZoMM2sqQIwjRmCJR
qxhwrzDsFN9Ai4YhTLkX5NsGBLVtt19A17qMi5lrFvcYVYvDbJ14S53cab5p4cnShrSf1J3P5T0x
EiqmXr7/kNekVlCu0kM7BL6YuxSQfauOuPBasdPWv/zToajkgTH94J2ibqtKZRKq6D1pkHfPlCbo
54KJ1n1Oc9+02UK7ZjrmFY8Kxo8dT9T7X3fXpi1qJR4ir7a73SaNWtEX2axPwUOdSkyiGsWVBLB1
e4Xk/iIKiUcNtu6tJSi5Luwnn4D9T8Ve5Y5jBw9wyeaZnY5pwvakx5DchqlAzfR0sMCUk/gohHkm
r9HxZ9iOxjBmX2zVZPloXcq6uHis39JHT32jsa+oivLph0wxW20UPwgOy6p4LGNbd/HII9KS9Dii
Fn0AnD8QT+iEHvQ+wACm8RrupzW1NYvcFxfpL8gpVRWQJd4GMvx/Xj+xZxMP70Q23OnSrclw076R
lNNZdxhkqQsqvzJK9qM42oNoW4CCLci072l9HAoFUF6EhPLOpGfBIVxlTWOerGyhmf0nkcwLda9A
WShwq02r3eWEzUYy0vjI2vzQAFWF3wQ9VD/atNGhrvFapewvL41mdsrkxFwN8DCFrWTERPqAZfuo
0Jr9NIGItnqEN6nWoifk+I+1r8RSNn+QWlWeEJGNzMevoEvZ1nu17Gnlr2Q6bECPJ8a+bzIFHpDx
5i6q8ASb9Q2E7e1i512EJ8UyB9zb4pz27ix1aZ4kvbMQ0Dt8Je64qivkNRzFW3zmKZqgUDbKpXWu
oVbVnhmo7L84kBi6/utog+F8Z3HQ8RsUxuyA89yCLPu5lIPj50AndWCGzC0HYlDjVq4Yf/ntLHO/
ngjnE6mZBW0BrAEhRnSevAxFO1sw/0KvBvuItbxqcO4IxZ6KKKF9xb90ymeFiRWQbF1iDPkwLxfW
W6adual8ibVR4o74lqlE2dBptYhKOSqHtw7r+OXVeVupkBtN/9xUkeqmfrE0/7WhC85Ux2z6r50E
zvz0RPBlHNCkEP6WAVvs38NUdf12df7qL31gBSgrWvqtqc649mJFhGJMD0cbeeE8CIDHAQCQSLnM
rZaK/WwHmKKfExgVbjkDVdKHTUuS6vEP2IJdDyz/6wsNE0H4AR2idtqzLsfOzaaN5gJZl534Y5Tg
qnMxJQ0cFmrwMv7JMhTlgMlzencZSFvO1SAwz+JcOXBjN8V8XrjHstnY0gVamfsSSQGf4jmIxTFT
CpiFFLDGJfZGLC3jTLdYlfwY2GsV4SrPjA4XC6uMPA/ycMcPpeC2Jcw0x6b0pqIS05YtZXtQ1ib+
9Iv0eitxhH3avMJ0nHUKLrYJzn2hj73OSI1m0I+Q7UWgnmPIy2hbarFtxNEafOFxdzqzl46Yy/DE
ZNQGQKM2mUxF0pdADaSDTAlwteByWlLh+otQQxS9zi8vaCLx+DKndWn2q97HOXolFWYI89Q+AGMZ
+JLKXvcJTQg+JEybEBHV1mfHA/yCk1jL4L8TIMXnuhvOvCXsKEVGAz5QRRiA4+bxMMEBcm3F7Nd8
2/S1LyRxXrui7pwZLRY2+wkwZIXkrFDUrf6Ehaq/O12ukjpEl1T0U8VkSl9792G4faC4txEgFxq9
ElHOelUpryb28LF3+mUQzkYH12vgt9T+QPACQOKL6+zvEZP2HtqBEqZ0QMJBk0z60D4+OMWiyFU1
s0lE8YGjMdQ8VempMGbbvgLgRx7uLgJRcOxFXOeGT00nK4aWoZ+HsZVladLsrBHs8exl2USjU/xd
vCIK+aXagga9InIiPgEyvxzZGC12cB9WKJ3NuQTbwJTOnwhfOaAiepC1kvEdlNv7bjObFXHSXIfx
nXQ43WMU30yUt2zoUKJkUjAZHjBcb8hID2RI7HbtK2MpaJUpuMzDnJi5djmUmLGqzVtEZZU/alyo
nPlPMQly2mch8mGDhf8jLTWgaaotNwA5MdAq5lCis8bNefbmRE9KUT8u29Cn5bes7YRKRESxeK/g
SliuW7arE3es8N622wFizf93ld+YKCaUsroZCAeUlq6d