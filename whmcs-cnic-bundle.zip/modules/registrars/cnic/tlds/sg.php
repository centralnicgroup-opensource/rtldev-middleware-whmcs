<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPru64TiAwUaSqxM4+4jNG1AEIRJfPXaVIwQuX87ejLrnLGbgSCCI0WEX7YLootDvnxB37EjJ
1jVeBSBGJXJ5yY1eHLNoCdT33sV0PyDfghqGJPjBLc5lXYf7svkI+F9HNOd8w7zUPcHl5ewwlsXI
ly7jjGCDwuCGzCR8qLUCQ1MmdtryYv41CK3kOW3YPjhP/f5gnkiVd+D4OZNoOVI52StaoLKFmZJB
3isHo8YE63lkIDl6LL4H+rKge6Egv8PfbQAd7gppYEhJ9G9xXWTad9nBMhTeonIUqcexlQqECzZ7
EASzRq1/e7flQY4R/WMXmzPismAZJpPuVw2ML/US5f9U93YxB0hNALRT0ScC484HIWCnwv/DVwb9
4B7F88x6hq4GNvyGL64K/M8IYe5Fsb6Sfic+t/1j/CN/EE5GoBEXxsZ6YTj4eNScP6Y2I/BoLocB
JPq9NqSvWmmaWA72sXLQXscueiruhrHHsabC6yJ0HxHrr2bboLJ7JUx2KTh5CGM30XgaQInjwMqB
CTHoqPpqSOtluph+v2hiOJaYhfyh9KUMbNF3w0gaUapn+Kna7QJVL7dZIJxURVoS0xM4LWxRZNet
gYY8f7rkftizVqcqHfRDXglKtOU/snt/o+nY7eC5qTMXEg524dTrYW+xoM8XYEfqneLvpMZZ7hie
Fuu4S3gomhX6FQLy1PJGCj3PnvyLExO7rIbNoXcu6np6u949VrdtkBtks5UzE4DBzQNaC+xmOQ7p
+MPacHdsTrJ/iPpACGQZxqTm8RuqQVBu7iltJQRDheqtX888BIbwVkribySmYOw4OCXQIyaVKqvN
f8zQ1X0czUkOI+0V5ahDDveVyq+xlHxACq/1U4WbPFHmdcmttVO9UIJCV3sd4KYZUXoDAB6+Qubb
jxkFpoAatJgF9IHgYqCq1PI4YSFrjb5UFwwSJyn0Q62ebEuz5yWRlJ2XscXno3i+Lh2681ctsv6k
C+fbgUzvufqo7Xea1FygyJJXkK5oMoYWP3Ho0wRTbogh4b4gwea861THapccFOT3wJuoTJeCgxiU
O83lktxAH5alkxImoBQl8kxO0h2RuU6UQQPfCgRDSVdSlO3ow3QymvUv7lwB5tu5HKluEACEH8r0
LYEyytqb+qecto7PaH/MU+mTe6mfKebOThJ1YEtRmycR7v/3Su+eqNYy84NnvjbFOz5zsJ4VLVXz
XzaC4JMa6pvd+7zo9ChKDZc2k3Fpk/pZCFA3smHdVCs09U3b8jRWs6pTh6svE9tdRUD1BZKRHQ/z
fCzc7sZInyg+KIQKGn1UbFDpqerFG3YRFQSxjh9Q8r/RwNMGw/0p09St/yudefOPXPu7DqyG3tp5
pI0Nc/yZADzRgdjEXjSYZ9K/Y22TmGmGZvwjZqZzKwgtUbsjvEuRLY8PxT9sZ+ldQ6Qe2PHfJHEO
xmHGuR9KVHRP+z2l0Z6b5b2pS4ii4UxD6Tbf8znzhScwXTvebYmoz/7FleLqCsE+5AjWClBo0PKH
2KjRsMZKs+rmX8RisjWz9mGJLRqXSPpBMwL7hejzSgq7SBiJJ6Q7hc5xZr5Bt/bfftvnsbA4u+38
WbdvYqwe7FG1c47hEklXIPxlqJLupcfeARaBiQ2aMKGf3Otwc0YHbeol7yXbORKdpNkxmigGikDL
Il5pN+lFgzs9FyRGmYqXAY8Wlzn+veVrAQo9yqKBj5h7EciBchJYR9/aC2gjrlhaZV0AtNbxm5F4
PgouXQ7oZpgg1rJkwID+wfUKJokSOHkmr9jMJva7kSFumWB2jGDbVlnVJcpWCXqWk8f31OnamANU
E9b0ha964mXL/IPMv+XLBXBH2LU4QJTwW1UdJWFYSJW0UDyrH9WUR76xArneSUCaZpwI4i7GEXS1
GpLVYijjt890y8xww0nmwi0gJ8EMtGTZiJEOylQh/qN6HGks+lxnK861Ba9hgerSqY7fFKie+PxH
RqQ3EK9Q7OTOre6/ySBIm8zoBi1DBbveLouTyi2yjVZhWN2dsW8NpIEPDEqGVfbYE9B72tLPyqnT
DJ1CjzVPqlm1LELLmi/RGxUqnoCn/KevPthVsc6+1tgaqzmO487C1JaUct/2RLasCJT8PTv24Nx0
bI7SaAL2QGWFvtGrEvbizG6tbotEumYhDIvFDSWPkrciup5DX2htN0BPVIOWzOuCIZdwsbxScDhq
xFN6/fdtJOZlVtHFixqRWnEPBbWqfLksFJkmU2IzmDURL0==