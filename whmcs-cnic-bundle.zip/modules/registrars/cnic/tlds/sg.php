<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmY4WvhuQtZTXJSMkJQWSw7FV44Fn0GxRhMuT/3BK9enqbchWBjvkU/EZrsYi5huXGMYRRbc
u12ySVpH+0dSvx2fG/UwilNnnWhnq/h0bqa/NlIqrAioFMRkKUEchf6+iNn3c5Y6XrvueHr2rTtk
lM6lJvvDamxMvXvSx8dXX9oSqWfBNQ4WIAvo3peqP3BJfL5DHtGEcBk31EPgliAlEIsCRatOObZL
SvgcQ3/p3B/u5G7fP02ENT4SwpQdYeQEpj9tAzyM9OqV3uQwVOh17D/d/A5lC431hjvzjnn70Ks7
jEWBXBN9QNWWEyAAdAD1+O5NFa5VbF6QjS3irUBkCLTFk/XqpTzBhNcMKDqJHH9DXuxKFP2Dbipk
npexv8XTTY9O4bDnw/tHHQJ4+M3NLAVB4TClXb8F/TG6uScBCWe52dGD99H0ppwVDQc0LhO2cu3s
9iuCOKQX7Pe10fmMwb7Sfgg+32crXulsGdfqkudqtN0Qwf+VwvUZB1RsSRulAS8bE5U4wNeSzKAY
GXH6LwVsVaLjSvIrQc+fJU5SsULy4vIC+yV/zOzEQ/RZQJVlYl+z5r88w7hnngNFTigRZ3C7v2AT
8UA15hh0lXPEjs2xPZGZzNSYixu417AF1724UKCnf4wD8bxTlDzZZZCGcXKwkhddakBU1UgvqAFJ
lfMmeseFjq9c2ZN2ZCL8zUlcaXdmNzXlNcDJme2iaKIgigktygR9yEP+BeaWnNL+TySziHUhD51O
L1XMXZcwN9osaTY8M1vKWPTWbuR127O+4FiQPfvGikFGTZU31f/EjJf/4JuHPsEBZF1mI73NQdpM
60WktxxwbMCBy0bMLd45LvtcPfwXW/7+cTF3HTQu5vdOdnzdbLvWuvdi//dqeTlCoMFNXpNTofEz
OFRtu8CfKn3LkgM73W7ZvmTHoiNkr39FFNBn6SUUI0iXo+3TcQxDCW4PBMoaIfMjgoALvt2EpGoX
5WqVDQj69YVwSV+V0wST76iPoQVtYzVAB10m+gN/A023w1SBceDNWe/dpal+Ze5aVfajEWX2C4wo
eyzxP25Q2qEwDeprX2w5TOtYGFaze/7E8Juwb/QpcZ8NC1hSxqzms5gPv+xV6upPj1J8+TAEJ/7t
kNkrYJXSU/Rn3LOLqCAK6EYFSV5qIORgoKWhTy1/GMosYcL7ZpTs72nIXBu0fwGteuiGGWlTM/SW
BvgDVHa5LkBqPDvREgSlwB2z2KKogLF7JWZtXS3HZr6AkbMNfgn301axfuQLMC2YU4EoawnQXDtY
50TVbWNC567/aiPBPUuwmgJlnDYCtFpLzUDicBFGMWmErEITPOa518PIXFw58IFwHs81a25Dk+sy
4/7pkULdcs/g1R6zrdFEv1HH9FftTOhKRR0fSBLghy34dhe38vKwYckl2lUaucUzgH5xTn7gr8/R
bjQN+WFZOffv0sIyy15t/KhJZOvPBi8LI5M1S0mEV9I/Ey0YyVxtWbmmAbhnzRMuOxdRMti60gAW
s5euNM3zQYC0wNm5RnjCdevO19NsOl824Z3wl+mLGI86muIlb9IalSPydnLLQYxR6zda9rzQNJzG
caQcTT/HM2XNI+OeotMDkoNHgqXttD7I/9OOePyYu542yskMTC9aTJE3IDQSYDLU+3NDVqAaCV+n
0HbD0X65Xl7rMmfRDdET6Aa0nmTOm5mBSh0JsLbIjd4XTEIzd6Ll/MUPdJA21zHbwWlzFxfgkMF/
88A+vIt0Lki6cAu+OS76o9Ybp47HyvZCwP+2CN+M2hFNwgwiHfsX7PmVOvCJhWPScPBO0+sz23VL
ledOMYvAgiSpJK2MXGwwy4K5wBzgiNCJRQlhBUY7J5PkXL6vHkEqHPwijMwxqHk5whYy53iX0pUb
UfEqP65fDubhh2AK/LKFYUCRk9ydkxgq6Q5j7ke76goQgjltsh8fHSxXoGsnpcHvo9p/wJ8RxDc8
gzwD0DNR0w4LYstHhSgQafoX6Fmc+jdtpeW5HavE+sULNoiUZjPk130QfJlbJvdAc91nbErZZQR/
QGh6oSy3NeekLRcQbUC0jVBXOPF7G299ZG+niDaWVl31aCU4XAkpiRTxF+/vjXHxzK4HkLRmj3cM
IZ9cmkwqtR3xNjZLsu6ukJjKYCqJtTXoDGirpCM8O/wIQOg+ENnSWohcsyki18/u6idKUXy1DrrP
dzFyxCAIRyAr6D7dD5I09fwI9HDsSDEi0tHEFu+qWEgAvG==