<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvpHxt9E/udKHHTYUb6H9HXjm+hoOlIl2CslqAdOgRW8brnI9e0o7b8VzomEyfGT8WAxUk1Z
K9jugPEZ2ju5/FHSWmD9rrVEEJ6aj+vUgCa637IgCJJrG4wXD9MMQZgewrvsSR3atH0KVq0UuqlP
C9mVNGz3Lzf1DypV2fX4wb0YAWCXYm92pmAda3X6uQBSElT4bfU600HKkn7LLrUrzbI1cTeFyuBs
D3OMXEuUqWPjfpAq3wVUCUrShstxYct8vTwNl8ucrFo549S8Sa3fqXm74PjUPTGxBACDzyPR0mL9
qRY82k8cSECanDkVLNdGeRAhPs1pY2rg6cgyBTfHDEZXjwhAU020NWeY8EblJKsSus5pSbGRM7JV
gU7HbmG+4QW+OewRMscqxhzlzlpAN6dJAjriD2F0ipBAL+NmgkbbU2SOV9U6buptbiw63+h8lObu
PA5pYIY2o8Msx6ubMTUchLqSO0HeU/L62PLo5PppN2Ljvu+JWszk8k7BttTpmrynMVgcgMe2vaJR
5kRiAyTBS6nBB7qOfksE7DrL5N/jOgT2lgU3FzjbGM4HKNcHIt7fIYLb2tbJ7VqumDvAHBeaWVF9
DjCuYY9q7799pHQLb0AKXYM+6aPTtb6k8JQt1uJSFMOjjeGZ/xwuJSxUcMfClUPu1Xj8ATYnJqyD
ei1Lcb79GsSGQRsru+x95lbtJ+ZxPSdDHi5XJIJjg+NFbU3YjOaD/UzaJjGmlvyjSwF96o2oYuwa
CoIdI+kfrZX1gZxUvowTyU0ZNfartLF0kT8KmPDVJ4K8cIuKcsLCIqMbOZSL+eahhQc5elZDxjA3
2WmurgWfgSDy8SjYCgykr7tEqSLY1ZTM9OpmsFcII8JfQcWEX+tpEFHtvFqChVIp1odmWuCLFiUp
g5K6Mjdm6S4hcIMADjmZBqduO4xYsIXsQ+fseQTDfodauSHTJ47XbBZb+2YCkDmUOV5ouv09IPb3
1gVVVyGXnZS2YEgNsNhyUEL/ild73mLmBrFk9iCNZzDMh/3cng1PCuEksT1olsB3UjFB04axrmcf
eOZG5ThAiUmrh4QPakHNQ2fv05yqwkAQjF4atSzOxJEp5mmG9jm7VH4C+TDxQ7mipjVA7/vEWzY4
ZPsBjRvgrVriVGUnPiaWY3jK2kdKITqxoo3ewqQXTPfLGJ4vmIEw3ds1hN7wHBNxHMP1HWrzNpJA
xfczWecU485jYmhCVx75x3lndTnSodSoYUZQdRtGRZZQmzcShdw2JPNZGRkGEAii2ad584cIk8ET
89KAXDr+UXzQHMK+ibjOxA9vtufKJN3pg3FP5daIn3892hcJTH4KG4SSkZNz+pwlcnowxKmOjnW0
cYK3HGYuvGdjhwYd3ockGgOUzqcMoJ6KTCmFsfC8LQIPAjh0233VAAq5k0pnyDaJHkl4SKjGWu1d
GRTxEEyDRAsC+xuLU3fwAiiOLtvRhGvoSVKaNbQnaBnZIVevDgTs355ngiJuaVI5Xw2AOK1i/JyQ
0YqQu8dEaQlmenqAvYerz3dlTHKgBlMQ++BAXWaYNQU5+UbYdFn1k9iPIRlg5rjjHiBKMk27QJPN
pL+T5Kyv/j4WPFzQDLl+njGF9RAOZR/1oqICbr2ZZkkO88PlA8qpzeF4oE+SP3YDZB7MYAf7H5DH
tMsGlF5rCdXQn2N+C4aecOACcf6x9/PQZjCeTE44zYp5m/QDK/m+lGncj/3+RbpJsFT7AY6WN+kd
HiDduRrpZSPvD6ziEEc80pYsniur72jU9/nbqkspvl4a5RinzE+dZXnlukFSxc40/5j7wrF7HJvC
G7C1aVegxETKzDnoDcaFSlmTvxr7x1gls2bEaHIVoic8QgXG6Fy6Vj3UQon0mNdcJ0sQb06ueeXu
O6MyqHlib1LuKLUjfmjyto32D1MPp6si4Wpa+iB9GxLu/dj6yah5nqgqMkMWgZ9Hjd4qK7kUHoQD
S1KUIv9TLvdIlBz240ne4k8RWJBrDPyHmvGrSDbrwH1nG36YNvAcIpiuHlLPR4UQKV9V+57W1sZa
I/h6HudzsqyVTaNPUDTuAtJ2U/09apiC3DFmmy7UnTA5+mQ9G6cYawdyeF13nIYbrv1A17lPIAvb
IGB1VbiYuJLLwuLwvQ0bcbi3+VT+YsudLs7Le1R8RHmr31/SOjjwqfhI3e1QRuXJ3B5NE0okiJsM
20Q0tOHa4Pg4abpoaiwLYbEPAaVeuAbHcQByfEka2A3AuBnK