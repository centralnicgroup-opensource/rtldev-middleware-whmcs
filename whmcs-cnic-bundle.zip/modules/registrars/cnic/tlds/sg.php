<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpv0ShIkhqQyj/Fdb/8r8x3C+miX8ndYHgUuluZsRmTdXyfOpLfXt7iA5HpHTbceGdE2whSd
jLeuSc20vbR3wMFaQsZ9H0UNcQV9BPM1uzbtvnv5dO+6ohFTO8fY2ECegdHoLVvmBrHLbPrqZDPk
Di607R2hNB+uzgsQm3989h20QWZYPJBaeZrD0/1l0zQj8gzQIx+18KrhBSuDwIrGzNw9uWX6T/Q6
b0VRTOB5IdZiJLkchcJ1w/xyFUf8XkuN4Q/FIdtbqdmqCchhCinmfHNvkhXifwDeHsRWNVn/d0VH
rKPiaho3ps0kVPAsXEaIuES+RaPmvtmmkWUlktAFQZ19Tm6Bj5yS8MfKARXxciudRnSxIrbwcPV1
/271ACc2EgjF/TsN19rFPT8/zQV8l4ehXHJZFXmORGJAHJC5fbIy1PjrR9Bg4/TlAfHCw9KcFerg
1FGdHdNy0TxxbT3gswLbWcksjQihTjdUap6FoLaavZl7smOtZ01GR8OKbEXo4NEskKvVJLOVt2iN
PRGxjmzlpQ0J/EBOr34nZgwzEbLSTXCAuEMgmA4eECYv3WU9zDB69V9asCFHAW+E3M0nawOMEQXg
KaVEZY4mDECfH5lzzQ67xH7W+Guog+rcz/gGtqq7BUgR1d9uCsrDHi7eO6rd8K5p7iYwI3wVFLHU
uzT9hz2tPZ529n1RE+2poi9ewRxl4ssXJ0GYsXpy2wpczMc74TYa2DaupoN70uA/qa82eKdLio6t
w1gnOx6DbuQfsWUtRnoHYYedXA0SJhKjoHhDBlT22aXC3Xt2wWUV3QjdaY9D9rqmlgtK8YI3Ch4e
TN7mHnCAS2PTVHPVnk+HSizLjGE0T21djRVEQOqBHruqIUvaegENPy2mzYQAXjifB2g2VE3ijjQi
aDibmOWze+GE+S+SQF+K3bdSvhHtg5mjITPIPBpcmaX4krj3xrgLCfA90h8vO/olpWOKTP54EOQH
R90kYW/Hp2exUq8v0//qoglPms4TSpIjejGTWavjqXCfyS4L6vBN30CQou1Ul/r+heeqTWPWCIb9
df7CjBdTWgoNiyLaoUihzeVk72M53BBgjQskSLSZwbQhOHMx/H5rl/RuE3YwY28752btytaCji47
CqzlDTtwPekx0NIAQKdXxRUn97sxhTHiyvh/lq6+PjNDGOrBfqDE0VK1LZlUqr9MGrBuwgYGDz1j
JQhLyADJ9qZs9Ohymmi+0pyTsSXO45BW9EyWnhymPW+KPebRI/Ypu6HmrR/nt8SZ7yicLBNtH3P2
D4vDXx1R4gULN7UHI35iaBcKpwZRknfhNrdGGaVCP4hobQT1j0lY60qeL1bR/Huqv8JBQZs3WoD4
vXvuotMVG9J9BTnjIgdm6XvPj9VA78lZ6OQS+KZ22eYHklUxmQ5wuPk22kZ6HmTFFT6voZ8tEQL0
oS5sejAvuDCvxdzdPOYKHAfAqxWvn1VuZQVUaUmPz4a+DV8IMQur2FMfod6BAkQcRN+x+4pRx2co
KrTtl9j5wZ87r+qdDVbcyV8MHLq1krD02oNmGXm/SPYtsKP/sf5TyV2COg4Nb3ybhc2qTQ83pCWi
l/8euwizYPOqeiCNQHlRAvQ8Npxk0eYpQ94AofPlo9kzMWKiQeXDUjlzLHxtkYd3Y4GCf7YvPoWG
sEqZPZ6IENIPJKKMdmUpDWiLV3OEqjhn1URFusaI8hdpfiU7QBzCYyHEwHyxA0pYjjnMBxX1Y+5L
X2Adov7D6CDPaA9Fu/jrj5OaweRqTCeo/faMlmpftsmrb7om8NwPSjAJGeqMzZrSOmdcbOiog+AP
32j8QlsSTRD4gV/Phh5aiv7FK9yeujyi5oO3LCrnPDuILI5FlqrrsIwPW/W6D1FnWuN6DdqcDxJw
TcOvYMydqGoB9RJOQmhW3wamU9w+Jfc3Z4ueguiLI1Zwn+LZs16bmDKkXbQL853yj7EsPrT6IbCR
T0B1s4DzcuF23wgaAUSKC/LeNRbeM3cxGRfup0lamcaA63Z3vWi44OBIteQpLNZk2ZJ7peul7Qqn
Us8W2EgjIf9i9QyMMGdVBedKgMsR5Aq2V3bFzF2lRsSsuhzZnMPNc5Iu56k7YkkRwsvWjQezE539
lyKlTCdxLxTzUh8iRyctlWW9faP/wVEGETUOwP/CYFN6BumPlYmbw7zywS2+zi9YZtvHA+klDLrD
hLdA6aSpPUPXcoVsM0fr9kggcYrde5hc/YHImqFE2dusigNCHdG=