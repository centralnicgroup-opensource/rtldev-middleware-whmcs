<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoE4tklbQ2FCy3PBoFtatxOpusZHg7xLWzaHnLbSA+WZ93VZ+ZbOPeR/LpwmfcTYmNYlDlZj
3AqPmHB55+lnMGdIKE8GFXYEpU8jezRAAyCRJD8Dj3Dprl0O2xrL0HXDbGXYYbQHzuOnXCVhBvE6
w4wxCNheNk55lVNLZfSR7xfo9Uc0uKtGl7SN/JcjoU4XkNy7AcYcYlTMAbTnu6xUvNiLsloGApUT
H+ubY+URTDQ8euGbYfKnwdadEBBcPXzRqDHoqC0ecS5h5/SQ9v2j2HIeQ9btRV0rcZWG6Q9FVvpN
jh9cRVzQUnj4YxctmOMVr0yHQmZaCosTHm2htQwqMMnv+dMMFWar79GBlF3Zq7QnwKj2DpLIa+ci
B3NoFPTWyrBW9pHSm0VnHuJYzbrs+XyM75SMxdaBIn5BRMWLpPlsHjJXiaGHZjZkppuvQFLFKf/q
k3ag8vGxAIp89rmGYKNKhmqpiFu6IcTdRzgWVg7JziQWL5DtaYcc3B6VSC2OpikBRPVhDQe53L+H
Xr3LehXdYVEVk1YIWn0oJSOkJL09Qxb9wNVnpKJ0dxvJ2BrHT1fRy2Yx7rE4Hbf862lzXozomKqh
ntMrItt/pivQ0WzfmqErauJLCoreUttMgCbHvEiCrCzi/qrjrSWgeasPtu6+Wk3c7He7saEn/M4k
AqJj0eGoWswjMjEG3cAmBHnp5dR5xDtQRnAFtmT+NiRdu52O5vahQgOwZfbgjMNx60VvCPzatFIS
ynMuy2hPDfQfAggkAs9mZ1eVzeBMjUs3SLvzfGPe+wcje+ftFbMDU26gNw+f/3yIuZ3rf8dy3yEF
2bRoTT4VBo36pQ1q5Y9eROszW092Hf5IVBYdEIkfnO8lgF76U4WoK4VixIQ5kMLXA7r0AycpU9Tr
751KQCwkGlhlu9i/qpipBe8zbE5Oby22JHawVjJdQXmFHnNKLdRvIhthODj9wjsmityXlw5B7ZYY
EXzLf2al3g1NXekTRMffTuYtLX7wv6nZp0QgMuG25+FmAzD9A8E+fj3cC4pP2r3FScUrBuE9gpy4
W9W94P+oJfvQxEXxDDBbSQ45gMzhizWLLd1BSiNu+oKh093VFS3CB6GSWqddLN/u44BjXMQVGf2u
kS7pGf9SRa1Wk+J+zQOiaRLsT4FQolemYhAyH99lNBJM6WIBWwaZY2qq14lo8LeQwMtskYitwx6w
ojokeZKYNKOJ2i7rtJw35clt/Xu/kZlnjYvfPy5D8hizOWutBA41CjJKfGkTUil+V4+/Vux/O2jL
t4AP34AH8WCputdF/0N+6WQOgS32AdBKxJ4BYN8jIKq7fCNUYxWnkPmEGFya3WruSAF7fa2tywZj
0ctgIkzzelM0llvrv9jq1Spr1g0jbZtonYm7T/H9TPeXCBg+5xBCkC0pd64//3jU9jwkGxdggtSR
c49HdJsxefXkWgSIk26vLGfi8dboms1+XoT7G6uh5g3Nb86ksqkk/JxFGLXmYIyD0/ra02vgXRYM
psvOZvJIUm0Xb1eKgjuxltRS390jxxNVXCZ6UNrlveLa63lloUxf4gngWlHyYVGsfKHSh+lNwiAP
1Lldm4do4RmjkY5KQBCHzogC22+c1Uj6TXab6aEWQdS8TW8+WCEMsu8QEYfydgE1ZmrY7aJEEmhe
dPHHJwt7n4Lq3UVN1M4CLTiWHXzQN1UfbiUcChsDiW5w2lYI/vCUUs2Vu2f0CDoMZrXIQj4D8HQv
gARueUzaB6V7IatMXc3Ol48otR3c4wdbQyLiG+a7N/AqOMSYiBNkOjA3n9QqMIZG//a=