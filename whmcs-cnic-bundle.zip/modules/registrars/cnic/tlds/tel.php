<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr/3UTx3BK8Icd7i/GWOtGb/LjA++12CAiDYdVI3rZK8EW4AVeZOzJfcifnWfrHuI6Vl6Ubt
wlk5grRomE/xASRMiFqE7pfR8b0u4Ypn+1PPeHlXbw62v0dLGmZ+SB48vWUOk82t/N9YcI9nTysx
O0bPT1/weud/WZtxIJk4LSEeOhcBgensGCySBnYFG2ftdG/IQyfRKIS5EH8vCjq4o4Ii2jrf20sC
WtyaYuAi+uFSbwtIDkCAblV7XrAjJVUZtoYqzfYxr2XaI9Aw0nHvreN5YHCFQL7FFlnF0p1UTrLE
mbd6HMWqo09RjV3OGZtX7ea6TZk755lgnca7D9ivaV92ItC5zPj4Yp5tXgm0QbFVlHN/hGVgYCo6
0WGV5j925hNFBQIdHwxH1IuNK/xjotyqVQ2yYoWsbKIvmJ/hRBb6qwPdGwGkDd3jJrbbIeL5IPQZ
BpQuHUqpKU49tbbu80QTeKjb4vhR/jR3mQFSv3vnoEq8PzcctayOz17/EobD5Y3zGkAKq3YCswFe
RMLlSZiRUcupvY2pLRi2HEgz9aC/kx9u7FWkVcJEgL+wTdJ9zxYZTrXvDJTjA2iJZdXJlZR/tqv8
Q5lFWKXY8H7ZlVxSfrSeVYN19cSD5KZkkzWr32IAyqlBu4OlFL5/VfAkdNo4D87MLF/h7mvHR7Oo
fj/Yw1P86EcDkiIhphZOag5QzrsdAEIauKUSffHe5Kdo/bBoqUhNS8IF2nfZoyN8Ksl6aQda05cP
+sCpwZyw2E0d1piMPGcPUoYiWkIj+0wXsy1irc25LSV5BzXCP/CZyTRGO8YIDKfiiGqvm+AQlaAz
WDVM4gIR8pyijIhSZZ5l7k2LconG7qGOT30dOsLccdz0NObOjDu0Bx9lEapivJJ1N3rZ1CFype4q
tnyWNQUzmjZ2OR4wrMRH4dWxcvzCcjhzwVX0QkJS1tXORd8z+eRKO251u8OTc1R668B5JEKJmv1v
6KEvauB4RgTB/14df5uliH4/a1dx0MGTvh221ZisStNbabxFY7V1J/StdCk+Nc9vZkyx8m0h7A3q
UNVYZtQUr2zPs1brdYPi3pPDzY1fRJt8I++u/GTYe7iaHSUtMc5PGmdi9dHo91/zeIU1VtDGr4r7
kDZ3tlgravPQnqdDnZAB1csagj8qVKk3XEXxLvKELAKH1DS9UpzRvDsFgtKKv7bESVhC9Z6cGty4
3PL7LKtZtkYLV5XWLjHsytqeTbryBUl4dCA4Gfi97QQubpSSPKJphEBFfsVY7tPFi/2zm3so4YFr
rsn24ysEpPbP4z3tpqRHu/kdozKoPKMr8qW6cklbuG2H/1bLGcdWgw8QAydzosaB+758IEMnwbya
VcTqoYsOdeO5zNjWNkp3GQD/8La2UMaHXtYLdrdmKx0G/F5Wye9kIRFFNdSjydbmYz7elGbCsvCJ
o9pjjwGk1FE1kUHpFQfR00OextQpcN0rD/PHD5j0LITXnDtkuRQp8vMjHF9X6mLUdI840kmzyYQQ
XWQtH1lxwra/2t2NcLtszO1ny5gYFoxXcRMAPE3ObO+glJRJCLO9PfPnQ6rQecZsQ0gXsq6pJTiv
7D/esuB5vHcZjyoHiII5A56NPEidwAV1LBClnyXBjOXfQYlVdSyIJEBYJSutlGyxE+kZC47FY1Ks
6RZ5cY2QVtsrNW5Rt3XSbuKFtXJ84AYx8dPt7EpowXBJz3uD5MBpKkRkegvruHIGheNG2S1QJ2sN
vqKuE+uB4Y/uIj/bfaRkok+Kg89/xgehKe6JgvuEzyjn/GIwK3tvTyU324FoSejVqRHbNMWx+56V
Nd6p7pZp3m==