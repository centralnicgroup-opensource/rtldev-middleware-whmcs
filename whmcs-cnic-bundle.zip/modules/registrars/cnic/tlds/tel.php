<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtIdJYlVYRCCfXNR21k8KqewVF2RzR6Q3CmKQHZts3WizEY3oResxF8Rh01/E9cVeqUgLsyG
w6DSyyUEEaf56CNDHRwaJdMwil0r2wQMHIadX69nt/qVXWFKSUZspeqdUihXbRLXxWScStrTNhBX
Aj086XHzbsgnbxeqowe6h4vtvo6QA7xo4VTTJkodT0Msv2SJTExCXXXOYltWsRYqC7sBgIOTx42y
LfeFa8DW57E2xAYIimQe67mrbWdYk4emAmFAAHwiyuZgqoK2UuO7P9oSIrfDPxfuc+oCwWM0mc/O
fsvc46Wmcd9HrnHz9NBH/YGbN0T3b7rKcQIZECt52l7QRmdP5VQc1WRnwh56/0iS+gFHvVxw2KxH
WpRzepbvQPY/i5tczlDvx2VakdcznY3nHWDzoyKjk9V+oeVXRfBzyCMZbk7ZSky47qW0a91t5fO4
seSx7OIB0+NNUULMaqWm5BqpG7iA0wXMq4GUMgiWmb8SpHv8oPevke5h75YX1phWkoYf79T00YyO
PcoZRUpZQFcCyrE7kpLKDUjQ5WfCmgnXOOLhDm7zqU3NxYE4Zj4+GyiWatMXTeNAYHKSZmYW4qFt
6Jvgt1ZRb9FN4ANKOrlUN1SDfORFALTo/HmSRn0qf+BOPFqS//iXT9d4elkHu8OP2qtfGE6gpQbG
tJ1PeHJP/5JWshSveYA+sVlqQyDx1x0DmMz8XKwmI5ZT1mhT88X10yeVO8mX27sNLR5XfwhDf8Xs
gaxI06sqo5/H52EJQ8o/7ZHjxuB8lhondFGdbeBuaSl98s1fWmyGm2ygjGDAc2/ykfQcE/1v8f/8
DV1hcW4U3OKw1vb5Tx0gl6UTBV4M13ZBaYqeeoFxCpCcy8e/uB5rVQQE/IpZv0BM/lOBTN//RD+0
eWiVQsvBya92dxrNMVDJzAzphsx1rxpW3OchDqqaa2OS+tXyFbxBQ4KNFVKKEv/Ij6eZeEmmmSkt
J0eGhMDTRGt/JhefRs4idrHfmUguV63nhYoxwRozrbrtbSf82lb93+vBEby3ROiTIMvfZvJ8AN5q
kqNkS9lNpZRW6dAsVUTJ/Uef/DK7BBTCM7Tv+qA8e2H8NuOR0FHBNBUcFvxceKWvODDOELV8edMW
BzkBGpf9NI4SvsMBInZHnd0NNyqkCZ8dMTQNVfyOEa8ZERteKt92j7H9KeempzDZJSOCHB1O+eiZ
reMaLnl8tBFzk7rMDcTbQZYqqp+NmKo4EtYqRv7BX2praP3ZPeGpOoK2aVmtuSYp5xwyV7NYiSpo
9s+OKiz0TJXpk0PiHWMEfj+Uarf0OT2D9z5F2MZv8kXhHCvP6wX7LOLwkPbiG6ETgTFNeao6skjJ
x/j9KeiggD2BiL9TaT9l5mZVzCCngCZBLkrxM7v/vzOgTTiRRlRH4mUapQM555LEyhKTucSABNfQ
ShvAYCZZmcwYGnp5Jt0PWCTXNDK9LK9X3PIuHGsPUylIiVY0yBvbOwnjpBny2oDxZdEEaQTwaWMm
thcepHc/lWShUMtnzKTj9C1LvXQgME58xzoCZhWbjVlsqS+R+dvMEF5zWTvtaSfiDfcOv8CCAjSZ
Vsrl6Ggh9z29VxK6Es3WM4FwSYQ9aaSqqb3e4qZzpxkXRPvhJ50pfKnobJwpTm4uQqOLq1mezicc
7pAHP9Vf0MhCoSu3M6PZZq8KGvBF6570ldJAuW+I2o7833vSc7QdOqw0P+6HdFjZlB9M217LAxlV
aI/l2FE8eTC29ftFEkvdyTThMs2p82xPfdjGoQTyvgjANfoW70/JaoAzyn6WfYuezG==