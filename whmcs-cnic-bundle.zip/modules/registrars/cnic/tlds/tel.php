<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq7mTyJDN4piY4BYvt+T/k+MwlseEJ4GfusuPPMuO36K/rDzrUwO1RQfXSDVhGan4oNURRNQ
nW0MZN2Jfx+KFvixPbWVry2y31HouFY6fDZ6a+OAdHIVtFCf4clC0AIX7VH2evZD4j9h7YONJTvg
aCa0HlprauERAELF5hQh4I/MSJeosN32lJWEaHhTipv9kMqGNsvh26D3qD6o1EUZeafTCNie4e7E
Cse5/1bYtakJTIdqBwk7NIA5P8JObDRlpRp/zJ+PedukJPKmH71Gvf9HSmPghokZPUhkGzlZlpfD
KmO+HiHTdF7yVArQWpcUPPOzdrQm/e1I8zMOlrDbSWpGXUK2+/p9irjjusTCQPsy9kN5rCSH3NzF
R0jDpblu92G6GBY18cu9ZpQUtKsuAH6Bjv5id6J/kXQUgKu1yyhEKgNEMk05qtlGa+VMScpuHG/H
pkw7NOWEskAtkIDZNepM+p49bic5qUcMEj10Jcoig/H9flfkcDy7JuhVSyixmS+JMQts5g3vJb0U
XLA44jQi9yB9Fxye4ipHPNGsImviGk4WjpzRwNz19r4iBChiyfDoDM64pILSkXOGt9adW4egmPtV
1FeYFvwhUlENPBDCxf03XY1XXRNmR3iz6S+NSXSP++FudoV/xwZk6O9OJBS9ofCzJx/hcOknFwCs
ErokMXXR6AaVQRTiLknXtTFCXY5DBlJwHIEwyTwsbdxSqEmL3lNbOJBvkH0e48urqxPwCdcTzBxz
hWUM684mqfTbyOX4eTR3PBplAqyANBduTLWwxIZnUHU6ig+lL6C7tbu9XgKJJ/xx5i+4RFrkaJjA
Z74MmHa1ufwK1h15PB+tp5rJm4reZDd1ivgylEkKCxXvdHZMkvG5E6CtmrrtWe4dplkM4I1WSDy1
LyAYnbEDeNQWIIQs239+NXNR3jv73y6fEkK6XXIUaPQgD+1RzhrJPNoLC3AKNmRTPTpdM1ep973J
i71Y56iZIns6HoEOsyjV5FRKgessfF5mnp6Jq1PHIfVfdG0ef8iBNYni8Rcy+5181RL9NcLFj6mD
OKz+XAyl/sknMsvepHp8r9AhdQ6QIlLvM7RJODvxQRGNPQO9FT40Xmp2ttmRvYIxW/uasIgNHaXV
mAm176Y3aUpLOeRZfvLDEQZZFjKsCyI1Z6jhkoz4B+IdGSvAZL9xcXHqLS8TaOG2mgmS6wrnsYfP
ppIQe0mcgmc8SHVUJVXR85Hs7obgpIA2BZfb426ydN2h6qPi4ku+a7PkpijZM2xSY2p5RYF9SQle
bMqDi6Wx7yG5aPKnw64ELgy2+Sv8pAAxZ5WRQEeiU8KfIvCU1HAtPyS/cHhqOE6LCugtPk9vrOIZ
UK67a7pXpx4Re0j6JrT+Syo7Tm3kyoIPw17oGO5CUOBhrfJmD0zGLJk8OhbvJCoxvSodMMeCTIQA
XkANwGz+KalPi3GCDrvC+xZbqR5nBq9gXtGTruyKN4jN8OwLWcx1DQ54Z7ScXnL7HbWcuaNx4tbc
tlQ/UdAWi3Wdp+epP8Rpa23Pur1h8itDIv+gJXxpvPItpOMTkM4gEx7GYRJLQi3LprM6QoUdeuNm
u/gEQ6j63Rhz5OHiW5BMVcKZwIRYA7Nm/Fkwx0LpX43LtmSpzX0Qgb/xPlSaHS9bBvnsE87lPFML
CqPEprmnXYc6VaY9Aw5UR+bCZq1R4YT5l7fWOjZPf1MSxenrGkqb9lyzgUNyLU0mbLbZdNqpnGPS
4kbgPySKpcYjziXjsXBit/cvNPD84L3ibUuI2Y29fzHYAcDXmtKKzG8GGhJGtkUlK1TLGAdLRhZC
Cv1D