<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPswA4F/ArMhfCw0uXHywKboEXFaNaOH+HjW8zDPImWcz1ggwhwist311Uvks4TL72k3cMebd
Lar4CX6DNihmk+u4wulaQhPuRNxp1+zwCeheUoXzdvY14v3PNWzTIqFPztg9Yn2QFqnL6nsYb9MO
KhuedijgZv4CsgS1R1mYi6bBORnggPYlAIIYF+tUNgI44+sdPcX9xq5SuZc7rSnOgVeBHD2LmT/d
2QV2aUgU6QAA5G33EOzNykJ8H9D715c1xystrafzvT9yD39gwpBCSAKL+Rh3QcLbEvO9XVsowr07
uIQdEF1DJ1UsCT5PKWG4ggTnaSO2qu/K1RBUDRw+tynWiBJNIqmbiqc1tvUYNekuFLtb8WYav7bn
S/NCGOedjCMkVD1NyW9yvkrHD5flTVCDWjeC9L4NmFx9R0mqaCZ5OvmiV+Z5B9hZhTzwi8Qy00ou
YZbYsBPU01AeJVkZ9cNHpA2XezUDyHbBhU4zTzLwDpZPgtw/HEi4cIFEYPn1iwwYZNCFyo8+Ms6A
JJCngGVmYvVGi2wh8khjJroKmW5eGQlG062gW9r3xsh4jGiG9SMYFjxtTAS3ssz7FzFELw3ueftj
kKQTQ1V/ydWODGXS7zI2BHQOg0qENm8Oq8gsCgogVzD3OkmISWegAmTHEaf0rJxAbzEISDTmiJZl
qv2FJCOCERIjeGbQg+Mag78UpDwzkRnJUgwyJJAIiZzj6pLxbJrJR7WCkGxRkI3SceUhwlI68+B/
sCMG2H93HXpa0DjnIe3A6AtMagjx4qbi92umSZ4uT911nEY/Pf8DJOmwd9kXzshZZ8k5LInuiNDI
CTnpI4gutF4J26dOjzWi4WF+eGxLU4vdlhjBy6Ay84nm6bX3yd22aJADC1nAF/17l5kBB2glIITM
hlF9TRzajE+LJMflovyAsvU6CQydgZB2kIiVoNqIYPz6qkgLG/lClL1afNqozIg4UDB14SfQXE39
dcuZCtPgtD9mBKYdJmaD+EGl2oP2M3vJkx+OHV+KOPCDUdrQwVwueI6KoZjveM7D5+QgPewCueZv
qgyllYxlGEe4tawAiZjhFzMvNNP/JOu/7bGEaayd5uTFrUd16RzOPjai6rcXX8Hs5T2ThLeqSiwK
++rIIpgIQBGiPSKQ/DQJqzC0XDEGRkW9OMb5bs0KK6hIkNu4p1SifNMa2qH4zFedreIA9Brv612w
FXqEHzZCtPg8U1zNhEmAoDXYtjb+tupx00g2jOy4gbh2MGmD/GvD9Jb0IF29ErMgJ/zyrWhpgloI
GylQ2MpP0UhMxeQf6wb7/JPR4XTZtcBo1agRtXugmnxbLZr1m/o3cubCBVymvPTH/MRieMPUSbk4
XjG9a1YPMvhVDiN01f6ejhE3ukljMv+uzHGPoXsC9SCqr9/tupQLMiqal55J9xJmCEk5PAj+iR1N
ekoZAHLE6PwEcqFYCjfW2BddHMaVhTm9o4yAtOtmtrv25/xmBIz3dyvk+J4e8skd3UB04dgtNc9l
Y1Ri29b9143p2/PPwYLvgPDMu/OAroc4wJLZBVLcLuGKxxJICM819iEleNfvXBQd0osqbZe29V6D
jO1PmS99xHRakFqYGQ3hlOfw2v5jsZKr3L+6VSNrShfFOcD1orvTNk0A57qWSo2wE+ce287mvu0u
Wtg9Mf2CREwUkgWFisrILmrapLP/fm6IQf6m3rBwBAw52Cd/MxhjgxRjDVp13hI3cRt7qZFirkNw
mnm92clZzvRU9XKg6B125mnI5nCTg4hrZKXdIe5IH35rJoCVDmvLThNXfFSoLf80fTSiGY0=