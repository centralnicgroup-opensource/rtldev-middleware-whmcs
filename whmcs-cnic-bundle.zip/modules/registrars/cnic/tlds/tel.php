<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/LljbTKiGgO8TqZT3PvbihEZ61qLX9zTRku6GVw5LeJQUSYCxZD1nubcxIFIvRIixI+x5p5
JtGXeO5z87AKhU7X0OSYoPJEIFUKGC3QoqNkUryToXML+yJIK1b5T1GBA4l2oILFG5mg1DU9f6f5
c7FFfrYx50dNJNcNpQGRgfUBl9WcW1MJJDEgCtyF9WEJXflCuSpHxGnNYNgwSSkTXSkRuCU1+YZa
yh2X/Wos3O881IXTbZ7Csw1/NPbPGzyPQp6+EPx11iLtV7WoGwx5smpwtVTdDnyEW4d4ChSGECyt
bMOD/md35qB1ESMo6h9+LyrXBuPa7bJIPCsjAoeDcXcCy37FHX/8AlYx0/vdAaQ3xziH+sFN1XIV
V17KL1tCXWZM+/VMv/RqLpDUbpLd2lHyLE8VERQWbvGXL05cf2fBfdIEJteko8ONR69aCeaZXkKr
z2NsQg5FKnIJEMCpVU5tGaRvSfkNOcwzNhk6ZDp9gm69xpHGdZDv7eUjkuyxU31loLpRoQsOlQ7t
Vh9JCUMeSQXewyN2o8cAWlR1rZl77Sza2KMZ8daDTZu+3cNnPVGb6rUxdssH+F5KvCrxatrjT/1F
7cJLrA4kvfPVuB1r/FsCQbFp+Fz8kvm1txZeadLn+WV/QrqqdTnZ3SeEja06PY/q7XBUTubqgXAm
sqQDf8+0cVF/RtJMCwwfOZZeE4fDz5vZVUFHFeKLcOsJD4256V64WxZXiezX5BJrrwg77TRtR2iY
jCuuzndP/+aHLTkJfhG1e6mvuh3wTNhoMGo8TOKijN8YGpCW6xWg70Xa01x5PI0VZ2wQRF3HWbsb
Rt2tjp96dQgkbvV/G2hoovAJd2cpzU19QJQ/5/1AHcPal2cV0rrlU89y4+0I1Vnc4R1mY8i0Wp7r
phJzH6wAeRly0Z8d62M88aKMve+KThVVr2Z4yHS2T6R8SRQOTtirKjxhOab2MjciotOiGu+TsFsT
qjG7Q1H0j93qDnveAeoY/8TXr5FtiHT0VOZTAQDSCdwmMnl1SVMJWtai1FS4kPmdBfbNYq8dN6Ps
ajgaAm2X7k7pCo3NaTI9xJTiLto1Sfe3ov9p7yb/1OvljqA7i+Hnz+4FCr3a5FY0w2n/S+p4Df3y
l8v5t7829lRjRGtHKm0DrRMizAmj0cpMyF3LmKdPkhBVcV5wWOhXW4I0+z4Mjdd8Nq71McydoIDF
VR3MuypUhALwT0azU1Q+a5JTpX7ZYJb5HZykSkXLzU058wTJbz1kbs1PfmqhnoG4cYh3nLX3N/T1
tyRErCQtVTp+NWpf6UtXkvmRo2NlokpxqTUEyt0YMKC0+kJcVoK9/uJJ8ySTIo0aP9B34LxVtIih
nAhuNPRJVn+2x0SMgAd0u5BG2qDXxB8NmDDMTuwTBu/sZZLVc2l1OWS5OtNPXfwWlKAFnmJrBe6A
Od8HBhwIg1NKj1/5YJZIc+lkM79US9KHPvq0Sy7dJpCHH+9jIAcdzmGGLibrzs1I1ZyAmLNoQW2k
5gwU0Y+1AvD+xBP3xCq0RAQyDPnIjd7kDWOcGtu6gurjeo5hweiRDW6SS7Ca2nGfaATucZkBlrP1
4WX6Nk3oYzoInwvZqXHBTKlgozOKlW4wbL+E8jEdbLFd72bP0bAMHkcNGJB2Oy7Anrr0/hX5vztE
3T5W4vDmYdhmpYHNNmDS7Rn8y9p3kKmD8bFevD1VKniGC3i5hGypXYmCCJcaIeoEM3WEgMB+VsmU
BJOjIyZ7UIyFenDlv5CSozib+U3au5JTSn7Ex9V2PzQqkrliVoneBQ9WivOkpne=