<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpZlK5iICQcSwrt5UEDdlzLxdoSkVQx+uSIlvNokuZHLgtPixGY/ZOuo/glL+a6k0NdZZqgr
rshL42cS6EGSLSynsW8SJQcJZjP2wP86l57y8ZUNuxYfr5nePLWRf4jPxenZhly/yIJNQp7uUrdh
BbqhsKC3LVDh54d2tLkEsKL3rdG5jRb/ltdqpxUAxZqWmpRKebczszb4xCeEqjrPv1TT0f19nNiY
CmTMIeKZbJzEZvNAZxMBpBoR+lIEDFW9SqpEl8ucrFo548O8Sa3fqXm74PlXRJHnTCv7pUe2GSX9
0Vub7NdCvfzli1N3oyDUHRkDD26kN5GY9h8ALArfZ4ZxLLWgRIU+be6Vze/gTedF8/RsEIQMyWPT
ZYA1Vg3HJNuES/NmDm43nSrGN62Zk5ZiwdzNh1lu2TqojXPFZR5FnSM80Uuc9txcRQ/XV6qwILXR
hR82poKFVW6dvA5pdPOzXVBzZNATmzg1dEG4a5J4gy7vPRW9cyGgR2DwhYCU9IwFqq5yKnuKoXdY
+Iqh4uPOJMGajpY/qmX5vos/HVlq6HZVmrwJPzJ4B3j6NpMXRMvtdIkwh5A76+FrjYOegb8B/TQA
a+JoB9o4ReYa6bgJV9Od74rz9Pp6oBiD14lh6UMDzdG/E2br/zJV0DhrTDrhlm59dLaf/oOZNfuY
oA46I/EmpmGiSyvsfQTPDo/btescqnFEAwiKktP70M0YxIa0/IwJ5P9sCF8Z2DZKX+uUHkiP8Q8Z
S91HDp5dqbo/orK03/UGWWFYuvNcujvWOjcXcAejw70V/LG6H5ZsIKy5n6MjHj/qanMEZ6uJn3tC
SzBvW86CTSkcSJwIMhICcFXOWpWuYxdMTEmGgAoSTFwLgDL4rlQDqBw7A2lynYdf7Vg8Umu23/id
iRrIeco6PmNiXvVXQeyvz7XbJUCUh2T90/hNWO/3TOYzA6D9PE3hy5W255z/2W/BL2qeGPeKDsrB
lfcRzr9AUb1epnedJHsIaWzsBVcqpQuzJRFP1V1tnd0feVLQEFI/uolLoP/VkwpwUf2I3q/EkTlH
P09NjsUots0jSFhNGFiR4AoPxn7OdJdl2nssu+eVyUWxrsZdtVGKb+SzYm5u3wFtpcfeqyIz/K6G
mc6MBkS8QJs5QdTW7s7dkPWucBZBBRmSNJhrPz/aTDJ2edeNYM1SO069HZjhAUZwKGRQ9lqhM4kG
o5HXfFoK9cLNeq9f9nY4JQjn1N21JI9M0Lj8mj2pUD7/S/IHabgVWMGKk3CAuvjtadTUqq0BuwtB
j8ypTIRQRK61ytxSr0F81TRsh4ifx4WoCNxxDkZwo2y/KO/zRx0HPHBjftngyznX0D0cI/aC1Vp6
kg+5Or3iG96SyrVT+t+Uf+aaVj0Kbdcr5nuslm0OyD9iEQ0UGiRrDaYq3UEYKYSQ3OdnA4zZT6cu
Q4IET4BCcNsrdFFuaEIpePzwvEyCWD47v0SvGKv/mEJR+XWLGM5RloDqadODrVzTf1XHdNRowhE/
4Epb989Kqi0MNdUfuxLBjqje2MCDt7bCkk8FuNF/yV0oIs9/Z72NYRAuIojj1OCw+uKlEL3bPUtU
g+4Yznq4jN5yv5sZtWmiMPJKzaf74YLovJiFsCJcU3znQdKizNv/HxP46kECIMIJPwyJ3UKuLuZY
cNe23oFWCmMg2wXKhHWpLiRcLHWtbU5jtKhDAMeSSPMzmrjlQu3HQ6wWduiGnsFZTt4s01hIBWiF
5VIC/M66ySk0GGeZdUn9MSrTuROPnowY5+Wft/G/CcVB57AZo5sYB2pO8MZbjZGmhem=