<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxCVPK5zuLrtUAtmOe0X+40kbKwh8c3ak/O2w1VP6o5ie+/dgu7wXt3p0fexRsSbGFs/UCEF
xn9g7fgPTy0rL+1olQWlBmSWkHjlu3uFd9QDYf30GGgh7INQb0pTb9JVAlawNtR7oxCo4+sqKd2k
obcfqGa1xwBBsHJZtOU78C0KJN4MYXxMJ6mXYeIOOCdc1Ov1AwjU0VDohg0UrGUwFisg8Eiv6ewk
IjRB+EXIzGTNYX9eoSdEUChhSeG61wUdOC1mhaKhtnObZHyFXhfzYi4St+Vyj6bcrxn4QsoDV+Lg
JHT91s93osSoyKUW+8SeaLdXt0CZIa3DVecC19uQPfVS9WpeoxQ61iVC/UlwHfnnlUuZpkxvTN9o
Ch50yg0HWrc1FMLOkrFNCe871RicqGackyM0xXNw6fAsVwZHJfI+FpYxoNtAIvfS96wnyUqsLIlA
7qlzSKVw/bXhf9AOstkzPclSox9nHXJh4PTI+N7sj66UNGFZet3WC4v+pQneKaFpxTz5uc5zEvpN
r6PqfF/vKB6pR/bKjCsJ3f947syi+VMwZOGCvFL977YxRUlgjQ29P0n/c2750i9csU6bu9zNLRl+
gxGKteBM2Ue8IRBed5owdUdYg7Ln1H7z7p27KBrzhKFOIGjiLGCRoCULZH2iNGuu5NICGZR9S8wK
cfzITiFFay/ySiYFnqAUS4ZKs8OxHVRKTrA1PO0Fbh090uIZXbSTdbA5K8Hg8ciMBV7Wg1CwTVee
zXmm4rU8wbUTgYkyEFw05Ot+FT6mbYsz28wvZ2C3+hkXKG+7lTchRK/A5yctOkTR5TA/fHZdqGM4
KQBAYrk6ip/0pOvkDz84V/uar/m0S5aL589GMpMddmnxiku+K5aLAYLFn8ZnL93GR4vczSuO2mrM
/+pq5q5JJHbrBOehq/mZD6UAaoGk55uuGPzin9grAcztULUQ0T3oMSozatqfjhJIm/32c/DMT1uq
4GVBRX/0xl/cGay9T8jn/zBBx1vBZjFxiaus4+82To3Mdf/4iN5Cnzv6EGW+qa0ZPqi8Zbz4siZ6
C9STe2AELQVgDm5Zy70VsLZHckgPssZkUL59NRCww2XIqpbtdb0XcQrfyv95A6xelCOnI+9Wkicc
hcai31ogDCHN8460HX8BRDWDbLsAkJtPTBGe+evZ0kN8eamYqCCu5f4AgJXFKPATQ98RDQIbsv48
0pGbRy85packLhgAry2Ou67GwD1F4YxRHwv27rsEHyNKaGPAPYT9xrEITBSLSLQyGp/r0A8Cfx0I
tW+56HOYgKXr464GW9tJrbubUfctCePXPwjnacomUWRETceIAImlCx0X20LFjCIN6Pia+123sDui
yVXSVnLcC4E505qeCDZsuP82UChvSqYOmLZU5sFrqNz1LwbTOD5pDlBChG2d5KrCNpgLUySjd1Qx
uryJD5YcAl2d48KRRAzTfOb7p6MqgXTxy3tabVt/B+x3k5A7nu0aI9UdSPpKYXh/iZTjhQcLoJ/0
UjlKScBvXdYf289N7ulW7jI6H+tJgItunVXv86TmGZaIldH9ELXvGPMWgKuRZi8tgIInR7KhIzSK
k4jPg2sRRXFh3MigouCR/dSqY+zrY2hl5gW1rva2zW4UoOE7TtZQd39iDk2oQR+cYvDPUTxBK2gd
zx7EzIkf3RKl+h5NlEAYh6ei0rElbXmWyRH9gGPnMY4HodGi4xVHdKIInnJ7NRRtxpi5xk3jV/HS
7QSYXIBLgTQS+0gPTzaf3OsSqMHU0+Zn2ndFAMY3NjT3RqRTI6kb9w5IGR7JX8C4O0FqhD6bI2+Z
oW==