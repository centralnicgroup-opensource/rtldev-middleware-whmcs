<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPutzqzQCGYWPIKz6zNS+wr5JA0ddKkoqYeAua8vP180FcZyxSgfeR03tJxoaBAEM5lzELmpR
se/aT14+r8gBhdhfQRPLgU5PDSFyCzVxq7QAoYL8x4yXXg9EkJ5XMbrx3gSW7QJA8ckRmQ7W7blJ
NfxDhiNPwVDs34KXbLyDxA3nE5vKV4dAYz1nrhismmiIBzJXcg8BUNSNy8T9Mv1aHlZa4xIJB3PR
tlKzvPzfEKcEYYK5PMPWdxj+j2h3cdA62Ku/SjssbBeja4egBIOQXBJ+E65dFZkxpk53SjewhK8T
iCPC4knGHSFZasqmzbtkMG7gwVGT18mCHUmeZ1fMJljnmceiMRlRKkHIBIe1unxFastCEEGFZfoh
k3OW60yxbIsYAXZHiJalmipITXx3dPzt00hCtDyPP9H7BxTF2zSlDW+QN5UDuulaxjt6ZYVqQa0q
LFMe9nhfM1xh/VdZo1D1cUZ+N1BppqRXDXIRoptVw8s9LjMEiEAJgHew4Aq+uIwKZCf+3qfKVSBJ
ZkXaUom057bwN5QreMzJ//mGskZD822xeFjVEscuA27Brmxxrxr4kDa2lx0osOy5CLoZWIo5ip6z
9OlyvpaGFpcW+wEmWYgj9DcNj74iRaNj/5DZA5KKLucVgW+8rbSVSyKNG3GNv4TBgekP3E1TWGEA
uiV1OZ6keVZnWVJVaqB0JMYM8Mu1UQ8PL1GNzr0GS7/f17EchaQkX/UttIVnn4klreqcBRjcr/in
/ACFmBGpRaYfxddL+4FOC37OZ8ca2PO9+tqzuG6lQxZJvMsJDEcKMyFEYKYdvFWMfjp/rnUxS34w
fu/jQtQUnyBqZ1Tlca4PlhXmZpg1bsnRpM99Rk2JFHW/LEwxp/vq6ceq/QTav1QwFnkcARXQDFxw
26CKjRnhZfYLlvVJl422CMMDjQHWDQa7GK0bKFyJDxGEkae7ei2vVOgWHSueWsLos3kaZS2vCus2
L7wr++v6wvSOKlnnfPMjhCTEgr6wIySN8ItBgwipCqRTS+HhiSjkBEvilc7p9ybOqv3inK10scCd
LURR07We09iow5b41DL9r+22rvjyKCenAXVnPjEY0fT2LkuoXOV28f5bdb8wvVuKLKDvOMR20/N9
R1ipM7Tzarmk0aA41p9Oso5ioVh/RsxGIUCJKP9OI6hywinEI4DhdR44dIpEStl9C9R+xmUQMeS5
oT6eKm0MM3qMILdaEL4cOmTQRk5TjPxrD7mNRY1xBcZ0Lm2ly0j00jR4U5nW4jikmPLBjKKeLpJ6
1rlG8TbGzg8ezM80kxn1Ndw4r7ec7dZvXhginVC1peDgjKQI/Xy2S5a9N3tcS7vvAS1k17cfznQo
2m/79JsZMSw6NxqWwc6O5QgDixv19XIPNy7LX+SVAgQdCnbKm5juj+A5kgHF/Ih6h8/eT9W8K405
GFBibgjkmZwDib4YOO5UP48PTcr4YPSHDtHD30Zp+IJMDwUMJ9OBAT/PVSJKEs92cSbHN9d96Ewx
8hEdq6aS2tjndFWUV2C3W3+Doqy0IFAHhozgKBq+GnmIXODr+XgMzk5CGMXT7vEie+CR5bN6y0hU
+qPWIqlfXDYA2a/lMuGOHbAur/3kn7iYZWJAbd3pMgLqErdzElhsiGroi157qrF8nYUPyKToKjum
dS2yhaYDsQQVe2IiAq0fkQfqQs0qNdhQmqMZCAANsfpzjiU8ySdqnoSUvCgAxen8vhao6oRhbw5l
90tLmZ0kBASrdFgMYSaAE8389YRHhwBDeB1zHZ6P+UNudMZQuXpS6Vuo7Uqu3/xW1mlZFigEg4jz
Og0mDH9V