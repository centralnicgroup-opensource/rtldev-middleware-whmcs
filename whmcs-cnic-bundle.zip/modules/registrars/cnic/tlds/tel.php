<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxwan/y1ael/nF1h5bBSmM3IZu2MvMeRn8Iu4e5wTuA3PEgiAnRzY5AbAmWi/YQAjn7K1Zuh
Y7etHjhYpfMhop7DZuKwsQjkqCHZMHRDqf080ZY7SHtRutBpdew6gAq4wOjgLtAzDQik7ZvPxPfX
+0h4/yH8VZhHUiUwFxpnJWsrEw3bvJ/zzxAr9fHb91zxT2x5CHwSGohGyVMWX5QVnH6AG1fywYI9
2HRGAF9+xftdcC5S4unO+tRNQaxRsvu8VRJcI8rG6HoI3gSU9NxHfA0EL4ThMa96oaRYNZqW6dKX
QgOv/ybQZA1Du8ikbI1PdPmSM9EgjWl4ACokv2hOS5UCE0v6JD1DwE/y8ylJUY/hesWd/g7fxmPX
gZ829AKw15pdYQdj3T03NRCYPThis1SHmlKSqXW+mpG9+IPRbgCpfXug6ymP6hibnHSGadmxYGtv
Ur5rVQRe6oFQrPOM7ohBkWWWyh2tqbTREqSAGgjIU8I1kKmzTQ5OjjVhI+5df0VK3AOFxFrUK6MB
daH5bCi00sottztHxQkC4jv2NbEk40h24QReCF1/uo8Sdu3xkHIFMVLKcQW1ozbkmtKiABKpU22s
lZTORlrFcwG/DXEqo462WDGSOwct1CTH0AphLq7Kx1vqBOnZMWTph5SgoU/Ygf2Y8ZkxztOfdasp
9dRh/lKzg+8P8Pz9hpfLpIKdidFLW05uZ5Xo0cKE8UM2er6nOY5p/LOBbOO1i6mJyjHf2/EAJ82F
liKeCSQANij9oii//JKBLE3gGH2w+Fz4Hz1iQis/Mqu7G8QUA5bQGFnYSCeP2+B/wyRNSz60iUtD
aoaPn0h1+cGVzqSa+4ig4/04upRq0OEv4Oh/hdkNJ+dVjisOb97G0khC1F/oyu0FTP0uvQXRi7+d
pRZQgSQtcXhItOq7O39tcNj+B/k55WGJYbDYNMx3TX3yr5PyGrolbg3OQ/B9bqyt/qr1bum443+g
Iv3mx7XHco8qILNV9OERH4i7ghpSi3Z84xTnOaOh1vDl1o6LAGxn3n5duzc1CiTdg9kgBe8zeonp
1iYraQ3aWsPoMw9JQLUz+aPek/N+kUa18DKYk4p2PVLrnI7khAP+YPC4JQ0h9z0OMg4LEykbqRuH
L6XE84L836KMmgqu5AYLGtEHazNXPajFov3ORZGmLqan8QnJVZHLaS79aWmp4WkDEN3gwOf7ySAM
DG+gMwJ6XBboMwr2uGxegpHqBhv/hOwNTZbCIUw68excWasYKpt0hB5HXvffz2QoN4o9+9E5tGVO
tFXU49u2vpbh4aV7POcZiPkhp24M1zvMTSUIAyTt02lRK98KfZxA2W9RRQalfXzPOul4sm17wpLJ
o+WI+Gki2k94qYVc8Drk2WRODnyh/TnsfqxU9p8Lw15j3R+rYwOFZ7KlbY/Xiy0BJUbqUDaHH81L
KaV3obxAqq0Vd8jj8Lv/mYJIyZwwDdN/JbI/O64hmc8nQreTydyt8exbyq47BwgDwaxyIO9aWQR9
BJ6e6oen6Mjz2E/t1UDez4G/6dck4jLpTe/ESTSK1fT1Dsvh6h4tw0MFzszO5UWnZOcD/HdXU6RS
DHRu1/hdxgJeQ0U3zx9ycOYPQW2+oB3DrnqpAxlGcO3w5Q4URgo08tsszeZYfQfZ9uKLROZ0X9/H
WYxKxGIhWSXENZflrfLDVHENBtPQNCyxvDTgdTSPiDKgl/zST+MSqWl/+MiECMgfQtfwWuIUrU2Y
2hhB065LQsZ7fqqeYiBX9du7oVGStW8HbW6zDnhm+q64dTE+66W9LBbxG+AIizoBDE8RU3O6lfGf
PNS=