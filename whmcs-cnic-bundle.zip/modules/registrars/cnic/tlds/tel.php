<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwVsJR+GMRQmRKJOd928LwrXhiWQLCbs4eEurxrHdqU3IGRzlwJg1P0QinBKzK0weHpszQM0
LnAnjcc9nEaAorbutCQEZtgrbJjpg/+RCLlsAVRie7uHvxT81fgtpiXyQUpaL+c62bFslm9dGVzJ
llrLEwgy4tGWT4Y9IaSNh6telQSb/SYGsKZe3ZDZm+fD757yjNVJwRSRw8DaaTFVCk/Nim38oGmk
62mESLOAudO4HQhS4h6vwZY1NyoNHdAXKKF96dpVV5iY+qGEdJ7xGhOwLOjjHOKSs5ju47uWcisX
p4La+yhPfNLYhuv5u1G6JB0Ka1wOXXs5eS7NN2sNWizcV3G+Bxs/nF33tVepG5hpAUSWgEGK4FhN
4mPAFOO2vLK1xV4wPgfEwe9WjxnvwayNtKtqDycnocJ6t2RoElMz4Da4V6nwuavQeysyrBnejn4/
jXiwGEaQiUbdDzpS4FgyD23h2PJFhzPwXIWNznuF23agjAQ6XCTg1m8rfmOEXCVdFath2AFgSg6f
cArj+HqROeejJBI0+rI9aRhljk39Z12Xb+ZzZzwt0WyDBq7KBj9zMn0npxPJYsQFcNcoMxTtlDqh
mkfSx2c36EvU8B56fxT4ak4T2YUEHf8BjiiXX4150/CB6aHycA/JYlDv8kE8VDOjxY/ucShMXW95
8LJsgk3lNF8j5LQpFnC0Akyk0S+Ahm/6UwDsKVl59CO5UJFo9htD6gNFoKzNJA2pCXMnfOAlMJsv
OcudJhUGVR3pEYklfiIFyvN8zEdVZF0avPCr9H411yZsa9v20oCSpQL8xxwoQOJ9FOA6rQRyVvm8
p7YzHs6hn5VB95s0t4BcH5V1yk19rYivtKLkomGouj3jaYYh+2FP0/Ym9n92rZKiIMMR1VDPR7aM
0bCxKZvwFRILQ3ZcRns/bj/M+6NFVz+JPJV8B4AKT4to1n4qHS8msjxvr0YxY/c4okm+MGdqNrEf
bFH7n5r6no2wQV/daanS1bQJYQHs+mtSMEwK/0GzXxQdGiBHpugLllQTAYXEisNC2JOQtqbWmNPd
AqJxZm23OF+iL97T7LjLmwlCbw1Vrr4WRziQOYZqGP2aKo+cZz91ursyOkdxaEEVfh7j01QsvWHa
12stVOHh8wkADg5N1xBZnvDTBNVgmyZMh0RCmRWjshzKACS/pGlcfNzRd3GmZTZYUvDWd6aOaiXq
UBVv0d2W1jHyEKctKIWCo0oROJ8U0ptqg/cOjxflIpuxH8x9GEMfSfUDzYPrY3C+74DDZLd/q5VV
1qZ7ABhToD4gfJvXCoA4I6PY8W06Y83bDg/iE1J58Be7pBRO8NST3Gvoa8mgiEtPQI1fCWETOIrl
5NABw+KBGonS+wWu+vI6ShNC4ujJbrguVIptVB3om2eYaFXB7mamALxqk4WDW+wtACoCmZY8WjI8
Ml4zwhtAPzkf3MS08OSbGa3gq7k+w9NHj8qHTd7FUwjpLoSA8dQ4vzgfVsj7fTBAeZZxCySlZVP9
VS0tVIHnGNMaagtmuj5oBWKSmBzk9d2qIoxu9RO5TLzg2xgPJrRDMKdfVjvGXof0ylVkgPZxnOYR
10sCEmMflXHocZMr/AcjGP+N6UQpUJaP/NGtIPGe+KPV3ETHvAl8SC+3KiIx23QYcQ8qw9gw+hcc
yOupPhjdhieJ9kfQYSXY0n1vNM1Ot2iTabivUQWFGC8RbXJUe68xAAQp+kLkZTN5Lk/aoW//7iBC
XfNkdKkz0QcVSSRCXtn41iNWYFlIO9S5pYEG5ab0mSELmtouQ5ulSB6YhzbW+IVf9mPtxwqNEXdb
