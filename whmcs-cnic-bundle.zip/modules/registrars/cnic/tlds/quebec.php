<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqp0JVU7AhRuNdVOrF8M4vYc2ye+gWs33wEuEmB+QcedEsjhA5a5E1f4dS4W9Qvu8U/B1Jhn
C4cKs3G7Gyf4EGD2hGBtWs2T5ypFNiOZ9wocjqDqLtTc2cQ2x5oBOHLjlkKWQcP2eg5lqhKmEoG3
rid2z4d3dZJcukIF19//t1+D8dvb3ug3xzLkS99OVpvMCEEZHBt4q0FoYFTtJ2kL6LX9bzbknMrR
B1kifhDXYitIpsEcyZDooNPO5FvK7cVd7v1bSjssbBeja4egBIOQXBJ+EDbZR28QZUe7NDfAzq9z
9OOtkll6L2hvLYme6myGQjqIJa0e+cA18E0rATvwFN39e9UEwQ2s/z1GfcEcqFivtIeOXnNUWDVs
r0TAObsyNFqvGFWg53TmdLNLu6xyQdN5nKae/6TODMfWt/86ZE4jnzdPUfYWJUcDW8Z0q7ZLjKw/
+i5fNym6+HflpQOGGVmgwsrt/oQYRujbxQsezDKjsfUn87QySwODODlZwA/9w8HDt1hRmckiqs5w
EH6XYkfscgj5LdxjHJDrSOkRzvT8AKIR0HldgVNkObsdnfVU486D/J5gbW3W6gThDKjMV6T4f9TT
WE97MqEVvRQVCJ/CwgJipxN+JUD52DQAvfKQGXLsRK0W45nsVXnS7zD8cCkSpMxCHJlintl8WN5j
oWZIieStO7Gxn7BN2NoGNsrM86bIyhidCitPjbumw8TwfRgWIgoPWgz5NQY69CU6AvTm7qEP2KZ6
9NJ9IqyB2xlCg1+bQyt2Uw1s3D6ii+ap+aBGnS2eEh4l+sU2S+wxrfpLTeY/l6qtgfI49NzedBP2
OAIqe/QsKggagDfWzZjOVHNgZZqtpdpxVFnSKef/3bYpuMb+0bU7hcMmau25/8f/dcU0pUr2XZXT
sD+1UeEy7WJ0bkSTcv3hK9GKWR6/UkEOm8DN4FL3D7VLJM62Tc9LqAsFkqPZ4Wq1WL6f9X2dzJtP
zyLFzUw+fCeZEXizpJEFxVdh3JznAoumlGecKN1GauYjtpPHJ4olNXmpw0==