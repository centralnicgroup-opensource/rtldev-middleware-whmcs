<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoZeI8mdCx6ZFb/Th+Z2IqW8GN/Kvu9o5ys1Jr+P/Z/X4BAE2PboJRIfjU2qPk6hW7UAkUM0
QWf+dOpfZ+GXN0q87ymqUFnOEzhg5/Esi2Pc4xBdxGTvy2OiBTuOX00syFzni0BTt42wVoUv6RYT
ICpKE8104gcFDaC1aTrlVrBTMkTcGaE6/kTPaVwAHBz0zMA9U70eqSPPHqVXbJQWRA+GjyxqsDsU
s76aEQCTdsA/FHgVkiTu3gu0QbBv32ZC41KE3XfyttnR8lj43fqn+qAsEbNfQ3baztbs18zAtmxD
8I+6O/PrZfXtwvqmO2dVqd1oJd6Wq0O0GlXBH8X7/cWnj3KAyU6YRsCqyR7lpHUCP5rj2HAt2bD6
hmw6MXfyGhXX14oPyi+oh1deMPcSuDD+VZw/jQhqp63ykd5vAAZz4qffcDfCUG2f7YNtYw5eQ8CG
3woYKL0MUUu9WHv5hryv+ehQy8tc7OEY2CrAn+RbiugRLlvpwAi7Q0O2b6vVmS5qw+xScP5RX2fG
2wG3VCpmI8Whe4yq96tjZnhuhGOaaN6wiWw3JStjbtWbahaiyHbKyrMCioq4rw9yMjErAFPHPPhW
01NrDKFP++Qvmog03UQzkbhyzVI/bEs3J648eydy8bZmVD5x/oGhq2fYfaAfhcuwSnhF284RjbUn
evkh8EwVAsEDXf0jjeBAb8xbZIVkTgKLcFDlQtigLwvk/rbE2Uaz5Jeui9Z0T1MSxMu0H101AZdY
kAd69wxs2RX8L1vmp2wZEjFYLAkClegnODVWUK+G1HZ8yhhQtdXK+nSik7MIUJNsjcu9rKrvNpUt
hoZnL2J7rFuWKnLGNhngLCYqwzfugmF//M4pkr6DWffww2JIBGCX8NmEcDdvaeyKGYHyoHbWDS8c
4sZb9jeKx0cDdBI2yKSMsRGFIoj2uuve8IV77rAGIR7qnW0hxwSwpkxic6gERMjkls0/HETrW8JS
dguo7IHcC1qPAuimPJ5wrsRbXgJCrokbwzc489LfsM83fQ8X3uAT