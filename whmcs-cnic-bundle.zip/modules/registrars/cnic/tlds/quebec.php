<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpxc4QPLJUg98564XItZm4yS40K8w4saQ9QuqzANDBBx/WSQhAtbD2URKzJVctLTGEkE9rvP
3eWRqtyWhvTEzTsItSpI3s82CNJOLhJGZx4q2hS4OJ5XI1xP1Xj+Cu6RaVeF1xm4bgWLdbz428R2
bkFkL8ZTUNBcVGCkmYt2aqyPniWmHqSraPfhB7tQ4M0JjNq3bYixmt7bFuVxaYyWnmoFT10d+6Gq
NBJcUpBLdf302zFtB/HCedc0KRyMnp6EiodEI8rG6HoI3gSU9NxHfA0EL41XJwkp1CwHCo21fdLX
c4PE/qs8fqtfwJ3l2lRw2aZdzGA1ZevA1tGANqwN+w1V5eOHMXNZ4jfCQBye9f51BJRnHdxKp5ZJ
7I+6tT+ofw8DcmTUiN26wInOJdu0YsnqAIF87tZXLK0M8YupnLyLYOtSR7t/krvAG9OX71JOKKr8
Ml9yesMlR535G72knKjgLmj2AkoBHSzwOXNZFi7AqPftEvlJkeEVEVLiCrDO5w2CyfiGGKTUUS2y
tRrDm08UjPQmFk33k+eKaUbJsxO21gs/+d3k08fH5VzU6qBgo5Lh3xuM0eoUzPjSFMxIzOeQofjz
1IvXiRvJSi71sXAerTLJSvf7OSyBwn5QvakX6mtOwqENxTG4QeBhqL4/GN0bYrdZqtAOOzGUdAaU
yB4LWtJqFQOL/VtyJBsm2GP88QobUQJrjAGgzyDwhiJYba+piKFEaxXgTXEBoxsjVGUqu1+Ly1D8
1zgZhNIiccxZqrivVlSuqK5Nk3Z1w2KvBAV981jhZSOr2c3UlYUeX9dkN6AXFpuBQj8HU0ydWFKc
AWop7uSjFQkDVl6V18FwIGBhrOcaC6Ig7BqUsfXLS4aR4Rx11s7I/qNcykShZwvXLZVN7yQtC+au
o4gf+1YL2AuQt8zU/LXLNrG4nUyiztv/LDlGlPTV3hoj6acDgZsBmvtBrEWcLNDOGVyae6eTgHXV
tDmbIzw9G0Yw6nhmXkgvtFPPcFmv1in4cFVgncWZs1ZjEefKcw/13n9Y