<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnl2yDjtASaS3dLb+7PuStoKvkP3yhPt7jHG2e0o8QK2DWMVnY7txNyTDLSlKOxLXjBJn7Kz
g57Ltr9XaPAtwcHr8HpKG7Crc1JRUmCvZoeRCBjSLY2amPPkfAwZEjamukPg4eX6JxaLyjAwP/3y
WzJnwrpCxh3W/OJ/TpOHcKmdyea7SKeS3y+znOIui/lKiW0W7ULUyNFMuyaRTNs6j9M8b0kux0fD
pUFb5pRluARg2G83ALrcKl3ar9cIVayZqpX3UIlV5YMD7m+6kdsAmHpVv/pdQsSgj6GNdpey8rXD
PtMc7QQteR+xT85ZqwHvcEfndt/Qj6dj+TS6ggLssdhj5pIfJcjifpeKPMImlW0tZne6LWaU3UiT
EUGz7Q3PXtn1OsfadRSlYGkWQaAVND1EFjyDVo7S+ItXxGFYFh98ob0fe/Vgc1tpsqv6uJ2+ycKU
FbO9eh2PLzwRVofWBXBi3vHNVYew92cvxCjcRqCJ+f5/fH6EJsj3cb8ABm1EJQ+jyalZKEuxQsXE
dRncM3hg8J9gRIiaCPj0cj2wI84BksoCYx16v72+lnvqe3MLxeQIJblOWmDVjzANDLAPZlxaquKb
3j3nZRQyvLy/vxO/n5mWEYa3mgclojCXVfx3ym9FF+oN9KvCj8gEjLMMlrmJTXke/WmJiYKw/21+
Ls3Ij73wwcHM+3wS8BhLWxvsDxqmopLwNeV9L2i4kAKRTcgjXbXxcudLT9XurnsjZgPZAi8vC1j1
UWPy1cgn3Z+KjucTZ4hp1GL5DbfdYQ+iyBRBYFNjEikZXCMp0lrSKVeXuS3CZU7WyQThWswAZhes
aRnuNyak0K3tP51/K6JH6Yy6YSxVRFH+2scO/x+OZQxhpbcuQ9FE+dGxxW+42eovL4fecFtiY1lR
kYHeCJviIEYiim6nnpEE0wrlGpzDv8LaAFSzf0e7T60kkL0/+7sQfM98vugXdBqcdw5CEovMgYEQ
aaAEneCaWf68VbaPyyNjdkM2mhAPyXmr4MNJC/uoKW79o6sIWAFZ3JNd