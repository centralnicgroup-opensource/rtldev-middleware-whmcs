<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmPGypL0kySw7UTc5X/LYaB+Xj7lUC0uauMuuxpEwsTmF/lWsnDoQlR4Xg9IkVb+vL83EcxS
4RYi1IHPE3UuSbxD7B4jK0kPqumX9zOCXPt9WyRlS5F5Pqc12We5Utsgz02edTd5ZmZmlfOKBIcx
MBr/8dk7JcmnK1r1h/UDR09jtaOXI1aaYoKEwHZmxU6OmZbyYXHLEGdZAEh/v8aGAIUmzIZCIFAp
ESTqw5lnOWslqJjB1GdsaW8T4DzgiCzrX2TREPx11iLtV7WoGwx5smpwtUvbcBjxTTxzQpzmei+N
RuOUnqeA6OaLv+r7KOnzZcFm0Z4dxkRMc+dDNUxL/G4cyboDMCjvoXkT7+uxnWyHFm8qtZ3qqrrD
2XqPmRNNZKH/sc67qdqSEGptXTwyfkNdIYQoXkOCcfpZ8ySWBarEdSNovnJOq+EHj/UqDLWLAHDg
HWL4PnhLlOBkRDAatssTOkhe/Op5XjB0EOEE5r0qoC+YSoVJnEMa2fDqs6wclihKMXrM4A1xmg1d
V2HFzS8KPLOHvg/4AN+fSpOw6Z5+28TNVcPM7XxjHewUhritwrem/pRfPXulPn3OPifcumc6bVnp
ayu8fvLbZZe88aWtWhfrBmBhGS+TZ+uwKE44MN+6e/t+d0N/godAq4CxUt+1DB+MLVrk2Jjm3ri5
D8yapxNOvktmS37jD40NuOkqGLOHAGQlJoCmJQCXOSvcwCITWcs1oLC875rjV5X5+XgNmGF9tuuM
i+yRZ06AclaNB1vhEUaLh2JFQexQhD7bPl+V9QAMosvaU8TRvh5HMLzak5qVWmQjs2SgVd76kDnO
Hhs4UO77t6eunQWXZr9reSlie+g7lyw0O4/0FgRo35xXyiGohfmQ6A5qjmlTUPiGIzcg3/UvehYc
1nbM3jaJTXnjyQOGaFdpkBM/paYL39vA1RdDljCpxatvvblysJ4IJEseH3EDB3k6mlgvfuooKkBf
bfn8jFbaD1Vt70DaU1OEaEYtutADecUqFnIYdo5xpRBM3+Sv