<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo1GsifNkpxjBkTFwVLnXvMCIvfO4a7+c8+uVIomeel8A9cpAbHpp+/HS0qjEC7PRdF1QRNC
Qsk7A6KMyoGOUa4FD/te9gW90zcKOxzmmdatpONUjSioP/zgWLco26bfIaHQ0GZr6W5K3+T21enJ
xVDONOwJfNphJTlU29/frLvITViXq5mrHit6wDtYrmueWvVX2q73ycjzRh9Whi13gfInpjuZvO+a
6C/udtanZqJ3nnj31T0OeDLCA+LiWnDYuFPozJ+PedukJPKmH71Gvf9HSrzgHSUmIPEGzQD8yZfT
UKO7TtAYILFZP2U83gUcbq6cyP1q0a5GQdf4GZvEKjlbYYQQ+OEO2pKi7Yvkd35p/nAJ0HwjPliO
ajaftUgJ3A6Zc5DuZQXFy+qKNySryx3SX+jjro4ak+VvnhYfxHUAKEsRlQnAj+57d6oIMOFlCE7h
W/mcnkXnmGNTXpTJESpt5BM/kNOJUwto91S+5PwMVgdNppvkqdjsuS+fSq6yRSraqUHm3CRaLcoJ
fP5axRiYWRy4/jSsT9DiJ4slx57IblZXOKSAZAwtdoS5nP+O0KNZnr91yvcYDLcag8kC3uoDNo+u
ATAVu8f4QyUyEGkRqcOWiAqrN1gLdtTSTzTb2kqBpLK7apf88LeW90zZWsbwEFto2gP811IHj+3t
76uTXmlnOguiw9vSbKMQmbtUCTz3ru3DsRivYRsXpa8GL1R+ooRG3Fr89XDlOi5h9xuVibH4f1PA
Y+QkPI35CToum8evGyqM43RVwR+vAwQ2r2+0CuK3rdzcdLQXLPxOz1ikyygDxB8oiMsuhoG0W7yl
uhp0MfgNbMMozLM+OK6wOXA2YX48M2b5SZsBmNEkiLHWPFR2mItI4ljjdv2zrUjvw0PFyiIkA3Me
+v0jD/KuW0cGfiKiBUuqWNMQm6IeCeJGy8PJUQLyU80YTTHdyOxIGNKXr5p0PZZhvfRhxYsJrAvY
vSWwlfYrTgqJ+UDJ4Hoq+e40Rafi1QJy1AKCrbUrsL/GQGkCAkPQCt7ueHmPmSK=