<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmSw24zE0V5W5usTRAcwji/C6G9EeKS939EuoPxwVgnVCWZuIB/20hi9crpYLW0EwTh07TwL
7qg+u1SpPu7BaoGalAxqI7RCPCeKDhimPik8lhGuhsM0N5H6iTshOoAw8iRpaSaXzSMGuR9XZSMk
pKihuz4gv7pXZoLVZSrSm2dzmAYX5EDcOcPGJ17wJzgsBcAYRbEyEwEfW08tK3yuvYsRHbomL+iC
+SdqCJuMVtdSYhaw8mSwvdEZ9n/Xnoep4qrUcBlKA6H8ahe357dMXSM94yfbCWRKx3YCiSNNuqvI
J2SdcfAWKtXhNneFzLFnQe1LeHWo5nz4wAbqjtMrdS3kKFxshQKbpc2svVWZMpy3AtG6gFnTxAzJ
f+t9ZEhqIo7XOhOGEfWHAD+5RWZle4LjZM8LkfMn0U1gMeHYy8U6OHc2Lqm10zr175hcPqJROHLU
z9dxUHwocPXyD273OE4P1oFSNpln51X2zDw7ENfSlY7ElRcToAR62U/UmwQ7PIfa/rsYVd1b8koG
2ZgRMB6FaOKRbNeQ0uyLOvvaRPbH2M7KyxLVu1EIMsU6pLvmOEQPawnUcjTgnQ0AOfE1fij12CWG
m8PDQXfHvGNiYWbQFm13KV0bfoudwhV46zef/Pd/smj21oKTgqLGJ8kbZvmKuTbOZFX7ubhYMRDG
d6mx/oNeWiw5LYWYY5ywza07/sIQie9na5+47HETr+B5nDSTsqnwmNncMTNd2OZqIhw/64z7ozaL
DfBR40SIUhkLdN4LJdLMBEmFwOAU1oiASy/3DurAQxnCgF3SwBB9710pS9PIA2+ybvejDBnBDtJw
JABitvad5lsV13wFsCeiKsgTFS4rT+4w/ZErqDleRr68Ctf1jeDUaatu3vxSISqqthqJG/TqCweD
kWiYVRY3VKYLKDlBImo/qxBxmkMBlvvIxQhomaY1fW/4K/fvq67F5KVhG0IuT+cKyDhB+JEFWVQ2
xf5V5yuq6KvEyr8ESnhSb6YjYZ+zKR0+VaAU3/xvioM8ETvPoEJG6wbn4Zi1