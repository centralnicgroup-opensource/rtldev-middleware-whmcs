<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyKCqPiorodSoxj4kEG/LkukAe+uzUcasl4Yt1/UPZGotFXJ1lqi0rXXKRYmIrYPMki4+OU1
fLdWBwGpThcL9sc76FkWxBaHLZNj2XYwa3KNYII5Z0PKNxbU2IT2DVShU/BTqVbWZ2RkkPoHBjDj
GzMNkOMWPb6nMKRlBCa0Up7VzPyDvQm7TZgPnbvTkpAyhaNfyQhAVZ4ShCNr61WNIXehCivfz8qL
gDu2nvzZLTPGHaAFi0cyNKeWnhKvufPczHNe+afzvT9yD39gwpBCSAKL+Rg3Qb5CxXpLl2E1Hy07
KGNdRxWXyis+TAZ0zofNqcMTDPSO72gHm3a35pNryTJmib93OA3Y+jhD8aNSzMtJklTNBro+UHnS
aUY7KkFhvjqV/KbBsWYYXjqHnCpz00CsHPGVdH2BwDnJUXjCbKgLqenBkmyGyQBnAdpSGCWbw9ri
YtjcRQA8FLphyqKwjxJSHSdyK1afL2Lgtb1j3nL5bPYyuSUH+/xUr/nQI7I7PyKTIUo0dcOCrPjf
DE66mNsL+VhahkR2wj4wA1JtZpue3+lkyDt6avwZz1r9YE6buuYR6JOP1j/qHZj1dsXRB5gUfjRK
9hZXzK5E5Lq25fS7TyW69v91fF68kwscMwjvKAGfdtY2p8ADS2CdWo50x9sv0HF++YWXA0bR/EAn
/Wapmpt04TeNaega1NSGNsVIPEt5ZpCv970KCmVZ0VN6jRxa4Kamobg+03j570Uyx4QPlGPP7MEn
86eNz/RZ/cTWTQ3wDDfPl8v4j81yC0srsBmnEP/DfLLbHrKwW+kSOeANz5DCvyL5Q4+H/T07Z4I2
XsKQ9POz06ArAgLI/Ea/ZdyBK66+2XLMut8XJqZbcCJjzj5GKP3ZC3IQypzLMU7LbnPPyP9hs7JR
XHn4AS2asYIYAnXQo5bJcSV98JvgcrFmJr792BWiQxWdoCjGZQU8vasIwG+ftvl35GEKg3Vry0MF
e1NAcSYXA77398VQsIEYHpKOZldlA9WiFMfrJ4vQ14oy3Lgg3hwJ1q/tfhSKq7e=