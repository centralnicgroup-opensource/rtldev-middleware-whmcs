<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmF6kPPmBGBP3N4ijLLq9Y7A4RQ+7OrWD+WnvHXY0vracRPQwtyV7jWlkNgShPRYpil7tBfg
a6da6y1QaCwMb/m/vYClHgoVQ7aVykvNSzWvJNCY0vxXM+u6lHOjRVYcnVzkrQy03d4MldUnaiv8
Vo4+7sq1FttFXLX7aBtJsY5FkxAEx5ObDWby7zfgyv+4qbvXXohZlBUmzyEtWLW4fb9lLuG0/oNx
ioQeM6E9/iyezdjx4OqCh1ZQk2qc16bVD6XcN8kyZYRK/8KGZ0XoGEdI70SHcnvdNOCdzznbB5Rc
fqbnqAOriTetkoAdyXVakE2WwDqSff/0MKFMKgHXQqOdrzHjm9d+2czdVUUdizn+M7MuvkuAIrpb
GC50fpwPu8tZ78FIOaebrWfIHPOouzHKIWsU27tiFu9O+3GvQ4lGWEX9OsU+8zg0g/LxggaBe9uz
1UzVo/WSs8KPMmsQazlz8kANk+nRr4wcr+fNARV7Qx0rbuwrUShTXrNPRiGZkMkDdd9KDJ6NjQBr
3qxdcQv3jCK5C6PImfMfQ4qNrxpnxW4OzFmsdJCsDfFasRKhwaenbxgbScfE7s5xzvMZkqxFfMyP
rJMYMv82booDwDgt8bRArK07soLwM6o7G40cz5SwKgE0IPReFIgOj+0OC5In2xaq12w33+SxmmSH
wWOXs5TpzALj7v7qFG5peeETZWYKIS0x5GycQsFc8UNtjnV49S3JrzVq4twsdmaON+KV07pLwOEF
JExMCWW2rBchKaI7U1KnHhwz0i4aN4CxipWG7s8z6OAXqUH/qqgKtvEDkmRmHBZ5qjpY/OV6NIaA
FuSJf6xGBqTro1/OttDe2jwbOYsAErbckWpP+SbvkT+yVPhNiGw6a73vItWnBNISZOOJNL24KDMh
r15jNcm5aQF3cVNL+YQWkkjqAEvw2E+FZftgNdFrenT5XYB1o/8bxgT4eL8etDoA8u2lN/Za8IWc
Vdo1e/68G0BGQEklTGvYbSGHO2zBClhdPgiQ49MdRWf82zbScX0ul/z4hsCKCWK=