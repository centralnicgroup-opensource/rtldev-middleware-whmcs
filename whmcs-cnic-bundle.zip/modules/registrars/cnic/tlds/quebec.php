<?php //ICB0 81:0 72:caf                                                      ?><?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPprSE1I7fe1RNkkjDnDnsXG5fn50N/7gO9MuAYBiO9YtE47n5yz+B8owzs/ADxWgYW3kmUQR
QAg1SGPl9CVIEbC5ZAQDTtJWAAM0LkCvuHU42a/PTBefFQsNQ+NAV6SBV76P5HnI3KLfgj6584dz
B0F2jJDrbs3axwbTzNnpqu5aX0Th06sTWRv/BDrWswpxWTmhxKsSjCWMLf31uMa3EfTgIAGqzLXl
9gaf4W1RGI6wKt5sVEpeeJu5Dw2K1dBzoUMpdBsZZZcvGvn89whMREo4231b1HyZ5F9HpsXxkN5/
LmKK/tm+kUO2MakYmIFsVlBjQH2Ch36tbGxmsoCGWHJNR/j2bat/3gOOWdVv1Yw7wfZUNT3zHRrl
ax0KK3ernaSMUSY6TLtEcBSBhL5x5JEWn2bN+yvjbFjsGBfD8bzlKGlPPEp29gb5yKSbz2hB9w5a
nl9cwABQSSaxLZM9kjva5m5MGQYBQDhfeq23Gu/V3JZuhQcNWSBFRf3zBuPt8065HFkzo7WKljXd
qKUV6bJ6YFkqCHJj4flwVY3qesGPPL0KMNGFGlSFrdCUV0RBoiXtbjR8hRlrcgIiw1Nfrz1TI5Da
Er2kt7UWWenNwW1gbajM6nUjXazk2cVsDQyTJOH2mciF1LIWUHPaw+zRQQr3+TFnYwzfup06u0Jb
K9zQ/TH0u8c7wspO7m0Ibzf+Xs4t5h+kQKTwaOt5erkdQbwC/1bVPI3ZDv4u/yaCH4i/b06hi0C3
oL02kfVB7Aj4NeWpctC9VmsTacNGQ/P32B9zeb9+cFOl3FxtXTmWW0NEnivc/GUYLjUAkDsy4fgk
RdugIzAc2jV2XAXYg6HelPN24elar62lYpMTSEqmRvGpbuymZYbNAS4B/+eUeBrX+9YSrEYN1KMp
yG1kE1W+URYKWwg5+2q8g31S+Fzyn2nu/7dxzkDs6ouMzZ0tmXXmHX4Sn+k9ud/S3TcpYHrL2x2d
CM1BVrvfL/wsSHVuYJNi1id7mCqNXRG7wGsXYdK1us+4SwyD4GoU=
HR+cPwvHOv6qerUdGUxsilPExENuj7+0T10XoyAPW686pEwwks9aUuc+B+DXtl0XtR+ygfVqN4Fz
Jq9yw0XUMtNVigRjbH4TkZCf5mnnEgKNZEIGvYhY2XlEY6ctu9iBgeLyuWlV1J7rISgFBUH8I1YQ
TMKmCumsULPxybUXFLJFk6IN+HpVEbvfQaehoLeDrxAkyZz+NOlGZnD0pL4xpA+2rD23LVa74eoR
19fp+KrTWv5VyxFJiHw238fJQZlTPmK9ny2+XhB37Wn682uDVHsf5X5LczyhQId/R2ldoMHcFx0X
fiX5SyOsxwTFE6Ckf/TAfodrzDIKFNYW26wA2zGc//lg5Ddiz8vU7R1oV3hzb/ac3EQrg4d50s7s
Ok2SSr44+Jv2eH4vvNndySTDO8heKFn+gTUWzXmMMhXORz8wTOjvYwVX06kmH6x9dqmBUzbUnwuU
RjoK+boV+e5c9SX1GjVGgCtlmHYtUsdxbpd830H+j11Ye0kC5lZs+6LFACAr8T2aORqrr0QBMlow
9ODfmxVNVYy+YPk4MYWDR7rtVdL49FTPGTZPnsBEY9AJj7OTxnRVyrQoxxKzqb3BO4iFd2KHxZWz
7xFvbZ8hlBAMxaqQQJCvNgr3cj2ZkKF/a/bZ3L5N/wCach2E72PO5RHAOHNCmI4tgi6j5j6bEcdW
cZLIvvXRVUdkVkgqt3t989Pm9j+gqYrlp07nWzVyVQorsgidRutoubD76ZF5qB0qYGtgSd7UHG+L
QDBYm6IoXnnkeORP29bcFhz4bYPOw7DTqbTX0PIkrgQWFkWmEhtRd36sXp23C7s5GUbrYeeuJuRB
C2cAfn105vWiw3bFGxbChsrUa92PSY21wW4rDYbKEuu36Cfs7+Vt7h5lXF472puSOUzEH8VJ88SC
IA5juINdZYsFQzA+ZMN1UmgYDuLroa90yU0hvMhpcaIG6YmCGhpcjUFNfqdYjuUKuKOpLPFo7IYd
brFbOVSJKcVdGTFe1d8NJzFGOz8OlwX7RrL97WtARDsfAK9EztIoJHJEgG==