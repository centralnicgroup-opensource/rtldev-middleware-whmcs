<?php

$extensions["X-ES-OWNER-LEGALFORM"] = $params["additionalfields"]["Legal Form"];
$extensions["X-ES-OWNER-TIPO-IDENTIFICACION"] = $params["additionalfields"]["ID Form Type"];
$extensions["X-ES-OWNER-IDENTIFICACION"] = $params["additionalfields"]["ID Form Number"];

$extensions["X-ES-ADMIN-LEGALFORM"] = $params["additionalfields"]["Admin Legal Form"];
$extensions["X-ES-ADMIN-TIPO-IDENTIFICACION"] = $params["additionalfields"]["Admin ID Form Type"];
$extensions["X-ES-ADMIN-IDENTIFICACION"] = $params["additionalfields"]["Admin ID Form Number"];

$extensions["X-ES-TECH-LEGALFORM"] = $params["additionalfields"]["Tech Legal Form"];
$extensions["X-ES-TECH-TIPO-IDENTIFICACION"] = $params["additionalfields"]["Tech ID Form Type"];
$extensions["X-ES-TECH-IDENTIFICACION"] = $params["additionalfields"]["Tech ID Form Number"];

$extensions["X-ES-BILLING-LEGALFORM"] = $params["additionalfields"]["Billing Legal Form"];
$extensions["X-ES-BILLING-TIPO-IDENTIFICACION"] = $params["additionalfields"]["Billing ID Form Type"];
$extensions["X-ES-BILLING-IDENTIFICACION"] = $params["additionalfields"]["Billing ID Form Number"];
