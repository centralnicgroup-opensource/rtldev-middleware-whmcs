<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvhb/uchhKc5ZAXLgOZ4ezqOOJXRvIjYHvUu6yhqq+qjkRyU4lmK+8Mjxx/ot6gwwk7YpxVe
JRg5n/SItjTP5QFb4R2W1IjWUoRMY/C4jrbNLZUpxr8fzKAWWeYKdmL6e3KQ3Kabc4jj6+Gxf3FM
P79bpQ91NPgMjjOKyA8u71Rr/aRK1DPKsND6u9VWw/lER2136BrCvVwUcMN6kXKLCAo1LGy/LZ/I
E3lHBjPKsCXQZOcY+Q9Rd3YoQDgJ0lGAMuZeAzyM9OqV3uQwVOh17D/d/75khEKaif9wBk8SY4tt
nMPxwQP/5gHZMpkEAFJA0GebHiXI/yVvA1AavM6B6BPHyGdc2beOdwNi42+kaPbtcAguc4iznSap
owGPRMZXgG/8WyvpP5Wjx7sgg7o/sIcTnBwLWEWUAziiDKk/hBQBtQsG09achVPJLyrbbLtYvnUy
6JsmTnNvw+QGwTHEcX+/2g1adi09Gx9h8R7dEyJ2pMmI1LjRIsmkrBlWfbn7yB3yRpixOlMuY8A3
ZWkb/le442FNluWII/U2AYfU46uA4y7kIPQ8+giEZrvlR04Uq5XynRjUyen62t7mvwTzyW5DqfkV
pKTl6W0xHUi4cryQ5J+QvJtnNIblPzts8msfXkmz8QpKVmd5rH2PTwUBWlNkvsA9P74Nrf45Frqp
6OKGfntHrj0kuC66QY9weRY4CDsGT2Pt8MhxYzaWRn1ackOx5Fsy3nSYHksNo4vUHxTDXk+FHSzn
PZ40b1k4lpl3obzd2j7y2inUEMJ+oUAJHP/FCi5/xdACoDJ+K7l9yX0d4iPcjfTPzMCI/qGbvqCh
9kFXhEkck5H/SsWn1pIp2+Gi+PYVdwcISSuarUvHJnI1kOIcKPo36wdJItIHtjRllFkjPZd3RcQM
UU6Chjc9xYKvL63LVNmf6USk0Qvle3ACKQ8JLwHldPuWgWk+xkAoExWfxe0EFO3/6pxCcaaPgQ3n
hnq+Voe6EWwlI20TLyCCW5alEvZg7L26nooi6pNpkawU8EH3EE40yjrSd8YDAJcdI7iatZ6786/B
i3xv0sjsJRrc+NTlrOFA0EDF+wNVAiAaPAqdmo9oeyEcJjrG4FahBaqQO8dnQMc9IWIaNPJzfCsU
+nAXWgfbKrjBEx/cn/40usaGx52kt0NJNmMUoizDBkfModFO5XwiePBrnSVo1KtWm4qI8hHSyYvF
xReYUY5Ou/pi1PURrbX5Eu1LdaPDRdT2H101C2MYsoWrt2smmxEQ3386jWqXQsZD/qqEfyfcgwoA
caSsURDBc1A9RT+JTTmpazUOd7FXWzYWVjUlKUA50cBJDDwOP33AfrxGYEaAD0A5gVPbcJa6PaAL
0o9zrzAWkv/8nSbzHrRVLROzcFiS3ZCJWeNV+XjGLtkDVerr6hfqO4kW/PxusG==