<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoTgsl/FGRG+CnpQJnzx+M8+cNv0exgV5lXNIzc0tWwznUggju9bcbGiWl1jo3H1bNRh4WWg
Dvn1T4IHBUNVJ15k1xvM8rUbVAx81AbT97gcXfmLi2zEiq7ybHt9pkXEPd72wpF2TsJzDLgSbWUK
j+Zb+bSVNgoAsrf90xyomJahla64RphGnBtI4p36gVaUxHJK3WNFyi7JR/yO8ucr2YetkDhNMvyW
lV5GjeCJCu0I09UQK4TLLO5fTFDwE+dQaCmNtBoE9jJyXH2x2790wT8S1n6RNMWnahFyZO6wKA84
II4/XWB/QcnKpxZq5pGfvPVwIQopfGQK05XrTwcGfalCRmX4pVMWWgsgcdSiBrkQ1074xeWIGr4L
yRkyNnfLn+MeVHPTzKcG6Zvt3nh06chWeoi9nrzXKpIskgq7hXRVW2Uw792YYN6yjWqG1U/a601X
bog4Q/wx1XODM/Vk4WntnJRUU1jNvrzfmlmNKlERM+KhH7xMA/fgjzYUZSGfqdObgOpTZTMCDo00
KA4SGOzQbbXNSxOV3+oONxAJh4SSZ/7Bksu4Mxz50IXlka2AS61kSJXlCu3gqQY+VsI5ICIaxwVn
nkjDtSThHHP4HQ955EtxqwEHQgw5ro94xK7m3I5qZ/o6Uly4RvRPKvGMUoqmfEbJQ3DYS84/T6gN
Fgn6v0XY5U9CWpba0iCGnPChOs4ReN6fEZuJYLPqmOItfKvsPJF4JkffZgSB66Nex5I5rSemOeqj
nruLDsIyr+3pBA7mf7gfjKKfO6IZYN2/3ZOluS9Jgux2nT1E7hL/mksHMbW9/vb4L6b2KROQgKT2
IcGaBjKiWTgFUAnLp1HXvMEN+K+5KssAtC03r6cl01MChxwDe5U5SYXYcP1vMTvyzT3XxfLceHVp
e4c71P0CKsTp1f2u+Z6Ta3whE5wXssHAJlv0fk1iyr94zx4LTjZQGvPxTb4W+MNpMinCbhR7LVpc
aON4vzGD4SQVinLpb3wOPeNLsOB5gK1CZSfKxMYVtUBklXiH2FJJXPd3+HvpDBK5ebgCLlRi1KN0
arOJGRQYXAdoD24YI9T4KgjAT2cebsAzd8Z/3RURxlBHxnghl7b0ty+yAF6i+gTt9sVL0rX2jPJM
0pAlGsA1ulIGaIzDIwplrsIc4SgDFw3yBMrXevz3eo+ZnS4dpj2vHEjRV1K7hTagNFz/rOSiu8kr
oXIXJjdTxSANp6M3BvPVtmWb5FiQuMJ6PkJko3Oh64Ka8UONyhtoT1QTzuReXvOp/kz5WaoAmQwY
cYTthIVwY/fu8beFKeQQ1xJiFScyEToUQHjttAxnNR8ssdobsrmqzQEeIRjPvL3juWh3K7tcdVwX
oJsplfUpQBvtpiL34vndAO/SDvOPGbZGMJK2AQ9H5cjFohyEelfp