<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr8VWhQLudQvOAyNbOs5INhTovoea5v1rUs1uTiDwxCtJBS26abv38YGxpuwuliEe22LxYXX
0Wan2yHzKo1ikJD2k/RRP5G9AgubsyESDd/f7UFcPumx/+QJXGK7YbxQ3CEsoq/4vgd090JXnj5w
FOw6eNbmdSnLB7SoPPRPljwIoCOTX+iaIApRi4288lBXC9dMvGAGZ6wfybZtXJOTAN1jGXsL/Oyn
dTopXOqUOUNw4Lbw63rSTNDf1+MgfaoQpcGDTfYxr2XaI9Aw0nHvreN5YHFJQMuUrYDipslxjrLE
8llc9MJHmPxfGaoWP7lVkn322e3Sep7X/MP46RuOrOcLhVmYC2P4BJ4muoVQEVkAt8n7qIgjv9Jy
vIP+BwMyMr6arDhyKC6shsCSq9BqygpgHSEDVArfN2EZP6S+w672BuDupEB09LjSXKzl0xrTMu+P
APOGnNxizZA6TzMKCtk9WyF/nEM/x7XivxSWtWDG/3G2mOL7Y39oCnMtlsHrSUdp8CN4OFIGo1km
q5Pc09hUqbGhalUe0cGl4SRcVDIov1moXdqptTU9E8hwxbrOQEEEgk/95ij+EtK4d+aO4fBT84Vv
l1FmPrOZ4+I5COusD+VXZGWPbQ0HbtPv2ENMa0rEU0sr1hyJe5Xp/o6F5LJYXbN6w9rYSOTb6aht
X3CJ7UNM5vW+2fXoBldK1WXHZxckNofUaPpXrDKUcnenr+81mbL7wCVlBQMjfhVeSGFNCXjK67o1
y76JBnO4wiqXxVfW5mNutZ9c978t2EqPAQA1WPWn2WJZkTcMClidvpMZ8cptZyufnr/mMVzZmPJl
npBjALxUQhjwtRUR+7+f3L062SYGdV4JQ1/wmKP4Uz4uUukrAVD63rhP3CNZCk5PWVEYnfHCNXnZ
yVTD1HKkIbShg9esFksKaTIXeUJPDON/JUfSnTKjIKsjBtd9+Mn26JRqG4Bq4W9E0/Spx4NoT82c
PBcfwN4oQwgVLcf9PyE7UzLb1RoJQOMxj0g0DlQRCPZ8XKxPQxwfJioZ3SHSb+NpGDMbTlxpo/d2
fmWPM3LfOgjwyzv6a6a6PxrOyNnqM5kLKNATdOgFFRLSaxF3B+CaiSWK8377AlxbvnLZ2OdiRGy/
JN3usBzV9VR8NuxNunySqjmeeuua41ZLkCpfVb2MCIqkXC5MPt024h99dneg0f8KPfjzVq7+jksL
TO3drxCWjJyo2dkVJjLbgdg8/6cpvh5lCbAlACgYHuGkD22uRvWrcg9OtwStrYmltWyIu6RU6Z6V
abfJRcPEYsewCDgVuhNt+wtPFmXWU5sHuREzQYOYA6ysDMnnQ8qVo7dYJpPbjfyNfxQoYk5dzodR
AS3PfpNcMmhpo/Mo5ZLGAda40zHUW7DYVzlSX1GjThkZjmGo+4U810UmUgJ09W==