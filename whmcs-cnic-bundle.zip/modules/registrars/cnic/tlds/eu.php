<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvm3GV6jxxd6gBFKqXbY19C9XeVKgXNin9MuaTYt4leuMRhYXgp6odhYGOlx+Si99kk/JUwD
M2dmw30ZDHIxxZHRrhvLfhX8hIsiiGD/IpNjXrxrWijnzOH7p8JWFzMxjTCmbc/Q0CabetPQC7Py
i2SVWCTiIhxf5gZRBET9fczPyX/eJrUpS4EXbdQVwxWbpSs7gekt5sCGKA6liV/eCijQMiNyrKCL
z8z4bnfGziHkWBSdJ0AGffFqJxbfq/lniKKgSjssbBeja4egBIOQXBJ+E3XntQfPVIGfEUnZdKAz
dUOztjHTUT5ZsI4Bu0bOCRTVb3Jjk7O/zI0ecnyjUGKfWBjfvByZcLIKA57lluGxxHhs0aywazky
/YYx7i/IzHg4pgzlsA4RUztQKFNUey2dGyVh/LPmpdz+laXCFnuD7vjxDXRo2ZEYpvJvurs3xlWu
CrOFqrljJEaI6RZPSbNC4jTsDmsC19Kf2aJ+5+8ZekR5e5wNC0kAm0jyOL8SqGPs1Ep6kiEkX8V9
b/DSkou3QoMUa6/Wz5M6YfrPnzqOGVqpKaNJVJkv/W72VecIcXvMuE/Omo7VVwN4n3emUPmkV9ru
So2hN1dalIwPw6G+ls3A4Y7VlaCxQCIHjS70uqld1MqPTXh/ZLjqAMxhdrHnD5TBtFOHPuXESNEd
MEBYmMeFYuYCwm28wo/DhcYp4QHZEMIhHH34XER+MrscG0dJmDLmXT0jSYeD3s38nx8/s6D1y4EC
cKzLQ7VsOZxnBKBcCOtXapsbQcZOiRpjt/zh7GPAnexglbodddVDTG3cgnv9TGvYjcC6bBxQPr0S
MbKx0GZFvQ38jC6sSKbWKXdU324oqifC2gBPfxD/mZtmCN40SXDyFp98ZgrQYyImLJNi9Ae5Jo3B
TMkCX8BXLko+gmK05P3smD+PIaj/ZhtEPKpgdspYRJQpl608RZUJUxDr9mbMQ75Nmq1u/1aF5i2M
yI/BXegUI/hCkSX5InL93Wri7b4KwjFoZ9hPvpdXaoOCMukGqqH2kjQgXVEYg2eNJuGdtnHIrEPN
EmeFXdXVrjoM+uSQy3LNWllqJyl20r/7DlPJ8kBzT/xFnPQrWFPowo7SmyzAUBTdItJVPK/EQj5G
U8RDg6ZeamZL5KFBBs3hAERXNHtIU0MtBYxE0hhELKWCyhhGMt27pB+S0n2Vj6pID5Tt39HmySj0
FOi/SQuL6TqKkW1aAeSESqkmlM6bo2x4XmZS82yAuWnWRa02rEQuGBH/aSBIRmxw1WtDKmWXuUud
NvPNsC17gkxna0XJmVck0Ukc0ncZsMqmBShpZiXiYvz616ipLkTtEFfavUMQuQm2dzcK8v5njzKh
ASA0ttkP9cQ4aFOgj4QfsZY7GejBg5SZ1ka+p5brqIk4Og5vUuldi2MXlei=