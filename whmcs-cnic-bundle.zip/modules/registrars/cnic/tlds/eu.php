<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy89qguMrIQ1xxb7ZIKlABVn8zyrZNgxO/s5/XmxrTWjdJyL4aE7KkDpsf/Poqg8zyL+mtb7
/drjhUC70HwrBII7eGW9a9d7fFWTZniwbYb/TxQW2rcStmGLCuIPNx1rhRd0HI2BDMHBoT2V3fAy
V7px/J+mZyvOoY4ucrR1/ljVwigQRvX+THsSPKfrb4RiGCgFHccGX1czKWNq/fjCdRyo3Xlopyak
tCNKxH0aitIQNDuUwmdbK3Uu8ciOMHozIyIHQlK/cQ9+BasLC4HmKEQIKNCTQNtGmkmPIKaEnR4w
RLrdKPwL3/QdfdRhp2pPQxKLGIGCnstgE9/RSxwQOtZHavZsgzEcM4AyVE8gA2QHU1XyztPhRVbi
mo+0elS2oP6dLfOp905pw/nqYKcc/FUZhaiiRpcema8d2wLD1pFkphX7WY3JaTx3JQM9oTiVT/QT
gv82wlVLdAmDjKWIpN2jeQJ3TvbbILdlEWgnSDI7tKrv7NLKlnVvxAYiVIgc3EeBm94/P63QdDl4
V3XzgUVwGCoiKqcbxib294S9ql0U600HVXKgJ5+CdbIIfWrJ0f4Mrs3M+6XwZdTR1roq0KV71TXd
cbKVLssE40yNYTh9OvOYWs9zDOZAd2ixsOVJ/CUP634uPN5dHEYAV1xcJ9ZmIlkx3RgTo/nR0MOb
BKwsQp7vSJPWDOCciCx6gPu2CZ4uFfGfovVR98rWVq+6istZt+p/1HX48EJkh2P+X/4Q7MtfRCG0
Mw8zxZ6pTnRIV8/DqwFO2PRtbPH5r9O8caO0d2UViZPCULZOPyMh/emaEEJaIL+9dEwOVKFaRyUy
b4dt4aeMfeDq0H3vnuGxD5FikrGa0WRZqFaORzvcSm3BX/hKX8+NN4pQtR4QawwTw90bKVfHerzz
ceBJ8JMnzxJvS9FhJ8XLhrhqEhs9iwOprf4ClJ8ZNxZg1KwLnFS7d+m2iUBbJoBFMD5EhiTE0TLt
0B60BwQ9BvRSHQhMZ3X0NeeJS/2nS76jWrBWw7ZZLij5BAFBAdQd+dyiaoPNn3t+RAgTMr3drcDz
hVJAlUw1KsVDHRz4Wqt+RIw1KkRBnPZsUhuNyqNbzPNxbg9VQysxRuUyl73iGmG4DSqObENP5sBU
GyGRcm9hZzzyVOAgKL70xyWPjBDSqLW0QxXCJB84UAePfcR5IUJvYi7rSYDeO1HH/2GbzapkG6NN
If51x443vbH43wUDlItRrQg15GjtW7DLTbVRVbwr3IBca95GvHrhnuOA2gNzWgMdvzp0so51kwmr
bNEbUKH5rUTRUHDP5wcZqc8sdLk7Nam2uFxGEVGMLmtJsJHqbxbtQhOa4EY3H0A3neJ/FpGDcMHW
XatkaaE3vUKZXFI/1FFPH6aKUopP2yOC8VA4j3YfXZ7fC7aJxGnvHK+B4jLTyCQviwAhDA0=