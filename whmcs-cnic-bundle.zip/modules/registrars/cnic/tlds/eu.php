<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr0WzBsG3SsoRP1Xdh0fMXCiWcGnYlyvBfcuSuYw7uWH6Z/DJbTww1R1gkRxyVGMpZKoYEh+
o2PJ9r8n48NtlY/b4acwtigH3dZ2OkmSZDdTf3lyfQd2+2vpLhJY0HiK/gJ4IduXFnlEpZYbJC0+
wBMRtryp6O9Um65mLLsScxqgg1baI88h1dxm0dTMbQHG+i/t84fxU/3oi93dkXfZN0pDMKbLuIYr
NCQelbpPbCi69cOrOUxJ9Y7Yhq+foAsQQB+dNazPctGn2vxb75HMiM0PiQ5eBZYx4cFhs7/W4TQM
0mTZ/xHscfLATJqj0QCiVghlH7gIIfwvBR4Z6y3hPl+IRaIaSIA7eBWGDC/XRPH7LXX6QvO+ScX1
JtH2yfBodmWc3GOssDieKmdHTAaFdxLjmf3Zkj2pt5trQFhpvsjTgFtO3Su4MUduSXyCTXNrHdX3
r91gfosMnDPuvGT1j9qHjzKdxe1YCf8lc6OgwCm7FJspGWdKJkqdmdrr8vCqXsH+eq3dJuxkImqj
eKOIcGvYhnsNMVRY0O71C9DKFmUwavN419bQBXSZPOqJJOYH86ghmNDDBg2vaKUnnwV/HilnylRu
PJFxAT0g9113y5XaTS5BulHHC9bsnDGLha2ns5OgX4V/8YUnjJtW+oIVnJT3Xza1uqEJy2Awl4bR
Mkj3dNSdgkKLIIEfw8se2vdv+cNqFrCQID4YH+ojhh3P4MFnT+p93YIueAiT7M0fSy8WzAz44DOO
Xoml588mHfNjL0/RscwjlBfw32MEbNLJxPjrsxSOwLottOfJw6iJqaJ+xYVL7DqAZS+6fbUDHQ0D
YifOVygCeEMD5a/+oN+eMRZJZVDLf0r0z/dRMFvBO2c8oMw9fuji09giWMYNnMtoj5lrS3Bjgj/H
ZmQQpgB5lKCLLSUHZsXh3gf6lrvGhhl7+eX4o8W0I5iz9VxtHaugTOp2AIEPqsu09d7gLnJxg5XR
WZuZLe+ROVh3/HID1LkrFoX3fc4Avf1MJi4mAD5BvM7968n+yz5Bac0RmevkjJX1kJzB0965xE2T
j/sTZR7SdRbDU1HUuzxjBfLKDawPKxl/dBOLQp0uooBPdmQA0Px2QXIhq3Ca7/XwwIQgdnY0DP1v
1+UHiEGVpQ6cu3byraT7B8tjFl121ihq+5f361rbNtne19O/E6zrwt1Bq9YhSp+gWGrxxhGtuBik
FNQFP/AorVwB0bva/1QBBv3QJAl3uk/ehCJysYKpgECpeF9A2XB0tfUOJWQGT2oae3Fv6CYEKa5N
Ldo9VjY1THlqxbjEakBRhHviOKb+6J7ML3VQ99VtmIK9+ZXDD3Z4O8bDbWYt6lQZ99XZ0WLEY+HL
ljaXu+RvvvpPe8K09zgMY+TfgQVCKp3HJ3BCu6VFIq6+Vf/R00==