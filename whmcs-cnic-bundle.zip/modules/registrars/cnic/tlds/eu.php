<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxULsuFpUI2qYYLEe3XG7AqHmfz+++Jv+F9ah4IVoTgylCfHlgqei9cvVBQZVR2oh0H4yegV
Joa3YDxqMW+zkOa1mx8JTfSSKy1xJGhgkwkO3QUfudTK32opTaiWWC/bOcpF8OLD3TIzoZPpbbwv
bnhKsmHu/hR3CLgkbje91QDJAjEpObjmrw+JHvqMknungrKAV/ZtnZNadwTBsmkr3H7Jp0e78SR+
xf/QPSE+2AUtlfEX5bYA1InBkhbj/Kq6FTJU41wiyuZgqoK2UuO7P9oSIreQR5KzxSjw6Y5sd6JO
PnV78l+fboY3ILIf+aly18+6g0JKmfrVIGa+UD0PG6II0xapyuImqb8ncqL1kBfI3pNrDwJdJpX8
uoYLjbYa8f1Eecjc3FGDbofMHxX4h5JmuGaIjtMw16kCMUBqlXm+jVM4yEXdNqb1r5e1Vwq+MtbO
dIpi3h2ZApuH4sAI3xteghnjDu0B0NPg3UzqUFs81I6ZLx0uqdxdSN3evwKUfKC62CTAYICs6Rrz
kC43MNcdz1C7ya7k53LCY37NwWZwAM8LV79ORe55mmHh0SA+AvUwvM/XqarunauBjJ2ufPk6AJG0
oQwZ2AuOnta7UstVSwkhGk09ZXlO/zh63ohEPwrjh0DFOUwr2IAUnKmlhP2/x4469XqP1o+ZGBsk
Kvwfp4PYh7l6lI+xqIQB6jcBpoP085UebcKpS7ebnP0NkFSYJmJHmXmkC5FLgOXo1sUhlMvbBAON
LmiBUPBTsbwhwrWIjFAcGMwF9r2T9luTiSAx8vJC8TVQj5dmmwECCLqUUOwYJBc+cgNc/U4Yk4wy
yxCtJlb6V13kpPO44O9wJxEExYI3ygN7lvh2rc4G1GqCh8DLLGzknJXn0hW2a+litt1O/6WH7u3x
MIXvGQ9LpYvLjWBlSTuEzo3sZaQxCSBMg91xBGhkjrvSe6i7pqZetfrNUMcdfaFxtXjmDhvgQ5Wb
EGGQ6XQadpJ/W5XkGoDITnIOmWDCzNGZICbcsPJXBgznPmgo6aa0kuqb8wrWadcAPMMaYZKqaSXi
dd1sxVw5WAcB6Uqkm0uL/bXNfcmH4GnPKoSNItzWooh4JkOXOilyapl60oRgIAKNeQQtQKc4JqnP
90jXb93AENKWygxqaFvbB+xLfWiZwwUDSOLdQzy5DnQrAYqW25ib0HT79cJrghqVc0parJ+rL+h3
o67RVNIsS3L/0QlORE6HwxJHwD2rz+QXGsDP3n8qlUdaWpUk45idYekaj7oIRm2Npa0ASgTZbRPh
7v9B6exkfCCzHPb+MgeYINaz4iiCyZ1OtbE56pc1zmArBiYb73EcCNNQbQ83hlXAU3efTN/iS3Du
YaD1xf7ql24vj6/GyLzk6HtZ+Udr1dAeDUtwqyr15VEeFubY60==