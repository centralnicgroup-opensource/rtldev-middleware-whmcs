<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoflzrtFiykIbjzYVXUHggaYVMEgUUw/eBsuBPfKZ3825TQaZziFPFuNHQi6W3M28GMb55sl
irlW6OkcZGghMffR2IxGTt9E4BK4tBV5SrVgw2PWPx6PKqO/kwEkmpIdXBd5JJ5VgqMwhUrxJlj3
HVBpIBK14+7z/9ye7wcB7jwdxl1pXSr2zpxtO+mYqgZtL9k8+9FwVxvUYXT8B21wFgdX6xtHAtAC
EVfPD+E41MNz/bl+WhCkGO48DErx+yW6QakEhLmNTQBmEO+CXpAnqZy6GCrgczWFse8dVn87rixt
b+T//sK84+5yEbZm557h0n3us9ngfJ6hB+KKELmlI7RJRpvzIKcW4wDtlOnPCd0Q1uDegm4EydV6
P79Q1/z9CfAam3uj2RQXFczxUw94qaEh+sGrBExw+6yiltveBhMN9U4hTWnMxOnO48lYXytWButI
m8Ducft7BBN/Q3XAQCg+oXVJP5SqXNDD4r61VEKl8H9a6hhUm34/4/ViuU4KQjzA6L9DL/M9trM0
MlzaRi0Pv1HIiBAOi7IM7KTU9/6HMfYmPPHzLfTosMTcaJK3Q7xkKexJqCsgsEszyqOxptf1GGQJ
O4Hdp++IQLwFWERRHdRGpXdskCh5p3kJmeWkJIczM1DfWttpfMSkEkx9mDvrWeb07squq+HysDtQ
zU/nqjxEAmKm90GgbBmAU1BWf9tthW15REHDviE/kdHuUDTxKlTU91Ntiafq98Cajf3fIPxMBNUt
KCv0bbyMPnyv9VzIoI1vzWHMN1+HIogoazzBbNy1Ch3w72xkwCuVHLLAmW+UP4kR2iNr4cgsQa1H
Eyz7stReyo/CP28XE5zwj87w8u1EhREEyONEaPACFUO9q5YPT87N4nh9johnqYgq95hAZ7SPK8t3
X1VHsm4vCmdEFa7NDkaNohWnSVEFK9nea/P6cx7rHRnQrCMLdHFPy8sBAnq+1AP9EXlmRyP0zvvo
1eTZ3wz20hJG4bSQN4NxmczGEafBWZaBHIdiLtOj6MwSmIEikrkA3lJ/wRN98kfw2qSL0kKqoXaW
o2nfjXz6cJJqDuwJoCX4xWZO+FUi9Akz5y2nbWdHXWoDtRafohQIwxThQ/T9kzlrd4Pxz71B/XUB
qP7150dqz5ffbMu+SKrgn6dIduFVe5dMDJfvKVTmNYc8FRvL28raN1ywlZJ0EP5JdwTqjRsiFo9e
79+b7KAXRnc2NmavWEMfNL+pg5S3qm==