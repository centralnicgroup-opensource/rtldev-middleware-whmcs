<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpezy7D/0Sb41erbKCb/k8LuyTSHabetb+r5HjfHM+kT4hcu3G67C7BZ+RJp78Hp5Dr5sv9A
MGUOTuhjiPBh0pW9/bhbmX0vFfDLKIVZodgN0K2rJzV3h/lYRVQLxvJXZd9xh/wix1hkVUTLyItR
akIdnhx6vINXRuUuStJt2HX8GKLHNmMJuHBqfXIYwefMGfeMeDFshlA3GjuEsUE+OEDpbYr4FuER
UGFqpzzhv6xyWrFdR2fMUklqGNNOHf64ZbX82nfyttnR8lj43fqn+qAsEbMuRcgh0sF96w381AxD
WJa6I/zJAtpsloFf/XM8GCp4D2zaH3JdzFUfwS3cNPp92GjiiS8H7zpqCA8EILVxYrHsR3e1X2dE
hy4sQCmnyiw5V8/sKmXSrcUV1p3zsz1jtg5DeAOL87XyP8xcEizQctRz03tQGrPBh6KTFoUdBTFY
t53reMcCj2+qlMVtGFOxY5HHnexElEu+X1Zi0T0Djzkn3qxq2POI57BiN/fZWR1jWBsUZx6cR3e9
GHFWbuF+1HVaPjUSOJ5Ojvs8QbFjLLyj5f+LmSr6UFTbnsfOXPg4JazHrgwKvoCBpqsBQ+kta8VM
L+H0Y9LBjcIeGtlMmYAsWDQdCKx4q+neFdxQGKsdNZyz/tnTE3L4X1XKy4IbA1D/+Mje0pxFYI0I
J1foiuQztL7cCQdb5lDPKhXlycpL8NlUwNB4t63xmTcGrSGnutTilFtSR0GX8AkYysByp7YZaaCo
dmKu4nhp+Uw/mUExtFk+bAN2rqHtr2z/fHd76m3elP9DXM9PCpr1cqZd4820YZXnLQqRmV0bAZZt
r9mM6D+TrhQbcjmlqXyBSzFkoqJ4u40sJHrgsISMgyTmoGCV14BmaLxHY+PSqe8ESB4i7t6K66pQ
BYf5xsSkrVhUcpGD23x/ZJAiSIaJlnP2gT4WM1cZpHURc7lDFucv4BlH0QoMgft1IZVXhsYrTbiH
H8M78HF/Mq6Q+AByc4owHC5BArMErcP4AusF7IvT4ocVyRvRXEO6FWVlIHP4iJLOOQf26ERDL+so
bennj+39Nzxtrvw+Y72IQMmkfiJXb0xOA42xnFrfDlmFZjoJlfTGJ7fwBr5Se3XsB/BPZtWUy5bT
WuPqS7QR+mK1za92pCj62L03Sy+dXEbrXaRn6C9pOE9KYy4U2HIxruzvxhhuL4Qn2v90h4g/aUoa
UzENcVor/P6g4x8vqW0e9LfxxfrkMpWQAZJKHFiZZ/b0sKMlFOpKTwZC2It9tLKSmlHIpoXXZr5w
KL3477LsK2zGVjuB01y+c9tjqBXkY3TQCIYyEIA71amN8JNyxi0aEiwCr9EYHWlSM+Tkq/WKiTkN
EbZyjHu3ynhIi7ipxW02Ux2FlHZ8cW7Jy4FkBVd5WwMVdxx7