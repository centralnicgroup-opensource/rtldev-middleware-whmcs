<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr+EvIxiKDu1wJvm3KjQxp5FtuO+kUu2NzSXo0muCNhddCH18hBWnvhC43AJj5o65Que6+Tv
jU+kN9ZngvOhzYjk2BpFdgSF19X8CtpiS5UajGVtNc0fJ1na3dKPNTlZKaL1WOpVYcOmIC1ztDWD
3XaquExChZ/vqOhVtDeXX+EiAVBr0SnzYLQJE7ahNOHMar6MOW2rVNiWIPB1ks205dyaH2hliFPd
YQiDiJ6TuGpLQSSHhdxxfQywNzBy3RnqmbBEMKYDK1aSaWwd7YL+qQIW3bISPdNBoXzrWphWc8Dr
SSG5TpLoVayrrwi3LqYunREZVgq6eJsAUGQBDjytnJx12k+kDvVMx/7sQF3BY+knmfXvqqtKAX4T
RfSG83eqjX13IjtKovdCm8PH/IIGaqPmh/Nyglz4EWT1CRqOUhZOsTnlbEukHe7jeGYYC1tMTyIb
gY4Z8in8WF5RYZyoQwaRbEeKHoB0KSLeS0E8MxsvnUN35gl4hF4EWk3EUj4LxP9SOViOeViL4ReH
u+nGjzr22e0lNn/KLjfHhMaZVEz6+YPtZhovxRiAX6KSdgV71JUkI/YJb0gZ3IBiRHhzE97Ous0j
uFD2yaQ1Gk4KNJKmBv8Yn2HnAMPNmf/9GDTrzldfBkupdvlz2m5lY/XS0HjdNbpkwa8kuMWbcjYo
lfagdRNDUFibfqW60LvYiJQ5436xsz5LsU2HXvX67itkKNRywPwQhgSzJ/+K05h89pYF/mbfb1Uv
E6/yWVoYWh2j+3Dr/+l9PODgNqu+++RLsKE7rnHIrVe7dALH3SN+trX4Qq5oYEftbtSXj7QoPvYF
C1NFIZgUy7YEEKTbddacKiSTVem3V77s2cnY2nW3ploDBMBFEgXlrZ2JoWFZtZBwC6DuQNUCN9HN
2KqsaJ1bSjW+m+DI8q9AH92y+p/sMRr+SPQLkmf7hYNjjGKxHWEAvRQH7k2JeuJqpCElGZ9v08hd
mc4NuuKMZsaYem2MPdjc/kepRRajk1Ar6fUE8eDI6nGR2p8TmivjmyF69vOwTDvqLf1FgfFx+1jZ
UhvJu93HseH89ABKx+JPu8wFCRnm4aGkvhboG+EEVMfYuy60YeHBBl+njolRzDNMhuBBSJ+05AR9
rVzQNCt0tApVG3ZvbOwf79Q+BZ2VmOdFqG2HTjqr9pzQ/LEWsRpxElXFqckKVyIdVx6oU1MzqCAQ
Ivn2hx03lkWI0UDSe8YaR3xEByEKJooNo/+zkuwpRf2c7BOKRtEX