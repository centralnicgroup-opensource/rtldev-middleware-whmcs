<?php

$extensions['X-EU-REGISTRANT-CITIZENSHIP'] = $params["additionalfields"]["EU Country of Citizenship"];
$extensions['X-EU-ACCEPT-TRUSTEE-TAC'] = "0";
