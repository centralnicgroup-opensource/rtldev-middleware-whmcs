<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwSBykR7ryR9dhjdnUcfHhEPdOIMYDqflvcurt8NXYSY4ZqqatKIuHafLkRMa8jYXLdj6BQy
MaGbR0jkeRzNNMxEb2zRDQ1cr77I/0uDVzST2G1I0Ipwdzd05Hc6Wnhma5u6ItzlOXboj4T8LxFx
jTvKiOPWMJwS8rhGsjf/TPZwgOTH/b+btJrIw0cPGG8NLtk4qotkRNcSnqy1tHBmeAAUAF69l1yu
LCtXEzf1aRowwhC4oDZQnNjRtHe9fH5/fij2gu3L3W3OXwtmeEhzGSlm2TTg47Tod5o/VFMm10QX
YKO9//KDAL6qMjvgtOY601loLCSA/dKD9zvShtBtta4kxiY3mLApa8jxkPbK06+vhZLK8Q3WML4O
ChjFTke+CO8XhGRNllWFRT/Is2MpoF4nvhQaKeh+tVJeNY3EEg+weLcAVWW9JLYOy69uFNYp7DxE
GK/ff8NQa2WTLjwRvjCFkW8GhIY7uD98s0EfqHVbgrav9dNehULdTXHbQJakcUl7+FR9+fb0xhLA
IYQgSaOOV9YnubHBYLAINoct/p/NPGnjfWkFlDMkGP2xTnG9SJM4IiatqkkAE9wUj4h45N3puhUw
s50qlxgjHumgpUgwemX7zu9mHe/yNxtGxmTcy7qmgJCE4wjMvdbIzfWMtfGm9WcJT5dmYxrd+Y5K
K1NZCKjSjmORR4JuINyj1/Ba376eBBe6cADOMWHJt99rjv2dRumShmyja/ieV5xkzyKR5Mi/e/uY
Ih//UGjT+rLKi0lEJg9K5PjtP+V2BPQH5+1jWGzdNL47wARpcNV+5RA8iC+/Q0C6WiJ4L8Z2C1md
180S4affw0hS/HGjwe5EgEu1ow11eFbn4WERNaO/4xW/yeSiCWAJBYs4DTaMAmfZUvqvtVIgaL+7
YejTWZh37S/yRy/Sxjgs4zhOuYV3SMyPAytKhML8FR8dupVUxNTpXy78MKgldaJmzH9n3D9rqEvR
WFUC2/CRIlzZXw+KgnXUbMkUr7AvbgUinQTLsniii/DedAi3B9ivIqVIcsmUk/HO+aalZsQQLqFs
5dLJmHdwQ3dqPNrVtxer50zXakU0MjwRx+aQvGJ7tsPlA8f9w98IlEmTZGmA1HH+RIqQ0nI/IfR5
Q7c7mhD8VY6FgDaZvmxKs5zpJ4E4Sk6Drqps13s0cJEMgIUDLEdL18+bJUJGpg2HQR8CCKTHaNUI
02dk27jJw0o3QNwAMp9Gofdi4/AR2otjcQVMiwX6PTY30kdzy/StvsZ+mY2HW5FMhIcdo7z18Z1M
6s8Ilu3h6mAObBg3OTLCTaVtQXjxQc7CKP2llNF2VQrHIy40DofN4FsEiKH7fNLQMViW2kvEcHiB
7ozs6BVamIazcJ9m2HkUC0YU6ygrv75QP5ArZYaN80PGhy6Z/yIOykK=