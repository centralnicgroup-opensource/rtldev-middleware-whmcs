<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtV5ianAWGTZ4mqdRv4uDMoJSqTdtKCP0kzTaq0OiVaWNknq/28m51QmNEaxFQYWfX0iLL0T
vwTBLZwqrWOhSyWruU/IhH5W+Fr8BEXyJjEB/5lIql8KBc3YusgClLt57xdbUKEYlVRRKQs2Fa6x
mfXh1zr7sUEFXLgAhn7MEHvd89FG2ccnvqac5RlQkXA7cFVfZVuntFgoXwloOFP5yryesNTddHqi
0onV3HqXSHkvNo/ps42VmI4EPN/qjnHv8PEuRlK/cQ9+BasLC4HmKEQIKNEfPi7G7IpkC7NIWSWw
FHb8OoZYjMUI+TYclHWdIXMoaaS61HC5KyW9BC8bKyMgjX12Q0ndhIG8/+/YWoKeIz/qY6uXsXwD
/ph3ZVzC/0ePte0FqDj5/mULHj86D8iV+qd4tC/syFasHf+OaLQsnIjfKBzcjW/3rC2xbV1ljUvh
PsmEazq9tGbWE8Z+OIMhFWVU28m0Ta6AXU1nJyLzRuOI4/CAxgegWhh7v4BtUX0M5ygoWUraP2CP
kcv5i+WzHOCoQ0cknbR+upO14xg5gvg+Ux9pj0qURayHoWjjNuGB/pquDRLSQrn6pKaVB/SSQLB+
j5jmQ8ZEffy+9GS6MT/+mDWIjqgi5sk/y4o+2mwfpOipbb3pToC0jLL+/rZVJo5K+RRlgPYJu8Yf
i2HZkq7JyEtAbZYcP9qvJVcSJdkEyB+MCD02CqvQ8BA8kNNJ53kD6wp80mbQtzdo5Gfbe0NR4kld
QQDoTqWGDb+lyL4E/dbevIY2uNN92ld3hLN1YeBvz8XNSnJAZ+VUx0mPXEEB1FF+alew6m8M1UB4
fhn6O64bQ+HAjuYRZETkSBGNYOpjRUNGFshKWGhY0mhGPmJKwCkZsnnZJYD37F5mT9MBjqWS5k5k
/DmvhrI1Otn1o69V2ZDPcdPOMTn/vTxzu431953dfXMvLqfp+BNXsVLll3NTPwPtnju7srsISvQp
2T/rDxjujVW1DrCnu5l/tFGPYdg/hPX2069ypKY2Qg4rqFNg8cpL6uFizr8l4ODzL/XXScaifL+g
N47868Ca3ga/2LTbNQ+mf9DmKCfh3ept7pfiqqQw1eQAFs/Ih+Q51sw3oWynqWLsOdmZzyKZZ60e
vSewBseqUepAtf/6xRtiB+PW8ux9kmGWIJ0VaoXCzlFAY5gdgJFUP+iVxrjKcIMMkURd0FNbg5TN
O4nKBm+MQmKl0PU7TOm4cG4zyXj3G49vuP+ySIXf0q0l4kx2oNs4x3rBc8hcbHYr2lx1TrVLW1mu
s+2xDkzrb7OJLspe0GXq9nF/lnBUh1I/C03qVqZRBPvp11SNPMhosJAqV/+x+L2HWbXcu3fYpbOz
VZ/pKBEDPg6aSOzM0/cXXaoBKr+qxFYZXamYi9xj5RkohRp9Atss8GVEHvXzcJOuJ9zf/LVZneOY
+sXY1DZN9rm+EID8g45MvcUsRgFGq6IsP5ozQRtiB+a7fNZ01TEiHvC7YThZEwNaLx4Bet7urJ5m
zYMGi9kIyZ7/AmSfTg1vBBb0re56erzbhSdoDX0K1evy0oEFhSxXFof/LFxuTw0TwbK51SV4N26y
OvbxVzIWvxgQW2faGXpt3fx1W73B1qcDUIwjynQVYqFScFllS4aJuOvAhiH3w734XdGMZI4lxMlc
Tm2c+pSx1NG+PK3nWKjWalNKSDZiU6IiFammoEUl8BsdA9da7x/O0Y2vfYNsiMUhWBbDogvVrd2D
lKAxXs1zRdHT+G/g2Z32qp9eQ0cY1vmvIA35uNDqoqo1Jj1nv/2877vZBXIVTtvliqQpzIX6rGue
9kecpT0XxVGbllZsKgnRO/GtFTtf3CdKYNA5GdPyPoKCoEHRjLitaZyja/+cvN9fW8OgR6L+GCM+
ppM1bsN6p/mvsn23kQygFqFJvMi5ryg6CROZJVHXonc2XwU4y+BLM8RTtFI4XFcvojrThn7R4Wy7
/6OFJ9XtXvQsWaP0lqBYuCKFLW25xVOWNXxXyT580RUY3+vp+CKmbYSn6yMqfIG85OXDJZaAd524
97H6BXlrTxkWYf8+WG9Bvf5Vh65uZhVZeOIFt+coCQ3omLKcJlWoZ6k9aZJIHub2U5SZ81uSDLks
TbtwbMLB/5Q+L4j0RXyPyfH23m/jWnq4mrAa77sJMO3uNPgFFXjM/tcvalBAqRqhfcneYExj6HQB
JU10qYp6v7IdEg8A89y7jrz+pet7nm/liNSVLNfGk82ZXO9qjMJtrSjQtr6ex2LaZmc3eQNOHfjE
5nFwgEzXIUWHjR2RnoT8hv0UIvEbCHkHwiAg52aX0LArTe/1mSOVywy5UyfD3d9vYc14npqaakAn
3x1BDVcbepFQBjl9GAJ7ddRMuggnJovMvcMb2WIUMFyx9BkOqBgmyjE04476hFbbK2TgnbUbmGLg
zxFzK0llm2WRnK6ux8nwAcYiFbXZpxQXD93KNccSzy7qG/+BPu9/9GTv6z3Wmq71+T98djcltTPt
RyjLq1X6IVKUsyPvsgUeMFI2uKdrXsp/V1SCaje6nPaXE3Ip3IL7N25Ey4nM3j57098YCdyvaXSh
IvjEJQOBn1XYc//LtV1l9GXvT7nAMdtrK5QDa8otoNFtLWoecK+lm/b/Ns56jmnL9/r8pYt8wOcW
zC98xTMxWVEwGow+uIdhESzxfcTHU6pQykr4fR9RoNoQ2S3KiPKzZlZfIN3jgKOGWavIcYmNjwIS
6ia8htXhoyH280PQXeuzSuRt2g50ovRiNOuJxFdJRv8cjRCzhGxsFWWUoiLmxWQR9QaCLRUhUE0m
8K+qBjTu7hOardeDfg3IPh/+SgDDM8XuKAHnJZMVFtxBmE17iEqMX9xnPeG/DZNTnDq/uwZjlFOh
lq3VM2paEkemDU3wzwvNkMFlpy4CSSg49dg0+kKxOUBSpR+tVleMefmfVDqmwCL3dYIAKBTyIkaA
qRaaMKV3D/M8vcTFaqWihWXYHxgWlblOV+zhA081SsQ3cxSb/CK9uDKwBtXyendYW1RvKPmZL3It
QOiVEhpjcLriCjhD96u6ZOI2OUAh4pG/bAvsOq0VOD3UV2GNdrYUw/glqfw7ulDsw2jusilOoOEq
kGI4zWPSKNMG9QgTctpuGl3Ow/vBIzUhvXELhe6PC2t9tNpyZ/D8cPqGiWL3HRo7lLGdiVLh1x57
kywhniEV14YH5jhVjBR++lxRUi5VcifU7+qGPNaZ9yphRZcgOF/y+Zw6Jq+AswdY7MqOMtFtKJ20
g1iIJy+kYoIqVsh37GVvNFksgr7DReJNhJXAn44Qk8Cze0aKk54jcX2XbMU1bl9hqbVAv30Ie3Lu
69GKBjZprP6N+cebKy62pK59VHfHcSPxEUZLu6JbVOVJyf87YHEc7Zvx79lMcgd8hv9Yq8LsqY6d
WZg06biTnUYWZrnn4/zQvNnIIhXNQKrI/A5rPUTud73NJpfaLJw2EHPxdE9DtqfjQs6ljkFzUwT2
ED1WDKhTfsiflxOdRFkUA9cq+RtMdpkIo4Xsk4MX/R2bvJVsgeA1AjrseWQtb5Jo9QSFgHVTCYBw
+RqcL6FdRtJaQKu5+pwd01nqfiO0oIKbSAk2cwGTnnhuSUCVHNcmeGfsOavBZZ6RRjtUOzkqQAeD
dscO+LsEP/okO1Y45o71E10uzVMWQopxKnUvkzJjjOy9JgzjJHYjrWWEH5UJA0qspbttjsmFA41v
RLT8agxrB0He14U2HISKIMBIYgHdNGN8rzxN1ySsm1E+VmJ2afsb4oXQvVjF89AwcZfxiA5Vnfme
7vja7KkC+y4il4QMKzMtY6Vu+BEeCgqx0FupPDCK6mRqiToyqp3moXmBn4Bglx9BNndaEPQfp7yI
rDb0nv3d+RUP4bmvQPA9kZcKeLb11VZ1c5U4WDjm1qlVL7EDby3Jg7HbpLAfjGdMZRQoFkAUO++t
bm9QhDWqvWP7X8e+CfL6pWbQY4UPpkBg2KcVLRe+xACI284pTnNbBoAyxmuaGCUCcH7BhNFm/Ecc
S8B571hoT05oUJXKRxkTEhgUy4JDbJ+9Kuv03X7M9JlydF16E0HJxSuaQoogMPHSVW==