<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvgBDsFaNunKyKEYG8VIbUTy0oxWC7HVFOwuD5ovLA7g7WtSziJl5scg3nNNhpS0yYYR9LVU
k4Yr9099AmqvQA2goFkJbIXLXawphTIpQMiwqpQqWdgCVlZNbQe7IJDoPwIH+MCAkdGSpg6gS1g8
Q9JQ3KvePrOzJOfK6X1J7DrUxusGbWDEfH2wVy7qfFdrl3+FSDH+xll+8nm9E2x1wrpZN8O+xN4m
LntbnPpn99Lmixmf1cRJ8CuRQBBwsbDE7hXu6dpVV5iY+qGEdJ7xGhOwLMXcRoC3KTXZJGtNmyrn
4IT2iIbw3EZxIySH4tMPwUQ8iYDzARKJO4Ay+FwqEX/aS+YY7byHZsldhUjzJUR/1ZvKx+2CmV6y
iWZIeGNC2zXdjyNjRn0mtSSrmRb7P1v2xzUxthsKEQ4o98LHO2SAx0GhIcjvXbowl9d7f3ZvBHll
3oemAPHKkVHjPrc5sk2UX7qjjVGY6YfUfTD35I791UAH07Vqw/UFm3ZVoTdt50ya+KnSz377KYcO
UG2x0m5rmQqi1e9fR4sEMxMQv2NV6zE32fWpXI8pSpw3Zu2i6mnJyOiO4UWdV5Jw/OmOEI34fMhG
QEYkq+Osat9wWDi+gC60ncPZa1Kkdb27wmGd3zwNwVsCcMl/nAy91sqFWiFd+mGSLFwaeHcTGkaS
HdRstNcS+sjLVWB85AtqoMrn8B2mMNOix1aHQqIt7E5zhznnUDCuwno3cFHvosUJ7/bCXkIi2RIx
khN8yV/HZs0Re4UnMUMIUrRosDzl068YgCFiGVWKVM+r0Ey/YPP2gPNneiETaDWqsm7fbeu+h27M
UUf8aqy9GPP3rl16zUIT9QxSSsqqhINKqyR4luwoizJlGO7muqXc/xx+AStX//3XLzA5YHaIxtou
/fj3vkpaVo57jWAIVNVwI4stHb29RrIQOp1dfICOjNud/zJ3Fa8KrO9fPzRkrbpZn3xpra4tDDgs
tmJanD1q3/+U3vnKHFPrUTzmz1k0ey7enYW72h7CPqMo7rz9jAQfAKrZlX2ldq9QeweYG0nIA/NM
YFATM87oOFWZalh3CNJKSqSN4mCAAbv9YkdzAykw3l91wF5hO4743R1X+NYyj+Ezjwq0QbFerdWa
3/c/5MRmSTUIbBXvvrWvtbvtU7AHEyY7vQUi45tLutTOqliIRRQ3meRzEVuUoYGcpCua2d4Leu0t
da2EIX5QVLe3Nb4AMT5SJSi9QtHI9ctzbDJiIsGEdBPHyOfd0oc0sVPobDn5VhtN3KTQ0J6pAC88
wDivVG261FNbDXhvWwG4WHPqkgklO51K9NeC83O2scom1rSA8m8Pj1xaJ2v2UEUcASfnNJXHww2H
YRM7lB9CgnoXD+yRxE+4Yfq2sv+JkDBajfAO+QukQ9mM8MYaxlzbLqtw30Hr3DtcYv/MxWktKmPm
vtDoCDHIcdfyi0AlRQblLlIVDE0F7GKsc7VH05FQAdeYe0JYa/7KVLewLSurgvb4WgS6oc3fD+Ys
a/gE+Wx6yPy+9cCOHstvn8uEmtaONZhCbtJOGFhSSgL4Pt7IKsCxDmC5gmj8sMHXkncfuxMrxQhY
MHaexL5yy/eNws4LsZFHA3kg7kon/ssDfqkyNZ1ZjFHRM33nQ94AZJkPxlr+Hbs7p75d/xOGpc9d
V+heaAvBHVZM6Yytp2KCTbHlgAaNJB4Zd39ZNZ8ZCUAo/6d2WxqggwGgt2zSAoGr0Idsn0ICn/uc
ZpkUZ2giMD9nAe+JKOWRN+u1Xb2BOi/Y9LgQ9kANBBDM/DlcHWyx5rz0noK11iDe/ktqPxqbGZxP
9ahQPlyXh/dAKzvRrUWfoqWJfrwugnDjkhumH/81Uoq6DMOEzVyDPZzT4Nl81/BAnX1UjWWMlrxs
ysPPg/NW4+kQ94XS7EJaAos42/g9quhV0j2lq7RzAJCt0vfMaO0/FjNUeWoAR7LkfRissAGY/ELL
Px4YAaVcoO9PIhHzMtb2IYIwrZVP080tPHtyjrwZM6jGWZaLxd67WpPYtSV0SqjjjBFs6b9KDU3t
QIH8liP3y8UioMXPA6IZ1ozzPCDwir/my6GL+GB8nu9i+kRhiEJQERdKb9JpAcKn49kpECbUXBvr
ZEvPFnGc3ukJzo6pUiWCUaS9clQpdsOPsmSZcsi6xcIH2Xsc+fIL9oq0vNKOxxmwy0bYgticH6n5
19pdB8e+rJcN3lh+RfnfVAdA1eIGx2uAc5WivbqqJz2KZyYApExVwcRzfXaxmP6+YuQ8KcSQ+Zty
GxK7l9mg4TWdUzE8vRr+d6d8FN7OUWHUGzmbTg5ueJaeqSF/P1ZE6k5+mxCYwTlnUD2GZ4ld+89J
FekOz/6yyXOg1ex/iHhD4vdtz+mZuZZ5LLUFA94IWugaAa5hziGQuoqu54fnlfaTzFWNxzycKQrO
ASRm5/7DUEyuUMFHneahSksYPboRbFYNZDMKuGv8PNYGZbCAlf5ZxUWJTUjiUsijlwfEcFk51LUL
CiNbAtaLlXroI6zG5TEdyR83QwSZTHTetovEDLFgJjh8JPumKiu1P/Y+dYrMsPoxzGiUS4vNMpk3
4+4p8arv8gUpE0dSP71B3Z8mN94IyVERMC5ENS1mLM6N2sCij1NmA6v+QZBYtGI4HvHcxaONtlUO
D2KRmN/Z6Uo2fNgoiLCPIJsChVc3/nWAkd3o1YWHFtJDQfZ5E16rYaGz0+9rYKmo3boBhjUhjpPo
Ldf2f4TpNPZlDhL7zUpssuwpxp06ajtEPENBX4z8o6q04tQm4TA+9dauxLP5qw/UHDVLSHRJbC0p
udyt48Ztjf3HHJFL1l9UiwajOvvdYsx4weK5L6esM0PsQ6dZ8rgH7yktwuJEOYCkApB6ThwN7Tg4
bkOvZE3gUMgT8qEVd5+rjkLhSv8mPHxBOzp7JqlUVbosnmZpqWlvczlebFWR1V+pCtSs1jfLAT3B
D9DyTQo3GI/T7BDxOu3pnYqWVEKZa7f69K+SoAq50SxRrb0kn7gpwZ8lbnjCsxAkPwTIOvRiil0n
GtG3z0b5jC0JRJtEsoAn6buISc4phK+KsqJRCZClQPUhYb6N1js/PA5aInUqTdcGpBumXpHlEA0x
vmV22AYwKs1cD4xBy3XiqXxp7NXKW2bfqicTDMjlV0rOZzk9JDCIHzh4M0BVl5G90gVt0WiSbQdn
ftWuV6YQR1u7XqTQakK4+YOJ5zRYRvIlWS28qbU0PNrEtJTWeaMTvBrRRT23ALreCGZoMkuJgPcQ
u5oT5nvLLsgpFQyFYOm9PxzUj0QxhPwMwV3GFGwWyqnJpwFR2zu9gCFHcfgGtFHWQheu2lACSvyk
+Wud3VAgWbzG/sJe2/TFK9gKqY+7TmgjREIbU4x0nkUDnbJ6MijAUzNxw/RvJupT+a5ccbw3QodT
/MwazfTq/+LL9eJVj5qE1odghckGHAgOsqgZet/saFGSHpGTFVfi0yRsakp7QbObREGGOg5cuph5
gb5HB67d4XO2hqqv5vEv4AoQIT2mtYmBSBUkt7hKp9Ed3iRYKu9jSun5zhzj04S7+yvNWM+m2ISB
y/qaGu8uoM6fFLTzpLe5GljLvKHVsUnujWvEsWIyCuuMvZ51Anp2IbM22NOR/BJ892xlQUuR7W38
uWZh+yRHVuajtaKSgC/9CJTuvAEXHCaWZhJDXHHQ6U6Cw7LyhX3fNxGQhS9mP3GsPLq2vhjMVIu7
CPyDbAVbjMouN0dMho3qWkQO41DhMWSZ4bv7wljcsgNuhKxdzZk9pPUr0TuWJQiOxyt16URvnR2R
gIN9WugSvcG6zDJrMQoXEseVMxva+lMJbRg4PZizAIbm71GrZ77eV3lipCxxU+HbHnWRHMrdob5u
1xeHNycU7DWWQVttVRLx0mcqWF5cKxoRDPU1PawYN+TykhpPpZtxeh5NLzfeS8I3cmH0H8+Hwv0L
jVZzoGEVXgSXHhIXuSDxOwifIGKmDIoL+hj8FkHdDPK0QSIgIu3hUSJMqYAu85QyajfAeEuUykqd
1FB4OoWS9lLIw5mxjEwgnTdXeCc5mmXSS9tRbZhGGzTrCfDF8DYyk5gEbau=