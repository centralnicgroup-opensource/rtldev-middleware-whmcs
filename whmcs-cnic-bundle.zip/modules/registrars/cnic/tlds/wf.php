<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxmQDwm6p8k3tzAYZyggasM6qev5pIwyqVKlKoe9WfD3OvnddtmAGNXo4bclsL+D4sdNI0AG
FoSLa3LqJN5vRiWPOYrG6mjtwoEWY9v20UHMx32WPGKirdkGX7UcGRL0dXRuUbkPuCcR2n4AvqvS
/Uimk7RFCLda32PkUZiixYi0OqCf9UKkm+WIYuwfm6IwsMr8g+S+6PvDZ/TkQWtDOpfRGCOsVCxk
MsKzL5nBZI32LpTUX30/NTXuqi6yrPz+AfpIyPYxr2XaI9Aw0nHvreN5YHDiObi/ELmiZQyVHbHE
qZ28cNLUgzycoMN7OZLHXewdhaXuykFkDvp9X03ON8ddqa9kTBwpz8QopFhtnOx4fZ/7Bx08MxPI
kOqHe2RIhq9Xn/j1ueOtI26Ejg/sx+GMc6a13B25zZDOyHuGDJLfCrTQy4Iv87anYc0fmwoXHalr
Tpqqd1x0OW+q27664FB/YM5avb0CMyu+ZPl5QF2xpUcRPFdT43BTMaVeB0OlT7YYsGYzUlyuTwdP
T5VE5mldtvugJLAMWjpVkz2fAJjW0rt38tsYg6SAEU3L3qCig2cslZqTAN/8MGb9totx1K9oBu5y
2NBBp2w9B6d0MNGsl+yXYGuz4YUMKCFIhHnxXRQ1pK3UTV0J7F+Vol7Gr07R4CRX0zQBE88tiZDN
TxIxxX6KOpzyAS4Hb5UFDtA/gQP1ETOFXn/9hOopJ62d+nwY+JxVzUvkFs+NmjSKw9AnlfuNa8m5
AQBfLd2DXhXv/r7UwhKxhLCA5Hm8EetjiJ2JJ+sDYG6dMA7RFK/9/lhj+xXfGyAMPzo3n4IQQQvL
UDX8Dm3fOQ/xuuhOVlZBGCKSrzN4nA/Z7hy2wiQRXEeZ4IgSNaU2keZ3VMEp3HSKVTghpeZi4b+L
yvl7i7ejrDU90rHKO1tDk4MINwMuWBuOfJP53cO5pUYAejGoh/A7vFAcHQAeoRQPyPfA/3PhAz2K
2NMBmbyDh9qiaSoWKvrDUaiMajPQSuPzqLJvuCDampFWDjLzC6GjR1bjT3iu2l1ambyHcO4qWxvf
QmQMEnDH9oauhDtgnKaGVgmD8WCVOd14ropqYKxaCwmtm8w7rFZJ8SSO6II6l/b0i1s8u+HY4Fwm
dzGp3htnffw34mY6sKaAjizqlykt+a/kK8jYy/qCdhCHu3bogSqnsgUCP5mXa169LhURqVz/Y5MR
GM/3BnDzUEvTAB6JEF7mmtKUFpkhd7G0IxSiZvJ8t5PfdmuHfLRe/0SxfMSPUlq0imwHiWckLopc
TFIAekIbMBkpEK590sjmn6N28fAmoVm8X+52KydpJljD1hL9tQDfC/o1on05nG1vn/cG3c3v3mi+
6tr7xx5gYoMkmuxtzMbcmySaEl9/IF0aFuVqYRL/xI2RJZHGloXvexwlf28YwDAY5MIgOH+ioA8J
Fqdazd6goICrCA6eb1O1rDHFsSDlQBz2O3APmDQJeKaEnocvR1GlrZSTlSKNl06LI5iiCiGjtZNZ
Mdo8ZFsYihG4Vnx+m2WK9AF/xFdcKvcpWmX+QMRYT3cNvwjsj4V0nqGENYhZ0ihPHn/++p0p6Szm
wxE58ZxJjrX3QJiuqhEGEQtL7OzcVddKE4Bskpr8B5lQQHIdRO5zJHfgLLFBWeZzOaUMdvIMGmph
B/uYggRKpW6bCez8xOu/egBg9lzaMPLZLymF5S1Ooy6n1SBj4QTcrO+ESb8X+/EuwHuII26q1gNo
A7UJoQgG9yn9JO7Ob5S0szyb4nYcf2YAY3yFj7bILvpnjiBz900IbCmIpSBjaV5ogJiNW5d5uL/J
or7vcKzkPZS5/A9ydsruWVIRqm4ME+exMn1X7B4B2kD0nz6yRtS6iC2suoMTdrkzmlt8PPJXh/ol
42oWrf4ncdc90XAadB9kcmU7FkZ86N3Zt9yLbJijsxeDkeUD1B2rHPI5f/tjJdgDT8OPNK34gYO8
TlqVkeFSJLGXvr8T12Z80nmKbQizp9V7ZEZBo7qTiJCF640FVdqCjlGwq0A9Vsr25QSqFiVpTnvC
sA05t+wZQjzDEtMLVeAH9s6uSaLXdu9jBhBhYax73dS31u9nxCj+LzppT/7h8ysjlcpu+sv3xJlI
ftNrDXW1Cu1eKyAFSp/zr94Ez8aMj/2l3dST9lzA/Fae31FSL42lmmYEmDY3Y4GLV6cZ3Bkowyew
XzbyXofsLEuGfLNsYYHnlVrwfas3mdO6pFDI8yQZD65Z4gXdJoYKvd3EfStc9tnfJ35NHdcEyTuP
i1w7rcvVjjz6LMiKBEPL/M3ndQgTCaDcZPsuS2Q13JP0QcjDTR4xnnbHPcSMQsYVrVlVKOq3i6M4
Cd9u/uIx8KyqPmiddHbvmAeE5QO3NhRdgrj9Q1IuTu5v+nj+ysVxQB4zfsosOcJyJsSb3x2N9Mqn
mnBjV021l4I2FePy3JXfRwpifNsWWz8rJrWRPo/ejau3n0rlG1eZQ0uKp9jT7vLiXRDf4Rj3ZF2f
kmoAa9vkoiJukcvDQnl3aPAenluR/6vOpDWi21Xz6WNCfm+vwO3CM8l+6+JWE93t5CenxX9veJH/
PanmtJeQkftau98T6vo9+pHey1efEzoDiTFZoJYaB5y0lBUegxokdRR9FJLe0UI6+aZwwdvbuS6M
P5Z1PUlZ0yzijEJx1bKJqYW7Zb+XUnhdj9y6LmNNBwdO1PTwdNeg68gWk9JD++31jglCssJBoxPn
nyjKG582Q1p/TdTR6bBcuERSUpgFJ+ax4ew+c+roWkLvLWW4KAl1m83egZD2Kn/2gWltzdnb6jsi
+T+79FpbvBN9wKvo4iJzXHQsAt0x9/UdWfXwcnKtM3kTIWeZunBBTAwDtXa08ZDDHgFrtGP0TDwH
vlfWoOS+h8L+uxjCrQAvRdqZYRlDZNoPu6e6FLpxa38Mmh9zVoeTaC3+5EKC+on/idKZSURypRqn
A4k5Pifbo0VpMr89+IRbYVoMbtqR/L9g8VnNfBqT2jSTeMZOW0p53fo7fevJx72etn7PnZZuN5nN
msNz3XSq+qfIKseOtjIcOl6Ae2bp/zGpU83Bpaq0a2f0/MyGHF/wmRpXi/zVi9rJImwM2E/hDCx7
yJZQggL9HMorJkuaaxSRRP7C5MLGk4Ebdzr7QEonhdz/LXTiYb29Fvi+7+12TIA5L9+4CJEnDqln
y667OjmnskX3EdU4sWlp/j3GOZZjoLMN7cN9PYzNv+Tor1fEoo2RtZ/yuoeuGRcG5K2oSFTRyTM7
g9T92ci82iyKgmoe33e3fRaJWiQkglOAWMSB+Z6wWfxH3yokid/tSbnPRPhbdUNNtLji/nVoPT5H
9Trfptfcsku50ZO7SzWr+D/eX61trmYeTtSHm0V4VSxeSYB5w+gQW/qvtKrxCDjPAF4Xj9Q9xs+X
jwBfIgIQ2JCe/scnFxAgalrQ+UEb63r+8dWCbJj4q9iD9x5xHtN482/fc1LoSSsqXUmHsRNXAbbl
lnLAKf0+uuxzVVA8IMumUHiIwe94mR8cX2zJZZ1ozLeg5a+cawQMueB3dM9TG0F1daKgJs5V6X9Y
eIVrCMO/WGC2cedZ9HG3UcFOYPkTyEGbLxjhu9/4oTdUwXnLJpcXvlnZ89TbA3GWOl3nOb/fLS3l
0PMXJtwhfTNo4CLK37ffKElXcaueyRRueHugMuaFMqt9mNAkp04dJiKVL3St0WdIcjy0YN0eR2I4
8O9OozN94Pxz6oLzVE+lu1eCwR5gLhmmyfq0YRq0UUQ8eRBD43SuWvwoVZhfvw7IfxkOgR3E/AuT
BMu3UfXktxtaWNMc+twdOLTkbLCZ4ZXlWjQa+rMD18w73WjD2BcNbMEYTeOciIvfcc5s0nD6MkGd
V6DALRcoZTX2UiGNCO/q3p3hFzQwaVyKkEVO4DmtRTGXZBY03f9HxOYqIzjlNa1GgNWar5t4yCp0
NAsHCy79QlzSu5nrSV7UQmQcqcpus9pN+nNwbsfdJ9v6nHR6D6BZp0+NAG6Uri6GfyJZE6mmjMSS
NDDMbPtOfdc7928THKPyJQP29IgjsuRwgz7FA0ovawWzWnqp2giQ2LlM6btZB9cX4f77eG==