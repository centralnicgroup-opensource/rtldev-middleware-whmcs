<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/CBqO39toctbCD4ezHHvAEilbBPKk8eljui2mElsYuEU+UguDHBWrAZOQ4aSqpErLlSgjDp
0/JJljjSYApIznhUa8g8nN77HzmVkvxO3KTe/KgLmOuns0KPSJMIsKKkgo33znre/YxEejEXKd36
8Wbl2U/uU70up/QuSIVyU722vZ6dkaFX8prxcHxN9etPvZe6nniPa4wvjLYqUbfffmk8PesMXBz8
+MOcJAcgKNGINDSkWan1RI34vOGwZYaj1+6aYX+yZYRK/8KGYWXoGEdI70SHcrziYSaZThJUrkUh
EaaXmUT7R1p7mCEm6sK559kotnB6kLcbEIvYgBS5m/Hb8YfZoMa9gdPZI+hbEE20Vb7F+XiITNKH
HXm2x/QSEEGTY88grGEmJ1i0IzXjdhWkMAd6+8MySApbVzIhdrkX8SeFRj/u/oBixZQTmrKaoGzX
iuTKLvBG8G31zdg+2T3R/HEv0LXTmfow57PUB5NvXMFqooovNj/zdlzCYgFhW/mVCsgfNIe86Sg9
TCszfdtOYbnTc55+xAyTTyJQNtIARIBjv0j/skT4m66dy/RqBENmr8icJw5dEnC4P56wkJGRfiQF
THBBZbRsvuOpJmvuxklHZTNRbVgt70JbGJHXWy/RlResI3PnlqB/W/uuMXAsEzjsFqRjNBBDYr8T
wcpfjF8tQeas5IqFWRt8gcjImzkcbpu50MeGY07cUrsPoP22EWqmDmum+hTyLO/GsDDLv3leC5tu
JF8gJZv14jDB08OLaMrNN57gN10NwbpcwhU2f8sptNj6V2iizCGIKU+VH2F7+zyUIruwuKzIj9IS
m5VyOKE0e84AEqA60fx+29CjqelvMV7UhZsI88wwdCQRoAgS17YWUExMIEf0I05FK1gL33+cAQQA
Qu9HzHGXRIMxbAOHNwadYgGteldfIN/+eDXhet8jEju2ISmlVCHzWcEnjE7Vm4zLOeWLLW/p0R4+
VOX4QBPabWyD9WGeW+itXkjz7B+yS9sZTQYf7r5X45DVpi7sYi/vtjp2Y0tpO5wTwblTq5mFQD+b
aG1GTLNomlC1qtYQAS9M9sct7DPAXCFpHyi1y9wk2AXRaAf9WdHJkhKMD4L7QpKcr5KzpUMAbXjc
YHoyO2BbiDE6AekKpvy2ui9Vxly64MWL5DgAtGL1RXsdTKtTtTU+b/BCIjDpTksKQ7WnKTe6Adwi
tFOE3ejwC3wH+1MhbPdEkHg7ThlMpZ/F2gCXGxLWJjruhbqJEzhZu5TSK2t28ggOstx9pKao6Wt0
P2iScV8ukHiwIgGc+ekgPp2t7YEot9OcK4U62gjykZH3jDEONqvNyQNZT2apjStiuJ0xQez3RnPo
KPCGgCKPFP0Tya0rQ5qHsYUdrCiT8HqDDxTFkrAEJAtw1x6xYK+r7WkSoudR0upnvWiAr09alzlw
wAgI/kOlqALT5uboaqQLvNG7EbOFsTmlvE4/1t7V4W1HbLnn5YlC3pJ38ULSK5xF0dLIShI2Qat2
04vJkPlhFaE3xe6WrkHLMOjijh4+ocZIjRsz00CII8r8iNRBWBE5+ID4L0q1EIbJj+QsX1k57CwJ
0mu6Ab4AjxOdZjqtGa+9fSogqlm/cn2MucmkUruOlM/vsu3+E+r3qbyLGfnS8rv1pZQyWNk6ztp5
x+bhZ5BrsCzZ7pZWtGJ8WPi/5QdMw5mlz7Rm4kMsGpbwGoHiNju6Qtyd4Jhyy/th74v7VpeKlmi2
M8NJP3zNQWFrX+3RokASwd3F8uwd/dFaCPVDqgEghE7ErzjnxgmEEi8/PqdnemoLaflqlPw1RNQk
dqlA5kAxU0zAD0ahjV/auoLvsUKYv29a8ub5sdLFZ0gm1CE0FrehkyGC1T35zyGUqZAX1o8326OY
IpsAVYum3EgirTTyIjALJecnHJzjYMq0fgBgzSkiV7DJS9vKG3Sh+QvQUSIymtQEghdEQ8MaMjg8
K9CJ+jo1v+PdeHYxCIWnKScxO/M3eLBEqF/qlu4rFKJeqlxfTemZsFddxLkGI0+H8c8wJCTkF/zw
tN7Sf0iB8Yg9uO6KH9J5eLiOPVHT2idDmtl/sSIwaDfebYUxtT72Svk1gapUD8Ne99WHRlptX5zp
ZkXqwNBzk0i1cXdG9M1isZLkP3LtteIW4h5IekCPFxkXgHyns0FfXKLYeCwvrD1KO7RNA1YnFrtL
fUc8PFfKxGVuMQStAsxHB6nVV5NgPHtuJAYbDpsTrRu64gkOGmxEEs4tHE4Si7chb2Hfi0cfgWT+
BL+dFlDH3mZC/skPtAH7MvvkAsCvzIDFl9Lg2s8S0yxuxkJgKqlT/e4R7cmuPXQISBrT9laFY1L4
7JfPkSUv9Is5kVkeeAAwZoZnU9foRdhgNcvK/sDbfeikL1hkwY6vbReV3mlOeKEegLjvIDNvqroN
e6dLNzPe1uRs2eNGE2jzbLZS8F/wm7DlWP0rEZHG5Cn4Wplj+di9C8sPnNj3FU3liRyfJ6LaGsOt
wHjkP3yNV2Xgut+RRcRuUpSWW1Zod+A2gtIKQHOKy37kfRfWUFWwwwQTJvHouSrgMKiz7pINyKvK
x4L7bC/ALOVqZsuC9smup8cBLttDGiRYS9/gfgvqQlKa75yasA9yAckYGhXg13lr+gFayJX0mDSS
9iWsvV4E4PGkDb5Ejjge6fp5KaxU0RdrNv1awjdFKLwmZ/4D9WmlmJdnPUFBTl3TPS+PzWuj86Ek
0CSgWOZ6mxsQAvME+XThHjSzXQr18DM3HISYc7aAqrclXyt3cnWq/ouFy6gJ3E1SgOU7/DTdhDTP
J6/Ng2ae3+YGb3FC/mBEf4Pt9W8iQTiZuytO3pv4boE5BWRdkB924vR7WAEBv2WYaPzf3SZndiLR
aHKSHArpPcMMilMc2fNwI9vxjRtszF4fI1EGdiLe3HS0aNz4sJ8E3ZSYsbW90IwThAU0it2LK/Ag
vf81WrXpKEkx8J244CwwU+5xZ0ewtlqXHpYD7xRQAdYz8MoWloYlWn6ri8vAZAH++pzwLZxrFj1Q
+cQIaxMaDfXUGZAA4hmse3L472LhJMkL/BbnoosCOca1sAWtx6buevJdA02elyb25GUJsvaBPocI
4XdwsBrXy0zYj2yBiqf5DfMovz9CEde0D/brPjQsSBINmBWj9j2IRtmR1VgretmgcuOK6iOzgNmI
u+uEUQ3H0yXzhJA7ksB+A1SXz4fWeCI2k6ILJMG93UsoQV+eQufma7n6TxnPxM/dgA0MPOxpjd5W
sHu+tcaargYZE4Bp3JU0DYiT/ayG4gdI7fkxZpg2E+cBh3i+4FWh+YriH+d5KsUzfXFHqnluSwZl
tqDbImn0pmp3fbr+keYXy1Ank8y9g0DR4+3pFME6G7T2WNZLaH631rcmy/cmrIeprDNZDN03ERbK
lbPMlcWqQTsGiyuY5sXarf/Tru8hWE1vryGaIUAkyH6Bkp1R5ToiGR5rHWwxKlam3cM7uZlZcy/l
iqfpjxX43tFv4APiJbuTxZrqTbVcuydUaqZUhnrnYCpfzHXq2CdJOx7QTIv1OmAATWBuEO4j2vJX
MfN1FdPbAtPTycAtQwXISe3BUha9AxsTPJ+Rvs96b0K3jd1WfDutsL1PJCnSXX656sQPvKdqdVoJ
T+oo6udtTP9ZATRBrKh+GY+3LmQ72loqSd/5raeTg7ZaZA629NdDYLd6Ll1jRSZoBjgi4pNCRWKn
ZX0wzUOTUHfGl9Xoz5sJCopw8TsmaLWvDHhksalY+rwX1LxOW0bh/5hL596txpAFuG4mt3CwN/EX
yg9N6CfPEkvnwsN3oECdu3Tv7cG8Zb9aH6F1twQ/APi9jRQFto7rlcTzdGoIjeej/aaqywqIJzIO
EKscynbGzBIvoCQ87W5VVPaP35x4bbln9+uaQCnu1fw9H6bvrvF7sJQNg4oSGai8aJvbdLfL2l2G
1sux3YYBhgMbyEDl1g4GMZOYRWgfYDm+74OirVIgk9xlQ/z5E1yze0xgM8UZ0DfCQtK5E1b5D6Ts
uNW6KJ30dfjNhaX/baBrVxxyqaAb1FYAin0MqxwMrjbkd0kwu+KmIqfQ1gQxVLQc