<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtr8HQjF4hwC5e3GYD3uDJtrsMc3mKpnlwkutoXD/Q/HfQrw8zA20UIIlrJfctuHQMztlxUJ
ze8pV50jZvdjp3Z7VEkwQiAoOZasd/GFCLYGLCqEx4CqjXnypYm5DhuxralNv85k6jYs4ipWHGSX
qf+Rt0whvP99308OLZ5fepAswmVSGMFAPYs+IT+qN45cKYVIKO42Vvvhu/78vI0JJCl9dGJ0pqD9
/LZhptXJiDiV2wDH0MTuWhE0C+1s4HOz1bauEPx11iLtV7WoGwx5smpwtQne1wMTvP/zx9CKHi/7
1GTuDYafRUo4GThswzRoj3t5VrinW2pUyODs2U0isQ1fz2/FLY82qcALlZSFV6NOMJNhZOQcaUKX
vfYP5ril7hDq1fxkkOoeFLgNeApL1f89yFsg7SP3cQTnW3uAXCEUBzgTU+JvFvKvwFGXBrk/CBFt
Tgm3Atk2K7nTPIOKb38m7buHHPOPkpuPFHpiv5D/znR/MMv6eLAabxeGR5sWFbggVUL3EhY3J2cY
pzMyzOTkpa6jT9oxBp5kTPRpCRmu+8kT0dgxG4eHg6U+OuJo7ra0R1O/ZfTl2PGiS1c36/PIXvV5
iNtKv/QJ9p/ug2ts6nEEy03X+pekRUd1gP9SxcYfCqTf1NJXX1oXQ0Qz5gXnL8H7HmOdLRPiIemC
pjgkTYFFOSNUn9Z7bhkOLRK7D/w+KghKmxaFXS1dQNVfA3eRSj3dJBul4hxSAEs/W33FVuEJi/cq
O+qjJ/Ng1wdV1sei4dyCpJ9oEjSLP31waTTlgidBUgE/5A2JXcRsWTg3BgRYqBgyc+N//yl8XdnN
73L9t6sI/R7xbrZ6XSWsDyMTEgg4+CSSvchWoYAS1IbTOR0M/f6lJfX29BJnCIFX6NEoiOCEDQGD
3m38v5RqfWqVJOT5dU7G2DZVpTGh/HUZIaw394hlsNUO2ZMoiEe1/OVTRw5kwQr9RgFMcmwkAgwt
LrdzVXVj7vBOZLnyKwLZ1IV5ArAjlpdasPqrxifhQuUxLwWdjvQLK7hg0drOhyp67oVdv3PmrSj+
QTPLllRpTDu5dBAKptTdeSerivO/szjYiuvrIgQLMPnqVGxoBgHOJmDz6H45ujvphB0bUSI4NdOn
bBdPIVS/IJbZmAmkdgeKAORMIgMeGaZfC9/Aq74MlW7VlQ43uTWEhotl4/Aw8fXL5n+6y++4xT1B
+LUYu9nmSLkJ8IfPPnVOY9Hx3WngT1mq8cjhCeEvvRlLfxcVkoIbvXR6sk8LaazAECFW+gwasQPy
p5F1ys/y4Ykz9T37GdooBfRyKV0vr9qPXMhOq/H5sUEJkaf1Fd/sJouJkiKCSWVQ49/30RmbwZPO
C+sckqTwOxk+1GdU0NHEwLo/kuzO22XfJuv8xZI1msHphIPjdSiL4hPODgSRtdY44vtDuoUKciim
i3hxSRrAiK5Tl2yO++TwytNqILUHfg1KEvqJ3Zf0ujSD7+VR8callsn8Xjr/FeoJOOpPR3HmTvBt
30ZIfHadVMbra2Gf9W2jQpc4P5En2WXroIoTwGEmzfrh6gTbTDvR74gtpaGEw0bRVg6nZSo/cBOS
RHUqf+IMAnuzNsfQDTE6UDbJhdlwacbarvU9MWlv26AlX+uILytmhimwsy+x5uKBjZ2KOqhSY/T3
I/z3c2glHxPxZukx+eAgObH7iJk2Ugo2FTMIDp9eeYcVyzZYLdq2Jt/jt57RkwAbT6gkkkEDf2Qx
bJvptT0H2O6eJmTi0T+rG8xKJWC44uHLcetGNbv9MK0iUHBSE/OQs+CVpTZlRPY07MFSNUKo3fxH
DHVbQb9BRW62bupOq9zae+soWhiTY2/LqKRz2KECsa2+DjgX4fiHR7mTAZ1om72i53Ue2IUFEWn9
AagS2ipzIqOLcHxq0HLOamf6m1Yk7IqCYHYQGLFbULGV2LzYs/VYj0z0IxUrkz4nGC/ok9I1sVhQ
wToOLQsRpb/pJGUlDfsrpAspE8CG9plE42oXtNqeRQPm8n0HVBa11QEV5F8ob+xITeJ39KQefXe6
ViJ9SUflqm7kznBAUmz80B5ZqTbJMUT77wkPgsC4ORrN7LsnAGx2tO5amJOIbHn6HXHfVlX1Sa01
1MdOhTOWxSchXL1zk78geKljGH5JLdxURNG0LbpOuxx47rKuOWuXHowWzEbhWL53kMTA3rCWMe5y
cZUddviAjQYgWBwrYKVexyILWRdIdGzHbALBXaRZdtPJlXe98VNbV1PD7LEfUSjyLUA4HI9xH4Da
aa+OQUXW0XCUJPijASjMjOKmOcKdhfXWH93W4/qsssrFRZU61KbTHcfOoP5/BnWrIwLUzr8Dy5OJ
HB7XKYzml9xPKF6uZtnzVVqeNaDHF+cdNT8X/mEjCOwyGJSDE4mbmhLb0rDnitU49eQ8Tont/+8r
uw2IHZASPmeM3p+CoB8OT40P8DIngXPJahsAtBRrPCUFooCf4ozk2wCHVpUwN1UgPAqcXNQFxLr8
uBh79aB9yaEfThCKCINFMky98s8iv5VWiUkEy+5XGMkHVeyzDrgh6bFx956v1OhpnFRwnC9pEdxK
0leueczFW7IQjuK0j3Glvzkak5NYf1TX2rV9HxZnTPS8adCQaaiBGPGMSq8sRIR27F7k1rv7EOsH
KPG8M+FPQjiKPejLFXZffBmn9iAuinxppvaJVik0VG2UOa3pwb4leAqul+UIq7+xHUbK6QEeqrHz
Phi3C240qON3D7/SfxRwqM77Tqy5d7aq7Jl020hPKikY7Anni7GMun4u/PdD6WpDhVvJ0IEVgRKN
2JNFBNFCyCPUwBL4n3JSSa1qY1ySgoWeJ8G2nMtaHfZrEToRoOsMzTC/QhiV2qiQbdx4CcrqlYAU
g1u20oZyMjdKocEKr3s166/4vj8O4rFNm36n1sgF/wQzWvGqjvH1llScDKxtAwHz1z6MozJocxR/
gY4jWunixGz0FmV1yTFEv8Tyva4rXzf8ZJaxFdQUSFEZErp0wqdHiNNiWUDYUJPB4HoBI1/8cRUa
gBKsxfg+4ipdBrdl6zuHmt60p4BmkUDz+5aiz3dTCF+8db3rPCvsyTk0Low3Iu0syPxJlOEGFx9f
QA7mH1nGm+HBjQ5IS6u+FpNd6UqCwE74m3gKHgf2Gfoses5uRXU3BbBQNiQ/PnFYVjG2J1Kma7yq
VR26Z48q9AZey0n8DwmMHpb/e2pWVcY0gS+4UqIHZLqdehmuS0UWQmpa1AIHKf6KCxsH/wgp+D8D
EnBi5wo8h5iU+tMUtLK/mD+tOGGfVBO7HJWm+4kDWrwFQdS8P7YvC7CDo+sZXrGP0MVrITEoXJ/T
QhGgHqmsBl8jJ/Bu7MfXFNMq1S53YDXaaeZGQasWKFZK4T+5GmfKWyzq8X/eWZsiOLWHlRa7y1bZ
GcLeCBKIFwm11gxoW+kGjjc7ecPkjqVeaq/OlAmlOfi2Zcc8e64USi0mcaf/pR7LceSLreWjSyvk
P0CHHIxqaJcgvULDxr1SUMNJqKhyYk+2KNxbtuOYs5pAUjBT3nxyf3HevtSxOFKWI2vu3LiVLhEK
AN9iiLFdb+dYrzp//InqQvbmTLYu43Gke2m6IstJD61NQ5kksU61/edmaRIx5QLxgKDXvGBW0SLI
hnDWpAG/U0KExjblSbmfoZkQ6fLDMSvQ12RI1rmo6tQcdoe4sJLoi1d93e6EkqGtAJFVy3f1vuJq
KLtbWzERFQP/Z7zET5XJf55a3YSJySHyn8gXvgbuf3L1Ft7dMeN5rHejAJUBwChBjmKgP2wFli+K
3jaYH59AElLiFVac8MFrkokgqdJ+ThKZEeT53w0a/e4xx1lUt3l2MBvPtz/wyzqa/doHjiTx8F4M
oC1WLE7DDO01qY44eLRlEHWHkSbzzr2sPG8axnXXZosGkku0ifcmr4pcdtEk9LuYV0EaM6hTHlAt
bNSP7cXHVdi0Gy2kmpa2wsUte3RsKNSkWEVmx1wvILjUq+xDiWvRJwet9lTQpNH+aiyRXtMU54bM
r550hWae4hqzoQtFSI4F+O2coRt9EssJWDgNrr10aR10JBczxPO+fAfjM/m=