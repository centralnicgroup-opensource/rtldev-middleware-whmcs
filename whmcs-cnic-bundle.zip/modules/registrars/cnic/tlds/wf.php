<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm4ZCG+IfeaWQ+kaBCDw7GiwH9Z18CAvulMB022xEqGxNOhHOrbL7GXPMuDSKTOX/1GF2ge7
y6Os19JcZdV68XqvSujHBx2qBSVH0vyYTSiHnf1sOClU6hKe84ufcOr3mnBqUvzlVopAbH7q93T/
3L0SwLx18uBDOcAYqKvQDTgx9b8E+c6B8h2MyE6AdQzMh03qXchEl6cm+Pp70voiMpEy+OQUX9qi
R8NfuQXD5vLbzfd9KYV07FLtsQU0H9bbWu2Y2qYDK1aSaWwd7YL+qQIW3bITOQ/A9/u9R5NQksPr
qRw8MRPCK47RtRJN6n4dA9LHtDaXB3hAf+z2tH986v+bNrTo2OzhK2fVLj6dzg9rjC2wWdRwMHbY
SyiRwjyF7MDzl4xcnen464e7J3HpUczVzWFGNtdi2LCxZUaF5u7+t2VB6PLObNZBh5T/ujZSTXxp
ln8tcsbF//PdWwgTlJDxtFtcEI/9bkqLrbhIVJ3+zo7BErf1MnZ7duFxrQrLqmPuG+PYHE25j3IQ
Wdx30CG3peabDPK+iuUFc9ciTK7KCw6kP7f+S+Dd3Ycr9PN/igk3cHvSoH47DHOEKDM89I8F7Ae1
QA2MPzO8ucM6o2Nf2sQzs5/Z+Hn7YUiFqNsXy9MLOmPHMwmzkVrM/sTn6/XX+m+l2BQ3KJAF7jse
7CA9ibl/GC+M50itlFac4eGdy8Qdcnnmi5DupEF6V8W7gBWLd/5ca67DB6ZNEToM94sg1qB8ZqlG
M1GxyP6CQIxmNUza5lo+BxOAQnomd1FN9Pd25oejUFgspZ+m3d56XnHwSLzZ5wBIMfZXwG0iHeAD
8WS71q/qITdzec77Bk+JKDSTEslv7VJW32ft9ivjIM3svFGhjWCR1PI5TkxX87KPhPz0gfWe0bCx
Jk0+i7j4+Q38+Fq3ZDPhZ0BUIAbeKUrG4r37ZP1Tj7b/Y2pfVR8sSdcHihL/icJZ0+PS2vkOQJk/
fpPAbmIOa4z4XNp/kGMkId7zeuwjX4CNCRNDJMjSb9ml1r4fPg6ck0Rt7FjlXXzi6FqEvs03IQLn
+PjX9EUYIgtgz+Ofz6mxgN/5N4JEfcJtLtDzkfiA9oRenv2NmagQhHD0GMgSCtGFCBM+NaAh7P7r
UphKMRROKLB1ZGoW2cSEpptLihuxC4isZRw453aL8JQTzxRXufQAsFuhyqd6rvlrtWqp1S37o+Dt
C7Qbdcshqqq/5lgSABe0Zm4V+VxzYyt7oQomywPYqPUHGD2DzhithI8fuLrYWjCXUjpMPOKg76vD
81vHup6QGtZI0aTOHx2StQuAiQix59kM/pyMZbDZEtyL1Wk94E3AQWEFd5AAdoFxQayPDZKMb5ks
mcLaGFuhXIGIIV7mVVeHXrvQA2UyG4GA2Anbm+7QNZ41iWzQiW65QOV2Z4auc/J/ewJeH5gMe88u
CwTpRIfJAxrOC7D3DtbHtOsfWVW3yXosWQ+d/Va7UWfj0LmLEFMb7UnwqReqYYOcz7JTx46o9Gam
W1H8OzhExBQq/D2WKpgmIVjaON23oqhmHXQS59SbrqNWB1QljR+TFSDl8xt46zx7Qd4RjK7yqDHM
vThVq1KlKvESCJ+4r1psMe9Rq0WAl2kRE6ACSfJHg+Qs6sNZIbwzd/N/TXE56lT8teSsJgU5qQsH
scK2juTWf2ab6QLqoge52BmcVStIVY/PXNHtzXO5BdzlSJWfq62QLnDxRbsuZLU9wawkLfeahX5e
GbXY3f+3cESgocUl/2A2uc5xBKsJvzzRLXG0bstiAC9kwDG+3THurT807CkeXw1VNljr+Jca6mLJ
oBOZ/9AfYLhtGnQs4c90rlt5zh92u2KtaDoYarQlaLZ7zHaXerkEZxLTjvu3oGzSq0M3C9I7JFmA
q4l71XekcoexHMVpSnlF2ktGYnwRdlAMzJ2rZ6TzBIyoa2Bqy2L8taeJDSI4m4iqw+3sgFcbei10
gXsPH9B9Tcwhx10ZYey0NxUK7RCYgN3/r/+lDUUMlk/upIQ2vGs5ZiquiP7Po2baGPF4T++wa5v7
nPMfjy1sKeeYAspJeKgxszBr5ekfbas6DT6dQBZ5AwFQuEZ2qgovGDyCEX3FN4eag+JnUHyr/rJX
T+8uGX8omteqsTuaVcHGS7GZZ7OHz1a4Lr4oPb8XtRc9UedGGGXkO4CZn5uYDu7k3P5pNOR47AgQ
BNPkocnoHpuQQXaN+yfSXpHcvxhoHTWH8AYNtBJ4LgPKVviMkibAoWZcFom6jnY76QrBek2EodLc
e+kmulHbhqeUuvqqLq9trVTT39rfeflNP+zyiX+CVnIqvY+A2875dDxGX/DfC5SJGYoYJWFGa6Mw
jhc3sJ3IY/29o01yUg2qwPjSneJ65nIvB7hgoV0ZIUcqidd/wjO0Fopkz1nFQrLY/RfQw18n82pl
5dZFSpTaDNDA5ZF6gDCrVdm7P0BIM60E5w8PWftdhe920GLzR1BeGxC0dIquDjSZV7+Cec69kOPc
XF3g2oqGIsIX9/vBNkeKymuWOvEKjZygyzCj9kLW35Tv/8oi0WvJnMyAi0Eup92by5iUe888LNNq
lPnktj6fJPP5J8yiDkWshOjXajNnQfZXVApPMOwzfJcs+BxHTDCTUzURuWrYjID7jW4TgiQ9fH2U
SBVmh1DrnUvhpfebEKOevey/fMedzMeUWtCcHQ3skB7lXptIIOn0UCm8iIkO85EmfodVTR8FvxD4
/pqCoXpv+7UJHh+Sasy3kzVwBNxvTx8/Pm4TcTaDciXIyQC6UL+EPKFvNf5DS4HpamcOI+uPTVak
3Ul3wmURgLMZvLslP6pzzOE77zIjfd2mzDnSDjOJXxxG85+InGqLV2GhT66e7NY3OzJKC42vBc7m
9gXkw66zEcuRK7ezinOW5sr88Nlo6UAf1X7YLId1FMaSl6e/Ejdjw/fFnmBfdQI1qxp5ts+Vz1aE
GYzvEqgxjYeWswICTlQCilAWn8lEYZglNQ459L/8v1FL9WACPW0quXIWz30qvmMwDFGKLqoXaVZe
suP0b02eMS1B3c3k0VdjZs4V1wEPpn9c2il0tjb2A1EO9ncAqWyzFW3Y8UHXBu6wGO17NM9K37dB
66l6AzuSnUI0KglgmtIEn8ImPhklSnFNaRU4uzlPidh971x+ieaHdgv34GHltW2350RAGWm9aKzd
VFxVKE/u+JF4hmRkapuSns8Uj033Ib6wjh8UhR6TuIEakoBQNzYkjyVP5UIuFlrsMadxo2BqX1T6
itevcHzNT45JK6liT6aST+fIeZynjiGuVvJT91MUN6g3NM4ILnbYP9IclndwVqUcqd0GEzO672A1
e2cY+03JMV+46Eq3oMCM4Zbt3sel6ul4vUgUs4m8UZLCD2tfJwE4X8QKcvC+foVx0/sw07cVqeSJ
RJZGwKJwfeOp4gqgX7ge8JU1UlOLcuVHaMWIYVXvnLjsfO5pAynnmmnz7gzPVlkvJNpYLZ2szy4I
WcznLxAqj3yMj2PdNOzgRCGcibi8pz1AJtMKtOdr6cfNwwZVw2QggsB0VGcVzUILtobWYoqVKGMM
yVvKkVPBUNw2ODp0hdJnUOzaGxl0Uuyqtky1CIKTM7fnqGB4w9UdOZRFRWelbIc2pdoEroByU8uT
j9MZCTXF2Tet33iokPBBLr6XAIfU98jOEokze+6qKFXYb97lBQiIYy9uO/m2uRVt0T6BmoC+wKZt
6ZxJlG47UpPyaS4bmqa83N20doSgL+oxKEsicHnYyT77++qi892GL8yNwfrpdCcl2/9gMfGUbI3Y
b0OOJ9OSRsFgAqahZ2PHJ36dReZuhnS7l+s+mRjZcApkvOW0ozvDoBHSLKGdJ3SQUiuMaPQLOpan
iXrST6g5VqioWMjQDwuoyvalSojbivXpGIhY+fMMb6Tx1vi6A7iSDfHw0ywxvOpNE3gSMC5V/92v
xfpCqYpo6zWwOhh+TyZ6OqPPzqw5z9ma/IXsfRjORUjBpZ5MLwX9w1tz5AjH+fByYmBFh6u7/MJ4
i36oWcVTYX57bZJB/XVeFlaRtE0I59ueo704pBUZrxc2wC2c1RnxzROvJrlu9/4inhorT/Rc