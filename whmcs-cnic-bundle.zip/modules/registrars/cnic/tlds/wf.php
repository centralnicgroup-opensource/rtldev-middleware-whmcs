<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+QWGQ7jEhgMw6ZKWghSVGsixM+VIP1oahkuNGf/aov/Yk/UcwSXRauCFMUStgSEajeN7AuW
unHgPe5AtfKxwdXazXqjl+mdrluhSLH9tLK2ox2mRlR5cFAmiCL/vhyvNmV7GkSAnw7NinhyXuXR
jhgK8EGXj+VuVxfB48jy8Q2AvM3/kBSYD8hAyYfTCgFmwNSCI4B5VZtOjbrnY4XmY8CUWhmIYY8Q
AmBEjSi++7O6C+DbEgjSwr/tfTequ8K3FMizSjssbBeja4egBIOQXBJ+E2fi+/F4FmFPCfGWF4Az
UcSiCpzGL2LZsZAHn45E8ayLsmBKnSJNaV62IkSxEKs0Og22KJPCM/PPAoA21w5ORQv5Qqf79Om0
b02609u0YW2208u0am2C0980Wm2H09y0dW2D08y0c02G08u0X02V02WEFdDLFdgeYsMaKOMe34E8
QIQeEknjRqIrUT3yVZ5/s2lvKYO8j6zgoFcU8rXI9geEECIxyaV23ddFiBKWBc9eWywA/jg57Hdd
MUUyk6TwJ/q8i70op45KRj831kPjWiwszQfSUkXxR28UyA9Rfun9M/OoxQsZSh6XiG20dGvo9w5O
VK/CrefSOiJMudyDxMbE5i57Jm8ivdQqzVN80mrZdaovBceSo6ozOC8fQmZWzdxlhvVBk9savGbn
0rw688PG7/wQ8T6SRGTGJFYQ66rOMmCSRshavmzNsghDKvwwk4TAMt2gPSpha35Wd1Io8KHUL/OF
5aEInUVKFXm9XxovQruL7MHlNWDVf0FRvP9ugVWtDwEFsOYJXVp6WyKbe90NrLHM1xKr/KdnCRAu
VpG4I8FeFqthLFyQCyYM4eXFveKXarJsPiM5m/f0DfEXKjY0rYfbfz6uDlXN2Y8beyJynBZJLeTB
SH8pU1lDEabozBSmSWtZHjNgReqS3RvjE+zFqrbWA4OfegpAMwfJfwD+q7xlRq9WaK9OEnYMrvKw
CadObXtiCtuPZD+y8ce//ic9a2SlxSepYbSqO8sZYBm9L5jNohFSnRNo02hOzuFkQwI05Gnp6IHf
Ub8/1g0+N6wzWluuROcY62wwZ9H8wzy9KbxasT9yXyBTluqNqF6IjIEHKgx9dE2pp3/mQ88vs+PZ
HpV188aoCm6CaqoJJ1kdPh8ikPTZ512ICxAuvtKbnEa6r1NZYsYfCcSvgTha6guDT1OUMf9oOhhH
qdZMKnSXQkzL+bFpoNYKWW7WhMYA6+f9PaQIv1JTZCc6A1oIl8oF6UlIPyyAk2qwng+6Ol0GkvRf
o3RHZtuomvncIM7cFtMBmI9gX8uBM6bI+yE/2hgfG2qNEQs4HNZ8v/MzOGgGgtvmyfD+zGrqEbfb
6y6jGK4qrBNrkLeG4L0mQ5b16izvNwRxj4Dat6xYaCWdHZfoayGakJsZ+0eXUNHGVClIzWzRPEv6
NdjLPWwDNKf9qTSEgVpTOdfib3Cvuc4hJC6Q43vnf1VLvnFPX8jX+zEkFLEdN6g7PHEcnHvVNCpc
8Dc/nVqEa0xxpDpJs5qZa2NWTsujB/NN+LCS/LtpBF/ZKt27PRUHpcMAvmTYaTF4p8DH/vkit32D
06FBX8hetqT3QfOmslKLGCF2ElGgYFEHiEVNraBjFYJnXvlBICFQge8xNqg/baBIeM37TU6EHNkc
hzZLyL6tCMlPKTIWTuVjI7BnaGZE8Pwr7B3a42pr3dahhu8PU0C7Cka9u2bvYXp/NKV6bb7kBN2H
fT42cqVmcN0Fycb80cAegVhfDbeBECAWT7pfKhmip7RwKteA6sTlmfJa5DNT8hJzUXpUAQsVo5Qr
uTuAsrNqujB8sG+r/oLvNJajoil34qEhrtAK0lYycljZdV5riSUYWcQxoCJe4H5xQQPJalhB4RwX
WQ/gqx71zDEbU10Kf1baj40FrJZwS2Jl5zOjXFDafdr+bn0JSo2jiBECWaOLrjWe1Z254zK3dZPE
n+xa/XkUTg3aUXkUsmWjiZAjLobqO9gezs/igVqMb8UiSyfjAeaEzpHrVW0rRujcV7K7DIYGMNtG
F+rJsPuzntd+Kd4MPK3bWx9S5VzMHOtmKhO24hfLyT0DgN3xEevLcDi8HbYrqunuvxRt8PJG6I64
ZiVckwZMY1IGfE5Su+dsi71RshL41WTBAJBI9fMEihr+dEw2D7UPN0ulQWopfcDhbU8GrGrAlFIc
5hsczUwwXE9z/hlprCb8uGuUWDLYXIKWe4DgrBUymftCfxUEfXSaKcO7a6bSDL59APlWeWqJYiwp
+O04d5Q5uEoqOQlQMGLTN4MHRifsYpe8qQZQvgsr52tjZgvYkOxCxQZssoRnXqkQCGXYT+SdLbf3
3RN03KEOabyt+6RwvdSfrE02Ms5hI7TUBVIIfEDJ/HwE9of1S/Zy91koXPd6cIGb/th9BTRObyfy
ZJ58IYyl+zLGdrgXrlkCMGUzP3aD6soBTVeCTNdkfXtjBdUcvOsq0eqvnMa3csIfRc/vtZT3GElc
fLvJpsNxv92B84a/u9zmz0+Ig650gJJpNYZZ5gisL01kVEyWSivu0zZ4OwvrIgLBmDcvj0rsjn0H
a4QP/bwqq1/IjpMeVZKcsnbIksr6xB3IX5C+c5eaS7bS0eHI9zr7qBFs1XA05gVfg0xvRb1AAFjO
+dKxkLC1BSA56YEofyb3nGWxO8yr/7MaGhxt0oz6Ug+FTcpN3GnzI5QhH7NNz4R97en42OlwlBSv
CpLMDc9/TcQHEcehFTAlDLpyJNy468tGxv/LOdOwraCu3w8AOXBFnIe4jkyDZWLvaRkZ19twT8e2
I4ivyyPiqy7lm7/smdt9Qq95lgJG+Qd5gDoJDyUOC5zYv9mKUpYlBcJsYUnOVKCqXirZkVA8U88Q
eswHfvXZYBsSDVdR1tf/zP19aQaW9RN1B1z9kfgd4kyvWhScWx1EqcK1z1CezOY+QrQiqVrwKQ0H
QJ4fIZ6qjDcEw+PLSLH8QPXlxXBByYsDo1BUU6Za7YWnnqBboYGEp/OELyiMiwt9k9U+gWFF/arc
H7DdnqFl9wXgYnNBFKh7MjWb5jgXyFqI37t09awz3SFudJwv99IAzVVyrqlFoPJFY2JWqXtXTmqe
jEeDevHfT2BT8tq6bnLnyPfV6IwqaCLCh8W9DybO7oBND17OGmGTd/cDHA+w1JUmm6ujKL1D44Nz
O5I3sbh6AeWLd6z7RkjasJCUfKzfp3zF0Bx6+w3kKKnaV/iAYzjbBLo1PhKXmzaf1FtAykXJj73w
JCwv25IDu4O/8VCDEgVms1hn4tcRBfj3wAZT5dlqVB6PNvoPN0EEwF6rQFW7cT1iPXgdtMU1Mats
fXVgwUaDoa+If1Bm4UOc1yI9wLsnZ2MI15WM4QRDJwCRHgZXuZR3+ZhrXdIxqChYu2tno72/SGzz
FJjmaSU08ErHOfufYYRZ45bz4/x85FV2V8Tg2dTl/zykhWB2fjHAW/nXURbcJCWKLPSzc/cqcp2f
/v+gLpsUloScTMhtpo6u3P3CW7oyni8pRuHvgnaiHN/tWQPxPAhvwbI11w5kQpzp7Dmk/pDLOtss
YNfH4T25KKsHQh5p4hSW7yCOech2zZUktQdp6+aEBoN78H8mFdgqMoQCrRqxgv9SqIMD1NSSdUhw
u2o9eSVzURB5ch07OG3mb1JZ99g7e012v1oakuw27cW+Zxi0XrZrViWcxIaQ60+eQO5EKdnfeQle
8nQO9Tt5CkzoDSZpoVbE6KObgDtFT31yKmSAYmHPPIhJ8+COY9+1h/SqjetLGiFanUxZjJYaM0L9
TYBgayyWdjP1AYAZ2ZHtIno/L2uVDkVbjUzubJvijmjaIIWgp4Y9BwPCPxXadZH1HVcnZhKuFurW
2WSzy04DzAGh6wBB53/DN6BGYka2Ec7msDibK5k6Vv6GKfKJ5YvG0UGvjDRWy8QsBehRK4h/VzaP
Oh/AjOigaQ3sXkp2BD+UEiVHUUAPWMwy45HbgZaVyC4Mg3DUkcPL91zmVDAqwjL0ygb1WJusAtfU
v2o84q2KFdZ19z5YBJ44Vx8GqbA6UlAPk53dn8Nz8hJ86BhbY9m1JhDnV3JrSr7zht9QbW6tD/pY
NPbxD5JqaL8/krQAuDy=