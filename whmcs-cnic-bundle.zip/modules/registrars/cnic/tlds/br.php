<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpO61b2bwFfdiBQJSrvM6TMSuPnpWvvyLeAu6OtHXLhVAVpdksuJMN9SL7IJaSIKn+6SQvP3
ka9jlkMY8QCRBB2Knk+RzD0h1/E8o13ON0d1yW6kMTMQKUckXQFXHebMEEpTUmjMwIeuVFKocHxv
+Qc7Nl/mrT4VoZh/ObQ042ulC/P5qkDpcW9CXX5BDHtzSRRYJilGEU4BVDu6XiGKum8XDsf16C0b
vHN3xHByVdyGuhdM9nm3Ls+VvcMJEyiNuiTGu08rschs7159idl4hwtDlnTiWZhuL/jpGx85WzTN
v0L///o/tsqTPbHgZOZrjUg0YaA+hjsfUtjqeur38dbeZOZEexN2/tC2kaygZbnsEG8PX6TMSJ78
GhLVCfRqsLO/Ik1OwZ0nXwmIpDCc4IBO8EEsl9mxMftPCJiYhEpQOsb+1yCBEAhdcnd7hmrQqdbG
FNdxZ1v7IFTo6mQGwCqBJNd1Ewjfr921r0YRCKgYBNaMyimBkx117/x2uLUwtIV8PssvPnjkgO3g
nnfX8eKwSiPGzwDrDK7C46AKOeo5qS5YSK2JElHa1Doy3X/iVyvg777Iql/6+JKcj3VtLwSCzSES
wg2cXepFDCj6QojkwJymvmpdFeSWgV9lL5EgCHTPN4HHlF0nmptSoo+4mup9xIGIBd1iJ8T2mfrz
qFyJ3EMo+5gKnd9Ts5+yCMKjYij2m8MD2ntrtzTTuLTL4Nybu52nG12QtQC2b1HbVGOO/yJ8DRiD
XAeSN1NxV9mlw5IggN9n1U55Fg1V9wsZ2xoYmwhYlq+biBrJT3/3kIxBAfDtDReah5VwUxg4UlLJ
g6Ulw9Rde+9bIMuI9Err2rpmpNvfYVQXbMf0PQ3MLxlTAT4E6kqmd5fEK1KmKRna5xClXApsJvmf
X1MytGjsoUJgVi9gjLwBD9I0Rn0QG5G+gglL1voD5NOGhU99hsg0do1muhdbg8rKd3jq8HvpdqoW
JDQ+JWoC4J2wTATtbWJp4S/J4lMRD6cgk/RD6rZSMklm3M5zHhMNumlL6/N45/nJ3y5FEHBnyMGx
sCuQMlbezKEccj4IgzGCRS30ki8A2K8CrXVAeNS+8Uip3uPRzfjuCbYWhhKm4vsV4MTKKkkEtTJ5
pyehS5rxvkr5pUo4Cy1FQXvM/2v29Xb7d/9aNUlNn0XSY4r6cxc3C4tdTS8TXX48+fOTR6xg49rI
vWWsVR7yCAaPL+Zx