<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtD+iDRZm0WP+iubzVVwsHG7AFTF3tav+O+ucZPLNAipwu0U6iPfCNWKjDba+UMGQhKDqukq
PhqYRL5ezmfur6DqxdczTtl9gFIGlphfucKa3YKYSj4V55maZ69KRlib7yH/GhvqAGe0/2LR4s6T
SfQSiwVLlVV0G416LdA/G9CXdwUyiDu2Uv4P+B/ids6KRn/V5e3xVY55NKihmMjIhrdfj/65nRGD
iOKiyEF/15G7ktQywTTDq7/WN4YEqkNR5AX+HCJbVPVNPnWIKKGpvUxVHjLh3Wn3sNFeyn1us47j
L0P+/xUz4wcN+T8ahHpi7aGoituEfOQqqwPipch5h7VsKrQcRsMpXtNnTSpogqax1bNz8yLhi22e
2cxezdQ68jdK+nHOggYT46HJleWqktZVlmkRHWB8Iwqk+yavtwcmy+4L+zICnqxZ4IsD4QDPGL6s
Dl2fYYbfYie9kyJv/Mf5n6vdbS4WSagcduG9B3MqT+POGgHvKaNS7PsxgaQQyHS8oPViRgfJwuqH
5DVUqeX5gWz0oDkMqEAlX+fRIrGQkpTNazy7hoKMv2i+9yo2Jj6cvx4S0VYFHCLErV/W37/9pMqv
7k9rfpfjbWzuL//s9+7SiOPf8wpKbxWYVTKG/ts3+GJ/yF+CLjW60x0MhnZ5chngdXZyPonM987T
kQ6/p7sBNaUNema+0XUjC7cHIbSNlHp69mGB7EAoA+IY22uTmqsNMUollN6PllV9UjDD+y0rRRHe
/l/Z3UJQz8RN+wy3DWGo6iuPCVlHgG3tU8FXivCS1mso9VGs4h0SlqNIFnn/DMiGJXZ+AZJQe8A9
M8o4YjfnxjzvyeLZ1DTwwlXv/0R2kc5pvOroaXW0YC+cx6bszGzg0eQTsba9XI0RsCPr4gfHP2ev
7/TXKSbgn8s/j+1XqHNJd9ni34lWl5QayI1B8vi0jRHLQwl7IGixTSMEZW0K29i6SaJFju6btZht
vbodSpD5wizUlw5ItELjLP/WPeHd6jGjaPkJeIK7iXd/wXCrgnMr8I7Ko5SVWYWJ1igzR8Kzn1kJ
M5brm6VJQQ4TsRHWj1w5TjWVQ87Xibgdxh9MJHS/1UiDm0WUdVLWqQxQJa0wrmHpI9BP2i2sd1zK
lN1vRtREcGm+JFQ2YpWR7z4aR+IBtTAJ5QSA55kvvHiVAIpK0c7BE2WILMfFbraiXwzzbq8Xps89
Kkss35Ufe7zM1sq=