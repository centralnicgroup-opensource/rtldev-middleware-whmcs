<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoO7bthMwsjzhxS2MIjAL6G3sctlKZjpWg6umxO/0SeW0AYdJNGlWCiKkJ7A4ILebgl3hhVh
ziJpm4ftWd5TsqOVEuvA7hwZaghPYt3dKT0/LAdxjegpjVPQtBgt452SiUygVT+xZoAEJFyGsdSO
RemkYtNhKJxVpbxdd9hBD6R6PrIlkap9KOOhw4BKC65VYiFbrQY2J5nIXT7Vz+lt7K54arFUqrRm
gX3fNLbayUDPjrdBVorO1iaPXYBEmXdvsI0wFHgssC1YTuRUSO5ryYqJAavjQOhJt0d5hRe6oar2
JiPx/vw9q83tMxXuy3Ckaf9thC/CHX4d7ndVTpYXlBDlplIj/6L/kTp8MaEPqTp6xRmncVXC8NWY
M7LhZd6XDa+xSo5X01PpPmz7GA15Uo1Fv6/GGu2G7Rb6g4ArO5AI9nHPPeP95JbmKxsFRFcu9Asq
9Z3ZqE4iyO30oeZhMuas6UTNG61nuKl/+V5kYnFzn8KEwfAtxToU/j4aNU+Gedv11yQDA0yzrVyT
mVt6IS+Am3vIJtUvFf0Llsh3PTxDKt1ylikN+e+JKkkZs4sczHygXWKYnoku4p0iHXZI1UZ7I4Qz
dulF7bWnZmVtC9hF9vwbUd0sa/GkIKCoePdeQRHsUb7/0+3pV4LXMevIWjtjy0s8ZGRRd7SU6oFA
M88avqTFrHMwqmY/AXcu7gY9ZUNoHtq6qJNzB90OKUiFsT/1pROJrZcjEoZEtE8NSidO1rzZ10Xu
w+3BhovdDMn8baNPUtWDybrBtPVdh+rRXCOz1TvncLXecy3cND+g/KZj56CNK0K9k64iRsmB8GwG
f+sAh1lfj3d+f0rnIrpfqHEIvgaJVrt98s7TWdVsOcs4SSBRu9040NyLcUIrW2/CRODUhWCO+e48
9dkuUiTSMYTQiqD8jbl977413AIipb7CsIlJmi4ndE0CdjihpBs9b2zOuWmVFjJrqMq1ml95L+Nt
FJeMHWIGd5cOXb01fB0IrpF/ByC990B23+E+exH9w2PebECWo1Z8qcn583yq50rp1byG4928KtLA
ANlHyzvH6lytbkyRpqWr4TnFyv43z4r/12+DKX9YZj+pCwR2/woGbm9779D6hwKfCRf3KYlHzLeG
JPAlX8NqkZ3D+dLUZP5DFj+rGgcsMtyAWAXt07Lg8MQgIqevObamDqoldFqUYBSGt+w7t5+UnPkG
ahwB2PRHf+5IZLW=