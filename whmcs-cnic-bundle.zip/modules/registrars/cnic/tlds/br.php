<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/pc0onlIFW3TbQM3rgDu6mI+INxImsCLuAua4mVebpF7x0APFrpPidvYTv0RkT7TNs2tXMY
3RgrC0VZoL0i8NrjLsfhUEe3O8fMvZht22+WdazGX+ZmQsWE7jxHhUrhxKfatGb2uBVgaCvh4xwK
qPbqD7cc/K5wxMB+NhIaQFq5H5oFST7/CtilKv015nfk8zO0XI4rg+9skbzC9GV7wjgM1DwtKGhE
ulfSZcYmjKgUNpxZnYncGowTyxd1gRM2xLsMPr7xiogPqoBwarRZit/zaWjhRwQj4kaejyL5+Cp1
SoTkAMvyHfKPTQA9ICSbYlSnJK0PslqhWECZT5mKE1jZcupYqTnc87UEika7ZcPZrLha1drhXUoV
u36VmYZMS+/WU59NFVfPfigydANXrq1k61BbwjZKB2+DR8OLgf21V+TVTq11AK9aVtTgxlu6fnfs
E3vNi1n07VTp99dzbgd2bcADBkvESg0Dh1bwUndB9GtWt7LRRNhEqMEtQ8UCp1FCqEx15pyLMfVS
z+UE2+gU/lhB9N9v592uZyC0YCtN14tZJHhnxyB7jgvrM6kV3DdFPOlhNWnTgJbjZHj6h2Tq2qoL
VrunruKadiDSM5rQ1DwkKoTzCKxqeETuIRUXGSiN2/v0cKd/AlANpOqZNXBRgcTrJkPcyocWKbx6
515Qh9p1WRFHjpwGo/6VpsCwh1F6evd8WGaNu74A8qPTm+ImaOAByUPVdwzM91qih9gwzJ1Ikogi
s2OfYbx/qPF3cI/qOnaOU1/A2FoWisrI7xlVh1o9wLS2NoxtvYuW7uBdEZC5q+UFWX+aJEUwRiB0
GIbH2G+wrDy27eihGn+c+0MKBTGLaTv2YEi6PsjUOjZt+NXr3K9z4jfYT0avJ6H0BvVvq72w1kFz
m4mTnwU6LZV6l/wTkltzBnV54QFFvztXkSkDqlxhM4MjswROMv85gEd3xreAobcv7A9/r9KJgmIX
hBRrIXUDNQQyb39xw4XnIiBH31DjENGt8+STETiYvCAEo56VX1ROyG5VnPJTw4BFlujw2s9/CJfK
nVc3hW6bC2zjQKueWToVX2tGo7MBSiA4pMHFmG/DOFElMCIH2vSq8zFaqoB0YZPHiw0Xbfhxv8J1
F+wbB5fDUufTQ3Me77feHiHoiCxL2VStNulRr6bXfERKdPi+eUnUpHggIdejRHj0OVYEkPffOtgy
1yBsebDRgjG=