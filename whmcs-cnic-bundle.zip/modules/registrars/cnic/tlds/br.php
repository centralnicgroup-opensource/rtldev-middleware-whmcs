<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy8w4js+1+SIHug7/bVny1dpyf9JSTEsaEa17CuEuhPfJxlY403pDuY884sYfq1uSB6A+A8L
2dIqmjLJV4iO+5VEUBcBR+syG7REbE64THhgYwAdYiKpzEjjC1RBIE2nHIvV9X04r7rGb5jbSIRU
+xr2xPhIFhmIrjpv+sgDwWhQXigdo9VtyYDAkh+KgoZGHRqE+ZbNHUWNKOHpfEUGpBOBOl6Dh3VF
ZyOVqhg+SYzKMN8GXF25zHAchnPx2WyVauRZWLzUJrcRT34BdkKSL5QnO1cn/MqHrpBpuJKF6KV/
rkP/HsozGGQMWQ5yvFObRDafsYPDz8/XmnOz3p0DCIJ1s15lK7Ums5eQpJBjRIHWxvNu0+vROcHm
SzNVIi3+rPKiiUk3TsbWBr5w+nKAht27z4NgTcEL3esiW8RmbMjnPkl5J+HBFUN8OYS2M1m2qQw7
9oOs6VlOWskxceGUePmOO+ggdqxWEQ76pyVjNiy0woECpOaS79E+Xi8B3zKLmydh/Pa7tcJz20PS
i1Biz89Sc/jfDAFxMbiH1NnJTx1HBfpXZAjMGU8Fn3TeXa5tOAD+LeOxaRBjvGsWqjuujhQbJbPU
NW4RoR11vq1eP0/YY8oEPATMAgjhiqc0wJ/akOafZiaaVMtCIVo3QCTUKrWsmru8M4xsNQJsb2BE
8NKVb96PNX9OncDj13zEMiZ3jBf6QsKF9yKov4ldadRbPNW6dCgZCP9NBK2s7vnjnXUx65z+0w/u
uxweCK0AkpubPQWG6BoYkQ1gCAylIrG70Nps/25+cvnKmTvoUOaqRgItid6X/2EyBn8A2hSJ6FjF
WW5VCueT5d1WfMqkq8ZnaeCcp185R1A5w065lJe7LJ2RB2prmxZsUDdvS56C4k24wIyK7q2WVzNy
qpxvLeEW4OA2pGTP3/v1V/rP8sjbSLyKDPBTZ6NGlkp96Ml8W8QSNefBCMBem9Zumi1xur2sBImC
DxFLT2I9SHu2uvPrg4sDPZ8t2dSilEzj/kYrfd+hUupds5m83NxKn5Q2vCn0gsE69RVKLpqpvMkj
e1pBEtIbaITzjH5N0dBWoRX3I+9YdOEruzNV3LwDsnmo6RWE3hajh0Y/+ZKtosW60GZnj9NCA71+
SgPV7ctRc9Po3QAJ/ejF8K/sZi6iLxT9vRtnpNaY1wvnzfvYHYAjsqu95Av74bhWhG6uLJJjNomK
ay+FJCnt8CMFjQwAJnaf