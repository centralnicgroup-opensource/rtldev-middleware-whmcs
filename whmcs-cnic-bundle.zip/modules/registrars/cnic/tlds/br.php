<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvc5I59QQR5b8pNTSUpZvSRiGMrQT31eIiMHFPyHk0KihFwNJd0iC1IFzzHL5bT2Du4qX1P+
H2NDmfu8xJC/j5yqTO4IUpGwsdvdH+kIO2oe4YtvUWG0tkYv5Lh+v+pizAkiRm00g7W82Gz58GI0
Ube62Hk0z9Si587u37c8ua1CYfWiRn/i4UEjG4/1a6YrOFp4SR9z3on+D4RjTcTVhpMVgUopUvJZ
vuEcCfScWGm+Uu5WOOJu4IWhc+kjFdf/1arRgYlV5YMD7m+6kdsAmHpVv/p5OE6kcD+P6F01ULrD
zuTdFJapVg4jLUZsAnbIxYXZQx7JNbV6q+nn6Y8/7sOBH/6JDCbUqBsGO82Rys/MU9r6M4mMDdGV
sPujdHUT0ZWGhWTFio7RWxcPNfTKeVsd4PYSU3H7xvrIHrgfKw1aNJrS4BMsljWap+Pf7e+f5V7v
OrOao/N8f/9g++8duMREmu1SObzNAKBucFjX30Q1gBg8sxEqnSpjXO6/E2/AZkFRn63UNJYCewk+
HplwT69wD+ODf1nRcWmqLq9JjMfEqfJhJ94cwRpMqQAOJfZJCKAG2597/QNxHRXFyxH2bC8ZDktI
f5c7NUHr3RfkiyfWumRQ/0B6v1vhaK7SjtbtbpPRJhZaSMBZS4UOVPijmTmQS8fI/mnDkKUlybO1
mVkIrnQq2nem848f5FYl++wd7EfeBieBLkvAt4ugFeHYR5TIHOjLn6TDc/vFJtKQZsq4G1M4/kCc
6/G/u9X8t9Par5gyQlKqYthgwAYN09rJrw9xYexT34vTMBlhAIj2cpqA6z1H4G3odNos2OK1KdNe
bfpexsnCc7xNcOH9w0BbhCaXfQULOj1RmFVvXW1+f4IzrpbtVGAz0fK144311FTr9qkqqmPfG6bp
7x1z1B5u0S/mt6gC9G/sEQxqAQQ10Fr4hHTzduGJ26s7ivMDSSTRv5oDoBNfD65ztBM8ktirLUn4
r7uc7nMDFdzIyAxnvP+1DZAWcsAfKIsTFPSrkwbkXrodLxZ339g1vrMsCjetSliUvid+E5hVnbtg
vqhE26D7drSlIkBDk1EN3sDZsyLwRRMg8b4n8lDa8lyGTZ6HGQukfKNHb/7AXJC3oJFWmKHLipXw
p8gCapNMBLxF7FJPyt/s/Lr6zmt4C1LDOk8eu1WXM64lcxTBajgethXe/sGvKb6TsaOINUOxb6aa
xATOnKEgY3eLJts54ZdBx1Oskx9TNVjW