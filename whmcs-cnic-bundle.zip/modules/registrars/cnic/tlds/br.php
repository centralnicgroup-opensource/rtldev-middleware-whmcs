<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxuiV74ZzaH7EfpfKgl82A2ZtSfV+qybxluN7jr6vtqz8/NEnX3R6GA6T78H3LsftOJjRhsb
M1ZJSuVFnqnJKPNZkbIOrHEQ5ApCWk33hv0s1zllq4qzE4I6ID9mJt37pOtHgN/9YGnFWSzXcVGf
hjfVA/DPbUC8zaGrwaqz8WtiAx/bHVOjR/4cryH33b4rPC3jdQI/D+rhcf+PxrDj6DYT/YYkWyvD
m97ZUgqRGfLtJHQZjJkUlKGeE+suziKAQbXoWQcyZYRK/8KGWWXoGEdI70SHcunjxpNrQYmZHSsX
KqbXowKI/zwurutnwW2LjracJjO4AlHDh+P9nwt+5vUhID7mYJJeH3X6pVDLupjEpirnvQGElUdW
DkItlwxu8s0nFI7AasQ+dZuH7cGTXMdhsRK1lzPD1kLn3GfgH+NgwBwBl6/Qf03k5VsbAlthLqYO
eMxJ/FCUrkGROig3CSSJhffcLaVOH8fQrz65oUp/md+Cd3F0bgWIB1eKmUyVN3rIJHmHGlg0Bs8j
HYXUzp+3Jzd/zBn8zmNYwv+vI1l7M/A5bgq8NAyauOjr6o4j4yTt8jq8Hs+CWUkAZHmuOWpBKv+R
ZsiFCsUhsd6C3tk0gfIlHQ6tvERoJX3vVIXAiLXQm3hrfsny+/S3XgDjIupjz/Ad5TUPiXVEH3uC
GBtDDywyhkzl+XXr3oKzzER8qUdlKx25KBs2IDpcOqqll2/HuNtQE6bUrqyMAbLwRtsQ2K/tQUgv
CiD4UAJj/NxXozllvlnmVAOT/aINmrr+hpJ9rSDI6OffTqxwtpEaK2ODxVwGCenR91rT5ylxKYQY
zp9qVD6v/eTGNWeuXxybb0BQu7uwmeIE3sG9vAca0HEOyE8WIJlhCfxZsTx7reLIRmD6vP1L/Nxj
pE5krgZBgcrV0gG+jNtqBEWUsJ632Smzrw25NxnN07Iqrn43rlTOi0bVib8YkwYbZq9gwf1Bn7y/
lkh5gYEqCrgaQL3RKQRMx2Vf+QkQlvEh8Uo5E53n5b0qstkP/zN/nBjMT3dhZO6+IBYdYtu2Jrwi
LmpXM9ACqM9U2o4cW+mKDv3obX7UoUSjtNfufnciZYZzoJxRh1bEICy5OYJI+8cIjWNpKQ3HbOuP
tpGOa+Xlcn3emzXw8zu5hP3sWGiHQ18RR0wgwsQ+FnueQGbUVjtWEDICoUoqD4+X2ontULtWsVWu
JSOVvGoqb2sff0Ld+lm=