<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxFKoQfnFZAD36HSYN3jBw4ZgVFOrO0ZTFSxSHt4Zt9Uip7Nf4BNinQTWGBe1KaoGYAWfCPV
PkBDT5zPYKUh3oPriYFjMauQdkuzDCZ8Cbd8jrusjYIHV3+IZReYAZyI6bzt/6jV/BqBb6UqRrDP
6fm/rpIC9IrqFn9nheShMcq8hDgxdqbeVDOXSULRTgsWepAqU/Sh+Oh9rmc3LhS3C8E/09o+Ywm6
YlhTLVJn40f1ZcW7VmZrvUmfc33MCDghYd92+VK/cQ9+BasLC4HmKEQIKNFrP9AUOPtRtRiuHYOw
BQqb32b4r5NR8mahHVrbD7F1fBDZhCOnx8/1r0m2Kdujd00jvEV+kuaOzy6fhOncQuLQU1tXNuGA
bd2TT/KMecoQFlN0a/gKvqh4sk76hGQEIumOEh+OJ9vf1eD4K7Z9O4tdqThDBf6mSLfqru+bzqqA
K3E7KtwElWWgnNpp9myh6YuZUxMsX6oPL+O4vA6/3b+2l3uQlDBfcNZx4TX9SiFG/rbWI2a95/wA
QSbt9YkjDlBU5snmYyKSJpAlfR/+6nBzOfJud6BRxk993f64LJ/JbElMEdTZMYEv10vq/rF3zvP3
jsM4CHJHS03xhtOrYYsqo1CkCDpEgmTmB2saJdmSbaYoKyZg5Z1j3fTfWsukFOrse9SBm7I5ZSHv
y6fOC+3iquQkuiMy0N5lcdZ9ept68U4RD1pMrDFDafLNLV4If5+kJJj4Y2FdoeFdtGAqlkgxRyBG
1BbwfUkhbds+3uwavKAOxnGnans3EIrNC3ZteCvbCDvxGzsJaDNFbnjxXoe7s5ZM6hw2Cuv1GnhS
+Z/8qsTJTKWw/zgiL76dup61fZ3w89spAQ/OyJsONYQPKAN9oAgEX6J9GSZi9myv1wQhlF0CEDZN
Qir5BsF/BMbRUdNitoZbdThb2n17ATiIpIDcn1/1UlpPRF1S029dMqnnJMDu5iW3A+ToEKGQD/0z
cIB7d2d7yx/IK2XrCYwiTgx91eUzHyuUfx3PnJcuXWA8uOr/hFskKXMnYU9wHXeqtVBPA23Ce2yK
LSD3df5DZ7OEMyT3MiZ5AIN7KI/X2OEgPQDSQZzr7++amQ1segX0U4NdH+Jkh13PAD9QcRm3viyB
D4j9FffKHFb5paoXZ1LjykpfPCJKBGef8EVpCFxS71aPU9i/FL9iQWt1uw56c1d3baLVNY7q0LYy
5sseDwVITTUGQmHiDG0Dzh8DMHFd