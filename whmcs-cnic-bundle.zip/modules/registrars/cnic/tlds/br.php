<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxIEc9J/Z51Xspa+3RU/A+g3nPElLHGWvDjvRlQnusLPQAb2gWOMPE5fb3ZXCjtVIWcsesNI
q7WkGLXuxW/d3ueE9eB1svFUiZ0jnyQIKwtK0lX6BOrgNRwHgHraEZX1bwprW42GFY1NXowNIpea
361DInI0jSB1e92mutsM6N5nO/VPgVWRe6T4yvgePEuFInwx+fi+Tuw4s2CjNLUEmkAIFv4r6sKD
MIxZiuKBomJ7orpw213dLGbPTVaLFXieE9WucqYDK1aSaWwd7YL+qQIW3bIGOrnCSyhF1ItoEavr
aPM610Ck8Oc4O5RxBERQ+JK0RgNIR35BpzmuMjkHorRt2jZLLka71J1J1c3A8QGeGJYgt5gOvDuO
E41xGo5yvjWNPFLQI3BgSaphPhcpzlbux/2TbF1bfbVsGAZbLn+9kRepaPImXG1OZeKGNTlfpGt+
Kqr84VyH+hh1iaFhZfGkDVxhnGkHcU1v/VskgQHNxBeIJJHogEafh1/JJaz20P4D1LcKU/grS7tk
mT/gs1viHICP8F4OHzV5szbj5rCBqRuO0l8hcXzJVgtU3QB4707S6Qg49sjCVMJikoK1LcfYJ9cY
WTmwwPUk/byw2NjNpHMxJVhDz7z6O2Ut1UTiw8B2ZB1D73W0Yb/QRsgc+4Bf59wv83B3HQyTVQUe
8GQkHFvuK31A0YuaywxJ4QXxo4Dl1EEAmJ4jOt4bT9BtbdCtPlGEjWibf30Q0toS6VEFYpGQEYte
IGwrh+diyhu9pW6DrizlroNkpdQzeykWxV2xYRLciWiJUAeeGpP8mwblPLKl9gvL4NcihIOFutbu
j2YVNe2l3NIDI0rZFYvyWBcwLESRjk+5YcLmyO05TjJm+czSsZA4NmHK3N2VtV0MFTMlqeXkTZq2
uKYXkjPJCNVp7F9+mg7bkC39Vb11X3v5IcGKFHaeb8Nhu5pInGWxT68lx7UggurDX9+u4R4qNldA
EIYsGofUkavR/ML1Fq16lxxwjVwA4LAXLqpgf/5oXP8c+x7L++gtWIZ+oWy+uR6PUbRxamzqhwU0
vVulvYqzC9cy8Y6kuN6hWvrt/9I5j19dgH+H96afJ1iYHbsXmo2x6tisZuFO1JrFaw8cJLXMAH8k
nJetJG/CUU1rQYtc8BMuDcT6QblJUQ+az4FJBcca9vbD6VaTEwyuj5iJWoklhGAbBKxNVq8r8Xgd
KcIPKgvCPj5X+Nft3gEzKNrY