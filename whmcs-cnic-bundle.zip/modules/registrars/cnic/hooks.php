<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq2QSv1VJ4ZO9bBciv8Cid1o4/hBxmCPcQcucoozQvUBgQ/F4BTd/K28CyhifrqDIUx08VPc
Fa4F4OBuLoSvmLTA+rkwsTV06aTyYKXgGmHevA5jS7txry8Mi8TIKmcSWaHS/qK0S82I2zzaEioI
BXdk8c5wg3fjV++xniyzVVsRtYoLZAMHuZcAuZb3J17R3U2D3GT0NQiFAB2Uuit3R7f4Y3AGp9pt
um1Leb5+W3l7yCtTwELJe8dqohv31pf5FrhLPr7xiogPqoBwarRZit/zalPgBFIs0Mzz6P/3Cwmn
HYWGot4U2mivrhF2PUnzH7Heoqn0RrNY6p9ixo6Kbr2sXsMyXgn0zqDfvNYirRhgdmKzuuOUjNfg
OCmW1zbq7FCwFsUaoPkRDeyWMFHlSRm+pbLegkVha90x9I09moflzQm8ecV965wAtMBdmoHfZ+Eq
h6CbjmFxbnZgbhllyHFOm8ToBzsXue4qrLxzt/ZlYyUTdXwCJFYrspQxKRmsPuzCQbQ1nhwKX5+a
wdRWxoJvdSkeIjbLeSrOlXkiY6CBcQ8busRe2QX9+CjSGAOUa5SJCvmrwSJ3GBy0oaJP8+sltaR7
s5yjRsE4Ekj8NAvmWUuQePw3cSCbN6Zg41iYuOdw/ZsbbLP5b4bv898TlG76vgkw7OfTyWfk/3YW
/mvQ/L1dukM3pLVQUpEOb2ZqjOBb3/pEUQjaeAlseqNUITZ49B2wpLpMpSJdnYhFbeyhkV4W12Bs
FkgGwpHkrQTwMeFCTuxA0mN1lFyB9ChAekPj9Xd22zgp/i3cndwSCgYRjeQw6+SDH7d/GBCe10bC
B7/opyPXIpAvOx472lP6kILbVOC2hWuMNJTPeGoTCcQpAPY0olAQyQCAg4Ut45xYimP+tylchgdn
wOAMj3Sp5e+ZXzktB1u+j0tHDEIOTeVe23GIoM1XWnWkRXa9DjZO0Y/DT+ec73yY3le9nS9Hv+FI
Ui3nXoTwe0iTH+FHuUdv5PbKMQ+iMhWuu3PvTyU+stlgaagmjVenGsPO38vl6cIA70lzdrg/dm9l
D3Gu4nZYjcww+CX0U6fgf3lPJOts+h3Yk2yr8Hqs+nHEwLqWCRivDYA+1ADvxZYC+kDc+sSD3ocF
hd7FU1lHc1HMXxJFBdJvjUKRSMmr59yHxPa6PzC9NJx0NyLd+3w77Uq5lOfs5Kr9QlkR8umRhEt3
o6mOG0YfPgOBMHZhmYU0ahtF8H5SFK9Mat5b/TfGfJTes2oqbJVwYxxPHFQUVdt2tSrrX3F5B4fs
2Vgytkm+ls7JHuV+CXi300dLbHVkwyKe03tY+nPdi76cU6qC0tj2viLrTirbp1TbvA8uJZ+Kq1CJ
5w7OjuZQ6e/0I0Og4MhB0PU2p6/0poQJg4D+FtJpVI+I7iXtzFteJLAFYrBmttOTVbj2ax8sTcFV
v34scHXAy1FrnEAAjNehvlstkAzSVimvI4QBVXGeITf2cJG7Nh2D4fTZjTagw3ELuIKxw0Tox9Eb
kJ7GRGz2ywmlLm1B74luPFL6PIwl38t5yOkpCxu0MmFNJSOnunqgKhu8asjhrCo43Du1/ADA0JwA
HqOI0h/z55/ox2fpYNWGyMmwXsbAXcmlCbgLBpGQA/neLsbAbzUw2QLIxVsFjFYvcFrfzaUQ9w5f
kNAOW6XEHo/3HL3SUBZTIFaHZrOQ1HqIFrNMLXd8KPl3qqkZ97M2C8iiC804u2K89B3gUordbgu7
VKie3tiqN4AYeH6z9WdCS1aWytUL5bIT1UGqDK2jxntWklC8oNrLAwGJuuF6hIptJUDjLzBuMjdY
hV7r9J8NFXLv0dm76FeTg35/mq2mwqxeU6qUa8DueZISk9sCw/4ubF09/a8iiG93PpRQERVGL9t8
dtWxbgzEnUaxwNInXrfUFMuFx/lnwCnKVQXhDTuhkpV58ymWmkAiph24f1I6a8rPUv/afEKjYSNn
URwffUKeb9d72KOPe4/RspaGjZEUasiGUUcLWlR3g0q5Cbt2cduLuulcAnYgfymn1rWxdX/2Xw4O
AFdh/XmusNHFuR5l/nn2zFEFr+kO+a2FDH0PBOfH8iiBSlynMCBhdj4/BCMZd81ixKcClA1sUvAb
VbSMIFLLG6xr3kLA0E5doOKXfAatloucs0UHB+PJaeiweWiP6tk7KYlDhXq2YwSz1JJDJ7yu20Bv
71DSeGqddef2CbCkwbPulgDzgmZcZf8YL95PrTBHAyqoPPrAhyeo4KrWQg3qrZUIE/awbe8qyPMd
IubDT2I06IrjIZZ772Cm/G49YS60WaIKwvMiyMc7ka5ZwrJtUmwszcyYbxywH1b0dIX9x7FgAK6U
y48w5Tifdw7Y+9U07muBIbsxXX0UYKbekaur/mZI+2gOMJ+R9ZFog6Msm2hYx2K/wFAKhTAOUvAo
z4DlxIVTCVI0jmBzgBYr5IuhcQMZOgubL9wg7xT1NDB/S+xeYj6OclkPEKNNoIKYFRb1PlGmI4be
PX2xTXxgociw5m40Wa3fhHOjTD9rN015gyzdKnpba6H97sF4i0sBigJdauQgCPRtj9yVSM5WgAV0
tK0qsr2MP6Q9glLB2dbvKIEWsZ9E7rCoeBDMDkTfUuZR3pCJa2t2I7N/X4bwQkPzytMxFWo5Jtz8
rvIZcVGFaZGxogMWyLofTivaAd+vBOt0eyfpKq3K5VNg4iPzJgaeEpXJsPE8KMi+cx8qu1wTny1U
sYigfjWsn/3T6T1nBRph1mkop72jq/4sYEFk2eULS29CHE59CSOiTvcu+HIZJjycbAENqaiRiGY+
U/RffGyxRZfda0mGB227kFt/q0yzhxdivMNiH75NZwIvjWbnOR4KfyjHHN+odMTQ3P/9vDIoNWIC
a0KEG32rLvu7bchITJxQAihA3Htw+ZC1oMR+GsAMCwsCKCV5T+Rxa37VY1Qc5f4rRIeMPeXiarhJ
KyIM4tMiHp92JD+E35nYrtmE52NladgTLNDpOF5QZEsPREwK1TOc/JzQtr7vQ8FTeQ3KUpTlFWwB
gmZ+aUIAURTgoN/Rc6wxLVaZlhXHDSSPqZ53ppul5YFxA/NGTBvRfhkvCnJmXXRFB/RGyL8fSTv5
gDb+cLxiH5IcRCT5WYUN9UfB2UofQV7KVcjQACAZKggvsQHBgYB0TOR4JR2dSv/s8abpQ+HZOM2T
BuOCsKOzE6V13ucVjdPIZIhk6pRkmenzkH4hpNsrOGdtjrbr8cmVjEzkp6psn6E0kTQ2tHR40Bd1
pNvqRea6kenw1xuzCynQSqUAzdM2S26Eho7nWlFtdFc5ZTfDRnCOp+0VBInZHRoWXTrREcLxAuM2
U5PX9wN4VbohQmMb8DAcxweM92RETXhMuwFlpgaqECw2h5KXY2sXoU2PaiEPyW/m9FrIoIOjhpXv
Co26TCLYFKcxLUZJ8bChdkDIRfZmteozvJHfjJ/pj5Z/3Ldyk25SQkVEiOOOSMGBJGt5b5sG8nrU
/g5MEBIHiM6cJ1PmaQB6kov3OHZrOhtO52msvPxKa3D9+B+UcDONhNE2Hj2OvYkjDUjq9Q4/P5mX
yGVL+J1oeRVRgmuUiAefid9t7pFlGvZRnoU3X1fy+dlJezPdcgZBrEqJXFMXE07fwKe+Zu4KVp6t
ML3fyvDPb9CbLJakJwCptcpdQfJO0MnnlljHprEC9mc6BWkyBv37UO99UzFCoVXXZPzLFl72rrOE
PK3wGOv6TnsuKqcTSuVqd1eT97qsZWpIvzf4bh8oekdSxeAimcHu1iqWH3ICjZMH1GaKfOZNfFJN
ADEpTz3XH9FKw7XpaQqAffIlU4omOPgsfLjBa6pri1qaN7v87NxmWEN+31hW9tW9SWY4wjHxCeYn
BJ5iZ6qzRN7hAftCeSUkYR76HfkbofdY77PhUXNXJTmnbgpWDfmDhjHJo/qZXwZV0tXytmEGIZ4z
DV8WwW5quLjU77RAYrtITr4XWuOuA/snuVSV6IHxwZWlYjORRwU6dsE0h+u7no6H3hkM3YBfTIR/
QXqtPC/vK5Zx+01HzprghqOtxKbxsAhb9vyJ7gixQJK8YyaUZ1Bi7W8Bj8f+nFe=