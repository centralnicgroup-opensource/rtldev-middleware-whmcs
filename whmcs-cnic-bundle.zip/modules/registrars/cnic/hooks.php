<?php

/**
 * Hooks for the CNIC registrar module
 */

/**
 * Add widget output
 */
add_hook("AdminHomeWidgets", 1, function () {
    require_once __DIR__ . '/cnic.php';
    return new CNIC\Widgets\CnicWidget("cnic", "CentralNic Reseller Dashboard Widget", "CnicDashWidget", "https://github.com/centralnicgroup-opensource/rtldev-middleware-whmcs");
});

/**
 * Runs before the WHMCS daily cron
 */
add_hook('PreCronJob', 1, function () {
    $registrar = new \WHMCS\Module\Registrar();
    if (!$registrar->load("cnic")) {
        localAPI('LogActivity', ['description' => "[CentralNic Reseller] Daily Cron: unable to load registrar configuration"]);
        return;
    }
    $params = $registrar->getSettings();
    if (!$params["DailyCron"]) {
        localAPI('LogActivity', ['description' => "[CentralNic Reseller] Daily Cron: disabled"]);
        return;
    }

    require_once __DIR__ . '/cnic.php';

    localAPI('LogActivity', ['description' => "[CentralNic Reseller] Daily Cron: executing"]);
    $sync = new \WHMCS\Module\Registrar\CNIC\Helpers\Sync($params);
    $sync->sync();
    $reportSent = $sync->sendReport();
    localAPI('LogActivity', ['description' => "[CentralNic Reseller] Daily Cron: done - " . ($reportSent ? "report sent" : "no report necessary")]);
});

/**
 * Automatically precheck addons on cart page
 */
add_hook("ClientAreaHeadOutput", 1, function ($vars) {
    require_once(ROOTDIR . '/resources/cnic/vendor/autoload.php');
    $vars['registrar'] = 'cnic';
    return cnic_precheckAddons($vars);
});

/**
 *  Remove Menu Entry "Registrar Lock Status" if not supported by TLD
 */
function cnic_domainMenuUpdate($vars)
{
    $domain = Menu::context("domain");
    $menu = $vars["primarySidebar"]->getChild("Domain Details Management");
    if (is_null($menu) || $domain->registrar !== "cnic") {
        return $vars;
    }

    $registrar = new \WHMCS\Module\Registrar();
    if (!$registrar->load("cnic")) {
        return $vars;
    }

    require_once implode(DIRECTORY_SEPARATOR, [ROOTDIR, "resources", "cnic", "vendor", "autoload.php"]);
    try {
        $zone = \WHMCS\Module\Registrar\CNIC\Helpers\ZoneInfo::get($registrar->getSettings(), $domain->tld);
        if ($zone->supports_transferlock) {
            return $vars;
        }
    } catch (Exception $e) {
        return $vars;
    }

    $vars["managementoptions"]["locking"] = false;
    $vars["lockstatus"] = false;
    $menu->removeChild("Registrar Lock Status");
    return $vars;
}

add_hook("ClientAreaPageDomainDNSManagement", 1, 'cnic_domainMenuUpdate');
add_hook("ClientAreaPageDomainEPPCode", 1, 'cnic_domainMenuUpdate');
add_hook("ClientAreaPageDomainContacts", 1, 'cnic_domainMenuUpdate');
add_hook("ClientAreaPageDomainRegisterNameservers", 1, 'cnic_domainMenuUpdate');
add_hook("ClientAreaPageDomainDetails", 1, 'cnic_domainMenuUpdate');
