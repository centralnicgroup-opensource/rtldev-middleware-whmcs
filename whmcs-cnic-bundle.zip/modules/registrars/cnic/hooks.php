<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvIxfpBk8Xm5zt0o4SLwhzCLiGNT+z6wQDWPdW2gubIR+58wjVVSWdYy3uyGQhewzeNq0zPF
bGxaTMmSC//hmn9OCIqCuyR6xHPBmevl1MkkV5zhRhWCc6H8Qh+GCLdnZmXaZtWsFk8EYe7ScYSe
BfbiE6mpDD91hy5M7Pusqx3/7627Hii0xYDc+NAxqnEytox3TFHHoKxo2dg5UBWO4d4r654c+uBt
hYLko9yfeojBmOI/FuHldRHQNY2rSHTi7y7tqwPfOAhIxozYFlMSSWQDTmzBbsFpPtuuSUJYA6uS
6SLqyGbdMdoj+u/bgXrr5Cm2Uw0nGrwnL86ZYpzEWZtUyzmN3xyKiO2zM4K7dgppZ5FwKJc7AQ5O
nkKsVfoFSyaNXrM4516h12vdVsqNNPY9Jya6ldhbhtB7pmzbIjeWlWq6m8dPKxHeQJ3m5S9/xEnr
WiRk/e06o0iEIF/5RkqXBHlece1ACRDP7IJlmnq/PS453wDz6g1NpxHpq4fPoJUOB59dWfK2sQrI
5GHjyZcRFVp0vt2vcIEAOoTGgEOUFRJOxege6AZrnm82hP+5HqaE06T8x1YP6Gu8S0vV41ZSyhmk
4JM8HH1Qin+R8EUXSnM5rmDjNwJUpDlKY2CUsw+kIR9oAjxLPCR50dDjeJ3mlH3ndj/oIM7Ze1xH
15AGy2AnLd1hW+JMwMBkL1T7AmUpQkVYQEZ7KA4Kxn0zG3R6tFiK6YNo9MtTuoKs4mMr3g0dI8P+
GEapAKOhdpJ2S14xA3bQFOqqQWALkvI41NdsmOORh1g+pbvt6oH1DIWk7Ioll/1Gy3SU9enNyYKD
SOALFKxK3Tb21J52iHt118Doh5cAtlj8lDvSfunPisDqZLjO7PnJAb7HbOfnTO9ZW+00ySF+BXtD
bURsg0k6s6A9c2bjFrbTeikqWXDv3QRRHlPwkAdun1hKP5+eoq+fqdiSwzDK/NFugLkXRqyK4huS
tTbGyBjxTDcyCJf0+zFs4IpHoGQiWbV87aFuKq0xv3sSq1CPDKS6gVjilWquL5lEuy9l2fHwv6D1
lXWxg66wkC5mI1HsCqCV6YakO9thSXbARd1qVWSNkMq3iZHKwNNrdE+uU8TYTzgbU4cSpCkNWdzQ
JKdVmSrCE4heVumJpWhrGgD5KHq6vPqNo2xGTR3cKeSPbXV05VQaQNQTxjcogsa/Q+z/gRQQS50W
jUpxYtyozNhIK4F/sBZzZGP4iFJiG8P+1ae7UI8MgqjvsiLHiEZMh8ntvGrR0HF5XU71m44foHz9
aVJbYMLRLIf6GoBcq+OXkzi+/NWlWXLVJaEkGPZp2OoU/DqM1T9SZCnegeRtHmVsjh726bLj1/ys
lAIudwFfR4tsycggk+98MiwLk7VdodMoAbNzVvPUDWGqJg0r9sdxxSN7vyOxx8ISjU5baPwG4Mdg
ZlmAFWrHdcdAeS3k7ieltcV3yiGcXU5SslAiQG73yj091oLMv9gT9OIyqFhoyK7zXXQiX8VKVp66
8RNW447QvqW/t+LZLrA1HENwsh3PgffhkI/otNbR/5zEnktUJigifDqH1KPTek3PbH4VGvj1/e0n
03Vpquevxsgaz1/uDH4G20RCs5npsm6M2+DPkzi8sSI54rnGLMaf4uwd60TkdjTvi3QMxGEYCHEl
w+aIGvii1gA8Jf3cB1btMGtJrgAwHDel+ECpDxOT/ROEHUucJNzSxCvD3+Qai4oZecD1sJddrlWq
2qwJO704xE3j5iAhCotlD/MvPiqgPFUMbsMJrH4KErQegfQe0ewi/ytn3CL0kHwsRZgHQ2coCs7x
fYsL3JGmT+Xgg72mPWMT9o8vn90VoFntAU3p7VkUA/DuI6nNGmqztddCnZTmiCvQPQ2w0vOr6XqY
Ne1Zl0Ypd8R17u4AyIGX1cqn9MvRCfLcE6PXqi53De6zoM9fEKWaoE653fIaTOprsOH+C2Af6l8k
wDI3LnL0YIWm+nzLQVAcQ8ru+7JSV2ON5zaYhqe0ACEGQWPCPr/O2F6aTVcjCp9/cSGdwZKXGtJX
LpZPhX//XLEnsNaWgnBdeu78FsU+YU51sJjItt3NvVKRw1Y1CMZaeECJdpsatwLjQusHvT/Kr2vd
Lx9uxGB5M+wkJU+DAKtfZ6WlSwTgvZ7q/PgNyIN2BkRsrlqGzqqJ56XSW4+PP4XekaydYVJzkYOC
r3goLvR9HBiPAeWB6Xz1hyfTWlrN8OLO88Gp5pJJGXf2ixinARQ0G+4Snu1fGefdHkH+6i2Zu4fs
bIzJKxJccv1hZhBf2JyRxFFQw93QRMOZHNqr/vmKKWHwB9lt3bY85lVBNSuMFaB47fOMc3yh66pp
zT8AZAhA4KzldSpYxwz8TdCU2BBFWP4DCTuIJBG/3e8jA//MMwIXqX1WzAwwBJ+5SP0rp4PohyZG
SHgpzwpjyeJ5YjmpsJxAqsQt0JUpbZTtMK+h7ISO4B6/QSgd3yJWBZrWsG0p9KqgbcytcV8FXsBa
Rsj7qxshAzEPbdvoi7MEupAvnFwD1pAqcwM5XvokBlqiwBinm8+r96+4xOupXXQHEkgTQRw0Dnme
6M9VBVenZnvWdQbNBfOBvIWDpJcSe4rgAQ9KDu55f5+uLKXy0cvvlM7Kh7osx2UTDvP3XsTIBXOb
2Q16DPIWHZrH2Z8LLF7IQ03/A6rkU5aksIJGKgShbRXLpIHhcxbyI4HmFJ4RBrMPVqCX4ovans9Z
t7fLnOmEbB3Dw/CLPFjJrw23ytT9hlMI5e08VucCBHpC8W48UrDMtLyVT9OXM+nJ8m2rpYksdsvO
atAL6mjVPbqqtHhgk4NNazWwAq1uGEviZIT1M3cGS+MFW5zeD6N6ZsUF/K8mWMY9YeIENCLNOI1V
ZcClcewgYa7DKr67efBIM5lJ5Odfp+CXbGHFKr+VHRJtHgnY2YCBkCwE5KuEOwY+DnyW0iB4VIBT
91UER7zROTOLTT1It0vvLnvWir9va/16CGPKPPkYotz7wovv+PAIlGwLME1EV9tAPyZcX6IpzYuf
p46vWTzhOvY6tN5gCMUt9aokz81dFL24FkiCgdIXJeiu4/V7OK77aGqYV27+byCarbZ41il9vcuR
+3jKG6zSnnGBxe5yRm4UU8xwK8rD5tKpu8y/5OofnODqKjOGfUFb6M4q01pA99SMaNFWy8jMp9qk
oXTISH7WIio5C9ChZxxdIaa6FKFi1th7qEWWbHHuBMJyRfErLUBkEtiVvN6O4MpxeuSSNGShRgOz
8yN2eZzUUT+R0NNXPjSvpUHqDS+WwCeQZI+Na7r0sd9N4ODmHTSxBAJndM848eiYSJULAEt5mvXn
NSAPM4n7uwyjDSR6T86wtkKIDcTPK1/3+p6KrwznhWnbcmPjT9qWKoKXMt6Xjza8q82qDY51yIlj
iaefoe04k9ztGwFhw6DEqi8MTFoLUyXoQ0Px0euLXndcu0Fi/4RA4DRM75Vf0d7rCzMD4IsD4tnW
bXu7n+e/M5gHAaLlG6K4SZdGj7wFNoV80d5OjTeJReSAfmi1mXE1lTWOxSuDpHUk3QaVqfVCka92
wqcbLAOrAzW3khBKX9e5AYRuQFDWKKOgRrZ9i4bki79KN+4CtrPfH8XcMH+WJ042HTgskdVU51jo
ezl9JCfRFm++C+4sj0zENZlh4ZzntP5Iq+GHzFlhq35Inaz+sXGOeC92t+9i/rwjz1EGpvjSN3Rl
ldWhXYpU3Aoe52yRgz0JewUFZkoY06e56d2+DGXQgC9cEPKOMdVbEIUi3sZr12AF+CGP0xTBV+2o
DNVpgZvX2aXrJBYAYR7KoSafVGlUY6Gpkql9wDOfdVLFmWkApDVFn4f9OiRc2K7Sj6Ln5bjv4IyF
pD8N2FNOHX8DCmM+L0VCqKt8bms45H7hq66kLB6yEVZZ5Lkx7HPb3r3a21+hEnCBwPVvzSSFXO+i
gz9UKF2mhtiBKSMBvZvVC+xIT08+7rjGPCpO+l+0k8nFlktIeRZG2NODjbkaRaDfHsVf8AyjjbLL
Jyh65VcwGhhc9L3iH9QZcoZFhkDN/IXykKSncUvOhGnm2rWr377jcM6oNGKV10TT04wKfh2U1WSV
n7PZSBV0ucAAerz1uWtAdP8+ufgsngPlGZM98XPaepJ/USGG9mPhMOLIoltJlbhHcJR9faKIxlJc
D4xyxYtSWBhR7R3LWI8S6wRnR3GQ2FltbKM3Il++rR1SuD0+6bv8C3HC2ra2Y3qBd2jln0Ce4D6h
EUoHo9z98WxVfc/j8z9KlkgnoI5WcOb7LncfTyjTxipsBWbMjXqGOWKbN3wtrIS/YdULdIMvoGdC
RdX0e7l2NLKbjpAr87L2ZO9kAA10kw1GS7uAgu+dargmlHOEleA5g/MnXwFYMowee07FtvMQAazz
ANS+Rwf43Oh56IxuEWe5UTXqiExAn8Jw/C2JZXHQ1N9nB+5WKEMfbkr39bNo51EpFszhYK9oV/UF
MLxQMYQapHZvUClrr6uRwVrdFWNLZRY+bKGZ9u4IkCWVnEy3qa26iUmXFfhO4RIAi2EQ3ViiQo0I
KnxrTb4pXinpxcH87qlLXitCpRKwd6QZQJBKcP88wjLesz5/rcZH6wHMv5nRkW+PxTGgAkPpfLSA
iLiW07pqhs5FHA4MMK9QK1ymoN31CyCZm/qk079xrvliFQlFnLYGMCgz2e1+WVziEIaSFwz8C/Ur
f6KndP9jnJiKnTOuA02buTD4Kvc+5aaQxw+9uCpfW5FjQwBxIl5GXY7G104fQ+afrGB/HBZTfpUH
hJKZEYtHHhC8DUEfbWHkcpaW+zfwcNjZe1iGkIKUmElftJf5WcWo5ZJo90is+rnZEVIYknE0b/Sm
FT0qWYMIH3+nw24vwNJ5C5/Y/vWW1kWHp9YzO2NrPnJPLQa8+5kepKJdQ3D6lH3VDVgmW+Ee7aPd
84X/TjAx1BceHj3ppzHRZhr/Gb3TziUrO8ctpq6LvxSU+9g/D1qSilrGWE6XkjY3oTN2Zg99nq1s
4FW+J600EgZnls5TGJ2IPHpOzGtaLaoyn82mbbGjWD66W2wjudaYv+mV87QKbNSs0Q480/xvaNSh
N04cJNJNAGmAQb/0BFJgdpWe2NbNhkg0E46UuxTZrYgF