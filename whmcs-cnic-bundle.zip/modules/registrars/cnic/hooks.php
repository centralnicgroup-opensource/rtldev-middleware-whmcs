<?php

/**
 * Hooks for the CNIC registrar module
 */

use WHMCS\Module\Registrar\CNIC\AdditionalFields;

/**
 * Add widget output
 */
add_hook("AdminHomeWidgets", 1, function () {
    require_once __DIR__ . "/cnic.php";
    return new CNIC\Widgets\CnicWidget("cnic", "CentralNic Reseller Dashboard Widget", "CnicDashWidget", "https://github.com/centralnicgroup-opensource/rtldev-middleware-whmcs");
});
if (\App::getRemoteIp() === "172.16.237.1") {
    /**
     * Remove development and ssl banners
     */
    add_hook("AdminAreaFooterOutput", 1, function ($vars) {
            return <<<HTML
    <script type="text/javascript">
    $(document).ready(function() {
        // Remove ssl element notification
        $(".global-admin-warning:first").remove();

        // Remove development license banner
        $("#whmcsdevbanner:first").remove();
    });
    </script>
    HTML;
    });

    /**
     * Remove development license banner
     */
    add_hook("ClientAreaFooterOutput", 1, function ($vars) {

            return <<<HTML
    <script type="text/javascript">
    $(document).ready(function() {
        // Remove development license banner
        const previousDiv = $(".primary-content:first > div:first");
        if (previousDiv.length && !previousDiv.attr("class")) {
            previousDiv.remove();
        }});
    </script>
    HTML;
    });
}

/**
 * Runs before the WHMCS daily cron
 */
add_hook("PreCronJob", 1, function () {
    $registrar = new \WHMCS\Module\Registrar();
    if (!$registrar->load("cnic")) {
        cnic_logActivity(["custom" => "Daily Cron: unable to load registrar configuration"]);
        return;
    }
    $params = $registrar->getSettings();
    if (!$params["DailyCron"]) {
        cnic_logActivity(["custom" => "Daily Cron: disabled"]);
        return;
    }

    require_once __DIR__ . "/cnic.php";

    cnic_logActivity(["custom" => "Daily Cron: executing"]);
    $sync = new \WHMCS\Module\Registrar\CNIC\Helpers\Sync($params);
    $sync->sync();
    $reportSent = $sync->sendReport();
    cnic_logActivity(["custom" => "Daily Cron: done - " . ($reportSent ? "report sent" : "no report necessary")]);
});

/**
 * Automatically precheck addons on cart page
 */
add_hook("ClientAreaHeadOutput", 1, function ($vars) {
    require_once(ROOTDIR . "/resources/cnic/vendor/autoload.php");
    $fn = "cnic_precheckAddons";
    if (function_exists($fn) && is_callable($fn)) {
        $vars["registrar"] = "cnic";
        return $fn($vars);
    }
    return "";
});

add_hook("ClientAreaHeadOutput", 1, function ($vars) {
    require_once(ROOTDIR . "/resources/cnic/vendor/autoload.php");

    $domain = Menu::context("domain");
    $fn = "cnic_injectNameserverList";
    if (
        !$domain
        || $domain->registrar !== "cnic"
        || !is_callable($fn)
    ) {
        return "";
    }
    $domainObj = new \WHMCS\Domains\Domain($domain->domain);
    $vars["registrar"] = $domain->registrar;
    $vars["domain"] = $domain->domain;
    $vars["tld"] = $domainObj->getTLD();

    return $fn($vars);
});

/**
 *  Remove Menu Entry "Registrar Lock Status" if not supported by TLD
 */
function cnic_domainMenuUpdate($vars)
{
    $domain = Menu::context("domain");
    $menu = $vars["primarySidebar"]->getChild("Domain Details Management");
    if (is_null($menu) || $domain->registrar !== "cnic") {
        return $vars;
    }

    $registrar = new \WHMCS\Module\Registrar();
    if (!$registrar->load("cnic")) {
        return $vars;
    }

    try {
        $zone = \WHMCS\Module\Registrar\CNIC\Helpers\ZoneInfo::get($registrar->getSettings(), $domain->tld);
        if ($zone->supports_transferlock) {
            return $vars;
        }
    } catch (Exception $e) {
        return $vars;
    }

    $vars["managementoptions"]["locking"] = false;
    $vars["lockstatus"] = false;
    $menu->removeChild("Registrar Lock Status");
    return $vars;
}

add_hook("ClientAreaPageDomainDNSManagement", 1, "cnic_domainMenuUpdate");
add_hook("ClientAreaPageDomainEPPCode", 1, "cnic_domainMenuUpdate");
add_hook("ClientAreaPageDomainContacts", 1, "cnic_domainMenuUpdate");
add_hook("ClientAreaPageDomainRegisterNameservers", 1, "cnic_domainMenuUpdate");
add_hook("ClientAreaPageDomainDetails", 1, "cnic_domainMenuUpdate");

/**
 * Subscription to ShoppingCartValidateCheckout Hook
 * Transfer Pre-Checking feature
 */
add_hook("ShoppingCartValidateCheckout", 1, function () {
    require_once(ROOTDIR . "/resources/cnic/vendor/autoload.php");
    $fn = "cnic_precheckTransfersCheckout";

    if (
        empty($_SESSION["cart"]["domains"])
        || !is_callable($fn)
    ) {
        return [];
    }

    return $fn("cnic");
});

/**
 * Check the domain suspension status
 * & Unsuspend domain if the domain is suspended
 */
add_hook("AfterRegistrarRenewal", 1, function ($vars) {
    $params = $vars["params"];
    $registrar = new WHMCS\Module\Registrar();
    if (
        $params["registrar"] !== "cnic"
        || !$registrar->load($params["registrar"])
    ) {
        return;
    }
    // get registrar settings
    $registrarSettings = $registrar->getSettings();
    // merge registrar setting and parameters which includes domain data
    $params = array_merge($params, $registrarSettings);
    if ($params["SUSPENDONEXPIRATION"] === "on") {
        try {
            $domain = new \WHMCS\Module\Registrar\CNIC\Commands\StatusDomain($params);
            if ($domain->isSuspended) {
                $modify = new \WHMCS\Module\Registrar\CNIC\Commands\ModifyDomain($params);
                $modify->unsuspend()->execute();
                cnic_logActivity([
                    "item" => $vars["domain"],
                    "success" => true
                ]);
            }
        } catch (Exception $ex) {
            cnic_logActivity([
                "item" => $vars["domain"],
                "success" => false,
                "reason" => $ex->getMessage()
            ]);
        }
    }
});

add_hook("ClientAreaPageDomainDNSManagement", 1, function ($vars) {
    $registrar = new \WHMCS\Module\Registrar();
    if (
        !$vars["managementoptions"]["dnsmanagement"]
        || !count($vars["dnsrecords"])
        || !$registrar->load("cnic")
    ) {
        return [];
    }

    $params = $registrar->getSettings();
    $domainObj = new \WHMCS\Domains\Domain($vars["domain"]);
    $params["domain"] = $vars["domain"];
    $params["tld"] = $domainObj->getTLD();

    try {
        $status = new \WHMCS\Module\Registrar\CNIC\Commands\StatusDomain($params);
        if ($params["KeyDnsNameservers"]) {
            $nameServers = explode(",", strtolower($params["KeyDnsNameservers"]));
        } else {
            $nameServers = ["ns1.dnsres.net", "ns2.dnsres.net", "ns3.dnsres.net"];
        }
        foreach ($nameServers as $nameServer) {
            if (!in_array(trim($nameServer), $status->nameServers)) {
                return [
                    "KeyDnsActive" => false,
                    "KeyDnsNameservers" => implode(", ", $nameServers)
                ];
            }
        }
        return ["KeyDnsActive" => true];
    } catch (Exception $e) {
        return [];
    }
});

add_hook("ClientAreaPageDomainContacts", 1, function ($vars) {
    $domain = Menu::context("domain");
    $fields = new AdditionalFields($vars);
    $fields->setDomainType("register")
        ->setDomain($domain["domain"])
        ->getFieldValuesFromDatabase($domain->id);
    $vars["additionalfields"] = $fields->getFieldsForOutput();
    return $vars;
});
