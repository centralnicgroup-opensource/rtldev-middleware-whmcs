<script>
const form = document.querySelector(`form[action='/clientarea.php?action=domainaddons']`);
if (form) {
  const button = form.querySelector("button");
  if (button) {
    const alert = document.createElement("div");
    alert.className = "alert alert-danger";
    alert.innerHTML = "Disabling the DNS Management Addon may impact DNS resolution, and you may need to manually reconfigure DNSSEC.";
    button.parentNode.insertBefore(alert, button);
  }
}
</script>