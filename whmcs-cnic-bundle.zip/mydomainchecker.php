<?php

use WHMCS\Module\Addon\ispapidomaincheck\DCHelper;

error_reporting(E_ALL);
ini_set("display_errors", 1);

// Handle "Transfer" button from the WHMCS default Homepage
if (!empty($_POST["transfer"])) {
    header("Location: cart.php?a=add&domain=transfer&query=" . $_POST["domain"]);
    exit();
}

global $perf;

define("CLIENTAREA", true);

$perf = [
    "script" => [
        "start" => microtime(true),
    ]
];

// Find the correct path of the init.php file, based on the way we are integrating the module
// (via symlinks or copy/paste), the path is different.
$perf["init.php"] = ["start" => microtime(true)];
$isXHR = (isset($_REQUEST["action"])
    || (isset($_REQUEST["nodata"])
        && $_REQUEST["nodata"] == 1
    )
);
require "init.php";

$perf["init.php"]["end"] = microtime(true);
$perf["init.php"]["rt"] = $perf["init.php"]["end"] - $perf["init.php"]["start"];
$basepath = [ROOTDIR, "modules", "addons", "ispapidomaincheck"];

// load DCHelper class
require_once(implode(DIRECTORY_SEPARATOR, array_merge($basepath, ["lib", "Common", "DCHelper.class.php"])));

// Include module file
$modulepath = implode(DIRECTORY_SEPARATOR, array_merge($basepath, ["ispapidomaincheck.php"]));
if (!file_exists($modulepath)) {
    exit($modulepath . " not found");
}
require $modulepath;

// Call clientarea function
$modulevars = DCHelper::getAddOnConfigurationValue('ispapidomaincheck');

// Multi-Language Support
// https://developers.whmcs.com/addon-modules/multi-language/
// They are pointing out that WHMCS will care for loading language files
// whenever we are in addon context. Probably this file is specific as
// it is a different and non-addon entry point...
$defaultlang = "english";
$language = (isset($_SESSION["Language"]) ? $_SESSION["Language"] : $defaultlang);
$langbasepath = implode(DIRECTORY_SEPARATOR, array_merge($basepath, ["lang", ""]));
$langbasepathov = implode(DIRECTORY_SEPARATOR, array_merge($basepath, ["lang", "overrides", ""]));
$langfiles = [
    $langbasepathov . $language . ".php",
    $langbasepath . $language . ".php",
    $langbasepathov . $defaultlang . ".php",
    $langbasepath . $defaultlang . ".php"
];
foreach($langfiles as $langfile) {
    if (file_exists($langfile)) {
        include($langfile);
        break;
    }
}

$modulevars["_lang"] =  $_ADDONLANG;
$results = call_user_func(
    "ispapidomaincheck_clientarea",
    $modulevars
);

//respond XHR Requests in JSON
if ($isXHR) {
    header('Cache-Control: no-cache, must-revalidate'); // HTTP/1.1
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
    header('Content-type: application/json; charset=utf-8');
    echo $results;
    exit();
}

$ca = new WHMCS_ClientArea();
$ca->setPageTitle(Lang::trans("domaintitle"));
$ca->addToBreadCrumb('index.php', Lang::trans('globalsystemname'));
$ca->addToBreadCrumb('mydomainchecker.php', Lang::trans("domaintitle"));
$ca->initPage();
if (is_array($results["vars"])) {
    foreach ($results["vars"] as $k => $v) {
        $smartyvalues[$k] = $v;
    }
}
$tplpath = cnic_getTemplateDir(null, "ispapidomaincheck", "client");
$ca->setTemplate($tplpath . ($smartyvalues["error"] ? "error" : "index") . ".tpl");
$ca->output();
