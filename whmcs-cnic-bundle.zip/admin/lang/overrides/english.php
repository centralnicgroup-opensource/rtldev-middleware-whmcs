<?php
$_ADMINLANG['general']['suggesttldsinfo'] = (
    "<div style=\"margin:-20px 20px;text-align:justify;\">" .
    "Configure TLDs for the Domain Suggestion Engine to evaluate availability and present results alongside search queries. " .
    "<ul style=\"text-align:left;\">" .
    "<li>The selected TLDs are processed in their configured priority order from WHMCS domain pricing.</li>" .
    "<li>The first 10 prioritized TLDs are requested individually; the next up to 255 TLDs are requested in one additional batch.</li>" .
    "<li>Any selected TLDs beyond that limit are not included in the suggestion lookup.</li>" .
    "<li>For optimal performance, limit selections to business-relevant TLDs.</li>" .
    "<li>No selection required — if none are chosen, no TLDs will be submitted.</li>" .
    "</ul></div>"
);
