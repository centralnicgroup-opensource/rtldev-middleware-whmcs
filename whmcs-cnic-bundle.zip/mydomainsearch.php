<?php

if (extension_loaded("zlib") && !ini_get('zlib.output_compression')) {
    ob_start("ob_gzhandler");
}
define("CLIENTAREA", true);

require_once("init.php");

if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_REQUEST["domain"])) {
    $domain = $_REQUEST["domain"];
    $action = $_REQUEST["transfer"] === 1 ? "transfer" : "register";
    \App::redirect("mydomainsearch.php", "searchTerm={$domain}&action={$action}&referrer=whmcs");
}

$addon["Name"] = "cnicdomainsearch";
$addon["basePath"] = [ROOTDIR, "modules", "addons", $addon["Name"]];
$modulePath = implode(DIRECTORY_SEPARATOR, array_merge($addon["basePath"], [$addon["Name"] . ".php"]));

if (!file_exists($modulePath)) {
    exit($modulePath . " not found");
}

require_once($modulePath);
$safePostVars = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$isXHR = (isset($safePostVars["action"])
    || (isset($safePostVars["nodata"])
        && $safePostVars["nodata"] == 1
    )
);

// Call clientarea function
//$modulevars = DCHelper::getAddOnConfigurationValue($addon["Name"]);

// Multi-Language Support
// https://developers.whmcs.com/addon-modules/multi-language/
// They are pointing out that WHMCS will care for loading language files
// whenever we are in addon context. Probably this file is specific as
// it is a different and non-addon entry point...
$modulevars = [];
$addon["defaultlang"] = "english";
$addon["templatePath"] = rtrim(cnic_getTemplateDir(null, $addon["Name"]), "/");
$addon["language"] = ltrim($addon["templatePath"] . "/client_theme/languages/" . (isset($_SESSION["Language"]) ? $_SESSION["Language"] : $addon["defaultlang"]) . ".json", "/");
$addon["language"] = json_decode(file_get_contents($addon["language"]), true);
$modulevars["_lang"] =  $addon["language"];
$modulevars["POST_DATA"] = $safePostVars;
$modulevars["addon"] = $addon;
$results = cnicdomainsearch_clientarea($modulevars);

//respond XHR Requests in JSON
if ($isXHR) {
    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
    header("Content-type: application/json; charset=utf-8");
    echo $results;
    exit();
}

$ca = new WHMCS_ClientArea();
$ca->setPageTitle($modulevars["_lang"]["title"]);
$ca->addToBreadCrumb("index.php", Lang::trans("globalsystemname"));
$ca->addToBreadCrumb("mydomainsearch.php", $modulevars["_lang"]["title"]);
$ca->addonPath = $addon;
$ca->initPage();
if (is_array($results["vars"])) {
    foreach ($results["vars"] as $k => $v) {
        $smartyvalues[$k] = $v;
    }
}

$ca->setTemplate($addon["templatePath"] . "/" . ($smartyvalues["error"] ? "error" : "index") . ".tpl");
$ca->output();

if (extension_loaded("zlib") && !ini_get('zlib.output_compression')) {
    ob_end_flush();
}
