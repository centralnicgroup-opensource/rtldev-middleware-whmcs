## [16.1.1](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v16.1.0...v16.1.1) (2022-10-20)


### Bug Fixes

* **ispapi registrar module:** nameserver update patched ([da45fc5](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/da45fc5f721429f6f5a34018491c8a6086c66d84))

# [16.1.0](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v16.0.3...v16.1.0) (2022-10-20)


### Bug Fixes

* **cnic-ssl:** fix several issues and add PHP 8.1 compatibility ([65b76e9](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/65b76e9126a5f71f3528a0436151c2f24d89d370))


### Features

* **precheck addons:** automatically precheck addons on cart level page, feature added ([fdbba09](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/fdbba091533b78eeb081d32e9bcf6eec418429b6))

## [16.0.3](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v16.0.2...v16.0.3) (2022-10-19)


### Bug Fixes

* **gulp:** updated encryption files list ([150e603](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/150e603df47a2257b550be21144ebc665fb64451))

## [16.0.2](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v16.0.1...v16.0.2) (2022-10-19)


### Bug Fixes

* **domainchecker:** default categories import fix, build-release workflow fix, gulp config updated ([ff4b211](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/ff4b211d11e8fb34b897b984cad96b2043d39ca8))
* **ispapi domain search:** fix multi-year terms dropdown order (10Y now after 9Y) ([1918b72](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/1918b72d4f9936f53ab22b250e9b85bbb2318fda))

## [16.0.1](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v16.0.0...v16.0.1) (2022-10-19)


### Bug Fixes

* **tld-import:** skip tlds with no pricing ([2a58dbe](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/2a58dbe304fa69b8f6651b57d1a1ad5a6d3d0041))

# [16.0.0](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v15.9.9...v16.0.0) (2022-10-18)


### chore

* **restructuring:** in direction of a software bundle ([ac88ed6](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/ac88ed674da7c947d5874cd263337c52d70cb1a8))


### BREAKING CHANGES

* **restructuring:** Restructuring of all repositories into a single repository. Offering several benefits to us and our resellers.

# [16.0.0](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/v15.9.9...v16.0.0) (2022-10-18)


### chore

* **restructuring:** in direction of a software bundle ([ac88ed6](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/ac88ed674da7c947d5874cd263337c52d70cb1a8))


### BREAKING CHANGES

* **restructuring:** Restructuring of all repositories into a single repository. Offering several benefits to us and our resellers.
