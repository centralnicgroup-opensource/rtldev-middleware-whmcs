## [5.5.13](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.12...ibs-moniker-5.5.13) (2026-10-14)

### Upgrade Notes

* **CNIC DNS Manager Addon:** If the "KeyDNS Nameservers" setting of a CNIC registrar module contains an invalid entry, WHMCS will refuse to save that module's settings until the entry is corrected or the field is emptied to use the default nameservers.


### Bug Fixes

* **CNIC DNS Manager Addon:** send clients to their domain list when a domain cannot be managed ([25554db](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/25554db9a852b589512e01118fa732592558e6b5))

  When the DNS Manager is opened for a domain that cannot be managed there, for example a domain of another client account, a domain without DNS management or one not managed through a CentralNic registrar module, the client is now taken to their domain list. Previously they landed on the client area home page, and every such request added a 'requested template file ".tpl" which could not be found' entry to the WHMCS Activity Log. The redirect works with every Friendly URLs setting and for WHMCS installations in a subfolder.

  The DNS Manager no longer shows unreadable nameservers in its "This zone is not active" notice, and no longer reports a zone as inactive because of them. The "KeyDNS Nameservers" setting of the CNIC registrar module and of its additional account modules (cnic1, cnic2, ...) now ignores entries that are not valid nameserver hostnames, and uses the default nameservers ns1.dnsres.net, ns2.dnsres.net and ns3.dnsres.net when no valid entry is left. Saving the registrar settings with an invalid entry, for example nameservers separated by semicolons or spaces instead of commas, is now refused with a message naming the entry, so that it can be corrected.

## [5.5.12](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.11...ibs-moniker-5.5.12) (2026-10-13)

### Bug Fixes

* **CNIC DNS Manager Addon:** only let clients manage DNS of their own domains ([a083507](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/a08350757821f24a66d0651e70212e8cfc49cc00))

  The DNS Manager now checks that a domain belongs to the logged-in client before it shows or changes the domain's DNS records, web forwarding or zone file. Opening the DNS Manager for a domain of another client account, for example through an old link or after switching between client accounts, now returns to the client area instead of failing with "The domain name input is empty". We recommend installing this update.

  Web forwarding now also works for domains assigned to an additional CentralNic Reseller account (wrapper registrar modules such as cnic1 and cnic2). Until now the Web Forwarding page returned to the client area for these domains.

## [5.5.11](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.10...ibs-moniker-5.5.11) (2026-10-09)

### Bug Fixes

* **Internet.bs Registrar Module:** keep NS records when saving DNS in the client area ([1cd068f](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/1cd068fdd452427610dd2a9622378a7fc69c6cbc))

  Adding, editing or deleting a DNS record on the standard WHMCS DNS management page could remove the domain's NS records (for example topdns nameserver records). The page has no NS option in its record-type list, so existing NS records were sent back as the wrong type and removed on save.

  Record types the standard WHMCS page cannot display (NS, CAA, SRV, SSHFP, TLSA and others) are now left out of that page and are never changed when a client saves. They stay in place at the registrar.

  If you use the CNIC DNS Manager addon, nothing changes: all record types, including NS, stay visible and editable there.

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))
