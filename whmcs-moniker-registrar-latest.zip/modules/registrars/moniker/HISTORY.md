## [5.5.11](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.10...ibs-moniker-5.5.11) (2026-10-09)

### Bug Fixes

* **Internet.bs Registrar Module:** keep NS records when saving DNS in the client area ([1cd068f](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/1cd068fdd452427610dd2a9622378a7fc69c6cbc))

  Adding, editing or deleting a DNS record on the standard WHMCS DNS management page could remove the domain's NS records (for example topdns nameserver records). The page has no NS option in its record-type list, so existing NS records were sent back as the wrong type and removed on save.

  Record types the standard WHMCS page cannot display (NS, CAA, SRV, SSHFP, TLSA and others) are now left out of that page and are never changed when a client saves. They stay in place at the registrar.

  If you use the CNIC DNS Manager addon, nothing changes: all record types, including NS, stay visible and editable there.

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))

## [5.5.10](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/compare/ibs-moniker-5.5.9...ibs-moniker-5.5.10) (2026-07-24)


### Bug Fixes

* **ibs registrar module:** improved environment validation and shows system requirements banner in admin area ([8967192](https://github.com/centralnicgroup/rtldev-middleware-whmcs-src/commit/896719210efb564e92b3993b905371e84cf67d0f))
