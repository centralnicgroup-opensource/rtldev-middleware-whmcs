<?php

use WHMCS\Module\Registrar\Moniker\HookMgr;

/**
 * Validate Additional Fields as part of ShoppingCartValidateDomainsConfig Hook
 * Error messages are returned as an array - if empty, no errors
 *
 * @param array<string,mixed> $params WHMCS input parameters
 * @return array<string>
 */
function moniker_validateAdditionalFields($params)
{
    return HookMgr::invoke("shoppingCartValidateDomainsConfig", $params);
}
HookMgr::subscribe("ShoppingCartValidateDomainsConfig", "moniker_validateAdditionalFields");

/**
 * Automatically add the include statement for additional fields configuration file
 *
 * @param array<string,mixed> $vars WHMCS input parameters for ClientAreaPageDomain* hooks
 * @return void
 */
function moniker_autoAdditionalFieldsInclude($vars)
{
    HookMgr::invoke("autoAdditionalFieldsInclude", $vars);
}
HookMgr::subscribe("AfterCronJob", "moniker_autoAdditionalFieldsInclude");

/**
 * Validate fields when user perform final checkout as part of ShoppingCartValidateCheckout Hook
 * Error messages are returned as an array - if empty, no errors
 *
 * @param array<string,mixed> $params WHMCS input parameters
 * @return array<string>
 */
function moniker_shoppingCartValidateCheckout($params)
{
    return HookMgr::invoke("shoppingCartValidateCheckout", $params);
}
HookMgr::subscribe("ShoppingCartValidateCheckout", "moniker_shoppingCartValidateCheckout");

/**
 * Remove Menu Entry "Registrar Lock Status" if not supported by TLD
 *
 * @param array<string,mixed> $vars WHMCS input parameters for ClientAreaPageDomain* hooks
 * @return array<string,mixed>
 */
function moniker_clientAreaPageDomainMenuRemoval($vars)
{
    return HookMgr::invoke("clientAreaPageDomainMenuRemoval", $vars);
}
HookMgr::subscribe("ClientAreaPageDomain*", "moniker_clientAreaPageDomainMenuRemoval");
