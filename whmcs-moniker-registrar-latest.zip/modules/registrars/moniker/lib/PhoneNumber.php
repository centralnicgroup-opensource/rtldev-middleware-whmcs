<?php

namespace WHMCS\Module\Registrar\Moniker;

class PhoneNumber
{
    /**
     * Get Country Phone Code by Country Code
     *
     * @param string $countryCode 2-letter country code e.g. US, DE, FR
     * @return int
     */
    private static function getCountryPhoneCode($countryCode)
    {
        static $mapc = [
            "US" => 1, "CA" => 1, "AI" => 1, "AG" => 1, "BB" => 1, "BS" => 1, "VG" => 1, "VI" => 1, "KY" => 1, "BM" => 1, "GD" => 1, "TC" => 1, "MS" => 1, "MP" => 1, "GU" => 1, "LC" => 1, "DM" => 1, "VC" => 1, "PR" => 1, "DO" => 1, "TT" => 1, "KN" => 1, "JM" => 1, "EG" => 20, "MA" => 212, "DZ" => 213, "TN" => 216, "LY" => 218, "GM" => 220, "SN" => 221, "MR" => 222, "ML" => 223, "GN" => 224, "CI" => 225, "BF" => 226, "NE" => 227, "TG" => 228, "BJ" => 229, "MU" => 230, "LR" => 231, "SL" => 232, "GH" => 233, "NG" => 234, "TD" => 235, "CF" => 236, "CM" => 237, "CV" => 238, "ST" => 239, "GQ" => 240, "GA" => 241, "CG" => 242, "CD" => 243, "AO" => 244, "GW" => 245, "IO" => 246, "AC" => 247, "SC" => 248, "SD" => 249, "RW" => 250, "ET" => 251, "SO" => 252, "DJ" => 253, "KE" => 254, "TZ" => 255, "UG" => 256, "BI" => 257, "MZ" => 258, "ZM" => 260, "MG" => 261, "RE" => 262, "ZW" => 263, "NA" => 264, "MW" => 265, "LS" => 266, "BW" => 267, "SZ" => 268, "KM" => 269, "YT" => 269, "ZA" => 27, "SH" => 290, "ER" => 291, "AW" => 297, "FO" => 298, "GL" => 299, "GR" => 30, "NL" => 31, "BE" => 32, "FR" => 33, "ES" => 34, "GI" => 350, "PT" => 351, "LU" => 352, "IE" => 353, "IS" => 354, "AL" => 355, "MT" => 356, "CY" => 357, "FI" => 358, "BG" => 359, "HU" => 36, "LT" => 370, "LV" => 371, "EE" => 372, "MD" => 373, "AM" => 374, "BY" => 375, "AD" => 376, "MC" => 377, "SM" => 378, "VA" => 379, "UA" => 380, "CS" => 381, "YU" => 381, "HR" => 385, "SI" => 386, "BA" => 387, "EU" => 388, "MK" => 389, "IT" => 39, "RO" => 40, "CH" => 41, "CZ" => 420, "SK" => 421, "LI" => 423, "AT" => 43, "GB" => 44, "DK" => 45, "SE" => 46, "NO" => 47, "PL" => 48, "DE" => 49, "FK" => 500, "BZ" => 501, "GT" => 502, "SV" => 503, "HN" => 504, "NI" => 505, "CR" => 506, "PA" => 507, "PM" => 508, "HT" => 509, "PE" => 51, "MX" => 52, "CU" => 53, "AR" => 54, "BR" => 55, "CL" => 56, "CO" => 57, "VE" => 58, "GP" => 590, "BO" => 591, "GY" => 592, "EC" => 593, "GF" => 594, "PY" => 595, "MQ" => 596, "SR" => 597, "UY" => 598, "AN" => 599, "MY" => 60, "AU" => 61, "CC" => 61, "CX" => 61, "ID" => 62, "PH" => 63, "NZ" => 64, "SG" => 65, "TH" => 66, "TL" => 670, "AQ" => 672, "NF" => 672, "BN" => 673, "NR" => 674, "PG" => 675, "TO" => 676, "SB" => 677, "VU" => 678, "FJ" => 679, "PW" => 680, "WF" => 681, "CK" => 682, "NU" => 683, "AS" => 684, "WS" => 685, "KI" => 686, "NC" => 687, "TV" => 688, "PF" => 689, "TK" => 690, "FM" => 691, "MH" => 692, "RU" => 7, "KZ" => 7, "XF" => 800, "XC" => 808, "JP" => 81, "KR" => 82, "VN" => 84, "KP" => 850, "HK" => 852, "MO" => 853, "KH" => 855, "LA" => 856, "CN" => 86, "XS" => 870, "XE" => 871, "XP" => 872, "XI" => 873, "XW" => 874, "XU" => 878, "BD" => 880, "XG" => 881, "XN" => 882, "TW" => 886, "TR" => 90, "IN" => 91, "PK" => 92, "AF" => 93, "LK" => 94, "MM" => 95, "MV" => 960, "LB" => 961, "JO" => 962, "SY" => 963, "IQ" => 964, "KW" => 965, "SA" => 966, "YE" => 967, "OM" => 968, "PS" => 970, "AE" => 971, "IL" => 972, "BH" => 973, "QA" => 974, "BT" => 975, "MN" => 976, "NP" => 977, "XR" => 979, "IR" => 98, "XT" => 991, "TJ" => 992, "TM" => 993, "AZ" => 994, "GE" => 995, "KG" => 996, "UZ" => 998
        ];

        if (isset($mapc[$countryCode])) {
            return $mapc[$countryCode];
        }
        return 1;
    }

    /**
     * Check if the given phone number is valid
     *
     * @param string $phoneNumber Phone Number
     * @return bool
     */
    public static function isValid($phoneNumber)
    {
        $phoneNumber = str_replace(" ", "", $phoneNumber);
        $phoneNumber = str_replace("\t", "", $phoneNumber);
        return (bool)preg_match("/^\+[0-9]{1,4}\.[0-9 ]+$/is", $phoneNumber);
    }

    /**
     * validate phone number
     * TODO: no use to have a isValid and a validate method that do the different things but have the same meaning
     * @param string $phoneNumber phone number
     * @return bool
     */
    public static function validate($phoneNumber)
    {
        $phone = explode(".", $phoneNumber);
        if (count($phone) > 1) {
            $phone = $phone[1];
        } else {
            $phone = $phoneNumber;
        }
        return !((strlen($phone) < 4) || (strlen($phone) >  13));
    }

    /**
     * Reformat phone number
     *
     * @param string $phoneNumber Phone Number
     * @param string $countryCode 2-letter country code e.g. US, DE, FR
     * @return string
     */
    public static function reformat($phoneNumber, $countryCode)
    {
        $scontrol = trim($phoneNumber);

        /* If empty phone number, return as it is*/
        $l = strlen($scontrol);
        if (!$l) {
            return $phoneNumber;
        }

        $plus = ($scontrol[0] === "+");
        $countryPhoneCode = (string)self::getCountryPhoneCode($countryCode);

        /* check if first character is + */
        if ($plus) {
            $phoneExplode = explode(".", $scontrol);
            if (count($phoneExplode) > 1) {
                /* IF country code is added in phone numnber*/
                $countryPhoneCode = ltrim($phoneExplode[0], "+");
                $scontrol = $phoneExplode[1];
                $plus = false;
            }
        }

        /* Remove non-digit character from string */
        $scontrol = preg_replace("#\D*#si", "", $scontrol);
        if (is_null($scontrol)) {
            return $phoneNumber;
        }

        /*if original phone number has + sign, add it again*/
        if ($plus) {
            $scontrol = "+" . $scontrol;
        }

        /* check if first 2 digit is 00, replace 00 with +*/
        if (strncmp($scontrol, "00", 2) === 0) {
            $scontrol = "+" . substr($scontrol, 2);
            /* If only 00 is entered, pass it to api and it will return invalid */
            if (strlen($scontrol) === 1) {
                return $phoneNumber;
            }
        }

        /* If first digit is +, find countrycode from that string, and prepend it in phone number */
        if ($scontrol[0] === "+") {
            for ($i = 2; $i < strlen($scontrol); $i++) {
                $first = substr($scontrol, 1, $i - 1);
                if ($first === $countryPhoneCode) {
                    return "+" . $first . "." . substr($scontrol, $i);
                }
            }
            $scontrol = trim($scontrol, "+");
        }

        $rphone = "+" . $countryPhoneCode . "." . $scontrol;
        if (self::isValid($rphone)) {
            $countryCodeLength = strlen($countryPhoneCode);
            if (substr($phoneNumber, 0, $countryCodeLength) === $countryPhoneCode) {
                $myPhoneNumber = substr($phoneNumber, $countryCodeLength);
                $myPhoneNumber = preg_replace("/[^0-9,.]/", "", $myPhoneNumber);
                $rphone = "+" . $countryPhoneCode . "." . $myPhoneNumber;
            }
            return $rphone;
        }
        return $phoneNumber;
    }
}
