<?php

namespace WHMCS\Module\Registrar\Moniker;

class WidgetBalance
{
    /** @var array<string,mixed> */
    private $data = [];
    /** @var string */
    private $widgetid = null;
    /** @var string */
    private $registrarid = null;
    /** @var array<string,mixed> */
    private $currency = [];
    /** @var float */
    private $lowBalanceThreshold = 0; // threshold for low balance
    /**
     * Constructor
     *
     * @param string $widgetid the widget id
     * @param string $registrarid the registrar id
     * @param array<string,mixed> $params common module parameters
     */
    public function __construct($widgetid, $registrarid, $params)
    {
        $this->widgetid = $widgetid;
        $this->registrarid = $registrarid;

        /**
         * @codeCoverageIgnore
         */
        // init status
        if (isset($_SESSION[$this->widgetid]["data"])) { // data cache exists
            $this->data = $_SESSION[$this->widgetid]["data"];
        } else {
            // fetch data from registrar
            $fn = $this->registrarid . "_getAccountDetails";
            if (!function_exists($fn)) {
                return;
            }
            $accountsStatus = $fn($params);
            if ($accountsStatus["status"] === "SUCCESS") {
                // Collect all balances and currencies
                $balances = [];
                $defaultCurrencyCode = "USD";
                $defaultTotal = 0;
                $exchangeRates = \WHMCS\Utility\CurrencyExchange::fetchCurrentRates();
                foreach ($accountsStatus as $key => $value) {
                    if (preg_match('/^balance_(\d+)_currency$/', $key, $matches)) {
                        $idx = $matches[1];
                        $currency = $value;
                        $amountKey = "balance_{$idx}_amount";
                        if (isset($accountsStatus[$amountKey])) {
                            $amount = $accountsStatus[$amountKey];
                            $balances[] = [
                                "currency" => $currency,
                                "amount" => $amount,
                            ];
                            $defaultTotal += $amount * $exchangeRates->getUsdExchangeRate($currency);
                        }
                    }
                }
                // Store all balances in $this->data
                $this->data["balances"] = $balances;
                // Optionally, set the first balance as default for backward compatibility
                if ($balances && count($balances) > 1) {
                    $this->data["amount"] = $defaultTotal;
                    $this->data["currency"] = $defaultCurrencyCode;
                } else {
                    $this->data["amount"] = $balances[0]["amount"] ?? 0;
                    $this->data["currency"] = $balances[0]["currency"] ?? "USD";
                }
                $this->data["lastUpdated"] = date("Y-m-d H:i:s");
                $_SESSION[$this->widgetid]["data"] = $this->data;
            }
        }

        // init currency
        $currencies = localAPI("GetCurrencies", []);
        $currenciesAsAssocList = [];
        if ($currencies["result"] === "success") {
            foreach ($currencies["currencies"]["currency"] as $idx => $d) {
                $currenciesAsAssocList[$d["code"]] = $d;
            }
        }
        $this->currency  = $currenciesAsAssocList;
    }

    /**
     * get balance data
     * @return array<string,mixed>
     */
    public function getData(): array
    {
        $amount = floatval($this->data["amount"]);
        $currency = $this->data["currency"];
        $currencyid = $this->currency[$currency]["id"] ?? null;
        return [
            "amount" => $amount,
            "currency" => $currency,
            "currencyID" => $currencyid,
            "lastUpdated" => $this->data["lastUpdated"] ?? null,
            "balances" => $this->data["balances"] ?? [],
        ];
    }

    /**
     * get formatted balance data
     * @return array<string,mixed>
     */
    public function getDataFormatted(): ?array
    {
        $data = $this->getData();
        if (is_null($data["currencyID"])) {
            $formattedAmount = number_format($data["amount"], 2, ".", ",") . " " . $data["currency"];
        } else {
            $formattedAmount = formatCurrency($data["amount"], $data["currencyID"]);
        }
        return [
            "amount" => $formattedAmount,
            "rawAmount" => $data["amount"],
            "balances" => $data["balances"],
            "lastUpdated" => $data["lastUpdated"],
        ];
    }

    /**
     * generate balance as HTML
     * @return string
     */
    public function toHTML(): string
    {
        $data = $this->getDataFormatted();
        if (is_null($data)) {
            return <<<HTML
<div class="widget-content-padded widget-billing">
    <div class="alert alert-danger">
        <i class="fa fa-exclamation-triangle"></i> Loading Account Data failed.
    </div>
</div>
HTML;
        }

        $balanceColor = (floatval($data["rawAmount"]) < $this->lowBalanceThreshold) ? "text-danger" : "text-success";
        $html = <<<HTML
<div class="widget-content-padded widget-billing">
    <!-- Main Balance Display -->
    <div class="text-center" style="margin-bottom: 10px;">
        <h2 class="{$balanceColor}" style="margin: 0;padding: 0;">
            {$data["amount"]}
        </h2>
        <div class="text-muted small">Account Balance</div>
    </div>
HTML;

        // Enhanced multi-currency display if multiple balances exist
        if (!empty($data["balances"]) && count($data["balances"]) > 1) {
            $html .= <<<HTML
    
    <!-- Currency Breakdown -->
    <div class="text-center">
HTML;

            foreach ($data["balances"] as $index => $bal) {
                $currency = htmlspecialchars($bal["currency"]);
                $amount = number_format(floatval($bal["amount"]), 2, ".", ",");
                $isNegative = floatval($bal["amount"]) < $this->lowBalanceThreshold;
                $labelClass = $isNegative ? "label-danger" : "label-default";

                $html .= <<<HTML
        <span class="label {$labelClass}" style="margin: 2px; display: inline-block;">
            {$currency} {$amount}
        </span>
HTML;
            }

            $html .= <<<HTML
    </div>
HTML;
        }

        $html .= <<<HTML
    
    <!-- Additional Info -->
    <div class="text-center">
        <small class="text-muted">
            <i class="fa fa-info-circle"></i>
            Balances are updated from your registrar account.
            <br>
            <i class="fa fa-clock-o"></i>
            Last updated: {$this->data["lastUpdated"]}
        </small>
    </div>
</div>
HTML;

        return $html;
    }
}
