<div class="card">
	<div class="card-body">
		<div class="mb-4">
			<h3 class="mb-2">Web Forwarding</h3>
			<p class="text-muted">Manage web forwarding rules for <strong>{$domainName}</strong></p>
		</div>

		{if $errormessage}
			<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<i class="fa fa-exclamation-circle"></i> {$errormessage}
			</div>
		{/if}

		{if $success}
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<i class="fa fa-check-circle"></i> Changes saved successfully
			</div>
		{/if}

		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<i class="fa fa-exchange"></i> Forwarding Rules
				</h4>
			</div>
			<div class="panel-body">
				<form method="post" action="clientarea.php?action=domaindetails&id={$domainid}&modop=custom&a=domainurlforwarding" id="frmWebForwarding">
					<input type="hidden" name="id" value="{$domainid}" />
					<input type="hidden" name="modop" value="custom"/>
					<input type="hidden" name="a" value="domainurlforwarding"/>

					<div class="table-responsive">
						<table class="table table-striped table-hover">
							<thead>
								<tr>
									<th style="width: 35%;">Hostname</th>
									<th style="width: 5%;"></th>
									<th style="width: 25%;">Type</th>
									<th style="width: 35%;">Target URL</th>
								</tr>
							</thead>
							<tbody>
								{for $cnt=0 to $data|@count}
									<tr>
										<td>
											<input class="form-control" type="text" name="dnsrecordhost[]" 
												value="{$data[$cnt].hostname}" 
												placeholder="@ or subdomain" />
										</td>
										<td style="vertical-align: middle; text-align: center;">
											<span class="text-muted">.{$domainName}</span>
										</td>
								<td>
									<select class="form-control" name="dnsrecordtype[]">
										<option value="URL" {if $data[$cnt].type == "URL"}selected{/if}>
											URL Redirect
										</option>
										<option value="FRAME" {if $data[$cnt].type == "FRAME"}selected{/if}>
											URL Frame
										</option>
									</select>
									</td>
										<td>
											<input class="form-control" name="dnsrecordaddress[]" type="text" 
												value="{$data[$cnt].address}" 
												placeholder="https://example.com" />
										</td>
									</tr>
								{/for}
							</tbody>
						</table>
					</div>

					<div class="text-center mt-3">
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-save"></i> Save Changes
						</button>
						<a href="clientarea.php?action=domaindetails&id={$domainid}" class="btn btn-default">
							<i class="fa fa-arrow-left"></i> Back
						</a>
					</div>
				</form>

				<div class="help-block mt-3">
					<p class="text-muted">
						<i class="fa fa-info-circle"></i> 
						<strong>URL Redirect:</strong> Redirects visitors to the target URL (visible in browser address bar)
						<br>
						<i class="fa fa-info-circle"></i> 
						<strong>URL Frame:</strong> Shows target URL within a frame (keeps your domain in address bar)
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
