<?php

// #########################################################################
// #########################################################################
// CentralNic DNS Manager Addon Language File - English
// #########################################################################
// #########################################################################

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

$_ADDONLANG = [];
// Add Record
$_ADDONLANG["addRecord"] = "Add Record";
// TTL
$_ADDONLANG["ttl"] = "TTL";
// Type
$_ADDONLANG["type"] = "Type";
// Priority
$_ADDONLANG["priority"] = "Priority";
// Address
$_ADDONLANG["address"] = "Address";
// Hostname
$_ADDONLANG["hostname"] = "Hostname";
// No DNS Records Found
$_ADDONLANG["noDnsRecordsFound"] = "No DNS records found.";
// Add Record Form
$_ADDONLANG["addRecordNameLabel"] = "Name";
$_ADDONLANG["addRecordContentLabel"] = "Content";
$_ADDONLANG["addRecordCancelBtn"] = "Cancel";
$_ADDONLANG["addRecordSaveBtn"] = "Save";
// Add Record Validation
$_ADDONLANG["hostRequired"] = "Host is required.";
$_ADDONLANG["addressRequired"] = "Address is required.";
// Copy to Clipboard
$_ADDONLANG["copyAddress"] = "Copy to clipboard";
$_ADDONLANG["copiedToClipboard"] = "Copied";
// Zone Import / Export Controls
$_ADDONLANG["searchDnsRecordsPlaceholder"] = "Search DNS Records";
$_ADDONLANG["addRecordBtn"] = "Add record";
$_ADDONLANG["importDnsRecordsTitle"] = "Import DNS records";
$_ADDONLANG["importDnsRecordsDesc"] = "Upload a zone file to import DNS records";
$_ADDONLANG["importWarningLabel"] = "Important:";
$_ADDONLANG["importWarningText"] = "Importing a zone file will replace all existing DNS records. Make sure to export your current records first if you need to keep a backup.";
$_ADDONLANG["applyImportedRecordsBtn"] = "Apply Imported Records";
$_ADDONLANG["exportDnsRecordsTitle"] = "Export DNS records";
$_ADDONLANG["exportDnsRecordsDesc"] = "Download all DNS records as a zone file in standard format";
$_ADDONLANG["exportZoneFileBtn"] = "Export Zone File";
// Key DNS Message
$_ADDONLANG["keyDnsMsg"] = "This zone is not active because your domain does not have the correct nameservers configured.<br>Please set your nameservers to: ";
// DNSSEC Management for DNS Zone
$_ADDONLANG["dnszoneDnssecManagement"] = "DNSSEC Management for DNS Zone";
// View DNSSEC Records
$_ADDONLANG["viewDnssecRecords"] = "View DNSSEC Records";
// Oops Error
$_ADDONLANG["oopsError"] = "Oops! An error occurred.";
// DNSSEC Pending
$_ADDONLANG["dnssecPending"] = "Signing Process is PENDING";
// DNSSEC Inactive Message
$_ADDONLANG["dnssecInactiveMessage"] = "<b>DNSSEC IS NOT ACTIVE</b>";
// Auto Activate Button — pushes DS records from the signed DNS zone to the domain registrar for the first time
$_ADDONLANG["autoActivateBtn"] = "Push DS Records to Domain";
// Auto Update Button — updates the domain registrar's DS records after a KSK rollover
$_ADDONLANG["autoUpdateBtn"] = "Update DS Records on Domain";
// DNSSEC Sign Zone Button (replaces generic "Enable")
$_ADDONLANG["dnssecSignZoneBtn"] = "Sign DNS Zone &amp; Generate ZSK/KSK Keys";
// DNSSEC keys table column headers
$_ADDONLANG["dnssecKeyType"] = "Type";
$_ADDONLANG["dnssecKeyStatus"] = "Status";
$_ADDONLANG["dnssecDsRecord"] = "DS Record (SHA-256)";
$_ADDONLANG["dnssecAction"] = "Action";
// KSK rollover action buttons
$_ADDONLANG["dnssecRolloverKskBtn"] = "Rollover KSK";
$_ADDONLANG["dnssecRolloverKskTooltip"] = "Initiate a KSK rollover. A new Key Signing Key will be generated. You will then need to submit the new DS record to the parent zone and complete the rollover. Recommended every 1-2 years.";
$_ADDONLANG["dnssecFinishRolloverBtn"] = "Complete Rollover";
$_ADDONLANG["dnssecZskAutomatic"] = "Automatic";
// DNSSEC keys table labels & tooltips
$_ADDONLANG["dnssecKeysTitle"] = "DNSSEC Keys";
$_ADDONLANG["dnssecKeysCountLabel"] = "keys";
$_ADDONLANG["dnssecCopyTooltip"] = "Copy to clipboard";
$_ADDONLANG["dnssecZskAutoTooltip"] = "The ZSK is rotated automatically by the platform";
$_ADDONLANG["dnssecSignZoneTooltip"] = "Signs your DNS zone and generates ZSK/KSK cryptographic keys. DS records will then be available for registrar-level activation. May take up to 48 hours.";
$_ADDONLANG["dnssecDisableTooltip"] = "Removes the cryptographic signing from your DNS zone. DNSSEC protection will be deactivated.";
// DNSSEC per-key status badges and descriptions (mirror the CNR control panel)
$_ADDONLANG["dnssecStatusPending"] = "PENDING";
$_ADDONLANG["dnssecStatusReady"] = "READY";
$_ADDONLANG["dnssecStatusActive"] = "ACTIVE";
$_ADDONLANG["dnssecDescPending"] = "Waiting for DNS propagation (pending acknowledgement).";
$_ADDONLANG["dnssecDescActivating"] = "Key activation in progress.";
$_ADDONLANG["dnssecDescConfigured"] = "DNSSEC successfully configured.";
// DNSSEC: info panel shown when the zone is not yet signed
$_ADDONLANG["dnssecNotSignedInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>Your DNS zone is capable of using DNSSEC.</strong>
            <p class="mb-1 mt-1">Clicking <em>Sign DNS Zone &amp; Generate ZSK/KSK Keys</em> will:</p>
            <ul class="mb-2 pl-3">
                <li>Cryptographically sign your DNS zone</li>
                <li>Automatically generate a <b>ZSK</b> (Zone Signing Key) and <b>KSK</b> (Key Signing Key)</li>
                <li>Produce <b>DS records</b> that are then published at the registrar level to complete DNSSEC activation</li>
            </ul>
            <div class="text-muted small">
                <i class="fas fa-clock mr-1"></i> This process may take up to <b>48 hours</b> to complete.
                Once signed, DS records will be automatically imported into your domain\'s DNSSEC settings.
            </div>
        </div>
    </div>
';
// DNSSEC: info panel shown when signing is in progress (pending)
$_ADDONLANG["dnssecPendingInfo"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-hourglass-half text-warning mr-3 mt-1" style="font-size: 1.2rem; flex-shrink:0;"></i>
        <div>
            <strong>The zone signing process has been initiated.</strong>
            <p class="mb-1 mt-1">ZSK/KSK Keys are being generated. This may take up to <b>48 hours</b> to complete.</p>
            <div class="text-muted small">
                Once signing is complete, DS records will appear here and can be published at the registrar level.
                No further action is needed at this time.
            </div>
        </div>
    </div>
';
// DNSSEC Active Message
$_ADDONLANG["dnssecActiveMessage"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-info-circle text-info mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC is <span class="font-weight-bold">active</span> on your DNS zone.
            </strong>
            <div class="text-info mb-2">
                However, the DNSSEC records on your domain may not match those in your DNS zone.
            </div>
            <div class="text-muted mb-2">
                <em>Tip:</em> You can manage DNSSEC in the 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC Management</u>
                </a> section.
            </div>
            <div class="text-muted">
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';
// DNSSEC DS Data Matches and Signed
$_ADDONLANG["dnssecDataMatchesAndSigned"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-check-circle text-success mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success mb-2 d-block">
                Great news! DNSSEC is fully active and secured for your domain.
            </strong>
            <div class="text-success mb-2">
                The DNSSEC records in your DNS zone and on your domain are signed and matched.
            </div>
            <div class="text-info mb-2">
                No further action is needed.
            </div>
            <div class="text-muted">
                <em>Tip:</em> You can 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>view and manage your DNSSEC records</u>
                </a> anytime in the DNSSEC Management section. 
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';
// DNSSEC DS Signed Pending
$_ADDONLANG["dnssecSignedPending"] = '
    <div class="d-flex align-items-start">
        <i class="fas fa-clock text-warning mr-3" style="font-size: 1.5rem;"></i>
        <div class="flex-grow-1">
            <strong class="text-success d-block mb-2">
                DNSSEC is active on your DNS zone, and your activation request has been received.
            </strong>
            <div class="text-success mb-2">
                The DNSSEC records in your DNS zone are now synced with your domain.
            </div>
            <div class="text-info mb-2">
                No further action is required at this moment, but you can update the records manually if needed.
            </div>
            <div class="text-muted mb-2">
                <em>Tip:</em> Manage your DNSSEC settings in the 
                <a href="#dnssecmanagementlink_placeholder#" class="alert-link">
                    <u>DNSSEC Management</u>
                </a> section.
            </div>
            <div class="text-muted">
                DNSSEC changes may take up to <b>24-48 hours</b> to propagate across the internet due to DNS propagation delays.
            </div>
        </div>
    </div>
';

// Web Forwarding
$_ADDONLANG["webForwardingProcessingMessage"] = "Processing...";
$_ADDONLANG["webForwardingAddNew"] = "Add New Web Forwarding";
$_ADDONLANG["webForwardingUrlType"] = "URL Redirect";
$_ADDONLANG["webForwardingFrameType"] = "URL Frame";
$_ADDONLANG["webForwardingTrdType"] = "Temporary Redirect";
$_ADDONLANG["webForwardingTargetHelp"] = "Enter the full URL including http:// or https://";
$_ADDONLANG["webForwardingUrlDescription"] = "Redirects to the target URL (visible in address bar)";
$_ADDONLANG["webForwardingFrameDescription"] = "Shows target URL within a frame (hides target in address bar)";
$_ADDONLANG["webForwardingTrdDescription"] = "Temporary redirect (HTTP 302) - useful for temporary moves";
$_ADDONLANG["webForwardingCancelButton"] = "Cancel";
$_ADDONLANG["webForwardingGetStarted"] = "Create your first web forwarding rule to redirect or frame your domain.";
$_ADDONLANG["webForwardingSource"] = "Source";
$_ADDONLANG["webForwardingTargetLabel"] = "Target";
$_ADDONLANG["webForwardingEdit"] = "Edit";
$_ADDONLANG["webForwardingDelete"] = "Delete";
$_ADDONLANG["webForwardingNoRecordsTitle"] = "No Web Forwarding Configured";
$_ADDONLANG["webForwardingCreateButton"] = "Create Web Forwarding";
$_ADDONLANG["webForwardingDeleteConfirm"] = "Confirm Deletion";
$_ADDONLANG["webForwardingSourceHostname"] = "Source Hostname";
$_ADDONLANG["webForwardingTargetUrl"] = "Target URL";
$_ADDONLANG["webForwardingSourcePlaceholder"] = "@ or www";
$_ADDONLANG["webForwardingTargetPlaceholder"] = "https://www.example.com/path";
$_ADDONLANG["webForwardingRootDomainInfo"] = "Use @ for root domain or enter a valid subdomain";
// SOA settings of the DNS zone
$_ADDONLANG["soaBtn"] = "Zone settings";
$_ADDONLANG["soaDesc"] = "The defaults suit most zones. Empty fields keep their current value.";
$_ADDONLANG["soaLabelSOAMNAME"] = "Primary Nameserver (MName)";
$_ADDONLANG["soaHelpSOAMNAME"] = "Managed by the DNS platform, cannot be changed.";
$_ADDONLANG["soaLabelSOARNAME"] = "Responsible Mailbox (RName)";
$_ADDONLANG["soaHelpSOARNAME"] = "Email address of the zone administrator, written with a dot instead of the @ (admin.example.com). An email address is converted automatically.";
$_ADDONLANG["soaLabelSOAREFRESH"] = "Refresh";
$_ADDONLANG["soaHelpSOAREFRESH"] = "How often secondary nameservers check for zone updates";
$_ADDONLANG["soaLabelSOARETRY"] = "Retry";
$_ADDONLANG["soaHelpSOARETRY"] = "How long secondary nameservers wait before retrying a failed refresh";
$_ADDONLANG["soaLabelSOAEXPIRE"] = "Expire";
$_ADDONLANG["soaHelpSOAEXPIRE"] = "How long secondary nameservers keep answering when the primary nameserver can't be reached";
$_ADDONLANG["soaLabelSOAMINTTL"] = "Minimum TTL";
$_ADDONLANG["soaHelpSOAMINTTL"] = "How long resolvers may cache negative answers (like NXDOMAIN); lower values make new records visible sooner";
$_ADDONLANG["soaAllowed"] = "Allowed:";
$_ADDONLANG["soaSeconds"] = "seconds";
$_ADDONLANG["soaSaveBtn"] = "Save";
$_ADDONLANG["soaSaved"] = "SOA settings saved successfully.";
$_ADDONLANG["soaInvalid"] = "Please correct the highlighted values.";
// DNS Manager redesign: toolbar, popovers, record form, confirmations (record type formats stay as they are)
$_ADDONLANG["importBtn"] = "Import";
$_ADDONLANG["exportBtn"] = "Export";
$_ADDONLANG["moreActionsBtn"] = "More actions";
$_ADDONLANG["moreZoneDesc"] = "SOA timing and responsible mailbox";
$_ADDONLANG["moreImportDesc"] = "Replace all records from a BIND zone file";
$_ADDONLANG["moreExportDesc"] = "Download all records as a BIND zone file";
$_ADDONLANG["filterByType"] = "Filter by type";
$_ADDONLANG["jsEdit"] = "Edit";
$_ADDONLANG["jsClose"] = "Close";
$_ADDONLANG["jsSave"] = "Save";
$_ADDONLANG["jsAdd"] = "Add record";
$_ADDONLANG["jsAll"] = "All";
$_ADDONLANG["jsRecordAdded"] = "Record added";
$_ADDONLANG["jsRecordSaved"] = "Record saved";
$_ADDONLANG["jsRecordDeleted"] = "Record deleted";
$_ADDONLANG["jsZoneExported"] = "Zone file downloaded";
$_ADDONLANG["jsRecordsImported"] = "Records imported";
$_ADDONLANG["jsDeleteConfirm"] = "Delete this record? This takes effect immediately.";
$_ADDONLANG["jsDeleteKeep"] = "Keep";
$_ADDONLANG["jsDeleteBtn"] = "Delete";
$_ADDONLANG["jsDiscardChanges"] = "Discard your changes to this record?";
$_ADDONLANG["jsNamePlaceholder"] = "[name]";
$_ADDONLANG["jsValuePlaceholder"] = "[value]";
$_ADDONLANG["jsSummaryAddress"] = "{name} points to {value}";
$_ADDONLANG["jsSummaryAlias"] = "{name} is an alias of {value}";
$_ADDONLANG["jsSummaryRedirect"] = "Subdomains of {name} are redirected to {value}";
$_ADDONLANG["jsSummaryMail"] = "Mail for {name} is delivered to {value} (priority {priority})";
$_ADDONLANG["jsSummaryDelegation"] = "{name} is delegated to the nameserver {value}";
$_ADDONLANG["jsSummaryText"] = "{name} has the text value {value}";
$_ADDONLANG["jsSummaryDefault"] = "{name} has the {type} value {value}";
$_ADDONLANG["jsTypeLabelA"] = "IPv4 address";
$_ADDONLANG["jsTypeLabelAAAA"] = "IPv6 address";
$_ADDONLANG["jsTypeLabelALIAS"] = "Target host name";
$_ADDONLANG["jsTypeLabelCNAME"] = "Target host name";
$_ADDONLANG["jsTypeLabelDNAME"] = "Target domain";
$_ADDONLANG["jsTypeLabelMX"] = "Mail server";
$_ADDONLANG["jsTypeLabelMXE"] = "Mail server IPv4 address";
$_ADDONLANG["jsTypeLabelNS"] = "Nameserver";
$_ADDONLANG["jsTypeLabelPTR"] = "Host name";
$_ADDONLANG["jsTypeLabelTXT"] = "Text value";
$_ADDONLANG["jsTypeLabelSPF"] = "SPF value";
$_ADDONLANG["jsTypeLabelDefault"] = "Value";
$_ADDONLANG["jsTypeHelpSRV"] = "Format: weight port target";
$_ADDONLANG["jsTypeExampleSRV"] = "Example: 5 5060 jabber.example.com";
$_ADDONLANG["jsTypeHelpSVCB"] = "Format: target [params]";
$_ADDONLANG["jsTypeExampleSVCB"] = "Example: svc.example.net. port=443 ipv4hint=192.0.2.1 | Supported: port, ipv4hint, ipv6hint, ech, mandatory, no-default-alpn | Not supported: alpn with h2/h3, dohpath, ohttp, tls-supported-groups";
$_ADDONLANG["jsTypeHelpNAPTR"] = "Format: preference flags service regexp replacement";
$_ADDONLANG["jsTypeExampleNAPTR"] = "Example: 10 \"A\" \"\" \"!^.*$!prodserver.example.com!\" .";
$_ADDONLANG["jsTypeHelpCAA"] = "Format: flags tag value";
$_ADDONLANG["jsTypeExampleCAA"] = "Example: 0 issue letsencrypt.org";
$_ADDONLANG["jsTypeHelpTLSA"] = "Format: usage selector type certificate-data";
$_ADDONLANG["jsTypeHelpSSHFP"] = "Format: algorithm fp-type fingerprint";
$_ADDONLANG["jsTypeHelpLOC"] = "Format: latitude longitude altitude size hp vp";
$_ADDONLANG["jsTypeHelpDHCID"] = "Format: base64-encoded identifier data";
$_ADDONLANG["jsTypeHelpDS"] = "Format: key-tag algorithm digest-type digest";
$_ADDONLANG["jsTypeHelpDNSKEY"] = "Format: flags protocol algorithm public-key";
$_ADDONLANG["jsTypeHelpSMIMEA"] = "Format: usage selector type certificate-data";
$_ADDONLANG["jsHelpMore"] = "more";
$_ADDONLANG["jsHelpLess"] = "less";
$_ADDONLANG["selectFileLink"] = "Select a file";
$_ADDONLANG["dragFileHereText"] = "or drag it here";
// Web Forwarding redesign
$_ADDONLANG["webForwardingTypeLabel"] = "Forwarding type";
$_ADDONLANG["webForwardingType"] = "Type";
$_ADDONLANG["jsWfHelpPath"] = "Enter the full URL, e.g. https://example.com/page";
$_ADDONLANG["jsWfHelpNoPath"] = "Enter the host name only, without a path, e.g. https://example.com";
$_ADDONLANG["jsWfInvalidUrl"] = "Enter a valid URL starting with http:// or https://";
$_ADDONLANG["jsWfPathNotAllowed"] = "This forwarding type does not allow a path. Use the host name only, e.g. https://example.com";
$_ADDONLANG["jsWfSummaryURL"] = "{source} redirects permanently to {target}";
$_ADDONLANG["jsWfSummaryTRD"] = "{source} redirects temporarily to {target}";
$_ADDONLANG["jsWfSummaryFRAME"] = "{source} shows {target} in a frame";
$_ADDONLANG["jsWfSourcePlaceholder"] = "[source]";
$_ADDONLANG["jsWfTargetPlaceholder"] = "[target URL]";
$_ADDONLANG["jsWfFillAll"] = "Please fill in all fields.";
$_ADDONLANG["jsWfSaved"] = "Web forwarding saved";
$_ADDONLANG["jsWfDeleted"] = "Web forwarding deleted";
$_ADDONLANG["jsWfError"] = "The web forwarding could not be saved.";
$_ADDONLANG["jsWfDeleteTitle"] = "Delete this web forwarding?";
$_ADDONLANG["jsWfCannotUndo"] = "This cannot be undone.";
// DNS records page: title and paging
$_ADDONLANG["dnsRecordsFor"] = "DNS records for";
$_ADDONLANG["dnsRecordsIntro"] = "Manage how websites, email and other services of your domain are found on the Internet.";
$_ADDONLANG["jsShowing"] = "Showing {from}–{to} of {total}";
$_ADDONLANG["jsPerPage"] = "Per page";
$_ADDONLANG["jsPreviousPage"] = "Previous page";
$_ADDONLANG["jsNextPage"] = "Next page";
$_ADDONLANG["webForwardingFor"] = "Web forwarding for";
$_ADDONLANG["webForwardingIntro"] = "Send visitors of a host name of your domain to another web address.";
$_ADDONLANG["jsEditRecord"] = "Edit record";
