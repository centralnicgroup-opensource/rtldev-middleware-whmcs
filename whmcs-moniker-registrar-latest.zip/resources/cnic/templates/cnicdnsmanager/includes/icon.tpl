{* Outline icon, sized and coloured by .cnic-icon (client-base.css); usage: {include file="$templateDir/includes/icon.tpl" name="upload"} *}
<svg class="cnic-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
{if $name eq "search"}<circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.5-3.5"></path>
{elseif $name eq "plus"}<path d="M12 5v14"></path><path d="M5 12h14"></path>
{elseif $name eq "close"}<path d="M6 6l12 12"></path><path d="M18 6L6 18"></path>
{elseif $name eq "check"}<path d="M20 6L9 17l-5-5"></path>
{elseif $name eq "upload"}<path d="M12 15V3"></path><path d="M7 8l5-5 5 5"></path><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"></path>
{elseif $name eq "download"}<path d="M12 3v12"></path><path d="M7 10l5 5 5-5"></path><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"></path>
{elseif $name eq "more"}<circle cx="5" cy="12" r="1"></circle><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle>
{elseif $name eq "trash"}<path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v6"></path><path d="M14 11v6"></path>
{elseif $name eq "settings"}<path d="M4 6h9"></path><path d="M17 6h3"></path><circle cx="15" cy="6" r="2"></circle><path d="M4 12h3"></path><path d="M11 12h9"></path><circle cx="9" cy="12" r="2"></circle><path d="M4 18h11"></path><path d="M19 18h1"></path><circle cx="17" cy="18" r="2"></circle>
{elseif $name eq "copy"}<rect x="9" y="9" width="12" height="12" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
{elseif $name eq "file-up"}<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"></path><path d="M14 3v5h5"></path><path d="M12 18v-6"></path><path d="M9.5 14.5L12 12l2.5 2.5"></path>
{elseif $name eq "chevron-left"}<path d="M15 6l-6 6 6 6"></path>
{elseif $name eq "chevron-right"}<path d="M9 6l6 6-6 6"></path>
{elseif $name eq "alert"}<path d="M12 3l9.5 17h-19z"></path><path d="M12 10v4"></path><path d="M12 17h.01"></path>
{/if}
</svg>
