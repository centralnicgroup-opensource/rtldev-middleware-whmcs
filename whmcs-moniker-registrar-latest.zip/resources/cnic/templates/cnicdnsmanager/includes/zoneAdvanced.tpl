<div class="cnic-dns-controls">
    <div class="dns-toolbar">
        <div class="dns-search">
            <span class="dns-search-icon">{include file="$templateDir/includes/icon.tpl" name="search"}</span>
            <label for="dnsRecordSearch" class="cnic-visually-hidden">{$lang.searchDnsRecordsPlaceholder}</label>
            <input type="search" id="dnsRecordSearch" class="cnic-input" placeholder="{$lang.searchDnsRecordsPlaceholder}" autocomplete="off" />
        </div>
        <div class="dns-toolbar-actions">
            {if $soa.isSupported}
                <button type="button" class="cnic-btn dns-toolbar-secondary" data-cnic-popover="zonePopover" aria-haspopup="dialog" aria-controls="zonePopover" aria-expanded="{if isset($smarty.post["soa-save"])}true{else}false{/if}">
                    {include file="$templateDir/includes/icon.tpl" name="settings"} {$lang.soaBtn}
                </button>
            {/if}
            <button type="button" class="cnic-btn dns-toolbar-secondary" data-cnic-popover="importPopover" aria-haspopup="dialog" aria-controls="importPopover" aria-expanded="false">
                {include file="$templateDir/includes/icon.tpl" name="upload"} {$lang.importBtn}
            </button>
            <button type="button" class="cnic-btn dns-toolbar-secondary" data-cnic-popover="exportPopover" aria-haspopup="dialog" aria-controls="exportPopover" aria-expanded="false">
                {include file="$templateDir/includes/icon.tpl" name="download"} {$lang.exportBtn}
            </button>
            <button type="button" class="cnic-btn cnic-btn--icon dns-more-btn" data-cnic-popover="morePopover" aria-haspopup="dialog" aria-controls="morePopover" aria-expanded="false" aria-label="{$lang.moreActionsBtn}">
                {include file="$templateDir/includes/icon.tpl" name="more"}
            </button>
            <button type="button" id="headerAddRecordButton" class="cnic-btn cnic-btn--primary dns-toolbar-add" data-dns-add aria-controls="addNewRecordContainer" aria-expanded="false">
                {include file="$templateDir/includes/icon.tpl" name="plus"} {$lang.addRecordBtn}
            </button>
        </div>

        <div class="dns-popovers">
            {if $soa.isSupported}
                {include file="$templateDir/includes/soa.tpl"}
            {/if}

            <div id="importPopover" class="cnic-popover-host" hidden>
                <button type="button" class="cnic-popover-backdrop" data-cnic-popover-close aria-label="{$lang.jsClose}"></button>
                <div class="cnic-popover" role="dialog" aria-labelledby="importPopoverTitle">
                    <div class="dns-popover-head">
                        <h2 class="cnic-popover-title" id="importPopoverTitle">{$lang.importDnsRecordsTitle}</h2>
                        <button type="button" class="cnic-btn cnic-btn--icon dns-popover-close" data-cnic-popover-close aria-label="{$lang.jsClose}">{include file="$templateDir/includes/icon.tpl" name="close"}</button>
                    </div>
                    <p class="cnic-callout">{$lang.importDnsRecordsDesc}</p>
                    <div id="zoneDropArea" class="cnic-zone-drop-area-compact">
                        <input type="file" id="zoneFileInput" accept="text/plain,.txt,.zone" style="display:none;" />
                        <span class="cnic-drop-icon">{include file="$templateDir/includes/icon.tpl" name="file-up"}</span>
                        <span class="cnic-drop-text"><button type="button" id="zoneFileBrowse" class="dns-link-btn">{$lang.selectFileLink}</button> {$lang.dragFileHereText}</span>
                    </div>
                    <p class="cnic-callout cnic-callout--warning">{include file="$templateDir/includes/icon.tpl" name="alert"}<span><strong>{$lang.importWarningLabel}</strong> {$lang.importWarningText}</span></p>
                    <div id="zoneImportResults" class="cnic-zone-import-results"></div>
                    <div class="cnic-apply-button-wrapper">
                        <button type="button" id="applyImportedRecordsButton" class="cnic-btn cnic-btn--primary cnic-btn--block cnic-apply-button">
                            {include file="$templateDir/includes/icon.tpl" name="check"} {$lang.applyImportedRecordsBtn}
                        </button>
                    </div>
                </div>
            </div>

            <div id="exportPopover" class="cnic-popover-host" hidden>
                <button type="button" class="cnic-popover-backdrop" data-cnic-popover-close aria-label="{$lang.jsClose}"></button>
                <div class="cnic-popover" role="dialog" aria-labelledby="exportPopoverTitle">
                    <div class="dns-popover-head">
                        <h2 class="cnic-popover-title" id="exportPopoverTitle">{$lang.exportDnsRecordsTitle}</h2>
                        <button type="button" class="cnic-btn cnic-btn--icon dns-popover-close" data-cnic-popover-close aria-label="{$lang.jsClose}">{include file="$templateDir/includes/icon.tpl" name="close"}</button>
                    </div>
                    <p class="cnic-callout">{$lang.exportDnsRecordsDesc} ({$dnszone}.txt)</p>
                    <div class="cnic-actions">
                        <button type="button" id="exportZoneButton" class="cnic-btn cnic-btn--primary">
                            {include file="$templateDir/includes/icon.tpl" name="download"} {$lang.exportZoneFileBtn}
                        </button>
                    </div>
                </div>
            </div>

            <div id="morePopover" class="cnic-popover-host" hidden>
                <button type="button" class="cnic-popover-backdrop" data-cnic-popover-close aria-label="{$lang.jsClose}"></button>
                <div class="cnic-popover" role="dialog" aria-labelledby="morePopoverTitle">
                    <div class="dns-popover-head">
                        <h2 class="cnic-popover-title" id="morePopoverTitle">{$lang.moreActionsBtn}</h2>
                        <button type="button" class="cnic-btn cnic-btn--icon dns-popover-close" data-cnic-popover-close aria-label="{$lang.jsClose}">{include file="$templateDir/includes/icon.tpl" name="close"}</button>
                    </div>
                    <div class="dns-more-list">
                        {if $soa.isSupported}
                            <button type="button" class="cnic-list-row" data-cnic-popover="zonePopover">
                                <span class="dns-more-icon">{include file="$templateDir/includes/icon.tpl" name="settings"}</span>
                                <span class="cnic-list-row-main"><span class="cnic-list-row-title">{$lang.soaBtn}</span><span class="dns-more-desc">{$lang.moreZoneDesc}</span></span>
                            </button>
                        {/if}
                        <button type="button" class="cnic-list-row" data-cnic-popover="importPopover">
                            <span class="dns-more-icon">{include file="$templateDir/includes/icon.tpl" name="upload"}</span>
                            <span class="cnic-list-row-main"><span class="cnic-list-row-title">{$lang.importBtn}</span><span class="dns-more-desc">{$lang.moreImportDesc}</span></span>
                        </button>
                        <button type="button" class="cnic-list-row" data-cnic-popover="exportPopover">
                            <span class="dns-more-icon">{include file="$templateDir/includes/icon.tpl" name="download"}</span>
                            <span class="cnic-list-row-main"><span class="cnic-list-row-title">{$lang.exportBtn}</span><span class="dns-more-desc">{$lang.moreExportDesc}</span></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="dnsTypeChips" class="cnic-chips dns-chips" role="group" aria-label="{$lang.filterByType}"></div>
</div>
