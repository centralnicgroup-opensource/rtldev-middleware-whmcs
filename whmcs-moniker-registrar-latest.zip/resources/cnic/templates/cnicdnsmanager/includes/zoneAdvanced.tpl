<div class="cnic-dns-controls">
    <div class="row cnic-controls-row">
        <div class="col-sm-7">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" id="dnsRecordSearch" class="form-control" placeholder="Search DNS Records" />
            </div>
        </div>
        <div class="col-sm-5">
            <div class="cnic-button-group">
                <button type="button" id="importExportToggle" class="btn btn-default">
                    <i class="fa fa-exchange"></i> Import and Export
                </button>
                <button type="button" id="headerAddRecordButton" class="btn btn-primary">
                    <i class="fa fa-plus"></i> Add record
                </button>
            </div>
        </div>
    </div>
    
    <!-- Combined Import/Export Panel -->
    <div id="importExportPanel" class="cnic-zone-panel">
        <div class="cnic-zone-panel-body">
            <div class="row cnic-panel-content">
                <!-- Import Section -->
                <div class="col-md-6 cnic-import-section">
                    <h4 class="cnic-zone-section-title"><i class="fa fa-upload"></i> Import DNS records</h4>
                    <p class="text-muted cnic-section-desc">Upload a zone file to import DNS records</p>
                    <div class="alert alert-warning" style="margin-bottom: 15px; padding: 10px 15px; font-size: 0.9em;">
                        <i class="fa fa-exclamation-triangle"></i> <strong>Important:</strong> Importing a zone file will replace all existing DNS records. Make sure to export your current records first if you need to keep a backup.
                    </div>
                    <div id="zoneDropArea" class="cnic-zone-drop-area-compact">
                        <input type="file" id="zoneFileInput" accept="text/plain,.txt,.zone" style="display:none;" />
                        <i class="fa fa-cloud-upload cnic-drop-icon"></i>
                        <p class="cnic-drop-text">Select a file or drag it here</p>
                        <button type="button" id="zoneFileBrowse" class="btn btn-primary">
                            <i class="fa fa-folder-open"></i> Browse Files
                        </button>
                    </div>
                    <div id="zoneImportResults" class="cnic-zone-import-results"></div>
                    <div class="cnic-apply-button-wrapper">
                        <button type="button" id="applyImportedRecordsButton" class="btn btn-success btn-block cnic-apply-button">
                            <i class="fa fa-check"></i> Apply Imported Records
                        </button>
                    </div>
                </div>
                
                <!-- Export Section -->
                <div class="col-md-6 cnic-export-section">
                    <h4 class="cnic-zone-section-title"><i class="fa fa-download"></i> Export DNS records</h4>
                    <p class="text-muted cnic-section-desc">Download all DNS records as a zone file in standard format</p>
                    <div class="well cnic-export-info">
                        <p><i class="fa fa-info-circle"></i> The exported file will contain all DNS records in BIND zone file format</p>
                    </div>
                    <button type="button" id="exportZoneButton" class="btn btn-primary btn-block">
                        <i class="fa fa-download"></i> Export Zone File
                    </button>
                </div>
            </div>
            
            <!-- Footer with Close Button -->
            <div class="cnic-panel-footer">
                <button type="button" id="closeImportExportPanel" class="btn btn-default btn-sm">
                    <i class="fa fa-times"></i> Close
                </button>
            </div>
        </div>
    </div>
</div>
