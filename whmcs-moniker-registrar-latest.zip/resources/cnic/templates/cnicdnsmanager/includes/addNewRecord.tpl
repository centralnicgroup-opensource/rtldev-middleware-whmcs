<div class="panel panel-default mb-3" id="addNewRecordContainer" style="display:none;">
    <div class="panel-body">
        <div class="addNewRecord">
            <input type="hidden" name="dnsrecid[]" value="" />
            {foreach $prioritySupportedRecordTypes as $priorityResourceRecord}
                <input type="hidden" name="prioritySupportedRecordType[]" value="{$priorityResourceRecord}" />
            {/foreach}
            
            <!-- Form Fields Row -->
            <div class="row">
                <div class="col-sm-2" id="newDnsRecordTypeWrapper">
                    <label class="control-label">Type</label>
                    <select id="newDnsRecordType" class="form-control record-type">
                        {foreach from=$dnsRecordTypes key=type item=label}
                            <option value="{$type}">{$label}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="col-sm-3" id="newDnsRecordHostWrapper">
                    <label class="control-label">Name</label>
                    <input type="text" id="newDnsRecordHost" class="form-control" placeholder="example.com" />
                </div>
                <div class="col-sm-5" id="newDnsRecordAddressWrapper">
                    <label class="control-label">Content</label>
                    <input type="text" id="newDnsRecordAddress" class="form-control" placeholder="192.168.1.1" />
                    <small class="form-text text-muted" id="addressHelpText" style="display: none;"></small>
                </div>
                <div class="col-sm-1" id="newDnsRecordTtlWrapper">
                    <label class="control-label">TTL</label>
                    <input type="text" id="newDnsRecordTtl" class="form-control" placeholder="Auto" />
                </div>
                <div class="col-sm-1" id="newDnsRecordPriorityWrapper" style="display: none;">
                    <label class="control-label">Priority</label>
                    <input type="text" id="newDnsRecordPriority" class="form-control priority-input" placeholder="10" />
                </div>
            </div>
            
            <!-- Action Buttons Row -->
            <div class="row cnic-add-record-actions">
                <div class="col-sm-12 text-right">
                    <button type="button" id="cancelAddRecordButton" class="btn btn-default">
                        Cancel
                    </button>
                    <button type="button" id="addRecordButton" class="btn btn-primary">
                        <i class="fa fa-plus"></i> Save
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>