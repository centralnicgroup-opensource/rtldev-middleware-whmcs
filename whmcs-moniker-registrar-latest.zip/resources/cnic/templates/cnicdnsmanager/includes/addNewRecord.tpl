{* Record form, shared by "Add record" (opens below the toolbar) and "Edit" (moves under the record's row);
   a bottom sheet on phones *}
<div id="addRecordHome"></div>
<div class="cnic-sheet-backdrop dns-form-backdrop" id="recordFormBackdrop" hidden></div>
<div class="cnic-panel dns-record-form" id="addNewRecordContainer" role="region" aria-label="{$lang.addRecordBtn}" style="display:none;">
    <div class="dns-sheet-head">
        <span class="cnic-sheet-handle" aria-hidden="true"></span>
        <h2 class="cnic-popover-title" id="recordFormTitle">{$lang.addRecordBtn}</h2>
        <button type="button" class="cnic-btn cnic-btn--icon dns-popover-close" id="recordFormClose" aria-label="{$lang.jsClose}">{include file="$templateDir/includes/icon.tpl" name="close"}</button>
    </div>
    <div class="addNewRecord">
        {foreach $prioritySupportedRecordTypes as $priorityResourceRecord}
            <input type="hidden" name="prioritySupportedRecordType[]" value="{$priorityResourceRecord}" />
        {/foreach}

        <p class="dns-summary" id="recordSummary" aria-live="polite"></p>

        <div id="deleteConfirm" class="dns-delete-confirm" role="alert" hidden>
            <span>{$lang.jsDeleteConfirm}</span>
            <span class="cnic-actions">
                <button type="button" id="deleteKeepButton" class="cnic-btn">{$lang.jsDeleteKeep}</button>
                <button type="button" id="deleteConfirmButton" class="cnic-btn cnic-btn--danger-solid">{$lang.jsDeleteBtn}</button>
            </span>
        </div>

        <div class="dns-form-row">
            <div class="cnic-field dns-field-type" id="newDnsRecordTypeWrapper">
                <label class="cnic-label" for="newDnsRecordType">{$lang.type}</label>
                <select id="newDnsRecordType" class="cnic-input record-type">
                    {foreach from=$dnsRecordTypes key=type item=label}
                        <option value="{$type}">{$label}</option>
                    {/foreach}
                </select>
            </div>
            <div class="cnic-field dns-field-name" id="newDnsRecordHostWrapper">
                <label class="cnic-label" for="newDnsRecordHost">{$lang.addRecordNameLabel}</label>
                <input type="text" id="newDnsRecordHost" class="cnic-input" placeholder="@" autocomplete="off" />
                <small class="invalid-feedback" data-error-for="host">{$lang.hostRequired}</small>
            </div>
        </div>
        <div class="dns-form-row">
            <div class="cnic-field dns-field-value" id="newDnsRecordAddressWrapper">
                <label class="cnic-label" for="newDnsRecordAddress" id="newDnsRecordAddressLabel">{$lang.addRecordContentLabel}</label>
                <input type="text" id="newDnsRecordAddress" class="cnic-input cnic-input--mono" autocomplete="off" />
                <small class="invalid-feedback" data-error-for="address">{$lang.addressRequired}</small>
                <small class="cnic-field-hint" id="addressHelpText" style="display: none;"></small>
            </div>
            <div class="cnic-field dns-field-small" id="newDnsRecordPriorityWrapper" style="display: none;">
                <label class="cnic-label" for="newDnsRecordPriority">{$lang.priority}</label>
                <input type="text" id="newDnsRecordPriority" class="cnic-input priority-input" inputmode="numeric" placeholder="10" />
            </div>
            <div class="cnic-field dns-field-small" id="newDnsRecordTtlWrapper">
                <label class="cnic-label" for="newDnsRecordTtl">{$lang.ttl}</label>
                <select id="newDnsRecordTtl" class="cnic-input">
                    <option value="300">5 min</option>
                    <option value="1800">30 min</option>
                    <option value="3600">1 h</option>
                    <option value="14400">4 h</option>
                    <option value="43200">12 h</option>
                    <option value="86400">1 d</option>
                </select>
            </div>
        </div>

        <div class="cnic-actions">
            <button type="button" id="deleteRecordButton" class="cnic-btn cnic-btn--danger" hidden>
                {include file="$templateDir/includes/icon.tpl" name="trash"} {$lang.jsDeleteBtn}
            </button>
            <span class="cnic-actions-spacer"></span>
            <button type="button" id="cancelAddRecordButton" class="cnic-btn">{$lang.addRecordCancelBtn}</button>
            <button type="button" id="addRecordButton" class="cnic-btn cnic-btn--primary" disabled>
                {include file="$templateDir/includes/icon.tpl" name="check"} <span id="addRecordButtonLabel">{$lang.jsAdd}</span>
            </button>
        </div>
    </div>
</div>
