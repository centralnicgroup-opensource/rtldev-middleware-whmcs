<div class="card cnic-ui">
    <div class="card-body">
        <div class="cnic-dns-header mb-3">
            <h3 class="mb-2">{$lang.webForwardingFor} <span class="dns-header-zone">{$dnszone}</span></h3>
            <p class="mb-0 dns-header-intro">{$lang.webForwardingIntro}</p>
        </div>

        <div id="webForwardingLoader" class="wf-loader" style="display: none;" role="status">
            <div class="wf-loader-box"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i> {$lang.webForwardingProcessingMessage}</div>
        </div>

        <div id="webForwardingMessage" style="display: none;"></div>

        {if $success}
            {include file="$templateDir/includes/alert.tpl" type="success" msg=$success}
        {/if}

        {if $error}
            {include file="$templateDir/includes/alert.tpl" type="error" msg=$error}
        {else}
            <script type="application/json" id="cnicWfI18n">{$jsLang}</script>
            <input type="hidden" id="modulelink" value="{$modulelink}" />
            <input type="hidden" id="domainid" value="{$domainid}" />
            <input type="hidden" id="dnszone" value="{$dnszone}" />

            <div class="cnic-dns-controls cnic-actions">
                <button type="button" id="addForwardingButton" class="cnic-btn cnic-btn--primary" aria-controls="addForwardingPanel" aria-expanded="false">
                    {include file="$templateDir/includes/icon.tpl" name="plus"} {$lang.webForwardingAddNew}
                </button>
            </div>

            {* Add or edit a web forwarding *}
            <div id="addForwardingPanel" class="cnic-panel wf-form" style="display: none;">
                <form method="POST" action="{$modulelink}&domainid={$domainid}" id="addWebForwardingForm" novalidate>
                    <input type="hidden" name="action" value="saveDNS" />
                    <input type="hidden" name="m" value="cnicdnsmanager" />
                    <input type="hidden" name="sub" value="webforwarding" />
                    <input type="hidden" name="domainid" value="{$domainid}" />
                    <input type="hidden" name="dnszone" value="{$dnszone}" />
                    <input type="hidden" name="webForwardingAddon" value="1" />
                    <input type="hidden" name="newrecord" value="1" />
                    <input type="hidden" name="dnsrecordtype[]" id="newType" value="URL" />
                    <input type="hidden" name="dnsrecordpriority[]" value="N/A" />
                    <input type="hidden" name="dnsrecordttl[]" value="" />

                    <p class="dns-summary" id="wfSummary" aria-live="polite"></p>

                    <fieldset class="wf-types">
                        <legend class="cnic-label">{$lang.webForwardingTypeLabel}</legend>
                        <div class="wf-type-options" role="radiogroup">
                            <button type="button" class="wf-type-option" role="radio" aria-checked="true" data-type="URL" data-allows-path="true">
                                <span class="wf-type-title">{$lang.webForwardingUrlType}</span>
                                <span class="wf-type-desc">{$lang.webForwardingUrlDescription}</span>
                            </button>
                            {if in_array('TRD', $supportedTypes)}
                                <button type="button" class="wf-type-option" role="radio" aria-checked="false" data-type="TRD" data-allows-path="false">
                                    <span class="wf-type-title">{$lang.webForwardingTrdType}</span>
                                    <span class="wf-type-desc">{$lang.webForwardingTrdDescription}</span>
                                </button>
                            {/if}
                            <button type="button" class="wf-type-option" role="radio" aria-checked="false" data-type="FRAME" data-allows-path="false">
                                <span class="wf-type-title">{$lang.webForwardingFrameType}</span>
                                <span class="wf-type-desc">{$lang.webForwardingFrameDescription}</span>
                            </button>
                        </div>
                    </fieldset>

                    <div class="dns-form-row">
                        <div class="cnic-field wf-field-source">
                            <label class="cnic-label" for="newHostname">{$lang.webForwardingSourceHostname}</label>
                            <div class="cnic-input-group">
                                <input type="text" name="dnsrecordhost[]" id="newHostname" class="cnic-input" autocomplete="off"
                                    placeholder="{$lang.webForwardingSourcePlaceholder}" required
                                    pattern="^(@|[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)*)$" />
                                <span class="cnic-input-suffix wf-zone-suffix">.{$dnszone}</span>
                            </div>
                            <span class="cnic-field-hint">{$lang.webForwardingRootDomainInfo}</span>
                        </div>
                        <div class="cnic-field wf-field-target">
                            <label class="cnic-label" for="newTarget">{$lang.webForwardingTargetUrl}</label>
                            <input type="url" name="dnsrecordaddress[]" id="newTarget" class="cnic-input cnic-input--mono" autocomplete="off"
                                placeholder="{$lang.webForwardingTargetPlaceholder}" required pattern="https?://.+" />
                            <span class="cnic-field-hint" id="targetHelp">{$lang.webForwardingTargetHelp}</span>
                        </div>
                    </div>

                    <div class="cnic-actions">
                        <button type="button" id="cancelAddForwardingButton" class="cnic-btn">{$lang.webForwardingCancelButton}</button>
                        <button type="submit" id="saveForwardingButton" class="cnic-btn cnic-btn--primary" disabled>
                            {include file="$templateDir/includes/icon.tpl" name="check"} {$lang.jsSave}
                        </button>
                    </div>
                </form>
            </div>

            {* Web forwardings of the domain *}
            <div id="webForwardingRecordsContainer">
                <div id="noRecordsMessage" class="wf-empty"{if $forwardings|@count > 0} style="display: none;"{/if}>
                    <span class="wf-empty-icon"><i class="fa fa-exchange" aria-hidden="true"></i></span>
                    <h4>{$lang.webForwardingNoRecordsTitle}</h4>
                    <p>{$lang.webForwardingGetStarted}</p>
                    <button type="button" class="cnic-btn cnic-btn--primary" data-wf-add>
                        {include file="$templateDir/includes/icon.tpl" name="plus"} {$lang.webForwardingCreateButton}
                    </button>
                </div>

                <table class="table cnic-table wf-table" id="forwardingTable"{if $forwardings|@count == 0} style="display: none;"{/if}>
                    <thead class="cnic-thead">
                        <tr class="cnic-tr">
                            <th class="cnic-th">{$lang.webForwardingSource}</th>
                            <th class="cnic-th">{$lang.type}</th>
                            <th class="cnic-th">{$lang.webForwardingTargetLabel}</th>
                            <th class="cnic-th"><span class="cnic-visually-hidden">{$lang.webForwardingEdit}</span></th>
                        </tr>
                    </thead>
                    <tbody id="forwardingCards" class="cnic-tbody">
                        {foreach $forwardings as $fwd}
                            {assign var="fwdType" value=$fwd.type|upper}
                            <tr class="cnic-tr dns-record wf-row" data-hostname="{$fwd.hostname|escape:'html'}" data-type="{$fwdType|escape:'html'}" data-target="{$fwd.address|escape:'html'}">
                                <td class="cnic-td dns-cell-name">
                                    <span class="dns-name" title="{if $fwd.hostname eq '@' || $fwd.hostname eq $dnszone}{$dnszone}{else}{$fwd.hostname|escape:'html'}.{$dnszone}{/if}">{if $fwd.hostname eq '@' || $fwd.hostname eq $dnszone}{$dnszone}{else}{$fwd.hostname|escape:'html'}<span class="dns-zone">.{$dnszone}</span>{/if}</span>
                                </td>
                                <td class="cnic-td dns-cell-type">
                                    <span class="cnic-badge wf-badge-{$fwdType|lower|escape:'html'}">{if $fwdType eq 'URL'}{$lang.webForwardingUrlType}{elseif $fwdType eq 'TRD'}{$lang.webForwardingTrdType}{else}{$lang.webForwardingFrameType}{/if}</span>
                                </td>
                                <td class="cnic-td dns-cell-content"><span class="dns-content" title="{$fwd.address|escape:'html'}">{$fwd.address|escape:'html'}</span></td>
                                <td class="cnic-td dns-cell-action text-right">
                                    <button type="button" class="cnic-btn cnic-btn--quiet edit-forwarding-btn">{$lang.webForwardingEdit}</button>
                                    <button type="button" class="cnic-btn cnic-btn--quiet wf-delete delete-forwarding-row">{$lang.webForwardingDelete}</button>
                                </td>
                            </tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>
        {/if}
    </div>
</div>

{* Delete confirmation *}
<div class="modal fade cnic-ui" id="webForwardingModal" tabindex="-1" role="dialog" aria-labelledby="webForwardingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="webForwardingModalLabel">{$lang.webForwardingDeleteConfirm}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="{$lang.webForwardingCancelButton}"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body" id="webForwardingModalBody"></div>
            <div class="modal-footer">
                <button type="button" class="cnic-btn" data-dismiss="modal">{$lang.webForwardingCancelButton}</button>
                <button type="button" class="cnic-btn cnic-btn--danger-solid" id="confirmDeleteForwarding">
                    {include file="$templateDir/includes/icon.tpl" name="trash"} {$lang.webForwardingDelete}
                </button>
            </div>
        </div>
    </div>
</div>
