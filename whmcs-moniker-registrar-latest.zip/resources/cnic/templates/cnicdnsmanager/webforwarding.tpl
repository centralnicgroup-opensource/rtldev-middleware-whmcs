<div class="card">
    <div class="card-body">
        <div class="cnic-dns-header mb-3">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <h3 class="mb-2">{$lang.webForwardingTitle}</h3>
                    <p class="text-muted mb-0">{$lang.webForwardingDescription} {$dnszone}</p>
                </div>
            </div>
        </div>

        {* Loading Spinner *}
        <div id="webForwardingLoader" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
            <div style="background: #fff; padding: 40px; border-radius: 12px; text-align: center; box-shadow: 0 8px 32px rgba(0,0,0,0.3);">
                <i class="fa fa-spinner fa-spin" style="font-size: 48px; color: #3b82f6; margin-bottom: 16px;"></i>
                <p style="margin: 0; font-size: 16px; font-weight: 600; color: #1e293b;">{$lang.webForwardingProcessingMessage}</p>
            </div>
        </div>

        {* Success/Error Messages *}
        <div id="webForwardingMessage" style="display: none; margin-bottom: 20px;"></div>

        {if $success}
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                {$success}
            </div>
        {/if}

        {if $error}
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert">
                    <span aria-hidden="true">&times;</span>
                </button>
                {$error}
            </div>
        {else}
            {* Hidden data for JavaScript *}
            <input type="hidden" id="modulelink" value="{$modulelink}" />
            <input type="hidden" id="domainid" value="{$domainid}" />
            <input type="hidden" id="dnszone" value="{$dnszone}" />

            {* Controls Section *}
            <div class="cnic-dns-controls">
                <div class="row cnic-controls-row">
                    <div class="col-sm-12">
                        <div class="cnic-button-group">
                            <button type="button" id="addForwardingButton" class="btn btn-primary" data-lang-add="{$lang.webForwardingAddNew}">
                                <i class="fa fa-plus"></i> {$lang.webForwardingAddNew}
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        {* Add New Web Forwarding Panel (Hidden by default) *}
        <div id="addForwardingPanel" class="panel panel-default mb-3" style="display:none; border: 1px solid #bfdbfe; border-radius: 8px; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1); overflow: hidden;">
            <div class="panel-heading" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); border-bottom: 0; padding: 20px 24px;">
                <h4 style="margin: 0; font-size: 18px; font-weight: 700; color: #fff; display: flex; align-items: center;">
                    <i class="fa fa-plus-circle" style="margin-right: 10px; font-size: 20px;"></i> 
                    <span>{$lang.webForwardingAddNew}</span>
                </h4>
            </div>
            <div class="panel-body" style="padding: 32px 24px; background: #fafbff;">
                <form method="POST" action="{$modulelink}&domainid={$domainid}" id="addWebForwardingForm">
                    <input type="hidden" name="action" value="saveDNS" />
                    <input type="hidden" name="m" value="cnicdnsmanager" />
                    <input type="hidden" name="sub" value="webforwarding" />
                    <input type="hidden" name="domainid" value="{$domainid}" />
                    <input type="hidden" name="dnszone" value="{$dnszone}" />
                    <input type="hidden" name="webForwardingAddon" value="1" />
                    <input type="hidden" name="newrecord" value="1" />

                    {* Step 1: Choose Forwarding Type - Card Selection *}
                    <div style="margin-bottom: 32px;">
                        <label style="font-size: 14px; font-weight: 700; color: #1e293b; margin-bottom: 16px; display: block; text-transform: uppercase; letter-spacing: 0.5px;">
                            <i class="fa fa-exchange" style="margin-right: 8px; color: #3b82f6;"></i>
                            {$lang.webForwardingStep1}
                        </label>
                        
                        {* Calculate number of supported types for responsive layout *}
                        {assign var="numTypes" value=$supportedTypes|@count}
                        {if $numTypes == 2}
                            {assign var="colClass" value="col-sm-6"}
                        {else}
                            {assign var="colClass" value="col-sm-4"}
                        {/if}
                        
                        <div class="row forwarding-type-selector" style="margin: 0 -8px; display: flex;">
                            {* URL Redirect Card *}
                            <div class="{$colClass}" style="padding: 0 8px; display: flex;">
                                <div class="forwarding-card forwarding-card--selectable active type-url" data-type="URL" data-allows-path="true">
                                    <div class="card-header">
                                        <div class="card-icon">
                                            <i class="fa fa-arrow-right"></i>
                                        </div>
                                        <h5 class="card-title">
                                            {$lang.webForwardingUrlType}
                                        </h5>
                                    </div>
                                    <p class="card-description">
                                        {$lang.webForwardingUrlDescription}
                                    </p>
                                    <div class="card-example">
                                        <strong>{$lang.webForwardingExampleLabel}</strong><br>
                                        <code>yourdomain.com</code>
                                        <i class="fa fa-long-arrow-right" style="margin: 0 4px;"></i>
                                        <code>target.com/page</code>
                                        <br><small>{$lang.webForwardingAllowsPaths}</small>
                                    </div>
                                </div>
                            </div>
                            
                            {* Temporary Redirect Card - Only show if supported *}
                            {if in_array('TRD', $supportedTypes)}
                            <div class="{$colClass}" style="padding: 0 8px; display: flex;">
                                <div class="forwarding-card forwarding-card--selectable type-trd" data-type="TRD" data-allows-path="false">
                                    <div class="card-header">
                                        <div class="card-icon">
                                            <i class="fa fa-clock"></i>
                                        </div>
                                        <h5 class="card-title">
                                            {$lang.webForwardingTrdType}
                                        </h5>
                                    </div>
                                    <p class="card-description">
                                        {$lang.webForwardingTrdDescription}
                                    </p>
                                    <div class="card-example">
                                        <strong>{$lang.webForwardingExampleLabel}</strong><br>
                                        <code>yourdomain.com</code>
                                        <i class="fa fa-exchange" style="margin: 0 4px;"></i>
                                        <code>target.com</code>
                                        <br><small>{$lang.webForwardingNoPaths302}</small>
                                    </div>
                                </div>
                            </div>
                            {/if}
                            
                            {* URL Frame Card *}
                            <div class="{$colClass}" style="padding: 0 8px; display: flex;">
                                <div class="forwarding-card forwarding-card--selectable type-frame" data-type="FRAME" data-allows-path="false">
                                    <div class="card-header">
                                        <div class="card-icon">
                                            <i class="fa fa-window-restore"></i>
                                        </div>
                                        <h5 class="card-title">
                                            {$lang.webForwardingFrameType}
                                        </h5>
                                    </div>
                                    <p class="card-description">
                                        {$lang.webForwardingFrameDescription}
                                    </p>
                                    <div class="card-example">
                                        <strong>{$lang.webForwardingExampleLabel}</strong><br>
                                        <code>yourdomain.com</code>
                                        <i class="fa fa-window-maximize" style="margin: 0 4px;"></i>
                                        <code>target.com</code>
                                        <br><small>{$lang.webForwardingNoPathsKeepsDomain}</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <input type="hidden" name="dnsrecordtype[]" id="newType" value="URL" />
                    </div>

                    {* Step 2: Configure Forwarding *}
                    <div style="margin-bottom: 28px;">
                        <label style="font-size: 14px; font-weight: 700; color: #1e293b; margin-bottom: 16px; display: block; text-transform: uppercase; letter-spacing: 0.5px;">
                            <i class="fa fa-cog" style="margin-right: 8px; color: #3b82f6;"></i>
                            {$lang.webForwardingStep2}
                        </label>
                        
                        <div style="background: #fff; border: 2px solid #e0e7ff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(99, 102, 241, 0.08);">
                            <div class="row" style="margin-bottom: 20px;">
                                <div class="col-sm-5">
                                    <label class="control-label" style="font-size: 13px; font-weight: 600; margin-bottom: 10px; display: block; color: #475569;">
                                        <i class="fa fa-globe" style="color: #3b82f6; margin-right: 6px;"></i> 
                                        {$lang.webForwardingSourceHostname}
                                    </label>
                                    <input type="text" name="dnsrecordhost[]" id="newHostname" class="form-control" 
                                           placeholder="{$lang.webForwardingSourcePlaceholder}" required 
                                           pattern="^(@|[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)*)$"
                                           title="{$lang.webForwardingRootDomainInfo}"
                                           style="height: 46px; font-size: 15px; border: 2px solid #e0e7ff; border-radius: 8px; transition: all 0.2s; font-weight: 500;" 
                                           onfocus="this.style.borderColor='#3b82f6'; this.style.boxShadow='0 0 0 4px rgba(59, 130, 246, 0.1)';" 
                                           onblur="this.style.borderColor='#cbd5e0'; this.style.boxShadow='none';"
                                           oninvalid="this.setCustomValidity('{$lang.webForwardingRootDomainInfo}');"
                                           oninput="this.setCustomValidity('');" />
                                    <div style="margin-top: 10px; padding: 10px 14px; background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border: 1px solid #bfdbfe; border-radius: 8px; font-size: 13px; color: #1e40af; font-weight: 600;">
                                        <i class="fa fa-arrow-right" style="color: #0ea5e9; margin-right: 6px;"></i>
                                        <span id="hostnamePreview" style="color: #0c4a6e;">.{$dnszone}</span>
                                    </div>
                                </div>
                                <div class="col-sm-7">
                                    <label class="control-label" style="font-size: 13px; font-weight: 600; margin-bottom: 10px; display: block; color: #475569;">
                                        <i class="fa fa-external-link" style="color: #3b82f6; margin-right: 6px;"></i> 
                                        {$lang.webForwardingTargetUrl}
                                    </label>
                                    <input type="url" name="dnsrecordaddress[]" id="newTarget" class="form-control" 
                                           placeholder="{$lang.webForwardingTargetPlaceholder}" required 
                                           pattern="https?://.+"
                                           title="{$lang.webForwardingUrlValidation}"
                                           style="height: 44px; font-size: 15px; border: 1px solid #ced4da; border-radius: 4px; transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;" 
                                           onfocus="this.style.borderColor='#80bdff'; this.style.boxShadow='0 0 0 0.2rem rgba(0,123,255,.25)';" 
                                           onblur="this.style.borderColor='#ced4da'; this.style.boxShadow='none';"
                                           oninvalid="this.setCustomValidity('{$lang.webForwardingUrlValidation}');"
                                           oninput="this.setCustomValidity('');" />
                                    <input type="hidden" name="dnsrecordpriority[]" value="N/A" />
                                    <input type="hidden" name="dnsrecordttl[]" value="" />
                                    <small id="targetHelp" class="form-text text-muted" style="margin-top: 8px; font-size: 12px; line-height: 1.4; display: block;">
                                        <i class="fa fa-info-circle" style="color: #17a2b8;"></i> {$lang.webForwardingTargetHelp}
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 text-right" style="padding-top: 20px; border-top: 2px solid #e9ecef; margin-top: 5px;">
                            <button type="button" id="cancelAddForwardingButton" class="btn btn-default" 
                                    style="padding: 11px 28px; font-size: 14px; font-weight: 500; border-radius: 4px; margin-right: 10px; transition: all 0.2s ease-in-out;"
                                    onmouseover="this.style.backgroundColor='#e2e6ea'; this.style.borderColor='#dae0e5';"
                                    onmouseout="this.style.backgroundColor=''; this.style.borderColor='';"
                                    onmousedown="this.style.transform='scale(0.98)';"
                                    onmouseup="this.style.transform='scale(1)';">
                                <i class="fa fa-times"></i> {$lang.webForwardingCancelButton}
                            </button>
                            <button type="submit" class="btn btn-success" 
                                    style="padding: 11px 28px; font-size: 14px; font-weight: 500; border-radius: 4px; background-color: #28a745; border-color: #28a745; transition: all 0.2s ease-in-out;"
                                    onmouseover="this.style.backgroundColor='#218838'; this.style.borderColor='#1e7e34'; this.style.boxShadow='0 4px 8px rgba(40, 167, 69, 0.3)';"
                                    onmouseout="this.style.backgroundColor='#28a745'; this.style.borderColor='#28a745'; this.style.boxShadow='none';"
                                    onmousedown="this.style.transform='scale(0.98)';"
                                    onmouseup="this.style.transform='scale(1)';">
                                <i class="fa fa-check"></i> {$lang.webForwardingSaveButton}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        {* Existing Web Forwarding Records - Creative Card Display *}
        <div id="webForwardingRecordsContainer">
            {if $forwardings|@count == 0}
                <div id="noRecordsMessage" class="forwarding-empty-state">
                    <div class="forwarding-empty-icon">
                        <i class="fa fa-exchange"></i>
                    </div>
                    <h4 style="color: #475569; font-weight: 600; margin-bottom: 12px;">{$lang.webForwardingNoRecordsTitle}</h4>
                    <p style="color: #64748b; font-size: 15px; margin-bottom: 24px;">{$lang.webForwardingGetStarted}</p>
                    <button type="button" class="btn btn-primary" onclick="document.getElementById('addForwardingButton').click();" 
                            style="padding: 12px 32px; font-size: 15px; font-weight: 600; border-radius: 8px; background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); border: 0; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);">
                        <i class="fa fa-plus-circle"></i> {$lang.webForwardingCreateButton}
                    </button>
                </div>
            {else}
                <div id="forwardingCards" class="row" style="margin: 0 -8px;">
                    {foreach $forwardings as $index => $fwd}
                        {if is_array($fwd) && isset($fwd.hostname) && isset($fwd.type) && isset($fwd.address)}
                        <div class="col-sm-12 col-md-6" style="padding: 8px; margin-bottom: 16px;">
                            <div class="forwarding-card type-{$fwd.type|lower}" data-hostname="{$fwd.hostname}" data-type="{$fwd.type}" data-index="{$index}">
                                
                                {* Type Badge with Icon *}
                                <div class="forwarding-type-badge type-{$fwd.type|lower}">
                                    {if $fwd.type == "URL" || $fwd.type == "url"}
                                        <i class="fa fa-arrow-right"></i>
                                        {$lang.webForwardingUrlType}
                                    {elseif $fwd.type == "TRD" || $fwd.type == "trd"}
                                        <i class="fa fa-clock-o"></i>
                                        {$lang.webForwardingTrdType}
                                    {else}
                                        <i class="fa fa-window-restore"></i>
                                        {$lang.webForwardingFrameType}
                                    {/if}
                                </div>

                                {* Card Content *}
                                <div class="forwarding-card-content">
                                    {* Source Domain Section *}
                                    <div class="forwarding-card-section">
                                        <label class="forwarding-card-label">
                                            <i class="fa fa-globe"></i> {$lang.webForwardingSource}
                                        </label>
                                        <div class="forwarding-source-display">
                                            <div class="forwarding-source editable-hostname" data-field="hostname"
                                                 onclick="makeEditable(this, '{$fwd.hostname}', '{$fwd.type}')">
                                                {if $fwd.hostname == "@"}
                                                    <span class="domain-root">{$dnszone}</span>
                                                {else}
                                                    <span class="domain-sub">{$fwd.hostname}</span>
                                                    <span class="domain-base">.{$dnszone}</span>
                                                {/if}
                                            </div>
                                        </div>
                                    </div>

                                    {* Visual Arrow/Flow Indicator *}
                                    <div class="forwarding-flow-arrow">
                                        {if $fwd.type == "URL" || $fwd.type == "url"}
                                            <i class="fa fa-long-arrow-right"></i>
                                        {elseif $fwd.type == "TRD" || $fwd.type == "trd"}
                                            <i class="fa fa-exchange"></i>
                                        {else}
                                            <i class="fa fa-window-maximize"></i>
                                        {/if}
                                    </div>

                                    {* Target URL Section *}
                                    <div class="forwarding-card-section">
                                        <label class="forwarding-card-label">
                                            <i class="fa fa-external-link"></i> {$lang.webForwardingTargetLabel}
                                        </label>
                                        <div class="forwarding-target editable-target" data-field="target"
                                             onclick="makeEditable(this, '{$fwd.hostname}', '{$fwd.type}')">
                                            <i class="fa fa-link"></i>
                                            <span class="target-url">{$fwd.address}</span>
                                        </div>
                                    </div>

                                    {* Info Banner *}
                                    <div class="forwarding-info-banner type-{$fwd.type|lower}">
                                        <i class="fa fa-info-circle"></i>
                                        <span>
                                            {if $fwd.type == "URL"}
                                                {$lang.webForwardingVisitorsSeeUrl} <strong>{$fwd.address}</strong> {$lang.webForwardingInBrowser}
                                            {elseif $fwd.type == "TRD"}
                                                {$lang.webForwardingTemporaryRedirectInfo}
                                            {else}
                                                {$lang.webForwardingFrameInfo}
                                            {/if}
                                        </span>
                                    </div>
                                </div>

                                {* Action Buttons *}
                                <div class="forwarding-card-actions">
                                        <button type="button" class="btn btn-sm edit-forwarding-btn btn-edit-{$fwd.type|lower}" 
                                            data-hostname="{$fwd.hostname}" data-type="{$fwd.type}" data-target="{$fwd.address}"
                                            title="{$lang.webForwardingEdit}">
                                        <i class="fa fa-edit"></i> {$lang.webForwardingEdit}
                                    </button>
                                        <button type="button" class="btn btn-sm delete-forwarding-row btn-delete" 
                                            data-hostname="{$fwd.hostname}" data-type="{$fwd.type}" data-target="{$fwd.address}"
                                            title="{$lang.webForwardingDelete}">
                                        <i class="fa fa-trash"></i> {$lang.webForwardingDelete}
                                    </button>
                                </div>
                            </div>
                        </div>
                        {/if}
                    {/foreach}
                </div>
            {/if}
        </div>
        {/if}

    </div>
</div>

{* Confirmation Modal *}
<div class="modal fade" id="webForwardingModal" tabindex="-1" role="dialog" aria-labelledby="webForwardingModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="webForwardingModalLabel">{$lang.webForwardingDeleteConfirm}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="webForwardingModalBody">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{$lang.webForwardingCancelButton}</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteForwarding">
                    <i class="fa fa-trash"></i> {$lang.webForwardingDelete}
                </button>
            </div>
        </div>
    </div>
</div>
