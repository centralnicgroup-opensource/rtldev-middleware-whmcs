{if $dnssec.isSupported}
    {include file="$templateDir/dnssec.tpl"}
{/if}
<div class="card cnic-ui">
    <div class="card-body">
        <div class="cnic-dns-header mb-3">
            <h3 class="mb-2">{$lang.dnsRecordsFor} <span class="dns-header-zone">{$dnszone}</span></h3>
            <p class="mb-0 dns-header-intro">{$lang.dnsRecordsIntro}</p>
        </div>

        {if !empty($error)}
            {include file="$templateDir/includes/alert.tpl" type="error" msg=$error}
            <!-- CNIC: Add success message: START -->
        {elseif !empty($smarty.post["token"]) && !isset($smarty.post["dnssec-disable"]) && !isset($smarty.post["dnssec-enable"]) && !isset($smarty.post["soa-save"])}
            {include file="$templateDir/includes/alert.tpl" type="success" msg="{lang key='changessavedsuccessfully'}"}
            <!-- CNIC: Add success message: END -->
        {/if}

        <!-- CNIC: Show KeyDNS specific data: START -->
        {if isset($KeyDnsActive) and $KeyDnsActive === false}
            {include file="$templateDir/includes/alert.tpl" type="warning" msg="{$lang.keyDnsMsg} {$KeyDnsNameservers}"}
        {/if}
        <!-- CNIC: Show KeyDNS specific data: END -->

        {if $external}
            <div class="text-center px-4">
                {$code}
            </div>
        {else}
            <script type="application/json" id="cnicDnsI18n">{$jsLang}</script>
            <div id="dnsToast" class="cnic-toast dns-toast" role="status" aria-live="polite" hidden></div>

            {include file="$templateDir/includes/zoneAdvanced.tpl"}
            {include file="$templateDir/includes/addNewRecord.tpl"}

            <form method="post" class="form" role="form" id="dnsForm">
                <input type="hidden" name="action" value="saveDNS" />
                <input type="hidden" name="m" value="cnicdnsmanager" />
                <input type="hidden" name="sub" value="save" />
                <input type="hidden" name="domainid" value="{$domainid}" />
                <input type="hidden" name="dnszone" value="{$dnszone}" />
                <table class="table cnic-table">
                    <thead class="cnic-thead">
                        <tr class="cnic-tr">
                            <th class="cnic-th" aria-sort="none"><button type="button" class="dns-sort" data-sort="name">{$lang.addRecordNameLabel}<span class="dns-sort-icon" aria-hidden="true">&#8597;</span></button></th>
                            <th class="cnic-th" aria-sort="none"><button type="button" class="dns-sort" data-sort="type">{$lang.type}<span class="dns-sort-icon" aria-hidden="true">&#8597;</span></button></th>
                            <th class="cnic-th" aria-sort="none"><button type="button" class="dns-sort" data-sort="content">{$lang.addRecordContentLabel}<span class="dns-sort-icon" aria-hidden="true">&#8597;</span></button></th>
                            <th class="cnic-th" aria-sort="none"><button type="button" class="dns-sort" data-sort="ttl">{$lang.ttl}<span class="dns-sort-icon" aria-hidden="true">&#8597;</span></button></th>
                            <th class="cnic-th"><span class="cnic-visually-hidden">{$lang.jsEdit}</span></th>
                        </tr>
                    </thead>
                    <tbody id="dnsRecordsTableBody" class="cnic-tbody" data-empty-text="{$lang.noDnsRecordsFound|escape:'html'}">
                        {if $dnsrecords|@count == 0}
                            <tr class="cnic-tr dns-record-empty">
                                <td class="cnic-td text-center" colspan="5">
                                    {$lang.noDnsRecordsFound}
                                </td>
                            </tr>
                        {else}
                            {foreach $dnsrecords as $dnsrecord}
                                {assign var="hasPriority" value=in_array($dnsrecord.type, $prioritySupportedRecordTypes)}
                                <tr class="dns-record cnic-tr" data-record-type="{$dnsrecord.type}">
                                    <td class="cnic-td dns-cell-name">
                                        <input type="hidden" name="dnsrecid[]" value="{$dnsrecord.recid}" />
                                        <input type="hidden" name="dnsrecordtype[]" value="{$dnsrecord.type}" />
                                        <input type="hidden" name="dnsrecordhost[]" value="{$dnsrecord.hostname|escape:'htmlall'}" />
                                        <input type="hidden" name="dnsrecordaddress[]" value="{$dnsrecord.address|escape:'htmlall'}" />
                                        <input type="hidden" name="dnsrecordpriority[]" value="{if $hasPriority}{$dnsrecord.priority}{else}N/A{/if}" />
                                        <input type="hidden" name="dnsrecordttl[]" value="{$dnsrecord.ttl}" />
                                        <span class="dns-name" title="{if $dnsrecord.hostname eq '@'}{$dnszone}{else}{$dnsrecord.hostname|escape:'htmlall'}.{$dnszone}{/if}">{if $dnsrecord.hostname eq '@'}{$dnszone}{else}{$dnsrecord.hostname|escape:'htmlall'}<span class="dns-zone">.{$dnszone}</span>{/if}</span>
                                    </td>
                                    <td class="cnic-td dns-cell-type"><span class="cnic-badge">{$dnsrecord.type}</span></td>
                                    <td class="cnic-td dns-cell-content">
                                        <span class="dns-content" title="{$dnsrecord.address|escape:'htmlall'}">{if $hasPriority}{$dnsrecord.priority} {/if}{$dnsrecord.address|escape:'htmlall'}</span>
                                        <button type="button" class="cnic-copy-btn" title="{$lang.copyAddress}" aria-label="{$lang.copyAddress}"><i class="fa fa-copy"></i></button>
                                    </td>
                                    <td class="cnic-td dns-cell-ttl" data-ttl="{$dnsrecord.ttl}">{$dnsrecord.ttl}</td>
                                    <td class="cnic-td dns-cell-action text-right">
                                        <button type="button" class="cnic-btn cnic-btn--quiet dns-edit" aria-expanded="false">{$lang.jsEdit}</button>
                                    </td>
                                </tr>
                            {/foreach}
                        {/if}
                    </tbody>
                </table>
            </form>

            <div id="dnsPager" class="dns-pager" hidden>
                <span id="dnsPagerInfo" class="dns-pager-info" aria-live="polite"></span>
                <label class="dns-pager-size" for="dnsPerPage">{$lang.jsPerPage}
                    <select id="dnsPerPage" class="cnic-input">
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </label>
                <span class="dns-pager-nav">
                    <button type="button" id="dnsPagePrev" class="cnic-btn cnic-btn--icon" aria-label="{$lang.jsPreviousPage}">{include file="$templateDir/includes/icon.tpl" name="chevron-left"}</button>
                    <button type="button" id="dnsPageNext" class="cnic-btn cnic-btn--icon" aria-label="{$lang.jsNextPage}">{include file="$templateDir/includes/icon.tpl" name="chevron-right"}</button>
                </span>
            </div>

            <div class="dns-add-sticky">
                <button type="button" class="cnic-btn cnic-btn--primary cnic-btn--block" data-dns-add aria-controls="addNewRecordContainer">
                    {include file="$templateDir/includes/icon.tpl" name="plus"} {$lang.addRecordBtn}
                </button>
            </div>
            <span id="loaderIcon" style="display: none;"></span>
        {/if}

    </div>
</div>

{include file="$templateDir/includes/modal.tpl"}