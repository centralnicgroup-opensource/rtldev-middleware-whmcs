<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
if (!function_exists("cnic_GetConfigArray")) {
    require ROOTDIR . "/modules/registrars/cnic/cnic.php";
}

// ------------------------------------- STANDARD INTEGRATION FUNCTIONS -------------------------------------

/**
 * Define Module Meta Data.
 * TODO: get displayname from RegistrarModule class directly?
 * @param array<string,mixed> $params WHMCS common module parameters
 * @return array<string,mixed>
 */
function cnic2_MetaData(array $params): array
{
    static $json = null;
    if (
        !empty($json) || (
            (($raw = file_get_contents(__DIR__ . "/whmcs.json")) !== false)
            && ($json = json_decode($raw, true)) !== null
            && !is_bool($json)
        )
    ) {
        return cnic_MetaData($params, $json);
    }
    return cnic_MetaData($params, ["_priv" => ["brand" => "CNR 1"]]);
}

/**
 * Validate Module Configuration Settings.
 *
 * @param array<string,mixed> $params WHMCS common module parameters
 * @return void
 * @throws \Exception
 */
function cnic2_config_validate(array $params): void
{
    cnic_config_validate($params);
}
/**
 * Get the Module's Configuration Settings.
 *
 * @param array<string,mixed> $params WHMCS common module parameters
 * @return array<string,mixed>
 */
function cnic2_getConfigArray(array $params): array
{
    return cnic_getConfigArray($params);
}
/**
 * Get Data for the Domain Details Page.
 * NOTE: fallbacks to GetNameservers and GetRegistrarLock, find details there!
 *
 * @param array<string,mixed> $params WHMCS common module parameters
 * @return CNIC\Classes\RegistrarDomain
 * @see https://developers.whmcs.com/domain-registrars/domain-information/
 * @see https://classdocs.whmcs.com/8.7/WHMCS/Domain/Registrar/Domain.html
 * @throws \Exception
 */
function cnic2_GetDomainInformation(array $params): \WHMCS\Domain\Registrar\Domain
{
    return cnic_GetDomainInformation($params);
}
/**
 * Resend contact verification e-mail to owner
 * @param array<string,mixed> $params
 * @return array<string,mixed>
 */
function cnic2_ResendIRTPVerificationEmail(array $params): array
{
    return cnic_ResendIRTPVerificationEmail($params);
}
/**
 * Register a domain.
 *
 * Attempt to register a domain with the domain registrar.
 *
 * This is triggered when the following events occur:
 * * Payment received for a domain registration order
 * * When a pending domain registration order is accepted
 * * Upon manual request by an admin user
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @throws \Exception
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_RegisterDomain(array $params): array
{
    return cnic_RegisterDomain($params);
}
/**
 * Initiate domain transfer.
 *
 * Attempt to create a domain transfer request for a given domain.
 *
 * This is triggered when the following events occur:
 * * Payment received for a domain transfer order
 * * When a pending domain transfer order is accepted
 * * Upon manual request by an admin user
 *
 * @param array<string,mixed> $params common module parameters
 * @param bool $skipcontacts skip dealing with contact data (migrator retry)
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_TransferDomain(array $params, bool $skipcontacts = false): array
{
    return cnic_TransferDomain($params, $skipcontacts);
}
/**
 * Renew a domain.
 *
 * Attempt to renew/extend a domain for a given number of years.
 *
 * This is triggered when the following events occur:
 * * Payment received for a domain renewal order
 * * When a pending domain renewal order is accepted
 * * Upon manual request by an admin user
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_RenewDomain(array $params): array
{
    return cnic_RenewDomain($params);
}
/**
 * Fetch current nameservers.
 *
 * This function should return an array of nameservers for a given domain.
 * NOTE: This function is invoked in case GetDomainInformation throws an exception Or returns no nameservers
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_GetNameservers(array $params): array
{
    return cnic_GetNameservers($params);
}
/**
 * Save nameserver changes.
 *
 * This function should submit a change of nameservers request to the
 * domain registrar.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_SaveNameservers(array $params): array
{
    return cnic_SaveNameservers($params);
}

/**
 * Get the current WHOIS Contact Information.
 *
 * Should return a multi-level array of the contacts and name/address
 * fields that be modified.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_GetContactDetails(array $params): array
{
    return cnic_GetContactDetails($params);
}
/**
 * Update the WHOIS Contact Information for a given domain.
 *
 * Called when a change of WHOIS Information is requested within WHMCS.
 * Receives an array matching the format provided via the `GetContactDetails`
 * method with the values from the users input.
 *
 * @param array<string,mixed> $params common module parameters
 * @param bool $isPostTransfer is this a post-transfer update? (see hook "DomainTransferCompleted" subscription)
 * @param bool $explicitTrade explictely retry via trade (ownerchange process must be wrongly configured for the TLD)
 * @return array<string,mixed>
 * @throws \Exception
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_SaveContactDetails(array $params, $isPostTransfer = false, $explicitTrade = false): array
{
    return cnic_SaveContactDetails($params, $isPostTransfer, $explicitTrade);
}
/**
 * Check Domain Availability.
 *
 * Determine if a domain or group of domains are available for
 * registration or transfer.
 *
 * @param array<string,mixed> $params common module parameters
 * @return \WHMCS\Domains\DomainLookup\ResultsList<\WHMCS\Domains\DomainLookup\SearchResult> An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 * @throws \Exception
 * @see \WHMCS\Domains\DomainLookup\ResultsList
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @see \WHMCS\Domains\DomainLookup\SearchResult
 */
function cnic2_CheckAvailability($params)
{
    return cnic_CheckAvailability($params);
}
/**
 * Get Domain Suggestions.
 *
 * Provide domain suggestions based on the domain lookup term provided.
 *
 * @param array<string,mixed> $params common module parameters
 * @return \WHMCS\Domains\DomainLookup\ResultsList<\WHMCS\Domains\DomainLookup\SearchResult> An ArrayObject based collection of \WHMCS\Domains\DomainLookup\SearchResult results
 * @throws \Exception
 * @see \WHMCS\Domains\DomainLookup\ResultsList
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @see https://kb.centralnicreseller.com/api/name-suggestion
 * @see \WHMCS\Domains\DomainLookup\SearchResult
 */
function cnic2_GetDomainSuggestions(array $params)
{
    return cnic_GetDomainSuggestions($params);
}
/**
 * Define the settings relating to domain suggestions
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 */
function cnic2_DomainSuggestionOptions($params)
{
    return cnic_DomainSuggestionOptions($params);
}
/**
 * Get registrar lock status.
 *
 * Also known as Domain Lock or Transfer Lock status.
 * NOTE: Not invoked for domain transfers
 *
 * @param array<string,mixed> $params common module parameters
 * @return string|array<string,string> Lock status or error message
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_GetRegistrarLock(array $params)
{
    return cnic_GetRegistrarLock($params);
}
/**
 * Set registrar lock status.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_SaveRegistrarLock(array $params): array
{
    return cnic_SaveRegistrarLock($params);
}
/**
 * Get DNS Records for DNS Host Record Management.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed> DNS Host Records
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_GetDNS(array $params): array
{
    return cnic_GetDNS($params);
}
/**
 * Update DNS Host Records.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_SaveDNS(array $params): array
{
    return cnic_SaveDNS($params);
}
/**
 * Get Email Forwardings
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_GetEmailForwarding(array $params): array
{
    return cnic_GetEmailForwarding($params);
}
/**
 * Save Email Forwarding
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_SaveEmailForwarding(array $params): array
{
    return cnic_SaveEmailForwarding($params);
}
/**
 * Enable/Disable ID Protection.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_IDProtectToggle(array $params): array
{
    return cnic_IDProtectToggle($params);
}
/**
 * Request EEP Code.
 *
 * Supports both displaying the EPP Code directly to a user or indicating
 * that the EPP Code will be emailed to the registrant.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array{error:string}|array{eppcode:string}
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_GetEPPCode(array $params): array
{
    return cnic_GetEPPCode($params);
}
/**
 * Release a Domain.
 *
 * This feature currently works for .DE, .UK domains and .AT domains.
 *
 * TARGET    Where to push the domain
 * .DE target: TRANSIT (push domain back to registry)
 * .AT target: REGISTRY (push domain back to registry)
 * .UK target: EXAMPLE-TAG-HOLDER (new IPS TAG) DETAGGED (push domain back to registry)
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_ReleaseDomain(array $params): array
{
    return cnic_ReleaseDomain($params);
}
/**
 * Delete Domain.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_RequestDelete(array $params): array
{
    return cnic_RequestDelete($params);
}
/**
 * Register a Nameserver.
 *
 * Adds a child nameserver for the given domain name.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_RegisterNameserver(array $params): array
{
    return cnic_RegisterNameserver($params);
}
/**
 * Modify a Nameserver.
 *
 * Modifies the IP of a child nameserver.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_ModifyNameserver(array $params): array
{
    return cnic_ModifyNameserver($params);
}
/**
 * Delete a Nameserver.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_DeleteNameserver(array $params): array
{
    return cnic_DeleteNameserver($params);
}
/**
 * Sync Domain Status & Expiration Date.
 *
 * Domain syncing is intended to ensure domain status and expiry date
 * changes made directly at the domain registrar are synced to WHMCS.
 * It is called periodically for a domain.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_Sync(array $params): array
{
    return cnic_Sync($params);
}
/**
 * Incoming Domain Transfer Sync.
 *
 * Check status of incoming domain transfers and notify end-user upon
 * completion. This function is called daily for incoming domains.
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 * @throws \Exception
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 */
function cnic2_TransferSync(array $params): array
{
    return cnic_TransferSync($params);
}
/**
 * Return TLD & Pricing for sync (WHMCS 7.10)
 *
 * @param array<string,mixed> $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return array{error:string}|\WHMCS\Results\ResultsList
 */
function cnic2_GetTldPricing(array $params)
{
    return cnic_GetTldPricing($params);
}
/**
 * Get Premium Domain Pricing
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed>
 */
function cnic2_GetPremiumPrice($params)
{
    return cnic_GetPremiumPrice($params);
}
/**
 * Return Additional Domain Fields per extension and order type
 *
 * @param array<string,mixed> $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return array{fields:array<int,array<string,mixed>>}
 */
function cnic2_AdditionalDomainFields(array $params)
{
    return cnic_AdditionalDomainFields($params);
}

// ------------------------------------- EXTRA CLIENT AREA FUNCTIONS -------------------------------------
/**
 * Client Area Custom Button Array.
 *
 * Allows you to define additional actions your module supports.
 *
 * @param array<string,mixed> $params
 * @return array<string,mixed>
 */
function cnic2_ClientAreaCustomButtonArray(array $params): array
{
    return cnic_ClientAreaCustomButtonArray($params);
}
/**
 * DNSSEC Management
 *
 * @param array<string,mixed> $params common module parameters
 * @return array<string,mixed> an array with a template name
 */
function cnic2_dnssec(array $params): array
{
    return cnic_dnssec($params);
}

// ------------------------------------- EXTRA ADMIN AREA FUNCTIONS --------------------------------------

/**
 * Provide custom buttons for domains in admin area (label to function mapping)
 *
 * @param array<string,mixed> $params WHMCS module parameters
 * @return array<string,string>
 */
function cnic2_AdminCustomButtonArray(array $params): array
{
    return cnic_AdminCustomButtonArray($params);
}
/**
 * Resend the Transfer Approval Email
 * @param array<string,mixed> $params common module parameters
 * @return array<string,string> process result
 */
function cnic2_ResendTransferApproval(array $params)
{
    return cnic_ResendTransferApproval($params);
}
/**
 * Cancel the Domain Transfer
 * @param array<string,mixed> $params common module parameters
 * @return array<string,string> process result
 */
function cnic2_CancelDomainTransfer(array $params)
{
    return cnic_CancelDomainTransfer($params);
}
/**
 * Reject the outgoing Domain Transfer
 * @param array<string,mixed> $params common module parameters
 * @return array<string,string> process result
 */
function cnic2_RejectTransferOut(array $params)
{
    return cnic_RejectTransferOut($params);
}
/**
 * Approve the outgoing Domain Transfer
 * @param array<string,mixed> $params common module parameters
 * @return array<string,string> process result
 */
function cnic2_ApproveTransferOut(array $params)
{
    return cnic_ApproveTransferOut($params);
}
/**
 * Suspend the domain name
 * @param array<string,mixed> $params common module parameters
 * @return array<string,string> process result
 */
function cnic2_suspend(array $params): array
{
    return cnic_suspend($params);
}
/**
 * Unsuspend the domain name
 * @param array<string,mixed> $params common module parameters
 * @return array<string,string> process result
 */
function cnic2_unsuspend(array $params): array
{
    return cnic_unsuspend($params);
}

// ------------------------------------- EXTRA COMMON FUNCTIONS --------------------------------------

/**
 * Return Zone Configuration / Feature data (used by Domain Migrator)
 * @param array<string,mixed> $params common module parameters
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return \stdClass|null
 */
function cnic2_GetZoneFeatures(array $params): ?object
{
    return cnic_GetZoneFeatures($params);
}
/**
 * Returns customer account details such as amount, currency, deposit etc.
 *
 * @param array<string,mixed> $params registrar settings
 * @return array<string,mixed>
 */
function cnic2_getAccountDetails($params): array
{
    return cnic_getAccountDetails($params);
}
/**
 * Get Host Objects / GR per Domain
 *
 * @param array<string,mixed> $params registrar settings, plus hook vars
 * @return array<string>
 */
function cnic2_getHostsForDomain(array $params): array
{
    return cnic_getHostsForDomain($params);
}
/**
 * Return Result of Transfer Precheck
 *
 * @param array<string,mixed> $params registrar settings plus hook data
 * @return array{success:true}|array{error:string}
 */
function cnic2_precheckTransfer(array $params): array
{
    return cnic_precheckTransfer($params);
}

/**
 * Get Public WHOIS Data of a Domain
 *
 * @param array<string,mixed> $params common module parameters
 * @param string $domain domain name
 * @see https://developers.whmcs.com/domain-registrars/module-parameters/
 * @return array<string,mixed>
 */
function cnic2_whoislookup(array $params, string $domain): array
{
    return cnic_whoislookup($params, $domain);
}
/**
 * Get Aftermarket Domains (used by Domain Search)
 *
 * @param array<string,mixed> $params common module parameters
 * @return \WHMCS\Domains\DomainLookup\ResultsList
 */
function cnic2_GetAftermarketDomains(array $params)
{
    return cnic_GetAftermarketDomains($params);
}
/**
 * Returns the supported DNS record types
 *
 * @param array<string,mixed> $params WHMCS common module parameters
 * @return array<string,string>
 */
function cnic2_GetSupportedDNSRecords($params): array
{
    return cnic_GetSupportedDNSRecords($params);
}

/**
 * Returns the default nameservers to use for the DNS management feature
 * @param array<string,mixed> $params common module parameters
 * @return string[] list of nameservers
 */
function cnic2_GetDnsManagementNameservers(array $params): array
{
    return cnic_GetDnsManagementNameservers($params);
}
