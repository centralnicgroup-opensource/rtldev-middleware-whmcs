<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrIHiADjVmcKQ2CbW5EtpO2+rN8j3BADUwkuQJS5G3UG5EnCiSf5UOp/NuzEm/bsSsIGdEZq
+t779avwQb8zu8xkVuhXYCdzrjUCdt5g06zVoZLlq4NhpLg7CJHJR133/vt2u2+vJuMA8eyRdIoB
Q9jyV8pLu83Dr2dfsFEWn9kuyKYgoGYU5Tw0tguC9qAO3HROLMloGBD/bw7ZbsOxBNhBQxLfaq4G
M0uY787g918JMUjr95AmTp0JvompesFm+N6oNqaS+U6plwEW2t370xYjprXhHAbj+PdFX91T7efY
MUS4N6z6v0UHRFrQEqalU8BXQdPLEwmfDMUk1Ntg2ma5+/5e7pBBRbexRN23Lmpf4QSeBcUUbzzL
hQ8Ww4+53QUvv4XPUF/dy9Naq4IAudrUxVWn0LCWQJvXt17rs5pTX7DdedpUpineYsekeeoe/Koi
Q8QKdXhr2/ZOJIaI9kOmdHmsJWwQRjTfQ+RDVi9Z1dDQzcWYI2vmAwKlHM/glBl7KDuxcM43jk74
CEF6LLsulczWrZu1GgwSEsgM+yZEYwZyUSPS2L7lNVR2ZxWtuoiO7diCJsLwJmvNxvblhcQc0rQd
OAt4ScPuVdb+hs0AU+VlZ7BEMWY90FiGhNgQwd3C5VTOxMx/ymfRhCYlhvm4ZlSgodSioTRWVmnP
BETlkNx2K7H1dZwPEo/wRAPum448OIP0yYCLaFNPONVWFWjI9yBJCjvOaViCC/8VS/RwCZ0tZHND
l/3cPyssSwdFvOZIxtveQPL+U+/9WnklWFBY8+osq6pyWMCDDit2I8ujZJQJkhF3lm3GlCPy+FfU
PRx/Q0KWCTtvigzXIMLm/k1GjxFuLeHE2wHig1rhIsfybcUWX0NyiBf8KIy/h7/OYJwbJz4PMUGb
lme8ztTtP7bDqzrg+whjlEo8zyb9yOxv2AuTvOQynaheDTA44xkITd/bh4TRE5ym1rNNCy+cbWcm
L5aHZY6AP/yIBBXHIo9LCb+3sDcuKo32PGXckysg795vXsQ36LiG82AIjEGQV+3mzy8fpqsCXXdI
zlRWdmBySPnMe+NKVuKIdRJGE6vXhH0EI6YtWxvTAeikYjzuwDYbNZBPon76FHyd0Co0uFpT2u6K
UY7OiYCOk5seQYyIuzw4EdZ5gbp2gI1cu2wDDPlwpWcKL7k/pbOsbHT8MvJUv6cANyCZbxBSquXR
GGRuCpspZ+AAsezdWVPzkSwAqOkWfopV8h0vmk+aIOcgS+ozmYpUWgqiToaodqGADRqeZFTyAAiz
RF2IehPgddzs/QWZkdCFOrVQd38UN2+6RK1Pvw1+ahfqYRnunQbLiJMLeI+zRmDSPo6aII8dM49G
KwIJGzCenvHZMVG5hblLYiaQMXTrT5CstTqGFvEY9Mhgs92B8Z7lWXT7p7SUGJPh4opvy/yvYX2m
EJ7qB58sDRwryldO6eKPXVXYVvo0D6Yn1cmvnE1R/6ur0khPWgjx6lO//ue5KHFVM52ZPi+M7WdJ
CNTXP3BYJqif8SBZz0tY0mhLUJrC18msiZ0xJsaNV5yIQ/u8/qcE5zHBuBL6/nnEhpCiQH3p4iWb
6yhWxdhVc3HcELdyJjRvB9lverkLgFHDX9iavf/fXeKFz6cUH23W5lFR5kts2w/WCkzMJRZaVj8U
sMTnv2Z4qSzLm1Z/B7mJ6W0rLx7yLKA0ihbhXdUFVWL6ubchwp2ckF+KebXPognuGyJlawgLC7f/
j9X5YyAbvDQtGZxsybbvmz5Gym/iCBzPCqVFTbf9dBbkckdjMkQN4/J1d+7kgA8sTHeIQCJvgctO
ijBKNfAjYF+swer28IEVqoMDCHefE+YHNlBPSdiREoUVlNPijh6Z1U1YlBsUQ22eDcwzb4HFilyp
twmjCHa/mhenWVdAw/Aj6M/w9DLc+58URq719W4sb+Wb5aLUDS6kkWrtHm1qgIa9CvULqsnbBsIu
ZIeu4erEv8L6LfjQkSXYJ2FGprjUIY5K9gSWsEr2Ib6LmnzoLJgxM0X4UorVJXcKmfY2OoAbUz7T
l/cU4xpdGIDg+YrlDne5Bjvwvc/007jQLwJtdHU3g2gWTT0=