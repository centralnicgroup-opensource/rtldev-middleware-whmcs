<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz8WC3hBe8Wzakwb6S8rXV/KNICrCEXd8R6uAzfH0ZCcUTJS9jcdiFf9ZLEtPmRB5uwS6fU6
e0w274pyb28QutFjQIk0hAD6nnNWCkF3pQMBvXP0pf5Cn64pImSdRhPsUEy/XeddejENcUFliaNP
4YbiLo/LHfhwGhw4nkNX6MRt/bFqXtbTVl9HqZWZk1EvxgmxHanrtOIOYRQpENlDuyIv51QTkkG7
9xMiGefU1zGMCrzsx7Qy9Sxvj/N9GnKmp0pV3E+cvjY6REXvMmDmVRK+IkLhtiLXnZj9TJY3tuc2
DWShojd7nE/MVj4Am2BQrkxn1fx6IPuYpr99UeZoe3QXTF++3y18w36I6ttRLsYP4Q+8HDYgnCZv
bhIWB3rNuRjrPgSaBXPAkd6nvoYeC0meLy7KGr29QP4S4QRbPS/dviQMpW/0950VKfyrzPBbztcE
TJfDQaNyGzB7xGLf88ra+2vqZ/5++N/sfmGHw0KeurSTo1ojzyravgQDTEvm7jfKQQRHO4CG0+AQ
z+j5IZ/vr2J42de2wf/WTWQmQIyZk9R938BaAYUHWIr9jZcBNNiqrP1RMkfVUlYXOaMeplKM0lQk
+D4mzUwi/4MJ8BUbALx31GtiiTXQNaD3hISrDHVEtP36oa//sDRlB8RzfgnrIYm/CogL+1YGRub/
wPUACm74c7CjQDxVcBBKO2km5h7iN6uorkLQ8zjfZT2mUi+kLHrlD/vXNmHUmQGRioHd2mLEEXop
aO5cWe+9vSgsvXDKoaf0nCDCX6p6dNmH6YGKtvTxxSsqUQzL/MvBwvNOuCHgejUGxFAfAVBvYMj/
7uOxFX4lyxaQNEM5paWQWP3+SsUxzp7nrjBNLoaB+YQD5PhKbS/DALRrfbPfPeqaX3eVvIng30PL
0SUvkbBsg83vekv8DXmpxkIxUZSDhUwuOium+rsZslaVG+Hdj1f32oY3FzcSMQqtK/JvTsRM/TWW
Aes4ioTk0V/3vFwf9HFK5z3KyNZRTKr1EP+Q7El3LgVbO6Iknwv6I2RxeQzssG6HWBEMiBfAo7KL
Wxza/uZurLz/mJM1PjmvJNHdbQFSIR5OdHvFY9KE5X1s7LjfK+3ijZyEVQJPr2+wqGNUEDUQe4rt
EQMne4Y+qPKCtLV8jTaHRVpr94+PusI3vrXfT9EvBr5Y/ySjrw/MlE5FrqZ35k4z9VewaHGiQ/4D
TRC9X4j6L9cIKsjaKngR3Amvo3KE7mUsqMIyEpdqc+z69hA93KjcdQix66eJbCGhW49bNkrUYmJ6
6KcHiPj5MX0gqSTiFwUWVpbPz+Uiwo7ulxxQ9asrx7bKcYD0DWPf38skXJy2uU3l6zI/LuA1Wxp1
uk3szW+0PYfISQc9AB9f65UECnyOtsJ9Uo98YVwQUL3Ahu2SFGfv4n9Hnlki6vHRdKSVlJVHfyWo
t7FvMx2CmC1x6QeCX1xYzWy1PwYrBbGb30XguY+OIyZPBq3NS+UBTyUDjcbWkw9z1wl/9V7g1dbK
RZNWL8a7k7WBhya1Jnfl6iH3RmG9xD7UsqiuKY7zdvq8No5MKvFnfM9zQw22JdQcMD0JAEgRtkLB
f8yUZdH35WYJmrbF/TqL+PdPxCaOCgzualPKVmylv4dF8+gop9zsFRJgG7iKER1VsTeU3qpz1fRr
ZVWgoB060gz8LV0fcqp/NQgma05TkVGb834uQ10KXNhjZ4WS0SPCHQ36uDQR6XJCuBa99ApAc0Dw
e+9UpqVhraEXWlyTIoJtjv4L/9s2Yqs8raEsBw8J9XpUQYKKWnVSuF2al20xBKJtC4NWQZXI45/U
fxafIW03MUOo48gjjCgfp0PxtvEjBaQ9jtEkvl6V3UOMqhK88qEJMxogbRZwoujXf+LAvfeNs4UN
AnFal89HhkliX7MEX3RMK993/2ZhdJqGY8vmJxDNxN3bn16kGuuD1edSrOta+OtF6vVtj7whFjw8
Agghcq32kB0ddh8PVNM5vWLDFMf/RoNLJyCHImLp8DwDfeOu+tlKtWFcLV+lQUtTvT8kprAQpWpK
Y7++6WUw6J73uRYhIn9XVbgPvGrEHinhwg7EJhpcZazGC+EXK+nL2Qg3FPQQZo8ZC0l+jl/HJTLx
RKpXl8CkpqE+7EOQLTDFK8zWRWnjGhsVVxMnjE33Fj/BD1l138Z9QRf336rxWxMaozLYDkdYq0Yd
R8MxRkBR/SzHagz2kBASRZet2VCGBRYHPc1zESa/MEGu91CUbrUfyVwEmsBt9Zgj+YFrkqGTPsI+
+Vu1DK96+ijd5uiYMwiBXr4RbLNeEfR1IDt7jzeIJsyhnJA8Hy6+0zJ7UHdhUd8uxP324LeU4f87
OEyqHB9q7ZL/QrHb5ijjseLkc2HGesR2I8QP8GdCei6Aejbz+sy7URr0K1HcUn0JE0O7YEFbQ5nI
yj7Eq2V+EKjr4E2Wi/kR9FuBFnKkhfAcIC6PdGgiSSB8rEEeSvqM+aisup52Qw8/zPFTpWxVVica
U+fjeSWHOiymxTYnMOcYtytwk0I6iqi3mcvVy4pWU73O2l2MeoWsPEQuKvY7HYVVKHmqCbKTSYbj
xwK9vNt1GYiMPYffwneUI7Lqv61vvF0KDUH4Rtb/9prqWdFCK5HeV4nIUAAi8j290OTaUoYVbKit
Va3QInjOZHuZ920kUdCDZ8lwqsa8yt84ftO7nMBFY8tNHqyU+nyobCC+E1BYmLioOLJibmaa05sN
01axHLA1wlWzkDYwrfBTUsz42IoicqmxG3g733OgVaZ4AJEeBx2lV1kRbI3Cq+EtrHw6HmkjIHZf
XN7TH2FT3DQGMk0SfoOnyD6HLCkqstaQjW5/lQebdqP/Jf4leBnzzpqHlj+u7MF/vE0JMBJJ1XcJ
XbxQZ0m3e84gKHFF05/Ba7aaFzTQ/0e+ESbkK865u+1kq7FD6Qh2INSvLx6uU3koJonwjBXrVL9D
dFrRZ1SKIdFwUOTTXGnCDGRyHG9VX3Vg453eu4X4b5qp06YtAc3Pl6YZorxPHxpM0nmOwlwZxNWL
FLls4oytv1Ms/nVUz9haMWLEkxrUD5cT0h2W7mvD4Sgfq0vjaBMLNIiQXNNrhd+Md71Sp83fzzu2
blL39FnzTerFsDRboglYFKUfVu4Z+PjF2s3DsTDmt0AJ5w+HrhMkv20xhoveqnkarciTXWCE89Jn
PbAByzvOos856HxcJRTRNg5BQYt1bEqCr1Td6sRxl0eUMA7xXUyvhCww6daqjyBAxphwMOhWD7/l
gfZ0FkSzYeHF3d6D72c7IDZB1yvubAZxu8+wXW1MAyrPBLtGAruzVrMx34mVb9IcDJWRORZM13q2
+HwwTKsJfJRao64If3/RxictdNKn4m==