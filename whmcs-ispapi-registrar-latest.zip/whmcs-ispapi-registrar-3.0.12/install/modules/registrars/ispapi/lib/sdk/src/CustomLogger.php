<?php
#declare(strict_types=1);

/**
 * MYCUSTOMNAMESPACE
 * Copyright © MYCUSTOMNAMESPACE
 */

namespace MYCUSTOMNAMESPACE;

use \HEXONET\Logger as L;

/**
 * MYCUSTOMNAMESPACE Logger
 *
 * @package MYCUSTOMNAMESPACE
 */

class Logger extends L
{
    /**
     * output/log given data
     */
    public function log($post, $r, $error = null)
    {
        // apply your custom logging / output here
    }
}
