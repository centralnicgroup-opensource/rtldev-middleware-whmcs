<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtwmj/Ptdmpv3WCYrONP481TDQ+OZDoF5vIu+NDnI467sbMzeZ0BWZfETYAWEo5aqDMMvfa9
L/Gau8pEo5JB7FPdHd/1aHNZNOjfSAoMwzROIiCvpvaK/xieo/VMU84lvq9hehMYCyxLlZ1BmgU+
1UOux42Q6oyv2TFEth+XDcNimxp/J9C2wK/3nGif9kpr8X/QbM7qkxocBEVkKWPik8Au4p67Efbj
BQWrwobmpeoHWMxhVPCJHPVRo2t4wskfA8bs4xy/aYpMHNW56at4sU2pwvHjZnnJ1G1yYnCiz8YY
98WvlF8KS4sVlWCH5QjBQSyD3MZETKJJsvPaQFym2M0/wlfN0VxatvgKvMbpjy8xufFhVIxklwyn
wdpuy4MaPYP0a8wzlVJl2pVrHTmPhxq1KpHJK8EK5WkubpHi2HwCs0Mt50pJbs6hRAQJ7imgMpOl
AMyCR/Y4AVKw9/qYR1//WOQp+6ZEi19t5fPtuTTnLEuvJET61FwcuQFJHnI21WhFTPR953XGPyIk
vAm4USkToWQ+qNL284bIFK+LBilscRuQGlrCY5gmm155CXrcDvVNzCJsVCUqitC+Hk8Ef7XbgVek
opecBkPgWZeEXzA8ELR8WvYbYkWg8Z1zITO/Qlv4dyl9Z4uuZd8hkFJsaeqqolzGngK4sqArDzGb
QBf1uzc0LSQ/bpMny8j2ozqXno2PQkCfmJEIcAqpZ6zWDKsEN5h1l4SWSyeVP6C0/HKKj2oZN+8Q
zAedHtOxUpwsaGh/+AsnJvLbNsDgxPRNS3HlHmno46tGZzkNOdnnd1Dw6jS/9d3QHSvf0Pmd7D+0
UT2XLnywndYhg+c7dFaASp/5tS/kTnXOiv2XesaYOmVPTl6RC90ojoeluCFTn958cio2AoMMwkMP
A6zS27f32wdKV0P2xysdYOHIMyMSBnE8ftzicp6IjJIp5WTCsybkfRq/SjmWnvDCmLQkjt2lYo1f
I660dPfnM0Ie7pIjI/znTp8Af+x+r2Up0LDQ6YKT7Ve9VYILkzIA32522fH9bCpuUpySP9BRFOL6
0YvcloM+SVUMRGSjKwI3qapQ+161c5A8sylXNs83+qq1PTuVfVPRmXwyUVerf+j6+2QNBaJ9ceyR
0YodhtWrdakV8RA0U5NqaxobYi4dfKAfiK4l35ELyCgNVidu4C8WuSiPBUUBHZAlLpUXKQtQoc3u
4kcptXPI/P//7mX5x7ctmHsI3r0HX0MaFkUYsgsrsN5Qq6JmG4xgxSNPtdQVppN1nMQG6rITD6cq
2KjzwoSNZF57xYqL+iAkEeUii3d56u4NpIHnZAl6yB1k6JPUrfijCej/D6JmjRzZVknNIhJfbXvy
K0VQgKRln4gSDZ0Y6AjwQCQxCGfGEYDN/NqXZ8NDKWF/hB28MbAVxLlArV1Nq67kHl71TRX8cyyj
j1Oznx2FkswTcUkdrIv4s/h/id1LZaiVJOd8jCr25w269OZASH960vvhY3kIuI/RqXbGHxAGqikE
e6wInKu/DTfh+j5/47XVE9Yirh4bVpEfJ+G2ssRAG4OMfC3YZuVzCFquPgiRNEGx06dokU/tttIQ
iO/DTTW2NMv72hnGr8dXWMzhSqPhAU+3oIQakt28jtWUaqdjQgo/54cWNo3eg5I46iMAKNQQPj+W
vwZGAW6L/N9HzS4Sse1CMcDF6UEeVMKN9N5tA/pJuYxiBo4sUDa9Jz6Ko+GPaWmUOlzAYXLqN1a1
TfhO1t1O80yIXaT5o1cV5n4s4+50t+Xz+cncGbDGbguptUEBGjgzUuCpUg+awO5RalPwJhIobpaA
mprhaYg0OCJlKqQYYxUsOuR2vUiWstLTP64gPmI0T3+d1VUqeyXBAXGwqf0Tm9qKAvFt6B+rOB+o
aSRkyFEj1lSxgdNd8ZBv+uWnKg80PmwX1K+9sHy7osCS8OUwAbdeEuReZ9wtgVDxJAwS3R9BvqSb
4MhMGtlYTh5m2fn+SG130QFLD+J7YhVMlX3zo/bi0z/ntJXdH4xQy/Et6rGXw2FRDCqqJlP/QmuF
HEPDYpDNGAJwX2pRiLmJtgqCA7McI8h00nOsLAz7HXdGT6jEk4VERvrNpdbh2jGDDu4I2mX1pvCD
/RLMYIgNcZCSgC9NmGbPEkDRAe+rykaM/0bMGboNwdPCdENpT2GHLgVs+qDHnMhzqw2W+r0c1fXw
bNuUvmySIMFFSqAw5sVOHqhu0auLaHAnbkee5jwtNesgqvLev1kj09xi+ZavHNbi82b4Bo5e0xW5
06kSQUnOqETiqHL4874i2hcHWOK7/BeKvSSxb3eu8EIGT7Dk2VziA9qmNcpw9klvcn7+pbVz5syk
nRWeCEZLhYptgTG=