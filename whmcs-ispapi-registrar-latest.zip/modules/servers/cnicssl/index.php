<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsB23rSMAVIOxtMQTBsBRPHVls5tZ38w7R2u+8V88ouK8yiGC0XKfh/aThP1lmIAUkUAm37E
eHtFI82YZnxKu59gvH8fSnhjyknGoNPtLiLAgBlFbxYOgVfkKafMCp4ngHniol3UrVBlSmKCX5cq
siXz+TqcGQPa3HHiQwJ+lqBIDIHN3w9M+im7F+kCqZL0RxwbRhstyx6RprWdpzz+x2jltMPDebFp
yIlLUDUf8DOcseRmrEAGkpRnRO2Tg/fgjpFdxhKcQJ7FrAUrfXHzWVZQ65rmrrNAAA+u+4bG36RY
N0Sp2S6rt120nt1HnvFe4aiPxY+H1tSOrWbbiaB8sotoyquCUPBgR2tIqFgVsnAKrNfZUtPYcErB
pMSvPqzhDx4zmNbS9hCdWIv2KhpiT6pBbgajhGO9zCfhH3+IlW5RsUCMUeyAdZOLWMLYB6EtGRGw
ptF4iPbPN2CIA2p3fRxxdcffduuYPoE/fjo1LUTq8qLfpRgYIA5NyJ2cN70dysXHRZKAXOWn6xU+
t9EwY3reWUOaTnYi1XKpze7n6aq67aYYFrbBxUBwMeTH4/X8E34f4pPDcNSu2jcAefX5ZCAcis53
tH4kWfzyqHiVCyufTFNf0vfJodY3BWOB6xW5phErtrjm08w2EtC4udjY2nY7rweeLxyEeP4xFIME
MAoSVM9Sq+f22z4MHGwl4M5P3B6WNY2azrPzzJ0n08FYiqKi5Uabq2YySNjDOGsEx9/9LQ3PUWum
nRVmK4LH7TImakPIcLU2ZgPeCfEJwckYAl2RVJ4wtcktJ1Q+2/mgrQTW0dO4QHBnOUV18Ir0wwiP
OgmfQS8q4eI7DcsMj608Lnr1jO2TOaHIDyFKHPqQswIzn0pr