<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPub93lx9bFBnbFgRtKFR+oBykxs/prVTawEu1+2Yo27dlvXysnn9SWIvIFSsGSym83wxFvwH
HbwfGQaNbh2/yuzjimYX3tdRE33lACl+3ZQHKPV9IPhM/naN1embZd8Zp1dIMclRS7zj8gfAh3Am
bDUUldN8+Xpx+FcHB+WZEzB12KyGMng8JF4h+3cReXkJGjw5IlIFTTySFoOVJ3s9lzaXnwHI17BN
7FIOzpMuSXT1J9K5l1gM0t2CiHWCWpGfsxnj4xy/aYpMHNW56at4sU2pwrzfNAbhLbPcv49E5SXI
AWT19N7zUZN45HTckNWchdkLfbHU8krmNUgjjElS7pe5sxdLH8Mdbl212Lba6440pc/hOjkjJscs
CHnRLVD5g310lVsm/oUxX/t6W/gVADk8zRvMCCFhQjmYX2RxyXq3qYAJ1gdTXeDPxAMKf0kHTsYC
+EFh56B5FWsybrhQ9X3cLBQeB9RsJj/lAcrWukQV9vdCStGbPoQmk/A58+1hi9TiLrShhN2/RLpW
0CWRjYmi8cJq2IU/rZCVOSSms0U8UI+p5gR7kzeTcYODIwK8tC+r2Uo+4HM+jITTJkp0sgJK/1R8
xI1pFvtr63NqCMgQ+WPsAMAySl2sKV2Vy4WBL+ZqnjgRuoGQEIN/nsjVj4ffQLa3uNteCbSq8CnE
O79I6lapD0PcCEXQ42UCE9SXtAj4Ho0x80zbyzRnfgdPJ4Lr3s948dLXRBADVsE/DCUnY7C8/wUB
basIjVWlLC+hELwSe39UiljJYWzqnnXrIFuEQDII2bpo8BPaBMY36PiDcWToVu+OMFPZdWhMsoaE
17cG8OITuESIrmCzcqT1wUZj/9AY/laXtvp1k7W29M78er/O32UUTSPvsuK4kTi1v92s32l0GzBy
QWg891nJjSNA0TCuS/hPrloKwL8xvBq67LcAx+yS4iQK6xp86uscK1wv4rkT8od8oCm6qUm7iuKu
0JEh9WtG6qnZOVyndnQbU+upXpqCSH3Fd9Y9ot/vKfa1GsA+LEsO4sY1FPd9C0mxL8qZyaxSngjL
VuM+EuiJXquo9cGcSRD9QqyW43afkaFFZq3JhiYSkugQO4aoNIsQWssOgFYYPepuzVRTo8hDy9P7
OrAeV4ik6pL6srIxmh7fRG/ucBKdrguerQ812Ol5d8+Uyt4R6ztNOZjIYzNolgBVi6/GEmrbEZS/
gXIrzRr7BNGfKRavo74CsqIy3ONWK0Nq4uVncPgbWcDH6GGiBaZW96bZd/us4rwyZq2t1vzr4etu
K8uTXY7gjdIj1HK1hkP7AfX9fBkje0L7l8d3nZegZ1GBnWJUXZGwsXdu3/LcUrB6NoM9ncZONgHo
ic+B4zyALiNeJOcdgymadkYdSP5zsJdFftJ2XT/fPrCzsNYRy1MYIxkGia62VGSfsV2SQDUly4i/
4ZwRaQH/TknD0g8mE6mxxIdAP9FGua4ikWyRwMc5ydmZNxqieinT6xW/9vWKYv1gvoAk8nhvu/tE
3j6Ot9M9gE8ej3XcVz36Upt/nwUKW1ZvpUTEeiuGyyuLG81jdmvQhgFfDEr6Jgpo/zyLJLL5m08M
5YeC7Nik/tQ0WyIHR+RMLvT9foPuiRVVCOeloKHbchn/90OA7hZzsiGRKsv2IjLlUjbfnES55hUz
Hf+TIZBQHjQP8HgTj5V/4p7RO2Gqz9XBZJJUAkesx788pVr/VZSeDc5x19ZHFInc7YEXq36L78gh
RLD7872aq1XXifo7GpDoXg8ACCnpscCTsD1YhH/BWomPBFDYNMn79kvmvPjX6bbQ3fBHdLBM7ASR
QoDykiIZCe0HYibFuDca1spj34O5iwGb9AqzZDtd+e2FNQZAP5nJafuWZLBb214Cm9CXiiHWJEmY
LuegXMHckDlLAGHAHQoG1rXHfzdf9m45IdVpCvXDTTr6UE1Fia0MAY2Ra/fI7EDR9OYeAVO3ISVs
uxaV5j2VJ/ghf0ojIm76/LJfoNEJPEx55+3HZ6T4TCDScTx+e+FH2x292IaxR9WUM11J+UnDO2jC
Vm//aUfipnitPt4fyDXz+62FWfuAp2i+K7hkdudEPDLzhyDMDCveZES3AcI4ahNFTYHw/ANyo9tz
CXCZJt3w1kHjxlMAZMmzGwsAjVUpc6B1mkgjyCl8ue6qF+nCC6cact7qKzGkA9Zbfcfi2/uUf3Dd
gX6qOCFNLOqN6Dio5swrPuWxi5YMcwDs3Sd/kF1gI7Q6Edx1+9442dvpqwuJ6zT+iXllpFENPmtJ
GmjkZozLH3sNibCMEacX34aN0Z/I/BiU7ADnOVI7aJY3zdR0sqSxuyHXElHzI78+f9tkHMEsZkXT
TXzQoyDrFWkzMraINiEzYef22DwU46Cm3ChMfEa0zyK=