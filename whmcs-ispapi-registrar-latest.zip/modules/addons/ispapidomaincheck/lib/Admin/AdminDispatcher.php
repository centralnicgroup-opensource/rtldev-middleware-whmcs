<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPytPBCo69fNZNskvxuT02O46nsw28qlvgBgu5RyE103/0Ga6sYDZc1WqJauux8dVaplQPNzQ
kj141GzPErc16HymD2nbfHDD0e2BXdVmRRhfda+zq303kTotgZIXb2DHw5DMaOdXNWbnxUKVnUDg
CCoGWNCas8XYgM434rhpHFizsk2aIA3jVrciGAHjixJEKAJ7qJXJp4a0v+5e7Povh38CevUz75H7
lf346kgGKG7La8qOrV3o/hZ66kXoWh/wHRBG4xy/aYpMHNW56at4sU2pwnHeoytob5h8eMZnFyXI
ouSa/uSMRnEjSE5RG3hRGkjqaUCZur8CdIwz09cQH/0cguPw3VtvIJqL4blcQXaziGoJkzdrbJXx
9SrksqoP6YO/6L3eNEJ+Yz1PCPEXDR+J82QLOwRUglLSd1Gtd0CAYt1LY51Z0TDht7jO/5pnPcYz
c3OAD+dmo0c3wTEqOWKhcT01UXlOZV+aiuQr/00tGalvsJ6dnsEpXkwbv1JnzECST/9Lp1f9vxHF
UGYD8hbegSPLzvT4uV53RluY7Euo2+Dx0yMUMwNWxqzCHyiwmA1KA2nZcykzUNIcEsUs1J49wLAu
HT6u81wX7hqz9udQnlJFx0Ltr0bQxpKGY63VpFPcSp1d3iX0/tF2iWBpAlShuzpx8dfMWekL1Hai
K8ds8/PktbZM8qQGSCl4I1mkmbWl44BJeu86V9DucNc6tgMxmKi2Pj/7/0jWvbGBdhZHwtMdLiEp
q22xvf6VoPglEv9nOb3a6INAt1RYRP2nTPVa5CqtnV3NitcQR3WQkwlesAfLQ8kK06Ru75OvHcyF
OBS0fOI7xrCgJIu1tlgFwFnzvROO7JVj2hzBM0Ty28RXGc1zEMaDX2eJCO+QDsYSle8FseuD0Cum
Vy+Z3GEp1ssi6pvjVXdHRR0Xy6bA8iTMYBUZMf+lf+s7g9J6brVt1LT1yAaRujrEXIRakyugifUe
jwIXA1B5UVy8jdD2v4UZhOyovMk222USEavrGuu1AdrHJAkL/XoCPoBH4uysX2WgyeU542dtKcIc
3sv2nP5WPltHc0oRAynrjLeK0bKkgxZeWLMj6qW2WKkRA1/OvzPS3Df3Op658dNXr5yoB0lVpoSV
NaP07MO1DjNkV+bhIQHRvzPJkpN6d9NNhhwYUSDGEnVEBnPkIgDBQcUxUeJLng21buz9ig/Ysf1X
c5G3ajGQYJw8XXFUVGBEDuxQ3FtJH5c4GW3UInOOdLODOMJB9raI48UnFrD3cInqrjhh595YdPPX
m+JHXVCwVxxkHjTU8dQM85ybPbdyAsO1HglVeAjASs06SuWx/ynwklaSgMGF3LXvfsb+fTIvk9Oe
MpyMBKLz5kSw2by0+4GUJ4hUsNTqiPZUaxSdpuBxEiSbZB0wa6TCaq65Jhaha4hdxLWcOQxJdVJX
QE6JvotqjQ7WlMQ/yGAcX0+79L0xkLlRLjvBc5zT8Mgiu9MKX8AXyV2OiTWwMgjhubznILFMNDxe
R/rBn1XX+X0mOTVc1azpdspwptOH06aXH+hpuPdmcm1+SbZ9ilyvjJeJxWlXKKnyQ+mqqEX+LPcT
9WxsXZcvOOFa0UwqLkodGb9NAv7nxV/d3rmA6MjlJ5iLNY+zqFsU9Inbl+Qr0kt/TtQKrSfYCrDW
GWHzk6NPqupoFsNDM8Isol8A+LC8svebZ4rT61nzO0eJnzsNf9RzpiOL3pamFulqh6NmWVRx9Szj
DVwY0lQlC/S3stkQ4hU5NFbYhp2A0q5SxlPBHmhvq5ku4b85098+L6to/jVMO70kGangxW2WUf/m
TZ4qU4mlLSl8q3T6R5Paa9Y+SQkEE6DqpsxuBUipCJ6yQw7p7ANnEeB7Cc4NnDUKn004j+vAUxm=