<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsw2+dJzRTzx+35lLtVJzzi4ylNT/FPgPOouAkT8JRk4Uhmkn+MEi4uGt7ErX96r1GawOYCD
pqqYv3M9+zRUXToqo3AkouBGkBYd6ran0cuqskzbfB+9jCkuqMbNGmB1zQEjvEVKJ72nRFxXzU9/
syEe/XbLazSTFQW4NA6Oc4mKjg7EEIufitaHmpz5bjmTKOOdyiWZjdaq5q/Ld6i3lEh4SFkvcV0k
shpxOBUx62hDMC9g9/KVAfGwiJy3nPYOs3JCxhKcQJ7FrAUrfXHzWVZQ61DpWureiajuKbmsPeOo
k6P7/oV1Zb4SaDuQ4cqu27JPqnun86xubrcvyoexRI9ZbLuCPdAE+AssD2KqOugF9EBksiRA4/ll
u+HcP/vhl5BiT/LlKEMxhffwr8nkpz5uqaDdNxke1oqBRseUicl0wjXb+hjLqaXQLWu6uFaZ32HX
1vedGMVDz4geWgeZalxyqQjRBJiFaql8jpPGPWjnVtvcORl/B3ZQOqYlHGrAwqwd9O0icODOFoxB
kO/Yvw5/qWKHl0rIlLmifA7JNY1AD7dUHGOQG8iN8rT17+DlcjqZl1Uu1X/oVA3QArDk/ibjXRtQ
PSG6tySTrAVbf/Ojxw/hFMTCOUtV5j1KlkpDPmhuI3d/PjKctnU2FxCa+OxcR947dlaIl6deZ8e0
0bAm3grsdD4DfbMQ4QLDSRHD3ZGgjX7FO033hwbqC8+9EwGuO21m6CySxrRy08S6CMVmE/Uw426W
HH2MWyzgWxVobdYqAISC5HvUobOfnIq1fjvMkG0OP6eeVCa9FGG/j5LFZ6pbWmS1U47IrUaO60GT
KOUNo+xyVqrGS4jjISYSLV5VT62f2gH6TJIZvUt5qhM6i/cH850+rYmd9lfUj1L3HW2nuPlJIyas
9iDQMhjB3Ow+u8E4SgGNAyx7HzeuEj9RR94cHib2+HBCLf/zCwJjhdT5xp2r1HgB2Mm59XaVgWkn
tQKkNIP6w2RvxCO24b0Iz2YeKfV1purqj1Xedb6I5oWeqAqQ7PNGr3NBofrtDN2kYVVzawF971SW
Wcz3H3asN1ChGIeEk0aGgVEcs27v1VtH7Ss6DSnEAXXd9GhIkVgj5uneFoD9cKiw3VY4uTKJUMAs
zyPcA+goXaulidvsfzRNmwwi6Qa8FlOVTYOfUPhzV9YKyqn3nKJV8FnSRvJEbUqxAjEWUlMvO1ms
ECbTfKiuhv05ujLXUywxB7FODSIrH5vOHcg4aBFMQZFrZfkVRJlpU0unA0ydm5O370BgSjA9uwXu
m+gxiV5cjBrSKRcEY13tmYQIgltwj4DcYP8KzdW2r8thscX4Xye7WJO1kGN/mAc8HFyWmEdyjjLE
lDu8qyTehUQ+89tJh3R7E4GR/hrbQKu3HMzH8PNTcwwgwQTVxPnqEtoS3H3WTiEurSlvW3IT0iiM
3cGSZFZt0E8+k0QbOK1jevWC8e6LVtTEDshALB75ndgRnJCR8Ho80R7e6ycmeL8Jz8B1MhWBDjTC
/wfndlls2L6vV8S2ZBtFkQml2LRQfWLobtBJTaf8dUxcROYvNyEXvr0ZpQWd0M47ZpCRUYDp0ME1
qazVmPGQeW/kCbwkeiJ9264txs8fe8i4Nip/m0a6NNexzY3LG1EE0kwIKeM/9wEF42GKY/dEA2En
0zzcRbTE6hlh6/GEayHh4mVnv63why42aqS/zrfEiEDF0lPoTv2yLUdB5FL4peVqzVQ0NgkbSK4j
mb/2vM1QCt2UvR2a1Z16PmoCC6qa4iSMVygcgdRqRWMavdN/Lxui8JS+9UJcnlZkwVRgthDKR0r4
Y13J1jysBbGEl+lxMn8A2fqNPBCjNHNc34fsgAUbJgpBU5vW71SceL88DWPZu7pzOFxUKq9gBbWQ
TqWUVrTrsBQUx0abzjk8jO2N3MdBWzEg1FiKJPBEnwa9e04sVMQwa9GebDTvBB7vyua6DDNnwD5N
DrpuiBybYMaA3dxVwyaeqFR2Q4mFdK7d5sUuyUxMpXFkwGYi7hYnvuIk5L5Xay9uH7peSbj75cmG
QuKVZvtGZa1ibh7C+ERxv76WEjE/cpGSe0ypmuuHjTIPig/ovle8Ids2y09rv5dwMwbOCpZqTza7
dTfhc6TgH0gKEwhEzO5rP0uAzBr6gjg+dIzRfn3RBLKflxW+1Bw0YxA7T6wibl+cPTy4LmPrKITn
lwSqHCffLP0XWKgjTo0q+O90hsR1A1K=