<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzjXZH30uNKddQqOCnSDk0kfunW4O/OUjOMue6EeY7mb0hvgME+Vo06GuFM3zSK/CeeEBcq1
tTgS4tas6C0svVjU7VVfU29+h9HSuKG5TJ+Q2wfC33cXo62fSc0lbe9C6f8ViZOruvsW7zbl+wOT
gKdl2VDUCmcWqHJxixjywDR4O7+Jy0nAT2sNhPtHRDJhU/o59vBQ+H8ON6BxAEj0skyfKGm+gKve
q1cYHUHXgJRa/i/0c688YiIY3sb+SAsPFiioxhKcQJ7FrAUrfXHzWVZQ605fwFMMgt5dpZwuQ8QI
GCWL/wOPMm2kqGSB3O2snQbi5Awv4KlxDy9uQBVyS/7A6y1oR7byF+hZqH7cvMaFboAcu42HIk1w
jAIvnNfmtChvEC3d7YNqm54s907YZCvHUoamga89du2m2GX09vc9xP51XgeSTJISdHDYswl5oMZk
bk8Z6CkDH2Fo0ep1l8B9utTlyxGrcIZeVOx/GvoLrR+q+TxKjQTuULG4VWh6nWr7H+/DvJqAVnNh
ZtBDZ4gNPWp/4mLARfs5IDIdIAKmazmYQFy4bq7YLpBk7opV2sJZ8UqPvig4/+mz92wWC5iE1TWr
nKVbR2puvCgzKYF5t3lFqlXFqr8iZKnug515PIhxb3h/i/9AUNDsCrpQmvsNMX4RlKomzhlMtftM
YMSECG5JLmpGtsoQdjDMcMQ+4Hkj8REilsVEs1Sqrb2yG/JXbAgJtGnPCYwwmNsZpL9dOiN72Dsf
7AS2jiSJG8JoecZ2fJXzokl8101S+TXYvr9HfrstevTarZf4zVHwsdlAXWM/CW1F0pK1KlV41048
1LY2u5RlFbM0h/BiPkmzyB3ocuGAy9r4nRdRanc5bqkdQV3ZZ9qJ/62t8yo0qw05dfQup5n9SYRW
m3UvSISuaggbpC+yEI8vVCSnFt77AnWqeOfdXAqBTnjSqUKfo/kgV3vNQ3iPN+QuBqJFbFBuRZDQ
zwCtFWwU7dUHPWzaS4lMZdGW1PwoVSNA+2Ev+VQMkhJaePEnPP3kpHzsR0PH31e9pQxwBFNqE48l
KvQqORrbZJZyjRTWSoS+YOkkURx01k3X2RP+lbnC2NtA7tG2fVa8vb8bwYbniSwck5hgOD5NvN17
p3Zuc5QmSF1IOxateRkXAfIKw1PRM1nj+NjP1CNXYGHZ0TDDzf7Xm8+IZM+o3aJIbzQKfkJn6GLJ
7wlHD+A+74DTSpYcDvcgB1VRLIkChRRUWr+DUB/Y2xeqQ9uSGa5K2dDKFwVXXuKoaPq6JYhqulDZ
cf7wpbtZslrikf20m+qc+hx+0o5mPNBLtPYGkBZfJBaaGfkY9AbjDsyUEnwvQ4QMo8uUSPIHDwRM
tQ28CLzYb1x5lJlSdA2PmkwOZRaDsZ9Fgmj5mMZbNlyVQ8sdH0QD11370PCE0PnN4Jaazgi5Fg8F
/l4InDCuDikNtq4KVDUv4YeqK6/Bsyvoa8hy6c7RbbyQSfNnPFvobj6MqzeNs33CSHemcwbwKzIQ
P8iedEY17T5RtMj6lYtZz708xDWhE8Ea6CgQsFQGukpwgnHAgiNtTpqXjJ8bCs2QAq2Qoeatn35r
yNvqwect1G5g+w7WhLVYM73P+plU58Czvode7jsIwcIgQNASPzBzZvw8QRylXYx1bzFuGqtmP8Ir
Yugl7KRC+M/iaDLUvWN/oPrmt0ErIVjk4vvmGu3rZf1HxyCRM7JQmEvzlU6uVcmSKaItziYK48NK
HzHbsIUBERZ8Yu45ZpF8IbhJYC5JPC3R9S3MOYPyJHxsQ58NDhDIpiuANIIiBw0ONQI5J6wqsXKr
U/XGLAspTuQUG13dZK+hpNKa0UY6BFTqY10Dg+Yz+6MNCueYdn/xhUq7FiSufKJ0UgaaZWhmoSKU
/1bw/a1adRvdRhIIZhKkiHVIt+sQM8aKoHYfy6EM7nbi67q6UPzCIYSe9m3NYEe51qutt8fPrCix
qcjjrUQfZ8uZXuNYlekytmnSJCMsPt0DWhJy4Ji28Nd3j5TyWRgjU/fg8Nmk17gs722ODDHc/Xta
WrAejhBwqaRLicqbUMs9qeuz1Y+4rGvfmBLV21s5xQLELmBSldcOzem04y9lby7SSTK4yWOM491X
uVPMC/YvXWw26azLc8Knk4HNiB6Hq72pjIxICBevHbBkpYYWFuMxv1Pt5+YQPzBpo+HFZXheWJCu
WiMtdKViej+HPgV0H2ilSNcXahKdQGF6PNl12Xo2wlx6B8Y5JncF7ANQhbgY7kAAXIxt5EAJVjYf
JQNPxkqNu8qM35XdxCPfsn+aa3kr1JFhEQ1PLgrfTyzu3ArHkjiJKjPMyrwSjKOYx/WIIF/RxGuW
p/dIxJgD4qSv77oROsl2U4LqtHHMcY06xc3EJbk6JE5st32aQW9AfNmkSLI/gTnQMpqG02lSguxu
TPdaXbUrRr9L0EUAJbhtsZs1mrGXzior1PMo0590JZcMAjlVkOYUHGnVoOhZAnREUFwG8pW64IH4
4VqxUZ5OXrLAOfGl/M5QpGuEGKHNzYqkB2WgnX/QFiCd6xy6js4u69GY/asJ2zLr+6h6jIt59qJ+
h65AZHVTNAuEe+SrwJItKo4o86BwLGQmvl0FvBh2bCaV7nfc7EDvifG35s22ysm7UHObWrN0qVzG
Bhy9r6+FpbUh19tRfmf+pMy=