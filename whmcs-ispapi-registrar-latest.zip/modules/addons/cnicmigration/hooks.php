<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqB2mXA3XZSbMWjNCRYiLAQuDLnIN3tYBFuz66BVr5Kh5/b47NahgL5YQ6bMe5ZWmbzGvAKr
933E/2La/mQX/9M16RHfxBNa4LT06xAcVDIjLLkQpAoOMU4sDJU5JHa9yj9e1ZZGWgA5ULvpNVJN
PBbfmbsQfqssHW3k6YT1BW86NbaYjTLi8UuDRIR71HdjZKCMQApzPfx2hhJw45U/ksWkXLHJYI9Y
rNRDJxs4VJEy7hJHG7CLW3fSrQuVz2s8Aoqb2VVkjIPfCS/KfxMc57s1+DeOOcD/kLMGuYwPoYCD
XhAFvpWMPov82YQ9x8k7BfqZF+wzLDEPvWRAefY0UxNyaqnRbmpehaT419GnBf3fbYS7K4kW+qJE
foWoXVbs5n+ad4CSiHaGQkR6BgdNy4MaVr3vIXZ/e3ka5eG+MaZkaP4ZxVLBJRAdQoVYKM4dcnry
ciRhjmKDoytiRuOTTS2QgPTA0zuZP5Jw6LIE213CwbOMIHRYuChICpvhMvtx8HNP8TOrqel80Ee3
y4H6Wec8iDO4Q1yLYPI3fcgK/BzjyXnDL+7HvK7DplGMxzhiBqgfYyQJc+yuCd5QEdCadDKHhv9u
oCG/PCs1f33v8DNe5eSwFTiXY5mASBaL9zQnPqepNopz6T0XLa+qMhTYFJX6w438jdSevZTrxgkc
DZSC9lOwN40QpKOwvWesuk6RLtVgo9Y+CsPaeJPE576GPZANayIUoEfoVIGIWBWzUVlDwVWuBCbD
OeL1QzDjcCcoybNiI0Zj6eL5fPYU7HZobMTrCpXB2uZ81PgNUkgn0tqmuR76nJXI/PPGxDFk0juj
XDgxG2O5SDUGhxxLs4ZNJVMdH3hCTF+26qQW2Sq2pw39Eg5YmWMlO6oz/Z3pOqwkyN9ss1YQhGD7
Q57Tmp/cMfHJOg6/5FVhP7yc7d7ec9HiLTdt4+oxYySZ2+7a8HOl2Ktjf/O6m2ZRIBCvBsBqR8gn
EvXAUEQkF+Ug9YUwJgu+1ln7xprdtvxM2FYdZjg25rjLnVMUmKY4APUkDu18zR4t4eTMi2P2NJNK
YSmnjKmXWr2Ivndv0tMkmDXlMiLCgxNEGXgKiCrY6a0aEiaPMSfpaf8sSp1H3fVPJX2xwoifQ07s
6kSWI9tHJpPJyMrhYo6rn4+ayy+LeTXQdqDMPmq34LdiaSnIWeiqtGA2yjK+VlwS/tVr+VEPwTA9
4PU5Cz8Kr4bvg8J70KF5fEq+ZV2ar9goXYqJUW7+Bd+JIX8C2295wRk04CIFYCmHzGeST1z1cl+8
8aBJPW9f1wdgL3Mdn6tXgKhivDRM2Xokh81O/dNsS96d2dJXVAG8BfsCuMjh6Iy7fqs97Cpdre+Q
SL/NgPi54wATLe76DtGQv4sT3fRGEMHcBZbvwhcEGrxTQLlnXEJw1jhI/IB7v9oNRTE5QP0F0TIE
MGSdqpkwXo/UZlIo3tL/9nfM9V1fmuPe8hNV+e7YJLBMebSSzrrBh95gDPUbrS/e8CTe1L1eYDQQ
ROKcLjQA3UkTl7fjv6bHBc0wmXlLli5s+vE7he+6nxOj4OGHdYs8yjcEDRZ7kQ8aG6FNGCAD95S7
DvHhij8SgcAOGdLeW4N0OaAolptenK66xm52ylIehzUm9U5r1DIdNECTgL4u4bj5KvOAsVyvM6iB
pViCpcwRgprwCTn/u/qn+5bYi8A+YopPGXSApqJmvcqXAxJI3ETEJNK3LCc8Qi0DGOBtHbpxxpji
K2+et8t9lrNNfIWb0bo7QdU8J8nB9zeTqnFK7GdhjBOj5yjCOdt7g5ju0oBzJM40GRnyiTn9KrTi
9rdR/5qNYFk7fnpZZdncpFdoXGRT9ypVVJXWEAUWo8PpVOg01Q+j1iSQMWkpp9AXetcvo9fVoD6b
slRA/bTzPFmc/ZOD79I2AjyOWE5aTEsRBNwhPFs/DIZwsfpkNYfLLrlumZ60ppehUdWEXc9m3Qs/
JRJzAuLkD/btsx8KCVFy2ymBLT95ZDxjBGkTIH7jLg+DGGNe9MHJ0f44dGjI6FjBEVGX45ezl7VK
ES8wKxJQzCdPP8g74hjUssUonf69PpiVsnl99wE4OqT+LBD2zDdVd9NmpR5SfSl+s/ihZ8ulv6En
yhNGrI1AN4Xxk8RCee2FcqeWrtNbibEb9SEz/8RjchrmE3WtGhkjJHUQo/oeXWWnOS3nmcWpISiq
mqWSQIYltezxV/cqbNreIXiP8Iw4JWda+J9TQ+oFNPrca7nA4CIJCi6DBjPSDhW3YS52DGMABXbX
tOPJyJ5kuRM9kTlrzg+ZAYq0z+kdt7gq8H7Q3drQt0nwv2+NyM+EKpHXu/bNwgfbdkMLSpiiwrCY
OzKXvs60I7KJs36A/G4WNbLL4ngabk8KXYviyHFVLYCwTFXbPDcpjZ6HTObINrrbVrflPKs/cpTs
FGC7uveLYpk1JovuO48/hqtGbZbi0Jjml3f18UzG3gGEowS+vQZEKoHgN8UC4SpUDKaRTZdlanw+
e8WF3OGcTKg2VGpLEoryjo8vbGrQ7okrVcLCWXJPyD+NEt8FEvL4Z4JJ36I8z+kyFjTsS/brO4JQ
75KZQGJLNOCXotFzPAVxwf4eKIu2+I1NhQI60agwQa7q/DUdmZ4nDfbYrI9lvn6NMMZEe6diLTGO
ovQMPRcweOkMaMvoFbgrJQCVZoWYJj0OyKp1uexrUtTIe3aEiuYuCIxNhHTuTJT9K/7/hunaP52T
d+sX03HBPgkiSL3qaPTajx0G8LR9JZb3AbydMiY5Pr8Mzs4cmvSm9TU98ofisXh2Zlr/nBFjLMhk
eUUfQa1NHJAk/Z4tzWDiC4y77UMZyb9q4b1PvghO7oWn1ABcXHQ7/Lkqej6vqCZNG86VBAXYinZI
da+veBa1/5u3cr0GEHUpDKdtqcy1nSfSuEPS2AF9HFNvdmJka6M2sYuhDCAQQQM+iozmAdKf6kWv
xPUQWgYjBaq1C9NoL1rjDuUQGJAv1hE3ulPokl83UN0gpJUGkDhRcL6CdkaBWWjzwiM8PVuYUUgy
PPq+bc+O/atTXMZlRO8LibtFM9Nbc7pFgHB50jMDTcduBzYTFp1BxG7V8O0utB6OAgfb/+2vY4wN
XwmiIhkwzqvU8jxx0dfkCYzzmvtKsTPfbQQPXCQqq76GEq8hJpJpfX7NPkAb2AExn39OgFPGY+Ys
HYnCdPXYU+aX6YXkxPcPHmM1DUm6V9X/2M4hzQjuVkcG27PolW4oogWxpfbTIoXa+EBDG186Cm+D
Y/6MgPPAbWW9ayfU1k85IBgroU+VsusRZumcsFLNgmHmZBCZwGmCDo+ArRhNULvZGX5pAqartPOL
l223ivnDfLdFZtIoUSDWubr8lqvZGGOJbqtZYblkfWeYROyiUYVSfqBfu4f3d52IwACGBeU3/ZO8
MFvcsaJFdFvUOMtQusHCXHEhcEAzgmN0MEeUI0IDrnnIhQSY5aSte+yiEGQB6R97eWi1l+tT+Oo4
z03SVf8kkUzQ+kEB/iuluvwyhizeHpYLZSSTJzMNmB/V8oHtTy0gzyM2LOcdizoFSiqkwXsxxKFq
aq3yt2OhRLB1vf0zN9xTAOE8lMVKwwZdXKSHLOllVhx7lFzHH7c4gE0gPGWB1sbyKcrczdgco/cJ
bsW0ojZJbKhz5cgroJK0+9Acyt+57ILNRtkPwFieGRGYwGFFkKV79zvQUdVBXKi+5oVedJPpWyl+
hpFlgBCVFleaZSW/HpXKdbrg9Z7cZdfozudB1u0lqvbU/yz6Xb2QL+C6UGtj8vT84HJ9SnUwK8/Q
BXLMPBv+EwHNQ3Y0AqLi/Tm8J7V4dMQE/Ypf1guJfmqWc7H+UCXkOR0krYFZw+6cqhVAnUggkNtX
x0UQAhQij9HChJ0BDUPHfcuOfGXs+qlyOJ8h9AheFcPRCnRHo8dxGe4/YK4tR1NWC4B88YALKk/e
RbE62O7GMBPe6OaIVhh9vglQlN4vS9Wr9ZQBQKgrTdmbPa9f+r/6dedUR4QhUy3T8dV6tL9zk/Yw
dmnS82KtQC8Qsh9iouGENT+YiTZvGH2i2AlgR2NtEBVDvIU8R3WalbcFNcQSKqAjT1AIsUXFbbNP
Ty/FTrLzK7gnKNebLgGrzs+goJV5JanpTUbnvAJ+crLV4JXVNv74er5iKRNVQdirJcjvd/PH8KpS
klJF7IDehXgqhB7b7MdS7GftbPwSiRn62jI5FXBSWP6b8QF7Jd61oebt1OFJOmtZAsALtQKvwZLv
mBJkE1GLIdRxrSM4lxaUwf+AUevkJv3yLMZfkzuwHngOSqOZjWBNO9hKcChsgHi36LFzhVAh3EfQ
FqRof/i4xT13s/8gkfHLJfNSJ6tjLPVhZksUfs7XmhzrPggfYTGG8WDmBj8AjBu+yWsyWKVmV41/
FcjAbFM5oH0XbSEgUdGrs6cZ5wVb7uKS/0cWkOiAK4O=