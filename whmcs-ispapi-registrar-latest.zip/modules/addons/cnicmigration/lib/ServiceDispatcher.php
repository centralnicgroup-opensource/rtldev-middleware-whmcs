<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnp/VdPcaa5BIcjCuqKeh0LRQmTS4T91WUuq4AhltupEX8aKQN+3O71DX04lalcoW/y5O3Z2
+RWwysh2YtPwI4cXNq/AIpWtUO0RtaYII8M3TBKqK+ALJKNzw3vxFxfPP8rSoZCN2mMJsWkLGjMW
OpInzHh2uaObCzRmvBaXhBmqcI2hvNjOsIOtAnH5INPa25TGYRm+obZqWgPNfYTWyeha2F6vz2hm
9V2KW05ziN/QsxxWptfq1yniU1wRncK46gCxTEwr9canpzIdjQOKVO7usXYIPeCeao3oIhGbMkF6
uYGd1XnWKoobiP+OBMJWT3VPQdXMNp4jm/ps8dPGthOuXijbI58wILMr4QtCePHcYcjZLn/8IxL4
sge4lKCULVcAcxgruyaj2jW0q7faQVbIZnlJ0S7guyeJYq+0RGMPcjPJYiP+s6BEZqbuc8MyUH9F
EbqiUTTHflsiLz/Oj4MZ0MgPbXU66MoleeyfMqYkrFMbx9GR0TlTs8pEgjngGJ+HLfcljb/meCdt
HPUPE2CrL7QVlQjXFh5eXha1tciYz5Tz3fo07dxjV6qkS3XtjHObsvxAYIs6zXDHc/7R631hWJZi
6GcJKc1m4GwfKbwgpEXYq5TkyVKtpVLmnfJFX1Co2JyodH3N7FTlDxmX/uNImhfocgEZNrKk3kIu
nRCK3xbY7eLxWhCXxqBlLzOzn+LIviZrI6EDolWdw6Vd8L48HDUR5j8LX/IN2Fk0rQLNBNpK8xnF
iqH1eMtpAoWOFNi5KQgi3yORl+eBiNO34o0wpjfYY2FNvYCLKAXlOPZtuy7sS4iLdIHM8QFnT2kb
uxuzha13/VEGUHNvfi0PvrwBxFWwnuG/6t5QR9T+pQqi+u6m48joOLV8YME2VvnWsKPEOu0O/d/3
n1+YlbA1Hy7qOOob33xsCXW+SU6ZRbSoiTRd6J75zEWprOBSu30YjspIPHtGN3qvcG4RuETIgn/u
FX1kH+PHwEsUZgxdI4iBg0EHJm93z9BT+YYBSGawO7bFY+XQMIJfU58qI9x0o/w3aRNniSWhlqTN
WDcWRFo0zg0GI2qX9ofvJGT7oXbi4YpAf1VdKiNj+uaE5RZbwl+aiUV9n/LSWUlYydVISaL+RPkh
dsbqEh9pR6250iGkGmZQ8U8V/fl3t2BGwtpcaSaNJczej6+1XhqXAATeo6fVbW9F6TYKU13MMOFr
vWcb+CcyEVWjH9dHOnOJ1WoVW0Yo9A0Lw+pm7xHkE+dIhHYcf76SFQgUrbqpa/nF3vqMYDg3PAHy
EMaT07jp6YS73nZfV84Dkmq7l9cLzzK3Ht1PdcJSry/pmgGt6yahHfpriAsy5k89K5ovpPbBWG6F
0Vt2Q0MvLTggpVe6Bt7CoB1daw2125gmuuNttOpQ/pWw2Ea7jwk35znrsEv1dYMvuldIsbqZVR7L
Q69frstM3Y/7fPbM0Ixm2r1a7NUDe7jT+AXeI92J5ABw193DuUBkPilPVnsrvtGdjWTrP4IIix8p
NcEE1NwaXmri3+V5qYE8EghMysDKcJQlOVJsZjnR/YYVkeC9cmTT8qI2d8B4fhOCfNz5rHveFstH
DzlGJifXx2pyyOnmfiSZzn6YFQPY+kFdlZeNITWjAMOn5eUaa7iewohWWOvbwferKKnkV95i+2nS
9bAdl/TrsanF3zQFUGpi4GLkbEhvN30VflDNzCw/K8++185MgyIW2TBqbW2ygguhKwXWwKhVbM4Q
ypkgOslWNvGX+vy/SCyjt/HxCyWfsKBicnle+c7arrA59y/AJDjzzKzPduRaTH0JDDKCOEZZA4BI
q71yUWCgh5hArsolhoVSa0Tl1qUfezI89ODiaAy9jYfE6sLPPuoAU1syT+EP29xZSZvxmrE3a5x1
9JYX+UqRtUEDQjvFywH3egGtnpIVVNjOvfCJxUZTLw1WxbKUmMVtlJRniqNmgbof7Y4o69wvIl8M
bSSf+gpexGRJCGY6V2Nu2s8OEy6RdyyOrwFNDsWsoA1VpdsboFUCJz+BymmrYZCCrx4T3IZU01Zb
nIxVMazdMEt/Bq4AAP/cVxMdsF61pFzyg5fhOKnJlsUwWVV4dBXgHM7CGZ/zw3Z3L9ndhrw2j+nQ
kANo5TsoYG9y5StLGVQosElYnzrbUy0wyNpCg7uNvuxu970xDX91ivqtEgPbjLQOlu01GedSHkBx
3ACpaBEob82PnK+74FYGh7M6uAcA6sk5Wmg4e+ez8rdviXPeOc6NDathjUiegO0vSHuHSmH2SXqT
b8TOS4boQxsiFahGVNCsof/+IM8dxduov+Cnmqa7ePQnRWhDEDb7nfg+K6fSPKjgDzksLg+I4T3H
CRw837QH