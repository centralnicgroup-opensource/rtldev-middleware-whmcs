<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtQWpaVxZ3DeWX9RP3SzteTXKPAuOkmEu9cu7/B9qM9OJxat/8ZwnRZ+XE9raSfavJe87mge
+Mr7AqJeaf0jEA8xaEOqjE8Dp5I2wY60FdmszObBTiGPjn6GNZISevaQUwwvE7NcHLsFAks+0i+i
8uIfZrWL/cYQcT2BjEepbcilHIcHkOsoKUoBolzKG9Wb4B1dBGXisCVMRtOfATQGmHOGvEyMrISi
HqNE2Z9kW0nZSGrlWssChfGm67fYtB3Ym4gTxhKcQJ7FrAUrfXHzWVZQ6CjeOyWirMRTat2QOSRY
mkSe/mq5UtHHL7dT4NgWw4Zc+2o7fTF3k9/19xvepohXCQKXYhqmnZcBJGS4KUwoOMsIK1x3ZWgH
ZtUobaufQfhfYO5f4GD/eNd4wWB5x7g59ApfwSkQayUMRQPZLMJDbCNXHCKoQ1xyjDs/YxKsnlvc
umzT/nRgMemC3R4a9nLGy4n3OlrKd20ULArN9XiV9GbI1pjp1Lt1RTNHdCtw0SLaJ1OaM4Fq6aP/
6kEVBl1fGWFI1FFH3m38BdzH+OELZDvnoIQugyuUV215VuceJFS1ph+ehd8pZsi6m6xTnps/g9qe
2jopzsVbWDofLiK6UyBJC7PFqXSh+7KjOKdCtQBXsGg2jwdLjdNWChtVa3DYdilXALhM0e/OV3J3
Rqh08eQFIY4gkZ4jJLbeLte461QBulatstR/dYdZkA2/5W6ku3PrzJUn6lh8kXQIAEWFgwC375uq
ZIOTc+7toJlpdShsVaAkgIvF7I+c/BdjzNYO0MILS6tsdwHx2llBgFWu0pahC2pcFehXLtptQlub
g4d7fVCjR1DjIB5eJ/ZIlWA9KMCAmPcsSiFxzVZD1K1+7YVWUHE2nLJN4qBD677SRmfKZ5ysSFPL
CgXzyl+Xhv6Fu6WUzdSYuD5c1D05NYQpPCq5QtZHTwGiCZ3Yxyo6WuG30HgJP9ebXeQGQ3gmCTgr
CboNnlmJ4YKeXSQfdNn2v//JOSzQgZhizXFLfyGGcJhBs7E/GYqT8Uce16fkacaY9GIOyLSeltoh
OWsCXbq6Lz6v8wf9cDBjp/ECBmaIT0LaGc6DmlI2GKsp3W7WM9vdel1bROiTXh9LSNXqXyTRv5Zv
sKU/R/Wj44YIUN3Mi2lKfXFdmP5uii+4uYzoROBIjqut0QeWo1mRXrfJVcH+TkGQ5J14XP3wS+6/
SBnnrN8HW8O3ov/ocIgveuenQ5SxxIEXvW0c3J3CcWbejaKSub+QtZYHqybMyr6Rkz4YIzcQYz9q
WxgSNyTuDNh0bI0+ZuKhrLnoqRgFHBAEm9bBt8nOEQHApWSmBG7cpTnm6U+0xtimsdKokX+JEjui
xCwElUCrLmGv6FlGUm8dgfh06YqOrz4MCsbcGl8b5ggY2O+ftFu5N6iYOFXoeI+8vfPbt06xWbeb
PraBok1IX+UODvWmrMBYDSHFUMzdH7C6lsnwsRQJhuCQRcDBxrpw5w80TY+r3KsEw4vsDYpUiD2+
avD/sj7PJ6crb8aYyH+MHXMhafmxLvuwHo2sb6xMmDxd1Kzok5oDUgq41ZRfFqU5IIvLRC915brO
8s1d4UED8X9HYwvmAiJKTIYwAD74HMdR2h/V9aiBG2Ads2fZsvLy38PF60DEFvoz1+e7+QRBws9C
UTyF9MwCsQD/JmSoqWQX5eflrn+Hg7jhbigmrjPhVb8lzF9AGTD0Yjozvy0UmN1jCLxR5EQeLjAM
6KUyO+zOzxeBeTAy01ezy/ElEbtmB6dFgc/SIFqOnzVspr2St545Pw/gqVDZlOifIADP8ziwOIrJ
QUTXJQHyz0CH26dvqcFU8JAjTpYgZW==