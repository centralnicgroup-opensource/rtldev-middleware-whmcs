<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnRO47CEZEb4rnA5K2ML/jKCS7JmOBF/dVgH4tJERZynWz3MUHLb7KImLswXbCeNXAMKWcNt
J+gPmCaYEwEFYF1/pedU27nDEX6pwqraoM/XFUCPUoF/UY3YCQ7uLGxyPZ+NKc6Ht95cKvHXiOyq
6s1Itj0RBL7bPu3/pbxrrrC4VqbCjlpzbYeTvQu3z9nSO72PPCw0hQeoVma1a/4U3XK1KV5KWIh1
srRwaOacwRCDAeUy0EbpM8mkbIlkjUNhvrbn8kwr9canpzIdjQOKVO7usXZcQaW437kv5dQ8h1h6
yfp8AIO6ry6HW3J+VbcYZQBh+IEAHG3AxfN5wwzYSIzeow7IU/vmWymaRucuFIZpOg5UNh+ciRBC
gUKaqqckvT0py1Z5xk161GlZiod9FkVw5hQEYD2TdSSUhodlgjLlCNC//o4xqDpAPbSxQ0vb0ocu
tfVdcgGLCXUxawk8k2UIEgcLsV4z6JGV+dVmiOkp0G/a9loxoBNeZy4TTtZWswjiHOzY/BO8x6Rq
E/avST2lob9TZoqVbyJvS8jU/rZs0CLgeWEkvZdsdSAr8vb6Pp0ik8PoVQk0AKz8fpDY29ZT7MAs
37Q3lYQHEphW7+9XRtJKnPo3oZQOejp/EIHubD9yPczCo2gSWCS77qRlrBGg0ayOwmQ+5aEvRPqD
7KkyPNIQFpkhu/qdb8c7TIVVZ90LPu40CP9/gm8muj0AUrEMprqoOhwpAjYZWY2uce8u7DpHqPQJ
k4zTWRxQ30oPskC30pUXPN8p6PqtYOC2JKLO04oECMBdxVF9vRebLUB+H6c5X54oxWacfF14JVw8
lR0OFav/YqvcJgeYVV2BMvqxTcs7jFauKxHcjVrL13yaVfSZD4bV5PLmA1R5od2EIqLrpTWO3q5b
zEAq9OSsUltr7uXBJJVB35aDC/K8lsLejIm3OrD9JcxtThZQUKH8Mqq71q8uCLUBdaBvo+JdjBsa
f+4QCDJXY8hJ5daNg1KugvqfuLpzdhYf5qRgB5xI4CjXv0NYEZIqjBoO2f4WRutTNXhraMBmRqOE
3vm42PONyW9TE54UXsMLiKyqi+rvzAG84nB1t0/tCNVQrgYAj714STWENUM91tIKJfKby0DiCFQI
XD8rW9jQGQqIDzxAxe++40ZGGZi1qKgmp93MJ8ZK5wtm3FP/K0DbtZXqOP7F20NLxc69U7drbt0t
KHYr4/VWJ6inBjuZRTCZpNBv0I4MoYI5WX5SpsWLCaMF+oJViumXXClZQ0tvw9C+UJUnoXXiSbv7
IS0lnGZr9dnKWaHdIYSajniKSgYHllNetEZdT1/HrOwi55IMd/ybz+Mu8r+B2EQT2aLsJ6XPUe1R
wjTo3REZ9tT8YjNHT8ukQRkVnDZUtAWWIO0huqdA1mk7+hTsOtq1mNQleP5xDlO/etdAN4VzVTlZ
9no0bSPRVfPKlfkVCARHaJLUhV9FVNWrei+XDmydRJ0o9hcG4FUqC7ioP8pg2fPyUXFDooFvRTF0
NGiGiPh9BO1osiqwyKx/HVO7RZ9CVH+S7n8+ZNSxQ+Qh5wzNGFsEsov05w/TxAHl5dHb6TlM5h82
IVxxUiROOp9UlfF6YysVMHWiWD2QGNvY0DDFaYMAGslssoaaL3XcPAYUO/gs5LTI2VaCBjlSJ/cy
1YjV1ruU2WQqoWP6V332QyYcD7G94uhvqB8deZANtLN4f/nzYGJ8RSv4gfHHHRWCb08hqRUinN7e
zm+iIT8xt8nK4CCUD8oQ5HCzY+Zn77jT5O+CTaLWghKpQOcoLyQCcIi5LAROKHkRITK7lPgHRZSZ
3Rh2a26kGhuLG4Yzeyjz+zIGkU6W3N96hjhixbSY3Yq12jvv9FYT29If/e7v/KIMKYoTx9XoZsXd
emmqnHWIZg9l7D1TPcjxOZ60bOSHBLmtRh9kH9INmf4qbyzZq7kXoPArm4Hv3KA+dthmJk7zYYF9
gufY/5UF8jcXiU1+c5X8JMuel9+5zW+GEUfFcHMVuaW8mgt5q2yJ2M4IYg0AdfrYoKgwSyFgm/fy
/rwzBNNGsT2GNLzxSIYwMSChfFJMQPEzBZXT0YWk8gy8pOpLPhbQXQoYOtPYiLErdK5Ig1+p3/bo
DlpIKiP8cbvsyncSO1nDai2XE0ibXnsHheS45RO36nGThTx+k7VsBW6NbfbgnaA4KFfjw5X8Gxk9
WumFt/5fD46znrtqyX3rlFToiBWthhf2fRVKofs/U8gYSWF5e8Gs6zYMYntRjOnMPIU3A+Z0OLxj
wB17RD9K2vEOYOxQ2+HIW122lAWxdbOIEqvaafRnAjfPBuk4gMm8+ejtxRqZXRH+udgMtlDe2rlv
kc3cFX89tB56Eqn5msv6oXiltrnE+mfm2UyzabCl1P913vRCAdWLG0UanqEJlWdRZJCe53SEvLBW
uo7ZT6rTESIx0hX1LepjWYiUaKiqVXMoFIwQ4m1aqM/BItUjX0rqtJiJk7poSVyiGUbyL/e6WxUE
s7d6lKxF1eSnG+wLRCEVM5OlTpxUqQapuP4e40wCfhrCQqQKQ89Xc6s1vk2Amsg617QwGJqEKdo8
y2SSxcdIqWgVl44Kp/qHYrpdFMhVFSeFvNc5IUetmjVu4gP+lirVbFnujmYOUylDPcywOpZfGDvL
O3tiXDW1sQaKQPHd/jTdYoP0E+63ete+ybhDEeJubycEkJh1kqPMtJN/MS2PaQbAHSH10b6IyURT
Qp6eNx63rXv1nWal/r0E86vuoEd5sbhf0j8jwSAmfr3MWrA/+pHHin73ozKgqLk0sft8Hmb/06qb
QXIzc2kMaPuoHDFHMLAtY0CwAZklQI3lHilF2yOVpT/xMZzhgpTo7bUif1KSgL44eFKbEr2vJPDI
yd2PU4QHewNk63NbTDZ/lRSGaGCm5Ha+Ej2HR6luZrkbjOsa3aWV8bCLBnpobEpCEyExyyWBFfOV
JI3DugQOQ7uCm3ts2y34uOF8f9kMoM1+WFHLZVkomBQVh8NQxKiehuAo8ki4bmweS/ytw8Fwyz0R
kBEoJmBEg0VLBCGtCfdOoEMzfThbRhBzUnahh1Vj+a6DN2u15fCK928Jt1dpwRGNGxOVci462+zd
W9a8A89jKoqo0Bj5DSXK0brMlRYY9CKUPj0Qapdw33irTMaXsZR8zp4wepEPXfhZjatl/wYJ9JfO
24M3FnxFM14kM9RXKz7sQcK0c1l1x8rh8cqv6PRiftlXNIKCmzZYCqGkS2o/ino+WTDlR2DryqHS
Chhv/B5+wwJfR2Y2lcT2H49IN8hL4uGE8/L5xYt+6PfC7LHQUfhlCa2Aaxrmh9Qmi/MEVoyuXfWc
2W+pAF81sVK4WQed08cAryy5dye4xA8o01/V0r9SbtIPUrIfulTV3XxImDg2WGramFZRL647Yk2e
z4gC30MTWIWFy/lJ8IAWorwMWnTtMhhSHd3IXRrYXQGvmptXxlQCg0WdvJGpHpHTiR+x2D1NqWFz
62GlnXzdr3Jq7lzn1NyLxci62cgt7Tp+8w6e7KSRVQnAb6luirxiKBJjb4edWpRAYkNaf0BGkCeS
1mkPQWf/2tKsghO0S2QGXC7QFSG5loZpXiG47qf8hv9Lrp2KqffdKUEH1WzcAGxusDCa2sR3BBVH
KK+427Pkb91dmpVg9RaoKXjLraNzoDV2XcBUugVzVzxwIGR0QpB1xUXiZjr38wXLTTU9nOL/XAl8
aFez3ScVZ3sy+MC89JCv91oAnGmEMuLEqR5+27OI+1P2qOjN4GdvPtX3clcIXPW4xR/QATtHNaKW
Y51X/rt1VaA4k7AmPX+kKo272nu15MikVbpNPDIL5t0nhklY/8z7Daa4syuqKDLnojDfyp7d2nG/
pBTYl1oh+6zVm/p6Hg1bXgFJ1SBdzOQJTK6mnZHyyWnLf1lRqqkGT9mgibyEXswsxb8shNm9NSCa
KB/oIF3B8Tt5BJDdENLOTIhDRwmlqr9aUC2R0wzEcUqIwOsI6CPUwEpN3xaPi1EgHFHds918pwZs
WqCzMjQ3WxD76AL/4PcTBKQms5kIO608AXi22n/T/pOqMkeD3rz8kWxYU9YjS+wN9fc4n7krF+xN
Xe4uWijZQ45HZ6XXNqd91NzPhqOun9RLCAkFejd9xZPOqQJVsND17PZSVvkwPtOujWgjZ9tYR5aT
Xj5Q2grqgo7wn31/Svhhs8HSKX4sEQaKkZdw1E/ZOynncrmeMdToDkCmYNVORVsW8HeKFVyceLrf
sUpSLSfD0vPfCwOfp+DBXyitER86zQDWcA8w7LeirsKPiwqjPmnaxW6oKGpHV6HIeiIe4nT2mcKP
nO9J6bA2ZA1p6WvKNa+bHMw9QSHEMxLKBBxCWhtECxqdbutUDm7Jg/7bx55z7oKFsAXIEr9J0ykx
0hOuSNtFKjuTIcbhAtq5r82FhNx+5YhdvmwTS2dAt7fA6EFKzSVzSeQtzMzUxmFpNPaojfP1sgSW
6gf5q3W003Cd1XNLyX4x+SRpUmfBUKx6TnQ8eDsHMpunnCkx106Ncvzr379zLM48JHpPjqqujJea
fvEnvHRDZ0==