<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxWYEdWd3Pz/Ff6lMy6ugRNOO9YTu/yBC/KGHyqdPX2nFTjIe/AayYzxjhgdCNXq/EmoWJwX
1L2rjcOj/ZQEqcY+vjy8ZKCwDb/LUI4nj4K3lj6xH9Bm0RLIGKR6XYUiCy1AzPvDAr5Ib5Z0Sd0f
49o1c4PKV+BPgs8scpqnEK4GsRXfFPH9H/pmDHtMHVakoHc4XyO9fYShO1sQebFNelYqkuuZB4KN
sCj2wk+ZN4ggPyz4v2c/3f4obFJiA93hJSR431E/Fv8iraLu1HfDnDdWi+l3Py3T2udZEf78ABR8
8dw60ir0ufEvFdJh2oP1nrFD04dfQllfZiCiD+eErwYKRA8vES8I5V43KdjeWTVU12KAkMVIkKWt
8qmunhhdo8hlvrb2qyg6+f8dyNI7TB7i1Oa1zPsRFZTs73vPXLVxHAaSo1CUfZCqRPzqVyALShzT
Dx34gM4Q2UcTn7JGptwnP9JQ8e7P2INpH160W/wqQWV7ud9n7yICOcVMdFyTmJsC64/bvZkz1yya
8UEchHI/h9yBWHRzB7YC/0TDvr2wfA6UiLSR8qCqcYqwEp2/CY++Wd1lCRRgZWrilAJv0nmUmFNC
chiu3NKWdr/MrRSvTpcvCo3vRyxtDX53nGoLPFxu5BYeVQu7sKuG+Ji7wDagJHywlXiikMRkqlSM
mINqHbeb6AkohQMw2BJ3lYRD2pIYArnUNWCn/a3u7ND+BmR6Xds4TjWRl4BRPOcX+KD+y41uUcpF
nYtmOsbMM0ZfFQhqgwJyAGx4QlkbLTPi3GAWFyuEs7j9eDxLuHghtNXs7lPbdEKNtiI6V5alrEvl
ZxutKGM+cx0TT+2hlFNro7i5WdT/r5/dayvV1X69nKFZBcOej6cEG7BnU/3+wgfnnIjD0pzeN/+8
xYq7GqGAuI7PX28piLe5aUwk3FTRLfmtV/k7no85SXu1mhQ2oMOCV8qUKNEyILREXFlpXYGz4gvC
fTqKv8TaiW4bKtmXYgFBGIA5gVgN/gr6JCfnyzrSY8fv/4NIWfESoVkC9X66uGqVyDq72za55IwC
TFKQWFJgXdtT65swlXwfcWRQLTAcNQbAJZxLYRh8CPpCjrFwY4sc7iImWkaeZrZ6OHaXB8pc2vUW
7IANvNeM1Tgtmd6WymxruAtYRsgI2IWeveCdVLi0SuMDJbxlYu82GGFaO5Y1ncPr2J6SM83eT1VC
q1lYAv5Pnagob++2EsnM1PoWAy5NswY/AeU4iQHMd9alkEgo1T+52gfFUU0/p15sTg1XUO8OK5tJ
Skv7xYlB1onPcgTPHqTJaKYn201NDj8f7dmz5VWERc+tCjxzQt19FeWVh5FZ2vHu/3kP81/GG+7D
zFnsm/oMrEf7zkg+fwr0Ey9K3kWdOMXCRSXOWCWft+TJ0YH99ab8Z5DgSFNs25uffh92Pv3Ie11j
WdizAh3aPNWR1JKnoAtPAFzsFYAoLPQANuMF2VQ2f+2ipHWpbdO2W8Ltl3ivGcnlOwdNYYv9Fqrm
nnrGULDYfHuWaJIfo7dcQmiQYOk355rgJeADhhVAwbJ65bNzdSXuKn9sLmfkwM5K08RPjpZkI3Kp
wkplPtVJ4OJV3f7TnQ+Hiz/PR2JrdzIuhBEb3nlxja9RYjYCH4fhj+rOFxjir/1t0wE+nXOxeedb
LmiohYkFRecBYTJzv6ktsoCsFZkAf/JRYqjf+1Z2L3TwBkDBwI+X5W9dKY7zBIA3UjsvnClB+mR6
hRpPLi94twQH9cgU11xLl2/kBBpzWeUr4WvbsB7LM261cypMSsG7CwGJuoK/4UTwRLRND0PgtgAR
GPwjIB1SkzMBcvlYfHYUkkJBbBNkwyngwA/0NSuwuh35KOJWbbpF5bbkEIS2PwTBSVUqZxt1a0TZ
bxOPtdjhzVum+an7vIxMD7XoX3Q7Z7eLCl7B5qcp2tPkPWhqJEHlMY8rlyrPkjZKvIfJh+kiDLVY
6gkgQIIm9rZ7IHZXzIZnmekwpSIxSJ0Jm8RXwpMCLJI8DtGSYqNawjkV6jGqfuG5YU8Z1cCCQBc0
woiUdHbQW3wLQrCHOXo9YW0pDXyl+5sXIfkbhFVPYwAdY/yqRr46z8ik0XAM72KKCnb5E+SicQXt
HC2qQHsjz00EXMpdQiKro+ad8neZRmZ1UUHRmkm3VJUOSwvXPVQNOftftERah+m5wTEBFaQbYWmL
idmmNiUXiLqG095OGIrmUEyLXvGuio8GGiq8+o1tNpZH8gijpTrg