<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPurnAFyhMTMGy2IvlTp4k2uGd1EXx7ZKmvcuQ+4YrOdlUi3AXqL7S0UjYN00/jBrwSBqmvNv
fnEPCcgkjmusXnIh2/4RgI8VIY6UEPrZZq9Hew1mSMCDIpMwuiy2usSzt6AX82bjSvCAvOdibean
XdaCRc9FFHom/FVaqDYSqjxkcoK259o3VFwsheMNZLgNCAo2SPJNXf7e1n94OVSmEbnZlK5DKA2a
rjnFaDCjSrNDX/POfkrmonKjASQgtNG1jfF2xhKcQJ7FrAUrfXHzWVZQ66rjz31C2HDMjrmciyR2
WQXYj1shVFUzJ/meh3VYbZ91I9HdS7h770lrr1VAY32YSqw1XrFehJLYW65EaY76kVaejJ6SfhxL
0VuRu8DTDBqgXhHdZdByq2jItzFy4ScY4gqCRcSOzdmaD+qhX3Q9250OrH1MFNSM2+ni2lFFEJKU
NStdItv2BY4r4LeaEdXdfkjIB0Ncpya1dJHIGoZgfe7mjJKPbrpeJMtScZyUJoprv5oPVdr7zVfs
ft0gQwN5+bc4dXVRS8Bo6qeSSwup1QujzNwFaZwlzNIqytAcMc81OTU+qboOPvBzBemADK4Zr9zL
vJwmHimf0z/LLEk96DSFepaMrwLmaJ52v46JdlMR1skOKahD/fC77qk8G1U0ekz7MdRL6Qx2ubmL
+FyZEJNSlLkMT0V4mqe5K2P/HwKYobgV/PeWSAQwW/C4hlNacthgtgciOcsHfyLyGulYuwfrVot0
014+Kb79q+YRZaAptJsYcYeAv1uUbw0aBWM5kTvjTJf4KChO+wqYOTOsXB0EXQcM5UxJbm8qVdce
96aKhMLsrGtndzhUmILMG4QnJulem+zgfRYaEthEDQF98iPB0QJCqKfQEsk48b/gev4X+0jX39iS
3NPrryrqDApgrv31JefiHJ5JyeYIotLqPRuDZ6x1pLNg8X4hH7AAMgahV4ynAkncNUACZtV/RQ6I
iOKIMsEeDnuN2l/zo9+eWGc/evy126ZlaNkjmG+uw5ShbwcMNXXNT0M/kD/er5dsH9S1GIjYuVbO
IfrpM1b0Ltli8l9iECPPllp77fAyfSHroaN26ZsXO1QPy/XxqgQTxEOvUOulyu20Rg8phrYP7pY2
98CWWVPIMtRZ5zll84Iz7W2vWekJ+J4nSaevSjTMniFy0uZA+axJYujVUy/BuI7SoEX0QzBExGhJ
TKDTPsJ1fWSTZC7rJGGYyz6n0jmLiCuJ6xNQRSKUBVmZJg1CP/5QkIZRUhNawHilGwnoR319TRwF
Nbqha5vaddPuZXSpO78nrltxL2iZXNlnokoKv+JnTmps+xMSG5SUD2gM164Ctq1f7fVq7XbR9n/J
KsFXGOCwB/T1fDDJO05lnqZd0OpfkS/blleaWXWBCRSdINAUyGZAsj9L+NVZbrTCtpr/4+a1OFGZ
EnE0ImcpEbe+H03L5nkHfE7OKybbsHKjkRrUC6ksdKh00dc02kC9Qxqxx2yCz6EG7PUZNKhyj434
qFZy09rOOtoXYG2ErUK360FM/O5cm+e93V9V8+R65KG8mtL4hVo6HQdPclqz+VpO35ZthfCMta14
/XZT1NgBzjDzkFPr0LSJaCHN9OjuvZDiO4AyxmxhEdiNu9VIzRtBeq+q3lue1t13yyVGvJRFAleo
3xE+NTM9lb+3G6HdpqB/202gRf9k6cgXaITIlSe7V0jg9N/C24I1bg8ObkoKxRf9LFQguUu09572
XVXI73SEVHCJFvOFvWsBORAs0dQ5Wf68tIlT9eEj5g/zevu0zvxFHYx2gyl7c2x1BCfIYf1chu/+
6a1H6CrVfxvMGS/TcU0fVsZxPcOoAhq5dIRegFp3PoZAFhnRGimr3/K+K7VUI7FjWnKMWrB554C6
Euk6ZtmzNN6UczTD9JjBvQ34+0lhwtff8mfv73Ds4weQMjOPCOx1w+F1npyqGuGCGKSZ9oapJvac
JkWp0uJJgIm/jMocZdD2pm8HcRlqNW6uf1nvi9l35gC89jDAKgHja28vUQA51kpHdMbrpnaCxkad
Cjk/LT0U6xDQ7dl1G/8KEvSKnlw4HAhe05j7CkJEkhKMi04snPRocFRW1J8bsBaBOELUpFWTbj/s
1z+cO9e2/hNQuOfmqG5P4/kiyWwCM9cEOqlcVdx8fn+zM9g2JEDGMRAQY2ZAojCh5gsPFLJ2sBow
+WprUy/0NqHWa0zGPlEe9FwvFm9qg9XheJwxvy50aF3w7BsPt6PSnOu9hYAVxaz7dlgeNj7y52+d
sqpb2an/W5WGcVGk+3DTngr9D2NT6lPiFjppBOiBkI0dgLTyMXnynAqG3reWWWJdHzX8aEXTmlus
gIDXRgaK0h1ciggS+zBqBF1P/sOGeyFz/QyJBZMdUYIO3DdYqdboqWMlmUDf0TW/8MH5Uma3wSHx
OXcHodOveDd8/fTMG0h9S/0T1DlVn+QlSt4/H44C43kp4FX2MrhYOesSZDqvnUlHjtguldOhaKGo
HIqKZmA/F+VW+qeC3UUbCUK22B4j4w93YmdUpgfLfHxkfxy1JHokRFN5OsJD/x2xGRHvpLNdAWis
VqMWFX10r3tQbDbEXyDJ1FEshf4r82nB1ua67pwZrD7nn2cecpCzuOBF0e5e/mpvYJ53ZC4rJJbu
Kv5IJFT6v8A3e6J6dYORVfEnAO1+WT5RoShVjG7lCk1tvoWtBgzDMvOFOrY4QNp/T81GSNKlUF3+
FhxpJD65XRUDy7B8pcn44C0oMAiz70yc+pk94Jyr/QaFZeejwHObVH5F/9i31dy3tqK1M5r6juwg
bHkEr8RmkuNynXPQYM0p0ml4S9ZDVPMGiYgYTJK4TQwKc517SKT95SCu+HFeWOt0WnS01Dc51kCT
0iidtLqKvl5hrBh0Ltfgw1Oltwr71Z9oYiA7e5wTtPYZVOEifmXqq0e2+E3xk+e2Kek+wEUburtT
5mFm1nWYdAkhq51zYq17orqbnLHTOGFN4NLdAPKZU76Q6D6+p66G4ZZqW6MVxKb1X0/Nk43FYznb
cJa3S99yUBAiDuRKK1vrCZXaMB9WiuOgp4FKuQgahYV3fmbMBTqDI6ah5omZ362Dk5aTjmVlqGbg
dzEB659JYa3pgwSm/B6PvYcH11/fdpvswqf/YcwG4w/RebBaLciEjXX9Ee2a/vM0hAWLfpQj8DYU
ELe0U9Utr/SHcotat96RXeM8mBa3DDZcLyqqUwY3xwh0X5CMS1ZwgQONdvVmHeMFPjf9dRwMb5Pm
Pjdrf82qf3GTS06xWyYQp+klxs6L5vYjqDqgc9i3J45q86pfy6WMJ/ERpYphbLXzxEHimoBNh5s5
UJWwzevbu4itIhkc5aOVBtBY+rKqb1S3K3CLtqBstNVI+o4GiyXtHGi3Ip9qlyypfJTDPQseo8MW
aUUWgqrNH3DHouNxDiVuYsTfEiAM5vps11Z7fbrJNWvaJl+ZRvZc/xyat9ZQCay0hjO+00JJyX0J
rM6an/XkKaHTnWstRBKmXntD1XJEmwgO295m54AzhvQ4vMtN9vrjZRuVcTtjWBiI5/ybGZ6IVBqV
wED7raEQ2nRgl2LvKsEAuPvI5yc8VnfxIzALZwzp6TSzsNNUHTOYs2LrnAmdO+jYYLx4cK9WU7Vl
tW2PbcspaILaGWGC+JyN34/uidScKELA3Ba0nod7SzvF5fm1YBHWLC/wyjaCntIjuoOBlv2m/gJa
UUBYTSGV5xZjwPIJ/gRWOStS0bX9LzQbeGY1ST1lrKswHld5fo+aV8+LLaq5zyIuR09+GSinWVyK
vKIt3h+j+RdlVnNw4RlYDKRHQG7lLtPNrG/GQpF+brnQ2A7GxRivli8kzooOFcPymAtjaDO1RzTb
rh61xmab19aNNjCOd4PSmZO4zJ9l6gwZPD6EnuWtUHOhGdOkEEByCKiMY2vRBQrc8LO2ghoMHoab
+dyk2V9UkIlv5XpnPtzzc2rBiUNYo6QXffZzc14vTgsMuwBPLDkj