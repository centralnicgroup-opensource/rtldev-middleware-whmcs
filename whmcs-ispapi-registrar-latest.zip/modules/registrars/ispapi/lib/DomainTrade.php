<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrLxZmcYx7Ckkx8QAknXkXOblnH/T+y4V/a9QeKHu0KS87I1xs38KPtTPhOZYIEdqINqfM9B
XaUAULeIoX4BbTH1LEkSLjAYf+g6W/gY4MlTEof5Yu+LL01nHCEmK+GDkInXGaNmbW12wSZdYZ8i
PormLqGsOHH5FQFUfpLslNJLipGkwzgzJUQZfHLqQpALAXPWmBkfiLJ1prSpdeEZA5vG0HwsFUXw
tB//jRwrRMRsTw+ul9eflnSs6K9ZaV2m84YqIEiJlp+IBDP5U0KQJSJPuBFhIcRVcUy3HrNfNOQC
YC8C1oe3S9sbYdXi9bSNHKMh7UBt48qn/HHIG1hhjQNSOu8hgpDVCatMkV7ttHXIHYSTZCqsrBsb
xrM9e52nBSmanIJ2MgdEOWjxdV1u9uritsnIn+KmaUEVU+Y/E7GWpL06xqklafiKoMdIo21CGTMy
hDiM9QEX+0JL0dJOnKJ3l+pPr9AKwfn6ZFo2mFFm9m1hBMhS6ttjWKRPPWZpqyDlcMWKl/4beTgc
TyI6OqvtDiz4WhIDaReLGh34PK2WpUHsYSQylveABJa23weHavrstaB3WC/Fc04/EiCgATDtiW6+
JfrYYVfjwYR1I0H8h0rJcMUYiW85mrwx7EfZosDng7es3gVnjcRYRKRLwMpeW7G0LRceGkzWSEGB
9yAgU0yY6H6AdX9wzZ0A9ZUAcg/TpRpKqIeL2pECNSJ/IsD44wYlD2BgG2rLAZSYOUXytRS1ZVnh
k3T9HIhioYAmfMAKyGAHei0VcIDuyX+8lu+21FksRYSJ2sOoMiDIn8hd+26lvG5YAMOPQb696ZS/
MNv4mZv9/+lte6lM4rePFSZQtu0B7vEWY9y/Q+ZgW58gDBni9oAGZQ+JdCaEcXsGc9/3rT5LacQr
CodVysbGebS4aS0OjfJKetlnPDtTuolfsNu2NbDFx1nxti+HU88Bat8oOuK8+w3MSN3HGFActKPx
x4MM+wdvdHFkGFdk93DsUHlyIOBqTZDCjRq92vBQ63rNpxwPTo8CHGTwR4TC51TOR5WW0yi5JzsE
fJjWbxVK+l3zqrfRFYYXaWcHjT7HY67pGmfGtj9KjFlULL2fFmC9aQob9NjKm17YuwJUMFHYxOQL
l2zqVWv6p8uv6KSo/Z3B/pEtK39iu1MMyZHMPtQYY9oiVEkdev/0EkAIvFeb/2WLKr6ZVEhRwddw
5S0VOG0TuXyRuoASSXUNMYR2oMxl73dA2L2I7nXvuLGS3vKMK1aG1KGM1/iHIHtQaepxJHXVzd2K
s5ufss3/ty5T2bKkBRVcnBRH4IDS2IzxgnvGCQL2VK7jZ9XVm6xAWs3dPLYUt4K43YCD1sio6uuo
5FMqscOjk3yn/lu1KaWabj0dg5wIxzhG+wiq0PcKyI2h6xSc1R78P9tppV73VyABDmKG0Ihdya2V
dfcfd40KlOGmDuLZH7OilC0C9Roq+9SZLTmjhHbMzQrXWt0sNU1zvKifU3t/1/F/wGmTUmz9qmY7
Lb62LL6fSTStZPPRHp4jac10E+zdQs5jbKtjbdGptu2Be9q+4r8KtpUZAQ8bKV4wjE/Az5BmD+Ja
ixA27wTW6czxrBVxYvz5NR+/X6rzH6P7okb27zYLV4LxmtH+ikoyZEUB+WVt8XpU3qT6O+h4v8zD
2xEcW1wrQhqUYqQhAFp8gXVqdGhkxAEEFZ5GGSsihn42VV9W6hHl9L+AJ04h2ixxLLoOLKEK/Dm7
uGk5KC/G06Mx1FplzC52ruwVzWiLzIHcUXx6s6/K5p4zWo+T2SyNf3sqiK5iG9kIk5HSGvtAZzfb
zjlgIF+/X7EhuMbaid3Z0jUNvMCZ9P0c/Sm1f5A9Fad3B1vCrt8EiesIiw6am0SdQy8R74TDQaLE
YGThsG3TjrIQz1C0YaMMt26WW7+rDkJcfj3E5N0BZxjTr381+TG+xD52gUPgfoMVu+zyygv1g/BT
W+K4ZP+ZUuI1uWC6lixjccl+l0t+P6M5jRi8FoSFMKIP1xau3lemtyOKouaDN26zbvtnJWpDBtL1
7CvN9f0Rxga/5NIp3joJRGwLWL9eAtIEoBHa7doAmPzI8oo8VAabldds6laZoSVDmEL8n09LJWJ3
3Sg0Zgxg5M3Z3i5IRC/k7slcjC+JneCxKRnEZrMzkjMPfuzcxCUFn/rJ/0PQ9vniVBiwECvx2MfK
0QgNAYSNgf4JFJganhOD8vEBUGhzk1Rtw9U1vt9fXNTKyA/loj/19AQ53SSnko+2fZMTdxTU5Yw7
rkTLCn7El2IZiHEhJ9aUnQqdW+0VBhxF/cJ+2TTbWLs+h+j5t2c80FmHk2QPIaA0Sg62EqBis591
OpwOL0ySJ9w8Ken1LHpsB8ohXqdjhBCB08Kuj+OkJL9MjbuPHWO0XLuliJhxBM+Z5ISZ9qvKL+TB
Nd1PeeR3+Rx5s6I3ssF4gWv74Y9EJ5tHLsvBPmDXa3Q4KDqMaxdQ1r1unR8ZyViztddXhbSaIRlt
WjJakOaauaMVQAxcY0xCXYVNQ9Np+ZDF3I8tfPDqexUQ/XRfBCMp4sTUpFRBqrx2UmdON11QLhPj
mAaJi+wtuZPWpzh+E+h8Rs2QOkRtlKkosNQmNcCIhUIro6fw0B26NLsJMKo0066CU0a+d4539GS2
ZEFuLN2CxNlscbaO9wnlDuvvsJGgeAu7sCs5aLgdKxWivc3vP7Wlv241an2xSgvBSSjs0AdoiG04
SbAmhwVY+T5/7pkQ4t832vzzEHhUtStYQswrfbXbyIYA7pEjVtQ/7oXiFkuUu9cJMEJhTN1XbXKw
PHOqMeywlruMW/hWUB1CqpbwyZvMJ4CZim1wPkByc2EoHA2Kd3yt/MncGt/WVSEdRMOvX2/z8KtB
22Y25FmziD6OPoK0PiXg2QRNbQG9R4BGe5rGd1FlmMSwZxiZoHpWCZPqZpY2yY3lmPSQulRIvgCY
etFajQ+n4IXJOEOP442mq9s4PQCltnDyR+AFr+Gctz2jqN74/82/l6VbZIxVJV3w3LYiKlxPlDYc
EPCFSlMoXf5Ink02D2IvH2G0WC1o6BNfqtk0aekhM5p6omKkLS4YiPFDTz9zKkbbvaHw/vp+8Rf7
xalIPfRMKL3LHgyBuLA0JD6oMVLJPtGT5m1zjqdXPrHc/jqhO7e+trmO+b6F6v5Bi+INYMhudb99
UKPVpfoRLjA5gEcUkLTVXFpihRMAkEP1Q2AagXy4at0f5ANGaCQwi7aMzHIvMm2+7uIFWR13OgzV
8TbgJqhwxxZyk87Ejct4UMspNxZIiUMQBFpo8g31o7z0TUMsMwI5WoyFel8ea3CS14oF/MSAZ6uR
S4QQzLWS0l8urtJVfvejNAToAEH+cm/px0IKLUN5AHVEgFwuP3NWYa91+RFiyE3bcnwJ0quCyYng
qvi2PmvgWkyu09evBTrEae4hir7AsMfrDzy67CrnPcuDjw6+Sa7anb+ASDEE0yLsQuswRUUJBoF6
avuO/jKoT8m9/7bUMH+/hXTV8ODvVqE6nkN9tZ0zQu5QBBpuuRidbY/Yt/7q87cilhi6PS6uE9DW
KAf7ciK8pZ7xKrpUNdFm90b6rpy1n0M9ejvrYYbaYPnCxby8NwUsCWfUgzLtW1Fgr6lA1CrKxgkL
oCIv3kzUhaU0r8PZXXsvlDuPm/bFhADMlNJ8mUGNvM+qDdrn1vxA+07nIyzo1P9hYH5lcbvAq8je
bnbFR8IEvUMZg6MblcrdJoZATdULjiZRxjgdlr4XMqoIp0AJlupAGvG0psruEoQ5jiaGCLOUJcgB
7SIXj30lX5nece6wht5CgkaUQUQLG5pH5bZWA0D4qz1QMDBoHnvUJpxwfNg3d6hJXU1QK+SHeLwk
SnnN/fkKqWYbCWZ24m5i6wjLO0wdKgLt/wnLst3Zf6My9S2QS5xikwAzLW7M5bXdZjzWb50ZQHor
8b0Bzv3DbnjX577EMLwxJ5RqVBgLd+RtrfnunXxWAhYIOZv/ZZ/yjuisy2ssZbqFdVSagfBFfAw5
KMMisUlvhcanvVvWbyqdhZHwzBDc1RmmqbOGIavpeuE6rRY7+IvAwcTwpb0m4FFP0MHZctqZRNL+
Nd8WH0DtttvvhFyCeN164M4775R1ugbGXhE0YQj37aBfcixYUN03rxYoyDFL+uH0LNjIf4vW9uFh
t2/voOE3AIWpkxvD6N3Exl9EJt3cddo3v2kVzlp8hJTxGbtPX4Cjq4DxzKCfwTH8i331/MK=