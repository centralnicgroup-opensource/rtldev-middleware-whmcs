<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqeVSPjyuKdTUQtak4aE6S/uE/bBtwVbcxQuG4xf77FUbydT1dOFVYGK0Lm6EZyef3HcY2LQ
6YiMEhUY9xQ/Xje4H6eNYh9gPAzCL5VPBJXZ0gw/RVXcvCx8jtmATW0PRXP+zmTzCLzXqsvqUNci
9PieIL/jh2GxNAytLJu43hDdfYTJJaDwe677eKBNynHH+qy/FfEQ/uh4tQb5Gz+ykpkyyE7s/I9e
V76EpMzRGeG5RK5LoyqREkEDjGvl1we+7wEc4xy/aYpMHNW56at4sU2pwmnYjDkblJtVTOcJLeWI
smSO/yawETyjQ4wogAQ1wcXHWp/KHJuUPp6GruxKZWpDMzkybYYfqvSEsWIxC2ZrPXK2cJAk4Cby
SoBHHuSR7FN9pmrfJ98weVVXLO32zrk6lLu9yJVSdYC5vggfnVK6uezcE+DYatM925/LQP8wRO5T
6MKhkMV3O6dh6NPRClSRg+JJT4gvUt9rDn2M+7XT0xxU2ck1AXYcC2KtmCeU3FmmrXVo9ytJNg9V
tYXwmhpJeVN9uHBhk9Bfbyj4XuTNbn+2Cy4XCka4i2UPOfo/CzW/Bk7gzjscTLKWPkPgW9Iw3sYt
R7WXhu59DPDINhF1QQ6JO5FCXB24VQ2Rhnp2C2wsKqx/6kO9xCYnlJ1eBmkZO3fOX0G/vUMI1FZE
IaZDioAvq7JDwBzbLTxO/Jit35W9tVP7nR0SulsB63wCxjYxKJS4Fmq+6xNphLmppcVe3s41ZZUS
LrsBl3Z9EgRa0hmkgmZkoidf4goBOb7xwYbSbJVD73i6b/Om2Inknmh+lM2Ur1pu5zb+oN0bmquR
FLUFeevUlFJkBbxq4Vxy52lBnwqZ+LtfAD4MKMBlx0fcBuChMPmmJCAbspK7112gQlyoVivBo+5L
Pxodklr0TZEycrK/R4cGoNKb6BIQSrqTdOL4UKxXrOIfCQg5rYtFrSbArYGiQHAnR+xHl6OA+L7T
ZyNF6/ydeo9q/sg9V2KYpT3s+gszmK/+p4/1IdTNztOMvt86Rj7AGEoufDE4OXbXf2EyYoCXkaZb
sHc+zPjaiY0S9D9vpbo2hVEKcEKGw+f9v2hTFxsSqj5R3K6KQozXpR5MXZAdI4p/4/lHC+mYWgKU
LHVdbWGdmvYWcgOPi2LSazjkV919ByjPlHYaD+cAdLlo+QJXBNyDhaNdkugigtgDVMY7v0geNrDE
M3jJAtaPD8LDabpYm80BB/EyQ6EQuZrkYbcXhCtS/+4ku9u+v1OBTRg2hrN2je6/UrdbtpkwDOpD
DgEPn1ybz0yZ5l9CfWmCCWlUHTWG9laAGYmFMExveUWYJjrLbEwYpmUreq90ogAvf30kRUaJVlLa
+Q/lKhr7XHL+2zAPiRQN52WJXYThUhCt70sKXrhMf8BINkPa1+PC8Aa91uomFoLCKx5GmE3eB89R
6R3/QibA+5kMrtJRc+5Q9+zuMfhLcoFdJAwkrptf7nerP1J5N9gpGNYu+tDrPG/EMMYLQ41gg+7g
bMJujGwuLjZKhFAi5iGARz+PwyPJcvwaWHaqYXdMvmon0IVrKjPmiyF65SAdcWT7Te0sy9O2Uyej
BNDIszZPnQ2s9iCMhrq/xJxVNutbK2mmFVenx40DObQbUEsFaI2DV6DEIqoqfe+FpS0x/o9aQFTT
E3lxVylgsZqEXPtx5TX5T5zEHcAT4bcTMo3mZ0jIR0GedszHVlo2NOnTnHugBzJ7kT7zIqentsBC
U5ge9vVvkZDkZ01uCAEE+gV3rorwCNRzb1i8TKPikZKdWAcThsqHi3ScvloNwcjeU1TZOa+a8frx
yG7qoWAJ6XEAIPHoPMPRqj+5cmfHzQQt6UWJmzgvJV+RAqa7UNa2bEYWfpgwVBOszIBJJ1K4qlfa
sdIM5/utPQ8L9ClAu0VgBRhCMFDWnqB1pAzdMQUXl2rWOA2d9vbOHFtF9hIhKnseh1VTYtBVqqcC
wQgkRXa7XKum0PVpFTP6v6a7kWkHHZT0Hoz8tUyzREG5unh8fdHR73bI3enlvmDEnGe27HJhDvFi
+4byO5nJfBnuqUmYniPfKRKDvLiYa84WFQozW57+cyP8BXE/DaD7HRshMg4kK0==