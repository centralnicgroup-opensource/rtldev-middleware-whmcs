<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxO/SEXOh4Z09VBborGEnWGGISGDvXvashQuOkgpBt1SBJ9UdiogBmDBWK82/lUD4ccqV7gm
PKmoCPLqP66o8CXEPVENWN/nH1Szbl+bup1nez5DlS/wLJVACTHTzzoW84rg+KhI9p/n0ss4AP3H
yf/efTNFW9NifRVTal1OhcAzi51mbL5/mTwBQpzkZHpOak7jfj7kRj5nTGd3hwCesZ3UP9ZvLkrZ
oPNxIYUCA0FPadH9mjk6s/JtMeP6taKIxO164xy/aYpMHNW56at4sU2pwqLm5mTWwKOFGdSpf8XY
QEWsh/ufFgGxLESXhsFYi8HqJMWITligWYD/Y+TwE8pkQy26YMmaJEE9u8hMgxbv97hIcVZG8v/e
b60+1yEoAX4ONa5EdjRVUxi7RKHDExJYvbTw5DJsPcgf81/2K6Kd/0atFcUjFhahwq5Msseo4eU3
SE21b3YyeYy1VrHoJf6pGrQb5tiBGh9vtgltmAv3s5UY8cK/7z7qv1uPvdRGT0qZBJAvTg+NfwDe
KFqS1XELgYQMltjFAZTy8ICB4cXE669BDQVsrasMGQTjQydW5OBRqKL4Ubnq2xdOpnS63fhYKKdg
XypGdGMBNT5YHL8H/cQ+bInNfTtnwUK5Dd0v21EOtRshObxoD8pY0tZ5i/0uD3cTh3lbk0H+zHaU
EJzDfgtIxy+UG+NztEds3Cvny37K14IJ/T7gZD3IR3GvjdHAF/D5uNwlWPTPO+JEIKcXkHiU/+Fz
AYH4z3NiZNOYdTZjEOPhCYcUXBmQ9DQoA1ltSFxguGFkf2ikxTw3hf5llgp7qKMrFuWxOr2Qkkxb
3B6r2BHfJxq2Upxn5Z7X3p7WOOPzwovjyTPPWXOQcrlx9MFQl338+fBRcL/DllT5wgSq2ueRcDe6
bQHQCgjzNXbaUdiQs+EIutVT48Z0YZ8/Lei0v/oDOxjKyZVCjNVR7y9jNtPhbaPAe/MUa74COCkw
cf+HdX2kc3wJGYi+aroB95v47OxnM5zJMVvl6XLXHQPl2V33f07HgqAKGZFD4mw9qey4FhkbWba+
QWKQouwEOB6frtKi0fqZ42s9b1/7A26iCTd6S+gcLiUU2ckKkpaTZVcHWbwke1Lp7AzDvEL/h4fc
eC6e6DnHJabTVisg1wn435EjAoy4KOCGQFuCLudrTflSxgdoAuECX9Clu32/+cNREgAUHbnefo54
F+BeILSv3lmVoYRvHTEKakt120d0UUILJcPEeAwB75EbNpOUc1ig+0phDMcOpp0dKHVt2jRYE3sC
oNdFOQKWUq3A+klw7mTJYqqgDwgYmKsf9IkjUZEIQsxhifV6R5ppq+fopYT30S+3oK4QWL5QN77O
eBFnbvAn/Q0AXZxEDcDs8PPE+AY1LLRYJwvxZbP+EfvuATmUYqZEnEsTqJYyYxz+X3BRFxsT/uCI
dyu6MWotDtddoCBmdvP7X3N1aQKOdOA+yF+80Yk+j8YJrrKp4SkdhVLg7oqm27rNYliX00icGJtH
LVO6ITY+gXhe4myObjYP6ebplQ5G3Njmvk/SOlicDRkTWEdr0irswTe/xsq2mF5nPmTuucC25kzS
KeJkh4Le8cnUPja8NI/ZA4zNxeIsNch5WbLSS4KDAFkn5hTgkAsg1GbuNboKSQI6jK0LKrJleYRS
qb5FidvrOnYQpiS8HlCHPs9NPCTxVN//qsxnhB3iFSYfCMAQtH1HTj1UP/4/eY1rllJRUjDcDHcS
9+Ov6HEhweuLxMwv5OGX3GCczxNmuZKe8VLiCLcu9TK2EbC2a8GsEWe5RT4zYKy+azw30C/cypGf
74Dbt/0r1N8+BerhlUkKIM17o5U+jGFh4eBA0YJZC0EjGOOd+r6rG6peP/nj++mkbTqxvjaWY/Bi
5HQDtiRuVq3nC7RMXnRK3Mnn4eEDC/EIk+JtbaxPyRbxmJcNelSCbTOiG7VL3pzvnKGGdZhrdh3w
y9k4qibrMjVunYlgXjByLu6NxdZsI3gWNQK74r0ziarHyV9QK5A1DGvuJVv/0bV2iTQf12/C+CBZ
uZVrPVr9TxAUfCCNfmgq8N/Z4onLU/jKQ51Kt6lMkb2wL4soSPUZBomBmuIKTeehLPkcMteB98/Q
VWtb77m3GMSSt3NYYR0WIOhpo/rM0gmMDKeLKYotb0yhiTjIm6AKwgdM2wmSumeGb9uKMLOFY4u1
hxXgTBKLMCnFn5uN23vW5Secpfa4UQrvLGX5ad/DykchTBv1JdCDR0LANsTmPwy4QnJVR0X8FLFs
zjT9CK6BCVJz9tZp1aoMD1X4/nP+ikY3apsslUbV50H2AzzSMPcJtcagjBQNjtaGL7QZJAqSLbTw
/qD3pv7BkYdng3T6DTiZ/JDZb5GrK1MO6gqv6wOB/xunpLajeij4+pbzE6Lq9NC8ywf/EMPCJwTJ
zRKC0nheT8zp2GCJXXjkgVm806dWA6USyYt2JvWNr18kPSF2BTSt9DExkLB5z9QtI9BvKaicT01b
dkK2IiQdnoihmL45FVoOuDRowNcPGS50fumJoPc0bKioATnJ1IbBx4XwMATdjEmPjtt6JbjUHvjk
BIOYBwxbQ+O0U0W6VWSL2fakt1xr5T4KS++7WhUVxnCtaff9KvPRGaupMJwPG8CuQuVDBSdgiN25
cvu8ff7ptM0cpiwIsAi+CfgicrUXk2xXardDvmZo09tngJWJ3yzmzfLjuQxsAPeQB6xrou4br4k/
7II5ah8skS4FuXkm/4IpY8U6tnPPBljHVPS+Eci0USxsGb9EDJxd0Irygbsh/XqSqR98ETCLdsqG
9UTJHTMEJr4NvPimu8esV3J40TQunM160OOpn24+WT2aOAD9Gy1/fzHTWISvW4SqlA//tADidLzG
YZ+LnP/GUnXWh/HACPU9AKGN3jLHAwCEjhVg