<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPneX1BRsflovZ+oHbV8Qg9r+4dlbcWAWphguCTS9oYyQNp2OKUfSkrZeFohuVZx4DJrVow0U
giYXv/IiUCeXWDHzXFEAhJW+ci17Sg4bKQhLAusO4paaGuxn73eMmGNgGviCi/nFhiBAaDSiR1MS
INUvgoKLosXkGelYJB6skGqJC9IVQ2rXgZQwGT9cBXZ0oW9ajqGrCYSI6rf6XnhBZojXILCzmNK8
RwYPJhUcQNcxb3PR+A/wX3Hy6psHJIfUmEmB4xy/aYpMHNW56at4sU2pw/XZywIIOQ8ZotFZuuZo
wkOT/qSYUzfEoMDLcSTvoZZvP0jQ+0/iIw2hb0+HeLXV0Tg0tdJmAIP5WqNWKP3Rvf69WLK6/c6G
+cFM5o0lt+I7pDcvaxqoEb5MW+h6GjfCXqgL71cPlpXZH7QNpACev0xKSihgp1pfGlTnqmPZjsW4
SxN5Aa8/1IbHGFFGIglUrnmX4X5Uf6VK2WSo9lEcFfpydwNy3hzfYjgHKL8XyIlCK0SDEPL6ap60
U94qZrT7Geq35/QprCx2CNC1JBfdZZPLCbiOHn0pqEfduyuKCzPXlT1snsxN56yfd/1DTK9Gatgb
n0COvKuA5jpzu1leZ2iX8uMExFFggMqc+9EXmCLP0LEOBVvzyYt5ZUEgUR1JezMf72jATlwTz78C
Mb3YkeIYI9Z37ENV5KOPUBrLAENeHIQL4FG22MkDzleg0VTiibrRWHFh3BQu6VhXaolAwxrPmRkT
dxmGKzEZoU29MOww/oaLizqjn3cYf8VBH0hOuUcrPpP2i3GY8DUmD8gQu6wksjMhDNJAzI39jjNQ
JJrAPth+CoM9FHAYFM6JhYPcAogrECEkSAc+9bVmMSJIg3AQZmrFobO4YiJjhH+Ngr4EBZg9A85B
cykkBpN1X8JKFkZhC/cuH14rQhLot4GZf0LmYDhNdjjIQgikyq/YJdv0kwiX2hvVDSXzRMStKDhW
swX8N4O07FqwnPen/NVJQieREcxyDPhCD5KcvGYg5MWHywM5E+yqpzs7/BTo3PgH9CL8EOdOBVp1
Hdfe0Rg9xQc0ex1Wx2VLW1MT57YhhANdChXkg9RLOJIPg04AHe71gCxwufwCZLOr9IJDdSNFTCF0
ZN2udpSzawLudAq5qkuLWKjgH6cR8jbv1O1pOLO6Z6ejDus/Dty32MIwsM5UHaWm86pXI1YjSHAO
8ymhGj/ITgezfT0wUQU4sg83qz+eU5BLjis3Syr/u9nsRZbWSiFE4NHwcm1TL+/PS6hmoNAp9/dP
fiaCTftzAKpf4YyqIM59EjKRYejMVu9kJxZfRQbU0eEgd01o0M5EINoSl8tghKVpigkAikPRYTuN
uyzlmJVeZhCLYGSWxnq5qgFQo7I1y928exUjt5r6OyjMyO7o9bED3hbCr2u58ob6Zc5tvqolbLUE
hp2rcTWw0nkxyI76W1XxgN5vBIk+9ylnUbwF6Ii+5a79yHe3Nc1JECdrmWo/k0ngBGqEcCtZ4xFo
x8R3tkbztjVSvUXmYmM34BV1Hf+qT5Xn4aAnEpkBuq/bhlwsqt1owUobwAP2AawCbzHMqTRGc4Hy
C0VIdLlJn+WiUahwn+ND3ydvyK6TpPNZhgw1OEhNotMjZiqtuzHLk4HBvjqRT63KfjCi9plwWWUj
yBlHXvUIqMEeYCfzQ0kEo8lswAlw1aM1BEE6HgajksSJlr2EIymp8KAD7t3JjZNgauOY325wJDC1
IjJyaw7eI9uq24VlBsCfQLYyldUrHiSJ8IOMVKknBYYoSqpDu8NLHb1+08daw93fBX4B2Jlis9me
lkYM2yLml+z8xLv563bmthgHq1px52KGgtYwXOqQsnk7i9SxuYkKzAmFkujNBqB0hHDuXGRRE0Tg
6t/VSShBulCOHm1EtBFtYLEYf3ld3wmFU5L8rCKXHIOIRzQmtJJATGDsDQmRE9ylSSCb7TCisewF
wJOjpL0TadMTjXjABZtDldHbSN1elTzCC9xJ44DQpG9vErSgrdeR60OcAxdYc7eC3lym6qhi4m5B
r4SpTtJjwCtdCjM5lVnhGRRUA2aANtyat8DhP1DpdZ0LqsRYZrgplYpj6jBhbHji+mADiUHnTAyu
oz8dS3tSnwAJzyzIAtskt5rOAO2q3b8SXWslcc2SbTJfHwh4FUsnmeOg0w/nb5hWdBK7EetSLXrh
8YEVa4nKpMmqOvq9BTinS/FtZLgEatdGvTly93qjxFZuFtkonEPbpvfbOF0KkwWi+pFeZE0/u+pM
RYg/P6fXxVAoNLMGsdu9p2g22v7h7kHk1jHAJVSUzzdBU+/wPM1ZYgN/vPxpLzgdoOWD7N1gWmnH
nyGazn7HfjfskQOG4gLScMITPDfZDJFGlcJjp3i3+FHJd7aSvcchrrtZ1VusrFlWljRU1uZr6p3Y
ynLLDaPhGZMpWF+RZXzUgZb6WweOoJGUBAqOEAdf5XrwiTXjxnkIP3PJqxh8Odt0ad2/tm8Qsvzm
FXKGPi0W4IbEB0ZpXXR+M2/0Sdjr2R3cqKMCE1uK6JKXkHxogFYqUFU8AzKrJw3+vphHjuGTrGna
vdLblQ0nNYHK1U593XQ6Apk162zVNg1S+lJI6NPtmYZvgh57ZqilpBOMefrPhvcj0d6tmru1Mg13
FUriQIO5M2PTFRmWSMDADgDbLIqX0woNyLL4YGPD0HkTgmIgFtpzzgx46tK7ffJnSeeKK1TRWUlx
M70jR2X6MmmGVbvfJ8BjBJ94IJ2pYyZrEpiOwNwWTjoHZvEKueDMUy21jdCwcX/rK1VwlN4SGAL+
Szf6B5CvPtC/MGqNT1jWQwqDCY0jklcROBFPheYgXvSV0ofE8I3bvUzlgF61llGUda5OJqhY6C1f
DweNWfaukmEAZrQUsD1liLYCJrcWJCYA0m==