<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp6P8VS5Pvhuq2kqr9bU7LTMgWLqI/DCchkuMO68fR1tR+tibxf7E502ebt8tKzLvWa55CHE
pzoGFHqS+i7bVokI6MHOLOcmhiVebQXxTNUoOryIUrUK1ptHyfVOytjnio8kk9R+h1tcd2vhjf9T
VMtB/t3OoHIeHa/M7JU0RDLMiiX0JHpuGRwNyms3xOfjZj5V3Ncahvjt38L+VAgR1L6xTsEubCdm
P41og0CYE1OCr5CiQjYY3IZYTttGyEmPP0Z24xy/aYpMHNW56at4sU2pwoPf5h96bxNq4SAcjyZI
E8X//nzSbqJA8LP/Ob6KgxYeTzTpvFVATKBHKYtncxlrvnuIQlitCsitOKRa7dHGB9raoWI907Az
nt3naSNj2/DYcUg3TiR3zXjvg48DwV9+hT9zbjjgPRnBXJe0bxMFq5VGS/kxolBq13luWrrODs5b
VpEbjbSzqfPovnJCxnEOvxSV1DqxwH08o06Czw53vBff8sGEC5ssA3F/gpKHXWxex5sdQPamr29n
6WLZBs172tAgrNK8E2NUiOMtxJZ/+XQfGUceGLOdGAvirnHkcHr6Q18zPDFyr9uRzgUNbflhEmLp
8yPUmLP0+dUuzjY3jeRGsXNOfud1orbFjbRz4171Pch/1qH/l9pKzJimgVZcKC+2eFQYMulaJAq8
Pj2gcqOZNIDuWChAJw1yrtp4QQwYQYbI0Uy9gxOC/zr0f3wcFewjub2rVWW7CZlhKlODeo3zdcrY
UvzWw05FCek2qFE1IndMS6bpSqAAPWPHiDeiSC89xgcuXNreBitocKHado5idI5w6DiYeiFbqTfD
mFjMc+kGZrLIfJJF3G7Y2RvSmns9qhK5E9K0RSVRDj4cpq8KxjUsTMtXmjUOYGL8N1uQagag3EeP
xi0TTMXNHI53fVezsyAFs0jWf8kTggJ2VR1IsPyPLc2Tomhh8Vbm8n/oWcaSuA1uVqnmHIooffiK
s1AYL1JOOO/5sqDvVENjJ7VCxjHGiYQLLPH5SE8SFe0uPNziBiYOclL8Rf7iaIdSUkuAhgh21QO/
lQBn1WOCfYp5lbs/EwxZhPUuCjG4tDoUV8Kx3GgZpv1SdhMft8Akv22x5vJlcFj7U+vCoiX++hPW
RODP2B/Ifks+UKx5HIpjOZQDHXd5tMvXyairoKbdtDIOxrfYBNH1HYKFeCqV/EPzWwIi4DfF4uQ1
zHap1DqBUpOxgGoeiUinHmBPXWNDqXCpoL2jbXbcIUcTvBlYVhh/uMfHzcy/KethKMwknqUgIFS3
8eXk/S5TqBpf8qNC0QmlHMajBSAmCXQr67BHaAeC1/FUPP3hl4Wd3iZ8N8mqZQiBhTwWP8aQXqeU
y7dWsP8BT3yHJ5o3LkJk3wnLFZ8w27ws79rvv+woX7XPdG4X0NqKbSGUR0F3ydVmsIDD857dmEDX
kTCYTMQ3/P3B6UPv/K5+1FAc9rLlDMaAk3UOtDyzhCQXCdr0wg5BtB4immJGT5jkmOgWyVNZmiXL
ClU74d2J4zpi6vXnpUZwW/r/5cZ/3hVlK86WU84ossjtX1QHmhNFip8/AlMiul4xKjx1LdHatFJs
BUFC4mqn7yFMd3LpSkzrL92qiZ90ikD+ueg0x6r97W2+M0pinslzfOh/LoLvTJCAjOcwKFqhs3EW
emtzs2OCI3EVm0n67642RyE1Zo23a8WXOr8zKm1dr5hiyNcV/NYqHcW09OPFj6TaUYh33XMyKX4I
2Xa9GB9Oop3BBTmxJlwDbEFaEtlHiIr6tJjcdH2pJU+conxiCmi7BrcCR6GgusddJFJfYPeU+VvP
pAEdVIRwwDtnIa8GHsnpeVYC9UiR0xxA7PFpqoqptY6/FHhThEcxd587sm==