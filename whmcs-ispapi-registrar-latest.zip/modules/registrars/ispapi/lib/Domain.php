<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class Domain
{
    /**
     * get domain name variants (idn, punycode)
     * @param array $params common module parameters
     * @param string $domain domain name
     * @return array with keys idn and punycode
     */
    public static function convert($params, $domain)
    {
        $domain = strtolower($domain);
        $r = Ispapi::call([
            "COMMAND" => "ConvertIDN",
            "DOMAIN0" => $domain
        ], $params);
        if ($r["CODE"] == "200" && isset($r["PROPERTY"]["ACE"][0])) {
            return [
                "idn" => strtolower($r["PROPERTY"]["IDN"][0]),
                "punycode" => strtolower($r["PROPERTY"]["ACE"][0])
            ];
        }
        return [
            "idn" => $domain,
            "punycode" => $domain
        ];
    }
    /**
     * get domain status
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getStatus($params, $domain, $hosttypeattr = false)
    {
        $cmd = [
            "COMMAND" => "StatusDomain",
            "DOMAIN" => $domain
        ];
        if ($hosttypeattr) {
            $cmd["HOSTTYPE"] = "ATTRIBUTE";
        }
        $r = Ispapi::call($cmd, $params);
        if ($r["CODE"] != "200") {
            return [
                "success" => false,
                "error" => "Loading domain status failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }
    /**
     * get nameservers of transfer request
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getNameservers($params, $domain)
    {
        $r = self::getStatus($params, $domain);
        if (!$r["success"]) {
            return $r;
        }
        return [
            "success" => true,
            "nameservers" => $r["data"]["NAMESERVER"]
        ];
    }

    /**
     * check if trade is necessary for registrant modification
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function needsTradeForRegistrantModification($params, $domain, $type = "TRADE")
    {
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainOptions",
            "DOMAIN0" => $domain
        ], $params);
        return (
            $r["CODE"] == 200
            && isset($r["PROPERTY"]["ZONEPOLICYREGISTRANTNAMECHANGEBY"][0])
            && $type === $r["PROPERTY"]["ZONEPOLICYREGISTRANTNAMECHANGEBY"][0]
        );
    }

    /**
     * check if IRTP Trade is necessary for registrant modification
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function needsIRTPForRegistrantModification($params, $domain)
    {
        return self::needsTradeForRegistrantModification($params, $domain, "ICANN-TRADE");
    }

    /**
     * Get the domain's assigned auth code.
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getAuthCode($params, $domain)
    {
        // Expiring Authorization Codes
        // https://confluence.centralnic.com/display/RSR/Expiring+Authcodes
        // pending cases:
        // - RSRBE-3774
        // - RSRBE-3753
        if (preg_match("/\.de$/i", $domain)) {
            $response = Ispapi::call([
                "COMMAND" => "DENIC_CreateAuthInfo1",
                "DOMAIN" => $domain
            ], $params);
        } elseif (preg_match("/\.eu$/i", $domain)) {
            $response = Ispapi::call([
                "COMMAND" => "RequestDomainAuthInfo",
                "DOMAIN" => $domain
            ], $params);
            // TODO -> PENDING = 1|0
        } else {
            // default case for all other tlds
            $response = Ispapi::call([
               "COMMAND" => "StatusDomain",
               "DOMAIN" => $domain
            ], $params);
            if (preg_match("/\.(fi|nz)$/i", $domain)) {
                if ($response["CODE"] === "200" && $response["PROPERTY"]["TRANSFERLOCK"][0] === "1") {
                    return [
                        "error" => "Failed loading the epp code. Please unlock this domain name first. A new epp code will then be generated and provided here."
                    ];
                }
            }
        }

        // check response
        if ($response["CODE"] === "200") {
            if (!isset($response["PROPERTY"]["AUTH"][0])) {
                return []; // send to registrant by email
            }
            if (!strlen($response["PROPERTY"]["AUTH"][0])) {
                return [
                    "error" => "Failed loading the epp code (No authcode assigned to this domain name. Contact Support)."
                ];
            }
            //htmlspecialchars -> fixed in (#5070 @ 6.2.0 GA) / (#4166 @ 5.3.0)
            return [
                "eppcode" => $response["PROPERTY"]["AUTH"][0]
            ];
        }
        return [
            "error" => "Failed loading the epp code (" . $response["DESCRIPTION"] . ")."
        ];
    }

    /**
     * Get current Lock Status of the given domain.
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getRegistrarLock($params, $domain)
    {
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainList",
            "VERSION" => 2,
            "NOTOTAL" => 1,
            "DOMAIN" => $domain,
            "WIDE" => 1
        ], $params);

        // NOTE: returning an error still shows up as "unlocked"
        // Removing the menu entry by hook therefore ftw.
        if ($r["CODE"] !== "200") {
            return [
                "error" => $r["DESCRIPTION"]
            ];
        }
        $r = $r["PROPERTY"];
        // list command always returns 200, but maybe no data
        if (!isset($r["TRANSFERLOCK"])) {
            return [
                "error" => "Domain Name not found."
            ];
        }
        // return locking status
        if ($r["TRANSFERLOCK"][0] === "1") {
            return "locked";
        }
        if ($r["TRANSFERLOCK"][0] === "0") {
            return "unlocked";
        }
        // empty string
        return [
            "error" => "Registrar Lock unsupported for this TLD."
        ];
    }

    /**
     * Lock or Unlock the domain as requested.
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function saveRegistrarLock($params, $domain)
    {
        $doLock = ($params["lockenabled"] === "locked");

        $cmd = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "TRANSFERLOCK" => $doLock ? "1" : "0"
        ];
        //Expiring Authcodes
        //https://confluence.centralnic.com/display/RSR/Expiring+Authcodes
        if (!$doLock && preg_match("/\.fi$/i", $domain)) {
            $cmd["AUTH"] = self::generateEPPCode();
        }
        $response = Ispapi::call($cmd, $params);

        if ($response["CODE"] !== "200") {
            return [
                "error" => $domain . ": Unable to " . ($doLock ? "set" : "remove")  . " registrar lock. [" . $response["DESCRIPTION"] . "]"
            ];
        }
        return [
            "success" => $domain . ": Successfully " . ($doLock ? "set" : "removed")  . " registrar lock."
        ];
    }

    /**
     * Restore given Domain Name
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function restore($params, $domain)
    {
        $response = Ispapi::call([
            "COMMAND" => "RestoreDomain",
            "DOMAIN" => $domain
        ], $params);
        if ($response["CODE"] !== "200") {
            return [
                "error" => "Domain Restore failed. (" . $response["CODE"] . " " . $response["DESCRIPTION"] . ")"
            ];
        }

        $msg = "Domain Restore succeeded. ";
        // compare WHMCS' regperiod with the default restore period
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainOptions",
            "DOMAIN0" => $domain
        ], $params);
        // unable to fetch list of supported renewal periods
        if (!isset($r["PROPERTY"]["ZONERENEWALPERIODS"][0])) {
            return [
                "success" => true,
                "message" => $msg . "Not able to check for matching renewal period."
            ];
        }

        // compare periods
        $periods = explode(",", $r["PROPERTY"]["ZONERENEWALPERIODS"][0]);
        $perioddiff = $params["regperiod"] - intval($periods[0]);
        // no difference - should apply to the most cases
        if ($perioddiff === 0) {
            return [
                "success" => true,
                "message" => $msg
            ];
        }
        // difference detected. check if that diff period is supported as renewal period
        if (!in_array($perioddiff . "Y", $periods)) {
            return [
                "success" => true,
                "message" => $msg . "Not able to check for matching renewal period."
            ];
        }

        return [
            "success" => true,
            "message" => $msg . "Requires additional Renewal to fit Renewal Period provided.",
            "periodLeft" => $perioddiff
        ];
    }

    /**
     * Renew given Domain Name
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function renew($params, $domain)
    {
        // --- Domain Renewal
        $command = [
            "COMMAND" => "RenewDomain",
            "DOMAIN" => $domain,
            "PERIOD" => $params["regperiod"]
        ];
        // renew premium domain
        $premiumDomainsEnabled = (bool) $params["premiumEnabled"];
        if ($premiumDomainsEnabled) { //check if premium domain functionality is enabled by the admin
            $premiumDomainsCost = $params["premiumCost"];
            if (!empty($premiumDomainsCost)) { //check if the domain has a premium price
                $statusDomainResponse = Ispapi::call([
                    "COMMAND" => "StatusDomain",
                    "DOMAIN" => $domain
                    //"PROPERTIES" => "PRICES" //not an option as account currency is different
                ], $params);

                if ($statusDomainResponse["CODE"] == 200 && !empty($statusDomainResponse["PROPERTY"]["SUBCLASS"][0])) {
                    $prices = ispapi_GetPremiumPrice($params);
                    if ($premiumDomainsCost === $prices["renew"]) { //check if WHMCS' price fits to the API one
                        $command["CLASS"] = $statusDomainResponse["PROPERTY"]["SUBCLASS"][0];
                    }
                }
            }
        }
        $response = Ispapi::call($command, $params);

        // required explit renewal in our system
        if ($response["CODE"] === "510") {
            $command["COMMAND"] = "PayDomainRenewal";
            $response = Ispapi::call($command, $params);
        }

        if ($response["CODE"] !== "200") {
            return [
                "error" => "Renewal failed. (" . $response["CODE"] . " " . $response["DESCRIPTION"] . ")"
            ];
        }

        return [
            "success" => true,
            "message" => "Renewal succeeded."
        ];
    }

    /**
     * Generate a random auth code
     * @return string
     */
    private static function generateEPPCode()
    {
        $numbers = "0123456789";
        $small_letters = "abcdefghijklmnopqrstuvwxyz";
        $capital_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $special_chars = "@#$*[]{}=+";
        $final_auth = substr(str_shuffle($numbers), 0, 3);
        $final_auth .= substr(str_shuffle($small_letters), 0, 3);
        $final_auth .= substr(str_shuffle($capital_letters), 0, 3);
        $final_auth .= substr(str_shuffle($special_chars), 0, 2);
        return str_shuffle($final_auth);
    }
}
