<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class Domain
{
    /**
     * get domain name variants (idn, punycode)
     * @param array $params common module parameters
     * @param string $domain domain name
     * @return array with keys idn and punycode
     */
    public static function convert($params, $domain)
    {
        $domain = strtolower($domain);
        $r = Ispapi::call([
            "COMMAND" => "ConvertIDN",
            "DOMAIN0" => $domain
        ], $params);
        if ($r["CODE"] == "200" && isset($r["PROPERTY"]["ACE"][0])) {
            return [
                "idn" => strtolower($r["PROPERTY"]["IDN"][0]),
                "punycode" => strtolower($r["PROPERTY"]["ACE"][0])
            ];
        }
        return [
            "idn" => $domain,
            "punycode" => $domain
        ];
    }
    /**
     * get domain status
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getStatus($params, $domain)
    {
        $r = Ispapi::call([
            "COMMAND" => "StatusDomain",
            "DOMAIN" => $domain
        ], $params);
        if ($r["CODE"] != "200") {
            return [
                "success" => false,
                "error" => "Loading domain status failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }
    /**
     * get nameservers of transfer request
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getNameservers($params, $domain)
    {
        $r = self::getStatus($params, $domain);
        if (!$r["success"]) {
            return $r;
        }
        return [
            "success" => true,
            "nameservers" => $r["data"]["NAMESERVER"]
        ];
    }

    /**
     * check if trade is necessary for registrant modification
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function needsTradeForRegistrantModification($params, $domain)
    {
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainOptions",
            "DOMAIN0" => $domain
        ], $params);
        return ($r["CODE"] == 200 && "TRADE" === $r["PROPERTY"]["ZONEPOLICYREGISTRANTNAMECHANGEBY"][0]);
    }

    /**
     * Get Deletion Date
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getDeletionDate($params, $domain)
    {
        $r = Ispapi::call([
            "COMMAND" => "QueryObjectList",
            "OBJECTCLASS" => "DELETEDDOMAIN",
            "USERDEPTH" => "SELF",
            "OBJECTID" => $domain,
            "WIDE" => 1
        ], $params);
        if ($r["CODE"] == "200" && $r["COUNT"][0]) {
            return [
                "success" => true,
                "deletiondate" => $r["PROPERTY"]["UPDATEDDATE"][0]
            ];
        }
        return [
            "success" => false,
            "error" => "Loading domain deletion date failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
            "errorcode" => $r["CODE"]
        ];
    }

    /**
     * Get the exact domain status after being dropped out of our API
     * So, where StatusDomain would return "545 Object not found"
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getDeletionStatus($params, $domain)
    {
        $dd = self::getDeletionDate($params, $domain);
        if (!$dd["success"]) {
        }
    }
}
