<?php //00967
// MIT License
// 
// Copyright (c) 2018-2021 HEXONET
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyDxQBfwnr2+0ylzcGeGQUt1ee5HjGl+fjU9163Vq4es52is5wtUDd7fK6GXmvenv7o1q0Pv
b8pgEqdtrAABcveOVXosqrYusTEiMq76vZZCasXzk/JXoX3t5nKTlZ2qzvUQfrwpJGzZjXn89Q6Q
OOwnkWG0i6zAeURgMD2EFcERP1G1ciV+Zlw6m3b+K8Q9QmngIWLyTxfZShoazYTr7Q5wXsE+BgDq
hOQO5zZ/ivdVIrzodLZfxgrd1vxGn2oiKpygFXVBYR9mIvPYNKcKQxLxHogLQdVdfOHQBexgcOAQ
9qc3SIWB1vFhqb9TL8dhycANqP6yO/325UC2W+tiiO55PZwYDiqo61EFe1IBaHrOTnwWbhlazGNp
w89pGJQ/xsv1x457KPaajnEG2gJIG2sT0QNXftQvtuxVFuHl6vrxx3RPTb4zidH9TyN/qn3QYhj9
SdI0ImJDIW3GVAjvJmj7/DOBwZ2n1UNu1lcCKUGhcJvl/p49kC+rc2QQh3vUoAoLFVT/3AXdc7K1
Ni0IyC9SSj2V0DM0y5iLKtyf6aeRgX2O6oee+RIYGeCF1DPx7CnR+yGUI6Jl9qj/ciQo2ukv8yn7
MEszxwM7DadU8BO1uDTCzfioGt+nf6oHSTPysuquvrxzzUKATQLDdIxNofCJ5NF4kc2j1vuwY55z
MG6it45CgI7pp1i6Bn8sffS+eyN0pwtZTzAp4mRv+XPxSd5xfFJbucfX6+KTJPSYxrsU+oL+OIhM
71H3E1BWkkvL0aYvjqLtoQjW576Ao0Cmub/+Qq71P943huHerqXy4lqSEF92s+HHiC+JhOvtwiyL
CgA/MkranJb9sksQzRr+5ugHAKwFkV/z8N6mQzEx1G==