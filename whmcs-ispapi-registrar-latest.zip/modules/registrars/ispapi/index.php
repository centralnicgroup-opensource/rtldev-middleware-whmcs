<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpvwghtGmIwohSq/dWKK0CkECTTzkGZ7HQou2MwnXDBxcbxV+2qiFQui3tLAbcoHhKVs8ZSF
plMKY2vmcfGqEXYCD1AO1qBFtCgXd7koQ5WUDM4q1gPiMZNeXFE2SWnUjz6+GZ85BHXLtcXFyfXd
q5cDFcOODwrFdIlEiHdXJCZc8HIQO3kAsiGhqYWWYiaCx5SNIK0Ilko7DXcmQr8AtukzMk/DFOBp
CKqiv3MrOKgESI5N1fLnJBxK1dtaTFkZDdhSxhKcQJ7FrAUrfXHzWVZQ6BTZ2wND33kfoBm7xuRI
F+SjnZcotoCcKolZgj+7f9cbRzbmyBxMi13UXJxW2a02WYqLXgvJdcZ52d6w25e00b6e/TRvV9hm
nLr+cYvZuYFFks7scs0AdQCgxzdn4yIyLF+CtxSTliq09evszld5MNnbcmU5kpyKa4dySPFnPs4T
6UijoDPfMbRDLnVM8kas5u9XA16laBM2O+Qt6WJN0Uju3AA5gvn1A7ULfO4zWEPhOLVLmVwzSWj1
w766G+nxDQ2ZRy28RjeBM26MzkEh5llLP+Um0EsoserzSZYeOoR1LVupsWxTDu6PdlkY3d7FSTf4
EWiPBf5Y49s0fI1Ae6pGPW+Ar2/8khu5u2UFvkFo+sixBLcM3iMTSoD+wMjjYsvMPAvolhZLyjza
N1Zwo8+92jtw+2P7uL/Y8SPgNtKcqu2gWYj/1AxPw3GM59B0IMITh0etYGgeKSX7AXsOekmlt/05
p/Y6e0UdJJlwAQ0hsOHmuDgZYK1pk6QzEN0GSfkq3eSaS7tBGYi0UiD61P9UAJgTWw+lwW3HYY36
Q/K4uM+igPHrcRqlRB8ccJOO1cM5pVDfWAyur6IC