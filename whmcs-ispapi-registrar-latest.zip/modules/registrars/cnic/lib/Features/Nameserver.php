<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt2RQRLFILAx5bNybdRQp2tJvAvabI3DwDKHfroC/1pPLpylfeOdPUdm+dYTfhqbeaJx+OOr
NFJDvy7yDiOCuezZul6jJ6sTMICZ+NhPavAvj0SCe4PcnCdsl/GSxfKkxUSJ6STUdGFQkTwsLXpg
61ZbqIT8kKseZb0jcmHcJfok7QnUspbXh1gsjeu87AO0fx/PWXKxFw8oa5nfbVYjplbdgc0jwD0c
t9NuvoX27Ymld290/npuFg9exl+CmhvKOFYuAGplfkROXcpeULi3S7srFahjRx52NxY6Tqh4F/39
eY68FIp6dO0pzctq3yYr3E0WMsY7ipJ+lIdsY1CB9TnX1Iupnso5h7bZph/+lzZslfs0VzAUPUy8
wQ0RgDyb0wicdrgBrTIdY7DTMiG9Xg3IuTRgnMXPNFG3c5WLU3RdoHhpvhao+DwV3Vwfecm/4ohD
Eb5vvmJsBVvBYb5ZGyijLmziNI7f9XV91XKsfiDhbqsiqJ5rvnux8fHTUvwhdNJ9YVWa6hCj4CXF
Un8l5/2u8FQ9z71EK2YXFShRYmyGvIjaVooeo4DeyXG7LDW17CMIaaIt5j/wy5dWJzV/ONrSpd0L
B9v2TPjog3rN6LbssPQQir3o+V1behFaWbkBDxRazwf5xL1Z/wWZ4/YVx4eDV0AoWIDKWug5uVdh
2j65cu7MNhIH4TlMO4E1NZTVBIjnJH8iSZxBgqmIkNcvk4/UbUU+4sT0RW+eKw2gwPboDO25RXgx
SWRDKTcJLmoCB87WLOAgB0I8KfgGKjWrgw9ZzRTUjXvlsC07hGgJXp9Oo2Me9xueKX/eO99D0NDC
k7P9fLdrgWkOCczUT9QX1lktIuLZ9oaPFNuKSLUDcmqRPYwTS0Yfa+UketJkh7UTIR1stnWivYTD
+AmaNdtCBvuR1eWFAzrOHkG1zkYw/N8wOTTeKVpWyVDWD2//9YR+4WM8t63L8VfEgmm04Sd8Dt3O
UYai+Vgpp4V/4Gf+KemWY5lY6SmExkowXfCJPpLxCSsnzKYH54S/9fo55sTsbDOEsbDyy6Chkt3U
FIzbDqNU1hmFnQd6hqnmzTN2QtGvSdRU/Dfym7hnkrUvGEvyWb1qHjjrDa1UqTy2xBXS21taqqdj
BpiX7KQaiaxVk/fOVBBEGCy3W0kkJ2k7OIe0CqdukKmBO5ad0mOxXKBZMR2+m7RFg2ow5cYcUnj4
6xZv3h7jonTwct8PsOqAQUoRzeLqKQQFfocnrkI08E8Ry6xGeMC54/VJKTrx70sY+NSua3GMHRQi
XvKgRuF9ZuYHVoXXy0WYe18HYt9btbI7LtY1GZxkK6665XwdOjgol53is0GVNYtp+f6XvIuYSlVc
UWKY2Ekz1YbV7nQ1AJgkZJ5Jkg87u0dpSkfxxNbkYmD0lYx/puaqh9a0wMwZLqzm8rqwfh9vFvPA
LqmS++RnBjViJAa52igvYesLQUfKETY8HD94igZzbmCG+K2fGjNUf9LUxbOXtfhxVcC688SNfwFO
Xi65hq2aDdrb6VaEe46C8SRbTuDicvj238ATftMLUowkCAniqFSZA9gU160GrD/9VR9Cf/zAZcZS
u1tsL9/6MIeVCBuK8feBSNSJlpFzfvQx5kJDW89yUIJx7323FvoIk1xzMNqDkxxPBktM7QiBQy5n
jZkvdn8P5eS7e/ai/nB/dniUFVteYoPzRXsE9wb6gd0MRZGhU0DXYrTYERLYJq/3kzGjywfcucMx
POuYmCzzXQgBftEl/rEmxDopcSIIhHO5LNj+BCguNLJthaH81LppDFWXlksU2ddZRKSxH0n6Hcwm
fUQoPr/CduQbsy7/QAd6xJtgbBIum/DO9vJDirCFbnE70WYndsQRbaRfwsQROL15qDG/c8q124R2
rZMershZhpw1D1kPHIoGRsIiR6duqsRmZdTt9KpC62uqzkmaORWYZT5yIlXc2yixsUAvbwE9ACmQ
v1bpiUWf/YW9zn9k+LcK3rLS9gbkNzoU2rn2ucPBHm598QJG/RfvC1R/94JHQWjK/zNNWzJdxFMZ
jTtg9KqWXTNlQncpf7nHfZYytpuizXY3rzBUfSiJo1vsn/VmE4tbgytTLrvUoy/Dc5oz/IC+JafW
7BVbnKhwrORPJ17HSqaBhLfivDvRcwdiUsrnFc8+e60zB8VEhZ6B2gJOAboYY6W7Egu1JBuFd65b
q6ApwuWoiaKiWilCXkFM7nCpgFTjTjG5t6la7n9MH2VTqgEUN/v4m2d/1EalQqkJ/X99/qgRXvMw
FUHhsumY9nNspt4LEwZZjO29U/P0KgK8ZdpRs1QD6mWsNCWmArajLx0TX15LAgLrKUaau0i4s9Jg
XECFHwZG/X22HllwLqqr2eOY3FYN4J5o1IPpDfi71y9J03DUbBUcnrmwDa3OjzthYJK5cyx1x8C9
td1D5QNxAE44akqRHn/eMSPtVlxorJA8XaoSS1VF24kYhPSW4R7HOIpBtNPxZaW+lBjSep+qlRAH
Hin+Vft9FRwtbKnYhfPzw4cETBfnWeZ9sW7t+8hl7CILjmtfnKAPLbRLrxiGH2FeB1kAOB8xa92P
yn09FdSU4ZuvYjKQL7AEByiqu6uZA76GsSwK4jA419vvev8zkeZTaBvEhNmAIAxO0T9ikKxW54mB
i+TX/gC/qr8TFuynSpfIwyUZ4xjKCfkQXFYJlwL4Cll7/7B6tzMf15R+paLf2JG98kTVb7hoRucO
RVNYOMkSowU8Jc24K/Xt5KcM636hM7W3WHGm5wyQwD+atpU1xGNqFg4tkJA+QXHI4p3chkO+BeDI
Ut8UUBcyvnjPeCxzrQgFNk2uhydzNtDUM0D8jUQFgilIgo7HqE/UbHogSiGDhmEn46407DJPU0rP
lR0bc8/rMecNtHOSVILcNZI8qn4pAMIMIAjjuxejNpWNOd6vfZkkYNgYA4lbm8Q5bTvdJpqltLuM
xe3ESZEny8owyKk2tTA0tC8cY+W60EMUc5hIBIGEaPjlDT97qKwfCZCUDTMPGXGiEA7kzMbRqBG7
teXSnAqP5KH6we/KKhYdIwbo7LnMtzLbt0Wi2OWli0Xy0TdIHej/1Y52yNRu/TgHYlzipJdXTvCU
e+V7oJy9xd0LC4wecQeOhqTkfuQ8CxqSE+sQ3JBu5dXOKt9c+vutTzeRv50BUc2MStcS8NMWWIIT
aqPPjlRTDNsj/ssiPoJ9la6FnZbgl6gSriRsVEnB6UgmdWvYoDFBoZr9uJHHFMabZf2aE3kdkrlZ
AyaZCug91HhLuxMWRUyGLnh14HQjP7xn0CD9YdPNZPAk0ibecs0ll/zYmbSXNGLsaqcJCYtPKqNO
r9iYOiLCihrjVuYPCoQ5qZBcEGjcLaimXfDFuv+J6Uvd+v6g5L9n4a4hjQvwThdt