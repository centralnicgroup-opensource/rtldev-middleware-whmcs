<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPytxeJeiRXezAJGq6LmD701+MUB61/npgCEKGGyRrcRI4hTu7tlzdg6aK/uisQqWrNjorvN7
9EFL2w//3Gcy65nWfxT+mXv1ZcFSoHS516ngzqLlNT0EePfyILH0RPK3B4Ua3LJ4E4aLqqjbtJE7
OEgr5o0KbVhVl0MJYiye1QJLB5SxNBrmyh5JjMgk3Ai1DflnKlk7UXaWgtR/A8YLAPDZbFY+Vqld
lB79yziPwzC2laIC81427pSYd5LW2TeqY54uLG0CxwRcs8Piw7bR0t1zjJvAzc5eVrMO1a0PwSjF
YQA+vqkR8ExpTHIAc9AdaYTnzDtyIwbbet+qD3zlsUDzML3tXJ7cImseI47T6nOdveX4cxEP25jK
tekG2zUch9oC8ojKUvxUDVeYdjVH2FY/4++QmuxA6E8AgYjuK1WYde+KdAsxW33mZuKvE9CXwTNW
0NeXq7Eik8Br00STf9iG8xjVdh/UiEhtXjfqRs5ENIN+7HqtWg/r1G1RilhjFfUBVI9ZkpKAw5nO
d1PiVu8nsk/uwY2USYIHQ8BCTMnmuxH26epuefbzzqVijB1SjX12enECawM0+dlOWp86au+tV1rp
5R8l/WgGgrcXsIVxS+jwe6fD3tIMdhgxAcwCwDu01Mm7Uija1YqbbDUToj9BhcflDYi5l34APJU2
kYybDhHS1scrtpusi8iNfBDWQ34APsxVBUo6+5F97ZOwIzIMWZy2tzjcvnu0JuZ0tPr0nZ2TdOUk
wmjaVmeHEuo1i6g0mw2QiBYBr6QvszibCoFZknXBa80TufF8C1S/K/fnBTNdiZkoqGg9xZcTRGzK
22QeXuVz3leG46cepdZ1BlwKV8lF1CyfMmtNMY5HmLuWoBto/gTtHGOsGnAvDrD+l2m9iowLKJtf
/5z1bdbGsERd/QeAlC6Kh7SKSKeLaC0oUyeTb7+OvKEb+ruGL34EV7XrxnfmnawlvXNSmo0f456o
Agg6apbH1yGiAcN7twbBEq9JN3i6KaNlgl+MYzsZTPyhMWK4JA0l9XSCgnojQRB7Llgc4XYeoQeY
dqdPRa+jXOrPwTT+r1wIIf+/YraaCw2KLQiTueXToDYgcoRgKpKowmU+m6XFWUq1g2Cvy2nt6OPC
ck2ekSZtNAwg0FNGRFg8HeJdE8y/5UTLzvQphcOqMMCz469xZqufJQMbNtTXKQl2H+JBsaIYHxXn
CoPAsY6jlJEV3CqBKZRUAvN8uzUHNElGr0UbWS+j9MoBgiYRXJR1Sim5trixx+c5Ir86WcyLCltT
1Gno8d/D9ohJ0LjfM0YE97DEM+M01SOu6GPVGle2u8RBrAJJUxbts53lQW73K7G+IdT73m0qaOPj
GQvEqcg6QezTGXSYMA25MFZ3M05tGDlNbUzjJ0yoSAqVjtSpj5zAXvOowrv/f7cQ41Cn6NT6Tta8
dLyrAn+DH7UNKtstAoPKqjBEeSRBRnyfZeE0xsk+OYk0kl4fVGbxmP7ka9JKPyPaA/gW3/ZpAibi
Kyl9ub0aff/BOkgCM8GUOAGX0ViYYU6POszi/2wSQsKjIH3iR2FimImxi6zidKPyGP3AzIoiXytb
cUjcTbooWykTzjSOHuptYQRuybAbOPxmDu4sW5Zqv92YCVMm5/rVtl9xT5H8SAO7kDlM2N8vsLcs
QzxH0pAYC51JpS3u+7EUuO2Xn6zvTaeKCF/onOdT4c93sEQnv6ODHxtqvYysdGW1QogUOAu7drpT
ePfG3S7bDJfD5jDRPHi4V269WFJT/eOjjjNqeHHwBhpAdx4f1bk5R2N1YmL/Mfe8+CVAn1eAbPcd
QB5LwtXJpBMPb8n4byC/hoaEoGIB8mpyuQv3kUYqeeCTQewC523zwgzppNjSJ9HgNel2NGCM34y7
GT4bI2NKbKMJcga3DbUduQQkMSNaPsdMi5eA8k+N6W9t/t5nakbKS6IzwrdSq6d2tojyLywjDDuV
IJK+4wTSl7n8GSPzx7VCaBb/wByKYCtXBtXGcerCIp9J/6Mid6tk1ztnJVXt3ckH0I1KmRfeamar
LZ1LKQYD3it5L3D+VQTW3k9tQE3ZIbuGeOaRDusePNPwbicCSoIDd83c5sFTPWKUL0Pow0eWE1ae
mcNfmxCkh4GKPhw8nJFfafWgT9gktnjCMsAQzy95fY2nWmW9bKK6UsyoTBoqpC6Yrj6Kp3Z4gTvV
bkmWux49fxkwiVjuNCSoXj+iqC4hsBVpR68pBujiDOYW3GqvoB+sqkPwurRuCpKmZVW1CD509ryn
HVtjXsBnKoqLDzl8P461TNmiQ66CwGOBKTTeAUEZk5Q/yWGWeS9joGH0sO6FMYogXYiS48DcIoUz
MgPAedPiBGeHy0TMqxn/Ey724k/hbqK+rYt2FOD1V3RnjmG2CIE4AHRyuL0X1TwgjtCPygaUMCtJ
0rURr8z+9KaO4YacM2NRYjXIw2rrvHSQ9rSa1VNQIkfIR9fgNwbUK1OEPJC5zTTmvmhrCyRFyqsj
5w6VKWyYdH5o8Y8jvx0Yx6moj5PRzK5SOQ0eXqUcPgTn4lYIoNUBCEvl9WvJrltbsoHgyuJKTEXe
wxAims3dDwMZua2361B4Tno4P2hMlPzxh3C9/NOiPcQzz7kYkYHdHo7GAbmwjqIjgk369xm3OSYe
xff9YqUUquPE7YuLImWEtGyReA7dw25+j88X6XIjkNvnViraxzlbqyO1tYQhfFQfyWb5JqYahQrw
fS/pOyKJfOFST1iiDD0raHcA9urCoWM2aGI9ZF0zXKKBvKHjcP2KNI7ZFun278cTYPhDNG4lV1eu
SrWG9j7uE4k/D4m1y5Jws6miVr2qSqjAQh/cep/zIGxxUnYmCSP7tfMcZDAnGvChSaU7okY1o37D
MwAVRt23daINXc+nof/AM4vDkTucq7uSDSHGU/TaJEYwgVDypqN6GF2SHCwzlfG3+17xtJbDidjU
wZLAWziu6EMHwhO8efIL80elvGv7//Avmv7kIvKd6eMn29onQw50GPBeiLHiBuPrN+GhSNoFdKk1
ni49t3d7/wCWoL4pEtAT1O19UXLU4TvRD8BCHITQcA8fEiZqeufslaPK/txjOTym/v2JbGbbOgST
H+fPwIMq/BQIS5kGuvlxwbXl1XJQBk0ZCNQ0mD+9QP/X/XDLnJ9bA8BPOxHYM8BKQHuj03ggW3bt
A1pgLLVsateRDVheKu9As01HrmzpezLB/QS1E3gCb0UnRpt27fhRfGM2txu4D4jM4KBrwU774kt+
1JaIM0h0RvdtT7Pz1WeKywVVAlpwWFe0AKQZ+Ld31ZDxRN2yN4kxjvG1i+rHGayIstk2CRZPEJSm
AzX171ADWW8jkIj2u1TIA5x56GVsf1nzzdU5ZxJSXSm2rqy8/Dg/mP+qmA5kpHmJ6YKnfeSme5y+
kVBukBmYdM5gLsuTXp1bbKIFutMOjjlndOyJE6H7OApp1C01C12RBdaoIqx2s768Tj3jHZMHzwv+
sW7sENDsfXzyaKVu+40x4ycisHKlr0tbaVPHAqPAmaX2jVemRllsXz+HfyeWFTyj36CLuJTBwMze
6nk/FgastG==