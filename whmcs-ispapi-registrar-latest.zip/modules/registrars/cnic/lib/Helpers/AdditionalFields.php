<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvIgLNsPTAvoP1d0NjzR/enQTGm9UZPJbiAUsqCRaCQyd3llbPGwkvvAiJX4s24QKvjNKiaM
6yxv+qucLWQYJwOCN3l3pe9Aicofi5xYdANt0MhAflRF7/yWtC3t0CllWYkc1bWxBJTvWwqzR4gW
YuhO21qKwz+lCFo5sTQHzPdZLrovc0QDsxa01+WHKqurWfH+8AIxzuV0XtW48e+Xp6enYNGUgZWk
JWe2n9/JyiQD6GsUaHwcE3+I6UqKZD8xC3bgHWplfkROXcpeULi3S7srFafuPiGdCoNsec4NEJZ9
KdE88C27jKGS+n3oQYJr1cEBotcz8Q4IkCjHrd/Ikih/lWkKxcPMBndhBav41LgIDoHJPJMMuPHb
y407FwKF0IeJgjM7ikpjZFgYUY3BPESJlQ05B88SVw001bH3vogj2J/7cHXhZUIssshM2ZuVktaS
jf5no8Zzp16s0QaPVeto0Os0RgZ865PxLiL4Yi6wrs7FnO+4gzKceRtMa6+sd44AiAxqsbgSgnUX
W04zu1JgJvbumOob1nRU7wJvHzQztTQqSMc0dpa+Vty3Xd+JpJfaKGsCZrYWFNmlGrOgU2B8E+bC
OOyUXhkER8dasKHQtGvefLADlh5/5S/sW0Yzw+DFzWDZ95mM4DmqbpOq7yKENPeisFV3tvsMNXBk
WUSkucmjgQZKD3egcDRNm6z+UU0HxuosXyP7fWFkvRbkGbd6tlB4S976ZQIrobrNMpwHLy0fWLsy
+gw6Xeph4TorI+UuNSHmsJTceZCAmVu0ehrg4uRiySkQAea7NbsooQr2+yOXqPnAl2rNu86zjx/r
LgnnxWLAOzUSh6mPjhPe1ZfWHwviuJ+55oxXTzHWnbSZyqs7IxsRrzP/N/n26aIK3wQUmvf7UXKf
uKeA6TKHBz8zd0tYbOAaEr5IyQwg3W5t6TYrQZAvR66TD+9PwwvtKZZiY/ILCdvk8lnEmoNRY3E9
X9ecIxudJEYoUYnpls0vbM6EkPuQeDC0u4eABuWChzOSpM7w3cUDJPz3AYf3fshk3k5U04GKYAvS
5gGELfcfyeeGjco8iLF8uOogkArl5q8FeBeUvkiuMMCHDtsgI+f8wUJN3E1SG0fPlwbWMyV0/i9B
68UeEcGQg6oKB86xgemkSmlo76/1UjM27iRvvfD4JdzGD9HoN/zrs9PwwB01aOblgDByYX2TAT9D
GSACM2OrYh1Lgpxajw9QC64170WcY1nRvDEM0cO7VDzFncVemuX2ETRuA+sEXe4+x2iM+lfpI2U+
onLdAhzYKFhR15J7fkig3EGAnmcvAPY+OX4HZogogzuqwoAUwC1Wl9Hm2i/Sd+C9/kiadi1gQOUo
Y/UhFy4fPO/3bt6GI+LJSm/R1FIzyZwS9+Ym9UStmHf5umm07ydfMJil7oQmpau4w8yCV+XcfLEQ
bd2jfQJ86cb1rNTlf0DEXDl5AofMXKuAaglfkcsjJisYSWzeNUrWZ5Rfgu71NGsNnwyvvUEBa054
15aMj1VkdUD3nI0QhwrIQdDDrgLY5q2XEZMFpW1bvHnuxMouwRiUesoG1GZEm6dp9uj8VIAvTjS7
803qAQnJuYBmIpvqTgE9lrMrJKnucA0gZq4H2Kb4YzWkeXfsyLDSrdnVODwtisYR+wEmoNL3PVBr
fCqXJabC4Bqm8o9mxBx5K3zTVV+nSgihGI1mPvp74DJ3clF2yEPfTx+vf+QQd+Yp02YJxLcy0JX3
YugfgzkgHoxptaw7lQFNPUsDFqPDDWthDhyovCb9jp1HCURfqUnVZGTsVNp8gDe4srVXt/xYGd55
5n+4BUSjbyP4MSRQNEQxUgHksYmjERLhl09n2HQsMU1Uq5GOVJ4CtniH1evdDokyuK20a7f11Cte
miQPx1oJCpQdHzhlYaiAihYEPeZOC74M54l0tzYBhb8bzgfPsOlH4PQp3cJ73kXPdj0Xxn9a+D8r
ye5qxmNY8pz3iDXCFlPioZ0JpQcqjQVe22Yh60BNpOuDU5znPgM3Uvyck2VcGY5oSXKBqV2K2Z4M
L/6jHdC0IskwmMv9+QTPoDtNA6xrUQ4rxDv1RKULMgD8mw0JNNhyu7OlCbmvMTtSZD+C6NzWYMkm
2mgNjnGSqhkuwH872Uex4iGoR1JCn1N0U2SLNmnXTyz2IRTwf4DKBibsDeAYosDSZw7MkWjH