<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrFKqgxREoU1ecT7ZT9eca0Xeco+3mqUCEC9wG0MkUKV0T5L+38OERpYn8brSU6DUolBQOY6
tkmCdkyr+0ZyZzPBs7niZWiIWWQI5pMj/zMhrMp/lliMDhvxX/QWq1ax/ADfOMqOrJFWix85wDwA
xAJLSPk/VF1nepYIfDnVlmuLkabH/kL8UTJVT9E4fjDjxCuNDkicO/4IXzrYoDuVqzk6AHz0wdIs
jSOPl53MtRyaDhXVzOpmcuQ/FpktpzmRsJN6QaeCxwRcs8Piw7bR0t1zjJvAV77J9VXuRvmqALUx
oI9PI06ZdN+6sxqk5L+iheqsipbteEdSN/5oY0cp+coHjaJc5km18yfeHIl1gGQRBEKb04AUmM+t
yPBk/pOJsQQvGP/5I+kPZaB6YezRYE6UAuySMLppSSptgU9tgfsuZo3Y1z44IEUhkoEbZi8VpuUr
LRHELtxI32pFcSDGLYEAHjNATq+gPmEn8d+NJ3QKBcmzg1VJIROj+n4YUQezQf8B6O0HggLIYe4R
UblNHObdl8/fdXqn80KgOL9j9AJA5h6phVgznCKuAjaK8rCEaKBNtPOn/XFUY7lxEZlKQkF5N1LC
8pFGCKS4UzFfrVOrP0PcrIKcPxZWpHJP49Dv/UDKnLFScC6FRxFWUacYebTTw3sdcksviJwauO7r
65LifOdXfJrXg/rW3WUTVd65Cvy7ntntvU08fQFLcObP9oxd9SufpmBouXmNRVxLLaBXLctJGKbF
zFQoCutFJEupy2b5plWMPcEnc5BebB7WyUg/U1yCWKkmmK3n7csnxlGg+0UTAcKdoN4u02X5tia9
teUeviaki3iH0IV2lqEEd0ijq/Zv8QAOyn2X4P4N0fzgMRdGUAsZsW3VR8tnfe+LOaibP/6hrQcD
PfNA2h4iQkLQ7c9Revg22zTP0Hxk5aTDtHx1San9yKCmyy0nMQ937tcC34gbMZtTTieLYLk3+9OR
O/DDGX+D3s0qpp5FA9av32aYZ8QgxLilPkVRzCOn6LdUFl65R5Icr4w/J1rcvhny6g3ASyEF7ZQF
csaCcQvMTFgkgDy1clnWaKJMv8vyZX+4+JyYMnpyr7tnYdlw/CTn/Tw8mjyZ06PV21wh5CBndFni
dVx8sUP35ei9LfKT5RPy8nlALdotquE7RxOMETLPjCNeszyes6uoFQJykAyLAXHrzmHJtgipomE6
qNJi8nOpPjv+ihdxnq2cl+8qQF4pFln0DCpk3SEMbqD6paX/yzJxrdcZRnYPDFrdXBf5Y21Asi/5
glogAUa+Lu9eNvWLbzA0ns2cMvXcELVFdxsXjAZDiheevZRjeOxchEP3b+MXudjqWQEEnfMJhEn5
whHmcH7+s6FhwhYkVFPg9oJfb1RmGjdptJsR1MbNQUpftdiDuqSbkL72KoOtFOk7ucCYgIUSYqPm
8xUZUhFR233kkUxwmGjHrKTmcqWc4lIHC9Xhmcbokfmr9OjJbjhd+Q1PcYFxOyI1XlMRiKkAI5vx
dy2RJFrXsIemBo01+nfW9u6XrhLxbYTyqzBwCmA5B1hqt0BWV5//eVf0rnWFUV8qrchDEnvFA0U2
lGz1bKLf780HNuN/mF6sbqS98f+BOJFrZ92njYMgb8sK3ZdND+gpWC2zhaGGZC/5dIfcLpGbCQB9
RUxnV8cFSwZymJNMHUYZ0XSc8PVwUNj+/hJP66FHxMSXDBi60zGClUN5WqPn2pbWNYgrPNh4kNRs
fHwBulsiGCEWDFVJR37ko1DRi0EXtqzh5fk87G7mhXdfvwKjqB2eVJ18LEwxNXpKOc5mK4jaheJp
CKxFAsasvUImLyOf+p3Ame0eZ8KkMTx7nY0/GMbAksAPA44a4BBjfleTU8q2/BomkKLJKw+hlyb1
YrPV+s/3opILXmRTyLvPWJW+NkF/X+8ZasmTuu4sbLSYheSnMc/WXTlQN6mAoOJ7KWJ0xc6h8zYr
i53OheqAw8sv/VDts8SVWtgzZiSnDOep0u7XOTQCUae1Fhut83ccjKPvHU40+4BkwrCHFTZYEuHa
QkErSemuuaVWH/oJeeTp3fWXwsRP0nhaA6GkGwXW6XBEAZOHWfqrHw+BdffGD8696a9RMsBqXkTs
e8qmjFfw5q6BXSRbnMYsGCF3b79E/20UA46FwQKLaa42GpwS7affZ52VYxRVNJY12Zs/FSmuJG==