<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrvtPFKxtbpxmiJnrlvC9noewhffOXvY9OouR7x9XO/j1ZV7mTtBoacJbX6ynuCKy5b+fz4t
zva9ousfq/qUT9LsRkVTfxwSg3t0aLYuwGKj9QV06Q41dzYMOPUmxrh9RShDPaY+bPMxvYZr0aU4
QOqViRrJoGNVDwBjgz0Wo96i3AZ+1ddYA5swfWcKAemwwSc7v7U/bZsdIygUwjAHS5cwq+NEV1bk
yUi+vb2NrJDEL+azI/SwQj8ziULN5gXNpIie3E+cvjY6REXvMmDmVRK+IgToC1deaLwfQ6Ygziao
yUSX8+trl0CqV/pbUmxK3w4zp4OIW4qxuwGCFJ90YeHi6XrKBdIoWRTFLp9J+i+jZqWaQQDrETPc
ZDs2OWeev1+JTunLBxsvPnEIdJ2vYyiWEtrB3+sgiHhYhMJqyitOGLEmXUEoD4eSbcEx2SV570es
NufTHLTyzPQnDvAbzCnpdO/qReEiK8EsxFZmdlmz8db8xf439B28NYvMgWNBGrKNzUxWqOlzNp/M
6sP45Sq7ra7qaqbEMA6CKU/gydVzqAFAwaypueL+/8Yx4Qwd8lBlffUOkLSnzGRx2hKMKsAOAhTH
i5xqrOiEgciMpTlcsFAnCiMFb4VG901r4vYRZfwmS22aIy1TYIbYrsvxkK7SWRuJOzosUvAEllFf
g+A6YX6uYCcorHUJ+tvortN5nkn4Sl4mUroMy89srjC++Hiqk8y0MByjMhqIDbHdok2pvrFANnvB
ZQ5p3Oz0N0b4SE9Gz4fzqkrSZUK5isE9+cQSkwxsNJk4y7E1olN414nF7FVD5a+BFwgZ/+QBMu6b
Xcswa3bhIyU4jVkZR1hPCTnVrbyRl97sdV9n7IIY6iexagFWHQI/QGPxjIfXUyjxTmSRARPwfYY9
TLGoiBb1krC1rnU+UYgxth1wtcYrdYBRa4BHABhTpk8sf+X6qvYuxdtfoIg+zwjIZfQCulD2qWwi
VrVqEgRgenEFFIBkAl/TpGF9vxBhFba08/V9prlrg3P55A4cGVc4Fz/KosrvW7wabvAT+dzf67IP
Yo/TRizossnGWiSnGfczzJX4DvSNZMhIwgNyGDKzTfFmmkYF28f+SPOXf83gmRRVJLNcoRDvf7i+
EH+yDtlbasbVKI6VASgh7zg6g3DqgU13l5v5Yr4za9l1ueflqorMWhGMl24q406AGB2FjU1nUmh7
ko44c18scaEx55tCpTkCEiFNJqVo8+XmBO4pN5W5PvPuJfW26fU+kF19tj95LKGKPdywx87FsndO
0IM4eebky+Ro5ZcXaXdh3oQFjZ/17BD0Ez7XyVCBRZY9Ic+QS4JUv9KaMQ+GLfdXyaud6v74ribG
5tendIT8pnUjTy1riMyzbSLdK9zSV+52jGW+G5p9ElAGAvOr/MaSBFAOwGI7A9XpZe4tWTcANNYj
ZljFnkH/d+bueSdWb1pm6ekPXEebEZ7J6Ju9x6vgVgYto22jB7XpYsXFlfGcda0PmfifRNw9v9Sj
Ome7d3wgCUh7nVlK1wrhR/eVs1Q0yZA5YqfgnK2sM5qs3EyN12SLxoYSlEfuKi2WXpETQy2q+6Lb
X9QRb8MztOgy+S6ziNckYQUyJBtXsg3ziUMjd8ApRTpJpRLo/cwDBPlCRPo2NftOSIQbYmV1TYv/
l/iXSMjlN4PIay/TebkoEJfefLV/JtDyeb0X4yq3E9DGYIB0OEIJhQ8lGs1d9OOFLRornSrbQL+W
+9joEEU8gULLwkX6BgwcimI+RaT4Ljjm9iWVX/Ej7+KlVdZHfDgTeZqwM81LgkMU7QEi7bVNS3x8
AXZKyoSAmHcaqfUHaHFvPsp6ahs/R+3zMKD8TtwYdPzOKDKExPmpPNbMJSI5NeZ4ZFcu4+UsTt3g
ct2w04XzAwUuQN7OurXf4dK4o0GvIUm5b2K2/zP/K1UhVuW9P8MU/ac9FtZ4EvLOnHVpGBWHyX/H
LoGZjAp+j5D21Fv9kUG0ZQQyEEyz4Jllx+50YaELozgsA92T0Fxgh8V0qC4S8HMIS8MqNJ1M2JYO
txMLie2Wd6j0tSFA2C4WKZSSZNyg2F/7pRcOEFB12rVC2AfkZ+4203wXdgaB63Dv7emm+OpUg8Mj
/guQG3NFPQuhyMInMOow+VgD15NlblxcoRIYbeDnjzXzN1jdiGW1gnmD6DOihF3FTwFC1yVjjmDC
NTA6se7nqdTFjc9OjP7YprC=