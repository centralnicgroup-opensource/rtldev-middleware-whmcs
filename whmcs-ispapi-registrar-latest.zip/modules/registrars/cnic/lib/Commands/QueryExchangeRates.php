<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuuqSFGF6qdyreVbrrJAXEy5X2TEcutMVh2ubNTzDEV5HHF9+Y8lrtVyO7EEtuLxyuSV5e5A
VlXXpLwl6RaN+2Tr7WklDGHSdKVSnQD1uXepqQ2nxcLHZL20nBxoktGdeUch0UfMmxbyxU4j27U4
x5VbiSQE4QZCcaaIyQXnrI1/QT4w6te+AGZxwYm4sSCOpHqqKkUPl3Q8kIvC86F0tvqQVRsFfMgV
3CK6DVf74wd8JeThWGnkFuTknpNtMPucztnK3E+cvjY6REXvMmDmVRK+IZjgXRESshuVxF2lqyaI
t0SFOe+X/yOuJFPlKvN4SodEHdab8WfPj5I5i8s4xh7bniCXtdwXPQ44VsXn30Mv/SQvEl6nWXqT
jcUoy3SiBQZkXmSiKmHDwCdVrnZ/aAXK7KKWS3cLwTSDxzHD9TuwKXw3K7+8Z/SQdCiurGsfGYRU
M5vKU10YuK4+unLr7zzwP2x1UGgPG2cGL+sUBAsVLKu7kcWN45/HhZGme1i2iOsJYDbxquD1fuvV
GCJcvEeWCetCDmUamZ8pchvKwsVPjMvyM/Ybas+iJK779AWGIydeELuhDfmIo+6nc64E5FIUWuWL
ovREw/yWxkmAg3AJtcPeZMMf9HwVBt7s1mxL2/o3Our+R7t/Br7D0MJynpK8/JZ7HM/z039wcOHy
TS2EmqPZJHyAXq6+HtBLwY8JMPsy34qA0Vaic2N1RSgIR1+u+NyBiSi7ZK/BOYL9HXEadR+lhTib
a32x32CzPCRIou4LTp2QNa0qRXuCxFD7VnQTU5sR4rc8j1Kq4k9p80P/UMsG35+5DH1qWXmHg6jm
cVf2+b3O/PzLvzziD2NHnkMtn5yKsWB3zq0NUyYpXnPXq3qGqS0cVWISJdQHHZbciUNiVbDMpP9j
J3cXzQ3zmN3JZG+PBYQDyE9m77vWJCOhe7ljd8rQOiFKE+ezygu8v2wdL98SPeiQgq2FnKpb3KTL
tEtPCWZWNF/nS1DOJR76FIAVpsDAz/FjE8PXM9CWNr4F7sBpLuJNbTUBk8vEpoxdz0FBkh9necSu
k/zR5U6AE3jhqD/hwFN9efHLBJxxiVD29m9ftaZb+u+yr4mQINpn3leQsn5/mf+rssgHxcRnoxEU
957R1Thps5xlcLesJm7tfvU6VeSLnofhm3hPcbqtn4nLQkFgO6f+8kza7S0S537/fkkUtBXC24YU
S5T/dafjhYufxonKSmQkG0ZHsZcytOxZpB6OKJgXD9uFZmSJEMWBKIxrnvhg15n0N/v6p9i2bShm
+zzErY9vU7Uyv0p4piNQZr8LyPcgXypATMaZUx2AU8Vx8H1X/qTea0vESf2RggdqJiouWiv5Gvl+
xPnKjoH5Q5gmtU40cl8HEfgYeXt8OvQ2/3rldH6peQ3UZcA1244Ld4m9XuLdXCcDZezyobpaxAKC
FlgDHWBhOGL7reqiKIFuSynzEx1G1nCnmWshTiAlWdmS2EtccYa8qrOxeiKVlhZp5xh4m47vvxYm
QK0r42uu6V4AC9sEzZT6RxLjUksLncw/WLNpiAbdno2Vdr/pDAcLNHB3UWDEFz5bDWJQc0dsVWeL
6GhrwTLeJ0zNIU7c53vwP0WVpmFREuhOQQWdpP3dtgIkkkJhCqN8Xe4RX0EDK7qVyDz5o86JH55A
5VwbzNe1Z1p/bCvDq/pTjjhLnvY8Lx4KrEcqcnh0fgeBWqOd9wtFHeUzuX0kneLx0ExWo+EpDV5p
Yomvm868Y737M32ckx7g75IX5D9solN7fGm93nhACTROguC+E1stGOZLFxCDmM5FwxZeNubFauOV
sfmulYCMBca0HP4XcLhKebAxM2oe1kpCm0gJuau9dzPoDGlfB39e0KAAv2g+RXUWY4opwPf4O/oN
fUgogLUAr/+j1F6KhlShGSYdLGRh2FCBZrT91gownzjWK36e/JgL2kTm3SCu7tHVyYtpg4MiEn89
XuocIyttoolz4WI/tmLCUQuLYKOoEAjG61es9xlQ0LHRcoihFJqb605qq7pJN0seTxC4iG5wSQhj
LIS7nOa9m9IVJQEejWl+WaL0UwdyO6Juz7YhSWPKrRpkRJJnJrsf8IUmdKeWb7PUnXvuNcOCPo50
nkGRxdRxicRnxY0W8n0rdzt1S6jweg15HddXj4axZtvRUfTq/kHr6BOmDiyN2IZ9PMGjh4qvNiMj
076NdHEq1bX5uLrHTypyM3R/+G23KWh32Hr1w1tlPMeqRJZV6w/bkkcSLrDOIkjCTC+co2zGIu8J
kqop4RoB/cHrurdzNegpoh1grs5lOkssaEABOG==