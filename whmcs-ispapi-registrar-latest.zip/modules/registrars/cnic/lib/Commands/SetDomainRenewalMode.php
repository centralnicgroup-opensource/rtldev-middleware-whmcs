<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsqBtjkNsY8SRiTB+2ncvQYPkDAaTd9arwYuQYnTBCZPDEH8DrN73IZnASg94/Rcd9s98Tz1
vnQgi2KRIJPkBk+34FOvVGzKTapigww5Kuq7ZGGPBHosFxEcS3BLb7iSc3AM/ansIdR5k8kB+o2P
rdUyId5I4EPlr723fSRP7vfKj1bQJwZMC4kGDBGeTVKZkqchpzd/l0eCjQGW4VOGyyKL5HcIJJhS
pokfPoTn0u9Jjhqqmnucb5zlHXD32TN4TXe83E+cvjY6REXvMmDmVRK+IWfa/MD6Tb2tkMKzvybI
NYWt/s7ouZTc/3NLVg8GmbCFjbGIOAQQxEM8Rn736cq+twO7SRKZbck6e76d73l39JMYnXU+u/jM
RcikpMv/3pMT9DpoXG/kWPIkXg4KvbnorsyD4YwezXbp4Au5yipco7jaBV+j2vXxIPE156knFdBz
stvFcSC3bfKKY1dxYfjeSUW5lopKgSa19hk5/QkHsp7uXGCdVOtHdwjof6UkDzqtBNeJBZ1UTd+w
Fp5bC/CKxOfduqZhSL3yK3uox8BD2CwGZ0WWTrMGLrfWiTcPvG3WGUOouURKX2031ExzfrZtFIVf
l7y2tkbQtC09Vc7yEB5zvXdVxyIJ5pqbQZak5znGjNdgk9V/MTqlkNq6DUHcKJ63n5XPIm5pLh2J
3G5VWNaSJ810vSUC2hPfnEiZEivP9aMldzCpCSkyM6eH88wrgpguwaIdE/2IMp/EWhXcGoZAuvLy
DSDme2Qs2zYLLmdblNsc4RYBJBVV0gaDFobW/sSa3SHkhayHuWYCWXxTqGtT9RY1Zip1AXfxTkvB
lNkXSa68vBYSoIIvVUU/hSi0Ro/LpdjcpdH87pYdpVuEvw2NZjpOjE/9/pg3Ik5Gt8KE5T1uoTDW
XsfKnnfIxQXNDBZPGSPLLZhWdYDxg5XQ0Fk1EiVf6XfkJH6aHlJxcID75BDwPnd/cRfePRAg/fAG
CW8S71nKTgYiFK6QmU/xhKb6/EcQMovnFiURDAvwA6u6ASBX8hSTT14j5Dh6qgFUueP2MToqO4gE
ZPMM7s7Kk10IKHCBdn4jjX+KKaGjU6ksAutD1BJcHEbZrun/8mxaNlHocStac1drLKIEppzACfPC
IdkOYQdF6cLIM+qh/w8zQXOmhr4xgO2xnxTFm61bMznbwWmDvVHTXvSNAX2d1ViGIBpfnMYh1Qet
cIHh1nUM3HzM3HUZj4VLp6eDY8tBpCqlpPZdBJbuACXJiulsUzbSR8V1BQblM7ceTlXP3OXf2Ntp
yVuNb/qQz4OQnS4SZOLqMaV3wcvoED2H5wLKtvBXy8Qal0E/vhz6kNnLPXRrrl6SzEmnuVz0qRPi
/NEee8rxoSjWZ9hOn9xapF4APc/ngUDfnprYztPLe6fay88+VuwDFu6qGq+FHEjgfeSCVFVkKZyH
Mcp9942uIE+oSilYfENoZToain2n1CqpOuTGvhihpczhl/Sjg9TM6QLQS0fEjMPLklSktgYQmmaa
ywBQC44BaytKVbSGJ3QKmCem9qg/Ndi9IieGX+a9P4PSdyXuXnqv9roPXOfyeZgL7Z3TUM+xXgLa
HUjXIbv0Z15UzuqSsHzbbWEDaiXBb64Bkt5oNYdkzkOpLx0aqEQbt+R7if00jYZGBuSDkIqW8Sln
JoOwjEbW5yzVPjf+yZyiCqAvoD6e86JqPpLPeqibnmTyGGrAf0IdTkeXdxi271rx/TFIOXCvViBB
pkkVYpD0YWZevdIGyBOQrdNnkQ4S8WfeiAkxnUOZLy1rY05YfMtkXCbj0gmlqIUfQBnZZWSaCAge
692Cj4Cl5Kb6C1nB0vDwMP5vnjWHd09vxjRGYYZw06n1QyvGRHu1BAYfih7vZaUJuAwc2BsLjOZz
ZJ34chuP1DjlKu0P57pGNldiKqKuyqv3Z2+KJx8FUEghVECto2tOU8jIjbTGsjySTMozn1z7rpe8
GI2xjCesiW3lu1wlTNt/urx+eh3BgkAPAW0rgFUWTJI9wiRFcEO3DF0sq7LtDvsANFzeofO3qvCB
PIY8GwY4Bb3mnuFwml9MeaBkiJPGi7/LnOjr/32ByHvbwMeNO4nR0HpXyTPgyYatLhC6O8YFPpDt
elPaBgIXWluffldqSd0tYzQZpQYe07iUv4IXxVOj9XqFoh2HOYV3B1RY1ifIsJGRKsG/M4logOLW
XSu83TButg9Pa/r6RbZE9eoVoEC9eYMkL0A7t6lcuZWbJgddRcXGIKp3ajloWJrp4Nh/SXb5+cZ+
6w/nWMv/5w6DFcgBAzNIPzL66B0KUvVbl8oYPZ/JCkpUqpLjb8uYmBSfoX5Mizg6ZzHqdfCsUxAf
wBBp2wFiOJVKFl/W+Rh98wTNepjdCgD50LB7yDygpqtHSISsszsAERIEiI+5l8xdrsm8oPx38OcZ
PgfWozBrlj20fgI4BTENXu8Rp7izTO2Xh3YrGmZ8GmgRDbP5eecQMZaw3LNCST8YTek/4+A3dRal
KvDSA3Y9m5yMubn054w93NOTZEK45GcK18f2tmaVzD17Dl9G5nZZkUX3gxIB+cWmzlEWYbeLiat+
GRUFWwDp7DsF5uMvSY3IigPIy85gEs1xIE4ELfjSrROIhIw76f8MFPDdHsY9cLNUHJxqsF52CrQr
oA0kTpImZXmbVc0bu0isxCDw/F8A0RahPJrER0GDmmshPbqmuoeMsuLSmDx5d2Z3cNPstLCRgKON
t+rBI8y1MRWkRy5YYViTYbXwwaLfUSVkik+NDIO=