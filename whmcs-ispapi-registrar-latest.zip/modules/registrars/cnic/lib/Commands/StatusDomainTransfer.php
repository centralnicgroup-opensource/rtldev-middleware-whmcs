<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoRYBlz3vMQJyF0ikznV8tMf8qyvXfJWr/g0KV7zsZLpnvQKR6p7gBXOhD6deMOFY+G3X2LE
Ccua6KJoZtku3Kn/DhWzAnJW7vUJsmtQaWe9/zCV5xc5fj5ILMPkeNsZEl38OUsv5pyptJfAelj6
WvS2Md+JEYqegFOJmFxT1jMgrM+918L0P/fNkgVr9y7m5lkIOZYpHN218mcrDwZDM/SZpXVR/bUG
dd0Fluf8T8R9y6a4LrJJw1r6EA9AJSBBxkAkO0plfkROXcpeULi3S7srFagGQsMrfGzQgvIYVst9
Gk76PF+EsvlJQklXZlPo9zYnqpULwIFQ5hqtyPrkpwBbheE3med8/yMgCZjwMSbZ/dR27PMr2ve7
dmgXdLMZcRJ4szLxXU57mkYFOrHJl4p2IMFVSch6A0Qcy/+2CiocQzLW/wBVC8DE1Ig+0apybQA3
UGOwFLDLIWD6YB13n5AdVF1pl7JlemCpDWmxSsaweBHmjYNcn1yM8wmIiLOv9ZKWCk0vzNaQ7Wgt
6dBWAPFt9+u8mXra3z7YrZqEaN/SC+5BzL5DuLVNKCwhslRuyvpcc2eQA5DJ6+s5ms0ehWvlMrYu
Y6gqKIYB4Z3VqZ7qjG5tvkbHYuYIw7+WiAahQ/aBcS1ITtS4Q0Vc6lDZPrdYNuDcXu5a6mMWDZGV
W7IBvvTUtFmvnJtYI2djop5/Tk+h8pkgpOBVA+CDUUWsqEcQW8Yw05ddyBm0M7O2LwIxQ/OrVCDI
pRbG9zY1UnfF+Z1Ifz38vX3Ql5XqFxTLf3i5BxTWBetSIj6bCs0fafrJJBmjodIAZxL7mp/Vq0Mz
dFD9a4SZNO6b4pNjXTKbhSAEybwqUVWlZdGaO3lGcZJi7Lb0HChnjcdbr+q/mI3f0tg+mBxN/Ko6
HdXKSWkJv3ewGmi3AMIZJWE0r2dlQACfKulizcsM1bv5zYshUx0o+k5TO0BIH5NYz3vtQ6EcdPGL
g2bEAEa/7/PUAax/I7EsC0kxncj+F/IkfwWPnoyXv7YZkjyDrFOZ9HNC2qUA2KUg8ry87JSWD4PA
kwCGZARX07tXBzMY5FPTzbVzc+xdl/aRv8x7doxikyK8adsRJPMcRm2Fq2r5b5hvbK4B+Y96h+aX
wLwoJo4whRZPPQpOE56g7Z8dK5GYvXd8cbT07oLjR/oUbLIzudPchw7nt9VeBbjiWhu+S7atLQdK
1OgfRvfcUoqorUufi08ntL3V+R+6+FmPJx6cixwsUyP3rc1TcmOEl5mBWuHgbDNbuOqhwVFCN00H
9FTvX6AycHkyzFtJMzmB/7Dv77KKiG8E+LoV9/iiIrlErsO6NTt8GF/GIi0W7U6TSnEwl8YxzYHM
d3SeLGjY6aIanasCTrLaP6Qcgwy/HuPSgUzJiUMdQxSj7YfibCCnIpBL0U+l6WEbzChPcehd2hGL
kdNIjDit4pc4waMv1fAwujAOgo7fz8wfvw3j9PEMLhk0N/S37VUCzvuE/aqQzRDraWXZvMquJm63
D1Fud6nikrLK5tZuBq41rnVWlqzRtbXLdqF8bhhNtdFW00GDs4aZKL33da3ieEYtw/Vi5vUpS93z
Go1EqVd7EWTF7I+Ga8khT5g4eL9fwvaIfVowt/+FWjXsnCbN1R8lQg+zp1KCltZHggOj6d3ezOB8
BcxrpdtRbluMFdeW/mFlrKsKvdlA0Fq1wHJHuYbem/KfxyeiSzwWNRmsgkJeh508qc1QIpyz2jgS
zgNoYvpj+nBgVYVvIzq3GCKZiDRrVzaJfqeC0tEwt4jJtpNpVw18VUO98YNHeXnAVAwUd1RKhAKl
tPAdh+ncRRZNDLVasU8bPdtaGcTTm7B9krIHphjV/lr/ht4YD7zgyHI0Umgn9otoR2wm3UGFCR7h
xPubLISkkh4vCUplFsSknkczJYzBCQT9nEDz5YVZtsrJRH7rHSuYw4AJqTjjAAs5F/Oj/6DA07cW
h6W7UxA3iheOa6F2B8zyIOS3HarB+67bDDhEf5xwSiWN91GnOfiHjX7/wUX06YbkINN7zDj0O1Bq
UNnwLDfzkLd260GoRM/wMnxJ+IAUFRAeA/KaR6qQWsdMRKmTQKnS4BGUSCKb18otaYVDN+XE2x/t
FYxV/1riNSbWvKZWAUA3/UavGsTXmNnM9fHDSsjng4qvMuAhYjnF40c9ss0R0fFQvi5KFp3UlPxF
hFjrV97mWHb2H0MXILxskVrj31msL8Ubtuon2D+hBq6s9mzIHKrjaIVVxZDD2XSMxH2WHa1PUHtT
WSHsHcC13b9p2TRtCj11iQEi9rXomxGT1Nzbpnd518YxRz4CKNghf6WuROMg6fXzoOgZ/6b+s79u
Xs3KNJHEby0lNa7nBV+kVaeq5+4EfBbF8jyn5eOglDRYBFWhfWeIYwY4qzaMUGzZ05/lt1xCv2BJ
c0676k2EiA8ESdWrurD1e7Lz5/YwqL9wgIZJ2bTbYwl5r7xR6NF1suHWgN9nS3+HyuegKG233A9W
/7yjTjWMpd9d04uOrWNFZEBoMVyILYt8XkfG0N5KligcNpBTHb+w+aWzH7nJEFlegfXqPwYGCO5v
PJg9hx81xmvXyeSHH5FroV18MoRZ+EY9slClozrOky+djqqQGF1k9ofWjV5TsGkNlFvy0op00nT2
GJ93Ix7+7/eWn/XzvhsB3suvCSBZ4ASnrl0gTHLiTPfl2qgTUth4n+Ki/w0jzhGupiROrXdoBqYg
qCxYf7RKxN6yjGU8FUi2ZHqTQMQaVUIoIDr1rWeOVkWPDYGMVpG0td022t+mZpSzh0X6JfQg0bnZ
rZ01Iq2WlvM9ntL8wug8fs4mIL3Er6P/Ul3G7nd+tezpkK5GsgaXbMJXgrhcfhqaesNzd5IQrI+h
lvDRaFtejOjQqCDjEAtyeNeV8kmk89K265FNJCKOKYg/Tz0nK/8QndxI6IjlOPp+5T0r/TmWliLE
cwGitCHK5DAmQdEV0QKZ8a6thsjpdQUYvo+MyAE5IStn62Nb1EHwU01NpFbANXum1JWkcSCBQMM8
C1nesfCpS7QWYYiK2YfGGcoRw2AaqijBxrQCllSfQgUo7oKIn78PSX8kHRKg+UXvQ8e7nIh8LctB
OP5PUUvPvHzvAhlEFZ7ZZWmJlE/fIuK/9sg7ZbhL3epeiPvAdOItlomIOW==