<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnKjX870ytosdPyHeejIoY/9OIjPfddFvV4eewEbPIzTYteSgXh1dYkGc7x/EX3qRGWoUmu6
/9sf4QIri/B/wX6KX8QFkpAM9bVi9L/SMMHYpxoJRmZY7IdXA4K7EFZT2PA8uIqzd8uh716+mrVk
ZNh7hpgXsHwnL5UjD1FN4w+FSU1Dv0MeoY320CiFTOGC2Q8ovcEOLPLP1lfUCn94vzC8Ljqrz9/C
5/ioyb9WU4vLhq5x2P+XZdh2HoWGZaWQqm//a0plfkROXcpeULi3S7srFaf5PQo5FjO9QVtDEOx9
Kfk8SqS9/3xcUeIelLBHww+aKlqE+6k98zu2qRfHAb2HR8SN+oA66BSp3ZFaej44gwgiPVthG9vH
83tXU5+wNOmhj1fX2Ol2sXkiKfCw5RSVdRwRqxjW18AX3In/TOnsvaSaDQ2aWXa73h5d5n3Gxc+i
UXtYjhf0yrM3SMhNl8xL8gEPBQjSAX4jrHkxCmzA+SjuJ7ZHzi6ofwUeL8c3p2PMpMF9Clw23lfc
K5TLzJyCBNs66I2iH5H4Xnf1YgX/bWGw2TVSP3vNz0X4yoRjw7MYqRSm1kmM3uab6/hRtVnU2izP
3e7E1pfXIZGMI0q2ov2jwQu++gymmiu4xjSdyvrfA7TqkHK8/theItJ7haWsFRRlb4tu/iKxGnA8
zq6CDmoYICsoC6ML3HW7n5R3NnV+VzxhFd37EE7IIimkDWxm+6bKZP2ER2g3V8xmI1OGHy0MG3Ph
zJl6hAGiwhNtUDwEdrEiDXGNFb77LlreUABXkkVF6oFlwB5qSN+Vl3ODXlDupLVYRbF2pHU4vKrc
v0PUQcXyubCa1P1gdp1gFlNE2B+UgbqA0WgKwtFiD6zBnLQzMx8AoZXfPqlqlsaXC0Q1G+gvtHDg
2fQRRuVeoj17E+SwznzyMconrwXebMn3Py26TbqElv2U+wAHXQSQIFTYSL2CEqzbI2Dh3fYRJwXu
rdapFjp7r5HTcyiWNcziy0STJAqOT8W+5r9L8IQr3QeOzG9IIhPXsaWthsUG7Td6kgFkgyX5ZGQi
IAuLRUPws6pOxzT5bXgZaCnJZWthdOh2O1AVcAyeqmdO0gHWTRLQnvVfi43Bb6uY72Mmm8aLD5nd
1Q6sfBP3iOh+KPaTZZbaMUqtrxU2ls64KNx6XI7nGFM4WYEmxK1oABST97+zwgqCbxkN7P/fZFsn
Zn2GX0KKX6wzwo6VU3V7S+8WKSZa1WCVMYzw+dCwkjZu5LZr+wZ36eSabtgNTpZ14TNtA5ORM6Zz
T+YoUDw7w3dmUQtAgfF2UiivHce+CyaUZXJvw3gpFJxDgDcn5MIQgMjW4A6+p5ceSv79tDcu/kX+
AjsfA4M7Kqo9p9azbmuSt/VaizY1+HzOmLfC5b+NzI959BOExw0cSngCQwxPagM4iUS5fZiZ5v2I
kFOQ/u+rSvXSxYEWIO2qBRUQ4xLCsvQO5AmBtW1S4Om1MNip/tEctxO8NqbUg+bKsr27SdhVPaYE
scx2bU0xjQvTXkpF/68+YMM92iu4GBIOu8EGVW2NOGootv2J6LtaftLxDkdkgSXVlx6FmuOPw73B
K6KorupQtAd9x6btyzTlTGlqhHezitXrJbACHVMyOrWax6VuGxzGVWH4DcEDAO4eqsvfRgrzA6D6
ZAT80wZg8Oqf1NlvBUn07J9aUemaeVJ/bC8h3rxSfUlvo/zsjJ7W1OPlU3VPwqLNveZOJM9xTUyo
EeBr7/KIQz+YMVsQxxr9JllbEfMuy+ikAF0KYBzAeyc6wXW5XWVDVooQf9JYaisNJAGdjI9giy9t
dNdJyHH/YoagK1rPTb0AFVQZm4LaUlVIzZhVXFrO7lEnAOckjdau/B/fpf3iYq7Y9bA1rbm81oat
ZgSoaAVoLecp