<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtFBN9kVcwNSPWR9k8cVOkNJjStK0aGziyKDOKVgNo8NxDOGb/BebuMge9pdUJ2azAepjwn0
l2ExyEaD0qAq+C6bjk/cTUm1eZFbkK3UnwYwbaNMi86rvm2G/4z5sGIrJNGt0379aHCdsgXDIaZ3
gsCMCvmXprg2B2s5kflJYJyGndUsicaN1zhq48p6d0PhnM/Yw5xSpn210B3tqBys5qCJ0D7gzkR9
e1N8Ocrh92v8fCNfnPN68AokMpYxkHV40/B3JGplfkROXcpeULi3S7srFaffRyiloQ/+j7iJrj39
KjJ61F+olFUh+J2/Lua22WAFo7oL+GoiRlSQlLjMaXgkQGo7wr9fTeED0an+b402XpKJx8Kmu41k
vrFwmaJDqqrYx7VT47MgwOqt2SpaM0H+Gq3dBgb1eDQ/2/ML+NBx1tMDCEC26XvpyrEiJlG9XA3u
kHjeAJCgUelgPhhFka6gdkuO0enWeorcTGcX9D2UxwXMl6o8PP5bWh2mYxPmvoEXs5vWIrTYcUlI
H5AIHTQengdx0fTrjanVSN+2+JtS5wSwSxtEGCn7o/OrhPZFUAQCxXfnxnIYgukUeWyrl68VLyAK
8k/OrN5P9W9btKjQSr0FQKfkwLbAa9xHNL2HS7lSSsy1mKwAu2DCc9bg6q2/oSy2dqImASLzevUm
ud6NzSpj81RlgGicymtFid/U7Pm7Oqd+l+qSH/aHG5BeqbIYv4Ecp8tlvKFxTLakXZ5SKdD2sTyS
lC8/iHbjLSx7ZjBfHLUWeLZK/YWNCKC6HYF2TYSRkGXr/ou5IHcFxJ0+RO7wHnpQ/iM+8S6WgRdx
gZWlGPWS6482U70G20JFiXdMbHwQjZj1Ck67YIKwOOMGWbCr0zbdtB96hLZL70Em0UJZXgwXijc1
OoWz1d3Diy2xWx1OfGYBdG1fbKxRs/KXml59qa68PdiiPABDw1bDzbPW1QSOkwGs4yxZ8lcD/9ss
huLK6YkxuKWX2nO5HqySEbij6YD/eVHo6YZWeczQgys6ym/uRqyDjcVCY3LsDxzL8iXNervr5xWI
sKNySD5IubiGhzLVNCZu6kARYG0Tz9zRhyiU9etyLJNxGlYLf7O8/LSxmd+Mb3cH54XF7qzjBFvR
8er1U8WWXc61vvxgECPgBl9lHsyjtqUz7O7ohftMWM1C88VvKg/Z8VT5NyQis/L5SOaP3UFUD+3+
voNgaPGc8OGxgBZrhCZ1YIj0uHugkC+X5xvOf3s013a6dPCTTKeJR/yHTVHlepQU8H6IS9HwekuD
joJbz5PQUrb9rLCq8ZrELOpt7kvmqfcTFXEgKVqic+0q6GvadKQenOhYqYDJG+21amwNJBOwBzoG
sVBK3eGMhfe8tYhfYWDMum6swtwTBiZ7txfrMXmMdCYMqoCgTv819LVU1MNwyQDtk1v70dWC+ZON
sFwKUbBwSIEJRpQJ4snHztV63nZO/j8Q7v5M5te226AX8MIx0HfhC+W3axkjxFC+JL5QVv395/6H
lL3OLwOtuYPW2cBwSgfqttmVG9daIQkCEeeenY0DjLKhxZJ8sUDlOuCa5M53BHjKbECgcYJiL33S
RgEgSfLkmYHzg7UORjYp6IyUMD+77LOYcNj3pAKzMyNk4C3cDBNKQ6AEMOFw0Hu7LIAl5AWAHOHC
cyHgiz+KiNMWpoC4X8ZjNFwSe01la+l2MohSq7jU5I2WXHgD08NCSdmJSNnY77VTgnjDLBM9DqeG
GH8viFwFLZCgLvmoxzY356SzObK9s1Ba8xGQfcCuoTzJq8XdRe0H4BSKsibxzS+TN/4kolT5EoVv
mwEuHM3eYKfL30Zn8qmzjxbYIqpelz7oVbVf1OM6+2fBrncpXzNIPe5d9SH3Cm8tAJAZVX1EiezB
VIqro87+tSSvGLRWuu3xDl8EC7gIWnjVVj5OQgpoLaP53ruHrnKXBx0QmoeQ4aMTr6azeWbXjp1p
tzIm/V5lPEKftGqux+jSH/1xTgoV481JVoj5DiWI+OzHkVKscNOoEVpUpMgeeY9cBmGlkBE+bn//
uUs9yQBJRkOd15qK5f8lorDTeafKmLGzExRNl6lNRugJN9kreB3sdorwH3kkAVUkFkWAexuvdpHi
973yhIczzAEza39klzfb7HnR26Uex96eZEEC6Jsyslr2LAvIE9Qwq9taxtxcZURb5tXMPpXNdnEi
9SBkJFSUQJj1GrffNzxdV+Bx97ZOy8axRdq1OrcSQCLICTKiH7HRxNIRDHwFQ2w2364XScYmTIxt
jbClREVJ6jLFP1mYIvUR1TgRc3vNTo6u1/MGh0Y29roVdIV098maBN8QbBPAT8QMOFOH2p4E0xgR
Xd/aOBaDI8uun33fnCTb5UrfpKZaCn1uVfYUPeJp+Ud2WJluiBj2FkhxFsQ7j1ye42NmhKhMr3we
Vrg9jT6rN2Mv+nEqh8Xa8yoXpWjZ8X0JnaPrFu+JtN60ATE/qfOizUYeFMmdoCB01e+7bRqlCwjr
Pq0gOml8q91o38Thjv0tepx/5uhpJoISxcpID8fBiX7lzbUvNPoSorgQ3N4HjDY6JWPwdC7Pxeqx
oxTihGmU7Tx4nOLtnZfyXz/uOSjmhTKQOdPEDxntMlUxVlA2nrAgxZdSKSEpFRwc7r+oa6v6RaQQ
0I7seLGWcgpUoHgS24J6rAA1QLyBBvNUcBZLvvG0aUKZhCcEqAGHJ+wsrOWQcbgcTt2VzVgrN7PL
oCKm/zD8X3TYzBnUUydR2OPoVnUbjdBKyK/njXFwM9lzEcDebWA1imJNq+mi1DzkRmV3cLihHk6U
sui1VUGs9I0eQN0c82bWwx+niOtJ+eK7MAhgieQ+sot3RKxzYRb0aRohdAU9Q6QtGUvOah6jNv+1
LTjo9SJ68uiQtd8fR/ORUda2fNDDx9k8KZZ4Xf7BtZbYdNeigz5ihoJXIOR6b+6UFhkmY6k1j/gd
sTEWld70l1AXdksaVFVl/rcirVTX28RIGcXFztAyqC0PMROfguq7E0LK8oYXVDg8hrl+YXfbP4Tw
TsL3NBiaTpclqGQOhX0Rm5VYka3NKkO2HN249LMj9ti1BQGf0tQr