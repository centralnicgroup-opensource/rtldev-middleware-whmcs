<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrfvBeCDufAqoB2xe7/10Wk8bFc7nj2ipBQuNZCSVY3fDut8wpS8g2UiQ18spDKHGtGczsZ0
+yCvlxpq13EuFbWTLtk5oxUUm4Ko/UevzGQda5Ub0S+/kYjuGJJp7O/ufdV5HZyYwVL+okirVvyA
inWCSJgsSRDMUJdKZwg6HBnq+J8u+lJ293F+sauAnPrH8Cd03sSeb0c5x9gqxQspO8gd8qYaY8PY
Sn8VLxdAplDXxnnqyGgbRQt55SDMfDN6hq9m3E+cvjY6REXvMmDmVRK+IXPiZd0TfCdl96rmxic2
Q2WZYN7utORq3vdOhA67Fy1U8oSBPJ2dRHDwRgvl4cUkHm6U4ntXz9KZo13Un/evzonS9eIkSF6B
nUbABWEzqvcUjBxiJOvPsUnIghnW1TG0M48B4f7BhkhpzxX/d3uKV/93nqExiJ7dz12Su7lgNWQu
tv91SKV5z6u7agFRbo5G04sYk06+8xZxGoQmW+u6TR4xfAa5EgQc6A970o0M15tKSoZIDxTdGYyx
aHRR+XTEBjUb3PS2cZ7rR2PJm9xdEkm63vKjSeQyxRT1OSinePmi04NYhBo3FkSro99IuE+fyUlr
4LFluKkaubC5+Xljzc9fkoRbB1Z9ZO5ZAPXi15Y7QHaeq493lIRC8mIOww4zQ0XgUgzivmCb0t8Z
IkOv6ko7M6hdrd/PJu4Zklg31onyfWGHxkz8b2pEWhOeN3KpYxzGIaEdpaVrmuB7S3Z4zn/OGLtY
+ZBE0SBA2aE7wZ5obxrtqZaZX/mgwYe6B/bUYTVAwDAFLEBzy2ywbLq8Fz9rzD+0kf0kJeAyB4UR
Qq3JfMdgPNRpJHb3H1h90+fbxlz0SI+M8RVccZknCxHK4bZaopxEyP2l+FBzQtaBerTom1vjg2tU
8GDGZQLfDOgcx0tCEE30r27Ya+XNJcj/vdDC5I/Ck5tV/CnQT7YVZUW5yVv5G4YMCcOtkiQJ+GFo
Jo1+BRfu74cIPXr049CLTdbqVEZTQ+9P1wsnpmZNuhHCZBBpMflkMaOKOeQyhz+RnU2xYjkHQ2RS
OOvlXkMISZqUDHpfcCwgBpyNbbBGo9CF3Fgn5bATqSYpuQKNf9851T6TMkZDmLqSwzg7KUqlfkko
cvdGv9/PesZGZRaIQMCbjxkEuB92RvxGSow+WnAUjDs5CelXuRMF+XjO6C7/3qQG8H9h+AdRGGgG
XisrBZ8JprH5wFD8Bm7zS0B/JOZ+G6aiyK21Pk8vN07fUT/9URYor64ebNpbHWn1g3brdVcCQ+0f
FuZoZYxJCtucl8jU42TCZoVD4pKMekr9Kr3ath0wAougy5JDmbbxZd1qcUP1xr6rbwOgEGgSw4fZ
UUOKBOpZvOtjY0ZBO7EJHr2fGUk/fo+p5uhNaCugbnuaCB/t5O5u90DIvkixRd06fxFw+ciP/VHH
pxtSifm/pyS5KFzr3CmzgUbXDY+j/fUSng4KVDipKBuY0aPs0qYf4uAnqnDDaUsMhxMlRrC6N4M3
7umwm3Utqz8v/z2myfzMbmcVunDFEnGVY4XIDPhG09fhQOfjRcNfCkB+3Wl7JmD/zCSB9YJPsEYV
16Mxi1Uhe/CaLZkhZ0zUt7OwS+o9MLaHsG457FrOMZVrcRzsprvsu4wLh64nP/cEokpyhG0lxrl6
WLm63zC/1JusxjHQ9CRhLI38LGhf52bYj08CEDMeC/5IaS8YvOl/BwFZCcZZ7we9k5FLT7OzfJgE
umVWt+4bDhvx0EHF9Vzh+iz0XIIV6+amDZJ8I5H0ppQlIGUw6sNXUwXDrbQz6Vs7hQtP7eVnyWPJ
ikTxEeswVDCKS66mf9d5nblUM8HeEUtoC9Sb8bEsCy2V422blFKS/SggGONxS/Zt0W7dpjSNr1tC
SpLJ0N+dCRTq8iQXYa3Vx1/c4Pb7/avR76BSzGhzZrf1z2zXYcyNAMFiKxR/6eFeq0nR8QScv6MI
vwruhcHJqkpJn8264BfQMmijjizj3BRwMrIAjcKLGaeHKlEDtNO+IQMcT89wloBHxFp8TYXnzxit
TGdh74SIRe0Cim4r65VS4NREfZl7Z1ybGbxz7eSKg7Mehf3LbceDrWapk504lvFh7wNDqv254h7r
7QfVTAh1cMgBTorGXjpoTftbbw+IWyXWPBt7+EnJnDZG+aKDcPQJNkHEaeSBRoM7tpCpUs4B8Cqq
6F+Bot6Gpq3dsRiN5bUJiWXOHprEKmMWu+lXMdAe1sgKhWtN13ccHx4I91KRhB5moI6ATO7E4D5F
7DHUwjRniCpU1uZVXBZrnD+E3uSEeWLPWNssPQ/+Xb3Zkl5Ou9WGhxlUfUTl8ZaMnV8RsVGNwjEA
Sve1Zl3QELKj9jBjHZ/68ZTdn1h8EI+6s3Dz/xlit/8hAVfqwhp4fYFTq+l/bCKoIEX1PRmW9L4f
m7h0/0Zk1N+ZRAypSLnL+QHio2l4MuunIO8fBfZZdFGFgZXlM+SgEIgcl2KfrqpAkXJoEEWCKddh
0hXC2JFvoq+0GCMmHLIlywT8SQCayL2w/AIPTlYqqfP6LGGQxBkBCeeFcsZQZm30yF79dQ/ECAl4
jtu0Yz2lzDd05xbX+5yPm5J7OJ7fs1Q6xNN8Sq05HS5vWaTBO+ph1JzUyWKhGSl3ietC4dSR6x+3
bU8DCWZnMf4TlGuqiN9auItdVoV3LeOMCbyIuNLZ+cIBu+GmzAU/qLLJ9e3VsM5+kK0/GiP8sWR/
N6IQDwwBd3loZREphcuA0Ws8qMT5TDlIZAdj3h98CFaVW8muYmcXg2psGaBigao8Mf8fDB9K8fLz
iHgi5OHHZ9CwYrLXw+mXEMtwP/2SRXRFoNlT1ob6w9lo5InMixITtVbhZlEn8Z97BlON0pPNAHrg
6lYgdvBtX1zG8qvBQicvyyIPQFXNwQIsqo7VPd5+jFBSmDz6Fxw8lKp0z4KtmSqgQhwNgaN/N2NY
jM3hYtWWzTZ5pYOFDMPChihlDdJs5ehBaFXWGz7qfLq4KrtlD8t7Kd0IOopboyRSzgcJqzJ0X025
hOibjv1FXAgOCsgadCedsX7/Phufoq0ezDLGCbywa9XuZGPW/NG9KiZ1+SS92VKTX7EhWRW23S91
NxVPIC/3HArRvLqCiTzKKwMPKIx3ZHLqGM1J1Hp+Q1gp7JIPcb2MugTMqfKeRhSFIYTyQUxvuqoT
JJKfy3bp5a+CJv9JDv+2UQkL2KwB+D7D2rB9mBes6uptX8XWz0MgIDdaB4TOY4zMRPv/djcyJ9xQ
So3d9etG4ZbLl61x9G/5TIcXcUs0hjVlnvkS/NuORdP3MDCwjRKHluzSu4g16hYhD17l5lcKCNSs
WomvnYKVutq19B8rGiN8s/K2ghueTd12tFVtk0DlJXmaPWNVrpyfD7ptaLIKPbTQ98jTVKYem+Gu
Bcbr0OYLRZeS3hJxiu2UEL+js4FOjF3srFv3OmBLkjtKHt6wofeiTE2kz2jparzRaahmbe0hgt8j
fGVlsKQe4eGwoTQNyY6fVLx7Gd/WsGCNPZgCFQYDXTvNDh9Ov4TNlGEITrjXddeDjJVOHNeXEBiQ
tSUV5ZZ2uMNn8oWMks8dbvBis2H1oB+FVmq9S6HpLQTvuOpUFfXg0vKRlA+zLoHJIFQRdG4iFR8g
dM7z0De27s1PfcoxvdgC10Wv919CbrNDg4kT4BHfvtJdtWS4QhKYm7DS5laR0Fjwm/VzrQyMv7qf
Qll6d+0aQsX+36/CtDTizoW51To4s2OeGvjID9GZUXfDFnRNgbJ/yK0YqOXRbmV163yIlktxNAgD
Crviea37ODwjQwjbkOKPrz4B5Xb8UJ03IvN6HZ31aP4j3lCIT98oSopDC0a4s/mnGwmwlEHsoKYa
IDKjOBnh0BBYEjKYVKAdCO9c7rU7m/g/axicdrWwoQwebd0BBjfmBA3mgNeZjUWdxwAvO1XKkICL
hh8CDAZplCMKy42IcYh09M0DzUGw2Ft3rkV0zITsoYM2kH3m4cFRPc83PmmqYBNE1Ff1K3sWk3AX
0v8UT5mJ6iQfoWSYXZ5/tHmqzZeuz1rRdXQAoEsz86fefGZ6APO/lf0g6MR2/MOberRjtguASSf8
ijo8ECOzdBcZFIGI+khp9SBN93wzOk4qes8UDEVw3kfFrNJbzAHVYEe9hLdo7qwT3pDIMLT6FhrR
dK+OgPepmpJKG6xeMPdOE4TF2jJU/LEWN/z9nJXIOLPZs1r/zza5+Zu98gK/JLoIwUAEXuQHLGxR
WI4+mF/YfC3ExZM72viIni4xcwK2q0zY