<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+54i4kag0XiiVObQEfcomAqUg8QHZdxSyUQjHLu0qsFeX9GxxeZFXSoDiXC1nF7cFvQCwlu
YSHu4eI3bcJZ54sw2a94L5DLoSWzBOAvZ7z/+5LX0IYCRm3KDvTymbH4HNc8xklzJNQuBaVW0ud3
sPhcag/logPdhth9jWHDLG3RrE2Q0RaXXQP0sSWFRPeQb5g+3QOBVC6hKCZQ3sfm/SpUK4noOBIW
CI/YLP0cw9SGYnoW7fiTN6FC6IZVBTirx58pk0plfkROXcpeULi3S7srFafIPYWB3RHaV3wbcNh9
mbe8IGkB1Iw4viMYvNl4oOcd2MpXdc5rUDAO9f5VkU+mkvW5vFUepb539hn8tDlEE0JULKqSr5mN
Su52q+WuFpw1tlSgrjd+hktXSLb71uZZxyQxRijJTkNidHtYZWyRmS3hZEJUN3KNuzsxRzGUpVct
l+8r59zccf+yAyw07y29vNo6FY3l1wE3wsk2cxkP5IJmGAkHw4AP2IkNOSG81jt3WF+eVSealJ4D
U1WOZdZ0eNHJTaD0RMlDxRS0LdMhQ8aEiD7QCYMjWvWgZA7J+6lOrnqzH7z/MAnh7mGfFMiKqV0O
Tn/6wcxrEEBMNuHJFINg9fBiRavSKWaWBQZFpVcjhyektMCQOcCP/n8M4QCOeWedRaCWKJgcn/Kt
Ve0FLM+E19uqZkNZdB23pYyg3y+4N8cOxVxyNkLQu6f9iEWhrJR+PuFXJ6ROWTrHvJYAEC5ThW06
MPrNrCdQh7ri57e6sLaicFQymDK0h6jbX73P7s2A82JYsrhEvtUPhuPMsSq7coAoCRo2+Ao66K3P
0TJPySKRmkG7peI88ljk+j3/Twr6tFewwWi4Y7J6PDX3/8LU5ESd7tGx2bFsWqtsRMHhYOls6Uv2
5kfoFWoUz12UkkdKxK1UYC/dblT0o66whasoDM0n5s8b8ek6LohyQXi/GPeHMR6RqPilOe/I6U12
GZzJHHsV8MgKWJhDh+hoYk+K2+uPwjcOxQMLY7Uvuh3jiqQu189VEaQzL3GBqYD5I9Ci26hRKqJi
7Fv9u2P7s9a3cbxTRYK9kcQEQuoEhk12gqNr0v6TL7Xw/1tBb4T9geVJwj/EO8s+X++HZ5fpYI2s
uicQ++jFZZsaMHGCNLsudYI/BJfvBSUM+of1B+h4JVhCwBuQjEpKRDPe5CvHx5+sOy4euobPftx7
KKGqK9mEz1pdaHsF1G0W6K2aThI/UGgLs7NHFeRCjaehv0YBEXsEaVvH6CYezfe+U0NyaYzXBvXy
C2iQnI1vISvpDvclRVn56szzhqCUoUx7oWtFw4Wvs7jt9gjzD+khmiorun8jVKn05DFz9y33TuKS
KxNFJNM/QXNX+v4kYFUB5m7OC+zSy9UfWIRf2wzqdtI2PKRQ1cyb9dSj0hfSU2TS0hwuXmbnqCHH
hbUFChojQFAidRbwE1oHNUxx9WCmkjMwTDw9qn0XMsqU9l20UtULWguDOOADRTj0vMnmltc7lmR0
Bs9oMCTT3aP8v0qjciz0UNYUJuQt2yEpBR0AI6+B8sjCxnI5DHHvfJGbN2iJX9tFhXezT9Pfds57
qvRnM82Ku9FbEIAQsDgL8p7qiMFSgceK+rhT2LkibhSOmNUgkfywEjKXCLWjLwvcYMIGFVsfYEug
dPn1SPv7x3KGvGsu9hUiSSAZbY8mzdGooQRKC5rVsrpFjBvcCfjs8/QiNKA4gz+DpWC6uw75ZUnq
4Xte+2hsm4vxJkAmlP56PreCw8c6MmDXxGS1IX+2BHXcG+h4uEuYjdgnVusbpdlgRCvu/FqHiWwP
IguoHET4ghHgoUFf5C2z9V07Ve8QS9fUOtX61HT+s2ApHuvXWxNKrLuAnlFfT0UdGjS8WTYKbDKO
u1WBtC9imJu++AaAQ7+ql3F+MFBeLOnnUfEZYtydXq6ZfhEFiqgWhNh2g6tqiPwBrVj+5iwg+f82
S04+hCTut0S=