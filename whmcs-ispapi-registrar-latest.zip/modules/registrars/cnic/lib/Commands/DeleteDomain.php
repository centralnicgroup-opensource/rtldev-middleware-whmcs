<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvxHFxeSFuIzsMEgcK4/6g/eUxAfoel5Q/ivHXtzVXRDbAPu4GyqUrp6Ukr8/GWvlu0CzIwT
5Ogiofuw/q3bskapLNtG93L4Ew1j0byS7AfgbVNNy2JjJ2JdI1N1YjxMU5P2t6yGJGGdeo8p6uCe
fwMN8L6DviTveusrMOmeg2365UvMg+AN3zZ5oyS5K7qqFkiBdXCQ3JfFSIwj3hvpkQF74w3/o7VH
0O88hrkFlEOL016mrknX2K0LGKxUdF7BRsKUwpKCxwRcs8Piw7bR0t1zjJvA7MQB216Qw0XhROoE
oOATPp6MjU/pp57LutnzU129mrNNgfygqMg3KplP/PSS2bebkKnQRDeXO/Oi52ljpy5k0X0M0C/p
WmeuV+LLZH4EpTsaQs25N6ZpZzI7iKMeQNjXujKQa/fl1OdzLKblmoXQajdBjzkgu8/Wz9FTzqQ8
q7/fJAjQRt1Pkl+ZDrIfwOiw//i7Sj3uXQp+W/Vpul4uCVXp71ZsMd+/aTuGQ4hz/UYKGs3F3Esq
AuDV8YQdisEEsSiHGP64cVfV6a3ihtVx3oBLeOszqdMh/S3PEK+n/qJB9/CczcBCiVY3D5HjzEXR
rcpch6eiP1CGme1X/K23FiqNOzHA2Y9IRiWJjpecb+BjV12tEVzWa7EWyBZD4zJNdZRp8+YHlbEf
9S8xGr3N+eZ2oWME+k9bg2BHezJ9YXdO9rRUGj28EswHkxLVby41tuHfG2f1hsq8GveJLZNnS15N
vFXrtLq47aS0lKx8pIqFuBvvHYuEZWMN5OQ1JFPcGbxShOTK38uRuj21mkoXisglWQ1it2MMxNko
nh5rB4fBcwZsavYwhGsaagMWMH3akFKYreoHTUrUpoqFJRUzI7Qwgu5cpB5sHEC9p8iAT0zfMdLe
bRzkVS5sftE6i9qjysPKJzxVFzTfTQYODQvCOYgD/8P7LSudv0QNfz1qP0bUck8X9OXM3ak8otm6
x3YJZ64auYzwhrTyPV4B5/T30qHHvTbkH9fbZzcD3gevd81yZwdXMRMA8ZvucintocNfj80ZZVBz
Qez1DHCWtGZ2YkmvTcR+ULbBBVCLp7276Xi9qfcWMs5ZYpxkjZzRNGVh4HkGUkPjV/G8AbTFXTgl
1JiSxKVZpehLnhUDkESxuJuPVmuGkGZNyPrlXhf6L+stWX07qqRqAGt99tu3Q6/GvUJMX+gkBP3s
i7lp0yBR6vEwT2gKIBkQVY9FyGFsArE7fk6ZOE9BsaWKJ+k1ZmtVfQSvq5ymbjX3ahYMp/IEj57W
QL2anKRGxIckouoiwAeWi9ahjkQUKpT6S8JJmyWn9yK4MZzeiuXHs6//zLE/Mcozk292pKgOXqJ8
18pjwOrcQnPQSWKltywS44PzjjtJUIj40qPF9FyMCyhDnvFRvXXUIoZ5QRBfU7sT8yfIgs2Wbagr
dPg3C+hp6ClI0i6lkag3rvWRA6uF36yuh6ERUNho84SRTvnCt9hxfAPJJ9jsayNvVdIYgIUFsPNX
w0ViBktn6MbyWGHfVnFYf1ZaH0IstODdhmWwoM3knFcMtlITPgxxCSeZUAWBJNxb8zZI7oE5os3s
iL7iaT0tRTJgs7wtpBwohMAdbEcpdNsBmh1rYtMrKCs83hEm9ngxanSE/FjaTddqRrAxoDjLVlaD
s3tuGhL1w2UGoXj3B+J69qiF74iFxDaPJP3TgXSS8Ro7XjcMImW6uozdPxOUxvGsPyaYkFWaCfn+
1WBAWGr67U0e3d9wfTDJrEr/3n21nA4EGlts11G51taeb+VHbdY35nr+S+fq/f1lGg5LcnAO6SB5
LrejNensvXoFmo1koi4mA85RCqC1+VU9kaj0ud4LFt/vvprSkCh93iZ8YG6wH83+9I3r3060vMeh
DUi9a0r67iwVA8YqH2j0GEHP8ePMgIRtSy9xQvAmE1Onq9eHi/8Kphi0rQZRRSJoqF80mbeIvaEq
xmelJr6ZI/EhUXYJp5Qwl8MEhm==