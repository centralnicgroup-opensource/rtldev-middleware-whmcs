<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzTxIXjEnKvT5ydVE18kl3bmicHBnViXH9IuCeuS3hQcKyaGKtzFH+/tTCbYm72uejnYr0P/
dsh2dsYmrew8GPJ3+eLBhYl8GQd5sAduGl3Qmt9lgaZ0qEgZJrNxs/I7+Z2GehVVP68+CUN4LVpb
B3MoKYx/lC5NkQB38PNxTaxjtLoDhuYljsRMI1YgkoTrOOOfn1UCxPscVgDUM72plo/YZ7/T5SCl
tT7gaXoUjKs4srDG1pKgnn+b1LfaZvNOSwos3E+cvjY6REXvMmDmVRK+IhHmQ5nqDCwf79uLwSao
U8WrIv67RoGe+vJ2lmicZt2MROFK7tVsYNYUFUys1KHxo797vntETZ7T0x/NMlXsK9HRPdZMZP1h
hquAmPDyj1Co7OQXbrr2Cz9Y+f94TPNt5p0KCll/EixcFhYHi7nYogcITRJnwUpNpjbKyK8KOiTf
qNSC1abAIBAH6Is5ODAgFk2NCa5kXWiKGxlvGtjJbxZ8bceRauXfj1HXix4tjejTvhZJ7WRtohC0
qUedS7lwFbFknE9YzgcrYAr+URcInSwTIw0pvXZnFjAoo7Fkg7cwblx3seMSiu25BIzD2oF1fsX7
jQkTCG+5DycNMHra/FMJPmE17buJKaO6UfO5KBhRUmtKOzoLv6NXFdE0QVkmNf2/iCKM/3WQqhya
Kfg1xEuRWq0gnMB+T9WNf+weTlvv+g4Gl+C7Am+km0zod5XT4q2U7gS6ZbZez7gtEu7Za01mAIHJ
/8SFUDLFLD+gqbc7nYPPqrzFcBNYYF6L0216M+b2n3Ibk82oScorMvGmJop9Wzw9D2O72D/pEpsJ
hNv+7tEGYvQadWRdOMQs24n+XPFeQrsbjLa7LzWo2jc//Lksoy3oJW5Fput8EU8zufq/4R6MIkqN
Qbj85eInmAq5esjDH4NxbgVff78m9G2ntC1nCCMQLLR8lrgJZIhGv74izcnXgh11S0G9TeGpkS9I
Qh6cH1XmtpHTsucbKf6THFyHgqHGOW9fGK3yGExrB15Sh+CCjSgdBV/vURfeW7qYbnfwEF7tAYct
1z1afosnllvhQjP3tp3YpDhRpWPbYIYyKkvU4xv0z9e7iVX2JTOYeWeQpOIv6Mz+b5SEf67gJGZy
tY1KBnZsA+/n7HvRecMtqiHW4b6VmFOzkpLnWfIsG2clkjO4O4y3YGWuW4+zEM1+EQhefXdy0ifp
IF+OYkzpIN+60UdUuNG/X7FAMlzHvvkhyqG7swb1sLXv8hqnJhHvTVR5qJb1TfSFgBrnIXyePkuk
fxIW8JRFEgpcNIk24YyWoqKtmwBtAyT6lmZ0aggnvWBnr3LhBpFjdxmIdRPW/uDkrDip/xenX2UH
OJDcPu52TPozC8rx+ZjNCuiB9YjYt5KazKZ3cmvwcjXJoJCBRwFwETwn9SfzuderOpgjqZwkp+kW
LkuJLC2yhNNqQmtTvA1F0PntJkghk6ZElDIB4lf0lKfWqXW7q41AIKYdLwU/nIpSx6OWcrADkGuZ
SuHDlHxOweJmcgKZ+pMGr66a+intno+xQolBcJVaatV3qJfioMuBaHav62q5E0jpOS+DCqB11zu1
bd9eiNW4gnOtchUlIYqXKlouXzqQIdv/i+xbc4Aw9hCjMzAONpzZw4VnJdgzsNFL2PfMCqu/dT7t
0Qs73atC73KKtbNQvHAOdsjb0krmmnExCiaFO7npQFNbld5M26JN+Gx3Uit5vPXOacuozDZbg9aa
8+2Z4RfoZY/DHwr0wnvxw7zwVu0TEvnxs+AWDLPKP9Pfd/LOXnyg55HVGqULL1eW1V4ToZ8Q27sb
NMoTfKcc3JbYV0==