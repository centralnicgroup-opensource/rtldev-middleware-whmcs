<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqXOIJ/h3h8myfJS7A125ZKiNsd4qW1WWlXzMdoefMHJSoNvj2NHNKGIcVuRjbRf2mDt8OR0
AfLiYMLCKKH9dg1QWwd3uiOSO6Y36UA0b5ZaIIH0JnXMWlgRve9VNPx/jU/zzrOACXuBiYXFP9Hh
Rah8qv6QvAHnx00RT7wE585To8u2BHcfVaNFTAdm77LBOGAS2Leq01YzEaAVIuWHpkrZNA/A7/C2
R/YRwFxcHW8nv6+axJQA0yCzqBUuPAXTRhCPc0plfkROXcpeULi3S7srFae5PB2UpUNa6EPLozt9
qWid4T8jGn899UJsol8ZM3G72RvwG+VPEOm0qvDHIkpc2c6/2SnGQKnQ0lzudhCzTXluPmPN2xwi
ZrRlQ5Npu+EhiXlIXrkhapYw4V5stsCN2rwDzwa5tdelrE0tXq8HfQjeNq/nmPYHBWacnzhgR80+
RZfOQRd+HNHOKHypeRhZZW4PNt10aJ5d23MzdgtPTg1ig4bqTiRzQH6gdDEMx3MsyEcjpm4uWo5E
OAWwszpDtB5zwbxTrUr9wS1IYoPaghCYt18qZFerxFZ609j6+KKGcr5pv32H758izsDPaNmEdIP9
Ctzh/FPbXFYjZ+HOxdYew6iAnooYjxD13MJbbScjmNdkA1rkrY2jOE79nmNE8S2prMLfxNjmDCX9
Ci+SeiAU6m01lBlDPxhjiil45EhlzNotAWFortQ+PGdDfY3K5WP4Y+nW85Fu+ZeIidmhOoNkCGGZ
08JxAj8fq5RLz1DStnfTm1CdB7qjOb1SOc85NkDPoUmdCNAfdlUf30An+8RGQ7lRrAHEBopvLSlw
1SLK1pGcUzN2Ksm6T7MyjKRcC/EWxP5eRaXHkChNS6YZttmFp9J8uOusX+lJ15eIQM82Ujfv9FWo
W82y01UMAWuYQuICqeTDTTAVm9P3kUIECtKeqrR0UPrEh+z3VKSuUIqYy4cJ+q8vqAyiEB5xvA21
ZW6i5D941WBwIZx/9eASEeSm9YYK/7fUlP4aUTG8lTuRRjIZ0SVQV/NzxGhsMljXwfrXT+lxLx1y
JSsbWZ1R9BTUPuQvkMSrYz+Q+Ct10GsW/WxYKErqtpaIyAs5lgDRcR1bKe2xxZywekwYoJtvzINJ
uEkkjD6RNhytskyUxOhDUXZ1DH+PQ/XfrlG+8MUJYZL/HAfYx2QLxkS6+/TIFsxJkLbsXcn/doox
86niUc3h8vlmyc5cx0Pj2G7Aj3d4LNwyHCcSI3Qb0tr+quEtg1bRCFEBKIg/EuKZ7iAANlLjnECe
2JLWl0gxfWwore3E56uYnGOh7SEe6QkZvmY5jjnegsfKkc/hsfsnLVz3SQ7IHVBPe/JtAHlkI+d5
9sMYcNmUlJ2CxaC4gWp3/DC0PkIi/fceKOnd7SkVwMIioY6SxTW/byzJ/FNTewgZMFcog9PcVmIs
M3EMjHanZXyFPFHXvHNS87BV/e0U/cw7M0G5tU0ZiJxRKx9DqDZRuvIUfztSkANjUIYALKcv6/5N
3lPjMZguEmHRgfd+2RMXUBm6Pjh1i+b03TjdZj3UkT945/5fYyeSp4aTpvpvVcxlxR9tunRf0oux
0W6r5Snn3A7sPfT11l7In0ytu/OpgRlT9pOHa2jZ6/EkTgRC7oJDN91A1cD4Qk1ui7djBwfN6SqC
+9ROfMDxs/Xk1kql/uSgV7qYVMGYK05Q5g6OhsnkYN0SM5Dtx0Dkb64UAFmAOrrtcBDMLtRhw1ua
ZLgkoaUP5hF2VrWuz2mD8+9dpPZqyRfHeMOYNPp82UIPvqLLvdeXgLW5CUiWG6PJeaikObvM0HKG
HcQgHmRRo+d5n0wzQa37PYkeCla46ll2dVfOdc9UpLMzfFYKfNXD4fX6hP+v+J3+fhfWodbguI+V
sL4sjHNSMHpzki6226TzsyC2w9l3KL5vkFrLfZBTxCpD/25N2TuNUDqVqQPYnpTP9e3TB3SNtoyQ
sayaHhJdn8JgmUC24Lx9bEDNUBgZjuqrdyXdx4/POmRPPR+IuhitN37/JrWckTKtYcD3UGTVD2Fm
YM+/4TBMbJcOkVObL0lb6kXhzjUWaUsOr8P/3FcatSvZr5LYdhoQWHQBO3JOH4qX+1EHg0yqKE/X
Yam3MRUYM9eTSoEpfUjucPxidVxUUuToXbT4OV+uV3e5Lb3PeyXWDrJLr+Fe6ZrGYqR0QkNBCsJz
udB0ET1mlsykClSFRIs1iMF4d7hMFYp91vzfkDjPMArJOd3mtT0iXqTtH8s82BcK36plJT0cYFdm
aAGeSJtWpgHlvoYMEBIjtYdHFtZupfLuaq4OtODUHt5GmjK9vwHw6PGrXnCGmj8cUPny68JfX6Wx
/T8GOQ/cFqXadDLI8wozW9reVdbv6yWHialkl4XynaHM4mpCuodv0oxx79f1FqZS6hHRy23EE4Ch
+V0LBcSikR86P2cjWxnoizC+YQt2YjTxjuB2dbRK9BBFvRSY38IS5yA5f0numPuY+MPnD52kULU+
I7FRpwxfMAw8ngpwJIFsD1503zaczCZJ7tvfJpZiPET3hGf0k4tyr5lXIj91rSFwKEu0cNy7jrSk
cmKc83RGhu2/JmeNd9C6WmA/86tnHm==