<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuSZDx81euk5tE+YaPHfE9RbyO7AKYjEjVrvttczOHWiogq8Yjjm4ixR0ohhniDFiVsNlghA
dlwtOHvCvtfqc4KvwrbhSgEgT3a4MtQHUdBACjQw3O+mmWj+m6SzV0kao9y/i0sQcn0+oKYaRvrf
kzhopmOXNEj3pMIBAyLRJ57R4HEPaSjN097QmKU0QZAbJpKPcu8+sn4m/VstSoHVDTpXFOKFhdxf
Y/+7bd5ZKmQnhYAOsSurHLJgopybRq60q81k2mplfkROXcpeULi3S7srFaeBQeFiZj/zRdWtfSV9
uZseB5DoseLhTZEwuTmEWA2onIQuQox1rxcWluZ+RcP8xn2ir8vxr7CVnMm1x/eA9QfWq/yfJ7fA
hNHjEjDLpAz6gwl51uL7HQXsVY11hVvtn/LTVsFO/OmWCcNIP5vCQDhWL9MqhTr2q4xNmokM6otC
D4hLBE+rydbmvd5Cjcq+WHVwWUZOgaszzwOj20a6S04g7ROnhMDMfTWcq5oO8JAFkZNSidQs7oRG
nkTkuJlk8GSjiog8lRwuHrh5WaNq4vBo5KMRxDelGiOASijzz1WNrwHyqb8RrrPmTeDaobmgQwVW
9zcc3j78JdSOK2fe/eCtvnw3QdR85KxJ1JXnZRmaOcooBBeG8W98/u7EAuREtDDguNCjYK37Ni2o
5BcM6oe88zY36C3Wg1yo50ixYyR/Oqi4w3aAZDn3Ic/sUYjghh5kkady537eh76iwMlyqMzzrev1
L6HU6nVqlTJFam5HTjfKbjR5LAtPQXPU/Io8AZtZFsfVyv8pIiwmSk7xPuz3lm6jbznN6pP1HpLr
IUelaysKS+4xmo0r8dOuYcUkQZwyFk5PDG8NoqBjWsjQBoX28mE9k51NTFyflwG+nDRJCP3TeNHK
hH9dUz423NfPZ+HX6Wnx9Df2nFb/AMbrEryo42h896FtOJQx+pTwNn5CBM+31nBsD1hOKtZ98hdj
5BHq4/XTQbqHC0J/xzWeBiZcSl43idUknC+ViRfWr9fIr0B23ohNDBcKOjt7wJWJvU+doOu1WKuM
Nm0DCDuZ4jXJc0HIKHrny6RE8oaWhymWUzh9u8x1qwXlinsSClmqwegtNjfDvaMVK/3VX/SjexXH
RkeWuWy0fkq7HabkpMZSsT6sG4xevEhlKptkKQEAZHnzJWlCs2gNdLSbjKRyaVNkyShMXQmqQFgF
qsLErUMtsPFQ71YgXWEf4aH2XF6xHrpf/f9adkNKzK8z6Qf2uulozOtNc7Klz913MfraAnk9JheG
/Vyc5rxiqlY1NyDb+E3t5KpsXSeus0eOvd8Gac8V4DtFCbdI/Ota55xOcikij7g7nz6tz6GaAQ2M
hfCJ/SRAGw3DcDctjn824Ceinwk4BGOoC5WtZAItExuehKn2wr8Fm+tsBUiFLrtKL8dAo2HH0O+G
7I7Mtuuzdv+7rUSfyNqlH6HZkMnGb3fve4Np2Swp8KQdz7SV7ldQCB4ol9kBsKIpVobpT51jqzEb
gHLLv220Ace42c5ZZ5iVH+ZGHBeqalfu/8z8ELIfKbmH2fbiiNlCoFVtPk0k75BlymTlYwoaaMzx
0K/IQ35fNx1j6q+6NnQO3WrEK43MWGlDqJbCMxCFVx7CkwKGtnS3Crst0U6V/nr36Zw0mDaJbgeG
WwozdhjgIuKFaegPHdyhc4fYh7IN5U9IPY49EVsaUw5uNmHkS+wHjOfiiFADnQrxCzAEsodYfVuA
odU06gYuIZtUjanFDeMxcqT4S84fMiPfTWwmYMXHL8VzjARxm3ZJAE6glFbiUG5YPkEa2A4nqTOe
yeIxryRkxWvDs8sRmTvqpW9EGXEAqLQZk9IXtfAEIeZomvLme669/DnNFgcd7e+GR6ySbebtYw1p
Pgr6q1VJ+h95awdGHL/7obuXhlINEvlInIj9OLhyPePq6bBE1f6l107yheQBkm67WX/p/cNkS2+6
5GzcuYOm2AWrWfx53QJqX0R+G9KagF/W+aK1r1u+/GpKpidVJYJM/8J3rUCf+dJyaLgBrG7DB77v
x+Q2sFV5zd5QgKVJ8BRztSZh4LWCey5Fn4TaxDEqNqtKpJauYqLC7AckTHIS/LRkD1g+oXG/53Ys
/TE3p3hK0SdWBumgdnFk8bE+tMCHsve+rvjqEVge8R1aBlWK6tCZ9K9ijytydxNSN8I3AMJrt7g1
or3C1wGxxa1HqxvxGgC3TxJzs72Q9YXJOHBZfhty1l3jGkJu+2bjhKFC7zRpsKKQ5TC8VkFrGk17
lfZAQy/HvyC4Z+ip3dVPoeZRKXMti2m9YpzzvqdmW0jo5RSjUOeGJIuIq1Ly3mal1DRXfH2RYL25
EzMs9yNCqaTSIrlgJHVobA400Z93HOr4yQEEclvUK63eYwzcisxKe9iM5ntgHm3gzPm3NQr2Nmi6
u8g1vWR2LW5avuSQ9Iob4NwDB66B+M5YOQ5+V6Yy5/GH1rMa3PNAxbR56pjv4TiiFTwp8CE+he4+
yYGipeydZJ/vUBJsDJzuHNIzHY5CEwy1Ig3v4TKhozVRS/AHScRnobycOLcT3dYMRmt5Up8rAYV/
xOhrIZCpBTTuU9cWNCjgfFG9s4/c310Dbih3DkKmmpqRVo+hK422ihF4v4g3mY21i96vZN1N2G==