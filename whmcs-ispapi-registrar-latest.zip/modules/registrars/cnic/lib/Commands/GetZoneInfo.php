<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvhd48yOIUcWvLM5h0ByffffMDvkLoTMgTrzvX93YFvroLoW35796rt7J8hZO7sChfuEbpT/
E8pPSTcGzg8xNeyB3Byck96bLfiHPvssXVxQ7KRN0/Ej/ay22a+q5+QZcwU/xjfxhWlrMHHH1T/M
eYb3IyumjrQIASqkwZBPIt+pEraDnKNHhXEbuUXnsWxdcGLfC8DtZUE+EX4ZO+xUBlkObSFxwn0M
MaEgITnwlkL3BApJzZJUCcVCJnxES2TFzuri6mplfkROXcpeULi3S7srFaemQnvn9qX+kNSN+Zd9
ScH8Eqvh9cPZmlX6lJhd+izMWVgjJxBKlA6kGo2QWhtilm1Bu6hKyiRaHIiWG873hrx81kHNviy4
eBCnMTSvN/2524l7XCjY7y3biMkSI8tayfIRM2cma08drizBc+gS1HAQrDVipSbx/Gnu1lD2KdlC
583xJCOnSv8SGkLYsH7u2RB7Zqkc9+37xSkvlp579CabX4KYf7UOamz6IrYrIc9OIH1AUU3a7ZS8
/zi3oP2Dj3uTYeRREqvFYdn+mZJqP8lkB7XyG7FxKlYB2JPcXuR1xDHlUTavIFp5paSCu58uCr7O
J72sOO0vHVF/9D39JpO/mPG5qrkIClVPUdQc/m69y7u4K5rR/nUNYlAbOjArFXwzz3ESs7DqiiBI
5TwGTW6nk4c6+m2+DrI+isUUUrEyySs4mCZRBWKGvQzcfJkSqnlkWrsbE0Ef9f3XRjZzCphbtv3Q
2x2KZuZwf8r+07IcBUDmqowRevmFx9Je/Q0xsQ06Ti0XwzlxvgB1fJzq2czWx5D4j70iUYn0yY4K
q7NIxeeC0jRsgBmexAx9PbROUAd+DHSBb+k0XyjlHHTeOrtK4fL1VBoVfJTCf+1oorSRyFmwyQWK
fh9Qm32sQcwGkupR42DlwbfF2EhGAjKKjSDbvImQf+0g30e5j+8ZrgapFxSH54wJTmqJIYuWad7K
5TyRUxK4Dr5M9E3Q6UZKi93tImIQSJ5q4ejVNz5HG4aHA/BQXaC3KboTu7lsO1tmul6f0ixc8S6U
Den8Mk772ZcygpkXxJRJQXPu09Jf32JLIPfbUcdFm4gbH0GzrbIHc5gepQcxcPgLoGPX5eSDTNbL
aDljziy/Qf2r8LV5ZVGXeZTaCX4Qk6Yo+VJoMmGPpeEoGx4QWGfWfHIHajeDLjjL7vUcsEMaHypA
6i7mxqELM9RoV9rycNXOA9sBM4wJUrQmwqx/rqTNUBEPLk33KuDJLtAjmHR6SUQOTfxFkBELX1vH
uo/XsZhpKdlMrPWYhdwgYbjLrEAydPvUy2sWqoq+QM+udaZiR3duHIRh38rHw4cXbI4GscD2ctlm
nZwtfwsgfAVpdhN/et3EzF3KHogMHONaPWn0xZIxNDKqFPyLiG26fW0aSDLj0nq7LoQLkuHGvXpo
51D6VrB9bakQ7K2YN3JrvRHoPdNlW0mzfXnodEA1FhVX8vUObHxrdJUgSIafAVtDP5TW3O7JD1E+
oBfc4MOW17W/sehM8bHWGFRgLSKYEAd5lDuRuwhwTIstksDsW4PRuyq5oQ6zh9iZZ3hDtKt47Qsq
GNqWPHxto80H4yU6Bfrb+ioqwYGC6wJRiQYTDuXc10FBMLw7U7MhavRvLgKUPbdtK3js8ewxGhi7
zBz+B5QLmJwY/KXm537LNR24ieKav1YSddbaiayL+B01ZNGQcuyc3HLir0PkhbKGxGC3obhfctkP
MJsp0xxgiGY5C20svyZ1StAlw9lJrGcxjY8XVwD53UyIj6IUhevOHaunDsln2YS2rzqBmvAGyftN
971fizlSIAkrOMFsrGo2fU8K1fQ7SCELo/I1uSMQiJ1w9fBohz1oyxrEzhiuZmbGA37jL8TAJtEd
ASKKiZMcTHUnUyAX+vJSx5Ykt9NcB6UEdfzqPhSGUPTTgVVe1MCn8VIvySN1jy/D8HUEqIPVHrrf
2m9LYvdXfGkbQeH8HVvvV3EfSyca8QTqXOlp