<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwad/0ZCfyGlYUjfAv8jaSZSmZt24jbCBjqUJzETMCmoTdcCpTMeAZIOIpkCnQ14MaQcEyKg
7kcCevadr8w+SPBEcku7Fgh6WFzzeM0+/Evr7TRpJiU8U2voj0UByEdpN4vYC+wOQ7RnBDzuzn0F
YkoNpCIsdST3rLR2b3HtriwZfssjKHX5kkCD8QgRdWigAW2hMuNs7KTv5+CUfm6DV0nQ5py0x+7I
gHN7wtVqkNQWtrsW4KIH3j7zHiWzNpSi44aEsWplfkROXcpeULi3S7srFaevQ+9ubJFynZ4GoQp9
eav7LmfYpz2F4DDTespIbubtZVDBIw+/ptkJwGzz+KqFmk9uvPpI5xdxOlWJDa28V1rDmd6XaE9W
hStxyf5jGOoT0jqFEJkO6bW/WjuIeqogmkA2uF8fLMQRfMP/qmHEZP8WuRRuvCJY75Sd3JQib30p
BJgW5pk68FC9mDIgFrn74kudEf3Xnk6XJMJiYyvrn365cwIpweR/Dx2B/cQg8vU2IMRFQ2f/1E1O
V4nLggdqdlCwVyoQTqyjqIkDpy/d4HyAGbmr2CCAmfECoi4Vn76UiOmh+Ilyw1QMy/Z8wi66X7JJ
A9oWeYmA9g9UafSoAnF3Sf11pN1Tm5XEswRilSgATF6vqUSTogPegmt6vbkuUvZqu1xmMTlTrzuX
k83VtcNeTafnrG4etsKqfQzwWyURTUXo5ag6/GYy910pMV2y2hTdVl2UOJeM2ecfbmg9WYhV+Plm
j6XWplcoAu9IAj9QKop9gbq2Om0pE+zxnkX30XFYJbCsAeMsKOknpaDH4c+NABhbT7ueBBwZxFyo
I4RJon1T/AzKIT7F4fhJ7wpA1gIO3+EtsRVApFy5VthVbk697WZKnOYTCrC7Ah83El3lyFrueI6t
mxjEzoNLdHAyOLzUlBs5Pw/4OzJkn6aUlMksvKmB6qxssyHsiIcgxSgh69uTseJQrruOCLBqbhru
VWFKT2j1+KA6FnNFPc/sV8zhwMNVjuygNL4de44qnYIf6GCHJRCMaAWKTDi9Kt041X8XqYS4E/S9
QGbOOVoPdacaOKgZizAPyd8DmAVZ2uZdtmi2MBFKoARQp+2Pdj17rrbep2RtjlECM8uIIBVX2rSs
G0xxv+MeR9VaBgiNyxxYHImrbGg48ZKiAJibRVor/XbMVIlt3r4od4NS5n3dOwXKXFrnaX9L+vCv
Qx31oeTJIRRa3TlcYwiHilhfPQW07iHeU9o/ZXWVPjn7ik8Irt/5XVb62JJMIc6Jxd8QlFUv2d6C
p3BJ+bibA5UwBuCPpNDJpO/M+okWRW6gyU+oeODFXi5SZtLZ27BZbtBsD9YiNl/6V7OrCmStDbKT
o7QiNl4Pdmkm536rd9lhReM2IGrCCYsyBcgGukNmMXmQbuBHP7YI0395/75oxHVu2Zv0VbnRo3SI
SG+QfosXDGTCRShJ3CLOvfyiqe5qt/4kanl16RHf/eVFicF4ETgSBIBqRbJo1rr1JWfJ2MbmQQyt
Sm/QUbc5xJ1ap03nfccxkWjJTE19BefszLo6YvtoAGruNivhuD+E1OVUl0mL/v0t3re4d3eaJXdg
B6TbO33S+ynT3QCH1wUPiwVMaoM4bvSmEMdWHk10eXpswEvzFpYVYmR//Fd8ltp3bZTfD5SNJGEG
hcNKe1lzogBTuNPfFMbXMY0gGlzfksv7wcz9WhEgK8UK1XPFDHJWbSNg2l2MNgKxJOPO4PTWIWjc
zaHtYImjn6V7WRvbb4X5AMO4ghyKpGDVQYH0SOfB8hpEZYR1hkHHPnFpurFulknhr2bHC+5CgPUW
27U+ChvUBSUXW+oWq0wvQJyhuDPLcACptTVyIT3QwpdKENT4hHGOSZT3L1+47htdgp40RMOHwYy5
/JdMg8moyBH02gUHdT1yktGoDWtoqC/5RA0Z42g5HRNNK+8kPNv8wTGZkpr7Cr6BTAtun5F3D4Is
UK0pH9oW8kEr7PQw2xsb16uiu4AGhfPCovRYJtD2wM4/U6KCVynUJ0lq7yMk2gla51RNDY6wlIQT
HqNKqZ8eS0UJ+6oEkid0zso8CI7Xcca3uGjmmN2RaEkjHcZFb8589ZgVKzIYMgAZFW1z86JLo0VD
cCWzWYeBqgyEP9RtTAWcYLQdaopHNi0xuqj/kUGfq+4FvJZHiAcC5uQAf6A8Lax+/7lM6AR4qQfs
oHuksvyU7STZCYARq9NQQLDJdpi2mpjHBugpxOKNvxk6G/C+2nsT+ca0RpdT9EzlbXTHd+zjaW/Z
DwV2VbzIvfDO+wXMvsl/KXeTJrjSsdaLZeKtwe+hCwa0uX6/VrEMjMidlKw2GPC6Nzh/mlQjU1r7
rQzBHZ8UR3gzzf+DGQ/PchnxHg2EbnCaJushF+oab225Llw4CNqbzLzXQDLmEBBB99mbhRtdLxZb
6kXcChRLvDePsN7XQ5suOxepjVNLrDy1e1JmzvHfPWKOA9uZ2w5qa+D15+PAD066cnm7Iexj3ipM
cvnnPPHrioK0Lb6G9i7Om+aF/XPp0Z3nf04KG+0+fVui81bXO93O5ikyIbJbTDh8bpuW4z6Fq2Tn
0J8sy6dZN+fJ80iqCFvHQtmaYMAvDHRCtwWusL9Q+6WjYJ7zZkxV5iwSNClnQ9qa50KQyX5Qze9N
dV1Zc34my+uPbyAecRGbHY1tR1cO1s7D6rBTWsGf4vxW0icYLXS+JMbn4tAiFwDE/ViTr/k8WfPG
E8dWTEaqLBd9PXaBuuCQz8MOIeprmNGK9lLOQWflX6gCHaOZDp542VByFavDsQcwgKV6NNuZkOJl
hXsYgE4=