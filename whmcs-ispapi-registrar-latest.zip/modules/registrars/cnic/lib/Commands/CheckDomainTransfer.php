<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqFryTMHLCeQR3bazYBuYZSJ0Wkb+1j4TeUu961qkGDc6z/VneJUDqGWKwtOAC+sego4gHzZ
0X+a91UjSyNuKt+1mxjvGD+uvD8Ax375AmBSWzx28ZMBYAhIfPV7J/B1+9wCLWRix9DgG0Gpv96s
j8n6K8dY01vN0AkD0/b5O579B0RAHazNz2yoxLCKP+TkLWcS2KctwaZY360A3TSNf6WOQTrZWRkr
cUhh6GyvzTYa5TODwYNe9zVdzgfp53YzCMER3E+cvjY6REXvMmDmVRK+IZrd59nonLZpjD5Ipibo
WuXBzQoHURrHMir8BOtLqMsFXSZ/WtSE4G4L04OXM85ZJ6iGS21SUP8/ah0PNYVJ2cFS43DX2m8b
HrbZPRT2K0i2z4+uCjNIsVJHvL/tm87Do2P5u2O/dKtEQlSFvncll/u4OXFwnvqMmcQKOswBNNrd
WTlf9zxCt7adUB7ACvokQJ3mb7mbp1NgaoIJxymO48D1xw4fbDJPsDl0ycEbBXtKmKWOBgr+vXff
K6w9FRSmmzlEJ1Ix5xlzYpQtyLKiS4rWsJ1/D/HVxP6lQ9j5sheMXPsymp1RsZLsedIsDPuzlnCG
Dy0tiKl/No/yDwCQ1N6x5ZAw6FurYojP2LLW//3CgA4WnI+G+vlDi65hKNMvrnyDkba2BQRTBMB+
PlRqxejJzOAe2zBbvQr/Lfq+hI9mC9VgLRcG3Aliip4J3ubgsAVVAi3nFOFUT3wjToc9CsYjr4u0
zzLvE+Nzz9CPVxfwZRXIbgk5WcABmQTBTtl9K4/RvssnNdJZeeVYg8Sl3pgI2I8fP1beuwmv9F+C
WmSp40U8XMswZ/L9RWi07VdnnEZDqdrbw4ZTwt7RA8D7clFM9ZAKN9u4Sp3KYTcyX0sKm4oEFVhb
oLfffKMSlw7cjwfCdj9hc0EkMc0elhbad10S1iPH8myNhF98wsu5+hqrfBWDKk0c3PNGGCSqnH5i
ABECTflFH1DiG/+bMIZan2bQmii8CMjCY2Du+qivT1y8EB0zBwTL2yutg7A3RNmCSkLY7PzLOKve
jYYj+cC7VZqb5yvDat4QZTn/opeK/Xw/9Y9azEN0Gb2kURi+Ig0JmdmTnbr6VSJOoSuIeBud2bk7
ch15UQiHYKV4LMIMChf1gx7cNQHH+Mpu8NfOrtXNWYzSUkOSzC57oJdvuyp2xCzv5BC1woLTNLgT
ULoaKGmKZhUqhpCEdqv0Ox4QKpM+mLO63XRVTQtXj2gL/aBl6ts33Uzt2Q7puurA2ZJaf66ghIML
kt4gIeJES5WXWaHebHyHahCY/DuB/loIaNJFh145sa1WD0A3X1iBTf9eTvdJhcHPOcc/OcZlS3Qr
4+GLrCZ14C61HHvVDm/+kvbO7dLhKJYQh+SKvd3pTUji1v01bjqLssK0HerORHYbX30/F+3VI4Lh
DblY0Gk5A6dPSCREoyHr4k8RK+gZOMlpDErGj/1lUo2T71HO8uC/zf0Q0YkBYn85SVCNGRsIqaU2
s3QQJcbwUcdSZoi4ThXbdMuRxmdhYZD6enpDJu+xVh8qxWQsKWZ5Erf8u/JxA//y2nS42ZW/MXga
xv0zhRUPldvcKcGUuR6RpQzxgExm12Kn6eP/SVI++eu8odNghGSFf+UaGSLc+jgyvdxXRwSZWJbo
6UVP2ACSU+ehmttNJu/z0KYCddHreAC+9MJFuQum603BeCelNAtLEEJXm5fXAM6Ko60ajSqul6C8
UJQU5HClR94IC9P/iYyFDP++/ytbHFq7nZRRLtTf1OpQSX43MA3GQjf/13C2RUUMg2dvOYrOWNPL
OprGCi3l88oFz+F3v/S1BlUD0nFwJ54+eiLugDwPxbS4rlMLLWcbbCg8J+Q8CqiCown3d74JumyB
db5lYsWKPNNGq/bp2fjfgot7DH1prefJkEc7NFiIMVxjVaDYeinkC+XKXmZSxHp8u/eZahcPk2QQ
cZJ5FMgBcoKaCT/nn6+5o5tTTwB/R8KE3CiSEBPCYe/SQ2zhesT2YcJsq2aqwfbRSOX0Llys48Ib
BT8TBeeF6CutnX/wAJx5cfgv75V6lRK/B1042Pfd4IsuDs2c59m/6MwaRjp909ITE8H6FmfuTFXy
DgSps1QhdHZ4RbtcFivFdgMYFMjnzbmI8WNLXbF8XHgc3n9xcs3WK4Gc2dPAF+pNP3xyWjRJRDAA
TMea8riP+9tIlKUo/it2udCbNrhx9TNwdl1OCIPY1CGHfV4jRnlnbfZSueFDZQxzBIvD0PXzB5sm
VK28DrnanRG78I5qXI9U11sQkBh78nuoHxrxa2pfniOc+ZY2QgS0sVWGmU7Wl31dI847nrauJ+u9
e7tE2fG/VtSY6XhRo4z/PqDMu7mRccjof1M/Ijb6yS/mZKnZq3IIl2LHaeS5Tx28T57E8EqQkWgd
1d2nbK1a6S/jgC5MI9NvRP5eIdFra/YRRLTXKKIBETA6PKSEofQRheu7uT2o8Qs6eCxYVYwZU9Xu
BYr1uE2VZKb0HrPBikK6PdHvXWWLo/0orArp949D5q5LPW0vC/BFg8hO9TPF8gT10nH/5dUdMB0c
+fUwu1UF6ZjFvRf2Xrhn/qegacv6LTUPiUL97rm7d4eHmjtWe7D66s9DG/pZYmFg4L0YkaXHCnGI
w2LMBT/OB6vlrJ2DnE2dJK/em+49hCHFRSKYG46q1tteduIdKxLrygzBzFDmMExmsWU6H3K4QJt9
7Z0fV4qGwAKlbbe8KYr/DArl0CQyg55OjSqE/uArNtEao/b2xH5RVFCfhmgqCOMHt0==