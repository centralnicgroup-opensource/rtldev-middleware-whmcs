<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsDox0VhqDGeyhvv91JDXo6epCu/rgmWUOgue00cqhVWAOeYksRjErtkr34YytpZXYc5ykeD
7a7hVJhBE2su/9B2Wnapq992ZMazaIqJl/4HFo7vqnVVgqlkpnWsgkbDy67Q5Un1cJuBoCOgkMEy
mkdiKD/RMbTR8ofPD5oBtq6kK85ptNtU7Ae5YjWffNSZRdA0Q47poF+z0F/ZQt+t9NgmiLGcA4rY
i/THGn4UfmtZWIZ7XCoeBxHGILadlXYvXkux4xy/aYpMHNW56at4sU2pw/LfUNsfW1SYHHKOfiZo
NaXAyrNj/T+R801zp6P1CXDkN1HVBpxmagyIef2z6P8mGhGg+oq6d2Je1vdVkk56/KytHB80j2pH
sSd3T6fp7DQr9ZL3pvRzaF+xhdFWb43MXScO8hX4R0CCMl5lL/ETLy2IFVIE5jsnZdyELEzjH6eP
suLh1VQL85dcL1Lwf8gp1JWNi8oAV3igyNN6hN1Qa1/22JWjxOiXYfa0u51jaSggLJ+DOV8Jx8eh
pT4H5+hGUHTCQ9T1eLsUQuDFVZRWLkfORzOGJjcOl7+Yo6GS3fjS+uHhY1sOCc0TBiJAZaL9qDbo
AHCNWttrZkvAKjNkFne7yZvZ2uhcJGj4+xJbe2gWlo/gWG5Cq5EmgHlXZ7St1TxdaHQFyIub66vC
mTxPboHgeNCkupP24TLt+FeBomNTAs5f040KqG6QrMveoBJVm6Rh7xBTgr8DiRTqrn7fitAYFO62
3MuMXW5szIEt8wG5BRS0XrsvOLfggQ9IENwL21yWpBeF8h5oDKdjQj4O0z2c2PrMpSbkmYo/hEzE
RksmrpfdU8kdWj7/yOuUy26cG/vf54GHUYtOOZsuJXDyUxs0/YMWDQsntXuMp0dGRX7xM27Pv8tN
S4DbfT8nRwEECu2shm9f0kYI9hekebVN3qnPMpFR7DKXbNP5dDsC+vmOVBLuGjNIZ3rCaZdzPcwh
f2BPepfLO+BQe59NVuZY+m3CxoWfaeOMQ8zfAfRn6n/rJpqXIPD5ho/TDjvrugBzQxaxVhcLnabf
6NS0yC4eaIpDXJW9/DMatNaBkLmCgKRUaio49HIIR5BUeVpovAxHh4cVugXOY2o9hPOqZxgFJVqj
f9cAuTe7Gi6Nlqi00kSTK/NGDMxvtUrMy4gGjjWdOwa9rSQKd+yzKOG1xZVxHoEid+VmxrBA1Vjo
ZVtoVXjOLC0HaLO/Rs16eEX2xr5DNX7yWVzxSUAWmAU1nidtoqzveJBVzPul5b200wwaK1XaSqc/
L8i9lZ47ivskCoJewL3xxWDxYbZkJ1/D5KGTD05vYA+na7RGvvBjSogqNDdOWbv5bXbJ8XkrDlYG
73J3+rdXrBcKGifpR2f6II8O4xjUKcCDVoFZdXjcP6wBEqMoWsBw+IAe3FdbnaTUY+oQpsn1uz1a
vEgFpqql3GZe/6x6z7wnIpTzGSETthKDIgmPs+qfrq72nEzEYV83HENByB72D7huc62eCxaXs+oz
gokffnmZQpwZ5H8/v2mhghMlkEsv3mcYWOCH/eKz76WEFQfy0cPLJZe0R7+i8q9DZFAve4Mw2+Dk
8laPRB1ZbRXq3FfI58E+CUN7qn5ww/EquJZLoJzzq5hFPOHnjNVJISosb80bNaAojhWLarTi/tNq
TBOx4agIBELaGlHFPT8AhMaVXmGYGb3/bH13RUdarjbesuJyjmKDAOyXnedP17jTf0T5uvmEcDpC
gDD0i7uGxAIyYSePG5bT/5tf40HqJoEQb71QhTNfdX9UdDMsTbQNuQnPW9XIU6cSFJAcckFdhi7r
XPqSlmN0xJ6z/642fNSLjiHg0UOiaBR5/RyJeX4duN7kLUlLSuv9vA/Bwd5/44ONyhxHeVGYGEQV
7Cy5qtgEvR732bzoQS6ka9Fm8vCqiMJmc7QZ7He1tiYZ2Wf7ydcCC8uKDGAbbbxpaGy3S8dXFO4C
TF/kKERcM0KwlPLVX0QYe1lY3EbAegze4DaMDMGtrt3oyJcjnPBABPox01tWNh2XIkTJEV/iB8yg
0+oVZkMZfxYeL/DIjxo6uNaC3GcFoSTIu185L/gB2HyurW66d2dxvGnEbmmRXBsrv2FL8vEs3xXi
uWt67dMdnvPl4CtdhrCalxlGwIDyUnejzGsDksTvWjezc9N40VGamzeYGUyo1bsqNqX9tpriIU6U
rmSaDECVxN/CbxxZBflZSkqPxSVgbvdYnNMApJJ1TmLnBE7pLqwMtF7XwgyAi6+4yzSIYhDU6UWi
b6jyABYclFF7uhHGwEOVEJL3uM1a4eFSYJ5t438xtY0OQTLF6EIIIxg1wax0zbQVluZwflgmEmEq
T78fyUn2aRi2Hk6UaG5mskOrws/U4pTaZliGysDhKCVZA9a0bapVqr5z8+glpm5RLFDgouj+vemS
AUVbOnA3NdmgEAJ0bjI3dEoioRHpAeDBJ5MCnNu9M/4jOqn/bNw4IqpQQWHWuORaoKJtQWQQ3nUb
oF1xRx/6TBcL67TExkcLQkPEbC3mib04LrDWhwlpQbtRmwRoRtIr0/Lgqpe8c9qCat0rL2sbbbjf
om==