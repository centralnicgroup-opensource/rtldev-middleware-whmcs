<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyxHu/DwSTZ40nrsq4KaoW5Bg2LV3ceDHDv8twR2qOirv0PAToxFgajQXe9Fpf/cA7TRg3F8
Em4qmPEE2IxeMnYzUQoYeCqhu4d9YHTyzKC/i8K4+PffWX3IPg95p8oCoK56sIPVQpI/4ubF5qwb
QMtcIIGb2EHQfG+C3l8bQCdghrEbuOKm1KU1vfT8q0kjFkIxeN0v59xFw2inYf/7zWdiJziAh4Ce
QOVdbmTUQoDapCWLgMa/YC4ZOfXYg6+KiXnnCXyCxwRcs8Piw7bR0t1zjJvAx6IKJhXPWQJewViF
oG9qQ7z8slq/7Mq8Bh8xDZKBFIgbq0xsrzr2fdvBpDJZV0YbrDNH981O3foDv1OrYgq4VETFYpe/
Js2xHvy/LdRfOxnVKHr1gBt9C2D6dmLd87oD3M8dgs+vAGWhQr1Ln46vsT2GlzXZsobt4nAmdBke
XnHIbQY78O1E8SxS5u7ds/r1KZYY4+oiTZeszPgPJGUKsBvWqyXHJ8lVY/kuQ+eN4n5dUXW3sjC0
PzpDnDPd5H8ebBg5Y/UA7E5XiHfWGrCUi/rhsAKOOuMPCgIItnUy6wjbY47Mjx9O6rnKXlFRkfXN
5ztASjA2dco36Pfle7Gu1hJrzaoH2id+379sz4HDm6l/ox5FFk3y1HOOU6ESqM/MvQ8ayEMN6mjT
0aVGYuQ9XJDeSBFrkOjNCHq+JvFXB3Osmr+HTOQqiecnDzq4tAI1mLtYUWd5RBmlh4vFzZXiOrtC
xvQFJBliAXJzWOF65nOvoZwz79EO9Vj92S0nVX1Fmrgi2PpqKjzoWXVCKM9QV507hS7DDRyuDi3r
e9+Akx57LRc8Rtvh2JQmPHZAf2pUfrp5vEUXO7o7mRDhmRyvEmOwcBmp5AS5Zf9Eq2AKYPvc/1AV
IhHXyoT/MgFs7tFg/Xe+HsCFKtDvCNc+XnAq2hAPRpN7W0CmvHVZmJZCol+2PNVyuGB79WW8doBy
9Gcx0v2UwYqB4isJsKZrpMSxo/OUr8Jp/kBq0z+Ql332yagnK0oeKfbXq1dw9N/ZmBZCz48sHZRI
VykvFdRf34Vf1sUwEJA6FmiuG8lTLsHnz4zoJzkd6/UJyk87qsCZbEv8J12BbAOJDncDio93caDx
JTkXTQfXbYskfuzBW4Mp0DanN9UlXwTQ9fRw8XcDapc32GTLOEBGJ2fN0NM3c5zol7MX9+xPQmke
fldgJXPx2mHMGy6qa7jkxmqeYCCOKtaqYqfkAMe7FnAwrFkSGpWZB9oUraCoL5+ZIUpNn0I+tLpG
X0PStB1BdffuAhEI4SitRnzbIAe9+UkbnfqFPqHCNDoJB0CUe1JMyX7lQpRgP/2iYR4Jf0jPtwWf
HPOAeW0x98VfdsKhihjHrduU4c/pZgZFi2oKzsUEKKkafNDXnuy/xZj1SMv+Q4XfUyong+GjaYTx
HTndrC2wJtWPP2Oaz4Q5wVBxcxQuscHC+0Lny9cB064Rv0n+W7FTVc3nJ/pO8AdtVr0vltgxykBy
ZvAYWSjfYIJaYW2dHFXPi6Z3POtQfRTLHHd4ofvR5YJk2ZGXCZZxJRdyOmMICqrQ1Xs3r/16djeV
I6Rzn6EN8P6WBouWoQBrDS4cnYWGlDtaE9zht8qn4su9jA3NMnjSCMqNSKU2bWIlimnZHnCpmgQG
+XnesLVdZcVgfHMdYf7CMnE8xkdUo6SI93bRC0ul4d69sM3uoYn+5JqU5kLDYdaPEKtJsFt8sZH4
bR1CFXdfc3dncxnFQ5MGhyYsdsD4XuowxyM8ZOBRvoXJR9fKZP29n+LQ3Jhl3oUmCiFUgb4bjJvP
APyCxW5zXsTVC3YTU4fcWALG1f92mao+24bnYBdBMf8cJ8qcQgp5M8ZiU110ba1MoJMKypZRoG36
85zi4g0cXlRzzXh01azmts9EUi42rnCpTvMpyW3DMae36SCExcJG68P4MsE81mFfvcSvgbsWDusg
nKUHLTWkICvCLCTXZNt+zvtPvCTzX0e/d20PNqUrQM8Y8yrJTt9O2IEqD0jVrvC6vCWXTUrb6e6A
9lxfTQb7QK4w7XHgMAcT45ksGn75o1Z7s/H6M+4tbM4vsnRtmhr4QPU4Fis3xX3/PT7NqAyIuCsG
li+AJGxVI3EmwWVHjiXvnmbg/56z52/Mz5Us/TI8O8GMqn32LlYk/nRGC/Ux/IzGSyMT8PhqzOTb
9vK5k+XxM9GWiM2KTO99I/LgIScIXKyjarzgMCUz1t06PoquqywDfOZwyUARNUugaHHgluOa+8mj
5vfXqhaElBHfLd5C1Juqh+8GPTwusFg07bq/UiBIV1wY66yc14qvE9/C8nQEaIHgNk34A6zr3ZeJ
ZnHftX6rPrE3+N7XS4nCDwObIsi0hx0zXKfVfobeqA+PjxK6cbb4hPL9NZA9yReFagUb/WxOnZZI
6tV+chshZEzurx/vjV4S0zqKRESne3ldalKsTYXBOwkHssI2Eb48HmVWCC6Mw8Woa/Ehtn/5Z0==