<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqTBkJDlgW44TlWi40hchoLC+wm39rLQDkrSTjfKDJ9VP+94b1mCtMfztejc6n9mKx1oVEPQ
2Exs9nKtx+tql8MdmPmGPi8kLjP7Ifc/mevyYwsTeo+r6SvYPxWYUIKI7peEtDZluWSTlo84tOJy
rhdFqhkzM1AgMm0/HimDykHGKssd/loeSghQcUb0Oy937fqJy13CHStX8wGpwZQk2oytjYNgbV7S
/XSYrUyQ8r4bXNjuA+M3uuLeJ5UKW4JqdhZyr0plfkROXcpeULi3S7srFagcQCEQd8a3VjR/g3p9
iZd7DK/eSlNtXLL7AslJBCz9Wn+3ISlpVnR0fwRJyXBL/ZVTFb9ZlC4ISrQqZuEbQJqP4mWtFj5y
ccyWTb3aibua7dLagCH9HTsmynlYr5nN02A4bVXqhonDRFEVILS5yKvK0QGZr4X2vvsFTcOuBThm
AbWlWiXCkWXBPEaUmgRGWf2oiW1QLwwrvMB1+e8DkWw5v7RhAB3kG/Fd1MO6m/JS7jqEXvl3xKvo
RzFIHDmdJ4LyKOfnknlILcApSx5NVJxzgR/htZTPVBbXxMc4N8xKilEW1QuYnBI5w4S4roHuredE
WOmSXNBm917U8Vq2YruxK/T08vmgxgPyamp0mWn1Why+4hOKPSaAfMm06MTNKB/WE0G9yLSYp8hw
xAsBi6QUYafpHh+i9JquqdQl4iNxm3sZb/3+rnEQ1XntOevN7Uv7rqmc0VxGv6IM/YgJLYvKWucN
4s19GzhfVcNBYTEO9GO7/JaE9VZyCDFObEHuMZxF2WB1gYpBAe5TstOfcesKmmTltX+PJO/srSbk
dOMnye1SyBQ+Vj60ppk0oX+UJpV6Djc99nbNUl313Q2LmSSQSVBmk2o1ViQLfxYm8D/urcssODS4
YuNjTfYUM2NbdXMtTkzq9lmOELbmqv6+uxaMOnBXQXc6581ddss0OSsDozmfcDm96FM6VK9TphOq
b4POq0ijaRhaVsjRgvylU6opTjNp9kxpGjnFiNNsBOgnXvqbkpWcWZwbSjq8KGGToW287D8Kfow/
5aMn2Jv0o4g2BkTzMV3/4sg8LLs5XO/H5xfBiUGpiBx3B4ws3GZcsVXAe8wOOmGw2IhNXWutheGa
xfVllVxBZOVAijBqUSRheaQa1C9jeYilEgC/Z3BWjM3x363ACKQv4d1qcn3qkLSB+bodpHtpOHAX
yFSKdV8a8JRxCTEomm+oSsbTlI00ozp4xfwCMLDBGdDAsfFJ1u5RgAWqwAOeitmlQVDlp41bTy23
m9oUi5CHCHj58063x+iQDDWqoan6iQD1Gup1Kc7ubLdljO6ED3KPzNCtIxmlwFCNO/pmLhfT8MOZ
fYHSoLUAR70RM8CWGaTbUDQwR/ycwUyGwEpwv2/JLz4UJ3FDoqtS4CQiGsIkwz+KrLw8/LLUMxFo
UgJqOun5xDQqPzEej/cZaLT1USM/rSxHv1LZfP7Cx+x1rdD7YVJKvSzoZeuuyvCafW2wbW2+vnU1
i68u91SffwcGLiKsNLR4z0YCuaGc11Yx7xzCdYyHIpy4s59dnGxWTjbYfaJCL24JA9OprkP2GgkT
ra1bsPE/S8sHgxFoBvQRbZU6Nl9y+/V7GStgMaa3C7HKGTJgaMfN2hh4wKikqn75CHj13awbdDgh
C7bJc2i8bstKaNysL7rxKFQ30142WPOm6Dj7ibp7f5sxrRaYiiSxDGG67cLO3njlBv15CkO8sqyv
W7DgBYoBRLUC0IPjdzvbLOAYB7aBo/RAlUbta/oTtIHTDstKaF4iQIcSCc+nGsipjr7SuyZa6V8S
KcAyNasOWkvPtT3bsgnGIFgOI9tiCK9bPHoYHfAxPvblbjUPIijoLpdAs8fU04vDBs47jKDv1OBj
BXuTq41xNVkYBZHHSSjYifcdFpCGpLihZIQA9u0XGtR1GWXVIlS17sJPuvzKj/sW8AgV+43uT6Fs
rDl49TzlfNI64V4X0wC1Vz63YXR7awnOqrGxQG/GQUSQmvZdEAi1TkY2gr1K7LNkBsUshW55X4OT
PE69ktCnQ5jVHkuF+yeB7gqsMgXWFtF4yfdwK6Y6z70VMaPtlJZ+CnCG+zQNJfizQseB0pI1JRuP
JmQZ9T79Jv1zHC1ECoroAA0owzG5Q410RosTSwBBpR1GfQ4Lrgb5sDbAh3dY+0vdhv04R8tW0gwp
d3LTnK/me5ejisJE/oR3O4FxemdsJRKExfNaVTcjt2Q5ssBoJBAuCtoNihdwsz7jqCpY/gNRRv5S
YVHD/GDq1S7Lm79E+7SO6OCuEQJP32x3xM685BJXuZ+Wyv383SFB7dBCEIEARy4Q3UogPproMl1z
7BAJ/eKj19TRVdkget6Q/WJ6WIIDautKe72/xvBr0us4Ct4ZuMgE+qZrI6wYs/DsyfPwyZhd4QoL
G7/qEa9reM1nuendOYkaIYUDMW==