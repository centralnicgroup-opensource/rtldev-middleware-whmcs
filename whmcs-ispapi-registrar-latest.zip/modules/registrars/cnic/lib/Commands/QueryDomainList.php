<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpfGk5mqyG2JmPqjVusm6ypnnlmDKmUxCVvKsY0rjM9jdycTEVu7mDpN/OfG+D+mr25//0JT
gT0Jo0LUfAtB0siQ/HPnrI0St0e9sBfxh6GBAHKLSWP5IEd3UovkL6w6FSngd5noFc/bTfCiXaBp
vL7RcaOmdhebXNsU7bPx5mczvv6Es1xv1X7mnD2F190MkJMxGVEUmvU5lWrCQXIzc+VnddXC5SPo
SlE0i/NqUaNrc3Dq33QyW6kNmYGZwlFC3/wY4UyCxwRcs8Piw7bR0t1zjJvA/cgP51qISQZQyQ2E
oVAx1oqW7Rj9rj+a06H/JWNr6Q06m9Yh0GqgjbG8EqY+mkPJ8yYDWcgR6B1/UNJWf5jKlhBuBZAR
ng4Wz0saGQmbpbiTQnJ8G7yw3uxcS9tL+C9JSp51xPWJB0Prj6O1cT0KK0bEHTiEPMFHWgAAiDfn
XLoY5/J/84OKNa5wRqGTyqBNLx3HaiMz9njsuhctCcdscDKN2/KpBV0mExifT6CBQ5rH9U8aUWcw
zRdoMFagEX8Osln2MGZRpQMzk7Lm4PA413EAN4n2cOlOJm7H2e6KmzoSLSVK2K1Pqz0UWiiIRpCx
rAvMOJj1llyzEj5Ievjsq8VBm0UectGw+PjiDIhW6MFnDa6i7jfRHWcZMWg0vT26VHY6AKhrsjq3
ijEt8Kk1qHnJP1VkPgoj6vBVchh2fKPjAk5sjNVCMNQQAgaUksMMmY+EVKRoVz+3NA3iFo92E6NI
VJ1zhc2Bf5uJSM0CCetRJaCZMPT0QfcYVcOv/uYBlpBw3IEOOrpd2hQi9sJXv0e9Ib+1FNdoRTdv
lUXric2mgS0X77JYTZXlH+ytUDyJdAE9zzoIHHxmkMQFgIDZmSui6UKI5ivl5DmI8+BZqoelHzF5
YtHIOTUyxr5UQQeD0xuza1Hp1BX+MbnKx4qt0caR3n4dP6hPuzE4P6j+OR1fUOlekPxLRV44K6ia
zG+s6h1lAMSzsm4fTKXV7+TTqkccxnZqH1YJYJ8WAZSR1d/mN95Z5qiikr1cuqMVeGR0DM55OZMT
RsFOMnVxNgtJvRck3m0br+a6qbhM+OsTwhvegDhtopi90TYz6y3Vrs1rhgWVyR/DR165jgxsZDtE
XZhH8YIi+Did/3j32jnQmUDBX8SRomimTuABRMC71X4ngeAXeStdePAs6ZFY0iXkIS8tn/Yper1V
jpD5bNvGglg/qo0YnXK8rYlMuUg49uJq0zp5BuDq7wcXJ5vbCfRtcW4q58X1W30TKbtHfdXklWOw
w4beFIF6x8uwcNLhd6wGXbzb7ih+jC/fsIydj5BK38Gtr6iwbRK9rZ4qIZhNxphkg53qwrj7cc0d
XlqvLaMY11AKx/xJtb1u3BnWSGZR82moMB45ocdj64e7Scwoei+JZlxyGzK11JOhx3rdjYPvkC75
+EmvvjdyifJdANpKi5YhjTpMoT+AyzIleptGsmB+BP2gMejzXCn5684aTDrKVmIFLupGSlo+TD7U
gos21XkKpYSbXXOS4PGM6ZUWMkcIWGaVtZ/PT0rWQOkVDNmt7+egVvYaJSeHzIPvgRs95FqL9+fl
d7lpuKO5Zsdurc/c+hW2O/KT2zKxhdRFOI+cGL6Y0vf2WhkJQWbE2UcJ/+/UcbrlLo5mw848ByE+
vWNmnwNm45dKqP1XOWeDAeab4St6C58v73LO1P0C4JJT1iFSdH/ZqsRQS/5biwYwNR8sWpDaGEzq
oW+f1nqzBBaYbYekx/1ncqkdlDL/QPnhDenpcJwxIPnhxfuMpRWCxXZK8Iv2x/jqziGMD6Q2slu3
inOoldFCJoGl+tM4l1nAue1F1gUp3iGYpdF8yBLe+BRIQZI1mVuvXFSTyM3jUy56i2tB2GRP4dK9
kpZq0iFMlIWrYAch4R7ZJvaN2TwrrsA/5gsRWXymPCuwiH9bi3xsQExWEUMwr+HwyZbYPvR9AJjN
Goo/PLZSXpNoKu4Zm5FL8x5Wqla7j/V9Tk2+JFn3DnCkdzzZylDpeBPK4snOTTU2LrEuWfwQeiN7
b2u1odex1sP9/RkRqw/cUfi6yxeb7OWvUVyLpdZbhfhFfOuZZfxOf1ahCqMB6BbtHPWszhFOQ9ff
/syMorncoJLD0NsDXqWP6BgoQil41yP31rlPJf8Rmhfi3Y6mKYFmJeX6815i0BECqL6rL7TgbY31
4rL02e0081aRpsqKS4QmwICx2VJNWHADitWU80E4hjHTW60xV2oTY8syCctdRW0/SdB7Pv2JBzVc
kcUAG1hglcy38EWSoSGuEH1k1rB9uOjabT0rnaEyr1uYFMTrR0mBtfooU9HpyUs/p4U7WsFchg80
og3cW9X5HmmCexE4Ir9olAXzDOnVCJs38E/2TAZLqyu5U36XJiYkHuJeI4z5Z8ma/wWQNuCCle85
7yPvRjsp4qXKl17aozk+Ttlj9Ta9J8oCS77sov/OGl39PjFkfmhahXWv6PW7KAADLOdBbNXREsy9
NQ8LRUR+GVrOeZXGWvP14ZK/GC3XKaOhME9cL09BfvDXL5uq7RQOALq8hzuA5UVEJosHuYzrKnKP
DTnbAGXdXS11Zpc047XrRoeIfojB1AFoojQm1NhpWhcZ1QeN9BYog3CoZG1MYlfTTapU2Yi+zXvH
eINy+jHmqyErtU2P/wmY52FrV+xB4Vq6AsBt/WpxDCYeIZSZ87Bi4SB/WWVSzQc4CAJ+dgYLFeoC
WftASIYNyWhq1v1LH1nzOn2FD0LBMAKQosCD91JrB62Ldm+vn2MXJ4RDHrycXMEPC78NX35K0qnH
5B+QjUtRipB30UqArgdnr6pUsZFiYNbGAgvhEO51ybFq013HVSi6lDYTdv4=