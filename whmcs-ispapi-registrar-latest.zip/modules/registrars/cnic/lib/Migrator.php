<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu+NAEvxDP710bczpS7iVYe5MU1vvRB/aP2uTtB/yP5Fd+OlIK8nPULZ6OGRDSIWhVSJ1sz8
WmYO2BWWMCV3up5YUycLZhaDayBsCBHQTy1+gdRwCKSwR8cSxm0iIUGFuBjqHsJBChMO3GntX52M
RUMKU//gpPS+Rz6la3dIaZO2C7S6rjxWA7zPO1VfyvhiMryrRum2muFJjSel29Vc2ae8VMV7LuXY
PUYoXhjzIkr2zUfm7mJxxqZTEst5VFlYBBCLLOp58Nnx+D+ZXOk86wduhqbie2CrK9ImCuCnjuSY
2CT0OQBAmNtD8EHcISFKuev6OxvahfF65OIZxRyIIEhZCpassWUWlAuOJu0KhFpfrm5oIqpVGjbz
ryNuRlZCWcJFoetdRyr1oaQSo/BaC0UnfLCRASi6y76JIHyJMb4WUUvjr3M0xpUTQ9zEgjXBrgaW
gQP031D2PPmhG3/zIEIToHfM22xvAjuf9zh1kfY+vYy7/8WVGe+cI6wPb4vrQ/2aTxOdIqrs7BNc
c6CDhzqbWgILDD54FlKxjwDlIH4DW8jefI6+I5zBFZv7FUljT4Sugm5vH/ehkfWXOLof1j6GXsl7
6XhDNpqGBIerBAVSDdAQFjYn3XTckEvEMIJ0A06+GrE8rsh/Etz3vxVnOXPC9MCrzKa3K62DDocg
hES7L6rJaabFyNiZR7vxAZs8RgZCKCcRGr9abiRdHg/F/XQbrdCU0ksWGbxhNk90oCxwCeMCqFyE
1zfLnFLMDvHvEme3sBe67fHeR8liGVvivA0J46acnAHYeKU8EINMZ/5e4RZ3iGVVWW0UvnJc3BIt
sBeApqr+q1Jxf6cIWivbGOgK0PYSkJJ6ts+EVk1GCIolRAVssTT/jfYFuSpfYZsWk/YkW7BHVrZC
btBuSshFU11/MyH70+HivowplJR1hrKENxYV5CQdtr4tYE0owE5zKmiba6PHHoIBEBrg8Byva9W3
lOllR58cPl+eB+VK4theMNE7SKTUca7BpiwONx0zi+lSKzQqbZuoCS8/0K4cAE/st2Twr8Ct/0UK
J8Lj4X7NIbEpsdiG4YT66aO2/ryeERJtY93MgbW7050acG+N85GP0Dg+XvXC+ziapt/KxnH1kWXP
957gr5t2cClZnnWmtirSJmrktrFZtWrYE2CKcg6IdRpdmiFdxC2UtTs0jVisVT7pBSDSZDULu+2w
BpblY7OYKGmY86MQJQ6ctdM6oETSslelnfLsujhZQok2y13v+bVm6AympyhkyWHhw8tQ1wo1vj9E
vzSaZw2jkU8PAksqLu4E8rKHV6zlcI3r25pXcF4vefY9LyrCJc8ZEhqj3WyEB06TGp+AV1JjJ4LA
3/KSB34umAEYv6pt9tiEjorvGwDCQGtZaedjXP6cybQ3oadF5ROkVyhYHb01eqK2MwO2pz14ooXK
KuokBIChC4Hs71bTNGElr1TmLhOSCZTRC2RNhR/lQzAOlwFt1nfPE8tp9eoNHbK+otGzbIk+Ku0t
6lt7Z4ujB7ncuPJOXJPsKGgsmLx+r0LTrcP9d5D3yofPnXIJPnWVQOhVxHnLFaaDxUOu266aObqQ
5e3KlOC3bbDDKwED1KaN6kavO5u6YasRZ+kJBSfogqtm/QlvXgOB4GVhp908PfRmT3A3/uAf6Lvx
i2irCjFEreuCCo0rxdEkPl4J4xH+qAz2DVxXkHotUpVY6jOLbrIampBH16T6tuAvSYZqw3/tLTuF
lOF+iSipsIFw8SfW11n8ojX3py6wzHIeZMOmNNDXFJXiVx4gdwtZJn+Qg6d75LLiKcS6OrzVGnYE
kyIDLRWj7DBmZFA/YTud6gdzUOSDURHDXoqI62E/WmHJwUFZWuBWFuvFT+SHo5AlYC2+x9m/C0Es
9RVtWsioafDlakyvTTARgIqga/n6KAfrPHnDqPLcsbIu2YP3mP6kP/L64rr7CjIlN+UDu3c2m4J+
JxunPQsXFZrHLQ38HkN/M0vzxgVFP/6+wctt2iMOnuuhPyoAOidQqDewa/DrIlzIGGKXsH5EYGx0
rOIo+tgOddEeFtMHWPsBeVcFQMVU4f6PKruZlseYPn9d7mTt/guR3Bpy8z0b077d8oD1hswRueDE
JWwR09RaEl0Ysbw+JGmQOGxWb27axK+0mIyWboppwHTgdxBPlC0YUNB9iMdSi2tXSZIAPbQVyipB
FI40L83RaJrc8GgER1s6yoRX/0srznQzK8KQ46JU+Xn6oux8Tx/5sHLkVXAcfIvezaD1oHOhH9aH
nokKPEg0LyyYEUe7quNDFcPGhsmroYkq/PMhh/MfCDULyG1tftMZL79HgGGTe6hrQjeKNq/8FNlp
dInhuPGrqjdCHtk+3Xag5PKF/wEJANla1bV6vVw9ftrlfAJQvDC/Cae4A6NdMESBrcKHXSiBua5H
GBTHwsCTGA+vRl8PMgBDPEvxGmq0AYvhz9BPODscA2ui3YIhm9JrJjStNquA5gLm7oqgsrO3HPze
cXMEukmfffNV00SuslzGhm/25HIwtJyqwYNt4my7c6YhKwgiTkwwLaZlvO/lRTcNxJ8A5tPd01QP
N5jcTY9KqCvQ40RXgL+l837ikiWvCucRmd06ho6s57XpkLnf4FlIZZkH6kHS0Sn58bAdVkSN0tOj
kAkegay7+4JRQ4hMFKQECDdvljKF518jZH7GO9O5Lee6YoyZi7349cOiTEvejrl/7iC9HN9CNl47
FVInwpeVkChJUNg5Ipu8XYsAStM/6h2AeJd9XLSIXqazQYoJHVeLyP9FSi0IjceE+cYnzIU3nTkb
XMFf3d20/AMOqQ0+B7wqo88PcVnUrJBbjOIUcc0i5H1HFtamHoBSHUh11czLSLtgsK2XqUvFJH1/
cVC7KBXnFGYUYiUDENQqaotFWPulLB+Zyq17vTB5qJ0u0EiIjgyG9R1fdYnb4WzA+s/1Z7jaJnPj
9HctfjKeLJuwp9Qc+/fyOeD0gx6GcQuuq/mu7n15obAtEY/Kr+5WnnoFH+Cvs/9QXgICCpEgbxrL
gl8xCxdzUIYXHxYMUUdrOzGW3vQjs+/idSu0fBDBRQYhd3/ox621L2xoUyVePBeW9gBo4fQLsCXr
dOULr32yyHDaIPAAmd7x8suuBb5doSuEGx5/2+/+UySC49fFlinQWvFgrJvjwtrLPcqRCG4Gv3aR
b5RKLLs8umDuCtZjbaa2SXBWTZeTqM9scAEB4QisNBGK974I+GcK9VxsAMD0qQzASyZMH1E3YTIg
SJl9bm==