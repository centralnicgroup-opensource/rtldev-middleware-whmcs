<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuyHZDKUitGQvzyPzbsGJ6gLG67B3Fc6g+iTN1YSYOqVRXVZZpPxn2ReIONKHVRLPBfQSrgc
ZZghciZrWO/mgLTQdLaYEXwq2yR9bRQN+xcCq/oqtYJ9vlfk3SmC2HQwrpevEZK/WnxGjo5wpiG/
xIwHmbKI/bpY6HcJLg0vyV6FOBF51deJSnDkLVfFL/ZzphX8vh0i9FiW/1ddLycmZ3CbakcfXJPe
8ikV4kpq4KCGzspNbeqJ+uIev4NVKKZPGtafQq6t+tDS45s8igTjfhcYSUaERMZRPp8H3MBln827
alq7SmZhI9udfJNhuPEpPFQq22SS/Q2VOOL1pgZZ1eNYDX9JqgcKXL98odv9co1XDt3OudPr3gjZ
9XJ872j2fiFyIPa3SXx/k2BR0phVfbb1LScrcGbDxc+VU1A4xJ3ul1IADApuPjFJ+F3JTX92xjjG
+vrEWOQWtvEBWJOq3gHXT9qp8P0LDzdPTuE2QpYrRlNVg2wmoOhp5TKJFPPBrFeEdnBYOZLle9f4
BqdWN9iQQRhq8YBDR1t5TGk3sAW3H4o30SBNNlXt8vAy6CDR8bNiWBWBaJ2L5KHWq6VA3pToD+BC
NWYwy4Xmse3zUNsnpx0HoBdxVdo6rS1a85CI4gsCcZsnUbGZIUGQioQsd7RPxF/Dn0e+Xvdm7V+q
SVVeFrZUeBi8VNMbXLj0dHbYeTXy+BCFNr33wSUuToSPA4wVUEPbqux04znvJLEk9hKoGh+3uG+r
Gv94D8yrryh474ws77yH7K3WH/dXXSSuhSfMynyq47njlkMdSJTcXoSxCXAK6apcdxy1Vmjh2ja6
TxUqHcbprhKB1T8tBGKUWgRiDY2SlwGzll3CvLaxWMvAtzh3pQpkSDAyR4zyO4sZS4monr1/ZUE8
ldgAq1Z4s1KLEGxBIANbN2qR6AfUiAHQ8kLv8ME4Juvs9defhTKdnnBBYY0p3dG7TQIwc/ggPOw4
z/apB4tz96+eZWh/5P6fDQUYFqIk3HErICvYEq7xFKuD2jVdCuGckFAhDMJfg04rlyEtbJNYqlgA
A3vjDMNZE9onxW0YPo0FoPW6v1mseqr3ED6DMcbetumdpGDilTEW4spNlon4+3BpcFJWh0Qq6N6i
kJVMl8/WTJbjkUuOv1prBifuq6RoVmocJr5r3ShvUnESnxjsAHqScpJU8pYM98U/OMGa+MaNR4PF
3B8x4pLl6Tu2xCl3rx23ffPYZ5aghirpKKgu0BNNTMgeDtAuGFzLu1PO/akgVIfr9wiDN0GX+LYC
Li3HhKX7UaiPKKZDw688SkYQWM2sEnEgxInbpPMUE1gUV8w1sRYnC3KrxNxirDKKgmcHhDHn8OYW
JjY3y9DcSHVn/HBu9Ahyr8V2EXA/3DZbAKhw2kOvLiPdrlx9gP2KSSbpMepQGefQW30aapdOscAB
INS8vTWzMKsbA8MyiSxRB8mXS/8RCIPW2dPEbbzmaiSBrqXHVZ8/EL+PMcsTY/5DpwUVhyeGktJz
jr690WvP2SFkVHIEJuZi0/NecGvN2y4nwyMjarajWLHfw4cOg30ZU8SZvTyNduD0l3tE5wzs2FWV
q3iIB4f/AmclJU+QLa4WDvwgUzubzFzFBDlv13/CSqnsDX0xNS8I7A3yATu9gkYRhoBrNg5eG9E9
wq8qkgYzby1no66u13jDEcpPMWMrhRuu0fRYCqvK7rJlMvB2PHSfFhp1tVA5V8tiDWvJilBr3UW1
5EHCgX/3Wkoq13yjf5nGD8sDdnjKwvZLhvw8rGjOdpJPlq9OywsYkVCoBU+fXDXsuKxLCp2nUoJ/
GJtXAi80v2Zc1fa0ixskAJYxyBB6nXx0vLSphP2Mk1gBePwivZTK3Fhjo9ggVcZRcvzERuXVOmoX
LRDWj1b/omRTjo3hiYitLlke0TVEupttWm+9HB5kG12U6/1y42jhPn+C84IvK3ONIOX4Li+BGVBg
WYH8ktYfywtYE92wBjZL5whW3r+HsFl7C0m/x4fD/yWZ+rdvX7ytfK45eotLrFgcz2J/KMERL3Al
iLiHYMChHMcmSi0jTcKcsrrT/mlciAonUvNiSO4EaXH6Askbnj6LyAz12VcyU86aRrO9bXmQPtEY
GGCmvj5kAGTrP82D83MVJd5i2FWBwjIoth/nVi1uIest4X+I7QzuqazOoPQSH65k89hJ5bZ+dsuN
rxIHQ2SOdvWQT1aNimPwY02mkK5F/LzczqQ6bDEvHCDVQr4uuDjrmsFvLphXNkaze/7Js0M8dCnu
NuONZH9eViJKhg++gYcos5ujD4bjSXK6SKxLZxOuPmLtU3RGbp+6TU7U9WCRBUUpU/U/ENCajQGW
s4Fsd17WfTyxIk0B/sw1Ms6z8rsCK/yOtdYsm9EfekOplDpLWjVXA9Lso+6O45VwalnpLKRkx8Fz
icq5nQonDKckEiOhgYNjPCxTIDjXz25pQ/ab6p7TBydjTQKZbLwFSR17XJKH2y2JVCbQlmz/y9sL
Mhit8FThZGoxn5o+w/ueYKxhKpcCriLTBN0LYswv6NFHhbHBO1UqVPW6Gka2ZRXkp7B10CP0gPzv
4DmD5MCEDgADerfHPM86y8A3M2Gm+F0CuVq+lNovATaGLCFN+y0Fj2haxqWfGBqfEpvTzGt+/Nwu
s6jdUqU+QWXBA42nJ3N59Xi1Mb/zllJ8YwkIhBDdufsXRqeg+xSQEp4qB0NI6pMecrSbEWGqLW+5
lesIjAVPfQzMYZAA3Gp23NSbl7yTXyXXaEUuo7+6plXOZ4BwBwmpenya1xLoRhh4GDpw6wI57LF4
n3vUHi7f+8HPpnq5gNQ6LCdsDu1dcQUUSbQQAjYQQy/L6uBse9BJPNsCV63If/kWdW2CO9pwKdCw
jMGzdaVVvp4m3l4YB4cKy5QAN3fGpdkEhoRkhrw1zLxcbZNNLC+bxCy75zoI1ktzcS+3lsw5uugH
x33aGi9F7h8rAH0o+5pHXohiiJgX+ZJRmBILeNzsMbKEUzjZQUjmC16snt/LpC0shsGPmo5EsA6H
+ihe3sxocsatFTbpMrtQIr76pv646ubFr0/ohigp/WUXXEpQQB4YWi61B11p24OKuOW2V9Ba8E5K
v2dOtMa23cm+41fqdKxcBueptuSoBY/RXBV/L3Fw8m4ZiAzX6I68vkMocZ+UTG/w8MKMJZuSdXN8
Q0FKynWJSY6ttjvRk/I8vSpI/AvjuVnj5sRHrTU3b51cmdAYhaBZMCX7iyz+TVzP1XQpxAXXPFi7
xCHxufsVH9PwQ5kkkalGZt3Mpf7wFggSQzU84uYtjc/5fJ7hQu5PCgtJIn+O5jU1Ry94ifSm+bbC
zjcucnJOie2xHrLgLWTcqbq8p5s0uhmPIOA4NH1CTDvEZ4ViYoOUU+cZPe59mW==