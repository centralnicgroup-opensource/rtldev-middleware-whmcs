<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/AmSszWcqX1VGVcJDCYL5MERPB8WTpJUFcOIJCI6ebsDUfJjKh1NrmUbe6eui3Hbe2NH6/j
72S2+zelC7W60EeqSPstnBaGDUaRIUwbMBl9+zK8sIJz84tPoroYSXSm2aqj2lqnhhUCFf4FFUzA
uwAp0B+0qR/qYaNgBP0oVq0l+WTNUqxbgICCL5dfQ7r27FTdriLzmepqPzKjMyt4/Yv2f6Cq+lZY
oSTj+QLFfdhMhioQ7ng5cJSlE56cseiDw2sIc+wr9canpzIdjQOKVO7usXY9QxI7eaIT/ZVYkk1c
yi+6GrfxtakAX9AgvfXUsk/sImIQ9NCqUYC5dkwO1BkTtb0xDJe6OALTeuxGK32BYJr0cNpeKb9T
fjwHmwjOo6rdxEKtwdT/MZ7MlZi7lzFh5kUnPqYstdz5d9Ngcdk3w3Ea/IQps18iEHCAjKDmwEOz
k4Xx+Q919b2p/U2852rXnZBHkwkJTqJQGIgimtez6f1kld3asTiRvyBcvDPnE+30mBpoT+Aw0P6Z
gQHMPUt1Pm7Q6IZXGq0WvgSYe0vKh/Z4fNLnMlbf6aTi4QcvFTOOwPdtkxZLpZIOGoNGgnZnP22P
xJBxLe+uzhNXHxzpXpfxEFc1LziSbOGff0SssvII8dsI8nDVJGU68lS6XWE/DO4pNunxZwxxzzqC
eeRq9sNjG6cnpd6+nlWaB318BTRwygKfODvgsEa4VRZkecaKIwzrzIIKj2UdQ/ZHxsPaXnW1chXj
dqOO4FdGeS6TJkTrP2bMq7XT6pQOUJq+RkKn6uFl69NKNAAoOKtPWk9pvP0b/E9/1NkePZ1fzFN2
yL6dFOPSX9wLoA/PirDuMo/ow0QAHo3eAFEI6eovojpKXG==