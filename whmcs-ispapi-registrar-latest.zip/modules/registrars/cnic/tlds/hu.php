<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpX4Za1Mgt9tB/SROx3vMZTw0HJBfHs57ucuzNlXTcYt6Vlv872YqleHUBQFnMfa9kTwpmSK
TPPgFi9u/iEnTw/NMozIQDVPAn8A5ioSEIu46Y44RmATVUck621H1a1ksnrJ2u6n+P/GQpCMmlxg
/EB2fjVLm+FsyTBAPEF9JeUUuk1I/VIFAJtRcks+x+LfWIZdhrqx6OxR4YuPpCstct0/nug8PUrF
OB+en87JhB2bfR2fXzmC7CkAIQH5dLA2bI9jLOp58Nnx+D+ZXOk86wduhyvk5T/jw7tTF/EfxuUo
FYTH/rtP5IrtLQBVi1TqZy+hedWZNBvFHTJj+R477diZJCmIaTtgVr+qkNyFOX+AffbpuaG0CDGW
k2kpTBVA9nLP6fqtVa+MfJVz+T7afhFVoqn9BdBJLbHjVebc9CVMi0t6MbvN3kBDTwpQYXAno8K+
1+QHQO10Uiwvg8ksAz9OEFoc1pQUOvX5KXqlfi/JQWSV+2hI2Igbtn5z4tTGYyy82byASeCplrok
vnwR9pG6ToacxQxKfHlu4Qf4m0lYYlyw/1RBWPpnSWtZeujL/OxZDx5ojwt/+kmroQAI+quTQ6kO
3XvQMTWwME9YKC28101USS4Rm5JataiRkDP5iN7QJJU0Cc7eAwUhv36FWlFb4dvlc6YrWK1p4OhC
Ci2TfwycTG5uxlV03CEzi6Zn/OQLsoFqwZk9+7l9S5d7jqjFMsRoQByIy/Bn/YLOx9Ugw7JZkSjY
7YP4lAlH3HEqbq53hYufA2aP+aCTIuBhm4ueE6amyzZlUQq8y3YgIpb38tczt82NhrnUkueAW15o
20AUQH9vJXm2MHHYh6V0arj0PEvIwU+nkRRe57OINpVaxAePmdEuUzEuxG+WRzV4D4InnZRK6xCd
7RnFBKuTcAy3ml0X0g/Z/R2qhmgzSOeqL6usS4TNl9pwOX+Q8qcVfAKVcLVb86oDaPc7vbijcv2K
dee0EuxA5dARLV+PgyDBPvAuu7v7eVa+lqFXZwzqCOKhVH55GUQoQZ9TvFa0toyNbgj0t9hJlPVq
cd+88+Ch3SWng5EU5lIfIQrnc5G3Xr+JU92ZElwfPEUGiOaaoGzZV/1xrcAjeHZ0AZvtpZHiEm2k
eIH3OLKtx+6lWAz5qNc1WBs7HHJmV4ZJd3gyr32DyjkdxUW6F+hGV9YQI0F4VXVU/2T9mHbjy8xl
YbwytvgeCh8siWlNMj/Ee/EsbiAC6RL6ZNeSAIAgNzBATNmOzUUWYgDYjzTM17WUEi4IlYo0IMQ+
N/xHNwbtjeN2D9lCVkVlgiMlYGi4a9kcoMDafjj/zafZj/1tLNiO/uaScV/wUVZjDNKMnU6kqZZp
yYwrEACSNNkRR87t7sa2eMW050NYTMtzAmkVTDNv9BMlw/YB/W3Zum8nSsd7tIxbFGFuoDS0qHz2
+ZahtcbAyiSbTZczM4a8Lu5zwol3l22/SAvloLcBGc9WRFWuuxAZ0fZUjSQZThRPk0dSSsMFlqez
Id/jfGCQVR41OK4zMXdPvUYkRtatU8rLhqFX8TC6GCTFS9Aybn8fmvHKEM+yFk9Tlyfb2n6jJy5Z
xTkaJCpn6fh2Cz/FHSEgLMOn7Rj4Oby3iT1JcxeotOw6Sc+Hx+iAlETkgXYnpn8ksyEaffMsVBsq
/w5JTZHu8HzUE53/2djJfXx8OSt3T+SPb+nlnzvn1p6Xdksyvq+LmbpLoTTuZwwkOzH3WtWl3qNJ
3AKQ968gXGZF68PFQn8uFKL+LkyiHcQvcxscmxZT+UMHCuLVys5pZaltMORQQgTUJVDZFNRdqxWs
iYngriXLZ3Lz2c+gwANWyUzSUAm+Z+zSvvj3TDYE+hSqTkZS6lG8ZqTqtNuk6MUs0vvIUiKBZ+d9
JGZjTpsI8pc2E1IYDntHM6/at03Kovmj10A2CrkfZoV9pIKY/4V6+OyWxW04x507+dsn7ZEHTVLD
dJHbble/zoHc4n/rzrYabb3cBUTbv3S7MAJV5vLpGv1yQIuzD6LtEZ0wL64pV6rVE+bUrj0spj0u
DLPddzyzxdMv7wnqCG/SVqTl6R84WGWCmU5/zwsK7CEQFmwjNAYKs/+lTW7n6CZrXSwYNs9HmFch
4Fds5VdjP4MdOElH3KbzICbD9ZgxyLlHo2BnUB2542lKO3Bsvfnr6nkQMPqaT8IwM5wO0zin2E8R
VszA9czQicntrUug2cTOKbp6QLCUHniHGTghojFvp1SnxQ77SLaHdqwbS30PzOTVzWCSbCetDNzE
zOe85h5QJimYb54J0hfRqfVPa9ekdscnkWjIFiGpc3UfESUl4ukEzciRFdyDVi7RD9VzxS37wypf
H9jY0vaTxVOYDTv7Yru41D/zIrT22waF6WIkRUkSm6UFjyaJWXe=