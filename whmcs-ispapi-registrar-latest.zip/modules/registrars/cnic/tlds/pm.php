<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzv4hVWu1XR/7iMCEDlg3oh+r2d30Q5ofjKCB6XnbS3jwOraJ3VMiQl8eYwiapgQ4DniaNVK
1hgcGMX2niu1r5/EaaoUJFoF9wPqoKKLfUxkSXc0gSuvry8w4JWp+QPG/H/1znnuG8j93IVELDDc
pTUktNrVPuyVYKnL1D7wvkyfFbYGH61AhzdgoT0+56SbcbMyYrq/0MlodzQl8B6xB6VjBUQxV2CQ
tHVNfXjjwUA1qkUkUadGTKOrGpBjDxAmDc66XLMCnI5yU/ZVeuMBY1kf+Ay3RSlhwo2UJX6drYQ7
8Wv7NGUPLywPL9GHdSKI1fe7tkrzrPAcIMFFHGumV6Aj5x4gIhjeiZEe2rpuILXSyPuReOvjNeJw
5vehhUcdPbRGoUcSI6v01PzTWfB2LJLWuSU/aeID393GwXtFhSksW7pKS+apIg7J9Gr76bcOJz6S
2PL/ezBttg7+C769FoOH7qy/KD/QWeRhv4CeiSCeUjM6vMzwHaNVHczfgD2OkMq6Axxz07xwgkEO
MuiJB2qZRn6VNW3uo/wKUbP/IeB/ilYbXW5G2md3nrw40pIPWy1wpWxSxdPydtfz5HQCcnUlOFOo
mSu3sbXsZFL1Q/IBY6JVKF/phx1JM7jI04M3ZQEAtseTwVzb3Co4vmIbNoXE5o2azFEz4PO9InzS
hevPlnroFzSrGDjYZY5CvrNKowcJPU71phOR2xlYmVLMyQVfkaS2FiuVrhnwWAwFXOCdsA7Kj1rV
ShhUUfg0TwhScXiJ7/nuQ2kdnTtl17XCA/VXCHG5on9OP35PLU5NIXzamTt0wfM7D0gE2dHF/Jx2
LfYt47yqAVKw6b1zFLXGaro7GQyNxEPYZs1z5QC9+76s12pDv2kqSLgxM3zll9Y9FaMDog3qJwji
iXsXIh6/c2daN2q/zBaLMqLYpFIwnncZKOQb72uiM+hhdJBJd+Yp08/uOagTSIFcO0/zmXiV3glo
+mMGj1Wmq11QYwZ44ozCOG4+ONBqqshj16Ie35HKn8SLd7Q1x97j83TIYnpThMxL8oP85tbkJPwc
6RsypYHfRyT0cRLyZZFNAIt3os1dYaVgsWr3fHHH0+DRibDddv3q2k7t5KUDmW68ZKlZrzn+74KZ
zfJ9VS1wWGr9rQtbitXTz4wZqBH3ys3Drrdz8i7vqGdowqrdHjzhzjsWo5HiYLIqW26wIHqDMLXN
uyfp3tffRlZqOBNcn4s6m86i8qTGxjgL70z5HmEShpuEhYSxRxckmy+PlvYyW1KCy2NKSlGpN4Qr
wop1j6uI1gB4oSVqWbyYRYzjCl0vHdPP+R0DpOaSsod710Nyu9A9SmhT+wRMCIGblSGzLFy45zSB
TE5Sc9jwaWcYzYrVyZIjiRsvzchVg2Mc2h63wWINXrDB68/I02xifCJ1OvUat/wIz2wZcG5Cwa0x
QgimzZeptGHVTd+rupW0cICLK9BfIOeMBgzd4+7babS8kVg5/g5MTVXc/z9Kc6aoesqLxfg91/fz
fB7HUQt4RtZAZhJekxUHKDi5NZ6uHOSiqp+7MOnPjZf5UR3aTgJqKFcuB/ziPSVDpwIEOIZ1L+GG
TVR1xE8DXfc4aOpog0skOZ1bC81eIN8TsG9mDkc8MVpE12lSjqIv3sgUo+wxwoQ8SumrQisQA7Mz
yevKaqZEakbQY5wpFKK/hy+Dp7IVGE1N58+e5+w/h8XKyhQ1VDu2Mn05Cluubn0EAcdWUPfmasby
LRcEvwGr0J0Kzn7Zz/NsRJSsQknvJ+2VFNZYih++jDcOTOx1UB/GoXTNuIUXo4+3LVYOTiQaUe8G
kYlRt2+UDr0UGkfvF/9XnALuNgbVKhRrnKWMCtMbI5opI8mElwoCnwW3JQHpm9G4alJJHnHL14EF
nLSgG5sgmdh9R0UcJBWd71yX9tWP0wj+wuACFlMA/sKIo/PwDVdqXV4bcv6d7orZ8J+xtM6VogFk
k23IK/DQENyG5eE2SCYEwjwMWKvxTouusJdkqMnClYjkSPDmWm/ak+/ZdUuR/73IBjHp7ICN/5pM
st8B4o4ty2BW8EerJf2I9ZaDFnRS2wChRUORA38tUfdeFwSNW6omQ0IxvQmq07Tlzvf+vo4q0XMN
/fbTnU+Ubcm/fJ+WB29IST47ggHqJDT7Hq0xZIA9tYIKJanj+PbeVFsUHNfGwL046fjv21+sNDNV
3wSx575w1BEx3/LvdCCRSMd+/41yEwDhNf4N0BTH32RvhpF/vnWfWV3Xi+X+xEvJJfNryYPYQwxM
ifR79CCrqS3eom+I8F6YwcwGaF3u4dhvsyxgYUW5bP/5GZtpt+nJCNJHOW1zbcgHaz5oxSBQKquF
xsSoaMEhE6XR5k8qz1H1y+2lpoJuFGiWpvhDNT9t7A34jkQ4fskt0FzdpAL+Nkqv3eMxkKJ8gmdq
lZtU6JjVt1BzmhfDJAexINJlB+b6zis/owzVTlJfZxcpW0v6Vbs6C2DhwcyrOdIZD5Z0QivYiCOv
fD9Y23ifQ6VbvxmgsGB/JU0NtpBfH5tJRoo2SL7r6PRZeN1//mcM3eAtisdU9IQy/+fpvWwlf+Po
uPusT4ZjiDVPziR08Kr/PxtkZbR7GzXMeEZ48XJEN5iEQII0Q6Igq5kwy+AH8wWuKEZq277MO3Di
PC9mUonmEh1EhIWE+H/hgONbX2cdTxICPG/ZfUTltEBAb+Q64JFKHpRnt5eQRX/jxReT8vNUVUWJ
6OSBczT/RTjQ6Zq+7/fFpWDkx9ZZIKhogHMY9DVtCKpHsYaUVz0RwayxrMcUQchVpzt5AYLeEbDj
Kemw9iTDrrA38S0ekaK/TMfr+ooAKGBImDpfw/cDjtHwz8+ksjUNKts1l/1MckW2yYiC9ek8VCHI
yIp+ZhcaKRG0EhYE06tjPX8xGm2mi8ILIahEPXDWb8UPP1eDb6b4YbpcbWubAbLNIxkDmWSAdBVy
YdfXCP2St/obBLVwhpxBccVk8A2pqdkC2qmA7NRFokYXv9T1z6sLjJtEAy0Ylg9iV6ustqprwM2W
goenGWIfB4Zcs9Jh01JjcCt+oj1XHfUJgjZkEvMqCb20r6gN2spnNzwy4bV/kDLOGh127L6tPZff
NOINziIQ3YeRhq/L754849/oKavrZaeSpnbVJm49tlU6WFYbBB+S7aYG5yzboesQorMOLSJZ+vMC
xAt4Hhm4Av9CkE7Kj/W5PKKQXNBmm/nVh5xfClBY0Po99FgZoa/p+Sx3bPBT13L3rxLFSX91Z1mX
lsup96iVX4e9rFm4+aHJwpMx6Y1h7vYPopkDjLTQdHPUdEOac19IXI5D2lFA+fP+t5JU0jNcl86I
QG0z5ju/ZALPx/7HfOARnIRgIPkc+U42lxbCyb8fC/p+HZkeVXqrvN1yGeSEg8LhLZ2oJm36ZoF1
xqb4T/3l/YZ0GNpq5GzcLdt/q+9ScVrAE8Y/C1WiVtgIdW/RSqLwFVhw+ptR7ARAjdYU1SOQhsGY
t41zL4zgNHss6+dGb4aDHqA1HHBO41B/2quRx01iEByf9T9+I3Kpgz/BdswOm4pDmOSahZ+VJ6FH
44aHPBjg2buCWYmuxbgNrXmeSzT01ZTl26RuTvOBE7fANeUiQhmmbof8uUR+n9ALOfBuVIC7da0X
uSSoi1KDK030rxazz1QBy84dxftByu/ygZb4I/ennkfG9ADLoYNiyTO8B6TscN5hnB4a8m8buWZa
sXi5pKpLQg34NTOV6zwwpznAvYeQ/KCBrnfUumD7bwMqi0q3DyJmDvXj6WRYShU1qDSfvzJwWQEW
iUm4JX4v07LWtQSBxvrSSBticZiCAuT62ZPEJ18Cq8q6mMGEGzPliQEu07ysJFlu6ma3QaLRRc2Q
E9ms9DCuZJiZevHZEMg6LD/rxedLlojAEG1jxn4IuND+5kwLRd1a9kYURdIoelbs0qSBDpdik8m0
2onJd6dk0TljybWZNxf5+KVOnrepfzO8923WP7jsPAH1JvZ459RbcVYtcuqds3/hk+Q+ojsvxH3c
tbwyTs5n4EymSmUD9m7t8oiqdQj/UaW/cd6HaWsshA/+NciGCIfn/9g6Re2/p6P6RBvCJXt+jgYR
aSuC