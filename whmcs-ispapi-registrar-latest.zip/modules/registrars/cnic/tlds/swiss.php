<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvFTyHen9ifTp6naELMv+gI72PYfVdwlXgEuYOeNWmrIVeAIuLPDbHPG0VlSHrZ+4n9kn1k8
CZTKWfF0vZZlC7xIdnlGbOt5JEBbtbIPzalFKOgXf+vWDq5etQ0XTQmP9OsHErEnTC98Fl3iNJb2
uuHus3YWqTMRPXWRMVGc8y5NluYdMIJ466KVKypTnVMpErs7zB6+Ytpow9kwQzzY78qzieuxgm60
iU5m55Eye/5YBJfR39I4KK5mFWs8mg9dM9D9LOp58Nnx+D+ZXOk86wduhrbgMgupDtppKoQyi8To
e2KrYRcl9OVO67IdUmKQdJJwbn/EvvT9zSfISc8lrqHuHCDZ8yPn/ECzlXcFgjxF31YAKUKKNeme
BfUpG9PWn2RImiJhrKfsM0HpqriYQjiYgkBTlCSi1/NEZsulOIk8f4UkBje49+EJ7dD70wjD+dib
lTnuiv59wqaX8e4pM3BJU9rCbxGNvtOJQkElbHCbTJUYNrptNbJG9056/JPGiA/7MkfUrchJSuyU
4QDxcQEya7YcMwLHhMj1mkso2PZ5v8snma/kZGmj9eL7JiaABSUSs7xz16vLkEMOkyEFVqO+2AnZ
pzbDgdcpHNsOnSXb8sZyW9e+UeQfsTo9GWIZg2v+futiwYqn8NrRRlat7Y3v/LlMnYf0HRp7MrW2
WqR1wXbdtjpBpTgxpa1EBTa/a0sCP9W4ZPt6t8sUOytbid4Xt7lOig04cGTi7kri4NYrpb/M2fRL
cCgvCWR/sxtVnyu6UuO/3rBOJXxKKkFIlcSJnRZSL0Iccn0Wwbn8Oen14htAmFpzMusAJBWe900Q
f6Vk9/6rlNTteHxAUXG/cwd7JkC6aTvWXS3war1wG1NS73IsuPRcCHDBamFt0xnAABxkpZ1W2F6v
WW/ojrmN4IJ8VM4vLChjl1OLmrqKyeQX1uHQYssjJud+254rMTmsyb8haB2fMZPYAdQHdLPgtV/C
uwwPgYj/xST0CoOrr+UXxySbWKa9zRN3ls7QoWlJlBZ7oXC5FXGLryjE9ObTUdiiJ9FuBDWKIjvC
NxqKcBRzu8YQSJ1F8NB6DZI0xZt8TucwQ3WNcK4fc5+v05/Hmbpw2chuyrnryRCmvj7pieDKEP5Z
FxpWLvADZQprkjHAQsfZrMiNjdMNnaYPYzReAzW+fEQDgaJatKLjVPscRIJRBajUL1wj1dg9nyMc
ziCaNjxC85etvnyeb1fSEDOR92ir8qDprsJcp/nEMYlWPrb1rWzjcHJoR/hNVpQ3yeqRp8R3nwgr
Xfn72BuQicWh58TNg1PAt2x9BaI9fzPTMr1DvoDxxeDBE6zIkvTMh0i2WXssel/qmeoFl29ba/gG
0CdnCsFS+fQPyfRY+JfjrIY6CyC2cElaXeak1De9kLtKyjxnTJwSHxnkIwlTFKnrDBJkByBSwMzZ
fWb29+T2Sj0PJWxf1wveI927FxgmBJPCKwiFI5TaIJs3/qzz25mTPRp3tiFK3CwgorPH3spVhdBs
NCk2AnP6APGz0MyL+o7+K17M12+C5cp4ea94bvDYRuh7c8att9Fk6Gr9uV/Bp32K70Rzj4lzULzS
v6P43UXA+whtaWwjDocK9HQ2Yg41xSMo