<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpIPr0KWJYqgFLH19heGHO6k60UVm/ZoxjcHItX/QyC+X0DkfWYWVDn8pGYHj/N/DPM49KvU
fjsdxHRTtxhGT2RUK53ibrPDv2gO7JB08tUsqAFkTzk4K0z2LB6lRLwRh4zizoN2f7YNusMu1gg5
7E8JOoda6CJE/8CXgTinBlj774WfMNpiI02Mv2ADDNarU7VSiknfIR7AzNn9MLRA2o6gozfNXcJb
RC5iVuKcsfZ/wHqRJiFs4JJQpjIvFkims/XWPLMCnI5yU/ZVeuMBY1kf+Ay9R4qPpLj3mp0/nl27
4lm7TEMDfoMfjHs/gvcWY6mlm+A+9b5jLHq7ZMRQOnzv2Qkc5riqv12mGgMpVZcFu9hAjkFaJG++
M49LQRbDawD6qM7fD6wA8NQmAX95XOf5H5czVYqpw5vsjen0kI8r3lhwMijlx8yQ1aV9akYug2ab
7XyrHGLiLsWQ4kKzC4kgowMO0g5O/e/f4TXM9p9ctgOi8td+gm7YYbFtgBJWCXDLUWIhYfPNbAjG
RYTJinZK7rKwW1BQ69iZJ+1YcmazX3+uoITjll18GVJtOb044o4CS1ZB1W4c6MWmuvWvX+QP7CBU
uuNAqPTibATa6VJU9k/yXvZ+dYx5sOyvqe4Aa5CSHWuqdQDx15um/SYRlp7wVeHh9SsCYrCLPGqw
BOhDTKoJxxvZMXkl7DdoYNLj6tgFuvebw2sja8nEV5VQPO52UKqByn4LI9W6WnIQw0OFlju78ELG
+yH5NMTSw155AESMBpvoxIEhG3qkSCOglfNDLCk0A8gjcoaMZSUr7qvGotlkad6RaiC9e2Tma9KS
mdg4BU7BXo0fE9OFqvwRiMsC00mi5yvokUrm2UPrGmZhLHMUNfO3CGVlwGRd8BZ9bEeeMNy9ScIr
KImruNac/6DoR+tjrVJph2oE3mOZ6UQInnKmnJKPI4kyTQrLJIjLDlmCJZl8aTa7CYE12I7gRVEm
Hn5Hdlx+SeeUAYV/Nnoccs0rVuEX/R7EJb3495Kc+2rX9EqnwrS+Kyjs5UW7HvDRjR6np5TA0f1k
bwr+pjKmMbsHR5Y9HiPuH9ys9AttHtywJYZT3PTSozt5wk378zXM9x7J6yBKMXptG8tmxcTFB8YK
U0DULLGNDSw4d/yK883CQg64LtU+yMN/jeBfN/e13hZ5Tsw9NS7zbLCNkwkp8nPDrpGQhskxPUg9
pYy/DC9voh7u4Y9HklE3WqyNNdzUriVhYsmvMgrC4a5J4osIdL93P/7uTlz+a5UqZlQ5EHzmKGUt
3ZWF6ggMHriHPrj6uIGqwhqGqj1XFoU1nCtZae1uNcnauzxBaIOR4V/GWRvpx1x9MXvRpSxxfHyl
hiCQtAXkLonkRuVqmmu/AVvnuWJrOe2TmNBrk3c2rHqSZ3wrsRsK59S6h+0LL/AcfeTpWcDwU+IM
hUkRUUiAQZxKMkijtzKh6GDSFKmQ2s04AYQjGm81lqXaWAIInH8OvoNTwb8LWFsqDLdxajd6tfQi
LlpxUXtBWni5r78YzWLzSyo79mkX/CjjIx9lfjjrkcxNtWknJoVuycuIYo+qkr9PXfkpbnbha/3L
P0Uk7op/2pxj8Kj2Da4hlRDEKEpmvbjenZzdJ+yRIB1j9v6WiuBkN1Ur/0Cs49vp5ko3Pln882J/
D9sB897T7d4NHSmU/zJbTgQtKqZlfjUlvElKxteG9+t/NxJqDSmbFy7p2Rnyof467pw00fr0a0ls
KC/cxCLYdKUQ/M+VKvomywHezlz4hHHp82qlP94dePtfcVBh2aLtqOJb6XFslzaV80xrFwebzuPT
30iTdqRQrL8XZ8gGuf/+uerbYvzflZD+dQYInQvkq6areR1xoOrZbGjqK/inFyUGk2I34aiYVh19
PbVbK/tCm5pLf6EuUItmN7qwWBt051IGM18Dggd87sOaO4bpwqDuw+94qrpNNStINXLU2SmqRLgw
sfrBenhcmcqogo2oPuAaaOtb0PSO0pNWURb3qyHPFJJ5t2GG7ZDTFIN/htoXxilXAj+kO4YDlb/K
Jm0VzNvLi6g4SZDzzZ2Mr/HOWlJrGJHNpR2p+/THypCrdXC6JlzvqcCVHRjcORAgX6bhtdUmbJd9
xjzDiMjc/H30rqyTbipH38dkFUN+naGD2Ux+H72v4eHN3ZQeOLUm5RcfZzsRvk7RLbVwQC8iCiRi
Ijm5HfIMJInwkRI3103OyS80r2sA+qd+42KprYZj6w9x3eOuvrJJvXHfKyBy3gLBKwisN9FSa9wi
Xnfi19Da27Vy0TuMn0Lujd0TJsPFkaINUY3VBH0fYqRHApvgwzn23IP52yGY0Ht1xNkj/XHLqC8m
cWeGUbgpLUKBK0OrKVyoG9Cf1IUz8mYTr+C/RmB16p24cdGjBHuMT79VK8lRYeQfTEU3sbk+hYD9
CaOjcyPbIK4M8GX9fb0+3H8q8TWMRrkST7VFUk1/jusFTxIk0iBWxS49NSOEfBn0sT3vHptpj0Nj
7j/N6lUxoaLt3FeAoZrpNptXZc9PxHBIqFVbILBB1H3G8Rp1yOtZ4rPCEc0EWsRurVodm5OAZlN8
5uxY857DavyC1I4oknRibauu9Lq5kVzx2Jw7mb2ZF/MiDizlansRXIPrCf/KtXc2e+iXGKni/cb7
ey+l3eEL3orm/BYRTrwZeH1xWW3boszdfZKjxjLnKLw8UxJ+vAgJFlXV7Pjer1r5DoWo5STLhtIR
sFfQkF3fb5RZmAjv6GPldzKmMVdKqyIkYOnnNMwcVwtWYcdQJvRL6LdtAAMkPxYK6Pz+EPK0rmMA
h53EiMOaG09I90z0FPxphpwe2wkNAuiBZUBK8qv3mqOe7MMOpI8WAtO1YIPx0pjehn/pa1yPMxXG
22v46YLVqGMiYMcZlubzUoLRZtYxo3tHOl67i5lsYIFsCOPjyjbPXKpqkHN91b7nEOT3xm+zy8BG
zomRCTYhyTX7ElBEPEpA3ceMsjIeCcpTTqYKt3NV2McP7NuhQRdM6IuDQja+C4GTjQy7RdSnclyb
OtIF7t/l3X8M7/flqynlVBomwlqRoLS2uIgNdtWGF/E/4MWFvMtxmAo6a+EFJAhqzSDw