<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqhVEy1bYu3tS1UkuyFJbq3LJdcWVnE9GRsuj+xDOuoom6gaN/o4nyB7JwwUQqiIJVK7Qfdg
yLzIg0Lrm6Dk3ONPUdDyijfuuZqXVfY2CyZOJLPId6a2jSNRV3KsNPynk4A6cueXpgAgbxZ/RM8E
GICpnhWdX95BxdmeilnEOIwubkZE/e42oYqxQGm5FQGrRy6dq0xp5C8mN71Lk36LmSW8pbsA45A+
vudQDLTf2cuS0CFv8XHxZ2w593Sxquur8crMLOp58Nnx+D+ZXOk86wduhvreUj3h7RlsscSRy8T2
9kPZ/8m0pbedmNvVbiehECBvVuEVRdHwc0Iv6UAxidE7yV7qm49ZyAK48rZttMzOWbX25UQzNBac
pOkGM1U3/J8xGepnjGV/vjhGrKuHocCJLcuApvUZXKSkmBQk89Jd6tvu3jWIRSBaGeml+llevuk6
sXrcoXLeN2gdhFEcVoR5DT8Ao3AsHYC8uvB3xtQYEmPuxWknQRtberAQJIsKx+PRx+/3nxFMfJ//
DkxJx3W/4csLjT7qAbjVCe9JJ8Ds/0xE/o4i4Wnw7IZYe5OltE6lleZZ1nmN+uE+a6f4Fb5pTgEy
sYhykl4ztlCgexahSIPPpSweXVl08egt4DqlleCg7W8ZnGyYhyk1Hfpcx1JfQhbKBF1aVdKPOstu
6+Epvcs3DPvq9leWVe/DTmObRe2gZHQN5p4Pro6li6Q796gD60K2FumSqyucQGxyJmWQ7v79U08I
f9YV5nFSj+9CHOv43Sqz/BDQ9izEA6Onbo1FVsOrxUQ53y6VvUjlAuUrLNxK2tNBFZFdGcMOYuQm
9cx6lT1V/TWnbltAwxbSk624+kJeLun670AAtw39Qub2cdwOKaGn8tb5FGeKmTws6YlJE1oCTskv
r1RbIUWJbSGNaw+65Bp4JhHW/zqjeGMnp/G+ady1t81umF8Um86QehMFld0O8fDj3JfwZfXymTSH
1lzHcEo0sPbsulIVa7jB2my58vG7zxsifDpCDIGRSp7uEKWdV8hgP77+eupj5thxxvp/h8kM/x7Z
5jwWBbmKNx2LStuh9BdUZCj1Nak6GV47o6iH4UQYBKp7cO4vOWglo/4rZ4kQI59DNi//jawTYfwD
GQvmSElgYTKjWNUSBmMTNMqLhRM/1ii782Y9FGTDTtaY4qk0ki93aC5M3MGJIQcUk29uTlPJhHQB
QsN/qJ4J/oGT8z0bY6TSWVAqTCA3Aph3xVCZXG742wYm/ZBCGnhLZ9if/Ru82gMLWtiBnrh2Q18R
tXopNOQMyDpkgJHiFJ/rmaLT9ZFXu/u2Pf1BfIvqTDTj/sB+c2/p7VNsseOYIk/c69igo4W8x4Q6
mVf6nB8zAMydnWUHLoV3xaZUtHhLpn37PqNBAhGp8pImNOX5051R0XpwWxacaHcEdIDLrNCY5WZu
rSgLWmgOSTx21sMcbUWLZbMPYhBs2w4iSY90lFfSKoKjRaSGNwRBbzDA2FlOrQg6viInKctmVfGR
hQxHkSeNTYkvushWteE0rzAGQUMA/CgNQBqxw7gQeCF6nPrNKiuIyIdutVp/3VDdEvqbTuoRfbpd
M4aH69AHUGX3jEsQRjZc86Tx5e+mg5xwh4oxt33ypvfXL7hC2lZNWVgJjr48SFkf5PyW/HMbASKH
luQ9fUimEVDet1/IYj4MwQp4dWHPzLfBokS7fwRnpC58K5YOorESRyHCqcMmxwuBwzt8HQOnaKzW
c3dibes4M2b8jiAzLlVzrhKIVbxDRA0scsiQvGJQ2OucUFvxGVbhKHYkjKzKStnLnvc7cttYis2K
gMFZlaZ3L75sg1dDHeIY5Q4LSOdqzDY5IwINagNjxm2bYJy3bLqBWTI0uwYn0RLw7yrYC+4hcu/W
pGodgquVtMOxvHO1KJLnwRSk246Z6NsgaqK4Ocr0+lQA4gTCcS1nZR47Jrks4xV5YyCmXUH/DbBu
EDg/fDVrJCZmcIF5LWle1cOshsQcKHTUbKntOp9EbzKswVmsmkMjg0WzrYOirp7C+6CwG5Le8bYv
Blu55YgEXCP2upT0PVzizFCJOkIQhTpilvwL9/Icr8xpdwAN3l4u6wLGy8pbjjGGKXGpVyCDYc/c
Iv43GuuLABJuXEQkyoaAUOtjbxgFrZw2L+y5XUf2o/LwDBXCbpGL1H0snp6+GHSleyhC797K9k5v
vE93I+rVomv8UcxJVg+z8Tg7TNqZfp9dts+RtFjJ+1WUOjPxGVYpxXchsLcewBikZLKzrGc7wqFp
Z9xorUhGarr6xwl5mH4t7kyhPNrPohjEH+/enwEOzoFoIVBFeAFbLBjEH5/mj/v4tReorhzcucNh
s/bkFp/0JG030lo+rgxrco7TQlYztEBkokWor3ElD4FDwZkg/6hg+ZPPKi4QbvmibJSfdP2SAo5r
LbsvYxZF6bpUXuWQyzsRT6u3qYlIBENhQBInlfeaguALrTCND+l5RdoxKSlMmI8/U4ObjZANKxrP
dN070yTw+i3vR2UP2rciEME+EotNcyvIrRAsGz52edei/J5mDyMb9e5X9J7d33DOSwj9xJ5BVp2Y
L0/1ut3PczxtbZRjOs1x139j90sCSvRYkeHxN/aeB03tBUTMUKwrgwotlSbV6QFTlPvxlBMyMDLd
w9plnRTiarzk/ucyKohILDR77eJ+wcPVCs/DMogNET7FdFuMV8ASpDG8cB00v6ejqh/rfYm92rrq
Z8cjeNm3TFHttHN3so4b7Y3/KawWHnK0hZ25KeFCftNe+zpQUvlX9KRoa9pYSJgfNhiDuAONKqj+
4+vqgjpbZoeTZSk3Bn3m9/YeHu4h6HDWmO4B2rQlTaPVfaQe9A/E2OrUnNtfXegJt1/0KAOltpC1
w3uT5vcCOjcaTmyCiow47nRRZ6h1UnMp+3tl6zv/7HuY3IPQDtwqtky6Q8f7EC0vM1bGUW4MsBKa
cAFYGczZVtjU5fKJCNtd9HVNkLBER49K9DJ/j5j3qnUVU/ZOkrWDNyr6FWGChMxqNa4wNSj+3bLv
FYWVhtFWfuTeAq+5bdrr5GuFMxdlW8vOfuEofhlOtkfVRdKUh39oA7LOQWhyA/zHpEZzNynNlDUY
H+XdxXlf6mGNcivpH9T+Ydi2oVy3Iwq1yYmmx7aglxffBZgT44rrosDIUkJ1m6B9EWV7a5UFR3Vx
WJ6sQ5GZkOv5mD4D/jDZbQpO5JdaoduQmjQdwjzFAxrgW1GZzU/DDNolUvgy77jHAgg0Bxrec5xJ
YSekwYMrQKT7vvrU2IpibxikZkIiWKgiKq+EsYAG+9KnGZyWro2idTxSLeKok1IXItN27j6Ux8wg
ASITJzjo5LVAtjPV0oM4Jf8J2R+YqXX+PxO/BzW/+BEqmdUBv64us/e7cLnPkZdayb55eUB7f+n/
+NzfTDnsKiysde+GtaHL4rigBKAihEXKIKrgw0VmOole5M5ZX+uz4IeaqYjKxY/UyqtI2hGHJTyR
Lw/CRerqR8g+8D7aDUUdcQMpDY2MYDWSKrX5/zz2An3Yj6yuxru2p4MRQLbUjftOsRHc9+Yw7mpP
blG+u9PCsM1dtCRqyAVQ9johKuzsnSsW4hEds9qWlyGt74032fFo/EFCpy8gsoaFkKGJlTe9pnBS
t1BW7Gfm3974OFRti5TvFjlMeeOe7HQ5mZEijyL5qn0jYsrMrzhSXzgrurlH/KiajdCKfKCfj/W6
2e0qPY9j2KA6B2ZNkkgCmlN4GNUEGK8XaObRdMwXns0e9WJ11If29oW8SK1aL+hbMdJ/yxiLgAg4
5fwpHS0RE8j8lSPPV66KOerU19yWYo3r/KGGyg0gRZ9q8QA4CVguq4agRBzNP32sYaMqpcXcOOuG
q+OA+qVuGWjCuLBMf1juyb+xp7D+j+6pX/N8+7SsU1YOg2m+hadBNAPXWTK+RlB6Nf1iJ7arbD91
iZyWyF7FwuzYs0dO2ExJ6xK+Sij2LXVIZ5302FBWx661KE/lJPt55JaiBa3wmYzYKRCTDSqqa/lY
cYC+oXU/uRTxZJrndmlTxtKxzZ7BI8qO6Hp5359//8BAwMOFuMoO5L4M3n3TpwZ7e5Gc5WbZFiNA
t8wS0dUXw5svKIqxNP0l6HmC0dKG70PiOYSh2ucxFwk3w0==