<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxz6+T4ogC7co/PiyhaFhDmQ0HhhMnv2QlG+0J2yaCiYNyMU8KG0oNr6ie2d4b7cdi+FceWs
YL4tGErT/pVxYO4gsxvYG/kCmrdoy210voVtYV/MGe9H/Fs/UHLi2vgu5Pc2EN96j8tVEC7tVh1n
bT/5fYbGmRoGZGCqy8fLRJPbYp7pv8pr4MvknKMf/FXfag3CLroLnU2Xi2kBShI4HmDpPg0lqdAC
4wWJbnnWbxViwJ1ot2irwUmD4Xa0PToQs4SvELMCnI5yU/ZVeuMBY1kf+AzPReSJ4dQOeFBa6xA7
0lN5UFzxRhmKqacu+XlsbofPwgZT8A7SEWIL0KwMLEx3b14JKMnjBYqe4wwG2M7i0IaGLYObXOLh
pEii3kU8NQtuuIhNHNKolwtrZ/14rhdp8t7jVflF7i8FOGmNoy4CWYXxddX66CCmRrAC88Dcz42+
WO+QqS0FYic4SETsj8oLHFgUXhrQ3u66GNi3VNkHqqYIuNZng+COGpDeaWzUN4jSRg3ILxbUBq1g
DTZp5v3FPrHBoy3g95SSRCuoz3jM4bYIdnF5IoYf+MOb6FSSu4dJmVg1GHD1U3QYXSQELwzaGu1k
RZh3CE4V5d9+GJDUiaolDWOIJnNgsQZOs2W0LiSFOfDVFfjSUlrfxB0xTFq9tvMa8K5/s4daHw03
2orM2RDShIYG/1jT3zbDpykZqBErXVUMHGFQ5+0fqBHWk9F34eZ3dt1CCANJlHllf21uTAvojLXU
imYSjZM39h9YjqRRSzG5VMZWtNnssEjxLelJ1N7abEDNAepYSe+3cV3VWImhfO42R5LgB31qkyrw
eOO4knvdiEOtLM+43IIzm1Qvs/wgH8xwQR7c+cRq4EPofR3X9HJVa6BoaQTlpTw4MSEL6X4xMQGE
+Gry64XTkES/dtdnr/G9j+5jiMJCBv/1TN9R3xjhpt+vvRdKG7ceHyoHq86JjYMXpnAvlrVSqOKg
RP/eLX84JRcDa4duHD78n1ol7HVjXo+Y29QsN3lLaLKjWKwoK0OnU/2hB48UBqlUopDaDUiSs7zt
6nmnmr+Kq8EOzCAbINF44Rb7qYt3FGgzmEoh75qSZMaa6SmaStIEK4AcwiV0e641fj3itfnLdnsy
iofJJWo45qGEBbg0i7Om5LyLekav2EFl3yTZgfuW+WMlHKxq25LRaSKpep6XkJyKCIxBbneBeHC3
OJzPSVg7DldgKWLzIo0GEWOl3a1O45jthRgQOS582Ji3K/Ef6esk0pkZjB04gxRnHAeHAJgnD4cq
j7MZ62U/Tx+UvgdsbTWujgSpq45kL0l1BgymrguUnIImP78z7m==