<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+yXNHt2fQLIc+d8FfRwlt14V5oExPhCAfwuHDQWBkWa7yIzES935teKAZNjo4kEO7Kegmt7
qOqnBVuRd9VodFm5H5AeZEN+QPVxpsNxL5XKlRrcOMYkDqop7j/VB41Lpacn8V6Mob+z0BOChmpj
EJ4TAqE5vfuLMGzhnosK0yFDEUqDnmxMjNfTaueCIKNFelK+tbexCUaf0FaE8TzlVo0d+RO+kk+M
JnGg6ojj5di9KMqsBN2WLmLypcHPXYp3crloLOp58Nnx+D+ZXOk86wduh+5banwynEWT5ZxEb8SI
XUTddhYEwdn9Dsg76Ny9xF6daBD+zpNX+ewm2ETnUrNSLboTtlznaRk6Ooq2Puw5Ktg5W8CbRi+t
MjkCA4xZbTs0Ru/IJ2d25WANgpRXpDhFY3xFMv8IS/uoxlgon7B1kitSAownkBOP8Gk0+SswePX3
amyr3Q492vcg2Y2H9y3BPLf1Lik0rTbVWOFDz+2CFR83gA79XwvQ1zf0EwxO3q9BXoLeO79j6PtF
b19lyp0GH3I82b73Ve4qo9QOdtzH75VHlTfku9DHy0QScUMJ5s5ltylBJYJz6vTm8NDdrkWFSqk/
VFbeUHGf71F3kPltckENonPFb5A/3gxw3+oVrKYyp7tm7Zt/AMN3XJNhFRgvlO6MJz8f6Khb6YLA
b+//Jgzx8cLDBUZVnFnPrE7LAt3wRXxA5i/HGh6+2bIW4HaD4s9zIrqgSN5E2rPT0s+fqRW6Ee17
6pE5UWSHhLAnxUwV8WmEliRG7kAK99iM6hepbL7uViTWJ7mx0Ln4m1ihnj9WxGVx0Im80Tq1bmHo
JPO7vAQagLXXeltOZqO53F20FR2N52wsbLQ+1g0qx0dxxOWOaM7Qe+U6NJZDmFQPT5ltt+D5kzK4
YL7VIPsteulN7W4KkFo18WG6fMPIy2RF2DInPRCTq7z50uyVlYUyaNIHkLqXCG32pxjKZBHIDCvw
AOyJh2VZElzROB4sXXVjy2hEc9qfRqmD6GTOisaDbHLQIZE06KbkDRRSXW80Kjav0rqax8n32iwu
x5/38ui4SLFi8Vr3JVAlK5KPmItSmYGtpSOEaqePHQtNvSVbapXMpNiE/7QDskbagLJDsS7aRIR4
NjmYcBPR0QETbRBPmF8kFRuLkRy9cj+wrYrL2Qu8csrzfNtfo8Aoiaowr5K+QBLcWL9w7WWkCHUx
Z6AsPZXdI2CKU8yG9kZCIHDv18QjXiCuW/3XCkNvlhOFYh1ZdWPR+CmJ0UCD9pf1h5E0UqTYMfJe
FlvMEg46boVh0dkTuLow6oHZw/dN0lbmwx820kbHvB98hnqxqOkX5R5JFi2NkLDzmSL1l5ArN7jy
C+CKHkHa2Sam1gUL7JQtEhGbdGbEiJCkz8WXaDz7kj7ZFcxyhXRJkDrTHYiKahBiu8SGqgJDDJ0r
gjs9frkSj+FFVfZpIAZafgCD6wRmuVNCcm1w0DW0bL5fDZKxx7wqEXDcVmRvuAL5WY/0Sml8Bvm3
DBWARH5OcDDx6BHHuiMcxEeF2hICtSmM9LSzKCAOMDfZw4d3ZVR/k3XsmRoVpUJPLMpeVED+Dzch
Z+PO24hfv5Hty2g+xoUOjrpsczSWBKreGzLPfBaANy7eRZiASURKJ6xdl4rk/ZIbJx3LKv14j23h
P//fX9kPPNIYw2h/uyPvFvW0IEsuyMhu9fbOqiOlUjiBW8oWdOLsjvwmAGMUtW7yG4Sk/Gp7w57I
RY5u1RUlDk6l1O97xaIOfxMgIXwViXgjS8W50G8MbFGLjxYdffdUT+lSub7xzcTkgRwbBYb30nL4
FZFnL5moGcQGbLpmQoAAAQWOtQkzE2y2OthDW7xjtTDqBtHngkuH52nF5KM6QGlpm7IFXmXI9SXF
mBh8PgnXBlN/cY8bDvNInfiHeRCnuVNVUn3z3QH+p4Iqm/gHyoYon9CewFR0ODGjMbVGdBcQLGb2
/S4+h7T7YkOAxoRqqOeLU1n4XA0mY0DW+7jYISEtt40LCQeulhQt3F+rhKcikR0XfEuj9wMyPQmq
Alvz+07n54yBzA82gVPO8d70PyIi1uUbMWuTx64bwXxPsO5/vJUQwnu7D0JxWzCxjGjvG8pA510w
wfIySRDkMLJjsQ6PzYh/GrAOc2gHQH9yhZ2AxVjf045ctNTdtjbYE09F9IL2xP6kdQovGwlgSKiB
6VX2ofFk3fvJ0dAm+76KmV3Vqr9Z28NUhXpCeW4MYePArX3opp7N/Xb+I6LqBoL8DgjSpSgwd6KL
pLoKTwyEPuW1Kf7QVSCskROKIzm0KAr3ETArlsX1LTV98P+gxTY/97Z3lIfm2UUWp8J4lMCgwTCk
odcUSeqp6L8e50WzJ4fL4NKjqH8RHvslo+EqZ6xcL4YGie+8abfU6k5gjHr1SVtohUmC5SImCU8V
4mQOXc/AjS3nCEnRQ/KBqWbWzechkeXdGBFsRHQl/KgTI5EooW+V5GZUmxxiLPeoFwOxoXutIW0j
oI2GT6trDj7O/TSdGBP/Ric9Or53c3X2feWFY1vlfaT3PsGUXhwjH1BJA5tZJPF30jGFNdmpZ1oc
TkJTL6DWv9/3iPp5RsQ7oG/ywXiMQn/Ofdzgts22beQIHT1mU3VVCdtUf21zThQpWIf2YyGgN3O5
K31R17j63C5STigDImomAsb4wjras09eSBewIyy/2Arx8Ez5xhijycBUGd6DMvbPyZiz8oCSauO2
YHTmhEakaY4kCWu13NuiPuEkzoaLAJX1iPNMUnKjHMLxmptP6iudRYl8J0at+Zh0bEQlDUxKsCCT
2fjCpzJxLTuCO+DzpluxNlCUhIuqXz6YqseECqMMSigvIoyV4j4pjDy6niB/kBtPeDv04f5iDqkr
9fKfP79fOfcNponQBtaZaNOUSNYDmJltOpxyG2hCUFJpX7XXx4OCzrgU/dOQ3Vbk5dn6iClyP6H5
kbXTlCJqJhaM3tGgPnQJ2HnZLSx0PlKUczeNxl3mUdhVczbZztQTyKTznEct4mG0r1Iev1y1JiOZ
GEkKQlhHBlfwECZaHdRBatlq6R1DsoKejUpmft1DahD6r+ccApN8XwOjT9wzEVuqJCSsX6DipDPH
a87Z4vgTgcTKs/WZQgqVYjWhCvGYYkKd/p6YS1oLp830uxVSGjTWvvsrxrYWEFe2Di6+vhvxztN1
CCyC0+eKD+igbuM/ZCNzOknRCAh9XpyNrdTd/yqMaemj+N6dmPKaOdvi9AzY7Ez+lZ8wy5O/M+L6
MkWgLWZLsjUxCqovHuMUgY9UOhPoyqKs/9dU7qxwLeNfm/JqBRZB54x56Bjug6AATV7RxF8ALPzy
fS/O/9kDv6wcnguNfKRE+BvdlhZ71gvVQuy5DnP9Hgv828m102HlnLwhI1D53PoMKRHM6OPQKlwj
KSkI++oGzmkfqw5wCt/HLWrZE8kM96NbS3215ZSksUrHtVU92ROix78mYpMaCUj1gVngz/HJ6Gva
nIQWKOuNMNESTEHrmZQlbWE9ZMu2Ckngvjh1pqx5XlBLO8rONv2oEeDEDd58r343HnpjDKiKDRJI
Vgy5mTxNtno5PAbQ/HH6GQA2ZdfC8hEivHHCvDkCoZXyaCQD56BJzsBQa3UT5NF7nz+0+i3pCi6w
UrSTR8agCCdw2fqYqDjq4s+2cP6ON49TUGfZ+039VoeNpI6tK4svNAizvs17sb/+v9z1P44iy4kR
p8IyvoHtRhrHCvmu2Vx3Ka6q3RQJ+TVlhaxbRYRNYCmqmvK1wzB63HhLc+oIxhGJJnDxpikZRiEQ
5BR0LyWpZte02dc8fQgjiFZpnw4NoQI4hvnbWjMrxTdnYFlNlWa04R6fFN7DBG348Nr9cuCL9iVA
VPJRYY/Yadx2du3Glm3yOCF0IoAIfJadSqJKB4Wr2C56DROt/u7Aqi7J8x9Yn3y7KVZXA1FlTERz
UFJg+a0mslV7y5A3z3sD30zzykFC70En2iK2a9kJZ664fLTcRF6pVuDyP7BpowIfHAkf+SrkKDzI
d/A8s06/RYq3y9w6TTS4SfNDTksqJPKVS5ehSwVdWZeB