<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt9j6YBXiFuL/DwF0MKxxrx0Laj/NCMHgC1i196UXZ9GuIlDHTwwOpS8TsiaR6fTf1iCUL+v
VvIJzA5wnT8aEmY6OFzRWSVGHylDGr8iU/QthGaG/32WVIZYnzEa5ib9wLePZPU5zbBdu0YJjMee
f8aurWfcqQegAkcVI4h2zGnY5ZcgviYiYakbtb5uHO57rskrpMl3dwMIKDvX/0GzsRWOQFh8GsnN
G3J7x1O12wfZYDrxEt4uqHdsPI7aOkkarRiW65MCnI5yU/ZVeuMBY1kf+A/yQkgYKuIe5TjRGHE7
ydkdNl+LTL6uMZXQORxsQ5Z6zZ8IX3Ik7kwe6AygBZGPM5g+KNWOt0gZpWNOC+1Xribi0oBXDuyO
KvuEUT6Hwtc3gzzl9QndmIXQnMaDvMMw89KF4rB5xmJUn7CHTKCB0CdyByoyv1++LqS/bvsxaMqE
g5CP8ciW/gKC3wwPHGgegW2h+KBW8s9X7lh/kApsnqpMxKen8cwhkYYYI4lmwTW8jrkWIh7sZ+a6
3Y+zyGb9AAjYrG/Dj9schs0YizdjwoAyo/ucQKcPezNzI1mQq4KEvB5vFmqoxXPL8+cYHHUO8psd
5AKcHBvpKc6rIA9hJ/rBh7MKFTHG+H24u6TSQuhhi0HUgob2HNAHiLYn59PjaY25Fbh+s9bj+895
ygvl2QDpGKdpKNy/uxPcUc2N+khdPIoDKnOfVCvfDJ9iVfFmZZ9UiNRHG7QinGHuBWEdCs9o0+lX
TKFk5fSV0YwtNKTZq/hDwV20GrVYoCqgQQ3R+NyN42v2+uNGMnOhrh/wzo8vHdl1tGbwHsNEiJ80
DMLCYoOrR1UtsWgG75X++tymcCICcaEnK+LlP485lj/1evuSFLF5MYu2mXoGDWxRgGoI9oRXBye/
iduMQo1qpn3UAgewGY9fQyvD9rjGTGeBxWhnJnqghnhcjw+Y+GzZVbFHkp3Zp4nVHNiDy/MMGvDP
MpGgUY/T96J/+nt0stKsJlJx8Xy/etRf5uqZzQ1VSEvmG3yF9aQdO0IZCGQqwVIDfbypRbP4t9Re
OqsO7Lz0o8VKO9Qpk14ElWOxx4pJ3UIyWAVtb/I7Qm2TlPEJQpedpNzxhJxEQaUy9zWewkmXzelt
XX58UxoB5SaB6kvgWXv+x+sdGgKNEqSDQVL824dC9P0PeDHy4s9/TCpDjbO+8862tzW0s8wQPVNi
mDtZaHeu9uUHiwyftNOKyhEle4LndHfzRYtxselHhw1SRYA62UoLuSzX4EYJZIolYr1z29ownXtS
sNdPeTPFhnRHBTpelsrFG9X3MmaYIhPVeMN0FjWlEYmoNmZlEl/oR1nTIY7iTM98m5eK5xnW/y5K
wAtYsFLPhiXXuDfjE+qxzdv9zOuRYEjXFki6lNNbNdaGnig7rxkgyzODi26ZwszTaCD36ufm1j7j
ukbuOEjsst2DBFIdpY31oPptyzUmk3k2ut2yf7pw1+tYHiELxyI1Fm4mXQkbs4XIR5OtSosBnbaO
O2POCjltKFyS0FvLimfxFMNlJ6cH4aZ9MDJzqZy8KretMjT2A3qE2N22m6yN/buCwIt7hPYOmOE/
KJML8otaZAviaxlbA05kMK4M3xnUGXX1AKGUw1CJ+ojgUx2haf/8CgUnZKSZWFdgvfkrCoGo0rXc
1LFGTzdKihTcVlxGVlk8W4MR4qjKQMQgI/3kegTHwIiMwiTlBHBqS/vc5rggKmFw64b2p98pv3LG
zm2Cp341VnEzptmhl7bGZWO820kw4w14rZZLcgPnvI12lQdZ4ZrdGA7FH+/bwEbdwINaZZ0FpH2s
aauSkcbJYfbHrHy5iPL8AI0Cax48NeQqCu1Nz+mjeOlN3lJO6b07br1puGdjYkkR7ABnqf2C37mM
QufumqBuxiCmqckKDC56hOh1HSRmf0r5nw6XLBtK42z3DcFlNoLOqkZ3QYGXauWz8apFUosU9doW
mZ6nWPWOrBrwqcz6aFezNLMVZNRwjIzhL3AnDbX0Bzl7dZD6efefXGoRg6Bv0qzpSN2UQjy1n5Z/
8jXDPAtvu16jWHxHt931UMFyK0DeB6g8y8txEbNwijYWqrT7Y32BbevqwcuUBgCYDn7gTKQxLSKX
iGOMuRU/TozqXqtBQ5YEIC2Hb4A3Ob4BgL7nNCIRjcbzaPw7FymIO524Cc9RSXfqF+fF17Y/MTLQ
L/hV5LSaYTi/DHjqZO080+I7sepgpqB6a7MlBiD/6m==