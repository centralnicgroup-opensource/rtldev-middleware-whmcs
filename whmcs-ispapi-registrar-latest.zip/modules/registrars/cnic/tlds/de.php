<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmyqKepB7wUZaeF7h+cZHfZsIwDaWgA7Gkid8r3Dr9koU29Z2P28sot+Y2UD7T+zbPGCLg2Q
Es97P6Mfu22Mo+dop6WC3qRIer+VtI41BzG0Vsa2xjoIo+vNsTyJ4iCn63Q4f45X75SK+IITDzci
fVn6cX3P8UYwBJdbvcC++LryZc+J1z/R4UA0LQvG6XyS2nNDi7FnO+RP7APmTtqrHeClTF0Pyf4z
vMy4Efqd3M/JWiZsFVcI04tVElZKeMxVhGTYeNfLZCKXV7lutwE5YuWRgVYlucaSckmGLLtbuosL
XtBM1bb1g63gr8ICy+P2bk3YSWxCAuwDMGrexWtjsrx9OUzrgi4t4NiXfgr8YVnbIsOUvtQ7A/oc
+62j9xLT3V9+BEbuEqgPk5cza7N4GFTP4L+SpRH2KXmwl7a4SXEf40VbF/Jyl75QXZZ9JkPplVza
gq8hy26BVlSSahAvUrLCAmoiLoOifsdmPitmckRhJHGSXNLRiJHXHzw1nLE7C0AkdcTqUMx0VQEF
aIJkzsMkxe5IVJ6JQP3RIG7hNuvNnbT+Yto6/WuwMBtXwhOu9awAmi5LGVBIprNuzXFcZBJWqBu+
jitykT8VsZIG7jNedRAX/0nFyWaBxxPjdKJ/Yq+fs4JxHf1S8G9NnO6FEG7OcNi+YKB3uXHjWyws
XJRrNGw6gpbDzt8MW+/T3eWEvsqEp1FFowZmuoOaSgw5aPcL+cdiXjaEp0PTrtnYW2nXnC/dax3G
yJDW2K44TcT2cARqaeoYYHcJtgu1mA5PSA4hRneeBhp6FeShXGH8BRxB11qU+IWvQS/UCccx9g1q
+VQHaG+4pbrGwByQxxjZiBZIWqi=