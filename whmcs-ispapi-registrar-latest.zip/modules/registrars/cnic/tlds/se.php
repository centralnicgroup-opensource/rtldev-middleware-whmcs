<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy6sIcABcKzMKWJVGGeHgJ44T0kVOazgmewuWfChUBngP2zNmTl2Dyapng782+KZqOonjz7j
Xrjqn7k7dRxJJUQyWcGLEZRsG1CFP0BQ98AUxMN9NOpJLNjMRKrqShYC9gwWBudiNdgiIpFDXJ53
RFjMSyckrl4XOF3DmTytV0jxzm+zabJJKlJm66pRmcSqe5Qu2xZOMzcEqZWWr6gNgjyhX3tMnPGR
C+EYc4fHwZtj8ifjSRAideuvU3FIH1SEMToWLOp58Nnx+D+ZXOk86wduhqfhQ04QcHji4Y6VXOSY
/gLx6bIoSzQT6jw6X734UKsOksdybc000pFeD6INcuWjdl45w8TDf6MhjOwUO+F5GRr4bJX/JqcX
7y5N3XDCVdoKeKV9IX8IbrkN+hAhHy6wBPGqzHaA4s6ysYvqvBZ7PyOh8Cb+qu96ejdgC+Gr7Um9
UJ4pQDxqCsSJcg1fKmP8sri3HIKLTm4pqi4I9l8CNFnwHlnSmUnqfisw3FPgAhWToPPGKPLIR0cm
YiwXQeFKZPegUvfEAlt4YcWRqUbMZUv938maGosmzlgqSj6It8alTpPzhF00lmyUM/yJUqGYfIGV
9hNddmsACQM6mzCBSjIfDU6qUEubNDELK2OnOlNFCvi2QPOvcQAN57u1y7jTIwViKl0RvDFn0P8W
Njvd1PB8KKCzKgZFfAWlqOsmYzPNkX2ABAUHWkcTmxYALstlkq2DxvmnupgvrMM0JUZQsjZY4lu+
kTH8Tl6sgZqOI3YdViB2xCG3/8wZR+eucoLUeMFvhs2VTEJlHFka/b0qrwYCGrq+Avu1jyO4dgZy
RSArA+9RFqTU00BUTPG0GI4VXBX7TXM2FbMhuGTQVrM3Ka5qqhQYMj03Ro/b9mMJT6+BRu1Bckq0
MSWHrpvlr8irYG+wtM97J917cuVnQW69+s+PylTQAqjBOjRqkGFRueZrABsJgejGEZh5XHGMsEtY
nCoLzwJW9X0Lw62SfjFq+8SxBV+iKY3mdA6HzaykiCo8wPkCq3GslutT7H5k9+KG9mqO1zBv0EXK
4Eev8H5T5YDVm4PmyhftXHZeYdfMh4p9X/iWqoNsx+QaelyUc33OdTg4BGbLHEQd5D6gh371722z
BW+2vawes1vg5Q6DsO69iJ0GQD3BxAOUJTkuyqFNkFDTIrw7BjTn0BBDWA28tl5qHgQWPr6m8qwb
+ItGncKawe19d3viy/swqQeXTKfILrroYzPIg6KZjS0tqmjvWK+ejfm5FIb60tnOfPUu050eCEOf
1gPNes6SluGNI3k9/LCBuhON50A1lZ/4zdA+ZZT12PABQij11q8rDMzvZglD+QOz/pKR6jeLpj7W
cT2DaHYU8gOkbuZWWSvtD+C24T9/gOEtCmCvYhIuN7s0KKztpMYbdZX7ZXlzj9JTl1GozVCwuZKV
dqRLRmmiitdMBceqOVbBZe759LOFdMqx+UzTD0XoNM6thb0dulvh64GTQhrE4BSHvpTwyC3HrpGH
OYqKHrSo59+uhu/jq1iGuhyWE9kMfItyAsYIA0i0rQxhdYYXInf0ddF8jU64PGUewiCfKtoXiTsj
aKt10V0fxejhsCdC4jc/Agou0QfhQsXRDEszlt3zV4IS/I13vpu6+jAyDyhqSDufABZ/+PxeB7v9
+d4w5N9HKXZNWG2c4POC5rsiqmmttjM/vnro20BSeXjkS5BsLgMKmBKJ8B+N5MFEVXFGZcFq9p+l
rNZ9Q7jnGsWReOwYHlZM+xGgLepzELQIUDJrRUNcom4DVSPnMge6q7oJxocJ7ErGTsENAHYE3dzK
4yw3qzH74jehTeuWSTSnNGY+ubctUVrmVLQ/dcAdtDG8nh4Eo4Fn++hk1aD+dYD7l5yBNRIBJkdS
