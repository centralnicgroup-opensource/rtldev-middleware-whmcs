<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtpInTMXCZuQl61GziDm1XKS4XUUvtiPsucu9WtD07gv/ZbVearl8gzxG1/AwNF4UKFcDSqN
rTaloGps9Lrg6N+rBiRE7nankdrsx+a7CC9QjFdoiw4rHaG2lDcn/4LBps/xl+Jnfrk0+vN79Iqr
S2ga3B7Tk0beko44bZwj3npQQA7h9gj/9KQUJ3LSP45a9/OsZKe3ySnq6YB/iN+xb70nIxvk2bZ+
NMVtLdWZJmbUuFzXO9gpi2j2lQ/18vVMpohpLOp58Nnx+D+ZXOk86wduhzPdA/sjZs8OWVb7wuVY
niLk/rQbZY8DgRIJHamH6j0x/IE//oIoDZ05y53HU7BQlT0nrZXRxKBlwyjUIOMgcMwuMB1fJp12
uHyNu+xqrLGw5W2Z8RTBWzJDfwxsl+/aixVruJzcJXJTnKjsnFoIRm4gT4ZzRzoeYHcHU5TENn1a
zu67rS+AwzYeNvnFmOZhXauOCWG+WQf6a18vJ39X8mDqsv80Ube9XZgLCD0x/dEhIBGlExvZkU1l
5TTTWAT0zvRXWx91jVtpKLwheSr1z10MSTNkRzXebR/2CcIHJTamispSU1kSn/gYwiz5Z7yGfDnZ
m0WZzLLY34Lz4UzSUH7rc27qlsnV77kPqKcPOHYaiZR/Eo0vUfYOnrPno20uC/Gns7HHnnIgD6ES
cBM2uZD/feDIr+QzsRVbi/56I/ORRKVt16wNRpZd/KiQp9h0P9VMrgYPxnpefBD9Mnq65Xjna77P
WraYEwHpc2IprO3x1Fv4HCy49lIysEWixTqUCb/ADPIUnWF6vz8V6UCnOkOrJGa9gCVYrif2BTa3
XAq13177RpscMXjHs9vEBoE2KU4SpnW7A/v1zN3jITKj1lHCZuA3jHj8zfDUkB4CGqiKfIB62jz2
VzfdXmJN7dyAFkpPe5GreLk960ENC0EvhfpSOXp0Hoej4WWFpgmfsdh7djuuNfKj11Bg4f3rNayr
NUIKAa1ZSwWCwftKKcET5mq+U1VZexLNUCMTieTjRpPz4moXWOnxi82yxe/gQ1nEy3jFBKUUw4ja
FHckQ7J+3xRkie5zYbyDMuoq3TAr8+NzeMk+Abapcx52OkL7PWwEo4rI4trrSp0e9LpSdIVnNPfz
t4L7q467dyTD5vS0HzROJ9aDD7LUKUF0tg1Jn1w9aPFbCpF6WW8Z4Uz3I20OS/9yT2gDjJ86RlAI
7P3balue7QptJFLqFvgd8zYm3XBCNbmmLLufSy7y7VTRD7otYAreFLXK9DKL3ePfk5kfcR8XpXhS
y9Lc0DMkYMvqsEWhVn3wryFaxr88cwSO96fUdDjITHu6Pf4cHVRnwK7hCWSJ/o37Zgi9ax14GI/1
L27lKablz9SHEnvxo552FkNZKNXWv7TqKDRBLqHegYlR/XIt4A3xQZ9qez11wYbXt8RWqPljzVpr
6Tye5Dg/xxukxDyW9MpFRUL7Thn8J2kqC60gRYOXUwcLr4kUmsQ0PGz9FH2CaTzDdNbnl33KBr0k
lKHVbdcn/ZKX2MomPiXlHEisiWNBt0Wurs1gmLxrcF6+nHjCqlCUYNZg0SZuJ1vED7fYyQgzcjQX
UBVumIvzIjxrQtdea3JCUoFF+Q+Oxg0GmSQKKPcJ/xnVzVMQuwldJy1hQRQWyAx3lxqmzj4ZBBqa
tJOCntNXrcQnTpHGXQhGEbrb/e5yEOFIaTqo550kUnwnvkgUhwdIAEWEN6XHhvuaRDBsu9bsq18Q
JTEvw5KKN/JncypKrryS/NtGeLInBEgJnSQhfiWKLdCxXkndrGwhzo4R0YmJ0K2ZCSr7ROxlu1RK
R1NBKJ2fEZkw1W==