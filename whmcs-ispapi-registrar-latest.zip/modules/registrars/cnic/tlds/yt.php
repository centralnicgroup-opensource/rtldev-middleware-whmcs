<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxtX4sy3PUX0sYc6JFe79EVyJVB5qyTYVVX+C11X9/ToOLeXWx7VcxOs0ZKNEC14fh9oOS5A
Fg+d/lCMXcqpUTl11PcqVINnm0IZcVp+kx+/P4kNHAws68OSjxegVbw+Ua90OHZjJhsj1hJON6ok
OlAGjhvZp6Ak65trxUDKZ9L8WKAbU/FaepgivWRJn1l5AZFOi3dyylX+epc1jOXXiJhJlTGvf5ZZ
EK9qqSczXV22740Vvoudj0qRttKr6OIUK553THE/Fv8iraLu1HfDnDdWi+lJR9bGpCuj5AmyK2+8
Cd5d03He8XXinpHlIj7oOQ5YgpvLSR6yATnTRlzM6X/emOoj/FAmFcRDzczvmGGa78K1WcpGIQjH
W1WWofOfiuq5vgIWG9UyuWCaM2VEDJOlDEQ+vbe20COIZtZuVAmIUj3l86ZIoveBxuWUHp9PlfTY
ww0PDWC1UY81nHk3sE2QAJXXioShT/MIdX0Ncd1BQkx9f+xKMC83DSb6g7+sveomR+ylx5sgtmrb
80iDuK0L1zNW1Gu0YwGYPsrKK5xBhwJ87gBP9P3iraaZncEthCaw8QHeKIqwIMzf+EHblHnMvrjV
OYANUHLrTnRNoeB/ohYS4Yrq5HytWtDDypX6sNGa/fQK4suL/ww21o9VI2l/sI0N+9UsH/T3Yrj3
CIHNIsxGQCal5T4XfyxGgD+kxIwyLtH9O/2pct/6yPiGM++6oamBsllT260VdiaHcOatXda91PD7
63Lbcp7T2qUzL9YV3z0OGn/lzA6FVzYbAeWD6hcASG6GKKwuwHxA88RJbncdaAjGJkj3DK/u7PaR
36ZS9z+nKkg4qjPvwbJJD6ZVNOAKwMILt8HfH8EcOfnMt2htuNNglRI5qI/Nl7OqQnxYnBcVUBEL
rfELI+p4CvqYw4Tlazs/RDUHCWlDdpGJKXh+RoK1NHzI92/+1CuQ/sDwrdUJbwKY/0EOl1XUaxSK
qmO2CAKV0HpW4EuGe3Wdpl//QwTRBDo6avmLNDdp2KYM6Y0YQWwcyVTwrNwHqsye/LZhWJcPtAIP
Cnf1D3G3ZHlMxZw4E0c0iwTLpXsBuY59P4riWP7WyxffPt0J5cIJzSxEKFVg2PR5SNwNcVBjot6l
rAwZLIB73KCKyZEGHz5Wu3Z2KSv7bPXiydSm2zBj8rRl/ZCKq9ds1wbU0lBnsv11wJDP/VidRa65
yh60uD0OvZqW4qBtLaNHmEWjXtNScsXTG6WGzKPimkFUBto54KiQJkLeQ8Kxay7X4wUOm9+NruL9
uLumddwSMnOU1tu0nHmt74/8H3YsNsM7MU8Y2xkVx4TGTjr/JQ/J1zzQ0bV7usHfLBg06BQsUAXP
QV//cSMJ8g3R2mC5ZEHE7wYIwDZ4wfbsB5+aQwIT0uJmh5CiVHRE3pOU0ABNXNFR8rS7a6x/h6aI
IgDNEZPhdwdhxmLbIRzuNy5BA1jg2BKR1oThBCrgNYw1MjiwbSlklUHRBeNM676QLG3UwDvfdA7Q
Lk8oxYTfqS4m5NHhE6ZgxGJF201yIwgEZLPOo2dBT59apUyPkO9JMK6kuPelw1+91KL8WEASz9uo
wwrr+bKGdvprfqxUjNMFoXrSG9s64ucQRfu+/C/7QhzqqexeXnjZ7rFrJctCzBMSUYEM3wera928
fA5OhijjZgG2UoYvE+SFSHlXaL1aEXn5aG+zVU7lfdJh9H8ewNm5CfLY7hHuI9e5iZTPvESN1pk2
NEx3cj3WLsNTwlAjt/KcPRRSsGTeYpwxouuR/bZ67YpEELw1tA/FjRQM8tDVhyEyeZzwI2DnNrsy
nv45Pq1kcEansEg45xNyZpehZMh5IRbIBwNGZsrbDDzmr9RARObcLKvqqllrEE40J76ZLNZPQFrJ
CuQuSW5PL74Q61NdrNy05va08Pff2mq+ftcfJ7JVVAajXCpwOB8a+QjtbGUpCHZcGdsm4iBEOvVN
rtg6yBij7GakdKNx19NrcMdspbZpVYO7HRK0Hg795SzGHcwcCg36hab/eoyjfs5S0XAI/iCdI5PG
LEqGGBI0ILdEc3EWfpicQgVAcuFJPa3Wo+4nhhMDxFmGSdMny/rFrhPytkkeiFqdwIRIqC1FvTtU
jfvwGikbGqTsPIPm6h76ceUtsE1ljZeG5/U1Js6Yu9JAkRr+LxfIceozZCXsYCOOK2wlUpaLO6NO
xgbSNtESxGMcp1BWPUMdnEQw1HRv5YFARpwXJ/E2UvqdtWvBnFDSztyWnNlXgKaSXpYlDG/dpA5r
IHIfynUgAR6lUouQBnZFunqh/okglUWZI+5qmqkN0IPBbUBJjMbxrebX+V1z5F4GeK+WwWjbLIN4
lqHr2tiXQPjVO9tUERnXRbynXcJS9ly266dZmbfJRDq/v7vJliE2zEzG5Eqq2Ma5f/7z+liTfqva
seXl9cueagq7dhyMLwKFjguR+t/s1zcmU5O8RjOMzwMOvylN924RAMQtFTq8xFyXprCqBJQ9gFgD
L25PxN670UQ/gz8Npv5yLLcQHnC8UdT3D1y2fHO72PAtQkx1Xh0m8FHA7pvxSt3MzvPw+NvoJ1sW
U5Ggab/h6juMfgpVNgmCgQrIt+eSkFJ2mw8nRslNJcRlQROcirUdCCf7LI+dtNi80Aq7SRFx+z1m
MryDBSS+HWkAWI+OAiqBHvJVEurbO5X859elJUi98UXxkkeXMAIPVZvCiJtZYnnRfjaj/vLALxyY
im2HaGJbTs3aqEU1KSHyP3OX8I0eC1aRPvFxttPvpizxTiTE0VM0w4ra2afCPGhIRcZL+OOiGeIf
iAnxoG8eMPfKOrbgvig3QwD7v+BOYOveZmPw38gH2pKrpzTUsF+KGA3//ARAvjLYtmTVlxOb/9Ej
t5S4SoNAONWBtT+lB0XK3PolhDm7TcvXd48+ilD+CBz6tbpIAzAiUR9dyFsm2u/ScefbgJ1csAsH
gOd+2W7XMZd/gJfcs1i/IfXQdWV/7OR71YVLYB5BSWHnNW339hO9cdpFmwbeMX9z2mV2x/Az8w1g
i8OY9/4j80iagHX48DJsNLISAhJm3X25glJkVjOTUr9nqw5TiRh3ll5Jcn68ZoZznVDCR9OdWfaH
pIF2MvXbPLhj0D2RGazYJCQePMYi85aN2mXKxraCmffB6pcy4m9eT7l5CpV42v209itJYHsJshpf
0CKab1J4ksrenNefakWMtLikq8OhAfJ78S6NMtlVmbW3kmpuvUQcxNBIjf0vO1uHjRE+ml7fzAYy
l3XIuz6hDtZLw6R+veGDE63r9F+0P69Q3lgGjtHRHO1ljVU/sv49b59aBS+Yg/zOU6uNpRZb+84V
hUXCQsfb+HwcxABbeoMighdHSBjhHhKDIGjLaIo410Dp0DyfQZUG44SY3JBdViA9I9YDB7tpcPsY
A7L0MXnRVb/w2VLuTlXsi9tgt/ADimkPiPA6znwRSXMZShRrGvA5nQb7pL3JL6D8GRhV01fNa0Rq
HsvhSTMtUIRttFju4zaJfZEVh5+RxMHuETGpAdokrTKllMFWEeR4LzxGSldo5A9Bg8mho5cGZt7L
j3fVKG+8JMA9/cqe1MolQKERQpcACZ1TMELdruDhlrzdfEBm5X0ThroDGLAiCTJUOfUOqK0Mq4BU
Qe7KUa3j8lIF30mEMiYbxPkxbEQKxkGfTaRch3LaBHFNDJeqLwcD3boKKc2OdgAjXzPYFMXaPCwF
npPMiNEzI7yvmxg1KpS3vf93m1+qjD8onnM0RGcEh7e9QUE4d1OWImZRhX04GYOiha4E/j2ewjc5
Gsz7++XIjnWmuDCw6VU25K6x1GPK6E07DsXvfwz+KJz8sx1hx4VfBS9fXTHXZ5OhFuUhLb+9LGt5
P+8ZRNzCVnuXhoPEQ1lVhCbY6hbZca+V2OdADakygoF1oUcPoU+Oe8SCnNSSF+hBjv59r+lPgMWD
5RmrEqXSgTcuSSx7CJJrATJuQAFyS/j8btv/odtvmzfUx9oX0eO6QBQbPpAhb92MmNGniwvAb5ul
oeEohxPL/fP+JlCIhuqcDaUk6NkfO6z+qGPqnAInxtXMh1RKWhvmSfFVowZNUfwb