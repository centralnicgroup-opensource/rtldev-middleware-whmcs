<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvJBtWXF5oCl5djBA/aGj6eaoX7lBJUprznZXQAWHw7d1efHqNE6e63UMpyCKn+deCsp95Ml
GZu1E377kpxGJ1ORScDguP4/EpQCAr+0+1bttqLj5XMzmgHXg2pJU+gbuBVfcfg5eoMQ43YiG7vI
edthvo/CsD+OvuhmtvfHlbJp5fBx2OPZY6kImaeDpKv7nQEDeUZYYzyudjaKTGEaEKBw/gJNMUMb
PkigYyNap2iPCU4ts9odueaOusvWEPyBBKzTUbMCnI5yU/ZVeuMBY1kf+A/5QZV/fTimogvQsKA7
4W1c0FyxXCdOBLwbrEkPqxeopWHG9sgsAqta0uCbttcE/z29xj8PTH3RSJGqj0t4ThPE4sSTPsm1
CdqZ2d05zghyDOPRnn7BNOE8IBb3t+OHykYIisi9spRlWgRcyndCkA6PkquxKWYdNN5wMoWpB9gn
Fu47SmyK+cGAwea+nuRPUGcQ4MI3VTq2lR3Nf+3uR5mssMyJyXN3ziXRmiphJtPO7+r7eF052kzD
YhdKuCE5KKkHZ9MowJ8z8RSlbFyHEbqRHwwChEMr166VdyezotLvlmhHlR4URfONIFCN+4FK2h/T
UpFgv3AJyhJ5Jz4sXBkQs5BqpOud+w6MODbI736vphfDutU+ZbE/Vk0jPTWzksSRLrzDUVipCvgT
z7PYI6lZu1CwTIFUKNKX9bfVKQXcZ957XrQvOtIEtkl4S/yKAg1xOkckPt6RxsFB9hq6+WZkwNg5
neifdZB4AinWpa0xwvoZYK3vj/+2HuZhY4ekixzjbXuRbrglMI5jNYRpOxnfutz7cjCvI1S05iML
vOLguyhIrwQbTAx9g6ofLLfuJCIGoWfkQ7prj537rWohJ3xyxIn0Lo0p3kO3oU7WGI11kQ724vCU
2RkdDhWjs6RGqwpESdxwkmaxl9f+/yawc3yM3x6tpw8sZQik6smkOoe0kOHRWFuzSHCW+80imtvO
NbHMOxMdw4OiIAFcd41/JAhVnULuu2Yg1avBZ8u3zBBp/N1ETreIT/E/k23gVyrtu4LTePk65Jbz
wpHyOXgHupiXXwcwaLcegLhf2TKKX8j+WyNmn6WAeg5M2+AHuB65C6LeATuuoNXoDwjZe5uniOgQ
M7Th1uYVrWpkELoHxZtJ/ZzGeFa7iFetjGZxQ+zJgEfSzyHp9Vhr5FKRJQXEocrwaeQtKwWZrKYn
DbyegdKXNaHn21QeErvnQW==