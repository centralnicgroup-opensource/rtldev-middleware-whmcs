<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtkl9BnxFfsp0cIndt0bu9SGdT4qPcWuZDWVmvErMOzpeCgaUGaj3g3pAale2+CW6taRf9SX
QPenCxsOAoA3JO4IKI3C5rq8xpjRxWBSbftZZCrLD15ZVt9QkTbyeaB+DQQQsFn7GPQunwZ6gCW1
cwMnIZhYd8cKwwybWBkGAekM7Hn4tFM2oSNnNw1nBS0VUMCVqAQj0sFmWnKSWLEOkcfhUKDarIfd
mfReu0vh1wT/+04vTaUKSED9phSJmSHp5w8A+XE/Fv8iraLu1HfDnDdWi+knPeQ/8tiL7kkCoWE8
Gly6JK1p6aFUiQmUxOr+HxQjWhqA0nGtY3ut1joXkbnWyhuaMj8hGZveP2IuPeWfZqDZQ6R5ydsJ
lpHCsmaFd8GqTWZJZJuME+KDRRYn5tQKnXxfEBuuhDBc3VIDp1PwGxlHbX2JDSvCyI0I1wHKraja
8su6eBIIdbqp7sn5WXaZIWIM005fWFyuWGJq18ACtRy3c7Qh8iqBC2tVKxX7Gn18BuJQ/TGUx8RQ
SOAZ1lshGDRdRZ3FNAJXKt25UqXLRGfKLN/PpHevbRNuIcRgLgGlaAxcgIlp3EHcgfDrlOMX8jAW
7nGrnzCdU3qdeeZYtCbbu3U7hqmzXZqWVQpU0SlTirebdRBlteVO1MHDch03uEzOWqCfx6aOWWrq
2P7hnIDvm7G/PTGSVm+J3wIwiK/aMhIL51BPLcgZLwEAyfu7ic3r+YTh0LkzuTNFTsyC2LPHMUry
YMa3pVs49JknIOu4oxxyRfFwh6AihHRApZYnaudxRVWeNrnZ218ayjscIKjzsDfxWiqUCsO1GVpA
D2tlTRylCh10NRBB0LMEOsJAN2WEXjIEcfXdQFDuYIjWycokTTquFIFYS+2Dpr/0o2zQfwvQxLm1
ymaFkoVaj8rA4xHsrcR5BPrLzT/FuvlGe3KOIFMSVwwLrI78QL6BMTPiwCeOXXAcpLSAXLnRENn8
hNxinb0SOSfLsUI7xZIW2lzoj68AuJ++CbXKGwXq74rMA3ZtmN6ZBLTsvCH90+zVUKPC1x569ylW
3BXym800GCYNw1cZJ6DS9DaAtbCLHaS5ozeWohDiETZc8bwBHwOmrJlEvlGPdxubj0m8nArmVRF2
BQlQmSdvS49BP9ddfQrnh3DA4aEEdQ7oj6xseWyiw0iQYLhr1xH24VvJBEWkkdePj7h3HZ+Ipr+3
EDTQK9u3qFqFD/ymjzr1gH2G04pSWX2a2LIMkEQ0Vw+MUrwex5hw5CAE+xWVhY32goBKP8oUdHRJ
eaTJK08WqaWLl1LG6oon34sPSnS8VGHceM7SxsKAKGsKXyCJDxDoXGKBZK83/ojzfmzcm2Whmw7m
2VbwRYrrUAbyr2p36/4qV66izMUMU2oEHDPIlx3MOXg3urFkk/cWEvRx29xawUQu3+r7vLcrGlAT
yLmToh6oNWLCcjcPfn5tlfaUsw1CbrSCiabM9x8htCrjKAdAyNjA5yfCDty+Jh/hAkwP9iGJ8MBJ
IQuZD4pKEzqfVUZwGWTYBno9uCf7Fo4mM0jluITPDOPojhb1NXN20/erYhh7BCT1A8675rSrqWYj
Xy/qTzpp8J4ZvfoMrQ0BIwM8Ykw4x9IomElJQLZaVpF+YJ9ns+IHkQmNMGmdVuYnMJ8zEn2t4KGm
mlbV2dvccUbFvmgdGPr0Eb+tUHp7AHDX/cghZ+dGGO9F6nqEaRjNdzLm74BWW7o+FiAhjUcqeofO
tj2DJARkRdXiQ5gmYkh99mx/XZT4ERUi3gYasrV/PbkoxY4RKqBuHJ5tgIHNHbY5o7JgTZqzcyVM
PhQ8NfSXMmwC3OlMC2N2tVF83j9GkrpXnKZAby01cCI6mKjirNnGi2GG95+3Oc7+FIcO6PCuO29w
kHvygpUen1Mdrn6qmeed1IUDEGBVBgNozuLNX0fXdoztHza9vje5b24Gm9DsoseXQIQYxU+3g/Mw
XYXrKLq6I/VLGrbuS1OGYNtqcnkuN7iTMk7HVsDtP4xrsgT3Y8Vwz+JU6alpRWO7CF/R9v0UrVyX
I5eV4hI1qz4mfwFUmOWJm/DSYZfndQjOZsY/Mikwh4ZAEJNIaHrpbRTaRRI/yTSFLKJbmkNqPrTd
D8YMqfyY8zdPrMkbO0QimDWV5iT5Ys75UeX19Qj3HYZZKIXtLmx/iriqj5ebTHTfyH+Vz9kw3X+1
3stW/fwCOBCWYYoJ8HIFCSRrX+PY1DSEgN8wQFLPmzcly8TQZI4Wco+6c/MbOxeJ/xmlyurvknOC
DF+SWf/vXg67fHmjE7ptvt5NOrh1uvEwohyz9Aajks5eaQYBW39seU5Vj2x5lx22ccEd7+DhpSE4
dw3yolzpUGlC4GtQ0S0GHd5GIGK8/sEJiRI01tiBDX9sr1j9AA569dIXDIa8nSSlz5ApAHZtvkIC
BXt3DaIjmWRwrJKBOD0c0KfyqfDAkOCE3Hg7LHF4qSLuCRgmWLqdfJUPrMGLSEEliNGJVy/wtuq6
p+Gfx0JQS2mqKOvzy8lb4JYSdLkmfd59xvnNTC1WVJFmI0EUPpGhwSdXZ8c4uBgliZePPUlLnrTJ
mOeiKLcu64+8sQ3LZnIjt09+6mBWnjc4S1E0VCotB/n6v7B9CJ8YsI4ccG8h+hG5KLgqUojjWo1n
HNIPyPSHPLk7HTvAD7qutVkSYlo6E4aPvq1krcGBiMg3tr3b5kM3CMo/co65SUAZWJtinID/qeT6
fx6pTUHtHgsBYZ3so1u3wfsguig1XK8erfW71avN5tAjcQaOZ7mq2o11zxCWPYR/lx8APGlDGrM1
k5MImZO4gZvBritHUYy2t6c3X5aJ/K3I/pGJQm6Rw7z5stmNmZTpPuEddhtlXyLC+Ge79xO0E7CS
HR9y7GoPyl0f94vtfbx5HgaOnQ17icPrMN/T760xlD1nsesx1FP4BXyn4JeWIzhSopz8q75g8GQr
kKv/fPibwAtmC0Oh1gAb/4t7GHxSRa586WegmsKFoC8RHEhiyNNPYhzkH+FMJ8XqbavAvx8z+MmM
wuMTDp0IH9MJNYRxf8a00wDDMWnAvcfjO/+Br80MtT/1B43fNaqi4vV7HDU+EKw3YZ4tFwVUlHiT
XyNVFki/KgVjVWSzvHUZXLO9b9hOHhmBQPrpQSwRPNGvrHjjCW/YkjB9AFGsBAt2V3TnA85h4JZC
gqD3SuFTJJdY2UGA3d3pIFjw3h9Tem5nKF60l/zndVGsEPYOSLynMt1cSjq8vlpP6L98xgnME967
d1VE+t2wR+fE6WQZ9T/IQSohUZ/tFbxO/3JktOitYgb5YIZ8ScIRK6/gOv0ujwRJMSnrVDBqnENH
InVI+GPixgIPDPbNG+FugKDW4bA6Za///Ec546sERg0IZwp7GSxenDqRLmn441Mot1moQ0Wc5cPy
4xT1K2bf9pdirKNzYLH3L5yMT966C2HSQrpYM2poxvyk6lfan5zd8CBp9xdfg/RSChjKa08H5dyI
u5Mpls9uhsdMG8ANLRE1HDYEigZWzyYqBGeBTw7OnSRGGAy3XK1HU/IbwZUmEnJu7Aavd9CxoTh8
FjE4b7kBKSPcrF6n0DhoACfQy88f6wEZkAYF17izC+D4kZGsD/U83ZdDjlOmKW1Yy2tjROhdRFeh
zcX9Fnd0ZqYfxdLCLe523Ak5zvNQziMpfjIkIcSNQ7OAP90D1i+CLXfr1fO8GNJzJRJ2YsP6SL3e
snnkWs3G1FJEASwHcdUdMpFvy0YqLhrvZJ+XgH5B9HYSloNfGooailCM7ajaJ+ldUC6lrw7VJUb8
S+h5i6ytlTXKlNfLGCrk5obkrUTzK1xdGUr7qdTte8bmdn7LHaXGBrW0dw/JDHxhvgwA8AZQrueW
Zlua3aaHRC7HarjzndXkKMlO9djjVE55zdGpVMQNzQqZDMl8frauFsfDOnSg9319i9PU0LqA9873
9LKDawr0a7RPqnfhV0743Eyrc7G33u5uKX0mMomwuP3oWN08k8E+AI7U0alwuoIof8rd7XJc9DcQ
6BrIOZD2KsHD4u2qhZNQwes9dtamfAdEmUOJqcs1sbKLgfjZD9F/9a9TdPxTKzzi3vHPi1J4+uCi
hcR4Ovl766+KQP751XOFG1/4C8yf6MyPIu9ecm2SEZg3e8VGXc4JPn2JYw6xCkvM65c6UOPppCvG
jfmxPr4FjSC+RKwldAp5y9kqnZIjRs/frsdqvvyK9Mb2gHGk5pjmnOwwwTfJ/aSfLJTCLQBtxB8n
AsuL7LUfn4TqU5Ihm9B9146QfUwsJ5mce4dhZ3cJns206NF4Z6a8QS1GIeckrk6cHlByAv8JCaqf
KlWto7EsOVYpttP397OEBO5XBQ+cdcHqTiUCWSkJQaw+OBWDznSvU2QEx6zh9g77/3OzHVdKi900
nj5b+Vw7aY8I57K1AmDj2u18jbl3vPNjtgASo0YwxVWWjn0OUwLKtBOYci9V3KXu/rJo/Nmk/yxF
HpIuJuI2zXLpuraPcBR5HsDf3zwXeEf5wjIL02N++lsr/bXi63T27jm00dXSS5g/Dnaetyt7okn9
36FXXbB/BNJVnSo/px2EAH+9C16zUQU2+vjxMQzG1JN1aMlQuiw+4O2qwT77iD1irUyuP9e83SVl
PvPRUVMAr4EcGg4VJn028CZYarCRBF28ydqC9q2s/DNe3oAWd0lTFiaTFfr7rRbzU8D7jY+5Tch5
9f2eA+xfJYMG6R0UNw88iKoZ27ypVK8Q6WHhkRimNtReNwfWRICwqfN3d7Ifyc9vlru6EEYpA1R8
++DEvmostFmn/RGeuHafv1ixJG24kcqPNRp19hTne+wx39SiAUGBCr25p/5fDugdr8vAaziMHyPy
z3T8EkQoud6ewNT7Fs8pXz+WDRfJI39KKUrG8aLBagOVcgTk1V9eFm7T27aQstFaVcI6O0WQPvBK
8uQ63jts4WHljp6CU+oyzJsh9Ouw9AoS8BUAvyLsjenbFwbiRuVZWCvGGdsE8KO7A0UdW0NC67mp
O/pRMrkoFsoQBXLiq5je6XOFg/vL1qndNadXYZMnKobBIY66HIkE9YqMYeFd8KJlVSuFex+WpC4q
