<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyIJR92eDrNOjLlvisFIDbpbDO8eIrUKnfIuWA/UsxNmaIUX+UrcyoYS7Wk9rcIfJkEiPuqH
VjmahxVbqfsOQPeQWcQzPOLsXCm3WEvxD8+NaxQoIEgxYDTqF+NZHyBcGT0nzSlE7Icvtl/4gmiw
wQQ8qVuev7+6QyDPf+cmLVB4xb2CjdQb3TCJm1cqWTBa/AeIDqnQEt4OahL9eE+OqQWX/yTYR3fW
c0/Znj2bm3eQXZRNumviLZCf0TLrzmDRaJdgLOp58Nnx+D+ZXOk86wduh/Lp0fWx+8p5oQaJ2eUY
UaX3QPkTzAwelkmfhbAUBLGgnuDbgvi9MpI1h7azmw0EyzhdzyYoRsw7ZlqSsgL9dzK2k0NstrRK
FzCqtZAv3jNGetr4hVJFkRm5w1zfnEzngVrALExugg0PFquNOOnsBRXhWel00Ub7XGU9mSDxQfN3
4YQjEpFdMXJhIoQJOgt0d6LGpdLa4qVT2EUar5gw6WbydCW7UbvA/E3RrTvrxp08TSpdJxFKYxjU
95miEOiOZ9gDwmUwach+1RrAIYWmxluE6LzvW9Zy/czap3iY087wGX6Bcmsl7Qu2a5xfUGNyV+zz
Ng8G5nkTAc67KoueZkS7/QhVLQg9XkfvYgcE9ETUdFnhPch/zzO1DAp0sRdas41R+aYnjuhFDGax
lK/b7zypENs8DWagTHEl/N+r7A1RjG0DR+lEE9O442HVkypCYepcmuc8fUTw9Lm7mjWWsJcRZDG5
PGXXzHdgQQWNSKanCaNaY1DH0ZCtuMpsz1rRy82wq9nGMmtuZJ2uQO9UsleeJs0NI+BGNcNvfKF3
x40ZvCVqehcpnpNxBS3qJzHuBRyfed2hZGnjZbHwqOCkl1MfGPHACGdPiWyDR/AI7xYJr0HNlDYG
WU3ZE3iDQ0Q3D84rk7xsODYUs7eGHINyyY7NrmrdOcFSp0AZHKHiyjAVFcRfsR3FohjrAWahI59h
pxBbwfQhFIlcVgdmauGWzexSwQykgokIwYnMsahuUc75OZjNRr72fWbRjHyW7gmVx9B3dMW5qoz3
+n+yd8dL8ryWCdyxQGnY92SRWKn/WHgqXe7i/lPtfh2Ce1zr6DvP6UbUNYQ/VI6aVb/l5gV1NFLA
TBs/pwWJqMgB5uKdClOLd173yvPzMGPy/oFmcq/f8uxmc2+4z9mFjD56eiYSNbMYRsaO0tQhSvbj
JqaZAo38Lg7yq6kPVpvYsLvgePdwz2suKH0n2CMQdCwPtz+AitX4jAGxf7JznRJjQ5i/iG6SuGM8
+HwvXtl/zjZu73cBdCCgOJQQPRJP4U98cTaZ/za2GgYJC0l8mkTF/HJb8GQHeKbwkvsVnjLYf8XS
8FplTrSkfkozKL1TrNH2FO9zpTWq3bCm1f8YrhIBspgYegZIaG7S3NI91MxOB1gV078uyliVgC12
15IfsVufQoq8UEOixWHUDDG1yy6k4MITrzJL4rKUk9qxwB/mK9T4qcZlts5ejydIL+SIVtbYCZuG
3ZCrfpbmkxilYzRTgUOF/EYUgV32LRr2ScI2arFMokYSX42Ty05uyg3iYKhypxcZkGAH4MBJtnGa
VeHQbRA2/EVZkyK3hDyj48S8GwyQTkmhkBnJCGSVqV7rzmGkkdw5njKpXWkn9C663m2g/44Yz3ON
mR7VOIS8u/oF8301uMp/Ey5zt0NS58dJlGrvjPFDz59opG27GcNb3C2O1eTwxfpi7nB2BOJqPUxV
tQ4+NE2QS4X/HdGT5MNJL7XwzMd3rYwjX7Wt6MpkNqLQparbU32TJoIi3ktMAciAu5nEUmnUgPMv
WIpUNnFGehsYRqQXRqt8TaHvYizy5PVcHRYQKSQ9RwGWgnX6/3gFZgDvsk8SbbyfTopfbQJsJv1D
8Jje6fl3ecHBzIQwb+eVorIVWPelA7dxY+nkC3KDqmvAmE+DxpbMHqu5Ewi92QvRd55zZSUTX1m0
vmXWsC9aUYZc2pjcic6HSOfKNSLGglWoWHMexTvGUov+Uqy2lIuBgEHo9Dd5nqcPpjoH5yUnPsx7
HU5lUUO9D5N8/CvwywoKc3alh/vjCKqrsXfCSBOF01SjGurTLcgVD7p6oFKYbDDxomtO2HrQ9srA
u4dcy7N7etfZ5rP5+feheStLJSMEGNpIrg5O/nVzkxPetKS/Io3RIsfzb/OfJIh1FHlKJmGrr0Ws
FWT3h2bYoESYDb19g/FEJC1k21sfizOexWvc/quGQKMHCj2J++KhW26I+arX16cl+Ga8r3VKuklx
YTEWd2tVjv5wjOMC5aKMELsPnPoJoXp38M/wYGwHBLBvX3yz9Vlhh4UpFbIDIcsBmNkt27yxUFH0
Tpz0VNca0npxg/DYNfFHLmGOazyMmRMMNs1UILClKWFwobZtkyO9gqxlhXZiVowiIPVgID/SdgGU
JuZYcl/AFa5Y+keSoX/G6MH5l0wgj8UW2MSr1EL1DcaioDCDE5m0xGR3szivNcdQ5t7wgtpwl7DL
KvmgZUdudscAw80BtpizZznOcg12ZTsJSn3qj3aaeExgNwcVqEAaAWTQTdcEi4y81wy/cPZ8J6ib
cjn4C4b7luAQlEdzWdlgbMUAYhp6OLAOxxE3E84F4kqs+/7hqa34NhhNEKraErbMbfFgA56rPi2f
gV45LhMR7UCm/4l30j3hUQVaAYR0B1yw2uqn0BE+RVbbGJ934zeW/AidcMmSVj6LC63/30pJXa2C
o+1lTuHMBDhtedigh/gFBqORIg4obYMZwtNR0BiRyTPzjNyookgZZJVyklE2A5bHeJZ5FgVBh3uI
OvOxTf3keoI7cTIV7jJ9OKNnd7i8MbnuYbRgU8RjaMZEeUKmnbW2Y9uzX63qdVj0sqNXRoO//YC/
yLI+MO/DZH4UOAKB7omYcWo1x0QAbwJyrvmjFtDNGxkBGXV18xBgMQAbO4x6iReARy8ShRuB3J28
uFDmRPhSt/NlJ5bGwCdlWoLEME2PvLcucNUfhzEvUyO8SadNKUmRV86ozokNJ8CDN7mxDH/0e+KW
43jk/6jnYBAam72BHHEYh2XAfLkGUl/ET228BOfFBlWxWHF9tdnHGPEakAl7sy6FhPwYEyqOLIY3
nvAdqcrvp96JJVghSIOoik3baeQOG9XxzK+Wn8QPv02T2HM2xN2geUXjHhMjbwwFHBXb+vITipxe
zo3D5lh9Xj4FtIn5u1j9qLK80nSOjQae92KEIBahQr/tbPA8fshggT5sIf0ux6H0Qw9PBprWRWsL
aHb8KI+wz1RYc6N/TR4rEhzougzgil4nuF48MSfeMxfvXwiR2ttgxr1QjosUZw3kGe++vOhiTpv0
hWuforr0HBUzfuabpNGWav8aSHf9lOEpJNwgUsNRamqKmxe4f624mRa/bKdctqkOYHHs/stRPScv
Yr6G8Y4/G3HLZOcpqloTjx83HGfsKRzfw6m/YnuS99eVvH+QGoM8DnYxBSHntxbeJtiAzAh6mnju
gfVS0zT7L81d2Lf0wfx+m8Kimr1qfQJxg6E+SFycoeDSUtGpBWakT2ad/PE5wGeCg4GKcJ76ONEM
TepDXL+jnjRoyg74Y0lPggd9TgzL+h9wt9ZvE7hiqCM2xC+S4FMG+6nlyuQnIeDi23eUQKzhtSB5
ladxqX6g2earWWjB/52wOi6zzt8jyfNARrSZYSMHgiaq4kAjOwtDKhlxKl7Xuih4QGEhFxh8YZkh
MMw5xoas0EWIdnptwhVefEnd05KOY4ANkTOqe4UAAHSq6LUDSkVlEftuWquLTsdAh4QNSwob3DOB
kK28gdOPKp0g0uFaf8+qsUdW/6VsJ6ZzEC7gUAkQUHiayv21cCrhJPp9iIdOzLNNMusmjPb0Jt+U
2t++WZAwyn18SSNGb7qDQyczsIDnu02pxm7FVJu0BC8xdMRv/+0jid5LEoOJsr3/O/Yt4bgS91FR
V1bneO8o2aRvwLbaC6UO3YU+jn3HeLi51yrZ05VkQmXuemziOzVxIziRvzYkLDePc9qVZpaTcs/7
bpJMWuq0+AdMWPeTYjyvujnlWyR5YiOE26I3ZEfaEGgIedEGVOi=