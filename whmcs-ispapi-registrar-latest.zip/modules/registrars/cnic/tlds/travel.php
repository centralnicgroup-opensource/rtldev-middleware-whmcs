<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/rbqM6Bo2bMKjL4Gjrnv/GB4fOUmuj2Le2us1dT+7ry3q2EfMrl7walavdKgSLK1yH7qHJY
Y2xDCE/SDXNUzn/ObkghBXiClcjajqioLYWC2L7KH+OW1QZJ/q4hRTmlZYg5+B6Cl3svMi9Z+SLH
RTwhtrE6udw5Fd1GEecJW0ldjR787PZ2iVv24m300bvTChUr/eHAi+i3qEHFq4Ks02cMO0j0awm+
QyOoVUaYaBS9xd54qUu0P0V7qMuqGjMFmMqnLOp58Nnx+D+ZXOk86wduhnnfAq7DsE9qfqpyieTY
44OXo0hzIhrShD64tBThA9cuJBDQ6kP0NHHWv77+peVGls8x3dXG6MxQOwQjZB5j29ITHoSTalPo
Vo9fC/tjAMmHK0I/iIojw3XjTlsM4ZePnQNvwL2Xkte9kIO8P4UJn34OTrMOMf0WeVI/AMMO9DTr
40c7oeZi6k6OJBrt2Pj2p3Rj9gPBdtF3flXnIEUqpyyP1bY3n0IzTXpWcALRk87uRVjzuBVmwuy3
rxPYk89cJZl3KCbXbFEibxtnmQYEM+tLHYz+abFEmxhMWS4TDaGmrFdnumAnI5mCRVxKpUDXdtfh
6vIqtdQTdDmQDKe6cXNqpQdj7Ogo+BRS0Snjy15lPwJCSalQlIuXhT27FWXUx7Hvz/Q/ftk2KQUR
wLIlO9EkkCUZu9nuVT2sZHuAuIxeGx+BpeAwfHUh4HadNO50RSA4fcbBTron897ujmqg60yqjSvt
IrCOhb5cOZwctnWE0dBDuU+pkSQpuS6oL/Pn1EzzHApZJc28+vbIuNKg57LlBVx7k0wikbKbZqsj
U0whYGvHLFr+4FyznEHMgT/DhPIbsoEnHLbZXK218QBRtY642z+uB84Ct/VAQQgPxC6GX9GaBVvb
OyiumdWfjIwHR2PmPCFNHkYu2B74qHx3eQcBHpKF/Y9CijNiQvQpc1t1smKxbV9i58kd/kBiDRJj
bCpRqmSnb3Tq6goH04KdQtM/g2MonYd+VveSA0SRDXvuxvzMQfp0rtcvYZ4fvm2S+e/z/eu21160
cG31TKzt7qo523Jza7JHlZkLdgHQhf7WFJE0MaHq6avMG4IEuEkf0EoS28030+3VE8nlz+La0run
jvPuEkdSU7Y8YMPHpXRJzCIBGJLLm0S5trub0BAFg5zV5CHQrZDYfuwu4NTNcJSRkzpTNH9RdX6N
V839NEa1k+PsSqOibHQsLsG+/K87LS+yW9DuRha/nnAlTcdrum==