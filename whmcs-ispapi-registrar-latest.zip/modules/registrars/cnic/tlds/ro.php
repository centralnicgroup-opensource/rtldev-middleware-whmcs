<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvwh8A2hEvcNicUrWolrVF6t6n8JWhgaExIuBb7z3+Z1GLM8/YKlXhp2De/i6hj8VMijaOhh
fg44w56hhGiMnj9mqqP9tLYMrvY4zLT8AN02UgOwivTiofIrzfc67SrfzjiYKCeu0TOxoFo4ZOD9
i8agheCqjt7mdcBNMai0HcmRHR1zal+gmqQsmw2yLmPegS42BXlmYpFpzYKo+EDh/dddZ67u/ogx
20KgwaAjzr7VCCLF2EGJpXmky0aDmdtzg69OLOp58Nnx+D+ZXOk86wduh+viR9i+FlmIqwwGT8VY
7AOZ/tOZCLRV/6xf9vPN+QhHpTIvjXGtD0tx3LFdu1py+OkobMSMYonOBE4ZYBgzGe3W8BuxNsp7
qUMFrfUU4yklFJzC/5fwoWIY+TKTtsNDxa949STHo1fxuXWtIDqUuiWASpJ5LBcmZO4G09LCmqAJ
CPS/K+Ob16F7Ntvgclw1ktBXgf8D6AAlBf0CZ9Et3OlSJDpeXkf88LAMR/jU6wA6n0jZ7Toj5Fcy
7YWo2Cqa9HKhHc/oLeED6Wy22zbQk/LzLRfEESJZ6vU8gvmZ7sE8n7TlxIMThTuOuYDYx4VsNZkt
5qfrDrUIssuaCiI/jzskrIH8o5/MC5qvxMoYpLfR8Ks4PTOgq7q5ML8hhXyrhyHfYWBOdhrx6/l5
z12QCICbjepMVUM0DLmLkVc2H9MDpyJAsxc1hwisIrn9AH8IggW3rigDpf/AwPUlHxZu677zjeDr
frLHbHqZQv+/E1wWL+6y8KJ6yleY8LEtcQPZga06a4YzHcYsooReTB6GodQIYc82m3MjZR895eLN
+S8jASnRvvnJYMBktp9HnkQxXJE9LXfZpiEcL5LHNcH/c7RuOYkxB85T8mVRJTq3JKnP+7BRM8C/
zSI216S8Zt4/1cDWGmK2M+Yi6msHweihTMGa2KI+NnrzsQwg3NM1KLo1Tnyp7rxSHQFPCputdqvF
yI3XQwGkyRn9Slzk+l9oqiMSfs8C+3dHcX8Ph9bbjNjU/5QrlsyNL8vjWrh6BqWrqzOQuT6vkG/5
HJavWmb7NhtaRfqRjodN+lZvNOB/DIcYYbA5L2OcCE+3dYCgZLqk8oxMy7kXjwzymTvTMYi7mdlr
GO4raRjARBttE3Ddne80rHbLvOdMTxTtYRtNdpDNaTKIcttQtlW1SvljlTJNj1Oi/AaGqmPtR7th
cgBIqQyEwwu4eF4oYxJHukX8ej0ikM3iIl42miR+abQYhBn8OBC6yNBxXkxKlbDVq0BUuCZTomoO
ejzOcUlif/pWUNlnE0UsBFOgrEAbCg2CBKuQWtkRQfVClbld8YLEcxvF1jfA/2Cj3Y7giDBXPzdh
u/40PWFDfFQuN5IebrLI+ONo0AhtlAzPP3wIM4QzXTBdMk0lnnRbpYXkBoOKM2jEcnYMgjT/YuGh
Yqf7/3Np8EquzYEaDF8W3W2qaNwubWkdV6Z0gOUEhCamCoDkjegG+xUPoMuOV6xnepv6FwzPRhzT
rqf9jwlOZM46Yhf4RHQlm9zdrGg8B06aZaGuO/MMIVxmJrMpdjTrpHMyuGrW0vKJtSkKuz8RZ1jD
vr4jLIj2qWHG08QMjOdUCocjSwn5CGSUM8T90TFi8MEnkrRm07+c5ll4q2be87PqUDhyd78RktEJ
f1uhWLeBlWb1Gvv4Ltx//OiYbAbHZLXzhN3NMO/jrw0O7JMCrLKCeS25d4ZZ+8VxadTn8zd+ZMor
QE3LaaG5IlPJi+cjScQv6IV8R7IHyClJnphZLim2M9R/7VyZmuyvuAYBzmkK6NrM1/0FFjFEIuPj
gg6naqRPbDN/rt7JtlK4EBhi65Ln3Xwq5Fg4XPN8xYiF7QN2Wj6EZ7WOE72t0ucPFukioFHJeQwo
sAvvQJYtzmAXXAVYdj6EdBxhAgGR1WxYFJEzh78HoT99CEAHkiEhjoli3JlFVJS5Ix7UnS97eCKN
5YKkX544kZtwdLNpiTbVztab1cepq7FSCPvcAOOWJfh/eR+kvwJvHwB7U9u4JUW5TepPU254iMTl
nAFNMzk1Vt3+G1pAXBJtZTKLewZPJHekCp/7rOybM03Pr+Izg/cdjhtiEYQNRou4TRgHgTRwsOxj
dbeZWeSvROW9e/khnotvHR/YfR7iKrfS6PB2YSzXpECwTXmRoKOxr6D2DQdJOq/0XqCNQbMPOb1Y
O9u20jxxtLYc4e/wCvmpKgnDCwcyYEXAdpRjowKJhPX4Ks0d6QNny5XCcLDGluAjCEDubiLSFM6L
oWNE2UfvzRfssLFZI4jYCGPLMwRWu1NUggluRAkjwCJaEQDXppelqGXvW4OPPVmom9dA5LeTzJze
kgQoqaaCe8f6eh4121dxxgbP/tqD5j3gjF545G2Pzr5SBCe5sAzgNRw3TJ23QEt067Oz8LDjF/H1
FQ3pdVSGOf1oukrApVJRpDoPNLGpEEKLv0Bwh0R1eEuVUrp6+TnS64dQbqG9ub/xOA/rAtIgvcFy
SbvGTMNSvsoUtrWtepFKA/UheAfuUhCIs3bkLw6881cUhWX1qprW25AbuPDyJSTcycY0nJvGCqsZ
EYRp3hlGywuYiUHVqfAZNzB6NesNVunlKFPVlq4QKR50Fd7VJU2xUBuJr8cSl8WDPxPu/GLEj0Is
nw697EzIocUjaKKS3NZyZocbEVXgmqfmZx7mDQC9NNAaVuhlGsVLDHlHZ20ElIms3LExM/JahiQ8
Msr3rhrka1MLa8kEWX+TwHs9Uj3a+AyYImvZD7cSDe6vyZrjoV7gO35YqPaugg2qNFS=