<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzJJ/s2W53/4b+5ZQeFLQogBHtuUP+6oLSzLp/UX5DuCKxdKvtBt9loW05IXkc+bi2TQ4GXR
M+IY+9p1HBILLrf3T/p+AOfXV6XIP5auCmd6DI/OP/Bt2pI3O6/UG+aTyryqD9Lut9Xbd1KGLD/f
aPrYvz40WIUMAbf65MDqSYSxImWzASdLT0RuVqLBu5S+duWDkZCio6XUtxMoVaVBsIYE6zW6rsei
bTwJnwH2MKNd3hVKwuVWo0NH6iqx7g0rS53G7bMCnI5yU/ZVeuMBY1kf+A+CQB6eXFClBhcbb027
GffbSl/COVHSm79bYH0kytzUf9lvy3CfT/qN8e8MlmSx3ek99bc3Zypq8VRwnEdbRC0z9HN+AIKm
6G+BQJHAteI8s5vVSu9XtccGYIx+6327YQrM1eXesLsrxs1FeoGL/DiBPP2ZKbiQllGoIqeKnbd4
vVxXmedWfwxWVVN6Uq79oCC8WZgVTl+yVnWXmuNQ+yM+AO8a6ea/Q9t9woeS/Uv+YDF+qZ9OID1a
lieSHmJT3U3Mr73QJRH2/VP91BW+V1gb7jMNx/Qh2hFFuBXEyW86ry4gCu5fjpCNNO36gOEmaT9I
h1Tv9/o1LNdeS8OqZAmh9zoR2CwiuAAw7PRvVYZdqR9rCGB40JalSVYzsLce6MLJMadmeMK3b8/d
L0E4tpgS8VIwTyuBiVDSRafVwhoaidm1npMLlHcBOWte8d4DU8QAPjYCP2KoEKxoVgX+BqJKuCMN
NqWt5ajQyZqYPf4BMveChuv6GxnT0gnmsYsmy61YH9+Ksaj4uBnBmGhvDiBRTN3Wpze/I23Ui0eu
SnkXR8A+z4imk5l0fAQCzmF+OAs6ngydfA8uxZKYGK9oc0hHJR8Nwh94JNzTnS60l4KNexNDWPdl
O44aSjgFBikHKrix3nCqvmM9jwPqbt2Ru01GHVtAeLancn2N6GDnbnnYw+BOjz+JGA6CIB4pYb4R
UJyUxl0FwkeY2Zg2Z9zy6/ZvkjfzlNLWryVfEhIq/aM42LI5fYGrooKYO55GbMePW8olzzQZqaB5
NWWKk3UuA2tvG0pnGyf5OPdqQZkJSwaeTVJUGRWslhYj7+Rplke6xrMgSnwv4TqAI2NC2zsegkSR
GpbhdD1h6AIiB3rKX7sgD3zQNZ8M3DYVJ+/AJvhdUtniXEA45mt4U0F6ihfwsE+jrIGr++nxWQck
tLemvAOo9r8AYi7VkoqCy7HolxNIJiMSD7XCPjcwUfHO0F8/WpeiOwt0UbzCDvR/AZlA6VcCRFA6
8lon4tjaksWOQ4xqSKpGba6H/Mxrkq4XOJvNKd/T/28dLcWThiiiMYJ4M3KstQLhAhS7mDFxMzu9
G96SVgX9zyhmvoxO1VN0gncv2zm8OltDySX7bLh1HIcvY8VT8AcPAQCmfD3p