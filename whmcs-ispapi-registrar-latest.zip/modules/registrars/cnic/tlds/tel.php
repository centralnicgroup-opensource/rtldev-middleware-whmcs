<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqFG+Dp5//l14v1YRVz98EguV+WENXuxvQYuOf14uPotoRenI/6FlgpR0GCkaG/GB/NyUhvt
PAvHCgDfnuCINlUBFuqGEM+ucyCA9rsXchrL3GWLxrc6ves2anwIw74iOeLLFVlrzC1olJ1LOJBp
GrP7h2fKemrrZaf+JgUrvlpUdOvUyyhsyucv+oVFxpEURyFH/nM1kIH8LVqsBhvbezSiTAFhl5kJ
wvwrp7QEBZErOU/1CpFoYK24lI8rXV4wNmXrLOp58Nnx+D+ZXOk86wduhn1mJ3SZdQoblgZZzuTY
D8SW//3IedpvpRnQLdrmKzzFArJiDo+EzYIcSGPY/vmRr5qHAHWbVIUHjSdQCx4P/s6GM5oF7+A7
L4cIh+Z6YsTnI4HktshhVMZVfpkzg68pD9trXv+VSvxUqRvVY7O1hj5hyc4AuHpCr7AoGMtVFLaO
aefNIll1zhqcpKHUGITqqPoCij9t+e2+Bl9G4PVeti96OjoDGlooPXcqvtEAmV21xnNGB7WtmLEs
YCbeXLT0t7WYzYK2VjPO6TQ9MjNoOxec4i1QgO4lcUeiMcXRYzbzWsqRdG/kr5EvWO4B8FydfAZL
i18hsxKAYXHnUGsg7SyxJk+A/HBzQuUk+UVnWZcjs4xX90e/8c01hDWCZyyQkuDJtIEt6TBpaFiE
ne30z94CotwQzN9QAjBYYnWLIC9LvpwhqDKtv0yLEfVPCMil9+0qpOh4+tCEGGlFfcu6760mJ5U7
fA/XlC4Hh2qzGoBwSlZ8ZZWltCIOH/iQUNSBebngiFGTAsp/PnKpybYIUBRoqVlp/wJdabEyTGlw
NpkpdzsrmASphw4qUVlo2VnjTbrD3pzywPcFTPKUOoVUVPmI0cfKrsB/GXLyEDmpKKWl2KafcFR3
MSng01tJgamZJMXFp6WDoYKMCEFN2K0u3xURX1GzZcKJ7UJm1SjdePExHFFP+4wbvCGvB9DlFXPg
OKWHLS4fGQs9Ltl81UFJWFdxNM5aGKzJJCdPnXaSBf2wZvJ9dTdiTil1WtAUFr/FGggG5ZcwwyXA
PgyHvFyA7u93AnK9lKC2jNS8QtRVW1GG3DmVlX7vkoDCSjxthh+BjXrKoU5TqOSFsi2Bg7yaRJHv
Z5kdgtkDOIR9dv7y4ZYvmI+Oj18AaGUPKvND7OX+gNXjyDwlKaJr4qbeSkJ9tW5TOObrpt0hsVI9
fqkeeaRN/9hATu6DTL70LMvZL0t/NTSiJRvbBGGQMEl3aV8Mt/MdDE3LIajFC7jFqSP44H9w/Bhh
j9MfpJvIapRn2KxGGNBU+p51RWXEX6dxvF+jUpyGn03X+R9sPC1T/nBcTDzkMT1gQ6hOVwcFxjyu
zEhDr/v9pBKLU3hoEj2qTz+xc4Yx/kn94l2ncGzZcU6DeHop9XX/PsBX5x8BYdToiqz8HQ25/LHI
wLKeqRQXz2kOxu5BH5HhqRWRdhsMwgC5ktgxC73L7PeNNyDaAR3onmxnLL4akVs3b9qg5B4SLHeu
D9wmvsmMkONjqJhXtULq+v8dbvoU9iTUNIm7H9TJbwl62FXRMXE71kDamMR0g040OZa10Hx/Lbzf
Gkn4hX+7QG1JsjLANg+72JeVRA6jCOGuDSnepvZVvZTwnvYsb1CSqwYE1s6509gSAN2FtrwwHDaY
aT9qKx5pw6O0I4PQnmOeMzFN0TQ1GcKICNOvW6kOMLvBk6w4Lu2bBw8kb5KhJ/+wBq3WTx04V45k
8mQLe5ec8S9/I/Fk7P7P+BqQjqz44M0FX9OlFReg473y9Y5mE7lzYLTBacw4lj0lWei=