<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/d/4DJxV4Cj/7bFGTXAcQqiwN/ocrDMqVWvYj6r9mwONo9y+J2+u2tecN9vcDnrwQmXvSKG
QgGqwbMwhnzAKjMt+fo8Tsk1T87JoV956wC1/4GLf7wBEBtkvG0ODb64cJJcGJarkuEkMw5GCaBr
GpRXiHEM/6M3aoHkWCe8K2My/67Bse2X4IJmAi10eRVgU95LDJFY0To1zller7InzsnOA9i54jW6
3CXlYNSBIBTjsc9ILR13GLBb0100N3L+bWWJH5MCnI5yU/ZVeuMBY1kf+AzVQlyPnYkvuvKY4Ws7
mjfbK7tlNqZuea+R6UXiniZQ+D1Fo/5KAo4FYSH094heZxapt9bbprQJiuM3go2xNRVVgTupoKOP
yozbYa3odTrQ2gMX1mTrtKjBPqvNn5hGVIvJveMicqkaeQJDV6HiYwlH5e0+rItVh9IMW7CGq0xh
UClGB0IRQEMext/5wi9Uhf2VDdCsfD2hcwwEP72SoAYdEMrpx+9/NJWUCQgJL29OM22lvNPAY1Z9
5mcpzvlYNQTK2JVkRdB5FMv7TIy4LNviBozl/cx4JGVtJNGiFLZNGGaZUqefN1maAsMv/xfxcWct
eREaz548KUtRSzdO5naKCCftKNXibjjB3KCx8tuJDmXmdsjocHGZtNo3WpgIXlbrbroF/uWKKr+4
yWSUz8o9KgbIkSD2UXcZC+arwuOcdhvdPbet2t8XJWp8Rk4kUlQmvmo4ac4drhTd80uUCoFu2Eot
hht5oC6Hb2tbEUCR0nxha5xfBrkkxwLHGQgWwM7ggz9zeG07lFkHcrMwzzJ9V2OMVjTLl/i6ri+n
43ki2fZ98FE8BKhtL3OKC5lUFZJM1EwYz8cPBFD+XFwFqTX2KxOMVVD7lH487BovQNGdgBUewUbO
ZU5CJjWE4CXoonC/Q/z6ZZt2XBAZc1/7IHwb0cWrrrgZWxTn8JTE87YFlROD13+ApAROIwzg1OBo
uhN+N2WHc9XZ6jCuDmMfvXqBPIwVZbWRw5jMl6Z4XpsYTvkpb9J1OBQNu18m5jcO32sclAL1d9fb
56mFLAQ/n/Kdq1d7ut2jMhPnpz3+crp6PUKnkKUlQDQNE9+8EHqae2QpZpLfgtVRyOlOXpuOWN2x
aHW66jBSUnTBBvCuKf2zZq69m3NKbsArh7ZGRi7msAR0aXtPC34vwrYom9wNccwcjpXuAOwuAXsu
MPon8ROTRnvq58an8RaWLHa3