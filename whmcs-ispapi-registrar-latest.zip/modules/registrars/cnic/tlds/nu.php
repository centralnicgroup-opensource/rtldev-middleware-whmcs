<?php //00897
// 10.2 72
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPovoyld1tyR+dCDdsfa3/3hjB4kL5F8NeDmPVyM5T/taShxRRHwL8p+cUxc4SlH4HetukvcU
6WPbuvTeR8W7iz3/uf5rV92jR3iFHblcHwg6RFzUyRiCkI7AGQiQ9EJEnKBFA3YLnQx6AlpF8cLQ
Xfz98cisgaMPA6wru0h96ORLNLsY+k4m4UcXRCxR9IX81fUiiH3T5ayD8f9kgHMeSsoLM/rLrE6p
R5A4YwTNcUPHgRDTJ21u36tyXSXQ+HW6E5M2irMCnI5yU/ZVeuMBY1kf+AzDRM9q8HmbA2yuK9k7
GZddPSs+/GbEYRdYe6Ku6ygGKiQKemnZ/+lr1Y97h5iYTYXRP0u8uh3vhkwnLTrr33+zHXm9tXM1
UFTa4V3Vm4mEr3LHZhcfPrL8X+LKcE46TRIcBv6CbJwqThltexdPZOO0me7ao4uRtgfHyRg3h6sL
aN3/eRvQGj41w+a8VsYfjf6lX3OLDKiPeHnq99mhv3af9flDRxT2Tbxs5LoIHYmfNolQlRBD2T5I
Dt3d0UGz3gLx87pQv+u2uqgp3j8tLIVKb+cRKyGWlOXF43/0EQ0pXITMCQsASh9wrUQDSNtzi3RU
aQ73A6TpvHHtW0W3H9K2XoklGZM52eGHJzKNqhxD14zJQICaJ5ybFxCWP6H3XIj8Ry2wXvLppQn2
GTRa78yFtWyYfiZC8ksTeBzkxN1aYLaDANQtORpz9ltjQ5ZOGElaCk/i+JRzR13Ul34j0UXkGpM4
QLmEYsBrE9voxEu3bs8+secS1mMZN0TzS8XV3VFJTXW5jp2cWKAfWLAF43GDDEjOhllOkY7QN3Cf
04RgLrliUP1EorNbE6VepGUgiupjsG/LpRmIxTb/1MAlhClBSPBp9bbFI/YzwntunGpCOweka0W9
WIAGNv0nzFjv1R99Rq6vWsj4g6bmiDtAyJP5kesur5vIYiJj4+tNEURYOhaQHVHQbFlIQmqhbRmL
YcmCtno3HauKAekinZ3/pCTS5Juewz0LbOIWgpsiG085ygVdEWAOSZ2++IktmAHk/OPACNkjiv08
tnUjdXhlD7XJVUT9HjDpHjQWS3dDR46kOK+V0ByzNoVv+xtElnceW/0RvF5mD8BtcmslrIyXPSDL
n3q9MXuSK/jVAhoMg9Soa/OnOO+C0vyah+2loTl5agVqaobo1n1FjnEYXdpEfHqhSdpyDz0pfbIL
0kmFZLVNdqxGEKfcGr7+o0RVEXu6w6L5rkxXjUlsALIXj7wqWajpN45Dr+G/JGxSdyrCZZ+Ey7wp
XkWSMlagcXaLmesuMFihoi0l9LcxOYWgjmCbs756s2VBoCF5D5ss36fGO4jxMCCAiOCpY/Eyh87y
j5iXGOXvnh4ozOywhEaIU+MmzIIFX4/jd8PTsWUZs/gT9cpQOJ+QNOD0GjPfY7rMaUOi+HEew7hG
6D0O6AM0wmGiN6PzrC276z1/TB7/f/St0U2fcIh1t/YcVwGZDrzWbZdktjR1+H3CPvw+3FM4So8t
0PaYJVUQhzDhAzj3B0uWHn25BMXPqSxJjmpiCHd9ww+L7NAWc6pbQQ2AbXC+mXEiBxKFJqNEBwOe
ta0c