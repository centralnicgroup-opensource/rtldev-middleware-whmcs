<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class Domain
{
    /**
     * get domain status
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getStatus($params, $domain)
    {
        $r = Ispapi::call([
            "COMMAND" => "StatusDomain",
            "DOMAIN" => $domain
        ], $params);
        if ($r["CODE"]!="200") {
            return [
                "success" => false,
                "error" => "Loading domain status failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }
    /**
     * get nameservers of transfer request
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getNameservers($params, $domain)
    {
        $r = self::getStatus($params, $domain);
        if (!$r["success"]) {
            return $r;
        }
        return [
            "success" => true,
            "nameservers" => $r["data"]["NAMESERVER"]
        ];
    }
}
