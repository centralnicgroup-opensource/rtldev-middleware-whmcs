<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;

class DomainTransfer
{
    /**
     * get command of transfer request
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getRequestCommand($params, $domain)
    {
        $r = Ispapi::call([
            "COMMAND" => "QueryObjectLogList",
            "OBJECTCLASS" => "DOMAIN",
            "OBJECTID" => $domain,
            "ORDERBY" => "LOGDATEDESC",
            "OPERATIONTYPE" => "TRANSFER",
            "OPERATIONSTATUS" => "REQUEST",
            "USERDEPTH" => "SELF",
            "LIMIT" => 1
        ], $params);
        if (!isset($r["PROPERTY"]["LOGINDEX"])) {
            return [
                "success" => false,
                "error" => "Loading Log List failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
            ];
        }
        $r = Ispapi::call([
            "COMMAND" => "StatusObjectLog",
            "LOGINDEX" => $r["PROPERTY"]["LOGINDEX"][0]
        ], $params);
        if ($r["CODE"] != 200) {
            return [
                "success" => false,
                "error" => "Loading Log Entry failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
            ];
        }
        $cmd = implode("\r\n", $r["PROPERTY"]["OPERATIONINFO"]);
        if (preg_match("/\[COMMAND\]\r\n(.+)\r\nEOF\r\n/ms", $cmd, $m)) {
            $tmp = explode("\r\n", $m[1]);
            $cmd = [];
            foreach ($tmp as $param) {
                $param = explode("=", $param);
                $cmd[array_shift($param)] = implode("=", $param);
            }
            return [
                "success" => true,
                "command" => $cmd
            ];
        }
        return [
            "success" => false,
            "error" => "Loading Requested Transfer Command failed (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")"
        ];
    }

    /**
     * get nameservers of transfer request
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getRequestNameservers($params, $domain)
    {
        $cmd = self::getRequestCommand($params, $domain);
        if (!$cmd["success"]) {
            return $cmd;
        }
        $ns = [];
        foreach ($cmd["command"] as $key => $val) {
            if (preg_match("/^NAMESERVER[0-9]+$/i", $key)) {
                $ns[] = $val;
            }
        }
        return [
            "success" => true,
            "nameservers" => $ns
        ];
    }
}
