<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoVAHMKpcxvAoWVGHc5ocMY1RXc9zEHoFi5ZxtFWmS/ydCiVCAaUd1My4s7ohGxpEVzft7GM
Og4SQ08VIZjBFcOWcOXrmaJdqgu5dl7lySCmeElV6E0hBibZBbeRXKZF0TWhSn5HTDmqTBQvDerl
WHMd551RlZYDBldjZHUkZ5JA30+On9My9QUh5tSxQ6wyAD+UeLO51fbXUl2ujkJLZkc+2i1hwSG8
ohBdYTpS7v6YvWzN5+SNdvPU7eHEdEcPQ3wdNsBcoWUNtphwmGqGIJqNcpkzPvRik4lXexHFTLbx
a8L79xqtvu2Fu/euqkmxfP2QY+ugwyD5Y8PUrKSTtpsPuXxmQxP5sIM1anrUl+OZxpF1rAos/uWu
ItavPFWzqk23qtQ/LADJUR3njnbBHCxdu6tmOcQVkxNSLW7aRIqzof19trs0aw96fAeNH7+F+7IX
67D3QwDAyKJsHERjHEUSoDxaHnfssRGu7e657OKr6MUsl0vwiXV7jMRn12/BFwrIpNyOFiSanQP1
1AdffIkucJRCHPHwg+Q+nBu59dHMmSg7Kcb1gSOOfvgjhevTf2BeNP/TW1iz2unRrbWduLElypJk
9w73hV9rj5WdcBOg1t5R2phiI9iw7VOiLL4fKG/jDytMDcquYWY0dTMSXfdoW/9HRnM6RvwqvbUx
d6W5rgWFH37QTJx3lGFlagtTnqywHiA4xskH5F4OkCal9dDNttXYHjgLUd5qGNv8/12XXeNUnxbe
Dqk+s3vNOh7FloRCpTuXZ4RPsrl87GGE9tIp/KdBhjMkGkPxUm1Z2lo4KHqeRg6UlkLnE65QNGHU
WgIet9XT5YwFWb12M+hRy63qrXe9XhoB5EKJDe/sy0KsxyM08vuY/liSMFZvjSH7OpPDAv3EblS1
HIh4N7H2uL4JY9rPyVMBXf3FmQ3x4678PUZoOOzhCW1A40//MyKdf/Nz5VoxW/+nLI0UEJ31L7h3
HZt5sxRlzrCR2xVPcZx/CMU3tioyB5LC40nA6c60hlkvINGWW6K90xwBkWFJ/pqz6ZPZlSt444V8
yuWZvMdpmwbx7CgLKuxca/Zg6N4gUoKnk7YPGW76SNrF3fzkyK6qhBtmeKJZ2gAc6iigrPpTLrY6
dzLYND3ZcMcX4PUF59LFmi/UrCd3JCUxiLSC7NHBKGtOoap+H7cGhTFHTkoOLewtKraYnrB/r0gR
8nLj/uA8ju0QkRxr4N7ESUz2Tn279xvWX0DZcyDv5bduYmYZLqnz2sxzWG6JFXXkgI0Dqx8dbj8g
hhWa4Dm/SQAEjyd4TdpdKTZ+nBaDDur5Zw9kvThiKk5o1fHQFwC+DS2E1ZOA9uHWApMJIDxqchW9
M+d/Uh99EeGaPuleZrOMucC5a/rELc5EZQd2aZ9Fx90fYYM6Pp+BoIY6C16kAdVyLApCnzU3+JlW
8etV0qudRAe7sGYqMudapXSnvIcKUEtx5u0Kc1Vw9H23B8JuOYxz/0M+dn1a29dpWcO4PL1sty+U
aNG/Km5k04Z/s31FE6d7MnPtM6AJOZXdWNQctGNxQzFW46NCIuwgSyqfzZiY7TCjNg1zXC1rwLyT
FVENFKVLP2NbteQ4II4VamdTwHCVC1xntHeMlT+V9R+oFZI/JLKiTh+mxL9tEHGuaIXx6Irrz1CW
6xTw3KSv3zCYw7hv4zJFnC9/vCns/xVoyxW3nNZDmOEZ+bBAkBrseRj2Mkb5G7cvhMjRjgO98ErE
meflH/0sPIWB+3IlxeBUjGlY3qu7/El0Bt2LGh2cRCvjm+dKBc0SwBygdgpblVBaoYtnlDGdVjvS
Tv9idlEQwRsiNQq4pKbSminFGnFy78f/jgxEin2Mpd9bEcXkSK/DQE1R9bxQDY1/u86aOT+OfGjK
FjG64Dtqyc/ownWXwLKkJ9flr9IGwSjMYw4Jyj42fs/R4gxnpOAuc9tsAL+qYuFvayoWhnw/xlYI
N4R6W9+l2Nxqi415RhlTd+j89AtZXR5xqIOrDoh4axaZMcQijEwNi5tCuG3b1xfHwoA4k6CXapJt
zvrzh3t3DxJhXuTjf5EHxAtvEpbj+VnaoUre5hZEoNCUoxv28hNIfbiBCteS3LvBH0ynYI8TipxQ
oqeLZhpuQ+zleZAX7P67z9oeFjAPcCmPbKh1E5nKDE+gkQAKXyOEZ+3xFV0ne7UPSbWdAD/ZMKNf
S7kbhyl1jADmCdPeWXDgUehR95tg184IEqFS+UCLYSRrHo53RnsEmr29Ax4Btn8GuR/POLkxJ8HL
z2tvS+lO/UXnyTFT7Q8j+vLbTIa7ryJbalIlZlgtnwvL5MXngam+bngn6GbaRwQye52J1YQAWcye
YSDq27sJYymdWBupTV74Jy1hxvcg/kxIAkbkGB9eRqUr1/QBcmPQQ5ikGBrLHVmvgXC33GNCIagv
0Co5gJb8iqRHOqhoK2Qs3ThMH/fJCX/g/wY5yit/LeJEWDuh5K8RsAIJtqTeMOOKP7voNzJXhxs/
Mm8MvVFY+98OdpAksAcRDJ10S85+E4ATHe30UeSRoMNJRwlB8aj3j52EUhibCOMt+dlSAFUQD3Lk
GLT8levatbJ8MAFHalF5pwGUmx0GgfxZIFjpcckdIsgPiraeHcYtG4Yc29/Ta6httxZ9RYGX4mHB
T/dfpnkINiaZt+Bw6fl7oGYkCUaTaGYYE/9hFXt6xOhg71MVu3xQVHVuRu12+wR3liP+lo8Dqy9O
UA6H6I/e55yFV55i2JA1DAz+nhuj5+B66+lwVid8k5TRSSK9UgsiEdzxN814KechMSjQcr0gPHqX
inWcXG3RSFaB+/UvROoeKpJ0Oq0Cw5TvTJdETJjw7ZlqOj9LcPtzPC/4QSIa+QedGW8TqK/GvAbM
ea1U95vnHRSotDF+