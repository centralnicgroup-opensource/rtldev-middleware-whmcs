<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpBxj+GCQ0pBoJOYny5DFflRaOeXQbBMSBMunbqDDi/cqHU+QTL3BV4LyT439M90WCWEptoa
/l/V839NyjB60N4UTZHJ+8RabJjkZe2ddvjt19n6lKeFoQHHyS3tWb8e4aHu0ar5SrJ+i99jA9Ub
EoHMe+va+cwxFm6HJrYjW8WYNRV/27IxcRR/ukA5oGNgms2rEljQG6CjWgJiUkWWolfYmzsuR54S
9bDhWnqmTq31xPJGkFCKAuX/OXItIYHhLNM8yNb5lAdTnEVTNraC8qUfa7PgAkWEP9NYuIbvDadM
IwXqaf+Nr+HKx1ReRu1m0H4EpEQHPKOvjmWvk20fE9BYyl8ugQet7KcwbHT92Yecsz7nSqa5ZEKC
wF+i8/Wbtsk8PBPfFVIjXE7fefBuiU1ro2QNJrPrBmzpTayWgQIhX3ZIUotny46Aby2ioXtb9xs8
0llMj7fBPIZyyXom1q3HAnRKb/MKulrHHH5yNFlsvdKTH45XbDHTRD+ksAtJ77U1Pye+N8xDxJ0r
W4XhY4nICnXFjOQzBQrwUt704UZI7/xd7rX6vofcU/46NPokfWcZqUTr2yLsk2nCXsFKP/5IxwVF
dz+uUbmukU07l6hTb/XxLJM/iPA0RD9/ft4fgCFltXj08MJ/k9hSDDRo71EMa05GOGWQN0Es1snn
yk4of18kaAdhVDZwjwPkRHJ6BhXht3ZK1mYl7lve2TLg8YpM0hCPoj1uFdkDO5Bm3ctZQTCc5aym
cU9kfunOGjD6HlUWv2Hc0PInZFOsKAvXRPyMihMPJkvNoiShB6i2MifoHFcUCUQj/YMmqZe4vYgu
QiQqiywrN4+lye+D8zDwNryf+KvvhmTgTJxAmCcEN/7Oa06ssfUVwOG3xG2P7BtP3wXVnr4teKYt
jYdFhL2XMRqZdHQbCDCoixZOpkxUHf9AGhh+N+AKxHeZsgFVKNuY9blwmlTZsFBgIW8X7D5ZTHJi
sZjspTJs8MaF3O76jqADS6yDixBVu42zeNOgldflyJZOz7A07ageNc1Rltwk3HxmicnBL6sW9d2o
UP/HYrKmtC8bHoj4Cno7py9Z9DPaigf4skYVC9eSGtUXYA/DAUHJf/8ABbzc7jzXGwAlIAcarAI1
12wLx7oCD0TI2l6TFxClQDhlnT7BNupE6nQDgNqgmZDA3Lg7ka3ShSAbFQJf5RrVFglTiTE6vq+4
RmiDm3x30+d4JhJ3WWxzmWTQSIWWjngLyNCLVYnCOhlBvDLcOxyqFinT2FzpULswSDrvuf8J1azZ
kz3LS0ncpXNpweeM26uui3GkwhJlaPBl8uJBoOfWw3lFihgnMcP88bQo36CMtgba2+xE1NEL+Bln
sqlSv2zliqnptUEZsT7mdZQ8lqNSbj3q+gWtt7hDvHW/wcmugfm0JvMHaU4WWdT1Ep7/Lbcouy4F
UCBvj+j/uqPX6RiQv0oN0ykckUMmyt66NEtnLlalwaP3YFCMGBJVWbT5fQxuMIkLOBgoTvCYBmvP
iefXxJrGu4UdoJR7YtWO5TwXJ6Nx9Z8wrd7Z4Lx3qyWXu0iCNqpAORpB9mgpqV7Q3puS2imrTcYO
eAkFBI90pncoO0W71oW1qQYiWnL/X5yKHyecH17WVMiVgmKJmEYE2lLptlQ0jZr1FIe7PT9TpfbX
i9H+zOmrHkCSVh9yfaJ/ixkqvVDfqlvWn0IchUdaPilvHfnl+wGe25BQ4A8K8ZgIiGWTKkVDa6WV
ELka5ZNChE0Yjjpwv4opSbwkyvMNiQwErHGNwzhO+yj4+B88UQOWyUjKNgAKQ8oyGZwNYPHdE0A5
kWoRtDRh11xFh+aV7hCHUANN9UWvgnHjTmNrb4neiBIIlYzRqpekRLGMa6sxfLYgqxp+TPADZtTw
Yd4W07dwZoVeb4WviWrr1XQCYY/ne6YNXf+RhGh/BZ9bGwmZDepV/ZXnaakpzcEoUvL2wbaqvhCM
4xBeyodKPBNj3YEjPbOdWiNa4OhydEtA+yzGBZllZBswYwhbPjQcBPTGTmL6Cg+J2fVf0FcdtaWY
r6DyrLh7FVQvQqqaD5uejpFEBst/8WNNS+hkwQDpoaIUpdNoiHq04ZY4H1lDTPmc6fJuvtx5fB/T
2RQHZvOvgK9X5rN16f8rEfCMnPAe2wsSfvCaBXD6SzObyg7zPgS83JPCfgpcc9Ef2zpqkfkWYxq8
scN2ldNTHLHKT64I6fdj+3wQUzq8cD2mwa7SBBgF2Ql7Ps1cZLhZcL3mNeGFhWK0CQjteOK0w7qY
yTgrpzf2/ArryugVZtzHMY/TKy1YSA0gkuBNUyAjpgwYvGbH6h9n6rOPxwl9TC+B+EjeMdWXCCBP
uxJ8laUoMYHkZrZqVaWSmvfT/+FxdaicQ2nSmQvQAXhfakYj1KZW4Pe0KTaLlis8BotKRCPJdTxh
PFiUAPBJuoKaf3al91GQM8U584N3C+2zWDj+ZJBD1xY39oyf49OdiC2Lf/iCM03GQu+pdoaekhbe
YEKQy780J1g0+8+oOU4ovqhWVt0+Vuj6N4q1zmf9Sgi0M0OHiRkXO2jTlGiFDmN/zqRmbHfd8Oaj
9AexlZtn/+REtOUnhmDMyTDZ1ajsiXPUx+Sf38LSrAPtYOrG5gCJDfilrZJvRE4ph53hXIvxjCk0
Gc0AcBxb1AwmYFkjoKllqmCnlG6tsoYa+8/wHHSBDEsYoYap7632zPogE4DUmMPq9waRZ1Xm8Lj2
nqQBy9pO7QHrZH7X5T5phAzW+gycxKbRZe1Bg/MhpaiGmEdXCfIjOOoENPXUmP6/t9HhyPDcrpV0
DI+hBMgkTai4W098kiVszp3o+jk+InSeDwNlJHmhUQ8353XGEAU7vXdo10l+1FepUiU/kj6BBm==