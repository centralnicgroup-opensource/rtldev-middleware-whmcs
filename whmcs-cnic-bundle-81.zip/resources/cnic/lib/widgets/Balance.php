<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqUbmQ8a83gLCMvKWM+zdnmE35VKoPKYCT5QNkzoyJ9ByBgonkBe69jmz41zbHD20sR9uFL7
SLXINeXyKFBp4AxUrn5StVxZFVOng1gw4qqtvZ3wpdFZXtqF9CG8yCqQ1d2ebdKVzSJsPy9c6eam
ufvTm60ql5rAzoKGKmgpPBz+q6SoGhMObHBlCwF1HxIAwDk3ORsoILDALIPjFdJWToUIS4XZbArb
gYitm1X26KUrrvIYU0q0ifuOBymQ5rvjD1YzQl5vHRoftSJdtLzP32D7gP13PkuKaM8YFiqD3Az9
DWD95l+j3clh5PVywdSJCne1L+7nypZ3qXDuYrvsMYY1EQwOzvxdQUeKPCOLeDaG2jAoTXi2A16t
JBquiGHu5RMZIfYnynoS1wy6PgVx5Gj5P4DvqqnH4ZzfOQRESASoZz8L1EH9Pkif9qKVMdvgsJKM
bJY1TTpgNJ5cPZEhcvVXUzydzUlDjTiFTAQPQGdJdelcm8+bCtAUQCwbKo1+OOmjjjj+0QQfu/Vh
Oj51rswHvJQlCOyfjCVL3kes0mL1DXeqW5TQ0pUjXvjUYwsekHXSWnj5QS0maXvrhCJ/tvs8qN+j
lXH//+YOhEHKPTLGwBkjhMvdyQRbrK9pL9n4vKPZ0fGCNMLzPbQc0tclMkMkpFw/gMy9m9C+eH74
2U44vrk6uSZ+LvJNV2J0set+HSTywgNY1GnqJ/l1vi6on4eFg9v8TGv7s5yDFm9Nknp206SoMont
nXhFu+O1PVYfML6EB8nMSHoL/ZvZOCaWf6xR891zxSOsyJa4ktP72t11pfqVaVXvX09PCcuqD8Jk
CNhi1hEvBNkrrIk11Pw/zgLh2GuPJIpDwYepUk30sW62PlAzTlObFHXMIh22s1ALFnmYVV1My3u2
lKREbGZ2I1VjtSS5SLbaZn3lEVIJAYAW3QoeJyoUUYCW08p30GO8bOCMhZ1v3SO43Bs4Y0DnxDFB
72ncDoXqFGTcebTGoHbUhPY09Cj6cI2I023llCClrlOm3SWaHPzZbQnZLLyJqOh63R67iwZnHoL+
1VlMRTdpOxvL1N+OOXmqRHWt9oHvOlAFpbGuRUkWPmFKAP+NvMYkIchLcdmvDloXLfYoUwjbfy6J
8O9owCC1mc+jCtki2W7nma/m1lni6dhyRVjfqvvHK2Rn6BKfKMTqpkTH80CYmoEK+vFgYQQdbzFI
QW/G5X6NommbkdRjJ4S76ULqDb7ioSFvND8WdbAgEf7V6jOV0xOCdxAw3TZNL+Csi+zH9zKACgYi
PqfCZLZc1lZ9l+Vr8zQooxAdCP/VIl1aBiEBs+X3d+Huun5tM9WHL6A27V/rBfaTsS+7L9+DvcT8
/cz7kK5fCorFTdbzUN9VQFkrRJ/mz+x0p7IEfr5xr+nQw02Wd6yWonKWpJxOYZKQByLFWplKXryd
aas2NYe8cUc8RoIkEmZipFqdmgIZ2pu2Gb6BHn+lRnLV37CJDVZNoXVtblopDlIOGrft9YdKifmp
d+oh/mFkIX+oOaj33L8T42o7vs7OhhxChICzvLeXHrJ0z1wN3eGfiAZ6iq/rLTtRMmIVjgy5JAYZ
ir65BphUtd5TF/0oQipAo1bmlbOtJwp8IcSNDlmAgEovHZSQKb5Tc5oGXogsHZ+qWuD+HeFzCmD8
+VTdlKV1GlQLGGUcSGQLba/+RxOjDOT+mPsrMKNhKDPmJntTYxzjNcNSz83DW4KsTrErQl4BXl4u
d8T5pB3Ai58KIM4BLKsaeUQohTH2tSr527QofmvPfjkvG4sIdy2DtGfODY4otiXNW6EfeNqvh9+4
J0T1avFTvfXSHE95TV96Tts3El6F7mzE9bN9njKne60diZQ7mgbyjMgm9OK2Knb6tlL2V7DFarip
o+IbIhW29yy/riovXowgNl7A0A79RVeApWp0y9I0K4CnENR1YchfCpK/yFyKXISZwLdFoPLGNTER
zA/AIKS9j5iBGUnQCdLccfgNwk+bCvx9rMB1w2NAGHKub2LaS7sRXquZxwTT/qKHubbjVAPynVV7
RegpYQPUL17ZOufpsvf1/RXBJrBMUasCXY5dQq+vP0pb6q/ibVI7eFiaOhRkkVLBVvx7/BDCa2GP
ZymvVBxjWHNLQyW+ykGgCZ39N9E6uoRpdBiOpEt9Btwy7bhRSOXxtTQmUS75gE5yFQzmnH/fJHjp
G6UoU0gj5BBYK8R5PZChHXz0glnMVqSFGrmeJrTsVsWCODEiNxHSv7kdmIRQ5maBkFt+I0RE3Ora
Ws2V71qkxw3Q9pQDJUw6mr6b1wMbweFl6YQECLhtBmvp/bmzCXyN4g2+4GgKdl3eLLeGhOALXCgO
tXJLVH31Oaq7arhWnJkYQ5bkKTE5jXO64zqWeNcRDJS49MqHXrGiZJPtn07kNS1XbvHZiLzila6r
XdmLGfsVuBwUTzuWuBPOJXNr6xxhf+Gr2/wW/3aDrZ/hFgsLwX8++l3VFko+cJFoWhX2aFXvcVqS
dGsQGvVMZuF5LT2DbuEPpH2GuRI+kJuvvnpkM/K/cuWtgJRCz5Ooj59iKFB+79lLyl3KDky/hdIC
C/nFziNMmh/D6lr8qUjo6sQJ3BPHBbehJnLJHgtLpCHpSP31WZf5FTcy2tpWD1tojeE2WlLzPsjz
nsMhOP+FqHYdi/yKkOGBILBZK2rqpPyBtAxkoXtGZg5/oW6tTxHTmhR2zgZYDH2c1lzIUMdwxqn2
p0kbXF263lDzUO/1h0lnAgRfxfKv5ToGCmZklfWxiE4ZjkhALrGiOLB1uMZRO8ja/iiXA37dUSMJ
nIVbsRUSJ7IaaR52PJKK+zq1tkxfltIyEptkVJCX2Rm+XzfabBiV3wcQaGjiHyRh3JBoZMGX5ixJ
nRK8/Ea3aJGkrddU/UNNyQ0zUsIsU3xspRPRhCiqe/dV+etHNpzFlaREFYG9hTE4ht5gyVZ8IikL
0dtIhavsYusv2PJSMv2uTeWLcrtdhf1UVr2fq2zIbtHZdt4Cl1QGEWI6iemMjSrEbduDIM43S7hd
1l1O+xbiiliGDdDsq36gac6pW8vB1FSwzocBx1Jwk73d/drzFYRxvmA4+c1qrR6QXFBvJ+ynwTL/
ekEewxlzaUgf19ro797YNaV5QwkVoQ1jyi1vB8x3H2N0w5zb0ToUdkb69XTM7QVxpYUbtbCuHEGm
z+eqHb6gVU0LJ8/6KN1NQh1IZ494sL4uXMx2GKj0ykFLvUoEUD2ThLzG96icznYToWWrsEJ6OqOU
2Z/5aCpMfHvnx44Tcphl4/pWb+bxR1Q8lJ51pEkaq9zuPkxTnDJUjIUnpCeJwcUHuOpF1DCI4Hf2
rzo79iechL7eQwGprXEPZd1bweph6wf5736l/51u9ZvoSr/rkyYCRlXB5k6JBEQvZfsqyYvCis//
KmHU22sp3YlJiSaL9FRjztmdzF3grFVMHaf6H10S8LQiy51oR2AsH4y1iqIXItT0ee1NDisCJpaq
8gucmbJsU4y8rhoMMGkmouue9tApshuE4sdNoeZnLxLM6KDY2C6cRnTtGWJlSSiCbYfoN1I7YYOD
2G7BfSs9YgQHIlib1pLrjukNGhwuB8Q9q4CNIVnwCHbX6nJkyHpVsLa6wh+xTJxHBrC7S2sq8rys
xkwS+U/SnWH62Uv7HG35Vs2cxWo7KN4ru8Af6jcNqjeHkgXHvZqok+uF4u0ilr4EeLm68nHw9IeD
pKMAyKqBkufsSlaenvAukNjZW1+HIKC9nXorq92GgbWrH8H1HvyhPD56kctzrxN2br30+cfReRWn
OxGrrVwYgJ97Zjn7ejVtiDR1iSS0UIDyzFdi7jsb1pXdZ59JncCK3XAuvtRjMCnRmXXzhJWmUbXh
JULTOKGMsQ8IAzZqDSU0cISqwZZ86afPVQfnoJEMKJPTg+shqOd9KP+pfM3FVbOAWwdSfA24d19w
ofDHTtIbTcKxofC26GlD+oeBMUzmyLX0hXHyJMJ5bFI3imZPdjiBdQW07nB0iOB7T2GWZuenGHRK
HxMphB4e1QwnR7mXTo3aK4Ld2D2FgOrgNrHAeMlSOla00/XwLRck5aNswVM/lYj8fWJYmPKby8w8
eD2YNnDbxzHqi+CM4NAYvLm2FlvQ6YpKl1X2uf0V9uhieOFuW3iFmw8vvIZa91dNISc/2WRFTkRh
og2TvsHU28aO2x5Yh03v9zvFBFTmQKvnkekw7EX37p/GjspZ0abUh5DueBkbOk1hEhwhWLoAmBEf
Aod25FTaMwUcyRCiLlpChgeToacG+muXObkejjt6xMGeLe6mCUPCdvLSwh0D/kSdDOQ0QuGa6J0q
jKBDhTd+SYHUOnngwtZRIB/qb7jeIrhzH9Y0nQAfQ3Y1Lsp7Y1LbhyNbztjPOiPit9ma3U80S1zt
qVghZokUa/W9Jy2yStla60mgZn6WgylGkQcEwaUg6gUtZJTa4QIQy6bbbbHvMDm7FxJikZZ4j9Qt
c6fATKI+lehFCzMg0XgJf+gq+e68PjmR/dLUYLMVpHKSiFj2kBesIjvFB/x65WtYT49HA5uw2puT
ObVE+IQLzsq0ulzcgRER5lfJiTtok5at7bduj6Y9G3+PPz2aRshL7vF0tAQY+U+ZT3u2weVTSPBb
Rru94/jQknHj2dWAH/I/YV67lgrxMifsm4y6fCML/RLHDRajGzTf0iIGmlJcrnL0+gGba9u4DUNf
cCW4bmer2IB2LGJkXrLDuOOKw/h8jt1tzJJmboMePB4vDmR8R5v+evnj3d+VVNewbdqUCJ1BaGkN
PPI1/PLWK6OgVlPv1BvuEzheigDkwlkdcxUuQO6nDr/97HtXnYfF+X2O5ZAtUlZWbmaVRhzS6hD3
CSF1AdN0JaJjxO3BacuXN57d1+XJIJQxq3lQTs6UCyZL5MRT/qaeZHQQp+PzaXhU0FyKu3j9SK99
gtnxqJ2kPj6t/ugM4Gvx1blmg2oWh/qG0d7zLJahy5VQTqjd2pzUMs7P6AfFMBtayilyOvhI/fWt
e5m97GSH3tajHh0IjNtJkx2i+eOOqU2rejfdtTnFGJQc0an1i1Gtm/ME6UV4z4fHHCspJukuvpc6
gizkqye/Wxgl3Dy7