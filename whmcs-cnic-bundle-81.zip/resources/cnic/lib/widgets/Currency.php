<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/CadUvb26R1S9O8pHkVrW1BSA7MCS//WvouhueJxr4AqHX5nyroYZFa0t+/4p7HZ0GUdv17
bhT2sCbHJI+81PHGHXf0/0ZwdIT1nEwA+LB/qu49P7fsk8RW9/ceY32kVmHcG1AGykepN9lxmQ6M
S13CuKlc6duIPhUMWRUbilrcb/SnBftPkqWHQagBkL47s9vQyTa3ftpBxr4inljml26mKFa5lRIQ
EbekEcZbhczj1DAm0x1VsVd6+gFQjLlDH3cuyNb5lAdTnEVTNraC8qUfaELiCAn4zuzPYUBCp4dc
foXvhviLzjrpnRipv648SvhNZ8sm76QN6bvBT/66JaixZlwp89K3TVcy3RvT/WTeveqZR/NnVnkB
y+LpuvkO2Hev4kVJKXeKwmELo7Iks9mq820nlxGPmRQ274LF9VwR49uMsS4zx6HynhG4qGan2Eqi
R0ewHhrKoNrEhcyCfn9d8MsXvSi82spulZTaC43yS0BEHD5y6oMzER582AZ3H4pFfilz2PjAx6LV
OVpcijp8u/2PBXfFJulqKDMYD6l8PX9iTKS6jZ8ulHuSdoKM0KrB7qcyQRuwK1tX6Rxv2dqHKsyw
wlyfbCAuXmHFGKhor5Ntu/aDMTn9wHeV3Vw/KKywLx/daNR/x+03AOWnR6HD3e+gvkawNJiXqRit
hGaCjY7/9Wa6U2B8sOfRI0egAmuRUCBu/mfnwKIrheFORkh15j2WBIAmq8llBwz6u8wyr1CMQdiu
f3jjO71Ab0Z0A0veJy4ZqLfuv9jZ4vV31nezoztCfmO8P69Szlv9rS+7hU0ze8S97pD5I+4BhLKu
ceK76zqPE8PDEBPSsvTULd0/1EtgPMC0yYge4+V9lOQNgnIb8giD6D/YR8BLOZrX+6o0yNvELF7e
0i7vnVlzlmDeVvWwtGkafpVb1nVlKp2StHXPb8rdDJcI0DNV4s6CQRMgcPG4ITUPlIF8biYu3p6R
bdVhv/UQ5tl+KkAtRMdDpTbEn3krcpxHYLp70HrYLHMQl8VtzpvkpAtw4o1zC2Gd7+KEYWra4mHd
sd5mq/ofCvTMlJanL0nmElCtrxW3JZeM4XKKgzDXBsDbwyeZXBPuOC6Uh8WlADjVWGs6fzmOrbMz
MnW1jKmWwqhhX8I3QOgKPCMNS7PT0Yb7jGgFr9HnD+/4Z310YXjrc3k4tK+NHrXnt8X5pAWzY2cm
Tdm5RHF0Bc7WSX04P2k3MtWf0tjuCsc0isS30ztZP+dOVfiYz0T5FL2fNl/UvKz2sEwGdKTvLapw
bcCn9KA02+qnqdCZd+pOrrwoebQwmwGjalrINk+LBpC245RcK/RzZ613/viEfQ9+PvrRMM/uehv6
FzyEqp0Am+YfJcsOPb2zckd32CQ/3nLOqzten9dkxxo+b0qlDbNKeRPXhtAGLu+VLz7S/wyFrQ77
vpJF9tLMAnRRmI3fbdHkt2DukXJsY/X/vpQJaQDFEWnShHU8LWAe45sLqznNPd1Fg18mIZYI00FZ
slIXxrky/uTugjIffnMiTho270WCG2J8Rtv4ZKSHzhCP9+J/UE5duvf55sMMYmdbXsRNLu4XZU0/
HrhWkvwK/RUVz2ZTTfXX8fYlyFE3KOTIyVZPY0dpoVhd6vdtqPNgFJN0nuj1z/iIP7kULRwV0zP0
+iPcNplRWhFT/+vO50QoeEVlSngu77AM6cLXqZEvu9Lu+PBtgIzIIVglDrnNm/Y5Ft9y1n3t8O0c
OI8FcqmOSUNFqNLPARL7jGV91ocGvofVLWDJewprPtoQueDPV/V1U2uBPjcSFLCKRjTaAZrJk2VG
6ilR378pMFCr5PIKACpO6/iaqiclK7bJMT6QUn/dUe0IhFqKJZw/1bPhiqTTwQBhu9aA74nHYIeG
HkNU+BmVfG1OWQ1Cr42I84WO5OcWiQJGKUC9