<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPseXz5K53ysQq9DXTcK9+/k/jtAk6rj6+ekugTPuqg9KEq33nJAlxFKKM6V7QixpJ4J6lthx
qV+zYhcqnPOJpcRvMngRMU8D6herh2xfOAI9ybjFkTakCtPKxenfpp98JyadO98J01EMS1w4XIdx
SrIC9DeFS6q7v3BYKsuxH6N0GsAK9Cxhe4w48GhWcXrEgcwpb+aNFwB++6XaRK3fX1YUZTlRrGOY
XBd7vZYYODyOIXVp2eyG5cpsjQI0wyKoiYfbbcwCESlLqUyOTOILjwAzTf9hbi+RSy60NXVXd7o0
D4WE/qLjMU5YTZU8DWfTd8eCmLFDupgEEOxr/sbMjSdPdtabLG4nw3HEvAfmM1NosGoYmqr1+qVV
LF5l4VqKSKl8s2x0aVRIOzpVhpOgZ5v0CLVwi1UNp8Xt//kzBcR4IuZ0Lx+TIVw+BmXorx949/a8
Px79PdyeDztAwiOad77NQBE/QefWp6FGh+pci9Ar05cm6V5A9jbkAeib6z8fBqZPZHma0L2Go1Ed
swOAGvEj7cmhzXJ9NfFlxysnTdM/VMwkXIoOElGwZ/wpPLY2SgGFyF4Mf1zgnjHnDjgl+NEA5WEH
WZixS5YJW1RFk2KCngWQaxb5wf2mCavJusTdBBzfQb5Z/0IxfuKYEc2Wah+2CS8dezcB0qBB44V/
GXAfFxjA0omUgJrwgowdEAc9Qs18/K0IrCENHSc50dx0/8zw6D1G+LEbq+qGtQRu22OQSu0QhcHo
hQ4qwD5MsgOTGv6mbMcuumeCaGWQcu5GX8wpWfI4fndKstju5J+hX3V71EzQpGISOUBEcagGK2iG
XL/PfXDM0Qt6fCfad8crk9b892DHdYla4OTAEH63j9RHuaFkheDgrXlehzJa188VpQ/eCiUGXiOX
mlV3Dt/SUKwtkS9KM2888kTlpHQQnlh0SJ1U7l4xpAN+oL1BUv49xB+clDFmTsyRrqWbu+SqKnkl
ynWPyZErPXz8y1M/jmFR25QeKSCTBjfiue4ia73+UeOWpZhRlFu8XZ5LjucOX7o7PGPQ9jN8ztjk
3peIMYyBz0tG4yz8yJOnDsb3UohBvJjowHFvLenCSSnrHikImOIv28+AuGSJoHTjfSpDRwYbPZGV
JgGTy4nvNHGnigoB/b8V5sV00TnluaQw1HpunvYGZrkqWnJWr0lXNKwhVDLQu77VJc0j2QFv5b2p
y5gdoJLvrO2SiWucmeTmUjmd3YK/gTpB6MO4VRs3MIYXpo6Q+91ty8pme9MOBGd5s9awgBiGbvMN
QoVWwbaKDRZEsc4LlCCT4IPrZdJY5d1uc2b3gh8Kz6XVUfr2gH5FLTji+YCkiPeWnOJYfYSWgbZQ
l6Anlt8p8MODbh/NR+fIQrbi1eTcsC3c9BWDQsS8CFp2vNpdJXobaRTF0O4o0IlRiwT490JC121w
Jt3Sm2g3t1jnyOcvqPQdeQQPsR9HsAr7pyB2XoENL2cgtudiUN23aSngaBgq+REOZ9lMtgMtMo5O
17ZDsRyHG5PaWMfU+JDbIWyWC5N6cfTCSekJTMhQmxMNlfi8MyF1z9PqJl8M5FiCAVF2KYUSrtiN
NjrJOjtNtGxbiKqtSneaqZrKtGwrZpJEBlPbdNUagEeTQjJe9wtPqU0CtYNWzASYiTZkuJMVMPNe
VsnPeEFzbx6CaWS4XEpOs22sUrs/TP38EeL64ZTDp7V5vaXVL6FOJvFuE6vHz7yBxStTm2a1XMlt
cEFA24mkWtR7nDn7I4U5DnI9tIhrAKMbA+iFRkY/Qm3NaqjXLbfar+bJkSZFMsiwmoAGq0V8rvZL
nBl8S6gOIQtspJPaYeLV/qXHfdWFXBTgq8oNPgE37lbc5yr1/585jIxPpF3+akOOMivQc3byzZ1v
RYzPm4dFbEUivwcs2BvR7MLKcxDrr0PW6J8vW3QllsWe9m==