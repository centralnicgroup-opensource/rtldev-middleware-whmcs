<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn818UvZsfd1UiYqpPjOpTZHIY3sgR0FeDP7sARmEOkD3vTrg+nME5XjhygvQ+yNcGoL3sLZ
SqHjRp4UN9pWH/2Q3LZbgZBNQ5YQeF8noyRHUM+r0FSMT6SLuoKYe1OpG7hC6XcMxDDB9Pan24E1
3jN1GDT+HKTWJVvdlsVYcLLqYzvQGWh5JfbHoaBUIG6i9tbuQeLisOYENarT9XVLAzkS4kRjPWv2
PjwqoX5Qs5GDncuDjzyNlyAC5QEy0HY0xBTLNcdX9MiiqTvUd+QOO4ckO8VwpMSXfsoEVzX09H9v
cV2g9rFWsaCOTaez4ELML1UVfpKaeglZ2NUByXygI2mmm+OCIzwAPmwhC/yabVDFnOTUteXAlmnA
uRHzEkfEhMM03GTObIwkZaVlUtuxZBaHhiWwS5EDjI6cbc3/aDQ+Oai/SXimxF6/Q8ugDTun64n7
qDdRWN7b6gyruBVC3maXW6Bf+BftB5e14OBDdWY+xTIdeKm4OOJo+iKeox6RqjCPvlLs0eLxhoZ6
9EzEWA49sGRMLxypsaql6fFVMEBK5Qe8Rotm8Qv3kXuA3vrRO0bXR9ACjYlMlgmWEOPDBSfwVIaa
vLsJhnmT7sUfGVt2ZzvbkKGKOlb4TIrKY0NF6tvicswBm1cS3ap//wlaTs2GXMIa3gZfO+6YhqXM
wk4IKfBoWT6kBqfaH6EME16gdJzQrB83r3Kgtd+40Lil51DTDg6U6zkdHVWqQoa0EvF7l+lf48Sr
s2+cDkZS+NLDiS3uR08jRLTyVlvZcMXL8Nk9fZQpo8sXir4tBssiUislTFHnsEZTgniMHJk3CJI4
yHk06buaieaJFy3+8m9P9s5daqnBDG5GpFl2oQUjz2/SsOTuanJAN1Xh46ClqSp0rGirruj7HDB+
EwiRW8OGzc86jd744bh/uhCeN7xZiKiJELaK+pbjN0LQaO5eujax+QBZENBR48XhA1S9x9AyVz8n
s8F87oIhm0525nG+9Dn0+6fhI/J7zYeBJDx5VSVCE9V/ObOKoARAq8nRbBhtcm62dDujkMtTSSZz
NTTE15JP9gmkkfFyfjVLZz0PMtqmn8emXrP6HlP71IgVDaI7bZx2tLW0pDi1SvSoJQjgTG7yAo+f
gOlkPPBluuAI76wJEgOdxBmZqsbCO6eYgj+LRWT+AiGqjeugX6P+GIkOpBV7CglB4YScHwDGfp7y
NRxmCFe9oJLLQo0bhLCxwz6aIn3Tag8w4PeQEIrFTJu3XbX4MjOzZ7LoFcUqJ2lt743IlAkGiXG9
RyYTOHgvB9pqKmkUsotvScKsnXS9c9E7JnYX0p2HkMvnNEljOO5neQ6p7euUav1uPxibWhoEGqmH
LAWMThfmiWmH0//OX0TFoE87G5PP6SQnfJJRf+nw6aNJIAqZxsD0Jdfwfgp8KVo3ywmUSIZlDEl1
B1n2sHjDxza6aCjo6BkPkcbhw7p1R7AHFmsWyzEhP/5eiC5sM8BbdFuziMsZN+QuCTYYqfITKVJY
PVwV/Bg1w5mKsW+55b1yYwl3uKDipluJv+4BmH2HW24+0fgwxtJce7ZXSgqwQr8QeTovznez5R76
gaw4oozevTGOFZZIRtolePCTEXXkNM6fLQ2slhoE/hxQa1zvg6+D4n9xAvLzqE+2VS/nFt8nAM2l
ImkrWCLAh1MqueORw/3AgPIX5/9grgXFpKF/saWSuPXea2NwfsaZBxflk1mgGeMRPPVHkQKMOVCz
x8zI1wLHwWLjiXEzCUPorTAlcbsxLdGjeeiACK6+O83D285VIOozT9TjzdIsnGodwpd8GKF/b9wr
MZVY4hbmdByczlKrbdzvz0uR1htBCG5ogG08sJzcaqwUSSFE7H3M4w6KnlObGuLNYC2g8MOoRVy2
7lOOLuKclI9+2g97sXAQCjJbLEXMubCCQKpZI3g3xh8kmXEwqM/5CiMjLELCk3L+laDeseHfQ/C6
Vcd7pjbx4jtb5e+6IdBriFrkm082U0tXe1wadXVlVXC2hunys8v68nAKz8jUy7bexNAiI0T0UV/1
5vaJdYV9H/oMqx4KadmYtk0Og4MJwtCEZWjIa+I9o9avXEIjkZUA7ZUvMbAEp7MLHSFRK9b1HK6L
KHjpK3uvqOFztF4VXLTnjXIWl4/YHNalASkKMKrODa7GZIxdR2NlfufdZud7OoPF429WvVtm1l3+
fQf+8nevreJUUrDOqY1hp/jgVmBvJMLr397HVwwx1E4bc05nYwo4bgo8tEjZdYLskQpd/4Xqy/yA
WaCY2MxHTlL70YruP1Ow2WnNBt9tkKyZ09jsP4rQoVEIjvNCrJg1k72Dt8gEmkUchTFbQi4a8mV1
f1g0Pq+6V+9Db95CZ7ZhC8JN4Wnyz0XRggjA/osgU0wxDtxNLUwvfqDN0f4p/HO67zmeyJwy7+ih
M4sZWQPO5dp6wjRWUnKNTVcgKcnZQoKbHPQbk2Cqen1xJrB+N7u/bpEufJlN+bxVngaShfdVAd/x
fNXQ6ev8AaOu5wk2Bv6eQZRHBQtpPbwbrcLC3Mqmh+6rA+er306gqgrA60jAOqS6K4emkKKXbHON
FV4OlACiqjF7DqPzlt+eQXHsUzaemeXDRNnHNB/Ftw4CELoIqrWcqayUHhhOYHDA+QSp5Hv2JB9W
6h7ka3BlFfohAe/SQprEqrzDyYhW/DpFT6DnqxFJjEzXj3xId27iNGs2SVL4pFdJ+t3jYCy8jJZ/
fLSo1uyvyrYRFV6bI9209EAxVuKPreVYvz6KBSRY98kgXQbK7KUpHQAWk7aduCEFK+8bl9Cckenm
eJYloxKceO22GqtZ4YWTW1KwdTsYLgRTrzQ1e5Qq7+UcnyirccnWy1DuVTB49PbwAQvPyi3QB+SU
CRXjkAe87iAl2hi15yOpiTp/rPp7IkWD5H3+6QMU6mNoI7iGV8sYxFH/WE2acnyfzbEuvVaSg/2F
cSCZVh9m17ncVDF2mXrWrte5gaeX15ML9TQ44mhGpJ5IALhLH0OnLGHa76P7i/ArqHn/Pc+vCoYU
7GX9TgTIHuz1YskDrr8d+lWsM0XZOiAFstlV2F+L3A/MSRj7tEfHTFV64Etmddkwc34eukeMS1Vi
10E/eZNfdZNpUWqcBrZRVpsuoeLRmkpANuc/nWjCejdRARRLm2NVN9Pk51LE+/J6Pf1qWbTg6XPl
ZReWRq6O7tQaW/vcximI4+hfYeDSwLLfHw/sUoDu6qIF63KP8zl8GohnKPGt6DEv+Mfio1MiRdFj
0Z6KzmdHJfAo6/b/zqRQ+I7OKsH10ipWEn6HGore4TTFm/bEpELwqA1Qey2C+zS51+IxaHxBBDIH
YJTg1zsrpC689NuG+9NhPckEamvN7VVtgK3KVRHtrznuVDtXijs40f7Kt5n3cxgNQ2VUM2lDrxeq
/sFYDq4+MJiL0XkrCwXmnMOZ1ksFSHx6iVIQywN9pIMlaO1zZrLNztrFdJ4uDA4OJCmW3chCaTiG
b5/Scp0GJNB3v+M1cWreDw1Z6xYFFqVogMhj/FSEnMi/ctTbze2zMnaMLOj4arIeOoqZvZ+qVtOD
z2XqS01EILtxvQTCYSOo2NCOCbTgUFuoEBoTOM41/pljOjUNH2EKirm3NXn5/ZwnGlLkY+QIZ+R/
uhd4KuhWx298Pz/V2cvGCGXxOQePuyuSRAyLgDHLac1odNnukKKfI7wZD8nk0qSni8bt0zx7+t+9
9yjA+Qu/j5zp1z81doKEwqX+X+bLRWZEpk2ZpZx/wuq/Td0vP1bB/SdLi0AoXESbZFkp5kU0fhJ2
tiFerJlFvNynoRdgn/y/TUvOshNh9qn2Qnpg6x4kmqMXKz2iQkhQsxRX96coC7jwUUz1+YWK1fUe
NVUaM/DIPky8xUvloBVxC/CaeYfPJ+YJSipWVjj+UZQFuMjMwnjmcLVXHAg2lWRukrm1QDBVBzbC
VYvjpoxQE8fA7xStqYhCzWH+UqHEWvXa2LmXYsigavWM1h9NZc1v9TK14sj2Eye8G9PtqR28DQCV
wxAvPuA3XpJRPrcKwoOHoOKwA5k6QO70KyIHXJuvXFTb7LA7lzenuF3myajYPWmiKQEhqJ72l7z3
SE+hNaH+sH52mynDpSXs2aQRai9PjoYn/+Fs2gMBWMUhLi9gP5vJzjdJS6Cm/EpsLUfnMlIcNIDF
i430/BehK5S6hrGYO19S3jnDuf+y+oTwsXM3mIfCeXYXrpS9iqIzZT2xJOb7gWYFm//nCZysAZ3d
9Qv/BEq8rWt8ZG/kuMQiOJjWUZ40L0fh7BVDHmDrnN7ulCiDIU/dbeUPZ8PGfc/9bAKbl3HOwGrZ
Gi0OE2EhBDWh53PjVuD49JXo+SXdGFQ9eXc60mKawXTlhEFwB/C/L21xnHJV3/Xjhob40K2TthVl
foTNEVB2MUmOjUhMjP0S5WLeYxorjBlW+yty