<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtInGQcU5RgEPtZKYgQ6XCv+0MjRQfFtrlgZDorKUTCEsHsYgwVtZh0ucgI+J4FTEN0wtRcz
X6UdVPgSVlo10zTdXD6UeA/tq1C3NoKumcn5R02U8+WYAKgHwp/bHk/CoMXShx+Qt91qsffWyZW3
sl2qVwW8klBXWr8klb8kVAeRqOZWdAjtWLcA+LYZFsg8S7wSpTANImcFL1SnSuqVy/SDKGRfNqMR
jBrHbvPmsyieSE/5YPKrNfjUTlnfROeKXIDYu2V2MYo+k+bf68TSJ+ElcG+oRHqjUl2Ixa9ly8zb
LkG8GeOqUDyB7H7oX5Sfy01oRfgkmhQ1oLUoz88mjH4lbGeftP3Sxp5vI1zKLvFMgh0DlUoGm1Vb
PdfDVoVgG5NDWd/fE+h3uyp0Cnb4pu00PhlBPmetISEqfxtI6PnexISa5D1Mdj8NHz06a1qRGyGj
oeVvaeSTrbcaf8I6akK3soMi3jLJhr7cOuABHdZKfn33ydEbenYit2XHNy2czpjltpTkoHbPYIiw
YMNlypTOrIRqsCTet2XR/A+VGctAkWA7pmWA7nzo97TRuM751iltihI7BYHe78qmlV2F+KqAvll3
6IUKtUPtd2IJIskvciT0lkLB/DZtqZAdrhkwke9CkV9PQq1t/pRFkr5WsmPcHKwWsSRPPF5PPzrb
ZyqncNu8PvNf9L9bqWlUv28kam7wmiZxepkUUIGvyp6yh7s8DVUwABLeXlhyDoI6VaC58lsHq/wK
+3AFvIlgs0vMftNewnUrZlt9PXvHWmI0q83Szx+QfM+8PsciWy+FfvFs4Kemc9Q4ENCsneTuVfRK
mQfUZ6/DuWlilEGb2o20TRPNN4wYPrAsrHkxJO/t7BW6ATxySf/jpcbG2IHjQE5B7mZBn7jTcpHL
VbGc0S+5s5qFUrw4jMDA944wpHRYPgTHV0uYjnHEgmQA/TP86RrKntsqa4wh5K8n7a9unlSAoMYl
W+elNmJmgL3/Iytb2F8zjflWrzcDJtL/BiR25UesjiV3MPao48sU82xBJpM7wehI5tGE/iEaHoze
rvDq2sTmFSixjYT9bhFxO97JFYLIc26le0DIjOheJjGNm3ZcVH3Kd54Xpk3tLccBIVQDDLThqPOn
uF4iJgoCXs6kjZIywBh0je75+OHF07BGIQhAh7sb1MDS7byE7hfZA6kP3Qwj6ekwyHaRl8eWRJvR
wlCHrw4TbFiJdC3xdYDrUVfA62gExDmvp87MufIT2/Od3WWLgHww4gN0kgZGT2ZSC9USQCnhFXXC
Tbb7CcEyCgkTfDINR/8SFcoJXf7R0tpxTjmzdEPz0nBJYrGgGLVaQlR7n/wILizw0qGbtyQ/rIyV
8iRA3yY9x2T0s8yHaV7bHTDe7Xt9rBb6wrSIyIb2SNGSzzyjXvn5jjkWSY5Bri07zxTiuyu3zT+d
MBVZDg5kDZ1/iBU1hGodT+mWndZoBEYv/1zyyCsmlmuXMFXqhYP/VE0o6wQE9FXwb9a3Fot20W/Y
bdd2pKV9r3wNxLpGw/MSa9Yl4MqrzjCqV7vqryULILlrUYEZ9vTmBEn75ZiVma9XGYqMjehZvqDa
nPrZ+wf63/KRvCrAtSAwAn4dAaEqa68cOW5qkddApxZ6LHV75FnsSY9WGuJFC6dKcBgXZx+TxKeU
qqBCzgYKXu3Rh841209ua2igWCMiWUv3zi1ct7buf0R2Qf29Va6A8PuPnkkWZE6cnZ0JOZAEC740
O45iA5/U3VfvsQcqY6+EYoIqd0M8YB07VZs9bhbpr99JCFVeBe8Aitsbw22gt2+Bqjs77soGsLOO
CtPiCaCxsdnVyAExrNNY3h/gPJEdKfNKLV2WY4snVfOH4aAMeIyWJ+4bCR4pOJ2DsaDV3zlN2Shd
W5uRomI0L5rCj52b3OCD8Iv3CYGdixD1y6+3Eom+iC6iQq6Sy8j+urZYqSbXDgN1nVT2+RQhllOk
xJIfq3afTeuIJWGJf1iPsCZTMTCmVuh2E5sYcFgpnuinCcbn2mQsHn5366+EEfmFXGeJJACk6O23
vgag4ctejTpt7rU9UqE3ijXw0gliKmkqHcs9RiJmZg9F7GkAiyavf3YaGsPeNpzPSav5T5FRrhbd
uGqPxjk5X0pnocFxeyDWJrfEBp5SSs8QZjuTqdlW/QjSJ1be9qPWDVk1OdiNPdj8uIe3bRaftIzG
vql2Sumve6inXxIIcpDMAOzj0d1LiDJoX2O2uH0Ix2zmALbgqkf19Vk8CXUS4h7Lg5plvQIQ+nry
6eAzEvRVFOHz10LMC++B5DMVLK4cSl6ruavDK/hQRtDG6e7SojM7elZuT775EtHbdHbxPeaX1Lj7
YVgabz4cSPqJuQLBVa+iQPjiS1uBnHf0Y45ViN1iqWCvXTm5MU9csj+QAFsJOCovQgoGParJwthd
d3iuElrtvcEKGUd7id+Pb00ZhKtUjXVA8IJUckuNTJwdxgkEsXnEcxhJQ2IZnh5ueoTrHtUZwmNj
hLPBVc+4HTE/X9yFqllyLO8q+QHrx1QDPqgCabZki9mrwhtDILUAfou5bVQyqbIw14Qyi5Vv7HAI
5hMBOVFFy0riAuCDyDaQf88D4Y2sPTeDuLH1iBMZXopbp/yi5Glz5R7HseDvw1Ng82PfGhBlXZNj
CnZAx8fKM0sl9WsDFXUN7PkHt+z5zTInyxM0mP3UheSr23iHiZGV53UHnh2prc7SjoppPfz1+zlW
FIijA+/QJhc1WgBOe6iAYY4gnKmJ3AxSWNEF0xpnbNB+2iqbXPw3CwxXPXLvP/NRfayHoOz+VKkG
U6Zg1Z42EQi73pPFJYLq8VK3AzY13FaLJaDfkjFjgTkNICrRkHed3+o3LMg1cRNslc8mfY19Tmzs
OHmwr4M6hQ7u0UttWqHmJ9HjW85IHdOGhHPPVzIq8p5vwP0ASijQbY2eR2LuMGWzursnmWjiL60H
SaU9A0ec7wEXlv/SEbeZDI84V0iaQKX4w0RTKViGUXb6VP+P07TMClZ0HsEOZlZ1D39QIqEMEuBi
9R/L+03bwV8bdNNYxcTmCFQP4HRdWI820oJdBdO5D3sjWf2MppyxT7R3Q9lBDDvV7KFQ+IZ667CB
I4FTOd8aDJGMZKPIEqQJuT2BA/kpuewrbWNXzRy/T7sBE7vay8ti4Zyd0Sg7Dn+gIjv7orjA53z4
IeM8CabvgRudQhKwZp4cj/GvKWhaHOERHx1AOiw6+DwV8U7hlD1nGkeZkdk0qxm8U9YdShDQQMrI
0oJrMgLEX8hfnanN+EFA5QPzxh4Wq5i31br6dxAYkZfxgay3u7uZufkP9dxGnac+Jidp0DwCY+Vb
cEPS5Std7WSBH8MA8kqDS6vW0TYU3aH1xOzBpIiTnhfWCUDFhgAVXvGs7A/e5LgVFbi7uzVz5bjx
h9kAK0aKa5rciCRbezWc/rl5MGxcwAzlSMB87zbsqgFCq8EpyAFEubNXix4x0kaquvo9qEdbOMfX
7+K+6G33/b6f6adjOYTFy47hbvQBARMYkchb7NTluO6XJoE8pOLnKb3Td5ov91WWfhGUm5aJLffE
r/X6LnT3LsIQybu26fVljK0Huy40shm8rB3cTnmt+73SJIbD5/ZzyDCAUnbTPNyKckEqkv31Xn5L
BvDwics1nKHf887GvTa2jLn6ZK/GPQlqa1dW1nCULk0TMc0dJhIrELBE+d0aw88a4dHj2pDOcyEY
XNQ7mdRULaZiaQiX/rOI2YZmrdBKigskPP6vQkNeRS1hmEMP0QljErDnRpUq99C3pqSeRPhLdguh
wcxBm9F2oAJYiqGjE7IGgSIx/OclNcGxq58qY7rK70NpK9tBU/+Vcl1wB174hd/Oera+2wWH8K1M
nw+b9NPDVLkgzGfcJCRVHyjX2PnIcAciR7rwBfKMWNt24LuqkX5c9/ZNtoo5Rs6OcxNe0o4f2MQv
b9YiYiGK/kXZz7LehyWsUpX+rKiS/w2QT5ralucjRM93Lr6yGFlTGb889Uzjo0CIx51YbroCbrqz
IE5hRGpFHLX2yhIhbWKcxTaGXQcJJLlb5VLA4vChWF2s+CIXRBrmccEI5Gb0e84fUVDaTMWBGBnr
tN7elhCi6n9K4QGhH5dqh9qB2m7VJsYnE4xZbPzC5TfmRhREBeMW0hOItC7GeW8g+BRBGLa9aCPe
eN+H5z3TL3kXL/UBwxHBjjVU/zR1J9AdsActq2X8pjbfr5Osk1dox3RZiEru+v6n7hI5TeM35FeZ
STo4zBGs9jhW+2wSu8z26OvRt+EBTnTjEKyjA0wsaIRdFSdyGLMj18xxY23K1LtvRute6gq1WMm3
M8D9P33zCoX4TwZ4zx1gsBwzlwK+UynvHYlMEd2erSbCTrWNWKuRQQMzsOrhuONuCZEKZo2Qg5W6
COwgamNiXlR5uC9xWRfd1ESR0k7rPToEdBQ0aZDA4dNivGHEQoChAbHycHu6i5KCig0=