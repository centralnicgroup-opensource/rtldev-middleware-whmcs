<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPngzZRooAtQpItOOdu0sbw8UVGuC0j351CqlVgQXv08Afzu98BMqKWQyxhGbyQmFNd2S6voj
1ErU0W8nS3JMC5BTChnX0EUDhkFn8Rjqod4DhkHroOVyft0UYbrYf94gstFpU9okvu8KHwDsKOzc
035KAv5RvUpu53bVzdsI59TtULIVyo/qtJ1vfPocgQDFEC3sql+1Akl6Q62tpmn5dPLsrBkFK7P2
SN6WEMA11CiCbmXy3Zls7oKd5KKo7hJhaD1wO17X9MiiqTvUd+QOO4ckO8VwjcQM6XyvKNK4T75J
cU2xw5vLMINP+YOzgSmkhvnzWGWVIHiFp35Q9aL8ClJFbRMygEhAdeBA9H5e2mDhAItWQiTCahTU
/VZOYJconfm2oxqABCz+IRBrig76mHTtmyNCdy3k8O8pW9wAMci48NkSKDeY4gjICy6SgxDDtJiY
CmszjsXfVXACsR7bwylD07qAoh80OIuMTxlADwWver4ZhNr4CUpraZ0NdZVgaOz0k7s6c6evAlQD
VafOyzidWGwY5Hq+Oyi5VLeB8CZVr9tpoTWGOeUDQ9hkB3qXzdLzDr9nHifGmw+TBGFGJk6km63j
N+LQM7szWq8bbU0/+T8gypO2AjaQa1nO7O22P+8TZ4zcl5SA0CU7SUiHtEHTDQSu9IaihhUhNh73
3yFa1dl5ztWI4REhRKFVjG7WrXmOEEK/r2vV01lJ2dK7x7mbGiL1eUNjng+piv4pAtx/gDu1huZp
OKSPJz0cSy8OLvqVEq8EeOXMmnP1IwVhehx46wSdU+7k08uLLtt2KFwtKAFqKPES6rfi+ugX/Yj0
IsJDmWm2Sfzw/Id0e7uHBegiwqzUYelkGoKaVlVej5MnvuWK/axCiS3cWC1nOpP0fSKtBFojTXFQ
DM1sKrsAccsTTZ6ZqQHBh5tZWXzj9R1V7+xVZogeNXDjctX5YXMngHi0iAz0/bmqaN0b4pv7Qv44
gSUGoApRwUEV/hOc//OnCmWgk1KNljmG3it8hZZVaxNXQKPMACHVfrIr/iUiaBj3AxipNPtIY/h/
CCIlcn484OSwNP5FJhEi8rDdxJJiPBqCIIgp8S1uvQM/gNuewQgY2pFxGhl6I21VS77aBboPu4Ww
jQ4ZLBxGkhClrQAFlH8sbIsBXjUMSuzg8AZJNoPOUZNCW2wl4fnScmv9MbF7hEr9Z/RZBl15GfgQ
2vH2/LTrnqiWCLKBoVy89uy1TSHSAnQMiUq8TSrJ1QNCKW2FUaRxffT2WMVeEZBb8H9PQRcS99pJ
F+bKOY4aydPC6og2wRTH+nH7xXAaFuuCDnSqHwA2HJ7vU4UltzipxYmwsnhvEnAhWmZ/HlRbqlEv
ywbj1aJoC0GXzyBTecAOryWpeRmCWyT+uGwM0PhFTnH6H9yefg/XLv3eXUr679zU/hUDb8pbEUq4
LjoOV/4MQwyuk6HJOHZ3EoJMcpQWQMaK7J0/Hh7Foc8fM1gBmnnQqOK1EO+TgTzA7nz8ysDLbYs9
WCgXLeTvwUe368hO7/kEaTgxqKTtsytnyFDVnaJGzE+H+BP5Y7tZ72JichXHnhrcUB/H7yo1PcMi
Cp+Bv0glI19I1xleMfVRkuPsgsEm5nP4YCrcBxZRC1vi37etPVQSyAb3G8Mw6SQHDBhMNFXLzz2y
rcI6xNBYUlOY6fsIRkT0y0LmxsZEIz71JfdGVfhS1lSJ7LIcztOgOacHM1NyQJAqUTpSGeAF4Qrf
nCEY4b8UkqXcvZRkKjJ8wQQ1ipMQzxbgjqb4bPP2xo50yjr6kgOW3FVf2XVzRWD+dffbLB6oH3i8
R08t7VXDYmhlN6yXCknpYfdpMjJo8LJfJQm438r9p15DlAqtmvIATYao0ok/a/5ut0e/laXPc+PV
OOPM3vT+zb64HZ9iWdN/vtoXitjfN7uuSG84axQ/isgRHx2u+tznn6m9+MpBQt6ayP2mrSex21Jt
e4mgs8j8DIrGCn27RjgHYORR5LyFlKjLy1aDbPAN9hSQN6oJ9v6dFhjgUV+KbxPjhKJGStTm8A19
nFvn8D1K3V+VRh0hrEjiKxsKnjRl6SHeZsBMhiILa2XitaFP82P2DP39SUNt/Z0YRIyiCls3BX5J
GQjsh/l8YEDbR6IlXhJD0mZrmeWVMMzluRi7JjtOInu1fT0Zj/JEGt3mvBdDwx5W6xzY2kgAP82e
+VV3mJbdUz54mYX7Zn7TJlHHln0DiBYU/5+IWA2WCF6lIueCwCg+hKR4ApxuEjfjOfk5+liiYxxH
9wzILsCS+PQh+jRDsKqRo/iS29NRYLn7DIkpgHVOXZzHUKQJ4KsSFQfX2mDYdATBzmjHfX6ZoL1j
esnWzxN6te1tdLeOd6CjwyAwzQzhdMrafpra1HFQfjdxNe1Zvke1BU+u1B28Iz0Dz/WzkpT5nQlF
SvDrU388r41Q4obm8iVAdRk2++mim1ug9FY2drfYQShjL9pCk6Xohp63rMM2N14Em6gdfob8NqBu
894mhrz1gQAA4fzVwkLwkOdeDcvwSlr2N3P9R2fe2sIgBwTaDUUdWAloofSujOvvr57AIfyt3t2I
TPm3WD4ohAxZGdyWXd3U/1m4YTil8ygNEzFF3rBVg/doh/ezeG7sO1zGQLn8KbkJ72VtamumZobh
WkK/PE8I9KvaIISba+qxiOrbSLEJ+64afFSiZcMqs//mhnCIewcwHHEAvQejaA095bO4Ijrcpyxl
fw/L5qpinn6H+xkIcsDFOac6mNaF8wIOmo+Re02qMlaWDglYrb7dA5toJPt5XVZ/Dgd9rB2VrjCo
GbPBeCA0WauXVauREM2k5MFqxhsj/kpfbqemft26uW1gpHlA1L71nAWm1Vx9xuDXgKLWDQicbuGv
kNygznGenu7yUoG5Ep7dgs3rvhCc2wnrJkKvVCOexnWliO7epccEzxhPmIy5Z8Wtu6MvjKZNct9c
V01xPuH+3vgaHdyRIrVLeudJGMRIBg5WUeULEv4iB+0d522zucsb9ADn/RwQOtZmhamKWBZNLHXu
96PWV+v/fo5T4Vep4XOYKPZfT9/k+LzLa7n12hgPBbIMQZL6edTY/+UVgE8Ut8erGKHNp7+XkuGo
1tqCRlKA6+MGXCQtD//VmzKA/h9gb33vZdn96DIxdFZoRJf88dndRh3N4S3cYdt7yiGhlogosv7U
iXLIfZsntvpX/GAM6roWtlhV6hv4l0dYw4fPN9VLyb+Ct9lXtxvXZBbH75D07eeUK9fiCnjqCRlt
MgnwAi0XyBrj9nmslL287AHi8P2j8lnet7+XZSW16UceqnllnCBUnz0QXUsnjdKV3TydmGfbLrCB
D0DKchfEQupbxE5lmirCnP2QtzrWucFc0WZv69Fy+R5IuYcPHP3yUGrdLJ5zGh1eMLvSUFIUj3ND
ClFNHkxJlpehMdh/raGPpNfP42GrZ4ix8vQzaFRsulNlwTrfrczUvG0pPyj3p8kA5xN9sEA6whLb
caDGWOXbYgMG619RZ3K9ieRq5dJGFqazGwIb7zRONCNJUW7DVwrHGv9xHxBca+O7bHNqJynk5WhL
dg2m1TAHgN8hdYbu6SUbW38nkv/dWF/3TiF3vDLEp+WbK9n01TCHrONKB5MuCw+8GyEe4D1gWb4A
+3U+ulUurrDzRc8F0yfW90n92CYQipudALMW8qdKJ1/tNVLA12H5RdbXmLZ3QwenxZ1hXHtz1X+y
jpYgkKiXVcMCLoDvEp3Yllg4CWE9/Py0juMi2ooNtHAuB9pwiT/h8F/yZyM71xTVRk3UFWGpC2I3
QRZT30HwGEJpCcbSzGBI35d4Xm4zBzUCH9pOz3VGC295PPS+muVv7o3Ry+GJXIyzffdI/iqk2f6r
kFxV256/g+Y4evsFfvzeHygyf25jKHDo9Iu64OBoQwxxVL6pK/V1tQ9YfE55WRaO/I5s01wVK/EO
vQTecIAnnR9WBegEiNOaLrpRsHv0ZTljtwnNxkVbKQCWmk9wOac5hVNhqpiVhw6HAIoKz6H8Wa13
ZHsWQxKDusyS5tsXQ2hS8SSHagXzRRv6qdRaPL4uoriGzlDDG3Ig/AthBTRf647IjIEq94i2Pk++
b1uJvrUlz+AIEZbQ/u41TkoWG+56DOKiBVFcFzgqCS3OWNjhQCrJK6oxP8F3r+R7ihifqcqoUj0x
R32gmwDCZqNlmhrDc1uJnDUYIKec2a4OKVFNmj0ZzNp424g3/84Ltpc1eyOnIcw4FPcGbXyxGMWJ
PEjchCQTzB1vi9GP+kA7J0bZMaLmjUbeQwpPV7xxnT0Q/4Myup7oWzDWP5hV2opITFV7D1j4tY4X
Eli4pbfufjaj5PsqCl2xrFb9T63Dat0CmHh9QMACwIBqvP6Aj6mKX3uZB1JNXn8Sy+QRCJkabFes
guZo+6l3GBANqDzRu66uLSQgWRp4996Irgho/PBs3B3uHPstW4SIudt/+h9hDMVbgUGnpHtHTmAU
ot98rj4WVbLtWjUVz7bt6oI4q9Ur5lZKu+hEMio3PliTQWajTRc5Fj4wMJis/rXCWBEA+KIv68D4
/SpMkpqR3Yik5fHWn08LbOZyljPwYdPHBaGerCr9GJVndyB9/1qvAPAU+D17C3Ujq80gzDX89Vt2
5LAu05jIckSmPazN/PgGcNJftUUJVYkL429BYvDddK3ynmCeEcMCAIkPozpxNCXIjUZcnD7jrUf1
q3WLqnW1Ys03ovk4akEoyV21nMnl1jpC3s4H2Liu3yHrhpWNcJVUEVxR+9Akv8i64huMq7BczSif
RK4bOR8i/gBTh0TfQvjnSv34uLLNi/qv37NcYtc1fyfRvWm90KyNWwvhMGUwu8nNw07a0x5U01bs
PnqPp6RWlQoyZFTK+chzEHq2froLt9Zmgoj49R3wvjwyjMcUV+zQniiKr8pCeBZE4PUSrA+Zmefp
ewDiWroQ7Hrz9s2CKYYJp14iEdLsDZOL88lpU20QpQ+AAjUb1rXkrfjx++wcQEzHGqYJKHh3oekx
B2N5djBzD8eRe6KFwUwy1tI1Xeszb6x7nsauQHESVaMdSRiF/eYIibe93va=