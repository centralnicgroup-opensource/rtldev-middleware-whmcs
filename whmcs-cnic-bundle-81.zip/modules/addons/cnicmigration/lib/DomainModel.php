<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpiO6GzNo+4WBjUCBC1YhoVuXb1bIV1H5w2urq3QZZAh+T2y+jbam5oDNGIagB33qyMqHxug
GjXVm2FF3OfKLfe3L2NE+HKe+7kvkk0j+w1yGg9s6aZh3Mh8I+Do5UZl+UKGSfJ3MgTmbA8OQY5e
PuZ41jSP39IPlQoGrCp4r5AYgmC2ijgCTBP/vq55ZyROU/WDd6pzCUboYGwWYFt6K+/VAcRlGTYq
G0CZihVi7YfxX/ZeaylB7VNCnYzfmpeNqHw89y9QBBwxwMaOXrnFuw+P3/njXDvRc9/lqYOWDvLM
FwTV/xjk8AOFAfpIEkXs7dno/5bDXKYu+l5+4/js0l25jhOhvfJ6rkLC2dVCWhvizBO8p9tMsnSg
mYl7YWKX0WUH+j4VdiltluDSY7/BaqyG8BgILhJ161qk27gHlyJE8Od7lXqkUjgTrg5+FQp6wbcK
O4SHmwiQQJAnFnm/BqTGuZEsp2Kb4rJGUiLohwR5pAWAW43haEiTv5ywhr7WqJJjS0sZ7wlP/T6e
DzR+K/MSzGPK1NqgQidVQKHkUb9Vj98pXV+I/sv4Y3EOCOLwdLbmh3qmo3lGEtx+Q5bUrhGT9B7o
zNQiIZPb/TxP7cgxv6o13XEA0qLjbOnlOxW7I6PxlZ7/Zwa0PzTRdsytYpTxQ06JZxY82MkmqgfU
Z3THxpECja2C+jgEXCIHH7/077TvKe3TeyM4QBUhxg69HjLsVufE9g0dKlckbLQ9UzKSCz8ncAPZ
VubeZov6WHfc4+0/t0BQ7suTf3cFwsAmGWpDFQpFcKtan9dMLHkI5w3q6mpEXwGAAUHE23UoGmKu
S1fUqowmEXqi2mJbHPRNmGyt4+Q1P3QgToQKKe4zEK4Uhry4am+Nuef9yS3pWtorPufBuoQnzq1x
elz+e9XbCHORLk0nqP35AVGk/qIshxC5EAsm9i5Q9Ga4NfReqAEHt9ahhXJp8pNTjwyBx9I/3OdQ
wXO82EAuQAkcEbuUjEla28BMQaXzIZSKUeyQQ3uFSny3DJRxCHjvq5QrCfuaMSdZyEWKENd4Kh+f
0GgjX2S8C6zPGTkJ515OuYtQHPU5Z735kuXAmTYVxtOYUJK1GzqqJElxiswXzj79iVAwkoVMcIZG
QJW+toqH26dqD1LZDLyjJ7Ixjz7Ap9xqKUiocuDWjj+VvmUmH/ZWRCnVwDW/RKYXElhmbC9t2iwW
H81qTz+kd7YPYBjPJOl10XfluXJac83kVSvGzN4vYgB0BqFvrSJxSLBRD12abXHhDLCmYk8IVuqP
l2BTY78W7C7dYeF4z+BQhBzSSkY8zjKR5OJMcPlY4UY0iknPjKid03sKoQ+QI7TqRjdERsP8O6BK
3KYvNqggSPujYg0bIbUldAUDlbi71WiNWDO+bMIxm7GGoZNWQRrlPCzFeMVvdQs3LI/w5PWYi48F
CqyJOjEUDEHBmAx4zTooqOvuJqB7wTfolI3eN+rxiSSxoGjm+LC0C7KtNIVWJ+PqxtqrGErkhoq/
RENJbulptlPmGn+fTUjPUiCzLqxTwRtsgm3DNsVr4QyH6D6GPktcGUopftkE5QwPSr1969f1qow4
0D00V+k0wURllkaT9VCCvg1P+iQcEfSZ7NwFK8+cx/KI1+fC5aTEYnpFA4ieK/gesKKQ1UIdcwSU
ftgsciMyF/i3JdJ/zwnDJrgNwiPJMuk3pwa46l8Wj+puSml0i6yJgAgWisA9i+DG+r5WgYEW8viz
hOQlQ1b+Eq0FcfUZlU25TU0OV7F8+71+sZ3UFd537tDly1yuRUl241LgirSwva1Mgi+PSIVpH21l
CDAPQbr3dQMRvSM11V63es8oiUAAuDBxn7uac9aXdANw/dR6vqsdZV3Igvw5BZUZJaWF+HD9NHvK
vp5V+lwadFqZmWmoNyu4FaKDZixTuLoavMLhJi7RH7TD0NKJcyRie3MfPXAUxB1r++fMRsBB5+5e
CUsGlT+Efy7WxoEobyPvzhr48cdr3hQ2JBbESBfsJ1qC1oYOZp9cDFzAuZBesK1CW4WJL3ZEHOR9
H9JSeDI8UAHph8TfJcTOafEB5hquGj646cgmWMdMPgZRb6+YX2ymjMvBbQh42ArqlxFuwrZjVxuf
0yqm+ycUXHu5Hklt3PsCXTTV7tX0WPh/9jvyO7NgZCAZEpgpS4GkiyUVsQWE+FZXJDZJvo8xiv9w
/jnSurCv+oyxJi7CqTsojJC8UeruoXNfWe0H/tANmgheu9x02MdjJ169aqfNsUu/Z7FNlWZbVAgS
bseOODGU6hOQ5e5mWj06qx2BPU7PEKRZqoPFdjw51NQUdxtF3Kaz0l/BbOdyqOo4VudezztbncwI
pmF8122Umyu05ISO/u0xU43r7iby3eFO4bLVIpfR+7PKGieaW96ge8cZ+y6hQ81Ncxfwux6+XCLO
UOZJ+/yJU+4u7sD1uQqSozgWMqFs1qKhYPc3sv1gW3I+y8RhKlfqrlUEQAfYOlmFUDmB0l5HDB/4
y9Aw84qkqw3ROHq0jbZI7AdIpSmEME3RaZfioET0veG1/w/4+zjQWUrxcTGtnEliqdPk203jd1YH
hZuStCrJzMgzD47KuYiKFpzh7208kpMPnbyleInxjoXm3oIx7b/hnT5CE5h23iRylHkj0CPhdJYg
3iUjRDiwzTwT9vJbH475prPsNRLyV//b6jBlyT9CU9cxbJAD3Q9ej21zV7r8oovv1g0vWhtq99ik
JJCc2G6FB1faxb3PAZUTYTtbPxD2k/CzFjDC6WQyHfgUjeB0dUYfvkMCfDDdVQXj0wkT4W8FXQBq
LqngK8Xjli88loxpQYaWUzAGJP7XnDiIr2ViFcFuLYCkLK2JmrKC1CLJ15SzrjWdB6EsyCU0rceC
QrWc6wJG6tZjwMf4YgOmT5BYMVxIXJwqswM5eZ2G3vyDjwKJ1sUpf3BjN4mNoDYBs1iLylq/oA2y
4Bp1nXWLS3JCLtj3TsnGnFOqUxYydqvMUE66+PdmmAeKUO5266Efvar4MS9iBX65zr1omADHNFt8
4+cdOg4R5a5FGXk2nN9ceZYsEXpdSmwUJScWnMb6wC7guR6zAKBCcds9Hxy/pHcmcXzL4xI6HgGp
1OOkr7G5Ez4wMZ4NMlYL3HLHROK9gmwtp7kbZ5IbuP/T7BYSX/5seCfdj05VDK5VkYmb7kVdY0nu
Ub3+vKGLUzYsorRz1qaVz1MMJ9TP628rMSfQiKg6nvpmcfiMj4ezcHQUbKOVVBgK0yIehzwHUNum
tJHxzNRVfdthiuzt2O5wMKeDMd+EJtwIhf+pfH1Jf4TKxMKVqqu868Ap/2j54OMIWzXDa8HAoxkq
qx5Rx1b1ZNg7/uDgYhJ4L568jv2lOlBvPrUN8V7CWYFR6gnlNTTCydQ0JdJSfvESDjFzbNB8rOre
2WTuTg5PaeOwSIk8UbewSD44Rg8xSAH45GO2qCykHJ3mGWlbL2+dPt3AK5gc2aXKddd9hOTjxhvT
NywE6dG+Sx7B0yWBAGMjR9geVsd5cI0bagQe1BxTS6KChu1SigpbpK5xp5s4RDpRWt9ocjWYpS+2
gv5InlktwGhIhpAeG+GPcaVmPCw3C0TJ0R1NwKJPpORvxsWrhvjjUmoFTqRTPhNxgv036y6tdcc0
kYvmCAxBhorFtG2V5rHFcg83yLJ4JvvUslj56HKIGk4U/lgDbZfVzhbC1OT2GTFNENZWsW4IbGbR
82ZsXNGWfTnClBP0Z4tyEELjZ+0UqmAx4Cx7LQ9yqFMExUCBhce57JUCxAglnYCve0==