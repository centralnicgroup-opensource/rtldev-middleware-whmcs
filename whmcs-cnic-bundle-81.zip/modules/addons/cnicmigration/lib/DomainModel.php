<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnlKUHfnTq9U31liEJKnSEqER26qg+42XEL6c6xney+0O1rcR2mYpOQhP9F/n2ClHyKlc2/F
MLZC8d47Uvdtc3qunE4WtxBQNdluuzSBZiGqgeMttkkpepIZuQCEOISTnRHnRqxP7ys2a6YsPUPc
D66zJAuZbGmUNaRe/j5mD2xV0wwuWlGhRS13tPo1fC7zGpvyOf513f5uweEMcgCxJP1KFgN285nH
xjM4iF2h3g1diRnokZ4rlFoszuoAvk6m3NAqJE4bQopHtbwVvfXWIQvWX/f+R9iVYEXo4GUttrt9
e1/7PXM0LDYkyRgXRoCBfYD1Rk+gXenRwoI6FXPVzClwbODf2CnOgKTUCWkf5gWm1WXYP6LV/K/U
UA9zLYlqE+NzqaCGNzEQH6BU2rOGvl2qhcsQGw7mgW0XSTBWHuSspbh8NYubFvps8Nxr6QxFHoGI
jcnjyoEJ7G3h6xMMqcY9y3qIKDk0yP6JpMxarw0dCyN3JCSdy2SwJwbhji9Slq4cfqT5kY2NYqq/
GgR/lEnDvGou2XwwwBDFTdfHeDl/Z+kS/ulaXAdD7gdlkPD002VgOhi4XvUGuv5ADnBCA0Dip2df
27pxPHvT/i3R8XQn9BlQtsSg/zK4IkoPnm8dAcC6K1P1nqLC0Rn0/qdN+CnYf3xoXCkkyM5pu84h
3TJbfJ/qAB2S9ust/xxw28YW3Uv89BkKFe+kbeFv0iSr+vc/E6gHoZapE3BwHemJ8W7BYYUwKjnF
Mntiu4aErlZ60zh2Gjt8kJ8PJ4Pdwrp0um4QRfu3baVI5n/7/zq4PnE1EaDfwNBjkaUBIrUEND3Y
vCYrSHgiYh2PWtC9L6yWPFRl6NaGWRMymZQL4D2B/dLvs3CYgGwK8isKiUw9syC9x9/q0fn/l5Df
YA1LMqvLSPBqO8ITxZXx2afBUVwSEWzAMI+lHNnFeFgUiIOm9fbMRslTFaTe3Thd5QqmiU1TfNKm
QegLv//fCpArR2pIoIWxatpr7NaWzOoe/X36x3Dk1vI9i4+JCuJR9AzM2DB1pTjCaKtPquXI8reR
Ok5T7wHyycfpiX7z24+JS/CDxf+awPE1prraFn/2CAWb6e4OEmwr7tfJ++/ckh907st7G952O2cR
IaNTfPVNXKLbA+3PtjT78ZPBfwf4/QeW0PzoP3PqBgYcVX4Rh+m7nQ+FMgfg49XDrPplXJxZpniU
7zP8zHMaG6LZVoYbKAEresWLhsMNTCsmmJFg5b8rR5WnZqWBt8CMkH60bg60H7GAb8e6ZDieBB92
AApFzQV7CSSAq1p2NHjg2dg7sBWjCgOiruzPpfMPZKcWUy8R9BDukifI7XnQ/CvB1hUmI/5UhXwx
zfC47YA1C3XuxIxmX4y9dgiGrVny8akS6kbrqBGUFQbndpGJwnmPGrvJGigwcBBm/FMIiy9Cimjz
Y94OVQY/z8mLrYTytS/RYg1Wu6piPmZW2eoadTCKQpBAZ5k470sPS7xA5TibYhM6aG3cRcU66cig
/BZOofM0kYdeer9DULj3dHeqnfrwzTd2ZLOxIiXJfHMKwcpxxhz2JkB2smTVPreiHwBCYEWtFiYD
3n814DTioUDMsA9GYvoAYB7OU3scMHHYJ0NZEYYXrono1AsLSYREbjb7TVMK1fpj4mqKEljDziTu
uc7XSP2aT0oU7H0ICzF0HPv9eDLT/rUczfrYaLaFumVtBS8sIQulRXEDYbSVdiLQqDRmboOB/GZp
LOqN7c1inu+jmDEmiQ1DBaV5mA9KEh6WcS7rTFf69vp6Ng2v8X7P0mmINGuMIis0IAktfzpAJ4w3
3FVvzb2rXxN/p6p3Vv9IzcQ7quAW4rqz1ChYm9qK5y15aIeGjh9a/bQiXKBIBAHHQlUtqp1k3Xv8
7KCrMyUBi5dOPLgZbKhH6bQVWF8GD8WYJLYOuFN4wkAGvTXuQX+xDxg/VrVG7Z/YnYN9FwchIFZj
Im6uiMxQEa0jOFGjG11wHPiqShQWvl/yIaZ4Skuwsnro+9jnxr3kZdEVouoKdNxb1sVt8YRHm8A7
HZ+6iteNDrMpNGTR/mvRwwxv3E28yOtlnGjfNmUMcybXELgTjpUPUwsCP1asdV1UpewonY1GcoOS
eAnSChzLxJVxP1UawWiBo3RKKM/WJLg+1gy8bukpRqTGrxW0Nxf6FMhefFZc3NGgfmTKCbujJPl+
QPwuwHViiunFXK2nH53CKDcG19c1FWFG87iEeJ/HE9FUtDOR+M1vKxQ/o2KxXT8qQW5kO1d7pKsA
ynRQlW7E2z+Pl6Zqrqplk/IspPhviBoVJ4R1aUBTgxWg1XO2aGnyPeV5eDRpoAjENELpONkciUyF
7y0X5YKIHAzdIiZisuSDFGVIAVU4PAL/QHDd6xwh2r12dj1ZbLHCAbXWQN6nYMD1w/ZZ/SeA499H
OQ046ZbYfASFb3WD36TzWSe4DqvYvYWjWhVliK/FeempdtUmt7qC+v1D08sW8PE2JQ5nwQQOCc6R
WG95ATgFYPCOnZ/+EMa8Jg3ZTI8iZB+lzbo8Usmtu5MKG9qGZ9duhLpJ4476KtNISY2n5fMxZyDj
PzxYB4uv6sJxmS+nKPD2XW4QPzj7Ua/M61KOwbKpJBPYNHu5GeDvRZ6OrZNxwuchrxMAuPX/3CYb
i9jY0BFOq9A3TDb+VGm34ZSpwaLLAkCDn5kKIVc677woxb+RuvHQCyg/tKuGCdcyNBkaN5wHUn5G
E606oC0deOKnEHnFPKsC2KRfZh1Y2Wl511rLFPoTAUUUgi7chwIKAw270nHmZq8ufQ8m1JYh92zS
aBbpnW2qE3HBjdoJaWXFTM9r8okVGNqthO/0NWVPyGeYhffgewVvAV7mOanuWOpJNiJTDI3YxZC/
pQTlQBBahLiLsgrib2eD9QyrlnWbX+IsKmUK+D6o83wKEot/9XjsLnSs7ERWm5DtQLRn/qhBa9HZ
0WP+Auo0E0AkDOq4Q07QoFHXRaPOW233Gtl/JEEiV/24xfUqlicYgJc8jbXLtbWS1sOwS7+GbDLg
aGymXyfV7qGrKLOLAOS+eYx85b1OAsj1bBb9v4ZBxml/Fv6C5Gzf9p9Yiknj97VjZ+Ey8QZ+1uUg
nc3IpC1qSMm5GKHbm8CmMMa13i2J3b99WVdk1R7ayQgKWrnUNwAaTvWBcyLvmYxQEhCDUNh6cHPe
ftKrtQheVOHAot66HdXGyvotKJUwKaV6igjemCZfnsvcB+cn5ZWVhlYZJaR5kxMMkdJkgt7zLhlS
Sjkx7WRKh1+yUhxAbQWiLEo6iiUW9zvSoZwPnbTRWef4UzoPboEQq2U30tPINNGhBFxnoF50bNCj
yioAAW19wEKv2gnQ7or6AC6vLjLX1dy4+/MuRQnNJ9REaGiP9sqMWJzxX0ZIjH+Vqy4NcvZBrkk6
OdllCV+v6WdQRt+2Ce+0RhRhyY6DeNn3M4fhZ5DuapSSM5PiyM5CnGdOv4oUo7mf2furOQUMu7aj
pjl/YOlmKzS2SEcM4kAr1a1+d8DOAwQo+vD6fffPllzMY7/Gjo64azlS3coWGifkwG++IsRBNEIi
JGwqoMeGyRl2yI/R2tCYD2m7h02v4yA8C2pdM8LuGuYz/zbWc1HgXn2RVtEN+PIdPGSzQ809a1Wx
G25INsr85rQTuWGFsVqb17EZ6xcWdYQOSim0dPj6olkXtsNEziLnjNpsFItP6iFpmrQBy0h3uaZu
LNzTnqIfK4aL9gLCYHQEcRWnro/59hGuOXJeoIkPO+Cs25QEO0KDSoQ9kPZ+BSC=