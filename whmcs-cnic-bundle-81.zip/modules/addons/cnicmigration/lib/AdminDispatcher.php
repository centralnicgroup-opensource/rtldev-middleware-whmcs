<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpSo6kWW7/yOpps3ZyiG/e3dOqFVPSkQuPcuQi7KCDVLZV4M6jk3UucaJdz9hTPOyRFHZ7vI
HIz6ocaW8kDkGaW/AXxwf8DeBAkSgzXGfTVS3EEx67KIC01dqVcqN9muttMZp2nqqC4Iji/uChCT
VBqcn1aoley6XESzAvNzmXCR47wc4yF8Mg137a10Hg0/HBgwb26n8TNJKDxH0wZzZOCkfSdm03Gj
AWGGckrPTIxpRmNZ6Rzo73rPEJqWTEm/TY4u9y9QBBwxwMaOXrnFuw+P3mbbB4y4MGN1gkMPy9L6
iIWJ1kxdvfdbQ9CKP89NZIQezoDuSw8wM/nahsrlGD4bqZYkqrEEVks/rjQjv63niNHMDp6vkYvg
FZVKwy3SNIT1Z7w38rogZ8yZaIHg5L2YZJBiH2WjsUnxsLDMeSMbENPT0XcFsvhN6/KS4YUKEGfA
ThPtQtv/DUjijCsjGInDVoWMOBo/qL5g+CuxUN+1XByfJn+FTmPLqeukRP/Do3aLPu/ufuaMPSNn
7WSfjBWscGsq4DzMWW6/D+Nt3xGuh+z35c8S//ST7mVnflUm4AsVYA7a7FBCqCMLxoNFZ//Z8O29
tYabTmli+Tn3rbF2Y1akFaMB1xJ7b6lFV2D6ZFr2cEQlOTP0iP3y3p//D1b3DuOkuADdxvDZicK5
ran8Oj9M4G1PRiOqHwdVxksEDllVBVBz8XsSl5MwnstnIljrlzJj12Ifk8WMA37lkMZEtraI7D8n
jQBUNoYGBjwOl3ykGBzHhgEwrvMD7ri+R4HSN7YVvXaN2/YXb7umb9aBJIFJjgVHNeYIdea1/ozQ
QIyOvgFQlPVVOy2bC0rOpkOVl+D6YGF74wfcD4QaunAQxu3Y+YuUlf/a8/pwBXwVsPVz9vheWeZu
4qBg6zJjuUzkY+YFabMWELu3oxVnIJfAPigQ60Ol5qTIzaeUYHPy5KxgZkfrIs6wAqXiUXuEOdqg
pzslHt0jYgXDi4BOP/+Uk7X1eyllbRKwcVeIQanyYkRlxYfxRoZHxHGzK57VtN0+VFx/YMiTTdZO
oLOFssdtxqioBvsGd7Ch/holtRfhUTe5xAXNUWtRUg+Clq2otM+vin6Vm1JMfH+n4P/iqT+gH9hm
ORbKwBhMAe2El86hWeoSwm2kbleWs5oC70BrsaqGInzd+yBP9vnvLLaazB5ZKu3yifMradT7TGUf
u7Jg3yg+vRW94xE3+jzfdGijwOuhV66U5VkRd74un6P3CrVC/9OMPJ0DPDszV++7iGx3gU3BCkRT
YzFLbTm9abLl7xjjivAhJXif9eUGnMgHoQkBU9nVoVQMXGnKfSZGEYz5sr7THvVsONjDMLyj8j8j
iZ7oPqP89hzOLk9w3AlscJN1ZB0aPCP/RRVaWx2twdeGZM8buEiVQX8Lov3e0oeQJc215YpHiInO
zVqcrIdcl+9uX2YqJt7MkNQpPjT6+2JAnZibmhKBKgclkR4zBNZiFs25I3aDCjalN5QvktE2xkAq
NIGFOjpUZ6rx84l3DbS0tPx+VwsT3tHxLIGPwmgH6jCWaxMImTkz3Ffhjo3QAcqmWRqkZ+bjPCSw
yFB0Gu9U8cOOxW5jjHm9h+6h0Ypw+9rbOggsSZXkJvYQCOMyG1QN/x504DwcTCnIQBDm5bBvOKGi
xTK0WFba33aOcgLGJUYU7RXHVpGZdEa4gmjAbfLAKpGBScxBqL3k1px89NVapkPyLbG6MmShcHYy
j1yRzG==