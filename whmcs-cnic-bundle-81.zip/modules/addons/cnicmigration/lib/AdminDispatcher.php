<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqPRq7cEfoX+L+f5MYxwPIdyVmBIw6o8x+5/V+7ZhbkjDMfZHLUUIzXkPs3VnT2MZ28lk11A
syVNR6DRttGLqYpEznAGYArVtl/4rGswMPt5DA7KmHewKNfTuEfzKypDmSbw16Ug1vYxAX0bUq/V
0VLb5Nkyl4nywGLrWtXSuQZ4isNvZgvjngIwlTD79oNBCkq/28TB7cWzyh4uncX+WXa+hgVUsr4V
FbrLMgHe+K71jNbCCOUT7JBHpUqgsKPN9F4I2U4bQopHtbwVvfXWIQvWX/gSR0otrW1zlmFvqrl9
m2w8TO7qvF31/he6u3l+Z0OYNR1oDnUoJk94bjESa21gUtS2+i31h7FeGIko5B+951+Csn3jYZuj
eoH2AJjZmzuVNorstAU0qNUW1wGGvB6BVUOmXcaZmfdzsXKoM0vAv3//nSHWxZzM7xpXCLjUr85j
UMUaiHMiCYrJXW9GY1ov3pPeo/QLmJPzczWWN0KJQFmZYo8ZSl0AMohKNUL76kIvB0vFv79N/OUk
4mLub5Lavpu3iuSvnzSxYzLIL6Ly7aM34K/Y5Y66qtupxTWGrm8Ur41Br2/GzTgIkb1mPoiWEYrq
m1mnrHlw6SY9Wjj0Bkt9z5Is3hu3O8TMRr7v3AufeufNJlSV/qEn86gyvYIW7utf3n/rZJ5ONG2l
CeVROIXvT/v/bA7TIUT5KahBKyHkzQKVO/9cajO9n8y5pENR+P1fXtsTGQw19492HswhRgSLg6f7
1PTRkvyKsCGiAQjc+C7S0rjR+O0jUlVzDd6wcogXEsLhhoHhz1J/fiEIYQsbtz0qiFwItinyALDq
3UL7tYktOjWK68N1aQS1uxBJiMeIVKZlAy+PLAGJgXRtq76eKnJ5S5P8/vaKptZiV4luHkQXDmf1
l2su+fCL2gctWN4tMM/TNIiOc32qByj7Z/ep9LkEcuAA22yx1iTJk6MyXS0MxkD8ItRODbAQ+9ss
QzcGUBFb3tGAK5KfyhKUpOSYmvJFL/Iin9fQOJ51qdtPzlXjC6ZZU5m40Bbdnq2Ds98i9NMLeyKI
uTfuWsWrKmOcGtgEwuN6vADxalV5XhjvJmI1h/27Ken1DcSJQAOID4b/XcWvt0R0RwPhgZckNfED
9Tm4f7oins5vTwOZBXyW0IexR8AK40FWy6nOLKTpAr+Yc3HRDRwt9Fo+asWl8farZp9bg6/uj1Vl
eJILxwWUA63wpmcn6Z1qTAzJhI4idTakgQiBgs3swNAP3vPBi7+iC6Oqdui6YmKsgyL5/IMnjOq2
yuFAlWYAgR0wLyfM5+cl3J55UoHCN0jU+PQMO0ViUQjXRKw3KCFbONvMc0XEsas0EYqk8nZ+QES2
EAR8EjnfN2r/FGiHAcPd1uMcpPWbVcYzWtjLqmMpp8E6dI5Ew1pNPzaXxVX6hixEQf/2JM2hyoD+
XLmICd9H+yhlBJT98KwiHKBIlnrOCqJ5zXJGBO/l+DzfG8Er2vXGMTLM7jgw6D/TQSj0swI1nqU0
cx7PjHlKYuDtaMeY/Wa540nyHbwj9F0LZrc/YHJV4nrqcEo66uDc1dUVLjyJrlmvoje/HVqHrHRn
8pPvXS/XgsvyCESY+emKWo3dUeEoYxmvRqQSpBkoB93YkCAryaHixaqAgYuZqyfVqJyKBAwU7PbU
AuQqu0Lh516xL/VIEILz8mW4dS/dQvnt8xTykNCBve5EgKLTRQz1tQW9PW8vsUQ0O5GefwC5ZZ0=