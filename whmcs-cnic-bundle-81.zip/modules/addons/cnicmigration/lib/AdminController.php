<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqMF15jMM/sSBqUHUD4jdKLA4R9gDL2pH8UuD4tlwQd9OIjUmbldzK73q4MnsnT7Ops2nrjL
+5lpxsbpZY35c43M+vm8NxE/PG+QwRBI8ue+o+6QJTEKcYpubivZMUgg0hfvT+EBmSnGoHMQFZUP
Tz2a9PV9goB4SK1Sz7aYeXxgkKJEvMg+0zwWfb8EmDH8wMu6ulY3cH60rvZ3sR7ai6KtI3LOl9YM
nEft1+xBgX4PNzKHem9uNzTiKBFNClTpuyo2uILhBD7UNf/cc619hc27+ivlGmRslF/UHGhBSSdG
ZQWM/sKJ4C4oeaY7ly15zTM8ZJb03Efly0lQBplItU5EZoa5zaGkeA+yBlNWsPFDe3AhbSilJAYR
W0ZZ3RdC4Y6YtVorT6rvw56smms9LJqC3o4PEv+TWh5GcenPnr0qiP6juT7kYTV5CkvHdvqBWH6B
rxS0wbnzbzHX4mlia9/pHJrNp8vtFYP1FWMyY1slHg8cS2OI0RiBbk+G10YS5w13E0g/8f4qjnUO
9W4tuKAdo+Ascet2MCtTK2oL68sHo5lGTbg9sF8Qj/qdQUg7KSlVX0Dmmr/hFi6Zma8+K8g0WCBO
+T0RK6isoG/VnXKLENZF1umMhoH+MTZiT2rVcgB1mIfiJSoUTBML3iY+XnK5E6b9d0O80NuVgP0v
FNx0G9AX8GvFoQdq9ZiwClPFe1HKYvbVfxswKl1Z+lYw1pik4q+/NX+ccWBOJOLbtVefeBn9sVee
8HVpIaTWUG5CpjmwiuNMBgbmfd+2CWKiuKSYYhubacocugWXgtacR4sPqi4sziw9mSuLhyO/NFjx
c82h7le6E2zZgHoyPUXp+68/FgHnK6JRD4BtW1HkZ2liLS04UmlXGzQOG4Mv+QoeEs0edlwM6Ka3
4d9qhtv+AHQNDk2b+s3/KvGhlMEo7UiGkHu8LUY+qo+4JLFgCFi9i1/LYgclYkVzRPBYovMgHVjj
+3IvKuoVR/+EYvO6EqOP4pejxbkMA8KXwjTy40/mmNeS8dARDvhw4RB7B1lKIxvyQCvT8mk+qtQ6
u7sU38xuJPp4HptzRKjUYB9ESWLiQxd/Bh8YiqshmkPaKHJGjnYiI7KEYQ3bOwtqopbKIfzHLcpZ
vn4cOuH+rTa8eswmmveJHhUqcJXQezX9uF61RGKqAsWgoVzBY0jSXoi+6ixplQQQEwL0+wNbG1rU
eg3zGKpgpwYGBGDFR7JP30jmu+4mdGZ1EzTl40KRM9OAGpvp0TJCB3AjJpaFnjl0mZLzMtU57x9u
qjTv2cNL+erUWEAOuGW1c/FVvnUGFY3UTFIvjr89dDQJVUrIE3IiIHehtrDrozEVC2+LtTfKtqOx
ZeBMXJlgW3/toR0mo5uYGQ/JQgwsX3N1av8DdSx0DHCmI5ZlahrUncc9DDgiWJUTJGM4qMc2Wl95
tlpIK6UrBLtiyWKOEVQ+LEoLtfHAYac+0yHlXMJXVWPUnPtNxoqM5CuqtKLWt8VTqB8PPM3qZ8qr
JUjIjM/eS5FzSwfyjvQGIQ14mwCoQ+cm2PLiwPEbjQosLuqDqJ32ybCIwiczGD+x3yzgiS6SeYPV
43QMn16FjwKCPkKnO+N17DS2biF8xPxGJuIfwRgrf8HiPpcL28NykdMLLHG2nT7tUqVRjLo+jW72
8zHm/6zlTUWworaGmNBkXRJx//ZO2RDLENWQYPd39kwj8Ohai8IzuY51r2n+bzRlmm8VWN8KUA5U
MhhdE2UGBRcVtD8EE6CDtY7uZiD4N8ZmyTntHcNaJaVNTmmWpQCc4DjgoodIxJd4oIsY9zYg4yWw
Rynr6/+t4W+nNsypONJsbJ+PE2QRtSgri/eMSyUXDgn+j6GatVF+UAGjZG37E4LO249r9EGL5n88
I/+0TI4Lbt37ElVRlmfOjqp7Xg8GGD44re7tniL0snwD+Jj50tMHXc30JJg2VuFqdEenVKrsRZyN
Nc1DUIG4jQqFvcCavzr5qUHsg306QX1wTJK2f+PxBJPCUOSfRdEb3K+w6FyrGrqk3d5Lk2cTYOdl
N/Q4UJc5ZG8qaXC56d6iGvjd0GOrhrXHPD58rYcnHNEVTyBWKsphqTqVbN0Z+RcVKNONxUCJcelK
vb8LByRPQJcrRXR1HDCcq5O14gpxY8GkN1ZvuhYck1KAzPX7zOY1LcjzwHFBxxr9lx74YsUfee8z
Ul0/0HjF5kOATMtJr0T5gwa/7U2h1cttWX00rmc9BAzJs95YvTWZ789ww4CWADKky5MwescvIAMg
e3DqrtgG1FI0HhNWXml5uowlVbMHke3MebTFDIPn/KXo/JGOgwM+5VFGP1TiGQQ18CTvxEbo31Jk
6w9nvlNJ+w5CLDjVWOiE/w4MqnjXwMHOHN9vdkP66srGa6QwN3a1pTj3SbUKcXHs7/R13TaBp2yQ
bzqtQbH3dCBr6ozVd4c5PmtiuILh4UwJ+CECe4DKEfCIoNvhcDwd4sO5rUF585FaWUkCL7+y4M2r
2hOqeeMAOs3NUK6I4gPGFT9AYNZojOIeMEELa/AvFJ0X1byVUY2F3Q/ocrxQ7HFnydJMTbIp9NPT
5izfjV2sglBZCLrFxDzVuuL/ZUGVZxACYnrmXpGBBEZ4TyITvIIW8XeT+H3chXTNjGBVxrl3UMEK
8kbRLxZzGw9cuTtr2XnWfH/FN8dqn/LPAkK7Pxuwua7kG9Aqp3XucK+nbo8ff65a6k2cP4S1ZmxT
CenaGBXjdjmkTPf1V5cbXyHZrR8bcin2uueeLnw26mdLGgSIC5DC26vK0ZcxA2aQah/4KND86RGa
+qDPO4RsMK/xbclTX4EnaIjVnasjVsHPWOF8q1eaA/NIZdTxlvLtvvwUgwMYLDeboeV84HWMi52z
ekZzGLmWjLwNiEHvOlIpFalf+F8ogz8VtXp2lEHl7d1QAUkfWj5GkfCtcx+d6VmKUuqtiIVlIQ5S
focs2gZlXfPu0Dr8OvDNNqi/Xul8exFy8XmxX+x9d3ex0ggt7jySRXvAjOhCPg961pb8Hoo6okTY
9hDris0qd8TleGxFwziwZV4CFlzmsOR0/UcUz0ZTT7BNdLZC8LjUkwst/EnPp5+yTNL6/wZvf4SX
CMtsC/cKRskQq1EFVpwq364WHmTyxdrQ/92kjY8CxTavs95bSBbYyds25LpuXRlhhhMWAphgn69M
72BRuUNcweu5Z01l54XWeZWSkL3YxlOcavEgZFTifesXXtXdgH0TG4EsNONqZ0Ya3Y8zklYir1Bp
0+z+DQygobWd6yWETenMJFDvhgzJEzJBx+/LMMAnaqfMsuFMTAGs29dORUHwGcgWSETXn0uixt7U
wmBPDbEQogPE/yEDhSmU+isD9DmHQec9YU4q6xEDeuYYsSmWLf4mPprvVDSps/8FRbt+U3xghRkK
9XXyKH8gfC8+Lik9HMEd1Eyvxs6Y/Cc8mTRp+LxJmcezr2O6qcKejm+Z0BsIzRocPvpwjA2IXKcZ
2bdW5EmBCi8GZPMgSP4zj8broUGhrHdbOfRldvAazUG3J6kygZUj08ekHOhsZuurFyJvZyyutu+p
G1pT5krSHuz418RdxQRxdVStbXL9HcsibJ5tavysEh/fzu2w/p0Sz+D5A6HVtBtI638ppB9TW9M/
2b2UJbvqP+norSeDWM5h1CZZNKa4fWGavQPc+EbAsjnZvX9FOEllCcZMJRteOiS7sUQCi9S41U7I
HdMnOiqXGdpASlj1zKEsLmt0a1/LoWz3SImxMzKquwRoXRRVu0ZJfG84NY1lgTExfLu+r2cd6QQN
TGsKp40AVoP6r58Sx4OSUrQZEJ4KoJ7ZOg1409vf0Tk9UreM6mXUcnIaT2uFRITUenZIPQkrmFZH
E9hA7PxeyYvcnm+ZNE/dtoD1TYc+wQy5JKaZahNdBlrNHqt/mot39ltp9N3fDYxtp42RVmn/XDs8
9EjenQlHeEwpnYBgB9lBEkfjXMZP3+7NUEfSeZKFSjJkwN0Wol7MALpib3QD63NkQhl82me53xc1
7A+sLQBkgK5fC1at9CD5Sm+3GgBrjGKpQkkPY4zqX4j68eHR3R4oJ43hXCL4Ncwp9gfqY6Tn