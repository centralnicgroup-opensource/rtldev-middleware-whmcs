<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm3MTpCuEKm5nMNY46usTI6+e5sy2cWOCh6u/AKvW+hLp+fJPp2fOGpprkQEuzVUUGW2Lv77
U0JzuR4/oNDoxNlr5DKgYxC0HZSLO+4TA+7Sb4SD5yVLCBdo9u28I3LptlAXPxYfBd4ZmjDnwYSn
BOd5e6iJbiYoBeeYJqnfrAlZnRZVQ6Y5cLxeIyAp/fr0CuvjgIZBl/gIcf79rw8Yv03je+9lYtLM
d2t661nca5Rh+gYWVyVdkLj0SxEYN3hbFNYw9y9QBBwxwMaOXrnFuw+P3tfiEvwwab27ju5lqfM6
e8Xg/tYWsGzjcYh9ViTb2a+iUtDZ78cfYmFu01MYW0a+UEx6kLtfTACUHxGPwHWmtjXuSjgFqocK
m5p1f6X1rmzjfLMZEMX23vkFZEvv+lu72EdaUBHSX8TNzrm+3jonmsNvv1v3kSHKfkLEy8bUR6ib
Y6W2X2XYlbLC7sEDwadUW0DGnzpMhMlKop0v65u6UJIXNkOsEqJdMhtdpMXhm3z/5zcDNtAczZ71
021ASKudGIAqLrTKE7TaOf8lUgbj9iSFOo0DLnE6h7qa6nt1vReHKyZR+pQkV3QLPuorAAJ017SM
VfbEzLXWK9ngC9vGuqwuvnX3kDPmu0cd2xYxYXqtnaVUhaIApwuGLJIwzZdZMxQaFrUtXEoDseqM
KRzgZGLij9/CTJkFQd8H9vQ7nwX+XmZ8QDtY2adz6GyChF7XSrwLD3dwFi3I/0LiXysoNV09aLy8
RITociZi7Bce3e7pmTFwBuNF3h+peA6aC5xtYeNADNpEwSPhbS67QQqEM2l/dSEJ4Weq1vjyO3kq
P7xvf1PMwn0EcccfygYuMjH5N7buof/eWOLjxJ5J2t7lfO+cTySYcSKKEpBHi00uRqarKUwi/zD6
IfVU8L/Q9H96rrBMuE6yVNUcBQgXS8ygFoMKXqXb8EK48MzkQBdZNG9sN4i9foo/0LySspl8dth+
sNWXNkzLBtLfCrdUyzstjbgKtzP70I98mPHkccushxAIUcubwSBcjMrtCqmX16DQvskOnCZcFaZd
3GaHyBYcWcR4jJ2GfC7IPn8+6tAnVq9ebnqt0OePhec+bURfyYo5NwQktT+LD/9kTN4IxWEAnr1P
avfFiYdYD2B0OyMFcX69kwzr8XNA4q3HO15ilXqRwPEAUZrYAYEY48r5IUzbpmi4mCW1dGxBehvm
GheQcB+4H8U2nDPtH5WzmMMkzRfAxJUt0zIAOqhmjay5IY0JA1H/0F3o357JYiwa8YPyOOnkNrDD
vZapz7iv98ec1J+jku98cqjx5uUccwkMRAtrYAn/D9lDzGa/7sGDfgG4/HvrgyJaLyoeVvf/r+VT
h8KpeIZfMya9RR1ct5jiWm3rXyoCKcvmxqXtCnWCkXYP/EqdE45HGxDv1ruulfUUDL4lashxTNmH
yNsYISOkByrwz+H/vJfP4gaY8VLzEX9DAMQlnXEks3RkPODXwZwj0CnCVceUJgR1wbfPQGQ3laiS
pZIk7vswyRcxhAgTXzuzGz6kO63g12suTmdG6ZJxOU44x+wDza9Op4E+yLF67ovnhLQfyNbE2TnA
2SRtJb+evcVSlMXR67q0OZ5yBHaXjqo5pmVbKhzuis4poW3VrtQTl+rhUSvx0S6gpj6lZhqj0+Xq
5yk/7AIi9sIeOVMB9bY+FlBtnecRLLmUStEg7rbKTmkAbkC945sy/t4mmACS2NnVT+R5j/8zdztj
y9JXIVXYn1dyHksMTghWbQvE7jSEArkl9QwS6YPo3M2dWvHzfy7xFpfmiYpABrP4x5pqPEUX/ZqG
JsmR3Fbr3HS3fTVad8uw9NJ96/4aHplYzgMaBZ2ndl7bCCPWNetLf7CKh4fRz/IHXU13tHJkmRwZ
OMHUuzW2Ysy7Wz+NupPnu2SCCINcKy0x8Wz6PLhxdN+mp9WPUa2MQJRL1a0LvP0vRfgTXt8NGcE6
lrB1WeRgiNlHfKjRqc2TQ1msNqXo6VSYXF9wKjiVVQm2C7Mn1uAM0u3mjs6x26oig3uRggt+tg44
t31tHNtnrk4X0WNKQfHgjL+DBATq0LkzPIL/oGwxYA0c19YVY74EULt23OQfDLTFbpfz3cDlLpSn
tt8JPBZAj7T9c1rQSCR7XryUwl/i1552NBcL/UQIU3ibTdT8hPTx76srQwtm+G==