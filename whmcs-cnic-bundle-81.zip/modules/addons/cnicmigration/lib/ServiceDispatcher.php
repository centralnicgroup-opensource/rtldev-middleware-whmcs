<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnI6YCyRQN7WuZKTx9o5bGDk25jHw/yiLSoauJ7qHrMZuPoJ3cufXCuch5l1FSBniOVupSZg
1g6nxJGftXnX64cPEVMZJVQOOO5D22XD9tylD/2qBNvdazBmwbY1+12zn2l72fChRI1NyU8Mzw0A
YeOcgAAttu5hSRPU9yuBhqXcbrI9q0RJErsx7jk2I0kupm9UyxA5OwofVS02BxyLE2z5EsX1SXkB
Nog3oEHukH0pSDZOTLXveBfZU/zpBRwi4yVSbE4bQopHtbwVvfXWIQvWX/fHQQ2H6jHTiC95GXV9
u0Ye4YrrCm0xSI1i7hhfqK6qoS4NyapeW2fpNbMPDh6y2MUuPWKABNW2q1I5H5/0aSUIzHlHTE5W
Q6var2HH2eKCJOpQHI+KOvnYOEAME07Np2brab8ZBQ+R64fdBonjit0ZJQVEfSmPe4wSH0BZDr9e
BYvl9AqJa1lm7WJlulzZ19Szn84sofdfu9PJzlbAqN5ookhE+zr+2IujCWfYnLLOeXuNftHjgGEj
0Istu+T1AoHb9Q5g8dYBbsl0cWVe3V9e/DkX2CBXtY9ISQvWjN61W1/9K5Q7pUImWw71O5lNcUh+
CEJgtCGBbgzyv38RNBwKTrw0O1v+yNispAMdmQBR7qJb2xy/O+pKszPCH6vQ8IRKyHjRtpe2VaXW
0YMpduNTHQeIeB9WYRUITyQJzos+5KqVG2Dbjj3VVBfrz6AJC8TmU24uycw1AQXk3fFzpFhnXSSi
g6HfWwNQizIG1zME+rRiqI+IzTqcuPyD8H9ymoJG2tKB9s/tyC5H3LW0OF61K6U8W0P2+9EDsMVj
M+aBDQGFvpT8+909f1CS43w1iFP9l5jGV2kLBAa3nWDnCvcZWUFooHuNBNOeVsr87jBc3WCEFqkn
Poxw9jvh0W5IgphF91uUKckz+lSPTGdt5Qfnr6rSD2dJKxQ52GSPHNaJxowDwcjd1OHdYlHQhMgm
31SGmAzS/sXItOmESc//dREF8vUP0bL6Pse5+2BteCqkKJv88hi2zNCLoTBLFnyU8c1hmYcmokGO
acVkg7IwJU1qozX73QAkx7ji/NlBwu7ak/KIt8QCmxBxWCezG8xXnHu1Q7U4MQ4DY6RDXy6EaSe8
HpZ7ZmDt9wL1ME8m4Fdj/y4uvYYZu/QHV7K2NKj8nCDg/J0S57EjzVRIGug8tYTCOr4CQiiEUUeq
6okKvzHowj3zt4UKMXYZPSpMp4hiDjPn6c0lRU999lyHC643KTCP+/EfrTkZHTXITrDs3tuc2ic4
bFvPdDVNzNuO6Zg2sDL5sFlJKmvbVP+EFw5fXyVnH5xyx6Qw89BcU2ypM2+tnqURKQxyCZeka5lA
q3N9SwkBXGHjG7JzQBCqTSJUtvN6gv6lnLura0xNMF7TO9XdRC+X3EAb3HO8kn9ziseMGmdcFYBi
ic2vKKYxwniG/NK7/K7PSx9jzNXEaIFqaUq11t1cq5fnBejYAVE6nsdVgL1FS7BVaZLj5mTIqRio
voosYYRqUriagCT8u5J0IJxh7N0LpDPdE2uVeeSsXnn9YsS7tDdnWM7iM3BVD42Bx0UnUpqd/GDR
62hhggFJTbIwFHDaixth4hSzhRL7LeQQmprAwqFN70zEmF037+HJw/MmTw1nJrvdG8po4gRM7tPl
EwRBSROmOFvz1CCxwiKMvDCPE/IWyFfaDfiou8hTcxhEs7rTOVb2Z2ymmyKYwtnX54jz085/guz5
U5ds0vRPZBhukVjO1Q7PVCH0VgrdJG5OZIHqJs28NYblt8rkzQ9lFxdtU4g1XhAJrD4EAgVG/xKo
TC9rpBH2NoURE+pACYQip/lQ2He/D9sSVJG+wy9JcWyc1erM7GEnEIzsbeMkquNxO0AKGIvoGxv9
xU0ruXQ/zpuXa/i3a3T5TNhGctIJ5CqUaJKxgaK5r7iNfAouAB8Vc4xS4KvHo6cBl3s4zGrzK9zS
PJhhZITR97QGigiUxCjFXcjUdrjDucRe6uSjuxCUGiu9gQPEqR2BkDNDB8FrjiPk4rZ4jftm0LiC
fBoFwg/1WySZCfhlYzSBcmPLEcfrmwDwZk+kqkfZg9jqt9gK0YTN+vgx+wvZftOCYjsGa7kVJMrI
ZPMuBXwCE/gNHgSI7XcmngvmJskwwX6nKdg9cDQBiSS2WLea4Ubh9aixfTFiQz2teU4cp9QnlQkx
Mpu=