<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPow2GIDJOheKAZ3K0B/FbLnwb+ZoLzKi8w2u+BWIDZkuzVAeTdiZiZzBuIZikEctFTY9+Qia
AdxxY6ae0S+VOlvYRqvdGNJlbHKAoDT5az1VhDCNLuuPqrheoYM+ULfbZMkSZwsDI1Ju0OjzbpYg
fypE7ps48mnavpASD0/9kJsyfZZegsu5LPA/Mb8A5JOWkaPRvNXDjHHaOuiZ8jmArAaxMo6B/5Ti
V+0NNO3k39LMWLZSUX4HpIKYaEQMAznXlXlDJpBNp7oroBaE/VGDitMnBvnb/L5Mjghs4LTUMxSc
5EPxn0/LLvKa186fVHR1wLPT8+WiY3Mf3pheiZ1C59qu/okBR6QBHB/HU7mICTmrYt/mRrT4GaEr
8rpjcxHW4VbWArCjWUVhKP9XkHEIx2625mpLkX2VtdPM3QDH68P4Fkv43rRA7uc0Ri+iPcVqdR1Y
HN/IWjhYJjlcbWcNYTuj98QwWlNwa2kQkxPO5QnlW0NUJGkQ9DhcJ2LUaqqknTcRs2NX2MBHckZ9
yH4eUkaqOqd3e05LHSJ6cdmjrkbDHX7uBjKOLc+RCry380nHdsrYDav6sanvyXsoh4/scyc5pRj3
KXmDTKr2T7nqoClSlhXaqVeD+8dt14M30J6mbHNewZvJ+kgTGsF/PRw2Ojh0EPqpsanuro748thc
J5pDBM87QypFkTGs2D8Bh1fmp1rIzjHH1c/JTUyAM1XmakGk4sm1S4+wlg1flZ7Nlu4v7TMmFSk7
fHNfjHRhme+5hKXg9DjCa09CqfwiYbh2QYkSStvRxgEv0rmIVwsrtjIHIrkZ2v+4I4nokWAj1J00
vephuLYDROlughoqkqkvekQ4rY+vd5PBVyDBw5YV0FjXR/kiAP/GMmcarLkWDBu2c4cjJ+LK990E
9mSG3s8gkc2gqJcUngXRmPWFzy9xE/FysL/aNKQYyQLBRTizfFY3Y472zfOG4jHBm0812F9z0/ud
5nTK0Y/7WCYcOYY7LMauHs+V2bQEQoS3mBybPF1Kw6HUcGChjtlm7yJwxQ2j5u3nucw6WiGvEHen
pt9cCutZnobJ14qkA/eluEHReLwGZML0beTKrPVIRRjNxmw9CA5wP8yD8NKA5uLZPDFfz1946PcC
TOeFxIYHWVUgCQjdFGmBOYqs5cPdqcxPCp8Ph3NDTRj3cGnUp/CZgv3IDqpFuwHfNkoWUfc4vao1
WaVjLtn29BTucTXIceFpI4xmXJcjP5FH0pHnbvaKU1hN1V0IXrta2Ed7kj7dakC1v8W6IOZuIMM4
yv5br7B0B/MqNbg3Kt0FsHogubrgwcTE5l2Ls08HjekyQs+Ra47X32Oi3RUgIM9d/uF6Mo7MWd1z
t51r3FOHsLB/18wXsWfup2/R5grrd1GO8G7Y2V5Q5qMc+MSmtmb+BdBFXdE6KCajrHLVCphZxS9w
Une2XDJNgFxNyNafl/hVVIXkgtVqqkfFHTI2g0XgIsz7Rj/ej37q+n8UI2+MvAf7nJdzvvTTG7WR
NIv5rspChU+MR4/maDFLPvyOjSu88Xl4Kg8EAtlLpzfC5n6f/myX0pIWjvKbj/pqIQC/yPja743Y
d4ZcYnoXu9yvflT5qY4xz49CjomdDV43620ip2ETPNPB4FIufdh8hibIA3upiZZtMROJ1lIRb0MB
yPBlyS/8JQfGXrlfJ3GF4EfA22x/tloYdTlBKh2Ut+9aMZi4s5faDY++ldcls49rdCCjhTNkycPM
TmI5r33Ediq8VmAdi8FOtzi281Iwv6jnEclEaC7pRy1FVsbsPBwiiKKqs5OR0qjSRNA/N2p1xpXS
FTikqx1ff7HgRZEV/2RcZrgD3/Y/2tTZnL1f8sxpqBAALfeQUZWljz0k25xuvjZH3WZjzt9CXkpK
RiBW6I44G2ZcxgzR/ep8r3FwjQq6vM/dosrI81dhgGQAsUFFxV6y9eFktkn1YTx2q1s+VYE4MwNq
XKM8tYsh36wAl7kTy/fE5bslU96GwWAF26nEjA/UHBBFL2dAePdsPN0E+PxMFtZUHIYHgtua81KP
1jfGhx2HkC1C9PospXlYw6JjGDk0gZF6myOoH1uv1AVof5gSxbW=