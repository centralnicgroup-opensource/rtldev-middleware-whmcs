<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvDxp9dex3JUzR9PkXt6iYziA1On/YrDPznjsFsHKZIPav/7rBN3zxHlixToNyCPLa44sU0G
/DkkWwzxG5SghwHHHPEadTRWsxKl5DPPW2drV7nHbMVFZFr0qZZxY69VHCkmA3zUVpa9aNYghUM+
OH482KYeo1G0JrkrYmP4uwz2H6rckIvvnBvA7DmAdq9C4nUJtttjxz/52hoj6ws31QiH22qwTAnz
AkSndzFWVeeIjtV1oEewily4Sm2zxR4iOZPFCPWZNlcIoQGZP9hi8VshPPhcQd6KKHZj2vhE8Jt8
8AE8SsJOSxf5kt56a6/og3KWWR2qWVzN3QVOMywBafHRIorjnTyeE2DJxtWwSws/gKq5KcQu4mcm
d0NOf/bh9Ptw3J3WZZv817yckL3CGRJrLsVEkZN28nkL8relxDXHujwrNaWlKmpnapDXccWFXwTa
VtBXOVmJhccULVvN/F25VK2Qg7BJ3PRHwiqqY7Cn0MByBGmh7+uUf4S6xlQTyqVyi37eZCPFBbA0
q02CTLNvguc0oIaBrkE0phutTJYWPFE8mWw6OJNczXQLbKxtK5pMuj1585qxRAPwydoNYwtOdUyT
VBJZA/HPIctX2rOK7Fh02aFku/RacfQus75LetV3lBMKOw88Y0cS7UJBApsEyar0WzdA6UO1G44T
7LG5087Dym/IVxWf8dA6nw1hNEnnUs8PH4+DQizdxyIVutfaRwhNtOOitJeuK9G6mMxIMOxIn0IC
GuZ36qmkGKY34K6hOootmyDFKs5It114bIPr6OBUWAlk+M1Fu9BpwYaGG+H+KK0gzjx08pRfobSG
wfA8RcKXuqhLjsYr0kLIKhrVE+oJ4zDnTeiRgj5fWNt9nddrg6eMXNjFLAXH/O4aHRgRYny5ZsOl
pupYmR9GBS6MFxYPmu6N6fyP+v4nRu/j6UdBgIBC7jG7Nspr1Ntuy85EYESD8lykorftZXiuSpNC
hvh7zmRG9gtUy8HY22Fe82ccxJfRRSj6vheQJLe+JrkaVzutlMFJtQyf4gx5wQCSBHVLcEsb9wSE
XQVzTEpea1TTG2x/Qu1Epztp0XRG94HkmPbcVhPGXPJGJdP/duG4sfEWfeWCs8jDE3/9GZ7yIFTm
7MuRU48kZLSqROSz5jaszwIse1cXFvTmMU+JmEc1eCVwxX3NfNEOW3NE94iomw/hwacSijPmLrfV
dJLK0WFYTZ9vCtyYkRUehBnBQnb896Z3tI2h2sE18DNHtChvwjoXAwSnqOFoGQpqOifgu30i5zLn
S7Cu7WEV35v+eNFEHpEhDLIKxOD+InQ+aKtBZdfnTg2JbrFzfAUyX7NQURNpWM56Ah2Wx0M9xLeh
PMSfrPIkQ7cQqewPPIIrGCawh9AnmPxo1ICqnCO7qmORsOQ70oC5rt8uxy8octaiwPpTPSQ3K0Dt
DC4dRZMIYdvQTgkFZiG+HOF+Tg+JJ2DGrerlIGDNY7Nk9zxsg+rEudYaxNWUI6vMA8gdpXlmTb3O
GyNqwIzHQMqdGWRzgTE/TOmsungb0eVWZ/77efR8KUF2PLgQkj2w71buqT2tW8o0R503uxHNTrPR
HdKNlY+vXjJYp5vG8iXJWYT2wtZExQ8g7kxGC2wcxt65OCD2f8G6n/r7MPKFHPiMWeUmfiB+uMki
r4iDSqRP6CEtXwpfa7w7MM395PfLS7tt1lyOIFM51NxgvkN3bKH6nSqHx0DXKflLxPKw0wp0Polo
TOu8DL5ftR7v9teatgms69/lwN6J6mnvcJcxEP/JmLKS5QcOdPQC6yHg7GIhrUc9bziSTMBcfRZO
IrNG9hBQjjSt5IvvD0ovom1kPk+07t9OSKYd6xyNvdbY2HiKPvSdsmiWjoHAB0nCmeL+ORtn0hgZ
tZhVXMKl/SIZGKdNivQpC8XDkh7Ps4G0EhboQXX2QkvJbIG8Vrj75w2U9uRRCGVjMmdrfCL7EOmL
HtOhxKIR2rKISgRZ6D1qs6h7v8E2NwF8wgqW4zle4ZbzGlw/41tD0VbDKlcTFzjws0hFYfv67aQL
uPnSLTkoncsgK9/MXUEFm+J93xVHvqwwX4ktpOPaK+3eyFBorsr8LBJB+3daVb/oyZbdxCHJnPhz
BhGVBIKQYnwRiD2fjQUCtAs3CwApAMnsnzDo2Qg8eDwXaOBDH+3h2coQl49WPtA7MMUmXVbnENli
vUVugFt5NTlJGLVkM2augZzqJSIJ5x3X0wZlfAqagzzi6SNjmrk+X6Lw9PY0X8yKDZyAP9CzNeON
xS4XA5TpK9cX7b2llLvwJ6nc2qDoDh4ZyT5dzkPWkrTEtQ8TrSxCt99N91T23IjrfTyTQwWqcdNQ
cvO5ykqj49IoD43igzBkPZJprHucfqTeWDp5IrZHEPwdpqVX/1hzgtaWErgPBj4JwE7HouTl3O/V
Y6bhTiqFpYq8FvTOqHLHGWBOTMvfkZSNgNpXkj7JiWTOrfj+dhPQFM+VdeS9s4gCHimP7hee+WiA
PeHV4j1SdwI5JbJ8szXdrhCMXLhCv/A8cjtuPIBdDz7jByQ7OFMMywFRAI49Z5Wdj8mG1t9e201V
82/fGomQK3f2Tk7hlNkgo+9bvBdb1MqrL2WjMilcdOv+Y5Vx7VTFGbHMzgPAvu9dZRByqhw4pOKM
npFtmfXeCjks3lEOS08SJTCZzBQd+PPW5bN5ECISrcphy7ifDrlWM3d4EeBV3moawnOKv1MXLt9K
XWgFf083pBLpVR2iS7I3+YZ3nowsN1nQVhHjyMrtRVBnFho3+SzInw9ZfmMjl07zI5BWW9zDyBsZ
pzr7EW4SVo7u0q6LQ4wU7MgA8e2l+k7yVoglNlJeA3gDwDvSb4QXaMmaAe8plrG7p0hqhp7EJcoE
AsQvEDQieCbjgXOD9af8K9zdqViu17jascz9coW3E/1wsyImWdTjnQZ9gfx7tS4LNfUcxgNNsB//
/Fr+PmEmyi2m51KUm44hdPtmJqwzrqhoK5SiLwLUTLv727nn++NR0Z6JUJsdyfohdHmcev8SjCmw
J57gwtpHbc6T4irV5v1J3t8ZCaqVBnDfey+1Hn43OmQu0b9xK71cHH0L/wB8HqQNgDIKOTwiUQ4a
cD0EKDAriMHk7qDryVT19X7GLKdQGoV+OMZmEvRXhsItg5ZWW04fjiQyvF51w7GVBlZ13Kq6RrwG
pYc4ojdPDG8WMHtwLaIBwrM757eLtsRJa6+9nCTMuSq4w0IRvY9/bzJCH2e4OIT/J+hlYOZHVUD2
NE22vKV1hibso4eft9KDLoi49TVNTFZyHCZNFXEoaO/vBSmbmF2EyBmufQQRdyg9Xemdal5z/meq
Y8LFcVjiLHFjKlAgE38rAT5idEqZIJEgj3FMlVEOH2iWwZ8TeSryYwErcp33Mi5K8YZnVx13zNuR
9txNbVDx/4Ly5VHoTHy2FHsV7JT/wKqIrFkRGQ9laUa6NIrMPpPl/fGWN0jdAABSlc7J3Z+zvqQt
0P7e2r7gItvCe9wH8p3GYbIudqqAx4jbKuKqCWwQEuqDlh/9NqekbK4ISs1N+c1XKRTDS1JCkyJb
cpX0ZY/FaxoUfkQAhsWkHGtI6iRGozDFNEVx8ZfhZepYzfUdTtnMWnHgUvhMY/ox6Ie+pH8sHUb0
sQ0QCytXCM0oCsaxJTaBR6tRv7fV2k97fOlRIhV94bbcnlIjx4FEb2KZph9forXQRCzPD/FJzDFm
pY61dKCPtyDi+x50+d2JrWHFxvmWV1/vG2i84NiD4/C8+1kl+XJsM4r3Ur3aFsFEDF/HDBMWA44O
sRylps7qHqpZWVlNSiitH1LM8L5r/lKJQf2MKrH0D8GZ6ndvYvPhIsGxY3/pyJ+NuZQf+DuqgVP6
b09x0RHguy3vppSI/rcNuWq4g8LNMyONO+hpJY+eVRBL6UKHSCYA9IHt+26JKzUP3Qg99QqDAL4l
zbr6AzShsSHZK8YHCOpGRUfbsm7LbA070UIJvSR8y9LG5X7eRePulX4I8qEqCORgen4445ziGt9x
LVX+8ZekplyMJ53avpqAllRsl7BMJGGuZ7IXGgwKKxni1W6zvFYX1mEFZM9QZLKRdrF4uf47W0LH
vgJr3eAzZD9GhfNcLgpwBzDIj+mddXwNakHkVzII5pQXy2imCFuD9sJh1yjFrVHzLa+swbtqhdUI
bB2qsqwOs85w2/N+iDhsnu6piBYru5wmBsF+SP7JT+9iROIPttbKnPpMNE+hmlwgTiL0iPcuHy+N
71gXfh3lHqDGXMu/41kpPiYzs/tuQP4AehbCxwgrxsBb5brgswfv9qc2fS1xDfkC2TwcmnTuXUJk
cvL2BzCugz/hXpTSH8FMbcBHOThNma3UIP773ZR+Pd0Vro+PPbzlG6JY/GckKHOheWaQKkG0b5CA
pM/2DuMM3R8g6ebPBl95kyuLLx0d1Ar9gzKRuXW=