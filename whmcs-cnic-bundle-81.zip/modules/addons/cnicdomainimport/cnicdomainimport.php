<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwrfsu8ryZ+rmA1EeROV4Nob5l77RKsdtj6qJRA8retJxnCvRRoCJKSBI3bLxRqbJOxn5MMC
GmyUWb0J2mYjtxMjJ/2xXNWPTBqEVeFF0woEt0GKq2d8WYl4cm6ybHHAdW/ugk/NNS8jOVLa/yue
1Y1WKGcoPTsy/WSVcZ+rwwbpdWimfRmVywnJqcx2kl1eWigyM3YrK8QAaK4VrrUsRiHbzDpo4wI1
OUEJQHGZWm9R7ZyZ4dyFK3imc/9QglaAYmemAR+OfAfzjPoo9LdiX0FZ6Ge8Pd4cfy5AoLbdDvIK
jWle0Y8wSRQFiRiH9gAQJEI8KBDMQ5bvKmrsQ/YG7uD0RAZjQcVpWkqnml+Si+lXpFIuOA+OvLng
czBKxFZ4f1mIoC8aW9zDLlwuDI2LrqVMsLsejiavu7tJHKNZwUtQdo8EfOisK41LA9WUT70jdh2B
d5hljJFD712iazjY9pErGvN9aA8fCVuiCp9+XPMfFe/KBXSSN0lX2Gs0TeqeTeQe625J4Ds3HVwJ
aESBjg6EdiDXpMfKpT2brX8CE816wT9Zpw9Oko6G8zYzeoiNaItc5vKtgMpOIGXlBaa7RrzEbWdV
RwQQe5NEcbXDaLub6OwrH3ALQC8BbECOaNt/u2qwn+Z8vk/QAxLSvCRaOfAzh0v4pE0H+Tl8CP3y
VmveDUKDrK4hculDa/F7B0vPWFjfaYRJnQBvGKDuWgZOpeTzNHRnJM02etcgORHyhZJVa5ba/7iv
6YtyJ2F2rKf80TvTsRtPl792SOM1diLQKFaYn65DRI9o1CJvmLEAXkWA+kmgn3xBPNXiQyK+GWiA
IFdQA0s1AJA7BgWJHGyMxPYWW50lD7W7Ota6JiUyixhf5LvEHLojod3h/XInKOSfWEnuDaADTWYU
76CR2YP5p+IGdNCg/CXu6bngn4qZpncE3aFdP9ImrQWQpEwKtU690PpvTnee9UwNLF6mL9hITEOU
UIfGXzx6UMRkwTqJRHKeyOMPqSm9g2KxA1Ts2UqoyT87MV/jQtGt7nUqiHixnTucp95hxkUy8vMT
JDPGZp0t3jhyp2iZO5Dpo7f8rnXWGE0gSwSTptYAEjdXAD+4tl8H1P1d0EVoIbulVzuAFa2srzrS
M5uEmyCwdwx7l4HdWMSdX7zV4UueAMLGfRCdptTx5Z8WEu9e1vVN8Rhvecf0qTPzWGOEkmjCWoCF
gb8xR6k5HDy89eEHqNpKyH3P89aA7WNr64NbHTnytnZhDDRxLY8eD/1jop4tliL+aQJKhHttk96p
B92+9fSX87SNjbaerMsy0CL317n3M5zhX8QAbKI+Pz06I5BxOuBhrhtz4llXLsK1MXutyB2xhtUZ
rAIc7dfPix6XrybEqPYzXUVKwg20Urov63/bAabfORsS1zrj+1p7oXGI8T+i0/e4zWH41JhG8QhE
4bmHLwuwMT5gvLdp1+CLQpbedeY+Q5I0kCskNuzhGy2rWfSVTvcDIO710rX7nDqI6WyGNwXKZSDX
GuFN84Bi/nsBeTn7B/gXkTW4QfTFJFol1zJhklpOKFagmg71KEE/0h/wvIvMRFmwFahMC8Qk50Tb
IcCOjaOmPN2fGqTv3AYCqoLDwApsV1TGGwHHb1lt7DUTcifBW7tkpOm7ZYymhcPIrTVlaSFD/zm3
8Qq5LlrplRHwpXkXHBKThJl3CG92A+DwgedqnQr8UUDSSScIvnS1wtYQZslhayfb8NbwAzQ84wwr
3CkegBEHH4k2vHtJqvQ0m4vn/S6KSyGCshuMND1hNLqOdLVqyDhutO+gS1qRsUoFcJyRlO9qrIuG
OC97wAdCs8XCQVGiDzwlLpMV2yz/sxuDQH4hN4MRyrHzxYstakHy4v7gS5vXxcA2klaxenN1mHie
tuyl1rU1w1lSXyC67236FJOdtkZvbQSqfIR6i7SNDw2O/dLuiPHHlpbuALelK/2B0DNM488Z8SQK
9qCV+YGEygjyU/ATr3zZkQCTwJthA9aYe1pXyyuKMclsRgzrT2hjTNkVn4ImaiwLgKWxX5QDTkHG
kWTYBrUAHb5ndsCslOnR98ExAgHLozSABhvzCQE3EdviZihxoZyItrpnTxBwOWKlsjvyslGeV1pU
E0nrgMpTDGWd3f5oVdEkgSeb3ZS3KgyWvx0qf1btZg1WEADcwPaVfxSQg1/DWVloaG3EdTACZ81h
5wcdlbvdkvATg5AmmOzj3qW0QC89d2AJbe8HSVzuxM7ZxQTjyoBA+K7V97TdTqNWJ3Gn57OxXmsG
Czfqr0fg81ST0aTVuqNQ4BcedREc069O4vs5jXyd4cgVViIVRi47KuXr3RJcVKbG9BidwAZPeIg/
e1XliRg6++kvkUq0svIADrcbYCnkVVXHQpxYDXakzvUHzaPLUAC8x2ww4JCoJ1qarUVvdHulbhz8
vQtJyWuWVYs0jn/8ACG55+WIKX+JpJf4aXTBZZtMZjfFbw6rMbAOOkiBs6+pBsC7hGkeGWkAVaFo
DU/03SwsVBmegt6URFSdtaX+wACH7dnVY72MglAubKs+mEyu25cmNAIZMisyJPKu4HrYojN/14o7
dz5cVPyNczAdjw093HR02QOY534FXNSm5vDEqJzpg5ry4xzGW2l753Dhu6cPdHd20nVCvUsCnjh3
cLtc/OR1LyiXP200X93nbkaqGr0QCXZU5yTV9IdAskCoaaYQSLApErraJHk49wGoQvNd3f/LO37L
ZOvTCafYfUZVfJxfeo3LZNqQ1wQbAHJkMfeps30b/OjFyA4njTJNsmBMcoGDwl+maWrYmTTKdI8g
p44tzXXh2BcHG2W2bjNd95oHTS3bXbVdo1XvWqesLKuxkNhr434d/fXWIHYGaiKC/nCvjBJRuWUA
0SpAuaRZvMfMZ1PQEUd58tVRNgXpY3KPQ9n+yq0O6/xEkXhzfn0f9UVcZ1TCYCQcXE+4itcLY1HE
kSs/p8dEqmq3Ob4jNL4IJQSKJsq7mkwOyQKR4eWRdk9vjebwDA3cKyYxpo8zGoFF9rlUIbv1yU6T
KXM+Hlz6erMSvPcgL1atS1xg7NpbPj0I0cy+pSx80DlXv3h/1YCn4ba83Y/wYXsyTso+HzJTWmIC
ByQzzoRknKznzFOiq8aG+TdYytlmasUoRKVD09/CXseqAWknMOHF28y/c0HcuAohMyk6jY2PAoGN
+G0Ql/Ab2horjSnLQrcSDvwIEsL8INKClWW4pyFCBCqSoLA/mhUUdnDmHW1Rn/RUXjFn5oKpitgp
sxIGUgpnlrW8X1RodTv9LmAhsMKPTKR8Tg/TwTd0pXI/m4TYhiTw5RQX7qcUYJHyS+bYvOXI/y4E
MMNYKq1Brt1bQBRSw4isRLngXC3DYCTep24LPLF+zXfvRNYfhg9U2ytNw+OHCXxZyczrqBWZNoa5
KipzYk/N8Tv6GEHL0oYQI0cKOsmI40wGEs5oeOJUpNk93r0J1+WEHiIpux72nPUezBeM6cDX741n
00X4hJjHtBRIig8Pfo4kBZRmjHzLDtFNLCo/vvIDYXiI07hyWWcuJEgzq9c5OIpSmCKBCzOTIarS
tGTpGglr3EISrDws8orfGEvxxEIuK+neML0akR11BS+QR6oxI/aB+PSHcItAWnI1Kt5PJUiS6mSh
H5urnPJl4leky+daHV3ETrGrmD1b1bmd7JM7YFJnVrr/XardMuBGHUWzSEQNnJir7EpxMyrEslgP
Q6Y1aaaWV2AC5hs3E0NIZue//8MLmRVb5+DuD2F8yxCn/QDfAyDduVEXedjFa8WqUxwVJPIAP+sp
T8rcKLHltYV/0cVkV28haMeFHIGdG26is7MUAd5140erFUkn/nTxdRBtOfzzj7Sb9tocLD6aSltm
Slo/28nz7B2lB5kawNeJEzmTDo8ffHzuMObLgw2KkTEO+AZ4EQ3RdDuS6eUZ+rgtXI0qQz1Msa9B
nYY6p4ZscMdeGYGZ0BrCepwkOFEr2lV/IkAvjp1C/0/HSGo13xTvVvDzvA28pkdya97FDHPkoiWd
JndFoUlhWOexjNeNNmfmusCoUn9u7+efQ5NyOOIZhm0bHylm2eTR2HqYBMDPuVkRFVxWbPeWs5O9
MNUxk9yd9iqCbpfWI3XM5usKpmzyV8UIswV5E4XF23V0bu9pkE0elPDThHvsHHEosFzNtk2D9i7p
9FZLI+67aztqbTlVY7T/VA92bJd61h+uDq7P1zR+b8Tygaxc7khA7EJ049YOuWXi+uI2Uol5hcY8
MSHTpTMrKThzhfVfX4k7DUTZrzqF+tn27QnoUe+aGlypRrCQdQmaTnPO/uV3gBTk8PjFU3RWx7xz
tZyoxcYxc3/xhFlLTUjhl/cRTjALVXt6SRxx2OzFRXF8kE0oafKSRfr8Y2iI7gPRjHRXqjI0zUPr
N2YT49C8YCEjvHVLxStE4ZRzuh8P01DC