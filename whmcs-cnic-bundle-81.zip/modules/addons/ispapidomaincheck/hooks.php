<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuDPDo6a2OmMiPMY0eOdiHpT4oNk+RdJyFGn+3hsPm5s8miStkfd0oKxbzKnZDFui/JoP9E4
wZQ+15AJgRcaLqluGKEbHnUcUx5inSo28wA7xBfjHPyvHnL97bjzaF9tLTzPQJ/A4tcqu9ngRsbG
s27ABMAyFfLQE+9Y5RSryyU6yA0cGv4DIwYCtfTqt8L19Rjk5sztLBKU0JCgeNM+H6ZBXv4dzkrH
if09r8QNo3PDO20PWkJEHcI3+tTUnAJ9mtu2Hoc/cAIgVRMSiYLPxAC3unaAjMSg8jq4MFVISwWA
HDOUXqV/+hRv9hKwbzNnpYmVtOByDGTIWf6ted0mVzu8VFux328AqIWgtoJoLJym8DnTfrxwT5YP
AqdWj+s+OANOvxbCfJgLHgK27KELf1V1lngjIQj1A8mxqiENrdKRNXFUj7njyS6VDdcxomYhiCRY
UEuhsRVT/+BTM66L+p7s845imJHFLcJV/CWTzUroIwwFjbEc6gt00Ej5vRZtfmNJBhwPRuLz2+XX
49gncrygd75uONAve4SWXoIKQnME+fA8DXpoj/p7Ug9gcBRJ0yCnz7yLVBiepo+Xpmu08F1pMam9
Q3LKIbKkrQSZaicxdZX4E7mrL76Lza+EKWuZXUZiHuMOCl+pNkAgs3M5nwr6K41au0VE72mBSrla
0RfG8OCQiGWEHI8KIqCaV/kSdTQqedt8QAR3bfx92RMSp3ltpye9so0SYFOi+Rw21TlRGno4gJ2f
UQJjcn9juynpqSEFrKTgT/62l2RDs1XLmpNvn0ov6L9qcXC0Qpiacplm9IrxeGGpXtKJRG22vVJ3
+5LOmKQtXd2wPy+BIYDgodV4r+FCSlVnxfoC04J5un6Lkgcsd2CYhqCHl1VGwHvSp6zm7ZOCne0U
fCCd9yTV9by9yV/Cblx8f0LYAoTRcaCEgJVYQ7RoCp6TtFu96Qwl/+ancercSAkt/x2dQi8QzRyF
4W/mLmDK/o9/vT3VDokaXE7j0fdIa2JLeYAiqeuBDIHpOTNNoPic6i7DHeGZ+8/lknLWhtRPCFVh
ygzXFgkFQ5+SXYkxYW9W18EMYrtKmEqSHloaWWBtm7H6xlhNtBG3E71SOp0Tiu5kFSj5ALG1FUiD
Z7UEDpurxOfZu8biukCLo0dn1TfZZXykM2rCB4CNOn9aCv7AbXrjDaZ9pXVnOlWx0xJNWk0SkDwO
OTgkEmqhsFu1ZQKV2VXEHpNS4bVKy8VroN43prC4YXkjAa7bnbCLP65n1t8ZsIQztJ1PTabfNfPt
s1j6E34OL0PHjZEL08U5XwWDzJUUvGeGgiJsgCp3UyEHknmFrY72QED56cssHcJoyROddDrJxmY9
sKGCdYjHQgpFDqf+SKJDCxJnRLQIbbbRPxFnUuBc5m5ML0ltt0ZyPl8L5jGb9YQUZ0RROwhW39Dr
ODAkIxtz7MMroQFVmXWKhjTRc5CabDeMtKW4hka5poqQ/WrPHdFcdF8XnQew5shDS0bzBlAlurTY
RKAYrUOPxs2EogXsUQ8gi6p9DJ/SMoGqnBmKTtNh1UqpEnIayUf1P5lPMnB/1PmMf6/02zAG62QK
ToWscccIMIAkSEiVHt8n1YbUOYyolDXcf6f1WeoTgmxxZTMvkrZ902SxrStGJPHnybbSW5Gk2lqw
BcE8SypsV5vlV950unxuY6ebewuFunZfUtLfhM7s5waga695+TIpTZLJSaf8LN7r7X3w9pYaldms
o9VCGqWXax9jckez5oGvg4AUKylIVC1U4t11DtrJceiSEGFEBnBx8EDMfC2RH6NU6Po6txv9JKOU
0kg6tx+/+trS0lQbhTR3vgWoNNbCzHI1hT4iPCBopqLwT/a4+iZXbWYFdCPJRGfwHm04syAAMfWn
j4Dlw0USNbB4yTS25qcMVjtvj+waeS2wsjfdaBIGhaeZHKbrHMzLLsEPnfci2zJSyzAK8papBaqk
qZByRcGM8mO0Ba9a6f9njaNz98Gcj9N9EWM4kZMRqz/v/WHltcVmNjShCZNNGN1pAWtvsRX63cLO
YTreboCLwlMr0GklC+VMdZTChvxsNmM9UGzp5TPNWMGaL1cAYrHy3uQzhRBwA1X7mRASBvqRt9pm
2OYHIeu53xCuAYXsQhg7fzWYmMzWsR6gl4x064bOzujR3sksPqtlUXIPvucB2TLep/AZZ/qWsjhu
Q+NGUVMbHTTKcZgxKcOoxoop9yc6o9IZekP0M6/adc55wsP3b8rEnBWqsEzMn3rZC2SDhw3JP73B
KxJkK2Mz45WD3Gt1xqt2Yrw/+YcW0WMvYI8FCyNhRpifaRDG1b33yM5Avtvv1oN/VHO0xtQ8vJWC
4GGW44U2GTil71mZJNuH9WzIbQZ1Btp/6uJJi1PfO0U1S1zSByzjmoK1B0/gsqee8BBslpCPS2m7
imy/9VuTc0CpARJpsK8592fsEJhHaq6SES0VC5+vO5zB3PXjnMDuclUzkNQ+elP8/FHlVM654WUU
ChILioLqiqyBSb5vx9OwotAaVN9anfgs9H19MqFlsa1ZBlzZ/u8v7FOU9HGSKZlTc8UYqrQZWw4z
rJAR9mzYrPRnBPO0WnM5j1NMHET7MGoUhe13GD5hyiX60EY8u8QQ3kAyE865T3tNdSvkRL2jQHaQ
EUeKTUHvbDxltOF2PMSoYIGJI3MgwYSDM46e3Qlaek/7M5UDYmur6kxfjcFZWLp3EwXeQIl1ydsq
b/6qIpFKMqG9V3yzVrmQ6bAZqEx7R7j3gJNNd0kdXWTK5WPy7ZAaYRHT1yAQYakOPoUlU8abmW==