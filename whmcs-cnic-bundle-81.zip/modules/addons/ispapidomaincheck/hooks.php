<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqY+A5TXB96OV7AzTCMh1ZkKrzgU3UpoMgku86DZv9M8VVjVVIzdQhyYR+A2roBBnFDB+m53
9/xmbp0b3jkHDENXN7kC7Q6/sRmMbKFvjezyH3qnqHG+DTNnnjfTc/kSHLjQycJHt2wmHsBVN/sH
D1IsP5gl+TUupOmvb/JAhBYJvCPEyxv8AYVVCRowaUQo95pXMukSPY60QDEf/jqXcwGZfeNPjXOn
JPRCIYowsp4/ko8MJPSS3KXvymmq8Zyn+mSMc2DU+PB9f2DackmX/QjbcXbjRT2I2NeYutjzkNYm
LSW+W5+Bcha/xe4VmWTfJWHN+WLSnfQoKOp5n1WkgCNH2M7GCeI8c4jtKz56GZq8OwWxG7+a6vks
kuaAi63cQEc22H8MlFTZnIaHZHsKy2HXyzfvoQB2bWG10LHdo0I78ztviFAPsBaVn7ukGdFe2CTR
EDtLNe+7TWiZv/2ODXIDX5ludYCZVYa/Hp+GKQY/PotZVONNanswv+Y6T13w1buE5JMayHYdX7PB
Pbwdj6pYiqyJVknLz2xRmn7y6EFSd6NomA8R838pymEghwS5PhObkTVh9hRud525HmiUQDTYtuH5
C2HkH6As9IFZLHUDBbCSV2MuOOB5nFv25bc2kzNjXt1Jtth//Qg6fCo+Ayhuw8rJJCbLVl26NwlF
apIj0h6N5/igLlZWT1m9cQMbgqlN6dnavqXZoc0lY7yYsCBGPLgpp2sNpHVrMVVhY5KhPsRI0tQn
P6WcJG5VD7FOL7vOCV1hstpSHq340LFxAsaKFTQ6Nn5//kFGVpDYmwQF7asysAA+x2A1SAhON1Rt
TI1fQqAUVfbZFhjN/6urS6FgnzF16XCJkDfVoVA/9jT2pzTgzmLRIUybFpEBsyLDRp5PkghAiAUn
hGnqIdKiEaLT1Ld+N6Ap5RrE4sEvdGqI6jIOKszmtH4OazouzHiVpfsYl9ex5dhReP9s5xzMh/ce
r3OVvbdJ6V+A3GavIwd7l9bEjVBbnnNCWXKOoC0TtUZ/VNwiHL330pARC4Zg9FWWbnL3u4CKtH0V
kUl6+Qfqc9WkjGYrauXPtQBWl0Ffh2nmfJs25FyMKj7shuppDkGRzoPRfnouOccDPQam55hHYDzB
EXRK51lo3C2wDEUB8Bcx3IcTb2EXvxQAP6x6+O/sViRhV/jp4NTikM1lyYMJT2pCN2VC/f4dV1Fq
2aFf3/ebLVTvTfPHkv/wjLsJV6gqVz40oer47lHzSatQ3GuJSzB5r7gBp6h3pi+jJCYJPtE4PT19
FU1WRRZLjULRz5A50XmVV640QWDQi/jU3pBBQlTqeV1PK2KJ//0wZwp1X3ZmYFY34o68v1UFv9Z0
DUGVBZKeum/oy73UcTTU/9mg3WO8UXNCsoq/heQU7fY6u8Iz6lPr9OqAu8EovhlxJpBbbcg76+mq
rTiTOKqz2YTj4/toTWL9E6DeP6ruvOEAKKYP2N4NYtEa9dAMgMSSbWF6FePI6nJZsdBBoQvb6Qs0
w/6uHIARyxTGdBGCUGlpPVx7VqOaCsjy5/AvcJ8PgodpZDvh4K/EYVNS2eC7C3DtEdee/w6XdRRu
JQznlyFYlTkeLp5xxrUZAePlM5NaMMvQiUaOUFO3hGau38mgm0FK2bbVL7B/1PdXE+IWZ9kVm/c6
/hSN3gervMiESsysubV940G2ebuliiQBtNTjLajNm5d6AzF9kQUwpMnppipGHwXYvvDw9I0/RrXX
hRJFPxFusf0hPG5UTba03NVs2iOEUGr9LJVzcr0I/wX1x41Ap8/UbZN1timO6LfEQ6QnNhRT7yuC
giEVxwE7NGD0ZCa/lyy5wWtu47aPzfUT2qd4Xxk2ND4WV9klsgFV5/P59GpChOmCHDNaazAV2tbN
cZ7YhGdzCNTHfNvDAr5HXTxsIwTvKzyKaUSqjrdbXX6i4zsfDwVq1wzfYwqFE2+jX4AJxZAwPNce
PF5aUiFhFbZST4Pa+PpT7WGuzzCrnktZq6oCPlj+NBAYXIA4k04Mchrg/e7ISaZa769ErLSY3XI5
xWkrB2r+HHOqIIu869lrzef44YqSkJRI5ApjzkP95QVo27fz5X+z+RNj1HoymnwU5tdBhMGfBk6P
wx/nckYIA5HsYUgmfYcafTynAnFcbC7+fE6mE4fH8T9Qklk09bEZNKHcSRy5+V+Lf0UKNylFkkHY
AB/txj8YTsBdsT7WG+VaSfq7Fq2a+bVQm/8EHp8F2wwYvESizAkdWcy07XYmyD+sxALkeGMcHazC
sNS9eOfu4hY3dgq65fIY7J/aJtKioi1EZRrL2CiiAzodvhuV7qStB33HMvL2vKX9L+6slvGWnysu
op2bKFuW+JJYJqmdG5ArRXdl855LFLSU/nFgVWEkdh/YeAPt1vQQliLBLsjyCj2Bg5jpfl1DXV8Q
MVkJJhyseh5DRNb1feIxl/xk4AnC8Wy5YGjDqBJQsD8Uh4AtfgKa56020b7jA8uUhaQrvvKKCNaL
csW6TwyKmDrJ1oabTg3MZrhJXAmX42wZcXaFVM40UlRoyVRcxK0kdT/wqbpiDcvKVAgOa72Kne1y
UcAIiKZEnoL2AbUrGLevXxlp52S1qofUWlMQExLGNOFabA0Xw7BWgd+QbtSA0RihmVK2N9C8fiyl
frt/7nWs5KpkYXVHnZ3UMw9CtYy6+ZzDWiM+CSXX4fCAKAzT96flDK8+Uw5wQUzQ7pt/d3WpsQHF
pUywCOQZGFrDKo+R6nVgPX0MuRmZKSccApdqwykKdVAGW8RDGwYkE42PKZZCxpMml6IW5Xe=