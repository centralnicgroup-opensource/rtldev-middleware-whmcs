<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzihg4wUzH1XPvWzRO5xtV6agWoZOy7RLusu/zpC2WLZ7yET8sefvnH/kNGB3Ka0PotB8uZI
U6+hlc1KwtHJgrz4cGICMvqgJ3VMy1AbSXyt/awPnIm95sZwUEsIsl2PRgtH3XdNWqhSkLCw1Er/
sH2rthnqnW9RoBZ1REgf6q5qTW129QSMSBnaG5G73wNb4CmUMMVcNZ7nOk/DFgcG4yllftDsaZK0
lIqc76pTNDwL2cDomlpgI9yNUVxwHQ9uoxRU8ahMLKiSqv6iQhdJ6vILlNDdiGp4siZmTacSkDYc
hmSs/xsdvmpw2iK4pebR3Xqx6smGH0jhAB+AzPkhsBaO4NWJFNetFVzfxx3vh9mPtkieoIp2e/s0
ggb4RQNLVwOhr+oPaWoGqF8zqNZfbQsRB2fGXQ+dtHLO96j5fI9i2k339l2u29tRJermxxknXX40
GhTjquMXzEJGTyf7NH4rvb88LxZcQ60wZWkDbj4GPoOrDROMtvJRKS+Cpqrt/FloxYDSQIO8MKec
LEYJVvPOXxXD51ZQMOJwe4lY0HV4QL+csMycuC7hamYZeM4HGVBLB/Z1/89QT+cFHcfJqI0j3WEU
YsRUVXN2tixs3+4RfkNx6yrmheWrvOgsSBwgpXIRPNLS16yGgWkWquvZ9DWVtVN4oZAHNUxe7PAn
JuSTs/rV1veox4ISRxiuGy+vsYpcEM0JzdAQWFhjxQ+9LEGD9ytlVBFUvX+wdozxIEcluL0BBynu
3cCADrdHVxvzrJ+LWqYYurlFRrCIn2s8MNvwRt5V9FxlGdzNijEZP07XlV84CpOXehcNKMyiVD+D
VBdfpycnwWdA3qHw83b0+Q/slYPXcwUrn4uXygOLH7k+/7YS9+vKrcSLAASdSASpvPr/RKA0FdbR
WFCPuGvT0HIFLygxDN6eRsFkjJ5CGhXuanmLkL4pDWVxx+MX5GRaVZYziagyv1E/osyKl4f+tGxm
vG7t+TN2Q+VNOQMJIgSavzYWHWmrw7mSV8cOTaYbeHWgpmXEvTWhUYS0SejnJbVFWpWK5Fer4e+i
ErDRgDWz1uqnvVOJZvFt+Jjwdv5QWSqHRKWefDa/0WWEMtBnUVej1fAojFdJmAiLsDOXc3dzpspr
adV60hqTcgCMx8y+VNWE/VtShvzgwpNCRX8PP6zgNb79RzJ4gBuHZg2vz822JVu5CCokiZ1+nx4G
UxmfdIgkXHU4I+3YK6sCxOL5tgCh/hLq9aBJVOBlJhjrx96XucrkOnTAJ3MPtzz1KeeoHRWRtkBP
Qqr1Onfd68AOGrYB8cGNwX16D41fg4GUKvA7VnHCvKNfs2stRDXTzVhFj0ztg0vlsKPikEmz+b7b
biBcg7dHlXrQpPGV4AOdpfNxHHji+ldlohxz+0lGiJ2cfdeDMSpMFQ4Q19ATlTawK4TUeJOek40u
ByBcdMpSfl5GIamSlpZNG1lDxKz64BcMRpk+NmhaSnW0Xn7YS3+xTfAreSi+NLvTtywrT/2f468b
A/vV3iereeyc7sJ+ZVGsVjh16nN2VB4I9j+fj9z0Yt7nI+nbXj8tNPpRxwgBlP1nz5f3iEpBy3Nh
9WTzUPfiuHldukOfoMOb7wTBmbbYRJOrDpOSXcjppdI3VBQHJo9b3INDpO14w9nAT9pgCc33nGFS
dJql2IPgTO4zmUzWwuaz3Fva1EWo9MG4Yh67/AHhDFKDkHroap3ShOQ5VcSWjvxUpcmWzNn79ZU3
BKfpX4yV1F2AKfFlKEPyzL4GQ/BTnzdcnhD+yv4Eq/n9Ve8Gc7JyvF56tjB9U1P9idVQd7bONbAp
SiV0d0jG5Bc7w13nYraYxHc/9JQspB79T6EIQMb2nWGzBelrGCmjAzxiASN61eUMM2uMGTr2LwT4
g228EZW8R9hRPZIdXVUy3FvZSS4uEuQIJz8zlztvaBINpKKNGi0ceYyRPK/SEiBwc2yMoP42Zq7O
k01g8S0docPRLiBZnlhWja+xn7mLCO5GTbq2y7XzXuMgd2dfQVpFNKza8Z4VRmeUVHsqk1rICt93
1ZLj2NrIHHxqA3CKFlT9Y4eCiP6OPfAHMUmFplfFOThVDRuXGmXZ+ISnLdiIcaaGVz8SlbpS7t4F
H1WWh5GMA1KVHN1dr9os40rD8guMyapfdwZlMucmt/CBCtZS7PTkt4/chEWFiyp7e99HRe2Xnwog
+7krQ0mDyMqXiObV+lZ8jCFXHQtbSjEW+ns/tNLOoTZmGdsQNdaHJQKd19fnRiOPj6zcyDs/ewZ+
ueVT