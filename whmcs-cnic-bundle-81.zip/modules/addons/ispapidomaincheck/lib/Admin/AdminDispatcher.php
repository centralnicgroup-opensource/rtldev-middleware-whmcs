<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+Vlvzy/CDmGnbvo/BYNp84XplHOkRuX2kWEACdSTOnFsCxc1PMh3RoigJ7Z8LcuVJuNXFwD
e3TiYPxwpFF+pxIJ4eDqWM+HpflRQcZYw3etXqHiw4dMVLUEhEI2IltQdOXZwcr9DFY+h15NLAOs
MXAyfSU0C5xOVr+i0ywo8qXWYzyPJQ8Aq9u1y6/wQyAdrvCu2zexbl3Af5Hcnqckj3R49q5W6dT6
TgbFYab4si0gelQom3VLSoKx9WdZY/fGtOQRZ29ArbLB7DEHh6gvqnkKbRq4S7774dTwrM5DfzdO
fg58UF+Ef7KjxUMNsxDmttNDLJWfYSsSEt5bx/1/GNJ6tsw6BdtgzNdwuu7Ipc7u7B/5vtdlX0Du
bKjDKbkGh9jS9fgT1tw42j0CmSOvw6N2sACKFpTlvqYXjPxwv15Jl7gMWwnGzwWpnLbDC7nKgxBr
R+g7EuALb2G28i7e/1FLY2+bWUhwsnDZtp3UxS4R3YKeUcRZwMBUsIQ88IF1JFU8o5hwhUMHDdFL
BweTFWlXLl1QtPpEoa0ZWoMlmcxpi2Sm9hlB1e1svPWCeya28BFs+yHFyMmQB07+H71XNbuK8nqI
HgCqKSc188LGl+RsFyT9MfOKICbmFVah6TWWByyKbYWWSxdv3x5A/4UwIKfoeRfu9EBePyJ1JsNI
sHCOQASOu+QQckss3+lCJpRB+qlw7WmMrFainz2zInbjoWCf+MwzREVsqAC9ENfwiLW+w0iQoCdv
bzWzca7ed/dLig+krP9jmN433uyP2fR/roZhKCIdq4+9bNQ0rdHC+nke6etO2s6E5EOa/ZbWrS7l
45CQeaRXTTiJWonWxItPoO9kywtp4+w/5v55MD/fAj8YsOws4zogdKalU8L2/oGnu4xVHJSb4tN1
I9G49IE2fhL7Go+QG0jKn7nROjGdAfo991OuHO/nxC3xufCC7CpbYeN7VXhZJ/sYctykkuBQY/8R
wv8+Dngm9TU6MvdNVpN/pND0w8TbD5sULZXsfalZI9sGWpdd0JFkE8dx11TZGQrpa2oGhhpsnoLg
LutWKgLKKKwj9E+OT+IPKrWY2Z2Uu2BR0/4gOEynNeO2jL4Rwtl+5n3Ov+kRDJxAS080auzuyZ+G
eTMnnCc65OFH/GBTenrrBnFg14uCAhvekYZ+ZJk4CtGHzIFfETUmzej18sFDpdN/mIcZK0Yedkor
QbZTZq8/Sf9DREka7Qvl9Bf64T1qkuczI1G4niOec3lm9VkKo5nxb4C4CbUNeH0QnIoTOOzhQLhs
fcj52Ja5LP3Kio0ScF/bD1fyuMOXotGs0f6DoZVyCABzxQXgkjtxOUDsElywW91hot5+vjiiVAs3
Z2tP0Haoxh4FbSUlzB27z/5hygkLyTXsKf+6tlyeUl8JOnEVh0LgWDd/WoduUBz6Dd1XJf9NGD8C
ep9p7PnByslxN9vQ0oJSWHyGQh9sN9ClXiDMZMsRelriENaXGi19RaiST7SkSx7jJw15GzLAvRW6
/czTAwzZnfon2ahQ6XsoCh3pevPjRaSR0/pQgawsfag3TKmPI68MuY8+RG3iPHhwI1S+dD16Jj3U
1/jJZiM0hIIEoNskvr/s8BeehTCCWJBK7eusnM8oY6+zAprKk0EeBuxSrKcICMClTINU7wJBAEm/
BZ0XBWuv/IPcdYJO18K4KopTQsXZO+521vTBWdxHbfzYmWSoYesscanGKNju98ZRUiEy5uSAh5sF
G0u5fHHvkOikKxQnDCLQGyXfm8qq1OQNItsv88qoyjcnCVOP9W0QNJFLlVOhJ4K=