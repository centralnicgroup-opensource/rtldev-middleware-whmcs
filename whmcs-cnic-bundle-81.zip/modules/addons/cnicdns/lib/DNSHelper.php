<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuycy77pfiX6YknbKkxMZRtQ01apFKmGOPwuqNH0/MUExVEXPSj+u9Hn6WZdm5WjTZAtAXO/
5T25VKjQmMtZ8g0djp3UixpQo260l/xQ+GNGZjkrMbIYaO6RuTaszsFI+j4IykBCnOw4n8B8Rp1v
jmnhIRTj+Lv1RGr66xoVpKU8qRiCcrKkMKAilgbHWoRrQNLZrjJCncYjPPcksWICjjN/KU9xpHjF
Cy7VpVeJc5CtkkbQ7/ATMO2qDE6WH8Zf8yaPc2DU+PB9f2DackmX/QjbcXHomDzzkFLHSwKORtZm
zOWxh4WXNiMOduVUXv9U2IkXETUlQ/tvxMrrazTq/ZWDNk0qRTGmI3Tm+2JY27LBtrcMEAYvNEO1
9NiLKYrHZ/kXJ5ghQzqXHicSKe5HOVwYK3AvSztu7HUnENF+O6Umk3uhdGlmPCa6fSq+RBG8KLqx
uDXztwC/jxTn01Q2MyacyV/+YfUFx/3kMVy4zR7IO0B5zSt+GrPFbo9h+P1A3DlgC/sSZyCmsRvV
Nn/0CgER+q5IgLDoxt//gUQlGYD6CdQN8jx8+DXnZaf0WMzQcvtgDjuJ/OLqbcry2d575T/SjsDC
49JQSKOBUYCNAqi0aGfFfNLH2bmbtD5okBBkBl3lWRvjvnHEtVDZPGluwwBvqmyFPpJBUGvJ8heT
ydMiVXRW220n3K9AvSEsUEjkesd/CZvJQIaAmkL76lg5qZ/oLSEbDLhEIA5ufNAYjy1VscVvlI4w
bFeBavmsLndja6JjuOjY9ZhXMBkBxSW3Zh4AxRPd6SFgQ2xAFt/1kupHluiEqhhAesRb9ucViqHI
BJCXbTWHZ8sQXImUX+xQu8++PibzDt2QBbinYyL2G70+dNzHEyu7te8QY+WX8U2EPttIwbgMk40w
M3gDvk6c5EcVadmE5zlemn394frmrjPI1CG22nuoVCYXtYzqD8jUIHpJ+Bxr7qyPVGdhNexcm94B
WcFacJB85JlKOBE2HAsJSpPtOquvUzGgF+FkhaGwpH1NJG8gwDmj8hbgZMYtSmoLvB6ufuRv/bkT
ciU1Zb6fgnxDf1sxgirtH4IL+UkFQ/YN4NZXn/sGFbVy2LuTqLn+QO8lNolHaRQBJwFtjRzUNXxR
YWPcMlyA6HwPMxDtdnu+IlBK6NeQnZ2SdjQ3TrMZ291d3N8VsLWFThUhLamKhGiVTjeAiF5ZSuod
+Qtyt6l1m34oh+GMqQB2xeG5Bb6kVL03SEsG4DNtioESxwnkXivHfV2LuahTrQeXEyODi1eTrRvE
kSFhk8USDG/A8yiBdJ8HDR8+U4iMVfYUCNWSqVtZ71I+yc3rljHkTB9sqjr+6pYbQV9N+wDi2feK
Fgoii7DxahI7qdEiSaGTcvuZFghJbZIlpR3FmkxDzU7aKpdFumZIPgsmzlzIvL8IzdT9KIYJug4/
NqPdy8k8sQCqBFbFz5IpvDOn1/r1RLYLlcoNxn3pTaopws54El7Hy/pxQjpW/sVzzJgYfDha1011
00i1DfJFms8NTUACTwFG4Z4/Tw7Nt0bjTaVUuSerZTyT5yoIroC1gqI19eH9Ph5WL7OVAwBsccR8
kuxC6uXLGYCGNgWLesap2E08+vu+A3YM6dmx9POgvR3UawGLLVV//Ry48GP0lSS2RGt48qMOobgX
rKRKIinsu+E5e1h3TLrhDJKF7c8PKYcvnAdbImCV/EoprB6FPDHKm95GGNYsiHH42J30Cnde/+BO
D+sgHyl55LkKigxqlt3ibgNFcxI50Ag/Gn/3qL90WxdoxmZVBLuNBYXPxtu53gyeThJ1+2B6a2me
xuIZU5co5F2gMBN4vo7VGM40FiDCofkCHQ9Bp45LG/nH5EPvwT1FkWMHQv/e2qbZ6XGdKbEoAPAs
ek4NLMab0I7u2MAZUnSb8/Xv4Ifk1rA7Ct1KDYLpJHNaRBhU0GU9zXb56xlddnOunANLAetSb1j9
8ypMFbQEvj1x0UW4DfU9BTgOZhmsTKzf0v6QH7omYWETBx2UgNLC4z8USFMUxEbVhVf/mt9I6bg6
7svoBw5qfIxPOrgxiDxhANCxYx9MBUsN7Hf2FY6tz24YyAg3ycAY009dvdqBgDgy+fwj7JNp5/5M
SQyanBkk3aKU78b0tLGDloDmkGzaQ9I3tjIyiaUyb8YQ/rUakAklZyTHZKCUGUzvbxM7btxDT/cu
sKMSAI2figr9h8YaMEeJRPF28pKG1uUBzonwPvavXxi0S2rSgn3fOfpHkEcfXO8eUJU7+SIISFof
/bKs8EC+vuD241PnHmnBoWhKzplS1BdK4c+5MMlvpQ0B9zS4+4jDtesZh/hANgkl5FgXxStUycKx
CKH1XY7ikrF+CuivNaL6BJPtAFaoSAnHYlYf4nSxBIWKcooyU7VS7j+a1jBRi422nW/9LwRwYFbT
KzipvOT6bOXgn7cO+nf5yx0BMPiFUKUTrQNnArkwNciBiusqqqfYvXpC66UqDvfgDjn7p3egA+7D
lPI2c1pe0FyPtCVK00tJ7ve6OImjOMYGIveVarcJjCxqq7P3bPb1FORbR4ystkD0VfzimqvzHleJ
HJvWz+UGvffqV4zGWalTatFc9SQ2Q4HI9AGvCVWIxj5b451ZE3Wt+qs8D6tiHuURIZ/qRFZ4LOc3
fjk7Tash0XpUBy+7nuqvfdkWougFifqa2qkWGvrgcjEi4fPtDj9vb3TGpEGmDgEFFNgpQ55JhWp/
uDwEWvsa7WBdZW+ZwtFsaEtgr87/nZbCPmrJOvDo2YknRlqw0pwsFVmjdEsdgFg/AVeSmF7OKhre
77m6HnqN6Cz8Ahyz6XNML45uPJI1BW3rURcms/SuzeIAVZZSW5w/r5EBgKTVVrsN1TBt8I6UNcpO
UWxKkxz0svOLRfvXsyaFsvHl/NAp99jTyuovQPHj6uvXjBotlLELA8w/V77LXejrpsoQ4kQzpFUh
KyAxxezDNmUS0VuKW2KPdwD4KmIzQTmwePhgEiVfusEh5u/jOHOSL5diW+EDhV2uUp10i6QJflSz
dWsadGTw6n5mDjDzYpH37WVl6Z+lSo1kznjP0GEvAas8SyqBmwXEJCP1WwAxT/y9A5qHjmvRryZB
Wt2VBIMR1a8m+ZhA+WaGw9r7l5y77KDBYFMhsP2h/KTxIWL/Zr+d6ldfKdGoavHpoqsWvLfZPXAl
OcfrsEcFvt9CXAUcwAy7R7RjKJvunymjKF71hVXiG4BN/3OBhPAf/TDncuKGzl/66Nxs98C8/tCq
KZsz7Hv8RoTTdQog0L7IfS1+ia8EwFWbtw1l+WinaDo9V0+Qg4FtAxNonqV4VaKSMBnB9OqRgDxr
opOjWCseA6dSlzbCtRfetTe3tBFaoZ57lU2Eg6ddAZOhOIjBqNja+RXHIPfMZxJyYdJoX2oFYuvQ
Zm2+gyu8tzbSR4RGRSqXdArE/ymOXMPsGTD4/nBehBA/D8A16gqvHwCXV4TlghaS76xwQnT+bWBk
diN6mtBIESCET3BTnob59RDNI/RQ8HPwb4tvYzkX6I4OCoPbC2lEW/pr0jriHfz5fKA6ZAKGU90Y
JUUFSYjlVgRjoy4Rm1OEddlfsieSUj+1yhhCIdauz1Oc0HYhuqQ52fLoS8NfbFZz14ddlNfiZuON
z+QZVNaIAleFv8EJgd1PdIYTwaZCc6vGfekjgRrpOfEP9hkN0WMSL2Udlex938yhwzo/+XMW5di8
P3IYep+aeXq6J95CdV7mimmmuq8UeuvLfLjo2l5zqdH4QvYBVwfbUttMr5jB7b3yEO/U8HJl84p0
ZvKYlDQ9ATkbzAS3pPGK+0EmoDQs2VrkLA+byP+XHmgam9E5VB674N4ukP/y9sl8XILOoF5/kK9N
BDWffQcYxo2sc8NX1S049feTuf5/Gb80W+QG/uaJ2YUrosUG8ezaNUgv7L4i8HdwFf4lqn1wiqsU
vVA66PgQFsgh9oUUcj9g6kgHVZeeKzGTDrOCkG1mCtIX6TWFnH1VhGrZfQRXYVB+edUocox53vCN
xvorS8h07EHnRGyEsYp4sXX+NiBGrN6ABglQQZW32Gmps0cykgV7OKdbiD8DJ6lFmHrAONmd/CA8
kx4n883dym7K1Cn/9DyQa54i0dXf3n5n6cB3afAtYCJgz1yUWPQlauyD2Etvc/Bt0QH8/s6yzpi2
Br1SZjAEO+f5amfCXVSXleJbODZ+lI1pvgJ/IB6381eCW7J15RlXnjE5isFzCYO88ti4W643vKcr
dYmJrGvsKIGr+JgX0tJfmK3iKqj6SnKf7xNZgHBrhFqidr9ZchtAI2rlh1Of8EQZyRDVIizF5u5E
MCNF5KclYMNmUSS53KXlxf3Hr88U21Vdxfifat1aoxhZuzum98eGvyOu2AJVBGrNyThv6vhk2NSt
fd9I6T23R6tMaSusImikWdidGRdImrSUiEuDJNGZFQr0DLNGQ+t/VHej/LwiPr7XdWxH9QH1/vAT
IpePpXW2bbT9gn0PrZMQDsEyUBwUZrVJyF6zXtAccYRPZyFmAJP5xciE46ZneK6T+B9FSVDCFdGL
Luf6lD5hzHDZWJMQZsjv15dE7x7rZqNqkecxZ8oD6mV+hJqcBXpO+9TFsA/XXnZ5AiwGBo/lsE6u
dGsUGaPwRMTXav4QCn5VBj5gxQWUNKpIDqscAFcWww9l/Htha1skOFK8knNEcWMvWhcJrjAW7D4L
Sapj/X3KmFvuUV/RaObLS7p8ZB/jjVcZW5FPfbUlY/SOzEKt5kGrY6Js8jDGEgKpsuCrlU7AKQuT
GvbgAqp2fwIpOsZwpWk6z+x+xFYYg3ZnA2S30Vj7jCMWA+C=