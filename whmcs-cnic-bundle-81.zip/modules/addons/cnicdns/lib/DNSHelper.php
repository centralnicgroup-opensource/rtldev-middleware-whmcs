<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoeXlBr4fmIo4UifdXBeH1nS6URobLFamk5izgajrnOW2S34t7Tm8fXHVXMn0kffVfggJ92Z
/wttPf4qAJKKRC+h9zY327y/pl4+P/E/fd6JlpOTe21UTKTxjWe8C7WzD/xttqirOT3Yhsx2yceD
I7rPwjRJ+MwyG//zBPTuZhUony6hCOU8h4k4Hl1TkPMd26LZENUnkFcdD9/3QIr9aYXhLkqqBOys
4TYD9oESP1IaGbd63gMAIYv0woCpLIgzgHCSEYV2MYo+k+bf68TSJ+ElcGzKPW1HareYK11mWSb5
re28G/zwLH5jkz3e5Nid1fLx5z/XNXUIr1l3N9KHEtFCdsx7W+kbbO7Y/mVB9IQtpEmulO7Lmbvy
d8Qx9lJxrSQAL0Q96jmsj2BT8HAeVyatpcweHwGtIaIWRRWYd+CMk55bqHRpRoPW0Ar11io2XkrF
omdYn5dkUDtKJzInmpZ4B2DXoxMXPmKFO0INCyAMBQvcYtwmI3QepBwGxCGB2FVWz+HEBWoYbrNo
CvL7vTprMZzo3MRaKP7g8F8uDe8GJqod6DJ2aVN8MyzvqqBqBDK/Wm/jy7dIEIC96UxDkPhuJr+0
/+ISc+tmKJuPlHAtH9aM8V/rdCh0FkXpV46uDPR3QxiYYplmM2Pw0JcYMjSu91fD807O/5852tCF
UkdLpW5zWVVcB1qDC1prwXzvce3Dz1DSDFk3vxrAhr2UWHm1hjFtcLbWgqc0eZiojhtQJzzi7H30
XRuvJq4YKhr53aX4SmD2nmpkYq5wCMm14XaC4LDYVDeHFkHvbgxj7CSkFqMlPcU5qWJeGsxIwlR5
Rq62bKrpvhXA6FW8Bud6AeDvpvImsrAM1F2UvRxSEKjRsvOHQpYYiO1K4I0TPriNf0HZfaVAhvKm
9ULBSZ0NdQSuRrBbEAb66VGW9dr92BgHAcMLkNdKBj/5UV/l3ua9+Ko9gnDkkCv/IvRR4yvQ6rZb
zROgUr+ySYmbWAq6p9ItsAu1emcOTjozH+ml6ZUEglR1CiE7XwfV78TsiscYHuncRzdpKE6uEetq
1iIy579bL9drOQzuA6eiUkOu+fZQ+hBBz0FW+vgnCfxhFmvGWRyOPcDURK9L6tS/7LVsjehIhWVg
Rl9qFrFBgLxAwOahb1ZdhZ/paNeFsgpDA4MnCz+rz66WxlsPWZWh8BImIZ/ztG6NTjVItbt2Pt2W
werwnKrHNQlkefw1W6zQZjKu8mxFMw9j/NEtCktrTHYOUKYBxCcbq7BwK/tfzMLpEbf9bPbShuHX
OyGCMolSESGRg07FsM1MvmR7jybWIHDPLeBboB46WvpGyrR+e2xPQeMxbly8F+FU0IYo7fHOVoCj
qUBFWeqUNQcuS8sLYV7IG8zqE73Gi5Gsl4NUQ1VdmMEYSMpNS7hZl+7djtF/AKueAZuPrn2b8Sho
PLILT0yA2sE1Yi3SPoF6JuzL7Gzue5Fj4yIPWB0LPP+5pPRQoSund5LieFcut6EkzpwXvk4xzTKm
qHBWYgSh3zUw7pDpwD20EwxpqAlIwOlgJJ3jfNwl7h+s5n5Q4QT+uqyguOme+ASrMCd9abnHGRCr
neeB70ns+/wHccqLSm2pKA6DL3GFm1U65uHO3uRtlOQXEHAYb7SR2VjXXyGmgVQ5Jvj1VXwaj4xI
1ODs9ReeZ6Bwk+Z3v3qPG2Q87wiXGS4N8wS187PmRigN+OJOFIqoCitcucYWw5dLVIOtPswng+xx
wSKnWQSz7ljs5wC9f0oRYiZmMNmem5W58W9WrWByJGFxhJ9GhfrJBB+FlQ6oGiSAQmNjLFrJLxqx
XIeM4ys9MfJSa8+DkXr1HilFr6CYTGRQNMOicfM6tJ7wMABPU/7HXVSnTUZddPrYZL5BoxpSGIp0
IiRfaHEym6cVZcMa5+zNlm0pFWuIwYQg3TGcW/frOeZ8ry/B3yS48htRLYEzu7xhTtjqQE3I1UUv
1p/g0VeUWP77SszCB+g5WYEZEMRby5g9I9vqu7wNwa0KD55vyFazr5ui3tu8q8fcFwAdDNrDBjpX
1rW2MoV/L/b10H2HPGqEg962qT7wCdLSzM7kzSCODx6P3kQl/9sV3IUTjSAj8HkdR95SeoEnIuib
pzYoKa1BI6BknLbt1TDYu40ptSHDyxO4ZnI17/pv5MArEJbxj1fEh+Wdxz5yqPNE1UaevfBpURvI
BsgxdESehD2j/08lYNyHPsis6km/KxgsU85oTEujArYXXnVZmZxdEpvBs3jVRU3ybK0VgYJdwLRU
jbp5cv/iHJ01Ld+zlzLV7ke+Zu+pQQUNRE/TFgwUG71+38x4tlkukgkao88YTSQO11OTxVJVY4u4
d+K/o0Z+Z91kOvtyPafCK4UOY2lx+OzsMVBk+RkWpsKUAsFOANKE3qOg5uloOF6tGDccoLUacVT1
j8k3ETL7yOZoI1iJ5q+RTPV+qfcwnBViLSAdgMBwrJtuXUiFe6T5OzuDNwqS9y+KDMLIynq/qene
R87WerxlYHNu6KhJOxVrR7o4eyQB77KcyxxmAKy8JogtfBOcelet5hXJkHwg07rYHFfnWechm739
28CoZjEL+J82Ht+ISbPnRmetPTXPeb5sMzc8e2Hl5t4eYlm1d4/iRTfYA7Bej1KJwvFMz0TEqVfO
tluIOcObG13jdGY1kYfX0vCcLEYKkPB5p3YMlOaOVf5TuT3Lhd1IN89OoUeQCbFC7OBUjXjBg5V5
DiNVt4GdJpBVy1VPfWr8/oViWnJIhqLL+FvIN+iiIMxcx/RsuMLHsGf7oCebNiY+wSMCB3S9ChKa
8aN6xElkYc93O0/bXHWxV51eVb746Tg6jqhTj06QOW1fWHyCUO2DIT1q5p0CXJLMkT7lvW0M4/da
hoyqVKY4ubJYAcwCML0glEXTLQkmPnvztTekaX0FmV0ThQuel8FvYkaBi/muyfW8+hAzMgHWeAXf
1+rjgFnWwgQ7oECLKnSsOIJn/OsSpN/dOj1SiflcquJAhJqfKRUbLUcyB7HYe7l7vqE/bcMEUCeD
fS74As5ZKiPaqdGFMGC/MyaX1ulrmHL8ynxyF/nAtDrpzcf+NiuvHt9cis3/NXDRN6R5OMttCaMI
X/PciBM1fBbBcLCPn83aEQN1gNAPDJWTrTNzoVFFi5BDAR2yn1AT12c5eQ9DAlC4cPV3ojHoY8oR
OutztzWHc/l7OTlyXhIdQTbxuAd6uXS2saMiW14bcvlmGLU3FdQGP0d6gumEEmQeK4sG1w5YQcZz
1ajfcu8nkJHK/GONqiWWbTXzPf6tkOYmDqQ22AgaRzj4FL/Y15x46oPYmpAj9ggB/VXZWWkymROx
Hw1IhJtscAUE1d/HAUn6EkcTUneWWeYEjhH5zjPws/sjekgaHxx5PJBJk/AHbszsZF7xwPFUY6uX
68YQwaqPoDyLOnyjy2ftNV+9M3R16XuaXikorGYJDJHXGRwWxNM2RmXTyi8qZjLppLZP8bRPaxBZ
l9L2W+ymFjf6+nqCcCKL4EQoKlErGjQ4Hqk7vMEgN9gBW2tOvSYtsGrF29ylcDCTnRrtxde/1rH5
lfsmqwSD8sXCtrxMqFlFmwgqNc6tEQj5bXf2hQi075sWtEa4MUAYMrFUqxgTaPZK1PpXdH3K8otE
LDMPad/uT45POvFLAPB00PjWBD8/dAvxJ7PqgPYxQXuAinUFoJY1ykF2g+5D07esb2/tDsczYWez
pXwXJSBfvngZBAcWYFKVfvihujGd31azm7ZYANbLkheC1nQJjB/zyPC74W8P//ND7OseHNczrm8p
lcwyKPUBSS2yL6CzacAYUqUhg82iV0Pgx73lXeq2woAABNUTNeCJ5McyVIPc+li9EW7Z/dc8deWe
ROYNs9ZFTVsLQzAx8p3iAE2MC+EEtPUL+1FLReQvCSNASiPC4DY/PiPvxk54J1pY705tHcyfn4mF
yTbtS170kYKhQ4WjVTnrw1RBC16Xgl84YgVvdvUA4RSsJUd3/DULi6bfzHMkXSxo9DFcIv5lVegh
nw0sVOChAqv+nmUBUxZ1KIr9Oi1Q0xt/0HH+5NLOmAxZ5Ox4zV7y7YRvt4nZH/LWDQVNL5LxUUgv
dJWNzCCQ7tDpApADTVx/HNJ/Ea1n6vO0NTrv0zB8FPt7GKm3aEr8VlmXuxH/XiKWtCX6J5/34UW5
wvsfE4amkp4cl1o+ytCQoq4PbNK5z48POwv19uPeEzZ+SoRn6oH7owDO3ubr45g7xNBnrS/h8fx7
zaHgmyqKKZMp+GFI5foL2wF37MM5wdK4/Hrvxm/GPTMgsDHYV/gqHLFnKj81e4G1ne4NHwU9aPSp
0Gd4Ru4f7k6WSJEBJH4z4ZblZ5OuerGWNCDmdpDjWrettyuXBGeWoXJJD4t20RZWeRLs5k0R6mvO
M1VCA5hR2W1nOyqUrjNZtu4UrezAp0bGjBrbXey4Uet/C+EBHiKVfYdxgBxOUxdhB50mML5UPY/P
GTaOo6LN+sXXsWsGgryznvjmnlzdQwE4V2B3uVE7NMcd55/r6LkSkDzeQGjVvZ4ESYvhRd7Gxora
oaJKWXbn863y8ByVrIwuQumxu53Cx+x0wwYPvSZJ7tfldvSqkJx9+c81yK0jbAXjz1HV77CocUN+
gwUgj8DUZnL+fK5S262OtPqvkjrWDr7/Newoz0OPH713qi0sAN839ONYVkzmHzn1eJuNJ1igAWWI
a6iAXfkl649KWD127AZ50eC/DYa+IrqqBO4qpzUR4EECqd9qiRGEb3wlmDCOR5xSrGXhJBe4wOy+
vW+f8GqqS20Iu/DHriuTGGwO0qi2nFaN3yTobjcoqyBL8+AItb1iqQ9thHBR