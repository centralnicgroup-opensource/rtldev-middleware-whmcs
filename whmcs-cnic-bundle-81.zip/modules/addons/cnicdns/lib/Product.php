<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpwvRSxZALRY+dNuxLGWlxsa8Oh+skUvwFXv9BfMCyfjEdLCHwQ/4bMJkb8luGwSaJeMYb/z
dpZqHwnLGkBAHmCTbhw0T5WbcIIhLeeq7zDrYBLSwUl3A5Ig3qkCGp2WZ4HGl+nppFP821Nasu9C
YsL4t7giwLoy2d3TU3IPp7lbISDP34zlg7CxOJVuons6ABOTNei+qLsr9aTQRqpMckOsEWFWDDMv
Ecdbt22f0OaH141xb4BF90RYAwWkvPG5K052lvWZNlcIoQGZP9hi8VshPPfhPv9F73Li20KZ4b9u
40P8HqHU3Yr425xWTE9gCIfg7dEPB4pljw/DtDIT6XRkmK98hqjqeIYHOIqVYKONbZs0mGM31nyV
o8yDjKoPgnf0fVnakPL86uTiLYaKOj3oHN1Z2Erq1tp1ExGbME9jHSoibT0nKMAe7p6BohWQPtiQ
T/W7CfR/5P2yN/xr6qPju1tUhZFin/JublCpXiEEyEwb5vi53PrjOE/aN246TNSXDMM0//X8HcRr
X+wC+sgrQoHib30OKLbN0Vk/2qam3uEelMckP8MLZl+TWnCHbkq6mueoku3/EJsCQxV+1UZGXj9E
JJV3WZXWuFS516IfVVSdEE/2S2e8W2Hz9dIIt6zZElpBKOYKku4cDgy3Jbd1g1uujuSTQJTu5VyC
Vmm5vrs6BjdgisCbndTlOMF2BQOUY6aMU0glUCDMyKzTY3zG7uRPCQdQnFuh7eVW6/qmQcPaXKsU
mxf0utVa9Z24kcmDqL/gU5ukzM6ATYHJbdzVKPpTa8JrI/mG+BLG0snTdWXkU3TG1wenYH8gU6DX
Slpb6RlRczliaruPD1lhldwlV2E8witLy7+KcdrZduYB68Q2b1Sg7qiY7CN0qyPWGpcPZTl2i7dH
c+6foOHk+OTI8xELmRNZwVaCbcN1Zaih0XQOg3WvZaXM0JMxQ2OsaHis7c3oXoPaOROlfLa5vIEB
8/ACO1klcSw90Rlz2kXF4adEgLpNY1NtK04wIr0aJQ4f9ZMUJCY+kMz+OPojZ6g+jo7eC4TZH+6j
59mXVQLDGAnpDJ6YGUCfsN8gjNhN/Wy+r8VuzlwaPZ0a16/QEptu3yRwhQNwzYU2z9iOabxsp7UM
joc7feP17IMu6mLpX8E2ZCqB4O/ZvHbTOxnlb9gdCH8Q167kxs7tpxuMJxKcjFfLRVrjQN4dreBc
2F4Ge9O0XLzfOYUx/CJxrj4JPA2oh1VPsHnjQ7ttDMoSDKBHt9uqJQIkvrzmy6sKasPEofY9yo4W
ggyokXUk9fMB7vvQ+2YC5wW+DkEOpl57r73itZfQykc1En0FEmdwi46oYom3sWMIHUXz5V/TMpjt
v7NZ3NFDekYgyHcrZxGKHny0oAqBAembdYtxJq4PbEhnFtN0HAVN2shL+ohvWhsj1inFVcEdKGCz
fJ8v23cqSa4I03700U8F8YSXKwL8HkfGEoIWhHP9q9etxspM2Chd7WmfSfwLtjftL+vONw/YvhUX
t1QPxi9S34ZDsqhkzar1yx0v3n5PquawtWeEp85ew06T3W6b/mnzH0dTOvRUOn6OoKOpkr9IIWvd
0kTqLFXU8OVt9We6KYiD1mERMhPBPuy1q8DFCwH99OpVoVtMc5o0BvOgSVtpZ17p+Px1RpAbMXN9
VEuwstkS/mhFHqR62VOheKQ3COvXkdy1/+KH2voNsLWCQ+yUn1lt5FA8l0KcoFmgCXfn+zeRFovH
t3LzJsbsNU7nJlyduI9T/qJ5CG4DndU01gKIV/l1sqQ0NH4JJuEHkjdJ8lVEmKcx5U5xiNeIwqgj
dtT3vCzImuvYjoFqkmEIWtBKLpSfzgY+b0p8Sgh8DgC4OoBdD8oNJYvc91htP8q9e0hG4F3PiASR
zutHeDoh7MK7aSljU6hc5C21PrCiRQmkLkyCJDthGQSQq+jvZ7XBjzve4XIopEBO5ehrl1schwFZ
z6kTK9HUOwdbh5QaG9zLv3EFazY/8mNugvC4jhbGVdpOuBM5SwyCY/K+Ri4mo8L2pIM9M1J/qUGC
VHzcX0w4T/i/8clUyMeGj4yi9DQHvtb31HP0nROO/focWukpAESSKmxTivEp3obzBRZXZWkybH5q
1dm77TRSPgsHRd0w8+zRVBrX1qvhQoJbUyAA4MXNS8+JqEBYfXrJdPDZ/37xj5sOqTq9v/lFihz5
nVYGL2LwP4RyUP8jlyHgcdB14fpq+jjB7LpIFJJGmm7CjSGxJe3D85nH6rhyWe3Sa8sJPuLQA1Ua
ZAcAGGH9RCG1xgtqg4TZqTY7grhlrNnoj3ACLw/ZBzzFTz7CjGh4kVOWdFvqrrxdGfhWAp3F9aF2
lqLw+ah1o09AZaqoX/BblhrFukACd6aj01xv17ofPiu523E5tuuw67+FeqCi8XgUp0cpTOPhKh20
zni3W8/rcovfEXBOElOpy5CVApCGkAYi5Kt0NfTn+RGULHhtXkvSmITPzXbjmkuase16k5oIHVFG
qP6hXoNkuVsjlNYlUowYjm==