<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpceZlyDwpvpyF9a6zn9AAAvWK45d3BZ/x2usIMgjBgg32nMPAdA+xSEn2HxSviBCiBFkFHc
wAxCzZwwjq2Snxv/m0am/wSg2zuBMUYRLcF8+q5ZOknbD6fnWKZ9JMBCMW23QzjYPpggmt6w7FW8
k1GqhWRCpYcxv0B5xbv75h9AgOp8YFPhkolCMNHmdh/OrW89fcNe8Y0C0qNfVJCRlsvLkqV7DFgL
CngW+ufcX6EH6uZr+DBdaILI3AxJoI+K8tKJ9y9QBBwxwMaOXrnFuw+P3sfg4Fnf+RLpWvg62aLc
40S3bOvj8H2nebvng/GtWuj2OHpDqkr6Fj1MHc+11XwU9X46KBO/XnK/XqaG5nF1613zVcQNLyYh
O8HBcGOP+h0vR3R7xq/9eEDLlwJgAAoPUdT8FzDRDHZxUgAcynt24TgZAg8GnMWlGUL2UIs36R9N
zzawGoQtOvv0e5fRk0b5fLbRGEK3UZzspVT1slctqQvZIIAtP7XmWprqQTQDd9wKJ3sRh+hktNVZ
b62rEi00X1RTdjiE/Aa3+N3LIKscaj+lJn4sy+m0uAhseX0sCBg5ArPZs/aTTyyeD0HiaAQEGJ3k
I7UcqnpM2ULNaJqtoUTjlds26dGCu02RlnZxwS0blK6k2rMNU2K2KJYHGReXr64IpsdGjdN0Q4vK
7zESXFKlrVddkfGWfF+KW8kfV0KcLW93XN/eWRBvnLzTVCsh/zEwDvoU+khs8GaEMjVznHfG8n6t
TatSUB/kfXw1anHZMadFl+cm2ZIOJ2gONYarOFyJSc55aiHfWKI73rkdMxbNcaZObI3yW+C9mSuU
2LWPf30FbzgQJ/6omyTLhvK0OcT87ZF9BOQ2t3XFpnbHMO6tIigespJ1ZjUICOlx514CgTD1VnEo
fkvMVJKra5dWJqbTuAtNWfZxPwrrzi5UqGInFPyVWMB8sjprFyZOFg6SlWVM+/p+o69JqJDOFz5q
68Y/Wh+XH9Na4MHaI+Nja7R2bUnL8EK1/H98Zp9e0ZtxvVX6G01oLzh+G4lTjCgyeI/9EDGAzcgC
Tg2Glbqpq1la7aIs41NzRWw2/XV2ggEvm/ZGo7gmYc2x2zQRJtOBjati/EFK6pNiTSELXJikaL8s
cjYLAv0fcPOGjiJZwFk7PHnt1wJJHmEaax+crSKoN9NwvwrsiHoOcRYX9dDieaeQ8Ax73C+mzHUn
EmdwUIbJCVMq59puax9WRv0SzyFk9chC2EiGc6ptHyxfN2+kPU4DG+fbJXxypyB3Ujr1CFy8Jihu
hfu4nwlTLDiB90+HQwXjqryS/fpI47sNLsYdjcoCohDHSsHVk6dgMNmNSNA3ycAGtLxWz/kma+CB
dtPOmBij3/QcKbCxKk3vlDxjAPgqEjZgaOhtusVlCRVSIA3trTGc7vASIkC22A5BfgHanFTG4udQ
rcWCZbs9jW8dqRpuqcLG50cHYld1EicFbLT3HuuG6Q6iB8eiFO8/bpSibnS65dkD0rI/v4NpFMNq
nt4fBv1Gcjl4EHY6jM5mHa9JsouOUZXeQdeQlnOI4S9zM4J2cx7VVqrtIgQ5HP/fnmV0oVZS42TH
twaavUUVqojXomEKek4vTKg9NaRlXGKcCBZZ5K9P2gNrGVcOH76SrmoEk+T477paqpgy0NRHBE/Y
5YAFjUJoaVVP9SAVdu5wS0ME37hHcqGb0k2O2M1DPqt/Yab8CicgAAVtnWvas0f4V+zMxvktkeG4
dl+aguJSBJR4ps6hoOFwgwePxwq1kJ+Lfq6idYheGTfYVVBg5p0CgNSX9XRdvLmGG5ApOUADW3O/
9WqcPIoDmXkYiKizzqiFkhwsky55UCXJtw8JBdy1ExZmXWH+e4D7I5b8sDwf/qSH2MNofWbnSjTa
uUQXEaxtNWPkPtFmqcG7XH2tn0XV5HEwgRr0bP5rprwMIqCminqti4VNw+puDF0Z76m9bG8n4Ttn
oQynX95tOEWs+KFrYVbrU3LSpnVeyUpa7mh+iOOLsn89K4Sdb3tkat1IX0hCTR5kjzDJzyN8q4Md
JVzH9PN88+cDTWGltMx8hrOYmyKAD0YYpu/vIujYdNXcQDmmO9UxFMlFSTpwNV1fDTttA5pWQocm
88BAosHHrCL16WstkR/oDnFE5d5YB1O2DAiTX/7SvFSZNua30J3K0k651tR3ja7Kc8v8ZVm87FCE
HK3Q176/XD+x2s6jKFyZKLrjk58YDVUunUY5HPWg1fpyZAzAfEWwFqirHitBuGzutBBfgJ0fQQfS
V+xXrim406znIyANZ7QKlg7yqLFciHADzLY2Opa+nggyaUiVQNn7/g4cByhde2d/DT8GMkov/gV2
DzJ5e8kD42ZAyUffpc887MpGVVrsk8U0Hc4eKnS5MMOP70f30Mitabkbn2RWjnInPEK5XAZFc1sR
6U1hR+rFQa2hjv7oNCG5xMsM5mABCSTa/zblyoluASSJPTL8aJ88Fn1ouujzpQiMTn6FyeE/bQnT
cSHNfCUYkx8/QRO=