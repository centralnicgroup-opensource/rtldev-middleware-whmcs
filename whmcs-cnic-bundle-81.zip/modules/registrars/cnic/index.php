<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuYzJkj5XBFC40hRo4rQHNkA1lz+LS7QIQIu3knCh6Vpl0kyeQ+h+26KyQpheRFPhkJ6W/B5
FhiW704+GBElQ/cxrFg+MGc0vof+66PjwfvkZro9knBsb6bQqc71wTmfviXtkxKDGGBK4lD7ovHh
lHx5jWonI22gXOhVrTrIuntLT15Hka0ifAA+kRxIip9DsOaBTYXOpnwaWsZrEYHR/wepV3V4GpiF
UtDDvWtjzeiePClTUVYMlowNzbXNZcBpya8Nc2DU+PB9f2DackmX/QjbcfLmDVzYFbDJo5vgCtZ0
gwOHugscHeVwiKZqdefsFd+SynfRWj+g79PrihZgxX7rCPLK2y5XsaQ/gigA8rKW8E8XU+K/0KA3
8DpkuEwTHhN/BHTBx1/b6o6+eOkRjwRAsDxzOkzUJcwzjeu0rHwd9iFj3HhEO69/ygt0Jny9VXmo
dRa4eOHrKGLsXUipSwos5ZY0PhABkFwkQVIsD6sW8xk9dcLZETex6sjxKZcZKsywxQDjqTesMdyZ
QKSKdFArNoO6lnaQBG8S9iLs0vzgxIu8oXskw9wXCQi0yu9wU07WUDwgRQpD4uslfkFHU8WP46U2
MA+Hxuhl5nE6nJ6ysuhjBcbsIQeKETNz681Yb+HK1v3AT5ReGVDye3DZaAbxjn7dID4ER2O0n73I
n+8DiZcRTvmx0ETgEIZktLSX90ES/m5uSa4kIKABB1UpoCUKqAh6L6YwvUGGoXIMqheHz/ZY+l7+
GCRyO7N5Vnx/395DzvWVmkJ19e4WlZ2Kb6MSSPgKq2N9KCIUW6oqw5k/dXIPbORF4KEzqqBVAC7j
CrGIP1JdTNDch44QsVkEvElB2yoXKWO/1mfrSLYxxTKZZG==