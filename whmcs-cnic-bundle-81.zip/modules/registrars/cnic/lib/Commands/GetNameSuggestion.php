<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpvu38h0nFIjdSgPgQwyC16PhoVo3bR+J9wuYXcBlL+tZGCM21m44W3wS6fYjiTMWfaU7Rzz
S+yE5tlWtrX1uYSFSE8LH06vo1JAJaSmjEuzHGJJ3geY2ufpjbiK2451JVlBfN5OgcX/fMz8Tlt9
xpguiV3/YCnGdmwCClYsGVpQ8vM8Mta+CJTFBuGQQ0R2zy08g5yKvcFqM+TGBQZWICC0n58drg9R
Wfl1jSIKXOziGnnzNth1/IpwRciPgnha/0wIOkRA1vVVElh13H19FHUREr9aM+keugRLoxZXbSlW
U6T9/pUf60l6w1N7haANSwlqR6Sp0sCL/PTMwIxZ3EAEn0ddDUj9481RNN+sIvhstT0Ct2lZrHtv
0ynJMUks8h+U+6iuFvPPYeej8AVvuRewPVCtdttDG7bbhxYfB1ZyW0TavPp1bVz78b651rddZ0QB
ZtuEIyE/o0pi4I6KwKeEXBwyoGsvSB5yqRoXFuoZbUQpRfs2WXnWbWB008tJ2r8dm+2MPNmnQ/zi
DaBob6xMTAJOVgsdSFw7usWHK1Cvi9aRbW3ULHSZuyDJMpT8knc40NwfSsXPN0l4nRLHxO5+1U7j
4TdCCExzchbWXD2uh2j5VE6WXNonIOIVbHaIL/pDnI19cN213E8aDeFJnMvM6shBpQVjhDOHL2yk
XjSmwTRucvz9k6rB0wsKP4dfWDVJ+oCWHrrtiIrcdDQfTgvUF/D3hO+Z28RaXi6Fre1UMBMr5jVp
gft8LQSkWEJUST2FzOe+4YmBl1bsDXKRO+mEtkCc7f7UHVB0HLkX/3A8bPaiTdmYw9Es9isO6bOu
RnIzf9FsIV7WqNOhyuyu7/mPVhY+qEFWkbXFjv2HVVGVe+3qHUqjQwEjuV4HsMX1exElU9Dh9DPv
ZlWaTlmGiRzAu0x12ze0+mwuTbfEsDFa19rN/vtRcVVcAZIC1tz2l9JIpnBKbC4fgZj1sKgLPiOP
29vSRfBaPl/EfFsQHFkTiUVLvfo5x1ldMfB15BXzzzvmEPJDYuK22DuiXn1pOQxKMtx7EaA5kc8Y
6vhiq/TguoedAthhR11OrSdbRk02aNbp3DBlftRP8tlsRz+2LTXDudWECIi5pmmI8746Md043LZ6
2yaiJTE0fMzYMEbbDf9OVTudjIooUiD5fl1ksAAWB1aOY28HFenXe4n2PvNDQFkqS86JD7txPrbc
ah99W0s1v2TieuYktpwx5hWZ/XAFa51UV6tBM21ohg9a7ptIPfBiVkQmcV0aZn/BbERL7dARc/2n
eISI+d1ms+EnEFHkD5UfjHdWh1n+woTrmY2ZoI/qrFsAAZ0saTKYnY1/e5lsKg8bYMec/09P3bVB
Laz7W/h/qZQPKpPt3hox4U6QH3hG4S1foWemlu4FoWQYVo7dLlouYsPvQ7TpALl23rFGR9eqQBWW
+p+ZAaM3Iw05ZwHSyX1rRxJv65RzmgWEzIl5qKbS6tX2/q2fJ4QC2GsiafU5dVOhiSDHLijO8a5M
LTMQ7OcoHZYprOwMJIrGD7XLwEpvljFeDGcEC96SosaZvsSX6ndYOZ+H7eBGLxCbx8Yi0PuTE2TH
HRzDEkCvZv7Zl5NaJX7Z1wsNuI/E6txgaJ3/8KWBw/7CJjCp0jAD+ICSYcDtGycSrUHLUWBzBzFn
b/jR+pRJsiB//27+OmdIlyJwc8qpWYyGD8pZH0PgbJWtZGXK25XWsMTZxZ+99FsAioTPE/A0/1dG
q0n74EOW0/SIQKk+iDRsUmzvanH0UmmGJgr9ekQDXycn+9f96LlBtH/LK/HZLeHCLazYyGGcCCYv
fB4dBF6DbSfPthgcpR/eQq6OSzJ9YgOQ3u2v6q0iDqYmWift+bReJAxQpnqPdYz9w/3dCdXVgtlN
/If9z60M81YNyOjgs03P8x3N7Orc2pQSjCtmrpM5RarBryuFALwT7k3nqDll3+9WUj16hNVHkqDv
y6a=