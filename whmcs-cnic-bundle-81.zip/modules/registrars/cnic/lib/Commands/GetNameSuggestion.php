<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqT5A+LBgw/A4lU+ngdn5d+ow8QdBd9VV8YuqwtlGVdTs+Nk57bmNNmGSvGNS/fdMQVsqcgz
3n2ZZ9QvXFhK6xf/1Mepp8a/VhC78bd2li+4xfjNmFQWzDUASMAgpdqEEnSnA3PGFb1aQMbj4rOM
KDsb/BReHQ9ojXqfvkvgWHtl0uVQQ+tuCzhaJVGzUcXJ6ZXHgdYHryQnMv7gubw9z2zkCc9Kd5lz
t/xci0hrZJdAa2DgDXYpuK5qM3R97Cy06wrD8ahMLKiSqv6iQhdJ6vILlV++RJyKq4LiCXKsjPYc
MuW6tWY8uOxS1z6VOGLzjMhAv4ipu5nz+EJfz+EicVipyfAi8W5xeSgf6TLitNwRM0ShVEO38G05
aMgYgnuhvWyOeDxWT/GvGKdGOrpGG4CFr+Sjfk7Rn2uHXZJGmQ6cd1/T2/NIzeyUFK3nXpqzdShc
OHa7kTTR7owye7VoeH2CRBUGInjrB3v0gfuF5bq856CoidarT1/3tp9rtqtwmpOzq2mL7IbCeReZ
nWIIYb7Nj6hBPrgU2NXX0OO9ug869r3QvUZgEYmTMNz5OKRRWbnv9T7CypefMtxMEN5utC2WIeRs
RI2te32fxKdcWCuf15CkcFMczALoh1KWw6vjBbex7Adf3Ix/BstNINc8zSVEgOp5ZRLrrAtjk4ue
FjsSYa8UlIVhNp8XshO5IcKFY+W54U7Zkr80fNBCv6Bfce1/hVvHHhFIbAbV+jenc8fGODRaoGNQ
WAPxCsGxUR0pqOlD9BLThuLWzJVKTwVKIayt/Wg0ndtIEWfivilxXHIY+ydfb6V9mDC37D7FUDXL
7JNnfi+cSDjqHIWLj66V9Ff1S0ICUvLW0khq4ZyPrgAxbXf4KesQ/7V4opCz2QGLw8FCQGFDVbsI
C46MG/D/5Zu0pbwUmSGGbYbaKc861Bd8PwLMCr/YyJEpk/uUClreDANNm3wxK02bxH8Pe1ITtURU
8bNH6rnuKLvtvrlRCP9T3yR+JncjEm9hftJYM3y0dVcM6yrocdPyLwarpM7jXkkYtLJMXk1hU/cq
zpM+j6+2207Cr/zM6k9F3ibwD3vv3q8tX/+9Xc+Qm2misK1eE8bp3dC7iKkFaLTcSzv3/0ce0dbq
M2iulRk3JegRtFb8tOOORFAR8ZVLx47o66gk2W1911sSO1Qa2fGsSYzOKMamJ3sDCJ9FSgPgLx8u
x+Bo59A0d6MfGRtQBJZ1H6zmg3RBs0FkzQIl34sxKHXAjr4VBkhit06z6NIQbJu3BAc69cGi0tJk
kI6KEyCz8Xh9afY1gyIpvQ0F6p1O8OF4SZ2/y3IFQTeChxkHJoHoitCZDuUGaj+GtSfc/lEQ5VL3
uII219vesmkq6Qu7vcHzrUeS+iiNh4t8Ni/CRKG/VVeIMxP7APSF+nw3UcWREBJ9XpvKSV9LtIav
zJCDA2CC9f9AdChfmwf2YAezDfOL50dAE1qg/X46LmRHazz76FIIuL/ioFpDgD80t/CC0dHPJxW4
UwsM8h5q91NH63IIiSZi3vrOCrZk/CsbTk8fWifl1dzkL6fIBASInhmcM24npOIKKEDOnx5yDVRJ
CznMFlphcBVBDkKokj2JSqRpAD6vCW3H4NW5+PuzhcnE5ItGrmty9kB70FQ/l2Fw48RFaq1j6oPT
XeHqFcKqTb0NFciawKFDODJHAwde9w/KANt84cqLSon8dLBlvbUCy2MtjhFDREttS3WuvVxqOJVk
sS/LVIHC0AXmlREsiAu5RbH0YfYTURaB0Y2Vj2cim6bLwJTDaViVEW/mwmQAwdNY8lrush8VbyXP
u2EBgdKTTmGQtG4rABL9Ig9Lbt8QQp/A092IzRBTXsEYSItyhs6OhJAbt5n5h5fq27teC2QUd/v6
T7dYmK3u23QTT5v0mxitMYW7Jq9P3G3tgItH8UEbogqVkm19qc42nrJmoKcXYcvumd1Q8dKD9uQT
4Nu8AtKmzW6svDYousOmKm==