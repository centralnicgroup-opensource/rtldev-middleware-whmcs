<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw2YVa8h84DsCcxhOKLj+joYlszya+3h+AEu1upKRIRHAThBuLMKn0/glm3fkjEjhl5LoRo2
lYTLVZhrSpdOAs0uWu8u5fGVulycuxK28uDPcxlKu6kx3R/DtHRt5hyqR+34gvZfa1iiL74a5FjC
g/z9+kh96kz7vxIeNPnXN2bXr6QMk7KUgC81GhyOg6oKm6VClKUcndTM3UZjPp2MtavoaEHG+QL2
w6d554BaO3yY3sil8lO1Oo/SOd7Qur7EVDryOkRA1vVVElh13H19FHUREuDj/x1KO7n1jpyDOSk0
g2SzKexkoSIkuKvJtVEP1EzDnZDR5DYCs6AJb/r8aLKRlXNxFk9h/82T80vxFe0SQ1nJsvB83gOg
8js3y5K0WC3w58CfpPjjm9eoCy+5epccO7X0pcITtdoiN0sUTJRHE1mmRCmNQOvFiIqSJvcF8PM0
W8J+DHkZ7DuGGF9519O2HlLavjrxr4cPfmaQBNfQnZOqDBQUaC5Ipj9QtrGWcLRaVebT/Hl0uOiC
/qvyX92AQY/uExo6IfbfJy2k57YGSsUAzE1BltZFoD06AUY1iUwi9KXdWGYUoZtxLUAMjz0ApmxT
UG5pN5fVgzUaE6ldJpH2Susw6d7xyo6VYsE4KXCa41AI7oCiyB/4zniCv/ChZj22HwsSaUyDT87y
VHLXSlsoBco9qQl40zRjBMxLC4u3wv+3Dr7IV6SYZvGZeb8/IX7OfCdEYN37w9RIPwCS+AGSCTIC
34N6jLexmcuqQ1CRqBNIRt305tSlOL3+IcoX5ILPTqqNnf1ZAl0oRz/f+joFSYkPn33olKIwZjm9
szuQOdfRP+4zFsM/Ix/O0Trwnj3CGKCzH0VgXogwEtzvfie7n3/+sCAhMMJicuJzIwOqh63OIdFu
Er/XkuFFCoiISGKnFREOiv9rIenEbxNDOzs0eE/oBWTidF5u2T9/VlcJ5GG5GFy6OV778uBVU5ZP
aRv8m2QnOOL61l/SpNdC5x5CrD86OHQgvD44T3uG/mZovu1J3FRKjk2qVa0IVZtyz3Ku1vMq9i9H
9VZo1tOwgsWxm7Ja1zXIoaMqdiTaqoQ/DIAicvxy+A0EY9hQWisgtmJHzgxbp8HsATQJiozZ6GwQ
uwQ0U1OdX8+wdeRS0RelOLnptcA0wrjEt3Y8xW1RWOuXYmaA7WzZd2bQUhEAYWhhqlGATUcyi7Qd
0G+WQ/lK/7FCsNrgqODfz+2hQs8DrhwCS/vm67t5ojCs3fyPUMIwgdUhmAG8op/s+Z9l1beF1BEU
ic8jz+DZXddTgLFF6IsU9taQm71e1uWOMM5Ug/y2+5D5RyiTVFWAvgZltoA8NP6CywoeP+7vMHKx
UAHd247B5OHH2Rw71zqX3ytdCxHtPfCFg1Gcm69lHDpvI2JdIOi7eoVbJ1xuT2e7JUTlf4JGXtm9
+bpPRhhG4uoAcZkTqL1op0m79oz3EQ85zLLI6xCu+eBoVa7NSvvlDLICYfD+YTTQt4v0PTdfEgCI
a7JbwVntdasfiZ1ZD/K26mONebFA83GusAE17+Ve0QAJ8skVPUVVfPKlddtNDV9yB6WdrTxEh9Xa
yVniqKrziK9lzeOACR3KB2NAM+7ChPO3uducjo1tPtbe5qNZVwvJEb3jYaic6ESSvZ9+g/QNyXN8
2ZrRviN6nEQrw1N+vHbi+T2a+x9bCovJj9HowQ7CN3tgsSI5UycwYWKqkW3++yH1X0NH1d8Gb26i
e6sw5KDca7wYwcOq+VZltygT7TP1eOYPReodsvk3YSvBbHwki59uspEpAxA9f0q45K+GMyB2B2Z9
ngmEgH1YtTlvcS9eakRCktYScMeQkLAcITmW6/hwmVTTGX+dLuP6CguYQ4Ja2NpTOWe9u0T/2pPM
SJZwId2gCXUIxpedfSNo6QM5jh5iSzybwLO83Ww1PuROK9n81ty6lSGOZOLZ7h6umvqqWn8Qcacv
X02qEJCoO330BmQbQnF2dQUXKl4TXp4cm5O0oTIgz3y8/gi575VNHcnzbI8EDV/omD3gfve07w71
ci5e1gSLjfXvw+atiQSWBoa0OGouS6EkIZDB+fGNt9Kwp9PLXAqOOcROWjEtP9KmC1HuAPGior9I
45t1biB5SMD/5wOtIVMFc9yvzsc9qSzskdZE5RrBnACXAREEwxuYh8Zunx+NPlTSAVCig0VDc2oT
hiy0myskCYCwacR5kMWzVtF/qgUJZEZrygDRO0DfzUXTtdXlRebUrz3dNXAmL2bCeI0E2yibI/lV
LNPe3PjBeKrHq1zUsGGm7BjkhlkSnH7q2y2vEvxltyHxNqOnVLIVGTJ/K6/QZMRUTzeB5aWCJH+E
U3PGAiuVfWgP4kA7Eqc/eGj1dFpLgtAxJbPzOD/2PfY9OgHkhrwh+y96d7u5vui+lKR/+QIbyfRE
7SRxtOBPoV7AsXdUtLJmb0pypa0piLOz2UTQKitaRhwQ8BVtW0gpLgwYXfhZcrD7hDqoyem9VNet
dyNSnXIqEYqxEvBe/ZWxxZEtFeqxZzSKgDBwMEkDEyx6/0duprU4Y7lLOq6OJRwXn25WzjEQr8Sj
NItAVwdLNhxI