<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwV8RvLJdbJRAWJwjf31kWxTIKVlZnQ5QDOleZ7bNhMebsTyxKekBdor1u4TKoAJbThGi9Rr
qkaQYLLQlL1Jg0ZI8VqjsUeIGVpp9W6F5zfprvV/oZi13OeK2i9eNYwEpuxbhD4ZRx1AeLrOYmsO
Xob/Xs4Q4Aa68gEPVjMshqm1da83hPFGmofVbR/cu9AsFzqQcRX706suSUkFK1jv4EiSCneefs/w
WGXSqhCMvjwAHn3DGa227ZBFeYLo68GKDanCBDuYIjPLInpJaQngkTCRb9MzAMMoP5Nqp0EVh8Ru
cAQfnoPaTVNFdIa/FKsm3Rfcty5msl7Y5cVdiQFhIKIluMFT9gKRhlt92XchN394ObBBbkfzr8SG
9wDkylY5ilz8GHLC4/qNRcRyrdeKJGaF8vl408RGJVqxuCVioYa6Yvc3Osq4xHeIkOPwNPf7UMBI
VcWY0xkTurdQQy35Po2x8x+vuHBiIcz73yIyJAzlMRMkpPSWevcy6UjjedkkamqTGd+LTjhWX5Rq
Q7C+wUKtnfXTsfnwzGSSj3PiRbeKhx1+s84Ej3WVauDhMXtf6778uhiz1jko/3EOp83it9cdNi5k
d3x0JaIwqHkiBR4Mkt7yuwhZYQFVUB1UlqneZmFUUACz9+8iMFznIyPQ8nbBBJ9k0uc+ewPcnkxY
Brh8nFjsOuMRtACrysPQ7J+oCmNVSVVMpJITttseU8smMTao0qyRwnb+qVotTSvNmvjAvNvvz1Lb
qHOdka7mLRZpdhBtR7wvCMnteKm2ASuleu6V4dFNQpDy97Piyr9WZL2MnK4+bhhIzHsgqNh9NZCV
h7B61bl5oPmpgSd5miIzNt/eo6QO/pMsqdgrcqKtdcH4ReiAoUIXNhIJ7VTfjpENKzDfXeSuCzWx
4UTAJ8NSic4pMeQCBoD8Lw4iFiRyX+DZyNQwC509JZSK5W8JtI1f/v4gPONIzMlBw5lRlqsx8x66
Lo6Y2YcvtKWm20PL64594v4IaAebzaJeeHHa1SVyXjK2s4r9tdb68XnRKX27+WDzMn4teTC83a9j
U2xGu4Lo2Bo9sRXt8KQVkssHrfo04NJ4vRJep1ux939R/jFD8d1dZwGWpBNHyoEXooAdtmpbZsdc
vbajc2s/mJLBdE4VexyPKX+hlVcYEIK0fXt2hmcljHMAkdcx2ob9Wl7lOlvhOpSe3Fuw0gOP4bql
NShuyf9hAThLqX1M3HcJIvtd9oyI1VZ+kyKTQj9XQDHhrWAdU4xlQAyhz4wadsoxvZ0+hH6fs1bl
YvR4Vd+M2X5BI1GsNvP0yQKrRtJBqYnjkeBXTx+5DymYDH2AhykFJ4MojW/7S82uuCpEh/nLH4qr
Vb8L3czSKpH8UI8XZxaT1seABPCkZqf5Y15pFfl64hyQOUr/ZVqXfy7RxsjuVqd0u7dBOmr1FH/R
MPS4uUo4UasOvz9PtPL8tSg0Cpi6iTHhvz1XPRKoNh0W+OlrqzVlq/QwWZCMiyBCZ1bsABHqL6CU
uPIuMv4DBLAhAgVb3eirWZJc3+LpIURxfYknKqsoYZKTUsPeiQ4F/scRewFKpoqFweKkR3iXmGe8
L4rH/JcNhl7880cLopWG496gKzA0eWvf4LIu1GwzP3RosDJk0sZ2HkFwhYDUXKTK2FfaT11hqOmY
RX0ctx4A8e7vbtm/hQkI1P6qQpH3EzpXtjfkcwLbruoq5vCYf1OZAOH/aeIP0R85PM5RGIrEbBtQ
kp93KHJO4u6jSth0vb/wYte+5iBj+nojV+Hl7g0bVmC8jpFDbRlWwk+UPLIp01npfq5f5wiJb0Vl
2cKoQuSYMdK6M0VFM5j1G5qv5rhisNqav+uIDTdnLa2HONpjgVkqUnflMtXWCJjctAFKc2kNYbra
/syZDG9+mFZv0mh5Ipxu13Lu78qm8vGvnypl+qhVy3N62T0bMnsXAsYMvTpp/BafZCiTLJCJ1sWt
a5e5qClfkZZ8pTBUu/xM/w0Jc1CaI2H+G3KqZGAeqaOd4le2VrEJupyzegnemuapfnyNMnSq/xf8
PrP1YBkpvRRBqoLljzlj+ekQa1EMY7YC6tvHBN0BLypvaRVXJfrxK+QY6vFxo8y/g4aaRaV/eD06
IVW9fD7GFSLlKIs0uAAAk3ZPFmPZQs2DmYK6J/mXJxvER5PWWwZ8SRem9umf1bTzr59voz3MaB1A
yXbl3FThaphZ/nLrCytRwi/NyYh/5bBgyEDAsc2VKjXhB2PuDH2DgG8siXMxy6zCk5ppSrkSmOS7
vs7xLYXP/rbmMTK1w/z8c51xkhfhMETAW7K9kjwSDgQrr0cGrP+W2B9kK5S6aV13GirRzri6ih1U
zSHdeU6QS61pychss6hlX79g810BcMvJzH2RaFttgBy3vP41taYswXZybriOPGepQV6fEKh0sagc
o/Ntoy88eSAAAFf4+n/prt4PZcrpG2Vctakg55V9beLkqZatBGubIC1AC4v/tuIDcrtLHVDLIlKu
J0NvC6upOiDmwB+cpJuLXy/0A2lID2xHVRpRMeFb/eSQq4vMdatXgiMk/KigLhLi49T14+sTSrnV
iyGuB6dN0PN6ZcIxJr5Djm==