<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPul7HO4xARwsmdNGebJjdQfjCf8h3tGY1fwucA6kZsb8kzOSHB1nAkwvdoxy/S6Ff2hvU9sf
nwHQwhiA/RING5jabBVh6+uasMzsGsZrw+XalwtpMWwXQ8C5g0p5UJAxNbedLw3fjqP0pQehEZ6T
Mung2gNSdEfse0hkcYWc1EflTvGa23dh43OjcnNUp0fYrHL/jxORgNT1CNtNNSBPHQs7Zfz4jANk
XwNX7Du1YiOkO/k13UK1XER/9cfY8YS6XxGROkRA1vVVElh13H19FHUREtbec9UdetIWKmdtqylG
FcTPZllpx4I13Cj7/PJ9QKsti39xB3FCZS5BVQ08vgD0LG9hH1N+N2lEOwIThJbrGRx4nD6IbqnJ
XzKPJ4zurywXOQZpUOPOVcJFJ+HelFWm3+fBdx3pIYEnAVDoInpwUwDjYpNsTxHuftPk/qsB575h
UJc9caJRf2hvpUiHekAQkIHAt6+HNB2ig2vuDzmfcsQP6tyD6rfEeMlM0ZRZ3w3ab9/MMMB9O8lP
AQYX4heh0X7sIgHsBqs1jC5BWBPj7qe4K89M4Bc+U0h8u93eemKpsv4H13f+VicIPrD8dZy2Vnff
tF+0qXd+uJaatVp36kH2EkgQQGuKFUtMjFt3U3TGg6b6fzAhBrV/VOWDeGxQdoDTVqCYtgREh11w
qS873V54c68wIB0YNZbXiy2S41xTh8Oojdihs5pndsjhnFf5iMbQ1c/21M/eNgRDwslQv4L4R/fP
wrlDsby9vSbG7V8gqa+vkI8fagE/OS/yBOTZuqiFa81kBmAjiEYxuKc2Y4fcwIRUHiJ6rG3SNjiW
thuxudPj93GVoqz/yqF5uQNuQD3PORoN39XA3VMMvLYp4ZlUDfVLWrSRSztpFdEC2BwAtLbPTZ55
n0W2RSHm290t0D6eb4jc4wJMt4gvusCttloXK6jciyYJ0+0go4OMpO9ndIA9uUmjD80+wWB49nOK
utejOE/s0jOoJ4h3oD1ipM/fdsZmn3kRx1tNY1xFkKwaXQSEBT6bjbDoyjh2MXjUWRAy0KBljz9k
3Mnzj7uWz6KZWpRDKZRtRhXSDjfyAc44nOZpWup+VRILYbc7lfMMj5AhvWeTyRRFZzJB+A6BmatG
yrKhkitnl69IiqxS8Xt2fB9w8Sl5NZMdtGoVG19TCQt+GdmVhb4NUD/VPiWNLlMjTj/xDsIXRRF7
PfJPl2XAq0MKZi2wJ6JSnDpZpjMx1ic4DqNO1Isav2ozNm0NKnAHwuBWemI+rw9Dmf7sXS7x2cfA
VIXsuLTSyIQAxNNsvbE913ItXMxiiG/CxdYUMgxnogNIULCpArVED7PlzsaPqzcdrG81dm37QU6C
4SbIP2mPMQ5q6tJqHUdufcjflqteDgHcpECjGpvEbqSznf+RbMhD67SMfj3LLBqVpUs3+2x+MbTl
1GxFU348ROAYyORjPk74N+MzIi/rBVGK2+b6gBnfgpA0oQb5+d9gWhyXN7syINw3ZD4FFsQiVa/8
eIi0NUz/irTtd2WeOLyJhxIRwDfp9nc5myil0QUjHvjLSQX9j0TsuVkN+0wAawNyvreU8HY2hD4j
tOkKcg6pOtbqbNrcVHF3oi+EdOXlfA5u2OkLxS4Gj1zY1G3GPoZnLfBmMbTcgGWOrkDzTuE8d4Z6
g52Xed6FbNW72KeBlKf9rNfFEipQdhxfvCeHbnLjmuswapOTdOllqcVc2L+tUo0e9H05wORp9tzu
ANMmXBW/9uNJLyWYMAmFCdhLWJRyMiMmV0upl/j38uaK/RhEk9f5Qfe71vO9CIHkM71dzwaFEVJd
DCqfyWpqB+VQPSVKUFnjw9O0kB6AhesacifVezAuOf5Mqng49pergmaF5TlG4CEfBuzLHKpuZFDM
bV9agsr330ztzbQvImffzXa8rUSJw2bjpdtUu9ZW9D0SlH8o+854S0by3Wvnsvg52AyHTgpInaQH
66wccTr1PTw8SLV1RXN+hiAx8nLmPB2j88UdQm==