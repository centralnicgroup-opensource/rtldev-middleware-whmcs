<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu81JhWDxxA/oBFRcqzkm6egTA9pTDY10uAuvgxmME88cJgu+PWPO4AuNhwtza2aUfjKNyoY
fiApXp4RGPMmwKmgjv0xLpuRML8hWNJ2WNwGI+TJrmgRzp9FANus66WJe3jZP+NwAieoPztTNP2U
kcSYKmHpMLYcr3yoNrVLbcTvQFtAfX4MUkEEMFx/of8Y78tF3UsYN0y8vM09HNzR0LJzJYvgqstK
G2+vZaWjcyte6GzvxEgCKCRyt/Ig/f3+rv0S8ahMLKiSqv6iQhdJ6vILlVbfgM+zyANFdxQwEfZM
3cXc2x7r7t1rg7AIQeQYXbGEZq4orgGaRMKcJJGGA84m3745tgBjiIe4o3g5bA3Ae2I0eURSKPQh
RKePAU/Qt6GJJp6Iex89OKuAJVs32qNozFRzZYZgKvABDlqepYHIrYo6BLaBqdkxTUVKiAZ4Cpql
BZkX6ek5wrg8eGfurocH994cQpxiRzWJ+oVeNAbL/9vCgJ8DSxG1qZQ0eMMAeCNmZcfVOu0u6ftV
vtDLALDT0KaPKsiPVnliNTIHeZzaKbcvEUXS+ZF3lmNQi9crDTm3Mt679PXT/uizCK5CZji+xsp8
FMhUe9ze5Y1IE/7kpnjQUm1P201k0hZtiAB4Bmlh5yJDd6T42XEJefKPDwtq2MnRk7wiCuaR6I20
xPdviUvopv0AUHgqGOCtqTjzbX7DrIqbFu9Oa37PrVCjj2jZacnf+w8FZA7TcOyLeKE2rAAX2JPi
webcUuvTIAXBq2HmhIgSG9Wn4lsqnw70qyisqmHFRBZwS5sr6aZxu+XLHQu2poKJmI1mi3LhhIw3
cGurdG6+Y5THzzdWtEqAaqf6Qwdqyez9ILRcIlNDK6gswUhwdQSE61eKRbfQvI0HOaRaD4FScQBw
t4whu+H+XiNsBUOQij3Q8Q7U6koHQgaz3nX48cfqKwM8rn4J3yrQPwjS3kz84EeKFsFOLKfav/Pr
p8l31lfv8nG7iBm+DV/IscAUIxAAqi2zUUxOsxnYm9jXvqOaXCfmYZqjZMVi1nWWiFIVssDoKENQ
10bS+rQpChZE0mHoR6LpWJeZltEI8x4jGq0uYYblQCOct5PchOx8jfI8yaj49yJza89aN0TA3tW9
d9ge5+QEOVw7V7ocj++NqJMs8xCe/5OdD+WFRRvrnatu89T7IT1Q9TBpXaKNvnktF/pvcfWVpIkz
uGPXHf7n6k6VaB6Rrdl/pE4EoEMiHpq6hyfyyiXg2Z9k/dida+D2jxFAKjsZv5M3AJqR2/QW3TXU
+k4xtp+3ntAQxJq5xo4q18XMS86f/KLfour9d0MKQudyEOoVMWMJcpf1J6ezrnLBAiH3AKmTZmsQ
qp2IiKLd6wR8teMdjik5gyWV+uvnXKZfaJ0x87dBwRU8IV0CARighgoSm2o2uGfMyWzNriQ1ybgW
Duq5QeI1CYY90dcListzNLn8FH1klGLRl7OxJEVy2UULrZyYvojyPBKbEPXpIS+LYRc+FmWx1kqx
WMMdVI/b6boON6XfHpy4OW/sqMRUwfYzV2WsW4K5Ae/LANQg4MYCPGVTtm6fTsRRHtbW4TECY70U
rEBtVMneZGEgexqrb4/M1Yygv1U8py/0GVFQ+lc3vbQ8WM4etsj2aUCPSPQPf01oIrQqOKUnJ5mj
2baJHECDHOtMSPP3IH4+SwugkcxZSH8FRIQs43JHVxswPsGqLomH/J4d0kZ6xt/Al8xkVOl73usk
adzSvAMMCrcDkq0hBsx/NoI5NyjUsoCvKUEHt9g0GgiGL01W1ZQfLtdEeoGpCcXQ8Fx61GLxz+lY
nWxm519MhkI9KczPo+Z+7fIJvUSIMrl2Bpy0rnRwIxzaAjeksdQ1V/G1e/8Gjc6jxBatYRsW66Fz
uxn7InBNYMJVgx+cjIPzrrzAwQrP/Zbj9wgE4nad1A/mpPWcB64wRoFbdF4d67QFRLT4gK9C+i0X
kjh5la5s8dAiVwJh/r+dqVj8tngWsck56G==