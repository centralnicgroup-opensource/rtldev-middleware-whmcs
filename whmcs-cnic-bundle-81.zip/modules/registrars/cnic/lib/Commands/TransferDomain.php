<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpfJk5xb2m6Hy9SjVRkoKP76ccr9gBtxIzXsC3aMxkYV7nbz9S//Gj/vWqnxaVLWS5IuibOv
eX6hpqafbrp6UhSrbnQwIR8qdp6hQvrgQCrj8FiVc24QQ78N8JSj3ovtAIIsklkI70ET7ytCautw
S9Va945KZk/2KU23PkXm9CmMzpaAFchZzmgxJrXsh1fbPvD18HYHJb74bu8NKD7rVLbaFJ9DEcLn
oNlM0oeXcVUISvgj6l5P2sfmlzQWfdpO3UjmW29ArbLB7DEHh6gvqnkKbRtRP87okKefyJXNKKgO
va9dSF+6m2v9NLQ29tKidsce7yNAPN630y/3A9dnoH1ihtGNLXTzsS4l1VsXl1nxVNoWtCMi373g
4uHTGSE3q8uWR7q4CKDxHySPGHrKvr8wp3L7k6JYZh8xQ1Nf4ciskzbxTE3TPWXRl+wKL7h2YN2f
Cu5KvUys7aLGyx3rC/6zuUXigupi7FmJi29DR89RY7YuIcaOxrrIDm6a+X9P2Tt5WIaNn5hBo0Zq
RIoeZawD/v+I0Yc9dCZa1Pgsg5LUnRf2254ZJBC99YEy4R8ayrWTk3ECTQzUP45fGbGKHo4kH1C1
vkkhd8KZIqgxAjkwaSR5EDbn6l0Fs/A8us3/5eONqhSK4qBZC/5x9UbPerP0sLDg1gwcrOMKyNCz
NapY1kYkpRlaUG72Uzk48WqPwEBNq+oEavTRtmqitWTDbq8BS9JZ5xabJi0gmFNKhrsS2TI2wtyd
Q6jgj9FJBAlj9mpkcH6iN6Mhy+lwpkBcDWr/G0EeFP+im93yH0x92cucq9je6ORRCq93NOpF5r48
8KPQ6u409nH0ky0KVcXD2QlvHhRdXrRyPC/Cdpi5a1HtxTzOACSOJgcaaEiYonXBRXVLY7b0eqbj
X14dar96fk9elOE4L86gjewMdyfZ1paCSTnK1yZizp8H0E+9bQU6Tkb7f+eYNwC+/LoYJH9nWSKs
Kzmm19uQMf2CDXa1ybx/1ru0eMDPUnbhqKcswwF7QjfQm0mZk9w22/lEO/URRWpt1FiKzLv4TYQS
3I3buVpe9gVAxqz37G8VFUtVoYhvuesf+gRpVktlQVNlR9gqhzmn4ECf9U3QI8RjN2cAhQIgY0Oj
xEfPasVTebaXVmUyWTnLW7ClqjbGRBTSFy1uGJPdxOCUc3islu6gK52doicURRo2cnCTCqw9GG/W
+kMECIF/XlX9Pk0RodyYV8Vl2H3ukCKlMblMd49GrWy0DnwPAw7hLPiT5oFljWJEEqJq7FITpug6
Mn2+5UegB9H1Y4FILwuaJ+V5mfalR5mcZoSHS5H8H7JG1LbAzw98BbLOLYbBiUmkJ9XluNQj+RzE
ZXP2OGf/X0kPO/vNA3kLNOgOmUwuprJXJHiwaPODQXLtbKBrmC85nMN8RxhiDu+2r+UhncAA4XuK
p1fcUg2Q1PGVP9dSyxURFgsSyncUN2YgZoPBQ3DacoDpv71A3Shfy0BX7Jx2qqXiTVe4ggNRqvjv
HhtjyUX+ky1gB6gZo8pGs8JyxmQmW2ZENBOUqHz1KMOAaNJjM7TL4OceDGMpUKU4GIyXYS6ZrXH+
x3MnKM3TI7TQfSRAgGoqpTPCsDJ1KOCNwvHQfM8XQOtyY6Ut0U9owwVqjbwkj8+HcPUxdTXBv2b4
WmRBdgmTS30m8oji3w2SMF6rMZvTxSv8X3rlogR/6jsqHjgpxrl8CRHp6xas55zAfzl+hG8Pztm5
a3jCfw8U9uH/eNSk5tAXSmXUkhjUsId7ZjWz+IM8vCaDiKevsSyfk7u0q5FBhsS0epqruez2eS1n
6xSWc6xc1Q39k0sdw6el0khKsTSNdCKJokQKKZqc39qXlGD6dAXOejI3zuZ0M4LtE6sRskZevJDj
tsxp7HKgmA8S/9evUif4OqN9mc6fPoLLvm08ye35zNdwAFU1WgIjftDNr9QbkfotLhT8Fdz15n5s
7goO1MCqmV7GUimLyuCvHzYNl4ltr0AyW2R8+PqCUoHfic6g+oFFZ8zU2MRDbwOVly63TCFfhmBo
75yBZglE3NbHlbGjsDQVv3To5QVmOtLNU1gc11E6lfm1hui/erYzQuEdln6QfndGI+bIsccdr0NO
tpqOSqkRCQvAHsRbxGDMN3M+TichJcBnqQ2ikJQHYJsYTha3ktwW2KlrsvUPc9RJc5M2QtTvCqNT
2LkDYsrHn8NBVvuwsZOpNDcwbqz28NBh1l9NOEE84yhhmeZgWZ+OMQKJ0xaBRzlWflewW/oo3uA/
KrwUuW9BqniS7sb0Wm0M2CM8MlyXiHUifdzaHm0bC7zHZul1e1H96hpvm7vBem7CURJsEeca/uWh
/l07okVyC1ji8Y1KX8k/oGKUY3YBts+f4P7OZHCv5K5a2fLoPXCXK/zrXmOEaRLKLZK1B5IqS2sj
C+enFur4fxMSeI2I3kKrUwN7hXIeZDlx5Eugk49zAoDO8SEqDxaYtDgp9mdOQV56mRjbvByud+QF
xqMvPBL9HBvWUXOF5ThZd4Z3BXSAeTZwh00TrSfeg+49EnjAO7klJ8fC2lgt2EPNWTToUvmWCMbn
X3S8yLo6OJC1i4LnR8QJJ47pFsJokL260qkxGNeAf2nOc291SOz6TcQfxYgEUfY6QzsDZm8Cq03u
kAPBuBYkpbauIsYo/Usa1OIP4NlZ89pFOQzm5clMTY2bXgwb16PQKuQsVBMTrKAEKZkveyHOremj
UE5OUssqnvIAdyS4/+tdlO/uzpOdRIHOoo09dS4i2qfQKeEnDLBBDt4KRotP0BLcCRfRoAtw43UG
6f8G8S2vS5scuyalnETyaZHJinVMkexmftZAao5bBl9BFNaNYQ0le038MXl8kQl9giaGJsR5TuwJ
+2P4lycbEdMyxCD9M0C/5SklBYUZSkxJZ/XB+sl6DUyGHzvBlT6GyDoet0+78cLVs48dWxq9H+Wc
mDsvPujIEkwqVSGIov/3VTdyNw4DPJYiLUmBkid3HCD+b8ynQgie1JKZlZU7zu7hZfBf6aB+6X7B
bVj75AgqoOI4YgVaJAjCr6k9j+rNcrY4wZLb8USrPvGQfkb1APYqxGMDHIXUAm0nJ84JBh3JYTBl
ympjRcqU5YsX3NAU5oo0X8i2KDM9G/w6n7V39rM5egQlwxYrk6bm+p+6IqUBL51+89WKU26EDB7l
jN4+7xICPS528z39qAPfHZggJF8zjuCMKt+2kDuvlc8sn0sxQUT8BxgmwFRoUq8he+StC+oQFI6C
q1UcRis1Y8/SKJ5RXV1MSQHt/l300OtGRnQtVslkrUJaSQjAGMSAR2kUYxbD+7jZ7AlbWIpx5Aws
H50043vUcT8WsxyRMkvAhKrbkpUZPK3kjj+jV2AK7Sk9H1z539D35atvCjUvEX2qJe0veJu3XfyV
YQRofiAnWRe4Mt3YfATZMF+dxCnHrDrc7+9mJOPVps8NHW9U/l3jbGgFNjGYfL/TunWFATnHFbxd
0lj6Jdo5My5reSZS0incfW07rMfdU2KY0OuO9p66S7kFYags0JGrNH/sAEGvlm3H9VPQ2IJD3Ejc
j6bhE1gmOQ4oBw/OiVWpWYb0YcwuZy5x0V+LXVSzpsev+vhv1NfObGMtC+hE8vsqvL6GEWWcpIL+
o9+uB15QVmTz3YivTm+HrwsIrjCMt+6+RxlEEX+jAIu5HFpWB/r6VivuqmpaqdeCi/7Nw09uv+0P
rRzvnTTYm/DrAHc+c9TsJQ5SlQEDxqi96clV5cvDZLZkRmQUp9Al9mL/YlfdJhJKPQen7nGM1Eh8
9GjmLwQgIc9yPIn5EvDMaiUnKWkE806voUOm7ZG1XDEmW+FSMwEzvH7l59H+taLavSuTMsoT2Yx0
XJ3tT7xRDAJZO8T/ER1pC/szVy6g2pefyiFdtrV1geqtQ6GJaIYBWwT5OpFVA2OufQUX9xQE68Yy
Dg8QXrfuP1i6fCDHeWUifkc8VLrIip9l70aLQDthP0/lqIL7zG8ZHHDtByfMHtPKex4rBjXQHuVD
PNJCMtsNGjGejYPR2119Wq/RvXIv+HnPKmkYx5S2ifeqCfFlyQKUuplHK4ggHlL/G+L1nfyW2lK6
FtbEpd6Vmnbo9xAHcNWrk7s4NGJQso6wdJ/Pjvy9sZVMXlRHHG3U67t7534erSPHzwftda102WVf
zn+3pp//OKUGUTzzpNofBKFMLX6YQeyXvnAwdp3Og8qvmsVzEe5fP0P2KDWklNF6lHVsRNQEy4YM
HOU0/cjMWLpBtc7L3ZteqJrcTU3hLUJNGdmpiwuphtJrr4NL1mfFU/xI6xmhTpqLr+JPcmdvOmRw
GOtynUfHhtKkUXGD213ocIcZgVDz1/6IN5d3HdNreVYxH7i1IWY90q8mg8g78dlABM4pSd0c26ut
BycpMe2S+v/j4A24/GeaBkqHWC+wKWh6SRhb7hqT2og5epEpBtAjzbzyeODNRXZ0ZHK7T1ZPQDNo
ZHNHWcvKtK8CVf0O4BJoc5RrxxkK1bWKDxD5vBOojPqtVpRgMpspDbWDsdsO8IxH/Qd/fHU4eFcq
ip4sQP1+fp1opSrvHhkuGwu2BVq7/iAjLU9rzMJwYoc+blFYNIWQvf4nePEFo0CbNiLC2D5BunE3
mzTuPOxmUnbcVPrQ7JylCW2qsnM89A3HEnQLFNmKelVEGWBCPEC1z4Ac0t6W7XY7u3Ij2hPxrC7s
84WYRcl94c3ym6mdVobSBU2MWDI7931LOrC8Wpw8wR3gihY5WPlFSgl2J8ct6DJUO/qU69SQekrX
aj5IQUXEiOD9UklAiysStZKkilp8izUdaPhDoPCT/+KwvaBExRIDn6EBGig1FvcKBoVm2TJ6x5Nn
UN1juTVGR/a9tbd5iqqooYrRkTG5PuoT7n1935ieczcaEJ+nSX/3uOwwagbvVuK5Sxsxr+97RtDy
/jmfLXkERmjGwcJy4K2RYvyo3dNiraOMjJ73n+cO8Z0Ck3Twq3IrxL0OD0vfMdIwQxsktdXc3j0s
2CQ6VW/aEWSRldT7vODKuJDhqTToi2IF13Al0JM5TqboNrtAlIGSKRUPsjomurGQcPZbiPSKPZTm
11gn/GTRLU9AW8ocfqGrKPZ87oTDyuVERN9LrvA2hxCSeEpkHfJ1yqPAz7kj676efbB4XBToepY/
NqetmyQr2ZuoX3y+4UxaHBy7Lw3jlh1a1NSJKscuncHoJBIWIng5+UcGA7C4ABAVCx1niD0+RCcU
sgw+6JrA