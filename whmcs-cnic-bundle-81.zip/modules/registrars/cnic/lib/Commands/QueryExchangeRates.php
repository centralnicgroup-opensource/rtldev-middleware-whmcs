<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+WmQJGq75B/zi62/1UjZRrWV90iRcFLz+P5zH7X03x/sTyExzEc+aZeH6fYP8NtBkXnc/lQ
svEkUsnPn7t4EqH8oD+cOq0fWKfX3HTj3pJ72RPNqYpbGulDOzs61SIZz05hit2j9hLED/bwG1pI
VOr1MnxELZA6said8JCVwQXqh+1fNEBQ+5wSAQjEamrtbUVvCdnkH3ukxEd5+NvdtolRgb5C1bIr
WTer2FYzIT5kYiszKv/b2HjYAuTTMy2EzVBGzC9Yvie7bzyw+i4D44az5vixVcr29DWNP035aOn+
om0Hg0B/dKtqIrdUZKQrT7LfKofSEe1xQShT5eaIk5dzt1yGh8JaR3DK/POKesHpYUL5iAr+dNzH
SAsn0wsppcFkwL/BcC+T7+EhsgcPwqGhPNGuwY+nKiV6j9WRyqIgMeajoVbU2NmJbrhag+DJ9K68
ALKZ/WLbxd9m42drDeRbGsnWZiI+lPYYeb1R+sr1RS99m/+iOlOwj/g/oNGWm9erK6dlGhH4vztE
hwza+ugKAaWrkM7vRoCYv+GMHoIbjOtsrMZVjncsKpRdbvNTmobFvpMyB/bIEiAUORUj4mumcTG/
eB5RTj6tkNoGdybZU//QrQ+iAu2hMbJCh/EFsw3TiKxyBV+WDR24f2JDkgeNGyEBBaG+jLC2tX/C
n6GbmrZZOs41+QmfnJrQhMvjDqrImrHN0WwcVrwBgy8Y7s8rZWLs5VTFQKzDJT+I/75WOGsBzXWC
W5mDainZWcPDr8ZxZZSzRwKMJV0FSR/DiIQqiCdA9Mbh5CAnxSXkGveOH+o1irBxWwVO5Hf71No5
rVnvZN85N9oI8Erzu8d9M/tft7OpUJXiC/MjGD53Rt+BK1Lft9CRAlYiGHriXgn/b0f1x+8Fc/ks
JaU8q0VUUEALqlxT4tDG9xpOLlRdVHPG8B/axQrr5GA5hsrcRfNP+kLoeDJy9PlfFq/TcI3p1/SO
jMBDw1WPrLpmfaq5bCjZ6nviMUD2qCLPtpbvyGL4YdV4S6XsB7XCrrUZDZZljbFIdJs1Rn31bL0e
IRbsbAeTwAL+J9fVApvU7ocCmmPNiWkKDdyWyG9CMovNwsR+TSMTgurWPerP72osBlGJw3debORE
Q/dFlf50Ee4uHTqVFRMCStBw7RRNB//mRnBSu2thqzTFK3vsrPgN4tMEJDL0N6JppEmOQKAi0GqX
qWNdXoKHmx2iBg+E5y0MpzHNBvpxHiO6wpST+q9hmQaT6GcGYWjrh1KOjtiYcGwLj9d9OYd4pPzv
h/EyQGwMnlZXGa5BVtWlJ7JyA6ydDKVM58CDSTG7XyymN06enYzazcNGuGRnWMRSt6L1OxxDIonF
luYgp/UytIc777HXbo05r3rpXHGms7fIRLDlBwhQhea1LVeIr9ABynSx5Brn3OK67Il6ab5n94mn
ThrMEz1RjwInjBiEYflmvAw47wridvj0TO+5J9exqXFtb5rXLU00c5tlFxkbe5iX1Dr4nV3g3szM
98dTeB6Gxeny4v4/m+S8GFQHZVuRsaJNX59QyQTM9YoDg3VSWd0tTAcRLQH52wbUh0qVxII5k0O+
5nJ/Z+cWPddzgADoDveKbmU8IDgqDgaFiCg+deuiIdStt3YmQug/h3Lp0UsfNZZyhYT9Q+w950Th
PG4guXk6UPJCcfciUh1Typue9KrZW+ABSRxwKzM22d/CzLl+5ZG8ALA8rcxvM7/ac9CwaOhEgVnu
cJMrIIWiXLDVeu/2zVwUbrB/0SAmzWULqbr8v3rY3cDVgG8dYtKM/qR9AshMhiIxPKCnR4PmhLzz
VAPIkCN3ECClAoK11IFyRW7PpkNftRPI66CP43yG19ceycnI7/s7xdKvnJITk5gnpjAJNnpZILU4
6CYnyEiQvkN1Pk0XABfs8PHGj9eHY14IJUGvIymfIFh+o56/3WSLTwL5eEF48B7ie1vbHbDkzKjk
3qj5OWTwvNcrWelevGSAaj5nIeX3Q9MnlysSBgg2ILFw3xQJtNznOZeEfJfMBG6PZG1QGoZBVMtm
vEiDxh5VWjUaBqCR11DnmMWtnYW+yhWlwKfxjN/Xgz1dZQFkoEoHbhTdeRa+cSgwFnFSMRLCfDRL
2L/svvsvDwm+Lm==