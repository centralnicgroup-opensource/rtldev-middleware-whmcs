<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/mxlCyT1GNWs8afx12d+PGvX5VZHk/eHTm3GLnazgCPeea9CE2/cWDhww46WuqSmjLd3sQD
p6vxjmTOUSlAi4g8L4zis4EP67Cj1fZDZJ8zf/BJH3MiPHdBwAEE5yYbhbiqIIQP6JzzFSSnVq+S
WF/T/qn4V9ZzJ9LCY3NZrXlS0fSXEMD/nmkdRHqZIBs64nQFcLmg8SewzlA42YclBqpn185U9WLP
dgbfoZlzi3fyLof0gfZh+22hoXJ2Pwaadsugl10YIjPLInpJaQngkTCRb9MzasH+UB6LIgoyoMkC
cFRFXnui8y1yPOyMx1V6pSBYSVyGuAKBZ7tlwpwV2R+I/9ecotOboggaWPhA5kLaKd+UtNQPOAtv
7mSVJWfCvvPw2lcHsUv/QRK4bITHRCFeSSWYTA1jBZ95BlsM3RHyMDnQ+LA2OQQx3NSzZVP1905C
RU62wjfGwUOP8s6pTirfCzCgi6L5478SoJPxrHtv6e71HnGc9hMhgs7g8q0vULRmIewOAdww37IX
xgXvckuvgzqqL35zaKDa8ApXB7emIWbqUhY19dQbxDtqe5HebfW7AnkdZRSH+iXN+KQIUKKY9/xG
f4poqKF0m7YtjRGrMeZ9vXTJEKFGpPR+NPY7ZbeC/GEw8JeqLoIBXSKJTV/9Ejb542Lc2cZHS6ic
97EHCi9DkFkejw5y6uxfYa/AL2gDxyAdtOQ8ZcO92Av9P13DYC9uDXuiOiBjhGoQeR9SZfrdamvS
8J6onD0BkWmA1IqRDZXmgLheKO9wUc1k/zEpXI1MK934LJA9/W2pn69umSsbFMHuPzcn2y8aGzpk
XgsMLPVrMu/c9ngur6uiz1MNDBatRWpRPlljJyBBdVOeRExtVb+OE9QlWsZxrsFPtO/XwO7No3YN
RnZGGFe1lfyEirg1P6JCavzwhO9ZQoXkhiH5re5jk8rljNTZ8cPQ2aJP6a7VlGMMysJ6bI0kOlhM
l5oq1je5rMQmiKkSn9L5NMNlygOzU0eMd5LZXsaBAqlDek1GDMwTMzeJdKhsvrT4FOC4zyvs/39o
YfdFBJ9c5uUtiYM56vYXygnitNTvEVhK/Fujm0N0/xT4eX7x+zos+R7bXISS8seUjSMI3uNPIKXA
XKk++7v+POclG92h/3X6UeHZ/HHhfhZcV0MdqZ+o6rkEH/UH3S634rWo/h+eVXoAE3dzSUS/YwHF
/l5ta2MI628VJT0wVfg9HK9OxF9Rqwavv+kwaMYYOFKY+AGDRgq4waBpOhycCfkbLALQVS+BXT/e
5R577cwiuLfNLFfQzBdzezjDRBCpNp0SWkqK1hLhoNG79boNpSxQxTF1QIuXvDzdjdB/QznoTa15
yloNtTZtR4UXNZrtu75tN5u3kC0W+sKiY35YrlCf+1a9011zpDQ+zQZC7xfJcTgjdNlBejPkOjsx
cbCfifc1zw60nQ1of65EQHN44zdbrupea8+AGZPwvs1YblZiXf1vJig/bvRK0WUfbYUqjxgB1Vbn
mREUJceS3ji6E83DJJikMZ0sn8zelaCShovavJGrQv00Yb8nZeF1X7JRXtYWQVFEO7H4NVPkFx+C
ydQDbZ0NGftTS5gdi8cGJ9FGdJxTc26AksXQHDSWJEbr9zDA1PtCohhIlDoQ/Dw3aK7k2rkIAoZW
0RiSpfVRlA4ocUoIrIQpKaCUTI8dTlyVckrXQK1MI1z0XKl9Fn5cytaRq+rj3F2wiWZRxkThd0SP
Elmemg+4E9XRxlxyYOxwYGkOzib/f4RnMls0zij8OXxJzK4TL4pSkNzZ1W1O4B7L5QB4OQtAzuj3
p7PGszR4731XzWIanWvIM76bvPhO3x1/wOSlrdfuL5P3fJcOC2qfEgNN7A5AHyYebzH1+f7+4wfX
W5GCVS6JOSLX+Qv+9qU+HVe1PYpD1Mvkr++Npw9m9/AvmLC1UmsLzVhsuSxNz9UPpjVyMrvcfl10
TRFUHeZMgYG9kM+m1fkjp6bJjirFuntuf4WCaDZwLfam2FcSEdsAJqLz0bcDf+gnPdG05lIDBX2r
RWDg4YXXepby5HodZ9ysRWU0SmKi6LHp9n5PcKodXvWV/kAvu5kWrJJCwO5OoWKYjzSFCKi3JjW8
bg9/iHX6nGAd3RV6NG==