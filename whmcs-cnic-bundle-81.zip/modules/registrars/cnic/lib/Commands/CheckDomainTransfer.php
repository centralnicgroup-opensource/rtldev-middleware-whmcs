<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtP99M/36Pv0ceMmJ3FCSlHufHt8M8QZ0gMu6At6Cq18GDB8t9iWEHUCbDX5IWt/mXdUVlHQ
9KcwCEKKVTXCuA8URQwvOQhg2kiA6/DDLf/0AgUOlPdgXJB7xCU8PHSAzy+0uv2q7gqej2a8qeGd
FRX/LOtier0MLVClJXKoIYyZMMMpduoFoJvlc3GTGaGh9E9TETwuMByJx9cIGaj/4sGXPmrJUvfi
G6L52UQ//zlj0nsWHOzNi1SA6iEhQSudM8S7OkRA1vVVElh13H19FHUREpjXPLzXeYOlqCRXsUjm
XYS7/zo+ogeP74ykGV0J2mxdOCp6XXUpyTxKN2baNjl5bsUx1wwwOBZQJ4Ulgxa2KdfzJqcPsHuE
yDMww8qtfk2moW+fYTXSm2E23qIKxDhf9CodJ3FNa02bN+rG/R0W+p9AqKAz63A4Z594bXTWYcgp
PfZY0CqEJJMjlu6PqMbN5fOfsTHxTP88ulQSU1Vp+za91TxJlCN133QLkUmID8QoLwPjH4qoRMaW
4p8YcwB/Dgi16BlPiakq3yPjH6OcFVVFHRJGbSDSPfzmGKqFGZz10+xYKs9fN5G3v+Isd+Ac2i2E
JF8+yBHGA7QwA2sEppM6n5HYv8r+fkycrZ+5kgBfz5F/2TRPuxsqIq1FXUlyzR4jG9REqkxaUjbf
Q3K+q0yqEGncGgIvYWXKAVof8CiAXv/geb5OnluLd3hyhWtjil7uOeb14fV5hrfzTcX5o2qL18Hr
kzAjik2FZiTQAOWCTSOoZk+PV3ttpompuCZxpsCezqr6zUDW+ERRb38aM4jWhc9VtAg8BQzuuyNA
JQeRIN2oHwi9hCkI5bgrqk/tCjNLrgv0MAsJfMRKZ4yl96QspNJ1C4XGEEPXU/BS9EZl2kTZ651Z
1yVn0jTL9CvoVFxEu4NQ0BUVwTWBthxk5QwpZ5nust/92pWFWZGRgGYOU8ADqZgtmlKQtux2ZuNb
Oez8EXvTm/W36D2J7tT4QX7NkEOt0KMJ3AKBNTt/6x3WyVQQT4VWeixBINyzlFtTUczo481YtF/a
RBMyjJQjq0ZKV4Maa4qjgHXMadegPNwS6rYf6qY3+JMnuSo5abHDCAvznB9/1Of7LSkx/OkQIaq4
e0P2DuQZEs54txFfWvNpDLElbMqo8aBhu54O704PrrtBLdOXRuP/+JXr1UWO7DEkBBBUnTSxHC+K
/D88MYKu5pRV6IWe63RMJPyoB29QgmhLj5oHPm9UlqBV/d0ionL7J/T2pMpZmwyV4lPsHYKzacfg
zeUyYQP+WpPDSorMCrzOWII6cRZ/BklIYYdJfljHEcG2veKbBHTEKPgDH3LstbP+pn/KIImP3Nkv
WKVn8JuIYlUCkAmNrSTE8hNFkaCUd+nYquKQAz75vQTzLSCfvUG6dJMhQhAQ2ljHpLliuy7Cdj39
hqFl1mF1nubQM+qDVwUMeLMR6GIumg0WuR35VurfE6e9ZusHPuUHeKDdcBAdWDJD1Pa+Ts7zJ6Ul
NGuf/fa9JeAbSMpgcLRfJi9JEbmuqc9SlAWfak21E0BHZzJIW5afPtYbfJS1/pA1nieeWjjrUuLQ
blNahJWeYO+60M9J6DTTvNgQOBtl2t3Vg4Fvx6Pe82Pld+bID+sb5EzrxsYK7+I4bWMJofbRtBQY
gyXQ0j528k8rwLgW6s3XW9GYFsd4sMC/QfsD3bgMaoEWj5DKIkr86SCWXBSUuuPbjXqnYLmqJqdu
a4zCkuzyyjTrz8dnzFhIZW8K2738p6kWtd3Z8e24o1QMBMYPKjiFlCMpS5G8B3hxv9xkfM+iFwlP
jutiZt71jpbC/+wSOdiUitK4G0Gn2rzdKDo5vBPQIo9WZtadXtDVqyvH4xoReUFaOnHXyw9ScLuC
/PhJEbx5lc6Dml8xoPYMxpVCL9E/+6Kgoglfa6j5jp6o/P7qaH5uO6q2E/X4kQqoUIS80/MFAtMl
4ZRXQ3fBN1ylsCUvFuWpL/Z2EB9FsAQQj4HQy+Qk6lI0sKjzNlVBf3zB9K92B1TX9zuty7qxqla1
4YBKtNrHlS1xYCDPzQF34kv2mzIIknJ19mSleAgxwlWle5lsGp3o/IxdmSvORCtz09+jd1k5PaWA
yJ98QI7+owAygeWB1h6UJnoQo4maDST/vXOIFjA0qR572Obb5vEvh7vpUczXmUgPuTZtl0YzzO/D
TAfRDwGgqDpYVflydGmr8GF+wTuDV6aO+gOQznkamWAB15H2bJQBIrI3JyAXYIs8G7AycLgSCeNc
YO6idIJMeHx96t917zpQjn7DSquY87oOkKrA8809pukmdyigNQr3vK9nVuT1UjdNWzJeuUJTJST5
Me0++SgRGcYnveFx+taMYkbaBuupV/UkO4v+rf7M9gpCCw1z72lkFGjiH9Ejbh8RYGJYrVaaZwC5
vRJ7Th32PVOTIkTDkYfOVnjkAKs7+NXgTbVYbJ02bCOCu8lZTgtY/LXbiV14NYeIjU4NY79qLBdN
3fHMdHPCO6w3gDbGXYzSEwX0ouiSmI8JCP3xOdGuKekv+wEoRLRE9W==