<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+StapXzbsS/UFi66nRm1r3l+bwNb0hJaxUuvmortj4v47l0opdrAEoz4r2hdBuLnggG+E69
Z84UKwEjjiXA5olALN9tbMtdcA8r6Jj2HzeSReT6qprYus09hIfQnjx24i5PzKb+hv3/kbbzEIIZ
zmotR/cZLXc+XqDm190Iu4uH2xMpNjuorGdLjEueyKRGkV/XwAcZxbJzJIjiCyQbn7sG/bfyq0QZ
0HMiY9oopJHDbbnxgXHX4oMCS/aN5kTaey568ahMLKiSqv6iQhdJ6vILlRPgAZ1gshLbZq1J8RZ6
TyTZ/q0HeOwuaf9SEOxze3VJuBxhBD+d1oWH1NWkUeSds+z59DQIVmwcAXPULWp9+bH/4sADWFZH
mL4PZWZfPBNLNci1zkhD/DA2O4E3nNiliV/NIzCGhZGGeBsqYJ3qvmdsa75mNeESfWxJw0bCa5G9
xnb3N72G+p43dfUS8b9QL7TWMilHKHWiTy460ch0+UfZMmj8MI8fIG3Z9TeNbOa8u/r+NUGg923v
FPnBA+LtrxcHuiv+bFpAHcbCjzGe98afuewuYghWNMf1HFDRyqBhtIK7weA7x8a8f1WKz9+DKdt3
r2DL/NKvfT8n+hJkqNzRrcGCtRJFDYro4ityBGopLKd/j0+2YTl6SSc1dX/L7SO+0DxH5Z2WqHlX
q6VGxDDc8+JHcp0pj50S/fs3xH+y2JzOb+f4aDeti08FPXZO5VaG4x6kX/rjdnuqi4TTMqXsugmj
ZU0LjN5w/SWFrVgXtJ75zq1BCMDbeYF3Uz8fhPt1QK+pNDpEPQRmNVyHVDOdofT0t/rL2YB7jcYd
Azns0dFNDcaxtteOsHZkf9FUve7LxH5ZhgBnVUnUb5fuoeIuxEc2byD6O7Let3Q1vHUQmqCEGf7E
v/lSgEV5npOVbjQd5xCOcJAZINLeSqycJTqLufygn70I7sBl5dVdb2CumBmqKx707M3yxC+38Uue
iARU3gK4NAiXGz9S6IRV8LsYppT9FvJqZxhwyRREK8HGlpwCr7lDKuhW+KxeI7dTFVS+E36Ufid9
DDo81JSIWfdt4lBTr+SUZFv7b9K8B2gaCStB55BKGPyrHtReh+U7ZL6E920lqGijH56zM83X4+YR
ofBNVcE2cry30P8btMZYuRvCuvNI2q+NcKZbWwiGPcMLTk2ZP3xuafEFld2tV9h2O+xJ6/1DW42E
yX5Px55KafMNIUOMAu6THGziZlRtBA1oYd+lvcaqFbIH7T345BlIxxx3+dMGN2mLXEIj294LNip4
eDR5UHqz6BWTmWNn+x56lbZFMU/7bare6RZgqe2pDwjAtWT8VbO/XOkBMe3a5bRsu9UOj6IsETFV
9kzSb1A08dxdsN8t7O/Pi175YRSWSGjaQUgYmDfsZru786PTmijQ7SxADyX5cHU4neJ9mZLXnqHD
+HyZ4iqJmX12mfaasde0uUHVafJNfJAzc5ys0qWO+VOnRLNtMHVPputnmhBDD+xFGuYzUa7+NJQK
WRCXP9Q6MtJJCrxJYjbI/UfFWuLZkVGlm5PCOhyK/zdAzxUHdr+V2RQCFqIWyIaBXFDwuBzPFmfw
4KtVcvhTOWkTbbwHgGPQfxFfb88b2J8T1omnEeBJcL55N0wiqyciA+8fM6kC7o7xd8qGASomSSfN
FoWrlYzuJkoSAA48OGlLhoCY9xZAjJOpltLALhYGjaZm8Px54hnXzrxhNSKUW6+PQ7ybXuC66bRr
qEsTfiSqc9cWtKaUFR3lzCsg4n0+7wVwI7Y7vsigTrziJfzku+OA26xB9AFT2fxZyw1iYZ7xWY/2
pDdbRYZHYGwDwWTCJEgPFJSYPrnzZYytQd6eafe93uKe2eBBqhjFTg/5uC/H01EXA58QAtjyXd8M
yaoT0JHnptDb30gwoFSSy0+R7s4+EYhY4dvXfNjdH+UeYUGcqcaH4vJzy/V7BvySxeENSJJ0Z+u4
lhKrjRxmkDUy1Me7HQu12CGefBnPnUoREAynlGLWbWqBUf+TlX2nJ2+PBM7XG/CXzddF1X4aVOdu
w4O+3vjVrWMHhMVqk8Qp3M5E0SLpK9y45stRLBY75gvyyQLHiFwe6dZ54QlV95ZxxmyAMtz0Q9Yt
q87ePuc9RYIaDoFJGPNc9VCqipQ1SeUgpxLY2fTN21zk/pz6mdPyk1OfDsFlkEoEofA16XGNqFB1
ZSfo0j5Jah9dYFTCpgGpPOuj4Lj6KP7ejwZinf+IQKLnnFAwBAHn+whf+pwjM30wfjfr6gxH3jyE
rNRxQi7AyHR7HfIEpCLH67Yh9bCdS4Nn1JPL+5UvCc/5oqqYfozxFQsGV+IdDawtqAf1rkUa4PM0
dvD7a7g0L2UwCv9+9EuqEBcX11kNrCNAmgXEsFK7ZdmlH7EKGDlXIUHns2yz1eOI1y/Im9w9Z5hX
9Y3QofTlqPykxGE6ihrmgw/crie5SfrEOs0vTHIS5niJfyzB0GviVGh1UkJkZyTiEa5c4VLwB0L5
mmHaXkGC3Y8R1Cu9KOFY62w2ZaU+LtFy9xDGBhznpqnEseZNpcP/rE1Quqw9TeZowAIuV5KmAG==