<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmHNbOGik6shAUO0fsgxk85g+JvbV93ArEyOm3BnnDpNuJtXtO/gBY788GcSXSYRaQpZqLko
eq6LaCOlfqnQbPVh0sdiORHH7meCJo4L6a+jfkpdreA4I/RcyZHRs2ps2QcU7HPcM4m+dfGb1Rzl
mwxU6KsjLuuX0jwxFxJ+wOoDVIscR86nHXpKzGRJwduXWqDORTgst9aWJC0MlqCcpQh8VbdoS9Zn
SfG+k3LISnw8MNdW+Hc26GKF97SfdPo1W1scqKnYvie7bzyw+i4D44az5vixPscDP3u9WmgTS/In
oo1mg1t/RbfllFYJzmEKfpaMX/TV9/WRC951CLf9xRKE92teg6FgmzoNlH9RwuYIU0ItGG8+psK7
GAk53pIuZx2AcZIdNT/5hS+tbBWW2i2zURTC9JQKAJ0XbKhX+uIxm1lcfUN7pCMyk+M9iPBCTV8A
6EWTtNDZI9S4Fy/+O50cH0o+MBVs+yG+Xk6WkASf0xcelKyPWxEZMk0krsK2IFeSEgATMWJc012T
0AYlt6pBraMcrJ26Ub0vV6hzzRHd/GVvmPkO397pHBI5nq4ukyJJuhg8BYKDIl0k/qI4vr/cN87F
nTu8/j4zX39V7QBF6L0P3epF2SDC0UytxcAYHdfOB7nZU/+qMcVeJs/qinHUOj6iwBxWGDtMBVE2
01CMRJZ6GceBg1xYaIYpsWTKS2/YW6GWPI9uuRkq+QUkHEGN/jRsN4DEpGAFAtKob7G7popVmIg5
NwaEqBkwd+AUMpyA58CkZbWg+jzJXYmojVajNzwsAieDshC9mebieW1IWY1Klor2JidhcC68ZohE
C+jWTSqQahASNddrtsYZM9nV+ifnUPlRNkMOKOes2pZh2yprWeM/DGt1JZRn9Yg4Imnmg4iKCre7
/E/9wlW257yIaYKsJ+8uciN37Wo5e/syqnoy5Kv0n6qajQV0ZsvEjpRWaPGdIyF7qZxwNbBSXsiF
luVQhCzS/v8J8yHHPQyi839Ur7KCGgaQ8fIKzMa2HxY+uU8o2Nk06y7ORrZGFKklPq/xNT0ip9qO
rxwYvpw4yoqvH280jSfjgO3/xob/Xe8m+byCyZGDtfo1k1+44Dl/JOgnUguaosL50RJXmY3UZqHA
vrW4xQ5v1VdEtwnOsI+hCjZ7oOWTpX8O8hA57qWWCgxQsBClW/LC/WLPZe2cGCNWvTmLdpDjADuo
+zL3UvN5eqI0vZggmWEJTT65cW/V83hK4IkAzpAwMTG7DPnuggmWEmWrCd3hJqNIJmrW2lk+FsJS
qFrS0E7a+fZAW90zDed2/DqogA9e28v8T/85GViHbNMQiYSp3qx4PdM3HqgwHRPGIqLQGk7DK0Mf
VGoooAvrwbFt+yMGQd8Useu7Vuttacmx+eDdShrTXzi5P6S3LIZ1mNWQLNyItH487wFg6n95B5rf
OJRYc0CCtOgQYpkYdxr/14QiLJGspKsaAlb3z3MVX9ezf0O9gw7V38h/HPRo5JqRuLqg6awlLvhf
9YKtgreZS2ef1K0bur5gjT5Gav65pm5cU8WAORDyKvwj6ZIZ+UHDpjJs0dn2VYffB8u9SSsWOR9n
T918g/1xd+OFBbcsSyjwmHUh1JDaqGEZTVSt+hG5kzpQLNAJ/JtP911yvZVhoSVE4fjfs7mSprqm
zP5QzHUmL0zWstAi6aaZHBkwFcWDBauL3/lbciuU5tOHX9XkTh1+XlQTnITc7O6qgxUWk9VoiqfU
TMmWUiTdN10rZ00l2xzrdbe2qTphpU5clgMia7HweE0X6WK=