<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz00CKpYxObZ+x6aRnMo12j1m++FPEcd9hQuu/7fQ3D8eLwWb05oJtlduOz2IEDb6zJy5ym5
cNrkvFGvnpUryrcV4kseryN69YL+nznu6ROk+dzEcmfFKAHBTDNhSlEa9A7Kw6lYQIO0D4BobBX2
O3u64PZFnaizhUoN5w8O6zY2wfSF02WcC5hg3K1QD5BXLK2y4MT+SxKsZo77hr44WAI1Sqh4C++V
N3RLiIPwiFYqk0gjCxLXSvxCZy0/RxDKLl6n8ahMLKiSqv6iQhdJ6vILlNnfL56t21d92GN8e9Yc
hISUGAQ4KSDRzniZ5XfjMFdxwWLDYyVgiNIcQPiWCBRsaDVuEPF3EfNeTNXrmpqzbStqp7lWACkw
GrBf7s6bEmrhml+UVto+RdVELo0UnywMPf2quYaqi9TTcAkKeLY028uhZvoFwZj8BHzyQRSOCWXS
QPQ9KS/AQVn1TgsmCeIj95FATGzL8WxHtbGoGj2z92zkbknc9cSCQJNRWeJlDGNLb+zQ8SppwpW2
wNelPccBR+lXUoyt0m+XteRvV/KFW9Aw7tJeUrwrSTzSOMrxnQzD8E3y3BP6vZzh2iqQzA/9/WY0
klXnAZwIuoYDX942UriLcMYJXANpgU/WqDVbIDPXORoxxaFDhR7XesktzsmekJZwA03iOXGRP5qd
u3tGvHINqg4PmX+TtSddJjSEf6Q8qdU24CIGYLlKtr8t0a8dlB0/ECbt4klcvSu2JOv1CyEJe/NP
ByVyOzmsMIbj4is4u9/ArGwkKIZhf1vWDx4rVz7nOCFSeQbSvNFM766JZLEpq02wCFtRz8M/66jJ
TmzpwrQFsjnEFrCemiTaypkE7adPVgE0tPnDQv4mmfeTX2xe72ZGJu51mn05a1qLPVpqI0jGXCEh
8kjQYtY6f7uorm0O8uDC4Z6pEDyRGCBIvagsgKYbxt4I5pwrH+eOApuU6aTpk8Y8oavbrVexO5K6
yPLpXaLdjUQU1F/AvYk9u04gPIc0exsgn5qZtytxvFL1vIFYNhTR2mBtFlBiAiVhtVmV/fiMf8Wp
evcsl1Schu6+p9JDpTfJAgEx+OKEATdod27ATVWPKv4obPeKktkT6IEPr4VWLByVKD9wi5Hu23Qr
MG//EbDPXir6+yVw7kU9Px04xjblUHplmsM3xxTY99TK8u9AZ2GLuQk2nyUC9I01LIAXKZlX9Zuc
mEfnLokhtMKfUAek1E60LEEXVcfpBYmeYaUCTiP9L67IWmYpRNRVlu0YeC1CZrlcAMbbfBix9EQQ
C45N81jo6iPokE62euX/7R5yeceiyN4fUhmWVOGCMJGzleq8K8L15Lkc72Z+/5/9rtJuech+98Be
dMyKUu5Y19PUebTR77yQBnCTgDlFWQfKrsFExi+V4HuqmvQNFipttaRwIPZB5cYRrZEGu+jStWMl
xFezc/8vVq4wSN7SFzjh/U6g5ou3yi2kAVkPbtcysQG6F+mD/OOzdBcqAy3NFUFoXC/70TsZKWyl
D5cAsRdUGCEOrms87Lz8GvE0mB4aClht9MEVCJwYC3QbiyqncL1IJJB1Dd+4NZjIvSPxbE6Mju/t
HgM1o4FKr22LitVfpMxayoBy1RJRUtIIui5/jZhQJ9++UjG5eY938R2nRcFIfHUfSjC8+/iSeaq0
mDESd7KOukthL94WUwvo9cv7g2Q84PyQD6hJK762hrpXczYLY2YUndKwW3bvW2YX+ml4MldavqDl
bEPhaPthja4em50ZNNCQnx+74K7GJUUu6R1fhLZZ7l2yxZD4zm==