<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu2LKJ3FUAe7bYR44pPjHzyugiZjJMiETlYLfAx6LrdLahoBgmEOR4I9h90oqUg3SvG9X69V
24ymmh28bVLjFx+lm9hWICfZevRNveNjbySc878SCx9mC+SCi2QOHO2SacysAMF2svP2fBbgQKWS
9Ubll3Mx/cFkPckVS5MYA2dFY1h4mVEHDHiDeizDRPhGRXGIH9O1ZmKCxzaSVIPXiGcoS4r54Su0
0G4sU71TdIs88WSO6R9cqdEWZAiGp3CY6QAMxsBcoWUNtphwmGqGIJqNcpi7OhQJs+z8frFIIzxB
m6n8I//Bx8UO2zaBLHdFd5peM5N0dFNzN9J9P7kzL+DbUObgaQGIWgHrNnT8IMjPlIBrmk6q0LnU
YYwh6X7Kud224unPgZCJTsNrpzkVdDWk7PUOR5X16sVCH8PXFzrfOB47/JXjT2wwbr5Z6t6hs3fF
XjsPlGJLRpTy4QXO1QeCnqhsFIPDtxkGBWNU9g8fkd1qzd6f4H3ZkUupn9caArGJ4PL+hgHrKomg
WKDVgjbTNy/XDSEULIs+5phHmMz/pIr1T31SsPI9wCI1YEJzufXQGVcoaIZ7PaeNw9gL4OXbpTWs
SpdvDQw2EYoeV73WlspBV25ufA5twO3v4ML1oXzzO2876gxOxxhg+P6OC+0aCbKMHCZ9Y5bmFQpu
gVFRXpPDv9ajOw3yzBVV9VV2tbRQwRlnDTc3RmL4owXVXBiw8e61ecH9guOo0R0z+9MKavMUo9dJ
8TPQMlcrxzYLzzARKZ441mcOMN2HFpgGOFwmv+7HoPbN/K7lArwFhQhzmszHRqmEXaxGCwo6piV3
IpKWJhE/6gDDxrw41fbsC/JMLt0/NONKBYAaEr7oNOqZ8mFUATG7O0goRHSmmkBGy5R9pevsOSDn
CuoeY3/5B1c+P6Y2wqo2HEduow5JXl+KQagCIWa2gMcaJParZdCokgm6tCb77RuvKeTSrnQ/2wX1
1fOwreNAUpe/iYFwqgJYUKPN7rSEN+zag3U6IcBf5tF0dGhOEv1GhFhj3SKbTRjTUzW46LjBymaQ
fsATB/NBobbS40JuzltsccmWBA+rDS7h6b84AjCzA7tEyAo0XIGTrOkmc0BpcSMJWyIyMKSxAMM3
dlbub4P7WC8MaiM571u4+ewy743g9UIBt3q/NhJb4/TECJMnDuMymLS2pDjKuNiarUVMWX2r6N7W
XHadrYaZcnF5p/Z0gb7wJAqHZZMCxtUX2vFzFLyQsnfIxa4fMgqY8I55yNv2gYu50SNbuqcmn01i
soA3tolVnWs/2VsyBcsw7lhpG5wZfSQO8Npm9VVSjZtqhGESmUI63uqWKlyOj2VfmCyshQYF2CG0
rSDN+4U3dJUZbGlpn2xjgDe9AHSupLMUN4gufi8EEwtCVXhfxoDhQkaB0hnQsCp8I4teiJDea3h/
hcLCzNSmPZd6QCNCTT7MwPJuAL5fwiZTOeXIdhM+WU84wPUlyKleC72bwEvqZ223T0qnDQ3yxVkw
QRGSiKTfvfDyeM9KvQ7Gc3gFzKYL9FlgwqPwqMZk8flzbs1yPalyymrGvs0nSijaOMdmK4pgdyOZ
eIte/Z+lpTeYjNfxgWkjKH17JxbTIrqr3KX/9xTxU8NUl/2qJH858x6aHbCJlqnVhGEe+whANKs2
Ljh/gIAZVEtJ/9bmQXPI5fPgbmTBHT0Dm/KdQg3F27CnkFv8k2EIZ2Aw9ngsxAR9Re4LVvjitNqn
xLrN4I0MVtxgpH7+K0eCu8oJ4Gw9TvpJd2nLbLS9oaMcthOxGQqKKnQuHDSvsNQq5axVV6RJDvmY
3l1GJku9xhsDli0wTjKkJXjxUH1wBGMTArx+wk3lSqJb74hJx8wcfsUuH7jaZVzbxPjc8yskXB0P
HW10d9q1IjFpaHhGrWX9l0xSIWOn6t0my5ff+R8zAUuLezQVIXU1P/59R+OJdPrAVu7+EmXCQ9Is
WYDQBOuRHBn/ziwln7GlOI4poq54jPwMpz7Da65Yo67ZzFzvUuNlg97ImWCCfn3PZ37D9M8+Slng
wn+EHvUWnY4vK4DQrv77BW8F2/fwY9A2MlItJWHMAb0ufqamTxwVZDPyhQCB3lO1zcfcBUBrM9mO
bU/ErnfRDTevA9pn30qsqaWt+o0o3i8ko9UZ0xy0vTCC3JXiLPZQB1Kz7UmXtN+vg1f7jCC6Z0fO
LVdcUJ1VQJyXC9sssv/9K+3LHpel5Go9N8vRuTAmpQMhWwDYLtdNGK/QHoaZnn1dOwSp78/OubJG
RBzEaYF71RJwX/ET9HTzsmaNg4PYQtztn4gLFP4P9YlMgSO1YAykCA95zdA+0Ipa8zCpbOWkHJHu
vbwJEr5nMbkw9zIQz+n6TxVMXcHg1PHF+B9rB0xMClJ+lSLyTqP0jExpOwZe4Sc/