<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPondOagnoLPkJDJtQHYhcoyH9PjSzHHoygAuxGnD3tX5KbOGTuNjdhPQgutfy9vzD81EnX/t
5bTH63kgL2RQOmF3zl/kZao6ehF+tNDswcLp3YYbwW9X+tIBqF5yXvJNnWm5LUH4ESXg/oQzSisT
s+V2skmErVJWEKvCwy2b91xmKA8vhC7QkJ9MOXektCoqzGtqgWPrIo4rJmsCxiU0zmCsFUQEMj8W
OiVGfvpbWbHcLD2BYNRDsUYETWmbSMpGlAZG8ahMLKiSqv6iQhdJ6vILlUTjDN0bOktu+Q/gsfYM
k+SI/nIRSzL2HeeU3Jjb7x9D8VJBS+nTLnY1b6NlPnJ/DQ19jVMfSEZTP9QxhrBJyPzDq7cvI80B
0fIKSfoeYCe2UX4T8l2CkvFusef+Cea6IPWve5G0rDj1JP8JLV1aLrXlbC3ujJj1g19QebQBpyXC
3F2VeycoLDjOpiiS+k72i1fLyGyz3i0gQ00RsRxm7nSpsdPl53t2w+3/Yn4YJS1tPK/P6VUDP65j
zpILoZx8+Q8Wwa3BjO3dcCAlCl6y7prOgR4uYrC9S4SG4sWcfGEBYjcIodntXNc/mFDY8kJ1SiLK
rTxl8wDYeQ0MCzEhnBW5v7ZFb3j9L+hUVt3ceiQNUoh/Vk4l6JriePzu/SwFLSH6IVzQzs9SH4G+
1mRQyVXpKvTC3wr1gMZyfoKnnU2NoTTM3qYHyj8P7kxk5VTBFdXtJ/YyzrHcsMQuWpk4TJi1Fj0I
D68FEMIikW9sJ3HshfEXdUm5++7bFoGRnP2pFG0bcjiw587s8we905aj0aF+uw+YS2kOaQPNXkuA
bd71JiUrOHDy8wJjAV+6DA2BpS2LPAhDKwc61hUQmweRYqqAIY08fULsrh7fbNJ0kyL3SYWuoCdN
nykpOKwbRt0KhwBgPR5KzEf44nadwPdtNSYZlHGLqTD0aSBoxO48+ulEkbU9UdJiin7VO+NNa2CJ
Fmyv06IQLoZyI4+U7rpUN09YVpEUDQlpZDh0lvVf92IRNOpTG109lV1pKeaI3xieGl4SjBRXho8J
E7Mm5f3FxPq+OLEmECreK5TQdRBZCSVBZNu0job/q7XT0h1C7BhQ+gq6eb3K7F69WCHcceKRuFjd
JdSTGTRrr87avZfLMF58omMfovS0nMy2dkQBRcuWWkioWifmaeeGrZSIi7CudKMAyO9BbgbJ6yrB
UnKsqY4N1NRCsxI+xWcVMONySuOdED9gJ5fGsEuPNUGBj0K4SLG4O4BTAjDHiRIMRpz3nLSdkWWP
bE/Ri9xGuajNWgxtHSqnqVLrnOuEQD4Pi8GeYCVx6SDyYHmK2soCW6/3JYqL7GITb0fsA6GG+nGA
ednXPa62YDNuHDblsY27uxljhhQfzkQsIEgcqCrVlP5jN7oMIX/Aa/l1phfZj2Ww0bAqnEd9r0u/
j37+ar3uE1ai7Tmjy7YzpxstHFgtjPvVyvjAQfccxJCKMCvC85/QNGC9qEe5PbwtBipbz/ir8ndX
I2ffNS+o4m74mHHKjRxmY+xStfFVoEfbduS6cEk+HDBqp1ghE76pdm5Wm2yo22oF4RytkHdsqGOx
Xe7lO8IXNGlxDL68l5Y2KiIUrTCcMUAizY5ohW2C0IMg/0LG55yv+vsYzIa97li3x3yug8bFUv/w
eRnbnRmkhx/CzR8V12N/JybezzbaUN6S7B4Kx+HAV0+2xNg5cAKkpWEE1UmAJNMY3YLgxb4a6exW
kHTGW8d1rNBQvcb30HWnDwuCo4NULVM3iZ5jg2S+uaqCZqiFYgFQeiAfHzj6nkWgxKgjNUC9WeXy
nMf39gCNv+6WC4TWNUjcmmGzgVdOJTz/DzioWC4Nt7BSALqizvt9aJyQCCgTIi/cRZsfElv9j/uw
VPjr4TPL/IIF04qFUbjtWnWJ/ohZbiqtJDnfiUAvXF0xcbfxFSjh4YF7cm2Cvl5yxEwgOLzBn3wY
WAnhjhbiML03yTZzba+cyV/Nq4T+yYl1OU5ePwDpTkeDMBnqUrDYs+2lPjTR/HrnO1hLCFqgK343
pyi0ukxBzXL0A1eAMUqdLcDaABCkPkteab62xgF9Xw228reRUn3fQ/ZPV9UeJSh2BYrGbI+FIKL7
2kO7v4XWjV3on4cIuJQa4hjyvg3CkIYGxTGmTcmivzcbCEp0+bscrh31PIipH0rsxlnGsqC5w4oP
PGFHl/CPMUGum0Nn+2qhLHRzyCj0O4PzT/6Y4Z18Ac2OU7ffR8TNOm5P3kaMRVooCknR5PdHlOOw
kFX1jHg4qsxDxx9HGv6IwXwhCdBTWGclv/VCEcG2buOe7GZSKnZy7+P7xPrCPXxhVbMUQBIch92x
vM2bqb6+seDgGBj6T5Jv/Z7Fhbzo2mDUc8DTr7cpZTBelgyQfiq=