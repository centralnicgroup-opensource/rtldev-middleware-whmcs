<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPynbLx16vQk77wd2ayJIge4fs6B2jwZrLPQuyQs2+xzt29/9ZDE8Ot5u0pU/tm7FeVTzfVh8
GEJuevE0ig5HV2yfsoohmQqa/dgq/EYXZU2Tc7Jx1o9HTSn3XiOZpE1KeKpa54iWpjo+4I9Faeci
OBCcP3IZUhKPVh2xckvUFdqtRA3lWLgRk1ulMjF4ivz8kD9rN43ORUXux6IzRKyH5m95RsvCrZI5
fhfxt9uSL/JwpROL5EvHz8VtOhc4Y7kNIYeM8ahMLKiSqv6iQhdJ6vILlVzgSBvNgCfaUUaDlPW6
yYTtbxFuUyNkJKcTYAgA5t/9yV8p6QG1N8DgZIiTtdkGeTQby35w8MWJzJEfZM+R/irX863Qpj7R
DYOGJDt2ia1545wZYHiCa+oMlP9s9Uzb3WNLvR81O7RTkWK8nwhCqLdC6SDJQvvVdDuxnsyofBmg
xDXjyFibSjsGJ4ix9w1jwftOFwf0DKAe1ujdufVF4VttsxLyf6xCNiENYLPdugceFU7hupceHtmz
ZjYBpnEWeV0wAr3BQ18BfIBVXF+IgfcqFiNfbvmsu549PcDpynkuJ83t1e45OZZEertNgdYqCGn3
1WZAw/7rJsjLenALv588qga3v28wTV87MBiUHd6wunnDgLnaIpiUl/DKlZTfWGdGRTK5ktjGxqhD
yD/Fi9SXb6aL/1AiUlJjY+2pkTiD5YP0p7c92s5J6TNKoRc5UctLi26Hd5KUW1268K8Sx0WtWrzn
IU1DUuMb+QJhLmKSfdov1im39Om+YPncUvgP+9DGMeQfmZBfeBtMY0NsMh33CGcHFtFE6N3Xf8XI
OUZJdmVIzFs0mpyDCyOsbIOVuZOfgf9yebE8NLQttZ3Uzq6hVrOdoh9v2YmF3FvN36FlrLmNIu+8
poMXdNdZP7cd6XGwJHm0ZeNAOLWXYyAisntcz9cHGND2rBW2gDkwJQ9tDWg3IGXl66vivmRh/YOP
8iNlP65n+sPwKlymW2bmVmoibh8mtLPu6NyxiTrHV/pdRnrUfaI4u+A/CXhRXkhLbSI2lvMuHLRy
kwwvTTFqC/hQD/gWUAOqlq3670BASR2N18SeDquMhFVdv/RcWMU6qPfg4FudcoHx/SV2SMXonSi0
r2Wk5HMWz/cMQ4E8WpdsJ/sfQhqSEqNb9DqzYEYlCyLQqBYaDI/NoxOZmg2D6XADn2acii4dZaXJ
p9Pq+lSG05DSM2z+ChE1xhRoybAohtTpND66C5fezmco6XJYN4lXI3s9OYiLjqWtjgIQ2Dd0ke1W
C9WACsJo8ENxamZjtCalqhfj0VX/BDCpgSu0WTg7LxPNUIm0Y9H1/+znpOsIGjgUleX9PWi8Uiy5
z+9F5EdHJU2VNUH+xAZWKs9LG8WEU+6fou5vQHq+9J1f6uVOmaG0w0V9GPRQR69enlBLWgVmgUy5
BILLSdZHIWYz1HO0EU9Hbu4WAw+816mu07XoiPFu5WtZdvugPOzpPcw53guMYSiWywF/wWqwp9yb
imCpYUfY7l8Mo9Q2Pi8cPaUsOvTVqqjcc6JHpmodBtCFITFVwhqOsvJDAowKGnSH/PA4X/Ju3WAc
T7uLd5GV0QxykmAYRxkw20S5CpyZJvDEUiUH31t4Ngw/gDz2jmE8Tl4OiFUWvxUE+VDeqXCfeo9W
NEmOyliqm5NlyGG/BAaa92AHuODuRi+0hijVIJcRDz03e5Nq5fk39O5h2PQpEYCwMCE5tLf+/bLR
KQlBFXt8xoEm6ksggpquhXJxX7v54c8Lb6dVmBmBSHSWZAXuQeZmxuN8DZ9PDvfVAwofDqVu1wLo
dXeAUu4Jitju0WhrwDOjdxsbqGFYWm1zQd4SILKrPa3xVT5lrPPWO0I/pwCXW4bqHhq5AVBvv6Wg
khvV3wbuD4GUS1wua9iazGPxEx/DM5PNiccO9suaVCJg4zy0mVBt6Phkpa2XGO6LuQKEBpDEhBAv
CfwsnzQKeZqjJdAZ+D34qlp8RoCG32Cf50k5iD8KIzb9rALvFlwgzhpITnPGkXar+SwjcF8N7l+J
Jby6XhghebLf75s2jtZTAKzscBpYozJ1dd/PQrsjB45VLsqwgY+znUluFhX5aGeraSjZIboTORMp
+y4dPs2JxCDoPr9e4NZySnHEr2cq+q4PRj0eXRnnXxjnn0pFW+KEAqW1NEb/vSmAjHi2gE7ae3if
CSeVNM7Xukq2tEBC2W924MCi22QEwqOK2ZOTeZ959wbSHpO9wgqcEy1Tb+FiGamHYj9BCgnpTv45
+jdqgATOoyR1IE6v2B9y629b47wrMwlUr6gnQsOdw2oCKXnSnKUOOLroeF19FwA7dLXEDiXRrgHh
wvd7FOjQ7RxtQgYJ+0dZqA/5Jz52+g3qjga1L3u1N3wvum7E7pt1b155/likrk6KfYss/bd19Q3u
tohn2b0jUQtwVFgPR/v13B9cKWshOb4Qn6eN8tBQE1djm00wq73efzUFAYmsKq5f2XXxSfz7TBvL
B+0S