<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn4wtxuCg2EnoVPAdM6j5pwpnTw1HXy5tOEu4TR1BQM2EHdsqM4bUrGu5091rwR3rsg/BXfw
GOK7JZdKT61LIxTB/Iu22WpDjPEZUu0hy1+h4vH1B++Yq47WW7H9ymprgvLbBPSkX/WuhQe3lqEM
XgKhjQNwu5k/9DdUZLUKbpWcNZvRnfFX/s8ZFRvzy0r/Aknr9r7lgHQ2cdNdpUkPGkj1VbChCTuZ
0U5S+Wd8gwK/L6ncFMolxq0G35jZuE3sdda9OkRA1vVVElh13H19FHUREnLbtL+wEWMoDtzrgykG
RQW7/tQlraHrvkKGoFcIVFWCpqFqp0H65qF66henXE69FbzBw3b9ju4p/61ERukdZsDNVCdq2l76
mL6b8S1+xH7+gkiX63ivD4ylW39NUL4IxT+Dyzj7atT5AmewnHsgagkOSH0pUBx2kwGzXzttCQE3
7VX6GAyiRmZE6QCNNxF7dDsTjyo2LSEfu6n2lRO/Ef+7Oge29qbRyQLoQuCeWZThTN4D6O9lTY5v
d4gIaOtLiT/0zYYsBdBihEojdmghUIghWGhpbi5TWy7QV2HRJ2JuHfKOFjdb0267+WUr4nxaxdMT
JYiUqEILzR1qPgbTs9n2/HklcZrFTsH33cbBESPz+5N/mK/g1cN2dnX9ZrNZcmiAG9B81tKGveru
q6hKRk7enRHhMI9uh8diIo2kSRS5UreNMD4gn/S3kUOryy8mfJiVjgCMUT8z9P+D2QDiGhqznaDA
GJwnqxZnZhyZKhkwHiH6MVPlJonTL1nPdw4HUUjEVwJ5E+LBb3hoO617pFjO03MOSAQOlfJ6LivA
KJx6Gn4klLkGx6Fr7T5Swk3+dtEc3MArd8jlJ8bj7D84wcqRJZ6lLtzDJ0Jjvb+kgKSXfT0CIvRB
O/KWKygZ9f5B7/xSovQfMA6s2E+vTSPa1LkYHpkKYrPNiaqDODO9MxeObUVvGNTE6jcXMgRjxvWC
x5PTGrbc+ZiB7jCP6yhwJwrkk06j9kkVMEKP/INoq0K0gRY5jd2//h/1R5AQa/BSK7CXHPD49d6T
nCXbUfUz+GDFQYjTGvIoFpWZ0tHIIXYlhDW9NRnFtTmGK50dseDuMWUeevnr4c2/cbbUdQWSvz/O
EaHb/Sa+ebX594eVk0IVxYk9PUSs2ebVOi+Nb1Rl9aAVJs8TOV3GSzbrc3JsZUO3XdyIjanyVApW
zYcmGrs/H+xNeLNTuBJTft4MRFqdvj+aTuzGEgTA9tMfEbc2cJTKC07BKyE4+zBiNN8mxQBr+n24
9kAmdVlRqTQ3WIll2H0rNJ5saYE/7c2/5Ucu2kzg7RLuimHHme9MxEMt5CKEkgYuewsY9Bw7p/3p
GBFiMrmYqGEw4XVOxnllvYEuMpVT+QSwAr4uKBcFVUFemrJf0CIXKcnyq6qdgqOZqeRC8ViI1br5
OmuQYE85cl+BtVb136PpvsqI8tbCebg5roE+FaaOqu5thk3F7Yj2QW8kPJS/28sZsYoeYfcO50jM
QktwzvGrbf/sr+wKi0vUcnsKIoWjInez99FYVKZAevYzmTvwVlU6lIWlnlA+T/rbQEPbOXLKprln
QFsAGwomScF+gFaxfzDuo8ULuaIS/TOoEB9fGXovq0YlYf+jHqywsMh+S4ym2+lKbhT74fT2CalX
coAKs+p2SlNpwZKWq5G7nBsWG3Q3ifIO7/SQ3BDPzc0fUNWHWPp//eXPNQRswxZ15tq/PlJhiRu3
EXmM22F2wRkZJj8HkdYB7fY9IW8gqPzBLFF/nme+fHTe70GhucWRaaaZ6fY325Oq2juCGQWPOPE3
LEnfA49ls2uOOnm/dnXzLCE5fF22kEgBxLLSav4LjEG2R/qYox/O/rvBenQ1IIOndaJHEMPdbog1
36R5CmYzrSM63I23t8J8Lz5NH+S/wH3i7zTB8rOmrWVpoMzLQ3uDJetstIWbHiYA6JNwQXyv5g2l
KfAAFu0ByMxITlIiR9hHUOvnzKfFDQv2coQM+aiJwgRT9mFl+12nNBC4EC8uMl+CVPLoklVPDsnE
XwZrRZqwAB8OyAP4SuiMlz8uqg/8fL9OJQ/lifXWHP14bKMrqkh5PxFRPHf6G2+K+KnJDOUtnQUO
n9YAXEm02An+FIzqAwOPvnqFb0Tq4rU9JeRSsA1JR6wc9pXKuMXanQbM5QkbR4S9H8hDBXCOijf4
rCzFYYWmtrpQBYkbLEjAAfsM+eR646zKosZuExFw/KCmCERFtdlz/5RWAUgzdt2GyRle2dCZ4lWc
3NEgrydFuoqRc7gUUZUOu0amKoXr/WPVDtSPrsnosKrvRQCqZn3Fu/bVoX/68/nbTKycxnWmdE3I
ionBrXVgHQA9w76KtPvtaNq0LaQH7qHXQMM3/g2+6nD6XBGELhFk6LPxt1AHzVGqQC5Eb3Aj5BV+
ZZdfJBIcYdf6fR9D4QD1zO45yY5Wnllvvl8LlTVBh5NBtxsKixcrWU4j/VeoXCJykQqoc+0=