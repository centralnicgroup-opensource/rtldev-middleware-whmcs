<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuwUBeWpOPEloYsxgyPpUilbobdpavcSTAguNJD77p8mwm7lPMPKi7shYbXVL4kKdkaKzqzm
O2H2SbV0lBmZlSjFdgtLkyx5xr2DwYQRMx1cp8mZMzLYUHRVh0f353bVWg5SWoD0Ymex3QI0pNcD
86/4UV69Rg9z5PF8ejHLDx86uHXnnl7tvJkYmlh8THcLYR9eoKxzB2HGz4OXnrqADCMkeTQvIDAD
SCHaamtz5xtu022wH7FZWp1g4F9pjS5/Ywra8ahMLKiSqv6iQhdJ6vILlHLhDYTqOdsCKw4t1fY6
AqTl/u5uEqiiZSRRhwmWYHvCxfw25wzFqtoqjozjrOVYb/XMi8R2AldJlT10VULkvqgXL1RgNR5Z
YtALzx8SDf4tDRwBUerSxP37q3PbqCpOZOlPhJLVlGmMY9iXDj+ThH3q63iqIeIecguYhvAK5Bqi
el9ErABEOTCVSSPbJc7ir/6yRlhQfU5s3ShilUGsDWHZpvYI/2S4zT9s+tM5O793xfJnRciMsdKY
T3W+EAkBJpHwxETza+bQ9Sirraahf+HVjDNu9EN+3N//RDke4MrMgfeOarSUhOf9vjhtHsTQoC3s
7UwizGwKDyITbkAtAH/xGmCMN/+rWelNdX6xd9XmbaN/RNq0Yy19+U37VZvIQFtu6JgNSSejhPMZ
eAB7J+26PfJ9WGcGkBXjvDkL2YqKC+eu/zvT0J/lyLCeL8HkV8d2BQQPmAD0P5Br/adaTGN82Pz9
gPfynEAYlzhEdt+N2TNHhU7DR2f6pge1wgpZ2MCe7usA9vctRAYVf7oFcn+VE7X19dHgLGAmGJGU
SVTE4pVVM9eI2Uqt4jaBuzHF3jaF1/bWZrYmqSIlUIeXpEUEz74ozzDOIVnAvxmLng4ZnzSjaMij
HdCwKz45MuhLtZIyOZlV6+txCuVcQRWC+NIWAoLlvtWAXbg1wyqXSYc7fuzND9QUVE5IO2B7CcM2
wB+FDX2vcW1WNIquzTHbET7G1G/8bjvQ8/N1tZrJOcuhd9qn7lHwnhMAVDPAE4EiTtp3vgEoBAtT
n7xKckeTXbLFj+vAhvCl4gYJRxYb5c+PY90AFd6Ua2YQrykPqLw6Oq7GQgutAQ2zb3eKV951alUp
YWU4hhQJRrTTECJMfqLTbxGloq8pNABXLB6wOFBaaTxHqfesMb+nnCWWwZ5RfAuP5j/H+RvMK4Cc
SYe1RrHFnjCMKsoNEeuvl7f/OxcR0BY0Td/GdPKZG+mjeZ8zsOTrfePZWeCrSjGcCqMTzR6hXPJC
kPB/DC5OnLgJnWUcx9iQDn+PeY3WePVUfvHuMxTm4NprbZd+0NLsxQfClu9nUbDfHwxIlIkFhdax
S37ZoIrl1Qo/1SM61/Pp9U5KoyZ0FRUG+zqpVtHe82x9HR9wm1Aw3Xh/dZQsev5Iv7YBiiP9Tceh
gfXYXaykufc0Sd3b1CDRf26NsfjTHuGohsTwL38PsYmUFzlwWgRwbaWZaUG/fl+yvfxyHjk64Vhc
/MyeUC3fL9FJxgGaQ0dsHC6JzB8eXeBWR73wKCTSr+hUyz2PDmPU6R4O7mYVuYF3QVjcwCuKjXrk
qWqu4aOHZ4PqFrfg2LECY/K2dZ7QbXm2vXcmEtcm6NaLMfnibZF2acBZWWt3kRMY8tW5ySESTJ2x
IZzxoAMpiEgZSxwCF/bwDN//D8V99gCnvDbBAQilaZGrxK6b7g5EILUp0bCMcfK6K+URp969LSJD
t3LMKgS/68IwoNjFuKkq8nQAg6itJ3aXqeB5ylpmTT7M5eUg6CasOUnfvh6YWmvlusZG5GV/FXUg
wttz0W00CutdPSsDkG3QvJVYNE194WfnqUVyBjcOZ7B7QoOzBw7HZbvcIKTCGXGnLmoB4a3Te20/
PDwp4uUrIF4ouKyaeU2axqUeRrN9fhJWy3qxKKdIJntkJ+5dV0N+E2vAZUtRAXTEBXvfxcs71mb4
k+JaZSSF5uga9kPLXxkVhBxVUcSz6lym2TDXzPAZo2XYiqBfHttpy3x9q5xQAf7r7Ehg5nsWzmRP
3qCL30I6EHTzJUeTJQiFazGOSSwc1NRyU9F8Y4vizrrHUvysIlVFRpMvYEKIGaKh56WXxXsTtohm
+oEG36RLHaerDnPbZST0ioiD6QSbYOO8l0JuPtR1YPJM0/7zzS+Kmfx4/C5BzC7WdDDAbPOIaTMg
ueDKvsAMchblN9PH/oMu11QztVrlYhSTLj2bXs/CFYzElD9qBinMkkzn5XJ/xg9i1+Tbcg2gTxYR
E4DCUTUZlzVIoDYWXGvO8U9+4kxbRAKbE7Hg2+4or3KCavlU7VOazZMmKX9EtKaFhL//UTpDf08F
P9K=