<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpUMnzsDUF+G4aWbKlxqyEklJrJ4T0j6TlM91GGcYo2qg6T7GAVwE1K6r/8RHDRR3nCPzfcx
XnJMH6MqNNk3bdovUD43yHTlpo4VaYHQqX0ceZIQZUv8BC/k4Kfd/3kEszAwhxfa2PHGRD1pwbGL
8CRs2wvwFZJtgvkjTNdeVAi7qrHiLkKtN/xTSyEzFe3bqFyETYWbGDHP+Q6MqVcg2NVxbKB56ytk
Pc5JQZVE00brXyjg4MXpIxwGN6oJEnkTWA0IK4zYvie7bzyw+i4D44az5vix+cTms9d34nO2N2iB
o/1Dg1w9rn1F1/GQt19vnZsL/7YNIQnOJM3pIzF7BcJqfbaRG12/kxssDIDQYh0juv1bZimpXyEC
bfTnuzrZNDU3PpP8RVdIoJSs7Jvaw8gnbWv4/SJZOAzrqD8cgKlxJqKrAO/ByZQw6i49OgsZxwTC
s9gnJDd3Nlkf+9Y35BSaX+QnSLn1Rm4ZUP9kppcUlLrr1ghpDWdZprj0HKCzpWUE08JaHKuJWVyY
ylWW+/K23N+SfsU0id4kaUgGUAiSgQwuMlsGTIJVty/F/1fOhaDQZ8TYu0YrOotd8kQKmgM0oPzq
RBu1WBofufMnTSpgAlaMnr6rp7B/4zH4m2TfxF857CUpGu5tElC/9Kmn238DqmVJrTHgIA8P0ksh
OMiiBtYswNj267cyachG14hK0GvfVuqZxTvMKeeU4N5gP5G6dF28kUNLiw76wfkCI2FH2Iz5CY1O
fWvb1nI9FYSTh2TCX+rP1KV+oHe8B0knJbHR8dzv/kutWd1XQ8Z8eXT6tel2rVvkl56vAmD8K/C2
bEa8L7dyMef4YWT1BesQgZYiyvnFMIEuIGJau7rYT4A7jmQ5kkbupcLkY43SabLVuMYMxV+vOe9g
dvFd5DLw04wUGivK8nxCTXEayhA8SGIANPCDO6tLW8e7X45rZqvw8OAO9l+ZiP98joXvpEEQs5SB
amgj3HkTSE2miinUKkYspU6ZOZ1P3VKwg8tEg3zBCsL0/8pTTe0cxSAG+U8EzAyxlZCFrUb6RPA1
DKB56Kzw1lA5+YvvUQQlab2CiM0ed8bQ1EqS6SDbWVxSWR/bCB+UhbMiqVtfKwIDprcL/LDAgoAB
y0K4rCDMLJcFmUzP/7wZ2dyXl0tEu4YNV300N9mgw9h55VamSYUt4+u6sKtMG9t/hCw6d8o171mJ
hBSQoUxSQF88Avr6rHNHFcUxhnP6GZttguPCE8j4fIS+15Qv+NN1Uyq0r6oHOLF50uHYv/E58z/b
MTcsxNYtlzcAItN0+UXO6Z5JO8+KKZaGx8j5AkmNtZkSYFGFiE1OI1r0M7E/pF1YMqiWRTmxm/yL
ZRJfp+bee9BSyRh4GYyXkK108lpLvqpkbFXrTlcI+yCu7+4tRXxK1YD/Zaqv+hrcpGhNSbAFYWza
NglzHIoOvhCgHyeQs8kEsJ9bXgtiHhZJPL7n/2fd1bUVlmou6+PVn8svu+ZLtggD7/WIRTdWOtbL
FZ19JW56y7FiKUl72DXdA/jCZLMMysO0I16iXFcIr6gpdpjh+5mLjWoVRJS2V0D/vwQ0M4v4lCaO
NkV8KOxbbJYJasy/b4VU9NZ4tPvhW625SY95yWBj1ODS08ZQ3eVZ6h71yx2wIb6bUzUZFOphfkVE
1gECe6H+Nj5e2WTjiFtVXArR3lyxCkGh1d44MwnmRuorrDndJVwEpMxHnxHhiDiNTE4dpaKOc9X8
iayth/XR87VWD4QeBIVcSX75eqCt2TAzI9T6j1mLnR5GYsz6eEaM4i+eJ3G9aqNAoywFOCuQT1BS
2I59+Dwa5fFyRFIh9uOdovDrKNGGVjJRdPYQzn6iVw7/6p3hkWMIieYnkSr1MDKS7x08H8BzZ8A5
h/yM/VWOtxGRXYJYLIlrC7BkzwmZ764MKDUjkOSeavK/pr1F87oDzFmDb0Cf96a1RIvtMrj3Y5qC
pHP+2gDxCpysXjgzZvI0RnLVCTLReOP6wzRKaccSEV/B97h3GabB6V/aAlNj1CPdy9Y+0pLajC+K
5ifL3MSwBMdqDGa2ByxMdKyC0mAOWcCfx/uMO8dpBCCEVjgk+bHQneQ7A/23KV8/wSdEREA2joLl
iKCFeox6IUrLiMIWeuGVNjHffHVcldiz/9EapI7GE8U4yW7X0iTHlCZIQTBIybn++FDJHu1B2VRE
HgVaibxzo3eZFpiWpvE4NZ61qZ7GyvuGOWyqG9XxTcb/u66EV4rIApgt0/+RhCit5dhDSpqrdwi3
A+G3ok6wHEOiUJ7z3KIi2YHrIfReZL+dTpYQprukoYN4KW60toJOwZTOo97UJ31NLUExjY4nisE4
oJ/wHQWZ0l0R