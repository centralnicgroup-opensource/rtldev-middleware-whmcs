<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpiDDfSGquhOxR+Zj4cgAPCQyqhTxmTQ2RMu6dlSkbCZW6BT5P46xU8fjG5hNgZoNlkqdjUy
LJFG7ofs3zkffQEytjna1+6pJegzuSgfWOlX03CJ/oj6mK0CJevhcHDG9r+6tPsMsdRuACfW4b3P
cgz9MEmS90lh+YiXoKJk+A/aVzw31hZt01PAGHP3Y5uC0lCN+aDk9DFm26ik3uzCVRvLoY7R+wn6
TxviEwteRowbH93U6uSppg8FfY+DNoFVJwkg8ahMLKiSqv6iQhdJ6vILlP1daJ0/dsZdNKuA49Z6
9ES6/yOHG8U1onDNnqsmuhf8C6mF4srFWOkJB8LVqvF6d+SIdcysEdsMME9yGrDgCL4Yg9YBsfUA
LM9tGAGnXjnzLy1WUC2XOEdQWy0rS6a9+jue7IXxHO66MCPZsGz8CMQ7hmUHSWdZWXnqltjZpk3S
Ldyouq25hAekvoSurCGLBbj05/ksXBBJ04IdumXGsPUhtOulQxgdscqxwTFOSKP6EFBAtnOjdaU1
etLhRo+tTISwX0WtayWFBIXMgjRKyK82Hsv7SdAt3h9l1fFQTdeq34IiBtgp4k4IQN3rhIlX64iM
TodkQNXdZqWHf+r+K79D2OTZRXtZNwEN0l1N2G7BUdwK/QeO7MjKfZr32Z2m5JP/ye8pyJI/OUKu
dJKkwphgMKEfEXsenTEJ7BFCv9K2NbZcAngvyGzW8fUDROvf9YLpoiiRww4O04T52LWBQ/wT/Xyz
2iDDrY44mgSdskjxUEzPetmMjvvaDdmdk7mE/1bWx24+9ndJAMAUi5aBnkGFvvl7JH4HhJ+U6jUQ
LUIv5/bKNru2SPxs16YoN6qm1h/u/dOkOw8kmyozPtzHMrlz8a2ioWHCTYbgbYGrQvyx03LHRKgk
vZrKaPNATvqloyAS0XzLh/7fuRbBAHQxEkqNDiuf+vTK3LfJCphOZ2tzcBBUFydld8EChOFiN0gd
84PdkuGL3G7QA//HXVtaQhyhx7VEj7g4UDwCy/ONRXYm4clHVQ2t3bwDoHQoM9KcvhS2M1XxWdnw
8FZklxaHHbxmSt3VmlVxAfoydcFsR3L3HRyYKcdzyCW/BgPLaMZthCNitPT/K77I4oU8/Vp+3yKV
NBabGWRTKG6rVfFrEzv1JlV0o9PtG/ps5NuFqooXzqTWg5HS2c3vWX58+tuWl/ZCcRyWCjqYbQJl
23NHzO65M5oHPblFc+ZYZEXUxKPbwieA2EbXwdl0OjohO2SzkbPMuhS7S+gcAtzlCWIFZ6tG5eiR
cw1HTv7pACV34NsR79st0/1bshODVkOliju/lzNQXDaPBsnj0I8FmEgIPa115sVi6lk7rRgl6HJv
14qayz7ZJinP0BVWXvl0aV2FDLk51zWRXh3NhbrgkN2Vl8HLZG859GqX+0exsEF0/2SexqgHPnKg
l7q07UUOe4aeGLajuoWAm9fH254SnQh/gt9VofFRoaW32IwVqRpuEa69FO72QYtZ1eVU2bROmgRv
D9scCigBg0Dtslr02iJNdRhNAYV/BXg6ea/wzu+IxWM9LRrr2c5D0ASI72LTeFQdxX6O52QbMvM/
FWHyre+p53wEWsZBHztIi4Y2yzfsusn+hOsEEi+aNgPAOBUgXG3YgqWb615BE62MS5p31RLIPSZm
6Q5HEomWLA1TVBbmyrzTKpTKKsh7+3St6VkqX85bpSvYxb9ZH49IlR7WoqKGQ96pV3XtyS84iOIY
VvpLbr5LvtSrCn2RvjKSA1s5JvNEWTk0if8LRbdmIwIW/0rd8qpIDgDmDDlXcuFCqnvfiSKbg9C=