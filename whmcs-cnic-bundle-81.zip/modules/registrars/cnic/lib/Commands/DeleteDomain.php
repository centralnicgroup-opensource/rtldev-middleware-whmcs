<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvlzkSs0GWBYNKyixgcug0CljPDh0wYYFzwCMGExEh0AHLes2+xQ4GvXEQ+/iVh5tz8R3vDg
98l1jiOIjvbfBwkr2pYPCqYPoxnUvS1BRQlJnKa4KKRHaXi1YV/JbfT3Rzq2QWEaYZDnOiUMgcI+
4iGTX3B4b3ZYKWShrHk5p+0rG1u82Spgm/UlSS/tsp75e1DcfreJoXy+rCkDcldLoxHp2csx3JIc
AxMIR8S+CKBnsyn4ElE8AwD7Nt2J/uQ9Zc6MZ6BcoWUNtphwmGqGIJqNcpjqPvU/wLGV3D8DpPtB
yFK6KmadQAnwiU0DyH2JUbq4fk46oPrO8vFK5/eeGNLX4zzee0OE122RUdr8dOKqzK9DO9xyLHe6
/aeQ+xfK6S6MIe6GPXZDY+nLgblgUXOIBtHr++C6DFZ8tIwI0QNCjEO9GD6c2L+m/B3JyeY1OHbw
gaS/2pfXGqjwuPaVQpZYOpF6e/mXLvABQV4FRBY4nqiuXks/m1DC8ONNVZWDHXMNtcWsnULGhzUn
Qmg3Y29SZtK73+7rxRIJiNoWJs9TV8WqkcZgPmeYhlzTjeOKYkjkJcZjZlz0J/4FQmZFo0LtA4TQ
qpMD8KaHEOJzwY14rQMvaz8nT39R9UZfMvRPvmX6d68fG+bVptvNdjHNQq84Gm9UcUgW57imWojt
j3aa+j6CPFqqxMyqlElm5zuE1SzwZOqNtCUHIrbWmYWTsLKj5Ea+AlS9Oa3Hfd77CtqNEPRVVBrd
QSqNdwWPsW0Iu2H7v6QVzEMFTmuTBzdEf11Rdz24TI+SW7HpbxHUaryH4gj9gEPKu3L7N88q8nDg
UMAf32la866zzSgnricBPvemM7zpaciqKC3OpXmNXVD2yzdnimQUHuhGpiCHikpvIfD7gdcucakX
nncNcoTsCVVYM1HHEYkCZ/yL6YBUv3jhfub7TlnTAmwdtemV+D0Ar9NsqFSo8XsN8ks32ABNxufh
WJuhwM34/W8C0uceAn4vG7OWA8tkQ0VCdT1ePFFggu+EoGMFpduoe69DY2TIb9SdvtEMT3ad9i+0
x1OSc0Q9nSoPq3OIP6nlLCve4OmPPjSCCWxYVhfRHRKYcN04cID5bJT14gafsa+yP5uB+S/pQOcE
IW9vbJMSkq8GBs9gUA5oB4S3PtVUxyJhrXaWJMkZOEFIXvltqNaFxFCeOXLwqc3FgLl96A7N9Wls
zsjedcnyekcZPBpJhnwxGafz+6oEgtnHBSpzaAgUm+c2irHWM2vtSYcJ4b8ZhXXlDzSsBk1gV04m
yt01JJ2gfrIZCOPWIhfPVa0JXUGo87puZdyz08i1cBHGaApYTN3cnUq+U6K7CMMcMj2TKBeiTl/S
/Bq0zbbytH0EkA6UQ2jlGmQ0NV+ChtnN0CVAm6qgsa5NpoNkJxn/OR5cZXZj3C/q8muLorLVTCk1
WSCt+DATLJcVXunmXh5jnIQlk+mpHq5jS9uJSIlWIJshLzmW1U0OM3fvk7t6Y/Ocym1Y3XDBe29s
k/gRTs86JY52UbRJuthjHJxtujbE4QsAauccGDOmEZP6SEMAPm22VF+mlPSOUG25touml0IeW39F
TCdq2m/M/n3KznzrWFYjmX6I/hJ1Fugf0x87UPgtzo35NUsTP2Vu6kWIUA0xrWXWuHM2LDY571h4
cx5kqUuwAxW+QTCq8HGee0IT0EY5xcowhbzbO5W1R+FW6EcF/hnbL4KAx5DRy3w+A//GXPVYynt+
gC7M7YK/PpK4nv5M3IcNOaSC5MLKR5a/z4Gqy0gBAzGTZlz0GpbbWUrVJRupwxY/Y4Qzptnjux4a
wGXnCjWLl6+e9QAs9mvS