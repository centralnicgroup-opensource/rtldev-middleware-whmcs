<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqDzPC7bxLptyB7nuY+TIvDBTjxNtBqYIDTlS41N62EXpN6WqhD4t6k11dLMQibJgQvoMIoc
nO1dfuzLasv+nwoa4fJtszY94tZLJD+htOrqaMOs8Yo7sC5gOiwvYfQls9QKthoKO+JO865JUkK+
Px57lDjCSzI6rXjqXln4dC9N7mwCXxNNiR+3eqXRR1RdZSJylAMjIz5YKMk/w6MjHO1HTSw3vJKA
DXAIZoCmbftoBpQxyoYAIBPMOCgGzT2ozB58g6BcoWUNtphwmGqGIJqNcpjBSJJmLE5qX8YzYKFh
0FIcOdcfSkqbWnS9WADm+9iIKm6PHLwQVegD5p3E2ZNvwTg2k5mMHxKZbkREtj1JlIhkZQQKlrCb
+AxkCrunPnZZqZq2VTW53kqu9HtAKk0QQHVQpCO48Xebn8eCDmo8+cZ3WuON+gZ1I+OKtul3Go0d
4/DKg4yqRCPun9aHWg1aAuI0wMt7kQgMHc+LIN2mbAqvkMdLFrSVd6gKTQa0BFCUD4tSsX/FJUEd
qwY4wsaaIS4sp6Qa0NizHzI4evaztg7Ov/fafiqu0qYEwdUFdSsG0vbrYRubACbG8nhh1NfPb9ek
/OKleV7Fk/eNHhqaeh8iM+97L5bZUJJlfXN4V265GqKBIIQ9ga6xKgAdxDXR/qIjNRYJOec3pMtp
mwYoZpkPg9baZ77lOQgSgVyYbAbp0Kt+YG4cMIrft6JPVmKQp1ydM//DwbctPRxzjKZ3BgMsXVyQ
7NCHmVPt1znfQkm76rhghxzgUgs+YBKVtqn4wVoevPwpvnYIfnOfcwQD54xVFfnqw1/IiqWnjKE+
dQDNutY16YLmTVCO0Kj4J7TwHDntP+ZfCaD9e2C9Oj2E7y+yKhpUPyNW84jg7DEDgu9xLOKG2Ufo
jILYhc0gHxIDzHSH+asJOmau22nS69jGJYW3Av4o4Veb+RCGoJBHOc0+Y12iERkvBWEfkM4qm8Ez
7ZI0ZStIAU/VgOep0QGNDHyu02clO8U6AhmVsyFBEbdYs6b5LMJLIJaz8rWQIy1OsKdTZRMLq2ez
plAgkvLZilo6heNmZjiQdXwVVt36h7STzlM+Gz4l9lKfnc4EGhCp/PAF4zVXYjVeb+yVGJbRYo5O
nDDVELaZmWFDpKUbNuACqXvh8/tiZbrajuuJGDFrmGzxw5222ZE4sTtUke0qxusJgi3PHY++hxl7
QLEaBX6BvXPbJ8/D5ZNM7N0utfUvObzfJlmhcykP/KOGLQQgM2aCWha1Xkpv+u4uK7QCQ5pNytvC
KdIKdk5zxtwuIBBzwRTCQ0X9LUO68GS6HeHnl5mNQg9GFiu4M/Xw2Okqu7dwPksNT/yXMRFIyBbd
29P1oMpE9qIWs9swalm1OLkshHRmcD/gZvm2shghseAPAHlOd492hxQOxNNr3wtRfbA5vS4RmX9I
wW6fWOvG+HHkeIgcFYDwSXApK9tbYrb1OHLLLfWRqDY2wLB2UAlN/QDyQKlubEILQS643uGmfE+v
Px8vH3PjFPBqvdWMvUMLgyD9HZPrEUIteYE8apK2lCO2xnXJbt9Q8h5Pr+G7KZP8NKyRZOb6iO6f
zA8i2gL33jgRv2U48c7Rdbcc8gxjV/Y3XL7TcLb+gPhFudu3+YCNSWMQaa29QEViN2hOI3CX7cyU
2N9lLTM9D61pzsA8c934wwapnISu7RbyxosYODMRQnJhFhojXev5dKsfeupCkR/zyv8/cC8DFPfv
Cqo4sWEBMWm+FOMuyS829RImtCsdnTT9KefrqIyrit6FWeT3QewmeoRPjg7WSKPa5LHb/6HleyXa
18oDWJyJwornLeKMVDIvBMp7i/YFZin5JfzgOe/bzITW68Dmi3JMZ5UsGm/cW4yFhOzDgminW/Yr
j7+vQ+6dBSpR5ng0/AK/jXBB59DhQlrhvC+TLrgHfTCj2hRjCuKFjHinL14fhJHZzyydqT0FY51t
Mz4Ag0XOVecv/PQ2GMs49gpgxaHxrkAhu9CjN7xH0g+x6H3eM3InZH6yWSh7L9lJ0w+tZDpY2hjw
gqR/idI2zBzsrODnk1jSwr/U6Q53wfS/NY4XIn1QdgeHBCpaPyeaMRryGBSB3JNa+HAxKqrDZtOa
CcbgfaVH2NJysmUkjrBCiEPLhoN8ScQHIn53OQEQPWKlyddgi/1bNyWbeahjfEvcDd9CQdXECLmv
wnyvfMgDHgbRgGX+71FXbyoQUcGCSOMbwwXb7k424RLzlw2JXPMwmLj5Dj3YFnTEGvxx11F1gvfz
pXKFQw15U1EVWEbRtMikENv0W5pyGv2r6z5/jqsiPwhq3FbfGUellp05xzDsO64wNbYeV4MkavjR
ABgL/lyvhibdM7KYtLVGKh80JZrh1lZf3MYAVAIrMA/dofuM97PK6/68nPNL66tRZqbd8sV8RQhT
08QXydx0fdtS2reuuK9h8OqOzGd3hEh/JUTy2JP94NpLHiOmRdlrDIY5AWCAdfZGHPPQMjYbkLjI
xn72RxguKTyrX0FgHbjeLWcIe+JajIzIMv876peoaKp73Fw7WZWqwte8H4vOOkkBmn0fNmFwro3x
dufvZg5eXmUQJc4n163t2sJ/j22aFGIIlzt7ioxsqOEK2rrNiVyLNDY2