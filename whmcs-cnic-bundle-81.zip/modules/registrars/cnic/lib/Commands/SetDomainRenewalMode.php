<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtlz81KmRPbQpJ6rDfNdJzo6VH6MAHYQEuou/ukhgNYI0H1Fcm+3DuwfBOi54x80GrW4Fpx0
1fKvswh0R9gwaMZqnwmctr5SOFw3pI8/bQ3nqNau5UolXmaAoWxponOvhUdt85CHLyn7694CRsUV
QxOQVK0Byz6xUzpgK9Pga7U4h8ZzRiwKPdyZY8wMZst1EkzylRK3O++2arYBWD67YjXKuONz/sgn
DMmb3677Hch+nSu9V3Z8RD3yx8e/xvoFR8fm8ahMLKiSqv6iQhdJ6vILlKffONZmHtc+854xRRY6
30XViATUgyqw549ucVQsWx2ceAZpVA46JQWi3a9hYvVVI8LLmtRw0ikq9MmFTbzSqnC70MW+zVqb
Wf9a0gsQmdxK3rUzwV4IaTV0IjW1hgb1PnuFDlXqXfu/jS3t2j5vhWUYDXueDf50Vq2kTkveksDt
uWgDS4Slp63awuusb2vSTu0sYM/wGbn/LTnaECOc7ii70IlRfY9y588gIeV9pNxpK63kOAlR7Uh9
1GMB4sXUNdrod+C82FJNvP2ufadKY8btHGDdR1qqXZxL0gx0NUahIkg4t790yIMvQGB8t6OeBa0v
3LNGFUCBF/KLgd3KbgcLff3cDl4FwGZgzs/wpok1pEZnRbE1ENBp1P05/Y45wX+9LJCMvnDrnkSt
dS5eN5zS/6V76AHPJrwOBWvm0IAo0K3FD4pbw+V2kN7OKQCJnkWwBclb0LXZK3jVoePH+oWk3irt
DkSlO1CtPKjAb83nPW9A0YvasZLQJyNjUMC4YDewppa3nHthfsi6orYZmKIjkqa114mviyQN1rTX
K4NFUme3hfM6ZY49Mejby2bKNEXTA30D2Yth/GEVov9/Li9PjbO8DrhVn8aK9/T6q/JpAJcZ9dlI
r0NjC7lFVzCha33ZAiL/zpLH+VxBcPalREXBI1K/yVH7Xfs7rnsL4thu4RAhxsYnrTA3RyvPacms
2vzLqA19MLY5yQd0OpK93cgHI+nn2yCLGprwjgQ2K303hPRpFMuYMF0eef6jDmV0ZCLrkBv5R8QS
5B/cvstj0cvy4uCEQrA7ySbdb1Y7rAOm1y3IC+3Sztt98q8+brZwFwcpkG/EzIcR3qWuMBoq1NVn
Lq8JVANTG8D+aQbLXDAJ5o3Qwv9v3AUwyw5vYm1/yYq1OvNWlu6lYxrmTYCXE6HvnYr2jE+YXMgz
yo2Otv4Bkj7SJb1FX9zXN7v2FgoixTqLRByKeOGuCfTZDodp9yaJ1AU9WDpYDuRTgmFJRQW7q62+
5jddC2Oapy4qZItu0vIspV37gVDSD0Rb2+/yk2IEn5iushD6BQEL1+MDzXjr2PSr/uLwnclSUcao
zqNDQD2CRgomyAo3ablCNpTV0kMpPcr78J5sEaMGMPcl98fnd06Oxcoy1lAlG/AEqhWYN805MFMh
JoMFE3w1o67MwhbvZJ4dxJwf10hf0T/Fne+JQIRJoetBVpbRMoVO3KItM9mA6V5JCS6++f6RRj49
UZaB9DQKPgOjXiCw50pNyuTawQzUJv7ePeQMph8k0qFEzVMRlcXP94LNuqA9bVMYiFV8ky1RKkyd
04cySdpP/FYUwQlAj5qXGUqRlXPYBOQUtkoPxxFq3X6Oq98AS72sELH8awkAx6J9ldpSEiUi2a26
TrO8sDtC4hTUyzH2dpQ+cwHxLtRGkx+lOncwmGwwQCfEsyp6opFWma5Y40DliNUE8aQKaHgz+XUj
VVe/g6bdg+ve5HQjonG8GTAfCyUHJ6K4/csaJQWfNM7MG/H8PG3iKQnwpdde2n0UyZt+k1hLWUMG
g++sDUGwE7HBYZs3rVIIUeT+nWO88u2WszU9pEZUA8FOndWH1zemQWPpAzMaBUYjKCKiPGRIq1U3
cET+fMNt3p3ZwvtBr6zYV8ArZxIsQFB/0giGRF9+qsc2jsRps3XQk2y+orjULuj5/9lf0dL8cQdP
SfRf0ownwTzUYU5yXr7xa0ktT2AhUvIEIqkmGAtRqIZT5lE39HcBZmsK9qWTjSpjHXoaDChq+2pX
djGm4AfCEgsifq+ZanL5vwAbWd/vodURi7kOqv4oMxna9aRNfzv1vsbS5Xldd8BG9jgRqwwtFWop
wKEWkIyTs2x2obr04dl+pbjN4w/r0mMu89bbbGj/vp3HfVQYU93VApLnd95PGcxSvtkRCORvW0Dl
wZsGwin/kcgrzC/WuGzX2iv2yeKCGLQ3fDB9Vm8EGAE68DRzaGd2l622cqQSfQQbLbCjKVmIATUg
v3lfhZHcLB0ryZ2V74hCYHj5OsWu854HkWtUb7GiBHpvC3/jZOC97cT1PGyJzadKLYkUnfgcdXBj
lT1yjj+T3uJ+GfoMaH2KqxGryep0SWPs2I/TRTTX14ga6lo1Ns+aXLSeAU52G0UYRbyBJG2GCPSR
V3GYV8lOBbZKHJfeKjjEouhJkR8npVOEK7RXZmAAqDQejc+HdnBS9RMx/OtmKExudRTHoTj59pHV
Ysg2guSbJjw9qjbM/wng42XSLdFEO1BW2iCCkgARDLVorlvVApC52Iiae8S60f2VpIoUvjfrq7yI
kwZm4aQoQSWJC4PbaIbk2S8NLaZpvPl0HXKSKHFaLrAzlLn/KW==