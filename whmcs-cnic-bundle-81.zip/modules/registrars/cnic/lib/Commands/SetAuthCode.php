<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmPrKWR/TDYcAOR6noKQSpgP5TsGxjq5J8ou3/yNy/QdAz+u0J1CFSTuyR6yUSRZECVhhOCK
DSZz4CsixB9rb70tE+/Im3MNk6ZEjDK21KqJXd5mGIUD4PFbJX0tiCuo+f5adGAGQcMmEwxKm9pS
/trfRCVt5RfiWIq/BnJzI4ZsYTxp8BiYA3xqTEXY+OMoJa5RSpuib5zIHKDdkLsvlE40RUbNFdhP
M6YAS25p+eCE+ca8QuV2/HgezCEYLiKBwxoo8ahMLKiSqv6iQhdJ6vILlLvhaYxcuHoWTQ/pQPW6
TwWhG5S9X8ltbpC4e6ffG1KzQJZRV4EySeO1l/CrOZNfnukOxCK32OXrnkwMIh/swNnRAfxRWfyl
UcNDCoZaMHQSJ6YBs00NbH0LzHyJAPOmVGpytUCfH0Vsr4cnhtA0tmiVscYvwP6WOPtMG536eGGa
IJ7fIfvNnwrK2BhV9aso48jV8uPB9u1OVKbTqB7s/wF9/JPjtZR91hl5wAZM2zEJRcqBexUKv94K
yMLwde8rQVxYR7see5UdGbDlYPf4GbYACbk3YooSfjWi4BYs5A6GxcuYhVTemFbFgJ7d+FuPBnqT
GlvqOyIFI/iceCvo5KPhlCN8pRfUPO6oTixpYy2uaHxfE3ScgzA/WZat8ZvQ8IKW0Dz7Ru2J3MYt
axbTvPA/yiCAgdI6bza+cgWMBYWfdBPO2iLQD7Q4QEglU8rqws2OQfdf5iTlpVPeMRWpn8U7GWUb
/rAp+vl5KwSOsvvp3OJNxJ+rj5tWn3a9myzRd9Uu+TBycQ5764XSdSSn2+1Hm5XTKQbPJRO4bqZu
s2T64727PLM5zu+vRyuSBupLxVARuzGGgLcqek5vKtqAjJebMDI/og82loYr+Ki/EhyK76w8AP5p
wBU1VoxPilVDQ0QBIuh3bcJIV2PdDrB9ULiCsiu8gxoJNnqjDmPaZdnG9KpieCQZjaYrplLdBtow
EnbLEqfhY+4kRNUXfK0IFVzLcGVIzm5yqhlLjiNdAWI+8lIpBXDHS17Uh1CWJUnfXLVp8GsMGnwY
OZR7+ZBU2uHQHIAvC5fsrHJEezUdlQ69Fd+LYns8CNnwAIPvS1i/y9DgiqNhdTqiZMgHib6wx61l
U7xWToKglXGtxmXUDMaceHZXUCGwSHdgVGOt+HQkHt77smebETjDTEhAbvbRKKyWRnqth4zHHQKa
c1XvVmZpkBOYuOK5cWiFuVx9oIiCsaU49t9wwLM6FiY7cm6FCvNeOjR2fCZq9Lugrh9m5Sz+XBs0
oG1bw+KH2w/I5rOXJSuzAh+cyyAEtYxJwxd8t7bsOyun/7bElNA0WfLpC7rY/qZRYNNiK/E9fPiX
UITUiC3gyJgmYm6zMBzdef8ItlrYbGi/szJBKTS4SBEwGQ4FHVhI7M3fECTeqhsXwPZ7Hez7MPpD
tZTvr8wjq2DVkeuCIrX0eQiMlQR+54TG2Tok+qSxpADK5j3ByVBOGaUxmfrzz8yn54Wbi8OYheKE
tf/yrcePEsE40wDdQEKgbMeq03dzrrHEwU94HNCTegmZ9VfI9yiJPQVaLeyBSmVx7bGYL4F/rGQd
YNL8MfPaLa6xehWSjXBWjHh7JZNchKqswywGAZjuTIwfk56lp92dqJbKkrPjs5zX1+jq0ohw/96J
/FLvWFPiygrj/rFE3vhVJLN8YddVqid0fxreFz1mr010junFBISW30D0Iimn7G6mZUtuL9XRSWEW
uHp8DjZ6Tp68QXVDTWhymxHMxcSQeoBEXk6eoAmkAGtDyMFQWJdr7CYYKmjRH0yiWb4OeL2tHiB8
iqY6P6aUl3hl2B0CbTa23HFpoNTxpnBFkG7HvI39RJwKFv7CAQgz+PvpYMx95qAcTyHS63gQDiTT
mWR6PXA51rvivEuxiz5LLOxZVDqQrihoDEwW0sscInqKGYERNMffnZeuI1MatqMLxnOs9naZJSHP
vVRPpp2X42L6aSp5TKFQBqywO9dJtbbacADfUwCLXWcNt7iUioqa2+gRLcoxzPHf0QpOZzvoYzls
xnWY04nkpxVMfhzhp+e2eu5R8gfCoM4lkyxfkiliD+eTTMAIAxP2s8pBaHqJLWufw6UyXBUfG8dh
UTVuElzDhlbKlnoxyVv0K82V9wvYykwIFiTJPxIyueRH94yO4oeBLkdL75ELBe8+oZjiHGXCCq6q
dK0zsvVv0V5f7FdrVQfvIDTn7xHRX9sktChE7o3L80IezsEyey+L+78Dhqr+VkxGQXa+ihpTElW=