<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/toxerZNTEYUa5xhkKCZmalzcEhRStnIAcuWeBX94JBFQS7fHX2YOZfO5+J7+QBMi6XhARU
gMKiaYXPpWMn5/qE9dGljEuEKDhUqkjnqkyMtH8VB1oCDD4z7ydRVGvDSYqZl5uRX+0eOBsKfnEh
oTHoMoh0/4LqyV4qQSH49eSxq558zRP86WMfpeth8dZ5BhcaW1tjga5tvkOMlhkxltr3LK1MYLfp
TbtdbZGlOx/wmW2GSnS8bCp7FL3otX5l2W1ZOkRA1vVVElh13H19FHUREuXdbGZ0EAaQHUQFHCjm
uMSV/oJHH9Sj2jgFKtDNbXk20r2iOvSxcphfjOULD1ImVfC7C+kSp2n0aDEwkffaIOwnmOf+IfT9
pEqkG6yh5Fqn7U+J2W0mWgKbeLzW9WAMb+RJ5qwzykmwzMO+Ch7HXm+xXrPRCL9igixmxt+COFoK
6J+Ot5TZSupNJU8+OIRts04VNYEa96djhhJoql0FVupauE5K/WaYM8UwDrkCnD4LEmyM6ZHcKMR9
0EtFN4lF6lunfbu7HzLdtgrG3jeE2k54U4c/OvVV3l4cLNSjUoxyVhFHZGB3fMQrK0dBtvueiRDm
Lcuaz7VPmsdJ7eHiUXHpxSQJ2Jtp7nApXcR66BeVL6F/JjKdqc8Q0GC06ElWN4ahJAkHSSHBGeEd
D4oo7OttrsDmpwDWIvZe1zMcN9YUyiH5GkR4A/tFO9tJV2MiWOecYMafeHxRBhruyhp18iZLUqs6
ENixXTnPWVOoRgoILx0P3WL27/hAEs9YaxOM264Flk3cuRP9m3kHLUePM2vTpVtLliTHJN7SWAIw
jytF723jijkLIwUsnbumhd/eSRnuMf0UWhGC1JKbmuWFh4vAAFmII+t/zVNEYTrw1OS6za94aUrb
eHaoj2Vd5Y50uwmMJ2VBdoI9dLpQ8Nb3JUslDCDHo+0FLIEXDTyWPMlbht37eZg6JpbCZowftvG+
RmylJ/+QT/Cc7HNZyc3fr5wgXF1DNDdpFl+vEe83OLWDf+B2wkSp4mzej7Fgb9wS9Ago9UTMxGEr
74Br1D7rgiA04vOdlWrecbnIUoNAj4LB7qWeDkXNG6vgAI4qZLzO45meXLUiRbpU9UtLVdwff1Rt
P/zqxT2vLKQXX9/D+XPOvv8XYUhY3ZVDTSO2+lEbTqXdxkRtAMr6Xm3sr4qDd6iedcrHUjTC4Tek
A4cMmCs7T6Y+zf7pmLvxdMKZGMagc+ZZbXBFfhfEV9fWxlxyNaHXy63uFlNyaQA0G/H41WoRp4hB
BdUOg3uYtzh6NAgIwVjF1/bSTkhlKOmrMNVO6ajiV00i6IhAJ3OBxL6S+314GHZLXuqT6HKzsagL
n1oCf79eo+gmLv2ce28Q8qJ/QGJfbYYrPr+5rbTu8toKs6B4Q342TYyi3ZzfxIEYmXjziDP9i2Wk
thOeJDzKZ9LMvDYexIzIZNwPydB/JBPsn4vgZe61sPd0UEHl+tRkH71Ju4y8wqPoZ0oNaUcIAayI
uoHmLsjlmPmuU/x2K0n2KKaQZwa23U8iblbRgUhKVzANGtw2ct9RwMMNR+ZIU5NWwptCCrtJYBmW
uUlUbTdRSxFbbMx97YsL62yYh9k+8UlqviSMh9PqsMS36sLyPqBb3VgIV9gCmfs6wcYcjLB/H3+l
FjMTS75rUZZ7YxqTHpKqIWd/WgzqkOsRc9/uXjUD0GMyKKdWOuerINcLvEF9+iEEjyWi/kPdkWqp
jxxWqTELOP8DS7NkiLyJ6Iwp1Zd4ryRewxNRDF7QEr2kOQVr4deKjN148sF58ZFOFqettBV6jfzP
nPJwBkTcwv3EBo69mcifStkjQlYpvv92cnhCj/IMwrbEC+Eb2Fh/crjLHm3XR1K++LaZcscM4NjQ
droGG1YwyiMyySty96/v5YBnKbl2ShTMDmH3LMiSRw9ZQkQYOBNRKkJ8SDDFwAWsb1VeJM4fTKEq
eSnqXnSEsPWHV11rxRgm2WD52NbsXxAsJZUhnOMQIjT37tqDXM/hsd2Mz7tP4AgMNdhCYM2Xtm5Q
2SU5ieLeVc4MZfe301exS8z+kTuKYBw+X3B2bGkuPjqBUjc63Zh6VB5095LiJa63X2NaaudEOl/y
w+kxAD4C9eKdgw2lrwtVL0v1GvRdp6egpTqR0WCjTqF9QOsOZVEq/frKLBDR5vUggih2BAPNGqa+
pJPIxsp3Eh7FaMeTSVp2AF1fyHzDXV1l8Knk0ecEN1OGVTKoojNj9j/3K8OFAwDyt+KI