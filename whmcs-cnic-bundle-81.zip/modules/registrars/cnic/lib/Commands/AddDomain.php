<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu0mGfCTbRQasFdNi31zKnLGY9D/kq7PlVajhnI13CeNs9zghgG2EzrOv5HM3toh1UdH5R10
kodUqFAKxLK8uF69rEIsN0TnX8gAMjkP5mhyZGQVAN/F3igs/aTbUVRBJA+p8W8EXk8HgCLptlHM
PUsJfi9x1skkj4i0j/B5o2P0da5LFdU3Aj7aeQM081RrmXFarD0WbP426QVKGCr2o4w0oFBnI/uJ
wQJbpD+YvSBXel7DavS4axvDAH0UTjQSD4v0v6BcoWUNtphwmGqGIJqNcpjSRZkNLPtr2JPVJYxB
G7IeBYC7eYWDRCdBkDuze9T732E8phj1cMjsoT9v3B5fGk7DryTJSewoSwbN3LsrpZqJQHCUc9TO
+29IhGiuZzmG1YB9UKw2nbooOuDtMFg425KsHTtZX35w6ScOAdfRUEYJ8ErIDvFM+KJHUqACuVib
VIAajy1/FqeCdpCvsxdcd/f61hXIN4z/LB+46cOuCrMWTRuvlfVPHuFZfNmBFOUDFZtLqKKRYQId
cbUyKbb9MiGZi0FPdh0uc4200Kj1Z+5C5Xy3VmRIc7GbL7WNrHW4EfaUaznICHSRzU6FefD1yhhL
97HgGX5WSx05I1fBJFGkyZttGxTlPmyYQh529bLrlCTDaIa3CC4p41cNuAcMDubFyhiLAuEEDAkJ
EsamJ4VBl2mUjOuVfxstCeqzy5t4ag5oJiu2k2PrU+OHwwvK3az05zxc4VRiGqK4lvfNYUaGSB8H
s3DmADvoxKWtjeg3Edze0y8xRddF58lzRfPB2Za0GjXxyRePWsiGp6Yu8tdknXb8+bdA98O8XYa8
jSB6IPskSbaMBPtbWl19nbbq0yAF+AEFsfC1USF6gC8go1wXG8VMBfdtHOvJVFkjS1noJVkGj7nC
MSVpOa1u7Gf6t3yIpH8oU80xU4R4AV4OzrpUKywzZTVcNhj5m3FJoUQEdIYxhM5KYNVw5T4suPXu
AXLZjTC0C66SOHKozAvB0RscMWJ/JC5L4vUNuY3/1pAGdVRmAPms33frfTwvHFtxGJrPfgm+Y1Zj
Stnrt+KbhIkKXscW7ctc4Er/1T57sZwQBqtZ5mrrZ/ImLcqejmbSBHwpBNHP9psqq4Oaby9HmbEX
sA0H5kL09Wv/S5/7EQOdkjb0gXxNjCnNdvAlbbl+iNtxCswOPMgBI7CboMbSmXV3UJy7sWQWEoFA
FHEnYcSXLRJ8L9zbqEB4oC3Kbi72pP1leE8bJipaylRGAaybMrNtn++YUG3InLrcxXyKO6PVVOdy
kDIdzhh7oa2ls/J3uuv3+o2ayhJ1T9+4bzZ2wqdB//4WhvwHsLqj0DSx02JyAW5bBrYuAx01qh2t
zkse8L58+8JM8S9Nm6v2hLAwvKWh78viQ22tPASjs97HxTGotDTpcqTWZ+w/sT/fNFFOf32rdp+Y
WOCYNDVaD3dRf5JUsT71SZJEEop3psWgZsG7fWMJfKtN68HwUKfAYZrAgUdJRUWXXUzPYi0I5aqr
DsXg6mnbbOX5BsNKmf10qYiAAEpV6+TuEWU2RH7W7qj9U4EuP09yRUHBDH1t38ec08c1nwgB5KKb
xRBRq6eG+gAf7YFYPVT3tS55I0V6q/y9ihRvdXwbUSooFocUrD90GyWFwa86LDzY7KS2C+ccgaZb
ZfigKiFmwMGXCKXLQ18faLJA9GZzFMW9tQaTPCgqtqXA0bfMSMctY1SSfCbrT+fD7eUebqDzQw0i
dgrycTHM+RoSFPIUpsjIYFMfwVwddKxAdiaAXcD7OIGVERb2jPCqopZCr6yFtohE2sg2tL0KPchh
p4OKAbgkpC/yml0VXd2by/1oSQqpu6Sj35IK2WKUTgDxsL1hHUWweKBil2fbsQrVV+ye6/fj3OEl
mGHgY054YKWYBFJPpf9wWLFy9u1/nUCvvhPChiHNyL+l6hv45Utut2OcDkFGHyenwD+Zg6Fu9Dvu
xhyCuXSgQBEXRmHtaXqz4DnnYODS8KODxWzPmVWTYZcj9x0NtWVzp3YMwr+27xcOcaao/mAOvmF8
oWlA/CodiXusGF4J+HCsheHcsDjh52/H4vgoWJHO3Lki3ofCKzy4tEeQYXwG7q2wrcGkf9LZV0ez
j8jUyPJ9uAnaU0jxl7iuOPfqNxdlkWIhIuXNgecAPBW3dx+5GczkvPQKFhKrRK2QO8k2alGxphNj
ED0gOcj2b50Mve4IFxn52a1zovj7VcT3LbmotkIVZAQQQml1Zy6JxIk8V4/lyNaYH/P846IP1QuR
wDN3YvLsedLj7pB5d+Xsu+/LMFCNB7/nrp/gp/w3tqqs8SJ9DeXYlojN1bNbMXPy9eT3DUuFgGhs
dFE0UH775XFhmQ64Iz3eduBrZXV8wBcdkCcJ5/xJ7//yYxVsKa34oV3biYuf9rRC8lUM26HZf2i2
jLo0TTyHtOY/o7p9SFEnOBXuqkxuIwMGkp5caMcyrMO4eErJqHf50bXMX+j1jaXbBKdH6pJxBDrM
bd/Axi4iJem/ZwqBQyGX14cRycstVbXF8/Y/AYOZOd2de87NM99oNEnYKT5e+sMt6SRv9oUTme8x
Z9qXzDVvEucPTQaoASrJ6pG4w8FU7l83vRavqvt9ZeDryaH0XkB5XXOFGrLRlaCbMS9ug7tawuqj
dTn+SwcrGsvPDQEeRu7cL7Qgi6B9Z1bicAfEDnGAMWsdtEAJ7B+IzjgBBuYB0TPcIX2N6Of5995s
clf2/qfkUpJsjtJ0LJNobgT1cxg87SOr2XjASp/0HZg9Kt0gE04ubIaOpvNF/IrcVMvxUagKv6Uh
apK/IuLI2cpf+NIHe97ZzVoOmJGhmOwxuHU/X0P2suUy+gzfE588ded3VTlCEigOPsZKpqFLV7ml
hStsTAXnFlQT4Q7pJ6UvKNsXrWa2tF3CcwpA3FZFZR/mQtEplMGKUnLYRKo1VS9LE4idFb/iBhtV
Su1zDNj+5wSNPsmkQrrOI/hHRoOb3hlWTifCHd1+IB9nkilphBGZzNGm9Zv0vcsY7ZSj4SgGAzdv
7FGd8kqWFrZ6W/AJZGD68021XOG0UDRTuiLbyl2L32P7e49cckW8M/znJG34ZICKYFnRd4UFKE7Y
qA9u5uLuj0lHwLhQS2DzSLVqNMH9YQ7naoDkMaavPWEiyAB5WXpVOPPP4sGAAg+6pWAtXXZui3cb
ELqwZ2mjcodQ4a3wdpr07V+zlq8MYkUKDXim43S4fol928NIPQTKYY3VdAN1+ef3mJukJcRDBxGz
OfbWQoaFLMKAo+mrR8fPI3yUPon4zsf4fX1Sb3w6eJIGFsulUsmMXa4mHaLuWDN4Apdq3dHiI2nb
t6C8yCBKofSVPRDWyCNO+TLw/qa6fRBnjqQN9zutvzV7M/vFe/hLjUg0S8JqEjIu+ZDh4SIkg1bz
5HzJnYNuSHo8L8H6LOJdW/0rxsmUAXEsYPs1N5sdotPeJHglaUT0uh88bdCbgtab+8GAA5O3qWW6
/dxdSDwiWKbeQenwkTgEOQhp+VAIU5FXRPDfm7X8nfyrLH2oQor6STZqU4FfcLxaHF9Wo8EUWdV6
nCq39vdUMA+d2bpWUOsK122sntbjYd1WxTYAxWlkYLm7iOUg+pzUaaRCDF1boaUCKj2ucNEB0LSv
hUvQM74bvlCaKl84gCNWZtsQeio5QYeEZOjbknbgZflQEMB3GFDtc0/uNr0/ncUNaUULCEJx8TCz
fF8CUYXLaRQP1YKTv9JNnccqZF6aITg+uk3Zl2j9zfiTVRG6gAmD/uS15xVYDh9K1ZEf5xb1QiIV
DK18sMtwiWIY4eWK7HVb2WHHQe9+dPRvKRSv6jw5NnCPfsY2/bvyIbXFrTLZ1GNLkjeL5FaeWUtE
uT49ZCFZUVGe+uMXlBkEhZ5TS/5kdN3Oolr5WHlZrpH6wi2LP+8qW7Ao3EiRyHU2WASQ4eDZb8Wa
1ghBXMhS0S6sJFYnbRwxglVxq2p/QmoMHANbo2+hRZsNSlYCo2vefwM94Gz8/TLz9+U26cq8iCtq
w9fNzK1qZ/TrE83hAf3K/2Z/cuUHO9D+FKMMzO932m76tPbTGsRzHcaMf1FtNmqUBX9Lph3bvsOE
UdDIQt+1sa2lidM+NrlaTU2DpEDxiq5CC3u/Yn7BUG3mPmkRijnNkZJrMzV3orUg0h5JEr5hUuSn
56nI/Kj8ZYx8/Pp149fms45atyMVW6dWRc3LXfT7YsQHSp2AcWeOiEYY3UHHUn5NJ1citogiULqk
hXPyVaDdl3wzP5JWuZGagUDhsUBJpywqYHX59CMRgVmSJXClN4pcbwe9T4PHMz/F4tB7fUeOEM24
mWcmeen7DipiNXmZFSZJASCuOJYUvXxlo85GzwhMcgsMvZDS