<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuhicRqTUMAos2KCdWslWv6M1hyEdQd/0Uaj0iBugTp9s17IPq8jiPAaBG+v8STIiuDOb++7
YV6yc2Cw3NoHvljaPutmsw2rzqVbtpr6If3Kdd7cv7/0czSBMMWSwmw2z5HCpbr5SfUym51EUXKo
460W+MLtCRAT8f7snp/7ybyTga5EN50IWjEH+XTbHDeuqvf2abVFdHgyXmUzKWltblbPJ0ah7CP9
c+T+WKRBQPJFjTU09EpWUgjNiutWzO4INy/U4jWYIjPLInpJaQngkTCRb9Mzh6rcePvxv9gp+DHx
c5Q49nPJov/EjlZddyo2XfFpd434wXtX5c20q64RIT2uxULT35GIUx4DP9ijscWqerWrkSqoEb6d
zMwUkIS29PzU25EDYvR2hHy2heaUMR0AQ1IIyXuIXskMLHqZomangEDD6YQfbjvDHRjXWDF7lxE3
DlQZR26OoY+lpFYMSGsT+o4TDSMe9qGlRlcNbEiQ8U6gO41987hqfznMiSHv9L61/ojf8Yt/5ulv
wUGmVzpR3T/a762pdk9rUj649lDNDjZQLkDDzPyGxNULeS8aLJ1UepHV+9trzw5HtFK59CmNVTlC
rqL62mnNRQzfXBU9lYU0dteWMBcfKeXGjqPDTun7Zs8aCjROg4mRKuBX5L2HmWvqYPMErV04MAoH
ikkJDsgdGDiUTNR988xxUlhasbQN2aj74f9MyTsBWxtUT872V4iMmnVNl40zyzcPYCTjy7B5EJkx
qoWfFmS5ITXTevLRUoGTf1kPtuKMoOf4PSpGasnf5wUPDVgJdloDmRuI2Ai4Dj8FwPgR1Xc9fxSG
O1UJx7xx2n7kplamdlrItjB/X28bxHFSx1gQmVaDDjKocDrBX+jcmCUN1wNlZRqMTUg48RJh3qf2
5lzNgs3GHA12oc3CbzzTkydkoWgjybn4+02DtAjJUNzFNcR+27TaDAII+1cfgPvrBFJ150F7U7NK
a4TgmRSW1zmIo5ZhucTVnhQo4UXMl+BdLBrF8Nuqaod6bbBXV1nkpGl3Z1LSdUmEPBcTZUX336Gk
iaEJDC8clrWnS3P0RZ78o25DmBpTzJ2Q8Q0cF+rydmUt5SSsQfU141+45YLA3PfT5wZEP1QG2i9R
oLodXL0IlC1RU2XDBk3gPFIehWW2WLblr9PS5GKNFGYal3FRNbETkVvsEtZBDrfIUyW0oQaC8fJA
A1Dp1LmSDU6zowCbaDowRUtZdGcLt9pDjcvItpVyXAI9uVmSn0Evq/90biPsFsAL7TMr9tQaiUax
BN1CjGlzMrQG1C5X/kGeHXdoP45KIJz3FL5NrfY/rKP2LeYyn1CnmrdVDiulaJMdQ8U1Tap/xhL5
RigjCkdeT/HTW2H3HO89VjQgBXnocY6D1Jq5oBFV1UZvPWpVm4gmE3kzy64qQdG0J+jheueRlcOP
jaO47BnZmDDxJJOomQ3eoYFabG2ycnpf9i5MDCcm0zQN+w8ltAOjvvvGh4vUWM69/KvclH96gb2z
0vOpOw3ZW0BlYEz58uHk6oBBxawrIteFSYPkPBLRIBSmfWi50AFF4JkcX6YV0zSZKynjrotMQ7ju
epDetT3+uZ8q4HRNK5zgim1euDUYOAtQRg4speDfkZfY4iFmUJr3lFkOI0qgg5cGfy2qYD/zDXsN
elTxM4pEE4UVbrJYPKFwWbrHL3Xl9Sup9l/qzgPTRiveDNsk2+uWogFKD4CETfXw9tv2rImqq5Jb
h/4d10Yyl1AnLs4R05Mbyz1SGdCTCCBF0zfxci+hIO4QbxytspNAjpFnTc9LL8ltXXm2PiZaCl1/
LOeF2/gMfMNNQFanRynvGQfRqOiJ+Ge0qGlSSKNOVShu2JPhcrw3GqA82zjoOY/+9IQ6Unm81tFq
vr4OGfL8VodW5OdWOtNHNmr5XpwDbp4Zi2D1zeT+RxHYj78j8rYVxK9K2FaDUh0tKlNwd8Q2QZIB
ZfWDYtWBCvYgY88epoz00U2qNsQtKcC9VTqgcY9DPFMmoTnm+OztC46kuFFlpYjeEBuc3+Ln3SVW
/RX+jOkle31OXhUHmZes8XS4nmqt1u8eHQpYQL8i99Chuj6jyJSVi9AoR4UJclkxR6maZjY1ccTo
vo/1KmhgrhumLs4LcYW5kfzgy2YbQpuqjNFWqiW2jfX0xQjqL13eZwaS1GaQy22VFfchUeR1sUMK
wSucLqeTRX0sRuvAwODLKhhNAGl9NrO6FL8wArkT7829bfzfsDTWPHL/+xmIjQ/RNuEwKanEL+3O
d3L/wNTYJw1nXxwia2zmWjDt/0DWlF9vqAxy9bc0tNwmKbN59CQrdo+sMQue7ewlIqZHeEYk3YzX
ednbXubl+gD9oiuo2kmk+3ebylqo+J+owbuW0W0cG47/WsKbW04JEqyCXjof2udf5vxrIVMXbRMT
lFWeu9YyjsN65dhpCG07TM5/koTaBLGn5tJSEDdhFGPuuw8EZraLdkOtHpJeGg+jpATQYqdBcYty
xCkR8k1+pnVC3lpGtUonjPj9H/j9y8yX/IDRkJUxTl1B+gJ3y6u1eBMi/osv9W0agiz+csalQvDA
oqtuLW0NhlTo3xdh1iUI2s03UT+V/STLooe9wBv3VHQjQjce6y5GqiSprAq11iQT5U8PMlOnw5jA
4H9t+B65aKMb1jEwi2fN+6mJ9qHF0+0GDPSdAbiF4KpOQsOI9gx4aWCM5tPnq0f1m5UkuXd2gSn1
/S0uB/yC/jQD3uMEJntuxpiY8OEaBRgWGTqIiCi1xMMQcFS5vEI49gFhXt4bcLHxXcROZv03z6n+
lWh/uWFw+vHW8zxTbJd6UnLDfO96zx4r3omJNopkHDV7y8ae8/8Zyujicknx0AL3SRTlbhVzQd/2
fotNTWDmxoodOJK4oiE9uCoOA+I8DxCk7opD3gmnSyrXM5k5kFqswC+/ZAP2WacUEpApIa+/3XZY
tQI+fOiCyFgRvKdowBpu/MSqkY1pikHyhfvo5TqDupV+2A59UC3t7b4GRo7o5JJAnj+LftDB52q5
hCacYGBcRud7vqrcClqPC1L1hNwD9VcSj8EjyeoBQ+jeI34xsEwkEuWAwrKNyzbOxAhg5Ct2D+Jg
mN134TYi14EtYv2c7gse7CP0XKREjbWHIm7+cYL8nCt3qwwlXoTz9HYHiXCChueZZOWpOxRIIb/h
hQvgGB8OqAlVZlaiWdK9rGtfDi5q7UqsadbhaurJThFNAIUzZAMMWnO0vAO4HzThwICsguizuNrH
j2CxXW34pwxyNopc4NWFWMZSg8pIRjS6Y5MvIoBdiIUsOHNCs3YvRtptLDBAP446B2mKQW15vgv3
WR8iVmaWp1szEFQD/XULpLunHDotMc78ianJTz8S0c+6sDw0sc3pBusgq6zQT1UEJQqFuioSeDuO
PPrH6hGC5JaJidIpTA/3UloPYA2y6t1l5m3UL9bhVEi5FGzDfUPRrjUgNcLRA+lersKa66h2k/gy
q/zETbD0sWdVHgWNMjiSz5IL4ri2+U4hc1vfkRkOKoTovoaHNyqN3jLr1gg9xUl/6W3Jqm8JDSOS
sUvH53Bs66wZsTsm5OEC79JoY6inf22u904MjFp29OHpHVHvZ232I/riryxs8pLM0RYXGXBP27Dn
5/2e+Zh+jXiS520xKCyYJZJjqZWAhks6OqhL8TO1qyiLnHoGT5FfkG1k/dlUH/lXR1H7+zMgO87I
dJTjmyOz3L+Z5VQiwwto3doVRtQy0jXY13w2loEGyVmnqd5edMfq7/klMeyPgwfJtGb9VQNuxhJA
kcLSxscFqthB1PSWf+Gk6TlKkZdXZOLyNi7ER54ACHkb1coiIKot3qw4hygTgdnUc+tu4OsIb7Pj
LZVzWglc44oJEGblb0TAbY2ambPk81BNDaIrX1NASz/VLP7XODsE5qXq3zsMI5INDuKAckyby6lh
XNVdRA+IHANS9Po6VId0gr8TT10kYQ1J/i+6wiTba44TXFGDOsIJmuse/swR40qOwXvYPfIruA32
WAyUa6oEuh8w+aD5PtTI9X/FmSFwK9OXDOmPUB2bjmsKzlIFtsCpxUGn9AzeAVSfa24rJxYYPASu
e9jpB/fffP+OGGC9RW1WmCTbeOmAiHZboJhFqmHC387Qf71KZpNERdzoPdan7tuzjDLSvbk6MULQ
MklsNCoYq8DgTivCOvSoY6LSI93mbHwRJ9iMFG6Fbpx2U5JgH4JiP8LWb+Xsm156OnNwmNiZ/DNm
NUxgPckyk8VYEjRjEPWuzQTLr2QbDQO580iwzqaje+RuJCh8+qVD+oT0592zRN8YsOBGAv4P8O53
0WPfygfhaB3q7FlpHyx4ArNe2hmfccllC4kdsrJuT28aaNaxQQFvurmC