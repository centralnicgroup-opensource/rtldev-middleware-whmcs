<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoi6e9vxnHZH0iarlVYuFu3f6Zl6/68MIx6uTGvCu0dSOQW25xPx5LGv/hkrmaF7f3kRt9ee
t5cZzzUNWX19XC+GWgq/3pWloVJlvemVznPRyxP/p76NqWvOkPAV9sLxQY0HDDfkTeVMvThHAMp0
8q1cem0z97UZ/M6KkPZwxBxPT2oN7sV0FrWmz3zIagYuXtfvPV4iPnGO/5G4KA3Xaq2r+yu8VQUK
HsW4ZstRkvKdHW6sb/H9aAzW37Pe/+NonKZw8ahMLKiSqv6iQhdJ6vILlRXgRPdQn9waFaHDk9WM
U6Ss/q42K4yakAqY13h1U6WEHlOLjkTUQXZwTSK6Z5hTjePINpwsqEfrEYZDffdqvVnN+0QQpaVH
QudbjWhVAdnNhnO9R7CNwmIapwkY77hE5O6TshBo/9SmzxAzV5+a8ZbgFUFQZDaB7O2IdgHPvf4S
vLswRx4PQmxxD7sQ8fGi9SW+DO0VE4pBnAZpANbWkrJTryMs35cyGHp/mybfxR4Gum6RcWt37xL/
X6ktyUSZ7JHI6BJJLQclo2sNxP+fLKFmAwTge6bPHjPaDinLE20rPH3wV0+ySp1GAbxuHcwyZxG/
aL6mHHb56tw0elLtkt3Z+QrqRlMzFvhKV4ufeuoJ5M//Ujg2bdUtSFEcvFTwPKHKBzxlqcihPSnc
DybEJGKFc9ah9zQwFRdbUvMSi/B4RlEk6/owYLhjr0aNWt3bo7qM3iQnqX2wvdyCuERcUQ54dfnL
FmW+cViaAIpCPrMZaSH71YtvZMyHSTcrKZi8fXqIR10O+NCocE/cutxknXVhOVrTc3jMeqPRaOrH
LgpP0/wbCnubZiBP1OnAjaaEjvrwqjZjblklpCoyDd/T4cx2s7yNNfzQqSVr3H+vGMhPHnqGNJK8
GjTo2jblIRikH/BzsNB9wWnaK7ZWRYn+9bCIGocT/ysZEdiIpBUNWa4HflKLuDmOmY0pZoHT/10A
gpOvG0C0Q1E0PmNxYYCMCugVrZGwOueK2ypt2ws8xlSTgHbqHKHVvfegS+YBWWJiP6wtbuUGAZXp
oMZVXkUsMvrGXGr8Jz0ebEKXIEsDGqBgfmifmQId96av5xXVxsLtSYahTO/p1C1N8BTMJMOuknSo
2uw3Pc+uHSuc8InhTjvdgerVMIXr1BZPGkcvGfwKOOkL9doQ5SnB+nX3WNPmYun3bkxripiMRQix
cuNeij2iQZ94v2HX+DZGquJGfWoolSyZOgHmQ/DPafjbMDC+Ai8kbxYBdrJF9J+lyXHqHIVCzLP+
yFo5jNDiCs2XU3c+00GXlm4fU7pBtlt/i0HS2tCZoghnWxG9/s0JdCnFvvCjri6p5S3oDwW1di6n
9nlDWk9OOi4BuY3lBnSFIC8zH7QQBpChnbLcicBCQZYkQNkkJXa58T/jfz09WiHXvIN5jooCEDEX
GGW0gX/5dYVHZymQCa6svEyYBGSxNSFPsEajuEhzavepspSRbnWA+IKQYChNPvL7hKV4HUhIROjU
jV2NhCauqm2a/4A51Cme3dr30IyI7wedUhf/r4udhYSpACirOlwjlvFGhiTDpH156xJuzuCKFLdW
DmwpFXrtx9iS9iA/rEX5xplh+FZ/Yo86yNQcdGvu0+0nzPOmG8aSS6kxpNiHnoDr7RIQ+A9Z7z7F
weLxGHDlMmuEndd7ubLfmByCTv9jI7MEq78MfnmSZD8tIkW5zYk26SPyWwxR56jyo9AJLvcN8tPq
cBiPmkyxxGHQHO3dwVrwMuWMzn7NbykFFGJJA5ajftau0gKdWXPuiAQmJ7SOd3kARI+rN8ZnI8Oh
ZsWQOsWvs1gtrDW/ju11EbDytdSQmsHh4wyA1C+FEo4Cz6nTFIVxq5u9X58c55reHoHS8SSQH9Zi
rV2cvIGnTWbGAJiNjQy3U3JPURu7m9k/5PXwn6iELP0SdEcNMGm/tn1X0U+Ewh3EGnTX4lBcfR2u
gTIFgPggzoYL2E9Jp5z7GR03nUSwX0Rcm678OaP9+Zgr2MRI4EoRGJLknH2I7i6Ozm3IlOFPxw8u
na0PsJVYhc2npssq3RXi/6AERJSgzrtGP8BtaBitJ/xoilzp9RATdWgVm0UeqqIqajJu2vfkh5Qt
Bp8QSzhuf9mVIcC1mJc/qomHXDwfp7BDOe1a2pBJXQ4PObeitFMMyBmSwlhsVbQ9ONpTfKe96zyD
FdJPzeOSm96QREFqDF2s/XkYLLZHjgxvUrv4o4aZlYvkbkAPJjuNO0QUkPhS+r3tqoHRXk9PTY+5
5T/1RfpwIOSuOBHmdl5OFLZWZftmpsGY3ehAniFb1x+CfKN7dsA35TMNq9uebg2yg1G3pYvmo3Yj
uBOGKW2HZN+sMEtHb6xq0fRxkuyJMdoUVcxhHhD47cuDj3CMC4PXUtknhITkn9JLuynemNDhXmI9
wEic6v9bA0ZfC2d/0WjxrFWfUBZg780skNVBPpOcgvce9Rf+SgqWMVlU6e9+UM78A7ci/DrM3PCo
5A22l1wXaujuVYqtUZ+lfRTy9m4kTGAIrb/Pnd0eY0P3qMs01zoN8AH+OnM8FTSuipLxDsWSf8C9
X1z4OivpC3YePiNjoDlUVvOAUW53vacFtH5y+2YmvL4EfvJS4fe+LAJiuGVe+Wo2K+o74rCSn1el
dgLj0NfNrXrxUPHD7iUwizqdtWCEEL0FW4HqvKHYKqYTcRP8+kg+op8ACU6u+sDvb5rv0y6OsbaZ
ZGiIRBWTYuPkpfLpdiW1Is44/wHnlIPOmFNPkTSjZFvEmGIPSm3RRVkOjHtEuEahWe9tj3EF68Yw
MiqAWY3s6qlsoYwnmKcFDU5zbry9a9CTUGaMs8aNxV62bVHs8b+YG1ScpPORrfi6jrVMOjCU4+97
JhNUB+x943RPEzG3bfok1d5FHM8COc3/U6NmzovRB+lT1f4Rj+IuQomUAKchZ7YKrmgLKbYaSCDG
2MEVkX4Kejj0d9CSyzd4siPLo4z83jJ/QeI3Sk9n/BmKsWK0mhKk5GNZ4pZTxqkq+3FKrYzWcRTH
+gTPp5gbviQRhNTuCgGg7xXi/EuhmJs3jju68Z881Q0U967+lbucLH3l1J+0M1CCB8Vt12RRHGnG
1ZHiHzRHtkO7VSbR5Bq0sTbNdBwOiYmGGyPyfyVTd56LgjM+7jEZ3ltjnqjJ4um4pTi3SpIuAZMu
9jWFwXmioLMisQwihvw/dKHYZvDd1Us0x3U+aDpQ2npQLro5OXHBuiHpXa5EpVvd8Dj6u5tBzczO
C2ucVZeGuKIpB01hyFu9SrLBynrfXP9eNYeINQPYM9BPctB3PvGYzAqRJFuljQ5qUpM6BhET5fEH
fgM4FQnuIUNGLBWit4cPkaMe7hWO+Q5iYdocUhD19JBptwy4UAVr3n64w3MHGAO0pexmDhbfY1sr
XS6H8cyS8TJXOA599qU51MypRxkIe2EJW9muw395bGE7pfDPJETLtPoX8KxV2QAofigDG1CPvMm9
+HChqCPrztHfNutV0OiZsw3P0PIP6ikkxkiiQozGjeIld8u3RiGaIe3Pob7nMGm6uhAAeuFWqNLF
I3NTU/S8how1sIMEU/sZd+szQmkblXAYXZe21lpgd/ZT+MxDygr4HqsWRiFyt3kXIJgrz0zkeTUg
35ZjR/WZz+imqxVklId6jgEeNPTddjJmoGYcaIlEBBRb9Cb0EHmNzvBEa+IqLXk/O1lHJrYYTeFw
2rOwDgv6YNEKHqk/ufPEh+BgpdjA+BFVnBdbBBIZpPhOkcKp5oaOoWSkSeuU2ltSbqMd5V5PdOrS
sYXrvySJwpWvWD9btSXMVT5aNjdVMy2n2Y431aq8zxmm78zx