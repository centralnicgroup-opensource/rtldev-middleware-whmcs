<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrfWIUpE+h73bwZSpo4YqaXoJWPemGbw2zsE8Bqi9+RPmHo6Dz2Uu3GPMdNeAKgYbMEdT7Jg
kdEaedZxy+w0YL73YiKnMUtJHMnVEA5hSPFMC8IcWimKFyR/Corhi4Ec5rjzVVsH/f20K7PB2YQB
/5rgf2ILmdoQ7FIBmHhU5HaOiSoODnTTREsef541vC6bQwjsrd544sWSBGjtviIbTsUbGlGUVIKV
GPyfMZxMexTHcBEjatCDErPoVxvg8xGDWkgRsMBcoWUNtphwmGqGIJqNcplrPxbZpUXqGcx2rRBB
WACeCZZhD/gqN+h+eOotxaqHgg8hjUsM0uM7eP/40u7uHJlRWUKQC8RoUEuFw5/F6+xmcwqnH/B4
8OwH8fBA4KREh7dtlNXFuZh2E/SvAGU2dza8UD2/MUs+xqWxyVUlTwI+jn/2E70US2Lf1oycPSpG
fFdPt4H73OpCpbrxKLYbgiwOUcivaLS0VxXxItGHvan2IDQH2GjDXIcS4w22aWmU+oPa6ArMv0rq
5l6DUeXLgVvF/aCqbRKHoxF4Rk8McCPcq7O77yt3nbbyVDnN20YvEMZFEV3BYmQgB+ivfS0Z8STZ
4/3FAoPucWcmidwq3kTidOXxuxwSL6+iT+JNvPm9zggNPe6ZPbvdHve/Yfp6BsV+LbLi6+6XgHEF
f2dMjaRioCs1OMfK2yCAPvbcrTn4THbY6rndJQBf9u7vNggDo0KTDW2zOq85mes7KJ8/OBazXorW
ju994OFbYIowVq2fySZnbWjtB8xTcgP0UCYFtCg1XdKtz87j78xm21s9gluWrzWBRBIoVIc6a3Hx
zHi3ITG2sdJKl1aa4zqiXy6ELtlChPSUzo/Ug0Y6+wB7qKmjHDNWAU/9VzvKKuEYTJgzyKu7Q25L
znnj+MXWAHI22m2JjBm+mKICCrHUZDPoXObAgY+kuVtE/xzMOYhMKKy423CbJTM2crr55WBZMIc9
MjFPt9D+YCxFUe3rM1qPNX7BfghQ8UXm3+YU66CGCD3/SZrmyyST09r6QeD1cHTvPXxXikIBp6RJ
0qIi2Yc60FL5dCEzRNfxwif3WonmGmPjILy6mjxux/UjUMQdyTEbVgZYMMZ0J1q0oiIXwJk9uQFl
OPG4HBbWXafCtCDd/1pRG/cttLVdA6MllHv2yg39MAL2QwjcO72vCPR125fPSPvyO6LE3Co+q4RH
ITEFSehY8s5W+vKmXSaOsj3rkngQxOBtT4rzKpg6xP3aAmNkwquYhYEHbFGxfdSqAyhSWMsYxx+z
3gETpWYyrKnECE8HG9jgGdmSEXYZJmF5Nepkp8DwLztohcmW19x/GV1yEByKtRZdDf1SILnIsuFf
cOQF6+B0D0JZXSYGsxc+fk+VFrWZyajaRDeVw4PUWz0Y6aoGGypsba07iPcO1V+d81taLV9Qibbz
i+82giTxcvZApvlaVvkhxV6ahjmEQlCtd0J+mzk2/N31Ykw1+ra6kjBocId3DGFgcOEZiB9fPJHG
0LO7T1BC/DBawgO+djCaGJlc8tibZpQMvKPk+kHgeXK4l2txTpCSOWxV3vu7EPWNIO9EyPJeX3d0
p26W9+lHd4m55jdkBVQEjUjyUgeEoqhq8yZ2snQBexXm3NhiklFMmR7g+nl//fmseFBfOXesbDYI
xGiuHoyU6ofO+nQw4xIKoxqZZhqqd5GxqZ9v8KFgAbkIT1tpg6djWBrb600SXPSa0G0iVb2tX6Ug
nXC/8AZjzlQxwnaXPEezai+K0wr8ack+7dlMuIf4Fwtr/Sx/o8ub3szzeUxjymRi0qVT/HFmN4f4
N1i8MA0x/dhEpuzhbnqwGG0lviBgdzOsEeJykg1R8s81wZuwKRlW2gAn/WQwnzv31NFDr+o9Ovsg
uUCc8leuOHChR+vJSV+zz6MzQ1RxksFwjtzkm65jBexoAgzHE4gXaQgE6EP0nWCMV3GlcxsklbPG
1ZSeKrVcvfjU92pFFMv35fvRzF42qAHw5htDz5LM0Q8zgRVb6W67gJFZzu+B0WVxzI5BuDjrObne
Z/feIxk83fkchwZdoBb+sSCaUnv9BqF5wDQmKoLhwT1PVsHF1UNau2Wr8fJuztWMi9hAyApbPrSQ
caIxcZFHpJdrGXlTQZOZ+P6+69zWsbWE+QOR+2du7ESP0nDbIOTWjpfMPvg23xQSyaGaa1IlnK+1
w5mwPj/jR7fdWc7Jp7962rZyI+Y91wDiQzlJdu54X31IBn9eSvMfq4lvWB9gi5xS/2zxVUn3cyzv
rxHO1in3DsYDWmCYNOmeAsKBNa/AD9DzaaW0GHf4q3NqX0WenjeGNC3EpHgrUYNH3xDPQvsEDTfc
XFj78R3fS+5uxirlZ6JN05Z+KRvyOTvXsVSJQWNzMf7Vawi15ZfgtHAvbfvoim6ZaE+3OhU9eFuq
0bTI8WLb6ZKnye5Ng7mCsHmjY5cusbPgPWrDU+4AZlnxK7IdzTQ/bYasWf2tO/O0E8CWK/UM3dtI
vx+aMwzP/v/5kyTPv6i8UEUC9o17kFkFjOolofglVu1yQXuTbaFRbDwTkNV09k8Muk+3jB6OV4LY
DlCj3blgX2zYpeXEDs5C9xf++Na/nDuluxwi5cYbtPojUlIdGPb3RSa6p61y/ZMj65Rb6HkMQoVd
geoMcNiSFIl5F+LUuL1Mfvrgfpcq0EB3xt6LSZ5H8ZrgXflV7oHwpdHaFzl99u/bJ6306WxglywI
tDLRbnCtFUwXH34cOK69Caej48ryr+t6TeUBkFbgoBslCm6DVZI5GIuS98ACUSHPEPhAPDDpouEl
lROqYftOTK+obPCrTZB0+JEnYqO6E8WipMsifAPmZVLvaIMc4PdpILk/z4wtIudOVUe2zui1PRw/
58DSPmse9lOZA8RK5oSvViFiiLdPx7mJ4zBRz8gRAaTrcE+GV12oa0tG6QNQQf9NNEYDayyxmTUS
w9HBNMZjUHElQF8M34ogqUKF8cmXjvlWxhISFYplt9VXGunenmjWLG3hoSHYIpJldRPQ0cMIMSJB
Wy3k19gAefiWXgpxwIDu8BTz3Dzmt8KbImfZPMrUtqu6+TgtYrGGmIHArt6FYpb2HOGiWXkUqFtg
JIJJheJYvRpTHeS8x9gDD5OqeFyaccCXty+pQeshgsFdzJl45heZJs1B6XvZs1yIARijtVo2wBeX
8MfGaSO+VZbK1+I+Xhoh2oxIskdXskdmodFGaOOOX0iVNvyYVUOl3/SDdKgAr7/RVLx+lH6Gbcj1
yAUF51IcOd44srggcGlnqWyO6ybMlqP2/oAlH5E2coGHO70dBHcy53+RIZjWyJbDR3U8c7M5QUlV
oH8u7QYFjN0AI6Ry9rzEJAffQoop87FRRFSJo9t8Kx9z7lQZmFmYOiigHJeTiK4eO999ICv1r8V8
32llLcZgSSJvEJl6faFpAi4ziPK0+Jug96rb6//f1ik52I8r+QouP+X4bUonZYzjlqVNsAHoIVxT
GeJ6AaNurTb6n38fbMDAuiSO6ir7+NN8SYMeQ9r7bNrYkstw4Swc98yuxKl2PUqlVUWetpr89fuH
pb7OgSlZVFDkdp811/JmlV8Ac7z4WLNYGczSqlU7boebprvgARkvje7bye5RWk4flWHVIHRWKoXc
PTiP9ptXC5cnNW31Q8BrMZNL+2sTEzKJB4w3OzYrfWiClw6zQx2U0zGKFWxtOY3Hkv3sQdSIfc0n
GxnPYdDdBg6TN2fmQw1O8Rno0T1B6nQr4R94tZN85cjD8bLV2Xi7ODOp5UDjgVbIoPbhNFTasqyA
ETJTK0tdMbsEL7a0JiqNrsLyfMJ642FZzCM001V0GyAeF/L+m8/hRNKX00O+Z93p9eoch7UqAsGc
5A4O/wutpW==