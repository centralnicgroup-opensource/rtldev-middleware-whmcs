<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnOLHTQJ+RqPQgJGzH1AmfpP3qhqEuUT0iblFg49o5S31KASLBRIvzV2dhizetUKXxf8AwpV
sT2jL3iOi7Kn2lKngMH3xr+Go11yETmQ+7kdNEsXWDh29mDY+vbuTAdXbGhiMF+n2FXfVJ2OO7G7
QyycGAylUUGtRtLAqumWQLxjNeyfCvctDUVbjKWr0KOOth0vgM2d5BWAIcWdORbDFGGrQQe9nkDO
Tyw0yxN2JidTZHtHuwxabdlUyHn8q9DhuD62No9ArbLB7DEHh6gvqnkKbRrFQeoF5wEb+KFQw8kO
PiX7LyCgbmHbvF39+RYgjGCjHF5hFkCbqvbfa5nFLBjKQqVFiiIFEOkLLsbSjeKwnjSg9SLVRvia
HoPs/oA7g7Ssl4C0j90prpbCOty68ZPaTRxZpL/t8w6rbMVRC8TBYyo1r+RlmuAbN/LWlLFylhL8
YVawGBaZN03SuEH/N6vY+eA6gDflzsLdVIvJ8EQLOrALehVHQz8jwLRXr2aOPCBd6Oz6arkkio3X
PAhMCCmTAnALnZaiit0uhLcV1eNxt3+InJyijsgNoqWxQ9146FthVZimqJ2IvpBw16C3S8sJKEte
9ShnPSXBfFc7wqrybYC7Itfu4+7c7iPTampWZ1Ekjxg4xezu/oSJNnZ2hC/W24qwGSObnw5KyDY0
wf3yWzEGrQ+oCrZtA5Pb5peGo3r9TOVhbd/xccGUo0WZnBJBJVwpeb8gLDqZfRTSfuwjkfkbouV1
FgeSA8w7DtupjLJlehdlEQ+09KuLHmWOhFdxYOrdnOwlWekzHjVZmaRAag/UNJ6OBp8nkImXJMjW
QnIAt0LfoazncIzDeB1xUVAsX+iebA+pJEhW4LBs7mQqSzXbtwPY66+s/rH5S0qTZ7NAUmTGepar
Mzp1r+O4BL91shxK1sCDQ25LHOoVnjwpqNPj2SxVZdNw+ijI3tVm69XRInKzXFkoKoQ+1V14qjwH
QpTP5yJylpqXN5B+MLiqAgDBpnVo83bIR3sl2P/OA0jdcKNcIgFPpQMpdSuUSnnIPBTC/QmP0shU
dpBKJQ9RbkvB4c1wpjIsvXtj8J0JcV1lnhji0v/wIFYLSxIQL1t+w2KPfAArx2rkcbnz3X5UNLmb
mHRUBGxoxqLfD7dxSSirYHd+1SO1HaAil36r2GJEwQLv5U374YQqSeqjQi3ZbuoUM0eL/ZItKNEo
8bMUlBz3nxn5oHT+n2DAYbWuGlX9RaBZmwKL3k4QvwRCzYXo0V7yBkCclweoEgiBSg9WpcuIhYx9
V8HZvlAci7Hz/h8SnGiBTKC60ucFUaZM8tyWrfXkQX3JRDZnpdTlvBgQx0yaBVUqQpiME2n0SipL
9CN6FeLGc8KGicY/NixoOgzWxO0714vbLMiWFXtAIncqlfzPR7xehE+KeN369rJ6pUlgx8i18sks
InintqIZz5sBLA6NRqKvYnw3XpriJEGB6yWeYM4xBuHKG5ZwhhgLOB3nvXBXbKhNMWVlGTTXgZSq
AuJCZ1Dl7wt9ERz+FlJNs2olSwlk6HEI46bxRTl87n4Jvy7ykAe+B9Y6fYwv1X1Hs8F3AKBvT5Ar
XiA+knhzg9Ofx/SlxG1912p087fIOS2cHzj58wxJMkGdkgM3TMMvFgLTLq7jIS1JwIeuldi5Qych
POHOhl++glyRtIO=