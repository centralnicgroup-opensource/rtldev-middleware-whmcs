<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn/Y59QUJktPPrE1jLgOAnm5vozoAUIsZ+DbQw26K7/QfuGKBWeiIrYl3NH757q3AIiKt9j4
VuUCrmjlgzkQ666icgwzDoVxvVV1CVI6tuiwq2AJyl5ikqDgSOC48pOzyE1tOtkI3kmPvYs+WCf4
h0VZRoe4uN+o0l/8a0kqIVkAKipEfwoZcSZouUHX57ICwjNNH3Ff49EU+7uUgxz3vHft3QEu6pVm
IvR9wGR0SkEuqp8L0fdKEub29XJ4xFAFwe4Dt6BcoWUNtphwmGqGIJqNcplBQVJfvcwqeIlcLVJB
0637FmVBUBw2N9VKds0jJRGZhEK0RyV6IQfcC6+tGvcho7QL91Ly35npYQyTAOlnR7hXjiw9bDK2
f3kmKWBIKSxZ7/C5X/IILCuA0zncSJJC7Xm8xrt2EBRICRcHZNO7gOmsrRPaYCWlE81fNv7IQuC0
ij3BNYsB70T81/lthuViHv/jWOqoc3L1HWrwltHkYlFPkL4AmlDSxEsPM7rG4gNCQ4QDziHe8nZE
9uvz/qTwJfLCnE8TNwleweDLtGNy6CID3Mvif5pRFZwn7ascQT9KSeXEIg9ZdN3R3BhDFc8wfyk/
WEz8G4EVo6fAB1bwZYNYNqNP8lK5xyaJWcEzUYdW8N2mL21YvBS6JrHvD3JrnaJ8K/rnEahUHLiS
4AycmAXY+lm9kVNO4ll0Ruc9d5Nrr8pCjPNhfLsL1UEZlvqLhtW6eYwVbNSZf65sBhnlIx20NVu1
PibSNQM64myL/5FgRophyCd/lod3pNWlGfzGOPxjZwyi2ZLX6t5572j7et+CRG9QAdVu1dR8yiDL
gsj+R0PqX2qnqxkQkuPgd4lXQ4WbLJPVGMM1+1cWd3byhPmWaETsXqsbK5TqE2uzMB6D0ipCkfmi
GDc+6tyJCR3cAvXOGMGiY1ivNDKLiY1FWevVCzQT6nh8Sy70i1o+AL/aeftxLBvNyGgpDx+qdwca
3OvIZPaoLeWcuGu5u67rrDPQsae8jZMqWY+otlmOv7H3XkMnTN9W2YNillPJMhfR/DxmyjDvyfbc
ydqIrZLPGDGalgfYr65O6ogE+cmfKTtDPYgNArJoXoEaoX5R29V4rX4GVH/CSfSBR72rIR6yUEWd
lN39vFTbjsJl7dkufqn3XAGVa0Xi8Aut2QRk+fKw664ghUYWRrQB154LL8fT1iCOkD/oSvnSuhzv
FnJqbQ5is+qIkykdS6qu1wOJg2YsCiJlFNXV+fLaimdIbJTxIh962A540i6imMh9mTleDyjdCLI/
Dj41Xaje7FuzSv99T6X5LbYlXXNBJL2yFQRvuMoTWl64vWbYSh44Z8htirtZADqRH6EXYdk3B3JP
ez0sM/Az0iUAt8LphEBcsDrKeicZx+OgoRlELSIXiyzzBpuzSZvHMJ/72cjXhYQa1yHBZEC5jan7
8/0PpuojBMvg4XWuN9PKjBM58xxBMBJ3T8khdNvaJJl4LkPgGfq6U2HKu7BIPc59PhaV7JBQYKKX
zhIWZDdMpuf4ak1rHkNv2zlu1IqCGYrFc8xUNpS6d8KNzNhQel1fLtUbIPjMYSzeL+WRL0LRcQ/S
kD9MxXJ8sw6EZv4eEb3CEhCPofAHO6jSJ2VmaLIyRl7TpF8/BDRx8VZug7XbasC9i3GjRD0gB+ts
6wgW9JNnNmZWjO7/TQMA