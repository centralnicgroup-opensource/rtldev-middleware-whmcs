<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnMNlvM2C0JQMrqgjircr4X7ggrIhndVPxkuHJsF9APtGl21pJZV6aYQgcKVnH1ARxKYOG77
7mdv9HXRRqceUv+FMX3GBzaIGPpEM3f7BHwNL89dQ1M7RJ3YzZ+6OMIafFSNXYVW8w3C/Bn37yYP
WByns7KnFVXlp+XYmucSfteYoYjzUxhtMgISkSqfE7iI/BZ5dLn9jsXJfax61ODkgLO2trjzPEnn
ymw1iuB6XwBW13SS5JL9oIA4EHePa39k5J4+8ahMLKiSqv6iQhdJ6vILlHzYDd9OGMAMja8T8fZc
ikXf//4PN4JWOOeHbLjmPUU4ragnHsiiUBj4Mfluuw+GHpf68d/SfPVPNZfxzyFAJof8g0zbQAhD
Y0ZLRK/KkGChVf9d8ploWARAOXb/exsE6zeKUsA8Gd4VH6AO/cVU87kFUWS70fxvFHnaRkSF2Zzy
xpQ4VNLXCCZ2LH+j4DqSVaL+u/nYecsuM87swErG/6G7Fb6uNXXgDD1IM4961eI1VvYvpAmkfWg0
pqjhGm3qjgIxVxl/iLIgqowKFWp7rxF9429eWgHOd/pZVXS3TKhYcd8jr2Ij6+Q5mjqzX1Q4utqj
enWjkiUfa2B/37SryOABfudxql153ZwqKmJYsiGMO0x/o0SQV21ZNX6OITWG/ehwJKyCwvyWfa4T
QBNNJ7ovYvgD5EQmQ9X5TF/QKezFC22vTEjJeDYu2oUme0rjOINg3HOiWtT5KU4jNHTjGjxrVHSz
hmycEgtniEzBPQqfYRixi9R6H7sfWL+auTBV2TDn4CVGURGXcZjh4PrVv104eXJTBUKineYyksSQ
DH+prI7TNftyViOrIxWZqnZ3VgVPKmVQgEKi6uABzCBJShduX42kpay6cwbyBlshtdwPd8FidBPJ
IzGps9aGXw32aP4RXVzCkFGJZlzJaB1zo5mTGvamvsupwRnqPP65ZGL2eYqID56OTWBpuC5dA3JM
sy1WQZJWCGcGi7tY69s/IK/kBUJS10f5/Dru5PBsIH2dcqRHcUWxz7+OG+3IZoeTBc3o3gN7KY08
YgKIjzKYGXlZHnEgm3Lvzkj92DTVSnY/8q/iynyg6XR5mXqkFwbvw+XVQa6rfAcYUbUDfHVrBDGR
YGLsSCZOUw8xg3MotyO9LeTY6F493GPVxVYJVPYoHdkQk9i1G8ZZYJsvFt01blq8TBRmCCPMlxQO
b7gZRUIlW5esi0BfekpOLY/2/j3MfBb5Quv+KT0gnuGdkq/jQ2UA9bSzND1oHgU4bima4/VFThGr
t6y2agPi6kwHpTKCDNZEMv9LBn8+d18zA3Ln6qSCVlzj9qcsOVLC/x65iBagBAoVc8YiGNtJwUKP
sNsIOsEjle5EMz/P8774jj417XMA9oymU48cDHTrvpE+zFS53gdqEejkVzgE/byfbEORbHEx/ip0
Q/YAtLVx6rBUiHijE8J68ZkUTxeY1WSQ6FdbrgdWLkNJBF2BZ+Gb6u5OSSbFwH9CL84T5vebDqtM
u/GMBvl19JdQOMgu+cypRMktNhRHFJiLH8+iv09QaJquKnx7IyZZrw5y7eVHVvsga5FROQtXkNVG
qGkS68EL7pSmKMwGR3GTmH6AQGbW6GOAzOpnw++/BsKOpPusIjuojKXkj2jnrOEeIjb6vPq7CK7H
r/YSZO/6EXKmXKG7thqCU+OLCOGJSFVDmkAXvwKdMGou9yTX1GNCkQWeYtmxoBo7y7qtOoH+2Z54
/qUBv7l9MHE+XYcKihq0gFrdP817ZtOtw8tVGQtuRx5QNYFS15BdDGa5NMpOy5OEmxck9AqPQdMz
d5iCIjbzYnzgpV4zq8rBOJO+46S4pjAN7nPuzz8kLZaOxLzHHp8j2NVX15L3nUGKoEewJ3VzRNv4
VuzX/HbB+rQTM1aQc2mhw4RrOjgVVP7Wf3A1xoHuEIBEPgHmIAEG9kGTLEzJNmhx14FUsZJtw9Ex
FMJPt7P9AfJWA7xPS9nX3Gf8rRGWINQB8tmMPha67QBPvgHpVeAG4ARASF/hl5Iudr1GNhyqi72H
dXACVlMOi0atYu1HO5Fqq4YBX4jp3B09uIV5aOZOS2tYhsleNkyFjaA5yEmGJ+nE4EUOCjea9D/e
QFVZTa4vDBJ8Iy9gWWHsVa0VAJEr115J9b2IVWc2PV9nCFzXimOQRaRNGuveX571twMxhok1UPZv
0d++HUENlhvLoNkaOXlnsSVO4ZVQTidWcGbcUTCm95KGnrx1o0Qs5oDfo3FbapT7pfi+4JMx6X+E
C+0lPjvCe6yEjIRu0kZf9hJ/yStHjwCmEMhZWGeG2fn6mBNztjWvgxxAtZLDdepX27xWiMK9zkwb
LsFckt+g97SkGp+2h2b7/wmi60WmGWuAPWbstKZppM2sSEKi8M+Yvl99LFJI9KsLUOREpSh4Pb4+
6lpeUW/pR/YHL94p3Ijyqqh1oifeBt2fbdTmJUc3s3D2nZdOV/pAG30MAPKjdhCCfFpn7Yydh5BD
RNp+8VYQCwqadrTVu4/jHZxSCMORMOi2GSxcIfG+Ap/j/tanfPjaFpjRpp2aYZI+1g1pXBk4S0yP
jtxxVtRK0PIwVqwpsAMyjkOFHaSawc/fsKUvV69V+oUpTt7KNJfjJo+SiJk3HZKidMGtdvNH3M6J
uMANTnfFUI958jUkQq3MUJSoYMMKcpCuacIsJN1FargtB17UfWr2TakHH3qr55suBqp+DQHC378Y
CIVREZ1Q3hunIJP4Y6vj7yIxsXIJSJTLtL2ATIm1tREPsfI6lQp1iU6TvoCkCwgnHca3mwli+bHh
ePtJweW4wVDeLhaLeusv5Q09EPbgddB7sSJHwN2ySlOEEeD5JvhzZTvN0o9TT2hrLemq9Blpu8KV
mso+ZIxEMGrjfVdgdf5c+SuObbBlUB7d/X0YrqK8wHQdu58vn/BABabcTsnSTjihy5r9aH0Irpd/
5Olg5EVsG+5iTZNS2AQnRqZFxD32hrIdmGUXp8MPOWWeCNdbVr0k9zI1HBSWPKbzhLbkfnpf0kkB
YtxKSPt4VJlNPOdjMbaLK0P1/pyPHlyFgzU4rb9or+4i0f4Xhm3m8xPNhvy5FaV1LkVBmja0LNux
H9Sxbvmfv1B5dSR5KMIJayEothSe0OysVi28sydWoG3u62C3j4O5V30IUFYHY6cMIcf+BlnB6fdt
kqV4KK8muMOkE5zos4rpUuzMaDN0uNKcfKZRaLVQoSqrVdXUnfj2ynLmJyzU/rmCoJjFXPBpVgrB
kjZICKpBVTRJ6JfzOu6gCEGE+pIGUROj83vTOpZjU7cpx98nGN5YmO1YA5nYBJXe6bvL1dZFXIE7
DAEMGZLNLXzL6I/Hlaw6+gUZl884h3+kWvfoIA/JruZYV1Q21AGuFjruFHGl9RDs1s4wiBOkgqCG
XeQO7pwEQa3L7UEcNNAN9EEyRVgaVg1rMPNRibDe5Tr04u9EQiB1Pa71BrJXH74tgW+in6O1CZPN
0nAPs8uQYtIKrL7G1N3vosHaX9xY1kI1HTLgyOiu8WO3bzmYmN6vCIANEPJEiCd9JrNE8buV2MZb
Oim4lvgT8HBQUZgkWXvvSlp5FIzQBxoQypOjb/0dk+5txZQIWylyjRB8xeEvOgvxGpNBYeSo4jeV
chKxJXjP+HNDgz23Kqe0+BFbuidmtKDfEwzhhKeHnOAiY4Uo3hvWbt1+bRFkurbXptffTKo1kpqS
wi0PpJfbtFNDzAKkNPSiQy5eBXDyiZvE2HfCj2e1MvwazBgZdvavGGZEIJPb2YHsJObmO+GPgH+Y
0UGpWtnOeI7S3eTpXU8RQl0ub+NTehn0CYp0mZTEyNYMPR9SZdfaplMDrb0UDvgt4s35ztZ7hw/5
xRQSanzjhf1RfMgG8ZW3PNdjuoXEgqR9HJ9C8HCv6o0adiG9Bc5KZfRU9fHUEoniD7OPmKdicWJo
NPtJ2qynNyLKbAsmJaRAUAocdt7IcZgd5F3EfgIg4ZkJq7PH5KnIX2gz/A1QzY4K2EJgmuPtgInd
39z1Zc2lr+Wx2/7X+TQV+1Ixfmid4tuQLlgK/9pcD1yZGjEBhwI4sI5qFShz8Iitb3JoPrGRIgxQ
J+TDR/zOsB3Z45tP3Bg6uyYrYHwyKtvxkwn6umh5jJefNhApUVW5C3jLdeba95+Mo5Bbiyok60k3
ytXgmkaUDcPcKO1Ixc7WzRlaWXevmDukSp4nfWDtZJfVEksKIHgD3PJpmwo/5kq7mAAYvyjrxuUt
9V94om/cu6aPEBui651JrPA7Qu5fTYAHwQ5fl7/ikbEywETCbqWrx7aLyKnqhSSI/u9MqaaI3DV0
90Ip6NHeTjPVLjzKY1wh8u31uN2WFfurfZL4LuPis60vWVMo2RAyba1GRpAOFGKgdMcjUTAS319j
LfKCUI07CC82ozxA8nL3Y5TA3MAWZGeu0vK3M+qZy8zPpi7qmcq+Q2aMbS0Wl/g7Om6/WxZpcbTg
yQEwSLomT8KzB1M8aSODCJqPVE8KnyIWD1ClK281EbDCHkOBu0hQ0kztvJZGx7rnObDv7JkJH5zC
QDiz/GDcPceqMJXxRHyU4BXEbBHYqs3Z64Fe1gnFVqd+y7lj7b0Cc9D+QKRDIX6zWCxxExPeCy39
MRBDuDjY35tQe99I4q8Na8tGtQmZoU9/3Dr2N8THNen/cOdi+RUn9hr4StTZ/2PIiMHOoejZ69CW
fsTK0/7An4LfDjIdfCfCFiW=