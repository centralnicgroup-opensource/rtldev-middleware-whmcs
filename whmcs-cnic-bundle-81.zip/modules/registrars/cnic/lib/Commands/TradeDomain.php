<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPox/J2Xcg4QHIRLClKMiG2CbfE99P8t/rlqhAsn1pTGKNIrPkdUrW6f8elm70P8H2T9YOckS
DwMKmteuatl2Kn2gI7Q3QvACPjoT66WdIOfuuRAUJio6VjVSo9du3BpPFPo7LcC3DwQdXvcWEnLD
6rsEWsR818rho1f5v59muVhPZAQA6hi+qscjiWCqFKBZ6TS9PQP1L5rg1GFYVQsgYavOrh86OtPq
QtVexhELMJvY9aqmHiHTmsnABih8j17CXp8scsBcoWUNtphwmGqGIJqNcpjiOqz/4RtnTKnCWJZB
iBJ7BFzU2328XVQjzmEhGpENEd0mIazz1k1usrQfgIUUWgMFXUYQCz39Z6svOB54DusBz6p29c3z
0aW+qp+Y4ZWoHpWbWhcpOV4CRAqRiyTOju9sNqMKMpcDhbL8p/O+zqqY0vFGkTmBtyCEMQYNqT+I
3UDzsudoc4hg4MyhQUCWcd46vjcSw630vLpVvDclAR60AFJChrm0eQ6pwhju8091RcYEtxurwmYm
kirFVYXSwRj8fjJEC/yx7+H2WAaCMtOC51ktqeyfd45oq3yZIzMv383j221xL02xHStE0ZLUyo1u
qMLsOiKpaigo9yW29QjzmOlAzQO9WnUehxfSTScb8IyKDip+Wsh/W2iJxx4ZDLDAx3La/4f7FuVp
icakFYDCq7H0rw+aFnEOwwDIrVFWrNvj8Az3IP3Cc9GDNyYojewFQ/i2mLOda3w4g3/TWuPagYYJ
UZHYfM9geL9iyNPb3MAbIUp3vW1BCBK4b0srNCXSmGHwVh9DhbSdGXSzk/jCvX4G+CTc6p0Mc0f9
s0UrKiLQhZrnqp8Y6WsojvFJCsPqHnMPgR0KM1BAQajuEwGiN0/eiFgMODZ+PBoiGU/c3dcimRfy
ik6+aExM2QRSA0PeAXXOiMh9i4YiWy5xx7n9kwAv56fssyGxTvOaBHZ36JMdfNqWys6EEJajFgwF
lycMcMFQAYp/s1ID+kj+0u+kDJA7svYENJTlpqLILqOuhF5l2qAu9k8exGIju1/bsgOJW/iPM6wN
96unJfKWhEQgybX4KnzlnzZhgjdfyEwNI3PpXsxC8tHssH66X2Z5i0Z2RsvCC/fID6bIlnFFgOm7
w0AlNxMEfYls7tp5X2jfnkYG5udYwkc0Hkpy+pYBhMJTlJHpZOR+DJY1Bztwn/HuIMF7BynCi0I2
XLbNSmzVbUBMhBofIcjuW3NIoxmEXbdjNn3Sa5/jbYM8536TG5yETsu4yN3c19jZcb946TojKWZ+
8mU0O1BiI1wJ9fc8fMW5XFkCVFzIQ7wdallG3U1P15SiKGA6QH+AtPjRKlBK89QLDwweb8flgimX
1zNOQ94XEtrT1MEdYPqGtsTmiBA7OONqy0Z2QIKJB+/TLcqQu8azqa6CRVRcc7W6kU/XCXFPS8gg
SRdT+OMRvDdJAJjLtMbDRP0HunM/YWbJVfcfhh1WLTGMiA1973/5+Xk0rGpoHh+ErAVwqecTPZ7W
a+Kxl+8rRNqgSfLVzZ/w581AMHnB3AbBaadoT8enmG4JUeu+TNmpnLMWHf1dIh7PLPbqZR+jkeaf
EAf+i5mn8AyBl5XVwdkMwoT1DCHIGs8bn5WtayXrpUfI8gxJAqPVRe/QCNp1oBU1fXGZQHDf4b6V
QwVoXCrL/oAMLIL+/zg/tak+opB98KEHlfKGQpxAuX9VVkIa2pNF6udC08Y4UiIR5TZj4dpXRGbD
IaqzPVt6PriB9SpQWL9AXAqRPGI3oouCcOf86UXSc9zpV0vscDqPNrJISaDLJqa2hZq9Eq8n8EA8
tT7WyUp/Jx8zOfOCTrN/GZtypEZKzFQDPv+vnF5te/inaWLKeslxuNQmdvnf1JFS+5nB7uAKWE+7
RS54Y815Q4N5dCq9T47BNGGp9Pmu6rzBFPpBGeV1f5mkxl9l9BTFbP1N2LavZxNjkd+O1cEXwB67
S46QPlupnqB0zrUXxFFi5qPkp16VxPmIkqouKwFwE3KB3YvXWnwNVWrXwGZgN9rBROUNGaVN/6TE
bbZXkviFEHb8NlShOOLcvXyRJgFqBVnaflZzM6avEUbWnMZ7gPvl7UCgsZkXD0Si5ELqqyJwO3/u
QqFrsdFPiEHnHYDiIbT+9ZGAzWe1ZtEcd8q3VZRsOSN2DwiMhKhT18Fz4/+8lSYuP67Kgk0w0dF9
vm8xOqdvrio23OwVIPNzlCeerQbcG3yF6rsq7SlY10==