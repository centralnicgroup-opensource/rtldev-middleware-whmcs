<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz045SY3wktlMhU0wsFgwQYzdc0SkaiYnQIuu1WLmWsgQotcSwK5b80RbD55+PZ0m25TtN+z
KVqua+iEIvXcW17X//8lee1b51x2jCSJy1HwfjxZGC+tI1RWR32jZQRMvGUQgrrEJRdKyYfTHxfM
D32V/kx2nYngskDX0lMqjs0k8iS3D3PUk4w0TWXejJjJCtof3A97AzCg+cY+PiaolxJf5zsZVFM5
YCkg9th8ITZfekkT0OCN6XmMz5RptjgCNv2o8ahMLKiSqv6iQhdJ6vILlU9j1+5QoCVH4/DlKPZM
RsWX2chpZzn2dskZNBs1GKdg/x2dtR4DVldBtsANrRLbdxeKCX7az/MAO42wtZqTC6/KVO6YV2tA
kUre92M77QL4fSPDGHChY7Otgg1MdqSWszFuKeqHDR2NSwgfTsuW9QFEEb6f0bBsFoQHmpuRyQa1
+Vqcfsg6XTutPIgIozyv771D9q75olf8htQZxwgyBmaEaMl631Ph0/rn6NO/tbgWgfRS5o60nG3T
1kcIXJOThREc5jke19cYWWFlbA2OfgiOmn8dNszTlR2/OUwnb1RpMIg+wR1oNi5mqGip9q1yaZxs
KrhuX3wIyu+RLWIRdFHHMZqLsaUZinsFYImg2LowoltKlQIKEtAQNw1knirIQUvB23GBrvsnMXes
8H84TH7L1UCokWmoS8qbI+/OzAaC2n0w5uHrjDF5xjmx4EFBFQkpMxNMpEsJmTtNFOi2tdWR9+Tj
iRO9NF5IzUE0qtCqnVZJCLNKCNT1XxB2yqUOsXoTOk7euR5wcyFFEtnPzI8KWQ09hMmWEQQpKWVK
YSwcUWoSk6DgdDLlbMjQS+/gjDU5RPAZN6JeOfX91att5pBFeeQALh9FDsRw3SLlEEdMaKUXLdCf
ANEUCsVrhQupzqmIo3TletV/OQKOuKgz53dmJpV9LGkS/AesedSZv/n7pQ+sS9thrCiAzaXB0yKZ
6TN8es1gxB0vS/W7IEZ0nda/oi21ToWh0B/Fakr3xy9TRr/iDE9kS0oeryO0rp5KccdPELrn3/DB
qzhl1oY5sZKafEi0vTHl255Y+P8QtkQ2wyMQe4omoFxZVmLz7QA+dVY/O8w/Ug8jpzt6tMs9Quwt
v1nTAzqYlNdDrbDp7w9pE3bz/6Aokp9iei4q93z2lFymTAip7k3zM+Jn/EqwdUZGRvrRi+AxCKj1
cQCuOS3m0bMbTRzNwR+MMbLix0Kz3DcwKFWvyGnhhWmSephrEinnV+zetql5AHuAps7d+acwnQtm
A8T8zV917zzyXwUJZ2e3OdBFY80s5bjKJXaKXqTX01owGsLA78tTIcm10EqzdG0WitRbg5wvJihQ
5rlMrreKcQ36lbrPnuM7XR6i4YVjAofBF+4Om7vvBaWW9OkJAVKS/azk72FQ7dyD7AqZ8bIbyn7o
BZTqg3jBdGbqgicDLmfMg9/A5spI2NYThRNlHWvbNICcwcPPTzTaYE1wxs6sU8I/A1Q+VOyJa8kt
53E2txGXelmZZEHCto8Ceq+8jw5dWkcox0DhBXgYgwgTf2CuKo8q1gsYnrJUidkd0rS5EHL012qh
ui7HVXjf7dPO8rCa3VMA1gDP6DwaYtBD+ki5P5b6I6WuiaY367u3QU/DdaXo9EVZ4FNalYCP38MS
X0rM5eGIeF3YIF1L/hVEJ9feytB6j6F5ZWR/u5WTes7V2EWVIAEsPcicrFUBxuEHzigy9U+F1B2S
2ic0a4vPI4JnxHnRnm93nAc3+tQGbj/se1RgNOo/Q9zJLCbCTohXBZb8hZQYSLXMvMbMyP9bxh0Q
yxvc6NKqQt9APO5n47xrK6s+SnjcJEP2sDY+rg/+NBL1LG+8WjDvHNZrigFbSF5cUEoK7VdkoOCY
oDJvIQIp+UGBSujv26oREq+pao8d3N6BhCDQ5VJPORd/pJhzt0IkpPnkgPcdybx3frBWf3uiKP+c
GB/PmDe/7tSJEq27dL+ln0X1SD8r1GAg2fClO71rDjJVuw34VAPA5U5esUyLw32LiV74pBalLv5g
5wEzSv0kYGG+En4TnUy9mVaDXipQc6OzPF4i7jt7Oc82fAkiH77LfwWShX7+ebn1UO39AsJ62gYg
4CrbvUZXaetRQXjwh11VKloUPoC+O2Q0p5Hfmfx/jtvH24rhsElj15pfb4EN88nnkUMrpZVRxxEU
1A5okkIMuVVB3OMvrVZsvrjdlrRJzk2qhz+zn8KPbnjo1mV31Qn9iogxKkFjt0==