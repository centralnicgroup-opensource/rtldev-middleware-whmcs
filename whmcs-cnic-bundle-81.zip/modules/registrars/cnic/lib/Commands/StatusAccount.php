<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm0WNGjA3QOi4v78A7bKlXWwqNDb9w+ynUHsqwCjzdtV5BeCCfIJq2MZXXJrEfgxeL0Qzs8Z
2csGNkEPnfxV9OW+RYhbhtPneLgB0dDitOT/b+bELFvR4hjS+xjrZpRyYEE29V5z3OPEt3VEhS6/
Qox9cr6P8SB8SPmjVbwNRJSKcYtp34E7WYguMg5jvZsegFaA04rwVKyE5ozRufes0Vab3D5BGY6j
4uhQtmO8gAdWKloIPhbY6RBLWiTouQfXveFp6VfYvie7bzyw+i4D44az5vixCMQtzH8uocYOdJXb
oq2io5O487E9tvRGAFgAw33f+r1aqFkdN/h/EFS+pIrO4TNLTolsY3IbbRIDkclOiQzDQ1+fdsT5
aYNgeKkpK3w3VACQVmqF4Tyt0/t4xwkG9rMZCULgGf/XKXwO5ntEywhadHdRRt42xiS0b7k/8GGH
6AVmf2LbRJZOiIU/TfME76eVRIMS0iU+jE8BGiXk7e4tx6SZaMrYQbxHVy8rmjGGsKT5omMgXXFY
Z9QaAHrpMmtjBGhyCFErx+fhHItLorShGb8MAQoIxoSLwEF7dJ6htZyspLyN740Vl3LkO5ijNeld
hy3o82MnsGEsgfcdlRwCumBvLHgtDoHaXj/0ZLUjuPDqlOVuPW9XhOQXUk9TdovTkmPSqy8cXpMO
pioVLFYjrDAQbYTrLZuFFfJtgnRx2QiHSf32/JiqBugJic3nOufz59TW6R6OE8cV2PThi4l/7Jg8
aDGhp7HF8UXNVJwESSct/fYMMGz9l4noszLmIxzMYfaAZSgkQ8AvYE8r38w7uhcsc8/sKY9Xhoro
wF/KQNjwG4F2d2HpxARJGKd3jN70jycuZ0xpJvssdNZUXAOvk6HDhedkLEX0Kc/66LApt6juTLIp
/siZEGLwqoATqk/cD4FekCX1V7Z2SSetAFRa+rlPj8tZXmAqN+SPdToWcbHT6OwU/N0Ek1YIvfkH
SCQOxXc7EmxPhyWh0HGvJXqxR5yYiwi/NEe+R6bMALn4DAfAbcb9y/r3zkgUgF5I/BR44xW4HnOr
nphEXeY/r7K6xHS20f6ya96FnIkMsx/u6E2xzqwXGDBHQPy6evd/HI+6eEcJG4LbSWINL+XYi9/e
SkLqDQkDjztCr/cEiGEqEA3BW/71AOZO07A+nb4cxuKeS6uX0bugBht5SWYj9/cfvrb4bQJYVoML
0OlKldA+UiffNIJ6YjBoQ6OiPMXfs3+i4EnVbXvr4wiFgJb0gk3thmphD1PYmYbwekcsyioBGXVE
3lZyjiz9tBgXcv/4Vvfg3vxbfVRo0yiqVTmTigO8lf1o8X55IY/1nnsLXwFCInmI57vMCmDMmcJ0
c2Y7qeSHXivQJcMIltIxt6fclH/tRII8/9oUP1OXLPjyj3qF2Ru8fchgkT6FkbKQv837xnWrYIQL
X9KlbuMRTOuhvCtJRoQ548LI/LzVLGa6oDk35sYekN+rMQGwatPxC2hA7w9GQmakIyiSPeNItiFM
L/LsybbYsDk3OplD993Bi5N6raL8HtA9nc8nGW2DALeuSWOTMSDpZVeBmwPZE8QP76MrrnZraqeo
iMMCmYAHmErHyjosX8Yhwcv0Jf+ivfdwIiKmCST/hRzSxcR348FWB+nCV6HcLvvf1BPrrvTo2ruq
rsPsheX0ivTAep1rB2XLaBDyr7VIg5HRZhmlKnJX/oqLNNDuLi3+4UZ6IzWjgfDpIgvA72Od