<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqJNG4DOEBbq9MRLO2Fu1t6fjRVomXjUiQguCRQ8Xo9xTaQXymxe1SEIA1GJIo99asZ/N7GS
pqmx1t6P2r9z9WAPG2BqshozKikqnzY/UtISdfMdZsfjI+/Joiamk0byDLEeMRbFRjgetdsoJIcj
HmmbpNcqBGFTAoDbv+vPBQPoiImCOT6I/NPXkATzjEZ8pRR5HMXT7OYkb6AnySfm5bxgqBYF97q8
w2evxs+8AXDkIRyXKjx3VgV4tqrzlw1jrJXP8ahMLKiSqv6iQhdJ6vILlL5eXFXfFvm5Cegy5vWc
oiOK/vg3susxEyLeO3Qd/t7Q1g62k+29EMFhowkVqE57BedU7ui46P2oe3XPW42X084AW1HgV64p
wDW02OPwhVnRLIXnkMDo96Eptizv3zOUYRVpGU34PZfcyLGF4W7hRSUKsYE8ibDGQ0qD9bDvtpc6
RDGd/nZYy5F8dx9ANzYRFNg/ksm/7bnqGUG4iGplJl24TbMm+9I1XgnI8TfcVtxG63gKgW01o99M
9WtY4VNiGndSRI7wm8Ej5bCB1YrM0DoMKT+q573Nf/69WkqbqOe49nPJLj+Iy//E/iEw+RBP2h9K
CT3Xf4hm+6uV5U2NdldGWHofgGUaw4E8ogc5rFiO5X7/KH2tnS2VXt7um1/pfOBFO/jrP0KtBE97
qXzdVO1xV46RZTUtB/hUhy6W1LmpnKJWo43Uh1nSHSX+J4K929oc1i4Yw6aLKvoFrOVh4PeVd48j
VKvhHCla38vN+MCWOmH9hEXamnMy+AahbgNYYwnNSI8aGTyDZ44+MigXAOt6hxLHGXdDm5TSsL5U
6W4smFU26rdohX5DXUJYrJHFuPaJ/eObSdoj5zZyWPyrZTqGQUnpa4uGsWustGsBVojTUqR0JffE
Rw9ccUa1fzKkx6iYAR42hPQhOAqwwb4WAH+NzmN5lkDvex+XKSHD/vLmURetS3tG/JZzwd2GN1cR
JW+BDX08dA5gT0hAnDNb1cWA0dTUbgPagjJTqTEf77qWgYkXMfky0YipzOPbnUswB1clGgCUm/Ph
XtAiGgTaCEKLFT2XpwXKprHbxYe0baRqV6JtYvea5zNfZN1tzZLqTP0RnzqKCiAIwQ3RtXuh+KI+
ZsPoKHww0q04CznA50Bqbi/GBaHD6+6nEDf5/vbktc1HRkDJdw4dOSzL6WH0cg7pI0jZlns8tr8j
hPOoSeFcpeG/rDuBjCWFW+SVpd+bklyRX2bOGvSlIgBHhi0NZdG29UtCjn7Y6ZqEk32KG+xGa8tJ
ORlrmFmjTswJGSXkuDE6w8STMXmm54798tX/K9MuVLwGH9egzZOJ52kRpdi2RViCXy2gdkk+AvIz
Ki2Iay9mm3PowCUE/ps5QcSCp1v1EyYupX3zlR8LcYVaBeC/GFbeY6eOc3tt1xS3dhln5eSe0XS/
/4wgYBLxkhu6Qqe5SCIOe5NQVwfxWEGzidHldpRRpybup+lbD7m7MaoVdP5biDfKx1DxIfKvY/Ah
ZltQ8DhqtQ2I8+JGb+zumkMvYlK2ePMI0wJyxKk0sKNRvdcNGS444rrgFmDbYK3GqVe5HILJztnl
XuxyElCwlIkquVfPehGXgJKnt+QJA0b3dCInsv0ZU2aCsh5gddS1OPUJeinzVr8qWUiMog/0bNsr
eRLfpq0Sa0y9Fl+P4Hu2wW4Hbrz09D3nJlB2YwscbmkcQCsd818UWG==