<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+k71lq5H/loq4kJtXaXC6cZqU+19jplA/jffQ51Yey2pZkWDawwh4cu9p93LQ3xnR96pKqm
4M95ojTsgFndPtsncHfP6B2lk+AI65dBB6qP+7Xvq2518ayV0zpsAG5hMb7ydgDMyNYCDOHo/ZHA
4tJI3gtkmUZ0YwPCvwbtG2l7fWzIm02xJKghtTCVpk6YMCgsKSzqhTkklasN95vACqLFG5Sqb4oi
lXWWZIcf8P7//C1rQoNjJh3giG8676Y+YvRWBKCYIjPLInpJaQngkTCRb9MzYMaLMbRtbTnZUtPB
cFPo1oN/rla6aW+x0Z0HfVOrNa9+wnTZDJw0Vw0G9ot6ZEz8NlUc3jiM9jfCNZ5oN2yhocfttaIX
I9DFZxxdqQMEPIr1gxNGMa3YE+8F/W0uk+rNukJJ7cDQynteu5JfRe9agzpsioq0QeDX5BWn5z6o
Ohd+uDg7bvKY4tWfbfNJNNmp57GUgfWkR4jDl7Q55+r49jsiRHO6HFA0MA2G+aphSyyQiR8S6/8U
biems6SimgxBScwAc/WWNSDNKg88m7cB3qsR1enhag+MT6UeS1jOlnpdeX/lQ2wg/yI68AfmprrP
gUEs2W2VDpaIz/24wUVKNoYC5PTjI75lX+hYA+/oNAUES5zKvFZvPEy3/vYvuA692RTZ1hIGT2j+
hng/YVSi1MMHpOncDIBc8trTfZf6jXGZD+IB4AVdPA+NRhArBhnpUwnyf5g+52ovSP3ESjoGLX/t
81r7GdBwRac0CVdVAS6B8P3HTYYveF/2TMCY8Tdqp5ZtaHXCO6hIDDGNtdSbrrOMniln6TxdnDKA
tAI9blbdTcCvVUto3Xwgs5P3Pjkx1qKjz/QvgMB6kv5anjCpsqPEhtK0TBKgYtWe7QN2jDVlZLxe
5qN3vo+brMysCNG2ZpjIiy9E+fOuZ9uBtQ9///khCdQqKGsWfXalqhfyus3nPesPe6HwYSx4aUhO
9ySPNGr7USWTDB4qdYbUstTY1IVck2XB/PQK1rtr9/nfFL1WvNGOCFMJfqEPO7pCkXvNiPeSoTTa
kFQSiKmO/efmN6syubFC0Z4gI5DL9b8PJjgjfMCJyc/PUMMbhTW5eM+gCzcz/UYyCw+gkyCeCRrJ
tl6MX+qOIH9h8dGEbcUj/RNIQ6DypIgPJrpdYKM9IP9H6Cqcbfg4HyW45wXQAMwKaiMvk0cmsSvG
bCXXM4ehQSvaBv6XDC6z4jQiRUMtEUqLv2lpuKZ9oU4EiCKoZRcxG2+D7S4Fh9NsJlf08tj7rB79
1oN+Kwb6NANvH24Fsp9Ge5it0K+m6a2Mm44z8Nwb9VDwiv61lHq7MECJWgmXXLaKcz7JbMaN3mwS
y6OBoQgSoBwEHgMPh0WGzl+b+//iEAYnsguk6a+tleYlFLJaM+GKgOhc6nzSz3Cv/BvoMXMsdrr9
nP3G4YtdEI15CS42Lm2pHw8JVQThMHWVks+gpPlivKk9Lg8hAT3iZg4WresR6l+0Gwcd7u3M790o
JzrcrG+Tl264M6GYbaN/53UCk9YkTHnf+wnwtxR+ms075zPHjEi+GvqiZAq+yT5RdFTbPnF84Vwl
FiCsoqP50bgQ8QwDr4TM9NN45bJNepw74TfP+mAQaD5dhedRiO8SgaxM7z/0uiaJWRecrTYC1yrm
lEk/XkFsVSNHAubAidQxTi5xuRwjxMuSJEn28/y9hM7vSl4J2zuxo6BCjO60+cKOpWJXifGQSTc2
6ZL4kv04pHoN7OxsjrweKVVAywqJ0v+5NlJ3Bb6JSlpzDNzo6nz8CxqElD34gzSlBCZVpCROjTdB
GwMbTvegPDqePrX89uF/Xn+7pFytKezM1xL3AT0hb1zzxeOUm7rO9LOxnN75ndBGcVVESVSTe29X
9okauN1oW38oop8brSooDz/Hc0HNzjZtoS7qE2nE+26Rj1W/0RDLZibA4KJb8Dv9nxnmSqUYjKgt
l43/jtlL1CMr7mvA4owcAWN9s+WMXyg4yPfKTmU59hWSngscEGD5wuX4H4YUUmIWREzpG9RLaxKZ
8GNGp1n3YZs3hv+ufz8eQiyLZkUcT3cFKu5wOKjF35rWO8C3IDsOVkOuQc1UUt1cy4yjc4UOPNcG
n9oUpv6Z+xPVp07s/H40PHY84rzYkfCfhf7Q/5sBaH1jA+tnlGaXYbX1G+8VyG5uOFVV91Kih9sj
UMDHMwXLZIuzKhKADCI9aWAZWi10XjJRKLXam5c/QdxdQe6tg1Gt3/ouI8gQXlXaEL1bxR2oIzZA
0ZVmlzGNKbRPyH923HPDHStHAyPJEdAFC3xnyEQQ2aTTSYcVTqOoDIadrbEwkgaxGDUIpoSV/opp
pVZOYN9X2+h+V63cFeSoU2nf+P3DLDUTC1PBdMMMh2lahx672K4XVBZTTUKVygZhnoyLATH4aC5d
VZ3qPSKjMbo78kNDqlJGU4DZy8tpXh+SRMef22hNXqVSQjt/QPnz5SqxD0rRXYNoDwokTZsJZbrS
QHuslmCkhWiYLw1nnp75y4sWrAjJ/ZYvWAODDlF2LEH9p7pTpdGjhcoA5UkejoQMEGKAWhiQp2u5
svlsIOn+VSl/CNVXsHQQz2+r7bSbzUtsK0KncU4O2deQhEyB3oRxbfi+retsEW3KDFBaHrRuR5tT
VciWFTUfrrvyvvRavgHioWWYSY+0d0V61Fz/C6XJVtPWYprm6fujv8o9ZwSIL1NgylnhHsE9MBIx
h9JVADHt9oC+uiqTpFERr4KurZbXtyeSMmDrws5rIALIkQMVlwJzASO1jAPbfkX9