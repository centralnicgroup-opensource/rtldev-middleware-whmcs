<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp2/6lCbB/ywn31pZz2Pwa953RVUI0oI3xkujO6Gqb/lov5ItmbL+JZcwn6d1xLCLBUvgJ+y
6aku3eboTaHHThFvC2N0n9V09dQcdcZvtV/fc7OSFfs+cRY0TDrO6BwUEYsIVzBgXlPVWjXpKQ5w
g2LfMIP+puCej22m2Wor/aF1e1r9vJEDi9QtnW/1QGJq/YD5x+vSLkQqERgcEZD8gP726w6v/kss
GtcB84va5rBWL6mxSDQPiQQLzoOEFTEmndm4OkRA1vVVElh13H19FHURE+fg6ftYEM2rDoIH2yj0
eAXa/o5bL0IdfPDA0Ptl6eEWCfOVySyb6aa5y8+fZRENdolHc7hhgjlejyevbfcY7uXvWD563n7s
Obj0c5Nlg9jkp0+V6pM0xqqS1DS4mwIB+VbEaetYGS+XEsXragyrgkn9vWYBZ5ElyETlQRvPCHJ1
cR35tvn+hqYipMykhVcgnC2RAkenQqYmUzqQaNCJudNfJh5NrLnqXlUPKCVUvCav7YH7Lt6j+Gh6
NXiGFqmeu7qEviOgNVdR5A+OK5cfe/6uoEQbnJwVKqluzZYVaIFW2lY5NGmiYZX1r6bj2oGsR5UF
8t/axWuJlYovMkqoHduv025MbfSngPEeO/p4Ub2Ijqx/HtNdETIChackN5zsMc98Ahie4Ig3k8Z5
+5h0hes1FVWRrzbCrDOa3/ooplvvTZYc3+Ht8tAV6qCsVh+vOHdzwnXaBOul+ZzWDT74QHv07jDt
peS+JnzD04EALYA2P8j+44HAaHwSytqdKP0bqffk3YSIdukEIJUEn6ytHfEJ7yaIxLfXuNDD9cBb
yfEoJtXiIhbtSIcRi+XfZ36+g0Ed0agI6SAgbWDZbUO3YtvDdQ9qox0tupE1BMjW7qsEPWOFEyLI
vMobt26IaKIQE2Hv7XuLuiDPwvSWWTiMfm4P0SttBSpfqaGKn15dadsMaonyymFMmWwD6dKGQ6ci
wApfAn2jp+SkeJOeeIALNqm/ycikYxLkHx/s1JwbrH+L3xV5n/rwFPixXr10cwJgY7MKQw+o3iVj
yJKekxnnVCZLEBAIWiR1Z44f+iAqvguwiDJr2WG6ExB6CAoOmRvuZdOsJHDqTcDVI3/MxRtovlBZ
sm5VnsnCnsseyqisrqy6b1vekhjDjgn+JESj3s3DGMGd5J6u/lsMXszY1j8KVGus4hurZluJ3EsA
uEeOpDdsbX9uM0MudZYWXTaK0Wfzp59FJIHqJixGusx/6OFfwsj4+qJodB5m8hJMnIbxfQVjELic
ZEjIlSYii4dkegcNMhJHztXnFUh8IgUdXR8cqnnTyr5aJkKwdZ4QW3fLJismLxvQnuKsLBVxPXVR
zzvBBKusa2/qNHISQt0RblAIonl/DoXusKaYSVNJ/tqrarA5RgVgdpe9P2hjgSvHpi5eqCzfFlGD
p9iQlYwLPvNy72T2BP+h/bQ8PY8paJgL+k/UbgVYtjQkiHVxDwNY+Y2dXTpo4lS4/qQS81Q8Oo0p
5O3tD9vfS7ZJQCqCrelm9itGPCa25fi9KlNrvgh5580OVmwXiVyFo9BuJOGu4RCuOWA+gUMBAlRq
9LsCN6jkqBFJhqIUp6VGzx9+MI4pOXO5YmUaWIQgnuZaSa8TJEmvMwRBt4p0PTUl5hpty+ro6+Dg
KkrHLH45MZIjTS837lHNb8FW5teQqEuWMk5p5pV/7bKKacXMH2t4h+p4j0Z3P3AQi0JSpQXQeajD
dTLUCkWh+BUFWCyK8iv7NoOWXR/GmrCzFRlVCIYNDPZpe0pViEoqx7UXDP6XTeUpSWSLSkpGtTJv
TYokQDnPExvE+31TIvAtRa9tGksc9/dOzTcGGksGsN/AQFNAJw3iRtxLeEUeET5IReOVrAZ5vgAJ
bNSsrB4oy8Rm0qXp9Di7Kec3GhsfgVlEXtY9Qccu5XHzUoNzwpAn6Dj/6Jt9LcVyrQNPRMsfZH6o
aQnjFNtRU+X3cY5XpyGD/gkbvs6R3WsPt/aH5BwbWwsVSdCV29+LGIkbA8GAK0UvdAFaEBEkOFzM
7Rn/AAL34pO6DQXTFJwpsAosTVH7OyVOvicmZX0vQfV5z9TX79grEvMYAnWKO5qeIfNyR9IxR5yn
6iuwFRCTh4HrMJcMelDfIfI3t9pOGBvNKrH4uJU2xisCRryawCP6fIng1mB4QpadTSoQUqWJyH7P
khF3JJ31jbMVB2PUaF6QXQJK0u7yh+SAbsZR07nVuu/HwVMJEwxniOZGsvwDJLrK7g7sqgyTHIuV
oLbO2C/Pi2n3bzoRXcytUEtoEhA5BuwDslifwnu8Hpgn4oaLeswdNZBixxkOwZs106BGpZtcsmFe
qlzcZlqxKqLIlaO83v3+z18gxyZBOH1J2Jvp/yNaqztIWemSytYdD3JH61QNKJUbjK+JMidCnQRy
lvOJ2zFUVe/guejvNCxlEtB4oIx4TR79kfzbwn9EWG1xockbQi38i2DKpXlrNRlom7ZpHwOVmmfh
722JvxabD74uDRt3wPKxzXS+mhTFZPb2EDTWEA+qnYzUsg5ZmwkLylxWIpLCig0CL/iAncXukH+4
LJz54HpwfP/oBlhw5N/dyQYCxCtbcJ3PG3Q8iGUEAxVRcM18KBNnRzZ17/Bx+oMfEcC0tzL57opg
GEWFSA4PjFux+CcVO+WKCZZ7Y1j+qVXsKZOFCfTqkmSPaG2SevSFa12qZQWRvypsynXHloGZRL0a
M3B8+Pep5BKcqGG6SpiZjdsFOykcrS0hswqIlHIkqmjj+3qMf8QhCLK=