<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwlX1O6SOVwsMIoGeh1Pq9z+QC90u9kb3Tb6fGss3QZS6zEuMb7xlsCgA57+YSHSD9TA3ou4
uwVTXfOBAf/gWeaCoYlXKDvaf7G27X2fGaQmwqL+/Gw8VRTx9HI7noX6iCmmRPBFdaMQLm1O0gUH
sywY8BIcmPlwWU6tS0XFo2pWTb+fxKjqvO33m08xfCZuR2J/i4192sP13ydJDilzRaW/jOORIJ0Q
Yb3aZzdBMdYBpIe4m/lh+1S/KGgVhrze8DE+x5WYIjPLInpJaQngkTCRb9Mz6MgD6oEpEYd+B6GH
k2RXw2Jix3PZL8LN8x7y3u9omCHt99IwdsFEIThkTXdFu8DtPM9rPwrpqB6I3m4Sdyrz8ifPYTqp
r/VzarGPt8is7W9mCLIM2bi9jYCWXhhMoQCzxu6pjy7OGugdXQ2n9z4XK/Gl0oy5E1OqGw6B7qyE
R4c9IKcG+TwtGtmo6XvyYOSqyQ+KmRicBIq/HSVHxWFujNiJwN0rNhpWXu5smY16UQli/9Dm+Zhu
klhMPVoEMcnFVmUkkLI+4cgCGaJ7A0nKXyXYsB0WnVcIqn0WiRYzgbN1Yh8A6wTylPoVUtb899s8
0ULjRiSFMdnPsQUosKE4WmaIAbMiCIOadWOFlm61mM2F/DKO9V+PQstPBTdkuCqLPCevRPMSyjfF
zU+WWEZggkuB86Szol916flbYVoL9FMZ/jO+EGsA0oR1VQO9WJJTv0uTjVP1Cb/v/NGxTxK9HU8G
K990M+KGagfYmilRXYXf8mZZGh6NIY6EUQFlIwRPDBDF6Z7HeIzyzEMPzZ+Qhhtz+KuoCALwmYuE
MMEvhPamZ1VOLp4TTBUWXotv40ltINFvusaAvBsPPx8wVw1JNr17Sapdg+7GsjcuvJOOmDiep9O8
g/lGJGHxKRKucW+5MWYjb/vg324mTgKgbqM2oSKn+b9vOwyWkehrsYMeBpYr1yd0CzwN4e3e51NL
I07cCSvqKvG4/vqkqThBWUIMUzKTQ4OTpUakN4HNnzDYH+mlXT6jUDubWIdraVUBtFdDU1X8O6Yu
3EqAUXEaiaPk4vUUpMrdGyU8m3Biejt8P89aQGq9wNNyU8eiT+moboO1tsmnBC0IRzdO3mSnE+ME
SIZg7GNU7YlZgA11zcDcodFq/A5FQwvBwHGk85SGpJFTmCuEW6J6Mtpf0HwsnSsAASFZyVfcIvmO
ZiXiZBg5zdCL2hofLx8qDKyC0Frqp9f7F/9kT6x/5cjWOxit7xj5p/YuZ28G0DOCNhyALB1aZN0f
933VISXEMYt778Eyi3idr+9tPfpLfnXcSVXf0gosuh2ixRI6H0kowAC+oKmgB9kBLsJ0jfgtmXTJ
ZW2q5MMQJXPeiwHTr0MlJ+8gBs5VH6YQV/AcHp81CngavzCYejKOaMYiWYn8kRfsJrQCMcL9IixY
hyxYLpP5jxRIvs3kJkUBwhQZ4RB32iNgnQrl1+3j0UfQpzvaUHLe7m5RkNTu9WVPiZ/vf9YT01rd
4wtfC3ALA+3N3Fq/QEIaoo03FO1uHVvdwviTz1QBRY0HIdlTDCNCj+L5d5xOC8lqOKoGFjZGlgzQ
AHkj3HrNJyMiTeGurvCItGsY4sQrVdW+8KrdkC5XB+h4CElYJh2uqzqxeGwWVzZqC2kHKQW8O5aI
1CRmiHV8XsR5gTO0NMi8+rz2p2yh9vJuOiwyKsgXwN5qosPyZqMl6YlMOLjko6evs4KIdlY6QPP2
CC6awZ2pqZT97X7CALheW5lU726YLFXl70fqfBS2qjnNeGxDTTSvlHXkFL0BzoZKsyXFarma/rxi
Co4ZFkEkmfqE2fFBTQ/zWtAOsHjkwMmV4kFnDusK8deTBeXNdBuSJdkt0/+ZvGv8F+Bu7x0E3KCN
cV1QQMp/umKAo9V2J1wW24iOmcUB0D0LD5pcLBYrHZ+nFzB1uw0E9wB1ZjADxTRVDSqrP2DtCaDW
0+4fTQYmLT8qIiHdaxygx5C7WZQajnUuFZPpppbL6QRuHJIJ6yHlb29vaW1OHw4x/fAswQA+fNhy
lGOwu9ncYZw0TuuOfVp8arHTyDAa16Hsq1RQ5OBBZgr25IC+9VpjZbqdwUTsqLBGrA/oKitckYdS
edpec2ifjps1vg7JCm/6cyo8czrogM/7DSluK+RaWlWM4xW0h5XtSeJQQbmdTnjNKhho5kRq1Anj
gfEDrVU+19DfaOXz4hXw5LkaJ40XpeObEaWoStxqC1hE9P80DnQQBbV/okBo3tVpaHKBy5gbBVzo
6QJmLGUWb3DAhHSo4Ov3dHKednm6jK9pcmqDbERyvxcxDktmNEW/Ph1Elsc/m5rzprKgfkyJNsnj
YAzZibfSt6R/2IRi1+mAhXdSdK7/zkQ6G1NHaSGszQg5IUuLog0upgoKUU0hWcxr4bzVuL9RXDqV
bxHJuRBj5LaWED97AJOhOOKN4lE9/FeZHCrL3HujutX6NGqjWD6k5QaYAEVAQDBwIzFD0HuiTkTS
dcGNYp881fbrn5v47Xij4i3Ye64EHbBJZUUQQyN3T51LTSvI9ehU/gEykMb7/Gjo+22NezOY6lt0
0OS3OTPL4jUDHauBzg2dpI5mjjh6CqDIB1rE5rSkYr2sGYBkRFYVfB31FMBlqCOSsPU71Iv5d6z7
U1DKejc2eL+5CaDq42z2jwwuYUQdwLaXw38DuBPvRkDxA9JTGkI9dVSfdF3ftA/u4da56FUUHwLB
FPlMaK00XsKYS/kJk1mQJ1WNHoYRKftD9YD1k/HOXJjg/b4ET2gL3OpYs1Sl+Tb4QjF/FyX931qF
N8uIqIXpdsLvgblcRSspcIYPdejxaN24emKrIECE4duRsUfuw2xP/MA1/ojURIBxd/V9i8w6DwGD
l/UsJk4=