<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyEY4OnQ8+gZ8s+4hvtVQLjfduIxMyzAZ+LVc5suPmkTUKpQDHimAVtRxqiPPQxlorc/wFuc
pTW+wak7mtZU5Xh+r3KcKq6eNxHv931530Ux691ytsiGk7Fv62WeYKUmcc/v/YKb64D3MXv4BxVQ
MSXLVHOAxh011Pw5M1jWikVKOmww54BL8PgwTzvnf1eCziEfbGm3e8x12O/+pjGo967O8bS+B7g0
yzAcQLNjkD52kMtP/P+Vfvn7tXWuuBm1pvQzN6BcoWUNtphwmGqGIJqNcpiIP/oupCDAKJjDMSBh
05q8SvMmy+4kl0X3tmsWC9onqqc1aPv3dlgYGXX74ynGB0CiS9Sb6PqCWj/mrn/PMWCcuZOl9rTi
qIvyzWum0l9SygzV1oQOLATZn8+DevgNTda+74hlnAtIhI1c04mP4M/5n9cceN2Mz8Ata6bOpUYG
0etZiDi4lfe26Gyl4IulUZlTOSN4TbG6bUoxf6ASPmQu6GbRCYWrEvFlC4o+d4+J2ZNsN6PM52U8
oVchJeGoSii2yyG4hocY6P88cHg6WS3GwinGoGb5sbSvw+d1mScIoExPlgKGOG1zL1yWFoRODACS
kfktiLkza3rU73vjXvNbK/iH04tdiEdx8icINukvmQU6o+XUXdn1biA3kJN9zYoVGigP0/AT5zO7
hdHYTtMw7L91GEBi/LgwODg2zNJN/FfLeHdygRDCYrN5gdyZproVDjyeJ7UyGqRzmzu9QSov98Vg
DkAliTKPLCZAcLuPILgHf/7FPVIduW2ZIe6PK34j7tISOPmktBQVMMZFQ/6MuRlJLYN91R236sKv
WUqIEJ1rZuojjpV/VIV22cAhBO4876ZOXNT45BEYoyCp3YA2TjcreSPqbtjK3grEAfPBxssSEhLl
MBGZfkUVCpgGOD1t1RWchp9zbz3QXGd8qtOePhlACGsetFKZXU9Wkcu73iJ7vaROFL44C3uOD0Pz
f+rV8iiQwb/i8GWLGbYV6WKJZOG3V6oLUkgnr/QnWrKEib2JaOTGFHC6JdcAuNGWnryA22OtpzEO
i/6+wUJROGFteVDzmwzgrGQE41SpTNFVkY6XgqexWn3u2Ljl+V/4mVB/rpcWOU2haadalK6tQiDa
C7zE3RM389XVUTQ7cWh6gUJGu6FzltP+H/1/Yfq0IOhARQtj0tqKmhrkARZpU/PR8KaFdE6fwIWM
YN1bcDaGN8AGKBzV5q+WPAvh2guUcOHjaLtvw1/cVEY2kig1asoOaOlHV02z70HG3aasXuVikoC6
rIPx5sqoFuxE1QrXl71UIfHkOnTOQh8hsgnatwxYsRjKIstOfpt7wwXza8Ok0dOJHYldC9KY6+hn
L6KmxZRN/TqtcVa3TD8c9/0GB9dGuqlb4IuwoV5xpS6Ac7n0XfLN5fzfhs2gTv6lbG9cv/63VDad
Q9Byl3QNOrEynCXePIm16WzunCxbeKerDvaLz4zBD0+E9Id1+fa7bAdByFkcQwRKDcvYOqwhDEGJ
S1Rh3X03KCk6wgGx/UZaGQ7dSA0YHZwHu5o5aK4lifE4vk8DGljmHqU3HKaWKEKgmKIJfxhej0XA
lIsL7EcuIUo2G93/fF57P/X/grBBZq0dALkFuPuusSmW+spEtSEOg/odXGSgkoKbLgG1Fh1rEbls
PhTW9Z9fVY44JuSUwy/yg0fFOqzPeOTWsJWQ0/8vh9ea5/8a5NZ5VlURPgAIP+NhtTbDDs7x+FLc
/GH4yXRxTbvbxKbGg54UnvdrmlKLe7FRTrvEFzv6OyNBPk0F2Vzrj9y1qP+x2fDCCDiHyNSowFmT
edYoFJZamB86shF5HkP4b79PGUluzvVHR/iQ9xm01lw8EfO6dSEGo9zFn0sVvBKxFlLwpcgmsJdz
/6r4dfBww2c5g1ZAWilT1HT9n63j/skq1Ux5RQYjhpU+7/MpMLbhyZO2Kl+Amfl7KK3IY3xpzmnV
m5Y5zwvhoJ3+VV1RGxHJdn9wJA9kzwSYzQJo/I8LrJel6nsTUQnUgBidbOojhDUXD9SNNWYklL8W
6moYTLB/UG3vSNyDDk05NJShKsnvXDMKsMHIWm5CMxYmy1it8IlNyIvy4L4gURZoVYb2Ma8+UdPV
bJ5TFRR9K7jgesSHOVfayUqXRn1MxN6KfeB/nyt+EUCoIbnq19X+NgLSyzgBjFcMfuyv3/SZhkwS
vw799P0TvIdfmG49mtI46vh6CTzctj2SEHq9B7zq+eGkOfLdt2sqKm0Vrjh4fkWhXE15Oeq/9VgD
ahk1RT2sqiVBUhyBQSPqVcPcRFKHvsaKTyGMlgRPWc4qCPaqqx2jrDT2W2IMWJ1SW82kUXEc17NM
KdqsiwRa0pINJN4bUaQ2qVlL6+BD5/xfKYkxfia7uXY9DPg3w4ywjbqo0MDqpVLHhxuT7qT6NJxR
GX3wnXosDWzkkytsesKAiD3mAeHNfRgkAi/KQrKiNNRbA7A2uaLpEmJGXBlTDYv9yrjHdE5oFz9a
a1IeGBF0UIxw5hMLRbFnrgeEanQ52H73LJaR58DKN9yYXFNIZi4knfNh23HyLp1m6MI0EAf8wboS
zQGrn0ShLLcB4n/tf7O3fqWbbIGR87RVorbSd2C6py2Eee8f6P6M0v0cdoVSHPL/+g98f5HUcmDY
2Q/SwTg6Zj3Bi8BgAZdgfe59Bt1h3GTyTTN8UzT8ZgpvKzJfPvfm3hF7Ap2hdMrSM+2g5BRxOU/F
m+6Q6D/s2tgQiF+N9rD1TAbI9ZsnUYNNOtmdCzYJ7apjM4MIoez/jau6eZkyEHgCNQYq+8Lc4rKx
Oa6gq8HaA0Leur+2IpcjyfRKmMWlWtLt77GumII3pbDYhR17OUPupu8QXc5vkSjxzyfq1ofXHj9Y
mGKxZ/CM8yG4W933HOnX+NQOged9bg4=