<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo2PUGA/Pq8sHYhi8Ju9MNBgTydfj2BLkAQuvmkH0kpdCXwRVqvd+P1ELry/IXmhTVM+ULfk
pNEkCoFP5hoC10lx5ez0WmwmXOzZXt6PJWkVsoarkoRQgCoUkOFTQkJ4AKJ/Z9VMgQLH99g5j4c+
K9Oz2SdeacMUI3GSP5jdVKx5LB767nFRwdpA/XGYBbjtn7fz+AkVVGGYDuKTsKXhJOTnp3bFvA1G
6O++Yb6jl1th30PQ9G6dghTX+OWwomqt1idD8ahMLKiSqv6iQhdJ6vILlUTZt/MJKOrcY4pzN9WM
Y6Wd/+76fnwWGCJA8bnBMSQ+Go9P7F5JRdFFeijd1DF2phxQz7nfCUjn2P/vEviVb+WVQJdN26s/
ygI86b43rztmRxyF9WEZNu7HRyJGKzuE2cWAgLJnWKavtZ1msETPNyuU5gDXJRAY9czqlDtXoxVq
lUczxaRApTmWPV8w6OAs4J8VmH2f4AlXPTY4XVn3rTIPyxfNz5uEmwW+2MEpLJll94pkSfXOyS9q
/9Bb2w09VrsY9jKwPUTUuQQGd2IL549N19s33FuZXaHhJzSE+8YcuUD7kh7cUvLM3c745qdDIap4
QN5i1wxWGp/aca9UKgQjZuZBiXiO0lnzLwSlA8wIt0Zyzw5/KtDLlGDKLGqT5C5WnOxj9NMAI2Qr
zUneH4qTuRsZPzlW56tfRXIdy8pir6nBN6FhQ5KPomBUpXsmYFgK4uj2g0f7KgOWQGkOm275QSYw
dWFlyBfZeCbyC/m+Fas1WaGqKTfiEldqmlyIMiFjtyXgHkeagLSTJi6hCEFx+TTVoS7K7+LR+7bL
1O/6/mc0MbM629kvoN/xShtsjkcH+8RmK07uqgIyeHhXT7vtXII4XA1qv4R0LTauXzH9PldUplG2
S+uzteV296Fx/yPXwL06/v5xZvJud8Qk1cT+aPu0OI/DdIyCVK+HZOHJ9sVP0JPmgsE7ZEq/NjDa
Y1Oz0drFH/+iauh4ii4FbenLCSSohrXFYWIc+4Hksg3ba9xxKUD81SmdsPzTPwmeqbBWvq4hj//D
+pa3xiF+PazFtsoMo69zxxACun+xpKz3bVfoWz2lZ+hVlVogFoToKDMbXsCWMy9OHWr3qH1Nq5I2
FxJ7aoD/ECRbmEmtGOh//0bp95CBj8xeiTBbInxb1Mj0QMu/tdMyYGfDdGNAzq9Lv5QLj9BOp15T
W0ooX6pVbnB+HIdasXBc0v54GD0RW66LvJzjXzN6R1tfQv/vMU6KBSRNVnpWfQUZgGbx6KwYoYB6
qMP+oT12tVJmqH/qX/JVkuzKeTeBdlUxvPjm4bYujTXRuvua/npYbH5OLqndSsvbdtcI8rjOcnHf
uQcF3gq6F+cXc8F3OlpIe59Mk7l/ibCKrgDlQVauLvHDhy4IcHRRYC5np8tQ6ve5/WVDHUdTgwM+
uzMPct5f0sqHaEtM1HByV37at7Pg36HTUS2H811m6Mnvv0bZJzjZ+oY/fZlk+vVS7djTa5zTIKqC
vxYWkvP3hipDYlu3DC1KVMNwARzCd9FsfXmP0QFSfE5tSkZVdNkL5c7DLiIMP8Pc2DbPxX+itY35
r0edlTG0wR5jLzRvBR4sjRKvz0dRNAQsetUNVfjE1WTlfSNVqdG9h1Iwx+ALyxhwptEL750gXl/t
BWFnMM/zD0p/hmK3jCVBpZj/3eBnNwwvSi96wPQxjd+008PBIFNjDB0nRpdxsLeQNLNCmjKCZcFN
pI76N1Yn+MpFSLZJlOodt6U7sscVv/Ute8vReukOFioc5GxnjOiu6oGQ6HDBtBBO9fSQfHoHgeDZ
arMa4wX+erwg9lgPoWGaLjQkKzqEM8syIoz2SdPtdyu869izxcBkTOy6oHRJWqotHBpb0LWhXbve
zu5NmY2746R+0hk/VNc+pp2AFSMxMRYUbQtDVbTi7+3OBCg8tnGl6NToh9eImWX/4lhXvONZBgVM
B4BNW1jTs3bvU490LOxQkVyUo90LvZUSppU4yHQxLpP3FkHgCgCmH2zsRyip8iCKfHB1tRqJJWg+
haOYlhGltkzVpny3rkhCc5bAKYMdUyaNs9TqXbfYbeuNuvx2NmF+Os4Rinfl4FtExbeFzUko2waa
FitHSDgfcl1oKpU0GG70Fs4Yt2mcN3cxe7Pxc23J5quS9OlzUnEEJP/GWi+nHX9IH4j2qBQQXpNr
FccyM7NS5LXyTDiB5IGRzyitmrOzb9bsKJSsXOTaaY8JHj1LxrYjLPtELwDXEAMV3gC4fHH+3Hjn
/0rA60zCJcsLDd8Ztii5v15xzkgv//CEUIZlgSxYez8RMRO5nCZfioMEPnUqiyYJ9tOKtop+Dy0H
+FSeSk9vBfTG0EUCxSXu2sfc5phsp9G/Xf2Ij/iXnba=