<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPveBtIp0wYK3dRX83uXv6lIZVY9YZ7luZ/zJHIGzU9nA3ZwwFgzpEfU4A1pnjyJJKN6v8TX+
5Irjhmqe47QB3m3I9vBILmyU5FO3NX8E/33Y/Yl86K4+OCNoJMymyHLgy8xC+u71XQl8+uTJ5cAw
P1Pq5BVsKvDuLs0D+Fjjk/4a2Ef3iY8YPmyGoAhOxG06hy8Pyxp/UGJA7e4zLv7aO+WibxpiGMl0
1MVdaLd2b8hVWHjktrm85JLgs2V8+JPE1EuQl6BcoWUNtphwmGqGIJqNcpi9Oqfehk+JZLCaOURB
q17dQdIYC0L/Q7gHluhUvpFFZbXsWL5F67/ExDkzsqwmfex7ateOw6b39pELHiBp4ted9AhdWTWR
kRrtj6eYofhdp295Krp4xgUrftDOT4sYEvaDqloz3824iL1xqnHVcyFW/LcLGHV/EreJw8buAVmE
oqJpIC8Si8hmS0fglvtN2OoSHKfba1Xm88vwaSlWok3I5tn4+MAdPK8p+M7mrL0LokNy695WkLJy
a05dNi6t2eNk04r1OnBiw5y6ssaWpqOfHAsrkft2coFURw8QIH3MAmUH5AI+NWg4vA/Xw2/lj4a9
B+9J1ZAVwrxtsRy9Io12LX6syCJki5DCD2eV+COFGOL6bonsaYDW80Pp/zB0sasws77hVwXdfsHB
eDdGbrqldne8lpahS9KPEo6Vd8UetdP0+SHCMrpwo+24PERzmWSHkhnpCFgfhsRFneimzXWjoT11
KhB8Ki9dxyEYYW1uyooUeTVtE4yEEiIX8z+8QMbj85a/x/uaOGgTzrCUK1WBKyng8Dx6PeVcGMIV
qEl8leXvqusFA821MHt3Rg5pIhWbcPlyTea9IfN5yWQUxyrRnjH+E5WFS4q0GPSTBftt4Xh0Io5q
gNTDTKvn5eECkZFPYt0wvtAOac7AHoPM9g84LpJglKFA96c0kACdfFxE13EquP+Kn03/qPGfbRhb
iWfUSYZ2Aruzj89/dXqYlYDKWaiVcwByMUXvaFxOa5rI6cBnRd2K7ps1hPNPS9jeO9tgCDnzKq03
EMLNGGQDZzGjE/248e4g2LUdUXAK36wgAD4iJ4jRNcl8ghOvOQkpcPrXfk7V4l1lsdf06vFyKZTg
LE/4CFvuj59r0W7wjofpwUjgwC/flkEWXDwLe8EQxfdM85m6AljOX05OBKSIN2fCIztn2Am7oPsU
MhlrYoCLJdzIOXNQRVF82LGunlXx7Zb0Qh0BdxrGeMJVAttOMHk4T4EHk31ljptk14Vx/x6igHXv
ObCGW3egcECUfQTssL+Kd0lBCGVhOn5cCvF7Vk4nsnv9WJFGKREsQw1m1cWRJ54Cr0E8uADFQ6C0
vbJ56jc5WSntDzTLoJVv2JBkcK0GSmOCTPKfCOLBfQfjrmGZjGtDrMNsojPjNL+5uLcuqvKN/2tn
lB6SdTRDT5pW/GNwyoMCEIUjuWO5RLJVLX6D04QEEY7dxdT89KtFapwFjMO6xR2t7SbxA0CriXFV
+aiMcjW1QTCtHa2u1r+8a7INwstKbqlIpZ69S9QMmbBTAWagxpPJabfJsaTEEN/9fiM7ZjPMcxSb
zInvm0VRQLiUETg6sGvnLwDPTgbFhuS0HxNrrN1F41Co7KamMnf0gaAOLyDmL3wYn50nz69lgony
3nGBLGP2ZJe20lB6Ef4n6ueUt6aF7gqHK0eMK7HAAOmGdY+vOTKEUjaJdyD1GPsEnf2Lqe+680Rr
gw/4Fuc0Qo8YRB+KxeFYp8zacc99Huj8Anm/ZwppoEi4S9Q8j5oiKKFpDuAEIBQa0xmqGkj7glVR
ifHaM4an33B37ByJV9jDpZcNbCwYdiPGR5w1YGJZdCoXfwb4RYrh6D/SMATLCpfq7LPIz9kOmcy8
Zqcf0Dt86RJg35awdN06IUfIorXTmsH20Xx5aEktfLiGcQ8qCTCOZgZCEFlE/EzLmj1aYiqdqj0x
0/kXWk0+0lYB9s3go/dTMrMsSoswkuMjtIpyhWiEzuWpmKI6CIoEpJOnzsh8dxSzKm4iqsWA52T6
NGWTQNzfnhMWeVLvsPCq2lGuIgsAHKzn3MIfwVHTvZc85rqIev8Xuk2NlRHHA+fpOmhiZTPIdS0V
8jHhWDxRkzVlcYCv6bB1P0RqsdyaU2BP1P1CX4OKKsu6BjMVodTGQCeZmlZzu8wOE1/d570XjL0f
z4EZqkIaUtlpWu9PilcUNGh7RkGfe5/SxB+4khMVRG/8wZg7YBXZv8mDqhegQJG0nWcD9bb2sZee
C92jMusNIc1QEb7pa6zUHVPlMsG0nbjgJrMDtKOxKwa86oM8YfJMdmg+Zdg8yj5XB8QhItH4q0St
3ceQIEOKgcoU6dEzyFqk+YOFTm8IPAzafBa4kEDs3CZnaAcR5gTKgVLISX2LxF8wtDJFO12t4v/R
85Zekfu74Fe=