<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmFX6AGoJ+6BorEDX/7L39AveQYu3e+uoFD+606RlJdLPUl1JpYJC1f4B88YFaUe2sxokKPJ
UvDWEoLHudmoPBavK5bECZ35Rk8kufXUJkwJhL2aSiYPr6hvZ2ELwfKh1DjXWPMaMDncpMtew1vH
6fGV+PxbsHuTl/nkPwRCmfU6X+9BXVmYAozO9LBEz5wzwIcpbWpgIQQ5YJbalv4AP/GSaesEfbwY
51O3QUPqCFi0hCMYrRJHfghdI5Qt9f8S8/t5dcBcoWUNtphwmGqGIJqNcpk5QNHyC48mTkwO/E7B
C5qd5aKD7dyTIt7xNS/n9ATmh7f3TrTDqFHi3oO1I0FRFJHHDnIu9vYKsvCAb9iRdudXYNS4vz1A
jtCZDHnD+C1S6HRLYAYy3SAMfYcvXLUzEn0urDEd+sc2yRa+wkCbXcy4ul5H9HPnf/yUn1ukHRhA
R6AVNsaGcVQ16kD2qo8x36qu21qHj3Mj3hfiv5ADQyf02BUBYm1ubLSZqtM6VK83Nb53pIp6ES5k
uIXbfhNi7Hz9t0MOoASspXb6edcLUg+vZUoEOSTz64vc0iLPFURkxXELfEYhHtaf6DT3So4Zp8Nv
RwoWT2qddUMN8fBBYt/mMauK9/Cf0qg16sH8cun7jr4lXzDk/wAiix80EZT1QJyQHgXtqRopGqOM
OgIMYpXOeHkHyLhZNC8klAJ/kxbXlVVyQRu1DO1XEkhdWIwp4PupCcbCdeLreZ045sAA0POBXdPP
IcbOEAFc0xfYAkwKlXArSoQBqG5JpQ/3BANeAziAnYc0xGqJtWhVpD6nhI11pRrLKGu8EVh0rB41
iaLFZBE9mhEz1Lt+EMl1XCq+ruFzS1kUfVuGJeQ9bTBwugBfqmUxEpg/YI2LTznNMtXdJsyIPQfA
dIEB4OD2/hJbsGmh1Cntf4oTf6jxS90q/cGASgbHk0njcAU7doK+0YWuPaL+8h6zRCcynDlDjxmz
js4bVEYpTakhKRLxj994c278JwtHHAtpf9+w90KVrd0ohSMCIrJlYqK/exPHE1Vy5E97+yiOHqjX
uuzvMt1YOekrdmkJI/fGl3Rw6JRkKEUcPOCeFL1SU/ImmFfR/G8ddmMVBJiT4lpELApikjvAQZ5m
FhTbbdpteMPGEhsSHAkfqBumAILS/24KmtA6faPfzwozB5QUsx8JVI3EIW4seUDPzxI1XAoLUFSG
R32Igv+ZgNUXYxaz24nUyNWoyeT/dIqLIjZxSiNICbzRk9hbseMX82gZzNQt/fEtpHAURnBGSWwE
SjU5IXskOkd5fnxWGeGGyXZ3G0wjtFcLAdaDaulQW6crCEV4COnBCjCFLHNAKjHU5ftQlI774J+N
1B3WW2znprAL3nlf09hDVhkol1Yfoa1wvkQts4HI+uTRy12xE74CkeANQ469/8Jb6+poP9menuFZ
6xat4B6V2+CfJ2M8Jc64azCwwWomJdSJLteTRBq8dXJmigoV9dBUYJQMHwJHtJHKhzH4J9C2FjaG
IW1uWb094vSkZkyKeCS4qDlH+k/VphmrikoUWSp9Yd7TmYlL3v0L8r6+o/2aq2auvCbM8W4qrvAR
IqebOBd4L1PKw9VhgEKv+ivGLIQrRk10Wa3eZC3KQOWV0rJfaiL7pyrhBE3tMwfJZkE7v6WJRX7o
oHUdnUsP8wkLkFMa6uBMS94F9L4Nmd5HIyfs2tdz9v1MVeeWpGEUOkw1pmm5JBoMQbw9TwvPXMAF
00ux58DhFHkQSajQqlgeuE4JPYuhuNezEKqpGiY0FJSbXZPlrtuVpBdI7Uf0FbIhqvPxGmX/ncCa
a0zFuBPi0GUdKImg9G==