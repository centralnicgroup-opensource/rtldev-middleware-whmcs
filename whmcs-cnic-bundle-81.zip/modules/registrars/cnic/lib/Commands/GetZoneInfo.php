<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwboRgPyqbAAUS3xXIzcCBUAcUl4qj3W8ls3AbVLIVZbKXr3vfDKkye21+d5GSAE35sduv22
JOvyeRFYmWZluARhNxLm6PdKG7Vi02fZ8ATJiO2mnmsdyoyh+LqkSka2MJXbNubcw/+k91yRvjJB
PFdbQP4s3Q5apZytQiO7JfOoMl3M3NGz/l0xPizgg0udLzXfRKT+pN0zXyGVSOkJD6iBtC/cwfav
uVBbs1e2gdXaZV8XdAYzEVpi/udaejlUxXUbj29ArbLB7DEHh6gvqnkKbRsWS227+BOeipr6iCUO
XiV77v01DW3rwDcr3Yo16W04mhzJAe8IGnXNA+7fbdwFUFTdQTHTlSmN/ZJa5beP6n5a5zdlend5
DFhzogOF0BVMLRvVt/zQlSX764V/dgbUEZ3csLzTKRF5IhzBKAIX0HT90qs4buL1z8aEG76abn4F
l1hlaeH8yfEHOyBuM+Ns2ic7X3BZduO5o8D3CRxz1MDdC7gVb01Q4li9lRDYlnYXggB30ivVBxae
FhA1EnJ0e6NqJyUsZvmMU2amLair1TRr6s87QhKDAx3jshqrk/+XZErRRUyYuLisdzLzKtW1rkbo
aIYriKu+c3+u/yKLbl2TW0qc4qvNxcrwhM6KNNzajLSFV06CN8LZ/vwwDoDTkiV4sGRumvPCnbjK
ktrH5o/n2xRdWdRkK4ubC67/95BZrX0HNhbknK9pw1tjDY1AoDfrE8+X3cwhLeSMm1QqQkSNx6z5
KdK3wcle66WmqjeOBKcMogv5qT1FqgRcae/59dF7KpHDFPxW9N/+pY+nvVy49dPDMLqQfVE3bgWV
Pf97dFyCb/S6x7Vdk0Nni+2YWK4rqf3vNvr2M30mbimri9tN3aqsDC/XlVEVILPBfJ5L6pr0BtNB
Q/Q8hGV1q4kYViMUNG+Ac35+6VbF6uX9gj3d1V1QAQURfG9hDy6o+HzloQN1V59xaeKc7yQY8uBa
ZqnYk3alqmim87R/HVqayhnvnfhL6lktLm4ZhVCDHuCvfonbdUnCGWD96N2ovegcRkJwFv6dj2cS
RHK/Imv/NWj5bcIZGOCvrLu3bev0wSRJ2MpQHhQm7HPlUuJoN7FOvUNkvocXrPIHonOjdHmMsDAu
GAVm5gNQTj9+ikO/ojRJAyGbNrWwnUI/2bbatnE/dOPlSXr/rxgO8oTWbocJQ26aWz1OXK/XXy9B
ZZVclK+jZxwSsIX2vc77DcwQ1qseNBXWJKBleg69xvABXx2eh9MeL8U2M3rbtKR/rgMKkFaCt3iB
dcJciVSGlhWBB+r1owVa6Bgu1e+LL8Jhfav2FIGuALhaSD5VJEeh2q6XRRBvk2kcjJvkfQylH6Ty
AsY5R+QZUjjZnHMvioqmQtUKDQKWGqEwEX1FtfzLzvpBw/EWcmCEiFeA8Se/K/g4WOi95BVzxE32
KK3HawOJxUt2qx49v05LTFs5k8xmMRwODEeAIGdiWGFIkg6YM0HgVlLkP3qGdhQJOwcRK+QgC4UX
sT+PHuLRMdfSrArRkz0/s1W4up+PFSpmwo3xnTYSAG4hC5W5zqXUvIwLN4RBK3Xrzw6G/JTNg0nu
CqrdlY0MAt81R1J0YZdIyo1xoYXCW15Xm3aRLXU2HpAD3OORbHJcfuhZcPnj7q3lynU2CLx83izB
DAboRQ67T8cKOci5qjGbIF5WN+b47q1pfMsZRHKpgtYNJ9jsi4TMkGrqGi4JYFHBnj/QX5VUtTOz
D6ZZ7BwrRtA1/0t+SenViONwCH60+y7oqx/7HtbzmwSSPELXPGk4liHpXAdVkCazmg+ehBoBhp7K
gsmq69q=