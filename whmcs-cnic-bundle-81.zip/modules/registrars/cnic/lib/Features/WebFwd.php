<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrEPRyAYGbJskr3wuI1B7AYTKobCzW0uzUfo/18XDBe2i/WfLxfaUketipJ6Dck7v0Hl8YMs
Sxnb0IQrqBRzskYRxMJVWN+XvDdEaIvKQ0j9qks6MXCWN1G/KNmX+olP914PrF6Of9bj4+LjyqNp
qswNEtV+wEyHFJ81SLgefs8zdA8TFjChKCUoVfp6aKMw1kKKzbvT3Fg+8lnTNxDxz4sj9oC0ySvd
MaXbfJQN7Hpp2OL8R9zugJNZicobfbTQ3mjM2sBcoWUNtphwmGqGIJqNcplwPO60otRjlPjGonhB
8Ax8B//dsbH+5bNSqyXjmbfRj845g6tT95k/Kevwk2ICQZ7JmvAre+bLoqoXAIw0g+9Nx7InbHbX
r6/nvVogatcw9HE+vKJjKTYn5kxF4fwuXgRWeMiiO2v4OrzckULTZFq3Yu0Vwdt2x4EXlK38yo9s
5kZ7kaYadlqNFGh2aBsWQq3XZgwtjhKAc2vyiiiQjEl6HH9aq/zvSeuY+wVtNHfzK95htt8+swWD
+pZhkXYZK6ryDIbFRShPtIaxIafZMHgEeCBHNfJE20aiorijfcoovRw4i+Kbt/eIjfwxRXg7SRTV
F/Uq6JWw4GlNMYkzkxNuPBVFnyjHFmO/D0INOGG+LIa2/x7AG7p4sIl4muKo1y2kYBso9OYndaeq
mEtUj4XJYZRNaQizmnqha4y9oxzmAizd07VW1+0XSQAiGQJmW0LBPZKzC+EgEFHhmQeM/b6BD4C4
kvw/MHjr4c/2v0tX0FDwaxUgmJj+NhX6Mqfxfe19cAJ5yvr6lOuUdGg7MHmD5vXnoBbwONMaUfJ7
AKGDp231vTftK0R6s4E5oJLj4u+fsXtRFgcv8chNdifvi0NAOfuvXFrYG05fik6wW9LRgurNTea6
YRUSH/ZwtdJgAOaHw6Ux+H/O3cgYg3gJKUqNu7bT0uzGLYQRKueM8LTENKr7gRcyS1P0IfjL4z4t
gnYEUKN/gKcTB0ogdYTHqeCnYgJybpJHEDNmqqu8fPdfGnQAJl9Ezbnw1Rrr9Yb8qlU5rKPyNZy/
Xj5pxIupnwoxL+tWv7tRjjmvXdrTHN9wcU17x50MarBTQM54B+nkV2HdvDJ+AKPWXXJZJq/Fi65+
Jzg885nK66ufN3dXp8slaI/2ooXVfNnV2AcX2ZDsOyQXJY91ImLoIU2i3xh5Fc8VSS2s4adZ7N5t
akMgTu2FnT1Gby69ouJG6CxRAjABSf26qalZO+WpbanfbqqQEm8LbqE6/5KeXUVLyvdi+PFcNKru
yI2RIvnRjAORpPe9lkNPBMyswux4M72L5URWKBCOhzn+7YD6bpNNbgEvv3jOOBX4OiBCNWxah7M1
H+/FIq0ixg0Twte4c9wtVjjTbE+b0EBhbMQVT+c/KvcmNo7rwPyBC/wdF+5AEtnk9002oOBR7Us7
TJw4z0VtugTUupTKhvX/+pxXytSYnpzjmovF85XbUe0uECPSTiwJYKk8S/tcab1E3dR3RX/p6MPx
8MeQaXADQabWA00Fe/YjUzTuCw6DLNFp2tsRh7R0eqBdEKWasCXc8CREgSnetHaLenPGbGEIAF5T
dLULe5Xlj0LsXfEc1X/Dm0qJtaAsP5HZYbuLMCxiHGXqGxcBaopyLja/yrUU7qOekz3PiZDaXrPC
7vtusEh0j79m/+Wve8jGpWCqP7fxxB7EFH/P2P8zCeL9jWfDD1lgSq9EfkEYwLuUUhFoMJSiR9LA
9ag/76ct0fxdV9PtQXwgDuW0XAtw9cbgvF7cieDWvP4Eb16VeE/ZjR5R+MC5Eu6cQ73x5msWHM2q
DVEtFWx63Vjg95om5uqZpVVg2HcM+uOMiOoILcoFdg1MfrfHvDppCx4L0tXoDFSb82DfxlC0O/7C
CvQvlSGk3hNq4XR6w2OB3JUpkk+VaLHZmTJmoB4xDXsINFvXYcrtUq1+Bhsd7D7CGPTyc8F1VXdL
PndRwTGONhTMCdWXGwfOyGar20QNbi7m3N/yt17hVC43p5t2jc3/2QqnbFnqbPXPk/W9Tiz7y3Ml
pQAbjOXLYrhV7Y+9YZbvMQYDFSIkW74uC39BmRs4YI5xCP3oBG3yIIvL3pihZ0jOnHGArQkkJ9G2
EH+Iek9Y3m+dlNdHebPsIAJXMg0qV8pxWuk+ZlVbZ6BC7w3tcujnNVvH9ZW+PowyR9xdm8mQKznB
6VM3YY+4sPTtceFqrsWzU/yiVFi9RIr/pT/nwbrrUTg692gZbb5ObvcGTWRBBQ8qKYnRpZdrYw56
O6Kjibkn4Qwxfov3hj7wneoErDPACjBXH0PVi00Sy3jSbANXPfcTTiEBGfN6di55/BqFJ+uhEbH4
x9D5sW4rSndSBVyOSe5OC1k6yQi+L3UYSPf3TFPz6bBFM1B8b8rXANRpWOfR5GdUkrNKVze2X/fL
J1+nAACMVPE3Y491AmxjexmDncWgeLTlhewEl54hAWHBG2p1uGXMBp7/fPlCElSpFWXWYxhRq1gc
V3+l8JsrisLj+rglDi+5R7YunLpXqU8bknNdH8wB/Lo0hvwgnpJ9x7xp5BQQHWNSGlmcEc0hgPba
LstZBzmCg5f+r1JIgRSnMJjA27Txoi4Bqr+KZosdCjRbW5ysxUlzw8jL+If3w659Pyq7bstGQm3/
uyVqr36dM8QskUzbiLpStDZB+Cp4yyBj2p2d50AoZA7o1yPU6hSa2QDqvWNJueAh4uH9J/LwM9ld
9dfvUw0wHnCM1M1AzKuj2EixOSXqKetJS0c5iitIFv0MgkCXnT3Y+l1WIm2y0lQH2DOIi72TJc4Q
JCBFRUBC00R2YG7nqHBRnR7nRA96Hw/4CwmFpIe6JdtdP/YDSnPRTqaegNGucYi1K5AZO++vWmCq
4d0rPR32fGttOlU1dR4VgP7j7F7lAgMfwVzoukT7wb+Wx9W91KNWQjeTijBUOuBKVd/A6v6lYFKh
WkAphlnecJECCgLnI5JvKogV6nRJ6Z4hfc4UPOqLUKHt5Gt0ITjAOXPlbgtTa4ZJGw59EVY+Kc9i
fgk199qSkyWOomnbFLgZ/x8QzRwy5Rzs7hn+oggJlZMxwAbnGB56dAh/7dfNtk/M5mzvhr364MaG
uYhtV7LnwKR8aYaxTvAPwM5yA1xxJxoaWUNIoG9epuMMFOlgT4ac8cxSqfLDle47Bax1DT4X9T6w
I5G5EvMk7RHtZG89x39LZRqjRYyJHhviP3GeLl58LO95+CocBHkcHpdacxFA5E0Mz6g1UyqrsCVk
lfC+rdTY+9gHRJMDT+8eqsRfQ54mqQAPP1UWz/k4sjHtgq25ivyeMr3s+KVcWMuuiE12I4kunFR+
2l9U7mf0JOqUOIN7aOsGpRD9pxXEZbuHN4aamIpSLMIQCJRrb8mtooRLGRKjCqzLMdSGIA33VvdQ
qTNIUg5U1fF/XNfJccwBxFbbVYATNp4xUsMbc2pmwqil8nsUwKLNM3CiDhz8agGAQHOuSspa4Axc
oID58DvDN7tyRyL5A0BTCTjjtWyXEldpcXYJ4WfxkMMYYvJC/Zu/oXThAU/a3xnvgn5Xq33xfven
81H1dvyOSdteK/+RRGXrYdEA/LqTzO2dQdB73Q0C8FoozCmD4OL3WG+t8HKpQMrzK05qDU2dPk/E
OTHbyUWIfOFKDt2MsUGzLzTVvbrEZ+pbGRwW07Kwdiy7vNOZnY8H/FogW2bZ3pDjTHsyv2C7uW0W
fMUz7B0IpiCdUEHtWyP2xz6Dlmn8bkYvVgy0KEAraJ2a87Mt4rQ7Pjc/2GOOJH/3wpUGBo84Dzwv
8lcmnBeEJcl+PByDu9I8Wj0SO9RFC9l7l2cbhw6chd+Rxq9zH19vUQmnrf1kMPCVS/XKW2i/B3ff
BOYFZAFzWcdFoF4oS/M3kAxSR35zgRmMOon7OFElLRzX4CevQE811ucBdpy01ecmFb1ng83cRNhn
Lmf/Hht3R7zUewnbJHKD/x+6CxKRxBn6T8+Ssoj67HcjRFMGnICQQyz2lM0WXWIPHQGX1PN3snkp
762L9KifgI9KIvJoqED+9ybmiPZFGIEtp5515gSTX9EDgOFeA/F0q43OK3azNfEm+qhXxS2fLTx1
xNCjabdwzo5n2Np1OuhbfIxIJE6/JsWP+M2iBv84dtkrYjANUMmBz7AvXTuDa0QSljG5VfWvCVhJ
YJ5FBNVO4BukvjaquPtO7HuqCqAxcVzR8zgwvwGAbToX8ktLYlf5wGLShFTRu5IDL4OSUuJ0AHvp
MRQzhIdYkCIw5yJlkG==