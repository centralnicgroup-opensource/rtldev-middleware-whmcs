<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuQBm4YONpblPK9LQmzgY+G+n8gcjeXvywQuc2D5HbKSeMJx2so98lR2zzZl1+11+k+3EU47
xuk4uC7Cq61H3NWh3aTDBXo3cbYmmvUWaJ3kAh9HBfgMZlnxQrEWxCZC3Wpobt76jPh+Zoa+8R/h
Hsgaeqj9pjnhp4aZMW70IHbxu5kXWgOJkY9H6hjGv3wRbphrNCXZP1O/m4WXnLmBIC+LPfxnY+un
HzFzCST6tIabmHHYdTbnovI2Iq/aH5T1tiNGyNb5lAdTnEVTNraC8qUfaCjgMierst4i4P2dCfb6
7KSpi3Ql8K00vKEe4fUmLgnmHe3kZuBnFmKP8Xzl7vNBebbNd+kvL6zsHJ5JavLcaokQifEzGQ/0
SYiQCTbD7MW8V79ed3Y3Af59+Uch7GtQuP4oyZy2E/QqdoVSuObQWV6G+p8nV7VQw1xqP1UKVO8I
C1M7Wfb6MPNoUuMo52NRQhSSZ75wkQ3oGS8D1zhXKnm1TaABaLyW0b6SEitXf34/8odkHCd+Q+CX
uT9W/8u5k3toayaGJfhHui3qbzLVB1G6fetmdtL10D2ebqBsmrAZJux4rxKs+RjNsQtK1oG/rUsV
+yWMyIvfSE/fV+VijhvuhsEBwKvOvHQ64pFndeBnCXdD1Ikm0tr/eyf0s02y0zU3EKK3MaLCgs0G
XE4I2Nqwt7ngnlpA98REoy9x/kSDpJyRAUtYsrckTVAYWvux0nB9Xl3Lh5HF1+Ce4pGsHkKKEFW5
0MNJYW+DbfoDBQ0vSIJYlpEtM0tNYLewThQOLtGQM3u9G/KhKB5g7UP/GEJ/2mjndFZP+5lbKFGt
6WTB0TnMUEEkdqRl9VIop+aCpt4VistF2iuZnUH1et3Ge2nDh7fKqd6BE3fEuhMELW/A8pAEr1jj
YsfPHTQFtOfAT7DaxAYlW8bfRy60rl08kzIyxgngm8vLjHJnP1HcICY0EdFTQtcRPDlJKm7G4ij8
cIJi3CpIQJbJDV/clixuBYnEvSduz5p51sN0rRfzVPPYKmKK4EX4Tbu6/hvcHF2Ng/npGXtCvLrg
aCbr/VOPwbbVuAa+c/jfiVget21Yt4hvPCPtaNH/Ql421Z895EkzTE43NOA7FiFLHM1eoS9cZFav
f8GWp1Uw19ThPFqL7UTenZP3H9rDe/KJ4QwdGjqUwCVCbt1CAfRPfNHmafaGjbzVBq0w2g12dG+c
rg2aHhlwogfFS9fsxeKhv0xQnt4xowjzeTaDKSwlO4gvBKXlRr+SzV/RoRT2u9eLeiR/EoWemiBX
lSRemWohRzOdtv0Cxcp9f38fZwuFEvrtSvEO9tBEudMNzydridfeeVGNpyFjST5Y6LL4I8+9G82g
V6aLmuGlCngVR/JDl4+S+NeLtczpb+IgXbY/XL50ALak3H6e+x7rewbqYKnPqlAjMhLHVlQ+jOVW
eB3iYqiLtoQj/tbix60svWpUTAa4ykBiycLKDHLVEnXZDIItiwgusY2AdNFYIMagklJlMtmgk3c8
PGtl/dAVrkSodj+dmXvhT59vm26MGSSWxXGQ80aOYCy6NTJBP61m73S6ezBNjxEn9o+LTgVzBqM/
KNi9hCDPDxBZDG3GwceHbfUSRdDH+3A5KAwE7fNOBgQpEpuipYcqA+hv3xmMrMOQXqOncOrk2V9u
8BBDNhNFLufSVxeHn3+qPT6zwOOAHbI90zr7VKoZ1zIjlvihyH+i6TskmLlbkJUt40DpNE1lLxcz
SCxWjT5DhYk+JqLCOrQj7VXtf8heaZ1/YjmJS1pVhr3dnGl7usUI9Fb+bM0fTiyrDWgXV+rGKmbq
cUkAFpX1l5oLi+kC7IQGCUVLYe3naSNprdW9VPw2t6CAHUTR4ACa1/fckIRKf6jQulgahvdsUwRh
C9h0NcoVNDqXRPfxllphiEjncY+PBcw1dqrqIlbH+sgo58hJZ9MmOaUYoCNGtmI7X0Aaw4B8YQSI
0YVWpPLz5b65TI8e7E4wAK7f3FAL9IA2oBN4RdVhdpirvmi9FHpeC5m7U/JKGbusrceHVC+ja72R
UPR+awY7AChMJu2LlBzgg0lGcHMsurmHF+iYch1xbrvL1XPyaAkKlktLG0HAe1NTUidx7Ourqe9N
dojVLvj1dQVC6zKebVAa6O/EADpPTNY86C6VWXXM1mAJct6t1SoMwaMOJaEBubMx20EwfcuH1MXd
bkE7JCKCGHferIAyIjuGkzPbIpLxOopsUpHGcn0vAKu/TL78zVQbJL69n508f5KkaEoUsxoQcseS
mABC7x2ULQH5bmSHoC9DaBUxTbgF8os0REpSLJCYkinK9QkzWZjM6vnB8N8toMzhJfZRZc9PTccl
pygJ5WOv/2db2hDE17qp18kx7HN4i+OTfov9HTB9fQpQKyh8pG08dHfFlna3Jnru8lxSLEEBGQUS
iQR9p8Eu6YL1d0agtUfBtMk6+morEIWa2BhgnQORdFQjyd4/V1FEa605lnInWP+GxwYUJ39Uqs95
8O+FGmU+KW4XGB1klHAfHgNRZgMNzV6R9mqGY2CUay3TKlHds3x7H1Sjs5tdQ1CvZ69pxi7wHhTL
YlgaImvOgHGzIm7IRY0oC8Ob/iOxdT4L3+6fduoR+rMaHfzQTq0PvvLo9qVl6wtZHKV5bE9Of5kr
2mZOIcTxx7RJ+u64msfJdVTMbUzI8AUciC4Ufh4pUybQYY2ekz1y/klKIUfuSVUdnh0etcF8DZDi
AqV/Bc+bDCEhtswQ7ujjyn20eWwigMpq9evccGM10Y8xDz/QfTvkUobScXrAhfpjneoM5LnqXwLp
oJIR4L3vl4vULUh9DbhIoouMvc1bN5JLm0IWdUQyGmAI7d/zJGutQmf82/Lu9Y/hAlLUJJJR1ptY
b1Cwv+wmf/Oe4xNPj/tjOXpMxKXZSjA4CYOqY8HCungCcY82R5bLyMut/0M+ieMuk5anjQqLyidc
ZOKZ6eolQLn74iT0xTHVmWxTMJLvSD1AHMgMLHql0fXqjVdFMxCVX7PpuPNOj1KcxW9GTIP+oFBU
wMeFA9D1rUakFOgXEUQgqBzo7xpbxHbQXIH9Xey83FymgeSS1wIQ0yrlwohUvtzBBsvbI/rcH3fF
FjJ99IWuvMwvyj0MJgVAIBCJAEEjRmf4nPzKGyUjkUVXoQ1i8kx8uZKFuCVcljYLvkz6APpDRTVv
V33BpPh5vfWakr6ME+G60vq761hyS4Wmr+6utpRyWZP+wLXtYr5WdExXMEhbId9X2C1XrPqtDdWd
EhcJTsa2SANLSa/0TEJ4HTAKVuZdw3tBdCZgT8+FbdOJWS6HDjBtQdotufVmI54l7KF+JsANbuvy
MTo7c1A/SbUHPEG/nvF+Q6gBZVt/zoVnl4l/ZXjZlGSu27H6vNDm2QJSevIQjwP6D5jgH7sP35t0
Jc8J/p2kFJIT9JX1UTqrP6GXV6dk0wgBMtUfZY0T2c6/upAkpSwN5s8RmftPmRnGvfzUEKJNfNFq
jUcAkChNIIc2fkRgYByoZMzcFaaEQLXwXdM2zBXsukE9z6h97gQ/IjB5v42KJBruT0OR/zrqzNAy
k5uktj0Tuc5UlGxtRTJwz3EZPven1dvEOjKfo/UW2PgpOiNw0bRMDgoB9yJTRMkQGq69h6kdzhLX
PSQeLW4SesPpRsdFDEs0JVoEqL55lmo6Q3Rk+WlPFy1zx0FNPzE5YGnd/FpEfZGC6W2lJfupoWHX
nmnYRPoDFPBRIPcJkhEYgQmBfesVIQTZjmTqtk5PwmuxrauDOxql9661oGJJi97wwpHD4kd2jo2G
YBeSb57rxfPczTyfoQbls+wha+buDoWVqP3/UsAFoyUU78mx0JYROsp2SD5+J7msslqE6kt9n7nw
6ICUEwCZq2tys1Jo0nMhZTV/YySKSTVGRcmG9I/OnCa32lC6O4lFytTFJOZhFv5d+FrAKDUGdBID
py6mpQVTyqpW4UOjMpM4jx5WczNZkTnKOdjVBB7Y8CYkmXcUw5nZosuhJxmqwSNnSCEFvlAoBHCV
nuT9Oh2S6uyFI025lIDgZIvDR4Hq8fh7QpM96xateJ3fT0iluBuz6VoXNI479kVbRL65NnemhEyk
l8kGNmgvZQj8DPSqh3U/KyJaA89iI6Ayw35BTchA1aigH46badnRZFvmau1jIG9Bpcj4bKwdS25B
59Lbw8VrY3KuEquQcStBaIQCRG9oTm6Mkpb7PsZeI7Y4bZGx+V05zewDiFPDSR/NRw81gGgxKkZ/
er7Z9x/9a5LUjGQK305AhwJPS08=