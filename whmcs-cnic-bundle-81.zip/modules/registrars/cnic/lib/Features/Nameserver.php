<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/Z2kF8tWm75pWyjqVMbY/AzsWDX5eM4qusuwTYDDVV1vEri4i8gLV95U4iCAT2Fgmc65U6C
nwIV5meT6mIWx7MlQZaGeJSCSrh1umq3UKKlsseExyOHxWM+Blb8OvUsXJ/70B075J2rczn/2sGx
3lhsBAs+srjy0I9w8jSjnwWApbIjLdg7MBGlKrJuXtuVJcb9SRIlic2GR3Kk7uGO0uYvEk0H8Uds
zIZQ+5GFQp83CJAPyyikTJNHs24354TfhAQbyNb5lAdTnEVTNraC8qUfa15a5LMbcGiMLEkHOvac
7QXu/oQPlNGAjzF6pNMRucvOVbD4md8eSW2+HK4vfwx01k4/eptJ7Pzqw83mvK+k657SaiptIH9k
9NGoslut93gnCskO3nI33lyDvmvaWdRAjkarXWqgg+3UN10lQunvNYpSeiNlfpLmVSETjMcGIGsE
hEUeP4oLZuOva2e2if4TSEhJoTrVwl3yUmzgpsvpPWiz0yCiKnAFScZy/tNyYjMibaj2NUV5gICC
fX3wGCgYaqvPQogexyWmBq9kQZFaawFZv8JMlKjjAnx8xFdrX8cMLw76/+QA0awWJ/eFy2nuv0iS
S5MI1lrzXBBz+3IqC9Z3YCynzeh6FqSTKyfT1LRwgYDBGz3/a6O9Ps3lqdAweggCMHZrEhHzjqRc
Ur+IGaidcbY9vVCL2YtrCJPxZXcgDYmoaHJ/9LpoXu00h3ZwFmP833qU7+3jwcRkk0nRWzLjiyFZ
nWoflfZGDZLqUgxMZrvCFwABSqUqrUgLOm0q2bDYwJUhoD+ap1o2rzhTwGXptumeBtO20zn7nw5k
s1JrjmU6XTRVW1KSeZXcCo7ihzfCU59NICfFb6oJICOEw0SSPFA+qeMBmTDtUMq0VD46B9j6vxnS
U7QT6FrpWtrLLkbs5Dt3ulEZ7meeSh1UxZyNtpRYmlIY/DDmgJIrx2M/yxFEfPLjTjpV+7yMxy8G
Kbh+fVvCTFzX/bHXcRl8okl5fzKomDicr1uo3CjG8rZO4WPpK2ENBSenQ8m4ngTL9b/t86WkS55f
mUHo+dEJr08Z6rBD3dz7zHU+cLvSsZ4NlxILfQBw81dBU8dmQyqS5eCIZWaQLBLfL8Aq6NKcoSZD
165MUl+8klO1fOyIc0a8WRnnxQWgquQs4JNmqSeZXkucb7XcQFIK70xK0p3nnJ5Jfwy7L4Gt3rSC
sFR98W+a+84Z3kfnqW+15qqaodVY5v+KEgP79bW8mIOSCHrQ6mTzivioUjrCrPRiyp8nuV3Dy0Vm
NTWqh6gugjB60xLDXAaT5S9CiyMvR5G2DygXJkgixidCnlvM/uch16I+YDC8i4SpYF/KqOU3+6it
rfo2oXWo71xi+wX9j8+y3FLjVd35dfugYP6NXrflNO0Z33KnPUlyDz2B23G8HLpW7jx6YDM7AQit
mYjAK5PC9Sdxx4EvGjGzTroS5br+KbHS6//l6NT9nMRLM+Qa5JOjDf2lUXF5CYFFNOuPXwYe6SND
CMP5AccTaWIArP+AcNY5Vzk890I9Db1GXPcQ+tbPDvk47lncniaG1Q8OO5+sN0kORUl4DiQ7j5T0
rowdZIb+oNW9+KNsv1mJ2IC82Z5iWEBXxuqP6Wke+Mejld5wfQswEoq+6oISvCw88J5pngcov/Yb
1kZuNjUcQ0J/D5US744CdrRyXWf4/rD3AsXLJBhB6immgfeA2iBVxeLwVXZqzW0oyGxFJxwPBlVL
3jJf8+HebB3Bgnq4MdHVmtUxAWbEmkECQaIfd0FpyUfnBbGgVxSZdr7BjpxAV9P7v3bJ3LW3mcXj
JTsriPhf5hRKv7Y0z0J/xi9/A3HdWIF3yU8DTUdDx6+9x3JjIAECDKXVZYMBK5tU4qkca9RjvZgN
0XZ+fupUryilKLVmj8d24KGwBh0jmvanqOAag80sdRa2pix1KqAHxMx6yWrxbLcFfwC9VsBV4Gsk
36pQH9eQHW5F4QVSjP2mmq10b3H2d1XoAcQL6UukafbpfDYg4GTVIG8gxSfOaPDZzr6TLGTSnV/a
ElGD/RgDVpkQrvrTNT59UTBxksejRra1d9eno7gU+yooNp4O5Xsi3PxC/NE5h2uR0mqGEOxCycZ/
3qkrfmrfTN7TQYwb4VHGMiJPYZ+b04egmW7qCRU3IrrlETsRR9pLFZs7jaed4tZGRQCD9MMKid+i
03IM4R/b190J7AjI5dH1+p367B2XaNWAb6DsIGptsF66on5hJ6vBIPK06gNGDbRbV9uKA475haea
0v0DOUQBFKqF2zVedCjIPu4t6YsqHV+yHYVUsBZj/h1e4F4m7NhkJZw+ABnjTIfFvIjOeDW205mv
MyAV+BrKH/1RsmmMKqBsc/imonkB1T3qx5QG/rtBRYFt7nIbtYQN86zUjDlTeWMyXipdiWFXxtSC
jSsPQKsU9hnhCXF0bfS9Db/R814qOpEUJuPuWD2H0oiUHREheB+hbXia4RlAY0d945LHawOUEw3y
MRLZXFSucL+PDHQQh1Cq8CsQfkYDa4kNho8AHDPgQ2oLfiyOcCav7ot1C2Udfd1A99nGkKJm7QWZ
LzKq4vM5ebAwYAIVBXCMT0Ko8pvRWBKiIfJKIEyD3OaEef2lXCUzNZtT/Q501Uk1MnjTGQyXQBD2
a5qOMvDAR+7cB9oNw6aZsXxD+j1v760E5BhbQDJI7d9Sr4tV1wdhU6BjxOcc7IB/W8KU0qKMFItx
l1iAyYe2A4/IKPCrIg6s0Amc4cneqPOULSWuSexhkNbo7UEq5VckUo7rNhkXlM99Y04NmGFM1bOp
2Y55su7PE+Kzj92Qg5Qdrkhj+fNGT87mxUSXZJ56rJ2mxPIPBL4hEGEDIs37sQbKM6/9qgvQTim3
frMiCWepYBEFXPAVzph5sstzLF0z3w/eEbMITGQ2XOwfagwZme2eHyXv6PDKj/j9ptSuSujgilNj
T4WMlGQVN5A9LZSJx0tepd+8d6Hvm+bRPrczkVk1elCCbCuKPYrb6igYOfnUfbgm2+CAJEUTuM17
yXLLfSoXj09DN+/lRCTyusLq0JPSgaHLeHLh0Wdg07VGGVP3EjfA7sSuw6rrSLpobG+XUs9arON0
b4bpjMr04AXqjPtxDszDa4gz/0mSYm==