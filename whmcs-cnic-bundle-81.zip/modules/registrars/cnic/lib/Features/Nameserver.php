<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn+xPT8kA5xcDtRmyNCh5NXh8bLsCLj8luEuMmIGFbhpE0nDopqumr1qsJvNCw+9jgkAkIys
M0W8u714LaJNToDRTXJKJ3Cv71KwawcCtI8eP8/cq6bMAU+ulQvNrTQeC+mV6GTqCQN7M8XVC61L
eRWOvJaWi+awhyppoWhfPmxaCpfZjs7teFETtNLn2eFkOYPQMyZnwA2S11QKz0Z8ye5+rJsDXeZw
KNo1CZQUsacp72UTlA7uCZYLqB/KkrIfzYrDOkRA1vVVElh13H19FHUREtXa/zUuRHZUWs/orCim
rcWc/+tZo2MCW2lFwLpqNsREWRUbccfX6HKAdNUONOfRYTQz+iXyx1UE/lG9mVw7kCd450hIssrC
NVNJZtptRtEXftDHCUxT8LXnm8TJ56RKXcB1F/zzCjePL3DeUz8jY/pSP1z88Y2Rk2JBeVwx6B5d
x7GkU2oSsMT+vjgiHVpdq/tsQPuxLemuPHQwim3sWZevUh6umkyx2lHKkiMNQqO9t6nxYlQTeWxD
M/vbuBszo6WTtOuoggWHHj+bCBuh/9hO/jZkwgRJsHOEZ5XPsbIca+zKA/k2/YSVWjWgqgkQyOf+
ToJzQ14DIzdzWa7IAhbebqkHKHRbONcYpyU7r2yzD5F/C3u8wq4lgHJuZpDlzohUqZgizInUtCsH
8PKxZKbu7bqFIfgjjhf4MQ6EprBwBCUKbdvRGGq754YfoSOYp75NFUeKMDzfwoL495iLzwoT/mGa
FJSiNl8xmvagr9poRj1h+VYgo+CCCOn/7rYMqJd5V7j9Zv5ykkEL55gOKpL0ergPZgxouHbFZ38P
NfSGaITQAsOuclvqOI8Osc1r8cu5TD631+6gQKJFAO2g5EXqw/pA9X4XstPpPcs4JFr+tOjmiLJz
di9xfWIAVojmZbiIBghQgOJygCoVYpPmS7hhqJaW4uFeMgAUefInt1FXfwn7OMWTl5KogHd2UhUU
p7hG3eJezPFqU/4G66SHnIzqnPfDCIQzwDRginA3wtF735g9XDGRVgJC3dVXfxGeQmoFn7Mf3cmI
7jOMmwzbCDQc2CrO+cqBaxam+8GBlN9k044Py+iYKtry1bHHM7WMYE3co9clu8ZOC22slO1nD2qb
xraDLSRAzflVSnHYZI+3x1bojCFFi+wEIq1w0XGjNOlQ5CiDMSjcSysAYIYVNM6UhM9l3R9enVGY
5w1XdojF1z4h0NrJxrhK+8uGJdUxl+V3kY9aMaLC2JWuK+aoc09EK+Bel3uho41A6/ngeGrTqvH6
G1uUwRfqYRw2U4S2x70A6YpeYKKPjaDzBy6Hpvaa8rNOO7WO/sH80sQOA9DlIR3nFRqHozxoPKg+
/jAsSc3H3MowHZThsRd3UjQF+6jTgtEMCJ9AW579WYgZZ8GHZAPYlN/o0ZIbklHwMfSIoHbFfgVS
/p0o9IKc027PnQGxVWUrvbVTHBA7IBQFqIZyzSfHEB3gJ1SI3r6w4HW6hESA0nfJq1dmtNb68Aqu
BNhV3yarWtrZfQhuCxCqNwxsoHO99JrrZA4bkYc8jYZXNUEpA0zX+tDq7+91NHjBkTq0s4KWMdYs
9eLO4d0eeKu1lHGo1m9Kk6h6veJ2a5PQLMo2/VXnQKJh+3T13lpszOoNE6t/KcofJOiKIlyRVSuu
V5aZxmfPlYHJeC9HJNlMa6h1qLNN+aAZKPCNZweS7gAGOpj0nAOAgDn+R7n1UWo0B9/4mUkxsjrY
xO2OvLE6JVvUm3zcJqcoyMkD6Iu7+vnJfln0fodi1jrbr4c4m4G34MnXX849fzBkYjKFkI03Ygrg
eVEfg+6TS9NnCN3BfeClIgNgq5QsN6qDdiVmunLoWzYEKGyOgNfB7ABr3axIfPqIILEfL4fjsfy6
ctZPRyYzDB1AANW5WHr+D6gjuNJQH5qvP1IB7KzIPGfKTEh6SexqvksRlmCNFSz5hsR8hHdpsGaB
sLPzEhi/soQ3hREqv7H/QV+zVkbHYlLudG9oVUzRNmLyD5mfAt4ugCqbMlykDlnIteIvk9Lg57E2
FysyfGtqc8BxoqhnEWUvw8GSMEtgjFqkZXe72ruRemFBVBJ3ujr+w2HyvN0oCYz5OH39Qw7F9ftn
zk5PvbtoIDO/4Np/xPkYfVnqWqkOIQacWHjYqQaCXXDb9ZQI5PkuPIuroZs/8pxIBALUNWYyhkwD
PqwLNHAK+yJ3O5BmQFmg3rpZzazZmHUcwR5iS+FaPv65nFdC1eu0CTznmlK7ULxjSM0nW9FiSJ2V
+zLMuSdR1GXJzcOuqPhgxcLEPZE8XUL3PrN/fs1XyXdQevnbuBbdFHkmFIDTps4zQUtBtId8tPiW
we+pJlbBS5PKnjy17ybHnlFB83bVLOqj4VhEcBRQ7rqBtXSH51EnKSsGh549GCwspvszEGZtCVFy
C+CYYyklph7iqUM613YYijUxxka7AJtC+d6WzyoywwJLnMwesrn+RtOFqKUUxrhUKks7jO59xI1H
DncrNNhWLhWqHqg9iamtYBA4AlfMYSdx7vdCyvTeQMmhNyCqk2YejKS3NCyK20aS4ZYEAgZ/ETVe
AQbpB2lm0rVNcwXWrQFsMQG8xSYot92lgyFXJlSqqtKwkTOtlaEPa9dPBf5ESJXLOZN+/QIYIVP9
qKRKgG8U+K7PyjXIiAldW4+mnIyAWKBgAqZ4Hfs/X9Q0h1pet77BpqY+6fo69Y6CQcU2jXaeV8gO
nD98YHXcUIVtAacD7Fx0VA3ps+GQWazXySHyu3TXFtGY69DL8plf/aEx5Noc/ZUiKSun6XvAqXMm
pqGLwjWdcXHUysCcQbVKqsncUoeAYXhpLeOixavjwL9pphE71PEPPCQGsqr3JsKsqZFoqc70eZvo
5AmTjbhhG0nlgsvz7Pz33wk100GO8fAElcybSyRYgwxtgCoZ+TO4RKCNehWDXEmO0JcONcDNvj13
y1sjE/fbVuPcNJagA7/rs5OdwTgICyUMvYl45IVRujdQ4zNyfiNetoS/OKEcGL1UxsFUX1g4XPhs
Wt4R3sFA3Z5O1YN7ZmAdkugHvtog/+yTR1ZlLJjnFULRVYROQXthiBmj5qVogNx5XNjujwh6Vj12
qObMAhp6ks42dDaBIFpBXSduzetSE09JopEXMr96Sh5RCXd5