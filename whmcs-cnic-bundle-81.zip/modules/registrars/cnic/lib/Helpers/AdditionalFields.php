<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsnzYX4emmucDSyVCeQNaNsCl/H5Wu1mgA+uEyOzIz9N8rwIpyGroYE2d4I7NGDP/MMqjm/g
eXhOa1LkSwJYIub/HmqiLXXmbnXBCPxwzUTQgMCSE8Q5hyljaidaKxLjMnau9gcgCFCFQrncMZNW
Q6irdnt16GMvSff1fdyXZNSkL8shT7h/2mMCtrld7c5WzC/LM3MYQCSK/sBVBs2OzwBSfxRgWVkp
7sMpHpsJ703MK2kqumIreE8z8ygVoCaLs8KsyNb5lAdTnEVTNraC8qUfaE1cEWy+ttwo9564+fcs
72Tv/xoBuozprq+zBf9YcRmeSmG9LG1FW5J2/PKzUKgKipu2SmlNDz/gvM8rYp74Msx6y3DbM2uj
v+1Js3v4qaRMvqFWHN6+qNyq9Zk3ksRTylE4rMbthffEru6B7bX3DpR/B11nHiWhaSc+MAhNVkrN
LT9sddjYKM3PKskQXubuq07xKnHLXRu8eQ+CGRXvf9krEr//wLldwnnM7L6JnLFOZ93ulLsmwAwO
wWWUX1ND9Xko/zpYKVOIqIgWN9/C94vWOYXDy9UpWduln78hgTxwTGjV9H6WPDE2QMDFQ87IFs/5
58y+1y2r6PEH7nYSeESo9f6jq/+jJM9Sj7sBO7JuULes3jny8a9Te88RMqJbhc3O0ArZ0Cxugz6s
UpfMbPb1YFKkpPe8BFoiumdesaxHGcsEjmIjJoOcch5nlbLxH04/1HOerU+WSfmvrZlOMY8ChRzC
llJWNdUNjYXZi8V7KLvxKvAOs9jX5M5opyYcGdaGWDWQrjjlnxeojFraN4N5ba+LZYuei7sGZ+O4
ZX5tdsTmlKBhXXhl70sw2VYRqxfp3kNERjwEr7UvTqwtZAOu8VUpnTKz/nLElu9JmbyfCPs1UxMu
6jHvXpjm66J7TtZTOP0ZX/zdn7xvcE4+8NOVR/9t1NvqPHx+6bxs9yUfHkTfFkG7x8+8I5YHI009
zhkELiS2M5lp0l++cfEtYTMjNYeuZdg3VsalDtRYHNy3QnWb4x8Mcin6kYonmQEA++RUDMaZ2Zue
90HkyIcUgOwUp8qrWUOecQlZSTQKQ38ujZPGXmAbYumN3PifrBLBPA3LL0O6jz7S6OLOtH7I71eK
4vk4TLgEW2/Bg4c1ta22rDERRU0vYhmFEGz27ckyoXYpoTbHMEbepS4rfpUvTA0cCek3oIjXP599
ojpJn5OfAefJUVNvCqvGiJWvCTbhjS8CnQOtd8Mp6CJ2QrycfR5uMXOim8GnlMJPidOa+SfgplRA
DxS6Gg9Q+krOo66cZN2EDIRVUqGoh4ldwF94ntk3ycNZfdplg4Cx/tmKACoYsuzYnwsKJ3tmXgvQ
nh2S3kegsVqHqa3AjKzJn3u7HhBTXSFr4OyIzS4XpwFu34cZeRsGwIm0ETSpDlIfXCT/ZmnNpbl2
Eaf93okt6ug8DwoLfZemyDaRZhmOsSEBzaa+x2lEPGMu3pSc9J9PF/62ONdYFNbSXrX9MtmEt5r0
RJ3Y6pB4CsF25uoYv96sw6Uh5CKZufYXFeOIcul8/ndu186tz3/NiVMUg7nb8puIDcW9cBxltKdQ
nwNQn2t5+t9RrYgPz3aJNQ91TJeCTdJDHX1WwrPyviVL2i1pUYN2UnlYQPVQUPPhQW8IOjmO3+8i
9h8c7EhNNU3rvWiKKRVHAYBuXBTu4MSCst2X2AFZcrcBBmW2zDg8gGt1PHZpXcybuU2FAidKqEpA
lRvrJkY1edEebt/IKR/HsqRNrqusPghCXKx3wsiK5J/U07F8hTUtGzPCpnWPe8ypO28Qo80F4DdS
90Mcxe0qmA7MLbWfPWnNkZC4QROnllTSxIPQmZTZ/OKStMwUclW/8BxFbQSBUQwTezqG8YVd/f12
f8OlEiKDUX5+L8aZ7ZG8FaHd+/m+fg8SGEguhSngXS6ONIw/b0e0rA1Xfl6bxtwv+r0F6zAuZ+Mu
gWDcETRzywXBTBs9