<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxKt9ciJ6PjCweMpI8YVsRGxrDA2A7m9UDLlyv2UwOzVm+Ek+S/WxZHK8x/IGviH7rX4OrcL
AvJN4cIkq33Bkbtyjn9imfhh78Tp6h6kvx5d2VAE3kJOFW/tgM74WNo21vC5W6f94nUY8MXhxDCR
+A+5SL8kcQ3+BMZlo0XhNzG6L0KuVvhy3OmPXaXRG8CjQjIejHaTW7SzcTc6HQ7IvpD14elMg1aC
Txxj5il7L5FBciAt+rcbmUTzVfB9Muet3wbCIMBcoWUNtphwmGqGIJqNcpjcQ5aJEanqteIEb9tB
i3l8OFyskXevSgYzeh7l4S3pN6Vuq3wM2kkOh/9tRJVp3YCa11U4vyCUUa8KstXluyiLxe7HsIvF
jymthi0/jFQzXXTcLOYgq6o+3QWrhadHhAd4PRxI6Sws0x/H0rUwCxjO1sVNcKSl7BnhqUC12POs
vMK0gmNzekW3Wed9e3Q0BkDsoevniYH1A87WCn3pc2RiyN9fWOJQKxRI9nPdf872GcNA5brEnVcn
C/W0NpetB25Yypq+2ZYv7ZW0BB4Sq5WBESsd1wEup4BslKBMzWb5u2m4SeEBndNeBS4H86WYWkMu
jbh17KYHuI5d1RrKWgxuNhCgp4WkIqub8uraTbzPXoOuft11Rep5VsHbr2K2UEJhzhbVuzPHdpRv
2MW5hGTKo8mzaEVCtJNKXi5FYmbjSoloQheWaXRcx7fYLRTg6sI6PQpkQ0zK3giBlD9j/7RElp+V
/pjJRqtS2WoBlTmEjtXXlklA43ZTrxK+Z27ljKlZuyGAbyIxSVUKBuljJSnRS+5WJz9f3tz9JEEt
08/7mv9HAU9C/eQO170rsPDl3bTlnnrkbDVUV2CYc3imLnBVcSoe0Na6GjtqLnPVLMa1H2m53CHq
pFa3TM7cbSgfQHW9Pi3DFyRRuHmvnKVcizTH4P8YfrshGnfQ5dIFeAYQbnMY8K45PO/Ex3VQ+V7j
CJXxdRe8gal/0ZrHszs2EpTHukSeNK46n8bopcumoS8mf9E1wZxry4gQ/DPcxvkTlFTQCzS0+1FA
MiYopRAYa52csAL1nCcAa6jjLmZcUFuMZkrZYT7m9aXNb/fEMK3F/OLd6Rhp+IIiijCUNAxxCnVh
9x0jEnHjdpq/dRBcZFva8vK3xQ7W2xmCVMssTstkh9U/A8WhR7wRXcNFotiPsSsC+ImgpsO7Y6Vg
Aihk/Li/zPCa8BHjm+UFvp/r+D571bjbeQ4/LG0lRfgXyj14TU1wnvZ18wmWPiv9tsWMhrPU0D5S
QggnHk6iEK6wBP/Bt0Roiq0+PbutJ+3Lvr8L+L2ix4qatzyX9F/ecSvIH/EXO67Z4S/7dJ0OBq0V
GuOTRy80tVvVOaG0HZ9D+0cNXetAcaccTb3VqEXTPphVTnHivfyl5mqoeEPA2c60jH+uHoD+BWD7
rVhK2Esu6Yp1813T0QuUTwKOmRzIMrpPI5pBIx/Jraq7k1q/VW78NMxtfYdzFcJk1ajKU2WqkMUP
kiNMptcVZwjJszGhMm8M4kAGSY8oYD8jx4VxDI4+A6vBbKf15ViEZ92zi4jcszZ/qxa3KzRp0qNI
faNgYSWYRUkRpytBjF8Vo8gQCsIjPuq83tih36XR4wo/4aS1NqEFPOm0jZvGHbc1lhvZFIgqCnGF
xOSplLbqR25NsqysTa958hdBzYeqgUW20UElL7zSUPtoi99wZiEzJ/r5ShSlIs1dYKaoFQcLaWTG
rCwArTMX6+GRvuCCz9rRBa7gNabstx3VB58Zhc119rrb8x5mo1FOcYFIRgDJJlwTu/W2MXjcCeOR
QTpitGVfWwL6G10HLkZlocpoWxVPzDoAte6a2Jxtl+tiG9Sij+QPKJZBY1ZSr45wXbAMDkM6HBCf
RvIUNwX+MSpLCMTVOSbGEyt2HMvOiQ4aCAarElCLWM6EJC4gjlqtXUjbNIF8eWJLhUlyKS8ViT+a
5hEAR5Un