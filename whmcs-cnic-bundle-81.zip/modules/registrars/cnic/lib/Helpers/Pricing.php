<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv1j3hLE/lAw5wIRbbchhLDQWM1/9Rrh6Ocuq5rz3va8xR7KcJzRaI0FlrsvYUw0ZNmw+iGu
3hTNfQA2JNL2SQKp4RUFuuiloz74glETEq1ha60FEWuFZz/gv0bRqJbiZ23IZjTfl9Ht7wxMHB0w
ZcYR87mGqOlLOgz32YnFYopqD4DKisYBpceITEGs1lkGcVGGM/j4Qn59WyfDNsW2URP1wRbzk+tC
ON/JJ2V8y9g5ATqDuVVZUSADrvaHn/mRvefpyNb5lAdTnEVTNraC8qUfaBTgmFtps7ByMRIGm9bM
N0Se/yf9xk7mR1vFQBqOpsfiVtFlweXpNA8BZyLNRkHM1CUSmVoKCaS9bBcSGuHE0asSEpWogfcR
mfqG2MoANEyASiff16BIu/8/NhvsUWBXsfG0YNrXznUu/Q68Clv/ag15s2oKrfhk1e6yuvlNu7Xw
fbq2YL/bjbY+EAnZXu2m3suaIiyTkG6OSm3KmCpqDdnFs/SDmNtuM3JBD6z/35mmpFqD5QuwenHa
227VMquMRe7atmteHmraaLLAtEEx92umWZPCct2VeQgGSMSvju/rpDRZxJQPlnMLNk0bXTNjK/06
VqvEkKEQEMkLWs0OMf/KmSv5hnRmJOdYr5XL7UiLaMB/+njBZfdfSep+BnguqbTdTW2RgCFEqucP
dxELDECesC3Qh27g+4sfS7DWIKUMft68/qRQ0ygguUaTFK8SAHhK9mv9DejHHKuI+X+icOKTCCpG
fIne3NycoMXdWNj11+dSKZkna0Y17rBuOuFtvzO70i3gIFSbMPk5rJjZwGF/JQt9pc7KcWGN4Vwm
g+p1t+i6GHH3IMkylVNu7zoWJ0kXnHJ7BcqZEukaUYkBrPFKAmQ2Ogp3LQeUJ79fQbEaVrcXCJOD
Drgq8Y6Z5pt8wKa//5dhe2RrhyQjaTs3Y0XLsmjd3RxJTSzlH3vc24w39Fxk//9c/ZCjiY80PcqQ
VDbeGo8kUWLpqsp2Zol3X2elS8PTWiXbQ91jlpPP9aAnW2Vuu9c1Wt9FSVdZ3fxdCHPNM3V9Ivmw
f2+Cg3kW7H/HuP4BnLSZKAzn3J7lNDWrjIIiITNqQfiNQfXK2iFPiFe3GUOP0G/5dN86nbT80rAb
K506gCwj0ZwWx4EvDYLSxye7EwKhPkjX/6+baQgX0THresb9Mz32ry5QZq15QWW+m1DyoCklRYeW
I1TgAOk6gXhb+IqM9qbSoiRIWnr6O5CaNhYC5Tgpohs5rQtWaCqF8u8ZREv7fDGna7fHsD1GdMcc
8KCfEJcFjy3AjWWSgCthfnNwoXI2riKI/iluyxyWJhABUUhufqWTEbdnqyw7Gnp6jAjRl4RA/MdG
5pFTP9OjaLg1q1+AEkbc9SnVDtbJhy4j0as8TIcnZX+KpnXR58Va+doTPs/3XLIn79kGGzbnGXMu
Pj0d3KPZEdJaPn+feFyXIZARV9g3PhRYfH+aPqbT5GGZeFbIprzoPA75fgV+79VmynltDGBkrLlr
A1/nONgbhhQiyrj1xjgWdxgtWg2Gl/VK+1tGCKqGhLa2jA3VHtOkI9svG738Lx8Hy2mzHTpqIjn2
X1G7S9BwWTbYbggX4bqrHWk1UIksaQZxRcF7WVY+iqe5jXWVhcfaDsIswpjevHo5/C7tBkJYvlLn
lRagsSH8SMHIusuHZoeL/tPomF5cseaQhlZr2141WYcGRWEtpu7JLIuXwJev1zrMeO05k+LrDR7b
HALPqGIKOx0bGtms5DV9HIFJk2ojqQqvTUtNm0k5ry9Wxfhy/WZUFpeSOhasLMp3mZSW2pFVUc5d
KtzvUC8aAZ9/E4JZVjvBddN//PD/XkS2c94RRgU0eiQM2wbDaMLnIMRNw/FBts/LCnsAi+SEhuqT
AVMOQZzQEuC4FuVf5XGA8xGzLwaven1Up9+ulJdCEFt1VEQr8dgHzOSlHeZF8wdat5iL8aTvdkqN
fUg/ySWRDaetsyBe8q//qdb8DLkbkNL5HQ33V59dDIbhznGBHmAybHco/XF/1nD2pU/3rT8ReWei
aGunji1ZSWALzesh8Gh8x+Jbr2/DQ0pLxNB3MaC6+BfBe3yVAC3lbXNcfBHwdZNgYNFNnNFxlQ60
YN/iorx8ontWNqlUDZLJxJ6RBsTN1lbj5EgvcYQiB4RShYABG0OSLc+cajcbeXrkDsgLqNF3uDBW
Q8KZJblU+weDEcqFfQuvjQA9GChfmROb0zrOvsOuuceQZzx1nrJgmNidnXjkmsqQ4YLpLfrerDlF
9Y8J/wy6XLzmugrMj/vyxaWeFeSfbTkoMEgKjyAVKpW9TMlJhVgqN3Z+AEUPvb+A9sWPg+Wjwq5T
erdfTnSu2/OKNXjxLcffPqhAVky5IapgdsdinOhdKAXZTy32RZJb9PG9BgUCCUdMLU4/vG3W3QVk
Ii1aAtEbpX4eY+JSYqUEmardmeYXodormGbNkR51dSl03uSdFQHbm4UMbszwkQpN6j/0d7CRu1C7
jqP52ifpZ/YsS/4MJmGeO5OiO7VZggphFrNn6Sz+niUNkThfTVOHu2DNhxxFcMxbuvBJstvtu6E4
PhiFI+o3ionv7K9dX3RJLAOgUEoelpRMqlICo0jx71GwmZ/xaU7uw3JAgO5FvjFYdqqs1hRJEv+T
l9w95Tgzh+any2WkXvH3sJOLvDK6LBqLXPYJAtdeYftNIG+jRrvbSDixF+FerQNu1yXi5Nmra7WV
1HnFmeBbMxDoPDTTLvkGA8mOJEcxldveKLYaFoHammOhvQuv4tfhCKzGFQ36VMcoWclZxDnNj1Qt
YirigkQd58VLOBCe68llUmhf5oLFTNfNx0tJzq6S2N290X61YBCjJVnqHPyZP3xxhfVERvI8SIHU
K716D9d2Wx8D/oeia4I+hOJ2fp1OPOW2ZONB/mvlGX6/miVhVauJYqRMqM6SpEyldHeQvIP+07+/
Dp6Q2ABLLEz0+AHcJGrSdRN0YQ0rQeI3hde1HvyKWjVg0jtlYx7d7Di9OX3Yt4a/GP65hTQr+Avo
rGYWOLxpbUmagmEAGLHMr+zuN/L1j/9TYot/pklJHfT1MR7nlor3HJLf8LbpesYroLEsZQ0OzQMv
GscqlbBxm8TZlJjWtu28Kw3lxefwocs8UshHUwujIyUdjAK9eAywUmlDGkaMhnsG8+OM53sXFNnt
M6bYz0wc2Ta3bTVCNTPzNg5lT+b2ao3hYNozoBaXUYeMYMWppo9tykaqUdgVtrFZ69iFu8hk1Hnh
whjr+q26VJzXLWNeLfRmskwxKhkTWFFX5/37G93hdhV1ACVg+S8h/XgawapuNZMKKNpxl7b88Cio
HLlFutdplo5wHc6Dbu52A5dCL9p1dORylaSNk2BuR6hW+sXBrb5Fz7uiriepiFPJsj/b7AX2K//I
fOv8yIV4OepWJeS6iXICAkAOyarNG7ej3zcDS9DkHfR5YR21eaFWsDeCPM4fxLCgKfnno18YJXVt
h6GJvpT01zI+QAqS9XaMZqvWGTONfz8N1/oX2ydmXe/N5mEjRiVeteusoCvE8n+z/KUua/hw45rZ
b45wOZtG+3S+Vtt5sJBfiPgwhZgtSr5OCgFaloskxrJrCJJX6rjYjkDNH43twOLjcPDYtIB2GGb0
R2FkX6wWxkux8wLAoQMbsvlVJsSAfQtIFJv1mw38e66hST5E1PrD+7gdGwuG1yURRLhPTkM1jyUG
297i0rKQAO6aeAuT/iIKTxoZ4Jg13Of+L3y9zZVHcm/fY5aHAfbzjBjcXa/hOcB1i+vkn03nY/c3
eA7xSpU7vliRzQ9kkhiSdtap4DsXj9hXx5oiICSVD1MQfb1yaJboSoz2HWcfLyFx40J0rfr3nPYn
foS68e/DnL9ni56WQOe7OJ0oZaJEgnW7VPIFQ9dJpJLjKxaBhua29vEtIx6vYRGDfh8BIyDAmPb7
vpejrgDADR7mStudB1FplU2tkZfzJA1S+tHY0Wzxy+cHmUWXNGrqjCgji11Z0QIR1gfgteqZaRWk
99+r2WndAM4wAFenffXkPZ0MRfPdzr4FwPmuLtcFtvQSCVEA/bKELGt7t2NzEecPIWXIarZz7twm
jdkQGgi9JGGN6RxUh0FqafDulJhnBxdpicQ/zJaZ2eD9ectvkodYyYJGZoVGuQIDgab1zwqB/g/Z
RNs8Myfk7zAhAlG2n+kRx1sup/QT9v52exGobmTCbj2t/BRTqM3780UGJvyQlRyH9/1ucCJiT2jH
jnYTmTQ6MVjRAjKWyrSQA4Srqgky5YNxqi/yvjLzEVr3+dM5oXtMV/FZPBdMwKjg