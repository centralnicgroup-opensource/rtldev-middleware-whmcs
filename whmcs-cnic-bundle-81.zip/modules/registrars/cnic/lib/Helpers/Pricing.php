<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPosY8LV/BIUQc8Phj7IujF5+3FdJAZT/Bvgu4ghS6YlqXOTmIG+VCwf+nitla845fVrLsRNu
5U4mquse9oU2XsYtk2wHGCev3zxXvNL8+6Wl94R6eIF8JeVDksglqthl/n7+uE9IOUKmZbzidOcm
CKiqj8j8cZYQYIXxiOJUExL87xGzFR4oOStlZjCZpnK6qRRhaG9lzkq2+AhsdRs8pTJa/FNZsrv4
DeV/Tz5rfOgvUdo0CZc/Dzfzz0ZAHnzAQxVzOkRA1vVVElh13H19FHUREmPlpMLorGXNe6ikLylm
w+PWZNeDLo7PPhH+CIDp35uR6RytjBqzxRRmBN/sBTR+qRhJ+EJadfkXTzpcwDuiCRU4N1o20lNf
dtaD8+3/rIZL5SqAtYRHWVwgYXYB75FXU+QtehLLhRguNi/Nuzad9pdnNjB1rxGIUbFU/f8UUF20
s+9hy6IaSzCEMMVQikhdgnXtCwhbwItmXO1V+Im1Au1qBd5avx/oiKq695AqewVij9FwRYdens8R
sL0px7D8+P23zLPz5dGs5rR/OE85NlOxorZi+VqFAwoUgakHXmGVyjzseeYaaW89sGSG+7EIox2t
nvKo2DS5D0o7884jZlUZRvkHeyzdnOZVCkR7MmHC212Yu260nMd07m3LMV5uuxt6e9fIqvoH59GO
4XJaH1Z7+RpmU5LteUOPBVjOlOZawZ71TXbRnca1bDE3Y8vAMX3hZ6gnxnX2HljBp8apiMUUmQzJ
MLeZrPeCERkDzulpsea60qLkwAizouJ9l4kCVZSne3HxXXGCiAfJSZd7F/LNVhMBsUc1mvJ3J7sy
EcXK9HbwYyivbKzsDE+QZGEBGAi2NIprxVNjoAYJmtUVWLgwpYxrH15tX/ZeJHJYweGaajPmleOx
sfQ4IPfhDsoy5B9mA/m8XHXdwGaAO6NvS/7nR9KX4PLEWmbttO19KnED1z4+AtoVDhqr32A7qNe1
DoA6xY27FpMuNMqvdyv3hhOrOnoB5Oeb90BCqbYQ77oa4UjncYc2ffRIAbJ0VLbFpGr7xy4OYR03
+hUJ5iK2hofsUXInZKusjC3E2/bmP0wiArYOHQh3xKhXYiDBrRcXdxK0/A1tqJHd1DMIS/xBs2aL
C3wze1eweI/dYjWqj0FBm5MUS9T+kSt9oWLP+tbCTHDZL44huOzUda0eQC1b06qQNORzdpDQuKSh
58W6MNrSbogBTEFWQiBHgZwLdg+fFR6w7iyF1jMkd4vVn3YpOWNF9sjf4tjNwZFQI3DskBHWp2wk
mPQHl9+/SoQeEsUNO3/D1TnmQ+6HBkJKjvRZCX2xLmc245TxqS7SIYE6qsAXG/yD9gTXOwFVUXYa
Xr+0WLb2AzV18A2zt1n1dD77+uOY/B5CaVDwWTjGYQxwKaRTJaffVJ7z5eza99Gs7eyBBzQUdRQ+
A4jAgmTpF+bosPfCqHGIna5CGcjUdDBEDZTv/F6hzPrxmltrcHnwweRPQNESv6pjCtu1JhlnBhAD
emYvPeqqhXOErIWo9Nw2qLj+Jb14uxMRbBMoB6TJb0+8GCwOYznM4HttWVlq/Bkr/qb7OyrfmzSc
Aduc/lsUTG3pcbL9Ptp2xL5JPsIyHKRSBL1yz/xVLZlJIG6463b60nJrVkCZuJD6vxp83ICAMyU9
8RZCp5pUzHVEQm5ttLJlnlHNYvGxgxeuVUP8cQCq0fw7s1D6kjMlg+rmdUZLR0MvQ2s/1sawWNHg
zyFNBTynmdpETWF6WmO8jmUVw7GoV8gcGxwzjptIm4XMH7vYunR4UwqYZT1E8F8UDLr+9/B4+fcL
3jKw1Rm2bQh/iZsNR71uv0iBfXVUTxkHuWX5JjQw/t2U4dGCuF+hHQbK+jkNkZW4mZiP59XLPMwJ
I1S9avcrhtHlPM3Y3P2c0qhYkaXL7d4beCNEad6I/xKrxIrDsv9cpBH9tJupRCPN5e61TSI2MT1L
5kmNPvmlmXbZlaLUav3p2TZ3nMfmLqJw6tcpNkx5QNAozqL0G1hEBj+gQPZQe0XPjl2F0sYAFgyl
DT4jte4GVeps6ymXhCkMGGcgo80CG/VerQWfbzWd66IXFJgpNpf+G0grX/bl0CgqFKVpZM07/6r5
hsKZKkJKLllVU3VvyRtSA5s6xXspm2LiDiQw/Lh1JcVrjp9GI0A4thZ452BJsByUi72pHquXIT4l
8AJy6otS59OAVapTNE7lX6dgTsgqY0iWT6BVLSNrnE4UgdFS3/B71f0qwgSlgOlaxraQXVW3GjrK
bigeC0I4JEGx/4avW89Ze2tn4IszHHvlEPB2wwioG5aGvuN7b9Kz+1qF8j00Z6vW98MdyCHTkVsd
NfGtZB+2/VJhz7ue4J9Ntw0I3nmV+qBHUqpe2/+86W5Mkd4BI1u+sV0a2+xp9DIN2Au/PspnqA0E
/TF2K1DcXi8D55JS6V64JCun/5pBsnLM3LFVFO5tOx/BaFVD4Vb0hjTUdgTNsTwEYZ5uVNioCu+Q
hXwualhUERh1VKd5Vqj3J6eByQCO4vn45uR/GEMKHn1+vKHk4rPfvBD76Zf7G+QuVuFQ9psqB0Px
N2W7YEYOGgSLNySJmodU0ZXyEYcJsJiXIFwMuQv9JoEVQqKOk8ygXXQeeKmaXRHPqR0BpGhFIkQw
P5+mppkPkd6NSS6AJndcnqavkuvUU8hJ5TUlIcXoNfwLG0EXm4P3epPfdl1q84doMHhX1V820/H0
MO34visIbe6BFg0cQvy9semkkONoKvJgGJGQTmcuTZIHcBUFK19nQEcyJFCMGKIDLxlsa8aK3o6c
xqoldXsXoxgIzlSZUEMHa4fMsDqK+ZthI3D+bKTJAVPKW68LQ9BfdkKeZDL83sO7xTq7/lQlu+p/
/roWkK2gT3cHNTJP+WV8HsHhdAQTTJZ2q9YGi8on8GZ0Ichm+OWls6Eowo1A4EdbKbafBePDdLUn
n/6WPgMxRSS/ZZzBmfkcXbXfvWdsLAOBbxWdbGa23iP2MKYeAKtleoRHd5eRWWr3BPAWE5S0c02J
L0ERmK/KjfoApB6t1nqcR6thOslpbR35nCseCZ6wIANK2gkcAbGTTc2X1U0Rajc4mOmSui+2x0p2
wHKELN2PSpYLpK2KP4zUixNbe7fD0TpAq0lNnn1jKRciJ+T0Y+7h41pcRu2QeEdi39T2LWgZfsK5
60ap2njy5Qv6WgSeOpNhRP9ghiurkHyxWhAiVstmEQRTTUQhT+7s59cMBAPAhRtVTfeUS8+6duOJ
DHcI6oOnhkmzayzHYHAkD5pc+dBcvjlffNVWjbfRVbgJc7gkVRQ+NV88NN/W4KuRyMMbELOCasq4
CuRJtSsNMNQ7a9SafYSAUg0zWQXoWpBdgyEVpxyJdl1XqC+I8zICD0QbN9Y2Ye9bFVc5CuGE11S/
TC7H59Km/wUfG9bJEWFsiTzMFIFhrIaHJOtTwnq2VKShHoOD7gSUMdQ9VtVZVruRHnaMZopsmUXt
AgV300ikte/11+rdIQQFh8hTX8eP/qSeR5vKSN+pwXvurW65DunL1aVXRFnj8VTEgf0v0TbfgEWk
bh7Qfx8P9G6nJIG8/VigS/AtaRXyg1L9MYKjdVPrnCb+2dGdBy6QEUZLECFGZ4YodDuMmsCDRAoJ
zdwEvhMVtQAC7tIThUuOcZXnySeZcQQzKZjWXo8ZRDipgx+BBHVAuN4B2eIaVH7iIIqIXlStUnf0
g5iMzxPVoPJpDNmDsEFQO9RuL1EZmMh5/qLJnIlgbbfiOm281LbHtfI5JOoNsbi9Vu3T1TxvNMgK
D3u7BzX1N+0BNdJ9maRSO2RTNMHalsG1iG3A1oWts1JVJidUYQn563J0k0iQQcVCht6zdJXTca55
TdoG/UcfvvIT1S1mTuzJrEVOEsHvKHylAtBBJTahlwLP01J6rhqRlzB9eDI/N1WSKZ96Ga76c32j
ihb7+JQmbNNUu2+en7G730hUuZcDzQURfJs9XR/B2AmnkQO5mOqJz2eoO44JDRkvpQPM87xIs9ic
R4X80v7Aixu1iustH6Mv5D+5WlcUDPfu4QXjVdjaAhkY8X3Q1QHBoIdhqMxvLS5MYsGLZ0szTNzb
YtqPL9vCClphb9vrtHTFerF9N8pPSCZyd5LmLQ3nCLbRbfoUcAU+Vffs0ugVr8eSgv0e8J4+fFA/
x888VP7k5aIwkjtWbV6CXq0YyzmlNv37KsRWXStONGvlRWUqFsiNkMQxE/ShxTVRPPiqUmdh7jb7
RK4/QJPyE77Cx7De6YvIM/oTAZrdQlU87oVf8XZx9uRXB1B/LvigXaB3+l8pAs2IR+SfD68azdhh
Zpj9dZPtw+NlyBGCigV/Qk7Jzm==