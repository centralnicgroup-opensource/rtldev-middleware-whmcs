<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyZK4OXOTEgl9Hg4gmzv4kv86dMAVwBdQi10usVQ6hHcBchF0yWx8Scb/W77wcFIu4sOfA2z
swmeD2ty+3gRByyssS9kpiFxGQPs6E0BBRQIx0cJfkiHI6Dy5eTtzgDVTyp5A9gSuQVeOSYNUQeW
y8WZqd3pGs/8HBaw5VXd2D9fJm3SGJ9hnR7zgf5d1Nof07scpBnIK6yjn4jZq7CxUQuM3y+3vMe4
mEJoqOv6C1eTnstcSEWS0tysCrYFbxvNjqQml6BcoWUNtphwmGqGIJqNcpkLQlWWK0PZLRFNko6R
0DM74L6hUirIRHU98S6+DIHuyneNENs/TY/JZ6DFMaHOS53Y/O07PDhQ9PDn69T0zvpQscszHnny
42iiQi9Xa6eGodNu1ylVTTM6Ga20kP2OT/4mLeAHw5eW0Am7Uz/JFQvuinsTj/MBtF4OrKqjqIDn
v/KhIa5W/4sQFpek0OlvdFUP8suMXtv73pjtNrfrfqXfNmByrdwkXFtTwni3pLT4xeANYetonAFI
PPf+4bss/vLsUedVvmHF4r22wCy08lnpMQ952dv9+VQOc45AIdX1I0B+Te+6H2pVRjCcb0VrZ6qq
bFz5luy0TQ6+soqsNpDL3bJj8JLkVAmXFnyIKbkEHtcHNYyai1gjyqSW6xeU9ty8twn4dHw27E4q
H7Mpwc/W8y+XMhqenu3VHiZMXSljwMdRF+Avoxt5JoNypvK0VAU5AtRyChjyvnAiAvH3p6JML3x2
d1pSd/E6P5vMUXzfwjNn5cJvFKPSz+jb1uQk54d/XDnotm/JtEnTNaQ0SFQNftzT+lqqmeXCmU2/
TICa4TxZ/+kRTebH09HkaVyc72egde9dr2TogXswADeZfNfPjmTrjFGMJjFhLXTVBhwjfKnAfH+k
/Skbvs5TlqM3nIXftl1FYJCclkvJdBqkWP80tv1ZwiAC+dL2Pl4LW2uQ6Mm10uOXYI5u6MMp0Alp
rfoHDWiKlVgT3K7wxvYwNUZpX6SO73tOpSBufFj4Gm20ypXOjpVHiUpdnXRU9D6cX+YOO1xYOTc6
pbVBDr+PdaBzDTwm30UEaYYqqIVC4fVrZsRryypDNLG9aPSfvUyuK6rveVBkKe3eIr24qKE5fzNQ
K8ik8Fx96IwRO3ErZqrIdD1dMdykVgYDv5MnyCKRdgDarYU9O/Za22o+Qgh40DKED7igzr3jus0m
5swd011ZoX8uBOZ0B6AFskSMBe8uNwPN2LPdJQc/LWcFPa5smkebY1VsgFwhiQ93c8hr+0DIzFSw
50Ldmk+p5hHx9Mm2mrvDctZ/j2zhy5p/FXQOVPvZUAfliCGqFWvKPkXUgIxCcEv9XcXjRW9cNGdk
WAFSW4w7BTyN3VyVl6vR0dobvENNq9CAT+DWeJ+cmE6YZKerx51pgwpynPTsaB4mYjfvigk5XUmH
nwbVMwaieSqtmfNkVdtSS2t9vAliBiyZpNr2IJN38Vh/q+zsP4+EYYD7WZzTc6xTRCDMPzX7OYy1
3tukV6mQ9HJr7NKXaknVR0OJjwBtggntj+B+nhW6olLLGaLhXQimNhsIJPIthBxpxVYaj3qV1GO+
6M7zqBzNqTLAqffrpjtcN+qt2X9v3nxrLC5dpjedcwYO/Hy3jYHkyB02yaKAhfn+puSkC9ICZdFT
jC0lqvHAFpg5XpWKgoaq57Qjoep+YJ0lvKitOWYjbPCGFsnn988qClOUvdPMRc6dsoQQjNjyiaBL
WAfGKw4DT6OAZ3Gqptha9TEku8lRwJBftvZR/gULrcbhDYL88XisPke3tnasqFSqB14llXcJgykt
MwGA56jlO8gmn8GOynTsHvWb/LQXpCkX+pTMo6YkxQEHzWgcSOj67QDv5z8NtSN921IxKfQgItYt
IKbPor3HPDglRRYaxb1Gpt1KPI93ev9wQhYYzmzQO4TtZJzZn3z1dxBQ63smDQAa4Z6nsedmihjp
kcVODLnctWGJDdUNeEPwvzBtue82rGeI+P3YoMoAjyXqbSpgY/EyjS0nz2dmVnOD0YTKCTprVNMx
bQe4Th+w0jvWPnbSVTerRsLOXBBpTefbi/R1PaRcni36AzsWBYJyecSvXjrKQRFcewfYhLmoNf0D
CykWPPrax3QkW7+LUNrHTh8guyxGN/lTsuzSl1enFHBQzUTsyLuTJB/GZRZzuSbETibbJCcrb0gK
pyPjydPEzS24Rt28VKV/lEnHL08EnkMyRcyNLHwymB9Fpg0Vvq/0+Tg31Te7lReDT7lDMVJTQg3Y
Hojzj0kwLRQYaVrglFbLgb3N/jZdnJzi1Y6itI3T2AlandAgFgga4kXchshk6ns9ezOAGRRWjtae
3w8GAd7oa2CNqSylmuAoycj6iQcINhU+ow3sA1ElieGoNqp/eKHX5LifXAsFI6D7PyUuOSa0L4iI
LwmZfmBmMuN/XpRzhN1vdjf+TNpEvZO0ZxDPyC32PEYro7gdaCxmO9KVIB00IQsVyd1Z9LO5bEPW
oU56Giq/pmJ4q7GHcB9rIZv94Mk8fYFesOfdREz5CfERw8DFx4Dtf5c8uawsOvrvbn5NFR3gGrPD
Tb9t1f8OGqz9rnbY+qu32Gkv4NXg81X/CRIZnbzbxgEBOe0QGspmZmhZe4y14fD9tQdJrkmgsRrd
jAGUITAXvFBNn26fzvjfLos71zvnYO0vyUp5K0rjtwVr3cWAq9rOq4aWeGgto4mtagtpStap2ix2
zS0mc2uMNplAP6gEPsIbwY4zI6J0lbgh96A1U+zx4X4LCAq64F+Bz8wAGXKdeBSBpmaPcf5FoyoA
sknFCGI7hCX/o9+K8AVGaltLKCW4UbsdWVnfWyUGmqXzhi2Xj/eeHF+ZByQVSxaicAwCD5Sfj/ZD
sVtSR+AwbEipnoK7LLyA4t2QXVaV0lh34ElZBO3eGnAcLV3QgixHoeu2L1UbJFubc6MkSD057MZC
2hN1RsGeRL2dZ2gpw4wT3H+ASpe/uVna8VDpmtlcT77oeblo9Fv/81iqsE0wcvSLl0LLgypUTB0a
KNlVU8/nxN0DBu3X61j8cCvQDSyLXaCrUV35JhR9NG0JwfOJGzk7+2baQggDAQZkwckmou5/WTBw
ysEnfDPhf5T837AGupOJhGu8NyjjGgv19jX7OEdMCqCARP5aCRUC48/K6H7wVC3YmG9VMLMvPt6E
3EvuUjZTJT0mVJOwSg5i4tqZMBIe5ZWoMlS4vbpknW0q/6+xVLUXtm==