<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqmiizMXl0SQlE8czYKrjAZRqaZEwTWo/kvOFcYxgQkEIG3ghhOb6OaAua0a1OjDmZF1EK9a
1A/NFHGW38STdV5WP1iu5wYGleWqi74fUVap8LvBfyqf+vXPLOSWwdc1ceU5buM6NAoLOB880ZsP
e3A8CQPVH63pSTOo29omFtc6DJlP/bKfBglvanAhxuXHkeHreimSDmSzuNX9wRUJRT2gG1Ufs8Nt
hXGnyFK9XcXCz99AGZfVBdrRWkABbWWA3ZqbI/5vHRoftSJdtLzP32D7gP0LP1ARReZlbNdRXbnf
TfQe9rYl8fZrNZdX9qgW6Xcqv8PqTYwko1ZevzoSK1tO5Gzvft2O4FyjkWhjCJwLzLlPlQYuamlp
9WxsCqDALZIMsnpY2kTljbHGdpOb3TdN/odoMjR4zUEDLWtZXsLJ9/yTlfhPRC+GtcuNqbMRLqKP
XfcuJfTJC0QlyCh5MJKgpyCMbx9Vi9DjBdw2IABogCSkH8HcowdtNI3cOJ/SNFxA2TRrnahRYRUY
e8lGN5nVNp6GtClheQEzD4+qCS6N5mGlKi/ZpOm1WONjM9DbVmAHMNPLH8cHXXPjOLubHxqVaIkD
y/JRZOxZTeMD2010WfxeDVXZyHK3m8c+cHUoxl5Lrcux3hDUBTXrB1+csZM6RHl4NzhBEZz3VH1k
XVLY8TalcA7dTe6Ou1i9LkgwI2Hew3kN+qNWbRil1+pxC0/8L7IFwIHCSElRW8/RPv78X0L+tcAW
QLyQo5jkxyvt+guiEl6W2zKcf6otrEkqXDSjgRzXSVYMeurIcsDmUCxEU4vJjsdCtxYtLAPdRxrQ
nkMzweHxMtt4P/5ONxLEUtklKJg+HW1VEtjSu/cMsBkeS4VNppUXH/FcUhUBc9FCLfl4aVxIcDtJ
Z4K47L/lUSeiGXkU9O5TA7J+D61PO639ZHdqI7Gqv12+Hm3w9/1oY6jQ28w/nM9I6hH9Ykwp/+1F
O59O2kHgmmN2YSlEUWpHw1NS1bF/dHP4SJXjYPesigKhUmskTEEaX4EnKmGEzjESMqsq0TJp4Cq/
YFoS2pbD1NsvKBluSSictoBWMxGfSn0VQq2V7vmw74kpciWDV9mJrHMer/1evGgpaLkIn+JT8ra9
sfoAgMGQh/n+NGATdtqt2MEYAz5p7fdn0LZJW3fYcEVhDphYdTRiRWvGNQ5xgFZnz4dRyCMe6JBc
ODnk9SGjFei7308M+XXQn90vQR4N7sBk+q4xoO4ATrbFMbpDvK8z/WESXlNyHTGEcy087JaIvoMJ
PHX2zBQNWZWH+upgsfe6wXP+qJi9s908QJhta0NYcgfFIzobXgb05Xly4IqENwTS5S1KBsD335DQ
dGhpFdwPPgsrCkRoGkqBc/eQ4F5rINc4XQ7zJ1wraQaPAj+kHS5lvk6tU4aGjONngI7jLHPAuC8D
T5ukdt8+AQL86lqM6WfDTcQnC3YQHX45pyQVaGIn9BPuElU+Pl/tgV33ptC+fLIuJn1zJWQxSd55
RwBwYIzHciEKUaq2+kV3PhHHcnVix8e7XD+T9TAbZMAkMikaKecNpYVvFkYyLs6rZ5SGZscD8dLw
s9t7nyE03Pn+8/WRgjcLuGOZ5BjBPa3MKddgB8cKVvPvPSiXT/6Z+HWGYtLePkGojsBx61k6Vm8Q
i1BuY8Wbvb2TKvBNN8Ywkflo8BeuycamDaCG/tIrpV7o1gyr/Ec5yMGja1xZYOYVeez1gRXcVu/m
tximg8AuJ+cCiQZ0uM+qaWr/cknfzzn3j7V9WVgW0fAuQACrQgcwf9Ub9YWtuiq4+w90nDW+q1a5
GYXGYXQlHi0D0o/rBRbc+/COmb/6kAgpJWuMY8bLjq9eKoFBz9aSReL5pHc49EfcyjndHzJmEnjM
I4mzHmc6H6RvZ3ZS7NAs/t7hU6ZYvhyv5p+SQDcGjnEF/Spb0Ym4Z088W4upEBlSTyjRsGlRNYNx
2pwGxBQjehrekW53c4JLbccU2yAFOu9uo+HestzzPb9gbSdZ2/KN+GHtnj241wTUNgWe/hUH5pN/
FPWpcyxXhAKi6LgjTIjH0URm6EI4RiGnhpVMrv3+64N8JLTAqeiNKtFQsoVe1Mh6I8kFU1fUuKX6
n2sp3OanzAQX5pZJ21GIAVnq3zH6abnaBXWtxNtBY+wi5aZQFObk0FzoKagilTSNGdcgzvweu+hn
mmTtAH5oQncffMazKdiAtC433ijmQuHMYnJ4w/tmnGNX78LyHd8wzA66xU9hNOge288bQ/BX4MfP
qdog1FBYDNw+OST5Gg6u9gee15mbp/UsSztVawS/H5gaBXa7wRrJEOJGf3zz7B8Pk6UE8V6NWwXY
J7TM1/Xlie91unTWtavpdeFgFq91FTzs2IaFOF/3Vu4RgOviXgCv60woJwFWdlZX4hUGuWziCtmK
xol70b8H3WqoI6QhXjON3gWztR49cmjveXnnJSBkPmMPcOpZIbqA3BNJJpEeTuWRwncLB2PfEjiW
bLYgzdmEsDvXhq+kq/CQJ41BpS476+D4GKI13nOkR/tWEHc0tycH6P9B6WVylEpKuRCusW2H/iEJ
TWDF7fCtRtSTZZ8uMQV3G0M9P99slgM/7i37NxzHAOC1SzTr4OhLMTrZDK6Q//+8duqdl0hWV1Pd
IitHu1IEcNSBpn+AsGidTAt2t5ph5vjYuGlYh9L5rTyhje+53S4XHIk7+j3XolX9RyEZWbrR54Xr
/sBnCELjZoq1bgE8R982l97HN8MM0JvMyeeLBZNTTWmJh44zMh4F1f0INjn6sKpLHN4mBRgXp8dR
aId/bz3z2QFI0ztXSWe4UAGzYMF1wtL1ELqJQEtTdgJn4MgGs9SDkoMYCS9xd+Yd7vARfGUmTzTU
6/QmVxA8o2Ylwzhx+/oe2At29jAL9sdnucZ6A1nmOQ/WymRnBGO5x2hpqO+GRxCC/3Eljrl5oKYC
whMIpiEyXXJWoKqBQ/HA9EkrwEdIUJxMiK5h6erHnLMNNTwlLFzcL/2tRD/AiMNWzzpgeNLuiD3U
TeMLTuF96SHh808QS98WpETh/6OKkzZB5GrSAICcY7lP9odvJqkTMdi/95qa/xHJVTS5yIWceIjQ
wM5q6DlCq+Lyp8U3lrGU2bwZMfj1TxEHG24MUOZsAc+UT5CEbt9AyAs0mxGYb8XP9e25w6gkL9VY
dExJfh84hAf3Hnh4z6y3AokehFRV7BlF9nLQSYMBe7H7jmW=