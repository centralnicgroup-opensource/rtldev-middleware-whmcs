<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoeJ3aY2i/9lMzwRQwVsI0x2k9Kd7ixopTCVtUvcyJigk/ADwnx/FsLV/1YMckXKlNnOxvcI
w/HbLvwONbbcuPh7kebKG1R2cOzfsx6NH2q6ugF0KjaA50guMJOhrG1zv/wiXw0RzVyUEYaCG0Dk
HBWcroF/udrcyZy7wMPP1j8m0KIdCWoSP41qisJTc+ZpY6DVWjM+aWbK9D5uJ81ysGZdec2XYCWv
85dFd7UoLh1Tw0+GDSBSb8Ux75fHJd88RkWl6oV2MYo+k+bf68TSJ+ElcGyrQMNeeuA+zsf7Z2D5
zd48GARvM1CmJ5ydBE7FMfS/OcIJ59zyAq7g9gjdBj6+sSys6iabh4JSYlQX9eIPNbsdbgkLfu7l
a1E7QLnhxnTjmRRnnsGmuL+X3/ymEMx/MNzLFdkHJEIU7SI2WHx0oWUKsQ4/Y0wLpIObPzr2bHkG
jQ9/DGHCiEsF5dfhykBDcO9RjS7t4erWzm6wLmjG8iH0qqFPZLNmipCNRsmEBJQoZUTPlA0hE/b6
W4yNGFmKLGuw7WygpPEscgwFFKbtRKYErZ8pAQ8NTkKUn0ckXQYZ3ciiy2LoYcJS6cfcDcrIE5kL
ypBdSkUifKPwlrINyYaN0EQsInvRVG9iRdeWk9R+S3CltEtgM+TZCPht5xwObOND0EhzhD2pBHZM
7Ed4KeDWUJKuyCDZZnzjqXwE21KHNec/XdpqPABjgew3jmbpy0/4WjEkK/nva9EETxhmiIl+K7gf
D9oYtEMJw9KXTYcCJd3vkHOVEbDALY3HJ3OatGmU9+udXYIJK6ZU3sQ1usfQEVNXkbPhw5etaMnR
QrLJCE3Ei72sS+t5HQDBQPXbdL6JEdGTKrWvo5F+hgXgz0N99eazPYOPQT3ne1WVRiPYgRrpFGN+
KVF4H+UDzLEfcaJJdciPGwi6ZDlHU8OXMmEasMsRg18kKgGCmd63dxDEetiEUagod3fJgd/vmazm
PULdfW/cFS0IYVGJLnbmKE5ABRnBN6waWo3YqU6epVwVoLAI36/+DPTm9qTv4zYdDKb0ZA1eQ84O
B/E4BrS92BdKrmGdRHG5o+Og+GtdiThMR6+RZwCcETJI9E9QJmjswhVCkeiAVY6jBrO3ZznlqQvn
U4WBYNHoSF08wQgfv7UxIEqd/1CY/zFaRMDpR/pwzQ04W8rLOP/Ms1cDX4ZmgdoWom43adKC18rl
faflIhsRYbFrZMKc/vy5c8QECtTQHqN/v11bzwxHRmGbZvCYinOC4u0iDeGnDpxx0uiRt9zAJviZ
P5IP6uMcmDAXB5CsarwZL3TUBrZCBB600vlH2HalK25GNY8402JXrn6NOn0rwIxRdM034Q7V75RK
FPwMO9HsWEiC6vIU7cDg0EFT4R2qQeTRqFy8389i36pCFhS8PljaWsUo2a/5ezV7xxb6wT04TDNF
PiMZny62CX3N7MiTuyWDYsH/cT03JcvTdBE/TPo1HQYKskvNPIv/nchVPn2T+HPtLvzM0GbCGCmT
ezblXFJIwjTPnF6Howvb57y7LE2SHNVMBV7S37S8nTeR+p4G6f/KePxBT20vhuz64Opd66+DaS/P
7xImbqwjKc47yztfrenloLI9/pkG/Xl30G1c36CZ7MTZfdt0kyawbVu8zDi2+0hGCap5bO2B19B8
z54ea682cK+T32oiAinKfDvdWRq0EKFOeQVJ1WXm/qO2QFJyc2AzXgAw9KuznLODT7KQ4rRgpG6J
SrhZjx/f2rrdogDidcMwbMNLBkMPMm/kRfyx9mc6A5B4TRs84cDcUmOUMH1l4CKTPCRWuynEyQrv
WyYsZKQ9rA04qKJRlVxWkFvgnIMYBovsOMuUjabgUkjx7vCzh3Aiz3Pu9JNk+m49peOkjxhYajkB
rtLHdfLRZ+SYWKFkIOk8WNkf0OLyB0Sic8Av2J/y0wq3ujDpsQVyJubF28BB06wzzH8uDTvm03Pf
FkGot1UOWPYtZO6ob3KQhgKzgXMZctXqwpk2JArEmmubNO501qrroMXVv8NbBj8GYkwQHf2c0vta
HNxNrPm1M/GWNBrTYIxlwDDW9wQYKPjyUTAIPr1Az1mrJGSSpDYLbLHKAT/hHiRQHiRhZLr08eiW
8SAnbJQKH5OxRQtLSb+zlQo5FUWW/8FXHAnKiUv31Jq+mL42rR53ZEOPBUwh8DGoerhNCReYQxpx
jczBDJkkoCIaLLGSfEgGAto1JMWUicBHHce5yTrSNduDpmU65wuHWcbPM6U2BhlQbhr6PNa5ukli
rAkV5VafCWgi5q58s8cgFw7m0cCTImOx9QTKKfL+TKKSpkyWiW+rHTqJ5HXG6CIUJpedMv92f7Dg
Wkh1jFxiJsfNZTdvO/GE5MtZ10bwHXieLMuQYTUyX07M8l/29fLAjopRpnAKwvc1xJtnZ4ckBgKi
zORkM0RFkSXgPz0KSnhvEBl+OuqwUZ2ebKys2N0q7aONZBa0AP/M/cpTlv5SkhRDOZUr6ujg0fgw
4knoejryR/vxrm/9K/NxEuEDpY8x5mMtjKYJIPMXbtK3MGQj0mtJa8pIC9Ek3EO4xe6bzeEaaAsv
W6Fq+hVOQjML3QZAW20U84LlxpbK7sqY5geT7wBSUcxX8+XdH3wAtGt1Jqh6tESohCMdUr8KrShk
FQ73gjFsTRMpLLZQLsEhMkWnoqfsZTsaj+Y5WjGObUe7ld82O0gLhEx21b/xYggftRzbXmUwWp4r
kXpt9cOC1Ryfxkr/Z1We9EvcdM7l0f0aisKkDPtGZcR0rH9qS/ULzUmkN8gjowFx3RHIauYp6Ywb
PiZrKtRTXNwCwCYLwZ2uWfgDJ/7MkjMwVZauCbGol6c8tdnMlXMtf5ginl16sdj/YsijzQriv8hB
K5f4kFYA3PIZZ/vEYEGzWehR8nDCJdKYofT/mdiFKYXTr0yuU7dCYQFJ1eZ/Rxq3o0GPlSkN+sSd
7F2xBFYTnqNmAQgE0U3FXZ275o/I20GYUrntmX/BVL9RfSccgf2I/6EYjKjInikmAsuD7PTboQik
PTCV3tiFBj1VInOK45g22u2tEUzztG==