<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtbRYvrv273I19OUlf1IWik7MPQdMPNdFOEuKWYQkBqL9YA4MantUzrirXInyrXz8luCs6dG
cY5qe1+9UFtyflrRxtP1zhGUKYc5ypPZYAO5w4cBn96S9O3ILW8o12ZPoQkiJZw+Yj+a7QJaJckt
fu0LJz4Swuorn4FWKJbYDjjg6j3JPRgmZifS0qzGz1DFfRmPNsuWXWEiHpFxKQBESViZw/ja2tD2
hoKRAvleUiV5dD9UovxSUIk58a8DaKNbL1cEuILhBD7UNf/cc619hc27+fHekDPUBDaHpUW/8NcW
GISDU3VNqXQN/RQSdgXAuEQuGc5xtW+KLrAE6yJoNjGGSXGRYqwb/Iv1yIOCoQ4CS22OR8xAHSD/
IarAL3r4zSUbTTJL2p8VpPUjqGqp6xY4wbOo8gpGMAKbEur+FSrWtLETvphZ4qa7/gVHbvMuVJkZ
cgmT7kX4OWu60eqNUOOhq93HExjB4Bq8/BINQSrXLSFHHE5P8loRWY6PQ7p63WTGFknR6bS0Yd+7
sP7OV1gnJdJGuWgj15/ys0tsiitK3m1n1GeTe9N5TZfklMvrVyGbwl6xTQMpg7DMH1QAa66y1S2T
Vlckr/HKQ+7lkcxGCk3MPVJHQFfk908AnF6X3MUCC+F0dKC7dz0/Z7NteuFL1gKR9oJJVjUoq/dw
5TPEolH7ljXoOAujeMyz7HblhFYGv+ez01j7i9erriaguwZIAW+99EYMJr7XtO7iUnl6/eisFV/8
lM83MDB5oB6K/xHiG2Dh9cqYkmavH7GZmshsYm0GHo/ibGVjxnuoGhQjiXARXniPrxpDbHBRUXqN
+nLjD1hIU0O+ZfM98y1NcBm0tIgcq27fj3JDrxGgaiLhXPSoxnrtQkM6emPHDY1XCMQNsQtepzAr
38X0/JTF0Sk47EGFTwhWOYTjVnDa8JrD0mNmC2z2lJDMo+2qmL2gank/GPnORSgtaUfVfLcAYfhX
XTE1pzeKICQRa/DBAFy4at9i7bibCFbwjULSYmCEoNjq/RVViDJs2xtcXvZF+XpxpoSaojFUu1zr
xm3jxODNIXD6d4GCu0slpFFYmUO33Mi7FUf9+N78gb1Sx8QuTvdsmznAtlg7zjvNd/qxgGzPOBzb
Ef1bJ4s3Fi5JtDh37ELUS5htn2pDsmgts76uqv66R4wGGKgo/P8K8fsOa4CH08mIDCTW6rmO+4nw
e3IyUBKRoNcsxuSjwz5cuJVjU4AbhNdUE6rH3MC7QnDAeOqnFLu0Lm5+J+QmMU7KS32HuI705snP
JUoQs/sF0eqKhv4ovJ9+n8NFkM9k4XwuTgTnHqhazgMG3UpSgBBciNaKTdc6qhyBwNtfLyjmQKeA
ufuFRhy3U1yRFhx4QEGm8cT2UZGvAFpYyVXGlRN2FPNChl1VB27uk3XdGSz5V2jX+aChO/apYd4A
bRNUApVd12PYicHWwi/HHkJ2eMKRFuXGRUZzVwouM8a4orMtaIdgmjMOkJA4FlEKPYGOT466zXcv
LoYMAmVWzgAr9914rHJn9+zAXDSxIx1TURO2yMdN96lcfK0+Ert7pDpjnsvH/65qK8acmilGSS99
ZEGlnMR1/OorOVViPNLDg49ByyOz5VxjlluonbEagS/ryTq58sy1DPiYDYEAooFUKohyxdOwMri3
MriPC1+aIOV4W99t5fDtJbUwjcHvmonNIi9QK+tCxKHURvP49fp3TygpGyASzuz+m6W20TMOCU1T
Xt0Qm6Rbi3IFfQKYv1HaQcKcKItD3S2t6XSQtULQYrd1K6MLs97yXvQilq0Guh76tdx4MPqNZA5j
ddJMoVoOL9CbBqZb0Z+Jw8OnlKhoKdcmTXZyqQYvfqLVF/d3jnoEou5y4amVShHoyoerBLg1bj38
P9YF2GUiUjqv3x1Nt85ZHIGrgOyUx9AuucnLCW/pish5+04dl2//UIILeaagysaPDCdrtKvdEThU
xIlZ/kGGdvqY1Q+EBTORxrJiKBEPEIUzba8PUprE+75/2utfYWIwbq1UvPFLZNTh20YeEXcriWWI
OV/5K8lBN/jzAGIVPWC7lCphZYwspbpdmxeexxifARpvbq1k0tHOcxMb9brEPm7ZVSfg6oGqjyRJ
BtvLnt9sJklZI1xvkwl4S9RSL+v4qFQWMHUvWzbMZe8ErphYpTFEc4b1uMsTJ5xZVUwzAfhFDLl0
Nn9OIRHVEUdhmCs84AnEHhJnyV38XV/kezYxVTobRmQ1+1XNbTmev06ltPwmsC3iuMzQY/USXWXN
FtaeGhvW0uxlbjKPe/BuIauf4cB9GoxQV/TAE9blvEAIuwq7GfAkl8qVYcVf0dCkSajVhvpSd8mB
ijjulox0RVnLaSqoOxRre4sVMMoREqOgIio6SNHd/mWcLQXy0oQ3oobagh05rLNl943KXtLv6Wtq
pUVogEdoLEvZLkCadeFwQ4jZa4RZN6qs3jcqXjLbUWXC33v79XiC90/yJldi//2OuxPDFabrc/Yb
n/zpaPOcV+xbGwAKieZDnU8gLsk5FhALubwZjAhWxbKXPi2vIEYRn/x8qkiHQIn4Ln9F6rjhhoRa
V2z7EHAAVd0ljuI6/POZJ2cLr2inGH6OXpBqwqxoWlCpjFSEpNMvP1sBUdUyXDzI13uXxQqDzvga
V5HiCASfLYb4yNc/C7KrwCX2QrwKPMBCn3yzKhBBB8BYT7qdmx9lcPI1CHoJr92oEAeMntW6nVOu
ObTxXQD/sfvXVw1IftRQgPsREnl3bT+5d5SNMy20Ft2PAnVvxXT1ePkMMh/bbMQdbf62/6u4E3Zt
YNgjyLxz1JtJL42P+vMlzQ0MU8NwBPiBkk5HMsDVXtX3QwKwv9JGzkUf4P9ZmbY+4LsBsN4WgogD
MvwpbZeO6HDxVluzbwyIPrwr4POE8Blohjw0iRc+C7VXz1OsZ6Dh9VOP+Tmh/VEtVlfi6vJP5nLJ
Myq2z0Uz/uQpl4xNa+7+bH/dFZeaYFND+eRjDWjgs5CDYmdBPmDLcLUc+pP+yIe8onCzfg2wA6O3
vw0LTqIWmn9Fz0==