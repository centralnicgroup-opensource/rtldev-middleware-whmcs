<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPq8MRKKOjrLhvTluPjMKcQS94nNu+FvKSxEuDDsSaZatvdR3PvNiapKijtpx/iqbA9bN+4lt
z9xPbfrIvmgVwyuwDQpEGOCwe6p7mjcJOEjwbDQ4/7yXr9UE2uj/5C7LeBdeBMF3WP1jMpWJluto
EH4MuLAgvluk4X84iQp+LF1ktOGzUdKlBWnEaTz9nwA51LMqRwZ0O7DTye+nC39SS4RpYt9Yx8kU
zkQ/mwG0axbdXlHEo+gzD85Fmvlq98EkPiKYuILhBD7UNf/cc619hc27+d5nGi9RfmnCP75jdtcG
w2SX/+EBCHc/JVOQ15J1EeXpSncx/7sYxopsmzqbaRXIuBjS4PQkEe0C+SUUAsfDx7/cLhvgXUqe
oUEe/aKc+I63a17SV03Ou4pL2ML4XbR8LyuTPywdjFBF34ZFm7Y8kyPYasj0Lo2WySoAUEKXQv5n
4S9KbvBKBdVnR11vSGPvrECW9sM5SBqYJfiSb+MkO782hX0UwqNRRnQvbbQmuuQFanI71qjRG3Xf
wlz4mvcOdkfjJdx19mYIdOFjf8whhP/DRzAdCYf+Sb6p5LUkoTGlWMNEewrVkaR5EoLATtY8aecn
Bt2+AvgXElImCHezLQusSZ71x9pOSabJNjIMnpOCjNyGKnwz1XBDE8t7taii2Eaxd9/HAEuk0ckA
BxNva+96dti0Y0++lW8wxS1A0SYzf84nEciVr/JF6qIXoo17XV/Fv2TYjuMPrcpakjs8xn/VVoQa
xMLB4UyQLvZaOsm00WIfuU9V1HuaOE5jK8rpzU+Sdum+Ywk2u+c2XS5AlSuuqJCAmi6GvACzTeAL
AzEQcxP6Qj6Eyn0V5EAs0quvIl5+SFKF9Z9jEhKfEkBqKjlnQtlRdAZWFw7K+KnvIF+DH5bEbFZW
ZTAZ1Ro92VgKoA0Vxus/h7wnHx1kbd0oJMGAt4T2FU2EiUVfjqIqbEhOdF2dZ40Sur9cc01WJ6td
Y3KLWaNzOlz8L+N9+fIxSy8KkD2pt193svTqXRJbM+eh9WCOSi/Zz9axLRwOr0sZORVJM/2s6/u8
axZupHC/oIrr2NN4UlDYyKKgQyXfzVlDz+m/pjCw8r5uhKW86j1lccScluzh2s2cXkUt2s64iL5I
efZVHvgklvuvUXfLxnZHqJV2Dsmr4gK/5cFwjUzM6pughS1vzOYKrnwVo7E2TKJ5AbHdGSBJdJJk
v01ouJlnbLFamJvu3j/2pnz/qtPjho/bZVBr4MoYA5NgUobSoqTvkpE2Tth9BF62KOMGHRoMHnlu
eXJQVeSbut00pYizSc67PDDcuiATmRO3M9GHNOyltyvbCbPSas5gqfoyaP20dI3ZVRo3P6Z03sB8
E5zD6h0IhZOGvEM4bYoqis8/ReGpl87j/fCSH6qUNbTBhSDOxWsgXFytpa8wEHp/GTQzaWajtRZk
WvjLFmP9pmliDOuitl53DxECUo2iFjn30WPE/C5OkkIDBqGGKr/z7zeoxU9yuFNJrV+898vuEugV
3O2WD4wbl1l1kaEpVPnYDciO5T79mNjtPyh6mmxcpiY94G5at34B0hN/nWcBFGr4MnWajWOIN6Fr
P+5Eswl1vrqas4ftbcdBiaWbFO0aEcBAsd9zd5l80ZaZqp2NhEoAo2iPpLkOwn/Eudbfb4b/iY15
4hGApD7lEU886L77dLba+FsTewYLVcO3uAxvjeqFTRGOefufDPZ3Ef6abxQHQr95M/ZteymDa66I
6mzJu0sSQTyC88p+iqixlL9xkHV0pDzJRBf7ZLxg9KvDm6kQA4VPi6oZX82gn2UGc3AO7qIuufYh
dS5YfLNX8z+WqY6FgpLPCbsWjGPJBZrnvfC7hhId5kGLZq75VsOjxdyr6jc4aZimP5f6YHvuOvNB
a55RuPYl/ai8tzV0tbtDu7HKUm4JmR6eEYIt4BnXeL08eyglHfC5K95X0JVDiTLNWkdrDBF8gEjx
Ujc7s+vnG4ZVePeDlHocXw/4BqQ2inER9nU7iCa8P3bqtRQRvEBzATYCS/ylySDRYxqQv2Y032aP
jKG8oxjNEK4n4aCGbMfSxANAHUlcpeU/3UIQ4je0YPNBfD1kELE215mK1N8KO+EelTZvm8nEloAn
y7Wt6vGARX5GE523Ye2kLHPtUA4BnUIGQ04BCCtCMJ5lcEmzW2Q8cWp6xe/gTBeNeFekrjg22NHj
I6HrgUBKg+VHdBt1KtlYAbGoh/hJ09LPEDmBLc82Ufxnb6+PW7juc6B59DYaH/7LWCnOGMFtVVaN
1E3QHkq6b4URPAewIIoUUR9Vbv2za0JBYOOIK3Z8bAc9tWwqzinJsEt8KKDGIYVko8dpBHdeUABl
PAg2xoVMH2JiKeDcts54XTqJD7xgHr09WZiindSx8+zP6Xk8czci6D2QbdLnYoAOK5zCGnGAqV7S
4GraqONZHvHXBOu863th81bERayuBO/tceJ/Y25ltfiBAbdfkJ6alfbryEdtrr9HBpMoAd6YdoPq
1wZqYjiDo74TFoLbpl6ny6zOrMUD08BsCUid73uUTuPUieM4H11vBgXp9VsEssn5s3EGH6SSi1B/
Bm2gYigsy7nz6VZYNJDJQspO2GrY+pGQR29Xdu6eiHoHCzzqKnIsRRLXT1KNb8S2jbeZZm56za7M
1JJV1BrhsfpHsM0/Eh6PXNgaO1LsdRBN7BTdX0yAffOccBof9T55Gf/ONJ4nrbvJyddt0Ddsyx+i
7lrQDYE+XA6RYotbNJfIfGQU7Rdf63rO+UAkFQpTX7s/vxhJeWPrHQs3oQvErINtZ6IdPQeFq6Mt
2AOV68o3/6cSrrSzsRDUYL+Uxs8BmWUbLcZY1JTML8Y2DX9Y8Pe1ArDn8SP4BzVeeY3Ty3YOpymf
a6syLwWHHIWfU6hQzB0Ba7zlTpaCITicrpNRTPIaA3Or3wf5ydP9Gv2qrJ2DokoF7aYBFe0L+k0S
hF6dGW7jD1uPRaUksuuk2VHN0bsgIUa9kW==