<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxaX7ReNfkMzxko8cMUIs8+LgZ3MvGMZZxwuU+DU6bn76wu9uEWWRwt82yaaX/xK3X0XQG1F
nx8uEAYOuzpaKD3wD5YUO3SlEf+xIFt4eMSlZsu0OFXiCZWizGOU27hmLeXVfFHkMNJBDR1thtpl
8BCSPoy0tBUoU873UkqUp6ITqEcvpkNiu4qLNdTYKPOes9JvJOEB9FaVz5s/Up5vwNviv+7B3xNt
Af2T+0GW4Mbyk/MmuybboJuQxWwlOq19//Jl9y9QBBwxwMaOXrnFuw+P3uHjcxb7ZuU/fGnkJqMs
3KXz/o8rtYJqkKG2quibGwQWJt9Zx9aUk0X/vjMNGimF+v8zIKCW/mpM1z5u3Ka1okBc2BQsy4+t
yUPc1WIRmHmIn9A9+JHkMRIkfEOC/1e+eln0ZPcfcQrm5EQm3sFuVPVbY9m02K8uZbxMhokdpkCS
SvHYZluPi2XCXPwA1cX8cQfbUetCPvFFj0zdUhN/hCQToHA56C3TEDP1zRef8EWNLDuLkvrLAuvV
tCrLwEs1zDIkllWoR4akpX3QX1L0a6PGxqGOBwa00WrWyqZPfDWrOJiuiSuvkrkvKVSgsedcSlvA
zn9VbjvL/RkWpIfed4/ZHf2HftY5s6gNp8kEH79xf3bFY7MdcFS+wOYeLnTEV592tUDrSXsoNq1c
EVTUfmYLFvsv2w6Rg8YLc0+CFWi/H7EXukZV4wqufxrIaIqNIhDi4H21oHQdgE1cxm8iUIbVdPaw
0gde4ARRoug5+10uRTtls5/23uVtcvjeqEKD6M/AvYNQufKmz7sIHPb14C9zY5z83BimWk+GDHjB
KwJEqaAG4qIYwJw6vWGcdY08xunqIMCroGu061lPi3YrFaKhKQN38/+NzfWxlB2TnXzRnDbvl3cI
iLoJfbi8/j5dpzPw3hAIf2iRlB2xGh1cNi69kE0Z4SVeAeYOWoSxRCVXmS9iuR2+tPuxexdivRo0
Wlrz1HlaUG0lUAY3LnLjd+G1TondfAygshLjWMu1q0FAlxTKejcQW2fy2veMQmynjx6jnJ8ZmKaw
BbsL3Wbk2vYN57RJJ0jOoMVsEyHLIc3avfqoU+FBflNdcPAk+H85ojDCb2m5N/EuQ/AanpMNMmXB
CVCwiRgJZYj0m2AOol7zohsVnyxjo3YUi7MrTkkMAetKRxTEqoqW2zYEM3he4rPmq5tECIEFueWb
NdFG/Jun+TYOlM8B/+6C3VzkglM6n+o2NKn5gUzpKQMWUnAmsQU1TEMBFdBr0m+w6aPtufeOGCi5
cAQFsCTEmZqjfmuUbKP9YlG3Tbkv9QzSPN92Sy4Uik/i0GKxleBNZCup12k4Od9G/m0fn10qhO7/
rZEbRxII3MdDRF2RgnP4H8V6NgD42rrs8JSXvnPTJJWqb1relvYUhBeY2UaweVairFrSNpWwfKOo
t6Jqv92g+YGFv2H7j45OdQb6rv08ZXUNcErZiQcjdLcuC0bh7YabiRDJWDWg5f9bjq8ALV/VbuyW
4xflImKhCSTy6L34/fJOWvJtII566nTCumnZ2z76GEQ0Pj9ac4KXJgEKY27v9Updse+Rv2Qc1qE6
JDiELYYAg/IqS/KqHtwGccccpaFo8SvTAJRWFPBtY0zsOqgAqwq6psRmwGcGZu7Z5bpy4QKhqf61
chXSB2IDaCr42XyTN5+nRrlZxdlpGdmtnph3qm/Jegv7ETp37MwUiEYd+6svyPLMzfXlI8m6T09n
bB+zmk6wl7DC/YsLjOZrmvTs/tbhVXhW928hkkDD4mKe5N27mW6tgr1qdPxLQ1cgfN6+IZ+lgb/q
+DSlh2N5LRAhAcBBWCLLa2ZFO86w6b186qwYcnwyr9pT5b6EISVuMuSRuXtN9bM9HmDieD6yflly
EYpCY/0bmALao/K5QPPEDCUc374n0bIWzLlg4Rk8iTaIgtd/G34DxIM56ofB+FxXZ1V57roeWPQ7
Qia5S9akLZ29U8ED/dV6eY+NhectvrfO1rrM9inyfS6NsDzFc/b72+4O8OFoEE4MzVHUOsAnQwOq
bKtIQH+ONMBZDKvLNc0c2sWf5Dc9te+c91242zvfkg33j8LSCdeKIUudby+j4+ReihyWC0eOSfb/
YDxWZzHYnruBOGNSqp4ow7GBSwEC/QLegEYfFqSB9M5yZVTr2OEePuwmlqvkhMf/57B/LUt8vmHu
qvqu0Waa7IOr048su6fJ7nAE/QuA8rw3DLGMdwG5UnwRr1EgqRSTA+dTkT/pNW1ouG3bbiufyHDG
9jsc+aFq/i7chXZFH+zAB6VkWq1jYghYItBW/lLYJrp9Rvm1elm8HAB8LVC4+hFaj7aoMZ2KgckW
0bjG4IUqGGYYtku6XnLY3QJyekX5oWXrXS+mn+PFObwxyf0RNV0GNMX11qV5M/5kOJuBpxM8GjKa
nk0+8lzHvqlpletvvUlW3iWpJan2IXQi1kvy2xxAQ/Mgtrrd0N0Xqi3eHYCmq3bGYhPjTttZA/rk
nO9oxyU8JM6FRb9ciSz6Zw1NdDEhPF7ZRAj3UKR7haLgk4RNRar+83/NabzXKE8trt05FqNZOyC6
60KMheb5hoZWNtrtLwk5VSPLo0PXd5b04Kqx/a+Pj3OVDWAYpZVlgNWZp8qp3s7qDDx8L69OwShT
A5rzXkwX/MPTJ8HlRoiWhWoNFL/F8f0EFPINqfl6hwqNe83oFv2cP42aNJHqGQC0PJ/U53yYXWdx
eS/07K4/hpvXRmK6PCmoj1nrCmhuzldvcyQ5AVQ+3JI22exIbXzf0qXdiCIe3Q0mLfUYyHDaHfVv
/9YRDgjzabUcXCNiWH5FGvDep3LXwLinzKP5yFlOofBUteiZK0bUFT/w/rManfGmax4s4rE9sgUW
gNnKD3MoLDsX5VBM45UqzMwAem7kW8R+5jkFVcmJSJsn1r9WUD9OUituGhSlVS6wYepRFoY+YLyG
TVrila8BsH8sVv/oA0nDzvaR4b8NVkxZYF9hDqi0xAvoIrn1jnRkiEa=