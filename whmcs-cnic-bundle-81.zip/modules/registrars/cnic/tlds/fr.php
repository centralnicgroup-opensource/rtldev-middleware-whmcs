<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsYBt7EkNoL4jqD9K4tJFjtb+3c9hWpyg/4RXcz0putpiDfSHPT27n5Sx2j41N/v4dM63fjX
YvnJjFFYHHfqLy3TjrlMHzOGZwNOPeImYm2WGVsOJ8k3oPqkTBKB2iQiQcJfatxowZVrgSyckN97
tCIjiD2jqW7KngguX6Sodmd80FJVvdBcxFV5yjO3qSscnCZbcFc0Y5MERJy3UP4nCvNeLAqgWMHq
A+VYNgagr9Kp1WSdEL3RX+5VtIe64bfu7k9AKU4bQopHtbwVvfXWIQvWX/h+Rgi7SGaLu9Y3G6Dv
0FU6BbGWgQ5IejKrjb/KpMyxcFg+wQBA2IqLSYc8thrrPiI1DOsOJVliGxoKa4NNWpCn/iR3w3TA
CaCBEECBIu2ny+AF3/gYtLnVvxhvHVpXQUetROORY+wERbsg8GXRlgyABKDb/2743g9TlKSvqp9u
GkWhBGNW/W5fDtkELUvi7RZXQ+tnTsorYQ4ximzYcNu/nkQhbIV92rkFcgCIpbNx2FytelKmsTSw
vwnm7opxKMrNLIggtG1WsGRNdEAGR1iBcB2b2hofdX6hzs4Ay/I3L1NuVytzqkNAoy6bCVcuWwwH
0QnMIPhLU5gdR2THGKzyugjVwLgICUcJ6vMq3tQUsOousy87/xFlS1t/QSltb/NXUzOwD6kbToOe
xB0oqFibvYF1BJDAjHyqETN1VkKWD+HKPqgUENEs7Gs3guVSkRqj+9oB2KyVbsjqKVuT98PqyEmf
ZKxEa2/pqv3kfhIP2WhoAo282n47z41FQxw1V1P507qVBq7Eg/2ksPPIebLi7aAE/nphU0fc0bN5
xuqDd/3vhJM8ki82SZObifN9v9sZzG2x/Bebj+tRKbUNYSZZJ6c2R1q9lYrpcS9Qzy4XQpFSp2LS
gXSb2SY8U4uW2UmTM9Gs4oYeZQIlVqX1QiV4JPhLeTCeO4RpRNt0ixMNYIyNC4fHgZTXusspVb51
Dw/0MW1quIau1stZ2lnKZ05XNx9aEoG6DBfpZzXhLZYPNSD9BUqMBs4XHShLMDlZiNfpmM8qAk7m
dw4NXp9Eoh69GYN6PiSzu2FYlfB0PDlhk06UcWzj/YjYtENfGyIFUGgzaIpcvRpWh/YAiFJTgurw
fzwdA0eFz7xypeD22Z59ja6y48oMwcIOZEobUYzbDWfEp8/dxj+31LQfxYY6TKRPw9Ch3qZcs64b
00k5u2jEPzrJNK5hAMuZKoRM45t5km4zXuOsLhlbq3Mk0rzNEiZIIceTZD4cKDZ+bOnJRr2vO5HC
36tVvSKqNgD6gRRbEjzvxXibWzzxaIfWEN9ReeOQRyW9Wiso4vDTEF+x+07KQ/MKrWAlJ2ffwsQv
McMIl4ln9pdJw26pq3f8vunbmCycwS8IDwTOj4fZtXnJ68n7geEzT1ELV26yVue49FrZ5cQJuq6g
xuC4MhQIcCS2jNsRInV3D3HMbpO3YNWv4FQ05JFo/KKo3imqnQw5WO/4a2uf7jldmwgtpyAO027A
fTSIgBSOOH13KPV6iGL0t+dwsSkvPgj91D++HjdQQDwHMnhYafogRfzP8+YiGUTuQHBDAelgFIYX
2CseTjEB5KGeh8x3uIF1dvNDI7LzlEUFGG0EKJTphvGDrwhdhidZEaE9O8Zcwp9aggblvptYjcD7
7Arefy4o+OseVRGZ/tpb2DjAI/WDiVqvE6UBtaPBZoWr5VAg/1PGUSyd9dgiImNC8WUdagkbVovs
Kk7pjGV3tIEY0gKY/NfVPpBhexscClpZ/cu95c2inXSYw2oS6mLHrGaG/Bxok71W/UBLh3Cfk+aZ
hiwBjeJ8AySQrq6xlqJ/VD/IfePmKcct8hj9atuCYqvOjwE1JzlCKz1NCeYZ+aIjQ4lIqbHRB+In
EFwbU7QEhUfbGH884e1Vh/2BeZaAm8dQYwQaV8U8sr0aq6nldNUnsFeBjxzeI8PeQh1+LS4zrWQ/
4Ju3o7rGQNT2g7Upxjy3ByFmVpr54T+vKsdKUjMtBQA2sH7Tmg5TopTGEewxviHkQjy/ha8hkjA4
rJvXQMVs5UM798gruySVIfZD9ZY3LaRlFPuD5Q3mK2vVv9HkwzFkJexKmu0ZEO5U7OniJweSZJVU
XWYd5ex0GK2NNrvexjzDLFBMZnpZEkckkdYAJCp8yw7cWFIfTLNT9bkK5985QjAKh2uYsNssfijG
wGpTRvf2vpx4EXjEfRTdQO9dLHwrL1uhN3KM+eS1/5MXwP77gcrrAbTXwHKNdzNUBRIwvwQUNGNU
6xoU8b8AbbNqP1H+N0aOV983ApfKPCgaLPqckTFEhJ3+HKjTVKINL+462cc/esgmEU80O7RQ5Nlh
wIz2wpU7ZfLeeDObnokoirVUFrNs93IPLGT9r8z/YBR50pSUknDjEXTJXMO/k52NJvLoFb4RqTwU
d6wsMJzpZnSEJGg5stqtKYqSXBeDoa0j+osP99pjtMhPDeYs6FzSj5TRzo1DeSdttDJQMI9XVXFd
0i1ntvwKvuhFFLBZleUgqyPNqVnHPr6vMgMlxal7/YhFK0fiqPxRjw+Y5aUk91CgspeVpbnTT6UI
fv25mPV7YSF2ULwGFKV0iqcEKv9sEC9f07yeuzmpAkYpKVtPDCslCtFkCk3q+YbOkDko4GUvFzeC
uoNVezkjn1EMCtM9HeFBPEDJ3Xd9Mh+0U1uFCJWH6bbPT8oZ/k4VWHGpNtYEFglRggyv/D9FXY8G
lX/sTXQSqJZphXILx06Czf8sX9S7TJleD0/P4w4PMlEY5Q1TT/3A3KgW3dIU5/NwutigpfqUoUbT
IcS/ttV8pOwUAF67pSx9BeghSblQWFh4pKxv4vYbCTxcl+/7mLRLLRL1hkfzJ3qzLq+Xwobnid9S
KcVlgK+ZNE7QkCIulqMwFyjyZraHR2Asn8GEbbZT3YF50z8Bg0vysn0Kgq4WE99/L9r2nfgUqE//
hb1jg7kaPaBj/I6UbFqSjl5/n77AoWNWKZuZ++E8L8tH8dcKFaLMOosF3vkHbZBBmxhFfKf7cEBZ
a5VhcvNd80/0VSHD8qk0Df7LGWkNzq8GkhJAI+eBg4jvtVE6iG4/pumJeB8HPL1s+BBEUtOemhgE
hJYiQE/WsR4Nqr3acmUanwVhieB9B9QDMve2SznBFPOEMN8N0l8mn99nuwiRvylRmTK9aI8dNRRF
77+tvE5BliSwAm7XPZW5TNR28fyPGx/jVjBBq44GysYSAIv/HvqNY8lL84ZdR6hwUWMxcrPxFaRZ
gqdksIdmHpzAeoxRRev5+ysZJ93/trr1c6jGKKyaV5hjRF0Gjwe0x7KZUAMwc3ZA9Qm+wwbjJhWb
GKU0xNCx1JYmh8+VyJg253fwCGhf3CDAWgriVv7v23AljjIgWbXWOQWN51s5pD2bkHmEIPKPuk+X
e+tkrqtUXuyl0IKMhmStwT26UuY+srsNPfUWx58tUSsyUjHuUdM4ln1wyiK/m0VPao/cA1cZblP3
flkEJkj61vn8DiDdntMKm2AHTNEG0NzE9MjzcbITadhjaiT6JPGXxmdtpfhrX2c+vc7q9sXLx60s
5jRuyzxdopRe56H465ct7s/Rzn1+dluTMkSo0q+EHxvBufzLlOF1YnsPHqVnxaN2NBS5tJIEpcYb
VPpWbrksOCdVu6dMqFZD+cMM36uAzPdppgdwetWZ6uwVN4HGz73HIh8Who4CzCjLpnur+L6PgGYE
WuTsDSK5GTyzltFkwHVdeyJSFL2G4n0oVp/NkSQcdsweXW4+LUmmNkQbyxLHx2qo43ExLBAA/CG8
9jsT0VHomuXxcu4Oo36oxTQ5x1K+isgFvkRUdrLD7Jxbd/pLqEEnfaocpaJBR0==