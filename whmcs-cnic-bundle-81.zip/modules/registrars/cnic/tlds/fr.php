<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyKWS211kaW87EZb0ta3pVF+254L6pU2SFU5PwXpSsqlBmXxbyoaPLSGa7DvxNKR7B+huClD
Js4wa+O1P4B2B4vJCgK2UKyl0VjZumFO0nLxmp4adqeO3wAHUgqqCVVvq7PN3D1nnDUN6PyNSvJg
2Om0xbj/xMpYP4mwvwfgkRiPn7+jIK9JfjuF/PLtbKV43YNKyV/pTSDHHSUsR+cPCBqozuYeX9NL
f94+Tp32+qR5O6Zh2M27HdmNQuBkwDmJpxKDi3QJ5US900ZAqTeuNAz5/4FFPHXUTToR73oLpuj6
9fl7NmB5wfyAEGVg9a40vHZscGbQz3Lqwf4vVQyT9zBjj7O2DaDcXrnkvkFW6LKh8TNFVu+Pqh8k
qjKRHUJWDIf1vC64s33Uu6Sa2JkbJvWDALhkEx+ML8LUfoin2lskdv8DqXg/8E9MFZFqNy0Sbuqs
NcBI9X9oWSoFhn7zWbnGqJ5bctAPpfMlmX+pjnW4RqzCvHzSfnJT73LP1cRofXifr0WNQtvBBlP3
N68+3NPJ3APGX0RON6/aoyN6yPwSIGLvfuTxKlhG0pHmVK/Vc8alNf8fkgtsquX3t3ZLbzpmZ2hl
a7RD6ZwStsc2TPhXvaJFAQy4DIcmHA1ddPa08a1vB2d6TWhQJmqlrh+cJelPYztFcB5msnkpA5Cr
iZYqNHJRB6DOa8sxjrWdoR/uQzXgWlSdRemgRTa5vktIc3KBwhNUQheO//MDcFbSck/FgDRJrHSJ
rY2zSbTzGwMhUK/2iq3vSSZPs1diHtZWfRXtGflWzujBqm8fu2C9BbpjsU4KcuBVGQ8AzPuCEDXV
IV/IjuICoD71YS14zXEg9lgvTZMbvxVqXRTr2H2p/lxuMFBpCnt9aks68LSZB1e6gEBkNAddXh/S
ssurfoi2/F7P5ZWAW7xiOudDWPWm9YSpD/EFvJaeDSeBAl4BPHMYv8qW93SAxBZ/d1mUsIphrQqM
3O3Scwci8nMvLtWv0Ln98BHjRYsHyPsCj9vOrc9hefu8aXZCP0HpCOZQWAV4Vy0/TGhv1twG6mTN
TcRUnIjh5aPTUY+5ufov35iNvafIrHOsLrSzs3EbgPohE5g3cX9yNJ82tXh8I1z/3H1J/yCBUXnN
k80+KfyYBBMrK5xciT1kTCzmtCuppB3oeJ8qDrrXK/uMwgVVlR/hCDu7/7pIDwgXMO887Z8VWScc
B520SVR4WKvEBAEO3aXQLWaX6d29Y/ex8/Scy3BfhynogUgnzdh+4OmmiobE5OI7lrLDxN4+7LVG
rnfW0I1Q2uPKPrcFbqAUib8bhpYA94OqZJ/XUrUCjrdp4SVloYreoaXkzQ/A5xTDAiOTJxfagd/E
BX1/IGIKJMW988C/y+jLqFeOiHUSq9Ln4S8TEK7C25lHqzhZezUKgrF1Sd25LO1GfQO0TYTRbpOF
URcoVMw4bP2s/r8Z4susKRmi9Tuuo7OGcAeuXUCAsOYoqM+2PfypNQNKjDmWRYSvakjePMklFYrn
y8VlJKuDe3i8XjgZrU/cGIinRli4Y1YWpzXXf4ZN6aEavCistW878avzk3K7rB/XvQYCT5+ykg+R
XldfBLgLsu/ZM7gBh+kdgVK9ToMA5qSPegZGciPU9HX1hENp7ya0cdaIf8Jvk/grVOUiJ1wXHgCH
ugA+LIMspIqCDkOj0wSQ3+TOL6YAVRrE10jIQ9kLD/9/7n38MRYpGKG32dvJXG3BecWWfK0w4OIM
Slhq6UPS9FK1Z/Xa2P9QI0S25BCjJmnL4bnYx8lyRuMIe87moMojzUwk8XKvpnoNZXg3En9QelNI
HjfIRgjJJq+A7rfkTHLU4cv1aZL8Eods3MnU+A7bN4bv/HjDCzJdgLvytipdqrVT87a0FRA5BZJc
Yfd7DSVewiwcdjL82tE/iRVUW9a9i3MeAG7eYSvJMNYJTE56WKiitqPMNKEju3NGCtC4pXniFLk6
SuIemkQzIRAlnwkczvrcH/qkbtuoZGolTXXF0jn9JBPaeYBIxzuPfhXnStSVBdXifxKIHqCTHdat
E4NYYZt78V+O+/hR8cBas3ra7cjkPwsldkbVZToB95jU6l2qThtNc84Pl+oULCCQdxD0NO/2lUVt
GiqBiUeJJboo/nl3EbTLRqyQ6V1wTCnmoO7TygwaGnYfSEaTts5xxrPf69dMCc4fRMbXyqRV2Chc
ePQgvmfkqr2xZhOgYyd171qkX/Qb7ye0JMu9ZbLgpQuU0Bp7TPuzDdL3kR2vYmIxvjBMeOUsWzNi
nIFbELiJ40fjGwBaruWW6/Q+oOvuie4s6+k75IdHsUtm8v0DhpfkBKwQqgyAztOO09KN5HsLpgKp
rYOU3fcFfHO5xR4/G3d7EmbTKIu45ZZtl5i8w1be5XnmL2vRrNVg8fe/fyHYZVSdyPmR21cHiVSn
HaecRX55wu1bhOtfhOqnPJdqG0kaoyWqyt88R7+Rdp+/Zk/0D6i8TJdr2pUvR0Pei6Yd57Dm+MMh
uR1ENJV/HD1R9T+ru1X6Lnf82mblY2PXitd5kYeHHRu2qKMQKsMUoXVFFm9dWo1dYOEwUPARSE7F
W/Azio3URdgZhrMpPH+PxPl6CTToqdFRq5jV3ucLjRUzuji35ngFbrZRjfyDglvhgNzflmINpHy1
82KuExPGJzErfRiDk4NQ8aCsLFb/xfisBocxMHrd2Gh0VCRIFdBrrGyLPJHFeDocBkGDPE23jj9U
xD6eggMO7oIMsoNw2BERJmmkkiuncYj/B2tTDwXfDkiSIsAL3T1FY/1YAAEMGlxe86Cobrq7V4CU
cnBNQ/3V0PRxXvPL9MB6YtTpuQ+uPJjN7L1cHxiQdefsbon21yZa7e3LdLTkdMnWKAN+7fHutBpz
SZYP9IoKIjJI8ZW50V60ib4djC/eM8NE1Tlb3v59EGK4MqIaIi8PShkKhNa5Np9CKD77gqI1SChw
C9nLaO+wiwSJdwp7yrPvjT3OfXKNpFTPQmmM1VlJaOZTODIda/lteLXa2jLNJFGmLOLR6E1ZRAyn
pL3f+xo9kQZUfWZVXgZlcYYGsG2ELjM7OiSVk+o30z27H8Ld6mGpgA6oGP5UKNytaQKTKUxGDJqE
N7eZ+C4hrIs64ictDlF8yyCBd68VROlyUULXGMz2XHmItmOLXrkB+oWbIQzzQU6ZvEji70jpouZ9
sKesFgelUQhFDpCAu5oIiE7Iz1wP8GFjLgchQ7bWl0FYL9lhj4Kj9ubP4lV/w5DD1olrlHJhUzw+
VGxoXQd5vmAvVDJqal/EltZYWLe6DrZ9jPAozLMFouAouUWam3X8Wck0CF3RGGO5t4f2m3xvEx7f
8ksxlDtNvLE2jkdkgvsE8kJe9T66xZOrN/2GBLt7552zFkO8Y6upeGgpjmA9Lkrb8+twJji227yt
p/AQxFugX9hEG+YcVvP7BaVot5z6bGgvIpBnAvYjqEl1vunFcnw6xP5LxJdXgPtZCxZ0aPHfe4gb
VPFJw+WpwaUWw7KdZ97F1sqEtIYv3w+cBS1ZCOwRVEGVneN/EONhVa6oOhGB2X73rbGbJSqLSbyX
F+6sq9KjgGWP2uRjfXFBXBGKgOMlZc5OLQs9SiyzFP792feBXkiJ980/IevVJyfmpXr0dVVezXXm
XdzfQVewJ6CxXFOiE7vV0fA1X5t35d1XA11hcN2bpgYFnp2qfgi8wo8hA0R9wPkEGclVj2L4nejO
OF75QcXpFrSAZwhv3dvhMq/HE5QK3DnQenJukEOAJPNo1ib5do+dm5VbFrxd4yNBXRrPFm8o9k4t
9NbKyETC2h4SHuUaaNt5eS0DtEO8cIhykhAQAmHvkfJ7WrqolYqDzS1m1h8RTqsjd1fXJW==