<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpBIUs6ATK1NKnZkGl3ZyznoNHZX0uCzsxkus8bSkEADGkxdQM/TGTns83xtWeag4V5RUO2T
smCTzc4zNI+RC+TUP0vYrdzg29yiU2BY4cpRxhbOpXF8Pb1wISDpAYfJlWvHp0SCvYswYSvLSQku
0VOfJgGrAT6BWQdFPANksuCwAzv9BzB2g+b45E0vg3enJWDIs+ZY7cT9BFL5YBsqeJkpbJj9XfiJ
ht2vXpWeBB8xzc3cLEAkc0uMyVXIEb1PTNhvJpBNp7oroBaE/VGDitMnBuDeuWFz/aq9rb6sK4Ts
IATv//thQ6+ljXjnm82jaXPB7ObruDAarAg1Ecbe9wIjhCEbgW/6em9u2UvR7+9n1JSYBjQLxGA3
PL/CRevW9JKpxSahWVzZaEAA92+mD8NJZKEg8Z1L31SNb/6gSELAS64j7xDAOyQLyWs3BfCDFyQt
99xAYzc/nackQvzcXhHRSgaS21NfgtbsYxPO1w1oihde+cidDmAanyGIZ8YVjZvqE6hHdT5q8Y8U
j9WAjYY6caH4STStL29nPRLLs8jmH3xRXIt2z2+HffuZMvcDCnwf7kH+hPmIrBETua6sTonv6syl
5jdMpYYaBPbX+xk9Gg49bZcapbUpn+cVzqslsMq/ONiZC3f32OjP8BsIznz9qrZXRMJwTR8jZn3o
VApnf/TyV/xzvaER/pakaNB+6yd2lPGBBwXslcEBKk50yoLbto+ju3k6ARN76vlibLEk2JiZov5M
fxHki9bn9QpWLL1uCGiw7tUGuuSbpog071qPatbAN0SvKe3UfL6KKqqvN7rINFP20221M7cUCZsk
UHtmwJsKTEfCDaKmrGVArpby1Vk0EjBFHwPw8njCbmr5TxsG05QvALO8HVV/zs2uwegCifDRVAK7
GOKZVloAVwVbbGBvzMAE3jfCXZ/00UG1zuvtI78xIWWQjNP2PgCh0jqUCVBZLtmfrznp0xP2N73y
BqyIXwKtL+Z/JmjG//C1vZ0ltK6DYuzXJFEoOMUffFmnTtIdEWwuYBUhSyE/Q7B52i/xerwa/V2j
WlEo0vInIeR/ywV2WYI78jPFAf7FQy1KvMZGyQrIwWo1g94UuHNFkwLrW71l5XizLrhS4MgyJ2qf
YSocQ4rtZUEgZXgeAXXvxCZ6KrXNkUxQVEZz7Jhcm1l1ZWnkXtCTkct4Yob/UDdc8WmOEwNr8DP4
fKfM9klZsH8C0obJN18qp6dS9gabOBMc5waF7eGEC5WHKUL4Ir0jDU83lmHcT3kRr1qpU+ymQsS1
2JwfZz3V/Oy0o1vnjZNPedUQvnsIpTM/jI4hdK9tExO1aZhHNqW8BLfS/zgN4eZQzP6XBU+Z+dbV
9fvFmgF71S49ojtWVxWNuylcQXzfcwRk2LMwXxnv5tFah4KfrWfE8LBecooQwB/5eNfkxl1A4opi
+y09uo+WBAQECUzNqn66OrVgJqV6FNJbhkwya8Gkkm2Fmc2CBSI4lXjEBwOLEcY24fOLdOMvpbMq
TtqDmGnCMnCgkGjsCyq8xRbko1hWYkMh+e6Fl+3J7jTwP3C9UMzv0ORVFJuYFnUyUlHulU6TV2LQ
J3g6sLXup/E67zj/v5AkD0e8sY6Qg/JGPEVBiPU2Kd1mnHfyd1GBTU3yRdkUKttyiag2afcOhwGX
nc5aoAZa1T84JzJC6Xs4Xo3Zq6KrWMj8xLVY5kPgLbHSpvp9UlwL3GLo2M+zIB/Uly0PbrMJoxTU
sfcf0TQiGrAdOeBa6K9qV7iV3uN6dbUyjvahdCvGq3vPIU+afT0s2IaJhj6fIabd0YVgRbGZ8tAd
gYi1M3lrzxIQ9dRi+6qQZHNAklWVY/iL+6gfB1KU8A3ZdI16KGNvdrp2XS8XMS2nmCmJvNkXpyJM
3Got8WfCgB6p+UChqewabnfLI5dOYhInD5nKcoKSGfThCQT+OKzoCxdR1xLCm43q0JM497nIiaBd
U2hhNOR9P2ZG6gvGwDoa2b1j660Z/WFw49cbgfcQ9N8IHR23e8NOyA/yjf8gb7U+4V+F2oVZIABZ
Lc3SEo3GVOo95vqetRqqTd3ZvJG4GzHNmnbfx/PlLUMtgKHqHDMqUaK+ek/FXeagX3wBPRCBUgBA
xA6XecbwrbqljssJGlGuhvzToRRl3v9D/qWr8BTCBRLaKpdCaGOmQmOZ4U/VuOy5HoaIQEuf+PG1
6BgvQqFS/faFLQ3zeOVfOlNLSF7ZsHFskFrT9PQOK5Rp/376TCh9xctlMWijbXGmxS1Mkh2fuOhW
/vzrh++kENxDAxCDHYj7n+VJxPIsM2XusGb4k1PAeLgXzKGEPmItYlLy8QHKS1OLpxH2zhXkiRBE
qcYX84hPIyhqgKC5bO4x04heQiXN/x4H8lhMBg33P6wnbJHIGJcVDaHbywbYcGp0jm9O3VZk8GTS
sNhKAPRW0Kw4DfFy8tgbzO9a3inGD0qz9s0JC5oyw/ZJatH8lpOBmFT1lmVbvFvjaatcM0XmuORX
vcz7eaT9VhAa1D72f8KNQEN8pvofmvqJMXL/Jt8a4JRjQacL7VjbTMjgTvhrSaxVq+gqbzmFj0Er
nyWqyCaQsSNxu7GAp9jcpEryQNOc65/mMtUqsAUxVp1O0WflvBBiNxsKXXbxwlUI7RZrhh6Kc7UH
ClfU2Sg0cA/TeAEoJXMYY0h2ydo1dDiB14GF0Tu14H7fjFcPobg0x6uUT1fJAJfGKXPNBeOXN4Az
996fs1fX0lnqYjLv84GAAchAbcMrFaFK0+obwb1tqtLdXSairkXk0Ytzae92Bzvy6dFoidE+v10T
WU0SnLy/kdJShsjReXcOY15oDx/ZFQADbg5Nfw9KSP+oJIgVTy+Zlm/3pbTGj9Lh+Jj9x6+4/TVO
XSbDdChUJgios4EXrOF29rn5yBs/yioCbLg8/0jcq/7kGewEvAfU7QMoB39Ji+O2pnMyOsFBOVBd
mNaPjaJ+yenLerH1piPZsqFA6XSalk+3cvnRrdd5auqngEtrakuWHUv/KCoju1zmaQdNYSHX2FJ6
xoBwG/DT9Im0rlucNrCNNTQ3VOCpJX/XFl+t2PQOiD5Ki9CPw7aVayo9oo2xFYievnkGMAUQ1HZr
aL1dYSXFyqLx7njSkonuUeloY2h7YzXrFxYTb+pDTYNu9w2Jtb4/DXpVpXy5f+RqhoKY7zqGxhLy
Kb5Ycjpru0IT2eurYlWKIrBHdPmtSJZpblsK3AurHRCmv15MA+doC8zCMBtbtQQM+cmTAN8fEBoI
6pBKX6k0VWhZXkiq7KtUbZrmGOu+DXzqo+vVJSS8JKS02vRyXmOw6zCgOF1vMeR7m8IXtp+qcDra
fniG9HBddxYW8KAZXMTKrBW566giKfJa9bpMlm+NBihKRhijeohXTac1JO8lIdNb3mF+g6OnRQeG
ldotEIcBBq31O86zoZCuk4bjdVCDTgvDgicsVhKjS5LF9pSAlJx/LqvthIl7IU2w6CJVwk6RV68M
0iMf5cG7Ov+wJz+lCJzNPXgyJFvbmsE/PqflrsKpsvGpzgkF+WfbCf57UyoxRFhvCwcHqWwHkPVN
9WlkU0yuwsmuvHJIr/qNssSFKG/qm0jy0wcbDeKHOdefiZUdf873SKqNpkwSCRge9yIbDIkPLxlk
YCx2HUklle8u0AOIs7AESKq+vNhvIiDPSasTLiTgHVmaSR98e4vEOOfpPMBrJrqMs6j65YKoQDu0
ul82zINNutdug/mjR4vt86/pbfApS955Zl1Q/dt/0OwUIF1LMLMqnNaT45BncaEwPBiYuTWCS05s
0oVXAM2Rup3TMybDw2Nl+uncsY+n3NFtSrWSlxXldgRVO96ww/cDwLC3YDDcbwnKSuoyKhq46HMI
BMIGd7CNVXXDeTQ5w6rcBKatc8266EahYAeuwIhSO67CzqbmLj6kHK3VcofPz10Qz5OHXlqNYRSR
kFNsj+o2nol+z9oZ/ocFe13dMtXnzE3Lr8dTR8mqsEz41xhzlsm1SG7oSytGXeFz3ZOmPb7ML1lb
D7oTlQjP7xO8dXz9Ol26MsPsO7o/tj/Uvb0b5ZsB/VS/Ba6znOG44kKvv5qpNtpVx/e+aCE/p7c5
9NPhtIxMiZgLGtbYlVLxtLytFnRc7HlN5/37N8EnDyNUZNzcydHReuu6zgjZSAifpeqdTNPpHwOf
qG6SjpPnA82RoAJiS7GHanxAMfKshSguYHtcETA0JEjUHtmU5gIE8T1Hu2gjh4DM2YiJgvoAZ28K
2lNNKMv8XLLVYB9HTq6zP5HcOF9ESzFNhN8Fah2dyaHVKlSnxeB4Gi0SO2I8H1nhA46g+AmZUFxo
Fh8wxLjlYrl1lZdVoz87ZRX90EEPhnT0tXQmqtqP0amQ/dDcRFgj8vFEl1Ap34K06Rkj8rnUpk37
Na+u3fCeu+CwB/POgspIIB7NeHdGDNCtSRC1G8q4Q4XL2iFZG5MI4M7ljZALG5ZqUWD1IKmbchcJ
ozxora3xcVLiZu6+rUFx/daGTR/kskYmKTWbZmT/QC+5JRUxnik4TOiK4ahGwcfBfEzIolaJvDWk
Hqy8L1pJXXb9ybd0YlM9S14j7IbfBV6YBsKxHSwQhh9P3aRX7zsBmDx0JsCrLMJgpdudgOjQCCyf
S2B40tJEW7XEs8eg0wUOn+H4hxlZqjBqK529qnNzxaVPDOtHudvihGSebPgpCUopEiBtZCyOwMtQ
iMqJH6hGfj9QDj87HKvWyRrWDB9OH5rmLIlKNV2A34XQ+VMwhrrPiyorJf3tGYxSPmhJmd/A93MG
BbO9tUWQjG==