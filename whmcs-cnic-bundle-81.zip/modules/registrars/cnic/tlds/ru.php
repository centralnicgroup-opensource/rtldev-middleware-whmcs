<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvZ6uGLMXzegBmjq9Z/Xr30axkg3Bc739lcPBcD0nz5cbdF98Pn5babyhO7xfGrgDk5liHrD
VRtanfWjdXGbtZ4QK9ZIMluuhfvDLfSwcXNsGRCO4ZN+UPYfMQHt0mtl+226WQ/BI2SPrGyZYB6l
0NANrEqz9V+b9c5cbIvQ8PpAoNu4LK/wDlCn4scf5aUz+k8rz62XP09odiHDukCf/U+MCPIfuqUl
prxTqSaRWahsHN7sYXwbhIImlo1fRcC+QsJ/8pQJ5US900ZAqTeuNAz5/4F+PejMHt1Hm0kQfsH6
Ldl89QvGAYcdsYprv+Z4vdNV+K+bygZAmaqsvMCHvHOnt/wyOK27MplVo9AUgvO9XqsPRc+Ev+0F
0YV+B2RqgVeccZdHFLPfFZXVdD68DPeZpQgFf8QlXgfIoXDBfbDXA5zPE6jLpCyGm57eysDSaZ2o
Vk7WgVahfT3Cpsvu4NzAO4+wV96DE2O133jhNpDZEXaCCHxCxKH0JXZHnlTcVeFVi8zjmA8FZm7j
7Bn6GPx+qTE54X9GR4RLE7yh2v3UDuEVoayB0rDJHB+l9YKkUw9CAUBqCBlkGt/WbLkWTkCzremD
UiRcpsQmBla/He/tYqbZoJYPjIe+q1FrSSw/p64nShj2R+P0gc02lgQeviIAZH1SJQRG6p26DgGD
LwonX8/Hw3tb3scUlILt3TtyHB8IgaP0iOjBCx8eDXluM0lfJ0tAKZxVX4m2Vp3IxxJSnQozunx6
xrVo01chLl5U9OIyReAxT7WxO544xrJarqz69E2L2FujGBkgp+JGeKBkdgK0XI5SVF/1GYIyb8z3
k/wilJ46hdX0YoYmk4GSfFYDmUSRfDk8tXgv4v/0AF0D1wK3WDSML5NPjGdmHhzEXx5Fuzu9v4b+
r4RoP1jS9gLDtr69DXXtfRnDzQeTuexELM9mwTRU2fR1hf3g20LsC0R4VaDsB7L1Ur+EecXxulPQ
yKOS6ahKbGIXA3KAUZ53nzO6CKP1mPLmP5Q+v9aI2p/HtdXO5pJnudCHXNocTv4kxtDBqTvjZSRg
pft3mzP15ENr0ybdlAj40usda+WTVdWBLVAVyc8Wt2PbleQ+uPEiW6Tv8UNQeE6xsw+/dVACI8If
BPqe/njehK9xrveHyF/G1c6q03TpNUGBRVNU940TfZswUgdlqUqnZWbHOHLS0radsp/Tdo34JSor
w3JUk/5ZC7QCgsu4vDMpyaJLGXnQ56XNOrNOTwOeSllayUVmUru2QFbcWa9nx1ewXRby3X/Y0Mtu
rz99nKfgyDL8O3NNHtHikdapJTLs8ebmGZGPBPVKN/++4FgDGxlDhxA4vE4T8ah2KQF2JfFewaMN
owHb5UO2ZFGkC9w7+7wuuNim1e20CY+Me75wqzwSe+WE7j2Uk3NLWIFiOb4RHzs1N8zQJzbPUHkL
4sOIDx3gB89l6RIXzU+9YXBpMEQQNP8MUBvd/yG4r8omvoSNeVWr6pVtyEr826BMviBzTw60MZRe
JCKf2lY2n97ogETdmVIEFIAQ/zqjdQOAvsLKA5i81m0OTeV/APFMzYh2TSW4rQV2OdGzvVIxhZkI
kmHvbNMUCv2+qDNpcKwfUL4dYA0GYECa6T9kFN/W9TKUnOPBqP/44EfTkuLKh+S+zz2VJWMCOc6d
nKqKwJOo9vzXKrkmY7C10FCVoOGD0hOAZN969GQjHsxW6whooUPbNLlTD45zKnbaKMLvqW7DDd6Q
v2LCnGF4Yj262KdMi0+NnhZDc2hnJeHxCIxPVWuTgt4hMqPNct0p6JhWQsirR2edEWE63R0Wt9zT
SEVXGkYAmPWRj9u0L2c6uPvxS067KfibuXa6err3ieg6LSSIDT5ae8I5FQWTLjaKryGHgZ9untqg
gHKOqrjkStsO5CBTpUabccesnWI3J5TNxCx6OFX9gpby8oqMverAL5MeTb0pO3lk5ky0ARaMDwB2
mAHPNrWCze5nzcpHo1h82fAnNCaMumpEQIawdzE1CR5cwZCdL8y8xNFdmXwBFHGN6T7uR462Ptt/
Oic/Jz6RI+6S2b5qHEyKp0Fp83hBY3xFr4L678pTwEe24NkIzov13KRqEJ/YVfAs7194+0Uo/m3D
fOKtGZy6Jl3yATwAdatD4aLoZJsrSyvei2sUoHaINuvzy/0pthQPqFfxZ/hlqQDFel9ogRtkV4Xr
x/0wlblhPlj5uLcCDUq6oEh6C5VFm8Pc7PXEvAHnnUg9KVu2MmgOjdejjSdQOjKrc1PIBrdukwm/
bS6bUMBMQO4Erbwbmuqr55ocd7L58bXYKsYgH5S/2+WTOrQQg7eTokD4m0jEuSx48rIdRDgcmZcK
onukGkCawPopPaZUL9I/Gkgt9VEaps8uwR5VLYN27y5ad5IeSj8BE3Ttnknpl0eNtauulBUuTA7n
lC4i4MXq3FUKbjnB8gJ5CUpZStVwsQBTI+X2j36roKdkeV04Jr3+ta86NkfIeTUBhs1zQwsEVRI/
qLr/wPD47UBTIqNolLof4R+L/Fpm6HtNx30lZnCOflFJARjmC+gnGbIm0YFFa+72W8NOFK+O4CqK
W/AWp4ogLHkePOaHC0nI/zOcP1MEJO5mQ/l+gQIsuE5C81v4dcwqa1i892IwO33TE4zv9hlaYXEj
bV2RZxM0CZuuG/LRg7Dy40SDZxP1eJ8Y+DDPPQ6rQN8C2jjQYCbkkutE9ikDHdsVY03K7gQVspEB
kkHz5jHjZm0H4czLcI1pMoH9Gv6WGNSZ0mOTRv4YIt6RHBIZyZyur/xzpKfyOcLDLCR9aTpzcX2E
6ug2SWv3qj+1CBEjf/+/AX9ctdRU52bie+UWlKFN2TrrV/gwa1r9WrJe4sKmvLTx0Oc+g2OO0L7O
SyutovWroeDXLpZ3kHQuJ/giD5nmj3+T1vG4ejG488kATHhybzChDh4jJ4NAZ/hv85P8RD7PdkOn
f7NgohPoukPw