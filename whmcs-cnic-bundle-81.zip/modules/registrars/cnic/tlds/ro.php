<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqxrY+7YLN3M+paUmiw8C96qgiSjsfrZnOkuerVeSY5Up3U2mAmj2pQvOhLtHGcnVj4jYgHG
Bg11wNi4qQNbempmS8D/R4gDy8qS107I35q14SzLRlnuoqW5iZHm4d2z73NEiOo3aWR6Oq+1sYCf
FoYH5tU8T6qBsAZtm1+VQYty/ljTZN36DmXE1+5p8upRsdgNTO/P2B+z+b69+alEKFXGBSmtgUHb
LBaBFXASwUWvQcva/IP7DapDWDCNG1pEHd0BDfCLvma02ChHsZXShqNyGynbn1KI0mr5HEZXQ4O6
h2O1YNLJBGnQHR3k3aTURMchczYppCta+A4Ryzublg+aZpIyzCMz2zJuBxp6ZkI+ii1wtnbFXkn9
Q9ucSTd6LPcZKptAgQf8VqbhE/O8vKlW1mhJ1emrVX4TPKkUPP0M3qoF/TowMqhUmuCbYDLfSj4/
tr4hKT2Gago5yvxKpc3h0vXOwyVgYFca2f1LWRn5TNed13uqhM6wmtKD2zGnTzMGGc2+VCJgMVTg
tK4efZzY1eD5v9hFWqHG+rV3ywcDDOQTCuCr0t/G0Ia3e+a1OUW3mYJ4qmKq2vD5mazydviOYd7P
R6VsgxAfPYdfj9viRkNlQuM4VxFvYKdFZXcfTaZ3qG336KV7N8RmSA+mUIqLzDFhk0H/jOmlsyg4
/TCVfYfiQYfKeiC75UKzNG6lilFe08snv3hetcgrey8ojCbJrphtve94y96DWuYgIGqL30nd7Ql2
sKBSG+KtX0TI5tX3jBj+uZFPgsd0492skocyEg8w+kgtSw37/1ywxQfgiZW2xajOewn6TbL3kIBE
scqSqLbgictO0OUlUdbS2KcU2NSrgOQZXT7DoOfByj1it26S5ZEoaJTz93Q53QxgVK3EXW+jZpNU
vz93GWqf+eTqFnZHGw9gsVYnyFfRfKuOpKPzLiPUtcUnCOoVoMqU42XpW7R/vIb6vO/16ZqXhpi4
JY+aEG6LJ12yZ7YpIV/wrOajUoSR6Abse6w5GCjm3eQC7lOfeUp/w/Oix2bDqpjyB5q07K92Yh6d
xp4U6AorsmBgbnRCG32c9UpWTzO54GbHbTOoxmV52JFM9czgJhERe3t0L+0+uWAR0MMdt8ivgp0K
1TWtkQ744ZdihhOAcLQYpfaJW6O3+e/0ER4gvOzxgKBMXHNci0F8yVIfN6miidqVicGgt0MtkY9g
n6a51SpBgPQXzGDKcplRu7O0PZgKA4O7JvxTF+1OLXhoEUmA1/pECgOMZt97KIc/wRPnIjPAbYxU
3G4Jj9rxq+Lu844MIoSQuf8SAXrpx031rdmVe57/RIMUcudiuF1grNPl/tsUpMbzmmWHd8RGKK8G
WjbmBSX56Ly8Xh0Nqz7LbzkOT+3gciwGyf0P3EuwHqWLVlhcZ71DEE81wTaU5jTaJeMfPDtd2/Hc
X+FPP/CGjLJqL2aV/3jFnvyYIjlEwy56JkxMWcC6hpbS8L4xPdYYbp2wNyEWbon8K4xOi9xmcygW
v6pYrrgbEy5g2yozzIEO+ewj5CgBEcnvzepk8jMjwOjyOA09N+jONjEJvhJoE1oalOl/GEfj2laX
ysVI181h5FLeNc8UJcVZXZZh2Is2QtTrXcDhjIMFKtQp5twQ2pte4pPB9/jjIBOPfaQDz6vBqaTj
RSTT6WROO/5tCDOlPabsP+X5QoS4oRSHPxobE1hAEZRo4bjCftCLmgCn1RbUzpMEqH3WlCGbuJvC
TKvDNfMMrd62mLohWh/ZbKRcCN5Vdi0BnfyO8YSe3v/Xm/svVzYwgMVB4VVvuVcini+0V0n2tNNx
w6wEFd7O6ecrHlK39XfG0WkD48c0EeWNOF6F+0BmQC2RM5lWzaWAKfodwUfXp9z8r2oTEYXz288I
SZa3uggVkv2x7zJ2qdYyoGZjFuJnAinWoJPGpgFOjy8vhyeaRsm8ljmXy6wbn6Jufs1m1rrEo6k9
ibm4fzg+1476dGRGf/SkfEMPHf0DpRqMohVdg73fciisOmyxNS6F5Hv9t/RC1C1W8zNRXWYpKf0z
rvDXw6Yax1UpL3PChxE3DCreCagGBX8037Q6ParMCA6EUAEBEdMG00StPtO3hnv5PlSLdhD6QUlK
NGiSOq1sX96FK6ldKLx2TzHeuqoR9HutAXnwa2ZIp3wylwTwf3d+rR05DXQJtHuMDnojfa/PLIt9
CjLDLuJ1EFwAdzAdlv3mxltvO2dgLE1vQyKB9fsb3KR3XR9QecoILZENy8phGOBZhVnHL61yvu8B
U+mCCDaUUbKmv0U4Fca+QCBZ9T3VCny01w2jVBQZBSFZyAxe33BN8OOhvWJjGv+vpk83dP6d3LLE
qjWQ/WNN4nUWQC0lnqp+451eIbP8kAvHkmqZi4IsRvqh8aqDlxMM61O1065lVTW0SbRdPQSYuuf8
SDdA1SGJ/Lv+OOLEX+ZHVYn1SpvUcP/iQt3O9x7ps+Rc9t4hxOXj58U1xeb3Rqy6zZ/Kr6cO0c8m
/T/pf92bllDENvwT7V1v1/OSTN123nupb4YlQZrj8KzO2CUw9AIm9fvXdfaTi3KErejem4voTlRX
owxdbP8NBXJkA6bgzRiZjVt78YcO0hG3qDph4olKLaS8IkAegbykU0==