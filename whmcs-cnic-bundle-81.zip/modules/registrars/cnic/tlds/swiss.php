<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPolcnGNRIpugebTG9WHvC3I5V46sfjDGoeAuA5swErTmZqHIk0OHWkeCQRHnEeIJw/r+QhQj
X2+Bp2SfPsBJ0vxYrlSdwiWITeW9whzA9GvEyZyHMUlx1h+/xuo8njnurw2Qttf1fdzyRgIYU3sB
HPqsn+ZBWD2uls7wiRo6Smvv/objzoJIChXyXG6I5YU8qjE1knW7yhmA8Uz/jxO5icg8JtOihfOE
KWmgrYMVdyp263trisZ1IscYf/i9WMTuD5uIDfCLvma02ChHsZXShqNyG+vcW6btUGXDpDU3W4Q6
rsKYYLKXpFraJSwEL2Lorjz1T1Ogy0efJGr774u3L3v0V2ukAMoIvZw/nIuFYquv+wdEBeNEzHeI
YoS4wNpA1p7I48ae2/leG5AWw7iHYxXKLwCSPLgjvqWKFx1+6GwGmEG5rWvN/yzZ5xH4i8aO1RXk
blSd9FHge9Jjw956D6/QX7akKbT30y4Vj6mmWhOiTGBUAfwknsELkX01KWHgOPw3znus3hrenLT+
xtG7q0M4uK1MI2qolylYuihdoXbszP96d1B7z3XiYjGIb+QBA5BJCpjeKyjMkEN2KJXylR9U6RdF
vyk5NCFebkIM9PS9sTp1bTTOr4r2wBiaOCPo1WmPXvLcn7N/fdAlkNMxvD/qNzRXnKw/B8sADPaT
7b3fhzDiiGcNdA+FkWopSqJD87/I8jYRYjsCR08pneHI+asambMqGtjL3Eq78a9MCsIJ0M9rRxqf
IB7NVbkYa0+FSxft46hz09zDxc/U7GRazWMP9jTx6kIs0L+xYhWp9sk1GDPRsI0W3aUwHI7ow/W1
B43vf/yR/G/tlKm0+6w/bwHbpxLli4FMny3BKx7F1q1lbF1o9GYxfxEqzsYqkpNq/VfZ/GdUk+aV
PbrF2uwlDejYjsodi8NunFqC7wtGz1ZkUF5/KHK+jLGn79Vtv0MqkgDEe5YhJ0Xx1SA7WPEq2UEV
ljBKRgcA2Fyl07zDvhn0VunbUYXS5dbb+1GYH2mMo4KSp+DGfcVBwWvhqi0nh/MHBYA7O7inIn56
H9sQWtITh1o3R8fAloeiw3QRwmekqHZcatvJ1ovf3mz94hREPTDVx7sVWXCmpNCXrJTdfJYUM6zh
5MGM66cB3tGfblYrY8cTR8xJKMMO1qejlpYzdZJwTmYqjvb6kvWEmMsBWizJVRekksgY/4GVLsC9
dU0C1rlD/Zcd9uPObhUuSr4rP5vV+ciAWAii49GzsihV91c4N82alv0QuMdCwNC1OpLSMH+pTUtg
Qp5hJ4y+DpUUmDoyqDxmdex+Luf96imxLroL0dOPdBLK4Qn73YRGjpcA7fESdGU9iXICX/oU/7uc
2s1aaNNdEAFOOhq3dTaMeviGVQU35Hmi8l0QhC+QoBWpb7rX/OQU1LKL5ZZjwfOYu4CG2Wjsn+qr
BQdc41W1bQC8NE6Y5pGGZqHC6uGRVNMHqjlzi/LC7QNiHhVKxsGIZMuvxJB3bh9STJyAAVCJByOo
LDhaJy3pd9Cvcc55ORe1Fux+plRS+hVyFhDvc39yz4Eobytr4LiUTeHTVRaCl7lCaXG=