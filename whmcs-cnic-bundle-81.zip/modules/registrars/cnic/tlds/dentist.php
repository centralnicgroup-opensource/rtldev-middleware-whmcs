<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPseN35IM/VIRRw2PTnbMni3CQrUriYXc/kew3MdLYvJ7hsLWXhG0E7QrVoV/13WLOzJakWcT
pTo6GvFtScOPnnP1zjtVSJwPyskMTiTty46VhzME2wzzOYxJHzK1fNcm9vEnw/KUJegQxrn5JKH9
Wuy8eFzMSxEw7M3z/QJ6I5dTRKaF63qjzeGCclbnNXeZc29Ao67A9gwaGsvGVoi6YlsZLd6V02ih
J3wE4OQEkHyMa+YQmf0+gMD4/LX311T6hYXaH3QJ5US900ZAqTeuNAz5/4D2PL7pY4+WOOKTiLH6
XbA6Ls0ub/DUPmmvBjZcnZuNrNo5c4AQVNJtirl3adpnUBGHGuRFLxILkgU9Su8JsM0tS0qpLF2L
ngfaRG797CxyAYxQntPtiU/DwAHgEJ1gj5GofFd2CgRQ7GjivC4mAywmvcINMGOKYQL5tMghFji8
t2Pjgv5x/LztaIU6d4o9/hmwz0pTmPc6VL7q1VRVJdnkgWl+6jto23HkGWrtMyuuQRgn/TuUQW/8
PhWgQ81Mr/iLHnefi32+aI9H0yez6eIcBlOl63dRRCzHn9U+tY4HA5FuEVLZ3CHRBkFRW/z5YqYt
gRtR/zgRWdU+IfVYfTLKyZhW+1jUfB8/HTTh0V4Y/3bIOoyGNB9/LlLfcjNxezY/6KEQZBRAvm5o
4R7r6Is2tSM8LSuoa7fdLOlZ5prnaid+2srCC2kSDK3FrANAIjzJ9FTmw+1gOSQIEfrleah/nO++
OHBaUsxgYA5FXnwtdxvo2qIeFbEGuzPP/stPagmiQR/PZkVTZrTlTB4Vwdj3zJw1oz4axq34x1k2
Sz5s0BW4tkKYYlkpsM+SGF9LpsNnNhdjjClM4Yy+cxs7jNedY0pNhBCUZ0RL6GHFWeng75g6Eo9P
nmLXsnBRBcSA0hN94+KHf7e/GaFoWum5SJBVeb9fxZ7nqIpIBRh/uRgONJhjDzXxBhU7saBRLoLL
+8UmVWdlb+GO0B72uAQmlNQus5qG3h6z/bG86nVZzrqbWjRKuvsUTHVCOBf8DTBgnJyqxGYAJ+H+
gKp1Ko/kqRLoA7FK