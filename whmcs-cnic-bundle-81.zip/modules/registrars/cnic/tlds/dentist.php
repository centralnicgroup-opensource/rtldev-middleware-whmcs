<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPprhg2WjjX0FADmz2wgmj2D68jJB493/wuguoacz8as8ANCk2ZQdOgIhK0XRe1nzmLFykivP
vkgTuLcT2YPeReEVyVGEngL3HCou6uVpBSzc5keiVLVnXcr+2gPJ8luvTgYK0sytIizN4UfCVS4K
0gRuyjtuNpSxM46lvXVqlDIM6x58xxVgB7DjrZ2a8Xjg9kCsDD6FpJFPw5dPWiovKM8B+dNFTKro
daZ9+3CvFo6hS484pj/igkbOw9KE08Y7PGmRuILhBD7UNf/cc619hc27+k5dAilrHxFTLxT64dc0
cGL8//TBEqyJQhxjkIZ+LMAp+PXhgyTw4LpNBAUahCpbLMHclmRIxOoXyBROdTKcdXL0pYyL31OJ
cafLcTqN00wJtXdEsk8j/3gM3SsM9N8XyZbL+FAV+vXZzPH6lVhACz7/QHqVetkMBfl4OtQ1VcxA
T4eQO/dFWHn2gtowDG5cEeRsigemYwrpjua6zJstKmxV6O6rrVnwdCGOvIzB7xp1aLwFfFQpCsZ8
Id3CMRCDNEIOEZT0p++c1NFxD+F97sPJcjfx03v6XyJtYiYtW3jgAxAEeDxFX0y3iznV7+Uu9bKu
I/L8WN8RjUeQqyUs/OGb/GyELoy8QBLyPVeai10jB4Z/UNvH8JNid6fhAf0fwO5d5hZrbbF0XS3Z
SnmGpgw58LrARKOx6b9Z+3zEpapGrWhga4B4OxV95jqvQgzhrdna/zXp6lr7noZt+0nINhWxT0jS
cQd6u3IKH9C79vyAg5YCnGMqD5RB2OgJ65dv5cgaq2bAk/OLB2LrGv+0p0U8VBOICpyPiy5x5+4G
XsfOk85aYdzYnonjAn294aEdc0SeKGeDQLpnByi3Uu6wfV4ZIp4rEvE37vQgiP/oQzwgdV3N7cBo
tCfKeSJ3HF8zuoZ7zHExryDo4gBDO7UG6z3vfxT7em02uvgpK8B638RRbVhg4GPpjjMn4jN4dmip
iuN19HxeAYIzyY+CVBTCH/1x2F0mwJOwUPmS9p+AdmGfyMA5U089eQT+mXd81/pegQ0JwZa=