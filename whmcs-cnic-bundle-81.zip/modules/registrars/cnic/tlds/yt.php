<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+EB1cSsNlj8pqIJHEDoczVZNJxMf3qFNgAu0WpcNggfACjNqm7WLO+NNi6eKE77bqA7SQ5Z
QBm9DabSZ4bOgrnmB8n/Bwp0QlsTr4ZblaYiE1bGiNx72+seaOmpDirrJLkI1ReYLAUSsiitLGEP
CKwP2KsGaWuBMHGOEQxP1d79f1LiW1RlWLv6nUYGfY/2jMMpAnwKmje4RjNjOU6PBaVKotzMFNHq
u08wnwKc8empGeiu4QXM9WBurPMfVuHiLKjhJpBNp7oroBaE/VGDitMnBqDa5vplbNhlMzRTqqS6
O4SvyYHOQHLscLk27wvuA5n8S9SfUe9iIKdTcfGRMsmkXl3QbTioZhMuN4vyiVSAf/jyBewZSLFV
jNJ1w9PBSMjtDtOAi3H1CNgjqtEXcya+XBggiYrcaf7O9uqWq9l0aaUgRsG8Wc2NLhQNYUQ0JjEv
HsORSlkgVD12JHZS1l2mGXHoupXQ88oi7cOOatNQ0gUqcCDEFm0/jfN4gOo8X42YtoxYjls/W0ez
//SJyJ7SuMS8LPADwxF18nd/khrSuMvEiZiTCs0IJ1fEGebF8+rxze3yJfDzRDok4rrQkduYUKWn
iCs0oj7J6jabsGiCroX0b7AAcMuK31HVMqoLwX1g26NSZcXq9f54TEAMuMiNgEN42zWdUHV8hUA9
9nxMxq27ftzZ+iLyEdXE2GusDZKVA6YVJ4x0L1yxuloMEFSQO2SSXdOg0D8fMMsipbKVAESWm5eG
vrlS44eoHwFS8hcflU3sqfHNr5I4XgiDR5HWnDR1wi7dW1mPNag84X8xOWWdI7FTz39u6X7VgnZQ
OrC7bHxhM7gZsne7TgPwfRA0S7p4G2989dqiQ67VlAaLWsaLNlOJ3Te2BTAIQ5bEleT/daD3ClIz
fnudbe3NktR6jdkf00hdphBAOoYCzBKuCyGH0K2nXvneq+zLvD7WIwAxvCXmo6/6v92YkJ7Zcx3A
5rkCW0LQ260ArZkVPqXr4ey0k3RZaFOcQ95gFdtawjFsNVhSDjPvAjT3/xNKE3uhyDyR3UgE784n
IkZF3o2a8lj/fpN0S0IgK4BU0+cMqvUEFL/ii+g77NwsYiZ7H54bu1uEVZcYiAe92yTpjX+ykBu9
QiCQ1uVbEV1j/xUx5s70C1iSxTOCis40Hs7AgRt/zirbW1oltHQKvg1+zFV61/lpLlfW0gMGjWdO
TceBOlgNEoTrIfVdvR4Gwoo21b597mpWGrBxKqLJVcegjbvgLgnGNTTLJG6l01aXUEApIfFrGi41
l05xxSAzCerGG8p/t/oFycwyoiEQjmkZLaCix4jQ/Qmnx3h+1k6uqcsARIfh/mL49yQ2vERdBB+A
1bD67PXjFK7VR0R2u8NcLke+GstwIB0sJtEK+upLPfa11ceWKt5b3YqDDQJeTgGnVKkQin0HsqiH
8R0CABPPYl7HPBCtfmB6YR1IDxiknLTEvjbxlgpNJAqUlMnQZaT/VT+BO8nKN2nt2gcHNHO4CoO1
A8EdoiZFJxt6+PlmeinOqepWf6DkZBkW4YncAIfd2cXWlIfx6j7fNo8ZOodabtAUjiFlS60MPIGZ
jNVd0BzXZ2/F5G4brY6F52yT+/xKTszok/wqfYaIkxFrxKYkBVfxr5YgGhnC3kYNT1uobnEWfdMG
qWfrFclI7rSNmjfP0ZUku5d/ZiWPHpkAY9jwGgW6jPzzSTZPphchkTNenjeYoqYNQ/Q4y6dtpFO1
fdS+V7Al2qQOFNvu/j//jyTbMIXkVgzZ/j53ZPL7G1xvz4l9kPOumSF8MNV0EjHBylL+nm9Qm7vW
jhAcBDmDWsI1nvTu34BK0ZvbCXnM1aya2OqWaDQx27cq1+x1ovW/cUTOfmfvLvlxB2Aw1np8y9xo
HOTcZ1sqLL35xsdRIwuAw8d3dlrJRrLUU8AJIGGjSskShIgIZi6kNJFx1eOZGyp4UXl0Q0AyuLT8
ViB6d6c9jlaKUsZ7fFnMItxpeJa969AfVIbGn7cx63EaJvOGgOa6R6hgEt+8T//gBwxku1opmMN6
GtNjJ/Q8H4IwjJ0JBXXHnWXxEF8+5HfSapPLDk20SfkSLNOQ59CD+t25tAknJal9CXtV1pAPtR3u
wGfbXOjDrDYHa9K3aQ5ume2Ed/MTpFBHTWiOByEf+o+6l2pY5GlRZOThzfA2kOKk5LibJmzP4B49
sdTCe+MbrZPLADLvuNCRBkClYSACSFhldUpJRx/AGEFlzF4gSTADZ1FOBkr2xCv2H/44mf3g8ET1
vO8k60qYYvlYcQbAtfEErytQJqiBD1IqByowtMChp9XA7LspJlx/rTQ2//37ZyYQSjRWokcr4dPO
K1YabC9qvJHAKYc2G1GPDHafPQysMkStdsbZERp2xI/f3lecz+VF8q2hvdvL6HgQqLGF9YFtKuLT
JdDAa61ouYCIRnc8qCd7YlN3qyb6den/0+2+iDhz6n79EKz3WG6kNfdCRl/lvb9vII7JGGGOO/01
TA2VZNihYLqocLmJFPs+KgUy+0wi1Kv+opy0jRD6Y6ik31Bez4ScaDNVss2M2fDgL4OJv9DmYs5E
gAURS8fCnNZ+ciKWJVv1RHL6sVm8fov+episLXz65Lz5Mn9pj9BtWBj1QLsCrYRV5R1G7VdSjRe5
8txexByxa6rCXpAy08y+8qW3N+pOPnCxbIh9CWcrrOxzNKVYW4CnWtz0U6bUWlZ/ltPGjDHE8WW1
o4S8vbhlAT6/NKBvmG56rQVnX08RJy7sHu9xdEU2X0ipSh1Mmgvk0tFFctbP7lsEzO93Z1OtgPCG
dvWMPPYLk8AwOLsLMV2zC2AMft4iX/dpt/kNJbbyoMzgu6z55BbEv19L5Mj55YnJAA4ir/w+Fg4e
GQFEVaV/kMEH+L+1/0+cagOCkpIctg80E5ULp7pyWO/SsOLHhOyi4xumiaeksCPWYOds7EkKwTZ3
N9TjYsjzlHbJnAktTiy8LlVyxUJmHiQ7fEfVPJT6SGoYjm+SnyF+5gRkN1vHRgBtmPLn3pJK7lNk
7gSGdRb3UKeFXfU8CJ0qGYlotfUREEwS80QYDlygv8VD8Ux8foP6pKE8fqYsM4o9Qzlkm2FBz/ne
DRzWVoYdgzr1VgsR4mX103IvweNqdC1sRGA6WwhpLrIl3/2qiR2pjivaRj2ba2zCDoozKk5nz1r2
bzWLA69sEy1iTXTwSBk9PZG2Y9rXlrOX2IX1ookYlcXTfy9+OcfoSyV+JfpEsz5Fw6VceUN/4KnO
V5NArsYo5QMD4vQGISFovfUVry0KUQqVGSf91aNspHXqUtxu+9tWJ/2WCnM8tbDTjVoIqcJzROdy
DwvbRKxfmYMR4Ovn/M9uKm9s9wn+FuIi/2DTPywSFu9/XkjcG+0fuyv99E2ZM016DnEnjznTgV1m
ZdRivmwI6p2LVJ2qRp21o2r1lhT7A3tLX8ClsQU1gojeWQTzMFZRWXANb1CPxCwqmSTy12r5zWtV
PJewu0JA1WGjnb/jBZquJugZx91SG+eVFQgLGaLwLwl3JGNAQjYfRC2gc0xecrevPmQCUl1ToHY7
wAtGpg6+1bnOfhDV7pw6cVIFIAzPsD5SHAZ8lBIGHKzmPLZk9IC1xJ+m4lhcxkiVXCtDNGw1HNl+
YVKSd6qA3PTmk+wSejgJi7lcnqOYo4fPRPs8qwerMXlIGSKUHDYD/KkVzkc9EvpvuI+6cU1EQH2n
mL2UucOjwhzfFLJUBZd/6tE20XygbojiStdEvd96K7iognaTY+AIdoXqq6cCNjWiiUHkzQRKCkjH
Fb65kjZI1xwLa0/incXdMomHTMokLLKxflsxbIF7jW==