<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxfRkBbufm2+1UijcX9YYvLILwg0sC2kOUOSLfmqrwYtxsuknjq2FO8XAaUa8UqFlUGA5vV0
XOsRiP5lgFXupj3KKCG2n8ErmxaLNVG85im2UUQNyutPj8w5u0E2Egu/6Ysq+SvTUDZR/VF+X4MO
5QsBGczP3ULrBzEAQ1buGqzkAigmc4Qo+RNVcIcC7XfjhVUWOE0ERlpr3vrvv7+bg0LrWk/i7Yvw
vq+VjJ86TdatC+sWU35tnl2wKyK3wAKHWUsD0pQJ5US900ZAqTeuNAz5/4DGR6XTgw9r8NRx9yz6
LcG6PeTyyLjPBF0p14llsnzLA+iK9EsybGJ1A2Eks89U/o7s80lB4qO5GGFKqJ5FQ6I2hNy5n4hN
rrnZ0k+suScZhfDLIEudkEOAGbqorau9q07s+rddcwErnqX/5PWk8ft22srgHHzAE6fKxmf7+fyT
jAol6vRuqhHUY+LIwj4ZDhAvA5rm36rusaw6+XznWAG1mrLwYddytG9I7akKGBhwJ3jezvoON14Q
Mrec62eu+ayaaJVDmR12ulZb2AUAoQZYY+xvB1T3qSSZRLP7JP0gNnpMTtsgkwUtuNvEKYPEL5PD
olUnQ/Qq60EXW4MP0JOOGlMeE8fRdBR0r11NQKMV/J03RFqdaFju0KMVeWy9vIG/fgj/WKKZZxKN
icX2YfecmnlMnxb1Npw7GO5xVvwoCeY/hLyOlr0fJO6+owxsW4wUi0vRysnsgtnCB2+aKhtK1xIj
BlYuG6WZsgl7VZuIyczD6U8dAR8UjEGrMw3oaZ3peMli6k8WTJAkwwpWkQjiIKe2zRoDQHDO1qUe
L80Ay8HSWRfLaoNAxS2G6wGFSh9eLTCNRT4RC++oDyPlH7LllGrLpFsfpL9+K10zlz+hx7qaAgoO
NDIs46fxkqoNvbv1Jirf2V1MCTjDD53fxfeFFZV1m2G5/4fFYBhebIEDT11sQoLkCnR5SR3psXys
LMVJ6IBvhet2UPMC0DECTePQYYmEZ16EKmuPUJAhles4Bo9vvJgyXL0jq3svOdGCMFiLRIPyarYf
MRKfIh33IWD7amhZOIAeytkQyAWzrdv+BV5Mb9MZgoqGy4RRwhbVD+I9Vg8tA55Mzn0D1OIE8Nj9
WMaBHBKB8eH8jkJV0xE7/eZFSw3nW7IUrZFL0QtvjOcJBVS2O21JfQ2fTL63tX1LZlbW8A7+tZ59
gjjuYUolmiad5F0HOzv7PveQaku5QP70hD95jpTL2xi=