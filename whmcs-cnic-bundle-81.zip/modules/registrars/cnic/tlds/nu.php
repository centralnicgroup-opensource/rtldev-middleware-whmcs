<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrSTIW+cvauXlwpVBAT7B3+DqbZ4PXeCuDDfWmAlKu6nCQsezUeb2WA9DPXK+fOpZmZzRsZK
+j2eM+JlFulgImNbsAxwtkK2eRWG8M0ehDC9i5c/IMxtocb0Ew0ky8tBx4gfp9uZZOjEYmLghKjB
qnexH1yav0yBx9rRYi5RT8f2j555hquqXmI/TTRA9RKajno3Ot035QJmS3XjjyusHI/QvA6BwbSX
0LG4ELxZquYxiu8hUevX9fwWKp0pMHnSgKDRnE4bQopHtbwVvfXWIQvWX/hIPVg40RhShsWcSlXv
yAT6LV/x307HSN7RrP6MX5lbtJRs3VxafmjER8PAZygs9ADd79VrZLugD8L+NW6nvWuWJ6w2QpKK
74Ee9J8Fc/sYNA0G+tU848z9e0drwu5hhp0CcGxztonYQ1th70Xt1JUAuIMF8GlQYp1Bm+NHha4O
VVgVUi7Uz851id7OAq58y4ABHcaWqdbDob+Ra7LC7y6qQ5qRHixQH1HNY5EgFgrE1HCcmhkzufNl
KIskkps/h3rqzM9N+Jgzt2QdfY7jmjUfcJMAmn4CwDn82IhuYvZy0bTilomTxMfPF+8WKSLH97Oj
Ppy/805UFgH+wODrXLox3gV+5iu/IT8oTfLVZjSVLsH0/u0tmW+dam8ScgS8mjmhdFAgER+XNOun
G4hKWFmbQfel3JTLFXoO/mjUvul7qqzjvy/FEUgmlzxDQJX8HldQVcZ5UsrLQMAek5pWdzOtSXWn
rDXNYWv0PBOsY3FisR6iPVZJ+szg07LayMkazdXUREl0/eGzT+yoyeBr/zvBALzBu5OZs9LeidBI
+5Ye/e/e060YERZKeLV8xG9zQe/+vvjmvOfrAX+58jjz5gFlAbqLHynPAx0EmmRWIzQ2UOYGtuR0
GlM8Fsn5Wp7NrXKgJZTrNX8FmOp3MB7UY1tiPqSK5Lc8j0Jv6HPfT7K2kYQl9zndAGxjfXn/pzW3
9ez/aNFnRg7NTsDsHP/8jg7TKm+eygWDrgTfJJ5xKJ7/vtORmk4xH2t1DCQ7TSzLPc09OQwRYcsC
7yKHEY0/1Qy/CT6MX/OYcRw6Rg0gQpP6o+1HcvL6Sjq4oVSRiScLmsj4jDpZKKa0RrLiXtapgJFs
kPFu+/ejS+kArp6BQ6h3mlVNhRFqm5/ZmIN0ZsAG5ai48rcMS0LcI5jHo4LEuraCihf9vWWRmf6h
Vyqs/SG3lSy7Y3qMOQqr/7sSGDRmXLA+z/BVLH4WJfNjfLpcTqa769Ds3rulUaXoSSjfnXkmKx3q
sa5wd001zJKuKlYaGdwcTSKVWvCn30sgXVtMHqgW8CkLQ44oVe4C20oJ86x82uI5dim2WiW+6/R9
d4ywTmGpLqVa2zApU0lvPgR1o1LKvRBmgTbslt0rlKBihWaFw3Hettx/RaCRxvAwEU6yJyNPphHQ
6nGzIJPM+PRd2TYbPY8IksmtXn6NVYLOfruvQkc+CNmdJGy9ii+tOUhD6o23Nh7mcBs6cgcUycmC
Ol2gyzCXBYsrlzGufT34O68=