<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrBiv5QZCTsPkbrnTKCkccQyf7hTnaCovVKzyM9qDpS1jOhuzfo5ote/7+ZcJUPfpLnhc0Tr
dD5JmZFTYDAWuWNMxN7oddeSeVtDRQlfE+d+ZCB4pK7sjBvwZOt8gi+4uV2huoIQn74CyWvWEvHW
qXbRGy4c5MTOlQvcHcMWAJhh5GVlACRtKtkb24WUGov14Uf+GEH1EQuU4Np2Eko5hDTSJz8czr0S
Mdd91ouVkHGbW6liLhgVd3gq40zxW93wV94OIJQJ5US900ZAqTeuNAz5/4DPQm8r7fsJ2x0Ie/96
LW46Tl+osXLQ2WyEMslR79iWd9Z8hUyQSgI3xpw9gpWwP+Zww6doiTBvMX6MuZOitWWVpcFySPQ3
pk89YO031SvUkOua1AbK6fCwWILwaCTflaThw4sQw1lEZ/rfUUnT9c71yvYmPmRtywbxPWXvqFpk
dgOrB8GHFswwfQu4qpF7isxiuspbKauSnwawkK2Z0w/GGYBk+/pyRgsB028685g0y0CvTsSYaEFn
Y+lFwyagkyx5oAoAOhOiLw1clyI5V09sIQ8qWAP9EYuF1obmYxuhbMcKzZ2vfpU9cl3iJMbQPHaf
YxAjsIrsYFGn/eIO/fZBQBpgm/up8kLUTUTphqbZ9rzB0tBElOiP8MQ0vDG7JhPr1JYGUrM2aBLO
tcedC/cBjtfv/R//4Pslge3kv5d0CbyoI2YOeDBoXcNdgjW3V5onlG58Bynpx8l2+os2CF9rwWBy
1xeWTkWKCc/PBmBup58ehTVYVPbycem0NW33PvM1wnwK3qflW62/xNwbwooTjFHJI9STG89XSEnJ
WflNjSCHQnsGryh9iJLEhog8iz9fjpEscrA0M55cpSXRRdYFy228JCosPrcD5cAbo4LS9739OChm
4AZ2VPTyzVSqwcCRHj1yYcGwy3fRb/BkvoiT4lZECAgecMVaY55sLYCPjJuQbVVaGL/JmGMcYJy5
pqc5OmRSeuUVNLt/qXQQs35dJkwE6yCv9UrTw/TXYRdoS/Xn2lLR7S5N/Plv1B1mjzZyva1D42xo
FbuBwyqiFHNvYn+WHLCe5Z/DQxklEceRqPAJcKpQ7gDw1CM7sxCdA92I9Ip7OMquLsUyaF8nG7DH
Vvl1yCPCv5U4jG42Ief/kPDCiqS0N/3lCzxWuvI3XA4flXFqrQu/llwDvP1eanNhCeYeLQDt3Yxl
Nmn7/JMH7NTXMCTDevZseR5LV8H3u/6oNT6FDXS4OqwtVkixpdozITWGJe/6pBqV8H/n6XhNC7HD
R5a9EMfITkMxkmR5mjJtMHqzU4G/ImZK9SZnbHbh8WJsuN4pIXT+Iux880pLvr+2slqjDL1vAuzL
1DKwpUjrZkx2GbWUj9//MMMfxPW8BL0FwD2P5fFzDRdOkCqpRumVfhIpPuZGnE3NI2OwhHHhPpxS
8A7zfqEznKqLSoINOL06MS28BOehwk1bNYP7/uY9QbuL3q6hMSuQMJsPsC06IfGmMFb6XOcBBvfQ
ykCQO1x+MDnmUOYHkndGMn4=