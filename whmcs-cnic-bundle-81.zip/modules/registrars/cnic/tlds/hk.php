<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPush0ifdF/VjVcENwLvp4FmPj8l1z+Ks8U17onOSZZMYyj+j3iAw6rzD1aaJHIXTn5tTBVzn
VVGn0JdVqBxCLrJE+EKiwUgu18wXEWCmY6rVRbBDeoapH9rY6fdy8+TPdMQ1SCiNXU1sX8XqNu66
slfMtGQFsifAZk3BLL4E3dDsNv93rqhoZZRIxAD8IIbPtElpxJDZaolpKxp2ymD5dIGBAxBhXLFN
fYOkKgkCEwKsRf8opPQkce14SXJjJzBBRhueG3QJ5US900ZAqTeuNAz5/4C/QS8fUBKMx/GCHqD6
bcScErN0wcKoBCcwLAGteJ0TXgjPpAFc7lV1/HFOVn+S5dcV861An+Fs757CAFFNNhS+Dkjzkm/y
42Yz3A4Xx4JmbVrk9fdN5X85a86DH3sWcnckC3vrB+XhctD834bdbqvW4VN0s/QG48W0YG2A041G
sCsogcFxMQAM287JYH1EofZ1FGj3mVvr/k5mAyYP4cOFnS6uoYHLUiSgL8ue7On3C9E+u1LEpP8D
to4g8mLk3NXtsjkXtro41d/pNxrmKaM06of9uWkHR861XFO9bjvFnlwhmi4syLr7i3sz/jn1f7vV
sm1CLORGw3CA1j/KqbT6yQKfTT20fMobhZsv+gFX5SlFbMkoYwH95Z5OwM4fv0kgRLzZK45SoY7H
/SpvkGwgTSjX7101Moudyy+UnNRHjDkkqCZdbn+1Ka0ww3H0zP+M6hwamaXKm+IgRxi/k78v7o3k
Ne9DvCYmJSu/mefWQIUIT1DQDMSPzJakjqAWk9zL6y7nFe30J9f2qYhrD8kKAf+blL3uv3uY9Cb0
+NyqhnAeEJelAEkbwz9ksb+ID60WJqXWTj2bD84tSLQy73ePfarcXLxdahNbDkCrUa5jc5Kjdo4a
aIhalK+V/q1iD+Y6PuqfcQRkaVqboNXEpl/KKVqk9YSTGjRoQhV+up0IlVoy1uQM/7Sa3DCnFiz4
grUfFr8zQq4CMRcNZ78cwf6L9QuOIwgZ8w6jbv0SOhB2JCyJ3tjR1ZKdqIAzzmxflD8jr+UgjZcW
5QaafP849z85qZ84Xf+99KhBhw7iGXOux3Tdw3s4+/HCwl0RmW5g1WMCRJJnea9yDYsXgsft63dP
2bliLYq4eG90NNRssRMkamlknF4DDWfm15MofdMY3GmsN+BzbjUUhcfAG1kxatnOEpNz7GH0bRgm
Zrl/07yqEJsEVe+H6MSBMticmx0Tpek4CHZj9rOjkX3TMAx2f75aAaOV0GaZ120rQ9YHDbKXeZZd
9/dBZ9K6HAUiaC5Ou6UVRtFfENWxlFmiZMwhUgzNbS436H8EVZBeRCosswUfmO53qe727K0oP+6F
XF8KIwHFbNmju7P8kdWp0RIrI38nf62HnTFgspyzPo3Mhp6EjGTsZiecRn7iYbcwrjge3DdnB+Wd
sC0P8RIkYF5SlDVC2T6jqLZOalkMzfJo6qdozUHvJGvjHcZAC1ZI0HLJoOu2sQzTjxbyDWFpTcKG
0GNDf/ILuMZwBQwSsW5fxWJ6prBsdVRmAYWankYalGQoMmIyLS5tkWjccmSAQH7w7ogTgtV8rj8V
Y9ngHGFFy401AunF8rkueAUVBNQdEziv73Iir4ZR4tljspP/PMe0SLSqWfZiZP2ttDkjZF3r9Xfc
fA8tWIw5/HpPnyFn0Kemw+hTOuCDw3+vE6m369Wfds3zIIrJbmcuavIKGIrwwIR0NNEQioJPeGRr
fJsesa4zMq2P9InbIqd/v7jKKhlpqNxNjslQByOwin2PjYsnuxYjUxQLmvc2LmBEMrjM8mnUyqtm
CJHr+L5E8zCjC66Jw9iVW1cOMQS16H+DVLML+BK9mEgNOaObf7x7GfTFrBv8RmX7K1k+TIw5mf4Z
75D7+La1g/SsVLqJpg2fXznNhbRIUXQkO8kVbHVTBrs7bk2uEkfD5qg4OKEqKjCHfASi2Od39KOF
B+0zbaKYvzF6IgB5Cd9pfmBvGJcez+6uqqCiixM1Y4Bk09WBkXieqczYbQXOsGR/xAblUkY4ZqAU
NLHeXkF2j/Oaj+WqTF/98PLFJdwlqzy1VQt0vPKsZgx/mz/hgrOAD/WfUzIErA7Uijb/QwSOD7UK
IiQOSMEGc1hqX4xx70SftIkMi49Dwow3v6+yRv0LSaXZGgbB5tcjJwYWx1yKJL9kbKg5QJjqq6W5
CSD9Yb9rADpSv8XTZQGAmL/927C5xfr/oBUnpYacP4zOb4lR8IIKp2aXeVV7QvZnAE9IyuGFcTtf
XxPKwEyIIHZQ9HwlC2TiNl9fWVMZlsaufJ0ZkrVQ2tOWniR04ikbueALxkCY8MeJ2eJ0yS6brRA1
qoTh/GZQER0QBvzR3yx+srWbD75Knfr3UhZc3ZVnsI9qnYZtkaiZMu0B/v39fj03e+QFsyzHKwp8
RUdc8xe0j5RUeFFvzqjz7k5/rg+sA+rM/m8icoazi1wFWjtwFnKlOZlETZqTSExQ/zexW21kBSvG
ZGiCFfErew2QEPjKI1olkkJbwbubm4S9v3tVaiod18xE5ecotebf1nDTUjX7cYiRKlYP3e3grO8B
LeoNu3qhRy58PVTllnMtKkArYFWTBFv52MvHCw9k1quWvzKB+g+bnKsjbsDX9q/S8RmWXYDhfSBw
0+mvoQq5HOmTjX4CYB/Abp6R13WJT92OdvUCGfJB9eR1Zh31HxJifdbPEfzHArN66UQIOgRXtoZp
MZ3xvOuQ/xIctn54ZMLsYC3Dr8uECJZJsVodQtYgLsZyZ24F8dS+ONx3sr08+S0+61wZdmIeBpK/
kQoxuT9cDw+M0W78MJgNdaCbUeVGx6wHyyx0Of4XklDI50yJeT08GAP/EC9LYyPoNe8TXmJItVVW
pRFZ52gF/c714MLg00C1sUVID8MWRuZVVW25qn1XwoEbTaEAR0Ff0gRcktu16HJ0owXBRH5fdeF+
yyzfp+HQQ505ZY2FCwO256Ty+jk2c8K0COHyFhvDqF2OR9qjAc0gVzcC97SWNHxC46ITCCFtsm2J
UN9M6WHMHxXpRhTSCOam1/Y1ObwaszTe1soVyvPIOm9ALNXlCGaUdHBmaCs73/zIwoy8lSAy8azx
8J1nkiMB8+t5mWDCR5uZkPm307j8Lo2X/7gPuPlosvwJ1lIPpdRMnXV4Js0utfTIG5DHKn5OO2y6
3FbUTiF/wcKgnpLNc4N2ePaYArG6Qxapk7daplzDR/QqWDLPEWHdra1IT4c5FnnA96XCKUqaFSi/
Uzs5QwP0I/IdOudDaytHwzSFd3UmTaasVsG7qTfGX1SVNPU2HgHKPIgPys/5TtvIJcih8erktBsa
MzR7wu4xj1uh93+UKpXF4pi9AHy4PBDeCj5KZ76EFHFTeyd4pLXfL+e/diag2sYqGIwBSIxzwS69
yXOKgynLqfF9Mpz7uDDuwp05b3vU4GHDjZhIzQADmBa1uQyv8yaIOKB7IaFge7RwMLcyMSA0iyta
DD0nd34pXrlm3GxBS+sSBI/UImHy0MFC0vPSkd+WaSxPnReaVdEUMbLCBEIbZm9aR65uzuBlp4B1
HeTOfrTqBIIbAsPOXkjO/nXR/BMwaHMhKTNbs8/GqGylsjjs2TTKaCTuMylpuJwALNCHiKo5jMbg
y66KjiI/xYdZ4y7E/D6y0HyoaVnKU4HH4RSVme5eCVKg9aqPyM8s0JSIpHoXtX+ByKqcrflcfAQU
ADsXQ6cPBLt9XYth+rESqhx2wTm94EJG80gU2fauNeJ5eta4brEI3A8oMqc42ySK1orRaCokRDNW
Cld3Vdbh/8HIfZkFyondldJCdLIKc+UTJt4XXc2sh8911OZUnJh56o9t0QwXDqqNmRfhtEktg88M
QBMGw8kh0G7wubT3+/Udlv/vRWsPmFVCO9vnxBx1BVLH