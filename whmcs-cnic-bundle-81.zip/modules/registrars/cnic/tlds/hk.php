<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxx6SvIEWqZSLmxcjwcEEq0nRICWVb8FVFj8ntrVCgTd8dTug7EPiJU4uoUGQpYBxTBwsjIt
m6Aa1as5kkPlfVNZx2/llH9YGK7GKhMrfn/2/l5NVZyc2jhs/UtugyUsTqkTisy1pwj3QlwVz1uI
0ADrdcLCI2OSO+zQsV10rqN+NDVnjl/BmKFqapacSgp3cprxm26YAlxG2Q6zN7yHG3WlledfdFYc
dKrjSs33PRYjzXxgcKbiqXkjiD7WklpVro3gNk4bQopHtbwVvfXWIQvWX/gYSxMoHGuOvv/p1Ufv
S4X6Vs7U/WCQ5fc1bqGeCDpD8c6dsjpzG2ty3f9GFMRQZwtcFdwJhqAAILDN1a3eGyCWp6PExymB
gIDdEQzD/99bz9ZRibwegU+6cm1PJqU/ria2vsZujGUA/KM6dvGDRgcunCuMdm220940W01GcjZE
M1oCEebN4Cyo3SqUk559GC0WwN3GJLrx1dLiaq3GAf0HaJSw4Bi+bMzftijCQOLFfxT4x2K6sZeS
bJb1+L9vCjJ4+kRc0/FiuACUO6OiYrUEEeY9nuVqbaPyZ4zuKUu6t6zjixU3XUrooT4oCkjbnhA9
2Arj85BmbMISfFJDoXqEcph28ZcorSARmZ96dx8Y+JPt+oviqI1G/yNWeuriAo4LwOFTG5OplM1d
OYCmB3yuEBgE7c2I1B1hs/FJZ9XBBS1G4AjXpuYPV89xPxkb2h8ZsRw5qsTMwtmKKZfJMUwFgLfs
eg/L7r/VyNJNrszjg9WMi8bWZrQMLWH6hTDvdRCJ3UZ6OH1JMofZPZ/dGRKA8K642FjhZ+9sSuhj
mQb+h/A0WQIwD7LWe0tHpUcWLD4eTF9nqMJBVMJbjRHEy04exwoxFKytYZ9VIivRp8xOPpwisGKl
cnQnguAdOno9RrGZVK6/Du2+miiZxZKWJd8AFORPmO2CRLixuFvg3QXDBEBm2FQ2dyo9sBlWPb4u
kLhFl3HrJN1tn3V/SXjhe7w5aC3MnlEjOzvGgUU43xSozs0R4hSuQ+i5VJXszi1HtSvoldAZP4QU
7nEpek6iHOQJOb5yD0cSh0FV2YwL5s0rQet1A0IS6THb1y2JCpjxGlSDxYAUe7K/id3XlXnrBlvy
WnGFYQTSxUp5hjbPkSroVBurUrIrLT/KQUqQ/pL1H9vau0MFyoTk/FIGJvPixcQuZpcqorv/UE4m
ommsjtPLx9ogxBf6AuTcLhxzVND0Ul6iFVLmDpR35jgCukdfiPArHzr0+JR0wSx1uwHBROQY1Y69
uHB+9ba8dHDon7pq1ujpaTeGQEOGcy6GBADKiTmQgOK89atJzdRiBLfIs9eF1aFDRq9xJSpuEHgl
ZXySHS3h3gS1rNfsaINEGiS4HweJGH4Wq9dfrkW6ypBcFvoKicigXeS+g4obCTxShjxeNR1ucMor
Oh0ADtE3lb2UtkYBi4lMHvgDOnEa1WDx9Luxd76QTnMuquk0/pNb2asY7bxYsZ5akqKgjiJv13zI
8Ml6Xn9I37pMhTV6CGhu7/B/Px13gY4CARtGhPoo7hvtDfwlA5zuyRILQakH4t5TRDjr1Oqmqlig
Jt8TkAwbKEYMhA78d5/T1b+WVnaS2ZALmT7yKTcKdxLfeSqD5soQnsE5CjgLuK62vCUYT6Q0orE/
W1Sh0B6cBHzh94y0rXTS19NJiV+SZpG8eYKb1JSB2y2K/LddKs+Tl/TfBlgpQap2jjGK3zIcb13p
p4oRMbwF+Cs/OSXz/Btt5IThCC9422ZEMEULsCGzpPLyKT3m1QMBmfn87pQTX5zos24V3p/Y/+H4
oSSgsQOiXx+URcU5zr8kDIxroXB3ZU2XpGxJsP9J0cMZMLMwmUXECdqSRAbvM1J61aJEraD5cLwR
9jqXhsDagwjigF3iYxUVNXTKkyjSs2oSpRVMFom6tyVC8bW9W2I7WH8668JQmoLvQpk0t6l6CNcw
1e7HVQHGNwhrB84pvzPmiYLrYFBZ9qhje9JM7x2jEr54h3koXpGscS872OXrCwirjvLNUXh/zkO1
74K1r6k35uwyOtMihgCMDwQBMwRAx9cVZ0ENeS/O2ilo5Lq0hVjrLdnFRHsQOv6RtrzkukgCXYL+
xrzf4oPs+LWOjPR4xhgeCSbfOlNg5mOIKusxu0g5yHbIqf9uhPZ3oLxnkJsg0rXpogmc+v5r0BWm
2KA0ABPTB6Jlse1RdDVJHZjq0Otp6GflymJ1kU33sQp3naI7uU5wtf+XmiJyLAjlY5o6/MtDqTGm
wyYnmlM2XbdA/n6vSEsBrwXFXaBY6S3GRc6r3+YFeVDYzvT3hzqhfhNGxbzWtvpMpfRCgCVXjA6D
oh9Z3afiPM3OLd7ZYe5Gjk4A8FFUeAMO8QLoH0u1iKn4xD8Zv1qBhIPWkmlPr8y+OTzXnc6NB8nn
GZ5S567/w/OmDTg5D442U2NEkUBkJWURxuHJPxHWJ2o4vD//hyjkXm3SLmHj6rM7V23kchkHScuq
4V/RoBea51K27fJyRaS40KigD2uPrRpttQoJ/rsqzT4CUcpXOCuvPU5ujSVJpSzs4+nzykT7WmpA
0ZilT+Nq9jo+1zSL7klXz6xks9E1VarP3PaJ+dG2wR4bsp5HLlKNgJwd8nrJkdzvmvkG/jBhaYNs
8n8SKHFVfk/4uWXxCzW3+wHikE+aA6FS3NWsHfWQJeHl+Dxz/KYmHhR6V+sn7KqZazv5u85jBbjP
C+cYN6+fevrp90Zrb9d2m5TThUM2hb8N93rWne4C14L5dpP12KzeEIUGVMWmMnTfyKgO3fb8Mmc9
xOiQ/a100CkRIGt1dqqS1aWhJGeVzXOd25R9+U3Y2v4Hd7Wwa/Rg+zF/ca1A1INauQr06TA7oW3d
m7XAnro+zFPSn3eYARiqZb3U+6cJL1Ej242trJACisnIDfLKQ9aNnwvSbHEiSjtd4EmC/Q2DXzPy
YCwTl6Q/4oPf1ctCA+TSudKgGMtSIkD535larMBvMsdwe3k9+965rhM41qvzMnZGPqr1WXF8AINU
BG9COEYC4/rb1JJYaix+exbiQjEqInIIm6aWYqcwMedWjoO9l19AZHOxILAPXlOPHA+W1mUtVxwv
O0qKksbGKUj57Hw9lPxlMTKba1uz9mzgdP9Lul5hOn++0JYW6Yz1DvunZxJDqeq5IWPowB2ZKLud
k8/8cHG18QpXcdznQkIUgWzNddmRLi8a1taRait7QRrihUa3L45Iyu4E2uv2TUfAwcnY4gdVB9HP
o5JEnoaao5yPHCZW4jhG4PuN9XErVpcvhXorYBOEDcYphJ/x08kU/25/a0PBPAwQ142HaVqlLWrg
05K7aKlUBb6NanM/jVHkSlTqagV0JIYhoLRNZfXjFo53VKqbaLeC6JNc51lBme1WaLPdz4d9nMIw
WuYyOa6py5VbS3Uwk/srIXwS3ofUj5Sd6d+ARhuY0NjN8NtNBMsmvKQEMQ6XfJUAncOtrJu3njL2
QCiNrXb/7I3Pt/5CJSV660bTEmTQzbafD3DQs9jM/7Gw4FoxuK+GjlXO/w4PIH/R7OQcD6gDHfRe
X79dFx299CMPV2oqqiwvpQfimSlx3V/E7OI5vTYYoWe4Lk3OSssJc4F2QM5GJqoqRGbhaxmDdABQ
bLc8/FNCGMUzarsFFUCa6Fw/53FepMKejOXqtQulnFik4TiOyzxDv7YL8w5VbE100RI0onaGfFWF
FYz25Zz0+XzDs9HIyfd6MIhKTzSYvPfajTSFhGf3h3YQ8l9+ywsb0Wn0We2qx0p5hO1+IvHLLf01
JuHCM+nbfLUvGuv4NPpJ5AVToNHUvWKu2dAsX6sxo/5YPY3TOSvlIKubeA+O34wJRUzmoGH/QrIa
/NjM74OpYGbFBKFr/4zjvmxzCd8dmTtuozOVIIcoMrYLYp9pFL6Zi49EyW==