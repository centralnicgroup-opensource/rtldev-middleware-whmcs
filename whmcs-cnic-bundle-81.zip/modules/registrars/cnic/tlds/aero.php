<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzxUKFlD8AdyY6x5sCrNN2yvo8FDVXTQjQ6uU7Y2s0Xn+8QrWDyAyBDTX3sDrgxY78xUoazq
9uxjJaV5PdDeYjCHJ/fnDsUPNNKde4sTyR3fcE4AXeLhBFoWHZFms+opfozyiMaLCx7udbPw/UdW
GiND5KfzmkuUDYNbjiOKgRqAV62N9WHMSgueml35yAqKIrmeXPkEnsPit8ksNpctputBg/+dDRgB
VqQd7fTa9gwWoJ2MPOyGgMWl98FIcreeQpb5uILhBD7UNf/cc619hc27+Xzlw0hQf4gURt0eTdcG
xUON/yKvVSyOEkFdszV+XyUOBu/MA1xfvlcmuEz1CQCGQ9w6IfV595/uQ6lvYHgnsfiYh8gYP7VF
W8kSkI9nPjjtkdE4vbIWWSvah00baGIHH3zEOlVe4y0/4IxnoWVU8eDDsQpKaT+9w7brZXOQ17eN
Fm94nU6PmV+aYbkKxfOWhx6I/FhNiCU7kNliWFiwcNGdq0UwqFgi5xvnCk0MrBgCC6hjgQ4u41lz
8mG6b22D7II7bc9rIQn3OUkMpUeFvoXD5sunPSO9xFF3lmKcKn4klJ07l29/g5d5Ad+eJAn3hc7M
gKvqDor0rzr14QYOKNiU0KLUJ8B6LURHUh/z2mNI8rN/j7c09+UqEE7l+TWRySN9MBSmBzhYSyIF
AgL9UtOHV7vWRRhZTrDAhW9oaCHWydq9C/tAndydtr/Ouqhup0wvmZsC6jTxBiMKDkeH+74XtP25
V9PbX1sgtZCq0ovrE/Faoa7CFM/4H66vzcF2q4q3fwCSJuSuiObfH3axg8fh09CNkbHWt2EOifne
V2Uj61AqJhxPzORRi7MMAPVRYBEyiENOfulvq5oY2l+VIT9cYEZVCYgjl/4sDmJOJkTRWfb+r+VU
u0GRz3Z801NmRSH0ZN1XuxRX5nbZM2Yrf9OzvKsiB1jXGVR7C7UN2/JJShphZg1gHijxNzVP+gCb
Iyq/0kYw5cMisFT/Axy/ZJBotPdnKBSjtxqzXp+p7xZv7K8DUW3ngzwztncZLqyfG2j9eTz3rQn4
PIINBMqpGsIv8bdM7/Il/5LYepChdIYS3rhv1d0dmcbUPTZkJ/VUawZ7AnRR0vZ3utk58aikx/0Q
jkrGGsD69MbUGOG4eEbT6aenVLjZWBFDQYzCjXhui3U7YjAHTcF3H2B4NipvlzxiKqwGHozNlf/k
9Eidmv2Wm2QsTS8z5hVOKYncVG9KsGd7lw/Hy3WX17tFoj0oz2AgPpJlPK417RQweoDVJnJJM+U5
YJD329ds+nJXf0Lys2a=