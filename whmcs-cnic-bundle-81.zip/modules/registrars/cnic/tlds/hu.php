<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsz1RUeFh5NErlBuoJOFXVsRgQ25tzi+9TGJopNlcLO8xBHiRyruAg9nli3Gj/jtEeDwrbCH
/pW0UIynWEMt7r/B4sm9u/Nkw1vDftnJyiYo/nPX4KAwCGUQ0wV7G91Izt2n3X9f+tQoKMQs0E+U
g4OUa4J0fHdXU5FVSq9k66OmhXN419vVxYJvjZk8yudtyOh1wKdR6A24BfL9avhEy+TRE4oFGe6C
B6NSmvDRRO1jgT/t8Gc3+P9ry3CxpsXwliiKG/tX9MiiqTvUd+QOO4ckO8Vw1szN7HmHMB3DBRpi
UM3TPNN/O3arMm2DMzGYU/Q3q/DSU3gh2ExLLULm1NlFOSI8NydehOE3SUcOukJ211LzI9AoZYG2
OA3Er2V7U5SHFcS2BwpDMZ+uLXCntII63L/M1r1YBVQH9sFHQmz2AAZmLWVDkEmrjUk2BEsaOP+s
DqPjwDIjxbIFq/GDcBjHLPhXz+RS29fXxHmWAScHfiaLHW/o92avCcv8jFOMym7qKBS6+p+5OeL3
yUIk0wZQE+GIg/iqUzHEtS1fEwR2vixAmUoSXr8PCUjApSTkS0SD+IJFucMru7oz0quiiT78lQxJ
yPnwg0CiZ8pkBP8W7XtTcpqvWFaZYXJIpYOguL67AbVQG2YI1r9o56j/3iHINtqaOa8tZQN1fkh4
67bFDrg6On5+/ONICJMGpxy6W7OgrXWSGo9SYQEn/C/j3JVeywl5/yjDIQmt0fCmKmPuZJU7Myx6
eBMwd0zIaeU2+ukNi0WhWEdHAU3ebADBAgKQs9rKkgEaeFALkQouO+M4rJqQGfv7SwkESb2hwxW+
KKegzITHlusTrjNs7mfQYv9ZH8wXQeJtDOTG0kNGAI2yptYZq/5+LDw0Et5IK4rFUmt0XokZ+TDl
ggheAbMdEspGbVrvbgDrLhqLe3ExULLfA6B3klueqRknKTkZH93yKdw8w1YH9j1KeVsRtVZ1wmXi
Wu3o7Yde8gC3UT8S0B8ZUZtDK08f0YikxULbKJjWDiC0OmftlnpJruDu8Ypb3YOAm+Gt+Uadt6Cl
qYFjUu25sZM5T77HohwlUc+U0zjje4yn8qA8O8PwZKu0ppVyUoD0cTUrLLogZ6vSUDB9KmYZFrOg
wJdQYr1mZ2L3foFn9FiZ7SU355LGPNOr6+X4sbspIG++Fl11IdTeq25XJ8kkYKN8LVYyn2F4cNEX
sDWklkpf7GNxwm3gQOkfBuPFc0LLWBmI9Lo9Dc6VX5nPRtW1HxSrIEgv7GwLj6SKN1DJJkV1r1rs
wfkAO6UWdEJWzEU7Lq0VG5Jx7+vSTm6u42uSDqqi/9/TGaS9A6aCol9yTorZkZTxtHFnRUHAo7Sn
PF8CfgDsYtm1yRGlL0t3SRCEKeb8USO5byFhuiBx5xrUkKWSFLqbL/ON/OxaMPq6XDAlqM4PiiSn
F/G4OCrInRpUjilSIuM7Hu8U53QcnctgJmopW59YTbQ5+t8cS62otNcxVmBg0hDfxjjKeQ3+62DJ
btfiWmWdsgwZ2rIq0vKEWYlrKBRG8qIBR9natQ0sri2dGJ7GvaW+Y/5Oq9XXnsD2icIBsVWopnPf
Vpb6pihE5ziGK3Ka8zDdlWKwJp6zRtwitIRSd7v1hJijyy4It2XbI8k+PxH+mZah6ft27S0X1lVd
Gd+o84ePHdFHd72ramZFOpUZ31BI2lzhr55idcILPzbiyevP9uId+7z8CYDLWw93zTDuomLbuqVP
wPzMFUJKbJWee+nwgKssaaOOezma1aV7QGz9mnlInWDKww0edewRLwXFO1fY2JjUMlZwNSceZhpT
W885Dh8T+k7QRaXRXMzGKqN4SE+xqELCuVBpomURDAPrEG9ic+SBH46NpCiFGhDVKIJxZT4E9CHC
BmDDeh0mkXU1ySVBA3NX2IZKRIsT87/xCabk9liVI1Fijt8l4SANKkSOlLVCa1T32DG+n53NdatK
TijBXBczjbuEJGW7RG01SpZnWkuwAi9V1wK2TWAo2tkERu7DLu6o3nOg6WDZ9q4S3qyBishR/TE9
sVScG5ATZNsK7xvJzK0SqoNis7jZ8mg7zd1oj7FVQ20+JX9EUlTI95bojrvrCNHOqsI9tFwRrAoR
Lc9rEaLxeMzi0VZtymWjxsdugqCrL8SZFQMGsfzgRx6HkGf1uQFKghe3ojXFzs6LqSbZ2RgkjdpW
3mF/NFooCvqXn3URyuuxpeLp7KgT40C+ICygswnEoED2R5ctwSCNhtz4LTDAUku28CkkvYMBFhLG
hTCjlwdJkVq=