<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwSuSvD81qYb5Olci5Mx//2CHIyH1hta6l8dGiDfiRCSsADab4wur9Q4EEtzi6w/IQ/QnwOP
edc1XoVhQAcUUf/Dmd+Kq2GieHIB6r8zBtnALwJqCPFO3srDagg6hFtX8JAm/xI3u1EZaV5wsHx5
N3y2/+nDQy5nse21OTcn7NcNqExDvC7oLCp89OFkOs9o/cquUWjiSptoZ7phKM14lll+PADHyiqC
pvyP3NjeqiFsg3gf/u4ZyYQzXb5l52O8NiQJeX0sanNd2G08oj7QE5olHVn3/rLkyewnmHTyin/m
HdOMPcRwPWCgNWJ9oDA5WcA/boctTdvl0AnpEpdr7lEKRgrGO5FQqWNyvhDzir5XVtm3scoExDFC
ua5wg6iGucHqg6qs8fDeZOf/XiYu9DfM6d2y8bcsy1Um8hkYkMqBHXnx+oRZ+P1mzlYsJZXXPm3a
LcI1x7mf4Fli8hkmvSXr91AP92WWdF7lCmZyTUJs8TvBdZvNYLcD6Qp/XCO3PDFimIWSRa/f2+11
OIV6imfXqo1NNb2HV/kyQPs3zRuoFpVziIg5Yy/axVXYqOgbe8ao4L6Ga6o5oxxIXQRvMQk7s4S2
6Np5V8rEnY2tW+81IIysUzhFoCcr3dTHK7QUUeOc3mIPoSAMQ19hROh0gWVsxliQigr+COb9dvM8
NNXhjkYDLhsdFz0l8st22n3xGn9XVrJ+wuD8mxDch7KEufANf0G8vbNWHCM3avX55AA50c18HuiL
uW0deMmnqO2/4MbP6I8FxQK402pRrp+JSFqOizKxPob+b0wU+l9sA+BufO5nXB0/3zEdxIAOA2I0
wMxxBKvB24YCeM1ng64O4jeYQvVf/pGxoclrYCpNlRRdZv4gGRyVHo5yZBWYfhJ+amR+XSNkq/Aa
mzXuPgn1v+goilxhChPXkjK88MrzKW7P0JxdC5BFbZCHVetZBjnwZeaGL8+gzoZk/fldO2elz4L6
Vekxd+sr2l8WgNA7/b5v/qrWCywrAa5dQBL7sOW0QT49tFoA/abCUgUyWwQaE8h1dh5Pro05wG3f
tvUMngGmRWUu56NeY+/pbDJeR7Oc5xpp4di6JCdMYmmJ4u1EXriM5FDVToRdh7ILVxdExism6Hwo
jbJwYcQo6hbXfHJA6ebWadbnXgLPViFOPfQrYR0oeMOWVubJtBmAzDeaMJAEJbu0gR7/99wEG/9i
GC1o7+f8pIWwt2pMEcyNYThXV2joqln+vzekgGquxjPL4yusC8BDYz2R66w7qU5wf+TMlb5XVc2y
TyPWMTp585Se7H2DWCAQjlcCSMG5wEVkK/JHAPs+vQauYMsSbuOmNHhyQpexgKZkAtWgFNUFhFAo
jPPgUxlSilvVUQB9lJiYQMs5H7OkV9jESPA4uFD4FPDXMEVpJSUys5a7i2fvLyS20OM2tZkVT57R
mhUFNHH68E3ZWOQzvxlbIxSQGT+etqGtMJl3Yw8aCUgb4fe/U2ejY5CvDVQq1WBaGjQC3Cx/P98E
9kMBzjyc+NChXYTjhs48glIX+Sio5fOC/jfzz3PvBVKYl9gxlIwuYLexgoDuKYix0Q4DTxMKQ7Et
Sedbpcttf6lNbuWYKUecmzH87MnisLzEH2/SJmLGg0AEl8cOXQN5+/7Wc+5d8aDykbmB8FZBpxZJ
LN5oGQFQuR8wDAf4ARoj04H1xFS1+LLo//m8zY+u488qh6tyeLYx+lmkpc0FDpH8tb3nQiXzTow6
EGxYC/n9Zp32OX1X1FTW+eAxa93vhK7fmeNrq4Mpf1ijSJ+SziKJpxylLehu4RUjcUbL0zi0ruKG
oS9CwgqYhpfgEanvpYcyocBxQRi6kY3aMmkrRZ9V98DfCg6GXTFKwRcZZzzMwcbMfajOcbgiagMz
E/OL6sCP3gyre4BaZhYIXjet6saJRwVJ2cxe1TJ6y6NoAROj+iYLg8/FbD5ztOFoV6JIqjSjzVjS
6/O2uRwak81Rb/Ex1gNp+WQ1W6QB06BfeSgPir+EvDX9aJTssp9QD274hAUb6PyioKjhO2kQeRpq
PrYhcH8+d60B9PY9jSAYYv4DzMIO+EPWqtsGqycjS9jNcFcnr5LE6dPq6K0kw3qIPEsjqvmXJJT1
niqboRoBPtU+lfO3QAofLbff5McHulzzUr61hb63wFw1a+Z31FFWjgsvaVHO6JAG56wzyYIEmROb
Wc49LYylKcu+m06sKeptPxve1p0MNc8GO/fFR2AmilS2+Be8neiEEHYQzv4gaiK7jXg0YVwz4/KW
S+129M5MFR2+VFUU40==