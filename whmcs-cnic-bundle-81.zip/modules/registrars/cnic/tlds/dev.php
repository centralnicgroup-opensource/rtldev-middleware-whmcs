<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrpG00q/ClaYnc2LBWN/VHG5kxBF0K2kbEqIzv/HmXyRDCDFxCjJe4exV/1N/WALEUGSrZGW
XFvJoqv6e2wxIvdrKrNbNBKaXXZ1FmeX99k5IybpMViAl8w95R/sHxSgEjYtlLDYImTl2QdAFoXa
n5lxpHowBHA+JKuPrtNPkBWaXkmqMfr4UGwueYkodyWpvl96RPe6udi+CmAzY045oYNA+CJWUUGt
oP+5XPkmItqKNAc+msG9QW67+SrkCdat/5zV5NT0DfCLvma02ChHsZXShqNyGxfaXWDidlYiLAoX
0KR6JIPxGGeMhbbEUeF5OKIGlNQ3YwNEkMyh4P+qX8t9slcSms/ml7s+qFPkfCHwgVhNY2T46EWb
tQ7DUyuYPPs0An4HEooDcx8k6UV7SgIgwwI1nMYh+3X2wlfpIGEnsheBtHEEadYZS1bUwOFoevEz
MMCZ5qjKj1nLeFRZ2hqXMTigwgOKofyXtZfBxmNm6sT7xOpG314u8NJedIIIZ8Dg1VskjT5T+yau
doeRnaJivKkS5n2WOdxxsUALWtvOesuHBk3vA7wdxpZxGorBo4A4qXM1fqoPhENSKuTFQJi+oiwW
HNHTXFd/XWBapiwPQt/wJcoPQSXxCcQixdZzvJu9tI8DkAMFsv9NhXp/a6LJKY7MItjjrKO3MUI9
38NPBz+7AodT2s0lvOm6OhVqDxpMSVzut3Mb4q9Qf5ZDYtO9yzLwFx3Jmnh9O3VTHf+3Z6AfbcWm
T3/8hFiU/bqzZ0BL9NCHHNK42GefQgjsL7MBjDXjhccNrfQTU/RK03/UBT/frKsXJ9nokoXMueiS
KkkjAVLpk0NSKkwyZRbCfi+YreDN8h83fg3gY5SZ1G6tM+7PKfwDoisHDgJqQriiApJ0aYtP3gos
hEWmPvTjoe55dpBaaamcFKEpYKobtP35qWD76nXJxf1mZ7G3H6y0isRr6n61bPNtvGYaWiYTfSiP
SVExATJteEube5nfTfkxKIuYCNzV99vwoI6nezqkTVTjICv31L5jDk62MBrN/k4PrFQ4bUwpI4B2
nxLmPNjRNf0hnCguq0+QXmRmIzEWxxq9YnnlzQ1l1OhCK5szxPBE+iC4UyIB3Bd7OzrfiM4xiX4H
vjygEsOULxc0Zz+mzSQVWn+fUgGaSP3kbA/9NcMDmkFMzIJoO9DHItOKwjYB58fsOkD8qyghAwXt
NM4r