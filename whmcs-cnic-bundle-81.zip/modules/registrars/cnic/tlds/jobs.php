<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPten4ckO6+TCPOQ7I7otyG4fVWdKQb3eglUI2KSUAlUdpA7uJsQg8j3VM6qALs1sCp+1MkZn
jYe/4cVb8N3BaZBNPw11bV6ZU108KKS2tVaJ6KfJJDL0yTDh79NGXQSF3z/dLP1/hr6yGw/gf8Em
nEnZMPXv/exSy39CYq51O7DOrvGQlgNlauqvZNq52fmKSvvBwxOvSecS+FSOHKwvoll1XeXGo4J8
jxUImFgp9RA4HUBgxani+SMXp24wIicZr3eJypQJ5US900ZAqTeuNAz5/4CZQmhgx2I0k0pADKD6
rgLbFJiOgzo7uM7ynIUedxqRgoVb5LpTDaOKAKY5iqIdvq1XAPt8oKuj/I/L+rh6Z43Hfu61ltVu
1tuXwFHRyfst9sXxcl8+2tF0U4huI1Tg//GB0BQaRyFbleRJNRT7U6d0eJ+6ARwAFzMsTcHczqEm
bEhQi+GSl8j2pTsqaB1rd0X62mRshCav3ozqVR+LpJVgtF87Tdg5TBV1llVb+bfFpZPCIxC2b1m7
AOVhJ5hR2oIBEaDExMXPvzLXFdSrTXlPmTI7eLWzD/Dc9STpc6DCfKTMzV9mGfBcFHxByjXPTRvm
YQPENrilctGm5ZfsT/2jT4ObUh9onW3ev1xPKfAqsNZwPwG0EaSEdpICdWekON+hxnCvLJNK30ee
T1VDQP0E8QATIaBFAhku5ajOFof+d6OJPdX5mbVEL8MZezfJq3iIBK5l0u59ggstwRiCUs6XI+lu
qzk5lRZmG+fyWVkEPfDDw8bPVXS5aIPPopOYh83mMYGDg/2x+H+yii0M+hAxcGl5TODjzeR1dBZe
c/Q5s0tucVsn4iZ7iREvNLC+Zo/1nxWMji6ek8wrA4tdSUHmLhcbxBg82LRmCb5qKusMfAgSKLhY
gTLmIIBwkuJDOey73L4WpBi0jDBLFZCstDoRlcbwA5iATDFR2vyRmJFG8xmQDVNKzeMupuYvVX4+
bmEttJ8fkbSCmVVC8lFOC5yKGshqmunJHYJObk4FjN5Injt2UEQYMnZAnW==