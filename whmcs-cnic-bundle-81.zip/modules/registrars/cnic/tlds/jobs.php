<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+rJKWJ+lgOhX+J79xIdRjKS2BvimmbosBYuvDnzVp9XwpbAiomUcQ5KXCOaHcnkoU2wweEq
o2yvhyUasI8A+NEO6RaSgpcYPIH4otJ9XxO+sC9qAmQ1OTO1voo7XUlvsst9KjEhI7ZqpjYKNX/S
ZLr3UfygPz4nfKeMYY4WvOehpH4wxv8gb0JfeIj/Ndt1ELyLVVUx6k7l8hDsLNoOSrI10KdEgIys
Sfs7gn30swWvX1UW6ozBMpUSEswIA0uFwENXuILhBD7UNf/cc619hc27+k5e3ZE3pr/ZHuFSXddW
tKOO/zdDMAyZLrPGZ4EPHVNu4aBvTpSF783g94U4vqKvPlGXy6qwK9HGx4VS0zonVI5GhuDRmbSR
Ig/uxnRG47f43rceUVpZN9Z5OjnzPMdfWMT4KW11ZqQUx93/Kw1ltyXXIcJjEqyNoQvwX4lhLZsg
YeKESMyGGW9RUFm9CBrskyyijehaj2Shl/39sySRoaUGy3hdGqmneuEEaSgGsdDXm+KmRRLkwZzN
HPK+GPyqnN2RGcf+seTo+or12AtEns5IWRFdqwx4rmN9tN8s8JJY6Q/4oIr/MD0KP50uXhTmeWB6
ndtvyj6Zm3Dreaar1Agd6mmviR2FsIALGougss5hd2//IW6PRdatJc9gpo3Pp6KAjFmscgo6PisF
SNqhbo6pksZumFt6sL06Q2wlYZQNcdS52yE5fdmGo+hptBLxqvpB6C5rURi5n+ao2IqSwilnqasW
3/atXLhxzrclbuw4+CpN+reigRrmbQiaM7V2l37KkxRbOz2aKHRHedlAWwFbCX29A6rWa2uT3Thq
yQZYOJJc+2LOOzNn8GuGDfK55bTRfJ5NVoEUzEZS836kL3iNvQ0j7uNFop8Cc+vq+6wAIIP0jcEK
roEAwl1h6b1RKSD70b+4CfRAFVELpgQgS4TUdFSvOGvd+lXOwx/JDvTGNPbx5PhkTAWfJgGzj3vD
+fva7HInq2RSizNKxy3kEotN53fqioDRsQlP3+Cq