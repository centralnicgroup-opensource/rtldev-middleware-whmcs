<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrFnpdHyKZDxUK1RLrRCGOHYhEywPMcli96u7+NTTMhLtHb/DCQSaBKomB+3ik6eEUvQv1PA
A+Y2QcZkfr6Qwc70yEvvUPhu6OL4fxpz+7ZinW2yUZiwPDEMytsz7fjb/xncpn/DW4hn4ImcdZbK
KIUp987EDgwfYZyJVuGvyjJzKVm0JdEFnMkSKapSECV69jb7cF+FZwxgsdIwMF9ysO3uy2pzMB2n
FZHg7KjqPvrubBzofmpalP5quNZk042WrktBDfCLvma02ChHsZXShqNyGnPnFTH7lIidVcuWr4R6
jQOJ7SN6D1qledSz8OA0G1+wABgCUgHTHNDX1T6KQhloam2M0940Wm2M08G0Ym2308m0YG2P014A
FXN2UaTAO3Q2k940aG2U0900dG2U08O0YW2G09C0Wm2508i0EGew/Rkv9N0DEf8ScG2D06mO7Br0
lF5LjNwoXB7apGTPFyvt3fbWriuXZ02I04sQY1L2iFSSDTTcNIzyEk9PIBCHsf3fSqriGxPxbUQ2
T/zx8NLYH7yt3q8pCL1PlmE4AssnBl6bAHb33CtnfvJPEqP+g0LHC61dSO7WVMseDsta6WFOP4jd
KCyAlQwQHoQhW4MG+oimYXZ2TOu7Nkeo20D6JleUjcQNjDrjiyEpb5PJSdTSeS5wedEVX9YntjQC
aUbIrFwYdEUNrMt/YhjTfp9t9jArCkgYbKk8N/QnAZeaR8wWXj9K0LWcwyMbVUH2HWEwbTIl1mrX
wx4VAavkh89xiZGJsMguKdGtBPzpkH6I3YAgYuJBKc/ohlrZT2PwxozLXDRW6yHsELv9dmJg1IXj
NjsHQjTokeaFubKFM3DIjzsHwy5ZhcPdKR6t1WEbEz9KsUAYYTKHCLIdTofBWxpYOvN3PiyVVag4
k4AgR+fyq5AI4srFgJcX8DMeDVzj1C1ybEsXncd9W48I/VRdIXFFTTTRTqVVQYeHrDibjNPfHao4
CiRhrS2oV732P+FYxnRy4BE+YDD6XDlJroXUSZRrRza6WGh2zPkDQFztsaWFhINQAAgrNSLXn8qv
wUZ6z6YNGdIuzEmme++BgHXuof5FYGSJnqwqUaPEMMCCgvuBjUKT7f93g8z7IuAONCs+TaL7yWw8
X/9tUxqHdApdlZVPNEwQ+6f2IgxOr/1z3nTKSfUYM7wEBGWTriR+TCJWI60pz2v2C9vgCt1CIGug
XkNis9kCK0Fq9f89jw7tmWxsJwNOS/oM7fFUFOXYGgfvWH0e/5shFXkm9s00dsreiUiQrepBDTZU
Xd8wI3eVV0d7Ta3WVxXwca4cyUY/67oZT2G6xXWsI/Ok+xxoOkBhsM0hYW2Vgu5nzKMQLEy1ANHj
c44RetNXwDbH6zrtIHcAUsuhyWPNdbHmQejBRU/gKIW6yWFFHRNH7r6JZhiCkzF0oQPOdImMTt5d
WjMzDpdt2UpZyd7HtAAKGqXIrdcqYDgwqHFQk5wNkHodggMFJLZ1Zl9mN0yS7Qhf9ipidnDxglwy
0fQqa67YzWXf5x/djCjULb98QF2ZPLKYtZ7FS2Z3ClU8gSnmwsChvhdhAqSTAThZZ1TADSG9R8PS
v6S4Q+6BhohkoFzdvCokj566A8s+JyipJr+Qs0mCGuCJ/wYnfTBgKQgpNNVPXQPfeNFj3h1La8MJ
M1Ek25Svfyl7vmrXJnO2WjePisy8yuG6o3M9FPwS/JuDM9r61DBbCg6w6BTQsqqO1Kp4uLs6rZ8x
fTtcc6WDPXBhvtuuqlP3ZVeq35BSHBaxMHuDoextAhae79bH