<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr3jDhGBCOkxqbsZbvILCZkBYGGw/U5riEQVFmRWSGhWS/9DeV6Xe2/Z7HPr71zdj1zMHmWX
i6SzEpjVmGSdjrLhyQUpFloCXvuUV+V3GYEuzPVHy/q/te8E5KXG7qa1hqU1SGalYgIa+nuaKI8N
cLHKDs97JIaKuFqCxqQ8YEn6dhQya3PF6MOrT8psT5zTiHe/OPe2ZSTQMBuQRyIG5QMjuvKCICM5
wZDZBmDDrNg3soDNCF/EtIqWYnYSNYFnHUG45pQJ5US900ZAqTeuNAz5/4C2OEjYX6jWAeK2crv6
rgH54F+UQwH/3myYdN97JHAkla3YcLPH/NkWGFJVB1WxYqHZID+/cMvHvEqBlr5e/8F/lPOUOaQO
OzIanIZPHUL6wCD88FMUt8GmNrK5Eondx7n1D2eSy9/qyfWkoOkLewwKZFY+DNkJirLX+4WOu/BF
u0zEtgHjRJlaxSjOAGrLL33egw4cBMEXZjp8fZaKJpH5g+tCNTy67EYrZTSsjkI8R8BR5AgvDBZH
XC9bsJEi1tRQ1UrvAPVYvHQCA5p7c4F0jJgr1bNeRfM2H10mMwgR0qXTA7Kh6eB0YZudYHjhhwAy
eo1G6wOKv2KJYRTyIOMl0hLaZ++ysGQMfoCOvmu00C1i7IGhQiBcgd6bBgJ/SkYwIy8VveD5mUAD
JeXi75K4Z8zvOLJhV0JvUL1idCiWEVapK2xzz4w/CBp6JMHvZ60NouvEVwGf6WtEywjRyNe2kkcS
O0U2cGZzDrdZ0VESiw/ruYnz4L0254mwJK05k1OHRLrWJo+eKtUfxLFwl71v4KUGByEPvWa7Krd2
1ClUyudLKs52ax4wzRFAYou/1ZrqFgGVyDg5Oq2yDzs92mpEyAtYqzrFprVATecy3/f9s/wbH0GI
mZIphDW4ReI3dtaebYTdJh/mJA7rFMyeIitXA8GO1CgcutI8OCMMRo0Cd1AeMQEuqtjc5Mhw+ffA
+pYZL/M8yn0phItPPpjIt2q+/GaLf8fDRXPo58q64kgSwFkm7wgeqXotfGUVprqwlucu32G0dOwq
HgDKdfj6Spcpxro8fOKxWmqE1ucV2n2DoNStE1GER2lRLDZxiWZV0D2kZtMGVjqof56zOq6fwsET
AspB0JVmkz/MECDAXy8WJZ9NW2mjJfOR29SMRJ9Gii29Ks60Wr1DbKw1HjxDNjkC0B4satZM9XTf
s/RhzpyXw6r6DZPpl1vhQ5A7B5pkYBGEK+qm