<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoJQhKYj91Plg6euQrmMuvILL8yIBtg1PukudY0qD6RayYsMS0pkwgCN8rauEBMaglftnfuY
PHQqaGedh9PtLUPUTaNjLQdVg9wp/0Due+ERI2IF9mIsnqnTVOIfEo/hJbsQHat3IBEYb0pqEI3C
+hmZZMyTVIJkFYVzV+KbmB7aK49XNge3lUCWK/9yB7b0cznlv/lhyToQS/OzNiRzYw7VWOXeSBXG
z3hBxCBU7oWSH29XkNaxVLXHe1bdPa7qlXLXuILhBD7UNf/cc619hc27+YvfTlZkynwrFt6zM7b0
XOLa/qE9drNOS79peGJvP57aDx3b1uPMuBhTvu5Dlb9lODeQTKJ+u1aPZM43+LeR1scA/nNAYxBG
fQL5g5pNRnfeczGhbOsAlAzqEw0QKuMQLYu0hm8ehqqO4FygWShHm9QRa4jRWM87KWdl/qZXsSNM
oA1sbc5HG0CtMiEm1NZafbkC9BWxTtTO9QyMtlDpG3fTxoE3ahW2UD3EahPcQRMyjzLFgfNZF+6F
QjPVWi8AG6SVoV6WrgqzWMQsT3tfj2DeOxRVFMNRCb96GmlmG2R4VjL0Ptzq+i8fpEUSgabQK2ez
YrwI2om2kbE5NPkAuX8DgaFA7ZqZoU8neWbgZct6+79JAgdi4e5NRAq29jbvhKJ6lSi/89riPcxK
lswBY8NevAXOxDVp1TYtz4+Iv6jvJUj3cFYhfBWE4VQVbG3uYC8R14vHJUZhGRXI1807cnkIasZI
GE6IVsb6g2EU6exwySyMohFncR8i8hw8MiHFYqZ48hdh0l1DgCUEGb8IGaz/CFmB8VrXpHCwLbmQ
I7UgOS9ca7u6eSWsPiNYdAz4a8dPMK5rcbzvfQ81uVzQmTlV0zdb/Bzcy7+v/GmfYWK+0AF277Ie
NDB6/QxeDDb8CyUMXNnA5yd2NPiwBv0/qJXCQo+XVfc2Do98S+MvXauCCKw/wF31/bZ6v5kI8X8e
j0JzyLxsd0wS9JeTVQdzSa1asKEY7Qx3ivzC0A0YmUVx8dP+HJYEfKR5YjJCuIsvuI1ipaBCONpL
FKu1S13kLnqOZsE6DLVuJz5XtdRryVW0z3zGWxw4Wek/glV7IByJl8CRKhgdTxC/QXe28lAD9thY
HS0ecaNsCAZxFfO+XViOV0A5zqbUoHNiMWAIKgeUJNVom+tq2uxqmksCc6UQiFMrSwTrPKNKWQQn
nnp4c3FmvVZAwuHQgOvWAy0=