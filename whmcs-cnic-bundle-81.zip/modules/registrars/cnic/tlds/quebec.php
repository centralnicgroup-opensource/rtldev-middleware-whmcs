<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvxrkm/WN00W/K8kB1I1uiZfZOrGtCqk68guiDQyt9/VB/qXzsrPo5tj/Qn1gK9qNVLIPqoG
sLHAE/K46ibFyxbcfu6qU6rdBA++/rzybTzb/98KiAwxuzO34woE7ABua1lA/uckvr6LgUQAp7ym
Tpa3vAzQpUsAivy56lgCL8DMKl7XZRZilpSnrD8X50kUC3vqgxqJ99ocHK+bxIVnNWykVXhZiP9l
6NGABkHRRyvAXVlD6rkunz4l6pvZrdU7WhKcuILhBD7UNf/cc619hc27+e5kltmhBONF3E1jodam
ckL/7h9QlMQHaXLNCaRNSodJ+dOYNYYjye5EN8ZSotFMCfyf1U3ojin8QSfSoAGt7yfaDFhLOChO
9/tbHC2nxjRFxrufsPrgbOphcXFaP2B28bu0FxKsge+6IaGJfkiGJiqqcnQkCns5dXzLwKrA91LN
jFPb0siRKwqt2jkJlffXVWhUk8YdtKLn6tnWKTbAhvkwrqCHRgFrB1SVZd0KR5capMAnlc37nBx5
gVcTyAAaUMY+H1zBQjwk4dQ06LxUr1OSJc3tlOY8v3PqIgWeCxBEnB19/+WAzZKfZhPNW5CcRfo2
mZa+yWNSquhx81frEKezjz4OgkWQnZQ2UOg40hAH2lreRLqPQdXgDQuC1eRHSn47dyLCENYPriTk
QINWWPqJTUKnTbXrL5xcXPI3W8GrtmesOTKXm7nZ4l4xShIMQqp9JtW+bfxmq9rSQmzupZldN2d1
jQy4PX9SZf4p/mvvlz/h2q3UfwdNht07RojT9QOlps+dYcNfN2RWjJessigCFspYX5Y9Rv1adUGp
uO73kyc47StTM+A6GdOkI2MGmt/Ge/+lSF66PjvJO9b4BbpQiuUvlb/QdEeAwhFqNToa8DSRf8to
Kx/ISfgjY3ieRBgaUqzKEIiO8X+opt6p2Qf78AtE96sagccs/UAHw4FQ0CBWzKNqpgENp107lD9/
e9475tAEpdYi0HU/Vyd2zKSOxeLUik0Zy+OWoScHnum59Rz74uds