<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzcR+EepPi7DoYnjoUZy5mBGtqWI6jA89v6uLmI6QrbD2hABOVAbYhm4K5h6eZhnV7V2bWwg
nyqwcg9V0DzuQ8roXDC2kovy5K248qKbYQASpnwzQjJIAvB737M9i0ZZ9JO09/Ma06m5U3iMCF2/
6pUwPHQuI75cmXhbQ6iZMHiUGMOzS/QXsHMc0wi209e2aYXbiNndDFDR5kceco21RvWsFr7seT17
+5lgf3rekx3tTyIaWX21PH5WjPoxkU8lq7NzDfCLvma02ChHsZXShqNyGsfZEKqAH8k/6yQJ3KOM
zsKqRgxb9DKO1m6ReTJ6E4XbbpGMiA6NTY21ku1iVxHmNHFHHwlFcl2DlKGuOMkBH30a7AJp8BN0
UQPRwzGjwzGcYezoxjkV/kPQEPM1TpTAIv7NMvESfPQ6+ZaDHwM/mPJZMolVSQyxcNHFlv/1+2/r
b9ji2SlMidz9zGRCHOoUV5WjTv0MUq2PaAjRFSiP9hE7Y+K+PAfrnvuDf+vhQLJu0gySyr0VSpWD
z5Lj580sqjvau0aqvDl0cdy5oPn+B3ZjqeILmYTOrHzUK95FsTB8tSHKaDTfKffud5vi6Ec++TBU
gnhEQA1+lTkHMdVUEpdnPWYHgepm0nGhkQTEv9ogtf+bmEFctqZf+H1q0sLQiS7HjZFxNMT9E6qJ
075BEeHZk+YfT1YCMjuwR++5WALpYI5wXO3x/EtWC5wKc4Jd3JT8tGUDX2Nft2uCaKip0HV0BxQ5
+0LIW3yhEh7NGL5JtTA+veCMpnlaXJapaXYwqLVrtg1U+O1wSxRslKn9ppMq4zQU7zorv88ji+uA
dAHOudFkkYPGvijCJ6GDy7AowADsPjkha7IOlc3ONNsURIznYjmUIX36X5BzQrMPS+o8dV1XGnGV
uImsRnda5FE1N1sjFIfhKwz4kaPC2bpzlYXe7w4iNPJsYCv3vfeKTvCVkZgQZmRg6PbpBFTeic7a
a+qN4QR5j6WUdOCAXoxJXTc1C6oN90qzPDuLkXxgiMcyizhuX3Cf2k9P9pu7x2nJCd6e81iR3m==