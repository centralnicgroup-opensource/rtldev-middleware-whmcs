<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvvF74Y/1kLlHek9QzIIymq9pRcy3EJWMgCxDPl8mu00QfcydS5m/pKtmX2eoDighBNTpkDI
wAZboo2pGDJKgX8rU0laRpifIODp1m/i/iMdEz7gQE/X0VEQUmtOSBj2Ow9R2spsg5ThnE5UNuN8
6z+NHmIzISiqc9+Sa4jZdICLd8SJ0WARcDRmlbOhqAdY7hCBfRV4LuYF7vpMtMnSDZ6ldY+rUYA8
+VQkWEeH6y++E3GcTu4YevUIqBR/0ZsS0HmGL4CqDfCLvma02ChHsZXShqNyGoPgZFWLsUK78fCe
1qRMpOOZUMmV2kj44AcjMS8FnnHTGQL9JXjkIHH1YT+QLvhUiTSCBdsGx2NoDyOaCEW3rRbuvBPy
NHAPKFC+S+aQGjoK/HGRUHD7KC/Dqh9h/THr1YBk9nkYBdSSz2AkpKX94WSN8IMIf7b0H/OvJUEM
klapJJ0pnoy1gAvLnoE33Gs5CHw4DGJrtRlgiiTKGFluyCkgS5tU2HlkMgw+tjNmlDRcT2T8/gcf
hd47h2R/NaEMKvvhO8ll9T2Dp9iZSe1NHJ7jrcWSdg5ojGGxIZyl/6iYV3fnnUkd+5EHMgKnxEhh
kA1rgLcWgTgco5axGPfUQ88qJnuHneweTWlDNrKYAZMv/7x7u0LNeiL7vQlIUcrCp/ZdZX3mTNkN
urDIFOflYtOtUa/Q0YPV27qSKP2GBJFQvFFfNdoCXRWXpYcCvZGZNH9uAGSFj8SnY46MOReo43sp
arTaXKtQakJOMG4VXIjefxIa3XrbemZRmo1WuORf4typE37TUJKQOsyBQrt9o5Vb2rid7lPnYBPs
zdmf8lmCub6JeXJ1zc1tcbgwaGoCAsfJOauCfwe8C9wtOGdpLnMye2aEwXuZu68lIkAAsQytEfyj
TtZyFeyKDpA+8lIsdkAtvkaICKZTZd8LHpw0Lo8P2PzCH4vqwkQVJp/4KeHzWcpD1+FX6ubjBh0Z
bMscm2PGiazfUGLe9FybyzLVgjlZwCr/ocm8tRNco/8JP4l4wcP59DrhRhy9Q21Pr7ROzUkAkdmG
9rrPV+uuwanZK1IcmkogOaIak0XjzgPoMAkyQkjfeKmPJLEtHnnHj0bhvxd4ebmgUM5uDgAQNDXr
uc0qnQK/tYmPgxEUZfTg56zztx2mNL/tyHiE0WZ93QObVDSMupJW1E2r6Pg7eQ0tPcWfR4f/uNBf
zeGXycM8WMKGjUbGMd/q8bkkVaS4UqtKEXd6Ux5Oh0oriGyj0SfI2XTDjWvh9Q0iyh5DDCQOJgpo
mZdB9hZk3SwPa0Lo9BsLKUI52sT1EqHvEGOF94e+AWVBC1BwyRTcp2b2FYFZ77LDV/UxoBlGlKg0
igZeVcMqdUZMbvf/7TLxBV3/8B3CfsBacbfVDioBo8UwPQqUCZAxNSHAZUH8liqpWiiblY2Rl0kT
uvjExryCOs2mIjWuDA6rUdkMkvGcUPVCRpPoPbeVRt3ULT7R2VnjbV9t8+W1j+F0V3RbFVXbVKiB
Ngv92VkGLn0sjUxC8SVORNNGZ2feVm2tEme/r8XqEEkFbRSDtShRIGOpiSfsR7scSCaaIp8nmMkl
krKkv6YptKm7DRJLO4O0M6jUkkteHaMvgpTcXKQdxd5jQVS9UEiRiqfmB4kVLGIr7Fa7MLunCy5U
t6eAm71jU3yY+jH/AXs5Hsi1NqbrTqj85wqzrKgWUrrvDOJPszUCcZTiX+9EBi/RiXjnADq6NIJY
SdXh56rGeTYtK10lFShpM6+sb8lPFzIQm2BZ8S26T7eEPkXv724Rfct5iMQeWb8vJjcc2vgbHLOd
QjnBqO+hu6msJ5B52JwQEOpuNLaEGXruYPv4YNJp08AED9KFMXkQHjdXEceLsSvPipL4E19rY644
7FT3UVW+SuWOcp1EEOjXQhTYKcsFFIRo3opeNCbxRWNjg3+JDy0w3/HG+1ZO4+EsEU2xY+3tek2C
fL3qNMxIAAW0Ta1p+/QYNS9PhK/244Ugj2fzsFSQS4W1njDcc/EkZNAXc/KdMn9/iF1P5OEZBuIA
MWo0Z7Ea9bWpIy0Ih63Qy3DxDDo2cm7eNegEZQz1zA1Z02a8Ccm8kA2KK0+X0e86n+tykRaKzsFd
LSNpaj5QEaBhAddTP42hlcCBzVn+zoXdz39jur2j5TaXduTg5J8P1zvFaW+lzprUjwMB2QiJ77K+
8Gqrkmb1RSy9QgfvbPM4HNlxHTCNoweE7X60u3tRebVl6ccPiq7yvoOSqMK3uU5Sx3ztpwddHtdW
6HKh1FKbFy4PCdysY1uCjjJh6TxkkykM0G9QswzOE7er0GynZVbyV0Z2eajZl2p3yORuPIhRp605
5kXfSZOnYlCz4v4jIxu5ooYt6a/CSO0mbUadtWCtIJ7bUa192AE3/U8LB9n9diKCbKgTTuz42sxw
nwRm91Vhq8PdNzxUAxqm3dRze7pWGQmD6jJWfKYD9W5TGL+d0eVI/PO/xSGbuefuDei6/vO4zAfh
4Xy6FgqABKAkCkKhserC2J2sZhZrGES5pSIY2eadTt1zVfTAESGAhNK66pKNu2tTQg8p7EEvw3jW
MJfZD1DqzjEcDEcOrHESgblAxNex1fHRs2kZao8xmmlnmoYSf4i0acknJb7AFx0J/V4owpJBDJ21
X8eSoA9jxrdq6j+JmvbAru4EJwQizuS2IY1LidSBKFsAoB91o8SrmCr+q2Djtplffz+QDHmXkVBG
MnTFzZUf5gfmtyr/dXunKaAwQHrVxgcCQ8MbiM02Tr7ae5XtxWeSb2i8HI1OtDtNZ8gVA/tnfrD4
pwSdL3Es6OlrMK7dOr4dgwms/oXxsGkGd9SC5wzC4fYybT+m4IDKCkqaXbvQ9MgJ7DXvDWecqJsW
qnYbaTzw+maHZER1uKch0WtoJYoA2hrCnNfwvYZ7yLYA8Tm3jolqsfOrg54apcIwI0B2DbYXreWj
TGZjc0c2Y/HURwmqu/7QU9VHmZ9X4P2wnxs4aoY6eGbaHDFPyN0+fX5MZo8LJFxyVgyfh9oMzB82
46fGvGrQUL74x6DFP8fxwB5Vt/n/bQBl2J36SpWBdZr55OWjrDXCOlhV9odnw4LzuQD/MUwnHN4m
933sLhNZV3D59qvVJhbzEXCB+Hy0+257ND1L9xAUugjHY0ULJHyhpSBwvYyZQWb9/JRzgkuAaqkj
ruuXM+5tgfz1cqNm7askamYouGFuc3wFIH5F+iETZ+GZ83lqg+L7re9dRK0Np3711OJ+I/3F/nwc
bRX5GN0Fl8gPoAXKJYQxMtk+GP7Fs2+251cQ4LUiCxo0G6xjzqV+44ylHoXY4+Ulv0ORECLY8CpT
BkOt+wpbCLcZAMY+XIbRDB6Mkz/1OwCmvNvKfI+s1GRQsspDT6xqloEhokVhabqpx2TwQGczpKLg
yILQ76rbua/GJirC0pMJQOpwB28S/eURfAwzmaGTVa+TzSgMfNMXecU652o5dm4C9OW/bDxvZBrH
UaT9+yJLb7MDUgys2Dvf1U8IYtdk/6oLPzY9Qz/8QqNak7dvw9/SjTUk0ldd8P7WE/nP4ykiExp8
UtTrXL9qG9bojwYypUtekgDdDsA44BvPLl871vK12kudM78VZdu/BO66sqjgbsID8gSv3ld7L2CH
ozjbI1LIglucaGLUKBTKUAs0DK6w/pXHk/ddX0b6UtR/SQA5xvUrpsRbY73Jd8VVe7tbZrCX3gNd
haCxHSHN+PD6s3TEWm1IVFc7heJvucOrMRjVe0NYslSIXJLEdcjO376FWSs9eOkAIwMHt2Z/1DrK
izutLRNrz5DKuIjSI+rVv+Wjg6P4D1IeyKacUwkyNJt3uII3jyc6Ar7AQM3ngeZr/S/GWjGd+x2X
hAi04eWz40wdxvfh56ygdN4ktJQF8wBV6SAw09lXybGUnAAomE3Z3nf8biR50MiGH+4r6RLtq3UU
OJdCaxV9BWvbraicuudPew27T5daTqJuRgQRSuY5TdbVBic2yuOAk0wcvejAGjen/Ne6jgNTowL0
Mcq0wxIuBsmlrIfF245wvN8v1TCAWWVryBsv3qjLP7co5eF09TD/gAugh5izTEIdKyuDnOpl5NAd
mBxV7IA8rD5rDzsRmUAtyIEPE13h8w5KNJs+7HHDZ535ejXRmwx6ulwi7apiZW+WVRt9Orf8GQgi
mIXiLAIe8ScDKYMyCjxAqGh5ruL7MMVLBaa+9B+WdTGuCDV8CgHNomm4FLKKkg3JUSgtnlrKeLM7
mcE9+voh28k8tjpdVCPpAvbVtRIMMj55SPZf1XVC6dx3XeW4vFDomScVIFuPxkn1OAJI7ePg7HGG
1nLYupXi0etpphPNqy4T219DT9rfJpydqTT7E1ggVl7wUgPpNegc3NQrxeaUaItf7y7qNPsO3MvG
96dDSRZr5SbWitx7e1RllYIdqYXhYV/sw5McHtUF+24ZChh4g/DLAAz3rptXlGTlo9poSXVXND+F
0tKLfsLtAqZSacCx/oYSbpGw2PBhEFigf/Sap+EG40sHlj4COZNXA2neRqhbQ9AXoJUxqfAhQrCk
bSSJgXI3V6VbTkEo31w1VcPKS3UV7ABvP/KxPHelXbA0na5y1lT4ZqI4VqPJ4hFyWLWt48h6RSXK
ZmNAObLf4GmIunA9KVJRyC/+vOsmzSFP8CjgZFZ0T5WmB7opVoZj3EMvuMamvNC2yUQx/kfjH0/T
V2M+sAJKxBrfA7N/USCcjhuwkzOw9L6Pph6IrUOARtXMgDRo0WmHUhIxKNGZenmg4w1HDA+lsjoI
FdxJM6/LrCXG7VIBDG6V5toBzu41bbWTSy7ZXRdozUUoZsZnzt+ziGowk7+RUnxkP8IMWt12k3J/
GES818JvjM26AF33H4sDTkcX04z8A1UMY66e1AsGCMbHhoySNcZYePcQ0l8mG3PCxQISz89Z9IhS
/EqfA98kKvJiEY3C9KJaa5W4CI3JozI1ZSw9K2rdqrEZd7GjTPMkV2C422iT0EpC3aynbt20FLJP
jHH3ZbJKl1RDUiOwHKjeGkjn+GniRzEgS2I18leNAnTYry5tty7R2sAahHC6oofTTuej8Nxa+7Cu
Z7He2rg/sBvoTCknxxmMY9P9E3dkVP45SIcg0PPOyfRHJsKEVwFoAXCXFqAu9lpidt+zyz8NwAEB
f2wDXAwzr1JWJMCnvIlgpRmkUHWp5ZM5bbl84eFRrIi+DxcfRcngWT86GpkkSGkX0W==