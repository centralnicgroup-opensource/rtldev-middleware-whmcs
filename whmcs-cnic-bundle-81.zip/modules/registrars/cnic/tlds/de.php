<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuzSStjdfqTzVklcM9c7UkcldQAFhiSDrRYuzkz+zlWLRf5Q+5JgyOe6WJdGWuOpqelsRjra
M1mKjDm6gVeJRRdbO5aiWjf3WnJLitRWw6y7hQ8QoQK9/yVcXqSoCa6tc3fEWfqvKejFKVkjrJzg
Evo1FMvjPGoyhYOkUGXtTiKqH0RpZSqRqH/DiP+KpkIIwPv+kuKePV1zp9wg+5q1S5r+to7GY/xG
0mJ11bApLTFZNLHIVp4QwpcZo/5T+PJvXrQKuILhBD7UNf/cc619hc27+gfl6tn9bDZbq28aDNcm
zOPQ/mtRaHHEFS5XlsGr+3Bg2O4uEBIkzLp067MGNYk7UHOFvFLo5WvNCyTRmSb258DciGFlxUSW
oFfHGgwxkxfnTrCTcr0ZvWbLLeO9T+j9bdCsl5SmhzA+M0/QPvSEHMKLwa7T2d8Dnh+u3kBF6AXp
yYvPApR+0kyjIi9BGSu+SXLTyrunYllF6sOMWYbEbPPNOPp420DhVuB/kVn/LbOWTdb/vQaMLrRy
R1Szjc9jYqU1E40TbHm1HncqZ2h0zl8uGSw5NcRMNWZD2ALtzyN/Yp/JeVNf95CIDGcn10UBorWd
Dixw5rWQomQ53D18OcexwjqLieTZvjXrpQXkzwk4DJEGMQ+0s5Ad3GGgJLHmZ5kdBeAxL6y/bN1A
DF6fePgpm3MDXP+XDnZC3D0jwAsuXi13r8r+71bW1uic5BS24KE6VMs1UsluL/Nhn96ftBMdKzKt
UNod2Y43PKXB96QF3Nd1SMDVlg0K/RMuu8Ak/9NzKJsVAmGuq+HwRx6bFkboTLVCcQKjZESgCp0X
rO/Kakz4iTo+3qy=