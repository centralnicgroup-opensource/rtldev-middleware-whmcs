<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvq0dMlKxMLCeR48I65bNyA8GBdCLYd/SDEAmxVlmmxbEafZ0o9f/tFdTLSdE5kmlJSw0/Uj
tKUgE89bPWt+OGN8CpRFepYSkP47l3Q11X/0w0aCJVsaAxXdtkGSNih77kOBGAXozG5tOu5Sfk09
gpzqfWGILs/3+YYnmMgDQ71kUugRFTqJP9L2DIZEDOYHZBJMHsEZu47xoz6bUNT/wLuxZzFfkYr7
FtaAQZXGJSQwN1piIw60Ph321V5I6aQ/bqEVS+4bQopHtbwVvfXWIQvWX/fcPt9NNu7s8hG2/qXv
i7S64/+FLjCiByppHa9J57ZmCjOIeXe/h5uLrxrlj15LJLKnxd6PVlaW++acoLnYLi95EBtP6wxh
7E/zABwtGkNT5eV/fIBSuMR9hDaSzMtnSxVUEw9d6SD6MTQdY0k6WT6S70k49jW0ATFs3VQPJzJ+
hd71oMlRKDQv6PRePX/zn+k4S7CbvL8S8BqlYpDZueRJ41dwXuyIquYiHUk7rADsm/+Bo5Fx+3k9
oQIUs6DnOGnjBEVUiJRLV2JdOZZu3bquOZsp5OwZ4iwKcxALMg8Q44vktiPRxwXvD4ajV9ZCpcW9
uce98Ll8MTsZZ4HDOKlmZI2mzPBMKHdR3aIKrF0BEOrwTyZ7ix17JzV+ccvM8l/pkCSrwiNwKJRT
qbBzxEE4abe5r4o38gZvvGXH/kcJNZqM+Z6vLpcXOoX/8Npw31aFs9Ox4QsTj9eP5U6rPpklEJ9t
kjNu8sMg9sZ7ezrVwByKZT6sGYO6YIQTbLMqVtcRfWjRQNj4EomZcXvGXu3WpwDbZ3Q22v+xBBxR
ckWEX6qzp9ZHl/vk0GIsLW6ypd0ibNWpo91kn34wbi4fnBD3ERcuXEyeuVYrp9s5U1qvuc4QsWFV
3x+75AUR3GwQYqEQ7GnL3zenCYpBJV8gUM1ltli5nQPFtFMvGg+ppNm5/HjVVf3vvm5HP8Do0xDM
FUh1nJU4VpOHG4w/Z6O9ANy0OF/x4aemgT6MJ0501vKggaA5qKQgp3k4uBRI1BuqQvH81SbhhkO3
RLSu1HPfhjiJPF4Fi6inZg0T58/okHzu06UvuIH3mJtI9MD4Ou532QoGuf2+Md3LqlzkWP/DLDuG
k62dv/bx7JCtt8wAwlq1TvVKOXvV5Ro8ddukiY8gkYSzB1OXxZcbBlZFHT8xe0GG9ek9O1LjXcH2
fb3Jkn76lmsEpYX1qBd0/fJXdZuhLYMWFbVEAoJs1ZSPGWgUBXAQzwY1TtWPQhH2PF4/ohWUgrDv
fRjUk4T1VLfxKlw7sXc5Q3OJ/l2jRabxfz6fSRvc5Xk8k1cV3e3xG7zz0l+370iwHIHg8nazxBs8
b+IlWjCKAuLFGbONv38TEWW35ZRPZKKA3g6nO/gM3yjz8EavGBxgCT1egSCRDbzE9Kufsuh7iaQv
hKg8X3htV72ofWwEt59bL+zPwze2h0GREL0q2nte0w/49jvGv63IcwGNEPcsyo8UlBo1APO39o5W
1RW1hLwUZIX0yH/Ppv7J1W6OiSUPLmX0FsdiwrDuJdbDtnkzgXiD1nTcG3RrRSIBM30w7k87Xg5K
shTRjjFVXW+GTgJvspEO6tLfvP/keO33vaegWQMk6ETgn4YSP43V7PY9AqTDyCpvn8FshWLoZyWU
AH0hkcEK0DocRCxuBzjwDlRgQuXqeRsVZiX9hJ2+GA6K1K9gs40OiAK4+YvwY6gNM81QrqwUrlMD
z44DwnFJOoq9rBfz1QzJ57OG