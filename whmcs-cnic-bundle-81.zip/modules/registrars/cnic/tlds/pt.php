<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvr3ldAgh095i/8hKKVot2+UnfP3LlJQP/ODbN4NiQJVQxNFYv07xlq6AmwOOSUGfQEELs4p
NEKIBMYk94Wd5fnqOdTYnYAVWpbOkHY7OeyM5Vjm/rTOtLrfNn7wnmOKGlIfeO0kLjvWS68M17DW
75s/Qj/aOV00FISKPOdim2IU/7lQsFoA2qMrzXDoGI4pDKEIA9j6U1cUCPywsGzueTqgTMdAXp19
Kjyq6AamBD/IXzP/HtZrPlafmkF17x7p1fVLlZ0sanNd2G08oj7QE5olHVn3t6HcC+SAXn8cFybq
HjPJPc4BEILckws5PEQJlqo108a0DQpq9SRiRG37lgy8OR/zrgCV82st7XgtyedeMlbGjlzoE7Tc
RmpUIVqClnka1gxTj7TtwUYjZsCtnioeKADRS2pPNPbiBooqKTccdzGVgmz2T1GkvDsL/OsNyhVB
TT0soD4oa1OwwMrpMfCeHUoZwnp4V9Ll6meQybY2RtkGjxxCKlMIAGFEWUBLisXUa5tJ+b/CyX+a
k12H6kxjYsUZquD5HaeOf2OFdtxQXNeSbR1SHJr7Zi6BNJFIO637s1bvoakCz6WPC7/rrZRKNugG
nVflVfDTHmHu4c6p+r68jB6uBnNiptFuPdA33jpsBLNHpnSF6/sZd2q4bi7fKeqdINK2qmMkBQn+
Q5+MDFR9P437bfI82juhbMt7IC5pb1IfYZ+kQzWtyn0RDW+EqEPQAdKXJP1oTbzxN1IbY5JS+3rY
GFAKpYJM3fRl80TLQwquoE9BUT+QXTyt1Q30ZeBxcAU0LBklrKUqJ6jeed4q0Y1B7a7QOX+9m6g4
OkBIZaftYfrRX5xrXh/JSEBFHLoZ6RgLMpF+c0Ob/Ys/nFuunSeQfvQCEguFHLyMFfFE6lrHZBcT
gbEVa1WhFNAPef1CKDqtlyn4qyqqyfZiVfPbbhZ6jamVxJU6f0n3nh2eoJ7pZooyI9puDK/nsMG5
uaY01VTEqIBnicH/pmPdv5Eq1Vy2MZQYgiTybPGHcRrQg0UoHy5OXFPg3NVgp/NBJoM7pV3TRYeT
16OieOF1WHSRuWPKDthgs5B/g/BjqVwvSDyfjFI+6l09zqQwCaXd/8H/Y0OCtykddySJ3JcFKPYQ
JibdbxRzc8CgqQwObPRSpx88MUM+xL1umdbXHBAlmOtda+mcmSzfTZF39HY3F+r1F/9MNhgQVAOX
EOG29BYQ/9Aw+uKpmGQRve6RHN5Gk7JD7cr0ciUQ6Nuw50Crlt0WNOJ8N/Qjnff9+f35JRrxev9y
mSyqjvSU8fHXMIWJHM7s5lxB3Xd+yqLMM9Z3FNVJjddH4BVqvKig3hFZOOpzruiGHfu20eYd8Ni2
2xe6wtMk2PW6Tz2zPc+Dnmo27WQ88ZeZxubD72ghnJM2Y12t62tpPIUnv5xfOllKNKKV5wxFrDBy
LNd1ShkGKYmbZEbu4Frwn3CFn++kA20ipUTPQtorPfkDpVvAZbyc1QY9oeUEMOp8Bv9/3n0YeIzX
gDTCe15kM3edAkQVfyH2ugkSbMrwSpZ3sEmt8KUaQw386dSdHMdG2mdaiLqQLCkWgqBDE2m1alpb
THmHTS5pkep4RnhxToNDNd2gsWw6fy46+0JcO/hpj5lXuGbUtIi+pgvjDwArKYCmmmynNS0M0DqR
1NwrrQwjKmedL+NgOioVaKGG74QGTMV0HZqk0fL2CKf7Ien0VIGgiDaRCIoRd85Plwzrs5Jv+rBb
xQ1bA0egn+n43bUC4w2VDPtZEWV6g3Gwa69YlWOcOB8=