<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnLOwtWd2z1/FfT+Mra1zlX7iXIEsUBQUP+uTb9TSQDceudOpeDvVy3tdJAkWiseowFBSjhw
v0WTDneT1XRlPQHVhVt6RTRf/KjRgJJfunjk6oV2CvMfX/Ym3Xi/Kw9L9eia8hVHV3KhKRZbGiHO
8urlr8Qwo6ZZ4IYzqDRB/5SVGbTggBIAhieSNKRWTnEsqjJmRuh5awEawAUBT0T5TmMdZmz3yZI5
yloryifd09XY6l1cWbHBBYXa+bRvRFv7mgKrDfCLvma02ChHsZXShqNyGmziBmRGh5Y3RMclEqOs
7sTQyepVeJ41QmdSk+C93W1ddDZRacdr40iJfdgPxYCOmh1CY2Yjbo01l4QGZW6PuSnbAymAFyPX
sKgMiDNJDHZAXveLv6CSZe57Wm/It84eICq6HJhYRBttTO2NJB84x6vXxr2+8RXldTRYab4AK7em
kzyBVCKJ+LgFphoyeTkJBswh9VloafnVz8T5lCnz9TaeozBhd7HmeckRXXZCLy12dOPuvvsanfty
+VdUxrNPa2++99hLVgl94AwwKDGgYS4bPRjhSVKJw0p1INoFAHJ/V5iZlCcvlOCYYIS4nvTyu9bP
ZukWJJSl935chptuyUHDoQfyccuq31GLxalEMX5yWnBbFpZ5yqtr/lFdHF39BP/bWZKcjH4+PewX
TRA52oFpk5N0gMZSqzrngUys5tCFxclz794O/FDhrAr9zi0OpfM1Grnd+Iwt/HptREhbOm5bLd5r
BP85hQqr5WOZ0awa8gYJi9Tm6qQdBTF17on5XT9CFtahXfyZ9UiwZeqr0pP8EabD4tVOIvJuPLu1
nGthBEVh49i5vYhZGP0Yf3danIL6aiS2/Xzy1OKcPkdotIlTeJKkDRV36Yx81QBwUegtYlYBfhk2
KtRk2HgOkK4v8vYuGxAmfc2Q8Doc8NLueyeXrnZWU/s+M0E4wY6XJVz5UiC65bMBDPx4Oe1atxMJ
M2kJa+ekek32UHdvZS7j+/R1g5mEjS8egna8qx1kp/Nn2VbbcLDOvGiwg20g+PscfMjdC2ubBG88
KwvlmdygiG4xcT5b0VOVU7krCINoTFvSNMMYrhI1m62KQbQajvOaVWY2hwP/p8rnUn34Qh6uxUYP
iHPwLihSZeUE4DiX1VaVuxNn2yGKJ+qoMludnf+pl8fO2B2Skn1jApGnAlqZhcaLZxBTt86acdnK
eB+wa0O0/I+CIJfHj99bcNszutj1xSG2VS6eZu2zGwn3u0PnIDhaNGb24UOhuXTqDAwDJEbjIyRp
kJvA2PP+I2haTq4/WVY3hKAkJJ31XdVKJdcAmY6R9OhLno5XIKveyMXW9Doa6zcl8KQoAVP4R9qR
/XGCWalKluDdpwLtbM9nZFhcUhrZ+816KTfuf4hHl6KRtPweUJurS4bnZsDAWqX3X9OKur25A8ba
+9uNkTcev4M/wrJxh4ryPnrgf+BRRNLH9LknVoZ8MTftB0zwVS6II5r1x01VNkJk2ois2mAllzzA
IAVxUWXze8R47xZuvcfVDOuzNl/ngxcc5B3mGwQgjzVdqX4DJkiwIVcNX3GcE+ClNmtQLhJmbL7L
ptrUVMbQEslr4Wks1fua3ai0gF9o8FM/QAK++38SZGTE+zAiKEcRVIVW7vHDFbeoEkO9wmjJpQQE
n6Tw6LAJyXsQV0eXyyy5Nnl/3HbSc2btVhqsfZhPkSCi71+QqwUgG+7V8LwA1MtPFRvr45KVJH5M
/YM3fIt7GZeLkoaYAVCGfnuTlRrzt7i9JZMv7Ua6XMHGL294givLvPxRwGh6Bqs0CCga1aC8afB5
4HuzyttowLGx6K5Sr1svvn93pP+VHtwgxqusNECXPvGkI6CUeHKUqlIY8BkA8JVuDfZrGeiW817y
DB8EoINR6w2v0hYkZnf296ub8wNbj5eV3Sjuj1Jc+74a3MQ9s6opmsN33glA0lnf015mHi3Pms2f
j8JkTwkISfhmgiJ6+cxARtC+tCjdeNDzzIE+12+SXdhY6yPjizxGsA5zEPRT1FzSL0UWAsuuW87c
49zQh5JtHkNgrpdv8WF2GuvWyfdLv2PooAKSjL1/crlWmMMoMp0sTMPsgj2tSobzInYCAv3G3DNM
NT0etTrlK//gODCvDXf1igjzaEtxriQXVUQ8qTk4vIulLtOMYEFVg8N008wkuKmpIs/KpZeP1+sA
Imzfmapc7b1qycLf2oI+R//IdbE4iAM87D/EqM8xOHxEghI248+w6FlEVhO+skw3hCoaCQOTSOQB
nHqOsclQ/jq1DPhUcKZY3Lf8vUlqvRGwm3kQbUUjDN43ob2pbAhRLJjwnNR7HFRJ5BU0rMGWR8Cl
3z3y/ztEYzsfsUm+nPYfzc9EFzRKTGXVL63hV7LTSgtFwqzegCw9oZ6E0f6yQDKT7Yf1jH76Vdup
JEA3VVtWGfu81nQ5kEDuo9loOaG5r6qEnOvBLRzlQJx/fKBkE2dyTlYSxc1oYmdoVqIU0HUJJiC1
2GxKbCSRxe5Fy4TExG80oOWEQ1f1aKgRvjtD8W1E27yUz2wBT7K3meRS2cO2g4qX51CznO/9tJbw
X9kq1Z1gWzTguL9mFMKIzgUNdr2pItwOC4POBBmY5hiaBJVyFejJ5/q/gjUTHXO1sJUGn806gU/o
rqH5BYT+n/WR2tYQYTAbufM1sk7hI9Dn9BKmileXo1Pz4l3/cylV1NdzLXqVuc7YOs8oBgS4bBU5
hXDkDoO/t5unftkBxmTHiKQkCkxxbA/aMt2Eovn3RX1PGpPQ+6YKFc2Mu9c2Pr3C5rZD5dVFc7aM
iAHW10dPd8/MC9dWi+PDnYoOfvy96p6mk8MflvOTjbY80sLfyLQKh/PW8KcVTx7RrxW2JRZXNvdy
OdxlCUQfTPyzb6BnBwpkvP9+/6TkMV0G9Sg6xTf3HOJLIrt3i2EuikZbhm45l2BtTvLGCPS9Scgj
wKdo+KZvZcWQ7H6Kgp/bezuMhfL333YgL553HRuXoCiazXDV5VU2twhwHOj5+C+lTyETfHoszphm
tYwS8bFNH19PvoWoYUI6r3FG3Zsm86s96FzB4d/IyDwJadHtRsZ+6kpxyNv4ubQwW9UGUajYOSSc
qrlbnPRhIKbxpwg3eLXoeF6y8s1xO2jonzdx/Yj5195SIg4XDwqk6VY9NrgT6aXeVIm1bQghjod2
3J7RRuXFWHgEI7L9Kl7NHQqr/V4vWsoiSclqd92/z0jki+slAJ/gwi+1S5RxL1zc8CRU968BjJcq
hYN/9wNCJxX2VXiiVwni5V9ksYojtVgRqW0o2oDykGH3TjuCBLCs1QOQR4zadr71RbDE54tMXYIP
3m7ftm1BYKUv/2Hkaizkr9Wgrxq0KECmvovq97XlOUH11kLBjqikeAUyIWWPl7nzrrm5FcPgBLDG
BxVXE3D5UVO86MJjTLnuACdMgSQYQGr032NGZEweZBGPWx1n27sTLZ9pMefoBog5M4nWbYXStnNQ
tgavbr0VVnJOBmk2hGb1ycoyc1pdV9/UIicmso58lxcF3ZTy3TMQBzKO77Lep3hBLnqrc/oJq5eW
XSWI5cWxAKy9Tm6FQYFmx8rKnoxIGiJFaUf1x/0mqo4TFpkMIbUQIyLCztMHK0T6QW1wt+v88tn+
SnsvCTSUsDmTuGyKioN9xAjtjhLPJNwm3qyFPkMzp8r05xp2o4EKwla3oWvXQfSs92ao8nA8rgR8
Ipdkm2atDPBqjokyB649ZCzFYUk87Yfhf67EK1JilsMjXKGo6LJc55uP577iC5k0+yd9IaxFccIS
+5yuWPwTiplkoyly8xnzMKRLjIVr7tL6n4TItE+m41qfvm==