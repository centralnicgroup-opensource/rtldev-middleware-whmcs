<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwO1Ycl9m0vCbCuVIAJpxlVcdzR6hFVmbvgur0jVrnaWBtRrsKHvPuaPPBhQgBiFUXDQr4B2
byG9VB7to1VirKYN31BmIUEQT6s5qqGR6RWhcqWNDmExHrr4bjCMeo3VZkLInbXX6bll+r6bIMtK
osWdzwsSXnwQ9YWo9xHyWVFUaN2xPTbu+5xe0YCBXXuH8Etc/oskCz8U2gOWjebkxcFs1ex3irwq
I0zEZA66wzg5P6ukADCnQ5mhIF+oCDZhNRqJuILhBD7UNf/cc619hc27+kXgKwmiRbBzOGt38db0
BqXk/tgHVwiO24DicWdjt/Y+6Q1CGAyGi4tdfOtH8ajx4mTxZmCdsIEVEwozocHZ4JZ0dSwc7tw4
dgAq+PUAKtcVU6HBOMTpkBLdkLi8UB93qkwN5vKUX3QnBzY0V5trNxS30DtZw9Q1AIejIngnJDrK
WghwCe1Pl1uQk/WAG9hWFIlYvcf1WOWCmVhenAp110PpCIhoUHphgYbAEylgC3jWXlCvNNpp7aYZ
babrS57RYYEmXaok8IiOMooe4I5SN9CeyXmGoPZA9zPj0+4FTOHike9FNqUcjpWt8IzKoF7rVC9Q
di3Il+f+0caKcdDZNB4SSIdkmuMw4xWVJLEr5JfK+p4t533zzzBW89jEwwVrw0khYRcuiyv3KBlL
cHQiRH6QeZsVyg6vyNdBX7UNHU61JEtqUMf9RDFJ894VD09Z/9GaCyGJd4Y+u9x+GqgXym7mn+Zt
ghS9uA68wIz16obGYhzRgAtwbosa53iSlvJ9kvWTNQmrTuorD0GH/m4O4/1Z/pcYSHcjanj6R3WE
lMyI9sM9sQys38IhXZc7jQ2VQdVK4v0v50ND85Ia7HEK5D8KpsRNj9D6aGnH9Dn2QF6lRoh1Nn89
kYk6QWIbAK7Urd3AvAKBeGtuUcUK0qo4vVnn4ZDoYdz4SyLNtpCR7pJ1I2XKUjzMF/hgkoNtvWEX
Axy+s5W2eLoTO063WCaz/N2cJf1iE2IeNHyIOAgVFdu3tD8WHBkv7M9qtpdpy5GekdyARCStq8WJ
aoWuCXWhYWw5LzQL6WrQL+I/YTxLC7VUk6oe/J5T4bAFFQs+NP8eoWXo9+aEXXfaZZu4kMvtxL/x
S+bAaiIvkF8P1ozE8FFO1jUPTNZWMQI84sM4Z9n+Hx2yuLX10hDH6ircdf459LNaCzma62bxu5IC
xwVqRPu1wxaPDO3ynh3cOG0JUB3JnAx9MtgmIZAZ18jwe1U/JGHZBvVKr+lxUJ1ro3VTJlJxNsRV
4J3AJskwy8M6ri+IV/f7xZL71L4MKqOE4u45ZBwLYMUgt/xstS6I02ul/qbD4FRWilgFMn1AY2gQ
//BEjr78cR0I/DkoXYxFXcWn2i6qwywQ6fTYdBhmCwxZIcRqKIKSK/alw0o92/cPAuyRyt84T3w9
wTPRALWcRDtPablfXlfUI13WNK5sb67kqADYytq0ZcymmBMuFZfjLtCRtv59s+32zuJJ2Y0ZefHC
hUNmx5FXkcAsnvpspZ9yLImuPvhzNDpfMRRgQf5/gFGcf5ksbpYvORpKm00EaU6Lu+YYslAzvU88
5iPrjy8Tcg1kH/I7f9uw6rvq6cWmwij+MgfR77b8+05eH7mqsRo6Cm7gPvPNcJrjk0nrM33y9GO/
XI7ka5kexNix4Pmg02efkb0QU/LVuGg63u/A54jB3U76GHBQZXEUvQM4rLk72DW5dy/+p6kBs/gA
laNLacuxl94zr01zDLC4rewxGU1MXhy9zjYUtzNVA5pFzjXJZGTc+r9d42EPIX/Upl1fjOtU/rse
PLstlwpcSx3QqRlVU6hjg98WKFfpRm0DYWzW2jz+V3EEfH+1QQCMTBa3jSv18KDfo2UBmz+wssgf
FGr1ilKBYUYh4N6+xsRa5zAJ8QD8lA6pvvldMVHINdHKUMnCL1HBygRzkyQS4yqoN512sjxnMiwb
c7Ctump2dLY2JhK0f5nqcNzwJEzBZk6pHBrn2ApwwwxyXd1sfipggSdlnaapAJIyWBqLX8EK1xC1
FIxraByDTUsEhD9Qpw3G3Pw+2MPxNXSabiyHM7xyZGPvG5fIhufqXuy9YIaGoYRCIR0vyPv5D7lK
MAJczOFLn63tFowxJibKlB0qv0T9kh4FZo4Kh7FGm9gK45CKK2giXXh8BfXKxJrIWsZRu+qg91jF
hs+Crxgq90VWJbWOqHYeCT9Y6XHZ+QvUp9XqGrBW+q1V5T/KeWUsZXIxXcVIXUirc/b+aPdZgfwe
7TvEqGLg2KSKvG6UDHH3rVpivrdSMrluz9T4jzTM99IlmOfOH4qbHR9GEc0e36rxNHDsnC8zJuZi
51fmGlJMBLRtiEbcth7iekMAhvDP/t0Bbas5SuZoWbk+jnNCr0Dt3LlS9IhacMdEG7WOJTo7DCRF
tgn7PDL8gsZ5H/56rTUJODBBADizrmL5AsVJXo0WuwhW35s6NHK+v5nfrnHTDmcvBe3XVQH3KPn2
EeGtXbJLzfoYCYcIMTcA+KPsjKzGTHtDaG0ckqe7/de4lyfD568sEOXTRWS52C999XbGwfzF9mQv
ffW51QRuRHniVTEQh49KAh+MgJADcgtXQrvEiDLY8TYXwmEaqqzJxxVI9SNJHNJTsMHh0Hh8jGLK
Hy7kXhpx6nVRgvp0UpPOE2mAaH3q/SG7Q+G6IlWNbKkbpQyXAb7IO4+4Ms3Q/RvcPsj1VQfzr/9A
HPZLSJuE04K1GDsUAp0fp/zXMGxc/vlxKVJ9ITXZg+mhauUA6S8e789Un8Kak1T9dKnrcclwXF4M
1f6B7m+zkCGIpKPfDaw1ycBnLdRHC8gEevNmXlDKHG4wtlMmlc4FH5R/9hOuHnepfgzo6rltiOvY
7yLKqlRD2p9p2qw9HidYbgS78JB1iUubANX9NXvI5xKSrUVF999h5HA9Zsro7HSTlWFr9nU5GiET
bb9jJlBLkUYYf0/dcQh5/FoOiZxBnBwS7i9aBuUDL9wuxWfK30VeJs3BP9VbMG9yT2HTYVMgK4Pb
KAXC/GnHyzGddOfzDG0+0O7LnbhBoFsz4//xKw4fgKwL80VGXDJXv36KewxSbInP3nhWzJ/e7KYP
6+y4lMIPjJYof9BwrwjwkRQ4BXxtZe0nzTHbvA5lW7iMAwMESo6SvQIzGUvoSsFWIAD8Uq1tC+yu
KWbJHFRh8tYz/CPpFX8HV6NWLU0X5Ah+HrTAD/IfxJOdm++yLrU0EAXDyA/ECdvVAitKZNZ48ukC
LvHhZeC0pFo7QwekAm6nJ55OdP1OUywyavBYWH+u1Kmziygor9ugIS3gSNtfnymfA4hiaiWNtFju
lG9x0gHko/qFt/w1OrcWP2/D+bZJlQPW/sh2TYvi5XWwwbu3Ltkj6lYuW6dfk3a4iV8fFnfb/wTp
zUqJex6ycZIFa7LY3ZVCO4sLa6Sk5eK4nsuXoyQI8nD4jRMEr7bHeudGzjAUMIrMrVxdcYd5a8SA
yzo0q/5VHV/tVnxR0llr0KzmgP2RX9AynvxB4+jLu9Pw8t4Yrm154BgEUVt117D3LawOZ1eitIJl
Bozu94+jU2xez4TVsAZn8x0FKiCcHC1uEpP3DlJKxHcZrpyjbqB4Yb0NFgsxLamgenNdxIweoqxS
/+axV8q1w+Q0aoQcalEvi4rhbzSQUYdwzp6Yxa4gN5+HPEPBaGFAFuKqukfhk1AWD61x3l6fbVO1
hNPDgWut2AKdhabKzbuxqjQXvqBYYOKNLNCos4JAxJBMIdWMzT2qVyfFHay844KQXTpt1BlFH1FP
iFD/4PTAKNeus9I3N/db8VgpRpsm4I2SBm==