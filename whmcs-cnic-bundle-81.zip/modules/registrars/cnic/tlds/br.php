<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxKY8VnI39hpAvAqtz+6tPbFEe9KA4o5Gwwu92LqRV4FNEvGjWi+TGh2Z1OoD2120OxxJMJz
mnWkElDmyweUGig5XuQ8obL9txF2uLEWnv2NuUzRiYxnzwsQOMX97lTvxpbNuBnrDP/ayiMdfKx9
8KFHVm0BtZeDtsUe8aQekgghnbmVVE951j7GoatZw4RMZ8omsIkfRbl/1P+D6PKsVTrDq4XV7X6E
rTrM9DVel5LZ97v8VQS+H6/jXD8NXkqrkmkQuILhBD7UNf/cc619hc27+cbhYORmNuGzb2F7itdG
MQO2CmYlUg8PtEsAb/kV1FXJsGMy0A7hYf+gtXMXI9N9J8AkTfaVDRZLglWXqvboLH8JvWq5pu9H
KSiF+6yt5QYxJakN34zclPIKMUUk01F8XDtEYICftNq0vkwN8G8Rze2AscomCSIOTCwVANE1p3fa
kq6K76fA+39xYClFY+yRE4SaEB5NFRcBRxT+vTJZI5pzFnM8bUgcC0kCjimGR72Qmk+Vngl8L7DE
dhPKUdabEn6fYx00E7l714Hr6g5ZCJZNPQgIjIliuB7eKob6aEOb4LW7qicPIyH9DGIqZnlZ+4Mn
L1vFBP9jveAoRhFiKDIttL903h6WQlGivf2IEN69kiw3PWp/UFMSrq8Bd7tT0+FW6HKY1DJt3mcW
UI7dH94n5IgRriiQmnrEjNXeXeaEUOw+LPxjReRujMfvg/Chgv9K7SWXbUNwVNamy35Fp7WiliMI
QsTA2KtfzIlnoJ0D6+DXaXf8CC7mp/TYiEry+kXI5rLUv/VOhHyFUvRpkXBtj7YGWgSQ3620xw35
Eqs7tF/TwUiFbndRcVTzk6lkHFMlDb0XnYq28NMEMx++/nm2ijSwyaV1xBZCCVc2VJPrEw5u3nPk
JcHlje2GiYngu7NetHCYTT86EdTBwpXJX4NrypKJQgGbqh5S4Ulh1Yl1Ojjh750HJ6EI58XZPsnP
nzyiJgX/RvsriugCgvATkKY+50wODaSRGLStfK6fbEr3qRH3iPLeuWdBTZeU5T03n40oal6opvXG
IYW93Y3q/hJ9v4Hwfa9wVTthdeTj9rYfT+czo1AQ4bF8KFu4El8TQGEGHdbmhj2RWXaOh16lMNwg
/lYlrOhJSrCmOtxJE+fwtMJpXgkiALtJyljoYiwVAuT2qYtoTs7qan36bC0jMAgIvSfii01KQYe=