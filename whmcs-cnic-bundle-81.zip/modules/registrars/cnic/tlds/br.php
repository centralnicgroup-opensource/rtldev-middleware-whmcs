<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+rNWu5zktUsUESMeW6GwxrkxAM/e/SFVlENUkl4zXWXDX0szd/o/5+JAsP7Umo70iRiq0Ag
IMmakSgD/Ztgzx2eqfJm5GGv+UeL5+5BVkgNrnrGBXGH52wqnpg7u2ypFzsgntI7UCtSu8DmnxI+
bbmt5RgEUJYv/PoG43Z9qGe6Jt4rE49zTvH8K5Fov8j0c96v7DzDgNrN9xneQuxorg6E1rj9m2pX
SV5tEJxY2eiroOOWA61Bn/+sanQB+Y9/6kLfpJQJ5US900ZAqTeuNAz5/4E/QZYYP7zKdYFS1sD6
9lY54rRe1kFYDehub5w+ZrcfbMWsr1WA4uukV+sURfOPcHjwS0i5R9kDMET63QKTc0v9qwRK0uvV
iH3XQaHkW1Zn1jZo/TyOfaysKLg+Bfe0+Bpadtg+C/1mY9D+Kv8dtrGt5Aki4imCzgEE83ad2hCX
iX00BDm8/Ik99EpMMbegy5lVpFatseMyQgyVDiwJnIprWWeaM+oa8LJzC5HuD16B4lYGgjrWTD16
5X2plf5g01+OemlKTtXC1RYDnEiNtj9Xgu7mL64qW4xznEOdBKFirbb2Wc8koGGPkqQOqY/SvKrk
V8z6rBeliC4PE+wVDvDoNHN13egelCfE6XsFOtIo4g4Vsm3jNlTe1bLtceBfheWGV5tusBS+Ps2L
t3BHdzh444g4eCri8GUpgmmkoTP3661JwJBEYOJPo7Z+hMqGHN5nOup3qcjSrqcCb3i0nReVuZFQ
5/QyFdKzdcADTTRA58YQXrvyNvtWWkmHIP6WhXESYtcQ+EK6z81T87R5/42iWJ5CaVtsShuOtJka
Kiy4dRBznn2PprMA53elxkm1YZGO+wGNVXHAd7+QDT5fefZWZA8X+G/PpU3EJxB1ddfDhRSbMcxj
ZV9pQ7h791drfRuAYlc9NO0GOdhhkyqVrNyViTRToeKX2SN6J96Sfd16rDPzZPfUw7VhbNK8sILk
tbse2K/6+hbHNi/fBYDey56Uj4Ltkls7Q6bHyT4L0EPNfrWbmiXmAGYisuEMIIpIxHUvXcvALwiJ
+9nDIjcE8f964rkeuRYItQVAxbgh5eNNJuljudYpYcPqkFFIY/IBPcA5JOEamAQ07Q0XhVW21Dsk
M9PINgg55nFdEYot2XTu1Eg19ii0AZqoX/gUSD6Yx6eLjob0KaxvPEUtoUePiZ+9IL1v2w04RifL
0g/QWNw+zrO3cm==