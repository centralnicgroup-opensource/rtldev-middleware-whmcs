<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo/P8tJkZPXxzn6sL/pCH67RU27rW/FAviCfNKoq7gkL1ycny25bhXftWrp7/wWl2uQbAEnw
2ejqoJ2uqupjkhCfWOABZhaVuD7PdVxYjtmCrO7Tfu/Q7AY04exmaKVd48aTtbbKC7RijR0IG7iG
2h/hzqzBhoH93o2jd9BgxrJF2+vqyv56AReUoCmCVA6mCEmUqHkvTrDiiZVZxEV/p5rBjh50wPoq
/F9TkMhxRWpMcHBxqftv+04+1JI94GP75aPutayorynyjSYv3ltq3RDriI/wS5CqfLpfn+meWJT7
njh7Q6fK16kir7NYPXXkZkDCpEiuXZv076WY8Rdqhf5JbI+In62U/XC+3RPOYupvhR6p6Rgvg1go
+oD3/SloX354vFIBYLBhlMUEJZg8Hxc8Wv4xsQR0014BhGoknCT33wce2Im9CZVWh+tiCcMRYA4t
2tZb/Xqz/ij/B4MTb+mwYDVIDAiONToEB4GIBn/tyJuQ9fKvNL2h5BfB3jpu93Sa2bgG7FeE23wq
jgGpvuTF0Ef3wngZfcg3UXtiUlOIQ3VwfSh8MoH98M7FZN4l7N4ws7sOZ42dUgi+QIkLVDEzGY8r
MRjlKZRAjDGa0jNjJQmeJHzQBNqHh16wGRe1r5IHbsFI13ImGGD9nXFp4FpM1CbvcQa1tuVJcPME
DByBQqbuowZ90h5F/fGxbYNnPC/PN7AyjfgEEejWinAxc8A3ZhNZcBrR16Zz58cR4r1L9y5x9YLB
xmpef0c3HjWJEbJIJlB1vfGFe1VUsBr7ecDovBR1iwLvctWzFOcnuEat5K2tBkQFo48woGXuwyII
pQbHGrmz0xt1nGd32x9KwNTZ6Fb7IVZH3YYRLkbok6YK/EpcWse+Px4zrwkHm+gbNzkvWKjL/ypD
XhQkT3MblXCS2uccH3XQR3eEqAMAcN306SeYrwiYmMpIRUTXEE3p6e522fqw2Dcl5LyY78EJUohc
erri5hSzd8drOjdUmMuE9vvhsEPgiolZrh6PWOEEFqqGpVmUlfeGKi4t4t4eka0Po8r2FTzcU+sG
CWCSiipuUlM2wOTazNO3WkWaXzakuQxb8/U6D7k5fqAYM9Zh92TI7CBZYEBNMxVzSRcOY8kS4XDT
lu8V5DZKPubqWMwKuZYQvVIo/nt+q448Fu8emodvg7kNCW5WZWLXNltXwGrQdB5ajauasyxJ5Z9O
tV1L3UHMEbd8cqDU/s4hbJtrD16ArIiSGWNu3iYUKdOLcwvij+NpGni4q3Elq0rdqLOQSkBt3j83
CEYS32eNxICj8MxlRpvAI2ZZnrZ7SLdKwGHgmb9kCAM7ZNY8Yb0zcOY1Ccuw6Oa0NesCsd5EgKEe
XJGu5UGAeLbc544s/MKX3W4GOXewBXY1a50efvaI3FwA+MxKKUwz/JBBNRHUW/NkPa17srPqtG7u
Fy0V8TYMAqPUo8MBOpvxy3P3eUGholczHGGwFhW97Upp8JGCcN+AeCPJS/qcPC9o2J11HFSsfZfF
8Adf4x6EYIj6V0vBlKmH4hX+kJcUFce3OcxbYXGWRKOMv/znJhj93BkjwUXlLGxi4n4vnnO9xv8v
tbYRzVT9S6/xujtmV4htU8IGwmI5juKWa/1A0+iRmoKwKV2XKIdYWFcjSGTpA1PqirW/EUD0gPQv
97nef149LBS8KIN2z0p4jK3jR50NOPdVLg0D/zl32o0iMqxgQYem1OzYN0YQGvnsloD18ejf5bOH
8MDqq4HZDbfwV9DaNSaD/GXKttWj4TRVyrFrHim55VST2jZznXd4eQ46eclSSEJD0+7/ag+U+2/a
pccsrRJCTdsqOqx/LkJrbsGe4xYZPfuo31F5nCRPGnNMmva19PgtPLeIrgZHh04rMetQVHbzDRd8
tZA5Dbj+ZLgiy6y//gm9Tu3C/7v6ZEryTKI9n1XHXC28aoTavZcFpqnhgiNSikWdQPuSRaKDRaYp
f4Gd9vUrZwqcObWu9P1aWrHDS06/uaz7aa0KIOx8cWiO096K3asW8QKInmWIeovQHe8kvTlvkbHq
w66Pd+uShCtsFQ0hbrWHwMae8Gvi26tgeg+1JZNtHSFRbg7xUkKbCiF9XMPEjjCg3M9W2BSq+3GH
/QitSA/sGaZLGGQxyTD8xnCd4CG/YyMM0x5Q5mtGG2BKf+wEeAC0oVBoA7eIrZvAj0ZBo7aznWDs
KaMKT3YAtw7UjAD/l6FqPWa2QHmoXTDRnvpFlsy7C9v6AznOT9UWQMpecyeCqoWa4Mxr/4wiif9a
iLMR/JcZlF2qmQqmEelayy8xFmPTHLjs27IbGKyIJPnYQeSxyMu9xdyhnZEBcSbqWeEkrK+ufF6A
9Gy09CoMwkPvT6HstHYyJc5CS6W2QpgB1EE1P2+3VOHuNHy5tsdd+7eczaKDfc6xrhKN39tJ7Dbm
Y1iMfncfbHPJ4ifmlyIdnpl3+y+dD6qGEyISKKpYDxzBqBoJjURrxUxNkcxiZamzhyGtaLjoFWE5
TUjtYXvh8xvlGroBb+PjFVsmpaOZsMrpdVu57vAbYYLi1Ra39GOEoR0C1LqnjKxKFpYTRmTw+k6A
WJZoiNLW159t6gUTfXdReQ+setuf2LC0jJhrXqBZyjWFREK4Pm4zQkoKFgPP/+HZ2tJKKnNdFuGY
eKNgyaNYPC3cG8ziBDVWULclACybyzHsOQ5x8CQf8Z77Y1susnbdKWMMVU7ugd/IGSsh2zgNo1zt
qFO2D8qQ/zKDTiXJORGqthfB0RpL/iFHX0ozcJsRVWqlNWBWuisLxpON003uN024dXExWIufFq2s
5SbGPzaxKUusM7zgX6cGcIaI7Njb4RdjAzZGA69jUsfR0Vzd2i840KGOfUfT0i2Gr6j2SjZuBHO+
1i4XmlJz7fx4elsLtPRkpBwj9jjAcFnsx0SHSSpKsk00CLU7oYxTcVKqeQjICtV+uREWkWW7KTE3
vB1Nxve2FHNSt1zlcSlafg5u0F9EcrLTDXerHIrRRnRsiPXre7LMzFEg+RlBdHiPs+baMXhhYgKX
JULeOBa1ewqk8Z4Np1LRHf+MVko5YtqjOsPSV8LcUn5UG18IG1k8C0PhejksalRDGxBybK+HalmO
XCn99tRd4XwuuVnqESAr5ZjC15ULopPLXmlHz+X6tZPGB8+kkbCv1O8ZNc81ouThe1wE7HvI1GP+
Jap29Oop5fLTq5H4MmUnRomhr3f/8VSq5mAfGpSc6hPYir6YN/XuWhl/DylNmowlr47Al1DSeK8d
ENJQgSy4KXb+mgZQvzMJkXIWAPX5SbFXepDhe/BvHejD9UvayrUSGuWBS8EYmqAdJDvZ5ZxepZJL
D5v27qm1t3GlC4xlHxT8ZlE2u0P4Q76WU6kXKnY6CnT+FcFrNGGH0TZ8vQs94njSlv8/EmNy2FRH
mvjXDGtuMCXA+WTmAE5lAh3AMFskLSZLWvIiNPlzR4txWlMSh+N+sQpyRsaqRDpe0Gf//w1LVjou
E6i+s/rH+6BuDJY1ymHQtdzvMALxDPfmDuAX1DBP5KccnoNTDjPUulUSyDArmMNT57VAyBHOenKZ
hd42wyS7XcT0A0sCaQ7FHPeEINl3CNHrLBOLsBp39nRe5n2JOYki87IDoX6RMrjKJcAb2C8JGl2U
Pe3vL/9VO/lYiqTmNx51/EfYGHUxPrvTuQILPWUxXsF//fSKLG6IoUoy72NpLmF0w1YAJG5iYpBv
/ImEvON12m0NxHWTbT93H7ljBvltgnZDFKQeXsYIrB0uKprJEktWunH9uvBWc8S50J4wCf1uce50
IQo01eC1wx7iEAHxRfNUp+Ir1fNaTJspudyujC0O9NR02DDJ5pRIAOmqzmFni80AVVzO