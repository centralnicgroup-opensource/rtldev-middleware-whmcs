<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtdcIKlQIR9ierNSQAqwMpC8allPoKe+2gIuRPmJ8mKXiqMRywLINuEeSkaZyG+jNvjdwHAj
89p5q8TWRgNckQBlJgCFX1IOBNXEs9CnOBcOCJCXpoyrjFtTaqb22lmho6YjHlu8JHg3zuylhR/O
0Ui8Hg7MjpjeDDICbW2lUB2MpZHbw4jcCQ9AukWMrRRR7e/sjJWHEQqTPEVpLuWsBL7t43TuAuOO
VImWXB5b/+WPYU+QCmVGCtVX1u4/ajLY4Y98DfCLvma02ChHsZXShqNyGsXaR4LdEVMqP6J37qPM
ZqP4/vNbB00jKvsJ5igv5kCHQGVDG2SszINl8EB+CG2iFOFyyqtAxYn4DAXyjClI3t4bp7dM5CUS
7BvqWwUQL1RXiqQNU8RD++vp8fsRKlAVAVBiLOhdsB3Vqc9DPEgyHkO1lp7vgtVO99VpG40STxxm
y0BK/VBxvZhAJ08QRn4h0pw9d3Z/jwWn2noqhWJ0Fg6JuVMy0MMXZmoMd0UyL4fdICCKFI9cCwUy
GNI9a+5+t/joc6dwBUSSUY+HJC++v3jvqTB+3BGceIuJPRLujbQNQdqJpkTQuZ8atrvqftkxW7yV
oU/2+MsO7sTlaXs5F+LZHBZjHRMz0GCDX3D9CMNUaHF/hwRecdYyAfpT+vphf0XRnbA8GMowu/2Z
WHenbEPskWXeeP13hsikTzD+lciLmgmCr6szsSwbzI0dGbd0yeQCpJW8beCzVneg5mydMMJehZxm
w1tJCDylnKoQHECdEJTSA0ZKik69EUe1NVG4fHWoRRl1XqoNONrjLCUZfzqSUoahQVbKai4Of5we
zC5QeQXGADjHR0w5PMsWsaDuPeBLPYYLv3jyAVsd02VXvwaGkQWqCZel4cMVIAcr7se3zCWoCyRF
QyprB+TtMgur13OnT3bjKrBlFtRFYriKB2+aiGHtw8gajsszElJUIVp93+w43HTWKAS/jSUjfzcw
Xbt/5F732Zr0beAG66UCPontryi11QM6az0TkeAf2xaxsPR8E8ng8B4PYTrSDReu2ZhnWR7uTEnb
DwT4o1DvUL21/kOs47JnD7p4I0SnOX0I/RlfY5Rewu//s34oDk94oA29s/atQJMRPcKNDdL6oxIG
s54cjN5Gwvfkh1sHMzIDAOagUiK9ZDnPdsak2WAVOLdjxAIWidEUYXElwizfZnZ5WFySfZeG9GQ9
+Oo7mhXj8wg3lzpICvjhEoecUyDqbmrofPm0Z04jsqVmPLzhLcsX4LZVs1Z1jrNMgKVsYK5d9Naz
S9AQrTBPSJ/FU9m9EyLlbzyEb2Gj3PGX3PUN7Izy9E8MfOzQuVkbVaK4QcYn5bE5MOz7Y1b3te7T
rCm0/ME9u2jixTlnqWwuLAZwmJhLwTH5S9BQWHkeD0E2rU0DfO7Jb+VkZ3b1K6ro619osHrhBdF7
eLCqvGQ102GJLcCPN5qZ9HqIq4+CmKe3h7c6T2B0zy4wU78fZYjOHtVrY/pLK9+MjO+W4bN1ODhv
kMIaBkDyW/uwuGx+CUAGGY50e0kR8+va+kBEpZC76YCJEq0drzhX3FzNGG5QUNXju5UJbpIRY23y
aRdWwNY81lsuOazrTXL29auAidEkMbKlKWMRT2/K7hqLlvfp9XtZrtEwvn4KbivmTJR9/IqxPfTm
V1mU/uwWnyrI3YuU7mog0KcYWBax43qiJWKAbfahL9OwAlCcSWD7Cne+Zdi77uKhRjUA0In1DZq6
77Lyzx/N1DWI0Gt/AO+B07WesXY7IH47TYGZm7B7Bv6r1xWZWfggfhziAdKBB186vKZbXWI3ZP4X
og+n/f/PsP3O72I6onIw48l2w9wU5uttNEb91x1jbZZrzIvRq8W9OToWh3NkliHXo2zEf7RJPS4N
qIpN939ydyKJrT/uxgMzIsqgb/9mlXHDSoBkZzWRPDc/KF81L+nmPu6Va5ZAmHkjm5+iNkZEsCVR
gdtPnc5ATkajM9croGyIB/jjp4diNuYVBf/wB7LOXO6Ip38Kgy68EgBYqDM8PCU8EHMj134OX+ij
N86o87ypcOdsG8vpFvoP34KvDSDYH9SmNW7Um14BhogljWWB66Kcazlpg+ZoXKhiJowBSGnkWVj8
D/rIjimEsN17gz9+AVRXTr7ifU6WLVm=