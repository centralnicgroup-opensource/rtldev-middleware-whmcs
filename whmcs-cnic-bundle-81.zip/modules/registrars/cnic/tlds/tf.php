<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsDsd+6/r6FMHhaAmZ9fa+DBJtL0o8rx29QudizT299aQeVZmWngX8HdmaVC8/tW7oOXtuj3
bUdP9adt0oUxm3JKcsawvdE5YFXOeNPGm+fhV9S4+Y1YJrMp0++MbOo2E7pKddV7ENHNuja5SUw/
9WS7YNbzyXzWzqK+SZW1Lq0L5kLXqGOdsT5V3hEwsYhAn+XH07DnkYn4gLwNaxgKGZHH1c5Cfm17
qK9iBrWaTRBoYD7PNKgg4mPewIznkx2402riDfCLvma02ChHsZXShqNyG+fZRSTHBdmkZnuHD4O6
4wWV/twq/F5kPP9BYeWmDXGrB7+4T8WGtalt9qtzC9zLAgF75rE3Y+LxR4tWaGTw7uGhIuF1pBbo
4VgDktoZan1xeOgoa08QCe5VAGjmsfpzpYPxMewIblg85UU2dhfl4yhAuBy7tSdRGNedDXXMrzao
pd3LKCMmZkTaOMYKWVqU7ELtpRdG5MdJlXCdTdA+tik/fDgeeRPxywoKDXQ1hikIJcB6oYX7NDV7
w9Tjt6dHyCA2KVFgjUA/VI8+xzvel4inEtXk8Oi3dT+iximLbwTGmt72LWW0Ep8n/Ar9lACt5p9S
U8skqvRy21DHhIHUv1N0GT3jnTbtASzp/gcrL96gb1/UZjm5sneC16miYf6HEjFtaHfbBwnF0KGX
rJ9QeW2XEcIFLGH8Yhrzq1njgwJ52nQjwbdYHjp8NOymiedhlLiqlVp20v4nKyUFr0Zg7vQzL5ON
nwp8h3bunyEgtR5UhBMwW91lrj0CKIq12r1eeWGmC+SvQFheSO8HLlxFEYUT5fszICO8OXUtVSUk
5UwLFag9kmT/sDU+iuELuFZE1YTm2YKgmSjfy99lRs3lR6U0YMr8ZwnH3tcZjSeGNuQnvkkAy+ZR
iGVaa1mcvjZIbHQaLBAL15cRJZBt9XIg/QNFd/XK8BukE47wv+uhlIty6726l+H03eCCCZzbXu/V
m+VYGffrVY9AXWXfQLbrAT0JYu8KlMiOoVJEv5Eebs6fKlRvM6LJgU5NderugSl5OT+tLLU9kAU1
MmdjvVk2ZlpFbKpyIfWrIuKOtOPEvQ0S9tumdeZJ201+ZJNEFIIrri3PiVEuZk9T/0eRoGRKEF/L
Wqi9QkF6UjzBzttd8ay8vhDUHdKZ1qUvf4+Vr7C+QqSzirjQzkhdv4v85yYvEukKTxBOQxwTn4xg
iOaMcVySjtuM/Pmj0nchZozmZUwNiUY7PT+ckaoxhRq1VoocgnBmBF3Nv/kOoneaSqAGcLuzjJvA
eEnOvsh89omw8hjKPKKx2ncUgwq41mjUHFe3cay33PkzOPO1/LLaUS9dWQeY8VZO5pOAWBljsPSd
87A8eHOBvrEm+3slkX+X18avPTXRsO8533uMPjtBxoZcpsTMqMGbwm7v1AbPI3exBArVJcB8DquU
+0M3UaHVvLitiMriTUwxIrZh27JN9wMvNhSk+jhIL8mPKGRhhKSCaSUHUbgNCgbypOX54bnpi1Vm
9kQiMXiKcO57711uhXnXzyhGBhqZPTuSvKRAhGsrQqwp01ApIZEXk5KYaeJaqcdSI+qik7eqyXmu
kJYf/stSId0iRXDCKksnnac2uykU0Vua1xzTijXqR1IrOEagoix8J5qXT9XLEYgDqHmHp0JR/4wn
NfJkWeptKB+ubzZi96DEebZ+JGJskw8+LrRAjd2NOIiGqX8EJs1Ep8mirIzGQDfOJdogLCGoI2bA
q58Gx/TQvxbzvVRDXL2BXMKnlH5SiNR4NlAIt6aL/6VQ84niyBM/PkYNdUpOwcslQVESVknhEcJ7
qU767HlOBP+HV93EPd2fyIoKpdeJd1lbQoz6fNI9jBu5i6KSITureP3uzcGrqkh6MN/bRzkpVU0j
w2+AR4D3W5UNUKyvtefEqB+LOoeWmAdq5Q4zWdPxeJ0x12E/5psb/8kzKxH3HK61whp6fv9eawK2
a9QQUpHOULqHWGX32h9QPtonJWBoFJFYMW4G9umIcG91BXHqMATIJbfmdTpIKCpcyFSUXcCm1j1l
DYJY0CU6Ktrk253ZZC5tk99t1BYUS1/iXOnC3UU1DVN3y4iX95kMCqFQqZa0Id33CDoQalv403HS
Ccf0UNFYOrx+P4X7xREYrllE5PIqxLRXr59puIYElTlWO7d8aT4dw5d2KQ1Yxn/WvUNFX8YuDUjr
Z1BHJGWg3BQ4lVYHHlOjGi1RHrhinElkmaZhgSImqYJV0YUbasedVR55ghXq/7J4uqdc+3V1agH3
q4wqXFydBsYaWsva9xQUAh+WsLfyKCdu03e5gyiRjqsu2Y9vhf7NcxhOyo45BdeupZQ7qa4lvin7
QObpSX/FhK+FITU4I09WFgdtNyy9r8x1R1UQWSs4sTbp/pZLal2BceVQ12S34/73x+cjhPwXhjzF
3R/vCeckWmyEyv6vviGfS/nANvXD2a7Hma34y+uway8M9FMF/8W5sxFKYUs/gh2ZrC/Plk5D8YXs
/5+Pi+pfMyyCnNiTeC/I/5fjDp8qPNjkhMfZ9r7p1QwhAwBEcZQKqM9A8q0gQp81QqJX9eUSVF1J
nfiWs6GznrL+SS38bYGgu3ed9yLPW0/yCwWGSvg+zpg9IrylCuXBd2JrH2MHO9go0seb8+TqHoHc
CHsVL/xuKR2jotZfLSe9QhmLLVYc8GSLHWtxTrfs/JOtjnXGXZz+lG6aRoTuWI6T1EaHieUlpR/F
IfGcCcF/Euc6TS0MVZ6hVFiaeydIEUBFPRdJ6dDYAUuXynZuP2v1IcKtJ2U2XlajPOPmU9Nl8Ylj
luT4ek8aj+cfOEa7SySRRUIOYwMSgDx8lJa6Px25MxGAN6+3P80ekhADepfPClTsQsHzfMoB2Yfi
HVrBMAYyrnol0MueVUE5ARPMRf751OEbD92hK0r715eK2AwSo8xgjw9EU7Y/4mToS44XVYEGuSTd
9z0KHRzUOn4t0QQSg5yqJ+Y7xopaAO5oDaog6+ioTOsQO0a4W2o/WaKZh7KvY7sLLD3KtA2B+9hH
IgqPOzDkampDgXxXL2zBsO7PYTQZ6vzI/v4/Jcl5PxQ3LmWSzhc9g9aKt9UE96YcK1hcVPmdratj
KkBF/Kp7fFVGWyzHxEqmS/zoNmsGuYxFWL4tmmprbfmSgNObqX+HD7dtODLlRQX/AVhiXnO8pBQ8
dDE7C0Nnm5t7Nk3x4xYCVo/+mROEK5MFKfIq8aWUpRsQ8HS708HmIOq7tFr9ivXmzudAJkoqsK59
C0E8wpJoiAGzNldEcblwjAM9RCOL5yrCg77yVY/DSkFsOBezqa9EssD6b3I9eqZSXzI1Ke2Ps8ns
LXjWcVlfQXUT/A0SaiduoS+v657B4L2H0tnkaw9stlMl1/CQY8IqN0GOrTnCLwWfyLKO4MCcu/ij
u6MjZR3t4KIqnm55/tiOxjpBQyY90c/3hsRqLFcklbPwXQw+gXl4zeh7cVb6G9wGH5o2/1Vkq/RW
+r91SKjXwuYy9Rhtc4ChoPFao+Cx0KbiySe0xWpHgR892tnkU3JxGbFClrciQsB/bNVsNcbdr+a3
I7bJK8nrifHOotg0mk7NuCR6Hgur9NAZiR328DqFC+pdT2AfyOHgk8cSSq66KQC6s7DfvyUkFLvc
X0ZDSTaMFQT5Z9Uv7TVbEnBnlNaiQ9gV52D5V/y0PKJO3MGAk9pQgw8+QuyR6QjSKMS6VkDbxVVh
yGvpDg6MYSvw+ZMKToQwCCL1l/GB1riYq0snPQ2Zb9LgPf7E7TnmYMGolKbo8Jz0uZ+mhlIi1nCS
QX81aC3VjLNugKq/C1/mXS284J1EJGzSLPUgXIlsJxL+WKIjipgLNm==