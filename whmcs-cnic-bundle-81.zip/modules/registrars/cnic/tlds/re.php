<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+fWi/uwumVnmwyctQrnZsJQETDhyRzF2VfiWdaR4Q+fQZRKo4ntn0nTHznu0OfjHDh6y6s1
omao9EA1TQVUi3AaeJBgyasXq6B6rU6ET7CaHybjX52yc0fV6QcTmIEM0XN8Ir11d69DLcSOoFOS
PnQRAb0/W86XxBjXvEFzwxt+OUJfp5aZrnAi995IoveR/0xIXJMsresjJtMHEEdNrnK6pEYkA+mX
3BsHlkqOeuGikkoIDODjvNe4VM6S/rKjCuO6gjpX9MiiqTvUd+QOO4ckO8Vw3czSK16rGRwEeCxw
UP0W1sEchO+ubCDdAdI67Ha5vt5bxeH0ABtrfR5QPDx+RMzJh2UnQQRV67M+Cs5BVZQFhaROobAt
Ns1OS5zgjyKfw9gkR+nGp+76gd3lxYT449TPJ6dAuicFAuj6z1qSBOKUX41HRy+AgcN22bkDA9zU
5BkqDldWCrvZreZiZdkZBLhFwxJF/RyJ4IK/gaNUjDoKOaN6NyuouQTAioVvD8C4bhMxLPT7XGlM
wOC4DLWJGBnOSdWAIDAG6QcamzkauvqvFecpQdjoCNKWy9aumpPggCXEpNNSxNJIeVchz/agiGd3
WDrg89tV7JQGptlLcQ4kTyH92rtilQveSL+w4wjaMBnQDAVsPBULoTH+rWRYZtlb7lXr0Am8O+Y6
l3PS99YXEIn0T7bzmKJvQmE9BmR7RoCJLsCwU9QoubKCgqY1qwo7Je1LW0XRuJX8Daf/3ksqIygc
Fg0LEScRCKNzsWZ3cdo8OpsrSU6oDhZCYZIA4DRIuM+93NyDmRy1oryTjbMxdb+zb+5Krm1xyK3H
9aAwvt4dZ2WGIB05706Z1VVx+pFPZpUB8eEVYHtuXJI3fWhGmuZvNX1BThO6E/FQrRM44q57Sswp
N1WrjD/rTdzkeBcMJYgFCrEU0RcoKxynp6ozG1YCxOYQai8FYUnxYGEexerXXllqMSzFhHqgIrFL
CbidGUh3bx5qgE9U/sozlmGKDHNdu3lSTOpkNb0mzMQRwdvH7OfpXK1zeJZaBUKjoaVms6LqQtv5
MaYIUtiDmvOVayQ87awair/d/wY5B2VUM6yRYvFjRoLbpHm1XvZiES5EoxSUie51jw92QfxcA0UE
sXrdNy7xRy0D2BJkwdvw4OZiPo8Su4rQEv7RAyjhGGSedg5Ma3UbpMcA0meSLJMQY65JwCmhsTGE
Pwppr9Opri4EE3CaRfdf6AyMXDdeI4BA2flZTc6wPxd+mHTVEBChW7U4tohFpk78F+ivh+iTXxtU
Ww5ZgSLESZlwLJgVoUdf3OlQoXd3PkmE4mVNxZM64Jv6zMoQNVirWnlD4aRV0wN7IfXG6757iW2f
ujnl+UMgp/knzoYUIKqGnAMCZ95eTXv79cPHObpDUgOcpB7x0iOXCvA7Pq9Fvxn7vmjVfQL1VLvw
d2omnZv1hp8GyRkL78j/+rybgfWvpgdb1HvWTmlYrhEoyIn4MRcHTHd1Y3tI0P3jZcMFREHdJUAT
Bb0wuq/7yc3CaEIterK6Txh3dDNkbtr/ajM5o3Uk0ou7CRpPiJXS+ZT6JVwkm6N4pApGBMusG+bv
9O1o5XS99pU3jLjFJOSnyCJjpPjX4J73AmZq8qCjZGJAJIMu7gkPjRjP+ISBq/Hzfi4lAm69rrcQ
yqm482uM1kirOE1FRqzTTgp4zgNoFlqSBMvmit3mzC2NTGUb7bPHqxObYuALP47OugLyZo6SA6Dz
ZeDHgf1X3aCZmu77m7mZs09Ojq/m51Xi/xy4iE5KhkQF5HNp9Hi6Rrlu2cfnxmyZd+quGhhonMpv
KXCtzNWEHWRvPx37xbt3D4nrb9pJ9aQeWnnXjiSwOwZEgkgcQQQgBK4VkSV79BBUJAzX09rw6DvQ
UHELqNU4c6SYX5qcTCME1uMcba1hJ/Nu29+CM/mccWW4b9qFUYdkG4iP0qLpsOqTeaM/vdn+GKTJ
HnBB29NsLeiKOjK9KpNzQRcjtEqp4nL9Mt3HNZHXMsSUuUYTxHq5zyahuOMBgmC24NKlNtxmZybM
nlp6Qk1RC3CjfGk5zN8IaRpXPo/wNDiQpDHqj3r6g2PJOPHRjYci+YejtPADc3xwMO1vk6qOV9XX
fJ6TNgKPv9EayOR+PE5KgKLJNwymRhgdOnddqCoRHzHPZ+KhUSR7inWlUNpGDx+ibFREtPFJ4/DL
P/ScZs1eRDpUG7Qga2eCzYxHKVh4N/YEJ8wsZ/ArIC7BUr0B0Y65pU7y9/emlrJ3ppDnDVwWhdhc
J/5PhXznpF1opaZa3GGLmP5JZVItBpf0J+vt54FXHD3wmW/vcPXdBhFdGZIBomWbNanMBNGhpUsQ
u1jys0CBUXt04Sc+6f7+X8zF+paNrItlxeLNfXOTp2K77elJ+PLYQ+FVu3F8m2F3lkRP7ejEQ/mc
lvQMA3BXU2CNEMxton+fBOce9ry8jgMk4RVO3NmeyHlLG5iIp1SIzpzsQf7LpRbdnXCcqw1xpbeF
NM4BVAnV++zOicvKs7lV9YWge9LaoMvJUvt7bdTYboopV90v/qiV8lCE1sUitN/Fok1sjOOcWuRC
8k+bKtz2Xsce5f+QfFI7z90xBsSrkTydWxb/o8FtsaieC2enfWigSwEeezw6AeHjjZu23LZQB9PT
QL7Cc18CJ4qGQTMj86XRVwQOKHR+UDXw1oZ2pIUva4jDiR04CH+qfDCb9ZRRX+atVy7HBELOKvyx
FpGbBQweJ15Vv1CSZBSz4hnycOlqo7K9a8a9FfqK4F3wStijaDBYL4rP5FR385+5g5HNmmh06cPm
TaKYHhhwxRbVngdgrD9W0/oLZxt5fk/nykbhzZrKTAlaowjSn+mxwXzggC29K6lGaP5IerYV6Ops
6u3+P5nyMr/IUkcuJZCg/vqkogXVzwqqRUGIRM2ARrSgxdL2ei4DEvtFoTuFt9PvzqKITW7Oe7CP
adcxSza1OjADtLPG8w5Wk2vW1EQd37faQFxT1ikOdbEi0jqnynYc2/bbBkqjNMNT1J5vGW7EQd+X
SfRI1HJ1vpRppLj5ZZ4/PffBEWtppPQrVdOEBLxjHL1OxJLn/wbuhDqMqiCjspK+gzgTQCFgJEaT
Aj/a/sq0IsADKh3dgzXY8o37NAzK8E7jU5QuV6w+Q2x7WwwUBVgLwB9mbmTIvjOmCUy7dr/gJKbo
SkHVZZAwEQ3zRONEdbJA/h5b8Oguk36euzffQ0AqrTLoYhTzN/cPx3aWhW20u/qsvLi9/rRKGk8+
TaTPrbypumIJcCHYLwSsov2jwfmv013JJbTEcbITuadPdY9fxMGnd+Hgx/zSN6lnsMxDw7PYpvNV
uoI8vg910gFNOOSe0uQhXeHjLgpJwXbGTXlFg0i6DW25jpVhx/D1zyrtD2ddeCvPiLASWpFJ3YPV
Fg3Yx1dHrH7/344KeG0YRJt23BDxmwHOw2BZ9phT1oVqALYjm50OYGmCwxLeuG7Du1pURuWxXgnG
s6z4IhfjJdk6i8trb65qD9t5pLXiUKxX/RL6BUwyRvdvobYuAWld3jWYs0yx+DCGEOEHpUpGetK8
FRtOZmBRyDc7yxz3YdHqxxl28a7PJKGD0/LPruE4h8eMxAabbbh9rAvGIUbihZfpHqXxiCClK/1o
O9cEsoQDpEucjIuBRbQC8Eg0MnCE4QvJuHa65dhOx7gGDOtrt7Sn4r8IerZwx5j6K5azYhelJO0h
0oDCgBRQN8I+13HnBnkumH5oi+YyK+pS9ecxDfsvTOna1U6hHpBzTtGB6K6TU3PckQGBf1Ml6tAK
G0sCmUyan0TOjMKmUBaBhvnsbmEvDUv+FXIzXsq9Gwqa9b7H