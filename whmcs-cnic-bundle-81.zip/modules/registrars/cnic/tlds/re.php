<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsoye8g2BXcjMtCrgIQ0bzuLiAaOaW6Oi9QurzVGtMHdwaM0ksysjLqrtljPUP41BJAdn21i
Xfnaglyb7u6jroeE8Nt4oGm0O8gSyQng6IUhlhw9mg/ZAoy2muKag5bB2LtcqNQBIKv0/jfO7jCb
NC/wgb6RoFvDbuwB/VNLhumF4AONvAPIxaWAXjpMYtgwIiAWZf8vYN8c3c2OrgYlFrmUmC8QeSVG
pmHSNuDdmBuz2RbnBgOEoiqz/DUN8Hifk+qTDfCLvma02ChHsZXShqNyGtneIKRKL8Hy4aExUqQc
6cW//uV7N3ew9dAmJTpOpUOM1MUFfUUlkQXLRtyX1gJ0pbz2NUCl7MQe4g+O8bWnfRjG6xSp0kWd
uGkTYu5AE9b/tC/d8whtXY+lWtCOFyn5r5s8wvv0l+SOxb1dmUZKMOjjq/w4eXkZ0PUeq2+6bA/l
P3/vmk5EOP+QSzS3UQ6D6KKqBgi8h/EduIoy1L8Z5ZYRMx3OgFLphQ/a/thAX6XXPK8Sp4n9Pz9j
xyye1w04kMsQBRP6pQvlkcbEec4N70MDPRW5bStAsZVYwlQFXNXTzPotZO6/Je5Z2p/lkT+76shA
79Dsq/7Y/tAWUqN1n091E+DZBl0tfBk83nVAuhPBcWl/ZfKDH2Pu4AgT+K0P4S1C7twAvEYOMeYf
m6TRT818iKFF8E1aQmQdZ4n3chbG2vdmR0rhXjVV821SzIggSWa3aSheKTfBNKlz0kkVlfedlN1c
mB3o7gen2wyXzWmVNsTaGZa8gPiotm25FWo2Y7KkeyC/Y5XcbhWV7nH2+LK2D3MSOEuNjl7EKJIL
fKEjv4f2CzYwV0Hc+DdQvrlHc+fIUEwXXNHgZPD/Nw6qWvJCGh93hwCM3lWfDQYv8TYfYiXM/FWH
i/V/Erpky5uzfCcJH2fCgx8tPk9q4yrnXkDCYR1Ux9tY5I8+g4pFVXLHAX4W+2wShMRZ75RU+ccw
IfYsTl+tKA44nLmBt8e1mKjlvf18DYL6DivAQah9yJjGj+p1pukdMKDrKGQTmzDYk+Niq5CW1LFw
z0rtT8O3/6cd09+yBEv6CzA4uwoXDuZBlo2Q0cKF3Rxk2y/MIH9n2d4rYMSzd7ib3jHQI0y7r+wP
3ekd/g1/icdMmuxno3zuAP3iY0C5G/6tlqEuSVYrdkOPhskkGl9xl/K2iPuDhczhkLUtZt6wTpre
RMxo2VATBbQ1CmUXtza93+wzS+jEoUYQFKNvKTq957wk8/BEwmKSDAbexNM48IzeX8+f80G3L7vW
U1wt3OlMHojDSIvuPtSgJlDTplygghKLAl0wssr3/7zCAvxZDnM2EEu+40xi+OjlN2ogTnejqrfh
5R661Eg7SjgIqyXN6JwEjZ9JPAUCoqNJ8BK8uJBX0Uqhvyfia5jApBMtx1xkiFdOyJc3M5WxSodi
T6E7NZl6BAYqrqq6vGgsyMh+wgkG3vIXt3biaR9ZSR/HCiW5zLLanaV3wp0b6YIt3CXB/YtUrrMN
u9HZIzA7BX0dXPfK6In01MhywVHvdey5MDeooe5tLa2vX/b0MlnKozgJYGW7l4N/OE6c2Mhg2Z1v
tGOn4a5s7BuksYTERy1BllIeP0t5xhyWG/b3slxUVoKhHMK+zX019Zgo1N42Im3AAiBsCqt+ZDc2
qP1H+0pZ/3d/sZ9C7FVOOFok/SuKwNmcq5+vVFvrkzUNTzmrra1Oh8O1KrKHI5qOPdNY6RmKNS3e
ZmT9g5px/aDrK/KpaKMU5xkA+VbzPszKtpX9CNZXuk8g7MfTWhLd1lEPsGkecHWBu9To8/e+MJ9U
jb+3jnWKK8V/qDX98wulQ7wsatxpA1dYKXx0n1KuDPPjvcgQd1OO83+sqqcvH1k4hjkNWduXfi4h
r5u+xlaVcnycjpKH0J0AxVJOrwCWZfI3jyVrDAUQIpriIiHkLRNaU/sXTK6RnL05AjHX8PQ5bqmq
RDpCo7xNE0F7gYcsyVoYwxRs7y9uIewA57HIUag79rF5Cl+PUx/FqQzSDEPLBBSiyY6vvUDj4ZNW
+4lRA3//sbxURXEhuTcuurYGuqCRoUv2nmTLzGVte+60sBkD9mjyJt7f3XdZdqlQW4i8VCDH8WKK
LG1zUo4J0+r19BJmHcxFt+uRm+nH0Rn3DD4vnPUv64Xi6x8tP0jbejwAqELmsPviHPCpRE7T7qm9
wczPukElOPCwlaKoBwdWYm+adwKenAVb0G7tXcd6P8hHJVOIRXAqHDXeHssfOiWjS3i9ryU9OvW3
a9lK0Zz06nU/rUKrJd/iZNaHimJCm1sjYDpH/tlYAZ9U4BtCRSByQqZC1vc7LJxb63fKZxuikuoD
cSrQzZMeqNnw5svX6gnrgAW7dKDxgnkFo1W24feKlkQXvKe0Bjn9WO5HOS7RcXp2zwhB/kD1THwD
zKmqAx4Kuu1YVDjWKwkwY7E5/xOPK8X5iySKUk+H4ibzItcgOxtLituJ6whMlq8rPstSoyLR7i5+
qRP52zEWLmPggAeICHl6cVYcUq/bkaLMA6EHmN22RUCi4lOeGaoYfR/Yi5bT7VTSoEGwjrrxLt7j
cbfSeLmtGMJxODpaZjUnmzRS5l5Nn+fzE1SjpvndVtGN0LuKpcKnu7BgKSMp4jP+ahzOpIBGkapg
hg/mI91FBXrQHtAJOBqhS1m7SpYfp2R8yjv47boevziQrJz8+FftgPD3784Cqmx/eCxWcq1+WxSx
dKY2pEqBbxycYpWR3MTcKbY+PKNmfrwt6iWSIMB7j1wTnpL3R1KjqXiNQdjPLPDP1aJENUQrnRYN
Zxb/BG1fkAcODJPdoFBxaOtpnsH1uCkBE3jU7Um4sRIDQMIhmoGC571g3UTNjfXV7Hjd9JHyBtGa
xKqJeWs4ejlv9fm6fgb7Ml/Kl0J7o+JHoOh4M34LanlLXHaHQOppLkgpWQQdezyLve6/qtz51whn
OSzDnMZyx9/W+3doDtImRUohjI+ruLNDBPNfoq5IN36KHKS0CVJtmFMtOxnJWdVeZKcY7RKao0FV
fmIgg7qwYHylGOJRwTO3fOCQKl+GdITs9FEOtIdxioe+5qVtMbO6o+AHSwekNsCCEtvLq5/t8yp2
H9HNAusVesCDAgcAdWODsmEO/xplK+6rVogajNuHs4gW+vPDvWsf5t40Y09dfyR2QnMHj8E0oEIy
IwV3q5WIS8n8Oe+bZl+8ZIaVM6wcrbGRos+nG4UAcuzwRxqI2w5f8hP0tHmceuxb4FDUfHGKzoxV
QPdWSkE8pYtGNIK1NgW5/EDXdLIpN/zvKPTEZMYbIgzy7PQ4+bR67V3jJ1A6oHsFjvjYpBcE0BDl
ktGKaYtkwM0EJnwyks5NLzPFniU0cfefZ/sTnvd1gdrYTc263f5wGOSUAYoI7Ie1/meSHafegts0
2FGsJ6I1IB+vyPkblxQgtVaJHDYz/QxOVNyL2Qf8LNsrVKF/Jnbw3CDokJ2Q44TtbOKkFXbIYjFt
1NanGb38XeeC1I/6kcdbkJaOGnmcJcOF9okbUD29YTekjejZT2naUMNvu3CUgXYo+NEa9ob0FoMr
pIDzXk/xHu0xRdDywYhJBhY6voI7HzxqP9YNUaurDjqqCyscE1gfc6jk8sOUWnpQPBaQihQTcE47
uzJz8NQzU4edOtG80550oGyFsJAK0fBYZBNRshy9l9QFzIRQoq4Y/cUxPf0BxTa5/JQ2UhKdfJwK
z7JXfE4iiAhSAcLM6uf0RI7ADHSfUViVCZALnztQUUjUXFQ45pWJWWc3w8bpYDExbQ3oHLHl0cfm
qwVL1O2N/sq878Bm8u1qFI2tbHitwm==