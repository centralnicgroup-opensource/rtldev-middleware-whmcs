<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzXCR+SIaLF9w/twn66wBQ55MWMEQkwhukyHJEGOnCaRIWkZVxnrh8CSun3Z3bHXr+9VSx7+
c/J6ptijynS8UXhYXeuhkf2oki92yHimXDw6/8aSMiGe5l0Q9Ti4a3czbAtF/wvEVoQGlAZU7Nnh
o5E+x7kci4P0Ge03e4x+4h5Mo71EMsiRHdDOm4jNvvcEKws/ZcWqQw/EQNAH/gtyHpGghDg3EbCG
g+g5DNtpEt+PN5XlBpK5FgYfhNYkakpgUSwP4EjnkZQJ5US900ZAqTeuNAz5/4EhRVmAIq0dmOap
NX96He0cPsVg1UaWjQ0Qa8hseZ/hYJVRK/qmo4lNGeLNcKq2rmMnXAGqPY6u11dNMRtz0829tcFP
xXZ/4BpO5z/hfk2Tlrf4eDraPmql08hmXqzfuEJ3+n0T/5B8mlp+L6zoVFh97SKqMtFnxAZwXtCF
Fa+obmXDLD7Agpi9atOpiIeZ3ut9l2Qo8vsMXSgqQImH9MZX/XhTFTx3CZkYc57rEFRWPW/OSqNp
oG4j+CpLZxa33zkJCNle4SyUXwFH6mrBh8FIU4WD6r/DMMNHozoORqF+NfWhhazDvdVqIix53TZI
C0vWeGtPVEY287Cc0N8WbeyOmgZIu676T+ITcSaBZ6ynrFYyxR0UwtZKmuTa/tNenscDa7wWd9wE
eJ2sRwakNXMxdOOM3mtT8A2Ioj+82UQy2r0CB7i55YpJrcBOhcdJKvpaD8UnzVthg29ME+ASPrhI
DC8SGa1tpaFNI/AUQlpSEiDuVrXhRosFFTVAnDhA44DYt7JvBEM/h//otPsZabIDCVRLCPKV2XMG
IJdhCI+7ZgzbSG3kr11NX+NjCtFnzAcGDusN/y9PAavgM+dJijmO4fasdEcbWFvYiiPMIpgNtTp8
SohC9iYh4hl3+hF93Uv38ZgJnE8Sj59/mzw1fWSuRuINeDOFFNahUSMPx+f0koFerdPp8+Mw7sqP
3xEeOHUV/z/7ynfG5uaoQM8ZvycrqQXaQJClCh0eflU2nt272tGPnAOdDqBDgMc4TiQynO229Y3R
1tDhGDmZAo02u3sB9MxeT/RmE3NjKpPTsxOPv+qfN7RBo7kwoU5v/a6MXPTN4qAOFHsf4KgeS/TS
mUVIzjCcLgozikOp7aeGnMJ1nkQiI+5asw2f65Pr3XEfOL7AmNwUAEhrvF5W+Nzkg6MgRK1zRIAI
h++H7Lw2hg4DYKHYlECZ5xnCihTB4CFEM1SUpKIDeb8xulV0T7pcAJWZXmqOBwRg5yBwoFGxHWOJ
fhogOS3E/gd4hS/wt8jxDcWeVn9PCNVtxB9P/9vFfwdamvFx6iLf4+B8slphCG5bDO+58pFWoH3N
QAdIyAygvSWjO5h7IykkhHyx0Ax6g76jsu8IH7wTBJbGTlDBx3ss0XD+obBygso9oGh3IBedcwbT
f5YHdosCBAuDBaOWWvtNSn9SFJi04MsmRcClon+Bm9NBd9K+KiOKrH64OQ6UG8sYcrSqqrdfU4Rf
kvRBTyK/1myAVUv6fs61HR1b5SsjAfKEFsyQBC3BLwRXYwn03Xnn1e5lDi8UMokdTVDr/Pt5dvIZ
7DyhbqspKubuIMfPQKBWbtRpJUylfsVNsxASU7eVJAbJpys7Ln6xjx/KgLdRKQsgtYaUYULjwAyt
hCaoh91yWnbl36A6s+XIt3MiuKdD4iq10aBbWNvOCX2TrlL/IKNiCEWuEek3/nE3IY18ga1nAKLw
6jt4QdzvyyE+JUVs+v2qrEcwkTpaDPpNjWesA7m=