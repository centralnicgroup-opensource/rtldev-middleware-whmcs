<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx1oTNQPtKrwPC3WLPmU3UsScXh3YQ47e9uxNrUy2d2pa/QTIe58y48cnanL+pZmBxIXLV5s
itCtIRHAWHjr8Pz6S1LPBA+0/UVXiTOm/AyICSq6dnps0GkuUstHz57UM4/R34nMmyQtseGh2Rm0
zOUtfsbyU4rJQ+G8KknJj/u9ODCb5iPRm1p2zgvSx5r8asIsB9t5DOFz3bNGR0gYo6WAbQQ+KZHj
hbtmESNBOt9JwHf2T0TU1eROwTS3VzdnjQk8AxMbJpBNp7oroBaE/VGDitMnBynh8eU25ncomVXU
Y9Sc+yP4/uv+LEfaWKEKvRmXUqvqUWyQgRwd6wP520gwOKw05U3+ETkezMcXMC9omQ7brh2ZCQnN
rwo+W71ciSK/y3x8I4WHP7xlxahe+A0dQ3s+VAkaPSWdNGMqx74JvZEjihaO43S/hbnWkU8YxasY
o7bJPGUEmRwya0fPzJzQdg8gb9+/B2vVaB9lLi96HDZqYC7pWXTLKB3922LuaY3nGD7orxNP3u1n
W3O/5BYSB/Pi17l3tVpEBBYX+Mz9+rCBnoIcjG8wQREM9afYYB3iGYAP3YVq7fqqyYeLOnv0k14o
eMMBUrlcAkSwyyuzy8J30Je8oERQT3EMGPe20ZxVLZbaO41lTHvrwCODB5pPa+Oo/jZrVk1vS94l
gRdFv2CtTQnXmNC5f3gNsZhAfLzNHhUUXNTY2U39nlyAsq/wFiOf/M5Og4WtaykMLF11Dv5JlITj
uhSCFX1ikRBQNsdMEOLewDBrJ8ojyI8Mp0w8AdeBYflxW2zD3DgrvHaE20vyLBL5wOraM1gB62nQ
0B98zESFO7kHHdftdCZB1ojHvVwJhfXgUcVEYqJY/wIRqPOeB660S1+YdKM2/mAuhjHRScKnTZum
i2Z71RNi2NTe+d6f442Xg80opHRGXY7ng2fDW4yx9s8ZbZ6y8jxep8lxCdtfKLt+fywOaKMt+i2Y
A55JJZuUSaE3GioG6+nPRFyjWyF7/FIt0e0YdnzPB9JSH+Qghxk6VyBg7tm7wtWrE8INg9O8f7og
lTJgKqJ2qKdCo0KSUE8Ibv7pH+uHbrHHAur0YU0lng+qM3sN3gSniX1pex03H9h1rdjp2lUgUq1z
HSa66MRS+h/hMuJ/16mhA5rkoACoAXvsS+SS4PoSmK+yaDcLR5qfQeM2hRKWJ8zmoeVuRyKphtjj
gAHDmHn7mVNf44gcQGekJ81mHC/hEjkmstKqXbAJgXtUrq8aiufiz8qkPXwDkG3+SPUsMbyNsvQc
86kil6+mjzHYUtThLJV0xUPG/xIuvo7vT5qjgbmrcUdjqhEI1LtvW1j1GtjOAfgbVukhHpze0/sP
FzdWmpJ6evP43tzFwUL8Xk9Q3RJH63rT81MGqrmQxfYnQjGPEDZgY7ASBTmtm+fKrf8UQOBYXOIo
c+VTXVHpVZMQi/VyY9xDV5fS3AGGQ1JOlocG13BdOv2iQtA1doz/uWIotfrUgwT3uUscU4W92d1q
izoxGceR4rMuOH2gerIpJDFa5mokBWA/GdFExeemf3LlpM85ZFTcZK9y1/ANtH7p3+Motmq5D0f0
yrFdgpB0u28JeJsceeE0PowssaB9hnd7v7uXVy8LOovGIZEDOuhO6jPbGudFLzjS0TEnQMmk7o0p
qLa+h0R8bTzuPgbKiNPT5gOi32Czm9zzuesKvBRFhNIvNBEKxMi4Z9+982qOrdvVL8ipcc1EyrMj
Vae4x8w3xAGUtpJq6ix3OpRZ+KsN6vuWceC6AnZ1KO9cyqheIlFBbXyK7rCFXIfhuKM3GKQfUp3m
U0==