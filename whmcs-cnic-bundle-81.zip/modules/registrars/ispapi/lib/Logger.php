<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuXxk/5qxX/60RGkqfySy5yZ37GLeJcNpFXQSHMx90jIrq72xlJ9lYU+9inroznLW4B0IuIP
CgxZneFpDO0gSwa210vWpfcHn8ws6WXN+x5O9pBhpAzOrE33obr9MHMe1nkOmZiFFZbxL7xmOLm/
ky4K2j7WhLqmXReLyT63IZgdQo31UCKQK2uKdzja/5LCNPNB7uzOLc3GMlfBrV06CFuvkTCobTHF
n5vvuPINmYKK7gFin5VR55Q7NmuzGstN0x+BdayorynyjSYv3ltq3RDriIz+Q7z0ttk1bZ44WE97
fdI8JugsH8FDaTd2b3Sfkf8TTp9gjvFzL2oqe43WMgCw+PvUn+eI+SPj2aAwQdlEKcFyzniJZnp8
tvkcUZz5XXcNJjQyTi6Eh39C+gm4z2eKBfc99V0AiDy+0gJaRc2o2x0He/imCZLeAZtwrsgxymU9
0UqwEFo2uyVsZ17qJrblcuHxnzJrlkV8pNqXfIEFbG0ITAAADk/bGih9DQC3rrq34HaBWC5H7cPG
ABgBAhEqff+AVWffNoqSLGonTj3wFrePVFqlwv6l2q3cPK5hRRbSqBwOnIZiIqjgOeaX/IQDbhzx
SJGBz+FoY9wQbJkx+OHs/xFAVNw/q4udky9piymp6eHMZdk+IRzpYvSp0KHS2XwMUVnyXS4gt1wS
MJSfEoVvv9gPLbK4kwtlseISlHD9ufA5JxFJrHVmZYruVvApucj4os34lP6NkNLIL5MqgFyw3JZj
qjUKX5OEFI2rMTVvYuD9OX0evBb5efW/7Mmk901UdT/Jbku8d4BPgtZqUcI3+22ZjrfNSLucAR71
PBsyIrtwnuD5zqUfpdTkQvLrTdV7PW/U80pDRwVAm7EJMdENo5/VJCgciwRXE8gyOi2EOfhbHkRw
7iJEAk7m9M/HbFLMR6JgRvXYRzkvhF8ht6EWwW8Hy17Vcfh+9/Fg0T+M4607jzZrxnprwuQ3EvSD
EeJfNqYQqtQlrAkfIn5t/KuhAEX44PRq76J/H592CyOvv9Rd09/63mvvPlu98j2gl6hLlER6HGo+
qoMI0NeksAXCjfVJxUJTQ2KGVKSrX4K6ACELjwjor/yWgSyDzSfjbmtIs5AncKqCrNLxImQJRR1V
Dj3kmoOXGbV3RyXFtOdluoEymwIQHbT3mfBCuJ9sFRG3j+6ZwY+eK+hlDl/kG+OBjO+3jKFpAqFU
sVOxUxdfGyV9rOGULUBNJdjOPqlKmvR/wX0Zyv6McYU/JaBfu5ejTMJ17j4g3bFXlaCuL9e3Ud7c
6leFgI4RuJA+KowKHeYXgV6Kekiu2EZiRz3XHMOQYfLDeuTW0r2vQ0zoN/eIqwV+BxiZ48v94/+d
tPq2kK3qtEZJYVFYxkzGiVDQFHd8GK+RDN61a3tR4vVTSw6yF/h8YiWZT9/3X2gxwH1DCKtU+Tk4
EJYqP2VhFIzQIMlaoKtuZ8hBnvbk5hjIc3ymfowpsHagonAvZNPzjKfTJ26KNOaYgy9/JxL52VHQ
sqaJNJz94MyDztrwFaNChQpj3MVNqHR+ViyEFXeI/TtCmEsL4O9hahefOrVtrQcFEDBmKKrwdnz1
c0BR6BmDcW7kyFkpiuJQmrdUqKOjr9jCuzaV0NW4bEIJ8Xmd9M+NxfAdgR0/7vt3SlXX9C5rEUZq
9UWE0raUkPczVCHa86brKbZPlZ7Lx8zdJQOd/oReU9DnYmVBjdHjIXdHIocteF3n2SbLhcePFN2+
Vj2tzBCHsnysptNYieqc3BqFSJsuUXd4XS4DLn+CRtyQjptGk6D3GnetM2omBFWq6gWlBdFt1eqR
mwHoMnen0ZSOCbY+W1H58uTM+mSkdy3ySeZM+iwEvV/lpVrG2WrmxSWI3ksyPlgbYGJJ+sstjPfd
8fTt0HTxwDk9ZGkC0Xqu3M3RjmR4fE/OD3wGXVCO+7r8WvO1VGl6FmnrIXQnDHVdUI4s06c1r2GL
rBwP0ZRQZ+cyIDMWHfoEHPKEaXja3v4OPVxoj+DIg87tQ2c4nZdJ/mogRe/Wel8kiJ281s9hPZt/
jG4VnRyDLcgJNxs7kCQfKGLHGA/JyH1p0FL1CUeQi7xDaN4KIjwMeOHLrw2hRyNSEiUdj4GDxLuT
G/2D9Ohzaraf2ldnbpWtUYkdsrb9dCGbzGRwltzH3JtnG0Tn6NYgo8fun6EwFJvj9zdN25pn5Ekb
QEUM5/Nj4nbA+myQ36sO081ZOOXg1CNynCWthEdrKRUCuOwIqc9n8P7ZFulCTgi/5fQ6WhXZf7OW
JXuxGs/lPC0d8VD4GlMpdF87ldKwcNolNp8cJ6W0NCQ08krMHY4mwrVg1G2jgzhsbLuhZBIpmaFK
VDH4qTqdmrPuZbNQi+Ih75hVqEUpX9B1wYVJDF/NNMr1xi9NK56zKO7y7EzBWO3qp/9NFMSOH2Wi
ndoyQktjcScfomPUh4whwtfldmL+TYA+JoBUxugJEwhFg7vdNjrHyz/DhscZlI/DfNtzHGOEEUdR
4OdCMdrW8+o8OIhkf2zClHc/Xzb2LSU+waNj5uRLwHd9/DAzlTMl+2V04d1LsRJZ1drtnpSjmuPF
tBT8yQlcJ+r6RzgvtzoDV//6lWfSbRZ16kMgq5QMPOrMnFZepYu506yj1ejHD/etNB6iags5m1z3
mIE5tz7yafKFFhWkCNAnmDQqD1sDCydXVchUbAKO80SJrG6nJfiFUKSJNgqko7zWMZj1x/T5KqqW
6YEr0sBEBTGj0M+TjirTbWXKQF4comH1ncu4WFTAEIqWLqyIq+sh54Wr78jYmgH8oDRP0P+9C7qY
tud8Q+gxAQiwbkJKpeuI7kncGscG0pEbrqNnaZzzeOht8QeI13XsH0WiPuBx0bLG2imzjdOlT4oT
1OgyJHyxGEo9C/6JpiI3b2FVTCl57rg4BLvBKlF5DLZddIZ8uDwUno3Y+iQoIn3X1yZVURjTGSfX
r9Zs6Jxok34D2SaZ4J/n6ZV4sFSzq8dKb4h3G8xRpCeNRYCQvkiQpPx+RzmZgHhcy6+C6x2OTaQq
FMo7hgDG6OjMZjf/xUPMuMhvWTgp1dolDYysnnFkBWyTVcaY+D+qBJhqjbLbabvuRvPN7oJEN7b6
421655b267eXhmkbZ8dAIAOs8FUvknOi/SDJl99isRuPzJjM4luNF+JJCf6y7FVGckbQyUKqVtja
Str5QZtdBkZUtxyiBvPWYdkCWn/ukGQL8VLI032IS2hCak3F2vV3Hzqx7hIqgbp2dXGv5gs+fbtP
dz5Qa+b+H1EFTnLyg40uQ/43WGjDOW+E4CBFDVGuUaHQIEw7luKwXD0ZqsIGuc2zYwOPcvLF0F2w
LqaIP2albYf4uMwDYDuwDImGCqJ2bNBPeo65Fc6GFq0L3JOrFb3s62vN6KiksEAun/TzIfnZnM9D
zFTBoajLmkKWEjfr2K/n0WLaGaEN9eunL8pNk4jGfUK6K/oesrg/CXk8JsxZ+X6WxHTzX3PjgKew
pxc0vOFsKL1o+fUkae+v3c9crGXNxTXQxiPY23ADJvYmFGVjYPCAErjY4ITXI/bojsPrNFNMQl1y
BXb7uHQVTNbkImJ6P6g0uL2VswB4l35HenDfF+8Ie9IfMHvzb5UmNKX6i+BUR7G=