<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxdLMgjDTR+C21dFYEa3ZXPN+Tlh6+8C2OwuWhDFK1HQtSzMeVXBfFtVzRZJ1XJmRu4vLmzM
0C91oNyEpr8k2QA0renyhknJQmbbfHUtpANthab+vuQcGZjgMfgi99SCw6YKzGMZL3HGpVz1Z5p3
z4kqoZ3PNDUN5kASAyZJRonMVZtVFYKw9+90Aoiq0Mqzq0NomHtQeQScuGdLtL9LIkmaeNs/p36K
sR+7QwT5Skl8Z5LqmOprSwRF9qGQWGj0gA5SJpBNp7oroBaE/VGDitMnB/bfNf1TkNJanIm/oaVM
v6T4OTJ4Paa0tTPbTX1lqxbmVUvkAzonuj1E90rPerBd6VZASN45iFxbumcWRVjkYXBS89EkqwhE
vW6iUiLCGAjBraeBnnXW9m4TKmAhw6JQlV1aPPd//otZMPxEfGBkdj19muI4yqUTz0Y156Jicrx4
R/AmI5T1zF9uIA1qX/3R9mlKgdVNxH6lOh0pipv78nhtQpiAD+E4chk+Fnm/zm2/b6kxOlAJEWFY
NFH1L+/GJdCugz0qLFHJue9CBOoY2j5Lnf7h6RLu/sVqJcUyq2tw06CvqbV7AuB3WZHR70RBWa0w
XQPAnXd4E4MtYvNJJPCUlwIt3+H0wYsf9qgCqs8v4Nnyu766YLouTrrpUeNlfHgesmmHmu/t3PuG
NYGsxxk6ePq5rcW5PVeK8Y5Fb33DwNcjX9eHVSt9Qz9GLHL1Q8zzbGa3gfDWvsG+mrtNVNdamYx7
WGYbWka6oomkJEiiO4NXB8zMtfkx7V1xCL+mP8zu3TuoAk+H81jYovcysW6ArqGj8lda7KXGFzYH
dWzupKvEvun4BgQ7PZIWuLuIA/HgLgO1dKYPrjEoe9szx4x+jnQIxHKMwWuScv0hGpvKx3O66OcP
67+rvHYPn+cSbAwk2YkKN626uQYHRFy3lAQTy9uxBJgQL0urbW2Z6LqO2C+rH4by/k60kIkJJiek
oZ+lkYJD5PbcK89qlMxVACHSZBHBYiG+0mYfShxDKCVvXIfZ9Zj2B5pBFdXgvHPFHZUzx+jRy6/4
LymClkb3X773TQ9YGWR2Yj3RZBS9Fe9wSW0KmV+NNQea38PhP43PRpQEzVOYhGKUYNKj9cz9Dy3k
XLtrweuPngR53fa1WmkV2EH1KHCHrCj8/5EgaDjoJvUlgKx6A7MIpvPZ1xBeiLm0aOBKmJqRo1i+
fpDl7ug5OhAIaCuDpLwRT4i0j6DVjaiq36Qd5QJfCQ0RMuMH2E3lRceuGHquBL0j4r0vDxcIT3ii
0vYONrAEEj4iYT4H8kR8OyCBb50f3e5cTvykY7yDgMsvcBjzaQZ6SSch1t4XrOcBcZcpDbjpjD23
coSgKec2mGbG8hxeeMigwf3IBFFcRsjb0tdApmXWWExlyDeRd/sIGexpCvXeIt5U3PhhVOS7kCKP
ugz1k9V8s3MO1OdBH6cLyFP8uEqBuKQvrkh1jK/+uzMTNmgseIgt6FzSaYyJgJLEArZdIjH2j9aN
KmacYMTSfR4O+tHrdV31/rv8vyH8zehlf/0x/dwabphkusMdbfvUKbifkhbcQ5fqTl7x0GvwJ/ij
AVQVrPGx9SZQxTcAn6lMDcWB+HlXJu0wmauDEJPbpe6ZI2dcVdQO8XjK1Qqwm3f8pH2cAOU2lmB6
qOCGVrOwJKeGGUJUlSnQQsANu7jHtRCmVmso2sZCXsEwmPzWJRGIrIfTnhXIRJtMFfzH1UT0tNiN
pj/J3TIHjevx+amBpSJcOe7zi7ThGztJm/i0UHlh7HQ/IfeewonrqAG8o9YyctiphPqD5z06DxhQ
7OtGaiarZoFoyFQherybE/P3ypVrTifDgxQ1maJMlAbnOoOUP2ohQ2rJfehCScK6romuNQEf9Qzm
Acd9CIZ6poYVbu24L5Kgf/jnnDCOGu3NoTNWiJSFSMuTd0TSJ95Nll1oVynrc2ZHHMH3zA33DOeg
Xw7O1tqGEraYrkNRJUTeMOvsVVm08kiIhnm16JD6XB1PJjNZ6lgJMH4gX5gjq4Fva/P0U/zCr+FZ
i1m/vVHdX+QZLyC/UlBjcRfjU+3Mxpawf8KvEOq2VX2zkAP+DgeuyFDIMIYg+Bz7UFLsxt3rTOhZ
VaVRVCAOprJ9KUEnED8q9H/HMxAA32SPQxiBGpP1rdoKblJYcCACVoxbyQE68vgY884xocc8q87t
HQlmUVTDZmSDPV5Uz39tiV+sNyyT5gW6T4dVR2veEL4Xq88TjQCMM+t9VU9hZ3hUqX+MzSSWYjA/
SZv/XhdHmSwZTTDKcLMwqBn5pGBP6qu0gXAkmQPnFOHCdAXgbYH/oaBnJ+t/nuKuyA8lvlz5Tc+3
1gPq7Ey5NKORVnEWTxkozZFeKKgMai0BkHDMS15HSeLXFR/FhlnCLGJqyD9PHPwOEYvx0Jta/yth
tUm6GYjWjwQtv1rHjFn1dtCHbDiHMsQVGH759rOcvwlCm7YjJHv+/RhkjwR+XW23XK7iIrZNMDiW
PtDxMP2hHiG09ohcZRjpd0bzxXwxkx8Q71lwWQnFJ6g5BM6LN5BmiA6K3lc/zGgW4GQ+V5lncus2
cWXMVkraFnDI+dh9/1N+BZyYonAXYkbPgkhSUUzetCGMMYu9je7xeDzeknC=