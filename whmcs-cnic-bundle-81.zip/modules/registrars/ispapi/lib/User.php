<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqesy7SkbCXuD/fbLE1JdbBmrnT4QqLwxyLwyGFQR0qctcWmcNepeBx99TN52AODASe/+Gd4
osrFWAmTvU0xhB1UO/kJZvYn/+2ousMfHKiftoi/8RJe5ghkJrHdXCRWHMUM+/q0nxoGSZSteme9
Gxu/wr/llFAjjgyB70x/Zw6CY6GjDVxXjJ+v3L63doFrS3NkK2FS1QEQnKx5lpTyUkcLk6WSPW/Q
FWXgMoxCnUaETv+3B9sZor7LAQLGPPKE/ltUTsLFCjVCVBN8kGxzz0spTR4lf6qOUO+wPLAR1ZS/
H/Ql1nV/oXtp9FZIp8pV1QkO4Ba/sWSoKKg/l+czeKE4fWrOVxvBfuGdOH9EOl1F/9gObbGMQiAr
TBMGOhBtV1hX1jDiT+C6eHOCkFkhmHaTAGkShScOFvwilQPQXGbzRVDDaRJFR+vBTKh9Lu43BpJk
rGnrnP3BSclMxHTL8lZOuaSfPeGUFHwZ7lbqzcJqSYjSvvNDSOKItmhNlNvx4UxYkeL0a9MIGMsK
bARPFrLZivwJ7GgiviTt6mVfNPofzvlKn2S5qBmS6yZzwPsHYYK8O1AYzgWCjiBF3KnwV5CgjWX+
XnsZb0YadYP+lxLM5zjOOVq6p7qGrCMRzLZYsVxLh9wh0SeN2Y8+rGjFL8/0DOBojsOs6e9HPOi+
glIq7vp2P8aXobk0GWLjcg2CCW9VlZqa/kYCWYbk4yTddNxReX6U4JReMSkd31nIVkZM9WCNtt0W
R1IYWwRG0esWLFw8jD/Ih/+Pc2MEmPdDm7bALXc4/vWGCbpUD1rrY33d+Y0g/DKDImYuQwKXm7LU
EqXOOOFu3pZbIeHnYMcW+QEH7u40JGL19a/+3suiEnhWeUDIsypA1V6b41iUefUBtzlddnfY0tDY
DWm9/Y7VqM23WGyWDAgUe8qtxh1WN57+B7EnFlVxxh03NRKLlx8KipKI+/R503/oZVfQ8UbFEnc2
H3JSfv8AwDb7/wiAWoN7U8irZRBVNdHzlE1+dXSr3S7uz0E+P/bX+A8cwSPbPWMc3mFhKJ+dH783
ZCUwMnB0PSC1Cev/Hfdvwc2b4h8+7qCvjq664eOvSGHc0cZHT+gLMGatI347liPzMQk+a9pYPb5S
9Rhz2H54qw5/UR0+o88+59M1e1jtuugj7/PAU9zMFbZnSqf4plmw5Byjj4vjWt3Ko4EGosMMBffn
cC6+r+DGTEiJ7Py6Eap/sNWdY7LL6sUhLs2O+UxcTdz84wrOpfesqmA4bAE5PBST7WakpEkEfiDA
wwOnbnPLRu8L1ax1eEsUwQpCdTxdkk6rkI+kC/W1yZF3BjZpRN9VT0nbnQMadoXXNZVPEMU+fTSa
hiijfc/rHxKXyyRO2K/trvwhMHZHTx7KemCVijop88RbFhzXl3PkOSZqczyTXNo+MeZBA69GH5zu
vzqvZWLE/si0MOrvbZO6eZ4+3rIIH6wVIzfjB2/Qtx3GANldJZMOs4Zsn0oceNUYWS/dbQmI1QL1
bxrxrVgi4FBcrjy9venhHeQ+yu1KSoWut0YwaTDMAiXjuSpAU2hjmXWviy+R/OyaqWQL95/kB5OW
Rb2cKMkYA7KEJXbeDAOh7mIaBGzezbAaR/9aChaZ/9KHQJ3tFxt0/CZD5cwhaV7aLmn8twx2mZcl
fOgZeWyNAh3zKI8R7BKsz8+3mW5GRsTW6Hr5qM4EGyswBsnACyXha65O7iaa/4CbgEIwQLSpj689
kXCrNNnge6Rh3HzVd/ek+hmZyDa/SXYZ8aY6v1qcR3z/6MgQJemJ/GiPLm3Qcv1oIszD1KJer8RJ
KBoPdSldtM15A9hPPFO1t0Z1BPKT0hdNWaoCtYdAQw4pVYOl05jynTiS3vnD8f83JanZ9WngOD0W
/GSTMwIAahOX4ps1v6Op/AyTZFG/xCQXdFfqIKaYozIactc3BM1RbmVCrETI9ZDM4qhWUcyUGoZ6
RqETa+6nwUtSMs0ogGoIXvtWuVXAiQyL3H/MLeiQ7MwlRROPqbc2RHa4nJqv/qkeuAZ+n6Di0aow
SOLNwyP2wCW++rr76py75CWRZ9oUE5B4vNcMAMWHVa02uOlDu6YiXqs8XIenJH1+B8AfOyYOEAwV
KHF2tIciWlqZKgqLjAdvoGw0BbONbjE2RvsjG6BQGAAaxqqi5QExyWf1rXODWqjpyyAsddFOnFH6
3ptWTwtNOAczsZJgZ9U23o3LpRyW7XzVGUd3voxZKK9j5RBjV/9pmgWL7GJQ0pOnft8Ml/+ymLD6
McFnZYu1CIfuhjmq/bd94QvKeyCVzqcBbQTSYufFh+ZBsARhj07MTIK+VQPzX904a8S8i/E31MOL
hS60q1q6t9LZlLX8jYOKf2Bq0SNj1TgfqbqnH8fnaApr93Xo6wYDDctP+Vt3PF7OQsUZZVSWGp7X
T5vuK+G6QUHoeNSgJbgd7nv0m9YFJB0t+a5t5vhFxT6VZ12PeDtKlwjl4IOj6BkknSmV2AbwqsK0
1z0DHhrBgXP6m63SFsRCKYMYFoP5HCKhpmOKJtSIOA7s6T03W2xq3LAQ7rpUwGu/0gDszyVwThRD
aDkme7MfRz9H8Sbqei6BSPP/s+6NjVC/kpcngWyw2eAGgxO05UCUAxkUjfIjNeVBmdFhErK3HRmq
iJbwd9zeeqFVkgiTRrjCeU7tIfb+XhZ5wari7KM3yfJcZhmgSEmm