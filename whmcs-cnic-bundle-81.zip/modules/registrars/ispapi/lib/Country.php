<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyDta8LWsMYgVSK5fZOSB9050xBf/zCFES2MXxuZnWg1LgNZP4//0RWzsxmPrACgtd2OZ9KU
t3xeSl0cYzo6voDNiyLrZ+vjWUUgLP3u/kagS//GDDvSfPCWSwK+MYMAL15kt2nS0B6UBA34nLJt
/cRyG9brs2/DtOYzLWGMahM9ZwJQ07BJTU3wMpcGZZqYjdQ77mWoZKu6+9mLwHmFL1flz5z/mNdP
dTfuTdy4l8r1Zo5Lbn36FykXImUJxSIXASO9YayorynyjSYv3ltq3RDriI/UQzCqI+Avz9apqVj7
1ZLeTQAzz5EJWvg3QHBOsPV4C0+GSkt/VRajdQPw2+6RtFPfWKd37l9snWk1sVhwCFKxW9Ng38Nf
8+bE8LX3FMrAqKyByKJQeJV8AHWjwyp/bzGjeGOnWU4WGRHpP6TLGVQOwO5fo9cja/pWynacWW1i
DWblriPYq8booXPIZJXY9iPFsDTwDgTMW1hgDoqK99065iluu9P4SQYT2xelpkjXXOmOY0wLSNrS
ga/wgUTotHTg//A6sUCGpHOGGNVjVHV2NMGvgVJeUvn8wFWAjuXGJog0KvRBeeUNLYhq3bCUBBKC
tA4aAQXwZ8IhVcQ6vwWW4PZQZwqAZLyk0PVaYzPzbCt/1+SpylrN/268alRFQTCALWcVPZq42O7s
QcntKZdJ1KTOarAOvr1v5i8EhvDLUssgCPCVZXyKnTqHLqy42oVl3bYkyew+CrIbh35c5tijYwt4
NH9/hHAGFWW5Dx2DEB3Q9xBB8b+IwVpH4zTK/jykY9pRNaL6WQMMnssughJT/J5g1DX7a1aoxVnx
oEbLIj4No/k9c0GQRIHKXQpGuR9odhWEHeq8dx0PTetvhfDpJQwp79cbxvN9EPm6vskG3tUtOcnF
+HTFvf/PwfkAwPzNLJBYsN/dSAeYR0ZI2W9Dg/+1kYxQObVw9Hp1DQaj/VgTseskw5IAa/Db382R
IkmMh0FX0Yl9q7w6VOpAZLxaboMxGiFJUjRcNLnqOfjtsQofj4zAFlvBIA7/RwQnXVGayNhLGi3N
7XLfDP0i7p4gckj1b5MG2t5maVew7zX6B+6xA0cN/RI4cvkxCQ1F9asnkgESFqZapIJFL6aaaV0l
Qh3FaObRv8kv+Qo93wowfpFhvA3ucTx1dh02q452eSUUcKTZDz898u+rhIcI3Zy9Zm9etklMywEi
FGnuflaAL8HAqaNaNFPJN7+y8YsYG4dVuZP8owNCRw5IMLCNVafLVPFFAhgt1xGnW7K+9zBY7XUj
uHF0IgcVkoYRhaWbPevt2JwWaXuVXmmM56UuQkhrZkFjp+YIGuRk7B0UW7rvTOwpnaVEjosW7KLO
nngWliIdmltWh6x7Tuf1bkedDBF8Ete7qtGJh9v3pVtrFjHsOFI79gjuLARF0zZoyxLKrYffrdrh
++yeItcnkTrMM/P+rWE5WXC9kRmATSdn3dIRHmaRkW+ogZ54nb4nRuGDRM+Q/zIGQjaFhERfBCxf
SrZVpWPs0J/HTfxh1BZRDXQxbGGgSBM1bEx29YP7v0HmY5fKgkFYFauiG0Ecur7sdOFxnt1J4hkI
wng8mqFJ56v2S/1hubt/GQk4WNb16V9i1i+pTdIjqtb86s2K1JkwoLktmH7XqA/HtzWq8qhwykEV
Uy+elUYpEcMdKfUakpK38SkH5KaohWO/HkgRWxUGdag7WpdN+qjEjtcA1kCD1xDcAS4H+zZPBqcO
biEW/pEOYsXrPHL+TQjKsvOqMQ+qMKTZoCmLg51nISi1ztvimA8goHF438hUc+iRbEtZjLfOci7h
GgBodKgDMLtpXMlkqBaQNiH0AczdGnHkmUyC81F2HQQd1ztS38xbyMlb4UQzwZ9fkJuAdWEMPKro
EYeH3Y6M3MEZujyCddYPyI6YwRYe0/ov0AADQIWF