<?php

namespace WHMCS\Module\Registrar\Ispapi;

use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\Contact as HXContact;
use WHMCS\Config\Setting as Setting;
use Illuminate\Database\Capsule\Manager as DB;

class Domain
{
    /**
     * check if we resigned the dk domain
     * @param array $params common module parameters
     * @param string $domain domain name
     * @return bool
     */
    public static function isResigned($params, $domain)
    {
        if ($params["tld"] !== "dk") {
            return false;
        }
        $r = Ispapi::call([
            "COMMAND" => "QueryObjectLogList",
            "OBJECTCLASS" => "DOMAIN",
            "OBJECTID" => $domain,
            "ORDERBY" => "LOGDATEDESC",
            "USERDEPTH" => "SELF",
            "LIMIT" => 1
        ], $params);
        return (
            $r["CODE"] === "200"
            && $r["PROPERTY"]["OPERATIONTYPE"][0] === "RENEW"
            && $r["PROPERTY"]["OPERATIONSTATUS"][0] === "FAILED"
        );
    }
    /**
     * get domain name variants (idn, punycode)
     * @param array $params common module parameters
     * @param string $domain domain name
     * @return array
     */
    public static function convert($params, $domain)
    {
        $domain = strtolower($domain);
        if (!(bool)preg_match("/^[a-z0-9\.\-]+$/i", $domain)) {
            $r = Ispapi::call([
                "COMMAND" => "ConvertIDN",
                "DOMAIN0" => $domain
            ], $params);
            if ($r["CODE"] === "200" && !empty($r["PROPERTY"]["ACE"][0])) {
                return [
                    "idn" => strtolower($r["PROPERTY"]["IDN"][0]),
                    "punycode" => strtolower($r["PROPERTY"]["ACE"][0])
                ];
            }
        }
        return [
            "idn" => $domain,
            "punycode" => $domain
        ];
    }
    /**
     * get domain status
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param bool $hosttypeattr return hosts as attributes (not as objects)
     * @return array
     */
    public static function getStatus($params, $domain, $hosttypeattr = false)
    {
        $cmd = [
            "COMMAND" => "StatusDomain",
            "DOMAIN" => $domain
        ];
        if ($hosttypeattr) {
            $cmd["HOSTTYPE"] = "ATTRIBUTE";
        }
        $r = Ispapi::call($cmd, $params);
        if ($r["CODE"] !== "200") {
            return [
                "success" => false,
                "error" => "Loading domain status failed. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        return [
            "success" => true,
            "data" => $r["PROPERTY"]
        ];
    }

    /**
     * get idn language for a given domain name (please check if this domain is an IDN first! Hint: Quota)
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getIDNLanguage($params, $domain)
    {
        $cmd = [
            "COMMAND" => "CheckIDNLanguage",
            "DOMAIN" => $domain
        ];
        $r = Ispapi::call($cmd, $params);
        if ($r["CODE"] !== "200" || !isset($r["PROPERTY"]["LANGUAGE"][0])) {
            return [
                "success" => false,
                "error" => "Impossible to detect IDN Language. (" . $r["CODE"] . " " . $r["DESCRIPTION"] . ")",
                "errorcode" => $r["CODE"]
            ];
        }
        return [
            "success" => true,
            "language" => strtolower($r["PROPERTY"]["LANGUAGE"][0])
        ];
    }

    /**
     * Return WHMCS Status Data of an expired domain name
     * (StatusDomain returns 545 and no outbound transfer in Object Log)
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param array $r optional API response, just in case we have it already,
     * @param bool $isSync optional Flag toggle Sync Debug output
     * @param int $sub #seconds to substract from calculated expirydate (0d = 0 by default); whmcs just deals with date portion
     * @return array
     */
    public static function getExpiredStatus($params, $domain, $r = null, $isSync = true, $sub = 0)
    {
        if (is_null($r)) {
            $r = Ispapi::call([
                "COMMAND" => "QueryObjectList",
                "OBJECTCLASS" => "DELETEDDOMAIN",
                "OBJECTID" => $domain
            ], $params);
        }
        if ($r["CODE"] === "545") {
            if ($isSync) {
                logActivity($domain . ": Domain Sync finished. Status updated to `Transferred Away`");
            }
            return [
                "transferredAway" => true
            ];
        }
        if ($r["CODE"] === "200" && $r["PROPERTY"]["COUNT"][0] > 0) {
            $expirationdate = Ispapi::castDate($r["PROPERTY"]["EXPIRATIONDATE"][0]);
            $ts = $expirationdate["ts"] - $sub;
            $values = [
                "expirydate" => date("Y-m-d", $ts),
                "expired" => strtotime("now") > $ts
            ];
            if ($isSync) {
                logActivity($domain . ": Domain Sync finished. Updated expirydate: " . $values["expirydate"]);
            }
            return $values;
        }
        if ($r["CODE"] === "200" && $r["PROPERTY"]["COUNT"][0] === "0") {
            // deleted, not restorable
            if ($isSync) {
                logActivity($domain . ": Domain Sync finished. Status updated to `Expired` (not restorable).");
            }
            // load expirydate we have in DB or fallback to some old date
            $expirydate = DB::table("tbldomains")
                ->where("id", $params["domainid"])
                ->value("expirydate");
            if (is_null($expirydate)) {
                $expirydate = date("Y-m-d", strtotime("-1 year", time()));
            }
            return [
                "expired" => true,// just returning expired wouldn't change anything
                "expirydate" => $expirydate
            ];
        }
        if ($isSync) {
            logActivity($domain . ": Domain Sync finished. Status Detection failed - probably a temporary issue.");
        }
        return []; // whmcs should show a curl error
    }
    /**
     * Returns WHMCS Status Data for a given Domain
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param string $isExpiredDomain optional flag identifying if this domain is already expired or not
     * @param array $r optional API response, just in case we have it already (StatusDomain for $isExpiredDomain=false or QueryObjectList for $isExpiredDomain=true)
     * @param array $needsCarbon optional flag, if Carbon instance is required (GetDomainInformation). false by default.
     * @param int $sub #seconds to substract from calculated expirydate (0d = 0 by default); whmcs just deals with date portion
     * @return array
     */
    public static function getExpiryData($params, $domain, $isExpiredDomain = false, $r = null, $needsCarbon = false, $sub = 0)
    {
        if ($isExpiredDomain) {
            return self::getExpiredStatus($params, $domain, $r);
        }
        if (is_null($r)) {
            $r = self::getStatus($params, $domain);
        }
        if (!$r["success"]) {
            return [];
        }
        $r = $r["data"];

        // cast our UTC API timestamp format to useful formats in local timezone
        $expirationdate = Ispapi::castDate($r["EXPIRATIONDATE"][0]);//XIRCA
        if (preg_match("/\.dk$/i", $domain)) {
            $regexpirationdate = Ispapi::castDate($r["REGISTRATIONEXPIRATIONDATE"][0]);//Service Domains
            if ($regexpirationdate["ts"] > $expirationdate["ts"]) {
                // xirca and service domains out of sync
                // service domains with a later expiration date
                // (might happen when domain is renewed at dkh)
                $expirationdate = $regexpirationdate;
            }
        }
        $finalizationdate = Ispapi::castDate($r["FINALIZATIONDATE"][0]);
        $paiduntildate = Ispapi::castDate($r["PAIDUNTILDATE"][0]);
        $failuredate = Ispapi::castDate($r["FAILUREDATE"][0]);

        //Example of using Carbon
        //$expirydate = \WHMCS\Carbon::createFromFormat("Y-m-d H:i:s", $expirydate["long"])->subDays(1);
        //$values["expirydate"] = $expirydate->toDateString();//YYYY-MM-DD
        //$values["expired"] = $expirydate->isPast();
        $format = "Y-m-d H:i:s";
        if ($failuredate["ts"] > $paiduntildate["ts"]) {
            $expirydate = Ispapi::castDate($r["FAILUREDATE"][0]);
            $ts = $paiduntildate["ts"] - $sub;
            $values = [
                "expirydate" => date("Y-m-d", $ts),
                "expired" => strtotime("now") > $ts,
                "active" => (bool)preg_match("/ACTIVE/i", $r["STATUS"][0])
            ];
            if ($needsCarbon) {
                $values["expirydate"] = \WHMCS\Carbon::createFromFormat($format, date($format, $ts));
            }
            return $values;
        }
        // https://github.com/hexonet/whmcs-ispapi-registrar/issues/82
        $ts = $finalizationdate["ts"] + ($paiduntildate["ts"] - $expirationdate["ts"]) - $sub;
        $values = [
            "expirydate" => date("Y-m-d", $ts),
            "expired" => strtotime("now") > $ts,
            "active" => (bool)preg_match("/ACTIVE/i", $r["STATUS"][0])
        ];
        if ($needsCarbon) {
            $values["expirydate"] = \WHMCS\Carbon::createFromFormat($format, date($format, $ts));
        }
        return $values;
    }
    /**
     * get nameservers of transfer request
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getNameservers($params, $domain)
    {
        $r = self::getStatus($params, $domain);
        if (!$r["success"]) {
            return $r;
        }
        return [
            "success" => true,
            "nameservers" => $r["data"]["NAMESERVER"]
        ];
    }
    /**
     * Checks if a contact update is considered for the given domain name
     * Applies to .com / .net / .cc / .tv domain names with "broken" contact data
     * where we were not able to parse contact details out of whois data after transfer
     * because of active WHOIS / id protection service.
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param array $r (optional) Domain::getStatus response
     * @return bool
     */
    public static function needsContactUpdate($params, $domain, $r = null)
    {
        if (
            $params["CHUpdTransfer"] !== "on"
            || !preg_match("/\.(com|net|cc|tv)$/", $domain)
        ) {
            return false;
        }
        if (is_null($r)) {
            $r = self::getStatus($params, $domain);
        }
        if (!$r["success"]) {
            return false;
        }
        $map = [
            "OWNERCONTACT",
            "ADMINCONTACT",
            "TECHCONTACT",
            "BILLINGCONTACT"
        ];
        foreach ($map as $ctype) {
            if (
                empty($r["data"][$ctype][0])
                || preg_match("/^AUTO-.+$/", $r["data"][$ctype][0])
            ) {
                return true;
            }
        }
        return false;
    }
    /**
     * Returns registrant and admin data related to the given domain
     * based on your settings in WHMCS.
     * @param int $domainid WHMCS domain id
     * @return array
     */
    public static function getContactDetailsWHMCS($domainid)
    {
        if (!function_exists("convertStateToCode") || !function_exists("getClientsDetails")) {
            require implode(DIRECTORY_SEPARATOR, [ROOTDIR, "includes", "clientfunctions.php"]);
            // TODO, ROOTDIR might not be working in Sync / TransferSync
        }
        // --- fetch client details of current domain
        $d = new \WHMCS\Domains();
        $domain_data = $d->getDomainsDatabyID($domainid);
        $p = getClientsDetails($domain_data["userid"]);
        $cmdparams = [
            "FIRSTNAME" => html_entity_decode($p["firstname"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "LASTNAME" => html_entity_decode($p["lastname"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "ORGANIZATION" => html_entity_decode($p["companyname"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "STREET" => html_entity_decode($p["address1"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "CITY" => html_entity_decode($p["city"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "STATE" => html_entity_decode($p["state"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "ZIP" => html_entity_decode($p["postcode"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "COUNTRY" => html_entity_decode($p["country"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "PHONE" => html_entity_decode($p["phonenumber"], ENT_QUOTES | ENT_XML1, "UTF-8"),
            "EMAIL" => html_entity_decode($p["email"], ENT_QUOTES | ENT_XML1, "UTF-8")
            //"FAX" => n/a in whmcs
        ];
        if (strlen($p["address2"])) {
            $cmdparams["STREET"] .= " , " . html_entity_decode($p["address2"], ENT_QUOTES | ENT_XML1, "UTF-8");
        }

        // --- fetch WHMCS' admin contact data
        $admindata = false;
        if (Setting::getValue("RegistrarAdminUseClientDetails") === "on") {
            $admindata = $cmdparams;
        } else {
            $admindata = [
                "FIRSTNAME" => html_entity_decode(Setting::getValue("RegistrarAdminFirstName"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "LASTNAME" => html_entity_decode(Setting::getValue("RegistrarAdminLastName"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "ORGANIZATION" => html_entity_decode(Setting::getValue("RegistrarAdminCompanyName"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "STREET" => html_entity_decode(Setting::getValue("RegistrarAdminAddress1"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "CITY" => html_entity_decode(Setting::getValue("RegistrarAdminCity"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "STATE" => html_entity_decode(convertStateToCode(
                    Setting::getValue("RegistrarAdminStateProvince"),
                    Setting::getValue("RegistrarAdminCountry")
                ), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "ZIP" => html_entity_decode(Setting::getValue("RegistrarAdminPostalCode"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "COUNTRY" => html_entity_decode(Setting::getValue("RegistrarAdminCountry"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "PHONE" => html_entity_decode(Setting::getValue("RegistrarAdminPhone"), ENT_QUOTES | ENT_XML1, "UTF-8"),
                "EMAIL" => html_entity_decode(Setting::getValue("RegistrarAdminEmailAddress"), ENT_QUOTES | ENT_XML1, "UTF-8")
                //"FAX" => n/a in whmcs
            ];
            $street2 = Setting::getValue("RegistrarAdminAddress2");
            if (strlen($street2)) {
                $admindata["STREET"] .= " , " . html_entity_decode($street2, ENT_QUOTES | ENT_XML1, "UTF-8");
            }
        }
        return [
            "registrant" => $cmdparams,
            "admin" => $admindata
        ];
    }
    /**
     * Request contact update
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param array $data data container
     * @param array $r Domain::getStatus response
     * @param null|bool
     */
    public static function updateContactDetails($params, $domain, $data, $r)
    {
        $command = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain
        ];
        $contacts = [];
        $map = [
            "OWNERCONTACT" => "registrant"
        ];
        // --- also auto-add admin/tech/billing-c in case whmcs admin data is present
        if ($data["admin"]) {
            $map["ADMINCONTACT"] = "admin";
            $map["TECHCONTACT"] = "admin";
            $map["BILLINGCONTACT"] = "admin";
        }
        // --- check if current registrant data is invalid/broken as of active ID Protection
        // --- and thus parsing data out of whois failed in transfer process
        foreach ($map as $apikey => $datakey) {
            if (empty($r["data"][$apikey][0])) {
                $command[$apikey . "0"] = $data[$datakey];
            } else {
                $contactid = $r["data"][$apikey][0];
                if (preg_match("/^AUTO-.+$/", $contactid)) {
                    if (!isset($contacts[$contactid])) {
                        $contacts[$contactid] = HXContact::getStatus($params, $contactid);
                    }
                    $rc = $contacts[$contactid];
                    if ($rc["success"] && empty($rc["data"]["EMAIL"][0])) {
                        $command[$apikey . "0"] = $data[$datakey];
                    }
                }
            }
        }
        //check if domain update is necessary, #parameters > COMMAND, DOMAIN
        if (count(array_keys($command)) > 2) {
            $r = Ispapi::call($command, $params);
            return [
                "success" => ($r["CODE"] === "200")
            ];
        }
        // no update necessary
        return null;
    }
    /**
     * Get the domain's assigned auth code.
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getAuthCode($params, $domain)
    {
        // Expiring Authorization Codes
        // https://confluence.centralnic.com/display/RSR/Expiring+Authcodes
        if (preg_match("/\.(eu|be)$/i", $domain)) {
            $response = Ispapi::call([
                "COMMAND" => "RequestDomainAuthInfo",
                "DOMAIN" => $domain
            ], $params);
            // TODO -> PENDING = 1|0
        } else {
            // default case for all other tlds
            $response = Ispapi::call([
               "COMMAND" => "StatusDomain",
               "DOMAIN" => $domain
            ], $params);
            if (preg_match("/\.(fi|nz|de)$/i", $domain)) {
                if ($response["CODE"] === "200" && $response["PROPERTY"]["TRANSFERLOCK"][0] === "1") {
                    return [
                        "error" => "Failed loading the epp code. Please unlock this domain name first to get a new epp code set by the registry provider. Access it later on here."
                    ];
                }
            }
        }

        // check response
        if ($response["CODE"] === "200") {
            if (!isset($response["PROPERTY"]["AUTH"][0])) {
                return []; // send to registrant by email
            }
            if (!strlen($response["PROPERTY"]["AUTH"][0])) {
                return [
                    "error" => "Failed loading the epp code (No authcode assigned to this domain name. Contact Support)."
                ];
            }
            //htmlspecialchars -> fixed in (#5070 @ 6.2.0 GA) / (#4166 @ 5.3.0)
            return [
                "eppcode" => $response["PROPERTY"]["AUTH"][0]
            ];
        }
        return [
            "error" => "Failed loading the epp code (" . $response["DESCRIPTION"] . ")."
        ];
    }
    /**
     * Get current Lock Status of the given domain.
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function getRegistrarLock($params, $domain)
    {
        // not using VERSION = 2 is incredible faster
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainList",
            "UNIQUE" => 1,
            "DOMAIN" => $domain,
            "OBJECTCLASS" => "DOMAIN",
            "WIDE" => 1
        ], $params);

        // NOTE: returning an error still shows up as "unlocked"
        // Removing the menu entry by hook therefore ftw.
        if ($r["CODE"] !== "200") {
            return [
                "error" => $r["DESCRIPTION"]
            ];
        }
        $r = $r["PROPERTY"];
        // list command always returns 200, but maybe no data
        if (!isset($r["DOMAINTRANSFERLOCK"])) {
            return [
                "error" => "Domain Name not found."
            ];
        }
        // return locking status
        if ($r["DOMAINTRANSFERLOCK"][0] === "1") {
            return "locked";
        }
        if ($r["DOMAINTRANSFERLOCK"][0] === "0") {
            return "unlocked";
        }
        // empty string
        return [
            "error" => "Registrar Lock unsupported for this TLD."
        ];
    }
    /**
     * Lock or Unlock the domain as requested.
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function saveRegistrarLock($params, $domain)
    {
        $doLock = ($params["lockenabled"] === "locked");

        $cmd = [
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "TRANSFERLOCK" => $doLock ? "1" : "0"
        ];
        //Expiring Authcodes
        //https://confluence.centralnic.com/display/RSR/Expiring+Authcodes
        if (!$doLock) {
            $zi = self::getZoneInformation($params, $domain);
            if (!is_null($zi) && $zi->update->unlockWithAuthCode) {
                $cmd["AUTH"] = self::generateEPPCode();
            }
        }
        $response = Ispapi::call($cmd, $params);

        if ($response["CODE"] !== "200") {
            return [
                "error" => $domain . ": Unable to " . ($doLock ? "set" : "remove")  . " registrar lock. [" . $response["DESCRIPTION"] . "]"
            ];
        }
        return [
            "success" => $domain . ": Successfully " . ($doLock ? "set" : "removed")  . " registrar lock."
        ];
    }
    /**
     * Function to toggle Id Protection Service
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @param bool $idprotection id protection status in WHMCS
     * @return array
     */
    public static function saveIdProtection($params, $domain, $idprotection)
    {
        $r = Ispapi::call([
            "COMMAND" => "ModifyDomain",
            "DOMAIN" => $domain,
            "X-ACCEPT-WHOISTRUSTEE-TAC" => (int)$idprotection
        ], $params);
        if ($r["CODE"] !== "200") {
            return [
                "error" => $domain . ": Unable to " . ($idprotection ? "activate" : "deactivate")  . " id protection. [" . $response["DESCRIPTION"] . "]"
            ];
        }
        return [
            "success" => $domain . ": Successfully " . ($doLock ? "activated" : "deactivated")  . " id protection."
        ];
    }
    /**
     * Restore given Domain Name
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function restore($params, $domain)
    {
        $response = Ispapi::call([
            "COMMAND" => "RestoreDomain",
            "DOMAIN" => $domain
        ], $params);
        if ($response["CODE"] !== "200") {
            return [
                "error" => "Domain Restore failed. (" . $response["CODE"] . " " . $response["DESCRIPTION"] . ")"
            ];
        }

        $msg = "Domain Restore succeeded. ";
        // compare WHMCS' regperiod with the default restore period
        $zi = self::getZoneInformation($params, $domain);
        // unable to fetch list of supported renewal periods
        if (
            is_null($zi)
            || empty($zi->renewal->periods)
        ) {
            return [
                "success" => true,
                "message" => $msg . "Not able to check for matching renewal period."
            ];
        }

        // compare periods
        $perioddiff = (int)$params["regperiod"] - $zi->renewal->defaultPeriod;
        // no difference - should apply to the most cases
        if ($perioddiff === 0) {
            return [
                "success" => true,
                "message" => $msg
            ];
        }
        // difference detected. check if that diff period is supported as renewal period
        if (!in_array($perioddiff, $zi->renewal->periods)) {
            return [
                "success" => true,
                "message" => $msg . "Not able to check for matching renewal period."
            ];
        }

        return [
            "success" => true,
            "message" => $msg . "Requires additional Renewal to fit Renewal Period provided.",
            "periodLeft" => $perioddiff
        ];
    }
    /**
     * Renew given Domain Name
     *
     * @param array $params common module parameters
     * @param string $domain puny code domain name
     * @return array
     */
    public static function renew($params, $domain)
    {
        // --- Domain Renewal
        $command = [
            "COMMAND" => "RenewDomain",
            "DOMAIN" => $domain,
            "PERIOD" => $params["regperiod"]
        ];
        // renew premium domain
        $premiumDomainsEnabled = (bool) $params["premiumEnabled"];
        //check if premium domain functionality is enabled and
        //check if the domain has a premium price
        if ($premiumDomainsEnabled && isset($params["premiumCost"])) {
            // QueryDomainList with Properties = PRICE not useful as it is
            // based on account currency which probably differs to the one
            // of the registry provider which is kept with WHMCS
            // still for reference as faster lookup method
            $sr = Ispapi::call([
                "COMMAND" => "QueryDomainList",
                "DOMAIN" => $domain,
                "WIDE" => 1
                //    "PROPERTIES" => "PRICE" (will be in account curency)
            ], $params);

            if (
                $sr["CODE"] === "200"
                //check if the underlying domain name is a premium one on API-end
                && !empty($sr["PROPERTY"]["DOMAINSUBCLASS"][0])
                && (bool) preg_match("/^PREMIUM_/", $sr["PROPERTY"]["DOMAINSUBCLASS"][0])
            ) {
                // sadly, WHMCS is NOT providing the premiumCurrency ...
                $params["isAftermarketCase"] = false;
                $pr = ispapi_GetPremiumPrice($params);
                //check if WHMCS' price fits to the API one
                if ($params["premiumCost"] === $pr["renew"]) {
                    $command["CLASS"] = $sr["PROPERTY"]["DOMAINSUBCLASS"][0];
                }
            }
        }
        $response = Ispapi::call($command, $params);

        // required explit renewal in our system
        if ($response["CODE"] === "510") {
            $command["COMMAND"] = "PayDomainRenewal";
            $response = Ispapi::call($command, $params);
        }

        if ($response["CODE"] !== "200") {
            return [
                "error" => "Renewal failed. (" . $response["CODE"] . " " . $response["DESCRIPTION"] . ")"
            ];
        }

        return [
            "success" => true,
            "message" => "Renewal succeeded."
        ];
    }

    /**
     * Flush Zone Configuration for given TLD
     * @param array $params common module parameters
     * @param string $domain domain name
     */
    public static function flushZoneInformation($params, $domain)
    {
        $datakey = self::getZoneInformationKey($params, $domain);
        $td = \WHMCS\TransientData::getInstance();
        if ($td->retrieve($datakey)) {
            $td->delete($datakey);
        }
    }

    /**
     * Get Zone Configuration Data for a single domain name
     * @param array $params common module parameters
     * @param string $domain domain name
     * @return object|null
     */
    public static function getZoneInformation($params, $domain)
    {
        list($dn, $tld) = explode(".", $domain, 2);
        $tld = "." . $tld;
        $data = self::getZoneInformations($params, [$domain]);
        return $data[$tld] ?? null;
    }

    /**
     * Get Zone Configuration Data for a list of domain names
     * @param array $params common module parameters
     * @param array $domains domain names
     * @return array
     */
    public static function getZoneInformations($params, $domains)
    {
        $data = [];
        $missing = [];
        $td = \WHMCS\TransientData::getInstance();

        foreach ($domains as $domain) {
            list($dn, $tld) = explode(".", $domain, 2);
            $tld = "." . $tld;
            $datakey = self::getZoneInformationKey($params, $domain);
            $d = $td->retrieve($datakey);
            if ($d) {
                $data[$tld] = json_decode($d);
                // WHMCS expects this part as array
                $data[$tld]->trade->triggerFields = json_decode(json_encode($data[$tld]->trade->triggerFields), true);
            } else {
                $data[$tld] = null;
                $missing[] = $domain;
            }
        }

        if (!empty($missing)) {
            $missing = self::requestZoneInformation($params, $missing, $data);
            if (!empty($missing)) { // retry for idns
                self::requestZoneInformation($params, $missing, $data);
            }
        }
        return $data;
    }

    private static function getZoneInformationKey($params, $domain)
    {
        list($dn, $tld) = explode(".", $domain, 2);
        return (
            "ispapiZoneInfo" .
            (($params["TestMode"] === "on") ? "Ote" : "Live") .
            strtoupper(str_replace(".", "", $tld))
        );
    }

    /**
     * Request Zone Configuration Data for a list of domain names
     * @param array $params common module parameters
     * @param array $domains domain names
     * @param string $datakeybase the base key to use for data retrival
     * @param array $data data container (by ref)
     * @return array
     */
    private static function requestZoneInformation($params, $domains, &$data)
    {
        $missing = [];
        // all configs available
        if (empty($domains)) {
            return $missing;
        }

        // api call fails
        $r = Ispapi::call([
            "COMMAND" => "QueryDomainOptions",
            "DOMAIN" => $domains
        ], $params);
        if ($r["CODE"] !== "200") {
            return $missing;
        }
        // add new configs to store
        $r = $r["PROPERTY"];
        // null === unsupported

        $td = \WHMCS\TransientData::getInstance();
        foreach ($domains as $idx => $domain) {
            list($dn, $tld) = explode(".", $domain, 2);
            $tld = "." . $tld;
            $registrationPeriods = self::formatPeriods($r["ZONEREGISTRATIONPERIODS"][$idx]);
            // logActivity("$tld: " . json_encode($registrationPeriods));
            if (empty($registrationPeriods)) {
                if (!preg_match("/^\.[.a-z]+$/", $tld)) {// for idn's
                    $missing[] = substr($tld, 1) . $tld;
                }
                // echo $tld . "\n";
                continue;
            }
            $zone = strtoupper(str_replace(".", "", $tld));
            $datakey = self::getZoneInformationKey($params, $domain);
            $transferPeriods = explode(",", $r["ZONETRANSFERPERIODS"][$idx]);
            $transferResetPeriods = self::formatPeriods(join(",", preg_grep( // filter for periods resetting expiration date
                "/^R[0-9]+Y$/",
                $transferPeriods
            )));
            $transferPeriods = self::formatPeriods($r["ZONETRANSFERPERIODS"][$idx]); // might be just 0Y
            $renewalPeriods = self::formatPeriods($r["ZONERENEWALPERIODS"][$idx]);

            $isAfnicTLD = (bool)preg_match("/^AFNIC-/i", $r["REPOSITORY"][$idx]);
            $contactsForTransfer = [];
            if ($isAfnicTLD) {
                $contactsForTransfer = [ "ADMINCONTACT", "TECHCONTACT" ];
            } elseif (
                (bool)preg_match("/\.(au|ro)$/i", $tld)
                || (
                    $r["ZONEPOLICYREGISTRANTNAMECHANGEBY"][$idx] === "UPDATE"
                    && !(bool)preg_match("/\.(ca|us)$/i", $tld)
                )
            ) {
                // REF -> ZONEPOLICYREGISTRANTNAMECHANGEBY = enum('UPDATE', 'TRADE', 'REGISTRY', 'NEWREG', 'ICANN-TRADE')
                $contactsForTransfer = [ "OWNERCONTACT", "ADMINCONTACT", "TECHCONTACT", "BILLINGCONTACT" ];
            }

            $json = json_encode([
                "tld" => [
                    "label" => $tld,
                    "class" => $zone,
                    "isAFNIC" => $isAfnicTLD,
                    "repository" => $r["REPOSITORY"][$idx]
                ],
                "registration" => [
                    "periods" => $registrationPeriods,
                    "defaultPeriod" => $registrationPeriods[0]
                ],
                "renewal" => [
                    "periods" => $renewalPeriods,
                    "defaultPeriod" => $renewalPeriods[0],
                    "explicit" => ($r["REGISTRYEXPLICITRENEWAL"][$idx] === "YES"),
                    "graceDays" => 0 // null is probably falling back to the default of whmcs
                ],
                "redemption" => [
                    "days" => ($r["ZONEDELETIONRESTORABLEPERIOD"][$idx] === "") ? null : (int)$r["ZONEDELETIONRESTORABLEPERIOD"][$idx]
                ],
                "transfer" => [
                    "periods" => $transferPeriods,
                    "resetPeriods" => $transferResetPeriods,
                    "defaultPeriod" => $transferPeriods[0],// evtl. 0Y
                    "isFree" => in_array("0Y", $transferPeriods), // TODO <------------
                    "includeContacts" => !empty($contactsForTransfer),
                    "contacts" => $contactsForTransfer,
                    "requiresAuthCode" => ($r["REGISTRYTRANSFERREQUIREAUTHCODE"][$idx] === "YES")
                ],
                "trade" => [
                    "required" => (bool)preg_match("/TRADE/", $r["ZONEPOLICYREGISTRANTNAMECHANGEBY"][$idx]),
                    "isStandard" => $r["ZONEPOLICYREGISTRANTNAMECHANGEBY"][$idx] === "TRADE",
                    "isIRTP" => $r["ZONEPOLICYREGISTRANTNAMECHANGEBY"][$idx] === "ICANN-TRADE",
                    "triggerFields" => [ "Registrant" => [ "First Name", "Last Name", "Organization Name", "Email" ]]
                ],
                "update" => [
                    "unlockWithAuthCode" => (bool)preg_match("/\.fi$/i", $tld),
                ],
                "addons" => [
                    "idprotection" => in_array("WHOISTRUSTEE", explode(" ", $r["X-PROXY"][$idx]))
                ],
                "registrant" => [
                    "changeBy" => $r["ZONEPOLICYREGISTRANTNAMECHANGEBY"][$idx]
                ]
            ]);
            $td->store($datakey, $json, 86400); // 24h
            $data[$tld] = json_decode($json);
            // WHMCS expects this part as array
            $data[$tld]->trade->triggerFields = json_decode(json_encode($data[$tld]->trade->triggerFields), true);
        }
        return $missing;
    }

    /**
     * Format Period String into useable format and filter out values unsupported by WHMCS
     * Reset Periods will also get nicely parsed into integers (e.g. R1Y)
     * @param string $periodStr Period String e.g. "1Y,2Y,3Y,4Y"
     * @return array
     */
    private static function formatPeriods($periodStr)
    {
        return array_values(array_unique( // unique values, re-indexed
            array_map( // convert strings to ints
                "intval",
                preg_grep( // filter out 1M period, not supported by whmcs at all;  and empty string which is probably a no longer supported zone
                    "/^(1M)?$/",
                    preg_replace(
                        "/^R/", // replace "R" of reset periods
                        "",
                        explode(",", $periodStr)
                    ),
                    PREG_GREP_INVERT
                )
            )
        ));
    }

    /**
     * Generate a random auth code
     * @return string
     */
    private static function generateEPPCode()
    {
        $numbers = "0123456789";
        $small_letters = "abcdefghijklmnopqrstuvwxyz";
        $capital_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $special_chars = "@#$*[]{}=+";
        $final_auth = substr(str_shuffle($numbers), 0, 3);
        $final_auth .= substr(str_shuffle($small_letters), 0, 3);
        $final_auth .= substr(str_shuffle($capital_letters), 0, 3);
        $final_auth .= substr(str_shuffle($special_chars), 0, 2);
        return str_shuffle($final_auth);
    }
}
