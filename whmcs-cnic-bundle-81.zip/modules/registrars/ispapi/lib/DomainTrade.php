<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnWd4vz3kkVG6kY6l4x8XuFx0NLYTmy+ifQuBN4ecUq9MF7nc1Jrbv1jNBjWG/u/aUSnhh3S
Yq3w4v2qbOnlK+tC79Ji5RBeQfjKRiMhuBKlMengd/64p4x5AWtTugEgLBIplfGayUTeqtPgcil/
w21FPBpmMFDdFo3zDYxe10qRe5knyyxvddFu8DHRXTuYSGaayyq1sZqd5/I5K/UTLzIA07/koMz/
002q/3OmUE1f/iJSauRgUyQ3Q4+Xpt26lm02JpBNp7oroBaE/VGDitMnBtnm7Hkc9IOIabWY8cVM
ScTxa7hLC8ckCYKLaQRHIuk7P5E9Q7BfLSSF5fHCyjTiFrTww+kXQmtxe2slZsdkx8i8hF1707Wl
m9qmGxc1kuQ93OOitD/tUaYy53XKNq0ZD15GUt0UM6QJEtQJJBR7j2jWETNQckqWzyHDA2Qn+MBN
jb9+LE/KjqJK6619kHyGYtXXTEyS3XMxLzICycWUjlnDR9kUOqSqYwy5E6ICz29A84777+GJuwjQ
W+FfKzRXAoLZ9QpRmjWup5foaySW83yiACI21DlYsTZ2t5eZqMlTviXSjcGLjcTB8epphOCU8YOB
eO9Q/qBKQDVYFkTsUurLY86orGAVoHc4VNj43t9JVxennSLYld3/nYo97XP/pU1zOXftmDma4qSt
mCqIaxx2vf3slPPtbIHUHWeYFXHth1fh2y7+I0l93S6sjN8VY21AfX6QhBlcOl7hZnrzuK9E/K1T
1Zv1KE9Gde9I7lZ6p/4IY7A8vxMWsZRxnVN/3T9Q0Cb1e1C9ODjAnvU8u0lY4L4OQkyp0TDzezA8
Bi32BOMUXEygWJvNXhJDQkVKTksnLJtszAauv43U4KC56O1kui/QjOGDcSEgWZjKfFMuOvE2Ud+z
KvxC17JELqfBwpDpSFpzM3u0oE+g3L0/88NRPPfmPWFBXJ6lvd/7w5eZDlXHUikKl1D1byBa/lfq
Ah8d0MegctvlEa4IJmPtLc73gV8H32gVXCbUuWUcek4Kg9vdP7cbvwJcnt5gkOpGWn09FLPfRp7l
uEyoO2TQxCmQHQO0urCaM8sAevhUAv8Hte5jCUM0NRh+D2Ar74NaZguJmK/WB9ajlLKaWCp559LM
NzZNqhRqYhAR7hU7OFiGK8sguqwrNs/LGIRVKukNO7KmzstNperN3vcX2KvSNoF9dKWI1g8OitBw
4Dl6EC0WNlELBU9gyNO8059RlQRIie0FXNSSuqMWxUdxyz513bwuvjIdY61dlJRJwq9lk0BVyOl8
1Yf3N7NvOVVNCUftIvcqDOq6/YgTYGVWi8JcYHHcBXaAAwyL10veI+gctd9F/pzQFJ/5i+0AWqi7
vKX/MWGfXbXWDUeaa71QTEZ+yo2GlVGmPSl1lVK8EZcWg8N4DfySCLrFflvnyz2pfDlsmp9bLCAw
7cF6TOv2h4Yh6iv/xE2c5QhqlV3k9bJROqAN1WWF01q+73D1qrgJ+AjbNYy84zNeCe91efL2p+LV
PzkeBhmH18ZyEzHnkj4vfdD2j/QyB1l2jgHBdf68y3FY4wkBARNfUExv4lz58nCCuzxmwT1grfbl
cdh0zKjcMxKi6S1iof7WULMlN2pSJ7oEJ06ZuC5uG/9dmMq+Thmjr5mG50aGv0mX3+7uoDNgTtpl
wjLEjAqXiP4R6M3dv+57I6vOkaydSIu++RDPW8KxC1bZUAGSXcCSuQR58dmHfOHEWDaEMMN0DJwP
GwMRl9GPmrT8wKE80JJdCNjOo8r3NGIgXJVhTgrDzph92l3AvETeN7nd/zyWsWtvZuwiQQRPvnQe
AXNTbP7pW7GJn/xV3zDrmhoSuwrYsxR8s0yfi0xBGEmp5oWRbCFOnMH/toD785CQEV8FJfinuHeo
eaArXvXR1o3zl3sRXDf7xOD+AaBCr0/m9HHXAyVvsdoS85XYVPZffzUvSdPXC2DVZdxvoIq5Dko0
VR1o26UqNHMxJyV0Y3s8KG72IVPf4/OvJDilYUusuyuoapRk2j+eENoVLOkOhyMKJVx+uPmsXKpg
nWPOrRkhe8/PWSXRNWBQZISguvP36Wo2IbGZl9ocpVpPJ9XzEjUU/04MoSYogVKM/pjhRMnRu1EB
rhXzn/pae20c0KQTRlf6iBFFuj+vmJezFgFnmu9oUrD3elqAI+fAZxeg9n1ViEo/xSi+oGjM38K2
2h5QN8BlUiy1tKOxhutGmSxoLD0em+nwpqPHz5d0SQaFJB59JdVdTeFu3m8c3xQuccRrUfz6i3FU
J/1aoaKcTHnH3BTBI88szIp3rzRYgUfl6Wzgz+8vyPdw/CO+G6ekhJ/h6ogze/fmU/Q/Meb7zBu8
KS6o9tFYxz2s4hdbY2iT8eD+m8tS9lzrZH8mGPy4FYszOTHpth5HWeo+yAoN0yClhU2UQ4SbQkeZ
iWXcBjT5vblbN1/tE0hMP7IfLitzvoZk/3PVhX/CG2dgxRn+mcU/cDHgpUSx9lHuYDZuznfUlF/J
iouXWpBAXV/TcDZ4F/N5A//CjyJOj6rUtOuFcimV2Sg/6xQE8DkDFJ1namAc6AdnCEKJ+SOvJpjF
pA6MGINxSPAOtEE9JRKsqV7dV3wWBTq0S8OI94ZE6TjzCqi9n6Vmn7jReMflXqO5eA1ZB3/SOT3W
LBaN2lnqOKfZovK1r4nutIB9n3z7WE0x9OaGPzjP/v0VcpQYyhPUjw1f1HETLylWwdWXU2pup6Zr
L6Hk/M/p8X8M9SgHdIqPjNQ5lg4vReB0AG9xoFz4+wsSL/BWowEv/aOoCzyEWphwxd3PqeutLxRh
2OW7VhWPi+7Blfxd3LES6dlPJc/ozPrkpbXQz/JQDXUMhRz5Qm52lSWEUA7ixzdyLNLFGF/MA7XH
9O4fT8QcxcfwOZ0jHx1i71JDMe98n39l4FTgyMBKjEXOMZJ3FylKfoy2hUB2QR5SswN2w9SvzspD
0NocH+tWwrFHg3quKuRIJg7SpAhZk/LjSV8C7A5WmG2QuDQL6us534wORyroQWTp3pSQtXcu1xbN
BOQgnhJ1qh8VxLQnAosR4fb7JfFDfSLS1J12/hO8wEC+XLpI/fwFi/+A67yJTOlBAjzP0K99nM04
R9DZ8dsKJaoEgs8kolRwUBqvzjWt5Vtte+kAFjjuDWJ0aoucaDfql13JZeKFqKw3ngTkHzoFj08J
N+zJ7MZ7XRQeh/ErN2JAv5RGueTG6Le3ZG4V4JZnGMczDvRsukX1uAVkT84qq3QWZfQBbnDpcgHX
TxG3nVlhf7x0DGUPCvjt3NFw+//2kjwIw/pmnID4b+wC7bEpifcN7sJyaNfzUQpjYvIRoieM/Z5M
OrbJhy6NT6Q70bUM1w7JqpbrOUekpdFOfPikUHB+bja1hcZzXQPAiOjDNhOfyBv14P4ZrhzeyvS+
IFzKCk6i/aMQYwrupB2k0fT2WjC0xx8OL7eDYCYVFc4BtJqE1kIBNjDu7P/DFfBKLuA76cY1LgYZ
ZEzXGKYGkDPrHBuQqWhSylGBuQxBW95EOZ735dFztpgsWX+GzGVR5eCLhLcAceXXQRdYuwB8VRj0
I+7CGCZBO8dx7qzzzeph2QuBVnrcveFbI9Y+CYd3aYI/e7M6XqPFD+Et5KiOnaGsD0t+fc8lTFDt
m1bQ72GM2Av4xNQiLoTjV/QOTvxYymwNfyztTEh4PnJ4n4jDkb1pkuoi1CRGsdudYWhECEtNMPPt
awTkmgE81lQ27kz5hG4pBdVwEIahtjw7xCfuWtWT7gCGBsNmN+4BucaTXlvs6SIaly7UhQL614hC
Bw4JlBV5EgtU