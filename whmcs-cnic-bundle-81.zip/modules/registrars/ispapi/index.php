<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzQoGmsCcBWYIGNMBb9aAuhAXsHouHJLZhguKWQqY8qU+/6qKaP7gAsUOByAfWoaY3EpFTCN
+/czuGIoYiW6M2bD0wcU4gchy3IL1YgJJSUjp4m4atYo6U3c4FsYSVj5Mjc4w2exHvRCivqjJcFE
rptJnevfcdIjEo0HCFp6fOR5aBtDmz+1DJbMTbYhejypgmOg7rOOuU/rwqnm7tOk8vAqqCw/KzRk
l28/qpChKoRLN7s648uIQr7oSzX3uq2UmEl39y9QBBwxwMaOXrnFuw+P3vbfhHddE9TUdY/xSKK6
rcKf//KChpyBtFZfoH+F6O5/f6C7/NYqU47UXO0OJMGjRN+n3/gB0yZZgbn42NAo+rI8QbF5dvdw
9iJFxczlfT5yx+4Zn2/0JDN3kdOdxxg/ALY0qzhjxZIiDjyO/BpA/Ib+GC8HPLZbpJC0Xuh5V4Kp
KNgM6CaYGJ89OdEZhybcVvOa/QUp7UvPp4NvAyZXXDMFGNmk+ap4t1pxB6QK2ZwDZMAl//o5PfLi
2s4QKJEL7qzpigZVVVHJqghMGzDks9pW9553WEGjK0gXazKkhxZf6u6cildGYk/Q9sSfoSKHcOQ8
dSUh2FrM1Li7IcA2ouFOLp2u/vrqqK+e1dvGl4+GD0bAWZ6gURUUgarzC7CMBs+/xg8JBLAWmo6K
oaosnlutOqhkySe0mU04iv26lNvkrXV6/GLQ+E9N/N0Vk2JD/G+oatf4SPnt49OOQSs9wNTKN2+E
mQnYK/vkInxp0RvWb8zfp7sQc6Um7XZBPRWM66WCYwGGIq1KHiq06coM6YU8SmS65LeOM3kcBW/U
B5496PQVW5jGAVs7DNwtjLXwUdOdyCmGfidGPum=