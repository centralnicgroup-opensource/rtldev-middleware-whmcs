<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwGdQoCqfcyLmUp+02G+jtaWLaK4NUsJ+iH7FtDJ3ufrl9cjVfLTNw1F/cPncrjNNT20u9xR
08ytvBNn/OXxwPyhi/YkCPnlQyY4Ec7e0bsuBIhwB765mnZM7gZ31L+X7Xg1S6VzwFRHHwGojaBY
S8DwPW99FmybqPo1yabdYVHmgRSrfub270g5RHcXjMGuHxTzuAEH2tO9mHMhHFAtrcfJKQ9wsaVC
9HU0gi/Cxw0wOY04bHqjNk/Was9dO0gWidkoV4yorynyjSYv3ltq3RDriIyYQDhCezVN9BrgvaP7
XeydJ6GWvtwJCU/T8PWuYyYRPJIVwksF3TQxrX+BmWTM45+XTFPe/HQ0lGlDGsFVHg/IMwkp/C3y
PCCC9Hz52auvYuQpST/4MpTTDjN0ppP9GDk1rXjLQW4Fu+gWq7gYz0ya/IQAVx7tZ6SRchS/uAN+
x4LEhwPPidHc8y+I50m5SFWC/PuUOGTcNveiIGBjyFXGV656wTxw0K1MKiks7UhqFjY4wN4P2R7W
KnBOpDNjHJVQBPuVrgzLZDskIwXZRIkjtfz0bLsUuie8Rn60a6PjGdDNixHqmBSmq55fAy9grd8P
saRF6dI0nuYf/dPvq1LxUhMB3/NVmk+nbAc7ebPHEaTKQs0hyWPJXTQdz6Nh/pbLgptrSONc/2fK
fH0rasOBJBn+RZseGTM3T1XG4VWKO8vHPLkCPr45BP1bMt3KoS7qHDMKevef1HOdOvTzYmBuNBjk
BzXTvbDTSlUfmuyZosrl2KzQNsAaWOFK3fI1OwwQu6ROtUtgPUYsUjugy5YVmERcyAa8jqx4obAd
TAFa0bPcYV7Dk4A4oPmHWrOWcmC1Z6zHLkR87RBO7UwETflxwv0u+E4N4D3HcMXy3h/km9mIeB2i
NGwCQ8TWXPUz/a3GofVm5jgsleDJPyvEz/gN28dOjC3OeQqjc3MNFQ4lzR6TQh9sqVeWYznN36MC
37VP1hMeZVbGwHqrZra6aWzdz6L1oZegj2YYj0gh6RC+I1hnz/ee74DEv+d4X0S2foE4sW78FTuJ
xgUacsnaph2TZmt9H9G1OAZyJO4sSy8iZCukUy6EvIAQNN2w4GohEqSL9EKhskT87HuaCLDcnEjm
yzZGZHbhlPQtlCOBkE3RizxKdk4EWcmX6YhOqTsWAlVgWehjHSmTAHeVnjmK/P0/ZK8t9K1mvfOC
w+nEkvtRqEH592NWCWNBd+rsQ2oI62Qz1XxSWay7dP+7y5ebj/q/3pQbSqJcKypAkfTSzar5jDff
DFQ+WTQRPgSmSqquJ5/atNpdBXGWV5RC2lrH+t8Ixbf+omNfneNvwdxTL4Wc1eFjpa44b7jHLvhv
nBlEodZhNdZVNKE0SJLhTMRvG+3YFt5OjV/HMNF+pW8bpPVnIgjZWzpEP8GCgy9iBBxLHTJpInTq
xBEKiqWNOQrqe5ymVGqWxCWgHJvGkuZoww6ATx+8KZwUeEe2ObjDujoH+7MdDkJibGmqFdxqHeC8
fgAgQ1qsRY3kDezkwDih/djgezOi8HyhIUcW4u0ezSXjPkBqhrXWNjhL5Ok8exjQU8sT0FLI2D46
FLrfBJChi5j2prp88lrOS5k9486w+7dA8hiR5Wet1MHlx4yi8U4LPjOX2I7s4OPqynJ4QRlee6n7
bAaaEwJqnmdQyt78BihB68+yQ8HfxgG0Z1+3klNxO5i8odgSvGPjgvYLHuQSuEGorg26JXpMCUCi
qz86wIsJ2oh0yi6lThroyeizO7JviC8G1DthKPGHxCb38D2ohkVF7pLvfmQQDteDNEtVpVuoOes0
AAPh+cLpk0+IulecalNIcgcfmaxN5DGNzROpZvw6M05Ob3vH8grQzTTC7OneKzpzPtLsgVw96VSU
7uuhrgeJeVDy1YodsyyLe6UC+7V/RAuZMLYAooLvGLFy4FGvgHqcZtRrulHH2qNWORgZIo5SX7De
G1dreB1teMhYitsLL9gQolTsb5waC+vQ3KqTUzzAnO29j489edXzQj3cfU8/WXyd1eu7ETE7eMp/
AdPjU4bCvm4t2iPY9l+KKNUTIJa7HWeZ3rKbI1O83uNYxjCFDcRZ8bcWuk8H70xyOrS7oVxOoKU3
mNrbVAzCMgHXcAXbb5UlFHi2B+vx6r0E8BADD7i5STd/vM4j2zJ6wdPmMPYhfKndB4PMj32D4Tdz
g11wglI91DFnIUE4j5ZONEBd32c8UnZ+PrW3ClQRU8DC+euL7D6RTyvkZ6Acv/1jVCCx36BbPQA2
JWqEa3bfHLWWVuztUtri0L+ZOwbCbH5FNzMvHCEEgxOzRPJ/WIjd1YtANydhqEvzV6mHd0g91cdS
RdzVVfPr+tyYo894QuuRnUJ5M3N2MGDATdaVRLiSlXvq53PA0bADcNSVS019nQjTLjaUxN8Lvtrm
DuXp36HmAWkrWh/kuWer3AdsKWRY83X0ayQZ0WGRAVLvKefhJ0H1gjUVNqcDo+D8T4uS+LtJxZCA
qoPAfGGqZUnnerfoCSEwomPRQUvJ+LRDlg+qwI2q87QJll+JZ1iEfVulwtbxaIfMXzZlI9g2cuvv
nZSvaiF2jHD2OOZ/WPooG6LJRHTGKjHC7WT60zYrLBcEEj80UgnmC9sjMpKexRyNYGaAEFXcMtiz
+3ezSa7oh6J04oiQ3kHXGr8STqhGHF34ykAdc/LcKnCAccCU3MvoDp0NMkLppjYdnZNmcSLIN4le
AGzZ/mH1BFZItPJQ7t+XOZciW10lKAxOSiMZaCFShFeIx7Nh+Ptj7GugQT+gqctGrXC7dkB+Zcv8
YQrEi4VBYT4ay5RnLG6XFts0evjpHT6jc0jE0YidiM5KSDfWwcTO0WF3gX3L/dIWHIuQwhUUoq3z
6YEWD8HEBGASw0Hz+M2ZPhgM9kT/z2YDgDHgBxTONmyfP2MCWfjoA7IxVErWNkBvGOQjJYrGmxUK
6T/Cv/WR8gRgRQDc/POsHSOP6kWhqRxTL6De/tVQkbW+icDmGVXouG+fKKKNTQ1f0LbcMZ6T6VzF
176Zwxgu3SyClxyq1yrmyBuflw1jaQqZ9BoL0Z4QGmp/1nhUAKCgTCN9f93vgi0MUEdptr35IyYY
i2APYwDc3b4NPzkqCYoqfHKgO7xtvb9tmBqFXVOfkv8MaVR25fvxPKeYo/fc1GFRLgT2vJZq3N2s
Aw1h8ETQU9pPpJDdzQgZwc5ZqwWdgx065E8KflJoCIvYt8chi0bVNGz+pgwxUd1pDw1P1lPZtPvm
1uWnaJrWcUVmnWHmxJLY46AEWkNZ3sr/guX/4MXiM8GVEReXg1w+q0qs+NIZgICo5v6gxLtLqdj2
nPcA95vYJ5T3JVC74M10nURLH6bOFghH6ND/sakfqnS9tMXgj3qn1AfxY8RVJEgYfvmfD0yIzEsU
D8ppPjOJKfe4SNhysw406eZdQhnJowvyI/2iPFrkJ32WfLe9c2iuzsOX/GYElJ8hKnR5u9U5N9I/
YovBbeKJvYt0C53oCYuri6tzsODbZ2oAADHOTlVpgUBWraGMFjxSdEv6elU1Vnc/3Z5/yKqM+lCi
BHlXhSACjY5Hvs5YlmkYu5goYOuGi4bRows0TnBjdUxi8D1PGEgSEx99G/hI89m+OCwJw77tz+qB
xheHT6FDex8+zLa42OJXuRxeV5jD7pdS3kHOrWjxEpvx/XqDXiJhfFfFRICpyu4EXXWUAFDz6v6u
ysakSiVhl6qqm3z1p8QnjuKCEvkHrVvkTXtMxVNcPuBsBxjQ//j19wW0Hul1l5G4BYiSO9il72G9
ATfBtes3WHjDsEuBKdDLl6+zYIjmUEwarlLeIUOPQJizArW4dcaXP56Fjj3lQAsKQpjLHCMQ5qvD
AVyNWW2Q8NQj9OcQQMLb9PZ3IF8ORNqMi2HMOOD7McEi6N2ojVLlADuW0z4+UPI25sYWTPYbvweQ
O6TEetnBLHCB8Pt25gaRsg5s34iGUl0tQ6sFcJwy3wroTM9uiiU3gn0x2d266IQ5O4a06mueis2u
QZ/PrvKrk2tRy9maaeICNr8bUcdHmhUEehKHckrdmNjYaFKmQBqxV0ly1fZzsCPYghWLHQ9+eofi
j/5HgE5Tpc4ocNcjQ78HIu7dOibst8peoHr6UgrMKmWCczZzVWJhdx/hd46H+HFvopKLdxR+yOEW
PJ61d3KOdkMdJT4JCEG+gxVT6Co0PWKoRz5Toe8GbNfViwqkruLegoPrCwTcA0UfwstfLvyqoOFr
ldsfmRLEVN0Mp56yKoJdRLCu7rBU1HH1xCk2VbGNGI+BeCIFdrgjlDQxiENfPkhPGU/Ht64HnAzV
zrAJC+ajMAcJMr3coP9KDrI8FiUIwdJcJ2RxXYuO2mwDP7RMaN5iBr1IpgvypgBdCkvoaubKbtKb
5lawLFRVYAM2Zr4s2XsNDtSi9cS7afU/XsDB4UkUmt9QOmR47NUrIaTpSJitV0fuAH37Zen+o2IZ
lkW8z91dqyYjR9FoBiStpKNUAtIvOOiVxb7SnMsLzkIJpaEL3jPw0N1eP747TMq19OqS6Zd+9FDI
SWguXsEaqlJZbStKjw+dZayD+rtfAySEYMYXJ72E70YPiPb/B90vjMIdeefZqGtCRCj6ABwQmWI8
yq5SQB4NnM/hY0AXc7VJR9Mpwc9bwRgPAFUumfPltBKkEj5r9Y4J7VcDJl685vydWX6vHeKsAquh
Ighf5F9S/ANaIhdGkLgTWMIqtQVuD1FbQ6MXpnIDD7W8LFtff9PeS/ohVYtej0RYtmO8EKnQ8neP
YiRYOIjDjV/OZ7yhPeiEzkgeofj7Z4y7lZ7TaFaVQ8ys2nfDad/A4swz0okIGl39yKZHvm1ckY/f
giHTzulsCf+SNlY76hI+rAworZvAA6NT8g9idvONIktQSi5EW8+H0LZVHlldcLGId5TN6aEGLMOc
/uLhDw92ZZZsPazYD7M3PAcXZssN5x78+7P2PPUx7k9soc7W8tI8MIS2kvGzr5vae6caiiLLn1Tn
Pb0veteRLSe+lWd7vlrr/dJ6ZeTMr6SOLQ7T7xFcjyaM5Q9IW0kSLcPPPB21IqhMQN1gFaQIrmiP
0VioYqMStqOuhWRIq+wThG6olvUjONf0mwsR/sXy+G==