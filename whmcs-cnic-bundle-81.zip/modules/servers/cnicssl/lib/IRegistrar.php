<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/ZgbTkiDMuSgLa0+B8Mgm9IYIWYcKDILUgIZm1eiPX2HiTzP9ccfG01MD5bFLnILb8k7q2m
tCK0Hy5LiZjYAAMbiy5PVP9f/YqgPNX4/oxVETu/xknTt5qKY/+ZcNe67lxhXqVj1q6yKFcrLJJc
2iylGxLrAAYguIAdaUEX9k+hIZDfOgm/jzI5lId4Sr6wFzHeFpJPEq9b8JJ50msYUwXwQ22pcAni
0vxGx7Ec9P5LD24SKc5Dgp5M6WMnBKv/Wxo2layorynyjSYv3ltq3RDriIyQP4vYKeiAhHTZF5X7
zeSeHywZXpuDOQGSaOf6Kv8sYV9x/DxrpVH8vcXi6cTOXynObmOgsuPpMTqdEW2JqUw62SAN+5mv
/jElvZNIG/9O8dUpAdO1FoQWsSTiR964BQW5BdeWlfqn5tHm9ttmi+GWkTvaNmcNwomq65oD+LNI
edhdJHiJkkss7aUFj/rQw3xJitrzEpkgcU4KK2vjfW3WZsrBXTZ/NVbNUPpOMMn+lzytZJya9fxq
oaLMyoIT5NrbRSaDD6pldljUWSM/1J2+VatrVRQVXKPwRMI0Q9Yv+eU2TZ2J2fuE2lyrYBwJmgRv
fRI6Hbk9WqjAm+lU6I+ZCBuOCg/+lh5KXTbRbGagRFaRBnft/qKSVWFEd+JZzITMvpSFYRYu47s9
SlhxVG8zAdOrdfRX5zDeEPBAtNYrPxn01C3ySk9fvG/NQ9aY8BWGKAcpMD0Srq2qDoo0HFEgSAH/
eE8Y631DHQ5LUGcCteYRinDYr/e8MIfPXLovvRexGqInCRI3i6S4yi2k/Z01PiD8mGt89QKiisRo
ZJjxI25ScS27T4A0y9LGCNqTAhWZxqWJ0whG4sBe+MJ1hnipgFwLiUVH9t8crTaws0w9b6UOxfmt
DOoU6o9CdK31EaJ35tPd23W92UHG0F13dEc+d334H0I1uIgbwLCHqu5+Uakk/0SD0fCqkuDKKoSJ
S5OJG3gZsmLGu6KBrH0pQ/BUz2UeNOAElCYbSAq0YhaP4siE3YjbGtIhIqc2cXt2A9qDfrnzauxG
OriLy7CKIvs+MOZOQOGrFRFffZhHGX74shKcx/gXlT25WHEkOb8UEM/rrfW9UpHwQLB7QHSDdkO9
DwxnakLkqq2g8ui25eJAW9M1+wKqe/6bFqSQI3aILxwmTtVVbmMRwDdlgo9KxoNrgcbu9YsTM3k+
D8VXxnZJ0w+NPXYmYuHKD7jq0lgYgA/vw1A1VP1S+Jd5NSYkakp9KrBZNTQni7w8lx6Rh5Ft9wtW
AVuFn7iTs5ciq1QSvJJHF/pg60TRsC/CeUQd8W/tpzGKtRBz2g5VIVzjW5h7Ph/vutybo4zxyznJ
gqN3nxQQbSVfodb7iB88vzX/B+sI6M8OIPJTseanxx7rYrNB9NviV0tBsj/sE77pVWgHaQnCn6XG
m+8XI/Om+0VBjZdNbfAr5aG1UIt7rK1I+5ZJRufFHGW+uzQBxmVx7CnTZC5ErQgCJvSPmudEDlLa
etQl/kZ+QVROKngqpZqrSCNFdaPs46qonDBHGA9613WewwBfjwD1kDgGOZYFG5RijF7Nhv2NGsjQ
0iOlIIJTuExktP1KoXQOGyuXLWm06fjBLnMkVu7zJy1HQtr+5Dbyy+tZjKRITFbI1lg9IlOzcgdG
bMH2+l2+PHD89yjGPJMBySpLn1AkFmJzlLafpRMZiZJbbyvYbEmo5mLBnZHPA/L2s/BZ9gpnpkVq
UFoBz0CDPaBmLgO2nPirbuBXd7WxfnvIWVBpalkj/W89Hc9Z6c4zJ7uHXbXSECiOmqcfTooJq4CX
a41g2Os42ne1HVq2pee2Jdk777E+ki5Ip5rpqSGRujpy4CrcDdNAqbTfRPT1HBVBg1HN7D7wBGj3
fR62f9JS2sw8gViNkQbElDcIK/916pG+8PHoyPU338h/t2GmlDMBridDPo7N66sPEYCdOShz2K+2
rMSrE2D+KnDd0xeWTyt0PLqHbNZoFltfVoYEo50Joc6LSH5Fshpb/jcwAD/SgS1HgckE9TsPTdGI
R+r9eN6E9bB4VQmdWfvYYPHxG/860WWDgWvC/dm1g1OWe1VmNLLzSN2+iif/cQtWmxoN5cYp/sg2
GvbHLVvN1nyCdDdr1XVcGI8ij6PaCLEXaakw7dbqU+ZpKbjUOtUghoBThOLItpAn1ao2f/la9oaV
oNWB59Auv6XJ40qCSHy5aND3gWW4POinC4ewyhe5wHeh0saB5UlsnhAS2a+n3v8JDLwiEi44yjdV
c9KN2Azq/rRyQRIFRdy/3U+mEw/2/QKVbiMacXD4Xy7ECYZ++UyTI02EpxmwzGp4