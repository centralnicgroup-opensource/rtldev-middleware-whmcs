<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuhm57H4M+rx4KU1LmdIEFUf70c+vWgZRfgu9/D07Kj1iZWH2EO0kvUqVj+3zDF/neMUBk+6
dX22EVY6JALkveUjocyZrxVcn/7PzYqFYPdYrcvTDtOHw0J+WFAYHtrElcEVa0WwApgn0DMzJplZ
VSKEnaqxw4P10Bu92aJ2E8LayL/KtfFg2311qlFwsPC2ftmL+jJmlC5S7Vn1hBkLN7SMqlXa85qh
JrJWQq3IEg4hxWGnVk1imuBqKhe+gkATdH9C9y9QBBwxwMaOXrnFuw+P3yfgOlAFUGCBmvNAX4Ms
rkPnqYBZuHpG916oE49oJ7P61UdHxzrU33S9AqIB8i+spjmlj0av+FOlNlcthau0rTJs3pApuU8h
n5eclivnkM8lFbahvu6wARv6q85N3xRYCeunTcD/N6FwLpXKY70OCNfVBw7fM51vUyVXbL1bvvpi
bUXHZWu8DaEfoPK8Vc1C5okjFK8qWtPeQrVhOVkWcLhh0k8xYQCdQ/gJOz6uBdeHuJRCRULdLHj/
pzmzFaz/qQ1vMLxu7j1G7xUmep0GfTo3j2PCyBScmcrgdUXOhGT38szyHv7KA2njusuvnbl0aZJM
82EI2ixWz5n5elede1W/nQfUyXOqpuTCoLPcl6FsiSFF4XypbLQd6BQ2epItNInYZ/s/OrETwOEM
C/og9R1SYtr5jjb3Erp44GCfzRVPc5Iuuz7jjBMDdvC5RCn+0GVklHYJ3R+srlf6lMSuoohddJAm
VRkaRgoZY+QHSK+sZggB777m3Tpi0neRLmJe8BZ6DYha24JYe0knSeG8x2nmoTPWmvv5BGgzpmr6
aY50it1DBSaYGAFf9pxOBB0nMos7OX3mOPok6RWnpvEZ