<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuj+Z8Pbr7IfSBePfVLxmsYEcIQ1YvBnQAEuQIdRylLnOVmmS7vv3RYuctNBUaZMiPqGJzWK
aH89i8lLfekMTddJ35pC7eqbNnwapvvTrE8oCf7+1vnTMrnOihRbDI9ecHj7p7tnHJ2bv9bwD+0W
J4STv5p/ULu6z+CDJ9hHZhv6lH9EletYS0jjIisifUz1IIn6jddE67PKzdv7IAs6g5rdbLpTUSly
dA83/Sh9iV8XuHrN8FNYZ2VpkrRLZTZdnAIPgrxnAPcbprMKWIRvvAVdak9lklNvgctuVy9GVAim
xsSGcg3Wdvk5rD8AU7NpZGV0mcSLkinRieu2e5IApmGzxQiwLUXAm+ToE3bTcY3kYTIA00hnCEiv
HK/qO/vCdHqtL/Elvxzr92QdXeDXh6nTqLgNSOdR20EKamlO+QVfJeWWI/Telbf6oNw6sAqGFqWn
XzsL/0JbT4yeq+jIaY9uBhBso4yL91QEjUIny9MkyWerlVSC0phMhoUaFu2G+qza8xKwuAWEHB0e
CUtecV3jvKXxZI8Sf/LC0/aAZDYTtRxniEZ9OEvTB1uIYfCAsF91XSoTn+5Qe1udSY1IBESt3CWu
XE1dZeZK1S5/N8yjVAePHaiPeKfpYBbkDlnX5qAEtc7vxW4mfI+rK/s6Yc0Miat7yL7Mo37d5YZb
vBOMYHdhH3ZUNxC9W483lVjZJGDIKCNi4fm6WJrRpc8cy2YCZweqR8LzjYjhciZSBxSaYeX8M/HA
IYXIGNtlH7KvU7HNME/E6VcoiNR++Hi0REBbma9kSA57OJaTm/mkjtyMuivz8fBKW7T6wlHsMXxv
P6Bg7S3gLsKQKv4neAt2abYFX9lVKLVOq8QlccuPdP/pgIQimLlyFvk+McveBZTGnqvr4qX8i8tN
VuHSIRoITBvORBjuVJeqRwLCfwPodiqztcPZCGFGTvgavKs+Mo0t3zdISqcB724rcxnLcObadICU
kjoaP18UnRRmCqkboh+3t6TcJJdBNvheWnvHyMpuyKujFTvwtR9z3eWZmHP0NIqPPnb6o4Pc2Ggw
2eGmFoJ+yZZa02sc9L708z9Vh4HokF5m7wAB8GYJU2DfJYD/C+ELntqT5o3g70HU3zrOq0LHak7+
CiNWkkf3UgY2IwspT5bPkZc9+gbdvkv/mVkzTOK2qav9t8kO97FPcOJ/ae5hrwdV9odKxtDZigyW
dyFyZmecMCAIeHSwkPUVFLbiVaBEV6BLWvy4IUKPWTo7FmN+0n0cQBDG6qkmJFdH4DUgeIRSCQwz
t5uDIX4kXKTsPzDv8UTrKOvgOLLMma0RmW+2nWI6sOdgqab9Uul8h2wGn2H8a/k7DtUrPI2Bt0Zy
uRtl4XiRplZyITIqsSvv0a6fq1Bs8EFTaQd+il39t5O0yrp7u8qUxQ6+S3vTSSa+WySDLlM07aUy
t5p5a49zOjpmN1oekwyz7cQLLbMLqM+Hyts0FvXiysg0pxQiOkypDRzGIgP75DSahKWlDoNuSKDE
AGAPWHdakIRiSJaO35QKQjuNbB+wDuYcPsllGRC6wsA7mnYZpC0sAczGuMsZOkk1dm6Yi85CTvaB
1BX7pkGj0XkxYXPEwHeVobVWoSC2X01jwb/Qxze21VPh374HxEslW3R1ZSReTVOMyF7K5OOErXkI
M2tXsiaUTx4HETwFJgNUb7FmxbqKqUqTE2p3Bc24hAAecuV+EIXa/pET800Y3bTokOlAKbv7Pzci
llSNAj0Vj5QSVpyB1G99lKRxE8pA7O14TCTFLjKoxvxBJyNYojPXRwabVUfs6ozsmHBtMQZ/vklS
Sr//EDeLixm/+bqcrIum9kvKmHPTiWAuqRAU6tw0njUvsBjO8HDjULKJBdByG+Ij7aCx1q7SQhVb
GWzLgCHIe8wu9kdAxJPYUaEnVa1mMUduJxwJUItxFVgcIsJHBBVPsv7Ct4dQtbdleMLWqPfircUB
cD0FlOKfEI1Af7Pm0vB6yeZ+raBEfpzsgL0CdaPs0YqI5nW6ODp9DG8jpwYC5rcsYG6hwzj4CHsK
ko2rVHESbfL9WgWvRA2GLAKDC17JuYfB7G6ceP7pDchokFvhXK9uVbChYbSgzSpHLhHSQjfxcvNI
g6eqFsiY/3zKcdcyA3yn5BFxDO2FVIXeaDlzmN5uwCbtzeh+33rfXgVN2lrTXIBKBHan71k2Y+Nn
fW8sMp97fJKERKS+6PPzujtWjA9yJDXYbe8dTdyAfqXKcErZ92wn8TOIdMuBPYTWIaAKAIilH2AE
7BtUVauZFTGcWfoS5h8MXR6V8sLjWN5Na6wwlPbCgMEvd3aeG/sRcoWxdzOvO+/1t4TPPIguenbz
bboT4TuePsUM+EVKfcDXLcAF7zHtx44NFWwwQlWhVU5X/rPq+S7vBNkxsbxN3RJ9wLsYL/NijjNF
h+S6HQz8C5vtclVVcaAim3sT8izcoL0XlAj9012CFHEs45JouXkS6B7gR2Ptwwu7wrL7aQ3VDHs2
EgxqkP/VmF9uhgaEQ9FH8aE1lb6HCM4zGy1yFcHTRmxfHZ3ynXPzK6hv+e/VBceGglyJIL4gsRzk
Qo8jt9Db0JiDTEpnr+VS0E/9M0LD4or+ywUzp4/YvuJyaqmEZNh5dWuM6OCoRr/ZuKPXNAye8Kd8
k7MqUJTxVl03LjuSYMcF1RgGU1DtCFFEYvPe1Hchca9Xk41Nkdy3eRZaJ3YpS1hivE7i9vhwr1rx
gdcCD5t/jvUSEUbnf8+MqBifATL3ieeJcpNhsEofJ6tnxwGa3h1az5jxVuafSP55DG/ZRv3akpOo
jBgp/uQoLIhjZzRATdSss/TPkEiTFbAlNteDTS6x2lNB0eMYWHV9dck1Qz6RorEuRCTcvVOFEr2B
gOdEW6QukiacG7F+r5rnFqu8QOoH+z+siQ9A1lqSfzYWT5zwEMNgiGWGv6OIYslbNpuGthsvZ4KY
/mJ2E8ABG1AEWf3Zr0Tf36UC6JyGSiBc5xIX5trp3pRl5gmBCu1UMg18FijZaejf471aU//pY+8B
NzfZUcD+OrBWQAzeU65AUCo7oebe6IW2Rx19kqHaJMeY8//400+wEe/ZjTuAaAaC0vQGQ4wH1s3u
nsCxYbKT/4DCpLX90i9TK+GgmSEHvRS3ksKEcNrnE5fr3Y2nZ7crERnCBS30tIR8jnFvIHBAX/xd
59NtT7R4qf9KX2Bzla6TKxTVAo8a9EHr5Qsm74trn12CtYmU32p6d39gGX8tQruobccIgTOWYf0p
F+tGkMwp4cW1nlqZzNq5za9Z0fk/P4NI8osaT5xNMWYtjoxUv221JFCmaUl6kivyRT8wV6kkNnZm
r7IJ144kotmMghtyAn9LZB7SRlwpm0sRNIJWmPVhCPZQsUD1fgfvIgVCGEiaRRRb/jYWwiHZfy1E
WIb9jvHeXbcJIv2VbwTiqOXsZKT7UVsdFmJ/OLce48+V3rb23NE2A4DwG8o0NSJuYgSe/5CmYWoX
svySttGUc/MOR9oG0XDxhJvcLQWZupH7GBb6YlDNQX71A9JscFPBNMqVNq/jIknhWHlKYeCm40Uw
zSfAXTlhqsJWuCcmbsqWYmu/UVjwXiOZhY9SY35WUECJdvl5rEgc48bDsuXTHKPyQPEppkm3amrF
keg8TdTZPX5hE994cNpoHJ2Gvq3Go00OY2hNGQxUVt2twiYw6DUkyx/ZWF/qHvYkJ8CxzGbKRY1m
Bjt2+Ckz18T6Rp4vWCzgZ2+p4qUysv2aZcupffz9TQ4K3EeVp5Ah5xVS9U/FaTWz4+j/QmgQvM6V
C9XV1IYevLGkVAZvPdU9UFoTNmxOwftH7jDhuAd2uC9yDr24OYbxksn4LhsfN1dlyIIVypTgpCqe
VCnjlG6JZj6QO4HdrWV1qLyhH++i2ML8uRgg+kceLFlGR26PcZIOR+PPTUJM9J6jR7cL3WO48Uho
rgamgl2o7CmBI4PxOTAt6kFU5cmNwir+kVTBUfuk6S2m1CGRC2sdajLKK/gKhJ43hNHjG501sMdn
zuF9CJD9v8+K6N4LgSeKyRFsTPfkUh2pXug4tSNG0A9inRSS9fArwarHav8ghH0VuNIFCz+WtTFm
tCpUJiAQ6+v44w9TPVyO64BMepwZ+HHaJml/cRhLtNeffd8SA0BF/ocZSWjLiSFb7lW9FVXNu8aX
CQnrhmdV2tu1mRnfds1s9Nh3EoRzUU5/nIaQzmzWtenlkw5rJQBtNFoNPOW0LUT+UF2cPlBR+d2p
efD2f5nZcRLWbDaL9kjm3BMszXe2YBJXvl9TJQKwk5Eno1JP293t/g7IFLJyNl154lmP8LAj6x4a
FYwE2UnBqUGzIVVis2oXjtQgbbAN2nUsNFCx2ofjYgzMtqwIpHdD904jiWs/k0KAiXtB37yVasQN
NiEnRbeguilRHmPDa3K+P4vvNH6LBVsj6QAHKMTMXJKk1QzMKATYc5yr/n/0dCkQIbwtxwibCwfF
+MQ+2LIQxXB1IvuM7lgLr032pqN+sxYkk0nozchYGT4hHSoF+wbg3Bxif5RW0QDElMjwDVg0piwt
Uo3gy+FUiVEvN1ok/W+f7+/W6eIsG4BO3A0FbgNIMR17C+5STjBievu4jUYErfkEo6jM5athd0WR
GOxKORkGhMe+FQzETJqAp3LRGDdVhupCIQ3g1Z1NtYiYDJDn0MVDM7CcRx6bdYP5D5724VMrXXnq
oJNLTjJVko9K1kCPm7s/ijPtK72g8e/v/ub7ZvuzvsBSdfbaXBWayzDhY1yAoAymRzpzyTpyheb+
fG8WNKCJ3ILXQETL57h/vO1CdrrVDM4umAM5Om6dnXaFJlPYl/e0OBzMDVWsJCng0TFAW1UtoHlm
m0mWmX+64XBTYNpXrtVs7xL3EQqRb35uQgKZXA3G41aurIa8QftkRdA5HpCIdfhVAgu101m2fx5O
c+E8iRedQU7VJfiESrArjQ/3cGWh2lNkDFHBnP/ky1z+yKENUF3iXGKIq2m3vclXH1QSMi1U9CyQ
2OSk3/GF/yAj9g+v7ph6LJ7L1k1NaEhV10FQAV26UTYiMxAbIXKJHF1GOaqvg5CTn6650EXaceRG
A6WfrjP3AU2yT+GLvikcDeULDi6kLNRY6ZETgu2eWS+Q4I+o6z/xOgg885XZyYR6onVxdW+1Q1Ul
SPhHgo3doZEYuagz1AVrGwJg1KMkJI9+I76VFirHNG06ttZTFvV+icXv9aex+VML3oBksN56orcj
9jvFAqy3E4aH86+KXlCDbJf6ivquKw4=