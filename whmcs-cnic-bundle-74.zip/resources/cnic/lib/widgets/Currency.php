<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt9GszmCl3yJoU9E/rl7HDswOHZMjZ3Sze+uOnxOAkv887NSnJBy0Ys6B9MKmslQIJMGsd13
1T7wQY77bC7tjthXlC9MLA08RVVgqIpmf36lISDCqJO9nRmaMHfODwUWVjss8wbwimtdXMi2vBmo
WcJsCxr8NqpYS/LfaRkapEcTJc5aMqKPfKFcwNBzEgop2Ugjs+fBg0dNpW+CDH+QDedjSj1AKhBf
yEH67A0xuYkX0RyA1hAzp8hgv4DlXKUU7aUsmtHCrQItKL42gCkSGP8WTF5jyF2CGdf7eSBlbtdM
EuSBimy/BoapLsnwLJHE9WJMshjXZOiwZ0ElKherm2TDReEq8d03hsYRCS5AJke3SdUqcqpY7gI3
2NPGWl7zv6rq6xm0erN2+d0kzsG4fEyXVJ+Haxe5mF3F5iQKNaIF49WL4BcEbTXMWbY+NqwmmxG5
Dc7pT8cP1bkZqVdscPdG0kjzcVWCeeS/TTqoSaflo7n2AwbS0YDCmmX7gFTirs4k3a74peIv21Cf
X7oRQJT7oJKiTHGdYyrnI/eIKyZt5TM5Vmz3rvCbbr/9LJusidw97mkjL2mief+TXvSmNT5vvJYR
jnc94SOqrXFHuv+aJtfbaWGpCE5yZaLEvJkNVTSLMoiHk0p/SCLhRqEmGpWCKK4jtNBDYu1+eOAl
ypfG+O5J0O61fH+OZJ7pf50HHlh+eqkWApwtpuJ3P+xALBChPNWkjBXO6iLYbeB4dK8NY3Oo4Fqb
mQZDc5iuqfFk07kdYYj0CC9OTVGsqvB6JroNUu8BoFMkM6AQmg6BHkCKVGZ+CDq//wWTAbn8i9Xq
HL8O2z7FJ/ndWR9YSNijg0G0WrmioAG/v0wIRpyYRoWn30XCqSRHqNCuMX9LDws4na6AuindQL+O
ZYSCeqO4+oIPsnVxv93Uty1x5sPOEd6+ZzneQJHFWEgf89xKLMI6Kft1p5T88CY/VITqUB6uYYHu
Gx15Jngy26s7dkq2HX3LZ33YGrAz3S8MOu/+PTDlgWLimKVHCutgJVzuTdoOOkTPVG6BACBGITCc
j8XdiFWMrGff973c6Z8tW3rS32i8PObtXb4/hvEiFW0E0j2KNoPTcWI3//J4rXU9mnvL4e3YU58O
EeLzYBjgY3+XOfFl1f7ZuP7UaGiLEpgVhPsgvfcbLuMT0L9WYJkffxat5E5wxJuv/aSAP4i2dA0C
tW5nhttS0uRMYmODgan43S5oIzCjSG4/x2fxWDKwLG7c/78J8W579gAxUdhq1ZPzbFhXYDdalLf/
W+SHaDAhb05WRakr6dC3IJ1uC6tcL4EBFeI0m2oAfZq8AGvO1WCDSw1yNQ1FhAQgVMIxzMQ75I8r
IbfhCKihjQIeZZaW0R7p/0/Dh13SGfMqWpKKiY5YbKdSumfudA2aslho8HHClXkWrKig/F3tCUJY
dFWTPcT9p2hq1CkZbV+SsgYCRTNIVvmz4g6cdD6ze2UJoVlg1tBuHLUpmUvQlt5CFxyTnX1mPAxX
u0XdSgrsx34dGrY/yURcyJUg4u9Whp0BO02HPeSr5B1eDNm7p+pfMUBDsy0/wg0AAmPEpl0dgOgG
jIPhOe/l+mA5SstmqS3lX2YXnhdho4KXjO+QI84h1R6vXHHYfxR3r0yqD9UwmXCloPE3I9PAOwaJ
t7JXZhngrJfzKgUO5k0b3tstm6J2DjdVR8jo/fdpDesqjk4+R7RYvlV7HnsEbNNUPWGzjYA24ZZj
PEaIO5Ftvk5loKJyC6h5k4qZJWx5Qm6DlHrkP5wnS+fDaqiGSZqwe04XKDSjIy9btKq0BLwVf/J4
Dtzx6LgBcTzHFzsD6Vu8IMQc15DlR71yBAkgYH1jSjDr5qShrxXrw2JGtyPDwDOGTBk37YtTsOtr
8L3hn3sXQwJMioDczhdkrWrJHuwaub1QRHvHom32f6XA1gu=