<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/Ox8KEm19fqJOcqO1kEr9rDHX5O44uSwDGYegsKk8NCw33zWO0WLYZ0wTGM9Sn57nQm0QPE
lT8By9A04fkLDAr0PQ981dTMRFwbYcKvDT4oOGbMK3FVXNHejTZfnVgML8jOJJa8+ycmynRwiepO
OHH9fp3/dplawbiJ+BDaqsGce27bhx7cy1PFxQ7QyEBqFiwC3/yYkZb3CkF/DhidgQjQYv61rmeD
DRkfZ7n2yrZNZL1aywVyhR19q/7PqBiFgHx8AMx0bOmbNtBYSam/m5YH1LowQ/4Kdr+LuZOa0tAi
C1O8NZhrt5Y2wV4mXYRg8WYgU75CWSGYx5jmTWZEL40wCTQ3o1+lua04KyzuopJ7YjdGgl5Lossu
OPgOS7oHddGjn3ssHM1/JsqsBo56046n9c2XqTVLXBdsfew+Po6F0XmsixroSsaZ0qPwP66WQ0Y3
zRrqZhreHbHHEKRwt/x+IjRKyUYWsUN5VSX+JJf3vmL+E8ze2pXcN7wDgNNbtD5Wa+LntWyMUrZy
/wTz0jH0OTUWMRXSyrTIyMEIw5Yu45StPWXoZi1BfqW7y7lnmSSsOcu1nbIExX+dt//MOkRrmsbx
Fca2bG4qdojgob3lvZ0Wq+zZa9zMtGq/xx4H1nGgtvb7tRfa1TLXJdlXXD5f+J94dI9901hiFY1L
5ZzTZ32gkP9Uxk7mVrHZCFmf1DTLbHVqL9OVq5t7NgZFVVCUnxerLDlDIRA5h8dZWcRkyn74P8/G
01tk+IIm/mI/BrRC2WeHvIqIw6AAv6Q2JRABC0WuCGrytOEGM0Dpq4zgZnCboVWxtHSpCDinvxf5
sG2DO0SQA1WAD7kPt2vxpyhA1C2HAlmGOWnydJbskOiCvEgnCUk691xL3LfrQheSzCXyFKU4Grf0
0/74qS9Ps42YEq7DIOmDnM4LUW732J3Icn2MkOMzZJJjBlF8qB6G+1svtWS0mZxufa11f6+yrsH/
ScBQttIR1c0sl5oM2cxnMoTIRGGdUxtzs20jtFD2oinw1BjhqSw8huKVSseEg3Oa9C9GkWaw5Hhy
sBMY0myX6WN3U7lsqk/NjcuFruaFieCOCHeWzTpK7ID1xV7fLvUf6D6WM1P8jflfHJJm5yxxTFad
SqQEUDTfMBULUgOrCQbe1fbTibgqoKWLljMCdaI6O+zxOOtonp0oSU1rglOte/cmdBTqQ6lw5mge
FViMbVsQxzMhfUhF0oA0m+9w4mHHDmuBawpOJjlyqo6OUthsW4L0kdAQ+77ZNRcNpl23uXaDSGKO
DXV2oL/cutYEZSskWKBj3V7IIlDhMrnZH/MJ47QWh6McuQxu64y3OS0R345+YBbY1nyYdegw1VAj
psf73Crq621Ck00R/GsaYGupuZQ0byY4oR6u7QzEPtbiCnxZimnN6ATU2s+qAPOq1rb7+OphJYfE
5DzntZM3Bp0mDvbGZclVwDw/bWYjNyybep/CwlcDQgYDOeMGKfVq8/IE+3sIIRRGSLqw+boxny9/
6+2BvE8hDfnAXvO4PJ7vXHq8dn9KK9+DnngI4U+tny60sDQbNo6B04VTPpfqtIXaWROuHJQdTNv1
VSYO0QTXqfAxZeebE+rqW5iMkw92H3xZjNUIOQVwbthb+kWdAliqM+FGozmQTrMqGRHoFunBelbk
SEoUukgYKR6scMajb89F/bnVJpy3ipOzddFhzz9gf10O0bLQGMyOdr/9JY+rJH7F1flGNpLQwvZq
A9dt1adx4uY+z/IATfESizKb5SU70Q3Dybbun4ub9aTflmsOqbPV9ROACdtiFzO7zbPr1Vip6rfy
TUDoVKOgwpDNs1PgwOWP7w1liL8d4qieGZMT5trIon1rf6Rs6pdbis/1eXGXR9COln3yPIvukCrd
xYdvn1i2Zj20rY0+46L3Rt+pyPrNs/Ek0fNG3thFjCPP5uO=