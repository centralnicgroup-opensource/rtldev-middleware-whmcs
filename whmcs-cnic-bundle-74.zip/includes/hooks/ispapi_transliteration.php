<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/B31xwdWFonlWwIdUVn/3ekzwk4TY6MkekupB80+iCM/VFLf29bSqnFmqQUpwhWRQ+3Ydy6
haJmBCLm+e982hrbuvOUY/+kYaVlY1yKX/9RlUY6/UkH8sME4hmwTww/aAOnrq9lkuQTyx7tgjak
ZwbShnCfWVy4drOvc3aKKqELbcXO69zfMHy5Y80ha6m8XcZ/E//zd/NsXKvdwiXAu8Ts/7JUIgsQ
tE49zM06n8zTKdpjSdfYDtlrh4nhnaNJ4+twmtHCrQItKL42gCkSGP8WT8TnRFKYY8U+RPm0ndcc
78Wp/sApAmODisaNewaNSkL0dqXFKHuA3GR3k9CbcZERaO/nC5Fh03j8zvsAhBKFsat3DiPQqHwk
MV3I5sslzPtC5iDreFSEXYgAeRqSiDL7AN2pPq3lAQnxw4skrw2ipbERRqeLasl05M3+zXJ0a7is
YjwikwZepLXVnXW7Wk1Ex3crnyLCPHBVMtFwwgJJh2EA2OEi1zd0z/cinFK6G4dUSKvyRj1Lk70g
bawlwfE0DRnDk/hjYiUvLSM/2eE4oUBVEvpc4K8xJs+ooYmA2jXVFuUpd1dWT+itYzAN+3bpRS/O
8GHkAAv+v4BvLG2mK6EsFxmC+aGBlfAMnB4Zt8fg3YV/AjmeUzDeZpzXhEj9Otdh9mFxsv0E1hHs
b7lQk89+AGur6oquwtjKuHpzZI0G1RJ9qMiLn7D8Lc2Gq9szLGnLsPWXOMYkWkZNlmubPVfPEhuD
uZYqL32ys5/ALU+jqbD+0CM80Ek2xJLKY/qCfxm4U5LOAkFUqzn/+H+QpIDVsy4sy0hHYe7WMj0e
0YThQWN/HkEBt2/OaI8aSL1frh4d5zVQRB+b1ssr6/yl9bfaGnGsurxHUASTY3LqxY5EWDQ0Fe5o
j5EaY5Jv4RDLpBXa3dw9MZi426cVOKGYlhroC5pDipfpND2IUEgABsYN2Nf051JMKKXfpdJk/2wW
kbbpIvjd3GExsfiOHgaNoR5eXF3l0McOqmv8yZ169UqFS4MWp99Br1viBYhpEkyAJSdCCi28D+RG
kmdogchJqjldwWPSL2R+scbYZGqCuVCT32WrnMU2ZVBat+GMJwHzDnhBK97SRHndABpB6aDVXmG+
rNHQ+S2flSVMrIARHQ0I3Iq9g5Gq/1LOo78WpQ9gqUBAcpSOh2n/mCXrESo6RelI8H0lLnw+H2Uf
6Vq0uhJBURCQWJWvKkamqXnYtXoxTE0vKCQP4bEpMqni4aZ/PZbJQBDk/h1SYcZBiSiQTeqcDWsd
3vz9K1czzZ5w2mPF2f7dNIKc90evEBYXhRdzbHgIoObyb0mnfwmH77J/D16vOTUlrjdknxXS9+Hz
+4jqhGwz810bWtMHi6vzHthDaCTpEyLwBcfqOl4D49skgGnOUF7NJgu+jpXiYDogV4vGrLe+rW0L
zfnlrxWLycEF496PnmK+oyFdbtjF5IbmSMbsEvLSh80UL62Xgkt+IToaujM/67eFPYq1bx7WtnQ5
q9IIg/LWfeWtGdkLWebPvjJ0S5jfYrs8REQEw7rBR/bFmv8sktusRo0VSYmhQLdXQmH52XDK5atm
MfRzAKUWVmvTX5ixGh6MTl3+SwYV00ZFpgHeuVC+zeD7pI4Q9PfW355sK3DQbrQhdU5c6BUwQTV0
QEZVschGgBMIS7vC4jYMHv30anT6LXdQik3y1JM1lCkmifXaQ3/ijgNf0UfWbnrLJQQz2IFe5uDv
pHdC7qrJcN6IRPt6MkYk/fst6tlvlTcD4TywC4930wOnAPTG4WXMBp/Nq9ZM2PB4AInzOUsXZkLC
rYcwYpF9rLhF4lx2LE3v8UgORyzSl0HXIM9JgirTmKeH1lhbCeb4AuBmZ1tKJwUJeZYcQ9YfOhnd
Zc/X5HszSsOK10pxu542nzm7gmV1/brJoGuvI5eJE8gGLT2wgxD92NtG7qiwa4DwvNzjq+HEyoo6
k5Mg63UIV8gDDbjIuE8ZqG3QssgXZQvg50zSmoS9SL/EGi+LG/iADUc//H8a8hFPDk4iGA0Cjqs0
1FzzC5N0Aj/A9JNitt0YL53M5MexWV4da/aiFGq7jlM+tCL3Bh2BIADS1bPTbjAtPwFwm2bX1cTc
Wi26UUC9Mj4Nxa+Svf/F0NFE1oBclsb3N5sPgSAJCDdh+jGqQlrxtkGhIifPfBS5YSVGDNbaY9Yk
wkRp2SGRDEusdQFtMucqLU3tKA/nbAX2aJDWyLBP6qZCwUDzpDGunDkYKWLFW4kzZ6gVg6YdrV2+
2YBmJx40xxnThH+94YSUL9AqlCcAf8dtr/vqg41YcmchQB+YXy8Dor5R4BrSU9HuPEFLwuk0FIfb
DxWbvweWMUauaVMObh03LzZFTX1ZvjI/8O3GpSOR/uD8+plms2Q0MSRgtz93O+EJHu4L1sP3hdMR
s7YfOFj5uekhz9wlMbqeQBW4KGXa9n9/Ro7okCHK8bVluCKxK8jExRWwo+0Y5F/jDVenW9EdrykV
S75IYmHKoXtLIfNB8bq9lBwZWhQdPzKIYBJpPyk8ppvfN9oUAFvYcWJwg4gzC9tfKaheVcO4vWzo
Cbih6oloQ8balRKrnv3z2Oh2iZ4nnZvrwfTdRJhxLYpYEP1YR9gKCbVZ90RkDvaN/JLnXBdtUnvs
dncUfNJPOEDxkh+Jpv4aUCIAwnqqrMt7bEKMFPcoah+UHGqt7LGzTJ/CQUQtMV9z2Wr1xPzn5cGn
kMhLmyeW9KzRBxB4rZeW/TCIin9I5r311QiOdz6opwTJLiPGHASdesTgg9cCvv0iCXYp/OtsQRIx
s3jq+Vo11Ejcqy5PgTKBgGYE7RnaDWhVh2tR7kCTkQNHReK+11ZNpUgvOW5kqGNfxZGHYYMwEbPw
Okoc5792qEuz5aqC1qaJ/rw/hSM21V4CYLHD6rTI4/AvHXfv6hAKsvQ8EaQ8T39osMb0rMwhaY8n
1u1nQQ16ZvL/CtpSSm/V4CHQc93XGplzdgiNSVMcir5kuDbJ4cjxFW1c9DcAk/ZmZ6O=