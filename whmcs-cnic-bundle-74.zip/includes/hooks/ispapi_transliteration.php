<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuN3FNu0W8PntGweNRWmrZZ8+6tTxg2wdAsubEBdxrWMYYJnbRqqUiTcsmq3T5gXhpDZhou0
PAFdFm7fW8PN2VXUUYa78O5Zq2k1UzMnQnbj77WHNNTTKn3LVWPFtq8DGNC8Ca+SjW2De6bUfBMs
A0UBcamRNtWBFNFqHtQVGgJN3R6tbgzMOQGJhVhUCRPYv9C7RAn++zwVQywEX/U8spFjdyryN6NC
t1KoEkjkREVQvJOjkpVyaxTWbG/SG3TCq5crgrxnAPcbprMKWIRvvAVdaX5fb0oXPoJMRVDr3Qjm
3GSWYJAXylNR0CXqgTkx6OKnTu2QXK4Y2S1MQ5Dqlo4ulJXJzKQAj1l+PKzotTI/ZS7wJEPC0PFY
Egr84++DlALr6eafqTpcVpIM0U1B69rO2NgfP7DW1RGf/OaBHMVqzU2z0jcaEhLAQ/URDrkuwItS
bSH2A0vCqDHkZhdjUiIQnGnsEJwHziKs5ksxW1beTS9JApzi9kC/2NKmZn8F8pTzRLSwlSaP853j
n4kOAww8MOiiMj6Gk6UEgSWg+9aN7jv8vpwAw5HG0yA07ci0HumdyAPKSyEewDJGASeqQfIJJ7nM
ArSbrgAlSllFBJVdSQAgXpPYvRsDl09dkudy0LLKnSe/p7p/uUdNWX7OT82L+6ENrNS/OE1sm9AM
reJzKrXAFdB0rBRcx4X8+duLc2ARVKhvaNxKw3D9who4r8IczxN7cGrS+2J1XhinzYhoBKjo/ezY
c77i/EKK+pYC5QRRR1EpVjVYTLzGiWcCAwq9yHvapZWUrf4EODXNYqY5gvcbFMwku4YRxN7C3BNi
Z7Sm0EkZenN/RUfoTuxxBgV6Ef0O/vpiHcCqkWDr5UN99lm4TYzX4v7SKmMUdv/Uob6l10DUcke3
oyrCYcfqCnRGj3c7eb+wDXy9Dc08t1wvXyNay1IB3Tf2hfa7pgNALUgNwGTHj4AOhDrBGl2eBIQc
gNLd1WzuCqPmljf2SaGOgBFibwA+KbNZa8flsiYLPSAKNKC1y/6890w/BmAInk90fvIFmsVUm4Oc
vOIyICBTzmfVUMjP3X8Bf5h8IsvXan9Mk5T+l/FkqHsa8DWtsC4nK0G0PSEVM90/AW9JHy/5QnYh
2frUVbXk8pItyQBrUflpIeV8iIW46OBpdYLK0jBCvycWsWzy8qirbU1SJNBLKX0t6u1oR+Thz+wr
S/os/fHeGaDidjLSN2RSyPjGR/gY8XcAeQ7+Ye0bVJtcxhJqcd3nKQ1ZUCJksNofpAm6vNQu2ZiQ
qSTI8s9xj0V8QFPNLyHwYdvrrS+aTgL7cI0N06c2vIRvuHGZBwyiSRb91rEDd8YfCO5oXte29LGp
uKcEU3awv2iLrgDGhbANuTOZDl9NCp1XflWpNDz+2RshqUJepyRAmx9XleZlFRovI0PdG+3iPQbY
H08U+9f+7kblZrNndqEikX8N9wI/ldEYkQirhBu0pTc9k273r7BlZ5q5K+2oxKQDHkFzytMCfQc4
CsQiP37DS0BrUWlzCMBiFnOjxD3g6bn9H/2nCR3hUhc9Ew/6iiSU50z5l620IUAwhuO1sdkEluqo
ZkLYqdSetXvNpjC1XRmLEIHL6p53G3BcpuPEr1ZUgPqhBxn5jd85LRXdB+zDCLYkSqMrhn08uO7g
jFQkCrtID+ns1dIR/+BGycKBgpIoXtwzrAeiO3c5L2iRyMLmWKo0ATLiKpdL3nouG2KXOlyPUQFZ
IyFQYu83rmSjDfKA/pRk+ffEOjRIfLRmKwcyXx1XKb4pEQEIqzWbDwkI7G+IMDlx2kPAGyQHyzch
rMmSWIbth2JFG5QubLsRe4E7RSsHd1RQxI3hP8fo3GWZ0/cGv2RqYdNFaW1l0nYcMZE18MYymHy/
UGAkZELUgO93dtPjlYT02NhmNM8xvPVsUoKzgJgdaYbrQfCb/MqwWHxf1tqRF+zfPhOSEXK1+Daa
1qIcxNTvGdzOnM474kynzaU6b2234Xta065KEicKGOxparRVQieVlAs1MRPdLyKwTB1MV/y29+Au
RqJ8sho26XK9IunBYLrcuqu1oGbCrC4u1bCcTj6aDnZM/tZOrheKPCJqrwzrtwaLh5qfZgfITkqo
xkU3fsmzidnCNfKSB4qNdsardhE9xeW4Yg6HnHajfUgFEFX8hRDtMWEEy5O7jkYBOgOtiqfGEk5/
+qSJrB7B0pJd5BLsrCx9wAhO3w089X6eHdQx0q/RqxxqeKnkl1ODCVrV/y5XODnp1fhtRuTw5lAz
PyJ8flcMH6ZPlEj1Q+YdHKhgM89NlqGSRf7YnesNHrcLoEb/RL3l6tsPQXuAwD9VIH3mWAcW9a+t
go5ddbtX7MWWclP2dkgqQIKChsqY8pqr/xPMmMYrPAINaQmeWIb6/459HU2BnBkfSM3nUOhRapzw
SRg+zjEeGWHbeufp/TxjW5TI9wUTPJ6Wr34MRQjdRv0+15UMVT2s3ILLv01kLoi5FY1uGR0ps/4U
qTZ4fVpOfJHaxcvBKvkmmWFddKzg67Xq8n/BPrjsrjNphS36R1DdMmAX1PH9vZbn3gHANUv0I7lu
7jEjaadaLCs6xiA7wTn2z6447+9QVGDduIO7VRzsTPsrTUvXzosjGMdj37nntS9sEtQ7cFy7+myA
0A5ntsBlduJUMhydhxvNanSokoRT5SdY4VVwkjmf07DVZS8dgIe/l0FOdQsDTKMVAoGNwbhFlyLG
xKpIdAaf3F0N6RIERA2r/wYesLsF7wgJtQsJnxQJvgZMhQl9iZcwzDEfFQivtHUl4lZ3812ffnkr
0QgeMs857vq0wRz33znbRjtv6fOnpjcjK5prUTiF2uMnlNabWqR5c6KbHv84Bo4xoEb4FlE/rnvp
XQPuKqObbEseVPXpeBV5XREbXLPlbukK1D/XWWP+MOzgOghgPZ/c4PlV1u6FJoSHw9Lz0stncRkZ
DfpJT22eOTyPNWwv4M04jBRbh8lqmyJioRuo4iWqwgoafPNv9N8=