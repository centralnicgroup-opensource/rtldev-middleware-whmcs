<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtJ53hgqXFEzGGcRcOpRyJhfe41C/NbTiVbMc8dNXPLd5WaNzcwxPOlKnJfhMgc3HKHslymT
Tp2d+enSr7yJUO31r/z3SnsQxBq+uJlwISj7hTRX5rdKUiAapXD4vYEWketI9c/AAX6+X1Nj4Er5
qC+ROIN3jJDAp+WFUbxiQCFWLTqWML+Sm2ypAj/n5MGB37vMheUQYCt/WDIHKu3Iku5rUklJCVLj
l6tQq3q1GUuJReHaRP/MUrTm4Y5SnqXye0xkGrtJ9SjYZNnfss/mhxrXfI6rRWY4Fk0ZXzmwOqft
XkN6JMEE6GYs7/RZPRkeLQ4Q1C476nd1DFjHwW3f1+yByFyJE6UHj1e6vdWZH8e3QgEurF2DNe1d
/lrqEPSlzWe8ciebGVJyiJCo1GsBUwEKkXe7XOV7hy/0obUscTUmUKRh4JRRQYIDVpwRj4vUnwdg
O7R1hqIzpUUYCa4ukg5QuX/Zcp3xU/Ls+HfvIadrh4maMWQyvfgvoyWSXGhUPy1XAhT6lWjGZnfG
952/kMPuTMqu4ANugaegMNpk9z+aA1dInUcn2QNhhjWX3WVImtQyoU+coLykCvITaxunXbqNTB/X
e8pFywtpuIb/YXOY4nZw8JzQxB7lH+QEw9Smv6UOnmh4ryyKle/jhPRY1fy+V5Iyq/htYd9wDTeq
iRrZ21L7jGWzBeewzYq3rrCXuYnyRTvbsNGOlqvT1pAt8Yq9BkXNl/NK9CvJrdi5/LRrS4sC5MJ9
pCHgIdc2Se3cX7nYn2ycmClTE50HxM2W8tC3zWrcAUmqGK3Z26F0KwYDFUDZEGygQQ7lxWSx+HXA
LSJ0Y1JUpOvmk1dVaBbCduEKVZaIYlyBklGK/ChAgTJxVubik5nUo3zsQPnk6cVKoKfj3Bf+u4UK
Bdf0lLCKGP0H6T0uVy8mIK4A88rHtUqDlJRwLQnAv6iP8RVxisvtFqJ9jknPkTgu4Glo+4Az+jTK
vN9Kdlnj2f8sxcSD9GophD74g39UP/k2OOSmPl6ApgH0D5p33/OEvQvOWvcWX8/Cp63z49Y6z6Vk
VACwCFDOXRiQo57Agwc60WvHiNgrn36ZL0R1O2B+STi6+V8SgmvVYpCe3s11f7j29yaX8bcwSS7E
tkPYHjIppdQDjR+/J37cdDtskHPxRkZYCYU26xzqWfxC7YRhR5ovrwH5dg5kMuTnge3xiV1sj+fy
mFsdKBNjCCRaZF/M6V7kbBEG1b9V0zPzb4ewT44KroVfGrjKicYz+vVzMBsOlQ4lFRlDsQye/6Ie
PkoqhnR2Ykz8Wi/rQXV8JVbb+bNgdcIWE31jxVM6xoyanziYrXlT/tFAO2cz22Q+tsnwDaJf0KUJ
UcZGOgs4fjOdkr2B05eaJhH3+4Rkz9l3zPtNxu0GUTMIcBb8UZGvUp6iGww217WwrIimmNBFIgbS
P4gxVQJ67nTMH1gAMr5bESM8atJRzglWRs/5d62bbyApxxZOkBzSb8NXiV2WnZFVCTW8kSOVRKcR
zAIWV91eiq6mzjOOWNh2EoHb7imD1XEmfPt735fyUS+Wb3xStmKexPY6XbEtVYb1jHxo8DZoS95r
IEny21PCk65yNcB3nnDiRFMguamB17AMxU/qFcQLM2AYTrpAp/wbUOUsrAzFhgjxLvvyfISBQdUb
UUbRL9YIaLVQ45+NnZcA51Kg/ny8YBrn07RaozNtNbHA+5hay9AJtYlKPuD4KXeYhngxbAxGzruF
VYosH1Dv0A0TSCzIb7I9BbX8jiUx3esmrFpCDY3HRKs/ffsvxDGla29/cQH6JZiHRy3ucsT3A/uZ
FeCKAwsZZu1boAHT9JU9seN+w+fV3rvNvnMoN+vsscIx5jhbw5vdapQLkwnD3NHnEpC23i2tYkxO
rpdYqS2Jcs2+JUxK7U7zyPKJRcqYq1hYHX6qOKk7pAa+Lj0mO7QKWQ6HIa48cIIfRaesg4UjdOJ9
HYxkL7gvJihehjnqATC5mu1h7CRpebzCtK1uboIj7h41zfw7LabiLYgYUO5yjcGQ3HFT5+zg1WzR
QSnU0rcwI4oyVCXbLtXyDW+4lYBa0xalqVxCd/UpWdWclwXl6+iJyVoVmH5LVL5TVBjb81PK3woj
b1rQ7faUD2KNIrrJU80qVGv3piKCP1YBRDegtOhBGeP11bJv22whS56U1fxzEbsqUsYlaWZrGSGU
6dU1xB6cXZWOIwYwAzSwuCnwODnUjZMSLr3REDzA1eaWrb6m3HzzqGlvQVufglMkm8CNsQzju7ND
ps471S2Plh6HDqJdk7kQypMgjY1yTVCzhrEz+yQr6csewMcKWfM7BlXlbLMMv25qKZs9zHsNOzrg
WD5cmoaX1zOOvITcfnQGYnXn4FcZ5+CP3E7b8ToUikSeTg+g4WYKgtPy5+mBaJCdsDp6eg2A9zzp
PZw+whjw7+J/JMantJ8Ig7yumTxfJr4EE/0O2i9TSR38QLVzDzNUP2uwurzpnCp5j3O6FvMIqtPv
2sBv3pP17+U2zZWVlVOKn/04ZSn0Rn0FoF16ZOewII89l9cKeTwY5ehg/piZNS/gi8knCgIQ6DnD
JVvHrBlY8DzYBkMrYBTB0nIVnzGtobai2HXnTx8nKbVdYPKuKLbpJZFICHrAOJimdxIX9Y24luXu
bmDIB4PU++0jQqHooSPG+iti21D+P9T671jQnpSbSg8U2OGk/0bdGVfgio8+aDSMUkP4HyyMCuOs
v6yF6ECuxP46Zm7UIxdUCJBWohZLSlNf9qvoS1cy2aRiNhcsW6QzpFnqqHez7GDB/wImgC8g