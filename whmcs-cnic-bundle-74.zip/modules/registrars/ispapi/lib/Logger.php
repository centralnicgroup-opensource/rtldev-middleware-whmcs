<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxFB1H9Qd/ub8mEGCJw1Ykj7aErkVo0Cwvgu1SX2nJQkxk2S4k/iZ9ZAKuk04ae/M+rMJwlV
a6+7eGoe074YaWPOkINriOyISyr16qS3zNDZFtIhBcW3z+v/BPvKQbO+/X5EVDuES7c3C+BQ0VHo
T6qdm1rsPoRlYLGQKDaPOT+A40k7Sewfyp5wE2QJZEMwCkUvGxZlIG+GmBcBOunLtgL2BlgtFOGZ
5DQ3zi/TBk9mtlOjlEnE92KaC4DwX1d5/5zGNTCbosADV6dRR/2llM6b8PXbXVMSYE5DfW50DtT6
ZgXXssR01kRj8f3aRcWOSkIpcPMIqY+Pf81lkIOE4k9+4JyzedAv4/txkA2GHH0YoX823SThI3Hp
g9nwiR6Evk5msqHkxpEmKHTeguCRH5EAN/raTUY6UsfQJDYQnEWE2TbUHszG9hRAGQwfvlXcnAMg
AF/ucBJpOEtY4e+Sx3kfuKefpXCaGeBMBAf3SJXCTk075U2mitajE7tMVKjB2VOwnjWdni1271l6
6YF4Q9elhiQZ0J2drnJxuuN849fH1oU5Up9GjfTZbAGJMStnzYJaLEB/FU4C8kLKTLjRYe6VP2Di
5X79TQPBstP8/5SQEizLdMWnJBdE6kXCoMyRGPCAg384KZP7L4UEojh/YjKFvGL/FwCO9i8vUsyg
yC/YTXKiEDhgFR32CEupQ1V10tzl2NMIOlCzKaaRub95Fv95/nF8Hoex87lpw5KqNW2MrWjB13KL
TbIrq1mp04NPNMNg1HkpFnpPqLjXbHf9R19W39aa+7aDThV0ozoYKUNCuKaGGZE+4dx4nGL7sMni
UaxqD7YsGtM6FOT8f3Z6YtGLQu2e6nW+ApJnILDktXBIoWZjROUxmVxc5eXzSiabmf6lCmwLGpK/
LqbB7mvqbF+tyUwMTsjTZ0q5AJxUq8nWOMWqCYXHxAAWSdwDYPlQvSDoaNhnTOi3vMGUvEg6Ns5L
n/gQmzq52E/o06Je53IBL6ygoB68B2I6M4B7AzuCFHzAWH7bUu0eJbcXqBMoXqcvmshANGWTRK2+
XAEu2Vdm//w5b5bnQrBIwPFq29evTiv0d9S2gCoVKfSmAN4kw9IHrRcTLw7MvZQig3M79npd7J1X
XGFvWxkLoM8a3pbRE3DXhTITP4cK8e0VFowB6l3P0f+LagphUlVhYLrd/Ky92vcvX3f7BwALgOcf
FgTfDdz6aGr9NiuqGO1g+fTsvX/UbIiIa/mUIFGxfKQkuRJg+R+LSvJw5zCWsHVtjHxSIMtzfADC
h5MRwlYqFzTvy+fH3NVa0nKWAHXFywheKdppYKKxDlebEukxsfy/Xu+4Luwq+9uV/rBK6aZB+0GT
bSAoyI2Qj0Jkcy0z4EqK/op91zvs+3+3aRFygixPXSbLbBtmEriw5RYffvktvESu5E/rZ1n7PUVA
Uh+3uqzrllwZSpiZ4niKlY9JhP+m8ztAQb4vVLzbfhdc6uZ/gQzkZMMT1CGKXPVzzzn5iTkCS4MD
3iZeJCtNTNJI3o5VEChxT4KDCF8WmdCa4JXkCcYOm6JN6WDDDeTeSvy/RycHfBs6ahjjIVhVuwxD
aDWv1wOe+0bZboheECqt3fwFR+Xgeax4znAS7NLstaQBqccbxow3jWg5spWzfyp/v4DAppZYfzgq
s9H8FZjNUV/+NDYRm5k0N8tlGNqAk3Y5bWE7qztUtvt6BeoOfD9ROqFDWa8ZfZBuTXgdRxNKNPwr
htHrZ+pe+qhQ0tWLYi8NjA8+swWmuk/JBy9k47WI9LNDW+QgBkstOx7LjzZwpny0fsFE8GV7iI1f
4jJBOCC6KCRXUWePJmV8yjS2wkJWkiURaGHr68x52KYIzu9NoORyj/BohXaE2pfYsYZ/ppASY4NL
4Gg9UuuC0m5rWz0QPJNFd7MjJmUCdjQ/CZ4GKXiB+lcQIrHA0dTvuY+U9UiQp//u3u76lLMDsE5+
ptWXKSknIATc2045oj2lrUWocxtUFRwHGw9yiNb2yQ7RK07r4V2dR0rI6zFwpKtB3SPadWMNk1eI
1QnpagAAb6NejYm8WOVFqnxoef1pS2IBi3WzJtWRs4wQIiVT3ihhw60IoUt1+Pen6RJz2fcTUBYW
VtXiDojHrM0T0iA/zNG4gun4Ceufkd0JCha4BaRRNxZDqPZ5zeWeQ/yrIBSu1m+ACQTp9nQaWMzH
9rh3i0+IqpsMd90xdIMaGjzqJEHFRNq0WHWOIcsTjqD+nWjUnj8vN9I91Nenz2tShN9JeJ4JFu3k
i7HcXNrlKaZvM7Z/9HdahsAXTkLCl/I7LHZYgzZcIvQpUkRfrT24biqGYOdwHl2MQvkqbO2wH1bL
RABJix8oG11BRmMiyb4/+yaP2yByxFsS45g41RhfQnDu/+E73jLa0aOAXYcckNNNQ9qAxRnqVufN
tFB4iS0Q35ZeOhIvFqW7aS2VWrXOI3xuquwMnO6XUfTPO+l00mDR5PnTqCB5+HxxxVNWt62Vha+l
5G1CeMQCQJ4j0FJGgYdpK005b7kWrDigQQNQtvnltX/P+5LvVIR1WXRBbcP/DzgRtrwlzvmuvwzh
f4+Of1Yl8Z3RAWJU4ymf7EHeklN8H9rsSYRRoeLL2rlD2oTugGd7BvzPrHDbR9AKnmMuVEIjO7OA
Tz91NCppq7WMGKZ8D0jhz5Z1otMgKtjhpHKkTbET+SQ0KqO1BqZRoxIlSqX7ZsZNmOYftPzD162g
q8HMI6t/LM9v/mjND3t+W6SQfPqp1OVB+iXtWEXrT29pjGHB7uZE0m35i/CmTomYe49et5KU3UiE
nIPGl6CxwRw9l5wGPYi7qK0FeZeYwsOfoX2tLyFeZ3yRvYrO2qsq2gLL1daU6zlc5ZeBLMaTqhI4
pzSgLTvGvXUpTamxaZ2pAT2t+816gc5ZOj+ZCeerJOmcd6HoHlhR0BdzWoaVVG8AckQ0OmKDzXgF
ArFspg7XRoKOvza2D6BiDxCFrmvi1gLljq7nEctKWd/9+UAZbPa43bF1W3WKgz++cQvfHG5FmCod
Nk7M6t0XRKOH5GigArATE3Eb7ns/YkmBKskYapGMTKfjMH7HfripSFqNq+jVdMfWvbNaP9ba9yU/
DgYImntbau6JdpV/bVq21DdX1ehwnu8NRU0jLaSqP/6kmlqnV1QXPTEy+rdFQEPK0Q0k+fvEkBJ6
32C+TkoZgW2QB3D1be2Qs9w+4HfjsSnMR7yRuRPNhNj2MJesIH3/zd0wWvIAMe0eeScfgbyqv6qH
j8+G1G6hctlTq5fKdEJLuZK15fzvEd4BwZDos29i1RXvKOgyAKwxmPxjUsexYp5fkjf5O5MpUlnY
2Rba16OqcgU9NDpIBchBPmFgZLZ8HAYbFkSnXsbR9R9MLCgAqvh5Vur4PckL7/MQ+CcAt/O7KmPk
hwT0AXvb1WlKwiSr/w7qQLsEBHC3TSHok2KtTr/QyeUDHgEqsfyZhq+31QYzhzEZvH8Sop9ryrbh
+yRYH61yjiPymiQI7v23g7laurgz/TZDokZdivB4+VRdAT+9uxWYUW+vd0bMP6iuT92z6U4B6d4T
TOL8mec82y2O8vy59tD2vZxyFZV1Z+0l0LN0+0m1xAvbueO4bB35ZkqPep3hTHzpjF3zk4ECtIBD
OJl0g99va306FdOh4SjvGp/QXiwf55tqTGL5uWqlpCiFI4gElNQ8ozWWy284o6brIZ93mtjE9g1P
NTKwOmPSl9Hne3P4ZzKdJVtF6qVgkb6CZdBm2QTgBfg9uAAccIwVJsI5PjHb7FKkeJHeurH4N6F5
6bIpbbSnlYU2cqoYtSrXZL4uI4ZBoHwBjrtR4cZ4ZMswzFxw6bvtCwZuac1kRxqwvxksEzmB6kZN
RwxgRu5bb6d4VctC+PNaDrSomB4WGvfI8yJEo9hGWM83WBDrOuIM7qbx8YlW3etJCIsXJUsPW0D9
qUiQUQWgIoi5