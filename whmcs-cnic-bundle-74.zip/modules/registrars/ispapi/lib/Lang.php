<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsWPQ/MJo6/xQjN+raDODZ3IO3wmmHAbt9IuPqZhsWOFA6TTNKI6cl4CuC3q/1feIkb8EjGX
B+wJc3Xbts53Woi1YpUnAe/FN8kzk7LD7m5rPBX5a8m7IhNWi0TqVtPTqOGR81nAu6NYhtZ+hQQo
W83Ry9xAYwkvKNYGzOjyTzVjbbDZ39XzgzqggwOi1LUmzumLNT6hjN84sNmlC1auLz4BcvnOykRf
OlaW7yhXkyo7nsCZt822GlrUw5ShYjaXSZiINTCbosADV6dRR/2llM6b8MrhMlO1UKlzSKty7NT6
9WXiCbj/kdKowOlUkvqZKIvmlB0l5L2b6Fs3/+sP3ccwhBW4tofCRTs9/Z9EHBRpu+UDUB/0p7jw
p1AOu+W3eJL30GjlaSwa9fvRjsqQ/5ba9M8C5MZfozLl/eQNzrjFlwWKbO0gatpRrGKv35nzb8UI
zu4rYEyjcQ11TGXbSt0sxfVgPwSBHb854w0uHIFyc3GGMvVKUo3gg0IG2KEXv+CwzSpthZZW9ixY
s0AYSwJLEt1kfWdl0YT4/brRoCiVEmRQoe/jyMgMYTPX9OL+TmNATyM3fi2RfEuY0HR2xGoUiaMS
oCnsNmdAE2r/dQuhgXPYErcBErgXbZhLuhdgCFkvQpMAE7R/td0VYNo60wrutWdoEsZPR/Un0kzJ
zKlOKMzsjfrDXPDmFxhOFMqqkncqRGQCANiZ2eC4fwX9AddB9uMbPUb0IvQXKIqGDHagq2xkYx7a
qLRUAe9iqySZbL/LyoP9YAauccXgMevW62AqtmdqvYL8bhvASA7GMyC93XbyKgIhvdgSbEWleHQS
DYvPpczLDjirz4ILBfcpYvOqyOFB0zl1OBqbknkLbblOMHmwzveT8BTlejR1KYZmS7WSfidBGqHi
Zmu+8GfBQzuB9t558jXuNdY2ESh7EGZHi/69SZe8FZqSGj22TDhcqg9Nb+LGSwhhvRJY1aKs3vCV
wBDmoJx+6YG64q49TWXqhj6vsOOCDct7ZrEgP8bD6P2eCDvgH8fPytRPelQQLasdTVhyPL1WEYvM
BwiDOzcDf8GsG23p8Vaw4fOY4QCTEQfUU3dooOSVMKJVTfq8RUuSJ/PF570pnAL0tQIOSjHReWNG
RCu2AEmOMYvf360qOsjRlt0T1nScfB2283WAYfhdc8o8/5Y9tbm4OidXvYBtWzwjE5frl+2ZYUw+
22wz4+YWKb9LW1JxNdiCeLV2T/F4hNSRw29LGNFyK1TB1O9LYJ9CKsMAPAwDw2Go3oizxMnwCr7L
+uGTNLFzsu2FLm86B+/w5xXwZ4cWgOd9j9k9LfUmD0j2XTFJBh6zuCviaYXxyc+3cLb91jFaS/dc
Qdm5GA8wb/k/IXN+jYvK8CfPcSPGOJA6z/7dO8Ggv2So9Pnw4CE9oFkqiU4qtter1+WqCy2rWDGZ
tVb9fJhHr3kdijs8DIrG9WKkbbxu0H0rc3cvP1k7Xs/4FIqge2wkbztJg/YOblmAGyypCMmOWw2D
NP/rOav5JRdYYgZy6MPHZX/JZDb6NQAO3X8lq5xBdYzdcvma50iY7rh1Gz6uj+c6kp/bbhjbKHF9
qS+ZVf5oLBgulb7g5rRQ+PCdcDx0zOzR/IdBI7JuwyLPTfpPSM9FvB/XXo1H0TaISCxGql9kjW4U
FuQNV0hW774HzH1+f5B/d18j0yLNgrp/CcAxcgmjQPJksvl1gSMeBeR6KHS+nXsquTvs2N69SAFY
TiNR9gwnb/CoxD/OPi8dOsn7nb9i05ppqGlSawCF0W2VhncQ+ohn3Mp2uyhZRJOLo2yK/0GFeMFq
lbAuBmmZBNHIRXXmdxgEYSrimzmQI3TiV0H61lCKuFq7uK3Om+nl2XP2xoZPjH8BF/HFxNhJoaqn
sQhzWJwzSecDRa3X0zdjdiNyn2vQbbIHOYf9ZUfHDtzBx5XuvWaeEM+Vl6y2g2GpCW2htC+3weaD
UhgDn+NZGhndMqyKNK5WepaYJetQvxHlbvF7KU4SQcnfKBx6HTDTP+f9V30+9hXkCFjlMlyK1kph
esGOyix+Xn2Qu/kLTRakQT0tGMo+90TjJU5jjRkyN1K6dQy74vLz/ouVYbEPrVKvAUOdnpV6/Man
O0NW358RYCGiJd9fVon8vGdtceRpY4ilpuC6l79ucAr3s9nl4fvxFQhze156g2JFDj2wxLYveLZL
uJFC8Y8YCdqFPSPoRPOECWnKz4/CpMtna7Uyg0pPBKh2O2MZDUrV0jKPRS0L+ml+fDvvFqqZEv7u
vdVBErm7UaGaaa9mk1gJqzRp0Qi6p/JQnKmrpdIwAV5mVH4PthhO+udw0sdZQVoC/PzEQX4iH/7N
/IOenQMIX3ftdw3FFyHZCjcBxCUx0EWLe5jwLB9HynbxCQww+yxz6ycm/UF4y0YpImmcvkzbDph4
AAPrPztM7Tfs3O2ZejVVwUBl1semrFAfCVGfiOZV3Rkt/20oL7NhnQ88zkRKJOxUOEKfzf571QGO
KqKxftmBhqzx75DU/jgYVsI7SZHYxIWZL6YW9WO4XR/BmnLRLGlYP5WC6rNgHmb65roDzciM2kzU
6SaRWIiXxxSKiFtGYBQLdoHU/t6E6AwQNw8oCE/P+nOIWxgQ0uODzvG5RagudcMabyUJCDvDJJ0V
yFSAmRVjZQc/1PdjrVVSG7t7O7/I7/oD1EtfgXq5J30X5tIbPDpn1iXgrrrVTH+zlCRqP9kKsp8T
DFdt3aWVdf0FNNSloX5uofN0/1DlAbVJ8c6Q4woI/IW1ngmcbE6m