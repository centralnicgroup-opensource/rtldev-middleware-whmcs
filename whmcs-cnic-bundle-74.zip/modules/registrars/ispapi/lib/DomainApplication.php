<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmN/ubH3MG6jT2IDmM3XGekAJ67GO915ig+uqZ/6xgDAIrugwCZ4S9OpFGjJtZ8j9+Fd1dvL
VG6emfEfhLP4mUKhJ8lrq1VK1PNDtBLzEf8s35oOUcIJXb9TjQlEPB/+/5d3GXj7uljn2guQQUTk
s8WW7HLNr4n1FHkkO3rzHCVF62Zf/i2mYg0zmo8JPqPe0PcD8T1xvt+ZvEe2GiHGogqd6xZnKk27
ULgwgYDHdF6ly4he6US8mJUSuqOEdaV3k/SLNTCbosADV6dRR/2llM6b8TDf/+BwsTTW8uRqaXTp
ceWS3RWgR1X3/Y7e0sW+rrASTZGY5+WR+2hizBxVyu+zZ8rRpDkxOV9snqG08d8kJFS9NsCC89Jl
5ywUz4+2wAynNfs5vgRXVL/hh+gUQwAoLdN4hzLksTH60lcJn1WOIEdNGoYvq2h1WvRBT0CDSkZM
dKjIK3GZIHOK0sUV6vVE1pRxpFfar9Bs177GPTlJzQgFRmzONXkrWvDx6AucBaDXBd8obbVq3y36
3yocWW80iTbqCjsvdhVwsFuV0buNryjMv7YEKmKEHZYnfywP71iEptQrlROzsQXGd2G8C4VBsYJm
drWjxJtG2rhcWTKJAMn1194oFGDIToRVNNDCW1AURBeRBtkVLsDBujbmOSb5ZyujYnJpXCRH0Fpk
Oq0XmZa6EFrlIB9attNzD0DCvnleXKM2IuGFMnU6qA2XGg63jDS+jaIpVjpZW7PyFcvfVX/TqCu4
WmW80Sg8+b2Wvi4nCS0Z2hw+l64Q8IderL9tp6Tt9rnXxK2CUrTQr0c6308Fj536jLDKFTanW1w0
okpEwqJneY/ChlVl4H1cizX347vnQ+I4Vevo0KjJwexPnrTShEPFETyJOo3hhT7gvZzLLATG6TCY
mpkJeBdAYjjTKsG1+57knYooJYH53cj+OLDgIvVqAo1VMRG8TUqJmqLvg+Y9xwksg70fpM0fIf3O
VH11IzX1dMcJHKipCoYKgnD7JVymjR60v2I6pbysnCCDrTKvVvlZhzhknaNQM/X7LR80D2ZuD924
HX8xhp1hkmLt2UxUSicLsJd71IkS9lYLmhZsPToFmt4GRQDUaAFE7E0CHcrS7xEftHUJuq2JiF+H
bXj5AGfi6WSXWXyPmku4mJUp9XDY20a2wvFppXBiuN4vm8FHrHkd+m7mI+tBkLOz6U05BrmP7y1X
ed7Udf9QuJbuzUxG1pGTigSYzlm1Map5yhTxuQdLQ4OYiFTJXzQzKjbdiPBMHYCmhUzXkLYIZ1zj
KHF5/dwuNXtXc0ULt02EiUX2NufXZ8fjzDowk+7UsKpbAd1Q48/EsCknZpZWWszx/mk4aS9gpTIK
EZl+h/DxZ5X7WAAf57cA4kwZNnxGvJNKhXyfGUSiSF0rEmF1rFuirXIOz6Pze41Z6vqtYqF+X0Q3
HVFGdtA9R5Tq1FooeT2Y2GxW8E+DPXP43Klw/c+hoiOqDzWL6KGo4SulYca1xS2Ug1wy/daquNQk
4Z7HkseDNAt5X/E717gDNw2ljPoHRTT2ClJXsrZMcVW7wmFhv3N7TCDSCS7Xbi39kxTPXH1h2Tqu
hDd6SyrKt7jCQXoi3Xqdw4lS9yY5wtpDBQqSQ7MDPIVmKqvRuqTo5RVpHA8kaoA4eeybImp04xTn
Dvp4v1Tzy4Y9XSquk05vX8yZab1ETvuFNCnzS2asn7cJVz+nTl0o2Bho7sCaLazgV+p40MZ9XiWY
ia7pAmoYvN+SK295Qr51PXm/a9ikfGWXPCQNhyqxhVELj/xDaqm9sqeXfR8gNiq=