<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmfGhC742XNsaPWvuZzlFObEtOc/WE50FkY3jFKQrChBW4vG7MHJwJIJV1Z0KrwuwFak3noZ
zM6vxNqdH8ysyZHy9leIyIrIc5TqMJe4EgY87Xpn8MCBeiRl5bsMNPzKq7eQnlad9vpjgwfwHWZU
Q21/HPtw1CKYI9QTbjbLxwKngzWOaZwi+5wFJSfF8/LOX2e2FYo9nsg3yZBBgnQnD5Wa/fmwkdXX
jI1/R8U+cmgCkYbxYxTN5BZxgiqMpdCTTsvOTLtJ9SjYZNnfss/mhxrXfI43PrM2yX8j1F6TTw7N
Kam74nH+RGkHQFLHo3FzCfI8JHo+EiZp+9CA0k2+In1ZMM6DfvSTc/qx25PiqUqgZB9uL5dTRp06
QPi3FvAySzvpKjHo7q8mCaFBx+k1HzQTmC9QyAAsAPWjbnDOAfNaNtKxCvc3+ConLYP/WoaZrJeH
dTAUQjJ/qf+nOjqDPOWPKkiS7Z8Dpk9DsG8OsswaTxlQcS2mrPX/glV4fVwVcQizlgel1RCfguFx
v+Qu1Ftb5nZdLv31ErmvVWqBrHa/g+bgB5bKHmiEXqf1tNkc16EkjJiXaxNr27epG6eadkEtvqnt
q6GoBQ06wnhhSaFLB+IAwLQl89rntdPUnuBbGWaChRg5Uu2b3VHu845Gw4jr4PY+lSV4IxBhTD3s
jTiSHwSrz/fK8ZIs5rMFcBuHth2WgFdf0cgZPLwxquh9IIpqZGBMMnL6TOZ24JY2tc2LqdtilPkL
ht61fmg3zrMKZ12Y2ph+mQcc76WVfmbUutJ6rClSPVLEIIOxofYYdnIUZzXiOEi8wGHHlN/xtwBO
2Cn0J35RA2cYOHMXZ4M5HN+Sd2R3a1WZ/YqVL4Ps4RejNxn54Z47SUNHOJ6iE1XfxF/Ui50Qj+0S
gBPMVvsxDpT34ZKqMYQqwGpCLaCmi0UpBkT2OBYKrvuEswmsEepRDzbbo/xoc/m/N0yflIrf+vNJ
MlubTFLwf0z5cryV4KePjejSATjQdzYqIkqsnrKOV+90XebkSalnkeepHY7WMqg94+Pdb+SEhQfb
GcU1LCmvj/I6VavEGPr9oTpEXHQ6It/39gSra2/F7vvr8FB3qkBUIkpopt7hXeqXVUxzg7Fg+o8j
lC4MgMxGTvgEb+rPIkijoLxfpm1/pFmGHn3DDOdoKCp3ix2T+YBwlMR0DhYJsicgypXGjFbRJ8FX
PA028d/UXF/lgEwOag/NT7pPBAIklIzwloBxtdzoEPGFkhLfbnIlX7Y4WcnpoxdIkaJt14SFvNtW
aN7zAb88q5UPu9yOKh3EDHRE2VRBzXASSRi/lhg3TBjqI3099Xz+h0iRo7h8y/QSNgoUjDDkFzOJ
xduoDOWb/whisjdHbgT34pZ70z3JOfq9q+eTb2pitszT8zhx4XGMZze+gzJfZXutrqH4D0Zw+3Kt
/tLnXUZ5WptUpaX5NNsMhhySqgJv6yIFsUXl88499ZKHThBEE8qtGFFrvrcuS1s0gVaSAXcfA+QU
bSFymJ1OmJgvvrPl83Vt1HFoaPAbUVbSKd0aJxH0g3bEjiQYGeoAyIdwLGltq1Q1obuYdf0AKjeV
svmaOitZYJG9oAgE2JIRzYSa8pchuVZ6RXwlis56IMaUKi7RU06WgD/2abrZ8CApJ277cd7TCvEy
oOjFO/cV86DWZdLZ4Q2NYNK5UkqwJlfh/mturCcwzb47UX+HCCtWp3uiNTTLiTIouFJcXFbCQnCr
g0eTSgHYoXVe7zFl3c4ZhxAFhJwRc8effrlCH2YR9dvbGHbGAx0bgYpWjtyRucKJVtm5rr3n2y+g
xVH09srAd7yVpsWisc53d08JMkzcAyC/oIoHjzDxs9z0/2rI43IFqWhCSoampcoQfLu0cA5j1CDo
sa1QzVuBrVpnz4mkrQkmJoyvoEk3NRbEullq+aFmdKm5Xro1gWITLUsy//NRgbZFank73gcV89wB
XPbxRxiHocCDofNw0FOPLZfGuCMIjLRfs9OqXb6Cmoyo7zvy8HGfipbDP40cFkSUJG8UCIp/tmLw
3m2ZXDQybd/oNnnYwqFrjyZhh0MCLBUlW5a2rQufcibOrdt0QkgmQG8+P/gEraALt84MQSPOoORd
j2C8lgdegO1nH5JrezBeC/3yC1+3oScWsybmay4OyOiESVP01AVyOiwN0iwg8pFnMsPi+eu0s+Xe
k2ywO4L03et738PE+kkT42qlIxANac+jKHFsYJjS/feuPVq6z+k16ur2h5eaKTv7nc6PlCvVtyZP
GUMfGeCtrcByXA8JyxFfnNraokXNoA5twyfIBO+faPB/YlzD7vFBieKMYO6pfSy3GQai1v9X06G+
aXMwvqvC9eSDHE8c8FsbtHKk4xcum/2pQM2sXet4phbRXn92TTW+2JDKsCDJeCyRl7Il3qt/r7QN
7MeGc9WEsI96c/l5qDCpJ1BfcEsZT+2ZfJymANDsqRz0h0OEPLwDlb5VZfuk0fo0Dx+3VBuKav5O
QVHAj7pHV5+91saDvsZfgfCNHp547Goq3ObdQInhtfRfe2hKQFi+SSWNcAkQ0gfaiL493FBxRm2D
vVRMQuOAdMm8Z5UGQ5coludkUMCT2Hr+yP2EYeMVAnYH6GzovqeEFGbepC7TSN1mUDWd4yUU2sfx
v/L8hdYrjvjvttM3MSF+D0ExlAtbKoYtql8EyZ1RQrlNLwIVvOY+ceI5r0ARx3JnIP6QAyUo50BO
uptu5404/+/RufTMyp4+cHKamtCa+H2X9f0KqSk8rYfHjNXq1YUFW+HzwaAb3zx1wwfzhYRShtkB
lNCxyu1mIEsZn+NWUQH8o+kt1+0+ouVe2wCLHqNRBV/J8nVpghEXPrGBN+LfhYLkEjP2iAe+3JZh
l6tuLmZwTeGL6ivwOT9pYkdxeK6aU3tRNxxhmI+BjqoXJf2unylEmnIIoRVqktNMSnMv60A8xdtc
NO6lfXgSQ60gCQjmznlYEdGYm9eOBWMOgd0mKa+/GHa7oEV2aYLTFkecM1FLuIhhTOIITvJRvJ/p
mI9LGVnLzDXSv34Wt4DqCFl4Ke9+yL97PM9xDP53jHwDPoUDNuo/uXPJnlIPyZbJhrA8EeExNuAZ
C2e6+My/oecmqGBAAj2XbATy4S/YhvrDblxwGqhgNG0iiksQD4XbQuTaeiaiz+F8MpJaiZhIWo9k
i9q/GACDC+/LK7znED50obEYZ7rxjvAwzsvVGl7JGP+IsM+zN4opaBrw5P6DXxa3axl+t3Zmu5JE
pW/IxrGcXrOTLTDHwesD2hLzLDiXMovzaKxeqDaZw/4kUmrxz6Qy4+Pj13F3O6cKwAxLr/qfgW/3
+n1Wi9Gmf4JFqcZz1f8BRKdyOTaoSfGFSWqefyh5WDaCrqFqQsITSrOGl1lGcCxme+hipTl/WoAv
dfOBA0fc9TEiJvpeQVdsKV/npC6PFTuW4dQ/mpGcJ/cBDJ6ZHWk/R6XWyXqdSIWa76lXz1vCjJNd
HowBcC+WZpAVL6BlYBHuWhZRCDxPKCh/cpCkkqO+xmVMln9Hovp9YbWXi8vYHUNQ/Bek8M5vv9l7
ymogyrhDHauHQd55ne8mckZInKX95p7NFYnKGvmSu4HuRa8wAFPKRvmIWoqbDfjcqXuSLKafIVs4
FGZkzdqHJ4gzqrMLrwQFcNMQfysi7hOd2GmhJQXxQ+etpFNF2jS/fQupM3IYE07PO5iIFcyPEAmv
zAIEvliKnoiLUm2NcSRqc92u6OiLxA4QD3QKZhhEYutxdiqMdF5U3IZwQcG8UAvi+CV36Tuga1q5
kwKtgv4TFW9pdT+88uPV2Mb/pNMs5UeqY11KtJDy39EqGKP+x+l2tVPxcOgdwUNka1H60M9nOCIc
YUFmDyh7OqjKXOJ6CqLVuwrvPIxW8mXy3nRdnSPgYfbgdrmPai5vLQqtOOIFAI2/EnX8qwZZP3gS
