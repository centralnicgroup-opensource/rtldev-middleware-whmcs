<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpjRrXCg3oiaCvD3CBX3WynV8nqxjsmszTYCbY/VfCItUa+ZSoGMvqrSv5fcxKy988qk2HOC
pypGzsxdhnlaZRFBz32pgYW4jhH9Rc6Ow7NSaEAUVs4bpnD8NiY0ljRXLTDcm89KGz/hviOfvIt+
zg4hhjze4SJfE+3jxq34hco5/X2kJV9EzvCwxNm4LQ7ckPEjifzmLEZQq9FK5UD0uHtpyWYufg7o
8MKzSNP8puZOreD1J6x9SR0XnVoxOeS1tYEop/Wke4Atj9m93Ff8k2SAjAxqxt0q/CDQ7jE3lLj9
TeOQ1X4rO6WlgH/FIDvQ3FXJdTPjBGzK4ZBajqfL8mF2BVqSwmlFS/9PAmccYPtQRrbrA1kA/cEt
D/MHjKojtd6TKbHEi3A7gDEaDBJBG6oJSl7xBjaD+16dI+l0d6Bx8wXNmDUxKsV62jM1yCPmCkhV
w1TNjDviyb4rX1Ckn52v4P8FYhg1y/bpHZi+2VSSAM6klzhMQADQUsE2IxDTetRX2Xg24Sm0JmIL
dFaV5dT0NtW2o3PbwTAWV7dQhh5GpfbTdyp/rM+/njWA8ek/oXACO1GILD6+jNJ4JbY56xtyyW9c
CAWMeSkc6l+Cy2yJ3wNcMT/H8jS859/2o8wCDY+WxuyKDmSbVF4vmWtXLm/Bu+MdVW+4Ff/tpnVM
pOgNxoRli2/YojfYRXkyfZ/42P51/5PWdbklmvG4M+3z6am7XXsaYb9u/qe90uR5ucGdPNQ/A682
7qFYciKJCyjLAkVTyU5FLaOqPFcF7I3q84nVzQ3Vf0V+JU7rR2kR9Oe84eMIkxXxDjSGee8niQwy
p1XF77mV7j+v7KMNPiKddqZ0380SBUXIxtN8RFL8AQlHM8/5qOSfEFRytnZfEhXBefi1mSE7OfjZ
iZ8zOATImpXQdVjMmE9BPp2+LGZreuBECNVtc/1VPYnM8iiYuk+MDh9a6dlQX5G73Ji7lLlHMA/4
mcXS/hbsC4+RK0Z53Ht3pFKBxa0s5GCMkaEOcc7/f6L/NJ+EMHceV0KEa0ZJOIgbH1lFeRqeI0ss
YhURYhctwMEOy5Q3/n7ovXESYnecm6B1eYJwYWuOX+jDojNpAn+Kb1VAOasqrQP81PUG9XobuNe5
N1pIWXYWNoNLbneQ2iBUxzPn7YQFmaESz1xSUdTCz2W67vKZn+Z5e/3nCi1+Mx5D9tAfjokGd6RW
qubKHQ0dlxIShKhAgRkG0hCAbKd3xEgNRUJ0OjBoiivMtUMDpcM1hTCQ5ZWsJJZVgjwA1hmi3C0H
lJCplhPwlYT5SvKT1L5t+KVtrwYezHEaKiRchyYBxs0G43hdTROYDGQ8LyT8l2HRool/lVuCiq9Z
hBKgJQtOEZwrzhdI07Rmv9ghelqJQUKm7Ee3AxnQVbWiESh/5w2pc0zCIe/LT3bIw+B4CKuoV0PF
m2je1MPEcDpZlX6sAs05DgG5PAdIUI0Ho9J4u1gfVgJJY37yQXj7g6BwS9yhZYT3ywu0W+umDa22
clxKgkQdDKKBFSfZsNAKGy2TChbz+IMoQNsLlYupeRes1pqEV857eO0si+1/P6DVSx2MRWQVOp4P
V5PJG+ecFSqu2bCJxbzjDybOXQ/w5XURTUsuPRVe1Tug4NV2GOwaBYye4iEN9MV3oL0BKXq/X0Zq
RMOjDSzfVlhl35Pjd+0rJhqlwHcNBEkuPBlY5sBkft1MbjY9zR75GwqXVDmvyNVft5SK/cJftzva
c9pnsXBTQwOPefdHJysGRHmpi9Mqi0V5I+m3vWEmXhBb+mCYylkh0vZGGbfyARAuvD60GzDE4g19
AAISc8g/qMd9luocmbQL5iVfqu2l99ddC+kBviLIeldoCVZmB4DREROk2BYvY4F6N4ZCv/N+Ymqe
HZKdq7vhX3EolC0AiiSp3qdff+0qN6l023leO1mmvPk/s35+ox4/b74T5KEcALPrZnswuI7s+8Yz
2QOnQd63zVgcXP4LRiIZzlk8EZYnNYCs0+rMtPBzZ4LC2JZas7tSg2G5u8nE2GaDABzxQggIl/TO
EwIulSVjrVBinNmGuMiMsoZtLrg8WqBfMX2qGNM7P2Mff2yeYAoU/8WFjNjhjqKm6x+ktZWVTIL4
V03nAG51YIXtmg7KTmIcPvDG7p2R/1PYj8Cah28OUy1Q/QSug/04Z5JSlmE6FbUpsAI8DAByILsQ
86GIlmMeCTouJfVjwYp0OxKNPL67gWpdqXu8BNbu15ps5jTRlZUuiv8nahnjevEN5NVP0H/OygXG
Xla0Gxgw+GcfOn4MBF54kQcHsLLLpQXuByE+BU1XMbTaqJKdU23rTYb1ZGlfuesObwjUiQ2FbF+B
FmlQ4noO8NiptcC1/ETnvn4lKpQFzAun2U7hccN9eMnCM/yAlqxt0tae109iTEXpfO0ccuQkQE3N
ZUnpCiAvY5dvd44TCf6piBDfQ+PaAoEQ+nu10N4UhO2YGKAQ4edkTna5Y5mpeAk+b0D26s4ppVek
qgvG3hJ6DC0//U4SAP+IYvh/gj7MmvTXvNTPbuAcjjjbfE2zNPd4azKaVShWRDtF52sctJY9QxKF
f10bes4wI8mIPrwynXU9B3h3zab0vBoQ+IHFA5gPtUyODZf9c8SslRMAEU2XsWxcAinwYbXaalmc
Js9OeLTEj7JwPs7ESFCoiAXTWU09sCZj9CNi9Y7qRCxP+dOHr1uu67gTDzFumYih4WETIVe58uYT
s/DeGUn3I23VHTg6SwsnIO49ng2/O7UWuq6fjZl7QhnWYGwdKhC1bhSwOdx+W+PWwA9Il6Igg0i5
VtUq69gyzyX3sy4746FH4lqoOe0OsuCrAhPepAwHdQ9GxRcfmG7NIOG9O707t+oxDWF8/a5jJp3H
FSIMbrt3sI5T5zerYiMSOjH4jPoO/VvD5+3+el8gy7TvJ9WeaXjU5E1h4Wq6DgwOFUK7+OoyDTX/
yw8iRDJEyqrVyauzhRm2mnaCknSY2Fy/p2urMyCA2ayRdW7rvtXiTGECDHviTDH1ZsAfiwN7EZzC
reeVBL3XwGQuEeMSl+QTrp8X5szkGyQfZXNltYGJ9eNQtN/yAIzz8i0SAav8mjyJWdDacbWIRJWc
61apGLrew/7mkW4J6iuNtsZGO5pNt7nh0w+srd0WKnXMqlL9qIBDcG4DADCDpOrm3Pg/dagx0av1
kN/dTpFWDXinwSiGJucDboJRzOZJxhFsjTwyBNg3k1vQQ4TdOZ4dvgUi9mQmPXWqMeMFqauNKhOl
LQe+bpBx/RpmHeu9NBoT3cGO/isEr6ff9rjfRCk/Z9Vze3x5/WQo9icELFeVxzrRBBnRyON8dWVw
J8PI3SwoROLjy0Cs+quPgn2+15m0fpyRRYHn92S2NcRJwg2w/wZwhrSXns4HeaZ35W6EpZx87uFL
zTnWGvke920C6yRKNIPH1QUdS+y8Z4T8YQmGxHQAVnvTgsCdvVk60+VQ7OjJ2//PrMkOmfRd1i0C
NK4n71lg5m7fcI/ohP5Fvsyz4PJtUWgkNzpgAN5IHjwcGVvw3I1O63SkkujONbbpQszbjX8VCFi3
4wGmdMQwsh1mdcDLmOKvSTBg3mHTZfHoV8dE1qf5inlBripx3oOMpl7j10KvMgzBUgLPhK3hZvso
DwKlMy+d+Xwnu7S2iON8DbV8JZYR+MnJ96oKTMErayF4t7SLJij+TVXOWJN3jzDbaAdqoevvSvgg
ei/5nFCUKOFfVAgQ4xC+GmL45SAlqVrjf4ISLVZM88i5C+xbOq1SDS+6l9QeUUnL/s1QmD60vmx/
QAZMwzMUcnoKawyz9J5PE8pLBX8nftHcvJQjlrfutNYdUqXaVMSNoQVmqo8wDwU2IjCMVreKq/YF
aVzeBdwV3+1CI364zbd7JP5ocxNTeHkcCp2jQUeOAsXHBPPYfxuv8+MBJbGeB8r/C3367EdWXtB2
OjbmZ1AHbG/20IF8w37daYhbzjvU2LEMDHwIAp/ZG11wOaoQh2fq9rM87zGcIpr2sRaH6I9H3hk5
RWLdEcSwNws9bs5GeOYtDNv90kw/1rmvZktPXE+KownUXpjEHbsb1mr6gfifEIcoOZYbhUY+UiUo
L2K4Ugo3VBmSimLpq330r0gUQ6K5JQFgnLAz28GVNm==