<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn2CJoDvNhGK14JQ00yV6oRwyhRwM9znGkQTcukyx6kkkO6sIjhiHQMTCjxTQR3q7KNb31ok
DovDlrjY+im5eaEGKrKcus5tKlVtXnb7B7DYHenYO3blxLpN+q/GuQy08/eIN9WJ70HzT/1DsYEI
p9YCLboQMg9POu2X0CWM7rYnM0aT4aIAoRxhiWnv/VrSqr/4belpr8Ri6+amMspMJYeKJpQxGHmX
iW4mulxRPv9cnzUT3BVxphSQDt6X5XTtjaGS0+83W26flQhBka+iHnnQeGdJP3a7CfOA0pwemBkf
0EL7TkJrtJ5y3n9POPt2W40cbPIq5rf88rxDkI2w850bMAS2Ax/rA1tTn1bDag+9+uHEE86guR+R
vlTvG6/IHY3qbw+pwzK3W4F1IHE2Q1f4YhsGGT1zBT8OAe51NhGOVYxYv1khfm8RGtpEMaffN2S8
/+whcisK+n72O1ttfeFB4Nn3N1TxiBG562Flo56ft9/jO1Km2nPEx6U4xCMfzzOCIyG3th/zyJ1J
aWzuZ7UK2PtKtn45hd6mSPdtap3ecmmI4YN4U1rhxRZD9EflI8KjdYYfiEPjyEYb5r0deRoGvQTD
AVdTiB6M20WQnaIGjHXrM9przIOHkcXPQ9ITkiIzBMXHbX53AsjR2JAdVq+5JUedUbZFTZH+TZLE
binoHq/rKwv19jWJtatPYuT0Y62NRH6396xJfK02DlBjkWPmeXg9I2zXYiJ0xH2TFscDKNjF6brB
CPkvsp3sQLKx40C0tM2NsGeNGLH1u9Cxdku7qTqBxqlWEJN8kswimMc93fNFkMMgYUKVWD8Ptf9Z
68zD/n1ebQaXQXTTNybvg13erMgaSx8Ox68Xx3AKh6p2ty2UMePPHCQTzHf2fSYErH3z8Qgl2Ukm
9f0vREpWwGTN4UDvOOZSTGDViOhSGVL1l8FSUF6yH0oI37lF3PHfLb4QjcIdiFDFeOO98t0jj9U4
aG5CaprkpSE2NpDCBHTF5L3KalBthWIadK7t4lp9/iPz3+ceOBxkLgn9T9ffOV/nfpgorFvF3m4L
FMw4DcJD+QG+jkRNhOdvLKdNklzZ9ee4H3yq9UOjk9EkEB9+NRFLGEZQmjeKRXZnOJSzuAZ3qMgE
7co4PlO8IQtD1a7L3e+HLbI8SEMnGBZSMiJYhyFGOKpH5Nnet2/habwjpQhsxTnj3SVV6NxIZLxx
WdGMypUGKlPSkXM122Kl4Yx0AOqIcdFKE6w56l2KOqRLJ+ySIrB4IrDNfHUcVjGje9wZV5ShVwwb
bhsNuXaIu8vWMNM3xFoRjY+D9iYmNiRVjxlXHDjuWfk5fNMN69lAQZZ42cUtvLvmSG/KYpzYcCta
9pTFefQnaBv2y5cfZObmvnG5LwuKhKz9mAxXyy8lFMI9MBAJz/qLs0sG4RaWoxchN+MZ7/UiGh4F
UGliRVWmXX929cfNKqvCfKcJ3VqB7FxJmRS9eVgLzTBYYir2bnXTDlme1kRxFL3VfLu2qgnSspOX
IWl4dAb7RU8VW1mC89LBJDjVUrIEKnBYvD180XG4EbVbNpzUsHO54HvZxCCntqfyrCIX8xNUlbcZ
oWDA35LypEvpBMi7HlfhEx8AG+MPW457BwoWoiSSrQz26blfVHuLYyanuYy4+2BZipxx/R/QZ1/U
1ISrzsk37mtHeeBadWwpfGXD/xi9TYLVeuc3xYCsJnAt9hGo+DRuQ9/z01LGWcMJObJjFnd7pmmd
lu25OKHAKdiqZPc7RsAgafDtqQPv+5RajPtWkJbZOaSLY2s9FT6rtefolzhHfPRRyFAnC46TeILy
rG5867jDI0lij/jtk6NhQMmqu0l8phVY+RgImllxOCEXl3Ix6a6jDxQSC4qShYgI8wRVp53/d+cc
euy1uQKw4bnnCgKJ0ai9PiylvHMhctBODd/2t1O8+RJ2nKn3ne21RBJB1xzR+iWvoUcdoCNROJrk
I8oPKLkzDSbuDIhAmsZZLzUv/Rndo/QHKkFN+xWARdBLeAT59mo6Q3tt9IdEgXF/qcy8i9sFKzME
70WoTNbcLlKFZhe2NAgyH1jFmnt3O1IWFUY3MijBwEcvcILk82oDaclN/us3dWLrkLGTSRy3Dazn
z7To0YHch9wqotpDjOpzXs+8RT8MhUcNJ5RtEJD2jay09ZrSFeMkclHJswQfvIjRw2R4XHVkHF7Z
4tFqmSnN4ZcFVol8WXDZ9QiwOsZMFOdLxbSwkkxUv/LV8/ejZnXdLkuFHA7wiTNoNpHbPOuSHG3L
wywNfwIxGVGA9jaJcS2RaDkphwAZyVLBF+FeA0b2LY6Vcfv1CxihZjfo/54tkh9OmIAKpIyR1Jlr
4X7yh2RWdX8AAepaamXRo32E0Ce4C8T12/LF3f7MFLiwXgWZHNFz+GsusNur5cvjR74kxX7ZAzRM
5YgbqL/Mo3K5KZ+/+V7R1Mjd71VpPu44ccZkYwdg+QnOzVsS+Lna4VxuZ88bscPIOzoSpNsbhPZ1
02db3cw+dFna9Z4b+VxcutkmVyl+IHPAXUJHTKT9Nyptle3TWh9xP8RcQsA1SCvpuIA0Z+9dq5e/
XERJHEUVnU8ba9m0Yo1s/sW9lOE0N8gVRI99ORpTv/ICwguoBd2uESvX+ZkkjcTyAOpPWCSBD8wZ
azhJUlYOkQUBZZkiPJxYOJVTX3DRZyCFFbepviARVr0QssRBwjYqCr/FmN9d3Af6vLGfQ69K1MTl
Dr2D3R0V4slsxLpN3M5YM/jWLXYc75K/zTpR46iDTBwtyGE+O23pdDD/Bf6H0Qu2ESQUJci5fC9t
50h5+lpatVJCa8tK4vHEaN5GMeYLK4kA0ewpz3bOdA0Pa1R18PmVwBasYIr4SpL1LXNdbPvPxjhf
fL/chgvtfr3djq2UdEID5hwHltkS/wiLQEMcWhVVyGDblpZTQghosKgvNBN3j23KsQ+aSCesRx6o
sjd+BTvWhuiUDShTDQG4ZOqwsvICYWtvmSBXjMDO+gCDJCJj94b/uNVFvevVDEQ497mYPaZPrUME
KSVzc8qXZLb0/AHCdDsD4g1WCwzscNFBbm1Rx7sTiIXlLe+ULLYMlWsgZkdGXAkVS0woegEtbeV3
y2rVygaO34kuUIeMhKieAx0GySRL85Y12nDVWYpDACtCa8DeDRch3N4OHa7Cbs/oDHrGrcM1+rRv
86BvC5FCUVlDvQoPHziNeE3CmpeLoZ4NXwXOOXrMxOYVlvuZtaQ2GY5GAiygCa66tEyVXVJGpNKc
tqj0Ehlk/cqZeD42gXNqpvtQ4M236brMALfxgVtMfkZqiNAb48xo8XeFbXBPyYjqg/hva1MteLsq
v9q9OaMkUiVCzrqpLL23YSBa8VIEb8DInGwS0cetkAqZelJiyIHgTth+3VP+MWA/anWrnqDoVtQQ
c/EHIsl/ftUnkIdlGGVv1g3lgG/bqdMFpHv/lOcDJAr8GSEvVkuh8Pc0vHgBoaIhsoU6g/Xnn3yu
chUcCjkMLkIcVqkTvMg1xRoxMeOsmzfexxqcqGC7wfn4UJuGcFVk/c5koGClnoxMw7ZCc3K8hbu+
64DJyWubMGi3Y+Uh7jhr2H4SkUAx6LRI285nMJxgkKfsXDzBlHbxgig8ROyFuSpN263b+1xn73A7
uLTmjxlph2+Y7ySvQabnLHfjQZPYi3wfWTsPyLpb4tpZEKTlxjDNMxSQe2WMtD2X8c0N94uGNfPc
LOWav0qmfVSdLWMPG2Aap6TaowvzO/SDyUo+bkOBLwAtL/ypjc6iO/LrzavQJDq1y2bmJmfoFh1N
r/nCnYMzHAuDS/FCDVSmc6O3De4QxCPC5npRErsOIb6x1TrplIySP9f9i23BgDdgWTCjH4YipQYx
3kx5fjI26J7Sp1JvaqfK1iGM3upCbmBA6i8vgOUjNcMiLqAEhloD87hIuDO07quCQ6opRvUOXTcy
kOsywuHMIp4/pUPqMd43Izm8mJN1uk33yTV3XylVV2D7nMXb4vcWYoy0pMAGFM6EAYkPfNPmDoI2
TDnPJxNFTVv9ahnQYGhdAH6d/22glvh3btsx2yFSZcde9HSOJt2cdkRVIBBRYZHEsKagmDDXOvb0
g7CNWpK70jC2XxzD0OEqfw9DFm==