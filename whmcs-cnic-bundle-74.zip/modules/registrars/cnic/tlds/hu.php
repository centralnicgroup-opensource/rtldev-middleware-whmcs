<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtreFb2Vje9dPjkhSwIWfI0tatsYe+nbcxkuqOWEiUL1STZ/0UDEXUKgBHZ5Gn9Ja/T/VN3h
ip0H2LsnrBPHEICS5X687y4H2ugd+ma16Rfpv6XVJm7AAw/FRV6+TGmbK/56OOcE36Ca5cXv4lTr
85hgXyMWol67GCp9O90HbZGQf+GdaxnkZc+WSArX34KSedmludINUntgV9JGcYg/C6Q6xvN64LTA
PKZzzX0fzGCNxeCts7doAR3Bd1eAtGZqu6+cuWE08QczgikwJwn775gX2Qza9tOeSYHlleYH3gdW
P2PPBvsiD0CQgKbygUFe2kJ/zUthLxH+x/SaTcNyY+dM7kDOnBMdvarWmcRE58l+6T9PcIGhgtMa
o23Z1DjCLWLnz35XQAV/tLQ/cZt7c69gudO4gqp3yxUycKWXlraYxtN3cUqhpOBVgh8TKFWiHWvk
5HiGOogwzSGF+YlsC5OdcTDbE1mNjIfVEx6hR40YKq/OzSmxtlh45L1rReych9hMOtDNfLPhh+sC
+ylbHnUDLZOGyZZVeBW+kdd8ZTUbj0WTY1GhQzBr7JssrQuFK+KwsFq31L6AW9yS9/pEed0XGel3
0oESaKUsRk+Re+i1oFjx0JfhcRoR/tUbIdZy+seBJOepSuODrIOfXFQ6Qaru1Al+Pfkh8RPeTlfk
IQrIpB7B6oPNXcd8cVv4K9l5zI793/A6Z71Jek/SSXseBp68lmmHa/NGg3U0E1CJ0/nPjBrEV9Yj
ZiwMEih7kVkGz+R1d0UffyyEmQDdRegleEK2JhoNXXwmIe2W/x8IFKL1AZxoNSxJnosDWR6Gcp+1
eQkGQJYy7sn3WOs/8ojVpVuUWERM3YRtkHcNs9OYjK145Ku32kxPk+LyrhTBIJO2xkcvQ+/AddNH
tPXG+wcZED7yKKaF/UEZOxX8/e0lbTbzWbLgihQTa5lw7ayZt2INR1S2D7jdmfgQnUEMcWPA2+o6
7Q649VfGUvAcs9CJPSL+2XjMjUcfMTvgt2WxL7Oiy3vPbWcpqjuOGmKM+xkA5KG2M3g4KpxWhQSQ
81IhnUJg+1Qg7jxf5kFCD+vjVDNvNjJI37xYqj8xUrX3G4ZGBjEIimZ7qy+JaxDT5FA6Zjism/NV
UC9kNbSC+xLRVAM1tGD7FW/pPEprTJeEBlfYuUBWiXqw1nRJ8hne2d24n7GPSzmqG/huCfn0jl8c
QwS48LMzJHNAVfjsEr/ZKTeTGe6xHCyurM0to4w5V8xx/8KNkSV3UlJe1fj4rG7yAz2nkKAv9Jgs
1nOBouImLWUVdq/jW7lS/MqwDg28HZI93kvpZ0OG9XOTvtVTlGO1q76Q6VlRYAamaZCNHgpBfgQ5
Ke0qA6Ehru4dRlGF9t9k92O82IziMKPmy69urFNur3JWOVHmoMTphCIc8MbfguQYAEoQ6De7tRmq
BzKFSy2bnC6NgrAuK3Fo8BmbCfP78+2ZuctPIp+OqPExnTu24H3K7psJM4CdRbFT77z1voyrCv/8
sWcarbiWybBJR4TUe4+8ImZ827Cxd2ZhEkzPZ/IMHLfNB+9Dy8IFKnIbjPk83pQUXKG98FniCgxW
G9FmoNDz0KGGtdXjcQt4jwCg2JzG6H3djQiC3X8wuPn5bs7cOcPvY0Wa8CvW7OZoqhbJFcH8JbC/
4MWDnBdI6nvlAGnVJbC+ts+C1aC1577UpXkWe9/tgEoWigOrHvBTMrvgZLJRlEUO325Ke8EUGJc/
ZSVMykvoqR0iEJVYzvMurKkqFGCSkY9pLWAyfSmBOzVvIpUvO1ndjrBFPytET7Qj/BYz/37TJQek
D70bLQhHW8TMJU6SdMFKMVRqZ9LGyVnnkY1ScQcdp9IXUOLvGnaa0A8Ujon+Bo5u7nZvyxR/ogB7
dnVYJ6atNsO0AUJ8BUiIEfi+ObuIKSYdgOG5oBoz+OJB+GqQ+CNW2K4+VHb8W50fQsXFEIJg+qiw
/BVI5sAEu9iS8MqaybJg3hLmEghEJGVTcX6A5bV7Lt9xlP1a2ALwPillkUV2v0sXH4TXTkjJt9fR
MV+pBAo4MLQkDhqez3c0ZBz2+Sb6VfNo2cmpapJD89mXCjCpACs8pEU80hOgH71T2M0POApdnSV5
g+llHd6pQoatFneHJYkwIny89SUdYXvlL8uGfjdvyNSGlrs+yaZgmJfn+nPSgdZzz7uaQ2/1bhL5
wIeiYKmxFVC7eSpv4uhSGse5Qwv7UbpLe4GZ24tbLOJ0AswsYo3wqYRVC0Lw+/UBChQyXr8ZQKiW
b0attoXoufWOrpBYPYqr4VCjbupTaHOebNuH9wkDku8UBq4ihtyfll6cTq0/l6Xo8y9MVJ0zJ6iJ
PMzmVAqmZp7iv7JnSF9rnzxY+JdCetJPJVl0KqKu2HjjbhabVGOR/wcE3DF2