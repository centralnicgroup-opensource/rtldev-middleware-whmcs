<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrew3K6x1FPsGecOOiC3QxAvjOOWp6CKVETBNIYSVqIsGWOJlPnlN0zM2g0dJ+/gGXuVaRV+
ybftfZXEqiRGnJww1fhhJ0mM4ZlzhviVE/X/VP+pr5geDEjMW3gZivWBKAkQc2iX+s9CaFoq5ulO
p3Ep3wwuO1aTmDMJ5CfiR6ZANHc17kYZ4q3uN4zsEa5OaejMm3iQXPUHCaVBpCzmvuAwfx6iUL8u
/LvtjnpVoEtPu5xwRY3HTCUURhTwyebeIfRhzFWke4AtjBa93Ff8k2SAjAxq0Melv39JciYju7hZ
TiRcHLl/PB9Vvjwyn+lFzETv1rz29v/567/+27ZY0jjgDGGTwdPOg1lGT+g945g9RNYD/T2IWdlN
leYudcEHDKDRUOQIcv+UiMetMrcN+fFiIY2qXWLN7hhp3LN/g2m4+3VHCOUYhmWuzyqtThiew6jo
e+W0AVIKewEP9aAkXZtmnuDJZfUzWTFpnPMfCsvJ66LUs1kFZYrJHEqZSegDVhpzYaTa5iNzWWJG
I8rA9yKTElduh4xDDs2bYX+Vd+xRsSssemmzGbOdLciAn0aCRK15uaS7hj9xBX4L6om2zKmheECs
LMj2NZwRBFvGhN1dRo+Hy0MWHSws3mz53aghgak9WYUtSOvFK5z0AJ6GzvOGDl26M9pU0RbY29d1
yAadQTXkJ9K1K7CFb82w5gKNfNej1yCJ1zMXBIMP1wbmfKnAONTIZkd/7tRCFcrIOfaTgflbQdHJ
H7XX615CJy9iuIAhMwjy+yG9AIaw8INTXHjiejzJIAFXhEJ2y04gTrcux8Wdc9g6D0D8WzD5PlWf
Y3BVHAluaRC/AsGL9RsvTI+gOh+FzRcEJXl3NL7Qua6Sdsm/k1vATQmiZ184amCHjKc9oq6Vxm54
GkBVxWGlgpwRfK6ygMm+hJgSp+lB7xNZMiAAZjCwUyghy4pRn8DBz2D4sIXLWG4riKWQLTzRG1Wq
QqpDNVFDY0sicMOH+Cf3fqSTWDvW7TYVDZKHpIN8REaECibGW3ccpcci9oSsyE5Bm7bTdYRkgwMe
LDflD1BPMY3i3N8jOrMiSx6RrQ5F/c0J+ucpi/LQzBDrHixlWAroYY2PzCMyI/h9g+kzl5a6FQ9v
Ew2nXkeSgtWAb55Yb/jQ/h6duBb+UsQmAzpJ6BVwFXQUPBjggunSQLpxk6SPv8cC2gpfetKnc6Eh
5p7csfUPOH1oPYLiMufs1O3zAXB8lrml5X41ksLWtJZ+ELrw5ZFOuYjLKwJAMcStSKI87265qR92
fpl6zRHys4w9EvVCV9L2anOUHbFVUsniu7iAZeHaAMoDaNWc1kg8syUtw7TXCkPRyb3L2eiNWAO2
isSZbdMkwldH4F89HOJEeiSfdAOf3n7AdtK4RRe4SgesCMyx4PRgWDvLJV740h41Elrq4+tlne6j
QYF5GakYVO0Un5oQCVDdMC6tuX2LsBl46Eqik9Vi6PscrAyFXBtm5yxYc1K68+b/AiF9+mMSx8Pl
IwiLeeKjarZ8Z6BdoaqQu+OXiULgqnR3wUf2OScoQLVDyBE69/y8U4juyO+Y240OsJkBRa6eLbaN
qhRKellmoGz4y9Fl8/sNnAwranZNRPlb4HzLV6ZfhGcM2G8dbQsDGJeONb35Kn8hdFrBWzQFA6+J
NDeCEJH7BWkuaL6/KDUmha1y4wFHmkHtGN0hWIi11mkDyO1GwnlLCCCxi1NlArKmJIPneEKgPGkK
aYZFvxAWtM3NDAXY8/T00x09KpQFX2dBr2vqEg5Q52mDldXa/eD3AO8kDaMFMt8cOwUpRxSS2tI+
gZTiVlbAmYwcjjDm1rKkludtyJ49IqOfVaTlEzCKmG7bBmW36ViM3amGSvynTsgUsgLGiVrApyrJ
Laz9rWv25jl+fm2bas9EM/dm/EPfVVVGzrqGpfPVP50kCA07X6GNO8d64K3xoDohQkb9UiMN7iZd
cemkC0ovlw8X4jm3xODiFTnxuWhZzPRZAoc5VAYE7fC0P7GG6jIzod8qh2TNlW6XX7aI3+i1/dSX
b06nVylEhJwq6v9R9qR6u+ZudcOvQGNkzcPMbKWXC1n719U3B0ECxZ8ppHLuNYP1mpFzLDFP7QJM
Tidl/pfAi0Z1lyzagavT2rq+DxktEwRLKwUxX/X5gA4ATtBTT6GEqmNfgEwDFup8oCaqkkGumODK
dZq6R3IWEUtbtplB/dizBRgK8Bw4s2PBTuIyHrRnTsRGfoG9+uddkwTmwoo9E56QzKE/93f0E/bK
xb4Ntrike4mG/Mx6lb9NqoFsETBooxf7GwzTakc4yhXYfBLN8chgDOhyB/QiqvYsiFDh6xwueu5U
1vdbRT6hE7q8HhtnlXhx7if1t5kjT6m3ZWJQS2SB6nXL1dOOCP727/wuXm0BSW==