<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr/gsvj6D23S7rfEkCOvS06n8Otp75MphA+uIr4mtqeRPQVoB8IKCzl5ghiPoePFyTOdiQcQ
IcuYLb+KyIxnbtE1Q7Hz9t3jVbRXvDXaSzzQwvCO3ZSAi7BTzE/TpgkhKSEoxPapHIzuQFyvIJ7w
LYfDDP/FMOTdSYGORcO69E/VIApWagA5/uGOg6UL7vW3jPtwClb8N3HbxYlMmlLEedqQ6oyAR/cF
pwXHMjXwz+uZGKb85T1hDY85Sb6unOh3S/v7uWE08QczgikwJwn775gX2ULefBizZWHEAPbpegb0
9eSG/w6//rhb9Q5bELKe0UXmtVSUIEuA0amXZNrjQRLfxlhFIXILvQgWNLVXm1PzmrVtOYiRJwN6
i0GJ3c5xmJ0VoG0euL9tGsyNwFwIVmJQHl+mydk0N43IQMTJNKWDhKqOKmpqdNfaEo93xqP0LaK8
IwxUYmc4An1k8WoUX26AahPoscNdvmmkcET+NceruWvlnSOI1eilstvvfNkOGPamGG9sigkV/gFC
69peN7SJHmRROgGs6HFRncLyBHdhmykOqBfpG/wCbxrsl2LG5EWrwqB8Zwq3tKb+cokkkjfSZZNa
2U1hLB3KoC/Vqjt25HLucA9hH80LYcXfEbDCQNmPJXaoezq3SqyTQ2Ty66IMVNGkyUx/cooYoD6o
7Sf+dofvEY+xNkEp/ruoikiHV/sLU4WFZ7sPs53CRUswPG+gg1ZuxgCpNn7YoaXoCg7b7Twwy5Qa
a1lsaqoB3EQ/UtTEscRbPVuzjPl4CbcilO4w3C8quu8z6FSvYEpbWHbpRizrJixb6UGNYXVcfTHZ
xG/ytuUKdv9/2Y9CiUNqvI601YIRIAVIUHjfMHr8rlmDN9+Fxb+Eg6dI4W8b5aVRgRywCZ901oeB
pE8uiInyFuC4Z1LMEGNSx41DgyGYkY4j7fDU9lG1XocbuErQcnm0tt7Q0tMJUzjFheKwRGRuEfpk
J4nlg9Qs3fCtq9xSiEGtZcCwofHPhDxCRsL2TzfEsH91E9Aqi4NmUDT01SWXnGBTwDDbT2vZL9sf
AN3UVmVryK+NU1bWJO6VLBBR4bopTmK1n6kq7/ah9nycjjLrDb5PPmQxbPRC86aHLtigW3zYIFTN
rQi/LuUB0MNAd3INOFz0we2W9miHhBS84UMMUNzjDNmA44p8mPwY2E2EyH9Z8HitxxUQiWuiIgGC
kUMYC+p9OrwjTesc++xc1Mqv7NjwafsrB7sZJqy8SrfME8W10saYriLr5xGvPxyKNOrpyGRHm1Nh
/jtm5Cxu2+rKHpcsGsvIiiPeO2rX+84+to914SofhY1m/zlQ