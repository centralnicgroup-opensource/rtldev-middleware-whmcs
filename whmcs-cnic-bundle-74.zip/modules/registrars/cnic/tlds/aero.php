<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy6HBIkdVPOClY6u24MP76SPmpwWd04olC2kZosfmgHNkFX4ZvJ98OYfXXrnpusxhF2pnegn
PpuUmQEuXus8rUe+LAaZJz1ypZsTSvkYfj/Oey7XjxG7T674ZB2jxjQGUt3LfO94dDBjqbhhChhK
wdbb+BztqgU2R+c4YodwPJeEsdvlZqMqcX43x84sUZM6Cmh/ku2dwZ4gP84OqxyoGbHEkZH673h3
DKybQvYtxfbWzFZ2Ilyv6smUpsJ9ZEo9XTAm+2wWGhUqjGaC+aYu9mgqhlG8SAbftTerdOW1DC1s
DdV62V/udMy/cKz1DrO29mPxMv2CUPxVY6MW5wSl38JktGERiofWKUjIz27NCYxP1cX8s4833voT
BmGVbQVQKdrWkBtSC2aTw07SZ7ER+nI+6YfwcwfbUi2vD5/1WqDWcNu2H/6A672sC5SKTCF9dC9H
L0CQJ72ik0Vn9j/JwoIYK/Mw8HN7cviYULBkYJO4iaO4UISd1RUxGvEeyxeRB62jHjsUZZjJ8Q2e
9OjPARm3X5+Vkw5cb5gGsOZarpV1kQZ/KX2MLOCcTjXO56eW5Ya4ReQGUiK7nlUeXZiYx9xrRI8A
HDN+XkYsNioGDlOSrB1WSYtmA3VYg2bCVqK+En5E3CO59kiiNow4GfT+wjdRjS6qWs0dBDhwKxsc
EEIVqgEuIHoRw69J6ObtXTCK9p8caV70U0uahLimOCIMrPJOi6OFRyLJUEzIbgPBT2Ow+wjIIpJI
S9HoKB19V2kObCL8K+DSdp/a0CvHrUA3V9PPxUm752GrWdRnKrbRwqVb+XXHhQyPPxRUutV1DmLB
ZVIvghXelETOuC7gpYoBsqS1/IT4+sA12Zh2cG7XniGmVFWwQKSxvGsypV8KFiJ0B7wH/5+Jn6t4
i3swStBigUAdd0FomSuafyZwfKeQTvk9/uiMAhCdilw57Z9ZtjyYJViVvTi8LLTEGvMqiQRYp4et
gANekEyAGtm8A5xRVwhlhQpo1u/IxQelQSaan8hXcRisG1v7oAPccJHbjuos056zwHdlOXMWdH2/
2dGOtcHy+0e95L79UJBLhAPT6gyfzP5+//ARLNhdsj6kDE1N+CZUCDE9t95cBpXTQ7jDPNKqioLL
Rv/Obu4czkfv//YmB7b2cFj7aflRKzTpOr+XTKfiO+hdfjG0gSCNeYV3HXqG/zgxtyFnwgXJ6mEr
gRWCAX2bEXkCruq8J2PbLOHV/czhKDLSytJHy7D8/lOX1MkGUFRP/RT+6rHCQYUHbtKORFCZ/I3X
tPw1djWu6nZYwShlwiHkm5g/+mYW9lwlL7ItU/fvFPJMmxwyXPn3