<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/u+Oc0I1LT8wudtGvaUzwlaWVwQmE2DjjMkNd7OjhqtS2fJ/orGUIv4O2ZXJbXtBVkgr/Ee
bH/Jw9pfKVGmQZqvjJli5rxGF//c56wRhA4x/lVtWp4VSkUgC0Y0J6Q++2Uitc4t41ifEvw5wY+T
XcuchSYyMmvyoE2ysOa7sNr1e449+kgAHcza4iy9JaR/Zu6EGYVvVJK8Jp77ZAhMEurPVUehxXNb
60wX0nhT/9yTYqWU8X1aqZt71FjGBDt+6Six+2wWGhUqlWaC+aYu9mgqhlIWQNuSExVl+9bD6Uvs
Tco6RlyCKIAL3Lemf1NY0Bm6gw5zJTyPG9J5BSrz7/YAkc+IqN+oJmhWEwf+GSW/9co/gHSKLb80
+qgWuFTh0dHxb5cuLmEg0bIFhOYhqpqqTb7Ljs1XjLIRxF+XxyOf+skxYuQO5RkX6cTslF0fwz7Y
49333wbefPLR6Iq2VwKD2drsu5X9HeCbWOJ5xyPZ8gZXNOy3BAVQq3IIRPyURWq5tbSrAHZ23eLp
OGHlStA6WqAmbHnaATtJdj/OJDXWPb2mCeZHEYNIk8lGiO/q6UR6uLj8AMFuQaqpMFeFoI/QFnvw
AE33tWIK6yLU+j5tcRuZ7e28MAkrTXs5aOQPUTw5sXPP9J70+nLYbDrkfVONLAvITD788b1AFr9K
2EH2p6ivXGpPXzMipVUPdIbTJw64kAXE+u+D2UIFeRBckV0kAqLStVx0RsIHeDOm7thwqvfqtRV4
Z5MDnUzlPR6ItShDBqpP3m2i3PjPYQHSeXewlHbUCQmJ03zAuG6j3Ah3jFP1khbL08Jedo+PYU4R
UpSCNiJpOAF5Mx37WMR/wWBsmLZEAG+M0oYSX2CLkN73MiS5G0DHwMau+JiJfyEob5WCwLE2c8/S
2ZvF00hdS/VHXUaZGTdh5h+ssR2SakeIA6JDi9X1QukbHMnVbuqm3DYG25K2uGRU6coQc2w6R9i3
x1rwCjNg8ky1rGSaZO/bPHON/d4hmstvPm+mdAwLCJBWQijVICOk4lQwC2gOo+yRgomH6Lu=