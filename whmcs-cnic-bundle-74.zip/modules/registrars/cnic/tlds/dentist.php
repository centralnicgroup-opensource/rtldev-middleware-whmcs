<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/fPZfVje7BOwEuRj8SZFtkYrd9bqvRspeQuHJXhbBu6EuktVlBpM4u8oN5uV5Fb4TSxsCku
xLQWblQbq6XsAzXR5z9WlpxaYDmbzTkO2rk7b/o0Rquo0PR8dxM5qrPbV13NOifQpjPYaVXHif7W
+dViJVosbcdXth9CjRU209FQrC4Wn/BS6NPANBwF+vb7ye2WYjjn8ObSYAaef8xb2W0n1aaiSaej
kzMoFsMhu8PkyBM3Nj3wbHA5jnSRQBYFdQfXuWE08QczgikwJwn775gX2MPoM9xatd7BgO0jcQaW
qeOXM6m6sdUiVtP9i6yY+bMrWq2zQOH4jKij2Tp2PO5MtxVtT9nC5TJQGHApf6mekWcnfLDBAIEH
Xsb5sx7Q5aZ/ysq4gFB1bQ9DuRLN6hV0TvyUs3qSdVjQ3OI1csT78THfRfRsGEr2FYJK60jqbeZE
hQpml4V52SUWQ6XJjKHEc70QADaw/a1FndsY37Kk3zlAG4WZxcNmfoqW5O4cbmp4AeQhWZY75tPU
9nSDtMWaG4kMvTW4ElAMnJN4Cd3CQ6NLpjjCgYKV5I2D1XG0O2Np+/6zt77d5mO8QeT4erBuk5ls
+nYSrfHxQbLjtphFFeVM9qkuo+lDBuEHwDnNCHlU89Ck5z6wudV/eOVxEofQwVv67wylL+W/A5XT
ozXDDry75cJLgBhfEGXTTVIoCUHjNnmFWOYfefD/oOW6Lj0mjsMzrc83eKq0d2P6Wol+km3KDZH4
7cXmJkpyQOcVCMMitJBO5YFpgE2asg31CG5JGhiwwT/goKjYILddW6vuuPyjQASYanH140+cTRsw
1u8Wp+7ERlX6dXPhMC44vSKTpZ3TLwa8+MQFz5XbAhsOHFMPWa8NgsC7NrGO7OrfSw1DhV0D6djQ
OW0m3rI8Oq90udEJrDh1luCEcVqKW52CRLze8TvP943ezmaIFwf5eFTFViQOq9qeSD1d/Q09CZh4
gR/2DswRahVN5IOvYK+PA6ptesPKwfK0uxm8x/uupOCxL46iTcSnG5VWBxmSEycG9BjZ38Ua