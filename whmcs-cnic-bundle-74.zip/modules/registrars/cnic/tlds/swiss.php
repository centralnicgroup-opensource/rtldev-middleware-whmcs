<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/4SwTcwuD4UGwry+ePioaYvVymI/MMp4VClSlzqmHJtLdrJkk6Guki29h1bUibZXdlBZuJ3
SOPsT8GhPsjdkr+Fe2kM+0/hf2FRVZq5MHbc2tXNuVQML2q7PgsGDXc+halcHDPSJoF3SUwfbEn0
op5lMdD0kysN61ZBuKxd33dxWK8ukz/HngX9LqvgshcPvC8E2HMZgv3VYFn3lC+MVLJdto75QOGs
r/OuPwNylTaTP7fZgoYQzOWOu3/CGjqj7KFsm/Wke4AtjBG93Ff8k2SAjAxql6yPopUdpI7Zxf3M
TZQHvdF/Tz9fzjHrd8hGPAAfndbUvDUDFWMavBgr5h0PbufpnG3BXQK0I22jpvJA0lYFrAlpyjnA
HkaJC6HbMlK5Mm3fpsbnFfIY8/arLshi3IGAiiZHECevmHM+m1F5uYeYwYBMe8E8s21u/ougluZC
NJkRrfeFElRPmzGsFylPT+Xc0WjRK2yRKG6hy2s1qUIBj+EvxubAZ+tmGbPSL/v6+vF97/mvIMoj
RturVqr8xWdtUxcVvLoOfnUGZBtjFvNDTzkVkaQbNcOQIzP7FIxRaMrR5c1Ngqwn+vsjmJQzxGTY
t8BSnmHF2fz5RUGqQMG278v09ysyT/cI4klFE3wFnPzw5vAAashvtKNCCnCwhYL5TPk0GzR3YmOx
S8r6f+U9n7OnPMrDKfYPUK1e7THHTNZe04YJ42rDrYSKE+B/KE1ffTS+N06Ki2zSxLjlVPe9JHuf
J3ecQoq7bsBMzwLwxaz1zM/IK3W3UVYc8X9lCD6KO6e59ch8PnEEOxxweUpx9LZQZ55GYHIfmuiX
cttP5ybkUqftT9St3MnXDlN7Izg9RtGiwbTwlC4QcrumpJqB3OgNcAf3UkPJUtm6mhgAnuhnf1wN
VH+3YWYhWEcP7i38q45SqgWf0xYcnZ3RHOT/6F9xWdQGsvJKf+09gTw46kdxo1BS8RKJ3toGfdhJ
lWhgU6dI9JHb/yqMSZGtgyBsTgHsehuXbikmdFCax8ZuoLF8+YmTKOhYlRtwGW6X3cu3IH601ify
jMusyoCty2eiOUq4K1wQYJYHhTwfixRZM4AAEYdu6GZRSQjveo/tfywxn8rK1VoMSl9q9F8Q16QX
U61J6Pr012IQCST1DVMEoZUzUeDtNPhwaSUMJeJtE25rkRLS5HX6NK6O1TpMW8SLVy9b06+PuIkN
Wutsaos4r2agxh+gt64TFZ/iEvttdzDBR+LTzAcdEsBPzQzKDDLYiZyh36QcAt3fIELU37y/pMRr
kIYBKb+uA+DEv76kmm5OmpdBElXwP+jxN+AVeUeNm8x2LZzwSJt60om4AtzkS6mI7PMUPYpb21q3
98TCq/6zgwz9p0fPwzwFQ5jznv4FY2DM3WMJ7W1WVjV9hc2vMb/nB4msxKMcJkAeGPw+MQDArNFg
1Kcr7omVzx1j3s5rXtJxbNCfmokEK1B3dnLsHZ405XW7wnSoTz9j2MmtY32D94+7sVIJSEI/k0oa
mdTU5KBarE+vd8FcG7znoG65EJg8mbaAEAe3M5aHV+y/k6tceqv67QqSXqPfWY6quYQvpQbR59oA
8Bu4ZLHSIZZsi8ZS1Qu=