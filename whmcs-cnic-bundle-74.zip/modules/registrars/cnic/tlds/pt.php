<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzlwiXH6MWTR7qWdDtDKZOYQL9VDBJDVlDvYP6dS1P8VgCfz7ymr3J76m6h7iZQZtku8+pzE
PWz8qeVS/x7c3b4b4riaR+btakjRYajXmLZmaVhLvq1aCYRWnu8dSZbEzhpDDwXsOuNVj11Dcfrp
Q5MdbxSecUKb5dAMHTAvLHyiuMFugs/TmY9KaYnGKiQ4jH7jZhsbcIR/o7GIE0BAeKwTo8rMwunZ
uSvWyKD/foH12QaUysIMvqqiVKwA5OXtEBxXWU83W26flQhBka+iHnnQeGaPQDYnk/Oa6ucVBbIf
0DD6195zx7LEyP+MdmgcMkkWSep2NXvEGYROoxXwED838SWmpPYQkk9uL+rhLbtJ58+CmAsYMWIK
lSy8H4OQoNZfvc/Es7SBiesfRdi8T8BRsPsjcxv3/6mSllEnT7+g9M5iJ3uB+OCMAH5k6iB3kLbl
4YgllsFmv6o4ABUlkzWdJeLbiwbrerUEGjcaycHLkoXg+Ae4X5eSEwwuExj9oqntVPhZKAe3PiRb
l9uSRgiTOKHPxInuujO2jDXAlmhv3t1j72iCxmAbevNdwClib0+aPj/4D06HbBC4C6t21C4CaZrx
punPsNsmC94ZSTS12DBOMws6Vi+pwTK8EwdF/VInI+DpJCrGxfBVi3rV7b6witaQSiSRq3shsMe6
BI9mXvZclsJvOOHa1VIU4jv0Kc7sYl+pS32nElWjKaVLPqdc7Z+houcfZjC7OgpGeNzxXexOiVz2
Ax0PP0ZO/MF6cvF4vI4h4+ite0K21rkTcbs4MDpy5ey5yGcRL750O4tP2LnW1Rl4mT7N3Pyd2S2o
sPqRPTZ2F+KDge46huA4/xUmMwDxDVfok6FHZF889MLrgefJndvV9Ke9lgdEJjEi0+bEG0eexYOW
qstzXcvIUuya79VGrb/gSlkaHjKIAgC8HF7Ti2C+OGaAanUjtUZHDQVsuiqsdVvu6iKcChhsDi5U
lFqQ+OvdbXiftgnmh6SxBPaT8HwNCxachBSihcY2rNLi8fcCtBPaAqvr+PSnkGOXx9Q1j4ZWpnNQ
oURgvr/uddE5ZCMu+Lki5CkYX/CibU0JEPqTt0DieZHislF+irGpD5q6QS+cC0mlclCb+80MU589
8jEV9z4Nzz2X9rJxpDTn468HwenfiZtxwzRJwLfJot3rUIEdNIIMrgfLPAP0V3kKEAtibs7BlyIT
+ZGoXOdVsVJzWymqjuWaz3GcrkOOXwmzi1jH/L1FTwq2j0Zrc9YgB+nkMeqFrBcT/Sr7dMS7tk93
SGmLAMdw/pyF1Wlbo/2+Qrl1n4hUIMQcCscmAhDPRfh3YRaf8CR0hj6FqmsfcNx0yAXVoisiXeFw
QGUvUPKggfde+/aF8AX8TTXNcnHs9eO3J+WDy2SABSot4DEKd007y2y1CC3gJiYQPqg73FUmtyk9
ejHwqVpQmO2F60S3rLvrFry7jLz25Y0xldiprY4I4Y4LQQpv8zDXUj+D7LGUYMPQjSRXvxq0/OBY
Sypv4IEaFz3DkUdV9k+hV2AjFqVfWz6M+XXHqL2E3hsEhOfhO1PP2vWfAMuT7dMMsAxpOTiY8tVs
vZkOqEowY5lmnpbMSkSXvHDH1OZh+DKMWiQV+mCqOPnJLxzLnn9t4YdmMJ/b8aiO7E18eDVjb+CH
XWF1dM7syqDlFwtB4FieJVyr3pZZvCeeAcfZTDBDnCdSh+6z0eAFQbvjf/dHNPBmzeccgZqc5Xn1
rujaTapouFCG41nowbN3hHZkjiUX+67HrjYXPWOves9JCMKbxs0KvLb2RmHVlvaSPV0JXsT2Z3x8
US0sLjwGyg9qjlP4ehj9xSC=