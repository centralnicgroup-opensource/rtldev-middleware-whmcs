<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzDjyFf3iyZz6jzbsInUnR4pw9qCRJe2++D86psb11KsvITYt6AHN+jeszeQqIi6Ost+nCAc
V5cpxWmGqEjOS/sQ46TMc2B3IBjADUCImvRKrTMD4vE/+Yg7NSeTXELcfjhensL6lXNzdNoBqUuJ
N9fD8BxOy/NhS4YFSKk6rnGLuEeWzIg6t7mZCWJNsdmKoCUTQGQ7hKKJKzXkdfkZTOMiD6vCkEF/
OkXagsdilquellTYx6+XRYAceQ2nSml4Zy+w+lWke4Atj9C93Ff8k2SAjAxqYt5SxIj0DcgwOQvN
TaPeHd6BJA9rVmQ3qwn8qZukY8trrnARBImCm/6K0dwjKYWduIQAds9e8OhYuMWB9/wkiIG1vJjB
XIHMSEVAZP3ST84V+k0xJYU6QTZivtrq0hqVZ04U0TWoxCUCn3wS7X5rNtpQ2C8tZ9ovUJhZ6WSJ
VUh5zjAfETMihqmSKeT5YjIxHouaTQJRbdvETU9mGf7iCasU75IHhbyM0+Zv2/vH6R1M3MEOaHAA
RyGhSx6bUjLV45Cd4OCiuF6YWL/sJf83WC/31DaROVJu7LsejgmjkXFROGkQySYecX8dd7muDf8N
7oMW4yYet+RfAcfK7vu3ZxkPakjZoRg/UgmPeRYm27BUQWPCgiCnL0XeSEXy9IepSvH02VQThGIB
3pLo4tv1b8o72JbfhGgCUK2HwiWqVI+WxiuXYDpC2Zxw8E6qB0Aq4tTTjY74D5lotKug0NV74tOd
fDtpohIpT9iuJ+hADz2tzNCsDVNAa/zXDxzdOluKjaFi2h0+gAML757x29zW3eU6vn5xnuq0x2t8
dG1nNuwrnbmWhxDA1yfkZl7EJ81VPKtiYFqw+sqp0koaiau5XwYjfe6YEvgKiJDGdGz5HCKpGCzR
aiw5MrCbr2dw97E5jys4LkGUMG9wRLXHpRhLS1RJTad3xlLSspy/oDnsvA1fVasdeW4bIk7Yz6Wd
ySrGZ7Qm+am7JPQMh1bxuySuezeC1241dyDo3qFP41DE/zp/kq8FIirfCv6j2i6e5pRfoVb2RVAx
0L0RJC3xH9kihcJcJUeEBXVlOSfDuL9mRwKVo7xZ7yKEmxsEUDm18tbpv04Seu3OituR4Rz9ZpQQ
8Rfjjr0Tg15D+9xJz9CcnUoABTv8ws2XpUcWcoanGtoWNyBenVNynGmupw5HDf0URSUZhOYAsiga
CO4fCDUwh4j09AnvlrUCLj+f7+yuIodn7rJY5F07yjBEogWsW2+qP0k/cQGNb0HIoo7m0eQnB1tf
aoCMgB5a9Bvw+rHgKSxNczjF6yliGqbL6nN8kJgr//JX1VKm0yoXHXSDEbDtPmmUW+WLoQpSlRfE
ksRxkmwV2HQCCM5A80A/qVOZTgiKZ8n4u4zWw+ke0HEqpsX3u2Zu09I//E2nwZd8dFz0dsYKwpUG
d2QeGZqH7qH15ODiC8i0dH3k05ynACx3MOEOSQqgfv3Z4RUgPbZoYVcIVj4cuU1iwum3+xfUdXcV
7z0/+b3v4kKvRHJakVZhTr1h8oHWDPk9X3g8yLnjHh07LYqCHx/sGwakXqd7xgrOksV3Hy/tohdr
SCbidcuSnBncGICLkH9SaRU0jBxzG3HwDiqoQO51q0fOW4a4eAI3s5hjuwnS5BREROD4azqekyEQ
ac2ugqQUp7KbGzwK3KC9qZ3O/zNnB45rd6U9SfJcvqVELaxrJZ3TgJWpegkGgkEp+l5kjFpyB1t5
CpO96HPUnRQ8xVVLJAfrzWovxP3EbkaN78lwzdnlPenpJ1/iXfK7MD5WeP7vctUNCDHFXFt32OEA
Br233EolQsVplJOvtLy=