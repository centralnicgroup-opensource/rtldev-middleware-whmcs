<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmTlirUyimUOkTycT7mjBUmq7jlDQfuQVi5/0A1KovKvpLa4S3+aR5lZjFvlp6gPIiEyOBBW
jEs9hzq8DTi3SkEHnnjjjt58zuQFN9eRRDuQ/SIL0+p83l+Hu0+KsxNOw7FH9Q2MamUt9D1dx9JA
2e2KxRbxPXZLWVE5gNoEtLxweDJD9VBSsYMHquRYYcjdQ9J2H+kL7eogz9muVFJmRPqf52huM0z1
GhtfedTWgUimrHeWLvv3TK42qMOWa+XvXXNp+U83W26flQhBka+iHnnQeGafS4EP1455ojDZ1rof
yD+bQV+9+CcA2SvFHKnvi++WOLYOiG0MpJRA0X1K1eGfuuSrzNJ89eryMyezHdQGXwoIv2TFh2AP
9Hn6LtHdclF9GqFZukCG2Hgswccxy/TIsKi4R4kNvSWKw1gB7Gmd/NKCAFWxFqPQ5Reg3AzEUdix
SViFFlh6k9znW74DIoSRdLZMIhVkYQc/i7Cc8Qvcw0qBMlEbM4XnkGbHLIqR6zEO4eqsjl1Q9A2j
2HexeD38xbbtx8bNPdcYdyisZLd6rOaYkXkeZ3jruW8urXWll5szpwZSmJgfN8TubkuCCkQFg8jO
uGhHhOp5nX1faxtyom6/gGmuhtpnawW5s8cJ6qKfCjXN1EqbT6+NOqUHsc65JncX9dm0sFfuow9R
jtsov/eURHWeQcgHjquKzqf1sHKJpXKsIfbDr3Q947oUDa8Qy5x/5yOEwb1vgW7yggFDyYsSw32c
/NYPCOkL9W46c6dVBFx2CAR8tbkXFHf2MXg1ohB3YbFNrKJmedkjzJxHgbuEicXU4Qj+7bEIlhTG
Xii3yTgE/bWSVkmtTCrpn8TNJpIhxLl27hujX+taTOpgtP/1ZZXMqYDdLnQDxzkjQ/Pimu6r1E7w
JyXtz4Tz46lE2gRnV6G0ZxiHC+b2HzMvR5Kfdq0rFIkX0fv3jZKZp4/fmqqnf5GbYO0GSv6+h6DI
nKNNtdVbY6MzPEyFC3yV7EpyDM7Bb9wj3s9nzR388h7TmewXFfFVt6u7Pj4iMf/kRfCAP+OvX/zy
p2sOR61x6Qge16upyFxhkZEmyjRYGDIMgC7d5vvaryDzCkKGmUGrA0FFzMiXh5f+lLXBDKhtzAp3
K6eTiycPwsdYxFgRJrZbiOw3Z7r0VmkZRBHRMiyUqSbE460ns2HNOcVZprRrx+dpF/UneMhKNua5
/1SzCgRbSuYA1JuFeCEbYR0M3CZFErKFpV+glM9XUm==