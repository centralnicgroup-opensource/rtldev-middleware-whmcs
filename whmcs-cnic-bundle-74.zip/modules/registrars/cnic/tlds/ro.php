<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrPlJKLV/qgrQYQZs6O18nMp7FqwdfQHyiCCz6Zc5dombkT4Wrr2eglQ/suv8mNgGqRJv6H6
zj6OgaifNhrEgGy2gSA8hw14M/wQbTQHEr6JCcv99NpHgR7dNLbtpG2Uu2Xb6hdkKO10bpVuMYqE
nWOIbJ8e2QFONN4ZqcIgJNkbGXro2kwWg58dAVN9bUEUDu4bzHwWQ5VkqaSXHNmULACkLiPaW/S/
aa1x8Dgyo8Tev3YSXMeLyLiDlgWjrqv2GnvCoE83W26flQhBka+iHnnQeGcoP9rN8s8nl4YHp/cf
SAG7RDd/N0FrknESq9kvdetg82qRPDz5vU/XHSgkVB9+Ate1/p0cd5FwElmPjACUPVfbeBYU05GK
9/GKNSopTltSQV/DPxwAzfBPk7X3iqfSwuW6RqMagL7k63tCN6+PNvOW/zuXQ3ufYuBNhVILOCBq
LTJ+MDf9b2LvKQrZl0QewOgvAlwJ4V89q11TdMwM8bhVWv0hcK8to45MI69lkVe9C9UKEcxRf5LQ
2cCSI9iERSeb55MYTDQYrxoqs3BXlYnnrQ3b2Z0mt+TMTfpdM3B+x+FDAR66IvIaAhFrZ6ra9Vr/
MLclok+PBQAN5WcX8nYjarKrch1KUYfxoOcQpPGwzn2oH6CT/vug9wa7Y/p6ZG8usC7DC7h3W24M
OUv1sx1OW0y4d2+bJXp4eYQnSqmNE5yPyKio/m3kuT2aZxJ3cdDHT3Fuk9fLjF5QUifi9HU9i5DB
D7drpPKAqMiwkXhJlxfxCk5vh5vpNJeek34aJkU1YP4ltSga7JxmnQBydWJHhBVnpFCYYTOMPLrR
VXJufCUFBUC+Hn7KyWzQSVpSlEf2/URHUflC8RwDSI4wUuvqZhQ0yel51jZnWgZGdKeH5gLIlZd5
AlSPlrtJrn145Ftxvrod5s9vCF0XA+fmyvms30AAv+xrqw9dMoNF/v8q+8b9QXwdnBpxgqRXP9dj
O7NV+swvgZh/0SQNd1UPlFnDlH+Vi35UglVmrz7ri7d/rAJcgOw5bTLcDeziwjSAzB7JovQrfYua
tmjOiC0r/0jLzy/caQQCTtapbX9LMDhNWBGdEX5Int/GjhRb2AsHtpQBPfkl1QdFJ+PBS+lzJ4z8
6hwnb+7mMStBLzIDaO/lbU5L+zdxuj173y5Y9tjd3+Ha9Eh8OR943HpksVK9Q8hHh6uoX21tgp8N
rta0MydTpSXsll81/Ii5LG0rz8d6h9exO6ys2Y5+hHIVZE9EDEyHy/G4TcRSVZXp6eFHPHD9s+Sn
ezq9qcAjIUEyb5XCe29Y2A8Yc3XxnmppnKGHD12N/FNiD3q1Q2hYRAgMZtyj5/AZ5CCLJVUFts33
iKGW2lOCHGNOSdDvg1TLhUhDdX0U/A+8wss/uJTeGIBL9N3NCWwmRDZVpcCiZVuNuTZ8tLk2e5MB
3om/XRYgakxYQOW0VmdNCmRzhugLfCODaK0pntjLQCFOjrztQP9cHPbslo70Pbe3qI10WN39cSqZ
BfEsv3kQ4Oj9Dpq9JYSOXc/zS+klJAk4z3UvilZN8GoWuOKvXJ3Fg6fLkXCCx+yWm9zf7mi/xGZF
rANPMVeIBYsOohRyJJfuvWKDzq/9FPPKIsvlzoWoR2hyb7fHJaUsHxEV/B8dE0+DM6KKszKQ3i3T
GPQvDScz3t4/KbqmvnO2/m3izb0zIj6EhFgOlpPIdjlKpxYM7y/RHNyeZ1iwAZhBz20PTBvEOpEu
eoIvKW4MgYmo3iT5jeNXjGgqAbYL3P6EA1q/q7avzAH7vEBui/OAfeR53b/Efa8t6Nilmf6GDgM9
BWtL8P9eIU10T8xYzNq7aUBNOo3yzRn0x06v3JT1/z+BXTOlt0v6tyx4QyK//UbM8Yrm9iuJh+4t
txmG/AMiH/x/x7zs6G3RDSXv66pGLy+5qLt/gChWg9c/cyndIW2inRPel/eFmXuXKix6B5EOmnTO
PCy9aY3wA3Tg87kHTmu4pai1YrIp53N/pC4KKYXlEb6Wps7P5NAXf4AgU23/Ct0qzH90MrhvjDTg
vclpqzVruCC2l2C2Rm/rHwAsNzzOouMf8E0BIdGUUlENZdgP0LQZpGYFp5dXUBS30m3I4mGorZMl
egCSpNdN5RibwWqAbRaB+3BRWoVCH4/fGb5Nwi6zbfFVNJQFTHIvGrErzYUeC52l2nqIIpbx+b+d
LFKkmdwh1AapzZLCd9TVQQ7tRhGkD/49JCfi+M/GHZD3W1A3Gu12sTrcxDDiq6MawjuhMWwibtk9
tQXQ3pdl8T1df4ySeYz7jKfH78c/NV4RSukzcQzqUuuOD5GK20Wukwn7hqnK+WLw1+xoXyLqEp7C
FzaeP4I9Pr49Msd2gb6Z7mgYwA417IueGhckdybk29osaLMtexRgZXSYwqPHtgf56OSEXEKa4G5q
zKwm5DNiXRDTrT1N5j2sYZTA6RWxaRf4bxBmB+Xg3ilFlYJNYvjOqczayU0QvbE5SbGl3d9ilQJ5
SlMaQZsra5Yhg0GTmPRueHxDMm3MWBvB3SyAXB6Wx1e2KYX4A4ytnhcGTlGrVNuDTKyKcNPnrIjq
JaKuC0gyb/nxt9Vt8AfYy0DlsER1tXlFfLSL9XncQKrQVZWfPBS9acSLvNDW9aGOc41Q7WL5QV90
eAn8wP/RZ8EFApToUU3xLzL0mYRJoMUA2QdCxTb7L9fZCh3OaOGEbf1LYCUBwevwh10=