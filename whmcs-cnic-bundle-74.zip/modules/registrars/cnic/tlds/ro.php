<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPscYpcDD83DK26vRGBxWbkrnDeQ3bwR/GTwk+I2Xtanp5QOx3q/dTOB+8OwxxaNYWn1litl1
UwjSLsNeMEXvQPJwoe5HHjq42VdXwKhjYbpoZ3N7rljvuIUKs/hDpChQWkTyJI+XB1AC3SW/CJq/
z3+b5y1zeRNjP3Xb9Zq9LakZMpNrmfoO7YTEGpwPYj2+tSFtyEMbn0hIbOxY+u6LN+lVkLcYcrr8
+MwHPejCvpcwdFnYCAetvRCM1z+47fLl+EVH+2wWGhUqlmaC+aYu9mgqhlIqSIj+n/Kl8VUpo3Xs
9h6cOM/1E4CKzvjgeQ/XdBzSBRZyUtsrr1x29RT4KQf7LCxUkTt5ACdoB47AlguCPzbAl5WEfdUF
NEmZimhK2jUBbjzrymQ1kMTEKCNYr0WELEbEEUMW8GB30udDjlscISue6609espFkJew5ej5pv6U
mFU1/pvCRP1uMXFxoqrhW5lOLJ/oZ3CtrsU+mXE+qhEAmStNVULbDrYPaIDW3a9rBFAN3nG7WoDL
qbXFGU1MnCDRl0EOa4MIoWCayjDKwPpFhvwERXb5XnSTYaKBAW0M5fBOb77zkyuw0wta7c2qZbTN
6J/fVAopJrrBAU7AmHdgGmRw13aZqasAjDkN9JKEmEEGO49D9XFD7SkERSDE/u1PphOXtJuVnEK5
YiMnQTK0zeQMvnuO4kEiN4vASQFu5HADbu93sBsM73M/CBYzUddssjXhVLjAtgn9xwleSA4DIzEL
a3Zs9Gmed+dA7zJnhKK/bZRYmzbNSyVyv5TfoxV1KH4h+sj9Z5i5CYrW0hPfb2Y1hdm0WCw1I2+L
45zAAOfsbfcslUd/2ccwHo+DXhwrK5jTJTjpR0PEbXebYxbOlzDIS6oON227Qa+mGI1gxh9GJZBE
jxAkQ550zfHV3MS2KFQsrSWqabE0xojeJLP61C6175pKaVPXVEpN1ifr8CMAeQBjC+bK2gIEmwc3
JJb8ZQYAOnRVYzlbrfCIBsnaYFMQg3Cn6ZfyvfHFOI42Mo0IomQqfm9Kbe4GWXACLX3BwVTsu2dr
EQdpta9pAHVGtTJITELUuGmiPhtyZVfx42pol3sTd7OWujY2zH3U0urPa7RoMnt7Bph4mJU49sM2
cjVKL8peM1Fy9DEBLPOWV2PiVUWoVvBO/plvc0iCScaWfyGT+Wfpg7SvOA0//0I7GpVbq8AeMFc4
OWIbBNj5fK+iA2pJxhuwDRYTWOhZnyBah+RiPQyacHmL8s689GfCPxdkkwb3BG2QbgmsY09NYSCJ
O3v+o9Y0i6mpgU+rG1EZUhj/Ohb8legSQU7vt8aI98m5FmsFNM/qKQzai2xG/jIxdn5S1Gj6nmpX
5Mu84QxBtu3vNnJ1fPY93MM+DruOlGjCXhxI2eFygKeIYxONHcmGTJTLEn2HpP7PnjxPzr8HCHGe
mL96W6A5zrm0yrWjutg/IJP3s5nqPApkAwNZVpUFFqrkZPUmjJyu1VtNbbH9VrmXu8Z1Ix759fNd
IP2h91QSSLe5Qo2i+gjmjddCt5vGBG4+SjtebrtolfTcXXET2kp/93Sc+t9ipddjRdAWlKkhvUf7
2UJj8iKIWgdHiLwcyJgT1dDfOrtVxF5h8Y0nJMySmLURWCMkR6EK0GHP5ApwiU2H9bkM9CxnJtbD
NH/CHFg/oTjkpme/itN20+ScfOotwXsz8KZ4mUAViKOc/zUbHWbHWqfJmU5DGdUXJT7YjHRsSHyD
LKb3gR/V/h+4lZIb4dunVVMIfTQxm68rQhNLGWn5UwQlRBbghWXYDKLLEpNDPfdHKq7kifkYGuw6
jM4wcK6qFUVcAH6t49bPeLKKLTLvwj3NaPeh1kjGHRos4I2NPC5OjX5pNzdx7FHNm1tWHIl3pijY
T4UndiJwQSQydaakKb6gGyIeN2J80ViQOJtFMv8Utq1njiKDyxrUwo8gJwJue6SQeTylq3T14mwE
EzYFpurcAwoqHiFWL4Mu8/7GKkZF7+kyhnYCis6m30gNZGap56oNtcdORUgDG2NKL18moHyKm1v6
SmYxutp/6qdXp8N/uF/eVkGsBscjhUEYpBbiRP/qP3fZdDXeyPUZueUdIfnsV3qVQiwQG1RS8+hD
rWGScgtXiERcEh/8AwXqVVjJLta0IAiQWecPlbN1UtuTaYB4Cpkkxt6dreg42n9l5ahkzQyHk2Kv
JhVCO/RxRWtjdM6QgY7ONGzyew9vcDvN1B5fBGRPZ+kBmR4lznTDPuQx2GsRHh5fmQmXG+ykf6Xf
HmBAWmSa7jPxwsXbjpUpG44v+Oc574FCPkuGqAgcFxQhpMOL+cpQH8b1IakaohhDHweQXb/pap2a
QXzfzbT60tBYnNvXi8I82tLk94ifNb5Un7JR3kUdIBuqOFuwuJFuj/gKNdV1ZA2ikuTIkqLuZVFv
47A23dVYXQjGXTzsy0gFx2CGBf96k/D1B1g/C74NsnWGqZU9LvZ1+96WSKrerp/Oguzjc0IXoKfE
O62M+F3ZHaIt919BtFGV3izhu0idcMKxJW7gTDAwKa4PNpRw/MKJCvr9mAOJeVo2YIIXhdTOc15H
dMuRoJSuSjK1fMC813AoZknTXpbYWopyhEa/kgioR9ugppRfoyS1JRSjPB3NlJVtQdvqVd781O0G
6wdoRMgXTvv+AhQxmkp/jCHZcLwKD6pBWY77JSXZSBnKmkEoEdPrTHcUYUlrPkxtYOJPNSvK0IoT
y0Y9aQxNYIx/9m==