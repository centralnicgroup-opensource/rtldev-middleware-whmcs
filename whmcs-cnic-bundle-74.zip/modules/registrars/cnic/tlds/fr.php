<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxTO/S4p0iRsof1euc2ExGwZMbHSgBUyC/rWwMJ1mkoPGuzgASxA2CtcUDef6Cyn3rfJVMT3
nF88q9+Oo9UZ/daIv5GE2V+w5VYg6RdgTYnyMlTDUyyQlT+LJ0rr889QegTOluuxLW0XqqDEaC/N
9SqD6obGIg8DJkAgfbStwtSdPSgjrqdFurKKRnaZMDLbMoefyEd05MbKS3yOVcZGlyU8PnDoVrn4
6u+Xx+a3+RABKpAIHw9AKrouc2tAq8Me80rlSE83W26flQhBka+iHnnQeGcVPmIX4IontTX26vwf
84YeCF/zK6T0/x4zJNumJ3GoPayQ0jBdulLQlSb4KkopS0HtG9x7SN0MTdEmLc/Cv0ypIoLF5bVL
FOKrbHWLYH+1zuz1e8d7VKVMWNeF3ysVSD5w/KT+szb9EILl2mptSSYeKKwiQr827xDoR/rEiriq
NMSgBO0O+QF+X/n2Eiii1sW2UCCXkHwsSiSiDQPsYi1U/fh1/6N/Hk/hK699MMp+nPajHy0h74dA
l0+2juZ2mWe6FYzQ8HITcmVlr0qHnG2NCRPWdp2GzHsz2OwK4DjrwxDDKrNYDXHSLjemwcdtRnZr
gXpxkjV3xaKf2x3+j8145ZZzEYTVWywuuRX3PNpsyQHRpp7FL69hrnDsi17TlWgTw8m8VUSFHT+0
E55LQGbWDg8KM2ZuPkx9qhvxyAotRh2twsARN5KTHi72w+XyVlFMjwVT71WX1LzIaRetjw6+DmTj
NDgYK0DJCqOt+dgRSUxsNJ1GntXxG0lgOF86l4jaBqdR7IZXK6jrDwwcOU7yz1EhI883wcDt+FxO
Vx87x//Yq1dtP9rA4SVe3X8Cx8E4htRjpvwbR0By5EjdA61nNGSVstmeOsz0VlXibSKMMnT3GGui
gCE8TBkD4X1H5sw3avkMDYzzawfnM+gZS4GnR5lvExlAE3sdLrMECQUPuCHU65Ct+SB8CnVu/sKx
gdFtcio5v2yTdFarxzLYAIoevcWEgEY2AcvZDMkmBPrHxHgbJiAFOGn+eTUf5/RZHHSZ+CmgIYvH
zHWRHYknDFKOEyFV42JRX7WOjDj00tTwboXeUPjbIxzu9ZSRGHJ42yTJFsNs9Ep50rkOo6tOIkfS
2L/A3XXn+OR4FJD88+GejObRtrh3qfpJdoHEVYOuOIF/iekKYS4ErPTReKJdq0Zw++sWhdYLZ8n1
OYdpdLRlQjabE76Au3/csb+ofCqICB541/r+PXJFr/J3UuqEWHhtmisXm1MdIb2TmGTqBD0Zuzb/
v+rDNIfoVMpzfsW29bzWzD/upe73TNmqze0dn5ognyt4+4ujWqgaWYqQIflsEF4koMVVXcdnPurK
ABQVitypzpVv5j2K1cc33qgb8pjmJprz2sVlbLc7uo/cwigJ5UqtSUezQ93Ejl/FL4HWJaaoPOaU
UGSFMdy3V0PKRGp4RHJePypw9WL5NVFWzGxrec0FbIyXBx99EbpLwLtU/1Uk+KYt1g02OOMyt9vI
zwVFw7HwrAwvKItMoXe0a7EVVUO53y/LT95o5eguP6DuWLc+bXzt5EHmLf+LEl7Fh1UZHmL2zfki
0ThM5+gu+Nk23XF3TihGIrZ1K61D/HBD9RaT2qUswExTw3tDSny5lN3pfqq29SDLdy4HDGtL4xF2
itmE+qCTP2CmJM8LZmuwv8qqbI2eTvC/loqpVubdXS/7oJDypUfiVPlTDZN6Y+pw2vNsrvpmO/Ho
jckIkaVgcCuw8Esepg5qgB0cFMYgx8cdd2sqHsBMLYbQheKnUWnBbxo1IeAbXoCCr+vAozSoETWt
G65BxB2VwvGO1BPu+Uv/lkj2i+2PQHkjwOBWwklHUHgFar25NIS774R93gine14fU/8K9jVYb3HQ
QQdZksZlAXX+Gw19FxsTiOERkow/HXweBo7+c+N76YxsxtxUzfIySSosHZ6FcGBSP5v06uCnORkt
qqG37ksfMfx4GzykxsZwdu/2V6j87iwckbEid5341hbVaD6clAfZLjIB1Q7sdYEXAox/atocfUIl
22X7N7pVK6xenH6klX3WdZFEJX9B60m+y3t+kgp7/MVMswqX2oIlE80U67JxrJjsR8SG2nFFm/11
3dIL04Ndc4mN8oeL2Qid0yJ7RowMZXeHmfqwsztCnUeJM/xQvzG2hMK6Nr38HXs2tNPHWBR4VPJT
a3x6pSaNq5W3BI1pm3xT5CrkGwfr+GGe9YiVb/vUw3w6/Xa7rbTyAMNxcRx+Hq8CCa28V48VFqA1
9G+OBnPlAYWtSOgnks6VLmJ6L/922zHlzZ6FkcY/cVJgdIXJZE8SvF4pJHnsXPTGt0Tw8KF616vU
0sJ4MSR0bSED7iXNYFDxtdgepRDeBBxrO9lTbozBxINqXUZppdjxujlMU5A2z6ZsZzwbPGO/1m+Q
dbqiaWTolIgywz9UmJLTgI+1Lo2SVtAPZYVhiHBmQGaw+ACOHgRwuvD6ufPorBrHTZd+LKIA+qs8
aXBxrBAB9RM3eN0iMBwcTHnxGGiP4ckOgKjzg3MzXPcLQZWciTLdEY8JNnPBq25CKK9uUHhUtmWD
ow8H92Tpgh6txzmKTypaZNV9j1HZ/NPQoXr764dEe9/hZYX5P7esW6EXZBCxGBDr/Pcc5wL0nRri
1cGiLU4GOCwZyjmvl0ItP0Ep9JSmRmPybUZYeMqxVn2kEBF+neQitRvyAYss2S3DTmpCiJXF/xl/
qSptbQ7RnBtibiy1w86YknNEbCo2uf8X+75pH9gdfYNjDP2SXc95UBXjKdMzMvCX+bxQBBoG8LXr
nCOWDYZuqK2/c0h2J1DbCtYIUnoB2Mshx9uVVOfJcziJ4ShRhKsnQWWfxP/W6s/ow0YOpf9axiJf
PINWkqVg5kAdYKAzZnQb5ABrJuD7my9Hah8vbCZIkI7Yk6Z5L2qVXVPATvWpsXTut+MxiD+d6rNR
bSKI+cOzbthKnAvTwZUbsJ2Xe3Bnw8VnGQJAMYAD4iYzpMGhfll4N9+A3slPlHrwqVzJ88QlEHGs
ME3imTVLH/w5ia4EG1ZKQlk4RSVDrHVwW5aWPOSrWE8Ya5GcbqOo4Y/y0op7moa8WebdL1DKh3Xy
WloPYpR0pvFa6HwZWMwX11SZGiKVU7QHx9cPraClDuHKJkNy8UJ3FsInRnQpZ3JH2nN6XLKlxMO7
MHdr9eKitrbywtCLGSP3PWcA4yjo685kskDkN/7N35+/zDRgyPBUvGIdgTJsoxZu/gej5cS88Lhm
sIkQy572+BwhSgD7G34rvMvyOyvgkzL/Gj3vyGMhqMOOPK5uk0a8TeWBdQz78kzA3DAXcs0nJOFj
2p33hQ31rUhysehOondRXX3gldKdqJ3JJEQybkio7R5U1Dh48JPa6yivUjrDfN3hEF/W1fg6IDaH
YeNL0VzmXueoPKYa5C5/AACelSPzfgZZOH4PBKqv7a0qYf0FJCy+C586JkKdhmaA8pTSz68x+G7Z
WtcdsgyF+GsQppfLejqtyP0cO3lGomaAGnrggf3zcgKfkKHMsNLDYy8APypEg/ZzmNGECqWRidFm
dn58EFBIFJsjnmPyQcbfnSx1Kq/E0iMD/x7OuRxr9fuqXQY2SWby75FNqkr9vWtbD9nbbhZZa/Du
IlIS/IU3uy4jJKLe2L9D77f8dnkmpntB3oUsQwnw++rkLRdB5esDzORGOi2zxrJmLklk7T/VDli/
bARdepezbj/2S2AfsIZMBZj+jTsCK+DIY7vTdPmLkLSq1opHDPydNckKUcDgoyHQFUoX7VdSGQlV
N4nYcIr/7Bjw/uvZQbpgnIbYBhBn3I6b1m9Kwj1oTzoQy8p0U+5w1KDdp6fAUvcUoRzwynx4qsZV
xarbzP4PrgDOKzDXaML4yKCMcY3bZVmrfUO40PHhyreAfF4lh8F4A6cohmDVRnRgkIbSDnk8QMsH
EEohvk6wGZXwYuzGkgQqld2ZYgJFJrHyg9lUBtI9I+Lq6dOFZbhX4Mta0VSNwetbh8lurOvOiw8h
MsCmNwmivRiK/e2UBAU/zHHl1SFgq2yAIayPiilRaO2X7OFJnm==