<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+7RQXt7ZszJdXF/9pur/Ykviql4bXVJMSEkTMOog1MdmvGm9aZlQTgt20DNpaCT35EMMGXE
+q6sh/oEE8Lkn27KPw3R17+kT5KI/wIoA7T3KsiQ8Rfdvj/0ijTEeO8ntvCkM7tfqwvdCcSGs5lu
wvpRNyPhAOMraci5uE8rSnAGiG65jQsmHE5Q2RgonufjiXog/HXRuh6UTwS5GMpaSVcXr8XmBJb3
6yRtoFSrd/LIQ0DdE0w7dFmfs0NbCODDpvq5+2wWGhUqcGaC+aYu9mgqhlJIQUL/yfeob5L9Yrvs
beGeIyFVTiqJMqOtZgj+maE+oxV2GEcW9K5vXTbS3uq2I0YzbdalLMTzoMAFJxFvXjtS1CRoNqUd
MHuYxuXIwAvXTP8F2DdSEdtNhX5Kg3jvy77MyF6W5U1t+EghK9dc3jlrMP6ZmcWoJsxThJR7ctMJ
aGvE1mDzzrFalFV0lE1+XBIF6cwADPgVngemHz36PPDEJwKgR3JlsyvpROE5DHsGiKOXnsWoyzrq
pzs/afwQnIIBmjeH/CtmbW0UmKBkEFLo8fIueLEBeHWxEcQ0X9slA73fTCyK88reDqAsTI08JRCN
+HvjLLKiMyGPu/qPqCUE4K/MjkmBz5sCDcaooL8NRt1ebB1t/zG8qt+aAiQWo7ONItPDX+agoHHS
cbTmTBy82xgMo3SGUp8LQVnNIzs/GnncxSys+twVI1nalYlWhKFgIalGcdfwA+2tRGyrlsfsfa/z
Gk7exhNtr/A2xtcojR+b7dyvhHSGy/45nav7nvhRVXfeZ8ynTpdXEl5SUkH1wLrYE3iMHitmsRZr
Ljv8CtZLqhE0aLmHvy00gpMpvd3vwTQtBarnr6A2iQhCDMY9/XRbZnmJGSCr6fpGAYMLfoY0Tj3C
C1VFGI9UUP+TrzBYpaCBDO3zYJhPlOijpGt9VfVToRsc186xKwednHQVR5lfpO4EZItm1CosB7j9
np9Ge2RdP5ewdTJuTxrsZdhbwlAY341cudWIjlhKx8nKuQ2wjaoIp+KPg42FYMEf/Jr9kquDi6t/
PHUAKccA9rswdPh+0yHWnTuZFNUFGO01OjFGGZ5XHLOeg6XdX2WYOv8Q7GxWkWjDoRsoOhYVchAZ
PT1a8HoIqC4/auCsyTpHs5vY+FKkwAmGarZumTPRVZCmiAj8q+jL3msrqCLYr+CZUWg2Z4ufCkHS
3HycKmhFsHCc6TYje/P8pPaeK44Tis6UejslU7/u+T0E5Bt6/AK8NXR/RfUhIihs//kQ0iTV2FIQ
6jYh5USM48zVm4fKMBsUDgVjI1NI4BTYXHqJ3paL7jMSHWz1zJYhAFBR9JYkmnOv7b6pXA2rZrIk
29JsXt1dIf4iv+SIA+nLChMJoAzpwo+EhvVDm4zpoSIY93tuIVoEX8nRh6BwasTwvBL94GTmUf4E
g//zL6qqZX0KsTeI+hfj2cA90vxrOK/Z2DCSn28zoARS1VG6x7ZGP8sS0F7NTMPAlQo8di8l8268
phkZN3CzMoMg0jEbifVgSgZVJXHAbyKn1UVxdDcPccgFgZNKBhLzx9/zOcl3m+KZ9NykY8Ov4jVa
SGHzM4p5qS+bX9ZsLms52VXv0gl++0JavVOYC4zOzsqGWP9rS8gLi67DZFoEnaOrI+iQa03JauYs
6GmO7W24z+GeqE3Z6wOfE2pX9jcpPyXzP7qLhxJELZtuMu2t9s27lomAMygcaD5dw4Ixm2sFrka6
Zy8lPM9f6ARnAiQTyvBrYLu+nZrpI84t1kij0tHtaigsPeVzwhKxR8BjjBBifknBXDorR7ZYPSvo
obfPTQDftkM/RHl35ohDDIcd1jdxPHagncfSl/qLAxJSdmWpIHkPEOBQSlxCgr3IstV+EHyCpRRT
cbqDPUEoXw7LEl9IeE3aCRIDJMFw380dmLnPMjrCIPlTsfUTZrrDLi3yJWIVGEA4R+7gg97z5p40
51puFmmBhHZGc82pVuzbmhxEJLCdxmRDB0qSI/54J5WZz0ITlVt142V0HUbzYJZ/fEW08QnwxXvD
U5w/loDBjb5mKKI4wir+Gls7OU7uE97XkUCVu4sVODWvTAQWp800G1B6EHlBiKMg1VrjbFjkPkh7
KKm2feCaAm7E5EcfSEvE8F3gyPRiXZ25dh2wc7fF5ZHovjGPuLn8HiCOG3ySAXgr1KUC3qAgshvP
leRqAI8hqfxtgnXjuyYFz5RT/Di9WOFICxkqide+yIkWCFaQbjsDbkaWEq5XzrfYAGY5/bu0mLKa
nuTOlhtEaaXNyzRWcHOW0xXoAtR31oUYj8bZRaHsxMTqTbx2lEzFeI/o+a2e4UfvM2NpE8xVs40M
lrcmB57WfU67zQjxaDH7sQPWHn4enUxTNvqPt2PBTjXYCwxEmeSN4Eq4PxXBlnzVrctNCH9ukKsf
pKWrG0OWN8hU+j8w0PYgG1KnAZ/uZZcCTgjtPWwW2dUJ4c/NHEr7+53hkNEmnQJFRL1s1v18gt7L
W1bpua9iCORGDNbz9lHVRXY1NV+eiEuMoSUrI8843zdbqYm6um4oEWiE059lCTsCuGDuwDBv/8I1
mR2iamPrKqSZSKg/AWWBTkROGGrmYbtzLlTWwvfFA31gywXZpxSpDDzfkxrf63SDHCiVu++WmWym
lEIw5vld2kgR2fogMht9kFmfN8jGraUBXK0dGigIGeINmZdiuHgDkckoWAh9/Syzc84R58rFjAha
4fA4OHh43L6/zRtJ0SoTcwLp5hB8595IdJZzEdyMkvWHxQXe08NzGDkJdWNJ3UjrRWKuZWG3aFBf
UbzYksSdtWhdLYpMiyewHgkVORRj03gPCM0m209vSl3NcWdpqwTyFtu807HdqSMHNn/AC2Sd0FAk
0L3B0H0wEJBVRvtUYmtvdK2WuT6TtCCLJSvmKa/tTngeT8jSDmT+m6G0Y5pM3QTTlY7HuLKEdI4S
4W0FwINDqJzA91HMMLmWOii5QjMFYFk7ddcASijiMhm28hT0S6zWmXH/2P0JC2lfyUVSIF1kPmzA
wFftPdRZwuUdXoj7ysxI5mjr3VdhgZDVgmGSG1BXIEUyw+vD8/pfgOk0S6crgSD2EcNL8J8LczKn
0Vy9r9uLnjAIAs7Sn8sSftRdhg7OewM3K6axW0hLkRk5hC0YgW3NYDtqLdLB1b0fnQsl6NHrVdXb
qXGD7a/sI+pSElkOQAdj+KQMgWPGzNUyTtZgS4+kBE9N/teU2Ow/XZCVTLBRGHRwQXNI8wn2fNRX
EmLMrLCl+fdOmuVR1++Ed9Ry0eyAQNHLGtfYWfPdwg7jPK285D+7xrxL5whr0AofPPjtppQYCCxK
uD566p8nxSLKzXUNFkH1pVIeHdLupuKgMLzfajTI7HRseKeOthdKfpEHu/brYYJH3pkTo8AHxY4t
e8SMRVz7pF1Uf8Jwlwi55RRKw/ORxwJyG/6mE6TTTHkq5gAHjyOU9gYeI1bA7tL6QuKEvO9GcLAD
MzERbxjScKPGTAW5oozOJuLqMaAwWCcxu5X72HN0naF+ZVqeyQXKu5SMnaBqCHnnzjV3jG5IuI6l
PtAbqkHLrow4ZLWS91e3sqo07ba+eklwutN1weerIsC2bwntZc/GlKcnGLR6UnkbFvJQPjCq1Y1y
Pnq/fTePgOmQwE7M7Zg50Am4ciu6GoBx7ChJSLNc57xwqVBAVXiFgCvw7aemK6vXM3sD8VVQc8mW
gLvSfVaWnc9VxD9bB8cqfkPueewHez1eXOPG1ynlANucu1qMFtLyAkkLmsCP3Yq5xZafQccvFLgd
KPMRvo1TIf7ZPPAK5+Q3+djbOqJzwXEmn9hLfXtNGTYVxSD5pi5A8NBAzIZZahRRIs9g1kIvRDFN
XXPyVFUoNc5AT2p+D3ds8YBij6LAVX+unJMz2VepR6znBZT9dWznHt04j03McZkMWgbhRsGT8cFw
V+F6uGvWsO8NzRwLFvDL3Ve1bsAH8pAGXYapz0paUNvBuYdWXaW50ijkZt0/EQEIatkq3eSYqjTG
FU0HZN/OJgZlP2ISSacZg5Qq2jP89q7Wi3kecFdBgQA6DOu=