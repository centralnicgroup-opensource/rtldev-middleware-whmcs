<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPndumWXuGpSl1KzNAtvMhlO/a2ZLVHuG1xcuTO7UObsxonLt1Y9zvEzZ6YK16nb8InxHTFHi
fVqho71H5lZT2hhJPVKxDZ01iEOw2/8MG92asxS/EPVqjNuOuacpqXt4cUfMtg4TclCmLaE2xjKb
ad9QZrufcOE1CCnYZ/CYv4JyrCSkA03CIg2ObreYol4arbGHqP8p3Rk2oU9v+sSV8L27/pvzcygk
d4f5k8tAIg5gMPc2BIbzhZVDf0/oPGoP5G6tuWE08QczgikwJwn775gX2TDZq4N5nuvKep+a8Qdm
HuPt0KINO9zWY61+JuJx2Nbl1TMh2jVQKQUpaRDxzoMX23TPdvcOZs7dZMLzPlnFmgJx7UC6sTBn
7rls2ma7ux7+i81sdKzz41osSiMDdVTi80EujeDBDyK8sEUUkJIRKQlJqYrVbGCgvBLPgJGJqnKI
VI5eRXCIM7Ilk17gVUw6VccC2BnflpfcJWLxWDWrX8Hj0tlyLsq2I5bG9dyIecoNtYmX1HqRIo/i
Ixb2qnUGIyZqajxfbTX3QJXe2DYgJrenWxL3gH/xpPIytORDD1iYQwndJrGx7ZccOayEVW0nEEEY
pfypAGOIa/9W9bRlUHlRtVeUgN/ecWAK7KKFfdyL8qKIDJCRgNt1DemZ9RbyquwLXKRWi/vKeFGE
ar0ILKBEC8B37xcO/Hu+8LYNDLglPjPxB+8gMVF/6kuFJD+CHrj7sBiRfscdYXB+2xSzP0ngnW6o
tLgyMBpwnTapHatZInmKczb73ZIoEOlpogKOYn6PO2KQtJApJKG/rNGKh4cDBno45WXAyetZemP8
CYGsOAJEODRNMT6tzY3l9uds3P3xW1jxYB3eT6w6SiFmfTTkW8s0W5xetpKW64NbnM1Bl+li+1Tg
guLxM4KR/DarHaRS3TgEwPKxoZJa8H0+qchgY4IkW0lT+61qcCrZRyIdmgRDfiTZE8jm4LSC4MCj
ZNeFw6lusorFqp1uGiEE3J1P503IxMF9a3MbLaH7+PtzVtrophGLfg45Gq4=