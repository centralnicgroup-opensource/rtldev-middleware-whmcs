<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsUftCSQYYNeunX9vF2J8noT+S+SGvRAWj4uU/w/BLTksj6btX9dYeztqOkaCOd89+1GnYcv
N9yBWer8kvpKcYOeQSMBMg2J2U/SqMo/mitssD3tTGYCT6lhE6/JfZqR59FHCkDHEi6rSCSKHzKR
vrwpxfY5eQ3hEi/SUqd9YsNtM/t9ONUFNcfsV6XcdOaK6ufSLVxiPu8U9QeX+V10dxMVc/g04t8l
aaUX8sG9hu9ugh9/GiMN/9JqlO7On64rx1VwwVWke4Atj8493Ff8k2SAjAxqytANBhEWohA6Y9MJ
TiPMPmzxwBeLsrBIdIE6I8cuasDigYt+/DRFE0GQ1EVXPj47tfzk6oRnbckLFOUGjz82gQcFV1FP
Judwg2mwax0nEnT4kgAXqLggJslF0wP36sLWaJ+fOZqMYaJlBceCs6IfUoqZQF7xbSfoyQs1HNCZ
2hr+8bNAkFjf38ivae7EZyqYWoN8bj+I+pEq6CNgymyVMzs7I22t7G11gNEPq/MnK5dRaFmffkww
gBTZ2j9A/chUDijJqqtNYfCxEZ1tpKMn472wnbU63WNkXj5Qf9PL9k0EP2j56b3RmLYRzm60uDJr
i58f8hg6Uy/0UKpB+nK1wFfCethsHjEYYGX2V9vdKQnOJFJCOEqhIrcQ3lSizo8gHHhBewO9ZKB1
bN4hYkhnaX5qtv1tcvmPwNqpJWMsw1YOeZfEnui6nCZkv1Sn8sru5iwPiEZdImO6tZkKnQ1jdgDq
KEECK/qtrj+ucV23CAKrW+jYke9R11PcVE2QBVV2etnmp1iOl3FGAnlQf3RX7/fcD+OiHMOEIbf1
HeB8ySxsQ98QNJk/eQCbyCbU6MZnmUMq8ZOor+3tw5uK4mzFyDzmBNrxIbZaBrNCocXX+/MjAs5q
znaD+DEqC3vnJHUr6/pof7Nj4tfa3/EBOT+IozVSZbQWzVah9loALMdu5UJMbIM0hGGHZfCYiWw1
xAqj+kliNdyb/zHfMt6FJ8MckxfUSMbBgnMSxRBXwLYnigPDxscvgIiGXggkmpWM8iWec5cT1jlt
Ser/wR8345Kp1/lu021ViCxVno0F5SaV0BDl085UtOSPkaRZzXgKtQQHQbunOf69+NwNygJO84UT
gwfqeBQJgAH2w1r0pFebDl6F5ohvN9HrImezdvsUV1gLUMI4pUFjpVxq4yXWSGqQ4nY8zmOA8pzF
N0CMip4IIZ6ECmA3bJs8p20WE9hYrgiRAO8kO5Vsjk3IMzlHPqmq23fTwcBAk/7mgesxAtRL9MjX
LhG3YfeAeKl3ZlV5NIW3g6PbGkF+bU7kMMPkIrbSHvuVSWiCHO/pqdxyAA1vcK89wTjJOdveNCOJ
WdfiBUXp/TGzOZJNx8RBQueOZfzinrqsaEd6cqSbD9wblMGV/LJZN7DfqwwufJIEl8pfEcsuowSv
0qma9Zd6moXcK3s+TxROfi0wm8HD39kC4rJZoVBZVx+T3H9BWkxXcgK5KBqPW+5zCWS+FafDQs+d
VVZxrfhI281QbRDEn4xpqk3IYpjBYt+cKA1NQXj0j83AdbzMn3NVEi1RcgKvtVo9hrZX7Le=