<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPr/gLzG8DwmRrLl2zyJ44Gb541EwGjmA9BkuGHs5X31A3EIqRBqLSXCu6Ygs2nyfVvYPKRao
JU7Ik0TKdRgxAksmLSo2nHxJSWflliz18sJ5Bt4TezK/bQLzss1mn7twPe/RxFWojnnyft5BESpQ
FrLZAqrdxKd89iVE0P0gLTQbyS8ktgxhjCC5hu7TJ/cxukYfgoL08DG+g1EVTKRcCS1t2Qksz83s
CGtAPwwgPhsUZC22DP2Ru9/RRIqkQi5ZmhPguWE08QczgikwJwn775gX2J5fRBddV5gRIALGPgc0
kiPn/r7OCijl3y8F0ED5RJ82+IwXnYew5rxe59oBic19FvGbcwDulmgGHgsP7quUJtDvBBZss2it
LHe4l7ZHkXFKedOkqfDREsHfBHxXsjSm8ogKBdksW/NCgE5ixSGvDPLnIwNtbve+vYizcUByEIsu
UH1UduKoeqcGwe7k5alN/kEvuIG+kc+/KNPhQ3wc9gFPSie0ZE+hYCbpO4+297sijLanMOCgmRV3
SM9aIKNcbJ7w85eOmomuZC2gUlJuPm0fN8HZ6sSFGDIswZDnPMH9geaBogeDrMaXhtpTxJCKRE4f
sXxonLUb130csSmixGGGIOK7M9+WfOrsuYeJsRrEyof2G4Jlgbjo78kTw4VBV27EI5FHibkKO8Jj
BSbrCVRabRwB6U2aClZi00z8+1QttURVkmBepFnO7IHeXBV3E6thwgU0YhWcH7H+H7XeZMLoaSWr
90zarlrfytiAiR46ScSLG+VgaGbv1fITipa6RHGsJ6JwL8zhn3ZPeRlHV7jMonjivGazfyvgS6ih
XfGg2zDClH1/hGmKZsTwYlzvQnxMBvbFzt1okcGX04TExtXCaMUwzYAWBZ+ZEj7AERISuG3KGIEd
teCXv/uO3aHTfdr82RfkuhvtNN4418umZR+VGqPRmRr0CBNyUpWe8hP798a7IuXQyzjdsscZ1L++
GOK5A5QSv+INzKz7I/+Ru0/G7KTiWbUnG8Kq5aZ6nKHM6FEziUipC7yTfw3XhqNq0ti4CbhGOBja
Qe1m2uxRfXDadsxxk4SEme4LDeija/l+vj3tK43fjrk+f3VG+baQq4XfR0MtjEoPcr5m+364m5FS
2a5AH2S0t+1wvDqIObb848rG7+a0+tIUer+vTr7U9R3zjzcSRlb8TLe9imlwsXNMxSSNUHyblKa4
NZyWNFnbrB0pPyCIAsE7FnR8fqgUog5dCFiucFNXvjZkM7HJy1gn7fSDTW8L7ZWUO7TG5n4QRbjh
9ASb+sgbngf1A/dcB32x8+ru+0b4LIUAoTbE63vXcLNNabLnELRMOzjOAX/dhHvD1XWZvQJcxsTa
ScKw+tLo0iduBlICZUejrmppc0p0xLXNervqmvY4G7mSM0PmACBkE5nkswinBs2ImsOvLM/KDxys
Ea0+ToX7nlAfOBaaOEuAgZty2vbxS6aDVNQQsiqLlmkh/mUG4FXy6JQN83xOFLKCh6yEZ6x/DrXt
bvn+LZwpJQOepAeSVz5tvfDZh2jphKLJaywewgbcHl02E2EqeM0kWrtskp78JZe=