<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoDV2Gko2l8iIvUSA1NbJ3Imd5kWgypQST+kBTAvmdUeBTrGlaHn33YN36UJ3jN3SfFaZXuB
NO4YQjLjkBbzAldJ1Qb5/0TvPcnjBaYaqYE5MRj0ro6JCy3GWpFQBwhaL/TBBqNJAXR5hXA8mYsC
pGHcEKt03MGOZdH9zxBARqFg0pFJst6ZCqdUa32ssCJsXQ3jUeaig8z+ZfFHZcXGXEwOYzE+YF3g
WoaCRDqpOSUJKyukSE5ZYxUP5cOUNmhrUNNp+2wWGhUqk0aC+aYu9mgqhlG4QHKtOc9NqYjkGUTs
fXad8Wd40eEZhuPXZr+2H0WIZfT0hXukUrpomHMHPBvtLRdYY8P3uWl88omb2ca5U7wVonZjooPY
YTyBInkp5F/dzyZP52FP4TH67X8uXEfRJ4PRlg7vwwSDAUfRiABxU40JBiBWFWSgGpwzG0hisc9x
KpHGTN6+VU+CaIn+9VclfcTYwFy5zpG3+vZtcT+EddcBM6tlXSgHsX5zX0Pt+1CUK9Frk4c/deEe
O9IM5uG3Dun30DM39IvCkO0UFpgSn7Kkzc8MG3Z5hPGZyITeh2PAW878bZeaLuZYmct3lv98PE0G
cTpnXGj1iUjVwb3AZ4KVHg9iyYF87F148u3224zYreHZGCwnEcSZ/m8wjikDqkWZUj0Tqq9Wob/V
9FI0v8Q6E2wkwPUTqKDDYUAyLN4fdxlaT31p0T4A752kUupUvIfhEHBcCMWFpZTtu0hJx+q8pSCY
3zujM6XkscmC6orIL8lOdgL1RP5D6oMKuac8hgB6IE56tr9FnB2QVXfZe2f9wTt1Z9VcUf4Bznt3
2CcgsZ6Fhp59PMEogr7jttqGLqVhkeTL+4kYkXDWYL7/2wGqrRfBm6dD0BjNc+BAKGlWBdAURXeV
6sQ6CnwuIfZl+Vnd5wdRCSCkNBvPiccvl9I6DaUMM/mBNT/px1t7c3RnLcvaxrqf8sCxUqlwmNWw
uBdNZntOHt4hxpTQKfYvJcAL3Y7vJQwZ8rqgVf2uQ1s+fDIYebC3BHEPTv83/hT2MjdmuVMHt/S3
CuBPvzAHZz0hsnxmk2Dz8rbTY0UPm41NcH1irtZuSAMqC+nFxUfIiEROfxVHbnfU0GAUlpS/8J2k
AEJsEv+0KunIO4nOoSFlp8ouhL8gBISUpNbTQq4FoFTF5BwY6QxPVOONj9kFaZZwIE99LKFiYc4B
/pP8byeuOaab7q40h9BQR0XEKBXiJJHZ8nfFFg9FW22ZEDbRP8gUbQYnFPXfXVa2tqFg0rmirGD+
2ANbgIGlTrezA7TvWziGGhVhXX/ObCZlxbzUMtp10Pq/cYD/QD+5HTPGkj1gMzh2Bfq0JoPrJ7CO
7kp6sgA0E5Er09LzW8H2gA7GFYhY+4W9V0uev6Lvrz4GOqHvzIRI5IYO9XqbRdcEw9yoV5Nz45gK
wd/0M2kzCn1MmzzU5wcIN5V0ilw4GkCGIvu1yykf0GdRW15lece6P1i23cUbLyrwzuLJAALJb3fD
oXbWQ/dg863BvMQU5wmdeOZH0uCjOtDnYnDErXkLN8KfuSiHZiS9OSLt6von4Uex+8FOUaTNyhMA
hhtL1sxIwPOLWMTyHBKPxxtU5VFpRNziIN9p4Ot26LKEyJ/ezmZF+SLUSGCQ3+cpmLbtzI143Lpz
Nqziy7T6RDhlilSqHvRYhNQK6Kjps7rHyzR+b9l6/uRTT4waUe9zdE5IA217XL79R8Fgz9ZQV4Wd
FfNlzJcKiF60RgdwbZ3LqCxxIOgOBY53wqkyIif54iHqJHmp30VbqwkEFM7Qd2cLI+blbTYQpEXC
rxcyfrwD/dHutLRT0YUfebGtdYJJbc2ToQKjFIoC+ADuJ515SEInE/h4dG0a2WBd+FP+2PWG1lBL
Ydzkng0QfywvWE9cNQlF6dL0Xqp4Ek3aGDciHOfxyb4aH9vUgo2FhpdRp25svMBohlcj7a7Nq/Sh
JYxqR3w86GwVJHjw9h+tbnxpsSfBctd7QE92KRuga3vutmUWXsci397bOmiSgdv/wI6beseM3Jqs
rRL3zHe6tPEDe/C6kF9PP0lyhq8nCBbrAhSVrFLpTxd0IVzYRMWvEX4GrcY51YnII8eu7KX5dTX3
o4Ebbax7yfAx2fZGtyZl+o19aVRt0QabKQF8Uh1qwj7ZcqW45S74xTuLm+o8AV/D7OZvXpVy0/3d
Ms7zUl2s3TNYH0TeHce89uQJTF+4QIJ3LfjsVFZ6b7TI0uaQ9Y9bkq9CE92r6cybTfaIVxAhb6ql
p9z/zCS1X5Kvt6FDlNxKDQcZZjBpMNeAqxd/dl1KVmWj1cfNBrw35ZxmO1BUtGW26vw3zkSownmk
ur+VBoAvpqXtuWp4yA65q/s4NDf1gXvaOKqLzT/WIl/Nwdz8slTtf4sAUYTWEB2sgyrTm75FSH2S
n/4E71I3lrZ9YgGSkByWbOHXqm6K9CMSRAlWznPqZjOmVKoq1mM2sl0uRqgW5dGU0b4/ZF+YnBTE
xXG0KF6iwXR9ExS2LBcVbtnaPFkkejCsAGwDYg2b02tjVD0ZIzlrAJ1O8FpmVt+arGAvnkDlB7fB
vGGQRveTRHLqQXjnOQshSU8R7oUdQYRY7ErzEftCwhW5Oy1aEIINvD0oEhB5PRCzQodEW/kqW0pA
llLwjArihtkFN5TDvfkaEIW5KnFuxD9WlCeW320JJG1zFVs0A1lXgdb5t/pd7bqPL+ITc+LqQmUI
eQzC1fjDut/K/8oe2PjLlkvLHSMwCbl3yjL7dKpsvAJx+uaY1vo3M+lrmo/xa/HmBEkLCJNm/Lpq
OGSDPn+bUvDWQjG8hV4bR2N2Y7+w/zF7iO9b1x6Mu331av5ph6nEfnrOrsHtRbpTiaBrJdankNcG
DM6wwD4JKAXHqeUFzRO4MKMfH37hzJlhd9mzleFbgabC/mzsfeRNQe6gUwA2Pt3+dhtwLnC5k8dN
S5olPpX/W0+43vP/hrc3kHS2GY5zzsclrdIJwrSe1L/GtPCOMeVqbCD9L/OMJhex0yN+ieK10a2b
N1AgugROnHsYEmcAtGvMNqLm6CMEKKPEenFrxpCikEw0CEaQUNo4wsIS9SQGbNwecPEEmh5qfgR4
phxH1f3yEERW5qjbmbGLNCPx7HxNZvnhirL96ts2Ooa/70f5wC0S94xxZgwdkm1Cb25lAMItsxlp
Sff6gxs46qRR4zGhw1wNX5L+Z3kbKQQmqw7/SnROl3zBy+D2sGd7Tb9wy9Nv4qoaWhEUBTQkAgSh
d7yDUjfKlJSw0/hWmHrJ2sge1Cnhil/A5ItqygMK302eGAJMFjcveaFp5u0ZWD8azZ/yTNmH1eAs
bGI2guXzWsjlbCK77epp/LR5VfiOC4x4CCb6wcbdZpU8I5TN2gy3RBET5sod7xn8SEdpYEWALarB
fxnh5PBjRCDB85JhUR25Hj8wEB266N0N0iUpfwV/WhQmQbA2xrf4o1qbt5SZGKQPNocF3QfGWwsB
UzX+wnzCT2qt3S8NSrB2Nb4ClfmeZ1AQ/xwiG8YTjly5yrIq5YP/1HLmvITrt1auOscG8OZu+jPL
nT9CoWDm6kwUnRZD2ENTJVIwdi+UoTMutasVT9JM8T+i1iNYnKe17vo7S1qnJy26eCyvR+xt+5UU
G71uSvs3aiPqwJvuNrVMUbPPzvcK1WUhtTig84+fXfmR98tgy8bDOuX6/rKQ7POioBw918Y+e4tA
/L9/wPvZ9MWCD3Ev+Pju31sFEBeiJ3XYx9Jijp7Cxba7K8ozWABtf8Dbm4eco8onDWDhPNDsQS1a
XL9AQFB6Y7hrGGRXYFLC6DlwAOKri4UbMqB5yPqslRFYya7H2meGhV66IPtOiciVD4DuzgBQnq2A
L+biu4ze/2ocHg0C6WGDG5zI/yECB5WISfS19IgPeOBj0B9EX2BWwMXmTZwnkPRwTdCk0CJGWPtR
/1k4hOTJzdcjFygQ9EwamoGamVUaaqCtWVIwdC5CQsSIhUOeprVNk5sMEukCD4PbmXcg3r/zuu/y
pZtkym8b06vk0IlTkX0wJlZt0havIDS33SF7sOcIQzqiIQ80UkVBv8MbfffS/xPe53Q6fRE5eBW=