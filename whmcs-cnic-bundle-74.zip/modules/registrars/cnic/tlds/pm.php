<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrPnm5fNrJYTBhbLUUMHQ1L19IaQEW7B+OkuQ8n8dFQSu57A6b5v+a2umUSJwxQKowHDl1sK
u8BVPsB+qMAjEG/zIgXy78pW2iFEWo4GqizP2enz5gO+j395AKtzSUAqkHkh8FRNIzNUnfdG3+vp
cQRQms9WJ8xRCPQpzudjhMulrHxyEsSLMCEUpYzcTeLXNzUvzm2oClCZm0aM/nr2pH7U4KOGJ3OG
s7HbTUuca9NDsPV/R09+988d7itDxy9c4lntuWE08QczgikwJwn775gX2Pfg45scadiXPwZd8waG
oUSu/yQn7M4LRGF0Fe3wtnFHIdjhcPrClLKt593mGgtlX1uLmI39/ln+K12NSbHzgA/maErL/T+v
79lASatHfTRRUm9teM3sr2zfRtNL6wK/ODRePk/lgB+ipwS3J6X6wLE5bDamrM3d6wk8ppu2Ja97
O0ptAmWG6kegg+qWMnkf/vTdIG/xtG0F+vKBLL2gxTRp5OjRjwjJlwYRu4vgTg1hvyBJY5onEejI
83UpMRm7oYZ7jtDxUQBVV0HC1cmsCd6ajUBaZfXg+TfESSR95SxYLDBsSdstQwCHYgCFisEFvMzt
PfQy3l0aoOuraqvaSLR0B9w8kuPHax0LSZKqZEoSSnJ/NiZ2rB2APDuvqSsE8rn50cdS3uWuQ9l2
ivj9Wcm2ZEFyEroydCnoZd77daG4OcmxDVb4KUdg3EQRrgS5bFjIjwZf+4iCPODrwUqlj6oCJde7
5J1AYm2P8KsEYCQ7dN5NnSPeXt/eiFKsKnhZ9xpeZjL/4/jngKt5juM9NFpq5gmJDINuqQHno1Iv
iYznUKnKccRkePE2kDQaKFAB4/asTIaEs0QwkDCpUsqvm210I/nZ4ZbkCY4exqS2Kg9bFsegcoxd
3G2RZP/ruDwfNAQEgC0FgvqNzNxFH5bcKKvi1B/VyoB5V7zKCXymN/4skes7apujlrchusa+hvdW
FmNx4pMaQhdp2Ut6XR2BL+qktXYI/x5rS8uYZkIcdGW6nErFcsO3RMJkJG6p4rbdbA216dqemjcV
LPCVS0+qhKGF/oTzTahwmbAxfoYGT0kvxQolbcUFt0qK7CjvxYezWf7DWWPct0zZ4v077H2dut3S
J6wS4YLsExw7Jl7PyEYsxU6YOXG11anIHDUYx+SzE7g17uQ3cddU/eUxOYhoMvoGgOYDC+UGPOmf
6eDBzlq8gESvXdJ2JTnRk2Ki3Vj1rsGVPF7RP/DtLj2y6vx3OgbE7xqUsPJTDVOXzWfi+8q7T01F
bMhxG+bSL5I8JQOWdP7L4T11csD5MWPjyMhvXq+T5V14MAWapur+MnsSAv7Jmw7IcRagE6K6BEs4
QExPaKCpSqaUT5zgt65qBgTq8OkvAcne1rgWdtBg3KUEWn4z+4pC6cm9vQP/li5W+fBuLI/FsUxd
q49v6w/AnHqc0cxd3X8GjvgU+5X4HxjbZrMdRHQLfrgd6NqaAQdV2iXnp3IG4WwJiXtq+jMAjaDs
r9w7MNTjGiMGTFKBTmgDhJfbmzrNQ6ytVl9p3p3zOMoOArvUkCU6DjOEFpw+rce0qkxsO7W6IGYS
nrdgWbvpFSvo/+L1KxdG8BvyEA5QV83TMIm85tpBQiE+a9YAYs4hC4u6aZANtKT7fCjjW52MMcD7
ViPmb14CngAchQCNyvoBQ2I1DA0wyLHt9EzutBVLutbfiyzYV68dIhJ7Od/fhZ9T8r8CisDoeF/7
cmt0Xap6NvlVHb15Xn5rjs9uZADc52jj1mXfmPk9wMUCSrgseSE4s0aFQwfEu/VtGG/33IsZfAcC
/4qJGKiUt5bRRAVS4IECJOWYhFX/V9y/IpfZRBikxhUjn7jYVGHKBFM3eJ1CuZ+U2H+QkKqCixfB
jn3kYXfjDog0tTcAC0jkzaOwuJi/RrcETTxqCIb6oX0QJT95oxFtAkd6uT15xo8zJ2IvnfNZnf86
JiNanyNtuONcr9SufOKtUwi+5/XfQjbQ4SMgfxQ14ltp6WCPtdtQDLhgfpCAVptPEmxOXYR7Qi8C
X4YtJGOaw9kd3Jby25helQlnnRTNTCYEWTYQBtOpLB/UUJhK2xrokXqkJnVyQ38AFrMlMluQahn2
IDN6FQ80RtoEdToD6nksdixMVUWso94iARQ0MaJWkf10sB2ZT9VYlsQlptifhFyPrmW8D5U0wf3+
3uhBg2rl8yE2G0Rfy2KBMPrfHG011BiSICbELJUhxc+2vSHGgiodesD/F/XliiptIvtwk395m5LZ
EftStF5ZiOauT5eL/XUpzt/3bZlZduUe8nerdn5yyZzXxEvzcMx+gz6n1Xqm/QCNWek4gM/AdEqh
IF6CZg+wDSMsBxNVx7glY2LGyvfhd/dU6BC1/p2Zn0wd9pbdT79lFzeg1mc9uvAydHWApD4kU1Vk
4ds2pf0+eb8kZMRlqBDrrcnr/vRYL4ANhJt6sqBh8YE9NhT0yomTrDQ6TGwtu7FWXRonPKmOyqbh
StRnR+m6Bzur0Gc9FfzsmaZwUxOheyGMO2ilMk7bNh08FbqODin8psa7lnXRwUoQV9pJreou6oe5
paDMF+z2xhLvH9DjltsrP7RaC3jOuJkP0+vRX3Xx0y2q6TfE11e8YKNKhpB1gUbcfFRjDnNfWLTT
mTu8laqHKjsxyRxy4Q9EY/snewLB92aSaarID5jhjWO41gyhGM6OfaeBBiwQKcBK0aG8hpF5PN4m
4XmTLdzzmki6GpgbAb9gRcqGdosZG+qGae6rK0Pd3gxMnF6KM4nBkw35fuDidFPoaVOOpZKS8p+j
ujmlDOYuVvSAo7uccp0dEkSDaibepAF/Jazs5SJY7tqsWK2YZML8VU8bnBXVDLCloRP8MyRYayVx
8IeqevBjKCNiqjzDMpBaf4aTVNe9DbCqhU9W0ww3JPEW/2yV5Q8PegvpZb4J6DK9i6ruZMrXH2rs
7cQG6BPjRZlS2unldebeo4YPqnYbxTUYwqGG/dpjyojGFe58zohwlNgpG5Re9nkvwtdGSsrsgkBq
rZtgzvh8eptA6regWJZXHXx+/FNSnqukz5sxitc8K0xq6MR/2vVkMghNVkd2Yv0VGRkvQBXmlxFX
taGO3EQ3Zxni6RhZ0ocKjXYhCmilePWkUH3sm+SwapBKVWTj7EfnENpbE3fquLXfcmqF853TU8wp
bQ4AOjVQ9LRm45ZCWBVrLJ88N30N24IWVGTt3d3L5HMCQT75NjrmyQn16ZD7V7OTapYJrkkllSFN
IOis76hOJ0dYM44savUeRSugZHnQ//kXdFtbjupm+GIFTc/SnAWLjXzzL34B8SZTGl/QjvF8Kl60
kbBwwCSmooAaWPasD7JZs7wJvo2UU8DzwAoHMnCvsDxTwZyR4YsrCKMqy2tfAxsdAs0h4gxrKp0w
CT1GUlQklruM8At3+xi4feAXv++AZrxaKGyQ/u+qXB8SGicqQ8+Xvx0FbfW5taRlx9MFkDbg/Awg
9NJjjZhwJrR/8n7b+uMLlJaq6F5AOX91aDddHW53EmbksC6QCYnsV8SJOwIfBfStBPGQy/cj0XnP
3uktk8NU/hQgvnmplCh9T0TKwo9Mh7hBZbR7XEocX/i0e9mPGH7FcG4+w+vdPJyWPXUjGLeF5tot
Zq+CWBE9fxaJMmy/3+LtNTufJy9TTdBsjTQlckWq7Rq7GxTIWHAMUy+YUMVyzsH+nUtBvtk8EtCD
lZNPS++ZC9bO5Q6eYtJgiaaP3+5GxgIOPAdyVG9EOyrNo/lFsAbK05aJ44wPu6G7hwZp9IcCIO7u
VTRYL9a49yQGy5PBiOK67QNcVMifyo8akwZfd/EJwjnsYwZYjlF0Kgwn+HPMOSV5JTgMdI9Qfouw
gwva5aDTt1mzhw5tCBb4QSse/zFdxYiz4ZKhOAmMblssEMyJYF3VmhiFUGnF+LRGL/OAKIqa41r2
HgdiC0BYKz+/xHdiwMD3mJlzFnHUM9G/7ClG00cUm7QwXwApq6uOBIsYr1CN2jBZYsJqsMfHa4OA
A3HO7Xwf7AxSzbSJlaeSwqrFM1XTEmmeBA5B1i+vDT9JRNchPNckfG==