<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz/iSKm+VKfano7aR/YDI7Rh9X6NOSaQJVYk+dVXjYB2qNiPkrSC9BBKRulKRoT6E53GAZQB
M0HRbmGQ9OETTT0+wHe7TyuZhB5ozLYNtNcKY/0qffcLgA8OsUiehmWIwLz3iGB/9LjZcZ1mS6RV
nP78M0HYn6fjjghypb5sCTmtsY9lrwmTtNHr0LDw6rqYz+gdV2SRQ5JibfJOVf4l97WXmLVXr3X1
pjElHWhCdvnG6rpCqUig7cs9wcvtbkrNVZKV+2wWGhUqZWaC+aYu9mgqhlI+PyFmAs0ByL4GkpXs
jY97G//8LmtEZC7JkNT3nCxvofgn6bxAZEJHRjOpKa+ykGtUtRk2jTnahJR9OYs6uspvYoqhkFdf
j1GIYG8DxeEJZ2c/4d+ZCLwvu8L3h24P1gMFOO37XKdlD6YRHjDB4HW61LmvUEqkjgjPmUbrmZX7
ZoW3Kqrs5stljhtloul1gUo8OUaa78kiG4/MuIhOfXghzwFPeFo2QOrRmTqrLt5UGYLkc12QviNS
fegpmyNVeItolyjoKPDCoFC4/mHljHsvwPfzoyuDJewQgNJs7Hs0oYKXsLKauafgeOIPWI1ZVtWv
MIg2O8JnFxA7IKoZrnTkN+u73XRnEsO886Y2XWCfaAqf/v3DM7T6xVm4rhDP4defCqaTPdBsVzwB
5MxNSSp5JxhzY22LKOhhes14TjmC1Xu/MQRWLztFL08oY1HTZqzoU/pKZW1Vlvyv66/YD1ZF/FpE
lnljXynOZvw0bnvjhUcFyu5Cgs5vU8vrlLlkiz4z2P9QsQ9htAAWiH7LdFLkTJtvaVujBbY5pE14
6hZLdzVt/6y1XmgRPW/3Ih+8cCG1pf+k0EPnjpOs3xBGv7Vm7o/eiuz+zm9BJ5so/zYjenaW+FsY
M+nwuNNc5y2iTkpMx32wWgJgDCfDQv9gIlM7q0S/FyKH/cg1Fjd47rEYDkgMqXyQ0oHsr6MAf5Uq
FawMQbrdUi/u7vzzQPgPgqXcb0giBvMFAv7guclTto56j/8rjuO3mvb4XWC1K8hJjQiWh36E38sv
E1AWlLIxLk4Tl4j2IOBuGYhmtjR4ZSKrjaCBrODYNV7KFtsDjqFhL2oCSiMU/DdgOYzHMPqYCfTu
iG5tPbnqOaES+gLCkqm3JhRn9Cy8VCOQPXSkrUxyFvnr9S88xTrKThA5/CLVC7oBAL5cc74E3tbe
uZvpL9XSxatTDKjjWc/InqF2p2YwDwmX348VQ0tNcMgFJbiUGdnid03MNU/rDhnhCh2a8OFRHwk1
adzurEqcDeK4VWYd3y7yVtVj4ipvnv4EDRlEp4d4FOcXzCQmA1GXQvmiuGQzoiAokS3XL9azJoQj
dOWCE2ceMVE28+1/E8u7XVz2Jag0mPFfROZI2t9x9+TLO3GUdiBFxJiE4bOcJvZ+Ai1Rhi+cmBiF
dp2kvpjxPCUqIALtxf+AKn1yYgHjjScipzjmGgcXmllfzaj3I5Gc6mcJGp7wzKAdIaxTdQiuQTgb
iOWp5RHXUBSJMcsXBB8AvVPOfH4iy6i5CrpnK31DzNjMqWjerDzQHc4Ta0wsYH28AUFg/vn7epNK
PNBkXl9oycnjsFJYvoMQS9r9DQc4oTH1gAm57a2LcFbex2jzxn4jHQuiSTnZ8EzbO4V0ox+6uiB+
SPVEFJY/wsxJwyQpqrSg/oNd8YgWNOdsSFmnrITMpFUWWUzdQ2lBGUa/3sK2rkgcY/S+TogzLzHk
EGH9bWcFX+u+eey2Tse+xMcwJ6Qy+vI6ufpT7KN347U/jD7ioHc/x3PRoWY3sJusnMGwCkSiMJR2
mRLypSWs0HUzQgbACSlo8glEHLJQ88oa0Ij/4RpWCcNQcC27Oj9f6JlqqJIcS7xXLQobr7luGxU3
oOaD8UYw9KVZo/JmWPx3RZFLOBQ7ddhJo0xSQPp1Px4OqnP68osdON3MLSbpOHnd3IuZn2vB6lNE
kPzrpg1E89SdAEmYu/iWwFpR5k45mSmG28MFHwxSJXexHh3dNeh3zrfbNXf2iAN2g6TtAZ2EUw9w
YD4N6I8Jl4Jx5PFF5GlVCMlRajN0VNVsUG1IG/4ZlA6FIcGpYrnK771u3pb5kob51LHzRsIdchW0
U6+HfPgPUKKBdUTZ5lgOobOH5dcTxBIy4K2QpDINX8womj0EX7q0/fuPFlLuz3iI9z28KX5SocwK
tophKMjwYogBM+f7gJeiva6dAgs2vyJ4BldDBuvZ7arZ7jN1+Y4p43TxFvyNNWbIUBoP+bfmz8Tx
WUKEpI1YZu1/PKFkJPpkRXmRSM4wwphfZyI9pjeGQdHlAIsV6nrSwxpmWnMvE2ETOgp4DbEwhEKF
QdVVb9geECjIBXAI6VzdQzbdKQwFLF+u0fPFyVJJo6RqOwdcQN2q4nDMTDieHDkSevewSsizPBe0
ltI/ognZTFvM9NEMVP6AiILctXq9rkJqXgZUcshp5zdVWKBgcagusr4xeyQmz660JcBoW4/BBKva
DKW2D2Csh4AHMqWYrPFBdx7QLNoYTZ48VL9c5q4bynY83YppDkIpEZAckl+As0QZrZxLx7Tzv2v1
vy4j9XbvS4wqghm2TB5WhWw9Ahaba7kppYtRNR7A4ZbR/rZvPqVNFsyKVpDrObNVyjZcS62fs233
3vJm+1791X7n2w+kn3IZhpQUri+2UG9+dcX2JEw+nK3Eam4UWEQWZeKSJp0S7MMYk9OHT1NPsYKK
6LE8+HfjhptxWI7pe7UbLhgxNiw3UKkBpdOdHiN8nxrVBHXGY36OXrCfgFSRaipVZToaxOdM3GrP
qWOo+OUf7m8FkypKGMxt2ZuaXeIFWfNYBmkuzYoAFynAIjI4GphxgxIx8RVoywzB5Ew+/QMUaUyj
Yabw3JPs1pkvcLrMo2a2TwiBXILz5hu/AI0ktMbwfC1XUDO9BDvGw1iw9tl/UXFdErxVIZ2QFygj
hG7BZV0hah6wKFhN+3lPADUJpBD/3qeP7rMnSE8fmZi4Fyu54gAzUrNO50nTuorc3lB+iN72pOFL
0zSqUIdu54HJZohS3PfBWWyhH8HTsdULmYqDdLxiRK65xVB3wlCTzgLc5oEu