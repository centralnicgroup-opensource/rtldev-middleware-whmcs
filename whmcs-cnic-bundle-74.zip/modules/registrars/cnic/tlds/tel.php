<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/gB2enGLO+ZBJcVhwvUAQ3MVupXyROhXVQkoXPnpE/2dXmRLdOZVKjD1uCoV9Kwjy3vZKsk
GpJCYKz1HAVeF/iOgRDEWMjFfI8tadZKG92XUupI1IZUzKJ0ZMNbHaXJxir8J8HrPXbDIOeJehFe
mWsRt6lfstKVt1cFnakYnEnQr0+MYV1XgFvkyXpAcTg+MGwEScwyEXwnBMbbaG7I40L8yHMWk/k6
NeZ6YPz+uSs+1/2PcgJUp9jHwgna6WfJv94W+2wWGhUqWGaC+aYu9mgqhlGIR01OIBJ/AXp5Va9s
fYP6PV/syzZj6QzesqsvPbop7+R1+Vj/mOHiinLI+3+p9+7JO+KDYnxoyqrl9x9bdBJ5bW3mtddj
AH8keFxDceY0/WV/em12Y/PvnNSao+mZjaY7wSSUOLBDM/ZvC+HZNW7I86Kv+f5h6tNB2mUP3mxL
0Br5Sd1JCU3pW40n9iVj+06bW8mm9JzsOAI53ykpph00B8MOYR10/SOjbQsSzGpXFO5X3kvONo2J
hN8RBdlX0eJSZL3vGwFBsBNLSMdEUsQIIrl92UTXy7KuNBiJqLT1Vb+B2BeCVnbK7s2Ta0jVXzdg
c6p8VgXjd3FI/LiMpTQu0yxDpr5Z2mi3dGdsGliiRBvYh01Yr+JGasO0A6oCUl6ifts5Jso8WCef
DEOoRS8kltpmpwguGbJ2wS5SauEyDzJelKmGxUwvpxnfTNTWzbEyFLFilqa5kAMf0k1WGM1id0ng
d9TD37IvRc1KQR2Xjjmayv4jowf8NsUSALcLj6sR3enLSBs+bMcEnRqqqqHK08jrGtVqNPJM6yB9
ue1y/fIwdSHpuCUh4kj2um4QE1Wezihf63U7wEWe7fh2dzA2VXfI8c88uc43QvBvTi6TywOK56/q
OBkvG5Mwn+6NnGlacyUslUR2Qj2I1b7ga1G64VATAUDJkm7ZKBuwzU2dBsusdtX9FGjOigXWZ+Rp
Tgrb2VKVEc5MjVHfH/k1ZIuerZtLYCy/UkV0sInqks3TckdkCZ6WlHJIojiNR/he40YvEYhuhD11
s2iS65e+5URfBVEBZFaGqMvS33IvH4NnDg+25CGhwiYM4tLRlqQ1+M4I86jmHiQ5g89ypp32qJHo
WxWLWRTybMYJ+Jx+fG6EqGc7SPvYVwGsZeqvvDlppOxtAHv2R1fso0KecNjF+aHluxVbZ8c8H1EU
Be1S2IvPN2PpSDnqD95UlmXe5wiB0pjW9HOvXTzsQWfd6ajFv/FlQe3m/fCs6jvG6W+QGPTBy/LY
c856XC7yNkE5S74VKVRen/Tvz+xO8XnZMexXWjWbxv08NwwRuO2wtf2kMqUNSwykVIKiMuGOcRkk
QSyk91PLCxzg7SsLXwGE5cHisANT5144qRwVS5Cjk+x9vqUUP07wJmi+EjZdMyA5tjM/D3qam1vQ
N9jk6bnLiUuLvFXXhUO4DIZLJ6tUNQzKCee4PI90v4oNMv3LslB+I4Vazw+Dk6B/1/77lYCEDDrp
WFftWpaANdkIMQ6mRaC+mAj58IcyeE66sL2nIyeGq1jUW/WTQdRzCvg1Gbe0w12NBiqGWQaguQXw
AJ9X7b1JXjYHkUEv5fM1H5hgtsd6s4+1ntinzUosw/1GJOYwRX+0FZ/ClgUWgRDfjuOsYvSpMuzy
DaEfgfww8HCQ3MXKpwa6LUDSbhq2BNrIUODBp3w/D334ewW4G6BcmJLNwL58dTvyFZl5i1rkv2XZ
3XEgqtUKelPMjOAQ62OGBmxhQApfyGrr1tDgCKMKmgZoTc07+3gx+NZJMI8qfS0+b/wN3gu+EVkF
