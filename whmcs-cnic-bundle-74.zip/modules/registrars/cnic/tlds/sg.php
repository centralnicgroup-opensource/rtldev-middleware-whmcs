<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt+bI1qLYB5Iu1RTFhzpz3/82gt4GFjqo+jFiYzGGjgJJiWL7KiDj19cWjFA1RmCZ72fe966
RDPjikNh60FQl7jryYnZ7LG56d1uBsqRO17BbLgiUPJiRwJO9nhaWIy3ZxJorJC579KCb/PUSUWS
pahxM/DK+PUihlB9yD1HKdX0l5pNOGzmMGmXfJZeL5rj9+6qUe8ma2PJYnJLwNvQQ5VtRbuPXhLO
TsdpYNfwj2nbSqkC5qjSSCuLsKVbmgWnwre4T/Wke4Atj8493Ff8k2SAjAxqwcRsoc7+i5yiOPSf
TaQnY03/JusXkcTu2h76Zg2H42LTHO32mIrYDteN2Lza+FyScBTJ7ZJ8ADAVJteKUl2WcHAXxslP
73+i/TBVK//NH3JTRlWMVVgpfli/Bbrr/vGEXi8ZQMFxnLxMawhvg9blr/BTosDD7y83+7QeTwt+
GluuiNaOY72bgfPW3XaS5afF0EeTCAf4fl2CKPyqPVTY6WAUhkU3dJlAHHaMLk13Ysa9LQHZQX62
taplpaSS4uTIesRj23hdBVdmwvWNEcD9o0qj9ocsWVtqbXRsTNZeY2PiESXxl6AZcheH6McKdTRo
MJt+uVMyXfLMZlQZWNVdcLzMRoU3iBQsGOg4NXZ4fJGU60FoQoUOw0Rxj/eUuD6A+EKhZ6TSuGHO
+94qUpO/pQMVMOYwnCYsuAu8c0K5/mK/qRzUjwKfxAGsXahNf5czBeUtKUAc3t9VGC6vPBUcYM+z
JEzU3GCBPaHiDavhSQd6DpsHSHU07PIoTjXXO9SrpWrYTfVMHv/hFRIDsYpxznEBy8n1pOVCX9SC
1l+vsvSMimidr/iJZXEBDWzZvuLp1+F15xFd0HnyVP9ZyMuOWjag3pMGv5krUdyrI2AezgODW0FK
PuJ5cTYh42kqNn3UkxrsgJ6gIP2+3EUNK2MZSH6USLmaJMjXK1tnt24AfN2btFh00b+Qt7BHKNRH
PqAH5mFC8+XQZ/+oQdNhw+C7+/OSDbZ8XEaVTytxgjZ5C2M0IzJrJNvOdxNqmGk5jK/h8LZdvtrU
GbiW0XB7ci33Zk3Hz/dyAINzQntjL/GnCQOqSzj8dVLlgDyBp4UNbVnMrQWF9/KY671bS0HB0SFp
lcFNgIAIni84BHmS7aT1jwMeke4o0xPf39hlWATLcUYBlRVZM2lEcX466exFcjRJvf7pCCx3Qlv7
0OimTLyJpW5HZQfqXcTZLEmIWkxA4gMLSHG+p/JPA/fyNiZHcJwXbZZo02RzX81zFIwaxK1Ff9nZ
0oe6UvIZYhtVHGB2Ul4Uqn2SW88PWBjp9/Ai+AVwk81FfZucLZ8BdiSEEGJ/YFK/bsg3h71fmGND
vLklYP5oY/n7n5KkgGLf16Xe9oMLShe64pG7pKGG27CJsD3yD9IpQ6iDEfoNuSCC+D8xymu6kprR
XKwFzREsd0xMZww7Ek/SngyFdN3ZpyGQEevGvdQpXFhi390pXl15K3QdhZ1y1rpctPzjGttM3RSB
Y9bc40CWK9jLcDgfFz7rQ8TlXbewRKvLkVW3E1E+yRmIYV5ugaVHFSJ7ofGdNT/o93i+DfqsKbuR
oOtPO+bcpP2MHqlF7LYY8bBP09S9kRZmIFRZ20d0ePuQydSOsmDwm/hDvAG5yfDarUSRgN6KvsIu
0LFQMoPQ4tOTPw80XQPPJ//NWkr/ptrPfMPByB47YJSUGtnc6QVBSznyz3Hn9Cr2wtPXMnazbfB+
Rw7aPi9UX2WKGpNK+Go/iyOxeIDn0i7jLRQ1r+mqZ84KgYcBohOw6khp14Ed8JlgQ+JsXqKr7mxJ
VhgPclBDPaRxBsMTQQ+yKqiRjOq2HvzHThgc0AkHSH185i7/sXlgbTcosRXMbsZxa0yNg4OacLPm
v96HsBm6D949czfxle+Gc85yvYAQlPl4h+QkzasxWzD9ZSXZ+wuizK/YLW4ZEc/1ZEd941ILJAS/
6V1/5hlHj8a8wFxKPy89JwT555QJAt8kwtcA/n2fCm3FYO5ZY3dGMDI4sijUIqQICDMUUjupjHMM
dIMr1xWJ41NtOwFxWOBZCBk+5U0GRZNjT6eOGZtx6KUPh3U4uuMqyx5dqmLQukWztz6+ZKcJ3ih0
GVh9FpeWDfvFLaHNcRts3T6+xeonsvBvR4lAG6ZRhw0OXkjkNpdcykwC4e/McqpdNIpuKscVM8SR
iT39by6WSDM4hY3iQa9ff9SiLOMwVRmery9O