<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnB6GJM3WxewMWxK5Wldi8UrcwF32WoSviOlRtD3BWAqAKIsymsXnGzkYwukaWJ5MUCtZ2zg
+Grc053469iDFSpX2Uc5XX5ajTFQJ4FznFUCUBeOLFeQM5efR2JnmGavVt+QUjAUszwIOLksA83k
5OQHokxuvGUjV0G7OHlYPKXpkZPQNCaqyoHYxi+F9RnVYGk4l/O1drQpEqHXvQIgxh0ADkUUGyRq
0NhwO0vorDLMtSsguamtaxmjwicma/9OPog0qfXTqoNBOeryQTjlyA+zOQKXHsh39Q+xKlY9M/CO
TpQqfsKRGcIGuIHpeySCWr3/c4qXq02h8FX4B8celBcxXPf4uxv79K5ZtSUs6lefUysVwZP3PgkT
TeFCFlWGq7FWT8sD1oP8wZ+yy3uE4PR9z1xmGfJn5BDoVle/BbqM+pMPRmmBmSToUeXkrXpK5YJo
Bpus3wZ8qYar3v0c4bo2sZi2dBAhxEKAtgVADu3Q8U6aV7Kku14lC9MQb9RpSgwVG7xpSauFMwsJ
r/VIv7Dcpba4cgul8stiEaOq8Z40Du57Pcl0/m4Cz5grG25cs0tgEmcJg0jVSJ+3L+8N/Dd/gsqY
i5VdOyWCV+16CT67QGwoNN0uabOA6qs/4BYAPRtAc/KPKq357ey9YsCMmhLVQz/fc2r0ZaI8pDld
8au3Lq1hVgEm797Hf/DMXng/m3L6ihXBlhWRus39/2D9koMxRLCU7bOzwN455YH8ztF66UUURe7r
aU8ae8ZHePkXCQLFjvFQjIx8hJrLnXq4PEjG/scpKLdq6505GNJ/uF32n5Kw16oCKIM5rBJz6TUh
KoqXc0GgaQXJTPwp66yazr9tdUalxLBu/VziVOGXx+tZzxi+clcLk/QWomGUvxYlj3kyqS/EjD0U
ZdgNU/0TspDQajtR4p9jicW6NBw8fIapu0D932+mI8p/GMET+7JJAd/wDVCbfWk9dbn1CNwZB4uD
+DRGVgar6EZvEGHbeUhOUeQsNwuafHpYJB+N6Uddn8PgTJ1qamYd4+vV4ANytdeQVHRrxpVd76v2
iJ+h4fJ4+S1wnuKa7YXwaJwtPNqdqleOlHPUcJeL6TMNTdnuhiVv050DnOyCCHOUV/klZXU7DCBz
M6n1sElQPz83JQu6sDgmDPQjiztKwvbsukgd0Xxmvks0YllDtIcR5VPOm0X8g9Fdw3JT+8jnq5HI
A8SrXTrlNLc404n1I/TmY00lf6Nv/G5oB7Z5TDdHdYy9uH0u+Nj4FaEJmoYuVqU0GRIbAeHJVMtG
OFIPm14WXVIlFg/sGPew0fX+g7GbPpUB+rKwYg8OaNHOctj8JYrIKNcRZoZrGi9JZwKCDhP5fcgA
sAdewqrYonin0DIOalcF2Gcvc7zvWadvChidFITFchbzgWY0hiIs4+dMb/QiR2MlnkA2+/jbj7ou
Prb79b38zvdD5pGsrF0SNjPXlY0EpTEKc012kEOmrNDXDLWvjktsIVXiK19bEnoaosfTHt43RyRU
la6y5iKKuTkzGNUDFGxFnnH/+gVhhPhnJD0bspfOcrox+IRApEHVw74sM1jEhI6GkxWzs/6yz3Hx
cdD+OqPBWMXLY0Lk1dU4aaLRrd73iGcrqJWGgFNoSr5uGPjnFNMZ7O6hrbsTTI7oVFendNtYe2Ol
oi21Sp+8sJS9T0e8msW/ouhTAVzIBRC/ClbWkeHZQbBYfHzOSojUZSEWahObya449BIRdsyVzL1k
a/zO8QkOVIPcC3+GoBRO2cO5RUghhhTy5ydZcYtGZ2uzc1mSyFvZ0zxBmR20gQz53ll7P4m+ZN2n
lXxfWGyzykL5SHdwm9wBo6Um3VXlwEuaibyPAyeWmwAOD6v+hMpYzhYOoYb0dflf5Ql3pCdFUXNT
3xXSlzb0NzYpCBazsOm1dH5HmaLak9msEvry/vL0fUVOJt7KJfBcnalci69LXBHfLGrrR9l4Z5Fs
BSZZ6LvINgBdIkUDrVyBdTkSjcD59Cih2pF9YcTpPKzdHQaTVieXbaEW4+rw8Um/k302lpl2pZNz
tTuaOmfCHB/4Fo5lPDak9HhFGNcTO+Go+W9yG6BpENgV7FEcFfTWGwWb404HBpFyDoQ2wife80Y2
z9EmLr2Lp8cCkVh7MQI15WUXHvywaf5VyicqHbbBQJB4vkM43AIiREkBZBdCYRi6/fddZCjOuAS7
Pw1Ms+8n9Tv81k4u8zqJh/69Ifbn05NYAF3CHbjKdlA7vuiF6Y8tai/uGt0YbVhiYWcG7T7lsL1M
Sm94VcUVtMP6NBmuoKy8rOMz8rb9cafQgeSmDoMNuRhjimLZz3Wn+LRHVHvkN49KIMBTm1VgtaFa
Dx+NscoMG8RH+5wOwb49LmF0MeQ2yL//tdpr4dNokNR9oLJsOgLeEFvsrBJyqnKcFsaI6/Y8dpQM
e4qI+4eFL0EPiqQ1fnEBn3Hd4hM9nCl+NxHT2/rqnnhZLI7wLBdGJG5GL03oPTC2ffqeV4I4PKeJ
7ZSsJJKAadyxg8k9Spz9vWhMJYk3A5VXhlsqcB9d0M5U98hZCr3NSN1Gke1dWjoIpyKH9faj9Kdk
4UhGfnZz4ino5MWw/TcptdieLE+JiOQQHSPM8chqcTjjRScTRV1Uey4LCLenyaxOkSWvahbgKTu/
KPPXO+LqtU7LFg+GIQcfV1yryLbsZAzy0rHU5OMLW1uTmn/mxudr4+rtfK0DjT5VCTLDTF+kanv6
id6FS/qH/vsbf+rFnuS1B5aKohBWxt1CxG3Bn+scTg95f7SPB0Y+9ckBLyLqTXOUU8zk+Ry2hHqh
UrZqOP5ry/1a5TOp8uS3CfDTjVEGANexpfmkKJf9ekL8AxTXyD5YV3XxbkUZn727WgsrmpiZTrDR
phXHHbFn86JnmYO4ZkxLN+izbLzRsQ+uBYyqOB9t7/sqFofAgKtzI8egBAVHAAWShmX1gXt48lMU
73zShFnZpVn3ver60sV7jgk1duj+KDveeP3DmLYjXM/Oajy6bJI4mg03GZO/6ysem4ePtBkV3zyQ
2sU+CxEFIkQ9VEo/UNRGGV15+s6cEJuf/n7A6FdiOD+Ya5hDADT3cSL6KZqKJC5bhIm+xMGYc8gF
DJSUsVbh3pBEkgq23TZxEypHGS4Ls73E0hYUBufDjQvMX50LTffuZeK7kaXoqiNJHb7jPzs1MNUd
7lBWpp0p0pMHZBwg+gurN+7O4e3dxzsjywOS+MeLcLboKY12RoIGIE5Xt0RHbhqd1qduHJ/qKTQ1
tRyqSX1IUtzp4m/5r3krTmvSXnQfsZQU7K//m/15vkp9wReJXukbnPYldrDA8Baru04NUGzx8Zs7
0lPG8om7iYDKrP5KASiEZli3koP4Prrg3uOSW4Gw2eetaVoTQZlxSNicgePzyYWFsXGiI0h/eZQY
KMKEHL7qfxyUFn5rJrsD3MhQy1AZRd0Xo6nx3yU9PeMjozFdBwCPqKgMxMcHLJye6eGB22a6SQm+
qvYvcVcS/E2Ve3J9o/bNLeKxbkInJkzEWJrcHRSfoCAjI6+8gp2GxQ+9tlcEXPbEQqMQobzARDZW
Xxdy8Z4Vok6MoYfFlHk0raIT8eHfdm8skl9bGtm6Zm/IS4Ouze32Gef/AxDtSKBjFfF70zu56W4L
AO29JalTrUQc9hQGf5Mcm4PqtDchWjyq+x7vnkuUHkGv/ASIEpsNbfGm5Vxpr9MysYAPhsB6o4qH
oFfBGun1omUL//U80Isnd9FBEZfrJAESHTrwj5Lvcrp2ewiEJ8xjJmGPiKOF2KgbMx4pfn4kWCp9
aPcDntGI6LNVhH3gTygZhLVmyr5/N3up604CKJDwUm5nuvWNLlsupx3SvmyiAzI5rsbiuyCbJ24O
xdIQsHYDtEoRj3jB8aNWTfGYElxQsIrIdR4UEHcMNvrYBup/5Cs8q1x4VOKJRbG2s+dbcfxjnzbx
m4zd8XQnmm6lKN+8bjRqqwzAylyuFUPP44FHrkFbUx869tzX7nG7xLMgf6OlkLGSj2nI9KM4owPi
FqS8yONU1SQ3DRYKc0ywTVWGxAGVT8Su