<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/VoPM5xMLvN0aNmGbLHKszPZh++hx/MwBAu9j9DVhHewBSH1kojDsIgikbaU1xJdF1UNZ26
sdJ0NFQCoxH5v0bA1d/18cVPszjHWyX4Fo37jPuqeE9JmQBZAFK0/mwnl0Aygf8SizaEhwS+ry4R
xGwZ9mZtcHDNVyw2Qumq0J85RtfVBNUi8DvEo/2GfFX6J65INBj9uFvGM7PXZcJlYNOFZBxIbkB9
wl6NjlUDtQJs3CHKAzgHQm/058Udg0e+1Gy9uWE08QczgikwJwn775gX2Mrhf2ymn23VL84lRwbG
AyTd/qbZS0wCRUAO+4wq6A4xRle6AOih+mR5SZT1SFixJAKSKbTq2VsQGDWrKBtblcxo33VPjFEp
v6CQusGCU9G9H72rOGbnavtiTNeZk2sea+ATxjPRD89aUeKxAWjNBAK8rgNaEn/Ie+b1SjDf6fKC
YjfoZEkOGvPk1ix/9aQW+l9WJtbLurI1xheA8z9grLwuZzAe+5lMIuiQrtOXw6shaxFiiBH0424A
XeVZVRg1Pn9AwedChhg66HWibaf7mh0n0L+VOqN4/jHG0tLr3Jt/A0To/opwyamfYAz3Ngx+k4ik
kccbVOuSvrw4DBq+BWoLRBT1ZD+X4w8FihuCzFwpBYQCibsQ6uvsENqMy3+EgYiaMkgREwoy4xUF
3KS2RSccNW0UHBkEYieYrbzsvWW3s03Kl45Kw0vll8vACR6I+DoCIje1mBYh57MiA3HHcFJ0SxAw
kiBa3c4HQMNMUgVW1MEnEZ6ogRq3Nubt30DlJwBY4ogHfSVpXi7zKeXH6NX3yyG1nvcO6CVC5d1E
YAAzwi8/pW==