<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqRjCLNGD8gQhLgaTjdcRzDVG0xH3WCde+bQapXSPjjNHZusz0hrOPV09yU/CQ0d+UCUQ07i
oJCRqyHwCOoJjtDKdTFt1xulQgxPAkoMGsmML5ZOhbjIrxhYAuawuFrLj3ruRM6LUX3Jkr0rnmEE
ERleUJTYqoNI8GrNT19WNUjGjEdp2EC0329R0WD44SZvA7y30lrhi6G2fdoy+ItfX8hFP4JJAk9M
fSLejGuTquiZhYDCYLpzRrBqWr6uFY2P8/D9tPRuBg12jxIZ2GpwIBWd2hIkz45dgKbjeCfadKJn
ldPMsqPDZ0s2AYo4c3cKJxDiK5jetcfAJPwKitwlT6e6E56Jkc9iQ0LeOX+hXTfBhcCAy+2kRiHX
Ov7MgEB/AxFWZFo2DKsVntLJFtt3vPMJwZqAv8ek4Kb1uqvjIHHPnEakxKwuc9EkBCOeeaXbSgCq
4fZm758KOFgvoDHVIUFkvaON5jdL9Ju10895VrW5sLBWZV0rCQXavMbN9iVHb6FbxqUoBkzjJZvf
KkqIAuouYMfJusCuracG5QiHB6boYDThDx8vXuULSc90euNDG1teJ3YlOOUQhVixQ08+4W97O/rn
XzlW4OEOj5xqXnDuDP34H5O15V76GiPibZgPXrlT5FohxHLP/6MckbuWW6W4hqHlNHy00BI9q6DG
1rqjPI257dPQ3hqH/XeLlVkUZrnfj6GJE0+YZpq6KBoYVOzzhHxpIqzwg//XlMqkr+MDSMqOe56b
X/FCSs4O+hjeHexsn5DiolTGNBRbWKIUMnoh6osM6EI7x4J2zg0K+EA8qkJS6ny2juk4hNIBPAXG
kyBGZ1up9DjrCQLeeG74cIW=