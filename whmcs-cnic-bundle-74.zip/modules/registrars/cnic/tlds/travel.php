<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtw6zd7WQCj6/JPZKbdXjCE5jieQnyLC1zMkiH/yZ2utiFjmoHujVVCuOpITP3tTgkuVUQ0b
V8OMUAS6pqWlUQw9Hw2+ob/wkRO5aG2lZ2zQjbRjWwWRuzrM7e1v0pXkAElgvFNK8wC2ksIRATWL
B4f3Xpw1HJ3iTY3MtFZBwyPDOtpxfOwybAkEwF3S6DvRDUG6d/kqsdMh5oFQ4vMyjFOzWA815ES5
y/DXvyu3hBH8fanQjnNxKHlJJKvZ6AilSn1s+2wWGhUqXmaC+aYu9mgqhlIaR9YHJOzbVjhJs0Hs
XeZ6DlztTWT+mjwRrQkR79oQJ1sxlxO9MHykv1rOFs2X57YIH8B6JiNppljibUtaWGLYTzFzFTuL
XgFTnfQ1uRHvkKsyX1FWUD7uRoHAQb15Q5cnUbXOdbJsJy9oVNqTvsJt0gxWcuww237LWXERRlYD
Q9qEveJh5oIq3VgCLd2AO0aElplYE/1rNyipZ6BvZ/Wbcs/XHbNy/tR89etpllwzR+vu/+Y/8A9C
oPrzTIIBr7vLItXOJY0jCL3eOj7QAHuJoZdoZgmBDao7H55C6bodPA7ltGIWA6zhaCL7ON8P6tpM
7cGW07m3I2M1r2g3ROYw3Eq3fOKqZ6KB9Aten26o5ZKg0mI08ef7KSqKzNZmKvLQSLKZMeIQay3A
L9L1HRgFTzGfrvmxiyFBeCfQxM/dRVxmCwaotGkQnF0KmyTR9/0Qqa3HTMYWw6f2AIHbVqYJ3MAb
V/XrWon4/1W/kE/HttFVJWyJ8cQ6foR05blQY/80+GORa+V27ftdaNV6nh7TmLzqQeJrfKYiAHIF
K6xKQYfeX5uTQtBXzauwKVclYYiHX+dn+VDnv99ZGjFkVa4CQpXNiNMZk8gVexYHJamd4KDCCF7u
B/xET8Yf5DpsUVwgbzKbPg3baLK9BP2XulsdN367y/K5LyDt/YaUSeJrKs+z9lQXGvP3TgeIfbXD
f6j/lIlEhVLAHs2sj7t31fg4aCCe1m0YRndggB43ix8Twu0tzTlShqCeww+QCqHJjte5f3/HgUwL
IsbOPEaryR03BuxeiT4rhzoidDIN2/bnNnOmGqteHdMJFxvgi37wJLe4o0s7Fk2nOXrqeRK1m/fZ
DSmwHeUMig4Y7Bshhe6p+b/EopIimoUJj4OjXsJSMkHXEdvkKtbpGbohZND32aYdf9gF8xbwp6DN
39fQcnEznPqEq8Sp03JadjFP3ABWMEgsfM41ZW==