<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/0c6FyXcWlXy6EMZTna96v5uDsHG1Q83AEuNR5oP54m3HX5+7Ek4a3iztdv5/TmgqAQJmGM
9pPYpYNDQf0WQEUcpqOHx9TDmvir3jxwhjdpl6mI4v0SikHtyqinTOO/+5gxoMT3Jj61zk5+FQ74
nys59dWnZnXh96FEX4ikx+VTM16Fupwqs3Y8CAh1vh9TTM/pMR7HQH4CNJXrcudkmTk/haDQ1rwM
mFn2RFGa9zrx2fufQpXDajR3icN49wr5OoqLuWE08QczgikwJwn775gX2IjeP13AncbQX5YT8gcm
DyOzvKTem24OZly6ILf9tdlK0+8MiEf8dVtwnZ2A3nMEMA1mdc6hty2vToVrvg2A/BhdU4iJrnSV
sRsYizQJMSs4V8IVph+FDY45f6BNzr1Z8UAf+RVImEXSPUEy++FyJUACiK8aWZz7ATwznAGEdm65
61fjTo1kkrVQzCjsEsys8I+oFGs/fF9mlbq/0AZvQ6QlpA6X+3URurHCVYK7bd1kpym0ZyZhiaOd
ZhMpltnwwwigk3SmjvSRk30gCOgtHMKak5O7sda9gSmC1fDZxaZE3/Fyc9FJwqxbgUyrnjz1bHfd
oXoy6dcTBbGPUmTuDVnf/lgEbTWOyHCDLzFPACUi/wSxd5QVZ0YnRNagA8HbpdFTsyc3AyiU9Ki9
IV0tamMHXQ7G602UJDSU2/K9ccTgnCPxcmRPqIsBoFXVlskpxE7tQ/QlEMpMyaZMADQyP0bA7kjN
G//6QGU2e5Rez/eJyRqKri6zw1983F30fXzm8v2pK1GGHV0kXmFfBn0F2uzMNHo9yWAM5I1BFllL
cKWV0l4NZABR11kZWH8hFivZ7DKXOaEJbkrjNqwSrv1LblbE6FF1Xe5SLxIMDxc776JFXiY5Cgvn
eIjCbkA0LGrJysCv3V9YTyfB0zIAl1F7egVB0YaDxLnvJVkyTJ7ex0WEgoe977UrUcUlNYrpR91I
jodwkXs9ANhRAATxkA6sv9HNweD4IyTz3aL76zfNDPB2GgWw3QcVovAK+YdgPvQS+3EMTcdLmUkE
gwVBIFv6TeyfYIZeYHZDhjP4pAxVzcA8SDxC9WMNMESRGLV/tKcQDvC8tC2Sc2JYkRRpCgevkgWS
fEptYuqN0wO3V2RjNWQSZUjWnyEpEzdDknCat7CPAF7sFcjNp+xouoklm3uRsq/RyExRK6eUISoZ
QzTXXOQ5sgHINwhw