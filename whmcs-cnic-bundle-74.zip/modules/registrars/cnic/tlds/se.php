<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqlu/u96mKI5QPnAgMM5Yi4ej2LYZDQIRy5/KeeRmf8gEKkXCDzqyoP6m2Mn/xq9eO/sy7no
4FiCdtlmyeMqZKKXxYrUW6qOtb6kEDp1nkqsXvP6lttm70NtdL6vKhwPHQERWBlYOzJVNaOJGSKe
lF+9emvlBSzJZpQGhgzJwKIPUsWw4GQERqgGU1j2raOMK/5jMh+6t1SRFUmkCx7aiEWtb16+UEpU
VsXjeqvvdiQ8WlOA6DxwQN/LDwHLNCo1UUypbFWke4AtjBG93Ff8k2SAjAxql6oiRh7fLBhmWO80
TeQOPZde/QiryTii5fPHpC6tsyn1kecdBxi7Blsd3ouLoHpeqqfwscJQ92h0pI4eX1c4O54tl9Vv
9K/cSvnZzDfLprKpgqyDFy/9GHJSEBax3XEqkk9HYsCoBQkZltRN7IBrSVKBbeg6XcsTNGUG+w2m
tgDBxSpDc2U03sn+6vYTKXsZr4tgJEQpMSBO7WKmD0qBjL6tuzw+DD67E2tLd2zA18wZsbAz9aBo
gG39YFn2X1o7swC8EvLMMBqcbNZRBeuJ/M1SX9n1xOpdLLIOHSI9ZDb3gJ3Q1MWtv7leTL0eX0iP
DRyfoHXo8gysavcaEHRxuSVqeKJJvABVvR6/zWiILbKJcLouCsAIvp20e41BSUbgzk5oWzQZl6xC
4FaK6uLBacIl0H42Hu0uJnwowRNl2FTnb+gs8etZ1UdAA5r66z1G9P4uQqCZyE8rKCd5NtT7HGaB
xhJppzerC+KjabzZgZIlnTwnSu/JkPFvEGKOp+Ow1fdd23QNEFWHKKxxUMxuazNA4/+cbzdeGjNL
h5j/5ATTzxd6sbOb75M1l5HBwACl2YI9EBnIswcctfs8lq1VBt6Iii+pup1QjOO5Dalu5zUDjZCx
ecziaojXjlG3zNYu/aDi99kRgpwxf65jxiZmZyFeqxoGx2Nzm5nqCv36iWwJmvRP43rYvP4QyQk0
CSy+3Yr7v7GugWu/l0ojDcas/vRhb9WvR6/Ee7hf/jUvDXSmfsPSf9Z8TBQeqDkqVPFlZ1UWZyE5
ndCteeIhM/P7x8rs4tj4bzmxAS7mjS0rihJFN+PhlOUlgeo7MrqUnZIN+V53j67kMJeb+N9bWBZk
4mT/9cx46lf8Kxru0h2jDRv5q1DKjupKT6GWnTfm1dBv5Df26N5xDrlrOtnqAvP0g/TJAKx5vKER
IHIgUVFBxcRLvGJhqFQAnCoxeFd++3HZTlQwNeVpJ5uIjNWU6OHP91mALNf67U46Jzoc8O+cRikS
1Xe92kZMBPqmEDLGLP/VnjSwxCwtu7r5rBbaBiP2h8yBRLoteZ2bWQLPf+mieap/0IbB9PP9b6TE
QxCE5UEJH8iueb05cx/SIa+j4zkBZs6R8NjVoGyCOZiro+M71dYvDOgT5E7QuvfQcTvfM0JXxtMx
4cGlfvfx3GWZY5impdKArxCo00ME4qoRW76+H0y1T3+7tGWAHjNDNWpQb5pcmBV2rkjAOqiceNXF
36XcEQJZV8AlKsYVzmcK6WAtgsMIqDVCGoqO1tzBA7H1unY/6Cx6g9ut9gSMkgEiDblky5AAiny0
6AuXDuLADjfFlXXL5Eh5D37YnilaADMiNZPc1Cik9ptv+jpQ06GgRT+Q3NKJNU8DT3FCIt+/KTPN
B4I044M99+UcxaLmLwepcB4pJo+oq/ZhLpqnWWKagN5Ky6dLmqiI8jHs9+nRRR5rnTKjbaVoHtuN
uAzI2ilZonfUqO+uR2OORAyRWskLQ6VO2KYD4OicL5ryqfhDi7RHkB/m7wDzGkzxvScQ/QmJCssO
