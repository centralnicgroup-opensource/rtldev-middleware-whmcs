<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvWcxINZ3TOA+f5u1Y2YuEt8OzD9Wc3K2+rGYxVAfncmwO8h5v/e5NEg7qUVLpJV64rxJmb7
KOQonh26EsKY47gja+t0jk/DxP2iDJFqxN7tHyrMxyyQu+oZiPSB2RWtVMJqqOIX5VrU+U/tDJQu
lSoXZ/Ovqw30K5nrUeeHQa/itdzo62wXn19ynrH+eZRUxPEqtYOCMX5kXWs+ecDfdsTKwoTXoKu+
vVX6de1V8XQ843eNUuT8hMsHPxokTyMbgGrvqWFuBg12jxIT2GpwIBWd2hIkz05jGKoVnAentMM1
odPsuCKX//XHsvKS61BqV4TivnbkQc3ZHDfDIbTa27TQ+Zd43G+/ujUaC/2hm2jCl1TMqeoITwV1
quyCS/rgfz4lZ8rdvddOf+uUGtjCTm0xw1HKdlQhuu97vNEzQ9pgvAhte6S6H29McuTFqQ2bN7AO
5LjFkD0GGVk+Xi/DXcXz46mswhHZ0/lLv4z/zyp3wvkYfp2cJxruG2dtbi9ZQUOVdtTy6g3IGKdn
oCjwZ5HSe2kXaQa9XgG0yMYG3bTdqAn4dFIlQ/daaJT+XJYceeH5WHOSfOtlttRG/jTuGZKd9tNa
doEl0iI4EX8IxJjVUrXf/oeZB1hZZVmDe064xqKzDnUxVY8lM2GuYQaYsi1kY7j0IvOl2dxlFVh3
ZmSlyqlv+GQBCSoScDqxJZKEpzIaw+AEwiQ2W5RF3IyrikOk77vKahiD4sMfT6p3w7TAzb9BUnBX
TICKfApiQbKbFXpK+NdI/FBL4w9QrxnmhdI/n3ivLVtFvWMTOPgI8ScfJQZLJTZSrGXn5ll6U4Y3
YO2YxcQqrQbYXN1qpkm7EGT73+KLmCqbqCRHHlivvD0aXHZKmMri6zx9zfKQJsT5ik6FS7Gg+aSP
2ggl+DMBNPbgEgm3an6W/Bx44XAgIbJroTKqn2AtlQ2oHv5hSEvQmTZcgR+gMI3NHm2PfeGDvNY9
2PTSbQ6GzAE5E1RFvCNf0PjJBzL3u6gFrsR9MTNiEOWFiBmMbYa=