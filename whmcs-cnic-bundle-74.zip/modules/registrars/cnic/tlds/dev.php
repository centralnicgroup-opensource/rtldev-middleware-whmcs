<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx68V9HKQaNS8JZfj+fyk7AEVvPbhoX9uywk1/CCQuYw0vHJkqiqG+AxpDN1rkuk48ZhxTJB
of5irlu68P3cK2O1ekFKeXPWLBskVc7wPghMD7RS5I2wPPA95EEjUmyOZEYVkTkusOxXe3H7FTzL
Yr7vMM4BxWNw4sh72NxliUfxv2gCDbtbN0WDS7vhKlA5BpBv3xZrs0lZoFVfplp79ffUbnHOET+9
oDF1e0ZZBAhS6Is9yLxh6k0+UA1uP9rB76wd+2wWGhUqc0aC+aYu9mgqhlJARrx44jxs6SvW3srs
bYq7APjgnF/rJi7RYPKO4jH5E/0Fb5cYUQxiOjkx9ine5GbtB3ZZu+/witJAZBfVgjgA4qGpAflD
2oGSqHP9GA5h4bcDe5dzv+vx1P2I/hlu7eNpVv0m/zKqlKJPEz3hZiW25o65p1aEwPgc3MoYQrbo
b4OdMfWXloOCpXFxli6qXufQH6KDuVq9+zlDQxsbKfjdjG6WQ1ywaPVhmuvqLeaANcEhJa2lbeQf
1ONHKfrLHw6jo4wK0mAiKgvrjL1y7jawJHBfPW9YDT0mPmo2YxqBqRIubpsN/CYicdwr6j1+S9Bs
euBwwYxRP0JtGrjBzqASXJBgdhWkzqs+63ATklUHn1LKAHDEQvIu7W6T8hEJylk4fqPuuKcGIGbM
Ge0g9/6c1OgLYvDmCd9//2CCXccEvVEyYrKukBes5V2FksJ9mB+x8Oa4zll9oUazkxRvjpU7NJdq
5BpBWiWBI9VG6q1wyYkejhLvhfk3Ir2553BFPLGiZgrFaq3t8sz6pXwtoX7ov+WRFPmBE+vKNo/G
bF5Mo4szOaMGaC9IKcu+7a7EORyUKmIJIjh0jnFL0zV1fI1+S1FpiAmIKkxBnoL4my9pJgljHQ5j
KgNJtKGw7Fv8NplVEDwK0qW5cbisaunkxCZC3yrzIWX9g1Cs+Y4XB2ATjKeTD2Fh9Hn9jeNqvlDq
zq3jDBhpxgXQvmM3IoaRcdZbkLMN5KvKJ+eST2Y9uIxby+JPseVeaTEwhTIJ6dbd2aVDBV5SS32r
LdjeyVYmSzHx3SYxgVsEsKGTnuxGTIyme1aUkRS3hjOcibvqJWnD/ddCYLs1cIwlcr/j5OlxshAI
/FvjPtFawcMqB5EsXRySXaiMVn5Ai66Bt8Zst+k5WWKWUu3ej5MdwRA78p/NDbzw7ZU50if6UevY
a8AIZIvmHSww4Li6eG==