<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/50x5AQhTHbO/1vSPQulIiI8m1yQoXf4hkuscorBthRc3ksxvh2JZf3x5gqRgEsx+Y8QJtO
CyJrYj76YtfSbeMSlgdzS4HkTPry9rKi0rGktZfKvx8WIOal5EX5MrEqAhftCVg5WxZNLk6bRLk5
oiYNAf9JqBCUZqpXb6k5L9MEgp0hbAZcmAvlXUtT37yfTmeEAIoOgBbLY5LVFcNCDYj9Nxpnme4d
YBYcR9ZGi4TA/RGmJz4QeNbfFsd8fsD12zSquWE08QczgikwJwn775gX2L9fG8xSRZeICsB3Mwcm
0uPpZrILL1dYiZ1qWWuCPZx5baTtU0dAHh4LNlODNOpvdzhKHOyApZsuvTR+XeS4E+HlbJJg134N
t+xiuPa7NPtrQ/xm3IM4uvHYYkbSxrbtSOZOkPl1Tt1HTlq8AI6czESKsFxGugjVJHGCUeDoJmQz
55BevdBYtdtenQ+frl/cRhfdxVpLObtzv8Co/0jyRYeuaxygRycqOHcc+86uqCm6lLMbBZqEtBmQ
sB+t75Ag87IpZ4sMVzY6GZC+A1krnZazSOybT5+ikAD7TGy/PPyQDpN5L9uiHcmzcmaIA83kFy0M
JY7twVXqmCYXbMF83yyaHILvln4DcgYnATKlDIaaFwFhp01Nw37FMYOrdbguqEh6YRBYImzPuNZH
PrfqPWdj417+tOVtGz8N6pe/2PHJbpk/MtQ/LnEq45/slD2j3CTIE2a+WIiVSQSuLfEQE8Qu42j1
MR2PeAq8g9UYWD8nfpsdqZWPIY8rj/TCgCQySQKFu1hUz1PJH4L30wyoEIuO1J60R3/mqUF0jRva
Zr0F0OaKPbsJmfNkZdpfao0DwYO5sLx0kPH9oe/A3YsaWxTlXq35CJBUKLG08oB2yEXM5WKHlsX3
OvcoDJLxK+EnmANcsBan4unVt9m0OyXvhZRW3sCRziLAfjfgYob3RcMeug4XV/2jlZQqWWkzoOqE
e59jO7FLgpCrVANGUi1o0L/dhGLCGnP1O+fty7WZe3HgkEcpGi5RgWbDzMMTz8mAOi8FsIQ8B3e1
XFp4JxoPeNDpZP08wHS8aPbml1ESxvuuGhXhbvJzTXD/Ms98EefcHqC5dm2PwlKLhN58ZCZf55ER
aFkAH+Ua3i6+5xsaUIqetcIIbyvYXOJz2DB069mXrOg1w4oDNgbPOBevUdJZkmEF7MlFTnjmofVz
bmF3/vYp/yrFQfu=