<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnj8T5Ll4asRTe3XTZ7HYKxKQxaVAXjsnl0JpnEF5AA10+IbDBx3OKWqf1yGO/8BvlSqv3dX
aOM7nftqZW1Hp3Fj1aSSHn21eif6bueOGHi7+OYZOXMoIIWXyFYEyQGzXwMTP/GD8+wXpDyE7nl7
Pxeg9KgfAmEaT6VoKve5dEnmGWB9QqM4yq7v9bGwfu8nWTwbWTLuPhj3zu8MLxzvhEfb6BvGTV2v
ZI8sd44x2VQrbO+N3upnLJEho9j95knJT66AEg7uBg12jxIj2GpwIBWd2hIkz9XbZf5Tgifvxw27
8dRcg2TTuk7I+5fbMnr/KfT7vxowOHnwpOXVfQxmSmUXZihjWgsN3GGWGhquobrbE16hQF/tG2+R
nmyhuvdqndic3prJr6Z2fa4UvBo5weD/e5x32A0wvckLcJYBfpByWuPlJrWCoSG0WrCPQH1XR28i
aZPxh5tiqhr4IMZEcj9mlUI4sPyJ8UIPY+hkRPPOlgs+G7R8qdx/zI+ohUuLMI4GtkcjFhigcvLU
TtzpMLiQSXpLeRg4Xc8EUcbmrpZBD4R5zwhYkICe2PtcGl8fxOUhePLK83HBqY0uCm252X1SvACX
drgtibdTUryI3T61cymUPyQEytm8463V8z+vdzmW2P5Atd49dztzfmNsG+957XcYhfG6gnCrkNoi
v7w82xTvFL1jY0cOD+iIffkBi4eXpu+U60yRuEi6Y+nVTw3RI2uPSRB4y2r9DaYoT07IjcZFEpIh
o/tD+ifurZvW3oKqlQpl++NwFyzi5SCXndeU9vDOTbltYXhpH4uzfZjqY3avis9O8CNYUdSMci30
SjG5TeFTM13m2WQawd/qNTQjn5mEXm/bFdWte3voCPe4tdiLkV4e2F8A7CQ5GyOQNGzaN0Z1NLmM
jqLj9v89rP1IpHYhItWY8upkeN/yiHtLv3WhD1GHcEJuKzpft/BU8ZXY6irVObqIg05yDOWxnw4c
Vbr5XOmS15M1ZGISsJy3w4f6V2Ke52nbqhxO6ldIXFtB9JPtK+63R26BVGrDpl528hT2NG/0+YV6
d8TMsMbbKHkfpvD+uSc3THr1WqDuIGKwCtwNb8zNWJZN1L9WpimjUFepPtFc1y5/JJSI9xNp2Uda
lJOBlnMF0kC0RSjsNspl5caXyzfEtMTOYVEgEWn3giQOl06Z+AbrOyVHqwnQ/YeobKd7eq9m/nAW
l9wWlDfNRDfi9MHYn9WFD1PMQukhuGauMnCTQLfmWU19kusyYX7Jo2zxhvUtMXYR3dzpvb70C3Y4
Za98v/wjwvqMMWOQVoDzkh51it82u/yKzKh/BiNj/+PfMOCBpmtMbCEg632IJeGDHyyeG+dzHm2W
norcjNHPNvK+WoSSbJMqe/MK/n3wVBmAOOSGkWs2NAI7qcIhLHLHHJquxWwDhLVQ437ySxENOyFP
+CFdk0w8tK+xaP5XnTLyVysL859HmGSad9KqkjhldFG23l3e0xAl+2Q4KNZ5o1uJ0xjISlTE2hz1
WOv1gQ3aawagHOf0ask4wC7rxsoHs0CsTcGPPKelWhzde5pvI9yl0PDvwa7EG+UbvNG3iSokLHtK
ibL4yGa6y1zLnl4YSSiX6pSFcjMP45L1a4eGkOHT5fLikSw6IeksoWtiYCF6N2+Vd6KiXcQRKiVt
Sln8mMvi+5UWDHUDTdOK1W+79O7BErQBJ52OnGxGm9BQ2f43REX3KcxilzVZIv0q5UY1cIUzTxgW
AZAq/+8adVOY9UQ//lid3wZRwP/uBxLRvteJyS0ajjBypmuGHnZi+0Eoj02yoBjSH7ja7QOfodcX
HPl6lBloTJURTje4TgcoYj0Lmi6m+NKF+fLsAdsZ3afEWEQsO/W3p7rqMRQ410043jO9m6u3v2vt
D8/AXFD+hMgGdtDPK5zYkLf4v39shky2jCOmgSyLjbfdQ2queclGtP/cl2CRvELkpNjbbZdVNuIy
KeyqcoPkort+seDS1P6LCZurfnqGyY0QQ+BSobrpa0yiJjP87I2KsS3u4fEJc5aCLHpDUW0nHqIb
EQn5IlyxX/XDo+E6abozNStXpzbbIL/Lb3U7LHdAD9Wv5tfXekt8N0Djs3DRIm8EWrdI02Ocf/TY
fB2LBVXcV7V8iN51mdWVM+WwdjD6+0oVIAjTH7dgOQyH/caqukjfIUdy+MPTXxUBeomGoMMgISE8
aRuB/7udUfgChvneJ/tzYqeel0OaVTCVsveTSEVN1VjolqEWNg9K+WQ1kvJ7DmnbNm/ciP7L3TSF
lrWBAg+xjR5lSsjHgsEoBjl/kLsUENBb3s/yB55KlHTsNQicFm3ku1vTJkCHNOh7/0iNn2jo1PC2
PY+D2Co8Pi5WjidLZjVADIgpfYDR9Q59Rfab5dsLfuSgJnei9SvTicGR0uBuzm+8xLd7WmPt29RU
FRf+VaBvDbM735M2MfMgt5in350wHENxXv2j2hZcrweR1GekVoxYk+z6T6//Z/KOpQZgU2D82gsA
/NolzgoYMHcJ4P/TZOs48qroMNKEFx5nTZPNqwOvaOHY2omPsigMsEtoLB/nergm8P8HcJch1FmM
ZUlzIc+ptXpKNHdOVIpp6aFRfXMCzlOcWR4dDx8Afz4IZaPFPdmXtFsuqQXe3tymbNV8v6s6szOD
tG3kpjGp/9UfPiZVudJ7JSBDmlKiZ16qrRpqdY+MdCRqbZ2ED3PTmSYGFUNKGemcnaS4pKY3meLQ
7ju3K2iDGYF/tziKgjq+cGyh+PQZJ0jpZO8lrYUBfUo9R7lcHnDrUxDr3KzlxT285LmryvaADnhp
NHZHMsNXwBj+vaHEizjk4yiwYRt8wRbtAsZfg5evMpzzOopjvVA8iNWbCSi6TQHFolBAyqS/m3Pu
M8T4CT/bOFbOSCHpuB7wpPamszfhqs27ln81Blq/+q5gjQbkopHKltNoEgywYNpFla1cqdj4X/3p
kSvB7h2BKcyOC0ys0PrgyxhOej9Ulm4hWdVB9aa0YZffq3t3swaKwBm6eFu37uQhvsTx6HkcwbAw
crLQoQC6CgzTGNknBFkjIzxk92BWtK0t30/IKBb+naichH2d5evxjlF+c+Hx/5q5HpbF4wcvRFhj
5aq2BMIc7H/twoywUK/LiV3p6gPl/60+cfAk86wVmQpkD699eP0DkdHBO4fUzoccWMSJNc+4BFQq
6v3PUnJQXZ8fpF79Ps2bwugOL9fd3WHWDFnYQURf8Obfk7F+mtWEghuCkR43uO/lxNPCKDXNvHO6
nmYwwVONDjJObkICv7HR65TwQ1vImoNHXk53kn0OI+i5RrgVbJGgp+wv7d+KARI36b84QoMlCebA
VbCBRtpkOrC4Cq06COBPL64nxmTJr15UsP0mVK1DHXP1BkVuSUIEBUjsFyTNd2zt59J93HECfa3N
0Te55dIFchps3hERpoJMBdVPKUXS9w9HYJPk4c7/fKYOugNvflz2cNC/WlokybP58g03N1oQobBo
ikQmal20InocJYsUsaXXT0ZQqeA42bRssawSjEEDOUD+Nt+zpHtPmb1HBDgZft7aPFh8Lu7ohQ8b
hb8pvmp3vhPZcrzosxQUOc0+3hp6Gew1Gc5HNO0pklVo8j89PwiZEER9xWVzpw5mnOH/Rx7Lexfd
J1J7aninjqm0Z79sNgvskT53p17wceAzY1ZpD05kA5FDK6tRyiRRUA09gXWvTF9b/bZNAKwnUltp
hEiNS3zpU4ANWYm/9MKlkriLVrB13Yz/QCe/opwME9tcQlrETtCsBdpLHj3MyuuZoe5nuBnWzEoh
tzx2hvGuuV1+Orpf5c7tN7HaOaVpJAV2FdKIklqH91pfG7DniLe/2UJBMC5ejxBxb/D8RBaItEon
2dJpR9zab/hch9rWg+w5/CWBx21KRpTi81u3kJ13mLCACv4g025Ldaw7u99guWRbbZK0j8hyX21d
TmpYquP8q31nJAU7EogHEO7GhYb/rOdBDnXVflnYT6v01jXFIfMvk2gVrV+xkCfySxpwiBIAvdN5
j2TD0Bzzz7VEpaXUdRc2jStS3Ce1B3QFwuZ8sDkJQ8e1wi/0p3546nkMjR9YMxL/fIo0Rhy=