<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnfMZPY7ytNVNfuOknWPiFMZc6z1ZGWvVkLoiWibJRVMN1RRX0gVxzT5iSPYKg+RNgBgfymS
TUAo+gqgCalUHhWeEougvw7k9RoJNbo0Ti4ldmxugiOudtzbNyO5uwlPimjsu0Rcibar7yPA+qVD
V7QTX/1laYk9h9stBF2hIyWZFJMGgqzX0GJFTZ+YZaLODxyT0H+VNqwkmiHls9vlBGHI+Zfh2nVg
kF21eCA/5GRiAFgMMBINwszI0RL27K2vbiiFkk83W26flQhBka+iHnnQeGdQPt+qkPV9i9Leq4kf
aBa7CBqb5f/mPcP/PbKsmM67rlKZxbVkP8tLGkhoB/u+yDmHSpOa1S4cNyQscrnFgatFWfguWTmZ
DjB0u4NtjJ80r7sYdN6m5NpLgj9i7Tn8+a14vMtJcS7EK0HBgoAo28cyyk+GdGLwlIh4q2VjJPQa
knoCOL5pC9o1Lu1GzHKtzagiCSVv6qN/TEt4vqqc71VAHhvf78fhd1h2m9paTiIP3Pp5ijaDPkrR
sk5giEwzCzQkjKenihxswDEQvxTTUN6Grab1u68jBB8hwgDX/9XFGAANslEp9UYiUglCaYrPbIP2
8PJDuUjjSjnebLMmHzWUs3SHKJi1ZjZH3jvWHAP/E+95BOykqc3aSpDxFS75Fc8vrpxC/2jmGmDv
+ZsvtTwhbD1ROIYAuMCiPzsdzFxt8D2B6+HKdYvWWrNxtnC9jb7C6eXrXNppRZtZg2sgdlrfVkMN
wK9ifblDZ5nI4RNfnc03FUdjx7D4Qst113rqj6u5doM8uvfJrx4GldSZBoHsY/Zsm9I+b9ncdHrn
5L0nkCUsTq5hlPaKcRQaMj2MSvNe0Rswerg/mv1Y25MV58iCFj17qG40hgod3EsvxnwN63LFwrfD
8pfFJNPEXwNrpQJroJtMDpuXyex8RYoWkNrP48Sreih+y1/sLcB8kj0I4845moOk+RbZCNU2oGg0
ZsEznpdeX465XLp/nW+SYZwqMHDx4rcF4g56gPvSXK9H/p2Bh6sc77i0FZ1LvsGMY/G1dg5OBpkf
arb2bjMUIfjmrfdY4NONywFpwhtVEuFytP1BeGP1Z8XQj2yfL8VSBsGEP0V6UCf6GopedkdaqyeR
2vTrwBHOoAJ5lMeYFifkDAqVcEEKbNipkM5nOI4rR+sknLfZlBhtwDgmm9Lp/jLa2ndnoJXO3x8k
ad3CMO3ohOJeC19lKaXbCVqPxbzv0Imsla2sYwnvNAh0ozK9fvSp9MBfLZ1Kl//ZGZ3rN0bWJIXp
SjbhyQ7VusysdajNWNkn64jgrvKkZn3k+HzVxe0Bd7zSrxJ2Lyw5EVynQZdBARiXkpPfJEJmuv8t
Wh4R5UCEDIhZ9sxd8Hu9WEelOSxl3A1QrAa1LskXUNGfSHwhWtJUTjC0CwH69XWs8mLZuWHc/Orm
ChLMzZT5Q9o2/y7yRdFQbmJeXt+emLooRnsSQ2B3cR1Zk7UosV5bz+KcHF3nXoSec+kfsQkkFtnC
oCVvl1C/LYv03FuYIGbKwgyJ1dtOXwW3AaAmybzXoshZ0nSRrpEjDm2RdpyW39xUEL0mXCUCCZJJ
29ZbPDgXcyCKk4fl0HELEpDZjpT2B7yo0iSmY/rEBmxB9UmzIdsPz68EyPPc2bGimDh1M1l+XfV0
8RzvmhIoiK+OMsT1FaOvvOHf6PkBu8QDrJZV7pgQxwpx2ckv1WbQwIH1yjVwJp4gOpFg4lowT7u3
t67D4We09maWl8Lk+nlkldKaWICklwC7B0vvX+rNIAjgNk6cbQUYOxaCnK8wnmWhkFdmvG+nE+9z
8jD9B3xr8zJHk4EUK/+q8GLVo39iEPJWNJCgNwnTIwyQvjf9qpzx9u8VYBPgIDKmqeh88C664tzl
RREnTlv5yzxHw9ewoIDIFsckUbzg4E52njvFIcLccBU3SGwrUhZnGkpJbE4ijxYSSu/+PTYouiAl
bZ4g417DyjOp8rI3tmCWqkHDsYtoQJhf/T8TFSfkYlehyzEPjMCW5UMeZcSTEOfiPhsM2RE/tCfT
x+yiV0mXE2vW8mbbcFrm9ng5A1t5EKJf8drjC8xIc19hQOk37k8PlQPwkrtw4fsRESKJrtS1hW7R
eluXVmOQdEmSSafZQ+4GynrtMvWr4i5I13WHtUbk5OYzLEJReRv2rdrj0YimEKpru8Nu+geN82hI
4du2T00FOBNmYXR0OBnfSntLykg+Sj3zrH23hhtYzpz6Fu1swLOXPO9o1x+iv7aRuguCoKw9tLHB
zRvDiJa1tEQM0RPTug6cfc6eyzf5f70/yDbdkyw4a/EowgwiYsr22sf0G5KgtYlW1Ej3Z5/AH7iL
N/BZXUj9OtpPAdkPD3ry3tU57Ji7f9UjTU0cvvl/M/Ut5OWebE6gOOFvqBl2XOHK2Obo9nty9gNB
7i5cQwad/XFw0ol2s0/0OFybwgqGb8vDemo4+OoCVh/IAwIn+aHZeCRre74covNaMuL3KVGgofob
7za7J6LHG/q7OAVbgmQy5HgrvYMkXRS7zMudllPKPvClGEDOSAmq73lMpTyAhgvriBvqUJTB9DJM
nYWQvBImr7gcSGS3Mv8QPyTjbH1xRjy8+qArsIKmZT+sbRT/lcoRGLSc08ZntwZnhizsHenP+3NO
nr52+FNr+8BG+4Bit0Y8QuF0gfNDfIGY01+inYOTw1SxUTR0UJCUbnHg4hS0Llm2VbU74L5r/mwf
WxnxHWq48iVeFHnEV29eDiZBhpOWrKlmslfhuN5y3/gN4FiVXAWwEBVBU+kvJvVoX0kjHoY7CNdm
tVCQsgor+xo7EVcp6isSSh6+HgoHJoEjRZrdBpCadVBRvExnUIy9SBjDkfpQ2993WXi+DwP4P0Yx
sFl3OS4l+N7TRYApUetS2laC12xUTIv89BWCJzyhJ8dw/4RDTM1ixBqsAx/hDV8JrS9RPtp12qx0
uXeQFv4z/uI/Rg2k0024/GqMkGgTiectny+0s9nnejLVi++a/GiduLP1TRWwBrQKimlI/9KTQmVc
rqUf0NLMMtdPEFGGytniBiWAYI6LmIuajvSoeKiz3Fw81KTPNWrpHAlh0WmzOBMwvR2pr5PTHjUo
aCcyFLJ3mKhx/kZH0fI7/FBH1EUp8qWVtHP0epXheCYDaPHC/j0Z17UYxd1jDokyJw1K/SndXLj4
h2kO1Cv+RcRiN1XFhtew+TgfUMzflt/YosTRzZ49AdOBRs73WYXnj1q85XhxFM1+UEf5OLpdd+B8
1Iw445Q/qoh/GcEgwyjVeJbeaj00NUvKAqVg96EHbADOKe1VEMKH6C6KeIs736VcviV6chLZV9QF
6ltarEFgFTxoYdJNBgRjZxA/0Qf5oMLjFGz171NTyLfck7uAS+W9E9Dx5s6JEaLhH5WuwpCj2npR
pJl/V4pYJWDuMO8lhuaYS/UUntOGoOvhOvDrxFUpyr2pBXdqyyGExgjc4fs3nP5FJLxiqKipeSoQ
D6i3ax49t2TdEuny7oSPTaR5YV4wOmwT24BYR9NxAL6tMNs+WzLBW1ijHW7JtCwuE0UdTdPwZqA6
jpdKAmjoVMsLAVeRTIzKsX8Nv0ZBv+XK9uFEHD8Mixe3d8y2a4K5bLQW/emmFx8TVy43Xaa1JxtB
AmbGAmXhRA+b6KyCRuX1IMUpO1Kd7hQcCesVLzXlCh/OCCVK1MYLFZwIE89fJLdee88L+yvcc4It
YAa6ju7vu4vWYlFVtR+jL32biFMCRfxJJL3naa3UQTkpWiSEl2ix7SeobS7XhNanOuz1ovaxXcJl
XNW3h4GxA0jPcEiUUJ1VtoEDNcEgEYbSd0dnG1OiOYStOfmfnRv/q9+aoL7OzJ/Dxxa6J8KtcEEP
jOMP8+C6Gi1y7b/gPhUm7FzAyoL48UYypkZrH/wVvxHsy5QMnQYr62nAIFIdLKolycCoGhC+sfB4
K0A9YgjOJCXIiQIbUuozMiQ7aNxPnBqaqzqN/FDhOZuYvy4TuoYvu06pmcAh5cof/IhkiSSXCaoY
7tWlbj/vltpiwU2WRGmIbTioMOgvcFIqPtnKNG==