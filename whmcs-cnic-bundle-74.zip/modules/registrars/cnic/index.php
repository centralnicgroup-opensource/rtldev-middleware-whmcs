<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt/OPBmK8rsquM/ndobTV/WLmGo/BXHT6fUu2MeeGT5qSt97llCT9+ZFHQlt+/QdTntE01jn
G4seealexuYf7PQYHIkNTUxc/wOSNAdUIL/m7PyE/XNFHshLUwWs/QtM9yXxa52vqv8UAajcuO7K
STReM92Un/XE+Z6zzMWw40vtrARHmhD20qwZpFtJec/fGx61y05XKQCdo+SgnuUF6vKAmvmuz68w
5TvNQS+A2Tg6Pp1X5bZWySOFPjAaNeT3skwJGrpyBTnX8ItGl7cJBuB5RVLim9sFWEetkzPxcAYW
IkOJ/sv79wIXVchgDnN/5gytGWTxhj7jM+1CP9B6L+PMC2DGl/n4KLm3lXqstSkV+RtrLMTY7OmK
eEeYUi3AkQQJQTZRX2TUKtepmSTNNwWxM7xTnR0YtgR/NRcGIjSqo+jn3Sep+rnkFWeRzFkTcRUu
1zdJ2AigE7utNJDpXN+AXC5pP90suGgedDqwmC25Ac+Dk4pK26IpMzkutMmfcg6CS8xdoQsScBVi
Ki9fof8/84sKIdGbL4mBOZjrsCoGwYGr4tfkbsSQK/Wvq/kVcU4vYNX/xWOL5LUs+iwfC+9dC/GB
PpPkgnzMJbX/CdX6SF2J7X7Wer0MFZAjt1aL8Ck3fHn4PpxqDhJc3TdHZAnusOrhp8qVszT292Or
BtUA2AT2V8V4WA61LB0jaFY8OgjyvwhCw2R8I5sUOgTYtyXaUEGnwlFpQZQShpPPX44qDK55Rm9L
/HFaEihBoDbRT6mkEmvBOyW8EBl/Wyo353i8YBIaJyjjs0HAIs7Q1lp6V2t3UyM9epCVzZJKnY2q
EJ5lU3y1Ytbp/trMm5spfH8c3YXMzR+ibiuEQW==