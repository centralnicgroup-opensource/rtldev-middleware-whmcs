<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuortIT8d2O85G9810zsz5loJ+5LGDarkVjXrzNo/OfjGv4kVg+FvnakK9I4pPgfvol5GbA1
Mu9PaV1Iris3sOiE/JR/LEfPAqQ5Amm4fHV1SxerX1oF9vLUjSeKRYlEYaprvr8T9q8e+8rfbwki
hTnA+R49rXz2jcIZODSYDcA1EthMZGSeefteI/kf3UDy1rMfCaVvyRFMz79Q7aBm488pCPppoHGT
m4xFVW8BP2BuO+8D3VCPQJEDfowLGEQSMqK4EFAqYuSkSdAwyCLGPB91sJ4ONsRj2n5O1iJoqZZ9
TGQaHsa2sMI9O9jW02WK/w8b/l+VtMoTj97r88t6kPJ5k/XHWF1AKngc7iQ7irmB5xg7M/5nWB9f
qfCVhTwm89rsKN3q4ryPWe9pNQ8++rLJ9iqt0zBgEotGUm+eOZRVDZMnnsjQR96MVI84PnsimCcN
3aJ95j3HGWytZ1ViunO9NtT05JGGaAbIF/HDWr6D9EiBOam1/A8U65qpO7VAjtO3TFNAlFIC/JAM
8BxrrqNBT8w39Fvhm0ZfqREz8cMtVAmtDYJQAYAuArf6ZEy/jcGFdxoouAL0cHOHRUviuCQ47T6f
kj56/P/8UjF0WhINCudu8bW4HuyO/UgppOEgwBgh0BHMEkYwpFUy32mcGddVMQ/nhOygs/3pKkWv
fuDgMTdq+E8Nndl0ViV9PEHG9rA5zPMCWmjrJj67AFTcZN7eLNsKdCIFKZ1eA2dt4xRItHYgxq5W
8fBQ/fUy1bsHg3qvuAGhLULhryDB14NmmpbbsPDJGvlDZ+t0K4KNKarhV1zDwKcEN1k5mhaK0vkp
73JA0gWTM3CtmvfOc+USgdJZ5063omu8kBYRJnPZkjZKYU8=