<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu83eIFbx1aKyB8q06ZdsWkeik4rTcuWv/eIiWJJr2oUsXtp7uHmFmSKlM4NfANE6Q5FhsKn
Q5uVzWnrzf/T04ZqwzVz4B5yMY8rCo43JOznLNjxhknkx6RiDdHwhIM16wZz8wxTP2ZvKsX96a00
EoJj+j3RIshv/Mw6uBHFjqKcZwtdSnwiQ4R7Z58jmYeGe6jEnCODyVUiG/r7dLCHfJE4T7V4Oxxt
ZzGiAYfsjEn8XjOr3nqcfhFbmkIsp34Ufck/vhJ35b6nfRfTddK58f0NFJPZPqbyew4V3v+trc4O
axJ78F/U5P8ArDkbstWWpXT3RpaZq+3NlIO3vvJA1gbLxu8vJcaJwcjuUBZ01OJGT2a+Irvsa/V9
oMcJq6jM7RjD9nIP+Vek8njB6XYvo067ReskwfT68FySGuDmzN8INDIZpYoglQrZyT0fFoXEl+nb
4VUH9i7y7bWwTMbkr6+ZiDDJCeCEwCCJeKHlGvsQ97kz1dEF9Cpfbt0cRbWx97RFbYHqeEsFEPkK
65RlKPETrcRoOPr+Gk5uC8LS4Ih0Mo0AfolRVamNALaxUYxUagKA96oJxJBrDxvICkNMCUu9r4h/
tpNbfnQIWQfHhAvT411V3Atn3RqdgbtStd6RhAC8xk9g/xIbsYcxLeIwfjG0XFcOlquLklpoil31
HRzw4Zl/0QFoZQTc+eWGOa2ibs1b7iZ3YigRo2sygjR6ch2LZeaLbIepcMInX6wf+gpVAoL5SqbT
4YwtVg/HIBWUlcoFGradq+zYUr2vUuXxH0EJ5VUU5/QiCy0AABpUBIEXjL4p0hgSPJQkqAVCGVDT
Blf93gbXsTPtpXTD6ZLJ6QBuXL0lp5hXDI8o8y1fhyIYORWbBfiVTdNnd6k5SN8JFg06E2WSoEkR
Gricbvg+dj8zDHiIw8kAN/z5WUIfXcHAtCWhoe7aBeUKT1ZrDcl5mJfeP2MPm/Fou4pugkwZUWTn
qFPsVZx/xye4yAxd+9WkU8AF40el+nsKyTiKzSlzWEM8r8605+7lygvo4GOm+ZxLAP797pj7uSN6
oEKAe5iZdSCoW0a4+lNhz4z5QNMao+WazNNFgKEbdP04JwltrVfHaEuYpvgMHU5ajwZ7fIK0o13o
V8Z9xjHaWJUOieT4opFx4prPuyG8o+vu302YSsTkTc7DJaoJntd9nkKtmYMNAXnNMoE1mv+LYlZk
b2+8EWntM52VN7iJM21ChVQSnf7gtv0sPy3rkzRDkS4auTx3cmNDYRlPt+p7R4/0MN6zTPUe5q3i
YXKBxfKZEvzBo8f/93ZteCWDgaYA41Pk7kLW1MO9x8agR/ymNIBuy0wdSnyKV3bf2rE6J1/+sneU
lkEfu+EBgG/IXCTI5I93Zo3J4aiMl/3L1vVsnsCzbDXKWrRL2PD5UhCL/MgTpcGO3XyQSxl5bKGQ
C1fOQl2z56ZDjyabijpHxtt+RsqrX5VkXrn3TTmoemV5X6kz6TTgi5miabrQ/k7DllZR6xKk1506
12IPEfahkEXISfnT0ls/XMokSOTm0dRiWosECDKuJBxvePfgbQSvaCUoPKB297uaFvtEaWyF5Bob
ppzrqnXpQykq3CHKDSVfUKNDqhRd4ND/DxFTsQ1SaGJ7BwVr+jPBzUKMOjGrDLsH90S4qkpnUmZ/
YVLKS/uj2RA4TWXLtX389hsw2/v4