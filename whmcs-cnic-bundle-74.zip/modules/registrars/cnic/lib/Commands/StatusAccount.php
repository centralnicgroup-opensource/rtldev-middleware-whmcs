<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn6quyYKcDZlOGLswoB3EHYPvwAQEenuPEaz1hLu0kxQTj3LQpfyWE7bf3VgttZS4z++nYYt
l2R89c9TLqExQTiC9mdLYBSPq4l8/OvzwX9NKBzgoyxnYubwzSf44XbjkF6ALPzTuQYO/WbpKBHP
nVS9CLxArQ0quBJpJHPkyAaE0ybrIu/LHCu5VKAVWjqtS1/QTKQA7kKejE03MeMEBlms/2x4FTZn
Yz/rebzkCkyr1xJfkmDFSXuP3QabKVOWFS34nwjUyIcPfSzLb84c+UIdvv8lRzjpJ/6AdbAS765B
JRm7ROuHY0jZluh9tqc/tgKOGtJRHWNvo70a37I5dY/Di+xxZj8JvujklZjGuEPBLyI8cgEmwcIk
wa5Hc+/AOtfty2XzH45P9tH9b/U2/ZfmXMfFh9szjbgteAiG81Q/XOG/SIRjtlPK7JFB32XYaDHa
+XzpW0YJb1enI55RI4b9eKptKaMDwxpiF+9fNUDhOb73ZIboSDvyRPMDNnOZfZUVqZNWpXw/ar5v
CuEZhFVb81Th8deEVCfCr5oE+TzsSyZEeOpoX4jAZbu6raTxqXtfaRPplk7Wh0CxY5XeElMvECss
fNA6GKjlIIT7+hJH55kZ2/9KN8lJTCBwVJc4Aq5lDTzDg8KK/sPsXPJYFl5pzVaMvdX2A3g5WeJ/
QgMtmmfYr21MvVbI+Q0Ot/jPuHcChBCO+bakK5nO75DZ2nHZ+Vd8YhSsg7xpxaP/AuoW3WkothMo
PKrtmnERB+7y88t9mgA7t4LNsOA1QCoLIhWd4aveuADTkTVPgErFogbX0L/IPi4c6c5LCBcqjNqB
sPxLQepdYmiqQRSJKqZbiCw9Vst4knQV+Z3qGj5T3pd3aRKRilDXLtqTd8wvFiC7zjflfLp6IEVm
MgM/CV1pYhcrP2fnKbvFCbK6kJRCLGSwR4VwkxXW5lKXdYmAsmXxCLrtqcQP+2PhDUZc6AZuTqLU
ne1Rtsmjbb//YBEFzEaMskf11GlJ4AHJ9PIOLJQjxEr5kCZp5d0wTSRhbiBQ+uZISEpPKm/kyKEg
cVQEGgkwTv8471GtqsI3ZSBut9uGzzhBHqO2FXbauSo5JSJ5qktNLEqjdwPvbM5F1mw60rCc4Q+f
CYmKxyXAZfUGtOBB7Tq9MmMLU9KSkciikzykbARJAoxaYZMT6XXudCR4sld9PVFacsxma11g4wNJ
xD/OekmtYGLF0zc3ZhPpSdZMAQZThPPU4ShoPgcn6TgJjvzX0qrIoioJ14kCDk3BmrFTMkTliWDB
1f0Hc2RsouTitznDwxXvyuVUXAaNT59d3p86m6bmUr0hI5Jw0//8lGpI4v0IXVjaCj08qhCZHI+q
S7rQcz72FW+cvF9CB7kgsqXGWKJFpixLyyoQzJE6x8iATWwJUQSxrlagNtNO5GdblWYRpzdxxc73
BO/t2eV5peh7ET2Xt0fqxvOtKyYPK/nHMdxO8IvLAqfzFWxbZjSTiqBPysqvif1UYcMdMy5J9GCk
YqM1cx7p4jzR5HXoH1uiv1nNNhXqN9znVcw4V0UVGFnrNVHqxlW1ht1e1VYdsBZjmtEFTtSrLZ8R
ekcfaei/kestYu8FrySHWyustXXO1siP4Eajzk4OavhOVjr14hmz07r+rFKkbAVSJMynwAm5mGZd
SOeiif2ivwj723Ju1CH2kkhkeXSLVRO=