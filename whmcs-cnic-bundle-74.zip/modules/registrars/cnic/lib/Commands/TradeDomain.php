<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpYL5zxNUEmHhYQ2/PxlPe99wqmf6wQY8ibrXJHJl1nuE4zxKzhcFHSSxOv0pGZSXkxwHkwT
OHOksk/cE92pPyCn/DjfKmJ2zkw+zYWNZdtbawEpdHy/s+d1Ial5RUSebiW+14se81LjIxlueIv0
D1sqiuruo1eZsYyg3zsg1PIj00rJ7c7gwnpPV40FUPdtbKB/x1OSTUzolSRiHA5CQYdoJ4jeuWwL
428Mi5Juv73GX2FwXWRvstEGPwK3Hyc6UjqGjgjUyIcPfSzLb84c+UIdvv9OQwOUci7XrIdLm9TB
dKMdCtYLs13NT/VbSChJgwCWAHEcanml32ee7tukYS3FbZO47r2otcX80fB0Ko8kNh+gzsxVmBbJ
65aAempXvP5dXE3Cqdtrx0RlovSZxCO/wGAAszPQo1uNbTYNfWhu4ffn7ocRh6UWW/V2HUZc4yha
AVL5u/xHtnNyll+JDdOJSoZBU4zVouEEPxz76/1CIEChhPOT4oksaNdeSdCO9RwHc+5nEOdytlbO
nbe5aOQhWnqH3PHmbBtKwIZEJXvQaPnHavOiHcb8az7HvSLLgX0i+ii/Xg7u+6Nj7SCOEZi5A8YP
yVJe8wvwsPG9CmMe9Htsae74H9JO3/jEANiHlmYR1ZL7rJ6fYskn5xXt/rDAN0p6tpJlA30n8xcg
YHIubSJzf67IXb81YmX6HZCVyZzmDWRxkGIo1IgeWuanX90ikqzR73bu8yOBZZ8OmC3WEi8BrAZt
cnWvexJWxruV9IwBu39EXKdEj+0a8pt1z5ooS0Ocp5UM51igW6o5pc9XGVNbPDZJQl0WrXZu0N5f
SVLkC5cZHHUWVkeZpSW2Qev9lCmZucZwMYgMT4hhm95+lRBEJ5y64LaHqzinKd8qRhKmN90hhe5b
7zgbPxz7oar+UL+eGiCuc+ihK8lriVbFlOU/00jbrLcPC+t34+8Ea1M571XYL9dFEanWbp/lKFPj
y6xQi8QxqsLCdhmx8XN/CO9vdDodV3Fa8QFH030Z4G4ePKcEnbDPuWV3aGPhdCgA4UfFsFKAoE7C
Osoi6QMfkW0l4PjodYo3Ge/mlEIr/57bbFVmUmrjl0jy+TBQPTk+uYk1/tbb42/S6f0n4Ivd1JcZ
N148nTPoIgFs9q85KYl8uBFYC1Z527kXu9oGmQ0iBzZaxafIL22IXiSjmBOF+cfSakKOvggD6T7h
ax59vubDwqDxHfbqnM9LUXejiHxshdxp3OnITWovplYzDAw4y1iHX67fPxCJGQbV7rd/fF5ulahU
A7sVyWr34Zj+B4p6A9ESsAs1UW6ynfF/4D23spkkKev/zm+wKTIr3B2x6rZ3Z9capj5q02zvbRdc
JKdDUAZSriCs5YbG29lk7cgqj6XWAJFoFMPvPrRl5vjSx/RigRwAPXSivXlnHxKhzu6NDtJv0T3B
woRHeaK3IY2x/xd+fWNGWL9OcmvdfXQxafDl7MdRE/3ozB3O5AUGtT6fZmVYIwoZr+HzmBHvCkwk
QrZZI04Q2TvOUgVcEF0exZYepez8RpdcA3sT2Ga9w2bsMeio+uhpXrHCDA2KZu1mDjXNtjoqqNii
D5I/MkIItYebs1OmSD+g4jpSMZQjp1tM3+zYklR+twhY7o8ZxE5wDLtnihkPyG63UjxHJpiBIzsH
rH1UxX7WhwS4KwuCQSfaS6mS4vvuB77do7NIns+ZH7DlMNPvgE+Sx4xhr4kuF+OtmfWCAqxle/ht
UC+SG4Rld94qFQTzOey61SRpz0dqJ8x7JimlilLZsvavyNhH6dX07nDiAbyP9TNZ9Metks8jSlnU
7dbW8hJ17rNIJmHIMXyOOYSFb/Y9mcAF/9ysJhlO7qOv8IxCjxWjf5Zdo7qjvUBU8p6U78K+Nehn
GnPgMueb5iEbdX+EkiOQwbsFcDSt79REeay5cwVRodXlUVau8k1ZCcftp21tt2cEbZWKGeor0WOo
lPTO8d/5UaKjKZaqooICcQaRXPi++NYozHegwHzpDsbrGta6DZ3VXqv8mHm9RSiapZ6LjxkFUbFj
qfZ9/XB0AQFa+c5f2BjF0RYLx94qveowyGyNYrmqqHXnzQ3wG670AT23X3KgYKLl9znrkihubW5a
cNzRxyEZw8oxiemG7gvwPeWF58ycf4gQHUr6n9Of6D+9ArJhis+38/4ZOZdAn2UBIkaY3JAUEm44
k2hOMKzn5OLd6i53uqUW4tSHCcael/T2senHErwZkChxCG==