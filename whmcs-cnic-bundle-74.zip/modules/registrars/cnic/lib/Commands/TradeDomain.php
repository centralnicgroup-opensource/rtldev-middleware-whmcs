<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/bZDLbimesUQT2WUZJhIWhTLjXbFeh0U96uhFODj9FmWJfOorlGfcsA+RKBkVJgHYLG1EKQ
A00dIKuMz4+xkkOTWUBfK8YHmyopHGfLWMd1l3VzXEznYlZmTv+cVyqDy0f/HaLPlZFyNqo0fxVp
JL+3ywdCrX9+OmCZIy+G0xj4Dpe0QAsxSkoFJ1x09SlJ8KWHAhiA8dbPZsUtFXR6RPU09eZ1d0Rh
DxYON+RY/zKmXHqjTQaxt1qifw8KhXswLfSvjCCMKR6bkbsUTGKYa1SzDY9d3LjSzEZEtbNu51WJ
XyS6khurIhK4o0P4yKr1aM3pv6rTu1yIO4cxyrEOoT/x8+/LX9C4DUsBDd6QvAQeJMiLd4/UjjER
8Q4ibVtYNhWn6BJlubisHgB7MYWYL1cV4gCdWGjZv2GkHsdQCwEo+5n+TIGFQ8fLYdE6rAP64V1X
7horGhlZq6D9oto1E6AH+b5zTO6kxCJXBpEGhwtBvhOLskcTVyj/zXJex98B1mH4KADu01mTNEjk
Ep+2wA+z+xfci9NlBYPEDb56M8QpG4GaofVQKCdFJmSVfN6Fyfv3+wJzrHNdswLEgPGacnEi5TVK
D/cWulIfeKX3VDjB1fmRnL96ADTLwUWtGWnAQ1Enqpgz2481yuAz17tM33lFHIqgdYUB91YwG/q9
sCYm7RUFloDXgPAf+4++upfylB9zGO9Rcesxx2NNZtgeOmQEU+WS3drfJaRf8lsV+L/1VuefFg7s
OjAthBwPYh6JPVUXEftY7GBfwHJ0TmPG4Nl9pGCl9t0WXEPS9M59VjI+xU2Od8tORq3QOOGZFd/w
gOUdxHo2x8ZKEzxKGJL0HxRss5aOr8CFNqJO43dY/QYFtgTKFjWzxgmu9eDj2nGmwx+WJURw2lHK
X1OIYEFsrdVJEmxNYgMWCnI0kd98RWXxE2iq8cHEWAsYMG+Icb8DOjK8n0KujzMZsUJqZ1Z+3TbY
uQpKownDBCQbvWlyE+CjLnout5y+SGQP9ueT5NMoraVYLbr56FachbRGqjdIHu/9UNzoFQcBXmS9
X9L014zPoESXhYsN2omH3gqGVe+C4Wt0zJ1MklvVczmBhL24s80p1hhR5xjSPK9qkS9m1C1/4tY0
iF1aYpkKqArIxFGRpwuFbGXDMM0gAe4YwtNJkUbFDuXQXt/++dlr5ZBCKZYOLL5n7+qxrSBrkVai
3VqYxwKR4bhddKj9W2gngdHP4QA7pzauKuEdX4giTLqVvlfZkN+roHbk9JemUUSGoK0CvD0LGLze
7eEhWyusLE62MMyg/9jW0nlEEcEQc7fNv6XC7gbjRADwjbD9XYFKa/FJ3ojQ5mqjX/5whKPPyxie
B3ACsM4PaaRd61bKcZb5U4cYumBncI89LT8Lo9VFwYnXxREZkdSYEEGOAio6b7h+kblOInW7OhRY
g9zIyQ/wlWz/CxgOszAcPN+56qD2A5r8q8ud7gZWVb59nkndIi2Fw6CdmkYVxquZcZRh5KvDWn21
7RfI1V9uYwrh4dC2CHCt5kuqah7rj8L6NcuUPmJNPYh3ijz570X4/pSJydZ3SqeDo612DyYM1R38
yriN2IMm7aA1/XmVxRu7k6/ljtyvFsrwWs76inJNP5mNIYxKIV2xJe6Uk1v67G8w6jCS+wNzbUwQ
H2sMTJ7al4yhRpDPGl25em/nKnTTX31dQAznKNQYrkp3dQsq2NMQs4E+5nsaeLc27yPOCdU0XLWE
2l0pFXqv0nruQoX0IUfwfylfW5zpDkmoWY8V4nlCnCzQCIqCBfqIcGKgWlbIhZ8WBOdO/SY4kJOL
0VzLH7PkxdX6ki0Aaf2B2fUMjEbTQPJZGkRizgk8LU86sWD/27hJxCBIODLrwDJUzjJcGCziEceQ
KPLXUZPmtN/97s9E9w9ujKHwzLRs+1aNywqgKhFH4v4dgv4ZK7WEi7Kcp+bCbWJ7Wl5xgMyhIPTq
77sMZUqd2KqNwEVw9eRXJclqvrIfNgJoa10RElwzO2fNZZHRyk+Mnj5IcUrQ9gBe3t//v7gmFPRg
CYLuwTw4rjbYLjFsfG9BSEWYYo5evdxhA+voMl+W0+yRR7KTXVRM7X5RYgHXOFJc0KDWsVWjIcws
8BIE8Imf7buib9JPSV9o79LGA5Y7pHMvwlcclSV4sYNQj6WCjZBUdjqeAVvEgl6j1IXnlnGmISHG
UBfvTy6m/CXgDF0gREko1SMsyualzjC30K4l24M5RGmvaKYesial/W==