<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvT6ej2chXRdl/Gty/pZBMHR6rsSIXkB2RYu4aFAEDK+uIVspBgI1yk1NZdcid++VDUlSiZL
uUYjr3RYgrg4RoAG4k9fW9ixcTyEnkeMp5WtPSp8ER6rsfygCicgQIyRRIHEdIOmQ8+emYyWTQdQ
MyBhr2yIoUQBd6mP07usgFIf0XBmgh0nDE1hyAxJA2ys+Yprrj200WLnt+uFf8y/mKF1ZNH7tPfr
yKTtCD5uAOIhmhjjYG5uU12CZk+aGWP+ZCcEgrxnAPcbprMKWIRvvAVdaXrkG9XhSbuhL1Rwoajj
wMTSOsW5gykU0tTrzGAe2jyH8VNZu2MoNXvUzNmabaKuftVBshfuUGxn7ZeqZz9Y/vK/w+Q8jXrU
WrcFP0CwV/Ddml96yXDj/BtqyLDUjxds/VE34Ah1e4johGhMEBBbQ4qmi3alZPnd99kYwXDL8rd4
t0uV9n7f6dLhyMIFO0S82++ft9vepGb/jEwe8kpWCWnn0KMSGaSnMr1L50t8b4EvrcmjnrZweQO+
LzJMtfPgv3QIru4N90uSlD4iMzaphDWYHp2xwbhQ2FZnd8BX2yhaPzfAQ4fWx4CqGdyzkkOqWm7e
WxP6PKOVJWqXmLCBLko+zT7FsX4tQm0RA22J+juwu2dq37uIMobWQn5eHY8S/HEGHY7Vs4f4dj5o
kBZXo+r5l9JCP2JOypNPGojWgpfktskzqPnu4y0CT6zcnrB7uN6qUD6CrDrJqi/z1+ga5PIcqmuZ
IU1qJ4LgyoNlQ68puT5hZDELM8yb9oNjluaGYHxP304EaSEMAYfc6xQyE/hD/fEWykvYtCCYeqV2
cxgdbrRElr0+RYejLV16AVOP2q2fOhmrnPJOg3jMWLxvG0gjvGcNa1680f9cCw2gTQScxIfhdy/D
B+xg4NzInPYBYXA1eSYIymiB91ZlXWLX6xLtgdsBFKmUnFw4vWLuJv21OOTTC7l1Kw5pR8Y0sKXt
/rThWlBiZ2y923+Jz5yu6SPrH7/I3VqsNf9+0dT7DvbVI2GhUFDx/pLXiYKD+yoAErUPZU7WSfmB
cphUBfjrRddTd7CCBevEy2WbueMcZWDf9VJZ3Z8i/byLs66xLvOUnfTRKhUTLB3WKuvqX57oZOwl
84e2TfkWBicyYDJ6VThapbl83qhp80/kNDhlujlM/aM+X35FVqot1mNwVWQFzi1jnG50ZjRFfSWK
KGG3Czz7U4BMYCe7Frs+X0R+KZAc933n3FfubPGjARQoIKPqJ4Qs2s2R5PO91O+Ldpk0bq/5uIJH
lYChBKtqed5Gn17q/sKmGmP4cF1F4xbS4WQiGXoXtmqs08cR8//VF+2oCUg/OWFObP4j/oirIfgB
Ul7Zzqe9maJVfKe1ODipEN+QlIWBu6hdRkjGSVuwa/+ddCj4mMVbHtHfpHGcKdFlVLsyvEvgz/43
+HRqLlyb5/bNR6wBn38Az/rWiqjMCBgh1vnql715s5w5I6o+yWZ0pCffwyqSLyR6q+0JGQZjJrfX
yKGi0SZyyt4ue1ylaXA4aM0B6fgzFZ6+zqPPFIbY/kZkPRBya4JSk/hOE9Ko9ItQOD+OEaENNyHU
5vNr+8lI8GzxT4lnjdL54G1IT+NssOc8hFZt31AAyIAtbZ1seDysi2k36Xhk9qy/Nxx/Nf0k83zY
8DCZCEpW1LYNIf7BCbT+6tXQxcyRgNB/VqQVNSDi7CugCTdXBz0DyyhyDjDA1zIaQ+bua7Kig7KW
NVmsyb3cAg5042saxx4TIbHcp6JLLCXWdqO98MXyL7c4Zta6gUJfzmTxKW98kGRf96RaIRTlWOQj
kC/dkpMpU/adbrUFAkB6Z72Vvnojknr82WTbgFCTLe0t8eYzuEE4d2wfhavIfwIufuEl52DW7Vrh
bjvz9x3uPCv2487OOo2CvEkLzBQ6muKBOo3jyxHiARgNbqmmAs8zzW6jidbF0b5JcRwo3xigWw/m
i2IEyzjGO66iMfPfgYz4WCJXNbMGSAE2PLWJIdwvq5HxecLTDwoeoQmtPu2OXhaEo8ddHYg0ukvv
ahP06orB35erxs45wqDQPAoe95fUzU3xdvX2/OnAJP5nuKfQKLc660WJ140ZZBh27idb0GwLIlNX
ugfxjwnFetiU