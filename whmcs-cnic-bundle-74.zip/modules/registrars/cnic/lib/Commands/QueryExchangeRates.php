<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp8ZKaXx3QTl0f77Qyw1uxGfbdDTx6BgbQkuAIjCjazDSGeUd+VIVSDXCgh4cs5jmHu4Z459
q7ogd6h90fE2Od8H4VmBM205SG8u3IDbEp2KAjwY06DmE7L5fpxqmVybCEvL9TGvP4bhcOuTWUVv
8nbiwelXYd7p3xPuQjWLr8nbvajfRLnWE5Cmq6S8p8UQ5XLoa7eWmK1ZzS+S5Qf9dzNDesVo73bB
rJqmsZu2Sz4WUOlx3dDDYinw9pBUJv//RCYUjCCMKR6bkbsUTGKYa1SzDWDWLn/NyRngwQw3lHWZ
ksSp/ud/CDNHtoQC2+2r+0yrGXnDAIthguPCmCMDIzA9Me9KH/yNOk8jr+9Q8qf2nG/feWPrHgii
CH9+jFsCbIpDP4B3wdVzanS2KpYHgQZhqPZATqDDgAb5h9TmsW/hD/TFWPdKQEV0Z42Fhbz1dy7g
h/5kzBYS8ZAKBpkmCtRHg4ART+B/yqIQscg6fyhnbGapihw2kH5kYJYcwC39Nc+3Pif0Rq0lZ7Mr
EG33u5P2J9KZyqliBwdcE3diBR6mckfVoZg4IrUjtdHbu8DTN99Lb0zUS2amp9Gndefi7RVDdRcV
QnYHnL+hCJByXVfNHVo97s+EB9Xy0qb7aknNqr8KA0cheVdx6PMySJXCiAQqkFGQ9ecMM/X4D1J+
Ca5jQkCAh6AYYGh2KuDr4bqVO4TxLPCtDKcqaXrc3KHlMtwvS8rYsCkIoAfgo6QtxNGxNszJ8kEw
4yyWfaP5QKQIaO8xfIsjfcpAwWBMdY1ZPHWOcwghzY7sLQG4EZrDmQqH5NKoBGN/U6dizvAF8C48
1oDG3LneYoCPWv8nn6AhcFj8IAnbjMPVFO5/R8/3w0TnYQs7hMvISVYWEYmu+96YQZY4/AZdw5Io
eI7r2CquZXh61sIzasoy5QoSe7O1YM/AT6m5A7CwC9v4iqWHFq0unxA37DNKW8mMabEEnEQ6/hy1
iQNxv9gwuNEEdnWxEkl/J/+sUCbrzUXHGP2e8ZyPc59HxpjlXNwc9YHRIDrzGb+9Vr3iFvEsmEzt
AyIlJi922hFJHFLoTqvqd1PoVrTZuWNum21LajdJVV2V/FlTSpu6Bf3TWOQqYLd2JB3WLjm+3/s0
qvl6EZb0uvv/L0u59/ttawzAhQg+KcAnUsw87FO9x4uQNZ74WfEdJ73e3Dh3C1dSlmxcHtu3FmKc
/hAwSkBhqe0+4/uPdD7GHk7oK7m4bB4pXvomfF3LNaxAqD1X757odSA3EQvJ3hWd9saRyt+ZgukI
bDyhBep6nLtR8a/B4ey4+IUbyFPk2rNlCYRiAqYTqtuh2TPAhGBuJlzilLCf2FSlKFt12TVED4WU
J4Vz7hTFexdcsyAu5JRsyC6p9sktZ8wAIMPweG79+ox0suF1LHjw0aV7RuIqOWtNcn2qr60Wbyzo
NChK06x2/akuPDVGXIKAKrD/Ify0gdUf5a5SDAWHDNmijrRXP+W9FKwpqmaeD955j5hfdxd/ojh6
zDGOGWLG0u1bfxr/CCS5X9f4yb9ygjVitlOJWEkhLCGckmkxhmrfNyYLlIrBqxkNaK9c6LievaP1
Yrd0flHHnzhkSysptLjQhSZ9sa5FjvbIOh088+dI2hdEJ/U7pegEf3X54pdb1LeenJyLLXU1I22Q
IeBgaySx0CwO0/TgoXs5ASXP6CBuuXRfbm0LIBDWhP98BeURJNkGyFB4TiBF88libNViT15G0c/F
cam7WD+9BSkGOnqwycDZXjb9yZgINoHcM+iUkv/VvteW47hEqaknEB9eX89GDgkDn56UAHJRbMAl
mIS0hnBMH3uSgA2cBt6tASpkCKwANGdGjvH/JsDsQfAiG8Y01nrBLOuNO5VIPYq7UyL2e+zjylyR
I1lbg5pLk7ug6uasUZJOYS/+8gUZKWlkvjvMeXdukYAG/v7RqnUKC5kwCkUAwXKqoYixm+E9PTGm
WEPU5zf94qecnMILYEK16XZui0SRgWwvZv/jD52yc07FoK+FP2OuvQsmtqT0rg9+sCOPMCatmUKn
UTgq72mM8QTEgGz6iC2iMiao6a4N968o2UhAb4IiH4OGK5ikhzrz9xs0DktNAYlC+z8PAwCGelzX
aW==