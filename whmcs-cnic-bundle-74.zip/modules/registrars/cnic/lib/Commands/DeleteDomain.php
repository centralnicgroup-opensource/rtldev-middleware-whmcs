<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxrK7L6Vk+LcPkQ8ScFSQux0+vv5DWMMyQwudnHuGK5xDh4eoktxRS7TdsjepFOTHBJe0ri2
T4oY8xXPgUZUHQLtrXw32wXDO9mD1mHfNHijZPgk2/EudZ2Mlzp2YVkbL0+urTAyFb6h9zyzR0jn
+vr7ELR8qJ4oCRRnkuJHHfbWmSQv5Qr0C9Ug8ZViWsi+B/X1vFCHspVFjV4TXlDPHENbTAy3q9x7
cm4n7kETQ47uaVdOfVtuxU4UNQsmOfnfh0xlgrxnAPcbprMKWIRvvAVdahHlxA2FnLQ2A6g/lqjT
5eWUXnAvcKhbL9DUYsOkjYc7qgtB9AHVxIezDPLcQWrPIo2l9FXOZZaQebs9vrYnPhCT8NkcjYPT
xrPS09lLTMM1gSNkmlHxe8785nWI71nrlG2FolcuxFkcSaQrmnSo9SwsJN4sEs9iTOdccqyJD2Ws
Jh5r77rC/7yo2ZL4dqxin5OY+JvEtuzpxvuD9snzxrNUgY4bdh23Xko0EMq7aKaSIe5XkKr0s+Bf
iRi3WmviSxLp0oGOcAXc218Tbekiu0PVfVlP+I1wwjnJvjeBfnSC/PNqQp/zXJi8NGW/wVz+zvr8
0f1s+yn2WzWIeTifXpujtavivVmtbeg7rNaASnzDgkLkSWHSeWwivQONADlqTJbhts3p1rVouFip
J0ftxKfNg21kMRPzdMImZfCmiHwYL3iebI+9+iSPGK8aOW55EbJ6V+F5GVK3ilTqT48g/ANu5i/u
8mFiXO5fsJXaVvThvG8kfsYOsF8drdqonzd9CuqKhcxDe6KRet1SQnexT2b37KuRxJFjMhza0yIN
3l2nKQJbB/4JjqlCigFQ7Fdyf2BM9QUCqfAe1JOk3FAMTp6HgkHMKextT5BcxbYbOuy3aEUeHpSo
PlhRXmUOSe/hicQ1kqkoHHn/DGlvLyLbf8Hw2Mujpnf8aJHHZKQwLsQeEOXjZE7Wax++iu2e99w3
DRpv1ApLtY7Qc6RfP/yvGeklk+qKFs77CY2UFyU5IhDw5wsKeoo7LS8Pp8anLCaPNvK/nVSlOaQJ
/wnrilodFIs3i/YxWMgP7nWF3S3SDMr6dFlYDSgC4cRBkQpb/bCFuAc4hkRl9Fa9B799bkOj/G1p
xRd1r003rzZU//fGSWQ9Bmcd3IMwiwOWHvLxLFgOWE6ADLbXE8IRUVjwEDphpLfrYaSt+3t2q/GZ
/f8s2rrn0ZfBbWgmINrLbiIhEwsaKXxTj+E6nxAwS2/A+r3xgv//u0paiZecaXPevqlTNbG2SjGQ
8ltYkPU6h5sMifYMi67ivylFOy1iZqcl9K45+3rpKI0xyvJP0ss0IKG1/ti0Ssh1c2AgGYtJUlOG
mWlPUWpt8RZ/PgGIUDcw4yCPZnDfEt7b7l5uvPj4/lEQN84r1839WxVh0G84AmJeCGhwqQzYB5CS
8OHJxl+/pmoH+Wc/E5eNct2Ovd8ACKgFlqiEHtTdOdRPicSDib8vEKIuPjNo6MO7Bd/JpE3oGBJV
iWvkYMJQFKYJKJtKZnzHxW4LdyA+PmmZlrJBlAJ4gV9524oTxXErncR7NJEQZVCx2RfKi1eRUjQ1
/DXv1zt+6WxHJKSDQmVA48BdseeIkPidAuUUuVihBa6UabQgGbbYy2ebe/rQzwfSluuZq0cBEPSO
KaQv/xSSWcbDt+qLNsTQ0DShgRxCC/cyO81cDRiudKhnBc7W17/vGSz9knhOHng2n0EkL9SFSOur
DW2Y3iAX7ZwvlqtnCN3avL9MJYdDIpy11qWHoFrmVRP1bOXJYQOoYFpZkFg0+m2Defqgrh8=