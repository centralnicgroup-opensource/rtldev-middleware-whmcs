<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/dLisyjEmX0A6ScJEX0x5U/OUEl47raEvAucbodcbOZIp3FQVm7BNuzQLuKnq7ssO9Axty1
Cij0/0wXxod9q3IkYBjUGckFSBouI8JpLGWifmbk3pC74qxCjXQB1HZVqmyoedl76rQYb5EIL/8o
K7KvKvO37t4dFqvtbpKIBDHMaGBtk8egJyM49yGLzHYKuvzdXc+Yg3Oppi7wWgwSbO9kOMBBz4Ha
AC6cHOe/6MfD/abp8f5Rb/fbYHHqcUH1act/jCCMKR6bkbsUTGKYa1SzDXvWJsr/rL9JjcWb/nX3
gWTfGM157NMGbMvyPYe4a9reGY0t4+24CEcwNG5005G9qw4Wd8iGulDGStWUOkAH8raIe5GHpT1r
nf/wJulrC+ry+LMdYOT24hrabaLOqXRsV3krPEjnvrHebu8/6Zj/0oB+WaP2j2ncl6NicvR/LRaE
V75Rwhv4gziIzh5SZxu64UWsjzuGpNvN/bA6/LjLJA9Ap+cu3oFwiGO1S8RH64RoO4HjQV4k22AE
de1gYAywTL3vveTaoTgoLF+m5RRf5sALup7JNBe/fJt7LrmMFIqPbSGsZ7VYogB242SJOj32Nk80
GlCAc1P/9ZYU+MACS40uN/mj1SKec2vJSdHNRJjDigDwTgVhWDgxnqmrie5iDF/SLNhL3f3wcGaJ
MSEHhL2/Uj8CVaub3dUbM8SKxDgufRKVSTV6Xw0AIr2ABdebMdVsBteVcAPR2KgoMzuxFSd7pZfq
9NZHBS+prsMGGXj2MuXWe0EaYOtsTL23dkUUMRpSM57O775Rl2Wc5MtSiBWq0VHIcvYCsQphXeci
BRuU0nCgmorsGxwadkr0ViYJ9EFbmZ05LW7CcTai32L/g67zx8hDnilGK0sLvFiB9WMibSfwGsow
olqhRYzH+KxPTcaIcO0TU+ODJOmSG+25f9iNKGsRA0RgPg3pgntvj8keSAy99QT3gjkIRN02MIxJ
pReHTFbfZqb8AaCDDdjI+hCB/qGt2uGwFPrrA29623jfAxTs2oJUSVNHWIc30AQ0fkhvhwClltxW
nxiwlH/RycoKDXIw9OZ1dVb6MSDF7I6JjEbm47nT5pu7eRtmrSM5CqqVEQ+4BxxNQyWGRe2doQlC
JFBN8tvF0eInI8K/22q786ReiXHSvEuq+4v1S2UtlhakEgelUZjltLYcCRKCr0qZeUMqrFImu5vJ
1SQu+cbKdrWdqDkWLs4EO/RvVPY7Vw0oe1CZsh5LTYFTThfeSmnOdMDJaljlv/cgAdspzNDSN6LT
vqJCxdN+4UIHpEy2BKHzAEBHQMXT3+cUxytyle0zg2HsXNrQbS7PIn1pkPqbork8BPt2CsLVXW2F
ui7627fA1qiVhAg/PCulELvzd4FPdnHrvspIzV0LfHCkkBRPh663UlkgcqdZWNvVsT8fK/6vusf0
gzYotqAqK7MG1NDbuDAm9nYQsbU8XUSm2jJ8wOn1+g0wBIYaUMaXjG1zE2/DkOgh317G9C5h/LbQ
o8JXFmNLg6x+AdeaGvky2507FsEhioqIyqkQcNjcHNhxiE+2vs+xTRv/OVWPWezF7hLCGx1AoXh1
VxU0cv96jVlVKSAnXSEHbB622EX3iiyTXuAlZDgOIaveqkttEisd08Wf02KswkewsW4Txkdru714
lr/70z8xI+Uba4DwPiFFwZB22fFr8lK8D5bgX24sNpVAiIvN6Ggaewt5wAB53IcYqEACEHm3MnLm
jvS/7vTqxkACAFcXE9VZsTF4Ii1Xp5y1SCUGxMwM3I/P0HO491rEa2CmGPthuTE+Vt1taR3oEOJM
Lw38CABk