<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrgb7RrGYEQoBHQ8dhbP7uFcRkk0VRh5aTcBQyYYGjl9H1TxNgMUnQvE3L5Hdl2/Z62BAe0D
0bVs9b5m9qDqRGUIJ+/KLIjmdV1JekjIIRSvJOf4PCJeQnBNkVRypfxVXkMpC17IsVbtnx/D5cKS
9/HANNUas4H9nK/ISLYAx694c4xJfeuUwuqB1PcgOKQ7E1vd2xK+eicngGS9GRRZwlCKEkQhhe8i
mOHXDVtT9V/TXFCu2olLZubKkvHGGe5CPZWUwgjUyIcPfSzLb84c+UIdvvAnRAwSjWrUof6Fbw9B
VSFd4rSps8B+tAidt9FsCXrgt02KmmATCanoWAwZyeH3z2mwP8csoAJyuTa0p+kfc68PTxv5tx8E
lsh/mTWboRSoZVEH+PW9y8QXdM67H/dBCZsppCOLO89uXeUJcIKW4o78/cgOJvQe1/Wx8mobyUti
s9K+3YX8yjEczh4geEg51oA6CO2sPZlXMAu/n4wb77aCHvMKj71m7cGDNndYyFr4pPnXESRAN/Og
U1EMV8H4ljeLPu0JaXqMuU2XcpNU7uNxy0yKnWlL52zAEwHZOANurngkMwC6cTq5ngc0mNZ/1TZZ
O+kj+eFC5P+HVvpqofCHeLUYlkMQPWbHJBD2WU4Sps80sNg4r8jxmYGQmMsl5lZdbRVBmzJSlT+c
6mG20d7mfU84JOgGGCD6CioZEIDiqvbRB73FEIve2tYiRvo0Lg8tZlHMI0TQ/+Xc/Sl6HyYBwKfo
36tV2jqGZ4OxotT9Mw/7EszUjHpx05uXMQDl1kwsT/uOeK6OFJTEYHDWNfHIMi5tJbF/h5qiaWEt
01HryYAlSZ83zY+IXZ4segefhxKRLvxkpkEZHbm+yOtcxj3ZWMgG1b2QVzftgFg5hPq8WXaYYKJQ
ce/MXgPUc/vJEtlxOK8i7I/lQHUqv4Y3waCjHVbNjwJig0r5GFDmIMjlAHj0OR2uhJ9kZkLBqKkv
8jYvj+impdSW0dO56m7Q6tIasBOcqDJW+Qp6K6JQ1ZhWt951wZrvdCXINkt3V2YfQrfEGeAWL10Z
6x5mqqDLVInGoW0cFlKQxIqhkWJDXsp+qOAR38w3HHNkI06ZGodJS9OH5tFeBc4eaJ914mh/h8f2
91UcUmj03n0JNk/KGj07YW3nVflmK4A2SLac9mnVIUVou8ee7IcaB0nXVHSzAXtSHBeIIzqKzFD3
hKQUOxMVjdKlfm5C05RbQmD4aLPvCR0Lx8fsuAlwWPIGhGH7sGFmONagrv6N5mHbIWjMhW2Tnpiu
1nqTr6MSz+psaJF6gt5pG5NkLFFXZFURmRxtIrzfCOqete2i89cFZdau6cS0QsHoQuCgV4dY38py
KY2rudECz8C3J/FeTO4Vc+8txe4EqJdovVPkGXeCTEDb9PtV+PaAGL4Qw23rTkGNivCfBRcVYRbC
qQcIBPJp+uIzi1W7459fVRd3DKXr5IoxB6yZcPeqSIH0UQseR/UHG7/9/RLcWy8hw6ehRPuUAvZl
QIjCU9wA6dPcjQTFOJ2b62XZTPVhQVQhzy8k2uyAwkFKnTGljrjRcVytrXZY6LSks8IB6B8Cz6NM
jSwRIadT9iHCtBynLQ6oSspd4m99YW2EPOoU/Tm8AXnoMZywmnncXHUd+/ERZu7fU9X/lenGbcfQ
6q5PIx8Z9uGsu4umU7xwriZahgG2G0ifNnhYWIaEMttDU/UtuvT/PLYqNR+9ubaKC+IF1l7JsYKw
Jhdo8CystRQDsDUPZaVRr4/Rt16H24sRrB9YBHB+lao65ZQzDytj8YrrNv8dR4gIbcOnNJjGoUIV
VwFXGuUN+HAS35NZ1IrFExJcoEBcXnZ03TFyjocGMakPlYjZ/1bKH7wT3FYFISqD/wGL5zRGcvyv
iOkGLTCifjjWR72YaVuzyG9m4b66VbbhtYYr4uHj90gTUzGan0HQFSEss1C/d/N4UMl3wSDQpqTE
VJ6ZiASJNFs4ZcC7G7wl/gLvfw8IQw18WK8GuQiWZuSuwgeIyWUH5xszVsnzrnWWrN6oSdhUCWea
gbNkFdQj0LGsj+8vzXP2yD8Gj0FbnrWL/8SnstVr97RfHcTVnJFNw0wyZk/kAGK5CIXWrjCu3MQO
uuTgPLv3LCyn/B/onTax0XN1ap3Kr9fuGP+yUFiMk9m5QDc180+GIWEzw+hum2ne9uDTBoFxglSO
iPFvwW3KLY4N/GqhixAKrurrLk9BLfK6sjZCKQE4Qr0f/+55JHLQ1CkDhjTvc1dntDhhz91VPZ5O
Q9ylgaRTOh+9mFQZCRiaKsHPWTtCFdZ91ob2xsbimcHjNDpoosmAWpuOHGHEqIjFTc6QhNl0mQ+g
JgFSYJASiG9cjxNjjz3vKMW=