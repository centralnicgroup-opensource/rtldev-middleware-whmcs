<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxwXIeixZ4+jmXBVg5b6B37R2sN2aPWhshoul/NdDta1px89o+eA6IjkBuIjLgZWQt9BBFfw
VRZD+a/t4uiVuis3Vkly7DtbEkxk2xY1t6Uu1nQZzecltl8S4NWL64xd/57PuCp5jhoZjWhIvIFo
+tEYGmgXFhdFFmL1bgfzgfF5786We5i3g+iTaV1ddqSImsQLVgVOTJIxNWbsNNO8Gdx1kUiHv7o+
92wHIASscgrJZhmRfLmLbMwNIjhFfQDPrl/djCCMKR6bkbsUTGKYa1SzDiXiKgAbVlcVI8Fu4XXJ
sATB3XMB6c8vTfYV5MZqS4QtYpWby4A37K0b3FGDHtk2V3Wo5LkGpXa2xjAUO+MXLQxbqccl2/IL
r6auFu/iWA09YhZzQ4b7QNIORXuUvyVjhq9afPvEa31EEzE9EA08+q2jeomsOavbYllM/2fs0XGe
VhXOnNoTdGIYha7GsJ4e7eRHJ78V1xIHuv47tUtDn86fE6iURG8+ZBHm76duReGUlVabK4a9tREg
/eEMvVzPjZ32z26+ib2HWBULQ2F7y0RfUmvxLplH0wWX2zL88iXU7yQmyqR2ezul+UjYNk/h0A6t
gMtN/U2tctSughEuzVTRNAPQ6QUEGr413sXKa/n6v/W6zX2MamL+6xISSzd9HZcRXxnM2MjsGTGp
GOI93XYpBfYYszo58VXFrbKOcRPOhs3GBSFscipi4s6shvH39ej388pCHPnU5+BL4g0zSZP5viQt
EEeX9f2zWDu9iqp8a+rZ0JSzIMWmAqiV5QYozvaCab0snzANOMs8asQcox8pfbg0rqqF4BglxsCt
Ys+3oG2xrCHSPKqHdg1aa5LYAXMQCs8KthzImh8AjY0uQF9ym/GVBEjy/gycUdh2wOcgX+2VrHva
tMPV9u8V2JqQdltTILUhJJ0WpdnmSYLFuw3V7b+lZvCxRZbsfY0tN5/zewVFZBB6Xtdwe75aNwtz
VOylNNA8HmhXluFw1ZXvwi7nc6nlpfl5s3wpXfoyWaRwDRnhpxbNv1RCIMtSFTbgHX4W3MO43EUx
AdgXFKOsP9adj4zO08QE8r1+GdxBRMp+/KZ8JoyWv5kJRDBGA+5PPJAjx4aXfbowJsZXKg7S63dt
eQgda77AA5IaDxAIkHkgnsMo86KYfYkBNMBr85EzKLrC2YPfdaPq7uCdMdGtft0sGps0ADwOIaKU
2+eAyAzMJqQqnWdjKrbkXcNgN2pUuiM5PJd5JdDm8Gs+A/1nvmUuwqPfUwYvhTeIxS7jA3JymK4f
RED68h+tzWsl3kvRD8P5/B0LQVPfULYWcPwA0OGQ5/34i3irpWIIFKprLldbJfhp3FzpZf399jVK
pl/H0DXxj9Pf8PTxgHnemPoKy7hitQoAWnGhwcUEEV3ouKwnv6vJhuNkCcKqJ8+nhCB70abqquc4
23TmlsWkA1fFpumGIYN2OrZv+sQNh04PKVyMCeoK7L4+RcW66phuBiepqSwik/oWEOH9xsGT6TIs
9SLYYfa+Q9qnvVPUZyh/aDbVXv32clfE+SVLHmkALu2tCTC8d4I9QpLlpksNcxIKyThOngTpHLa2
yjyEfW4zi+Zo7GFcT+zjmap3pCLl0NokNE6+i0Zhofv96vMoNf3LJFKKQQK4cpHpy+X8UqrXiOvs
0GGUyt0ZR4y9Qj0R0JiP3FxI70Gz/mluJ/VEOAtZYOM/k4p8mxKUTFX+pmkqQuS96gNYFZdlukBW
Rnc068FTliwAuzpiUrBiSFWAEeLS7mjiKUiWXKKd20RRSM3yv4bWJYgGAxXsDOOC8877O8jiMJgZ
NcaWw7DLE8SedgxR4oDo39lHX+rdjLRBw+9qAKbCZm44eWdTyy9hfH/K9Kv4sv5pA2ZYTfrcHCM9
oyhKYghxm5hABZBIKMNlE68xqAJoly3OORe2k/sq9mEQ64wAie2aZEVFhD8f9Utvc2UwWz6d5ZGC
bTeCwBiHOOEvAqXN4MxkyHa+wKRr+BocvgiLaRo90QRjZi58PBcdzfJ1GgPB72BfSrgAQK2c9hBc
3dLzqoJb6OaeG1qtpl6PGhNPV2m6jUvX2DXSjIASj010hAjRUlCvJHh/mstOdXcrYsy5Ey1dr6x7
gFZO/j+tNSswJsRq+U7YnuNHQqiMZidh/xalI8D1Jx54Eur/h/Vv4x99HKQg4g4E3R0eEM8bDS5D
Grss1uLPEeoANmUYl4xbm0e5ciXW6+Q1tpAQ2d8w5fhLufYHstUHHAuuB6V1EI6xQu3S8aBfR5Un
Q96Ponl9ziYLW/EELImgUKCP7f+JyWtsfjdufBEfR3YdOWtUWlkQqZCJGle/jon6a8YZZxLhSD2l
znqjpW2wKW3m7G==