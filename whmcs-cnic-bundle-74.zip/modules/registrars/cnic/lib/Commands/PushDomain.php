<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz+pRT/mdLOHZG7u/1NwjX6OWwhK25PLHOMut/Og4juja77g/h0e4100kXfDsWI9/yuOerVZ
vtZTkHsCnFHOtmUKw5KpH/LFxdI0vC7+VTrhEOAwWeUwcjU9DMNljty9lVxIRRxJLYCL0moQNXsC
18aqLTMX79TdZKd5R/yYjqPTJr1uy7aQQn+8tVRy16iPGnOLM9IKAY+CMSKEYTKa0yzARwqXZ5Ro
iORmTXq9OFoGTPi1xB8bCv9bWeXet96YbsbVgrxnAPcbprMKWIRvvAVdagPgzgG2JxYbC81Kg4kD
eEX4/papmJUzgFKHUg8GxkY/DvrH4c7vvXZj16oZSnX9PGMlNlf6LyGEHtSjImskeu72Iibp1NIH
7RtTSZtBZhQO+eMwXtnXYgfJukvaFiwU3MhAoS/6Lnt1BqY8PLS4gIJhAn/Z9l9ZazaO3LxK5mlw
ei/ke1vtWe20gfKxEOcuZkpKypSK+3VIolYPtwPOGfLQh5ZcoN475Oz2wjk2KWj3jyU8oEqY5cOz
m9nI+Gi11amXT+HB6cZKjmVNA6fqAh6SVpzOFNTFUyF4K18nndVtMdK3eU1CsHnqkdLoyZcLwN8F
OS/meko3JNu9EK77KqIR0YFJmNjNiotpePYDV8Kc/18+kCPSIoFitlQkJz704rVSI9RneGn3KUQJ
bGsCSni+gp5mhkCRLeiM4jl88lBq+5YrBEwS/mOWt3MYMbITd9UIhoIBP5UeX5gQA6C57DNh10Fy
T8gk3mqe74+U4Tmwtd9f8NWgaLErthFDMfaswj1idRpIWi8JukXqqFJmAUfZevYHX27AYfTLM8Qy
boD7lFddT3dghED0ZAE7Ux8IhOKsWElZ8RwKV+z9eta1VEDXu8QXq/r8yH4Fxn2VO50EX7lxu6aL
RrZnhIKPrH4768InEJIZrBEoKQS/3VARev0UAKaLq3aUpB6uRN1BIWaEN9SjKuVCJzU8sNf8nCZK
O7weQqdirr/xOEuXePOqwLsxjSfb2yI1TVMtQVcYSZt5hxpi/NExgqyobtaZKfhqIz3+7LMRTF8X
wrLimQzTJBJFW/aHLDJtieaS035WWpYd8f8Qy+Jj1HrdPad5eq8KE8OYpjdx/jxnfFUpcnDdQfEE
v3KQ8IansT37/rzM5HIt5vqQpSVP0SPbRrjo1bsUhVJN4mSQXUAF9U9vVxgDsbyLJqr5VQ7/d0Jx
Q3NWQzRaTiJVcCSYx2H7bQZSH96ziAQ9V69Gcy656PwO/ULetuCT4FjJyd7dn8TcKyb5OoNFdgQF
PM6JunW5oiZocPX7VBH1if0iiLneWEeS434AvLxqDc8SVU9hhe5VMV8z0RoTiKAM38H1FNEul711
ZEv6X/rcPooX/9Ujcmb2yQegb/rPjhiVOgpq7z5axZELJnroWd3iM0vgJeXOkQ9PZJya/WcI6onb
UoUghJFnf+DlX+e+aA+PEX/UgLNJlGjKCpdYkZM1NXypKsK/8TkFXyUG8HcATBCDWIcDBT3bOGiq
4NekXYgtxf+KNNlhrpAmjp+CyiDJN8eVhP+ZWaDv0bG1cGz9O/1sIF+Zlwk+7XUE7hntXaln8zT9
MpwzN9ZyZi3+GSV/TsKeY8w6zIuszukG1DHCmUP0E0IbN8PdJkVJnattDX7BeNNIv43QrCM36XNS
3IsenPtkGK7CxczMWrvZP3qj71jYzYdO0hZ2g8ackct2RgmcYzxYNWfWt0QNEo0uMf9jBWNSSPEL
aXz0n59jft69HaDhSMS8ZmIDZPq0GLCmpw5vhE+zaqAn1MW4cELBuL9vYUO+lXDCAEoDi2W/PJiz
up4WJDb3uXanly5ywNEzRWhimDXRnA1qaqxYrsbl1fFsL/Pz7kX439gC5vf7Fo65hV10OuL0x6PI
B6621w1IkkxFwZugwfwVxQdH/renm/GztQZIc4Db12ZBjxRYaOOjTLc2Cz6I7vEpM1nT/alh8T85
c31CPLcJiMRUUYuKkD9suX0=