<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmjz/tq5ZyB3AbRFQYQfyTyNYstjSVvxflOkR9NkXXwTq/YiDqtGg1qkBfvMeAhy+f85f/B7
uEWzTIQp+2FXiYydu3hiE2pxjiqhovTAH1YmYErxHKUzDtBxmfFFlCueYOSMDd+b6bRn8X/+exB6
jk9EoUN+z+KDg8V8N8cSPNLgKYpy6vzFlXqvWee3AChvKUEepi5Js9eM7BsuZ9bifnrDkwPv6Y/B
reZCAXZ07wUVtGEAuGRM6NcrlYZhvSwMrgtPygtijCCMKR6bkbsUTGKYa1SzDbjo6cRP7fSn2ZT6
KnXZ8gTa/v0Khzjp4OtpX6debq/XxX6IbYe3jvVtBR7fZv30Y3x5M+H/1934BsTyMKk9bNOiQlNx
Yd7FRGMDyR6ymZhXyz+HYh35c6Ov88coYeqIrdMhMWC9wrP05IcFOSR5ebFzCLVwLOHKdBAW6kLj
jfr4JLdqlGARTJwsLweD+QSX+NfRQ8501jO4R5tseSFrEGycxcr9yMFtBdyEOIOqO693Q0kGebxN
zkeKCtJrHL1SYJqKStFfZ/J0siwjfDS2SGiYbcptSs+VSpxSrfj+8SdtkD89ENEN2Xl2969cYMJU
w2MpkgILjPg+ufWZcfrsldjIlKB2I17ZezUOXNzW7QRt8X4LLH/mNf43+FdQtVxEzrBRC0U3UdiN
aTahwHoS3/2MSma8QTZcycb8selbY50Wy6sQrBLMfSGHTSyrfspCqQ55VCQN4RWQ6WYw07aVlHon
vZHXgWcgdpHFXmvmTx5JyqFIgcTKn0JMj2t5um+pDvPcWgS60txQIVnlrl8o7VXhIDMx/Z/iPZId
gYT6bdHe03RFiTDSlX3TCdHp5Okkf1wdX9xNT2+kaZrETWzJ1/7iV+8X2vqRfVIx5bCmfqEfcx7V
oQfYv91doJ5FritFdy5TLUye9x6CiiyOuRQwRjo2XxmGhu6ryLmXQgAvIYeKPqva9LKO1GtECtfn
p2HqsgRyflHAAVzImuN9+eI8/Q+JL+Hb9iD5ObJcNANZutW9FvHUnJIj+ndFkkMuByZqNC/Ntbls
tRJQQNcf3y1Mp1FBWei3F/pKp6kYEb6cUV1ePOF9G/qZWN+UKkbnYgVANIWqXD5iiawMlVBBQLc9
IFjhNHhkQ+ZYX5sMmerI2+8TH3aOWvOvDKattUK478x/jaLDoRebK31FHIxe0OUuGtW1f2mwV3Ok
5fdvFZrLIwy83+I8ySyjEWQfMus1kbH+IVN+7XKTqyHkCxmgRXtVUl6elK1dyTdpQ4GvKpaK/oof
8aDIbUnsq3ltuCYgv6DzP50wB1u/kxXEklHiFGbikzxBfZ8Zg2vt/quuYPYZraBPDEQ2CBIlQeOC
dawe6mWUem+Vh01JTTNGt0ovjlYdbiHwsxHRsLmYCkt93e1ijh6uQ5mTBLS+5QjpC96LU7gIhtK0
XXqbXw3smKMEooLx4muZDYkdrs6xNbSY9mYiNwTUz6VJUg0NAoFuUKDq9yktQjbHN2JbqI/1u5X2
Bcj3TXJTB+Y5VTF8PO2eAuFRi+X4zDGWhqHRXf1DMXnnwJIpA2uszGJAKV4NWjBunI/+OnEIWB7e
aUBcUgX0KnRiyWkrtImK+2E4oXczWrDAQBfHgH0wbizRovZkCaKrxUI7++F+iX1GjX3mq99Ro6db
4ky7pOdgJhzHzn+2aY+D2tO+lr96VKOmB76E+oHjkGnS7Y8VfeVpXuFXKXEO88dyKC8rHvwGK+DI
97aUkoH4eedV87tuy0LkJIQn4tNUItbYjZOsW9tKnpx6aF+QzSoGGK9qhfZkkO7Mz3yh7dPyp+Ip
SAeE4XOOrkiafwvyAcDtBOg0eIOH231ZEdrjUPyC4LL2d7ZoE8NVDk84AGGcgFSJl+SWXOK/9hdT
7XYVmWTyk+M3lvbdDCk9RPzx3Zgoidt1FljXCeiCHZ6ClytMfSrwAJdvo3lJMjOZKba4aNJVNCNo
CNc0lJjne5G=