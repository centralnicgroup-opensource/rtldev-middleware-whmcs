<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmArZnd65NHUdtaQEcLKNY3MDh3dxto8f8YuqxwkLjas43B4HaOM6iO9NA8QYd+C6VL9QMN8
C7AmYLaUcZT3H6WGWLR9bxtVaVBFRUxaj7H1RYeng71vg0zN/zH96qzjV2Ozy2BxNhS1dI8pvCF8
z5fUvchYSzguK8tRXlwTq3sECXAItw3a80W2K/PPIgSl+xmPuzpcrsV2hOFwVhOgo19RxhgJ3sAp
ha+NGLQH4+t0HquaxK3SwdWkRCARIlZutrc3grxnAPcbprMKWIRvvAVdaWnipZ3bHOPo29r8Yqjz
qMW1/m4Z8h5eGxzwOhZp1GcBJcw6bKIhTxeSY6Wg0Vx1zJTcFJVXxr6ulfm5MeeT2lPGSW5AlqkL
dUKF26jKlm1BQXE2CZB7+0TgRmW4yVe+yQQVDfA+rxm0Uk5Cn7wbAstspOCscZWj9+NnlNrKYYP5
DHn3FXJFEAncHyhOyDKUw2HIrgXfyqq5XjqJtVvyZ+36zi2uDn6ebYLUamOtXcX4vJSRMQuhf3X3
fOSE8tTPo8605fMDUx5ak6a/3UCkVk+T0s/P6l9cB0JjoALdG8TfkwJ7m1Di7dGCDrHUjbZ/72Bl
j88ttwqGW73IMmdsCzrP8S/kcqldIdZmyzX7P09OjNL2UKxLM/W8NUw4385DGa6Nf7QcfKk+58RX
z4W2HBrD/N0SuCBMtwWBbBRNHkHsH3N5NsJOUErbgSGrbxzCpwwpveOXbTnjc0dgEMlQoMzCSmE9
uwmI9YnDGArj5CJUn18ajlYeLT9zj7jpGd7Y/tHTs3rBNC2Yg1b3SM5skXLE4ioA6HQQrnHgREow
RfD8RipVZD8dscPEpgbyccB8RS0rEFNDOQQDIEVx9Xbh+bEaXH5PlgectVWb5RF32QO4I62VveCZ
UGZfm1sx5NBWBjSTX8HtI7+N05mQhspYGy5jZIqj8/9QkC1yokb4RdSu6+qGdV3lNkJ/1AMiPiqz
MTZRZ0rTqakE6oN2bHK0/r4TtX3F1Bv1g7Uy6Co4o+9USFJVa8GdTPWJQtQLWcu6czy5UzZXzluu
2NT3uLlwldIZ+TXuQc3xQBwc5qcCQ0wpA5pQR9UazeyxNA+NvmqdlFeJ+MQ6NiFGD/PHmsdOc8x7
/JOqjlVJQFmzj0oUK4fnG+4QUWYjXQIwWPy4MUqCYYj0ZEMBJ3UPTlRC8VP/KHR4ofMmd9s0faFc
TyYQGuL505samDltTAHt/HHmOdD4YY6hSpwKOyhdi8hcwOwZ7Og0yaKJwjQiPiu9+zKsJhSXT+bi
OxFszOScWy+KPpcFMvmJUnVw4uO5rNCgvDnI6Nb6ARsUdUbumF139wVtUYy0/phi7WwcuGrMLyAb
wRaj5sXMPFE6TlqcCU/qR6+ZeRN4UjjCikOvrpeD6NK+21a1f9RJ8am4zuHiRgiuYaRxTxfK7Q+C
+UEPfIJpNK900/8dBOKEsOsaJpFb1p3S5snAsQdQ4tqBTY6CC5HDJvX/GKkqVCvttsbwal59q3ym
vjFao3y1XnKfdPNFEYY+NBTxOF1/EEqlWJf505CJ9b9UH57E8wvM8lPVbqBHg4gBD92VbpB/mcyd
077UJ45h8l+Km+zInadxk9D3BerJUg3+V0fjyPFFXJb/Yg0o4tJzliADs7KWFi0TYHzAXHfIj6yY
mmt6zxJ+nMKA76IKdPvvemp/s0RztwkuJ4lbRQy0ArpmpdLR6hw1syRtcRNA/DAYhbnmKwVRcEiU
B4raUq8JYucXpjGFf1GHIBmuOVvxEkYgIHMK8RNmJsFNsVrZTkGL58y++0pR8SFwPv5QDKMqYfZB
oYMwIi7YG1f6SpTBvVaQMjF/Av5elqdP3nfB0ulxj/BjQyZOrtLqacTDDn2q/4IpdzpS4rxry8li
eTfgUH34AE6vNVkNjmp0g05E5m3ObPAksgNKJSSFFIsICZ64pQMa68gnklOPfnHPYgQpdoIlRyBI
0ek5OYbOkipReFG+Xt1+Yj4b9zBqzBXLlADs55pCFyCGtf8LaATJaNAotTgxQVzVNZO4CSsclI5c
JxThNguKrylFbegRv9WaGYuOyW4r73TllJ6SNgEPc5OsCovXuZ6lmhF1BoKx1TOCs7JCohqF8amP
7o8VVJb8IgDz/xG8nNk7ZlidOVh63+xTi3qVsORyYHuhGmi7mt2CdBG7Vdad7UVGmEaMgXijLJJf
6aTGRIPxB82VdzlFalqTEP3y4uI2Z8D6bwRPm+0FzBx+ho37U/3C8ngSHUSHHaHga4FC6RhBoxpp
zVlMWeWqLZik6f9bFfABR4VneKZX+dtttz/uXUVWe1VuwBUugswZVM2iBlvs4pSa5ZCUMm1TCRNg
BQxUUWssPWor4ZvWevcMMZXrRei0nzCuZ2lGVFK6UGCAhI/82ZV0U/0IQ87t+ERQPu87LeM0CIk+
bii+3AbswptJEJP93G37zHdiCkU/7ciZc3ELlycgzSXjB7s6fd+S60Yp8W7n/m0Tx+oPXAqjMAHT
hNdw7B/mIYoHNTJOn4RhbNif8K22J9ZXL0ZBBqbf3C3SAkFp508wkiEd3jPJ45nodtdvtgeqKIGD
