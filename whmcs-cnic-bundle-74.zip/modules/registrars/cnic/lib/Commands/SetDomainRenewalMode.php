<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwEBFJ4cMuO6FqUe4bZMWd9Uy3K4IuUydUoD4LUMiuc3DLJFow3rrGd8wny1KsCROl2GV/Gs
Zz3CcHLVH4o0kIZ9Rk5sW5lc1EiXQRf6pxP6R7w+vgZBQr/kJFhCW5T8Dg1W5FDX5ptWctSDHfoe
x3FeU02QQUPHvWdmM6elg8fzCoNLlNrHvGpI+W3X5c4l6ZaS6jzsCg3gg/GoSBWY0D1XorX64CAG
fIfS/q8xHwqDQ0UMjcNsHolmvNMrwx1dHibWGxJ35b6nfRfTddK58f0NFJPHPM4/Rrjp/KFPtFaO
mzceD//QKVVNu1Mv45vWWtkbbTu/7L5h4BQfhQdXqwd5wyv5aKFv2KvL3N3t52AcmlhhnDsetR5E
Up0cqGAZ/ua/qoAha0NDjxGdTJlzbHR3TcBMSmh9NuxTL8TrLaE9Rh1g0kxROn9Fp//pIZWB+r0/
rDT00nOiYJJAu+0p98JVfUB3K9dQLTU56MN3I3ieXQ7fC8QVWyHbOmVaN2bexPExpzQ1Bzb7bQZd
wzasGIP/6b7zMrocIw42YR36i4uG1DeYDnkhA8S+anQguOJrncqJQS3NZPHeg/tuzG/jIRlC1aSJ
UhwbXB4j4AP0XXm1JwuFe3RXjRV3dFlusjxdI/zqCxX/1nxJg3dvJGIVy1pLkfvImspTk/pBnvku
z8wX0GueJ3BCrY5kO2LxjDufFsM8O6w51iicB8izluEMbQIfR30kxh+hnydHbkD3uSP1M3+fPSHF
+27cI51tUtEDH3YckL19AgfBc8Jw36OSHIuz+qOJWC8NNh9/Ntg/izneI7uKNNcMFyMIWj0KMPU3
R1iOM7NQjrsDwcUtdBn+fBtHCeGDb9HgEn38aSaJ8QFez3Num+uRj9mB9mWLmP2k+kioNNPM5nE6
Ar5FIGrFeCKfs6IQDT8MwwufK8zlCHVLwM3qiEpbdAS68QPntkvTgFnBf0EaiGRFLjy6Wn9KkB41
eWnDUPoomVQ3k7Dv80LFsJfz4/OcHpLlTvhRuarHk7ROXEEREzg8Givr0RCpPk+xxXypEEnRpnQu
u2Fiw27QMY7uhURkb+WBVnQAiJjHsXcTowhWMYM2T80wi7/UVeON/bNkVqcYoS6UYohoCRKKEBIU
RZ0BZYIFRgRLEmBTYoXyPqpG5vCi5eMfh+wqSzTDlk3l4phOtSiWobGsq0zh9MTCbxZNqer9k9+Z
ma7cTTKAiikS7s6Xg9p9NbFq7off6M9JnI8jsGwAAt2d29TbE/yZ8wWs9+xfkOMnjiSrOkbvW355
xqjxCHelunKchU4dDOrHdojOIT+trIKtl5UjKPbmJVTEEBldZmUDqwMJ5HJb5/RmucinRQ6xQgYN
HxdeSqETFfNYMkh/NiOO8CcW4KAl7YnkQagJ/mPreQ+hatOt2CaT0wIXoGTzr5G3UHfPVw0l7vIS
oT1zvMbf4Man/GT4WbKET+94L4pFYXGUjPzDE6B+RyV9Q+qhhoJ/dvJhHraDzYpQxTw7fK0i7nX/
3Uup8+FJYX0FrzZr9MnzRtm0K9F8U/cofkpMsoqL0gUXbqsYBDjr42YHPdguvUq1DcRfWFDkIkGi
KhIQdr2lH4X5PWcGSNYHmtMtXG8Ns9IxMFiiRoyqoM9qX6jJgufK8u5QQbPqephGQ/VoAs44C0Di
bRDgo/xZkegndsJHjshxvvfh/qByE34Hn5SMNTz247iK5eZQ58UhGUiNzKyodFoumuJGsHB9RK0q
wgraGRHlgdWskPqEjqNyUzWnUNcat+AXgk+EkY9/e14xGqKKIyn7Y3/l+C48sj6d8AEFllqxn7j/
UVv14H7y0hK//Knm7cLOlVBFs6Kc5zWrMrCA6GbPJUFr2u5K03es034pEEIQHyi4is1DXkNJMbnZ
Y4YZgCgilP7c4Ix75FE/x71lIIN7ffVL2e1TIijcxnOS50EAHf4o6heIbBzRLIfAK93m+F0HjOf3
qbhU+ONBlnkI8kwSBCvT8DM+3aLQjbdyk/KeMpbahs1yJvMRd7XnJIW6d9hod4N/2isygaFdveW+
b6fTiEpnxGexxK8/oZLvonbMbjBFNvPKqyLcj1RJveSqZ55dILNno193mZ3UM/g3C4poXbjIH3k5
3d5glsYe7B2NGtoymoiimDEmscn1tzugrxLexT+scKgw6woAy4DGO9HvwZ65K7pMajTWVgrGvl7m
TVcumEGV2l3IhXJlkTL6MYtH51UYHB4C/uPzNhdwh87aCU6fzYWd2dm1rijtAqiqC5+a6lP+rvBi
aIvv6jOP/E2gsgEoRYlNP33ldQgg9p8QGg7b1RWvwDRfe1IOn4S5gJ2I24hIj8rdtdQlPzs1Go/8
ozwWnmiKV0usWIz3lM3g/AiAG2xY8xsNBkhWNnfq6DSPZS8rMvdrFLX4vG2GXvv/nGgMWM67QbWb
VpAmb3zVliMCWE9KNo7PsYZoxE9y7nwCszEd2Vlhl9DHYcJdy9exrbysgYjVN4smC5f7HScnSl/r
xeirkPy2PR94wLzq2bcefgG3zLa3xDQ1PEgKZ/ezKWSC8Bid8Xe1gTKVln+TXXuJB7rvjDrJIOa=