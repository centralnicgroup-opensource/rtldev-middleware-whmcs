<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxad6zDol/ynv0lZZl1RQtPapNFg66cY2/qfjIyjVwCXxWdGs5epCqvwCtXRVBRRBfJAgFJr
Ti68ceRYX0XVk3eo+YwgZcF36pVCjMhoAuhWGdbVtldpAFRJGFw7c7WIDxJCWCnwMF94fV46w71L
bPyu6WDNnqDnIcXzJ5K8s6XM5arAXJ9LWHtChu1L2bP3KTBS5dwrjOAmL2PNvtArxfj5arNi8Ppq
bDLBs/mSiCzyfd76c1scHJ/dU1xcoIpPKdvBBAjUyIcPfSzLb84c+UIdvvAARAcQdEKRjPd99RDB
3G789vJEJAmxrrerhewXn8Qe6Zlq1PhIborNuGkhdWzb7M3zFmlwISvtPyryGT9CSH1xxDcn244a
jtyrbKMzCQ5EmgTfSaSuARGGnlXm7erA3RhVr6b27zpTBL3ijGsyDGDbgkIt9HuDZCNJjtmsZBTw
y43LYXG3To0f1OT4mwKpbLqgr8p5yzvXFZL05pUTZIXSHm2Kg8qKXmCBQatlSWMj5thOFTGlwYx2
fGduhhq7DkqdqTB0x1P2iDks+oyvfZMiD0FA5QpsAE+YAmYZZu87T9osbUFws1kCgZ5A/SbbKR9y
XZ7bY6CBRx4T8CXBXHbDfsyaOtI5ueL9R1VX0zCRR/jUU0Khcl80afyY2TESBSVyWhpupG8VoPrl
TOJriK+vi27gc1yU797jsmUr7ybCh4hir6ao7f9lU+N+pMCPrnwMsIEFSVPAB6NjeFmCXMk0bAjt
wU9PyrWNVikGrPKuoHG5ZTsJv4sCRvnNYZ7zBq68tMgKK9HMdFid6xYExdBlLu+aPuv6HPArJbjL
wvip0rv8crimHkuXHlnFQMc8bvsBLMba7gvaj9mDa5oMOf7E7yILVa2p+oJfycWp7ymVhJhIYDH/
38qCLMm/ZaDiGaBtbewWmsFrB0jGNZTAq6V4wNRawoAlfdt9MSht7aimGZyK8kmkI8/iwAW5cXo7
Jw0sXmOLEInoD7x/+/8VzhiH20Os4voKHGTBseVlwGnYwUHoTpJgZnKiz96mCuwvp+PMWAhELKW2
Qt877c1W+ZzCtE3eQC/3L5+fGCM1SGwlFUYmo0EuARPKm6diShMbicrBoOFwv3QNaTBDTzZmKKzN
Q4pf/aMZjnboJijLut+zIIGC6mhpDEKiJ+rMCyHgR0SgOhOTGzCACOa/N8htai49oroqsVIv74eR
bntKGK3AOkWtfpK8VO/Y0w7zRp1HTugArpcypJc7hRJhsiD8IKvcJiMrXW1gmyX/RT1tbrZTIpT7
p/NSa8whnYr6b46hwnDWVw0U/8e78AhHe3G1cnnbj382gNpJoG27HN9/QuBDkv8niRUI7ggzgXPa
6/8POl9qeVE8+mO/YvQCETg448iS7dnH9RsUJSsrWX3dTxWSPFBn9ggx/dwfPtQB1Wxm05e++eOY
yKS30fs1+JfQoBs0P/RP5XciCMDwKOpEd1SBfYBZ7xBRMtjC/UPPaaQ5D1fOOwMPtWjjzhyi4x9K
Z1jPdgvmQMMIQvKVvWNt9ZkQ/inJYp6D4LbjrEsHecIWv/bWN85679Ui0IpZ6wH/d+9q/g7yjxiB
v/DKuoOEB17BsQoDeMCAg5wnYPg1PpCaNECcUmcaSx2B+IpEX3vl3w8LM4G4MrkrKHJkvf4Xg8RR
ZD12nZbwPg3JOxpCaC1zeJL2HAa9vOLXSbhjKzjJwhOc2uBbIco2okvqa9f0L8maNQWNT1IVqVMJ
gJ6dzhvCBVuJAbm5bbCm23s1Ta9D6A/so5xektXjWizi9d7xFVzA9RNLQgkvBOj43PHSHlMPSry4
32TEpeaKJMqDpDHhfdzvZDHSBsenkxMINRsfZQLNIdiPeyXdZb2K/ye3sMi6qidFaTvZTTYuacWg
GLz2ef7Vt3vudAGc6+tn1A5WiF3P2RGdO0GnnQb3WMRcEzSbQd8jn8OC6qV2fTtGjqgnNPjvdAIC
HHu0IdRy+BA4vwTESycqe6GkKSo3S7NtVKtGLMoUsV3SIr+1Y/8Y+OOwUeN0nHCNbsmJZFm/qigO
+JHsE2LIIhJWMD3fX9J3DOjyHpyMWh2XA8ZMDi5LfZ1awtx1KLbLQvftq1teiXrj407n1Pk4AZ7Q
+MtolY08OQvsRkkcEU0jM12Ni0YXfh1JIdb8bVBJy358vAYDmCbG8LLvigBQEFXMDRakqgkBi/3h
zYkGJhDqQ9Ja5uZMqMKR12fR8WZFUFHS7ihItMyKwHqfKvzmh9/Dk5P7rKTj9VgUVdwIfMsH0Qj6
dIYSgR731szNTrLxvMApwlI5MVo4kDIIYHvKgXzLjGETRPNJQOCKTb5hno9lJ9hohRtsIyq4ToKm
olU7AlMUW2X3k8gQKK4cnC8SuK7aK2siKoMvgnH+vzh3S/+7aZFAqpZITmDiozO8cdVaR7uqWe8X
Xt3yn5JiYyWFWSuNLx57Xz7hsLnYJEwe+GikQvX+SbvXmkJ7czZ+MG5XLsR4pUUh+auosintgAX/
YiurBruZqvQ97mYyMRd6ChQN6rw4rSh8xhRfV8dLIvvkht8h/IMzR6aU2qZdFhh1TPRy0I0JDubs
tG04Zfj9VNPre/E84c28mJIOJcLXkjSJNG6mL9Xg5nXoWK0QX64BqbQBrVFd0nQnIaflwouA9njS
Ty3xOWm1Lsqx3U0Oqs3rKejQWwGZl28qFognj8Hcx5PQ/e4E4Gl8FsImmFQ2MUTUS7dx9wHeDENy
+plw6u0O3i+S3ooDr08L+4rrPHBqc9Tv88VmsJMRDQucOYkoQ/s3XP6UfjIcyq8iNCWoymCCYgqP
cO4YpufxhMMer02cN/ltm05S85yWZhKxeSxk8+mouOiiVa2n5zK14NR/u6vQC2mYQ3ivovbbTbBv
sF2sh85lZq4qsbDpC/doFnfcYu/oWyO/Se349sqiaWcWQL68i8g9YrpomSzdmJOQ5IQY11NXD+LX
by9zk4O0kPS7xVg5qRKkrnSSRu3SnM4l6naJC3h9SCK6boFzHsDBIMyPTe6RxCmel7DNhm47QPDe
6gOaGTrQ9mPjZkoJeC/w6HjgcU9oxgYxhyYftJxWdySlV9Z79O9nUmN/g5aM4RX7SEV01emsRB0n
7IjsvRPM1AbQzUl8nndMlE2L9nWv7ByPcKHBp3lhqVaEYufscDZBRlanO/E+87uz2KaZ3PjZsmrR
q0QiytMzKkgh9CeB/JDMlkYrJkM2IDQsoWFj0j7t9vrGaIduRUrDqmZFxmepWzUn0og0T2bYMkI5
ZPKTSCcrKlgpDJ8j4W0uKgD2TILqm1DRGXlmo1W0E21r7aazzmwo8DCYrL6VUoEau/UP8sJdXpf1
CsZ08CCDCL8WYVUokCd6tfXYP3abViAfoodUAmv72Bd9Tan5C1axo3frfQaGc08N2TVfltdiD8QE
R39WSpUsOXaw6bRbG8qEi3rTYDzdocvxwvyPbRCJ4N+4SYf63i+fGqMpE+ullDavXCyOCRYSyxWH
oLbQ/rXsfRF4Rc0MWIjzoptF5jzLoVHNGc7OZBPM09WTuIBBtf1q0xnMeE/ckZur0ZS0wJb0Mir/
ceibVBaMzVIk2ebdrYabi39h0pJPml2LgCrDvqh9czGWq/LHK4tCHs607tnnCn+fMI6Mdhpd/63x
kXs5N5LTK+Ih/X1pmkXWruxjczxQwKPbBz1+ahwlkyys2UbVgO1d/EQbxiAYDrSQPzcyNRn+YnAF
GALKfFdJ737Dc7qp5WNPGnn7K5mzjzLFh/+3e00TUt7dlvtEdfQEXv/LD8rm/um2orytMeZaTE6S
roNg0MMPLTHIP4z8latG+ytq54lgYjZLVnrRCJhN3uHRxQ6qBUO2/FiFcLS+AYIgB5tVq5hy2ApB
rEv9qajg+Im1Ttdy8N3s64pcm/gKwEHg0ZDvaN54MDv1B7ZYsT6TwHkW7/I0YQqDPHu/M8y0tOjK
Rmc61dyUuqQcekt2rocr2KFu8OYmBvCTC7hozOlABo2EaXuNLhZJjLEJdkCLS+20qgJG0ExsHgFf
Rugfb/tRA48UzrAPhQ2AbxEKdfS9sdi4u+pnW4kbdvRTDjJbCHn++2npUSA4gj5CGzEA/2/Lgu3X
7avUUvyhsFEGYGdybb3PioKsl8i4xDekBa8+Va9t32ILI4fnejcnO2MJunJVCk9fUOE6vPsMfhzz
16VBTXRnfa241SGoDyrQXNizo79+HLu6FiazNa6BPerWrv2OwFRaTrZK83fQ7Av4OA1kKh7TwL78
aLdzdOnUtyGVzZ2ip0YO4odmXnXn+N/QobN4d8CRJEE+2liBUL5igrY3lSTppNXpj6UAuIv1KttD
ljkwN2m6eG31X2LD/PnXuqTvIdZYtrAMhxUdlb1/00iGF/JQtKcl1qJ1g23x4YbQsm0/CesezCuB
LTZYmfoGZqxqG4MlYRjxCuPAQcPhgHovvwPTxaP7tcsYsRly3PFlDxpaUCOhVXO7JHNqLrbnylu6
6yP/gW7fd88oqTpdzWIDe0ldouOm1tdHNopnLABrO/fnlSk3SwJsNsrjmMF/2/mCMNNkSd+BT7d6
UAvgk0Xsfr/H8jnJMLfhaXBO2eirZZFKtQ5tu1XEH/QUwnVGJpv69euvrBGJPZg31VRqYSp2SS/s
YlSlIh/uuAg631SfL0YMgMqFqmPVJ7CbpBC9jsmAXBgcWgybgbfT5y7tDLt4XJxpcsYuTJPuhMcY
3flj+EtEJB/Ykea4MUmPnf3n4VGofWCoAG6jNv45hfl6JgxVSNdIOuCtUvUXX/S7Adpz6VsGDGIH
c1YRk7IaX6Ed5jmYZA0Vy9RykGEEYwS50KK//y6IXgBxUybBEu0pOKin/zky5gGvjbUXKwajcY6l
KR7ujuMaJPUB3zpMM1nvkqwM3Lf/O3jSbGiJYLpMo1u4t1vSh7gfDwyHH4XwhR8tLK9yz/hpHn9V
WvwLNEnJpQ9fFngrAeS285zGSTy60HZc+gpZYX7eTRKSb/O05RQarCeDtzt96sw5SLBJp006CMpE
IiJk+XjnawAhebHtiIeXptHU6GhRXZLNWuRuC68r6Rip5tVTJU2HuJ0u7SWJAagAJKjm2DW3UxD9
HfUGtBip9Obr00kppBn8N+ePbbbctIcjMhgFQB4Zx7bs/BfTm0sH4zGKOFv+HtA1rR5/TIXyHr8O
pprLadoHJYkFVC6O09VwjNS5j0r+9hshak1JQzz9yl4FcjDp4v5GhAaONhQsjiOEXmWdsCGGGAzT
k5jsLoyDHoFpMeIuAlGbB7DD5czuoEhezjlgR+zSXj6tox8RgW48vScm9WjEMu+VHY6A4tdVRD2g
EP4MBdEFGnLg3/ioDoO/aT/1E8n9a+bG1wnpXTxkyIUp753daG==