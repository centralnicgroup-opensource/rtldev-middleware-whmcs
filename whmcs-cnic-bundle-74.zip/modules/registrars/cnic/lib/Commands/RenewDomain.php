<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPphGaRaJTsg+wXi4cYL/bzNilQZtYxs68lW+v5RMzTgGCfJnxRiglOFibqm2EibOejMrcRU0
bdOCcQqNBbOIb0CS7zPCwebLYlWTEoiZOr9bxaow2Pl1A2o6UUDdfAcDVveOcDYuguBFK2ALLutY
36N1uTHCvBRq7ko/w5kwLzSYMvFsKxw8m1T36wm9L7/hAUajdyN0H0oXTdWOB3AEl68T8LRdGvdt
EN1BBNuFDOI0M4UgUe4znGjectjLrsnAK8/KRBJ35b6nfRfTddK58f0NFJQNPpZqEj6Sxi1GYneO
0wz76Ld1kaidWp5KIlkp3XId1VkiyZPwjAOztiDbmHjyBGgTrTIn0NLb35VIVzH4F/YFaiumJvhA
R48KJIsk7mtXjdBjJglXhJysd19MWxUZmuU8RM/1VMTdH6pHJ9adCmJnBK5NazSce9Gq+yVp3LOI
Z0Lizwkxku0Hu3Rebf2r2eDRiEi7viZToToViBuiVUFbLk3LxvHtXTNSd/ZDWrbOgbfNoB2UdN3r
uzn1+2qTyl6DrGwFTYfBLtbUGo9YYST/ZqZm8dJ8f9q7q9al91+JnABvgNsh0fNFQNDcSHM+VXwp
TuFUKEnnrrJ87y7feylrkrMr/wHspwkgE1EbBiu43NuXiP6bIkjW/y3WYLs0GI6Ce55w81U9ktuZ
5Zfcz0e0hF/WIH4BQ+b2zo9iaeseuqTbLKkUnae5VsfSP0fs5/nb+eOQuEyOYwYy22jt/v5QqTlc
jnfUcM+QttXAg/O6PWcJxlgu/ux0r5Bzt/ds+kKx8zZi0La3XOPZAMVLUtnjrW/mE0Kp4lYkw2MB
6BWtoF8Vp9PCpmv+wqBAWOmU8950CTLJQgZl4wjwFskxdXoGHIvR9Yw+nEgnLueR8opBOn57DAj5
0kBYpM/Qac0Ph14pQ1ZaNkFiJ+1EfHtW1vV0YsxqWHOXYrYuIBkOm78SCCNOLtr+uAzIecxS6ATc
X+ZYgdU0JsC2/1B/yl2jQuu7+M4uykw1UJew4loNtsEKEHiFlFn3p7KgfcxzBRf4edYWTFnKAhOP
Se66D+bmEg8LkExss1CDxiLS+jb0I04vweNLhvEzbN0jnGCc926af6XkqacSOxyT/ZLg21U20xnB
JOLEZ9yDt5U6vi2YWwdRuaf5bVQM3jNyRBjLtS31MVfrSt77nAr93dzxmqg9ZC//Ya2+KKt007lI
q6ahfz16cdhCYQXLFnpOLxtFWE2qfbgqd3b5bzsA3M4VeAs6Tx2wAmoN2a5ewVycXCKb310uQrBw
zVFCfjrbHlgI/uwf49RSKSYFFVK2AZ85+sI5aWX90Ig1snItaikqJKt4eFvT7gwLVp3tT1yZuklG
8X30vS0q2bmDHIqDLYYMd0OF0PfQnVQnmmVBPJyqGxYse9EsHDx8r1B6Zbw0H8OgXbBo6kOe4Z9x
+XRDQutXUWcJU5i/Mixure+QK2v+LMHl94Wzk8QIcKdj7XG3p2VQcB5GLh+t/3yHyFuGWSCZwK3l
5HdSoiO+8WrUETcOSk7mJ73XqKLI0GRwMDvVm4wflloYjgSZTCv5WfY26Lr42/rTKF+ylCzEWGgZ
40c56PbRQBTkFzoIxWblG+8Z5ZhBKZ4ukc8UZGe6sjhVZeOoABZCBZsBZ0RXdg6MZnJSnkDSOxV3
K4cunf1z2jEPgnKi3+6wnc1azvK4D2YiMPBjHpHfai8h7gy63OnJ9HbxiD4EXG2hZB6PNqQ6fbCu
jzH38sIeADoXJdci5Ws0IqU4E4ZA5gbH83y8TWiqAI6GXSJ0m+pQf6JFf9EnkhMURwudvBMuMvHN
vzkL679hZlmF4RmDaTS7H2EIdWVJy7wEbVI5wnaO/wPmR0QgcD5uG5XBu7DiUPcijjLZ6UsuBNru
b5Rmc9hSbazOyjtzi3RAQ3fZPt8JOlDTmEORPLVFN2z0h+zw2ZNVcHKYecKv93X3xXibiMK3G6aX
x6iJttHzgZV64Nmt/k3n1Z47pssS6Jg32PWpzfcuyNNJmho50L6m7HmuuCnHZmE+4zTDEod/i2pd
r9Z42jtqSX0gjBcNsmSkPXNvDwwaoqAeUz0EnbenENkyAnFE+pvKGg1zM2bi3VKnRoNF6oc0vecx
VxWCG28Zovd5Il5jSxCTD1el6JUR6JWUPMm8ZE2g61dqS/+uBET57Qh9oAKWk3U3Ru6rcX3nSpvS
E9FbIaFPU8XYgJAcKuY5Tv1G0aVICSVsiUOh2JtnSTrUM+rdIZbmtGd9lmx8Y+2zVSphN/ldQCsA
WA+5FmbjoNPh8+8uTLxopn4ZtmEJ0TVqDrkrl6EQuLUxiC16Y82DAf4FBjA+xOyIjEc2QlI5DNsD
yStcjhlVgNkqlcCci+bd5OWWjdtnIUd5QuxD9NtTZNfMpoQur/6S5ajI+aZgII6k/Bfn2YepTJSU
g4gN7vEhTG7J6mzh7LJyqyI5uIYnd2Ciq4pyQjVXX+AVi3q+0PWYAZccWFaDoQYszv1aM/zwgu0h
TeoABPj+dRfabediSSXvjp98FIueqBYatg9LmbUN47PIZ/abcVEuw8ODwOZtAF4JKOzCuyNzYzeS
2E6VOWz8jmq4dFHtP/WkssTs0In+DDDRMaSBOp+etEQ9OaRdp5BK00TueSdxaFg3Fp1Iih9XoHX6
hAu4cB90kcCWfP8SzPC6WtFS7oOT/nvNMDm+opwCaBuGvX4outA9CYMGSrRox1INqPnew6cGyy+i
qcyAalr7I3lKmYe3uwY6Gg1zROsEG9prHu3jLMKpUUfprH0Mf2C6WQ3uzI1N5FAw765q6dil4Aup
J//N3m+Cj2OZIeoATMT7pFYY/E9FHqqQBcMSVZ8VKEZ6phNqyWh+ejFnBMcVKxSCtia4kwFCAo3P
/4xWW1+ukKxQV1ZLh1BQezKHYCruyqtqNSgMR13vTKyxfNoEYeLw8uij3z0gtI0B8sVVSSn/AP3n
ePnNH9Upa8zqS0eNZ/c4tMSscYfZI8Q4v4rzbFQoMudd1MaTQ1r2m/5tkTcXuQKfPeIRv91RQ36O
LFoK6xYkG0t3EN+2ZlA2VitPDgn+LX2jzgwK/FubLwSRU1GPJax/R6/SGi425Gn9lA3wKvB4uzmY
TQvvNRm9MCFH9Ixz371jLgd4k7vlYAZ3QzC0KpAvAFHF5eHkm+VBmDpFn4eHiayOvbrOmcM8e3A3
hYmkemdI3VmcMaWGVTSimjHwlB2J9QaJkktbNy+w4AiXhS4ooikewjA0erhFqZZTnYFJ66Swobwq
2qrmEV8HfE7FpKKS/0+CQLC7I/bxIaBlNPfptOka7hjUUHv8aEFFYtkl0jbkcGgjVuyPJLfE6i3N
n7TkygMjiRSYCcLIdiKqc1S3ThNbewTO2zcp5H3OlOxi+tUXQg7QitWE0qmS7qIZmnogsGUZvUTs
OgNkNPLDjkeYPWXH8DUrZGWVS8PeMYAQIMg8xbKsJarWCFXC11p0fsKGQZLKHy0fOYcB8Wv0CISM
ckC0CPmR1OfxVgbMRPUm+SAqywrTWmENLFI5OEVg6Xr6+ymn91TKhUhbJ/FJ9Hpe3QQbKis0YYC3
MtjRWyDpdHdYbf8m9XzFYd2Kk8JeEvicH7MGZapkz8naZhZ2UrKn3+szGUbkm/V37epinCJDHtJd
iuT+iui6km3qEvZnvMnGIuAQdExGNBdeZrxv9tCeVXTokZNCpU2C1KXEM22yvYIEFmHi2RiJtSyz
u9zmcLm9y+UVheB3aHKYUhn9oUT7cXecYTJnPyMwMfvgckrmUadk6T/wnJ/ND6yxHWmp/osqt9bV
CzfojN8j++/38y3j9a5NGZcpOFSq804/M6HocGQXdN6yDM/JJ7cYGH7Isa8oWf3xXFXoa8qd7eqY
iuR9TXVCw5yvchugkM+6YvaQDytFynwHyNFEB+dA8f5OtEtdu1s+k4j8Wb6gJsCaFwQpCkr1iACF
ycsEHI7Px1gSXMrBBe1xoest8nz6eJUPy++M1GxmrWwY8bikJMlApHETq6zQI4Dc1WoEC5FCc+Kj
VWGf/aguDye5qWc3tTDXc92E/WPaDFhU8Nn9K2IrCnLibAZyKeZVrzBe136hxj8AoNwn5fc2ZUoQ
tCMmGDyP6PECAJidLqMD2QveSQPuw2Z/EOxhhw4M0Jz9Y6HScTT1NKG7UCrBVBj25ysMbXqiVjj4
U2s+lNE7JFBHkooY80hkmvRsf8lgYPt+0Jk7ssxqCpHnUDiKJk2texKD+QyF+JiXSqHAju3oFnIH
kGLNAxiMG2Q1WR3BRW3rALwDlTx0aKjpv5Be7Ou/k8phdPckasJJLDq9EyD75cRZgyEBjsAlo/Nv
aRFBllQ9cURmhPuCN5n0TLnkeZgBTLceIOJxeHwwVRGk4gnHw5crKau0o/sUvtrwPRJg+ZOxE8fn
CSYYqY2pggB2kfaJuVnvidMtCc/inEYTac6EXBUveYtjYBlbHqA4kaCDbvBWfSFb9Rh30a+G3WzW
otRpgp3AQY/2AC5PmkNsLMbY0ShaY9meAWVFn+whDFcxmWRGHAHVCnTGmoaXUuXC9hNFRYM/hwyg
hNGYTHn8qEuWWgDjNDAqO/SbWjHthvlmYaEQyPbWHmldcHi+p8eGBCzvUxMPzwyR5W+z+51ZQAWR
J50MeCik4Md0d3zSPyzOAjMan45P9RQ6LNpe55yAcdqNVtWsw/H3w3DggcApouuOS17gigG+7STd
UxCzAYytoyHpio3p2cIXpqpFM124wJryXDoMwsR4tX3glbgSixFGtr9jSdcEQ9JNlXy6Hh/gE38F
T+PiE1S7uKwwG0bWhL9mh3CYBf0L/r6uuHvPDLe52+nCe9OX7cQAGxeSUWENbExEI7X94YvGyCkw
jLpvvh5EXMfS51QQlY/MDCJoCTsa5jIJh2wqx6q=