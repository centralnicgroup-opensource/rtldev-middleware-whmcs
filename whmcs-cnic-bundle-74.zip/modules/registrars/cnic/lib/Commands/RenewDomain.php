<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyH1idHt10Tx3eedL/M33bV1mZGqLkkfb+18qAmh69mTJE/mqHErsYhbBorjmBnb2irE18Jf
SoF+Abq2x1gDNcxNBlUS431vlhP2R6Nntyh1x2wVc2w74IVAJvI8h6PQ/RSIrrNsLrd8rPYWE1Kd
HGC2T6CBHI4qahvY8JA3deBPBti53w6EYjywhtDnMIptJeKwjQg6Irk8VKonJ5awNNMffJO5qXMe
llL72+8lbpONd6aMIHWbkPGobncU+WdJeAhyroghNl4fcQNFLPI19ldaf+UI7sGb8h7dU5/Mlnn1
IsrxY2p/8UO5dd4N0rdtRQIbYeomvjULMN5sTl7RdilVLWxX0MqLvVPSmVngGjqM8Z/HLX34nfCS
ONJQFPQEMtUBT7Kbv4sYYFXjsowi3UpxH5azDlRj5jeKQcMwGf2jxDhCZdw55IVcOtoYcdMKWVUh
9TVIXduRSP6M4mRdjhzUHoFnn7TQtG+ezc55Q47okf9KJUcmRps9VT5b1Dvs0GMLCpjPszLAC0lr
Lb4MS0oFHrANl156pj4s/gbZkeoi/G7CMUyA7XZrVPBL0cgIkhBMFjn8JNilg/5It/azTqpWipKM
MKIP4ysLsVpl42Jgd3guxtlvr08NhprY9krMVeFcMtEi8//PbzJT+VclzbhrSJDrkmkBKBX+JdMp
RIq6Ef0P3N0EQ7TkJRnggMPXn5975G+XhqpIhD1sgFfPnnwTxjaCkFnaWIbrt3+J06lV/DAcyCgK
QZ1JvkVY+dZmNW1hd0SJ/fNoKAVG6jlCb0OrKvhQA5gPxtRHaqsQjD6QCN9g45zJVtWG8pSFs9oi
Lx1k04A8YsSCgJt+Gda38G0OaN5kWnBjRjdVvH0wP6ALUNy3ISLKEvKnMokBOtB54xAAnhjLqQaa
0Bp2syLb7krRoVziVmJM0+LblNJEsHNAewl8jkEb8sODc0KWLpZXmnE+TxL2t6AZMVPL7uEEAxKh
QA1txrGi/vLX1Bv4ughFvFmIRcOXSZTshseMyrWv7pFNVE02PfGsCMyrbfP+JhfQ6BZtB9qi68cv
takogiXjj62CT/UameCrNBOEcmdLtoW6Tmb0tW0PfW8pZUGo5w26SHb5Zbjo9iEOIYJv7TJVLT3w
txwH1vOPknvLMwr3cuTGM2kVi8Vt3bcMpzt1UED0m+b7OjBv+hJAK+ix2SnfaRjr+L7k8vHO+FN3
KjrNK/0a9Szm6Sjxml624dKfxrbO7tHxfodcm65SjZEEHzviLqiKEmQnosVswAeul8ySfIrA18hP
cqoBItMuLwRT2wwelEjqx6+4Fq2YKBWM3ArJdp+1/bn60GClHaNjVnrDFYaScTtkP0RKpjHgYjdy
Qi7hB9vvQbU1I1/P1y46l0I4KZJBy5+05Yw3oalFl221PolB4drcXQq4txGj8LBre0Zg7RE1NvjE
elz0QZkwYCxM+uV3Yg4FtNPUKATaBkWT6tj26y+0OMEJSmehwXdrgfdqdjZhph+aCgv4LBgTFP/K
0T2JjWva9T94lb0tW0uMocEkIE/QwwCvXQ7TaQUbvRKc2bGi8QaTfSYwsp/oVkvSApBGastIkZSt
vax6wSA9FjzDLIgoqd3mv4fDPZ0Oun7UHUocvE3Y9KUDop3YSIxggeIp+o0Dy6KS+6s773w866LP
s/KvkaOUVzkOSO6Zb7rI3aqsl52CLdkJH9MNByZRT3w5b9KHW6SHcdpDjpg/0gMMbG0zAQ5D2xzK
w8dfrJAL9GHGN6EwmihZKqqglFiVekWFFlvJodxJh1061cDwdqYzAXL1BfSAW64IahM7b3US3BhF
vaMsneMaKaFrMqfruTs+CyESln19iZj5TSgHMYT49QIFzGYiELqTzqFLthMKtcuZediNIIXd6qS5
e6mwp9ivjUZTwzBZczknktLRlrRkbniM1ozYqFhUXjNEL2Zu5HNpw0Y7aYiu+VUpAnf8HB6cqdeH
yTXQzZgSuutQEhc2F/7LRxa2CsQgQfr/B9LgxuKJMeSHDuOSGG/eQUfx4S97L4PgjX9/cjmBfCxY
7+hQsGXy7LjbDU5zMJdxUGiwNKZ5PMTQ4SxGji3cFgZ5WVe2xcAupNu5M0oPOACY1ptwapEa4pXi
/lkxPJa00DiCytyNgigg68SUJQe6hGcn9STszDio7RJ59zBfgSp49BkKI9lVzT6aQ/WmCPhPQxY6
udiMs8IDTxlO0rxwL2oPoht5ASq4daP6mr0jB6GwNMwM1/BKKDluhmnRGHMNUsmwQiQCmgTad99W
Caja9s9FSNdibO1Vt6S0Ielq3g2uQapcyYDr7z263uNh2lTJtJDfR1oYH5MPerNYRL+N2xUVIOt9
SvfPx3VeZR9FTwbevBSreV5gZdz+ThciFQNpKC8nITKCKXNv386KEnXQbxGLPZ2KVxR4WRf+l+rQ
fTHyzaLxR0niTDsk2R/UNhTOEPYIDe1B8ADNW1kJR1sAnkHNm9Muoc++oN+gZaY0xSEM+yOJgLhn
IGvtPge27c0UoukDx3xod7LRwZWOH6lyI4U33TTnGWZydoiFBU9A+PeWC9nuaGBMqfSAqNCk9U1F
pSntgvi13bUFwAwMBW0sSRpBTHgxGk83IuzGBrB9KxSl/K0P2xc2f+5LuwVlun+046VxUn+wYUUW
1Gt+Vcz5u89XxcOZ97zxKiqSAA9v9OIE8TEJCkXX7az9LAqic67VHyAtI0kzx+oSXKf5YYLjVL4b
+bjVFlhEPod2pLkWnL7ePY+UTH2p5z0GYcHlenzN9Lx5Rk8uLAb1Ebf1IQI3V4Jryw7zd0W/ZhTJ
LUpkN1cPqXo4Vpc6b+NNVAaAoEhJSmAT8neC8S0JfrR0RLx1q56Eck8wDtGksNcmfiexpQw2wJCk
Ize8YS1E9b3nJ7DIPuyl6h1MMz5ILj23WKQzmnYzFocosZWl7Cn44mgQl7XePaGalhXXrN1eBZhv
hlPWo5FpcQxMyNJY+bRFLZ38iEIZEPIlWztT1DUYGS5nHTha5FFsTwW7cJxlOLsD0QwqKYYdGSF0
LorVVrhrMq84Almn9re5MlUhgIY55xqNHOCGYjMCcburc7CC/zZe2mnzEFaG+qNcGhi4Q1/ojyAw
ojGz1yu4K1MyVCmn1c6VrJtL0uDV1Fcbc4TQXHMc6LifCVVKGul8xy9QSLGHfPsI2yzJXEZJLpJL
HxyfAjete3P6SXXngSBF+fcld1m2oWs+sgAhZLGk8P5pWgLFLn6U83WV6y5YDjnXeUvcjhDnQbL5
OTzP/BEfc8kLagCiDzgesjTewvoFgmxHu7hZI3e6sL5/FWT9wKr4shM6b4c+XgIWJN7mGQoDfG8k
Q8vsmSnRKSzMsa0+WazMGWtzpbU8J5WGVPoR7U3Gu+oEh4nzymBpgz5mjrRYRouNyPVfB+NOh0sc
0Q1pRdZ5aYd/fbdk1+3iALIUIIrzdT3yHePpFqXuxk7AGsyYWUhvCQbVpXin070iIViPIjherlK/
jhifBEz9XwmaY6PUcBQ1yBcAQXm3//qY5B2BvnphcjiQo9HhMuWDvts6NcezNoIQHaWgKFmu5Zir
RU5olc1IxN4J+O9xS2MKJ71/MRgNg3+EbQD/nT/qDZ7EuTkgdOSaVpG8KPwZH0f+PTH1tMlROzc7
cafQK2k6XIudQoPXqSu+JHTIkECsq+FnmRMNpZgkfKjXGDdavNgEPaMuVnG7WkSq2z2vLaR7M63g
l0Y3J1+1IxEowbAPI/nbFHZAraJA9MOM0Nl2Xb33ZQPDjirNPNBuNd9wY4mJIGv+C+qtjNhSi3SC
x2WLwF0feNihnH48aDgL1j8s4UoLUfIAw3Q9+F+I95C2fhaGf9kSE6ZmNvOiz8ef6ffSE9xrwBtl
ME+qYOp2JqTUN0pKZieWdKxWiVqlu76ixNvC/qlzX8OZlqtRMLo5BYMCLRcUtlDRHxgiJPUdsAjU
IoFesha7BrOfZC1Asw2CN6ozVg/6TpgJDTAvHzlHJwUo1y88MzfNXarPwX74hrz96FfytefGL5lK
qrfsFHsppOyodKF/yDpN0Q72gB3StQZQ3Uwa2QT5D+yelgIvr58S85PEhsrc+OWrIu+basG2T9Eo
KPqcfH3ppJ9QIP4KS4U7J7tf8XP3BOR+VQq52LsgPorObAKaSh6+xktSYWov564iTiM7bu9zA++7
mC/9pi2ICyBZvWWxbgrTFu7FgL2KuMfszUNkSL55rHFw58o/lJtO5rXSY0xG1O/h3TMQAO9bpTtl
dHnbllIo9kQCNvoKZ3ibo/B+D3Ip1ZXabWbsyZ+JyQfCQYFlPchYm5/gvi2ydodP9rLxnviDR6Wf
qfKJX+td3rdvpTTp1kRSYYIqy2vsRTTNfEN4nP07Ec0kItAWG/Yg7ODlgDcT3xr8OUEXuj0mAhz3
jHJgjy5iK9al6wveAK67u8weoflXJ5Zf6+se6EHqOZQgG9zawK4siB+LpDX/b7gv2l6sAheHpL67
Ci9xSAL5xWygN4tiXMJAIzgt7a82seHcEgxVWc3UmdfBDihe730J145CYFCkAiP2FqB3YrqfysrB
uz09wX8CcvUKtDJDM42EL9Q5LX/zPLT0sO9gjgQ+xY70hbNUjutoyq9iXOPkzKpZreEm5nrbbPAS
OGgf6hVy62AwrUIRV3dy2oykG6kbfA57H1R92bUBYVV+1YzHfe+q5KQcIeg56JTMhCjgQD+id/Dj
ABLnmR6Q3615sY3YabFfDi+tyT6F8U6J+RNZNomPQRqZuAbUOecgPiu4yvq3bd4IR5Xr4AOTBQgq
w0oJ83tAwl7dZh01HQ4M0l06lKJdFa0NGCroLkDHaXuzKPmmQnWxAnAoAfYMy+8Bg0i/TmCK0ja7
rfQakN5pKSVeJX0QFRvZFg163Ys2UC44kcjGP+oFhJgpgpC=