<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqQXg1msZ15Jpn8zF/wYL0MHxr5yopF6owAuFIZV3HUsiX4J7qMQ/gWfR+8Kb1Fuh3EfVL+i
6Ldum5oiABXRKtWrgZHSppsyJ1eLhCzdgEif4n6libcZp+kCIcZ/8k6OFdbriaiApNRfO4Rc/04S
DUsfOKQ2jM5WHORti+SClOexT6MvfWbxbFSI0GSZ0yfP/sTKKSrQhgM/L6BBoMMprnP53kfrcFn0
a8AFIUNRqVTdsCv80ssXflOW9PzgD/mIjIURjCCMKR6bkbsUTGKYa1SzDXPb3Xl+x/BRZ21NA1Xp
aITva3hqrnnZ+eubYrPMac2F+bgdK+ILcRDb72jI1lL7prOPbGttpYcE0i8tcCw5yovKDIZMbDyl
fT+zuE/3aVAExTYNIfAlui/5NfNaCQ4DbME+xBNHVHSpPl4l7SnWvPOH0WrhqdkhgUFVeWufn1cP
SNoWg01F24Axfow9N8aj9OxPwy/Xj/EODG0M6cUHdkcmu9dJKMuO+2eRCuuUVNnK47mgjU885Sb6
uEyWjaDgG91insHsXujvchAcT2B0kVg9Bom31kWtY0b4Z3YgywDVwxZ4vFJzh5nRH1/rHilNA0NY
efrc4M8tMPBiKqv4ymRwhgbywiw0YaVAqHjcX+JzjBX3VZTP7BfjbmTWTl2/Wn+GaULx7fQsapwI
Lz2UDsyBnuRIzouzTe75IwtBeNGYTAuivOO/nnNKBtcxCkOIQ84gRH7W3jZifS+c4QxQgJwJmRm8
V1B1dMAJ0i/+b5ENUIkbOPis8Hd7UUL9HkbcKzUwCeaARbr8x3XwYy7yr6GlE9A8mJsSqB5MUFD1
QZuN6mKrNYTBd+3ywvui3rZ9SG805nUWV9ZbLYpyTVNeLFuWhlqH6ouJR5NeZ8l+Krv0Qs77QFMR
4OdRgptiJoFVrmzZ3fA0Kb4zBJa1uaBOHZkqi954HTISMmYvvL58750+6ypSqyAlI2kC1nrGqih7
HLbIOZ7Bow/zIsDwpVaPpVOGSGUKC1ObafFRAxQdW6YeTR4PvDMRrH024fYpjRz3rl2lCtxra+aR
X6WOLZImrqrkX+LY7OOjNcMVdePbwWwNfVKFlwYnOplaVeATswnq1mlTQ/UHkf0DSuSptaoBE58O
meNvOlNDzGyv5SFpByOgebIKakEMtgdKaZzLWZG3JT5ul6b4rNXqWEmeFKEip9+uutgeMdZfvNFo
iHNydNVWuaFqJwxtU4YWvZeTo6u00FVFIlFaXZLDKB76Az0nWpRoeZ3mvHVps6eRG3LgtLOZWp+U
8J8DLOI1tuFJo6IMeamcJBS7hh0oqQIP8lQowNw2s4U9fsS0R7TpqFGO2aKl/ut23hzjWrJw7ADe
gTHlrSUhMwrLsMH0wXyjbNjTRbwI2k+IuwfoSqaE6sOENRWfp5ErsXhVFfFhrGq3MpSiZvoE0B80
ANsw/1ahbBxp+UrcJ0Qd3LPxlouVIRPPeCwip/lYeTzzsuf19JBbiZ/71l9U7XpClutMgNomV14b
MzYD8PBUkwT9WU10sFlfmbZUaG96bP+oJaPhpzQbsH2hGJNibOWq8JLw6W37k1+JY/7Fo+EXvNkS
KScTEO7Jk79JxKd6t0NAeD1b28r98m7zI7wjh7WowxAtA+DlVVSnf6AvKR8xU85eTe8rmXf8g6He
bFBoh1UYAWY9mI2uXsa1vtj8aiom2Lb5qSW4aOFFNiDlA32PkIAfr524/omoCGNQ8E3p0A1ZFuz0
Nbxb7gjcacD0qH9zuljBCwsUMw/FlWztlbSMy3Xxuz9AcqDPjdQvoYzYRSxQLAhv1K2qhcKOkeKg
c1HGm/yZZXfxboF+V569nP57r0Y+P5emUlb3BFHOUIEdbG0laXF4ieSbNztpa4NHYOxFgVQzm1VV
UWzWtI5p/Cke1re8wVbcdGnX22h+KlCv+16Kx52AyWZFv50JzK0jWRLjlcwC2roWkbX4KOAWeT7w
TDffMYzje16GArvhAoMiGcBl4ZS/QvTFpF+n93h3RLARYg0pelRGm5rMxFCVPFh+VoJpDhKqJbrc
e2bnKn+hEz5lN0nxa12br6bYEUp+94RDB+cg8PwVMXjzzrumRlWRVLaU82Mfg3/K9bLwOpRgIhGp
Yhth97gL8gjRXc5Fo0rlivY0cHvl2XDz3gj1/gEbqToBZJFds/5mfVi4ojYYfKrOrUp5eel34CFk
SUTnA6IGPWv8C7eaT5t7ZIbF2EItJKE5lvWPTBHcStujxzrDONV7lx/+1vkwejyLKm==