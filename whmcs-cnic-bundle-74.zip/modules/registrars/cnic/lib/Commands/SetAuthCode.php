<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvob921LY9qN81Qn0yuORgKKIWu0mD5OvjaLJVbZou9XHCSLVESCe9L1aYflO2n9cwBFagw8
UMBMU4zZN6URmdoMjMoozd5LdVorZZuAvnQQKUC7y2TQ3LYxCMoGArvhyEAwQ/J1r64aafbK791J
M6550Ma1+553EXoD+YR6H46e9mQhY0cOAHctXuOiFtljsLMRYWFsobND748TRTVoh+eAaEeVyZje
sQocXiW2DuZw0NGUWOm9y6po0XZ8HdV49E7MCAjUyIcPfSzLb84c+UIdvvB/5MIYMrI2TMx3Tf5B
lIH8KHA7gM/89JVbVsp8kHDTpPyjh9MHWHf2+Ifyp+k/1CAndyMqSOot6bnzTGQYVIW+SVnTbIsf
2VuuQPEMJ3uvCWn5j1i6BWcgxoea7RYU/LDrnvhvA44ac5aFch52gRyuk8/PK/I5U/kzGasshXGJ
1s/UBWLWy5u+dhvR0Hbm5edXCa0wW7GEqeYz6jnGfoV0wu0WtFb7XiVnNaORKOYOfSQDcQPC3iF1
tWBNsRGALIcskJ0KzA/u1AP2vjeFKlwSTcp8MjNb/hHpkCAVjkzo6IHvuoPJcsG6/SAbk+MmFR2c
b5TeSvWvYSdMZQURCJP9XByAsKdJnuXbu0EZezdPbv0kPG4UBbi51va9ekUyrYk5jLDQSzdquEFX
dcBXuioRPIsPERXLyVtinQiniB7ufSMrhY0i6uBWrl+mHU9CVrkH+jrCw6doYJaHj6GkNvzYcSOE
OUJhVicaPtbsI1+U5e7jDAUs36FM4h7HYj/napP7dA0zz8VPI/zWOp6UjRbZ5bkBiawQFbRuXm5S
tTOAjf0Ku4Xapny/P2l9drZUvNl/H7qxJH6aRQ0x0WnIatnEzX0BOCwnUJw9Y/lHwhMdPu82w1Do
kwaLZ04/l44AY3P/ga2I+3ktgSW/PwbPfMY9x8v7K/hYTzvzlnPXjoKvpepGynCmGoOisV+TtfC4
CbudvA8bIXYHMJUhp+X3eXb8HipJ/HyPq/8k8U6amsrqkm2VwnvwPwCW7wZfIE6oQdXXsNI/3h35
ifR8GoC0XeAVsXBqb0R3VfZf3TOoABGYGeSrV0dcHimgcTSrMLwjZI3VyNVPog27tMIUPtXi3l99
AOPue13RKYqIc1F5x/WGSYNs7ScTFI9VwMnXvPoXr5u9XSnrGs3kArZiTHBDSUl+wi0lK0X5zNDF
6o2TZ0jvMQev5V25bPHE1V1ollLoZcSkL6bmrLE48V2/Huwlpxm/HcsbG1AxFLsBZVmEsl8V4JeE
dcteMc/cLDuZ0u04SwE0poCm4w9BqsUqM8o6gkukxV5GC7XYxLVj3rpaoSe6mI1AU/d3pOxqC06f
5lzfCb3V6RAk6PxNxRco/QPEO/ujPOHHWEaS/9t9K8QofgrrEuMZRleRrHMRjRwneW6tREvnxdY6
7B3QRQjbzKJ1CYlgNBapqOHN6WTgxYSdEGdJnsomG0jLXWaO6AqK3+yeWhi4T1+jXdtk6LexPBZy
vxqSb8J4/t3N3zJ3gcSYq9r/f/entwyiCiDSpJEjnkstAxaQmbYjtZCrMe60nShnD9oAmSPlap9Z
wcmtxivBbxteBx3wnGTDe9aqz/FfmwPnS1PYdMKaEwSFeamWWnxMpXkEb/J4ON8MqAKUNEX5FS3Z
/dS1kqS8YUuR4Ngw4HNhXcIBiUi77HYzWbBls3vf/rNKgER2hIFu4QQy0whiQ4WA5noxi46ZCg37
9XFOO4z15SxqNst/CdenzrZgJTSn9kl59mflovbk32dctLJnGLNPv9sYteFJi+E8fGO0SVA14FYD
7yVQ6KmrIyrSY/flnSBkNVKjfhyZ5/Dx11svP9QhYJL8+L9XFlz7/dEaXlxvKI5iT3Vz3QLkm+vX
4VPKtTTBbynKsUVw/GrbIQJQ0fFKTNvOoxuVlJM2lHtKQti2L/pRcH1bcYj7/SuZnuf2635xp8YN
czWCE5Hx+klVPZ7i3mqXQlfWzEYuWOc/loJ2diyVDnaK+lNWCn0UwVXreTK+T4N6OfZs++mWnqWH
8rz34SrBxI4XHOyrpFfeIFFlvR4dyBNnJfJyqytIIjpJjUxEnxHwryt4nzH7tw83CMsGn52fzqbg
itbyWEd8GVWCrMW3wPyNFby3G0cVm7t9KZhvaVgQb/o5u0o3wTLjk0u6mEeHxj9UpyENkWQTxXYy
05pZHtb6EOAbpoJwiM8m2TANxmaZVmsqxXEj+XZYkhXU5EsMJsi9hYbk+CbfJNBoNpHgTydqKw+u
zArv