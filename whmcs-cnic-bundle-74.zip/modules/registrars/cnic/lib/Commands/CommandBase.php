<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtwkMumQEA2ZusREh/l5tKMKuqEn2cheH+W4KmcQ+vYpCO7og6IR3+U38+WI9/5TX8Y6x9yX
gxBb7xrZIvHDW2vj6w20O6v7cdI48EnPKIl6tlEe4wrEeXXF3eexxvOv93yEQ/XvMfW1vl2FJNxh
kwCgcHBpnL4DZogNHX4XfGlquJe4oLw82+9aTbnlCayurPKujJ6LsmkVrmWHrM16LEho3bJ3Tmp1
yDrJRYIQAlZnrOZ5hhVzWwBVsps/78iNKPRT+QjUyIcPfSzLb84c+UIdvv9YQoYOnLlcd9CR7vrB
RIteVNwb3XuLn+aVEObryfFlGDESx6oLCW4qUWjgbv/xcaVcRdCb7jAS3T5tzWES/jLbDm13lR5L
ePi+4IshbtXsvKRKGFANOk/VYy1uVTRRbkzj8EDET8zSlof49DOSv/Lw3litlIosnPH1hfVLxb0b
vzPUfgoUvGVzlheEVl7hwycTo6k0Ss072FcIr8kiKqrwbUHbyWfS+2ijr4tfQkRQvgfu8CQ+Xse9
sGr00Cm1mNK0lDRLiaKRTJUQ4vRNtuvqTmsZ6OIYL2bkbqQy6OWTcvFYgU8LlvK1QGbjMuX6bN9B
eO8Zec6u5mqKQvSnSILfN1K/0jW1Kuj+oUpW/mpSHBGn+lGmMwPF+5a3YFvb6Itk0FrT5pJy4Iqh
iCQn7vDeRGww8IenDjUXYzEm3IIu+19Lzzo+Vb2ZAaHzkVeO8jRft5V5OdGc80f+9sHnqwQjJCbg
tsCjPuf+j9En5AaQi9gGEJAZ12FUQAzOj9mjdUYkcEZK/19fPikcq2xtX1HWRJD7DQRCLMJuy4eB
Crk95dt5K1UdalLLCexpCcggc4y0UDwBfRNRhzyeohsOfzI+WYAElTvUhN2YJmY/WnR25eqLUSXa
Iz/gH/6hGjUMmY5Ey/nCWr/xo5Ke9cf/ZeEKTPy7eqfXADEje465NQgSN8dDp8ZvuO2dDw/x6jF2
u29pnJ/NTdzyGJ/IFuOdP2FIbm/FrJPwLZzaraMgvQwtb4BgWH8Yja79p3gzzj2c4hYBfBT7e10c
hVQRdwBMaHUtXn4g63Tz1gGuocElw+Lk2cjYvAHlRakYVsP/e1wN/uX35E4bEeQB7BzQo/dq0kU0
FSD2btA1cEH6AJtDvd4lcBpPy2WLsNeH3QTVWHYbAlxACr739UCT6OBLU/GwJbDABKSq6ffZEbQ/
BWx/hWJF09Q8wyENYLX+tXDAAeVf6GSJeKQBsH6sky3ffZ1+w4/N5AtBIjqI0kIRx9Yudvm/B9C+
zLSWfCIcadlBnjOqRQAFD87rxg4vcFaAVKws8D3bu246+n9xipSjbyDfVFzvH7UsG1om3+UfWfhj
s/m1ZLoLwRnXAOp5+bFa2lb6jkLFCQ8HW675ctmzUkwPAj6LU3QAY+3jMnSnnlCgMQENQjaJO/qp
7jZNt8lb71Bhg/X3nu9jSDNkO+apOVUxMNJi7VmM9EQ3oSjXj4N5ijr4q7M951tFiSFPk635C47C
t4vLeZGFL12iAPZKfv9bmznWYf365mFxDLqVdATvGGhxzqv+9OaZjaK/dznGolpmQ+zUuIGz4N+9
nbZy6CbfojV5mogdB5Vs8DomFX8EMt9K0TGgqRLGSOgYgwn4ne/uz6SQDK4oXpXanC1uZ76veqtq
tCWW2MTVxCf3obCxUky8RA2QpXjT/Ok+qooT1i6fczZdjTbriN9jl2h8PXygTDEVm0T19t3HkcG+
pXK2PfUewt3HxIkYfIYkcinW+qt70RK3sYoxnSUZuNaw/ryOetHncvKdSWJXfkz17c31u9gxOheW
PKfujURDjFx77uYk9JWUc2DZ2q+h9CxHAKKdfmTyP6joS6Ua/M0czu6bcHIL3AIMewx6X1IA6o6h
ClXK/CySwzqGDapfFeKSN5d2qwM6rau50eA6gKl5OJ1SRK0t4qnyeTzrsVvotoxYP9oSbO0kVQ6e
skwrhwfNOfQs7pLitRqne8azNu5UHy+rmeNLXctMAeRiukFKHDHqMkl4eZHZVFLiN1IX+JLvzjkk
V5xfqoAfeknmEhQIGN/O3nEN64wxHXrXOlk8FXDLcHItMWGFTly3PceZB3jTRNRSDRsfQHvXDvyB
HpEPZ7TuTV1QzfiflMjSoRvRtIp0SDDEnL5KQ2H/XYYhWCfXVeJTBRi2d9zwZlLcG0MpuGjyS503
FKnh8sEYbKCFywLYms7V+N19oHi7gXMjHdylXtfnOEEdnHdJI436fhsKHarTSSeeWMjDsUPP+/KH
bu6sG0aRJdKAQw3zy3fXSf5lwWoWQUI+SHeJYZU6PeMmMdOgvbHYPq/Pccd9yQeSr/O2NN1y7lyX
QtSwhJIoIOFckaYPJkUMBdD33zrADhEuKVzVXy/H3Bm4QlrIhRrsyX4vCKW8fgUqsPONz6YZCngd
RT56XcHrOKT9yDjhhs4L7pBjqeBBDfiASZPRfMRUfhh50Y4SVFlq/1LUAoYhvhIeL9iNCwXAZp6T
NrCxXdTL7F4cVMLyqayDvOfFKxrkIh+3Vfg78+wJnT/qNAdqpwsl+j008eR8iVKP221W1ABcm5WV
4wg12M5KSRWTTjiEY6lwuR0IesAxkk0Wf41csrVx/vCKSgUmY1DLthcb697E+vYlHM7V67Pzk6gS
aBN58K8hu0FHTvoK2JdB/o91N1HIyj3a2hDbVtmILp9npPiVp6cGSYe1Kb7bDTxa9tS9Pc4VMtno
pH3qkhmRNwX3z4bH9KMSLxPO+gSIzakb8hCqVIHgvETDrJX4NsujmVq2rVNunv5TrBwdpNp6XwM3
AHTEGuODtFQ3mNu5LMM6n9mxMlx4O/npXEd48rKBXJ6V8mfBPZ+q6BeRIerDEVF26FeTZHoVoEEB
8wbeadzZwLDYnSh8qerrbQJBXAMGLwEPxHgeDXcbyhV5bSMPodbppUPYUIBMNsWdumrUZNecYcyS
LwkjuUPJbR7oCcU4GGlYxnWz/c3tOkJwRRL+zAlObe4N2fnS2EqT3mmtgTPdZyMUy0K68c0wzUYU
iWKmE7mnYsmcwrSSKoDy87mb1UgrdAETs4UPm+THw3F/mSl/YbgzTdpjnrgkmnPbzxHzzwJl4y7F
DiJa+pyb7PWulNIFYPOmnHUiPdJIs5gRLN+trYUx3MiW8DXYWI3lXurzxoIYz9puBqxj2U/kikJD
GrjJsaFzAwMxMM96+dcQIsGfYh3Nw1icZAV4s+o0pW211/weaqx5rwlbjnPakp4LvI4Z9Dd4+sYE
n9vGkogzp3wgV34p3wDYfCd2HY5erfzTRIc2Z+646sg5voQ1UUXpIjaQUgZHc1v0L7NVUs0WIKNM
7BA9OIhXF/HUO1FhbJloq8mGv14pEPbvn1ifE74vc+W1IXjcYlNwW+an/6MQorWkNXvHUj/eBN/F
pBieGVyFM9ruAPNpAlU7usZGoQsd1gV6w85bgVFXQA2tjYXe1+PPBOqE4dQ2lfgX32zy2idSMNqc
rZPAsSmJyM66PmCQtreBtCmec/74+nh+74JuA9C0OLeo3HiCn1t8DzWvuAPMUpkcjGqeds5EEGd4
6xquwDVOFNNMLc0WDlLRO54uIsDuBZsgpIfr4OXEtJkpABvxLayhpGiOOa8pWvrcjmy37nVtaHAZ
+jmeex1/O8xxPiCgPjpp4abvii7AHSVmPR3720rYRg/tcKfPa3MqSjCpK0wslUZe0IjWV76Zu1zM
wD+rl9VrlSyMFsbxop38013yyXEq454TG2c8MHHitLawWW76D/6jz2F2e0PUZdesxaoQOuFV+3cv
4qjVgz5hk3PwIjLcjuLsHL0gVnGzZJXdYFNZyFr49WDp26BPyIKznbQl8KnZVf23OobSuOczsr2j
K/YDdVmmb9i+sYD+zL728BpqWqgGYmylNvAjhhPMaeT0lYhnm/kgyP23Lfm71T+RPrsrvrRPrW==