<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyM82vbNKl3UBa2UkYi6vAlX0f9W1IYtUFTT8q0rSOSFdtV0V8xT0Y6WEkT+zQ7vh+cEoHvy
TUouFlQnyYU0cVAZb+nKzL0q45vYO6ddcFTHbiOiSTjSc2Xx8UhSGDQm8Fpye7eXpTRHb2ZiRprI
SSb7RYmuObaOdLh6DAK2Z1FKOAXGNCVeZZ0ALfrUciWsxvanQrEcO/CzFqwmeDwDmfpud/LWaCeI
wkdkkQn/MlGCO/s53hl1ch/Syhkm2RRTDYHzlxJ35b6nfRfTddK58f0NFJOORiHF0UXW92/LTPGO
OvI7TFzZXX0nWVDt77n1AZlZWr5ebLlA/xPWwIazUijogtADzvK5PJNY3tYBiQ96DYizjZkOUaoA
QQjOPq/vqxxQY74pXq6zTGHAUfJbm6TWsNcB3y9SFxGXHf8/93LZCpuvAJMm5ooB5hSEEdO8VIlb
NFeeZgJgwDJ4QqYQ6NgkuqP66FNW00mSmTF+iUhPMC9TFZEY4FsLsIkG/V1vbh2iExOtq3uz7Kzi
r/BhRkkBLOSTXjFbW0ZP17Hz0jBi801sFKA/LjRnwSSAnScGAbgiNRp537z/qgIQr0R9examACh3
r8HN/V5R8Q9rsDEcBWINiMutNCpDYt1zf630IE0H2pLc/qF/ZodX2QWCp59yjUiwqZcIAboq6plL
ltNDJpPE7tnrKGON1X1Kd/lYmVO3NT+WpRqiGyaT/Ns6rB5g/YEJKCaESHhMu/DoHpqc0bqNjo5q
b9tCgLK2OEAeriZi1HIRpVvxaTMcdekJ507YbDlRQhmOfIWFDVbXYJZe8uWbH7kTYpCKYpIHl0fL
EzRyLH7SGRimwFIHh7jEdDgLxawUJj5xNfw8K/0z31owV/GcExzebB73whF8fSQUwWOBCHRUE0Hu
FK4FLWwSQGVU8dmFlgNqV9sS1Zevrjn045n5FTSvn0urAAQn4SxrKvXUk9lwvuoD4j67AqmmojeT
vck5/p7/tp1KTHh7FdiaKgphOS6iOrbwFKqf7Z4XTPOVLJS9DGRL73b3imTg7ZQSebACeFhtrvw8
EMfNZ1yCggnMtti+c/9G/W0Zn7AktZagAzxoSgsIDr5xxLwqV0NPvbpoo3Jz8o5pSw9ONQYDwMig
dUMfoLU2SNLdP+OYJpx/qX53n8W1nnt0AC13+BVI4oClW+u5rSYYfmmcmAjBDqxWjQ7kjQEaI2bx
/m+a0c+RVJHelDYfxdRl1jXKGQ1UYUXibt8OsgmRBl/GVW/zag3DxAZf/+ThgRbAJf5+vR2vvwD3
bU+au2uJ15mAcXfvv0xhe2R6kIz62gPAGdY36BN2cTqE5QORLtXWmEKMfyeZgeA/6bUbThyNmw3f
06WCQPTtI1F5RsyA/nbsP/oXH6GUoPNzeu6BRkUwygK6rZkmnU3SpkC7jT/8fmwkHDv5kuRLMgFk
VA4afyzfPdH1V7Ev9sVUh2TJdQ8YzWlZ/YSnijrfScApuaDa7LuBYFGwXXRE11rp9AR2u5JAcIvk
WpGSe9rVcxBOGx8lXKY+QpGYFNqikkRWDZLXp6P5bRv0M5zH3EvtL/psEKqBkX29t/zYaqEgXlgz
ufT/dH2V3w0QgT8/m9yYOSIaMU5j4fLz9oG172rWbi8X//Ur2bakffIGmHNkRkB8l6nk5eeziSj5
V5CUs+ZAvq1M/o8P/zbjet4mcocOi7ysAE3NXSZXggJ0hLOsc32IZZT49Be56yf415shYNiSMUrY
qF92hog+BFGGxcz1+H+n0GK843wxTQ+8r6tueVIfp6klAaelEC4uAfIxnOV+AIHrrDUGEf+ouvOT
kWcM89L2gOP9BFJiZUZsTyDVCV1NhgDNHK2PqzJeuNiO9m3AFmxMYAGUT64Ztwjtw6x6W4YJzarJ
2GLqYm3PGjBaZq+foNR5znAZQYoDaSBbQyUPbpLEHWNMR4aftwEHrlxl6Mx7WzqmRtZ4LMaaqh5z
UcqPn5qMxivd/BiOi+jmSsglsyF92RpdpICNopZ+dZL6h9Ahgndgi97w/tJ4R0+l3HDBackVQJKx
X3OgSpXoQI6r8MYomI02aCky4ujjgiP7FofkO3H2NtNXfeEKvuk6S7Q/OZSOYHMaLOrgiN/FJmxg
84ZRVxUko5j/hknSeWD/btxauXeoKIrkUWyriCIZewwIPOa+59t8fh73ifLcXzlILrxXOakc2ejV
Qec5Yke5YLZRsAHtLVs/BOO0J1vWf4oX3lxvmSu+jIUVsv2mR2jMTD2kM315CPw3UbSbAj7t2fUi
KjnuHymDF/kf/qtWUV/0FLW55UmuBmBgEdzhGcgEnXAZXLBP/KDVL2f2YAiocITB5D9OU1nK0C9k
y6yO4RP7XAHtWwsyCV+UaAPxLm9MwU/dC0thrEgz1V81RUMkT4tv4dXhaEuTbw7ifxBW0OLQpUSX
nmpUS0I1pkzKLD5hpCeuZfzf0VNfUHiRTwaC72KHY0pNB6S1VNDfsK2SYfcI6SeFCcmfcWw9PAPd
96JJKJbnRSzf8xk1s9n/+oztbp9LBV0O607xnGzRmlW4dlxAyD5Cr5OGLUKRsCdcQtSxeobY4RNo
80SpZt+cPWblTtYJ/buoq2p2iQfsGyRoVcA7o7wsD3CWXlg+m/zBR0y3qZjVepVD+m54nf9cd4sk
i+lmW+ECrl1AfAL6H/K/iNk7IWI/NqRQOZIhI4YphgCTBQ2EQNkXXHKN/o4RgCoGuYRqowuQEgYj
Qb/Y6ixvczrHc9w6ng/hL+X+/FBAG59V+6GkSDZsPA1+fmiBrc5QDqYhI0FEqmffTIVUaRel8QYO
Nc2taS/0fqxZ84HBIYPeziZTmMLCKszSOMF/5ygkWHxTv/n97ULA2g3i9PohcDbfuRPswrowYb3M
idB4LZkaj6USp5hjLB4Gwj08h62i03Z+//R3zekKLXc06XnQYh8Y9/kPZXb2gHyicIERiRUYZh53
qawp5fXeLG94ECKroOgAPcjO3cj90bFvRY/KEe1er/IvyYXwIplKQf1bktd1Xo+bBN++0CZMY7Ry
YE+PLHtZavVyB43IN3Hs6khq3GtjvuATkd51lFXq8Mj42jVlZuQ47hR/0UNvSEA6P3lS3wyhBik5
lYmLYGTUHLHyt2vOP1dTQ8708ngy4ucf3s4OjM/OckhWHVO71a5I3hdI9B/FjFIs5KDJc7VGkdSV
uE5p/eG47jvx0ld/J/CedaWA2fGsIuW3OE2HsWxbfHqt/8n5GOlE7XHagugMt/UisM7PYN66lB0e
OjiS79MvGj2Ye3rTY/p3pI1192aDPkW07dNxRzw74FlqE6TrBuEQC4oDBYW9af0NrCazk/7vnMb/
VwbZ72IbgSSgYmqtTmHxcOF0eMiT/uKFRRYhZyPu59s1+1mm3BnrP+NcviwLMAJx+aNNwF58dRmh
y23xtdr2jyc/g5ME23zMJlzimWN1pDd0fCowD+8nz0/7/sB0Bf/Q+r8EhFs1ESdI5A8TCwtVbPuJ
ZNywtaxMejtLJoYtzmdHIxj0WI80bgJfyxRnSlMmEVMyJsZDEnL9MuBiSRsZ6SIlPzkuOMVThL82
gyR69DDxpPkELPGvO2HdjI+zRh6yPV7yrYhv6HkSQpdjo7tf4PKJQvX39bfIspQtt/neiIZ+TyWA
eRDbzRlEyk9n/yMk5h6S2qT5qpNTKRb8FI6l7C/69hv6+zYZwqPgAwhD4rArER7Cs2OFkdSiaduV
bi3sxQ4Giw0XPKIRDEGRrDnbybuHWBopRRX5qfoiAEL67j6CJ2udHfOCve+bcOfjXQerhT46fSk2
/dn1HwT82n8aVxMtjZNPri/e5fXXJMTERbLiU/hr9WdG3vEZGV+wpyOvHeL4fjKZYZ7rzPbkkVeR
llQu7mo7z/GxecRquqZ57leN8RrVQ+Hor3X42hm6kAPfbWisiPbJuyy=