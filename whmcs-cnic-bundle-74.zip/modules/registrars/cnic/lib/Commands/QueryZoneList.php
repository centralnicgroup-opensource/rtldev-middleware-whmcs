<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxv5NPGNhgNRxlJ8j/KVuUtporEhp15mlBEucekE6VQOtsxT5h0wZBlOauBi4DKxZqav2XYx
m3PB9FdkuXt3Qz/5J8S4jjxD0X1MpiGvtSOOKLo7WdVdb4q6PrOYcWROysiNGZknQ0+eivFyhhCE
FY7HBVftf05S7hwztb+sp31cPxTG4lccsfQUVY0d8lu5watvHTzWXPjhetSSnF50lap6r074+ALi
S/Mq3Q0NXGBxj9hUc2v0gIuOKAUDEZkiDbA/jCCMKR6bkbsUTGKYa1SzDZLhAKjxtxfis5pUHXXJ
GOXF9t1/eqjOr7I2R23CBYhtYOVYEAYztsXH6WN2xpYyQ5c5wSG/uo+sxOyTVzTJKrITYz/f1Lar
T/Bfmx2sqQpgAQaP6YCVJF4Jv54aoABxy4kCiiISf40xf/eXJDkfLOc4H1+9px/8Y+4Ss0uewvul
0m5xqpDsqRXEs9dAsiEfo3kmlJkuRA9bPJAuGR9vJIsqsn3JnqKxi+dLwHJl9r9iJRm/vAKbQ2iL
NiNGr60bzv7X7C+RNy+EvPbO2fK+URs8nyJmLzYUjE+7iesVg8jwv8JixlLj1+eobE82SKoiib1s
TgcDmixI3/tkhKH/0Agj4Do5dfrp57aTmX99lNzO9pExt5R/80/bUq5A9r/LjbxApI+UXBYTlghp
DF9sPRml2jKA9drUl6naxO4k+MDVym14bLxGGw0Jl6/YqdDa3aZpA+RWxHTWVJQ2D8KSKQtFuotx
BDcXU40RgC6XPJLvavhFMcbxffkhZGZUg01fVfMeNIqNp3J/2Mciz8E0TdgmuqED2fjHwwy9mDZ6
qorx8PREKZuGMrIsZ82H7AP/g2Crg2TWBMESMj799Eg9R6t8OucRHXgsb8cwqI6blG3ZFdoZ9tWg
+E+VBKL492BywSyhtcx2vu/DsfhN2Bm6OlFoeb9PTkdUWowEL22VTNNUymRYoaPN7lslayIffffN
K8jSx/YbHGU/LvaPB828XSaqUaTHUbm74j4R4HY+6HtfUIsEhJLQumQxKFH/nG7lN9y/jMHg/88g
eIYJ6qahDZT5kQxnM/hyqwu24TG1LYWCuMkg2LbMTL67BAZ2BHIUIjUhTjEeglLqLdndlf+Jkw6f
b442NFEwp0YP+eUOYJROH2vvys78St3NtJ0RbECiFaFsBMffv0fscI3LCP2W3alNlXfdjgDs4v/D
ZcAjePomDpynZgpQBP/RCeGEz+f7JKWf8OUpNZMUt5wsjgxrZEGMFK216ujAdsPfFuXiEiMVidM0
lz0wCP9AYm57p6N/c/L1s7nJqdOtHVsEmGQ6bAolvaW1HYY7lqK/Eb5anNT1FejW18WRJofmzHi0
ve+PU0+PG9DRSzQVpFb9dHxE/s6jq03K/bPOvsDZsoM26vPTlPxFoZDNyfvgvfMY/lpbWSPmLp9l
CcuC7GYge9ySKSUauLeXRftet8SVbRrBEetMKszxeKqAnFbj0HjETmR6fOZsg5o+Zno4vI5zx1ZM
EX38Ls+w/BBB5l4hRoNGKWq9ugEFVT1Wpn8vVf275Wec21oHJV9ar/4zbiCLDld/X3qv/l/t21p3
GhaSDiX72Q83rYz8VRn2hy2gS//EU0an3AaSmUR47o59vFhhHGfYOEWK2B7e+fb+