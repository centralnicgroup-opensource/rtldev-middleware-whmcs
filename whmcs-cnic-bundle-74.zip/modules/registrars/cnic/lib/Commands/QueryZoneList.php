<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmOwp3A41ZK5KOjP4KYKzTImr+Znsl4nGl+NiK8SIV1AiofeWDM4zmkdQPZI/ZNkobZEsCE6
8tttU/kpbTL3RRcncjPIbwGLJuqzBlEIiyMKhzk4rkrhBIzJklkE8F2DXv5KVt1BD5ir8XpRVjlw
WMVg8IOq5vr+8tndnBSn8glodx7tFm+bDdOM52QOM7OzVy2OqVXIls/2yhGYP5oIhO+yLD4f/KjI
mwV9mX1AQLA5geuW7wsho1+Yvs+ky3FZcvZcsAjUyIcPfSzLb84c+UIdvvAZS5xtj614uiGgDdPB
VHbeA82+gkMesDVXyJgQLiN2fS372SiJX0f4BxQETD2KJbGqQnJTdTYtiJZza+VlZqg8vI1dNUQ3
B7Kay2M7YE6LQoOx85lkX+4V5ij2glhf2mD6Sjo/N7wIDpzMOfg3LH1WyLOoFsDhOOc3hvSFU+jq
ZUNpNH07k5OGjtxaxoMwaLYTqeYQAmH0IGqhYxuvUL3gExFDmBaE+ASCq1ecp8RgzkXPKo6X33NK
2cBWeRREKUhkyPMZTQW346ggR+4OZcRqmcPIzKAGhwE1G0ESUV2+1jxUzhO5MsYMUxDIhM5s8ydD
rG1SQ0AeX2K00Hyktb8SseyikxICmNydQqZwp72Pa99Lwh9RBAec/gRAOIOfMoqLb2FyS9KPKFAL
ZEFI/6m/6VFep7SQ4+3zPGT2/EBW/KD1HZ0rW9fAi5ml90s6kDSiiokXod9itfzyiv7PWLKrYvjP
Gohmk2acWYcrvEN8aFNbRuMooMsOD3ZmR4dSJO7y2JeeggzBJ+l+0X1hdlhFyOJQYCUVumcEwWHP
U9d8DW2azMtzoPa0YtNo2I7zV0xcWIcQUn/oy9dzcZcRXWRIVm6y5Pqjoe5rGyLI4cTeyiXQK3TN
0uNojXX0ozEIVaH+QnxYafw8J3TEPDvlGlsuOguiD4+tH3OjeS5umoLefz16umDI9SEj3VgV3p6a
cTOLgh+P22TNXkL57RjDE2Tf3yG56zjSTajA+2coui3f4TAwoSkZwsS+XVuALAiJYRxafU9TnBzk
61mFXDLHPBCqXOu8tfHG8JT/H66RcEdnnPPRL84tpsC9DGLdB6MsxVVio/K4FthccwCN3aLmusxg
imy31wPEPur5Ecs5CwiqDOhKIreSH5phWbAIUKq7hY8vM/uYlVkbbqlk+NlSiUGmbE41aLM0z6PY
wLKpCmOgYQnDkp5tI5HXk1gKnIb/cDgXvoQqRkdXGbofTt8g5LZvmuqPy/06SYA/+kRzmhoBloqn
DrppXUm7EH6IT7QqbSH2g5d27bFfBhhJVri13QGbez20T6Pm9H5JJukyvnUjP/AK/M7N8vyg993L
XPDdhasmUc0iNBr9HmWEIyBusmBxaMIX9oinJ8tjJZqts/9uUKVtAQ6tfV1sS4gLnvE42373hz+m
Whc6sZ6P3NlxZCtPwft/SKpyVwwXOv3TExrxX4JRSuJHJK/JjZGAEHmB8dYy9rwou05FlcdtvbKo
kUIdTTphYRSrdw6Gc3NRSXyfydO+lqTQHHGJNID+leU4YhNbvgidnjkiCtOdNiKxVXkvhkzqiq5O
S3Yhw9EfcQ7Frb2FmlGsP4+UGpgHy/vm3L5LnRVA93d83xNckukdRlYSGW==