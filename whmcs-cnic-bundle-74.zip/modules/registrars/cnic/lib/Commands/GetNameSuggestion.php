<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzjT1HvYe/rHU++GFM+5/BwS3Riev2YCVC4gab7RxMkDiHUfUsolGzR0V/gJOwb3Ybb08e6Y
ZRMDlYZoTNF3jKWjCIgBhOqHVGTPtWKNAHNf+tQZyFOF962RD/D+1j5LEWwHJSHMynyxSi6Mm24X
Gn9tThQYiJ8cOttTAM9lnikrkK+R3PRwLOHlJ5Je1em3VRuNgyIjjU8eCgD0pmG0lX544j3glKRr
zAsNuKOlP7uJB5RdzBt77LIUyCMYRlL8ua3c1gjUyIcPfSzLb84c+UIdvvBbQVS1soIRtGJ8eTzB
dPl8VVy+Ct+X3aj6TBUZB5591aSP0s59OsE1A7X0URo0jilacRM+pubpwdwxikym2AF/613ib2hN
+pc3giz0tqgp9Tt3CEmL4aXclAaMghSnlJ8UZORzgdgu7cgAwthyo0U2PdI9pidykk26Z5Fc/kkS
vOvo3kXMXNzlpZTHxuk9YCHlvNiOoIzZRl22phsQE5w9kVfvllR+AJxHAqErvySlJaoABqj16qpW
eZq46fHXgbJviW/Ss5LkFUTc65Bqm7nwKXV8jsurUXW88c91lo2fYxJGBDQixDmholyCIZBx2FVk
USGRBO7EnTphU2omWW5e+j8Cm2F4L1qPU7FT3HLrjQSTPdLTcWO5TjVMwMmCGeNA9korth8sq8R9
AqWt3A+iOtrfCXx9mIBDWGMgha2HOZIKzHIbi3Jc3vKrAJuXdCiAhdlnydglw1yUb0umd4WjR8Zm
MUU0xOhCdOXGfE515vZ20QtJAcXuIfqwK9Yg+TXkq8r2wLpPr8JmNNgQHZv+9kok3LnSoZCDySJ9
5qrG/Rti8zP8Du8gyeeKYFPUh/f98jDaSz0D00ATQzRY41P3P/niKBn8Y/JDWaxKQgTeny8W5BNW
RRpGzNbx/OmewKzJA3fnRaGEbtfHHnVipt/lbFuZKP4M2C/rg4XmewNC/slxAyTB5qLnmIn8ce+y
2TdMmMe+w1Pb3KStm6uuTCp3TaqDC7Wiqdp/gLjRwJAx6Y8cP5Ol29jj+xvzZ1vs2K20sCSPGrp/
9J4Hf/AvN4ktLiZtQyWi00BgtMfIUwtsItRyDyJkhd0VlWzlzSi8h7vMXt8+0ieG/aDSLY2MzpIP
FVgDrqPVUYq8nbf8wB0dLcySubZWVX/Ks8CmrnB5KjRgR82LFeOp2zSe4hkBi7t0veaNeaJLk/cr
1IT7hfGZJnRoDKoaiyVH6qrS10x1/yDzYaYNB4V0knzfFxpXH/J7qUfZNQcnorP9Jm0jet0I7O/z
wZaOgLvHz7ObqWmlPnzPwbmi5TjTkynC0QqEWgX47Zj6YCxS8Ck+Vu8GNE/WYUXk+nbDGopn3lX+
8pNhbq8n38oRZgwxLEZ2BubpBZYvgW2TeKJ2sNoq78IgTC2Kp2uxBgwZJBLLhtQY/AS7x2wGU/dT
puXcDx6we1NJk1+m7dcbkj5VwoncHae7JAAfMLm+uislAQ+9vJ0CIZBXy1Zqzp9Ms+N8iI8YjJ+V
dqbWMqbB6oG5xA6xgoQ9RHD/+5UH1ZBaVMjQFq4w1Y5suR2dMdBBBgNlCrzLy1eqsNkLGkut158C
64KupKo/kMPwrC61+htRCmkPstUUkQ5WM/Me6Aq6KX2A283yzt20868W4GWY+9x16Kj2ET53ksOW
Hpen+5t2zUOa8x/ixsNRxUbTS16ciG/7CY5iia3w9cod94/Aa/kL6I/duATvV4SwPaiV9tbqqmkm
6p2SFlNog/7cIit9+WhZxqKHDxkzKfp7SF/MEIK93YUdofK6WmCpOsjTrgAHB84N8tGZ39LKQTqm
/Pj5ql2D0lQyBVQuLlI9gOsTN59RPcI5yHFLYoRTJdCm8doLY40zesowA6+FKGVgH77eGwt4WLqN
NlpZeIQEAb6Ig06v+y70pnFuqAf4KxlHb4Zkad/J4ONoY4xb1KfpKS83gcH+9F5S+uuEvZD7ihfZ
Q05R