<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo/A20FtAl4qZdYT866+6uA4L75alt51VFKa79qWMl6IYjXK5FN9UwjDFRNMJ4HpV6oxY+/R
vu0f+DTiLOw6gfDJQIrseA4PLgAsUHHFDMZzzwHYwBNFA+gb4ogtmQcIY9h8XYpsNPY03mmvtagx
NxAzuQtvO5Gv20Ii8KQ506liUPEzpFmbnjnj24QQGy37RGltU1Svsk/Rtz9deu8YStyHwm8hrocG
O3zX1PsxncITBltbMJKAjchbP/fNnGx1CZjEwxJ35b6nfRfTddK58f0NFJQRQEx2bjYkV4bnTFOO
m+K6Mlzddt4Nsq40bO5y8Ug9GfZGkg3oS7vVo6g1IIGRbhg93frF5OwPVO2IZ/kvvf/KSA2DLYzP
TjprKz7IzmlN16arY5y91Hx+o2A58iTLe/09vPxs/8rZ5uUE606JFaxCH2kgSwZGp87NYFYUgnkV
vwi8rpihIjM3oSzjfpAbkG9Y5KUNan1b439r9xKUroHx9LjxdQHVN5OHTKho/4MYtcmGH47q2wCh
eWWe21B0PvDKDwmqYPLobEB4I/Uu1OdtMIl7AODAxl8xN0O4tTo2Y9TNcjw3p3hSleAZb59LewdK
Yu2ySqkiBlf1f3hWFk/oA2OqovRgkM1QWX/jQN9YtSS6NmOdZBwCqC6Mz+qqpHzW/2C4x/VbsnKp
sbqOTm2HN6zi0Ts+w76ROZBVz8nG8xa0B3v8si9TQYARf7EBMsLtETpKSaX3BesiFKri7REQEd2j
ghOEjDvIbbJoK4UoIFwyXgy8BiKDNekKVqdg0Miz1e0WufykUx7iCkU8WSwvxZXcV7QY4ONxy/KM
QxdciR0a0Ow8edOOQILLnhHs0sh5DxD0stJMwOE4ZCuc8oDebiPzLwRyFNsux1L8wiUDwYRJ2ktM
swbxcxxVLzpJ9QiBHPKzJCy/bHaNBF9LinHLNmJH6kjtBMoBHx7nld0rIo6Aq9EynbGDtfiPA/PI
scfZhx0e57bki/UgbaB/T65WvNBxV628tonzYq9Qm02M1ZcJfY9NJ/YQuO4Is0AC+KYcP8JYS6Qo
V1ua9mNJhKK+oklhLkeUAksE2XRDGusvMc7dK31nGfUHhX95EWSlXi+mSeLbXyCFvrD5eXFWO4tb
rMIyrb3+vM+jeSdqavrW7GMtFK9MqLAdRqBRaYqvmWCqsteVYWxOPW5q1LjoPTX9hoDbIfl5DfSk
QsZZ8LwMNgvu1qHTMGXe/v6Cz6yTHkmSBBcCX6mezDXI8ZJVKmAgyTHZfkBXtync3wOq/OLKMzNx
gEqCnjZBrZKqODcV5Qd17drcLPzT+olIKjFlUAXscyLOrI2zxw5i1Jr5JdEVqHTBBBXtW5oYewl9
dzYoQ9VBEc7xv46Sk0ged3VawCY3RcCm42mioPGx6r72DWv/C0U4j1GzlSVGE8M4XYK59KB6XhNt
ZDQFUin0vMhITj1jwybJX6ljkourtP0MHjR6p6i9lIN4/az/10jdd/xQv6r1ZeX88RsKL+XqvT7K
b1ZZUD9xjiwxl5g1Xvv4OAiG82bqqe5HZOZYBccwyBlNjzOEPdfb9ajos+zBCB+abRumdwQvw9FR
DtgxA3Ht3HM5QtFJT+Jy0PLUl4QnezfB7HFQs8otmcyORqNw7iqlIyjpsbcfYQudG6zo/DKHtRvD
LtsHUc1CC/z5gMxoGhlO8UIJZTCupTEQfvyG/hN0yz1TnnGreCeA29inqzcBdaeWDW6qr8wOfJyh
t5EYJ3vKsqLKSlozJ7Uoq78L0PjraSiRgkh7E7NkT7hAfHVO1fDYf3RfXLLpU6ZXNA98HOCdV9dB
FU6vdPliafqOp0LwyRTudH45xuZ+36AWDtHZVhFtaXhyt+rqwAI262D2WcvxEPMouO8h5fuPHQdM
nAvG7gsGdevh4Ci7UYlmfs4AFy7cQQ2wCwgCtQnMLcVEHHwoBUfHiLhl2ohUbg/ZIXLhLMZD1Ggp
8tDn/G==