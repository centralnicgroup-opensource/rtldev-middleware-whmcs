<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvi1Cq7PseTsfCYcOb9kL9fwg4UsH0NmaF1X/1YNmtGzEuiu5Mj8UaFYQokTcaZKvZGNx0Ie
uYNyhMSnvWzxCjFHdNC070VwJPLKveUnjQ8KslMH2fI1OE7UrkT9PNWhQX/qd2UIkXOckYELqsLW
PcYHiorTVhedunLgJPbMvdfelJg/BTmPDMK9Of2oQGk8LLD8wUKj4iymIj99tj1Ys7T9L9mu7lzw
v1ZKcUv8MoKT+6C31t8fYnYafUCbZozimBMBsAjUyIcPfSzLb84c+UIdvvADPs1tkxyGNtuNx1rB
3IAe7CBSECdb/psWxGJOLUVKqiNv/CSgM4Ja2eotmLKo98XDnKVwcequ+KqhZeYPgSBDaoWtyUMq
DEx0GKytYXPo7viQMxGEQnhUHHiVstu7v9ovR2ApbpXPzBJEiGKQY6K6ZnHiv0WpTSslKTXuz1+e
hZepj6Q1BeGl6P7m4xsD7eMtlFgdlihNe5N3j0gdIszuNcU8SjcpOpKXYjpqlMLtYfGs22FpeArr
2DT44jr+TGiZdGdlQzx9jmTtgXHstd31FIpT1vnoNZk15XOAODuwf47fN6dSu6dO5BKBp+bHKOFF
gaz6R5F9Vv1mvQ41r1NX4yciL3LfkqgAw19p0/o9+YtG1tG14GM9Nb+UCNxFxvaVPZZMHybxWXmL
By1Assp0IvC7knxkf9LCUB0IXP4rphGMPwKqy7N8EzcNU9NtwYPMuTHpEnMfpVaVIVFfO4WtVAdR
c8LM5+b/y/lntqbEDD+3f/Wj3x4uNDuBmlgZbTVJwxSpkkx/G9+ioRWriwf1id4eUo4H6405VkP0
gIxYJhM5eMbrt90UQOqt3r/TDdjLyho68t4OlnDcV7tOdBRx5V052NS2Qd2zXC/xbVWMPph6honD
P9Q/jjpkoSYnZZCtC6hro/4SSu3hodftBDcRico4IJRuterABiH+mQVulcf4M6M5+wOKpzYmvuvt
82vgYZfVhgct+h6hBdEl6t9YesH/l6xAB/x17/XI4O/ryftS5nTI0cQfx6sIPzLSIFcNrc7J5ic5
L/sGWN2C3VeQUm7tGlAjrgwopJCYBXSCV3/Yad5dlCRhdV5xkE5uWcvy7a8d9sY7DhU+uqVkyKOU
ig8SqQAJ1kXvDsCNUD0FZXjdYp5on9mR+dbcX3SwpyhY3MykUN8v7Xq/3QotNPqHGiJk5X/WWeIm
XK8zAwabHs67xYiAgKQUR6wZaFHc5Yv9IbzkbwUfsmNlprn2gC0TrKVREWYtL8wDgPy1Y608KFRv
2rIpd60/6JHCd/UYrBJAat3LTA+eOR/QvbJZ85LDY1YUK/tyZ45IpttaTK8LSiRRjozvvK11PMjG
uqiWp2E2luAQLpAsGTZiai+a+C8L6KYnsqtrrM0nrvtCDcPrN7FdW+PTCHHWcHoT7W/PoMLHeEjK
RvYhDyk+bp6CiwkqHfRibXXDItYzrDHA2hMZRQebSXt8YahictL5oYnWde6xzPMa46O3DZCr06us
3fvknNR9zP7siv2ikLzBKQ8j0Llp+nQG46oMm1jH8A99MKAvlKjlCOR9cT6yIwfyWcM36IWwZKUs
UAw0aJV1DJ++acdKSedSJqFANNrc5+yGQ0LDkS/qlxGWTwLBK1IGbZabD2RGfZsaHvkCMOXFTU3g
b5h1wcxGA6u87BzBukb2tq15s+Ss3nedJcKrt9LLL7zI53rOZprWs1MVfy/9mHS7TrWodJYbaFfh
bO2RmLascc5wHUUMUc9gL1KcXQRDChGwd8ACQT/JVozUSrnjypztQxaU8K4BxiEC4GIpFTRuTV99
OLosYMs4fkef8cDRjBteA60su3j21PglJP4mv1u2yimhuejA/Bq2ZawUvxtTsBb7aWZ8xBsXFZas
byp/rUGlvlpvXofTj+El0W9QebqS5dWwJHJJVvTGHT9NjaD83kyaG8HD2DG+b27r9wi/PRT4r3eB
dC0Qcl8oLHY7TNR6b2HoccU2RUbqO/Kra1HILO6lyuuSG+AuQISF5IPZFHpHfY3BZVJRd9r6Zu/6
3aBODmaKLzJwQZve7ie9i+UL416qIwES3YLzUXQKSIwyaoxWty1vJUJ+a4NNx/jrg/H0XHp9jXzf
1aF4IKmHnV/OKTMETMqPYLID1Y62Q2iQ8R/Rm3K9OfS36/w6mu2xGOrp6Q83LK0mUT5Bkf+D2IvK
rjvbtbO+vRB5Ax6ojLlb05LfYLQIZGBSqrv2EshWz2BkQhmUNEVxH2zkl3srWNzBqtSn2SrkTBSV
RChuOY4bwUAwJpR+8sS1xcHWxq4oPGKsNagB3TU4haNpcB5P9pSgKrNmeXs5Llupt+5BcO6GqiBz
VhMIFwAphNwVouJMGTk84F1Yx5QYkMUiHMQQv7piWcJmvMjwQ8S5PkYqnafUAlgcu9DWX/FZblVs
g6fFBNxvh/jQ9B3slG/szwRdXBPsrzlWOEjotHYJYfeNu6k0PHniEBjdzH0p/Lxz/xyjfdrcNJxq
Lh9S/uEESPJJU5LwV48eqLN/c9j/dCiuDSvqcbfXbYD3l9V5ueuRIm3SgmzC9bYllo7NxVL3XPKT
BdxOzrUeBJxurce34i5vCq9AKscRcPO3Y/70G0Ythacj7fw0U5zqEmhfU/jl/MOYAUE0vBs5vnja
5xSawTVcZWV3GfGi1oSjFlIT6XcFVCIQ0oOWAK1N06OzE5jrHYxHXzpIg0fKWi7+y9rgc2wn42rl
B61YFGB2SBKZ41uvFN05lO5d1VXCc1JNAO258ANxWFyFODOicACSS7b6tST3Chym0kJwximPZvNa
eAAnxrKxC6G0s6f2daibNzQ800OsuJZKM6UbAzU2pw10noU+++msY1Nl5HK7wPooRnxFLhis1YiL
TBMSHeM31YYb6CvzWD9jj6ifgPTKALtqLElCUfDV+PspDvA2mvcqi4bVn4Atfct3pLcck0XkXVqJ
PNUqPrIMBHVyE+C9tbnhLoJyibLWzo2m7VZypQQlNZBdohjNT2jPVZdxsGMNrLE6IGR8tw35bnsu
PGPyivtC+0FR4T7c3G+6claoiT4wNghlzkR35nrbEObty8aqsx2rKyIH4lEQLFyGZkPSJzrLB/Jk
5Vob6+TuepM6uGcWEeIvibRePaR2res4M+MZjgUkSHm/yaMavQMC4NdONdYmOAbWV6YNfws3CU/1
ZcUCyuE8ytIGzCZcWHHazOM4O1woM4HN3NTixtgGWEW4fI5EFg10DsQXO+/euZBtfEtn9iUVGJqH
Zyekhm+8K5IeDRD5uZ3LOtY2yv9jJv16XIUkV2euihg5dtDE5VT157MiqNWfzxKWkAzE3EraXGko
gqV5AMHWrFUT2fSC2VT/+ebjKMVmkFuV1epNc7GEqzq9GQa2wQYmtMph2xC35PsNOSE8WruHlfTd
/W4suErlVJ4zigtHF+qufIKFqh5RrMI7ByCEFHu/HqBOH6eq2xmRbUutombPDnnjsqHmNncWPOnI
63BOW615VDMinwPUorIFmN1qSa0otS44SEWr0m+ThSIFppSLRywPX/sKSeT6I+SG9GjelQqBQOG0
dlVjUzsdDGaNOYZ6XMJqi/tViKaBlrMzilASjtJ9gjPLXbKSqNB4UiapgRlfuSrV2k1L2bcszXkY
iVQAXCsMXacVcCtnJ0FvQnrh/qhhToEibSRSUTZ5zXeFXfTQUQ4tFjPlwbX2XRCg3pXamiVhejD2
suyF82pC1SzqZnawnEylqsHT3HkFrfcHm8a3U0zwMFYti35rGw4t5+9oQUlPuZdmZ2CH0ln5Rpza
y8xyNlx/xiy2Dfg3/asS7ecJnmJm4GmZjgfqieO42TH4aLqRIZFeEfsA9af28VLEpMgRgyZzXi+e
X2OqY3Ev0FjsRuBxolTlV9Wtd4W4kXdOr3fSkDJLVg2RsYBmTcaBUQGmQgXtVQsIx8Tnyuab0BkP
sZ2LitRyWvua39oFHCMZUJfHFN36T3RAj9FlUsMV83OVraSHJvyLTdwbiE9g/HJU3wg5P2SqoRup
ZP0CK5arGpq5dVOSY2vZJg0ELq5Y4s104MXiLDAUbtxZi16NVy6MpW8CvhiWqKsvwgKblgLE+PnZ
vT32LeRj6CUOb8JRhG6t32X3e+qjDuMmlF+oEHpDlxtLv3dL1iINA4zvaYMlTfiLbJtPXW+tRXPy
cV1PuNMAZXSAcfs/EAl5/yHi5n1+YPG+ZiLbePblp07lHBQ03W9rEQxJpNUlTfdy6pO4pPPSnviX
BXEN8mEVN26+9wClXMC4Po1rWf1bZvQZu8nIyRtLgzAZKqrL3U3ZkNJZ5vKt/4DvO37ftlLdHxUy
MdQfBkdBt8d3kVJT8JU5jQs8MJ28qOHLmaW+jsEXxfNnMxBFKFPIpMXfrwyEXmc7YHATqKkNXQXZ
jPxNu9B7bqomGWFtEgABFw74FceY0ugwYY1BcqELaHfQEPDiXtTApU83Y+1/DxVIV32H9UV4jm2s
z9c/OGF/PwoaWnzEdG==