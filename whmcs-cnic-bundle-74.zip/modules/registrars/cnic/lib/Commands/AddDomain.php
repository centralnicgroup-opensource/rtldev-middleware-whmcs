<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp7Som5KYJ0s8HLU8iln98y2U2L0WS77GQIuPnh5u2LzjMsKgT0+R3dHPVfkwKWrKOgWSy7+
sE13iuDCPBwykVVPTwAl4biV6RNDiyYLaNjZhUFH4FWt8nSNz1vAnnTtseWHNE/dWG78qyPrzl/v
RBB5ZYCgkC2Jq5LJz0Udj3gz5qEl3xWR1XYTHnhxCprguRJ+bLlbXDuZv9giYPkV48ar80VD+a5K
Bov95G7cwEbClYLEdMM2dkbG2K+HFUbeh+8MjCCMKR6bkbsUTGKYa1SzDjvdHdOMpmNm8FYHjHXp
QyXYNEFBFcvH2vaN9HGTAzB25a1JdT9ZOcO8UFeT0cHIjoELI6zON916/GewTcBrHrlybpcMJhVI
BeFBiW66posvXs75Cc3h+u1bemLHebdyN1RQhiZ3IpDtV4ih19GQWhqieh9q+FADCx/W8NT1Jc8M
6N5eK/uM46saE8A37BcEnhDj3rjRbf4pEBbUv49XBvsHhts7M6f9DTBQ/4x4Z9FTfM5nzsz7FLyw
/aarnc+g0kvLli5p/LiMm6EWSBpcldYRQuKBg7cpHB9ehQxsZMsMu11pftUROZ6MpJUJH2Fk5/1A
p/88ExwGqgsOay/J0SeFQtZbgN1E/4+yCaPXdjmLzeM1kmz6jiv6HpNPareBIsN00ZaI/sBBIvTq
Dw5qoys5vuKhylSUM+I7v2xS32fTPrE3d8VevwPaNT28MMEb1W9/4k+0A4CJaUTLre+mRBSXOcE1
IruwSPR4cthv632l1ogbtiNz9LMWsJxUqHOr6Mz4MnADVTWMT4ak7GxYK7jGMumjvNdiL59Fq8MD
glJ5rcSrlmy1b2jqbc81EwwTExdWJFQY5SxjWoDPa6ZFKKWw/Q9u/bO2gtRhhALEAM43o9o7odPh
fp6JwPg3GWaC0OG5e25lJNyLUqgdLm/0brM9v9Rl7o5SyHcLP+/3XFxwtWuvVs5MaANmXTjRP0+Q
2MzeyJRD5QYCbZt/kfAnEP5g7lYr3ANCIPrCa+k5xFsmKyHyw254npf9tzyEXhnu1q+tB/usTtzM
N7ZplVVfQok0zqTIFmBMCLktrnQDjrBOt3t2wuqjrNBLqA+9h/zql7ijAz9NFU+b42NFzaqNaxul
L/8ItEGbk9urSC9slpNuTZx/wmfnVgSEqJtq2csjFrMIhstLlc3jcSiREU31iT8/sU2XmZrd7Ix4
Oept7kmhvhxqP1qUw+M20CFIAJElGaoA68kaO/hKXWradeyO6i/uaIkRTN82a/vGJiDkRqvH6A3u
qSrQTpFbVzYWXkBZuVcayWIrybHyU+4nYmbcfpLIVUUKi2zMns5+89HMEPGY8kWUfuhNKxqIgSkP
vlfJy+AttfmhS4zNgsnSurxcDXqdSa1MW/qpFvKtNVqNZ6PdFtvBv5tBtIColG8DGQ6Ag6Ox/VTx
uVNbu9nXk8GsL4R3aMWBmPDqxNeB2D1NVf2TYPYAz/rZYl+7fq7AysALyDqRkvhquPdGtuugyCVE
ikF9oGBFsLNjuYAeRdxoqsikW39kQax+jitdT8XkL5AAxBy9A989xTlxw9POhaOcEuiepzHAI62A
lLlzdekhNwiiXAw6mMYk6Q+dCTn5ez9eZ+/JqIbxVUbTuvFtlHbtJ1e/r3MgiEfX1XYGqnvF3DSC
agr4Mzc0f0tf6JZrQR02/nTfmmRii0LdlPKcyQfBz+F4n+McsqB5yTQ0PMK/e5jPQkv/JtlQhYMK
faraib69XU30bSeHmk4xgFcq0xdVUgVrTXlzEtpLBkFc8WZNZpAClddiS0PkMSrR49ZcSoDRlMnK
UHHuZtdudI1LEBMRNEkFIjfdETc/DXdafTPMAA782TGQrfMsy9CIzJQQ70YNCMSDv1wqTv/6AxxS
E53dYmwZ/WtlNJ1QPaSfby9d/+YhGUogpyw+YSolBzLUscyk1tYAWrCUY2EYPnzLaYmCYH9KA1MQ
DfoKtdjP4Gq/6TELo6Gq2tjI5K0iIWqMgMDU3S0tsdGQpzvy/lRfUrRkiYSKSZSal6BaMXwecwhx
lwbmbo/cTvo7/sxgusy3imY6WetdSkNPMLHtIS2Y9+HZxj7fTsi3+7qrzoQ0GWgP29Ou9frOVa1h
DW0Wmipd/6lJgUS1ALQZlVnQ6urx2j7D27bhwWcWrZUz+TNn23kmtKzeLCfWhzb8Lhk7vC+khexv
31uZnd8u+QJGgiklDmUlCkGMniFuITDuy3Ks6ByDIG0utcnngkpAlMcXVMaQyh04awSorEnWQxGK
Xb6/FyeW+b8F5P2Xl/Gmv30RK6IZKWXpLCM97tquWdcKxDjfkncPn1zZFiiqauUhtaFFNXFX5CO2
IHjXvv49uZcQiyawL1KV4IVz0/y8SRVbojjbASvXv+vbvGsMpjzpVR9LEwYnw1reLce5M457OnM9
eRpf0PLAAqNxn4CX+qCzFyH9Baa+l5Xp3dvebIyxp2Gr7K/fgknIbW6OZMxHmNBCaOooHDuJUlAN
lxqlHDXKFN+/MpTfKzf7Me3qbDspddkjeWJo3qwNtIh5RO6Ioa0Y+nfxaA1qMY5smeDYgQKJU/xn
1gxZH6mqXWQdBMEqcMKl+ZGKGbFUejXz1Wlgv2jnzEhBEgoB1hirsKlAv3st9v+cjdUKNAFSnmDY
lSh7jXtFEfETmc19IKulN845a3457HJ06hCq9CUEqOaxNHz/c2eqk5F/zpkZrarG/mAjjsKIs0Ub
YRgj5vawfAMmT+JdCdf8jfq9bRrQnsTtzPn6JtM8QvqN3Wg6Czw3btCgvJhsg/o/LePex+aIwuyN
IMhZrB4VyHW7DwtIlTcmlIvGDTABGdng3TarVoc4BSzPwCv5Fs+88ZjXeAJYzYizcxNjW69R094g
IbAEnAgj4UbbV+EbSDVWfLmcM8kcWLZLk5eaV4mcwLZ0y04TpgaPSDAuVFrLlEXlvOSJg4GLUYoW
/g3Hw/W2xTS3YT9skBLbkxutxj7rc09/D0nIOyDJajDtzVAL4e/KdTJBrOAsuJxqWKEiw0wuerVV
idPBOK/RheYIjaKmGklyeQO0k7awtY2G4ZNrqjB1CEqwFQ0jFzoMgaXJcyklyxZVp4tzVvotUNTS
koK4bc2YSuKkfy2tOAMscnbWtkaT/faQ3SIuUlatlqJymo2JuCenSmJofqY/hvVte8Mmoxjld6/Y
TVOC7mX0vNJnUYuTChVZQW583Bn50pF73G2hGYVtkqg7wsDu2az2wpj/sEGLrom1Zst3I2S2IviC
lxt0tto/e4v7NPi4mxJq7YKucUKEYtcZEFmlFcdZADiFs5aptONszCei32IHiqSLJaP+kcI6NwXg
ad1rlpBCDUpaWkl2PgeP7sosBH36TCAJX8g47Tw+1O5cXTM6oSdasvpuEYI5w77jXvDyKNwLlNEa
jSqdfPXSD2uUEPYYd4rW8xMDnoj1szuOxbJY9PDQPtmLCO04bfQaUn18MerQ8g2Zd1rmBpW7Wu7L
/m9Z6fxC0BnuAm7k7UwL7IguFTTdx1msg8/b7eQhifKzcGR9UphoU4tfcbNFcH8sHYl1Zk2fOtd7
W5PF4zKzu+wHlrs0/UwOJKkgUm30jGxh1WGqnovLstwq+Y+yyMWe3pQKPSiee4/6qwVKq/v7+Gfc
O7ZM+7Y0lbQ3MaPW/5uWHEMErKZX20QhR4nH3I5ANvYyuHVl5Yp4FK8EW1n8Z5Jz/gWdfXmQ8l4F
Gc54f5DANarnHdfKDGwtO85XQHAPrhEYtUqS/mAurqxao/oOXOPqceGmpPghi6TvyW51GaEPL0qI
rkkkbcKQK8wRVeGBiBoDKmK3Eg7O4egknsTE7hGH/1MYvb78tsTNptpz6s6+tshEWuge4uL1RBl8
LTWlX7h1aKCjidSmUmk3KhVTL9GIXnCwma92BiVxjiYkn7Oi4kM6ZwumPmylM/M4IB1WXBcpi2eX
lrn0inESrkEy9HMqA2Axq5UGAHo5tXYpluWhEv0d4Rfk4mwh2sjsRQSoYA6bvcUVxv+BxqL1nwVR
6keqvpBeUUfQZ9fipYN0n77bnJASmIb/wfxYWwJ2Aqkr4DC7nzwE3z3wR9np6Y6x5ch55uTPhoXE
kAFZxaL5DsW7JzBvctmcqPrD6RByHqu2bY5TKJ6QkKJMsm/RaH2U0NI/XqlQhBLsDDbHESgPAR9D
Yl7dVr6HgxIxsHgYrPGvjApvfiq5YDLzX08aMNFYyt1u7ZhjynC6G6gJd5SSGTz7lGLGH1X3jqda
NYI27H2wsbb5QRXzoQad7Z8A1qkKDQhVy9jRtAR/EYfHa+PHnlpwI9hiONbOy3a9bmWjfB+sfXUY
73fJili/sRj7BtyHs5va0H6dAkliy8nfQbBBk3N8whPJHJSuCoDquN/hSvq672l5DtacWxj7wTdF
WymZ7hxgZLpRN9TACwrbpuj7ZR+qe9dqvmzFKF07wQMaSmkMMg/GoQUC3mSHHx+p7N0l