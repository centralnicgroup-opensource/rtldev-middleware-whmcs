<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqEts+LIdY3AAmHEnfqiU4II3sRuAZKYUEWQI0Juicmfz22o/B6J2te841v4RJJxRjrvyhM4
dH7RFTU0W0uzTM2mHDVbgh+B0N2jGtxOSZqYqAzPI3LuTNlqEbSw1SOXiYwFBqe13n+N0iwRgp42
D3gLujS9DNMWu186g1Vay+/ZVaC2rxt9NxwIc8PRXgxFoizjiUqSID9ZAlV0y7fRjVtAP6O0zYdV
Ejuj7RFZX9zBvvyvOYIxehGtLDBjcom3cywtngjUyIcPfSzLb84c+UIdvv8UQT0rWox14jkv9fPB
VPudHVz/Dj3wddSwTmJJjxpTstqbYqovovTteKlJ82W3/kIyh9EiJtPW6pdkQbipGok/z293LheM
n0RqWVyjdh6/MNWi9KQ0QR2c+N4OKhK/grXJHXYp2JgILzlALQa39ch0UUzaOVLTXC0lwhpqyU+t
SYPfzgvmEYlPTDez0HHLgh07n+niQmWYuOx6tW05B5PtmjxDePFHOTLf+QWCdXwASYCkXfVc4eIf
IyWVwol8H2Txs8ifRPZAwXUXrpY84fmX7V5W/tn2vNdgrllSI2uL6iGARB2h0MGK/+uzwcLw4Xek
E5dddHPMSNcPIv92QtKFDccEAXcSGzlxhVP6dCgIf0WXT5t+9vdngm7Eu8uVTSoMCjAhbxWzRJEW
/6GttDXugOBgDqWnMJ9V7NlvMOPv7JH3jzfXLgAQbIgfsudu750gZJ7Y2deIybaOpXBvVknmgIJu
oayU8FO/8UifovCkKmwe+4r8sj8YKgJNPw5PXzGKrgTVjTy8WNrtYXQrIj9q116KNOXJjr0q+nLB
9M0JwIIbkKmsJnYWDHZTsiNbTy5CnAWDr9Z8aPDYbrDhlgzfAU9NvZeI14nPRCGLaPN3MDbvbCHa
hXEIzmSDPH9VOys3zQASPu1ggXyE6PshZ0+bvAUIqSpeGmcwTaRPy45lvOiWZTEw+GwaylShX7jC
ojeQjRFf01p/y3wDPzcY+GX118mqk94kxnNg7Q0CKbZRXqGCpmTXxKOCFRtBwt8QnfXZ0N/FWmVF
mFWOeGyarBvV0EZoeOh9vW5thuNFlw8W9myNyGLjpBjLSN9U4UVn9l7YhCTZVqXHZ/LnjNWBEOrS
ZMU3L95UQmKTz0vj8q9D9OCP74Th9I76kmZ79PC/XaZHSNxElfYb1170XkGFjAIR0Vr8LpIFzewv
FcnbV+iaDsnBRwz8d476RRfLqWkvEu04YXNj/LCcz/5eYhB8bRtArH9DfajK6wkeDKNHI7LTNO3d
6zqeKCv+t8MGy0tSWjVpABaxEFYhb7l79Cic4irxkTS2biCZ2//o5JDrgtUm+4+qmY/xdW44Nf8Q
KY6ZlsT0KC2Wj/s4smlzo5D0BkedGhNkPvYN6hjBDiMGPLXXffC8kTPDhmvDNL8P+ClDLiF43Vpa
uEn7tSwT9i9nQakU4qyzUanOrhamfD8qYt3EW9kukpWYIFpPbstuEVVeoE9chuVMtc5IMix50TvM
shC1QrhgUwJ3Oa+v2a2Ph7HGmc3xLYum3TLN0l25Na/EPpUeA1v0OP9SbLvU/MxfuiZwjRX6rP2d
GkCiioVARkex2jDlr8MFtLSxlFo+T6ySoStMk+O75AynzuSVhpE2+xKr3VTQOZUrM5z1l5JcTw1e
KwRg1kdwVNet/wlpnxPr5HBXkOgdXJj800E6GCs78MNvK2JAmjT0tLw7X8d6JxgywyxK5pMPeDOR
a2HLhM8708hEVhBgpRVnsXf6TnT0qWstoOrvVBDXMmQwMJqO2bMe+eTmLFVvVUSVv2/IhVbWG4qC
CEk4oQP5HGEvIoV7kQFiwcF0QGgbO+Gd7LH2n5ZHf1OxHY3R10MImQt/m+rgXOnunL1vhhBMWg7N
PiOLRur+LWOFpRX7bOqmO9h7lwbPdZPAW9EAaI7tdvS3IxeWHrXv0I8gwYbSHLyztkpIKZzpY/aH
2/f/vi7m1JMSkLLm9jRhiAG++izyhaSl+qyTAW6z2fzaD8jyt0WwYWXzK+QaLVeJDLbMC2OfyhBW
fLeO8qAK1Lu6c48bhx/BioCbq2X5eEcvjQkMI1hQIykurR3xt2+D/OW9ASHTzxFMPgqZ6rNE59v2
WhweUu/GIg34l+QD5x5nm4fuyatR69m/BN55deRyHGgHbwtYhWudcYMz2OK34sTQOEDD03LLroW3
x4aIJvN967IsoqgUKe7k9npUtOYloayPDb94zoRNFpcV+W4JOAFsKWsCjskG1DsPhlUNtY5KQHSZ
xQ725XRyhhYiKLjX2jUzGQ/t6cKpWVIfH/OoGDNQzo1d0bzu0POE+cU9CDvU9vR9JZCiGbRMKbZo
g2W/YXZztYsBcYBxQWifm5wlh1bvmcytBxDz0qBt