<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwLi1JUgi/quiz+G58cm+S+FKNmlJ29aNe2uHzMU/TEHaRRBJtB3HIsJ76yYva2j5ZugiD4h
oYr+72AK6rQJn20Tp7bdUA9pmlWYyyuX/00fv0QSor0S7v9G9QrEQK3qFq035B/phPURAwExjwrv
WEcpcxXjOVJEUf1wVnnHnF9SFYKOZzrQECUDJtSs4Kl/KFz0+QLzWwmhEvEl5NoRinSVTQT61eKZ
g2vsIxgEWgduNnPmOBDwSIev+/ZO9hL4RkHtjCCMKR6bkbsUTGKYa1SzDizaComWefjRANVQZ1ZZ
B+TyhKcn3QHrfgCIOla/fW25sWgk0+7UPqjlnVljjt3u2MjNCb7pSB7blaY79PJYzZcINK9O8qAg
zINyICrvrRspVG/urbpqlQNGZzDwVAWYO/sY/HksqiDC6k0VBHMvWCRP+qW4A8sv4KBT4eF0zNwG
8SMEpUEtNRKLkr6w5u9TdBI/PJtvRmTQ1Vc4/avU+vcM/wlwA/7/9HfIJcAyI76OkDvDMeMNxyl7
MCi3hIvKd2OtKVSi8VKApd01Xjzo76BREOFQLguofP10vhzJZfVsLCyY+CiN9JqsM2YwsdIg7m3O
yp25S1kRT0hWECX5WYPQChWVsGsEX35yUcqPFeUyMrnzQ30wBprR+kE3vMQLJc8npmKUbeuPgI7r
JyvM7S17SplGeH1xNGHmI7EcEIOevhg6NEGPGVorzjCpMIcwV91iBmDh/SQFTZgj2zqUc0ZuKhWf
cXNon7Iq8NVskPq0mgg5OV2ZJEi1HXCD5YEPw52jY+z9+qDwwDUSbPemdJUDUCRkTrrkZc8pg0Li
mLNX0mBJZoQJa6m7Iccjbw6xEtQHhhMPCvVBkjJ8FlqFCczy/cm/lHgzmQtrUQwiLMT08kgc4CAD
OVfeDRFXi9lWTs55g3gM4mUlw5xfINl5wq1Xl2/8M3iwuSc2nK/aovVDcvKEBWkEwPcQuGuIUTsk
OJKZom70C4jSV4/n05fO8cKatAOfDxVxZEF1nM/LeJMYSgJ9s0AaUbN9vfSlThIUp7K1TXhImO+7
dDGXdaLltHITLnaWTvd2rhSpTw+jeXju+2WU2t0uGTchydpU+NE1o7xTLBl4TKnBbAStJvedWQL8
Lo3nDeB7NPbV7vwGkBzmEKBXlmXxuKmwJUijD7rJsV2z337O3/cLBW8xr9t0HnPntsCkqiHMNsCs
sZwjjm2kyo9p5H0ZkQTL/wLkyWwLqQNCpZKM0d68bX/46XKgg0EkGMWLE6+CK5Qls5iQAND+khwh
KDdu9cOx2dNtdC05gXa+qsLpA9T7koWXGJEocqoHcilSfl8pXlPR/8gQHrElpTr9/yV+kOzNXX1P
AVLAslhoZX4YM8ED+X8PraW9qjxZ6F5768LQRHeaIE/PcfqjS9XTeRS3N7cUb4FNyRC7r8nfChBz
VqqAUG/c6r0jsu6aLmWtXoix5/HokpXhD2GTV/67ewqLmU22RNDwmV7yK3VNEvB7Xx+5svGtxK/N
u2PaMLwvalC0our2u5etwLDD59NhSVh7Amz8P0nNMqkegq11j77TolYpDmcFsC/4zBkO3SkwVrlM
N9l68dUNzqhzLPKakEI6P1O2TIH/H62eJlbtriLhsXh97UEc7sk9bWDp6wMNXr906mgMMIRmRa6l
eHHFGoeMsTCfQ33cC6uxPJtN5n3heEXY3bw5zTnk2MqzilpuKSV/RMrpWVZmHayKwX07HniEUkjp
ajLEs2y+zL6TjpFP+qa2fA+AL7yTfCohATMjj8/efx1YbIMbnOrPsfdtYrTbJuhIhZZ6vNt+3x6u
60/dg/skHdpzDYao21OECeDqf9ysLj5Z9hj0YlY+QrkQNFeAeBuABMFPh6swoNej0sboKEmngLlp
bnDEj1OvZrJ48SxsBLKGJ4J7b0ena/ExQpjIo6nituP6SRIW3KY29PGuZT829fVIb95FZekz6tUE
ydaRcEuE41Yaur3t+PUPwtWeM+iD+ij7KZ68gP2IBHFk/FlEXPzwe58B6cmlc7pH/fCwPrVyMif3
9aX3lNR8m3RilW34BgYpM4hU5I44ykdduXMTu3d53qVZfBBvDgxjeLbHlEeUfTIcsfHFsWzacrIY
7QAf+zcfdEGHK1lyeooFDOAWi39tOUB4dJY7wc98XcGXM8Dxfi+ColzCgmAdeKgoX8TEvW3Lfv29
IiBsQcKArW7G94j2f0OsgRo6VlBv4LZsW7tGe8Dj0euczjVpnIKG3VwoksKcWkHyNWes5rlbznYY
lkKRKCLF6v4b08uubxGJvQ2HY/H7HEzwBTr1MYsyPzGXBjTdzxydtWFEKmqpXkwvYCDDDHq/EFz7
GFNMZ7Feoy3gDhuwwsHgW0BGbIwl/lKA3CJwpQPy3F6r/sE825SYXi28QxG25bfo