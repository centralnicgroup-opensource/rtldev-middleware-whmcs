<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnnwWkuHw7R1xBONpGJHTqBc3S/vS04UJFyVLp3HzRx8CI4DoUjrYHQXV8VW/lF2phj9TpQB
2AEnW9+O1FDY6Snr+hF2LRzNytJ7yigt/NMFV2v5KGnfHq6LjPWJyRoEAjbf9lC94OByLaRJ53U5
/S1I+TCpgHOFeh+gvGbmXeiSaSV3uo7fg0jdR0y9be+ycjmvcdI3xhwQ8rI1WLOS75ZhFI8llaEf
sfFHB+EUJe1VhOWRYdi3VKN0mj7leh/WKhR2QQjUyIcPfSzLb84c+UIdvvB+RdYhW9HAkcqzId5B
ROz8Sl/f/vqgHEdAEI1qdngpYjq/49EsYWUObESP/PKLPctgFKp64BqSl8/eNnM6brHb14uuNmJE
h9mw4EvWJRWxDFuDcVjgLUNtHkOS9pgoq5LQnYJQexCOssctYRNWSdDA4apG9n9PI13uEgZ5Hwht
Z05PbIy7m55CH4yusbUCGP38++4YASvW0b9mtWJtPOJIh4lp4qTiXfCIoH5y5aoOtogBRzSj2393
VlajPfHs4re2eSqxVBULksVm0/eY9EfvsAdj+rJzMnX9h4WF0AbOKkpa60KCgh0NGZh0hgAZtbCK
SZTpL1IFI4ZsX01DPO6kHB1HtYkJW/Dst7POo1g7OyueN2qsznct7q1eJaCI2Hulr4ccyn1B1jgn
0EvUGdDqGoF9lLtiolKnTUkIPaihUd5Rku4rvvW4EQCdmaWJKJ/gzd+z3/vS7tfCx6OcLb3geCfb
TH3nhVuodB5Eu4E+Y8exEcMDR/TP+Y+y/pADUXyaaarLNYsZSiaKsRZgSYHODfiNgHspx3YjAkUU
Uz7OetSdq2mbQcM73MI4+AsRtKDdO45sAWlFCTVVeniYYYcMH0dooukf2vYAme9c6eCQJfKwEIGq
8RVMGkOvogH1nj+4aAAhNALWgUSxeLR6NyAuFvw3ZXo7DcZdXQoUDm+xE1oRl2eZ+DwTTPMxKMvS
IE0wCA6fqRtl5pWxOoNZ+nExRLdraBzAWlS1a686Vck1OSHvw1dgpqM7oMhdQ74oP9PCKddsVtG8
yEYHXNdMeGTbMmjIIHcOvZkzYeuMTxKT2Lo9E9pJPKJo9sjJjhKI0ESosHtOxmBER3CQcwR96ILL
4aWYx3Xj63c/yhSqdiGo0LepP7QjK3PR8JedfErRi02hWl5KAdynuCd25P++Me+DGkhxce1COEUl
+m4Z/arsO849Nl5v41EKAVQRZ1XWDF7Ducu8xuzERejHLnAapmiHhEslRjnhT472miPNTsb0Ds3p
dliXjAqAMAU2J9kw6gFHWhDmEZUjp2QB0Fh1Wt9PnJKkgYVQcsfz1MKiWhpv7FzNFN9OcSr4WEtN
ACeV18knAr5fW7E+vISapwJINARiWsQ9PyZJMD58MsWLoXyiMYJhGj+6I47ASqLbaUWH3Wka4Cjw
byEz9z1OkjcwScqWMGClAE74HVNHxvco3fws6s7VaMzVzGQw9sHv8uZLr/Ztg0K4x8GGmI0Bg5v5
xupSJssOnfljZ5zmKitvNLCukJR9K4vYqXUnDAtuJpSrhCXLbbXvMKnLEcdOCKc6/HKerwOLK66p
7FNaGaNKpkb7I/ah1Zz9lfP8zScxxTmfgfRop3+NJSq71lJenCjJzP+NK/BAqRIzo5Y2eMhpAtbi
krWJHis/dml/sXVF0fUkFIb4zMnTuG+Wb3Pf0CUe27rT47KSnaB56j/DeItEe4vnJ0WPTh4ExaKo
dPXg/G0mzp5mzfj8exlLkQSjpsYnguXLsRnz2lINpa1NCODC9ZNiZd1kjiSB01DtNus5O3VqCJOk
cC3vBASOSMrq3H+SraaJOtcOFqdsXdmEKCpFBkyHRFlGoxoHm21deJ6REHLLrBA5H5s+mNnl2uYG
EPjLWuBqsHJ4i1UOjcbQjV8Cl/3lwg1wAZaBvqjgkuB4wCu1nLvEI8iPHMaNEVEinAaA0IzCYGXQ
mo69vw2czCM/t10n4+3mLaerag4LEEOLFGPMWRQPPxzBsHJ2XCLP2TYmnDIrHngQ15m2sVsSQ1By
VhYeMknfQXKq0Dt0o4PbowneakqiGMlzuqo/M8pylISZ6iCOlLzghKsbu0ixxWQt1WNs6rZtuSqK
n8wblGEfRCMFA+3ieQKUxJu3giEm1RTPKlyNidxQiCZhS2dWRNJsLt+FuBfDTeRNgCjvozqaoT+q
NsiY/Gx8+W4VV1yZeXDOP2jF5/cUM1CWitzmDd5lkb9pD78OWBddzNTvbHQt+sVkw6J0Me1yZSxE
zw6l7oM3hGHlBLA2VhnFMuyOl4Q8yUAXVejHYdVVIl+BxKZuBn6LeFVqyMMu3koVTR5CLxku3C2Y
LHrCvtOga8AFahLOYN0hLHAlbUZ9aIqh32uG6tPBjLLPGKfnryGCjUqbTb+aezjo4wdS7eWFZrNf
W9raW1l+upiaFiQ7nRGAZ0rEHNw9NluGg6XqLCRGDGxBG8Os7GLJEszlDMelMg9Y15YSQSnhBSBC
EQLzn3Eb3fvdjbqKuZ7VlNtheIpLu0wijBa+f+G/AQ51CT/+