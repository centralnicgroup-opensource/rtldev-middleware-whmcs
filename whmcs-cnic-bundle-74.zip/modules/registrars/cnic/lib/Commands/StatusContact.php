<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoLQE7aD285+o9QjMbmVkaG6CPIRQQJdQDjoJ+Q9SAQi+v4MXzlfCWOPrwFjjpW2x1kl4sYd
sYxfXJVzZN8ap03QupdryOtysFbG1MMst2Xebx7aLabbZzDOFrzODSjmcVlaYQ0j0pYg24eBNvs0
nFgD4f3kw9YL3WqxtiIpxXOSSMN8xnLGERvmPoDpjaK64fXxOKETZoEB3dUtLi6Ce0qbAMEs1OBX
tXZUSM0md1xlQXAQ0STqeBN6z/8rg5YQ081oNxJ35b6nfRfTddK58f0NFJPQPRZcz3MfirjVfsOO
umQd9y/ptQwE5E0uNmsi0q8n5C7DudGtyOSLAiVt43QR/JaXxdl1HkDKMLbK7EDFid/Op0CGpCyN
inW4z4U2JhEMj8svOw/yE18obWocttzhcQx5/9rQxo4xRdcj0pSRvkaf1mAwdW87reGdN8fbq31m
7vbT5qBlvymlhN1hEMIJB60vgXhLxdXFqh6sPGOginvrhMXr4s34TSXSSEIkZj5SRMqzQgEEneFg
zYlRIBTxWM+HPpFtgmBSdCsamoC4jZAPbiSsjn9aqx/B7nHVgRXVbmE7RpelwbZQOtsXoUkoBymW
8+D+TaHkCSZT7QXM38Y+NhSYaE5NG9paNEBmP0ODSmb/h1GnK5jMe9AEQPPprnpnC9U4hJ1ZpJ3D
tl/l34bsK22B8leIu6QWciUu94k5tt7qU4aGlB1VE/auhvs4OC+FLzpBkKfxt5gH4HoGvmVz3YWR
AuSfaSyYhb9fm4mqlLF59TmuaaBmn51TLrIXzcAzNqFOzd/Xrro7ud1jCr+SGWqPp6VFfGPseaKN
DXaudYphtgSOx3ku6wsS1u/dlWPVuNE7oqIeEihc945bG8T4tfb7v4Od9X/zpjD5lDkx3pUE6NUs
czOqdOyhb1P2gChB5fhq2xYMbFwqNwMOD4GFmba9pJuqrDYurJkaoYYPX6Gqnbh/Hl2uhC4NVMLC
FZJRm8QmN0sQAGd/HHzMWgWotE+35ywE2UoskKgE9kXffCtMMWgOG4SGvSfMdTb3YBjU5Lo8wHLY
KELytazuWHGgow5etg1fgZlQIm+U06j9GxLCHiyaGGFFNmcsBfsqJ94i2GL/EufroEnxDSttwAEW
WFX2Cnngze6gvznSHZuAkFv5O5k0mqspCcOQ0GOLtnYpHkebWzSml8UL7AhOy1et7mplK7FS5e3Y
kZIGo8CGxFixfo0MSr6/cHR9C8fKfNy+pY57L8KCWQPg12c+Ksy+IkYBPM0u9an1joSsvXSIoQIV
KZ6yWSLC5gHsVyFeWmfvnztHqDm8+dO39KiLwBib1nUeqjNYQNubPplh/JTzcFNviJ29wXFJrn58
aOqPOhjY6xTQDrsgLoprnde9mTY68Fs87sPoImdToZIyoREMIiPQyk1d0Ze18fhvN0HH7mvEdFDj
lGH5Ys8RwG2ovGMeb6BrhH+7knpgTuYT5ER2sN1AGgerk+c0oh2NpK1ZxTd/wHfUKbevBPW5cYU+
o19i6hck5ljhqHll4fxsYMpSjj0mppsgnjEZ38NAQX54tAWc1PYtJHuvdcnTsFlxOJVZepQip/6G
ylqzKK1HN03Qj665mJaszu9t5hufPv3FaFqz0MOPbpAkMLJNJLPQMF3rhsUrjBiZcymofVmUWC11
V2SJ/E1t9Ss3EqiHOcEH9evgwKxEgzoqIIuQLqH/NZRc/IqCxArUEugKMCZml3+KrswkZvFDsg04
84Ywix64f4d1082I0jn/dzX2xFo26x5BKFYd+FKmjZMwrVxRb9ziIJOHPWqOUUHN+iQKWQEGuztF
+r+pSN9Y5KMvMPae/fsflN8g7ylM5FZ2Tk4xWrU32DjhT+TZWfmGAfEuWWePDiELCCb4aRlexxHJ
6P48QRvdPheWrk++oyz+/gNbxh0tX1wNU9X/xmn3e9ZCShUnKHwtd6syWLZMcTdX83ZGwxUCDwUE
mMWixSZbEQxIvkLRLVFpQaaHnkhv7gPbQWEo/55XGL964q20kkI8zu91r8GhPvA89re38fSjA8tP
ywpUzJLqJW+erBnfxJGLZjaOjBhRDfFrZBvMRwuwJqwvkCb8aRSb48OKrCfeln/Z2dZ045ccXWli
y11VyfUInuUoTdj39HSokqnesSSObFgAI220YpMgigr9j+kWGdQX8XZk3Pno3hc2uJWGaB94BuGR
SYWJ9lzbHvteci+34pdz4xZMI8wVK8TDqqs8XXLnH6GZbvXGL1FZ6sAYiXBjAVsHVdXIQtLvb5o2
NRE6rQ4MntI7G9q9KAQKkLUGoJgaDk5C/0O4oY15EbVtEHGQELXAPKi4Iwaj40d5+lPwEZqNQ1aJ
I2c505UKSWbDyxrLkHsA0Gh8/OeEpnXle8+8k+ao4lvZauuvK5lKoufdPbRhz/Jd+v8C4nlDckkj
YEl0C+ks+hyGMtODMaagV2YdBNcwYbUJ/t52s4VM8r2KxdR3mlP5AhaAwoJqx4A0RejQ9MqGzaSv
Kt+l4DDVg8zqohEAeKFDCQPwilHCh+aEGkw0Uk5Au6LwM8S/l150KJG=