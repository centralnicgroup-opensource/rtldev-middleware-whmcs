<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPooeGTT7FheO7cJKz4Wv9+nmAaiEHRT/Tv+uWyZoTo/jBa3G1+rxRDwZWpUTOKs+5eB+Xwv4
jfItHSHJUZ1orRk2m+ilW4GbwpD8eAY0oozEHIeUPEI4fBxbL/zKg4XpNRKMDuHmu1AWT7Zmj4kJ
RZ53biOYSt6ywdH/+XweHwZQp8kpUY7XhSHvdH9j5fmpovMaCI+yfQsuR5aAp93csCJQD5yIQzEB
UjHcvUVM2J1HMd9ymftJlDYHVY+6zuvLCitLgrxnAPcbprMKWIRvvAVdaeHj1rpYDykW0obY3KkD
k2Wh/pj9At1rRwZxoZkHQogLXPGvBPnPuojiDHkn+zwBQFw8bKvd59egpJ4CcsVQg7mc+rY/03ji
OgOZeXG435Z2lhxkHkWKyYyMPz7B92gNH7i1j9vVDU0xdq5II4JYOthOQR+/OQTwpDLuf8MtxZ5W
jFHKDhkEDJgNmywjGihN2bm38HXoeaxjyqmDFewfa1UKv16FBk2PUbQL092TO+8G7FCQ4LkWIeBO
nb1dXLD5hLX6t+OkLnMt8fk6Bn+vDJ8zf7Bvu0wRaa5WRmerXc8+EPTTNVIk8NLGTx1sKmlL7GOO
zXsiNdwaGDa4t+1q6havNKjwhEQr5BlFxdDLkVvqlYh/rmp/keujGeTb6fdD6R7liHQAJKzoxH9I
wCDGF+yzZGyRP/tYyxxonisJlVlGR97wKarThs8fXGt/5f2gYX0QbZWXx2SZWKSVV7bdSsOf7WEQ
bTCawFqpx0VlJsZgboCkyV3S9ZknzRky0+tzvboUmN73JkRZp35OrbNjJbyBZC/eAtky61h5Null
q9EurL3c+D1rRMO4hyyM88ASYE+32nGfI7o096sncTtYZddJMUl/x3QwXQchry3j020/9CPVCQ5t
BwFSPzEYxsped2DYjHpCkEogsWtGucKTXFNvEsvojf0vDDkFWuf5UcK7I8rhbuIJMRKTEcw9S0AS
tWFuJr3uXFcIoMeYgnj7iTosSs2PVw1qbuQEtLo+xxTrFkN7+bjP3THT4TixLiDvnrbavugl+vfT
b9Gq24pbGBsdonZfAMyAw7u1sRm/DJ90xkuXLu/KCwvz4GL4kTg2lQo2o8Le61wb6Bjs+Sgz3+uV
ZcCNEyfldPUl87jMkY5oK8twAQ+tUPvE9HcEGOKR4qcMn5vP2UHASkTF/046OjFCg6POhp9WkEWK
Oavc65UlmsToUPlPL/bNkKHIVE4lKuBwhyoNTx9ToAuR3dInqPiiI31+KF0vtz/o6iXvEuLLCWcy
bi2uNX9854skb6NdljGhtPtF/XUS5KJ1s9PTtLW4OiPMKjeP/+4O8hHTorw3/nwhjIOb4bvXfs6e
rsAaTUN1+LkqQnZH+y62B/Uk5n1f+PmCVtkbc53bOUyU/KD4h/qxE1lVeK2NTqsP2wZkII/8lZl1
XylAO2fycyyGa1re6cX1Eu1W5Tj7RF+UeDB1Whe5S3XIIBH009tBiewPB1ZhI+t0jwqXJbMX4vgv
OWN00qqoZkZFR2hXB296XLW2K2Kzu+3Q4K1lFtiphrA2VReUg1L03FzfL5t9UK9FKjUgM9Ei4Qk4
t//3ubbBrEVK8WtzR53FoMWJJIGnOEOHT67DSZhVm0kjuvyWncuLrYMcGWwZluRkNJZieDant+nJ
6s4vH8yTbJ+BSmTCYUXgbcpdDC36qz9XF/dS0ETwy839ScMTURTB9MbKmxehYKQ5qwV4tKiZopGC
MzCUrNfWopcR4/8/I2xNYR3rduyKmYMduZC0DU/HGo5DYo7Jy4sGkfkPxFju32MmvKwVPv/yHu5W
D2NUieID3qTT6NAVqxS1KJwNUI6dxn/DC44MThs0PpWT6PzmFtF2TS/HPa4oYT8VttaGh6kidfq2
lXNq2F1nvDf+KDVSTNpk8i8wulNYlXp/UeavUFhnoA/ZhXCxPYoYBhdmjKbA0d3INHZPC4G0rRUP
MYNjUeH+cImaRsyL02tlSRE4NaAuo3SNJvLzed7xGCzeyYLe7zIrRko1B5JMhMnKqLuA8BvUdVcO
t4mBTpJYMFS8ffsX9DTLLs2woADK9W7UNDtJz7Fu5a27CCaLHqpM2XE547iAn3XjrBTjK7Hkn9G6
FvGz6QuH4U4txRCIm6csbF9lw3DAz7rZ9AuodxFZyW59BW0FWJBuY5J8gakQ3g+qb57ZDx24E8Ix
PnU/QX9ynWpCU6c2hgpe5d/LMUO/N/TvA41Stl9u9F88X8RIayU/RBZqWErJgXTqqkluwiU5T4i6
bQ9ej/jOgQpZ0tWAQLn1BzHxE41V4UiAEaxYiI5AEAgdev734hG2EFkOU68RwNff0OwV7HAFNyCR
ry1Ly3a/P4wY08lGu1LaUrMt6PVukrD4MsM7xCmJRb0J2iXNfSteXEghq/ew1jPlo+4kIWUrBshn
h34d9WJm4tUf90tf44mafa9VnUZ13tfFGsUhhakdEVABf3bKtdueinao5nZl/tEJLAVegaoeEFKW
cwXRuAl6jDCk7WutgZkqwwcxalql2KfNa8JWPuDZ7l0Kd1/JRm7zp5WG+SlNrmQByliwSzOlAle7
MEvzjV7qNhW3G+gpP4gzbb6d6cDFn3xEM4Flyuy4EDsX2Yr9/t9V/Qg6zTFxZcEY3cA85b7X4k4Z
iCoWyUCYcDhcA1RqzitFrQbHpub5YHjDr+mgXYxWTlM6qJcuECMNLm6UNXGY1HixnDPwLhM4C31p
i0TuohmLaG3B4NvjwsKcu+AxU3BjBF2pMLDSZ7zz7Fes/PWPzOrzbyqHmnGAoHb9D0Iobf/L/0==