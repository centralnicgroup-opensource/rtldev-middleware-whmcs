<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvXlnZtK/oKwCg6ZKnuf1kCNnUlSp6wLxugudU9Cm0dqSraQCTTN5rtgKU/r8x1HcSUK24HO
HzxSxa6hyMmwrTJxEvNmQEV5RInJfsjJNQWnzAjrbE3YHZZ0EabEErDol4DpapLvoD0nYr3WRcYA
SzQ+6K9cEbp5Phmlyg0tyIl6jdACE1pK6Xt5wCy8r2FQ8q1RtgFMb8lF8Zlcg7N7qtbFtMTbi5Yz
slO4eXLOchHfX2NAwFzlfxWB4LBuzAAeWI/xjCCMKR6bkbsUTGKYa1SzDl1iTr7Tit/VvD6QNHWJ
NkW8rxdQjNhQUjWkVK+61T8kD9izpyMwHjRULD8Ysunw7MffkPh8vgU+hzpKDQpq56HuyIgTnZ+v
qKE/4hjFYDXbGrZL4SBHX10P+gpioBLs5DI5j9+au8YhOjBjOUT+XTUe3+anY6DLjhfkyeNwrtnA
hMv0t7Y9TJ/jeckblehhByc/BylZ5HgaGaI76GSZJMPHQB9wKWQ4y+7o41urnOlO2w5A6K+gv8U+
9N/rddP9fXjmNwS6B/lCwRP+1euZNSrZ6B4Hu6/QarrQQlXMbOBDHMuhwsI6DGCSYFPT7Zw0y+YX
B3qwrEKbxKzIcxemzYCjf+LRmHLtxvVW8PsvJ0ZpVHLy1ynL14B/eNJ9u6KZy6Uirs/5rYlLaKfO
HXPctMNiaQE/3ji9yD0UP/nueda8Hxj4d8qiDkpgB5Aj46Rj1Bv0wmVPckVdYBLTatwAkdsf1GHe
Tj8ws5ru8hB1FfRbRSE7028sz7fZ/MbSCW4aBUOrwtaSMlJ6CNw9qNT6T3JxgbFaAZ37Z1Qp4ioU
Af3lQuNtiH2H5SjKWv0Vj8+qWEpARGikeQkusw7KnFLUW5QLaq3KxtFe5QpOS/iDfGYUlbQa74w5
z3IzY8Q0HvTMN6+BXjvR98cbQdjdxF4QvaF1JXfnagVq4OiqDghNWh1NGm61rkEFCCrV1vLgJWCV
O2sBWnwPIFvfQl/OLrriBXQeP1mf9EyQh/aUCFhaawviMBgebl/188a6gGwor5q5WyDQJTQYGatK
LGPCOIvGFvl2wEFtpjCRcXgRqVhgtpV4cUFDPRht1wUURDmDcKi1uzPW4KFn3O2U1ka6MSiwnSC2
b04tI4OTS/33EiEG5Y9spdY2AK8XXlz/27SdmZvkL6e0Cz2ZbWGueNEG56Gz3tF1tItuHKgGzBQd
V3dPqhCNlIwBrQmXIgpl+Dce+f+7nev3tkr1tbWIL00I0sf63Y6vJhyl3PvWo8DWyMOvyX1JzV79
a3POPLknAbFZPFyGMkWzTe1RoXUCYwp/gr+j8O6fKkkWXqrvdVP6/mZuPAmm6+XKG/H525vzokXP
uUkE2caS46ZxU6t2lxDuAyf2bHwHRh/MurLydHKpaorO7qTx9EI3IqJSRjQQYk5UL179Dzw5OTBT
XArPDklNA3BAs0b8rcrl3IpCzRJY9+qilmXEmDdj48TXVmmxtyjERb82Cht5Ha+K5b96X5MhM5b6
xzEe5vPmFvBfpPMN0ITj0/riEhj+Jm9uaAFCORcrZ47iIB2hqliE3f+sn5wh7Neh9P//cvzIbT4R
fo4slsHaunt9XycUCi0pB83kan/WplpfnmkkJBACNZ9KdPKPqaHf/T+CZjiAXHdIo+04IfbHghrQ
vjCIH3JS/6V1T7d5jVtUJufrbAAXBDD19L9Ptf3ejT1gkE0Ba2T37ivXihfib4wfAjZCaKsvHap1
12hKRLOxMK36z54l1zanEG2cCL4JCM1uIv/0TtQWhDSSRj3ySN/OsxxNfd1+EkxiIPAH3hO+SqUu
2UJWNQOVjA7ArZtnG67umYCspw/DTo3Mg7fnQ1Q4omMRbkhoz+IPJ1CYWZ0U3cp9WR4dywEHZVDe
f8qvmDpwWjjVA4VBrmn54CsoenpogVFB/HJpws/XVdkkykimx6sPeImvc67sxez13QFbOavhHIpi
DbryQbOgWCojUR8q8xMLHyHh5spCsmzxVn0Mrwedq/z4EETnnjvuOPhPI/zD6WldYd/+8cvTSY0c
GBRFRPiUCYZBDn/gZAeBpulT0MxxvKwrJuD8M4CUEmj3PZfN6jsW1JFVxCswwMK/MndrsDG7/Qc0
Z1vbcJ1V2R+tG6lPJ1Q5ratbfz1aKWW0LLiz/iwlKXav2k6YUuoKxczJ4bSk0VqxRy3aROWMXL2e
/PXxRflMwulY39Rne9OqotEMkfi6g7wuFpdczfvPmJam0rnssW1mqoTKxC3ESRCd0GmUIIT6p05t
EHXIkybwA5vdoYfYJkCCquqsW/oA0sO0tAD7sQXMcfCeqnDpu5rZZfpXQT8fbh3w4iphXcos10fX
NCipZ4FfRN1SdLiwwWSrdj7RXf8+6mvsR1FZPKZhWCkM09goDDl3idWwCYMqQels2Vd40GCtssP/
6QdQe2YNuFHLT/rOXeMr6mGM8Fmzv23XCdtU1pcqBXieiESdr6LnGOQ4AR/lnrsskwL3VeGuT25t
bGD6+i1qiS9Y284OmUO1Fl3AmT+H5LgCVr8ZjpvizI/1U07nfrYsMtRMAdyQNqAMd6GvbzohO+j6
ovgsbI592AWRSzOjQHQoYSuSLstjC02p/6yLV1Ho+8ZS854Tn5JLeDOqMPx2HhTRUfNsIagdlZST
vK15ZqKCgm0uuprufMaOnooEdhUAK/7UX/+LTl62rct0Rvcb+jSnm4E3e3ELSU2cKWCpjW8H1oVj
1HlMFbgXxY3ELrTcAH+K2CrgBw+vdpySZyu5zPwpuBfRJil2Uoth5kytsJujgM2a9zi=