<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw/8VQp65KQ4dtdeZuNclUV7KG2mcq4u+i9S1G+m8E4O3o5pRRwWA0dFn/DXC8nix2tmw67Z
feTo/fp77ECYBRbPGOJiFPhJle0t2EirDeT0WGAKvoz83KxVhhXeDTVhkKnP0S2aYiisTWtaQd3a
k6IlbbQkHcEVMwu5Yw9th9P8WAkoWp4p3mfEsaylzAgLAKX+iibqPPFLhzyBImbmZbAmALgPwjVd
cV1QCYh1nHpAOoh+aC0HGsD2yojst4UEnTHVTBJ35b6nfRfTddK58f0NFJQnQBGwTWtznHud8z8O
Or+7RADcxb8kQAO9P5GvC03kkRBM7bGaPK/lvXjht9HOfWPlTQ8uxOCOUKxTRqNKdh8m1UdkOCos
5wHt0Mgn76cBOy20TUk1gJBCDg2sh9sZRynRVwxv+eMLToEKQVY8Ekv1fLg+p5lDrOkyeRIYudya
vXtKB+TIEeRru7o7yr92O3sm0O9M0YbUDW0nqfUeQLwnoAMfYIR2/1x1LtOJ1VTrWP3l6eNjZ8zB
GfRdh3hAYu3bmYe6QuKsaBT38PHmDptso+v1ZkVrttWo1U4LHZeLaOEjyJZrPzD8diyZdHjoQlG0
wJQL9+5uz4VqbeibBXY/VcNbL/k2OAYqQkRdL37e9CMTRm8FBAnyKDjhUtn+S9sUaAvilCjgJ6of
BHXOeKh/Dw0bVriwSPyKFy6SZVjVkHXREPxrv3E2VvMZ+K3YfjKNMZQUhkC0s/G25TJG1SMRdCGA
aWp+vFYldB5H8+AkYxjldz4sTQCwKnYE3oVxjKv0c7FYKDumJWG7czPIVaGAaVW8YfT/xVoP3gUG
DCh6GTgvbYgG7rcrIZlHI6aqSjVWyhaxcv3LlJguH+rjbfx7pjieRxEhrL8kAXMMw6xY8U1Mg+8R
ymEPOR43iQr+BTmB4v/x/D2fB9HUlfbuIYAcuRtdTgYKB20SU2zF5fBVo8TGGXutU295WNgzVm8I
6MFPliGzoAuJLD1H8jDl7IV/5gy0b/u/mumi8MazYdY9YoR4htSCJcrF/Slzlj6qMqYuruzH6NQW
XjAKOuo8AXt+wWVzwW6Mp+V38rsB7GsRsZt8gzDuJLwResY094kFMBO/cgB4TvmYtaHoEuJs4DIn
/tAq++9J/WqeS28Lg8HDUaYVSo5IBtFd1iQo99NuLfDEazc9AbX/1ljYUzu1jAOxobhH3ogYMQ4D
8t14bRv7kgXdl4ejnMu2QeRZ1JqtShy7maTnWq35VXo3ifFmkiTweJInENIvaaV24z+XX/oBBTMS
WVQdTu7NvozSgqUh5JIUBgJD4+qo6D4UbfG+wE0HYp4hKJ1WlXEcX0/y4tcK1lyavgGoWXtnaX24
qCX5vDmV8yfqGxv0LiXCsgJCjpSvZSnPgqAUHKv0ZEoLD9/R9SWW9qk31+B/XI9hKoesrv7pWn/+
rgj2zdN/UOkFUcLGqvp3WKHiQU+HMT0Qdihm+3unATAaaPkEEeeTolsY1mLvIUEVSCI2j4eXGQA2
dcfJyfyhTmteOgiOuu9TAY/m/htErv3drBFOgQc44rM5b3B4Iuprv3E1I8NVYMtcORv7LAEXMudH
qasaGwBCadZREREGy6D9YlyL9HG+x+FRhqb1Q0VefvAq2fuvaStgpBVVtk+pk1lFYbKMSjKD4dkA
jTagoWdkthxbt2+FqFuUZvLtC3hivSY7htC73NPFDszErjlCC0fOmUVCldSrWNm/cxTWW+vYZqKG
2IJx93X4V1htmPTGFGlIG4cDs8TSauSETxOSBoi2