<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyuZHwJf3BoBz9BIXxa0w9ZiIjlkV4L7t+1+T8ITd+5z8QL3dbxpH2/OJpSHOG0lUzXubmAs
iaujs94qIMJgmYNZjUlu7YneN7KgVUrtt5zVXpVvRhi/X5ej/1GFNQAXL09ofON0clKisM5vghZS
zVAG5aUJj8ffzlRjKdI0k2gCG1OG0ojDFXO1TS9ZfM2g4oLajlHoYCp0YZbm7J8mpWw7glm6UhOM
c5Cq+LcMO8Y6JZYuqJ8Cu5PY1W3BwUlH8lmksAjUyIcPfSzLb84c+UIdvv9hQjniZltBcia7ZJXB
lQT8GQlDdDZinjtvh4Cv0sVvlKtudotki+1zGGMj1Rau8qsRJs7dmmJUnNELcdxXQeWUlxlKIRAO
e6azHGshR+hRCrHgQiNugJdemYKgE+qI/RZVN10TXNKzNJhu5SDPwpuXd7tOZbjg7d7MDwGgoUh5
YFGVdfPWuhc2iNjOFMcfGMV2Y0P/JeN7UdVPHhtbnrEf82Qd3aNVJTPfPf5p2lAXUR/7WfDZcWPe
qDNr4IU1j6TJFw4HLkRMaGejC+p1+VaUAazZoBfVzmplcDGoQK0VNG9hm5LtpgRco0k6hH6WbEJL
jFQuHTAVpatWaBCm2Vo2tqCi6sNOMIk5jxeT8hbMWg/0dEDmCG9PWv0q7qsp7eNmAbX5VMB1g+4U
VJ8jBVOhUT8bd0dXz0h/vTy1Pbu7CpNYnGOMwJ2GMJtDEfwQfnybRPsQ8Q8CL8+W9T0cIrNtt/R3
dLpHi55QnmrlUbZcv8dg3kk39REMn2MqVKchQxbknwOL9J1Px6jEO3W5QF77ptznLe5xoXxNAiN7
r7W96I5eHSm9Abl4+WkSTQDivpTfS1VKIEFkxFmxWF0jN7C+E1KC8qMi8TQRkQ8Hf4x0EDOdQNRh
NDZLIov8QXtcbbE1i66w1MKY0Hmx7myKgocpHiW+gA6ywpl6XYQ0ETDbS5+kgyMUfzjsw5dmiJ4Q
qZP1h/t2wedBBW3/U433GjEdJOyMrHpzBlGJszOddrNq5+bQwcVUDy4M2jMQgTRremSbLlIccSqJ
FVYiqe1TUYn21pgs1R27bUrx6DJ1NlpblFn7lGxv6x3xn985xfao5vn8KX28cu3V8xajrCUaqkGU
t//8JCTyh8hgw/qPzIwhjXrhEsqK0Fy7CDh8KszuAx5zkUu6D+2cUGJwo2dVXPjBU9D9XkO0fXLb
nKd68Dn4oxF5JI/geyrjxrDjfFuz6r6HKdbqI5xsAdOzMuPU+x2zUxfltu+0naiC1pVUm4FAKN1s
Jr0hdbb2I73FtLDwvqgXlWKk7MKGAIjqXOJtPTAjTC0EHDGjFwG+UF+8C9Y+mhjHoLcy12iPRi+E
iBs+PuSXxj0NWV0IX6eOSiEV5NVOo5Lnaik4nHv6mzZTKTAhVcR2px1hxa6UKyfSoqvf01gcTr8D
fLpMwQmnWSPsOQ8K89X8AlTpOaHlCz4oeXYd5GPEQrfIYtfZDYCoY4bp0esF+D5lyeqY8xxkWLX5
ZZKQcPrmAYehOX4okeJahvvdUGNR+r3hDMpvMzaoxBYrsdwXSS8lOpGZLCxKg5Koveu5FeHvN7Ge
jrooheaoMIcWR7fWd/oVSPAryOG9DVL59pPBccX2moKfqL/wDUO+KxbWo53mSeMGsD+9ZrlUgtjl
WT6FRkbWTU01JRCQEpv/KtCWivEYLqs/FjgnCQ3bzE7P26Vd1WuiS/VZYCEXqVrA6goN9AIJf2Uj
eqL99ALjgUIiEEhDvZZeiBua0Ri=