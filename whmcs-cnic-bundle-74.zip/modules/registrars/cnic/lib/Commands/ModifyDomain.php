<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpeeJPCheRMaCktOi45gruUzZ++zAqaAVvku+tEU2GDiDCDoJy1Ytm+Pifz38H2fmRoh2shy
d4l4TQe+nDupdK+kYBfvS9AEx1SmVaPuW9HA1SFD3K5xgYlFn0WRHxqQIB1p6mfKm00g//Bzfmj8
7BtWmSXEyl6pAK0WPRyLaK+dA7l67jj08locSA/ggquMiop6GkoUijY06POWyMmkzKt0PDuKR+Vw
5f+d4gXN6ER+/QaBoHfSYMj4rlDj9WX5vFzFgrxnAPcbprMKWIRvvAVdaZjgUxIogq49WuNeY4jT
rUX4VPJGUuPuTzJNZzYGS+0TYj1jdJtKtTnekcWv3+p68qqBkwrassMfufmdASmp4I4hvwF0U+/E
gXzquj3CiBEfaZ/OdiVIB6TZGwgXD4wDHbjT5/5Nk+UnDfmhDtU9OliPaK2c51JTLChXHdl4THLl
ZNYQT1lPTW/31Ea3MPs6X4nLWUcqunG9T5sx0uKSj/JveBtdXxi1L0SQgtUA1sKBxtw6Tq6PVRS1
alPih1ISiPqAuSyOWhjkykseDKBlhh+lhJkxsL2N6Y0fTyPj6JRjNCCLEalW6eQuUiibU6u1p4Rx
7A7PBX/1l4b9hVmGbI87eKBVh2OSz5W5QitTTCCjOyMUZ2pH2rIoMQhRhDrSU4kaxhtbJynvkURN
GpVM+VZ2ROqVdJdkxMbeCkGf/YQq3DIs4pMlMd8p9ddfJtpi+2I2GwI2whewYcrrnMNVn+UxPYZS
oAOPC/QycO8iHK/KiaBCqxo057hcO3c31lG1wwNDqOtWlV3vPEm9eAfTbowf2GTbzaw3+B/gqMQ4
6XaBZgkvp95hGjz5wGvWrvvJjDDC3z1e61PFP46m7mMT8DlRBS75mNlJ6ydr6pWc3aH2kUPYN/ZX
VSIAptcBT9HhXo32ZlsTkKQCnpWjHRVKtV9V6nqYzCnbuRWeYsx3SiKPY42P4BZV3vFvvsxru4Ay
PWqJmCHk3KSKM2/19Tt/B3MYnML6rVJPXi+DbUoWDYuP1MTBOrHdujKcOhQYQ3PXzPuR5a7j0/uB
9vY6AYGFLEn9l8N1d3w+S59flq12smyUY2TqMlf3AihzzNDUOqP6rs+AR02gYueFlYPN4Xp40fjA
BluDBLiMKOPmHoKF+NLE0BG6OIdiCRBf4SyFVSbUmkVckHx09SwEJdiE5HodON9H3KDr8p3WEwVK
1CnJlAkIyvZ1c1yqy2/zI4YeBOZpBj4Z5PK01KzNdvG/NctcgfB+EfspiRZnYNKvA1h3RJq9OmWI
kjtIM9ZK7bQDY0n45E8OArsRR3eVhoIwbAVFdiyEq5IFEUQgA55Ri1wUPwKZ/+R9Q4y1qYQEJ6FR
Xo5j8cfgOW2HNTyNWfoY/KUgKerRGyKrsVlHRfriAcAHz6JG4kZ/oN4Ouzhno52/A/6k1bnNwYQI
e/Pc4DygBeqdUsi6NMMwZY7ClwujpAW/sVffRejsPX2gFrrilIWBGSL1+VRg0+DAaP2ZQyUBFnpb
+HkwS+/rlm0nafyrucUS4gs3uJjG3PhqjXIveDrStyf5LzTWM/IsFWHiwL84kcrEs4WehBu8Mjw5
hp3ucZkvN3uS/G79L9aGdtt7xb8bN/0+3ooom0eLvZ7eDA8ueYlHhqYvED5PZ6xpt8mURd0fVJGQ
MLlLFmTYwwIq/zAAlgx/Ds0mdpyfdJI0J2sM8HuNeiEmfwlkIu25gDO6lSaCu3WIwqnp7mxevT9d
Sqgs3delUkBNWF9IDwmscFG+hDAcXQi7N3uGHB1cJXhDrLXb8aZA1bW+By0dauxEraMZ5tAcOxNI
Mw5yiosG4pw5RrwILMW48HzOkOXhQP6ItorC0nxYsUPVtoxH/jJEYlaEAPrFdEuJYMZlYzt8UL+a
3bqCjXyWeXqfk185hUjg7xwoj58W2BM7MdeUM7ME714xty0K30c1e7DTOyo6UQqbsteE32sG62Nf
eJ1wCt2zaE8ht0Z3lRS/ew/yXUN3M8vLLQDaZgzAWtzgEYWNRc7DO1uwBWUQ2ryoI05UKYUm6Ya2
nb1cBu0U9G+W3UISKuC0RQZbRk6SVXcS37vttW42bv8GyeP/qz4INvgeKX3ul3d7p+zA3TylQsuk
2ENzaYqXn9Mw7dhj3bsoj40uS4uJw2b8M3JjxiJ8AqDc8FhGTwDYULRdBzLkSNgSa9OzR4tSLija
mSFfY7oorxoSbZG7YM347d8TmYYHX5tdg8SL73apiN75nCnhZkuRehM7UFWhU9GwPIo1LpggyUMA
scozIY53QQctg3UGYD90jXoAbRbl880MkXDlZlW18ASRtXJXrFjV/4gIcJlitwPD7WcggwOgaB6a
mkW1K5BSgGflrvZQpQtgoCY722mPLLMzVYCsjByaARHzA9054biW6dvBKo3O4FxiuMcexz+2Zsvh
cIs/qswHS8qaiYDcBAtW0OQT6bj7gO2ADJZyriOEAfxekJjBgDxfuayCqUAo2qjDNUEPNLxIvK+r
+pBGudVIXEhfkHNhjXaXrFQGnH5wfCWj13su8Rlb02lyQWIR91kEDqFki/Smnnmj/ydcNLRT2q0Y
H6nUKCn6b+aW/1A9WJgpRp7Hjb/D2Gm4Ym4VhCzjoJD/o4S/QOruy+s1B09dE2n2Fod7RUX8zfCG
gN4fBvx/1SnHgV3J4cLcVoD2x4dM/0+e55IkrupJRaIMtMMsiH10xVC8RDDaQcSdFQdkJMD0aU/0
ofLBPCrsP3xCd1p//M8kMoln7kmGRHx0mCfCIW/pueQq/aVrQNcygVGnqM+zPWtdUIjK36p7xCb4
jipF1mrBP1GQgCSEFto/4i79aMFoNZJhVMYIyEWaQME7qxei0m/LsScN57bVsCWICZ3wzsdakKSD
1oR76tHu3811ODqPv5OxUbXxQmqeMi+IBpabgvMEVwauEzMa6ZWgyLfupcfF7w7fIMMUTgbHcVY9
z1VJ/G4337SQqNQdDXj0hCIzDBbVDLsTD2IYpe5siuNsZrzXptC9qNyaGEHzc9j+/SAYrb+Asc73
rm4gVKm0jsurOUQgPXAMnR2ZZu4AymUvHnFrNN1zA9bOcmyJNVLlGlzKcOcxXL8dhVnvvr40X7vl
6r5MPkH8kH1H80EwPbfUvvf13792EGfds+IvWqpcIpY6R1SbeplHLFgAeDfA2LpoBUlkWokPuw1q
TuZvQG/sGqftN3EqA1ysiQpJJw+Obn537R1BEQvU2T43rk3XQVd+AaGl+c2KV24n/lBznFxs+12f
tIVyw2pgUaeV6oC3FiguHpbJdjVixzgC51sDdKFfJkgCiKuJVlzP7ZawebxLz/fvGxVCqpx12EMc
Tkw3r7qnl4jPlJlI2us389swFf9JTQydQzNwbjZ72Um365CQFfzVGze6OdckrAFGNRp/Vmk4JxUj
kU0OhOffIgfm/fb4fG/yVzlD98a6UFTQM9b11GAeK3lzrRRIEmm2wdn7lPgVlSXnKgOtc0En4u6J
4IuDUUnkdUOT/ZDIjkLIHrPYEqT4nQnPaFRs3pUSGabIQddmybYFSP8mdftpNuLpYWwyy/wQtsXe
KSUTi9H726+FeS5SDlh9IZvAT+27eNfaiACeq+UaLhvOyADPS8o+FhuVavz8Jn7AW+0NCu7miz4S
sDh5J6hBtuHxQLbt5ZdfZiPiZwlcIoJKnr0rYF2GVuYw1obOweDptlb+f3MLTK2fnSPJTNu73K98
4ktFTVSS/TI99018I8fyQ771SLBhM7Z3FwchPfcH5hP9b49rHrcPk7qLcsI9yXo0ug6KRgiaVz5O
uUwutbo+cwzWTFHYA6nqO2U1cck/nZPMpE0v/MOcAO4d5X2VfxTET+dMMKUObUyRxFS/uRs4f8so
ZgrErR8URmoXe8a70UDRka6jcP5w7hJm5HTJ+wCvU+psEZgqigfG7y7VGE2ZFayh5mQuu5d9RnZ8
ttGxL5FFswBRrn64zpHrSZMiJ6HUN19j+x6bDfRetvQxmkbIwUhT3DI30EWnn96rDBGFbbOS97nu
1C1tFVgCYqI9GxEp6Z6s0HkzWhf/MFTCOrR4YMDM0g16oOj0HRfMdWsCzCVWDTaxc3/elEEECkHG
OuOtzF3BpgiXXpyfORC4gufwLSdanK1KHJhiOdliRPypNCLYG7Q3YFRQmASNkANw+2mpKDElpixu
GmAT3DSC49qrKvEMfAJgOED9zlKm9mhMQ4lSiLWNRIO3nr0Dk7CGV+t3hZq4gSwcx2Ykevabp1jQ
cy6oxmI0p2Sqo+Nfb8Al6t125+A23qvHfIhItUNp8mWCwOvsdqkxICWDxVCExaBkd/mCC8MVUxOg
EOHPALeW3d2PGA31l2jHaMmZNtxbzta+JAt2mabpIsvtvcWjDoG/+97EBBkLh6oXkEgLLGurheS3
Wcioe0hed75A6VxXGJKaieJqkUjS9+iOyT2uu5tYFyzYtoyt4clMaAf2UAYji5aQnbOzL9KA1DMt
mDJixJ9cmZdPYc0tZWnt68vMzCO2qJVf8VJ8blTRN0a4Ps28IqE5js2io6OaXqPRXXc6SiBm2gRx
tg0xG/h3XWvIl7oljAa2hlwHJqacvfrCKgeBE1t5t2IzZINMA/ozCN2raK17izO2v1izmIU69uo0
0n9JOSySfecEBCz3YsJd8O6Q1C7fLxBeBor5nHy5ax3H9vNTi39H8VoPc43VFbQOJNUM3qRmKWDq
0olJq8RULZjRpV7cmGk261Lee3csMJ8/DPRcKIXLoDm5WY66NTyuz3BIBy/1pTb4QhOLuUv5tLrt
wpKw1QxM0YKzAH/FZplzIUBD9s0cGI0czIWV2wBfqugGOw1YB6ZHKL/4pweQilqxNoXu+MlyXjKT
suX56x+PqsJUML4hgHFFJ0/Kp8Wdrjj3zIQ0saKIe2FXIgRRJMozwdebcZDB8ZaCiB8cNK4HE8t8
ar7ANiaKQPFRjm2nVSv8h9GsSigwy+2ffj2M5UbHuy3wSCSpzujuHr6LRJWvbrOahC+1e5sV2G5g
EPUWK5tjKR+WPmGEGNmsrGUBX2Y3iuCLCZDNeDq+CGSUjc91bRE2L0/udOMYJiGmml8TFYk/EHmG
GW1Xr6gQgBvvISZ56/jijcG06EfjR53YtfjvOn+VIGtLhpbdZixY3EU+jQgtGzACGObAsLa89u+J
Be/a6p0xsHHhBCfAqKssRKTaG3dG+DW0q6PHdyr/JJkM6yjgTyva1kgXsdRCYgn7YWypYhARN1/E
oFtYSrLG66qZwcl/xS3dRHtoAQv30ET2I+3zvco27W0a09AdJ48k/a7jTwJHDCMgbBPOX3efU4zR
5WOPp55pFPua1b5lOvAQUWT1BmolzUZEqdSzHggANblN+DqHt/CjegZ4APrCKEAPfJOByEWVWJXx
RhOHJmzf2yQnwPCgb4lN1qZiK7z733YXlY4a5C5n9GXcjLkyt6e2yoC+HSB9cJWWJOVOVoi6wXIv
T7rsHtA39K0e+a6XBfXHArRHDOmMUVTUORBl8SlkY7AmRQLCiOYYvKMrn/TvQe/adEgobTFH9MG8
JJfKBBrZbqPrjUN9mq+ouRTNZ1fEJ/sxVHUlnCuhVGLYvs1aQwSu+DNyRLxwzXn66ib/TeakWPaf
1mpz9Ifin7XjLVyaFf4kdMWKD21gbYI99aYFlIt6b6mGquBPDjUsQ+cYvvF1GiT9mjPf9r3y+Nq/
HBFYtIyNt6aBLUnJ1DrVq8MTdOksZuTt8gRrpesyHSPnDbKC6tcEFc/sAuoYKpxF4BsnjAq7SLFb
e1zkY9b5NtgZYcCtwsiRkJ1ETLPejN6q2sl/bINXV3BE0kt+NeoZI7ouugPPcllnmL5BMhbt+JXq
