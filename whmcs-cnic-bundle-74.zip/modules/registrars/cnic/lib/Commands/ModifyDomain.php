<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvlcatBwVsX5WoC6KPtjJg60fi78D8YRQfMuYRLzzWJ8LQY5NOXk2wHq9aIQr+j0yQ8WfPOk
MHlxvUIuSTGv29qXIvg2qXmX1DO2VDWUbEferj1aGR+sHhLaEnJAfXzACrIszvQ9J59cSQPGRK/Z
GD9WIeQU2geYC33q3KC9IE20C7sOn79cuwMcydTp5QKMyfogGMVhoizlFHpHzAx4INl6VFK1lnsu
8qZU0df2tWV3+3cvQ+S6WbSpM7393fXM4zvzjCCMKR6bkbsUTGKYa1SzDbbcM467uPO4tpsXpHXZ
AcS3ITq9YzeBWgCT9Fm6YZAsP1T/o8Dy54+TDzDtQ0InqgivygBMiEo7GWeuWQ8MMxlNHoE/UdFe
tBmhZHgZSeHaLedyR7Lctr10Jy23W4ycQRikWnwi3B2X0vGnylGRhvbcVkzkBf3LhHD9Rx/Nq8iL
kbANcT6FO0oEIGpLn3KRNNG7XoKOfykS3kaMwZfQOhyCj4R1mdATsIwoB/Ly/Qp36P+E0tqfknsQ
oUHV15vyCf1/iZlIt9/MlqNphU3mK1Rk7XZ1/n3u7ILBfTWiRJ5erYLMaBOIitITe2nGzm5uUQSO
bhO1VfHzhG7QkKgDROjd7BAL8BIbMe87oUTA4fYC3dSmBJGWzXl/W88uOecEediNjaWRRFX8tcEk
lGfUSje4M0EAh7j3B1QPmvKi+Pa+3PUctVApo1rT+9VwIlzx0sAsE+49wlhe16VC9xS7A6YMgu6h
JX+C02ehTB/l/rATs6FEVVufr4gmfnSIIP9+2n8V8iVdyTWUjGI/CnySai06KZ9In+OTyt9GHVEK
K++UUaM5DVe565GMP/Xfo1hYgwzejm6dblSP9EfI0pdJeMmgs9TlGKOgiRn+0jZIH5HbXojr9LPL
14G7khrlpxJ5uA57uqpXxQ4lFjlfYrK7Zf1/l5nI3k5e6Gw2pRaXC/Pq2HLLR21OYC94jol8O8jb
DERnYqC8OohYBF/QCks0cyWRDXKIuZKOUJ0Lto2HahCGctSuZr/fEWs2H5x0y9BroQ/kwDpXVu9y
sAJzsJ53LG6+qzQciIB4YyXnRQJ2LgsNO4QcE/nLev1slS2cy/UQ5BBfVEADzCacDTQHtJtWK9XH
BzwDPjAiuBNWEEOjqJlx7sSfJnkeUxQWX3tgedH0M4QW7BiPZhaStuFRQkpj6vaoKIlYw/w3Bi1s
SBV/pzil1Ur8clhjmlNV35J/l8gmMnTb5UpgdZc5kniCZYau+8gMBwof8ylEUlTBrkJtSniU9yu9
hf/jm3DPICmEiZx1eMQBTXAJFyl06bdf9YjVlQldCfhd5jORk+07//kMK1ugwpMXj1LY9bNaVFgj
TD6E9vlfmG+lPPPQhz+PWot7f3cbADQM50Be6kuuBX9O2aOOL/gPtPJFP8J+vwgkcznZAQKormEV
JG9ZcM3o5ih9bPkLGeapUnPcodFX6DViDwTwofjsyUbHjgT7XW14Y5TpyzZzBLL6OeCewOciWlKc
qU4dnO5jh2LncORtD3F3PW3UwvwiIJtr2EIOQGwySmgQ4Zb7acUlaPOE9bNcgHPktC6hEK2f94lN
Kxo8S/30DHEA80dkUrBZCABLBOvf28DK7Z3BPazkZFAidy/X1Cx+y8c5YtUINdWMuiRVYYX+RDL6
3i5j5L53bjoR1LpPFS/Z8PFEXqi2sqXi0TbxZ4EycDKYOhF5MU91s/x1Pm3H4xw1CHR/GfPvZJtl
JHFYGk3O/6QOfstpw0Y1/NLG+1xbLZeWJy8IXNrNNAE225AaZUtOUNS+0tXqNqRLp8mpCkGIeMLw
HjAEFOnws8AsrOvAiowsYdxDmzRke2mPt6zlw5geB1u9Aa2Q/lZhkbcbGdb4b5LduA3w6Lg+rwpQ
oHGaSD9oJOneoLIqaPAhwu1k3d3lD3/4Cjt7Td8nKP1S7Qs9I+MIbspsxwWkFqs9YfWGR2t/H0+6
NPor4INi3Kj7wy1JJlPr0f4Nu6+VvRZ5wi4qMnZ7Ph7TweE/du2KgN6VUVy2V4HH3rQcIlwcErQA
zfSXphOL0/1moY1dn3yjUWYoP26MJzQjLBdd9bAp979Qo8+tb6DModRPNjbEwRfRMc1FY+z6X4Er
3YD9/CzRIc0WJ7h+tPM+Lf3pfYn6hqS2Z843zPFaE4IsrO+pXyKhHdcVr/5BDjQ+bjoeKaGLC0Mo
/endWStVHHA90IkLeVZDv7MGJf948vdjyKHffK34CM2iLSYXbHG6yd7HL8g/tKs/uaCv/sGp2cGL
xQIKh6qXGVuctFwdf4sSk8RcHCArWdo686S9g7NoO6i7N5BhHOcKiw7w+U5gw1kNqFV6f3vq9FM6
DahvoE308rwXBI6Ccfj+/nozt3BbcToIxrQUSkQRyTFb3azywADoTRjOHm0cS5A+k0nqJ6DyUuFv
G5nDGoiiXXP/yqoFvQQAAZ3rz4UQHlPT6imdZZUUKP9YiAzSzz5v8gbSlgl2aIJM68+RHPA6Bpr3
7kK9OGOZMC6TlXzz/HFV2lnoj7ni4z67xQSFQoYYa+Pbw0OpVAfCoj8R5tuaiYMSVs+bCIz5DrXj
cS+3RoWgsABfPVIICFYt07srmiQzqUrpZMElzP/OOiCs24lfPG0eZq27htaTP0PZBgvjNYUEXGPG
U1vzidAGdaOk7jqD0K/G3DAhTnHto98bPfDlP+xJlH3CuuKRIV8cAVA625RhT+gzZVPadPQLXlr6
m444upySQ1ZqcX886VN+22sUtXwJlob1+7cwCUB2BiMG5H3Xo7xiQRLp/mnHyQpB/q6Z3VtA6fgd
5nDiRFG7o99hfp7PZ5CMfTsrFL9WQVxdFQtXGzKo/9mNn1UWXTz19k/SWL2MHq1RXXbVKljpKMZK
16AYYjclLRdT1pWTqeCavRvfUuCGCqC5J011pknESl9S+/4S00tCjF+VkRYqp8jVfKIMCz/WN74d
avDi30AB2K4oK3/P+Nyo9AjX/UMouV04iFWrSZ8WRcMGeK1ri9k91hzgiUO/CogAR9vr99PyTHDQ
EemUbz1TXzQJK0Q6Llff9J1RVKnJ94Giz7XPT1Zuk3b+UjTmVbq8fod362l9o+rdsRRW7eVOeIlg
O+2q6xHhFJJGHz3RoN2LI/hC/0rFmJ0LWMJS9ZscGKB0YvvAYangdSqJTeWprExTIggt2PP2kyab
Z1HqPHT/hTRoDwpQ+tfY9/N4K30FiA4/n2atfH4wfgcD+9cwSasBMiuMEAzYZyenXG14wu1rjjvb
5VsA5KuzpOt/TQBkej00NrnEFwgoLM89sbTjsmc3zgFsRvFd+jKdZLpFCkQOq1gJ1qOxBdoFuLvi
Uk6p9P7fVFmx8SC80fZ2nJh2WR9AhKD6HA4zwLNPvDBrYJ++NuWRi3W5N1UnqLwc3rq0VQazQaLX
AxGwlok6RbJ+hvotsAxMGm0xv83wySKLOYWMJ2J/PSFRXpcpOrzLRL5zFYJ8A2lbpyB4H9+v6rPN
6RDOIuGTiVzRCcp3rPRBxJR74aOhWmItxmTGYpWhkQSgmPeoUzE0649HJT951t+T5n2K7UzSTMYf
SvdgFeAbfuDPw4kfSk3zt3MxgUKCwGa9veScCiYgO8X0aB/IhPITDZ9Y6q6Lvcc8DfDMesZ1fAUF
WInOpo/dvro+VdAJawYzfzepEVW7BXlNZEjovPSdttHh2clg0GxKEy5XgCOWxPwWlss8HISawH/U
44RByV7MUq+VwFlecquqTU44h2/lXi9v3ca8spvexfn73UiL2IYDSMccU9mF3uE4yJixHctbNA97
OmmdT0MaK+J3CmLC7J2P4BY2G8TslivZiebIQ6nOxfFK7vytoDHxpTdaHWwLyh4k4Px+YKyvl6m0
peCFxF8iWOa/WGg32W+TRIpigPQUh2kMzc9AC8LvBdjegdqtc/NYlTsxO8CoUhnUdAU5M9oNTGmq
gx94GMicpTThyfOsQn7oBCeBraFgPkOfqZqPHQrP4jKfpzUHGXiVkw32MAPufUpPlBc8AoZ8o9h2
MO8SSnK21BAKOgCF13IQhvkjcwP5UrkjI6KX5shlBxUmUp9RI9rjhvtOFMooECXeiT/T7qf0iwMQ
jWC70JBmWw5nMWc6SOypyakTy5J6nPsj6QFMBRZNcU0GYX8Jl3Aks17isOnRKVlAbz6xujXAj85t
KSooCmE3xT+L3A56RvTT3AXLmK2ddLKYosZ0mGjSeIR2WW/kYQfv11Ys4b8R2nfqz42WRes148B6
MCzTawliHF+CwHZyym1ydewoJ2h+Eusn6qEcq5KCHtQxDmv6xBsNIcmRBmQF2tT6eeznY3/Sj+kM
tTHfO3hooJ6AV0gCkmpOem6DB6B8tHVZO8Jz6Ij3PC26O5jWaDegOFGrdFHhoBnHv9uCudi7UGBW
n9RKgQRr5d1f1qfLwzm9DhsWCVPOlZL8CeZ0x90xBl/LHBiqO/ImSBC/alGt++R02WAtuUwqNbhr
17jFCfqT4FJOhdpY65wNh6CVoeGfn8GqOiU0NqAXik59t9lPmD1Dz4UAbrb5wS3/XRquOMoO2UF7
0nKg01Ru24GLM36VAG6Na1ZxHp5NCfG31fkWUowb52PCULgd12Oaxp5EV7PvgcFhHs9v7aVRSMV5
K4MUIX1NLOj/xyEzQKKp54OkC6FXkGmY01L8Dozeuy/YBnWpNtsdNQPDdFDqSLWb5xVej/8/TEP7
s99MEXOAmRleeNYp1cvgHELPWu1bevoViirOS6xBOxh/CIhUQMHu5oe9iaoUTltopSruC+RYwRXx
KFaRvbQb6Ur8TmB/JOKAEyJqVbrZBDWrZHDaj8t53DMOkUES1JriDEWEUSVR76E5vpF8YJ2Paikw
ysgWvktCTfAeqhpDAD7V01MToV1bQiJsg5vZq7/G0pqeGzXZBJhWCaPCTs9h0z6DjQm/z1//K39T
9F4uJMe6yeZKMcKJvOa1EHED43VSKwPT4bHAs9H+9CA4oDDn+cyU0FiCJN1JkqKFcjzciYtczktu
MuVshoGx46nVbAmX6t+A9xvJBTntxhwQvH+UqMjCXRC2oDwAGPWWuxzrzq1CWJsWw6+jDjYnybTu
ssSru4gRTa3CMazAVsmimJGI+VwkJ7r0KN8eO+WVHlc3YCxfRuPfO1k1Q62mrqQJ6la/MoetnD0d
cEhVtm4BN/wo08g0lHlZUHDdlZwXU7BHhgKH6AjWiifMR56YMfr6bwJL9rjzTRd/5p3vPxvYgxfy
iPlcoJWmOXPWtJY4Zyig39ktkcXHiKUvGy3pc2JPpPOWfTbvcJ/e8Xorie9h/+/I6O/bohtYDwkC
o9mkc+c9aMR6+rQfmGi59KcvJ9Qfwla3Dc2cthRy7eqRaFIi+3x5UlCE0E2FzwryXZvbdnif1urT
4HpGe9BMJ2D4Pbp1EmQyBek1XQvMQmzq/gjVs7utybmNr+0VaChfsJtGMEaJWui04w/k5ZZ5A0a+
vFk7YdNGJrwBUSsiIkXScWqsuv9IS/j6Jvw8TNzzV5eUGujnuysxibfc1X3Re/wr/xr+FIyDa2pZ
LJHI8mNRM5+Hl82F4AnA+oBUW0p29JQ+hWueqkrQmCnCKdJSnDmWvOJ9PauVr5mCLsR0uJJMdygO
+z9KAzxeppkDCoHuvsHjRWUXC4misnVCGGvVp58eOCH56CqYMlBhSHNsvjpKSUMfNSL9zEt/tR6S
e2jQkb6aYbFSQz7BrUPfKTA9HOn09j/+7/z62CflT/+5fYw6jZDfbpxUAGTslKA4LVqEToGUVCpW
AkS8Fi5R/3zdpFqBISMTJgpKgcLcnm7jBvBOLpKh2bXN4b2ogxKBYRO=