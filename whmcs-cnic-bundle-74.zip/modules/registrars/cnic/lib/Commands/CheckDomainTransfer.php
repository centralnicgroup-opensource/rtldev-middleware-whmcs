<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/xSHET1Wht8713Hn0iXd76Mn4HW7RPWZQIuTH5SJD9r4xiiKNPLmIgOIFdIl3/N0Y15qCOe
GJKoKiSX/aQJn8sMbqFEVi5F53cnqrOGeYlI0veBjqiQVUNdn/I1ee6RNeYa6wFkiRNziEZdy7Pj
PgrT6AblwJ3CbGAgzNEbKuLzWQQbxlknXxjSTmLYvDo36xP1gBcKwg+j3l6Byb0gg7qY54HhTKBu
nAaTsDvZSMcf91sk9g6eh6Jo8p2QfVDaeC3EjCCMKR6bkbsUTGKYa1SzDgrhbnKCz4mGib9KmXZZ
EUSmm/zgayiS/38tKgsH1vnYeyiU14b/Mc9ETSSI6fLvWUs069jPhgjN9LrH7/NyaXtTsAEp8/ER
k8UcfC70G5bHa8bYVhwPDwjAt3ykbM6CpVEQGjevi11Z0kmFqB6s7UTQf4+3ik41qyPpXdBHph1W
tJZMOZ4C1i9llGuwJQ+a0Di8q+T0aJKj8fzxKsnHolnz5Gb13V4Gmn+PkLAbRgS10gifjK77Y459
TVkKN8SfFPx8SD6C+9Bo2OikLXSJy8RazasMqP1T3pjU3pIBIiKg7444lxp7dG2zVEuqYBbBVh+e
9blfQgQZ9TNUZePDkkEGCUSIxN2mz1PWorGUWHXuejvqM1NvdMtFNjbqBJVRlCJ5FTfM0dSXxPN3
nFgJnPASr2bGr94+jcnBACEj2ZBvNEd2K6qu06ync4PoQFgZrWmzyczDq5nr2psgEpacnOD2MJ5m
i+5+ATjZSbvhXCYwaEf6m9Hdeh8vpko5XZtrqUcsgza/78J769/+mis0S8t2yOHGL47eRUuSZEnG
EwLX2RLnJptXe4Q7Sswe0yajv/dLOMJ37vos3iW0dFKDqhtg3W117oZOtV6wprxX+CvyBiTd0uTR
TTVTBXCPsA0bt1MxgmFubSP4NiC6POb3qt0V/4lIm+IdjC9dp8mFGxCDhkMerMvQM3/jqu8Fvwv8
bVjX13zl0mg1WGF/wfj+Sj2zIIcZ5oqQnlFqYtro1SJk7u1I6GT2XqxD/wDdGSN5EGN5u/VODoTB
E9ffEgeBdkloSk0SSi2URWycrA4jECjGgMJLUHzllNXMV5TRDsOpHB0CK8afed1e4ql38A5vzrjY
AHTjgNHaiw4X5sxOfg5vli9XLJv5D+HAWi/+l+CWhCPg1nkmU3Ial346Jp3Uy61eNOUDOc7CLANW
5WsDwR/V6xOBK/2Wt7EDDvFyfJRlJbzoOvVo6uq3m1O2MgfvRVlBnYjpS2DXhCDX4XmF4+SrJkhb
OWmXjkTWMvT+tZ5MCawAtGFWhLhvf1k+ne6LRiiu7y+zxDHMJaD/2v5vtQb35+1CVWoWmiQ1AJgc
gTsBGsE6MwlfmmJAO2zQHWPTgszm589YyEMVvBGLXkhNTIH5XDEAvint4+vjJT12BWaJl5qamLPu
Qki+Buw+tP33tVsXXrIb4V9bCYlJXFepdNP9pvCvclQsWyUMhCVdnUhKZgaRMmF1Z9et61mHjoQp
FL9fAU7cqitJop4UsizDYo0CHsDFqqNfswOu4+M3BZTSl7/jvINxUqM36Gh8xtp5/Z5yM0kvHU4b
5yO6hYwdZjb+ME1YymZcVBqtsURehbJxQEoGllSj1/d/Z6X01eem8l12VO0jSnuJzOk+t8zziDWY
xMTsl5KmBOaNHYrh6S3fjKwXE2CeXBUcY+uwFySuJQlbG8WPh8xExhYejAcmdv4tNE0f2qlr2vT2
Gy5U66P+dQaC4K0DTJ6X3Xts7GTILSSwG0sP9Tlsf4zec+q6/2d17b5FAdyKuvFEn0EPnZPKpt9j
uGBbYPQc25BqkoRlwCuCV+vmBzofaG+zkXbcXfzj+NIuVgYsZdFx68XvN7hpUDW7gEr+5Vy34Mei
96msqFdoyVo5Te+fTEBPe4JCWkOpYBFo/cEKH9tl8wa9Zhbh79EuLweKfoFtHbFRwKatRU2/myfB
SL0qTV4GwTcu6KM6aEgFzNrSpuTPa7Lv1AvsJexVtlbhQ66QdufW+COga/zDHYEuVthq1Lr43f7j
OSQLGfR44rCeY9zBYWx9fu6BpAtsa5aSTyEQ1mDni6CPf3s++IYqk6cZ8LTaTaUV3rOHayGaS2ON
skNGMwnXadsT2b+wnIRqmQpWXF+erk16RnvefVlz/d0weM6SiXb9aHfmLRUsFkNs4SQxS5YqYNvx
LUU8YH5NDjuvRA0wvz/V27WfXesr1Lc9KIOIC6UxQK1Bs6MtxbWHtjbXmZ7eVVpz904YQydAzNJY
1UCxqp614hbli4TgcVIhCkIZxQNi7WmzG+ExQcBRLnTNVvGuePE/95P/n+K3pKkuugM4z1JaxC7m
31VQTUXjk6EuvkmaLd5XJKgvtp3JPZ3lxTNkVJLLB0Ypwx9/KwB5IDxzDKsevMbWrKMicEMnf/2Q
CQ6+7J+JpKBGeqjDkG2AUNKQ8zKUgcvyHftZ9KXS+A4MCEdblaMEkI/NICSTPaQBrFPyoYvTBBcM
SnPz6dLgv+yF6FLHNcbYWsLnBm5zwIo6/ZbpipZ4p45VAXkJYbg6pYhtmN6ymLN/tRq=