<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoNcZCyFP7NWrYePxB5D9gjgl5kTsYwQGfMue5chO5HEn2wW6vfS4qpyTBpC59WBxOZt+9Xj
7ABqx69EHfDLr+sCFz4dEr9ChSdrA0jOWHsKVY8bnhPbNPM+ZvnvjSsfqWlM/StuN8TuRuwO5qKi
zIrGkvptq2CWy3185Y9zFHiZlvHgpMCQWWbnUvViw/p7G+Ow+c4x+kY+ezIoYYhVvhXHZPXN61bb
mz1a77xcJ7O1mtsYBhotmRCXAwm6/cUEYC0pgrxnAPcbprMKWIRvvAVdaW9jm2xCzh/ZAazufaiD
7iSSQIXijRgjq6qKEuZK4DKlkGvljl6lXkXqyROdvn+Ivji40hBYG1YuFtcaxdYSdjwbEyAB5NDQ
4VEdFsMGrQ+VAEPR9C2a6ZXNeUNh03GHHLl3wl20wuhj1wpg2X9Hm+5sr8jHZ3fST1X79vmOQ9Ka
iSkIlqUj6Pl21ZY3TlOiwDge2j4CJlaJ/SESFul5LpM0z15kWhSWR+QEzOkN+Q9ea0Mt32et9EeP
4CFbBazioE9CRPPkuA6KfuT2+tZN3ztzoneaNYVi+JfM9i6YrRd8FtTGuOYvczPhGM1qh4VHstEJ
gGLhuyMyzdsw4ZhhdjKg9ij2cQ/Vqx5G0OEajMTJucixc6O27As6g3Fy1uZm5iDAOXFJjZ6CgwG5
gCMV6OK6gAHyEdg4yPkoE+veTIX8qAItFyuKDvyS9G3mBnku010/Y3YY9TzzwfGtGjk1YRcC1GBL
2LsDIVxQ8ztI6wRtAR1SkzUVzv7pHRhZqOa6LrsjwfZsPDzkaPYvW5TkJIPAHmoMXRzlrzZ/TxrN
hX1rxI35AIeZDzuok402HgLS1ix8ObNetb4SwT3yztP36/V6XW0lTvxnLHAAvOEnZW2JhvKaDAPt
KC7r/ob1J0XqPdXMaFCYzOLs5g7f34nomOphxD453OjcuHSMnDdK2+ezWWF7aVZ7SHvRwqlEv7QO
ENYv37TLyvPd9pbowiUuHQ8Al33YiIeWkWRPKfauVVQ0UbZZJ7rmYbORC0ejvOh/VlGteAL4iaAy
JAw3sWDEzCowO5+7VZJ5oyksND/Yms840R3CL7Duimh6WM++1iIFPh29BN8p5e8jWZ2bfTqEouIU
YPdUq22ijGzPFGtRoxIqSa17Qf1O1v/nlLqktegaJHBxNZxLLq6XCyHkv+4FIZ/XV3NUxMynCJIf
Jt5a2ZkI7U0IQEFg+TN9c6FM9MT7Vv//jadNBjOar4b2/Rl5cccdwQuQHnfkJJV/WqYYAW+hwJCQ
lgFQNWkuAI80As0hnQo5gIY4NDH82ThgMXM4A0m/mqouaNMpBRoxBczE/ygZCAuOZtZq9pctgzry
9InPVLBfbn8tGR3ZBPFAMDXdHnYH0weEye2Vz7LL36k9UE9WcMGd95142Ntujc/+AaPGcxu7HaP2
Un2SW+tmXpJE9FIknYZHTzn9ufn5NM8DGf72NQ2qmQvaIrfOcLZHyYtH6tl2KEPRjX/nrF4Ffs5r
3BAgWS8aH2uLNDGCUWLP11Wv0X8eetpcDizbKpikX40ZzXJZufwaXkQEnGXdcLDTjdTMVZ1V8jsr
ByY2uZYrg/S8UNv3BK1ItzU1h8luhY89LacAuo4ktqme1fx4SGdNK1UTve+OX6qVP0ci5+4TmdYj
ODOevl903n65MY3n0dJ/VZWOxeMs6Q2yLcZ65jD0SMTbnn8+zF+EvgtU63l8le8ZuwoyajWeSMyr
NaVkjLdpFm6q4XLHJxm/5BgmbHYVRwQNuGlcnjMk3ZB/5Kf3ZVFBkiYlgl4d+7d2Evjz9WUMrJWY
8474dJa9OB1zYzFobeZHm7qLU7DepxUHqyMCbjfdRahwx8ifMXe+hlQWOrqmDV6wpwmbKfewP05i
ldRVH3uLC/pDMyJHe3Z6u93/blpBynfEbUJsLAawaN8wShX0/nOzobU/53MB2jX5ofGZ0+gLWJPo
dNlo4YAHlDM+xiODUDYkR3/7aT7K5nSKCjRGgLKtZkDsuH2WaHwoVse2AFyelI5QdzH/ZwYuo0V9
DFfoeaFW+J9yR6D1kNsEXeMG+yBy/BpakG3+5wStesnJJiyzlmMnwKpqtEP0bIbbQVsvbdYvV+0Z
MVfZxFNBCHr7V8O1W2dBR+Wpn4jf0KzVrVZOgf8OGQAL7qpF3fZqKX+9wamFAZ7iw0GhO3jOZVff
T8ToKd9ksEjo49TmJ01UuwOkmrBVsLK+kEfdwJ0uijl2w3QHJc+QuFRkeXe1FkwgxoX+rIMlDprM
PjIfuFxPTOqvoC/N4G3EUZC0Vc6/bwxagz/rM1yDnvzLMQg8uyea+jweW1lTCxxI2GHHvRUMPi8R
ICHv0D6ehIhKJj8BzRjfH9cXe+2TgYjYVTjkowGWRA06b3dzBCfub/UK6bXSL07MObWEKmaDFnsK
NnznCapUm+MWouoLzFbWhv8IJ+i6xWAaGJyOYPeHE6yQtA2kpT1lUJO3ti5Rb+J3gJ6KY8lSwSC5
1miiKWj+Tj5qtsqjJ0o2H+IYPk+lBcMOPi7JR5SifEb8aDG=