<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwKo0wTb4lY8S82MXBDlkWiIdBvj8xvLSxEuwLyC/dz/rJHdwTaGjwyq7s3m9MD+BbMhquYj
YYAZOHsX2np8MLBPp+VDSWKVB1djMhphNFSdMTDHZ47IBk64qK9iAmLDdyjCFJyFKV2NR3wA9c9R
+983dz6oP2WiKeJaxUmLxLGDjtzp+ffrPHaP1je7XDTT+c/XTy5k+a8x5lMHATQjwRyvLIInZbHc
KfR/yfAewRN02MuYj4Ox+f6Lyp9CqeUhPS7PjCCMKR6bkbsUTGKYa1SzDdbd8Y0c4YsMFFl/CXWp
P2TL2Pp+l2TX57TuGvNdMHx/qtURmQPeilSP3fuGwU/TvzIwFLVjOFoavC5ok36PSdIO9V9h9UVo
LjY9gFlvL+UDX2dt1pVqVJZ4nUxYBP76DEL58K5TWTposnipTWk+knMdlGb2w8S9RH5eiBt5ABkQ
r9rcGvbJWZy1+/mCFWXRfDzgRQk2JdUrarIDlMSYVDWD8bynvnV+KiYSPRQvhLukRp+/Yc6WoVGM
gAGnM5IaHmLEq9itsNcURHHHVkNuuceG0cS+un06IC2KCI0zCOFLGsx49Ua1T3HsIHAtPLCa3zJd
ylOAZrttbICxKUIN6o73VLPxv12zOlNGp1CfPLBQNP2lahFnddLQpnS1UPUyOVscnjJ341AURdZG
YoynaS9z2FUibh1a5cf0AYGUHb49kvRQSdPyYShnVABWTH2RunIM/Y+BDFRgn/6Iwe3Lp+OHyp2y
gzQaFkGr5BUtCDcX6PNJmYId5mk4UZwn05ZlWgUAaRKj6QDjvAehB1IbgU23G+9evsR1uBeRy7Fk
Bcky9PMtWxLq4T8PeutYPTZMBR0puQXgpwyWo0ZGMl2NTvsgxoszPmoJ6EN2o/ZOqlpirNkvJgWf
a6HBAgvoo2bEWXPJpCKIRuf0AJK0+atSzqGFnCj6/EfaIZMDoXgfm/G/ImUM7N8Rd86K4nbU2ka3
E7RZ7utsMuxPtDf9VnWIDY84GVtPhp+EunajYKOt/OIvk/yeXQqsYFoZwF8F3w2I5CPabkCSlbWU
nuSvufdmfbydE1+qcK2Mp5WHFk8r+Cy1Re2+r6Vid/BS9NhZUb7EnghjSGQmJ2mWcbGtabkhv2ni
qZgSWxbYt9WPtqSD1htsHBjkRfVUItRSPDTX0afFZad+1PUGxE5F/fvZwE377jatYB4iaGnvClai
5E1/4vJA5wYtOFYLWA+DJauzB2LNcqM82J6nI5wnNbmfcUaSNLgEI2JwvmHyFXSSWzLxL2+yikK5
D02hIBmuPY6IpwWdCoGM316S4JyNS2lSiQL7cPcrvgYhDlNW3TH9KAPqIEEVoHS5kGF7cJid/o3w
1cJWUjL58KNdj60naVFT4A6orpqxNdTR1dfbf5XszGICpG9hBeJhVgyTQ8LVTKhPNtfbNQR0Q2SK
faFBZ/NSirXDEJ/bOgJ0rRWGE+XPvTD7Cw7P+wIX4STYxuv4Wf7RIgWo4fNp1xxVRv6yGlRB38GS
0JGBjGMYd2pXhiS5fKvjVlU0Ufq5UWtpEHUTyeQXitwsc8/ss9S2ExY/wAg/NeKvy3Hya73eUkeN
BblYIfkpHfCGih9eTfTgPJVh0WwU9+4OfzkQtOiCSpb0eybIoodX77qRgbSA6ulgtDTF67Xnge/F
5LcMfzmvBQPbC4XMM86frZCUVX5EDp6BvGzK4QN78InCAoF5GQPoMEHt2mqsX/di3ly7XcEDrWjO
tHkpb9oRxEcFKDCQN8DJ3ZwCBFDbGpkL61G35ruUXpKlgq7dAPStVyK6csbcx0vvnss7NqkshiGk
OzG=