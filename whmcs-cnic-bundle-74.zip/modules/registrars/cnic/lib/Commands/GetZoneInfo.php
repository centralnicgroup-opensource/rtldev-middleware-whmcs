<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxMIuW2RVTStOY1t8zJ81Gi40lzB1Xv269sujzINiQbPrEyMJFW7cNiOpdR7yAtekfMjfapV
eVLCVBb3SLOb1GrDsOesb8k8hLV7DIeYm0JW4ojm+RReihuCqGE56PmGcMJq4ToQ+Jyx+fCdNY2a
wj37hyD1PI8sduYBm8axAJPwg3Y5mIVufsMsBnmv4aQRuLMaHXYJhwVVHGNgMJsbcnTdsFoevR3k
OvihDmvZ0TGJkbhcwoW3JEHpvzVagmcYmCu2grxnAPcbprMKWIRvvAVdalXeln/Uf/U3fX8ynqlj
U2TfPi7r3gmDjAf3mlUrYbGljzV8cVJ8riB9AbsCNTVWvui9LLuO4Z3yp9DDL97j3brJdVPCoXvM
JEizAcazQlbdvBDsJSOouhB7l0uwZ0uYGGh8W42hzz/v8ychLDh5OwbsmEE636NVc8b1UorJ4OXy
aF3ucnKumRf+2IIh1vtlENl+RU4cHiiZis3ie64aRFiYDcg2Qd4fTYoRyIuk5OKeDWe0vacvovWA
JUsXLGNkrA4uXlznVwwc69tXQVvZACDsTQsYdXxP0NhWpeut1JkD1R5B6kuqgKhjGheJ+MHZUNws
rQuJ+wrYRxtyb6lLYIUc7Seh3bvEpJevXxK0zph1u4IrpPX70imWjKeYrl+prXv2mMOEFOg6Ahy/
riMOQ7tMu7tv/6z8JHKb8MrdNuhTTDX6YbEwCpc+3SnAppHDKeRRgsLE07RrsJ3K1qHsfFG7nrTG
X/KP13MdS27+mErAGn606HdyhKy8lZH7vSsU8kG7TRkrJSMWsDIeS8MJU1Pz1vO6xOWEuc8tUCOw
qZdIV7woSd1f0vtWNfSRJv5TFMKGFG3oyUnKEZLAU4LmjWeixnN3op07JY7ikEeCO6zUqu9E9THk
AI9CvzfAhco/naqFFn0vBG4RWIDNqT6dYo5ERCTYULUGxbsg7vfUSWHGaR0QqylRidQ2Rc1ze0BV
xPGG+sgg8yBq9F+KJdK3hNxVG/yMwU4UQ7qbJs5o9zCNrvzq4FnlWW8Ou/fgIuZYP8rzM+0Qt3e7
zRA8KdP/MSxvN0YuPeJLWG/AVFACSiqRtSBXIyq1pHK1MUxQMTEi7DtR6atCvbQ5ZT5YyyoPHSEf
J2mJ3hvGwDWJwUPqGUrW/Fs6vpAm6OqoASA2ygHkDXYpYkwI9QPC9PiawyBAHoJhue6tHcxVhi0E
ZdGt5te4aCVa4Kwa0LPETiHx6+rWu9CNOVraijju0nYhyxFZPPGKXEzhchXdjcAZv9t1oG/AbM11
jeonh324szVenWEFveX1vWb3jK6/PPXTUKFBd02i8w2vrG/vS0ajJnUeE8t99WqB/VXE4cK6IZMu
loTFqNs6f3X7oaucye9CiQr3iUlWDwnKJ5VGHitKw0ZO3t3OvFfZPyTOJWzOk0I2v49nNQGhjhU6
M3LrkFM92fPWbVkcC+BQZU32pzO87ZYWtNd7V16NvCEiKCCuXWny/Oz+5YUcof5QlQFA40+C2K4l
2zIejsVzBJbhN4s0jTjxteCTOTg/1sq4+xYnz20vG/7iAhNIgd3t+LJVx/uvLp2i1In8yCxTJZzD
YGoFcPlWT9/4Kg9QRbxahcbrn2tFkh+OQ/6BIBO36AG7jw4jKESIj0NMfYcS2dVZb4K23DVB7giR
2axOv+x3DGa4+44eT2w0DFUBfZa15713TA9/RY7KXevBH7qiJIsT5g3yYfMctyE+PMOul3y2/dGA
ToeHaFbLTJZQHofvOMvLHVovr4p6LxQQWVB5TuJKj+Ule920IGwQ7fCnx90z83dUNrhR+R1TC/Eq
