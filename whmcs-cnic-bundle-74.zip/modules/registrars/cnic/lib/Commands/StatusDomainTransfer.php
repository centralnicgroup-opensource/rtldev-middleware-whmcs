<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPySZ2ac3euvkMkwVQeECAry5ULT35WoYakDid8yGImquSHPvl8hqiQ6KdwrN7x20Fkr1P3Ar
st4fk7L+DJ/91/1dQnCQUnq+4OvhJIapbNWRYfcPloSbuKBYxkQXki3NtU5gqOkPMYUX1AshoMkl
StxFLsDaMzQz6xqFWdmmcCoQSMf7kdT4j4isQpqgqGUD/BrV10TPfGyk8/iqwGtH7aLu9H69mf8r
rUixY3Klbn+E0sBhbqE8VHSs4rczoXZ6oG9BIQjUyIcPfSzLb84c+UIdvvBFOUJXzGQtaLMwb+1B
BJ578VyKuX40FVrMeci6MqvhMi7gT4F66crjCEuWnW98xzY+vsY4y1bFZ4PfsGqF6TducAG9/QyJ
3Lwcae/RQ82sGQqFd91qjVQEojphpzR730c9olB9yuMywC1aOJtWJq6JteMhiUmNRnEugkjHRA39
iYKEBuYnrcdRZw4oVCXRlH13XBE/CN2Q0TheFdBxyre9yBt/OjUqluqwrD9/D+I+BoAsVfAjJ033
GINm3oGjptQdV8syPRiSVgmuCO0f6Y160GAvm7doDJMVuuk6wL0eAMTwOPfLULdawvSYYoHh47bs
hkx07lqm3RTdxMIQfWkTUIyKLyZnxTxFhdw87FL/tJP+MulpNMQbwkLkOJfvy9iGiK+PJM0tkCyt
L5f2RdydGuDISAdzMZeWWnVTMVXehJxcOcgjaPbROJgOqdPjSUBhpldsR/9tkmOd8RRm/fy2Wghv
GhIWmtpiyZlDCwQUTn5dvC+bu2YyMt9iKnFLhGI30J90EDsBpsd+ZvAZMWCmCxirWr/Z57DH6uIb
cq0So9NcWm+HBUIdr8yzrTLMypBbN9mZIoa+VeXwMA+E7XtmeoOqC00ERu+ccwIZtwEmlxS/HHMK
z9SOPP7VP3iqMbs/72U+Gbgkx0Lp0dwR+G5uavyQfqxH+sN05P7PpL+52UyEHaje+IxyEobbmK3E
MgC5qWTjiQXXiIZ/E0vqaLX9MKYwoRHApsSY5XG3/EP6/FqnaXVltv1UFK500anUxh/YxT6SLTpC
3zANR6YyDQ5paMIkEavnqkPK17seWkZXfV6XRuFvH2hQVUaQm6RRacSVD9w2FVupGcJG3tatlPvE
OPzRcAOgynyxMDJVfdp8HGDF9phU0E6OeCp7EKNgWCGKi0DDlWigNYgKdrh8DF4eWInFdkUoSJKT
mp70B0kJbPdtHYhl8n8LDk/1T3KBoNCw5IysRDN4QvFe9YfEy/J1HuExzTLxZNznkEceI4sN78tx
FfsfbUVQf1orM39m+X38D6+drCr7wAoLyo0WAasWTvDf1PnCX56EV/+ZEi6Z5IMCMuzciYL1Hyn9
mkDoggRBrO78KfUBzBzcG14GvivVTuhxvdl1444HgPUnkUqlKUQABIRuO99WHjBeZpkpYPfNQsAq
bFrQuXuFBMFq7Cho08E6RYsSV3YQlBTrgEtwz0xrFxItDGDbIF7rLYSo37Vcl475hsmnb74NV4eA
h1CAtKNp4EejgDq1+eAYZMvSzbfhn1eBcyuZ+e1ZMfsMXFRkGRux2e80/C9Ws0/ipLX+Q+sohFCv
8z4GyYX+eUdKXySeKbHi/HEqbDPWeFHuNliXC2rYXLKTg6wOhxemLaEy3JX7JuuO3BW/s3+BCAiG
sQw4qM8L/mliA0DwFYt2s1LDDFy6Wbkh49+1V2JsnB8p9F0OxOqWMsJAqGy1yhWgbiy/uamdnsHw
uuIN+MuVRWLCaoj74BzhyyJjcYaqmAQSnPUa9g7nGqGxaLFzv95m/A6TBsA8kh7oVFGzQxhVKk81
CnUTMmbLzGfCBp1zyEpD6BkI1/b9I4Nl00PuDRCdlXix3w4w6G74IXpvmfMyH/YESXixmMPp6/Po
rQ5x9J3R+2jtC8h2WOBAEEl9fywuU8jnVl7GRSD2yJhB57cUkUVC0T6E29TsQP/fC0pOmH4+hwUy
7Bb4CicZEszWMS+H9zKtsi8N5EuJi8lexmIWz0PK84e46YfloJcWKx/xyM//Jkl9YdmYE1CF3RGu
qwdLmJ2OV5BQyX0LgL6nxaK3Nu29TKT5VQBmf16DtJMsOjVeT6ALHkoET3dQ6Tx8VyLrBpYycKsF
FxSsysUzGmCZs8JHU6LuO3SYzQKbQERmYLwATZetkvEJmIZNenR0SnYTI+qZCAXV/621krha3+d6
lIsW9koeTv1tMmvQ+haJ27ZAugoiyWgwiBV+dPHyN1yjE6HSOy961B18x+cMPKQAH7Ijh9YkkTGF
oLoQK6xXfTFobKRciUtwFKUroDSz2EJ2RgzIvU1SwJZ2iMlPrYio5TLovNJC6K3EVx52AGOoxxUG
p2CetXBXkWp1sfnNmgwx6dMuOnqYqJLJI6wcNoAOYLYEKP+DnOUSTRpL6j8ryjWdSTGYL1f0g+tW
A42+jOoqtbr6mlrfhASPXbBHCo4vo21eD/ubGv19AeNbdMkmJiGicDQLnKM9RvrED22Z11Z6n/0H
dyCa4D1Wu960uyHLi/YbskJ6a9oQYLi7qfK9TWeDsPiYK87kedCckUipGd6ZQHvW5PpYv3RBeXIq
Jc4ReA3//lvfhc6tQdtzHvGb2DqlH4pYoxH9f3wqkd4RUnoUIVSan0vs4jRO+4kvjnjvGe1levpX
dm43Mlgp6tSgMbm5cftWrQu0MUJKCoxncNq5OzpPC3dc39WMd1L1YLOAP6g0oITxEN9CZaEWacKY
l+ZHHsVK81W0YZg0WaysMH3FP68TaR0Wmh2mzaCENRaeHqQxpSKnunQKKvOWeLZPwPeu7mHC+uQ6
ciAK1DDm954v3Ko3MW1ZILaYjNTbSOXWIPFFOd1W2CfNfNwos9Xn3ssYAcXceUhj+BA/WBGf3CHL
6XJf1H9b8LI76Rd3lUqR6fc1YY54t2UpuinDMG==