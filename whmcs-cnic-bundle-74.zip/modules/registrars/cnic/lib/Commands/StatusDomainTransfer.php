<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqqANze4swCTqSVA+I438WouJbXhiqUYEinpFzakwyJDa1hPMgQyufFVT/B3o41S0Y3+kLtY
KehGHYmBD4Dwx+Qqa9cIntKkxpEGYMh1auirvkKo7RY+cxIHGN+F7fB9RIK77p5Zbj3OvKWU9AYz
Ld3AYhC/nIk/Kv6nd2KWBSRf88DFr/JrkBjFc5HONvj4LHDHSQSFUr3knEoUUumnoMthZPYldv2D
n6zmifBbbPmoe1iACHe2dRQpurYdgCXq1MAxMBJ35b6nfRfTddK58f0NFJROQMP+nbqqyZj3CPuO
8nV84bsHxsEEgbjrhzMm8nttTwXA0uyDfIQk+7nVTg0+elB9vbmgDOyR2frzME7twwdF8vFIrU77
EAnksy7lqe7N1PPRl6DlW24COuTMI1heAmQVvH/2dsGpiocUf/JeHdAIko+XS3EW1UkwKtrNemgP
GA8vBorIw2LFnNJI8R8k4X+ZuV4zUYehYm5rGLHKV/0jn/xsw93wM4hWk2oO+bCzsowGv2IAIUFM
ky++gP1bBlzJU1AFG8bUDat3CIKzfcl1iqG41vhgyluzeMo6aFHeaFU+iog4JQBnLXmFMKkKtc5U
SZSizBlW7apQQ5pWqA7VwriGrvtvjgyE9C5s370UAwv41+58oL6sEkESkjM8HkJ8WA840cKaWQoF
o8ReXc9isY2z1mYZqXzg0cjH4P9snvWaocFBu5WrZg4/I40K+A6pXmfrO1EbENq65WyAn1v6CM2C
zrNJzw4EyHQ4u2VXP4G4V7nllcA41AGZAz6mVrAtB/fMuBX+jwLvupPPfC3cxXD77o7JNuIrHhdc
YAyX3124HMlumscX+nGpn35zc9SCNOqdqJEX7g/BrKxsm78Q2UgzQIzEQ5kowHGM/FresCH9mmyE
Nba0A+Rq4Y9WxeXJD3LQNcnohcRpShv5s7MvCn1ZhbWlQL+eZh5kb1RaIPk6WcMJ8o+uH0NzQvmm
6o8sWT0NT1VYwtbUR/4Xc0aSwAMHsf4FgPUoiLgo1SkE0hCfZJKLClDhg8eKgGGefj4gyKKEf2sX
a6VQvVjzW3VIJY7swSiAt//weBQqOGfFQzzPXjgx0vDHNm6mY0/VRHiwI2U9d59vs9dr4w3AZaPd
DMAUwseVl5Az9xRzWdobNoWRT9WO1Vvauu+rfTZhtA6pGfOMR0qLu76/mfTObS+VTTa+wJ4nKwZd
WCr9ahj5VSf/t0ttghvIgyO9yvJ5ZaOpy+x94ZeFCToYk/lJozEWSQbH4MlGTekBr4JVKxzi7IXV
q+0p6qIkQ6gxzB8O3A0TJiT+y8ZjmJOcE3R0b6NRudDU20woia/ErFap9WaaJ+Gk8Mg3Wl26IZDd
G59QqNf/LoE60Flk5QT2U2F+htSVP4AYf61Jnt/SrS4n/J6nwLYFGMoKY04JNCaPhILzLMTg6sJi
E4Q/SzmgWQ4iCyDQQtt9UZF9zcwivQssLlwqQvYuGFOuJONq/m+wh3BgH4ub5PFIKOs8cUA0riV3
1Y5piUtydRsxi2LpkeWaYu9rv3NnWgPchYX0p9zZxZkQev8zHFgPudsAAJKIw2ZEka3kUcAQ7C81
LnlmlIvWJaZCcbqPgCeowfYQIxtSGDCVHyKNHQOolvIjcKqEElfn0m0NDBbPZHksbnKZ5g+TwHex
bD5Mokh38pSFlmuhB1jW5bWEdUed2BEsbg42dR2eXuKVGFrvrjUxudjCKR6SvhA62AGBEIWJVAnC
ZdvnQI4x7zxQ1rMVZXWt74R5XyULU6k1jqrLjmLV+X5X9pQKxnYQJdAVW5wrH8XQ5HQ49typfB6O
8OASR/82ZPx/rWMM/veQ3vDacAv+PSIe5fKWHnpY6dPnrbltQq6XsOlwBuObXtHzbds9rpCLkwrH
ztPRewjA795atwSqEDGAaBXDEOvKIOIPmLJwBe8eNbhaXCqMmo6kFcW/1t7CEBIEYqbsMxuaqhEj
nSjlvBxl6Na2cLrBA7A5OEjD9wUh6NUSfE7Bs623pkIvbibwqPfwCih5A4DoQiHSpVwtz6RvwIFZ
ZeBdwJ7g87zYSKrSdjQR/G4UYrOFNTNnzLhrpU+3cf6i6Ef8Exy4QCVhXuDdAwHEELMew2VjDJsg
fSrGLtESsEdz2HzRU+6c3k7f2kl0935dOQ5iwqOl1flZoSY7QgIiE0VCB1FbrB6CoJxCDd7wWwpV
NOFRafc9dlMoo/t4K/+1NrjdaqVcwWJ9J739hx3VA6fffDXbzazeEbhBQ/ZXb1DOraGRbCoNgOqR
SpRNW0TrN+nQWhR6uEAeYMSUg8+HeM93sLhFIiq61KdPEOs/sqD4O44dAFjZaihJ+r6f+AdgMW+3
sLWR5AZiS9obzcR/pDO0g7gBW+a4RC2K6/oNVY6KA/zTWyACCh7NvisTS7e/DQPt0lg/JwGi8zgY
jd+WWdvrUMPXQHJta1tO2q6GNMLgBDU5k0AvYs6iWaNLXFFrLJFunTbpv0kyIvOljmFP9PddsVyt
kC7nLKf1vXC8m3+gyX14aPgbHPyQagbRak+Tt4N1sQsgmcYATXqfCPAImTgQf0bXUXnHxIuYlfhu
Ql6tDaePERHjFVpDEFAvibRCrUwbRwOcm6hHHreFvshtJ2TdAfjOcnO2yybfQxs5PrPVq0DttW3r
JuaxFw0Q1rlA6K65HNovUGN1d+Qn/r+4TmzZM7nnjv18PkWPZ6UbjOHTrRUygFZdCs8/ZV9gS36L
KBm6XFRSO/49p25NMfkEWC6PGn4F8Yl2Y/Kut6G0U5/fPrsJGWMm9TKZ1aeST2SOcYLaQJuvBYjb
R1YwgHUals0gyAzHSb/VGP/2Obl7LZgJnBSpb4UkESBuCHPSFUYaQoTr3KXaFO1sL/rduxOZ+OlI
6wpjEvzeuxWJtcunyEE532ELW0ajvQlEpfYX