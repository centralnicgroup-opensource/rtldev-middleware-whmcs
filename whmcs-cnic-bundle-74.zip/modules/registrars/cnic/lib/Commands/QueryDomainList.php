<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/mw8k+HgvR0RFQtpAoKoDbVsZavbX8GCSTEioTSdZjBuL8EpxeYTJXIt1+htD/haX1OKz2/
QBbbryuLj6InAU4nwyDUA0czqWvRgiD08L3gRWwORB4udGr9h7l9FrG4ITT7PI41sb1TZcbzHA+1
nM9d160YprboobTfXo65OMLtUVw6LyHMczehW3Li7ubEQOcOrKYLkB0UREeUCDeZfYxpeidzMKSb
vefzu4JidQgJvNL8ANAPyRwyFplyYVovP500hQjUyIcPfSzLb84c+UIdvvAFQfjOZfd1gBt6AVTB
dGv7GMX6/mU85xcNj22lcfmp1De4a7fIY6Hpihv4sHmVr/Jf1xNJHFwqoyQYYsZaLtIHi2L6+k8d
QkbRw5A9RRn3r9pXohXKhEGY1WnK81x1mwOBoOjQ5uvq7FFJtykIad5j2J/aY9kiYhmNCe5JL9RC
M3N9iYUvCtE3QYwVc6nRVFGp/EyqnqTxOF00pvRlMV1kwpt3KwoZQ0QpoDaxFpUGL9x4vSQBzIsM
cERPxfIxfT1hX0Vc52urIK0r+xhpvmvJ6sxrlENEYdTMmvX5sWbjfI86JcAJwNvRW97zZvYV0uTN
+zo7ASuWHHHnf3x6BRlT7piiFTKILblbJU+u+CGCo6VPe81n/ouClrRkH2+l2fGMfgPEcTMxnzZ9
4FPgp4ZZirA/UMY63p2O84X9LFTGgspVR71I4UIDPOHh7GKeS96yRLLX+YG+zXZHJNUT8cudGFTz
Y6ApdtYiLspj8PQcFVmrdFbNfzKIrFDulvUrlnU7WrHoBVycN8mGi/a1aXHkRaGNvXK3N0cW3zQb
Xx+XpohSD4uvtVwBe2ndG1FshZsDhkwQXQc3XM9724RRzyfhoyO1zykIqvvcfbf/MpPIeJQKIUIB
s0B1A4fw7ERaCXPGjPPzAAXqL6NrbDDixsaSboRGNd2KkVzxZsLBNazIXchMHMyCeEsHAN+59iGR
bmQXmwSxFMB/eOJrg1FGUWgpfsV9tQumH4qK2JFkEU3oVX8mFPLS6GHRBIR10ydKDuXFloZliTWo
xSEkjLkyPLFni+alIMjDRlTIcFPUl4E8y2DAlkqJ+jdxax9lGq6fY58l3dUWqZxx29pceHmDbVRn
cnlIumnAhAOClygGJlcNsrbFgJWtDv8mVzRZw/7NIxXv3FYZ+PZUdgtaEKwlm8h/WgF25NPeLcuv
TSuV2ratv71FHl4aaH0D9kwYFoS0RBk8qe42O6drGjunYRa1uspUNgjCx2QfhblyrCfR0EY4HlyU
a9clDN975th05J9jZsCAqk0VQnF16d12vNCNXo6srn5IcOt1LKLBQ42c8+Z+7ZcVHXylkFP1QNqn
opblYmhUHXCisOt6Yw5nxI7T2LFI6bZepdRi6G0q1HTbZ2pZsD5qg0UuslsGimyNVw+LONnQ7aDw
M7++SFtiD+77+sKNlR7SdgEW8F0tQ9MiV0R22z7eYa/4lMNbuQgR6KvJ1YOqfiQ+lO8CCSW7UARj
UL9f2CxHehD/GIC1g3vG5U5SztTT7RNMqh0f+1vad8CqNcPeSo6jRzbpxopUmOIM9T4hyUZXeg+H
BxnMMTxFQuVtdj+eljRe27r0J6pmW8dcZw0quAJBFf8mYCNPXqlsTEFrNU/1aAfZ5qIZhD6eorIJ
2YJlj0jM8f3B6+k4tt47Du7AByjfd6KtRGxIVzH4BXHK+qlipF8eXUXnSxmAQP6ExugA2ZgNluo2
nJNt4sfjc0kTTXYtEUQ7C1t7BXV7lyUs7xWEZyRQWCFicXe07C0NiGoNQ1xTTaC6xSZOo2C+n/zX
6+6JzSuwloMBQPP9ikWkGOlrAwwLPvls3gWfJOWrUCsZ3zy4s/9yeDq/2ocUdmAOgA9vzGQhtvTT
KAhHIPXMD+1+QXKCPU+MIrBOb/D3C9jXe9cHnd8CgCdwCR2rAN5fBagRvFd/oY/ey2+7SQEtDE4d
e23r9jmOeNWnbII5D72x/nj3KLLG3CCvrzsy+77/bGFanlbVx769v8sUSeieBMid1ryMY4geXJ0f
NehpJhlII40xbZ+EBLtALLiE0vgMcOlDI02TM3EOYqmxrzomQB2RQ3/AWrYk33HtC0utIdsLzsSf
rE1CthJUhekCL5WmW+Es7eON2AaF5uMwuN+iOil6XMIuAgzhDXITxcglZVCM17KPA3X9sI6V6Uaa
QN5K4wXWn9pPi0s+RxJjpXrggcErp3CSiKDIsYor1wUiKZr9pP+NRmiq3CnYDxKqiXxJJnKE/YbB
2FdP2EqCGp6EzPhzVvv+RV9V+AbRk/2QtKQVRlOX0KD/xxYcIuS7mAKOFTi6VVDqChLU0g4b7xaR
fcfQEfK1XG9l0aDRyNH59m8quTtY7fhhVS4oEvS/P02YIu/kJPTMSgKs+T4pTQFC77Te8pZ3lPiv
tH2umYbMMg2RcouLpSBCZTLGxe1vJ15XL7zbPxNqsBjHxBvT7q+X8vf1wcTRn1/F7MIJ6pVhJUyt
3qcoItoxI1zHZ0q1nDvmaPfgqyDlWmVd/FGAhCVnQJysYTg6wM9QoafZxVUVSva7afYcsfvcXeOa
Zt33j5wBhjnN7ju=