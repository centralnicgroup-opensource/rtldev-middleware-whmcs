<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpiGspIajZyxiTnE5upK6+tDoZ1czLSpXSIEiGLhn8knGjh7HcKAylYDwCRaXDMO/skWwoJi
EWHDrhCLS9nOW83jC5Rm5DtZCFEjjF2cdVZqU9kW1CWTqwmXe81BcWPPEzrZDAvAteUd9zB2Aqs2
xbCH0dMj0WHMhNJBpcTyBRGBUF/XV88bdJw3IwfALj4eZyjqqMN60pPGPVq2wRDeZtPnHiCwldAz
ikSKs+Z/QJiz7nuwlWZZgte7Tx7Vn46e52/i2gwqmnPHiQMwNPvr1IAG5pqs/yPh8pt7ScKIVfFN
69EEY2q3d9ybZL02PN/Geoo9ZoWUnbq0OEhfdCi72SRTveXQ+kRMXMPH/oAAgj49zIKE77kz1F1Z
xay8PkpUmxhfwyLZO9pLpv/nj6Z8eyDsKEFSTEZBxmlnkcMnfbS0NqAA6cwmQOVGlTSo1citmhk0
Wlr9bOdHyRDcaD9XjuxcitaCQvSKEE98RIxGnkNmtjO+eIaZCba2ZBgOZLobcjwfwPxfb/SfUTQB
uFb3KGz3pY49dAcpFg7iHVgFk5EXC/oq7k+mStrUUGr2UwXmI2uBiWvlWOwYxRVzBf30ANu8k9gS
+XAU8LbH7j7SsNbQrMB8noE/laAiAKjXF/wW7o7lA9Zr/QiZJ1gRR/+uIxZj4M+1KG5obrKajEwl
e1ig8yJBd4xQQ3f+cdxsnP0Ta8AsjE/jc7G3rFgvx2IGv4GxSRCPhvCgvYU5Q2E3VffUwFnlzEpn
t25QRBRu5wcb1hv+uEgD1urQ1CEqdvH1/KKckFiMuXSrhokDAGSmMaBnJ5PbWB+S2t0uXy15COLV
BNeYqZ6udSnn2qq1P2MGdoRW48BXjdnDh8q7Z0rQWMBMo5HijQEQAaKOgmyHpT2K/G6r77ZYicIT
L8H7fNkQCtyqnHwONg4mbsbZiIq7tWn3EdTCP7qDtLVwCC7GkpqjMAJ8JSr/vMMKe3N0S94VF+ac
2cZsCfr56zo1SyHQlSpQF/qkT30Rs/TFytbgJsGo1qBRKXhhN+UWcv+NOqarQNfMFlBXLF4WdH/e
m7HmpVn4t7A4TzEMN20jrCJTAloFgmWSpRRr/65CAGK6JFmgda6IeIObuqpOTZyNxDKaBjxCBf4z
oqkBiRcRVjhvumict+BuxYyAhS6+mGBK95kL9G4I6penE9esNiQXlPEO+zcvplYl9NE+q3XXEaVD
CmudDxMGonHhsQZ/fH5h4MzbII78KbNUeizN/g+GIvfjJa75DvO//njYjUVySJaJCGBwO+1GWA6f
hscffflyyI5jXxKG9k/4KkycL0UDeFTgyWgeUAcKoTMgbxaNgzOpbldkwNtjCn99thWjOLKFDoqw
k9EgmJsWWhD6kA3NtpHqme85fomqR383vqkYBzDF2hwBo36lWqrkPKPWjMI8Jvf/vyGXPlNa9Gr4
1IoQ30A24b/LLftkfBllqMeEqv8joN0msssHu85YKORe3pcKGAmAKgO5BViY9csZcpftm6a41Ode
NHunjOfrYP/qTz7YxG74qQoZRrOl98PZHUtDwcPLl620wcJfRQlcRtCPHg2+GafiDsUJT/6tHQQK
7+GuaL4ro0b3TwYa+Aq0UsbN3PspSgMjpthc/K9bmCWl8ZwkpOA/iPTmGQwyaUwpJ8t/12X8dI49
4LsuFUpMSolgq/I88xSYpA/980nuaO7hgQZdtuPBttA0VMtoNTudd/91MxCg3QWiI9UDZ+Xey6Cp
kAJfutvKsLaG4arvgYmsiCMygkTCqgJlUqmFE1gpaOODdebzoem5PWP6Zw8+nNR0vFoSlWJT81R1
sx8bDzoJRx1hMTsnUUiF9Gbp+Pl+0ByPucelCBaoTcvsrVltV1qvDCHa4VN+Zf/5+VP20AOL/iUX
XSAWlzt7nzMIVTRiJENA7BLKxJU1A69RcyXPnebcGGUGIV0G1h41atwsUJdTZW/pw0Kk/jjRUvKp
AVOkmF6GsQ/CXThEm3K0Nyh+UH6pTIdqVNokiQw1VXO4ILzZ+YzSRssOJBFRT8pMAQ5Zdpr+MXWW
M+6FuZU3rg2YOHf2fSpXxSKcx+WAqukEr4CBGSIClWjR6hAsGDdyeLcqb7bkYtAR+OvP6+L5anNi
wr34D6ITlZ/d8JPttg59Oe5xi673SuqY/BGz+/uBC4GgmHGLzfv+YXyE1Qe3c67Q5bGWWpToyDuk
i/5f+P45uo0++HYVxe5/DFbQtjz3yXCr0MePXkbCUJ76ZpMj3TsDyeD7PL/enzzxDoogUdm9t8+V
fl9MwjfDJPl5AR7CnfDOtgjWbzM2ukGFf7URJ/vrta+2GLZwgrwUr4KHeKymuU+bPN2nQnyNEc4k
LnievDubGuhNcKZbgm1Zh1roIOt2eVutgcQSgblQ/G61qrGjkkczzn8UxvZ4bcp5b6PsB9Ci3J43
2PBgnLUcdJKkKvwpqS4I8sFxQ3l67Kz1jVSxpLqHlpIAcbbSDKZibIMSAfs4OwtU+jR7QEawz9Fq
2ifknuSo4iIidGNnrfD2I1lSdiewdNNUGHxBnTE/vDlCGzFQ1cxqIFXjPg/ihB4x8UKqmIE/R/V1
bsL9o1H/17qavVTjiG5k13y=