<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqgzo9oqWp7JGGvTlwpjFi4bS/olSX6EzT0ZzB0GK55Hoi875U2as4x9lOeZCCsemf3ZXPXd
joWfHuqb9rQ7b2Bw5KK02BBTAp/ayKkG7Im7CC5GLmUUK7eYTduD6C05XszahNOZDi8X2uidhOuA
mn1vx7gl+aAoaclhfpkdWaZek+zTlNN20tBWii4qmLxUf0+RHf1jD5jJaw2lteNZ2C24R2iD4CXd
FxM7IHQRsK39h4gUgmkGzyHyZzfXocLQIbUWVxJ35b6nfRfTddK58f0NFJQRP0BsbOElmYbE+yKO
CoqdCWhWidnnWayJLJjUaY1Gz4pCot+n0Pnij8yMuZBm1XOD+Jdwk/A3Nj9GdB89atVRs+UTe0eY
ouS9Iintt7HzC+eoq5V/On2WaeqbgdHvvu1fiktl/ruRojy46pCeDtrfJlFEWHCARYSDI8wDN3v4
Ob0GWBS54+DmnA46NAfrK2e17eq2G/C9HKrWTJ5g9azu0HplRx0sFiouAp1eADHwS9ia8ZWt4KBa
2wS2s6hu5FlA1ef8K2UtMiND512hc46IQFOou4CaEjOA0h5D4Ef6IOsM8m22pryLgN8lPY2oUhFP
W18ZMweL5BygpmiTVsMPu9CYRsE068w3YfgYx9XwoClcXfKAU7DffzbIG54Kj3iia2F6zEJkDzG2
gd7kPsuHpveXKeweIe812GV8JXEbKUXq2n0UIQxE3m9D4cEqbED6Y6WYNOKp83RoOWLSnp3sOmpj
J2xb203AOokUviQHSeZ23WlqXp6mUhie/Dx0uh3z/SlyzMCWFYlUa5mLfuhf9OOfQymPQ8sVfGei
E19TZMHDPfcU67cGaJyRPe28TBDavemCjOnzaS1d3Q2MG4MLA3O+fdPEKvdR9/VwqRgXLcxSdQt/
DJ43hEWEgNfVPA5pXJC9T3vwpMOn8t94afIQstcN/GobkTI0xiTORTrlG6ZAJGgWXpH1I5gdk0re
Hl39xGOraKWNTLuQD6AkXt6GlGA9q1ZsyofYNZSeMx+Bd7zf0oIU6s7a6ColyVt5D2jDdGbsWnbt
6jnDHWUJxDIaGcjHzDCxT3dj0VJ6Qg+q2pjkrzvouRSorFdxJCePjcYR2Kgh0QrRLtN3wcAjgyKc
FhXrBzVeIAZNkpIsCtRWoaeME17jHILYVwg4HVfVKK7OMjL9hO2m6bKOFrjOOQaF1VOnGCkpELF9
I36Ue0WFIiOcvCHsd3D/v7ny4laxHB9gE5DW7OaGvwAfBwZfuopTO41zsLXlcvENbkimQM7NWIzz
YIwUZvcaq/yG0XjY84RJ18sfmhbmfr5QD6m2I/FtmYShwJOA+RMol/uqHpaV0rhyq+UjuN+E9sL6
4A3A1YSDw3VXyA0JPGTpIv1rRoAwgef+r0JFbNETrzZXrknPOkL8QbwUpIw7TNp5uVKv6b5fOurS
13aOpv7zcyNs+cGAY1x6ym9SZ1ZeAvpDmPdVxnEEp4PQzznaYBFOFWPaZRc3E9Pd42AdPgmoSM6A
KwnnqSTwfOJ5keA8kYtZsACGMZ7l7VXXhsMB7FSzmLPvlau8yH+maEVTkNyv9KI91akz5uXsh2Fg
WxxnjnAeYTbaRnQP/YQ2lremsGih5C2AIUBzlf/skuk8IM2i786L4kuL4pMczIjqylZ7nAXEaISL
sN99S9RYMPn3tNh/21X9ZILrDpEEQ9xXjly4kRn/3EZLjRuNqVzUFX+G4zuFb1D9a1dqUVMyNy3V
ZhVz7bdGB7RCX7MrsGfCJGYLcoh7DcNAaUVHj8ZuTG0hpnbElm4SoL0bM3zJiQJRhRpr2W2wam8r
hEtbjN5PFH75SyiMo8WI0r1ECs/dy+qRAd+tFofrxKENMMO8Q4h0x0SQGqZVmCMu/Z+h0NyAt2Yv
9i+RL6YGp/ojEcE5mRYc8Xsq+lJm02z6WmbME3ASh5TsMPQNlxxoZfFx/uVSOVQtBTOYaPPxwHHF
IfjHWFK2WYQJRJLc0zUJ/EDdgAKwNkeovwGeSM63oWpTdOSbOK05Bpx8HqPBsyiIHW3/va/UlmKr
dNXaqbthU66snTVxX8OfjQrLc5J0SqNeTWtutULHOAkXB9qNCBQYJ7KjM7mAzIlsOIWK5DpVB2gr
6FtZFx8trQqdhUi5k99VKh9oiqQrnoVrexrZtgEaUldft0Uve4Q2l6jlmBfZIb69kJ5gECbw/Q8m
Tg6zc+Dr2H8VbUUX+diHoxwd8uJ4oAfW6qocrLHcc+T/hgkNQ4BzvW9Of7cjWhucad6LoyQCrwjz
qtI7v7dSsC5yUtvAXQJrqVP5uNwsIMK1wIrWL0bxQklHvvv0H8mG6KFfyZSFMxoV7oNsmSRDzgnc
jn2zcIU7qlahJdQFGpx+ou9YDD0wUI6803lihC8shoeOfVVtPj/qhwxtvNrpq/Cxh/UpwqfLKeUx
VGrid0==