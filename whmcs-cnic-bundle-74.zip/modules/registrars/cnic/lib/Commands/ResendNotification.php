<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtuLhGUr+nKeGAOu9F1zK/kT+a5ywPI8RucuzM2iC5XRXgS17lvJpWxrJXT26hf3KUPc7oGO
kwhcbi4GzZRWAL9F/JO5fEJ/qsZkGoz1gCEAJJ+g9ziG0KSscu48BsCgpULJIfJ8grJv7yOUGoek
4k/mk0UmyjpMEsqnaER5U5M1JhGDYaYwzf+7yRxvZrucUuFn4pXhsvm6QSAkoKpPzr1CEVzUsVEO
8/6vQgMPFkdbTdczYe/oAG48Ywj5JEdglDv0grxnAPcbprMKWIRvvAVdaZji3vpO+d5PWZAdP4lz
SKXQnWVVkQax3OUWbZyYEsCroH0R8w0VoGSLD1KcJTKMCuH0KG+iC1YGcZVq6A0jG02HALpvGxaI
UAz1ocGMhVMJHkgLbS738RTCy6m2eavCd5D3CeJG7OlV3lff063vlqMW+B1M4e75IQ1vujsedZ4m
+kA45K+Db0Gaq65hLG5Z5c/PqoxIDp5McERf8uoVCuj/we5Xdwhb6Wa8qh5A7Kpmn6+Fh5n7HbPy
//eMaf67ZvN3EuJ4qVigmbzozRhb90Ir254HGNYUoPhdQoO+k7e4lkGMzJBHPGso6afvDHZfOqtP
caCr4mMjf3XhClhtHeR1heiTTn77tyc97Yi5JOXwiFP+M9rNlmg6GCdPkXoeZQc31lJ3DwOs0Y8A
xXV9cLpQp0pEU+Z/XlYt1jpYYClWciV6Nk9QcP+Eplwa2cCJEy8FgxgKTQqalJKvJs60LclVa8fU
QpF5bFZaeVQHOwhGw1FnALz9sUXUvHjlvpAPa9oZefmM+fX6u+nrfymXON6NvWDdZVQo8HwrwRFe
0VwAZ2XuGx6HhNrYoPUiz4J21ft7/sIlt2zkxytMLe953zFYnHvTNe+hW2WfWXk0MVgvQtktQr7l
31cSkP9V8QldJdahxaGRHP6Lqzq1Szb6UeEKtcZefTlb79DAC5pUcm0HsnIQIqXr+YJXA6QC0Wra
PVt/3r5bOxGkjPJECe0kB1t6Doo7q7csBhDv+z0ouQ5UQaLxGVrykCJZFkxP9a3ieuE4bU1fnij/
BgtnG5kPCH3MXA85gyaPw1OPjQFV6Dlj2xOnYbCmoslroAxmIC/Hj3dTNrjtHT1nFxnaOl6sL4hY
RxAWlbY7Q/9DcGDt3Kduoo32UPNkF+j/YLHA6vBiD49CMAjjKGfp7sdHz8gN8N0KhuyVPT9RsjRZ
t2tVXq2zZ1/ZAapeZw/hnHQYB90QfGCJdBt+rhSHNGd6j1x6qxodaUcK4quxI3viuQGw0UoymTEz
niJFyjuLI1NdaTBwhklPQdqdB2xKr1wCf1yDiAFCnOMXcaqDcnvUUvnVCfsIPuCvDVRQqhVXGtFh
sBCKQDD04FUzGUqHtOdhTXFmU0OYjPgoBFQzLOS2f5LY9JMgtJgVDktR44P7cMfZG0Fp+LjP7h6n
Wtwi4bBtem2cKiOSX8rgPIvB3i1gJs9xQpOYJFzt0nvHgoD5zUNoezr4JmyQ+uNQmHHfZqJTFfk3
JWI8c/VvxxcwVWdTOUvgIFVReEFo9mLqz3ws/HnBAcRpuOH3Y32/OqrkBFnJOKX1TfTsRDOn3b8n
EMFa9mn3zQq3p6/DBEOjuuSMXZvXoWnj61xMovfzNJ5BoGOK6WsJtBIDURdZfz09vAJ1LmPSlgd/
+00dzVbQKaiotZ4QIQrv9ullSabIvFUx8bPhKLF4tyUYtPMb5eTIc7IlA4q36O+arLhT6VDLuJgD
infDRbxwYl+azTOsDbeWcarSmLzQhnKrN/fvz4iQlBK7hHFMr5qlUVp7Hg7Cv7/zsIJFjzSnDG/e
jbX0cEssKeV/znJ6/LZ8BYlniQIMq12JolsTeflI6kwz+q2GXbzaaMHVohWt667Z25q/tiQ8vriL
Vc0sbThGliMq9UkXq60ESPwBOWLc/78q9FDnCv0Yecn7P44C0XWQhN51/nA86Iub37yehZYuqERE
gry0tOFEH/k2PMJDZh5Xj4qx4155AHfMouA9wPMQNf8fplkwtFtUntU95dKIkGIYGiXxY159EqxC
UVywraymLJKqXxH9xCAki3xrYb110eTGTWyDta1f9a6anfTBrlCpxnvCYSDFGjK0l0XuzBYiDEEs
MiesPW1vBxeh/Aw1JC3i20plOjVsM7KL8Wl3sI2qAi77Dmpo/gvOI6RtJjLyQOgQe7sw0SDZV3xa
+5OWogUhtWQvgJMM74VRDU2/OHHZUcTZj6hHSlDMG8rp6Wu4HGy9Ghe/hxPpunRoky2PzQpXFhVE
vpLbPyY6YygbEDymUgNHO9cGy04uVIvFurNPoam/iBaHwdFwi8Ru9bQx9KiFxZ1DY+KR/1RO2VO7
E4caq32l57H+CD82ECCo0ywOJd1vBdsU8/Hm9tSN8snBdXaVPegTAY4XcSwJT0n8mhbA/PrMHJHM
Ynh8Wp3VB9jNeyaSElyG