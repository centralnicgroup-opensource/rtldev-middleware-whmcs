<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpXeeNF/WVaPH3cbD53CgHKf6UYrGLcUcR+u8vvP1aZlZoUI7WBIwUnmNNqvsu/HCTiRkGoj
a4qGX8BDNsHJnTFnJ2RKRhWOpOcSjEcyoadrimhw92zTZkntAPueHmFfhW6Vxl6YLL6orzkajQGJ
ZPpGQGL3DQlOqTwXlTeufgCQb647bL8cg48gblEV2rnbwx/r7bRuGk95A2+8D04GIRvvuRiZNe29
ONFm6XB60K9nuECbduuGOskEn9LMeF/EfJv3uWE08QczgikwJwn775gX2U5d/2SFbISsfPlOxwa0
IQW0/z9y001ikHv0nai8Jlik35PLdwgpqzGBLtoN9g3W43Eqs1e5DxJCwld1erzph03Q6FXxbKa/
V61dz30xL9bp8J/mtkwDiyPouTAn9hF4iMrIxtewd7+lh0QXE+ICXZam41i6Nhm6VrTpxwi3ga3B
pWwwsRgUVssSgLx7wcckMceaBb/ZRgF0Zm3PfHghf9pLQujut6xA3nbCOHm3H1lkoaSRfu1yX2gq
DWNY2ffGeHBOYZOtVu50Wr6niIHrGqn2D3XK0D2jecnoGipIRQIax3lP7tWxZHqXpOZ7uVVpMD+E
hGwmvxcWmCCga6QBFaLTKjp5iH1a4nuSiRpd0A+X+rLJdqDvWBDCaKGb4eylG24fZ7kCczkkGjEQ
4x4x2wjQ8jHSQetbhhYkTuUoa7080F9SaZWhHgDCXtLLwbrATmRX5+GtSAQ9Pb8CcN3TmOZJFe6B
wUILeLchUYPPvMxefz8dugHMlGDy4LDkxMgab33a6hVXGMehNR69tbJJaqjyPep81CKGbVStVVxY
MLqL4iIbD0tZNgrKaffDooFGIJNXJel4BZ+Tqt68qP24hJ0L4NcynQwQzyofcrPK2VxDO+hLVytl
iqeA6YmNDWaU+JepIR9UpCfqy6txGeSAW2QgNQ29y3tcjpy3nA3TC7yt3lpqcS4D9Q11QswnrfBt
Aeq43LwQE3s4GqJl7IsHxDazg3li6YkcBC9vO3AlilzxFiOx9sTQvTuSHDu5OQplUo+1aQ6fvKjo
MyLvJYoRQPe7eaiEc5bhGhe1+/dvxAhtmuvPwroyxmXADRpY5L26ipuQPh6ltoEjc0pONbQZvlgd
9dnGxvXLzqsRWhbvDF5/xc8lCLnD2QJmBOkCCqV2YoEd0YfMc0aYHWG+j7iSJjMG9o1lhJiXV83A
lvXnANV3tXMichQd1voiXW8j085YGewsi7bXqImZXwJwQdUtDVj94lFye9EP9JOiTadJBQc+OyFP
OSHqPmD3y2Qq1B3KXAtGzzdZsv/46tt+EJkkJbS2XMI5eE9QJ1QxqGnrOAbuNKLuHIOJb8skJWyV
E1Mo2fBYhn4gyqGWayKBGIuI125KHV2joYmVzfjiy6Lzj8T/S5dZ87vSlZY/36yRqxPhdKhYjFwx
ivJ7OmQLIZSghyBwxjsrPNRGr22+L80ZAfXEPA5i+4tPrqOXss93W6lxQ4DMURYF9KHMnyZ8oOMp
gjRn6fpfVTJ5V18DLRoWHu6F1D0pPBCtwd4dFqboYDotMrLaSTANShQ39JFsrkCT5b7gAEkh3/+2
j9xb+kekdEqm8ekGftATdwE6Z9w3tqfHceZAkPexS+y2IydtkOSt+wc+IuBS0JspIQQ+AvSEWH76
G/6IrXZH8Zi/kg9HA9I8dmRWfaqnsPb0khBCW5e7HMUOIxXdUrg0tPGpcGJheg27vWBgFWILK0C5
2p/jDFXi4vNO6h/Z3Oq1Sit8kmcKPR0HgnCH1j+xTzOXcihwTixBnq4TARmSeTL27yJjrbjC5K8Y
3fpEDs1SX/ZdpngI3Ex7QnmiJIxtqb2EvMK8EeyRThcvW+Y1Q0mQEOsFIAJaHBdS2Kidc5GiWtUF
SMOS49PMlQdfybCHGgLBUCdemzh7k4EFEvRfpl7qMUUsz8H2aQAs/rhQ5eYwAyBgAmDcMmEB+Ykr
MwKCcSOQI/616hocCnj56HOjuVI2jOQ8eTnvXchyzXSBRMqHqpbIl4qYTIWpIQ6V4pXGQV/Q5guD
9xAKt6qbWUxlx7D2dofO6rtVHR5Rf2ETduprb+wNJ5QgI8xmBwj2gzUuO4pqFznZh3DpPTUP66kz
msDYiaTMHgox+UJD+e04O/Vd9ZsUlaZgTALMv9CGM/5A0H+FFV4RwSkDpgHKDs8JG6kGNLcpDULc
IVh5nNbqAWUYkoz+ZvZBxZ0C472TvJ6SZv1YcCdbobV4whW4J081qy+KlmBZZTZyBINaRlwqnsdG
k48KYeJb8yUuRTrN/ug9nUt+88ujf1q2PiLnjaHcsXeeuIZv+YSAb3xyv6osAzUAbyWgv3uQYLsa
EhevSNGR/WHrft1vs0OlzMkvSBlB+2uW/nIadBXjQe4eLkOtusTCbOoI2rcfM/zo6AcHQ4HPZcWs
e5b9b44CqGNaMPYR2KHSfrnjQ02DODWmRWGRaOUX7Sm87hWUNGzyFcvEMPp63okcVCIdxoIHvWOv
+wRA9E4QPvePZbpajsCufHn/uqE4WSbTRfPhiAPMbfPsvytIP7MvGcpg0B+ovdcigxGRQJWlcfx2
n3yz9GZphviPSPca1Sh8iJ52DO1/5CYPjW7Ti6MQ9ckmXHSQxFYZwhaBXCiUsoIiiJdV+9lc4dwe
26aJnm8A9COQK4hA3ohqiHniCneriTFnDnVVGazROeNlu/zqTlgM5uCZl4caj52X0j6wR4y9yaPO
v9uKcEcLZzTqzTeq4FJvKJ/HDotK22eBC0PgoKgDmAgkAyzeu+/AMxBigR0DPY5/lHNIcxxRl4ux
jeWNYKxzNnPJ5i5rBUr+if3PAPs1lZA980pwnbcLks+3ebnJePDE90JLVQVkHg3s5qzG3awMw71H
gqXIZEjyWE53deNiophkKcUgJzHV5ExaC9JOO0qY880YcCABfmA627Va0ZL+xhG5NMk1Pe7XrniI
4Lq/BUyU0teGvempRbvUPpDrXJG2vQCPAE4zZRdDxRezvI0EuHjtTZLAp/xv5vXwwd4Bms57eGsG
aWtOJVGiA6NlV/aBs11QvXai0dEUtshW+iUUHIIriphlPRl5ZU8kYiHVg45Y/iDeD358tA1Hu3zE
MZOkyX/F4xUa50/430==