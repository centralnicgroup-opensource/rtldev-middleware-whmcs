<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuWRszdVo3yUfjPE+dCcyX3wH3PyUvvvyxAuH/ct2pbOjDSQKLLkDtEhTukWJNuawETWr8ub
VopCrBTZFUF38C38X5efcHHLPuZ1pOumDJWMHuKUMN/r7sSfEJi8TeICaHSXqb+q8qKYQ3BgSlvB
GZPjd4TAES8ln3ZNZahl9utDGhgLiiW1v5/XRq1xXNTuWAV1GSgYaMwkUe5vfBon7cwDciwF5haD
WwCX1AnXgDRz2qnbBBJArrsDxG30hI8XYG1nj8k7Bd9okl35K6IoGTan6A5bDaA1BX55WHlj4tK6
eISWITDczrXs24QIGrekeUQLDHe+rkoXJRCe9sz/3zb77VOkU0TcbMXPuPM0jPQIYmtTj/aUb/X3
1rF62WBBIpi7V9Uk+HSMQYn2HAU05ICdhkgSGvs1CDjhBxdvyQggr0jKcoqprPZIkF9xNa7oiPT8
+o0Z07kBWzixZL1scxAffuQyko3rvJ7Ao45YE6sCDA9zM7v5vRfXi8Dwy0a4kesUMxR39cmiell3
ZezWBoOIs+dLvi2CRQGRm1Mc/T2ICPMBqIszP2DSlfLdhvVtPM2nECDJG7Uuo2hXeqMZCUQ/r/n7
oEwI2U0TySwox0KOR+03p2gN/Eb4zqLXXs56sbhh6KNnoWvOC2nudOPWtYZ6r0Wk684miv03M6uZ
EjtyE/594eYTjiMw7Q4UJnUDG50Lwdm61MTtOQha87DrXbOLUzxWw5Y0VXe7JigO/wULnjA6pJj6
8a6MH74f/PrYOdimSJ1eHWGBT1H29eALgMSMBFWspN5nHpb+U8Vco2CVvS+tZ3aWXlBCsbUEg4xR
XPIyh5Isp3IIIebGCo3K05FTmtCwHeGSMoe14MkTw38k7Ob4Ldsj5pjGiheQ0zpJXjoYrApuvuuc
AdVSRfH6uhYYPlmL9eZ+PlASoED67LuGaOM2VS1QJa9OEQX+0oo5JqHOgfxU5rmBnpq6VQ8CKMg0
xFiDkxW8aNT6nAnUAup6cBo3yzAydxvYx5qBNzIALgfI5TbSXlNXvBri9fWKYMJGniOG6j7TrFl4
J1AoY43xwua/GPZrB4BS9LO/BFDj1etGB3E0YaK4JbqtfZFzJPRWA+Q8XRdzsgAb8yMR4RZbz+uq
HNn948N6PguAKGYRFts9AC/ADeqvRLntwpUuQ+IYlLjWBWEO/kuGnekR0t9aHQ7+EMLec3KarQS9
Ky7TlxGdkcbNRhKRPkuTVRwnNCCNss4ItG930yLwgXdEFU8NJTR9fURbKczzZRR4i4joZ9oe+c97
Jw9+0QhTmGlaAS95NfiNQxEbWMIwOHOqxgCVTNuOuKS3gd+3wMvSMv2ycNDeSwuITFaW2MNRYjks
vNFR55vYdDjhC+MdTtONeQV6eNaLp1LUmnJhlaICUUEyypYJFsj++LU7hQhKg34YF/p5CjKNWaw9
ggb0JbbpUU1MGro54cv3QEdQRi34qv+phSwNiNEA0eMmC0nx/BY7nlU18CpphhA8fm86V94BNgs9
Wa0pSrzqZZ5k4hXildTYhaf0xEdh2b8SSk7kP1WJGSxpx+/0z1uV27OXujvXZ71hNVlgSQCEVxau
1axVU00g4ZaUTLWHzkrzmYD0M8jJrbZefUy0sgIoRQbuAsctS6QmkjSVqbTemUGPXJBgBMGN9kGh
Q+DrR1cJL1yGKpvJfYSfNArkktTZVWn3/JZ/d/hAxL7Pn07iX0KMLLOL2leRghjQ5ZgAtYv4UJr1
M8HnTYm+v2Qa3udUMfFP+KbGetMl0ELzlX2reW1K+BYDv48nN8YtUxriDrjpPKx6aNGtLCGhvhlF
eaqtifDJpJbDQ+8nuYCBL11nDwY+CbkPBe61ydCYTbZ9ZJzhJnp7SrlO1qhXqNni0BE1yezFynUL
3eJXBjHPOsdloYtvSiabDxIfsPJUjd9lCJUX4lvCKxBo1AXr+iaS0n0/qjWOL8armxiXrNQwYhZa
OWifgUuelYejDigMjDxaPj78qHNkEOE87sDcW9oBtZN2Nm5cG+xSKZv2a52Zkmx4sDXZ7JJ78nHy
LgDVZGZphuN+J5EsChoHSQzgk8C85UeJ+W5qrjrF32onoMgC/uCM3INvFiNPWOOzlUg9l/jhaPvh
0H/K4CV0VhLaLET+5J+DutEBPnyeiFrIBbxwIBnGX4dUbrO1jRJMUdnkLuUTTB8kVj68i/6Jv6u3
QF2fjkF7HeYmdx96LyQIut/cDUtCbt18FJd36XzZEpZ3W1whVqeiY6g3MbPuJTle5febsuJLPclr
n6GRiKAAAQxqP+WWXbBxxdKH96Eaq6zlbtR/mqhuk/C1HZfyvxrnys1nqSyeF/vrubX+Jgzrfx2q
V/ycaP0pfTshvCzoIb9FAO5bY6q2jHCzGKyrfMz6//+Uwhjz3X250mn8Y7l9P6cUZolRtxnqfX4L
LxXy9vEpa8ym0zBAwE5dq4Ih15/XYROS2YJT+LF3ktxg5KVpR11dUfnJRASPHQwkqSI0IcMbiCXY
mc/D1qBiCkQla84Re2HHGzZrOyftP+5c46H+aQuQuYx9zTHsnGxS4zXQXv3OdWV/hTQFCCHNF/mw
RF4j1sY63ssMg8XEwp0svo5OJgFQRMRaUVJTN7dPY0L/cPgfsjBqgH847hJ2+52kjcu0ujUjxJQX
15vq7QZMZwIecUiFI8QTeQTWKTDiKFzF/XQd6EjxM7Nq8ZkS2MjsURWGrR8ZUbavj7EKHyHdT9O4
Mcai7srbflLR4FDKy9u5TDLIl9oBDypejei/V5iWp3ZzRJ0RXu4m4kFY5Hsjbek97oXTC5MCL7Me
btoElomzfpth/q3IZ1LU22gtam5mJ6pKAY7VNx/CDaksujavgLYGoPqFIyTDFQ/kQngFRPwDlFip
EGVNtxsPXZ4m7910XONkgtvXP70NxRrxuVcbYaj0Y0i5T5D9s/WDB7VydnBg+Js3ugMCtRPgzl9c
RHT6QHHdI2Q812c2b0DQ+qVZ25Upo3z5quQThI+VI8AqNw8leiSdixKDAz8iqrYnu5+X2bXhqTCL
5zzVA/qKk8pmvMIm6ANUvfUliL0OGVMeqmygoyYyGXhppt7XPomBMCtcOIx38M3bLj8VgRiDtpV0
djqBUx1A5/gdERN04DWkLOjp5FXOo9zWjAT38Lc3