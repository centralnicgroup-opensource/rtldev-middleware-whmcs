<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+JcU1SQPq5PuoljD8daYQpEJm3CCsEpjj87UlxCI9Dqb9+muQ3trKZH6kypNTjsJ/ukY72C
3x0LHsaoG8sGPce+XdCUOOqVrMHzR8yViptS25TwzUdpzf5n9qThGDsY5M7sSrviMk8JXezLmbKJ
o9UyNdOpCfPOAdriJqXQhqkyVPYldDeJc7AAl66JFs9DvLiC77a5Rm17Jb9ZiQjjj8SZLpjDFIFX
4Jxyq4Umr3rLvDjcAXBlDPwdwe6PMHZn/W0FAxIBXovoShhmnL1aia7PCHZKPCp0OExdp4Dq2DTr
DWI854tWo11gy/FbVj4XjaSQGLwWvA/YApdn2ETvi9lwEwYl1czv9V8jdNxo9yQ0d9/K7HmIQpUn
4VjWjE405nRh+IIOMa+izqclOTj0rz8BbfGWQLofmwSvP9bevKfbsL5RWybhQo0LTYDwUzoASHJj
uETfrZ5Qcd4D99y+rbIWv5cqGapiy5NGTQJJV1thHvf9kxhAehSxsinSYc0PSkpqfm8YBGHSNHb0
5Ukd6dytCed+GLJwTTU89aaF2zd5IiSqg/0TfBT81QuV9gx6smyC0ISfAFWMcfyc4QIExjxR8e2o
Gt2xRCZDJr23KdoWk5jV+JDwi2aBlsGTg35XilMpxgK0xk7FcLO7Sgq93jEwSC/p4rPOujbF+wnn
8kdhronG+6AeIiZGOWkI6otGiLySXJkKn+VJniE4jI1YhxPCDuC/V9LGikfqT/LJXnDh0U45NzQU
8Gx7jGoHURtc6f0Z4AkHEONMPRPLkY7YEC+laW538LbwQ8aJZ7PeruUK78oQUS1wewyNG8t6w4/I
MAp0k+aqt4oS5Xb4VFS0gQipWhJHpwJipAYP65jDHgVT6FVy4fCZlC1WexaEwZaDa/WDoaKJTqhS
/KPN3OqYg6LCSL5CiQQdmdV1zSY/QAsC6pCrRM6MV5f6cKHWR3rmRQSTaRDjAEEkHcq5YWKCVzFA
+IMp3EvIEdRs+5O5vLhNA5T2fGwWv2EF/gyGO5qsttooW5bucvs5nq8fNLsl5YS5zdVBzV8gBo9l
2UzXRymEYS/qAshP5j8d/K49DauS2Qz6Dok1hGk7sBrcu4X6M03q89/pI9a6/qiP8aNCUP/4fwMY
0CHfd0e3FV1we4aVZVYGhIRPe2VCxKo54q1Nniq7fGqsZrzpxGwDIhawB+cu6g7zncAF4Temkf1f
I9vWJgF9sAheW+bjwomuNh1YwKh8Xvy/xZR3cOwb5JI45IF8CrnmUR9u2FUPqjdvIf13pVRkM1f9
DpgQ5dyd2WYRjzXvtiHQjx7BCvmoPXCOiWChoK4Dv8vwqTNYypkWzqDbzDrO6F/3HnD0Kv73L767
/H3BosqfAhAJzFt6V3eLz6MpxtECLtka1p4esAvLcsZtvKQ9NjUB+oyhwkx4JoaqU2ZqEMG+TtXZ
CWTAAQjIu3zuCR3Bq3jIMH/7qqHrLs2OR/2mEOM9GrdswNSB1GIjjfdQ5yAksJ8ejwJFZy20QHT7
FTW4r/Y84gpPiMB5NFZTzdaY/K5mNVv18olzY4im96fo5JwfmOyA2bEVrrDvMKxaDSRm0sS8rxCQ
BrOVs9eGRxFO0wJ++wg81s3ie4n/0ohvgO45p0CqjTyMrqZ6MSiOydEO4tMT70il/B1SxvVnDddK
ghZyvpUosPDLvsymgr8D/Km+6WCAHtNfcYz26W6hEPlV/U2H28QI14Bvb4NZdhSFrDjAIx9MrfNm
tXw7nOWBrIVzgi8ax38FA3NQpk9EopubceNpzoqFlts9dZcyjmEkqRm/IELbt1Kd6+8VWK+y2FbG
9R5rYuolXUNaOaFyIfllFcxC3IF0r1Mjugur+pCBHFXVk43d7ofdhmIWYNPDFHP53mGDEiHKtudC
72wpbEsbnPlQ+T6xCQHhb+M2wqXM9m2Sv/tvKahlFk16YPBZMZu4ucDNSZwIpKEksChjvMpVnVyS
c2waJDyo8RUp+vD8H9+16Tt1gT0UHzjCmShuIbL/dZ30Zyw6pcuEHoIfGTS1SnAlmz65wqKzO8vU
1T7h/nwVeSU1jPMTJa17lL5AuZgwgPd6R14izIwpN6ZYBF7Cuqw0bdH6ezCx5xZI5AbUMftJYb2K
0ZaTahlXNzMSYiaNdn8rCXQQ1MhynAkcg4OVtd+Y2BjYfaw5/9svK9u1shyqXcdvCF33XasyWYzQ
5DkDgWnZ5qzS0otLByTrVAlSTqk3IeldADvdY48GUO5llAJ7osCFkYOY5zqxSZXZxBhHRMcoM4mb
MISY4WHJ0UNrCAz3om2o0D68hJlZMvt+PbgeJe1S+HYsb1IbHs9oZO7/Rk6G5X2fAN8jeuoqkZz9
HNzJ6Rc1uuM7K1lyx+pzEjRMxGDMdulpSQZlVHp5JSX8HN1dPYpjIqm20mWAK6UuVNYD4lf5k8uK
MCuVfz/UGvmxQsbIbFqEnWr0C9om8+5+VtvVT2wxe2IoF/EUx+ZZFvkvX0G/dMYPAZ+VLZB1keW3
MGsglJRptGs/ZNjGELGUBeb6Uh5sQFUYuAcRNhrafUQZshr64v4m9AP7vYbdI8Lqx9HfZomfB9On
5ENNVryIDl2bgsQRpG2H9NvMxAifaccUi7g7vmu1ZlvM39Q/E9dQrXqAini6CFN5JAsVpRDqSSsS
ONCvc/gaZqONLrz0Yn+O//R/87l6CItrdhDiAXK/0Swc7lm7Cp+trLgOAsyLLQ+t8jmSzT5fxdAB
jI+IDggytYVfHz98YvR1QzdM1kxOxjq6HrLIgyLWsusRm/9JbDk6OIsZiCgrMeek7Hk0Mw9rh9ur
1MYmDZeBmCAiNWUO+r4vmaSwDw4PgaMws2P47e04BuoLJ5aB69X0erZwTGMeLk6fAN/NSIrVl0Bh
U2RgPlxg4vCGFl0MKmRu9iG7Gv8gZgnh1TrlcWSwp0ktMkBITTWDwBZtxudK5GS5jCls45THTFO0
kJy7yvQ/P5HyJ9e5SdC725f0dh7SEdhr0y+OFPIfpfvPOQ3Fiuvk3BDyP/CtZND0wVYnvmTq4EzP
74iXDOe8qAzRg0cYbdSEw+649FLq7CZmfMJKSQM0zwVgxNix5dhz46ECUwVZ6hVXXr/DywVGHO19
3G6w2m+hhm==