<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxgIoiUWCy/elLzVvBL3mO9nz9keraUD+ESF/1/EQnRwLQwS5GvKzqVosX48yarX8no6r5OL
qC4IuKmghgAMz2Evi1dTgEIF1IHrRBCAVrlZ4HRvYgSe2v7iNDCr/LkbbvNfQPYix5jamEaglyQ9
CV2aNsmYc69XKbIs4+BqaMxCxjczWiltJFyK0uwzKqQiwZdWN/jGYLLSg+OlGvcE8afhUcRqqt/r
Lo0PRBKHnLd5Zde3p6JWjJQXpzXV+SLfp1V6yhJY0u0XgRsgoxfFh4SSMg49Lt7OcJN4D+rDKiov
gU3J24bC0qNJ4wovSO8vhuDVYPMv/am93XOtGRpCPF7M+n7g4cNe8N6j7+EGflvHSMzQm14I9zev
fpcYRuA6tNIGxWpkmgTunReDJnXZ99DTR8dMTcRyCA5TMjb0pohBtzWDq4clU3XwnRzfhNd63jCr
ZujHO8GxfhBDsYWVseLeb328HAhmTPOBr9jT7hK5wHK9iFtyGo9Jmci6osrM6mBwItLImEK2obgb
R8qN11nZVfJhAk3OQte2a6UMxH9BO7zhCYAzXHbMZiXMQbDk9pVNSGwsSTtIriMccSGatvpXycoU
RY/vgkO5VkycAN9EBTF57c73oNbOY1QjxUteiAVAp1/AWyY4K+ly18+rjve1VMB21WlW45BrwM+x
vhZ/Tfig4VGqdMp20M5HM/wrKXOg3QNKOE9fwj2/PwYfGdTlUaZ+SFYVAIvaFn4qBj0Q4LR85PpP
imYZzGxMsGbR+h8VRVNIQK8M5J5rEPxbat9pUVDxd/0aIVEnPWVEn6ULawDrk+v/29K4iVNIa80m
uUAPZ6t+aqqxqrePheJtKsycgo+a0o/ekNB/5sNZEIm88nAhAgqgbXr2zk160/EbW5QOdfgysNRS
7cXOL1DItB/mxupQBgZeWNPR2+2ij8mPpiKjK+aMjsgPkJ+p/r6NhgVmM/WKo006kc433TMGfAXl
e7Hgqzj4sCKjN/HMcUW6e0UtoToIAHEncsyHia3RTkjG5EPhqXxJz6H8fEnAQq6ciNHidtyrfjfY
Am3PWC3mrbTvrkzCdRY83N9Zblv9K7RuwtzT3wFnN3OKDPPuA3RXMsHBeMobr4nXj3E+Bn7kZfaT
HGXIuW+IT5H8LSB6jlsfOiyWcBJuI51atTGzgzwcJfZJKNLktFVIVoRs2ax/xIwCZsj6vzwekp3W
njtPmRQ6N3PUHsXmA0RV1QekyCH5zu+nFkw5ISamKFOPnd6xqIq6FKs9w6g/wEPnCqoBrBcTSMKr
T1wFgCSYvORbCE+BUyf+JRqqTlcIPQi1UsOuPuNn+v3HIMd/aXvAgStbKoe99ITRqyRHQQtFgDky
+gBdcF9Tw6SmkYWN9uOMdCQlghfky3EP+dW/V604QkFgEKW71NyR9M7o+oUawU5IUEv9K5tKZ8vE
2aXz+Dnf01JF+TvDzptE3Ls/noy8sEfXyOUmNHiGgofCqYM4gFfW31PFBr8MT3dSv3Cmf6PfdKwT
dJ27hmyYe2Ybj1Gt2qDBmyni+8U9myTwSFvCn0NTcwMx+UIHe5SDr1guraLO6GVMLElpsmsFs+0B
zjG7ZIdvsi4Z49ZgYb/ejavoiKsoYBNR+92yvXSVNnvACGGbjjsB1qMFzd6nKChHmvo6kSSs+BXX
ibNg/EeIUjywlu9bzNmjOBGBKp5EEdq7S2+lCdj54jWN4n0PCpu/+d6uPkDz0r0eUR9OtSHRd4uS
Nb5ApiejmAi03x/5Bpeqn91uCCyTMlYDYUXld/mVjtRiRYT5sOj+XTDoIndk5QGjdHqj9x1Sxq6x
z8PU2omQCRbe8Rglpms+3R5O8S26whnfSmy3zG6/28wVLsLQCiy+kYJRTH00vrsiTkJnlJyjXGoE
LMeug+w3B3To+CckxI6KYUrqPaoocQuetsgwK2mI008MWnBCaTI3OK2h9EG42PszZO2n9cAgQeQZ
9aPk5+azf7ZJ9t/nESV/vjoilB3VLDYyKNwMvzUodRbmmtzZaGNDaI21mYIzdCqFX7KTJdJFlNDz
/wil1i9qljWYTdvnzQRQsz6tl2HiscwbUc6HqQEPGgddfw+8YKYXP4p1mj0t/dUGogT1vHtbYYOx
u9UTvz81tnftCG1UY8vwKMsl6z+dmXKx9v23IdaH3Kcewi48MvXqShMJPA37RUWj4j1PmqxG54E6
IaaODQZXIVRTWpe+TuBKzldSVLplRF0UNKkgo99NYFqKsevEOg9aU0BhHPlD6V+UVndvYZt6SMXu
5aWnAuJbyfzJKSryNWSmej7yqNuYy731yf5kHI0IwtxOB+w9gDm7fjd6kTmzFz2cbhp5l0iUPFZR
fvok4AiHJxmoOn1fpt3fEC1RIgeCWMCE2n8re2gqtX/0FXUmyqZqf2M2nm9d3J+C9VZBsHcMRyLI
LrKtndjRVggyUNMBGm2CP+BwhYSnxlQukC+CZW9gWA+6G1drSFFuyq/Ty6itI0UvxUAl7c+5mgE7
SwKsR4J31rYccFnrP0SYgIRpG94cru3MFrISNNLk55cL/ObMS25l4/h33iKBv6gpJrtAisP64q+L
e9K8GztzBAq3A4VaYdKtjFT/6bNWHatvpqSbbQ3KOn2F0crp++YSYj14IdAQCGg/uVpCPNNWFziC
2ROXpCcvfYmtRXIVIPYSxqpRSuDwX3Art7zWGZN6YrEEGX/jvYXCD3PbbstZjXRleG3a3p7LZNb5
0V7zLLxiX0fpePeQtNJOKeYFmhe7P8bVGhVIZDzouduQgLSTRgmty+ZVUDL2CaXar7g/Z6DNOD1F
/exSfD9HkdTAePnK+mUIcVwzwoNYlgbmxSSZafZiy/FvBLLCDlzeCKKJbJHdeEd59UAckajBrTT+
IeU93LglnyEjbsnr1gdxotJrmKbRiVT8dMLNg8SjoBVt/dui6/mELpCdX15sDG5yR33O4oNtd/fK
ll3kacEiTmQmfbdbevFFQeqOsnuFn0C3tz9xzKR8DbBgNfb3IaU/NDfIToPBHdSuBJl8gXYFgnpM
I1I+1jjTkv3BbnCEeY6Hb3buE6ZFh9xHra+uwwfhB1R1ttTv5WeamVQ12GuRC711sXRMD+aJCoj4
7Z6d1oS8MG==