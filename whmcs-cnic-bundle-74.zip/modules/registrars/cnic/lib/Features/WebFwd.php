<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvepLzbtbAiU3lh2+iJ06S5nuCQiuYWVVw2ucOf/nTi6uzPipt/p60OljMb1Cewdqe/QVzIA
NUjtrnutPlZWHmsLycQXxTvkYck6Idi/jiYO/nCxZWfXUBK5nNTerEwkmbRMdInCB1d78LX6QSM6
9XKE8hCeaObSI6WwLXkmseImLZP4d0sXV2fvFiCOH4OkXVrPd0v8TMs/CWbwt5ZZ+WA2NpCeV50c
DhYq4mExdfdLIBGiMIEPPBZmV/dTni4S6kotmtHCrQItKL42gCkSGP8WT1HdM1Z1WfFDpOV+0Xcp
r6SV4bmh2gixRkUg6eWjK7xS1SePCvyZFb4LTJvOEaglW7grFYKFXyi5uDEM3Tl6HF8WWyvuRc+t
AG94KWbIuqg9Wh357pyuaRkn9xjRzbWbdfUkQyjk/NMjtlCjO2b6YaKelA3xx8HkQ1AUvnuS1ZPe
6cT68x+qyIUpHRU5joifWo22TSHzY2L9qfxwMtr73o4K7BE+VdA/PZ7CwrqxTIXVFOrUQWH4Pb59
LvUKK/NavJ5G+31QqhSfjSUdOYin2AGMnB5cPccVWTQRdN/UojHK/r4QNVfTbA5aRtuAGLPL82if
xni5ZJkgQellr0LhDyWcUBaMfN2hzwLnJK85h8cxnrPp/Qi+6ImnAstTaJlKuApsk6Mm+A3u0ysF
lPauaPZiyoQ1e586ujrycU5q/rZSK336ast9FzHqcWwfwDLJWzGmQMFlitDdU2vfBPJ6LoUZ+WP3
V4x5BYHS39ixKEuXUvsTCWw+ljtJRpJZs0FUD+r1TdWe8PWZbiozIdxcyqLsxlsab3cVnx/IzqUX
8mgsbkGU85Hh+LgrplBbyWgnvSKQQvl6rsWTBFKNKZECM7uioEGtzIfoJsgI+7Bykj4D5djHgF1R
GqN9Pbt5H6aRLnkUB1geC4DihH7dxQ9UqjMQREuguCEnvyIDgnGXQjlQVOrdtuU5J+upvzUoHlOO
uKVs8BgmnCBjUIjqdEukCSWEURwJW02F5j7ERLWFgWSWa5rBnXACtSUNJylH7gDirgblC9Q4lSHV
cUg27prDCv71Bh3mvq3IdrneYK1+lqJ9Mrqg+pyvmuOOwK6I3s3+eLKklwtIfKa0wm2gqaLBDroC
stbwRd2mDpMWDFA8o+7V6K2MjkJybZ1R+WHGSwKC3yP2LahJGarogoY5H2uYFMeX2/K6eYXnNrhy
Ogk4RLvtFzPykeCnUUU2yYkttkf3ff1hmrRjkWHauffSGVyujUIWch83A+N/d97ePZPfDPfZZPlA
byyzTyDT578WCktwRUx5tCC98vfCdwCj/W0J1KJqN6kn3zPxC7SCkbRDgFP7bN8g/o9sTGKvgmJF
tzkcCILyds6VpK8IfAVYh2rHj+w5iRzpHa6Mph8/NMEr56m4yLiGDe+RzcQ6ZoLPUTicJkYwoqLW
Xs9iZkzXcnEwEeDLev2NdR8qYY1oCWOkKV+nU2Mn80SxDPG68s8bH6yVIH2d4ki3NfElKPQBfBwn
rcQoo9WgbVuryEcciIT2tNThup0XXquYfLWQ3+an6wstW19z+xVp6614WS3iKL9TIFL0I29z14+A
ElYHis446PJNsdix3hmOMXfIoqzTK6gxgpq3hQ6FqnvUrs911XAuxdar9L6cJOWbX/ZDP+nMv0he
+k8Jbep8lbGojYTn4dWXznFhWXFVCLVi/kUz9ArtZbWEz3qam9tSfze4CVfabkMcDI0+y771PYDB
Q8KSh/8u1VVo5FckU7jUPo3v90FQ7Cn6gn9M85Fu0peWMtHhfBJuoHeoSL4HSN0d648+zai8natF
x5dw6ZTMGPPgX/HFDBDiINNKMewmSqooYAqRvHlt3DBwCIIEWqhoLihiW2/2BX6QErYX0KaWt0uf
asySFtnOFxNiwQJsAoVb1rP2m08J8y7V6XEs0h1aba0JEQgFUzRtJ2Xb9TKQH+ckxrWJnxH9JEOR
jXEod2Fi7MgucfK8q3j5V9FmK1yX5KSetubIggIaroHNZJFdO6yn4pjztY1X96+pmxYf3vLfRD+Z
dPGjxIZHhQ007PBS1X7PToHvmZE5ZjVRxljfXpIxGFOYFdJq+Ao1udVJOn2Z4aVLlDQSIJrP9v/X
vHrBrja/d0Avf0S1qou6UOSDqKP8q6lQHI/th/t8y8ibfA/cJJ8/UxVkLgKT0I5Mf39ECP2Zd2vl
x952K8Gt4FMQY4TkPdAcZGPo1mTJKfA48SRxlr6EKez836bNIpZE8eax6VOqWWqs3IGvlTN8jMnO
6pU99m8P8M4Ul6+PQ8rXU+BZzcv+8xn25PRt7N7tXm+KrBOeB2JklJ+L6fnU3ItABsDGZYngfCHS
jeMzXLb/k2xr8AdPmr/DCN3D6ydM+lg0N/TA/oDOXKJv7NMCm1BwDGnYc9zmFYXSfOpEMQWNlk5W
Ej3+adyEjVPo3DsYfZgmBxyaQ7n38CA9uMF4NWoVZRuQaQDET8nbcgH/oIhxvgVP50nfQtM3WeOX
6ImYbJHKA+ITR/f3fua0thVfQr4efJ9grjAYBBCrPeUuGwlD2bT1cRExnPtS5ubhNrEaVtU8zpEs
DsV3YmmEgXKNgmDk6ip0OBwoxJfrKdIevmbachkcp9fpPHmqUldhmvr8QZuWqQiZqTHX+Pxu7+tm
ebadvGNCRGjoYkuv91m4WjxX/9XgPsp9N80LP7NhKfN+pNIucvtkPm/wjMgcStVOo8PJN8YOTGl/
zkUR3fY6j2MSNwfNNfLN5fO5XFcidI9ofu3VLCGOEyJKs4ztAXxlztBi/M0qXjR12rluanyvza30
s4Vdhp3gYKPOyVU7uGo+/meL6bxP3WP7Dd5nYCVficeAIGDPYrldA8i3Zd10cDM2JRY11zdvTvLq
eEPUeDtbRNRb/75RbBfdfq978EkuuDSlygLwqMkjO18oHhCwznVQm2GnnXVpPY8WSG2zptPxvFpb
/UclkJEwNDh2z3J7XWMs4Fh/GxqRIijn106AAKG1U8yiIQvoSZMesKcDkrxFZ2kWi9CjM7oxSOAT
Ttobsn8VJeIxmV7Gc5NIzOErJ9ScuR1z2+OuVFy5j59jTaJCt0kKIChA1qE2JFYN7l5IOKvUi1jl
NnV8NU7DJFT4z7NpaTjeLczrSB4dTH5yo9GzQ2UZfFK82Erm3VEo4sXvDGfS7k4cFSiM3dxnUfKc
zDIgBmK4u4/NjInVIbMOxH4o9xbMkjA7IlWiHXEizzk0d3/uk3QVJyrFQa9WBSSdTajeB08rXYYu
+k0RbCyHdxSI7OqklhzQ9HaGVfw2T1E62cIESOLboNvWBA42yrEmHodzEcA1t250MtSOag9xU+sC
fhMB/VBUnqbpeG+BbG3r0pwvpphnYsfxf+v7Z6YtSh1v0zn0IKj9y4v88tzkgOPgWpvjv3PMpgqZ
14WWPKQ3qK/1zXrXfOHo/Kr5FNrPGF4jQMxydEjApOiUEVKKKZ1CbXZsq8SahlgGg5bZNLD3CIrx
+AO9v7Ew5JREtf5Gv2zEXchVmoZeKnv7RMxV1VXPnessJNv4GOExASgz6PDZL6xP2XnxQnrnmKE6
MaOKaCGzR5+1fLPR+NvtvhNoYb4dAbqJ3E/x505o8rxg3yYebvHibBPpbGLAtXrWA4UwMAOVo95N
O4WYn/ZQN/5NNGEuyrn/naecSFqoNY5aa1VhIt2yHO+eFJZU4EjJ1TcYHaHmPfbdeSBDpd5HYxW9
iWeO6XcOUzB9CumZ4DPVHq3XiJf4GeeaRPkUD/owmUJEQ616qZaV7Z4VDtg0G2EegJVzNkLBfq+/
JO1cxN87huXeex83OX2f0HhS3NRluyYN/Pya2GcswSecz0s3doL1Z7VyI3Zl9ggMVe2eFxYS9cWT
uB+v3/aXXccyRIG3BlJwOXJd/5MeSUxUyCCqfHUm+U8D0X2xfnU6B409TPRDL+KdvriooOHRUvhb
JOaPiHFYz8gUkPXlVt6oig21p0dRaL3DdJPscvxtR3TSU+h3V+tVVkf+dNJMvorF1qsUcbahOFPy
GZPatmImOh322wVcD7FbcKCKDDFSWL86IxDTqVBG5HIAIb7m5BATTsxBP29+0rdBnrmIukNi8LgY
XKgpvHPDNdQpI8FRteIVXwxfnX/USr9sDZWKcWRetZEu3TWhVz+2US3rdR6OFmInxDoaCn30+Esv
+JUGWl+Epv7grdefGYBe/lhSubFmj/rUR6CImgsaIPCUwSlVp7cHiuy+Pdwq53Fivsn3eYMRl2vL
5XlNkVBt+aQ8Y2wVwKha5Z2hzRvxEv5LHKPaQx8TjYCj