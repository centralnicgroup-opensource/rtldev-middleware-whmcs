<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmlmdUFBLMRKaZa8mFdHSzGOcNpxHLn+4/Pg2LJk0u8Yj7f3zDpX4/MH2IZ9psTaUcf2iY3S
DUIGP98T+AzWkCnPYJ6r+EbhNKy3gQnOo3MjCMGpTlSzKxi6VsQptykhEPwjgvcBzoR1oNhJ2C7b
Vi9pQQ0o/dDm/xu4Ge/KbnmdvV634gfDWIQC7mrCwnTPCnf1h6XPpSth8zXsYcAvEYUgfaTXjPZy
cL6/hYDZWTbcK6CV1SHVVF4YO47//MkjFtlrHgjUyIcPfSzLb84c+UIdvv9URKOqgTFu5aAcrAPB
hOndV0e675l5LxuNYdrXdC9nz1toWRMwsF60HLnIosQoJcoI2EB0H1LZScIwrpQYDtwimDd9DDXE
AsigIi2koZd+WPo2fC2ig/6szpkpxuDEQONszd+HzXWFaNrTyJZIPEXGPbZ72TtJV8zOmz/iQXcf
WMHJUXIHq8lVcq9t6h1Rbanh3/GWIvAvzQmHvrcb9D0XG7ia03xvJHuAn7/Bz8Pca6kWCGbh7GAm
0nN1C8qfggkdLhdqNaceenZOl5GTx2pBLf04MKViXrJMjQr3xhe1LFnqvVMzUJaMTB0mM2cdmGsT
rVZb8tAAe1mkIS+Ly/6HLJduk2jlPwF984dw3Xh3n/9ph1CELdkdymTEyEt5RiDRs0cgTeGqJjxt
Vr2yXlWvUTTyUaytoLO/Af0k6m63uM/0+sidvu0jmiks8W3dkyqwohvtacezROZ4ZwrQ6MW7tSCs
s/CO6cNHK+PRZinnREquiphmtYCsoRXdcoCN/mvm2/2bLL2DrOplltZceqxhNq/7Or+P4hagMHK/
iXcztVbUUspd+JS6UwADLdtdMQ3GUvQlhRZ06tMBZw0pnVj1ttbP9vg2GfXSWmdrR3DMN0cH04xF
9C9Kc1Bxcf6qJXpb6SgL4hikh58TAEbCi5XSgqZjyvxVjAxZBoPrZlqo7Zj8sCRgVH3iX+oEVIjB
ppXPXJ9o11Z+Dn1k6b7Rb0l/jGUYpkTkly1iSgjSAfPlY+408azfagmq/z2u/0wqOFiipJSFnh4d
hZwYPDS5lJVyOEzgroJpuY5jSp5lLxAfYwOiOTz6Idx2TfM0WVGv/nA42Dva8ECJCOirzUDLQNCT
8u9JrhRUASjGv2dLTtOPMov+OzJdWb1KFsd/bxCKslPhKfCBAVTAddQ8kOEltQidgEYqIEkFuoZS
m+W6S6bvfBZx5QlKVk3PKZjpBX5mYZ7f8DQeBvyR8zkg7exMZLIoxwztrUW+DbmHgvTa07xvepFm
0UrjZ+2Gn5GgEj7udV4G96KZmrMHLx7J2kx+iTxjn3yUFdyvNJ3XDqzlQWQO4Fz3A4uwLyhd3rcJ
PjW2qakds2bQJn47BzvAfTg6McN759+EQQdF0Mvy46BOLGLiW9STW4mb1HWUq6x8aukpR7yWvWgX
aEjctEXLYtjy1NBIm0J82lobyhxyRaMOsE8tWFcHIvv6dEyW6AdpJnp/pOZFVsmmyQbPNPHHqvP2
94h6RFTAb1mh3Dn8jJPJZND2zefn9L1fUr2D5dHFeHce6mFPChW5AHWpayNgprRL6+THv7Z5t8YD
AMz8i/qntiMqZAwQ2znCh9zeSaJoBMG/dxN23w7mrEuEiErkbfEXBw1uLQCcV3wsDUexh5IpjwH9
2mXngIIaVvlN3je/rwv6Me8J9up7arkaGa+HHbOvc28cAaQIWtz62Mcl/soviT9gATGR273X+n4d
bPEW7jT2igos0vRNFackcSzLdWBic4cps1bOnJEO5rmsJKuwIiaNyn1MQhjrE0TWwIqPl2W26U+b
aQ0o7HFKfLtZEVHfp4ipImfyyKTkMBrYjrvX0JP42JRaDVmZUd/RDaKmkb4KatPr3KBMXSWa3IF1
7D0uMlVkPo7uTlOrGaMsypA1MyeOrlMacydjKX1tsxPE0/6mTXCD8NOXMiUP4b13mbtj/yEu6ksD
1Q3p20HGdBpFfohTCU33cJtNUToRvKmLEkImMuxZDtLJrb1qVODKaqv91LJBQ0drSYCCIKboU/z0
s2J6s6RBWuWqybuz5IhFjH7tWbIsoEopNv56ZGhB+EHAhWyx3rtVUrjDDcStx35sJftAuDQFVM6a
e+wVhyApgvMTvYRSdWC+3TXjZ37ZtqEHBzeI+8dXq/I7xUzz7secfSi8NBzqGW6VaISjZS+XsrT7
4CigW9SUcYoouNsietoVtgjnwo5hsw1aZAPLw7vlCkkDu/Kh7ok4QZUnpikBqk/Ed+8LXGBE2908
IH2PwF+R7A4Vhn9S4zCQ3wyAuaM2Huf0wJt/Bz5mUeH4cLmlAyGhPiKOAsruCq2JBHpUKU4xs3wv
MWi0PxOJrFmbdJQ/L6tFA3WH2lO40F905RVs2sziZyywOXMOQWLuW53+50ty1gv5IWLBCaULO5PC
MqSQ8TA40L06f/4dxA23bqV0jWKXH1AYJs3FINGlVwXrCEkrDAhCVHib3BxBXRnURYgGV42TQqLn
hCoyxh7CauAFHukdPvply+xQUzU1RRvjT23Kkz1k6/B2PvIpai6WmziWksQ/2wQQU+tXJQyUgjk7
Zm9PCVcy5WlHmdlkrar02hnh/Uuc7tDBNvCSQrjvVwRzX2heDJcLwYX7HIymNZAQM/X8OkwsydoN
Yff8obEpCiovWN51NukVq2y1FPNBqoe3XCQYApNEXJjUMcxoJ96JNsoMojAJ5VGcQ3sSaSRcOlyx
DqO9OBm2O7u455K8BPpoCmfRR02zQqUCZYsGrZZoEW5yIEp+8zmU3FdzR1zGCuyxYSr/SWaeeDsR
YJR7WoeluUrYHcpczYnatAkp8MmqkfwfxGAMJlSoR8tm0rrZbV44VBQidhPFk8UAQxdFSgmT0xS3
1KKcx0j8jXCQYfngjScDvAh68+9uaPO/s8ciBFAZcPVcEd2jictsvxxL3+pQtE2Xz/OQ1eLm8IaM
250aFSMCr65kcPRsbPFcW59Dx9DlG1RVtYPwDgJED4Wasw3SRbzSoWF3CONaXNXLKFpRaSKY+/fK
jkROrVWhR+cxZMXTze/fAIpO+T7OpooWlH54RZ2z8KcVM1n1Cf2rtXDsIagEQIwLBrzTxcgdzJxf
cvBL/tFR/WLi8/5n69O4TEflxD2/dgJ/7L/RK64R/3R/wNBLlMKUG+MWoxRc/vYY9Foj1RevoG4n
R+0cBXLH32pNK4/QEvhgAUXAxN5GddviBrd4sMK0HECWWZM12yzxXCcFuj0EYZXs16QCrA0V//U4
y4vOE/vkrJCiR+fjj7Z1Wl2HMmMtYKnzN+26ny81E02/bTj9qKYqnskKNZXdL2bRjR1/EhbDqJjJ
Ui91N2Sv+ondOx0sCydVzORyNmCQBs8WWSZUJL2tTlwlG0RjIeyP3JwbpWUwcsHvju/oGOr/0xxv
+MA/tx9aLl+vsa/JGxUvwodjgDJXY1IGmQnznew+WQfys2NWpNKoWiA8WaY1rC+oo+he5NfajlVU
iSpyyfJScM7ny4ZlxZ+RJoH5NLmkjVhhfOmgC+NqTujmBRs3Q36URLfISII58lmEGp/4leLUA2N5
w0aZttkKv8rDtnII0lYyYADKyifY5YGMaIX2ZqM5OY1R9ug7tRuXWujHK8Y0LbiwYgaH0kTbyuNJ
cK2GAfPvqAr4PiiTA7Jtenwq/BOE5tmrOXa7zHwkmx26DAiQJSKjabKel1TMQKjpS7ngXmye9tYm
KM5o8BFnWAfD7bNbtry39edU+FElElYnz5lNU29A+QAQq1DzBBNmAbnxn2BLNmUWPhiXg36IPj9o
cFYs6RooBaZm2QnQyQXlfIyF6F7Vxe0vdHf6qjb+4+jYWTA+s9x4L8qr8K4bH/q2aj3MPLEf7Q3Y
dySC29YlzHFWX5yelsVCDAe+CC76APzqyCyb38+bMHt1jyxij5WYuHMkYP/4U7DomCpEvpthJpQ+
P8+DV7gSuo2IYg9JRoUV8C4PshEghTkkXnFpOot8LSgIx1k/ypqVqClEgRVX2cXTn7SPtaUhtcVs
oBND3Yildv2hfyVH9KqaDF8nVapBWlyRUeNyvBcNrqsdPTuUtQ1Hic4S8uBJuZL4hEZmPFGwdlhJ
YvCcIK/BkWFkDbzYsmMCXeSk1aLkHeE0DGQ8kkGl12Hfald0TaNuzc5xM4y5I4727lRkYgxjqfnI
a6WFvn/gV+fDx9RoXvjE3EusCxS0LAVOtP8SNXvo9yvc9gLhHp29u0zMoU/ZJWRgxf2dWtoVZNOP
m+9wyxKDjZclntcd24lfcWT7U4rFPbgO5B1vrQrq