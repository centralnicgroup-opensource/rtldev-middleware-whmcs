<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP++5POCqMbwrmKZme69kf7wCo3JnA7gxW8AuQijG2A6ICeCVVf0+2ZXpLVr1fX1pbFtK4CP9
tkdKBQFJqFspMrwFLv8hOhH6uTgbS2kir9s02WnOupc6DYmoqfEJ3cfQDQ82EUpJ15iXnrQNrTvs
FzNZxb9NIE5A4qjcHIykcfL6Iz/411Z8Dn+iPHNrIynGSc0XUa/Fri+/HSh+KAlUVxmqqgbzG/hZ
Q2qYsaq8i0psPYjXUXom9SbruyUu6qbrkbLPgrxnAPcbprMKWIRvvAVdaXrfD/mcRHTaYGIFrKiz
QKTN/yqKctLZQ2UlwUgdOck0V04rxDMgAP5J3kFV9EEB1JO33I+cwj7GiIziU8gvhPk8ByEZ0BTT
BzyjA5SRKJOfjjmbVXD8Ty1anDuSJ5EqE1+BCROxJM2K3LIt4FpoZFYexD8gjOsQnAgD5JhkIoxN
x5ZJrcrRg3sNT0CCa7aDoM81VY9VpNtdHA8MgPI1Z4HvnUp7DH2YzRh6hWpJbpPgyYK/2835fCb2
ouUfyRuQtwjautWt8/eIb+6dfgs+Mlgzn+icbFCW8sZ7GDI4JGfYdf6+8QrzmbjNyZeJJz4+m9Wl
9AmxgmF2dUILj6DG9sVIqAh4v0SGtbtD7a/UKl+cpIJ/CjEpO8qV69dOmzAQRNezXKqteC/N91EL
XmvM+OTT3TuCnAMkuMw2rx5MT+huyDUzkOKN66ggtOpdi8q/CTRT39mFPCpvDhZwtnms3ZXX3FiG
g39LGYAdJ+BWpA5bPNvCkpfCjriMubcmadaF5t4WT4Ixqs5ml7GzRAXCUAvgdu02go2WF+gL6CUw
sHNNJwwHIWMluxSHfK915YZ6i2qCoBJXX5SUOM3JVKJk3fGR5OedGZ/1m0V+/sGSeeL0lLkGA0js
73QNdKPwOfGYL3/c6erqak1dwGQvGHFmcMpF2cpprtTuigi6D7A+jfYdHB843prsxsz/+BsFwYu8
KJU+ToSCC9NlTtFOsDa7Um1kQg+IA+202/7+CX+D+0amGGL5H/KnjcTJ48INZMNNhO8E8PKGXV/j
oEdj8KSxuBeDAkuHJU6kI5B/8dBi/WkBmEp5v+nJ1tHr6LlqF+66YFSSlbzQe6tdejMsgwfEG2kL
BujaUoAz/SKxbAGfO+LpVrcrmD5zXAbd+nGerzTsNimXUVt1LNjs9FLuymTNNcrO7nedvtZpKg8E
HGYh7ZZXcXs6nFSbY4wuwJsKjMIXk1xrUirJIrZAl47adsPk2Yz35NElFGMHJaviCjFf0Gu0iQ6a
T6cDIajyscqxMltXf/mA3yWD1BnUGKgyYAsw7OzFS5ObLfbw/xXTfAaD3w4pNvxcOM2O5AgNR8US
iSdxqUWFu69xHYE8PUoQ3aKNDA71qmHm5AlqiQJopPZgjLT6UD0ibvrjKwwF98QvL47Ncn6kC79Z
WEM8vEWGx9PWv+t0539ETrrjxjis8YpRVmL38rDh0GY6IvTm5djCXVKoBLVXv1PLsQkIJl61ZQrD
YXU0K0fzMO7XPbLd6pDP5aLBR0dB7gbhKul21oMOcJv8bpAGDwsGwXHl6A+CHFW8ihwvERpXTPDw
pQ2djHK2TrJoBoZSlvTbbSYsPa7rd7h10Wd2ezeKMmtjcndLgIKvcIij4TutC5sns0IXr6IGPg1H
lGJduQlst1J/me0ITGvtxDDSrjgPgHCeicdNlPcWC0jAFMfxRxG0cu5Iw2siWveARmTKjRFl99Ok
jMQY+fN/1vDcWWfIe8hdgg8gMq6XhJIVRPTmHQdYNg7MVdqg4STK+uuDgzLQzpU4JPxo9XLJ6QNa
KsXwWSoa+Lp6Rq+xGP0YQ8LbgfJr+Mjoi2kuXYklUUpaFsQtnKVA6EPnhM6O/3R67EcdX+w+u60t
k4P83wlPceZdv5HnyT3J12AY0vO/XWCAZfDGyx6I9/YwKvniZLoKt00Mm3XAFdBR2lBYm8pQvcGp
58X9VePiyXr2bNJ+YdissujLGkA4Ond2BEJc1AjM6cvjbUuf91oEOMFumn6greMBMnp/+xNbdLz4
9cHBAQmJLyZTX41dYoO8pWPJza18heT1uXO+9/kdQMHEDciEtbn4J8KvSIhjXPFAinH0DQjPkyA8
JqG47VxZJMsnqJt2FX45har8kOt1irS0EN/1/oeFSLlA7/hbVXn4rFIXbdFchlwbLcLBgO0LYpqK
LApHBMPEkCatlVDNT0hHueSpNni5SBbBxGYw5zROMC/CifIR0c67y7XMCDRU9wVznaMlTyVoUQMw
Y+W04pPlsJwMtHlIxrZzTENA6rHIQaURXELCJpz2Vzn1/j37AT2/VQsU0tS6FReaHBxgyWStrevs
QjCRi7ATEiC7Y4tsmwel/r5o6KXvknYA2AsQKqmWm7PE4lk7Iz6XlYsde/4O/WRFy7Gl4vC5lz6G
EUsw3nPrcajPpAcu03NRDB1CC5J6EC9WzYsQBn9d51QiMHpa+39viMF4Je8R0jk+fvCdfGfTvifB
Lf+KPPL788fj59U+9lIBeNBGv7YzMjaZTN1Mi6jJvhXxA8D80p0UMw8maHgOAffbyNV66bxPzDBn
D6XA+k0nkHk22lRqTTzrWo4A+jIoe2efV+pKt7lmU4uhjIEe02gEQ5lAjHUtMEbMaOw0PIBHt1qz
Lvt/hajOw4/LMmAcpsKkMGwC1c0VTeRDMpH0MZhKhIT5xlA0fCuq5z+3k5/tpz10TKlmf51J4h2l
nvE/H6pKwtu7X16ZxGQ7MBd0sz7+R5G9MnrtYjdr1nPn9aOUkGqQRe14Bj9T+7kaRO4KIAS7kpfn
FxTV3SDTq3IPsamMK4UahOovPoX2eW/jLJfoHFyayH+15w/3BCXOJcIMYyiTYqJ4pfXxMmq8+wlK
TTQ9b1g+BAKudEpCRYuJkm3+SCn9vuVbs11ObByTio5vz1do/QEcdHuCnc3zDhfh4ESKRx2Zga1U
VYPrirVHqgOTW/0KmeoDd90o18+UrlkeoKjXdgm7Uh8SJBEhRQXMxPBRaSUgz9EXK7slp2AJHgS0
HKnN9ZQoDP/u4mVB4PB4UHor3ZkJDtFKEhfmsTNN9O7W9a77MbXYxUOjbvpDNnIxn2B31QLHCubn
QIulXw3GKbYlS+Z+GbYddu4Qi6Ygh041MBga5mpf