<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvChk+Qkk1/9j+OknVMX5cvWODkzpby+NVHNIgcWTkEAhXf96k6K6jEA6qef+RkmQ5fbdM34
jubrlZ+N0KxiTGSB8hySQc/mfkDbrPAdkGEQTBlUwtKXuNK/9DXeCzWpIyDDRvDZb+aAcKKx9iad
RYA0f61RrCc+oqRFw7/vDxZlwx3IUA/vHCYhe122RINoDlGDBXOznqDyrQ9M8BLai1J05UQB89+3
CcOmpop/DlqOtF7XCp5ggewcYAU0elrQ1nEU8yDqJDMajr5H0gZBd46I87J4Q/bOEqmiTlz94LeP
Oo1eQ//vhiX7Z7NTvJOLYoqrnKgI4pzZBYEk4HFcXmi0m05/HrABZJi/uhD1vyCrbe9PVIacCei6
1tnn5fcJpy0xQxEKkeAVJW2QzgbS6gcamKu9PDe1GoPojZipr3AzrKVTeRDxCBLenKq20k2KAjoS
O8+gpc+mVRvHAyh9KeXLj9DIyz7QdmaI7IehHVOeKsYgiC8FrWEyceklslydCl2wV+CUwIx9goW/
0hYr3qUCDfRs3h06sbGJ9MvSxD4L0mMP5S014L3xmjzRJdqeicd5JgInHL16aYApV/CtvdinY9DW
jiVfiS9TZoeVYQUcoGtEGKmeb1Q8DHUDZjZV7iU1ExO6BAoO4ShW/ameXq7dxbtt56QkqeypxQbP
yDtjNZOIJ/sFIxApRhoXntaTUb1SXi9Aqk5bQQhBqRW5ymOYHHhhP9Z9f3agXnqZKbDAi7AmhvVa
Vuz8lH7UceGcu0aa4XjJ6wZp/dETT5Bt88hfGR8lZE6A4wLcAEARfWCtmKRlJWZ67x+tcBOXU2x6
XwRqBpGTkjBz589PHLWMH76qZRUmxBv+m/GzBj9KcFXw8IKPTutkk58+YfcbTU6dCgfY0QY1gR4v
lQXpRJtuU+6D+SirrmI/tx9gxX0g17pbT2opdMQBvh8qqcj0P+cHeCGbt9XwBgGC7QQOcf9344xW
2URYgSfzLZaHvk0Ktai20TRx3LUxpBXXKs2P+d2qINaes+1L17ixoORsX5C6nO396whWqnFRvzNf
xiRWgDSEgNhYmiFUJf36eXGfkzUDRu43Hbk2RgC38/wud3K/cyKd/bxG4SImzhiPmMmDl0BsSlAr
txHBJWqoaiEcr+NyGEc18v0OwNkWXrxaybYMNb7OfbwgM/IuWyH/zgd3xKpzuzJLD0LNEn51WhAh
sioUDIXr83NVc/OWUnl2HdrjUtCroL1JgWINDxCgqGlpqNoMLC25aFHc0pGg78OD5pJHtfZceRqe
boLxjvky6vM4Jc9l8DAQQIYbVjNwlJM3xlYi54uKxhKOoEtldc4rJXzvroFOBZif9XNA8clm/T0u
hx09o/mctnXOjp+qG2lzrlv5Lcw0qAhB6vjlxTZ/J1gwpVru1LjOUiMJja6K7cCe88vxBCDQ+yb5
ozMD4zxeSO/LiewOrmLRm7Q0fxdLsaEaapbpMv+k8KFSTKqxlAR9OX6pbJDQoXzo4f4HY2TRhWQ1
MSLc2yDgW9reKrQ+8+jt9gfLzLUUvhVrVIFfaerohdFJblaawNk0EoY/OCny2fKQtpLaMQo2hviU
m/ADSaJW6l12BIHTR+ueZ+a5eba/CxY+AQvKEaR3H50/Jhp+YUBuA8KZCyqUhammBLGGOAb4DpF3
+27xsy8KIuo2nzCOoFN6TXu3U/HEhAuWcmKSJWghTxssEZ0lzOHhAHL28T8fGYF5j9Nm5aaud5gv
NIKeLMycDEQGwtan2eeK9xnZ13Ny6rKsV7Z1bVX+KnD6/49FuIW8hKnoGluTVZf/A3cYORwNQ2lX
wMD97Q0wV9n+y159llDmb/T0aAvcSCnNIBP7Qtpdte5oTtxqm8wGDFz2gbnCpS8C7LxxMeOh+tyw
Gx1WxyvFBukHLqiRGTBwEez8E50Nf9wE0czIdQM/fGS3UgcDqSevZWRTi4iVBdEqOg+9cIlZjvYX
/IUnjAU2HtCO2fMjhcCnrvUa37ZgmJSrHWz/Sy6ElGN44szn/b+KjekDOSNvlfE2lcNAHJB/DHIZ
dyhdMjCgvpCs6PCz+ITMxSINmj6sqcG/Gu26NkJdmCZm+PqFIuFjR/Z9P6k7xFD3gNPxLcq3jUf2
48jp2+7SCCUekL9+IMaZv7svWAW1nXHS1jQIGn/jyPosLIMLgpTox6E85W19x+Eb8czBzC4oAga/
FaImq8NWhG+e1X3CuWALPcwAwPBx6Rm1gaK4b7Pur32Sxca6VSUlHAHUyu2RRh9pI17vY6w3srS7
/HhDtJE7seqYcXHiXHjJ+6jWs4I8X+z1QYibLVP1CUKcZMrWfRw+A3Ha6L+5gaIM7Ua49FVJkyTU
lxUzsBkYO2BpDOgv6OA/sLdxdfL2zHO07wH9aPn+fzrbu3z3zO1U1kNQPLs1zf+X1kQhqerT35Yk
/WSmBMn+pVeT2ibbsaRDT7uNlpMR1enSg98+kGtXCs5Pb6yk5zqQdniLDc5zBrlMm0INcYt3xG8P
Tx7Up+Xpshp+P2OKjh082wJaR+xofoiYxVEtr4rpBc/QKGGYhi3iP42QhhJou1XoBrIrnX026jNu
wyteHfJTPYe4oNW83vaAXXq4TP+gD2skVy0XKvfHPgmDnaYMJVHurcBOuRE9Yy3IrSAZpvv9viJ8
Lt2R5YqJ/dEKyOYKQrSiIv4682QuvB5GAzMwcgcvHSqJXqFpUTD68xpXExjB6oUfxSxv6l2ttP0d
s1XkFwwpixMF1UhdnzpMI9UwXvilw59//O64L5Jjagtg+lqVpYWApdzsse0q6SJa1/I4gvFQqqBV
gYPE3dUfwK5T38vV2hy7LtDwbV4Cfk3mIv+WqCUnqv0UgoG1qOje/0YLNMVkkw9ysHfeluUxH6ch
+MQC9mHaHfNfPHtk5qAR7uu3XOd5l6uif1dMS2TC60yT76lxcV5kR4J36+SYBEDXaepsryp4gNyf
Kss5gNN2R9NhpS/tiAqtgh51aMooH+1hYsTzr2wLRUuvJDhXgvcfxpROaMKjnIgFnPVma/++Pyzs
EFNkaPtpdJ6THJ9hPa2cuaRgDOVcU4Bn2yKqbDgd4yDdyHiuPtzMubul3glV/e+FGqTRSqeEaHd/
Jk1hqoIooCmWqxLF7fDruzciOw3pnxgLDyC67zDUcOBZjlYx8pSnnW==