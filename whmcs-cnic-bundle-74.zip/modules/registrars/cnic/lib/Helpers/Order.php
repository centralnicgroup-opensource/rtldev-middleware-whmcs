<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoANFaBBDODrabchOMdWT7nrt7h1T40MBDvYAjFexM+pSYpmkVDGN3JR40O8b3W7JxLtmKNh
RZrBxFqtCPJxjQD6idW603+c/JrZljCs8sYKHDglVnoFAWCrUN/uh0F5cp79wLjymJcFRNy/ghuC
r4agnW2EFqCXGAt+zHkXLShvagpWYybj5jfDT8pFTnOpnZ84deJF4CyAlxJUuoZp3yaYxFqpMlrb
e0UpTO8VKL1ySIUYcPC+TyWfLGK1Rkn/Oy49fgjUyIcPfSzLb84c+UIdvvAnPqzG6YR23BULVqeB
/TrdRl/yPA9YtWAco+dCMtOX6uxdEJR1PPTUZKfmPkYnlzmblus3zszArCXf63RFa/i3VHNW+Opw
709fsyzLPJBr7YcxtTLqf5OG7WbR0M4QD9FzUhe6KqcI3MUyPbhJZj2rnJ8UH9vumgxzwkru9KYs
Keb3Q+Re/4qk1H/61g/Nmymkm9nQwjC6vBdRiSr6eI3LjRHcm/gugMQ4HiKprjQ2tbYTH4oLp2BK
P2YzPXDkJh9ckKgH17baa97QErbQy6rA1+7x/edBPuj/HKDqU1fpXZO1XAHNVGyMhGGZM1BtCqj6
qY0EhW+XkP0PxFuxr3BJC0A97N0oZ3HJBX7Q59PTxByq/r14jE8DshPanzJScKPUA4QGCRYu3vmk
HdkM0G1SrdVeYwqmL76qcb9oHNG/HLYKiydB1Kq6iQc+xHFWWAd5uYGewrBSgK4R5jQgsW390Jgs
kFGDy8ZCxwgHZO6zSXe5etzBEj8MHq6wHVW57h8cBZkJqAZzaj+YpQKR1hyBytvZ1bCj+qLoFcfY
OkqH61yjScRGu4AuExWxZtjTkKWLASUrn1+5a1R65ur7KY2QjDrisOjhlnIWLqiO6btXRdMJQGg7
quPrG82i5Gajk4NyPOt8L0Z+Rg/VUDQ0T0LNnYD/Na5IlbMmgKam1P+I11gYXWm0pvdE5Wm3jVsI
fr/GFct/hKICEXgcEFEmOUUvLoD2akRiWbXhFUO2n5ewwccy8WLdZcfF3QzGNYruMiVqCdX4/z5Y
rrc5TSdRrFkx3+PDnG8P4vPkhoFvUF6iJz8z729AhPf5jUGmrOAsMK9G4qnaUpkCdIAS+kDCcCBA
K7Nljyucx1fWgmugqaonw0W+cXyEJ5/+722oev6r9GsqQCPVX2M6iXSQ1Skb33b/MV458oGVM9/L
RM8dK4IH1YuK1wKvWSekOy8WIHXx2CZLfXjdYIx3mxJYragUJhVlLDQIFJMw7ruwQ4lhyayrQZld
/mCt+O3ZrQgwSZC64TvC6GjfLPa538dlP2ISdqTQYD2pDV/RQYz6fp02IyC1rch/XQ3HTIqnrEeS
WVanyBT1mNHP9VPL0d1WmbFfpNX61StqpIBQsHKWZR7sUxBWTJFPusYPW8NNvQ7uWHBC9/kDKT5Y
zBt3ygj9M5oWrj/PTQzBvhhMpIhm0DVTuoLtf6vZLjmUCoqptPUeEUf6ybLul6Xu9Rfw/fO9Dfto
PmUz97pFq2lLg/FhQF4pXshHZOeD5xTchLqF3Hazk10nEE++8eSs5qbUACm/veDJ44PPTGTPDHNy
EnQd0MJZMvwL0gjMx8rAMDcT71ensFdKchfwU332tB4Zc13edRBB36h0TJiMDZbj3aVT9jlkzo6n
2iTB7BqV+EaXKAi+8X9i7qBc0dnJn7dd790aECHTDnozAGnHsZCcInym3dqYEf2m/tV/XNonYWSq
DKpULVPva3j3RKKjESCz/+8L+5p80jR1jbO6698vQhpvcvqfnVj6ieRZDUphMG7tSRkITuPNmAkn
RqmiBFnQyZIs7Ine1lh5DsssbWz2ycmjZrD5T3xblngiTmEZz6uzfYqbnyyhN6V0FqCivyGTdjXv
WcGEHQivi2/BhTqlRKLiXhTI+V0TYuvHO/uRtszWvtmIycH5wCc/n6fCwZqMtwuKn/KnR6U8N9Ra
/s1pWTptQQpQGAgCh8tKIvK+uR72EAby5g0Kd+z21d+WohDzvKLEOOtvBDgoBDacqRcgHhdgwU/B
onxSvg2ObPj+fSN980MR2FnS9sBgwlLXg1wvOzfQFSV+MKo1/eRfP5VocoiYxerbcswPIt7t2y/1
jVdtXIG9BIFEUBp5LgVCrrLTqsfMiSxjZoyft3x+pFRd5VkS2HRk2V8NdaTmPZNqLSfi08b2Le82
i/F/fAlnreToZF+1fz1c3Dg/am1NC/ZMADf0QXQhxJYxMaOfwkfiqSGw2QNPavxY0FGmTHu57Iqq
6EN/z12ybAPQ1Wt9wa2mYr4haZF/o3q6yO6noumgxVaJ/1uvJXS1cuLLuskJNzdCp3yqEsByXAYH
Bp1vZFwjFcH0j/Iy2enV2/y6AiGL0PMZwj52fW2lsHkF8R9RP5gU20orXgptco1vSJM43uIwhTZw
9mDW456js5G/2hMtmi1TW/eVT0ENZTcFrj6hibzCkUcT+j1axjLVR0PWAmU+gDecUYvNvV9Z5a6t
9Pl4haShThvbS0QGy8eg1H8kg4O5WaewyhHUcKj2xfr+Njdf5EOAfKxdtpW7PyFnyPjCo3VyyZs4
WSrFb+vbORxLmD7NUpda+gkUYE40OB5wQBltAA7XQcXS6MpRNEFX7mVj/j0CwdjTEtqFVNi1gKnR
03rh2o+5UpNENxQuiqrHLQsrd4Ewms4Damwa+mSB8O1Kzhav2u75a53i3S877Vn8GjnZsdNOjwAl
Bkkh093sW06kNBhQ4FtZiuhYXv9VZXOMhzYhD1y3kFUneXqx8t2YCIGYr2OI/WURkv3tqw53rUTA
C3r3lSKvWXxSJt2Ge9QlrSo3HEqs//DJtKe5DQHGCUwkzvfvU40PJ3xXaKEsarapAdag2/ymQUEv
fXFxypFCLVNYFcLv57/ZbMgxyfY4YKqaesBTrUF9XadftLircmahCVdXZzSXBH6GiQQV634MhVlt
YALYPNtnOcl7bHPaSX3ryOgmN97+IpiJUO8kSAoBw0oAcDZJsrx135muRCKNADKc+1G90CmTWcsw
gk7QZ/wrMuMlJ0E/j3NjQX9x2HDpBvGGE1gr7v9ocNMOSWJtRoGc3RvX5aQOmX9GC13fGxZQiUDk
ykHfya/8L2SS8ahm6FW1AJq5xwoPrDvFfhrP94W8aK/XSFJs/LXe6YmtxHWK/VvPk7A2wt9+vyw8
00O9S9pbqYMZHaTCzuwmhBYaIgqXbH3oYHTKAYN+1X6nhcCZoyfj6/cAIY2MIk62KKgy2yf9mFs0
UDuSVOM36meSZuC6dajp/sf8c87cl/5LsdfNCL4RRsIo7yokhQAXMR9y