<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP//DQ4uooVYo1PIcsn4N+Cnu7AUAVM5x6fcu68vnG3MxGluO18lnvnO+xt5KB+raVzkZzIUF
XKiMG5aMbnGuq9l6iCtLjULw/DPXgXl3lLEQbPT66qD4XTyhzwTaXIPeut28HqizK68oE+SxtCcm
acyQ1v/IlYlSTnxs9yMDa5xDt8WB8TvfpM4gNy/8ydtIJ97JbLodzigHKupPkxmEXFxRvlf8SKtT
ppMpm4BxWkyWhFNMPUi3qPA7VutmoJIjKX7zmtHCrQItKL42gCkSGP8WTAXlXTEDesLrMGbE8DcI
PeXAZqmOZzA4Rox2RDkNv+UcFwwRaCVw29djoBOzd4bvg3QBnrNcL/ks3soaahbHnK/FKGnfMJfR
i0fVY25Tcs0tUi4Wyxn/RIZzlyMjGRNrbhDcaTNcew4AdWxcdLM7M14pcZvClQ8e7fZKeyucl024
MMn+VlVNB/1p7OLYj9z2zWe64OM5jIU7csu2Qyn2Ce1aYeb2Rub806QVXQKYuwZJjswxpnavwLlI
r8v5BxnsPl6o2dyNGYZGo5e4eaXZKgA31WOtlCHuxr1nxdG/tpOIuyho3WVnxnamz3rWv3PFVHlH
ikmg9YjSh5rb9FYbtYGSi8fkQQHVVQuCokSdEc4Vacx1imqz1CGkSsUBhIqJ/+qSlW7Odv/9vg5y
xzgGmf0jI5U+bir0u4Eaft6gNgRVCEq4pKzc8dE6+LTdpLsXtDD2eOrsMbhgackzI+/8mAiww5U1
AUoLCZk7s4oO3quLbRknmghQzRuJlxmm/bQe+A4/cGBBmz4T2A7AvyMFS27w7mZaAkav5RGRImlP
xIKJ92T8jz5JD6SU8QPZ7dG3oesQHtTcuoxgEqDdJizH5iO8+a2PkqhoSujxYqPRnPTgA79mWfh1
KmkclOYdYJi1b/sZzfpjTDlamJa/y+CfMJ198xZBHBfFq6bKRkX+wLvghrRKivX70w5TnBPSG5zU
7QOHH37LGpsm+Vtn9/z8lpGgva+8FcajvyNLwbo5jXtmNUTye9jF3vqg3oEIP9JTRPaMSZa+cDY0
/3tsxSjPJBordsGrGYZsJVvdVRT9OFvYvVulUHez3r4LvOq0LGHm4aAtTKzebrAnlmeCDSJl8oV/
e1cLEp71lCVfg68zB8QQT6yKMc2qvFm7nJehNrRRMOwkkjn3PbavmgcnhjsTkmwZ22rb11ynnMWh
tU7lpZceAjTqB6sBMaMZ8ZVygBS2COSd1M5Z4bilVeKhyVzHZ+yhgIGguT02M6KuvS6WRUnG2o3V
yUeQN/GiTF6H+Fe1APvU/19liLMitEiuR0dCWrQgemvSCDSt1QLxWfKH/+BYh5f6668VxsJRBzwU
Nk0Mv351eRadExA3FvUATyiR87enp3wUO/Z0aXY2qPUClRakmM/ZtD1vGIs1mvjrcfmshEr14G//
QZS4Xtlf+9LG0eTp4YXssB5SOD1XfCQ7Ag8B38910nWVjZ8aEx/rVaz2I+Jp+mcHHkLhpcqE3Y6s
0vNTI9xGrmls5iRn7oKSG2ZVmQWdrhFRHuq/V8gafp0BFiu7AA3j4JF7KOky3fcqYYL6gdfx0Mf1
xHlGYem1+wXNU5Jxy/9OpQxO4qfaz/6pbJOIYRrWPJtewf/8gXpjQZlZpAfRUUEu3BtlK/+3DfXt
3gG88VvpYLxIMuC2vGZwpHh52WAMVY640YzhZ9X/SiauhMbCDou/+l6BKVfABvzxz4h81dlSuVKs
J3NUv/aqyAbpQkB4KUJj+sMrDdTH6c0kuKiT1PMdl2tgkdC0v5Sq9U7qgDxJhw+UsU48vTe8uplH
8WxiyMbzfMk6VcFPxo6Oku8r/h+gUMWg6V9zgi8wVfrFvsBBVn1HTond6F32TB+8dnULZOFtTLXW
AqVpr7/enWvQmUL/OaKVeugW4okAY4Ac5QHnRFSgkKjSu/R665++3sR7M8e5fTEIaS1PEoa3Ie3U
eHHgDbMIBS3U+d/f3PqP1Tin979xTL9SeD3+LKi+buhEdmFVauXgUGHnr1TXTAf2l/L33nxooJg4
Hu1DaGHghN19GGCgWbBblCfdzG04pmQuy5AJczqIfhzc5pcq8OTH8V43xT4SsKwHzKQ0pVIvEAFT
JsDWksJUz8+SG7bywiEcDzraaNv22iKz0B3fGoCLunRGl4CMm7hD657fNFfS7wBWs+maYNXPerCF
MTkc1XriXBb5wK4baniN5JWvOez4nzr7+jNjpRJrbvzMCEUWp2ckTe7vdt4YrvIU1bGrHsVsgG36
i2iFrPqSaNSMbPEhKWvm/KQY3S+bETqrMuV4mdDhAjJafWXOXvPjk9FW+2+5gVtEL2C5S+wtfaan
C7ahJGokUixzLJEeE+Vn+0jJviiV//YRP6k2zl4YjzJbiLtiYHmp1W1VZXa4SZVIbBNY+Xyjf9Zi
deV7++NnZpQlh0QyyLlUDBKS61VGzzjpjsmXrgJ1GnNdtVneAGpEpNQiyAIR7RngkqPPeY+P1hSu
+fAfSQpI20A//N8LA4Lh76+brqKMa4QV5XIWASkf07SE4Gnwz/dgurwm1llcDTALjfZzO/7e0UEE
jGZgiyZgEtT5/5Sqr1OjxiiEKR8umc/0Bfq7M7ormTk0Sev/Cg+KdRw8tsznjLMmFJd3il3tobhY
iKIJMLSUhj44GfmlnLWRyeQdH6/9eyS1D2gXDt75TpixpY8xOfivZjzSCOT00bNrQG8u7y2uV0Ei
YFcqS7CieUXEeHGDRw8FRdhkIBmj20HZBA3HhZHtH3OMIdAegdx7EcIVL3HD1gCAh362Mo76wPrV
dOGOCCnfdgzFD6oluW5EyPZR4x5VY+C+PXh5N+EQSIZQZz4V1ClDYmWqpLtMbg7Lhze6KDyE1Wq9
rRKfAlZgG7I8U3w2Owr6kfanyNk31162HAf3Vfp5V1XKQqyzST8qWSA7YaBI0RKoBhazh+Ou+nkK
dZGQG9uL0WQp9IE7g3OmxuUJJVKB+/YKEzt2uw11EZgJkSa13jAzIFtT8dBHTL7cJgLq3dy0DKE8
16lFre1QmYDb43M5LcgfOmtWknIWXZYQ94sUyT+HpnXeWOwVcoMr+so/AhZCtirh8PUrH99uIY34
9YE1Hvz+6euYXHIQ9w8KpDh6NPcnhtLS+6s3aEdj6ct59iQpKCmYJ12SoClGmeIX7stn01tEy0vj
GGoe30QmukSvIANzpFHd2t5o55Os/5nY+o2hbOUlifzd5zpKS5M45z0UngYx31GhAShnzcPt8bD7
KTDHE3eNYsKtXdvefesvdG89poyxP88HWWbu9KJ89U8nXZSbPHEbdMT1y6jmkD9Qqda=