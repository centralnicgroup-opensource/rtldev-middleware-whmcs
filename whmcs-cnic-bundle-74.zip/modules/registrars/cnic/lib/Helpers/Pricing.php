<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxvi1ZtV+VeofgMJ7f9Zd5mgEqeFOE4bYSyDwowi2hUtqB0UqXqMWEoPq2ZBXSWSWx2ChI9/
dDKL5yur0DwClOFYJbBnmhdjFdfvBaNSxy9eb+VhBrubOhm29b1ZBUE27hIwQJT69ASUdx61pB+H
AIkNgxKaqW16bDtaaVtAA5Ckh7KuoRWc5kTgGP0Pgzbe9S1fdoeS5AWeNhiqmnuUT9mbBfVHeCPa
KyzwZ9IS5wcGX5hjx5FUYFu/EzikQQcteWC6in2hNl4fcQNFLPI19ldaf+UINMbORK+u9LFWMLEd
Izsl9mYhEdDRHt0evGG+zYJLMAhJSO5b/veS8+/Cvs+Vwj6EYcxHslVHP3+b1sSC1JN1tyD5Bi/w
j1GeTav5wJW6lEn7i0wKNZ+D4qFCRZYRGHr1IAi3YC1xJiGkm8rWxgFJTRxhNOPb/8Yo3WlVHH8B
inT9hQk7wotvBOul2tYppTQxLI+CLUCPPdWc6KFBntx0WpEGitNFyb05dNV9/JSAd0bVNEm41d2S
UZF6hRDwY2ap10nWCGcJmrmLg1BQem7aIAVwVKnMdPh1i9tszMU5d5+KNp02E02GqpOq3pZwocW4
an2pcSdRPVuTt1BcisFf6dNKgtQ0uJFPbKN0nquKjCDTXEQtH6I5drJSt5viqLAc3Mtvb5WcYHoC
ooQ3OWbqcddqeFJREybzIolAfZPpntOuaYYcTHuUrFFtHUc//eSU3cjRGVXQULxExszY9+/JakFu
o/9ff6t9FkM89/oiKXEYg5tHLDtivGOuutxA0LG+/cZhQxLyfWA3vrlUn2O7iKzcduP0bGEWXuhU
eTitMSU7R9XbChuvFKzZqeGshYSAP2VRR18tbKih+cpr321GmwBAQCGpEPBEJLZAS0zq8jnXZp/r
RW4Kv6LGiI5FgXFIDDLLwxe/Hlf/7Ii4PTFM2t0ktibfXWqpx7G2KL1Bilt8v0dUbmdCnBG4ET6f
xyv/bhkPzTkLh3xhHbzuh5nRVO8tL/ykr5R7ymodmBK13AO4e3bkrDMP5Tt77S8Hh8wN2PvIO+9F
11sRgMJH0HONUoFIJE2nSF0q1VT3k6XgFI0id/rnpsGAifXrUtoujMHtKMXaP5UsTRmJEZk4Fij5
/htjEtmx2ZYRhvnBmmNY8TecpgMUDELs3tUIiTPefyDdasvTLa3eiyT6W66CfnCtAZARu4/OYwUB
eD9SMckI3fqAEPlrAS2By2Qptbbno5KEgfPcVrmWxjb2WMlsdD17lHC1u/W/ZyfDHrnE9UWJCg8v
RojW8WYMThj6l2olgV8qagE8CVFx3vwkmcjqZCbE2+hM7bFqOni3qnt1wc5eI0LReeb3ZVfZQbVI
tN/ocuLj9QodW6XKAls65PmAXMOMZHaE9iAwX3U5gIr478aus21kpaShAssK4W0CSelALzQv8nqX
IcG3/z95aKtPxvl+FawUp9pkFwKJWf6TQn/QtA4+/HvX5ot7DnLKVl7Pdkg8/4fwlwuE39EK4sfc
TT7hay7I6ZconuvYlCkRM2uo5FeqMeEvB77V3DOJCCdq4jMC1nPO32P5ab4k/lxv0pOjK5sb4VrU
yg6MmRu9uiELexyVC7RVgqB8Y+ZQpUMfHzUsKcPpQhYHRAB2Do49Krsvomb3EzceDu6enl4h6RLF
diGxMCcKZkMS3pK8dhJsAbDFU2+ZMDzY+qTP91W59SwkQmTdEWcH64Y2dxTEGVmDPQtx1AtHfwyr
/LRL6Gqj2rvIex+bex8pYFvsD4maPOiOC/kNGGMgf0JNNB1LhDnyJ0Uyg9Hv/DeckmE1GD/x73JA
jCc7u1Abtp6lEYo+raMdgweSKAgq6vATaSwr4bZN/KzwlLDRj6puUZOZiSPPJJcw3qA0OTvQ6pVP
1R9pwe8ikFLK//IS6o/T5IpU29av2Aj3l97ZER0W3xbN3bE00y9K7BvFn5MH3r9l/lo2JNCH00CH
uOagiUVzjNBE459FMJ7i0Hw6uul2MH23EctyLFsV9lC9wGJ8+oQhrkAvx3Dz4wqD/+vvAMA7dJgR
FWgJaVRpQukuTbG2dfqSAJUtXJqZY0/5UHn2fj3Wj92GuUJHvpxs3z8JYKFcb+mRYiJo5l+j0Xra
d01tUeoRrjRXT1izttiYWfgwc7ds/lDSa4YSYzjO2nwkXQogbGhICkOsgzbjMmQQFpGUQyPL46ID
jDjGCaWqO/UCBpTZ8T2/fCFW1wiElhXHxNVN1HmQMPR65gL4CosvqHSLl2wS2WcrhLMp11JTqGN3
ENuxDzOsMVPQq4lAbtSF8cg+tCkCy16qfWvzc22DKQBKxOUI+HMXiNXiRhZhP+NFHH+FVqaiP2sd
d8NNyYJ7eOT6C+0xHz3V0oj9Sz8Wt3VDKvw9ASzAiYZ9z0R0//BLclD1/tOSXRpqXlZ3HXhtEP1Y
vcwFs4GoV1Q9FnKD+pwkP2mmbpRYza5DpQY3vWNtKjGvwHwwreaoNW9Lgujy2z6WadHr+2MBc7Ss
gw2od5sn6gp4My53Is8Gw3zI6XkwJWqW3kDrYjWP5VwjmFfU9w8O9+iJqusYeCkbWQ73QAwYDA+O
+7C4u8kNrVfz/FtwA/a/peBBLVs3TfJxC8PIY95VqPbiJrnB3sY78kUO9Ry3V9/U6/dxvz/RrDYF
ZbNnfaW9OGL7+pf7gOv2iiyalXZzeCbPGbM4HnkYtyZgEL5oqJAtA2s5jQdkka1HBoS4593YXydR
zj9nXedGhWY68+upwa3/XrXnAnLMHkIN7ogXOsR/Bz3rJ9KaVg+PX3azbhCUT5DvTLfMwIph4No8
pmwNm+QVd/RpYEKI0QwlqpZj89GKUwdSDjek50bj/hHGGFdKONPXYAHbBlgeS+hkTiJCbw4R1vIf
WkbKuKoGxNUKDy/VWhN2oWivv1qi4vV68VAXEp9uYVf0BqCuRmeO0JCjg/amyXHdmA1MYI9NAMw8
MZv9dEhCN8hIxH1HmotzA+K6bshvwASzo7eeo7wvv35CuAj6G0GltV0MY4VNHNq9043lPp8Ip7ki
AoVl/eJO6qfzEEnjKceg8Uhh0r4Z0DIMCampHu7HMvxdfUD6j70UIaTjBFyqx1Z+eH82I4R98HgI
CXAqtr9oZTzRWij+UjxddjVf6UBP7DAZRioXzszhLaoRpZXXH+fokK0dWKO/A7Ua9+oYUe+/aDoJ
QwryBZ+S2Y9/2MitfNhc56qunzCxsGpVROuRqZOAidX2ttYXFwp9tZQErzab9gk78O1RlwA351sH
D4KS7b2oT8YDnU/Q3roRh54MaOKbPH6cC0uVmZxNGkJcRE457OUZLJ+eVyxsdztTs45TUBts1u/Q
oicqO7b030c6x/kwOYyOrBg/gT9M1FxSC7+Luc3plCCfl9xbK+/IjfP7GB+6XFYm7BRhavVtAZAE
IbrgbOfokW10QQy56ymACjDMRjkJoMJRVBvABKugwFb0pLl3V+iYMhhq9xq27YE9R1vZ2b+qaIgC
poboLEbp70m2YeXJLwbXdkF0iQ/UTuFYjmKjsm8OmMoZDfrTlxBXqh6la5ciPItSU/BBQJzQTMcx
5CEBdtAK0ZL3f+NXLi16KRR93+eFxjymq1rI891J3PvG9XqB08bdG0k3A9F3GtIjUTmgPpiR1CEu
V+3cBORmly66+ZyaqqLuy5PFwBkgWsy/78/S3/YpsUK2sfJzAFl2bDDtRxGF1nPDcvR7aFsc3wba
OEoIFh7sXxyZZi6CDc3gzGM4aSfWCqN7gLXggE2hmTwnvFavSLf8X5TC2+6UuuQtIMl/XoxUS3Se
pCz7YvYImXnIe/w5Niqe50FuOs/gx9O20evMLh70CjFtA6uA6Ndwo8+pm8cbl2obShylwoxFJBje
kjThCQkgsV/vTPIx091N4KDFr9jbBhmDjTWQKiVXpPKJujolgPgjspNCbcTbW8Z3LqIoBu3jj/lo
lFgJMSYpRibZg/siI7YH79FneUtNDme4uFRum7SS4MB7xgP8pHqjoHnX2QvuWutM2FbePRWBQyT1
dtuGbd4q1qQDgrgreycr4Mt5oeWFXqkWavFwxIo5OjpxDSomIJEdjUsoq3Ro1jf8YVeIfbq0YEcu
4sAhpQtbcdQE3fQtwXkITuBBvyhLSbp+hoZTq+bDdhFsqckNmcy7T/7tCVod05kz6k0c4eHT/ha+
z270VPzujERcJzqu90k6GbE0BbMDDFtc5StsvP8Le5ItPbu5fonlrN+F5LOSOKb8ePyv6OyVPAl3
Hf8EOfFin/SPiQHfzaDZ1XnMDuZbrU+F0yNwUjzo6dLxboprQY8D+qh+GzYuCOY2CKCuCkrSt30v
7SMnYWkeGY4zqmUSs6JTF/dCmJZDlRsXL2+XvbZtN7dTcat+lyDLDhOImyQZbsEEJx/DoPZ75iqE
PqfYF/0hYcEB0aDaubvBsVaWGd7RDHTSuxpv3ILiVB7FGJkQtkoh5HFdIG==