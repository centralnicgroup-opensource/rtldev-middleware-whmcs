<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyrdDx/Nu8kmhgwYdDg/8S5WLUEoCad5IV4/AdPhAKDzbYbaiBlHwsziIit2Xsx/xSmNHzBl
ecwbRfrjjKWuWEU5RjqaplStGMMC1ZKRW/ctjsUG4UOTaAwHrbph571yMAQkfQ/Urm3SLnUvtW4h
LMB41L6Rx+PaC6r8FOAjnI+7dnPpqtxntlyh0qQP1B/MFokUsG0FtAgH17EYuZC0LlLJXTFDJ7N7
rAA3/a6Lr0XUty06m989vvORM2M45Ce9616e+Qp3T4pLfBTHKGAeovn1aY1qZsnZgfejGGZCfwLR
6ODrnst/oovcV1yCaESuWieVr5v3rJPVKGP7MnNnoHtJJLgitexsBujy044A19IzP9gRdfpZ3ZvX
Zc3axndJT1MTpv1gWuUbKOBD4yN+Ls2baeyH9mzkl9NUAFR1WNaF3bPF3bdYUPAVWz5l9EBSr5pA
NgKSwilYnN7e7FgxAFA7j4zCv4a3bBYWAXjNwEeLYgYkZ0YP72Sa+Taw+bhojTOmy5FWinJ+v3kO
+hKliMLh4X+KieweMg8gV1O03tBezNy8DzMaCM068o+fa0vSNor/Sz5qiu8kXWSIa2IrsUXrEzz0
pvr8vaGFLwKn0o12YE6rflRmkLjkFOmwoC3HM7yJ/MnLOVzveijQq2EoL6nAUSRUdto4+rRPpox6
2DiRYJlopMyj5fEGZMG86s2X5O/dNI0d4ZwZj7e5jU2rEwKfqe563yAH3C5WJWM/8VpOJnuAO4j+
bB9mxKyQ/Yt1Sqp3xXLBUhIhulriTF5P3rDb+ouX262R5RejDbJhO9mHQOiSlV653SLRBrrohIIc
ParOQ6taWZ4J7hT3kLIiYFQABYDv/+Epw8OTjmgaz0OSOpcTLbYePyuA8GhfEtcGvP/wS8Y5bApx
H+O+fg5YCTdrxQYTdKbqzslkOfnmu4xFSMzeCuRqpY8XBIH0dsthNifCy6z7OII2o79WXildHman
TarPnKH/FV2sl8avXEIHXtkHX+ZJ+wwn0baptG2B0NBb/XdonxG2Xhr/+aQt14BsDYeuPU/Cc7xZ
JpRrGTwca8vSgyQV25d1NAr78NT4477t/siAq+q+edewwxORjbljVb8/OLWxRbHCAkqNBAcITGJs
kiD/QwdKQE8sqp6yfaBJQd3RMHor8oBQV2vrskbOjcPf+3jMrwPhDj2zrMCTljqZ2f6he4IA5bx/
4Qy8mWbQNjSzF+qhwFTBHw+E3pt7VyaQCUS48RYypYaxmnKHapBFRLC+pWqfVvyT61arwFXgGszN
M1z3OLLwr/kQnAJg2bZlt0JpTG5yzAr+msJIDLcGjnCihdCProGgk5O5c+ymfW7NowfkWkNkO4vN
wQ1aOP2UXnsmawhBTkPEpzSBW+oeNCGSX21IKLzadICl0sOKTA/QE76VDwB+QIqFwffrGx8Ik5Xq
PrRQXEUVxz2kIeOiP0U5uHD4cFJoOIhENH9uDdn7llHfBJCd/Y8XzpCe01T0y1P5jEqW8fBa7O9y
Qx1A/OLV9lTxJCzta2s6AKhctNmlL7p/EDOnxJjdTp+qEWmOf6cpRekbSz+F+/RHR5LQo0CrhtKa
MKvLoTKXFf5DPpQuxU/Re5MovMg/Xcn2JdUkreA5ti8IXxPRZAsrvvGDMoIjyTg2i0uagdg7ly0N
jisvgow9uY0wlGfs3jL5GxBMkVrecoTJ4fuCzL+pJ+X3eSWES+6VaOgvOOMLXdJPOrzClyJkEFD0
dt095uTkFcvZYC4UvSshdqUGq9nqJF1V23qSqIPPNtZkeY4FoEexBAczVH+njGScIplpbuGHAOA0
CkLhqKQBpaDlLXrR3EBRdLBPMAUYPX/obEKWnlTAHMRDkV74Q9bYpX+NEXM5AdMTzLhvdNIF+CwD
k2ZrnxbQwpC76WV73l2++IB7bhnEa40AWpSPJEyx5k4g02T1c7NoLhaSeODSf7KrvVUEPz19qnSE
rm/ef2OPc+eqiMdrodYMoVcMDmWXJ8EPXr0g73BV6iLRPACW9M+1XNoHNvlCcxiJ9NTZZr5G/Ql0
fI+JDU/jEnhcycCd4Fu7uTx+x+kNbSAVtoKNv7IJ+Yymd9/SOrNzRtx+LDHMLzT2HDX+6f0IiZ0X
4Ou2UHRk4zAFEDWsDohcgVKplzCWsXEVZx46g3wtcCnaTeUe4b8rln6e9Uy0CaIuJxg/74uhnP7o
uN879DkRa7MhtObici5F0DS5JwL3HSEev16O2h8iGimHK0mQZ/4MHJhzmFBaPepGcA3yDJKPgsjU
8CtWYuKWkTPx8mzu7DhqpaW43AL+jHBDjYWYQRQeoJ/ifZA8HtHYst438G9lieXc8sdphY1S5HZe
t4FfcUdx/7xzwbYd6WvqdQQFLX1oMpXVlYZDG2KxRQ2KRPSiX9tYAgzKQfZ2QOy5ds82X8se52G5
k7ZZON7haoDmRRrvBH/1WuYG9YeN9ejQHe/AK0d7mhFTm8h5yN3vBDjyGWYuNj1SYGNpxgzBiZNO
P5inkEvWtVktvGDoioS1+97e6OwS5r+egC8UwnJzXNryVmFuZefVDINy8VgKZxBMn794jnzZ4QIY
nDiTRjMuYKzvaGydUdCAUek2Af7OtvNhpBhs6xlGDJKaDJcyWQocsCcrtaMiM+DG8sxfO/KlqgkQ
VEh3K8WzLZ51CKCOD2fHmeCWfzTRLwDEXBTD1DJFnWc40H9KLczFmWQicOie0e03APi1W1yC6txp
Uz9ZIgylXfojmKwybJKXKdkAFWAenOyB64VpjvwjbTTP5ITe/CYPp1CnHqTD8yMtHjm/eeBqAMBU
/xKm3W0wvzsHboGAV6LzOHL1UnQWR6pakuBOkyIhbo0/STEntahvV8PTjDbHhDzMXv+H6Ed4kyA6
eDGpgf4+mTMMxr0sKLuxwkJny3uY66u6XIpQmBHPz7DOyN4qUR0lxPXdBLISE/21YOm3IaZ8Li0p
qp2zuWNIf3a6VMCATgqrs1UxbspqWotQWB1RD+xRhDtKr6vJKg5YgB2Rwaii1qNQVybWu9TzPQ2G
Ufr4g5uowEUQJ1TtmroUZ1nbnQyqnUsDO0oVCpNlPlOM/o/BzA4c+je8QHdTstpi/i5lK9A2pdRx
dSBJDbkHWYcCi/hq+B1LpZb0esKpCNys639vELl8vy4tLrQ2HU2bsYGxA8G+pPFStCxC6TNosIpR
m74WJ0vOdrwd7ZradITJaV1IXMOcd7ZVlm6SIzue/lXKCyBE8crQSvdPoG8naEIN66VKMWYccOoP
Z0DsCRzv//AzqCzxXqZlrniaLjkSysNcM9RHkMqYuJUmeEbX6eOY53q8j2C2DvSir/XnmlsB2fO0
srxtFfYIwiAvK0YmWJleB3K4lbz2ljvEHWEga6dIkHQmLIR/MsDSN+LhTIs+20WAQxzZjLAq4Dz9
bfj0u5Z/QovTVdmqIN0iFGKeT1lNB3WVo/DpPcR6V9b2rk7eyei+AyInY1N5OLQQ3zrt1ShyUJQ9
nzsT/1kv8CQmlKHvGSMmePHq7g7w0IW4UYOmk3hw/fpIOnxTzRKX/sQE9QhORMMED2jZ7De0y77t
52NaRvsAQZwz8sB04xavbVO/HtK82ATwnS2EXvosbRVttvspDJJrBjUnPcvY2IGZYHiktuqjaqrU
NNEnzOjEspRheg61p7atlho0yDVI4htf39SLI8VVVYNp26J9Z/k1zY3WGV+0cn3SXw/3nv2B0p/d
B3JT0uSQoAv7p4zNhTPqK1rolwchHkVbingorHmqpFRCFKGaKczrChV5GidjV0mk6J0SjxYChdwN
l9l9+TmTS3325OQdiwu9nIjnsdRG/nTMAyJlzJJWN1PStqFg7XakWq8DC+R3SPqdDxhW35f7h7Jd
la6GFgRYOm2wRAADSBII5I9Yhn/ZJqva18DTYkRCni4ID0xmYV2PAxZurToMfeidzm2YaxaLxjVu
c+WlJAb2zy+SOuqvf6wC8IflV49vIbkrj5wiT8rD9tRYlNI4mJY2ZE+7jteZiicS9jFs1t2o+fyd
El1Lz5jNYz9Qlc5TeY9zp7wBhY432WxuWBo/aFwWvW/1eTn883cOA+ch+RXyBfsXXmAFCwibPpOa
li+yagYq7M8lz/+tVdDiaYtx0ikTwcko0sqY2JzQYpZsD6M1RClydCaDznD04KzejBx8ck1TyFZ+
e5jFH9u3hrPsztsYXtZPpVWsNcngCu8tFOhZuSGd5nH4RlE7Am6BtYSBgvmMhwL+gim/HLtiT43y
LwFTO3rTn/MOsadqGv94X/wg3dfOy1i5o4/pnLSXTZdERQ7N8+DL6ciZNAvb++DSwQ7PNxdG7kMi
epDrPoGnolbwi+cFXrOr/XBAXjn8S6OT3IZ3sDm/tkupgARxcUvHjT8/GP7LDRI9PQr7Jh2+/g3i
9YHZ7QCjVoRHoMYn3v1uDsTHkbtIN5coEEqbCXMx3WdTBm==