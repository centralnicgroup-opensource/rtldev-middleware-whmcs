<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrOHBI23/fKNMgEu0pRAnmwxOI/b/6Ra1EcRIDf4KDwZtiSaQHBulBqzbOvdbWgUbOAzo0d9
pJ9OzB+v9RKSa2PROLDQd5lDy6XGrXSRAxNdenGuQi2cm/uw1n0HWomUL8YZ8Srf86Is6ybwXXeP
iluWDkMeXb2VWj6TmCNl+d2M/VZ0EjYFW2rKCBm02sJ67lmu+g8FMD8Nu2sWQlq3PlwGK9FwYvST
gg3Rq+o6OKTMb3NflOAD7B36oc3ajanEbGAhowjUyIcPfSzLb84c+UIdvvAkREzk8P4eD15l/J5B
RIJdGH4ml357U1xsdvPl81i5FGAXOe6L3+s26P2CSl/DONM0QE7Givux4XWIuF5LEagAfwOloSsI
B//QcK3TNbvxo1LID/7eLU+sqWTL9LeK+JSueaGDnVKIdc6zJoJ941SK4dU/JGTxvxesgmiSNQp1
b9NKRPLlMBe+9G8d4ujxHwjql/G9O5FHmOSIDJbmczsvBcWdURx611oyNTh3dvgnx0hMCsKwOdFi
iq4ACQLKM/CWcfHpryDCHV9vdfm5sOoOue/XjXo4au5bTCEkEG/8MH6ychCFtztMA9y/44JD8LaV
YP6KAilLhvoo+LttJQZFFMuMA22Fsfhou3bWK4VHS9C/pmHD4mG3nE1WRkgk6RmsVZWCAbAoYUYD
q0VhIO146kLz2MFwyy/3LgoVBmB89Zk3UHaNg2tsMA+yDQfy4Hd654z4uquVFjB3CLbC8GUctsmA
LeW3VybNWDGelgta7V0aVq8lwCHCa48aoeiD5oa3cynlnaz79vNcZxuM4A9ypdt8MaPUJgYFvfcf
/HYNz1zezzZk1lNBdBIyfkwXgRc3ITXY8GtFfVI/59u+6VYsHHq+J2eM9JHcwNZP7faVoK6nhlw1
UaaFOnJ2SyR7U6/ZQEfPMOfao4JQAQtK9EzgO+ndIXQ81lfp/pKC/mHX3AxEte2oSpurIx4OXMzd
+ykMzMsrM9/L0Ygv5PSrKs3SzdLVNOD2sIstDIT9zb0p5AIU3RMvg7vsHZs0NXvmUHV8LMBFKYMO
AtUEcEsdFsl5+ZWMTvaYX6A81oaTQKiHhxH7kxwAAg2IJ5LxWDxWf3lTh2Vk8cgr6dli+LKY3joj
xOExJ5oJyhVpva3FIb2sQ9XX91lFEUlBoLaHwlDroVZCH/z2iZ/8i6p3vm1HUb6WMuFF+TDJtQgj
HFDYdrqfr/H6i1i1jeuw0XsgofmY7Knaxk6AaX8ZuO7iT3s82Zu4x5s5Sxm2aM7rCZlmtgMrLh1o
a4u2pi8/dgYIYbyXkm+EB1Eaucq7FcKr/ZOMeYbdfLCbS11icP65J+w5+Ocf6YZ5azcFziDpyD7m
IwButNvoyEJcLQZRkidWPr0I7bI4gXxO/71hNii4cezHCByaX4eq7z9LsziSRocgrMD1OH2EWFHJ
U/Jxyw5WwFGbQboKXlrYnbNCwHeh1GT0ef6z8gK5HEfJt+oT68G2S9pjWU48Pc3bXbicW2dduk6+
LrUyI4V68afE8IqffEX0puGg79LUSqEnJHNaxn0u5IxS7QwFzSdk8ed3zYjT+YVxCsxWiFIwbJ9l
SXEaby7LWrWiNeh9Sno7je/UR4STQ+AeZX1Uq3gFt8NO6dAXS8etY5tdUQvP7XiaD7qnb26VmuGV
qLTTkhFQYf4uSlfyHTSrN5PNbCaohO8N2n/0q+pvO/Kvx4DWb/TLraWZeue+M6lazMJuv1nf3nwu
PZlGbOwWBMAGW9Ve1Vc8JNDd6s5yIC4NVyRq6nzYwYmWnOlzm49iwT6hIcPQ5dc2LntsA48FrA+z
sVA86tRAaCFqU58kQcceElPg4egjrheBdS+PCoACPPYA55uoMqlIRs1p/GhPIzrNEwTmapOmDomQ
G7qHYFU6Xl8Shj23URBjiVZj+ULeeZRkZULoeyuUpe2fvaeNdm+8XyIVM1ZTt5DxZvhtJSW2AvxF
p+w991Xpwi6aX3L06KAJhefFu4hr0rQ2o+kL/ZqSBTHc1hyrKC93YLKnnzTTuMnFjZLsN/unuUuY
epaMem7B4OdHr6SpswohEFh+lbfV1FbNFQbQaIKr