<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+aYRell0bEjzf3xgF1jDmErRDEUJDwbbe+u8+XCNnRUM4I6gsbYBOAx/YrevofIjQJUSTBX
k/BtdtBj9LBDejmiQDqzBAzmlT5m0mCZIC+PgMPAZeTDarG49JFPOBPI7UhiT7Oadbpa1l66J4qR
r5cepOfuVNTBKh6kUVuclvmtliMca7q50OR7A7Yg50DMIAR8hrCzo63EoJTTJ9BZC4vQ+Sj11jhX
ZoLKOsVQAtbtfhTVHOgvxs2twLCf51EC72nBmtHCrQItKL42gCkSGP8WTBTe2xiYAbVNU/wGU1ap
LyXthiXOuoxOR8zpPJOsPIloOKUGVoQVLNBrV0SOyMUBWdoKYyMhZwWl9DTqOw/0yT1j9M9exnCF
abhfvnOgmldGZ3gL80JeUWZHDqPeLNY9O+u+JRSCMAPwHDYEtqkK4s/ov0L4Z+ETBvQJMv7eWS05
aPATd7LGTuH3Nm4IhTMWuRGCTl15GW4HsUaeq7VRaNxS8Cn500v/tDtvQr/vrmgEskUJC/hhLn9b
D941vhEB8vV8151QQgYHWGAXAH8lfuPdtluOzL1pdVzd1sgVXzthitlasRBvDpKswDwKFTjPa07S
Jn1gknyD1O2XpLLvAbEQpwHudylzbjtth5NVtzNbf7waJHWxUFaVV4ag/4/yYC7ZnEivtsNEsUe0
QeCvkpe+pKP7S6yFHchSZRC/Ck8791YdZGjN/GpDlJUiyVTAxvr70K67cbZ2shLPq9o7k0KazQCd
knOSIk5XIMh8MkEME3uP9JbbuTVyZkIFpqZwT8MUjK+ICA9w2xyYHulL5RVkH5uC9A3Pw0KHsh/o
7Zqa0gurqUUnrP5j5MhN8puh9+ztguYrpfetsYG2SxVephpyIbLizDDTMxkW4gc4/VOBax9lx1dJ
v708cyWiJoZ7gGTqfe/7jfDZd+rhudGUmR6HVservQIiKP2ozvUm/8ZFNsDJcjrtd0VGd8exXV9e
88i8bU7ghw6+rHDf/puOKEb3zUn9vXo1ig3sO4pHedbI6PlN4c+2/x7Q7JOfgphwHkaJaJ28woZj
zYrIGj7HLWtfo41Nh5x6W7vs0VHoneoxFxC1v/i+kP8DCscAdW6rOH3VKLfg/34eBbVLp0fNE//t
eS7ewVOHVoco8yBIoy/0v5wh78bEv1lfcig5HorCLp9w5ADYq4ziOR00mG9+9TrPLZ82E6ZKjUt9
lSmKNWJnKbSfwIOGCbsT+Ylno7U4KbzlP+491kH8D71LUeN9QxMnklPYxdT6/N4rT6vyohbfDU/G
kpcEZ6ZubIdbScQEdrk6ges1xIrMnWqgr2ltRf5e6k/b7Fys25Ey34oLRqixxVEyguhgtnmnO5QL
25YAgmE8np6mBnD6R7ItgaVXxYZRz43246a/62yFwp2xJgbaf58e7WIO7hUojHI3N0DNc0e/nnuc
rxkwy2bVs4nI9IbfnyR77sWroL7l4BAl6kbtevIV1vHPERSGq/y4CBLdnfBEW+Kucre4b8nf95Ds
l8et8iX92ua8kJjLe53XknsBVoUC8rff7Ua9PRUs9xmNiOYQghWN94nRS6VMW5t4lm++0hFZSf+g
NWSdrbGb9NkM1NMMum2DDm693HX0n/pClCAP/RMyVmODRkhdGePMYK052PlrZ0QNFwJIUfpmODO7
LcNhvIwhasDG7DtFQ/ZcSlcrhefYvQdZmNqsPzC1Z63zXVmY7LrZnKqczJJBq7BgcnBFhYcGyotY
bTk42aWP1+1vqhIDxfcLWkKf16SRS3sGNaO8mAIr/Y6GktTaKabTsN1vmrIAv5aLz/lwLbGJxmc2
RguZcMTW4lYQa67NsxG6/Vq7y0ZOdong6LL+eIdzItYv9P7DCDFloWpgZwQD/4nMvPo/uJvqaY3a
1ZqmrhnSexIQbQ8boo7KSihJMBNRrcmAqY69g2BaHwVLJ1FEy1Jjrk9RIvYoxq1avJg7KlB6yc5t
5096zRVYI8vLo+wuvZhEqqyjbk3FqohT18i3knIsS08EHGJIQo6ICnS5GSOqz8OZ46hqZkxcV9ok
d7aASN3XX+EtGfcKq0==