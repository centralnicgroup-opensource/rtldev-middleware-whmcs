<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwI7RDKWObKRFJ3vzbEsunLL6gvLUj5whSmbpeJ7cqSb21BpMnlyVjdAkj65eJ4Iktwok05n
7Q13V6z0x3wGbhYIhSEpnhwf/gVT645ZUaphkOVffdIgbyX8eugQ2IllmltGgbG5do2PCQ69D9g5
8eWMpLRDyU2ANrbF16gRFuD8cDeu0RPgoX7j7Xe4wt+7QaaZLHdxuWWVddUSWUnIsPGDljcRDMML
n/lGFaBlpO0gAOCDD8uYBq9271fulbO00y6ba4DS/2tSOI4jqBnvao+2nMrDPtaPk0opCgixGjUe
KF/cRofqGf9a59jufq+uP7dy7IHZ1i3fZ/e8c8J6IRQ9/rpH5AtCjr1vTEGX11sFKqqVSnCf9Wht
LX6MqqYnTazXz4GOYKblHAQNL/PAdHboOesiE4uhIDpGydoLzlShtUKxgT0mtaACLCBTNDLdZqZz
IOcLfYRbLnyZ2z9DNNXQqf4bQRHWCFttS+1yaIf+oa3AtrmwZI9mN+y1KQLQ2SkDrmEORqjb3KX3
BwfX489q3sOm2NHbNvyeZetbm2O0eJl3ElFCDTqKn2yzgdkN6zNBnHMFetuRN5Ieqr6tWRszRn5d
1A3VTQnetUPpGWQWW3CMy4fI308drrHW+o4hqFaIFpSZYyMfbRjmr/nzdgZhTkOcot89r7ok/KMI
BqkUtxA8DIU6uvb7f6lq2Fc9NHBYPxcp0fIsEjBMd0QG5TXIcXrLeDWp+aPd5H7JOXgR2tgDGVth
TuXqowj3jBocdTMuLP2zSzpQkeP6QnZ1Y6uCKcXSp2vtNvu/svbBlg55GHPuvAppNx1EszEGUC6e
KcvRe0fwvYFWcddWPLwRHmOoNome744U8OTQLhkHko3DsQi=