<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+02dOjYwMMiUxK8gELsK3Yltp5fWnhg6SsGPSLa9YW/wiSd/vaCDQHYMKsyOveoKwjx3tYm
EcC2gmaJEK4EN4n8TFIuq1Q69dIOGEYXKFAPQ7UScNOb2gp0TgsolQ+wbdY8CyT70UnYhdwIsiDA
fF2BUiHlvqLPywEEP0UsjhMnFz0MUH7Dk2aubIumh8Qg3Gn6mhs8zbxuy/oO+wjX2cBwxkzYkyUN
ImgigYSXOMp9khiDlda6KUMx0qit3ZAioevWgRIBXovoShhmnL1aia7PCHZCQCAnRfvZqACT/knr
1gjbS71q5/eAuQNazGwJGrq37rjR2EXYJ1nLyCxzVwF/hJJ03JIKj5xSkAP74+CzA2YO5D295tWS
i4Cn2e0/Pd418UrPVsaum89dA55DIFtRilSc+nPwpWjFo7LhVcAZxLZRPCXxbaMCL+QUbGOsFh7D
fpVsaBSrNFUjoMqIGxIBbvJcgZGPHKYyba2QTsuJ/oB7AVrC9zs/PtJLbTdIO0dSYFYP+un0ahVp
CsFz36bUZYnkBIhhBibBUBL73KNbMC/cLJXsfx6/drIi4dKL3hPIrP/abVOKCIZnagv+wIe/lthx
uanveQtI0/i7GZGkk1nyn/LqX+ONG/4T6Afy7bGTfvmF/wlTVhau0TMOhrUQzjOGMIPDsp9k41fQ
qp1/xTCqr+sZ560JvBZTjHGi7qKgWhs01wsxHwJQypsP1y1855TDlDL+2ZtfdAgtZ+1wn3N+L3/p
5gt6ehpPhSsPzjTGHB42mjFr6JeeR0y+goeWJaJfS9vw67HxB+kZCWaZK0vUO0YzJCV4Qn2Cd7hA
uhgNbPAgFqDeP9Sp0MLZno3dmY63TDT4wMebxAcbpr85