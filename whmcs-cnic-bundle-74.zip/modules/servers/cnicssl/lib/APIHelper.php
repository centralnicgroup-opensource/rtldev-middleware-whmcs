<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrj+avINw6VRRhK6jmrfnRqA3ODgsUgETlkWdizhY4Ax8rY0PSC0PfEKizePVdqfjOnpYrBM
kyvccvQLjalMVfunKAEJZEjS5iFOPsdpyKwK2fpo7m0O/taicihadm2VE1uzZZfBIXQ4FmL0MyIC
kXptCRZzmLNCVEs1eYjVhcSLKmsTmlCE9tTgAZeheCPBZy+pTq9A8j9atNgMuRR1RXrLouc95QP/
mvmMJI2cnKysanrLDTutNuUEgfSNGbgdum+xhLtJ9SjYZNnfss/mhxrXfI59QA/L8Wi49QfKX5nt
XWseEl+ROTfXOTAEA4bnd/b4Ve9Ij8yvchWfYjFTeLoGFmv9TRXL966fvQ6fub4gG5Tgqf9ZVRR/
WzjUTW+BpySwt7U30PJBk/BEeLBZ6lsrd7IspBPStJjxI4aPTaGzTwQYwv7OfICmWhQvwFreTAhz
S8s+0FC83sfIYl5/EP0LJTZoIGbBIYAmbOXvr7cg451ExAdx4uifceJQbWlEKgKPuy6A6w3Emcf8
yYYHk4cDAWwfnUeOHNRn+gbHuG/kgl+VK9YozDrIX27ee+DL44ONjT1xcuwlnd8bKe+RWu2oETde
n5bzZEhlzhlppCU4G9Ujs9f77OhPr1Vr8LE9WrBdI94xA0SzSNDi2ilm9SS0p6gWuk17Xfowg2+r
3rD4XA1o6v6BliMKAE8xKj2RmaJMLI1LuM/SkpBWIsY0bKMi28N2IsNlIhPk1b5g1ZYrKSdT/jXb
i8TOwLGHsdTZ97FIqVMUafmD6piQk3Ylo1Okb8nbLJF4i4y08KxxWgNA9M2FGpFikxMnwYms0gAT
1xMWUJeOKx/BqjZNxXRsCj4emV6VQhgdrU8vpwcKn4qGxHO+xnPfqgdaC8/2Xk70sOg1E+kDdKja
5W3Pw37f8a73SML1d/emuLxsJL8Q9p66zkJfnHw7ElPyyyGpnk2H0tVD++h1T/OdTAgENrsPCoOg
ltFtSXQU267/WG+WwkVFhVxn1Z2RDRQcCUCfnyCB30FKvYDDL8O7djki5AU2ESK2zEHHH7dMCg6t
98vDsLLlu97otolumxKaI+MvVDg8Epap7ll8fvkTaWIp0USK32u+WjQXCY8cEoy9bxy0VQxIIB8l
rIhF96Mol7Ms8kNilV061kpv3WeM0DtWHZsoKEUD2dcaxhNMGbyEEIyFo5AgtGtyTfTvXJkhXpUy
DlBcDvz3aMX80J5psGYESQWKt65zonobrPfJ4zOdFPiAaxTnIIo+JnQtDnP8ZnFVn8zw+C+KG7Pu
7djPQxHJqmLtBQJpFkBKsU9PtRm0ojQk13FPrBw3hVeXIHPSTmkcw/qHxOjdA/OZFfVaIlDHMGzc
sX8rYK7c+7ldO5uqnHfhv7YghrmV4bAxPAwONqjXUaQBs9t4tPlL74O+Cg8IhhubTVdTld9qfCYr
JYSk4VNjilMGLHSsFNssJImzCyHiNW11J6R9yuDaobvp2pgdgF+crfkl02IWQX5QlAc9IzwNO3Ah
yQ6+JMUKZu7sd76iFuzq8JGV+R1skpFx8GRk+rBkYLMq3gSHYeQQXcJp5a/OM02faas/vxHw94n7
cAxOdpsyIX/UzFkdlToFMbGI9btiC/hUJPcW/6StMrP4tgCtbkyuiymj3jsnQj3Twcyl5iBvQ4xM
kku6MKHEiB6IYVu4/uEXi5MC8O6EbxziggPk06MagWTGOlGPYY4ZS1XXnhmiwsnWAcdLR/Iq0spw
sSZtPm9vmSL1K4v7QKY1tO6+cDXFCdD6KSoAexbdsEFhrCYzsx3/FxEZ/vMB0s9YjkFPIruJ3bzF
DTTfWv7g4BdcrZNjgpgoM46F1XI+96MJye8O35kB4WA5p84W3XC9rhamzcidTiFvFe+w9r3fzZqg
Nfjm353274PCeTR0PEb0hzUMomRHsw1VA8PCLx+kRo6SopWRIUhxqQeH9p+3uQiUDp3XsVqpIYlc
ei4p6i8bnjA+elwRgVTS9B/T0lRKlgU8LZWXBC5IQmiHRsrskUmnNYHEHDW4qjCz7iX6tG9ZNLLR
UaABM+yCkTXiBFPL1mrz/afmdp5HlQ5Ov2+0wNQoV1dCMlYZJxf16M/ZOcJ1OYytq6RarY9+Zjh5
0+300DpnX7GoP64QnQb1UwaCrjhQe28vdwPzL4fdv7YmdlBrNlVhWE/sCfuoKnxET+rUA0+iItL2
g7nqrVPkSWBINs9aQPB+5iEaayFevcfIdclINzfYlcntoHmc1eQz5quAoTbY9mj7odT6dREIK4aB
YhjGFK9iajkiHXg9P3yuv1z5rBkykIZiz5I0whb81aYXAvFosu4JyDWBvgL9o/A9+dHFo9fbLCQj
jywMqMBUBe+vNNfVCgQVeoW6BaAIdbJTIVyJlB53yJhZP56v0RiP1403Iviwy+Da8IAW04APQF+a
02l2giyEMMC9ZA70jZCGTV7AZBWVWZ7f2HVHC83s8jTWjakjTzv8vC0nuL3hPkz7GEtf2nacw0mY
UPkXB5BF+fDd9IkSn5QAtzcq4Ae+Tnr6u84AtaQUctsIrWyZo7ZY6t1f3qznCgvrquMN1CfY/X7J
iMTq4QwAWDD3/MoLo+H0isq7SF7QluLWFbhyXKe9OU10Y/1B9rIt48a+i3ch9kmIvm0TUmpDhC7I
Mtry69srWOhKTYVmhCkBx6yd4DPZfQbGgD2URS3aJamelJ9RxndUcqvTYONbXSOicrDLd05IS0V5
j6LaxfNebc1peUh8Vlsa18jrCUXUryLZhG2nYD8YHI/6Yu3oBoBL/dRVZ8c3nRbRvAvKT4cEVHUs
XdzAqYNg5RKALQcschkSR3cXOKN8d8j2Jiok+z15+MlHIzsRUPbJ7KDfp8hgDq9GTA2h2MAIibgE
e4LiLF2BnLvheoAS9wMK98uDJNZX/zJKQKUq0dsfD7303YzguKyo23VO2kIGFfxs8Q9JXTvDkkYr
OfwVWLIpbaKxDIBoNCq5GtaOM1hfCZeWdNVIr4cw+sVg1L85RmXZRP8BUPvfzSAjOuZh1/nI82Y3
iKqZqlAwkwjkLnratqa4evWQb5vryoKUUWkK7s8D09e35ERFhYf8Kkf6Ru8XJl4WOuwn7yUn0AOl
4/UmaahG+NBsqlfBugWaiWZuo8CmuD9eNyPBOzr46N0UBb2x1jEvgp+HCiFrHD7Qh3CUUAVhDiy6
KyqKJ8YVIwJlVItfmv6jdtIWxKv4bwfhIu1YdIE2s/XfuQgQlt99TiwexbhWndsYMWDGtEz9eHaL
yGbtE2PgPUa8OJQDTv/HhxM6eweHK72qrBf9a2fNGz+rpO82Oq0lJyfEN9rvmu5s1T16rycEFcyt
n5RKKltxGb4YwP2MCH+vWYoDsA5aaZWIci5nQFx4BD9q09awcxhKMQeiKofxEK2KPIjRwzt9wuZp
tS9f23wC36ty+5PHFp+Ett/GvDKe98FJBFuGvJbBx4UoqIcJ0HHLNsj3mtcPaprsaJeHdnUFYziU
OUGI0EDYP2zBh8W9OC1hE+wrAKOllathTf3vpCJQJYwSqrJWN5E1UMbImTFeis31zZZPfakfPEXU
JmYtDZv9N3AFJE/BG/SciwQvlLkt7R7NE9OaNdD+AcXszVxugRf+2Zw6WFetx02hMauhQTxmzUlh
msl6/XaDaM7MYTXxNsQ8gAS3QR56lTmEKUETn4oVeedVci+R8eNicg8+9F4lpN3G270rzyPqo+fw
bp9mkbBn1kbT/NVhDwzwN1P5TPaSZSSQiI5vtlpQFUeSSvnRV/X6B/zwxP+oegcnfEmvYebB7e0F
Ug1nqxfxOWWDe8/SxFWjbii/FbZ7+LUFgthWiPZ46NTDqldK/k0VQ5OcqZxg+0BDZ1kiuq6yzY50
dHUuMaZ6rw3S55hjqXbdGSY32zHJMAQVAG3skCaZ2lNYXDvDXVbifY/RLplydti8cKkRgJH/gmdL
PURUHeZ9H6OIUBh6m7G+p1v7BUMz6tCvkA43r0iPGBuVOnZvJ30lrBhUEhvE4F7hEZK2hiy9dsGh
DhHYrGjc8kD2+9zFHIcQyXyFeMTP2e/LujeWNsHFcQK7pjdmYihSdLqKDEWB+vWYZFQAGzo6/H7j
otDzK1Ptx7GYR0eBBgVoqp2UXwfdwZwAT2hpEHkMibmsTdqYUq/GDWAdg4SmMOFDgDdbxR2YB4VS
11W1dZJSWY7dzh5hRBnoX6vVEsmHkaCY6pC8oRamGbbiz3A72bsENLfDw6hTYI3WKEZqBGrNjFg3
dYJR8oXL3CX6Lx7muQbWYkw1L7tNVnjD/1uxtoHsKyYlkpyPLgIg/S3XP8PPhrrVyufc7aAby702
YFbFOvVbCI7eR6GvscP1wqLzpBpNMfER0BDjkJlxb5x4A8EDQxut4m4JKOi0vhNNW5zMkvAFNd6S
jgCsp9q73fM8oZzSa5iqBE2p+uJD0X7CMW6ieP+FlP3FdHxPB6t1dKTOPV7hvmsFrSAOcbgsBUVy
4Fzk/vVhmBPTgZ3qfE1OOMn9mBathAorXOwZfEmKIFFUGLXiSIAdDnscQXubZZFVgOUvkmZ/FNz0
bp/7t3YDTjefshQbPDrZy2eRqMMyJV1vqlDo2dIDSPqoKbeNXLo4lxtN6GVzYBrd0/N0i1Wv4uUy
DBm4D471p6I8JwK5cuI5PV+06uUqqjhVpBq36tBTzRNXgOHM91rB67WeAB9bYXpyPzU4UXcylyRw
LV1vl42aP78Wxze13Lnhd/cLAyyLgD/FC3t/jmoXlqNWUhsGXZe/9rubG2pA5dzga69K1uDhJImm
XTOB3UZY4UsTMnUFrTWKXgKN/sPd2s/JJC09BU8hSpBmxCFd1vIyubAzRWarkEyCEl8i1SkGabXi
yuMNIkE37tPRcf5ZtGPkK7en9oNs+MFT+yiXJYaD3x39T6VM8txOMZX5fqn2SZPhCcowwrRcPZbO
iptXp9rFboo1IfHYbt8EyOrYt4hN/HMXKwP3ipOaq0OqRbM/Gb32qe2RgHCz6jZX0jQ4gCtC7YUu
u2SgFzrxo8brwvrmI0yllBKVYTcUdTZDAExfY0oBvOTORO9jAk9zaizo45fJmoZdoRi+ISn7as3/
+c+kVL+X2z9IGU/nuz4dEV9cFRTfrkDe5DFxTtuJh5AQox5EXXiXYyfWAucSV5KQvC1TAPq5r3EK
EHs2Zjx4rOKgIiPK3X6Bv8kzeZTWVG==