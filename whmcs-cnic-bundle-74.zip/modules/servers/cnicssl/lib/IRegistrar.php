<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwiiWuufytUXD9yMhU9oJhMpjC2z8cuupTSFmvk2nj3XOTYKy2fpCDe5igXvhoDeVPdk2N2b
eU2+ntzI+WZkwtzxgw3knjnQ+xV0QFtKQFQR3KrneAOWTNAupPLpnOoFifA35qjKdbGWNdttbXJi
NMoW7zV5SAmAfJdv/19PkJrEsAYMKj6xR0IumcEupN2CkqDN8RVeGZQCZGQ2+2eEEFZg5ZLwAxhE
xQUhARWY3nQyRnwKLjZZACtrh9SIfTsDumgNK5tJ9SjYZNnfss/mhxrXfI4VSNV7HN8GMx717APt
PdYeAkZ7jup5GUGpaMDEGeG4idM0wOGUQ7GxKFO9ldpWuo25IfwARxXN4ySPw0rsHsNJ3qy7kEnJ
TuCFopaMQKHAsk00g1yu03xkMURooqQuMYAI/HmSxnBLMLR797n/uQOdn03aOVWiPDGZeE0aTUKM
PAirC7gx/Z2Ec/O1sOUmk05KK3Cuf6F8GNzusg56/k5aCXNP7bZ61Sq2i7HInW8zG8pr5LBAMoZU
itBvZwMO0vUX2GExbaHWIK1XF+bEt1grPhw6I+nmZ3OfjeJPGL6S2Gv5BjWFNWL3qkmWNv8EddQN
2IaPTLzzAlxNYjjR5XSLAo+9WDrY5yNik2CGW+a3YX3yOtjf/nXbPyZEdz8v9A0d5UCwI348hMri
YVheb33RoZsnuh3eIG7a5F9G6FuI9tGRyDS357ZL7kwGeX0iB8wi46AtO30KoQ12ojDoZmoE4Z+d
JM9ASmRxo7R9JZeZRSaS1bfFPVBKbZ9zvs6E6eOpzsFIHyjT8RyS9RXv1OC15mMVHCb6hGuXXPRd
u/jJbMARjC0D4c09IUkOIHg5VTEoZu2wNzPzmNy1B8ZQHG2R+s4lacE3qfYEHISBZNBRVa2sfnw8
4kGcCreg3DIMvYBygvfAfmM5dxjVQCNB8JY94KiDfG2Ypfg3E+2qzZ3GJRT8PFX6al746B/ewIdT
2MBeFVoWCqiSopg8g1Ta08VYNQXe/LoEljeh7qBiQ92v+KCfyej47QpJrlkhf7CUHLk2NRTqDguV
JsnpfLR2aXnUavjzyy5/lSLKwa3tlg0HblfGp2xlAmKk7EMB4kcJ+r3NAyEru74utPM0JJZoVd/L
3LX8BoK57FPM1qAO/0hgsX+B/0cJJx9Eun1LXwQfYLJlD8wDtaZYRtOB69/VrtDnzU+Dx22Ote1a
TuV5zxy9m2syNBBPdYNoYpc2Q9ZVZkxdQL8Mlo7dPEzDUuUjHiBTn1vfdOX35VvEzbINYGOj9pZ1
WwX64iUuA4DUd8Cn31yvKOazUVaNloFUwp5aUUgfqboc/DztsnXKh7hlEkZgLF/XUzTXVQ0Y8voX
v70uFVJ9nWcg2l/UZyGRkos2kDsbu7OmYtPA863BxDw8YF1KcmB2rLaJwPHUPqt/CJGFlFF74+PF
aAOtzUZ09LaRhHYFmIiXwOVa1yCgfg1i8lHRYypQHsPlTOwKQenxmtkMvRos0pHMN4/PfUV9gIw4
erBhGyOKsx82b3ggiAqkcYaaGvbH3zComG4CWRvAYTlfgwesiweER6W1j2JvjWceeUdbxIn9ALpg
oVvLVjJ/sFghU3hfIrTx6le2Zvglg4bOTtDfnCLw7oCsn+dIiEV8An/Hk400YZWfla1p99WYjjcv
oTaWktZ9cC8lH7kLilZ30w9t5ncW8kzYSo+ZcDPLpwG1M7DY50EUgEDWbwXwOiwsMl6C3S6Jq6m9
2NzYLVxl8Rn5WBmInUSMjyIkrbCOf+h/3hpDGKPhcEiFXUj/QNX3b5/gQwNufYT08QleAj9BzWBz
MJGmU4ozCVpi530DA0Ui1o48MPFTjvDArbzKOa/WceG999I2QXcwvK828siJ1in18cVwV/y/p9c7
7+xxYGLAPOE2JrSKT8bkIbyESTy8RnMTHGZPmuy6sDubEXOV34RiHx3ixyQcIqCWKCiKuKs5YH+v
LZXsJgldIYRc4TwnownAl40NpTj0GYB2cedIFiC1bGUy1UGdSSxogivgtILACiulowxIh5Hr5H28
t0fPpnjQxbxFaAZp28gCOtyu8/XTTLj6stUvVubbHn28IMdi/kfYYpxer1JCE1d4s5dhlAGak12U
HygTtzCrXZRir0mVNmk6Unw3gd3w/9Mno4aCtufeEop4Ud/R3oR2s4o0tt4j8yiEQBW+77C1tgx/
9TUMFnF774DXU238BXql+Y0CfYgsyAIMm1Xg