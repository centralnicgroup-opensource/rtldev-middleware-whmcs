<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuQlnahLFZjje6HJQTrYSBOgm91uTc/eDAAuBi95+8WsJp3FRP9rCEqWpOQxEeSXnpFdqzxE
5XqMqWokV8eAlR3L4MAAEOIXRKXfv/NLg6g8KLMtUqk6aAltlhi3EeGnb4wxzvVZcaj+voYiib4n
j4N7RrYfedxD75QdX8JC0J0ZUyoJGtW4OCPxR93Q35hR6oQRjBkk9T+gZeCNzuOjambhVC5Mk7ZV
aEI58wdMXra/FhQIuqLTvSRY59G2ts1oxMgQGrpyBTnX8ItGl7cJBuB5ROjgMzK2XrmYUlfsbAWm
hOSqHKg002QGP6VAqeG8p5Xmz2aqyZ620FdgPtbgUdRRIDPFMLwpksQ+LC4okbm04a3uZ/OajePs
2tM5qjg19IFyTct3/pcpe9Hh4mSgm4oO5hU5awj4PVQxrY5QBGKKLiSVG0iu1D/XnHx8fif38Th4
3CtcZwIHkPipUCrJOpE4eWOMy75tUebZGKtBj9+mcKkifBfs+MYAu39AzvvRQxiBbcWGfGxmd/Po
vOD1T2074VwMANQuL4DEhulaX3zjIplXFkBfHo0BeRdFd/1S0oNfJ7Wj75SCcNUkbcxGPMlWwuX1
0rkSTMRUjnEX8nN9SnEwckHY6VJYLft/HHWkKhkiqdgYfPuEeG3C1YWXe5cMJ4tdPiRSq/oz3ue5
urhOJyD9hGMKk5QD8v6bzZBtY3vJtUYXWRyR1Kx4kLSES4dUdeFM+SAAZ6mQ5tXinH0LbUpbQi/J
E7VtWk3Lt3vUFG++4gV/popU+IAZhtrjzyd1jCjqu9Hn4n9ueWI/knoot2mQOTKojJleegUxooGG
eXuncso601iUWAnfZe89620kF+W2htT71Ny/wYrJ6vFKClIPhNz5B2kGrubdkudlFq54DZPhTbIF
sFmEuwYaqd9N/bw13agb06MmU0a4wykdhyBXORRjt50fHRbjxLOrnu68ZaoHn6/GsyUyvAyPCI8Q
hixMQaw0SxobvB392rJEJH+s+qxGLfQAWXweFmSmKXs4l/RkJxSb+pfnQ34Zr8z7ZOO2DFIiDdV7
Dg2qDKHWv5yTecoyANa0hQBHpQqD6lVhogzKS5+bXemk3bkr09YSPOkSe/cB7DE2XH4MZNljEivx
rEErI0q2rYQTq6AnJ4AUev7RRPDm66i3gkourhqFy+96/H/lFYf9Vc1vozXgKUwbrm4fCe+C/QgS
04po3SUZk7wUboneZIj5ODrKV/45HaPtGhRpXLmU9PlSmMiWMB/OJuEje1jnBCialh5oTRsPGeG+
A0qmP51aL7lUYjVOmbmf22n4cM8rZO7oNvbhoqUCnwn5ksODTkNF6g+gqdtOmegQRID841yBDSxV
HX9Q6VM2Bym8oOQHpbbMIulDO5T4oVIU5GobTaq5JdmjbE9WsXmnQmVmIqf0eGSLKI93Yy9h3tCt
hyw4GKGMf7DNyQgpWukN1MA36BD/hjx0NKxZBkXeIJWYbvhU2/cUUWkkdG9WODXBZwfc2Pya6LrM
4wmEc6VZn7piPgWBW0XjU9+DXlwg0jNjAFcrRaiCW+WfZSKXLQTmE4IMfqXCGt3E5u6+2nawZflA
kONNDLPGQiIsDLv/nieOWhhxNRGPD0/Emz3GYaaG3+aj35LWH3bmjRgbhldsIKl4RJKl8a3hA/tr
MxHHx1/r9hhUDf0uZekrU5cp7hdVun9qirygENOR6iTH8XPFhf+dZ0mcNETP8hQv5A/l71lYRluI
kaklMA0XwFdsvJs/EWFhtXYp/j7HZ5Yt+dfUsMnYvYJLfgI88yFbGkpr7c69PVp070NnISbefCao
yvOFPw/ZtcV7j19+Ka0QL/qsXL8oILUdEpIJ6SzS82G0CQMOGW35yHcVpG98c+qsoV+F/UA0J90b
ek7kt/xmyFtGV6fJ2fOHHsvP8/iLtZ+mlGxbWFxh1XAuuY1K7RUXTLEidxbXg2jxHcg4GLR98VMH
mCB+evLDftZnJaPcd8Hbf59kmqarWTBofhpiALlMbn/uKFUttON5Uf4KKc1d4+d1Yw+dcyIeOt3e
kIGV2KG08KFWO2Q91kSmZdPoAvvaRyKzzJCFRXceshpw+dZxbOAq78dyFq/tdFWbye0ILYVa92Di
gR2Gpv/Js9sKl0KkocbzlPal1Thn32DsiLREQytSr59smeQMSbWrLU+Ix0yeJrmZd4q7qUvCJwcd
HTCAfXR+sg1FrHYYgrw4T189ZOLqZCMQPLunQdC4Ib3dIVEOg0TwSgUCiDBJXvOL/35yL3tzO/Cr
o2zE/1vpyRIZrb+dotl5V4qwgnbOp1MiQ12sp+DNwOueDmsyYJxP4OFZMIcsUDMRBSmzW8EKxml2
JrCFlMSPpwCDdzEPkkRK4/kWRz5WAKTf3aWUAhaexlC9Jin3DLt7ul9de6T/hD5rO9qx7X6FOmS5
hyBl59QDx2MSPg4TEY7RvJjCo/LwXouEiC9tgfTtLn8iuDtVRLDfab1qGBa4EZTOyHcUch32O44/
CI6tjTF4wlfK05EyiDuiyUg6iirD5V1DYc6i1d2aRvLsEW4nceGpd4PlMwQqjaQ53iy3eL6UlYht
WT0Q6Wb1dserotzpzhTvr6/aKdFcbnrTlyFJSGAoU3b1wpdilUInoi+KyffgDreWJ5zbJNVMiQXK
IIoEpRm0x7p4iJx3G1Lz46ucyqz8bIwFyilUlUNk6uCSkQzR5Kh3VXe0qYIXg0Brf2eaJAIjP4qW
wegqu+17Fs+JdrVYaAfHlfvHsM1kDu2FVaYH+d1MLuwxyYFvMXzGl5P4L7qbcp1oTYON5EkH/A24
auB2FcepJt0632tavx/wGUCkDZkXbhM8Zv2w6jCzSXhkU0Zq5aJVLWGnN2ouW31tdiIH2aBNRPr/
lhEU87Q6bFUeVY3vU6Mnl78X9jzb5rMkURCeIsFn197vdOLPw2rHwXb3k+UEecl6mml2tbHLrjoW
heXe619PYYdkFGeWMv3+LI64VWKuTLUOCJqMq/EcsTOoiKi63dsDxUe3ecBDb/8ebvs1MqEjsHSq
V4DOqxwt5E68fPdUqt7qans48yph5mXzlS9nUrSoM4FiDeEdoKUwd702PnQaD2cVnnW3jmnFLOAV
gvFdLn467ACOpmpZ/T80/BsjBNQKsxc6w7sNVQNLpzUr0/soY2E6Fk0TcjPBls3JkB6CKSvozZMb
f8gi5GAkiOlw16Yh04VFH8Rc8q01lOTmGwASD1qdxVyRHYDMoDT6Uue61vYcQy8+1uYH0ASS3ulr
IGCnuWyrdkonqvXmdv5tjShAuH4LnwLwSm95aGLu+vBiQtvra5yMcwB1FXvStN7U60f9vQxI0n2K
d5qR8+q2QP4QZzLidnYoT0Yl4fFmLA2B6S4vnZjo3VA8lj21lw2qcsrwDuk5IhELcymepLkDYhXA
5BlvPfrGjo/9xXREUKUuCBVpkjFC2yIhlgGmMKo1VJvp58yivLmCY3upLwQXNvxzaEZiv3QKFP+k
WqTZIo6UAPfCMkNk83M+iVfM8sxJC1t4uBZUonU5wibcB0apHbeL5cz60H7Je7O/9zsU3XoVmBQz
QWN6esXYvDQNZY2vHH+SXfDu9cmJht7rJdg27mhdOjUbQFlBC/ugdq/S592oH4tTXGPZbJDiI44S
Uxn2ogoHmBXbOKER/8Js8TUENjtfnLJYDZ6GRndiIBO188Viv1U64q//cAB0g+CFhnIUdJXfPzDi
kRwxWSPhJ9IMSJe8Lk+6Z2qwK8YTcntahuDd+99BeXqo2orRHw12amYPZkOutiNtMDxf7DBYwDN9
wr6PiuScWu2nI8ZwupDdJfF6Vm0lQ+sgUGRVFVnStxWvOA1l/4zYRL151Wsgy8GvlLCKo4bc9dST
V3sadjTaDUebOVg0LpjxPeF9slJbQE/i4cDI96qjXsd4NKCHTqqpVOwMDF8t5o2Nf3GimDPTUgA0
6/ToAJShGQLMQ9GfgvsTowhytQRBOf7koUWdaj36Dujfod7HI8uTnHg6BWfoxRR+O0QSmInJ5Qmq
VWS2gqW7JrXfe/eQxtj77EUdH7KHOZd0co1zKwpn0YbqQSsk68tFI8STGRhHi/K/oyg/NcbeWt5J
XrBKf5VqjXwtnrYJ0/lHrKpVQuRbdCrLtUVMIbdH+gc5jQfpO8GCANEM43HT6tRx5PEPpkQQFZI1
SS59cCmP6tOGEgiCyDwhmWtVVYJQOitXIyeYcNJ34EIoOF133NQ80kC61VqCRIt1MECWdlb13rGQ
n12roaTbgW87du253e7PQZ/76OjlU87Uw99/uAIdl6Wecw9yi9h/e6hpKB+zOCAYNlQA2t3PjpWB
V4d0J14c+fqejmij5G/OoX/ZdMIwcMQAu5D0AgBBzVMTvIViq+zAERFHRlkter0k9QQO/NjNx8KG
yI7OhPjNf19BZ/37sD31ebY2fk21MbDbZIEIR0XzNzsCvPFc3JdIKEFBJjcb46mhwYSFZGxvEOzo
AabnMJCxUs2+1u47ROv1m39ugbi85U1/B4h3wXfibGapRH9WuU81F+vEcIaafMnA+aqNcMZciMJd
hxrHDCa/Qv1NSHn6UpE/R5MA9JACCkbeMjuF6mgx6bfi6hmUkBoRT2Wq+U8nYe5zFYvVeNSIMmWm
ekvYg74D1AKlpjqQp2UZXBhzETXChuCsmvV9YtkR9iFcsflmFi6iddOaa8izLpLFpsxJNwQJPEdg
Q2gQ5YgHl6OF70g/n0SqUXMBSd7gnH5w87d5D1G/DnXa31kEHmRCg5ZAPgY92bvhUGmHX5p3Hljv
5Pwj+NLu3bMlkEgcxkcBzW5BnicpqU7qdlGE5tBn6468zWURwKN3mA5TBS4+YqR0isgS6Jz2Y0pF
4fYRi9fXcpzgAu/5QKmh/o88gX2gon8YzA62GmjBIKZGnxJkXYhMoz0vw5EEcSts5jQZHTCZjxh1
Ab7GfWl+s/6YYbG0ZRC9csHPJtYyEbwxYaScQtkQO4GOKDUjfq+TkPnbsHOJBFtUYp4+bVUA1H3I
BGdgqy7aE+N5Fc64UGWBzJLg8x1gxv5DT1kbAC4j7eIon+w0Oxh6+Ac5hw7Jk0+cPacL6F+5ZWRb
5s9j8wf6EK62NKEJvtHEPnp5xQwR6r2P/XKSz8a1vk2+rNBCzFnI9czu9z28yvp7/9QCMzwuvEKP
4+8wz8arE2b/wydjvt6LXjHOZRA4+U6XqKuLgqyRfs8Lp8K=