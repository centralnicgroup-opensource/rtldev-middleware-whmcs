<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs4IaO6ji6csgDu4ehVCC7hV/0Vei8n74wkuS7esV0C6KoWLyxeuHWEtluVjeyvQEURwJC2D
jR+macKLsZgwlfg5CDAG16eujBcmPcOjOdmuszcN1oZi/syRNbxcwC+rsFJ7LoHZE0qTmT7CBwVq
RCzIT2AiRaZMxePJsTfhGrH9v0kmofEqwSX7air8VkFZImmPT7qDSnWm+IJSa2bK40pZxQUoRi63
9YMnSCwPXi0il2aRmqnYzQGMzMclJIcnPIBDj8k7Bd9okl35K6IoGTan60LhgOQijFW4OZSmxtNc
xATad+M8PiZ9QVvoe660NiJlANnCLkETbxMG+jRV1XJ54se2cyLD9+G2NoQvStztPVlPNAuH5rYV
Bniw2velxXCEZynRSHDpLBJZ8KxCbK7wU6freNIdmF27cvFeG0y547XwbzGn7fKUqStUj1WDcLYw
rj1hv9t0fIZVxqjn3yeslLGApApFBPWkclTT5nHOWq6R/Kg48MUZdmJSLSFJN9fNHuJtOL/d9qUq
vGzPWzSA5Lt0eDytEl6rUlWAXXyUrSmxGOZv6xe/DQHYl75tomIQgvaROUjqkzvOpYa9zNs8i0JJ
bk+xwOfXqpiPaVRnKA9ZcXT2iONr0WdSO6uMonHoA4zC67M3PsxKP8fV4SEGafDtV6kLm/kHBEpr
adW+7N2rYHjtnST9N+InfJRVAJ+EIQLVPFrKtMOsaXugaAnX8ZAxz7G4fWWI/l+xYk4cCKNM3cQH
B92UVUPanFyrC8ga0CdAeOrxlSoAyYD4SIEyhvo8V6WwGq99SjEfYB7Dl22+eMljq/x2XeALKtWc
3cfyDW7ysKuFcN8mGGWHW/np0eNHk8kOjIW+URCz0E7XB0b2JLUOfsfKDaGBG9NGI2kzq8bW4pBy
LwCvCf7tPRA+X++h0ZiReB4qro9DjDB75ziAtXPS7BZ2JJwSK4eAOzHAahnsAVtSj+MhP9wCbE3v
a8mUx0cgrB/8AAkT0F+CdCLqb0JNVvSjGo+cOxj5KmqkofcK6jlxeBTu6AvBOrvlx+H2j3/Z7Gd/
LXTyvNRMMcO4G4ZGQTwV4UorfseBVBCWVETTROneItflyM9wkVM46JYq7vs9Mrdt/zyna5SIc7xy
1SCLaEzvBTZLTEIGiKT4+yBAI+rJfjl/sLyqLS8I3VPYg6V53zo9pWE0EwmeA5vDMeS0OlrIHfM1
+3cpu5/jrmAHJBFmKwsyYXAMcEdktTkZNfYeuR+RcX89cNTdmQlOX0dLHBK8N2eXbqhdrRwsqdAz
YX0IKNBxJUQk7yrSEc7UrCX3RXEoV/NTJXHFloYprQ/Ej41sc+d8X518Enic++/KpziiamsRSR8c
f0vAfLlArRrN/KD4eSYMajsZS0Qw9e6egvh6tqm1hSySNIBWfaItlmlX8EoqHG6OXN1dgZwvm/Go
iqeVZBSCfBQWKa2pgIm7rJioxMqR3Uiw9/agktiGt7kPjdMteJ05bm+l3oTa0mTb+j9vgl8gIGLB
Z0QA1yeUBRovj9SqEdd3wTvSlKChrQTDFGdwuDCMraQOIdzvjHaitk8OG56n9+m4TP9fs4iFK9KP
6pGsohuNuqb+XRsM2aU7qz89vbURvvjLK5mQX/skfEIcjXIeZ5tcO2bLDrC8GU1DlQrZXv495zpX
40An5LzSJb0+Pz4vIM++RX+MTEMe9V+G4AUXsRU42bVkgafzmX0mrx/5QkCKByN4jZcoEHk+vRPo
ZEjaj7dBUGSV2VRcHMUVqfAecLdNAACCsmhA4aWilQEMYB3OuYP/PnfZDi0rISJpshaKj/wSY2kA
6IsnjriwRakLC79P3nx6nbkQa3Hr145ZkXhX+7II05Ro0kaqxYjk4idT8LRNcOYVWcTcSrtmI2i5
ByLu9OaVXKTrPqkZqQa3bUddr6GwswltKH6gIA5d+mKP0W574IwXgw8BKJTiAvOLehX+RJNwoyNj
h/KXGoTQTeoIcAcRPIxdxVec9gfDN+xDXWCA670ZewVIug2lHgMRbKcBgojYT+uHbKGe/zJWe/KN
j+HUK8c0NTtfPEFKsD6x3ONq44hiztMRYz6QNEhmTxnE26pk9YA6bBWZuAPmH8AOKRMPqUBdrXjQ
v2I8YvedD60B8cK4u/JJgLD7Mn5YUmPx1P8v4o7VLesrMNfhi+cpecwn7W+AGjLpYOriSs+Upyrn
3vZfNgTTsJzYS8rWW1y61yNi1Jd7a1q/oae7U3DF/Mba3lCsDLylEIc9rjIwwcrf8mUhpUDTWiyY
jsEyZhmBXuam3PpG8RRuvndyeUtq/FNRXdPX4Cg83Fj3wf6vcwF0qOLbW5W/kG8gd7l37Dveqa0T
gTZyYgvjGtqR2B0xFyAaWbDZ4iAcg1XY6KUKZwWOwOA7AkYx8CymUCEoG68paga1iDVOuD4UC11o
j3GQ7nbiVIgPNcgOxmoAGMn8TVBJvaYTbwBspVMeQGwx3yMqFxwV891gjmpc2bwDsJSJRN/o7uq9
ets3GuTmaNQkDZGVbW==