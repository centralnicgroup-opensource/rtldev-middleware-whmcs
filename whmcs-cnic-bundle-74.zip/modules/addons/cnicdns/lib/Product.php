<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo4Z9j7aevhcyU+pyY/CIWiH/2Tni6TzF+44RuuX7zu0lx9EsF9S+SQCNucKg1m1NyCjox0K
CKJruszGyerfHmnVHoDyq2b0oyI+BlusSfCaKk6O4FDohRRJ1WIi7ag77wz4//nMGblL+snXbPdg
tLrIT9G0Gxr5uIlTnZ/RgVTXmpZ9DnsbZDLyu6GpZBnsdhJvf+wY2QV7tU5iN2TufKHwoBiOUnPV
2SFTQhNuwsJX34aI3VVpOvigoIt0yggPj6NJDtn3NFmjt64XBT2yUPClWiLjg6sl7kyXeiH6GcRc
gC3nHbB/puONKejEy1otqk00/mfSa4bHE0zUhmRCB/UFFhU3zVEQtcNpblzKMxOMobb9N6Vf+UW3
50hej7PZ4ZP9d9bRR5Ktnw9w5YalA2oO2NbLC1bKFdRSJS4wHQ9TGzLjQBsML7sFWDr6vSrVl68Z
nRE2qTKe1ZkKwNInuhHkAjebhLf3HpBUHR+aCM8/slzOfD3RyM9lxuhgenLsffhg3KxIBMoDGccO
DULcX0OYw+W9rCp7qyEt7tWZHhfCw0tS1tNUuerWtpdj2fftQbBLF+hN3EzmopL81ZyR0XAiIMCa
9r7rPqeYtB4IpGtU7JRo8cgavk26n0LBz1M2PSMPT5Vz1Vzfe+h/HsPEkv/MtgwU4XgPAXAJZA1Z
Z4WnLX6wC/idAorJhmdWgTxhYbB/bMs/xJBKZWmm/yeUkj5EVa1wzNwugA01qvy2MT2UjiqD4xvw
k+RXLws3K2mEl6cTGqW9LCUkg1lOBuiLRoyplcKkjYqk8lN7QB/5yEenWypVo9rShVp/Sp/VZjQr
mRGrU5aJQQDn165e44SDn3cmY8cvxBdavKUkR1vm2qAGFdPdiOLLjeSv169NXjDVm7UwoVCSPQCK
zfV2QBlKoVxRbkxWfxelknvubrQjybsMF/mCEe7rXWlM2k+FGgl5jlexCjCLY1QfzQvJhDU/gpxl
RKbDT7bq/q/NjjGrjLK6d9h86I6g9QHbHvHlPbyNagSnlHHNLe2X+7gzEh1HwCZKh/mQ/BIam75P
6bW4K8is10Mu3NWQ40/j33AH3zcj8CMTPDY27hcfQ+nMRmJHGmuRfFQwbBwbActAIzqI0m0RbDRN
xoPPPCmNfqHCrxJOPk5HuWI1wX5+bNpR0k32pK4/XXSmiZtPgexfDIgOK3jLFoXTs8Cj5TaYxcKs
6vuEtYU2LBrl1Rsit7Vc+sPCXEfZfX84fTPeeSegtYfDLOiX7KknjQPqvHj7wazyxaoi18iSgxxd
9uLOAnjPrLOvU/kbD7eIyz0DdW28mAmBr32dff1rk1fNHNnuHsYPT0jO79Ad6Pvn/29a/72id47L
il3pWFdXuKXauzxRdDAT9Z/o4D32NTmJ0aXB4HZJBAJ6g6BljwgWJ6Mq+BYYtZPYzNNq94kJM0Bi
T5CF1hI1wAqK2gXo6sk9XW5w8bZOmoLttxJ1RlvuNbW6Rdr7A8pAHyJwdADJXk9PosXMKqJ/0L9I
qms9qPO5sBW7v4OxciICWvVV412TBnoBk8ATNGz0tM38U3TbNP/AE1FOMVFrqZxqzqDAeeSphENm
Uf1iWogiIdkF/U40eMosa1M36lxIAwZSOME7TgpLn6BZPCH+lGHOi+FHqAhFOwAJ79FildCZxtc2
bxGgNNXSMGkKGlX14ddqxaNLsBjBsTL/Xha6u2R6uuHTB99muvPBCV/iIMSKp4zlCOxvRYRFITgr
yETAG9FnuDP9qcFE9Q5g3mjPLmFhbr9nBagpWdGSIb7oec592wZqxrOC78zVsf/R2TUMXrtSZDnL
dX6eTcwPl8yQmNNeg7vy6MKE9oToAvbRmkmhktMYQ9YYrFc3z4Fdyeb6byYsuRPZeN+RUISpOm5a
60gPHIBki1M5fwC5FG8XnpjC1gSY0dGwlts1Ktp7oEb/hutW6roRe/1GgsN3FKSZF/7DHMRc4T1Q
jEK3fmxYOp+D2cIV/fyjdbLoBIeZ+mrcphKRhQVJFOBHV0RJspJOUcnuBKRtZSWXmtdMKYlrmSJG
+aGhuxeBoGAaAbF5Pid54l6x73yPKgFBwJRE+06/svXFNT68vv1rTUyFZ0SmltcvkDjBqqr5Hnu5
EadCg/8pwd9hQYGGyLs9LvU+rQaNQdj66sSqmTXnxuUnM5WCeE3OVWGnHEVEQSvyOKM9nv7KKuUk
N5UQMq76DhrLED2I3k9JH7D7Gp7awiaunS+kqabNp6jL4bFE8ExRPAIgEOiPXLsabDxKIXz0y0ZC
jHYHG/z1JDX/QinWj+h3IsbksUIcv1zTyr1txc9KoyVXM+gLIzwQpZ/uSrqK3htQXh7g2ktZzk7Q
tGL7s+9dYiXvEqvcVkcpH79V84YookTzEk+0U9lx5AURT/z7cAI0EMz+oa03K05rGaJ2OYrH10Em
400LNoLfmbAZyhF2WYsGL94hr+cVrpF2wqhiY6oaKd9PN8FEMcBn9tZH7V0oaim2fvZQ7kX6el2X
FpvIUW==