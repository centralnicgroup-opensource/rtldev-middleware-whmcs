<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvWq1HEu6/uaHOQGC0xsZjxmRypRp2jJsSPWxhPMBxbNeklAT40uNMxozvP6Vz1tFug3X0Sh
/dBsTzAcOJlTYjN8bRK8Gdr1hcNSNE19mhNUFkZ97G/hkKitaW/bOpDW/eZRCCTGtWdKdlU072AF
gijaqKERZ7qAQgRviLTMLzOo0eeqpYdYQYHBl1nmR44OsO0tN0qxirpj64OhKzz01frQ5aRIrkCS
qa9TNtK8ZYaz8/fk6NJWov1Fqr1gZzAHmRUq1xJ35b6nfRfTddK58f0NFJPPPt+DY20TRlVIjciu
uv4dDwducMydj3W7kglA9Ebj+lQgwaHZSK9stHF2fy2b3S/Swjd5FLk3xTz/nbqHXdYaPTJCWKlI
aG0FgIKWziMDT/jSkBZZr9bXrtsB/YLlx0IRsRGAA1r37l4uZ/EwgqYT0XcMkJkVFjBA0o+DDPlt
fi0uAK+rTPrb5olp+ZenTzvLlWZ+Z0jNX0eLk63Rf5taKGvXh+3wgxb67b3vwhfrRFWB3rJowpre
ziJQbwDs1oH8t5XnxvMMILnDwXb0bZ8w//ozh3H9pVNXPAlZLHYDpUPKjYbQg1P16kRvjMShpaCG
xfXJm51EhsdiVfTKu4PkGqQY/voPquvY23r6Yvaoiih+ZMJy5QP4/+D7VPsMbn22m5KPKQbxGx65
MJL8/fqgPnbVK4rxwNKqhneOyrfsqPl7JyaYAjfptIbM4HVr4yQRpKhNrmCjdGVUctMBKFjWJwtH
hjYaCzwFVgq0juVANJ3jhoaQbXTDlYtRs6ZYQXXlY1VPCmmbOxKrkBzIMIvrEz6JvuBLUnUc1vgy
PfpJLAKcW09jO9SzAFM6Y854GvOMYVK3IHq86ryZp4tqkhFWx0BEBWPnSZKHKCrVAq8ajuR/OUA5
opeTzL5bpnTX00c8e+8SvglVhP2RRRRl6PeByKULu4QS6+CksU+ZSyFdllukttZdXu0fArLDb875
3SqpQTJ7w/WWv1//TyNi3XEAT83Oe9lf3g95LVGJh6OCaafCA/eI/7Ia0ombZnFPg3E7qi9Ec1Q8
nl/vgsNj4FebBncxBH4LeTRWMqdPKYB2XaUNMVe7nGYuNEi6N9e3WBSeLgZhFvqpzP4BmyxElzzY
boecek1JK7od/NH0I+4bA9xIlrIkSad7SSZx++YuRKTQNlTgmoTgIOOGAgJAccV5/i6lRp9t2WOr
jEcR2BdcYRNC7GODtghoKCmq/iEHD6zUAFIu0CvWzmdjdxesRUwwS+Sh+Lh4BNfuRcarQ9rdhQxD
rltCWGXOjxneDPOGYakdsKZacnLgEm9MAVWxbgUBQLoPXQznKHVp0LB3yflpihAhY++0Lp9MS1Qz
fpRUBlaHA87HFvL3db+wDnp+b5t9RI7j9UbdFMoap3Z0tsGoby70n3BWw/UUA9MjnZMhjOA7Qr3x
QplYcvLsFxvHWGSihB3LZuYNV0/wHMnSqoNnuy0EAbI2/AJ/D+k0von7jE6NkOU98ANWS3rZbxeo
AdCChdWPuq50Cx7q1SRvzDkwnXt9VfZcDI1ZxuvHN1KPraHnHe74AuCoGlt/RA5zHgmzkUECC+6E
8kLDbj7/dl72jIa6g+xZfwExFzkcwnTEhN5U2PStp3jWsB9AoMxoAM3gB4Konuq1ZWdfyHi/OaeR
9SKHC3qKPRu0CJfPl98KLu7UntYfa/dbn4lggO9ZHvznd8qZGnXyflNw6z8Fw9QBUPpHPPcJH1oA
oHlcy+c2h/K7aWjEH/NXlxxCQrY4W2SqATN6lgAR1tub7tYyG+dREEIl04AoEATcFbiG