<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwxpcjnuKdyJ1K0F/tjRpQWnAA/m2gkJDgguN7RvSOYVwB31YN3c7RVn7rbrtbiMVscer63r
PUsaQFfWw1aMYar03WAlIVXQDFlcTGySrWxrzCzrjIA8Nh1cGKCgBYa3DlwsjAfbJMzpn1Gz/baw
//G+CDVMR6fRYMX1O+PVp43bTptKTX/MDhpEzGcfE8uwYS2Vqjujxp0i0bObvFdoW0ZFKYiTf+Tj
x/+yGw8ryEnq6SjtnNOW9o0KQr9mCxlUzzFbjCCMKR6bkbsUTGKYa1SzDiffl1xoJryAojpLH/Y6
wmWe/ptLAAhtoS/B182D+wwV7WuqcRNRISSvwePc1LrHqH6zFuCupFIFezA+HrZ5hOxCNCEAQr8J
halSCdwzypqncoZTjJywFk5oAVVfSHUjdzQp6vj4amcnTPECTnnUNfbZx3//wwR+7gL9cvTU2Ozx
9UMz/HRkcvFEE/SN8SpiVFauymfoogct7FuNuMquvQZEjl+uqOkExqBMLGoJcCGlWZArCl1b/rU9
LRzddl9wcRNzMiGrf/CF7kRPeFZGmap1i9g/B/hYi5D4IRPVJwgVjr8SXK4NrXT6P1PMpzR+Kit8
VJUKmPMMDrZGGXo0ykzJ0vjN2SsCzDpZNlyKYpH5Lt6HZvplMNTTgLm6jNOTLGH81Dq26mGrJYo3
1dUqSXMtbtBpTudbzuPjjqYAg1T4nu4Y/Wy8XRjsnGgOw5sdc8OSPTncji+KivHuLOpdIetL0hbC
VkhURF1Tf0bc+5YrMZJHqffaqL3B0tIOU/SWFbxOJzRhbLU56FYppEqpjMLCedzKuuDas+sPOpjv
i7Otjf39rv7YHMqQS5cHNwruBE7CeQM0azrT0IK4C0Pxb0k1KF0e6ZDTMNt+YLU6GlTXxx3jhHBt
xcrwzhyA5toI+8wl/IaFIX93IC3vx9DilycQameR5Ix9PW/gYPa97K/6fCMyZ5L1s8jhfZHf0joP
cKPdB0Y+2Lw9WyPve56Eu17xPYg8G54fYcTKN6/z7xEQPMOYIEcsaJCS2JESxEXODRktQ4xuJTpE
w6Ru2f5Ba7lSabst1T4v6kZvhVkRGN192AbDKH7yJHg9NidM4ixi1yEglhNmYOe/9ABbkzjNr+JD
A9q3gbMgNtuNYdy71UVswSUvP8MtvV6e8LA8AvzY0tkL9+10oZbJ1yprPTnkFNqO3OKpg4t6MrnD
YeHAOdUo+3D03AuSNi+iAXnnSjPztaAkykTgJxFs9jCBlbX2lmyo0c+OLMqxqqTA/ydedPaCcpPz
XwxhoOdr20m6LXBuEroQvnE5vfO9f0xQGWHz6wVmqUGATi60xkYMbgWcN8OrlymhfvAdKXGHN68U
K4bv9JPQ5w0TTFmtjjWTeK7YANF2k/COe5bBelL7aho9Qv59mUq6LOClob3p09fy7G0A/XVoW7Vz
8nJPynr6dJ5UtWGEO6APy9lQyo8HXb8Pedbq2xrguiCWextdmGPYk9MBNS1+R7Pl5bl74AgOeLU4
k6JeMBndlxmQziY4FafQPDuHP3IUdJ9/IGqEsbbt07ukoD//zj2evRaiOdxPo8w84Ij5VWfXYUXo
GLXOIEqOduN1/nD/cX1gkCHlJQfR15eru23E2kNaijgjxRlFaRPhl6MpjvbERB3jIYthZxzS1LiS
xjk2SGWmqwQtgLzjesQnNWh/XhYLIVu71QroLkljZc7u1Dd6N2XIyvKrtFtHH1CcbKi147OgVIbb
nMv7ffd7xhWxiMl6KDb+ULMA3eo6cmtwr7TMHgvNeAmcszXd5JesfmqFtadKuGQoGBPfpS4t7+iR
I9+NtMsfCL0B5ZiY3LYhCk+Pc6qd6QlYsBnIuDRkildRCGuJQMJv5NX8sM+OerKuj3OpVfbNxgUu
OsCpyBdPxb5ow0D1acDAEU97zsukyl77hLpKZyW1a6gTZ5TfL/esKeMJaKvJNtawXMcNJm+86sUS
YsKfkZDFWkZaJ4h2w8c+XCAV1QKOGtv5JTaLJm0Eu4JmD4dHlcsuyXprwKB+3csM00F5FKsibJaP
UQ66mgHFhwpUqnOhuLJITKnv+N7DYSwnK5hJC7SKe0/hlR9p2jkj5JtTiDACgp36nFdmF/MyeOki
CtRYaOeivdknEKWRMgkwSf8afIkDw6YGT7/drBx/BrfUXleV3tScAgTEZZjQLQ4gLojvObaPRuNp
KD6KOLKxbtLOj8g8klJXwzX/NbTZzTDfXRNUL0Gixsa9yNMDXI2F60rZkuqg6reVQ/zCk8jfS17K
/CU/owoKI9OkCIHwplU74vUkwl3dDW==