<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPo0R8EnSvPZ36QcrpsZVbYv8ZXZq7meRnxQurCfpsMP0Yx7/JsDMaF+5aDtGrca/g5q/kzII
S/HJohpTSeWXqxAJUmc0NhQs1LTW2mZ2AgLsVHU0Dy48xL2Ac2GXuIFfIBqJTxn0fWBGGhV4Zn20
rEzP/but/9zfLzr+z9cfYToJEzAZndQMMyO8uAfultbWulVU3Bs2Gk14bWnCnmBZXb44S2YF9Au/
megrSAfVJm1sEiAO9K9NZrhzlQ4fqqdvvRGwGrpyBTnX8ItGl7cJBuB5RS1heSjN0iPUgFyowQW0
iUXU/pfQyN/8pzjyGAem6cZMd3fu6SdoTArc6P8QG0ouPKHIUY+6+sCLOp2T+MH9AZHUWCsa4fpQ
mFY15kVyJLjtPJlkXNtE+uUYRIl6yrz1PzuDiwELj96lULKOB2zVG5ECfqqFhdsxm3NiKEippNWu
jHSQhuYjwsHywSPoA9IFg6dxoZfHrZsVLtRCifxiuG80yznszuBxGP6wCLkQFNIqvr7ZEKCXrjTQ
LoL0t/87vJQ+bzpvePXhm3lcABonewFFpb7lIuxwrvCYeUQP+0k9RIV6JWzD4nr3nNTsXsYROIe0
g0xVfSHGU32oKczt1jr21pLjg+yo+8dbUaqSPe7Hxdl/QkfAgdsFwUbwUUZDObu4agsfaVEM79dm
5VzGt02eRj+7y9Mi/2ILWje5/Exm2CdBLN8CLa38pQPIx5rjY6/Qs3qIr5WgK80XGhMX84J9JBgF
EXIfTes2Kk83myXuPZAHV8qzpRoSg3zwkEj87hPzAlmsFV3gRWOYuqb/yCwu/ssxeMsCDKAVVCBc
cp9Xsq6WVQyX/DjBv+dN6GQ4ewbmoMgfnWVfoAsoGis6oOG5efWJphBhQSk/pSweD+CzWHIjfPFO
5Tke0gGkGWvAh/BVHZ2XOpOQwX/w0H/jPmYqEDQXMqZjxoCcp7LYpUL+D03xoR6hIfiY/bIJMs3E
Sv1zM/+LCPusnVhqnPwVjUORQ9UjXAPWUiDR1Hux5YNxjRj3YHC9wB6n2Fo2hDrfUKA+9tnHu1el
8pvGwzuGQAS/ds3SP7PNnO+1cars3VWr6KEF/cO2yZbWjVvm8f+/oEIE5J8hU/PiBZS8D4ikJlII
64x/tH1ZmB/U5foY6DQfuld2+fkZDVDflljNVEG7tpxovYNKtxZv53WbZIwLm8st5xBg811AXOtj
N3dJiSkOvIEwQVTGWMsidiLMQ1od9+bvdgyo5wLo5hytHc2fo3vV2EOp8vuH4HBgeFcR3x4vp1GI
W5p4/iHP6krz3BwRt06ZWbSW1TTsKAIObrKXHG+qDjSLE4qMiiG5l0uAM6kfYPZx5VNsxhFZ0LZO
Wc5Sb1BN5Jfpye1oTVDNx74DQINqgVrKgqhpGzxpJBLfbHTmnWNVCxVyaNx4H2fzh+rYDE3dAUDS
ysRRqlFirxH7oBw2/0Ty8laomylAjO8Iqd6IKiP04+RlmvShMxnb5laU1N+uk+6Dd2gddm8XI/Nt
FSrfZYbDVcjtNOv3NQNYtbReU/PSEyrPC9mttEm/4iI8vmalDpIJhsm0bP9ZRFWx5dVY7QQfeFoV
WTS5Z/VopuU3ytCSLIFmE6IYa2pj/z4UCO9b6MLzmzK/B8zCHFx0fHfy2zqGKoa6uwydlSn3gdKA
lDEtXDzIXbHwPFK2HkF5/HlQ1sJPwh8s+9y7QwwLN8y+m+YChzDr60oZlM8YGjTSclf14l/XOsF0
bF2jWSTp80CPp1c9Exo/MFZxKm1vvs0Oh4ck7wAx7KLw6ZxqwwDJaS1wuIOMmyRhwsNB1DIwLLny
26okfDPFokvF1FXwvZ9hMDsK+1ub178rLMBqXnpTNMYJBTnrEIlaSDEvO2wUWtulj/igP3C+JDqJ
Pvw0R5vraCTtCUw6XQr+m5hMCbbhJ3buqLVDUcnnVXIS9jRdbW3fSfsQeqI/dKU2L2ikHz9kYJjA
2AzIr0N2lJhLAy0sSuJ43bBgE+FWzRvnfoOtuGBXJ5DjKSRtbHj97+7a23ibrODO4EDiftpRahYC
8FQSlTlIuL3tg5fO5jWjW2jTtDaDRhtlpsD9vtvBX5MW0w32BTFJo8jf8MV9lxV8jpeJ