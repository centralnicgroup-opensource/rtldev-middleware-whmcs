<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtJwZRoFHNQpLaWOdzxT0LlshVGE0xs+RSsbLBjteyIHDwh5KQ/1186hOI+TmubhhFb65E5B
rg+emgd6pYkZi8ISv22sKMM3K7WeeMXr8KDNQK62jtaIhUyTJQICyCIAUPHuZSOWOrEg8lZgtqZL
BVhNWgC4lZlCtorDiCvK5yt7xF3owO5GlwtAMdQTP2p+/rmb0mD16FLGFOwzGW4/b35nb+H/actK
IKdroqA1Wm1bYXuvOivrFPoSWoLbkjzxZn9QcwMuIZQBYWnStR4V8zev0JP6Qnmx/yxcV9HfdgLq
bWA7BWLMazf21uva2uywajh/zZ2TU1I5bT3So69aqKA5vxBMbESjN1jCEp63Z3VUZPuD/PbkehSu
AIwI0O+b5lQN719aq0qM3DT8g+9h9Gm78X2P/Uca+o5i8EiJrp5v+lH8feGey8iXaS8kFeC3CeS9
wvJwRJduaC5c0mjzq5hSwoXmcZ3ZXbOmkAzHm6Fn64EL2Qa+j2IQvGEWk8jBRMd6g5LJwzoBkCLR
UT6J1YbPrdpuo1k+2M2ePI7p1CR4v3SVXR6xGpMlY4u7KxAerSUhRnrR91x25fZs3pzm4xE5z1Jp
2IQM1MgcPKu7Iq7b/p0fRyfNt776sWvkmOed8qkbRaxJJbiB0rmlk6WSuf0cG+iIBPSdf2jYU4yD
bEx4vwEGhrQ6Clp3KJ7cAChHQQ1EQ5izZavlH+9zoe65GRJh1BlcZLqdHjwVrseX2idCDM6qOCVC
u25yq2sP6Y9zHAmexseZ2TlW+/HCQFEstEly7HZFuAE5TC/adIcVeQfv4o2bjfKZq6nZX2F1nyXf
3E7FpA5UAxsOLUL33h+lPjNmQKt2hg9rC2A8G72zUuSWnFfBZJfm0+AjB36FiwwYgfs/yykFPIeB
eM1EnyM82iwaIhEAyrKwGA7K1UjfeBTb1RvVtVBBsXZ5HhdHDfSodpG4NYEfICp0/MabjgnyIWCi
cSG9/yX8RAae4IwmVdLMedRAl6p3xHT5+I9gYMYyh+koioZFQ0qHOXGEMzjaTE7IaSuMWvIIDQjZ
IM2R0K1k947UBtsKAShlbPH8pLNTOlHsyCn3NvI5U0gg/1Tg3R5gKLv1O42enOUfYJCdiapd/Qwz
YvO0D58OiB/195YrF+rz5UQ6L+UwiVPX8sNMEObQiwnrMiBmJ8Ufy41O463+iF7ohud12UUWM42V
b7DhSIgfrOLBp4OeJKg505ptHmy4/iJNz2Rq7HLg42VHY23ldjp4+dl87dJjjzQKVfPI0ZIbP94p
enDtBbCGseFDeHo+5yn+wzkLA20KXJjdzTviipL1mSN77y8XiKhCh+PS2AYAJAV5UH2KiJiPsTNA
kQBSTdIkA+y/cGnKMd0qCsxt1ck3XAeVqqCC+w6YZVixf2zjz7dWnDf2h/2oqnaht53tKDtOBFz4
HbkJel2ijkSB0U+hHn2EHfyZAZ9PEnZucJ19e1bjXnYchXDVhww+y/PKICKO8vGDFHL9b2sw+0s0
61rYxspv2ANl7roP7D6TOJHz4xdcAvMpzqOjJkH5f9IH+Pplh5Q9bF3fMdqUaP6Yp+OmdGf2D+VA
22o1Yck/UpfyXhffwNCVmHpr6lk0SZ94jDkYxaQt2W70iLofpBjW1tECozk/4PdIwJHRUEZZyjRa
kjNyTA/wyCggcG/F+jRKrtp0W1NvYz0Vhm1U8wacsofC99pB5+5B8SYt2qP7bE6jw6GY0LAiAeJB
3bnYwwoYE1hxiZBtasUuTRZgVWZz5plUghobGR+O68OVgC9pKrQqmtXnXd767bbuhvSl1mi6D+dk
qUQlLee9wLn6DMxVDDcKmt+x1z77SYRwKiQsgSgczcuVrNPRdR/Gw937XGiQJzUR5x5ns7QOucJ7
pvHZXtZPp1vDwdMD/0sBoazBpx0ZyIEUcfaUg9LeLynTzjlnD2fgvL5G1h+Fi093lgvgItHpUOfw
iPxFFl1FgQh/NzO9Zv0Mbmo8eNR80ORqVIFRzqHFwGUBzL6twDAhd5viO9Lr77EdaGqEQGWq35ML
vflrgrypjYdupgxIThySc7o1HCYUpSVhPqJtmy8XNVLDiqJYNXmUgqeg7299rAqWh0ZuVScBQoJ9
ds0k1dmXDe296go4j7um