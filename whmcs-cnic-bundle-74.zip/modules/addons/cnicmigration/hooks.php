<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPs/fZnNhSdHQyY0QDd4ekDr1DPzphO0G0TXs5XT/BeYCwogURJuDBudTgGjUFWr9HyyDEe1K
/Zy4WKaFyKlo5pscNQNBY3A19V7qS5v5q9uK1LWfgu0CSqaLNOaJekKadqmprPsReCWbpdV2Qx5p
m6yfiR1y0YCk4Scf0R4gyyFT0KkMYXJTRdO7uHL6SXJhzAv1q11AoqKE92Pc2+0KjMyiCBGltoOq
Gb0rqBLuKbW+jQXrR3rcULCCA/3quzw46eq74KDS/2tSOI4jqBnvao+2nMqrN0ZAnPuqawZ/p0ke
CB58U3QUFKn4IIX24FaWR+yXdd/8ZIRFU3NcmiJ2BZTymwczsJDrlrYonqCrISIVh16NcJS+rvcz
MFkOWXv1U4qCB7ThL5uJvvUe5qwop0FdtF7twYy95PYuofuE2RkTRYqpifNcN7xt81JLzm2tp1Fx
OJ4zGcw7O6imhlkxvjIUxKadMFHoydZFZO/rj0pphoCAD8nAXXV66Sad/eHlDZV4iw8UJ8NbVZ39
YIXdNkHx3CovxSIQx6eN32fGIag5d629OB+UofmnhD4Se8OigvD/mm5ZIopLiBz52QhRT42M2I5Q
vRy7PUcuLpuJ58GKDQaV7I6YgC6/SFgjiYUp3g/oU4cCZZ/TnVAW2LTL/rYT9ptoFmhpyV57/PPU
HIWrfEPnt47+AmRoTkRoVMvXmz5zyBP55Mg/UCYuqKOajk28SlzBuhwCsYIwkl1rgde7mByW63OG
qfrRnuPeKdwukA7WrvYWGI5F5rUJQSLoOcMdr4sqwkpr0GcU98GmeqOm68ODyP7mOIwHp+NExJE0
u+oIrhGA7ujKPq7ITPorbgx9TX7UVRA09+znAnv2EbLE9JJ0zxQZDCie8rEnPv6VVpy6sf1PdcEZ
mni9ElqUqkQIV8qNOgdhfY26WIZFsDaHT9j80uKD7/kytoClESUj2RYm/HPLst/ddw12Jw8Ij1wb
7YmjUH2Py6F08sFgVNGfukZ0rE2341A8Q5vgKNAljuh8sikkCXw54tO0QBeTXTaUuKgzsjtwhh2K
oGADoHW7BgIKOJydQw1ri6aLJ4cc8WrEZoWYClFOyUaI/VZ541Sftl1rumKicFDK6svCZWDS99sM
FSDEYvOW9cKuPCDgdajcRY1cpuSAI11tfF4MJYcKL+NfIEU6TE+06zHGk/JYxz0f6PNxqO6cIOHA
oXVfreDJwUXEMNz56F2P9KiRyXqoyMJ8XDngRtk/WkGNHxt3RmgfEy/nn3IeH4p/1ZP3Mq5hQV0C
pVGbSOgjgD6vyNY+/lR0nWR9jw+alLI9MLUrTkpXvQgczpb8UbhRMQ4G8JgRB7k32d6wtNqZixNo
JlbuhwX/fmh2ycvDjmMCa1OsB/UYnli/BZeOBTQVVRvBCFwf2fo9ZGCZydywfBEqBD3zXjoUG+YF
Trw9i1HQejjYW2tlDsQx5TSierpqh5c/mU94IlrpONAOJksJmlXirK70YHmzC6RWYehWVeqcTheK
mSR/KuAior/P4jsCNPt56TH6pKdxLieXBVYLvtVpytoiBJaa0dLd8FeWVSTFiI0v7JAzseXYvAi3
th1NsWqIzVb5qA4jdYNEJvDNOw20s2qAq/yu+5uCwYoWMAjGMAZPDzxK70KaeSBB87K3L7MxDGKq
dFFjpVcR8deV436SgXjG+6K5eNZK+aLi/rql/D/nsrvQkbwTQa97q0ZB90LQzxRZcBks/0DrxL5k
2kAcBJgI5FUrJklEUkNat1r21+rziv5i0gfEFmSpb40vughpaD0EjddeEsBN/wknpL/PE+80RlEs
mBovwN2P8bogZs/fFpxIh+/YH9T6Bvn60Q3W3JZd0wDJs/dyaI+6wS749i7lRsg6GHlqfkE47xdV
9L4YOz1Dk7PETICYa5tNTQnfN98wmt0Gfoq0PT9Xt8o3oxHO5A0PPmeuSfIjRiE3wqTQrazfLUjr
9r4f9sNEFtg0qTwL+3HfWfoO48mbfv/pCPwk2IcRvfoJEHTQcYfjAf6cwLdxl+p+nsSi9pgrBVff
APDSx4Jbni/7+bgFe2Ob0OHp3/X3vAKAeBYfsXxWWxIN+0E/p2j//xPKdVGKDbfm+HagQQdYhsnn
qAcE36hQZ99oJXaZdDSqV23xew9H2sTD4Rr3SHQXnqW2EPoXzXQzoQKes8U7H6WNfLHW6rD58s2y
EoP8fOFLQ0ptfD0GYbSguzrPc5NRWeSLkPkR531pS/ukSiok8/Z2E71KpGoVxuUKbVtD71Z6HEia
bD6GaCFJR9g3AacJDpAi+BDP4B4/pTYCw10JWdToK2R6zZEgPDAzh4AEwMLqBSbKX/qIujbVNDRw
EG7o1NT4LPMwai/VciVSUckEVDDYjMthtxO66pjrnff7Q9wag/l6023TbFjxSO60qmIIG2NVJAvV
zuzISeI2J+LCIdeHfoNiMSa1MHhat2j3L9+yENlGgvkq5ojP4plwlk8n4HkUiYvPPT/jqWRjG2Vy
GE7JJko/kvqOz4BXLEmdSddhsHwPbmOT8udsTZTE57OGCP0AmRulnztP6UBDQxlK5f2ErEZo7Ts/
X44MdO8gPwO+z4har3FBez/ziS+W9RBI5+4AHYUR+H02nRMpHg6CjzUyHIyNtpyI3a5h+xDxGAuH
5ySOa0G0HS3uxRPn95ywy2To71oyr5T0by4JZSJ3luxoaiTE4Vx9AXVhb2Q+564WNMZy4GcAR48B
TTgLVcQ9uBFanLaE+d/Q8lvgkbG9Otg+1Jaj4yMJbuD69dpTcILDeC5rWXbtdFFlOPNMPFGmA6D9
QLALpwCj5r8v9RR56x31Lw6IFn8itK4HMf+M/rDJKY91rnqZRkYofbiBp251WGyDflllvTDlQzSw
gNi7Mk7ERkMKpnm0B6062qqzLyVG1kcMbqkSWeIdPaT/iBf3AcFgFZ2a94kHVab2j70C52tFqsfd
jY3Fj7TK40O8/2ySZkc194WzbSrIHaARPXK6hFp/cqHUV/QSZyVHY77ELBo2lyRgWjsMI+caY1rW
qe0JhCiRr81lPEsoqxMeG7sqQZlGlFcSxe97Vuu2QRIG8zcE9pq4Kj2d3Xx/liLwMXN7qrkxOcaH
yuNQ59ho9OCwE+IixSVkY4bUQrqRnUgog8bUMPZj9bCuJ3tC5IAJfZTfYoNW2hPEFL/CnyUroZh8
YS/g1OQKLlwTfNgH1Ic19EdDRQShpL3XCG/08CKYrQxY2BUTUohSuAP0/r/nKGCxzA7vZjvYLwSr
VLjh26cbummlOLi+L8/o+u1rKeg7mjN1nz+Tg3iAnypkzaYY0w/KLe6fDEBPiA2coJ2tk+1bcrcC
A6cv1PnKkhHbY5/lvVHQShJxE+DOKASwZMfdDbsPmQ0qxfoLtbL9knf/4fuIIcCvEy/nbF72f7c/
McvECo5EXAcXzudbPVP4UFNngHICCAttrhS1eMY+GZ0p+Zt04Poby29ssHNcjK2ke+Zr48r71pWI
nF2HPGicL5a7NtZkHXbJkjYgiSnS7liJGYX7MGluXAfieEvZ0geHtzwc5vrqdMy1YY6LxEHXc7Kz
CXQy0WGDFvT2qazCZEt91PZ0hcNWs13AmWDGHqtyCans82ObNCcJ4n5P+NxfTIf6ucDHpaYP67yK
dr0UllPx1Sdz8TmdHUtkvMWE35S3vhE72FtvgKNJdNcOjounOZ5mDWxJOd5edulZX1k3vI7qDklS
o1VFN8GHrgATl3CV9ATPzP13vwBiwKb2zgRVSZi7Kq8tSfW+EGcfPN8unvBzsVCpfBdxXGfR3g5e
7tfXaF1IIc1vmMMNxhJAx70GtYQNi/6pL73nn/FciCVW/Brq/4ogpYFmA/B39uOraT6r/3hX2/vE
0NVQUaSf2h4JKHmoH4J9udl4jvFduNK8WLMFTlYI9PYkRzZBiVoJVNfrzR1ais195H4upwROBM65
zcqklRPCmdcOeFNmWotHXAtCwChgETckwU/I67JJ3tncgmdQ3n8upuPEarmvMdSBGsHn5w5sjsBM
YE94RCCgz/n4uhUEAxpDpDSYk39hzCq2sxcqdcwf34/ZzDQjev892geJzrMNNIWvz8gV+6SJ9nOW
EuXgl+whxhLJ44noqNSdrkQN0i/RO0Ldp5gCR/GJz6wqpLReupI4ZPxYXel0kI4O+H/WXZWjDVfI
4o12n0uxK5Xrx66mjrBxFWfs97oN9jtzB3SbdA1cBe9XoTjpENxqCfri3SoN7kcUqPNqleQLaQBK
BY4sBDN0Km9pOlDk68Ne4GJ34maokYNYSQe=