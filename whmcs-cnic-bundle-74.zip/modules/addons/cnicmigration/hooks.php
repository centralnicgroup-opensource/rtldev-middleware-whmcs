<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnKtTwtma4k3ZVxYZa+Is73KZDeqLnPbyOEub9LigTZarK4+oZcJa1C+C/tHA5d+W1QvtvxT
LopJcp6lgnYTLbRPmQ+/xMRqKH6OVdBLPvUw3Uf8OnNfi15mLC0hrftsSqGVel+nhLYvpGnajzBy
MeIJtd3OxKHV4jjSzPsoSQ4nZOwx09xLUjAmvJi50rAjGC7wfFs5jT4zBAjnP6nWu3b9rfDaHq+1
OXisCHbfZqOnnUx2U7/k8MILzqrpu8Nk1Zw6fRXADekA35pTiHyZsZa1DZvjEgSh36zXoT07ldHM
J2TMIpILOIKEng5sh2s1Q+w2NxKxWium2NUEwshpGJyud/SbBrdwg5wgOF0ix44c1iWRy/a1FXWV
J8JeX4RRi+O+C/Lfb5Ywn4WUrS8H6vPkTxFQ6GzjzyiZtq1PPyg9zHmoeFeWuYWnpPchWCcPRqDV
dvsnyXf5smHEANm43Zqp488vBfKOEhjCcR0NFpXhAd55uUQNc3yq4G9akJ0BH6MO3ZT2pZ5Yio6q
+qwDsemxbhR1xxTyiVyRU3ycJoirIMBXKQUQ4HyTZZBmMV0gOnG6hfZtg2pRlYUtyrjvBYdlkCZq
d8hz9E4tVFIUgSc8B0AnS5z2daLobpHpjTnf2vv1ZBQQOGAFZeNyBijHs/vbZ0iFudAIYb0BjYix
AuRSww2CMe4HoXPR0RhU0nI6vuaHA8ec1tUaPxUvNbVB05Qhwu8CNWedvbERUXtX+fgKRlVEuaU2
cLWL/by9ZSTgwttnc/kCV01L+/izu6Rk/CxwbTwWb2h8cn6b0jIwX9ik7zgnhxPEUnKLjf56pFZ1
iATOP6kBu1+2/n4WiDHGdCgIUvzUfIv9RoNzpFrmdjHt/RrBhW74ARWnUREHBsvEk9X60O9k+nkC
MUUagqvjRKsYuGHHwgOeQNrvTgxsB3YDn2FM7LrPgV3gizrAovupZQLSsTGgwuao81oJnjcdfeY/
I3M+hCNM9VfAJ6wZBFzKXvfPlk65V6GunVZia06LMgT9qL5T+7I1DzbyYB8pgBWK1Bvjd8rjAsek
pbV7sGWrUkbYXmtiP3KQMPY0NG8RAmwRSvQc1Ogww/L5qS9DVTSpL+ZLPkXQ1XI1Fgf4MRUQFMav
xYpYVij9NUnJkN6F+CAfDKLTedOvCvNlY6P8YFJqWIa8CQl4jgndfsyQ05K7fWSC4nue/V9aYYkP
E7l3Pg6uwXmptA7HnhcXvUnBjdSQ/qb1wSH5b0PydIJMzPLD2OxqxY1Rkktjil8JgIV01Ya0bxn/
ksBfGwsDXr/QQDVuSaF78DfwmoSGayRnNzuCEePVybPJEWM+tQl/4BGL/sIQOIfTEXzTGuw0+hh/
S1/e0uzhC/A/S+rCggLHB9LeKlfIqAoUVt1ZVQfSlFg2/gJRnd2R/XNZKQL2EAgzPSrL6LY/m2tZ
ZjyqekfWoLnxS6EawCPUvqlacqyzCuWmxPP09ULAa1zMZzrU1d6EoIP9c4+97Q4bdLn7H2nM2BdB
ZlM1VueoF+hwjspy5SnFZEXVHkGWGpPtR3ePYw/F+TdBQzPYrTljD8+4+TvzFp4/ue8vQa2LZFyh
EDlcZKEpIDCqWi3RVkU4daMQ0EwoGbTR8s/puKdMQ09uDk7lbqP7GkkJ5QTctX5nSQd3ywzW0s36
Kpim3efcvb1DU96sGNPT791M0/SSlEdt3FzXEGiPMZ42FQ9tKOopf0JQbtXLxdHCw5Vr/IDWmhqC
poSZ85EQe8Rq/69CQRlne7wR0UYoP2ZrE+xXnHbqIUAnff/EjH83az1fuDvahPYFIRTRbay7eVae
uoE562VeV3xrWKf8oQ/Lma8CCdxEPL1vqL4js3W5H1ESxlGrJpVkbHdqlftb6Jt2bNWgQwe+bUmq
T0A58ZwWrAK8+6zIgUA/0QqxasvTc5BEr8Ie3EcpXSLx8RAM4UgYv/m0Q5T8JoBvwUYF0p+XGbeF
mFXlcKsJfjIwniLAV4cpmFDRkkPGuqb+j9EaK7OOzUSPfOYOyAYVwyg/zM3gQLjh+X91TmzWNx4G
VjgLzfQtY3gm+iHalTPwxpbH9DIZoWHJeJsy396xC1nAW7QYVLik2vCswyR7nPPnuV+lkNpBlyGJ
Y37aaVRKuElOY/FTfxD3AaHdOOar1Ry1YTaYHzo1kOp8ctIyJZj4DAkWdBV5Mw7sog3gSMGIuTXQ
88xksI9IoJ6NSKVrUxOFCyUvjyx7X3BoHh8aNSFkIOHFO4blwfsde4FyWfLIMqnAkPmPYOJjb/EZ
SNA3vkOOsw7OMFuvAaZwGJIx1LF/kT9p9K+3N1Q9AOFd+R8ccW9NjdO2K1BRPPT6osOLtzTAdhsp
AYNY2GtZBC8hivS5YWNW4DLlBH6o9+yEpmYDLhSnWCYlM1fg8xmC3kt2Nz6+/xNwy9fbpPKQoAlg
WCJgt2sPQt4SGxZRdNxeIx9KGlx8Kt7wQOqPrkUR2mLYkW2DuLF/iwCUCMI6rkg9d+1gv4RCbMKX
504ucciSGOi7U1ciZBO8Rzu6Nk7pnHTM21ZrMrmqfYZokLeU/KM8W9O1s4yBuCkL9HAiFJ8ZUbGp
WqLo5esaIXaJ53h6aRxPtWOaUayv2KuwyrBs/rXIZtfJ7UBSBV5IcRwNMULm3c12swfbnPYscJar
AcnCgOuj8YyWu6PJNLJIXH/tCRI8KAr6OI9xL6mjXZNQQAs/fyEPEkurJDPQpPeJ8mOo+nfcRmWN
XJ9Hq0hxkovYjzmUuI9sj/sf+iiCkj+8EqKCogRdoSl+DvFsD8NIXMCwAKlsJRFoV0BV7qTFbeHm
GmpzfoCN66TG/JbD7NAE2+0gxu1evXejXkKKciWfi8zTKgqmqu3RwuCCsQXhg0u9uWKtDJ9YZRhV
KvM2u52J+/N1lsuGu/ieGk1U1LUWJqwd1/8/AGyn97d+64zWVcbOJ2rh4r/rzCScbiJ5MH06bVhT
LEiLaojEha3i9/bqp8EfKcL6pcHOwxS9O/v+vPcqFxklmuKvdwq46pgd7pRZW4eRvQd7V3VToAdw
fyw4X9MWdAhvzcUVt5PVY5xdldrZ/hTZYVTOYkdFrRFo2TaWJooUI7BYr2kDnQ6VXgwyUd402ZlO
KqhkMff7B7MI/J7+QPIYMvq/oQdN9rtFNe+FK05maF1Kq2CI6C2PL0nSfMVu5WBzY8an6p6ULT2q
mih4yoDiIhkmwcix7zKcncoyBayPGzbcCCyt+asX4uNPh2BtTn30R05t5HV4fwQvLhVyt0Pz+LLd
S6v44J2puY1CbmDtyjvxWDUhIh5X3XFL9LV304mw5wL7TFVexXt99Pq9kSNnMinEUaafmrhjUVKb
njI+MqK5p8mMv5MOQM1sXgaEFhTQeEKhg4MljTNiVEeJaYDxsZ/unCEI45MbJ4vVKdWgbrEK9Gn/
L6Pfj+ijKmwqBFSbvHeLFgtvixgY+oZxAs0Xw/rGDAA/Pdnda2sp686wWntK75JGMebyFt7Y38db
MSZXH8t7gpD4YfdkkKRknpNM/9SMbPHrmExiW2So/KmjkDoHWhPEPrK6xyxyKY4KTQ9Qlfj3NRvM
hpN7THuKoc8lMQo7iq8WnH9hztZN0fg55GEKdj0HjbptQNB31Vu6Txih8VL7XWC8Apr6tzHga/6N
VakEib39PRqzMiiPscge3h4b0TGECwLAYOUxhfRMxmwk/By1bg3bQMTJxHm2D0XpvcvktCCgskYT
LHT5+/FMR8i2H04aIrd0uWpL+kO/bCwcdBLYdcc4ZnG0+xccnvZl3A+DhYBcW0OI3sUGMn7yc+hx
NMF45llpKpS5XdGu85pTktdMFZ90bnOXbMnj+UuWA7Vtz1BxiEOc5gHOJSlgcFe7onc0VHNi/2jQ
+eRElIt3XwhVn89JBObmTCOGBBDz4NtHOi0O9zULzUNp4GvxYEwWvOVudKwHkFs/P8BZLwiUOuCd
dwSXxTwaYku2WMMN7pHSpq66DnVV9rxuMQQMjVnKGGP69XqaczTPwrlObnfA7NsRANVdrXhqRTCD
6k9wOMrIU0IxYQ/9B0UutXh5CtG2fJf4DnBlWUP0OC9MCOOvkiXc3mf9oV8ATQWiSBkIzFG0fLzo
qSSzauUcDDklXNQIO02zyk+qRFpLeKyeGd1ZYSjotUjqGIA8HiPNK7x6QjqlI1bH+ZaZJ45Tx9Zd
k69m5J8FcTVDONL9ZzbtqgsaVQXVfbU31NLw4PrRY2njMEmI/+TlWeU0mq4o3djAHfghFT2DfT6S
uy0b9Zu1Bbxmqsf9qzd+Cleff5MMvPZ0fJRP7MW=