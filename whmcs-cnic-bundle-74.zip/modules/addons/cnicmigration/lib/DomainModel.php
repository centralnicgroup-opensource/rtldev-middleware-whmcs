<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtjVE1ls2u5SZvUjEAnYy/FLVFlXGE0k/vYustGFDjMiFwfeGXYK8LUiNxCosvMdqwczuT6f
2kuQEtrdob8xPIKc+9G8NyJ9aJhvhpdp5l4NrNvN+2nK7J8zh4UZwKvAOVtK+9ijXdVjVIdAFOi1
7sifNRoNhkARfN3Wml22yJSF9GqJ1lWIcV6xR9cok4WARwC9uIQMmnyobxHtPV9Wtj+0gVr+xfNh
HM42Je4n8h46Y+ARSB4zAq25b+rBPZv0ZXDEuWE08QczgikwJwn775gX2Uvencrr0rd3VIIBZaaT
DEWM/wOqvoQhBZd/EVPGBFkFv/VKH3uPJlVGbaHqjq0fT8LoIUVnJ4K4Z9Kx4Fn9aRIvIIsm7mY6
K8y9Km1bdwPVP6yruGHQcOXvSdrydO+naKNZETtUkOSUIMCJvJxA2FHOM6udn9K1Iod5aYogHiZY
v4uPmOfSNbRffdhaP14jhx5nHlZzQoE2R4Scy7RE5+YtJZDdreA0zt2MwGCK+CveoGDF2hUxKBgy
Xov9g3ZOxU3gXCzqCYmdt/OAiw7xOPmSlWCV228YeuMMUUsKVCJNWMENJcZhM1iqI7hQydrdq1Ss
3K9/rOmmPSI9/aGUNW3CY4KdCnnlv4AqM5D/UdVHut3/oCZ00NyTJOZxk/HziesCsd0UQrutwU6c
uC6dXs6QLswd7tVaj0dXP0xdjd1OSxcqZtyLk09KXm++ILw+1MjDRRCGjRb99Rvzs2hDcJFc4dEA
/g6RUC4wueiq+v366KitVUqA9k4oW14aXMqRYwBBEcA9a4S4PoE2ML8bhWLOMS23RBaKzeclr0e3
Re0D0v9FCNS80UY0aeVujRUrIGzoz2Lt7DLVsVoZD1cG6SpH8pCzybDfCIiNE1m/7DLiha785l2e
0o8uCMHnm+nBxTX8sUkD3A+22ziBe0GnBJXyeqt3lAa+3RQNrhGpfOE/UtmXSNYxXvZKNbxxIUiZ
Bskl7V+BnBhWlvmo8Im/x5l0DdZ2UDeUY8SZftVkgTBc88rdrCMVeDfifXkrSg0rBq5w+GUaGenh
twSgIPiSgVSB2p+mjmHfeVwBJGf3ppflkLG+bzkIDKdaaa67ST8FyT09aQJlpmxApJR2HaIUTsmf
FVBykzwC9vv0KJ6XuFjXivf4DWKnxMUiLVmfThjcAbrLYFgq86V/VJUzhheRujmOkSsK7fBlTGkR
avnIjp4G3zW50ObGzi72e/Fx5IWcg0oGjSngRCBswMeiWsyw0V0vnmQstLCSTjecjKPZkViu/8rV
dcYKD7barw/EN893ZP+OT+avaU71P3qMHNZY7veoHqCR25shjZ4GxcmAcyiFzcmUb78dht3hP4XC
VOtUxJVm9pAn/MvqgJZbQlOByIiu7UdjBqU2de7tjXYOt/gdPQIxo9ndE5aZOkflwuZhx+Pv/msy
hlxX/2B/hj2cj8hPCmiPFldkh4B0a7R6+xsx0BNBduOi2XuPefUpnFDdWZ+FyXzzJ0fKfPyG2mTH
Tr1uycuq27XcAesa5kwHcK6/Ix26Qq+1Pj+j9m1X9tJEAclpy7FPcVi+UCjU5IK96LSvvFKPiK5b
S7+7Zwol0Eu3eXr9cspfw/Rk2eaQx6ELC3y9SnhNACXCAQDw5JR2H+7F/L+6bDegenUQUU47t5wY
YmcxS1oTo34F3bipWb5RTvLsuYURUPhLaHLk70uLacis9EQRPVviljD3fIEx3XuEYxLh6wx2u2QE
fdhI4F4cZgHM0o8hsNqq+BiiyOKw2zu5mQ33C+u3v+kwya0YMuiPBfTNFl4/DnFRIb0Z0KbIl+C3
TtcNz0+6tyQ6S0ilU8zfgyaC59LyonMhCqi/L5yQjO6lfP3FJS9QfdUVjRoJXiB2RuIhewSJB6k9
9IbzKCUFhYKaYlQ7L/JM2Gp4hRb7fQ1Vns63PLfvdGt5pxWn36suf6VKTlQPJEfVPMvXGNya+auo
q1DyccRXgaKlrIF7nB48RYLTb7gcNH+pffcmM5mVOJYw4wfRaoxOMuxKDvUFCzO/iTellP5BlRLk
foHSk43OcjK4YPPQ/9FXeEnXxc4hyMcgWDHKpYAKE8V9feRMed2aJD6+/RSekZfUyXVJgSBkZVXI
eAxqW4y0iFtcyUe4ULLMYsqGfNmdo8Z3YlMIH678Xr3E6p6/q4BfWkVZdLtCIO8XZtCXyCMBJ6Tg
SwsPOz5a4zzW2K/ODg+O36kZu5x4pN7bbumWPo7XJZ80b2VfGlaRRRxav0mCEKT+XVll69l9HJUu
gUG/jxY5KQlmvIBX+NIfX1DYMX5d7CmUCxz3GUoWuvJsqtcipv1gp6oMd1kyY7qaDdFCiOI5vNdq
OJYSETbZs9E+ycOlisWJldz1/+gTJje66LD8Urq7vd59G9WRhfXliM9XiQA8x8mukfdrETbQ04d/
Ed02GvDcqjK9s5n/2/Qf+rlZRzw9l5AbCcY0qj4RUg510rU9H4UAiathAHXUyjTZt2XDCICBjo/1
Y36nl7oNhOzdOZIKc9X9T+lsb6Sj429u2RR8QtFWJN0OBJi6JfZSPJT1/Vc04LtxuQBk6hSYhxr8
62g6YyK/OHvRo/4ixpyGgCpH/JgqgaBWw83tNDWFNYn7ylZDs1W6cNlEuh/U+PRHVaX+gKwZnSUq
y1MkzRmi5qwxu0Bqe4BHhziDFGnkeuSYRIAiB17XU6WK+QkfoWhjxQ2Tm+CR/rFMtoYz1Sr06GZv
qY7NQArHMc4vVYWA8s1lb+q3XcS1N6WmG8jZpCCHW1b2335FsT5xiO8iWI4gRQ7ENRu2WFHg5Jdb
zV1dH98vgzNLZfXlyAtelCM6ItZa6wdC1u3ULoXSI/5SiiFnSaOhhIHliNg7Kgryad8Q6wN21hSt
G+SLvyZ7CI4ouZMI1Nba7OXgP+L+T745nBM0eRMdkkDdDnZ1V43ly+IMq3f0PgSmwI1u9w7J8ex9
xbA7i8RXhr3BD9ffV233tiDR2Y9cqcRyXWTKsYjj6atnIPFGGIXTWHy4EBOBt9nROoBKFqGZOmbu
00t78GYQL6H4EAIwnA//vHYhyOoKEMsERwImFVRIlN+Ucs2SDnV64jgogWNj69BsfsArtK9JvkiB
cOqzYAP/DPINYvodjJe56140whVX89IPVPEAVvsh+HgodPO7+bQwSCE23z1yWNkIzr9iGDGv0Ja/
DLF4Yx71C8vW5jZm41dkMiW4cSm9aIMuq97Va18z8gkDQFwnNI0UHO+PRrggau12/YnbcM6oOaPx
+MSvOs/CGcaWEeQP8nmRVBABYtSw1cwwa/KdkiRpavPlcnEDAYf3pSEIhtOcmZ+V6QNVdctTueJC
vALaqcTKZjxCQ+M28KvHzP7khyAGqtdXgNCNsc6WIyxfYxQD9RrstWVuUmNRa13oTJ22MnOKpQ0W
pGQYmObbGIxz+Is7Ddof+zqn4kgxo9rLLvrYpMpo463HXHDf81tSlo1qXld/5wFGAfqn9NKSQcK7
y1SXd1AujbBHr9/xNGIY50Wq3oU/W/KcxPjSTwuaHYbXOM83UO+cGvDFoYUuM8PKhI+BK9LHLGS3
Be79ZcgcmbGCgIMfIK9U7Zb/iuZoGfpcyHjmShKsiIoawtFwQK0RXbMmwRUi25xN3mfO07qn8JyA
0TEFVvKS4gMADD0iY/maxVxlPdh6qX1tz5COcfcNqakKammnJqA7iaaFNb1D8NqojjBdwbDC0Pte
u3fV+SuC32t3csZ61nO5KFABM5wjr7OkiVerFbfj77jpslCnl3lsKXj1kjAqmACbJMj95N7zrngQ
8olu8NerMa1b7w0c3z2S5guEsf+9v7b36BHpTlrSuKCoRs5Wut2rhnsDLqhkRVck/8xv3X+Fxo+B
EPjI2HyoZL0J9iXYacNaO5pNi5jIhidvDRnTCTjs