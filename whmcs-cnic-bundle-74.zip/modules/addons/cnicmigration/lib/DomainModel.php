<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsFNn9JySptR+HzHjmc+SkTeXWcSZdfcAA2uUugCNGp8MLTrvfUT04LHrPN6bJe6IgsrD5tC
Umke+PkMIEpN7rlmdZUVKYDZbf99+RpX/f8fYgQgmsQlmJjWurZ5Dlc6bgY7w4DjwVLhalVEPDhq
VghBYiomXM5boFs0/p+vx4JXE1qrwuULKZSRcTlaIXZhzqxpS6YGpK63Em13ChWEEPMF0dj1cOBZ
ZzRZgpOFdGx6PvfWDBXQo0opD9aKKoOl/nMzj8k7Bd9okl35K6IoGTan6CTjEKgcs8EAWuyzm1KZ
8MXs/9RtoPfMGKZwh1iNqnxvwXW4iCpjngzd8n/swBPvGYFfziR2+aR9rNyLEF3O9kQQdV02/OPk
N/JcBF/JvbsYCrw2+VKFtzPaGzbvpHFj9ZlizbnfPQtQ7mJACXaP0K0QTs7x9HE0uPVIlP9isqZT
jupIcU6/A/RlwDrUREOJ3BPB1ljs3V8UAV1Gp0sFKlRH+Oh1FjkIoMhrE/xpJB9dpLcAeCOpD/GY
M4tyEwgwxGnOcRTeiZrbh5ck5V12FY4Otc2YmcF5iKLxqd/BJtq9KlxxZEipinoeWsICbEAV0DYD
dqN2zJgnZ1xysfYCcyJbtNqQKMy+uqoWKXLjG9RIA08cwXOihXBNetW8Ro+1RU8VTS9ZVLfRtLIB
eRy4nFe6edxZdYS/d14veoEFHgwmDIgMPdYwuhQq44nOhmCZjTpXQVADmb1ciCaRHrH6vxhIwn9f
/94N1OE15z6P8ZVWHXHxk9Detw6xw/C6SoDG+vxmPYHHkTbvJ6DugMtuuD8MVwkyK+JMpt0uYCgV
FcoTjMU6gz13OmyV5LA0gtOzqjUenQ7+A2L6WWueWLN+KUhxdQ3RHwoYsoruemnXsCWd2emJp4/P
B7zjJjjPkzMrWlF8v91k7TbKpqcg42FJzJEX/Yozsbph6a2m+lbFjbvPc1eP3Ux6Y8FlY7DIFS4h
M0YP7GC9dXSgalZ7CZGO6lzLvgyjAoJ0oMs9sYzrfR57Mnto1KVIXwlrRvfZEn3rNgSDszHSTG00
MBPp+iVgIP8c/jg3UYQSdbhldZTA0Bb5owUmuYiQeC4x/c+BmnGZ6O0OuAyHZnBvHdiBpM4nJqMc
UlHLEOOckLE1X7duHAPOTzgTSmNhPfGSdb8Nasfphldb8t5AVT65JucBOWVnm9RpOsqziYJ+XGVp
IvixSORIZrzmpBkS9D5xUif7E+nlb8D6ymXua84KhqGqrfFnRk1HScfgaZqKwoOF5NHi9GgHWWUa
cF5e3Ki9BtkLvtM3bvQMVWInd4a+9NmLrpPu+f+sAnNdnRzXfPETTp9pOQik3nGGPSwInXTV9oXQ
1vBYX8wJEQjRW6RsPO2D4drdFcte6/OJs4siV8y7GKZpzP/ZD+ZNVVLX0fI5onZ5Qsre8LdPerKe
9HFSL8uq7ifNbZZ7cCgeCTByMtXAKwMm6HJQ965I65BMGVTjpGngjNECC9U/O0iIONnXKVDAnPQG
8cggerj4NsgA0fJT/EIsrwKXdP/WKoy6UwTkZ2xldaGTMfNq61aQv5/Mwe2GmZWeBgoc80weDcPX
N+vwBpgfXx+Pfn8KrIhRBN/lMF7F/BxpHeZtkymf9WgIGG04Lu6fhO2a6odu9AkiyDw1ErjtyKVp
e+8nKCb5BojJZ4BHWkVkCABbY2c4vEbiDC4mdm0mADJ5UEw4n1IkVUqugvPpVTQ7MkkHIKJIr3Nd
O7QeX3hgd+K/zZ0YhaDZkURzSSR5W9KipirlM2bSANGeGqSsN8zSXGU3Rx9hhI37Pq27Hoq4tzEP
DfdPQ4V6JoXsdfRr7X9pJJd5IVnQp+fJeJu8KpBx4pUJnCbbdHtucHqEy25KiTeva0BAMz0mSDTn
ujG1RaF8Md5rBgLP0OwDliF4rA2FfA8co5aS8uk1DVCbwYJWxK9f2pd3vT+DdvH1a5koHOPrp+Hk
vbq2cpbbffamKui0DSMpQ4D9aeJ3G/uHo44Y40FfzOFwo3dI3RyfHLO1M6NBmxkyIGPNEHNDbGDh
Ywqi6/yWsTdrQ9utArpHOx82nDRj82TV5se8fzgxNgJjwMiMKBxuHtuOTlBzfRglLTuVGp39xMIa
yZ4Yd5b1ZHyjIQAbi4/7WmM1BVTYDWNveqDTdTbmo/mKRFzXA6ssWNHZLX0+tNuVJlHP2Nio7kW3
OFSGRDxG/j5h4ZZ71F/+EiM4RzeRFOYghtKTXSIvwY3vyV+0UggftHSTD6x0Exq5qjufMNQQcA1J
krUIzkViHnhx1sih0sS1QFGK2z7BOnAJHA/xy+tvZtaQNxT/TL6PRn+7zaO/KUpAZy/yVbqfE4iE
YWn1/sPe7BqWBfbvREl38OBLAqCx8qND1XKICZ/oh4X9/pxlwGuMK7WPocDF6w3ikJzbYRVEtChj
U9gJ1eVh1bEvpZ/LziWgprWBQX14Csd1LSL1yTaGzLPWrOvaK96H/oaupwkGiit39if5sQwLxBRR
ZVM4Wx0/dslDzF+JcX2ZktQVBS7dO/YozM4oeTo70E93xrJuzJPrEbwPVf+H9lQn2pdMyO4noJbZ
yFBaPs9yIRQ+guW0JZg67jX7ObkV+/Ge/oIr3cNm5ShO51i9H3ieE6PB5iS/8RYPmx90e3lBmtj9
W6pGMQKMBZRlPTJU5briEHBEDVmVMeLml8bVFf3uj2udoWGcCqCR9M+glw3eKCBfXP5SvWxMOeI2
009/xX1hpBfRvC1qDqujDXarGneNSU5slj6LoXl0IaP/2P8zMIlQFQB83nyQ3pS5/RcEuCFz3rz9
nWWBSQnJtCiCRMWTAIraG1CKLYswiSJr6skTRycQU5wFkFfoRpPFla2sTfzELfLTwXqucnCVu0oG
5I2JQdede4kXRjTQPDUtLfnYQFICyyIy3n4eW5eRRvjruioSEqY00r/Xgogr6cU9tddPr90PVDCp
bW5x9+4o6tfAOXwWnxrUcQ7ohiS+a/3L32khNCOpv6aRxWby+fbhZYVBl+SxrQiT8juk5e9kchBt
+J493C5b5Se4NxuVqcqUSLHf50VoftmjujwvngKICMOlahyNLnCoLvgiNLdoiI5xa/Qu8+8ugFiO
bySIwrfRhv9aucAGaaLa8vy2Cfto+8JtOX5oCnTwa7Fb+HY3rSUrsxf/hNsC+0etqEfsW0PgrzTJ
DJJlaURaxmQ81V4a/uW6V3UNnwMUsbgRLGcssm8o7A89qowtJS9n0wniN0lTV9449J2j/ivWNVwn
oHUm5OIya0Czv0U5uYBzFmLhCvI8mwfp0qqUv4oGTlSZQm3vHQFYqF8V+MlCDQehdpIsLGNuLDM5
Kbr4EYm0iG1RT1yFg5fAdV2QYywtVe7+GC4+Ws/cDMN27PUolxDWGONxhbVgJLXJ0873oIvNBzX1
b3tTwSaGMeT003r/4B0W15zthWQP1rR4/4k/rC6Vvphk99EeKCUh0gtE6TLmC3OnpRd/sYJM535S
ICbA6rbuuzqk+yeVLuA7pCT86gdR9OQNubImlw5TjKrjwqzbnym4dX+z1vT8L/kRjv57gVueeDh1
ldoarXVYrBNoV9pbPeg7OniRCMHQ9dvGaVJF0Cl+YbWwZq1OBZAZnnCrz7Rl/zVVTUAAumhnKRsz
DQ/tUhUhSpwagpSecuRYekFUVPGzmPxxUb8atVA7IxVh7CyHVVhrlJiUQoGpsqAJQFChoXkucqvK
mLjN4sAXE7flwd7oqnTAJRPKjoFxH4xHQG8Yd8oszrWtvDjIsCh/0bzYJnXu8FdSuUxEVH+b4vin
XkCcDMDivbxAy/Eoi3qP3NuWgXHrGUTSoMTEdN9LMia9fRvmQETHChZzdLL8dTSkvTLoiU0lMCaZ
sOHMnmse3E4m4ZAMMgRvOdFEu8kkx1dG3REdCigUwp/CD6qjlBB23/jdYOJT3ybUYST6eAnFMWi=