<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrOSFyWmoOFlpTMgwnWgeqxykz1wM1M6WgguxnP7PDstU0QDlemS2bGGH+OJ0b4H/9q1KiO4
uQr68WUrwMmwx0BIOFbZQQX0Lj7DVAOI9AZPxusUcbxeBwXn+t1moJ7kA30ROM9fit5BkywfGXbx
mdhipYPRxS4gsZ7PLfl42JJklDC21TSJaild7rV080cOLCgzcE3HU3dO6eI7v+S/UMwZd7qRT3+G
1Dk7TczGJL+RExEDauG33jOSluf6DYcIoUP+uWE08QczgikwJwn775gX2VbcfSjJYjts7/HCLKbj
cWW23VbTuCI9Pm0qMahXwjI2s7Xnc5V8vnC1vykORNaYigLfvdAH/noFxH/xBKQxkyo7ZFrC5hbx
uZ8tBSYRJUEkHJrSpAPVGtbXW1c6Gkw0Zy/T8OLp3uIX3Nx4l035KtwVacwXLswnVix4h1M9po5s
uRpJ5oog5e861xl4zE3o9XytvcYOoa9/s9+hTMYQMGN2K/NgQIndJTIjlrrco/hXtU2XqJc+7zKb
yeRoax/VvgtdQ9Q6OZs3YHMCOZxXaQegtCGvnfEfWN7Amvf6jAYGyKAPm9jqp2L1bM6BGPT/DXqw
LOi6vZ6uVgm09HrMKXNQGPDmjyfmOvlyCz39NzoBDFtfWsW0/1DNtMmpnpGSU8IUEIabpU85rDhI
dGnNcvXxdDeYWWg7vSGmtMuVPQfHFsft9c50HX+8X3LtbH42+tH05qpCJ8Eqdm4M4tdFa0m+L6ap
hGltyDn8FvM+WW+ranT4fv3m36x16ILZeWzOnr5oNwiMr1E5kBXviyazTTBW1pOlsPEYGG6jeFtZ
d+gMKFJ3lwg/NBBwFLUFcHWmzK+VJGqZeiF9l48ZrlroAh+JHVEflUtijua+BVx7cWbgTwWOZlm2
COleVfG3ffKPvvUZNZEzpxe1WQw9KX5TfepJigR2HCOQbmzfM9WPPTaNEMD8DFzVoL6SA/dHtJwj
jw4hjyypciF9tzfV4Rcf6jXF5wSqHgET8sEriB8JXL72VdSv1M3SIt0QpHNTIJgVA9FcAKs3LyB6
dIsIQx8LBBmznl0gs87DlI/z4XyO0FGYXTvSgmCet8s+Ye2CcGgmcSVBIrP1gVlX/1fH+9NskH83
6CtneP1Miqx0dgu+pf/CZo/cXSBtunkWv1tb1SJp0xx9HPfE8gWknBgqsQ88AnEntxYZVPNh85ah
9/h0cwJPzraTvVH9IeFb7YOHWNOscT3h7pDxGv5PRqL7s9zkC+3WUvDXkw8E5AunfcCVbeAY/PyW
g+lqv7x8aZ23NbDRqdn6JYgdFw0+pT++O91yIcFElxMai/f4KKZ+n9CJa0qS/v5vjAqNytzTOGcY
r4iaMRRuP2KLOU/w28zxokLvW5FMuoyAVq13wXYqEIApOUXjo5br6mNSnz+KKXdoqdAHoS64oJ1T
Nv1POKre0D+zDOmcCPAmIYjQD4UdgN2Sq3WE3cX8op/quJR+jb2oJpUD0sWSCUUamk/3CqIn8ulM
GHXI+YptcOsiMRm9pxp9pQGazV+PhwQZZUfTYcJ301fFg4KMOM5lEmJu6MSOvlTJsYURqaEXo6kj
kM4GyhS/j4GOYgzFPBExg8BLZhS3KcAzNagrk8/JK3aCrjU+vHqmu2FfMj0IYYMNpjHSoDzHfWKF
ZTGkwC69TpCGo1O1T7JS6peosbQIttv2wEnFK/wHOAfRnIKRkK1rmzbLfruLedk3k9MP5pkZsyXs
3m6L5qmL20YgnhIQCMVChngAQjdwUVKFr05uGhgz41uon54sGyZGy17zchHisWLky2sSimCWGz3e
ZGkISc1QVNUYNh9BsiVcrEI8uGJYT190HywTvsl6DoDxy+5GvJyJsucpQBK0tvdOSXE2Acp6GdOa
ZsFDaJqETRNfTE/aRFFzJs0LQ4J9Vw9y2qKL+rPww1pKJM86SRdMUoZSDwKqt3c62X+S3Ue2hfzY
7FxQTkEEzY0KKUN0HwlTFJ0TGf+pKpFOBrMN9G8Vpd9XUJxWnyZaQRFjnsgKtnmxNag2cr8YJ/1A
XZZxxuqfJ94R/r4NaY+Q7YnDzPn8+vvICpDRDrsEDOGMGe5tVqgdRxpL+3IIiywIM4jZpuXx8+kI
P5o3Lk0xQQIDqfuMPuPB5uV9La8h4lVy3oAZ8YoEFvuvdMiWKhxzBl+UGOQ6PhU6CV11TLPiULtA
gq4tx9aLBxQvc1zN9f7f4q+e0VNmMBe/jkPv0796ce1gOKLrogdEd2MH1zdBdVP2LhFPh1lUmolJ
fTE/aV1EJpvAqStqD9illzhXfN9EZr4kdqOGtrUY5Iw4veU5VnxcV92X9QVuTKeSB1PKv/XGFGeV
ajE+HsPPKCpJSowVg2eEPA+wSTTMvkAGkqYgpX8BQHNvvUkibrhxjFqYnCQ/guQ1ozEZ4VXYjB7A
SBPWjoPp8dgGYnm3Q8OpjBg4AOhcLWPi7+cgBzOEMNR/HuKGeHS9jepqzmKp+jfA+OSde+FcKnVr
U6HzhS1ouqupGN41w+qZGXfjU8B+juli0fMadYSUrdY48u4Ikc1RPue4CViZE4lJrbtaW/2I0Xbj
HwXsmT1ciJMPziupkXksu4/UGTcuhjWWqXopdnoUkClhm/yUWyiIDyXopZsSoyxceVnu0JR1nWBu
1JLCMC/5w+yHLe9XEv6YDtVuEvv9WuIDSt6K2zlG8M3G90VpCy08K8SVUFNH1wuUxIweoY71xSR+
dKVk4Yt/aasojpedXu6tALAdx3IsHoWstM1wigdH8HpAzXlI6/aXpA/vMRSvpaPPQR2SgH39USKH
+zpJ8hr0jOO6KXNRz9fI9qZBLW65IpJPVzeUECiIJcVNWo048W4HkfRYeDcRoaqj+RE6idhodg/U
ekvJoXNh4iS5Onf6ly1gP/GjQz+KIKkV/3km0IPniFg5v1Dyim+YYrPPoHsrFon+DPxlfbPIBC+s
IoKGe28ZQoJF3LzSU4NX6X4snE4dTJxAeXxCJVYoT+R1foWcuVPH2xNzdKaT3jO91HtJDkDSiw0G
ii1d1UuL0177rILQdzGuzDHHhwROIaFZW+V4bWXLIVHPBY6v54fUQXsWTuuPi85ot61ngayb4ulN
VS3tCDhOk0lMx0gEwnjtDiknshrSp0hSV5sCrUGoaWAiKqR+soMTMbd5swxKooT/L88tPZOuiRGh
UCNx0hPdDMUlB51y81eIwAhvmmAbndY8UJ5K4Uyxu7NyHsG5dDVnytH7mL88b3OB4jMD+G4Xt1jj
X6EFZMUoluV1XGuYyeZ5gf32VWUR1rmeyQonpRtaLWaz7ho17uo/RLQkbXwq2piZrRSIOei6zVL0
U4Ay70gu7foANZk8Bawx78fXmmT3GbejRccwIRY0ShKh7Ge6nXu1w8a0mbOLDXagDBh00bZYEFsw
YncIvi4NyqMNnkPnh2G1zsj+FPJrnbL2AC+7VshKIB3sCf1SU5PvzK01zmM6rh/0xyVZ8znj0mMk
phtkRx/Ks9wzLk+rwpK/su8xT2KqcMQB5OU2WuXbCWN8+krWOmDi6V5O6QJsYi+WjWSl+OzQEkEe
C0DDqfUadf39V4+kYH67yQIzc3zqVFqG1d1JvO4XYzDZ5eymWuEEwEO9J+AwbMqV5ayH8UaIurM3
ntrfjvw/j9nYfe+qij6wwQ0bBLpa6oBSqF6N9X27ySWFNBTSxOIuJYIEVjU4EOreUA5BcD0YQ+uK
MRA00D/0XH4dos2rjjMBedwAEbSNKvCb1y8dwEeiCvQyd8yvf3CaYnxZR81DGHxRM8sHTJRzPMm1
ICAOZ1rTo51vBEymKcahJotTjjCZNm2+/jURXdlJVF0flC6wuxuHFPW+fT2l4ApZebkLn3R8vsJr
BsGbHRVPBhO8iTbIRaHsw0qOout/oadepTxGfc4Ir0nlN4OfleJqmteHqI5z533XOhwyKRU8mHN2
qdrAe5Al1aOjmrECe1VQlzLquhQmqyQqZD8uHjVa54NXKYd7CBjovykn+OBDV2BuC48waD8gbI0Z
JodYfxXfIF7HfhAoHM6HdEVjaqXjnYGosNRtbzSTHF5SClZv4xnHcS3eaxMC4+TYvkRHc4IhYb4T
4wj+7W56B97KH240tdedS9CJ26wHRwLWVsag6f1LTxUY7r80CymF7XNnPsi8fJ1rzvdj6o0wYhPt
JvQh0Sc/OaHEA1qA63xewuccMazBJJdhaIhTqdRyl79o6rvk08ulJfLJVrS+yrfGJP2Ssq1uK7l4
i6Jwz2t10vGSNqpgfTMO7V6CMgd6GUklkS/C5W==