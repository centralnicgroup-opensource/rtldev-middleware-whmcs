<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+YzO5b2BbcV6tJrUYns/8hw6umo1g/6M9wu4CpSAprM3r6kI0i9C/TDJ5P22xsAfDfc6fYE
mj7o3dD6IaFKE4RcDiickgaHKEZdVdIHteZsmymVoGRMPJaffGN2kAksNpLJ7PUkra8oHygeYX5e
rHfhR/NiypK+eS733RUoqUqmeH/IhZvswgurvAbL98y6kSFzzhftDhWB8RffPqawt77JXSGstqge
U2VHRhpwgXrV9+dXkbjIGqe03ej2t7z/+PFpj8k7Bd9okl35K6IoGTan655fbrzgMz2R7n78XnN3
12Wthlosuy0Rp4cPNLP24Mgjfr6/D20DFxOgsdwVwWeukx51wvERpSNmkKsb6ecgQK+tBl62qWLP
I4zvA2rpu5eEKe6NkPITg8MvdCVrP6gZcSpT/qftyQ0/FbQzfztIdUc5eOKwFuFyLiI6qEv1LdpK
xE4+sj66ts50YZQxCb/MdUEQYcfcg3Vtb/a0WNKoBQcGAdmXd3yU8ke9hJDTePdO3J0cqYvGQNzH
EsA+w0RpH9Tz742EraZckpAo50no88f+2bV/u9JmGihrRQ+iDChtfQdn/LJ8UlCzzeqBI8elIJOK
Cs6KS8Ufop/kDPMGZc6vKso8d34v3pWUS/Q7LU8k1kcywwyZ5N8JgvWCuQengXphu9m3GZRvtBds
i9BMHEib28wED+S/1Di4fSaTNr4UiUBbdqh8fDClAYdPGdYVsZZN21+EeFXa4oSs34wRu7uKN8yK
6MolAa66Ua+hoi4XyCqbK3gd2EGDMB1F8oKgqZBWsaIaCL+aqmn2DlRJHNs51OzKu/Eo/geN3ub3
4JlQW/UiI0I9o0kJIJA47TURBbFcb7Al2h8SRw8alfAMPKrJP8DaoCuc3TRcSOg8sdqjtB0sJNgb
TjsPerToe0+SZ/A5cBCNtzHAzVAQB4vN90PCmn7qbwbJWfzOLTPZ+NA1an0YW3x/ARpdYNKPJLw8
M0Rx8aXvNyr3K5vKS//p12APOb9DSaB0f1g5aqOSi5UEfTrIqIN9oxxDG9/Ilk4OngCxIEXatNqX
+ykyu009XO/Fot+RR2+sCGHvRbY9MiHi7ho5I5sCCj/TDpHpuPNJCXydCqGon8HKd21Ne/iPsk6B
6hCzmVA67RDLiugwN+ixciSGeOAjkGTn7Z5bW3Q8jgubBOeQxefEOgYjqvqf8VoAlUzOZ5RqD4LK
GuZXtMjltlEjGOynLfKFb90sEMQef1Nn65KWz0Bv8Wi9x6HGaKN9CmSksWdsp9ccYTi/9ZR0+RUl
cMB0JpT3PtbS4bYF7Ony3PRayTal1839bUVOjmBqs38F5y+DNh24wUSl5rvkBkvV317uFP2Pr507
KQZ5LnQqm/5AZoihsdmS78+WSUH4GDxCUbUTVgnxadRXwb9hVfAh8USH26tuT2fTUjX+bMxMRqwZ
LJbO7j1PFGjYvb8NO70z2Ttg3/nHX4PLKleP8cL70pdM6q6FFPqrqSjhwCnUtZv5SlNrHQZczhN7
Z97z72LHH57RuMYeOoj9NYboY5UR0/94nQ6T5lpry1fjKVbjPz5NA3zY9pEpstksncrfRx38/Liq
jes4cWoZxUlDt303Pf8gt+YkNZwbQ9Z1H2UMj7M1nb++UrLjowFxVPUBKhsbVmuqUGwh+cymYSQK
NHtAYna939geZ4TsX+LuQmvcs1G1+9HdCY8NoE+16csv3bSt22ES/44CeDd99SUOyqxinOZjHIrB
0xzZaXC+1BC6ZbUUO3G1zvJ97BdYm0dpR0sWe89oJOAeKi8Dm/E8vZY7BWu0nJI37lgaEukQIGji
oERjaEVG1HxBLWqW8cAgVPIt1685pyg1XscVb2gGcm3d5FZcayjRJIu8jVbEpTNteQFmhnEGCs83
9mmvEZbNzf65k8itikIwcSIL/eOEw6U9gfKXT/9kezLn2quI5f5LWK3M6JPExuPkbwL69Mjt8a05
/OLxBGbYxDrH0dPdEAkiJraH0xFOLcZpybuLcLLWut7esfpFJXdHX/nssJCbhFcwpf6ZipMlHp4W
rV4WfRu+CIXCGTxw7lOjudNcy9lQ8PPpluYUs+SdZkyRYy+d5pZyAQ56hzK4AyXaaSeurgBhr/ZM
nvh2UQ+6ipd9DbZb+rESoyVGusp0s0Wm9zE9oNTfWrHmlcVfQVrW7s4Bf7pDutjbta6XQFGKO65J
CZ4Y2UdsT3BvMn+Bek1iR6wjxPcUgHM5rlqDUWD+vdAWOGsDQMhpIqWK16k2c+Dr4FXocDPZxwNN
kJPpi6mIwgSmDLQJDFj02wPEKzf4bWiWEsWMwxoAZaQdLWF4n5hGnQMp7Zk6cJ5JypCOcTjrguWZ
ym+VTfN4fsM6zy0ugT1gAvyabpQ38RxPnq09fZ95andfu7Rzzkafjo/K1Liw2gZU3/hztZ5+eJKh
3rnaCO50dbNusQUgTXJJztc2In2Rqdy5NfsaboKLTthxdDMFMNPWHj8CdrOaxiSWww91IAJtmX+K
/x0gjIk7YaTrqPc/MGPiDmuR9aGbQt7DcVtvlfAqdl1Z3xP4DXmLAAL+W/ivDX4wn+ZZjlyqlu6u
rOfG3ABVc/7W73LCtwHS3m843UXd9ccuDsEaa0XdJ0x7m8Fq+kTSqy839O4jEgOKB9pUOecFL4VJ
pmUQNCO/2Y1hhTI7JdtxGhuHpNb5kbQSsIMWWv2a08W9WvJZdWD6t/qCAZ7EHFS7cSNN4UbXldIF
gXK4GLwf3ONY4iGGpaV/1ZDYkh55vjbYqLYo3btZMpYRx4V8eNDpCw98VpK54oSQsKvktWG/oiAw
Rht900dE128E0j0+PVlfwQ3JYVJ8AXGuzeN6/iL66ns/jaqH348K///KNQ4cnpwb2Zz0+g2nzXrI
Ra+UO6rIzOKpUAfjQ4vaNfLv8N0ofiHOI2uEekghSVBWNxd0PIwjHF9etToxCiGGYF9bAnEY0VIj
MpabLUhLsXpYGro5Cmr6D7/qWlfNo1K2t0wHHABY4jT1ElrDXvF5kehGsZ4EbXAG6U0BQW7eBNv9
zS/Oyf2gf5gZADWbuUsXwpN6rZEIhKTIfTGmckJ5kek//8hAJnrXRIhv0l/In210g7Z9MDlBBQGv
pBk1bzCndTVAZmchZ71FXVtwbun7G3rVCPXOHAtzHcMwir64ZyCtJxcaLFLpVIS2asGcsOqW1pSj
M4UvOe7z+Os3dJT8yuJ/Dtrt2ENJLWEmY07INDhbU1FcKqj9I9kYi15+WDB5fFP01dKV7+LypELQ
X163wCGeDKbAcjd/3zlewjLtaMMiskcTfs7D0P4YXg7RqCKmS/5DAZqT86FtXw0RuAvkqyXhTAKf
wNamMa+QpkhjX5zgPkuCI+rhzUSHfa3vcnN179rWPwoQ2axRo61bSd0HztbCffBLFwDVeZHuVeo1
8nRszhIDOkPyZyU2Hgep/I0jD9Ja0ciVusJQBm0JTN7/+6lfub3JNbdUa/QSSW8TVXylf89tcm5w
l177e8MRIQZqHyCYKV9YGXwCTYR200djdJaW6M4nNB+l4CPgtjJd207uBkdeRv2QHohHZz5Oggby
K3eO8grtO1XoE7uU3drvAHLfMdqSAsYEgKfkJ0mkMLTl3j1AOy3Q7QB7vnBRgGJSLgp9EzIzoZ85
7rIOET+LgcQltAwFpyNYpo24mdxzjDJ1imlDK01j0eMYUu0AeOsb3P+203VyniVkUVN9gzFdkJX4
MZU6GP+X5dyvlR1uxLa/UHCKLXDWpVid9IycTJ0UQiONdg8rkAvbfcYJN2C1WMd/903Eio+LE6dY
bQFxIRyNkHJC8dXDymWd1W/Sfb/3H7euIEZmdl4/QUPK7Jq/RpRQ7/O121VHC8QUPPCw8WSvoiZa
hdIjssb1ZVaI/TOsgRGkK7BS9kyEtrm0Yw4x4iRhj2UNItKe2GkCNM+mbuXprocA20B+bzpWnsc/
dz8vkQmcSUQ1W69yFQGEakh6oRvm7e+s9Shmn9p2aL5vfSdal6mKFwebZF3FJrjXqX6ue9OzujiT
8tQbq63mJK+AlSoiN5FwD3ZSiQlnWw7ftx3YRlv1cx3tz29aq/5Cf6TWZTURSsg1A8AVXMAdWgnB
v6WjOO+lhjcNN4mE9LaBhRzJR5tjhyg6X7ElV0MpbTViYxuHtQeaks0EDEi8NgOJHVX7s+HkJ5Wr
U2P0E4mUQD9kQJHKPMtZIVIX0LGnzRBXwUJTgwdF3RwlP9FcTE4KZIyIRMO3KqYgbD+6xgI8OQ2l
sRi8G0==