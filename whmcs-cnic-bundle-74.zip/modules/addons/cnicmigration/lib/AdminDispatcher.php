<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn/t4bfFMEUT5aQ7UN7HKTBlmEc6FpbS+vAuxxrhonfr++iu31kjAMeuFz5++jyD5u7uOx61
ZOAEIQjjlnlQgXNJyhufzhfaIx49hAQImKvcFjA0oJ3W37xo4BCkz1HJa0nrssOOs+KeoBc1aFSV
KA2uj6g3Sfudof/MomnPliH5JWnXQOHPGBF7uC9NmOeRVIcYYEOh3ckVtpvi6CXKcq4hyJk5jYpm
6ubtJzjJOo5Bzdz9wtj+d2evqJV7m24Qd86PuWE08QczgikwJwn775gX2KnfnsuG6W6HTji9wKcD
DYSXZP+ThNKgsa3RK8k1/6SVaz8WPOoTzMzCLTQKx6NJIfmh7yE6CJkDnHPbL1aQBQHM2yYdA4aW
YaSXnVU77a7gciLdJXZfyifMXXxsNNJBqmfVqceLL4nAUv/Hqt7M76jhdxjfY6zfxsJZgD/wOfuU
oASKCb0xWbhnLaZ1OBjWlYexQs6gxu0kJVrh9FmGrO6FLN6KoM4V1mNAHY/dOvpc19rcFWBgZWCi
o7v8zdAYaJH0EV24zBpSy9Qh/tcOd4oY5TlYnJNqpWfljyvZgoM6L7DvqftMiwL+R5rrRlTQ0O+r
TxMxeBPjMoDdTb2hIHTBwr40mWC+8WHIQwZXUSQGakzN67n+U3azl7ROXIA838yO5f5+BHuGjYAx
FGRne4wamx3xXcd9TjVpZ1tSsT5UldESVJ+C87x6jfArX/vyhHtHpSgIKfgTEjxAhDSRbui11zjn
DQ+hqWWlDhkaa5d5O9MLlQ2FBqnfnf8TtD1u01LcCEoEUkOnEpu+8GNkKPsZdS35d0jT7UAySP80
wesGEeT6vd3QDncHedGkUHggUFKksXE5dS4wJSiYaTxjjdT1Bh08eikUbcu3ahe43E4ICsVAphA7
Ia9rHy24ehPidolZaS9AV4kBLPX/IGQWJKEIZIe0hnMrTUamIXRhKADtB38GrfYuceLU50gycGBm
WyJiIvMhUcLlKcWau1dTL/+giPDRHuSSfl/Ihd4FDaXHGjjHKqlwKtCHxGkDb0dzG9aqpypB0IKS
Ne+ku+TtM6PwIZw7Du295M7FHvOAdz38f0eN+gBKeUZi+U5eLqxU6FqevsXpN+ZtRXMVoXa9tiEm
cyrEV0Zf1g8CFUPeg5OA7d06dvZl4/D83Q+AEACrYgMQ0QrSjKF6Rk9An+/NyYUtMC8jhei0JKn2
5GGz+wfnuzfFJOG1jp8WH5UWvaBUUKs+XvLe8n6xS/xNbS3L0VywnVaoZzOQhPU59eQiXSI8ysCt
bbeFCj5sCQupNkpRMPrYKe4LZDbmK738Y8GliTEOn0fZ95LMZJ32lsbhTUOSCj7EDOqameIwlZ9K
6eTeLYVpXh3O6d29sUNA13Y2uyIc/gxcs+Tc+nCVX5cBPV6P5pgtd6Cdp1IPWa+jLJsqMfgVmOnF
zHD52zS7+Lo1tFtg6zqiO37UxPPuSTSas43N8ab06tS1YIPMWxNwI9tcrMoX8jbg46NxD92jFePZ
R/FSqK467PwE9+/UuPTmfjOICYrpBSya4GBJFJs/6KzDpr6eY4SubHp/UtKCZ3v0XJfr0kNqGWXF
cIyqpjEwu+a8YcnhoqK4h3Xmfg3Iyj06L0Sb+bREkWGF2aj3XY9gr+kUq8fEiucKMEmDVBDvqzt8
qQHXpb86bt/ZjZ4NqHPkf3i42WacFQg5xGLHJw2pBZdiUA6VkPHghMPmnOerURUKo8GEbbBocMSq
zkIyFnGdjW==