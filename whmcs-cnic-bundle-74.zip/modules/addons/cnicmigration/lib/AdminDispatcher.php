<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwTaS5BHoKXchDNbSRBHoYQFYiCLb+NqqRux9Q8Tp3gUnEGMjIGxvNaIEB4xi63b/zZMi9TV
0kWuKVVskN1rqlcjoDM6HZVT5oKxUoSSOjxF/aOrHbtN0U69Uww/WxHlYfATF/imSPcjjrudDQgh
yRyhiQJFN0lRXz68qIzzeN/51TiUYQgas2Sa4BZ2yRlqNf9tulVWo9sSmCUJngbgNbzpKdV4G93y
QbH2Q0lKvEDth99jJ+3jCjW+HXLAdmn0ttvpbG3/j8k7Bd9okl35K6IoGTan66vpVVzbbPweSCXC
D1K3h4WN/vKHfnTJWdTkPhYaHrjMVW8enCa+K/wdw3EuZ9u8GF/U/QuYwFDsVE7/LN1aJbEs5p+z
1ZtJdeFiOgr4te7YsYR8bol2usOPzdaWmhBvaar1vTb851hECeKe3SrSS2dnIIVoKjv9wDvifwn5
KHqxoIppL+UyRd73pSUTozp5zZzFGeIxQvhuNROdlXIca81nMicpjN2wbRb1OKGhbD33P9jtMBU+
wM7Sq0/EiVF1sLAYnvlTSlEZh5cEidubVRj7jXFf6evvVRolIUCGa5Wn46WwDlJVYVs4wjZD4SOr
W7joD3Mi9rWtIE8NLqoEoqUQkc0Qq74VmuY30BirWe/bh37/CjDLPub4twJ0uhIKXdDJgD8J7Ajc
v1Wv0v9JbbB/1y3+HndmLTLTQEJPK2TSMq7UmyLDWrHHVDH560wUUKlB/4BZ2lWdOJMEgKsb9q60
Ex5AavPLHgXvAawuTvT8VrYSxcpA5YQ//eMoXHZQX6W2Ip1RM6TJr2cNAFeCXD8KHOyS9Hc+D6IX
KhITgkTnpiLs/U/dXkPkBUo6chASeD4APioCuDbu1ylvFkLBFRuaWXZNVgXEuKIzB5JjjbGeTkBr
OWGSEEXbDATqz18Q79iMvSVAiB9GSgcYNc8YlD1yLHgV2WR92rvyQuUgLIiL+YJRyhcVwlb3KoXq
y1FXzxi31V+fBHf9fc5kkdIObs+0vEVYi1w7Kmfj6AVj2TIUFrIUk4eCLZ+QbJTrnmlrwgpHklMo
Aq6ZmeGbiC/AMXMaGyLlWitLdJG7tHKsdngqYJKq+zFX8xitb60dLeKut/z+KadbZGB3BmxkohNE
mZxxYfEbW6Cazgj6lyW1VAwlPP4Fsdl1CgJ+ubAqccMdwihkNjzcvH2gHAvvLlcduP3cyaCLT0w0
imhMODEZmUcJ+FEj1y5I/wxC1FeUrVB14M9/Dlnmc3YFr6YieO2B7PVQfPQR7UbmdNStFofR2SIk
gBRSsIDUic0Gy7kGihQ9bXu9c868xlBNYC53XU9DUEb2kK5/CoZrivXzrd2o/JjWzREWRzMNxVdK
qySVA5zmIJDe7CLUgv3TyXUeVI+ZdKc0QfVPTRIcI9yDQ2Tiut6ZdFx2l6d1tt0qJOMgjIxjwrM0
oS3mj3c7g/GTBIaG8Ppuy0w8t4sZ0SKDKls0RS3iV+b+6CuVNGuxzsKqVlK63TTlc31d+cbqcfbH
HyYlzTu5RMF2hs0klqT//YCA/yxAKST5wJQsPLnPpCZ1aG0VMTbQeY2iXXLOElLdi9HL7OytVdUh
ZjMi6ZBhvxI2aWxzvfmGuisDcQRCuC5KLQ+lBVc2trgdXEuX3JNfQzcs9Or8VLBP42+rxyKGdYIF
0bKGqO9lY2DyCAGaiX8gnxOU1HNdMR+dOrM4+sMWQp8IlGKHbkgWdD/lW3yeWkDEq6WK8maS21E6
ltOiBGa=