<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPm2E1vNpKVpQYZsIji0W4H/sqAxyJliT3QouEsvRSn0Gb5iNTN+krHngsIhj32rpda2bWRCK
mSDn+1Tnwf02oz/B2rAYMMLOLb+EdJbuAG9Fy5zbnZxzt108243JxGa7rl8rvgJKkmXlm87cabge
8zzlQeuDQpDmeoj7qGhoMpXAOiUifxm87YeG5OweyWINqHfrET26qEMXrOs0LLqzyrJXaszGFyCU
PnCdK75z3hHLWuCEb92JPeuwsE21JJx9k9Fsj8k7Bd9okl35K6IoGTan67jaWZ5dXC3yHPjJT1LZ
yUP956aO8QrwTuYhAhHgUJgJmCpDJeFrYGLhMK00uzMHsy3QtsyPJQ6mMedTDm6LfgK9CiwnsR0F
KK4MSCrq33k6o+rjbAuKk3JhNHo0w6JLAqRpm2SVK2SigiYgHfxSxnj49knZnS3bGRrmrU7Wdi6j
gNIlYtvLaF6FKXtw9pEP8/laGUBCIO0T2gL0E3iq0ek5edh/pZ22eyYOs/WZfaFSqBQ8prV7LH4f
bCY4BoQRj4Y4Vk9BLX75saRKXNyhyZUawWCBF+LqDK/nxflcLL4B1GzWWWuO6HvBjf6Eu2D2zSCT
VqMH4K7UV3/T3Pl1gl6vv5uYLOkCVFbQLuiK/vqRip+Xpac8c5CQty5FzLZOKRGRRsyzcYzgp3Fo
x2kVU0O4xCwJprpapV0qciuB9iIEAsWMIsihGS9KfZS+h9tG0gu/LfQ7CQFylBEtz+kt19+vb72L
2DWMb+fW1m31fI72LhVLOBx3EouFFs7Gwgo+7hPI1WVfsaXeKQR1sDCuWxhsSXNA3k0q7fiu5ws0
Vi51QkxuIZ62nF8VbkCEzBBNJ7PNVTB5noTYCWRdHryewmXZrYGEN7WuHhZWDooAsouphKeOMdiz
8iX84BlA4WOORiPI75ETb9Hfx60xQZv3GCJKgG24ton3G2WlXyOFYpYASlJ9/cvJ8PZG1hRuUnSR
AomxMfgmgi92R70dGsyhbJdioaZAey7sqrtDKo/rsV6xc3MBe8zj/LUc53/eUVQHsZITeM5hso9D
14obTD6gZOoZX5SoD9V1+r/I5OmncLj9LC6FPePoDQb1cLEFgvmCf73Cv7Fh+JVT5dls1kJr5dDa
64cFH0sDZKBLHU63lqLKaOTvE1B3APVG0vnZSKgsyPOUdQLBoN2V0CRN3sSYWLezm0L2FxCj6ZOH
boJgMyHDoqcBUejEYgV8LRwNyWhyh5h5YHau/RKgq/x5Runk4oP4ueQ3XNndEieCihuDgsCKnxy5
h2TiQrw621+K6XKU/cf3szvDj11gHrtYF/PnbpS13V8HcyXj6ay18XU1xxozU+57aNEbWkFkYb7E
70FEHvB6npHbx33xw+X+PGkk6i73+pKGeCQtyzQeRZw5vpiTQx011WSccTk6ETw8Dk+k38Oiy9IC
ivi8a8PALhVf/APLWJxTDTE4NTOX4197okuZXJj/e/J6IL9sFYVgVm97TNZ2rE6d0A2MV3jN2m4d
WAjtwTIxRcD3vkW9Ar2KQQ+eoNFJIeA7bcvKbE72kyxml5MEqoQPD22M8V+JOpOJ4xiwFI2DNOc8
SF4CBJZT+Xl1DkjIVpxrD3Qq+1e+plvDETAnvOWdk/BWOuCxv6/6W5np6wCQsmyjoh3AUXtpZXPi
62m19tlBKg3p5A3RzOV9Z5ThR2OdscQWQrV/r+VfF+11GjJMbz1vktAOgM+6kElUEOvo9oYeFZGL
3szyVHSuhHnXShOJbqCXpgE5xOE2OS/fRKtP8u6bkhGgKryC7Ng6YYBqHuK2IFaC5sw9YcbWwKXS
/CWIEs4LdokZXSZC1ougFbOjRdMqr90Jze6Md/hltVHH0YEZPq7ClG/pxBddCT+JD6ACx4647q6I
svFcRumhO1e7YPxb7FCkNOIItdovQAj80eUTE5hFuTUIfuhooIbgH7Eo/+DGpg+BGKQlleDcvRSE
lECw+7flkkLWH7tf08KWshyWTafdDeL1SAW1xIA8ydB03gIxYdCPxee6FhbBHZRqb/Fpcfca3G4T
ZSLkUORpnhx26bRdRWd4eN6F7BFzPFV5lC8C7iQoDWP5XxKeVSPkmCOhcer+yWMzpxErZDTvxPXO
7Db0v5KAUKe8NEX/SI5DnJHYByGVTDC8mWrZdLHzA2H1pBRKLKHESouwRnUqubpBzv1dUWqs455k
vZz9OX2D7GfO+UkEFa8Qqt4TmvaK1bHDV+lbTaYRzBDE4zNlf68GDBQiMCtyqG==