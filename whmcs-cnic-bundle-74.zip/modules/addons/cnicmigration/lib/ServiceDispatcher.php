<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnVJd3N/Lp9bEePW2HQxh2iLcaGvhEwBckaTwtQf1lD2topl97kRuUI3Maq/BKZJEfzQ1KtH
TdcvckwLQWKlFkrNdthSNPZAhrL/n84LQEXxHV4DjVGXbGv7l52aVg6Ft00KZYlPp/pEoRUKbouK
Qjer0bq6h8HpSI+4fF4vdSPDUyY5UBd8HcdUiHbgBhuWkBZVXF1ddXDTX2qTQKusoRyEGMJjknW/
fr9lLhrExu6U1xtUjOi460wtOYhsY238pkQGi+83W26flQhBka+iHnnQeGd/rcTLaTcRVHluo/T9
/USd4Fy+vQ9Fd02nsPuBdTmAXynka6LMwlqhSTVMtmS3leyEMc7MoIb6mH8jSzooAje7738g7cl7
hQT3ITM2HPd4Pb8wDZLhXx0TBGzzMBlYa+tC6Nr4g/POwf14wmDrptTKkpyQ0IhGPweW8omUx0/E
9Df52OyW0AfsW+Dr5V0pqU9MaPw8FsC/j0oLcu7U1uaX6y60yhgnFuSsdhM0hcOINxlC6WF+2G6w
QpDd9ljwn1PWoM9h4rcZPBMiKt5hw6c+LRl1flkosCMY4AGAfUxd04uO6OVzU10f7sKurTnp5Scb
zbleub5pZQkaDS3QcnZHs97DfzMoZkke50Gcb4tytgDAwgvCv+xJyJIaN1HDR6xbdBRd8hce9Zs6
lJMKXFFtuiA4kyHiMYYdp6xU0Qgyl0ZhJibE7/1WQPENHbFs/UL5jp1qg3AsUsNOCWyBTpqP3xIY
7f5TkJ4hpCUGZWa924jJ/8OThygMk60A6875I5+sRRpUWFyXD40HHKBm7yKfmmgR+sj5Z024zApS
nhPLbi2D/+M9MlxwqslmMIIqqbufclA30fUrIKLn6Gpmvs0Q660LAfrwVDA19YxDGgh7stvLoaKq
v0UZrsdO9U9SgUtmCVduC6tUJoD3Y4GbtDbp3YgU1EHMTCt/2aQ4HufP4XGeqeTcy0ko8KUWYN1t
TTLgUVmgRX6vG9sM/umkJ0FcftX8CIxZjTvkWvbvQSpDhzAI/1iphuNSxfHEWhC+ecmhXPQyZdxF
pnCBZu5hDtRekOxLXX3kukGJNaMbZne+Enl8B9kzvfaT54/Ra+9cBaYBppzSFw/LGt+DnUXh2NMg
kpyppGtaXUGqzVZqKn4NEhPfEjNGcb3S9ouO1I26lk2KrH4KRpFLpyICI3zqrpaOelvnSXvQaiQX
o9yBl/tryxVoCsSncWMf7DfHNZw1RXEHbXWFDC3SDdKb4DuCQmdYqs/LcCSuAv771tAdEMPmxHp3
mNMygtqXj45/B2O4xXzeHCCgOwJsW+uVHfVZhl92ZSMO1NS9TydCk5iLmKfV5opx1QB1xlm7hJOf
IO1GYs1mtXJj0s3AmjD0FN3YPgMcwmpzqZrLBv/8whS4IfTJDzARx37sscf8Xj9QjJ/pzEQGORnU
9TjLujFGK507xA9l0EhkDbzdDfx+QKFrRKVNVr/9Rqedgj+uyDecZhSUOU8NUCTfenIPKbbJu/oo
LsTFmyCQtyFqLpVqX840UKUsTSnF1ABmUu7+3Hk76yNS57EPoqGVD0UhBrtKbosFm2Asq8fyIFcg
zAvtPJfI5ExcPIIvJk9jnRo/NvsqUCd+IVNDuGS6IruFKsl0lm4ESLOqmkpgOWUUjVl70kEL/39R
oJBbAP34q7Ri7s3PS00g+x+bFRCRrDDI/PA2IO/PQ+uLkzBx/hKg9BCT6PHXUwFHJJhlucECgB6y
+Vfdy0bq5PjMqDDhfEI7Ofmvz62yT0/uS/dMXdkh18kT/OL3vFRSz8mrZySf5arZ4+lCyeWlEz2t
XuPK318qad6qKj/aKptcK1ef82GJsMFRkhF9A43JbGa4RSRWMlZVpjd+4/Xx6t2jnd734A4LNutU
OwWcmPu7o01ZNez41TNXRXfhjJZWTSxQVvg9BeruBX6m8fRbQQCl8vOSgcdvUcHTsz4M6jDNtrCp
3JJZGUj6coOP9kh7Il85YLIjepESjgDN9kLNRgcjtLZ6QS7GsS2xPmca3lgBs2/EcTqJ0ooUG42M
LK10KOlNREVgw8AFLgvAQEyFc2M2dyym44hQssECQ9FWnI6O+wbzZjyDyjFtEBPqWHTCCWdInEq6
mcnLoCVhG3sAWNrDlBGmdAOH2G0fa3ZCwv/Y3hS1BiofKCfELGfZ7wRlYLkDVBl18MD3RmGpQ535
MgTZRIgEbIHVkuiaZirrbbi4+qaTxyHwzYM8UT1LbMnMMc1sgatTVNG=