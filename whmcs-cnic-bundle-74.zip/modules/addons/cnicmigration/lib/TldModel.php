<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzbd7VU//kNuHgE8r8PY3IbVVM2spYIUsP6upb9GWLaJwVSS1dy6hSff8+tzrfjqLFSWUTNr
bJTle35Ah+i5Dz4OqM/U0fPpum1a7BOiRVwKtgpTBvjyFj6/Z9aEqE+gm3eTxvtw7mBHofH5o3BT
w3MiBTZ82ZwrCtdKI3QKLRjAkicchd4P6uAQpVXFe8BhO0U0kGmvUtbbTI2gxg0bRIrt5zqqYooB
tVSbi7ClhMnxFzw4ruws7mgDvkQy+I2YPCnVuWE08QczgikwJwn775gX2OziCArQyW2rmpolU0bj
BmWliDSknHJCdzs/fOHTPM6bckjnoWKBYMYF2VR0AChIr3CXbSuSDnTKolzVyVRdlLP3ywHRBVJ+
J65sgkncuv1nM5RVmU6AOwaCZffBC/ha/UFCotPniCgs1yZdIRk6WOhxiFJfYWyBuY2hMfpNAkeF
JNlPl7NqIOAfDUbDtjtBxFkZ6JQSODPb2TCZ/Nu0V76ZOvGql4MMDBrof+qhlS0mAx4sdVqGQZNW
AWoZ5Z8bqO7lZwz+DwvKM1MlIVyT0GTht7XT6TJmyTyFELnkIxT6E19PuPrvdMSHz7K3KPhhSD7R
ICzfWeAXVHkfDAsUrJiM3z3zpJ62QsjwJ8e1uuNYMKVeO3/ff5F/owHK87BMuJukxt3m9alHmL7J
08sKYu30Z7zXWXXT8g1FOvW2cbYbgEhbQ6CMBEhIh1EtNgzCRKxgOypNflzo9Yz8jswIMFZbuyfl
/ijggJxA/gaPeh2/7b+yNYA7vOFgIfJkkTE4Nr6BTfC330tmKo13n0q/nxPBPOX/p1/wOUht510T
ZhR/81Km+qMXhb17awqHEP7CYazl2wFwZuCHY5w30mi0hIYme9yvnBYY9fHnQPar0A2JwcFO5j40
N3G5EeWFnuhwdyenIbdh6ewc2o9THAYxqxM2sD1HSRYv/drDNOnmVfFXH57dxmQ4K10fQbQKDdtH
Oy8YpF3TLRPaGDPBeWfiZR9PsJ+UoD7SssCC70AJJpDhBBQRlUUd9vmwj3gWAzlYEv668nopdz1y
CltXDrDVT+R+7O2rsz7Xu022Kr19RdPgAQB2uZh+eiM332govqfXH/NDHmOPzRms2Q+RIX5PEA9J
MIX5v+xPM5flOuOxwP1DDS4PCPXbh5+V5lh4uXakcDnrwoOQu14oR0RSx7awhimuX665Agmkiu4w
NN5MsMM9C7IgBtcw855d3Ga4gH5zj4WsSwNaVYLSrHFOth9Wrprvm6b2xux3drWswbX7reX7W1S5
5lEZxA8VvedG++k00Pf9t+fYNwHYrdo5+5eHo1+J/S5uO7QwciGgpFnOuOmFVC+3pcRvZ5wh4ORV
Uj+lhnRPPVMncEKTqS8lIROfabLOxsucHF7TswhvATMChkJq79HQ/j3F6WWOWOhADMDStb1K1m9Z
+H5eAwMFOvGXX9PepeIjrcZAQDRimvwj69Uph7h83fP3Wfs81/kNwnjXBTTGCSVrkrqmfhrlNAwF
ctn0g+BgzLI43VSihv4fsh7TcCpA0biOfhzB8ndQ9vjSVeUVP/NwZ54ER5PTYqEPoaSbPqB2Jczx
7UOvPxGxQnLRfvncU3ChlBWDX6zP/Ffmt42YfQd41QZaXYeu1SqoX9esKnCiaflefM4t0mJhOhX2
Tv+TzgDs+yQOCb4DJQgSbAG04ihm8W8456F/E4BhTG1mTsBjgidO5ny3SGW3kVjMcsWRyysS65Ju
Nh96HoP4yJ7FcJRdcpk1p6B23lqTUnMUFdQ/6Y+NRBiktUWifBZZx0prWG/R0lju929SnoPTNHIO
ylfKj1pBEt69rt79lKx14FsM61wav8hZ81vPKgLteVXrmWgyTjCh+MwR+tPd0IWaj1ZDcVSY134K
l7NFTvcZ87ljfS7HjGSzh6u/yGbHYhBF6QUOCC1a2tUX9YW80TDp3JZxVPTls0Hz7yWkS7ATQU5d
9fmxPiVvQdvGtBvnq1R5MCO8Oo5rJhsrdrKtH9AIpBE0XQDYc4UNqrb9xu3H0nxNM2f9wHvNSV/f
Wc4gHfEUPuW1MsyzyTdXK5JicwUwBDhYEb0h+5v0XEHvAeZlHv49wRCl3eczELc0OiTzprWiFXpj
vXKtfo7o+lW58kGH2ZBFxGD291LvRxR+J9RYB3vzo67qJ1YK4bXsPQZ4Ee7rO7QwFI0eHcAbS1K4
kF3FnTxtWaudz/P/vgIEhdWS83W04a4BReZwu6A8bLcBHfvW2/8NlhZFbDrfMiYQU/LKEqpxrS8D
Mt9sgzjvuI+CUDF6w+TTRIXV/Nx7BmrpwdaUYJ/LiDib9Wm9Dx9vLFu9GZZ7Q5Kagla+pHgpRASt
s4gQhd/RKq3aHl1oysTkTlXt0vMNCtLaR2vd/tCX3/gI6zOiXk7NKrhUUNZk1OXhAtIIa5Ew7mx4
5jK1IS3v+qrZCRQzaTeRAmBcZ+EKB4OPLcZ88tD8txcxP9TrIdNKDE5UkBEgYPJCtbcVV6kLaAC+
FJD6OUZIJ3PJDYq18y4FcEk1FYNkjmSloE00hQiK21Amcm3vbVz/2MRVUG0zk6sc8zGmg3Cf/UAq
i2/kJCaHw1rlTnwHAn621fKjsp8tyP/GHZtZuDPj+JDlrJKWsPqrFVpT08z/DY9cw/UgFTsFs5qo
lVuEw12dj0tOAV9BldsWNH88hxQb1bv7HDodyGr0HTQIuNWIjo3SHuqWDFL5Bz27L1TLXj3AbsHO
MpSkcRXXW0RQ+zngx4p6LRgTyVofJdC/0dKP3o2QOWPkCdDT/0Oe0xI0EoRVALhd33kBl2mwSAce
BkwjFV64/HqcsiXfrOVOVIM4hbfwnESKyugkiJSDNOI6BgQKd+NDBjcCFKEcNld7uS24vdICTf0g
bRufnjDnjtYjOUEsX5FU/P4jOGVZ2Vq2v5B/npKFgmBdHdxyG/PapwhfazABB5+Ig876w1OG4lDZ
cxA6Faixpbv1/9Ndd8bD9ELgUlCwbN8r16lKiLAk2ckIM6PP661AqXrFHxl7nBsnf6MGejC47f2E
ytenNb6TQDAi0VQ2rWMvKsaczxlfY7gtiT/WjaJIT96csvtbvUyNh5QOYevTA5ztFOeJC6OaOst+
8pRLMyNZbYw78EWQI+vyNL+34wTidoZU0oewDX/lYtN0E2xZg0crHKkQvyE3xaaCuDGzFbd1+nqe
aLzUV5sPVqoufYJrGqJYZwUJnsVsiZsn8X7siB7TQf3NFKzvsTAg10Kwa4hqmExo6Dlo4aTrTpR/
Ix10KtWtb1HNROrlLkUHQeWmKqAbXCoecUpjmNXyK8l9rsm4tLV/3vtehHjm3c7vOAHaV+a7P378
PupoU9vAuQVmKvIXpaOxhaZjUKlP98YgorYEEH+9fnsxJxPORdmHQqOr4T8SMyOsJgkvTyt0TllE
YqITYGHy/ooXBWHBHGMq0RSPPRb4IqRH6KKFW4NohK9SvPt7EXCHHLlTIqqMfaqwjw8DA1uVWyYb
8PkdywBkgdpnpWLJ/Ur7o49jVvSJuAk1Mkbjs1HJh5ci0Hq5apcFPxHGJJf6d5fpG+q/setSCXW1
8I1jJsexoLtV9LFcVSd3jItHoEUEnu6JldtTP3xMT9AV2EUbHWYFvJ7nXDxAFGSBN4CzaIm0pI9d
2kAbaXI7+rlZZg8ERWzzalIWpK1Q71L1NmH5iwKxhFxM2hZAOm3CZCRKkfgWXvMk0fyH3iTLCqi9
VwrbE1we2aQEhfA4fOmJjFdZXcYdg+Nc4rUaIvlncy7kAod/BJzx8PpWjcl9nKAl7BZmD1ATpQ9k
rUTGbvva8dcJDCUprt/GDQRf0xgNkjV7lkFd0ejWIe63LJzbOAa//AUQbDg3eOJOxjPOi5dEMvwy
fuZymOkyn91xXTCgQW7PXJVRZns5AwECAGTIkxkG3Yy8G1RQflYq2UPcWf49aEFUqEnFIY54NWsZ
u592K+8bndZVwlHBvo/XE4AMYeg/pSXBCQcZ+7/vakr/YKrgq4BgvKHCuYInpDFR0zkB75rh8hS2
J9arVjTCMMPZcAiLbNTueNtS6FQlu0yGXpMzITyB16nY7Q1DDtPZgLpT60cT0ksLCXAabjzGbI5a
kv2Mm1stUP+CrPANW38nV9IU4DtWWE0EzkQoyo4XjV6eMdNDxlDnSVgBDs7G8vg64ZBK61JazcQe
dhczgwQQtYAZ4GVqa+VG/7d/NUGSMsvB0Rv5yVxXd5ILvddMtdXdZfac+sgWDLHHFsyurKGXUjDf
Av7ZdMZmNIxCC1AMl3Zndi2teCkuoqic7SJ8hL8FrtXk2fxap4iPyiyYjzox+Rogw6kKXx2PKImj
MS/pkjsMGKHVD6SE9yQ0HvU7iofW90N4LAiZN0KW6uIlPRO7mkuiZYF4hWA6Z6W2CJ0bosBaoIc9
n+Ni/XjP2qIsesoTEM1qD4zTskAvP1Mbf6s3Dp1lL4N5y67bL69uK4aBj1umV8uvn4VegU90WglZ
vTo2grIAjE1kgGGfqOkW04Bnh5/FkOl7gvRHcFPQ60sBIoOM+7R4jU+H/U0mOIpjqo8aKDrlWxTp
JEkFJs22qCb8tmgY0JY7FGQ0qJ8nWtvZErecRnEJFUBO724Z5oC8U4aSxxoyQGN5OHn4kvLpOguf
O81Alf3zp5znCIIJp/HihE8GTGVgObs7Y/QHmlF8+SA3Xhcool6mikWj/wmx7E16hSgEfulEPae2
gr4MFjX08Bq04eA0iuxvxbOw4zGOmjuhkq0i8cX2wX6v3yTpZIytAu73I0MucshL/rKifnGIEBjq
NWKj1bgoRHZUv/Q7+y4uAM//Ml+KiWV+MNwfFtGdJdWE2EeYAvAGMOA3H8AOeq1PqnZac2gp5irX
gOOBVwgaoonKr8Z1wXYx8pKN/LoTzgfQpmjeTemOD0uWxgTR+rIs+euLdXsCCVMpIKpw0G97T+Ox
CNtaOcIHzScXqvtgm5CSbpPepH0k0qNtp8o/U+swksHpwGgLBe2XlHleTMcIH47lMC2ItJj0WQqg
fUxutl6j4GvmZ5jEZP9PAQz0DnanNx1+pI3YLsHeYkNleZV7w4EYH0rP4BYVQJDaYo46UPRcW9pP
rNWrOBNv2hy5jnwCe4wwe6a8LW//kpHz+rzh32W7EJfeHENbER1SVGaS4Td78t5dEvfhdSN/BJTh
3cFXj/eIV3ytyBnW0m8esxic+dPpvW2UJsgLUKUCX3IYYz8c4i9jRoa+sAdJ3qextcOThSaY1ybM
PRdCwzsQW98UQurK/rG5ulat5ycDeZ0b3YuhbmPAK7oct00AOK3Cfy+XJ9KoowZvICUS