<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqXMJyeHzhFjx9pQwMx493XcTdXvYnxhPRUu2uMqSEeXip04eUzKkj0acRyDg3VHMmmlOCW3
NUl8WTPcHEoO6b1AoPpWXbCGGa+YXFtvvIdqBuxoPGcvdqSAVLiOHQczJTLBScxMNc57tVn1oaKc
NhEX/yJcc1Ui/muGy7TZKMv8As1kk/Zyo9jxzSWl5tGt158+Bq91B9fy7/cYO3MtlshnAmfxsRGC
evTmrjSita/j8mjl9soAbLqQLhi7TEyILCwSj8k7Bd9okl35K6IoGTan615eVCwHH+WYhUnJ/TLI
PcTJ/zOw6LYNRJitQbPJbq6xJMq5ENxeUTcNRePY644i2cmUF+GEHE3A/KT8KUNlWESQSmjlDjLU
3OPPAWmcuj1GTxLvgRZeVsxHsvbkKnVAXsHN1cEgcZDn/XUhIqt/OwCeOYLWZdlzA/TZefPfj3cR
iXnWgWAe+ENj4BW1Cy1jUlP3SkdtiqsyhQJZuy49dWL5g+dBHzlwHrTHYNWZywUh7TNzHYCMVBgy
56mqYrUwyYuHYHS+2fMJl5RSRPCtlW4efW6HEcTk+7a7FNRK+kZL2eiY680/OHl1z2hSIh854Vv2
9SHzVMrQZvg4gFzm2m7SDIoEesujWjPQJ9hcckVlLaNUqGLAXR0JGf4IwXzUy1dTYu+3Bx+7bPqZ
NAjPCSKhgcYQWYuODbUHdlli6S+7+w/V2SK870tudrtV0/Z1XEHSJElglteMiimdXAP1qW3a/Vas
HtT0ggT56zF33df9E8t4rJDrkuoAWgBWNFdMHbTQ6vPRpbZvzU2LJmP7oUbDPklUE+UAoPmRKryv
qd9N1Q9+oapjZPHx/GDx48VyGr3iaScxIGyJRDdxZI7mDFDc/I3nJ61f2EEtMzhSRyf962TWMKWd
IAnOxJbOWE/GWKTw9R/VKnoVKD/nkTRHnK1LXVi683ucg+fA36kHrv3aCZ6pYYwhnOGRFmao5o2i
m2yFwG5kIb76heDyDcTiINqQIL4tDMgQWkgZTqWgKudlVm1PWYCGgej72KqxhJuRKiQ9poxpZQUx
/kz50PkUnHoyTrDPngkbPISHMp/pjGLtJPF1wYo9vrEABszCDHRuZQty0Xiffwf/3YVttIjnr3JQ
jWbn0Qvi1iVfGsju8G6DTvBvPDnZ53fA913AhjQuvzbJvVR2LVA0gbyODHInpGR5PQ280GnCn8zP
C62uqZUZZQ6nsICOojfnWsSkIhlo9lWmQd9gtWDR/46m8tMkB/et7vJ7RWUklcgTS/I6d8suAan9
fJztQT9S5M+qCRvoGz7jFPlxnodktYb4jMaWGCJRe2J1swCYPk/hoB575PDVUK4St4cw1cQrp73X
/A0efoa7J8VwMJFAewiGYvu1zzaHs7unQF6L3AwwWC0vSEvuYk92h0NjJbWm0Veqsr/zA3tKG0dV
DOnaZXwPkqAr17UyBTWz2FqnUiafzhMundwI2nBNx8XUUFdP2kLbxMrrpw8i/rJGD4EHsyj3+Nk8
1f1iRUAlPYk671bAZPTUyL63qTIEqQvz7jb7vUx9j3Pm88XixOf0s3RPUXPnwnYcjgzMxAae+atf
atfooxeL3lB0u2ZGo7dYbm3mLbMT1DivdiasJmKeiScoAZeTajHq0YKNvzRBDK0IkWEMPU2b00Ym
yt249rw1Ch379LLCowErjUNR8H//+IZybSSG72haiprOjkcjL9yukKEd0/74wuQHnn0zT5XdlrHm
xOHNQdyg5OKXdxzPqJAT0zxZZEQ9CNNsnKcaTRpaNnlU7fV014wzKdUcxkSa8XflONilqh+crxWA
nNp9JHswfJB5ztEFuX3uduzh6zlGGkKHEwV/9zQLVW9m4nAxyr0ln5kxODShCa/nEhmWxG5hW8eQ
z/i3Aw5HgUg4BzQKDNfFqNPdU6bdtE6s7vDWayvOEUgUMudSJa6x2XYFDF4mhfjSnFjQmQSpNHAu
DqLWktzE54qtnMpznnXRhZYt32C4qBKPkZWOT6sNm64vzxBqqNSFFySu+rAm6Od91/zbchbGVL/e
oc6MwgwnuVBFIMtxH6izQ3qP8jhmcMkLiDduRszh45EOew92NInKUCcHHbah+jm6ycq5h7A3qKN3
j4EAgsM5PV+0hBDg8A5lMwgBivgryK7umknRt9r+0cO+QLc4vlmMwkTD7H8GTGfW+9b1wtTbGHHk
LLXCfhoBZrYzS0fWiHGvnc/unhbT3UWWAYMOpiXzCaHiJ537zI1sHOLkPLEN+E1ppY8Io1gC6Uai
Zu3HgdFHy6c2nXExji+rll8Fiqkw0LERgOSDQpTgyz2jS3Y8j8Lv3HzApzF3MiR+9Bwa/10UXjaY
zx1XqGgTzYB3mrXHt2JsDQDh0Py6QTjCwMELO20uioSFRXFHMSIHSFgkAITlrOIAJICkV1vJ2+wN
WTrBoaSGAZ4bEAgtyHmKtcOgignSjK8xwfqASAPR8hjeN8yY23dj+Sr1GSJ7WIvzl89IgTNXsB5+
HN+a5OI5ixQ0xf54MOOJJvNJmdlVfTz3avOQ7dhb1HPnPJe8+D4ACfMYbVkKKjLD7NB/DiEGEOmg
Zv2VDswXc8ip2dm3yrXeUtnKC1T9mPrEwR27ksvT0y0VJiKEKNRLxeVZloEQYrEPpraid2l+oiiJ
M/5Z/qYGFbz3pwcoplFwlxeDAUmWbrdPtFimHT2vkmd0bII7Owfv2QEz795fUAW4pZHmlLCRfURz
xVb1zgJPMKcNQMmdbNGCcthcGG+f3l3bay9b61Q5wJyFGyXPqL+luDlROjlSvaCJb7tfb8MHGvns
o0q712UJFSq+1wp/ijC5HEqN+BXJsM+UmvhLQiNmmu9PS+9vlNpmfiXaqmRAE07JXf+DCCVc3EGW
Jr/vOr3+lheqrFJ4RsT9h721lVnT6du/ifqTD2h8oXC9lKtwcFb8mqD+TW5LyW5ro+vxv97rOfe9
hBspnKgwI1RyaUQLg6CM21ACvo9uWTXqzyaXyaNA7+Tlh73gb07dJNg3CY4jpBs9mixxnZ5fsvWb
kH9vL9lRtH+zxS24szTvRSDLFbjGHJHcs3AsrptQr3yTJI7sAVHiuAQuZWw3CQksbovHxREAsdZv
Q2NymFYDRMWSi8QDnGNTcOBMdeMWPBjk5qMrv+D2pmXHgMHK0uk59NDk3j6loLFnFiocEaT3qSjO
Ev6utEJ6SnfSzM36/nzOkxk8cyW49bbYepVD06jbWBsI0o728BEMe94Hd/tmYDmFiHw9boPqJh+P
rszbHFbVGCTPMbaMzu3HG6KkgdLtnkXOv9HNkdnKbMX4csWJDrtWT9CiJWT0IljSpv9znAxg4x41
UZhn+RMjnoAWigGIKVA6JN6yinaErXVq/L7baPCXoF5XtmfqlisY5szb43ticMhV+BvybE8Swubn
L3Uq1lZZOsWm10zqTbEGorlw3x0i+J00OobCKvaBhtCDZuVVyAzdvrCMYUT4usAZI7+oz1tzFVnF
LPwsb85FMCZFhWPuBEemEg6KS9PAC2szEA9G4RcAgIwSnOhmyO3niOG0tW8VMESfgL4qMwHJp14p
aB9RjOIcnhF/lBZe0aAFl2rEVkZwFp2/rTQTSASeDbvZSB4LRKTnQMPpZ/DYtyGRYNMBEka4my20
4lRNyCd7LQ4nOvkkR+MLYFiFl1giSkGJSP9P7ikVZ2C2VbLknvsMUMEtjzLeyaLy29dkfCeTpXnO
rd3tczUMVGkk/yqUv1cqmKNqw6zkuPcsz2gxdmV7Njp1Ax0q+qcfIsZZuAQmBRVp9yZCpKVKO8lX
PoKSsAo6kHnssMq4RhD75Xsw7p3mIXgA9ZkKRGR7iKqqudAoPeo7nrw1JGIHNKrFfPDcWEAtblW6
7kR7J9wfOZRRX5emgsk0vlQ1r43FSvNdbCwH0Z+LXviVXeYpHrKxMuQqXSC8u3w2wU6u+Nl3Y5Wr
hECb8anYVWmLFqYADIfXDn9zCCYU/zIKcS9Hf43z6LV9IkxnJ5keg6jFQWhGVu0HN1Fv7Y0/He1a
467K3tSQuf1w26YOU0GpTQA/PpMFQWn1zMrQW6uXDk2stCqV2BzZoXk86MO7ei1Xfxb3qePt0HDR
zNqWia/+tFFFrL8bQRgmeR+wCVzd/7ApSWFQe4FOzsI/t9dyuboQKjmARoj6DXjsWI5ikWH4NacP
N1jUTxZZigBkJIrH81asprHv/WV8rF94fzxjpiOD1cGnP3KgdTX6tlZ+WlCkolJ81s7WF/4BPwff
w0fo+SbstI8F6++GtYaBXC7hi1ukCJaSODvhLXAwC4C4ejjw29pLILVfkNap92iu5w3zXJRZrRHZ
BI+w7w6aRAHAC7N36C2uBauaoYo8H3QfboEhK8m1ZH0ntZid7o0byMVFVuX9P0tvD4TALDNtzeiN
apVuF+gZDxLFUyVt0nooyzOCGK6NjQTqzPYQ8vbKfOYYoAbqEz3bNNsdmegSmIHxgKAgUAN9pByJ
ysTCTC2feyIGEZxxbikUOaBDd4abfuWXqUUhKgPzyR9+7wMeHwco9O7f3m5pmeC26a0JuK/LMUB5
hH+otQmwfuuXwqANPtJJN9ja8sxbuL3J9BI93TWkNI7BvQF/66vo1aMLNGtgnKOG/iz9mlify8+g
G/DP8FQWAsm6FnAHORS1vYSFGZY+I4t61rQKZwXqvB/lBy2XNBnQmFR4RSW2hKUetdD+YW==