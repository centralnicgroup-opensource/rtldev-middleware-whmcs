<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+CzFOmt0uQZpe+ehwMwVcYwFnPXaxHKRxgu0JNdtp4jbfW4isFMOj0M+xXUIo+7MPrQYBzK
mVjPVeYxg8707AXhTj7FeTuJch/kXKxnOkeYv41qEWQJH9g+WIuTGo1B1wg7Gb2joq0fwMCUP6Qg
87RLjMo8UTLuohg/6FD0ZSlgadXe8SsULp3NN3dOi6hXGLsjIhBREu1PCwqk1ZGPjCCMDtNpn11M
/rQ5ZvO0EcbneO0QFvorxu9tynlQUTXtac4eNTCbosADV6dRR/2llM6b8SLelp+mPEDhwyVXtHT3
9GSBRYiLyoGoGlcVGoto64jqgO5lq46nG45xxMXJO/tLiXDjv38O1iB3TS8/y4LOEFmOx2AxhV21
kP4VtNqgmLOJwVqBKgXITX/7ar6aP1CFFp2fKe0JS1Vys6V4Y3aR0+F0SKSNQX5jclWoZDeYompZ
Ym95X3xWqjEeHNVQosn/4kfRJC1dAA35dKlwJK878FfWzkLDpiYkIu8QK5PZj3f8R66H0Wr0lNc7
QGHI3egT8NUrFdPYkCrdXEZreHlaQZMJcbwAHq8d6+IFj4Ch76+juMORZll45KUiY9TBwSIjnRxt
1ucfi6zHDsTf7wg7bjuI/EZA03R5COLy1mijwepSM6bI+GzjXZHCzAes6p2IQYxRnTgTo0x4NNsf
9lEszjfXkYiZte6t27HuthUDETtFsDkDotofBsC+VIGf17AMfu7cdsPawPoVgdY91w2OnE5a8OXW
VvIcPPebOEPC6NV7Kv89NYTMikGwahqavk77GvOIa7KNrWnxrScDv5FqdciUeb6fRfsXr+tayIO4
wlVKPTjIxYar01VmWiO29AHNuM0PNThxSDylHnTRtO43FQlYYAR7vAwg3WXC5uwojEyrJ0MLtfMk
EBf2cAOc5RgMaRFobBv0oZgudIyDZT0pAZvyVVRA3Uo9aCRm/kCdJAXKaZzEXPKf5oEJ+gynVW91
494TKfLJ5yHOhVggThIPJvRPvo6QRsSXw6m995614zsn2hUUExXCyTZ/zmbmRkppNV7XV3NmkFDz
8vturyQ7ykJZGN1NE3wTV3a0mW+kQEEl6fRJLA2s+1x+qlosGA7oXZj/BLtnQ/W6h3l4hY/gjLrJ
uYil9Q6WqUg8UMqEI0WzYtQ5AZiNvET0XfTdtUtPLijpdfVUyJ58u0f76uIFRhjNs4aFz8oFVMW3
SR81YC4vPEg/KYafLydzvSjwv97SZqw5aTOx9UZxQeagQ/DIEh2MS89WHMJCLso5cXUZKCNzoBvr
+/ngUS8AvFEwqrZC3H+IlhkZFUBIebsOr5yM0/fBj9BoVQWWX94By/ZAPu+lngJh62el/oV+uK7S
J3CGnNy8gi0zqzKml4BKl3s9TbyoxcsccNpYAClhj7VAgh8i6VM19pcRXPZ0ntn6fEFnS+Y1yN+p
fprDB0ed/3q8i2E4sFHDkGvsPOXak3ISTSwqcz+10tEJiiizkPg30VlPR7GjqWzWYY0bytqsO9RV
Y/9Ro+VEBfxcXMz2jo3XATQKy1Dd64i0mz4w7ForFJ+U3yctxD/f8765Dv/CGUvUqZb7Aa+fzRFJ
n+H+9qTMZOTQfroZvkG5zrBhiT0zfok/J/LpoPeqrSlZ9dKkOkParC1+UQx1o+CFfg3klC943ISr
npepyAxHblpDFGF67BqYMbkXUuv7PnNpKVHFy5GaAuaQhYgM+mgWbZZN5gzy+GBVqWwpsZNOT+/5
DDR83bJSdSYQJ+4GI2l7Pi5/JcdnmiAi84LGMVemz5OD3WGAyGHTR5m6ytdj+hcfPXbc3kbbhUAG
qCa+HdVhwKacL/KuNdckRjqJWSIsHyiXXCPZk74D94H8+PZvtbbdNDojhVZxqZNNZSLfokiZEcsr
1Lp0ILRarvJd4YGlEZq7okOQUXd92lLll+6N36T55Q4PZHl3ERMKXk1r+/4v3CYL2G/AsgJLfaya
XB0sLPUAf/PMUca73qoxXMYKXH0GPtmzIZEe0sINQ1QEkdizFNs4bJ8q2wEyhziQxPOtfM4+2Zeb
T9o5FmCuwIoDqiXUxM6JENuH3vbviLFvOKqDxSLfjerISFuxsdxO+W5uu1ajGKgOLTLtOC+RPXOv
hqIqU/yg