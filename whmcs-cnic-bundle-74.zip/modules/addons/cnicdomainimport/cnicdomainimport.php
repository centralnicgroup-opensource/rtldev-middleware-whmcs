<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnqwn64ShV/QLjdnKKA2swHh6YaMAQdyiFzin7XNxkCA+27cQiRTovYqUAJHA6Rtr5JNYNgw
vXpXqyxgWSD10Fk3zSZ+gICCke0l7Npn1EK25xcNRUdCB+h6/ubrXopgQF9TY4Jc8KsKiGBdkFXL
47Z3dlQO4+K6gIxK9HYQm/vGhFklOx46i4kMiU8pI0AkqJWmL9UwTvT8ZaouGweOWQJx/Wc/xNOE
s2Km0dSFMjHuQbrkbFUIPbmRqkkn+8VRtBDmJgMuIZQBYWnStR4V8zev0JOvS6mhMWEsgksPcaGK
8n09SV+8S0zgBOmU/JMKjH3rr9Pk4rXpBJRx4uTIuRDjBsPKQtqrozOdpnLy+4EaxlbkwI8M/3EO
eGF7IBsYFu8d8HmWsoZ9HJVRTszQ8fRlRZXe+9vhccAAsSrLWGTuBx1JEMDzWo3XCow5//7uG/8R
Kt0ZYW6VYjyNcgNfI8FF6dcJyNSAgnbylD3wymHD/Fw11+eho99Ldnqghh7YqkWaICRAw/11m8B4
iHmnkYpFzPtFzkEZv+7bQmwOJTLhIHBKBDL8VABsMigA0dAFD+MyynC3HGdJMlAin16CkQVBsL/s
+ei1zUoSlU9b0snEcBO7mHvS2XNCkLBc+jxP5BbwCkqPJ8RfDgPD7XSbcfkNVb1koDMyYqxb/0oh
v+QYsR9E//T9yQlFvvCWfzB9fwwPndoPK+a/D3AJ754DxB8fC08M+GH9HTFIr+9YQFjUk2YPoHnG
SFIIWWYxh0KU6IKahDELrQU/yY7W9z6Wcm14JW6+8nJZqzbMqBhickGQCu3bQo0ulw/agovpoaiM
vfSFzN/VsuFzQDHw/bwUOHlC7bsGOesSVozXt2V9KMR8Ho1RwPVJrhYU4ETZys2hmmgREGok2G8P
FZP5ID6tx/0uLwGoW1vI990I7HbOaLfGWCHWKWVS6fOC0k7EFHTvir9gVVJbTkm1j+dU+XVg6O3M
EUcxJGy6J8oP0r1+5NikYtUSSWqZYOchWfWaiYcM02rdi39aXHdqAwoAjz1hmpS7y1Uk/hFcI6Ir
AK/3jj0K0SVb4mO14tNTUzzBLnhFByh90RYzwESRiMP7MMA0uG89r98R2tQQhN1G9hJSu/glndla
khqXmYdCTCeFM55zVjo8KZ0u6DxucR0iaAnG32Ov6vUQZdGppzIVRf1EQNFdPF/LafMwWa9Ex21T
2e1CYEvtfHl27SE4uJ35lih6VDwLf6saYCumJjbSttsQnB1K8pcdjzodmgJUJtBUIqn2BAaPhDzA
UKAn4m9paHAGJ7y/mDSrb2zzS57F+gneyKCL48Octtbq1yPjSWMekUf+SMajM8Y+RGJUvCpJTZDP
lntLPn37VQy0ZbRgb25HZEJnNy95X0ylO2x77fzsMAZDWTImV/x9l8dHZOO/vFNFDA1xIcrz95Ll
8Xgrno04g8SZAvaJeqsGBAnfAncIiixgvuapuhare7eGrSIFQBdfoiuTYBd4QTnXEFQEGtoxfHAx
3edfNhQwhGw/S0o7c4KMNnAayvIl4RupI4ihv//mm5fcXMLGTw0jEeUdzjurlb98pz4GY51af5HZ
bKKSuLiVr8KWD0qpHHzgMsxiyq/+5S0mOQXsrgHllye3UOTE8cFxkrk7oRLOW1Eg+4f3i7kNbcTW
5e1zuSpmNfHOyYPHizmmV+mIaAAerLbLhf5N1FXHmP6CH+pTCCJwEv78pTdZUE/GbyWAclBen2Gr
/gSbXzZE3FeKZXy7EYAUp69ZVBW8+t/EXXlxY0Urw2z3D55yh2JOVYtjN8GLCBGSjEbxGmSn77X0
9FvKrywUq6C8jzVRRABbqV29kOLMwtFZsWVkHWuGaQm2kiA/NaUWGdhBaKlHDzy+/t1BAbF/EK/5
ohw12YJSwRzlSDooCYX1JPsJchv8t0JrHyVriPMtSb0jMySjPQy82ipaNDf1LZLDQ9Tkvd5v3zhc
1Cs6c229CL5Xb1s3E1MB++t4PjwV67rV86/kK5ZIbpcfGM9TQhJ/OM6bkh+2le4BlaTuAzZEBqU1
5qZIQu0YpChdMNz60ekSGJ+Gl2sHrMfyjMzPjZXK3UpifPOFB9e6StdAPpSIaHHVtlGfBasnR903
VhcSZDn101aFfgfbkM051myGTdgsjFnEDbXVtL/iNLXYmj3/lY4ql7m5h5kZIHvGhJyNVvC9aJug
Q7wt/IPrS1oUbeNWgKiDXx1FVTgVi4Se1zvW24olniHGV/Iqk2vv7mbL55JvB1FPYFCWI5yxkhXa
bZhsOeLNzViszQ8ziywclUrlzgQLHiqiziJehI2ZZ13Wu2sW3tgO+t233AqzK/bWOH0gmvDqaAHM
XBPM9sEHn+zgBOaFyHvhmNdozu+0JfUXz03gA79eHK67DCFBy57rkqrHjrjvbB0o1bxXVPTcEcGB
iBnsXiIAdksEohzgPDPPVr29ojkjvN4VGDFnbFgkYNLwCTXLpDVzguNZTRqQTzxmYKlZLmepE8pw
/HyfzAuFjbi81qEUhVfrJhE0m3Py6ZR4zeBgnYZjyuZ6+hKEYDK9Ff8tymUyuWfzfm1tKX6TR2pd
Dony/MhaSPpgR84679kdIZ8ODCbLt1oUUGZanLkLTgUx5MnW5Ii1sUDCSR/Hr5oLMUFsmQLBlDLd
ZhpLSQfgXadU1HSWQ32jUulcQ0bS1OWL/uaPFmjtCMxI8cUNVOtJko1LSR96E59HCcsb2UekycEJ
n7zv5JW69LIgP4eLDCPY1LEjpEsf6DwEyoi+FO7EFLq181GGkLcYy1uxoKU61qpPtmfilNHkRfET
uHrHLb13HSaWyJD7ZkDt1GNOfjsnwtMISylOVyJ6+OHeb7rf7vi1Vp0Xp+k3aVrSm2AClru6heIT
UOaKhnkaYZ6QOiBSc1ecmtiY1fO5mGe0nIqWNCMTbW4Mmwg8xlwtwtKh9iozufEh8iCgFW5mhXBS
Q4EgiqaXlmxg4R7VSSCDNHRGHqKfV8idDJS6l3Dz/r0ewHU052+XI9COebvcLh6paMXXgKRJnaN4
cEyhgtIcu3Mn3z+SV3QJFqlYTytOv2HUs1xUMWTTkIVGW9WnImN/waxh28HsSt/LGyYinwoFveyX
QaF9Qee18+dZibIA8etlrv01w00XPjE5opJUOPSckd8+qZKUW1mo0Vm0P+V1n1xTMt4FLvS8Q6qV
oQu5WTRUpOsgy1ZLQShiZ19bq+27qtYt1dZ2qkP3BXA6hyce50WGClSD0132i7DzPXkvOIh98UWS
JKiw6T/3374hi42SQoiPKcGbju3pXmgUuqv/3zNMQbPgPaFnswa6joMvmED244jfZ768jvy61MNU
LF6FZkSV9mO0iwS656tLgdeGPI7ooWCmqDvq9P9B5fR2kXwmVCBFZSwTz4C2t7O8P3Ufursfqne6
7FewiQyYVWSf89Cn/rTPNsUFjg7IjEcd2u1OYPKJZjeBbYNh2v3r0NowN9kImrEknLTQOblrBvsK
MmKiCFMzpLoXdkFFXhdEVr+XkpYP0I0JHS6IZNVtuaVIJUmb5vjNZwflQp7ma8fjIjoleWMel1Rs
HCIvnEuMoz4pg2ShB+yNhSbxe9BXwwgqlOM06+TAPcSO+oAnE7MbdkTNBOk02srG4GffsLGCnlbi
u0IBp7kzC+RsHDVS+i6s+b6OLszIGyZ80KJII2fGZsj7QlD7RHwQ1mlfU2Qyi4z8WTjEgIIjIxUw
SiGaLZ2K29U3HK67fh6DD1yQh9e5OawXKabh3YBgT4yewyLYTNhOQamVRi0HWsgITsLqc/o38+px
29XKpOVawAhJubdHWnAHeqdG/8bCR1E13volynvhbROa7iVQYYXfLs0j/1lIsATzuASw2bilo2F6
pSfxRYVwef+UgUWG1NBfa99zEYMrnvUpfkyqPfbd1whDJXGDGrVi55n6TvHNeeSVrp8kc9YgLArj
NboAZE0TaQTRUvqe+BxYFRsyAJMRjV9Nu5Pnk3gfCapAD7R96Kf+qI9Fvrc6FNOJ4c8G2vD5SpUA
vfrb8jHf8rL864ozIUTKjYaDah7Dj9b1rzl61KwJlZqBhK0GQZNag1Z4kDQUVWBoq/tky3j/jft5
amObdPqSSshbYqg0gqCnvABBcYYV1HNVE0eU0YsMRdtKjijdSL9gLKWU24HOUU9sqbLh922aFrZh
RHoukBXdfLvTLdno6ou9fuQk1a4MvVV1Ng6xEVwXhstXTcrSJLg2LHaib2qwDTpM3n1XUnJSxG7l
ohPCrHYgKMEQAXu51IZwkSJo5ngZgm7VD6/1eXQftIFdgMaKpoEg7KYwhDrZnuMEaHXOhlxTp4Kl
j7YuLtdFinq7YDSuNq/+C61HlGrQvJSUFZqDR0ovCroN64s6LsJQIo9Pc5gf1ZvguFkuSg7C2apT
7o5x2Gh4yLgh/BRch2vgyh4tXdP5u7fG0fSL4x8j+6iZJt72KmXTtz/9l8HpRM26f95WLJKuC+kr
UP+qlMIN7AOU3QIMEP4chH169XPrvsWlHq6uBl4XahU0mguNwenzICXHwFHMYjPHM9KkSycgBS29
G6wtPPFvmED84M12G8xzia9ivd1WGe8/LKEeRcTLYBDadgboWmlhsKx0yhHg+wtQX61uaMWovk6G
zCjhpsMBpKAy1uZ5/AIBoeXHUnB3Xl67I3NiNtwbQ1zvbMLRERu+ff/KK4EazAQaZ/M3Veop5xF1
bjxj6a4iWE2Mm/uwhruiwEKU8EFTpfpSedBoyMhEFIWxNqNRHih51xj/rrs2zSeFGUedz5wthaZp
RndPVNBfAWqlHkGGfwLjwdZvCfwNt70ineL9GQdSLtZ6FL3gvrM3w5gMCAAPUox2nEBaJ/a1uLnS
E36DrtL1SD95PmjS3BUh4og19zs2VuV6V5qb8ZscY/sK21GQiI2foQG=