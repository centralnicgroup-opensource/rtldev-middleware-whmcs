<?php //0088c
// 
// Except the ISPAPI Registrar Module and the CNIC Migrator Addon, all our WHMCS Modules are licensed using the MIT License below.
// Using these two encrypted Addons is allowed. Any actions in direction of unencrypting / reverse engineering et al to gain knowledge of how these encrypted modules work are disallowed.
// 
// MIT License
// 
// Copyright (c) 2018-2022 CentralNic Group PLC
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzsB6VbEKkB+5q2CsezKR/R2sbtGlDgKxjLg8hbBev8whbPAOvS0idHroX2/cmlP28auGpK9
B8JbEoNof0XqlG0XnYGLLFbMSXtMpOmWYKQ/lUD/CvEoI4pNptEHmp/6TjC57S76TlSa0SPMEDO6
aES59h/cl7nXfXEpei0vfKPGpSNmZBLDgNtVTLxvgrHKrJ5mKnABKySpyhMFekSinz0HyFEPdW2y
s8jmNK1rooRig+34qsENAupCfdk8AxxfQq6huqDS/2tSOI4jqBnvao+2nMsaRN2w6oxk2iDQQkr8
7Rhe9H4Z+4CQsVjqnPdaZuPzVJVIXOL6G+rvkRQorbwB08d1jBTz48W7xlnTbrZfbAPTfgoV2FRU
KwwY3la+VwBAylDdnvMVgFRPpasVKKEfgI4voHq1v5ROnQatT1A2MbYdTwxNId1IB45jVRCSnRky
SvnGpTM+iQoiUlAzTQoHd+1T3qeVMXHExdOfkDep0Ktf67Fzl+BMrkCSuXFWsnn2hb8QB5+aNCMM
UwZzq77ebaSMLlqnBClCEOd+oRhEkmUpE9aQGRtB0eFOZI6n3JGXqK4gGo/MGg1nRIeJgYPi+mV6
nBlLZS5WRvQzYdH43cLVwzA49ZtO68XJp2EyE+5TTzzgfiS58+Sigs9vMdlVkaxz+Lipv2ANOoT3
7jPZyPgAIMsxIm+qScZfXULkM3ALRYnaduDZ3G/lzSIc9D37isgMRzFR7g/Pnw0YWIHMDx1R23NS
MMnbzzw7VmrJtRJAru8LJNEpnipb+2LgUyuXTFV7tTp3fxIlU+K2gWRef4ECib+NUWcETIs238g/
OBeRYaLMeOH94TgkdbmjDmY4Or20XBJvlUGhhPVdV+1+2AcSvafN6wCD8MQ8aPzeePfaXtyAB2YL
3S5MxKu5HImgmrL6CQuI64FMljBaDcrhPYBU3ND8XRbVg4auOTwJR2EKXF0m3rC3dE+9+7Unykq4
cWwNuJcyk1sNNLXeVGXxtmm1ZbqzRRzaQU5Ylb6G8+/cTHm9bW0GtWlVtZF3V4ja6zoGY5Lx/IM1
5vFMzqr2J3seTbWgpkV3+zGJj0P45yDneMLelV3YmiYTpaJJ8ckb3QVBHlmB2Rz294mH9RlQPq/N
GY8E+BBD5Fhqc48Nu5msFsZSm1iIm2UNY14IWrkqlPbSrVOi+rWV0rCvpg1l9r91STS0arisGSF9
+gedfIwKlKZnpreuheqi3Kgh7MhRUTzvhlaukQzCy91uQcOakG4QduvjPdx+soTsvxTRHs6kiWMf
jH9GLgVGS5bMw7i7SguZFHOlC5GrlhG4cjnxcHY6QYpYthsGmNwOSwGcZH8e15blitrYZxHCeYOD
63ekxYiIU5pty6dJ51zAtmWd9MTBoawYk9bKxdSLNcNswamJI9j6mvqubS9Ws3HGNb5CFmwR6PJg
mOltqylGkMSkZS9bGfyQBLN9aKp2yuJ70QKs7sXAAnpf4+c5+2fgf7OK/KEB4WFUHhhdIQmzBR/V
LjTK5SybPNd0gDrAkKslE76wKLiB+67EIr9ZMGowYS7Lu/Z//6DPWD3ijXpIHxwZ303k8Sif66Hv
eH4FI5F0XivZ6Gy8PM6e9/RPaX5UrDW2AonJ58nm5IKd7e0/yyYCWLvvZrWI959O5yTXh7Bt0a1e
YTziSycYaRDfnSRT/I1BzJwr84rjNnw5iPjKfznYx/2qFJMKp5iLW/xbOJX0lBigQs2IZsM6GNAv
79f4+QyQ8yO8zBFXw8BNq9JRTwAeu5CAWBDeox/kNXr5fAYsVS7mteviYdSIxW/kmKXKIIWJEvPK
jMpoZR98dwDF5liw7FxErjy3XnCAZv2eCXc9QYKkmN6DiEQwOKXmeqeN1sVKP1gCHTNS2gUasTeh
5lUbtd2ohfjyUnYQ13sknlUZEjf5MS73Axai0ErURDjksoLBcTX9cYDUB14j9qxz72SZjsZTwMUi
QA9nM+OIIdE0oAuQH1C/ngITRSDsMEsLV3up4GI7VQNBorhtO8iRSGUfLpiuNlOfV4+Um3CBayb+
IcK1UmyicrgJd5R36JYPEccCC3lq/O+OHJf5YC3JR32u8Rx31hrvOGHDMmRQ4zqaE/Q8ge6yuRvC
d8P9tamQ4muRsw14bTRNjKl+LMCR9k5OCCjM82d2xiR0y2XZBIGeKvtrI1A1o9h5mS4Wfeh6aagn
xRXhP2PnpuV4WRW9btH7gxR7wSmoSMfJ3JFZs9FgnZ5uqmYZFdfsrN+dKpGdcxZid0C+2Rm4NKKO
cveQLT6J2j9RRj5I8JeNeqc+QOpzszdtWS38fIZ8sc0K4SGmbdSkBskd4Ef7gxGZyCrQUAT2yRaY
UQsMMbtqszxuDJa2tuVfeHkK9OpjQUNR9lEIeNPfBly/JUw6koN1kGuV5681lotGYtIloU6mcz2U
5wnIUJXO3HFX8RL7Rb3qRVcqXKtfipf8HtYE1etvywsbb82gda3tRRoApG0zCjnAtQ14NycWc5rl
JSBU1nAM2bEpYB58ZmbvNV0t2CR8aNC+8ne4X3N3llyDcccR48TUMHgGrUQGWxZLk3VOnBulZGMk
V9ZYjjhqpDlzPo5uV/ztOmaJBNMHTYQii2qJ1Y89MN2qgtcfHaM/0WYof/Bqylz/BKkEi5cLRcUn
3Ebg5iMPSAkv09Te63ijvtXBY98PTYH+APE7EgIDRXptFKkjap0x3F3AlRjNl9tUtCdfCOabVBqQ
kwe9rvJhjYW9JLZiiXceFgv1W9bs0rWH2Zx1Id833U/LQP+MhBj46xNccq2nHZCBU7vQdaLJhvKE
ZtEnZaC6B+2CJfgCNGSQoGk22RBmLkUw/oNNU4EdHsdNYYxwiSOd5nQxaTUBSvlCdx8bAou7YDJb
pMvewZwii0mYIaXapMLXaISfREjDU7AFZKJhhpG/V/blDAbiHibADEbOgiyHo+eJx1qtVgWPWNyu
8S6bo5rG8WO/zCY6+zjSiW8CLvqRz7tmCJtdC4/YVTfBI8LPvZPLZBqs14BwY3SPYH119ohLO9FT
pvgNb8DPeBJxKIiGmY002leW03PvKJqJlq+lRxMaQGHk1Ywy3oo/355jEL/nuW7W1LyuzgrPg4ZD
JHpvPaHiQgE8Rr0FpimIwcom4Cieu+LdBnvle7dmENZ6siDJlLOX5WUXHKaNmn7khrYrP7S3i60O
Oo1164vzrr/gpSoi+XlFQ3MSY0Y3JBNu3b0e6KnPPvHA2j5lFHYHgredQnbLfWUn0jD2VMiicrvv
2yZ2heOr+WPWzmLwV5oyNe/Q3etliBN9pEgQIg3qrt78LGPuDP1sIL0LC/RbAgkRXgRb5o+EkmX2
9PlmPPtQaotdYgsCAWe05U8FnHLwjhnc14hk6btrsIgXbuDQJkwhQzJm73aXy3Uwyx6lEmvp3UaL
HRvjB+z8YgT710ucObqnq+krTZV5JStkxOHUF/3t8P34PHdqolOAGRSvJtzz8APJ4s7hGZ/cr9cR
udnv1C4IJ+92JmoOwhr9TdX0uSBwCgxPN4hslKIrSJf9MvxJk04sRxJRyKK8ZAvY1cv/h+VIOWh5
cUCTTRY9ANziGF1f+d7kLnHNNtG9EP2q9EIc16CECluvAeSasp+z9DNZxVuB2fdl5EsXwMWeOMoQ
QqwSHBCdZSMbmCd3IMhVjHSXIjf02ji4AK0eLhremEWC6uRs+gNimifRadRSuC8jK7WpaW40PR0N
IjoZGRcF9YGoMiR3arpBpc/RrtMEnc78gd85SuwfpfQoKcS+OHe7s7XbAFGWciRIxUutN4Vhvail
pTNwjSCMJfzrRlUCCGWRrOHWVP5OqDN5vW25uGvSFcfxDwwQkX4nTgQ3yKb4vtTKcBum6udJCyac
Rny+ZWPqn2cdKIlap6ge/IRCMl0xj9f5qkqdvVl5E9MJwbATWRO5eEjhGcuwtp2dSuErSNZ2GrIa
Yljh7xwxa3UEAZjgWihOOX62jFGHQOf5SheZoOfyoAWuHdR2gpM2Dirr+9Yyg5TXvZOdM6ef8KM5
olTTs8T18Ji5M2ewWj3b8WEsmrcCWQZhinr3v4nYloQQnD4FDHsdj55yXQk98gu7THASILx2O77D
6mNLuvjr7GvK+3tVQ3bHDCGIKebGuM//2J4rVJ0IjIPMkMNG/nXhUstu7SusrA7o0sWlRKfUgcOq
LL6Fal8wkJDEcWVwi1Exyu4PT/suCs/HKpjbl9vZB9i09a0BZvLL36durQTc7qX5d7SQoQzYPz8f
Ffu66GVwxHrQ8e+Tal5uwGPsml2VUiyfqtFq6nP/vn3YMO44tJwJ8ymi/xNG3D5m975LSr0bjJwB
LnCFMqUue/hFf5xOPMbnI3qvT89rbv2vI3Qcjak37+/iIsRF3luRfTdxhesRzrGknStEfnI/hSzp
ryITvjA+WuxPHHRTjKHQlohxt78Yyox/Z0cvTn6knMW5f5mG9rBECZWGbfxnfDucHtfbIV/48AQ7
YCfrRtfCOzCLUwD5VwqP67Bz32QyLrDqEUwDfQJE/HdBxEWeMGe7h5DiTwML9s+fP3DSvyJLBIj7
Ojqc45c/zPNeCj6M/+LjWWonIUiuHbFDI+3/yHMCWfaEJmJ1lZQgFakB5zL/AEQi3qrN+Edy6Rx6
LTR/SuwJ37PobgDPcjcAQiJ9lN5mTDE1w3xLpcsDeuADoCy0GbdlaezDrL2pHc+SiQrS0IQJBy5s
OzHKAx7wbxlh7Ev3Pp17w3hDRdNij8e+UWTcSLsmzq4lJVA46M3ep8URL6lCnXJ+mx0EtFYHkoX1
8Zz3yqjiAvDxy0mwqh/ES5GSvrG79CDsFdzYoiqQ73y1RzWQx1lxH8dYcHeuWy6yMPLu3+Q6iZBz
8tQvX9QbahC5Hr6LJU33UDsaPtoNVIGY2tbGNeiPiEIIZ80=