<?php

$extensions['X-CN-ACCEPT-TRUSTEE-TAC'] = 0;
