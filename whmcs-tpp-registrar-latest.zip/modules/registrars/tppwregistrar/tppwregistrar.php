<?php

// phpcs:disable PSR1.Classes.ClassDeclaration.MissingNamespace
// phpcs:disable Squiz.Classes.ValidClassName.NotCamelCaps
// phpcs:disable PSR1.Classes.ClassDeclaration.MultipleClasses
// phpcs:disable PSR1.Methods.CamelCapsMethodName.NotCamelCaps

use Illuminate\Database\Capsule\Manager as DB;
use WHMCS\Domains\DomainLookup\SearchResult as SR;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

class TPPW_API
{
    protected $url;
    protected $params;
    protected $systemEnv;
    protected static $sessionId = false;

    public function __construct($script, $params)
    {
        global $CONFIG;

        $parts = parse_url($CONFIG["SystemURL"]);
        // map to ip manually if translation failed
        if ($parts["host"] === "whmcsdev1.hexonet.net") {
            $host = gethostbyname(TPPW_APIUtils::$API_DEV_HOST);
            if ($host === TPPW_APIUtils::$API_DEV_HOST) {
                $host = TPPW_APIUtils::$API_DEV_IP;
            }
        } else {
            $host = gethostbyname(TPPW_APIUtils::$API_HOST);
            if ($host === TPPW_APIUtils::$API_HOST) {
                $host = TPPW_APIUtils::$API_IP;
            }
        }

        $this->url = "https://" . $host . TPPW_APIUtils::$API_PATH . $script;

        $this->params = $params;

        $parts = parse_url($CONFIG["SystemURL"]);
        $ip = gethostbyname($parts["host"]);
        $this->systemEnv = ($ip === "172.16.237.11") ? "DEV" : "LIVE";
    }

    protected function getPostParams($object, $action)
    {
        return [
            'Object' => $object,
            'Action' => $action
        ];
    }

    protected function execute($postParams, $existingSession = true, $isAvailabilityCheck = false)
    {
        /*if ($isAvailabilityCheck) {
            $tpls = [
                "OK: Minimum=1&Maximum=10",
                "OK: Minimum=-1&Maximum=10",
                "OK: Minimum=1&Maximum=-1",
                "OK: Minimum=-1&Maximum=-1",
                "ERR: 302",
                "ERR: 304, Domain is not available",
                "ERR: 309, Unsupported TLD",
                "ERR: 401, Connection issue",
                "ERR: 100, Missing domain parameter"
            ];
            $response = "";
            foreach($postParams["Domain"] as $domain) {
                $response .= $domain . ": " . $tpls[array_rand($tpls)] . "\n";
            }
            return new TPPW_APIResult($response, $isAvailabilityCheck);
        }*/
        if ($existingSession) {
            if (self::$sessionId === false) {
                $api = new TPPW_AuthAPI($this->params);
                $results = $api->authenticate();

                if (!$results->isSuccess()) {
                    return $results;
                }

                self::$sessionId = $results->getResponse();
            }

            $postParams['SessionID'] = self::$sessionId;
        }

        $postParams = array_merge(TPPW_APIUtils::$API_COMMON_PARAMS, $postParams);
        $postFields = '';

        foreach ($postParams as $key => $values) {
            if (is_array($values)) {
                foreach ($values as $value) {
                    $postFields .= $key . '=' . urlencode($value) . '&';
                }
            } else {
                $postFields .= $key . '=' . urlencode($values) . '&';
            }
        }

        $conn = curl_init();
        if ($conn === false) {
            return new TPPW_APIResult(TPPW_APIUtils::$ERROR_CURL . ": curl_init failed.");
        }

        curl_setopt_array($conn, [
            CURLOPT_URL => $this->url,
            CURLOPT_CONNECTTIMEOUT => $this->systemEnv === "DEV" ? 15 : 5,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => $postFields,
            CURLOPT_HEADER => 0,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT => "WHMCS (TPP Wholesale v" . TPPW_APIUtils::$API_COMMON_PARAMS['Version'] . ")",
            CURLOPT_HTTPHEADER => [
                "Expect:",
                "Content-Type: application/x-www-form-urlencoded", //UTF-8 implied
                "Content-Length: " . strlen($postFields)
            ]
        ]);

        $response = curl_exec($conn);
        $log = [
            "action" => $this->url,
            "environment" => $this->systemEnv,
            "requestParam" => $postParams,
            // hide password, find auth code handling later
            "replace" => [$postParams["Password"]]
        ];

        if ($response === false) {
            $error = curl_error($conn);
            $errorNum = curl_errno($conn);
            $response = TPPW_APIUtils::$ERROR_CURL . ": {$errorNum}, {$error}";
        }

        curl_close($conn);

        tppwregistrar_debugLog(array_merge($log, [
            "response" => $response
        ]));

        return new TPPW_APIResult($response, $isAvailabilityCheck);
    }

    protected function getDomain()
    {
        return $this->params['sld'] . '.' . $this->params['tld'];
    }

    protected function getTLD()
    {
        return $this->params['tld'];
    }

    protected function getClientId()
    {
        return $this->params['userid'];
    }
}

class TPPW_AuthAPI extends TPPW_API
{
    public function __construct($params)
    {
        parent::__construct('auth.pl', $params);
    }

    public function authenticate()
    {
        return $this->execute([
            'AccountNo' => $this->params['AccountNo'],
            'UserId' => $this->params['Login'],
            'Password' => $this->params['Password']
        ], false);
    }
}

class TPPW_QueryAPI extends TPPW_API
{
    private static $domainWhois = false;

    public function __construct($params)
    {
        parent::__construct('query.pl', $params);
    }

    public function checkAvailability($domains) {
        $postParams = $this->getPostParams('Domain', 'Availability');
        $postParams['Domain'] = $domains;
        return $this->execute($postParams, true, true);
    }

    public function domainWhois()
    {
        if (!(self::$domainWhois instanceof TPPW_APIResult)) {
            $postParams = $this->getPostParams('Domain', 'Details');
            $postParams['Domain'] = $this->getDomain();
            self::$domainWhois = $this->execute($postParams);
        }
        return self::$domainWhois;
    }

    public function domainSync($domains = null)
    {
        $postParams = $this->getPostParams('Domain', 'Sync');
        if (!empty($domains)) {
            $postParams['Domain'] = $domains;
        } else {
            $postParams['Domain'] = $this->getDomain();
        }
        return $this->execute($postParams);
    }

    public function domainPassword($domains)
    {
        $postParams = $this->getPostParams('Domain', 'SyncPass');
        $postParams['Domain'] = $domains;
        $postParams['resetIfVirgin'] = "true";
        return $this->execute($postParams);
    }

    public function accountInfo()
    {
        $postParams = $this->getPostParams('Account', 'Details');
        $postParams['ExternalAccountID'] = $this->getClientId();
        return $this->execute($postParams);
    }

    public function orderStatus($workflow = true)
    {
        $postParams = $this->getPostParams('Order', 'OrderStatus');
        if ($workflow) {
            $postParams['OrderID'] = TPPW_APIUtils::getWorkflowID($this->params['domainid']);
            if (is_null($postParams['OrderID'])) {
                return new TPPW_APIResult("ERR: 889");
            }
        } else {
            $postParams['Domain'] = $this->getDomain();
        }
        return $this->execute($postParams);
    }

    public function checkTransferability()
    {
        $postParams = $this->getPostParams('Domain', 'Transfer');
        $postParams['Domain'] = $this->getDomain();
        $postParams['DomainPassword'] = TPPW_APIUtils::getValue($this->params, 'transfersecret', '');
        return $this->execute($postParams);
    }
}

class TPPW_APIUtils
{
    public static $BRAND_NAME = 'TPP Wholesale';

    public static $MODULE_NAME = 'tppwregistrar';

    public static $API_IP = '114.141.204.99';

    public static $API_HOST = 'theconsole.tppwholesale.com.au';

    public static $API_DEV_IP = '13.238.79.109';

    public static $API_DEV_HOST = 'theconsole.dev.tppwholesale.com.au';

    public static $API_PATH = '/api/';

    public static $URL_SUPPORT = 'http://www.tppwholesale.com.au/support/category/getting-started/whmcs';

    public static $URL_SIGNUP = 'http://www.tppwholesale.com.au/sign-up.php';

    public static $API_COMMON_PARAMS = [
        'Requester' => 'WHMCS',
        'Version' => '3.1.1', // also update version number in whmcs.json
        'Type' => 'Domains'
    ];

    public static $ERROR_UNKNOWN = 'Unknown error occurred';

    public static $ERROR_CURL = 'CURL Communication failed';

    public static $ERROR_CODES = [
        '100' => 'Missing parameters',
        '102' => 'Authentication failed',
        '105' => 'Request is coming from incorrect IP address',
        '202' => 'Invalid API Type',
        '203' => 'API call has not been implemented yet',
        '301' => 'Invalid order ID',
        '302' => 'Domain name is either invalid or not supplied',
        '303' => 'Domain prices are not setted up',
        '304' => 'Domain registration failed',
        '305' => 'Domain renewal failed',
        '306' => 'Domain transfer failed',
        '307' => 'Incorrect auth code provided',
        '309' => 'Invalid domain extension',
        '311' => 'Domain does not exist in your reseller account',
        '312' => 'Invalid username/password',
        '313' => 'Account does not exist in your reseller profile',
        '401' => 'Failed to connect to registry, please retry',
        '500' => 'Prepaid account does not have enough funds to cover the cost of this order',
        '501' => 'Invalid credit card type',
        '502' => 'Invalid credit card number',
        '503' => 'Invalid credit card expiry date',
        '505' => 'Credit card transaction failed',
        '600' => 'Failed to create/update contact',
        '601' => 'Failed to create order',
        '602' => 'Invalid hosts supplied',
        '603' => 'Invalid eligibility fields supplied',
        '604' => 'Invalid IP Address',
        '610' => 'Failed to connect to registry, please retry',
        '611' => 'Domain renewal/transfer failed',
        '612' => 'Locking is not available for this domain',
        '614' => 'Failed to lock/unlock domain',
        '615' => 'Domain delegation failed',
        '700' => 'Invalid Product',
        '701' => 'Domain already exists',
        '888' => 'Order is still being processed. Current Status',
        '889' => 'No OrderID for this domain name was found'
    ];

    public static $CONTACT_TYPES = [
        'Owner' => 'Registrant',
        'Administration' => 'Admin',
        'Technical' => 'Tech',
        'Billing' => 'Billing'
    ];

    public static $CHECK_PERIOD_BEFORE_XFER = [
        'au',
        'com.au',
        'net.au',
        'org.au',
        'asn.au',
        'id.au'
    ];

    public static $CONTACT_FIELDS = [
        'FirstName' => 'firstname',
        'LastName' => 'lastname',
        'Address1' => 'address1',
        'Address2' => 'address2',
        'City' => 'city',
        'Region' => 'state',
        'PostalCode' => 'postcode',
        'CountryCode' => 'country',
        'Email' => 'email',
        'PhoneNumber' => 'phonenumber'
    ];

    public static $TRANSFORM_CONTACT_FIELDS = [
        'First Name' => 'FirstName',
        'Last Name' => 'LastName',
        'Address 1' => 'Address1',
        'Address 2' => 'Address2',
        'Postcode' => 'PostalCode',
        'Country' => 'CountryCode',
        'Phone Number' => 'PhoneNumber',
        'Organisation Name' => 'OrganisationName',
        'Email Address' => 'Email'
    ];

    public static $ASIA_LEGAL_TYPES = [
        'naturalPerson' => 'naturalPerson',
        'corporation' => 'corporation',
        'cooperative' => 'cooperative',
        'partnership' => 'partnership',
        'government' => 'government',
        'politicalParty' => 'politicalParty',
        'society' => 'society',
        'institution' => 'institution'
    ];

    public static $ASIA_IDENTITY_FORMS = [
        'passport' => 'passport',
        'politicalPartyRegistry' => 'politicalPartyRegistry',
        'societyRegistry' => 'societiesRegistry',
        'legislation' => 'legislation',
        'certificate' => 'certificate'
    ];

    public static $ELIGIBILITY_ID_TYPES = [
        'ACN' => 1,
        'ACT BN' => 2,
        'NSW BN' => 3,
        'NT BN' => 4,
        'QLD BN' => 5,
        'SA BN' => 6,
        'TAS BN' => 7,
        'VIC BN' => 8,
        'WA BN' => 9,
        'Trademark' => 10,
        'Other' => 11,
        'ABN' => 12,

        'Australian Company Number (ACN)' => 1,
        'ACT Business Number' => 2,
        'NSW Business Number' => 3,
        'NT Business Number' => 4,
        'QLD Business Number' => 5,
        'SA Business Number' => 6,
        'TAS Business Number' => 7,
        'VIC Business Number' => 8,
        'WA Business Number' => 9,
        'Trademark (TM)' => 10,
        'Other - Used to record an Incorporated Association number' => 11,
        'Australian Business Number (ABN)' => 12,
        'Business Registration Number' => 11
    ];

    public static $ELIGIBILITY_TYPES = [
        'Charity' => 1,
        'Citizen/Resident' => 2,
        'Club' => 3,
        'Commercial Statutory Body' => 4,
        'Company' => 5,
        'Incorporated Association' => 6,
        'Industry Body' => 8,
        'Non-profit Organisation' => 9,
        'Other' => 10,
        'Partnership' => 11,
        'Pending TM Owner' => 12,
        'Political Party' => 13,
        'Registered Business' => 14,
        'Religious/Church Group' => 15,
        'Sole Trader' => 16,
        'Trade Union' => 17,
        'Trademark Owner' => 18,
        'Child Care Centre' => 19,
        'Government School' => 20,
        'Higher Education Institution' => 21,
        'National Body' => 22,
        'Non-Government School' => 23,
        'Pre-school' => 24,
        'Research Organisation' => 25,
        'Training Organisation' => 26
    ];

    public static $ELIGIBILITY_REASONS = [
        'Domain name is an Exact Match Abbreviation or Acronym of your Entity or Trading Name.' => 1,
        'Close and substantial connection between the domain name and the operations of your Entity.' => 2
    ];

    public static function getValue($array, $key, $defaultValue)
    {
        return array_key_exists($key, $array) ? $array[$key] : $defaultValue;
    }

    public static function getValueConverted($array, $key, $valueMap, $defaultValue = false)
    {
        $value = TPPW_APIUtils::getValue($array, $key, false);
        return $value !== false ? TPPW_APIUtils::getValue($valueMap, $value, $defaultValue) : $defaultValue;
    }

    /**
     * Get Workflow ID
     * @param int $domainID ID of the domain in WHMCS
     * @return null|string
     */
    public static function getWorkflowID($domainID)
    {
        return DB::table("tbldomainsadditionalfields")
            ->where('domainid', $domainID)
            ->where('name', 'TPPOrderID')
            ->value("value");
    }

    /**
     * Set Workflow ID in DB
     * @param int $domainID id of the domain in WHMCS
     * @param string $wfID workflow id
     * @return boolean
     */
    public static function setWorkflowID($domainID, $wfID)
    {
        if (is_null(TPPW_APIUtils::getWorkflowID($domainID))) {
            return DB::table("tbldomainsadditionalfields")
                ->insert([
                    "domainid" => $domainID,
                    "name" => "TPPOrderID",
                    "value" => $wfID
                ]);
        }
        return (bool)DB::table("tbldomainsadditionalfields")
            ->where("domainid", $domainID)
            ->where("name", "TPPOrderID")
            ->update([
                "value" => $wfID
            ]);
    }
    
    /**
     * Flatten multidimensional array recursively
     *
     * @param array $array
     * @param string $parentKey
     * @return string
     */
    public static function flattenArray($array, $parentKey = "") {
        $return = "";
        // Iterate through each key-value pair
        foreach ($array as $key => $value) {
            // Check if value is an array
            if (is_array($value)) {
                // Recursively call function with nested array
                // Use current key as parent key if $parentKey is empty
                $return .= self::flattenArray($value, $parentKey ?: $key);
            } else {
                // If value is not an array
                // Use parent key as prefix if not empty
                // Otherwise, use current key as prefix
                $return .= (empty($parentKey) ? $key : $parentKey) . "=" . $value . "\n";
            }
        }
        
        return $return;
    }
}

class TPPW_OrderAPI extends TPPW_API
{
    public function __construct($params)
    {
        parent::__construct('order.pl', $params);
    }

    private function saveWorkflowId(TPPW_APIResult $result)
    {
        if ($result->isSuccess()) {
            TPPW_APIUtils::setWorkflowID($this->params['domainid'], $result->getResponse());
        }
        return $result;
    }

    public function domainRegister()
    {
        $contactIds = $this->createContacts();

        if ($contactIds instanceof TPPW_APIResult) {
            return $contactIds;
        }

        $postParams = $this->getPostParams('Domain', 'Create');
        $postParams['Domain'] = $this->getDomain();
        $postParams['Period'] = $this->getPeriod();
        $postParams['Host'] = $this->getNameServers();
        $postParams = array_merge($postParams, $this->getDomainCredentials());
        $postParams = array_merge($postParams, $contactIds);
        $postParams = array_merge($postParams, $this->getEligibilityDetails());
        return $this->saveWorkflowId($this->execute($postParams));
    }

    public function domainRenewal()
    {
        $postParams = $this->getPostParams('Domain', 'Renewal');
        $postParams['Domain'] = $this->getDomain();
        $postParams['Period'] = $this->getPeriod();
        return $this->saveWorkflowId($this->execute($postParams));
    }

    public function domainTransfer()
    {
        $postParams = $this->getPostParams('Domain', 'TransferRequest');
        $postParams['Domain'] = $this->getDomain();
        $postParams['Period'] = $this->getPeriod();

        if (in_array($this->params['tld'], TPPW_APIUtils::$CHECK_PERIOD_BEFORE_XFER)) {
            $queryAPI = new TPPW_QueryAPI($this->params);
            $queryResult = $queryAPI->checkTransferability();
            if ($queryResult->isSuccess()) {
                $postParams['Period'] = $queryResult->get("Maximum");
            } else {
                return $queryResult;
            }
        }

        $contactIds = $this->createContacts();

        if ($contactIds instanceof TPPW_APIResult) {
            return $contactIds;
        }

        $postParams['DomainPassword'] = TPPW_APIUtils::getValue($this->params, 'transfersecret', '');
        $postParams = array_merge($postParams, $this->getDomainCredentials());
        $postParams = array_merge($postParams, $contactIds);
        return $this->saveWorkflowId($this->execute($postParams));
    }

    public function domainDelegation()
    {
        $postParams = $this->getPostParams('Domain', 'UpdateHosts');
        $postParams['Domain'] = $this->getDomain();
        $postParams['AddHost'] = $this->getNameServers();
        $postParams['RemoveHost'] = 'ALL';
        return $this->execute($postParams);
    }

    public function domainLock()
    {
        $postParams = $this->getPostParams('Domain', 'UpdateDomainLock');
        $postParams['Domain'] = $this->getDomain();
        $lockEnabled = $this->params['lockenabled'];
        $postParams['DomainLock'] = (!$lockEnabled || $lockEnabled == 'unlocked') ? 'Unlock' : 'Lock';
        return $this->execute($postParams);
    }

    public function hostCreate()
    {
        $postParams = $this->getPostParams('Domain', 'CreateNameServer');
        $postParams['Domain'] = $this->getDomain();
        $postParams['NameServerPrefix'] = $this->getHost();
        $postParams['NameServerIP'] = $this->getHostIPs('ipaddress');
        return $this->execute($postParams);
    }

    public function hostUpdate()
    {
        $postParams = $this->getPostParams('Domain', 'ChangeNameServer');
        $postParams['Domain'] = $this->getDomain();
        $postParams['NameServerPrefix'] = $this->getHost();
        $postParams['NameServerIP'] = $this->getHostIPs('newipaddress');
        return $this->execute($postParams);
    }

    public function hostRemove()
    {
        $postParams = $this->getPostParams('Domain', 'DeleteNameServer');
        $postParams['Domain'] = $this->getDomain();
        $postParams['NameServerPrefix'] = $this->getHost();
        return $this->execute($postParams);
    }

    public function contactsUpdate()
    {
        $contactIds = $this->createContacts(false);

        if ($contactIds instanceof TPPW_APIResult) {
            return $contactIds;
        }

        $postParams = $this->getPostParams('Domain', 'UpdateContacts');
        $postParams['Domain'] = $this->getDomain();
        $postParams = array_merge($postParams, $contactIds);
        return $this->execute($postParams);
    }

    private function createContacts($all = true)
    {
        $contacts = TPPW_APIUtils::getValue($this->params, 'contactdetails', false);

        if ($contacts === false) {
            $contacts = [
                'Registrant' => $this->getContact(),
                'Admin' => $this->getContact('admin')
            ];
        }

        $contactIds = [];
        $defaultContactId = false;

        foreach (TPPW_APIUtils::$CONTACT_TYPES as $apiType => $moduleType) {
            $contact = TPPW_APIUtils::getValue($contacts, $moduleType, false);

            if ($contact !== false) {
                if (array_key_exists("First Name", $contact)) {
                    foreach (TPPW_APIUtils::$TRANSFORM_CONTACT_FIELDS as $wrongKeyName => $correctKeyName) {
                        $contact[$correctKeyName] = $contact[$wrongKeyName];
                        unset($contact[$wrongKeyName]);
                    }
                }

                $results = $this->createContact($contact);

                if (!$results->isSuccess()) {
                    return $results;
                }
                $key = $apiType . 'ContactID';
                $contactId = $results->getResponse();
                $contactIds[$key] = $contactId;

                if ($defaultContactId === false) {
                    $defaultContactId = $contactId;
                }
            }
        }

        if ($all && $defaultContactId !== false) {
            foreach (array_keys(TPPW_APIUtils::$CONTACT_TYPES) as $apiType) {
                $key = $apiType . 'ContactID';
                if (!array_key_exists($key, $contactIds)) {
                    $contactIds[$key] = $defaultContactId;
                }
            }
        }

        return $contactIds;
    }

    private function createContact($contact)
    {
        $postParams = $this->getPostParams('Contact', 'Create');
        $postParams = array_merge($postParams, $contact);
        return $this->execute($postParams);
    }

    private function getContact($type = '')
    {
        $contact = [];

        foreach (TPPW_APIUtils::$CONTACT_FIELDS as $apiField => $moduleField) {
            $key = $type . $moduleField;
            $value = TPPW_APIUtils::getValue($this->params, $key, '');
            $contact[$apiField] = $value;
        }

        return $contact;
    }

    private function getProductId()
    {
        return TPPW_APIUtils::getValue($this->params, 'ConsoleProductId', '');
    }

    private function getPeriod()
    {
        return TPPW_APIUtils::getValue($this->params, 'regperiod', '');
    }

    private function getHost()
    {
        return str_replace("." . $this->getDomain(), "", TPPW_APIUtils::getValue($this->params, 'nameserver', ''));
    }

    private function getHostIPs($key)
    {
        $ips = TPPW_APIUtils::getValue($this->params, $key, '');
        return preg_split('/\s*,\s*/', $ips);
    }

    private function getNameServers()
    {
        $nameServers = [];
        $keys = ['ns1', 'ns2', 'ns3', 'ns4', 'ns5', 'ns6', 'ns7', 'ns8', 'ns9'];

        foreach ($keys as $key) {
            $value = TPPW_APIUtils::getValue($this->params, $key, false);

            if ($value !== false) {
                $nameServers[] = $value;
            }
        }

        return $nameServers;
    }

    private function getEligibilityDetails()
    {
        $eligibilityForm = TPPW_APIUtils::getValue($this->params, 'additionalfields', false);

        if (!$eligibilityForm) {
            return [];
        }

        if (substr($this->getTLD(), -3) == ".au" || $this->getTLD() == "au") {
            $registrantName = TPPW_APIUtils::getValue($eligibilityForm, 'Registrant Name', '');
            $registrantId = TPPW_APIUtils::getValue($eligibilityForm, 'Registrant ID', '');
            $registrantIdType = TPPW_APIUtils::getValueConverted($eligibilityForm, 'Registrant ID Type', TPPW_APIUtils::$ELIGIBILITY_ID_TYPES, '');

            $eligibilityName = TPPW_APIUtils::getValue($eligibilityForm, 'Eligibility Name', '');

            $eligibilityId = TPPW_APIUtils::getValue($eligibilityForm, 'Eligibility ID', '');
            $eligibilityIdType = TPPW_APIUtils::getValueConverted($eligibilityForm, 'Eligibility ID Type', TPPW_APIUtils::$ELIGIBILITY_ID_TYPES, '');
            $eligibilityType = TPPW_APIUtils::getValueConverted($eligibilityForm, 'Eligibility Type', TPPW_APIUtils::$ELIGIBILITY_TYPES, '');
            $eligibilityReason = TPPW_APIUtils::getValueConverted($eligibilityForm, 'Eligibility Reason', TPPW_APIUtils::$ELIGIBILITY_REASONS, '');


            if (!empty($registrantIdType) && empty($eligibilityIdType)) {
                $eligibilityIdType = $registrantIdType;

                $eligibilityType = TPPW_APIUtils::$ELIGIBILITY_TYPES['Company'];
                $eligibilityId = empty($eligibilityId) ? $registrantId : $eligibilityId;
            }

            return [
                'RegistrantName' => $registrantName,
                'EligibilityName' => $eligibilityName,
                'EligibilityID' => $eligibilityId,
                'EligibilityIDType' => $eligibilityIdType,
                'EligibilityType' => $eligibilityType,
                'EligibilityReason' => $eligibilityReason
            ];
        }

        if (strpos($this->getTLD(), "asia") !== false) {
            $country = $this->params['country'];
            $legalType = TPPW_APIUtils::getValueConverted($eligibilityForm, 'Legal Type', TPPW_APIUtils::$ASIA_LEGAL_TYPES, '');
            $identityForm = TPPW_APIUtils::getValueConverted($eligibilityForm, 'Identity Form', TPPW_APIUtils::$ASIA_IDENTITY_FORMS, 'other');
            $identityNumber = TPPW_APIUtils::getValue($eligibilityForm, 'Identity Number', '');

            if ($identityForm == 'other') {
                $otherIdentityForm = TPPW_APIUtils::getValue($eligibilityForm, 'Identity Form', '');
            }

            return [
                'Country' => $country,
                'LegalType' => $legalType,
                'IdentityForm' => $identityForm,
                'IdentityNumber' => $identityNumber,
                'OtherIdentityForm' => $otherIdentityForm
            ];
        }

        return [];
    }

    private function getDomainCredentials()
    {
        $accountSetting = TPPW_APIUtils::getValue($this->params, 'DefaultAccount', '');

        $accountSetting = strtoupper($accountSetting);
        $accountId = null;
        $accountOption = 'CONSOLE';

        switch ($accountSetting) {
            case null:
            case '':
                $accountOption = 'EXTERNAL';
                $accountId = $this->getClientId();
                break;

            case 'DEFAULT':
                $accountOption = 'DEFAULT';
                break;

            default:
                $accountId = $accountSetting;
                break;
        }

        return [
            'AccountOption' => $accountOption,
            'AccountID' => $accountId
        ];
    }
}


class TPPW_APIResult
{
    private $response;
    private $success = false;
    private $params = [];
    private $error;
    private $errorCode;

    public function __construct($response, $isAvailabilityCheck = false)
    {
        if (str_starts_with($response, TPPW_APIUtils::$ERROR_CURL)) {
            $this->error = $response;
            return $this;
        }
        if ($isAvailabilityCheck && str_starts_with($response, "ERR:")) {
            $this->error = $response;
            return $this;
        }

        $this->response = $response;

        // availability check special handling
        if ($isAvailabilityCheck) {
            $this->success = true;
            return;
        }

        // other request's response
        $responseTemp = preg_split('/\s*:\s*/', $response);
        $index = array_search('OK', $responseTemp);

        if ($index !== false) {
            $this->success = true;

            $responseTemp = array_splice($responseTemp, $index + 1);
            $response = trim(implode(':', $responseTemp));
            $this->response = $response;

            $lines = explode("\n", $response);

            foreach ($lines as $line) {
                $index = strpos($line, '=');
                if ($index !== false) {
                    $key = trim(substr($line, 0, $index));
                    $value = trim(substr($line, $index + 1));
                    $this->params[$key][] = $value;
                }
            }
        } else {
            $index = array_search('ERR', $responseTemp);

            if ($index !== false) {
                $responseTemp = array_splice($responseTemp, $index + 1);
                $response = implode(':', $responseTemp);
                $this->error = TPPW_APIUtils::$ERROR_UNKNOWN . ': ' . $response;

                if ($response && preg_match('/^\d+/', $response)) {
                    $errorTemp = preg_split('/\s*,\s*/', $response);
                    $errorCode = $errorTemp[0];
                    $this->errorCode = $errorCode;
                    $this->error = "[$errorCode] ";
                    $this->error .= TPPW_APIUtils::getValue(TPPW_APIUtils::$ERROR_CODES, $errorCode, TPPW_APIUtils::$ERROR_UNKNOWN);
                    $this->error .= ': ' . implode(', ', array_slice($errorTemp, 1));
                }
            }
        }
        if (!$this->success && !$this->error) {
            $this->error = TPPW_APIUtils::$ERROR_UNKNOWN;
        }
    }

    public function getResponse()
    {
        return $this->response;
    }

    public function isSuccess()
    {
        return $this->success;
    }

    public function getParams($prefix)
    {
        $params = [];
        $keys = array_keys($this->params);

        foreach ($keys as $key) {
            if (preg_match('/^' . $prefix . '/', $key)) {
                $value = $this->get($key);
                $key = substr($key, strlen($prefix));
                $params[$key] = $value;
            }
        }

        return $params;
    }

    public function get($key)
    {
        $value = $this->getArray($key);
        return empty($value) ? '' : $value[0];
    }

    public function getArray($key)
    {
        return TPPW_APIUtils::getValue($this->params, $key, []);
    }

    public function getModuleResults()
    {
        return $this->success ? '' : $this->getModuleError();
    }

    public function getModuleError()
    {
        return ['error' => $this->error];
    }

    public function getModuleErrorCode()
    {
        return (int) $this->errorCode;
    }
}

/**
 * Undocumented function to validate user inputs in getConfigArray's form - only invoked if configuration settings are submitted
 * @link https://www.whmcs.com/members/viewticket.php?tid=ESD-183344&c=wjZ1LjOs #ESD-183344
 * @param array $params common module parameters
 * @throws Exception if estabilishing the API connection failed
 */
function tppwregistrar_config_validate($params)
{
    global $CONFIG;
    $parts = parse_url($CONFIG["SystemURL"]);
    $ip = gethostbyname($parts["host"]);
    $system = ($ip === "172.16.237.11") ? "DEV" : "LIVE";

    $api = new TPPW_AuthAPI($params);
    $result = $api->authenticate();
    $authOk = $result->isSuccess();

    if ($authOk === false) {
        $apierror = $result->getModuleError();
        $error = $apierror["error"];
        $url = TPPW_APIUtils::$URL_SUPPORT;

        throw new \Exception(
            <<<HTML
                <h2>Connecting to the {$system} Environment failed. <small>({$error})</small></h2>
                <p><b>Need Help?</b> For assistance configuring WHMCS at TPP Wholesale, please see this <a target="_blank" href="{$url}">support article</a>.
HTML
        );
    } else {
        unset($_SESSION["ConfigurationWarning"]);
    }
}

function tppwregistrar_getConfigArray($params)
{
    global $CONFIG;
    $parts = parse_url($CONFIG["SystemURL"]);
    $ip = gethostbyname($parts["host"]);

    return [
        'FriendlyName' => [
            'Type' => 'System',
            'Value' => "\0 TPP Wholesale v" . TPPW_APIUtils::$API_COMMON_PARAMS['Version']
        ],

        'Description' => [
            'Type' => 'System',
            'Value' => 'Get a free account <a href="' . TPPW_APIUtils::$URL_SIGNUP . '" target="_blank">here</a>'
        ],

        'AccountNo' => [
            'Type' => 'text',
            'Size' => '20',
            'Description' => 'Enter your ' . TPPW_APIUtils::$BRAND_NAME . ' API Account Number'
        ],

        'Login' => [
            'Type' => 'text',
            'Size' => '20',
            'Description' => 'Enter your ' . TPPW_APIUtils::$BRAND_NAME . ' API Login'
        ],

        'Password' => [
            'Type' => 'password',
            'Size' => '20',
            'Description' => 'Enter your ' . TPPW_APIUtils::$BRAND_NAME . ' API Password'
        ],

        'DefaultAccount' => [
            'Type' => 'text',
            'Size' => '20',
            'Description' => '<ul><li>Leave this field blank if you are happy for WHMCS to create client accounts on the TPP Wholesale systems and group each client\'s domain registrations within them. </li><li>If you\'d prefer to have all the domain names simply grouped in one account on the TPP Wholesale systems, enter that Account Reference here.</li></ul>'
        ],

        "" => [
            "Type" => "system",
            "Description" => (<<<HTML
                <div class="alert alert-info" style="font-size:medium;margin-bottom:0px;">
                    Click on Save for testing your connection to the configured TPP Wholesale Backend System. Only in case it fails, an error will be shown.<br/><b>Your Server IP Address</b>: {$ip}
                </div>
HTML
            )
        ]

    ];
}

function tppwregistrar_GetNameservers($params)
{
    $api = new TPPW_QueryAPI($params);
    $results = $api->domainWhois();

    if (!$results->isSuccess()) {
        return $results->getModuleError();
    }

    $nameServers = $results->getArray('Nameserver');
    $ns = [];
    $count = 1;

    foreach ($nameServers as $nameServer) {
        $ns['ns' . $count++] = $nameServer;
    }

    return $ns;
}

function tppwregistrar_SaveNameservers($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->domainDelegation();
    return $results->getModuleResults();
}

function tppwregistrar_GetRegistrarLock($params)
{
    $api = new TPPW_QueryAPI($params);
    $results = $api->domainWhois();

    if (!$results->isSuccess()) {
        return $results->getModuleError();
    }

    $lockStatus = $results->get('LockStatus');
    return $lockStatus == '2' ? 'locked' : 'unlocked';
}

function tppwregistrar_SaveRegistrarLock($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->domainLock();
    return $results->getModuleResults();
}

function tppwregistrar_RegisterDomain($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->domainRegister();
    return $results->getModuleResults();
}

function tppwregistrar_TransferDomain($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->domainTransfer();
    return $results->getModuleResults();
}

function tppwregistrar_RenewDomain($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->domainRenewal();
    return $results->getModuleResults();
}

function tppwregistrar_GetContactDetails($params)
{
    $api = new TPPW_QueryAPI($params);
    $results = $api->domainWhois();

    if (!$results->isSuccess()) {
        return $results->getModuleError();
    }

    $contacts = [];

    foreach (TPPW_APIUtils::$CONTACT_TYPES as $apiPrefix => $modulePrefix) {
        $contact = $results->getParams($apiPrefix . '-');
        $contacts[$modulePrefix] = $contact;
    }

    return $contacts;
}

function tppwregistrar_SaveContactDetails($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->contactsUpdate();
    return $results->getModuleResults();
}

function tppwregistrar_GetEPPCode($params)
{
    $api = new TPPW_QueryAPI($params);
    $results = $api->domainWhois();

    if (!$results->isSuccess()) {
        return $results->getModuleError();
    }

    $domainPassword = $results->get('DomainPassword');
    return ['eppcode' => $domainPassword];
}

function tppwregistrar_TransferSync($params)
{
    $api = new TPPW_QueryAPI($params);
    $results = $api->domainSync();

    if ($results->isSuccess()) {
        return [
            "expirydate" => $results->get("ExpiryDate"),
            "active" => true
        ];
    }

    if ($results->getModuleErrorCode() === 311) {
        $orderStatus = $api->orderStatus();
        if ($orderStatus->isSuccess()) {
            if (stripos($orderStatus->getResponse(), "reject") !== false) {
                return [
                    "failed" => true,
                    "reason" => $orderStatus->getResponse()
                ];
            }
        }
        return [];
    }

    return $results->getModuleError();
}

function tppwregistrar_Sync($params)
{
    $api = new TPPW_QueryAPI($params);
    $results = $api->domainSync();

    if (!$results->isSuccess()) {
        return $results->getModuleError();
    }

    $expiry = $results->get("ExpiryDate");
    date_default_timezone_set(@date_default_timezone_get());
    $expiryEpoch = strtotime($expiry);
    if ($expiryEpoch !== false) {
        if ($expiryEpoch > time()) {
            return [
                "expirydate" => $expiry,
                "active" => true
            ];
        }
        return [
            "expirydate" => $expiry,
            "expired" => true
        ];
    }

    return []; // no changes
}

function tppwregistrar_checkOrder($params)
{
    $api = new TPPW_QueryAPI($params);
    $result = $api->orderStatus();
    if (!$result->isSuccess()) {
        return $result->getModuleError();
    }

    $data = $result->getResponse();
    if ($data === 'Complete') {
        return [];
    }

    $res = new TPPW_APIResult("ERR: 888, $data\r\n");
    return $res->getModuleResults();
}

function tppwregistrar_AdminCustomButtonArray($params)
{
    return [
        "Check Order Progress" => "checkOrder"
    ];
}

function tppwregistrar_RegisterNameserver($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->hostCreate();
    return $results->getModuleResults();
}

function tppwregistrar_ModifyNameserver($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->hostUpdate();
    return $results->getModuleResults();
}

function tppwregistrar_DeleteNameserver($params)
{
    $api = new TPPW_OrderAPI($params);
    $results = $api->hostRemove();
    return $results->getModuleResults();
}


function tppwregistrar_debugLog($log)
{
    // $module The name of the module
    // $action The name of the action being performed
    // $requestString The input parameters for the API call
    // $responseData The response data from the API call
    // $processedData The resulting data after any post processing (eg. json decode, xml decode, etc...)
    // $replaceVars An array of strings for replacement
    $endpoint = preg_replace("/^http(s)?:\/\/[^\/]+\//", "", $log["action"]);
    $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS | DEBUG_BACKTRACE_PROVIDE_OBJECT);
    $action = $trace[0];
    do {
        $t = array_shift($trace);
        if ($t !== null && preg_match("/^tppwregistrar_(.+)$/i", $t["function"], $m) && $m[1] !== "call") {
            $action = $m[1];
        }
    } while (!empty($trace));

    $requestStr = TPPW_APIUtils::flattenArray($log["requestParam"]);

    $request = $endpoint . " @ " . $log["environment"] . " Environment \n\n" . $requestStr;

    logModuleCall(
        TPPW_APIUtils::$MODULE_NAME,
        $action,
        $request,
        $log["response"],
        "",
        $log["replace"]
    );
}

function tppwregistrar_CheckAvailability($params)
{
    if (!empty($params["domains"])) {
        $tocheck = $params["domains"];
    } else {
        $label = strtolower(
            ($params["isIdnDomain"] && !empty($params["punyCodeSearchTerm"])) ?
                $params["punyCodeSearchTerm"] :
                $params["searchTerm"]
        );
        // for common availability checks (we get just a search label and list of tlds)
        // remove duplicates and empty ones
        $tocheck = array_values(array_unique(array_filter($params["tldsToInclude"])));
        $tocheck = array_map(function ($tld) use ($label) {
            return $label  . "." . ltrim($tld, ".");
        }, $tocheck);
    }

    $api = new TPPW_QueryAPI($params);

    // build the result list for WHMCS
    // chunk the check list, only ~250 are allowed at once
    $maxGroupSize = 25;
    $results = new \WHMCS\Domains\DomainLookup\ResultsList();

    foreach (array_chunk($tocheck, $maxGroupSize) as $domains) {
        $result = $api->checkAvailability($domains);
        if (!$result->isSuccess()) {
            $err = $result->getModuleError();
            throw new Exception($err["error"]);
        }
        $data = explode("\n", $result->getResponse());

        // The domains returned are in the same sort order as
        // supplied in the 'Domain' data parameter/s.
        foreach ($domains as $idx => $domain) {
            list($sld, $tld) = explode(".", $domain, 2);
            $row = $data[$idx];

            $sr = new SR($sld, $tld);
            $sr->setStatus($sr::STATUS_REGISTERED);

            if (empty($sld) || empty($tld) || !isset($row)) {
                $results->append($sr);
                continue;
            }

            // strip prefix "(Domain): "
            list($tmp, $row) = explode(" ", $row, 2);

            // Available (or TLD not enabled)
            if ((bool)preg_match("/^OK: /", $row)) {
                // e.g. OK: Minimum=1&Maximum=10
                // If Minimum=-1 or Maximum=-1 is returned,
                // it means domain registration prices for the TLD are
                // disabled for the reseller account.
                // They will need to be enabled in the reseller portal.
                $sr->setStatus($sr::STATUS_NOT_REGISTERED);
                if ((bool)preg_match("/(^Minimum=-1|Maximum=-1$)/i", $row)) {
                    $sr->setStatus($sr::STATUS_UNKNOWN); // not supported -> whois lookup
                }
                $results->append($sr);
                continue;
            }

            // Error Cases
            // (Domain): ERR: (Error Code)(,Error Description)?
            if ((bool)preg_match("/^ERR: (\d+)/", $row, $m)) {
                switch($m[1]) { // Error Code
                    case "304": // Domain is not available
                        $sr->setStatus($sr::STATUS_REGISTERED);
                        break;
                    case "309": // TLD is not supported
                        $sr->setStatus($sr::STATUS_TLD_NOT_SUPPORTED);
                        break;
                    default:
                        // 100 Missing Domain parameter
                        // 401 Registry connection failed
                        // anything not documented ...
                        $sr->setStatus($sr::STATUS_UNKNOWN);
                        break;
                }
                $results->append($sr);
                continue;
            }
            $results->append($sr);
        }
    }
    return $results;
}

function tppwregistrar_GetDomainSuggestions($params)
{
    return new \WHMCS\Domains\DomainLookup\ResultsList();
}
