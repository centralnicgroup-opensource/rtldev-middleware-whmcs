# WHMCS "ISPAPI DNS" Registrar Module #

[![semantic-release](https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg)](https://github.com/semantic-release/semantic-release)
[![Build Status](https://github.com/hexonet/whmcs-ispapi-registrardns/workflows/Release/badge.svg?branch=master)](https://github.com/hexonet/whmcs-ispapi-registrardns/workflows/Release/badge.svg?branch=master)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![PRs welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/hexonet/whmcs-ispapi-registrardns/blob/master/CONTRIBUTING.md)

This Repository covers a special WHMCS Registrar Module of HEXONET. It allows to register and manage DNSZones for Domains that are not registered and managed over HEXONET.
It internally uses the [WHMCS "ISPAPI" Registrar Module](https://github.com/hexonet/whmcs-ispapi-registrar).

## Resources ##

Read the following to get more information about Installation, Configuration and so on:

* [Usage Guide](https://github.com/hexonet/whmcs-ispapi-registrardns/wiki/Usage-Guide)
* [Release Notes](https://github.com/hexonet/whmcs-ispapi-registrardns/releases)
* [Development Guide](https://github.com/hexonet/whmcs-ispapi-registrardns/wiki/Development-Guide)

**If you have any issue related to this module, please take a look at the FAQs [here](https://github.com/hexonet/whmcs-ispapi-registrardns/wiki/FAQs). If you can't find help in the FAQs feel free to contact our support team.**

## Latest Version ##

Download the ZIP archive including the latest release version [here](https://github.com/hexonet/whmcs-ispapi-registrardns/raw/master/whmcs-ispapi-registrardns-latest.zip).
Feel free to subscribe yourself as Watcher of this repository to get informed about new released versions of this module.

## Minimum Requirements ##

For the latest WHMCS minimum system requirements, please refer to
[https://docs.whmcs.com/System_Requirements](https://docs.whmcs.com/System_Requirements)
As mentioned above, you need our [WHMCS "ISPAPI" Registrar Module](https://github.com/hexonet/whmcs-ispapi-registrar) as base.

## Contributing ##

Please read [our development guide](https://github.com/hexonet/whmcs-ispapi-registrardns/wiki/Development-Guide) for details on our code of conduct, and the process for submitting pull requests to us.

## Authors ##

* **Kai Schwarz** - *development* - [PapaKai](https://github.com/papakai)

See also the list of [contributors](https://github.com/hexonet/whmcs-ispapi-registrardns/graphs/contributors) who participated in this project.

## License ##

This project is licensed under the MIT License - see the [LICENSE](https://github.com/hexonet/whmcs-ispapi-registrardns/blob/master/LICENSE) file for details.

[HEXONET GmbH](https://hexonet.net)
