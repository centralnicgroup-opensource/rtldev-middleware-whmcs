## [1.0.2](https://github.com/hexonet/whmcs-ispapi-registrardns/compare/v1.0.1...v1.0.2) (2021-01-26)


### Bug Fixes

* **ci:** migration from Travis CI to GitHub Actions; replace make with gulp ([b148fd0](https://github.com/hexonet/whmcs-ispapi-registrardns/commit/b148fd00b9f3df2a80c071c389c72a8b0ffceae9))
* **dep-bump:** upgrade @hexonet/semantic-release-github-whmcsbase-config to v2.0.2 ([c3d6d2d](https://github.com/hexonet/whmcs-ispapi-registrardns/commit/c3d6d2d5f9b82b65134d58e24a92f5c5c7281583))
* **psr12:** applied formatting ([db06240](https://github.com/hexonet/whmcs-ispapi-registrardns/commit/db062409d8e8da7fe744cecbbf0d21ccd2eb316e))

## [1.0.1](https://github.com/hexonet/whmcs-ispapi-registrardns/compare/v1.0.0...v1.0.1) (2020-06-02)


### Bug Fixes

* **ci:** fixed makefile: wrong location of ispapidns.php ([a26af54](https://github.com/hexonet/whmcs-ispapi-registrardns/commit/a26af54b44963f4603b69c12e7e078743d3b8237))

# 1.0.0 (2020-06-02)


### chore

* **ci/cd:** added initial build and release process ([d5e1b4d](https://github.com/hexonet/whmcs-ispapi-registrardns/commit/d5e1b4db76602e3e0fd29c832a292fb06b2eeff4))


### BREAKING CHANGES

* **ci/cd:** just triggering first initial release
