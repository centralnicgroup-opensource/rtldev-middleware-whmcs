<?php

require_once dirname(__FILE__) . "/../ispapi/ispapi.php";

use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\Helper;

define("ISPAPIDNS_MODULE_VERSION", "1.0.2");

function ispapidns_getConfigArray()
{
    $configarray = array(
     "FriendlyName" => array("Type" => "System", "Value" => "Manual/EMail Registrations + HEXONET DNS"),
     "Description" => array("Type" => "System", "Value" => "This module can be used for manual domain registrations, with automatic DNS"),
     "EmailAddress" => array( "Type" => "text", "Size" => "40", "Description" => "Enter the email address notifications should be sent to", ),
    );
    return $configarray;
}

function ispapidns_GetNameservers($params)
{
    $dnszone = $params["sld"] . "." . $params["tld"] . ".";
    $values["error"] = "";
    $command = array(
        "COMMAND" => "QueryDNSZoneRRList",
        "DNSZONE" => $dnszone,
        "SHORT" => 1,
        "EXTENDED" => 1
    );
    $response = Ispapi::call($command);
    $count = 0;
    if ($response["CODE"] == 200) {
        $values = array(
            "error" => "",
            "ns1" => "",
            "ns2" => "",
            "ns3" => "",
            "ns4" => "",
        );

        $i = 0;
        foreach ($response["PROPERTY"]["RR"] as $rr) {
            $fields = explode(" ", $rr);
            $domain = array_shift($fields);
            $ttl = array_shift($fields);
            $class = array_shift($fields);
            $rrtype = array_shift($fields);

            if (($rrtype == "NS") && ($domain == "@")) {
                $count++;
                if ($fields[0] == "@") {
                    $values["ns$count"] = $params["sld"] . "." . $params["tld"];
                } elseif (preg_match('/^(.*)\.$/', $fields[0], $m)) {
                    $values["ns$count"] = $m[1];
                } else {
                    $values["ns$count"] = $fields[0] . "." . $params["sld"] . "." . $params["tld"];
                }

                $i++;
            }
        }
    } else {
        $values["error"] = $response["DESCRIPTION"];
    }
    return $values;
}

function ispapidns_SaveNameservers($params)
{
    global $CONFIG;
    $command = "Update Domain Nameservers";
    $message = "Domain: " . $params["sld"] . "." . $params["tld"] . "<br>Nameserver 1: " . $params["ns1"] . "<br>Nameserver 2: " . $params["ns2"] . "<br>Nameserver 3: " . $params["ns3"] . "<br>Nameserver 4: " . $params["ns4"] . "";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: " . $CONFIG["CompanyName"] . " <" . $CONFIG["Email"] . ">\r\n";
    mail($params["EmailAddress"], $command, $message, $headers);

    //return ispapidns_CreateDNSZone($params);

    $dnszone = $params["sld"] . "." . $params["tld"] . ".";
    $values["error"] = "";
    $command = array(
        "COMMAND" => "UpdateDNSZone",
        "DNSZONE" => $dnszone,
        "INCSERIAL" => 1,
        "DELRR" => array("@ NS"),
        "ADDRR" => array(),
    );
    if (strlen($params["ns1"])) {
        $command["ADDRR"][] = "@ NS " . $params["ns1"] . ".";
    }
    if (strlen($params["ns2"])) {
        $command["ADDRR"][] = "@ NS " . $params["ns2"] . ".";
    }
    if (strlen($params["ns3"])) {
        $command["ADDRR"][] = "@ NS " . $params["ns3"] . ".";
    }
    if (strlen($params["ns4"])) {
        $command["ADDRR"][] = "@ NS " . $params["ns4"] . ".";
    }
    $response = Ispapi::call($command);
    if ($response["CODE"] == 200) {
    } else {
        $values["error"] = $response["DESCRIPTION"];
    }
    return $values;
}

function ispapidns_GetDNS($params)
{
    $config = getregistrarconfigoptions("ispapi");
    foreach ($config as $key => $value) {
        $params[$key] = $config[$key];
        $params["original"][$key] = $config[$key];
    }
    return ispapi_GetDNS($params);
}


function ispapidns_SaveDNS($params)
{
    $config = getregistrarconfigoptions("ispapi");
    foreach ($config as $key => $value) {
        $params[$key] = $config[$key];
        $params["original"][$key] = $config[$key];
    }
    return ispapi_SaveDNS($params);
}


function ispapidns_GetEmailForwarding($params)
{
    $config = getregistrarconfigoptions("ispapi");
    foreach ($config as $key => $value) {
        $params[$key] = $config[$key];
        $params["original"][$key] = $config[$key];
    }
    return ispapi_GetEmailForwarding($params);
}

function ispapidns_SaveEmailForwarding($params)
{
    $config = getregistrarconfigoptions("ispapi");
    foreach ($config as $key => $value) {
        $params[$key] = $config[$key];
        $params["original"][$key] = $config[$key];
    }
    return ispapi_SaveEmailForwarding($params);
}

function ispapidns_CreateDNSZone($params)
{
    $dnszone = $params["sld"] . "." . $params["tld"] . ".";
    $values["error"] = "";
    $command = array(
        "COMMAND" => "CreateDNSZone",
        "DNSZONE" => $dnszone,
        "RR" => array(),
    );
    if (strlen($params["ns1"])) {
        $command["RR"][] = "@ NS " . $params["ns1"] . ".";
    }
    if (strlen($params["ns2"])) {
        $command["RR"][] = "@ NS " . $params["ns2"] . ".";
    }
    if (strlen($params["ns3"])) {
        $command["RR"][] = "@ NS " . $params["ns3"] . ".";
    }
    if (strlen($params["ns4"])) {
        $command["RR"][] = "@ NS " . $params["ns4"] . ".";
    }

    $response = Ispapi::call($command);
    if ($response["CODE"] == 200) {
    } else {
        $values["error"] = $response["DESCRIPTION"];
    }
    return $values;
}

function ispapidns_RegisterDomain($params)
{
    global $CONFIG;
    $command = "Register Domain";
    $message = "Domain: " . $params["sld"] . "." . $params["tld"] . "<br>Registration Period: " . $params["regperiod"] . "<br>Nameserver 1: " . $params["ns1"] . "<br>Nameserver 2: " . $params["ns2"] . "<br>Nameserver 3: " . $params["ns3"] . "<br>Nameserver 4: " . $params["ns4"] . "<br>RegistrantFirstName: " . $params["firstname"] . "<br>RegistrantLastName: " . $params["lastname"] . "<br>RegistrantOrganizationName: " . $params["companyname"] . "<br>RegistrantAddress1: " . $params["address1"] . "<br>RegistrantAddress2: " . $params["address2"] . "<br>RegistrantCity: " . $params["city"] . "<br>RegistrantStateProvince: " . $params["state"] . "<br>RegistrantCountry: " . $params["country"] . "<br>RegistrantPostalCode: " . $params["postcode"] . "<br>RegistrantPhone: " . $params["phonenumber"] . "<br>RegistrantEmailAddress: " . $params["email"] . "<br>AdminFirstName: " . $params["adminfirstname"] . "<br>AdminLastName: " . $params["adminlastname"] . "<br>AdminOrganizationName: " . $params["admincompanyname"] . "<br>AdminAddress1: " . $params["adminaddress1"] . "<br>AdminAddress2: " . $params["adminaddress2"] . "<br>AdminCity: " . $params["admincity"] . "<br>AdminStateProvince: " . $params["adminstate"] . "<br>AdminCountry: " . $params["admincountry"] . "<br>AdminPostalCode: " . $params["adminpostcode"] . "<br>AdminPhone: " . $params["adminphonenumber"] . "<br>AdminEmailAddress: " . $params["adminemail"] . "";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: " . $CONFIG["CompanyName"] . " <" . $CONFIG["Email"] . ">\r\n";
    mail($params["EmailAddress"], $command, $message, $headers);

    ispapidns_CreateDNSZone($params);
}

function ispapidns_TransferDomain($params)
{
    global $CONFIG;
    $command = "Transfer Domain";
    $message = "Domain: " . $params["sld"] . "." . $params["tld"] . "<br>Registration Period: " . $params["regperiod"] . "<br>Transfer Secret: " . $params["transfersecret"] . "<br>RegistrantFirstName: " . $params["firstname"] . "<br>RegistrantLastName: " . $params["lastname"] . "<br>RegistrantOrganizationName: " . $params["companyname"] . "<br>RegistrantAddress1: " . $params["address1"] . "<br>RegistrantAddress2: " . $params["address2"] . "<br>RegistrantCity: " . $params["city"] . "<br>RegistrantStateProvince: " . $params["state"] . "<br>RegistrantCountry: " . $params["country"] . "<br>RegistrantPostalCode: " . $params["postcode"] . "<br>RegistrantPhone: " . $params["phonenumber"] . "<br>RegistrantEmailAddress: " . $params["email"] . "";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: " . $CONFIG["CompanyName"] . " <" . $CONFIG["Email"] . ">\r\n";
    mail($params["EmailAddress"], $command, $message, $headers);

    ispapidns_CreateDNSZone($params);
}

function ispapidns_RenewDomain($params)
{
    global $CONFIG;
    $command = "Renew Domain";
    $message = "Domain: " . $params["sld"] . "." . $params["tld"] . "<br>Registration Period: " . $params["regperiod"] . "";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: " . $CONFIG["CompanyName"] . " <" . $CONFIG["Email"] . ">\r\n";
    mail($params["EmailAddress"], $command, $message, $headers);
}
