# WHMCS "ISPAPI" Premium DNS provisioning Module #

[![semantic-release](https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg)](https://github.com/semantic-release/semantic-release)
[![Build Status](https://github.com/hexonet/whmcs-ispapi-premiumdns/workflows/Release/badge.svg?branch=master)](https://github.com/hexonet/whmcs-ispapi-premiumdns/workflows/Release/badge.svg?branch=master)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![PRs welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/hexonet/whmcs-ispapi-premiumdns/blob/master/CONTRIBUTING.md)

This Repository covers the WHMCS Premium DNS Module of HEXONET. It provides the following features in WHMCS:

## Supported Features ##

The ISPAPI Premium DNS Module supports the following functions and features:

* Unified handling of different suppliers
* Support for testing environment
* Premium DNS products directly connected to the ISPAPI Registrar Module
* Premium DNS addon
  * Load available Premium DNS plans and import them under a product group
  * Bulk price update by using a profit margin
  * Support for different currencies

## Premium DNS Product Features ##

Also, check out our [FAQ Section](https://github.com/hexonet/whmcs-ispapi-premiumdns/wiki/FAQs).

* 6 nodes in our Global Anycast DNS network
* Works with any domain name regardless
 of registrar
* Supports IPv6 resolution and management
 of AAAA resource records
* Supports DNSSEC natively
* Supports secondary DNS configuration
* Provides hourly/daily/monthly reports to
 track DNS usage per zone
* 99.99% uptime SLA
* 24/7 real time monitoring of DNS zone
* REST and SOAP API to automate DNS
 management
* Manage DNS zone via HEXONET's Control Panel,
 a white-label Web-based portal
* Changes to DNS configuration is propagated
 globally within 2 seconds (on average)
* Worldwide DNS response time as low as 10ms
* 345.6 million DNS queries responded every day

A geographically distributed Anycast DNS solution gives you lightning fast DNS responses from the nearest
DNS service data center. With highly redundant DNS nodes per DNS service data center paired together
with the Anycast DNS architecture, HEXONET guarantees a 99.99% reliability SLA.

HEXONET's current data centers for Premium DNS:

* Vancouver, Canada
* Frankfurt, Germany
* Saarlouis, Germany
* London, UK
* Dallas, USA
* Tampa, USA

More nodes available soon!

## Resources ##

* [Usage Guide](https://github.com/hexonet/whmcs-ispapi-premiumdns/wiki/Usage-Guide)
* [Release Notes](https://github.com/hexonet/whmcs-ispapi-premiumdns/releases)
* [Development Guide](https://github.com/hexonet/whmcs-ispapi-premiumdns/wiki/Development-Guide)

## Usage Guide ##

Download the ZIP archive including the latest release version [here](https://github.com/hexonet/whmcs-ispapi-premiumdns/raw/master/whmcs-ispapi-premiumdns-latest.zip).

Read the following to get more information ...

* [Getting started](https://github.com/hexonet/whmcs-ispapi-premiumdns/wiki/Usage-Guide#getting-started)
* [Configuration](https://github.com/hexonet/whmcs-ispapi-premiumdns/wiki/Usage-Guide#configuration)

## Minimum Requirements ##

For the latest WHMCS minimum system requirements, please refer to
[https://docs.whmcs.com/System_Requirements](https://docs.whmcs.com/System_Requirements)

## Contributing ##

Please read [our development guide](https://github.com/hexonet/whmcs-ispapi-premiumdns/wiki/Development-Guide) for details on our code of conduct, and the process for submitting pull requests to us.

## Authors ##

* **Anthony Schneider** - *development* - [AnthonySchn](https://github.com/anthonyschn)
* **Kai Schwarz** - *development* - [PapaKai](https://github.com/papakai)

See also the list of [contributors](https://github.com/hexonet/whmcs-ispapi-premiumdns/graphs/contributors) who participated in this project.

## License ##

This project is licensed under the MIT License - see the [LICENSE](https://github.com/hexonet/whmcs-ispapi-premiumdns/blob/master/LICENSE) file for details.

[HEXONET GmbH](https://hexonet.net)
