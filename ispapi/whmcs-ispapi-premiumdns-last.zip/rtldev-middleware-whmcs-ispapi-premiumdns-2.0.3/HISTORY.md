## [2.0.3](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v2.0.2...v2.0.3) (2021-01-27)


### Bug Fixes

* **ci:** migration to github actions and gulp ([f3307b7](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/f3307b7e230c908718ba78f3427aa3cf839f799c))

## [2.0.2](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v2.0.1...v2.0.2) (2020-05-27)


### Bug Fixes

* **versioning:** fixed issue with updating version number in server module part ([b563c44](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/b563c443d9efe8278b1c9842067f2e17df54f030))

## [2.0.1](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v2.0.0...v2.0.1) (2020-05-27)


### Bug Fixes

* **versioning:** moved version into config function ([93ea5cc](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/93ea5ccad271c3fbe414cb76aedc1c840baa9c30))

# [2.0.0](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.10...v2.0.0) (2020-04-27)


### Code Refactoring

* **migration:** to support v3.x.x of the ispapi registrar module ([393fe38](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/393fe38c3b9f1a0e4f05464d839ac9d5503fc4e0))


### BREAKING CHANGES

* **migration:** compatible with ISPAPI registrar module v3.x.x

## [1.2.10](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.9...v1.2.10) (2020-03-02)


### Performance Improvements

* **request-cancellation:** renewal mode set to AUTOEXPIRE on product cancellation order ([fbd04c9](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/fbd04c9c47da0f2034cce35fd582ae8c37e58d80))

## [1.2.9](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.8...v1.2.9) (2020-02-21)


### Bug Fixes

* **analytics:** fixed wrong last month usage summary and average usage data ([6a1c53e](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/6a1c53ed86fdee03a2cbe594c28dd9b066093a2c))

## [1.2.8](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.7...v1.2.8) (2020-02-17)


### Performance Improvements

* **regex:** updated regex to accept domain name or DNS zone in the text field ([47f4db7](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/47f4db78f0519dab23d07ab9fbe38401c105bb1c))

## [1.2.7](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.6...v1.2.7) (2020-02-11)


### Bug Fixes

* **SHA1:** removed SHA1 DS record to display ([5a8bb65](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/5a8bb65b6841aa137b52c975abf21ab6c751dfae))

## [1.2.6](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.5...v1.2.6) (2019-12-05)


### Bug Fixes

* **update:** regex for DNS zone field validation ([bf876ed](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/bf876ed41556c48d400c95c101e360458b9ce93f))

## [1.2.5](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.4...v1.2.5) (2019-10-08)


### Bug Fixes

* **assets:** review form paths and paths to assets ([c022452](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/c022452))

## [1.2.4](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.3...v1.2.4) (2019-09-17)


### Bug Fixes

* **release process:** review from scratch ([748789d](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/748789d))

## [1.2.3](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.2...v1.2.3) (2019-09-13)


### Bug Fixes

* **dep-bump:** Migrate CI to semantic-release-whmcs ([10b0e02](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/10b0e02))

## [1.2.2](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.1...v1.2.2) (2019-08-23)


### Bug Fixes

* **versioning:** introduce meta-data MODULEVersion ([84de005](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/84de005))

## [1.2.1](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.2.0...v1.2.1) (2019-08-16)


### Bug Fixes

* **logo:** updated to our new logo design ([bd75205](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/bd75205))

# [1.2.0](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.1.0...v1.2.0) (2019-07-19)


### Features

* **DNSSEC:** added 'view DNSSEC record' button ([a80caad](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/a80caad))
* **DNSSEC:** offer DNSSec service if available ([d47a453](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/d47a453))

# [1.1.0](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.0.2...v1.1.0) (2019-06-24)


### Features

* **pkg:** handle DNSSEC support for external domains ([aa257ed](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/aa257ed))

## [1.0.2](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.0.1...v1.0.2) (2019-05-20)


### Bug Fixes

* **CI:** include call of make file ([7a08ced](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/7a08ced))
* **CI:** update file permission on updateVersion.sh ([83d660f](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/83d660f))

## [1.0.1](https://github.com/hexonet/whmcs-ispapi-premiumdns/compare/v1.0.0...v1.0.1) (2019-05-20)


### Bug Fixes

* **template:** fix broken template ([3822b43](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/3822b43))

# 1.0.0 (2019-05-20)


### Features

* **pkg:** initial release ([6deca62](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/6deca62))
* **pkg:** initial release ([d8a4e38](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/d8a4e38))
* **pkg:** initial release ([39dbc9b](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/39dbc9b))
* **pkg:** initial release ([ede6346](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/ede6346))
* **pkg:** initial release ([b98b521](https://github.com/hexonet/whmcs-ispapi-premiumdns/commit/b98b521))
