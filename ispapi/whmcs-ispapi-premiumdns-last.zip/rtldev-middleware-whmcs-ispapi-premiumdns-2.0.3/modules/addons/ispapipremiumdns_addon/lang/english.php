<?php

$_ADDONLANG['load'] = "Load";
$_ADDONLANG['select_product_group'] = "Select Product Group";
$_ADDONLANG['selected_product_group'] = "Selected Product Group";
$_ADDONLANG['please_load_premium_DNS_plans'] = "Please load Premium DNS plans";
$_ADDONLANG['choose_one'] = "Choose one ...";
$_ADDONLANG['error'] = "ERROR!";
$_ADDONLANG['please_select_premium_DNS_plans'] = "Please select Premium DNS plans";
$_ADDONLANG['please_select_product_group'] = "Please select a product group";
$_ADDONLANG['update_successful'] = "Update successful!";
$_ADDONLANG['success_message'] = "Your products list has been updated successfully.";
$_ADDONLANG['bulk_price_update'] = "Bulk Price update";
$_ADDONLANG['profit_margin'] = "Profit Margin: ";
$_ADDONLANG['price'] = "Price";
$_ADDONLANG['currency'] = "Currency";
$_ADDONLANG['cost'] = "Cost";
$_ADDONLANG['sale'] = "Sale";
$_ADDONLANG['premium_DNS_plans'] = "Premium DNS plans";
