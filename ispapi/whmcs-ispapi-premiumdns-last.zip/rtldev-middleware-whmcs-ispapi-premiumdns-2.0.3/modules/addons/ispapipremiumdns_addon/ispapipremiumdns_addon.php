<?php

use WHMCS\Database\Capsule;
use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\LoadRegistrars;
use WHMCS\Module\Registrar\Ispapi\Helper;

/*
 * Configuration of the addon module.
 */
function ispapipremiumdns_addon_config()
{
    return [
        "name" => "ISPAPI Premium DNS Addon",
        "description" => "This addon allows you to quickly add and configure Premium DNS plans",
        "author" => "HEXONET",
        "language" => "english",
        "version" => "2.0.3"
    ];
}

function ispapipremiumdns_addon_upgrade($vars)
{
    //premium DNS plans
    $product_ids = Helper::SQLCall("SELECT * FROM tblproducts WHERE configoption3='ispapi'", array(), "fetchall");
    $description = "Please enter a domain name or a DNS zone";
    //remove regex and update description
    if ($product_ids["success"] && $product_ids['result']) {
        foreach ($product_ids['result'] as $key => $value) {
            Helper::SQLCall("UPDATE tblcustomfields SET regexpr='', description=? WHERE relid=?", array($description, $value['id']), "execute");
        }
    }
}

/*
 * Module interface functionality
 */
function ispapipremiumdns_addon_output($vars)
{
    add_hook('AdminAreaHeadOutput', 1, function ($vars) {
        $now = mktime();
        $wr = $vars['WEB_ROOT'];
        return <<<HTML
        <script>const wr = "{$wr}";</script>
        <link rel="stylesheet" href="{$wr}/modules/addons/ispapipremiumdns_addon/assets/ispapipremiumdns_addon.css?t={$now}">
HTML;
    });

    //for price formatting
    $userId = $_SESSION['adminid'];
    $currencyData = getCurrency($userId);

    //load all the ISPAPI registrars
    $ispapi_registrars = new LoadRegistrars();
    $_SESSION["ispapi_registrar"] = $ispapi_registrars->getLoadedRegistars();

    if (empty($_SESSION["ispapi_registrar"])) {
        die("The ispapi registrar authentication failed! Please verify your registrar credentials and try again.");
    }

    //smarty template
    $smarty = new Smarty();
    $smarty->compile_dir = $GLOBALS['templates_compiledir'];
    $smarty->caching = false;
    $smarty->assign('LANG', $vars['_lang']);//translations

    //display all the product groups that user has
    $product_groups = Helper::SQLCall("SELECT * FROM tblproductgroups", null, "fetchall");

    //check if user has any product groups. if not create one and display it
    if ($product_groups['success'] && $product_groups['result']) {
        //if there is only one product group, make it preselected
        if (sizeof($product_groups['result']) == 1) {
            $smarty->assign('product_group', $product_groups['result']);
        } else {
            //multiple product groups
            $smarty->assign('product_groups', $product_groups['result']);
        }
    } else {
        Helper::SQLCall("INSERT INTO tblproductgroups (name) VALUES ('Premium DNS plans')", null, "execute");

        $product_groups = Helper::SQLCall("SELECT * FROM tblproductgroups", null, "fetchall");

        $smarty->assign('product_groups', $product_groups['result']);
    }

    //collect premium dns plans under a user account
    $premiumdnsplans_and_prices = ispapipremiumdnscustom_premiumdnsplans_and_prices($_SESSION["ispapi_registrar"][0], $currencyData);

    //sort premium dns plans
    uksort($premiumdnsplans_and_prices, strnatcasecmp);

    //user currencies configured in whmcs
    $configured_currencies_in_whmcs = [];

    $currencies = Helper::getCurrencies();
    foreach ($currencies as $currency) {
        $configured_currencies_in_whmcs[$currency["id"]] = $currency["code"];
    }

    //product group selected by the user
    $selected_product_group = htmlspecialchars($_POST['selectedproductgroup']);

    //for prices with profit margin
    $premiumdnsplans_and_new_prices = array();

    //import (products) premium dns plans and prices (these are common for the smarty parts below)
    $smarty->assign('configured_currencies_in_whmcs', $configured_currencies_in_whmcs);
    $smarty->assign('premiumdnsplans_and_prices', $premiumdnsplans_and_prices);

    if (isset($_POST['loadplans'])) {
        $_SESSION['selectedproductgroup'] = $selected_product_group;
        //check of the product group is selected by user if not show a error message
        if (empty($_SESSION['selectedproductgroup'])) {
            $smarty->display(dirname(__FILE__) . '/templates/error.tpl');
            $smarty->display(dirname(__FILE__) . '/templates/step1.tpl');
        } else {
            $smarty->assign('session-selected-product-group', $_SESSION["selectedproductgroup"]);
            $smarty->display(dirname(__FILE__) . '/templates/step2.tpl');
        }
    } elseif (isset($_POST['addprofitmargin'])) {
        $profit_margin = $_POST['profitmargin'];
        if (!empty($profit_margin)) {
            //call a function to calculate profit margin
            $premiumdnsplans_and_new_prices = ispapipremiumdnscustom_calculate_profitmargin($premiumdnsplans_and_prices, $profit_margin, $currencyData);
            $smarty->assign('premiumdnsplans_and_prices', $premiumdnsplans_and_new_prices);
            $smarty->display(dirname(__FILE__) . '/templates/step2.tpl');
        } else {
            $smarty->display(dirname(__FILE__) . '/templates/step2.tpl');
        }
    } elseif (isset($_POST['import'])) {
        //to collect new prices, premium dns plans and (new) currency from POST and import
        if (isset($_POST["checkboxpremiumdnsplan"])) {
            ispapipremiumdnscustom_import_button($_SESSION["ispapi_registrar"][0], $currencyData);
        }

        //take post values of sale prices - when user edit sale prices manually, should be displayed same after 'import'
        //to display updated prices even after import
        $premiumDNS_plan_match_pattern = "/(.*)_saleprice/";
        foreach ($_POST as $key => &$value) {
            if (preg_match($premiumDNS_plan_match_pattern, $key, $match)) {
                $premiumdnsplans_and_prices[$match[1]]['Newprice'] = $value;
            }
        }

        $smarty->assign('premiumdnsplans_and_prices', $premiumdnsplans_and_prices);
        $smarty->assign('session-selected-product-group', $_SESSION["selectedproductgroup"]);

        $smarty->display(dirname(__FILE__) . '/templates/step2.tpl');
    } else {
        $smarty->display(dirname(__FILE__) . '/templates/step1.tpl');
    }
}

/*
 * collect premium dns plans under a user account
 */
function ispapipremiumdnscustom_premiumdnsplans_and_prices($registrar, $currencyData) //$currencyData['id']
{
    //premium dns plans
    $statususer_data = Ispapi::call(array("command" => "statususer"));
    $pattern_for_premium_DNS_plan = "/PRICE_CLASS_PREMIUMDNS_(.*)_ANNUAL$/";
    $premiumdnsplans_and_prices = array();
    if (preg_grep($pattern_for_premium_DNS_plan, $statususer_data["PROPERTY"]["RELATIONTYPE"])) {
        //collect all the premium DNS plans
        $list_of_plans = preg_grep($pattern_for_premium_DNS_plan, $statususer_data["PROPERTY"]["RELATIONTYPE"]);

        //prices of the premium DNS plans
        foreach ($list_of_plans as $key => &$premiumdns_plan) {
            //to match ispapi classes of premium dns plans
            preg_match($pattern_for_premium_DNS_plan, $premiumdns_plan, $plan);
            $ispapi_match_premiumdns_plan = $plan[1];
            //price of the premium dns plan
            $price = $statususer_data["PROPERTY"]["RELATIONVALUE"][$key];

            $price = formatCurrency($price, $currencyData['id']); //price formatting
            //collect premium dns plans and prices
            $premiumdnsplans_and_prices[$ispapi_match_premiumdns_plan]['Price'] = $price->toNumeric();
            //this 'newprice' is modifiable by the user and this is the price that will be imported when it is changed/unchanged by user.
            $premiumdnsplans_and_prices[$ispapi_match_premiumdns_plan]['Newprice'] = $price->toNumeric();

            //default currency (at hexonet)
            $pattern_for_currency = "/PRICE_CLASS_PREMIUMDNS_" . $plan[1] . "_CURRENCY$/";
            $currency_match = preg_grep($pattern_for_currency, $statususer_data["PROPERTY"]["RELATIONTYPE"]);
            $currency_match_keys = array_keys($currency_match);

            foreach ($currency_match_keys as $key) {
                if (array_key_exists($key, $statususer_data["PROPERTY"]["RELATIONVALUE"])) {
                    $plan_currency = $statususer_data["PROPERTY"]["RELATIONVALUE"][$key];
                }
            }
            $premiumdnsplans_and_prices[$ispapi_match_premiumdns_plan]['Defaultcurrency'] = $plan_currency;
        }
    }
    return $premiumdnsplans_and_prices;
}

/*
 * calculate profit margin of the product price
 */
function ispapipremiumdnscustom_calculate_profitmargin($premiumdnsplans_and_prices, $profit_margin, $currencyData)
{
    //prices with profit margin
    $premiumdnsplans_and_new_prices = $premiumdnsplans_and_prices;

    foreach ($premiumdnsplans_and_prices as $premiumdnsplan => &$price_defaultcurrency) {
        $percentage_of_price = ($profit_margin / 100) * $price_defaultcurrency['Price'];
        $new_price = $price_defaultcurrency['Price'] + $percentage_of_price;
        $new_price = formatCurrency($new_price, $currencyData['id']); //price formatting
        $premiumdnsplans_and_new_prices[$premiumdnsplan]['Newprice'] = $new_price->toNumeric();
    }

    return $premiumdnsplans_and_new_prices;
}

/*
 * To import selected premium dns plans/products
 */
function ispapipremiumdnscustom_import_button($registrar, $currencyData)
{
    $selected_product_group = $_POST['SelectedProductGroup'];

    $premiumdnsplan_match_pattern = "/(.*)_saleprice/";

    //POST values and checked items of premium dns plans are different. POST's are seperated by _ underscore where checked items not.
    $premiumdnsplans_and_new_prices = [];//will have all the premium dns plans which have new prices

    foreach ($_POST as $key => $value) {
        if (preg_match($premiumdnsplan_match_pattern, $key, $match)) {
            $value = formatCurrency($value, $currencyData['id']); //price formatting
            $premiumdnsplans_and_new_prices[$match[1]]['newprice'] = $value->toNumeric();
            //premium dns class
            $premiumdnsplans_and_new_prices[$match[1]]['premiumdnsClass'] = 'Premium DNS plan ' . strtoupper($match[1]);
            //for premium dns server module
            $premiumdnsplans_and_new_prices[$match[1]]['servertype'] = 'ispapipremiumdns';
            //registrar
            $premiumdnsplans_and_new_prices[$match[1]]['registrar'] = $registrar;
            //description
            if ($match[1] == 'ENTERPRISE') {
                $premiumdnsplans_and_new_prices[$match[1]]['description'] = 'Unlimited queries per month';
            } else {
                $premiumdnsplans_and_new_prices[$match[1]]['description'] = substr($match[1], 0, -1) . ' million queries per month';
            }
        }
    }

    //only checked items can be collected into premiumdnsplans_and_new_prices but it is not possible due to getting currect selected currency for each plan
    //for currency
    $currencies = [];
    $currency_pattern = "/currency/";

    foreach ($_POST as $key => $value) {
        if (preg_match($currency_pattern, $key)) {
            $currencies['currency'] = $value;
        }
    }

    //to merge each curreny value from currencies array premiumdnsplans_and_new_prices
    $i = -1;
    foreach ($premiumdnsplans_and_new_prices as $key => $value) {
        $i++;
        $premiumdnsplans_and_new_prices[$key]['currency'] = $currencies['currency'][$i];
    }

    //import only checked premium dns plans - unset/remove all other plans from $premiumdnsplans_and_new_prices
    foreach ($premiumdnsplans_and_new_prices as $key => $val) {
        if (array_search($key, $_POST['checkboxpremiumdnsplan']) === false) {
            unset($premiumdnsplans_and_new_prices[$key]);
        }
    }
    //import premiumdnsplans and new prices
    ispapipremiumdnscustom_importproducts($premiumdnsplans_and_new_prices, $selected_product_group);
}

/*
 * Import premium dns plans/products
 */
function ispapipremiumdnscustom_importproducts($premiumdnsplans_and_prices, $selected_product_group)
{
    //get the id of selected product group
    $product_group_id = Helper::SQLCall("SELECT id FROM tblproductgroups WHERE name=? LIMIT 1", array($selected_product_group), "fetch");

    foreach ($premiumdnsplans_and_prices as $premiumdns_plan => &$data) {
        //check if the product already exists under the selected product group
        $data_tblproduct = Helper::SQLCall("SELECT * FROM tblproducts WHERE configoption1=? AND gid=?", array($premiumdns_plan, $product_group_id['result']['id']), "fetch");
        if ($data_tblproduct['success']) {
            if (empty($data_tblproduct['result'])) {
                //insert the product if it does not exists //gid = product group id
                Helper::SQLCall("INSERT INTO tblproducts (type, gid, name, description, paytype, autosetup, servertype, configoption1, configoption2, configoption3) VALUES ('other', ?, ?, ?, 'recurring', 'payment', ?, ?, '1', ?)", array($product_group_id['result']['id'], $data['premiumdnsClass'], $data['description'], $data['servertype'], $premiumdns_plan, $data['registrar']), "execute");
                //ID of the inserted product to insert/update pricing (relid in tblpricing)
                //product_id = relid
                $product_id = Helper::SQLCall("SELECT id FROM tblproducts WHERE configoption1=? AND gid=? LIMIT 1", array($premiumdns_plan, $product_group_id['result']['id']), "fetch");

                //insert pricing
                $params_tblpricing = array(
                    ":type" => "product",
                    ":currency" => $data['currency'],
                    ":relid" => $product_id['result']['id'],
                    ":msetupfee" => "0",
                    ":qsetupfee" => "0",
                    ":ssetupfee" => "0",
                    ":asetupfee" => "0",
                    ":bsetupfee" => "0",
                    ":tsetupfee" => "0",
                    ":monthly" => "-1",
                    ":quarterly" => "-1",
                    ":semiannually" => "-1",
                    ":annually" => $data['newprice'],
                    ":biennially" => "-1",
                    ":triennially" => "-1"
                );
                Helper::SQLCall("INSERT INTO tblpricing ({{KEYS}}) VALUES ({{VALUES}})", $params_tblpricing, "execute");
                //insert custom fields //tblcustomfields
                $params_tblcustomfields = array(
                    ":type" => "product",
                    ":relid" => $product_id['result']['id'],
                    ":fieldname" => "DNS Zone",
                    ":fieldtype" => "text",
                    ":description" => "Please enter a domain name or a DNS zone",
                    ":required" => "on",
                    ":showorder" => "on",
                    ":showinvoice" => "on",
                );
                Helper::SQLCall("INSERT INTO tblcustomfields ({{KEYS}}) VALUES ({{VALUES}})", $params_tblcustomfields, "execute");
            } else {
                //the product exists then with which currency - there is possibility to store price of a product with as many currency as possible (if currencies configured in WHMCS)
                $data_tblpricing = Helper::SQLCall("SELECT * FROM tblpricing WHERE relid=?", array($data_tblproduct['result']['id']), "fetchall");
                //if the currency exists in the $data_tblpricing then update it with new price
                if (in_array($data['currency'], array_column($data_tblpricing['result'], 'currency'))) { // search value in the array
                    Helper::SQLCall("UPDATE tblpricing SET annually=? WHERE relid=? AND currency=?", array($data['newprice'], $data_tblproduct['result']['id'], $data['currency']), "execute");
                } else {
                    $params_tblpricing = array(
                        ":type" => "product",
                        ":currency" => $data['currency'],
                        ":relid" => $data_tblproduct['result']['id'],
                        ":msetupfee" => "0",
                        ":qsetupfee" => "0",
                        ":ssetupfee" => "0",
                        ":asetupfee" => "0",
                        ":bsetupfee" => "0",
                        ":tsetupfee" => "0",
                        ":monthly" => "-1",
                        ":quarterly" => "-1",
                        ":semiannually" => "-1",
                        ":annually" => $data['newprice'],
                        ":biennially" => "-1",
                        ":triennially" => "-1"
                    );
                    //if the currency does not exists, then insert it with new price with same relid
                    Helper::SQLCall("INSERT INTO tblpricing ({{KEYS}}) VALUES ({{VALUES}})", $params_tblpricing, "execute");
                }
            }
        }
    }

    //insert higher premium plan IDs into DB for the selected premium plan (only took higher available plans under selected product group id)
    $list_all_of_products = Helper::SQLCall("SELECT * FROM tblproducts WHERE servertype='ispapipremiumdns' AND gid=?", array($product_group_id['result']['id']), "fetchall");
    $upgrade_product_ids = array();

    foreach ($premiumdnsplans_and_prices as $key => &$values) {
        if ($key != 'ENTERPRISE') { //enterprise is the highest plan
            $keyNum = (int)$key;
            $upgrade_product_ids[$key] = [];
            foreach ($list_all_of_products['result'] as $product) {
                //if ENTERPRISE exists, include it to all plans since it is the highest plan
                if ($product['configoption1'] == 'ENTERPRISE') {
                    array_push($upgrade_product_ids[$key], $product['id']);
                }
                $configoption1Num = (int)$product['configoption1'];
                if ($configoption1Num > $keyNum) {
                    array_push($upgrade_product_ids[$key], $product['id']);
                }
            }
        }
    }

    foreach ($upgrade_product_ids as $key => &$value) {
        if (!empty($value)) {
            $product_id = Helper::SQLCall("SELECT id FROM tblproducts WHERE configoption1=? AND gid=? LIMIT 1", array($key, $product_group_id['result']['id']), "fetch");

            foreach ($value as $upgrade_productid) {
                //check if the upgrade id is already inserted to the select premium plan
                $upgradeproduct_exists =  Helper::SQLCall("SELECT * FROM tblproduct_upgrade_products WHERE product_id=? AND upgrade_product_id=?", array($product_id['result']['id'], $upgrade_productid), "fetch");
                if ($upgradeproduct_exists['success'] && empty($upgradeproduct_exists['result'])) {
                    //insert id of higher premium plan to the selected plan
                    $params_tblproduct_upgrade_products = array(
                        ":product_id" => $product_id['result']['id'],
                        ":upgrade_product_id" => $upgrade_productid
                    );
                    //if the currency does not exists, then insert it with new price with same relid
                    Helper::SQLCall("INSERT INTO tblproduct_upgrade_products ({{KEYS}}) VALUES ({{VALUES}})", $params_tblproduct_upgrade_products, "execute");
                }
            }
        }
    }
}
