<?php

namespace WHMCS\Module\Server\IspapiPremiumDNS\Client;

use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\Helper;

/**
 * Client Area Controller
 */
class Controller
{
    /**
     *
     *
     * @param array $params Module configuration parameters
     *
     *
     * @return array html code
     */
    public function productdetails($params)
    {
        //this array contain required data for the form
        $ispapipremiumdns = array();

        $dnsZone = $params['customfields']['DNS Zone'];
        $registrar = $params['configoption3'];

        //if domain (TLD) does not support DNSSEC, do not display DNSSEC support section
        $dnssecsupport = array('COMMAND' => 'QueryDomainRepositoryInfo',
                                'DOMAIN' => substr($dnsZone, 0, -1));

        $dnssecsupportResponse = Ispapi::call($dnssecsupport);

        $ispapipremiumdns['dnssec_support'] = 'yes';
        if ($dnssecsupportResponse['PROPERTY']['ZONESECDNSINTERFACE'][0] == 'NONE') {
            $ispapipremiumdns['dnssec_support'] = 'no';
        }

        $stausdomainresponse = Ispapi::call(array(
                            "COMMAND" => "StatusDomain",
                            "DOMAIN" => substr($dnsZone, 0, -1)));

        if ($stausdomainresponse['CODE'] == 200) {
            //'confirm' text for internal domain
            $ispapipremiumdns['confirm_disable_enable_dnssec'] = 'internal domain';
        }

        //statusDNSZone provides the required information about a registered premium DNS (object ID)
        $statusDNSResponse = Ispapi::call(array( 'COMMAND' => 'statusDNSZone',
                            'DNSzone' => $dnsZone));

        if ($statusDNSResponse['PROPERTY']['DNSSEC-MODE'][0] == 'AUTO') {
            //show 'view DNSSEC record' button if dnssec mode is auto
            $ispapipremiumdns['show_view_dnssec_record'] = 'yes';
            //DNSSEC record
            $ispapipremiumdns['keyrecord'] = $statusDNSResponse['PROPERTY']['DNSSEC-KEY'][0];
            $ispapipremiumdns['dsrecordssha256'] = $statusDNSResponse['PROPERTY']['DNSSEC-DS-SHA-256'][0];
        }

        //display info on the template based on the status WARNING|SUSPENDED|EXCEEDED
        $ispapipremiumdns['queryquotastatus'] = $statusDNSResponse['PROPERTY']['QUERY-QUOTA-STATUS'][0];

        if ($ispapipremiumdns['queryquotastatus'] == 'EXCEEDED' || $ispapipremiumdns['queryquotastatus'] == 'SUSPENDED') {
            $templateFile = 'templates/client/error.tpl';
            return array(
                'tabOverviewReplacementTemplate' => $templateFile,
                'templateVariables' => array(
                    'ispapipremiumdns' => $ispapipremiumdns,
                ),
            );
        }

        //if the DNS zone does not exist, no need to display template of the product
        //default whmcs template will be displayed
        if ($statusDNSResponse['CODE'] == 545) {
            return;
        }

        $statusPremiumDNSZone = array( 'COMMAND' => 'StatusPremiumDNS',
                                       'OBJECTID' => $statusDNSResponse['PROPERTY']['PREMIUMDNS'][0]);
        $statusPremiumDNSZoneResponse = Ispapi::call($statusPremiumDNSZone);
        //if the premium dns order is still pending, default whmcs template will be displayed
        if ($statusPremiumDNSZoneResponse['CODE'] == 504) {
            return;
        }

        //request cancellation:
        $cancellation_order = Helper::SQLCall("SELECT * FROM tblcancelrequests WHERE relid=?", array($params['serviceid']), "fetchall");
        if ($cancellation_order['success'] && $cancellation_order['result']) {
            if ($statusPremiumDNSZoneResponse['PROPERTY']['RENEWALMODE'] != 'AUTOEXPIRE') {
                $command = array( 'COMMAND' => 'SetPremiumDNSRenewalMode',
                                  'OBJECTID' => $statusDNSResponse['PROPERTY']['PREMIUMDNS'][0],
                                  'RENEWALMODE' => 'AUTOEXPIRE');
                $response = Ispapi::call($command);
            }
            //for message:
            $ispapipremiumdns['orderCancellation'] = "yes";
        }

        //required information in an array to display on the client area
        $ispapipremiumdns['DNS Zone'] = $statusPremiumDNSZoneResponse['PROPERTY']['DNSZONE'][0];
        $ispapipremiumdns['dnszoneDetails']['Status'] = $statusPremiumDNSZoneResponse['PROPERTY']['STATUS'][0];
        $ispapipremiumdns['dnszoneDetails']['Created date'] = $statusPremiumDNSZoneResponse['PROPERTY']['CREATEDDATE'][0];
        if ($statusPremiumDNSZoneResponse['PROPERTY']['SUBCLASS'][0] != 'ENTERPRISE') {//for wording
            $ispapipremiumdns['premiumdnszoneDetails']['Type of Plan'] = 'Premium ' . $statusPremiumDNSZoneResponse['PROPERTY']['SUBCLASS'][0];
            $ispapipremiumdns['premiumdnszoneDetails']['Maximum queries'] = substr($statusPremiumDNSZoneResponse['PROPERTY']['SUBCLASS'][0], 0, -1) . ' million queries per month';//this is not available in $statusPremiumDNSZoneResponse
        } else {
            $ispapipremiumdns['premiumdnszoneDetails']['Type of Plan'] = $statusPremiumDNSZoneResponse['PROPERTY']['SUBCLASS'][0];
            $ispapipremiumdns['premiumdnszoneDetails']['Maximum queries'] = 'Unlimited queries per month';
        }

        $ispapipremiumdns['premiumdnszoneDetails']['Expiration date'] = $statusPremiumDNSZoneResponse['PROPERTY']['EXPIRATIONDATE'][0];
        $ispapipremiumdns['currentRenewalMode'] = $statusPremiumDNSZoneResponse['PROPERTY']['RENEWALMODE'][0];

        //view analytics
        $periodicity = array('DAILY', 'MONTHLY');
        foreach ($periodicity as $period) {
            $queryDNSZoneStatsResponse = Ispapi::call(array('COMMAND' => 'QueryDNSZoneStats',
                                        'DNSzone' => $dnsZone,
                                        'PERIODICITY' => $period));

            if (($period == 'DAILY')) {
                //last 7 items
                $ispapipremiumdns['successcount7days'] = json_encode(array_slice($queryDNSZoneStatsResponse['PROPERTY']['RESPONSE-COUNT'], -7));
                $ispapipremiumdns['errorcount7days'] = json_encode(array_slice($queryDNSZoneStatsResponse['PROPERTY']['ERROR-COUNT'], -7));
                $ispapipremiumdns['dates7days'] = json_encode(array_slice($queryDNSZoneStatsResponse['PROPERTY']['DATE'], -7));
            }

            if (($period == 'MONTHLY')) {
                //summary of ussage - analytics
                $tmpUsage = 0;
                foreach ($queryDNSZoneStatsResponse['PROPERTY']['RESPONSE-COUNT'] as $responseCount) {
                    $tmpUsage = $tmpUsage + $responseCount;
                }

                //stats length should be length of subarray - RESPONSE-COUNT or ERROR-COUNT (both are with same length)
                $statslength = sizeof($queryDNSZoneStatsResponse['PROPERTY']['RESPONSE-COUNT']);

                //average query usage
                $averageUsage = $tmpUsage / $statslength;
                $averageUsageCal = $averageUsage / 1000000;
                $ispapipremiumdns['averageUsage'] = number_format($averageUsageCal, 2) . 'M';

                //percentage - average query usage
                $averagepercentageCal = ($averageUsage / $statusDNSResponse['PROPERTY']['QUERY-QUOTA-LIMIT'][0]) * 100;
                $ispapipremiumdns['averagepercentage'] =  ($averageUsage > 10000) ? number_format($averagepercentageCal, 2) : number_format(0, 2);

                //average last month query usage
                $lastmonthusage = ($statslength >= 2) ? ($queryDNSZoneStatsResponse['PROPERTY']['RESPONSE-COUNT'][$statslength - 2]) : 0; //24
                $lastmonthusageCal = $lastmonthusage / 1000000;
                $ispapipremiumdns['lastmonthusage'] = number_format($lastmonthusageCal, 2) . 'M';

                //percentage - average last month query usage
                $lastmonthpercentageCal = ($lastmonthusage / $statusDNSResponse['PROPERTY']['QUERY-QUOTA-LIMIT'][0]) * 100;
                $ispapipremiumdns['lastmonthpercentage'] = ($lastmonthusage > 10000) ? number_format($lastmonthpercentageCal, 2) : number_format(0, 2);

                //6months //last 6 items
                $ispapipremiumdns['successcount6months'] = json_encode(array_slice($queryDNSZoneStatsResponse['PROPERTY']['RESPONSE-COUNT'], -6));
                $ispapipremiumdns['errorcount6months'] = json_encode(array_slice($queryDNSZoneStatsResponse['PROPERTY']['ERROR-COUNT'], -6));
                $ispapipremiumdns['dates6months'] = json_encode(array_slice($queryDNSZoneStatsResponse['PROPERTY']['DATE'], -6));
            }

            //12month and 4 weeks values stay same as response data (DAILY and MONTHLY)
            $ispapipremiumdns['successcount' . $period] = json_encode($queryDNSZoneStatsResponse['PROPERTY']['RESPONSE-COUNT']);
            $ispapipremiumdns['errorcount' . $period] = json_encode($queryDNSZoneStatsResponse['PROPERTY']['ERROR-COUNT']);
            $ispapipremiumdns['dates' . $period] = json_encode($queryDNSZoneStatsResponse['PROPERTY']['DATE']);
        }
        //summary of usage - analytics
        $ispapipremiumdns['included'] = number_format($statusDNSResponse['PROPERTY']['QUERY-QUOTA-LIMIT'][0] / 1000000, 2) . 'M';
        $ispapipremiumdns['myusage'] = number_format($statusDNSResponse['PROPERTY']['QUERY-QUOTA-COUNT'][0] / 1000000, 2) . 'M';
        if ($statusDNSResponse['PROPERTY']['QUERY-QUOTA-COUNT'][0] > 10000 && $statusDNSResponse['PROPERTY']['QUERY-QUOTA-LIMIT'][0] !== 0) {
            $ispapipremiumdns['myusagepercentage'] = number_format((($statusDNSResponse['PROPERTY']['QUERY-QUOTA-COUNT'][0] / $statusDNSResponse['PROPERTY']['QUERY-QUOTA-LIMIT'][0]) * 100), 2);
        } else {
            $ispapipremiumdns['myusagepercentage'] = number_format(0, 2);
        }
        //remaining queries
        $remaining = $statusDNSResponse['PROPERTY']['QUERY-QUOTA-LIMIT'][0] - $statusDNSResponse['PROPERTY']['QUERY-QUOTA-COUNT'][0];
        $ispapipremiumdns['remaining'] = ($remaining > 0) ? number_format($remaining / 1000000, 2) . 'M' : number_format(0, 2);
        //usage resets in
        $timestamp = strtotime(date("d-m-Y"));
        $ispapipremiumdns['queryquotareset'] = (int)date('t', $timestamp) - (int)date('j', $timestamp) . ' days';

        //for donut
        $ispapipremiumdns['queryquotacount'] = json_encode($statusDNSResponse['PROPERTY']['QUERY-QUOTA-COUNT'][0]);
        $ispapipremiumdns['remainingjson'] =  json_encode($remaining);

        //DNSSEC support
        //if the dnszone exists in database table, show the button REENABLE
        $dnszone_exists = Helper::SQLCall('SELECT * FROM ispapi_premiumdns_dnssec WHERE dnszone=?', array($dnsZone), "fetch");
        $current_date = strtotime(date("Y-m-d H:i:s"));
        if ($dnszone_exists['success']) {
            if (!empty($dnszone_exists['result'])) {
                //if one day passed than the date to disable DNSSEC (clean up DNS zone level), throw a warning. User needs to manually clean up the database entry for the DNSZone and send UpdateDNSzone command on Cp.
                if ($current_date > $dnszone_exists['result']['dnssecdisable_date_utc']) {
                    $ispapipremiumdns['failed_dnssec_disabling'] = 'failed'; //for a warning/info message
                } else {
                    $ispapipremiumdns['reenable'] = 'REENABLE';
                }
            } else {
                //otherwise, dnssec status: AUTO or DISABLE
                $ispapipremiumdns['dnssecstatus'] = $statusDNSResponse['PROPERTY']['DNSSEC-MODE'][0];
            }
        }

        if ($_REQUEST['dnssecmode']) {
            $modifydomain = array('COMMAND' => 'ModifyDomain',
                                  'DOMAIN' => substr($dnsZone, 0, -1));

            if ($_REQUEST['dnssecmode'] == 'AUTO') { //enable dnssec
                $modifydnssecmode = array('COMMAND' => 'UPDATEDNSZONE',
                                          'DNSSEC-MODE' => $_REQUEST['dnssecmode'],
                                          'DNSZONE' => $dnsZone,
                                          'RESOLVETTLCONFLICTS' => 1);
                $modifydnssecmodeResponse = Ispapi::call($modifydnssecmode);
                //log module api response
                logModuleCall('ispapipremiumdns', __FUNCTION__, $modifydnssecmode, $modifydnssecmodeResponse, $modifydnssecmodeResponse);

                if ($modifydnssecmodeResponse['CODE'] == 200 && $stausdomainresponse["CODE"] == 200) {
                    //key record from statusDNSZone
                    //add records to domain. We add only one record
                    $modifydomain['SECDNS-KEY0'] = $statusDNSResponse['PROPERTY']['DNSSEC-KEY'][0];
                    $modifydomainResponse = Ispapi::call($modifydomain);
                    //log module
                    logModuleCall('ispapipremiumdns', __FUNCTION__, $modifydomain, $modifydomainResponse, $modifydomainResponse);
                    if ($modifydomainResponse['CODE'] != 200) {
                        $ispapipremiumdns['dnssecinfoerror'] = $modifydomainResponse['DESCRIPTION'];
                    } else {
                        //successfully enabled DNSSEC support
                        $ispapipremiumdns['dnssecinfosuccess'] = 'DNSSEC support successfully enabled on your domain ' . substr($dnsZone, 0, -1);
                    }
                } elseif ($stausdomainresponse["CODE"] == 545) {
                    //successfully enabled DNSSEC support
                    $ispapipremiumdns['dnssecinfosuccess'] = 'DNSSEC support successfully enabled on your zone ' . $dnsZone;
                    //add record on domain level info
                    $ispapipremiumdns['externaldomain_DNSSEC_enable_info'] = $statusDNSResponse['PROPERTY']['DNSSEC-KEY'][0] . trim();
                } else {
                    //error message failed modifydnssecmodeResponse
                    $ispapipremiumdns['dnssecinfoerror'] = $modifydnssecmodeResponse['DESCRIPTION'];
                }
            } elseif ($_REQUEST['dnssecmode'] == 'DISABLED') {
                //remove all key records on the domain name
                //get list of key records on the domain name by sending statusdomain command
                $secdnsds = array();
                if ($stausdomainresponse["CODE"] == 200) {
                    $secdnsds = (isset($stausdomainresponse["PROPERTY"]["SECDNS-DS"])) ? $stausdomainresponse["PROPERTY"]["SECDNS-DS"] : array();
                    $modifydomain["DELSECDNS-DS"] = array();
                    foreach ($secdnsds as $item) {
                        array_push($modifydomain["DELSECDNS-DS"], $item);
                    }
                    $modifydomainResponse = Ispapi::call($modifydomain);
                    //log module
                    logModuleCall('ispapipremiumdns', __FUNCTION__, $modifydomain, $modifydomainResponse, $modifydomainResponse);

                    if ($modifydomainResponse['CODE'] != 200) {
                        $ispapipremiumdns['dnssecinfoerror'] = $modifydomainResponse['DESCRIPTION'];
                    }
                }
                if ($modifydomainResponse['CODE'] == 200 || $stausdomainresponse["CODE"] == 545) {
                    //update the database with required information
                    //date in 10days
                    $ux = strtotime("+10 days");
                    $newDate = date("Y-m-d H:i:s", $ux);
                    //insert into database
                    $values = array(
                        ":user_id" => $params['userid'],
                        ":dnszone" => $dnsZone,
                        ":dnssecdisable_requested_date" => $current_date,
                        ":dnssecdisable_date" => $newDate,
                        ":dnssecdisable_date_utc" => $ux
                    );
                    Helper::SQLCall('INSERT INTO ispapi_premiumdns_dnssec ({{KEYS}}) VALUES ({{VALUES}})', $values, "execute");

                    //success message
                    if ($stausdomainresponse["CODE"] == 545) {
                        $ispapipremiumdns['externaldomain_DNSSEC_disable_info'] = $statusDNSResponse['PROPERTY']['DNSSEC-KEY'][0] . trim();
                        #$ispapipremiumdns['externaldomain_DNSSEC_info'] = "Please make sure to remove the following record on your domain level: <br>..".$statusDNSResponse['PROPERTY']['DNSSEC-KEY'][0]." <br>In case if you have already removed the record, please ignore this information.";

                        $ispapipremiumdns['dnssecinfosuccess'] = 'The cleanup on DNS zone level will be processed automatically on ' . $newDate;
                    } else {
                        $ispapipremiumdns['dnssecinfosuccess'] = 'DNSSEC is successfully disabled on domain level. The cleanup on DNS zone level will be processed automatically on ' . $newDate;
                    }
                }
            } elseif ($_REQUEST['dnssecmode'] == 'Re-enable DNSSEC') {
                //add back the key record to the domain name
                //get key record from statusDNSZone
                if ($stausdomainresponse["CODE"] == 200) { //only domains managed under HEXONET
                    //add key record to the domain
                    $modifydomain['SECDNS-KEY0'] = $statusDNSResponse['PROPERTY']['DNSSEC-KEY'][0];
                    $modifydomainResponse = Ispapi::call($modifydomain);

                    if ($modifydomainResponse['CODE'] != 200) {
                        //
                        $ispapipremiumdns['dnssecinfoerror'] = $modifydomainResponse['DESCRIPTION'];
                    } else {
                        //successfully added key record to the domain name
                        $ispapipremiumdns['dnssecinfosuccess'] = 'Re-enabled DNSSEC successfully for your domain ' . substr($dnsZone, 0, -1);
                    }
                } else {
                    //for external domain
                    $ispapipremiumdns['dnssecinfosuccess'] = 'Re-enabled DNSSEC successfully for your domain ' . substr($dnsZone, 0, -1);
                }
                //update the database table - delete the row based on the DNSZONE
                //delete this entry for external or internal domain name
                Helper::SQLCall('DELETE FROM ispapi_premiumdns_dnssec WHERE dnszone=? ', array($dnsZone), "execute");
            } else {
                //something went wrong contact support
                $ispapipremiumdns['dnssecinfoerror'] = 'Enable to modify DNSSEC support. Please contact support';
            }

            //template file
            $templateFile = 'templates/client/info.tpl';
            return array(
                'tabOverviewReplacementTemplate' => $templateFile,
                'templateVariables' => array(
                    'ispapipremiumdns' => $ispapipremiumdns,
                ),
            );
        }

        $templateFile = 'templates/client/clientarea.tpl';
        return array(
            'tabOverviewReplacementTemplate' => $templateFile,
            'templateVariables' => array(
                'ispapipremiumdns' => $ispapipremiumdns,
            ),
        );
    }
}
