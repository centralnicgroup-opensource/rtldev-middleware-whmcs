<?php

namespace WHMCS\Module\Server\IspapiPremiumDNS\Client;

/**
 * Sample Client Area Dispatch Handler
 */
class ClientDispatcher
{

    /**
     * Dispatch request.
     *
     * @param string $action
     * @param array $args
     *
     * @return string
     */
    public function dispatch($action, $args)
    {
        $controller = new Controller();
        // Verify requested action is valid and callable
        if (is_callable(array($controller, $action))) {
            return $controller->$action($args);
        }
    }
}
