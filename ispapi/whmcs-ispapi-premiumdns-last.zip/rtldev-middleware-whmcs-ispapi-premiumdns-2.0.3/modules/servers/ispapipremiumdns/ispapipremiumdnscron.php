<?php

date_default_timezone_set('UTC');
$root_path = $_SERVER["DOCUMENT_ROOT"];

$init_path = implode(DIRECTORY_SEPARATOR, array($root_path,"init.php"));

if (isset($GLOBALS["customadminpath"])) {
    $init_path = preg_replace("/(\/|\\\)" . $GLOBALS["customadminpath"] . "(\/|\\\)init.php$/", DIRECTORY_SEPARATOR . "init.php", $init_path);
}
if (file_exists($init_path)) {
    require_once($init_path);
} else {
    exit("cannot find init.php");
}

use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\LoadRegistrars;
use WHMCS\Module\Registrar\Ispapi\Helper;

$registrars = (new LoadRegistrars())->getLoadedRegistars();

//DNSSEC disable and notify customer per email
$current_utc_timestamp = strtotime(date("Y-m-d H:i:s")); //utc timestamp

$disable_dnssec_dnszones = Helper::SQLCall('SELECT * FROM ispapi_premiumdns_dnssec WHERE (dnssecdisable_date_utc <= ? )', array($current_utc_timestamp), "fetchall");
#$today_utc_timestamp = gmdate("Y-m-d H:i:s");//format in GMT/UTC date and time

$command = 'SendEmail';
$values["messagename"] = "Premium_DNS_notification";
if ($disable_dnssec_dnszones['success']) {
    foreach ($disable_dnssec_dnszones['result'] as $key => &$value) {
        //send updateDNSzone command diable DNSSEC (to clean up the key records on DNSZone)
        $modifydnssecmodeResponse = Ispapi::call(array('COMMAND' => 'UPDATEDNSZONE',
                                    'DNSSEC-MODE' => 'DISABLED',
                                    'DNSZONE' => $value['dnszone'],
                                    'RESOLVETTLCONFLICTS' => 1));

        if ($modifydnssecmodeResponse['CODE'] == 200) {
            //clean up the database table
            //update the database table - delete the row based on the DNSZONE
            Helper::SQLCall('DELETE FROM ispapi_premiumdns_dnssec WHERE dnszone=? ', array($value['dnszone']), "execute");

            //send email to customer that the DNSSEC is diabled
            $values["id"] = $value['user_id'];
            $values["customvars"] = array('disablednssec' => "OK", 'dnszone' => $value['dnszone']);
            $results = localAPI($command, $values);
        } else {
            //send customer an email about the error - dnssec diabling failed
            $values["id"] = $value['user_id'];
            $values["customvars"] = array('disablednssec' => "FAILED", 'dnszone' => $value['dnszone'], 'reason' => $modifydnssecmodeResponse['DESCRIPTION']);
            $results = localAPI($command, $values);
        }
    }
}

//to send cusotmer the status of the query usage
//userid and contact information
$command = 'GetClients';
$clients = localAPI($command);

//products of each user based on userid
foreach ($clients['clients'] as $key => &$data) {
    foreach ($data as $value) {
        $command = 'GetClientsProducts';
        $postData = array(
            'clientid' => $value['id'],
        );
        $client_products[] = localAPI($command, $postData);
    }
}

$query_quota_status_not_ok = array();
#QUERY-QUOTA-STATUS = WARNING | EXCEEDED | SUSPENDED | OK
foreach ($client_products as $key => &$clients) {
    foreach ($clients['products']['product'] as $products) {
        foreach ($products['customfields']['customfield'] as $ky => &$dnszone) {
            $statusDNSResponse = Ispapi::call(array( 'COMMAND' => 'statusDNSZone',
                                'DNSzone' => $dnszone['value']));
            //if the zone is not managed at hexonet, command fails. Therefore dont need to filter which products are using our module.
            if ($statusDNSResponse['CODE'] == 200) {
                if ($statusDNSResponse['PROPERTY']['QUERY-QUOTA-STATUS'][0] != 'OK') {
                    $query_quota_status_not_ok[$products['id']]['userid'] = $products['clientid'];
                    $query_quota_status_not_ok[$products['id']]['queryquotastatus'] = $statusDNSResponse['PROPERTY']['QUERY-QUOTA-STATUS'][0];
                    $query_quota_status_not_ok[$products['id']]['dnszone'] = $dnszone['value'];
                    $query_quota_status_not_ok[$products['id']]['currentplan'] = $statusDNSResponse['PROPERTY']['PREMIUMDNSCLASS'][0];
                }
            }
        }
    }
}

foreach ($query_quota_status_not_ok as $key => &$data) {
    $command = 'SendEmail';
    $values["messagename"] = "Premium_DNS_notification";
    $values["id"] = $data['userid'];
    $values["customvars"] = array('querystatus' => $data['queryquotastatus'], 'plan' => $data['currentplan'], 'dnszone' => $data['dnszone']);
    $results = localAPI($command, $values);
}
