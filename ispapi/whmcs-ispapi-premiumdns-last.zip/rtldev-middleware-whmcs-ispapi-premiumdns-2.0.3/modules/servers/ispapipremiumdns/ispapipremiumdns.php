<?php

/**
 * ISPAPI Premium DNS Provisioning Module for WHMCS
 *
 * Premium DNS Registrations using WHMCS & HEXONET
 *
 * For more information, please refer to the online documentation.
 * @see https://wiki.hexonet.net/wiki/WHMCS_Modules
 */

use WHMCS\Module\Server\IspapiPremiumDNS\Client\ClientDispatcher;
use WHMCS\Module\Registrar\Ispapi\Ispapi;
use WHMCS\Module\Registrar\Ispapi\LoadRegistrars;
use WHMCS\Module\Registrar\Ispapi\Helper;
use WHMCS\View\Menu\Item as MenuItem;

function ispapipremiumdns_MetaData()
{
    return [
        "DisplayName" => "ISPAPI Premium DNS",
        "MODULEVersion" => "2.0.3"
    ];
}

/*
 * Config options of the module.
 */
function ispapipremiumdns_ConfigOptions()
{
    //create a table to store info when disabling DNSSEC
    $dnssecdata = Helper::SQLCall("SHOW tables LIKE 'ispapi_premiumdns_dnssec'", null, "fetchall");
    if ($dnssecdata['success'] && empty($dnssecdata['result'])) {
        Helper::SQLCall(
            "CREATE TABLE ispapi_premiumdns_dnssec (
            user_id int(11) NOT NULL, 
            dnszone varchar(255) NOT NULL, 
            dnssecdisable_requested_date datetime NOT NULL, 
            dnssecdisable_date datetime NOT NULL, 
            dnssecdisable_date_utc int(11) NOT NULL)",
            null,
            "execute"
        );
    }

    //email template for cron - querystatus and disable dnssec
    $data = Helper::SQLCall("SELECT * FROM tblemailtemplates WHERE name='Premium_DNS_notification'", null, "fetchall");
    if ($data['success'] && empty($data['result'])) {
        $values = array(
            ":type" => 'general',
            ":name" => 'Premium_DNS_notification',
            ":subject" => 'Premium DNS notification from {$company_name}',
            ":message" => '<p>Dear {$client_name},</p><br /><p>{if $querystatus eq SUSPENDED} The DNS zone {$dnszone} with the premium plan {$plan} is suspended and will stop resolving to any queries. In order to restore your DNS zone, upgrade to higher tiered plan immediately. Or wait for an automated restore at the start of the following month. <br />Note, query counter is always reset at the beginning of each month, so suspended DNS zone in the previous month will be automatically restored due to the counter reset.<br />{else if $querystatus eq EXCEEDED}<br />The DNS zone {$dnszone} with the premium plan {$plan} has used 100% of its monthly query limit. Please upgrade to a higher tiered plan within 72 hours. Otherwise, the DNS zone will be suspended.<br />{else if $querystatus eq WARNING}<br />WARNING: The DNS zone {$dnszone} with the premium plan {$plan} has used 80% of its monthly query limit and is at risk of exceeding the monthly query limit.<p>{else if $disablednssec eq OK}<br />The DNSSEC has been successfully disabled on the DNS zone {$dnszone}</p><p>{else if $disablednssec eq FAILED} The DNSSEC disabling has been failed due to the following reason:  <b>{$reason}</b> .</p><p>Please contact support.</p><br />{/if}<br /></p><p>{$signature}</p>',
            ":disabled" => 0,
            ":custom" => 1,
            ":plaintext" => 0,
        );
        Helper::SQLCall('INSERT INTO tblemailtemplates ({{KEYS}}) VALUES ({{VALUES}})', $values, "execute");
    }

    //load all the ISPAPI registrars (Ispapi, Hexonet)
    $ispapi_registrars = new LoadRegistrars();
    $registrars = $ispapi_registrars->getLoadedRegistars();

    return array(
        'Premium DNS Product Class' => array(
            'Type' => 'text',
            'Size' => '25',
        ),
        'Years' => array(
            'Type' => 'dropdown',
            'Options' => '1,2,3,4,5,6,7,8,9,10'
        ),
        'Registrar' => array(
            'Type' => 'dropdown',
            'Options' => implode(",", $registrars)
        ),
    );
}

/*
 * Account will be created under Client Profile page > Products/Services, when ordered a premium DNS plan
 */
function ispapipremiumdns_CreateAccount(array $params)
{
    try {
        $premiumDNSProductClass = $params['configoption1'];
        $period = $params['configoption2'];
        $registrar = $params['configoption3'];
        $dnsZone = $params['customfields']['DNS Zone'];

        //trim if needed and add a dot
        $dnsZone = rtrim($dnsZone, '.') . '.'; //if user inputs a domain name, add a dot.

        $userid = $params['userid'];
        $postData = array(
            'clientid' => $userid,
            'stats' => true,
        );
        //list of domains the client has (based on userid)
        $whmcs_client_domains = localAPI('GetClientsDomains', $postData, array());
        //check if domain is registered
        $domain_exists = array_search(substr($dnsZone, 0, -1), array_column($whmcs_client_domains['domains']['domain'], 'domainname'));

        if ($domain_exists) {
            //command to create Premium DNS order
            $command = array( 'COMMAND' => 'CreatePremiumDNS',
                              'CLASS' => $premiumDNSProductClass,
                              'DNSZONE' => $dnsZone,
                              'PERIOD' => $period,
                              'RENEWALMODE' => 'AUTOEXPIRE');

            $response = Ispapi::call($command);

            //log the command and response to check which params has been sent to api
            logModuleCall('ispapipremiumdns', __FUNCTION__, $command, $response, $response);

            //if the DNS zone already exists, it fails here
            if ($response['CODE'] != 200) {
                throw new Exception($response['CODE'] . ' ' . $response['DESCRIPTION']);
            }
        } else {
            throw new Exception('Please make sure the domain ' . substr($dnsZone, 0, -1) . ' exists in your account');
        }
    } catch (Exception $e) {
        logModuleCall(
            'ispapipremiumdns',
            __FUNCTION__,
            'DNS ZONE: ' . $params['customfields']['DNS Zone'],
            "",
            $e->getMessage()
        );
        return $e->getMessage();
    }
    return 'success';
}

/*
 * On ClientArea, product details page
 */
function ispapipremiumdns_ClientArea($params)
{
    //hook to rename the action 'Upgrade/Downgrade' to 'Upgrade' on the client area
    add_hook('ClientAreaPrimarySidebar', 1, function (MenuItem $primarySidebar) {
        //note: check for if child 'Upgrade/Downgrade' is not null because for Enterprise plan there is no upgrading process
        if (!is_null($primarySidebar->getchild('Service Details Actions')) && !is_null($primarySidebar->getchild('Service Details Actions')->getChild("Upgrade/Downgrade"))) {
            $primarySidebar->getchild('Service Details Actions')
            ->getChild("Upgrade/Downgrade")
            ->setLabel("Upgrade");
        }
    });
    //hook to include css and js
    add_hook('ClientAreaHeadOutput', 1, function ($vars) {
        $now = mktime();
        $wr = $vars['WEB_ROOT'];
        return <<<HTML
        <script>const wr = "{$wr}";</script>
        <!-- module's css -->
        <link rel="stylesheet" href="{$wr}/modules/servers/ispapipremiumdns/assets/styles.css?t={$now}">
        <!-- JQuery-UI (accordion) -->
        <link rel="stylesheet" href="{$wr}/modules/servers/ispapipremiumdns/assets/jquery-ui.min.css?t={$now}">
        <script src="{$wr}/modules/servers/ispapipremiumdns/assets/jquery-ui.min.js?t={$now}"></script>
        <!-- Chart.js (graph, donut) -->
        <script src="{$wr}/modules/servers/ispapipremiumdns/assets/Chart.min.js?t={$now}"></script>
HTML;
    });

    //check if registrar module installed
    $registrars = (new LoadRegistrars())->getLoadedRegistars();
    //if not installed display a warning message
    if (empty($registrars)) {
        $templateFile = 'templates/client/error.tpl';
        return array(
            'tabOverviewReplacementTemplate' => $templateFile,
        );
    }

    $dispatcher = new ClientDispatcher();
    return $dispatcher->dispatch($_REQUEST['action'], $params);
}

/*
 * Upgrade product
 * the upgrade option will be shown in the client area. once the upgrade is triggered, the invoice will be generated and and client will receive an email about upgrade
 * the upgrade can also be triggered from admin area
 */
function ispapipremiumdns_ChangePackage($params)
{
    try {
        $dnsZone = $params['customfields']['DNS Zone'];
        $registrar = $params['configoption3'];
        //selected upgrade plan
        $upgradePlan = $params['configoption1'];

        //status of the premium dns
        $statusDNSResponse = Ispapi::call(array( 'COMMAND' => 'statusDNSZone',
                            'DNSzone' => $dnsZone));

        if ($statusDNSResponse['CODE'] != 200) {
            throw new Exception($statusDNSResponse['CODE'] . ' ' . $statusDNSResponse['DESCRIPTION']);
        }

        $upgradepremiumplan = array('COMMAND' => 'UpgradePremiumDNS',
                                    'CLASS' => $upgradePlan,
                                    'OBJECTID' => $statusDNSResponse['PROPERTY']['PREMIUMDNS'][0],
                                    'RENEWALMODE' => 'AUTOEXPIRE');

        $upgradepremiumplanResponse = Ispapi::call($upgradepremiumplan);

        //log the command and response to check which params has been sent to api
        logModuleCall('ispapipremiumdns', __FUNCTION__, $upgradepremiumplan, $upgradepremiumplanResponse, $upgradepremiumplanResponse);

        if ($upgradepremiumplanResponse['CODE'] != 200) {
            throw new Exception($upgradepremiumplanResponse['CODE'] . ' ' . $upgradepremiumplanResponse['DESCRIPTION']);
        }
    } catch (Exception $e) {
        logModuleCall(
            'ispapipremiumdns',
            __FUNCTION__,
            'DNS ZONE: ' . $params['customfields']['DNS Zone'],
            "",
            $e->getMessage()
        );
        return $e->getMessage();
    }

    return 'success';
}

/*
 * Renew premium plan admin area
 *
 */
function ispapipremiumdns_Renew($params)
{
    try {
        $dnsZone = $params['customfields']['DNS Zone'];
        $registrar = $params['configoption3'];

        //status of the premium dns
        $statusDNSResponse = Ispapi::call(array( 'COMMAND' => 'statusDNSZone',
                            'DNSzone' => $dnsZone));

        if ($statusDNSResponse['CODE'] != 200) {
            throw new Exception($statusDNSResponse['CODE'] . ' ' . $statusDNSResponse['DESCRIPTION']);
        }

        //renew premium dns plan
        $renewpremiumdnsplan = array( 'COMMAND' => 'PayPremiumDNSRenewal',
                                      'OBJECTID' =>  $statusDNSResponse['PROPERTY']['PREMIUMDNS'][0]);

        $renewpremiumdnsplanResponse = Ispapi::call($renewpremiumdnsplan);
        //log the command and response to check which params has been sent to api
        logModuleCall('ispapipremiumdns', __FUNCTION__, $renewpremiumdnsplan, $renewpremiumdnsplanResponse, $renewpremiumdnsplanResponse);

        if ($renewpremiumdnsplanResponse['CODE'] != 200) {
            throw new Exception($renewpremiumdnsplanResponse['CODE'] . ' ' . $renewpremiumdnsplanResponse['DESCRIPTION']);
        }
    } catch (Exception $e) {
        logModuleCall(
            'ispapipremiumdns',
            __FUNCTION__,
            'DNS ZONE: ' . $params['customfields']['DNS Zone'],
            "",
            $e->getMessage()
        );
        return $e->getMessage();
    }

    return 'success';
}
