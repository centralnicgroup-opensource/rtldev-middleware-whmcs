// prettier.config.js, or some other file
module.exports = require('prettier-config-xo');
